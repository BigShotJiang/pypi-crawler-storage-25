"""CRUD endpoints for the artifacts router — dual-mode (local + enterprise).

Contains: list_artifacts (GET /), get_artifact (GET /{artifact_id}),
          create_artifact (POST /), update_artifact (PUT /{artifact_id}),
          update_artifact_parameters (PUT /{artifact_id}/parameters),
          delete_artifact (DELETE /{artifact_id}),
          check_artifact_upstream (GET /{artifact_id}/upstream)

Each endpoint branches on ``settings.edition == "enterprise"`` and delegates
to the appropriate handler.  Local handlers are copied verbatim from
``_legacy.py`` so behaviour is identical.  Enterprise handlers use
``IArtifactRepository`` methods only — they never access ``artifact_mgr`` or
``collection_mgr``.
"""

from __future__ import annotations

import logging
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status

from skillmeat.api.dependencies import (
    ArtifactManagerOptDep,
    ArtifactRepoDep,
    CollectionManagerOptDep,
    CollectionRepoDep,
    DbCollectionArtifactRepoDep,
    DbSessionDep,
    DeploymentRepoDep,
    MarketplaceCatalogRepoDep,
    SettingsDep,
    SyncManagerOptDep,
    get_auth_context,
    require_auth,
    verify_api_key,
)
from skillmeat.api.middleware.auth import TokenDep
from skillmeat.api.schemas.artifacts import (
    ArtifactCreateRequest,
    ArtifactCreateResponse,
    ArtifactListResponse,
    ArtifactResponse,
    ArtifactUpdateRequest,
    ArtifactUpstreamInfo,
    ArtifactUpstreamResponse,
    DeploymentStatistics,
    ProjectDeploymentInfo,
)
from skillmeat.api.schemas.discovery import (
    ParameterUpdateRequest,
    ParameterUpdateResponse,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.common import ErrorResponse, PageInfo
from skillmeat.api.services.artifact_cache_service import parse_deployments
from skillmeat.cache.models import (
    CollectionArtifact as DbCollectionArtifact,
)
from skillmeat.core.artifact import ArtifactType

from skillmeat.api.services import refresh_single_artifact_cache
from skillmeat.cache.models import get_session
from skillmeat.core.interfaces.dtos import ArtifactDTO

from ._helpers import (
    _is_uuid,
    decode_cursor,
    encode_cursor,
    parse_artifact_id,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/artifacts",
    tags=["artifacts"],
    dependencies=[Depends(verify_api_key)],
)


# ---------------------------------------------------------------------------
# Helper: map ArtifactDTO → ArtifactResponse (enterprise path)
# ---------------------------------------------------------------------------


def _dto_to_response(dto: ArtifactDTO) -> ArtifactResponse:
    """Convert an enterprise-repo ArtifactDTO to an ArtifactResponse schema.

    Only the fields that can be populated from the DTO directly are filled;
    optional enrichment fields (deployment_stats, collections, drift) default
    to None / empty list as they require separate queries not performed on
    the enterprise list path.

    Args:
        dto: ArtifactDTO returned by IArtifactRepository.

    Returns:
        ArtifactResponse suitable for inclusion in ArtifactListResponse.
    """
    from datetime import datetime, timezone

    # Derive ``added`` / ``updated`` from DTO timestamps; fall back to now.
    _now = datetime.now(timezone.utc)

    def _parse_ts(ts: str | None) -> datetime:
        if not ts:
            return _now
        try:
            return datetime.fromisoformat(ts)
        except ValueError:
            return _now

    added = _parse_ts(dto.created_at)
    updated = _parse_ts(dto.updated_at)

    # Determine origin from source field (best-effort heuristic).
    source = dto.source or ""
    if source.startswith("github:") or "/" in source:
        origin = "github"
    elif source.startswith("marketplace:"):
        origin = "marketplace"
    else:
        origin = "local"

    # Populate upstream tracking info when the artifact has a GitHub-backed
    # source URL.  Enterprise artifacts store the upstream URL in source_url
    # (mapped to ArtifactDTO.source by EnterpriseArtifactRepository._artifact_to_dto).
    # This field is required by the frontend's hasValidUpstreamSource() check.
    upstream_info: ArtifactUpstreamInfo | None = None
    if origin in ("github", "marketplace") and source:
        upstream_info = ArtifactUpstreamInfo(
            tracking_enabled=True,
            current_sha=None,
            upstream_sha=None,
            update_available=False,
            has_local_modifications=False,
            drift_status="none",
        )

    return ArtifactResponse(
        id=dto.id,
        uuid=dto.uuid or "",
        name=dto.name,
        type=dto.artifact_type,
        source=source,
        origin=origin,
        origin_source=None,
        version=dto.version or "latest",
        aliases=[],
        tags=list(dto.tags) if dto.tags else [],
        target_platforms=None,
        metadata=None,
        upstream=upstream_info,
        deployment_stats=None,
        deployments=None,
        collections=[],
        added=added,
        updated=updated,
    )


# ---------------------------------------------------------------------------
# Enterprise list handler
# ---------------------------------------------------------------------------


async def _list_artifacts_enterprise(
    artifact_repo: ArtifactRepoDep,
    settings: SettingsDep,
    auth_context: AuthContext,
    limit: int,
    offset: int,
    artifact_type: Optional[str],
    tags: Optional[str],
    search: Optional[str],
    include_deployments: bool,
    owner_scope: Optional[str],
    owner_id: Optional[str],
    # local-only params that are ignored in the enterprise path
    collection: Optional[str],
    tools: Optional[str],
    has_unlinked: Optional[bool],
    import_id: Optional[str],
    check_drift: bool,
    project_path: Optional[str],
) -> ArtifactListResponse:
    """Enterprise handler for list_artifacts.

    Uses IArtifactRepository.list() / .search() / .count() — no filesystem
    access and no artifact_mgr / collection_mgr usage.

    Args:
        artifact_repo: Repository implementation (enterprise backend).
        settings: API settings.
        auth_context: Caller auth context for tenant scoping.
        limit: Page size.
        offset: Zero-based record offset derived from cursor decoding.
        artifact_type: Optional comma-separated type filter.
        tags: Optional comma-separated tag filter.
        search: Optional search string (delegated to repo.search()).
        include_deployments: Not yet supported on enterprise path; ignored.
        owner_scope: Passed directly as a repo filter.
        owner_id: Passed directly as a repo filter.
        collection: Local-only; logged as debug and ignored.
        tools: Local-only; logged as debug and ignored.
        has_unlinked: Local-only; logged as debug and ignored.
        import_id: Local-only; logged as debug and ignored.
        check_drift: Local-only; logged as debug and ignored.
        project_path: Local-only; logged as debug and ignored.

    Returns:
        ArtifactListResponse with enterprise-sourced data.
    """
    # Warn callers that local-only params are silently dropped.
    if collection:
        logger.debug(
            "enterprise list_artifacts: 'collection' filter is local-only — ignored"
        )
    if tools:
        logger.debug(
            "enterprise list_artifacts: 'tools' filter is local-only — ignored"
        )
    if has_unlinked is not None:
        logger.debug(
            "enterprise list_artifacts: 'has_unlinked' filter is local-only — ignored"
        )
    if import_id:
        logger.debug(
            "enterprise list_artifacts: 'import_id' filter is local-only — ignored"
        )
    if check_drift:
        logger.debug("enterprise list_artifacts: 'check_drift' is local-only — ignored")
    if include_deployments:
        logger.debug(
            "enterprise list_artifacts: 'include_deployments' is not yet supported "
            "on the enterprise path — ignored"
        )

    # Build filter dict.
    filters: dict = {}
    if artifact_type:
        # Support comma-separated type values.
        raw_types = [t.strip() for t in artifact_type.split(",") if t.strip()]
        parsed_types = []
        for raw in raw_types:
            try:
                parsed_types.append(ArtifactType(raw).value)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid artifact type: {raw}",
                )
        filters["artifact_type"] = (
            parsed_types if len(parsed_types) > 1 else parsed_types[0]
        )
    if tags:
        filters["tags"] = [t.strip() for t in tags.split(",") if t.strip()]
    if owner_scope and owner_scope != "all":
        filters["owner_scope"] = owner_scope
    if owner_id:
        filters["owner_id"] = owner_id

    # Fetch page.
    if search:
        dtos: list[ArtifactDTO] = artifact_repo.search(
            search, filters=filters or None, auth_context=auth_context
        )
        total = len(dtos)
        # search() returns ranked results; apply offset/limit in Python.
        page_dtos = dtos[offset : offset + limit]
    else:
        dtos = artifact_repo.list(
            filters=filters or None,
            offset=offset,
            limit=limit,
            auth_context=auth_context,
        )
        total = artifact_repo.count(filters=filters or None, auth_context=auth_context)
        page_dtos = dtos

    items: list[ArtifactResponse] = [_dto_to_response(dto) for dto in page_dtos]

    # Build pagination info.
    has_next = (offset + limit) < total
    has_previous = offset > 0

    start_cursor = encode_cursor(page_dtos[0].id) if page_dtos else None
    end_cursor = encode_cursor(page_dtos[-1].id) if page_dtos else None

    page_info = PageInfo(
        has_next_page=has_next,
        has_previous_page=has_previous,
        start_cursor=start_cursor,
        end_cursor=end_cursor,
        total_count=total,
    )

    return ArtifactListResponse(items=items, page_info=page_info)


# ---------------------------------------------------------------------------
# list_artifacts endpoint
# ---------------------------------------------------------------------------


@router.get(
    "",
    response_model=ArtifactListResponse,
    summary="List all artifacts",
    description="Retrieve a paginated list of artifacts across all collections",
    responses={
        200: {"description": "Successfully retrieved artifacts"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def list_artifacts(
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    collection_repo: CollectionRepoDep,
    coll_artifact_repo: DbCollectionArtifactRepoDep,
    marketplace_catalog_repo: MarketplaceCatalogRepoDep,
    db_session: DbSessionDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    sync_mgr: SyncManagerOptDep = None,
    limit: int = Query(
        default=20,
        ge=1,
        le=500,
        description="Number of items per page (max 500)",
    ),
    after: Optional[str] = Query(
        default=None,
        description="Cursor for pagination (next page)",
    ),
    artifact_type: Optional[str] = Query(
        default=None,
        description="Filter by artifact type (skill, command, agent). Supports comma-separated values (e.g., skill,command,agent).",
    ),
    collection: Optional[str] = Query(
        default=None,
        description="Filter by collection name",
    ),
    tags: Optional[str] = Query(
        default=None,
        description="Filter by tags (comma-separated)",
    ),
    tools: Optional[str] = Query(
        default=None,
        description="Filter by tools (comma-separated). Returns artifacts that use any of the specified tools.",
    ),
    check_drift: bool = Query(
        default=False,
        description="Check for local modifications and drift status (may impact performance)",
    ),
    project_path: Optional[str] = Query(
        default=None,
        description="Project path for drift detection (required if check_drift=true)",
    ),
    has_unlinked: Optional[bool] = Query(
        default=None,
        description="Filter for artifacts with unlinked references (true) or without (false)",
    ),
    import_id: Optional[str] = Query(
        default=None,
        description="Filter by marketplace import batch ID",
    ),
    search: Optional[str] = Query(
        default=None,
        description="Search artifacts by name or description (case-insensitive substring match)",
    ),
    include_deployments: bool = Query(
        default=False,
        description="Include deployment statistics for each artifact (may impact performance)",
    ),
    owner_scope: Optional[str] = Query(
        default=None,
        description="Filter by owner scope: user|team|enterprise|all",
    ),
    owner_id: Optional[str] = Query(
        default=None,
        description="Filter by specific owner ID",
    ),
) -> ArtifactListResponse:
    """List all artifacts with filters and pagination.

    Args:
        settings: API settings (controls edition-based branching).
        artifact_repo: Repository DI for enterprise path.
        collection_repo: Collection repository DI.
        coll_artifact_repo: Collection–artifact join repository DI.
        marketplace_catalog_repo: Marketplace catalog repository DI.
        db_session: Database session.
        token: Authentication token.
        auth_context: Resolved auth context.
        artifact_mgr: Artifact manager (local path only; None in enterprise).
        collection_mgr: Collection manager (local path only; None in enterprise).
        sync_mgr: Sync manager (local path only; None in enterprise).
        limit: Number of items per page.
        after: Cursor for next page.
        artifact_type: Optional type filter (comma-separated for multiple types).
        collection: Optional collection filter (local only).
        tags: Optional tag filter (comma-separated).
        tools: Optional tools filter (comma-separated; local only).
        check_drift: Whether to check for drift and local modifications (local only).
        project_path: Project path for drift detection (local only).
        has_unlinked: Filter for artifacts with/without unlinked references (local only).
        import_id: Filter by marketplace import batch ID (local only).
        search: Optional search string (case-insensitive match on name/description).
        include_deployments: Whether to include deployment statistics for each artifact.
        owner_scope: Optional ownership tier filter (user|team|enterprise|all).
        owner_id: Optional owner ID filter.

    Returns:
        Paginated list of artifacts.

    Raises:
        HTTPException: On error.
    """
    # ── Enterprise path ──────────────────────────────────────────────────────
    if settings.edition == "enterprise":
        # Decode cursor to offset for the enterprise repo.
        offset = 0
        if after:
            # For the enterprise path cursor contains a stringified offset integer.
            try:
                cursor_value = decode_cursor(after)
                offset = int(cursor_value)
            except (ValueError, Exception):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid cursor",
                )

        return await _list_artifacts_enterprise(
            artifact_repo=artifact_repo,
            settings=settings,
            auth_context=auth_context,
            limit=limit,
            offset=offset,
            artifact_type=artifact_type,
            tags=tags,
            search=search,
            include_deployments=include_deployments,
            owner_scope=owner_scope,
            owner_id=owner_id,
            collection=collection,
            tools=tools,
            has_unlinked=has_unlinked,
            import_id=import_id,
            check_drift=check_drift,
            project_path=project_path,
        )

    # ── Local path — delegates to _legacy.py ─────────────────────────────────
    assert artifact_mgr is not None, "artifact_mgr required in local edition"
    assert collection_mgr is not None, "collection_mgr required in local edition"
    from . import _legacy as _leg

    return await _leg.list_artifacts(
        artifact_mgr=artifact_mgr,
        artifact_repo=artifact_repo,
        collection_mgr=collection_mgr,
        collection_repo=collection_repo,
        coll_artifact_repo=coll_artifact_repo,
        marketplace_catalog_repo=marketplace_catalog_repo,
        db_session=db_session,
        sync_mgr=sync_mgr,
        token=token,
        auth_context=auth_context,
        limit=limit,
        after=after,
        artifact_type=artifact_type,
        collection=collection,
        tags=tags,
        tools=tools,
        check_drift=check_drift,
        project_path=project_path,
        has_unlinked=has_unlinked,
        import_id=import_id,
        search=search,
        include_deployments=include_deployments,
        owner_scope=owner_scope,
        owner_id=owner_id,
    )


# ---------------------------------------------------------------------------
# Enterprise get handler
# ---------------------------------------------------------------------------


async def _get_artifact_enterprise(
    artifact_id: str,
    artifact_repo: ArtifactRepoDep,
    include_deployments: bool,
    db_session,
    deployment_repo: DeploymentRepoDep = None,
) -> ArtifactResponse:
    """Enterprise handler for get_artifact.

    Uses IArtifactRepository.get() — no filesystem access and no artifact_mgr
    or collection_mgr usage.

    Args:
        artifact_id: Artifact identifier in 'type:name' format or UUID string.
        artifact_repo: Repository implementation (enterprise backend).
        include_deployments: Whether to include deployment statistics.
        db_session: Database session (unused; kept for signature compatibility).
        deployment_repo: Deployment repository for deployment stats.

    Returns:
        ArtifactResponse for the requested artifact.

    Raises:
        HTTPException: 400 on invalid artifact_id format, 404 if not found.
    """
    if _is_uuid(artifact_id):
        # Enterprise mode: frontend passes the UUID from the listing response.
        # Route directly through get_by_uuid so no type:name parsing is needed.
        dto = artifact_repo.get_by_uuid(artifact_id)
    else:
        try:
            art_type_str, art_name = parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )
        composite_id = f"{art_type_str}:{art_name}"
        dto = artifact_repo.get(composite_id)
    if dto is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Artifact '{artifact_id}' not found",
        )

    response = _dto_to_response(dto)

    if include_deployments and deployment_repo is not None:
        try:
            from datetime import datetime, timezone

            artifact_identifier: "uuid.UUID | str"
            if dto.uuid:
                try:
                    artifact_identifier = uuid.UUID(dto.uuid)
                except (ValueError, TypeError):
                    logger.debug(
                        "crud: falling back to composite dto.id,"
                        " dto.uuid=%r is not a valid UUID",
                        dto.uuid,
                    )
                    artifact_identifier = dto.id
            else:
                artifact_identifier = dto.id
            deployments = deployment_repo.get_by_artifact(artifact_identifier)
            if deployments:
                modified_count = sum(
                    1 for d in deployments if d.local_modifications is True
                )
                response.deployment_stats = DeploymentStatistics(
                    total_deployments=len(deployments),
                    modified_deployments=modified_count,
                    projects=[
                        ProjectDeploymentInfo(
                            project_name=d.project_name or "Unknown",
                            project_path=d.project_path or "",
                            is_modified=d.local_modifications or False,
                            deployed_at=(
                                d.deployed_at
                                if d.deployed_at
                                else datetime.now(timezone.utc).isoformat()
                            ),
                        )
                        for d in deployments
                    ],
                )
        except Exception as e:
            logger.warning(
                f"Failed to build deployment statistics for {artifact_id}: {e}"
            )

    return response


# ---------------------------------------------------------------------------
# get_artifact endpoint
# ---------------------------------------------------------------------------


@router.get(
    "/{artifact_id}",
    response_model=ArtifactResponse,
    summary="Get artifact details",
    description="Retrieve detailed information about a specific artifact",
    responses={
        200: {"description": "Successfully retrieved artifact"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_artifact(
    artifact_id: str,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    collection_repo: CollectionRepoDep,
    db_session: DbSessionDep,
    deployment_repo: DeploymentRepoDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
    include_deployments: bool = Query(
        default=False,
        description="Include deployment statistics across all projects",
    ),
) -> ArtifactResponse:
    """Get details for a specific artifact.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        settings: API settings (controls edition-based branching).
        artifact_repo: Repository DI for enterprise path.
        collection_repo: Collection repository DI.
        db_session: Database session dependency.
        token: Authentication token.
        auth_context: Resolved auth context.
        artifact_mgr: Artifact manager (local path only; None in enterprise).
        collection_mgr: Collection manager (local path only; None in enterprise).
        collection: Optional collection filter (local only).
        include_deployments: Whether to include deployment statistics.

    Returns:
        Artifact details with optional deployment statistics and collections.

    Raises:
        HTTPException: If artifact not found or on error.

    Example:
        GET /api/v1/artifacts/skill:pdf-processor?include_deployments=true
    """
    # ── Enterprise path ──────────────────────────────────────────────────────
    if settings.edition == "enterprise":
        return await _get_artifact_enterprise(
            artifact_id=artifact_id,
            artifact_repo=artifact_repo,
            include_deployments=include_deployments,
            db_session=db_session,
            deployment_repo=deployment_repo,
        )

    # ── Local path — delegates to _legacy.py ─────────────────────────────────
    assert artifact_mgr is not None, "artifact_mgr required in local edition"
    assert collection_mgr is not None, "collection_mgr required in local edition"
    from . import _legacy as _leg

    return await _leg.get_artifact(
        artifact_id=artifact_id,
        artifact_mgr=artifact_mgr,
        artifact_repo=artifact_repo,
        collection_mgr=collection_mgr,
        collection_repo=collection_repo,
        db_session=db_session,
        token=token,
        auth_context=auth_context,
        collection=collection,
        include_deployments=include_deployments,
    )


# ---------------------------------------------------------------------------
# Enterprise create handler
# ---------------------------------------------------------------------------


def _refresh_cache_safe_local(
    artifact_mgr,
    artifact_id: str,
    collection_name: str,
) -> None:
    """Refresh DB cache after create, swallowing errors to avoid failing the create.

    Mirrors ``_refresh_cache_safe`` in ``_legacy.py``.
    """
    try:
        db_session = get_session()
        try:
            refresh_single_artifact_cache(
                db_session,
                artifact_mgr,
                artifact_id,
                collection_name,
            )
        finally:
            db_session.close()
    except Exception as cache_err:
        logger.warning(f"Cache refresh failed for {artifact_id}: {cache_err}")


async def _create_artifact_enterprise(
    request: ArtifactCreateRequest,
    artifact_repo: ArtifactRepoDep,
    auth_context: AuthContext,
) -> ArtifactCreateResponse:
    """Enterprise handler for create_artifact.

    Builds an ArtifactDTO from the request, delegates to
    ``IArtifactRepository.create()``, and returns a 201 response.  No
    filesystem access; ``artifact_mgr`` and ``collection_mgr`` are never used.

    Args:
        request: Validated create request from the caller.
        artifact_repo: Repository implementation (enterprise backend).
        auth_context: Caller auth context for tenant scoping.

    Returns:
        ArtifactCreateResponse with the persisted artifact details.

    Raises:
        HTTPException: 400 on invalid artifact type, 500 on unexpected error.
    """
    # Validate artifact type first so the error surface matches the local path.
    try:
        artifact_type_obj = ArtifactType(request.artifact_type)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid artifact type: {request.artifact_type}. "
            f"Must be one of: {', '.join([t.value for t in ArtifactType])}",
        )

    artifact_type_value = artifact_type_obj.value
    artifact_name = request.name or request.source.rstrip("/").split("/")[-1]

    dto = ArtifactDTO(
        id=f"{artifact_type_value}:{artifact_name}",
        name=artifact_name,
        artifact_type=artifact_type_value,
        source=request.source,
        description=request.description,
        tags=list(request.tags) if request.tags else [],
    )

    try:
        created_dto = artifact_repo.create(dto, auth_context=auth_context)
    except Exception as e:
        logger.error(f"Enterprise create_artifact failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create artifact: {str(e)}",
        )

    artifact_id = created_dto.id
    collection_name = request.collection or "default"

    logger.info(
        f"Enterprise: successfully created artifact {artifact_id} "
        f"in collection '{collection_name}'"
    )

    return ArtifactCreateResponse(
        success=True,
        artifact_id=artifact_id,
        artifact_name=created_dto.name,
        artifact_type=created_dto.artifact_type,
        collection=collection_name,
        source=request.source,
        source_type=request.source_type.value,
        path=created_dto.content_path,
        message=f"Artifact '{created_dto.name}' created successfully from "
        f"{request.source_type.value} source",
    )


# ---------------------------------------------------------------------------
# create_artifact endpoint
# ---------------------------------------------------------------------------


@router.post(
    "",
    response_model=ArtifactCreateResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create new artifact",
    description="Create a new artifact from GitHub URL or local path",
    responses={
        201: {"description": "Artifact created successfully"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Source not found"},
        409: {"model": ErrorResponse, "description": "Artifact already exists"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def create_artifact(
    request: ArtifactCreateRequest,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    collection_repo: CollectionRepoDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
) -> ArtifactCreateResponse:
    """Create a new artifact from GitHub or local source.

    This endpoint allows you to add artifacts to your collection from:
    - GitHub repositories (supports specs like username/repo/path@version)
    - Local filesystem paths

    Args:
        request: Artifact creation request with source and metadata
        settings: API settings (controls edition-based branching).
        artifact_repo: Repository DI for enterprise path.
        collection_repo: Collection repository DI.
        token: Authentication token.
        auth_context: Resolved auth context.
        artifact_mgr: Artifact manager (local path only; None in enterprise).
        collection_mgr: Collection manager (local path only; None in enterprise).

    Returns:
        ArtifactCreateResponse with created artifact details

    Raises:
        HTTPException: If validation fails, source not found, or artifact exists

    Examples:
        GitHub source:
        ```json
        {
            "source_type": "github",
            "source": "anthropics/skills/canvas-design",
            "artifact_type": "skill",
            "name": "canvas",
            "tags": ["design", "ui"]
        }
        ```

        Local source:
        ```json
        {
            "source_type": "local",
            "source": "/path/to/my-skill",
            "artifact_type": "skill"
        }
        ```
    """
    # ── Enterprise path ──────────────────────────────────────────────────────
    if settings.edition == "enterprise":
        return await _create_artifact_enterprise(
            request=request,
            artifact_repo=artifact_repo,
            auth_context=auth_context,
        )

    # ── Local path — delegates to _legacy.py ─────────────────────────────────
    assert artifact_mgr is not None, "artifact_mgr required in local edition"
    assert collection_mgr is not None, "collection_mgr required in local edition"
    from . import _legacy as _leg

    return await _leg.create_artifact(
        request=request,
        artifact_mgr=artifact_mgr,
        collection_mgr=collection_mgr,
        collection_repo=collection_repo,
        token=token,
        auth_context=auth_context,
    )


# ---------------------------------------------------------------------------
# Enterprise update handler
# ---------------------------------------------------------------------------


async def _update_artifact_enterprise(
    artifact_id: str,
    update_request: ArtifactUpdateRequest,
    artifact_repo: ArtifactRepoDep,
    auth_context: AuthContext,
) -> ArtifactResponse:
    """Enterprise handler for update_artifact.

    Applies a partial update to an existing artifact using
    ``IArtifactRepository.update()``.  Never accesses ``artifact_mgr`` or
    ``collection_mgr``.

    Args:
        artifact_id: Artifact primary key in ``"type:name"`` format.
        update_request: Fields to update (all optional / None means skip).
        artifact_repo: Repository implementation (enterprise backend).
        auth_context: Caller auth context for tenant scoping.

    Returns:
        Updated ArtifactResponse.

    Raises:
        HTTPException 400: If artifact_id cannot be parsed.
        HTTPException 404: If no artifact with that id exists.
        HTTPException 500: On unexpected repository errors.
    """
    art_type_str, art_name = parse_artifact_id(artifact_id)
    composite_id = f"{art_type_str}:{art_name}"

    # Build partial-update dict — only include fields explicitly set.
    updates: dict = {}
    if update_request.tags is not None:
        updates["tags"] = update_request.tags
    if update_request.owner_type is not None:
        updates["owner_type"] = update_request.owner_type
    if update_request.visibility is not None:
        updates["visibility"] = update_request.visibility
    if update_request.enforce_override is not None:
        updates["enforce_override"] = update_request.enforce_override
    if update_request.metadata is not None:
        meta = update_request.metadata
        if meta.title is not None:
            updates["title"] = meta.title
        if meta.description is not None:
            updates["description"] = meta.description
        if meta.author is not None:
            updates["author"] = meta.author
        if meta.license is not None:
            updates["license"] = meta.license
        if meta.tags is not None:
            updates["tags"] = meta.tags
    # aliases not yet supported — log and skip (mirrors legacy behaviour)
    if update_request.aliases is not None:
        logger.warning(
            f"Enterprise update_artifact: aliases update requested for {artifact_id} "
            "but aliases are not yet implemented — ignored"
        )

    try:
        updated_dto = artifact_repo.update(
            composite_id,
            updates,
            auth_context=auth_context,
        )
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Artifact '{artifact_id}' not found",
        )

    return _dto_to_response(updated_dto)


# ---------------------------------------------------------------------------
# Enterprise update_artifact_parameters handler
# ---------------------------------------------------------------------------


async def _update_artifact_parameters_enterprise(
    artifact_id: str,
    request: ParameterUpdateRequest,
    artifact_repo: ArtifactRepoDep,
    auth_context: AuthContext,
) -> ParameterUpdateResponse:
    """Enterprise handler for update_artifact_parameters.

    Applies parameter-level changes (source, version, scope, tags, aliases) to
    an existing artifact via ``IArtifactRepository.update()``.  Never accesses
    ``artifact_mgr`` or ``collection_mgr``.

    Args:
        artifact_id: Artifact primary key in ``"type:name"`` format.
        request: Parameter update request.
        artifact_repo: Repository implementation (enterprise backend).
        auth_context: Caller auth context for tenant scoping.

    Returns:
        ParameterUpdateResponse listing updated fields.

    Raises:
        HTTPException 400: If artifact_id or source format is invalid.
        HTTPException 404: If no artifact with that id exists.
        HTTPException 422: If source format fails validation.
        HTTPException 500: On unexpected repository errors.
    """
    art_type_str, art_name = parse_artifact_id(artifact_id)
    composite_id = f"{art_type_str}:{art_name}"

    params = request.parameters
    updates: dict = {}
    updated_fields: list[str] = []

    if params.source is not None and params.source.strip():
        # Validate GitHub source format before persisting.
        try:
            from skillmeat.core.github_metadata import GitHubMetadataExtractor

            extractor = GitHubMetadataExtractor(cache=None)
            extractor.parse_github_url(params.source)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Invalid GitHub source format: {str(exc)}",
            )
        updates["upstream"] = params.source
        updated_fields.append("source")

    if params.version is not None and params.version.strip():
        version = params.version.strip()
        if not version.startswith("@"):
            if version != "latest":
                version = f"@{version}"
        else:
            version = version[1:]
        updates["version_spec"] = version
        updated_fields.append("version")

    if params.scope is not None:
        # Scope changes are not yet fully implemented (file moves not performed).
        logger.warning(
            f"Enterprise update_artifact_parameters: scope update requested for "
            f"{artifact_id} to '{params.scope}' — tracked but file moves not performed"
        )
        updated_fields.append("scope")

    if params.tags is not None:
        normalized_tags: list[str] = []
        seen: set[str] = set()
        for tag in params.tags:
            if not isinstance(tag, str):
                continue
            cleaned = tag.strip()
            if not cleaned:
                continue
            key = cleaned.lower()
            if key in seen:
                continue
            seen.add(key)
            normalized_tags.append(cleaned)
        updates["tags"] = normalized_tags
        updated_fields.append("tags")

    if params.aliases is not None:
        updates["aliases"] = params.aliases
        updated_fields.append("aliases")

    if not updates and not updated_fields:
        return ParameterUpdateResponse(
            success=True,
            artifact_id=artifact_id,
            updated_fields=[],
            message="No parameters were updated",
        )

    try:
        artifact_repo.update(
            composite_id,
            updates,
            auth_context=auth_context,
        )
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Artifact '{artifact_id}' not found",
        )

    message = f"Updated {len(updated_fields)} field(s): {', '.join(updated_fields)}"
    return ParameterUpdateResponse(
        success=True,
        artifact_id=artifact_id,
        updated_fields=updated_fields,
        message=message,
    )


# ---------------------------------------------------------------------------
# update_artifact endpoint
# ---------------------------------------------------------------------------


@router.put(
    "/{artifact_id}",
    response_model=ArtifactResponse,
    summary="Update artifact",
    description="Update artifact metadata, tags, and aliases",
    responses={
        200: {"description": "Successfully updated artifact"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def update_artifact(
    artifact_id: str,
    update_request: ArtifactUpdateRequest,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    collection_repo: CollectionRepoDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
) -> ArtifactResponse:
    """Update an artifact's metadata, tags, and aliases.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        update_request: Update request containing new values
        settings: API settings (controls edition-based branching).
        artifact_repo: Repository DI for enterprise path.
        collection_repo: Collection repository DI.
        token: Authentication token
        auth_context: Resolved auth context.
        artifact_mgr: Artifact manager (local path only; None in enterprise).
        collection_mgr: Collection manager (local path only; None in enterprise).
        collection: Optional collection filter

    Returns:
        Updated artifact details

    Raises:
        HTTPException: If artifact not found or on error
    """
    # ── Enterprise path ──────────────────────────────────────────────────────
    if settings.edition == "enterprise":
        return await _update_artifact_enterprise(
            artifact_id=artifact_id,
            update_request=update_request,
            artifact_repo=artifact_repo,
            auth_context=auth_context,
        )

    # ── Local path — delegates to _legacy.py ─────────────────────────────────
    assert artifact_mgr is not None, "artifact_mgr required in local edition"
    assert collection_mgr is not None, "collection_mgr required in local edition"
    from . import _legacy as _leg

    return await _leg.update_artifact(
        artifact_id=artifact_id,
        update_request=update_request,
        artifact_mgr=artifact_mgr,
        collection_mgr=collection_mgr,
        collection_repo=collection_repo,
        token=token,
        auth_context=auth_context,
        collection=collection,
    )


# ---------------------------------------------------------------------------
# update_artifact_parameters endpoint
# ---------------------------------------------------------------------------


@router.put(
    "/{artifact_id}/parameters",
    response_model=ParameterUpdateResponse,
    summary="Update artifact parameters",
    description="Update artifact parameters (source, version, scope, tags, aliases) after import",
    responses={
        200: {"description": "Successfully updated parameters"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        422: {"model": ErrorResponse, "description": "Validation error"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def update_artifact_parameters(
    artifact_id: str,
    request: ParameterUpdateRequest,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    collection_repo: CollectionRepoDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
) -> ParameterUpdateResponse:
    """Update artifact parameters after import.

    Updates the source, version, scope, tags, or aliases of an existing artifact.
    Changes are persisted to the manifest and lock file atomically.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        request: Parameter update request
        settings: API settings (controls edition-based branching).
        artifact_repo: Repository DI for enterprise path.
        collection_repo: Collection repository DI.
        token: Authentication token
        auth_context: Resolved auth context.
        artifact_mgr: Artifact manager (local path only; None in enterprise).
        collection_mgr: Collection manager (local path only; None in enterprise).
        collection: Optional collection filter

    Returns:
        Parameter update response with list of updated fields

    Raises:
        HTTPException: If artifact not found or validation fails
    """
    # ── Enterprise path ──────────────────────────────────────────────────────
    if settings.edition == "enterprise":
        return await _update_artifact_parameters_enterprise(
            artifact_id=artifact_id,
            request=request,
            artifact_repo=artifact_repo,
            auth_context=auth_context,
        )

    # ── Local path — delegates to _legacy.py ─────────────────────────────────
    assert artifact_mgr is not None, "artifact_mgr required in local edition"
    assert collection_mgr is not None, "collection_mgr required in local edition"
    from . import _legacy as _leg

    return await _leg.update_artifact_parameters(
        artifact_id=artifact_id,
        request=request,
        artifact_mgr=artifact_mgr,
        artifact_repo=artifact_repo,
        collection_mgr=collection_mgr,
        collection_repo=collection_repo,
        token=token,
        auth_context=auth_context,
        collection=collection,
    )


# ---------------------------------------------------------------------------
# delete_artifact — DELETE /{artifact_id}
# ---------------------------------------------------------------------------


async def _delete_artifact_enterprise(
    artifact_id: str,
    artifact_repo: ArtifactRepoDep,
    auth_context,
) -> Response:
    """Enterprise handler for delete_artifact.

    Uses IArtifactRepository.delete() — no filesystem access, no artifact_mgr
    or collection_mgr usage.

    Args:
        artifact_id: Artifact identifier in 'type:name' format.
        artifact_repo: Repository implementation (enterprise backend).
        auth_context: Auth context for auditing.

    Returns:
        HTTP 204 No Content on success.

    Raises:
        HTTPException: 400 on invalid format, 404 if not found.
    """
    try:
        art_type_str, art_name = parse_artifact_id(artifact_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid artifact ID format. Expected 'type:name'",
        )

    composite_id = f"{art_type_str}:{art_name}"
    deleted = artifact_repo.delete(composite_id, auth_context=auth_context)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Artifact '{artifact_id}' not found",
        )
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.delete(
    "/{artifact_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete artifact",
    description="Remove an artifact from the collection",
    responses={
        204: {"description": "Successfully deleted artifact"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def delete_artifact(
    artifact_id: str,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    collection_repo: CollectionRepoDep,
    db_session: DbSessionDep,
    catalog_repo: MarketplaceCatalogRepoDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
) -> None:
    """Delete an artifact from the collection."""
    if settings.edition == "enterprise":
        return await _delete_artifact_enterprise(
            artifact_id, artifact_repo, auth_context
        )

    # ── Local path — delegates to _legacy.py ─────────────────────────────────
    assert artifact_mgr is not None, "artifact_mgr required in local edition"
    assert collection_mgr is not None, "collection_mgr required in local edition"
    from . import _legacy as _leg

    return await _leg.delete_artifact(
        artifact_id=artifact_id,
        artifact_mgr=artifact_mgr,
        collection_mgr=collection_mgr,
        collection_repo=collection_repo,
        db_session=db_session,
        catalog_repo=catalog_repo,
        token=token,
        auth_context=auth_context,
        collection=collection,
    )


# ---------------------------------------------------------------------------
# check_artifact_upstream — GET /{artifact_id}/upstream
# ---------------------------------------------------------------------------


async def _check_upstream_enterprise(
    artifact_id: str,
    artifact_repo: ArtifactRepoDep,
) -> ArtifactUpstreamResponse:
    """Enterprise handler for check_artifact_upstream.

    Enterprise artifacts do not currently support upstream tracking via
    artifact_mgr.  Returns a response indicating tracking is not configured.

    Args:
        artifact_id: Artifact identifier in 'type:name' format.
        artifact_repo: Repository implementation (enterprise backend).

    Returns:
        ArtifactUpstreamResponse with tracking_enabled=False.

    Raises:
        HTTPException: 400 on invalid format, 404 if not found.
    """
    try:
        art_type_str, art_name = parse_artifact_id(artifact_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid artifact ID format. Expected 'type:name'",
        )

    composite_id = f"{art_type_str}:{art_name}"
    dto = artifact_repo.get(composite_id)
    if dto is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Artifact '{artifact_id}' not found",
        )

    from datetime import datetime, timezone

    return ArtifactUpstreamResponse(
        artifact_id=artifact_id,
        tracking_enabled=False,
        current_version=dto.version_spec or "unknown",
        current_sha=dto.resolved_sha or "unknown",
        upstream_version=None,
        upstream_sha=None,
        update_available=False,
        has_local_modifications=False,
        last_checked=datetime.now(timezone.utc),
    )


@router.get(
    "/{artifact_id}/upstream",
    response_model=ArtifactUpstreamResponse,
    summary="Check upstream status",
    description="Check for updates and upstream status for an artifact",
    responses={
        200: {"description": "Successfully checked upstream status"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def check_artifact_upstream(
    artifact_id: str,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    collection_repo: CollectionRepoDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
) -> ArtifactUpstreamResponse:
    """Check upstream status and available updates for an artifact."""
    if settings.edition == "enterprise":
        return await _check_upstream_enterprise(artifact_id, artifact_repo)

    # ── Local path — delegates to _legacy.py ─────────────────────────────────
    assert artifact_mgr is not None, "artifact_mgr required in local edition"
    assert collection_mgr is not None, "collection_mgr required in local edition"
    from . import _legacy as _leg

    return await _leg.check_artifact_upstream(
        artifact_id=artifact_id,
        artifact_mgr=artifact_mgr,
        collection_mgr=collection_mgr,
        collection_repo=collection_repo,
        token=token,
        auth_context=auth_context,
        collection=collection,
    )
