"""GitHub metadata fetch endpoint for the artifacts router — no edition branching.

Contains:
  - fetch_github_metadata    GET    /artifacts/metadata/github

This endpoint performs a remote GitHub API call to fetch artifact metadata.
It does not use ArtifactManagerDep or any filesystem-bound dependency, so it
behaves identically in both local and enterprise editions.  No edition
branching is needed.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status

from skillmeat.api.dependencies import (
    ConfigManagerDep,
    get_app_state,
    get_auth_context,
    require_auth,
    verify_api_key,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.discovery import (
    GitHubMetadata,
    MetadataFetchResponse,
)
from skillmeat.api.utils.error_handlers import create_internal_error
from skillmeat.core.cache import MetadataCache
from skillmeat.core.github_metadata import GitHubMetadataExtractor

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/artifacts",
    tags=["artifacts"],
    dependencies=[Depends(verify_api_key)],
)


# ---------------------------------------------------------------------------
# GET /metadata/github  — fetch GitHub metadata for a source
# ---------------------------------------------------------------------------


@router.get(
    "/metadata/github",
    response_model=MetadataFetchResponse,
    summary="Fetch GitHub metadata",
    description=(
        "Fetch metadata from GitHub for a given source. "
        "Parses the source URL, fetches repository metadata and "
        "frontmatter from the artifact's markdown file. Results "
        "are cached to reduce GitHub API calls (configurable TTL)."
    ),
)
async def fetch_github_metadata(
    source: str = Query(..., description="GitHub source: user/repo/path[@version]"),
    request: Request = None,
    config_mgr: ConfigManagerDep = None,
    auth_context: AuthContext = Depends(get_auth_context),
) -> MetadataFetchResponse:
    """Fetch metadata from GitHub for a given source.

    Parses the source URL, fetches repository metadata and
    frontmatter from the artifact's markdown file. Results
    are cached to reduce GitHub API calls (configurable TTL).

    Args:
        source: GitHub source in format user/repo/path[@version]
        request: FastAPI request object for accessing app state
        config_mgr: Config manager dependency for GitHub token
        auth_context: Caller auth context

    Returns:
        MetadataFetchResponse with metadata or error details

    Raises:
        HTTPException: On internal errors or if feature is disabled
    """
    from skillmeat.api.config import get_settings

    settings = get_settings()
    if not settings.enable_auto_population:
        logger.warning("Auto-population feature is disabled")
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="GitHub metadata auto-population feature is currently disabled. Enable with SKILLMEAT_ENABLE_AUTO_POPULATION=true",
        )

    try:
        from skillmeat.core.validation import validate_github_source

        is_valid, error_msg = validate_github_source(source)
        if not is_valid:
            logger.warning(f"Invalid source format '{source}': {error_msg}")
            return MetadataFetchResponse(success=False, error=error_msg)

        logger.info(f"Fetching GitHub metadata for source: {source}")

        # Get or create metadata cache from app state
        app_state = get_app_state()
        if not hasattr(app_state, "metadata_cache") or app_state.metadata_cache is None:
            ttl_seconds = settings.discovery_cache_ttl
            app_state.metadata_cache = MetadataCache(ttl_seconds=ttl_seconds)
            logger.debug(f"Initialized metadata cache with TTL={ttl_seconds}s")

        # Get GitHub token from settings first, then fallback to config manager
        github_token = settings.github_token
        if not github_token and config_mgr:
            github_token = config_mgr.get("github-token")

        if github_token:
            logger.debug("Using configured GitHub token for API requests")
        else:
            logger.debug(
                "No GitHub token configured, using unauthenticated requests (60 req/hr limit)"
            )

        # Resolve via the package namespace so test mocks applied to
        # ``skillmeat.api.routers.artifacts.GitHubMetadataExtractor`` intercept
        # this call — matching the original artifacts.py behaviour.
        import sys as _sys

        _arts_pkg = _sys.modules.get("skillmeat.api.routers.artifacts")
        _extractor_cls = (
            _arts_pkg.GitHubMetadataExtractor  # type: ignore[attr-defined]
            if _arts_pkg is not None
            else GitHubMetadataExtractor
        )
        extractor = _extractor_cls(cache=app_state.metadata_cache, token=github_token)

        try:
            metadata = extractor.fetch_metadata(source)
            logger.info(f"Successfully fetched metadata for {source}")

            return MetadataFetchResponse(
                success=True,
                metadata=GitHubMetadata(
                    title=metadata.title,
                    description=metadata.description,
                    author=metadata.author,
                    license=metadata.license,
                    topics=metadata.topics,
                    url=metadata.url,
                    fetched_at=metadata.fetched_at,
                ),
            )

        except ValueError as e:
            logger.warning(f"Invalid source format '{source}': {e}")
            return MetadataFetchResponse(success=False, error=str(e))

        except RuntimeError as e:
            error_msg = str(e)
            logger.error(f"GitHub API error for '{source}': {error_msg}")

            if "404" in error_msg or "not found" in error_msg.lower():
                return MetadataFetchResponse(
                    success=False, error="Repository or artifact not found"
                )
            elif "429" in error_msg or "rate limit" in error_msg.lower():
                return MetadataFetchResponse(
                    success=False,
                    error="GitHub rate limit exceeded. Please configure a GitHub token for higher limits.",
                )
            else:
                return MetadataFetchResponse(success=False, error=error_msg)

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Unexpected error fetching metadata for '{source}': {e}")
        raise create_internal_error("Failed to fetch metadata", e)
