"""Import/export endpoints for the artifacts router — dual-mode (local + enterprise).

Contains:
  - bulk_import_artifacts  POST  /artifacts/discover/import
  - confirm_duplicates     POST  /artifacts/confirm-duplicates

Each endpoint branches on ``settings.edition == "enterprise"`` and delegates
to the appropriate handler.  The local handler is copied verbatim from
``_legacy.py`` so behaviour is identical.  The enterprise handler uses
``ArtifactRepoDep`` with ``artifact_repo.create()`` per artifact, returning a
summary that matches the local response schema exactly.

Enterprise semantics (bulk_import_artifacts):
  - Each artifact in the request is validated (same ``validate_artifact_request``
    helper as the local path).
  - Valid artifacts are persisted via ``artifact_repo.create()``.
  - A 409 is returned for duplicate artifact IDs within the same tenant.
  - The final ``BulkImportResult`` mirrors the local response structure.

Enterprise semantics (confirm_duplicates):
  - Duplicate matches are confirmed in the DB via ``artifact_repo.update()``.
  - New artifacts are created via ``artifact_repo.create()``.
  - Skipped artifacts are logged for audit but not persisted.
  - The final ``ConfirmDuplicatesResponse`` mirrors the local response structure.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from pathlib import Path as PathLib
from typing import Any, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from skillmeat.api.dependencies import (
    ArtifactManagerDep,
    ArtifactManagerOptDep,
    ArtifactRepoDep,
    CollectionManagerDep,
    CollectionManagerOptDep,
    DbSessionDep,
    SettingsDep,
    require_auth,
    verify_api_key,
)
from skillmeat.api.middleware.auth import TokenDep
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.common import ErrorResponse
from skillmeat.api.schemas.discovery import (
    BulkImportRequest,
    BulkImportResult,
    ConfirmDuplicatesRequest,
    ConfirmDuplicatesResponse,
)
from skillmeat.api.utils.error_handlers import (
    create_internal_error,
    validate_artifact_request,
)
from skillmeat.core.interfaces.dtos import ArtifactDTO

from ._helpers import _decode_project_id_param

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/artifacts",
    tags=["artifacts"],
    dependencies=[Depends(verify_api_key)],
)


# ---------------------------------------------------------------------------
# POST /discover/import  — bulk import artifacts
# ---------------------------------------------------------------------------


@router.post(
    "/discover/import",
    response_model=BulkImportResult,
    status_code=status.HTTP_200_OK,
    summary="Bulk import artifacts",
    description="Import multiple artifacts from discovered artifacts or external sources with atomic transaction",
    responses={
        200: {
            "description": "Bulk import completed (check results for per-artifact status)"
        },
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def bulk_import_artifacts(
    request: BulkImportRequest,
    artifact_mgr: ArtifactManagerOptDep,
    collection_mgr: CollectionManagerOptDep,
    session: DbSessionDep,
    artifact_repo: ArtifactRepoDep,
    settings: SettingsDep,
    _token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    collection: Optional[str] = Query(
        None, description="Collection name (uses default if not specified)"
    ),
    project_id: Optional[str] = Query(
        None,
        description="Base64-encoded project path to also record deployments for the imports",
    ),
) -> BulkImportResult:
    """Bulk import multiple artifacts with graceful error handling.

    Validates all artifacts before importing. Validation failures are tracked
    per-artifact but do NOT cause the entire batch to fail. Valid artifacts
    are imported while failed ones are reported in the results with detailed
    error messages.

    The endpoint supports importing from:
    - GitHub sources (e.g., "anthropics/skills/canvas-design@latest")
    - Discovered artifacts from the collection

    Process:
    1. Validate all artifact specifications (failures tracked, not raised)
    2. Filter to valid artifacts only
    3. Check for duplicates in target collection
    4. Import valid artifacts (skip duplicates if auto_resolve_conflicts=True)
    5. Update collection manifest and lock files
    6. Build results combining validation failures + import results

    Response includes per-artifact status:
    - status: "success" (imported), "skipped" (already exists), "failed" (error)
    - skip_reason: Explanation when status="skipped"
    - error: Error message when status="failed" (includes validation errors)

    Args:
        request: BulkImportRequest with list of artifacts to import
        artifact_mgr: Artifact manager dependency
        collection_mgr: Collection manager dependency
        session: Database session for cache writes
        artifact_repo: Artifact repository (enterprise path only)
        settings: API settings (controls edition-based branching)
        _token: Authentication token (dependency injection)
        auth_context: Caller auth context
        collection: Optional collection name (defaults to "default")
        project_id: Optional base64-encoded project path for deployment recording

    Returns:
        BulkImportResult with per-artifact status, summary counts, and location breakdown

    Raises:
        HTTPException: 409 on duplicate artifact ID per tenant (enterprise only)
        HTTPException: 500 if import fails catastrophically
    """
    # -----------------------------------------------------------------------
    # Enterprise path
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        return await _enterprise_bulk_import(
            request=request,
            artifact_repo=artifact_repo,
            auth_context=auth_context,
        )

    # -----------------------------------------------------------------------
    # Local path (copied verbatim from _legacy.py)
    # -----------------------------------------------------------------------
    assert artifact_mgr is not None, "artifact_mgr required for local edition"
    assert collection_mgr is not None, "collection_mgr required for local edition"
    return await _local_bulk_import(
        request=request,
        artifact_mgr=artifact_mgr,
        collection_mgr=collection_mgr,
        session=session,
        collection=collection,
        project_id=project_id,
    )


# ---------------------------------------------------------------------------
# Enterprise handler
# ---------------------------------------------------------------------------


async def _enterprise_bulk_import(
    request: BulkImportRequest,
    artifact_repo: ArtifactRepoDep,  # type: ignore[valid-type]
    auth_context: AuthContext,
) -> BulkImportResult:
    """Enterprise bulk import — persists artifacts via repository DI.

    Args:
        request: Validated import request payload.
        artifact_repo: Artifact repository for create operations.
        auth_context: Caller auth context used for tenant scoping.

    Returns:
        BulkImportResult with per-artifact status and summary counts.

    Raises:
        HTTPException: 409 if a duplicate artifact ID is detected within the tenant.
    """
    from skillmeat.api.schemas.discovery import (
        ErrorReasonCode,
        ImportResult,
        ImportStatus,
    )

    start_time = time.time()

    # Validate all artifacts first — track failures without aborting the batch.
    validation_failures: dict[int, str] = {}
    for i, artifact in enumerate(request.artifacts):
        error = validate_artifact_request(
            source=artifact.source,
            artifact_type=artifact.artifact_type,
            scope=artifact.scope,
            name=artifact.name,
            tags=artifact.tags,
        )
        if error:
            detail: Any = error.detail
            if isinstance(detail, dict) and "details" in detail:
                messages = [d.get("message", str(d)) for d in detail["details"]]
                validation_failures[i] = "; ".join(messages)
            else:
                validation_failures[i] = str(detail)
            logger.warning(
                f"Enterprise bulk import: artifact {i} "
                f"({artifact.name or artifact.source}) failed validation: "
                f"{validation_failures[i]}"
            )

    results: list[ImportResult] = []
    seen_ids: set[str] = set()

    for i, artifact in enumerate(request.artifacts):
        artifact_id = (
            f"{artifact.artifact_type}:{artifact.name}"
            if artifact.name
            else f"{artifact.artifact_type}:{artifact.source}"
        )

        if i in validation_failures:
            results.append(
                ImportResult(
                    artifact_id=artifact_id,
                    path=artifact.path,
                    status=ImportStatus.FAILED,
                    message="Validation failed",
                    error=validation_failures[i],
                    reason_code=ErrorReasonCode.INVALID_SOURCE,
                    skip_reason=None,
                    details=None,
                    tags_applied=0,
                )
            )
            continue

        # Duplicate detection within the current request batch.
        if artifact_id in seen_ids:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Duplicate artifact ID '{artifact_id}' in import request",
            )
        seen_ids.add(artifact_id)

        dto = ArtifactDTO(
            id=artifact_id,
            name=artifact.name or artifact.source.rsplit("/", 1)[-1].split("@")[0],
            artifact_type=artifact.artifact_type,
            source=artifact.source,
            scope=artifact.scope,
            description=artifact.description,
            tags=list(artifact.tags),
            metadata={
                "author": artifact.author,
                "target_platforms": (
                    [p.value for p in artifact.target_platforms]
                    if artifact.target_platforms is not None
                    else None
                ),
            },
        )

        try:
            artifact_repo.create(dto, auth_context=auth_context)
            results.append(
                ImportResult(
                    artifact_id=artifact_id,
                    path=artifact.path,
                    status=ImportStatus.SUCCESS,
                    message="Artifact imported successfully",
                    error=None,
                    reason_code=None,
                    skip_reason=None,
                    details=None,
                    tags_applied=len(artifact.tags),
                )
            )
            logger.info(f"Enterprise bulk import: created artifact '{artifact_id}'")
        except ValueError as exc:
            # Repository raises ValueError for duplicate IDs within the tenant.
            error_msg = str(exc)
            if (
                "duplicate" in error_msg.lower()
                or "already exists" in error_msg.lower()
            ):
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Artifact '{artifact_id}' already exists: {error_msg}",
                )
            results.append(
                ImportResult(
                    artifact_id=artifact_id,
                    path=artifact.path,
                    status=ImportStatus.FAILED,
                    message="Import failed",
                    error=error_msg,
                    reason_code=ErrorReasonCode.INVALID_SOURCE,
                    skip_reason=None,
                    details=None,
                    tags_applied=0,
                )
            )
        except Exception as exc:
            logger.exception(
                f"Enterprise bulk import: unexpected error for '{artifact_id}': {exc}"
            )
            results.append(
                ImportResult(
                    artifact_id=artifact_id,
                    path=artifact.path,
                    status=ImportStatus.FAILED,
                    message="Import failed",
                    error=str(exc),
                    reason_code=None,
                    skip_reason=None,
                    details=None,
                    tags_applied=0,
                )
            )

    total_imported = sum(1 for r in results if r.status == ImportStatus.SUCCESS)
    total_skipped = sum(1 for r in results if r.status == ImportStatus.SKIPPED)
    total_failed = sum(1 for r in results if r.status == ImportStatus.FAILED)
    total_tags = sum(r.tags_applied or 0 for r in results)

    return BulkImportResult(
        total_requested=len(request.artifacts),
        total_imported=total_imported,
        total_skipped=total_skipped,
        total_failed=total_failed,
        imported_to_collection=total_imported,
        added_to_project=0,
        total_tags_applied=total_tags,
        results=results,
        duration_ms=(time.time() - start_time) * 1000,
    )


# ---------------------------------------------------------------------------
# Local handler (copied verbatim from _legacy.py)
# ---------------------------------------------------------------------------


async def _local_bulk_import(
    request: BulkImportRequest,
    artifact_mgr: ArtifactManagerDep,  # type: ignore[valid-type]
    collection_mgr: CollectionManagerDep,  # type: ignore[valid-type]
    session: DbSessionDep,  # type: ignore[valid-type]
    collection: Optional[str],
    project_id: Optional[str],
) -> BulkImportResult:
    """Local bulk import — delegates to ArtifactImporter and filesystem writes.

    This is the local path from ``_legacy.py``, preserved verbatim so that
    local edition behaviour is bit-for-bit identical.

    Args:
        request: Validated import request payload.
        artifact_mgr: Local artifact manager.
        collection_mgr: Local collection manager.
        session: Database session for cache writes.
        collection: Optional collection name override.
        project_id: Optional base64-encoded project path for deployment recording.

    Returns:
        BulkImportResult with per-artifact status, summary counts, and location breakdown.

    Raises:
        HTTPException: 500 if import fails catastrophically.
    """
    # Deferred imports kept in function scope (heavy, only needed on local path).
    from skillmeat.api.schemas.discovery import (
        ErrorReasonCode,
        ImportResult,
        ImportStatus,
    )
    from skillmeat.api.services.artifact_cache_service import add_deployment_to_cache
    from skillmeat.core.deployment import Deployment
    from skillmeat.core.importer import (
        BulkImportArtifactData,
        BulkImportResultData,
    )
    from skillmeat.core.version_service import VersionService
    from skillmeat.storage.deployment import DeploymentTracker
    from skillmeat.utils.filesystem import compute_content_hash

    # Import ArtifactImporter via the package namespace so test mocks applied to
    # ``skillmeat.api.routers.artifacts.ArtifactImporter`` are intercepted here.
    import sys as _sys

    _arts_pkg = _sys.modules.get("skillmeat.api.routers.artifacts")
    ArtifactImporter = (
        _arts_pkg.ArtifactImporter  # type: ignore[attr-defined]
        if _arts_pkg is not None
        else __import__(
            "skillmeat.core.importer", fromlist=["ArtifactImporter"]
        ).ArtifactImporter
    )

    collection_name = collection or "default"

    try:
        # Validate all artifacts before importing - track failures instead of raising 422
        validation_failures: dict[int, str] = {}
        for i, artifact in enumerate(request.artifacts):
            error = validate_artifact_request(
                source=artifact.source,
                artifact_type=artifact.artifact_type,
                scope=artifact.scope,
                name=artifact.name,
                tags=artifact.tags,
            )
            if error:
                detail: Any = error.detail
                if isinstance(detail, dict) and "details" in detail:
                    messages = [d.get("message", str(d)) for d in detail["details"]]
                    validation_failures[i] = "; ".join(messages)
                else:
                    validation_failures[i] = str(detail)
                logger.warning(
                    f"Artifact {i} ({artifact.name or artifact.source}) failed validation: "
                    f"{validation_failures[i]}"
                )

        # Create importer service
        importer = ArtifactImporter(
            artifact_manager=artifact_mgr,
            collection_manager=collection_mgr,
        )

        # Filter to only valid artifacts for import
        valid_artifact_indices = [
            i for i in range(len(request.artifacts)) if i not in validation_failures
        ]
        valid_artifacts = [request.artifacts[i] for i in valid_artifact_indices]

        # Convert only valid Pydantic schemas to data classes
        artifacts_data = [
            BulkImportArtifactData(
                source=a.source,
                artifact_type=a.artifact_type,
                name=a.name,
                description=a.description,
                author=a.author,
                tags=a.tags,
                target_platforms=(
                    [platform.value for platform in a.target_platforms]
                    if a.target_platforms is not None
                    else None
                ),
                scope=a.scope,
                path=a.path,
            )
            for a in valid_artifacts
        ]

        # Perform bulk import only if there are valid artifacts
        start_time = time.time()

        if artifacts_data:
            logger.info(
                f"Starting bulk import of {len(artifacts_data)} artifacts "
                f"(skipped {len(validation_failures)} with validation errors) "
                f"to collection '{collection_name}'"
            )

            result_data = importer.bulk_import(
                artifacts=artifacts_data,
                collection_name=collection_name,
                auto_resolve_conflicts=request.auto_resolve_conflicts,
                apply_path_tags=request.apply_path_tags,
            )

            logger.info(
                f"Bulk import completed: {result_data.total_imported}/{result_data.total_requested} "
                f"imported, {result_data.total_failed} failed in {result_data.duration_ms:.1f}ms"
            )
        else:
            # All artifacts failed validation - create empty result
            logger.warning(
                f"No valid artifacts to import - all {len(request.artifacts)} failed validation"
            )
            result_data = BulkImportResultData(
                total_requested=0,
                total_imported=0,
                total_failed=0,
                results=[],
                duration_ms=(time.time() - start_time) * 1000,
                total_tags_applied=0,
            )

        # Build results: combine validation failures + import results in original order
        import_results_by_valid_idx = {i: r for i, r in enumerate(result_data.results)}

        results: list[ImportResult] = []
        valid_idx = 0

        for i, artifact in enumerate(request.artifacts):
            if i in validation_failures:
                artifact_id = (
                    f"{artifact.artifact_type}:{artifact.name}"
                    if artifact.name
                    else f"{artifact.artifact_type}:{artifact.source}"
                )
                results.append(
                    ImportResult(
                        artifact_id=artifact_id,
                        path=artifact.path,
                        status=ImportStatus.FAILED,
                        message="Validation failed",
                        error=validation_failures[i],
                        reason_code=ErrorReasonCode.INVALID_SOURCE,
                        skip_reason=None,
                        details=None,
                        tags_applied=0,
                    )
                )
            else:
                if valid_idx in import_results_by_valid_idx:
                    r = import_results_by_valid_idx[valid_idx]
                    results.append(
                        ImportResult(
                            artifact_id=r.artifact_id,
                            path=r.path,
                            status=(
                                ImportStatus(r.status.value)
                                if r.status
                                else (
                                    ImportStatus.SUCCESS
                                    if r.success
                                    else ImportStatus.FAILED
                                )
                            ),
                            message=r.message,
                            error=r.error,
                            reason_code=(
                                ErrorReasonCode(r.reason_code)
                                if r.reason_code
                                and r.reason_code in [e.value for e in ErrorReasonCode]
                                else None
                            ),
                            skip_reason=r.skip_reason,
                            details=r.details,
                            tags_applied=r.tags_applied,
                        )
                    )
                valid_idx += 1

        # If we know which project initiated the import, record deployments so UI reflects the change
        if project_id:
            project_path = _decode_project_id_param(project_id)

            if project_path is None:
                logger.warning(
                    f"Invalid project_id provided to bulk import: {project_id}"
                )
            elif not project_path.exists():
                logger.warning(
                    f"Provided project_id path does not exist: {project_path}"
                )
                project_path = None

            if project_path:
                try:
                    claude_dir = project_path / ".claude"
                    if not claude_dir.exists():
                        logger.warning(
                            f"Cannot record deployments for {project_path}: .claude directory missing"
                        )
                    else:
                        deployments = DeploymentTracker.read_deployments(project_path)
                        updated = False

                        for artifact_payload, import_result in zip(
                            request.artifacts, results
                        ):
                            if import_result.status != ImportStatus.SUCCESS:
                                continue

                            if not artifact_payload.path:
                                logger.debug(
                                    f"Skipping deployment record for {import_result.artifact_id}: missing path"
                                )
                                continue

                            artifact_path = PathLib(artifact_payload.path).resolve()
                            try:
                                artifact_path.relative_to(claude_dir)
                            except ValueError:
                                logger.warning(
                                    f"Artifact path {artifact_path} is outside project .claude ({claude_dir}); skipping deployment record"
                                )
                                continue

                            artifact_name = artifact_payload.name or artifact_path.stem

                            try:
                                content_hash = compute_content_hash(artifact_path)
                            except Exception as e:
                                logger.warning(
                                    f"Failed to hash artifact at {artifact_path}: {e}"
                                )
                                continue

                            deployment = Deployment(
                                artifact_name=artifact_name,
                                artifact_type=artifact_payload.artifact_type,
                                from_collection=collection_name,
                                deployed_at=datetime.now(),
                                artifact_path=artifact_path.relative_to(claude_dir),
                                content_hash=content_hash,
                                local_modifications=False,
                            )

                            deployments = [
                                d
                                for d in deployments
                                if not (
                                    d.artifact_name == deployment.artifact_name
                                    and d.artifact_type == deployment.artifact_type
                                )
                            ]
                            deployments.append(deployment)
                            updated = True

                        if updated:
                            DeploymentTracker.write_deployments(
                                project_path, deployments
                            )
                            logger.info(
                                f"Recorded deployments for {project_path} after import"
                            )

                            # Also record deployments in DB cache for UI visibility
                            for artifact_payload, import_result in zip(
                                request.artifacts, results
                            ):
                                if import_result.status != ImportStatus.SUCCESS:
                                    continue

                                artifact_name = artifact_payload.name or (
                                    PathLib(artifact_payload.path).stem
                                    if artifact_payload.path
                                    else None
                                )
                                if not artifact_name:
                                    continue

                                artifact_id = (
                                    f"{artifact_payload.artifact_type}:{artifact_name}"
                                )

                                try:
                                    add_deployment_to_cache(
                                        session=session,
                                        artifact_id=artifact_id,
                                        project_path=str(project_path),
                                        project_name=project_path.name,
                                        deployed_at=datetime.now(timezone.utc),
                                        content_hash=(
                                            compute_content_hash(
                                                PathLib(artifact_payload.path)
                                            )
                                            if artifact_payload.path
                                            else None
                                        ),
                                        local_modifications=False,
                                        collection_id=collection_name,
                                    )
                                except Exception as e:
                                    logger.warning(
                                        f"Failed to record deployment in cache for {artifact_id}: {e}"
                                    )
                except Exception as e:
                    logger.warning(
                        f"Failed to update project deployments for {project_path}: {e}"
                    )

        # Version seeding — record initial_seed for every successfully imported artifact.
        # Non-fatal: any failure is caught and logged without affecting the response.
        try:
            vs = VersionService(session)
            for artifact_payload, import_result in zip(request.artifacts, results):
                if import_result.status != ImportStatus.SUCCESS:
                    continue
                artifact_name = artifact_payload.name or (
                    PathLib(artifact_payload.path).stem
                    if artifact_payload.path
                    else None
                )
                if not artifact_name:
                    continue
                seed_artifact_id = f"{artifact_payload.artifact_type}:{artifact_name}"
                seed_hash = ""
                if artifact_payload.path:
                    try:
                        seed_hash = compute_content_hash(PathLib(artifact_payload.path))
                    except Exception:
                        pass
                vs.record_mutation(
                    artifact_id=seed_artifact_id,
                    change_origin="initial_seed",
                    content_hash=seed_hash,
                )
        except Exception:
            pass  # VersionService is already non-fatal internally

        # Calculate totals from combined results (including validation failures)
        total_skipped = sum(1 for r in results if r.status == ImportStatus.SKIPPED)
        total_failed = sum(1 for r in results if r.status == ImportStatus.FAILED)
        total_imported = sum(1 for r in results if r.status == ImportStatus.SUCCESS)

        return BulkImportResult(
            total_requested=len(request.artifacts),
            total_imported=total_imported,
            total_skipped=total_skipped,
            total_failed=total_failed,
            imported_to_collection=total_imported,
            added_to_project=0,
            total_tags_applied=result_data.total_tags_applied,
            results=results,
            duration_ms=result_data.duration_ms,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Bulk import failed: {e}")
        raise create_internal_error("Bulk import failed", e)


# ---------------------------------------------------------------------------
# POST /confirm-duplicates  — process duplicate review decisions
# ---------------------------------------------------------------------------


@router.post(
    "/confirm-duplicates",
    response_model=ConfirmDuplicatesResponse,
    status_code=status.HTTP_200_OK,
    summary="Process duplicate review decisions",
    description="""
    Process user decisions from the duplicate review modal.

    Handles three types of decisions:
    1. **matches**: Link discovered duplicates to existing collection artifacts
    2. **new_artifacts**: Import selected paths as new artifacts
    3. **skipped**: Acknowledge paths the user chose to skip (logged for audit)

    All operations are atomic - if any operation fails, the response will
    indicate partial success with error details.

    This endpoint is idempotent for link operations - calling multiple times
    with the same matches will not create duplicate links.
    """,
    responses={
        200: {"description": "Duplicate decisions processed successfully"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
    tags=["discovery"],
)
async def confirm_duplicates(
    request: ConfirmDuplicatesRequest,
    collection_mgr: CollectionManagerOptDep,
    artifact_mgr: ArtifactManagerOptDep,
    artifact_repo: ArtifactRepoDep,
    settings: SettingsDep,
    _token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    collection: Optional[str] = Query(
        None, description="Collection name (uses default if not specified)"
    ),
) -> ConfirmDuplicatesResponse:
    """Process duplicate review decisions from the frontend modal.

    This endpoint processes user decisions made in the duplicate review modal:
    - Links duplicates to existing collection artifacts
    - Imports new artifacts using the standard importer
    - Logs skipped artifacts for audit purposes

    Args:
        request: ConfirmDuplicatesRequest with matches, new_artifacts, and skipped
        collection_mgr: Collection manager dependency
        artifact_mgr: Artifact manager dependency
        artifact_repo: Artifact repository (enterprise path only)
        settings: API settings (controls edition-based branching)
        _token: Authentication token
        auth_context: Caller auth context
        collection: Target collection name

    Returns:
        ConfirmDuplicatesResponse with operation counts and status
    """
    if settings.edition == "enterprise":
        return await _enterprise_confirm_duplicates(
            request=request,
            artifact_repo=artifact_repo,
            auth_context=auth_context,
        )

    assert artifact_mgr is not None, "artifact_mgr required for local edition"
    assert collection_mgr is not None, "collection_mgr required for local edition"
    return await _local_confirm_duplicates(
        request=request,
        collection_mgr=collection_mgr,
        artifact_mgr=artifact_mgr,
        collection=collection,
    )


# ---------------------------------------------------------------------------
# Enterprise handler for confirm_duplicates
# ---------------------------------------------------------------------------


async def _enterprise_confirm_duplicates(
    request: ConfirmDuplicatesRequest,
    artifact_repo: ArtifactRepoDep,  # type: ignore[valid-type]
    auth_context: AuthContext,
) -> ConfirmDuplicatesResponse:
    """Enterprise confirm duplicates — marks duplicates as confirmed in the DB.

    Args:
        request: Validated confirm-duplicates request payload.
        artifact_repo: Artifact repository for update/create operations.
        auth_context: Caller auth context used for tenant scoping.

    Returns:
        ConfirmDuplicatesResponse with operation counts and status.
    """
    from skillmeat.api.schemas.discovery import (
        ConfirmDuplicatesStatus,
        DuplicateDecisionAction,
    )

    errors: List[str] = []
    linked_count = 0
    imported_count = 0
    skipped_count = len(request.skipped)

    logger.info(
        f"Enterprise: processing duplicate decisions: {len(request.matches)} matches, "
        f"{len(request.new_artifacts)} new, {len(request.skipped)} skipped"
    )

    # Phase 1: Process duplicate matches — mark confirmed in DB via update()
    for match in request.matches:
        if match.action == DuplicateDecisionAction.SKIP:
            skipped_count += 1
            logger.debug(
                f"Enterprise: skipping duplicate match for {match.discovered_path}"
            )
            continue

        try:
            existing = artifact_repo.get(
                match.collection_artifact_id, auth_context=auth_context
            )
            if existing is None:
                errors.append(
                    f"Artifact not found in enterprise DB: {match.collection_artifact_id}"
                )
                continue

            # Record the confirmed duplicate link in the artifact metadata.
            confirmed_links: list[str] = list(
                existing.metadata.get("confirmed_duplicate_paths", [])
            )
            if match.discovered_path not in confirmed_links:
                confirmed_links.append(match.discovered_path)

            updated_metadata = dict(existing.metadata)
            updated_metadata["confirmed_duplicate_paths"] = confirmed_links

            artifact_repo.update(
                match.collection_artifact_id,
                {"metadata": updated_metadata},
                auth_context=auth_context,
            )
            linked_count += 1
            logger.info(
                f"Enterprise: confirmed duplicate link: {match.discovered_path} -> "
                f"{match.collection_artifact_id}"
            )
        except ValueError as e:
            errors.append(f"Invalid artifact ID format: {e}")
        except Exception as e:
            logger.exception(
                f"Enterprise: failed to confirm duplicate for "
                f"{match.collection_artifact_id}: {e}"
            )
            errors.append(f"Failed to confirm {match.discovered_path}: {str(e)}")

    # Phase 2: Import new artifacts into the enterprise DB
    for artifact_path in request.new_artifacts:
        try:
            path = PathLib(artifact_path)
            artifact_id = f"skill:{path.name}"

            dto = ArtifactDTO(
                id=artifact_id,
                name=path.name,
                artifact_type="skill",
                source=f"local/{path.name}",
                scope="user",
                description=None,
                tags=[],
                metadata={"discovered_path": artifact_path},
            )
            try:
                artifact_repo.create(dto, auth_context=auth_context)
                imported_count += 1
                logger.info(
                    f"Enterprise: imported new artifact from path: {artifact_path}"
                )
            except ValueError as exc:
                error_msg = str(exc)
                if (
                    "duplicate" in error_msg.lower()
                    or "already exists" in error_msg.lower()
                ):
                    # Treat pre-existing artifact as a successful import (idempotent)
                    imported_count += 1
                    logger.debug(
                        f"Enterprise: artifact already exists (idempotent): {artifact_id}"
                    )
                else:
                    errors.append(f"Failed to import {artifact_path}: {error_msg}")
        except Exception as e:
            logger.exception(
                f"Enterprise: failed to import artifact {artifact_path}: {e}"
            )
            errors.append(f"Failed to import {artifact_path}: {str(e)}")

    # Phase 3: Log skipped artifacts (audit trail)
    for skipped_path in request.skipped:
        logger.info(f"Enterprise: user skipped artifact: {skipped_path}")

    # Determine overall status
    total_operations = len(request.matches) + len(request.new_artifacts)
    successful_operations = linked_count + imported_count

    if total_operations == 0:
        op_status = ConfirmDuplicatesStatus.SUCCESS
    elif successful_operations == 0 and errors:
        op_status = ConfirmDuplicatesStatus.FAILED
    elif errors:
        op_status = ConfirmDuplicatesStatus.PARTIAL
    else:
        op_status = ConfirmDuplicatesStatus.SUCCESS

    parts = []
    if linked_count > 0:
        parts.append(f"{linked_count} linked")
    if imported_count > 0:
        parts.append(f"{imported_count} imported")
    if skipped_count > 0:
        parts.append(f"{skipped_count} skipped")

    total_processed = linked_count + imported_count + skipped_count
    message = f"Processed {total_processed} artifacts"
    if parts:
        message += f": {', '.join(parts)}"

    timestamp = datetime.now(timezone.utc).isoformat()

    logger.info(
        f"Enterprise duplicate confirmation complete: {message} "
        f"(status={op_status.value}, errors={len(errors)})"
    )

    return ConfirmDuplicatesResponse(
        status=op_status,
        linked_count=linked_count,
        imported_count=imported_count,
        skipped_count=skipped_count,
        message=message,
        timestamp=timestamp,
        errors=errors,
    )


# ---------------------------------------------------------------------------
# Local handler for confirm_duplicates (copied verbatim from _legacy.py)
# ---------------------------------------------------------------------------


async def _local_confirm_duplicates(
    request: ConfirmDuplicatesRequest,
    collection_mgr: CollectionManagerDep,  # type: ignore[valid-type]
    artifact_mgr: ArtifactManagerDep,  # type: ignore[valid-type]
    collection: Optional[str],
) -> ConfirmDuplicatesResponse:
    """Local confirm duplicates — delegates to CollectionManager link and ArtifactImporter.

    This is the local path from ``_legacy.py``, preserved verbatim so that
    local edition behaviour is bit-for-bit identical.

    Args:
        request: Validated confirm-duplicates request payload.
        collection_mgr: Local collection manager.
        artifact_mgr: Local artifact manager.
        collection: Optional collection name override.

    Returns:
        ConfirmDuplicatesResponse with operation counts and status.
    """
    from skillmeat.api.schemas.discovery import (
        ConfirmDuplicatesStatus,
        DuplicateDecisionAction,
    )
    from skillmeat.core.importer import BulkImportArtifactData

    # Import ArtifactImporter via the package namespace so test mocks applied to
    # ``skillmeat.api.routers.artifacts.ArtifactImporter`` are intercepted here.
    import sys as _sys

    _arts_pkg = _sys.modules.get("skillmeat.api.routers.artifacts")
    ArtifactImporter = (
        _arts_pkg.ArtifactImporter  # type: ignore[attr-defined]
        if _arts_pkg is not None
        else __import__(
            "skillmeat.core.importer", fromlist=["ArtifactImporter"]
        ).ArtifactImporter
    )

    errors: List[str] = []
    linked_count = 0
    imported_count = 0
    skipped_count = len(request.skipped)

    collection_name = collection or collection_mgr.get_active_collection_name()

    logger.info(
        f"Processing duplicate decisions: {len(request.matches)} matches, "
        f"{len(request.new_artifacts)} new, {len(request.skipped)} skipped"
    )

    # Phase 1: Process duplicate links
    for match in request.matches:
        if match.action == DuplicateDecisionAction.SKIP:
            skipped_count += 1
            logger.debug(f"Skipping duplicate match for {match.discovered_path}")
            continue

        try:
            # Validate discovered path exists
            discovered_path = PathLib(match.discovered_path)
            if not discovered_path.exists():
                errors.append(
                    f"Discovered path does not exist: {match.discovered_path}"
                )
                continue

            # Create the duplicate link
            success = collection_mgr.link_duplicate(
                discovered_path=str(discovered_path),
                collection_artifact_id=match.collection_artifact_id,
                collection_name=collection_name,
            )

            if success:
                linked_count += 1
                logger.info(
                    f"Linked duplicate: {match.discovered_path} -> "
                    f"{match.collection_artifact_id}"
                )
            else:
                errors.append(
                    f"Failed to link {match.discovered_path} to "
                    f"{match.collection_artifact_id}: artifact not found in collection"
                )

        except ValueError as e:
            errors.append(f"Invalid artifact ID format: {e}")
        except Exception as e:
            logger.exception(f"Failed to link duplicate: {e}")
            errors.append(f"Failed to link {match.discovered_path}: {str(e)}")

    # Phase 2: Import new artifacts
    if request.new_artifacts:
        try:
            # Use the existing importer for new artifacts
            importer = ArtifactImporter(artifact_mgr, collection_mgr)

            for artifact_path in request.new_artifacts:
                try:
                    path = PathLib(artifact_path)
                    if not path.exists():
                        errors.append(f"Artifact path does not exist: {artifact_path}")
                        continue

                    # Detect artifact type and extract metadata
                    from skillmeat.core.artifact_detection import infer_artifact_type

                    artifact_type = infer_artifact_type(path)
                    if artifact_type is None:
                        errors.append(
                            f"Could not detect artifact type for: {artifact_path}"
                        )
                        continue

                    # Build import data
                    artifact_data = BulkImportArtifactData(
                        source=f"local/{path.name}",
                        artifact_type=artifact_type.value,
                        name=path.name,
                        path=str(path),
                        scope="user",
                    )

                    # Import single artifact
                    result = importer._import_single(artifact_data, collection_name)

                    if result.success:
                        imported_count += 1
                        logger.info(f"Imported new artifact: {artifact_path}")
                    else:
                        errors.append(
                            f"Failed to import {artifact_path}: "
                            f"{result.error or result.message}"
                        )

                except Exception as e:
                    logger.exception(f"Failed to import artifact {artifact_path}: {e}")
                    errors.append(f"Failed to import {artifact_path}: {str(e)}")

        except Exception as e:
            logger.exception(f"Failed to initialize importer: {e}")
            errors.append(f"Failed to initialize importer: {str(e)}")

    # Phase 3: Log skipped artifacts (for audit trail)
    for skipped_path in request.skipped:
        logger.info(f"User skipped artifact: {skipped_path}")

    # Determine overall status
    total_operations = len(request.matches) + len(request.new_artifacts)
    successful_operations = linked_count + imported_count

    if total_operations == 0:
        op_status = ConfirmDuplicatesStatus.SUCCESS
    elif successful_operations == 0 and errors:
        op_status = ConfirmDuplicatesStatus.FAILED
    elif errors:
        op_status = ConfirmDuplicatesStatus.PARTIAL
    else:
        op_status = ConfirmDuplicatesStatus.SUCCESS

    # Build summary message
    parts = []
    if linked_count > 0:
        parts.append(f"{linked_count} linked")
    if imported_count > 0:
        parts.append(f"{imported_count} imported")
    if skipped_count > 0:
        parts.append(f"{skipped_count} skipped")

    total_processed = linked_count + imported_count + skipped_count
    message = f"Processed {total_processed} artifacts"
    if parts:
        message += f": {', '.join(parts)}"

    timestamp = datetime.now(timezone.utc).isoformat()

    logger.info(
        f"Duplicate confirmation complete: {message} "
        f"(status={op_status.value}, errors={len(errors)})"
    )

    return ConfirmDuplicatesResponse(
        status=op_status,
        linked_count=linked_count,
        imported_count=imported_count,
        skipped_count=skipped_count,
        message=message,
        timestamp=timestamp,
        errors=errors,
    )
