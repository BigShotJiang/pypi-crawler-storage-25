"""Deployment endpoint for the artifacts router — dual-mode (local + enterprise).

Contains: deploy_artifact (POST /{artifact_id}/deploy)

The endpoint branches on ``settings.edition == "enterprise"`` and delegates
to the appropriate handler.  The local handler is copied verbatim from
``_legacy.py`` so behaviour is identical.  The enterprise handler uses
``IDeploymentRepository.deploy()`` only — it never accesses ``artifact_mgr``
or ``collection_mgr``.
"""

from __future__ import annotations

import base64
import hashlib
import logging
import shutil
from pathlib import Path as PathLib
from typing import Optional

from fastapi import APIRouter, Body, Depends, HTTPException, Query, status

from skillmeat.api.dependencies import (
    ArtifactManagerOptDep,
    CollectionManagerOptDep,
    CollectionRepoDep,
    DeploymentRepoDep,
    SettingsDep,
    SyncManagerOptDep,
    require_auth,
    verify_api_key,
)
from skillmeat.api.middleware.auth import TokenDep
from skillmeat.api.schemas.artifacts import (
    ArtifactDeployRequest,
    ArtifactDeployResponse,
    ArtifactSyncRequest,
    ArtifactSyncResponse,
    ConflictInfo,
    MergeDeployDetails,
    MergeFileAction,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.common import ErrorResponse
from skillmeat.core.artifact import ArtifactType
from skillmeat.core.bom.event_emitter import emit_activity_event
from skillmeat.api.utils.upstream_cache import get_upstream_cache
from skillmeat.cache.models import get_session
from skillmeat.api.services import refresh_single_artifact_cache

from ._helpers import (
    iter_artifact_files,
    parse_artifact_id,
    resolve_collection_name,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/artifacts",
    tags=["artifacts"],
    dependencies=[Depends(verify_api_key)],
)


# ---------------------------------------------------------------------------
# Enterprise helper: map DeploymentDTO → ArtifactDeployResponse
# ---------------------------------------------------------------------------


def _dto_to_deploy_response(dto) -> ArtifactDeployResponse:
    """Convert a DeploymentDTO from the enterprise repo to an ArtifactDeployResponse.

    Only fields available on DeploymentDTO are populated; filesystem-specific
    fields such as ``deployed_path`` default to None on the enterprise path.

    Args:
        dto: DeploymentDTO returned by IDeploymentRepository.deploy().

    Returns:
        ArtifactDeployResponse suitable for returning to the caller.
    """
    return ArtifactDeployResponse(
        success=True,
        message=f"Artifact '{dto.artifact_name}' deployed successfully",
        artifact_name=dto.artifact_name,
        artifact_type=dto.artifact_type,
        deployed_path=dto.target_path,
        error_message=None,
        strategy="overwrite",
        deployment_profile_id=dto.deployment_profile_id,
        deployed_profiles=(
            [dto.deployment_profile_id] if dto.deployment_profile_id else []
        ),
    )


# ---------------------------------------------------------------------------
# Local helper: refresh DB cache after deploy (non-fatal)
# ---------------------------------------------------------------------------


def _refresh_cache_safe(
    artifact_mgr,
    artifact_id: str,
    collection_name: str,
    deployment_profile_id: Optional[str] = None,
) -> None:
    """Refresh DB cache after deploy, swallowing errors to avoid failing the deploy.

    TODO: When the service layer has a proper cache-sync abstraction, replace
    the raw get_session() calls here with a CacheSyncService dependency.
    """
    try:
        db_session = get_session()
        try:
            refresh_single_artifact_cache(
                db_session,
                artifact_mgr,
                artifact_id,
                collection_name,
                deployment_profile_id=deployment_profile_id,
            )
        finally:
            db_session.close()
    except Exception as cache_err:
        logger.warning(f"Cache refresh failed for {artifact_id}: {cache_err}")


# ---------------------------------------------------------------------------
# Local helper: merge deployment strategy
# ---------------------------------------------------------------------------


async def _deploy_merge(
    *,
    artifact_id: str,
    artifact_name: str,
    artifact_type: ArtifactType,
    artifact,
    collection_name: str,
    collection_mgr,
    artifact_mgr,
    project_path: PathLib,
    settings: SettingsDep,
) -> ArtifactDeployResponse:
    """Perform a merge deployment: file-level merge between collection and project.

    Files only in collection (source) are copied to project.
    Files only in project (target) are preserved (not deleted).
    Files in both that are identical are skipped.
    Files in both that differ are reported as conflicts (project version kept).

    Args:
        artifact_id: Artifact identifier string
        artifact_name: Artifact name
        artifact_type: Artifact type enum
        artifact: Artifact object from collection
        collection_name: Name of source collection
        collection_mgr: Collection manager instance
        artifact_mgr: Artifact manager instance
        project_path: Path to the target project directory
        settings: API settings instance

    Returns:
        ArtifactDeployResponse with merge_details populated
    """
    # Resolve source path (collection artifact directory)
    collection_path = collection_mgr.config.get_collection_path(collection_name)
    source_path = collection_path / artifact.path

    if not source_path.exists():
        logger.error(f"Collection artifact path missing: {source_path}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Collection artifact path does not exist: {source_path}",
        )

    # Resolve target path (project deployment directory)
    dest_base = project_path / ".claude"
    if artifact_type == ArtifactType.SKILL:
        target_path = dest_base / "skills" / artifact_name
    elif artifact_type == ArtifactType.COMMAND:
        target_path = dest_base / "commands" / f"{artifact_name}.md"
    elif artifact_type == ArtifactType.AGENT:
        target_path = dest_base / "agents" / f"{artifact_name}.md"
    elif artifact_type == ArtifactType.MCP:
        target_path = dest_base / "mcp" / artifact_name
    elif artifact_type == ArtifactType.HOOK:
        target_path = dest_base / "hooks" / f"{artifact_name}.md"
    elif artifact_type == ArtifactType.COMPOSITE:
        target_path = dest_base / "composites" / artifact_name
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported artifact type for merge: {artifact_type.value}",
        )

    # If target does not exist yet, this is a fresh deploy — copy everything
    if not target_path.exists():
        logger.info(
            f"Merge deploy: target does not exist, performing full copy to {target_path}"
        )
        target_path.parent.mkdir(parents=True, exist_ok=True)
        if source_path.is_dir():
            shutil.copytree(
                source_path,
                target_path,
                ignore=shutil.ignore_patterns(
                    "__pycache__", "*.pyc", ".DS_Store", ".git"
                ),
            )
        else:
            shutil.copy2(source_path, target_path)

        # Count files copied
        if target_path.is_dir():
            copied_files = sorted(
                str(f.relative_to(target_path))
                for f in iter_artifact_files(
                    target_path, set(settings.diff_exclude_dirs)
                )
            )
        else:
            copied_files = [target_path.name]

        file_actions = [
            MergeFileAction(file_path=fp, action="copied") for fp in copied_files
        ]

        _refresh_cache_safe(artifact_mgr, artifact_id, collection_name)

        return ArtifactDeployResponse(
            success=True,
            message=(
                f"Artifact '{artifact_name}' deployed successfully "
                f"(merge, fresh copy of {len(copied_files)} file(s))"
            ),
            artifact_name=artifact_name,
            artifact_type=artifact_type.value,
            deployed_path=str(target_path),
            strategy="merge",
            merge_details=MergeDeployDetails(
                files_copied=len(copied_files),
                files_skipped=0,
                files_preserved=0,
                conflicts=0,
                file_actions=file_actions,
            ),
        )

    # --- Both source and target exist: perform file-level merge ---
    def _file_hash(file_path: PathLib) -> str:
        """Compute SHA-256 hash of a file."""
        hasher = hashlib.sha256()
        with open(file_path, "rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                hasher.update(chunk)
        return hasher.hexdigest()

    exclude_dirs = set(settings.diff_exclude_dirs)

    # Index source files
    if source_path.is_dir():
        source_files = {
            str(f.relative_to(source_path)): f
            for f in iter_artifact_files(source_path, exclude_dirs)
        }
    else:
        source_files = {source_path.name: source_path}

    # Index target files
    if target_path.is_dir():
        target_files = {
            str(f.relative_to(target_path)): f
            for f in iter_artifact_files(target_path, exclude_dirs)
        }
    else:
        target_files = {target_path.name: target_path}

    file_actions: list[MergeFileAction] = []
    files_copied = 0
    files_skipped = 0
    files_preserved = 0
    conflicts = 0

    # Process source files
    for rel_path, src_file in sorted(source_files.items()):
        if rel_path in target_files:
            tgt_file = target_files[rel_path]
            src_hash = _file_hash(src_file)
            tgt_hash = _file_hash(tgt_file)
            if src_hash == tgt_hash:
                file_actions.append(
                    MergeFileAction(file_path=rel_path, action="skipped")
                )
                files_skipped += 1
            else:
                file_actions.append(
                    MergeFileAction(
                        file_path=rel_path,
                        action="conflict",
                        detail="File modified on both sides — project version preserved",
                    )
                )
                conflicts += 1
        else:
            # File only in source — copy to target
            dest_file = target_path / rel_path if target_path.is_dir() else target_path
            dest_file.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_file, dest_file)
            file_actions.append(MergeFileAction(file_path=rel_path, action="copied"))
            files_copied += 1

    # Files only in target are preserved (no action needed except reporting)
    for rel_path in sorted(target_files):
        if rel_path not in source_files:
            file_actions.append(
                MergeFileAction(
                    file_path=rel_path,
                    action="preserved",
                    detail="File exists only in project — kept",
                )
            )
            files_preserved += 1

    _refresh_cache_safe(artifact_mgr, artifact_id, collection_name)

    return ArtifactDeployResponse(
        success=True,
        message=(
            f"Artifact '{artifact_name}' merge deployment complete "
            f"({files_copied} copied, {files_skipped} skipped, "
            f"{files_preserved} preserved, {conflicts} conflict(s))"
        ),
        artifact_name=artifact_name,
        artifact_type=artifact_type.value,
        deployed_path=str(target_path),
        strategy="merge",
        merge_details=MergeDeployDetails(
            files_copied=files_copied,
            files_skipped=files_skipped,
            files_preserved=files_preserved,
            conflicts=conflicts,
            file_actions=file_actions,
        ),
    )


# ---------------------------------------------------------------------------
# deploy_artifact endpoint
# ---------------------------------------------------------------------------


@router.post(
    "/{artifact_id}/deploy",
    response_model=ArtifactDeployResponse,
    summary="Deploy artifact to project",
    description=(
        "Deploy an artifact from the collection to a project directory. "
        "Supports 'overwrite' (default) and 'merge' strategies. "
        "Enterprise edition records the deployment in the database."
    ),
    responses={
        200: {"description": "Deployment result"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {
            "model": ErrorResponse,
            "description": "Artifact or collection not found",
        },
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def deploy_artifact(
    artifact_id: str,
    request: ArtifactDeployRequest,
    settings: SettingsDep,
    deployment_repo: DeploymentRepoDep,
    collection_repo: CollectionRepoDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    collection: Optional[str] = Query(
        None, description="Collection name (uses default if not specified)"
    ),
) -> ArtifactDeployResponse:
    """Deploy artifact from collection to project.

    Copies the artifact to the project's .claude/ directory and tracks
    the deployment in .skillmeat-deployed.toml (local edition) or in the
    enterprise database (enterprise edition).

    Supports two strategies:
    - 'overwrite' (default): Replace existing deployment entirely.
    - 'merge': File-level merge. New files are copied, project-only files
      are preserved, identical files are skipped, and conflicts (files
      modified on both sides) are reported without overwriting.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        request: Deployment request with project_path, overwrite flag, and strategy
        settings: API settings (controls edition-based branching)
        deployment_repo: Deployment repository (enterprise path only)
        collection_repo: Collection repository for name resolution
        token: Authentication token
        auth_context: Caller auth context
        artifact_mgr: Artifact manager (local edition only; None in enterprise)
        collection_mgr: Collection manager (local edition only; None in enterprise)
        collection: Optional collection name

    Returns:
        Deployment result with optional merge_details when strategy='merge'

    Raises:
        HTTPException: If artifact not found or on error
    """
    logger.info(
        f"Deploying artifact: {artifact_id} to {request.project_path} "
        f"(edition={settings.edition}, collection={collection}, "
        f"strategy={request.strategy})"
    )

    # -----------------------------------------------------------------------
    # Enterprise path
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        try:
            # Parse artifact ID for validation
            try:
                artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid artifact ID format. Expected 'type:name'",
                )

            # Derive a project_id from the project_path (base64-encoded path).
            # Per OQ-1 resolution, project_id FK is nullable — deployments CAN
            # be created without a pre-existing project row.
            project_id: Optional[str] = None
            if request.project_path:
                project_id = base64.b64encode(request.project_path.encode()).decode()

            options: dict = {
                "status": "deployed",
                "overwrite": request.overwrite,
            }
            if request.deployment_profile_id:
                options["deployment_profile_id"] = request.deployment_profile_id
            if request.all_profiles:
                options["all_profiles"] = True

            dto = deployment_repo.deploy(
                artifact_id=artifact_id,
                project_id=project_id or "",
                options=options,
            )

            # Emit activity event (fire-and-forget)
            emit_activity_event(
                artifact_id=artifact_id,
                event_type="deploy",
                actor_id=getattr(auth_context, "user_id", None),
                auth_context=auth_context,
            )

            return _dto_to_deploy_response(dto)

        except HTTPException:
            raise
        except KeyError as exc:
            logger.warning(
                f"Enterprise deploy: project/artifact not found for '{artifact_id}': {exc}"
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact or project not found: {exc}",
            )
        except Exception as exc:
            logger.error(
                f"Enterprise deploy error for '{artifact_id}': {exc}", exc_info=True
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to deploy artifact: {str(exc)}",
            )

    # -----------------------------------------------------------------------
    # Local path — verbatim copy from _legacy.py deploy_artifact
    # -----------------------------------------------------------------------
    if collection_mgr is None or artifact_mgr is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Collection/artifact manager unavailable",
        )

    _ = token  # used by legacy auth middleware; kept for signature compat

    try:
        if request.all_profiles and request.deployment_profile_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="deployment_profile_id cannot be set when all_profiles=true",
            )

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Validate project path
        project_path = PathLib(request.project_path)
        if not project_path.exists():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Project path does not exist: {request.project_path}",
            )

        # Get or create collection
        if collection:
            resolved = resolve_collection_name(
                collection, collection_mgr, collection_repo=collection_repo
            )
            if not resolved:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Collection '{collection}' not found",
                )
            collection = resolved
            collection_name = collection
        else:
            collections = collection_mgr.list_collections()
            if not collections:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="No collections found",
                )
            collection_name = collections[0]

        # Load collection and find artifact
        coll = collection_mgr.load_collection(collection_name)
        artifact = coll.find_artifact(artifact_name, artifact_type)

        if not artifact:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found in collection '{collection_name}'",
            )

        # --- Strategy: merge ---
        if request.strategy == "merge":
            return await _deploy_merge(
                artifact_id=artifact_id,
                artifact_name=artifact_name,
                artifact_type=artifact_type,
                artifact=artifact,
                collection_name=collection_name,
                collection_mgr=collection_mgr,
                artifact_mgr=artifact_mgr,
                project_path=project_path,
                settings=settings,
            )

        # --- Strategy: overwrite (default, existing behavior) ---
        from skillmeat.core.deployment import (
            DeploymentManager as RuntimeDeploymentManager,
        )

        deployment_mgr = RuntimeDeploymentManager(collection_mgr=collection_mgr)

        # Deploy artifact
        try:
            deployments = deployment_mgr.deploy_artifacts(
                artifact_names=[artifact_name],
                collection_name=collection_name,
                project_path=project_path,
                artifact_type=artifact_type,
                overwrite=request.overwrite,
                profile_id=request.deployment_profile_id,
                all_profiles=request.all_profiles,
            )

            if not deployments:
                # Deployment was skipped (likely user declined overwrite prompt)
                return ArtifactDeployResponse(
                    success=False,
                    message=f"Deployment of '{artifact_name}' was skipped",
                    artifact_name=artifact_name,
                    artifact_type=artifact_type.value,
                    error_message="Deployment cancelled or artifact not found",
                    strategy="overwrite",
                )

            deployment = deployments[0]
            deployed_profiles = sorted(
                {item.deployment_profile_id or "claude_code" for item in deployments}
            )

            # Determine deployed path
            deployed_path = (
                project_path
                / (deployment.profile_root_dir or ".claude")
                / deployment.artifact_path
            )
            logger.info(
                f"Artifact '{artifact_name}' deployed successfully to {deployed_path}"
            )

            # Refresh DB cache after successful deploy (non-blocking)
            _refresh_cache_safe(
                artifact_mgr,
                artifact_id,
                collection_name,
                deployment_profile_id=request.deployment_profile_id,
            )

            # VCS v2: record deployment version (non-fatal)
            try:
                from skillmeat.cache.models import get_session
                from skillmeat.core.version_service import VersionService

                _vs_session = get_session()
                try:
                    VersionService(_vs_session).record_mutation(
                        artifact_id=artifact_id,
                        change_origin="deployment",
                        content_hash=deployment.content_hash or "",
                        project_id=base64.b64encode(
                            str(project_path).encode()
                        ).decode(),
                    )
                finally:
                    _vs_session.close()
            except Exception:
                pass

            # Emit activity event — fire-and-forget, never blocks the response
            emit_activity_event(
                artifact_id=artifact_id,
                event_type="deploy",
                actor_id=getattr(auth_context, "user_id", None),
                auth_context=auth_context,
            )

            # Invalidate upstream fetch cache — project version has changed
            try:
                get_upstream_cache().invalidate_artifact(artifact_id)
            except Exception:
                pass  # Cache invalidation failure is non-critical

            return ArtifactDeployResponse(
                success=True,
                message=f"Artifact '{artifact_name}' deployed successfully",
                artifact_name=artifact_name,
                artifact_type=artifact_type.value,
                deployed_path=str(deployed_path),
                strategy="overwrite",
                deployment_profile_id=deployment.deployment_profile_id,
                deployed_profiles=deployed_profiles,
            )

        except ValueError as e:
            # Business logic error (e.g., artifact not found)
            logger.warning(f"Deployment failed for '{artifact_name}': {e}")
            return ArtifactDeployResponse(
                success=False,
                message=f"Deployment failed: {str(e)}",
                artifact_name=artifact_name,
                artifact_type=artifact_type.value,
                error_message=str(e),
                strategy="overwrite",
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deploying artifact '{artifact_id}': {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to deploy artifact: {str(e)}",
        )


# ---------------------------------------------------------------------------
# undeploy_artifact endpoint
# ---------------------------------------------------------------------------


@router.post(
    "/{artifact_id}/undeploy",
    response_model=ArtifactDeployResponse,
    summary="Undeploy artifact from project",
    description="Remove deployed artifact from project's .claude/ directory",
    responses={
        200: {"description": "Artifact undeployed successfully"},
        404: {"model": None, "description": "Artifact not found"},
        500: {"model": None, "description": "Internal server error"},
    },
)
async def undeploy_artifact(
    artifact_id: str,
    settings: SettingsDep,
    deployment_repo: DeploymentRepoDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    project_path: str = Body(..., embed=True, description="Project path"),
    _collection: Optional[str] = Query(
        None, description="Collection name (uses default if not specified)"
    ),
) -> ArtifactDeployResponse:
    """Remove deployed artifact from project.

    Removes the artifact from the project's .claude/ directory and updates
    the deployment tracking record (local edition) or removes the deployment
    record from the enterprise database (enterprise edition).

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        settings: API settings (controls edition-based branching)
        deployment_repo: Deployment repository (enterprise path only)
        token: Authentication token
        auth_context: Caller auth context
        artifact_mgr: Artifact manager (local edition only; None in enterprise)
        collection_mgr: Collection manager (local edition only; None in enterprise)
        project_path: Project directory path
        _collection: Optional collection name (unused, reserved for future use)

    Returns:
        Undeploy result

    Raises:
        HTTPException: If artifact not found or on error
    """
    logger.info(
        f"Undeploying artifact: {artifact_id} from {project_path} "
        f"(edition={settings.edition})"
    )

    # -----------------------------------------------------------------------
    # Enterprise path
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        try:
            removed = deployment_repo.undeploy(id=artifact_id)
            if not removed:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Deployment record not found for artifact '{artifact_id}'",
                )

            try:
                artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            except ValueError:
                artifact_name = artifact_id
                artifact_type_str = "unknown"

            logger.info(
                f"Enterprise undeploy: artifact '{artifact_id}' removed from deployment records"
            )

            emit_activity_event(
                artifact_id=artifact_id,
                event_type="undeploy",
                actor_id=getattr(auth_context, "user_id", None),
                auth_context=auth_context,
            )

            return ArtifactDeployResponse(
                success=True,
                message=f"Artifact '{artifact_name}' undeployed successfully",
                artifact_name=artifact_name,
                artifact_type=artifact_type_str,
            )

        except HTTPException:
            raise
        except Exception as exc:
            logger.error(
                f"Enterprise undeploy error for '{artifact_id}': {exc}", exc_info=True
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to undeploy artifact: {str(exc)}",
            )

    # -----------------------------------------------------------------------
    # Local path — verbatim copy from _legacy.py undeploy_artifact
    # -----------------------------------------------------------------------
    if collection_mgr is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Collection manager unavailable",
        )

    _ = token  # used by legacy auth middleware; kept for signature compat

    try:
        logger.info(f"Undeploying artifact: {artifact_id} from {project_path}")

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Validate project path
        proj_path = PathLib(project_path)
        if not proj_path.exists():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Project path does not exist: {project_path}",
            )

        # Create deployment manager
        from skillmeat.core.deployment import DeploymentManager

        deployment_mgr = DeploymentManager(collection_mgr=collection_mgr)

        # Undeploy artifact
        try:
            deployment_mgr.undeploy(
                artifact_name=artifact_name,
                artifact_type=artifact_type,
                project_path=proj_path,
            )

            logger.info(f"Artifact '{artifact_name}' undeployed successfully")

            # Emit activity event — fire-and-forget, never blocks the response
            emit_activity_event(
                artifact_id=artifact_id,
                event_type="undeploy",
                actor_id=getattr(auth_context, "user_id", None),
                auth_context=auth_context,
            )

            return ArtifactDeployResponse(
                success=True,
                message=f"Artifact '{artifact_name}' undeployed successfully",
                artifact_name=artifact_name,
                artifact_type=artifact_type.value,
            )

        except ValueError as e:
            # Business logic error (e.g., artifact not deployed)
            logger.warning(f"Undeploy failed for '{artifact_name}': {e}")
            return ArtifactDeployResponse(
                success=False,
                message=f"Undeploy failed: {str(e)}",
                artifact_name=artifact_name,
                artifact_type=artifact_type.value,
                error_message=str(e),
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error undeploying artifact '{artifact_id}': {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to undeploy artifact: {str(e)}",
        )


# ---------------------------------------------------------------------------
# sync_artifact endpoint
# ---------------------------------------------------------------------------


@router.post(
    "/{artifact_id}/sync",
    response_model=ArtifactSyncResponse,
    summary="Sync artifact from project to collection",
    description="Pull changes from project back to collection, with conflict resolution",
    responses={
        200: {"description": "Artifact synced successfully"},
        400: {"model": None, "description": "Invalid request"},
        404: {"model": None, "description": "Artifact not found"},
        500: {"model": None, "description": "Internal server error"},
    },
)
async def sync_artifact(
    artifact_id: str,
    request: ArtifactSyncRequest,
    settings: SettingsDep,
    deployment_repo: DeploymentRepoDep,
    collection_repo: CollectionRepoDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    sync_mgr: SyncManagerOptDep = None,
    collection: Optional[str] = Query(
        None, description="Collection name (uses default if not specified)"
    ),
) -> ArtifactSyncResponse:
    """Sync artifact from project to collection.

    Pulls changes from a deployed artifact in a project back to the collection.
    This is useful for capturing local modifications made to deployed artifacts.

    In enterprise edition, updates the sync metadata (``synced_at``,
    ``local_modifications``) for the artifact in the DB without touching the
    filesystem — filesystem sync is a local-only operation.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        request: Sync request with project_path, force flag, and strategy
        settings: API settings (controls edition-based branching)
        artifact_repo: Artifact repository (enterprise path — updates sync metadata)
        collection_repo: Collection repository for name resolution (local path)
        token: Authentication token
        auth_context: Caller auth context
        artifact_mgr: Artifact manager (local edition only; None in enterprise)
        collection_mgr: Collection manager (local edition only; None in enterprise)
        sync_mgr: Sync manager (local edition only; None in enterprise)
        collection: Optional collection name

    Returns:
        Sync result with conflicts and updated version info

    Raises:
        HTTPException: If artifact not found, validation fails, or on error
    """
    logger.info(
        f"Syncing artifact: {artifact_id} from {request.project_path or 'upstream'} "
        f"(edition={settings.edition}, collection={collection})"
    )

    # -----------------------------------------------------------------------
    # Enterprise path — update sync metadata in DB only
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        try:
            try:
                artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid artifact ID format. Expected 'type:name'",
                )

            from datetime import datetime, timezone

            synced_at = datetime.now(timezone.utc)
            project_path_str = request.project_path or ""
            project_name = PathLib(project_path_str).name if project_path_str else ""

            # Record the sync event in the artifact repository's deployment cache.
            # This does NOT perform any filesystem operations — enterprise sync
            # metadata lives exclusively in the DB.
            updated = deployment_repo.sync_deployment_cache(
                artifact_id=artifact_id,
                project_path=project_path_str,
                project_name=project_name,
                deployed_at=synced_at,
                local_modifications=True,
            )

            logger.info(
                f"Enterprise sync: artifact '{artifact_id}' sync metadata updated "
                f"(project={project_path_str}, updated={updated})"
            )

            emit_activity_event(
                artifact_id=artifact_id,
                event_type="sync",
                actor_id=getattr(auth_context, "user_id", None),
                auth_context=auth_context,
            )

            return ArtifactSyncResponse(
                success=True,
                message=f"Artifact '{artifact_name}' sync metadata updated",
                artifact_name=artifact_name,
                artifact_type=artifact_type_str,
                conflicts=None,
                updated_version=None,
                synced_files_count=None,
            )

        except HTTPException:
            raise
        except Exception as exc:
            logger.error(
                f"Enterprise sync error for '{artifact_id}': {exc}", exc_info=True
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to sync artifact: {str(exc)}",
            )

    # -----------------------------------------------------------------------
    # Local path — verbatim copy from _legacy.py sync_artifact
    # -----------------------------------------------------------------------
    if collection_mgr is None or artifact_mgr is None or sync_mgr is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Collection/artifact/sync manager unavailable",
        )

    _ = token  # used by legacy auth middleware; kept for signature compat

    try:
        logger.info(
            f"Syncing artifact: {artifact_id} from {request.project_path or 'upstream'} (collection={collection})"
        )

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Handle upstream sync (no project_path provided)
        if not request.project_path:
            logger.info(f"Syncing {artifact_id} from upstream source")

            # Get collection name (use provided or default)
            collection_name = collection or collection_mgr.get_active_collection_name()

            # Fetch update from upstream
            try:
                fetch_result = artifact_mgr.fetch_update(
                    artifact_name=artifact_name,
                    artifact_type=artifact_type,
                    collection_name=collection_name,
                )
            except Exception as e:
                logger.error(
                    f"Failed to fetch update for '{artifact_id}': {e}", exc_info=True
                )
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to fetch update from upstream: {str(e)}",
                )

            # Check if fetch was successful
            if fetch_result.error:
                return ArtifactSyncResponse(
                    success=False,
                    message=f"Failed to fetch update: {fetch_result.error}",
                    artifact_name=artifact_name,
                    artifact_type=artifact_type.value,
                    conflicts=None,
                    updated_version=None,
                    synced_files_count=None,
                )

            # If no update available, return success with message
            if not fetch_result.has_update:
                return ArtifactSyncResponse(
                    success=True,
                    message=f"Artifact '{artifact_name}' is already up to date",
                    artifact_name=artifact_name,
                    artifact_type=artifact_type.value,
                    conflicts=None,
                    updated_version=(
                        fetch_result.artifact.metadata.version
                        if fetch_result.artifact and fetch_result.artifact.metadata
                        else None
                    ),
                    synced_files_count=0,
                )

            # Map request strategy
            # "theirs" = take upstream -> "overwrite"
            # "ours" = keep local -> skip
            # "manual" = preserve conflicts -> "merge"
            strategy_map = {
                "theirs": "overwrite",
                "ours": "skip",
                "manual": "merge",
            }
            apply_strategy = strategy_map.get(request.strategy, "overwrite")

            # If strategy is "ours", skip the update
            if apply_strategy == "skip":
                logger.info(
                    f"Strategy 'ours' selected - keeping local version of '{artifact_id}'"
                )
                return ArtifactSyncResponse(
                    success=True,
                    message=f"Local version of '{artifact_name}' preserved (strategy: ours)",
                    artifact_name=artifact_name,
                    artifact_type=artifact_type.value,
                    conflicts=None,
                    updated_version=(
                        fetch_result.artifact.metadata.version
                        if fetch_result.artifact and fetch_result.artifact.metadata
                        else None
                    ),
                    synced_files_count=0,
                )

            # Apply the update
            try:
                update_result = artifact_mgr.apply_update_strategy(
                    fetch_result=fetch_result,
                    strategy=apply_strategy,
                    interactive=False,
                    auto_resolve="theirs" if apply_strategy == "overwrite" else "abort",
                    collection_name=collection_name,
                )
            except Exception as e:
                logger.error(
                    f"Failed to apply update for '{artifact_id}': {e}", exc_info=True
                )
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to apply update: {str(e)}",
                )

            # Count synced files
            synced_files_count = None
            if update_result.updated and fetch_result.artifact:
                try:
                    collection_path = collection_mgr.config.get_collection_path(
                        collection_name
                    )
                    artifact_path = collection_path / fetch_result.artifact.path
                    if artifact_path.exists():
                        if artifact_path.is_dir():
                            synced_files_count = len(
                                [f for f in artifact_path.rglob("*") if f.is_file()]
                            )
                        else:
                            synced_files_count = 1
                except Exception:
                    pass  # Non-critical, leave as None

            # Refresh DB cache after filesystem mutation (write-through pattern)
            if update_result.updated:
                try:
                    db_session = get_session()
                    try:
                        from skillmeat.api.services import (
                            refresh_single_artifact_cache as _rsc,
                        )

                        _rsc(
                            db_session,
                            artifact_mgr,
                            artifact_id,
                            collection_name,
                        )
                        db_session.commit()
                    except Exception:
                        db_session.rollback()
                        raise
                    finally:
                        db_session.close()
                except Exception as e:
                    logger.warning(f"Cache refresh after upstream sync failed: {e}")

                # Record version for GitHub upstream update (non-fatal)
                try:
                    from skillmeat.core.version_service import VersionService

                    _new_hash = update_result.new_version or ""
                    if fetch_result.artifact and not _new_hash:
                        try:
                            from skillmeat.core.sync import SyncManager as _SM

                            _coll_path = collection_mgr.config.get_collection_path(
                                collection_name
                            )
                            _art_path = _coll_path / fetch_result.artifact.path
                            _new_hash = _SM()._compute_content_hash(_art_path)
                        except Exception:
                            pass
                    _vs_session = get_session()
                    try:
                        vs = VersionService(_vs_session)
                        vs.record_mutation(
                            artifact_id=artifact_id,
                            change_origin="github_update",
                            content_hash=_new_hash,
                        )
                    finally:
                        _vs_session.close()
                except Exception:
                    pass

            logger.info(
                f"Upstream sync for '{artifact_name}' completed: "
                f"updated={update_result.updated}, status={update_result.status}"
            )

            return ArtifactSyncResponse(
                success=update_result.updated,
                message=f"Artifact '{artifact_name}' synced from upstream: {update_result.status}",
                artifact_name=artifact_name,
                artifact_type=artifact_type.value,
                conflicts=None,
                updated_version=update_result.new_version,
                synced_files_count=synced_files_count,
            )

        # Validate project path
        project_path = PathLib(request.project_path)
        if not project_path.exists():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Project path does not exist: {request.project_path}",
            )

        # Validate strategy
        valid_strategies = {"theirs", "ours", "manual"}
        if request.strategy not in valid_strategies:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid strategy '{request.strategy}'. Must be one of: {', '.join(valid_strategies)}",
            )

        # Map request strategy to SyncManager strategy
        strategy_map = {
            "theirs": "overwrite",
            "ours": "overwrite",
            "manual": "merge",
        }
        sync_strategy = strategy_map[request.strategy]

        # Check for deployment metadata using DeploymentTracker (public API)
        from skillmeat.storage.deployment import DeploymentTracker

        deployments = DeploymentTracker.read_deployments(project_path)
        target_deployment = None
        collection_name = collection

        for deployment in deployments:
            if (
                deployment.artifact_name == artifact_name
                and deployment.artifact_type == artifact_type.value
            ):
                target_deployment = deployment
                break

        # Backward-compatibility: support legacy sync metadata loaders in tests
        if target_deployment is None and hasattr(sync_mgr, "_load_deployment_metadata"):
            legacy_metadata = sync_mgr._load_deployment_metadata(project_path)
            if legacy_metadata:
                if not collection_name:
                    collection_name = getattr(legacy_metadata, "collection", None)
                for deployed in getattr(legacy_metadata, "artifacts", []) or []:
                    if (
                        deployed.name == artifact_name
                        and deployed.artifact_type == artifact_type.value
                    ):
                        target_deployment = deployed
                        break

        if target_deployment is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not deployed in project",
            )

        if not collection_name:
            collection_name = getattr(target_deployment, "from_collection", "default")

        # Verify collection exists (resolve UUID if needed)
        resolved = resolve_collection_name(
            collection_name, collection_mgr, collection_repo=collection_repo
        )
        if not resolved:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Collection '{collection_name}' not found",
            )
        collection_name = resolved

        # Load collection and verify artifact exists
        coll = collection_mgr.load_collection(collection_name)
        artifact = coll.find_artifact(artifact_name, artifact_type)

        if not artifact:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found in project deployment metadata",
            )

        # Perform sync using sync_from_project
        try:
            sync_result = sync_mgr.sync_from_project(
                project_path=project_path,
                artifact_names=[artifact_name],
                strategy=sync_strategy,
                dry_run=False,
                interactive=False,
            )

            # Extract conflicts if any
            conflicts_list = None
            if sync_result.conflicts:
                conflicts_list = [
                    ConflictInfo(file_path=conflict_file, conflict_type="modified")
                    for conflict_result in sync_result.conflicts
                    for conflict_file in (
                        conflict_result.conflict_files
                        if hasattr(conflict_result, "conflict_files")
                        else []
                    )
                ]

            # Determine success based on sync result status
            success = sync_result.status in ("success", "partial")

            # Get updated version from artifact if available
            updated_version = None
            if success:
                updated_coll = collection_mgr.load_collection(collection_name)
                updated_artifact = updated_coll.find_artifact(
                    artifact_name, artifact_type
                )
                if updated_artifact and updated_artifact.metadata:
                    updated_version = updated_artifact.metadata.version

            # Count synced files (approximate based on artifact path)
            synced_files_count = None
            if success and artifact_name in sync_result.artifacts_synced:
                collection_path = collection_mgr.config.get_collection_path(
                    collection_name
                )
                artifact_path = collection_path / artifact.path
                if artifact_path.exists():
                    synced_files_count = sum(
                        1
                        for _ in iter_artifact_files(
                            artifact_path, set(settings.diff_exclude_dirs)
                        )
                    )

            logger.info(
                f"Artifact '{artifact_name}' sync completed: status={sync_result.status}, "
                f"conflicts={len(conflicts_list) if conflicts_list else 0}"
            )

            # Refresh DB cache after successful project sync (non-blocking)
            if success:
                _refresh_cache_safe(artifact_mgr, artifact_id, collection_name)

                # Emit activity event — fire-and-forget, never blocks the response
                emit_activity_event(
                    artifact_id=artifact_id,
                    event_type="sync",
                    actor_id=getattr(auth_context, "user_id", None),
                    auth_context=auth_context,
                )

                # Invalidate upstream fetch cache — collection version has changed
                try:
                    get_upstream_cache().invalidate_artifact(artifact_id)
                except Exception:
                    pass  # Cache invalidation failure is non-critical

            return ArtifactSyncResponse(
                success=success,
                message=sync_result.message,
                artifact_name=artifact_name,
                artifact_type=artifact_type.value,
                conflicts=conflicts_list if conflicts_list else None,
                updated_version=updated_version,
                synced_files_count=synced_files_count,
            )

        except ValueError as e:
            # Business logic error (e.g., sync preconditions not met)
            logger.warning(f"Sync failed for '{artifact_name}': {e}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error syncing artifact '{artifact_id}': {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to sync artifact: {str(e)}",
        )
