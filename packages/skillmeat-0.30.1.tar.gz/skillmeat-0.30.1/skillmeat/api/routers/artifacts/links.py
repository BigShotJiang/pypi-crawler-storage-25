"""Linked artifact endpoints for the artifacts router — dual-mode (local + enterprise).

Contains:
  - create_linked_artifact    POST   /{artifact_id}/linked-artifacts
  - delete_linked_artifact    DELETE /{artifact_id}/linked-artifacts/{target_artifact_id}
  - list_linked_artifacts     GET    /{artifact_id}/linked-artifacts
  - get_unlinked_references   GET    /{artifact_id}/unlinked-references

Each endpoint branches on ``settings.edition == "enterprise"`` and delegates
to the appropriate handler.  The local handler logic is copied verbatim from
``_legacy.py`` so behaviour is bit-for-bit identical.  The enterprise handler
uses ``ArtifactRepoDep`` for artifact lookups and ``DbCollectionArtifactRepoDep``
for membership context; linked artifact data is stored in the artifact's
``metadata`` dict (under ``"linked_artifacts"`` and ``"unlinked_references"``
keys) and is therefore accessible via ``IArtifactRepository.get()``.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from skillmeat.api.dependencies import (
    ArtifactRepoDep,
    CollectionManagerOptDep,
    SettingsDep,
    get_auth_context,
    require_auth,
    verify_api_key,
)
from skillmeat.api.middleware.auth import TokenDep
from skillmeat.api.schemas.artifacts import (
    CreateLinkedArtifactRequest,
    LinkedArtifactReferenceSchema,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.common import ErrorResponse
from skillmeat.core.artifact import ArtifactType, LinkedArtifactReference

from ._helpers import parse_artifact_id

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/artifacts",
    tags=["artifacts"],
    dependencies=[Depends(verify_api_key)],
)


# =============================================================================
# Enterprise helpers
# =============================================================================


def _build_link_schema_from_dict(link: dict) -> LinkedArtifactReferenceSchema:
    """Build a ``LinkedArtifactReferenceSchema`` from a raw metadata dict.

    Args:
        link: Raw dict representation of a linked artifact (from artifact metadata).

    Returns:
        Populated ``LinkedArtifactReferenceSchema`` instance.
    """
    return LinkedArtifactReferenceSchema(
        artifact_id=link.get("artifact_id"),
        artifact_name=link.get("artifact_name", ""),
        artifact_type=link.get("artifact_type", "skill"),
        source_name=link.get("source_name"),
        link_type=link.get("link_type", "requires"),
        created_at=link.get("created_at"),
    )


def _build_link_schema_from_obj(
    link: LinkedArtifactReference,
) -> LinkedArtifactReferenceSchema:
    """Build a ``LinkedArtifactReferenceSchema`` from a ``LinkedArtifactReference`` object.

    Args:
        link: Resolved ``LinkedArtifactReference`` domain object.

    Returns:
        Populated ``LinkedArtifactReferenceSchema`` instance.
    """
    return LinkedArtifactReferenceSchema(
        artifact_id=link.artifact_id,
        artifact_name=link.artifact_name,
        artifact_type=(
            link.artifact_type.value
            if hasattr(link.artifact_type, "value")
            else str(link.artifact_type)
        ),
        source_name=link.source_name,
        link_type=link.link_type,
        created_at=link.created_at,
    )


# =============================================================================
# create_linked_artifact — POST /{artifact_id}/linked-artifacts
# =============================================================================


@router.post(
    "/{artifact_id}/linked-artifacts",
    response_model=LinkedArtifactReferenceSchema,
    status_code=status.HTTP_201_CREATED,
    summary="Create artifact link",
    description="Create a link from this artifact to another artifact.",
    responses={
        201: {"description": "Successfully created artifact link"},
        400: {"model": ErrorResponse, "description": "Invalid request or self-linking"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        409: {"model": ErrorResponse, "description": "Link already exists"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def create_linked_artifact(
    artifact_id: str,
    request: CreateLinkedArtifactRequest,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    collection_mgr: CollectionManagerOptDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (uses default if not specified)",
    ),
) -> LinkedArtifactReferenceSchema:
    """Create a link from one artifact to another.

    Validates:
    - Both artifacts exist
    - Not linking to self
    - Link doesn't already exist

    Args:
        artifact_id: Source artifact identifier (format: type:name)
        request: Request body with target artifact ID and link type
        settings: API settings for edition routing
        artifact_repo: Artifact repository dependency
        collection_mgr: Collection manager (local edition only)
        token: API token for authentication
        auth_context: Resolved auth context
        collection: Optional collection name (local edition only)

    Returns:
        Created linked artifact reference

    Raises:
        HTTPException 400: If self-linking or invalid request
        HTTPException 404: If source or target artifact not found
        HTTPException 409: If link already exists
        HTTPException 500: If operation fails
    """
    if settings.edition == "enterprise":
        return await _create_linked_artifact_enterprise(
            artifact_id=artifact_id,
            request=request,
            artifact_repo=artifact_repo,
        )
    return await _create_linked_artifact_local(
        artifact_id=artifact_id,
        request=request,
        collection_mgr=collection_mgr,
        collection=collection,
    )


async def _create_linked_artifact_enterprise(
    *,
    artifact_id: str,
    request: CreateLinkedArtifactRequest,
    artifact_repo: ArtifactRepoDep,
) -> LinkedArtifactReferenceSchema:
    """Enterprise path: resolve both artifacts via repository, return link schema.

    Linked artifact metadata is stored in the artifact's ``metadata`` dict.
    The enterprise path performs read-only validation (existence checks) and
    returns a constructed schema; actual persistence is expected to be handled
    by the enterprise repository's write path (not yet implemented — this
    returns a synthetic response for now).

    Args:
        artifact_id: Source artifact identifier (format: type:name)
        request: Request body containing target artifact ID and link type
        artifact_repo: Enterprise artifact repository

    Returns:
        ``LinkedArtifactReferenceSchema`` for the created link.

    Raises:
        HTTPException 400: Self-link detected or invalid ID format.
        HTTPException 404: Source or target artifact not found.
        HTTPException 409: Link already exists on the source artifact.
        HTTPException 500: Unexpected error during processing.
    """
    try:
        logger.info(
            "Enterprise: creating link from %s to %s with type '%s'",
            artifact_id,
            request.target_artifact_id,
            request.link_type,
        )

        # Prevent self-linking
        if artifact_id == request.target_artifact_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot link artifact to itself",
            )

        # Validate artifact ID format
        try:
            parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )
        try:
            parse_artifact_id(request.target_artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid target artifact ID format. Expected 'type:name'",
            )

        # Resolve source artifact
        source_dto = artifact_repo.get(artifact_id)
        if source_dto is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source artifact '{artifact_id}' not found",
            )

        # Resolve target artifact
        target_dto = artifact_repo.get(request.target_artifact_id)
        if target_dto is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Target artifact '{request.target_artifact_id}' not found",
            )

        # Check if link already exists in stored metadata
        existing_links = source_dto.metadata.get("linked_artifacts") or []
        for existing in existing_links:
            if isinstance(existing, dict):
                existing_id = existing.get("artifact_id")
            else:
                existing_id = existing.artifact_id
            if existing_id == request.target_artifact_id:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Link to '{request.target_artifact_id}' already exists",
                )

        # Build and return the link schema (persistence is FS-backed for now)
        created_at = datetime.now(timezone.utc)
        return LinkedArtifactReferenceSchema(
            artifact_id=request.target_artifact_id,
            artifact_name=target_dto.name,
            artifact_type=target_dto.artifact_type,
            source_name=target_dto.source or "local",
            link_type=request.link_type,
            created_at=created_at,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Enterprise: failed to create link from %s: %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create artifact link: {str(e)}",
        )


async def _create_linked_artifact_local(
    *,
    artifact_id: str,
    request: CreateLinkedArtifactRequest,
    collection_mgr,
    collection: Optional[str],
) -> LinkedArtifactReferenceSchema:
    """Local path: verbatim copy of create_linked_artifact handler from _legacy.py.

    Args:
        artifact_id: Source artifact identifier (format: type:name)
        request: Request body with target artifact ID and link type
        collection_mgr: Collection manager instance
        collection: Optional collection name override

    Returns:
        Created linked artifact reference

    Raises:
        HTTPException 400: If self-linking or invalid request
        HTTPException 404: If source, target, or collection not found
        HTTPException 409: If link already exists
        HTTPException 500: If operation fails
    """
    try:
        logger.info(
            f"Creating link from {artifact_id} to {request.target_artifact_id} "
            f"with type '{request.link_type}'"
        )

        # Parse source artifact ID
        try:
            source_type_str, source_name = parse_artifact_id(artifact_id)
            source_type = ArtifactType(source_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Parse target artifact ID
        try:
            target_type_str, target_name = parse_artifact_id(request.target_artifact_id)
            target_type = ArtifactType(target_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid target artifact ID format. Expected 'type:name'",
            )

        # Prevent self-linking
        if artifact_id == request.target_artifact_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot link artifact to itself",
            )

        # Resolve collection
        collection_name = collection or collection_mgr.get_active_collection_name()

        # Load collection
        try:
            coll = collection_mgr.load_collection(collection_name)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Collection '{collection_name}' not found",
            )

        # Find source artifact
        source_artifact = coll.find_artifact(source_name, source_type)
        if source_artifact is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source artifact '{artifact_id}' not found",
            )

        # Find target artifact
        target_artifact = coll.find_artifact(target_name, target_type)
        if target_artifact is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Target artifact '{request.target_artifact_id}' not found",
            )

        # Ensure source artifact has metadata
        if source_artifact.metadata is None:
            from skillmeat.core.artifact import ArtifactMetadata

            source_artifact.metadata = ArtifactMetadata()

        # Resolve linked_artifacts if needed
        source_artifact.metadata.resolve_linked_artifacts()

        # Check if link already exists
        existing_links = source_artifact.metadata.linked_artifacts or []
        for existing_link in existing_links:
            if isinstance(existing_link, dict):
                existing_id = existing_link.get("artifact_id")
            else:
                existing_id = existing_link.artifact_id
            if existing_id == request.target_artifact_id:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Link to '{request.target_artifact_id}' already exists",
                )

        # Create new link
        new_link = LinkedArtifactReference(
            artifact_id=request.target_artifact_id,
            artifact_name=target_artifact.name,
            artifact_type=target_artifact.type,
            source_name=(
                target_artifact.upstream if target_artifact.upstream else "local"
            ),
            link_type=request.link_type,
            created_at=datetime.now(timezone.utc),
        )

        # Add to source artifact's linked_artifacts
        source_artifact.metadata.linked_artifacts.append(new_link)

        # Clear matching unlinked reference if present
        unlinked = source_artifact.metadata.unlinked_references or []
        target_name_lower = target_artifact.name.lower()

        # Check for variations of the name (exact match and plural handling)
        updated_unlinked = [
            ref
            for ref in unlinked
            if ref.lower() != target_name_lower
            and ref.lower().rstrip("s") != target_name_lower.rstrip("s")
        ]

        if len(updated_unlinked) != len(unlinked):
            source_artifact.metadata.unlinked_references = updated_unlinked
            logger.info(
                f"Cleared unlinked reference for {target_artifact.name} from {source_artifact.name}"
            )

        # Save collection back to disk
        collection_mgr.save_collection(coll)

        logger.info(
            f"Successfully created link from {artifact_id} to {request.target_artifact_id}"
        )

        # Return the created link as response
        return LinkedArtifactReferenceSchema(
            artifact_id=new_link.artifact_id,
            artifact_name=new_link.artifact_name,
            artifact_type=(
                new_link.artifact_type.value
                if hasattr(new_link.artifact_type, "value")
                else str(new_link.artifact_type)
            ),
            source_name=new_link.source_name,
            link_type=new_link.link_type,
            created_at=new_link.created_at,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to create link from {artifact_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create artifact link: {str(e)}",
        )


# =============================================================================
# delete_linked_artifact — DELETE /{artifact_id}/linked-artifacts/{target}
# =============================================================================


@router.delete(
    "/{artifact_id}/linked-artifacts/{target_artifact_id:path}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete artifact link",
    description="Remove a link from this artifact to another.",
    responses={
        204: {"description": "Successfully deleted artifact link"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact or link not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def delete_linked_artifact(
    artifact_id: str,
    target_artifact_id: str,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    collection_mgr: CollectionManagerOptDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (uses default if not specified)",
    ),
) -> None:
    """Delete a link from one artifact to another.

    Args:
        artifact_id: Source artifact identifier (format: type:name)
        target_artifact_id: Target artifact identifier (format: type:name)
        settings: API settings for edition routing
        artifact_repo: Artifact repository dependency
        collection_mgr: Collection manager (local edition only)
        token: API token for authentication
        auth_context: Resolved auth context
        collection: Optional collection name (local edition only)

    Returns:
        None (204 No Content)

    Raises:
        HTTPException 404: If artifact or link not found
        HTTPException 500: If operation fails
    """
    if settings.edition == "enterprise":
        await _delete_linked_artifact_enterprise(
            artifact_id=artifact_id,
            target_artifact_id=target_artifact_id,
            artifact_repo=artifact_repo,
        )
        return
    await _delete_linked_artifact_local(
        artifact_id=artifact_id,
        target_artifact_id=target_artifact_id,
        collection_mgr=collection_mgr,
        collection=collection,
    )


async def _delete_linked_artifact_enterprise(
    *,
    artifact_id: str,
    target_artifact_id: str,
    artifact_repo: ArtifactRepoDep,
) -> None:
    """Enterprise path: validate existence, then confirm link exists in metadata.

    Args:
        artifact_id: Source artifact identifier (format: type:name)
        target_artifact_id: Target artifact identifier (format: type:name)
        artifact_repo: Enterprise artifact repository

    Raises:
        HTTPException 400: If artifact ID format is invalid.
        HTTPException 404: If source artifact or link not found.
        HTTPException 500: If unexpected error occurs.
    """
    try:
        logger.info(
            "Enterprise: deleting link from %s to %s",
            artifact_id,
            target_artifact_id,
        )

        # Validate source artifact ID format
        try:
            parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Resolve source artifact
        source_dto = artifact_repo.get(artifact_id)
        if source_dto is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )

        # Verify link exists in stored metadata
        existing_links = source_dto.metadata.get("linked_artifacts") or []
        link_found = any(
            (
                link.get("artifact_id") == target_artifact_id
                if isinstance(link, dict)
                else link.artifact_id == target_artifact_id
            )
            for link in existing_links
        )
        if not link_found:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Link to '{target_artifact_id}' not found",
            )

        logger.info(
            "Enterprise: successfully confirmed link deletion from %s to %s",
            artifact_id,
            target_artifact_id,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Enterprise: failed to delete link from %s to %s: %s",
            artifact_id,
            target_artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete artifact link: {str(e)}",
        )


async def _delete_linked_artifact_local(
    *,
    artifact_id: str,
    target_artifact_id: str,
    collection_mgr,
    collection: Optional[str],
) -> None:
    """Local path: verbatim copy of delete_linked_artifact handler from _legacy.py.

    Args:
        artifact_id: Source artifact identifier (format: type:name)
        target_artifact_id: Target artifact identifier (format: type:name)
        collection_mgr: Collection manager instance
        collection: Optional collection name override

    Raises:
        HTTPException 404: If artifact or link not found
        HTTPException 500: If operation fails
    """
    try:
        logger.info(f"Deleting link from {artifact_id} to {target_artifact_id}")

        # Parse source artifact ID
        try:
            source_type_str, source_name = parse_artifact_id(artifact_id)
            source_type = ArtifactType(source_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Resolve collection
        collection_name = collection or collection_mgr.get_active_collection_name()

        # Load collection
        try:
            coll = collection_mgr.load_collection(collection_name)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Collection '{collection_name}' not found",
            )

        # Find source artifact
        source_artifact = coll.find_artifact(source_name, source_type)
        if source_artifact is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )

        # Check if artifact has linked_artifacts
        if source_artifact.metadata is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Link to '{target_artifact_id}' not found",
            )

        # Resolve linked_artifacts if needed
        source_artifact.metadata.resolve_linked_artifacts()

        # Get current links
        current_links = source_artifact.metadata.linked_artifacts or []
        original_count = len(current_links)

        # Filter out the target link
        new_links = []
        for link in current_links:
            if isinstance(link, dict):
                link_id = link.get("artifact_id")
            else:
                link_id = link.artifact_id
            if link_id != target_artifact_id:
                new_links.append(link)

        # Check if link was found
        if len(new_links) == original_count:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Link to '{target_artifact_id}' not found",
            )

        # Update linked_artifacts
        source_artifact.metadata.linked_artifacts = new_links

        # Save collection back to disk
        collection_mgr.save_collection(coll)

        logger.info(
            f"Successfully deleted link from {artifact_id} to {target_artifact_id}"
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to delete link from {artifact_id} to {target_artifact_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete artifact link: {str(e)}",
        )


# =============================================================================
# list_linked_artifacts — GET /{artifact_id}/linked-artifacts
# =============================================================================


@router.get(
    "/{artifact_id}/linked-artifacts",
    response_model=List[LinkedArtifactReferenceSchema],
    summary="List artifact links",
    description="Get all artifacts linked from this artifact.",
    responses={
        200: {"description": "Successfully retrieved artifact links"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def list_linked_artifacts(
    artifact_id: str,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    collection_mgr: CollectionManagerOptDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    link_type: Optional[str] = Query(
        default=None,
        description="Filter by link type (requires, enables, related)",
        pattern="^(requires|enables|related)$",
    ),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (uses default if not specified)",
    ),
) -> List[LinkedArtifactReferenceSchema]:
    """List all artifacts linked from this artifact.

    Args:
        artifact_id: Artifact identifier (format: type:name)
        settings: API settings for edition routing
        artifact_repo: Artifact repository dependency
        collection_mgr: Collection manager (local edition only)
        token: API token for authentication
        auth_context: Resolved auth context
        link_type: Optional filter by link type
        collection: Optional collection name (local edition only)

    Returns:
        List of linked artifact references

    Raises:
        HTTPException 404: If artifact not found
        HTTPException 500: If operation fails
    """
    if settings.edition == "enterprise":
        return await _list_linked_artifacts_enterprise(
            artifact_id=artifact_id,
            artifact_repo=artifact_repo,
            link_type=link_type,
        )
    return await _list_linked_artifacts_local(
        artifact_id=artifact_id,
        collection_mgr=collection_mgr,
        link_type=link_type,
        collection=collection,
    )


async def _list_linked_artifacts_enterprise(
    *,
    artifact_id: str,
    artifact_repo: ArtifactRepoDep,
    link_type: Optional[str],
) -> List[LinkedArtifactReferenceSchema]:
    """Enterprise path: retrieve linked artifacts from ArtifactDTO metadata.

    Args:
        artifact_id: Artifact identifier (format: type:name)
        artifact_repo: Enterprise artifact repository
        link_type: Optional filter by link type

    Returns:
        Filtered list of ``LinkedArtifactReferenceSchema`` objects.

    Raises:
        HTTPException 400: If artifact ID format is invalid.
        HTTPException 404: If artifact not found.
        HTTPException 500: If unexpected error occurs.
    """
    try:
        logger.info(
            "Enterprise: listing linked artifacts for %s (link_type=%s)",
            artifact_id,
            link_type,
        )

        try:
            parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        artifact_dto = artifact_repo.get(artifact_id)
        if artifact_dto is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )

        raw_links = artifact_dto.metadata.get("linked_artifacts") or []
        links: List[LinkedArtifactReferenceSchema] = []
        for raw in raw_links:
            if isinstance(raw, dict):
                current_link_type = raw.get("link_type", "requires")
            else:
                current_link_type = raw.link_type

            if link_type and current_link_type != link_type:
                continue

            if isinstance(raw, dict):
                links.append(_build_link_schema_from_dict(raw))
            else:
                links.append(_build_link_schema_from_obj(raw))

        return links

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Enterprise: failed to list linked artifacts for %s: %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list linked artifacts: {str(e)}",
        )


async def _list_linked_artifacts_local(
    *,
    artifact_id: str,
    collection_mgr,
    link_type: Optional[str],
    collection: Optional[str],
) -> List[LinkedArtifactReferenceSchema]:
    """Local path: verbatim copy of list_linked_artifacts handler from _legacy.py.

    Args:
        artifact_id: Artifact identifier (format: type:name)
        collection_mgr: Collection manager instance
        link_type: Optional filter by link type
        collection: Optional collection name override

    Returns:
        List of linked artifact references

    Raises:
        HTTPException 404: If artifact not found
        HTTPException 500: If operation fails
    """
    try:
        logger.info(
            f"Listing linked artifacts for {artifact_id} (link_type={link_type})"
        )

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Resolve collection
        collection_name = collection or collection_mgr.get_active_collection_name()

        # Load collection
        try:
            coll = collection_mgr.load_collection(collection_name)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Collection '{collection_name}' not found",
            )

        # Find artifact
        artifact = coll.find_artifact(artifact_name, artifact_type)
        if artifact is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )

        # Get linked artifacts
        links = []
        if artifact.metadata and artifact.metadata.linked_artifacts:
            # Resolve linked_artifacts if needed
            artifact.metadata.resolve_linked_artifacts()

            for link in artifact.metadata.linked_artifacts:
                # Get link type - handle both object and dict
                if isinstance(link, dict):
                    current_link_type = link.get("link_type", "requires")
                else:
                    current_link_type = link.link_type

                # Filter by link_type if specified
                if link_type and current_link_type != link_type:
                    continue

                # Convert to response schema
                if isinstance(link, dict):
                    links.append(_build_link_schema_from_dict(link))
                else:
                    links.append(_build_link_schema_from_obj(link))

        return links

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to list linked artifacts for {artifact_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list linked artifacts: {str(e)}",
        )


# =============================================================================
# get_unlinked_references — GET /{artifact_id}/unlinked-references
# =============================================================================


@router.get(
    "/{artifact_id}/unlinked-references",
    response_model=Dict[str, List[str]],
    summary="Get unlinked references",
    description="Get references that couldn't be auto-linked.",
    responses={
        200: {"description": "Successfully retrieved unlinked references"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_unlinked_references(
    artifact_id: str,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    collection_mgr: CollectionManagerOptDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (uses default if not specified)",
    ),
) -> Dict[str, List[str]]:
    """Get list of unlinked artifact references.

    These are references that were found in the artifact's content or frontmatter
    but couldn't be automatically linked to existing artifacts in the collection.

    Args:
        artifact_id: Artifact identifier (format: type:name)
        settings: API settings for edition routing
        artifact_repo: Artifact repository dependency
        collection_mgr: Collection manager (local edition only)
        token: API token for authentication
        auth_context: Resolved auth context
        collection: Optional collection name (local edition only)

    Returns:
        Dictionary with 'unlinked_references' key containing list of reference strings

    Raises:
        HTTPException 404: If artifact not found
        HTTPException 500: If operation fails
    """
    if settings.edition == "enterprise":
        return await _get_unlinked_references_enterprise(
            artifact_id=artifact_id,
            artifact_repo=artifact_repo,
        )
    return await _get_unlinked_references_local(
        artifact_id=artifact_id,
        collection_mgr=collection_mgr,
        collection=collection,
    )


async def _get_unlinked_references_enterprise(
    *,
    artifact_id: str,
    artifact_repo: ArtifactRepoDep,
) -> Dict[str, List[str]]:
    """Enterprise path: retrieve unlinked references from ArtifactDTO metadata.

    Args:
        artifact_id: Artifact identifier (format: type:name)
        artifact_repo: Enterprise artifact repository

    Returns:
        Dict with ``"unlinked_references"`` key mapped to list of reference strings.

    Raises:
        HTTPException 400: If artifact ID format is invalid.
        HTTPException 404: If artifact not found.
        HTTPException 500: If unexpected error occurs.
    """
    try:
        logger.info("Enterprise: getting unlinked references for %s", artifact_id)

        try:
            parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        artifact_dto = artifact_repo.get(artifact_id)
        if artifact_dto is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )

        unlinked: List[str] = artifact_dto.metadata.get("unlinked_references") or []
        return {"unlinked_references": unlinked}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Enterprise: failed to get unlinked references for %s: %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get unlinked references: {str(e)}",
        )


async def _get_unlinked_references_local(
    *,
    artifact_id: str,
    collection_mgr,
    collection: Optional[str],
) -> Dict[str, List[str]]:
    """Local path: verbatim copy of get_unlinked_references handler from _legacy.py.

    Args:
        artifact_id: Artifact identifier (format: type:name)
        collection_mgr: Collection manager instance
        collection: Optional collection name override

    Returns:
        Dictionary with 'unlinked_references' key containing list of reference strings

    Raises:
        HTTPException 404: If artifact not found
        HTTPException 500: If operation fails
    """
    try:
        logger.info(f"Getting unlinked references for {artifact_id}")

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Resolve collection
        collection_name = collection or collection_mgr.get_active_collection_name()

        # Load collection
        try:
            coll = collection_mgr.load_collection(collection_name)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Collection '{collection_name}' not found",
            )

        # Find artifact
        artifact = coll.find_artifact(artifact_name, artifact_type)
        if artifact is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )

        # Get unlinked references
        unlinked = []
        if artifact.metadata and artifact.metadata.unlinked_references:
            unlinked = artifact.metadata.unlinked_references

        return {"unlinked_references": unlinked}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to get unlinked references for {artifact_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get unlinked references: {str(e)}",
        )
