"""Shared utility helpers for the artifacts router sub-modules.

These functions are extracted from the monolithic _legacy.py to be reused
across the decomposed sub-modules as the artifacts router is incrementally
split up.  None of these helpers import from _legacy.py — they are
self-contained.
"""

from __future__ import annotations

import base64
import hashlib
import logging
import re
from pathlib import Path as PathLib
from typing import Iterator, List, Optional

from fastapi import HTTPException, status

from skillmeat.api.dependencies import get_settings

from skillmeat.api.schemas.artifacts import (
    ArtifactCollectionInfo,
    ArtifactMetadataResponse,
    ArtifactResponse,
    ArtifactUpstreamInfo,
    DeploymentStatistics,
    ProjectDeploymentInfo,
)
from skillmeat.api.schemas.deployments import DeploymentSummary
from skillmeat.api.utils.error_handlers import (
    create_bad_request_error,
    create_not_found_error,
)
from skillmeat.api.schemas.errors import ErrorCodes
from skillmeat.core.artifact import ArtifactType
from skillmeat.core.interfaces.repositories import (
    IArtifactRepository,
    ICollectionRepository,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Enterprise artifact ID resolution
# ---------------------------------------------------------------------------

#: Compiled UUID regex — matches standard 8-4-4-4-12 hyphenated form.
#: This is the single canonical definition; import it from here rather than
#: defining local copies in individual router modules.
_UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
    re.IGNORECASE,
)


def _is_uuid(s: str) -> bool:
    """Return True if *s* looks like a hyphenated UUID string."""
    return bool(_UUID_RE.match(s))


async def resolve_enterprise_artifact_id(
    artifact_id: str,
    settings,
    artifact_repo,
) -> str:
    """Resolve *artifact_id* to an enterprise UUID string when in enterprise mode.

    In **local** mode the value is returned unchanged — local repositories
    accept ``type:name`` composite IDs directly.

    In **enterprise** mode:

    * If *artifact_id* already looks like a UUID (8-4-4-4-12 hex), it is
      returned unchanged (short-circuit avoids an unnecessary DB round-trip).
    * Otherwise the ID is forwarded to
      ``artifact_repo.resolve_uuid_by_id(artifact_id)`` which queries the
      enterprise DB to map ``type:name`` → UUID hex string.
    * If resolution fails (artifact not found), ``HTTPException(404)`` is
      raised.

    Args:
        artifact_id: The raw ``artifact_id`` path parameter value, in either
            ``type:name`` or UUID format.
        settings: ``APISettings`` instance (used to check ``settings.edition``).
        artifact_repo: An ``IArtifactRepository`` implementation that exposes
            a ``resolve_uuid_by_id(str) -> str | None`` method in enterprise
            mode.

    Returns:
        The resolved UUID string (enterprise mode) or the original
        *artifact_id* unchanged (local mode).

    Raises:
        HTTPException: 404 when enterprise mode and the artifact cannot be
            resolved.
    """
    if settings.edition != "enterprise":
        return artifact_id

    if _is_uuid(artifact_id):
        return artifact_id

    resolved: Optional[str] = None
    try:
        resolved = artifact_repo.resolve_uuid_by_id(artifact_id)
    except Exception as exc:
        logger.debug(
            "resolve_enterprise_artifact_id: resolve_uuid_by_id(%r) raised: %s",
            artifact_id,
            exc,
        )

    if not resolved:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Artifact '{artifact_id}' not found",
        )

    return resolved


# Exclusion patterns for diff operations - skip non-content directories
DIFF_EXCLUDE_DIRS = {
    ".git",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    ".tox",
    ".pytest_cache",
    ".mypy_cache",
    "dist",
    "build",
    ".next",
    ".turbo",
}

# Common file extensions that may be incorrectly included in artifact IDs
_ARTIFACT_ID_EXTENSIONS = (".md", ".txt", ".json", ".yaml", ".yml")


# ---------------------------------------------------------------------------
# Filesystem iteration
# ---------------------------------------------------------------------------


def iter_artifact_files(
    base_path: PathLib, exclude_dirs: Optional[set[str]] = None
) -> Iterator[PathLib]:
    """Iterate artifact files, excluding specified directories.

    Filters out directories like node_modules, .git, __pycache__, etc. that
    would cause significant performance degradation during diff operations.

    Args:
        base_path: Root path to iterate
        exclude_dirs: Set of directory names to exclude (defaults to
            DIFF_EXCLUDE_DIRS)
    """
    exclusions = exclude_dirs or DIFF_EXCLUDE_DIRS
    for f in base_path.rglob("*"):
        if f.is_file():
            if not any(part in exclusions for part in f.relative_to(base_path).parts):
                yield f


# ---------------------------------------------------------------------------
# Path normalization / decoding
# ---------------------------------------------------------------------------


def _normalize_artifact_path(path_str: str) -> str:
    """Normalize artifact path by removing duplicate extensions.

    Detects and fixes double extensions like .md.md, .txt.txt, etc.

    Args:
        path_str: Artifact path from manifest

    Returns:
        Normalized path with duplicate extensions removed
    """
    path = PathLib(path_str)
    stem = path.stem
    suffix = path.suffix

    if suffix:
        suffix_no_dot = suffix[1:]
        if stem.endswith(f".{suffix_no_dot}"):
            normalized = str(PathLib(path.parent) / stem)
            logger.warning(
                "Normalized artifact path with duplicate extension: %s -> %s",
                path_str,
                normalized,
            )
            return normalized

    return path_str


def _decode_project_id_param(raw_project_id: str) -> Optional[PathLib]:
    """Decode project identifier passed to bulk import.

    Accepts standard base64-encoded project paths (with or without padding)
    and gracefully falls back to treating the value as a URL-encoded absolute
    path.
    """
    from urllib.parse import unquote

    candidate = unquote(raw_project_id.strip().replace(" ", "+"))

    try:
        padding = "=" * (-len(candidate) % 4)
        decoded_path = base64.b64decode(candidate + padding).decode()
        project_path = PathLib(decoded_path).resolve()
        if project_path.is_absolute():
            return project_path
    except Exception:
        pass

    try:
        decoded_path = unquote(candidate)
        project_path = PathLib(decoded_path).resolve()
        if project_path.is_absolute():
            return project_path
    except Exception:
        pass

    return None


def _get_possible_artifact_paths(artifact_type: ArtifactType, name: str) -> List[str]:
    """Get possible project paths for an artifact without a deployment record.

    When an artifact exists in a project but has no deployment record (e.g.,
    manually deployed or deployed before tracking was implemented), this
    function returns candidate paths based on artifact type conventions.

    Args:
        artifact_type: The type of artifact (skill, command, agent, etc.)
        name: The artifact name

    Returns:
        List of possible relative paths within .claude/ directory, ordered by
        likelihood.  The first matching path should be used.
    """
    type_val = artifact_type.value
    paths: List[str] = []

    if type_val == "skill":
        paths = [f"skills/{name}"]
    elif type_val == "command":
        paths = [f"commands/{name}"]
    elif type_val == "agent":
        paths = [
            f"agents/{name}.md",
            f"agents/{name}",
            f"agents/pm/{name}.md",
            f"agents/dev/{name}.md",
        ]
    elif type_val == "hook":
        paths = [f"hooks/{name}"]
    elif type_val == "mcp":
        paths = [f"mcp/{name}"]

    return paths


def resolve_project_path(project_id: str) -> PathLib:
    """Resolve project ID to filesystem path.

    Args:
        project_id: URL-encoded project path

    Returns:
        Resolved PathLib object

    Raises:
        HTTPException: If path is invalid or doesn't exist
    """
    from urllib.parse import unquote

    decoded_path = unquote(project_id)
    project_path = PathLib(decoded_path)

    if not project_path.is_absolute():
        raise create_bad_request_error(
            f"Project path must be absolute: {decoded_path}",
            ErrorCodes.VALIDATION_FAILED,
        )

    if not project_path.exists():
        raise create_not_found_error(
            f"Project path not found: {decoded_path}", ErrorCodes.NOT_FOUND
        )

    return project_path


# ---------------------------------------------------------------------------
# Artifact ID parsing
# ---------------------------------------------------------------------------


def parse_artifact_id(artifact_id: str) -> tuple[str, str]:
    """Parse artifact_id into (type, name), normalizing the name.

    Handles cases where the frontend sends artifact IDs with file extensions
    (e.g., 'agent:prd-writer.md' instead of 'agent:prd-writer').

    Args:
        artifact_id: The artifact identifier in 'type:name' format

    Returns:
        Tuple of (artifact_type_str, artifact_name) with normalized name

    Raises:
        ValueError: If artifact_id is not in 'type:name' format
    """
    if ":" not in artifact_id:
        raise ValueError("Invalid artifact ID format. Expected 'type:name'")

    artifact_type_str, artifact_name = artifact_id.split(":", 1)

    original_name = artifact_name
    for ext in _ARTIFACT_ID_EXTENSIONS:
        if artifact_name.endswith(ext):
            artifact_name = artifact_name[: -len(ext)]
            logger.warning(
                "Stripped extension from artifact ID: '%s' -> '%s'",
                original_name,
                artifact_name,
            )
            break

    return artifact_type_str, artifact_name


# ---------------------------------------------------------------------------
# Collection resolution
# ---------------------------------------------------------------------------


def resolve_collection_name(
    collection_param: str,
    collection_mgr=None,
    db_user_coll_repo=None,
    db_session=None,
    collection_repo: Optional[ICollectionRepository] = None,
) -> Optional[str]:
    """Resolve a collection parameter to a collection name.

    Accepts either a collection name or UUID.  If a UUID is provided, looks up
    the name from the database via the repository.

    In enterprise mode (collection_repo is the primary source), the repository
    is checked first before any filesystem scan.  When collection_mgr is None
    the filesystem path is skipped entirely.

    Args:
        collection_param: Collection name or UUID string
        collection_mgr: CollectionManager instance (optional; when None the
            filesystem path is skipped and collection_repo is used exclusively)
        db_user_coll_repo: Optional IDbUserCollectionRepository instance for
            UUID-to-name resolution (preferred).  Falls back to db_session if
            not provided.
        db_session: Deprecated — kept for backward compatibility only.
            Use db_user_coll_repo instead.
        collection_repo: ICollectionRepository for enterprise-mode resolution.
            When provided, the DB-backed collection list is checked as the
            primary source so that collections that exist only in the database
            (not on the local filesystem) are resolved correctly.

    Returns:
        The collection name if found, None if not resolvable.
    """
    if collection_repo is not None:
        try:
            db_collections = collection_repo.list()
            db_names = [c.name for c in db_collections]
            if collection_param in db_names:
                return collection_param
            db_names_lower = {n.lower(): n for n in db_names}
            if collection_param.lower() in db_names_lower:
                return db_names_lower[collection_param.lower()]
        except Exception as e:
            logger.debug(
                "collection_repo.list() failed during resolve_collection_name: %s", e
            )

    collection_names: List[str] = []
    if collection_mgr is not None:
        collection_names = collection_mgr.list_collections()
        if collection_param in collection_names:
            return collection_param

    collection_record = None
    if db_user_coll_repo is not None:
        collection_record = db_user_coll_repo.get_by_id(collection_param)
    else:
        settings = get_settings()
        if settings.edition == "enterprise":
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail="Not available in enterprise edition",
            )
        from skillmeat.cache.repositories import DbUserCollectionRepository

        _repo = DbUserCollectionRepository()
        collection_record = _repo.get_by_id(collection_param)

    if collection_record is not None:
        collection_names_lower = {name.lower(): name for name in collection_names}
        db_name_lower = collection_record.name.lower()

        if db_name_lower in collection_names_lower:
            filesystem_name = collection_names_lower[db_name_lower]
            logger.warning(
                "Resolved collection UUID '%s' to name '%s' (DB: '%s', filesystem: '%s'). "
                "Frontend should send collection name instead of UUID.",
                collection_param,
                filesystem_name,
                collection_record.name,
                filesystem_name,
            )
            return filesystem_name

        if collection_repo is not None:
            logger.debug(
                "Resolved collection UUID '%s' to DB name '%s' (no filesystem counterpart).",
                collection_param,
                collection_record.name,
            )
            return collection_record.name

    return None


def _find_artifact_in_collections(
    artifact_name: str,
    artifact_type: ArtifactType,
    collection_mgr=None,
    preferred_collection: Optional[str] = None,
    db_session=None,
    artifact_repo: Optional[IArtifactRepository] = None,
    collection_repo: Optional[ICollectionRepository] = None,
) -> tuple:
    """Find an artifact across collections, with optional preferred collection hint.

    When a preferred collection is specified (name or UUID), searches there
    first.  If the artifact is not found in the preferred collection (e.g.,
    stale DB association), falls back to searching all collections.

    In enterprise mode (artifact_repo provided and collection_mgr is None or
    the filesystem has no collections), the repository is queried directly
    without a filesystem scan.

    Args:
        artifact_name: Normalized artifact name (extension already stripped)
        artifact_type: Artifact type enum
        collection_mgr: CollectionManager instance (optional; when None the
            filesystem path is skipped entirely)
        preferred_collection: Optional collection name or UUID to search first
        db_session: Optional SQLAlchemy session for UUID resolution
        artifact_repo: IArtifactRepository for enterprise-mode lookup.
            When provided and the filesystem search yields no result, the
            function falls back (or goes directly in enterprise mode) to
            querying the DB-backed repository.
        collection_repo: Optional ICollectionRepository used when resolving
            preferred_collection names in enterprise mode.

    Returns:
        Tuple of (artifact_or_dto, collection_name).  Returns (None, None) if
        not found anywhere.
    """
    if artifact_repo is not None and collection_mgr is None:
        try:
            artifact_id = f"{artifact_type.value}:{artifact_name}"
            dto = artifact_repo.get(artifact_id)
            if dto is not None:
                collection_name = getattr(dto, "collection_name", None) or "default"
                return dto, collection_name
        except Exception as e:
            logger.debug(
                "artifact_repo.get('%s:%s') failed in _find_artifact_in_collections "
                "(enterprise primary): %s",
                artifact_type.value,
                artifact_name,
                e,
            )
        return None, None

    if preferred_collection and collection_mgr is not None:
        resolved = resolve_collection_name(
            preferred_collection,
            collection_mgr,
            db_session=db_session,
            collection_repo=collection_repo,
        )
        if resolved:
            try:
                coll = collection_mgr.load_collection(resolved)
                artifact = coll.find_artifact(artifact_name, artifact_type)
                if artifact:
                    return artifact, resolved
            except ValueError:
                pass
            logger.warning(
                "Artifact '%s:%s' not found in preferred collection '%s' "
                "(resolved from '%s'). Falling back to searching all collections.",
                artifact_type.value,
                artifact_name,
                resolved,
                preferred_collection,
            )

    if collection_mgr is not None:
        for coll_name in collection_mgr.list_collections():
            try:
                coll = collection_mgr.load_collection(coll_name)
                artifact = coll.find_artifact(artifact_name, artifact_type)
                if artifact:
                    return artifact, coll_name
            except ValueError:
                continue

    if artifact_repo is not None:
        try:
            artifact_id = f"{artifact_type.value}:{artifact_name}"
            dto = artifact_repo.get(artifact_id)
            if dto is not None:
                collection_name = getattr(dto, "collection_name", None) or "default"
                return dto, collection_name
        except Exception as e:
            logger.debug(
                "artifact_repo.get('%s:%s') failed in _find_artifact_in_collections: %s",
                artifact_type.value,
                artifact_name,
                e,
            )

    return None, None


# ---------------------------------------------------------------------------
# Cursor-based pagination
# ---------------------------------------------------------------------------


def encode_cursor(value: str) -> str:
    """Encode a cursor value to base64.

    Args:
        value: Value to encode

    Returns:
        Base64 encoded cursor string
    """
    return base64.b64encode(value.encode()).decode()


def decode_cursor(cursor: str) -> str:
    """Decode a base64 cursor value.

    Args:
        cursor: Base64 encoded cursor

    Returns:
        Decoded cursor value

    Raises:
        HTTPException: If cursor is invalid
    """
    try:
        return base64.b64decode(cursor.encode()).decode()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid cursor format: {str(e)}",
        )


# ---------------------------------------------------------------------------
# Response DTO mapping
# ---------------------------------------------------------------------------


def artifact_to_response(
    artifact,
    drift_status: Optional[str] = None,
    has_local_modifications: Optional[bool] = None,
    collections_data: Optional[List[ArtifactCollectionInfo]] = None,
    db_source: Optional[str] = None,
    deployments: Optional[List[DeploymentSummary]] = None,
    db_uuid: Optional[str] = None,
    workflow_id: Optional[str] = None,
) -> ArtifactResponse:
    """Convert Artifact model to API response schema.

    Args:
        artifact: Artifact instance
        drift_status: Optional drift status ("none", "modified", "deleted",
            "added")
        has_local_modifications: Optional flag indicating local modifications
        collections_data: Optional list of ArtifactCollectionInfo from
            CollectionService
        db_source: Optional source from DB cache (overrides filesystem source)
        deployments: Optional list of DeploymentSummary objects
        db_uuid: Optional UUID from DB cache (used when artifact.uuid is None)
        workflow_id: Optional workflow identifier for workflow-type artifacts

    Returns:
        ArtifactResponse schema
    """
    metadata_response = None
    if artifact.metadata:
        metadata_response = ArtifactMetadataResponse(
            title=artifact.metadata.title,
            description=artifact.metadata.description,
            author=artifact.metadata.author,
            license=artifact.metadata.license,
            version=artifact.metadata.version,
            dependencies=artifact.metadata.dependencies,
            tools=(
                [tool.value for tool in artifact.metadata.tools]
                if artifact.metadata.tools
                else []
            ),
            effort=artifact.metadata.effort,
            model=artifact.metadata.model,
            allowed_tools=artifact.metadata.allowed_tools,
            disallowed_tools=artifact.metadata.disallowed_tools,
            permission_mode=artifact.metadata.permission_mode,
            context=artifact.metadata.context,
            scope=artifact.metadata.scope,
        )

    upstream_response = None
    _has_github_upstream = artifact.upstream and (
        artifact.origin == "github"
        or (artifact.origin == "marketplace" and artifact.origin_source == "github")
    )
    if _has_github_upstream:
        update_available = False
        if artifact.resolved_sha and artifact.version_spec == "latest":
            update_available = False

        upstream_response = ArtifactUpstreamInfo(
            tracking_enabled=True,
            current_sha=artifact.resolved_sha,
            upstream_sha=None,
            update_available=update_available,
            has_local_modifications=has_local_modifications or False,
            drift_status=drift_status or "none",
        )

    version = artifact.version_spec or "unknown"
    collections_response = collections_data or []

    artifact_uuid = artifact.uuid or db_uuid
    if not artifact_uuid:
        fallback_input = f"{artifact.type.value}:{artifact.name}"
        artifact_uuid = hashlib.md5(fallback_input.encode()).hexdigest()

    return ArtifactResponse(
        id=f"{artifact.type.value}:{artifact.name}",
        uuid=artifact_uuid,
        name=artifact.name,
        type=artifact.type.value,
        source=db_source or (artifact.upstream if artifact.upstream else "local"),
        origin=artifact.origin,
        origin_source=artifact.origin_source,
        version=version,
        aliases=[],
        tags=artifact.tags or [],
        target_platforms=artifact.target_platforms,
        metadata=metadata_response,
        upstream=upstream_response,
        collections=collections_response,
        deployments=deployments,
        added=artifact.added,
        updated=artifact.last_updated or artifact.added,
        workflow_id=workflow_id,
    )


# ─── Filter/Sort Parameter Mapping ───────────────────────────────────────────
#
# This table maps _legacy.py endpoint query parameters (and the manager methods
# they call) to their IArtifactRepository / enterprise-repo equivalents.
# Used by dual-mode handlers to translate between the local (manager) path and
# the enterprise (repository) path as the artifacts router is incrementally
# migrated.
#
# ── LIST ARTIFACTS (GET /api/v1/artifacts) ────────────────────────────────────
#
# Legacy call:
#   artifact_mgr.list_artifacts(
#       collection_name=collection_name,   # str
#       artifact_type=type_filter,         # ArtifactType | None
#       tags=tag_filter,                   # list[str] | None
#   )
#   Post-list in Python: tools filter, has_unlinked filter,
#                        import_id filter (via marketplace_catalog_repo),
#                        search substring match, cursor-based pagination,
#                        owner_scope / owner_id filter,
#                        check_drift flag (via sync_mgr.check_drift()),
#                        include_deployments flag (extra DB query)
#
# Enterprise repo call:
#   artifact_repo.list(
#       filters={...},   # dict[str, Any] | None
#       offset=int,
#       limit=int,
#   )
#   artifact_repo.count(filters={...})        # for page_info.total
#   artifact_repo.search(query, filters={})   # when `search` param is set
#
# Query param             | Manager param           | Repo filters key          | Notes
# ----------------------- | ----------------------- | ------------------------- | -----
# artifact_type           | artifact_type           | "artifact_type"           | Direct mapping; comma-separated values need splitting before passing
# collection              | collection_name         | N/A — local only          | Manager scopes to a single collection dir; repo uses tenant scoping
# tags                    | tags (list[str])        | "tags"                    | Direct mapping; comma-separated string → list before passing
# tools                   | N/A (post-filter)       | N/A — local only          | No repo equivalent; applied in Python after list() returns
# has_unlinked            | N/A (post-filter)       | N/A — local only          | No repo equivalent; applied in Python after list() returns
# import_id               | N/A (post-filter)       | N/A — local only          | Resolved via marketplace_catalog_repo; no direct repo filter
# search                  | N/A (post-filter)       | "search" / repo.search()  | Local: in-memory substring; enterprise: use artifact_repo.search(query)
# limit                   | N/A (post-slice)        | limit (kwarg)             | Direct mapping as repo.list() kwarg
# after (cursor)          | N/A (post-slice)        | offset (derived)          | Cursor must be decoded to integer offset for repo.list()
# owner_scope             | N/A (post-filter)       | "owner_scope"             | Local edition ignores it; enterprise repo respects it
# owner_id                | N/A (post-filter)       | "owner_id"                | Local edition ignores it; enterprise repo respects it
# check_drift             | N/A (flag)              | N/A — local only          | Calls sync_mgr.check_drift(project_path); no repo equivalent
# project_path            | N/A (drift only)        | N/A — local only          | Only meaningful alongside check_drift=true
# include_deployments     | N/A (flag)              | N/A — separate query      | Extra DB query after list; not a repo filter
#
# ── GET ARTIFACT (GET /api/v1/artifacts/{artifact_id}) ───────────────────────
#
# Legacy call:
#   artifact_mgr.show(
#       artifact_name=artifact_name,       # str
#       artifact_type=artifact_type,       # ArtifactType
#       collection_name=collection_name,   # str
#   )
#
# Enterprise repo call:
#   artifact_repo.get(id="type:name")
#   artifact_repo.get_by_uuid(uuid=uuid_str)   # when artifact_id is a UUID
#
# Query param             | Manager param           | Repo param                | Notes
# ----------------------- | ----------------------- | ------------------------- | -----
# artifact_id (path)      | artifact_name + type    | id="type:name"            | Manager splits type:name; repo accepts composite id directly
# collection              | collection_name         | N/A — local only          | Manager searches that collection; repo uses auth_context tenant scoping
# include_deployments     | N/A (flag)              | N/A — separate query      | Extra DB query; not a repo param
#
# ── CREATE ARTIFACT (POST /api/v1/artifacts) ─────────────────────────────────
#
# Legacy calls:
#   artifact_mgr.add_from_github(
#       spec=source_str,                   # str  "owner/repo/path[@version]"
#       artifact_type=artifact_type,       # ArtifactType
#       collection_name=collection_name,   # str
#       custom_name=request.name,          # str | None
#       tags=request.tags,                 # list[str] | None
#       target_platforms=...,              # list[str] | None
#       force=False,
#   )
#   artifact_mgr.add_from_local(
#       path=request.source,               # str (filesystem path)
#       artifact_type=artifact_type,
#       collection_name=collection_name,
#       custom_name=request.name,
#       tags=request.tags,
#       target_platforms=...,
#       force=False,
#   )
#
# Enterprise repo call:
#   artifact_repo.create(dto=ArtifactDTO(...), owner_target=...)
#
# Request field           | Manager param           | Repo DTO field            | Notes
# ----------------------- | ----------------------- | ------------------------- | -----
# source (GitHub spec)    | spec=                   | dto.source                | add_from_github fetches + stores; repo.create() expects pre-populated DTO
# source (local path)     | path=                   | dto.source / dto.origin   | add_from_local copies files; repo.create() expects pre-populated DTO
# artifact_type           | artifact_type           | dto.type                  | Direct mapping
# name                    | custom_name             | dto.name                  | Direct mapping
# tags                    | tags                    | set_tags() after create   | Manager stores in manifest; repo uses separate set_tags() call
# target_platforms        | target_platforms        | dto.metadata.target_platforms | Direct mapping via metadata dict
# collection              | collection_name         | N/A — local only          | Manager stores under that collection dir; repo uses tenant/owner scoping
#
# ── UPDATE ARTIFACT (PUT /api/v1/artifacts/{artifact_id}) ────────────────────
#
# Legacy call:
#   collection.find_artifact() → direct mutation on manifest object
#   collection_mgr.save_collection()
#
# Enterprise repo call:
#   artifact_repo.update(id="type:name", updates={...})
#   artifact_repo.set_tags(id="type:name", tag_ids=[...])
#
# Request field           | Manager approach        | Repo param                | Notes
# ----------------------- | ----------------------- | ------------------------- | -----
# tags                    | manifest.artifact.tags  | set_tags(id, tag_ids)     | Tags stored as strings in manifest; repo uses tag IDs
# aliases                 | manifest.artifact.aliases | updates={"aliases": [...]} | Direct mapping via updates dict
# description / metadata  | manifest.artifact.metadata | updates={"metadata": ...} | Nested metadata dict
# collection              | collection_name (scope) | N/A — local only          | Scopes which manifest to update; not a repo param
#
# ── DELETE ARTIFACT (DELETE /api/v1/artifacts/{artifact_id}) ─────────────────
#
# Legacy call:
#   artifact_mgr.remove(
#       artifact_name,                     # str
#       artifact_type,                     # ArtifactType
#       collection_name,                   # str
#   )
#
# Enterprise repo call:
#   artifact_repo.delete(id="type:name")
#
# Query param             | Manager param           | Repo param                | Notes
# ----------------------- | ----------------------- | ------------------------- | -----
# artifact_id (path)      | artifact_name + type    | id="type:name"            | Same transformation as GET
# collection              | collection_name         | N/A — local only          | Manager needs collection to find file path; repo uses id directly
#
# ── UPSTREAM / FETCH UPDATE (GET /api/v1/artifacts/{id}/upstream) ────────────
#
# Legacy call:
#   artifact_mgr.fetch_update(
#       artifact_name=artifact_name,       # str
#       artifact_type=artifact_type,       # ArtifactType
#       collection_name=collection_name,   # str
#   )
#
# Enterprise repo equivalent: N/A — local only
#   fetch_update() performs a live GitHub network call and stores to filesystem.
#   The enterprise path would delegate to a separate FetchService; no direct
#   IArtifactRepository method covers this operation.
#
# ── APPLY UPDATE / SYNC FROM UPSTREAM (POST /api/v1/artifacts/{id}/sync) ─────
#
# Legacy calls:
#   artifact_mgr.apply_update_strategy(
#       fetch_result=fetch_result,
#       strategy=apply_strategy,           # "overwrite" | "merge" | "skip"
#       interactive=False,
#       auto_resolve=...,
#       collection_name=collection_name,
#   )
#   sync_mgr.sync_from_project(
#       project_path=project_path,         # str
#       artifact_names=[artifact_name],    # list[str]
#       strategy=sync_strategy,            # str
#       dry_run=False,
#       interactive=False,
#   )
#   sync_mgr.check_drift(project_path)     # returns drift results per artifact
#
# Enterprise repo equivalent: N/A — local only
#   All sync operations are filesystem-level; no IArtifactRepository method
#   covers apply_update_strategy or sync_from_project.  These remain in the
#   local-edition code path and are guarded by require_local_edition().
#
# ── SUMMARY OF UNSUPPORTED / LOCAL-ONLY PARAMETERS ───────────────────────────
#
# The following query parameters exist in _legacy.py but have no equivalent in
# IArtifactRepository.  In dual-mode handlers they must be handled exclusively
# on the local code path:
#
#   collection       — filesystem scope; enterprise uses tenant/owner context
#   tools            — post-list Python filter; no DB column or repo filter
#   has_unlinked     — post-list Python filter on artifact.metadata
#   import_id        — resolved via marketplace_catalog_repo, not artifact_repo
#   check_drift      — calls sync_mgr; no repo equivalent
#   project_path     — drift/sync only; no repo equivalent
#   include_deployments — extra DeploymentRepository query; not an artifact filter
#   after (cursor)   — must be decoded to integer offset for repo.list()
#
# ─────────────────────────────────────────────────────────────────────────────
