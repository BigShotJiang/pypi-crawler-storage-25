"""Artifacts router package.

Combines the migrated CRUD endpoints (crud.py) with the remaining legacy
endpoints (_legacy.py) into a single ``router`` that ``server.py`` registers.

Migration status
----------------
The seven endpoints below have been moved to ``crud.py`` and are served from
there exclusively.  They are filtered out of the legacy router to avoid
duplicate route registration.

Migrated endpoints (crud.py):
  - list_artifacts              GET    /artifacts
  - get_artifact                GET    /artifacts/{artifact_id}
  - create_artifact             POST   /artifacts
  - update_artifact             PUT    /artifacts/{artifact_id}
  - update_artifact_parameters  PUT    /artifacts/{artifact_id}/parameters
  - delete_artifact             DELETE /artifacts/{artifact_id}
  - check_artifact_upstream     GET    /artifacts/{artifact_id}/upstream

Migrated endpoints (deployment.py):
  - deploy_artifact             POST   /artifacts/{artifact_id}/deploy
  - undeploy_artifact           POST   /artifacts/{artifact_id}/undeploy
  - sync_artifact               POST   /artifacts/{artifact_id}/sync

Migrated endpoints (tags.py):
  - add_tag_to_artifact         POST   /artifacts/{artifact_id}/tags/{tag_id}
  - remove_tag_from_artifact    DELETE /artifacts/{artifact_id}/tags/{tag_id}

Migrated endpoints (files.py):
  - list_artifact_files          GET    /artifacts/{artifact_id}/files
  - get_artifact_file_content    GET    /artifacts/{artifact_id}/files/{file_path}
  - update_artifact_file_content PUT    /artifacts/{artifact_id}/files/{file_path}
  - create_artifact_file         POST   /artifacts/{artifact_id}/files/{file_path}
  - delete_artifact_file         DELETE /artifacts/{artifact_id}/files/{file_path}

Migrated endpoints (diff.py):
  - get_artifact_diff            GET    /artifacts/{artifact_id}/diff
  - get_artifact_upstream_diff   GET    /artifacts/{artifact_id}/upstream-diff
  - get_artifact_source_project_diff GET /artifacts/{artifact_id}/source-project-diff
  - get_skill_sync_diff          GET    /artifacts/{artifact_id}/sync-diff

Migrated endpoints (links.py):
  - create_linked_artifact      POST   /artifacts/{artifact_id}/linked-artifacts
  - delete_linked_artifact      DELETE /artifacts/{artifact_id}/linked-artifacts/{target}
  - list_linked_artifacts       GET    /artifacts/{artifact_id}/linked-artifacts
  - get_unlinked_references     GET    /artifacts/{artifact_id}/unlinked-references

Migrated endpoints (import_export.py):
  - bulk_import_artifacts       POST   /artifacts/discover/import
  - confirm_duplicates          POST   /artifacts/confirm-duplicates

Migrated endpoints (associations.py):
  - get_artifact_associations       GET    /artifacts/{artifact_id}/associations
  - get_consolidation_clusters      GET    /artifacts/consolidation/clusters
  - ignore_duplicate_pair           POST   /artifacts/consolidation/pairs/{pair_id}/ignore
  - unignore_duplicate_pair         DELETE /artifacts/consolidation/pairs/{pair_id}/ignore
  - merge_consolidation_cluster     POST   /artifacts/consolidation/clusters/{cluster_id}/merge
  - replace_consolidation_cluster   POST   /artifacts/consolidation/clusters/{cluster_id}/replace

Migrated endpoints (metadata.py):
  - fetch_github_metadata           GET    /artifacts/metadata/github

Migrated endpoints (version_graph.py):
  - get_version_graph               GET    /artifacts/{artifact_id}/version-graph

Registration topology
---------------------
``server.py`` registers this package's ``router`` with
``prefix=settings.api_prefix`` (``/api/v1``).  Both ``crud.router`` and
``_legacy.router`` carry their own ``prefix="/artifacts"``, so this combined
router must have **no prefix** to avoid double-prefixing.
"""

from fastapi import APIRouter
from fastapi.routing import APIRoute

from . import (
    _legacy,
    associations,
    crud,
    deployment,
    diff,
    files,
    import_export,
    links,
    metadata,
    tags,
    version_graph,
)

# Re-export names that tests patch via ``skillmeat.api.routers.artifacts.<name>``.
# This keeps test patch paths valid after ``artifacts.py`` was split into a
# sub-package.  On ``main`` both names lived directly in ``artifacts.py``; here
# they live in sub-modules but must be addressable from the package namespace.
from skillmeat.api.services import refresh_single_artifact_cache  # noqa: F401
from skillmeat.api.utils.upstream_cache import get_upstream_cache  # noqa: F401
from skillmeat.cache.models import get_session  # noqa: F401
from skillmeat.core.github_metadata import GitHubMetadataExtractor  # noqa: F401
from skillmeat.core.importer import ArtifactImporter  # noqa: F401
from skillmeat.storage.deployment import DeploymentTracker  # noqa: F401
from ._helpers import _find_artifact_in_collections  # noqa: F401

# ---------------------------------------------------------------------------
# Endpoint names that have been migrated to crud.py.
# These are excluded from the legacy router slice to avoid duplicate routes.
# ---------------------------------------------------------------------------
_MIGRATED: frozenset[str] = frozenset(
    {
        "list_artifacts",
        "get_artifact",
        "create_artifact",
        "update_artifact",
        "update_artifact_parameters",
        "delete_artifact",
        "check_artifact_upstream",
        "deploy_artifact",
        "undeploy_artifact",
        "sync_artifact",
        "add_tag_to_artifact",
        "remove_tag_from_artifact",
        "create_linked_artifact",
        "delete_linked_artifact",
        "list_linked_artifacts",
        "get_unlinked_references",
        "list_artifact_files",
        "get_artifact_file_content",
        "update_artifact_file_content",
        "create_artifact_file",
        "delete_artifact_file",
        "get_artifact_diff",
        "get_artifact_upstream_diff",
        "get_artifact_source_project_diff",
        "get_skill_sync_diff",
        "bulk_import_artifacts",
        "confirm_duplicates",
        "get_artifact_associations",
        "get_consolidation_clusters",
        "ignore_duplicate_pair",
        "unignore_duplicate_pair",
        "merge_consolidation_cluster",
        "replace_consolidation_cluster",
        "fetch_github_metadata",
        "get_version_graph",
    }
)

# ---------------------------------------------------------------------------
# Combined router — no prefix; each sub-router carries "/artifacts" itself.
# ---------------------------------------------------------------------------
router = APIRouter()

# 1. Migrated CRUD endpoints from crud.py (prefix="/artifacts" on that router)
router.include_router(crud.router)

# 2. Migrated deployment endpoint from deployment.py (prefix="/artifacts" on that router)
router.include_router(deployment.router)

# 3. Migrated tag association endpoints from tags.py (prefix="/artifacts" on that router)
router.include_router(tags.router)

# 4. Migrated linked artifact endpoints from links.py (prefix="/artifacts" on that router)
router.include_router(links.router)

# 5. Migrated file content endpoints from files.py (prefix="/artifacts" on that router)
router.include_router(files.router)

# 6. Migrated diff endpoints from diff.py (prefix="/artifacts" on that router)
router.include_router(diff.router)

# 7. Migrated import/export endpoints from import_export.py (prefix="/artifacts" on that router)
router.include_router(import_export.router)

# 8. Migrated association & consolidation endpoints from associations.py (prefix="/artifacts" on that router)
router.include_router(associations.router)

# 9. Migrated GitHub metadata endpoint from metadata.py (prefix="/artifacts" on that router)
router.include_router(metadata.router)

# 10. Migrated version graph endpoint from version_graph.py (prefix="/artifacts" on that router)
router.include_router(version_graph.router)

# 11. Remaining legacy endpoints — skip already-migrated ones.
#    _legacy.router has prefix="/artifacts" baked into its routes; append
#    directly so the outer combined router does not re-apply any prefix.
for _route in _legacy.router.routes:
    if isinstance(_route, APIRoute) and _route.endpoint.__name__ in _MIGRATED:
        continue
    router.routes.append(_route)
