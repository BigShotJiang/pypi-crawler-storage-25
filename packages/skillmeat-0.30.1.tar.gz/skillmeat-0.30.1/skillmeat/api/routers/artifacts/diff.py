"""Diff endpoints for the artifacts router — dual-mode (local + enterprise).

Contains:
  - get_artifact_diff          GET  /{artifact_id}/diff
  - get_artifact_upstream_diff GET  /{artifact_id}/upstream-diff
  - get_artifact_source_project_diff GET /{artifact_id}/source-project-diff
  - get_skill_sync_diff        GET  /{artifact_id}/sync-diff

The enterprise path for the three filesystem diff endpoints returns a
schema-compatible response derived from DB-stored artifact content (via
``IDbArtifactHistoryRepository`` / ``IArtifactRepository``).  When content is
not available in the DB the enterprise path returns an empty diff rather than
a 501 error, so the frontend always receives a valid payload.

The ``get_skill_sync_diff`` endpoint is local-only (it delegates to
``compute_skill_sync_diff`` which reads the SQLite DB directly); on the
enterprise path it returns an empty list.
"""

from __future__ import annotations

import difflib
import hashlib
import logging
import shutil
from pathlib import Path as PathLib
from typing import List, Optional

from fastapi import APIRouter, Depends, Query, status
from fastapi import HTTPException

from skillmeat.api.dependencies import (
    ArtifactManagerOptDep,
    ArtifactRepoDep,
    CollectionManagerOptDep,
    DbArtifactHistoryRepoDep,
    DbSessionDep,
    SettingsDep,
    get_auth_context,
    require_auth,
    verify_api_key,
)
from skillmeat.api.middleware.auth import TokenDep
from skillmeat.api.schemas.artifacts import (
    ArtifactDiffResponse,
    ArtifactUpstreamDiffResponse,
    FileDiff,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.common import ErrorResponse
from skillmeat.api.utils.upstream_cache import get_upstream_cache
from skillmeat.core.artifact import ArtifactType
from skillmeat.observability.timing import PerfTimer
from skillmeat.storage.deployment import DeploymentTracker

from ._helpers import (
    _find_artifact_in_collections,
    _get_possible_artifact_paths,
    _normalize_artifact_path,
    iter_artifact_files,
    parse_artifact_id,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Package-namespace proxy helpers
#
# These thin wrappers resolve via ``skillmeat.api.routers.artifacts`` at
# call-time so that test mocks applied to that package namespace are
# intercepted here — matching the original monolithic artifacts.py behaviour.
# ---------------------------------------------------------------------------

import sys as _sys  # noqa: E402


def _pkg_find_artifact_in_collections(*args, **kwargs):  # type: ignore[no-untyped-def]
    _pkg = _sys.modules.get("skillmeat.api.routers.artifacts")
    fn = (
        _pkg._find_artifact_in_collections  # type: ignore[attr-defined]
        if _pkg is not None
        else _find_artifact_in_collections
    )
    return fn(*args, **kwargs)


def _pkg_get_upstream_cache():  # type: ignore[no-untyped-def]
    _pkg = _sys.modules.get("skillmeat.api.routers.artifacts")
    fn = (
        _pkg.get_upstream_cache  # type: ignore[attr-defined]
        if _pkg is not None
        else get_upstream_cache
    )
    return fn()


router = APIRouter(
    prefix="/artifacts",
    tags=["artifacts"],
    dependencies=[Depends(verify_api_key)],
)


# ---------------------------------------------------------------------------
# Enterprise helpers
# ---------------------------------------------------------------------------


def _enterprise_empty_diff(
    artifact_id: str,
    artifact_name: str,
    artifact_type_str: str,
    collection_name: str,
    project_path: str,
) -> ArtifactDiffResponse:
    """Return a schema-compatible empty diff for enterprise mode.

    Used when the enterprise DB does not hold enough content to compute a
    real diff (e.g. content snapshots not available).  The response is valid
    per the schema — callers should treat it as "no detectable changes".
    """
    return ArtifactDiffResponse(
        artifact_id=artifact_id,
        artifact_name=artifact_name,
        artifact_type=artifact_type_str,
        collection_name=collection_name,
        project_path=project_path,
        has_changes=False,
        files=[],
        summary={"added": 0, "modified": 0, "deleted": 0, "unchanged": 0},
    )


def _enterprise_empty_upstream_diff(
    artifact_id: str,
    artifact_name: str,
    artifact_type_str: str,
    collection_name: str,
) -> ArtifactUpstreamDiffResponse:
    """Return a schema-compatible empty upstream diff for enterprise mode."""
    return ArtifactUpstreamDiffResponse(
        artifact_id=artifact_id,
        artifact_name=artifact_name,
        artifact_type=artifact_type_str,
        collection_name=collection_name,
        upstream_source="unknown",
        upstream_version="unknown",
        has_changes=False,
        files=[],
        summary={"added": 0, "modified": 0, "deleted": 0, "unchanged": 0},
    )


def _compute_text_diff(
    left_content: str,
    right_content: str,
    left_label: str,
    right_label: str,
) -> str:
    """Generate a unified diff between two text strings."""
    left_lines = left_content.splitlines(keepends=True)
    right_lines = right_content.splitlines(keepends=True)
    diff_lines = difflib.unified_diff(
        left_lines,
        right_lines,
        fromfile=left_label,
        tofile=right_label,
        lineterm="",
    )
    return "\n".join(diff_lines)


def _sha256_of_content(content: str) -> str:
    """Return the SHA-256 hex digest of a UTF-8 encoded string."""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Enterprise diff: build FileDiff list from DB history content
# ---------------------------------------------------------------------------


def _build_diff_from_db_content(
    artifact_id: str,
    artifact_name: str,
    artifact_type_str: str,
    collection_name: str,
    history_repo,
    artifact_repo,
    summary_only: bool,
    include_unified_diff: bool,
    requested_files: Optional[set],
) -> tuple[list[FileDiff], dict]:
    """Build diff file list from DB-backed artifact content snapshots.

    Returns (file_diffs, summary_dict).  When content is unavailable this
    returns empty lists so callers always get a valid response.

    Args:
        artifact_id: Artifact identifier (type:name).
        artifact_name: Parsed artifact name.
        artifact_type_str: Artifact type as string.
        collection_name: Resolved collection name.
        history_repo: IDbArtifactHistoryRepository instance.
        artifact_repo: IArtifactRepository instance.
        summary_only: Skip unified diff content when True.
        include_unified_diff: Include unified diff when True.
        requested_files: Optional set of file paths to include diffs for.

    Returns:
        Tuple of (file_diffs, summary).
    """
    summary = {"added": 0, "modified": 0, "deleted": 0, "unchanged": 0}
    file_diffs: list[FileDiff] = []

    try:
        # Look up DB artifact rows matching name+type
        cache_artifacts = history_repo.list_cache_artifacts_by_name_type(
            name=artifact_name,
            artifact_type=artifact_type_str,
        )
        if not cache_artifacts:
            return file_diffs, summary

        # Use the first cache artifact to get version lineage
        ca = cache_artifacts[0]
        version_lineage = history_repo.list_versions_for_artifacts(
            artifact_ids=[ca.uuid],
        )

        if len(version_lineage) < 2:
            # Only one version — nothing to diff
            return file_diffs, summary

        # Compare the two most-recent versions
        newest = version_lineage[0]
        previous = version_lineage[1]

        new_content = getattr(newest, "content", None) or ""
        old_content = getattr(previous, "content", None) or ""

        if not new_content and not old_content:
            return file_diffs, summary

        # Treat entire content as a single "file" diff
        file_rel_path = f"{artifact_name}.content"
        old_hash = _sha256_of_content(old_content)
        new_hash = _sha256_of_content(new_content)

        if old_hash == new_hash:
            file_status = "unchanged"
            summary["unchanged"] += 1
            file_diffs.append(
                FileDiff(
                    file_path=file_rel_path,
                    status=file_status,
                    collection_hash=old_hash,
                    project_hash=new_hash,
                    unified_diff=None,
                )
            )
        else:
            file_status = "modified"
            summary["modified"] += 1

            unified_diff: Optional[str] = None
            skip_diff = summary_only or not include_unified_diff
            if (
                not skip_diff
                and requested_files is not None
                and file_rel_path not in requested_files
            ):
                skip_diff = True
            if not skip_diff and new_content and old_content:
                try:
                    unified_diff = _compute_text_diff(
                        old_content,
                        new_content,
                        left_label=f"collection/{file_rel_path}",
                        right_label=f"project/{file_rel_path}",
                    )
                except Exception as exc:
                    logger.warning("Failed to generate enterprise diff: %s", exc)
                    unified_diff = f"[Error generating diff: {exc}]"

            file_diffs.append(
                FileDiff(
                    file_path=file_rel_path,
                    status=file_status,
                    collection_hash=old_hash,
                    project_hash=new_hash,
                    unified_diff=unified_diff,
                )
            )
    except Exception as exc:
        logger.warning(
            "Enterprise diff content lookup failed for %s: %s", artifact_id, exc
        )

    return file_diffs, summary


# ---------------------------------------------------------------------------
# get_artifact_diff
# ---------------------------------------------------------------------------


@router.get(
    "/{artifact_id}/diff",
    response_model=ArtifactDiffResponse,
    summary="Get artifact diff",
    description="Compare artifact versions between collection and deployed project",
    responses={
        200: {"description": "Successfully retrieved diff"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_artifact_diff(
    artifact_id: str,
    artifact_repo: ArtifactRepoDep,
    history_repo: DbArtifactHistoryRepoDep,
    settings: SettingsDep,
    _token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    project_path: str = Query(
        ...,
        description="Path to project for comparison",
    ),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
    summary_only: bool = Query(
        default=False,
        description="Return only summary counts and file metadata without unified diffs",
    ),
    include_unified_diff: bool = Query(
        default=True,
        description="Include unified diff content in file results. Set to False for summary view.",
    ),
    file_paths: Optional[str] = Query(
        default=None,
        description="Comma-separated file paths to include unified diffs for. When set, only these files get full diff content; others get status/hash only.",
    ),
) -> ArtifactDiffResponse:
    """Get diff between collection version and deployed project version.

    Compares the artifact in the collection with the deployed version in a
    project, showing file-level differences with unified diff format for
    modified files.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        artifact_repo: Artifact repository (enterprise path)
        history_repo: Artifact history repository (enterprise path)
        settings: API settings (controls edition-based branching)
        _token: Authentication token
        auth_context: Caller auth context
        artifact_mgr: Artifact manager (local edition only)
        collection_mgr: Collection manager (local edition only)
        project_path: Path to project directory containing deployed artifact
        collection: Optional collection filter
        summary_only: Return only summary without full diffs
        include_unified_diff: Include unified diff content
        file_paths: Comma-separated specific file paths for diff

    Returns:
        ArtifactDiffResponse with file-level diffs and summary

    Raises:
        HTTPException: If artifact not found, project not found, or on error
    """
    # -----------------------------------------------------------------------
    # Enterprise path
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        collection_name = collection or "default"
        requested_files = set(file_paths.split(",")) if file_paths else None

        try:
            file_diffs, summary = _build_diff_from_db_content(
                artifact_id=artifact_id,
                artifact_name=artifact_name,
                artifact_type_str=artifact_type_str,
                collection_name=collection_name,
                history_repo=history_repo,
                artifact_repo=artifact_repo,
                summary_only=summary_only,
                include_unified_diff=include_unified_diff,
                requested_files=requested_files,
            )
        except Exception as exc:
            logger.warning(
                "Enterprise artifact diff failed for %s: %s", artifact_id, exc
            )
            return _enterprise_empty_diff(
                artifact_id,
                artifact_name,
                artifact_type_str,
                collection_name,
                project_path,
            )

        has_changes = (
            summary["added"] > 0 or summary["modified"] > 0 or summary["deleted"] > 0
        )
        return ArtifactDiffResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type_str,
            collection_name=collection_name,
            project_path=project_path,
            has_changes=has_changes,
            files=file_diffs,
            summary=summary,
        )

    # -----------------------------------------------------------------------
    # Local path — verbatim copy from _legacy.py get_artifact_diff
    # -----------------------------------------------------------------------
    try:
        logger.info(
            f"Getting diff for artifact: {artifact_id} (project={project_path}, collection={collection})"
        )

        # Parse optional file-path filter for lazy per-file diff loading
        requested_files = set(file_paths.split(",")) if file_paths else None

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Validate project path
        proj_path = PathLib(project_path)
        if not proj_path.exists():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Project path does not exist: {project_path}",
            )

        # Find deployment in project
        deployment = DeploymentTracker.get_deployment(
            proj_path, artifact_name, artifact_type.value
        )

        # Handle case when no deployment record exists (manually deployed or legacy)
        if deployment:
            collection_name = collection or deployment.from_collection
            inferred_artifact_path = deployment.artifact_path
        else:
            # No deployment record - try to infer paths
            logger.debug(
                f"No deployment record for {artifact_id}, attempting to infer paths"
            )
            collection_name = collection or "default"

            # Find artifact in project using standard conventions
            possible_paths = _get_possible_artifact_paths(artifact_type, artifact_name)
            inferred_artifact_path = None

            for path in possible_paths:
                full_path = proj_path / ".claude" / path
                if full_path.exists():
                    inferred_artifact_path = path
                    logger.debug(f"Found artifact at inferred path: {path}")
                    break

            if not inferred_artifact_path:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Artifact '{artifact_id}' not found in project {project_path}",
                )

        # Find artifact in collection (with fallback across all collections)
        artifact, resolved_collection = _pkg_find_artifact_in_collections(
            artifact_name,
            artifact_type,
            collection_mgr,
            preferred_collection=collection_name,
            artifact_repo=artifact_repo,
        )

        if not artifact:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found in any collection",
            )
        collection_name = resolved_collection

        # Normalize artifact path to handle duplicate extensions
        normalized_artifact_path = _normalize_artifact_path(artifact.path)

        # Get paths
        collection_path = collection_mgr.config.get_collection_path(collection_name)
        collection_artifact_path = collection_path / normalized_artifact_path
        project_artifact_path = proj_path / ".claude" / inferred_artifact_path

        # Handle missing collection artifact (project has files that aren't in collection)
        collection_exists = collection_artifact_path.exists()
        project_exists = project_artifact_path.exists()

        if not collection_exists and not project_exists:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found in either collection or project",
            )

        # Log resilience cases
        if not collection_exists:
            logger.warning(
                f"Collection artifact missing but project exists: {artifact_id} "
                f"(collection_path={collection_artifact_path}, project_path={project_artifact_path}). "
                "Returning diff with all project files marked as 'deleted'."
            )
        elif not project_exists:
            logger.warning(
                f"Project artifact missing but collection exists: {artifact_id} "
                f"(collection_path={collection_artifact_path}, project_path={project_artifact_path}). "
                "Returning diff with all collection files marked as 'added'."
            )

        # Collect all files from both locations — timed to measure filesystem enumeration
        with PerfTimer(
            "router.get_artifact_diff.enumerate_files",
            artifact_id=artifact_id,
            project_path=project_path,
        ):
            collection_files = set()
            project_files = set()
            exclude_dirs = set(settings.diff_exclude_dirs)

            if collection_exists:
                if collection_artifact_path.is_dir():
                    collection_files = {
                        str(f.relative_to(collection_artifact_path))
                        for f in iter_artifact_files(
                            collection_artifact_path, exclude_dirs
                        )
                    }
                else:
                    collection_files = {collection_artifact_path.name}

            if project_exists:
                if project_artifact_path.is_dir():
                    project_files = {
                        str(f.relative_to(project_artifact_path))
                        for f in iter_artifact_files(
                            project_artifact_path, exclude_dirs
                        )
                    }
                else:
                    project_files = {project_artifact_path.name}

        # Single-file fast path: when both sides are individual files (not
        # directories), align both sets to the same canonical name so the union
        # produces a single entry and the comparison loop treats them as one file.
        is_single_file_both = (
            collection_exists
            and not collection_artifact_path.is_dir()
            and project_exists
            and not project_artifact_path.is_dir()
        )
        if is_single_file_both:
            canonical_name = collection_artifact_path.name
            collection_files = {canonical_name}
            project_files = {canonical_name}

        # Get all unique files
        all_files = sorted(collection_files | project_files)

        # Helper function to compute file hash
        def compute_file_hash(file_path: PathLib) -> str:
            """Compute SHA256 hash of a single file."""
            hasher = hashlib.sha256()
            with open(file_path, "rb") as f:
                while True:
                    chunk = f.read(8192)
                    if not chunk:
                        break
                    hasher.update(chunk)
            return hasher.hexdigest()

        # Helper function to check if file is binary
        def is_binary_file(file_path: PathLib) -> bool:
            """Check if file is binary by reading first 8KB."""
            try:
                with open(file_path, "rb") as f:
                    chunk = f.read(8192)
                    # Check for null bytes
                    return b"\x00" in chunk
            except Exception:
                return True  # Treat as binary if can't read

        # Build file diffs — timed to measure hashing + diff generation cost
        file_diffs: List[FileDiff] = []
        summary = {"added": 0, "modified": 0, "deleted": 0, "unchanged": 0}

        with PerfTimer(
            "router.get_artifact_diff.compute",
            artifact_id=artifact_id,
            file_count=len(all_files),
        ):
            for file_rel_path in all_files:
                in_collection = file_rel_path in collection_files
                in_project = file_rel_path in project_files

                # Determine status
                if in_collection and in_project:
                    # File exists in both - check if modified
                    if collection_artifact_path.is_dir():
                        coll_file_path = collection_artifact_path / file_rel_path
                    else:
                        coll_file_path = collection_artifact_path

                    if project_artifact_path.is_dir():
                        proj_file_path = project_artifact_path / file_rel_path
                    else:
                        proj_file_path = project_artifact_path

                    coll_hash = compute_file_hash(coll_file_path)
                    proj_hash = compute_file_hash(proj_file_path)

                    if coll_hash == proj_hash:
                        # Unchanged
                        file_status = "unchanged"
                        unified_diff = None
                        summary["unchanged"] += 1
                    else:
                        # Modified
                        file_status = "modified"
                        summary["modified"] += 1

                        # Generate unified diff if text file and not summary-only mode
                        unified_diff = None
                        skip_diff = summary_only or not include_unified_diff
                        if (
                            not skip_diff
                            and requested_files is not None
                            and file_rel_path not in requested_files
                        ):
                            skip_diff = True
                        if (
                            not skip_diff
                            and not is_binary_file(coll_file_path)
                            and not is_binary_file(proj_file_path)
                        ):
                            try:
                                with open(coll_file_path, "r", encoding="utf-8") as f:
                                    coll_lines = f.readlines()
                                with open(proj_file_path, "r", encoding="utf-8") as f:
                                    proj_lines = f.readlines()

                                diff_lines = difflib.unified_diff(
                                    coll_lines,
                                    proj_lines,
                                    fromfile=f"collection/{file_rel_path}",
                                    tofile=f"project/{file_rel_path}",
                                    lineterm="",
                                )
                                unified_diff = "\n".join(diff_lines)
                            except Exception as e:
                                logger.warning(
                                    f"Failed to generate diff for {file_rel_path}: {e}"
                                )
                                unified_diff = f"[Error generating diff: {str(e)}]"

                    file_diffs.append(
                        FileDiff(
                            file_path=file_rel_path,
                            status=file_status,
                            collection_hash=coll_hash,
                            project_hash=proj_hash,
                            unified_diff=unified_diff,
                        )
                    )

                elif in_collection and not in_project:
                    # File only in collection: would be added when deploying
                    file_status = "added"
                    summary["added"] += 1

                    if collection_exists:
                        if collection_artifact_path.is_dir():
                            coll_file_path = collection_artifact_path / file_rel_path
                        else:
                            coll_file_path = collection_artifact_path
                        coll_hash = compute_file_hash(coll_file_path)
                    else:
                        coll_hash = None

                    file_diffs.append(
                        FileDiff(
                            file_path=file_rel_path,
                            status=file_status,
                            collection_hash=coll_hash,
                            project_hash=None,
                            unified_diff=None,
                        )
                    )

                elif not in_collection and in_project:
                    # File only in project
                    file_status = "deleted"
                    summary["deleted"] += 1

                    if project_exists:
                        if project_artifact_path.is_dir():
                            proj_file_path = project_artifact_path / file_rel_path
                        else:
                            proj_file_path = project_artifact_path
                        proj_hash = compute_file_hash(proj_file_path)
                    else:
                        proj_hash = None

                    file_diffs.append(
                        FileDiff(
                            file_path=file_rel_path,
                            status=file_status,
                            collection_hash=None,
                            project_hash=proj_hash,
                            unified_diff=None,
                        )
                    )

        # Determine if there are changes
        has_changes = (
            summary["added"] > 0 or summary["modified"] > 0 or summary["deleted"] > 0
        )

        logger.info(
            f"Diff computed for {artifact_id}: {len(file_diffs)} files, "
            f"has_changes={has_changes}, summary={summary}"
        )

        return ArtifactDiffResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type.value,
            collection_name=collection_name,
            project_path=str(proj_path),
            has_changes=has_changes,
            files=file_diffs,
            summary=summary,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting diff for '{artifact_id}': {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get artifact diff: {str(e)}",
        )


# ---------------------------------------------------------------------------
# get_artifact_upstream_diff
# ---------------------------------------------------------------------------


@router.get(
    "/{artifact_id}/upstream-diff",
    response_model=ArtifactUpstreamDiffResponse,
    summary="Get artifact upstream diff",
    description="Compare collection artifact with its GitHub upstream source",
    responses={
        200: {"description": "Successfully retrieved upstream diff"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid request or no upstream source",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_artifact_upstream_diff(
    artifact_id: str,
    artifact_repo: ArtifactRepoDep,
    history_repo: DbArtifactHistoryRepoDep,
    settings: SettingsDep,
    _token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
    summary_only: bool = Query(
        default=False,
        description="Return only summary counts and file metadata without unified diffs",
    ),
    include_unified_diff: bool = Query(
        default=True,
        description="Include unified diff content in file results. Set to False for summary view.",
    ),
    file_paths: Optional[str] = Query(
        default=None,
        description="Comma-separated file paths to include unified diffs for. When set, only these files get full diff content; others get status/hash only.",
    ),
) -> ArtifactUpstreamDiffResponse:
    """Get diff between collection version and GitHub upstream source.

    Compares the artifact in the collection with the latest version from
    GitHub, showing file-level differences with unified diff format for
    modified files.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        artifact_repo: Artifact repository (enterprise path)
        history_repo: Artifact history repository (enterprise path)
        settings: API settings (controls edition-based branching)
        _token: Authentication token
        auth_context: Caller auth context
        artifact_mgr: Artifact manager (local edition only)
        collection_mgr: Collection manager (local edition only)
        collection: Optional collection filter
        summary_only: Return only summary without full diffs
        include_unified_diff: Include unified diff content
        file_paths: Comma-separated specific file paths for diff

    Returns:
        ArtifactUpstreamDiffResponse with file-level diffs and summary

    Raises:
        HTTPException: If artifact not found, no upstream source, or on error
    """
    # -----------------------------------------------------------------------
    # Enterprise path
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        collection_name = collection or "default"
        requested_files = set(file_paths.split(",")) if file_paths else None

        # Try to retrieve current artifact from repo for upstream metadata
        upstream_source = "unknown"
        upstream_version = "unknown"
        try:
            dto = artifact_repo.get(artifact_id)
            if dto is not None:
                upstream_source = (
                    getattr(dto, "upstream", None)
                    or getattr(dto, "source", None)
                    or "unknown"
                )
                upstream_version = (
                    getattr(dto, "resolved_sha", None)
                    or getattr(dto, "version", None)
                    or "unknown"
                )
                collection_name = (
                    getattr(dto, "collection_name", None) or collection_name
                )
        except Exception as exc:
            logger.debug("Enterprise upstream diff: artifact_repo.get failed: %s", exc)

        # Build diff from DB history content
        try:
            file_diffs, summary = _build_diff_from_db_content(
                artifact_id=artifact_id,
                artifact_name=artifact_name,
                artifact_type_str=artifact_type_str,
                collection_name=collection_name,
                history_repo=history_repo,
                artifact_repo=artifact_repo,
                summary_only=summary_only,
                include_unified_diff=include_unified_diff,
                requested_files=requested_files,
            )
        except Exception as exc:
            logger.warning(
                "Enterprise upstream diff failed for %s: %s", artifact_id, exc
            )
            return _enterprise_empty_upstream_diff(
                artifact_id, artifact_name, artifact_type_str, collection_name
            )

        has_changes = (
            summary["added"] > 0 or summary["modified"] > 0 or summary["deleted"] > 0
        )
        return ArtifactUpstreamDiffResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type_str,
            collection_name=collection_name,
            upstream_source=upstream_source,
            upstream_version=upstream_version,
            has_changes=has_changes,
            files=file_diffs,
            summary=summary,
        )

    # -----------------------------------------------------------------------
    # Local path — verbatim copy from _legacy.py get_artifact_upstream_diff
    # -----------------------------------------------------------------------
    try:
        logger.info(
            f"Getting upstream diff for artifact: {artifact_id} (collection={collection})"
        )

        # Parse optional file-path filter for lazy per-file diff loading
        requested_files = set(file_paths.split(",")) if file_paths else None

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Find artifact (with fallback across collections)
        artifact, collection_name = _pkg_find_artifact_in_collections(
            artifact_name,
            artifact_type,
            collection_mgr,
            preferred_collection=collection,
            artifact_repo=artifact_repo,
        )

        if not artifact:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found in any collection",
            )

        # Check if artifact has upstream tracking
        is_github_backed = artifact.origin == "github" or (
            artifact.origin == "marketplace" and artifact.origin_source == "github"
        )
        if not is_github_backed:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Artifact origin '{artifact.origin}' does not support upstream diff. Only GitHub-backed artifacts are supported.",
            )

        if not artifact.upstream:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Artifact does not have upstream tracking configured",
            )

        # Fetch latest upstream version — check short-lived cache first to
        # avoid redundant GitHub API calls when the sync modal fires both
        # upstream-diff and source-project-diff for the same artifact.
        _cache_key = f"{artifact_id}:{collection_name or 'default'}"
        _cached_fetch = None
        try:
            _cached_fetch = _pkg_get_upstream_cache().get(_cache_key)
        except Exception:
            logger.warning(
                f"Upstream cache get failed for {_cache_key}, falling through to fetch"
            )
        if _cached_fetch is not None:
            fetch_result = _cached_fetch
        else:
            logger.info(f"Fetching upstream update for {artifact_id}")
            fetch_result = artifact_mgr.fetch_update(
                artifact_name=artifact_name,
                artifact_type=artifact_type,
                collection_name=collection_name,
            )
            if not fetch_result.error:
                try:
                    _pkg_get_upstream_cache().put(_cache_key, fetch_result)
                except Exception:
                    logger.warning(f"Upstream cache put failed for {_cache_key}")

        # Check for fetch errors
        if fetch_result.error:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to fetch upstream: {fetch_result.error}",
            )

        # If no update detected (SHA matches), return empty diff
        if not fetch_result.has_update:
            return ArtifactUpstreamDiffResponse(
                artifact_id=artifact_id,
                artifact_name=artifact_name,
                artifact_type=artifact_type.value,
                collection_name=collection_name,
                upstream_source=artifact.upstream or "",
                upstream_version=artifact.resolved_sha or artifact.version_spec or "",
                has_changes=False,
                files=[],
                summary={"added": 0, "modified": 0, "deleted": 0, "unchanged": 0},
            )

        if not fetch_result.fetch_result or not fetch_result.temp_workspace:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to fetch upstream artifact",
            )

        # Normalize artifact path to handle duplicate extensions
        normalized_artifact_path = _normalize_artifact_path(artifact.path)

        # Get paths
        collection_path = collection_mgr.config.get_collection_path(collection_name)
        collection_artifact_path = collection_path / normalized_artifact_path
        upstream_artifact_path = fetch_result.fetch_result.artifact_path

        # Handle missing artifacts gracefully
        collection_exists = collection_artifact_path.exists()
        upstream_exists = upstream_artifact_path.exists()

        if not collection_exists and not upstream_exists:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Neither collection nor upstream artifact exists for {artifact_id}",
            )

        # Log resilience cases
        if not collection_exists:
            logger.warning(
                f"Collection artifact missing but upstream exists: {artifact_id} "
                f"(collection_path={collection_artifact_path}). "
                "Returning diff with all upstream files marked as 'added'."
            )
        elif not upstream_exists:
            logger.warning(
                f"Upstream artifact missing but collection exists: {artifact_id} "
                f"(upstream_path={upstream_artifact_path}). "
                "Returning diff with all collection files marked as 'deleted'."
            )

        # Collect all files from both locations
        collection_files = set()
        upstream_files = set()
        exclude_dirs = set(settings.diff_exclude_dirs)

        if collection_exists:
            if collection_artifact_path.is_dir():
                collection_files = {
                    str(f.relative_to(collection_artifact_path))
                    for f in iter_artifact_files(collection_artifact_path, exclude_dirs)
                }
            else:
                collection_files = {collection_artifact_path.name}

        if upstream_exists:
            if upstream_artifact_path.is_dir():
                upstream_files = {
                    str(f.relative_to(upstream_artifact_path))
                    for f in iter_artifact_files(upstream_artifact_path, exclude_dirs)
                }
            else:
                upstream_files = {upstream_artifact_path.name}

        # Get all unique files
        all_files = sorted(collection_files | upstream_files)

        # Helper function to compute file hash
        def compute_file_hash(file_path: PathLib) -> str:
            """Compute SHA256 hash of a single file."""
            hasher = hashlib.sha256()
            with open(file_path, "rb") as f:
                while True:
                    chunk = f.read(8192)
                    if not chunk:
                        break
                    hasher.update(chunk)
            return hasher.hexdigest()

        # Helper function to check if file is binary
        def is_binary_file(file_path: PathLib) -> bool:
            """Check if file is binary by reading first 8KB."""
            try:
                with open(file_path, "rb") as f:
                    chunk = f.read(8192)
                    # Check for null bytes
                    return b"\x00" in chunk
            except Exception:
                return True  # Treat as binary if can't read

        # Build file diffs
        file_diffs: List[FileDiff] = []
        summary = {"added": 0, "modified": 0, "deleted": 0, "unchanged": 0}

        for file_rel_path in all_files:
            in_collection = file_rel_path in collection_files
            in_upstream = file_rel_path in upstream_files

            # Determine status
            if in_collection and in_upstream:
                # File exists in both - check if modified
                if collection_artifact_path.is_dir():
                    coll_file_path = collection_artifact_path / file_rel_path
                else:
                    coll_file_path = collection_artifact_path

                if upstream_artifact_path.is_dir():
                    upstream_file_path = upstream_artifact_path / file_rel_path
                else:
                    upstream_file_path = upstream_artifact_path

                coll_hash = compute_file_hash(coll_file_path)
                upstream_hash = compute_file_hash(upstream_file_path)

                if coll_hash == upstream_hash:
                    # Unchanged
                    file_status = "unchanged"
                    unified_diff = None
                    summary["unchanged"] += 1
                else:
                    # Modified
                    file_status = "modified"
                    summary["modified"] += 1

                    # Generate unified diff if text file and not summary-only mode
                    unified_diff = None
                    skip_diff = summary_only or not include_unified_diff
                    if (
                        not skip_diff
                        and requested_files is not None
                        and file_rel_path not in requested_files
                    ):
                        skip_diff = True
                    if (
                        not skip_diff
                        and not is_binary_file(coll_file_path)
                        and not is_binary_file(upstream_file_path)
                    ):
                        try:
                            with open(coll_file_path, "r", encoding="utf-8") as f:
                                coll_lines = f.readlines()
                            with open(upstream_file_path, "r", encoding="utf-8") as f:
                                upstream_lines = f.readlines()

                            diff_lines = difflib.unified_diff(
                                coll_lines,
                                upstream_lines,
                                fromfile=f"collection/{file_rel_path}",
                                tofile=f"upstream/{file_rel_path}",
                                lineterm="",
                            )
                            unified_diff = "\n".join(diff_lines)
                        except Exception as e:
                            logger.warning(
                                f"Failed to generate diff for {file_rel_path}: {e}"
                            )
                            unified_diff = f"[Error generating diff: {str(e)}]"

                file_diffs.append(
                    FileDiff(
                        file_path=file_rel_path,
                        status=file_status,
                        collection_hash=coll_hash,
                        project_hash=upstream_hash,
                        unified_diff=unified_diff,
                    )
                )

            elif in_collection and not in_upstream:
                # File deleted in upstream (only in collection)
                file_status = "deleted"
                summary["deleted"] += 1

                if collection_exists:
                    if collection_artifact_path.is_dir():
                        coll_file_path = collection_artifact_path / file_rel_path
                    else:
                        coll_file_path = collection_artifact_path
                    coll_hash = compute_file_hash(coll_file_path)
                else:
                    coll_hash = None

                file_diffs.append(
                    FileDiff(
                        file_path=file_rel_path,
                        status=file_status,
                        collection_hash=coll_hash,
                        project_hash=None,
                        unified_diff=None,
                    )
                )

            elif not in_collection and in_upstream:
                # File added in upstream (only in upstream)
                file_status = "added"
                summary["added"] += 1

                if upstream_exists:
                    if upstream_artifact_path.is_dir():
                        upstream_file_path = upstream_artifact_path / file_rel_path
                    else:
                        upstream_file_path = upstream_artifact_path
                    upstream_hash = compute_file_hash(upstream_file_path)
                else:
                    upstream_hash = None

                file_diffs.append(
                    FileDiff(
                        file_path=file_rel_path,
                        status=file_status,
                        collection_hash=None,
                        project_hash=upstream_hash,
                        unified_diff=None,
                    )
                )

        # Determine if there are changes
        has_changes = (
            summary["added"] > 0 or summary["modified"] > 0 or summary["deleted"] > 0
        )

        # Extract upstream version info
        upstream_version = "unknown"
        if fetch_result.update_info:
            upstream_version = (
                getattr(fetch_result.update_info, "latest_sha", None) or "unknown"
            )

        logger.info(
            f"Upstream diff computed for {artifact_id}: {len(file_diffs)} files, "
            f"has_changes={has_changes}, summary={summary}"
        )

        # Clean up temp workspace
        try:
            if fetch_result.temp_workspace and fetch_result.temp_workspace.exists():
                shutil.rmtree(fetch_result.temp_workspace, ignore_errors=True)
                logger.debug(
                    f"Cleaned up temp workspace: {fetch_result.temp_workspace}"
                )
        except Exception as e:
            logger.warning(f"Failed to clean up temp workspace: {e}")

        return ArtifactUpstreamDiffResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type.value,
            collection_name=collection_name,
            upstream_source=artifact.upstream if artifact.upstream else "unknown",
            upstream_version=upstream_version,
            has_changes=has_changes,
            files=file_diffs,
            summary=summary,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Error getting upstream diff for '{artifact_id}': {e}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get artifact upstream diff: {str(e)}",
        )


# ---------------------------------------------------------------------------
# get_artifact_source_project_diff
# ---------------------------------------------------------------------------


@router.get(
    "/{artifact_id}/source-project-diff",
    response_model=ArtifactDiffResponse,
    summary="Get source-to-project diff",
    description="Compare artifact upstream source directly against project deployment",
    responses={
        200: {"description": "Successfully retrieved source-project diff"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid request or missing project_path",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_artifact_source_project_diff(
    artifact_id: str,
    artifact_repo: ArtifactRepoDep,
    history_repo: DbArtifactHistoryRepoDep,
    settings: SettingsDep,
    _token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    artifact_mgr: ArtifactManagerOptDep = None,
    collection_mgr: CollectionManagerOptDep = None,
    project_path: str = Query(
        ...,
        description="Path to project deployment directory",
    ),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
    summary_only: bool = Query(
        default=False,
        description="Return only summary counts and file metadata without unified diffs",
    ),
    include_unified_diff: bool = Query(
        default=True,
        description="Include unified diff content in file results. Set to False for summary view.",
    ),
    file_paths: Optional[str] = Query(
        default=None,
        description="Comma-separated file paths to include unified diffs for. When set, only these files get full diff content; others get status/hash only.",
    ),
) -> ArtifactDiffResponse:
    """Get diff between upstream source and project deployment, skipping collection.

    Fetches the latest upstream version from GitHub and compares it directly
    against the deployed version in a project, bypassing the collection copy.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        artifact_repo: Artifact repository (enterprise path)
        history_repo: Artifact history repository (enterprise path)
        settings: API settings (controls edition-based branching)
        _token: Authentication token
        auth_context: Caller auth context
        artifact_mgr: Artifact manager (local edition only)
        collection_mgr: Collection manager (local edition only)
        project_path: Path to project directory containing deployed artifact
        collection: Optional collection filter
        summary_only: Return only summary without full diffs
        include_unified_diff: Include unified diff content
        file_paths: Comma-separated specific file paths for diff

    Returns:
        ArtifactDiffResponse with file-level diffs and summary

    Raises:
        HTTPException: If artifact not found, project not found, or on error
    """
    # -----------------------------------------------------------------------
    # Enterprise path
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        collection_name = collection or "default"
        requested_files = set(file_paths.split(",")) if file_paths else None

        try:
            file_diffs, summary = _build_diff_from_db_content(
                artifact_id=artifact_id,
                artifact_name=artifact_name,
                artifact_type_str=artifact_type_str,
                collection_name=collection_name,
                history_repo=history_repo,
                artifact_repo=artifact_repo,
                summary_only=summary_only,
                include_unified_diff=include_unified_diff,
                requested_files=requested_files,
            )
        except Exception as exc:
            logger.warning(
                "Enterprise source-project diff failed for %s: %s", artifact_id, exc
            )
            return _enterprise_empty_diff(
                artifact_id,
                artifact_name,
                artifact_type_str,
                collection_name,
                project_path,
            )

        has_changes = (
            summary["added"] > 0 or summary["modified"] > 0 or summary["deleted"] > 0
        )
        return ArtifactDiffResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type_str,
            collection_name=collection_name,
            project_path=project_path,
            has_changes=has_changes,
            files=file_diffs,
            summary=summary,
        )

    # -----------------------------------------------------------------------
    # Local path — verbatim copy from _legacy.py get_artifact_source_project_diff
    # -----------------------------------------------------------------------
    try:
        logger.info(
            f"Getting source-project diff for artifact: {artifact_id} "
            f"(project={project_path}, collection={collection})"
        )

        # Parse optional file-path filter for lazy per-file diff loading
        requested_files = set(file_paths.split(",")) if file_paths else None

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Validate project path
        proj_path = PathLib(project_path)
        if not proj_path.exists():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Project path does not exist: {project_path}",
            )

        # Find deployment in project
        deployment = DeploymentTracker.get_deployment(
            proj_path, artifact_name, artifact_type.value
        )

        if deployment:
            collection_name = collection or deployment.from_collection
            inferred_artifact_path = deployment.artifact_path
        else:
            logger.debug(
                f"No deployment record for {artifact_id}, attempting to infer paths"
            )
            collection_name = collection or "default"
            possible_paths = _get_possible_artifact_paths(artifact_type, artifact_name)
            inferred_artifact_path = None

            for path in possible_paths:
                full_path = proj_path / ".claude" / path
                if full_path.exists():
                    inferred_artifact_path = path
                    break

            if not inferred_artifact_path:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Artifact '{artifact_id}' not found in project {project_path}",
                )

        # Find artifact in collection (with fallback across all collections)
        artifact, resolved_collection = _pkg_find_artifact_in_collections(
            artifact_name,
            artifact_type,
            collection_mgr,
            preferred_collection=collection_name,
            artifact_repo=artifact_repo,
        )

        if not artifact:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found in any collection",
            )
        collection_name = resolved_collection

        # Check upstream support
        is_github_backed = artifact.origin == "github" or (
            artifact.origin == "marketplace" and artifact.origin_source == "github"
        )
        if not is_github_backed:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Artifact origin '{artifact.origin}' does not support source diff. Only GitHub-backed artifacts are supported.",
            )

        if not artifact.upstream:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Artifact does not have upstream tracking configured",
            )

        # Fetch latest upstream version — check short-lived cache first to avoid
        # redundant GitHub API calls when the sync modal fires both upstream-diff
        # and source-project-diff for the same artifact.
        _cache_key = f"{artifact_id}:{collection_name or 'default'}"
        _cached_fetch = None
        try:
            _cached_fetch = _pkg_get_upstream_cache().get(_cache_key)
        except Exception:
            logger.warning(
                f"Upstream cache get failed for {_cache_key}, falling through to fetch"
            )
        if _cached_fetch is not None:
            logger.info(
                f"Using cached upstream fetch for source-project diff: {artifact_id}"
            )
            fetch_result = _cached_fetch
        else:
            logger.info(f"Fetching upstream for source-project diff: {artifact_id}")
            with PerfTimer(
                "router.get_artifact_source_project_diff.fetch_upstream",
                artifact_id=artifact_id,
                collection=collection_name,
            ):
                fetch_result = artifact_mgr.fetch_update(
                    artifact_name=artifact_name,
                    artifact_type=artifact_type,
                    collection_name=collection_name,
                )
            if not fetch_result.error:
                try:
                    _pkg_get_upstream_cache().put(_cache_key, fetch_result)
                except Exception:
                    logger.warning(f"Upstream cache put failed for {_cache_key}")

        try:
            if fetch_result.error:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to fetch upstream: {fetch_result.error}",
                )

            # Normalize artifact path to handle duplicate extensions
            normalized_artifact_path = _normalize_artifact_path(artifact.path)

            # Determine upstream artifact path
            if fetch_result.has_update and fetch_result.fetch_result:
                upstream_artifact_path = fetch_result.fetch_result.artifact_path
            elif not fetch_result.has_update:
                # No upstream update means collection matches upstream; use collection copy
                collection_path = collection_mgr.config.get_collection_path(
                    collection_name
                )
                upstream_artifact_path = collection_path / normalized_artifact_path
            else:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Failed to resolve upstream artifact path",
                )

            project_artifact_path = proj_path / ".claude" / inferred_artifact_path

            # Handle missing artifacts gracefully
            upstream_exists = upstream_artifact_path.exists()
            project_exists = project_artifact_path.exists()

            if not upstream_exists and not project_exists:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Neither upstream nor project artifact exists for {artifact_id}",
                )

            # Log resilience cases
            if not upstream_exists:
                logger.warning(
                    f"Upstream artifact missing but project exists: {artifact_id} "
                    f"(upstream_path={upstream_artifact_path}, project_path={project_artifact_path}). "
                    "Returning diff with all project files marked as 'deleted'."
                )
            elif not project_exists:
                logger.warning(
                    f"Project artifact missing but upstream exists: {artifact_id} "
                    f"(upstream_path={upstream_artifact_path}, project_path={project_artifact_path}). "
                    "Returning diff with all upstream files marked as 'added'."
                )

            # Collect files from both locations — timed to measure filesystem enumeration
            with PerfTimer(
                "router.get_artifact_source_project_diff.enumerate_files",
                artifact_id=artifact_id,
                project_path=project_path,
            ):
                source_files = set()
                project_files = set()
                exclude_dirs = set(settings.diff_exclude_dirs)

                if upstream_exists:
                    if upstream_artifact_path.is_dir():
                        source_files = {
                            str(f.relative_to(upstream_artifact_path))
                            for f in iter_artifact_files(
                                upstream_artifact_path, exclude_dirs
                            )
                        }
                    else:
                        source_files = {upstream_artifact_path.name}

                if project_exists:
                    if project_artifact_path.is_dir():
                        project_files = {
                            str(f.relative_to(project_artifact_path))
                            for f in iter_artifact_files(
                                project_artifact_path, exclude_dirs
                            )
                        }
                    else:
                        project_files = {project_artifact_path.name}

            all_files = sorted(source_files | project_files)

            def compute_file_hash(file_path: PathLib) -> str:
                hasher = hashlib.sha256()
                with open(file_path, "rb") as f:
                    while True:
                        chunk = f.read(8192)
                        if not chunk:
                            break
                        hasher.update(chunk)
                return hasher.hexdigest()

            def is_binary_file(file_path: PathLib) -> bool:
                try:
                    with open(file_path, "rb") as f:
                        chunk = f.read(8192)
                        return b"\x00" in chunk
                except Exception:
                    return True

            file_diffs: List[FileDiff] = []
            summary = {"added": 0, "modified": 0, "deleted": 0, "unchanged": 0}

            # Diff computation — timed to measure hashing + diff generation cost
            with PerfTimer(
                "router.get_artifact_source_project_diff.compute",
                artifact_id=artifact_id,
                file_count=len(all_files),
            ):
                for file_rel_path in all_files:
                    in_source = file_rel_path in source_files
                    in_project = file_rel_path in project_files

                    if in_source and in_project:
                        src_file = (
                            upstream_artifact_path / file_rel_path
                            if upstream_artifact_path.is_dir()
                            else upstream_artifact_path
                        )
                        proj_file = (
                            project_artifact_path / file_rel_path
                            if project_artifact_path.is_dir()
                            else project_artifact_path
                        )

                        src_hash = compute_file_hash(src_file)
                        proj_hash = compute_file_hash(proj_file)

                        if src_hash == proj_hash:
                            file_status = "unchanged"
                            unified_diff = None
                            summary["unchanged"] += 1
                        else:
                            file_status = "modified"
                            summary["modified"] += 1
                            unified_diff = None
                            skip_diff = summary_only or not include_unified_diff
                            if (
                                not skip_diff
                                and requested_files is not None
                                and file_rel_path not in requested_files
                            ):
                                skip_diff = True
                            if (
                                not skip_diff
                                and not is_binary_file(src_file)
                                and not is_binary_file(proj_file)
                            ):
                                try:
                                    with open(src_file, "r", encoding="utf-8") as f:
                                        src_lines = f.readlines()
                                    with open(proj_file, "r", encoding="utf-8") as f:
                                        proj_lines = f.readlines()
                                    diff_lines = difflib.unified_diff(
                                        src_lines,
                                        proj_lines,
                                        fromfile=f"source/{file_rel_path}",
                                        tofile=f"project/{file_rel_path}",
                                        lineterm="",
                                    )
                                    unified_diff = "\n".join(diff_lines)
                                except Exception as e:
                                    logger.warning(
                                        f"Failed to generate diff for {file_rel_path}: {e}"
                                    )
                                    unified_diff = f"[Error generating diff: {str(e)}]"

                        file_diffs.append(
                            FileDiff(
                                file_path=file_rel_path,
                                status=file_status,
                                collection_hash=src_hash,
                                project_hash=proj_hash,
                                unified_diff=unified_diff,
                            )
                        )

                    elif in_source and not in_project:
                        # File only in source (would be added when deploying)
                        file_status = "added"
                        summary["added"] += 1
                        if upstream_exists:
                            src_file = (
                                upstream_artifact_path / file_rel_path
                                if upstream_artifact_path.is_dir()
                                else upstream_artifact_path
                            )
                            src_hash = compute_file_hash(src_file)
                        else:
                            src_hash = None
                        file_diffs.append(
                            FileDiff(
                                file_path=file_rel_path,
                                status=file_status,
                                collection_hash=src_hash,
                                project_hash=None,
                                unified_diff=None,
                            )
                        )

                    elif not in_source and in_project:
                        # File only in project (would be deleted when syncing from source)
                        file_status = "deleted"
                        summary["deleted"] += 1
                        if project_exists:
                            proj_file = (
                                project_artifact_path / file_rel_path
                                if project_artifact_path.is_dir()
                                else project_artifact_path
                            )
                            proj_hash = compute_file_hash(proj_file)
                        else:
                            proj_hash = None
                        file_diffs.append(
                            FileDiff(
                                file_path=file_rel_path,
                                status=file_status,
                                collection_hash=None,
                                project_hash=proj_hash,
                                unified_diff=None,
                            )
                        )

            has_changes = (
                summary["added"] > 0
                or summary["modified"] > 0
                or summary["deleted"] > 0
            )

            logger.info(
                f"Source-project diff computed for {artifact_id}: {len(file_diffs)} files, "
                f"has_changes={has_changes}, summary={summary}"
            )

            return ArtifactDiffResponse(
                artifact_id=artifact_id,
                artifact_name=artifact_name,
                artifact_type=artifact_type.value,
                collection_name=collection_name,
                project_path=str(proj_path),
                has_changes=has_changes,
                files=file_diffs,
                summary=summary,
            )
        finally:
            # Clean up temp workspace if one was created
            try:
                if fetch_result.temp_workspace and fetch_result.temp_workspace.exists():
                    shutil.rmtree(fetch_result.temp_workspace, ignore_errors=True)
            except Exception as e:
                logger.warning(f"Failed to clean up temp workspace: {e}")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Error getting source-project diff for '{artifact_id}': {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get source-project diff: {str(e)}",
        )


# ---------------------------------------------------------------------------
# get_skill_sync_diff
# ---------------------------------------------------------------------------


@router.get(
    "/{artifact_id}/sync-diff",
    summary="Get per-member version comparison rows for a skill",
    description=(
        "Return a flat list of VersionComparisonRow objects for the given skill artifact "
        "and its composite members.  The first element is always the parent skill row "
        "(is_member=False); subsequent elements are member rows (is_member=True).  "
        "Returns a single-element list for skills without embedded members.  "
        "Requires collection and project_id query parameters."
    ),
    responses={
        200: {"description": "Successfully retrieved sync diff rows"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid artifact ID or missing params",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_skill_sync_diff(
    artifact_id: str,
    settings: SettingsDep,
    db_session: DbSessionDep,
    _token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    collection_mgr: CollectionManagerOptDep = None,
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (uses active collection if omitted)",
    ),
    project_id: Optional[str] = Query(
        default=None,
        description="Project identifier for deployed_version lookup",
    ),
):
    """Return hierarchical version comparison rows for a skill and its members.

    Uses ``compute_skill_sync_diff()`` from the sync diff service to build one
    row per artifact (parent + members) with ``source_version``,
    ``collection_version``, and ``deployed_version`` fields.

    This endpoint is local-edition only.  In enterprise mode it returns an
    empty list (no 501) so the frontend always gets a valid payload.

    Args:
        artifact_id: Artifact identifier in ``type:name`` format.
        settings: API settings (controls edition-based branching).
        db_session: Per-request SQLAlchemy session.
        _token: Authentication token dependency.
        auth_context: Caller auth context.
        collection_mgr: Collection manager (local edition only).
        collection: Collection name; defaults to active collection.
        project_id: Project identifier for deployed_version resolution.

    Returns:
        JSON list of VersionComparisonRow-shaped dicts.

    Raises:
        HTTPException 400: Invalid artifact_id or missing required params.
        HTTPException 404: Artifact not found.
        HTTPException 500: Unexpected database or service error.
    """
    # -----------------------------------------------------------------------
    # Enterprise path — operation requires local filesystem; return empty list
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        try:
            parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )
        logger.debug(
            "sync-diff is local-only; returning empty list for enterprise edition (artifact=%s)",
            artifact_id,
        )
        return []

    # -----------------------------------------------------------------------
    # Local path — verbatim copy from _legacy.py get_skill_sync_diff
    # -----------------------------------------------------------------------
    from skillmeat.core.services.sync_diff_service import (
        compute_skill_sync_diff,
    )  # noqa: PLC0415

    try:
        # Validate artifact ID
        try:
            parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        collection_name = collection or collection_mgr.get_active_collection_name()
        if not collection_name:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No active collection found. Pass the 'collection' query parameter.",
            )

        # Resolve a db_path by looking up the collection path
        try:
            collection_path = collection_mgr.config.get_collection_path(collection_name)
            db_path = str(collection_path / "cache.db")
        except Exception:
            db_path = None

        effective_project_id = project_id or ""

        rows = compute_skill_sync_diff(
            artifact_id=artifact_id,
            collection_id=collection_name,
            project_id=effective_project_id,
            db_path=db_path or "",
            _session=db_session,  # Always use the injected session; fallback handled in service
        )

        return [
            {
                "artifact_id": r.artifact_id,
                "artifact_name": r.artifact_name,
                "artifact_type": r.artifact_type,
                "source_version": r.source_version,
                "collection_version": r.collection_version,
                "deployed_version": r.deployed_version,
                "is_member": r.is_member,
                "parent_artifact_id": r.parent_artifact_id,
            }
            for r in rows
        ]

    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.error(
            "Failed to compute sync diff for '%s': %s", artifact_id, e, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to compute sync diff: {str(e)}",
        )
