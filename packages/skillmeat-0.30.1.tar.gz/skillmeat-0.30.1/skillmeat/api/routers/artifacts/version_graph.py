"""Version graph endpoint for the artifacts router — dual-mode (local + enterprise).

Contains:
  - get_version_graph    GET    /artifacts/{artifact_id}/version-graph

The local path traverses filesystem deployments and collection directories via
``build_version_graph`` (defined in ``_legacy.py``).

The enterprise path returns 501 Not Implemented — filesystem traversal is not
available in enterprise mode and a DB-backed replacement has not yet been
implemented.
"""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from skillmeat.api.dependencies import (
    ArtifactManagerDep,
    ArtifactManagerOptDep,
    CollectionManagerDep,
    CollectionManagerOptDep,
    SettingsDep,
    get_auth_context,
    require_auth,
    verify_api_key,
)
from skillmeat.api.middleware.auth import TokenDep
from skillmeat.api.schemas.artifacts import VersionGraphResponse
from skillmeat.api.schemas.common import ErrorResponse
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.core.artifact import ArtifactType

from ._helpers import parse_artifact_id

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/artifacts",
    tags=["artifacts"],
    dependencies=[Depends(verify_api_key)],
)


# ---------------------------------------------------------------------------
# GET /{artifact_id}/version-graph
# ---------------------------------------------------------------------------


@router.get(
    "/{artifact_id}/version-graph",
    response_model=VersionGraphResponse,
    summary="Get artifact version graph",
    description="Build and return version graph showing deployment hierarchy across all projects",
    responses={
        200: {
            "description": "Successfully retrieved version graph",
            "headers": {
                "Cache-Control": {
                    "description": "Caching directives",
                    "schema": {"type": "string", "example": "max-age=300"},
                }
            },
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_version_graph(
    artifact_id: str,
    _artifact_mgr: ArtifactManagerOptDep,
    collection_mgr: CollectionManagerOptDep,
    settings: SettingsDep,
    _token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    collection: Optional[str] = Query(
        default=None,
        description="Filter to specific collection",
    ),
) -> VersionGraphResponse:
    """Get complete version graph for an artifact.

    Returns a hierarchical tree structure showing:
    - Collection version as root node
    - Project deployments as child nodes
    - Content hashes and modification status at each node
    - Aggregated statistics

    The graph enables visualization of how an artifact has been
    deployed across projects and which deployments have local modifications.

    Results are cached for 5 minutes (Cache-Control header).

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        _artifact_mgr: Artifact manager dependency (unused, reserved for future use)
        collection_mgr: Collection manager dependency
        settings: API settings for edition-based branching
        _token: Authentication token (dependency injection)
        auth_context: Caller auth context
        collection: Optional collection filter

    Returns:
        VersionGraphResponse with complete hierarchy

    Raises:
        HTTPException: If artifact not found or on error

    Example:
        GET /api/v1/artifacts/skill:pdf-processor/version-graph?collection=default
    """
    # Version graph traversal reads local filesystem deployments and collection
    # directories — not yet available in enterprise mode.
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="Version graph is not yet available in enterprise edition",
        )

    assert collection_mgr is not None, "collection_mgr required for local edition"

    # Import here to avoid circular dependency — build_version_graph is defined
    # in _legacy.py which imports from this package.
    from skillmeat.api.routers.artifacts._legacy import build_version_graph

    try:
        logger.info(
            f"Building version graph for artifact: {artifact_id} (collection={collection})"
        )

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Build version graph
        version_graph = await build_version_graph(
            artifact_name=artifact_name,
            artifact_type=artifact_type,
            collection_name=collection,
            collection_mgr=collection_mgr,
        )

        # Check if we found the artifact anywhere
        if (
            version_graph.root is None
            and version_graph.statistics["total_deployments"] == 0
        ):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found in any collection or project",
            )

        logger.info(
            f"Version graph built: {version_graph.statistics['total_deployments']} deployments, "
            f"{version_graph.statistics['modified_count']} modified"
        )

        return version_graph

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Error building version graph for '{artifact_id}': {e}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to build version graph: {str(e)}",
        )
