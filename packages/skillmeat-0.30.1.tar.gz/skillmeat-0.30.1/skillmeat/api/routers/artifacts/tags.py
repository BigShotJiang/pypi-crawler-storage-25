"""Tag association endpoints for the artifacts router — dual-mode (local + enterprise).

Contains:
  - add_tag_to_artifact    POST   /artifacts/{artifact_id}/tags/{tag_id}
  - remove_tag_from_artifact DELETE /artifacts/{artifact_id}/tags/{tag_id}

Each endpoint branches on ``settings.edition == "enterprise"`` and delegates
to the appropriate handler.  The local handler is copied verbatim from
``_legacy.py`` so behaviour is identical.  The enterprise handler uses
``ITagRepository.assign()`` / ``ITagRepository.unassign()`` only — it never
accesses ``collection_mgr``.
"""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status

from skillmeat.api.dependencies import (
    ArtifactRepoDep,
    CollectionManagerOptDep,
    SettingsDep,
    TagRepoDep,
    require_auth,
    verify_api_key,
)
from skillmeat.api.middleware.auth import TokenDep
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.core.artifact import ArtifactType

from ._helpers import parse_artifact_id

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/artifacts",
    tags=["artifacts"],
    dependencies=[Depends(verify_api_key)],
)


# ---------------------------------------------------------------------------
# POST /{artifact_id}/tags/{tag_id}  — add tag to artifact
# ---------------------------------------------------------------------------


@router.post(
    "/{artifact_id}/tags/{tag_id}",
    status_code=status.HTTP_201_CREATED,
    summary="Add tag to artifact",
    description="Associate a tag with an artifact",
)
async def add_tag_to_artifact(
    artifact_id: str,
    tag_id: str,
    artifact_repo: ArtifactRepoDep,
    settings: SettingsDep,
    tag_repo: TagRepoDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    collection_mgr: CollectionManagerOptDep = None,
) -> dict[str, str]:
    """Add a tag to an artifact.

    Args:
        artifact_id: Unique identifier of the artifact (format: ``"type:name"``)
        tag_id: Unique identifier of the tag
        artifact_repo: Artifact repository for UUID resolution
        settings: API settings (controls edition-based branching)
        tag_repo: Tag repository (enterprise path only)
        token: API token for authentication
        auth_context: Caller auth context
        collection_mgr: Collection manager (local edition only; None in enterprise)

    Returns:
        Success message with artifact and tag IDs

    Raises:
        HTTPException: 400 if association already exists or invalid request
        HTTPException: 404 if artifact or tag not found
    """
    # -----------------------------------------------------------------------
    # Enterprise path
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        try:
            tag_repo.assign(tag_id, artifact_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
            )
        return {"message": f"Tag {tag_id} added to artifact {artifact_id}"}

    # -----------------------------------------------------------------------
    # Local path (copied verbatim from _legacy.py)
    # -----------------------------------------------------------------------
    from skillmeat.core.services import TagService

    service = TagService()

    # Resolve type:name artifact_id → UUID via repository (ADR-007 stable identity)
    art_type_str, art_name = artifact_id.split(":", 1)
    artifact_uuid = artifact_repo.resolve_uuid_by_type_name(art_type_str, art_name)
    if not artifact_uuid:
        raise HTTPException(
            status_code=404, detail=f"Artifact '{artifact_id}' not found"
        )

    try:
        service.add_tag_to_artifact(artifact_uuid, tag_id)

        # Write-through: sync tags to CollectionArtifact.tags_json and filesystem
        updated_tags = [t.name for t in service.get_artifact_tags(artifact_uuid)]

        # Update CollectionArtifact.tags_json in DB cache via repository.
        try:
            artifact_repo.update_collection_tags(artifact_uuid, updated_tags)
        except Exception as cache_err:
            logger.warning(
                f"Failed to update CollectionArtifact tags cache: {cache_err}"
            )

        # Update filesystem artifact
        try:
            artifact_type_str_fs, artifact_name_fs = parse_artifact_id(artifact_id)
            artifact_type_fs = ArtifactType(artifact_type_str_fs)
            collection_name = collection_mgr.get_active_collection_name()
            coll = collection_mgr.load_collection(collection_name)
            artifact = coll.find_artifact(artifact_name_fs, artifact_type_fs)
            if artifact:
                artifact.tags = updated_tags
                collection_mgr.save_collection(coll)
                logger.info(
                    f"Updated filesystem tags for {artifact_id}: {updated_tags}"
                )
        except Exception as fs_err:
            logger.warning(f"Failed to update filesystem artifact tags: {fs_err}")

        return {"message": f"Tag {tag_id} added to artifact {artifact_id}"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except LookupError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ---------------------------------------------------------------------------
# DELETE /{artifact_id}/tags/{tag_id}  — remove tag from artifact
# ---------------------------------------------------------------------------


@router.delete(
    "/{artifact_id}/tags/{tag_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Remove tag from artifact",
    description="Remove a tag from an artifact",
)
async def remove_tag_from_artifact(
    artifact_id: str,
    tag_id: str,
    artifact_repo: ArtifactRepoDep,
    settings: SettingsDep,
    tag_repo: TagRepoDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    collection_mgr: CollectionManagerOptDep = None,
) -> None:
    """Remove a tag from an artifact.

    Args:
        artifact_id: Unique identifier of the artifact (format: ``"type:name"``)
        tag_id: Unique identifier of the tag
        artifact_repo: Artifact repository for UUID resolution
        settings: API settings (controls edition-based branching)
        tag_repo: Tag repository (enterprise path only)
        token: API token for authentication
        auth_context: Caller auth context
        collection_mgr: Collection manager (local edition only; None in enterprise)

    Returns:
        None (204 No Content)

    Raises:
        HTTPException: 400 if invalid request
        HTTPException: 404 if tag association not found
    """
    # -----------------------------------------------------------------------
    # Enterprise path
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        try:
            removed = tag_repo.unassign(tag_id, artifact_id)
        except KeyError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
            )
        if not removed:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Tag association not found",
            )
        return

    # -----------------------------------------------------------------------
    # Local path (copied verbatim from _legacy.py)
    # -----------------------------------------------------------------------
    from skillmeat.core.services import TagService

    service = TagService()

    # Resolve type:name artifact_id → UUID via repository (ADR-007 stable identity)
    art_type_str, art_name = artifact_id.split(":", 1)
    artifact_uuid = artifact_repo.resolve_uuid_by_type_name(art_type_str, art_name)
    if not artifact_uuid:
        raise HTTPException(
            status_code=404, detail=f"Artifact '{artifact_id}' not found"
        )

    try:
        if not service.remove_tag_from_artifact(artifact_uuid, tag_id):
            raise HTTPException(status_code=404, detail="Tag association not found")

        # Write-through: sync tags to CollectionArtifact.tags_json and filesystem
        updated_tags = [t.name for t in service.get_artifact_tags(artifact_uuid)]

        # Update CollectionArtifact.tags_json in DB cache via repository.
        try:
            artifact_repo.update_collection_tags(artifact_uuid, updated_tags)
        except Exception as cache_err:
            logger.warning(
                f"Failed to update CollectionArtifact tags cache: {cache_err}"
            )

        # Update filesystem artifact
        try:
            artifact_type_str_fs, artifact_name_fs = parse_artifact_id(artifact_id)
            artifact_type_fs = ArtifactType(artifact_type_str_fs)
            collection_name = collection_mgr.get_active_collection_name()
            coll = collection_mgr.load_collection(collection_name)
            artifact = coll.find_artifact(artifact_name_fs, artifact_type_fs)
            if artifact:
                artifact.tags = updated_tags
                collection_mgr.save_collection(coll)
                logger.info(
                    f"Updated filesystem tags for {artifact_id}: {updated_tags}"
                )
        except Exception as fs_err:
            logger.warning(f"Failed to update filesystem artifact tags: {fs_err}")

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
