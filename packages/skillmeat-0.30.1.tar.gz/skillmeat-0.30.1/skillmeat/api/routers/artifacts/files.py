"""File content endpoints for the artifacts router — dual-mode (local + enterprise).

Contains:
  - list_artifact_files        GET  /{artifact_id}/files
  - get_artifact_file_content  GET  /{artifact_id}/files/{file_path}
  - update_artifact_file_content PUT /{artifact_id}/files/{file_path}
  - create_artifact_file       POST /{artifact_id}/files/{file_path}
  - delete_artifact_file       DELETE /{artifact_id}/files/{file_path}

Each handler branches on ``settings.edition == "enterprise"``:
  - Enterprise path: delegates to ``EnterpriseFileContentService`` using CAS
    blob storage with SHA-256 deduplication.
  - Local path: uses ``ArtifactManager`` for filesystem-based file operations.
"""

from __future__ import annotations

import logging
from pathlib import Path as PathLib
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from skillmeat.api.dependencies import (
    ArtifactManagerOptDep,
    ArtifactRepoDep,
    CollectionManagerOptDep,
    EnterpriseFileContentServiceDep,
    SettingsDep,
    get_auth_context,
    require_auth,
    verify_api_key,
)
from skillmeat.core.services.enterprise_file_content import (
    BlobTooLargeError,
    CASArtifactNotFoundError,
    CASFileAlreadyExistsError,
    CASFileNotFoundError,
    CASVersionNotFoundError,
)
from skillmeat.api.middleware.auth import TokenDep
from skillmeat.api.schemas.artifacts import (
    FileContentResponse,
    FileListResponse,
    FileNode,
    FileUpdateRequest,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.common import ErrorResponse
from skillmeat.api.services import refresh_single_artifact_cache
from skillmeat.cache.models import get_session
from skillmeat.core.artifact import ArtifactType

from ._helpers import (
    _find_artifact_in_collections,
    parse_artifact_id,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/artifacts",
    tags=["artifacts"],
    dependencies=[Depends(verify_api_key)],
)

# ---------------------------------------------------------------------------
# Enterprise 501 message — must contain the word "enterprise"
# ---------------------------------------------------------------------------

_ENTERPRISE_501_MSG = (
    "File content operations are not available in enterprise mode. "
    "Content is stored in the database. Use the artifact content API instead."
)

# ---------------------------------------------------------------------------
# Local helper: refresh DB cache after mutation (non-fatal)
# ---------------------------------------------------------------------------


def _refresh_cache_safe(
    artifact_mgr,
    artifact_id: str,
    collection_name: str,
) -> None:
    """Refresh DB cache after a file mutation, swallowing errors.

    Args:
        artifact_mgr: ArtifactManager instance.
        artifact_id: Artifact identifier string.
        collection_name: Name of the collection containing the artifact.
    """
    try:
        db_session = get_session()
        try:
            refresh_single_artifact_cache(
                db_session,
                artifact_mgr,
                artifact_id,
                collection_name,
            )
        finally:
            db_session.close()
    except Exception as cache_err:
        logger.warning(f"Cache refresh failed for {artifact_id}: {cache_err}")


# ---------------------------------------------------------------------------
# Endpoint: list_artifact_files
# ---------------------------------------------------------------------------


@router.get(
    "/{artifact_id}/files",
    response_model=FileListResponse,
    summary="List artifact files",
    description="List all files and directories in an artifact",
    responses={
        200: {"description": "Successfully retrieved file list"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def list_artifact_files(
    artifact_id: str,
    _artifact_mgr: ArtifactManagerOptDep,
    artifact_repo: ArtifactRepoDep,
    collection_mgr: CollectionManagerOptDep,
    _token: TokenDep,
    settings: SettingsDep,
    enterprise_svc: EnterpriseFileContentServiceDep,
    auth_context: AuthContext = Depends(get_auth_context),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
    project_id: Optional[str] = Query(
        default=None,
        description="URL-encoded project path (required when collection=discovered)",
    ),
) -> FileListResponse:
    """List all files in an artifact.

    Returns a nested tree structure showing all files and directories
    within the artifact. Hidden files and directories are excluded
    (.git, __pycache__, node_modules, etc.).

    In enterprise mode, returns the CAS-backed file manifest from the database.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        _artifact_mgr: Artifact manager dependency (unused, reserved for future use)
        artifact_repo: Artifact repository dependency
        collection_mgr: Collection manager dependency
        _token: Authentication token (dependency injection)
        settings: API settings instance
        enterprise_svc: Enterprise CAS file content service (None in local edition)
        auth_context: Authenticated user context
        collection: Optional collection filter
        project_id: URL-encoded project path (required when collection=discovered)

    Returns:
        FileListResponse with nested file tree

    Raises:
        HTTPException: 404 if artifact not found; 500 on error
    """
    if settings.edition == "enterprise":
        # Enterprise path: serve files from CAS manifest in the database.
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )
        try:
            entries = enterprise_svc.list_files(artifact_name)
        except CASArtifactNotFoundError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )
        except CASVersionNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(exc),
            )
        except Exception as exc:
            logger.error(
                "Enterprise list_files failed for '%s': %s", artifact_id, exc, exc_info=True
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to list artifact files: {exc}",
            )
        # Convert flat FileEntry dicts to FileNode list (no tree nesting — flat list).
        files: List[FileNode] = [
            FileNode(
                name=e["path"].split("/")[-1],
                path=e["path"],
                type="file",
                size=e.get("size"),
                children=None,
            )
            for e in entries
        ]
        return FileListResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type_str,
            collection_name="enterprise",
            files=files,
        )

    try:
        logger.info(
            f"Listing files for artifact: {artifact_id} (collection={collection})"
        )

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # --- Discovered artifact fast path ---
        if collection == "discovered":
            if not project_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="project_id query parameter is required when collection=discovered",
                )

            from urllib.parse import unquote as _url_unquote
            from skillmeat.core.discovery import ArtifactDiscoveryService

            decoded_project_path = _url_unquote(project_id)
            project_path_obj = PathLib(decoded_project_path)

            if not project_path_obj.is_absolute() or not project_path_obj.exists():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid or non-existent project path: {decoded_project_path}",
                )

            # Run discovery to find the matching artifact's path.
            discovery_service = ArtifactDiscoveryService(
                project_path_obj, scan_mode="project"
            )
            discovery_result = discovery_service.discover_artifacts(manifest=None)

            matched_path: Optional[PathLib] = None
            for da in discovery_result.artifacts:
                if da.type == artifact_type_str and da.name == artifact_name:
                    matched_path = PathLib(da.path)
                    break

            if matched_path is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Discovered artifact '{artifact_id}' not found in project '{decoded_project_path}'",
                )

            if not matched_path.exists():
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Artifact path does not exist: {matched_path}",
                )

            artifact_path = matched_path
            collection_name = "discovered"

        else:
            # --- Normal collection lookup path ---
            artifact, collection_name = _find_artifact_in_collections(
                artifact_name,
                artifact_type,
                collection_mgr,
                preferred_collection=collection,
                artifact_repo=artifact_repo,
            )

            if not artifact:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Artifact '{artifact_id}' not found",
                )

            # Get artifact path
            collection_path = collection_mgr.config.get_collection_path(collection_name)
            artifact_path = collection_path / artifact.path

            if not artifact_path.exists():
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Artifact path does not exist: {artifact_path}",
                )

        # Define hidden/excluded patterns
        EXCLUDED_PATTERNS = {
            ".git",
            ".gitignore",
            "__pycache__",
            "node_modules",
            ".DS_Store",
            "*.pyc",
            "*.pyo",
            ".pytest_cache",
            ".mypy_cache",
            ".ruff_cache",
            ".venv",
            "venv",
        }

        def should_exclude(name: str) -> bool:
            """Check if file/directory should be excluded."""
            # Exclude hidden files (starting with .)
            if name.startswith("."):
                return True
            # Exclude common artifacts
            if name in EXCLUDED_PATTERNS:
                return True
            return False

        def build_file_tree(path: PathLib, relative_root: PathLib) -> List[FileNode]:
            """Recursively build file tree structure."""
            nodes: List[FileNode] = []

            try:
                entries = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name))
            except PermissionError:
                logger.warning(f"Permission denied accessing {path}")
                return nodes

            for entry in entries:
                # Skip excluded files/directories
                if should_exclude(entry.name):
                    continue

                rel_path = str(entry.relative_to(relative_root))

                if entry.is_dir():
                    # Recursively process directory
                    children = build_file_tree(entry, relative_root)
                    nodes.append(
                        FileNode(
                            name=entry.name,
                            path=rel_path,
                            type="directory",
                            size=None,
                            children=children,
                        )
                    )
                elif entry.is_file():
                    # Add file node
                    try:
                        file_size = entry.stat().st_size
                    except Exception:
                        file_size = 0

                    nodes.append(
                        FileNode(
                            name=entry.name,
                            path=rel_path,
                            type="file",
                            size=file_size,
                            children=None,
                        )
                    )

            return nodes

        # Build file tree
        if artifact_path.is_dir():
            files = build_file_tree(artifact_path, artifact_path)
        else:
            # Single file artifact
            files = [
                FileNode(
                    name=artifact_path.name,
                    path=artifact_path.name,
                    type="file",
                    size=artifact_path.stat().st_size,
                    children=None,
                )
            ]

        logger.info(f"Listed {len(files)} files for artifact: {artifact_id}")

        return FileListResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type.value,
            collection_name=collection_name,
            files=files,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing files for '{artifact_id}': {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list artifact files: {str(e)}",
        )


# ---------------------------------------------------------------------------
# Endpoint: get_artifact_file_content
# ---------------------------------------------------------------------------


@router.get(
    "/{artifact_id}/files/{file_path:path}",
    response_model=FileContentResponse,
    summary="Get artifact file content",
    description="Get the content of a specific file within an artifact",
    responses={
        200: {"description": "Successfully retrieved file content"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid request or path traversal attempt",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact or file not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_artifact_file_content(
    artifact_id: str,
    file_path: str,
    _artifact_mgr: ArtifactManagerOptDep,
    artifact_repo: ArtifactRepoDep,
    collection_mgr: CollectionManagerOptDep,
    _token: TokenDep,
    settings: SettingsDep,
    enterprise_svc: EnterpriseFileContentServiceDep,
    auth_context: AuthContext = Depends(get_auth_context),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
    project_id: Optional[str] = Query(
        default=None,
        description="URL-encoded project path (required when collection=discovered)",
    ),
) -> FileContentResponse:
    """Get content of a specific file within an artifact.

    **SECURITY: Path Traversal Protection**
    This endpoint implements strict path validation to prevent directory
    traversal attacks. The file_path must:
    - Be within the artifact directory
    - Not contain ".." (parent directory references)
    - Resolve to a path inside the artifact root

    In enterprise mode, content is fetched from the CAS blob store in the database.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        file_path: Relative path to file within artifact (e.g., "SKILL.md" or "src/main.py")
        _artifact_mgr: Artifact manager dependency (unused, reserved for future use)
        artifact_repo: Artifact repository dependency
        collection_mgr: Collection manager dependency
        _token: Authentication token (dependency injection)
        settings: API settings instance
        enterprise_svc: Enterprise CAS file content service (None in local edition)
        auth_context: Authenticated user context
        collection: Optional collection filter
        project_id: URL-encoded project path (required when collection=discovered)

    Returns:
        FileContentResponse with file content and metadata

    Raises:
        HTTPException: 404 if artifact/file not found; 500 on error
    """
    import mimetypes
    import os

    if settings.edition == "enterprise":
        # Enterprise path: fetch content from CAS blob store.
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )
        try:
            content_bytes, mime_type = enterprise_svc.get_content(artifact_name, file_path)
        except CASArtifactNotFoundError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )
        except CASVersionNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(exc),
            )
        except CASFileNotFoundError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"File not found: {file_path}",
            )
        except Exception as exc:
            logger.error(
                "Enterprise get_content failed for '%s/%s': %s",
                artifact_id,
                file_path,
                exc,
                exc_info=True,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to get file content: {exc}",
            )
        try:
            content_str = content_bytes.decode("utf-8")
        except UnicodeDecodeError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"File encoding error: {file_path} is not valid UTF-8",
            )
        return FileContentResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type_str,
            collection_name="enterprise",
            path=file_path,
            content=content_str,
            size=len(content_bytes),
            mime_type=mime_type,
        )

    try:
        logger.info(
            f"Getting file content for artifact: {artifact_id}, file: {file_path} (collection={collection})"
        )

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # --- Discovered artifact fast path ---
        if collection == "discovered":
            if not project_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="project_id query parameter is required when collection=discovered",
                )

            from urllib.parse import unquote as _url_unquote
            from skillmeat.core.discovery import ArtifactDiscoveryService

            decoded_project_path = _url_unquote(project_id)
            project_path_obj = PathLib(decoded_project_path)

            if not project_path_obj.is_absolute() or not project_path_obj.exists():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid or non-existent project path: {decoded_project_path}",
                )

            discovery_service = ArtifactDiscoveryService(
                project_path_obj, scan_mode="project"
            )
            discovery_result = discovery_service.discover_artifacts(manifest=None)

            matched_path: Optional[PathLib] = None
            for da in discovery_result.artifacts:
                if da.type == artifact_type_str and da.name == artifact_name:
                    matched_path = PathLib(da.path)
                    break

            if matched_path is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Discovered artifact '{artifact_id}' not found in project '{decoded_project_path}'",
                )

            artifact_root = matched_path
            collection_name = "discovered"
        else:
            # --- Normal collection lookup path ---
            artifact, collection_name = _find_artifact_in_collections(
                artifact_name,
                artifact_type,
                collection_mgr,
                preferred_collection=collection,
                artifact_repo=artifact_repo,
            )

            if not artifact:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Artifact '{artifact_id}' not found",
                )

            # Get artifact path
            collection_path = collection_mgr.config.get_collection_path(collection_name)
            artifact_root = collection_path / artifact.path

        if not artifact_root.exists():
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Artifact path does not exist: {artifact_root}",
            )

        # Handle single-file artifacts (e.g., agents stored as agents/prd-writer.md)
        # For single-file artifacts, artifact_root IS the file, not a directory
        is_single_file_artifact = artifact_root.is_file()

        # CRITICAL SECURITY: Validate and normalize the file path to prevent path traversal
        try:
            # Normalize the requested path to remove any .., ., etc.
            normalized_file_path = os.path.normpath(file_path)

            # Check for path traversal indicators
            if (
                normalized_file_path.startswith("..")
                or "/.." in normalized_file_path
                or "\\.." in normalized_file_path
            ):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid file path: path traversal attempt detected",
                )

            if is_single_file_artifact:
                # For single-file artifacts, the file_path must match the artifact's filename
                # or be "." (root indicator). The full_path IS the artifact_root itself.
                artifact_filename = artifact_root.name
                if normalized_file_path in (".", artifact_filename):
                    # Valid request for the single file
                    full_path = artifact_root.resolve()
                else:
                    # Requested file doesn't exist in this single-file artifact
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"File not found: {file_path}. This is a single-file artifact containing only '{artifact_filename}'",
                    )
            else:
                # Directory-based artifact: construct path normally
                full_path = (artifact_root / normalized_file_path).resolve()

                # Ensure the resolved path is still within the artifact directory
                artifact_root_resolved = artifact_root.resolve()
                if not str(full_path).startswith(str(artifact_root_resolved)):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid file path: path escapes artifact directory",
                    )

        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Path validation error: {e}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid file path: {str(e)}",
            )

        # Check if file exists
        if not full_path.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"File not found: {file_path}",
            )

        # Check if it's a file (not a directory)
        if not full_path.is_file():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Path is not a file: {file_path}",
            )

        # Get file size
        file_size = full_path.stat().st_size

        # Determine MIME type
        mime_type, _ = mimetypes.guess_type(str(full_path))

        # Check if file is binary
        def is_binary_file(path: PathLib) -> bool:
            """Check if file is binary by reading first 8KB."""
            try:
                with open(path, "rb") as f:
                    chunk = f.read(8192)
                    return b"\x00" in chunk
            except Exception:
                return True

        # Read file content
        try:
            if is_binary_file(full_path):
                # For binary files, return a placeholder
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Cannot display binary file: {file_path}. Binary files are not supported.",
                )

            # Read text file
            with open(full_path, "r", encoding="utf-8") as f:
                content = f.read()

        except UnicodeDecodeError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"File encoding error: {file_path} is not valid UTF-8",
            )
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Error reading file {full_path}: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to read file: {str(e)}",
            )

        logger.info(f"Successfully retrieved file content: {artifact_id}/{file_path}")

        return FileContentResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type.value,
            collection_name=collection_name,
            path=file_path,
            content=content,
            size=file_size,
            mime_type=mime_type,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Error getting file content for '{artifact_id}/{file_path}': {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get file content: {str(e)}",
        )


# ---------------------------------------------------------------------------
# Endpoint: update_artifact_file_content
# ---------------------------------------------------------------------------


@router.put(
    "/{artifact_id}/files/{file_path:path}",
    response_model=FileContentResponse,
    summary="Update artifact file content",
    description="Update the content of a specific file within an artifact",
    responses={
        200: {"description": "Successfully updated file content"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid request, path traversal attempt, or directory path",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact or file not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def update_artifact_file_content(
    artifact_id: str,
    file_path: str,
    request: FileUpdateRequest,
    _artifact_mgr: ArtifactManagerOptDep,
    artifact_repo: ArtifactRepoDep,
    collection_mgr: CollectionManagerOptDep,
    _token: TokenDep,
    settings: SettingsDep,
    enterprise_svc: EnterpriseFileContentServiceDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
) -> FileContentResponse:
    """Update a file's content within an artifact.

    **SECURITY: Path Traversal Protection**
    This endpoint implements strict path validation to prevent directory
    traversal attacks. The file_path must:
    - Be within the artifact directory
    - Not contain ".." (parent directory references)
    - Resolve to a path inside the artifact root

    **Atomic Write**
    File updates are performed atomically using a temporary file and rename
    operation to ensure consistency (local edition). Enterprise edition writes
    to the CAS blob store transactionally.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        file_path: Relative path to file within artifact (e.g., "SKILL.md" or "src/main.py")
        request: File update request containing new content
        _artifact_mgr: Artifact manager dependency
        artifact_repo: Artifact repository dependency
        collection_mgr: Collection manager dependency
        _token: Authentication token (dependency injection)
        settings: API settings instance
        enterprise_svc: Enterprise CAS file content service (None in local edition)
        auth_context: Authenticated user context
        collection: Optional collection filter

    Returns:
        FileContentResponse with updated file content and metadata

    Raises:
        HTTPException: 404 if not found; 400 on validation error; 413 if too large
    """
    import mimetypes
    import os
    import tempfile

    if settings.edition == "enterprise":
        # Enterprise path: update content in CAS blob store.
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )
        try:
            content_bytes = request.content.encode("utf-8")
        except UnicodeEncodeError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid content encoding: {exc}. Content must be valid UTF-8.",
            )
        try:
            import mimetypes as _mimetypes
            mime_type, _ = _mimetypes.guess_type(file_path)
            entry = enterprise_svc.update_content(
                artifact_name, file_path, content_bytes, mime_type=mime_type
            )
        except CASArtifactNotFoundError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )
        except CASFileNotFoundError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"File not found: {file_path}",
            )
        except BlobTooLargeError as exc:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=str(exc),
            )
        except Exception as exc:
            logger.error(
                "Enterprise update_content failed for '%s/%s': %s",
                artifact_id,
                file_path,
                exc,
                exc_info=True,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to update file content: {exc}",
            )
        return FileContentResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type_str,
            collection_name="enterprise",
            path=file_path,
            content=request.content,
            size=entry.get("size", len(content_bytes)),
            mime_type=entry.get("mime_type"),
        )

    try:
        logger.info(
            f"Updating file content for artifact: {artifact_id}, file: {file_path} (collection={collection})"
        )

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Find artifact (with fallback across collections)
        artifact, collection_name = _find_artifact_in_collections(
            artifact_name,
            artifact_type,
            collection_mgr,
            preferred_collection=collection,
            artifact_repo=artifact_repo,
        )

        if not artifact:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )

        # Get artifact path - use artifact.path to get correct pluralized directory
        collection_path = collection_mgr.config.get_collection_path(collection_name)
        artifact_root = collection_path / artifact.path

        if not artifact_root.exists():
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Artifact path does not exist: {artifact_root}",
            )

        # Handle single-file artifacts (e.g., agents stored as agents/prd-writer.md)
        # For single-file artifacts, artifact_root IS the file, not a directory
        is_single_file_artifact = artifact_root.is_file()

        # Validate file path (path traversal protection)
        try:
            # Normalize the requested path to remove any .., ., etc.
            normalized_file_path = os.path.normpath(file_path)

            # Check for path traversal indicators
            if (
                normalized_file_path.startswith("..")
                or "/.." in normalized_file_path
                or "\\.." in normalized_file_path
            ):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid file path: path traversal attempt detected",
                )

            if is_single_file_artifact:
                # For single-file artifacts, the file_path must match the artifact's filename
                # or be "." (root indicator). The full_path IS the artifact_root itself.
                artifact_filename = artifact_root.name
                if normalized_file_path in (".", artifact_filename):
                    # Valid request for the single file - update is allowed
                    full_path = artifact_root.resolve()
                else:
                    # Requested file doesn't exist in this single-file artifact
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"File not found: {file_path}. This is a single-file artifact containing only '{artifact_filename}'",
                    )
            else:
                # Directory-based artifact: construct path normally
                full_path = (artifact_root / normalized_file_path).resolve()

                # Ensure the resolved path is still within the artifact directory
                artifact_root_resolved = artifact_root.resolve()
                if not str(full_path).startswith(str(artifact_root_resolved)):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid file path: path escapes artifact directory",
                    )

        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Path validation error: {e}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid file path: {str(e)}",
            )

        # Check if file exists
        if not full_path.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"File not found: {file_path}",
            )

        # Check if it's a file (not a directory)
        if not full_path.is_file():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Path is not a file: {file_path}",
            )

        # Validate content is valid UTF-8 (will raise UnicodeEncodeError if not)
        try:
            request.content.encode("utf-8")
        except UnicodeEncodeError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid content encoding: {str(e)}. Content must be valid UTF-8.",
            )

        # Write file atomically
        try:
            dir_path = full_path.parent

            # Create temporary file in the same directory for atomic rename
            with tempfile.NamedTemporaryFile(
                mode="w",
                dir=dir_path,
                delete=False,
                encoding="utf-8",
                prefix=".tmp_",
                suffix=f"_{full_path.name}",
            ) as tmp:
                tmp.write(request.content)
                tmp_path = PathLib(tmp.name)

            # Atomic rename (same filesystem)
            tmp_path.replace(full_path)

            logger.info(f"Successfully wrote file atomically: {full_path}")

        except Exception as e:
            # Clean up temp file if it still exists
            if "tmp_path" in locals() and tmp_path.exists():
                try:
                    tmp_path.unlink()
                except Exception:
                    pass
            logger.error(f"Error writing file {full_path}: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to write file: {str(e)}",
            )

        # Get updated file info
        file_size = full_path.stat().st_size
        mime_type, _ = mimetypes.guess_type(str(full_path))

        logger.info(f"Successfully updated file content: {artifact_id}/{file_path}")

        # Refresh DB cache after successful file update (non-blocking)
        _refresh_cache_safe(_artifact_mgr, artifact_id, collection_name)
        logger.debug(f"Refreshed cache after file update: {artifact_id}")

        return FileContentResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type.value,
            collection_name=collection_name,
            path=file_path,
            content=request.content,
            size=file_size,
            mime_type=mime_type,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Error updating file content for '{artifact_id}/{file_path}': {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update file content: {str(e)}",
        )


# ---------------------------------------------------------------------------
# Endpoint: create_artifact_file
# ---------------------------------------------------------------------------


@router.post(
    "/{artifact_id}/files/{file_path:path}",
    response_model=FileContentResponse,
    summary="Create new artifact file",
    description="Create a new file within an artifact",
    responses={
        201: {"description": "Successfully created file"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid request, path traversal attempt, or file already exists",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
    status_code=status.HTTP_201_CREATED,
)
async def create_artifact_file(
    artifact_id: str,
    file_path: str,
    request: FileUpdateRequest,
    _artifact_mgr: ArtifactManagerOptDep,
    artifact_repo: ArtifactRepoDep,
    collection_mgr: CollectionManagerOptDep,
    _token: TokenDep,
    settings: SettingsDep,
    enterprise_svc: EnterpriseFileContentServiceDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
) -> FileContentResponse:
    """Create a new file within an artifact.

    **SECURITY: Path Traversal Protection**
    This endpoint implements strict path validation to prevent directory
    traversal attacks. The file_path must:
    - Be within the artifact directory
    - Not contain ".." (parent directory references)
    - Resolve to a path inside the artifact root

    **Atomic Write**
    File creation is performed atomically using a temporary file and rename
    operation to ensure consistency (local edition). Enterprise edition writes
    to the CAS blob store transactionally.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        file_path: Relative path to new file within artifact (e.g., "README.md" or "docs/guide.md")
        request: File content request
        _artifact_mgr: Artifact manager dependency
        artifact_repo: Artifact repository dependency
        collection_mgr: Collection manager dependency
        _token: Authentication token (dependency injection)
        settings: API settings instance
        enterprise_svc: Enterprise CAS file content service (None in local edition)
        auth_context: Authenticated user context
        collection: Optional collection filter

    Returns:
        FileContentResponse with created file content and metadata

    Raises:
        HTTPException: 404 if artifact not found; 409 if file exists; 413 if too large
    """
    import mimetypes
    import os
    import tempfile

    if settings.edition == "enterprise":
        # Enterprise path: create file in CAS blob store.
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )
        try:
            content_bytes = request.content.encode("utf-8")
        except UnicodeEncodeError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid content encoding: {exc}. Content must be valid UTF-8.",
            )
        try:
            import mimetypes as _mimetypes
            mime_type, _ = _mimetypes.guess_type(file_path)
            entry = enterprise_svc.create_file(
                artifact_name, file_path, content_bytes, mime_type=mime_type
            )
        except CASArtifactNotFoundError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )
        except CASFileAlreadyExistsError:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"File already exists: {file_path}",
            )
        except BlobTooLargeError as exc:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=str(exc),
            )
        except Exception as exc:
            logger.error(
                "Enterprise create_file failed for '%s/%s': %s",
                artifact_id,
                file_path,
                exc,
                exc_info=True,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to create file: {exc}",
            )
        return FileContentResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type_str,
            collection_name="enterprise",
            path=file_path,
            content=request.content,
            size=entry.get("size", len(content_bytes)),
            mime_type=entry.get("mime_type"),
        )

    try:
        logger.info(
            f"Creating file for artifact: {artifact_id}, file: {file_path} (collection={collection})"
        )

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Find artifact (with fallback across collections)
        artifact, collection_name = _find_artifact_in_collections(
            artifact_name,
            artifact_type,
            collection_mgr,
            preferred_collection=collection,
            artifact_repo=artifact_repo,
        )

        if not artifact:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )

        # Get artifact path
        collection_path = collection_mgr.config.get_collection_path(collection_name)
        artifact_root = collection_path / artifact.path

        if not artifact_root.exists():
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Artifact path does not exist: {artifact_root}",
            )

        # Handle single-file artifacts (e.g., agents stored as agents/prd-writer.md)
        # For single-file artifacts, artifact_root IS the file, not a directory
        is_single_file_artifact = artifact_root.is_file()

        # Validate file path (path traversal protection)
        try:
            # Normalize the requested path to remove any .., ., etc.
            normalized_file_path = os.path.normpath(file_path)

            # Check for path traversal indicators
            if (
                normalized_file_path.startswith("..")
                or "/.." in normalized_file_path
                or "\\.." in normalized_file_path
            ):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid file path: path traversal attempt detected",
                )

            if is_single_file_artifact:
                # Single-file artifacts cannot have new files created
                # They can only contain one file (the artifact itself)
                artifact_filename = artifact_root.name
                if normalized_file_path in (".", artifact_filename):
                    # Trying to create the file that already exists
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"File already exists: {file_path}. This is a single-file artifact.",
                    )
                else:
                    # Trying to create a different file in a single-file artifact
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Cannot create new files in single-file artifacts. "
                        f"This artifact contains only '{artifact_filename}'. "
                        f"To add multiple files, convert to a directory-based artifact.",
                    )
            else:
                # Directory-based artifact: construct path normally
                full_path = (artifact_root / normalized_file_path).resolve()

                # Ensure the resolved path is still within the artifact directory
                artifact_root_resolved = artifact_root.resolve()
                if not str(full_path).startswith(str(artifact_root_resolved)):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid file path: path escapes artifact directory",
                    )

        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Path validation error: {e}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid file path: {str(e)}",
            )

        # Check if file already exists
        if full_path.exists():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"File already exists: {file_path}",
            )

        # Validate content is valid UTF-8
        try:
            request.content.encode("utf-8")
        except UnicodeEncodeError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid content encoding: {str(e)}. Content must be valid UTF-8.",
            )

        # Create parent directories if they don't exist
        try:
            full_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            logger.error(f"Error creating parent directories for {full_path}: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to create parent directories: {str(e)}",
            )

        # Write file atomically
        try:
            dir_path = full_path.parent

            # Create temporary file in the same directory for atomic rename
            with tempfile.NamedTemporaryFile(
                mode="w",
                dir=dir_path,
                delete=False,
                encoding="utf-8",
                prefix=".tmp_",
                suffix=f"_{full_path.name}",
            ) as tmp:
                tmp.write(request.content)
                tmp_path = PathLib(tmp.name)

            # Atomic rename (same filesystem)
            tmp_path.replace(full_path)

            logger.info(f"Successfully created file atomically: {full_path}")

        except Exception as e:
            # Clean up temp file if it still exists
            if "tmp_path" in locals() and tmp_path.exists():
                try:
                    tmp_path.unlink()
                except Exception:
                    pass
            logger.error(f"Error creating file {full_path}: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to create file: {str(e)}",
            )

        # Get file info
        file_size = full_path.stat().st_size
        mime_type, _ = mimetypes.guess_type(str(full_path))

        logger.info(f"Successfully created file: {artifact_id}/{file_path}")

        # Refresh DB cache after successful file create (non-blocking)
        _refresh_cache_safe(_artifact_mgr, artifact_id, collection_name)
        logger.debug(f"Refreshed cache after file create: {artifact_id}")

        return FileContentResponse(
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type.value,
            collection_name=collection_name,
            path=file_path,
            content=request.content,
            size=file_size,
            mime_type=mime_type,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Error creating file for '{artifact_id}/{file_path}': {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create file: {str(e)}",
        )


# ---------------------------------------------------------------------------
# Endpoint: delete_artifact_file
# ---------------------------------------------------------------------------


@router.delete(
    "/{artifact_id}/files/{file_path:path}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete artifact file",
    description="Delete a specific file within an artifact",
    responses={
        204: {"description": "Successfully deleted file"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid request, path traversal attempt, or directory path",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact or file not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def delete_artifact_file(
    artifact_id: str,
    file_path: str,
    _artifact_mgr: ArtifactManagerOptDep,
    artifact_repo: ArtifactRepoDep,
    collection_mgr: CollectionManagerOptDep,
    _token: TokenDep,
    settings: SettingsDep,
    enterprise_svc: EnterpriseFileContentServiceDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name (searches all if not specified)",
    ),
) -> None:
    """Delete a file within an artifact.

    **SECURITY: Path Traversal Protection**
    This endpoint implements strict path validation to prevent directory
    traversal attacks. The file_path must:
    - Be within the artifact directory
    - Not contain ".." (parent directory references)
    - Resolve to a path inside the artifact root

    **Safety**
    - Only files can be deleted, not directories
    - Protected files (SKILL.md, COMMAND.md, etc.) cannot be deleted (local edition)

    In enterprise edition, removes the file from the CAS manifest and decrements
    the backing blob ref count.

    Args:
        artifact_id: Artifact identifier (format: "type:name")
        file_path: Relative path to file within artifact (e.g., "README.md" or "docs/guide.md")
        _artifact_mgr: Artifact manager dependency
        artifact_repo: Artifact repository dependency
        collection_mgr: Collection manager dependency
        _token: Authentication token (dependency injection)
        settings: API settings instance
        enterprise_svc: Enterprise CAS file content service (None in local edition)
        auth_context: Authenticated user context
        collection: Optional collection filter

    Returns:
        None (204 No Content)

    Raises:
        HTTPException: 404 if not found; 400 on protected/directory files (local)
    """
    import os

    if settings.edition == "enterprise":
        # Enterprise path: remove file from CAS manifest.
        try:
            _artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )
        try:
            enterprise_svc.delete_file(artifact_name, file_path)
        except CASArtifactNotFoundError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )
        except CASFileNotFoundError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"File not found: {file_path}",
            )
        except Exception as exc:
            logger.error(
                "Enterprise delete_file failed for '%s/%s': %s",
                artifact_id,
                file_path,
                exc,
                exc_info=True,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to delete file: {exc}",
            )
        return  # 204 No Content

    try:
        logger.info(
            f"Deleting file for artifact: {artifact_id}, file: {file_path} (collection={collection})"
        )

        # Parse artifact ID
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
            artifact_type = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        # Find artifact (with fallback across collections)
        artifact, collection_name = _find_artifact_in_collections(
            artifact_name,
            artifact_type,
            collection_mgr,
            preferred_collection=collection,
            artifact_repo=artifact_repo,
        )

        if not artifact:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )

        # Get artifact path
        collection_path = collection_mgr.config.get_collection_path(collection_name)
        artifact_root = collection_path / artifact.path

        if not artifact_root.exists():
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Artifact path does not exist: {artifact_root}",
            )

        # Handle single-file artifacts (e.g., agents stored as agents/prd-writer.md)
        # For single-file artifacts, artifact_root IS the file, not a directory
        is_single_file_artifact = artifact_root.is_file()

        # Validate file path (path traversal protection)
        try:
            # Normalize the requested path to remove any .., ., etc.
            normalized_file_path = os.path.normpath(file_path)

            # Check for path traversal indicators
            if (
                normalized_file_path.startswith("..")
                or "/.." in normalized_file_path
                or "\\.." in normalized_file_path
            ):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid file path: path traversal attempt detected",
                )

            if is_single_file_artifact:
                # Single-file artifacts cannot have their only file deleted
                # Deleting it would effectively delete the entire artifact
                artifact_filename = artifact_root.name
                if normalized_file_path in (".", artifact_filename):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Cannot delete the only file in a single-file artifact. "
                        f"This would effectively delete the entire artifact '{artifact_id}'. "
                        f"Use the artifact deletion endpoint (DELETE /api/v1/artifacts/{artifact_id}) instead.",
                    )
                else:
                    # Requested file doesn't exist in this single-file artifact
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"File not found: {file_path}. This is a single-file artifact containing only '{artifact_filename}'",
                    )
            else:
                # Directory-based artifact: construct path normally
                full_path = (artifact_root / normalized_file_path).resolve()

                # Ensure the resolved path is still within the artifact directory
                artifact_root_resolved = artifact_root.resolve()
                if not str(full_path).startswith(str(artifact_root_resolved)):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid file path: path escapes artifact directory",
                    )

        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Path validation error: {e}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid file path: {str(e)}",
            )

        # Check if file exists
        if not full_path.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"File not found: {file_path}",
            )

        # Check if it's a file (not a directory)
        if not full_path.is_file():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Path is not a file (directories cannot be deleted): {file_path}",
            )

        # Prevent deletion of critical files
        critical_files = {
            "SKILL.md",
            "COMMAND.md",
            "AGENT.md",
            "HOOK.md",
            "MCP.md",
        }
        if full_path.name in critical_files:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Cannot delete critical file: {full_path.name}",
            )

        # Delete the file
        try:
            full_path.unlink()
            logger.info(f"Successfully deleted file: {full_path}")
        except Exception as e:
            logger.error(f"Error deleting file {full_path}: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to delete file: {str(e)}",
            )

        logger.info(f"Successfully deleted file: {artifact_id}/{file_path}")

        # Refresh DB cache after successful file delete (non-blocking)
        _refresh_cache_safe(_artifact_mgr, artifact_id, collection_name)
        logger.debug(f"Refreshed cache after file delete: {artifact_id}")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Error deleting file for '{artifact_id}/{file_path}': {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete file: {str(e)}",
        )
