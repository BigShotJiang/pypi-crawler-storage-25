"""FastAPI router for Git Credential CRUD endpoints (GCD-2.9).

Provides create, list, get, and delete operations for git credentials
(PATs and app-installation tokens) scoped to org, team, or developer.

All endpoints are gated by the ``git_credentials_enabled`` feature flag
in :class:`~skillmeat.api.config.APISettings`.  Disabling the flag causes
every endpoint to return HTTP 403.

Endpoints:
    POST   /git-credentials           — Register a new credential
    GET    /git-credentials           — List credentials (filterable)
    GET    /git-credentials/{id}      — Get a single credential
    DELETE /git-credentials/{id}      — Delete a credential
"""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from skillmeat.api.config import APISettings, get_settings
from skillmeat.api.dependencies import AuthContextDep
from skillmeat.api.schemas.git_credential import (
    GitCredentialCreate,
    GitCredentialListResponse,
    GitCredentialResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/git-credentials",
    tags=["git-credentials"],
)


# ---------------------------------------------------------------------------
# Feature flag guard
# ---------------------------------------------------------------------------


def _check_feature_enabled(settings: APISettings) -> None:
    """Raise HTTP 403 when the git_credentials feature flag is disabled.

    Args:
        settings: API settings instance.

    Raises:
        HTTPException: 403 when ``git_credentials_enabled`` is ``False``.
    """
    if not settings.git_credentials_enabled:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="git_credentials feature is not enabled",
        )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "",
    response_model=GitCredentialResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new git credential",
    description=(
        "Store an encrypted Git access token scoped to an org, team, or developer. "
        "The ``token`` field is encrypted at rest and is NEVER returned in any "
        "response payload.  Returns 403 when ``git_credentials_enabled`` is false."
    ),
)
async def create_git_credential(
    body: GitCredentialCreate,
    auth: AuthContextDep,
    settings: APISettings = Depends(get_settings),
) -> GitCredentialResponse:
    """Create a new git credential record."""
    _check_feature_enabled(settings)

    try:
        from skillmeat.api.dependencies import get_credential_repo
        from skillmeat.cache.session import get_db_session

        # Resolve the repository at call-time so the import is deferred until
        # GCD-2.10 wires the dependency.  This also avoids a circular import at
        # module load time.
        session = next(get_db_session())
        try:
            repo = get_credential_repo(session=session, settings=settings)
            credential = repo.create(
                scope_type=body.scope_type.value,
                scope_id=body.scope_id,
                token=body.token,
                credential_type=body.credential_type.value,
                connection_id=body.connection_id,
                created_by=getattr(auth, "user_id", None),
            )
        finally:
            session.close()
    except ImportError:
        # GCD-2.10 not yet wired — return a meaningful error during development.
        logger.error("get_credential_repo is not yet available (GCD-2.10 pending)")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Credential repository not yet available.",
        )
    except Exception as e:
        logger.exception("Failed to create git credential: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create git credential.",
        )

    return GitCredentialResponse.model_validate(credential)


@router.get(
    "",
    response_model=GitCredentialListResponse,
    summary="List git credentials",
    description=(
        "Return a list of Git credentials.  Filter by ``scope_type``, ``scope_id``, "
        "or ``connection_id``.  Returns 403 when ``git_credentials_enabled`` is false."
    ),
)
async def list_git_credentials(
    auth: AuthContextDep,
    settings: APISettings = Depends(get_settings),
    scope_type: Optional[str] = Query(
        None,
        description="Filter by scope type (``org``, ``team``, or ``developer``).",
    ),
    scope_id: Optional[str] = Query(
        None,
        description=(
            "Filter by scope identifier.  Must be combined with ``scope_type`` "
            "to use the ``list_by_scope`` query path."
        ),
    ),
    connection_id: Optional[str] = Query(
        None,
        description="Filter to credentials pinned to a specific git connection ID.",
    ),
) -> GitCredentialListResponse:
    """List git credentials with optional filtering."""
    _check_feature_enabled(settings)

    try:
        from skillmeat.api.dependencies import get_credential_repo
        from skillmeat.cache.session import get_db_session

        session = next(get_db_session())
        try:
            repo = get_credential_repo(session=session, settings=settings)

            if scope_type is not None and scope_id is not None:
                credentials = repo.list_by_scope(
                    scope_type=scope_type,
                    scope_id=scope_id,
                )
            elif connection_id is not None:
                credentials = repo.list_by_connection(connection_id=connection_id)
            else:
                # Return all credentials — implementations may return an empty list
                # for editions that restrict cross-scope enumeration.
                try:
                    credentials = repo.list_all()
                except AttributeError:
                    credentials = []
        finally:
            session.close()
    except ImportError:
        logger.error("get_credential_repo is not yet available (GCD-2.10 pending)")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Credential repository not yet available.",
        )
    except Exception as e:
        logger.exception("Failed to list git credentials: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list git credentials.",
        )

    items = [GitCredentialResponse.model_validate(c) for c in credentials]
    return GitCredentialListResponse(items=items, total=len(items))


@router.get(
    "/{credential_id}",
    response_model=GitCredentialResponse,
    summary="Get a single git credential",
    description=(
        "Return the credential identified by *credential_id*, or 404 if not found.  "
        "Returns 403 when ``git_credentials_enabled`` is false."
    ),
)
async def get_git_credential(
    credential_id: str,
    auth: AuthContextDep,
    settings: APISettings = Depends(get_settings),
) -> GitCredentialResponse:
    """Get a single git credential by ID."""
    _check_feature_enabled(settings)

    try:
        from skillmeat.api.dependencies import get_credential_repo
        from skillmeat.cache.session import get_db_session

        session = next(get_db_session())
        try:
            repo = get_credential_repo(session=session, settings=settings)
            credential = repo.get_by_id(credential_id)
        finally:
            session.close()
    except ImportError:
        logger.error("get_credential_repo is not yet available (GCD-2.10 pending)")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Credential repository not yet available.",
        )
    except Exception as e:
        logger.exception("Failed to fetch git credential %s: %s", credential_id, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch git credential.",
        )

    if credential is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Git credential '{credential_id}' not found.",
        )

    return GitCredentialResponse.model_validate(credential)


@router.delete(
    "/{credential_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a git credential",
    description=(
        "Remove a git credential record.  Returns 404 if the credential does not "
        "exist.  Returns 403 when ``git_credentials_enabled`` is false."
    ),
)
async def delete_git_credential(
    credential_id: str,
    auth: AuthContextDep,
    settings: APISettings = Depends(get_settings),
) -> None:
    """Delete a git credential by ID."""
    _check_feature_enabled(settings)

    try:
        from skillmeat.api.dependencies import get_credential_repo
        from skillmeat.cache.session import get_db_session

        session = next(get_db_session())
        try:
            repo = get_credential_repo(session=session, settings=settings)
            credential = repo.get_by_id(credential_id)
            if credential is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Git credential '{credential_id}' not found.",
                )
            repo.delete(credential_id)
        finally:
            session.close()
    except HTTPException:
        raise
    except ImportError:
        logger.error("get_credential_repo is not yet available (GCD-2.10 pending)")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Credential repository not yet available.",
        )
    except Exception as e:
        logger.exception("Failed to delete git credential %s: %s", credential_id, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete git credential.",
        )

    return None
