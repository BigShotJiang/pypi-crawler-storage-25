"""Enterprise Global Collections management router.

Provides CRUD and binding endpoints for enterprise-wide (global) collections
under the ``/enterprise/collections`` prefix.  Write operations and binding
mutations are gated by the ``require_enterprise_admin()`` dependency.

Routes
------
GET    /enterprise/collections                                         List global collections
POST   /enterprise/collections                                         Create a global collection
POST   /enterprise/collections/{collection_id}/bind                    Bind a user or team
DELETE /enterprise/collections/{collection_id}/bindings/{binding_id}  Unbind a user or team
"""

from __future__ import annotations

import logging
import uuid
from typing import Annotated, List, Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy import func, select

from skillmeat.api.dependencies import (
    DbSessionDep,
    EnterpriseAdminDep,
    EnterpriseContextDep,
    OwnershipContextDep,
    get_auth_context,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.cache.enterprise_repositories import (
    EnterpriseCollectionRepository,
    TenantIsolationError,
)
from skillmeat.cache.models_enterprise import (
    EnterpriseCollection,
    EnterpriseCollectionBinding,
)
from skillmeat.core.auth.auto_bind import unbind_collection

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = APIRouter(
    prefix="/enterprise/collections",
    tags=["Enterprise Collections"],
)

# ---------------------------------------------------------------------------
# Dependency: per-request EnterpriseCollectionRepository
# ---------------------------------------------------------------------------


def _get_collection_repo(session: DbSessionDep) -> EnterpriseCollectionRepository:
    """Build an ``EnterpriseCollectionRepository`` for the current request.

    Tenant isolation is controlled via ``TenantContext`` (a ContextVar in
    ``skillmeat.cache.enterprise_repositories``).  When ``TenantContext`` is
    not set the repository falls back to ``DEFAULT_TENANT_ID`` automatically.

    Parameters
    ----------
    session:
        Per-request SQLAlchemy session injected by ``DbSessionDep``.

    Returns
    -------
    EnterpriseCollectionRepository
        Repository instance ready for use within the current request.
    """
    return EnterpriseCollectionRepository(session)


EnterpriseCollectionRepoDep = Annotated[
    EnterpriseCollectionRepository, Depends(_get_collection_repo)
]

# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


class EnterpriseCollectionCreateRequest(BaseModel):
    """Request body for creating a global enterprise collection.

    Attributes
    ----------
    name:
        Human-readable collection name (unique per tenant).
    description:
        Optional free-text description.
    auto_bind:
        When ``True``, new users and teams are automatically bound to this
        collection on Day-0 provisioning.
    enforce_override:
        When ``True``, governance policy overrides apply regardless of owner
        settings.
    """

    name: str = Field(
        description="Human-readable collection name; must be unique per tenant",
        min_length=1,
        max_length=255,
    )
    description: Optional[str] = Field(
        default=None,
        description="Optional free-text description",
    )
    auto_bind: bool = Field(
        default=False,
        description=(
            "When True, new users and teams automatically receive this collection "
            "on Day-0 provisioning"
        ),
    )
    enforce_override: bool = Field(
        default=False,
        description=(
            "When True, governance policy overrides apply to this collection "
            "regardless of owner settings"
        ),
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "name": "enterprise-defaults",
                "description": "Standard enterprise artifact set for all users",
                "auto_bind": True,
                "enforce_override": False,
            }
        }
    }


class EnterpriseCollectionResponse(BaseModel):
    """Response schema for a single enterprise global collection.

    Attributes
    ----------
    id:
        UUID primary key of the collection.
    tenant_id:
        UUID of the owning tenant.
    name:
        Human-readable collection name.
    description:
        Optional free-text description.
    is_global_collection:
        Always ``True`` for collections returned by this router.
    auto_bind:
        When ``True``, new entities are automatically bound on Day-0.
    enforce_override:
        When ``True``, governance policy overrides are applied.
    is_default:
        When ``True``, the CLI uses this collection implicitly.
    binding_count:
        Number of active bindings (user/team) for this collection.
    created_at:
        ISO-8601 creation timestamp.
    updated_at:
        ISO-8601 last-modification timestamp.
    """

    id: str = Field(description="UUID identifying the enterprise collection")
    tenant_id: str = Field(description="UUID of the owning tenant")
    name: str = Field(description="Human-readable collection name")
    description: Optional[str] = Field(default=None, description="Optional description")
    is_global_collection: bool = Field(
        description="Always True for collections returned by this router"
    )
    auto_bind: bool = Field(
        description="When True, new entities are auto-bound on Day-0"
    )
    enforce_override: bool = Field(
        description="When True, governance policy overrides are applied"
    )
    is_default: bool = Field(
        description="When True, the CLI uses this collection implicitly"
    )
    binding_count: int = Field(
        default=0,
        description="Number of active user/team bindings for this collection",
    )
    created_at: Optional[str] = Field(
        default=None, description="ISO-8601 creation timestamp"
    )
    updated_at: Optional[str] = Field(
        default=None, description="ISO-8601 last-modification timestamp"
    )

    model_config = {"from_attributes": True}


class EnterpriseCollectionListResponse(BaseModel):
    """Paginated list response for enterprise global collections.

    Attributes
    ----------
    items:
        Page of collection objects.
    total:
        Total number of global collections for the tenant.
    limit:
        Maximum items per page (as requested).
    offset:
        Items skipped before this page (as requested).
    """

    items: List[EnterpriseCollectionResponse] = Field(
        description="Page of global collections"
    )
    total: int = Field(description="Total global collection count for the tenant")
    limit: int = Field(description="Maximum items per page")
    offset: int = Field(description="Number of items skipped")


class BindCollectionRequest(BaseModel):
    """Request body for binding a user or team to a global collection.

    Attributes
    ----------
    target_type:
        The type of entity to bind: ``"user"`` or ``"team"``.
    target_id:
        UUID of the ``EnterpriseUser`` or ``EnterpriseTeam`` to bind.
    """

    target_type: Literal["user", "team"] = Field(
        description="Type of the entity to bind: 'user' or 'team'",
    )
    target_id: str = Field(
        description="UUID of the EnterpriseUser or EnterpriseTeam to bind",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "target_type": "team",
                "target_id": "550e8400-e29b-41d4-a716-446655440000",
            }
        }
    }


class CollectionBindingResponse(BaseModel):
    """Response schema for a single collection binding.

    Attributes
    ----------
    id:
        UUID primary key of the binding row.
    collection_id:
        UUID of the bound collection.
    bound_entity_type:
        ``"user"`` or ``"team"``.
    bound_entity_id:
        UUID of the bound entity.
    is_readonly:
        When ``True`` only a ``system_admin`` may delete this binding.
    created_at:
        ISO-8601 timestamp when the binding was created.
    """

    id: str = Field(description="UUID identifying the binding")
    collection_id: str = Field(description="UUID of the bound collection")
    bound_entity_type: str = Field(description="'user' or 'team'")
    bound_entity_id: str = Field(description="UUID of the bound entity")
    is_readonly: bool = Field(
        description="When True only a system_admin may delete this binding"
    )
    created_at: Optional[str] = Field(
        default=None, description="ISO-8601 creation timestamp"
    )

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _collection_to_response(
    collection: "EnterpriseCollection",
    binding_count: int = 0,
) -> EnterpriseCollectionResponse:
    """Convert an ``EnterpriseCollection`` ORM instance to response schema.

    Parameters
    ----------
    collection:
        An ``EnterpriseCollection`` ORM instance.
    binding_count:
        Pre-computed count of active bindings for this collection.

    Returns
    -------
    EnterpriseCollectionResponse
        Serialisable response object.
    """
    created_at = collection.created_at
    updated_at = collection.updated_at
    return EnterpriseCollectionResponse(
        id=str(collection.id),
        tenant_id=str(collection.tenant_id),
        name=collection.name,
        description=collection.description,
        is_global_collection=bool(collection.is_global_collection),
        auto_bind=bool(collection.auto_bind),
        enforce_override=bool(collection.enforce_override),
        is_default=bool(collection.is_default),
        binding_count=binding_count,
        created_at=created_at.isoformat() if created_at is not None else None,
        updated_at=updated_at.isoformat() if updated_at is not None else None,
    )


def _binding_to_response(
    binding: "EnterpriseCollectionBinding",
) -> CollectionBindingResponse:
    """Convert an ``EnterpriseCollectionBinding`` ORM instance to response schema.

    Parameters
    ----------
    binding:
        An ``EnterpriseCollectionBinding`` ORM instance.

    Returns
    -------
    CollectionBindingResponse
        Serialisable response object.
    """
    created_at = binding.created_at
    return CollectionBindingResponse(
        id=str(binding.id),
        collection_id=str(binding.collection_id),
        bound_entity_type=binding.bound_entity_type,
        bound_entity_id=str(binding.bound_entity_id),
        is_readonly=bool(binding.is_readonly),
        created_at=created_at.isoformat() if created_at is not None else None,
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "",
    summary="List global enterprise collections",
    description=(
        "Return a paginated list of enterprise-wide (``is_global_collection=True``) "
        "collections visible to the authenticated user.  Each item includes a "
        "``binding_count`` summarising how many user/team bindings exist."
    ),
    response_model=EnterpriseCollectionListResponse,
    responses={
        200: {"description": "Paginated list of global enterprise collections."},
        401: {"description": "Authentication required."},
    },
)
def list_global_collections(
    repo: EnterpriseCollectionRepoDep,
    session: DbSessionDep,
    ctx: EnterpriseContextDep,
    _ownership: OwnershipContextDep,
    auth_context: AuthContext = Depends(get_auth_context),
    limit: int = Query(
        default=50, ge=1, le=100, description="Maximum number of results"
    ),
    offset: int = Query(default=0, ge=0, description="Number of results to skip"),
) -> EnterpriseCollectionListResponse:
    """List all global enterprise collections with pagination.

    Parameters
    ----------
    repo:
        ``EnterpriseCollectionRepository`` injected per request.
    session:
        Open SQLAlchemy ``Session`` injected per request.
    ctx:
        Resolved enterprise tenant context (safe fallback to DEFAULT_TENANT_ID).
    _ownership:
        Resolved ownership context (injected for enterprise scope).
    auth_context:
        Authentication context for visibility-aware filtering.
    limit:
        Maximum number of results to return (1–100).
    offset:
        Number of results to skip before this page.

    Returns
    -------
    EnterpriseCollectionListResponse
        Paginated results with total count and per-item binding counts.
    """
    tenant_id = ctx.tenant_id

    # Query global collections for this tenant
    stmt = (
        select(EnterpriseCollection)
        .where(
            EnterpriseCollection.tenant_id == tenant_id,
            EnterpriseCollection.is_global_collection.is_(True),
        )
        .order_by(EnterpriseCollection.name)
        .offset(offset)
        .limit(limit)
    )
    collections = list(session.execute(stmt).scalars())

    # Count total for pagination metadata
    count_stmt = select(func.count()).where(
        EnterpriseCollection.tenant_id == tenant_id,
        EnterpriseCollection.is_global_collection.is_(True),
    )
    total = int(session.execute(count_stmt).scalar_one() or 0)

    # Fetch binding counts for each collection
    items = []
    for collection in collections:
        count_stmt = select(func.count()).where(
            EnterpriseCollectionBinding.collection_id == collection.id
        )
        b_count = int(session.execute(count_stmt).scalar_one() or 0)
        items.append(_collection_to_response(collection, binding_count=b_count))

    return EnterpriseCollectionListResponse(
        items=items,
        total=total,
        limit=limit,
        offset=offset,
    )


@router.post(
    "",
    summary="Create a global enterprise collection",
    description=(
        "Create a new enterprise-wide collection.  ``is_global_collection`` is "
        "set to ``True`` automatically.  Requires the ``system_admin`` role."
    ),
    response_model=EnterpriseCollectionResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        201: {"description": "Global collection created successfully."},
        401: {"description": "Authentication required."},
        403: {"description": "system_admin role required."},
        409: {"description": "A collection with the given name already exists."},
        422: {"description": "Validation error in request body."},
    },
)
def create_global_collection(
    request: EnterpriseCollectionCreateRequest,
    repo: EnterpriseCollectionRepoDep,
    auth: EnterpriseAdminDep,
) -> EnterpriseCollectionResponse:
    """Create a new global enterprise collection.

    Parameters
    ----------
    request:
        Collection creation payload.
    repo:
        ``EnterpriseCollectionRepository`` injected per request.
    auth:
        Authenticated admin context (injected by ``require_enterprise_admin()``).

    Returns
    -------
    EnterpriseCollectionResponse
        The newly created collection with ``is_global_collection=True``.

    Raises
    ------
    HTTPException(403)
        When the authenticated user does not hold the ``system_admin`` role.
    HTTPException(409)
        When a collection with the same name already exists for the tenant.
    HTTPException(422)
        When the request body fails Pydantic validation.
    HTTPException(500)
        When an unexpected error occurs during creation.
    """
    try:
        collection = repo.create(
            name=request.name,
            description=request.description,
            auth_context=auth,
        )
        # Set global-collection flags after creation
        collection.is_global_collection = True
        collection.auto_bind = request.auto_bind
        collection.enforce_override = request.enforce_override
        repo.session.flush()
    except Exception as exc:
        error_msg = str(exc)
        if "unique" in error_msg.lower() or "already exists" in error_msg.lower():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"A collection named {request.name!r} already exists for this tenant.",
            ) from exc
        logger.exception(
            "Failed to create global enterprise collection name=%r: %s",
            request.name,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create global enterprise collection.",
        ) from exc

    return _collection_to_response(collection, binding_count=0)


@router.post(
    "/{collection_id}/bind",
    summary="Bind a user or team to a global collection",
    description=(
        "Create a new binding linking a ``user`` or ``team`` to the specified "
        "global collection.  Bindings created via this endpoint are marked "
        "``is_readonly=False`` (manually-created), allowing non-admin deletion. "
        "Auto-bind bindings (``is_readonly=True``) are created separately by the "
        "provisioning workflow.  Requires the ``system_admin`` role."
    ),
    response_model=CollectionBindingResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        201: {"description": "Binding created successfully."},
        401: {"description": "Authentication required."},
        403: {"description": "system_admin role required."},
        404: {"description": "Collection not found or not a global collection."},
        409: {"description": "Binding already exists for this (collection, entity)."},
        422: {"description": "Invalid collection_id or request body."},
    },
)
def bind_collection(
    collection_id: str,
    request: BindCollectionRequest,
    repo: EnterpriseCollectionRepoDep,
    session: DbSessionDep,
    auth: EnterpriseAdminDep,
) -> CollectionBindingResponse:
    """Bind a user or team to a global enterprise collection.

    Parameters
    ----------
    collection_id:
        UUID string of the global collection to bind to.
    request:
        Binding request payload (target_type and target_id).
    repo:
        ``EnterpriseCollectionRepository`` injected per request.
    session:
        Open SQLAlchemy ``Session`` injected per request.
    auth:
        Authenticated admin context (injected by ``require_enterprise_admin()``).

    Returns
    -------
    CollectionBindingResponse
        The newly created binding.

    Raises
    ------
    HTTPException(404)
        When the collection does not exist, is not global, or is not in the
        current tenant.
    HTTPException(409)
        When a binding already exists for the (collection, entity_type, entity_id).
    HTTPException(422)
        When *collection_id* or *target_id* is not a valid UUID string.
    HTTPException(500)
        When an unexpected error occurs during binding creation.
    """
    # Validate collection UUID
    try:
        collection_uuid = uuid.UUID(collection_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid collection_id: {exc}",
        ) from exc

    # Validate target UUID
    try:
        target_uuid = uuid.UUID(request.target_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid target_id: {exc}",
        ) from exc

    # Resolve and validate the collection
    try:
        collection = repo.get(collection_uuid, auth_context=auth)
    except TenantIsolationError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Enterprise collection not found: {collection_id!r}",
        ) from exc
    except Exception as exc:
        logger.exception(
            "Unexpected error fetching enterprise collection %r: %s", collection_id, exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve enterprise collection.",
        ) from exc

    if collection is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Enterprise collection not found: {collection_id!r}",
        )

    if not collection.is_global_collection:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Collection {collection_id!r} is not a global collection. "
                "Only global collections support bindings via this endpoint."
            ),
        )

    # Check for an existing binding (idempotency guard / 409)
    existing = session.execute(
        select(EnterpriseCollectionBinding).where(
            EnterpriseCollectionBinding.tenant_id == collection.tenant_id,
            EnterpriseCollectionBinding.collection_id == collection_uuid,
            EnterpriseCollectionBinding.bound_entity_type == request.target_type,
            EnterpriseCollectionBinding.bound_entity_id == target_uuid,
        )
    ).scalar_one_or_none()

    if existing is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"A binding already exists for {request.target_type} "
                f"{request.target_id!r} on collection {collection_id!r}."
            ),
        )

    # Create the binding — manually-created bindings are NOT read-only
    try:
        binding = EnterpriseCollectionBinding(
            tenant_id=collection.tenant_id,
            collection_id=collection_uuid,
            bound_entity_type=request.target_type,
            bound_entity_id=target_uuid,
            is_readonly=False,
        )
        session.add(binding)
        session.flush()
        logger.info(
            "bind_collection: created binding tenant=%s collection=%s %s=%s",
            collection.tenant_id,
            collection_id,
            request.target_type,
            request.target_id,
        )
    except Exception as exc:
        logger.exception(
            "Failed to create binding for collection %r %s=%r: %s",
            collection_id,
            request.target_type,
            request.target_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create collection binding.",
        ) from exc

    return _binding_to_response(binding)


@router.delete(
    "/{collection_id}/bindings/{binding_id}",
    summary="Remove a binding from a global collection",
    description=(
        "Delete a binding linking a user or team to a global collection.  "
        "Read-only bindings (``is_readonly=True``, created by auto-bind) can only "
        "be deleted by a ``system_admin``.  Requires the ``system_admin`` role."
    ),
    status_code=status.HTTP_204_NO_CONTENT,
    responses={
        204: {"description": "Binding removed successfully."},
        401: {"description": "Authentication required."},
        403: {"description": "system_admin role required, or binding is read-only."},
        404: {"description": "Collection or binding not found."},
        422: {"description": "Invalid collection_id or binding_id format."},
    },
)
def unbind_from_collection(
    collection_id: str,
    binding_id: str,
    repo: EnterpriseCollectionRepoDep,
    session: DbSessionDep,
    auth: EnterpriseAdminDep,
) -> None:
    """Remove a binding from a global enterprise collection.

    Parameters
    ----------
    collection_id:
        UUID string of the collection; used to verify the binding belongs to
        this collection and the caller's tenant.
    binding_id:
        UUID string of the ``EnterpriseCollectionBinding`` to remove.
    repo:
        ``EnterpriseCollectionRepository`` injected per request.
    session:
        Open SQLAlchemy ``Session`` injected per request.
    auth:
        Authenticated admin context (injected by ``require_enterprise_admin()``).

    Returns
    -------
    None
        Responds with HTTP 204 No Content on success.

    Raises
    ------
    HTTPException(404)
        When the collection or binding does not exist in the current tenant.
    HTTPException(403)
        When the binding is read-only and the caller is not a system_admin.
    HTTPException(422)
        When *collection_id* or *binding_id* is not a valid UUID string.
    HTTPException(500)
        When an unexpected error occurs during deletion.
    """
    # Validate path UUIDs
    try:
        collection_uuid = uuid.UUID(collection_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid collection_id: {exc}",
        ) from exc

    try:
        uuid.UUID(binding_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid binding_id: {exc}",
        ) from exc

    # Validate the collection exists and belongs to the current tenant
    try:
        collection = repo.get(collection_uuid, auth_context=auth)
    except TenantIsolationError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Enterprise collection not found: {collection_id!r}",
        ) from exc
    except Exception as exc:
        logger.exception(
            "Unexpected error fetching enterprise collection %r: %s", collection_id, exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve enterprise collection.",
        ) from exc

    if collection is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Enterprise collection not found: {collection_id!r}",
        )

    # Determine admin privilege — auth roles may be a list or space-separated string
    roles = getattr(auth, "roles", []) or []
    if isinstance(roles, str):
        roles = roles.split()
    is_system_admin = "system_admin" in roles

    # Delegate to auto_bind module which enforces read-only guard
    try:
        deleted = unbind_collection(
            session=session,
            binding_id=binding_id,
            is_system_admin=is_system_admin,
        )
    except PermissionError as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(exc),
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc
    except Exception as exc:
        logger.exception(
            "Unexpected error deleting binding %r from collection %r: %s",
            binding_id,
            collection_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to remove collection binding.",
        ) from exc

    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Binding not found: {binding_id!r}",
        )
