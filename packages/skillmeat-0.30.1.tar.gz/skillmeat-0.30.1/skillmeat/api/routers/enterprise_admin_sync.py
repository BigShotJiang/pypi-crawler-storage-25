"""Enterprise admin sync endpoints.

Exposes:
  - ``GET /enterprise/admin/sync/org-health``          — org-wide sync aggregate
  - ``GET /enterprise/admin/sync/compliance-summary``  — per-project compliance audit
  - ``GET /enterprise/admin/sync/operations-log``      — paginated sync operation log
  - ``POST /enterprise/admin/sync/propagate``          — trigger forced propagation job
  - ``GET /enterprise/admin/sync/propagate/{job_id}/status``        — job status poll
  - ``GET /enterprise/admin/sync/propagate/{operation_id}/pr-links`` — PR links for hard-update operation

All endpoints require ``enterprise_admin`` scope via ``EnterpriseAdminDep``.

Feature flag gate
-----------------
``settings.edition != "enterprise"`` or ``settings.admin_sync_management_enabled
is False`` → HTTP 501.

RBAC enforcement
-----------------
All endpoints require ``enterprise_admin`` role (enforced by ``EnterpriseAdminDep``).
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Annotated, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from skillmeat.api.dependencies import (
    EnterpriseAdminDep,
    EnterpriseContextDep,
    SettingsDep,
    get_db_session,
    get_settings,
)
from skillmeat.api.schemas.enterprise_admin_sync import (
    ComplianceAuditEntry,
    ComplianceAuditResponse,
    OrgSyncHealthResponse,
    PropagationJobResponse,
    PropagationPRLinkEntry,
    PropagationPRLinksResponse,
    PropagationRequest,
    SyncOperationLogEntry,
    SyncOperationsLogResponse,
)
from skillmeat.api.schemas.enterprise_team_sync import TeamSyncSummary
from skillmeat.api.services.propagation_job_manager import (
    PropagationJob,
    get_propagation_job_manager,
)

from skillmeat.core.services.enterprise_context_sync import (
    EnterpriseContextSyncService,
)

# ---------------------------------------------------------------------------
# Optional OpenTelemetry import — silently skipped when not installed.
# ---------------------------------------------------------------------------

try:
    from opentelemetry import trace as _otel_trace

    _tracer = _otel_trace.get_tracer(__name__)
    _OTEL_AVAILABLE = True
except ImportError:  # pragma: no cover — OTel is optional
    _OTEL_AVAILABLE = False
    _tracer = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# OTel helpers (best-effort; isolated so handlers stay readable)
# ---------------------------------------------------------------------------


def _emit_org_health_span(auth: "EnterpriseAdminDep") -> None:
    """Emit a best-effort OTel span for an org-health request.

    Span name: ``enterprise.admin.org_health``

    Args:
        auth: Resolved enterprise_admin auth context.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return
    try:
        with _tracer.start_as_current_span("enterprise.admin.org_health") as span:
            span.set_attribute("user_id", str(auth.user_id))
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for admin org-health", exc_info=True)


def _emit_operations_log_span(
    auth: "EnterpriseAdminDep",
    team_id: Optional[str],
    operation_type: Optional[str],
) -> None:
    """Emit a best-effort OTel span for an operations-log request.

    Span name: ``enterprise.admin.operations_log``

    Args:
        auth: Resolved enterprise_admin auth context.
        team_id: Optional team UUID filter applied to the query.
        operation_type: Optional operation type filter.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return
    try:
        with _tracer.start_as_current_span("enterprise.admin.operations_log") as span:
            span.set_attribute("user_id", str(auth.user_id))
            if team_id is not None:
                span.set_attribute("team_id", team_id)
            if operation_type is not None:
                span.set_attribute("operation_type", operation_type)
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for admin operations-log", exc_info=True)


def _emit_propagate_span(
    auth: "EnterpriseAdminDep",
    job_id: str,
    team_ids: list,
    mode: str,
) -> None:
    """Emit a best-effort OTel span for a propagate request.

    Span name: ``enterprise.admin.propagate``

    Args:
        auth: Resolved enterprise_admin auth context.
        job_id: Newly created propagation job ID.
        team_ids: Target team IDs for the propagation.
        mode: Propagation mode (soft or hard).
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return
    try:
        with _tracer.start_as_current_span("enterprise.admin.propagate") as span:
            span.set_attribute("user_id", str(auth.user_id))
            span.set_attribute("job_id", job_id)
            span.set_attribute("mode", mode)
            span.set_attribute("team_count", len(team_ids))
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for admin propagate", exc_info=True)


def _emit_pr_links_span(
    auth: "EnterpriseAdminDep",
    operation_id: str,
) -> None:
    """Emit a best-effort OTel span for a pr-links request.

    Span name: ``enterprise.admin.pr_links``

    Args:
        auth: Resolved enterprise_admin auth context.
        operation_id: Operation ID whose PR links are being fetched.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return
    try:
        with _tracer.start_as_current_span("enterprise.admin.pr_links") as span:
            span.set_attribute("user_id", str(auth.user_id))
            span.set_attribute("operation_id", operation_id)
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for admin pr-links", exc_info=True)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _job_to_response(job: PropagationJob) -> PropagationJobResponse:
    """Convert a :class:`~skillmeat.api.services.propagation_job_manager.PropagationJob`
    dataclass to the API response schema.

    Args:
        job: In-memory propagation job instance.

    Returns:
        :class:`~skillmeat.api.schemas.enterprise_admin_sync.PropagationJobResponse`
        populated from the job's current state.
    """
    return PropagationJobResponse(
        job_id=job.job_id,
        status=job.status,  # type: ignore[arg-type]
        teams_total=job.teams_total,
        teams_complete=job.teams_complete,
        teams_failed=job.teams_failed,
        artifacts_updated=job.artifacts_updated,
        progress_pct=job.progress_pct,
        started_at=job.started_at,
        completed_at=job.completed_at,
        errors=job.errors if job.errors else None,
    )


# ---------------------------------------------------------------------------
# Feature flag gate
# ---------------------------------------------------------------------------


def _check_feature_flags(settings: SettingsDep) -> None:
    """Raise HTTP 501 when the admin sync management feature is unavailable.

    Two independent checks are applied:

    1. ``edition != "enterprise"`` — admin sync hierarchy only exists in
       enterprise edition.
    2. ``admin_sync_management_enabled is False`` — may be administratively
       disabled even in enterprise edition.

    Args:
        settings: Current application settings.

    Raises:
        HTTPException 501: When edition is not enterprise, or when
            ``admin_sync_management_enabled`` is disabled.
    """
    if settings.edition != "enterprise":
        logger.debug(
            "admin-sync: edition=%s is not enterprise — returning 501",
            settings.edition,
        )
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Admin Sync Management is only available in the enterprise edition. "
                "Current edition: %s." % settings.edition
            ),
        )

    if not settings.admin_sync_management_enabled:
        logger.debug("admin-sync: admin_sync_management_enabled=False — returning 501")
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Admin Sync Management is not enabled in this deployment. "
                "Set SKILLMEAT_ADMIN_SYNC_MANAGEMENT_ENABLED=true to activate."
            ),
        )


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = APIRouter(
    prefix="/enterprise",
    tags=["Enterprise Admin Sync"],
    dependencies=[Depends(_check_feature_flags)],
)

# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/admin/sync/org-health",
    summary="Get org-wide sync health",
    description=(
        "Return an aggregate view of sync health across all teams in the "
        "organization.  Includes per-team summaries so the admin dashboard "
        "can render team-level rows without additional requests.\n\n"
        "Phase 3 stub: returns an empty org health response.  "
        "Full aggregation logic is wired in Batch 2."
    ),
    response_model=OrgSyncHealthResponse,
    responses={
        200: {"description": "Org-wide sync health aggregate."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        501: {
            "description": (
                "Admin Sync Management is not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def get_org_sync_health(
    settings: SettingsDep,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
    session: Annotated[Session, Depends(get_db_session)],
) -> OrgSyncHealthResponse:
    """Return org-wide sync health aggregate.

    Parameters
    ----------
    settings:
        Application settings used for feature flag checks.
    auth:
        Resolved enterprise_admin auth context (enforced by dependency).
    session:
        SQLAlchemy session for DB queries.

    Returns
    -------
    OrgSyncHealthResponse
        Aggregate sync health with per-team summaries.

    Raises
    ------
    HTTPException(403)
        If the caller lacks enterprise_admin role.
    HTTPException(501)
        If the deployment is not enterprise edition or the feature is disabled.
    """
    # Feature gate fires via router dependency before this handler is entered.

    # OTel span (best-effort)
    _emit_org_health_span(auth=auth)

    logger.info(
        "admin-sync org-health request: user_id=%r",
        str(auth.user_id),
    )

    tenant_id = ctx.tenant_id

    service = EnterpriseContextSyncService(session=session, settings=settings)
    data = service.get_org_sync_health(tenant_id=tenant_id)

    teams = [
        TeamSyncSummary(
            team_id=t["team_id"],
            team_name=t["team_name"],
            artifact_count=t["artifact_count"],
            current_count=t["current_count"],
            diverged_count=t["diverged_count"],
            outdated_count=t["outdated_count"],
            last_sync_at=t.get("last_sync_at"),
        )
        for t in data["teams"]
    ]

    return OrgSyncHealthResponse(
        team_count=data["team_count"],
        total_artifacts=data["total_artifacts"],
        fully_current_teams=data["fully_current_teams"],
        teams_with_divergence=data["teams_with_divergence"],
        teams=teams,
    )


@router.get(
    "/admin/sync/compliance-summary",
    summary="Get compliance audit summary",
    description=(
        "Return a per-project compliance audit across the organization, "
        "showing which projects satisfy all forced-artifact requirements "
        "imposed by their team's governance policy.\n\n"
        "Phase 3 stub: returns an empty compliance response.  "
        "Full compliance evaluation is wired in Batch 2."
    ),
    response_model=ComplianceAuditResponse,
    responses={
        200: {"description": "Compliance audit summary."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        501: {
            "description": (
                "Admin Sync Management is not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def get_compliance_summary(
    settings: SettingsDep,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
    session: Annotated[Session, Depends(get_db_session)],
) -> ComplianceAuditResponse:
    """Return compliance audit summary for all projects.

    Parameters
    ----------
    settings:
        Application settings used for feature flag checks.
    auth:
        Resolved enterprise_admin auth context (enforced by dependency).
    session:
        SQLAlchemy session for DB queries.

    Returns
    -------
    ComplianceAuditResponse
        Per-team compliance entries and aggregate non-compliant count.

    Raises
    ------
    HTTPException(403)
        If the caller lacks enterprise_admin role.
    HTTPException(501)
        If the deployment is not enterprise edition or the feature is disabled.
    """
    # Feature gate fires via router dependency before this handler is entered.

    logger.info(
        "admin-sync compliance-summary request: user_id=%r",
        str(auth.user_id),
    )

    tenant_id = ctx.tenant_id

    service = EnterpriseContextSyncService(session=session, settings=settings)
    data = service.get_compliance_summary(tenant_id=tenant_id)

    entries = [
        ComplianceAuditEntry(
            project_id=e["team_id"],
            project_name=e["team_name"],
            team_id=e["team_id"],
            forced_artifact_ids=e.get("forced_artifact_ids", []),
            compliance_status=e["compliance_status"],
            checked_at=data["checked_at"],
        )
        for e in data["entries"]
    ]

    return ComplianceAuditResponse(
        entries=entries,
        non_compliant_count=data["non_compliant_count"],
        checked_at=data["checked_at"],
    )


@router.get(
    "/admin/sync/operations-log",
    summary="Get sync operations log",
    description=(
        "Return a paginated list of sync operations across the organization, "
        "optionally filtered by team and operation type.\n\n"
        "Phase 3 stub: returns an empty log.  "
        "Full log population is wired in Batch 2."
    ),
    response_model=SyncOperationsLogResponse,
    responses={
        200: {"description": "Paginated sync operations log."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        501: {
            "description": (
                "Admin Sync Management is not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def get_operations_log(
    settings: SettingsDep,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
    session: Annotated[Session, Depends(get_db_session)],
    limit: int = Query(
        default=50,
        ge=1,
        le=200,
        description="Maximum number of log entries to return.",
    ),
    offset: int = Query(
        default=0,
        ge=0,
        description="Number of entries to skip for pagination.",
    ),
    team_id: Optional[str] = Query(
        default=None,
        description="Filter by team UUID (as string).  When omitted, all teams are included.",
    ),
    operation_type: Optional[str] = Query(
        default=None,
        description=(
            "Filter by operation type (sync_propagate, sync_enforce, sync_pull, "
            "compliance_check).  When omitted, all sync operation types are included."
        ),
    ),
) -> SyncOperationsLogResponse:
    """Return a paginated sync operations log.

    Parameters
    ----------
    settings:
        Application settings used for feature flag checks.
    auth:
        Resolved enterprise_admin auth context (enforced by dependency).
    session:
        SQLAlchemy session for DB queries.
    limit:
        Maximum number of entries to return (1–200, default 50).
    offset:
        Number of entries to skip for pagination (default 0).
    team_id:
        Optional team UUID filter.
    operation_type:
        Optional operation type filter (must be a sync event type).

    Returns
    -------
    SyncOperationsLogResponse
        Filtered, paginated log entries and total count.

    Raises
    ------
    HTTPException(403)
        If the caller lacks enterprise_admin role.
    HTTPException(501)
        If the deployment is not enterprise edition or the feature is disabled.
    """
    # Feature gate fires via router dependency before this handler is entered.

    # OTel span (best-effort)
    _emit_operations_log_span(auth=auth, team_id=team_id, operation_type=operation_type)

    logger.info(
        "admin-sync operations-log request: user_id=%r limit=%d offset=%d "
        "team_id=%r operation_type=%r",
        str(auth.user_id),
        limit,
        offset,
        team_id,
        operation_type,
    )

    tenant_id = ctx.tenant_id

    service = EnterpriseContextSyncService(session=session, settings=settings)
    data = service.get_sync_operations_log(
        tenant_id=tenant_id,
        limit=limit,
        offset=offset,
        event_type=operation_type,
        team_id=team_id,
    )

    entries = [
        SyncOperationLogEntry(
            operation_id=e["operation_id"],
            operation_type=e["operation_type"],
            team_id=e.get("team_id"),
            team_name=None,
            triggered_by=e.get("triggered_by"),
            status=e.get("status", "complete"),
            artifact_count=e.get("artifact_count", 0),
            started_at=e["started_at"],
            completed_at=e.get("completed_at"),
        )
        for e in data["entries"]
    ]

    return SyncOperationsLogResponse(entries=entries, total=data["total"])


@router.post(
    "/admin/sync/propagate",
    summary="Trigger forced propagation",
    description=(
        "Queue a forced-propagation job that pushes one or more artifacts "
        "across the specified teams.  Supports soft (missing/outdated only) "
        "and hard (overwrite all) modes.\n\n"
        "Returns HTTP 202 immediately with the job ID. Poll "
        "``GET /admin/sync/propagate/{job_id}/status`` for progress.  "
        "Hard mode currently uses soft-mode push logic; full GitOps "
        "overwrite will be added when ECS-7 lands."
    ),
    response_model=PropagationJobResponse,
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        202: {"description": "Propagation job queued successfully."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        501: {
            "description": (
                "Admin Sync Management is not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
async def trigger_propagation(
    request: PropagationRequest,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
) -> PropagationJobResponse:
    """Queue a forced-propagation job and start background execution.

    Parameters
    ----------
    request:
        Propagation request specifying target teams, artifact IDs, and mode.
    auth:
        Resolved enterprise_admin auth context (enforced by dependency).

    Returns
    -------
    PropagationJobResponse
        Newly created propagation job in ``queued`` state (HTTP 202).
        The job transitions to ``running`` asynchronously; poll the status
        endpoint to track progress.

    Raises
    ------
    HTTPException(403)
        If the caller lacks enterprise_admin role.
    HTTPException(501)
        If the deployment is not enterprise edition or the feature is disabled.
    """
    # Feature gate fires via router dependency before this handler is entered.

    tenant_id = ctx.tenant_id

    manager = get_propagation_job_manager()
    job = manager.create_job(
        team_ids=request.team_ids,
        artifact_ids=request.artifact_ids,
        mode=request.mode,
        tenant_id=tenant_id,
    )

    # OTel span (best-effort)
    _emit_propagate_span(
        auth=auth,
        job_id=job.job_id,
        team_ids=request.team_ids,
        mode=request.mode,
    )

    logger.info(
        "admin-sync propagate request: user_id=%r job_id=%r team_ids=%r mode=%r",
        str(auth.user_id),
        job.job_id,
        request.team_ids,
        request.mode,
    )

    # Import the session factory lazily to avoid circular imports.
    from skillmeat.cache.models import get_session as _get_session

    asyncio.create_task(
        manager.execute_propagation(
            job_id=job.job_id,
            tenant_id=tenant_id,
            session_factory=_get_session,
            auth_context=auth,
        )
    )

    return _job_to_response(job)


@router.get(
    "/admin/sync/propagate/{job_id}/status",
    summary="Get propagation job status",
    description=(
        "Poll the current status and progress of a propagation job "
        "previously created via ``POST /admin/sync/propagate``.\n\n"
        "Returns 404 when the job ID is unknown (job lost after restart "
        "or ID typo).  Progress is updated per-team so callers can render "
        "a live progress bar."
    ),
    response_model=PropagationJobResponse,
    responses={
        200: {"description": "Propagation job status."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        404: {"description": "Propagation job not found."},
        501: {
            "description": (
                "Admin Sync Management is not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def get_propagation_job_status(
    job_id: str,
    auth: EnterpriseAdminDep,
) -> PropagationJobResponse:
    """Return current status of a propagation job.

    Parameters
    ----------
    job_id:
        Unique identifier of the propagation job to query.
    auth:
        Resolved enterprise_admin auth context (enforced by dependency).

    Returns
    -------
    PropagationJobResponse
        Current job status and progress.

    Raises
    ------
    HTTPException(403)
        If the caller lacks enterprise_admin role.
    HTTPException(404)
        If no job exists with the given job_id.
    HTTPException(501)
        If the deployment is not enterprise edition or the feature is disabled.
    """
    # Feature gate fires via router dependency before this handler is entered.

    logger.info(
        "admin-sync propagate status request: user_id=%r job_id=%r",
        str(auth.user_id),
        job_id,
    )

    manager = get_propagation_job_manager()
    job = manager.get_job(job_id)

    if job is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Propagation job '{job_id}' not found. "
                "Jobs are stored in-process and are lost on server restart."
            ),
        )

    return _job_to_response(job)


@router.get(
    "/admin/sync/propagate/{operation_id}/pr-links",
    summary="Get PR links for a propagation operation",
    description=(
        "Return links to pull requests created or updated as part of a "
        "GitOps hard-update propagation operation.\n\n"
        "PR URLs are sourced from ``hard_update_pr_opened`` audit events "
        "stored in ``EnterpriseArtifactHistoryEvent`` when "
        "``_gitops_hard_update`` completes successfully.\n\n"
        "Returns HTTP 404 when no ``hard_update_pr_opened`` event exists "
        "for the given ``operation_id``."
    ),
    response_model=PropagationPRLinksResponse,
    responses={
        200: {"description": "PR links for the propagation operation."},
        404: {"description": "No propagation operation found for the given operation_id."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        501: {
            "description": (
                "Admin Sync Management is not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def get_propagation_pr_links(
    operation_id: str,
    settings: SettingsDep,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
    session: Annotated[Session, Depends(get_db_session)],
) -> PropagationPRLinksResponse:
    """Return PR links for a GitOps hard-update propagation operation.

    Parameters
    ----------
    operation_id:
        UUID string identifying the propagation operation.  Corresponds to
        the ``id`` of a ``hard_update_pr_opened``
        :class:`~skillmeat.cache.models_enterprise.EnterpriseArtifactHistoryEvent`
        row emitted when :meth:`_gitops_hard_update` completes.
    settings:
        Application settings used for feature flag checks.
    auth:
        Resolved enterprise_admin auth context (enforced by dependency).
    session:
        SQLAlchemy session for DB queries.

    Returns
    -------
    PropagationPRLinksResponse
        PR links associated with the operation, including PR URL, team, and
        artifact metadata sourced from the audit event payload.

    Raises
    ------
    HTTPException(403)
        If the caller lacks enterprise_admin role.
    HTTPException(404)
        If no ``hard_update_pr_opened`` event exists for the given
        ``operation_id`` under the caller's tenant.
    HTTPException(501)
        If the deployment is not enterprise edition or the feature is disabled.
    """
    # Feature gate fires via router dependency before this handler is entered.

    # OTel span (best-effort)
    _emit_pr_links_span(auth=auth, operation_id=operation_id)

    logger.info(
        "admin-sync propagate pr-links request: operation_id=%r user_id=%r",
        operation_id,
        str(auth.user_id),
    )

    tenant_id = ctx.tenant_id

    service = EnterpriseContextSyncService(session=session, settings=settings)

    try:
        data = service.get_propagation_pr_links(
            operation_id=operation_id,
            tenant_id=tenant_id,
        )
    except ValueError as exc:
        logger.warning(
            "admin-sync propagate pr-links: invalid operation_id=%r: %s",
            operation_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Propagation operation '{operation_id}' not found.",
        ) from exc

    if not data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Propagation operation '{operation_id}' not found.",
        )

    pr_link_entries = [
        PropagationPRLinkEntry(
            pr_id=link["pr_id"],
            team_id=link["team_id"],
            team_name=link["team_name"],
            title=link["title"],
            url=link["url"],
            status=link["status"],
        )
        for link in data.get("pr_links", [])
    ]

    return PropagationPRLinksResponse(
        operation_id=data["operation_id"],
        teams=data.get("teams", []),
        artifacts=data.get("artifacts", []),
        pr_links=pr_link_entries,
        created_at=data["created_at"],
    )
