"""Webhook receivers for external integrations.

Supports:
- GitHub webhook receiver for Git repository connections (GRC Phase 3, Batch 2b)
- CCDash webhook receiver for workflow degradation monitoring (DVCS-6.3)

Authentication is performed via HMAC-SHA256 signature verification.
No standard API auth is applied — external services are the callers and
HMAC signatures are the trust anchors.

All heavy processing is dispatched asynchronously via FastAPI BackgroundTasks.

Endpoints:
    POST /api/v1/webhooks/github/{connection_id}
    POST /api/v1/webhooks/ccdash
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
from typing import Any

from fastapi import APIRouter, BackgroundTasks, HTTPException, Request, status

from skillmeat.api.config import get_settings
from skillmeat.api.dependencies import (
    DbSessionDep,
    GitConnectionRepoDep,
    GitRepoScanServiceDep,
)
from skillmeat.core.ccdash_service import CCDashService, CCDashWebhookPayload
from skillmeat.core.git_repo_scan_service import _detect_artifact_type

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/webhooks",
    tags=["webhooks"],
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _extract_branch(ref: str) -> str:
    """Convert a GitHub ``ref`` string to a plain branch name.

    GitHub delivers the full ref in the form ``refs/heads/<branch>``.  This
    helper strips the ``refs/heads/`` prefix so the result can be compared
    directly to the connection's ``branch`` field.

    Args:
        ref: Git ref string as delivered by GitHub (e.g. ``'refs/heads/main'``).

    Returns:
        Branch name (e.g. ``'main'``).  Returns *ref* unchanged when the prefix
        is absent (guards against unexpected ref formats such as tags).
    """
    prefix = "refs/heads/"
    if ref.startswith(prefix):
        return ref[len(prefix) :]
    return ref


def _collect_touched_paths(commits: list[dict[str, Any]]) -> list[str]:
    """Aggregate all added, modified, and removed file paths from a commit list.

    Args:
        commits: List of GitHub commit objects from a push payload.

    Returns:
        Deduplicated list of repository-relative file paths touched by the
        push (across all commits in the payload).
    """
    paths: set[str] = set()
    for commit in commits:
        paths.update(commit.get("added", []))
        paths.update(commit.get("modified", []))
        paths.update(commit.get("removed", []))
    return list(paths)


def _has_artifact_paths(paths: list[str]) -> bool:
    """Return ``True`` if at least one path matches a known artifact signal.

    Each path is tested against the module-level ``_detect_artifact_type``
    function using a synthetic *blob* entry dict (the cheapest representation
    that the detector understands).  A path that returns a non-``None`` artifact
    type is considered an artifact path.

    Args:
        paths: Repository-relative file paths to check.

    Returns:
        ``True`` if any path is identified as an artifact-related path.
    """
    for path in paths:
        artifact_type = _detect_artifact_type(path, {"type": "blob"})
        if artifact_type is not None:
            return True
    return False


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.post(
    "/github/{connection_id}",
    status_code=status.HTTP_200_OK,
    summary="Receive GitHub push webhook",
    description="""
    Receive a GitHub push webhook for a registered Git repository connection.

    Authentication is via HMAC-SHA256 signature verification on the raw request
    body.  When the connection has a ``webhook_secret`` configured, the
    ``X-Hub-Signature-256`` header must be present and must contain a valid
    signature.  Requests with missing or invalid signatures are rejected with
    HTTP 401.

    Push events are silently ignored (HTTP 200) when:
    - The push targets a branch other than the connection's configured branch.
    - None of the touched file paths match known artifact detection signals.

    When the push is relevant, a scan is queued asynchronously and the scan ID
    is returned immediately.  Use ``GET /api/v1/git-scans/{scan_id}`` to poll
    the scan status.

    Duplicate detection: if a scan for the same ``(connection_id, trigger_sha)``
    pair already exists, the existing scan ID is returned with
    ``status='duplicate'``.
    """,
    response_description="Webhook acceptance status with optional scan ID.",
    # No response_model — the shape varies based on outcome.
)
async def github_webhook(
    connection_id: int,
    request: Request,
    background_tasks: BackgroundTasks,
    conn_repo: GitConnectionRepoDep,
    service: GitRepoScanServiceDep,
) -> dict[str, Any]:
    """Receive and process a GitHub push webhook.

    Args:
        connection_id: Integer PK of the ``GitRepoConnection`` that owns this
            webhook URL.
        request:        Raw FastAPI request (needed to read body as bytes for
                        HMAC verification before JSON parsing).
        background_tasks: FastAPI background task queue used to dispatch the
                        asynchronous scan.
        conn_repo:      Injected ``IGitRepoConnectionRepository`` implementation.
        service:        Injected ``GitRepoScanService`` instance.

    Returns:
        A dict with a ``status`` key.  Possible shapes:

        - ``{"status": "ignored", "reason": "<why>"}`` — push is irrelevant.
        - ``{"status": "accepted", "scan_id": <int>}`` — scan queued.
        - ``{"status": "duplicate", "scan_id": <int>}`` — scan already exists.

    Raises:
        HTTPException 404: Connection not found.
        HTTPException 401: Missing or invalid HMAC signature.
        HTTPException 400: Malformed JSON payload.
    """
    # ------------------------------------------------------------------
    # 1. Read raw body (bytes) — must happen before request.json()
    # ------------------------------------------------------------------
    body = await request.body()

    # ------------------------------------------------------------------
    # 2. Look up connection
    # ------------------------------------------------------------------
    connection = conn_repo.get_by_id(connection_id)
    if connection is None:
        logger.warning(
            "Webhook received for unknown connection_id=%s — returning 404",
            connection_id,
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Connection {connection_id!r} not found",
        )

    # ------------------------------------------------------------------
    # 3. HMAC-SHA256 verification (when webhook_secret is configured)
    # ------------------------------------------------------------------
    if connection.webhook_secret:
        signature_header = request.headers.get("X-Hub-Signature-256")
        if not signature_header:
            logger.warning(
                "Webhook for connection %s rejected — missing X-Hub-Signature-256 header",
                connection_id,
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing X-Hub-Signature-256 signature header",
            )

        expected_digest = hmac.new(
            connection.webhook_secret.encode("utf-8"),
            body,
            hashlib.sha256,
        ).hexdigest()
        expected_signature = f"sha256={expected_digest}"

        # Constant-time comparison to prevent timing attacks
        if not hmac.compare_digest(signature_header, expected_signature):
            logger.warning(
                "Webhook for connection %s rejected — invalid HMAC signature",
                connection_id,
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid webhook signature",
            )

    # ------------------------------------------------------------------
    # 4. Parse JSON payload (body already read as bytes)
    # ------------------------------------------------------------------
    try:
        payload: dict[str, Any] = json.loads(body)
    except (json.JSONDecodeError, ValueError) as exc:
        logger.warning(
            "Webhook for connection %s has malformed JSON body: %s",
            connection_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Malformed JSON payload",
        )

    # ------------------------------------------------------------------
    # 5. Branch filter — ignore pushes to wrong branches
    # ------------------------------------------------------------------
    ref = payload.get("ref", "")
    pushed_branch = _extract_branch(ref)
    configured_branch = connection.branch or "main"

    if pushed_branch != configured_branch:
        logger.debug(
            "Webhook for connection %s ignored — push to branch %r, expected %r",
            connection_id,
            pushed_branch,
            configured_branch,
        )
        return {"status": "ignored", "reason": "branch_mismatch"}

    # ------------------------------------------------------------------
    # 6. Extract commit SHA and touched paths
    # ------------------------------------------------------------------
    head_commit = payload.get("head_commit") or {}
    trigger_sha: str | None = head_commit.get("id") or None

    commits: list[dict[str, Any]] = payload.get("commits", [])
    touched_paths = _collect_touched_paths(commits)

    # ------------------------------------------------------------------
    # 7. Artifact path filter — ignore pushes with no artifact changes
    # ------------------------------------------------------------------
    if not _has_artifact_paths(touched_paths):
        logger.debug(
            "Webhook for connection %s ignored — no artifact paths in %d touched files",
            connection_id,
            len(touched_paths),
        )
        return {"status": "ignored", "reason": "no_artifact_paths"}

    # ------------------------------------------------------------------
    # 8. Trigger scan (handles idempotency internally)
    # ------------------------------------------------------------------
    try:
        result = service.trigger_scan(
            connection_id=connection_id,
            triggered_by="webhook",
            trigger_sha=trigger_sha,
        )
    except ValueError as exc:
        # trigger_scan raises ValueError when connection is not found — this
        # should not happen here since we already validated above, but guard
        # defensively.
        logger.error(
            "trigger_scan raised ValueError for connection %s: %s",
            connection_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        )

    scan_id: int = result["scan_id"]
    scan_status: str = result["status"]

    # Detect idempotent case: trigger_scan returns the existing scan with a
    # non-pending status when the same (connection, sha) pair was already seen.
    if scan_status != "pending":
        logger.info(
            "Duplicate webhook for connection %s / sha %s — reusing scan %s (status=%s)",
            connection_id,
            trigger_sha,
            scan_id,
            scan_status,
        )
        return {"status": "duplicate", "scan_id": scan_id}

    # ------------------------------------------------------------------
    # 9. Dispatch scan asynchronously — must respond before GitHub times out
    # ------------------------------------------------------------------
    background_tasks.add_task(service.run_scan, scan_id)

    logger.info(
        "Webhook accepted for connection %s / sha %s — scan %s queued",
        connection_id,
        trigger_sha,
        scan_id,
    )
    return {"status": "accepted", "scan_id": scan_id}


# ---------------------------------------------------------------------------
# CCDash Webhook Endpoint (DVCS-6.3)
# ---------------------------------------------------------------------------


@router.post(
    "/ccdash",
    status_code=status.HTTP_200_OK,
    summary="Receive CCDash workflow degradation webhook",
    description="""
    Receive a CCDash webhook reporting workflow effectiveness degradation.

    Authentication is via HMAC-SHA256 signature verification using the shared
    secret configured in SKILLMEAT_CCDASH_WEBHOOK_SECRET. When the secret is
    configured, the X-CCDash-Signature header must be present and contain a
    valid signature. Requests with missing or invalid signatures are rejected
    with HTTP 401.

    The endpoint implements a circuit breaker pattern:
    - Records degradation events and tracks failure counts
    - Triggers automatic rollbacks when effectiveness falls below threshold
    - Manages circuit breaker state (CLOSED/OPEN/HALF_OPEN)
    - Provides idempotency via request body hash

    Feature flag: dvcs_ccdash_circuit_breaker must be enabled.

    Rollback behavior:
    - Critical threshold (effectiveness < 50% or error_rate > 50%): immediate rollback
    - Configured threshold: rollback after 3 repeated failures
    - Warning threshold: increment failure counter only

    Response includes circuit breaker state and rollback status.
    All rollback execution is performed asynchronously via BackgroundTasks.
    """,
    response_description="Webhook processing status with circuit breaker state.",
)
async def ccdash_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    db_session: DbSessionDep,
) -> dict[str, Any]:
    """Process CCDash workflow effectiveness webhook.

    Args:
        request: Raw FastAPI request (needed for body and headers)
        background_tasks: FastAPI background task queue for async rollback
        db_session: Injected SQLAlchemy session

    Returns:
        Dict with processing status, circuit state, and rollback info.

    Raises:
        HTTPException 404: Feature disabled (dvcs_ccdash_circuit_breaker=False)
        HTTPException 401: Missing or invalid HMAC signature
        HTTPException 400: Malformed JSON payload or validation error
        HTTPException 429: Rate limit exceeded (if implemented)
        HTTPException 500: Unexpected processing error
    """
    settings = get_settings()

    # Feature flag check
    if not settings.dvcs_ccdash_circuit_breaker:
        logger.info("CCDash webhook received but feature is disabled")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="CCDash circuit breaker feature is disabled",
        )

    # ------------------------------------------------------------------
    # 1. Read raw body (bytes) — must happen before request.json()
    # ------------------------------------------------------------------
    body = await request.body()

    # ------------------------------------------------------------------
    # 2. HMAC-SHA256 verification (when secret is configured)
    # ------------------------------------------------------------------
    if settings.ccdash_webhook_secret:
        signature_header = request.headers.get("X-CCDash-Signature")
        if not signature_header:
            logger.warning(
                "CCDash webhook rejected — missing X-CCDash-Signature header"
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing X-CCDash-Signature header",
            )

        if not CCDashService.verify_webhook_signature(
            body, signature_header, settings.ccdash_webhook_secret
        ):
            logger.warning("CCDash webhook rejected — invalid HMAC signature")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid webhook signature",
            )

    # ------------------------------------------------------------------
    # 3. Parse and validate JSON payload
    # ------------------------------------------------------------------
    try:
        payload_dict: dict[str, Any] = json.loads(body)
        payload = CCDashWebhookPayload(payload_dict)
    except (json.JSONDecodeError, ValueError, KeyError) as exc:
        logger.warning("CCDash webhook has malformed payload: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Malformed webhook payload: {exc}",
        ) from exc

    # ------------------------------------------------------------------
    # 4. Check idempotency
    # ------------------------------------------------------------------
    idempotency_key = CCDashService.generate_idempotency_key(body)

    # TODO: Implement duplicate detection in database
    # For now, we'll process all requests

    # ------------------------------------------------------------------
    # 5. Process webhook via CCDash service
    # ------------------------------------------------------------------
    try:
        service = CCDashService(db_session)
        result = service.process_webhook(payload, settings.ccdash_rollback_threshold)

        # If rollback was triggered, queue async execution
        if result.get("rollback_triggered"):
            logger.info(
                "Queueing rollback execution for workflow %s (reason: %s)",
                payload.workflow_id,
                result.get("rollback_reason", "Unknown"),
            )

            # TODO: Implement async rollback execution
            # background_tasks.add_task(
            #     execute_rollback_async,
            #     workflow_id=payload.workflow_id,
            #     deployment_id=payload.deployment_id,
            #     rollback_reason=result.get("rollback_reason"),
            # )

        # Add processing metadata to response
        result.update(
            {
                "idempotency_key": idempotency_key[:16],  # First 16 chars for logging
                "feature_enabled": True,
                "threshold_used": settings.ccdash_rollback_threshold,
            }
        )

        logger.info(
            "CCDash webhook processed successfully for workflow %s: state=%s, rollback=%s",
            payload.workflow_id,
            result.get("circuit_state"),
            result.get("rollback_triggered"),
        )

        return result

    except Exception as exc:
        logger.exception("Unexpected error processing CCDash webhook: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process CCDash webhook",
        ) from exc
