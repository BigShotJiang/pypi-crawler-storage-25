"""FastAPI router for Git Repository Connector endpoints (GRC-API-001, GRC-API-002).

Provides CRUD operations for Git repository connections and scan lifecycle
management, including manual scan triggering and artifact indexing.

Endpoints:
    POST   /git-connections                    — Register a new connection
    GET    /git-connections                    — List connections by project_id
    GET    /git-connections/{id}               — Get single connection
    PATCH  /git-connections/{id}              — Update connection fields
    DELETE /git-connections/{id}              — Delete connection

    POST   /git-connections/{id}/scan         — Trigger a scan (async)
    GET    /git-connections/{id}/scans        — Scan history for connection

    GET    /git-scans/{scan_id}               — Scan status + artifacts
    POST   /git-scans/{scan_id}/index         — Index approved artifacts
"""

from __future__ import annotations

import logging
from typing import List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, status

from skillmeat.api.config import APISettings, get_settings
from skillmeat.api.dependencies import (
    AuthContextDep,
    GitConnectionRepoDep,
    GitRepoScanServiceDep,
    GitScanArtifactRepoDep,
    GitScanRepoDep,
    get_token_resolver,
)
from skillmeat.core.services.token_resolver import TokenResolverService
from skillmeat.api.schemas.git_connector import (
    GitRepoConnectionCreate,
    GitRepoConnectionResponse,
    GitRepoConnectionUpdate,
    GitRepoScanResponse,
    GitScanArtifactResponse,
    IndexScanRequest,
    ScanTriggerRequest,
    ScanTriggerResponse,
)

logger = logging.getLogger(__name__)

# The server registers a single ``router`` object; we use two prefixed
# sub-routers internally and merge them at the bottom of this module.
_conn_router = APIRouter(
    prefix="/git-connections",
    tags=["git-connections"],
)

_scan_router = APIRouter(
    prefix="/git-scans",
    tags=["git-connections"],
)

# ---------------------------------------------------------------------------
# GRC-API-001: Connection CRUD
# ---------------------------------------------------------------------------


@_conn_router.post(
    "",
    response_model=GitRepoConnectionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new Git repository connection",
    description=(
        "Register a GitHub repository for artifact scanning.  "
        "The ``webhook_secret`` field is stored encrypted and never returned "
        "in any response payload.  Returns 409 when the same "
        "(repo_url, branch) pair already exists."
    ),
)
async def create_git_connection(
    body: GitRepoConnectionCreate,
    conn_repo: GitConnectionRepoDep,
    auth: AuthContextDep,
) -> GitRepoConnectionResponse:
    """Create a new Git repository connection."""
    # Duplicate check: same (repo_url, branch) — connections are no longer
    # tied to a single project after M2M decoupling.
    existing = conn_repo.get_by_repo_url_branch(body.repo_url, body.branch)
    if existing is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"A connection for '{body.repo_url}' on branch '{body.branch}' "
                f"already exists."
            ),
        )

    try:
        connection = conn_repo.create(
            project_id=body.project_id,
            repo_url=body.repo_url,
            branch=body.branch,
            developer_id=body.developer_id,
            scan_schedule=body.scan_schedule,
            webhook_secret=body.webhook_secret,
        )
    except Exception as e:
        logger.exception("Failed to create git connection: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create git connection.",
        )

    return GitRepoConnectionResponse.model_validate(connection)


@_conn_router.get(
    "",
    response_model=List[GitRepoConnectionResponse],
    summary="List Git connections",
    description=(
        "Return connections filtered by *project_id*, *team_id*, or all "
        "unlinked connections.  Exactly one of ``project_id``, ``team_id``, or "
        "``unlinked=true`` should be supplied.  ``team_id`` is only supported on "
        "the enterprise edition and returns HTTP 400 on the local edition."
    ),
)
async def list_git_connections(
    conn_repo: GitConnectionRepoDep,
    auth: AuthContextDep,
    settings: APISettings = Depends(get_settings),
    project_id: Optional[str] = Query(
        None, description="Project identifier to filter by."
    ),
    team_id: Optional[str] = Query(
        None, description="Team identifier to filter by (enterprise only)."
    ),
    unlinked: bool = Query(
        False,
        description="When true, return only connections not linked to any project.",
    ),
    limit: int = Query(50, ge=1, le=200, description="Maximum records to return."),
    offset: int = Query(0, ge=0, description="Records to skip for pagination."),
) -> List[GitRepoConnectionResponse]:
    """List Git connections, optionally filtered by project, team, or link status."""
    if team_id is not None and settings.edition == "local":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="team_id filter is not supported on local edition",
        )

    try:
        if unlinked:
            connections = conn_repo.list_unlinked()
        elif team_id is not None:
            connections = conn_repo.list_by_team_id(team_id)
        elif project_id is not None:
            connections = conn_repo.list_by_project_id(
                project_id=project_id,
                limit=limit,
                offset=offset,
            )
        else:
            connections = conn_repo.list_all()
    except Exception as e:
        logger.exception("Failed to list git connections: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list git connections.",
        )

    return [GitRepoConnectionResponse.model_validate(c) for c in connections]


@_conn_router.get(
    "/{id}",
    response_model=GitRepoConnectionResponse,
    summary="Get a single Git connection",
    description="Return the connection identified by *id*, or 404 if not found.",
)
async def get_git_connection(
    id: int,
    conn_repo: GitConnectionRepoDep,
    auth: AuthContextDep,
) -> GitRepoConnectionResponse:
    """Get a single Git repository connection by ID."""
    connection = conn_repo.get_by_id(id)
    if connection is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Git connection '{id}' not found.",
        )
    return GitRepoConnectionResponse.model_validate(connection)


@_conn_router.patch(
    "/{id}",
    response_model=GitRepoConnectionResponse,
    summary="Update a Git connection",
    description=(
        "Partially update a Git repository connection.  Only supplied fields "
        "are applied.  The ``webhook_secret`` field is write-only and never "
        "returned in responses."
    ),
)
async def update_git_connection(
    id: int,
    body: GitRepoConnectionUpdate,
    conn_repo: GitConnectionRepoDep,
    auth: AuthContextDep,
) -> GitRepoConnectionResponse:
    """Partially update a Git repository connection."""
    # Build kwargs from non-None fields only
    updates = body.model_dump(exclude_none=True)

    if not updates:
        # Nothing to update — return current state
        connection = conn_repo.get_by_id(id)
        if connection is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Git connection '{id}' not found.",
            )
        return GitRepoConnectionResponse.model_validate(connection)

    try:
        updated = conn_repo.update(id, **updates)
    except Exception as e:
        logger.exception("Failed to update git connection %s: %s", id, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update git connection.",
        )

    if updated is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Git connection '{id}' not found.",
        )

    return GitRepoConnectionResponse.model_validate(updated)


@_conn_router.delete(
    "/{id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a Git connection",
    description="Remove a Git repository connection and all associated scan records.",
)
async def delete_git_connection(
    id: int,
    conn_repo: GitConnectionRepoDep,
    auth: AuthContextDep,
) -> None:
    """Delete a Git repository connection."""
    connection = conn_repo.get_by_id(id)
    if connection is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Git connection '{id}' not found.",
        )

    try:
        conn_repo.delete(id)
    except Exception as e:
        logger.exception("Failed to delete git connection %s: %s", id, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete git connection.",
        )

    return None


# ---------------------------------------------------------------------------
# GRC-API-002: Scan operation endpoints
# ---------------------------------------------------------------------------


@_conn_router.post(
    "/{id}/scan",
    response_model=ScanTriggerResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Trigger a repository scan",
    description=(
        "Queue an asynchronous scan of the repository attached to *id*.  "
        "The scan runs in the background; poll ``GET /api/v1/git-scans/{scan_id}`` "
        "to check progress.  Returns 409 when an identical (connection, sha) scan "
        "already exists (idempotent webhook re-delivery)."
    ),
)
async def trigger_scan(
    id: int,
    service: GitRepoScanServiceDep,
    background_tasks: BackgroundTasks,
    auth: AuthContextDep,
    body: ScanTriggerRequest = Depends(),
    token_resolver: TokenResolverService = Depends(get_token_resolver),
) -> ScanTriggerResponse:
    """Trigger an asynchronous scan for a Git connection."""
    # Resolve the best available GitHub token for this connection using the
    # five-level fallback chain (developer-scoped → developer-wildcard →
    # connection-level → org/team → env var).
    resolved_token = token_resolver.resolve(
        connection_id=str(id),
        user_id=str(auth.user_id) if hasattr(auth, "user_id") else None,
    )

    try:
        result = service.trigger_scan(
            connection_id=id,
            triggered_by=body.triggered_by,
            trigger_sha=body.trigger_sha,
        )
    except ValueError as e:
        logger.warning("Scan trigger rejected: %s", e)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.exception("Failed to trigger scan for connection %s: %s", id, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to trigger scan.",
        )

    background_tasks.add_task(service.run_scan, result["scan_id"], resolved_token)
    return ScanTriggerResponse(**result)


@_conn_router.get(
    "/{id}/scans",
    response_model=List[GitRepoScanResponse],
    summary="List scan history for a connection",
    description=(
        "Return a paginated list of scan records for the given connection, "
        "ordered most-recent first."
    ),
)
async def list_scans(
    id: int,
    scan_repo: GitScanRepoDep,
    auth: AuthContextDep,
    limit: int = Query(20, ge=1, le=100, description="Maximum scan records to return."),
    offset: int = Query(0, ge=0, description="Records to skip for pagination."),
) -> List[GitRepoScanResponse]:
    """Return scan history for a Git connection."""
    try:
        scans = scan_repo.list_by_connection_id(
            connection_id=id,
            limit=limit,
            offset=offset,
        )
    except Exception as e:
        logger.exception("Failed to list scans for connection %s: %s", id, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list scans.",
        )

    return [GitRepoScanResponse.model_validate(s) for s in scans]


# ---------------------------------------------------------------------------
# Scan-level endpoints (prefix: /git-scans, merged into `router` below)
# ---------------------------------------------------------------------------


@_scan_router.get(
    "/{scan_id}",
    response_model=GitRepoScanResponse,
    summary="Get scan status and discovered artifacts",
    description=(
        "Return the scan record identified by *scan_id* together with the list "
        "of artifact observations produced during the scan run."
    ),
)
async def get_scan(
    scan_id: int,
    scan_repo: GitScanRepoDep,
    artifact_repo: GitScanArtifactRepoDep,
    auth: AuthContextDep,
) -> GitRepoScanResponse:
    """Get a scan record with its artifact observations."""
    scan = scan_repo.get_by_id(scan_id)
    if scan is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan '{scan_id}' not found.",
        )

    try:
        raw_artifacts = artifact_repo.list_by_scan_id(scan_id)
    except Exception as e:
        logger.exception("Failed to fetch artifacts for scan %s: %s", scan_id, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch scan artifacts.",
        )

    scan_response = GitRepoScanResponse.model_validate(scan)
    scan_response.artifacts = [
        GitScanArtifactResponse.model_validate(a) for a in raw_artifacts
    ]
    return scan_response


@_scan_router.post(
    "/{scan_id}/index",
    summary="Index approved artifacts from a scan",
    description=(
        "Mark a subset of ``GitScanArtifact`` rows as indexed, importing them "
        "into the local artifact cache.  Provide the integer IDs of the rows "
        "to index in the request body."
    ),
    responses={
        200: {
            "description": "Count of successfully indexed artifacts.",
            "content": {
                "application/json": {"example": {"scan_id": 101, "indexed_count": 3}}
            },
        }
    },
)
async def index_scan_artifacts(
    scan_id: int,
    body: IndexScanRequest,
    service: GitRepoScanServiceDep,
    auth: AuthContextDep,
) -> dict:
    """Index a subset of artifacts discovered in a scan."""
    try:
        result = service.index_scan(
            scan_id=scan_id,
            artifact_ids=body.artifact_ids,
        )
    except Exception as e:
        logger.exception("Failed to index artifacts for scan %s: %s", scan_id, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to index scan artifacts.",
        )

    return result


# ---------------------------------------------------------------------------
# Combined router — server.py imports and registers `router`.
# ---------------------------------------------------------------------------

# Both sub-routers have their own prefixes; `router` is a prefix-free parent
# that aggregates them so the server only needs one `include_router` call.
router = APIRouter(tags=["git-connections"])
router.include_router(_conn_router)
router.include_router(_scan_router)
