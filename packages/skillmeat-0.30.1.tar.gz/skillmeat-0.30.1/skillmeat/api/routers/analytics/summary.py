"""Project analytics summary endpoint.

Provides aggregated statistics about managed projects, artifact
distribution, drift posture, and optional effectiveness/cost metrics.
"""

import logging
from typing import Dict, List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func

from skillmeat.api.dependencies import (
    AuthContextDep,
    DbSessionDep,
    get_settings,
    verify_api_key,
)
from skillmeat.api.schemas.analytics import (
    DriftAlertEntry,
    DriftAlertSummary,
    ProjectAnalyticsSummaryResponse,
)

logger = logging.getLogger(__name__)

def _require_analytics_local_edition() -> None:
    """Block analytics endpoints in enterprise mode."""
    settings = get_settings()
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Analytics is not available in enterprise mode in this version. "
                "See docs/dev/architecture/enterprise-intentional-stubs.md"
            ),
        )


router = APIRouter(
    prefix="/analytics",
    tags=["analytics"],
    dependencies=[Depends(verify_api_key), Depends(_require_analytics_local_edition)],
)

_TOP_DRIFTED_LIMIT = 5


@router.get(
    "/project-summary",
    response_model=ProjectAnalyticsSummaryResponse,
    summary="Get project analytics summary",
    description=(
        "Returns an aggregated analytics summary including total project count, "
        "artifact type distribution, and drift alert posture derived from the "
        "cache database. An empty cache returns zeros/empty collections, not 404."
    ),
)
def get_analytics_summary(
    auth: AuthContextDep,
    session: DbSessionDep,
) -> ProjectAnalyticsSummaryResponse:
    """Return aggregated project analytics from the cache DB.

    Args:
        auth: Authenticated request context.
        session: Database session (injected).

    Returns:
        ProjectAnalyticsSummaryResponse with aggregated statistics.
    """
    # Import here to avoid circular imports at module load time.
    from skillmeat.cache.models import Artifact, Project

    try:
        # ------------------------------------------------------------------
        # total_projects: distinct projects that have at least one artifact
        # ------------------------------------------------------------------
        total_projects: int = session.query(func.count(Project.id)).scalar() or 0

        # ------------------------------------------------------------------
        # artifact_type_counts: count per type string across all artifacts
        # ------------------------------------------------------------------
        type_rows = (
            session.query(Artifact.type, func.count(Artifact.id))
            .group_by(Artifact.type)
            .all()
        )
        artifact_type_counts: Dict[str, int] = {
            artifact_type: count for artifact_type, count in type_rows if artifact_type
        }

        # ------------------------------------------------------------------
        # drift_alerts: projects where any artifact is outdated or locally
        # modified.  changed_count = number of drifted artifacts per project.
        # ------------------------------------------------------------------
        drift_rows = (
            session.query(
                Artifact.project_id,
                func.count(Artifact.id).label("changed_count"),
            )
            .filter(
                (Artifact.is_outdated == True)
                | (Artifact.local_modified == True)  # noqa: E712
            )
            .group_by(Artifact.project_id)
            .order_by(func.count(Artifact.id).desc())
            .all()
        )

        # Build top_drifted by joining back to Project for the name
        drifted_project_ids: List[str] = [row.project_id for row in drift_rows]

        project_names: Dict[str, str] = {}
        if drifted_project_ids:
            project_rows = (
                session.query(Project.id, Project.name)
                .filter(Project.id.in_(drifted_project_ids))
                .all()
            )
            project_names = {pid: name for pid, name in project_rows}

        top_drifted: List[DriftAlertEntry] = []
        for row in drift_rows[:_TOP_DRIFTED_LIMIT]:
            name: str = project_names.get(row.project_id, "") or row.project_id or ""
            top_drifted.append(
                DriftAlertEntry(
                    project_name=name,
                    changed_count=row.changed_count,
                    entity_ref=f"proj:{name}",
                )
            )

        drift_alerts = DriftAlertSummary(
            total=len(drift_rows),
            top_drifted=top_drifted,
        )

        return ProjectAnalyticsSummaryResponse(
            total_projects=total_projects,
            artifact_type_counts=artifact_type_counts,
            drift_alerts=drift_alerts,
            avg_effectiveness_score=None,
            total_cost_mtd=None,
        )

    except Exception as exc:
        logger.exception("Failed to compute analytics summary: %s", exc)
        # Return empty/zero response rather than 500 for resilience,
        # but re-raise so FastAPI can return the error to the caller.
        raise
