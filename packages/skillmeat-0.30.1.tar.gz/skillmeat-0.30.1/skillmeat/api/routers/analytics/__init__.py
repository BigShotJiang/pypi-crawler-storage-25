"""Analytics routers package.

Exposes sub-routers so callers can do::

    from skillmeat.api.routers.analytics import router  # usage analytics
    from skillmeat.api.routers.analytics import ingestion_router  # telemetry ingestion
    from skillmeat.api.routers.analytics import summary_router  # project analytics summary
"""

from .ingestion import router as ingestion_router
from .summary import router as summary_router
from .usage import ConfigManagerDep, get_analytics_db, router

__all__ = [
    "ConfigManagerDep",
    "get_analytics_db",
    "ingestion_router",
    "router",
    "summary_router",
]
