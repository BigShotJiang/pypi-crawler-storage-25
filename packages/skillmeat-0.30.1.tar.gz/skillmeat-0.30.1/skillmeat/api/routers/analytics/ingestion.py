"""SAM telemetry ingestion API endpoints.

Provides endpoints for SAM clients to submit execution outcome batches
and project-level rollup signals.

API Endpoints:
    POST /analytics/execution-outcomes  - Ingest a batch of execution records
    POST /analytics/project-rollups     - Ingest a project-level rollup payload
"""

import logging
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from skillmeat.api.dependencies import get_settings, require_auth
from skillmeat.api.middleware.rate_limit import telemetry_rate_limiter
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.telemetry import (
    ExecutionOutcomeBatch,
    IngestionResponse,
    ProjectRollupPayload,
)
from skillmeat.cache.execution_outcome_repository import ExecutionOutcomeRepository
from skillmeat.cache.project_agentic_metrics_repository import AgenticMetricsRepository
from skillmeat.cache.session import get_db_session
from skillmeat.core.services.ingestion_service import IngestionService

logger = logging.getLogger(__name__)

def _require_analytics_local_edition() -> None:
    """Block analytics endpoints in enterprise mode."""
    settings = get_settings()
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Analytics is not available in enterprise mode in this version. "
                "See docs/dev/architecture/enterprise-intentional-stubs.md"
            ),
        )


router = APIRouter(
    prefix="/analytics",
    tags=["analytics-ingestion"],
    dependencies=[Depends(_require_analytics_local_edition)],
)

# ---------------------------------------------------------------------------
# Dependency injection
# ---------------------------------------------------------------------------

AuthWriteDep = Annotated[
    AuthContext,
    Depends(require_auth(scopes=["telemetry:write"])),
]


def get_ingestion_service(
    session: Annotated[Session, Depends(get_db_session)],
) -> IngestionService:
    """Construct IngestionService with its repository dependencies."""
    return IngestionService(
        outcome_repo=ExecutionOutcomeRepository(session=session),
        metrics_repo=AgenticMetricsRepository(session=session),
    )


IngestionServiceDep = Annotated[IngestionService, Depends(get_ingestion_service)]

# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/execution-outcomes",
    status_code=status.HTTP_202_ACCEPTED,
    response_model=IngestionResponse,
    summary="Ingest execution outcome batch",
    description=(
        "Accept a batch of workflow execution records from a SAM client. "
        "Records are individually validated for PII before persistence. "
        "Returns 422 when all records in the batch are rejected."
    ),
)
async def ingest_execution_outcomes(
    payload: ExecutionOutcomeBatch,
    _auth: AuthWriteDep,
    _rate: Annotated[None, Depends(telemetry_rate_limiter)],
    service: IngestionServiceDep,
) -> IngestionResponse:
    """Validate and persist a batch of execution outcome records.

    Args:
        payload: Batch of execution records submitted by the SAM client.
        _auth:   Authenticated context (telemetry:write scope enforced).
        _rate:   Rate-limit gate (100 req/min per token identity).
        service: Ingestion service instance.

    Returns:
        IngestionResponse with accepted/rejected counts.

    Raises:
        HTTPException 422: When every record in the batch was rejected.
    """
    logger.debug(
        "Ingesting execution batch: project_id=%s, count=%d",
        payload.project_id,
        len(payload.executions),
    )

    response = service.ingest_execution_batch(payload)

    if response.accepted == 0 and response.rejected > 0:
        logger.warning(
            "Execution batch fully rejected: project_id=%s, rejected=%d",
            payload.project_id,
            response.rejected,
        )
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={
                "error": "ALL_RECORDS_REJECTED",
                "message": "Every record in the batch was rejected.",
                "rejected": response.rejected,
                "errors": [e.model_dump() for e in response.errors],
            },
        )

    return response


@router.post(
    "/project-rollups",
    status_code=status.HTTP_202_ACCEPTED,
    response_model=IngestionResponse,
    summary="Ingest project-level rollup",
    description=(
        "Accept a periodic project-level telemetry rollup from a SAM client. "
        "In v1, rollup signals are acknowledged but not persisted directly — "
        "aggregation is derived from execution outcome rows."
    ),
)
async def ingest_project_rollup(
    payload: ProjectRollupPayload,
    _auth: AuthWriteDep,
    _rate: Annotated[None, Depends(telemetry_rate_limiter)],
    service: IngestionServiceDep,
) -> IngestionResponse:
    """Accept and acknowledge a project-level rollup payload.

    Args:
        payload: Project rollup payload submitted by the SAM client.
        _auth:   Authenticated context (telemetry:write scope enforced).
        _rate:   Rate-limit gate (100 req/min per token identity).
        service: Ingestion service instance.

    Returns:
        IngestionResponse acknowledging the rollup (accepted=1, rejected=0).
    """
    logger.debug(
        "Ingesting project rollup: project_id=%s, period=%s to %s",
        payload.project_id,
        payload.period_start,
        payload.period_end,
    )

    return service.ingest_project_rollup(payload)
