"""Enterprise team sync dashboard endpoints.

Exposes:
  - ``GET /enterprise/teams/{team_id}/sync-dashboard`` — full team sync health
  - ``GET /enterprise/teams`` — list teams accessible to the requesting user
  - ``POST /enterprise/teams/{team_id}/sync/bulk`` — trigger bulk sync operations

All endpoints require ``team_sync_dashboard_enabled`` and enterprise edition.
RBAC is enforced via the ``team_admin`` / ``system_admin`` roles.

Feature flag gate
-----------------
``settings.edition != "enterprise"`` or ``settings.team_sync_dashboard_enabled
is False`` → HTTP 501.

RBAC enforcement
-----------------
+----------------------------+-----------------------------------------------+
| endpoint                   | required role                                 |
+============================+===============================================+
| GET  sync-dashboard        | team_admin or system_admin                    |
+----------------------------+-----------------------------------------------+
| GET  teams/                | team_admin or system_admin                    |
+----------------------------+-----------------------------------------------+
| POST sync/bulk             | operation-dependent:                          |
|                            | push_baseline → team_admin                    |
|                            | sync_all → system_admin                       |
|                            | pull_all → team_admin or system_admin         |
+----------------------------+-----------------------------------------------+

OpenTelemetry
-------------
Best-effort spans are emitted for the dashboard and bulk sync endpoints.
OTel failures never propagate to the caller.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, AsyncGenerator, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, status
from starlette.responses import StreamingResponse

from skillmeat.api.dependencies import (
    ContextSyncServiceDep,
    EnterpriseContextDep,
    SettingsDep,
    require_auth,
)
from skillmeat.api.schemas.auth import AuthContext, Role
from skillmeat.api.schemas.enterprise_team_sync import (
    BulkSyncRequest,
    BulkSyncResponse,
    TeamSyncDashboardResponse,
)
from skillmeat.api.services.sync_job_manager import SyncJobManager, get_sync_job_manager

# ---------------------------------------------------------------------------
# Optional OpenTelemetry import — silently skipped when not installed.
# ---------------------------------------------------------------------------

try:
    from opentelemetry import trace as _otel_trace

    _tracer = _otel_trace.get_tracer(__name__)
    _OTEL_AVAILABLE = True
except ImportError:  # pragma: no cover — OTel is optional
    _OTEL_AVAILABLE = False
    _tracer = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Valid bulk-sync operation values
# ---------------------------------------------------------------------------

_VALID_BULK_OPERATIONS = frozenset({"push_baseline", "pull_all", "sync_all"})

# ---------------------------------------------------------------------------
# Feature flag gate
# ---------------------------------------------------------------------------


def _check_feature_flags(settings: SettingsDep) -> None:
    """Raise HTTP 501 when the team sync dashboard is unavailable.

    Two independent checks are applied:

    1. ``edition != "enterprise"`` — team hierarchy only exists in enterprise.
    2. ``team_sync_dashboard_enabled is False`` — may be administratively
       disabled even in enterprise edition.

    Args:
        settings: Current application settings.

    Raises:
        HTTPException 501: When edition is not enterprise, or when
            ``team_sync_dashboard_enabled`` is disabled.
    """
    if settings.edition != "enterprise":
        logger.debug(
            "team-sync-dashboard: edition=%s is not enterprise — returning 501",
            settings.edition,
        )
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Team Sync Dashboard is only available in the enterprise edition. "
                "Current edition: %s." % settings.edition
            ),
        )

    if not settings.team_sync_dashboard_enabled:
        logger.debug(
            "team-sync-dashboard: team_sync_dashboard_enabled=False — returning 501"
        )
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Team Sync Dashboard is not enabled in this deployment. "
                "Set SKILLMEAT_TEAM_SYNC_DASHBOARD_ENABLED=true to activate."
            ),
        )


# ---------------------------------------------------------------------------
# RBAC helpers
# ---------------------------------------------------------------------------


def _require_team_or_system_admin(auth_context: AuthContext) -> None:
    """Raise HTTP 403 unless the caller is team_admin or system_admin.

    Args:
        auth_context: Authenticated request context.

    Raises:
        HTTPException 403: When caller lacks the required role.
    """
    if not (auth_context.is_admin() or auth_context.has_role(Role.team_admin)):
        logger.warning(
            "team-sync RBAC denied: user=%s — requires team_admin or system_admin",
            auth_context.user_id,
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Team Sync Dashboard requires team_admin or system_admin role.",
        )


def _check_bulk_sync_rbac(operation: str, auth_context: AuthContext) -> None:
    """Enforce operation-specific role rules for bulk sync.

    +------------------+----------------------------------------------+
    | operation        | required role                                |
    +==================+==============================================+
    | push_baseline    | team_admin (or system_admin)                 |
    +------------------+----------------------------------------------+
    | sync_all         | system_admin only                            |
    +------------------+----------------------------------------------+
    | pull_all         | team_admin or system_admin                   |
    +------------------+----------------------------------------------+

    Args:
        operation: Bulk sync operation string.
        auth_context: Authenticated request context.

    Raises:
        HTTPException 403: When the caller lacks the required role.
    """
    is_system_admin = auth_context.is_admin()
    is_team_admin = auth_context.has_role(Role.team_admin)

    if operation == "sync_all":
        if not is_system_admin:
            logger.warning(
                "bulk-sync RBAC denied: user=%s operation=%s — requires system_admin",
                auth_context.user_id,
                operation,
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="The 'sync_all' operation requires system_admin role.",
            )
    elif operation in ("push_baseline", "pull_all"):
        if not (is_system_admin or is_team_admin):
            logger.warning(
                "bulk-sync RBAC denied: user=%s operation=%s — requires team_admin or system_admin",
                auth_context.user_id,
                operation,
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    f"The '{operation}' operation requires team_admin or system_admin role."
                ),
            )


# ---------------------------------------------------------------------------
# OTel helpers (best-effort; isolated so handlers stay readable)
# ---------------------------------------------------------------------------


def _emit_dashboard_span(team_id: str, auth_context: AuthContext) -> None:
    """Emit a best-effort OTel span for a sync-dashboard request.

    Span name: ``enterprise.team_sync.dashboard``

    Args:
        team_id: Team identifier.
        auth_context: Authenticated request context.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return

    try:
        with _tracer.start_as_current_span("enterprise.team_sync.dashboard") as span:
            span.set_attribute("team_id", team_id)
            span.set_attribute("user_id", str(auth_context.user_id))
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for team-sync dashboard", exc_info=True)


def _emit_bulk_sync_span(
    team_id: str, operation: str, auth_context: AuthContext
) -> None:
    """Emit a best-effort OTel span for a bulk sync request.

    Span name: ``enterprise.team_sync.bulk``

    Args:
        team_id: Team identifier.
        operation: Bulk sync operation string.
        auth_context: Authenticated request context.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return

    try:
        with _tracer.start_as_current_span("enterprise.team_sync.bulk") as span:
            span.set_attribute("team_id", team_id)
            span.set_attribute("operation", operation)
            span.set_attribute("user_id", str(auth_context.user_id))
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for bulk-sync", exc_info=True)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = APIRouter(
    prefix="/enterprise",
    tags=["Enterprise Team Sync"],
    dependencies=[Depends(_check_feature_flags)],
)

# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/teams/{team_id}/sync-dashboard",
    summary="Get team sync dashboard",
    description=(
        "Return the full sync health dashboard for a team, including a "
        "high-level summary and per-artifact breakdown.  Each artifact row "
        "lists how many developers have diverged or outdated copies relative "
        "to the team baseline.\n\n"
        "Phase 1: Summary-level sync health only.  File-content diffs are "
        "deferred to a future phase."
    ),
    response_model=TeamSyncDashboardResponse,
    responses={
        200: {"description": "Team sync dashboard data."},
        403: {
            "description": "Insufficient role — requires team_admin or system_admin."
        },
        404: {"description": "Team not found for the current tenant."},
        501: {
            "description": (
                "Team Sync Dashboard feature is not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def get_team_sync_dashboard(
    team_id: UUID,
    sync_service: ContextSyncServiceDep,
    ctx: EnterpriseContextDep,
    auth_context: AuthContext = Depends(require_auth()),
) -> TeamSyncDashboardResponse:
    """Return sync health dashboard for a single team.

    Parameters
    ----------
    team_id:
        UUID of the team to retrieve the dashboard for.
    sync_service:
        ``IContextSyncService`` injected per-request.
    auth_context:
        Resolved auth context for RBAC enforcement.

    Returns
    -------
    TeamSyncDashboardResponse
        Full team sync dashboard (summary + per-artifact rows).

    Raises
    ------
    HTTPException(403)
        If the caller lacks team_admin or system_admin role.
    HTTPException(404)
        If the team does not exist for the current tenant.
    HTTPException(501)
        If the deployment is not enterprise edition or the feature is disabled.
    """
    # 1. RBAC enforcement — feature gate fires via router dependency.
    _require_team_or_system_admin(auth_context)

    # 2. OTel span (best-effort)
    _emit_dashboard_span(team_id=str(team_id), auth_context=auth_context)

    tenant_id: str = str(ctx.tenant_id)

    logger.info(
        "team-sync-dashboard request: team_id=%r tenant_id=%r user_id=%r",
        str(team_id),
        tenant_id,
        str(auth_context.user_id),
    )

    try:
        result = sync_service.get_team_sync_dashboard(
            team_id=str(team_id),
            tenant_id=tenant_id,
        )
    except LookupError as exc:
        logger.info(
            "team-sync-dashboard: team not found — team_id=%r: %s",
            str(team_id),
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc) or f"Team '{team_id}' not found.",
        ) from exc
    except Exception as exc:
        logger.exception(
            "team-sync-dashboard: unexpected error for team_id=%r",
            str(team_id),
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while loading team sync dashboard.",
        ) from exc

    return result


@router.get(
    "/teams",
    summary="List accessible teams",
    description=(
        "Return a list of teams accessible to the requesting user, "
        "suitable for populating the team selector in the Team Sync Dashboard.\n\n"
        "``system_admin`` sees all teams for the tenant.  "
        "``team_admin`` sees only teams they are a member of."
    ),
    responses={
        200: {"description": "List of teams (id + name) accessible to the caller."},
        403: {
            "description": "Insufficient role — requires team_admin or system_admin."
        },
        501: {
            "description": (
                "Team Sync Dashboard feature is not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def list_accessible_teams(
    sync_service: ContextSyncServiceDep,
    ctx: EnterpriseContextDep,
    auth_context: AuthContext = Depends(require_auth()),
) -> List[dict]:
    """Return teams the requesting user can access for the sync dashboard.

    Parameters
    ----------
    sync_service:
        ``IContextSyncService`` injected per-request.
    auth_context:
        Resolved auth context for RBAC enforcement and scope filtering.

    Returns
    -------
    list[dict]
        List of ``{"id": str, "name": str}`` records.

    Raises
    ------
    HTTPException(403)
        If the caller lacks team_admin or system_admin role.
    HTTPException(501)
        If the deployment is not enterprise edition or the feature is disabled.
    """
    # 1. RBAC enforcement — feature gate fires via router dependency.
    _require_team_or_system_admin(auth_context)

    tenant_id: str = str(ctx.tenant_id)
    is_system_admin = auth_context.is_admin()
    caller_id = str(auth_context.user_id)

    logger.info(
        "list-accessible-teams request: tenant_id=%r user_id=%r is_system_admin=%r",
        tenant_id,
        caller_id,
        is_system_admin,
    )

    try:
        # system_admin sees all teams; team_admin sees only their own teams.
        teams = sync_service.list_teams(
            tenant_id=tenant_id,
            user_id=None if is_system_admin else caller_id,
        )
    except Exception as exc:
        logger.exception(
            "list-accessible-teams: unexpected error for tenant_id=%r",
            tenant_id,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while listing teams.",
        ) from exc

    return teams


# ---------------------------------------------------------------------------
# Bulk-sync orchestration helpers (BE-2.4)
# ---------------------------------------------------------------------------


def _resolve_bulk_artifact_ids(
    team_id: UUID,
    requested_ids: Optional[List[str]],
    sync_service: Any,
    auth_context: "AuthContext",
) -> List[str]:
    """Return the artifact IDs to target in a bulk-sync operation.

    If *requested_ids* is provided, use it directly.  Otherwise query the
    team's tracked artifact scope rows via the sync service and derive the
    artifact IDs from those rows.

    Parameters
    ----------
    team_id:
        UUID of the team being synced.
    requested_ids:
        Explicit artifact IDs from the request body, or ``None`` to target all.
    sync_service:
        Context sync service (enterprise edition provides
        ``EnterpriseContextSyncService``).
    auth_context:
        Caller's auth context for tenant scoping.

    Returns
    -------
    list[str]
        Artifact ID strings to include in the bulk operation.
    """
    if requested_ids is not None:
        return list(requested_ids)

    # Resolve all artifacts tracked by the team via the sync service.
    try:
        from skillmeat.cache.constants import DEFAULT_TENANT_ID
        from skillmeat.cache.enterprise_repositories import EnterpriseTeamSyncRepository

        tenant_uuid = (
            auth_context.tenant_id
            if auth_context.tenant_id is not None
            else DEFAULT_TENANT_ID
        )
        repo = EnterpriseTeamSyncRepository(sync_service.session)
        scope_rows = repo.get_all_scope_rows_for_team(
            team_id=team_id,
            tenant_id=tenant_uuid,
        )
        return [str(row.artifact_id) for row in scope_rows]
    except Exception:  # pragma: no cover — fallback for non-enterprise configs
        logger.warning(
            "bulk-sync: could not resolve team artifact list for team_id=%r; "
            "using empty list",
            str(team_id),
            exc_info=True,
        )
        return []


def _resolve_bulk_developer_ids(
    team_id: UUID,
    requested_ids: Optional[List[str]],
    sync_service: Any,
    auth_context: "AuthContext",
) -> List[str]:
    """Return the developer IDs to target in a bulk-sync operation.

    If *requested_ids* is provided, use it directly.  Otherwise query all
    team members via the sync service and derive user IDs from those rows.

    Parameters
    ----------
    team_id:
        UUID of the team being synced.
    requested_ids:
        Explicit developer UUIDs from the request body, or ``None`` to target all.
    sync_service:
        Context sync service (enterprise edition provides
        ``EnterpriseContextSyncService``).
    auth_context:
        Caller's auth context for tenant scoping.

    Returns
    -------
    list[str]
        Developer ID strings (UUID as str) to include in the bulk operation.
    """
    if requested_ids is not None:
        return list(requested_ids)

    # Resolve all members of the team via the sync service.
    try:
        from skillmeat.cache.constants import DEFAULT_TENANT_ID
        from skillmeat.cache.enterprise_repositories import EnterpriseTeamSyncRepository

        tenant_uuid = (
            auth_context.tenant_id
            if auth_context.tenant_id is not None
            else DEFAULT_TENANT_ID
        )
        repo = EnterpriseTeamSyncRepository(sync_service.session)
        team = repo.get_team_with_members(
            team_id=team_id,
            tenant_id=tenant_uuid,
        )
        if team is None:
            logger.warning(
                "bulk-sync: team not found for developer resolution: team_id=%r",
                str(team_id),
            )
            return []
        return [str(member.user_id) for member in team.members]
    except Exception:  # pragma: no cover — fallback for non-enterprise configs
        logger.warning(
            "bulk-sync: could not resolve team developer list for team_id=%r; "
            "using empty list",
            str(team_id),
            exc_info=True,
        )
        return []


def _run_bulk_sync_job(
    job_id: str,
    artifact_id: str,
    developer_id: str,
    operation: str,
    sync_service: Any,
    job_manager: "SyncJobManager",
    auth_context: AuthContext,
) -> None:
    """Execute a single bulk-sync job in a background task.

    Marks the job as started, invokes the appropriate sync-service method
    based on *operation*, then marks it completed or failed.

    Parameters
    ----------
    job_id:
        ``SyncJob.job_id`` registered in *job_manager*.
    artifact_id:
        Artifact ID string (``type:name`` format) being synced.
    developer_id:
        Developer UUID string identifying the target user scope.
    operation:
        One of ``"push_baseline"``, ``"pull_all"``, or ``"sync_all"``.
    sync_service:
        Context sync service instance.
    job_manager:
        ``SyncJobManager`` instance for status tracking.
    """
    from skillmeat.api.schemas.vcs_v2 import SyncAllResponseDTO

    job_manager.start_job(job_id)
    try:
        if operation == "push_baseline":
            sync_service.push_changes(
                project_path=developer_id,
                entity_ids=[artifact_id],
                auth_context=auth_context,
            )
        elif operation == "pull_all":
            sync_service.pull_changes(
                project_path=developer_id,
                entity_ids=[artifact_id],
                auth_context=auth_context,
            )
        else:
            # sync_all — pull then push (full reconcile)
            sync_service.pull_changes(
                project_path=developer_id,
                entity_ids=[artifact_id],
                auth_context=auth_context,
            )
            sync_service.push_changes(
                project_path=developer_id,
                entity_ids=[artifact_id],
                auth_context=auth_context,
            )

        result = SyncAllResponseDTO(
            synced_count=1,
            skipped_count=0,
            errors=[],
        )
        job_manager.complete_job(job_id, result)
    except Exception as exc:
        logger.exception(
            "bulk-sync job failed: job_id=%r artifact_id=%r developer_id=%r",
            job_id,
            artifact_id,
            developer_id,
        )
        job_manager.fail_job(job_id, str(exc))


@router.post(
    "/teams/{team_id}/sync/bulk",
    summary="Trigger bulk sync operation for a team",
    description=(
        "Queue a bulk synchronisation operation across a team's artifacts "
        "and/or developers.\n\n"
        "Supported operations:\n\n"
        "- ``push_baseline`` — push the team baseline to selected developers "
        "(requires team_admin)\n"
        "- ``pull_all`` — pull upstream updates into the team baseline "
        "(requires team_admin or system_admin)\n"
        "- ``sync_all`` — reconcile all developer copies against the team "
        "baseline (requires system_admin)\n\n"
        "Phase 1 stub: returns ``queued=0`` with empty ``operation_ids``. "
        "Full orchestration wired in a future phase."
    ),
    response_model=BulkSyncResponse,
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        202: {"description": "Bulk sync jobs queued successfully."},
        400: {"description": "Invalid operation value."},
        403: {"description": "Insufficient role for the requested operation."},
        404: {"description": "Team not found for the current tenant."},
        501: {
            "description": (
                "Team Sync Dashboard feature is not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def bulk_sync_team(
    team_id: UUID,
    request: BulkSyncRequest,
    background_tasks: BackgroundTasks,
    sync_service: ContextSyncServiceDep,
    ctx: EnterpriseContextDep,
    auth_context: AuthContext = Depends(require_auth()),
) -> BulkSyncResponse:
    """Queue a bulk sync operation for a team's artifacts.

    Parameters
    ----------
    team_id:
        UUID of the team to run the bulk sync operation against.
    request:
        Bulk sync request body specifying operation, artifact IDs, and
        developer IDs to target.
    background_tasks:
        FastAPI ``BackgroundTasks`` instance used to schedule per-pair sync
        work after the response is returned.
    sync_service:
        Injected context sync service (enterprise edition provides
        ``EnterpriseContextSyncService``).
    auth_context:
        Resolved auth context for RBAC enforcement.

    Returns
    -------
    BulkSyncResponse
        Number of jobs queued and their operation identifiers.

    Raises
    ------
    HTTPException(400)
        If the operation value is not one of the recognised values.
    HTTPException(403)
        If the caller lacks the required role for the requested operation.
    HTTPException(501)
        If the deployment is not enterprise edition or the feature is disabled.
    """
    # 1. Validate operation — feature gate fires via router dependency.
    if request.operation not in _VALID_BULK_OPERATIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Invalid operation {request.operation!r}.  "
                "Must be one of: " + ", ".join(sorted(_VALID_BULK_OPERATIONS)) + "."
            ),
        )

    # 3. Operation-specific RBAC enforcement
    _check_bulk_sync_rbac(operation=request.operation, auth_context=auth_context)

    # 4. OTel span (best-effort)
    _emit_bulk_sync_span(
        team_id=str(team_id),
        operation=request.operation,
        auth_context=auth_context,
    )

    logger.info(
        "bulk-sync request: team_id=%r operation=%r artifact_ids=%r developer_ids=%r user_id=%r",
        str(team_id),
        request.operation,
        request.artifact_ids,
        request.developer_ids,
        str(auth_context.user_id),
    )

    # 5. Resolve artifact list
    artifact_ids: List[str] = _resolve_bulk_artifact_ids(
        team_id=team_id,
        requested_ids=request.artifact_ids,
        sync_service=sync_service,
        auth_context=auth_context,
    )

    # 6. Resolve developer list
    developer_ids: List[str] = _resolve_bulk_developer_ids(
        team_id=team_id,
        requested_ids=request.developer_ids,
        sync_service=sync_service,
        auth_context=auth_context,
    )

    # 7. Create one job per (artifact, developer) pair and enqueue background work
    job_manager = get_sync_job_manager()
    job_ids: List[str] = []
    for artifact_id in artifact_ids:
        for developer_id in developer_ids:
            job = job_manager.create_job(artifact_id)
            job_ids.append(job.job_id)
            background_tasks.add_task(
                _run_bulk_sync_job,
                job_id=job.job_id,
                artifact_id=artifact_id,
                developer_id=developer_id,
                operation=request.operation,
                sync_service=sync_service,
                job_manager=job_manager,
                auth_context=auth_context,
            )

    logger.info(
        "bulk-sync queued: team_id=%r operation=%r jobs=%d",
        str(team_id),
        request.operation,
        len(job_ids),
    )
    return BulkSyncResponse(queued=len(job_ids), operation_ids=job_ids)


# ---------------------------------------------------------------------------
# SSE: sync job progress stream
# ---------------------------------------------------------------------------

_TERMINAL_JOB_STATUSES = frozenset({"completed", "failed"})

_SSE_POLL_INTERVAL = 0.5  # seconds between status polls


@router.get(
    "/teams/{team_id}/sync/progress/{job_id}/stream",
    summary="Stream sync job progress via Server-Sent Events",
    description=(
        "Open an SSE stream that emits real-time status updates for a running "
        "sync job.  The stream closes automatically when the job reaches a "
        "terminal state (``completed`` or ``failed``).\n\n"
        "SSE event types emitted:\n\n"
        "- ``job_started``    — ``{job_id, artifact_id}`` when job transitions "
        "to ``running``\n"
        "- ``job_progress``   — ``{job_id, status}`` on intermediate polls\n"
        "- ``job_completed``  — ``{job_id, artifact_id, result}`` on success\n"
        "- ``job_failed``     — ``{job_id, artifact_id, error_message}`` on "
        "failure\n\n"
        "Returns ``404`` immediately if the job does not exist."
    ),
    responses={
        200: {"description": "SSE stream opened successfully."},
        404: {"description": "Sync job not found."},
        501: {
            "description": (
                "Team Sync Dashboard feature is not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
async def stream_sync_job_progress(
    team_id: UUID,
    job_id: str,
    auth_context: AuthContext = Depends(require_auth()),
) -> StreamingResponse:
    """Stream SSE events for a sync job.

    Polls :func:`~skillmeat.api.services.sync_job_manager.SyncJobManager.get_job`
    on a 0.5-second interval, emitting lifecycle events as the job progresses.
    The stream closes once the job reaches a terminal status.

    Parameters
    ----------
    team_id:
        UUID of the team that owns the sync job (used for routing context;
        not validated against job ownership in Phase 2 stub).
    job_id:
        Unique identifier of the sync job to stream.
    auth_context:
        Resolved auth context — standard ``require_auth()`` guard.

    Returns
    -------
    StreamingResponse
        ``text/event-stream`` response with lifecycle SSE events.

    Raises
    ------
    HTTPException(404)
        If no job with ``job_id`` exists in the in-memory job manager.
    HTTPException(501)
        If the deployment is not enterprise edition or the feature is
        disabled.
    """
    # Validate job exists before opening the stream so the client receives
    # a synchronous 404 rather than a silent empty stream.
    # Feature gate fires via router dependency before this handler is entered.
    # a synchronous 404 rather than a silent empty stream.
    job_manager: SyncJobManager = get_sync_job_manager()
    job = job_manager.get_job(job_id)
    if job is None:
        logger.warning(
            "stream_sync_job_progress: job_id=%r not found — team_id=%r user_id=%r",
            job_id,
            str(team_id),
            str(auth_context.user_id),
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Sync job '{job_id}' not found.",
        )

    logger.info(
        "stream_sync_job_progress: opening SSE stream job_id=%r team_id=%r user_id=%r",
        job_id,
        str(team_id),
        str(auth_context.user_id),
    )

    async def event_generator() -> AsyncGenerator[str, None]:
        """Yield SSE-formatted strings until the job reaches a terminal state."""
        last_status: str = ""

        while True:
            current_job = job_manager.get_job(job_id)

            if current_job is None:
                # Job was evicted (e.g. cleanup) — close stream gracefully.
                logger.warning(
                    "stream_sync_job_progress: job_id=%r disappeared mid-stream — closing",
                    job_id,
                )
                payload: Dict[str, Any] = {"job_id": job_id, "status": "unknown"}
                yield f"event: job_failed\n"
                yield f"data: {json.dumps(payload)}\n\n"
                break

            current_status = current_job.status

            # Emit transition events on status changes.
            if current_status != last_status:
                if current_status == "running":
                    event_type = "job_started"
                    event_payload: Dict[str, Any] = {
                        "job_id": job_id,
                        "artifact_id": current_job.artifact_id,
                    }
                    yield f"event: {event_type}\n"
                    yield f"data: {json.dumps(event_payload)}\n\n"
                elif current_status in _TERMINAL_JOB_STATUSES:
                    # Terminal events are handled after the if-block below.
                    pass
                else:
                    # Generic progress event for non-terminal status changes.
                    event_type = "job_progress"
                    event_payload = {"job_id": job_id, "status": current_status}
                    yield f"event: {event_type}\n"
                    yield f"data: {json.dumps(event_payload)}\n\n"

                last_status = current_status

            # Check for terminal state and close the stream.
            if current_status in _TERMINAL_JOB_STATUSES:
                if current_status == "completed":
                    result_dict: Optional[Dict[str, Any]] = None
                    if current_job.result is not None:
                        try:
                            result_dict = current_job.result.model_dump()
                        except AttributeError:
                            # Fallback for dataclasses / older Pydantic.
                            result_dict = vars(current_job.result)  # type: ignore[arg-type]
                    terminal_payload: Dict[str, Any] = {
                        "job_id": job_id,
                        "artifact_id": current_job.artifact_id,
                        "result": result_dict,
                    }
                    yield "event: job_completed\n"
                    yield f"data: {json.dumps(terminal_payload)}\n\n"
                else:
                    terminal_payload = {
                        "job_id": job_id,
                        "artifact_id": current_job.artifact_id,
                        "error_message": current_job.error_message,
                    }
                    yield "event: job_failed\n"
                    yield f"data: {json.dumps(terminal_payload)}\n\n"

                logger.info(
                    "stream_sync_job_progress: job_id=%r reached terminal status=%r — closing stream",
                    job_id,
                    current_status,
                )
                break

            await asyncio.sleep(_SSE_POLL_INTERVAL)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
