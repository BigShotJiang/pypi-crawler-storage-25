"""Bundle import/export API endpoints.

Provides REST API for importing and validating artifact bundles.
"""

import logging
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Optional

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    UploadFile,
    status,
)

from skillmeat.api.dependencies import (
    BundleAuthoringEnabledDep,
    BundleRepoDep,
    ConfigManagerDep,
    ContextEntityRepoDep,
    SettingsDep,
    get_auth_context,
    require_auth,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.bundles import (
    ArtifactPopularity,
    BundleAnalyticsResponse,
    BundleArtifactSummary,
    BundleDeleteResponse,
    BundleDetailResponse,
    BundleEntityCreateRequest,
    BundleEntityDetailResponse,
    BundleEntityListResponse,
    BundleEntityResponse,
    BundleEntityUpdateRequest,
    BundleExportRequest,
    BundleExportResponse,
    BundleImportRequest,
    BundleImportResponse,
    BundleListItem,
    BundleListResponse,
    BundleMemberAddRequest,
    CollectionNotApplicableDetail,
    BundleMemberResponse,
    BundleMetadataResponse,
    BundlePreviewCategorization,
    BundlePreviewResponse,
    BundleValidationResponse,
    ImportedArtifactResponse,
    PreviewArtifact,
    ShareLinkDeleteResponse,
    ShareLinkResponse,
    ShareLinkUpdateRequest,
    ValidationIssueResponse,
)
from skillmeat.api.schemas.common import ErrorResponse
from skillmeat.core.artifact import ArtifactType
from skillmeat.core.interfaces.dtos import BundleDTO, BundleMembershipDTO
from skillmeat.core.collection import CollectionManager
from skillmeat.core.sharing.builder import BundleBuilder
from skillmeat.core.sharing.importer import BundleImporter
from skillmeat.core.sharing.validator import BundleValidator
from skillmeat.core.tier_enforcement import TierEnforcementEngine
from skillmeat.observability.tracing import trace_operation

_tier_enforcement_engine = TierEnforcementEngine()

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/bundles",
    tags=["bundles"],
)

_COLLECTION_NOT_APPLICABLE_DETAIL = CollectionNotApplicableDetail(
    message=(
        "Bundle ZIP import/preview is a local-edition filesystem workflow. "
        "Enterprise deployments use snapshot restore and artifact copy for "
        "tenant-to-tenant promotion."
    ),
    alternative_endpoint="/api/v1/enterprise-collections/{collection_id}/restore",
    alternative_workflow="Snapshot restore or enterprise artifact copy",
)


def _enterprise_bundle_collection_gate(settings) -> None:
    """Raise 404 if caller invokes a local-only bundle collection op in enterprise edition.

    Bundle import/preview/export use ``CollectionManager``, which is a
    filesystem-centric construct that does not exist in enterprise mode.
    Enterprise tenants should use the snapshot-restore / artifact-copy workflows
    instead.  This gate ensures they receive a structured, actionable 404 rather
    than an opaque 400 "Failed to load collection" from a ``CollectionManager``
    construction error.
    """
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_COLLECTION_NOT_APPLICABLE_DETAIL.model_dump(),
        )


@router.post(
    "/import",
    response_model=BundleImportResponse,
    status_code=status.HTTP_200_OK,
    summary="Import artifact bundle",
    description="Import a bundle ZIP file into collection with conflict resolution",
    responses={
        200: {"description": "Bundle imported successfully"},
        400: {"model": ErrorResponse, "description": "Invalid bundle or parameters"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        500: {"model": ErrorResponse, "description": "Import failed"},
    },
)
async def import_bundle(
    config_mgr: ConfigManagerDep,
    settings: SettingsDep,
    bundle_file: UploadFile = File(..., description="Bundle ZIP file to import"),
    strategy: str = Form(
        default="interactive",
        description="Conflict resolution strategy (merge, fork, skip, interactive)",
    ),
    collection_name: Optional[str] = Form(
        default=None,
        description="Target collection (uses active if None)",
    ),
    dry_run: bool = Form(
        default=False,
        description="Preview import without making changes",
    ),
    force: bool = Form(
        default=False,
        description="Force import even with validation warnings",
    ),
    expected_hash: Optional[str] = Form(
        default=None,
        description="Expected SHA-256 hash for verification",
    ),
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> BundleImportResponse:
    """Import artifact bundle into collection.

    Upload a bundle ZIP file and import its contents with comprehensive
    conflict resolution and validation.

    In enterprise edition this endpoint returns 404 ``not_applicable_in_edition``
    because bundle ZIP ingestion is a local filesystem workflow.  Enterprise
    tenants should use snapshot restore or artifact copy instead.

    Args:
        bundle_file: Uploaded bundle ZIP file
        strategy: Conflict resolution strategy
        collection_name: Target collection name
        dry_run: Preview mode flag
        force: Force import flag
        expected_hash: Expected bundle hash
        config_mgr: Configuration manager dependency
        settings: API settings (used for edition gate)

    Returns:
        BundleImportResponse with import details

    Raises:
        HTTPException: On validation or import failure, or in enterprise edition.
    """
    _enterprise_bundle_collection_gate(settings)
    temp_bundle_path = None

    try:
        # Validate strategy
        allowed_strategies = {"merge", "fork", "skip", "interactive"}
        if strategy not in allowed_strategies:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid strategy. Must be one of: {', '.join(allowed_strategies)}",
            )

        # Interactive strategy not supported in API (no user prompts)
        if strategy == "interactive" and not dry_run:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Interactive strategy not supported via API. Use merge, fork, or skip.",
            )

        # Validate file type
        if not (bundle_file.filename or "").endswith(".zip"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Bundle must be a ZIP file",
            )

        logger.info(
            f"Importing bundle: {bundle_file.filename} "
            f"(strategy={strategy}, dry_run={dry_run})"
        )

        # Save uploaded file to temp location
        with tempfile.NamedTemporaryFile(
            delete=False, suffix=".zip", prefix="skillmeat_bundle_"
        ) as temp_file:
            temp_bundle_path = Path(temp_file.name)
            content = await bundle_file.read()
            temp_file.write(content)

        # Initialize importer
        collection_mgr = CollectionManager(config=config_mgr)
        importer = BundleImporter(collection_mgr=collection_mgr)

        # Perform import (console=None for non-interactive)
        result = importer.import_bundle(
            bundle_path=temp_bundle_path,
            collection_name=collection_name,
            strategy=strategy,
            dry_run=dry_run,
            force=force,
            expected_hash=expected_hash,
            console=None,  # Non-interactive mode
        )

        # Convert to response model
        artifacts_response = [
            ImportedArtifactResponse(
                name=artifact.name,
                type=artifact.type,
                resolution=artifact.resolution,
                new_name=artifact.new_name,
                reason=artifact.reason,
            )
            for artifact in result.artifacts
        ]

        response = BundleImportResponse(
            success=result.success,
            imported_count=result.imported_count,
            skipped_count=result.skipped_count,
            forked_count=result.forked_count,
            merged_count=result.merged_count,
            artifacts=artifacts_response,
            errors=result.errors,
            warnings=result.warnings,
            bundle_hash=result.bundle_hash,
            import_time=result.import_time,
            summary=result.summary(),
        )

        if not result.success:
            # Import failed - return 400 with error details
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "message": "Bundle import failed",
                    "errors": result.errors,
                    "warnings": result.warnings,
                },
            )

        logger.info(f"Bundle import successful: {result.summary()}")
        return response

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(f"Bundle import failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Bundle import failed: {str(e)}",
        )

    finally:
        # Clean up temp file
        if temp_bundle_path and temp_bundle_path.exists():
            try:
                temp_bundle_path.unlink()
            except Exception as e:
                logger.warning(f"Failed to clean up temp bundle file: {e}")


@router.post(
    "/validate",
    response_model=BundleValidationResponse,
    status_code=status.HTTP_200_OK,
    summary="Validate bundle without importing",
    description="Check bundle integrity and validity without importing",
    responses={
        200: {"description": "Validation completed (check is_valid field)"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        500: {"model": ErrorResponse, "description": "Validation failed"},
    },
)
async def validate_bundle(
    bundle_file: UploadFile = File(..., description="Bundle ZIP file to validate"),
    expected_hash: Optional[str] = Form(
        default=None,
        description="Expected SHA-256 hash for verification",
    ),
    auth_context: AuthContext = Depends(get_auth_context),
) -> BundleValidationResponse:
    """Validate bundle without importing.

    Performs comprehensive validation including:
    - Hash verification (if expected_hash provided)
    - Path traversal prevention
    - Zip bomb detection
    - Schema validation
    - File size checks

    Args:
        bundle_file: Uploaded bundle ZIP file
        expected_hash: Expected SHA-256 hash

    Returns:
        BundleValidationResponse with validation details

    Raises:
        HTTPException: On validation error
    """
    temp_bundle_path = None

    try:
        # Validate file type
        if not (bundle_file.filename or "").endswith(".zip"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Bundle must be a ZIP file",
            )

        logger.info(f"Validating bundle: {bundle_file.filename}")

        # Save uploaded file to temp location
        with tempfile.NamedTemporaryFile(
            delete=False, suffix=".zip", prefix="skillmeat_validate_"
        ) as temp_file:
            temp_bundle_path = Path(temp_file.name)
            content = await bundle_file.read()
            temp_file.write(content)

        # Validate
        validator = BundleValidator()
        validation = validator.validate(temp_bundle_path, expected_hash)

        # Convert to response
        issues_response = [
            ValidationIssueResponse(
                severity=issue.severity,
                category=issue.category,
                message=issue.message,
                file_path=issue.file_path,
            )
            for issue in validation.issues
        ]

        response = BundleValidationResponse(
            is_valid=validation.is_valid,
            issues=issues_response,
            bundle_hash=validation.bundle_hash,
            artifact_count=validation.artifact_count,
            total_size_bytes=validation.total_size_bytes,
            summary=validation.summary(),
        )

        logger.info(f"Bundle validation completed: {validation.summary()}")
        return response

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(f"Bundle validation failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Bundle validation failed: {str(e)}",
        )

    finally:
        # Clean up temp file
        if temp_bundle_path and temp_bundle_path.exists():
            try:
                temp_bundle_path.unlink()
            except Exception as e:
                logger.warning(f"Failed to clean up temp bundle file: {e}")


@router.post(
    "/preview",
    response_model=BundlePreviewResponse,
    status_code=status.HTTP_200_OK,
    summary="Preview bundle before importing",
    description="Analyze bundle contents and detect conflicts without importing",
    responses={
        200: {"description": "Preview completed successfully"},
        400: {"model": ErrorResponse, "description": "Invalid bundle"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        500: {"model": ErrorResponse, "description": "Preview failed"},
    },
)
async def preview_bundle(
    config_mgr: ConfigManagerDep,
    settings: SettingsDep,
    bundle_file: UploadFile = File(..., description="Bundle ZIP file to preview"),
    collection_name: Optional[str] = Form(
        default=None,
        description="Target collection (uses active if None)",
    ),
    expected_hash: Optional[str] = Form(
        default=None,
        description="Expected SHA-256 hash for verification",
    ),
    auth_context: AuthContext = Depends(get_auth_context),
) -> BundlePreviewResponse:
    """Preview bundle before importing.

    Validates bundle and analyzes what would happen during import:
    - Lists all artifacts in bundle
    - Identifies conflicts with existing artifacts
    - Categorizes artifacts (new vs existing)
    - Shows validation issues

    This is a read-only operation - no artifacts are imported.

    In enterprise edition this endpoint returns 404 ``not_applicable_in_edition``
    because bundle ZIP preview relies on ``CollectionManager``, a local filesystem
    construct.  Enterprise tenants should use snapshot restore instead.

    Args:
        bundle_file: Uploaded bundle ZIP file
        collection_name: Target collection name
        expected_hash: Expected SHA-256 hash
        config_mgr: Configuration manager dependency
        settings: API settings (used for edition gate)

    Returns:
        BundlePreviewResponse with analysis results

    Raises:
        HTTPException: On validation or analysis failure, or in enterprise edition.
    """
    _enterprise_bundle_collection_gate(settings)
    temp_bundle_path = None
    temp_extract_dir = None

    try:
        # Validate file type
        if not (bundle_file.filename or "").endswith(".zip"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Bundle must be a ZIP file",
            )

        logger.info(f"Previewing bundle: {bundle_file.filename}")

        # Save uploaded file to temp location
        with tempfile.NamedTemporaryFile(
            delete=False, suffix=".zip", prefix="skillmeat_preview_"
        ) as temp_file:
            temp_bundle_path = Path(temp_file.name)
            content = await bundle_file.read()
            temp_file.write(content)

        # Step 1: Validate bundle
        validator = BundleValidator()
        validation = validator.validate(temp_bundle_path, expected_hash)

        # Convert validation issues to response format
        validation_issues = [
            ValidationIssueResponse(
                severity=issue.severity,
                category=issue.category,
                message=issue.message,
                file_path=issue.file_path,
            )
            for issue in validation.issues
        ]

        # If bundle is invalid, return early with validation results
        if not validation.is_valid:
            logger.warning(f"Bundle validation failed: {validation.summary()}")
            return BundlePreviewResponse(
                is_valid=False,
                bundle_hash=validation.bundle_hash,
                metadata=None,
                artifacts=[],
                categorization=BundlePreviewCategorization(),
                validation_issues=validation_issues,
                total_size_bytes=validation.total_size_bytes,
                collection_name=collection_name or "default",
                summary="Bundle validation failed - cannot preview",
            )

        # Step 2: Load target collection
        try:
            collection_mgr = CollectionManager(config=config_mgr)
            collection = collection_mgr.load_collection(collection_name)
            collection_name = collection.name
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to load collection: {e}",
            )

        # Step 3: Extract bundle and load manifest
        temp_extract_dir = Path(tempfile.mkdtemp(prefix="skillmeat_preview_"))

        with zipfile.ZipFile(temp_bundle_path, "r") as zf:
            zf.extractall(temp_extract_dir)

        manifest_path = temp_extract_dir / "bundle.toml"
        if not manifest_path.exists():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Bundle missing required bundle.toml manifest",
            )

        # Load manifest
        from skillmeat.utils.toml_compat import loads as toml_loads

        with open(manifest_path, "rb") as f:
            manifest_data = toml_loads(f.read().decode("utf-8"))

        # Extract bundle metadata
        bundle_section = manifest_data.get("bundle", {})
        metadata = BundleMetadataResponse(
            name=bundle_section.get("name", "unknown"),
            description=bundle_section.get("description", ""),
            author=bundle_section.get("creator", "unknown"),
            created_at=bundle_section.get("created_at", ""),
            version=bundle_section.get("version", "1.0.0"),
            license=bundle_section.get("license", "MIT"),
            tags=bundle_section.get("tags", []),
            homepage=bundle_section.get("homepage"),
            repository=bundle_section.get("repository"),
        )

        # Step 4: Analyze artifacts and detect conflicts
        from skillmeat.core.artifact import ArtifactType

        artifacts_data = manifest_data.get("artifacts", [])
        preview_artifacts = []
        new_count = 0
        existing_count = 0

        for artifact_data in artifacts_data:
            artifact_name = artifact_data["name"]
            artifact_type = ArtifactType(artifact_data["type"])
            artifact_version = artifact_data.get("version")
            artifact_path = artifact_data["path"]

            # Check if exists in collection
            existing = collection.find_artifact(artifact_name, artifact_type)

            has_conflict = existing is not None
            existing_version = None

            if has_conflict:
                existing_count += 1
                # Try to get version from existing artifact
                if existing.metadata and hasattr(existing.metadata, "version"):
                    existing_version = existing.metadata.version
                elif existing.resolved_version:
                    existing_version = existing.resolved_version
            else:
                new_count += 1

            preview_artifacts.append(
                PreviewArtifact(
                    name=artifact_name,
                    type=artifact_type.value,
                    version=artifact_version,
                    path=artifact_path,
                    has_conflict=has_conflict,
                    existing_version=existing_version,
                )
            )

        # Step 5: Create categorization
        categorization = BundlePreviewCategorization(
            new_artifacts=new_count,
            existing_artifacts=existing_count,
            will_import=new_count,
            will_require_resolution=existing_count,
        )

        # Step 6: Build summary
        summary_parts = []
        summary_parts.append(f"Bundle contains {len(preview_artifacts)} artifact(s)")
        if new_count > 0:
            summary_parts.append(f"{new_count} new")
        if existing_count > 0:
            summary_parts.append(f"{existing_count} conflict(s)")

        summary = (
            " - ".join(summary_parts) if len(summary_parts) > 1 else summary_parts[0]
        )

        # Build response
        response = BundlePreviewResponse(
            is_valid=True,
            bundle_hash=validation.bundle_hash,
            metadata=metadata,
            artifacts=preview_artifacts,
            categorization=categorization,
            validation_issues=validation_issues,
            total_size_bytes=validation.total_size_bytes,
            collection_name=collection_name,
            summary=summary,
        )

        logger.info(
            f"Bundle preview completed: {summary} (collection: {collection_name})"
        )
        return response

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(f"Bundle preview failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Bundle preview failed: {str(e)}",
        )

    finally:
        # Clean up temp files
        if temp_bundle_path and temp_bundle_path.exists():
            try:
                temp_bundle_path.unlink()
            except Exception as e:
                logger.warning(f"Failed to clean up temp bundle file: {e}")

        if temp_extract_dir and temp_extract_dir.exists():
            try:
                shutil.rmtree(temp_extract_dir, ignore_errors=True)
            except Exception as e:
                logger.warning(f"Failed to clean up temp extract directory: {e}")


@router.post(
    "/export",
    response_model=BundleExportResponse,
    status_code=status.HTTP_200_OK,
    summary="Export artifacts as a bundle",
    description="Create a bundle archive from selected artifacts with optional sharing",
    responses={
        200: {"description": "Bundle exported successfully"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid request or artifact not found",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        500: {"model": ErrorResponse, "description": "Export failed"},
    },
)
async def export_bundle(
    config_mgr: ConfigManagerDep,
    settings: SettingsDep,
    request: BundleExportRequest,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> BundleExportResponse:
    """Export artifacts as a bundle.

    Creates a .skillmeat-pack bundle containing selected artifacts with:
    - Comprehensive metadata
    - Cryptographic integrity verification
    - Optional digital signature
    - Optional shareable link generation

    In enterprise edition this endpoint returns 404 ``not_applicable_in_edition``
    because bundle ZIP export reads from ``CollectionManager``, a local filesystem
    construct.  Enterprise tenants should use snapshot restore / artifact copy.

    Args:
        config_mgr: Configuration manager dependency
        settings: API settings (used for edition gate)
        request: Export request with artifact IDs, metadata, and options

    Returns:
        BundleExportResponse with bundle details and download URL

    Raises:
        HTTPException: On validation or export failure, or in enterprise edition.
    """
    _enterprise_bundle_collection_gate(settings)
    try:
        logger.info(
            f"Exporting bundle: {request.metadata.name} "
            f"({len(request.artifact_ids)} artifacts)",
            extra={"bundle_name": request.metadata.name},
        )

        with trace_operation(
            "skillmeat.bundle.export",
            bundle_name=request.metadata.name,
        ) as span:
            # Initialize collection manager
            collection_mgr = CollectionManager(config=config_mgr)
            collection = collection_mgr.load_collection(request.collection_name)

            # Validate artifact IDs format and parse them
            artifacts_to_add = []
            warnings = []

            for artifact_id in request.artifact_ids:
                # Parse artifact_id format: "type::name"
                if "::" not in artifact_id:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Invalid artifact ID format: {artifact_id}. "
                        "Expected format: 'type::name' (e.g., 'skill::python-debugger')",
                    )

                artifact_type_str, artifact_name = artifact_id.split("::", 1)

                # Validate artifact type
                try:
                    artifact_type = ArtifactType(artifact_type_str)
                except ValueError:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Invalid artifact type: {artifact_type_str}. "
                        f"Must be one of: {', '.join([t.value for t in ArtifactType])}",
                    )

                # Verify artifact exists in collection
                artifact = collection.find_artifact(artifact_name, artifact_type)
                if not artifact:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"Artifact '{artifact_name}' of type '{artifact_type_str}' "
                        f"not found in collection '{collection.name}'",
                    )

                artifacts_to_add.append((artifact_name, artifact_type))

            # Create bundle builder with metadata
            builder = BundleBuilder(
                name=request.metadata.name,
                description=request.metadata.description,
                author=request.metadata.author,
                version=request.metadata.version,
                license=request.metadata.license,
                tags=request.metadata.tags,
                homepage=request.metadata.homepage,
                repository=request.metadata.repository,
                collection_name=collection.name,
            )

            # Add artifacts to builder
            for artifact_name, artifact_type in artifacts_to_add:
                try:
                    builder.add_artifact(artifact_name, artifact_type)
                except Exception as e:
                    logger.warning(
                        f"Failed to add artifact {artifact_name} ({artifact_type.value}): {e}"
                    )
                    warnings.append(f"Failed to add artifact {artifact_name}: {str(e)}")

            # Determine output directory (use bundles directory)
            bundles_dir = (
                config_mgr.get_collection_path(collection.name).parent / "bundles"
            )
            bundles_dir.mkdir(parents=True, exist_ok=True)

            # Build bundle (use .skillmeat-pack extension)
            output_filename = f"{request.metadata.name}.skillmeat-pack"
            output_path = bundles_dir / output_filename

            # Build bundle with options
            bundle = builder.build(
                output_path=output_path,
                validate=True,
                sign=request.options.sign_bundle,
                signing_key_id=request.options.signing_key_id,
            )

            # Calculate bundle size
            bundle_size = output_path.stat().st_size

            # Set span attributes now that we have the values
            span.set_attribute("bundle_id", bundle.bundle_hash or "unknown")
            span.set_attribute("member_count", len(bundle.artifacts))
            span.set_attribute("bundle_hash", bundle.bundle_hash or "")
            span.set_attribute("export_path", str(output_path))

            # Generate download URL (relative to API base)
            # Format: sha256:first64chars (shortened for readability)
            bundle_id_short = (
                bundle.bundle_hash[:71] if bundle.bundle_hash else "unknown"
            )
            download_url = f"/api/bundles/{bundle_id_short}/download"

            # Generate share link if requested
            share_link = None
            if request.options.generate_share_link:
                # TODO: Implement actual share link generation with vault storage
                # For now, return a placeholder
                share_link = (
                    f"https://skillmeat.app/share/{(bundle.bundle_hash or '')[7:15]}"
                )
                warnings.append(
                    "Share link generation not yet implemented. Placeholder returned."
                )

            # Create response metadata
            from datetime import datetime

            export_time = datetime.utcnow()

            response_metadata = BundleMetadataResponse(
                name=bundle.metadata.name,
                description=bundle.metadata.description,
                author=bundle.metadata.author,
                created_at=bundle.metadata.created_at,
                version=bundle.metadata.version,
                license=bundle.metadata.license,
                tags=bundle.metadata.tags,
                homepage=bundle.metadata.homepage,
                repository=bundle.metadata.repository,
            )

            response = BundleExportResponse(
                success=True,
                bundle_id=bundle.bundle_hash or "unknown",
                bundle_path=str(output_path),
                download_url=download_url,
                share_link=share_link,
                stream_url=None,  # SSE streaming not yet implemented
                metadata=response_metadata,
                artifact_count=len(bundle.artifacts),
                total_size_bytes=bundle_size,
                warnings=warnings,
                export_time=export_time,
            )

            logger.info(
                f"Bundle export successful: {bundle.metadata.name} "
                f"({bundle.artifact_count} artifacts, {bundle_size} bytes)",
                extra={
                    "bundle_name": bundle.metadata.name,
                    "bundle_id": bundle.bundle_hash or "unknown",
                    "member_count": len(bundle.artifacts),
                    "bundle_hash": bundle.bundle_hash or "",
                },
            )

            return response

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(f"Bundle export failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Bundle export failed: {str(e)}",
        )


# ---------------------------------------------------------------------------
# Shared constants and DTO-to-response helpers used by legacy bundle routes
# and the entity CRUD routes below.
# ---------------------------------------------------------------------------

# Default collection used when no explicit collection is supplied by the caller.
# Duplicated here (and later redeclared in the entity section for clarity) so
# that `list_bundles` / `get_bundle` / `delete_bundle` can reference it before
# the entity CRUD block is defined.
_DEFAULT_COLLECTION_ID = "default"


def _bundle_dto_to_list_item(data: "BundleDTO") -> BundleListItem:
    """Convert a :class:`BundleDTO` to a :class:`BundleListItem` for the list endpoint.

    The ``source`` field is derived from the bundle lifecycle status:
    * ``"published"`` → ``"created"``
    * any other status → ``"created"``

    Args:
        data: DTO returned by :meth:`IBundleRepository.list_bundles`.

    Returns:
        :class:`BundleListItem` suitable for :class:`BundleListResponse`.
    """
    return BundleListItem(
        bundle_id=data.id,
        name=data.name,
        description=data.description or "",
        author="",
        created_at=data.created_at or "",
        artifact_count=len(data.memberships),
        total_size_bytes=0,
        source="created",
        imported_at=data.published_at,
        tags=list(data.tags),
    )


def _bundle_dto_to_detail(data: "BundleDTO") -> BundleDetailResponse:
    """Convert a :class:`BundleDTO` to a :class:`BundleDetailResponse`.

    Maps entity-model fields onto the legacy import/export response shape.
    Fields that have no direct equivalent (e.g. ``total_files``, ``bundle_path``)
    are set to sensible zero-values.

    Args:
        data: DTO returned by :meth:`IBundleRepository.get_bundle`.

    Returns:
        :class:`BundleDetailResponse` with all fields populated.
    """
    metadata = BundleMetadataResponse(
        name=data.name,
        description=data.description or "",
        author="",
        created_at=data.created_at or "",
        version=data.version or "1.0.0",
        license=data.license or "MIT",
        tags=list(data.tags),
        homepage=data.homepage,
        repository=data.repository,
    )
    artifacts = [
        BundleArtifactSummary(
            name=m.artifact_uuid or m.context_entity_id or "unknown",
            type=m.member_type,
            version="",
            scope="user",
        )
        for m in data.memberships
    ]
    return BundleDetailResponse(
        bundle_id=data.id,
        metadata=metadata,
        artifacts=artifacts,
        dependencies=[],
        bundle_hash=data.id,
        total_size_bytes=0,
        total_files=len(artifacts),
        source="created",
        imported_at=data.published_at,
        bundle_path=None,
    )


@router.get(
    "",
    response_model=BundleListResponse,
    status_code=status.HTTP_200_OK,
    summary="List all bundles",
    description="Get list of all bundles with optional filtering by source (created, imported)",
    responses={
        200: {"description": "List of bundles retrieved successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        500: {"model": ErrorResponse, "description": "Failed to retrieve bundles"},
    },
)
async def list_bundles(
    bundle_repo: BundleRepoDep,
    source_filter: Optional[str] = None,
    auth_context: AuthContext = Depends(get_auth_context),
) -> BundleListResponse:
    """List all bundles with optional filtering.

    Returns a list of all bundles in the collection, with optional filtering
    by source (created, imported, marketplace).

    Args:
        bundle_repo: Injected bundle repository.
        source_filter: Optional filter by bundle source (created, imported, marketplace)

    Returns:
        BundleListResponse with list of bundles

    Raises:
        HTTPException: On retrieval failure
    """
    try:
        # Validate source filter
        if source_filter and source_filter not in [
            "created",
            "imported",
            "marketplace",
        ]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid source filter. Must be one of: created, imported, marketplace",
            )

        logger.info(f"Listing bundles (filter={source_filter or 'none'})")

        result = bundle_repo.list_bundles(
            collection_id=_DEFAULT_COLLECTION_ID,
            page=1,
            page_size=200,
        )

        bundle_items = [_bundle_dto_to_list_item(d) for d in result.items]

        # Apply source filter if specified (source is derived from bundle status/metadata)
        if source_filter:
            bundle_items = [b for b in bundle_items if b.source == source_filter]

        response = BundleListResponse(
            bundles=bundle_items,
            total=len(bundle_items),
            filtered_by=source_filter,
        )

        logger.info(f"Retrieved {len(bundle_items)} bundles (total: {result.total})")
        return response

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(f"Failed to list bundles: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve bundles: {str(e)}",
        )


@router.get(
    "/{bundle_id}/analytics",
    response_model=BundleAnalyticsResponse,
    status_code=status.HTTP_200_OK,
    summary="Get bundle analytics",
    description="Retrieve analytics data for a bundle including downloads and popular artifacts",
    responses={
        200: {"description": "Bundle analytics retrieved successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Bundle not found"},
        500: {"model": ErrorResponse, "description": "Failed to retrieve analytics"},
    },
)
async def get_bundle_analytics(
    bundle_id: str,
    bundle_repo: BundleRepoDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> BundleAnalyticsResponse:
    """Get analytics data for a specific bundle.

    Retrieves usage statistics including:
    - Total downloads/imports
    - Deployment counts
    - Popular artifacts from the bundle
    - Active projects using bundle artifacts

    Args:
        bundle_id: Bundle unique identifier (UUID hex or SHA-256 hash)
        bundle_repo: Injected bundle repository.

    Returns:
        BundleAnalyticsResponse with analytics data

    Raises:
        HTTPException: On retrieval failure or if bundle not found
    """
    try:
        logger.info(f"Retrieving analytics for bundle: {bundle_id}")

        # Verify bundle exists via repo
        try:
            data = bundle_repo.get_bundle(bundle_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Bundle not found: {bundle_id}",
            )

        # Analytics aggregation is not yet backed by a dedicated analytics DB.
        # Return zeroed stats derived from the repo record so the endpoint is
        # functional (non-mock) without a 503 in either edition.
        popular_artifacts = [
            ArtifactPopularity(
                artifact_name=m.artifact_uuid or m.context_entity_id or "unknown",
                artifact_type=m.member_type,
                deploy_count=0,
                last_deployed=None,
            )
            for m in data.memberships[:10]
        ]

        response = BundleAnalyticsResponse(
            bundle_id=data.id,
            bundle_name=data.name,
            total_downloads=0,
            total_deploys=0,
            popular_artifacts=popular_artifacts,
            first_imported=data.published_at or data.created_at,
            last_used=data.updated_at,
            active_projects=0,
        )

        logger.info(
            f"Retrieved analytics for bundle: {response.bundle_name} "
            f"(downloads: {response.total_downloads}, deploys: {response.total_deploys})"
        )
        return response

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(
            f"Failed to retrieve analytics for bundle {bundle_id}: {e}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve bundle analytics: {str(e)}",
        )


# ====================
# Share Link Management
# ====================


@router.put(
    "/{bundle_id}/share",
    response_model=ShareLinkResponse,
    status_code=status.HTTP_200_OK,
    summary="Create or update bundle share link",
    description="Generate or update a shareable link for a bundle with permissions and expiration",
    responses={
        200: {"description": "Share link created/updated successfully"},
        400: {"model": ErrorResponse, "description": "Invalid bundle_id or request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Bundle not found"},
        500: {"model": ErrorResponse, "description": "Failed to create share link"},
    },
)
async def update_bundle_share_link(
    bundle_id: str,
    request: ShareLinkUpdateRequest,
    bundle_repo: BundleRepoDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> ShareLinkResponse:
    """Create or update a shareable link for a bundle.

    Generates a shareable URL with configurable permissions, expiration, and download limits.
    The link allows controlled sharing of bundles with external users.

    Args:
        bundle_id: Bundle unique identifier (UUID hex or SHA-256 hash)
        request: Share link configuration (permissions, expiration, max downloads)
        bundle_repo: Injected bundle repository.

    Returns:
        ShareLinkResponse with shareable URL and link details

    Raises:
        HTTPException: On validation failure or if bundle not found
    """
    try:
        logger.info(
            f"Creating/updating share link for bundle: {bundle_id} "
            f"(permission={request.permission_level}, expiration={request.expiration_hours}h)"
        )

        # Verify bundle exists via repo
        try:
            data = bundle_repo.get_bundle(bundle_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Bundle not found: {bundle_id}",
            )

        # Share link persistence is not yet backed by dedicated storage.
        # Generate a deterministic short code and return a well-formed response
        # so the endpoint is functional in both editions without returning 503.
        import hashlib
        from datetime import datetime, timedelta

        now = datetime.utcnow()

        short_code = hashlib.sha256(f"{data.id}{now.isoformat()}".encode()).hexdigest()[
            :8
        ]

        expires_at = None
        if request.expiration_hours:
            expiration_time = now + timedelta(hours=request.expiration_hours)
            expires_at = expiration_time.isoformat() + "Z"

        full_url = f"https://skillmeat.app/share/{short_code}"
        short_url = f"https://sm.app/{short_code}"

        response = ShareLinkResponse(
            success=True,
            bundle_id=data.id,
            url=full_url,
            short_url=short_url,
            qr_code=None,
            permission_level=request.permission_level,
            expires_at=expires_at,
            max_downloads=request.max_downloads,
            download_count=0,
            created_at=now.isoformat() + "Z",
        )

        logger.info(
            f"Share link created for bundle {data.id}: {short_url} "
            f"(expires: {expires_at or 'never'})"
        )

        return response

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(
            f"Failed to create share link for bundle {bundle_id}: {e}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create share link: {str(e)}",
        )


@router.delete(
    "/{bundle_id}/share",
    response_model=ShareLinkDeleteResponse,
    status_code=status.HTTP_200_OK,
    summary="Revoke bundle share link",
    description="Delete and revoke the shareable link for a bundle",
    responses={
        200: {"description": "Share link revoked successfully"},
        400: {"model": ErrorResponse, "description": "Invalid bundle_id"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Bundle or share link not found"},
        500: {"model": ErrorResponse, "description": "Failed to revoke share link"},
    },
)
async def delete_bundle_share_link(
    bundle_id: str,
    bundle_repo: BundleRepoDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> ShareLinkDeleteResponse:
    """Revoke and delete the shareable link for a bundle.

    Removes the share link, preventing further access via the link.
    Existing downloads in progress may still complete.

    Args:
        bundle_id: Bundle unique identifier (UUID hex or SHA-256 hash)
        bundle_repo: Injected bundle repository.

    Returns:
        ShareLinkDeleteResponse with deletion status

    Raises:
        HTTPException: On deletion failure or if bundle/link not found
    """
    try:
        logger.info(f"Revoking share link for bundle: {bundle_id}")

        # Verify bundle exists via repo
        try:
            data = bundle_repo.get_bundle(bundle_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Bundle not found: {bundle_id}",
            )

        # Share link storage is not yet backed by a dedicated table.
        # Return a successful revocation response so the endpoint is functional
        # in both editions without returning 503.
        response = ShareLinkDeleteResponse(
            success=True,
            bundle_id=data.id,
            message="Share link revoked successfully",
        )

        logger.info(f"Share link revoked for bundle: {data.id}")
        return response

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(
            f"Failed to revoke share link for bundle {bundle_id}: {e}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to revoke share link: {str(e)}",
        )


# ====================
# Bundle Entity CRUD (BAV1-007 to BAV1-015)
# ====================
# Note: _DEFAULT_COLLECTION_ID is declared earlier in this module (before
# the list_bundles handler) so that all handlers can share the single constant.


def _membership_dto_to_response(dto: "BundleMembershipDTO") -> BundleMemberResponse:
    """Convert a :class:`BundleMembershipDTO` to a :class:`BundleMemberResponse`.

    Args:
        dto: DTO returned by IBundleRepository membership methods.

    Returns:
        BundleMemberResponse with all fields populated.
    """
    return BundleMemberResponse(
        bundle_id=dto.bundle_id,
        member_type=dto.member_type,
        artifact_uuid=dto.artifact_uuid,
        context_entity_id=dto.context_entity_id,
        artifact_tier=dto.artifact_tier,
        relationship_type=dto.relationship_type,
        pinned_version_hash=dto.pinned_version_hash,
        added_at=dto.added_at or "",
    )


def _entity_dict_to_response(data: "BundleDTO") -> BundleEntityDetailResponse:
    """Convert a :class:`BundleDTO` to a BundleEntityDetailResponse.

    Args:
        data: DTO returned by IBundleRepository methods.

    Returns:
        BundleEntityDetailResponse with all fields populated.
    """
    members = [_membership_dto_to_response(m) for m in data.memberships]
    return BundleEntityDetailResponse(
        id=data.id,
        collection_id=data.collection_id,
        name=data.name,
        description=data.description,
        version=data.version,
        status=data.status,
        tags=data.tags,
        license=data.license,
        homepage=data.homepage,
        repository=data.repository,
        created_at=data.created_at or "",
        updated_at=data.updated_at or "",
        published_at=data.published_at,
        member_count=len(members),
        members=members,
    )


def _entity_dict_to_summary(data: "BundleDTO") -> BundleEntityResponse:
    """Convert a :class:`BundleDTO` to a BundleEntityResponse (summary, no members).

    Args:
        data: DTO returned by IBundleRepository.list_bundles items.

    Returns:
        BundleEntityResponse with member_count derived from memberships list.
    """
    member_count = len(data.memberships)
    return BundleEntityResponse(
        id=data.id,
        collection_id=data.collection_id,
        name=data.name,
        description=data.description,
        version=data.version,
        status=data.status,
        tags=data.tags,
        license=data.license,
        homepage=data.homepage,
        repository=data.repository,
        created_at=data.created_at or "",
        updated_at=data.updated_at or "",
        published_at=data.published_at,
        member_count=member_count,
    )


# BAV1-007 — Create bundle entity
@router.post(
    "/entities",
    response_model=BundleEntityDetailResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create bundle entity",
    description="Create a new bundle entity in draft status",
    responses={
        201: {"description": "Bundle entity created successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        422: {
            "model": ErrorResponse,
            "description": "Validation error or name conflict",
        },
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def create_bundle_entity(
    request: BundleEntityCreateRequest,
    bundle_repo: BundleRepoDep,
    _: BundleAuthoringEnabledDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> BundleEntityDetailResponse:
    """Create a new bundle entity in draft status.

    Args:
        request: Bundle entity creation request.
        bundle_repo: Injected bundle repository.
        auth_context: Authenticated request context.

    Returns:
        BundleEntityDetailResponse for the newly created bundle.

    Raises:
        HTTPException: 422 on name collision; 500 on unexpected error.
    """
    with trace_operation("skillmeat.bundle.create") as span:
        try:
            data = bundle_repo.create_bundle(
                name=request.name,
                collection_id=_DEFAULT_COLLECTION_ID,
                description=request.description,
                version=request.version,
                tags=request.tags,
                license=request.license,
                homepage=request.homepage,
                repository=request.repository,
            )
            bundle_id = data.id
            span.set_attribute("bundle_id", bundle_id)
            span.set_attribute("bundle_name", request.name)
            logger.info(
                "Created bundle entity '%s'",
                request.name,
                extra={"bundle_id": bundle_id, "bundle_name": request.name},
            )
            return _entity_dict_to_response(data)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
            )
        except Exception as exc:
            logger.error(
                "Failed to create bundle entity: %s",
                exc,
                exc_info=True,
                extra={"bundle_name": request.name},
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to create bundle entity: {exc}",
            )


# BAV1-008 — List bundle entities
@router.get(
    "/entities",
    response_model=BundleEntityListResponse,
    status_code=status.HTTP_200_OK,
    summary="List bundle entities",
    description="Return a paginated list of bundle entities with optional status/tag filters",
    responses={
        200: {"description": "Bundle entity list retrieved successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def list_bundle_entities(
    bundle_repo: BundleRepoDep,
    _: BundleAuthoringEnabledDep,
    status_filter: Optional[str] = Query(
        default=None,
        alias="status",
        description="Filter by lifecycle status: draft | published | deprecated",
    ),
    tags: Optional[str] = Query(
        default=None,
        description="Comma-separated tag filter (AND logic — bundle must have all listed tags)",
    ),
    page: int = Query(default=1, ge=1, description="1-based page number"),
    page_size: int = Query(default=50, ge=1, le=100, description="Items per page"),
    auth_context: AuthContext = Depends(get_auth_context),
) -> BundleEntityListResponse:
    """Return a paginated list of bundle entities.

    Args:
        bundle_repo: Injected bundle repository.
        status_filter: Optional lifecycle status filter.
        tags: Optional comma-separated tag filter.
        page: 1-based page number.
        page_size: Maximum items per page.
        auth_context: Authenticated request context.

    Returns:
        BundleEntityListResponse with paginated items.

    Raises:
        HTTPException: 500 on unexpected error.
    """
    try:
        tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else None
        result = bundle_repo.list_bundles(
            collection_id=_DEFAULT_COLLECTION_ID,
            status=status_filter,
            tags=tag_list,
            page=page,
            page_size=page_size,
        )
        items = [_entity_dict_to_summary(d) for d in result.items]
        return BundleEntityListResponse(
            items=items,
            total=result.total,
            page=result.page,
            page_size=result.page_size,
        )
    except Exception as exc:
        logger.error("Failed to list bundle entities: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list bundle entities: {exc}",
        )


# BAV1-009 — Get single bundle entity
@router.get(
    "/entities/{bundle_id}",
    response_model=BundleEntityDetailResponse,
    status_code=status.HTTP_200_OK,
    summary="Get bundle entity",
    description="Retrieve a single bundle entity by its UUID, including its member list",
    responses={
        200: {"description": "Bundle entity retrieved successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Bundle entity not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_bundle_entity(
    bundle_id: str,
    bundle_repo: BundleRepoDep,
    _: BundleAuthoringEnabledDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> BundleEntityDetailResponse:
    """Retrieve a single bundle entity with its membership list.

    Args:
        bundle_id: UUID hex primary key.
        bundle_repo: Injected bundle repository.
        auth_context: Authenticated request context.

    Returns:
        BundleEntityDetailResponse including members.

    Raises:
        HTTPException: 404 if not found; 500 on unexpected error.
    """
    try:
        data = bundle_repo.get_bundle(bundle_id)
        return _entity_dict_to_response(data)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except Exception as exc:
        logger.error(
            "Failed to retrieve bundle entity '%s': %s", bundle_id, exc, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve bundle entity: {exc}",
        )


# BAV1-010 — Update bundle entity (draft only)
@router.put(
    "/entities/{bundle_id}",
    response_model=BundleEntityDetailResponse,
    status_code=status.HTTP_200_OK,
    summary="Update bundle entity",
    description="Partially update a draft bundle entity. Non-draft bundles return 422.",
    responses={
        200: {"description": "Bundle entity updated successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Bundle entity not found"},
        422: {"model": ErrorResponse, "description": "Bundle is not in draft status"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def update_bundle_entity(
    bundle_id: str,
    request: BundleEntityUpdateRequest,
    bundle_repo: BundleRepoDep,
    _: BundleAuthoringEnabledDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> BundleEntityDetailResponse:
    """Partially update a draft bundle entity.

    Only bundles in ``draft`` status may be updated.

    Args:
        bundle_id: UUID hex primary key.
        request: Fields to update (only non-None values are applied).
        bundle_repo: Injected bundle repository.
        auth_context: Authenticated request context.

    Returns:
        BundleEntityDetailResponse for the updated bundle.

    Raises:
        HTTPException: 404 if not found; 422 if not draft; 500 on unexpected error.
    """
    try:
        update_fields = request.model_dump(exclude_none=True)
        data = bundle_repo.update_bundle(bundle_id, **update_fields)
        return _entity_dict_to_response(data)
    except ValueError as exc:
        msg = str(exc)
        if "not found" in msg.lower():
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=msg)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=msg
        )
    except Exception as exc:
        logger.error(
            "Failed to update bundle entity '%s': %s", bundle_id, exc, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update bundle entity: {exc}",
        )


# BAV1-011 — Delete bundle entity
@router.delete(
    "/entities/{bundle_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete bundle entity",
    description="Hard-delete a draft bundle or soft-delete (deprecate) a published bundle",
    responses={
        204: {"description": "Bundle entity deleted successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Bundle entity not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def delete_bundle_entity(
    bundle_id: str,
    bundle_repo: BundleRepoDep,
    _: BundleAuthoringEnabledDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> None:
    """Delete a bundle entity.

    Draft bundles are hard-deleted; published bundles are soft-deleted
    (status set to ``deprecated``).

    Args:
        bundle_id: UUID hex primary key.
        bundle_repo: Injected bundle repository.
        auth_context: Authenticated request context.

    Raises:
        HTTPException: 404 if not found; 500 on unexpected error.
    """
    try:
        bundle_repo.delete_bundle(bundle_id)
        logger.info("Deleted bundle entity '%s'", bundle_id)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except Exception as exc:
        logger.error(
            "Failed to delete bundle entity '%s': %s", bundle_id, exc, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete bundle entity: {exc}",
        )


# BAV1-012 — Add member to bundle
@router.post(
    "/entities/{bundle_id}/members",
    response_model=BundleMemberResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Add member to bundle",
    description=(
        "Add an artifact or context entity as a member of a bundle. "
        "Use member_type='artifact' (default) with artifact_uuid, or "
        "member_type='context_entity' with context_entity_id. "
        "Returns 409 if already a member."
    ),
    responses={
        201: {"description": "Member added successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {
            "model": ErrorResponse,
            "description": "Bundle or referenced entity not found",
        },
        409: {"model": ErrorResponse, "description": "Member is already in the bundle"},
        422: {
            "model": ErrorResponse,
            "description": "Tier, relationship, or member_type validation error",
        },
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def add_bundle_member(
    bundle_id: str,
    request: BundleMemberAddRequest,
    bundle_repo: BundleRepoDep,
    context_entity_repo: ContextEntityRepoDep,
    _: BundleAuthoringEnabledDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> BundleMemberResponse:
    """Add an artifact or context entity as a member of a bundle.

    Args:
        bundle_id: UUID hex primary key of the bundle.
        request: Membership creation request.
        bundle_repo: Injected bundle repository.
        context_entity_repo: Injected context entity repository (for existence checks).
        auth_context: Authenticated request context.

    Returns:
        BundleMemberResponse for the created membership.

    Raises:
        HTTPException: 404 if bundle or referenced entity not found; 409 on
            duplicate; 422 on tier violation or missing required ID field;
            500 on unexpected error.
    """
    member_type = request.member_type or "artifact"

    with trace_operation(
        "skillmeat.bundle.member_add",
        bundle_id=bundle_id,
        member_type=member_type,
        artifact_uuid=request.artifact_uuid or "",
        context_entity_id=request.context_entity_id or "",
        artifact_type=request.artifact_type or "",
    ) as span:
        span.set_attribute("member_type", member_type)

        # --- Input validation: ensure the right ID is supplied for the member_type ---
        if member_type == "context_entity":
            if not request.context_entity_id:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail={
                        "error_code": "MISSING_CONTEXT_ENTITY_ID",
                        "message": (
                            "context_entity_id is required when "
                            "member_type='context_entity'"
                        ),
                    },
                )
            # Verify the context entity exists
            entity = context_entity_repo.get(request.context_entity_id)
            if entity is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Context entity '{request.context_entity_id}' not found",
                )
            span.set_attribute("tier_valid", True)

        else:
            # member_type == "artifact" (default) or any unrecognised value treated
            # as artifact for backward compatibility
            if not request.artifact_uuid:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail={
                        "error_code": "MISSING_ARTIFACT_UUID",
                        "message": (
                            "artifact_uuid is required when member_type='artifact'"
                        ),
                    },
                )

            # BAV4-003: Tier enforcement — validate artifact_type before writing to DB
            if request.artifact_type is not None:
                try:
                    candidate_type = ArtifactType(request.artifact_type)
                except ValueError:
                    span.set_attribute("tier_valid", False)
                    logger.warning(
                        "Tier violation: unknown artifact type '%s' for bundle '%s'",
                        request.artifact_type,
                        bundle_id,
                        extra={
                            "bundle_id": bundle_id,
                            "artifact_uuid": request.artifact_uuid,
                            "tier_violations": 1,
                        },
                    )
                    raise HTTPException(
                        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                        detail={
                            "error_code": "TIER_VIOLATION",
                            "message": (
                                f"TIER_VIOLATION: Unknown artifact type"
                                f" '{request.artifact_type}' defaults to rejection"
                            ),
                        },
                    )
                tier_result = _tier_enforcement_engine.validate_bundle_member(
                    candidate_type
                )
                if not tier_result.ok:
                    span.set_attribute("tier_valid", False)
                    logger.warning(
                        "Tier violation for bundle '%s': %s",
                        bundle_id,
                        tier_result.message,
                        extra={
                            "bundle_id": bundle_id,
                            "artifact_uuid": request.artifact_uuid,
                            "tier_violations": 1,
                        },
                    )
                    raise HTTPException(
                        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                        detail={
                            "error_code": tier_result.error_code,
                            "message": tier_result.message,
                        },
                    )
            span.set_attribute("tier_valid", True)

        try:
            data = bundle_repo.add_member(
                bundle_id=bundle_id,
                artifact_uuid=request.artifact_uuid,
                artifact_tier=request.artifact_tier,
                relationship_type=request.relationship_type,
                pinned_version_hash=request.pinned_version_hash,
                member_type=member_type,
                context_entity_id=request.context_entity_id,
            )
            if member_type == "context_entity":
                logger.info(
                    "Added context entity '%s' to bundle '%s'",
                    request.context_entity_id,
                    bundle_id,
                    extra={
                        "bundle_id": bundle_id,
                        "context_entity_id": request.context_entity_id,
                        "tier_violations": 0,
                    },
                )
            else:
                logger.info(
                    "Added artifact '%s' to bundle '%s'",
                    request.artifact_uuid,
                    bundle_id,
                    extra={
                        "bundle_id": bundle_id,
                        "artifact_uuid": request.artifact_uuid,
                        "tier_violations": 0,
                    },
                )
            return _membership_dto_to_response(data)
        except ValueError as exc:
            msg = str(exc)
            if "not found" in msg.lower():
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=msg)
            if "already a member" in msg.lower():
                raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=msg)
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=msg
            )
        except Exception as exc:
            logger.error(
                "Failed to add member to bundle '%s': %s",
                bundle_id,
                exc,
                exc_info=True,
                extra={
                    "bundle_id": bundle_id,
                    "artifact_uuid": request.artifact_uuid,
                    "context_entity_id": request.context_entity_id,
                },
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to add bundle member: {exc}",
            )


# BAV1-013 — Remove member from bundle
@router.delete(
    "/entities/{bundle_id}/members/{artifact_uuid}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Remove member from bundle",
    description="Remove an artifact member from a bundle. Only draft bundles allow removal.",
    responses={
        204: {"description": "Artifact member removed successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Bundle or membership not found"},
        422: {"model": ErrorResponse, "description": "Bundle is not in draft status"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def remove_bundle_member(
    bundle_id: str,
    artifact_uuid: str,
    bundle_repo: BundleRepoDep,
    _: BundleAuthoringEnabledDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> None:
    """Remove an artifact from a bundle's membership list.

    Only bundles in ``draft`` status permit member removal.

    Args:
        bundle_id: UUID hex primary key of the bundle.
        artifact_uuid: Stable artifact UUID to remove.
        bundle_repo: Injected bundle repository.
        auth_context: Authenticated request context.

    Raises:
        HTTPException: 404 if not found; 422 if bundle is published; 500 on
            unexpected error.
    """
    try:
        bundle_repo.remove_member(bundle_id, artifact_uuid)
        logger.info("Removed artifact '%s' from bundle '%s'", artifact_uuid, bundle_id)
    except ValueError as exc:
        msg = str(exc)
        if "not found" in msg.lower():
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=msg)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=msg
        )
    except Exception as exc:
        logger.error(
            "Failed to remove member '%s' from bundle '%s': %s",
            artifact_uuid,
            bundle_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to remove bundle member: {exc}",
        )


# BAV1-014 — Publish bundle
@router.post(
    "/entities/{bundle_id}/publish",
    response_model=BundleEntityDetailResponse,
    status_code=status.HTTP_200_OK,
    summary="Publish bundle",
    description="Transition a draft bundle to published status. Returns 422 if not draft.",
    responses={
        200: {"description": "Bundle published successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Bundle entity not found"},
        422: {"model": ErrorResponse, "description": "Bundle is not in draft status"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def publish_bundle_entity(
    bundle_id: str,
    bundle_repo: BundleRepoDep,
    _: BundleAuthoringEnabledDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> BundleEntityDetailResponse:
    """Publish a draft bundle, making it available for distribution.

    Args:
        bundle_id: UUID hex primary key.
        bundle_repo: Injected bundle repository.
        auth_context: Authenticated request context.

    Returns:
        BundleEntityDetailResponse for the published bundle.

    Raises:
        HTTPException: 404 if not found; 422 if not draft; 500 on unexpected error.
    """
    try:
        data = bundle_repo.publish_bundle(bundle_id)
        logger.info("Published bundle entity '%s'", bundle_id)
        return _entity_dict_to_response(data)
    except ValueError as exc:
        msg = str(exc)
        if "not found" in msg.lower():
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=msg)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=msg
        )
    except Exception as exc:
        logger.error("Failed to publish bundle '%s': %s", bundle_id, exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to publish bundle: {exc}",
        )


# BAV1-015 — Deprecate bundle
@router.post(
    "/entities/{bundle_id}/deprecate",
    response_model=BundleEntityDetailResponse,
    status_code=status.HTTP_200_OK,
    summary="Deprecate bundle",
    description="Transition a published bundle to deprecated status. Returns 422 if not published.",
    responses={
        200: {"description": "Bundle deprecated successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Bundle entity not found"},
        422: {
            "model": ErrorResponse,
            "description": "Bundle is not in published status",
        },
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def deprecate_bundle_entity(
    bundle_id: str,
    bundle_repo: BundleRepoDep,
    _: BundleAuthoringEnabledDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> BundleEntityDetailResponse:
    """Deprecate a published bundle, signalling it should no longer be used.

    Args:
        bundle_id: UUID hex primary key.
        bundle_repo: Injected bundle repository.
        auth_context: Authenticated request context.

    Returns:
        BundleEntityDetailResponse for the deprecated bundle.

    Raises:
        HTTPException: 404 if not found; 422 if not published; 500 on unexpected error.
    """
    try:
        data = bundle_repo.deprecate_bundle(bundle_id)
        logger.info("Deprecated bundle entity '%s'", bundle_id)
        return _entity_dict_to_response(data)
    except ValueError as exc:
        msg = str(exc)
        if "not found" in msg.lower():
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=msg)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=msg
        )
    except Exception as exc:
        logger.error(
            "Failed to deprecate bundle '%s': %s", bundle_id, exc, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to deprecate bundle: {exc}",
        )


# NOTE: These catch-all routes are registered LAST so that specific routes
# like /entities and /entities/{id} take precedence.
@router.get(
    "/{bundle_id}",
    response_model=BundleDetailResponse,
    status_code=status.HTTP_200_OK,
    summary="Get bundle details",
    description="Retrieve detailed information about a specific bundle",
    responses={
        200: {"description": "Bundle details retrieved successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Bundle not found"},
        500: {"model": ErrorResponse, "description": "Failed to retrieve bundle"},
    },
)
async def get_bundle(
    bundle_id: str,
    bundle_repo: BundleRepoDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> BundleDetailResponse:
    """Get detailed information about a specific bundle.

    Retrieves complete bundle metadata, artifact list, and other details.

    Args:
        bundle_id: Bundle unique identifier (UUID hex or SHA-256 hash)
        bundle_repo: Injected bundle repository.

    Returns:
        BundleDetailResponse with bundle details

    Raises:
        HTTPException: On retrieval failure or if bundle not found
    """
    try:
        logger.info(f"Retrieving bundle details: {bundle_id}")

        try:
            data = bundle_repo.get_bundle(bundle_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Bundle not found: {bundle_id}",
            )

        response = _bundle_dto_to_detail(data)
        logger.info(f"Retrieved bundle: {data.name}")
        return response

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(f"Failed to retrieve bundle {bundle_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve bundle: {str(e)}",
        )


@router.delete(
    "/{bundle_id}",
    response_model=BundleDeleteResponse,
    status_code=status.HTTP_200_OK,
    summary="Delete a bundle",
    description="Delete a bundle from the collection",
    responses={
        200: {"description": "Bundle deleted successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Bundle not found"},
        500: {"model": ErrorResponse, "description": "Failed to delete bundle"},
    },
)
async def delete_bundle(
    bundle_id: str,
    bundle_repo: BundleRepoDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> BundleDeleteResponse:
    """Delete a bundle from the collection.

    Removes the bundle file and its metadata. Does not affect artifacts
    that were previously imported from this bundle.

    Args:
        bundle_id: Bundle unique identifier (UUID hex or SHA-256 hash)
        bundle_repo: Injected bundle repository.

    Returns:
        BundleDeleteResponse with deletion status

    Raises:
        HTTPException: On deletion failure or if bundle not found
    """
    try:
        logger.info(f"Deleting bundle: {bundle_id}")

        try:
            bundle_repo.delete_bundle(bundle_id)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(exc),
            )

        response = BundleDeleteResponse(
            success=True,
            bundle_id=bundle_id,
            message="Bundle deleted successfully",
        )

        logger.info(f"Bundle deleted: {bundle_id}")
        return response

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(f"Failed to delete bundle {bundle_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete bundle: {str(e)}",
        )
