"""Sync-capture notification and status API endpoints.

Provides endpoints for external callers (filesystem watchers, CLI, or other
agents) to notify the sync-capture pipeline of detected content-hash changes,
and for the frontend status indicator to query the current sync-capture state.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, status

from skillmeat.api.dependencies import (
    require_auth,
)
from skillmeat.api.config import APISettings, get_settings
from skillmeat.api.schemas.common import ErrorResponse
from skillmeat.api.schemas.sync_capture import (
    SyncCaptureNotifyRequest,
    SyncCaptureNotifyResponse,
    SyncCaptureStatusResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/sync-capture",
    tags=["sync-capture"],
)

# ---------------------------------------------------------------------------
# Dependency helpers
# ---------------------------------------------------------------------------

SettingsDep = Annotated[APISettings, Depends(get_settings)]


def _get_sync_capture_service(settings: SettingsDep):
    """Return a :class:`~skillmeat.core.sync_capture_service.SyncCaptureService`
    bound to the default DB path.

    The service is cheap to construct (lazy-init internals) so a fresh
    instance per request is fine.
    """
    from skillmeat.core.sync_capture_service import SyncCaptureService

    return SyncCaptureService(settings=settings)


SyncCaptureServiceDep = Annotated[
    Any,
    Depends(_get_sync_capture_service),
]


def _require_sync_capture_enabled(settings: SettingsDep) -> None:
    """Dependency that aborts with 503 when sync capture is disabled."""
    if not settings.sync_capture_enabled:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Sync capture is disabled. "
                "Set SKILLMEAT_SYNC_CAPTURE_ENABLED=true to enable."
            ),
        )


# ---------------------------------------------------------------------------
# POST /sync-capture/notify
# ---------------------------------------------------------------------------


@router.post(
    "/notify",
    response_model=SyncCaptureNotifyResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Notify sync capture of a detected content-hash change",
    description=(
        "Records a pending debounce entry for the given artifact when a "
        "content-hash mismatch is detected. The entry enters a quiet-window "
        "period; after the window expires the background scanner captures a "
        "new version. Idempotent: calling again before the quiet window "
        "expires simply resets the timer."
    ),
    responses={
        202: {"description": "Change notification accepted"},
        404: {
            "model": ErrorResponse,
            "description": "Artifact not found in the local registry",
        },
        503: {
            "model": ErrorResponse,
            "description": "Sync capture feature is disabled",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        422: {"description": "Validation error (invalid artifact_id or hash)"},
    },
    dependencies=[Depends(_require_sync_capture_enabled)],
)
async def notify_sync_capture(
    request: SyncCaptureNotifyRequest,
    svc: SyncCaptureServiceDep,
    _auth=Depends(require_auth()),
) -> SyncCaptureNotifyResponse:
    """Accept a sync-capture notification and queue a debounce entry.

    Args:
        request: Notification payload containing artifact_id, content_hash,
            and trigger_source.
        svc: :class:`~skillmeat.core.sync_capture_service.SyncCaptureService`
            dependency.
        _auth: Auth context (enforces authentication; value unused here).

    Returns:
        202 Accepted with the debounce entry ID and artifact echo.

    Raises:
        HTTPException 404: Artifact does not exist in the local artifact store.
        HTTPException 503: Sync capture is disabled in settings.
    """
    artifact_id = request.artifact_id

    # Validate that the artifact exists before recording a debounce entry.
    # We perform a lightweight existence check via the filesystem artifact
    # manager to avoid a full repository round-trip.
    try:
        from skillmeat.api.dependencies import app_state

        artifact_mgr = app_state.artifact_manager
        if artifact_mgr is not None:
            # artifact_id is "type:name" — parse and use show() for lookup.
            try:
                _type_str, _name = artifact_id.split(":", 1)
            except ValueError:
                _name = artifact_id
                _type_str = None
            try:
                artifact = artifact_mgr.show(_name)
            except (ValueError, Exception):
                artifact = None
            if artifact is None:
                logger.info(
                    "notify_sync_capture: artifact not found artifact_id=%s",
                    artifact_id,
                )
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Artifact '{artifact_id}' not found",
                )
        # Enterprise edition: artifact_mgr is None; skip existence check.
        # The debounce entry will be recorded regardless in that case.
    except HTTPException:
        raise
    except Exception as exc:
        # Treat any unexpected manager error as an internal service error
        # rather than silently swallowing it.
        logger.warning(
            "notify_sync_capture: artifact existence check failed "
            "artifact_id=%s — %s",
            artifact_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to validate artifact existence",
        ) from exc

    # Delegate to SyncCaptureService (non-fatal internally).
    svc.on_change_detected(
        artifact_id=artifact_id,
        content_hash=request.content_hash,
        trigger_source=request.trigger_source.value,
    )

    # Retrieve the newly created / refreshed entry ID for the response.
    # This is best-effort: the service is non-fatal, so the entry might not
    # have been persisted if the DB is unavailable.
    entry_id: str | None = None
    try:
        from skillmeat.core.repositories.sync_debounce_repository import (
            SyncDebounceRepository,
        )

        repo = SyncDebounceRepository()
        entry = repo.get_pending_for_artifact(artifact_id)
        if entry is not None:
            entry_id = str(entry.id)
    except Exception as exc:
        logger.debug(
            "notify_sync_capture: could not retrieve entry_id for "
            "artifact_id=%s — %s",
            artifact_id,
            exc,
        )

    return SyncCaptureNotifyResponse(
        status="accepted",
        debounce_entry_id=entry_id,
        artifact_id=artifact_id,
    )


# ---------------------------------------------------------------------------
# GET /sync-capture/status
# ---------------------------------------------------------------------------


@router.get(
    "/status",
    response_model=SyncCaptureStatusResponse,
    summary="Get sync-capture subsystem status",
    description=(
        "Returns the current operational status of the sync-capture "
        "subsystem, including enabled flags, pending debounce count, and "
        "configured timing parameters. Used by the frontend status indicator."
    ),
    responses={
        200: {"description": "Sync capture status"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
    },
)
async def get_sync_capture_status(
    settings: SettingsDep,
    _auth=Depends(require_auth()),
) -> SyncCaptureStatusResponse:
    """Return the current sync-capture subsystem status.

    Args:
        settings: Application settings dependency.
        _auth: Auth context (enforces authentication; value unused here).

    Returns:
        :class:`~skillmeat.api.schemas.sync_capture.SyncCaptureStatusResponse`
        with current state and configuration.
    """
    pending_count = 0

    if settings.sync_capture_enabled:
        try:
            from skillmeat.core.repositories.sync_debounce_repository import (
                SyncDebounceRepository,
            )
            from skillmeat.cache.models import SyncDebounceEntry

            repo = SyncDebounceRepository()
            session = repo._get_session()
            try:
                pending_count = (
                    session.query(SyncDebounceEntry)
                    .filter(SyncDebounceEntry.status == "pending")
                    .count()
                )
            finally:
                session.close()
        except Exception as exc:
            logger.warning(
                "get_sync_capture_status: could not query pending count — %s",
                exc,
            )

    return SyncCaptureStatusResponse(
        enabled=settings.sync_capture_enabled,
        fs_watcher_enabled=(
            settings.sync_capture_enabled and settings.sync_capture_fs_watcher_enabled
        ),
        auto_scan_enabled=(
            settings.sync_capture_enabled and settings.sync_capture_auto_scan_enabled
        ),
        pending_count=pending_count,
        quiet_seconds=settings.sync_capture_quiet_seconds,
        scan_interval_seconds=settings.sync_capture_scan_interval_seconds,
        checked_at=datetime.now(timezone.utc),
    )
