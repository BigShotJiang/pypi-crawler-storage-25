"""IDP (Internal Developer Portal) integration API router.

Provides endpoints for Backstage/IDP scaffold generation and deployment
registration operations.

API Endpoints:
    POST /integrations/idp/scaffold                             - Render template files in-memory
    POST /integrations/idp/register-deployment                  - Register/update an IDP deployment set
    GET  /integrations/idp/context-card/{deployment_set_id}     - Context card summary for Backstage entity page
    GET  /integrations/idp/bom-card/{project_id}                - Latest BOM snapshot summary for Backstage
    GET  /integrations/idp/telemetry/global                     - Paginated global workflow telemetry feed
    GET  /integrations/idp/telemetry/{project_id}               - Per-project workflow telemetry for SAM Backstage
    GET  /integrations/idp/templates                            - List Backstage Template entities for all scaffold-enabled bundles
    GET  /integrations/idp/templates/{bundle_id}                - Single Backstage Template entity for a bundle
"""

import hmac
import json
import logging
import re
from base64 import b64encode
from datetime import datetime, timezone
from typing import Annotated, Any, Dict, List, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Path, Query, status

from skillmeat.api.config import APISettings, get_settings
from skillmeat.api.dependencies import (
    APIKeyDep,
    DbSessionDep,
    DeploymentRepoDep,
    SettingsDep,
    require_auth,
    require_local_edition,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.bom import (
    BomCardArtifactEntry,
    BomCardAttestationSummary,
    BomCardRecentEvent,
    BomCardResponse,
)
from skillmeat.api.schemas.idp_integration import (
    DriftDetails,
    DriftSummary,
    IDPContextCardResponse,
    IDPDriftResponse,
    IDPRegisterDeploymentRequest,
    IDPRegisterDeploymentResponse,
    IDPScaffoldRequest,
    IDPScaffoldResponse,
    RenderedFile,
)
from skillmeat.api.schemas.idp_telemetry import (
    IDPGlobalTelemetryResponse,
    IDPProjectTelemetryResponse,
)
from skillmeat.core.services.idp_telemetry_service import IDPTelemetryService
from skillmeat.cache.scaffold_template_repository import ScaffoldTemplateRepository
from skillmeat.observability.tracing import trace_operation

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/integrations/idp",
    tags=["integrations-idp"],
)

# ---------------------------------------------------------------------------
# In-process discovery cache
# ---------------------------------------------------------------------------
# Keyed by (bundle_id, bundle_version) so a version bump automatically misses.
# Thread safety: the GIL makes plain dict reads/writes atomic in CPython.
# The cache does not persist across server restarts — that is intentional.
# ---------------------------------------------------------------------------
_discovery_cache: Dict[tuple, Dict[str, Any]] = {}


def _get_or_build_entity(
    orm_template: Any,
    cache: Dict[tuple, Dict[str, Any]],
) -> Dict[str, Any]:
    """Return a cached Backstage entity dict, building and storing it on miss.

    The cache key is ``(bundle_id, bundle_version)``.  When the bundle has no
    version the key falls back to ``(bundle_id, None)`` — such entries are
    still cached but will be evicted whenever
    :func:`clear_discovery_cache` is called for that ``bundle_id``.

    Args:
        orm_template: A ``ScaffoldTemplate`` ORM instance.
        cache: The module-level ``_discovery_cache`` dict (passed explicitly
            so unit tests can inject a fresh dict without monkey-patching the
            module global).

    Returns:
        The Backstage Template entity dict (may be a shared cached reference —
        callers must not mutate the returned dict).
    """
    bundle = getattr(orm_template, "bundle", None)
    bundle_id: str = getattr(orm_template, "bundle_id", "") or ""
    bundle_version: Optional[str] = getattr(bundle, "version", None) if bundle else None
    cache_key = (bundle_id, bundle_version)

    if cache_key in cache:
        logger.debug(
            "Discovery cache hit: bundle_id=%s version=%s", bundle_id, bundle_version
        )
        return cache[cache_key]

    logger.debug(
        "Discovery cache miss: bundle_id=%s version=%s — building entity",
        bundle_id,
        bundle_version,
    )
    entity = _build_backstage_entity(orm_template)
    cache[cache_key] = entity
    return entity


def clear_discovery_cache(bundle_id: Optional[str] = None) -> int:
    """Evict entries from the in-process Backstage discovery cache.

    Args:
        bundle_id: When supplied, only entries whose key starts with this
            ``bundle_id`` are removed.  When ``None`` the entire cache is
            cleared.

    Returns:
        Number of cache entries removed.
    """
    global _discovery_cache
    if bundle_id is None:
        count = len(_discovery_cache)
        _discovery_cache.clear()
        logger.info("Discovery cache cleared (%d entries removed)", count)
        return count

    keys_to_delete = [k for k in _discovery_cache if k[0] == bundle_id]
    for k in keys_to_delete:
        del _discovery_cache[k]
    logger.info(
        "Discovery cache evicted %d entries for bundle_id=%s",
        len(keys_to_delete),
        bundle_id,
    )
    return len(keys_to_delete)


# =============================================================================
# Service-to-service authentication
# =============================================================================


def verify_idp_service_token(
    x_skillmeat_service_token: Annotated[
        str | None,
        Header(alias="X-SkillMeat-Service-Token", include_in_schema=False),
    ] = None,
    settings: APISettings = Depends(get_settings),
) -> None:
    """Validate the ``X-SkillMeat-Service-Token`` header for IDP endpoints.

    Behaviour:

    * When ``SKILLMEAT_IDP_SERVICE_TOKEN`` is **not set**: pass through
      unconditionally (permissive dev/demo mode).
    * When the env var **is set** and the header matches: pass through.
    * When the env var **is set** and the header is absent or wrong: raise
      ``HTTP 401``.

    Uses :func:`hmac.compare_digest` for constant-time comparison to prevent
    timing-based token guessing.  The token value is never written to log
    output.

    Parameters
    ----------
    x_skillmeat_service_token:
        Value of the ``X-SkillMeat-Service-Token`` request header, or ``None``
        if the header is absent.
    settings:
        Application settings (provides the expected token secret).

    Raises
    ------
    HTTPException(401)
        When the env var is set and the header is absent or does not match.
    """
    expected: str | None = settings.idp_service_token

    # Permissive mode: no token configured, skip check entirely.
    if not expected:
        return

    # Token is configured — header must be present and correct.
    if not x_skillmeat_service_token or not hmac.compare_digest(
        x_skillmeat_service_token.encode(), expected.encode()
    ):
        logger.warning(
            "IDP service-token auth: missing or invalid X-SkillMeat-Service-Token header"
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing service token",
        )


# Type alias for cleaner route signatures
IDPServiceTokenDep = Annotated[None, Depends(verify_idp_service_token)]


# =============================================================================
# API Endpoints
# =============================================================================


@router.post(
    "/scaffold",
    response_model=IDPScaffoldResponse,
    status_code=status.HTTP_200_OK,
    summary="Generate scaffold files for an IDP target",
    description=(
        "Renders a composite or skill artifact in-memory and returns the generated "
        "files as base64-encoded content.  Intended for use by Backstage software "
        "template actions and other IDP scaffolders."
    ),
    responses={
        200: {"description": "Scaffold files rendered successfully"},
        422: {"description": "Invalid target_id or variable validation error"},
        404: {"description": "Target artifact not found"},
        500: {"description": "Internal rendering error"},
    },
)
async def scaffold(
    request: IDPScaffoldRequest,
    session: DbSessionDep,
    settings: SettingsDep,
    _auth: APIKeyDep,
    _service_token: IDPServiceTokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> IDPScaffoldResponse:
    """Render scaffold files for a given artifact target.

    Handles two target types:

    - ``composite:*`` — delegates to
      :func:`skillmeat.core.services.template_service.render_in_memory` to
      produce rendered file content without any disk writes (unchanged v1
      behaviour).
    - ``bundle:*`` — resolves the Bundle dependency graph via
      :class:`~skillmeat.core.services.bundle_resolver.BundleResolver`,
      applies platform filtering via
      :class:`~skillmeat.core.services.platform_filter.PlatformFilter`, and
      optionally attaches a BOM sidecar via
      :class:`~skillmeat.core.services.bom_sidecar_generator.BomSidecarGenerator`.

    Args:
        request: Scaffold request containing target_id, variables, platform,
                 and include_bom flag.
        session: Database session (injected via DI; required for bundle
                 resolution and the existing composite path).
        settings: API settings (injected via DI; used to check feature flags).
        _auth: API key authentication (enforced when auth is enabled).
        auth_context: Caller auth context (requires ``artifact:write`` scope).

    Returns:
        IDPScaffoldResponse with list of base64-encoded rendered files.

    Raises:
        HTTPException: 422 if target_id or variables are invalid, bundle
                       resolution fails, or a feature flag blocks the request.
                       404 if the target artifact does not exist.
                       500 for unexpected rendering errors.
    """
    logger.info(
        "IDP scaffold requested: target_id=%s platform=%s include_bom=%s variables=%s",
        request.target_id,
        request.platform,
        request.include_bom,
        list(request.variables.keys()),
    )

    # ------------------------------------------------------------------
    # Route: bundle:* target — BundleResolver → PlatformFilter → (BOM)
    # ------------------------------------------------------------------
    if request.target_id.startswith("bundle:"):
        return await _scaffold_bundle(request, session, settings)

    # ------------------------------------------------------------------
    # Route: composite:* target — unchanged v1 behaviour
    # ------------------------------------------------------------------
    from skillmeat.core.services.template_service import render_in_memory

    try:
        rendered = render_in_memory(
            session=session,
            target_id=request.target_id,
            variables=request.variables,
        )
    except ValueError as exc:
        logger.warning(
            "IDP scaffold validation error for target_id=%s: %s",
            request.target_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={"error": "validation_error", "message": str(exc)},
        )
    except LookupError as exc:
        # render_in_memory raises LookupError / KeyError when the target is not found
        logger.warning(
            "IDP scaffold target not found: target_id=%s: %s",
            request.target_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Target artifact '{request.target_id}' not found",
        )
    except Exception as exc:
        logger.exception(
            "IDP scaffold unexpected error for target_id=%s: %s",
            request.target_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to render scaffold files",
        )

    files = [
        RenderedFile(
            path=rf.path,
            content_base64=b64encode(rf.content).decode("ascii"),
        )
        for rf in rendered
    ]

    logger.info(
        "IDP scaffold completed: target_id=%s files=%d",
        request.target_id,
        len(files),
    )

    return IDPScaffoldResponse(files=files)


async def _scaffold_bundle(
    request: IDPScaffoldRequest,
    session,
    settings,
) -> IDPScaffoldResponse:
    """Handle scaffold generation for ``bundle:*`` target IDs.

    Implements the full Bundle resolution pipeline:
    BundleResolver → PlatformFilter → (BomSidecarGenerator) → IDPScaffoldResponse.

    Args:
        request: Validated scaffold request with a ``bundle:*`` target_id.
        session: Active SQLAlchemy session for BundleResolver DB queries.
        settings: API settings instance for feature-flag checks.

    Returns:
        IDPScaffoldResponse with rendered files and optional BOM sidecar entry.

    Raises:
        HTTPException: 422 when the feature flag is disabled, the bundle is
                       missing, resolution fails, or all artifacts are filtered
                       out for the requested platform.
    """
    from skillmeat.core.services.bom_sidecar_generator import BomSidecarGenerator
    from skillmeat.core.services.bundle_resolver import (
        BundleResolver,
        CircularDependencyError,
        ResolutionDepthError,
        SameTierRecursionError,
    )
    from skillmeat.core.services.platform_filter import (
        EmptyArtifactSetError,
        PlatformFilter,
    )

    # Feature flag guard
    if not settings.idp_bundle_resolution_enabled:
        logger.warning(
            "IDP scaffold bundle resolution disabled: target_id=%s",
            request.target_id,
        )
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={
                "error": "feature_disabled",
                "message": "Bundle resolution is not enabled",
            },
        )

    # Extract bundle ID from "bundle:<slug-or-uuid>"
    bundle_id = request.target_id[len("bundle:") :]
    bundle_version: str | None = None  # version not in request; placeholder for BOM

    logger.info(
        "IDP scaffold bundle resolution: bundle_id=%s platform=%s",
        bundle_id,
        request.platform,
    )

    # ------------------------------------------------------------------
    # Step 1: Resolve bundle dependency graph
    # ------------------------------------------------------------------
    try:
        with trace_operation(
            "idp.scaffold.bundle_resolve",
            bundle_id=bundle_id,
            platform=request.platform,
        ) as span:
            resolver = BundleResolver()
            resolution = resolver.resolve(bundle_id, session)
            resolved_artifacts = resolution.artifacts
            span.set_attribute("resolved_count", len(resolved_artifacts))
    except ValueError as exc:
        logger.warning(
            "IDP scaffold bundle not found: bundle_id=%s: %s",
            bundle_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Bundle '{bundle_id}' not found",
        )
    except CircularDependencyError as exc:
        logger.warning(
            "IDP scaffold circular dependency: bundle_id=%s path=%s",
            bundle_id,
            exc.node_path,
        )
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={"error": "circular_dependency", "message": str(exc)},
        )
    except ResolutionDepthError as exc:
        logger.warning(
            "IDP scaffold resolution depth exceeded: bundle_id=%s depth=%d max=%d",
            bundle_id,
            exc.current_depth,
            exc.max_depth,
        )
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={"error": "resolution_depth_exceeded", "message": str(exc)},
        )
    except SameTierRecursionError as exc:
        logger.warning(
            "IDP scaffold same-tier recursion: bundle_id=%s parent=%s child=%s tier=%d",
            bundle_id,
            exc.parent_id,
            exc.child_id,
            exc.tier,
        )
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={"error": "same_tier_recursion", "message": str(exc)},
        )

    # ------------------------------------------------------------------
    # Step 2: Apply platform filter
    # ------------------------------------------------------------------
    try:
        with trace_operation(
            "idp.scaffold.platform_filter",
            bundle_id=bundle_id,
            platform=request.platform,
            input_count=len(resolved_artifacts),
        ) as span:
            filtered_artifacts = PlatformFilter.filter(
                resolved_artifacts, request.platform
            )
            span.set_attribute("filtered_count", len(filtered_artifacts))
    except EmptyArtifactSetError as exc:
        logger.warning(
            "IDP scaffold empty artifact set after filtering: bundle_id=%s platform=%s",
            bundle_id,
            request.platform,
        )
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={"error": "empty_artifact_set", "message": str(exc)},
        )

    # ------------------------------------------------------------------
    # Step 3: Build file map from resolved artifacts
    # Validate paths for path traversal (NFR-07)
    # ------------------------------------------------------------------
    files: List[RenderedFile] = []
    for artifact in filtered_artifacts:
        for rel_path, content in artifact.file_content_map.items():
            # NFR-07: reject paths containing parent-directory traversal
            if ".." in rel_path.split("/") or ".." in rel_path.split("\\"):
                logger.warning(
                    "IDP scaffold path traversal rejected: bundle_id=%s path=%r",
                    bundle_id,
                    rel_path,
                )
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail={
                        "error": "path_traversal",
                        "message": f"Artifact file path contains '..' segment: {rel_path!r}",
                    },
                )
            files.append(
                RenderedFile(
                    path=rel_path,
                    content_base64=b64encode(content.encode("utf-8")).decode("ascii"),
                )
            )

    # ------------------------------------------------------------------
    # Step 4: Optionally generate BOM sidecar
    # ------------------------------------------------------------------
    bom_file: RenderedFile | None = None
    if request.include_bom:
        try:
            with trace_operation(
                "idp.scaffold.bom_generate",
                bundle_id=bundle_id,
                artifact_count=len(filtered_artifacts),
            ) as span:
                bom = BomSidecarGenerator.generate(
                    filtered_artifacts,
                    bundle_id=bundle_id,
                    bundle_version=bundle_version,
                )
                bom_json = bom.model_dump_json(indent=2)
                bom_file = RenderedFile(
                    path=".skillmeat/bom.json",
                    content_base64=b64encode(bom_json.encode("utf-8")).decode("ascii"),
                )
                span.set_attribute("bom_artifact_count", len(bom.artifacts))
        except Exception as exc:
            # BOM generation is best-effort; log but do not fail the scaffold
            logger.warning(
                "IDP scaffold BOM generation failed (non-fatal): bundle_id=%s: %s",
                bundle_id,
                exc,
            )

    if bom_file is not None:
        files.append(bom_file)

    logger.info(
        "IDP scaffold bundle completed: bundle_id=%s platform=%s files=%d include_bom=%s",
        bundle_id,
        request.platform,
        len(files),
        request.include_bom,
    )

    return IDPScaffoldResponse(files=files)


def _ensure_idp_project(session, repo_url: str, target_id: str) -> str:
    """Look up or create a minimal Project record for an IDP-registered repository.

    IDP repos have no local filesystem path, so ``repo_url`` is used as the
    stable ``path`` key (enforced by the ``projects.path`` UNIQUE constraint).
    The project ``id`` is built from the URL so it is human-readable and
    deterministic — it does not change between repeated registrations.

    The ``id`` is derived as ``"idp:<path-component>"`` where
    ``<path-component>`` is the ``owner/repo`` portion of a GitHub HTTPS URL
    (e.g. ``"https://github.com/org/customer-api"`` → ``"idp:org/customer-api"``).
    For non-GitHub or non-standard URLs the full URL is used as the suffix,
    stripped of the ``https://`` prefix.

    Args:
        session: Active SQLAlchemy session.
        repo_url: HTTPS URL of the IDP-registered repository.
        target_id: Artifact target identifier (e.g. ``"composite:my-skill"``).
            Used as the project description when creating a new record.

    Returns:
        The ``id`` string of the existing or newly created ``Project`` row.
    """
    from skillmeat.cache.models import Project

    # Derive a stable, human-readable project ID from the repo URL.
    # Strip scheme; for github.com URLs keep only "owner/repo".
    url_suffix = repo_url.removeprefix("https://").removeprefix("http://")
    # Drop any trailing ".git" suffix and trim slashes.
    url_suffix = url_suffix.rstrip("/")
    if url_suffix.endswith(".git"):
        url_suffix = url_suffix[:-4]
    # For github.com/owner/repo keep only the path portion after the host.
    parts = url_suffix.split("/", 1)
    if len(parts) == 2:
        url_suffix = parts[1]  # "owner/repo" (drops host)
    project_id = f"idp:{url_suffix}"

    existing = session.query(Project).filter(Project.path == repo_url).first()
    if existing is not None:
        logger.debug(
            "_ensure_idp_project: found existing project id=%s for repo_url=%s",
            existing.id,
            repo_url,
        )
        return existing.id

    # Create a minimal project record.  ``name`` is the last path segment of
    # the URL (i.e. the repo name); ``path`` is the full repo URL.
    repo_name = url_suffix.rsplit("/", 1)[-1] if "/" in url_suffix else url_suffix
    new_project = Project(
        id=project_id,
        name=repo_name,
        path=repo_url,
        description=f"IDP-registered repository for {target_id}",
        status="active",
        owner_id="idp",
    )
    session.add(new_project)
    session.commit()
    logger.debug(
        "_ensure_idp_project: created project id=%s for repo_url=%s",
        project_id,
        repo_url,
    )
    return project_id


@router.post(
    "/register-deployment",
    response_model=IDPRegisterDeploymentResponse,
    status_code=status.HTTP_200_OK,
    summary="Register or update an IDP deployment",
    description=(
        "Records that a repository has deployed a given artifact target.  "
        "The operation is idempotent: re-submitting the same repo_url + target_id "
        "pair updates the existing DeploymentSet record instead of creating a duplicate."
    ),
    responses={
        200: {"description": "Deployment registered or updated"},
        422: {"description": "Invalid request payload"},
        500: {"description": "Internal error persisting the deployment record"},
    },
)
async def register_deployment(
    request: IDPRegisterDeploymentRequest,
    deployment_repo: DeploymentRepoDep,
    session: DbSessionDep,
    _auth: APIKeyDep,
    _service_token: IDPServiceTokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
    x_backstage_user_entity: Annotated[
        str | None, Header(alias="X-Backstage-User-Entity")
    ] = None,
) -> IDPRegisterDeploymentResponse:
    """Register or idempotently update an IDP deployment set record.

    Looks up an existing ``DeploymentSet`` by ``(remote_url, name)`` — where
    *name* is derived from ``target_id`` — to enforce the idempotency constraint.
    If a match is found the record is updated; otherwise a new record is created.

    The request ``metadata`` dict is serialised as JSON and stored in the
    ``description`` field of the ``DeploymentSet`` (no dedicated metadata column
    exists on the model at this schema version).

    When the ``X-Backstage-User-Entity`` header is present its value (truncated
    to 255 characters) is persisted as ``requested_by`` on the
    ``DeploymentSet`` record.  A missing header is silently ignored.

    A ``Project`` record is looked up or created using ``repo_url`` as the
    stable path key.  Its ``id`` is returned as ``project_id`` so callers can
    write the ``skillmeat.io/project-id`` annotation and the BOM card endpoint
    can resolve the correct project snapshot.

    Args:
        request: Register-deployment request containing repo_url, target_id,
                 and optional metadata
        deployment_repo: Deployment repository (injected via DI)
        session: Database session (injected via DI; used for project lookup/create)
        _auth: API key authentication (enforced when auth is enabled)
        x_backstage_user_entity: Optional Backstage user entity reference
            (e.g. ``"user:default/alice"``).  Stored as ``requested_by``.

    Returns:
        IDPRegisterDeploymentResponse with deployment_set_id, created flag,
        and project_id

    Raises:
        HTTPException: 500 if the database operation fails
    """
    logger.info(
        "IDP register-deployment: repo_url=%s target_id=%s",
        request.repo_url,
        request.target_id,
    )

    # Serialise the caller-supplied metadata for storage.
    metadata_json: str | None = (
        json.dumps(request.metadata) if request.metadata else None
    )

    # Extract and sanitise the optional user identity header.
    requested_by: str | None = (
        x_backstage_user_entity[:255] if x_backstage_user_entity else None
    )

    try:
        deployment_set_id, created = deployment_repo.upsert_idp_deployment_set(
            remote_url=request.repo_url,
            name=request.target_id,
            provisioned_by="idp",
            description=metadata_json,
            bundle_id=request.bundle_id,
            bundle_version=request.bundle_version,
            platform=request.platform,
            requested_by=requested_by,
        )
    except Exception as exc:
        logger.exception(
            "IDP register-deployment failed for repo_url=%s target_id=%s: %s",
            request.repo_url,
            request.target_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to register deployment",
        )

    logger.info(
        "IDP register-deployment: %s set id=%s",
        "created new" if created else "updated existing",
        deployment_set_id,
    )

    # ------------------------------------------------------------------
    # Look up or create a Project record keyed by repo_url.
    #
    # IDP-registered repos have no filesystem path, so we use repo_url as
    # the unique ``path`` value.  The project ``id`` is a stable, human-
    # readable string derived from the URL so it is safe to use as the
    # ``skillmeat.io/project-id`` annotation value.
    # ------------------------------------------------------------------
    project_id: str | None = None
    try:
        project_id = _ensure_idp_project(session, request.repo_url, request.target_id)
    except Exception as exc:
        # Non-fatal: log and return None rather than failing the whole request.
        # The deployment set was successfully registered; project lookup is
        # best-effort enrichment.
        logger.warning(
            "IDP register-deployment: project lookup/create failed for "
            "repo_url=%s — project_id will be null: %s",
            request.repo_url,
            exc,
        )

    return IDPRegisterDeploymentResponse(
        deployment_set_id=deployment_set_id,
        created=created,
        project_id=project_id,
    )


@router.get(
    "/context-card/{deployment_set_id}",
    response_model=IDPContextCardResponse,
    status_code=status.HTTP_200_OK,
    summary="Get context card summary for a Backstage IDP deployment entity page",
    description=(
        "Returns a compact, structured summary of a DeploymentSet record for "
        "rendering in the SkillMeat Backstage plugin ContextCard component.  "
        "Includes the bundle name (with v1 fallback), version, platform, "
        "registration timestamp, and the latest drift-check outcome.  "
        "Does NOT trigger a new drift check — call the drift-check endpoint "
        "separately when a fresh check is required."
    ),
    responses={
        200: {"description": "Context card payload returned successfully"},
        404: {"description": "No DeploymentSet found for the given deployment_set_id"},
        500: {
            "description": "Internal error querying the deployment set or drift results"
        },
    },
)
async def get_context_card(
    deployment_set_id: str = Path(
        ...,
        description="UUID hex identifier of the DeploymentSet to retrieve the context card for",
    ),
    session: DbSessionDep = None,
    _auth: APIKeyDep = None,
    _service_token: IDPServiceTokenDep = None,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:read"])),
) -> IDPContextCardResponse:
    """Return a Backstage-renderable context card for the given deployment set.

    Fetches the ``DeploymentSet`` row by ``deployment_set_id``.  When
    ``bundle_id`` is set, resolves the display name from the linked
    ``BundleEntity``; otherwise falls back to ``DeploymentSet.name``.

    Queries the latest non-stale ``DriftCheckResult`` row for the
    deployment set (ordered by ``checked_at DESC``) to populate
    ``drift_summary``.  When no drift check has been run, all
    ``drift_summary`` fields are ``None``.

    Args:
        deployment_set_id: Path parameter — UUID hex of the target
            ``DeploymentSet``.
        session: Database session injected via DI.
        _auth: API key authentication (enforced when auth is enabled).
        _service_token: IDP service-token guard (permissive when env var
            is not set).
        auth_context: Caller auth context (requires ``artifact:read`` scope).

    Returns:
        IDPContextCardResponse with the compact deployment set summary.

    Raises:
        HTTPException: 404 if no ``DeploymentSet`` exists for the given ID,
                       500 for unexpected database errors.
    """
    from skillmeat.cache.models import BundleEntity, DeploymentSet, DriftCheckResult

    logger.info("IDP context-card requested: deployment_set_id=%s", deployment_set_id)

    # ------------------------------------------------------------------
    # 1. Fetch the DeploymentSet
    # ------------------------------------------------------------------
    try:
        deployment_set = (
            session.query(DeploymentSet)
            .filter(DeploymentSet.id == deployment_set_id)
            .first()
        )
    except Exception as exc:
        logger.exception(
            "IDP context-card DB query failed for deployment_set_id=%s: %s",
            deployment_set_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to query deployment set",
        )

    if deployment_set is None:
        logger.info(
            "IDP context-card: no deployment set found for id=%s", deployment_set_id
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"DeploymentSet '{deployment_set_id}' not found",
        )

    # ------------------------------------------------------------------
    # 2. Resolve bundle_name: linked BundleEntity.name or name fallback
    # ------------------------------------------------------------------
    bundle_name: str = deployment_set.name
    if deployment_set.bundle_id:
        try:
            bundle_entity = (
                session.query(BundleEntity)
                .filter(BundleEntity.id == deployment_set.bundle_id)
                .first()
            )
            if bundle_entity is not None:
                bundle_name = bundle_entity.name
            else:
                logger.warning(
                    "IDP context-card: bundle_id=%s not found in bundles table, "
                    "falling back to deployment_set.name for id=%s",
                    deployment_set.bundle_id,
                    deployment_set_id,
                )
        except Exception as exc:
            # Non-fatal: log and fall back to deployment_set.name
            logger.warning(
                "IDP context-card: bundle lookup failed for bundle_id=%s "
                "deployment_set_id=%s: %s — using name fallback",
                deployment_set.bundle_id,
                deployment_set_id,
                exc,
            )

    # ------------------------------------------------------------------
    # 3. Fetch the latest drift check result (most recent non-stale row)
    # ------------------------------------------------------------------
    drift_summary = DriftSummary()
    try:
        latest_drift = (
            session.query(DriftCheckResult)
            .filter(
                DriftCheckResult.deployment_set_id == deployment_set_id,
                DriftCheckResult.is_stale.is_(False),
            )
            .order_by(DriftCheckResult.checked_at.desc())
            .first()
        )
        if latest_drift is not None:
            drift_summary = DriftSummary(
                version_drift=latest_drift.version_drift,
                content_drift=latest_drift.content_drift,
                policy_drift=latest_drift.policy_drift,
                last_checked_at=(
                    latest_drift.checked_at.isoformat()
                    if latest_drift.checked_at
                    else None
                ),
            )
    except Exception as exc:
        # Non-fatal: log and return null drift summary rather than 500
        logger.warning(
            "IDP context-card: drift check query failed for deployment_set_id=%s: %s"
            " — returning null drift summary",
            deployment_set_id,
            exc,
        )

    # ------------------------------------------------------------------
    # 4. Compose and return the context card payload
    # ------------------------------------------------------------------
    registered_at: str | None = (
        deployment_set.created_at.isoformat() if deployment_set.created_at else None
    )

    logger.info(
        "IDP context-card: deployment_set_id=%s bundle_name=%s platform=%s "
        "drift_checked=%s",
        deployment_set_id,
        bundle_name,
        deployment_set.platform,
        drift_summary.last_checked_at is not None,
    )

    return IDPContextCardResponse(
        deployment_set_id=deployment_set_id,
        bundle_name=bundle_name,
        bundle_version=deployment_set.bundle_version,
        platform=deployment_set.platform,
        registered_at=registered_at,
        drift_summary=drift_summary,
    )


@router.get(
    "/bom-card/{project_id}",
    response_model=BomCardResponse,
    status_code=status.HTTP_200_OK,
    summary="Get latest BOM snapshot summary for Backstage/IDP consumption",
    description=(
        "Returns a lightweight Bill-of-Materials summary for the given project, "
        "sourced from the most recent BomSnapshot row.  The payload is intentionally "
        "compact (no full BOM JSON) for efficient Backstage backend/scaffolder "
        "consumption.  Artifact entries include name, type, version, and content_hash "
        "only.  Attestation count reflects all AttestationRecord rows linked to "
        "artifacts present in the snapshot."
    ),
    responses={
        200: {"description": "BOM card payload returned successfully"},
        404: {"description": "No BOM snapshot found for the given project_id"},
        500: {"description": "Internal error querying the BOM snapshot"},
    },
)
async def get_bom_card(
    project_id: str = Path(
        ...,
        description="Project identifier to fetch the latest BOM snapshot for",
    ),
    session: DbSessionDep = None,
    _auth: APIKeyDep = None,
    _service_token: IDPServiceTokenDep = None,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:read"])),
) -> BomCardResponse:
    """Return a Backstage-renderable BOM summary for the latest snapshot.

    Queries ``bom_snapshots`` for the most recent row matching ``project_id``
    (ordered by ``created_at DESC``).  Parses the stored ``bom_json`` and
    extracts a compact artifact list plus a count of linked attestation records.

    The ``attestation_count`` is computed by summing ``AttestationRecord`` rows
    whose ``artifact_id`` appears in the snapshot's artifact list.

    Args:
        project_id: Path parameter identifying the project.
        session: Database session injected via DI.
        _auth: API key authentication (enforced when auth is enabled).
        auth_context: Caller auth context (requires ``artifact:read`` scope).

    Returns:
        BomCardResponse containing the lightweight BOM summary.

    Raises:
        HTTPException: 404 if no snapshot exists for the project,
                       500 for unexpected database or parsing errors.
    """
    from skillmeat.cache.models import (
        ArtifactHistoryEvent,
        AttestationRecord,
        BomSnapshot,
    )

    logger.info("IDP bom-card requested: project_id=%s", project_id)

    # ------------------------------------------------------------------
    # 1. Fetch the latest BOM snapshot for the project
    # ------------------------------------------------------------------
    try:
        snapshot = (
            session.query(BomSnapshot)
            .filter(BomSnapshot.project_id == project_id)
            .order_by(BomSnapshot.created_at.desc())
            .first()
        )
    except Exception as exc:
        logger.exception(
            "IDP bom-card DB query failed for project_id=%s: %s",
            project_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to query BOM snapshot",
        )

    if snapshot is None:
        logger.info("IDP bom-card: no snapshot found for project_id=%s", project_id)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No BOM snapshot found for project '{project_id}'",
        )

    # ------------------------------------------------------------------
    # 2. Parse the stored BOM JSON and build a compact artifact list
    # ------------------------------------------------------------------
    try:
        bom_data: dict = json.loads(snapshot.bom_json)
    except (json.JSONDecodeError, TypeError) as exc:
        logger.exception(
            "IDP bom-card: invalid bom_json for snapshot id=%s project_id=%s: %s",
            snapshot.id,
            project_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="BOM snapshot contains invalid JSON",
        )

    raw_artifacts: List[dict] = bom_data.get("artifacts", [])
    card_artifacts: List[BomCardArtifactEntry] = [
        BomCardArtifactEntry(
            name=a.get("name", ""),
            type=a.get("type", ""),
            version=a.get("version"),
            content_hash=a.get("content_hash", ""),
        )
        for a in raw_artifacts
        if isinstance(a, dict)
    ]

    # Collect artifact IDs present in the snapshot for downstream queries
    artifact_ids: List[str] = [
        f"{a.get('type', '')}:{a.get('name', '')}"
        for a in raw_artifacts
        if isinstance(a, dict) and a.get("name") and a.get("type")
    ]

    # ------------------------------------------------------------------
    # 3. Fetch recent activity events for snapshot artifacts (last 20)
    # ------------------------------------------------------------------
    _RECENT_EVENTS_LIMIT = 20
    recent_events: List[BomCardRecentEvent] = []
    if artifact_ids:
        try:
            raw_events = (
                session.query(ArtifactHistoryEvent)
                .filter(ArtifactHistoryEvent.artifact_id.in_(artifact_ids))
                .order_by(ArtifactHistoryEvent.timestamp.desc())
                .limit(_RECENT_EVENTS_LIMIT)
                .all()
            )
            recent_events = [
                BomCardRecentEvent(
                    id=ev.id,
                    artifact_id=ev.artifact_id,
                    event_type=ev.event_type,
                    actor_id=ev.actor_id,
                    timestamp=ev.timestamp.isoformat() if ev.timestamp else None,
                )
                for ev in raw_events
            ]
        except Exception as exc:
            # Non-fatal: log and continue without events
            logger.warning(
                "IDP bom-card: recent events query failed for project_id=%s: %s",
                project_id,
                exc,
            )

    # ------------------------------------------------------------------
    # 4. Compute attestation summary (total + scope breakdown + latest)
    # ------------------------------------------------------------------
    attestation_count: int = 0
    attestation_summary = BomCardAttestationSummary(total=0)

    if artifact_ids:
        try:
            attestation_rows = (
                session.query(AttestationRecord)
                .filter(AttestationRecord.artifact_id.in_(artifact_ids))
                .all()
            )
            attestation_count = len(attestation_rows)

            # Build scope-count map and find latest attestation timestamp
            scope_counts: dict = {}
            latest_at: str | None = None
            for rec in attestation_rows:
                for scope in rec.scopes or []:
                    scope_counts[scope] = scope_counts.get(scope, 0) + 1
                if rec.created_at:
                    rec_ts = rec.created_at.isoformat()
                    if latest_at is None or rec_ts > latest_at:
                        latest_at = rec_ts

            attestation_summary = BomCardAttestationSummary(
                total=attestation_count,
                scope_counts=scope_counts,
                latest_at=latest_at,
            )
        except Exception as exc:
            logger.exception(
                "IDP bom-card: attestation summary query failed for project_id=%s: %s",
                project_id,
                exc,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to compute attestation summary",
            )

    # ------------------------------------------------------------------
    # 5. Compose and return the BOM card payload
    # ------------------------------------------------------------------
    signature_status = "signed" if snapshot.signature else "unsigned"
    generated_at = snapshot.created_at.isoformat() if snapshot.created_at else ""

    logger.info(
        "IDP bom-card: project_id=%s snapshot_id=%s artifacts=%d "
        "events=%d attestations=%d signature=%s",
        project_id,
        snapshot.id,
        len(card_artifacts),
        len(recent_events),
        attestation_count,
        signature_status,
    )

    return BomCardResponse(
        project_id=project_id,
        snapshot_id=snapshot.id,
        generated_at=generated_at,
        artifact_count=len(card_artifacts),
        artifacts=card_artifacts,
        signature_status=signature_status,
        attestation_count=attestation_count,
        recent_events=recent_events,
        attestation_summary=attestation_summary,
    )


@router.get(
    "/drift/{deployment_set_id}",
    response_model=IDPDriftResponse,
    status_code=status.HTTP_200_OK,
    summary="Get drift status for an IDP deployment set",
    description=(
        "Runs or returns cached drift detection results for the given DeploymentSet.  "
        "Checks three independent dimensions: version drift (deployed vs latest bundle "
        "version), content drift (SHA-256 hash comparison of .claude/ files), and "
        "policy drift (bundle updated_at vs deployment registration timestamp).  "
        "Results are cached for 24 hours; the ``is_stale`` flag indicates whether the "
        "returned data came from a result older than the cache TTL.  "
        "Requires the ``idp_drift_detection_enabled`` feature flag to be enabled."
    ),
    responses={
        200: {"description": "Drift check result returned successfully"},
        404: {"description": "No DeploymentSet found for the given deployment_set_id"},
        501: {"description": "Drift detection feature is not enabled"},
        500: {"description": "Internal error running drift check"},
    },
)
async def get_drift(
    deployment_set_id: str = Path(
        ...,
        description="UUID hex identifier of the DeploymentSet to check drift for",
    ),
    session: DbSessionDep = None,
    settings: SettingsDep = None,
    _auth: APIKeyDep = None,
    _service_token: IDPServiceTokenDep = None,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:read"])),
) -> IDPDriftResponse:
    """Return drift detection results for the given deployment set.

    Checks the ``idp_drift_detection_enabled`` feature flag first; returns
    HTTP 501 when the flag is disabled.  Fetches the ``DeploymentSet`` row
    by ``deployment_set_id``; returns HTTP 404 when not found.

    Delegates to :meth:`~skillmeat.core.services.drift_checker.DriftChecker.run_and_cache`
    which enforces a 24-hour result TTL and persists new ``DriftCheckResult``
    rows when the cache is cold or expired.

    Args:
        deployment_set_id: Path parameter — UUID hex of the target
            ``DeploymentSet``.
        session: Database session injected via DI.
        settings: API settings injected via DI (used for feature flag check).
        _auth: API key authentication (enforced when auth is enabled).
        _service_token: IDP service-token guard (permissive when env var
            is not set).
        auth_context: Caller auth context (requires ``artifact:read`` scope).

    Returns:
        IDPDriftResponse with drift classification results and metadata.

    Raises:
        HTTPException: 501 when ``idp_drift_detection_enabled`` is false,
                       404 when no DeploymentSet matches the given ID,
                       500 for unexpected errors during drift detection.
    """
    from skillmeat.cache.models import DeploymentSet
    from skillmeat.core.github_client import get_github_client
    from skillmeat.core.services.drift_checker import DriftChecker

    logger.info("IDP drift check requested: deployment_set_id=%s", deployment_set_id)

    # ------------------------------------------------------------------
    # 1. Feature flag guard
    # ------------------------------------------------------------------
    if not settings.idp_drift_detection_enabled:
        logger.info(
            "IDP drift check: feature flag disabled for deployment_set_id=%s",
            deployment_set_id,
        )
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="Drift detection not enabled",
        )

    # ------------------------------------------------------------------
    # 2. Verify the DeploymentSet exists
    # ------------------------------------------------------------------
    try:
        deployment_set = (
            session.query(DeploymentSet)
            .filter(DeploymentSet.id == deployment_set_id)
            .first()
        )
    except Exception as exc:
        logger.exception(
            "IDP drift check DB query failed for deployment_set_id=%s: %s",
            deployment_set_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to query deployment set",
        )

    if deployment_set is None:
        logger.info(
            "IDP drift check: no deployment set found for id=%s", deployment_set_id
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"DeploymentSet '{deployment_set_id}' not found",
        )

    # ------------------------------------------------------------------
    # 3. Run drift detection via DriftChecker.run_and_cache
    # ------------------------------------------------------------------
    try:
        github_client = get_github_client()
        checker = DriftChecker()
        result = checker.run_and_cache(
            deployment_set_id=deployment_set_id,
            session=session,
            github_client=github_client,
        )
        session.commit()
    except Exception as exc:
        logger.exception(
            "IDP drift check failed for deployment_set_id=%s: %s",
            deployment_set_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to run drift detection",
        )

    # ------------------------------------------------------------------
    # 4. Build DriftDetails from result details blob
    # ------------------------------------------------------------------
    raw_details = result.get("details")
    drift_details: DriftDetails | None = None
    if raw_details and isinstance(raw_details, dict):
        drift_details = DriftDetails(
            content_changed_files=raw_details.get("content_changed_files", []),
            version_deployed=raw_details.get("version_deployed"),
            version_latest=raw_details.get("version_latest"),
            policy_updated_at=raw_details.get("policy_updated_at"),
        )

    version_drift = result.get("version_drift")
    is_stale = result.get("is_stale", False)

    logger.info(
        "IDP drift check completed: deployment_set_id=%s version_drift=%s "
        "content_drift=%s policy_drift=%s is_stale=%s",
        deployment_set_id,
        version_drift,
        result.get("content_drift"),
        result.get("policy_drift"),
        is_stale,
    )

    return IDPDriftResponse(
        deployment_set_id=deployment_set_id,
        version_drift=version_drift,
        content_drift=result.get("content_drift"),
        policy_drift=result.get("policy_drift"),
        last_checked_at=result.get("checked_at"),
        is_stale=is_stale,
        details=drift_details,
    )


# =============================================================================
# Backstage Discovery Endpoints (FR-DISC-01, FR-DISC-04, FR-DISC-05)
# =============================================================================

# Slug helper mirrored from TemplateGenerator to avoid cross-module import of
# the private function (TemplateGenerator._slugify is not part of the public API).
_SLUG_RE = re.compile(r"[^a-zA-Z0-9\-]+")


def _slugify_name(name: str) -> str:
    """Convert an arbitrary bundle name into a Backstage-safe metadata.name slug.

    Args:
        name: Raw bundle name string (e.g. ``"My Bundle!"``)

    Returns:
        Lower-cased, hyphen-separated slug (e.g. ``"my-bundle"``)
    """
    slug = _SLUG_RE.sub("-", name).strip("-").lower()
    return slug or "bundle"


def _build_backstage_entity(orm_template: Any) -> Dict[str, Any]:
    """Construct a Backstage ``Template`` entity dict from a ``ScaffoldTemplate`` ORM row.

    The returned structure follows the ``scaffolder.backstage.io/v1beta3`` API
    version contract described in PRD Section 8.3.  All attribute access uses
    ``getattr`` with defaults so sparse records never cause ``AttributeError``.

    Args:
        orm_template: A ``ScaffoldTemplate`` ORM instance with its ``bundle``
            relationship loaded.

    Returns:
        A plain Python dict representing the Backstage Template entity.
    """
    bundle = getattr(orm_template, "bundle", None)

    # --- Bundle-derived values -----------------------------------------------
    bundle_id: str = getattr(orm_template, "bundle_id", "")
    bundle_name: str = getattr(bundle, "name", bundle_id) if bundle else bundle_id
    bundle_display_name: str = (
        getattr(bundle, "display_name", None) or bundle_name if bundle else bundle_name
    )
    bundle_description: str = getattr(bundle, "description", "") or "" if bundle else ""
    bundle_version: Optional[str] = getattr(bundle, "version", None) if bundle else None
    bundle_tags_raw = getattr(bundle, "tags", None) if bundle else None

    # Bundle tags may be stored as a JSON string (Text column) or a list.
    bundle_tags: List[str] = []
    if bundle_tags_raw:
        if isinstance(bundle_tags_raw, list):
            bundle_tags = [str(t) for t in bundle_tags_raw if t]
        elif isinstance(bundle_tags_raw, str):
            try:
                parsed = json.loads(bundle_tags_raw)
                if isinstance(parsed, list):
                    bundle_tags = [str(t) for t in parsed if t]
            except (json.JSONDecodeError, ValueError):
                pass

    # --- ScaffoldTemplate-derived values ------------------------------------
    backstage_owner: str = (
        getattr(orm_template, "backstage_owner", None) or "platform-team"
    )
    backstage_type: str = getattr(orm_template, "backstage_type", None) or "service"
    backstage_tags_raw = getattr(orm_template, "backstage_tags", None) or []
    backstage_tags: List[str] = [str(t) for t in backstage_tags_raw if t]
    required_variables: List[str] = list(
        getattr(orm_template, "required_variables", None) or []
    )
    variable_type_map: Dict[str, str] = dict(
        getattr(orm_template, "variable_type_map", None) or {}
    )
    skeleton_ref: Optional[str] = getattr(orm_template, "skeleton_ref", None) or None
    template_stale: bool = bool(getattr(orm_template, "template_stale", False))

    # Merge and deduplicate tags (bundle + backstage), sorted for determinism.
    merged_tags: List[str] = sorted(set(bundle_tags + backstage_tags))

    # --- Ensure repoUrl is always in the variable list -----------------------
    all_variables: List[str] = list(required_variables)
    if "repoUrl" not in all_variables and "repo_url" not in all_variables:
        all_variables.append("repoUrl")

    # --- Build parameter properties ------------------------------------------
    properties: Dict[str, Any] = {}
    for var in all_variables:
        prop: Dict[str, Any] = {
            "title": var.replace("_", " ").title(),
            "type": variable_type_map.get(var, "string"),
        }
        if var == "owner" or (
            var != "repoUrl" and re.search(r"owner", var, re.IGNORECASE)
        ):
            prop["ui:field"] = "OwnerPicker"
        elif var in ("repoUrl", "repo_url"):
            prop["ui:field"] = "RepoUrlPicker"
        properties[var] = prop

    # --- Build steps ---------------------------------------------------------
    steps: List[Dict[str, Any]] = []
    name_expr = (
        "${{ parameters.name }}"
        if "name" in all_variables
        else "${{ parameters.repoUrl }}"
    )
    if skeleton_ref:
        steps.append(
            {
                "id": "fetch-template",
                "name": "Fetch Skeleton",
                "action": "fetch:template",
                "input": {"url": skeleton_ref, "values": {"name": name_expr}},
            }
        )
    steps.append(
        {
            "id": "inject-context",
            "name": "Inject SkillMeat Context",
            "action": "skillmeat:context:inject",
            "input": {
                "bundleId": bundle_id,
                "variables": "${{ parameters }}",
            },
        }
    )
    steps.append(
        {
            "id": "publish",
            "name": "Publish to GitHub",
            "action": "publish:github",
            "input": {
                "allowedHosts": ["github.com"],
                "repoUrl": "${{ parameters.repoUrl }}",
                "description": bundle_description,
            },
        }
    )
    steps.append(
        {
            "id": "register",
            "name": "Register Deployment",
            "action": "skillmeat:deployment:register",
            "input": {
                "bundleId": bundle_id,
                "repoUrl": "${{ parameters.repoUrl }}",
            },
        }
    )

    # --- Build output links --------------------------------------------------
    output: Dict[str, Any] = {
        "links": [
            {
                "title": "Repository",
                "url": "${{ steps.publish.output.remoteUrl }}",
            }
        ]
    }

    # --- Assemble annotations ------------------------------------------------
    annotations: Dict[str, str] = {
        "skillmeat.io/bundle-id": bundle_id,
        "skillmeat.io/bundle-version": bundle_version or "unknown",
        "skillmeat.io/generated-at": datetime.now(timezone.utc).isoformat(),
    }
    if template_stale:
        annotations["skillmeat.io/template-stale"] = "true"

    # --- Assemble full entity ------------------------------------------------
    entity: Dict[str, Any] = {
        "apiVersion": "scaffolder.backstage.io/v1beta3",
        "kind": "Template",
        "metadata": {
            "name": f"skillmeat-bundle-{_slugify_name(bundle_name)}",
            "title": bundle_display_name,
            "description": f"Scaffold from SkillMeat Bundle {bundle_name}",
            "annotations": annotations,
        },
        "spec": {
            "owner": backstage_owner,
            "type": backstage_type,
            "parameters": [
                {
                    "title": "Configuration",
                    "required": all_variables,
                    "properties": properties,
                }
            ],
            "steps": steps,
            "output": output,
        },
    }

    if merged_tags:
        entity["metadata"]["tags"] = merged_tags

    return entity


@router.get(
    "/telemetry/global",
    response_model=IDPGlobalTelemetryResponse,
    status_code=status.HTTP_200_OK,
    summary="Get global telemetry feed across all projects",
    description=(
        "Returns a paginated, sorted feed of workflow telemetry entries across all "
        "projects.  Intended for the SAM Backstage global-telemetry panel.  "
        "Supports ``sort_by`` (``effectiveness_score``, ``avg_cost_usd``, "
        "``execution_count``, ``success_rate``), ``limit`` (max 100), and "
        "``offset`` for cursor-free pagination."
    ),
    responses={
        200: {"description": "Paginated global telemetry feed"},
        401: {"description": "Unauthenticated"},
        500: {"description": "Internal server error"},
    },
)
async def get_global_telemetry(
    session: DbSessionDep,
    _auth: APIKeyDep,
    _service_token: IDPServiceTokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["telemetry:read"])),
    sort_by: str = Query(
        "effectiveness_score",
        description=(
            "Column to sort by, descending.  Accepted values: "
            "``effectiveness_score`` (default), ``avg_cost_usd``, "
            "``execution_count``, ``success_rate``."
        ),
    ),
    limit: int = Query(
        50,
        ge=1,
        le=100,
        description="Maximum number of entries to return (1–100, default 50).",
    ),
    offset: int = Query(
        0,
        ge=0,
        description="Zero-based offset for pagination (default 0).",
    ),
) -> IDPGlobalTelemetryResponse:
    """Return a paginated global telemetry feed across all projects.

    Delegates to :class:`~skillmeat.core.services.idp_telemetry_service.IDPTelemetryService`
    which enforces a hard cap of 100 rows per page and falls back to
    ``effectiveness_score`` ordering for unknown ``sort_by`` values.

    Args:
        session: Database session (injected via DI).
        _auth: API key authentication (enforced when auth is enabled).
        _service_token: IDP service-token validation.
        auth_context: Caller auth context (requires ``telemetry:read`` scope).
        sort_by: Column to sort by, descending.
        limit: Maximum rows per page (1–100).
        offset: Zero-based row offset.

    Returns:
        :class:`IDPGlobalTelemetryResponse` with a page of entries and total count.

    Raises:
        HTTPException: 500 on unexpected database errors.
    """
    logger.info(
        "IDP global telemetry requested: sort_by=%s limit=%d offset=%d",
        sort_by,
        limit,
        offset,
    )
    try:
        svc = IDPTelemetryService(db=session)
        return svc.get_global_telemetry(sort_by=sort_by, limit=limit, offset=offset)
    except Exception as exc:
        logger.exception(
            "IDP global telemetry: unexpected error sort_by=%s limit=%d offset=%d: %s",
            sort_by,
            limit,
            offset,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve global telemetry",
        )


@router.get(
    "/telemetry/{project_id}",
    response_model=IDPProjectTelemetryResponse,
    status_code=status.HTTP_200_OK,
    summary="Get per-project telemetry for SAM Backstage",
    description=(
        "Returns workflow telemetry aggregates for a single project, sourced from "
        "pre-computed ``ProjectAgenticMetrics`` rollup rows.  Always returns 200: "
        "when no data exists the ``top_workflows`` list is empty and "
        "``period_signals`` is null — the endpoint never raises 404 for missing data."
    ),
    responses={
        200: {"description": "Per-project telemetry snapshot (may be empty)"},
        401: {"description": "Unauthenticated"},
        500: {"description": "Internal server error"},
    },
)
async def get_project_telemetry(
    project_id: str = Path(
        ...,
        description="Project identifier to fetch telemetry for",
    ),
    session: DbSessionDep = None,
    _auth: APIKeyDep = None,
    _service_token: IDPServiceTokenDep = None,
    auth_context: AuthContext = Depends(require_auth(scopes=["telemetry:read"])),
) -> IDPProjectTelemetryResponse:
    """Return per-project telemetry for SAM Backstage.

    Delegates to :class:`~skillmeat.core.services.idp_telemetry_service.IDPTelemetryService`.
    Returns an empty ``top_workflows`` list (not 404) when no rollup data exists.

    Args:
        project_id: Project identifier to query (path parameter).
        session: Database session (injected via DI).
        _auth: API key authentication (enforced when auth is enabled).
        _service_token: IDP service-token validation.
        auth_context: Caller auth context (requires ``telemetry:read`` scope).

    Returns:
        :class:`IDPProjectTelemetryResponse` with workflow summaries and period signals.

    Raises:
        HTTPException: 500 on unexpected database errors.
    """
    logger.info("IDP project telemetry requested: project_id=%s", project_id)
    try:
        svc = IDPTelemetryService(db=session)
        return svc.get_project_telemetry(project_id)
    except Exception as exc:
        logger.exception(
            "IDP project telemetry: unexpected error project_id=%s: %s",
            project_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve project telemetry",
        )


@router.get(
    "/templates",
    summary="List Backstage Template entities",
    description=(
        "Return a JSON array of Backstage ``scaffolder.backstage.io/v1beta3`` "
        "Template entities for all scaffold-enabled bundles.  Use the optional "
        "``platform`` query parameter to filter entities whose "
        "``backstage_tags`` include the requested platform string.  "
        "Returns ``[]`` (not 5xx) when no scaffold-enabled bundles exist."
    ),
    response_model=None,
    responses={
        200: {
            "description": "JSON array of Backstage Template entities (may be empty)"
        },
        401: {"description": "Unauthenticated"},
        500: {"description": "Internal server error"},
    },
)
async def list_backstage_templates(
    session: DbSessionDep,
    platform: Optional[str] = Query(
        None,
        description=(
            "Filter entities to those whose ``backstage_tags`` include this "
            "platform string (e.g. ``claude-code``, ``cursor``).  Omit to "
            "return all scaffold-enabled templates."
        ),
    ),
    _: None = Depends(require_local_edition),
    auth_context: AuthContext = Depends(require_auth()),
) -> List[Dict[str, Any]]:
    """Return a JSON array of Backstage Template entities (FR-DISC-01, FR-DISC-04).

    Queries all ``ScaffoldTemplate`` records with ``enabled=True``, optionally
    filtered by ``platform`` (matched against ``backstage_tags``).  The response
    is a raw JSON array — not wrapped in an envelope — for direct Backstage
    catalog discovery consumption.

    Args:
        session: Database session (injected).
        platform: Optional platform filter string.
        auth_context: Caller auth context (requires auth).

    Returns:
        List of Backstage Template entity dicts.

    Raises:
        HTTPException: 500 on unexpected database errors.
    """
    with trace_operation(
        "template_discover",
        platform=platform or "",
    ) as _disc_span:
        try:
            repo = ScaffoldTemplateRepository()
            orm_templates = repo.list(session, enabled_only=True)
        except Exception as exc:
            logger.exception(
                "Failed to list scaffold templates for Backstage discovery: %s", exc
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve scaffold templates",
            )

        entities: List[Dict[str, Any]] = []
        for orm_template in orm_templates:
            # Platform filter: when supplied, only include templates whose
            # backstage_tags contains the requested platform string.
            if platform is not None:
                tags: List[str] = list(
                    getattr(orm_template, "backstage_tags", None) or []
                )
                if platform not in tags:
                    continue

            try:
                entity = _get_or_build_entity(orm_template, _discovery_cache)
            except Exception as exc:
                logger.warning(
                    "Skipping scaffold template id=%s in discovery list: entity build failed: %s",
                    getattr(orm_template, "id", "?"),
                    exc,
                )
                continue

            entities.append(entity)

        _disc_span.set_attribute("bundle_count", len(entities))

        logger.info(
            "Backstage template discovery: platform=%s returned %d entities",
            platform,
            len(entities),
        )
        return entities


@router.get(
    "/templates/{bundle_id}",
    summary="Get Backstage Template entity by bundle ID",
    description=(
        "Return a single Backstage ``scaffolder.backstage.io/v1beta3`` Template "
        "entity for the scaffold-enabled bundle identified by ``bundle_id``.  "
        "Returns ``404`` when no scaffold template exists for the bundle or the "
        "template is disabled."
    ),
    response_model=None,
    responses={
        200: {"description": "Backstage Template entity"},
        401: {"description": "Unauthenticated"},
        404: {"description": "No scaffold template found for the given bundle_id"},
        500: {"description": "Internal server error"},
    },
)
async def get_backstage_template(
    bundle_id: str,
    session: DbSessionDep,
    _: None = Depends(require_local_edition),
    auth_context: AuthContext = Depends(require_auth()),
) -> Dict[str, Any]:
    """Return a single Backstage Template entity by bundle ID (FR-DISC-05).

    Looks up the ``ScaffoldTemplate`` record associated with ``bundle_id``.
    Returns ``404`` when no record exists or the template is disabled.

    Args:
        bundle_id: Bundle entity primary key.
        session: Database session (injected).
        auth_context: Caller auth context (requires auth).

    Returns:
        Backstage Template entity dict.

    Raises:
        HTTPException: 404 if the template does not exist or is disabled,
            500 on unexpected database errors.
    """
    try:
        repo = ScaffoldTemplateRepository()
        orm_template = repo.get_by_bundle_id(session, bundle_id)
    except Exception as exc:
        logger.exception(
            "Failed to retrieve scaffold template for bundle_id=%s: %s", bundle_id, exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve scaffold template",
        )

    if orm_template is None or not getattr(orm_template, "enabled", False):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No scaffold template found for bundle_id='{bundle_id}'",
        )

    try:
        entity = _get_or_build_entity(orm_template, _discovery_cache)
    except Exception as exc:
        logger.exception(
            "Failed to build Backstage entity for bundle_id=%s: %s", bundle_id, exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to build Backstage Template entity",
        )

    logger.info("Backstage template entity retrieved for bundle_id=%s", bundle_id)
    return entity


@router.post(
    "/templates/cache/invalidate",
    summary="Invalidate Backstage discovery cache",
    description=(
        "Evict entries from the in-process Backstage discovery cache.  "
        "Pass ``bundle_id`` to evict only that bundle's cached entities; "
        "omit it to flush the entire cache.  "
        "This endpoint is intended for internal service-to-service use "
        "(e.g. called by the bundle update handler when a bundle version "
        "changes) and is protected by the service token."
    ),
    response_model=None,
    responses={
        200: {"description": "Cache invalidated — returns count of entries removed"},
        401: {"description": "Missing or invalid service token"},
    },
)
async def invalidate_discovery_cache(
    bundle_id: Optional[str] = Query(
        None,
        description=(
            "Bundle ID whose cache entries should be evicted.  "
            "Omit to flush the entire cache."
        ),
    ),
    _token: None = Depends(verify_idp_service_token),
    auth_context: AuthContext = Depends(require_auth()),
) -> Dict[str, Any]:
    """Invalidate the in-process Backstage discovery cache (FR-DISC-INV).

    Intended to be called by bundle update handlers so that the next discovery
    request re-builds entity dicts from the latest data rather than serving a
    stale cached version.

    Args:
        bundle_id: Optional bundle to evict.  When ``None`` the entire cache
            is flushed.
        _token: Service-token dependency (validates ``X-SkillMeat-Service-Token``).
        auth_context: Caller auth context.

    Returns:
        JSON object ``{"evicted": <int>}``.
    """
    evicted = clear_discovery_cache(bundle_id)
    logger.info(
        "Discovery cache invalidation requested: bundle_id=%s evicted=%d",
        bundle_id,
        evicted,
    )
    return {"evicted": evicted}
