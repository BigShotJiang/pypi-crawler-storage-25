"""Tier API endpoints for DVCS Phase 3 (DVCS-3.4).

Provides REST endpoints for 4-tier inheritance queries, FQAN resolution,
upstream cascade status and propagation, cross-tier diff, and namespace
listing.
"""

import logging
from typing import Annotated, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session

from skillmeat.api.dependencies import (
    DbSessionDep,
    SettingsDep,
    require_auth,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.cache.models import TierNamespace
from skillmeat.core.cross_tier_diff import CrossTierDiffService
from skillmeat.core.enums import CollectionTier
from skillmeat.core.fqan_resolver import AmbiguousFQANError, FQANResolver
from skillmeat.core.upstream_cascade import UpstreamCascadeService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/tiers", tags=["tiers"])

# ---------------------------------------------------------------------------
# Valid tier values (derived from the CollectionTier enum)
# ---------------------------------------------------------------------------

_VALID_TIERS = {t.value for t in CollectionTier}


def _validate_tier_param(tier: str) -> str:
    """Validate *tier* against CollectionTier enum and return the normalised value.

    Args:
        tier: Raw tier string from the query parameter.  ``"local"`` is
              accepted as an alias for ``"project"``.

    Returns:
        Normalised tier string.

    Raises:
        :exc:`fastapi.HTTPException` (400) when *tier* is not recognised.
    """
    normalised = "project" if tier == "local" else tier
    if normalised not in _VALID_TIERS:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Invalid tier {tier!r}. "
                f"Must be one of: {sorted(_VALID_TIERS)} (or 'local' as alias for 'project')."
            ),
        )
    return normalised


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class TierArtifactResponse(BaseModel):
    """Artifact entry enriched with tier metadata."""

    id: str
    name: str
    type: str
    collection_tier: Optional[str] = None
    namespace: Optional[str] = None
    fqan: Optional[str] = None
    deployed_version: Optional[str] = None
    is_outdated: bool = False


class ResolveResponse(BaseModel):
    """Result of an FQAN or bare-name resolution."""

    artifact: Optional[TierArtifactResponse] = None
    candidates: List[TierArtifactResponse] = []
    tier_walk: List[str] = []
    ambiguity_warning: Optional[str] = None


class CascadeStatusResponse(BaseModel):
    """Upstream/downstream cascade picture for a single artifact."""

    artifact_id: str
    has_upstream: bool
    is_outdated: bool
    upstream_tier: Optional[str] = None
    upstream_version: Optional[str] = None
    downstream_count: int


class CascadeResultResponse(BaseModel):
    """Result of a cascade propagation operation."""

    source_artifact_id: str
    affected_count: int
    affected_ids: List[str] = []
    tier_breakdown: Dict[str, int] = {}


class CrossTierDiffResponse(BaseModel):
    """Unified diff between two artifacts at (potentially) different tiers."""

    source_id: str
    source_tier: Optional[str] = None
    target_id: str
    target_tier: Optional[str] = None
    unified_diff: str
    has_changes: bool
    content_hash_match: bool


class TierNamespaceResponse(BaseModel):
    """A registered tier namespace."""

    id: int
    tier: str
    namespace: str
    display_name: Optional[str] = None
    description: Optional[str] = None


# ---------------------------------------------------------------------------
# Helper: ORM Artifact → TierArtifactResponse
# ---------------------------------------------------------------------------


def _artifact_to_response(artifact) -> TierArtifactResponse:
    """Convert an ORM :class:`~skillmeat.cache.models.Artifact` to the response schema.

    Args:
        artifact: A SQLAlchemy ``Artifact`` ORM instance.

    Returns:
        :class:`TierArtifactResponse` ready for serialization.
    """
    return TierArtifactResponse(
        id=artifact.id,
        name=artifact.name,
        type=artifact.type,
        collection_tier=artifact.collection_tier,
        namespace=artifact.namespace,
        fqan=artifact.fqan,
        deployed_version=artifact.deployed_version,
        is_outdated=bool(artifact.is_outdated),
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/artifacts",
    response_model=List[TierArtifactResponse],
    summary="List artifacts at a given collection tier",
)
async def list_artifacts_by_tier(
    tier: str = Query(
        ..., description="Collection tier: enterprise, team, dev, project, marketplace"
    ),
    namespace: Optional[str] = Query(None, description="Filter by namespace slug"),
    type: Optional[str] = Query(None, description="Filter by artifact type"),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    session: DbSessionDep = None,
    _auth: AuthContext = Depends(require_auth),
) -> List[TierArtifactResponse]:
    """List artifacts at a given tier, optionally filtered by namespace and type.

    Args:
        tier: Collection tier to query.
        namespace: Optional namespace slug filter.
        type: Optional artifact type filter.
        limit: Maximum number of results to return (1-100).
        offset: Number of results to skip (for pagination).

    Returns:
        List of :class:`TierArtifactResponse` entries.

    Raises:
        HTTPException (400): When *tier* is not a valid ``CollectionTier`` value.
    """
    normalised_tier = _validate_tier_param(tier)
    resolver = FQANResolver(session)

    artifacts = resolver.list_by_tier(tier=normalised_tier, namespace=namespace)

    # Apply type filter if requested.
    if type is not None:
        artifacts = [a for a in artifacts if a.type == type]

    # Apply pagination.
    paginated = artifacts[offset : offset + limit]
    return [_artifact_to_response(a) for a in paginated]


@router.get(
    "/resolve",
    response_model=ResolveResponse,
    summary="Resolve an FQAN or bare artifact name via tier walk",
)
async def resolve_fqan(
    reference: str = Query(
        ..., description="FQAN (scope://ns/name@ver) or bare artifact name"
    ),
    project_id: Optional[str] = Query(
        None, description="Project ID for project-tier scoping"
    ),
    team: Optional[str] = Query(
        None, description="Team namespace for team-tier scoping"
    ),
    ambiguity_policy: Optional[str] = Query(
        None,
        description="Override ambiguity policy: warn-and-return-closest, error, return-all",
    ),
    session: DbSessionDep = None,
    settings: SettingsDep = None,
    _auth: AuthContext = Depends(require_auth),
) -> ResolveResponse:
    """Resolve an FQAN or bare artifact name to artifact(s) via tier walk.

    When *reference* contains ``://`` it is treated as an explicit FQAN and
    resolved against the specified tier directly.  Otherwise a tier walk is
    performed from ``project`` through ``marketplace``.

    The *ambiguity_policy* parameter overrides the global
    ``fqan_ambiguity_policy`` setting for this request.

    Args:
        reference: FQAN or bare artifact name.
        project_id: Optional project identifier for project-tier scoping.
        team: Optional team namespace for team-tier scoping.
        ambiguity_policy: Per-request policy override.

    Returns:
        :class:`ResolveResponse` with the primary artifact and resolution metadata.

    Raises:
        HTTPException (400): When *ambiguity_policy* override is invalid or
            the reference is a malformed FQAN.
        HTTPException (409): When *ambiguity_policy* is ``"error"`` and
            multiple tiers have matching candidates.
    """
    # Determine effective ambiguity policy.
    effective_policy = ambiguity_policy or settings.fqan_ambiguity_policy

    _VALID_POLICIES = {"warn-and-return-closest", "error", "return-all"}
    if effective_policy not in _VALID_POLICIES:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Invalid ambiguity_policy {effective_policy!r}. "
                f"Must be one of: {sorted(_VALID_POLICIES)}."
            ),
        )

    resolver = FQANResolver(session)

    try:
        result = resolver.resolve(
            reference=reference,
            project_id=project_id,
            team_namespace=team,
            ambiguity_policy=effective_policy,
        )
    except AmbiguousFQANError as exc:
        raise HTTPException(
            status_code=409,
            detail=str(exc),
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    return ResolveResponse(
        artifact=_artifact_to_response(result.artifact) if result.artifact else None,
        candidates=[_artifact_to_response(a) for a in result.candidates],
        tier_walk=result.tier_walk,
        ambiguity_warning=result.ambiguity_warning,
    )


@router.get(
    "/cascade/{artifact_id}",
    response_model=CascadeStatusResponse,
    summary="Get upstream/downstream cascade status for an artifact",
)
async def get_cascade_status(
    artifact_id: str,
    session: DbSessionDep = None,
    _auth: AuthContext = Depends(require_auth),
) -> CascadeStatusResponse:
    """Get the full upstream/downstream cascade picture for an artifact.

    Args:
        artifact_id: The ``artifacts.id`` of the artifact to inspect.

    Returns:
        :class:`CascadeStatusResponse` with upstream details and downstream count.

    Raises:
        HTTPException (404): When the artifact is not found.
    """
    svc = UpstreamCascadeService(session)

    try:
        status = svc.get_cascade_status(artifact_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    return CascadeStatusResponse(
        artifact_id=status.artifact_id,
        has_upstream=status.has_upstream,
        is_outdated=status.is_outdated,
        upstream_tier=status.upstream_tier,
        upstream_version=(
            status.upstream_artifact.upstream_version
            if status.upstream_artifact
            else None
        ),
        downstream_count=status.downstream_count,
    )


@router.post(
    "/cascade/{artifact_id}/propagate",
    response_model=CascadeResultResponse,
    summary="Propagate an update from an artifact to all downstream instances",
)
async def propagate_cascade(
    artifact_id: str,
    new_version: str = Query(
        ..., description="Version string to stamp on downstream artifacts"
    ),
    new_content_hash: str = Query(
        ..., description="Content hash of the new upstream version"
    ),
    session: DbSessionDep = None,
    _auth: AuthContext = Depends(require_auth),
) -> CascadeResultResponse:
    """Propagate an update from *artifact_id* to all downstream instances.

    Flags all lower-tier artifacts that share the same ``(name, type)`` as
    outdated and stamps them with *new_version* and *new_content_hash*.

    Args:
        artifact_id: The source artifact whose update should be propagated.
        new_version: Version string to write to downstream artifacts.
        new_content_hash: Content hash of the updated version (used for
            idempotent audit rows).

    Returns:
        :class:`CascadeResultResponse` with counts and per-tier breakdown.

    Raises:
        HTTPException (404): When the source artifact is not found.
        HTTPException (400): When the source artifact's tier cannot cascade
            (e.g. ``"marketplace"`` or no ``collection_tier`` set).
    """
    svc = UpstreamCascadeService(session)

    try:
        result = svc.propagate_update(
            source_artifact_id=artifact_id,
            new_version=new_version,
            new_content_hash=new_content_hash,
        )
    except ValueError as exc:
        msg = str(exc)
        # Distinguish "not found" from "invalid tier" errors.
        status_code = 404 if "not found" in msg.lower() else 400
        raise HTTPException(status_code=status_code, detail=msg) from exc

    session.commit()

    return CascadeResultResponse(
        source_artifact_id=result.source_artifact_id,
        affected_count=result.affected_count,
        affected_ids=result.affected_ids,
        tier_breakdown=result.tier_breakdown,
    )


@router.get(
    "/diff",
    response_model=CrossTierDiffResponse,
    summary="Generate a unified diff between two artifacts at different tiers",
)
async def cross_tier_diff(
    source_id: str = Query(
        ..., description="Source artifact ID (typically higher-tier)"
    ),
    target_id: str = Query(
        ..., description="Target artifact ID (typically lower-tier)"
    ),
    session: DbSessionDep = None,
    _auth: AuthContext = Depends(require_auth),
) -> CrossTierDiffResponse:
    """Generate a unified diff between two artifacts at (potentially) different tiers.

    Content is read from ``Artifact.content``.  When content is absent an
    empty string is used so diffs always succeed.

    Args:
        source_id: The reference artifact (usually the higher-tier / upstream one).
        target_id: The artifact to compare against the source.

    Returns:
        :class:`CrossTierDiffResponse` with the unified diff and metadata.

    Raises:
        HTTPException (404): When either artifact is not found.
    """
    svc = CrossTierDiffService(session)

    try:
        diff = svc.diff_across_tiers(
            source_artifact_id=source_id,
            target_artifact_id=target_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    return CrossTierDiffResponse(
        source_id=diff.source_id,
        source_tier=diff.source_tier,
        target_id=diff.target_id,
        target_tier=diff.target_tier,
        unified_diff=diff.unified_diff,
        has_changes=diff.has_changes,
        content_hash_match=diff.content_hash_match,
    )


@router.get(
    "/namespaces",
    response_model=List[TierNamespaceResponse],
    summary="List registered tier namespaces",
)
async def list_namespaces(
    tier: Optional[str] = Query(None, description="Filter by tier"),
    session: DbSessionDep = None,
    _auth: AuthContext = Depends(require_auth),
) -> List[TierNamespaceResponse]:
    """List all registered tier namespaces, optionally filtered by tier.

    Args:
        tier: Optional tier filter.  When provided, only namespaces for
              that tier are returned.

    Returns:
        List of :class:`TierNamespaceResponse` entries.

    Raises:
        HTTPException (400): When *tier* is not a valid ``CollectionTier`` value.
    """
    query = session.query(TierNamespace)

    if tier is not None:
        normalised = _validate_tier_param(tier)
        query = query.filter(TierNamespace.tier == normalised)

    namespaces = query.order_by(TierNamespace.tier, TierNamespace.namespace).all()

    return [
        TierNamespaceResponse(
            id=ns.id,
            tier=ns.tier,
            namespace=ns.namespace,
            display_name=ns.display_name,
            description=ns.description,
        )
        for ns in namespaces
    ]
