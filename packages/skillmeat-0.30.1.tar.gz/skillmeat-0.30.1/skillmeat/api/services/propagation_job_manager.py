"""Propagation Job Manager for async forced-propagation operations.

Provides in-memory job tracking for admin-initiated propagation jobs that push
artifacts across multiple teams. Jobs are tracked with unique IDs and progress
is updated as each team is processed.

Limitations
-----------
Job state is stored in-process. Jobs are lost on server restart. This is an
accepted trade-off for Phase 3; a persistent store (e.g. DB or Redis) can be
added in a future phase without changing the external API contract.

Stuck-job detection
-------------------
Any job that remains in ``running`` status for more than ``STUCK_JOB_TIMEOUT``
minutes is auto-failed when ``get_job`` is called. This prevents phantom
``running`` entries from accumulating after a crash or unhandled exception in
the worker coroutine.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# Jobs stuck in "running" for longer than this are auto-failed on lookup.
STUCK_JOB_TIMEOUT = timedelta(minutes=30)


# ---------------------------------------------------------------------------
# PropagationJob dataclass
# ---------------------------------------------------------------------------


@dataclass
class PropagationJob:
    """Represents a single in-process propagation job.

    Attributes:
        job_id: Unique identifier in the format ``prop-{uuid4}``.
        status: Lifecycle state: ``queued`` | ``running`` | ``complete`` |
            ``failed``.
        mode: Propagation mode requested by the caller: ``soft`` | ``hard``.
        team_ids: Ordered list of team UUID strings to process.
        artifact_ids: Artifact IDs (``type:name`` format) to propagate.
            ``None`` means "all governed artifacts for each team".
        teams_total: Total number of teams targeted.
        teams_complete: Teams processed so far (success + failure).
        teams_failed: Teams that produced an error during propagation.
        artifacts_updated: Cumulative artifact deployment updates.
        progress_pct: ``teams_complete / teams_total * 100`` (0–100).
        started_at: UTC timestamp when execution began.
        completed_at: UTC timestamp when execution finished.
        errors: Per-team error detail dicts, each containing at minimum
            ``team_id``, ``team_name``, and ``error_message`` keys.
    """

    job_id: str
    status: str  # "queued" | "running" | "complete" | "failed"
    mode: str  # "soft" | "hard"
    team_ids: List[str]
    artifact_ids: Optional[List[str]]
    teams_total: int
    teams_complete: int = 0
    teams_failed: int = 0
    artifacts_updated: int = 0
    progress_pct: float = 0.0
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    errors: List[dict] = field(default_factory=list)


# ---------------------------------------------------------------------------
# PropagationJobManager
# ---------------------------------------------------------------------------


class PropagationJobManager:
    """In-memory manager for propagation jobs.

    A single module-level singleton is exposed via
    :func:`get_propagation_job_manager`. All methods are safe to call from
    both sync and async contexts.

    Usage
    -----
    .. code-block:: python

        manager = get_propagation_job_manager()

        # Create and kick off a job:
        job = manager.create_job(team_ids, artifact_ids, mode, tenant_id)
        asyncio.create_task(
            manager.execute_propagation(job.job_id, tenant_id, session_factory)
        )

        # Poll status:
        job = manager.get_job(job.job_id)
    """

    def __init__(self) -> None:
        self._jobs: Dict[str, PropagationJob] = {}

    # ------------------------------------------------------------------
    # Job lifecycle helpers
    # ------------------------------------------------------------------

    def create_job(
        self,
        team_ids: List[str],
        artifact_ids: Optional[List[str]],
        mode: str,
        tenant_id: uuid.UUID,
    ) -> PropagationJob:
        """Create a new propagation job in ``queued`` state.

        Args:
            team_ids: Ordered list of team UUID strings to propagate to.
            artifact_ids: Artifact IDs to propagate, or ``None`` for all.
            mode: ``soft`` or ``hard``.
            tenant_id: Tenant context (for logging only at creation time).

        Returns:
            The newly created :class:`PropagationJob`.
        """
        job_id = f"prop-{uuid.uuid4()}"
        job = PropagationJob(
            job_id=job_id,
            status="queued",
            mode=mode,
            team_ids=list(team_ids),
            artifact_ids=list(artifact_ids) if artifact_ids is not None else None,
            teams_total=len(team_ids),
        )
        self._jobs[job_id] = job
        logger.info(
            "propagation-job created: job_id=%s tenant_id=%s teams=%d mode=%s",
            job_id,
            tenant_id,
            len(team_ids),
            mode,
        )
        return job

    def get_job(self, job_id: str) -> Optional[PropagationJob]:
        """Return the job for the given ID, or ``None`` if not found.

        Stuck-job detection: if the job is in ``running`` state and
        ``started_at`` is more than :data:`STUCK_JOB_TIMEOUT` ago, the job is
        auto-failed before being returned so callers never see a permanently
        stale ``running`` entry.

        Args:
            job_id: The unique propagation job ID.

        Returns:
            :class:`PropagationJob` or ``None``.
        """
        job = self._jobs.get(job_id)
        if job is None:
            return None

        if job.status == "running" and job.started_at is not None:
            age = datetime.now(tz=timezone.utc) - job.started_at
            if age > STUCK_JOB_TIMEOUT:
                logger.warning(
                    "propagation-job auto-failed (stuck): job_id=%s age=%s",
                    job_id,
                    age,
                )
                job.status = "failed"
                job.completed_at = datetime.now(tz=timezone.utc)
                job.errors.append(
                    {
                        "team_id": None,
                        "team_name": None,
                        "error_message": (
                            f"Job auto-failed after exceeding stuck-job timeout "
                            f"({STUCK_JOB_TIMEOUT.seconds // 60} min)."
                        ),
                    }
                )

        return job

    # ------------------------------------------------------------------
    # Async worker
    # ------------------------------------------------------------------

    async def execute_propagation(
        self,
        job_id: str,
        tenant_id: uuid.UUID,
        session_factory: Callable,
        auth_context: Optional[Any] = None,
    ) -> None:
        """Execute the propagation job in the background.

        Processes each team sequentially, calling
        :meth:`~skillmeat.core.services.enterprise_context_sync.EnterpriseContextSyncService.push_changes`
        for ``soft`` mode. ``hard`` mode currently falls back to soft-mode
        push logic with a note that full hard-mode enforcement will be
        provided when ECS-7 lands.

        Progress
        --------
        After each team, ``teams_complete`` and ``progress_pct`` are updated
        so polling callers see fine-grained progress. On a per-team error the
        job continues and the error detail is appended to ``job.errors``.

        Final state
        -----------
        * ``complete`` — at least one team succeeded (partial failures OK).
        * ``failed``   — every team failed, or a fatal setup error occurred.

        After completion, the org-health TTL cache is invalidated so the next
        dashboard poll reflects the updated state.

        Args:
            job_id: ID of the job to execute (must already exist in ``_jobs``).
            tenant_id: Tenant context for service and cache-key resolution.
            session_factory: Zero-argument callable returning a fresh
                SQLAlchemy ``Session``. Callers should pass
                ``skillmeat.cache.models.get_session`` or equivalent.
        """
        # Late import to avoid circular dependency at module load.
        from skillmeat.api.config import get_settings
        from skillmeat.core.services.enterprise_context_sync import (
            EnterpriseContextSyncService,
        )

        job = self._jobs.get(job_id)
        if job is None:
            logger.error(
                "execute_propagation: job_id=%s not found — aborting", job_id
            )
            return

        # Mark as running.
        job.status = "running"
        job.started_at = datetime.now(tz=timezone.utc)
        logger.info(
            "propagation-job started: job_id=%s teams=%d mode=%s",
            job_id,
            job.teams_total,
            job.mode,
        )

        settings = get_settings()

        for team_id in job.team_ids:
            session = None
            try:
                session = session_factory()
                service = EnterpriseContextSyncService(
                    session=session, settings=settings
                )

                if job.mode == "hard":
                    # Hard mode (ECS-7): full GitOps overwrite path not yet
                    # implemented. Execute soft-mode push as a best-effort
                    # fallback and log the limitation.
                    logger.info(
                        "propagation-job hard mode requested but ECS-7 not "
                        "yet implemented; executing soft-mode push for "
                        "team_id=%s job_id=%s",
                        team_id,
                        job_id,
                    )

                results = service.push_changes(
                    project_path="",  # Not used for enterprise push
                    entity_ids=job.artifact_ids,
                    target_owner_type="team",
                    target_project_id=_parse_uuid(team_id),
                    auth_context=auth_context,
                )

                # Count pushed/pending_review as successful updates.
                updates = sum(
                    1
                    for r in results
                    if getattr(r, "action", None) in ("pushed", "pending_review")
                )
                job.artifacts_updated += updates

                logger.debug(
                    "propagation-job team done: job_id=%s team_id=%s updates=%d",
                    job_id,
                    team_id,
                    updates,
                )

                # Commit the session on success.
                try:
                    session.commit()
                except Exception as commit_err:
                    logger.warning(
                        "propagation-job session commit failed for team_id=%s: %s",
                        team_id,
                        commit_err,
                    )

            except Exception as exc:
                job.teams_failed += 1
                job.errors.append(
                    {
                        "team_id": team_id,
                        "team_name": None,
                        "error_message": str(exc),
                    }
                )
                logger.warning(
                    "propagation-job team error: job_id=%s team_id=%s error=%s",
                    job_id,
                    team_id,
                    exc,
                )
                if session is not None:
                    try:
                        session.rollback()
                    except Exception:
                        pass
            finally:
                if session is not None:
                    try:
                        session.close()
                    except Exception:
                        pass

            job.teams_complete += 1
            job.progress_pct = (
                (job.teams_complete / job.teams_total * 100.0)
                if job.teams_total > 0
                else 100.0
            )

            # Yield control so other coroutines can run between teams.
            await asyncio.sleep(0)

        # Determine final status.
        if job.teams_failed == job.teams_total:
            job.status = "failed"
        else:
            job.status = "complete"

        job.completed_at = datetime.now(tz=timezone.utc)

        logger.info(
            "propagation-job finished: job_id=%s status=%s "
            "teams_total=%d teams_failed=%d artifacts_updated=%d",
            job_id,
            job.status,
            job.teams_total,
            job.teams_failed,
            job.artifacts_updated,
        )

        # Invalidate org-health cache so the next dashboard poll reflects
        # the updated state. We do this with a fresh session because all
        # per-team sessions are already closed.
        try:
            session = session_factory()
            try:
                service = EnterpriseContextSyncService(
                    session=session, settings=settings
                )
                service._invalidate_org_cache(tenant_id)
            finally:
                session.close()
        except Exception as cache_exc:
            # Non-fatal — the TTL will expire naturally.
            logger.warning(
                "propagation-job cache invalidation failed: job_id=%s error=%s",
                job_id,
                cache_exc,
            )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _parse_uuid(value: str) -> Optional[uuid.UUID]:
    """Parse a UUID string, returning ``None`` on failure.

    Args:
        value: UUID string to parse.

    Returns:
        :class:`uuid.UUID` or ``None`` when the string is not a valid UUID.
    """
    try:
        return uuid.UUID(value)
    except (ValueError, AttributeError):
        logger.warning("propagation-job: could not parse team_id as UUID: %r", value)
        return None


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_propagation_job_manager: Optional[PropagationJobManager] = None


def get_propagation_job_manager() -> PropagationJobManager:
    """Return the module-level :class:`PropagationJobManager` singleton.

    Thread-safe for read-heavy workloads. In the rare case of concurrent
    first-call initialization the worst outcome is two manager instances
    created, one of which is discarded — acceptable for in-process state.

    Returns:
        The global :class:`PropagationJobManager` instance.
    """
    global _propagation_job_manager
    if _propagation_job_manager is None:
        _propagation_job_manager = PropagationJobManager()
    return _propagation_job_manager
