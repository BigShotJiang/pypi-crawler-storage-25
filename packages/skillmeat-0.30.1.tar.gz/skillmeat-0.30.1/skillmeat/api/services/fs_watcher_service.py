"""API server lifecycle wrapper for the filesystem watcher.

``FSWatcherService`` is a thin service that owns the ``FSWatcher`` instance
within the API server process.  It is started during the FastAPI lifespan
when ``sync_capture_enabled=True``, ``sync_capture_fs_watcher_enabled=True``,
and the optional ``watchdog`` library is installed.

Responsibilities
----------------
- Resolve the list of project paths to watch from the DB (same heuristic used
  by :class:`~skillmeat.api.services.sync_capture_task.SyncCaptureTask`).
- Create an :class:`~skillmeat.core.fs_watcher.FSWatcher` with a change
  callback that delegates to
  :class:`~skillmeat.core.sync_capture_service.SyncCaptureService`.
- Provide ``start()`` / ``stop()`` methods that mirror the lifecycle pattern
  used by :class:`~skillmeat.api.services.sync_capture_task.SyncCaptureTask`.

The service degrades gracefully when ``watchdog`` is not installed: ``start()``
logs a warning and returns without raising.

Typical usage (from ``server.py`` lifespan)::

    svc = FSWatcherService(settings=settings)
    svc.start()
    yield  # app runs
    svc.stop()
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

from skillmeat.core.fs_watcher import HAS_WATCHDOG

if TYPE_CHECKING:
    from skillmeat.core.fs_watcher import ChangeEvent, FSWatcher
    from skillmeat.core.sync_capture_service import SyncCaptureService

logger = logging.getLogger(__name__)

__all__ = ["FSWatcherService"]


class FSWatcherService:
    """API server lifecycle wrapper for :class:`~skillmeat.core.fs_watcher.FSWatcher`.

    Args:
        settings: :class:`~skillmeat.api.config.APISettings` instance.  When
            ``None``, ``get_settings()`` is called lazily on first use.
        db_path: Optional path to the SQLite DB file.  Forwarded to
            :class:`~skillmeat.core.sync_capture_service.SyncCaptureService`.

    Attributes:
        is_running: ``True`` while the underlying ``FSWatcher`` is active.
    """

    def __init__(
        self,
        settings=None,
        db_path: Optional[Path] = None,
    ) -> None:
        self._settings = settings
        self._db_path = db_path

        # Lazily created
        self._watcher: Optional[FSWatcher] = None
        self._svc: Optional[SyncCaptureService] = None

    # ------------------------------------------------------------------
    # Public properties
    # ------------------------------------------------------------------

    @property
    def is_running(self) -> bool:
        """``True`` when the underlying :class:`~skillmeat.core.fs_watcher.FSWatcher` is active."""
        return self._watcher is not None and self._watcher.is_running

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the filesystem watcher.

        - Resolves project paths from the DB/filesystem heuristic.
        - Creates :class:`~skillmeat.core.fs_watcher.FSWatcher` and starts it.
        - Logs a warning and returns (no crash) if ``watchdog`` is not installed.

        Safe to call even when the watcher is already running (no-op with
        a warning log).
        """
        if not HAS_WATCHDOG:
            logger.warning(
                "FSWatcherService: watchdog is not installed — filesystem watcher "
                "will not run.  Install it with: pip install 'skillmeat[watch]'  "
                "or  pip install watchdog>=3.0.0"
            )
            return

        if self.is_running:
            logger.warning(
                "FSWatcherService: already running — ignoring duplicate start"
            )
            return

        project_paths = self._discover_project_paths()
        if not project_paths:
            logger.info(
                "FSWatcherService: no registered projects found — "
                "watcher started but will watch 0 directories"
            )

        svc = self._get_svc()

        def _on_change(event: "ChangeEvent") -> None:
            """Forward a :class:`~skillmeat.core.fs_watcher.ChangeEvent` to SyncCaptureService."""
            try:
                # Derive a best-effort project_id from the path by finding the
                # project root that is an ancestor of the changed file.
                project_id: Optional[str] = _resolve_project_id(
                    event.path, project_paths
                )
                # Use the relative path within .claude/ as the artifact_id
                # approximation.  SyncCaptureService handles unknown IDs
                # gracefully (creates a pending entry that the scan will
                # reconcile on the next cycle).
                artifact_id = str(event.path)
                svc.on_change_detected(
                    artifact_id=artifact_id,
                    content_hash=event.content_hash,
                    trigger_source="fs_watcher",
                    project_id=project_id,
                )
            except Exception:
                logger.warning(
                    "FSWatcherService: error forwarding change event for %s",
                    event.path,
                    exc_info=True,
                )

        from skillmeat.core.fs_watcher import FSWatcher

        self._watcher = FSWatcher(
            project_paths=project_paths,
            on_change=_on_change,
            settings=self._settings,
        )

        try:
            self._watcher.start()
        except RuntimeError as exc:
            # FSWatcher raises RuntimeError when watchdog is unavailable or
            # when it is already running.  We catch and log so that a watcher
            # failure never prevents the API from starting.
            logger.warning("FSWatcherService: could not start watcher: %s", exc)
            self._watcher = None
            return

        logger.info(
            "FSWatcherService: started — watching %d project path(s)",
            len(project_paths),
        )

    def stop(self) -> None:
        """Stop the filesystem watcher.

        Safe to call even when the watcher is not running.  Blocks until the
        underlying observer thread has fully exited.
        """
        watcher = self._watcher
        self._watcher = None

        if watcher is None:
            return

        try:
            watcher.stop()
        except Exception:
            logger.warning("FSWatcherService: error during watcher stop", exc_info=True)

        logger.info("FSWatcherService: stopped")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_settings(self):
        """Return the settings singleton, loading it lazily if needed."""
        if self._settings is None:
            from skillmeat.api.config import get_settings

            self._settings = get_settings()
        return self._settings

    def _get_svc(self) -> "SyncCaptureService":
        """Return the :class:`~skillmeat.core.sync_capture_service.SyncCaptureService`, creating it lazily."""
        if self._svc is None:
            from skillmeat.core.sync_capture_service import SyncCaptureService

            self._svc = SyncCaptureService(
                db_path=self._db_path,
                settings=self._settings,
            )
        return self._svc

    def _discover_project_paths(self) -> List[Path]:
        """Discover project directories using the same heuristic as SyncCaptureTask.

        Delegates to
        :meth:`~skillmeat.api.services.sync_capture_task.SyncCaptureTask._discover_project_paths_sync`
        so that both the periodic scanner and the FS watcher watch the same set
        of projects.

        Returns:
            Deduplicated list of absolute project root paths.
        """
        try:
            from skillmeat.api.services.sync_capture_task import SyncCaptureTask

            return SyncCaptureTask._discover_project_paths_sync()
        except Exception as exc:
            logger.warning(
                "FSWatcherService: could not discover project paths: %s", exc
            )
            return []


# ---------------------------------------------------------------------------
# Module-level helper
# ---------------------------------------------------------------------------


def _resolve_project_id(changed_path: Path, project_paths: List[Path]) -> Optional[str]:
    """Return the string project ID for *changed_path* by walking project roots.

    Iterates over *project_paths* and returns the string form of the first
    project root that is an ancestor of *changed_path*.  Returns ``None`` when
    no match is found.

    Args:
        changed_path: Absolute path of the changed file.
        project_paths: Known project root directories.

    Returns:
        String project ID (absolute path as string) or ``None``.
    """
    try:
        resolved = changed_path.resolve()
        for project_path in project_paths:
            try:
                resolved.relative_to(project_path)
                return str(project_path)
            except ValueError:
                continue
    except Exception:
        pass
    return None
