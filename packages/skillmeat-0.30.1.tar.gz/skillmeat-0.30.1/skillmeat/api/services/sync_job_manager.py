"""Sync Job Manager for tracking async sync-all operations.

This module provides in-memory job tracking for sync-all operations.
Jobs are tracked with unique IDs and status updates throughout their lifecycle.
"""

import logging
import uuid
from datetime import datetime, timezone
from typing import Dict, Optional
from dataclasses import dataclass, field

from skillmeat.api.schemas.vcs_v2 import SyncAllResponseDTO

logger = logging.getLogger(__name__)


@dataclass
class SyncJob:
    """Represents a sync-all job in progress."""

    job_id: str
    artifact_id: str
    status: str = "pending"  # pending, running, completed, failed
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    result: Optional[SyncAllResponseDTO] = None
    error_message: Optional[str] = None

    def start(self) -> None:
        """Mark job as started."""
        self.status = "running"
        self.started_at = datetime.now(timezone.utc)

    def complete(self, result: SyncAllResponseDTO) -> None:
        """Mark job as completed with results."""
        self.status = "completed"
        self.completed_at = datetime.now(timezone.utc)
        self.result = result

    def fail(self, error_message: str) -> None:
        """Mark job as failed with error message."""
        self.status = "failed"
        self.completed_at = datetime.now(timezone.utc)
        self.error_message = error_message


class SyncJobManager:
    """In-memory manager for sync-all jobs.

    This class provides simple job tracking for async sync operations.
    Jobs are stored in memory and will be lost on server restart.

    For production, this could be extended to use a database or Redis
    for persistence across server restarts.
    """

    def __init__(self):
        self._jobs: Dict[str, SyncJob] = {}

    def create_job(self, artifact_id: str) -> SyncJob:
        """Create a new sync job.

        Args:
            artifact_id: The artifact ID being synced

        Returns:
            SyncJob instance with unique job_id
        """
        job_id = f"sync-job-{uuid.uuid4()}"
        job = SyncJob(job_id=job_id, artifact_id=artifact_id)
        self._jobs[job_id] = job

        logger.info(f"Created sync job {job_id} for artifact {artifact_id}")
        return job

    def get_job(self, job_id: str) -> Optional[SyncJob]:
        """Get job by ID.

        Args:
            job_id: Job identifier

        Returns:
            SyncJob if found, None otherwise
        """
        return self._jobs.get(job_id)

    def start_job(self, job_id: str) -> Optional[SyncJob]:
        """Mark job as started.

        Args:
            job_id: Job identifier

        Returns:
            Updated SyncJob if found, None otherwise
        """
        job = self._jobs.get(job_id)
        if job:
            job.start()
            logger.info(f"Started sync job {job_id}")
        return job

    def complete_job(
        self, job_id: str, result: SyncAllResponseDTO
    ) -> Optional[SyncJob]:
        """Mark job as completed with results.

        Args:
            job_id: Job identifier
            result: Sync operation results

        Returns:
            Updated SyncJob if found, None otherwise
        """
        job = self._jobs.get(job_id)
        if job:
            job.complete(result)
            logger.info(
                f"Completed sync job {job_id}: "
                f"synced={result.synced_count}, skipped={result.skipped_count}, "
                f"errors={len(result.errors)}"
            )
        return job

    def fail_job(self, job_id: str, error_message: str) -> Optional[SyncJob]:
        """Mark job as failed.

        Args:
            job_id: Job identifier
            error_message: Error description

        Returns:
            Updated SyncJob if found, None otherwise
        """
        job = self._jobs.get(job_id)
        if job:
            job.fail(error_message)
            logger.error(f"Failed sync job {job_id}: {error_message}")
        return job

    def cleanup_old_jobs(self, max_age_hours: int = 24) -> int:
        """Remove jobs older than max_age_hours.

        Args:
            max_age_hours: Maximum age in hours before cleanup

        Returns:
            Number of jobs cleaned up
        """
        cutoff_time = datetime.now(timezone.utc).timestamp() - (max_age_hours * 3600)
        old_job_ids = []

        for job_id, job in self._jobs.items():
            job_age = job.created_at.timestamp()
            if job_age < cutoff_time:
                old_job_ids.append(job_id)

        for job_id in old_job_ids:
            del self._jobs[job_id]

        if old_job_ids:
            logger.info(f"Cleaned up {len(old_job_ids)} old sync jobs")

        return len(old_job_ids)

    def get_job_count(self) -> int:
        """Get total number of tracked jobs."""
        return len(self._jobs)


# Global singleton instance
_sync_job_manager: Optional[SyncJobManager] = None


def get_sync_job_manager() -> SyncJobManager:
    """Get the global sync job manager instance."""
    global _sync_job_manager
    if _sync_job_manager is None:
        _sync_job_manager = SyncJobManager()
    return _sync_job_manager
