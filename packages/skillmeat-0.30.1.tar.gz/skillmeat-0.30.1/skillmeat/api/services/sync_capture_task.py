"""Background task for periodic sync-capture scanning.

``SyncCaptureTask`` is the Phase 2 background task that drives the
Sync-as-Version-Capture (SaVC) debounce pipeline on a periodic schedule.

Responsibilities
----------------
1. **Full scan** (every ``scan_interval_seconds``): Walk every registered
   project, read its deployed artifact list, compute a content hash for each
   artifact path in the project tree, and call
   :meth:`~skillmeat.core.sync_capture_service.SyncCaptureService.on_change_detected`
   whenever the current hash differs from the baseline hash recorded in the
   deployment metadata.

2. **Debounce drain** (every ``DEBOUNCE_DRAIN_INTERVAL`` seconds, default
   15 s): Call
   :meth:`~skillmeat.core.sync_capture_service.SyncCaptureService.process_expired_entries`
   to flush any debounce entries whose quiet window has expired.

The task is intentionally non-fatal: all per-project and per-artifact errors
are caught and logged so that one bad project never blocks the rest.

Lifecycle
---------
The task is started during the FastAPI lifespan and stopped on shutdown::

    task = SyncCaptureTask(settings=get_settings())
    await task.start()
    yield  # app runs
    await task.stop()

The task only activates when **both** ``sync_capture_enabled`` and
``sync_capture_auto_scan_enabled`` are ``True`` in
:class:`~skillmeat.api.config.APISettings`.  When either flag is ``False``
the task exits its loop immediately after starting, logging an info message.
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Interval (seconds) for draining the debounce queue inside a single scan
# cycle.  The outer full-scan runs at settings.sync_capture_scan_interval_seconds;
# within that period we drain expired entries every DEBOUNCE_DRAIN_INTERVAL
# seconds so that changes captured by other triggers (on-access, fs-watcher)
# are not held up waiting for the next full scan.
DEBOUNCE_DRAIN_INTERVAL: int = 15

# Default TTL (days) for pruning captured/expired debounce entries.
# Use a settings field (sync_capture_prune_ttl_days) when available; fall back
# to this constant so the table stays bounded even without explicit config.
_DEFAULT_PRUNE_TTL_DAYS: int = 7

__all__ = ["SyncCaptureTask"]


class SyncCaptureTask:
    """Asyncio background task that periodically scans projects for changes.

    Args:
        settings: :class:`~skillmeat.api.config.APISettings` instance.  When
            ``None``, ``get_settings()`` is called lazily on first use.
        db_path: Optional path to the SQLite DB file.  Forwarded to
            :class:`~skillmeat.core.sync_capture_service.SyncCaptureService`.

    Attributes:
        scan_interval: Seconds between full project scans.
        is_running: ``True`` while the background task is active.
        stats: Dictionary of runtime statistics for observability.
    """

    def __init__(
        self,
        settings=None,
        db_path: Optional[Path] = None,
    ) -> None:
        self._settings = settings
        self._db_path = db_path

        # Lazily initialised in _get_svc()
        self._svc = None

        # Asyncio task handle
        self._task: Optional[asyncio.Task] = None
        self._running: bool = False

        # Runtime stats
        self._scan_count: int = 0
        self._drain_count: int = 0
        self._prune_count: int = 0
        self._error_count: int = 0
        self._artifacts_scanned: int = 0
        self._changes_detected: int = 0
        self._entries_pruned: int = 0
        self._last_scan_time: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Public properties
    # ------------------------------------------------------------------

    @property
    def is_running(self) -> bool:
        """``True`` while the background task coroutine is active."""
        return self._running

    @property
    def scan_interval(self) -> int:
        """Full-scan interval in seconds (from settings)."""
        try:
            return self._get_settings().sync_capture_scan_interval_seconds
        except Exception:
            return 300

    @property
    def stats(self) -> dict:
        """Runtime statistics dictionary for health/status endpoints."""
        return {
            "is_running": self._running,
            "scan_interval_seconds": self.scan_interval,
            "debounce_drain_interval_seconds": DEBOUNCE_DRAIN_INTERVAL,
            "scan_count": self._scan_count,
            "drain_count": self._drain_count,
            "prune_count": self._prune_count,
            "error_count": self._error_count,
            "artifacts_scanned": self._artifacts_scanned,
            "changes_detected": self._changes_detected,
            "entries_pruned": self._entries_pruned,
            "last_scan_time": (
                self._last_scan_time.isoformat() if self._last_scan_time else None
            ),
        }

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the background task.

        If the task is already running this is a no-op (logs a warning).
        """
        if self._running:
            logger.warning(
                "SyncCaptureTask already running — ignoring duplicate start"
            )
            return

        self._running = True
        self._task = asyncio.create_task(self._run_loop())
        logger.info(
            "SyncCaptureTask started (scan_interval=%ds, drain_interval=%ds)",
            self.scan_interval,
            DEBOUNCE_DRAIN_INTERVAL,
        )

    async def stop(self) -> None:
        """Stop the background task gracefully.

        Cancels the running coroutine and waits for it to terminate.
        """
        if not self._running:
            logger.debug("SyncCaptureTask not running — ignoring stop")
            return

        self._running = False
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass  # expected
            self._task = None

        logger.info("SyncCaptureTask stopped")

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    async def _run_loop(self) -> None:
        """Main event loop.

        Structure
        ---------
        ::

            while running:
                1. Check feature flags — exit early if disabled
                2. Run a full project scan (blocking work offloaded to thread pool)
                3. Within the scan cycle, drain debounce queue every 15 s
                   until the next full scan is due
        """
        settings = self._get_settings()

        if not settings.sync_capture_enabled:
            logger.info(
                "SyncCaptureTask: sync_capture_enabled=False — task will remain "
                "dormant until setting is changed and service is restarted"
            )
            self._running = False
            return

        if not settings.sync_capture_auto_scan_enabled:
            logger.info(
                "SyncCaptureTask: sync_capture_auto_scan_enabled=False — periodic "
                "scanning disabled; task exits"
            )
            self._running = False
            return

        while self._running:
            scan_start = time.monotonic()

            # --- Full project scan ---
            try:
                await self._scan_projects()
                self._last_scan_time = datetime.utcnow()
                self._scan_count += 1
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self._error_count += 1
                logger.exception("SyncCaptureTask: unhandled error during scan: %s", exc)

            # --- TTL-based pruning (runs once per scan cycle, non-fatal) ---
            await self._prune_old_entries()

            # --- Debounce drain loop until next full scan ---
            scan_interval = self.scan_interval
            elapsed = time.monotonic() - scan_start
            remaining = max(0.0, scan_interval - elapsed)

            while remaining > 0 and self._running:
                sleep_time = min(float(DEBOUNCE_DRAIN_INTERVAL), remaining)
                try:
                    await asyncio.sleep(sleep_time)
                except asyncio.CancelledError:
                    raise

                # Drain the debounce queue
                try:
                    svc = self._get_svc()
                    processed = svc.process_expired_entries()
                    self._drain_count += 1
                    if processed:
                        logger.debug(
                            "SyncCaptureTask: debounce drain processed %d entries",
                            processed,
                        )
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    self._error_count += 1
                    logger.warning(
                        "SyncCaptureTask: non-fatal error during debounce drain: %s",
                        exc,
                    )

                elapsed = time.monotonic() - scan_start
                remaining = max(0.0, scan_interval - elapsed)

    # ------------------------------------------------------------------
    # Scan implementation
    # ------------------------------------------------------------------

    async def _scan_projects(self) -> None:
        """Discover registered projects and scan each for artifact changes.

        The blocking filesystem work is offloaded to the default thread-pool
        executor so the event loop is not blocked.
        """
        loop = asyncio.get_event_loop()

        # Discover project paths (blocking I/O — run in executor)
        try:
            project_paths: List[Path] = await loop.run_in_executor(
                None, self._discover_project_paths_sync
            )
        except Exception as exc:
            logger.warning(
                "SyncCaptureTask: could not discover project paths: %s", exc
            )
            return

        if not project_paths:
            logger.debug("SyncCaptureTask: no registered projects found")
            return

        logger.debug(
            "SyncCaptureTask: scanning %d project(s)", len(project_paths)
        )

        total_scanned = 0
        total_changed = 0

        for project_path in project_paths:
            if not self._running:
                break
            try:
                scanned, changed = await loop.run_in_executor(
                    None, self._scan_single_project, project_path
                )
                total_scanned += scanned
                total_changed += changed
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self._error_count += 1
                logger.warning(
                    "SyncCaptureTask: error scanning project %s: %s",
                    project_path,
                    exc,
                )

        self._artifacts_scanned += total_scanned
        self._changes_detected += total_changed

        logger.info(
            "SyncCaptureTask: scan complete — projects=%d artifacts_scanned=%d "
            "changes_detected=%d",
            len(project_paths),
            total_scanned,
            total_changed,
        )

    def _scan_single_project(self, project_path: Path) -> Tuple[int, int]:
        """Scan one project for changed artifacts.

        Reads the deployment metadata for *project_path*, resolves each
        deployed artifact's filesystem path, computes its current content hash,
        and compares it against the baseline hash stored in the deployment
        record.  When a mismatch is detected,
        :meth:`SyncCaptureService.on_change_detected` is called.

        Args:
            project_path: Absolute path to the project root directory.

        Returns:
            ``(artifacts_scanned, changes_detected)`` counts for this project.
        """
        from skillmeat.storage.deployment import DeploymentTracker

        deployments = DeploymentTracker.read_deployments(project_path)
        if not deployments:
            return 0, 0

        svc = self._get_svc()
        scanned = 0
        changed = 0

        for deployment in deployments:
            try:
                artifact_path = self._resolve_artifact_path(
                    project_path, deployment
                )
                if artifact_path is None or not artifact_path.exists():
                    logger.debug(
                        "SyncCaptureTask: artifact path not found for %s:%s in %s",
                        deployment.artifact_type,
                        deployment.artifact_name,
                        project_path,
                    )
                    continue

                current_hash = _compute_content_hash(artifact_path)
                baseline_hash = deployment.content_hash
                scanned += 1

                if current_hash != baseline_hash:
                    artifact_id = (
                        f"{deployment.artifact_type}:{deployment.artifact_name}"
                    )
                    project_id = str(project_path)
                    svc.on_change_detected(
                        artifact_id=artifact_id,
                        content_hash=current_hash,
                        trigger_source="periodic",
                        project_id=project_id,
                    )
                    changed += 1
                    logger.debug(
                        "SyncCaptureTask: change detected %s in project %s "
                        "(baseline=%s current=%s)",
                        artifact_id,
                        project_path,
                        baseline_hash[:8] if baseline_hash else "none",
                        current_hash[:8],
                    )

            except Exception as exc:
                logger.warning(
                    "SyncCaptureTask: error processing deployment %s:%s in %s: %s",
                    getattr(deployment, "artifact_type", "?"),
                    getattr(deployment, "artifact_name", "?"),
                    project_path,
                    exc,
                )

        return scanned, changed

    # ------------------------------------------------------------------
    # Pruning
    # ------------------------------------------------------------------

    async def _prune_old_entries(self) -> None:
        """Remove stale ``captured``/``expired`` debounce entries.

        Runs once per full-scan cycle.  ``pending`` entries are never pruned so
        that queued captures are not silently discarded.

        The TTL is read from ``settings.sync_capture_prune_ttl_days`` when
        available; falls back to :data:`_DEFAULT_PRUNE_TTL_DAYS` (7 days).

        Errors are caught and logged so a pruning failure never crashes the
        background task.
        """
        try:
            ttl_days: int = _DEFAULT_PRUNE_TTL_DAYS
            try:
                settings = self._get_settings()
                ttl_days = int(
                    getattr(settings, "sync_capture_prune_ttl_days", _DEFAULT_PRUNE_TTL_DAYS)
                )
            except Exception:
                pass  # settings unavailable — use default

            loop = asyncio.get_event_loop()
            deleted = await loop.run_in_executor(
                None, self._run_prune_sync, ttl_days
            )
            self._prune_count += 1
            self._entries_pruned += deleted
            if deleted:
                logger.info(
                    "SyncCaptureTask: pruned %d stale debounce entries "
                    "(ttl_days=%d)",
                    deleted,
                    ttl_days,
                )
            else:
                logger.debug(
                    "SyncCaptureTask: prune pass complete — no entries removed "
                    "(ttl_days=%d)",
                    ttl_days,
                )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._error_count += 1
            logger.warning(
                "SyncCaptureTask: non-fatal error during prune: %s", exc
            )

    def _run_prune_sync(self, ttl_days: int) -> int:
        """Synchronous pruning call, executed in a thread-pool worker.

        Args:
            ttl_days: Age threshold for eligible rows.

        Returns:
            Number of rows deleted.
        """
        from skillmeat.core.repositories.sync_debounce_repository import (
            SyncDebounceRepository,
        )

        repo = SyncDebounceRepository(db_path=self._db_path)
        return repo.prune_old(older_than_days=ttl_days)

    # ------------------------------------------------------------------
    # Path resolution helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_artifact_path(
        project_path: Path, deployment
    ) -> Optional[Path]:
        """Resolve the deployed artifact's path within the project tree.

        Mirrors the naming conventions used by :class:`~skillmeat.core.sync.SyncManager`
        when computing project-side content hashes.

        Args:
            project_path: Root directory of the project.
            deployment: :class:`~skillmeat.core.deployment.Deployment` record.

        Returns:
            Absolute :class:`~pathlib.Path` to the deployed artifact, or
            ``None`` when the type mapping is unknown.
        """
        artifact_type = deployment.artifact_type
        artifact_name = deployment.artifact_name

        # Walk the profile roots (.claude, .windsurf, etc.) looking for the
        # deployed artifact location.  We check the canonical .claude location
        # first, then fall back to other profile dirs.
        from skillmeat.core.path_resolver import DEFAULT_PROFILE_ROOTS

        _TYPE_SUBDIRS: Dict[str, str] = {
            "skill": "skills",
            "command": "commands",
            "agent": "agents",
            "hook": "hooks",
            "mcp": "mcp",
            "workflow": "workflows",
            "rule": "rules",
            "context": "context",
            "spec": "specs",
            "template": "templates",
            "progress_template": "progress",
        }

        subdir = _TYPE_SUBDIRS.get(artifact_type)
        if subdir is None:
            # Unknown type — skip gracefully
            return None

        # For single-file artifacts the filename may carry an extension.
        # Commands are .md files; workflows are .yaml files.
        # Skills, agents, hooks, etc. are directories.
        _SINGLE_FILE_EXTENSIONS: Dict[str, str] = {
            "command": ".md",
            "workflow": ".yaml",
            "spec": ".md",
            "rule": ".md",
            "context": ".md",
            "progress_template": ".md",
        }

        ext = _SINGLE_FILE_EXTENSIONS.get(artifact_type, "")

        for profile_root in DEFAULT_PROFILE_ROOTS:
            base = project_path / profile_root / subdir
            if ext:
                candidate = base / f"{artifact_name}{ext}"
            else:
                candidate = base / artifact_name

            if candidate.exists():
                return candidate

        return None

    # ------------------------------------------------------------------
    # Project discovery
    # ------------------------------------------------------------------

    @staticmethod
    def _discover_project_paths_sync() -> List[Path]:
        """Synchronously discover project directories that have deployment files.

        This is the same heuristic used by :class:`~skillmeat.api.project_registry.ProjectRegistry`.
        It walks common home-directory locations (``~/projects``, ``~/dev``,
        ``~/workspace``, ``~/src``, and the current working directory) up to a
        depth of 3, looking for directories that contain a deployment file
        (``DeploymentTracker.DEPLOYMENT_FILE``).

        Returns:
            Deduplicated list of absolute project root paths.
        """
        import os

        from skillmeat.core.path_resolver import DEFAULT_PROFILE_ROOTS
        from skillmeat.storage.deployment import DeploymentTracker

        deployment_filename = DeploymentTracker.DEPLOYMENT_FILE
        home = Path.home()
        search_paths: List[Path] = [
            home / "projects",
            home / "dev",
            home / "workspace",
            home / "src",
            Path.cwd(),
        ]

        skip_dirs = {
            "node_modules",
            ".git",
            "venv",
            ".venv",
            "__pycache__",
            ".npm",
            ".cargo",
            ".rustup",
            ".cache",
            ".local",
            "vendor",
            "dist",
            "build",
            ".next",
            ".nuxt",
            "target",
            "Pods",
            ".gradle",
        }

        MAX_DEPTH = 3
        discovered: List[Path] = []
        seen: set = set()

        for search_root in search_paths:
            if not search_root.exists() or not search_root.is_dir():
                continue

            try:
                resolved_root = search_root.resolve()
            except (RuntimeError, OSError) as exc:
                logger.debug(
                    "SyncCaptureTask: skipping search root %s: %s", search_root, exc
                )
                continue

            for dirpath, dirnames, filenames in os.walk(
                resolved_root, topdown=True, followlinks=False
            ):
                current_path = Path(dirpath)
                depth = len(current_path.relative_to(resolved_root).parts)

                # Prune heavy/irrelevant directories
                dirnames[:] = [
                    d
                    for d in dirnames
                    if d not in skip_dirs
                ]

                # Stop descending beyond MAX_DEPTH
                if depth >= MAX_DEPTH:
                    dirnames.clear()
                    continue

                # Check if any profile-root subdirectory contains the deployment file
                for profile_root in DEFAULT_PROFILE_ROOTS:
                    deployment_file = current_path / profile_root / deployment_filename
                    if deployment_file.exists():
                        resolved_project = current_path.resolve()
                        key = str(resolved_project)
                        if key not in seen:
                            seen.add(key)
                            discovered.append(resolved_project)
                        break  # no need to check other profile roots for this dir

        return discovered

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_settings(self):
        """Return the settings singleton, loading it lazily if needed."""
        if self._settings is None:
            from skillmeat.api.config import get_settings

            self._settings = get_settings()
        return self._settings

    def _get_svc(self):
        """Return the :class:`SyncCaptureService`, creating it lazily."""
        if self._svc is None:
            from skillmeat.core.sync_capture_service import SyncCaptureService

            self._svc = SyncCaptureService(
                db_path=self._db_path,
                settings=self._settings,
            )
        return self._svc


# ---------------------------------------------------------------------------
# Module-level helper (avoids importing the full SyncManager for a single hash)
# ---------------------------------------------------------------------------


def _compute_content_hash(path: Path) -> str:
    """Compute SHA-256 hash of a file or directory.

    This is a local implementation that mirrors
    :func:`~skillmeat.utils.filesystem.compute_content_hash` but never raises
    on ``FileNotFoundError`` (callers already guard with ``path.exists()``).

    Args:
        path: Existing file or directory.

    Returns:
        Hexadecimal SHA-256 hash string.
    """
    hasher = hashlib.sha256()

    if path.is_file():
        try:
            hasher.update(path.read_bytes())
        except (PermissionError, OSError) as exc:
            logger.warning("_compute_content_hash: cannot read %s: %s", path, exc)
    elif path.is_dir():
        for file_path in sorted(path.rglob("*")):
            if file_path.is_file():
                rel = file_path.relative_to(path)
                hasher.update(str(rel).encode("utf-8"))
                try:
                    hasher.update(file_path.read_bytes())
                except (PermissionError, OSError) as exc:
                    logger.warning(
                        "_compute_content_hash: cannot read %s: %s", file_path, exc
                    )

    return hasher.hexdigest()
