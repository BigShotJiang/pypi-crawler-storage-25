"""FastAPI dependency injection providers.

This module provides dependency injection functions for FastAPI routes,
managing the lifecycle of shared resources like collection managers,
database connections, and configuration.
"""

import logging
import uuid
from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from typing import Annotated, Any, Optional

from fastapi import Depends, HTTPException, Request, Security, status
from fastapi.security import APIKeyHeader
from sqlalchemy.orm import Session

from skillmeat.api.auth.provider import AuthProvider
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.config import ConfigManager
from skillmeat.core.artifact import ArtifactManager
from skillmeat.core.auth import TokenManager
from skillmeat.core.collection import CollectionManager
from skillmeat.core.interfaces.repositories import (
    IArtifactActivityRepository,
    IArtifactRepository,
    IBomRepository,
    IBundleRepository,
    ICollectionRepository,
    IContextEntityRepository,
    IDbArtifactHistoryRepository,
    IDbCollectionArtifactRepository,
    IDbUserCollectionRepository,
    IDeploymentRepository,
    IGitCredentialRepository,
    IGitRepoConnectionRepository,
    IGitRepoScanRepository,
    IGitScanArtifactRepository,
    IGroupRepository,
    IProjectGitConnectionRepository,
    IMembershipRepository,
    IMarketplaceSourceRepository,
    IMemoryItemRepository,
    IProjectRepository,
    IProjectTemplateRepository,
    ISettingsRepository,
    ITagRepository,
    IWorkflowRepository,
)
from skillmeat.core.auth.ownership_context import ResolvedOwnershipContext
from skillmeat.core.ownership import ResolvedOwnership
from skillmeat.core.services.ownership_resolver import OwnershipResolver
from skillmeat.cache.repositories import (
    DbArtifactHistoryRepository,
    DbCollectionArtifactRepository,
    DbUserCollectionRepository,
    DeploymentProfileRepository,
    DeploymentSetRepository,
    DuplicatePairRepository,
    MarketplaceCatalogRepository,
    MarketplaceSourceRepository,
    MarketplaceTransactionHandler,
)
from skillmeat.cache.session import get_db_session
from skillmeat.core.path_resolver import ProjectPathResolver
from skillmeat.core.services.context_sync import ContextSyncService, IContextSyncService
from skillmeat.core.sync import SyncManager

from .config import APISettings, get_settings

logger = logging.getLogger(__name__)

# API Key security scheme (optional authentication)
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


# Application state container
class AppState:
    """Application state container for shared resources.

    This class holds singleton instances of managers and configuration
    that are shared across all requests.
    """

    def __init__(self):
        """Initialize application state."""
        self.config_manager: Optional[ConfigManager] = None
        self.collection_manager: Optional[CollectionManager] = None
        self.artifact_manager: Optional[ArtifactManager] = None
        self.token_manager: Optional[TokenManager] = None
        self.sync_manager: Optional[SyncManager] = None
        self.context_sync_service: Optional[ContextSyncService] = None
        self.settings: Optional[APISettings] = None
        self.metadata_cache: Optional[Any] = None  # MetadataCache, lazily initialized
        self.cache_manager: Optional[Any] = None  # CacheManager, lazily initialized
        self.refresh_job: Optional[Any] = None  # RefreshJob, lazily initialized
        self.path_resolver: Optional[ProjectPathResolver] = None
        self.redis_client: Optional[Any] = (
            None  # Redis client for compliance gate caching
        )

    def initialize(self, settings: APISettings) -> None:
        """Initialize all managers with settings.

        Args:
            settings: API settings instance
        """
        logger.info("Initializing application state...")
        self.settings = settings

        # Always-initialized managers (work in all editions)
        self.config_manager = ConfigManager()
        self.token_manager = TokenManager() if settings.auth_enabled else None
        self.path_resolver = ProjectPathResolver()

        # Filesystem managers — only available in local edition
        if settings.edition != "enterprise":
            self.collection_manager = CollectionManager(config=self.config_manager)
            self.artifact_manager = ArtifactManager(
                collection_mgr=self.collection_manager
            )
            self.sync_manager = SyncManager(
                collection_manager=self.collection_manager,
                artifact_manager=self.artifact_manager,
            )
        else:
            logger.info(
                "Enterprise edition: skipping filesystem manager initialization"
            )
            self.collection_manager = None
            self.artifact_manager = None
            self.sync_manager = None

        # Initialize cache manager if not already initialized (lazy init pattern)
        # Enterprise edition uses PostgreSQL repositories — skip SQLite cache
        if self.cache_manager is None and settings.edition != "enterprise":
            try:
                from skillmeat.cache.manager import CacheManager as CacheManagerImpl

                self.cache_manager = CacheManagerImpl()
                logger.info("CacheManager initialized")
            except Exception as e:
                logger.warning(f"CacheManager initialization failed: {e}")
                self.cache_manager = None

        # Initialize Redis client if enabled
        if settings.redis_enabled:
            try:
                import redis

                self.redis_client = redis.Redis(
                    host=settings.redis_host,
                    port=settings.redis_port,
                    db=settings.redis_db,
                    password=settings.redis_password,
                    decode_responses=True,
                    socket_connect_timeout=1,  # Fast timeout for compliance gate requirements
                    socket_timeout=1,
                    health_check_interval=30,
                )
                # Test connection
                self.redis_client.ping()
                logger.info(
                    f"Redis client initialized: {settings.redis_host}:{settings.redis_port}"
                )
            except Exception as e:
                logger.warning(
                    f"Redis initialization failed: {e}. Compliance gate will work without caching."
                )
                self.redis_client = None

        # Initialize context sync service (requires both cache_manager and collection_manager)
        if self.cache_manager is not None and self.collection_manager is not None:
            self.context_sync_service = ContextSyncService(
                collection_mgr=self.collection_manager,
                cache_mgr=self.cache_manager,
            )
            logger.info("ContextSyncService initialized")
        else:
            if settings.edition == "enterprise":
                logger.info(
                    "Enterprise edition: skipping ContextSyncService (no collection_manager)"
                )
            else:
                logger.warning(
                    "ContextSyncService not initialized (CacheManager unavailable)"
                )
            self.context_sync_service = None

        logger.info("Application state initialized successfully")

    def shutdown(self) -> None:
        """Clean up resources on shutdown."""
        logger.info("Shutting down application state...")
        # Add cleanup logic here if needed (close DB connections, etc.)

        # Stop refresh job scheduler if running
        if self.refresh_job is not None:
            try:
                self.refresh_job.stop_scheduler(wait=True)
            except Exception as e:
                logger.warning(f"Error stopping refresh job: {e}")

        self.config_manager = None
        self.collection_manager = None
        self.artifact_manager = None
        self.token_manager = None
        self.sync_manager = None
        self.context_sync_service = None
        self.metadata_cache = None
        self.cache_manager = None
        self.refresh_job = None
        self.path_resolver = None
        logger.info("Application state shutdown complete")


# Global application state (initialized in lifespan)
app_state = AppState()


@dataclass(frozen=True)
class EnterpriseContext:
    """Resolved enterprise tenant and org context for the current request.

    Derived from auth context — callers never need to send org_id explicitly.
    Safe for all modes: enterprise (from JWT), local (DEFAULT_TENANT_ID fallback).
    """

    tenant_id: uuid.UUID
    org_id: uuid.UUID


# ---------------------------------------------------------------------------
# Auth provider singleton
# ---------------------------------------------------------------------------

#: Module-level auth provider instance.  Set during app startup via
#: ``set_auth_provider()``.  ``None`` until explicitly configured.
_auth_provider: Optional[AuthProvider] = None


def set_auth_provider(provider: AuthProvider) -> None:
    """Register the application-wide authentication provider.

    Call this once during startup (e.g. inside the lifespan function) before
    any requests are handled.

    Args:
        provider: A concrete ``AuthProvider`` implementation.
    """
    global _auth_provider
    _auth_provider = provider


def get_auth_provider() -> AuthProvider:
    """Return the configured authentication provider.

    Returns:
        The registered ``AuthProvider`` instance.

    Raises:
        HTTPException: 503 if no provider has been registered yet.
    """
    if _auth_provider is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Authentication provider not configured",
        )
    return _auth_provider


# ---------------------------------------------------------------------------
# require_auth dependency
# ---------------------------------------------------------------------------


def require_auth(
    scopes: list[str] | None = None,
) -> Callable[..., Coroutine[Any, Any, AuthContext]]:
    """FastAPI dependency factory that validates authentication and optional scopes.

    # Auth Bypass Contract (CP-001)
    # -----------------------------------------------------------------------
    # auth_enabled=false → server.py lifespan registers LocalAuthProvider.
    #                      LocalAuthProvider.validate() always returns
    #                      LOCAL_ADMIN_CONTEXT (user_id="local", role=system_admin,
    #                      all scopes).  No credentials are inspected; auth
    #                      always succeeds.
    # auth_enabled=true  → lifespan registers the configured provider (e.g.
    #                      ClerkAuthProvider).  Every request is validated
    #                      against real credentials.
    # This function has NO awareness of auth_enabled.  The provider selection
    # at startup is the single enforcement decision point.
    # -----------------------------------------------------------------------

    Supports two usage patterns::

        # No scope check — just authenticate
        @router.get("/items")
        async def list_items(auth: AuthContext = Depends(require_auth)):
            ...

        # With scope check — 403 if any required scope is missing
        @router.post("/items")
        async def create_item(auth: AuthContext = Depends(require_auth(scopes=["artifact:write"]))):
            ...

    When used directly as ``Depends(require_auth)`` FastAPI calls ``require_auth``
    with no arguments (its default signature), which returns an inner coroutine
    that FastAPI then calls with the ``Request``.  When used as
    ``Depends(require_auth(scopes=[...]))`` the outer call returns the same inner
    coroutine type, so both forms are structurally identical to FastAPI.

    Args:
        scopes: Optional list of scope strings (e.g. ``["artifact:read"]``) that
            the authenticated context must carry.  Uses ``AuthContext.has_scope``
            which honours the ``admin:*`` wildcard automatically.

    Returns:
        An async dependency coroutine that resolves to the authenticated
        ``AuthContext``.

    Raises:
        HTTPException 401: Propagated from the provider when credentials are
            absent or invalid.
        HTTPException 403: When one or more required scopes are missing.
        HTTPException 503: When no auth provider has been registered.
    """

    async def _dependency(request: Request) -> AuthContext:
        provider = get_auth_provider()
        auth_context = await provider.validate(request)

        # Expose auth context on request state so middleware and downstream
        # handlers can access it without repeating the provider lookup.
        request.state.auth_context = auth_context

        if scopes:
            missing = [s for s in scopes if not auth_context.has_scope(s)]
            if missing:
                logger.warning(
                    "Auth scope check failed: user=%s missing=%s",
                    auth_context.user_id,
                    missing,
                )
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Missing required scopes: {missing}",
                )

        return auth_context

    return _dependency


#: Pre-built ``Annotated`` alias for routes that only need authentication
#: without explicit scope enforcement.
AuthContextDep = Annotated[AuthContext, Depends(require_auth())]


# ---------------------------------------------------------------------------
# require_enterprise_admin dependency
# ---------------------------------------------------------------------------


def require_enterprise_admin() -> Callable[..., Coroutine[Any, Any, AuthContext]]:
    """FastAPI dependency factory that enforces ``system_admin`` role.

    Chains on top of ``require_auth(scopes=["admin:*"])`` so the request is
    authenticated and carries the admin wildcard scope before the role check
    is applied.  This prevents privilege escalation via unauthenticated calls.

    Usage::

        @router.post("/enterprise/artifacts")
        async def create_enterprise_artifact(
            auth: AuthContext = Depends(require_enterprise_admin()),
        ) -> ...:
            ...

        # Or via the pre-built type alias:
        @router.delete("/enterprise/artifacts/{id}")
        async def delete_enterprise_artifact(
            auth: EnterpriseAdminDep,
        ) -> ...:
            ...

    Returns:
        An async dependency coroutine that resolves to the authenticated
        ``AuthContext`` when the caller holds the ``system_admin`` role.

    Raises:
        HTTPException 401: Propagated from ``require_auth`` when credentials
            are absent or invalid.
        HTTPException 403: When the authenticated user does not hold the
            ``system_admin`` role, or when required admin scopes are missing.
        HTTPException 503: When no auth provider has been registered.
    """

    async def _dependency(
        auth: AuthContext = Depends(require_auth(scopes=["admin:*"])),
    ) -> AuthContext:
        if not auth.is_admin():
            logger.warning(
                "Enterprise admin check failed: user=%s roles=%s",
                auth.user_id,
                auth.roles,
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Enterprise operations require system_admin role",
            )
        return auth

    return _dependency


#: Pre-built ``Annotated`` alias for enterprise-scoped write endpoints that
#: require the ``system_admin`` role.
EnterpriseAdminDep = Annotated[AuthContext, Depends(require_enterprise_admin())]


async def get_auth_context(request: Request) -> AuthContext:
    """Read AuthContext from request.state (set by router-level require_auth).

    This lightweight dependency avoids a second provider round-trip for
    handlers that are already protected by a router-level ``require_auth``
    dependency (registered via ``dependencies=_auth_deps`` in server.py).
    It simply reads the ``auth_context`` attribute that ``require_auth``
    stores on ``request.state`` and returns it.

    Args:
        request: The current FastAPI request.

    Returns:
        The ``AuthContext`` stored by the router-level auth dependency.

    Raises:
        HTTPException 401: If ``request.state`` has no ``auth_context``
            (should not happen when router-level auth is wired correctly).
    """
    auth_ctx = getattr(request.state, "auth_context", None)
    if auth_ctx is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
        )
    return auth_ctx


def get_app_state() -> AppState:
    """Get application state dependency.

    Returns:
        AppState instance

    Raises:
        HTTPException: If application state not initialized
    """
    if app_state.settings is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Application not initialized",
        )
    return app_state


def get_config_manager(
    state: Annotated[AppState, Depends(get_app_state)],
) -> ConfigManager:
    """Get ConfigManager dependency.

    Args:
        state: Application state

    Returns:
        ConfigManager instance

    Raises:
        HTTPException: If ConfigManager not available
    """
    if state.config_manager is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Configuration manager not available",
        )
    return state.config_manager


def get_collection_manager(
    state: Annotated[AppState, Depends(get_app_state)],
) -> CollectionManager:
    """Get CollectionManager dependency.

    Args:
        state: Application state

    Returns:
        CollectionManager instance

    Raises:
        HTTPException: If CollectionManager not available
    """
    if state.collection_manager is None:
        if state.settings and state.settings.edition == "enterprise":
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail="Collection manager is not available in enterprise edition",
            )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Collection manager not available",
        )
    return state.collection_manager


def get_artifact_manager(
    state: Annotated[AppState, Depends(get_app_state)],
) -> ArtifactManager:
    """Get ArtifactManager dependency.

    Args:
        state: Application state

    Returns:
        ArtifactManager instance

    Raises:
        HTTPException: If ArtifactManager not available
    """
    if state.artifact_manager is None:
        if state.settings and state.settings.edition == "enterprise":
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail="Artifact manager is not available in enterprise edition",
            )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Artifact manager not available",
        )
    return state.artifact_manager


def get_token_manager(
    state: Annotated[AppState, Depends(get_app_state)],
) -> TokenManager:
    """Get TokenManager dependency.

    Args:
        state: Application state

    Returns:
        TokenManager instance

    Raises:
        HTTPException: If TokenManager not available
    """
    if state.token_manager is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Token manager not available",
        )
    return state.token_manager


def get_sync_manager(
    state: Annotated[AppState, Depends(get_app_state)],
) -> SyncManager:
    """Get SyncManager dependency.

    Args:
        state: Application state

    Returns:
        SyncManager instance

    Raises:
        HTTPException: If SyncManager not available
    """
    if state.sync_manager is None:
        if state.settings and state.settings.edition == "enterprise":
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail="Sync manager is not available in enterprise edition",
            )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Sync manager not available",
        )
    return state.sync_manager


def get_context_sync_service(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IContextSyncService:
    """Get IContextSyncService dependency.

    In local edition, returns the pre-initialised ``LocalContextSyncService``
    stored on ``AppState``.

    In enterprise edition, returns an ``EnterpriseContextSyncService`` wired
    to the current request's DB session — but only when
    ``settings.enterprise_sync_enabled`` is ``True``.  When the flag is
    ``False`` a HTTP 501 is raised to signal that the feature is not yet
    enabled.

    Args:
        state: Application state.
        session: Per-request SQLAlchemy session (used in enterprise edition).

    Returns:
        IContextSyncService implementation for the configured edition.

    Raises:
        HTTPException: 501 if enterprise edition and flag is disabled.
        HTTPException: 503 if local edition and service not yet initialised.
    """
    if state.settings and state.settings.edition == "enterprise":
        if not state.settings.enterprise_sync_enabled:
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail="Enterprise sync not enabled",
            )
        from skillmeat.core.services.enterprise_context_sync import (
            EnterpriseContextSyncService,
        )

        return EnterpriseContextSyncService(
            session=session,
            settings=state.settings,
        )

    # Local edition — use the pre-initialised service from AppState
    if state.context_sync_service is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Context sync service not available",
        )
    return state.context_sync_service


def get_collection_manager_optional(
    state: Annotated[AppState, Depends(get_app_state)],
) -> Optional[CollectionManager]:
    """Return CollectionManager if available (local mode), None in enterprise mode.

    Args:
        state: Application state

    Returns:
        CollectionManager instance, or None in enterprise edition
    """
    if state.collection_manager is None:
        if state.settings and state.settings.edition == "enterprise":
            return None
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Collection manager not available",
        )
    return state.collection_manager


def get_artifact_manager_optional(
    state: Annotated[AppState, Depends(get_app_state)],
) -> Optional[ArtifactManager]:
    """Return ArtifactManager if available (local mode), None in enterprise mode.

    Args:
        state: Application state

    Returns:
        ArtifactManager instance, or None in enterprise edition
    """
    if state.artifact_manager is None:
        if state.settings and state.settings.edition == "enterprise":
            return None
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Artifact manager not available",
        )
    return state.artifact_manager


def get_sync_manager_optional(
    state: Annotated[AppState, Depends(get_app_state)],
) -> Optional[SyncManager]:
    """Return SyncManager if available (local mode), None in enterprise mode.

    Args:
        state: Application state

    Returns:
        SyncManager instance, or None in enterprise edition
    """
    if state.sync_manager is None:
        if state.settings and state.settings.edition == "enterprise":
            return None
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Sync manager not available",
        )
    return state.sync_manager


def get_context_sync_service_optional(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> Optional[IContextSyncService]:
    """Return IContextSyncService if available, None when unavailable.

    In enterprise edition, returns ``EnterpriseContextSyncService`` when
    ``enterprise_sync_enabled`` is ``True``, otherwise returns ``None``
    (callers that use the optional variant tolerate the absence gracefully).

    In local edition, returns the pre-initialised ``LocalContextSyncService``
    from ``AppState``, or raises HTTP 503 if the service failed to initialise.

    Args:
        state: Application state.
        session: Per-request SQLAlchemy session (used in enterprise edition).

    Returns:
        IContextSyncService instance, or None when the feature is disabled.
    """
    if state.settings and state.settings.edition == "enterprise":
        if not state.settings.enterprise_sync_enabled:
            return None
        from skillmeat.core.services.enterprise_context_sync import (
            EnterpriseContextSyncService,
        )

        return EnterpriseContextSyncService(
            session=session,
            settings=state.settings,
        )

    # Local edition
    if state.context_sync_service is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Context sync service not available",
        )
    return state.context_sync_service


def verify_api_key(
    api_key: Annotated[Optional[str], Security(api_key_header)],
    settings: Annotated[APISettings, Depends(get_settings)],
) -> None:
    """Verify API key if authentication is enabled.

    Args:
        api_key: API key from request header
        settings: API settings

    Raises:
        HTTPException: If API key is invalid or missing when required
    """
    # Skip authentication if disabled
    if not settings.api_key_enabled:
        return

    # Check if API key is provided
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key required",
            headers={"WWW-Authenticate": "ApiKey"},
        )

    # Verify API key
    if api_key != settings.api_key:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid API key",
        )


def require_memory_context_enabled(
    settings: Annotated[APISettings, Depends(get_settings)],
) -> None:
    """Legacy no-op dependency retained for backward compatibility."""
    _ = settings
    return


def require_local_edition(
    settings: Annotated[APISettings, Depends(get_settings)],
) -> None:
    """Dependency that blocks enterprise mode for filesystem-only features.

    Use this as a guard on endpoints that rely on local filesystem access and
    have not yet been migrated to enterprise DB backends.  Local mode is
    completely unaffected.

    Raises:
        HTTPException 501: When the configured edition is ``enterprise``.
    """
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="This feature is not yet available in enterprise edition",
        )


def require_bundle_authoring_enabled(
    settings: Annotated[APISettings, Depends(get_settings)],
) -> None:
    """Dependency that raises 404 when the bundle authoring feature flag is disabled.

    Add this as a route-level dependency to gate bundle entity CRUD endpoints
    behind the ``SKILLMEAT_BUNDLE_AUTHORING_ENABLED`` setting.

    Raises:
        HTTPException 404: When ``bundle_authoring_enabled`` is False.
    """
    if not settings.bundle_authoring_enabled:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bundle authoring is not enabled",
        )


def require_sam_telemetry_ingestion_enabled(
    settings: Annotated[APISettings, Depends(get_settings)],
) -> None:
    """Dependency that raises 404 when the SAM telemetry ingestion flag is disabled.

    Add this as a router-level dependency (via ``include_router``) to gate the
    analytics ingestion endpoints behind ``SKILLMEAT_SAM_TELEMETRY_INGESTION_ENABLED``.
    When the flag is off the routes are not reachable (404), preventing accidental
    data submission to an unmonitored endpoint.

    Raises:
        HTTPException 404: When ``sam_telemetry_ingestion_enabled`` is False.
    """
    if not settings.sam_telemetry_ingestion_enabled:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="SAM telemetry ingestion is not enabled",
        )


# ---------------------------------------------------------------------------
# Repository factory providers (hexagonal architecture)
#
# Enterprise Edition Provider Support (ENT2-002/003/ENT2-3.5/ENT2-5.3/ENT2-5.4)
# Supported:   artifact, collection, tag, settings, group, context_entity,
#              project, deployment, deployment_set, deployment_profile,
#              marketplace_source, project_template (stub), marketplace_transaction_handler
# Passthrough: marketplace_catalog (shared read-only cache)
# ---------------------------------------------------------------------------


def get_artifact_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IArtifactRepository:
    """Get IArtifactRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        IArtifactRepository implementation for the configured edition.
        Local edition returns ``LocalArtifactRepository``; enterprise edition
        returns ``EnterpriseArtifactRepository`` (wired directly — no adapter).

    Raises:
        HTTPException: If the configured edition is not supported
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "local":
        from skillmeat.core.repositories import LocalArtifactRepository

        return LocalArtifactRepository(  # type: ignore[return-value]
            artifact_manager=state.artifact_manager,
            path_resolver=state.path_resolver,
        )
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseArtifactRepository,
        )

        return EnterpriseArtifactRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Unsupported edition: {edition}",
    )


def get_project_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IProjectRepository:
    """Get IProjectRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        IProjectRepository implementation for the configured edition.
        Local edition returns ``LocalProjectRepository``; enterprise edition
        returns ``EnterpriseProjectRepository`` (wired directly — no adapter).

    Raises:
        HTTPException: If the configured edition is not supported
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "local":
        from skillmeat.core.repositories import LocalProjectRepository

        return LocalProjectRepository(
            path_resolver=state.path_resolver,
            cache_manager=state.cache_manager,
        )
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseProjectRepository,
        )

        return EnterpriseProjectRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Unsupported edition: {edition}",
    )


def get_collection_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> ICollectionRepository:
    """Get ICollectionRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        ICollectionRepository implementation for the configured edition.
        Local edition returns ``LocalCollectionRepository``; enterprise edition
        returns ``EnterpriseCollectionRepository`` (wired directly — no adapter).

    Raises:
        HTTPException: If the configured edition is not supported
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "local":
        from skillmeat.core.repositories import LocalCollectionRepository

        return LocalCollectionRepository(  # type: ignore[return-value]
            collection_manager=state.collection_manager,
            path_resolver=state.path_resolver,
        )
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseCollectionRepository,
        )

        return EnterpriseCollectionRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Unsupported edition: {edition}",
    )


def get_deployment_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IDeploymentRepository:
    """Get IDeploymentRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        IDeploymentRepository implementation for the configured edition.
        Local edition returns ``LocalDeploymentRepository``; enterprise edition
        returns ``EnterpriseDeploymentRepository`` (wired directly — no adapter).

    Raises:
        HTTPException: If the configured edition is not supported
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "local":
        from skillmeat.core.deployment import DeploymentManager
        from skillmeat.core.repositories import LocalDeploymentRepository

        deployment_manager = DeploymentManager(collection_mgr=state.collection_manager)
        return LocalDeploymentRepository(
            deployment_manager=deployment_manager,
            path_resolver=state.path_resolver,
        )
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseDeploymentRepository,
        )

        return EnterpriseDeploymentRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Unsupported edition: {edition}",
    )


def get_tag_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> ITagRepository:
    """Get ITagRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        ITagRepository implementation for the configured edition.
        Local edition returns ``LocalTagRepository``; enterprise edition
        returns ``EnterpriseTagRepository`` (wired directly — no adapter).

    Raises:
        HTTPException: If the configured edition is not supported
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "local":
        from skillmeat.core.repositories import LocalTagRepository

        return LocalTagRepository()
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import EnterpriseTagRepository

        return EnterpriseTagRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Unsupported edition: {edition}",
    )


def get_settings_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> ISettingsRepository:
    """Get ISettingsRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        ISettingsRepository implementation for the configured edition.
        Local edition returns ``LocalSettingsRepository``; enterprise edition
        returns ``EnterpriseSettingsRepository`` (wired directly — no adapter).

    Raises:
        HTTPException: If the configured edition is not supported
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "local":
        from skillmeat.core.repositories import LocalSettingsRepository

        return LocalSettingsRepository(
            path_resolver=state.path_resolver,
            config_manager=state.config_manager,
        )
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import EnterpriseSettingsRepository

        return EnterpriseSettingsRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Unsupported edition: {edition}",
    )


def get_group_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IGroupRepository:
    """Get IGroupRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        IGroupRepository implementation for the configured edition.
        Local edition returns ``LocalGroupRepository``; enterprise edition
        returns ``EnterpriseGroupRepository`` (wired directly — no adapter).

    Raises:
        HTTPException: If the configured edition is not supported
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "local":
        from skillmeat.core.repositories import LocalGroupRepository

        return LocalGroupRepository()
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import EnterpriseGroupRepository

        return EnterpriseGroupRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Unsupported edition: {edition}",
    )


def get_context_entity_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IContextEntityRepository:
    """Get IContextEntityRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        IContextEntityRepository implementation for the configured edition.
        Local edition returns ``LocalContextEntityRepository``; enterprise
        edition returns ``EnterpriseContextEntityRepository`` (wired directly
        — no adapter).

    Raises:
        HTTPException: If the configured edition is not supported
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "local":
        from skillmeat.core.repositories import LocalContextEntityRepository

        return LocalContextEntityRepository()
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseContextEntityRepository,
        )

        return EnterpriseContextEntityRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Unsupported edition: {edition}",
    )


def get_marketplace_source_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IMarketplaceSourceRepository:
    """Get IMarketplaceSourceRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        IMarketplaceSourceRepository implementation for the configured edition.
        Local edition returns ``LocalMarketplaceSourceRepository``; enterprise
        edition returns ``EnterpriseMarketplaceSourceRepository``.

    Raises:
        HTTPException: If the configured edition is not supported
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "local":
        from skillmeat.core.repositories import LocalMarketplaceSourceRepository

        return LocalMarketplaceSourceRepository()
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseMarketplaceSourceRepository,
        )

        return EnterpriseMarketplaceSourceRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Unsupported edition: {edition}",
    )


def get_project_template_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IProjectTemplateRepository:
    """Get IProjectTemplateRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        IProjectTemplateRepository implementation for the configured edition.
        Local edition returns ``LocalProjectTemplateRepository``; enterprise
        edition returns ``EnterpriseProjectTemplateRepository`` (stub —
        full implementation deferred to v3).

    Raises:
        HTTPException: If the configured edition is not supported
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "local":
        from skillmeat.core.repositories import LocalProjectTemplateRepository

        return LocalProjectTemplateRepository()
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseProjectTemplateRepository,
        )

        return EnterpriseProjectTemplateRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Unsupported edition: {edition}",
    )


def get_deployment_set_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> DeploymentSetRepository:
    """Get DeploymentSetRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        DeploymentSetRepository instance for local edition; enterprise edition
        returns ``EnterpriseDeploymentSetRepository``.
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseDeploymentSetRepository,
        )

        return EnterpriseDeploymentSetRepository(session=session)  # type: ignore[return-value]
    return DeploymentSetRepository()


def get_deployment_profile_repository(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> DeploymentProfileRepository:
    """Get DeploymentProfileRepository dependency.

    Args:
        state: Application state
        session: Per-request SQLAlchemy session (used by enterprise edition)

    Returns:
        DeploymentProfileRepository instance for local edition; enterprise
        edition returns ``EnterpriseDeploymentProfileRepository``.
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseDeploymentProfileRepository,
        )

        return EnterpriseDeploymentProfileRepository(session=session)  # type: ignore[return-value]
    return DeploymentProfileRepository()


def get_marketplace_source_repository_concrete(
    state: Annotated["AppState", Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> MarketplaceSourceRepository:
    """Get concrete MarketplaceSourceRepository dependency.

    # enterprise: routes to EnterpriseMarketplaceSourceRepository (Phase 5)

    Returns the concrete repository when the full set of ORM-level helpers
    (beyond the ``IMarketplaceSourceRepository`` interface) is required — e.g.
    in the marketplace-sources router.  Enterprise edition returns
    ``EnterpriseMarketplaceSourceRepository`` (already implemented in Phase 5).

    Args:
        state: Application state (edition resolution).
        session: Per-request SQLAlchemy session (enterprise path).

    Returns:
        MarketplaceSourceRepository or EnterpriseMarketplaceSourceRepository.
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseMarketplaceSourceRepository,
        )

        return EnterpriseMarketplaceSourceRepository(session=session)  # type: ignore[return-value]
    return MarketplaceSourceRepository()


def get_marketplace_catalog_repository() -> MarketplaceCatalogRepository:
    """Get MarketplaceCatalogRepository dependency.

    Returns a new ``MarketplaceCatalogRepository`` instance.  The repository
    manages its own session lifecycle internally.

    # enterprise: passthrough — shared read-only catalog cache.
    # No edition guard is intentional: the marketplace catalog is a shared,
    # read-only SQLite cache populated by the marketplace import pipeline and
    # consumed identically in both local and enterprise modes.  It is NOT
    # tenant-scoped and does NOT hold user-mutable data, so routing to a
    # separate PostgreSQL-backed implementation would provide no benefit and
    # would break the shared-catalog contract.

    Returns:
        MarketplaceCatalogRepository instance.
    """
    return MarketplaceCatalogRepository()


def get_marketplace_transaction_handler(
    state: Annotated[AppState, Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
    request: Request,
) -> MarketplaceTransactionHandler:
    """Get MarketplaceTransactionHandler dependency.

    Returns a handler for coordinating atomic cross-table marketplace
    operations.  In enterprise mode returns
    ``EnterpriseMarketplaceTransactionHandler`` wired with the per-request
    session and tenant; local mode returns the standard
    ``MarketplaceTransactionHandler``.

    Args:
        state: Application state (used to read the configured edition).
        session: Per-request SQLAlchemy session (enterprise path).
        request: Current FastAPI request (enterprise path reads tenant_id
            from auth context stored on request.state).

    Returns:
        MarketplaceTransactionHandler or EnterpriseMarketplaceTransactionHandler.
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseMarketplaceTransactionHandler,
        )

        auth_ctx: AuthContext | None = getattr(request.state, "auth_context", None)
        tenant_id = (
            auth_ctx.tenant_id
            if auth_ctx is not None and auth_ctx.tenant_id is not None
            else None
        )
        if tenant_id is None:
            from skillmeat.cache.constants import DEFAULT_TENANT_ID

            tenant_id = DEFAULT_TENANT_ID

        return EnterpriseMarketplaceTransactionHandler(  # type: ignore[return-value]
            session=session, tenant_id=tenant_id
        )
    return MarketplaceTransactionHandler()


def get_db_user_collection_repository(
    state: Annotated["AppState", Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IDbUserCollectionRepository:
    """Get an edition-aware IDbUserCollectionRepository dependency.

    In local mode returns a ``DbUserCollectionRepository`` backed by the
    SQLite cache (manages its own session).  In enterprise mode returns an
    ``EnterpriseUserCollectionAdapter`` that wraps the PostgreSQL-backed
    ``EnterpriseCollectionRepository`` and receives the per-request
    ``Session`` from the FastAPI DI layer.

    Args:
        state: Application state (used to read the configured edition).
        session: Per-request SQLAlchemy session (used by the enterprise path).

    Returns:
        IDbUserCollectionRepository implementation appropriate for the
        configured edition.
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseUserCollectionAdapter,
        )

        return EnterpriseUserCollectionAdapter(session=session)
    return DbUserCollectionRepository()


def get_db_collection_artifact_repository(
    state: Annotated["AppState", Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IDbCollectionArtifactRepository:
    """Get IDbCollectionArtifactRepository dependency.

    # enterprise: full — v1 gap, critical for user-collections router

    Returns an edition-aware repository.  Local edition returns
    ``DbCollectionArtifactRepository`` (SQLite, self-managed session);
    enterprise edition returns ``EnterpriseDbCollectionArtifactRepository``
    (PostgreSQL, per-request session).

    Args:
        state: Application state (edition resolution).
        session: Per-request SQLAlchemy session (enterprise path).

    Returns:
        IDbCollectionArtifactRepository implementation for the configured edition.
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseDbCollectionArtifactRepository,
        )

        return EnterpriseDbCollectionArtifactRepository(session=session)  # type: ignore[return-value]
    return DbCollectionArtifactRepository()


def get_duplicate_pair_repository(
    state: Annotated["AppState", Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> DuplicatePairRepository:
    """Get DuplicatePairRepository dependency.

    Returns a new ``DuplicatePairRepository`` instance for local edition.
    Enterprise edition returns ``EnterpriseDuplicatePairRepository`` backed
    by PostgreSQL (replaces the former ``EnterpriseDuplicatePairStub``).

    Args:
        state: Application state (edition resolution).
        session: Per-request SQLAlchemy session (used by the enterprise path).

    Returns:
        DuplicatePairRepository instance or enterprise implementation.
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseDuplicatePairRepository,
        )

        return EnterpriseDuplicatePairRepository(session=session)  # type: ignore[return-value]
    return DuplicatePairRepository()


# Type aliases for cleaner dependency injection
ConfigManagerDep = Annotated[ConfigManager, Depends(get_config_manager)]
CollectionManagerDep = Annotated[CollectionManager, Depends(get_collection_manager)]
ArtifactManagerDep = Annotated[ArtifactManager, Depends(get_artifact_manager)]
TokenManagerDep = Annotated[TokenManager, Depends(get_token_manager)]
SyncManagerDep = Annotated[SyncManager, Depends(get_sync_manager)]
ContextSyncServiceDep = Annotated[
    IContextSyncService, Depends(get_context_sync_service)
]
CollectionManagerOptDep = Annotated[
    Optional[CollectionManager], Depends(get_collection_manager_optional)
]
ArtifactManagerOptDep = Annotated[
    Optional[ArtifactManager], Depends(get_artifact_manager_optional)
]
SyncManagerOptDep = Annotated[Optional[SyncManager], Depends(get_sync_manager_optional)]
ContextSyncServiceOptDep = Annotated[
    Optional[IContextSyncService], Depends(get_context_sync_service_optional)
]
SettingsDep = Annotated[APISettings, Depends(get_settings)]
APIKeyDep = Annotated[None, Depends(verify_api_key)]
MemoryContextEnabledDep = Annotated[None, Depends(require_memory_context_enabled)]
LocalEditionDep = Annotated[None, Depends(require_local_edition)]
BundleAuthoringEnabledDep = Annotated[None, Depends(require_bundle_authoring_enabled)]


def get_bundle_repository(
    settings: Annotated[APISettings, Depends(get_settings)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IBundleRepository:
    """Get IBundleRepository dependency.

    Args:
        settings: API settings (used to read the configured edition).
        session: Per-request SQLAlchemy session.

    Returns:
        IBundleRepository implementation for the configured edition.
        Local edition returns ``LocalBundleRepository``; enterprise edition
        returns ``EnterpriseBundleRepository``.
    """
    if settings.edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseBundleRepository,
        )

        return EnterpriseBundleRepository(session=session)  # type: ignore[return-value]
    from skillmeat.core.repositories.local_bundle_repository import (
        LocalBundleRepository,
    )

    return LocalBundleRepository(session=session)


def get_workflow_repository(
    settings: Annotated[APISettings, Depends(get_settings)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IWorkflowRepository:
    """Get IWorkflowRepository dependency.

    Args:
        settings: API settings (used to read the configured edition).
        session: Per-request SQLAlchemy session (enterprise path only).

    Returns:
        EnterpriseWorkflowRepository in enterprise edition.

    Raises:
        HTTPException: 501 Not Implemented in local edition (no local
            workflow repository exists).
    """
    if settings.edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseWorkflowRepository,
        )

        return EnterpriseWorkflowRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Workflow operations require enterprise edition",
    )


def get_memory_item_repository(
    settings: Annotated[APISettings, Depends(get_settings)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IMemoryItemRepository:
    """Get IMemoryItemRepository dependency.

    Args:
        settings: API settings (used to read the configured edition).
        session: Per-request SQLAlchemy session (enterprise path only).

    Returns:
        EnterpriseMemoryItemRepository in enterprise edition.

    Raises:
        HTTPException: 501 Not Implemented in local edition (no local
            memory item repository exists).
    """
    if settings.edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseMemoryItemRepository,
        )

        return EnterpriseMemoryItemRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Memory item operations require enterprise edition",
    )


def get_bom_repository(
    settings: Annotated[APISettings, Depends(get_settings)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IBomRepository:
    """Get IBomRepository dependency.

    Args:
        settings: API settings (used to read the configured edition).
        session: Per-request SQLAlchemy session (enterprise path only).

    Returns:
        EnterpriseBomRepository in enterprise edition.

    Raises:
        HTTPException: 501 Not Implemented in local edition (no local
            BOM repository exists).
    """
    if settings.edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseBomRepository,
        )

        return EnterpriseBomRepository(session=session)  # type: ignore[return-value]
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="BOM operations require enterprise edition",
    )


def get_context_entity_category_repository(
    settings: Annotated[APISettings, Depends(get_settings)],
    session: Annotated[Session, Depends(get_db_session)],
) -> Optional[Any]:
    """Provide context entity category repository based on edition.

    Args:
        settings: API settings (used to read the configured edition).
        session: Per-request SQLAlchemy session (used by enterprise path).

    Returns:
        EnterpriseContextEntityCategoryRepository in enterprise edition, else None.
        Local edition has no category support.
    """
    if settings.edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseContextEntityCategoryRepository,
        )

        return EnterpriseContextEntityCategoryRepository(session=session)
    # Local edition: return None (no category support in local mode)
    return None


def get_artifact_history_event_repository(
    settings: Annotated[APISettings, Depends(get_settings)],
    session: Annotated[Session, Depends(get_db_session)],
) -> Optional[IArtifactActivityRepository]:
    """Provide artifact history event repository based on edition.

    Args:
        settings: API settings (used to read the configured edition).
        session: Per-request SQLAlchemy session (used by enterprise path).

    Returns:
        EnterpriseArtifactHistoryEventRepository in enterprise edition, else None.
        Local edition has no audit history support.
    """
    if settings.edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseArtifactHistoryEventRepository,
        )

        return EnterpriseArtifactHistoryEventRepository(session=session)
    # Local edition: return None (no audit history in local mode)
    return None


# Repository DI aliases (hexagonal architecture)
ArtifactRepoDep = Annotated[IArtifactRepository, Depends(get_artifact_repository)]
ProjectRepoDep = Annotated[IProjectRepository, Depends(get_project_repository)]
CollectionRepoDep = Annotated[ICollectionRepository, Depends(get_collection_repository)]
DeploymentRepoDep = Annotated[IDeploymentRepository, Depends(get_deployment_repository)]
TagRepoDep = Annotated[ITagRepository, Depends(get_tag_repository)]
SettingsRepoDep = Annotated[ISettingsRepository, Depends(get_settings_repository)]
GroupRepoDep = Annotated[IGroupRepository, Depends(get_group_repository)]
ContextEntityRepoDep = Annotated[
    IContextEntityRepository, Depends(get_context_entity_repository)
]
MarketplaceSourceRepoDep = Annotated[
    IMarketplaceSourceRepository, Depends(get_marketplace_source_repository)
]
ProjectTemplateRepoDep = Annotated[
    IProjectTemplateRepository, Depends(get_project_template_repository)
]
DeploymentSetRepoDep = Annotated[
    DeploymentSetRepository, Depends(get_deployment_set_repository)
]
DeploymentProfileRepoDep = Annotated[
    DeploymentProfileRepository, Depends(get_deployment_profile_repository)
]
MarketplaceCatalogRepoDep = Annotated[
    MarketplaceCatalogRepository, Depends(get_marketplace_catalog_repository)
]
DuplicatePairRepoDep = Annotated[
    DuplicatePairRepository, Depends(get_duplicate_pair_repository)
]
# Concrete MarketplaceSourceRepository (vs IMarketplaceSourceRepository interface).
# Use this in marketplace_sources router which requires methods beyond the interface.
MarketplaceSourceConcreteRepoDep = Annotated[
    MarketplaceSourceRepository, Depends(get_marketplace_source_repository_concrete)
]
MarketplaceTransactionHandlerDep = Annotated[
    MarketplaceTransactionHandler, Depends(get_marketplace_transaction_handler)
]
DbUserCollectionRepoDep = Annotated[
    IDbUserCollectionRepository, Depends(get_db_user_collection_repository)
]
DbCollectionArtifactRepoDep = Annotated[
    IDbCollectionArtifactRepository, Depends(get_db_collection_artifact_repository)
]
BundleRepoDep = Annotated[IBundleRepository, Depends(get_bundle_repository)]
WorkflowRepoDep = Annotated[IWorkflowRepository, Depends(get_workflow_repository)]
MemoryItemRepoDep = Annotated[
    IMemoryItemRepository, Depends(get_memory_item_repository)
]
BomRepoDep = Annotated[IBomRepository, Depends(get_bom_repository)]
ContextEntityCategoryRepoDep = Annotated[
    Optional[Any], Depends(get_context_entity_category_repository)
]
ArtifactHistoryEventRepoDep = Annotated[
    Optional[IArtifactActivityRepository],
    Depends(get_artifact_history_event_repository),
]


def get_enterprise_file_content_service(
    settings: Annotated[APISettings, Depends(get_settings)],
    session: Annotated[Session, Depends(get_db_session)],
) -> Optional[Any]:  # EnterpriseFileContentService | None
    """Return EnterpriseFileContentService for enterprise edition, None otherwise.

    Instantiated per-request with the injected SQLAlchemy session.  Returns
    ``None`` in local edition so callers can guard with a simple ``if service``
    check.

    Args:
        settings: API settings (used to read the configured edition).
        session: Per-request SQLAlchemy session (enterprise path only).

    Returns:
        EnterpriseFileContentService instance in enterprise edition, else None.
    """
    if settings.edition != "enterprise":
        return None
    from skillmeat.core.services.enterprise_file_content import (
        EnterpriseFileContentService,
    )

    return EnterpriseFileContentService(session=session)


EnterpriseFileContentServiceDep = Annotated[
    Optional[
        Any
    ],  # EnterpriseFileContentService | None — lazy import avoids circular deps
    Depends(get_enterprise_file_content_service),
]


# ---------------------------------------------------------------------------
# Membership + Ownership DI chain
# ---------------------------------------------------------------------------


def get_membership_repository(
    request: Request,
    session: Annotated[Session, Depends(get_db_session)],
) -> IMembershipRepository:
    """Return edition-appropriate membership repository.

    Reads the auth context already stored on ``request.state`` by the
    router-level ``require_auth`` dependency.  When ``auth_context.tenant_id``
    is present the request is running in enterprise mode and the enterprise
    implementation is returned.  Otherwise the local implementation is used.

    Args:
        request: The current FastAPI request (auth_context read from state).
        session: Per-request SQLAlchemy session for enterprise repositories.

    Returns:
        :class:`~skillmeat.core.repositories.enterprise_membership.EnterpriseMembershipRepository`
        when ``tenant_id`` is set on the auth context;
        :class:`~skillmeat.core.repositories.local_membership.LocalMembershipRepository`
        otherwise.
    """
    auth_ctx: AuthContext | None = getattr(request.state, "auth_context", None)
    tenant_id = auth_ctx.tenant_id if auth_ctx is not None else None

    if tenant_id is not None:
        from skillmeat.core.repositories.enterprise_membership import (
            EnterpriseMembershipRepository,
        )

        return EnterpriseMembershipRepository(session=session)

    from skillmeat.core.repositories.local_membership import LocalMembershipRepository

    return LocalMembershipRepository()


def get_ownership_resolver(
    membership_repo: Annotated[
        IMembershipRepository, Depends(get_membership_repository)
    ],
) -> OwnershipResolver:
    """Return an :class:`~skillmeat.core.services.ownership_resolver.OwnershipResolver`.

    Args:
        membership_repo: Edition-appropriate membership repository.

    Returns:
        A new :class:`~skillmeat.core.services.ownership_resolver.OwnershipResolver`
        wired with the provided membership repository.
    """
    return OwnershipResolver(membership_repo)


async def get_resolved_ownership(
    auth_context: Annotated[AuthContext, Depends(get_auth_context)],
    resolver: Annotated[OwnershipResolver, Depends(get_ownership_resolver)],
) -> ResolvedOwnership:
    """Resolve and return the full ownership context for the current request.

    Combines the authenticated :class:`~skillmeat.api.schemas.auth.AuthContext`
    with membership lookups to produce a
    :class:`~skillmeat.core.ownership.ResolvedOwnership` that encodes all
    readable and writable owner scopes for this request.

    Args:
        auth_context: Authenticated request context (from ``get_auth_context``).
        resolver: Ownership resolver wired with the correct membership repository.

    Returns:
        :class:`~skillmeat.core.ownership.ResolvedOwnership` instance.
    """
    return resolver.resolve(auth_context)


#: Pre-built ``Annotated`` alias for routes that need the resolved ownership context.
ResolvedOwnershipDep = Annotated[ResolvedOwnership, Depends(get_resolved_ownership)]


# ---------------------------------------------------------------------------
# get_ownership_context — EG-2 ResolvedOwnershipContext dependency
# ---------------------------------------------------------------------------


async def get_ownership_context(
    auth: AuthContext = Depends(require_auth()),
    session: Session = Depends(get_db_session),
    settings: APISettings = Depends(get_settings),
) -> ResolvedOwnershipContext:
    """Resolve ownership context for the current authenticated user.

    Provides :class:`~skillmeat.core.auth.ownership_context.ResolvedOwnershipContext`
    with team memberships, allowed owner types, and default ownership scope.
    Called once per request.

    The implementation selects the edition-appropriate
    :class:`~skillmeat.core.auth.membership_repository.IMembershipRepository`
    (``LocalMembershipRepository`` for ``local`` edition,
    ``EnterpriseMembershipRepository`` for ``enterprise`` edition) and wires it
    into :class:`~skillmeat.core.auth.ownership_resolver.OwnershipResolver`.

    Args:
        auth: Authenticated request context from ``require_auth()``.
        session: Per-request SQLAlchemy session.
        settings: API settings (edition field determines repo selection).

    Returns:
        :class:`~skillmeat.core.auth.ownership_context.ResolvedOwnershipContext`
        with all resolved ownership data for the caller.
    """
    from skillmeat.core.auth.membership_repository import (
        EnterpriseMembershipRepository,
        LocalMembershipRepository,
    )
    from skillmeat.core.auth.ownership_resolver import (
        OwnershipResolver as _OwnershipResolver,
    )

    edition = settings.edition  # "local" or "enterprise"

    if edition == "enterprise":
        membership_repo = EnterpriseMembershipRepository(session)
    else:
        membership_repo = LocalMembershipRepository(session)

    resolver = _OwnershipResolver(membership_repo=membership_repo, edition=edition)
    return resolver.resolve(auth)


#: Pre-built ``Annotated`` alias for routes that need the EG-2
#: ``ResolvedOwnershipContext`` (team memberships, allowed owner types,
#: default ownership scope).  Resolves once per request.
OwnershipContextDep = Annotated[
    ResolvedOwnershipContext, Depends(get_ownership_context)
]


def get_db_artifact_history_repository(
    state: Annotated["AppState", Depends(get_app_state)],
    session: Annotated[Session, Depends(get_db_session)],
) -> IDbArtifactHistoryRepository:
    """Get IDbArtifactHistoryRepository dependency.

    Returns a new ``DbArtifactHistoryRepository`` instance for local edition.
    Enterprise edition returns ``EnterpriseArtifactHistoryRepository`` backed
    by PostgreSQL (replaces the former ``EnterpriseArtifactHistoryStub``).

    Args:
        state: Application state (edition resolution).
        session: Per-request SQLAlchemy session (used by the enterprise path).

    Returns:
        IDbArtifactHistoryRepository implementation for the configured edition.
    """
    edition = state.settings.edition if state.settings else "local"
    if edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseArtifactHistoryRepository,
        )

        return EnterpriseArtifactHistoryRepository(session=session)
    return DbArtifactHistoryRepository()


DbArtifactHistoryRepoDep = Annotated[
    IDbArtifactHistoryRepository, Depends(get_db_artifact_history_repository)
]

# Per-request SQLAlchemy session (hexagonal architecture)
DbSessionDep = Annotated[Session, Depends(get_db_session)]


# ---------------------------------------------------------------------------
# Git Repo Connector DI providers (GRC Phase 2)
# ---------------------------------------------------------------------------


def get_git_connection_repo(
    session: Session = Depends(get_db_session),
    settings: APISettings = Depends(get_settings),
) -> IGitRepoConnectionRepository:
    """FastAPI dependency that returns the active ``IGitRepoConnectionRepository``.

    Routes to the local SQLite implementation for the ``"local"`` edition and
    to the enterprise PostgreSQL implementation for the ``"enterprise"`` edition.

    Args:
        session: Per-request SQLAlchemy session (used for enterprise edition).
        settings: API settings (edition field drives implementation selection).

    Returns:
        ``IGitRepoConnectionRepository`` implementation for the configured edition.
    """
    from skillmeat.cache.repository_factory import RepositoryFactory

    edition = settings.edition if settings else "local"
    return RepositoryFactory(edition=edition).get_git_repo_connection_repository(
        session=session
    )


#: Pre-built ``Annotated`` alias for routes that need a Git connection repository.
GitConnectionRepoDep = Annotated[
    IGitRepoConnectionRepository, Depends(get_git_connection_repo)
]


def get_git_scan_repo(
    session: Session = Depends(get_db_session),
    settings: APISettings = Depends(get_settings),
) -> IGitRepoScanRepository:
    """FastAPI dependency that returns the active ``IGitRepoScanRepository``.

    Routes to the local SQLite implementation for the ``"local"`` edition and
    to the enterprise PostgreSQL implementation for the ``"enterprise"`` edition.

    Args:
        session: Per-request SQLAlchemy session (used for enterprise edition).
        settings: API settings (edition field drives implementation selection).

    Returns:
        ``IGitRepoScanRepository`` implementation for the configured edition.
    """
    from skillmeat.cache.repository_factory import RepositoryFactory

    edition = settings.edition if settings else "local"
    return RepositoryFactory(edition=edition).get_git_repo_scan_repository(
        session=session
    )


#: Pre-built ``Annotated`` alias for routes that need a Git scan repository.
GitScanRepoDep = Annotated[IGitRepoScanRepository, Depends(get_git_scan_repo)]


def get_git_scan_artifact_repo(
    session: Session = Depends(get_db_session),
    settings: APISettings = Depends(get_settings),
) -> IGitScanArtifactRepository:
    """FastAPI dependency that returns the active ``IGitScanArtifactRepository``.

    Routes to the local SQLite implementation for the ``"local"`` edition and
    to the enterprise PostgreSQL implementation for the ``"enterprise"`` edition.

    Args:
        session: Per-request SQLAlchemy session (used for enterprise edition).
        settings: API settings (edition field drives implementation selection).

    Returns:
        ``IGitScanArtifactRepository`` implementation for the configured edition.
    """
    from skillmeat.cache.repository_factory import RepositoryFactory

    edition = settings.edition if settings else "local"
    return RepositoryFactory(edition=edition).get_git_scan_artifact_repository(
        session=session
    )


#: Pre-built ``Annotated`` alias for routes that need a Git scan artifact repository.
GitScanArtifactRepoDep = Annotated[
    IGitScanArtifactRepository, Depends(get_git_scan_artifact_repo)
]


def get_project_git_connection_repo(
    session: Session = Depends(get_db_session),
    settings: APISettings = Depends(get_settings),
) -> IProjectGitConnectionRepository:
    """FastAPI dependency that returns the active ``IProjectGitConnectionRepository``.

    Routes to the local SQLite implementation for the ``"local"`` edition and
    to the enterprise PostgreSQL implementation for the ``"enterprise"`` edition.

    Args:
        session: Per-request SQLAlchemy session (used for enterprise edition).
        settings: API settings (edition field drives implementation selection).

    Returns:
        ``IProjectGitConnectionRepository`` implementation for the configured edition.
    """
    from skillmeat.cache.repository_factory import RepositoryFactory

    edition = settings.edition if settings else "local"
    return RepositoryFactory(edition=edition).get_project_git_connection_repository(
        session=session
    )


#: Pre-built ``Annotated`` alias for routes that need a project↔git-connection repository.
ProjectGitConnectionRepoDep = Annotated[
    IProjectGitConnectionRepository, Depends(get_project_git_connection_repo)
]


# ---------------------------------------------------------------------------
# GitCredentialRepository DI provider (GCD Phase 2 — GCD-2.10)
# ---------------------------------------------------------------------------


def get_credential_repo(
    session: Session = Depends(get_db_session),
    settings: APISettings = Depends(get_settings),
    request: Request = None,  # type: ignore[assignment]
) -> IGitCredentialRepository:
    """FastAPI dependency that returns the active ``IGitCredentialRepository``.

    Routes to the local SQLite implementation (``LocalGitCredentialRepository``)
    for the ``"local"`` edition and to the enterprise PostgreSQL implementation
    (``EnterpriseGitCredentialRepository``) for the ``"enterprise"`` edition.

    For enterprise edition, ``tenant_id`` is resolved from the auth context
    stored on ``request.state`` (set by ``TenantContextMiddleware``).  When no
    auth context is present the ``DEFAULT_TENANT_ID`` sentinel is used as a
    safe fallback, consistent with other enterprise DI providers.

    Args:
        session: Per-request SQLAlchemy session (used for enterprise edition).
        settings: API settings (``edition`` field drives implementation selection).
        request: Current FastAPI request (enterprise path reads ``tenant_id``
            from auth context stored on ``request.state``).

    Returns:
        ``IGitCredentialRepository`` implementation for the configured edition.
    """
    edition = settings.edition if settings else "local"
    if edition == "enterprise":
        from skillmeat.cache.constants import DEFAULT_TENANT_ID
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseGitCredentialRepository,
        )

        auth_ctx: AuthContext | None = (
            getattr(request.state, "auth_context", None)
            if request is not None
            else None
        )
        tenant_id = (
            auth_ctx.tenant_id
            if auth_ctx is not None and auth_ctx.tenant_id is not None
            else DEFAULT_TENANT_ID
        )
        return EnterpriseGitCredentialRepository(session=session, tenant_id=tenant_id)

    from skillmeat.cache.repositories import LocalGitCredentialRepository

    return LocalGitCredentialRepository()


#: Pre-built ``Annotated`` alias for routes that need a git credential repository.
GitCredentialRepoDep = Annotated[IGitCredentialRepository, Depends(get_credential_repo)]


# ---------------------------------------------------------------------------
# TokenResolverService DI provider (GCD Phase 2 — GCD-2.10)
# ---------------------------------------------------------------------------


def get_token_resolver(
    credential_repo: IGitCredentialRepository = Depends(get_credential_repo),
    connection_repo: IProjectGitConnectionRepository = Depends(
        get_project_git_connection_repo
    ),
) -> Any:
    """FastAPI dependency that constructs a ``TokenResolverService`` instance.

    The service is stateless after construction — all state lives in the
    injected repositories — so it is safe to create a fresh instance per
    request.

    Args:
        credential_repo: Injected ``IGitCredentialRepository`` implementation.
        connection_repo: Injected ``IProjectGitConnectionRepository``
            implementation (provides connection-level ``access_token`` lookup
            at resolver level 3).

    Returns:
        Configured ``TokenResolverService`` ready for use by the calling route.
    """
    from skillmeat.core.services.token_resolver import TokenResolverService

    return TokenResolverService(
        credential_repo=credential_repo,
        connection_repo=connection_repo,
    )


#: Pre-built ``Annotated`` alias for routes that need the token resolver service.
#: The concrete type is ``skillmeat.core.services.token_resolver.TokenResolverService``.
TokenResolverServiceDep = Annotated[Any, Depends(get_token_resolver)]


# ---------------------------------------------------------------------------
# GitRepoScanService DI provider (GRC Phase 2)
# ---------------------------------------------------------------------------


def get_git_repo_scan_service(
    conn_repo: GitConnectionRepoDep,
    scan_repo: GitScanRepoDep,
    artifact_repo: GitScanArtifactRepoDep,
) -> Any:
    """FastAPI dependency that constructs a ``GitRepoScanService`` instance.

    The service is stateless — all state lives in the injected repositories —
    so it is safe to create a fresh instance per request.

    Args:
        conn_repo: Injected ``IGitRepoConnectionRepository`` implementation.
        scan_repo: Injected ``IGitRepoScanRepository`` implementation.
        artifact_repo: Injected ``IGitScanArtifactRepository`` implementation.

    Returns:
        Configured ``GitRepoScanService`` ready for use by the calling route.
    """
    from skillmeat.core.git_repo_scan_service import GitRepoScanService

    return GitRepoScanService(
        connection_repo=conn_repo,
        scan_repo=scan_repo,
        artifact_repo=artifact_repo,
    )


#: Pre-built ``Annotated`` alias for routes that need the Git repo scan service.
#: The concrete type is ``skillmeat.core.git_repo_scan_service.GitRepoScanService``.
GitRepoScanServiceDep = Annotated[Any, Depends(get_git_repo_scan_service)]


# ---------------------------------------------------------------------------
# Resolved artifact ID dependency (enterprise UUID resolution)
# ---------------------------------------------------------------------------


async def _resolve_artifact_id(
    artifact_id: str,
    settings: Annotated[APISettings, Depends(get_settings)],
    artifact_repo: Annotated[IArtifactRepository, Depends(get_artifact_repository)],
) -> str:
    """FastAPI dependency: resolve ``artifact_id`` path param to enterprise UUID.

    Wraps :func:`skillmeat.api.routers.artifacts._helpers.resolve_enterprise_artifact_id`
    with FastAPI dependency injection so route signatures stay clean.

    In **local** mode the raw *artifact_id* (``type:name``) is returned
    unchanged.  In **enterprise** mode the composite ID is resolved to a UUID
    hex string via ``artifact_repo.resolve_uuid_by_id()``.

    Usage::

        @router.get("/{artifact_id}")
        async def get_artifact(
            artifact_id: ResolvedArtifactIdDep,
            ...
        ) -> ArtifactResponse:
            # artifact_id is already a UUID string in enterprise mode
            ...

    Raises:
        HTTPException 404: When in enterprise mode and the artifact cannot be
            resolved.
    """
    from skillmeat.api.routers.artifacts._helpers import resolve_enterprise_artifact_id

    return await resolve_enterprise_artifact_id(
        artifact_id=artifact_id,
        settings=settings,
        artifact_repo=artifact_repo,
    )


#: Pre-built ``Annotated`` alias that resolves ``{artifact_id}`` path
#: parameters to enterprise UUIDs in enterprise edition, or passes them
#: through unchanged in local edition.
#:
#: Drop-in replacement for ``artifact_id: str`` on any route that currently
#: receives a ``type:name`` path param and needs a UUID for downstream
#: enterprise repository calls.
ResolvedArtifactIdDep = Annotated[str, Depends(_resolve_artifact_id)]


# ---------------------------------------------------------------------------
# EnterpriseContext — shared tenant/org context dependency
# ---------------------------------------------------------------------------


def resolve_enterprise_context(
    auth: AuthContextDep,
    session: Annotated[Session, Depends(get_db_session)],
) -> EnterpriseContext:
    """Derive enterprise tenant and org context from auth.

    Resolution order:
    1. auth.tenant_id from JWT (enterprise mode)
    2. DEFAULT_TENANT_ID fallback (local/dev mode when auth.tenant_id is None)

    org_id is looked up from EnterpriseSettings for the resolved tenant.
    Falls back to tenant_id as org_id when no EnterpriseSettings row exists
    (fresh dev DB, local mode, or testing scenarios).
    """
    from skillmeat.cache.constants import DEFAULT_TENANT_ID

    tenant_id = auth.tenant_id if auth.tenant_id is not None else DEFAULT_TENANT_ID

    # Look up canonical org_id from enterprise_settings
    try:
        from skillmeat.cache.models_enterprise import EnterpriseSettings

        row = session.query(EnterpriseSettings).filter_by(tenant_id=tenant_id).first()
        org_id = row.id if row is not None else tenant_id
    except Exception:
        # DB not available or table doesn't exist (local edition) — safe fallback
        org_id = tenant_id

    return EnterpriseContext(tenant_id=tenant_id, org_id=org_id)


#: Pre-built ``Annotated`` alias for routes that need enterprise tenant and org
#: context derived from auth.  Safe for all editions — falls back to
#: ``DEFAULT_TENANT_ID`` / tenant-as-org-id when running in local mode.
EnterpriseContextDep = Annotated[EnterpriseContext, Depends(resolve_enterprise_context)]


def get_scaffold_template_service(
    settings: Annotated[APISettings, Depends(get_settings)],
    session: Annotated[Session, Depends(get_db_session)],
) -> "ScaffoldTemplateService":
    """Return a wired ScaffoldTemplateService for the configured edition.

    Args:
        settings: API settings (used to read the configured edition).
        session: Per-request SQLAlchemy session (enterprise path only).

    Returns:
        ScaffoldTemplateService backed by:
        - ``EnterpriseScaffoldTemplateRepository`` in enterprise edition.
        - ``ScaffoldTemplateRepository`` (local SQLite) in local edition.
    """
    from skillmeat.core.services.scaffold_template_service import (
        ScaffoldTemplateService,
    )
    from skillmeat.core.services.template_generator import TemplateGenerator

    if settings.edition == "enterprise":
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseScaffoldTemplateRepository,
        )

        return ScaffoldTemplateService(
            repository=EnterpriseScaffoldTemplateRepository(session=session),
            generator=TemplateGenerator(),
        )

    from skillmeat.cache.scaffold_template_repository import ScaffoldTemplateRepository

    return ScaffoldTemplateService(
        repository=ScaffoldTemplateRepository(),
        generator=TemplateGenerator(),
    )
