"""Pydantic schemas for Git Repository Connector API endpoints (GRC).

Defines request/response models for git connection CRUD, scan lifecycle,
webhook reception, and artifact indexing endpoints.  All schemas use
Pydantic v2 style.

Schema Groups:
    - GitRepoConnectionCreate: POST body for registering a new connection.
    - GitRepoConnectionResponse: Read-only response (webhook_secret excluded).
    - GitRepoConnectionUpdate: PATCH body (all fields optional).
    - GitRepoScanResponse: Scan record with aggregate counters.
    - GitScanArtifactResponse: Individual artifact observation from a scan.
    - ScanTriggerRequest: POST body for triggering a scan manually.
    - ScanTriggerResponse: Immediate response after scan is queued.
    - IndexScanRequest: POST body for indexing a subset of scan artifacts.
"""

from __future__ import annotations

from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

# =============================================================================
# Connection schemas
# =============================================================================


class GitRepoConnectionCreate(BaseModel):
    """Request body for registering a new Git repository connection.

    The ``webhook_secret`` field, when supplied, is stored encrypted and is
    NEVER included in any response payload.

    Attributes:
        repo_url:       GitHub repository URL (HTTPS/SSH) or ``owner/repo``
                        shorthand.
        branch:         Branch to scan; defaults to ``"main"``.
        project_id:     Owning project identifier (FK to projects.id).
        developer_id:   Optional developer user ID.
        webhook_secret: Optional HMAC secret for validating webhook push
                        events.  Write-only — never returned in responses.
        scan_schedule:  Reserved for future cron expression.
        is_active:      When ``False`` the connection is created but paused.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "repo_url": "anthropics/claude-code-skills",
                "branch": "main",
                "project_id": "proj:my-project",
                "developer_id": None,
                "webhook_secret": "s3cr3t-hmac-key",
                "scan_schedule": None,
                "is_active": True,
            }
        }
    )

    repo_url: str = Field(
        description=(
            "GitHub repository URL (HTTPS or SSH) or ``owner/repo`` shorthand. "
            "Example: ``'anthropics/claude-code-skills'`` or "
            "``'https://github.com/anthropics/claude-code-skills'``."
        ),
        examples=["anthropics/claude-code-skills"],
    )
    branch: str = Field(
        default="main",
        description="Branch to scan.  Defaults to ``'main'``.",
        examples=["main"],
    )
    project_id: Optional[str] = Field(
        default=None,
        description="Optional legacy project identifier. Connections are now linked to projects via the join table.",
        examples=["proj:my-project"],
    )
    developer_id: Optional[int] = Field(
        default=None,
        description="Optional integer ID of the developer user who owns this connection.",
        examples=[42],
    )
    webhook_secret: Optional[str] = Field(
        default=None,
        description=(
            "Optional HMAC secret for validating incoming GitHub webhook push events. "
            "Write-only — never included in response payloads."
        ),
        examples=["s3cr3t-hmac-key"],
    )
    scan_schedule: Optional[str] = Field(
        default=None,
        description=(
            "Reserved for future use: cron expression for scheduled scans "
            "(e.g. ``'0 * * * *'`` for hourly).  Currently ignored by the scheduler."
        ),
        examples=["0 * * * *"],
    )
    is_active: bool = Field(
        default=True,
        description="When ``False`` the connection is registered but paused (no scans run).",
        examples=[True],
    )


class GitRepoConnectionResponse(BaseModel):
    """Response schema for a Git repository connection.

    The ``webhook_secret`` field is intentionally absent to prevent
    inadvertent secret exposure via API responses.

    Attributes:
        id:            Integer primary key.
        repo_url:      Registered repository URL.
        branch:        Configured scan branch.
        project_id:    Owning project identifier.
        developer_id:  Owning developer user ID (nullable).
        scan_schedule: Cron expression for scheduled scans (nullable).
        is_active:     Whether the connection is active.
        last_scan_at:  UTC timestamp of the most recent completed scan.
        created_at:    UTC creation timestamp.
        created_by:    User ID who registered the connection (nullable).
    """

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": {
                "id": 1,
                "repo_url": "anthropics/claude-code-skills",
                "branch": "main",
                "project_id": "proj:my-project",
                "developer_id": None,
                "scan_schedule": None,
                "is_active": True,
                "last_scan_at": None,
                "created_at": "2026-03-01T10:00:00Z",
                "created_by": None,
            }
        },
    )

    id: int = Field(description="Integer primary key.", examples=[1])
    repo_url: str = Field(
        description="Registered GitHub repository URL.",
        examples=["anthropics/claude-code-skills"],
    )
    branch: str = Field(
        description="Branch that is scanned.",
        examples=["main"],
    )
    project_id: Optional[str] = Field(
        description="Owning project identifier.",
        examples=["proj:my-project"],
    )
    developer_id: Optional[int] = Field(
        default=None,
        description="Owning developer user ID.",
        examples=[42],
    )
    scan_schedule: Optional[str] = Field(
        default=None,
        description="Cron expression for scheduled scans (reserved for future use).",
        examples=["0 * * * *"],
    )
    is_active: bool = Field(
        description="Whether the connection is active and eligible for scanning.",
        examples=[True],
    )
    last_scan_at: Optional[datetime] = Field(
        default=None,
        description="UTC timestamp of the most recently completed scan.",
        examples=["2026-03-15T08:30:00Z"],
    )
    created_at: datetime = Field(
        description="UTC timestamp when the connection was registered.",
        examples=["2026-03-01T10:00:00Z"],
    )
    created_by: Optional[int] = Field(
        default=None,
        description="User ID of the user who registered this connection.",
        examples=[1],
    )


class GitRepoConnectionUpdate(BaseModel):
    """PATCH request body for updating a Git repository connection.

    All fields are optional.  Only supplied fields are updated.

    The ``webhook_secret`` field is write-only — supplying it replaces the
    stored secret.  It is never included in response payloads.

    Attributes:
        branch:         New branch to scan.
        is_active:      Enable or pause the connection.
        scan_schedule:  Updated cron expression (reserved).
        webhook_secret: Replacement HMAC secret (write-only).
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "branch": "develop",
                "is_active": True,
                "scan_schedule": None,
                "webhook_secret": "new-s3cr3t",
            }
        }
    )

    branch: Optional[str] = Field(
        default=None,
        description="New branch to scan.",
        examples=["develop"],
    )
    is_active: Optional[bool] = Field(
        default=None,
        description="Enable (``True``) or pause (``False``) the connection.",
        examples=[True],
    )
    scan_schedule: Optional[str] = Field(
        default=None,
        description="Replacement cron expression for scheduled scans (reserved).",
        examples=["0 6 * * *"],
    )
    webhook_secret: Optional[str] = Field(
        default=None,
        description=(
            "Replacement HMAC secret for webhook validation.  Write-only — "
            "never returned in response payloads."
        ),
        examples=["new-s3cr3t"],
    )


# =============================================================================
# Scan schemas
# =============================================================================


class GitRepoScanResponse(BaseModel):
    """Response schema for a single Git repository scan record.

    Captures the full lifecycle of one scan run, from creation through
    completion (or failure), plus aggregate artifact counters.  When
    returned by the ``GET /scans/{scan_id}`` endpoint the ``artifacts``
    list is populated with the individual observations; list endpoints
    omit artifacts and leave the field as an empty list.

    Attributes:
        id:                 Integer primary key.
        connection_id:      FK to the parent GitRepoConnection.
        triggered_by:       How the scan was initiated.
        trigger_sha:        Git commit SHA that triggered the scan (nullable).
        status:             Current lifecycle state.
        started_at:         UTC timestamp when the worker started (nullable).
        completed_at:       UTC timestamp when the scan finished (nullable).
        created_at:         UTC creation timestamp.
        artifacts_found:    Total artifacts detected.
        artifacts_new:      Newly discovered artifacts.
        artifacts_changed:  Artifacts whose content changed.
        artifacts_removed:  Artifacts absent from this scan vs. previous.
        error_message:      Human-readable failure detail (nullable).
        artifacts:          Artifact observations attached to this scan.
                            Populated only on the single-scan detail endpoint.
    """

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": {
                "id": 101,
                "connection_id": 1,
                "triggered_by": "manual",
                "trigger_sha": None,
                "status": "completed",
                "started_at": "2026-03-15T08:30:05Z",
                "completed_at": "2026-03-15T08:30:42Z",
                "created_at": "2026-03-15T08:30:00Z",
                "artifacts_found": 12,
                "artifacts_new": 3,
                "artifacts_changed": 1,
                "artifacts_removed": 0,
                "error_message": None,
                "artifacts": [],
            }
        },
    )

    id: int = Field(
        description="Integer primary key of the scan record.", examples=[101]
    )
    connection_id: int = Field(
        description="FK to the parent GitRepoConnection.id.",
        examples=[1],
    )
    triggered_by: str = Field(
        description=(
            "How this scan was initiated: ``'manual'``, ``'schedule'``, or ``'webhook'``."
        ),
        examples=["manual"],
    )
    trigger_sha: Optional[str] = Field(
        default=None,
        description=(
            "Git commit SHA (40-char hex) that triggered a webhook-initiated scan. "
            "``null`` for manual or scheduled scans."
        ),
        examples=["a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2"],
    )
    status: str = Field(
        description=(
            "Current scan lifecycle state: ``'pending'``, ``'running'``, "
            "``'completed'``, or ``'failed'``."
        ),
        examples=["completed"],
    )
    started_at: Optional[datetime] = Field(
        default=None,
        description="UTC timestamp when the scan worker picked up the job.",
        examples=["2026-03-15T08:30:05Z"],
    )
    completed_at: Optional[datetime] = Field(
        default=None,
        description="UTC timestamp when the scan finished (success or failure).",
        examples=["2026-03-15T08:30:42Z"],
    )
    created_at: datetime = Field(
        description="UTC timestamp when the scan record was created.",
        examples=["2026-03-15T08:30:00Z"],
    )
    artifacts_found: int = Field(
        description="Total artifacts detected in this scan run.",
        examples=[12],
    )
    artifacts_new: int = Field(
        description="Artifacts newly discovered (not seen in previous scans).",
        examples=[3],
    )
    artifacts_changed: int = Field(
        description="Artifacts whose content changed since the last scan.",
        examples=[1],
    )
    artifacts_removed: int = Field(
        description="Artifacts present in the previous scan but no longer found.",
        examples=[0],
    )
    error_message: Optional[str] = Field(
        default=None,
        description="Human-readable error detail when status is ``'failed'``.",
        examples=[None],
    )
    artifacts: List[GitScanArtifactResponse] = Field(
        default_factory=list,
        description=(
            "Artifact observations for this scan run.  Populated by the "
            "single-scan detail endpoint (``GET /scans/{scan_id}``); "
            "omitted (empty list) on collection/list endpoints."
        ),
    )


class GitScanArtifactResponse(BaseModel):
    """Response schema for a single artifact observation from a scan run.

    Attributes:
        id:             Integer primary key.
        scan_id:        FK to the parent GitRepoScan.
        artifact_path:  Repository-relative path to the artifact.
        artifact_type:  Detected artifact type label.
        detected_name:  Human-readable name from frontmatter (nullable).
        content_hash:   SHA-256 hex digest of artifact content (nullable).
        change_type:    Classification relative to previous scan.
        indexed_at:     UTC timestamp when imported into cache (nullable).
        artifact_id:    FK to artifacts.id once indexed (nullable).
    """

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": {
                "id": 501,
                "scan_id": 101,
                "artifact_path": ".claude/skills/canvas-design",
                "artifact_type": "skill",
                "detected_name": "Canvas Design",
                "content_hash": "a" * 64,
                "change_type": "new",
                "indexed_at": None,
                "artifact_id": None,
            }
        },
    )

    id: int = Field(
        description="Integer primary key of the scan artifact row.", examples=[501]
    )
    scan_id: int = Field(
        description="FK to the parent GitRepoScan.id.",
        examples=[101],
    )
    artifact_path: str = Field(
        description="Repository-relative path to the artifact directory or file.",
        examples=[".claude/skills/canvas-design"],
    )
    artifact_type: str = Field(
        description="Detected artifact type label (e.g. ``'skill'``, ``'agent'``, ``'command'``).",
        examples=["skill"],
    )
    detected_name: Optional[str] = Field(
        default=None,
        description="Human-readable artifact name parsed from frontmatter (nullable).",
        examples=["Canvas Design"],
    )
    content_hash: Optional[str] = Field(
        default=None,
        description="SHA-256 hex digest (64 chars) of the artifact content at scan time.",
        examples=["a" * 64],
    )
    change_type: str = Field(
        description=(
            "Classification relative to the previous scan: "
            "``'new'``, ``'changed'``, ``'removed'``, or ``'unchanged'``."
        ),
        examples=["new"],
    )
    indexed_at: Optional[datetime] = Field(
        default=None,
        description=(
            "UTC timestamp when this artifact was imported into the local cache. "
            "``null`` until the ``/index`` endpoint is called."
        ),
        examples=["2026-03-15T09:00:00Z"],
    )
    artifact_id: Optional[str] = Field(
        default=None,
        description=(
            "FK to artifacts.id once the artifact has been indexed/imported. "
            "``null`` until import completes."
        ),
        examples=["skill:canvas-design"],
    )


# =============================================================================
# Trigger / action schemas
# =============================================================================


class ScanTriggerRequest(BaseModel):
    """Request body for triggering a Git repository scan.

    Attributes:
        triggered_by: How the scan is initiated.  Clients should always
                      use ``'manual'``; ``'schedule'`` is reserved for the
                      internal scheduler.
        trigger_sha:  Optional Git commit SHA to associate with this scan.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "triggered_by": "manual",
                "trigger_sha": None,
            }
        }
    )

    triggered_by: Literal["manual", "schedule"] = Field(
        default="manual",
        description=(
            "How this scan is being initiated.  Use ``'manual'`` for API-triggered scans. "
            "``'schedule'`` is reserved for the internal job scheduler."
        ),
        examples=["manual"],
    )
    trigger_sha: Optional[str] = Field(
        default=None,
        description=(
            "Optional Git commit SHA to associate with this scan. "
            "Useful for correlating a manual scan to a specific commit."
        ),
        examples=["a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2"],
    )


class ScanTriggerResponse(BaseModel):
    """Immediate response after a scan has been queued.

    The scan runs asynchronously.  Use ``GET /api/v1/git-scans/{scan_id}``
    to poll for status.

    Attributes:
        scan_id: Integer ID of the newly created scan record.
        status:  Always ``'pending'`` immediately after trigger.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "scan_id": 102,
                "status": "pending",
            }
        }
    )

    scan_id: int = Field(
        description="Integer ID of the newly created GitRepoScan record.",
        examples=[102],
    )
    status: str = Field(
        default="pending",
        description="Scan lifecycle state immediately after trigger — always ``'pending'``.",
        examples=["pending"],
    )


class IndexScanRequest(BaseModel):
    """Request body for importing scan artifacts into the local cache.

    Specifies which ``GitScanArtifact`` rows (by their integer IDs) should
    be imported.  Only artifacts whose ``change_type`` is ``'new'`` or
    ``'changed'`` can be meaningfully indexed.

    Attributes:
        artifact_ids: List of GitScanArtifact integer IDs to import.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "artifact_ids": [501, 502, 503],
            }
        }
    )

    artifact_ids: List[int] = Field(
        description=(
            "Integer IDs (from GitScanArtifact.id) of the scan artifacts to import "
            "into the local artifact cache."
        ),
        examples=[[501, 502, 503]],
    )


# =============================================================================
# Project–Git connection link schemas
# =============================================================================


class ProjectGitConnectionResponse(BaseModel):
    """Response schema for a project–Git connection link.

    Represents one row in the ``project_git_connections`` join table, enriched
    with the ``repo_url`` and ``branch`` fields from the parent
    ``GitRepoConnection``.

    The ``access_token`` and ``webhook_secret`` fields are intentionally absent
    to prevent inadvertent secret exposure via API responses.

    Attributes:
        connection_id: Integer PK of the Git repository connection.
        project_id:    Identifier of the project this connection is linked to.
        repo_url:      GitHub repository URL registered on the connection.
        branch:        Branch configured for scanning on the connection.
        linked_at:     UTC timestamp when the connection was linked to this project.
        linked_by:     User identifier who created the link (nullable).
    """

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": {
                "connection_id": 1,
                "project_id": "proj:my-project",
                "repo_url": "anthropics/claude-code-skills",
                "branch": "main",
                "linked_at": "2026-04-01T12:00:00Z",
                "linked_by": "user:alice",
            }
        },
    )

    connection_id: int = Field(
        description="Integer primary key of the Git repository connection.",
        examples=[1],
    )
    project_id: str = Field(
        description="Identifier of the project this connection is linked to.",
        examples=["proj:my-project"],
    )
    repo_url: str = Field(
        description="GitHub repository URL registered on the connection.",
        examples=["anthropics/claude-code-skills"],
    )
    branch: str = Field(
        description="Branch configured for scanning on the connection.",
        examples=["main"],
    )
    linked_at: datetime = Field(
        description="UTC timestamp when the connection was linked to this project.",
        examples=["2026-04-01T12:00:00Z"],
    )
    linked_by: Optional[str] = Field(
        default=None,
        description="User identifier of the person who created the link (nullable).",
        examples=["user:alice"],
    )


class ProjectGitConnectionListResponse(BaseModel):
    """Paginated response for listing Git connections linked to a project.

    Wraps a page of ``ProjectGitConnectionResponse`` items with standard
    pagination metadata.

    Attributes:
        items:  Page of project–Git connection link records.
        total:  Total number of linked connections across all pages.
        limit:  Page size used for this request.
        offset: Zero-based offset of the first item in this page.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "items": [
                    {
                        "connection_id": 1,
                        "project_id": "proj:my-project",
                        "repo_url": "anthropics/claude-code-skills",
                        "branch": "main",
                        "linked_at": "2026-04-01T12:00:00Z",
                        "linked_by": "user:alice",
                    }
                ],
                "total": 1,
                "limit": 50,
                "offset": 0,
            }
        }
    )

    items: List[ProjectGitConnectionResponse] = Field(
        description="Page of project–Git connection link records.",
    )
    total: int = Field(
        description="Total number of linked connections across all pages.",
        examples=[1],
    )
    limit: int = Field(
        description="Page size used for this request.",
        examples=[50],
    )
    offset: int = Field(
        description="Zero-based offset of the first item in this page.",
        examples=[0],
    )


# GitRepoScanResponse.artifacts references GitScanArtifactResponse which is
# defined later in this module.  Rebuild the model now that the forward
# reference can be resolved.
GitRepoScanResponse.model_rebuild()
