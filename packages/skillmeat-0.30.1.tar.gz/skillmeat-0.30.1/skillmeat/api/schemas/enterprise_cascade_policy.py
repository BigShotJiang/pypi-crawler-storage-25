"""Pydantic schemas for enterprise cascade policy API endpoints.

Defines request and response models for cascade policy CRUD, effective
policy resolution, and audit log retrieval — all consumable by the
enterprise_admin role only.

Phase 4 (DS-4): Implements the three-level policy hierarchy:
  org-level default → per-artifact override → per-team exemption

Only ``soft_update`` and ``hard_update`` policy types are supported.
The ``block`` type is deferred to Phase 5.
"""

from __future__ import annotations

from datetime import datetime
from typing import List, Literal, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "CascadePolicyCreate",
    "CascadePolicyUpdate",
    "CascadePolicyResponse",
    "CascadePolicyListResponse",
    "EffectivePolicyResponse",
    "CascadePolicyAuditEntry",
    "CascadePolicyAuditResponse",
]

# ---------------------------------------------------------------------------
# Literals
# ---------------------------------------------------------------------------

PolicyType = Literal["soft_update", "hard_update"]
ScopeLevelType = Literal["org", "artifact", "team"]
AuditActionType = Literal["create", "update", "delete"]


# ====================
# Request models
# ====================


class CascadePolicyCreate(BaseModel):
    """Request body for creating a cascade policy entry.

    Scope is determined by which optional fields are provided:
    - Neither ``artifact_id`` nor ``team_id``: org-level default
    - Only ``artifact_id``: per-artifact override
    - Both ``artifact_id`` and ``team_id``: per-team exemption

    Note: ``team_id`` without ``artifact_id`` is rejected (DB constraint).
    """

    org_id: Optional[UUID] = Field(
        default=None,
        description=(
            "UUID of the organization this policy applies to. "
            "When omitted, the org is derived from the authenticated context."
        ),
        examples=["550e8400-e29b-41d4-a716-446655440000"],
    )
    artifact_id: Optional[UUID] = Field(
        default=None,
        description=(
            "Optional artifact UUID. NULL → org-level default. "
            "Set with team_id NULL → per-artifact override. "
            "Set with team_id → per-team exemption."
        ),
    )
    team_id: Optional[UUID] = Field(
        default=None,
        description=(
            "Optional team UUID. Requires artifact_id to also be set. "
            "NULL → applies to all teams at this scope level."
        ),
    )
    policy_type: PolicyType = Field(
        description="Cascade action type: 'soft_update' or 'hard_update'",
        examples=["soft_update"],
    )
    is_auto_propagate: bool = Field(
        default=False,
        description=(
            "When True, the policy triggers automatically on upstream version bump. "
            "When False, requires explicit admin action to propagate."
        ),
    )
    change_reason: Optional[str] = Field(
        default=None,
        description="Optional free-text rationale for the policy change (logged in audit)",
        max_length=1000,
    )


class CascadePolicyUpdate(BaseModel):
    """Request body for updating an existing cascade policy entry.

    Only ``policy_type``, ``is_auto_propagate``, and ``change_reason`` may
    be updated — the scope (org_id / artifact_id / team_id) is immutable
    after creation and is not accepted in update requests.
    """

    policy_type: Optional[PolicyType] = Field(
        default=None,
        description="New cascade action type; omit to leave unchanged",
    )
    is_auto_propagate: Optional[bool] = Field(
        default=None,
        description="New auto-propagate setting; omit to leave unchanged",
    )
    change_reason: Optional[str] = Field(
        default=None,
        description="Optional free-text rationale for this change (logged in audit)",
        max_length=1000,
    )


# ====================
# Response models
# ====================


class CascadePolicyResponse(BaseModel):
    """Single cascade policy entry.

    The ``scope_level`` field is derived from the nullable pattern of
    ``artifact_id`` and ``team_id``:
    - ``org``: both NULL
    - ``artifact``: artifact_id set, team_id NULL
    - ``team``: both set
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID = Field(description="Unique cascade policy identifier")
    tenant_id: UUID = Field(description="Tenant scope for this policy")
    org_id: UUID = Field(description="Organization this policy applies to")
    artifact_id: Optional[UUID] = Field(
        default=None,
        description="Artifact UUID if this is an artifact-level policy; NULL for org default",
    )
    team_id: Optional[UUID] = Field(
        default=None,
        description="Team UUID if this is a team exemption; NULL for org or artifact level",
    )
    policy_type: str = Field(
        description="Cascade action type: 'soft_update' or 'hard_update'",
    )
    is_auto_propagate: bool = Field(
        description=(
            "True → policy fires automatically on upstream version bump; "
            "False → requires explicit admin action."
        )
    )
    scope_level: ScopeLevelType = Field(
        description="Resolved scope level: 'org', 'artifact', or 'team'",
    )
    created_by: UUID = Field(description="UUID of the user who created this policy")
    created_at: datetime = Field(description="Timezone-aware creation timestamp")
    updated_at: datetime = Field(description="Timezone-aware last-modified timestamp")


class CascadePolicyListResponse(BaseModel):
    """Paginated list of cascade policies for an organization."""

    model_config = ConfigDict(from_attributes=True)

    items: List[CascadePolicyResponse] = Field(
        description="List of cascade policy entries matching the query filters"
    )
    total: int = Field(
        description="Total number of entries matching the query (before pagination)",
        examples=[5],
    )


class EffectivePolicyResponse(BaseModel):
    """Resolved effective cascade policy for a specific (artifact, team) context.

    Applies the three-level resolution chain at query time:
    1. Org-level default
    2. Per-artifact override (if one exists)
    3. Per-team exemption (if one exists for this artifact + team)
    """

    model_config = ConfigDict(from_attributes=True)

    artifact_id: UUID = Field(
        description="Artifact UUID this resolution was computed for",
    )
    team_id: Optional[UUID] = Field(
        default=None,
        description="Team UUID used in resolution; NULL means org-default context",
    )
    org_id: UUID = Field(description="Organization providing the policy context")
    policy_type: str = Field(
        description="Resolved cascade action type: 'soft_update' or 'hard_update'",
    )
    is_auto_propagate: bool = Field(
        description="Resolved auto-propagate setting"
    )
    resolved_from: ScopeLevelType = Field(
        description=(
            "Scope level that provided the effective policy: "
            "'org' (default applied), 'artifact' (per-artifact override applied), "
            "or 'team' (per-team exemption applied)."
        ),
    )
    policy_id: Optional[UUID] = Field(
        default=None,
        description=(
            "UUID of the explicit policy row that provided the effective value; "
            "NULL when the built-in system default (soft_update / no auto-propagate) "
            "is returned because no explicit org-default row exists."
        ),
    )


# ====================
# Audit models
# ====================


class CascadePolicyAuditEntry(BaseModel):
    """Single cascade policy audit log entry.

    Represents one create / update / delete event on a cascade policy row.
    Audit entries are immutable — no update or delete operations are permitted.
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID = Field(description="Unique audit entry identifier")
    tenant_id: UUID = Field(description="Tenant scope")
    org_id: UUID = Field(description="Organization whose policy was mutated")
    artifact_id: Optional[UUID] = Field(
        default=None,
        description="Artifact scope of the mutated policy; NULL for org-level",
    )
    team_id: Optional[UUID] = Field(
        default=None,
        description="Team scope of the mutated policy; NULL for org or artifact level",
    )
    changed_by: UUID = Field(description="UUID of the user who made the change")
    changed_at: datetime = Field(description="Timezone-aware timestamp of the change")
    action: str = Field(
        description="Mutation type: 'create', 'update', or 'delete'",
    )
    old_policy_type: Optional[str] = Field(
        default=None,
        description="Policy type before the change; NULL when action is 'create'",
    )
    new_policy_type: Optional[str] = Field(
        default=None,
        description="Policy type after the change; NULL when action is 'delete'",
    )
    old_auto_propagate: Optional[bool] = Field(
        default=None,
        description="is_auto_propagate before the change; NULL when action is 'create'",
    )
    new_auto_propagate: Optional[bool] = Field(
        default=None,
        description="is_auto_propagate after the change; NULL when action is 'delete'",
    )
    change_reason: Optional[str] = Field(
        default=None,
        description="Optional free-text rationale supplied by the admin",
    )


class CascadePolicyAuditResponse(BaseModel):
    """Paginated audit log for a cascade policy."""

    model_config = ConfigDict(from_attributes=True)

    policy_id: UUID = Field(description="UUID of the policy whose audit log is returned")
    items: List[CascadePolicyAuditEntry] = Field(
        description="Audit log entries in reverse-chronological order (newest first)"
    )
    total: int = Field(
        description="Total number of audit entries for this policy",
        examples=[3],
    )
