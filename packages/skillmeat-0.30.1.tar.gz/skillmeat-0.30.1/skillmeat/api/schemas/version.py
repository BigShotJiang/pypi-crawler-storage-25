"""Pydantic schemas for version management API endpoints.

Defines request and response models for snapshot, rollback, and artifact
version history/restore operations (Phase 3).
"""

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional
from uuid import UUID

from pydantic import BaseModel, Field, field_validator

from .common import PageInfo, PaginatedResponse

# ====================
# Response Schemas
# ====================


class SnapshotResponse(BaseModel):
    """Single snapshot representation.

    Provides metadata about a collection snapshot including artifact count
    and timestamp information.
    """

    id: str = Field(
        description="Snapshot unique identifier (SHA-256 hash)",
        examples=["abc123def456789..."],
    )
    timestamp: datetime = Field(
        description="Snapshot creation timestamp",
        examples=["2025-12-17T12:00:00Z"],
    )
    message: str = Field(
        description="Snapshot description or commit message",
        examples=["Manual snapshot before upgrade"],
    )
    collection_name: str = Field(
        description="Name of the collection this snapshot belongs to",
        examples=["default"],
    )
    artifact_count: int = Field(
        description="Number of artifacts captured in this snapshot",
        examples=[15],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "id": "abc123def456789...",
                "timestamp": "2025-12-17T12:00:00Z",
                "message": "Manual snapshot before upgrade",
                "collection_name": "default",
                "artifact_count": 15,
            }
        }


class SnapshotListResponse(PaginatedResponse[SnapshotResponse]):
    """Paginated response for snapshot listings.

    Returns list of snapshots with pagination metadata following
    cursor-based pagination pattern.
    """

    pass


class ConflictMetadataResponse(BaseModel):
    """Conflict information for a single file.

    Describes the type and nature of a merge conflict detected
    during rollback analysis.
    """

    file_path: str = Field(
        description="Relative path to the conflicting file",
        examples=[".claude/skills/pdf/SKILL.md"],
    )
    conflict_type: str = Field(
        description="Type of conflict: content, deletion, add_add, both_modified",
        examples=["content"],
    )
    auto_mergeable: bool = Field(
        description="Whether the conflict can be automatically merged",
        examples=[True],
    )
    is_binary: bool = Field(
        description="Whether the file is binary (cannot be text-merged)",
        examples=[False],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "file_path": ".claude/skills/pdf/SKILL.md",
                "conflict_type": "content",
                "auto_mergeable": True,
                "is_binary": False,
            }
        }


class RollbackSafetyAnalysisResponse(BaseModel):
    """Pre-flight rollback safety analysis.

    Provides analysis of potential conflicts and safety information
    before executing a rollback operation.
    """

    is_safe: bool = Field(
        description="Whether rollback can proceed without data loss",
        examples=[True],
    )
    files_with_conflicts: List[str] = Field(
        default_factory=list,
        description="Files that have conflicts requiring manual resolution",
        examples=[[".claude/skills/pdf/SKILL.md"]],
    )
    files_safe_to_restore: List[str] = Field(
        default_factory=list,
        description="Files that can be safely restored without conflicts",
        examples=[[".claude/skills/canvas/SKILL.md"]],
    )
    warnings: List[str] = Field(
        default_factory=list,
        description="Warning messages about potential issues",
        examples=[["2 files have been modified since snapshot"]],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "is_safe": True,
                "files_with_conflicts": [".claude/skills/pdf/SKILL.md"],
                "files_safe_to_restore": [".claude/skills/canvas/SKILL.md"],
                "warnings": ["2 files have been modified since snapshot"],
            }
        }


class RollbackResponse(BaseModel):
    """Rollback operation result.

    Contains detailed information about files restored, merged, and
    any conflicts encountered during rollback.
    """

    success: bool = Field(
        description="Whether rollback operation completed successfully",
        examples=[True],
    )
    files_merged: List[str] = Field(
        default_factory=list,
        description="Files that were successfully merged",
        examples=[[".claude/skills/pdf/SKILL.md"]],
    )
    files_restored: List[str] = Field(
        default_factory=list,
        description="Files that were restored from snapshot",
        examples=[[".claude/skills/canvas/SKILL.md"]],
    )
    conflicts: List[ConflictMetadataResponse] = Field(
        default_factory=list,
        description="Conflicts that require manual resolution",
    )
    safety_snapshot_id: Optional[str] = Field(
        default=None,
        description="ID of safety snapshot created before rollback",
        examples=["def789abc123..."],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "success": True,
                "files_merged": [".claude/skills/pdf/SKILL.md"],
                "files_restored": [".claude/skills/canvas/SKILL.md"],
                "conflicts": [],
                "safety_snapshot_id": "def789abc123...",
            }
        }


class VersionDiffResponse(BaseModel):
    """Diff result between two snapshots.

    Provides statistical comparison of changes between two
    collection snapshots.
    """

    files_added: List[str] = Field(
        default_factory=list,
        description="Files added between snapshots",
        examples=[[".claude/skills/new-skill/SKILL.md"]],
    )
    files_removed: List[str] = Field(
        default_factory=list,
        description="Files removed between snapshots",
        examples=[[".claude/skills/old-skill/SKILL.md"]],
    )
    files_modified: List[str] = Field(
        default_factory=list,
        description="Files modified between snapshots",
        examples=[[".claude/skills/pdf/SKILL.md"]],
    )
    total_lines_added: int = Field(
        description="Total number of lines added across all files",
        examples=[150],
    )
    total_lines_removed: int = Field(
        description="Total number of lines removed across all files",
        examples=[75],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "files_added": [".claude/skills/new-skill/SKILL.md"],
                "files_removed": [".claude/skills/old-skill/SKILL.md"],
                "files_modified": [".claude/skills/pdf/SKILL.md"],
                "total_lines_added": 150,
                "total_lines_removed": 75,
            }
        }


# ====================
# Request Schemas
# ====================


class SnapshotCreateRequest(BaseModel):
    """Request to create a new snapshot.

    Creates a point-in-time snapshot of a collection for later rollback.
    """

    collection_name: Optional[str] = Field(
        default=None,
        description="Collection name (uses active collection if not specified)",
        examples=["default"],
    )
    message: str = Field(
        default="Manual snapshot",
        description="Snapshot description or commit message",
        max_length=500,
        examples=["Manual snapshot before major upgrade"],
    )

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "collection_name": "default",
                "message": "Manual snapshot before major upgrade",
            }
        }


class SnapshotCreateResponse(BaseModel):
    """Response after creating a snapshot.

    Returns the newly created snapshot with confirmation flag.
    """

    snapshot: SnapshotResponse = Field(
        description="Newly created snapshot metadata",
    )
    created: bool = Field(
        default=True,
        description="Confirmation that snapshot was created",
    )

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "snapshot": {
                    "id": "abc123def456789...",
                    "timestamp": "2025-12-17T12:00:00Z",
                    "message": "Manual snapshot before major upgrade",
                    "collection_name": "default",
                    "artifact_count": 15,
                },
                "created": True,
            }
        }


class RollbackRequest(BaseModel):
    """Request to rollback to a previous snapshot.

    Supports both simple rollback and intelligent merge-based rollback
    with selective path restoration.
    """

    snapshot_id: str = Field(
        description="ID of snapshot to rollback to",
        examples=["abc123def456789..."],
    )
    collection_name: Optional[str] = Field(
        default=None,
        description="Collection name (uses active collection if not specified)",
        examples=["default"],
    )
    preserve_changes: bool = Field(
        default=True,
        description="Use intelligent merge to preserve local changes (recommended)",
        examples=[True],
    )
    selective_paths: Optional[List[str]] = Field(
        default=None,
        description="Only rollback these specific paths (optional)",
        examples=[[".claude/skills/pdf/"]],
    )

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "snapshot_id": "abc123def456789...",
                "collection_name": "default",
                "preserve_changes": True,
                "selective_paths": None,
            }
        }


class VersionDiffRequest(BaseModel):
    """Request to compare two snapshots.

    Generates a diff showing changes between two collection snapshots.
    """

    snapshot_id_1: str = Field(
        description="First snapshot ID (older)",
        examples=["abc123def456789..."],
    )
    snapshot_id_2: str = Field(
        description="Second snapshot ID (newer)",
        examples=["def789abc123..."],
    )
    collection_name: Optional[str] = Field(
        default=None,
        description="Collection name (uses active collection if not specified)",
        examples=["default"],
    )

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "snapshot_id_1": "abc123def456789...",
                "snapshot_id_2": "def789abc123...",
                "collection_name": "default",
            }
        }


# ====================
# Phase 3: Artifact Version History & Restore Schemas
# ====================


# --- SCH-3.1: Version History Response Schemas ---


class DiffSummary(BaseModel):
    """Summary of line-level changes between two artifact versions.

    Provides a quick statistical overview of the diff without
    the full unified diff text.
    """

    lines_added: int = Field(
        description="Number of lines added in this version",
        examples=[12],
    )
    lines_removed: int = Field(
        description="Number of lines removed in this version",
        examples=[4],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "lines_added": 12,
                "lines_removed": 4,
            }
        }


class VersionHistoryItem(BaseModel):
    """Single entry in an artifact's version history.

    Represents one recorded state transition for a specific artifact,
    capturing the hash, origin, event type, actor, and optional diff summary.
    """

    content_hash: str = Field(
        description="SHA-256 hash of the artifact content at this version",
        examples=["a" * 64],
    )
    parent_hash: str | None = Field(
        default=None,
        description="SHA-256 hash of the immediately preceding version (null for first version)",
        examples=["b" * 64],
    )
    change_origin: Literal["manual", "sync", "restore", "deploy", "import", "merge"] = (
        Field(
            description="System operation that produced this version",
            examples=["sync"],
        )
    )
    created_at: datetime = Field(
        description="ISO 8601 timestamp when this version was recorded",
        examples=["2026-01-15T10:30:00Z"],
    )
    actor_id: str | None = Field(
        default=None,
        description="Identifier of the user or system actor that created this version",
        examples=["user:alice"],
    )
    event_type: Literal[
        "created", "updated", "restored", "synced", "deployed", "force_sync"
    ] = Field(
        description="Semantic label for the type of version event",
        examples=["updated"],
    )
    diff_summary: DiffSummary | None = Field(
        default=None,
        description="Line-level diff statistics relative to parent version (absent for first version)",
    )
    metadata: dict[str, Any] | None = Field(
        default=None,
        description="Arbitrary key-value metadata attached to this version event",
        examples=[{"source_ref": "v1.2.0", "upstream_sha": "abc123"}],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "content_hash": "a" * 64,
                "parent_hash": "b" * 64,
                "change_origin": "sync",
                "created_at": "2026-01-15T10:30:00Z",
                "actor_id": "user:alice",
                "event_type": "updated",
                "diff_summary": {"lines_added": 12, "lines_removed": 4},
                "metadata": {"source_ref": "v1.2.0"},
            }
        }


class VersionHistoryResponse(BaseModel):
    """Paginated version history for a single artifact.

    Returns an ordered list of version history entries (most recent first)
    with cursor-based pagination for efficient traversal.
    """

    artifact_id: str = Field(
        description="Unique identifier of the artifact whose history is returned",
        examples=["skill:canvas-design"],
    )
    items: list[VersionHistoryItem] = Field(
        description="Version history entries for this page, most recent first",
    )
    page_info: PageInfo = Field(
        description="Cursor-based pagination metadata for this result set",
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "artifact_id": "skill:canvas-design",
                "items": [],
                "page_info": {
                    "has_next_page": False,
                    "has_previous_page": False,
                    "end_cursor": None,
                    "total_count": 0,
                },
            }
        }


# --- SCH-3.2: Version Diff Response Schema ---


class ArtifactVersionDiffResponse(BaseModel):
    """Full unified diff between two specific artifact content hashes.

    Provides the raw unified diff text along with line-level statistics
    for rendering in diff viewer UI components.
    """

    artifact_id: str = Field(
        description="Unique identifier of the artifact being compared",
        examples=["skill:canvas-design"],
    )
    from_hash: str = Field(
        description="SHA-256 hash of the older (base) version",
        examples=["a" * 64],
    )
    to_hash: str = Field(
        description="SHA-256 hash of the newer (head) version",
        examples=["b" * 64],
    )
    unified_diff: str = Field(
        description="Unified diff output in standard patch format",
        examples=["--- a/SKILL.md\n+++ b/SKILL.md\n@@ -1,3 +1,4 @@\n ..."],
    )
    lines_added: int = Field(
        description="Total number of lines added in this diff",
        examples=[12],
    )
    lines_removed: int = Field(
        description="Total number of lines removed in this diff",
        examples=[4],
    )
    is_binary: bool = Field(
        default=False,
        description="Whether the artifact content is binary (unified_diff will be empty if true)",
        examples=[False],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "artifact_id": "skill:canvas-design",
                "from_hash": "a" * 64,
                "to_hash": "b" * 64,
                "unified_diff": "--- a/SKILL.md\n+++ b/SKILL.md\n",
                "lines_added": 12,
                "lines_removed": 4,
                "is_binary": False,
            }
        }


# --- SCH-3.3: Restore Request/Response Schemas ---

_HEX64_PATTERN = r"^[0-9a-f]{64}$"


class RestoreRequest(BaseModel):
    """Request to restore an artifact to a previously recorded content hash.

    Supports both simple single-artifact restores and composite artifact
    restores where member artifacts can be individually targeted.
    """

    target_hash: str = Field(
        min_length=64,
        max_length=64,
        pattern=_HEX64_PATTERN,
        description="SHA-256 hex content hash of the version to restore to",
        examples=["a" * 64],
    )
    restore_members: bool = Field(
        default=False,
        description=(
            "For composite artifacts, also restore member artifacts to their "
            "corresponding hashes from the target version"
        ),
        examples=[False],
    )
    member_hashes: dict[str, str] | None = Field(
        default=None,
        description=(
            "Override per-member target hashes keyed by member artifact_id. "
            "Only used when restore_members=True. Null means use hashes recorded "
            "in the composite's target version."
        ),
        examples=[{"skill:canvas-design": "a" * 64}],
    )
    collection_name: str | None = Field(
        default=None,
        description="Target collection name. Uses the active collection if not specified.",
        examples=["default"],
    )

    @field_validator("member_hashes")
    @classmethod
    def validate_member_hashes(
        cls, v: Optional[Dict[str, str]]
    ) -> Optional[Dict[str, str]]:
        """Validate each member hash matches the 64-hex SHA-256 pattern."""
        if v is None:
            return v
        import re

        pattern = re.compile(_HEX64_PATTERN)
        for member_id, hash_val in v.items():
            if not pattern.match(hash_val):
                raise ValueError(
                    f"member_hashes['{member_id}'] must be a 64-character lowercase hex string"
                )
        return v

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "target_hash": "a" * 64,
                "restore_members": False,
                "member_hashes": None,
                "collection_name": "default",
            }
        }


class RestoreResponse(BaseModel):
    """Result of an artifact restore operation.

    Confirms which hash was restored, the new version hash created for the
    restore event, and which member artifacts (if any) were also restored.
    """

    artifact_id: str = Field(
        description="Unique identifier of the artifact that was restored",
        examples=["skill:canvas-design"],
    )
    restored_to_hash: str = Field(
        description="SHA-256 hash of the version that was restored (the target_hash from the request)",
        examples=["a" * 64],
    )
    new_version_hash: str = Field(
        description=(
            "SHA-256 hash of the new version entry created to record this restore event. "
            "This becomes the new head hash."
        ),
        examples=["c" * 64],
    )
    members_restored: list[str] = Field(
        default_factory=list,
        description="List of member artifact_ids that were also restored (for composite artifacts)",
        examples=[["skill:canvas-design", "command:export"]],
    )
    event_id: str = Field(
        description="Unique identifier for this restore event, used for audit trail lookups",
        examples=["evt_abc123def456"],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "artifact_id": "composite:my-plugin",
                "restored_to_hash": "a" * 64,
                "new_version_hash": "c" * 64,
                "members_restored": ["skill:canvas-design"],
                "event_id": "evt_abc123def456",
            }
        }


# --- SCH-3.4: Enterprise Scope Schemas ---


class VersionScopeResponse(BaseModel):
    """Version scope record for a single artifact within an ownership context.

    Tracks the current head hash, optional baseline for drift detection,
    and any in-flight promotion state for enterprise governance workflows.
    """

    id: str = Field(
        description="Unique identifier for this version scope record",
        examples=["scope_abc123"],
    )
    artifact_id: str = Field(
        description="Unique identifier of the scoped artifact",
        examples=["skill:canvas-design"],
    )
    owner_type: Literal["user", "team", "enterprise"] = Field(
        description="Type of owner entity this scope belongs to",
        examples=["team"],
    )
    owner_id: str = Field(
        description="Identifier of the owner (user ID, team ID, or enterprise ID)",
        examples=["team:platform-eng"],
    )
    head_hash: str = Field(
        description="SHA-256 hash of the current head version for this scope",
        examples=["a" * 64],
    )
    baseline_hash: str | None = Field(
        default=None,
        description=(
            "SHA-256 hash of the approved baseline version. "
            "When set, divergence from this hash triggers is_diverged=True."
        ),
        examples=["b" * 64],
    )
    is_diverged: bool = Field(
        default=False,
        description="Whether the current head_hash differs from the baseline_hash",
        examples=[False],
    )
    promotion_state: Literal["none", "pending", "approved", "rejected"] = Field(
        default="none",
        description="Current state of any in-flight promotion request for this scope",
        examples=["none"],
    )
    promotion_requested_at: datetime | None = Field(
        default=None,
        description="ISO 8601 timestamp when promotion was requested (null if no pending promotion)",
        examples=["2026-02-10T09:00:00Z"],
    )
    promotion_reviewed_by: str | None = Field(
        default=None,
        description="Actor ID of the reviewer who approved or rejected the promotion",
        examples=["user:bob"],
    )
    promotion_reviewed_at: datetime | None = Field(
        default=None,
        description="ISO 8601 timestamp when the promotion was reviewed",
        examples=["2026-02-11T14:30:00Z"],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "id": "scope_abc123",
                "artifact_id": "skill:canvas-design",
                "owner_type": "team",
                "owner_id": "team:platform-eng",
                "head_hash": "a" * 64,
                "baseline_hash": None,
                "is_diverged": False,
                "promotion_state": "none",
                "promotion_requested_at": None,
                "promotion_reviewed_by": None,
                "promotion_reviewed_at": None,
            }
        }


class PromotionRequest(BaseModel):
    """Request to submit a promotion for a version scope.

    Signals intent to promote the current head version as the new
    baseline for enterprise governance review.
    """

    approval: bool = Field(
        description="Set to True to submit the promotion request",
        examples=[True],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {"example": {"approval": True}}


class ReviewRequest(BaseModel):
    """Request to review (approve or reject) a pending promotion.

    Used by enterprise administrators to finalize a promotion decision.
    """

    approved: bool = Field(
        description="True to approve the promotion, False to reject it",
        examples=[True],
    )
    rejection_reason: str | None = Field(
        default=None,
        description="Human-readable reason for rejection (required when approved=False)",
        examples=["Version contains unapproved dependency changes"],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "approved": False,
                "rejection_reason": "Version contains unapproved dependency changes",
            }
        }


class ForceSyncRequest(BaseModel):
    """Request to force-sync a version scope to a specific content hash.

    Bypasses the normal promotion workflow and directly sets the scope's
    head hash. Requires enterprise admin privileges.
    """

    target_hash: str = Field(
        min_length=64,
        max_length=64,
        pattern=_HEX64_PATTERN,
        description="SHA-256 hex content hash to force-sync the scope to",
        examples=["a" * 64],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {"example": {"target_hash": "a" * 64}}


# --- SCH-3.5: Admin Summary Schemas ---


class AdminVersionSummaryItem(BaseModel):
    """Summary of a single artifact's version scope for admin oversight.

    Aggregates ownership context, divergence state, and promotion status
    into a single row suitable for admin dashboard displays.
    """

    scope_id: UUID = Field(
        description=(
            "Primary key of the EnterpriseArtifactVersionScope row. "
            "Use this UUID when calling scope-keyed mutation endpoints such as "
            "POST /api/v1/versions/scopes/{scope_id}/force-sync and "
            "POST /api/v1/versions/artifacts/{artifact_id}/scopes/{scope_id}/promote."
        ),
        examples=["123e4567-e89b-12d3-a456-426614174000"],
    )
    artifact_id: str = Field(
        description="Unique identifier of the artifact",
        examples=["skill:canvas-design"],
    )
    artifact_name: str = Field(
        description="Human-readable display name of the artifact",
        examples=["Canvas Design"],
    )
    owner_type: Literal["user", "team", "enterprise"] = Field(
        description="Type of owner entity for this scope",
        examples=["team"],
    )
    owner_id: str = Field(
        description="Identifier of the owning entity",
        examples=["team:platform-eng"],
    )
    owner_display_name: str | None = Field(
        default=None,
        description="Human-readable display name of the owner",
        examples=["Platform Engineering"],
    )
    head_hash: str = Field(
        description="SHA-256 hash of the current head version",
        examples=["a" * 64],
    )
    baseline_hash: str | None = Field(
        default=None,
        description="SHA-256 hash of the approved baseline version",
        examples=["b" * 64],
    )
    is_diverged: bool = Field(
        default=False,
        description="Whether head_hash differs from baseline_hash",
        examples=[True],
    )
    promotion_state: Literal["none", "pending", "approved", "rejected"] = Field(
        default="none",
        description="Current in-flight promotion state for this scope",
        examples=["pending"],
    )
    last_modified_at: datetime | None = Field(
        default=None,
        description="ISO 8601 timestamp of the most recent version change",
        examples=["2026-03-01T12:00:00Z"],
    )
    modified_by: str | None = Field(
        default=None,
        description="Actor ID of the entity that made the most recent change",
        examples=["user:alice"],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "scope_id": "123e4567-e89b-12d3-a456-426614174000",
                "artifact_id": "skill:canvas-design",
                "artifact_name": "Canvas Design",
                "owner_type": "team",
                "owner_id": "team:platform-eng",
                "owner_display_name": "Platform Engineering",
                "head_hash": "a" * 64,
                "baseline_hash": "b" * 64,
                "is_diverged": True,
                "promotion_state": "pending",
                "last_modified_at": "2026-03-01T12:00:00Z",
                "modified_by": "user:alice",
            }
        }


class AdminVersionSummaryResponse(BaseModel):
    """Paginated admin summary of artifact version scopes.

    Returns a list of version scope summary items with cursor-based
    pagination for admin dashboard use.
    """

    items: list[AdminVersionSummaryItem] = Field(
        description="Version scope summary items for this page",
    )
    page_info: PageInfo = Field(
        description="Cursor-based pagination metadata",
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "items": [],
                "page_info": {
                    "has_next_page": False,
                    "has_previous_page": False,
                    "end_cursor": None,
                    "total_count": 0,
                },
            }
        }


class AdminBulkActionRequest(BaseModel):
    """Request to perform a bulk administrative action on multiple version scopes.

    Supports batch force-sync, approval, and rejection operations.
    When action is 'force-sync', target_hash must be provided.
    """

    scope_ids: list[str] = Field(
        min_length=1,
        description="List of version scope IDs to apply the action to (at least one required)",
        examples=[["scope_abc123", "scope_def456"]],
    )
    action: Literal["force-sync", "approve", "reject"] = Field(
        description="Bulk action to perform on all specified scope IDs",
        examples=["approve"],
    )
    target_hash: str | None = Field(
        default=None,
        description=(
            "SHA-256 hex content hash for force-sync actions. "
            "Required when action='force-sync', ignored otherwise."
        ),
        examples=["a" * 64],
    )

    @field_validator("target_hash")
    @classmethod
    def validate_target_hash(cls, v: Optional[str]) -> Optional[str]:
        """Validate target_hash format when provided."""
        if v is None:
            return v
        import re

        if not re.match(_HEX64_PATTERN, v):
            raise ValueError("target_hash must be a 64-character lowercase hex string")
        return v

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "scope_ids": ["scope_abc123", "scope_def456"],
                "action": "approve",
                "target_hash": None,
            }
        }


# ---------------------------------------------------------------------------
# Backfill status (VCS v2 — Phase 2)
# ---------------------------------------------------------------------------


# ====================
# Version-Centric Deployment View Schemas
# ====================


class OwnerScope(BaseModel):
    """Enterprise ownership scope for a version group.

    Represents one owner (user, team, or enterprise) whose current
    ``head_hash`` matches the version group's content hash.  Present only
    in enterprise edition responses when a ``tenant_id`` is available.
    """

    owner_type: str = Field(
        description="Owner category: 'user', 'team', or 'enterprise'",
        examples=["team"],
    )
    owner_id: str = Field(
        description="UUID of the owning entity (hex string)",
        examples=["a1b2c3d4-e5f6-7890-abcd-ef1234567890"],
    )
    head_hash: str = Field(
        description="SHA-256 content hash currently held by this owner",
        examples=["a" * 64],
    )
    is_diverged: bool = Field(
        description="Whether the owner's head_hash differs from the approved baseline",
        examples=[False],
    )
    promotion_state: str = Field(
        description="In-flight promotion state: 'none', 'requested', 'approved', or 'rejected'",
        examples=["none"],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "owner_type": "team",
                "owner_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                "head_hash": "a" * 64,
                "is_diverged": False,
                "promotion_state": "none",
            }
        }


class VersionGroupDeployment(BaseModel):
    """Single project deployment within a version group.

    Represents one project that has a given content hash deployed.
    """

    project_id: str = Field(
        description="Project identifier",
        examples=["my-project"],
    )
    project_path: str = Field(
        description="Absolute filesystem path to the project",
        examples=["/Users/alice/projects/my-app"],
    )
    deployed_at: datetime = Field(
        description="UTC timestamp when this deployment event was recorded",
        examples=["2026-01-15T10:30:00Z"],
    )
    pinned: bool = Field(
        description="Whether this deployment is pinned against auto-updates",
        examples=[False],
    )
    status: str = Field(
        description="Deployment status (e.g. 'current', 'outdated')",
        examples=["current"],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "project_id": "my-project",
                "project_path": "/Users/alice/projects/my-app",
                "deployed_at": "2026-01-15T10:30:00Z",
                "pinned": False,
                "status": "current",
            }
        }


class VersionGroup(BaseModel):
    """A group of deployments sharing the same content hash.

    Groups all project deployments that have the same artifact content hash,
    along with metadata from the ArtifactVersion record for that hash.
    """

    content_hash: str = Field(
        description="Full 64-character SHA-256 content hash",
        examples=["a" * 64],
    )
    semver_tag: Optional[str] = Field(
        default=None,
        description="Semantic version label associated with this hash, if any",
        examples=["v1.2.0"],
    )
    created_at: datetime = Field(
        description="UTC timestamp when this version was first recorded",
        examples=["2026-01-10T08:00:00Z"],
    )
    change_origin: Optional[str] = Field(
        default=None,
        description="System operation that produced this version (sync, deploy, etc.)",
        examples=["sync"],
    )
    deployment_count: int = Field(
        description="Number of projects currently deploying this content hash",
        examples=[3],
    )
    is_current: bool = Field(
        description="Whether this hash matches the current collection version",
        examples=[True],
    )
    deployments: List[VersionGroupDeployment] = Field(
        description="List of project deployments for this content hash",
    )
    owner_scopes: List[OwnerScope] = Field(
        default_factory=list,
        description=(
            "Enterprise owner scopes whose head_hash matches this content hash. "
            "Non-empty only in enterprise edition responses with a valid tenant_id."
        ),
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "content_hash": "a" * 64,
                "semver_tag": "v1.2.0",
                "created_at": "2026-01-10T08:00:00Z",
                "change_origin": "sync",
                "deployment_count": 2,
                "is_current": True,
                "deployments": [],
                "owner_scopes": [],
            }
        }


class VersionGroupedTopology(BaseModel):
    """Full version-grouped deployment topology for an artifact.

    Groups all project deployments by content hash, providing a version-centric
    view of where each version of the artifact is deployed.
    """

    artifact_id: str = Field(
        description="Artifact identifier in type:name format",
        examples=["skill:canvas-design"],
    )
    collection_version: Optional[str] = Field(
        default=None,
        description="Current collection content hash (from ArtifactCollectionVersion)",
        examples=["b" * 64],
    )
    versions: List[VersionGroup] = Field(
        description="Version groups ordered by most recent deployment descending",
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "artifact_id": "skill:canvas-design",
                "collection_version": "b" * 64,
                "versions": [],
            }
        }


class BatchSyncRequest(BaseModel):
    """Request to sync all projects deployed on source_hash to target_hash.

    Identifies all project deployments with source_hash and records a sync
    mutation to target_hash for each non-pinned deployment.
    """

    source_hash: str = Field(
        description="Content hash of the version to sync from",
        examples=["a" * 64],
    )
    target_hash: str = Field(
        description="Content hash of the version to sync to",
        examples=["b" * 64],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "source_hash": "a" * 64,
                "target_hash": "b" * 64,
            }
        }


class BatchSyncError(BaseModel):
    """Per-project error detail from a batch sync operation."""

    project_id: str = Field(
        description="Project identifier that failed to sync",
        examples=["my-project"],
    )
    error: str = Field(
        description="Human-readable error description",
        examples=["Failed to record sync mutation: constraint violation"],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "project_id": "my-project",
                "error": "Failed to record sync mutation: constraint violation",
            }
        }


class BatchSyncResponse(BaseModel):
    """Result of a batch-sync operation.

    Reports how many projects were synced, how many failed, and per-project
    error details for partial failures.
    """

    synced: int = Field(
        description="Number of projects successfully synced",
        examples=[3],
    )
    failed: int = Field(
        description="Number of projects that failed to sync",
        examples=[1],
    )
    errors: List[BatchSyncError] = Field(
        description="Per-project error details for failed syncs",
        default_factory=list,
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "synced": 3,
                "failed": 1,
                "errors": [
                    {
                        "project_id": "my-project",
                        "error": "Failed to record sync mutation",
                    }
                ],
            }
        }


class BackfillStatusResponse(BaseModel):
    """Response body for GET /versions/backfill/status.

    Reports the current state of the async initial-seed backfill task that
    seeds ``ArtifactVersion`` rows for artifacts that have none.

    Attributes:
        status: One of ``idle`` (never started), ``running`` (in progress),
            or ``complete`` (finished — success or partial failure).
        total: Total number of artifacts identified for seeding at task start.
        seeded: Number of artifacts successfully seeded so far.
        failed: Number of artifacts that failed to seed (non-fatal; task
            continues on failure).
        started_at: UTC timestamp when the task was last started, or ``None``
            if it has never been started.
        completed_at: UTC timestamp when the task completed, or ``None`` if
            it is still running or has not started.
    """

    status: Literal["idle", "running", "complete"]
    total: int
    seeded: int
    failed: int
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


# ====================
# Patch Version Schemas (DVCS-5b)
# ====================


class PatchVersionRequest(BaseModel):
    """Request to create a patched version from an existing source version.

    Creates a new ``ArtifactVersion`` with ``change_origin='patch'`` that
    derives content from the supplied *source_version_id* and applies the
    provided *content* as the new version body.

    Attributes:
        source_version_id: UUID hex of the ``ArtifactVersion`` to patch from.
        content: Full artifact content for the new patched version.
        semver_tag: Optional SemVer label (e.g. "v1.2.3") stored on the version.
        message: Optional commit-style message describing the change.
    """

    source_version_id: str = Field(
        description=(
            "UUID hex of the source ArtifactVersion to patch from.  The new version's "
            "``parent_hash`` will point at the source version's content_hash."
        ),
        examples=["a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4"],
    )
    content: str = Field(
        description="Full artifact content for the new patched version.",
        examples=["# My Skill\nUpdated instructions here."],
    )
    semver_tag: Optional[str] = Field(
        default=None,
        description=(
            "Optional SemVer version label (e.g. 'v1.2.3') stored on the new version. "
            "Must match the pattern vMAJOR.MINOR.PATCH."
        ),
        examples=["v1.2.3"],
    )
    message: Optional[str] = Field(
        default=None,
        description="Optional human-readable commit message describing the patch.",
        examples=["Fix typo in usage section"],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "source_version_id": "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4",
                "content": "# My Skill\nUpdated instructions here.",
                "semver_tag": "v1.2.3",
                "message": "Fix typo in usage section",
            }
        }


class PatchVersionResponse(BaseModel):
    """Response from a patch version creation operation.

    Attributes:
        id: UUID hex of the newly created ArtifactVersion.
        artifact_id: Identifier of the artifact (type:name format).
        content_hash: SHA-256 hash of the new version content.
        parent_hash: content_hash of the source version used as parent.
        change_origin: Always ``'patch'`` for versions created by this endpoint.
        semver_tag: SemVer label if provided in the request, otherwise None.
        message: Commit message if provided in the request, otherwise None.
        created_at: UTC timestamp when the version was created.
    """

    id: str = Field(
        description="UUID hex of the newly created ArtifactVersion",
        examples=["b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5"],
    )
    artifact_id: str = Field(
        description="Identifier of the artifact (type:name format)",
        examples=["skill:canvas-design"],
    )
    content_hash: str = Field(
        description="SHA-256 hash of the new version content",
        examples=["a" * 64],
    )
    parent_hash: Optional[str] = Field(
        default=None,
        description="content_hash of the source version used as parent",
        examples=["b" * 64],
    )
    change_origin: str = Field(
        default="patch",
        description="Always 'patch' for versions created by this endpoint",
        examples=["patch"],
    )
    semver_tag: Optional[str] = Field(
        default=None,
        description="SemVer label if provided in the request",
        examples=["v1.2.3"],
    )
    message: Optional[str] = Field(
        default=None,
        description="Commit message if provided in the request",
        examples=["Fix typo in usage section"],
    )
    created_at: Optional[datetime] = Field(
        default=None,
        description="UTC timestamp when the version was created",
        examples=["2026-03-31T10:00:00Z"],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "id": "b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5",
                "artifact_id": "skill:canvas-design",
                "content_hash": "a" * 64,
                "parent_hash": "b" * 64,
                "change_origin": "patch",
                "semver_tag": "v1.2.3",
                "message": "Fix typo in usage section",
                "created_at": "2026-03-31T10:00:00Z",
            }
        }
