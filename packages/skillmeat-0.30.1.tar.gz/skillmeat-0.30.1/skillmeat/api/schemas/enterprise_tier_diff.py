"""Pydantic schemas for enterprise tier-diff API endpoints.

Defines request and response models for comparing artifact state across
enterprise ownership tiers (enterprise, team, developer).

Phase 1: Returns partial results with file-level diff deferred to Phase 2.
Phase 2: File-level unified diffs populated when CAS blob content is available.
"""

from typing import Dict, List, Optional

from pydantic import BaseModel, Field

# ====================
# Sub-models
# ====================


class FileDiff(BaseModel):
    """File-level diff entry within a tier-diff response.

    Populated when CAS (Content-Addressed Storage) blob content is available
    for both tiers being compared (``partial_result=False``).  When the
    response is partial, ``files`` is an empty list and this model is not used.
    """

    path: str = Field(
        description="Relative file path within the artifact",
        examples=["SKILL.md"],
    )
    status: str = Field(
        description=(
            "Change status for this file:\n"
            "- modified: file exists on both sides but content differs\n"
            "- added: file exists only on the right (downstream) side\n"
            "- deleted: file exists only on the left (upstream) side"
        ),
        examples=["modified"],
    )
    unified_diff: str = Field(
        default="",
        description=(
            "Unified diff string in GNU diff format.  Empty string when the "
            "file is identical on both sides or when content is unavailable."
        ),
        examples=["--- a/SKILL.md\n+++ b/SKILL.md\n@@ -1,3 +1,3 @@\n-old\n+new\n"],
    )


class TierContext(BaseModel):
    """Describes the two ownership tiers being compared in a tier-diff operation.

    Each side of the comparison is identified by an owner type and optional
    owner ID. The tier integers follow the hierarchy: enterprise=1, team=2,
    developer=3.
    """

    left_owner_type: str = Field(
        description="Ownership type for the left side of the comparison",
        examples=["enterprise"],
    )
    left_owner_id: Optional[str] = Field(
        default=None,
        description="Unique identifier for the left owner (None for enterprise root)",
        examples=["org-acme"],
    )
    left_tier: int = Field(
        description="Tier level for the left side (1=enterprise, 2=team, 3=developer)",
        examples=[1],
    )
    right_owner_type: str = Field(
        description="Ownership type for the right side of the comparison",
        examples=["team"],
    )
    right_owner_id: Optional[str] = Field(
        default=None,
        description="Unique identifier for the right owner (None when comparing to root)",
        examples=["team-platform"],
    )
    right_tier: int = Field(
        description="Tier level for the right side (1=enterprise, 2=team, 3=developer)",
        examples=[2],
    )


# ====================
# Response Schemas
# ====================


class TierDiffResponse(BaseModel):
    """Response from a tier-diff comparison for a single artifact.

    Represents the synchronization state of an artifact between two ownership
    tiers (e.g., enterprise vs. team, or team vs. developer).

    When ``partial_result=False``, ``files`` contains per-file unified diffs
    computed from CAS blob content.  When ``partial_result=True``, ``files``
    is empty and only hash-level status information is available.
    """

    artifact_id: str = Field(
        description="Artifact identifier in type:name format",
        examples=["skill:pdf-reader"],
    )
    scope: str = Field(
        description="TierComparisonScope value describing which tiers are being compared",
        examples=["enterprise_vs_team"],
    )
    tier_context: TierContext = Field(
        description="Details of the two ownership tiers being compared",
    )
    has_diverged: bool = Field(
        description="Whether the artifact has diverged between the two tiers",
        examples=[True],
    )
    sync_status: str = Field(
        description=(
            "Synchronization status:\n"
            "- current: artifact is identical on both sides\n"
            "- outdated: right side lags behind left side\n"
            "- diverged: both sides have independent changes"
        ),
        examples=["outdated"],
    )
    left_hash: Optional[str] = Field(
        default=None,
        description="Content hash on the left (higher) tier (None if artifact absent)",
        examples=["abc123def456"],
    )
    right_hash: Optional[str] = Field(
        default=None,
        description="Content hash on the right (lower) tier (None if artifact absent)",
        examples=["def456abc789"],
    )
    diverged_files: List[str] = Field(
        default_factory=list,
        description="Paths of files that differ between the two tiers",
        examples=[["SKILL.md", "src/handler.py"]],
    )
    files: List[FileDiff] = Field(
        default_factory=list,
        description=(
            "File-level diff details.  Empty when ``partial_result=True`` "
            "(CAS content unavailable).  Populated with :class:`FileDiff` "
            "entries when ``partial_result=False`` and CAS blob content is "
            "available for both tiers."
        ),
    )
    summary: Dict[str, int] = Field(
        default_factory=lambda: {
            "added": 0,
            "modified": 0,
            "deleted": 0,
            "unchanged": 0,
        },
        description=(
            "Aggregate file change counts across the diff.\n"
            "Keys: added, modified, deleted, unchanged."
        ),
        examples=[{"added": 1, "modified": 2, "deleted": 0, "unchanged": 5}],
    )
    partial_result: bool = Field(
        default=True,
        description=(
            "True when the response omits file-level content diffs because CAS "
            "blob content was unavailable for one or both tier hashes.  False "
            "when ``files`` contains complete unified diff data."
        ),
        examples=[True],
    )

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "artifact_id": "skill:pdf-reader",
                "scope": "enterprise_vs_team",
                "tier_context": {
                    "left_owner_type": "enterprise",
                    "left_owner_id": "org-acme",
                    "left_tier": 1,
                    "right_owner_type": "team",
                    "right_owner_id": "team-platform",
                    "right_tier": 2,
                },
                "has_diverged": True,
                "sync_status": "outdated",
                "left_hash": "abc123def456",
                "right_hash": "def456abc789",
                "diverged_files": ["SKILL.md"],
                "files": [],
                "summary": {
                    "added": 0,
                    "modified": 1,
                    "deleted": 0,
                    "unchanged": 3,
                },
                "partial_result": True,
            }
        }
