"""Pydantic schemas for VCS v2 API endpoints (artifact-vcs-v2).

Defines request and response models for collection version tracking,
project deployment topology, version set management, and promote/sync
operations introduced in the artifact-vcs-v2 feature.
"""

from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

# ---------------------------------------------------------------------------
# Change origin type
# ---------------------------------------------------------------------------

#: All valid ``change_origin`` values for ``ArtifactVersion`` rows.
#: Mirrors the CHECK constraint in ``artifact_versions`` (models.py line 778-780).
ChangeOrigin = Literal[
    "initial_seed",
    "deployment",
    "sync",
    "local_modification",
    "restore",
    "promotion",
    "push",
    "github_update",
    "import",
    "policy_enforcement",
    "composite_update",
    "rename",
    "patch",
    "auto_capture",
]


# ---------------------------------------------------------------------------
# VersionSet
# ---------------------------------------------------------------------------


class VersionSetDTO(BaseModel):
    """Logical grouping of related ArtifactVersion rows.

    A VersionSet represents a bounded lineage of artifact versions that share
    a common ancestor chain.  The ``depth_limit`` controls how many historical
    versions are retained before the oldest are pruned.
    """

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": {
                "id": "a1b2c3d4e5f6",
                "depth_limit": 10,
                "created_at": "2026-01-15T10:30:00Z",
            }
        },
    )

    id: str = Field(
        description="UUID hex primary key of the version set",
        examples=["a1b2c3d4e5f6"],
    )
    depth_limit: int = Field(
        description="Maximum number of versions retained in this set",
        examples=[10],
    )
    created_at: datetime = Field(
        description="UTC timestamp when the version set was created",
        examples=["2026-01-15T10:30:00Z"],
    )


# ---------------------------------------------------------------------------
# ArtifactCollectionVersion
# ---------------------------------------------------------------------------


class ArtifactCollectionVersionDTO(BaseModel):
    """Current collection-side version record for a single artifact.

    One row per artifact (unique on ``artifact_id``).  Points at the
    ``ArtifactVersion`` that represents the content currently held in the
    collection, along with its raw content hash.
    """

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": {
                "id": "b2c3d4e5f6a1",
                "artifact_id": "skill:canvas-design",
                "version_id": "c3d4e5f6a1b2",
                "current_hash": "a" * 64,
                "updated_at": "2026-02-01T08:00:00Z",
            }
        },
    )

    id: str = Field(
        description="UUID hex primary key",
        examples=["b2c3d4e5f6a1"],
    )
    artifact_id: str = Field(
        description="FK to artifacts.id — identifies the artifact",
        examples=["skill:canvas-design"],
    )
    version_id: str = Field(
        description="FK to artifact_versions.id — the current collection version entry",
        examples=["c3d4e5f6a1b2"],
    )
    current_hash: str = Field(
        description="SHA-256 content hash of the current collection version",
        examples=["a" * 64],
    )
    updated_at: datetime = Field(
        description="UTC timestamp of the last update to this record",
        examples=["2026-02-01T08:00:00Z"],
    )


# ---------------------------------------------------------------------------
# ProjectVersionDeployment
# ---------------------------------------------------------------------------


class ProjectVersionDeploymentDTO(BaseModel):
    """Append-only deployment event record for a single artifact + project pair.

    Each row records one deployment event: which artifact was deployed to which
    project, what content hash it carried, and whether it was pinned.  Rows are
    never modified after insert (append-only audit log).
    """

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": {
                "id": "d4e5f6a1b2c3",
                "artifact_id": "skill:canvas-design",
                "project_id": "proj:my-project",
                "content_hash": "b" * 64,
                "pinned": False,
                "deployed_at": "2026-02-10T12:00:00Z",
                "updated_at": "2026-02-10T12:00:00Z",
                "project_name": "my-project",
            }
        },
    )

    id: str = Field(
        description="UUID hex primary key of this deployment event",
        examples=["d4e5f6a1b2c3"],
    )
    artifact_id: str = Field(
        description="FK to artifacts.id — identifies the deployed artifact",
        examples=["skill:canvas-design"],
    )
    project_id: str = Field(
        description="FK to projects.id — identifies the target project",
        examples=["proj:my-project"],
    )
    content_hash: str = Field(
        description="SHA-256 hash of the artifact content at deployment time",
        examples=["b" * 64],
    )
    pinned: bool = Field(
        description="When True the deployed version is locked against auto-updates",
        examples=[False],
    )
    deployed_at: datetime = Field(
        description="UTC timestamp of the deployment event",
        examples=["2026-02-10T12:00:00Z"],
    )
    updated_at: datetime = Field(
        description="UTC timestamp set once at insert; not updated thereafter",
        examples=["2026-02-10T12:00:00Z"],
    )
    # Joined / computed field — populated by topology queries, not by ORM
    project_name: Optional[str] = Field(
        default=None,
        description="Human-readable project name (joined field, absent in basic lookups)",
        examples=["my-project"],
    )


# ---------------------------------------------------------------------------
# Topology
# ---------------------------------------------------------------------------


class VersionTopologyDTO(BaseModel):
    """Collection version plus all project deployments for a single artifact.

    Used by topology query endpoints to return a complete picture of where an
    artifact currently lives across the collection and all projects.
    """

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": {
                "artifact_id": "skill:canvas-design",
                "collection_version": None,
                "deployments": [],
            }
        },
    )

    artifact_id: str = Field(
        description="Unique identifier of the artifact",
        examples=["skill:canvas-design"],
    )
    collection_version: Optional[ArtifactCollectionVersionDTO] = Field(
        default=None,
        description="Current collection-side version record (absent if never tracked)",
    )
    deployments: List[ProjectVersionDeploymentDTO] = Field(
        default_factory=list,
        description="All project deployment records for this artifact",
    )


# ---------------------------------------------------------------------------
# Conflict
# ---------------------------------------------------------------------------


class ConflictDTO(BaseModel):
    """Conflict response when a promote request fails a hash precondition check.

    Returned with HTTP 409 when the caller supplies ``expected_collection_hash``
    and it does not match the live ``ArtifactCollectionVersion.current_hash``.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "artifact_id": "skill:canvas-design",
                "expected_hash": "a" * 64,
                "actual_hash": "b" * 64,
                "detail": "Hash mismatch: collection was updated since the request was formed.",
            }
        }
    )

    artifact_id: str = Field(
        description="Identifier of the artifact involved in the conflict",
        examples=["skill:canvas-design"],
    )
    expected_hash: str = Field(
        description="The collection hash supplied by the caller",
        examples=["a" * 64],
    )
    actual_hash: str = Field(
        description="The current collection hash in the database",
        examples=["b" * 64],
    )
    detail: str = Field(
        default="Hash mismatch: collection was updated since the request was formed.",
        description="Human-readable conflict description",
    )


# ---------------------------------------------------------------------------
# Promote
# ---------------------------------------------------------------------------


class PromoteRequestDTO(BaseModel):
    """Request to promote a collection version to a project deployment.

    Creates a new ``ProjectVersionDeployment`` row pointing at the given
    ``content_hash`` for the ``(artifact_id, project_id)`` pair.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "artifact_id": "skill:canvas-design",
                "project_id": "proj:my-project",
                "content_hash": "a" * 64,
                "pinned": False,
            }
        }
    )

    artifact_id: str = Field(
        description="Identifier of the artifact to promote",
        examples=["skill:canvas-design"],
    )
    project_id: str = Field(
        description="Identifier of the target project",
        examples=["proj:my-project"],
    )
    content_hash: str = Field(
        description="SHA-256 content hash of the version to promote",
        examples=["a" * 64],
    )
    pinned: bool = Field(
        default=False,
        description="When True the promoted version is locked against auto-updates",
        examples=[False],
    )


class PromoteArtifactRequestDTO(BaseModel):
    """Request body for ``POST /versions/artifacts/{artifact_id}/promote``.

    Promotes the artifact's current project deployment content hash into the
    collection version record, creating a new ``ArtifactVersion`` row with
    ``change_origin='push'`` and updating ``ArtifactCollectionVersion``.

    ``artifact_id`` is taken from the path; this body provides the source
    project and optional optimistic-concurrency guard hash.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "source_project_id": "proj:my-project",
                "message": "Promote from my-project after local edits",
                "version_label": "v1.1.0",
                "expected_collection_hash": None,
            }
        }
    )

    source_project_id: str = Field(
        description="Project whose latest deployment hash becomes the new collection version",
        examples=["proj:my-project"],
    )
    message: Optional[str] = Field(
        default=None,
        description="Optional human-readable description stored on the new ArtifactVersion",
    )
    version_label: Optional[str] = Field(
        default=None,
        description="Optional short label (e.g. 'v1.1.0') stored on the new ArtifactVersion",
    )
    expected_collection_hash: Optional[str] = Field(
        default=None,
        description=(
            "Optimistic-concurrency guard: when supplied the endpoint returns 409 "
            "if the live collection hash no longer matches this value."
        ),
    )


class PromoteArtifactResponseDTO(BaseModel):
    """Response body for ``POST /versions/artifacts/{artifact_id}/promote``."""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "artifact_id": "skill:canvas-design",
                "new_collection_hash": "a" * 64,
                "promotion_request_id": None,
                "was_no_op": False,
            }
        }
    )

    artifact_id: str = Field(
        description="Identifier of the promoted artifact",
        examples=["skill:canvas-design"],
    )
    new_collection_hash: Optional[str] = Field(
        default=None,
        description="SHA-256 hash written to ArtifactCollectionVersion (local edition only)",
        examples=["a" * 64],
    )
    promotion_request_id: Optional[str] = Field(
        default=None,
        description=(
            "Enterprise only: UUID of the created PromotionRequest row. "
            "``None`` in local edition."
        ),
    )
    was_no_op: bool = Field(
        default=False,
        description="True when the collection hash already matched and no write was needed",
    )


class PromoteResponseDTO(BaseModel):
    """Response from a promote operation."""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "deployment": {
                    "id": "d4e5f6a1b2c3",
                    "artifact_id": "skill:canvas-design",
                    "project_id": "proj:my-project",
                    "content_hash": "a" * 64,
                    "pinned": False,
                    "deployed_at": "2026-03-01T10:00:00Z",
                    "updated_at": "2026-03-01T10:00:00Z",
                    "project_name": None,
                },
                "was_already_deployed": False,
            }
        }
    )

    deployment: ProjectVersionDeploymentDTO = Field(
        description="The newly created (or existing) deployment record",
    )
    was_already_deployed: bool = Field(
        default=False,
        description=(
            "True when an identical deployment already existed and no new row was written"
        ),
        examples=[False],
    )


# ---------------------------------------------------------------------------
# Sync all
# ---------------------------------------------------------------------------


class SyncAllResponseDTO(BaseModel):
    """Response from a bulk sync operation across all project deployments.

    Returned by endpoints that reconcile the latest collection version against
    every project that has the artifact deployed (non-pinned entries only).
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "synced_count": 3,
                "skipped_count": 1,
                "errors": [],
            }
        }
    )

    synced_count: int = Field(
        description="Number of project deployments that were updated",
        examples=[3],
    )
    skipped_count: int = Field(
        description="Number of project deployments skipped (pinned or already current)",
        examples=[1],
    )
    errors: List[str] = Field(
        default_factory=list,
        description="Error messages for any deployments that could not be synced",
        examples=[[]],
    )


# ---------------------------------------------------------------------------
# Async sync job tracking
# ---------------------------------------------------------------------------


class SyncJobTriggerResponse(BaseModel):
    """Response when sync-all job is triggered asynchronously.

    The sync runs in the background. Use GET /sync-jobs/{job_id} to poll status.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "job_id": "sync-job-123e4567-e89b-12d3-a456-426614174000",
                "status": "pending",
                "artifact_id": "skill:canvas-design",
                "created_at": "2024-01-06T12:00:00Z",
            }
        }
    )

    job_id: str = Field(
        description="Unique job identifier for polling status",
        examples=["sync-job-123e4567-e89b-12d3-a456-426614174000"],
    )
    status: Literal["pending"] = Field(
        description="Always 'pending' when job is first triggered", examples=["pending"]
    )
    artifact_id: str = Field(
        description="Artifact being synced", examples=["skill:canvas-design"]
    )
    created_at: datetime = Field(
        description="When the job was created (UTC)", examples=["2024-01-06T12:00:00Z"]
    )


class SyncJobStatusResponse(BaseModel):
    """Status response for a sync-all job.

    Used for polling job progress and retrieving results.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "job_id": "sync-job-123e4567-e89b-12d3-a456-426614174000",
                "status": "completed",
                "artifact_id": "skill:canvas-design",
                "created_at": "2024-01-06T12:00:00Z",
                "started_at": "2024-01-06T12:00:01Z",
                "completed_at": "2024-01-06T12:00:15Z",
                "result": {"synced_count": 3, "skipped_count": 1, "errors": []},
                "error_message": None,
            }
        }
    )

    job_id: str = Field(
        description="Job identifier",
        examples=["sync-job-123e4567-e89b-12d3-a456-426614174000"],
    )
    status: Literal["pending", "running", "completed", "failed"] = Field(
        description="Current job status", examples=["completed"]
    )
    artifact_id: str = Field(
        description="Artifact being synced", examples=["skill:canvas-design"]
    )
    created_at: datetime = Field(
        description="When the job was created (UTC)", examples=["2024-01-06T12:00:00Z"]
    )
    started_at: Optional[datetime] = Field(
        default=None,
        description="When the job started processing (UTC)",
        examples=["2024-01-06T12:00:01Z"],
    )
    completed_at: Optional[datetime] = Field(
        default=None,
        description="When the job finished (UTC)",
        examples=["2024-01-06T12:00:15Z"],
    )
    result: Optional[SyncAllResponseDTO] = Field(
        default=None, description="Sync results when job is completed successfully"
    )
    error_message: Optional[str] = Field(
        default=None, description="Error details when job status is 'failed'"
    )
