"""Pydantic schemas for enterprise admin sync API endpoints.

Defines request and response models for the Admin Sync Dashboard, which
surfaces org-wide sync health, compliance audits, operation logs, and
forced propagation controls — consumable by enterprise_admin role only.

Phase 3: Org-wide aggregate views, compliance audit, operation log, and
propagation job tracking. Per-team drill-down and file-level diffs are
deferred to a future phase.
"""

from __future__ import annotations

from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from skillmeat.api.schemas.enterprise_team_sync import TeamSyncSummary

__all__ = [
    "OrgSyncHealthResponse",
    "ComplianceAuditEntry",
    "ComplianceAuditResponse",
    "SyncOperationLogEntry",
    "SyncOperationsLogResponse",
    "PropagationJobResponse",
    "PropagationRequest",
    "PropagationPRLinkEntry",
    "PropagationPRLinksResponse",
]

# ====================
# Org-wide Health
# ====================


class OrgSyncHealthResponse(BaseModel):
    """Org-wide sync health aggregate across all teams.

    Top-level summary consumed by the Admin Sync Dashboard banner.
    Each team's individual summary is included in ``teams`` so the
    frontend can render per-team rows without a second request.
    """

    model_config = ConfigDict(from_attributes=True)

    team_count: int = Field(
        description="Total number of teams in this organization",
        examples=[12],
    )
    total_artifacts: int = Field(
        description="Sum of artifact counts across all teams (may count the same "
        "artifact multiple times when shared across teams)",
        examples=[480],
    )
    fully_current_teams: int = Field(
        description="Number of teams where all artifacts are fully in sync",
        examples=[8],
    )
    teams_with_divergence: int = Field(
        description="Number of teams with at least one diverged or outdated artifact",
        examples=[4],
    )
    teams: List[TeamSyncSummary] = Field(
        default_factory=list,
        description="Per-team sync health summaries, one entry per team",
    )


# ====================
# Compliance Audit
# ====================


class ComplianceAuditEntry(BaseModel):
    """Compliance check result for a single project within a team.

    Records whether a project satisfies all forced-artifact requirements
    imposed by the team's governance policy.
    """

    model_config = ConfigDict(from_attributes=True)

    project_id: str = Field(
        description="Unique identifier for the project",
        examples=["proj-abc123"],
    )
    project_name: str = Field(
        description="Human-readable project name",
        examples=["backend-api"],
    )
    team_id: str = Field(
        description="UUID of the team that owns this project (as string)",
        examples=["a1b2c3d4-e5f6-7890-abcd-123456789012"],
    )
    forced_artifact_ids: List[str] = Field(
        default_factory=list,
        description="Artifact IDs (type:name format) that are required by team policy",
        examples=[["skill:security-scanner", "command:run-tests"]],
    )
    compliance_status: Literal["compliant", "non_compliant"] = Field(
        description=(
            "Compliance result for this project:\n"
            "- compliant: all forced artifacts are deployed at the correct version\n"
            "- non_compliant: one or more forced artifacts are missing or outdated"
        ),
        examples=["compliant"],
    )
    checked_at: Optional[datetime] = Field(
        default=None,
        description="UTC datetime when this compliance check was last performed. "
        "None when the project has never been checked.",
        examples=["2026-04-04T12:00:00Z"],
    )


class ComplianceAuditResponse(BaseModel):
    """Full compliance audit response across all projects.

    Aggregates per-project compliance entries and surfaces a non-compliant
    count so the dashboard can render a health badge without iterating entries.
    """

    model_config = ConfigDict(from_attributes=True)

    entries: List[ComplianceAuditEntry] = Field(
        default_factory=list,
        description="Compliance check results, one entry per project",
    )
    non_compliant_count: int = Field(
        description="Number of projects currently in non_compliant state",
        examples=[3],
    )
    checked_at: datetime = Field(
        description="UTC datetime when this compliance summary was generated",
        examples=["2026-04-04T12:00:00Z"],
    )


# ====================
# Operation Log
# ====================


class SyncOperationLogEntry(BaseModel):
    """Single entry in the org-wide sync operation log.

    Captures metadata about a past or in-progress sync operation —
    who triggered it, which team and artifacts were targeted, and
    the final outcome.
    """

    model_config = ConfigDict(from_attributes=True)

    operation_id: str = Field(
        description="Unique identifier for this sync operation (UUID as string)",
        examples=["550e8400-e29b-41d4-a716-446655440000"],
    )
    operation_type: str = Field(
        description=(
            "Type of sync operation performed:\n"
            "- push_baseline: team baseline pushed to developer copies\n"
            "- pull_all: upstream changes pulled into team baseline\n"
            "- sync_all: full reconciliation of all developer copies\n"
            "- propagate: admin-initiated forced propagation across teams"
        ),
        examples=["propagate"],
    )
    team_id: Optional[str] = Field(
        default=None,
        description="UUID of the team targeted by this operation. "
        "None for org-wide operations that span multiple teams.",
        examples=["a1b2c3d4-e5f6-7890-abcd-123456789012"],
    )
    team_name: Optional[str] = Field(
        default=None,
        description="Display name of the team, if team-scoped. None for org-wide operations.",
        examples=["Platform Team"],
    )
    triggered_by: Optional[str] = Field(
        default=None,
        description="Identity of the user or system that triggered this operation. "
        "None when the trigger source is unknown or system-initiated.",
        examples=["admin@example.com"],
    )
    status: str = Field(
        description=(
            "Current status of the operation:\n"
            "- queued: waiting to start\n"
            "- running: in progress\n"
            "- complete: finished successfully\n"
            "- failed: finished with errors\n"
            "- partial: finished with some failures"
        ),
        examples=["complete"],
    )
    artifact_count: int = Field(
        description="Number of artifacts affected by this operation",
        examples=[14],
    )
    started_at: datetime = Field(
        description="UTC datetime when this operation started",
        examples=["2026-04-04T11:55:00Z"],
    )
    completed_at: Optional[datetime] = Field(
        default=None,
        description="UTC datetime when this operation finished. "
        "None when the operation is still running or queued.",
        examples=["2026-04-04T11:57:30Z"],
    )


class SyncOperationsLogResponse(BaseModel):
    """Paginated list of sync operation log entries.

    Supports filtering by team and operation type via query parameters
    on the endpoint. ``total`` reflects the unfiltered count before
    the ``limit`` is applied.
    """

    model_config = ConfigDict(from_attributes=True)

    entries: List[SyncOperationLogEntry] = Field(
        default_factory=list,
        description="Sync operation log entries for the requested page",
    )
    total: int = Field(
        description="Total number of log entries matching the applied filters",
        examples=[157],
    )


# ====================
# Propagation Job
# ====================


class PropagationJobResponse(BaseModel):
    """Status and progress of a forced-propagation job.

    A propagation job pushes one or more artifacts across multiple teams.
    Progress is tracked per-team so the frontend can render a progress bar
    and surface per-team error details without polling multiple endpoints.
    """

    model_config = ConfigDict(from_attributes=True)

    job_id: str = Field(
        description="Unique identifier for this propagation job (UUID as string)",
        examples=["6ba7b810-9dad-11d1-80b4-00c04fd430c8"],
    )
    status: Literal["queued", "running", "complete", "failed"] = Field(
        description=(
            "Current status of the propagation job:\n"
            "- queued: accepted, waiting to start\n"
            "- running: actively propagating\n"
            "- complete: all teams processed (some may have failed)\n"
            "- failed: job aborted due to a fatal error"
        ),
        examples=["running"],
    )
    teams_total: int = Field(
        description="Total number of teams targeted by this job",
        examples=[10],
    )
    teams_complete: int = Field(
        description="Number of teams for which propagation has finished (success or failure)",
        examples=[6],
    )
    teams_failed: int = Field(
        description="Number of teams where propagation failed",
        examples=[1],
    )
    artifacts_updated: int = Field(
        description="Cumulative count of artifact deployments updated across all teams",
        examples=[42],
    )
    progress_pct: float = Field(
        description="Progress as a percentage (0.0–100.0). "
        "Computed as teams_complete / teams_total * 100.",
        examples=[60.0],
        ge=0.0,
        le=100.0,
    )
    started_at: Optional[datetime] = Field(
        default=None,
        description="UTC datetime when this job started executing. "
        "None when still queued.",
        examples=["2026-04-04T12:00:00Z"],
    )
    completed_at: Optional[datetime] = Field(
        default=None,
        description="UTC datetime when this job finished. "
        "None when still running or queued.",
        examples=["2026-04-04T12:05:00Z"],
    )
    errors: Optional[List[dict]] = Field(
        default=None,
        description="Per-team error details when one or more teams failed. "
        "Each dict contains at minimum 'team_id' and 'message' keys. "
        "None when no errors have occurred.",
        examples=[[{"team_id": "a1b2c3d4", "message": "timeout after 30s"}]],
    )


# ====================
# PR Links
# ====================


class PropagationPRLinkEntry(BaseModel):
    """A single pull request created or updated as part of a propagation operation.

    Each entry represents one PR in the VCS (e.g. GitHub) that was opened
    to apply hard-update changes to a target team or project.
    """

    model_config = ConfigDict(from_attributes=True)

    pr_id: str = Field(
        description="Stable identifier for this PR entry (operation_id + index)",
        examples=["550e8400-e29b-41d4-a716-446655440000-pr-0"],
    )
    team_id: str = Field(
        description="Identifier of the team or project targeted by this PR",
        examples=["a1b2c3d4-e5f6-7890-abcd-123456789012"],
    )
    team_name: str = Field(
        description="Human-readable name of the team or project",
        examples=["Platform Team"],
    )
    title: str = Field(
        description="PR title as displayed in the VCS",
        examples=["Hard update PR #1"],
    )
    url: str = Field(
        description="Full URL to the pull request in the VCS",
        examples=["https://github.com/org/repo/pull/42"],
    )
    status: Literal["open", "merged", "closed"] = Field(
        description=(
            "Current status of the pull request in the VCS:\n"
            "- open: PR is still open and awaiting review/merge\n"
            "- merged: PR was accepted and merged\n"
            "- closed: PR was closed without merging"
        ),
        examples=["open"],
    )


class PropagationPRLinksResponse(BaseModel):
    """Response containing all PR links for a propagation operation.

    Returns the set of pull requests opened by a GitOps hard-update
    propagation.  One PR is created per active Git connection for the
    target project.
    """

    model_config = ConfigDict(from_attributes=True)

    operation_id: str = Field(
        description="Unique identifier of the propagation operation (UUID as string)",
        examples=["550e8400-e29b-41d4-a716-446655440000"],
    )
    teams: List[str] = Field(
        default_factory=list,
        description="Names or IDs of the teams/projects targeted by the hard update",
        examples=[["a1b2c3d4-e5f6-7890-abcd-123456789012"]],
    )
    artifacts: List[str] = Field(
        default_factory=list,
        description="Artifact IDs (UUID or type:name format) included in this hard update",
        examples=[["skill:security-scanner", "command:run-tests"]],
    )
    pr_links: List[PropagationPRLinkEntry] = Field(
        default_factory=list,
        description="One PR link entry per pull request created during this operation",
    )
    created_at: datetime = Field(
        description="UTC datetime when this propagation operation was initiated",
        examples=["2026-04-04T12:00:00Z"],
    )


class PropagationRequest(BaseModel):
    """Request body for triggering a forced-propagation job.

    Specifies which teams and artifacts to target, and whether to use
    soft (non-breaking) or hard (overwrite-all) propagation semantics.
    """

    model_config = ConfigDict(from_attributes=True)

    team_ids: List[str] = Field(
        description="UUIDs (as strings) of the teams to receive the propagation",
        examples=[["a1b2c3d4-e5f6-7890-abcd-123456789012"]],
    )
    artifact_ids: Optional[List[str]] = Field(
        default=None,
        description="Artifact IDs (type:name format) to propagate. "
        "When None, all artifacts governed by team policy are propagated.",
        examples=[["skill:security-scanner", "command:run-tests"]],
    )
    mode: Literal["soft", "hard"] = Field(
        description=(
            "Propagation mode:\n"
            "- soft: only update artifacts that are outdated or missing\n"
            "- hard: overwrite all targeted artifacts regardless of current state"
        ),
        examples=["soft"],
    )
