"""Pydantic schemas for enterprise team sync dashboard API endpoints.

Defines request and response models for the Team Sync Dashboard, which
surfaces sync health of all artifacts for a given team — consumable by
team_admin and system_admin roles.

Phase 1: Summary-level sync health per artifact with per-developer divergence
counts. File-level content diffs are deferred to a future phase.
"""

from typing import List, Optional

from pydantic import BaseModel, Field

# ====================
# Sub-models
# ====================


class DeveloperDivergenceInfo(BaseModel):
    """Sync divergence details for a single developer within a team.

    Represents how an individual developer's local copy of an artifact
    relates to the team baseline.
    """

    developer_id: str = Field(
        description="UUID of the developer (as string)",
        examples=["d3f1a2b4-5c6e-7890-abcd-ef1234567890"],
    )
    developer_name: str = Field(
        description="Display name of the developer",
        examples=["alice"],
    )
    tier_status: str = Field(
        description=(
            "Sync status of this developer's copy relative to the team baseline:\n"
            "- current: matches the team baseline\n"
            "- outdated: developer lags behind the team baseline\n"
            "- diverged: developer has independent changes from the team baseline"
        ),
        examples=["outdated"],
    )


class TeamArtifactSyncRow(BaseModel):
    """Sync state for a single artifact within a team.

    Aggregates per-developer divergence counts and lists which developers
    have copies that differ from the team baseline. Also captures whether
    the team baseline itself is out of date relative to the upstream source.
    """

    artifact_id: str = Field(
        description="Artifact identifier in type:name format",
        examples=["skill:pdf-reader"],
    )
    artifact_name: str = Field(
        description="Human-readable artifact name",
        examples=["pdf-reader"],
    )
    artifact_type: str = Field(
        description="Artifact type string (e.g. skill, command, agent)",
        examples=["skill"],
    )
    upstream_status: Optional[str] = Field(
        default=None,
        description=(
            "Sync status of the team baseline relative to the upstream source.\n"
            "None when no upstream source is configured for this artifact."
        ),
        examples=["outdated"],
    )
    tier_status: str = Field(
        description=(
            "Overall sync status of the team baseline:\n"
            "- current: all developer copies match the baseline\n"
            "- outdated: one or more developers lag behind the baseline\n"
            "- diverged: one or more developers have independent changes"
        ),
        examples=["diverged"],
    )
    diverged_developer_count: int = Field(
        description="Number of developers whose copy differs from the team baseline",
        examples=[2],
    )
    diverged_developers: List[DeveloperDivergenceInfo] = Field(
        default_factory=list,
        description="Details for each developer whose copy differs from the team baseline",
    )


# ====================
# Response Schemas
# ====================


class TeamSyncSummary(BaseModel):
    """High-level sync health summary for a team.

    Aggregate counts across all artifacts in the team, used to render the
    summary banner at the top of the Team Sync Dashboard.
    """

    team_id: str = Field(
        description="UUID of the team (as string)",
        examples=["a1b2c3d4-e5f6-7890-abcd-123456789012"],
    )
    team_name: str = Field(
        description="Display name of the team",
        examples=["Platform Team"],
    )
    artifact_count: int = Field(
        description="Total number of artifacts tracked for this team",
        examples=[42],
    )
    diverged_count: int = Field(
        description="Number of artifacts where at least one developer has diverged",
        examples=[5],
    )
    outdated_count: int = Field(
        description="Number of artifacts where at least one developer is outdated",
        examples=[8],
    )
    current_count: int = Field(
        description="Number of artifacts where all developers are in sync",
        examples=[29],
    )
    last_sync_at: Optional[str] = Field(
        default=None,
        description="ISO 8601 datetime of the most recent sync operation (None if never synced)",
        examples=["2026-04-04T12:00:00Z"],
    )


class TeamSyncDashboardResponse(BaseModel):
    """Full response for the Team Sync Dashboard endpoint.

    Combines a high-level summary with a per-artifact breakdown, giving
    team_admin and system_admin roles a complete picture of team sync health.
    """

    summary: TeamSyncSummary = Field(
        description="Aggregate sync health summary for the team",
    )
    artifacts: List[TeamArtifactSyncRow] = Field(
        default_factory=list,
        description="Per-artifact sync state rows, one entry per tracked artifact",
    )

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "summary": {
                    "team_id": "a1b2c3d4-e5f6-7890-abcd-123456789012",
                    "team_name": "Platform Team",
                    "artifact_count": 42,
                    "diverged_count": 5,
                    "outdated_count": 8,
                    "current_count": 29,
                    "last_sync_at": "2026-04-04T12:00:00Z",
                },
                "artifacts": [
                    {
                        "artifact_id": "skill:pdf-reader",
                        "artifact_name": "pdf-reader",
                        "artifact_type": "skill",
                        "upstream_status": "outdated",
                        "tier_status": "diverged",
                        "diverged_developer_count": 2,
                        "diverged_developers": [
                            {
                                "developer_id": "d3f1a2b4-5c6e-7890-abcd-ef1234567890",
                                "developer_name": "alice",
                                "tier_status": "diverged",
                            },
                            {
                                "developer_id": "e4f2b3c5-6d7f-8901-bcde-f01234567891",
                                "developer_name": "bob",
                                "tier_status": "outdated",
                            },
                        ],
                    }
                ],
            }
        }


# ====================
# Request Schemas
# ====================


class BulkSyncRequest(BaseModel):
    """Request body for bulk sync operations on a team's artifacts.

    Allows team_admin and system_admin roles to trigger synchronization
    across selected artifacts or developers in a single call.
    """

    operation: str = Field(
        description=(
            "Bulk sync operation to perform:\n"
            "- push_baseline: push the team baseline out to selected developers\n"
            "- pull_all: pull updates from upstream into the team baseline\n"
            "- sync_all: reconcile all developer copies against the team baseline"
        ),
        examples=["push_baseline"],
    )
    artifact_ids: Optional[List[str]] = Field(
        default=None,
        description=(
            "Artifact IDs (type:name format) to include in the operation. "
            "When None, all team artifacts are targeted."
        ),
        examples=[["skill:pdf-reader", "command:run-tests"]],
    )
    developer_ids: Optional[List[str]] = Field(
        default=None,
        description=(
            "Developer UUIDs (as strings) to include in the operation. "
            "When None, all team developers are targeted."
        ),
        examples=[["d3f1a2b4-5c6e-7890-abcd-ef1234567890"]],
    )


class BulkSyncResponse(BaseModel):
    """Response from a bulk sync operation.

    Returns the number of individual sync jobs queued and their operation IDs,
    which can be used to poll for status via the sync-capture endpoints.
    """

    queued: int = Field(
        description="Number of individual sync jobs queued for execution",
        examples=[14],
    )
    operation_ids: List[str] = Field(
        description="Identifiers for each queued sync operation (UUIDs as strings)",
        examples=[["op-abc123", "op-def456"]],
    )

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "queued": 14,
                "operation_ids": [
                    "550e8400-e29b-41d4-a716-446655440000",
                    "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
                ],
            }
        }
