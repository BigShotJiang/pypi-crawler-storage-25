"""Pydantic schemas for sync-capture notification and status endpoints."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class TriggerSource(str, Enum):
    """Source that triggered a sync-capture notification."""

    fs_watcher = "fs_watcher"
    cli = "cli"
    external = "external"


class SyncCaptureNotifyRequest(BaseModel):
    """Request body for POST /sync-capture/notify."""

    artifact_id: str = Field(
        ...,
        description=(
            "Artifact primary key in 'type:name' format " "(e.g. 'skill:my-skill')."
        ),
        examples=["skill:my-skill"],
    )
    content_hash: str = Field(
        ...,
        description=(
            "Hex content hash (SHA-256 or similar) detected for the artifact. "
            "Must be a non-empty hexadecimal string."
        ),
        min_length=8,
        max_length=128,
        pattern=r"^[0-9a-fA-F]+$",
        examples=["a1b2c3d4e5f67890"],
    )
    trigger_source: TriggerSource = Field(
        ...,
        description="The source that detected the change.",
    )


class SyncCaptureNotifyResponse(BaseModel):
    """Response body for a successful POST /sync-capture/notify."""

    status: str = Field(
        default="accepted",
        description="Always 'accepted' on a 202 response.",
    )
    debounce_entry_id: Optional[str] = Field(
        None,
        description=(
            "The ID of the debounce entry that was created or refreshed. "
            "May be None if the repository does not expose the ID directly."
        ),
    )
    artifact_id: str = Field(
        ...,
        description="Echo of the artifact_id from the request.",
    )


class SyncCaptureStatusResponse(BaseModel):
    """Response body for GET /sync-capture/status."""

    enabled: bool = Field(
        ...,
        description="Whether sync capture is currently enabled.",
    )
    fs_watcher_enabled: bool = Field(
        ...,
        description=(
            "Whether the filesystem watcher sub-feature is enabled. "
            "Always False when 'enabled' is False."
        ),
    )
    auto_scan_enabled: bool = Field(
        ...,
        description=(
            "Whether the background auto-scan is enabled. "
            "Always False when 'enabled' is False."
        ),
    )
    pending_count: int = Field(
        default=0,
        description="Number of debounce entries currently in 'pending' state.",
    )
    quiet_seconds: int = Field(
        ...,
        description="Configured quiet-window duration in seconds.",
    )
    scan_interval_seconds: int = Field(
        ...,
        description="Configured background-scan interval in seconds.",
    )
    checked_at: datetime = Field(
        ...,
        description="Server UTC timestamp when this status was collected.",
    )
