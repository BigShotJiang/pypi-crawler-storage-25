"""Pydantic schemas for IDP (Internal Developer Portal) integration endpoints.

Defines request and response models for Backstage/IDP scaffold generation and
deployment registration operations.
"""

import re
from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

# ====================
# Shared Helpers
# ====================

_TARGET_ID_PATTERN = re.compile(r"^[a-zA-Z0-9_-]+:[a-zA-Z0-9_/-]+$")

# Accepts composite:* or bundle:<slug-or-uuid>
# UUID format: 8-4-4-4-12 hex digits (e.g. 550e8400-e29b-41d4-a716-446655440000)
_SCAFFOLD_TARGET_ID_PATTERN = re.compile(
    r"^(composite:[a-zA-Z0-9_-]+"
    r"|bundle:[a-zA-Z0-9_-]+"
    r"|bundle:[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
    r")$"
)


# ====================
# Enums
# ====================


class IDPPlatformEnum(str, Enum):
    """Supported IDP/IDE platforms for scaffold generation.

    Determines which platform-specific template variants are rendered
    when generating scaffold files.
    """

    claude_code = "claude-code"
    cursor = "cursor"
    windsurf = "windsurf"
    vscode = "vscode"
    generic = "generic"


# ====================
# Request Schemas
# ====================


class IDPScaffoldRequest(BaseModel):
    """Request to generate scaffold files for an IDP target.

    Renders a set of template files (e.g. CLAUDE.md, project config) for a
    given composite or bundle target, with optional variable substitution and
    platform-specific template selection.

    Examples:
        >>> request = IDPScaffoldRequest(
        ...     target_id="composite:fin-serv-compliance",
        ...     variables={"PROJECT_NAME": "customer-api"},
        ...     platform="claude-code",
        ...     include_bom=True,
        ... )
    """

    model_config = ConfigDict(
        str_strip_whitespace=True,
        json_schema_extra={
            "example": {
                "target_id": "composite:fin-serv-compliance",
                "variables": {
                    "PROJECT_NAME": "customer-api",
                    "AUTHOR": "Jane Doe",
                },
                "platform": "claude-code",
                "include_bom": False,
            }
        },
    )

    target_id: str = Field(
        description=(
            "Target artifact identifier. Accepts 'composite:<name>' or "
            "'bundle:<slug-or-uuid>' "
            "(e.g. 'composite:fin-serv-compliance', 'bundle:my-bundle', "
            "'bundle:550e8400-e29b-41d4-a716-446655440000')"
        ),
        examples=[
            "composite:fin-serv-compliance",
            "bundle:my-bundle",
            "bundle:550e8400-e29b-41d4-a716-446655440000",
        ],
    )
    variables: Dict[str, str] = Field(
        default_factory=dict,
        description="Optional key/value pairs substituted into rendered template files",
        examples=[{"PROJECT_NAME": "customer-api", "AUTHOR": "Jane Doe"}],
    )
    platform: str = Field(
        default="generic",
        description=(
            "Target IDP/IDE platform for template variant selection. "
            f"Allowed values: {[e.value for e in IDPPlatformEnum]}. "
            "Defaults to 'generic'."
        ),
        examples=["claude-code", "cursor", "windsurf", "vscode", "generic"],
    )
    include_bom: bool = Field(
        default=False,
        description=(
            "When True, include a Bill-of-Materials file listing all "
            "artifacts contained in the scaffold target."
        ),
        examples=[False, True],
    )

    @field_validator("target_id")
    @classmethod
    def validate_target_id(cls, v: str) -> str:
        """Validate target_id is a composite or bundle identifier.

        Accepts:
        - ``composite:<slug>`` — existing composite artifact format
        - ``bundle:<slug>`` — bundle identifier by slug
        - ``bundle:<uuid>`` — bundle identifier by UUID

        Args:
            v: Target ID value

        Returns:
            Validated target_id

        Raises:
            ValueError: If format is not recognised
        """
        if not _SCAFFOLD_TARGET_ID_PATTERN.match(v):
            raise ValueError(
                "target_id must be 'composite:<name>' or 'bundle:<slug-or-uuid>' "
                "(e.g. 'composite:fin-serv-compliance', 'bundle:my-bundle', "
                "'bundle:550e8400-e29b-41d4-a716-446655440000'). "
                "Allowed name characters: letters, digits, hyphens, underscores."
            )
        return v

    @field_validator("platform")
    @classmethod
    def validate_platform(cls, v: str) -> str:
        """Validate platform is a recognised IDPPlatformEnum value.

        Args:
            v: Platform string value

        Returns:
            Validated platform string

        Raises:
            ValueError: If value is not a member of IDPPlatformEnum
        """
        allowed = {e.value for e in IDPPlatformEnum}
        if v not in allowed:
            raise ValueError(f"platform must be one of {sorted(allowed)}. Got: {v!r}")
        return v


class IDPRegisterDeploymentRequest(BaseModel):
    """Request to register an IDP deployment for an artifact target.

    Records that a repository has deployed a given artifact target.  The
    operation is idempotent: re-submitting the same ``repo_url`` + ``target_id``
    pair updates the existing deployment record rather than creating a duplicate.

    Examples:
        >>> request = IDPRegisterDeploymentRequest(
        ...     repo_url="https://github.com/org/customer-api",
        ...     target_id="composite:fin-serv-compliance",
        ...     metadata={"team": "platform"},
        ... )
    """

    model_config = ConfigDict(
        str_strip_whitespace=True,
        json_schema_extra={
            "example": {
                "repo_url": "https://github.com/org/customer-api",
                "target_id": "composite:fin-serv-compliance",
                "metadata": {"team": "platform", "environment": "production"},
            }
        },
    )

    repo_url: str = Field(
        description=(
            "HTTPS URL of the repository being registered "
            "(e.g. 'https://github.com/org/customer-api')"
        ),
        examples=["https://github.com/org/customer-api"],
    )
    target_id: str = Field(
        description=(
            "Target artifact identifier in 'type:name' format "
            "(e.g. 'composite:fin-serv-compliance')"
        ),
        examples=["composite:fin-serv-compliance"],
    )
    metadata: Dict[str, str] = Field(
        default_factory=dict,
        description="Optional key/value metadata stored alongside the deployment record",
        examples=[{"team": "platform", "environment": "production"}],
    )
    bundle_id: Optional[str] = Field(
        default=None,
        description=(
            "Optional UUID or slug of the bundle associated with this deployment. "
            "Persisted to the DeploymentSet record for IDP bundle tracking."
        ),
        examples=["my-bundle", "550e8400-e29b-41d4-a716-446655440000"],
    )
    bundle_version: Optional[str] = Field(
        default=None,
        description=(
            "Optional version string of the associated bundle. "
            "Persisted to the DeploymentSet record alongside bundle_id."
        ),
        examples=["1.0.0", "v2.3.1"],
    )
    platform: Optional[str] = Field(
        default=None,
        description=(
            "Optional target deployment platform identifier "
            "(e.g. 'backstage', 'remote_git', 'local'). "
            "Stored on the DeploymentSet for filtering and reporting."
        ),
        examples=["backstage", "remote_git", "local"],
    )

    @field_validator("target_id")
    @classmethod
    def validate_target_id(cls, v: str) -> str:
        """Validate target_id follows 'type:name' format.

        Args:
            v: Target ID value

        Returns:
            Validated target_id

        Raises:
            ValueError: If format is not 'type:name'
        """
        if not _TARGET_ID_PATTERN.match(v):
            raise ValueError(
                "target_id must be in 'type:name' format "
                "(e.g. 'composite:fin-serv-compliance'). "
                "Allowed characters: letters, digits, hyphens, underscores, "
                "and forward-slashes in the name segment."
            )
        return v

    @field_validator("repo_url")
    @classmethod
    def validate_repo_url(cls, v: str) -> str:
        """Validate repo_url is an HTTPS URL.

        Args:
            v: Repository URL value

        Returns:
            Validated URL

        Raises:
            ValueError: If URL does not start with https://
        """
        if not v.startswith("https://"):
            raise ValueError(
                "repo_url must be an HTTPS URL (e.g. 'https://github.com/org/repo')"
            )
        return v


# ====================
# BOM Sidecar Schemas
# ====================


class BomSidecarArtifact(BaseModel):
    """BOM entry for a single artifact included in a scaffold bundle.

    Attributes:
        name: Human-readable artifact name.
        type: Artifact type string (e.g. ``"skill"``, ``"command"``).
        version: Optional version string; ``None`` when no version metadata
            is available for the artifact.
        content_hash: SHA-256 hex digest of all file contents in the artifact.
    """

    name: str = Field(description="Human-readable artifact name")
    type: str = Field(
        description="Artifact type string (e.g. 'skill', 'command')",
        examples=["skill", "command", "agent"],
    )
    version: Optional[str] = Field(
        default=None,
        description="Optional version string; null when no version metadata is available",
        examples=["v1.2.0", None],
    )
    content_hash: str = Field(
        description="SHA-256 hex digest of all file contents in the artifact",
        examples=["e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"],
    )


class BomSidecar(BaseModel):
    """Bill of Materials sidecar for a scaffold bundle.

    Records each artifact's name, type, optional version, and a deterministic
    SHA-256 content hash.  Intended to be attached to IDP scaffold responses so
    consumers can verify artifact integrity and detect upstream changes.

    Attributes:
        artifacts: Ordered list of BOM entries, one per resolved artifact.
        generated_at: ISO-8601 UTC timestamp marking when the sidecar was produced.
        bundle_id: Optional identifier of the parent bundle.
        bundle_version: Optional version string of the parent bundle.
    """

    artifacts: List[BomSidecarArtifact] = Field(
        description="Ordered list of BOM entries, one per resolved artifact"
    )
    generated_at: str = Field(
        description="ISO-8601 UTC timestamp marking when the sidecar was produced",
        examples=["2026-03-15T12:00:00+00:00"],
    )
    bundle_id: Optional[str] = Field(
        default=None,
        description="Optional identifier of the parent bundle",
        examples=["my-bundle", "550e8400-e29b-41d4-a716-446655440000"],
    )
    bundle_version: Optional[str] = Field(
        default=None,
        description="Optional version string of the parent bundle",
        examples=["1.0.0"],
    )


# ====================
# Response Schemas
# ====================


class RenderedFile(BaseModel):
    """A single rendered scaffold file.

    Represents a file generated from a template during IDP scaffold rendering.
    Content is base64-encoded to safely transport arbitrary text (including
    CLAUDE.md files that may contain non-ASCII characters).
    """

    path: str = Field(
        description=(
            "Relative path of the rendered file within the project "
            "(e.g. '.claude/CLAUDE.md')"
        ),
        examples=[".claude/CLAUDE.md", ".claude/rules/api-patterns.md"],
    )
    content_base64: str = Field(
        description="Base64-encoded UTF-8 file content",
        examples=["IyBDTEFVREUubWQKCk15IHByb2plY3QuCg=="],
    )


class IDPScaffoldResponse(BaseModel):
    """Response containing rendered scaffold files for an IDP target.

    Returns a list of files that should be written to the repository by the
    IDP scaffolder (e.g. a Backstage software template action).
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "files": [
                    {
                        "path": ".claude/CLAUDE.md",
                        "content_base64": "IyBDTEFVREUubWQ=",
                    },
                    {
                        "path": ".claude/rules/compliance.md",
                        "content_base64": "IyBDb21wbGlhbmNlIFJ1bGVz",
                    },
                ]
            }
        }
    )

    files: List[RenderedFile] = Field(
        description=("Rendered template files to be written to the target repository"),
        examples=[
            [
                {
                    "path": ".claude/CLAUDE.md",
                    "content_base64": "IyBDTEFVREUubWQ=",
                }
            ]
        ],
    )
    bom: Optional[BomSidecar] = Field(
        default=None,
        description=(
            "Bill-of-Materials sidecar listing all artifacts in the scaffold target. "
            "Populated only when the scaffold request was made with ``include_bom=True``."
        ),
    )


class IDPRegisterDeploymentResponse(BaseModel):
    """Response for a successful IDP deployment registration.

    Returns the UUID of the created or updated DeploymentSet, an idempotency
    flag indicating whether the record was newly created, and the string ID of
    the associated Project record.  The ``project_id`` is stable across
    repeated registrations for the same ``repo_url`` + ``target_id`` pair and
    can be used to write the ``skillmeat.io/project-id`` annotation in
    Backstage catalog descriptors.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "deployment_set_id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "created": True,
                "project_id": "idp:org/customer-api",
            }
        }
    )

    deployment_set_id: str = Field(
        description="UUID of the DeploymentSet record created or updated by this request",
        examples=["3fa85f64-5717-4562-b3fc-2c963f66afa6"],
    )
    created: bool = Field(
        description=(
            "True when a new DeploymentSet was created; "
            "False when an existing record was updated (idempotent re-registration)"
        ),
        examples=[True],
    )
    project_id: Optional[str] = Field(
        default=None,
        description=(
            "String ID of the Project record associated with this deployment. "
            "Stable across repeated registrations for the same repo_url + target_id pair. "
            "Use this value to write the 'skillmeat.io/project-id' annotation so the "
            "BOM card endpoint can resolve the correct project snapshot."
        ),
        examples=["idp:org/customer-api"],
    )


class DriftSummary(BaseModel):
    """Drift check summary for an IDP context card.

    Captures the latest drift-check outcome across three independent
    dimensions.  All fields are ``None`` when no drift check has been run
    for the deployment set.

    Attributes:
        version_drift: True when the deployed version differs from the
            upstream source version; None if not yet checked.
        content_drift: True when file content of deployed artifacts
            differs from the upstream source; None if not yet checked.
        policy_drift: True when policy or access-control definitions have
            changed since last deployment; None if not yet checked.
        last_checked_at: ISO-8601 UTC timestamp of the most recent drift
            check run; None if no check has been performed.
    """

    version_drift: Optional[bool] = Field(
        default=None,
        description=(
            "True when deployed version differs from upstream source; "
            "null when this dimension has not been checked"
        ),
        examples=[True, False, None],
    )
    content_drift: Optional[bool] = Field(
        default=None,
        description=(
            "True when deployed file content differs from upstream source; "
            "null when this dimension has not been checked"
        ),
        examples=[False, None],
    )
    policy_drift: Optional[bool] = Field(
        default=None,
        description=(
            "True when policy/access-control definitions have changed "
            "since last deployment; null when not checked"
        ),
        examples=[None],
    )
    last_checked_at: Optional[str] = Field(
        default=None,
        description=(
            "ISO-8601 UTC timestamp of the most recent drift check run; "
            "null if no drift check has been performed"
        ),
        examples=["2026-03-15T12:00:00", None],
    )


class DriftDetails(BaseModel):
    """Extended diagnostics from a drift check run.

    Carries per-dimension detail fields produced by the three drift
    classifiers.  All fields are optional — classifiers that were skipped
    (e.g. because ``bundle_id`` is absent) leave their fields as ``None``.

    Attributes:
        content_changed_files: List of ``.claude/`` file paths whose SHA-256
            hash changed since the last baseline.  Empty when content drift
            was not detected or the classifier was skipped.
        version_deployed: The bundle version string recorded on the
            ``DeploymentSet`` at the time the check was run.
        version_latest: The latest bundle version string from
            ``BundleEntity.version``; ``None`` when unavailable.
        policy_updated_at: ISO-8601 UTC timestamp of the bundle's most
            recent ``updated_at`` value; ``None`` when unavailable.
    """

    content_changed_files: List[str] = Field(
        default_factory=list,
        description=(
            "List of .claude/ file paths whose SHA-256 hash changed since "
            "the last baseline; empty when no content drift was detected"
        ),
        examples=[[], [".claude/CLAUDE.md", ".claude/rules/api.md"]],
    )
    version_deployed: Optional[str] = Field(
        default=None,
        description=(
            "Bundle version string recorded on the DeploymentSet at check time; "
            "null when no bundle version is set"
        ),
        examples=["1.0.0", None],
    )
    version_latest: Optional[str] = Field(
        default=None,
        description=(
            "Latest bundle version string from BundleEntity; "
            "null when bundle is not found or has no version"
        ),
        examples=["1.2.0", None],
    )
    policy_updated_at: Optional[str] = Field(
        default=None,
        description=(
            "ISO-8601 UTC timestamp of the bundle's most recent updated_at; "
            "null when bundle is not found or has no timestamp"
        ),
        examples=["2026-03-10T08:00:00+00:00", None],
    )


class IDPDriftResponse(BaseModel):
    """Drift check response for a SkillMeat deployment set.

    Returns the result of running all three drift classifiers (version,
    content, policy) against the given ``DeploymentSet``.  Results are
    cached for 24 hours; the ``is_stale`` flag indicates whether the
    returned data came from a cached result that is older than 24 hours.

    Attributes:
        deployment_set_id: UUID hex identifier of the ``DeploymentSet``.
        version_drift: ``True`` when the deployed bundle version is older
            than the latest bundle version; ``None`` when not checked.
        content_drift: ``True`` when ``.claude/`` file hashes have changed
            since the last baseline; ``None`` when not checked.
        policy_drift: ``True`` when the bundle was updated after the
            deployment set was registered; ``None`` when not checked.
        last_checked_at: ISO-8601 UTC timestamp of the drift check result
            being returned.
        is_stale: ``True`` when the returned data came from a result that
            is older than 24 hours (the cache TTL).
        details: Extended diagnostics including changed files and version
            info; ``None`` when no details are available.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "deployment_set_id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "version_drift": True,
                "content_drift": False,
                "policy_drift": None,
                "last_checked_at": "2026-03-15T12:00:00+00:00",
                "is_stale": False,
                "details": {
                    "content_changed_files": [],
                    "version_deployed": "1.0.0",
                    "version_latest": "1.2.0",
                    "policy_updated_at": "2026-03-10T08:00:00+00:00",
                },
            }
        }
    )

    deployment_set_id: str = Field(
        description="UUID hex identifier of the DeploymentSet record",
        examples=["3fa85f64-5717-4562-b3fc-2c963f66afa6"],
    )
    version_drift: Optional[bool] = Field(
        default=None,
        description=(
            "True when deployed version is older than the latest bundle version; "
            "null when this dimension could not be checked"
        ),
        examples=[True, False, None],
    )
    content_drift: Optional[bool] = Field(
        default=None,
        description=(
            "True when .claude/ file hashes have changed since last baseline; "
            "null when this dimension could not be checked"
        ),
        examples=[False, None],
    )
    policy_drift: Optional[bool] = Field(
        default=None,
        description=(
            "True when the bundle was updated after the deployment set was registered; "
            "null when this dimension could not be checked"
        ),
        examples=[None],
    )
    last_checked_at: Optional[str] = Field(
        default=None,
        description=(
            "ISO-8601 UTC timestamp of the drift check result being returned; "
            "null when no check has been performed"
        ),
        examples=["2026-03-15T12:00:00+00:00", None],
    )
    is_stale: bool = Field(
        description=(
            "True when the returned data came from a result older than the 24-hour "
            "cache TTL"
        ),
        examples=[False, True],
    )
    details: Optional[DriftDetails] = Field(
        default=None,
        description=(
            "Extended diagnostics including changed files, version info, and policy "
            "timestamps; null when no details are available"
        ),
    )


class IDPContextCardResponse(BaseModel):
    """Context card payload for an IDP / Backstage deployment entity page.

    Returns a compact, structured summary of a ``DeploymentSet`` record
    suitable for rendering in the SkillMeat Backstage plugin ContextCard
    component.

    Attributes:
        deployment_set_id: UUID hex identifier of the ``DeploymentSet``.
        bundle_name: Human-readable bundle/deployment name.  Sourced from
            the linked ``BundleEntity.name`` when ``bundle_id`` is set,
            or from ``DeploymentSet.name`` as a v1 fallback.
        bundle_version: Optional semver version string of the associated
            bundle; ``None`` when no bundle version has been recorded.
        platform: Optional deployment platform identifier (e.g.
            ``"backstage"``, ``"remote_git"``); ``None`` for local sets.
        registered_at: ISO-8601 UTC timestamp when the deployment set was
            first created; ``None`` if the timestamp is unavailable.
        drift_summary: Latest drift-check outcome for all three dimensions.
            All nested fields are ``None`` when no drift check has been run.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "deployment_set_id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "bundle_name": "fin-serv-compliance",
                "bundle_version": "1.2.0",
                "platform": "backstage",
                "registered_at": "2026-03-01T09:00:00",
                "drift_summary": {
                    "version_drift": True,
                    "content_drift": False,
                    "policy_drift": None,
                    "last_checked_at": "2026-03-15T12:00:00",
                },
            }
        }
    )

    deployment_set_id: str = Field(
        description="UUID hex identifier of the DeploymentSet record",
        examples=["3fa85f64-5717-4562-b3fc-2c963f66afa6"],
    )
    bundle_name: str = Field(
        description=(
            "Human-readable bundle/deployment name. Sourced from the linked "
            "BundleEntity when bundle_id is set, or from DeploymentSet.name "
            "as a v1 fallback."
        ),
        examples=["fin-serv-compliance"],
    )
    bundle_version: Optional[str] = Field(
        default=None,
        description=(
            "Optional semver version string of the associated bundle; "
            "null when no bundle version has been recorded"
        ),
        examples=["1.2.0", None],
    )
    platform: Optional[str] = Field(
        default=None,
        description=(
            "Optional deployment platform identifier "
            "(e.g. 'backstage', 'remote_git', 'local'); null for local sets"
        ),
        examples=["backstage", "remote_git", None],
    )
    registered_at: Optional[str] = Field(
        default=None,
        description=(
            "ISO-8601 UTC timestamp when the deployment set was first created; "
            "null if timestamp is unavailable"
        ),
        examples=["2026-03-01T09:00:00", None],
    )
    drift_summary: DriftSummary = Field(
        description=(
            "Latest drift-check outcome across version, content, and policy "
            "dimensions. All fields are null when no drift check has been run."
        ),
    )


# Export all schemas
__all__ = [
    "IDPPlatformEnum",
    "IDPScaffoldRequest",
    "IDPRegisterDeploymentRequest",
    "RenderedFile",
    "BomSidecarArtifact",
    "BomSidecar",
    "IDPScaffoldResponse",
    "IDPRegisterDeploymentResponse",
    "DriftSummary",
    "DriftDetails",
    "IDPContextCardResponse",
    "IDPDriftResponse",
]
