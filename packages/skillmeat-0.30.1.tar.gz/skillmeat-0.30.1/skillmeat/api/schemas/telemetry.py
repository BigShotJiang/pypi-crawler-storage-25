"""SAM telemetry ingestion schemas for execution metrics and rollup signals."""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class ExecutionMetrics(BaseModel):
    """Token and cost metrics for a single workflow execution."""

    model_io_tokens: int = Field(
        description="Number of model I/O tokens consumed",
        examples=[45000],
    )
    cache_tokens: int = Field(
        description="Number of cache tokens consumed",
        examples=[120000],
    )
    cost_usd: float = Field(
        description="Total cost in USD for this execution",
        examples=[0.15],
    )
    quality_score: Optional[float] = Field(
        default=None,
        description="Optional quality score between 0.0 and 1.0",
        examples=[0.92],
    )


class ExecutionRecord(BaseModel):
    """A single workflow execution record from a SAM client."""

    execution_id: str = Field(
        max_length=256,
        description="Unique identifier for this execution",
        examples=["550e8400-e29b-41d4-a716-446655440000"],
    )
    workflow_id: str = Field(
        max_length=256,
        description="Identifier of the workflow that was executed",
        examples=["workflow:refactor-java-service"],
    )
    bundle_id: Optional[str] = Field(
        default=None,
        max_length=256,
        description="Optional bundle associated with this execution",
        examples=["bundle:spring-boot-migration-v2"],
    )
    status: str = Field(
        max_length=256,
        description="Execution status (e.g. completed, failed, cancelled)",
        examples=["completed"],
    )
    duration_seconds: float = Field(
        description="Wall-clock duration of the execution in seconds",
        examples=[145.0],
    )
    started_at: datetime = Field(
        description="UTC timestamp when the execution started",
        examples=["2026-03-24T10:00:00Z"],
    )
    metrics: ExecutionMetrics = Field(
        description="Token and cost metrics for this execution",
    )


class ExecutionOutcomeBatch(BaseModel):
    """Batch of execution records submitted by a SAM client."""

    project_id: str = Field(
        max_length=256,
        description="Backstage service or project identifier",
        examples=["backstage-service-id"],
    )
    client_version: str = Field(
        max_length=256,
        description="Version of the SAM client submitting the batch",
        examples=["v0.7.0"],
    )
    executions: List[ExecutionRecord] = Field(
        description="List of execution records in this batch",
    )


class ProjectRollupSignals(BaseModel):
    """Aggregated project-level signals for a reporting period.

    Allows extra fields to support forward-compatible signal additions.
    """

    model_config = ConfigDict(extra="allow")

    feature_velocity_score: Optional[float] = Field(
        default=None,
        description="Computed velocity score for feature delivery",
        examples=[0.78],
    )
    test_integrity_delta: Optional[float] = Field(
        default=None,
        description="Change in test integrity over the reporting period",
        examples=[-0.03],
    )
    total_executions: Optional[int] = Field(
        default=None,
        description="Total number of executions in the reporting period",
        examples=[312],
    )
    total_cost_usd: Optional[float] = Field(
        default=None,
        description="Total cost in USD across all executions in the period",
        examples=[47.82],
    )


class ProjectRollupPayload(BaseModel):
    """Periodic rollup of project-level telemetry signals."""

    project_id: str = Field(
        max_length=256,
        description="Backstage service or project identifier",
        examples=["backstage-service-id"],
    )
    client_version: str = Field(
        max_length=256,
        description="Version of the SAM client submitting the rollup",
        examples=["v0.7.0"],
    )
    period_start: datetime = Field(
        description="UTC start of the reporting period",
        examples=["2026-03-01T00:00:00Z"],
    )
    period_end: datetime = Field(
        description="UTC end of the reporting period",
        examples=["2026-03-31T23:59:59Z"],
    )
    signals: ProjectRollupSignals = Field(
        description="Aggregated signals for the reporting period",
    )


class IngestionError(BaseModel):
    """Details about a single rejected execution record."""

    execution_id: Optional[str] = Field(
        default=None,
        description="ID of the rejected execution, if identifiable",
        examples=["550e8400-e29b-41d4-a716-446655440000"],
    )
    reason: str = Field(
        description="Human-readable reason for rejection",
        examples=["duration_seconds must be non-negative"],
    )


class IngestionResponse(BaseModel):
    """Response returned after processing an execution outcome batch."""

    accepted: int = Field(
        description="Number of execution records successfully ingested",
        examples=[9],
    )
    rejected: int = Field(
        description="Number of execution records rejected",
        examples=[1],
    )
    errors: List[IngestionError] = Field(
        description="Details for each rejected record",
    )
