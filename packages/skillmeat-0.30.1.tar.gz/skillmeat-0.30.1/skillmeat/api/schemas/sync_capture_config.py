"""Pydantic schemas for the sync-capture-config CRUD endpoints (SYNC-5.2)."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, model_validator


class ConfigScope(str, Enum):
    """Scope level for a :class:`SyncCaptureConfig` row."""

    global_ = "global"
    tier = "tier"
    project = "project"


class SyncCaptureConfigRead(BaseModel):
    """Full representation of a SyncCaptureConfig row (response body)."""

    id: int = Field(..., description="Surrogate integer primary key.")
    scope: ConfigScope = Field(
        ...,
        description="Scope level: 'global', 'tier', or 'project'.",
    )
    scope_id: Optional[str] = Field(
        None,
        description=(
            "Discriminator within the scope: tier name or project ID. "
            "Always null for global scope."
        ),
    )
    quiet_window_seconds: int = Field(
        ...,
        ge=1,
        description=(
            "Debounce quiet-window duration in seconds. "
            "Poller waits this long after the last detected change before "
            "capturing a new version."
        ),
    )
    auto_scan_enabled: bool = Field(
        ...,
        description=(
            "When False, the background auto-scan is disabled for this scope."
        ),
    )
    sync_capture_enabled: bool = Field(
        ...,
        description="Master switch for sync capture within this scope.",
    )
    max_captures_per_hour: int = Field(
        ...,
        ge=1,
        description=(
            "Maximum number of version captures permitted per hour for "
            "artifacts within this scope."
        ),
    )
    created_at: datetime = Field(
        ..., description="UTC timestamp when this config row was inserted."
    )
    updated_at: datetime = Field(
        ..., description="UTC timestamp of the most recent update."
    )

    model_config = {"from_attributes": True}


class SyncCaptureConfigCreate(BaseModel):
    """Request body for creating or upserting a SyncCaptureConfig row.

    ``scope_id`` must be ``None`` for ``scope='global'`` and non-``None`` for
    ``scope='tier'`` or ``scope='project'``.
    """

    scope: ConfigScope = Field(
        ...,
        description="Scope level: 'global', 'tier', or 'project'.",
    )
    scope_id: Optional[str] = Field(
        None,
        description=(
            "Discriminator within the scope. Required for 'tier' and "
            "'project' scopes; must be omitted or null for 'global'."
        ),
    )
    quiet_window_seconds: int = Field(
        default=30,
        ge=1,
        description="Debounce quiet-window duration in seconds.",
    )
    auto_scan_enabled: bool = Field(
        default=True,
        description="Whether background auto-scan is active for this scope.",
    )
    sync_capture_enabled: bool = Field(
        default=True,
        description="Master switch for sync capture within this scope.",
    )
    max_captures_per_hour: int = Field(
        default=10,
        ge=1,
        description="Max version captures permitted per hour within this scope.",
    )

    @model_validator(mode="after")
    def _validate_scope_id(self) -> "SyncCaptureConfigCreate":
        scope = self.scope
        scope_id = self.scope_id
        if scope == ConfigScope.global_ and scope_id is not None:
            raise ValueError("scope_id must be null for scope='global'.")
        if scope != ConfigScope.global_ and not scope_id:
            raise ValueError(f"scope_id is required for scope='{scope.value}'.")
        return self


class SyncCaptureConfigUpdate(BaseModel):
    """Request body for updating overridable fields of a SyncCaptureConfig row.

    All fields are optional; only provided fields are updated.
    """

    quiet_window_seconds: Optional[int] = Field(
        None,
        ge=1,
        description="Debounce quiet-window duration in seconds.",
    )
    auto_scan_enabled: Optional[bool] = Field(
        None,
        description="Whether background auto-scan is active for this scope.",
    )
    sync_capture_enabled: Optional[bool] = Field(
        None,
        description="Master switch for sync capture within this scope.",
    )
    max_captures_per_hour: Optional[int] = Field(
        None,
        ge=1,
        description="Max version captures permitted per hour within this scope.",
    )
