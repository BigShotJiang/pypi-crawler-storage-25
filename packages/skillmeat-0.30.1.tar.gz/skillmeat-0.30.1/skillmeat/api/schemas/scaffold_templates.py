"""Pydantic schemas for scaffold template management API endpoints.

Defines request and response models for scaffold template CRUD operations.
Scaffold templates configure how SkillMeat bundles are rendered as Backstage
Software Templates (YAML) for use in the Backstage scaffolder plugin.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

import uuid as _uuid_module

from pydantic import BaseModel, ConfigDict, Field, field_validator

# ====================
# Request Schemas
# ====================


class ScaffoldTemplateCreate(BaseModel):
    """Request schema for creating a new scaffold template.

    Associates a bundle with Backstage scaffolder configuration, including
    which template variables are required and how they map to Backstage UI
    field types.
    """

    bundle_id: str = Field(
        description=(
            "ID of the bundle this scaffold template is derived from.  Must "
            "match an existing bundle entity in the collection."
        ),
        min_length=1,
        examples=["my-python-bundle"],
    )
    enabled: bool = Field(
        default=True,
        description=(
            "Whether this scaffold template is active and available for "
            "generation.  Disabled templates are retained but excluded from "
            "Backstage catalog sync."
        ),
        examples=[True],
    )
    required_variables: List[str] = Field(
        default_factory=list,
        description=(
            "Variable names that must be supplied when generating a template.  "
            "Each name corresponds to a key in the Backstage scaffolder form."
        ),
        examples=[["name", "owner", "repoUrl"]],
    )
    variable_type_map: Dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Maps variable names to Backstage UI field types (e.g. 'string', "
            "'owner', 'repoUrl').  Controls which Backstage form component is "
            "rendered for each variable."
        ),
        examples=[{"name": "string", "owner": "owner", "repoUrl": "repoUrl"}],
    )
    skeleton_ref: Optional[str] = Field(
        default=None,
        description=(
            "Optional reference to a skeleton directory or remote URL.  When "
            "provided, Backstage uses this skeleton instead of the bundle "
            "contents directly."
        ),
        examples=["https://github.com/org/templates/tree/main/skeletons/basic"],
    )
    backstage_owner: Optional[str] = Field(
        default=None,
        description=(
            "Backstage catalog owner entity ref for the generated template "
            "(e.g. 'group:default/platform-team').  Mapped to "
            "`spec.owner` in the generated YAML."
        ),
        examples=["group:default/platform-team"],
    )
    backstage_type: str = Field(
        default="service",
        description=(
            "Backstage scaffolder template type.  Typically 'service', "
            "'website', or 'library'.  Mapped to `spec.type` in the generated "
            "YAML."
        ),
        examples=["service"],
    )
    backstage_tags: List[str] = Field(
        default_factory=list,
        description=(
            "Backstage catalog tags applied to the generated template.  "
            "Used for filtering in the Backstage software catalog."
        ),
        examples=[["python", "fastapi"]],
    )


# ====================
# Update Schemas
# ====================


class ScaffoldTemplateUpdate(BaseModel):
    """Request schema for partially updating a scaffold template (PATCH semantics).

    All fields are optional.  Only provided fields are modified; omitted
    fields retain their current values.
    """

    enabled: Optional[bool] = Field(
        default=None,
        description="Set to False to disable this template without deleting it.",
        examples=[False],
    )
    required_variables: Optional[List[str]] = Field(
        default=None,
        description="Replacement list of required variable names.",
        examples=[["name", "owner"]],
    )
    variable_type_map: Optional[Dict[str, str]] = Field(
        default=None,
        description="Replacement variable-to-Backstage-field-type mapping.",
        examples=[{"name": "string", "owner": "owner"}],
    )
    skeleton_ref: Optional[str] = Field(
        default=None,
        description="Updated skeleton reference URL or path.",
        examples=["https://github.com/org/templates/tree/main/skeletons/v2"],
    )
    backstage_owner: Optional[str] = Field(
        default=None,
        description="Updated Backstage owner entity ref.",
        examples=["group:default/new-team"],
    )
    backstage_type: Optional[str] = Field(
        default=None,
        description="Updated Backstage template type.",
        examples=["library"],
    )
    backstage_tags: Optional[List[str]] = Field(
        default=None,
        description="Replacement list of Backstage catalog tags.",
        examples=[["python", "library"]],
    )


# ====================
# Response Schemas
# ====================


class ScaffoldTemplateResponse(BaseModel):
    """Full representation of a scaffold template returned from the API.

    Includes all configuration fields plus computed state such as
    ``template_stale`` (whether the backing bundle has changed since the last
    generation) and ``generation_history`` (ordered list of past generation
    events).
    """

    model_config = ConfigDict(from_attributes=True)

    @field_validator("generation_history", mode="before")
    @classmethod
    def coerce_none_to_list(cls, v: Any) -> List[Dict[str, Any]]:
        """Coerce None to empty list for nullable JSON column."""
        return v if v is not None else []

    @field_validator("id", "bundle_id", mode="before")
    @classmethod
    def coerce_uuid_to_str(cls, v: Any) -> str:
        """Coerce UUID objects to hex strings for edition-agnostic id fields.

        Local edition stores ``id`` as a hex string; enterprise edition stores
        it as a ``uuid.UUID`` object.  This validator normalises both to string
        so the response schema is edition-agnostic.
        """
        if isinstance(v, _uuid_module.UUID):
            return v.hex
        return str(v)

    id: str = Field(
        description="Unique identifier for the scaffold template.",
        examples=["tmpl-abc123"],
    )
    bundle_id: str = Field(
        description="ID of the bundle this template is derived from.",
        examples=["my-python-bundle"],
    )
    enabled: bool = Field(
        description="Whether this template is active.",
        examples=[True],
    )
    required_variables: List[str] = Field(
        description="Variable names required at generation time.",
        examples=[["name", "owner", "repoUrl"]],
    )
    variable_type_map: Dict[str, str] = Field(
        description="Maps variable names to Backstage UI field types.",
        examples=[{"name": "string", "owner": "owner", "repoUrl": "repoUrl"}],
    )
    skeleton_ref: Optional[str] = Field(
        default=None,
        description="Optional skeleton directory reference.",
        examples=["https://github.com/org/templates/tree/main/skeletons/basic"],
    )
    backstage_owner: Optional[str] = Field(
        default=None,
        description="Backstage catalog owner entity ref.",
        examples=["group:default/platform-team"],
    )
    backstage_type: str = Field(
        description="Backstage scaffolder template type.",
        examples=["service"],
    )
    backstage_tags: List[str] = Field(
        description="Backstage catalog tags for the generated template.",
        examples=[["python", "fastapi"]],
    )
    bundle_version_at_last_generation: Optional[str] = Field(
        default=None,
        description=(
            "Version string of the bundle at the time the template was last "
            "generated.  Null when no generation has occurred yet."
        ),
        examples=["1.2.0"],
    )
    generation_history: List[Dict[str, Any]] = Field(
        default_factory=list,
        description=(
            "Ordered list of generation event records (most-recent last).  "
            "Each dict contains at minimum ``generated_at`` (ISO 8601 string) "
            "and ``bundle_version`` (str or null)."
        ),
        examples=[
            [
                {
                    "generated_at": "2026-01-15T10:00:00Z",
                    "bundle_version": "1.1.0",
                },
                {
                    "generated_at": "2026-02-01T14:30:00Z",
                    "bundle_version": "1.2.0",
                },
            ]
        ],
    )
    template_stale: bool = Field(
        default=False,
        description=(
            "True when the backing bundle version differs from "
            "``bundle_version_at_last_generation``, indicating the template "
            "should be regenerated.  Populated by the service layer — not a "
            "computed Pydantic property."
        ),
        examples=[False],
    )
    created_at: datetime = Field(
        description="ISO 8601 timestamp when this scaffold template was created.",
        examples=["2026-01-10T09:00:00Z"],
    )
    updated_at: datetime = Field(
        description="ISO 8601 timestamp of the most recent update.",
        examples=["2026-02-01T14:30:00Z"],
    )


class ScaffoldTemplateListResponse(BaseModel):
    """Paginated list response for scaffold templates."""

    items: List[ScaffoldTemplateResponse] = Field(
        description="Scaffold templates for this page.",
    )
    total: int = Field(
        description="Total number of scaffold templates matching the query.",
        examples=[12],
    )
    page: int = Field(
        description="Current 1-based page number.",
        examples=[1],
    )
    page_size: int = Field(
        description="Items per page.",
        examples=[50],
    )


# ====================
# Preview Schemas
# ====================


class TemplatePreviewResponse(BaseModel):
    """Response from a scaffold template preview (generate-without-save) operation.

    Returns the rendered Backstage YAML along with provenance metadata and
    any non-fatal validation warnings discovered during rendering.
    """

    template_yaml: str = Field(
        description=(
            "The generated Backstage Software Template YAML string.  "
            "Ready to be written to a ``template.yaml`` file or pushed to the "
            "Backstage catalog."
        ),
        examples=["apiVersion: scaffolder.backstage.io/v1beta3\nkind: Template\n..."],
    )
    bundle_id: str = Field(
        description="ID of the bundle used to generate this preview.",
        examples=["my-python-bundle"],
    )
    bundle_version: Optional[str] = Field(
        default=None,
        description=(
            "Version of the bundle at preview time.  Null when the bundle has "
            "no version set."
        ),
        examples=["1.2.0"],
    )
    generated_at: datetime = Field(
        description="ISO 8601 timestamp when this preview was generated.",
        examples=["2026-03-18T12:00:00Z"],
    )
    validation_warnings: List[str] = Field(
        default_factory=list,
        description=(
            "Non-fatal warnings encountered during YAML rendering (e.g. "
            "missing recommended fields, unknown variable references).  An "
            "empty list means the template passed all validation checks."
        ),
        examples=[
            ["'spec.owner' is missing — Backstage catalog will use default owner"]
        ],
    )
