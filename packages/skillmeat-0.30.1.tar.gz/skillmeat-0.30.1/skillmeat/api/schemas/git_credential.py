"""Pydantic schemas for git credential CRUD endpoints (GCD Phase 2).

Defines request/response models for managing per-scope git credentials
(PATs, app installation tokens) used by the Git Connection Decoupling
feature.  All schemas use Pydantic v2 style.

Security invariant: ``GitCredentialResponse`` MUST NOT include
``token_encrypted`` or ``access_token`` fields.  The plaintext token is
accepted on create via ``GitCredentialCreate.token`` and is immediately
encrypted at rest by the router/service layer before persistence.

Schema Groups:
    - ScopeType: Enum for credential scope granularity.
    - CredentialType: Enum for credential mechanism.
    - GitCredentialCreate: POST body for registering a new credential.
    - GitCredentialResponse: Read-only response (token never included).
    - GitCredentialListResponse: Paginated list of credential summaries.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field


# =============================================================================
# Enums
# =============================================================================


class ScopeType(str, Enum):
    """Granularity level at which a credential applies."""

    org = "org"
    team = "team"
    developer = "developer"


class CredentialType(str, Enum):
    """Mechanism used to authenticate against the git provider."""

    pat = "pat"
    app_installation = "app_installation"


# =============================================================================
# Request schemas
# =============================================================================


class GitCredentialCreate(BaseModel):
    """Request body for registering a new git credential.

    The ``token`` field is accepted in plaintext here and MUST be encrypted
    at rest before the record is persisted.  The encrypted value is stored
    in the ``token_encrypted`` column; the plaintext is never stored.

    Attributes:
        scope_type:       Granularity level at which this credential applies.
        scope_id:         Identifier of the org, team, or developer this
                          credential belongs to.
        connection_id:    Optional FK to a specific ``GitRepoConnection``.
                          When ``None`` the credential applies to all
                          connections within the scope.
        token:            Plaintext access token (write-only — encrypted at
                          rest; never returned in responses).
        credential_type:  Mechanism used to authenticate.  Defaults to
                          ``CredentialType.pat``.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "scope_type": "developer",
                "scope_id": "user:alice",
                "connection_id": None,
                "token": "ghp_xxxxxxxxxxxxxxxxxxxx",
                "credential_type": "pat",
            }
        }
    )

    scope_type: ScopeType = Field(
        description=(
            "Granularity level at which this credential applies: "
            "``'org'``, ``'team'``, or ``'developer'``."
        ),
        examples=["developer"],
    )
    scope_id: str = Field(
        description=(
            "Identifier of the org, team, or developer this credential belongs to. "
            "Format depends on ``scope_type`` (e.g. ``'user:alice'`` for developer scope)."
        ),
        examples=["user:alice"],
    )
    connection_id: Optional[str] = Field(
        default=None,
        description=(
            "Optional FK to a specific ``GitRepoConnection.id``.  When ``null`` the "
            "credential applies to all connections within the given scope."
        ),
        examples=[None],
    )
    token: str = Field(
        description=(
            "Plaintext access token (PAT or app installation token).  Write-only — "
            "encrypted at rest immediately on receipt; never returned in any response."
        ),
        examples=["ghp_xxxxxxxxxxxxxxxxxxxx"],
    )
    credential_type: CredentialType = Field(
        default=CredentialType.pat,
        description=(
            "Authentication mechanism: ``'pat'`` (Personal Access Token) or "
            "``'app_installation'`` (GitHub App installation token)."
        ),
        examples=["pat"],
    )


# =============================================================================
# Response schemas
# =============================================================================


class GitCredentialResponse(BaseModel):
    """Response schema for a single git credential.

    Security invariant: this schema intentionally omits ``token_encrypted``
    and ``access_token`` to prevent inadvertent secret exposure via API
    responses.  The token accepted on create is NEVER reflected back.

    Attributes:
        id:              String primary key of the credential record.
        scope_type:      Granularity level at which this credential applies.
        scope_id:        Identifier of the org, team, or developer.
        connection_id:   FK to a specific ``GitRepoConnection`` (nullable).
        credential_type: Authentication mechanism.
        created_by:      User identifier who created the credential (nullable).
        created_at:      UTC timestamp when the credential was registered (nullable).
    """

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": {
                "id": "cred:abc123",
                "scope_type": "developer",
                "scope_id": "user:alice",
                "connection_id": None,
                "credential_type": "pat",
                "created_by": "user:alice",
                "created_at": "2026-04-01T12:00:00Z",
            }
        },
    )

    id: str = Field(
        description="String primary key of the credential record.",
        examples=["cred:abc123"],
    )
    scope_type: ScopeType = Field(
        description=(
            "Granularity level at which this credential applies: "
            "``'org'``, ``'team'``, or ``'developer'``."
        ),
        examples=["developer"],
    )
    scope_id: str = Field(
        description="Identifier of the org, team, or developer this credential belongs to.",
        examples=["user:alice"],
    )
    connection_id: Optional[str] = Field(
        default=None,
        description=(
            "FK to a specific ``GitRepoConnection.id``.  ``null`` when the credential "
            "applies to all connections within the given scope."
        ),
        examples=[None],
    )
    credential_type: CredentialType = Field(
        description=(
            "Authentication mechanism: ``'pat'`` (Personal Access Token) or "
            "``'app_installation'`` (GitHub App installation token)."
        ),
        examples=["pat"],
    )
    created_by: Optional[str] = Field(
        default=None,
        description="User identifier of the person who registered this credential (nullable).",
        examples=["user:alice"],
    )
    created_at: Optional[datetime] = Field(
        default=None,
        description="UTC timestamp when the credential was registered (nullable).",
        examples=["2026-04-01T12:00:00Z"],
    )


class GitCredentialListResponse(BaseModel):
    """Response schema for listing git credentials.

    Wraps a flat list of ``GitCredentialResponse`` items with a total count
    for pagination support.

    Attributes:
        items: List of git credential summary records.
        total: Total number of credentials matching the query (across all pages).
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "items": [
                    {
                        "id": "cred:abc123",
                        "scope_type": "developer",
                        "scope_id": "user:alice",
                        "connection_id": None,
                        "credential_type": "pat",
                        "created_by": "user:alice",
                        "created_at": "2026-04-01T12:00:00Z",
                    }
                ],
                "total": 1,
            }
        }
    )

    items: List[GitCredentialResponse] = Field(
        description="List of git credential summary records (tokens never included).",
    )
    total: int = Field(
        description="Total number of credentials matching the query (across all pages).",
        examples=[1],
    )
