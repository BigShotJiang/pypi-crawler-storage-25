"""Configuration API schemas.

Provides Pydantic models for configuration-related API endpoints,
including detection patterns for artifact type inference and feature flags.
"""

from typing import Dict, List

from pydantic import BaseModel, Field


class EditionFeatures(BaseModel):
    """Feature availability derived from the deployment edition.

    Attributes:
        sync_enabled: Whether collection sync features are available.
        context_sync_enabled: Whether context entity sync is available.
    """

    sync_enabled: bool = Field(
        description="Whether collection sync features are available in this edition."
    )
    context_sync_enabled: bool = Field(
        description="Whether context entity sync is available in this edition."
    )


class EditionResponse(BaseModel):
    """Response model for the deployment edition endpoint.

    Attributes:
        edition: Deployment edition identifier ('local' or 'enterprise').
        features: Feature availability flags derived from the edition.
    """

    edition: str = Field(
        description="Deployment edition identifier. 'local' for single-tenant filesystem "
        "mode; 'enterprise' for multi-tenant DB-backed mode."
    )
    features: EditionFeatures = Field(
        description="Feature availability flags derived from the current edition."
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "edition": "local",
                "features": {
                    "sync_enabled": True,
                    "context_sync_enabled": True,
                },
            }
        }


class DetectionPatternsResponse(BaseModel):
    """Response model for artifact detection patterns.

    This schema exposes the detection patterns used by the Python backend
    for identifying artifact types from directory structures. Frontend
    applications can use this data to replicate the same detection logic.

    Attributes:
        container_aliases: Maps artifact type to list of valid container names.
            e.g., {"skill": ["skills", "skill", "claude-skills"]}
        leaf_containers: Flattened unique list of all valid container names.
            Useful for quick membership checks when traversing directories.
        canonical_containers: Maps artifact type to its preferred container name.
            e.g., {"skill": "skills"}
    """

    container_aliases: Dict[str, List[str]] = Field(
        description="Maps artifact type to list of valid container directory names",
        examples=[
            {
                "skill": ["skills", "skill", "claude-skills"],
                "command": ["commands", "command", "claude-commands"],
            }
        ],
    )
    leaf_containers: List[str] = Field(
        description="Flattened unique list of all valid container names across all types",
        examples=[
            [
                "skills",
                "skill",
                "claude-skills",
                "commands",
                "command",
                "claude-commands",
            ]
        ],
    )
    canonical_containers: Dict[str, str] = Field(
        description="Maps artifact type to its canonical (preferred) container name",
        examples=[{"skill": "skills", "command": "commands", "agent": "agents"}],
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "container_aliases": {
                    "skill": ["skills", "skill", "claude-skills"],
                    "command": ["commands", "command", "claude-commands"],
                    "agent": ["agents", "agent", "subagents", "claude-agents"],
                    "hook": ["hooks", "hook", "claude-hooks"],
                    "mcp": [
                        "mcp",
                        "mcp-servers",
                        "servers",
                        "mcp_servers",
                        "claude-mcp",
                    ],
                },
                "leaf_containers": [
                    "skills",
                    "skill",
                    "claude-skills",
                    "commands",
                    "command",
                    "claude-commands",
                    "agents",
                    "agent",
                    "subagents",
                    "claude-agents",
                    "hooks",
                    "hook",
                    "claude-hooks",
                    "mcp",
                    "mcp-servers",
                    "servers",
                    "mcp_servers",
                    "claude-mcp",
                ],
                "canonical_containers": {
                    "skill": "skills",
                    "command": "commands",
                    "agent": "agents",
                    "hook": "hooks",
                    "mcp": "mcp",
                },
            }
        }


class FeatureFlagsResponse(BaseModel):
    """Response model for backend feature flags.

    Exposes feature flag state to the frontend so the UI can conditionally
    render features that depend on backend capabilities. Frontend components
    should gate visibility and routing on these flags.

    Attributes:
        composite_artifacts_enabled: Whether composite artifact detection is active.
        deployment_sets_enabled: Whether the deployment sets feature is active.
            When False, all /api/v1/deployment-sets endpoints return 404.
        memory_context_enabled: Whether the Memory & Context Intelligence System
            (memory items, context modules, context packing) is active.
        workflow_engine_enabled: Whether the Workflow Orchestration Engine is active.
            When False, all /api/v1/workflows and /api/v1/workflow-executions
            endpoints return 404 and CLI workflow commands show a coming-soon message.
    """

    composite_artifacts_enabled: bool = Field(
        description=(
            "Whether composite artifact detection is enabled. "
            "When False, discovery always performs flat detection."
        )
    )
    deployment_sets_enabled: bool = Field(
        description=(
            "Whether the deployment sets feature is enabled. "
            "When False, all /api/v1/deployment-sets endpoints return 404."
        )
    )
    memory_context_enabled: bool = Field(
        description=(
            "Whether the Memory & Context Intelligence System is enabled. "
            "Covers memory items, context modules, and context packing."
        )
    )
    workflow_engine_enabled: bool = Field(
        description=(
            "Whether the Workflow Orchestration Engine is enabled. "
            "When False, all /api/v1/workflows and /api/v1/workflow-executions "
            "endpoints return 404 and CLI workflow commands display a coming-soon message."
        )
    )
    modular_content_architecture: bool = Field(
        default=True,
        description=(
            "Whether the Modular Content Architecture is enabled (CECO-4.1). "
            "When True, context entity create/update endpoints store platform-agnostic "
            "core_content separately and assemble platform-specific content at deploy time."
        ),
    )
    version_history_ui_enabled: bool = Field(
        default=True,
        description="Enable the Version History tab in the artifact modal UI.",
    )
    modal_vertical_sidebar_enabled: bool = Field(
        default=True,
        description="Enable vertical sidebar tabs in artifact modal",
    )
    dvcs_signature_verification: bool = Field(
        default=False,
        description=(
            "Whether DVCS signature verification and cryptographic governance is enabled. "
            "When True, the /api/v1/governance endpoints are available for admin users "
            "to perform hard updates, compliance checks, and version signing. "
            "When False, all governance endpoints return 404."
        ),
    )
    dvcs_bom_trailer_injection: bool = Field(
        default=False,
        description=(
            "Whether automatic BOM trailer injection is enabled in git hooks. "
            "When True, the prepare-commit-msg hook will append a SkillBOM-Ref: <bom_hash> "
            "trailer to commits in project directories with active SkillBOM snapshots. "
            "This provides permanent traceability between commits and BOM states."
        ),
    )
    admin_sync_management_enabled: bool = Field(
        default=True,
        description=(
            "Whether the admin sync management page is enabled. "
            "When False, the /admin/sync-management page shows a 'Feature not available' "
            "state. Controlled by SKILLMEAT_ADMIN_SYNC_MANAGEMENT_ENABLED env var."
        ),
    )
    cascade_policy_enabled: bool = Field(
        default=True,
        description=(
            "Whether cascade policy configuration is enabled. "
            "When False, the /admin/cascade-policies page shows a 'Feature not available' "
            "state. Controlled by SKILLMEAT_CASCADE_POLICY_ENABLED env var."
        ),
    )
    team_sync_dashboard_enabled: bool = Field(
        default=True,
        description=(
            "Whether the team sync dashboard is enabled. "
            "When False, the /enterprise/team-sync page is hidden. "
            "Controlled by SKILLMEAT_TEAM_SYNC_DASHBOARD_ENABLED env var."
        ),
    )
    compositions_page_enabled: bool = Field(
        default=True,
        description=(
            "Whether the Compositions page is enabled. "
            "Groups Bundles, Deployment Sets, and Scaffold Templates under a single "
            "higher-tier management surface. Controlled by SKILLMEAT_COMPOSITIONS_PAGE_ENABLED env var."
        ),
    )

    class Config:
        """Pydantic model configuration."""

        json_schema_extra = {
            "example": {
                "composite_artifacts_enabled": True,
                "deployment_sets_enabled": True,
                "memory_context_enabled": True,
                "workflow_engine_enabled": True,
                "modular_content_architecture": True,
                "dvcs_signature_verification": True,
                "dvcs_bom_trailer_injection": False,
            }
        }
