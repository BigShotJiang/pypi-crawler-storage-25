"""Auth session response schema for GET /auth/me endpoint.

Returns the caller's resolved AuthContext, including DB role overrides
(e.g. system_admin elevation stored in enterprise_users table).
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict


class TeamMembershipResponse(BaseModel):
    """Team membership entry returned as part of the auth session.

    Attributes:
        team_id:   Stable identifier for the team.
        team_name: Human-readable display name for the team.
        role:      The caller's role within this team (e.g. "member", "admin").
    """

    team_id: str
    team_name: str
    role: str


class AuthSessionResponse(BaseModel):
    """Response for GET /auth/me — returns the caller's resolved auth context.

    Attributes:
        user_id:      UUID of the authenticated user as a string.
        tenant_id:    UUID of the tenant as a string, or None in local mode.
        roles:        List of role strings resolved for this user (includes DB overrides).
        scopes:       List of permission scope strings granted for this request.
        display_name: Human-readable display name for the user, if available.
        email:        Email address of the user, if available.
        teams:        Team memberships for the user (enterprise only; empty in local mode).
        edition:      Deployment edition ("local" or "enterprise").
    """

    user_id: str
    tenant_id: Optional[str]
    roles: list[str]
    scopes: list[str]
    display_name: Optional[str] = None
    email: Optional[str] = None
    teams: list[TeamMembershipResponse] = []
    edition: str = "local"

    model_config = ConfigDict(from_attributes=True)
