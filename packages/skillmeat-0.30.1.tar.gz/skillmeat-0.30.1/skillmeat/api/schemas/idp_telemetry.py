"""IDP telemetry response DTOs for SAM Backstage integration."""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class IDPWorkflowSummary(BaseModel):
    """Aggregated telemetry summary for a single workflow."""

    workflow_id: str = Field(description="Workflow identifier")
    bundle_id: Optional[str] = Field(
        default=None, description="Bundle this workflow belongs to, if any"
    )
    execution_count: int = Field(description="Total number of executions in the period")
    success_rate: float = Field(
        description="Fraction of executions that succeeded (0.0–1.0)"
    )
    avg_duration_seconds: float = Field(
        description="Mean wall-clock duration across executions, in seconds"
    )
    avg_cost_usd: float = Field(description="Mean token cost across executions, in USD")
    effectiveness_score: float = Field(
        description="Composite effectiveness score (0.0–1.0)"
    )


class IDPPeriodSignals(BaseModel):
    """Derived engineering signals computed over the reporting period."""

    feature_velocity_score: Optional[float] = Field(
        default=None,
        description="Normalized feature delivery velocity for the period",
    )
    test_integrity_delta: Optional[float] = Field(
        default=None,
        description="Change in test integrity score relative to the previous period",
    )
    total_cost_usd: Optional[float] = Field(
        default=None,
        description="Aggregate token cost for all executions in the period, in USD",
    )


class IDPProjectTelemetryResponse(BaseModel):
    """Per-project telemetry response returned to SAM Backstage."""

    project_id: str = Field(description="Project identifier")
    as_of: datetime = Field(
        description="Timestamp at which this snapshot was computed (UTC)"
    )
    top_workflows: List[IDPWorkflowSummary] = Field(
        description="Ranked list of workflow summaries for this project"
    )
    period_signals: Optional[IDPPeriodSignals] = Field(
        default=None,
        description="Aggregated engineering signals for the reporting period",
    )


class IDPGlobalEntry(BaseModel):
    """Single row in the global telemetry feed — workflow summary scoped to a project."""

    project_id: str = Field(description="Project that owns this workflow")
    workflow_id: str = Field(description="Workflow identifier")
    bundle_id: Optional[str] = Field(
        default=None, description="Bundle this workflow belongs to, if any"
    )
    execution_count: int = Field(description="Total number of executions in the period")
    success_rate: float = Field(
        description="Fraction of executions that succeeded (0.0–1.0)"
    )
    avg_duration_seconds: float = Field(
        description="Mean wall-clock duration across executions, in seconds"
    )
    avg_cost_usd: float = Field(description="Mean token cost across executions, in USD")
    effectiveness_score: float = Field(
        description="Composite effectiveness score (0.0–1.0)"
    )


class IDPGlobalTelemetryResponse(BaseModel):
    """Paginated global telemetry feed across all projects."""

    entries: List[IDPGlobalEntry] = Field(
        description="Page of global telemetry entries"
    )
    total: int = Field(description="Total number of entries matching the query")
    limit: int = Field(description="Maximum entries returned in this page")
    offset: int = Field(description="Zero-based offset of this page")
