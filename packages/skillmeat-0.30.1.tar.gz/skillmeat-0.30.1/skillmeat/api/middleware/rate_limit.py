"""Rate limiting middleware for API endpoints.

Implements sliding window burst detection for rate limiting with per-IP tracking,
and a fixed-window per-token rate limiter for use as a FastAPI dependency.

DEPRECATED CLASSES: TokenBucket, RateLimiter, and RateLimitConfig are deprecated
and provided only for backward compatibility. Use SlidingWindowTracker directly.
"""

import logging
import threading
import time
import warnings
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

from fastapi import Depends, HTTPException, Request, Response, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from .burst_detection import (
    RequestFingerprint,
    SlidingWindowTracker,
    create_fingerprint,
)

logger = logging.getLogger(__name__)


# ============================================================================
# DEPRECATED CLASSES - For backward compatibility only
# ============================================================================


@dataclass
class RateLimitConfig:
    """DEPRECATED: Use BurstLimitConfig or direct initialization instead.

    This class is provided for backward compatibility only. New code should
    use SlidingWindowTracker directly with appropriate window and threshold
    parameters.

    Raises:
        DeprecationWarning: When instantiated
    """

    requests_per_hour: int = 100

    def __post_init__(self) -> None:
        """Emit deprecation warning on instantiation."""
        warnings.warn(
            "RateLimitConfig is deprecated and will be removed in v1.0. "
            "Use SlidingWindowTracker with appropriate window_seconds and "
            "threshold parameters instead.",
            DeprecationWarning,
            stacklevel=2,
        )


class TokenBucket:
    """DEPRECATED: Replaced by SlidingWindowTracker.

    This class is provided for backward compatibility only. New code should
    use SlidingWindowTracker instead, which implements sliding window burst
    detection with better accuracy.

    Raises:
        DeprecationWarning: When instantiated
    """

    def __init__(self, *args, **kwargs) -> None:
        """Initialize deprecated TokenBucket.

        Args:
            *args: Ignored (for backward compatibility)
            **kwargs: Ignored (for backward compatibility)
        """
        warnings.warn(
            "TokenBucket is deprecated and will be removed in v1.0. "
            "Use SlidingWindowTracker for burst detection instead.",
            DeprecationWarning,
            stacklevel=2,
        )

    def add_tokens(self, *args, **kwargs) -> None:
        """Deprecated method.

        Raises:
            NotImplementedError: This method is no longer supported
        """
        raise NotImplementedError(
            "TokenBucket is deprecated. Use SlidingWindowTracker instead."
        )

    def consume_token(self, *args, **kwargs) -> bool:
        """Deprecated method.

        Raises:
            NotImplementedError: This method is no longer supported
        """
        raise NotImplementedError(
            "TokenBucket is deprecated. Use SlidingWindowTracker instead."
        )

    def get_available_tokens(self, *args, **kwargs) -> int:
        """Deprecated method.

        Raises:
            NotImplementedError: This method is no longer supported
        """
        raise NotImplementedError(
            "TokenBucket is deprecated. Use SlidingWindowTracker instead."
        )


class RateLimiter:
    """DEPRECATED: Use SlidingWindowTracker directly.

    This class is provided for backward compatibility only. New code should
    use SlidingWindowTracker, which implements sliding window burst detection.

    Raises:
        DeprecationWarning: When instantiated
    """

    def __init__(self, *args, **kwargs) -> None:
        """Initialize deprecated RateLimiter.

        Args:
            *args: Ignored (for backward compatibility)
            **kwargs: Ignored (for backward compatibility)
        """
        warnings.warn(
            "RateLimiter is deprecated and will be removed in v1.0. "
            "Use SlidingWindowTracker for burst detection instead.",
            DeprecationWarning,
            stacklevel=2,
        )

    def is_allowed(self, *args, **kwargs) -> bool:
        """Deprecated method.

        Raises:
            NotImplementedError: This method is no longer supported
        """
        raise NotImplementedError(
            "RateLimiter is deprecated. Use SlidingWindowTracker instead."
        )

    def reset(self, *args, **kwargs) -> None:
        """Deprecated method.

        Raises:
            NotImplementedError: This method is no longer supported
        """
        raise NotImplementedError(
            "RateLimiter is deprecated. Use SlidingWindowTracker instead."
        )


# ============================================================================
# END DEPRECATED CLASSES
# ============================================================================


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware for request rate limiting using sliding window burst detection.

    Applies rate limiting to API endpoints by detecting request bursts within
    a sliding time window. Returns 429 Too Many Requests when burst detected.

    Attributes:
        tracker: SlidingWindowTracker for burst detection
        burst_threshold: Maximum identical requests allowed in window
        block_duration: Seconds to block IP after burst detected
        excluded_paths: Paths to exclude from rate limiting
    """

    def __init__(
        self,
        app,
        window_seconds: int = 10,
        burst_threshold: int = 20,
        block_duration: int = 10,
        excluded_paths: Optional[List[str]] = None,
    ):
        """Initialize rate limit middleware.

        Args:
            app: FastAPI application
            window_seconds: Sliding window size in seconds
            burst_threshold: Max identical requests before burst is triggered
            block_duration: Seconds to block IP after burst
            excluded_paths: List of paths to exclude from rate limiting
        """
        super().__init__(app)

        self.tracker = SlidingWindowTracker(window_seconds=window_seconds)
        self.burst_threshold = burst_threshold
        self.block_duration = block_duration

        self.excluded_paths = excluded_paths or [
            "/health",
            "/docs",
            "/redoc",
            "/openapi.json",
            "/",
        ]

        logger.info(
            f"Rate limit middleware initialized "
            f"(window={window_seconds}s, threshold={burst_threshold}, "
            f"block={block_duration}s, excluded={self.excluded_paths})"
        )

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request with burst detection rate limiting.

        Args:
            request: Incoming request
            call_next: Next middleware in chain

        Returns:
            Response (429 if rate limited, otherwise from next middleware)
        """
        path = request.url.path

        # Check if path is excluded
        if self._is_excluded(path):
            return await call_next(request)

        # Get client IP
        client_ip = self._get_client_ip(request)

        # Check if IP is currently blocked
        if self.tracker.is_blocked(client_ip):
            logger.warning(f"Blocked request from {client_ip} on {path}")
            return self._rate_limit_response(client_ip, blocked=True)

        # Create fingerprint and track request
        fingerprint = create_fingerprint(request)
        self.tracker.add_request(client_ip, fingerprint)

        # Check for burst
        if self.tracker.detect_burst(client_ip, threshold=self.burst_threshold):
            # Block IP and return 429
            self.tracker.block_ip(client_ip, duration=self.block_duration)
            logger.warning(
                f"Burst detected for {client_ip} on {path} - "
                f"blocking for {self.block_duration}s"
            )
            return self._rate_limit_response(client_ip, blocked=True)

        # Process request normally
        response = await call_next(request)

        # Add rate limit headers to successful responses
        self._add_rate_limit_headers(response, client_ip, fingerprint)

        return response

    def _is_excluded(self, path: str) -> bool:
        """Check if path is excluded from rate limiting.

        Args:
            path: Request path

        Returns:
            True if path should be excluded
        """
        for excluded in self.excluded_paths:
            if path == excluded or path.startswith(excluded + "/"):
                return True
        return False

    def _get_client_ip(self, request: Request) -> str:
        """Extract client IP from request.

        Args:
            request: FastAPI request

        Returns:
            Client IP address
        """
        # Check X-Forwarded-For header (for proxies)
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            # Take first IP in chain
            return forwarded.split(",")[0].strip()

        # Fall back to direct client host
        if request.client:
            return request.client.host

        return "unknown"

    def _get_current_count(
        self, client_ip: str, fingerprint: RequestFingerprint
    ) -> int:
        """Get current request count for IP/fingerprint in sliding window.

        Args:
            client_ip: Client IP address
            fingerprint: Request fingerprint to count

        Returns:
            Number of requests with this fingerprint in current window
        """
        records = self.tracker.requests.get(client_ip, [])
        return sum(1 for record in records if record.fingerprint == fingerprint)

    def _add_rate_limit_headers(
        self,
        response: Response,
        client_ip: str,
        fingerprint: RequestFingerprint,
    ) -> None:
        """Add rate limit headers to response.

        Headers indicate rate limit status:
        - X-RateLimit-Window: Sliding window size in seconds
        - X-RateLimit-Threshold: Burst detection threshold
        - X-RateLimit-Current: Current request count in window for this IP
        - X-RateLimit-Blocked: Whether IP is currently blocked

        Args:
            response: FastAPI response object
            client_ip: Client IP address
            fingerprint: Current request fingerprint
        """
        current_count = self._get_current_count(client_ip, fingerprint)
        is_blocked = self.tracker.is_blocked(client_ip)

        response.headers["X-RateLimit-Window"] = str(self.tracker.window_seconds)
        response.headers["X-RateLimit-Threshold"] = str(self.burst_threshold)
        response.headers["X-RateLimit-Current"] = str(current_count)
        response.headers["X-RateLimit-Blocked"] = str(is_blocked).lower()

    def _rate_limit_response(
        self, client_ip: str, blocked: bool = False
    ) -> JSONResponse:
        """Create rate limit exceeded response.

        Args:
            client_ip: Client IP address
            blocked: Whether the IP is blocked

        Returns:
            429 JSON response with rate limit headers
        """
        response = JSONResponse(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            content={
                "error": "RATE_LIMIT_EXCEEDED",
                "message": "Too many requests. Please try again later.",
                "retry_after": self.block_duration,
            },
        )

        # Add rate limit headers to 429 response
        response.headers["Retry-After"] = str(self.block_duration)
        response.headers["X-RateLimit-Window"] = str(self.tracker.window_seconds)
        response.headers["X-RateLimit-Threshold"] = str(self.burst_threshold)
        response.headers["X-RateLimit-Current"] = str(self.burst_threshold)
        response.headers["X-RateLimit-Blocked"] = str(blocked).lower()

        return response


# ============================================================================
# TelemetryRateLimiter — per-client-token, fixed-window dependency
# ============================================================================


@dataclass
class _TokenWindow:
    """Tracking state for one client token in the current fixed window.

    Attributes:
        count:      Number of requests seen in the current window.
        window_start: Unix timestamp when the current window opened.
    """

    count: int = 0
    window_start: float = field(default_factory=time.time)


class TelemetryRateLimiter:
    """Fixed-window rate limiter keyed on client token identity.

    Designed to be used as a FastAPI dependency (not global middleware) so
    individual routers can opt-in — specifically the SAM telemetry ingestion
    router.

    Limits each distinct token identity to ``limit`` requests within every
    ``window_seconds`` second window.  On the (limit+1)-th request within the
    same window a 429 JSON response is raised via ``HTTPException``.  The
    window resets automatically after ``window_seconds`` have elapsed.

    Stale entries (tokens that have not been seen for more than one window)
    are cleaned up periodically to bound memory growth.  Cleanup runs every
    ``cleanup_interval`` requests (amortised O(1) overhead per call).

    Thread safety is provided by a single ``threading.Lock`` protecting the
    shared ``_windows`` dict.  This is sufficient for a single-process Uvicorn
    deployment; swap to an external store (Redis) for multi-process setups.

    Args:
        limit:            Maximum requests allowed per window per token.
        window_seconds:   Duration of each fixed window in seconds.
        cleanup_interval: How many ``check()`` calls between stale-entry
                          sweeps.  Defaults to 500.

    Example — inject into a router::

        limiter = TelemetryRateLimiter(limit=100, window_seconds=60)

        @router.post("/telemetry/ingest")
        async def ingest(
            payload: IngestRequest,
            _: None = Depends(limiter),
            auth: AuthContext = Depends(require_auth()),
        ) -> IngestResponse: ...

    Note: the dependency is registered *before* ``require_auth`` in the
    example above, but the limiter reads the token from the ``Authorization``
    header directly so it does not depend on ``require_auth`` having run first.
    If you want to key on ``AuthContext.user_id`` instead, pass the
    ``AuthContext`` to ``check()`` manually and skip ``__call__``.
    """

    _WINDOW_SECONDS = 60
    _DEFAULT_LIMIT = 100

    def __init__(
        self,
        limit: int = _DEFAULT_LIMIT,
        window_seconds: int = _WINDOW_SECONDS,
        cleanup_interval: int = 500,
    ) -> None:
        self._limit = limit
        self._window_seconds = window_seconds
        self._cleanup_interval = cleanup_interval

        # token_identity -> _TokenWindow
        self._windows: Dict[str, _TokenWindow] = {}
        self._lock = threading.Lock()
        self._calls_since_cleanup = 0

        logger.info(
            "TelemetryRateLimiter initialised "
            f"(limit={limit}/min, window={window_seconds}s)"
        )

    # ------------------------------------------------------------------
    # FastAPI dependency entry point
    # ------------------------------------------------------------------

    async def __call__(self, request: Request) -> None:
        """FastAPI dependency: enforce rate limit or raise HTTP 429.

        Extracts the token identity from the ``Authorization: Bearer <token>``
        header.  Falls back to the client IP when no bearer token is present
        so unauthenticated callers are still subject to a per-IP limit.

        Args:
            request: FastAPI request injected by the dependency system.

        Raises:
            HTTPException: 429 Too Many Requests when the limit is exceeded.
        """
        identity = self._extract_identity(request)
        self._enforce(identity)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _extract_identity(self, request: Request) -> str:
        """Derive a stable identity string from the request.

        Prefers the raw bearer token string so that different clients using
        different tokens from the same IP are tracked independently.  Falls
        back to the client IP for unauthenticated requests.

        Args:
            request: Incoming FastAPI request.

        Returns:
            A non-empty string that uniquely identifies the caller.
        """
        auth_header = request.headers.get("Authorization", "")
        if auth_header.lower().startswith("bearer "):
            token = auth_header[7:].strip()
            if token:
                return token

        # Fallback: use client IP (same logic as RateLimitMiddleware)
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return forwarded.split(",")[0].strip()
        if request.client:
            return request.client.host
        return "unknown"

    def _enforce(self, identity: str) -> None:
        """Increment counter and raise 429 if limit exceeded.

        Args:
            identity: The token/IP string identifying this caller.

        Raises:
            HTTPException: 429 when the caller has exceeded ``_limit``
                requests in the current window.
        """
        now = time.time()

        with self._lock:
            self._calls_since_cleanup += 1
            if self._calls_since_cleanup >= self._cleanup_interval:
                self._cleanup_stale(now)
                self._calls_since_cleanup = 0

            window = self._windows.get(identity)

            if window is None or (now - window.window_start) >= self._window_seconds:
                # New identity or expired window — open a fresh window.
                window = _TokenWindow(count=1, window_start=now)
                self._windows[identity] = window
                return

            window.count += 1
            if window.count > self._limit:
                retry_after = (
                    int(self._window_seconds - (now - window.window_start)) + 1
                )
                logger.warning(
                    f"TelemetryRateLimiter: limit exceeded for identity "
                    f"(count={window.count}, limit={self._limit})"
                )
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail={
                        "error": "RATE_LIMIT_EXCEEDED",
                        "message": (
                            f"Telemetry ingestion rate limit exceeded. "
                            f"Maximum {self._limit} requests per "
                            f"{self._window_seconds} seconds."
                        ),
                        "retry_after": retry_after,
                        "limit": self._limit,
                        "window_seconds": self._window_seconds,
                    },
                    headers={"Retry-After": str(retry_after)},
                )

    def _cleanup_stale(self, now: float) -> None:
        """Remove entries whose window has expired.

        Called periodically (every ``_cleanup_interval`` requests) while the
        lock is already held.  Keeps memory bounded for high-cardinality token
        sets.

        Args:
            now: Current Unix timestamp.
        """
        cutoff = now - self._window_seconds
        stale = [k for k, w in self._windows.items() if w.window_start < cutoff]
        for key in stale:
            del self._windows[key]
        if stale:
            logger.debug(f"TelemetryRateLimiter: cleaned up {len(stale)} stale entries")

    # ------------------------------------------------------------------
    # Introspection helpers (useful for tests)
    # ------------------------------------------------------------------

    def get_count(self, identity: str) -> int:
        """Return the current request count for an identity (0 if unknown/expired).

        Args:
            identity: The token/IP identity string.

        Returns:
            Current count within the active window, or 0.
        """
        now = time.time()
        with self._lock:
            window = self._windows.get(identity)
            if window is None or (now - window.window_start) >= self._window_seconds:
                return 0
            return window.count

    def reset(self, identity: str) -> None:
        """Remove the tracking entry for an identity (test helper).

        Args:
            identity: The token/IP identity string to clear.
        """
        with self._lock:
            self._windows.pop(identity, None)


# Singleton instance for the telemetry router to import and inject.
# Router code: ``from skillmeat.api.middleware.rate_limit import telemetry_rate_limiter``
# Then: ``Depends(telemetry_rate_limiter)``
telemetry_rate_limiter = TelemetryRateLimiter(limit=100, window_seconds=60)
