"""Collection import service for migrating local artifacts to enterprise mode.

Reads the local SkillMeat collection (manifest + lockfile) and imports each
artifact into the enterprise DB via the existing bulk-import path.  Content-
addressed deduplication is performed before each import batch.

Three conflict resolution strategies are supported:

``skip`` (default)
    If a blob with the identical SHA-256 hash already exists in
    ``ArtifactBlob``, skip the artifact entirely (no DB write).  If an
    artifact with the same ``type:name`` exists but with a *different* hash,
    count as ``conflicted`` (also no write).

``create_version``
    If an artifact with the same ``type:name`` exists but has a different
    content hash, create a new ``ArtifactVersion`` record (and a new
    ``ArtifactBlob`` row if the hash is not yet stored).  If the hash is
    identical to the current version, the artifact is skipped as up-to-date.

``overwrite``
    If an artifact with the same ``type:name`` exists (regardless of hash),
    replace its current content by inserting a new ``ArtifactVersion`` row
    (and a new ``ArtifactBlob`` if needed) with ``change_origin='overwrite'``.

Usage::

    from sqlalchemy.orm import Session
    from skillmeat.core.collection_import import CollectionImportService

    svc = CollectionImportService(session=session)
    result = svc.run(dry_run=False)
    print(f"created={result.created} skipped={result.skipped} errors={len(result.errors)}")
"""

from __future__ import annotations

import dataclasses
import hashlib
import logging
import uuid as _uuid_mod
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Sequence

logger = logging.getLogger(__name__)

__all__ = [
    "ImportResult",
    "CollectionImportService",
    "ConflictStrategy",
]

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_BATCH_SIZE = 50

# Conflict resolution strategies.
ConflictStrategy = str  # Literal["skip", "create_version", "overwrite"]

# Artifact types accepted by the BulkImportArtifact schema validator.
# Types outside this set (e.g. workflow, composite) are skipped with a warning
# rather than raising a validation error mid-batch.
_IMPORTABLE_TYPES = {"skill", "command", "agent", "hook", "mcp"}


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclasses.dataclass
class ImportResult:
    """Aggregated outcome of a collection import run.

    Attributes:
        created: Number of artifact records newly created in the DB.
        skipped: Number of artifacts whose CAS hash already existed — no
            DB write was performed.
        conflicted: Number of artifacts where a non-identical record
            already existed and the conflict strategy was "skip".
        errors: Human-readable error strings, one per failed artifact.
        details: Per-artifact action log (dict with ``name``, ``type``,
            ``action``, and optional ``error`` keys).
    """

    created: int = 0
    skipped: int = 0
    conflicted: int = 0
    errors: List[str] = dataclasses.field(default_factory=list)
    details: List[dict] = dataclasses.field(default_factory=list)


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


class CollectionImportService:
    """Migrate a local SkillMeat collection to enterprise mode.

    Args:
        session: SQLAlchemy ``Session`` used for ArtifactBlob CAS look-ups
            and (when not in dry-run mode) for the bulk-import path.
        collection_name: Name of the local collection to import.  ``None``
            uses whichever collection is currently active.
        conflict_strategy: How to handle an artifact whose ``type:name``
            already exists in the DB.  One of ``"skip"`` (default),
            ``"create_version"``, or ``"overwrite"``.
        tier: Artifact tier to assign on import (default ``3``).
        draft: When ``True``, imported artifacts are marked with draft
            status.
        filter_type: If provided, only artifacts whose ``ArtifactType``
            value matches this string are imported.
        filter_tag: If provided, only artifacts that carry this tag are
            imported.
    """

    def __init__(
        self,
        session,  # sqlalchemy.orm.Session — kept untyped to avoid hard dep at import time
        collection_name: Optional[str] = None,
        conflict_strategy: ConflictStrategy = "skip",
        tier: int = 3,
        draft: bool = False,
        filter_type: Optional[str] = None,
        filter_tag: Optional[str] = None,
    ) -> None:
        self._session = session
        self._collection_name = collection_name
        self._conflict_strategy = conflict_strategy
        self._tier = tier
        self._draft = draft
        self._filter_type = filter_type
        self._filter_tag = filter_tag

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self, dry_run: bool = False) -> ImportResult:
        """Run the collection import.

        Args:
            dry_run: When ``True``, all hashing and filtering logic runs
                but no DB writes are performed.  Returned counts reflect
                what *would* happen on a real run.

        Returns:
            :class:`ImportResult` with per-category counts and a
            per-artifact detail log.
        """
        result = ImportResult()

        try:
            artifacts = self._load_and_filter_artifacts()
        except Exception as exc:
            msg = f"Failed to load local collection: {exc}"
            logger.error(msg, exc_info=True)
            result.errors.append(msg)
            return result

        logger.info(
            "CollectionImportService: %d artifact(s) after filtering "
            "(dry_run=%s, filter_type=%r, filter_tag=%r)",
            len(artifacts),
            dry_run,
            self._filter_type,
            self._filter_tag,
        )

        for batch_start in range(0, len(artifacts), _BATCH_SIZE):
            batch = artifacts[batch_start : batch_start + _BATCH_SIZE]
            self._process_batch(batch, dry_run=dry_run, result=result)

        logger.info(
            "CollectionImportService finished: created=%d skipped=%d "
            "conflicted=%d errors=%d",
            result.created,
            result.skipped,
            result.conflicted,
            len(result.errors),
        )
        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_and_filter_artifacts(self):
        """Load the collection and apply type / tag filters.

        Returns:
            Filtered list of :class:`~skillmeat.core.artifact.Artifact`.
        """
        from skillmeat.core.collection import CollectionManager

        collection_mgr = CollectionManager()
        collection = collection_mgr.load_collection(self._collection_name)

        artifacts = list(collection.artifacts)

        if self._filter_type:
            ft = self._filter_type.lower()
            artifacts = [a for a in artifacts if a.type.value.lower() == ft]

        if self._filter_tag:
            tag = self._filter_tag.lower()
            artifacts = [a for a in artifacts if tag in (t.lower() for t in a.tags)]

        return artifacts

    def _compute_artifact_hash(self, artifact_path: Path) -> Optional[str]:
        """Compute the SHA-256 hash of an artifact's entire content tree.

        Walks every file under *artifact_path* (sorted for determinism),
        feeds each file's bytes into a single SHA-256 digest, and returns
        the 64-char hex string.

        Returns ``None`` when the path does not exist or is unreadable.
        """
        if not artifact_path.exists():
            return None

        h = hashlib.sha256()
        try:
            paths = sorted(artifact_path.rglob("*"))
            for fp in paths:
                if fp.is_file():
                    try:
                        h.update(fp.read_bytes())
                    except OSError as exc:
                        logger.warning("Skipping unreadable file %s: %s", fp, exc)
        except OSError as exc:
            logger.error("Cannot walk artifact path %s: %s", artifact_path, exc)
            return None

        return h.hexdigest()

    def _blob_exists(self, sha256_hex: str) -> bool:
        """Return True if an ArtifactBlob with this hash already exists in the DB."""
        from skillmeat.cache.models import ArtifactBlob

        return (
            self._session.query(ArtifactBlob)
            .filter(ArtifactBlob.hash == sha256_hex)
            .first()
            is not None
        )

    def _get_artifact_current_hash(self, artifact_id: str) -> Optional[str]:
        """Return the content hash of the most-recent ArtifactVersion for *artifact_id*.

        Returns ``None`` when no version rows exist for the artifact (new artifact).
        """
        from skillmeat.cache.models import ArtifactVersion

        row = (
            self._session.query(ArtifactVersion)
            .filter(ArtifactVersion.artifact_id == artifact_id)
            .order_by(ArtifactVersion.created_at.desc())
            .first()
        )
        return row.content_hash if row is not None else None

    def _ensure_blob(self, sha256_hex: str, content: str) -> None:
        """Insert an ArtifactBlob row if one with *sha256_hex* does not yet exist.

        This is an idempotent upsert: if the blob already exists the call is a
        no-op.  ``content`` must be the UTF-8 text content of the artifact tree.
        """
        from skillmeat.cache.models import ArtifactBlob

        if self._blob_exists(sha256_hex):
            return

        blob = ArtifactBlob(
            hash=sha256_hex,
            content=content,
            encoding="utf8",
            size_bytes=len(content.encode("utf-8")),
            created_at=datetime.utcnow(),
            compression="none",
        )
        self._session.add(blob)
        self._session.flush()

    def _read_artifact_content(self, artifact_path: Path) -> str:
        """Read and concatenate all files under *artifact_path* for blob storage.

        Files are read in sorted order (same order used by
        :meth:`_compute_artifact_hash`) so the stored text matches the hash.
        Returns an empty string when the path does not exist.
        """
        if not artifact_path.exists():
            return ""
        parts: List[str] = []
        try:
            for fp in sorted(artifact_path.rglob("*")):
                if fp.is_file():
                    try:
                        parts.append(fp.read_text(errors="replace"))
                    except OSError as exc:
                        logger.warning("Skipping unreadable file %s: %s", fp, exc)
        except OSError as exc:
            logger.error("Cannot walk artifact path %s: %s", artifact_path, exc)
        return "\n".join(parts)

    def _create_version_record(
        self,
        artifact_id: str,
        sha256_hex: str,
        parent_hash: Optional[str],
        change_origin: str,
    ) -> None:
        """Insert a new ArtifactVersion row for an existing artifact.

        Args:
            artifact_id: The ``type:name`` primary key of the existing artifact.
            sha256_hex: SHA-256 hash of the new content blob.
            parent_hash: Hash of the immediately preceding version (or ``None``
                for the very first version of this artifact).
            change_origin: Provenance string stored on the new version row.
        """
        from skillmeat.cache.models import ArtifactVersion

        version = ArtifactVersion(
            id=_uuid_mod.uuid4().hex,
            artifact_id=artifact_id,
            content_hash=sha256_hex,
            parent_hash=parent_hash,
            change_origin=change_origin,
            created_at=datetime.utcnow(),
        )
        self._session.add(version)
        self._session.flush()

    def _process_batch(
        self,
        batch: Sequence,
        *,
        dry_run: bool,
        result: ImportResult,
    ) -> None:
        """Process a single batch of artifacts.

        Computes CAS hashes, classifies each artifact according to
        ``self._conflict_strategy``, then (unless *dry_run*) applies the
        appropriate DB write.

        Strategy matrix
        ---------------
        ``skip``
            Blob hash already present → skip.
            Artifact ``type:name`` present with a different hash → conflicted.
            Artifact not present → delegate to bulk import.

        ``create_version``
            Blob hash already present AND it is the artifact's current version
            → skip (already up-to-date).
            Artifact ``type:name`` present but current hash differs → write new
            blob (if needed) + new ArtifactVersion row (parent = old hash).
            Artifact not present → delegate to bulk import.

        ``overwrite``
            Artifact ``type:name`` present (any hash) → write new blob (if
            needed) + new ArtifactVersion row with ``change_origin='overwrite'``.
            Artifact not present → delegate to bulk import.
        """
        from skillmeat.core.path_resolver import ProjectPathResolver

        resolver = ProjectPathResolver()

        to_import: List[dict] = []  # entries for the enterprise bulk import path

        for artifact in batch:
            artifact_name = artifact.name
            artifact_type_val = artifact.type.value

            if artifact_type_val not in _IMPORTABLE_TYPES:
                logger.debug(
                    "Skipping artifact '%s' of type '%s': not supported by bulk import",
                    artifact_name,
                    artifact_type_val,
                )
                result.skipped += 1
                result.details.append(
                    {
                        "name": artifact_name,
                        "type": artifact_type_val,
                        "action": "skipped",
                        "reason": f"type '{artifact_type_val}' not supported by bulk import",
                    }
                )
                continue

            artifact_path = resolver.artifact_path(artifact_name, artifact_type_val)

            sha = self._compute_artifact_hash(artifact_path)
            if sha is None:
                msg = (
                    f"Cannot hash artifact '{artifact_name}' "
                    f"(type={artifact_type_val}): path not found or unreadable"
                )
                logger.warning(msg)
                result.errors.append(msg)
                result.details.append(
                    {
                        "name": artifact_name,
                        "type": artifact_type_val,
                        "action": "error",
                        "error": msg,
                    }
                )
                continue

            # Build the canonical DB artifact ID (type:name).
            artifact_db_id = f"{artifact_type_val}:{artifact_name}"

            # Look up the artifact's current content hash from ArtifactVersion.
            current_hash: Optional[str] = None
            if not dry_run:
                current_hash = self._get_artifact_current_hash(artifact_db_id)

            # ------------------------------------------------------------------
            # skip strategy
            # ------------------------------------------------------------------
            if self._conflict_strategy == "skip":
                if dry_run:
                    # Dry-run: assume it would create (we can't check DB).
                    to_import.append(
                        {"artifact": artifact, "sha256": sha, "path": str(artifact_path)}
                    )
                    continue

                if self._blob_exists(sha):
                    # Identical content already stored — nothing to do.
                    logger.debug(
                        "skip: artifact '%s' CAS hash=%s already present, skipping",
                        artifact_name,
                        sha,
                    )
                    result.skipped += 1
                    result.details.append(
                        {
                            "name": artifact_name,
                            "type": artifact_type_val,
                            "action": "skipped",
                            "sha256": sha,
                        }
                    )
                    continue

                if current_hash is not None and current_hash != sha:
                    # Artifact exists but content differs — record as conflict.
                    logger.debug(
                        "skip: artifact '%s' exists with different hash, conflict",
                        artifact_name,
                    )
                    result.conflicted += 1
                    result.details.append(
                        {
                            "name": artifact_name,
                            "type": artifact_type_val,
                            "action": "conflicted",
                            "sha256": sha,
                            "existing_hash": current_hash,
                        }
                    )
                    continue

                # No prior version known → queue for creation.
                to_import.append(
                    {"artifact": artifact, "sha256": sha, "path": str(artifact_path)}
                )

            # ------------------------------------------------------------------
            # create_version strategy
            # ------------------------------------------------------------------
            elif self._conflict_strategy == "create_version":
                if dry_run:
                    to_import.append(
                        {"artifact": artifact, "sha256": sha, "path": str(artifact_path)}
                    )
                    continue

                if current_hash is None:
                    # Artifact does not exist yet → create via bulk import.
                    to_import.append(
                        {"artifact": artifact, "sha256": sha, "path": str(artifact_path)}
                    )
                    continue

                if current_hash == sha:
                    # Content unchanged — skip (already at this version).
                    logger.debug(
                        "create_version: artifact '%s' hash unchanged, skipping",
                        artifact_name,
                    )
                    result.skipped += 1
                    result.details.append(
                        {
                            "name": artifact_name,
                            "type": artifact_type_val,
                            "action": "skipped",
                            "sha256": sha,
                        }
                    )
                    continue

                # Content differs → create a new version record.
                logger.debug(
                    "create_version: artifact '%s' hash changed %s→%s, creating version",
                    artifact_name,
                    current_hash[:8],
                    sha[:8],
                )
                try:
                    content = self._read_artifact_content(artifact_path)
                    self._ensure_blob(sha, content)
                    self._create_version_record(
                        artifact_id=artifact_db_id,
                        sha256_hex=sha,
                        parent_hash=current_hash,
                        change_origin="collection_import",
                    )
                    self._session.commit()
                    result.created += 1
                    result.details.append(
                        {
                            "name": artifact_name,
                            "type": artifact_type_val,
                            "action": "created",
                            "sha256": sha,
                            "parent_hash": current_hash,
                        }
                    )
                except Exception as exc:
                    self._session.rollback()
                    msg = (
                        f"create_version: failed to create version for "
                        f"'{artifact_name}': {exc}"
                    )
                    logger.error(msg, exc_info=True)
                    result.errors.append(msg)
                    result.details.append(
                        {
                            "name": artifact_name,
                            "type": artifact_type_val,
                            "action": "error",
                            "error": msg,
                        }
                    )

            # ------------------------------------------------------------------
            # overwrite strategy
            # ------------------------------------------------------------------
            elif self._conflict_strategy == "overwrite":
                if dry_run:
                    to_import.append(
                        {"artifact": artifact, "sha256": sha, "path": str(artifact_path)}
                    )
                    continue

                if current_hash is None:
                    # Artifact does not exist yet → create via bulk import.
                    to_import.append(
                        {"artifact": artifact, "sha256": sha, "path": str(artifact_path)}
                    )
                    continue

                if current_hash == sha:
                    # Content identical — overwrite is a no-op.
                    logger.debug(
                        "overwrite: artifact '%s' hash unchanged, skipping",
                        artifact_name,
                    )
                    result.skipped += 1
                    result.details.append(
                        {
                            "name": artifact_name,
                            "type": artifact_type_val,
                            "action": "skipped",
                            "sha256": sha,
                        }
                    )
                    continue

                # Replace content by inserting a new blob + version row.
                logger.debug(
                    "overwrite: artifact '%s' hash %s→%s, overwriting",
                    artifact_name,
                    current_hash[:8],
                    sha[:8],
                )
                try:
                    content = self._read_artifact_content(artifact_path)
                    self._ensure_blob(sha, content)
                    self._create_version_record(
                        artifact_id=artifact_db_id,
                        sha256_hex=sha,
                        parent_hash=current_hash,
                        change_origin="overwrite",
                    )
                    self._session.commit()
                    result.created += 1
                    result.details.append(
                        {
                            "name": artifact_name,
                            "type": artifact_type_val,
                            "action": "overwritten",
                            "sha256": sha,
                            "replaced_hash": current_hash,
                        }
                    )
                except Exception as exc:
                    self._session.rollback()
                    msg = (
                        f"overwrite: failed to overwrite '{artifact_name}': {exc}"
                    )
                    logger.error(msg, exc_info=True)
                    result.errors.append(msg)
                    result.details.append(
                        {
                            "name": artifact_name,
                            "type": artifact_type_val,
                            "action": "error",
                            "error": msg,
                        }
                    )

            else:
                # Unknown strategy — treat as skip to be safe.
                logger.warning(
                    "Unknown conflict_strategy %r for artifact '%s'; skipping",
                    self._conflict_strategy,
                    artifact_name,
                )
                result.skipped += 1
                result.details.append(
                    {
                        "name": artifact_name,
                        "type": artifact_type_val,
                        "action": "skipped",
                        "reason": f"unknown strategy '{self._conflict_strategy}'",
                    }
                )

        if not to_import:
            return

        if dry_run:
            # Dry-run: count everything as would-be-created without touching the DB.
            for entry in to_import:
                result.created += 1
                result.details.append(
                    {
                        "name": entry["artifact"].name,
                        "type": entry["artifact"].type.value,
                        "action": "dry_run_create",
                        "sha256": entry["sha256"],
                    }
                )
            return

        self._bulk_import_batch(to_import, result=result)

    def _bulk_import_batch(
        self,
        to_import: List[dict],
        *,
        result: ImportResult,
    ) -> None:
        """Build a BulkImportRequest and call the enterprise bulk import helper.

        Each artifact in *to_import* is a dict with keys:
        ``artifact``, ``sha256``, and ``path``.
        """
        import asyncio

        from skillmeat.api.routers.artifacts.import_export import _enterprise_bulk_import
        from skillmeat.api.schemas.discovery import BulkImportArtifact, BulkImportRequest

        payloads: List[BulkImportArtifact] = []

        for entry in to_import:
            artifact = entry["artifact"]
            payloads.append(
                BulkImportArtifact(
                    source=artifact.upstream or f"local/{artifact.name}",
                    path=entry["path"],
                    artifact_type=artifact.type.value,
                    name=artifact.name,
                    description=(
                        artifact.metadata.description
                        if artifact.metadata and artifact.metadata.description
                        else None
                    ),
                    author=(
                        artifact.metadata.author
                        if artifact.metadata and artifact.metadata.author
                        else None
                    ),
                    tags=list(artifact.tags) if artifact.tags else [],
                    scope="user",
                )
            )

        if not payloads:
            return

        request = BulkImportRequest(
            artifacts=payloads,
            auto_resolve_conflicts=(self._conflict_strategy == "overwrite"),
        )

        # Build a minimal auth context for the enterprise path.
        auth_context = self._build_auth_context()

        try:
            import_result = asyncio.get_event_loop().run_until_complete(
                _enterprise_bulk_import(
                    request=request,
                    artifact_repo=self._session,  # type: ignore[arg-type]
                    auth_context=auth_context,
                )
            )
        except Exception as exc:
            # Non-fatal: log and record all artifacts in this batch as errors.
            msg = f"Enterprise bulk import failed for batch of {len(payloads)}: {exc}"
            logger.error(msg, exc_info=True)
            result.errors.append(msg)
            for entry in to_import:
                result.details.append(
                    {
                        "name": entry["artifact"].name,
                        "type": entry["artifact"].type.value,
                        "action": "error",
                        "error": msg,
                    }
                )
            return

        # Reconcile per-artifact results.
        for import_res in import_result.results:
            if import_res.status.value == "success":
                result.created += 1
                result.details.append(
                    {
                        "name": import_res.artifact_id,
                        "type": "unknown",
                        "action": "created",
                    }
                )
            elif import_res.status.value == "skipped":
                if self._conflict_strategy == "skip":
                    result.conflicted += 1
                    result.details.append(
                        {
                            "name": import_res.artifact_id,
                            "type": "unknown",
                            "action": "conflicted",
                            "reason": import_res.skip_reason,
                        }
                    )
                else:
                    result.skipped += 1
                    result.details.append(
                        {
                            "name": import_res.artifact_id,
                            "type": "unknown",
                            "action": "skipped",
                        }
                    )
            else:
                err = import_res.error or "unknown error"
                result.errors.append(f"{import_res.artifact_id}: {err}")
                result.details.append(
                    {
                        "name": import_res.artifact_id,
                        "type": "unknown",
                        "action": "error",
                        "error": err,
                    }
                )

    @staticmethod
    def _build_auth_context():
        """Build a minimal local auth context for the enterprise import path.

        Uses a well-known nil UUID for ``user_id`` so the ``AuthContext``
        frozen-dataclass constructor succeeds without a real user session.
        ``tenant_id`` is left ``None`` (single-tenant / local mode).
        """
        import uuid as _uuid

        from skillmeat.api.schemas.auth import AuthContext

        return AuthContext(
            user_id=_uuid.UUID(int=0),  # nil UUID — service identity
            tenant_id=None,
            roles=[],
            scopes=["artifact:write"],
        )
