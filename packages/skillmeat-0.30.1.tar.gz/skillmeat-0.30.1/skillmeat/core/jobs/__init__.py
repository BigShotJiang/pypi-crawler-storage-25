"""Background job definitions for SkillMeat."""
