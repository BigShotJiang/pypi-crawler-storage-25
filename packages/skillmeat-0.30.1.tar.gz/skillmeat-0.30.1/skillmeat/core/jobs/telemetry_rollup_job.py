"""APScheduler job for SAM telemetry rollup.

Runs every 5 minutes to aggregate ExecutionOutcome records into
ProjectAgenticMetrics rollups.  Only registered when the
``sam_telemetry_ingestion_enabled`` feature flag is on.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


def run_telemetry_rollup(session_factory: Callable[[], Any]) -> None:
    """Compute telemetry rollups for the last 10 minutes (with 5-min overlap).

    Creates a DB session, instantiates :class:`RollupService`, runs the
    rollup, logs metrics, and always closes the session.

    Args:
        session_factory: Zero-argument callable that returns a SQLAlchemy
            ``Session``.  Typically ``skillmeat.cache.models.get_session``.
    """
    session = session_factory()
    try:
        from skillmeat.cache.execution_outcome_repository import (
            ExecutionOutcomeRepository,
        )
        from skillmeat.cache.project_agentic_metrics_repository import (
            AgenticMetricsRepository,
        )
        from skillmeat.core.services.rollup_service import RollupService

        outcome_repo = ExecutionOutcomeRepository(session)
        metrics_repo = AgenticMetricsRepository(session)
        service = RollupService(outcome_repo=outcome_repo, metrics_repo=metrics_repo)

        now = datetime.now(tz=timezone.utc)
        period_end = now
        period_start = now - timedelta(minutes=10)

        start_ms = time.monotonic()
        result = service.compute_rollups(
            period_start=period_start,
            period_end=period_end,
        )
        duration_ms = int((time.monotonic() - start_ms) * 1000)

        logger.info(
            "rollup_completed groups_processed=%d duration_ms=%d",
            result.groups_processed,
            duration_ms,
            extra={
                "event": "rollup_completed",
                "groups_processed": result.groups_processed,
                "duration_ms": duration_ms,
            },
        )
    except Exception as exc:
        logger.error(
            "rollup_failed error=%s",
            exc,
            exc_info=True,
            extra={
                "event": "rollup_failed",
                "error": str(exc),
            },
        )
    finally:
        session.close()


def register_rollup_scheduler(app: Any) -> Optional[Any]:
    """Register the telemetry rollup background scheduler on ``app``.

    Checks the ``sam_telemetry_ingestion_enabled`` feature flag.  When the
    flag is on, a :class:`~apscheduler.schedulers.background.BackgroundScheduler`
    running every 5 minutes is started and returned.  When the flag is off,
    logs a skip notice and returns ``None``.

    Args:
        app: FastAPI application instance.  ``app.state`` is used to store the
            scheduler so the lifespan shutdown handler can stop it cleanly.

    Returns:
        The started scheduler, or ``None`` if the feature flag is disabled.
    """
    from skillmeat.api.config import get_settings

    settings = get_settings()
    if not settings.sam_telemetry_ingestion_enabled:
        logger.info(
            "Telemetry rollup job skipped: sam_telemetry_ingestion_enabled=false"
        )
        return None

    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.interval import IntervalTrigger
    from skillmeat.cache.models import get_session

    scheduler = BackgroundScheduler()
    scheduler.add_job(
        run_telemetry_rollup,
        trigger=IntervalTrigger(minutes=5),
        kwargs={"session_factory": get_session},
        id="telemetry_rollup",
        name="SAM telemetry rollup",
        replace_existing=True,
        max_instances=1,
        misfire_grace_time=60,
    )
    scheduler.start()
    logger.info("Telemetry rollup scheduler started (interval=5min)")
    return scheduler
