# =============================================================================
# SkillMeat Core Enums
# =============================================================================
"""
Core enumeration types for SkillMeat.

This module defines enums for platforms and tools used in artifact metadata.
All enums inherit from (str, Enum) to enable JSON serialization and string
comparison without explicit .value access.

Example:
    >>> from skillmeat.core.enums import Platform, Tool
    >>> import json
    >>> json.dumps({"platform": Platform.CLAUDE_CODE, "tool": Tool.BASH})
    '{"platform": "claude_code", "tool": "Bash"}'
"""

from enum import Enum
from typing import Dict, Optional

__all__ = [
    "Platform",
    "Tool",
    "ArtifactTier",
    "CollectionTier",
    "ARTIFACT_TYPE_TIER_MAP",
    "get_artifact_tier",
]


# =============================================================================
# Platform Enum
# =============================================================================


class Platform(str, Enum):
    """Supported platforms for artifact execution.

    Represents the target execution environment where an artifact is designed
    to run. Used in frontmatter metadata to indicate platform compatibility.

    Attributes:
        CLAUDE_CODE: Anthropic's Claude Code CLI tool
        CODEX: OpenAI Codex CLI and integrations
        GEMINI: Google Gemini CLI and integrations
        CURSOR: Cursor AI editor
        BOB: IBM's Bob AI coding assistant
        REMOTE_GIT: Remote Git repository (e.g. Backstage / IDP deployments)
        OTHER: Other platforms or unspecified

    Example:
        >>> Platform.CLAUDE_CODE.value
        'claude_code'
        >>> Platform.CLAUDE_CODE == "claude_code"
        True
        >>> str(Platform.CURSOR)
        'cursor'
        >>> Platform.REMOTE_GIT.value
        'remote_git'
    """

    CLAUDE_CODE = "claude_code"
    CODEX = "codex"
    GEMINI = "gemini"
    CURSOR = "cursor"
    BOB = "bob"
    REMOTE_GIT = "remote_git"
    OTHER = "other"


# =============================================================================
# Tool Enum
# =============================================================================


class Tool(str, Enum):
    """Claude Code tools available for artifact use.

    Represents the tools that can be specified in the frontmatter `allowed-tools`
    field. Tool names use PascalCase to match Claude Code's exact tool naming
    convention.

    These are the 18 tools available in Claude Code as of 2025:

    File Operations:
        READ: Read file contents
        WRITE: Write/create files
        EDIT: Edit existing files (single edit)
        MULTI_EDIT: Multiple edits in one operation
        GLOB: Find files by pattern
        GREP: Search file contents
        NOTEBOOK_EDIT: Edit Jupyter notebooks

    Execution:
        BASH: Execute shell commands
        KILL_SHELL: Terminate running shell processes

    User Interaction:
        ASK_USER_QUESTION: Prompt user for input
        TODO_WRITE: Manage task lists

    Web & Search:
        WEB_FETCH: Fetch web content
        WEB_SEARCH: Search the web

    Agent & Orchestration:
        TASK: Spawn sub-agent tasks
        TASK_OUTPUT: Retrieve task results
        SKILL: Invoke skills

    Planning:
        ENTER_PLAN_MODE: Enter planning mode
        EXIT_PLAN_MODE: Exit planning mode

    Example:
        >>> Tool.BASH.value
        'Bash'
        >>> Tool.READ == "Read"
        True
        >>> [Tool.BASH, Tool.READ, Tool.WRITE]
        [<Tool.BASH: 'Bash'>, <Tool.READ: 'Read'>, <Tool.WRITE: 'Write'>]
    """

    # File Operations
    READ = "Read"
    WRITE = "Write"
    EDIT = "Edit"
    MULTI_EDIT = "MultiEdit"
    GLOB = "Glob"
    GREP = "Grep"
    NOTEBOOK_EDIT = "NotebookEdit"

    # Execution
    BASH = "Bash"
    KILL_SHELL = "KillShell"

    # User Interaction
    ASK_USER_QUESTION = "AskUserQuestion"
    TODO_WRITE = "TodoWrite"

    # Web & Search
    WEB_FETCH = "WebFetch"
    WEB_SEARCH = "WebSearch"

    # Agent & Orchestration
    TASK = "Task"
    TASK_OUTPUT = "TaskOutput"
    SKILL = "Skill"

    # Planning
    ENTER_PLAN_MODE = "EnterPlanMode"
    EXIT_PLAN_MODE = "ExitPlanMode"


# =============================================================================
# CollectionTier Enum (DVCS Phase 3: 4-Tier Collection Inheritance)
# =============================================================================


class CollectionTier(str, Enum):
    """DVCS collection tier for artifact namespace scoping.

    Defines the five tiers of the collection inheritance hierarchy.
    Artifacts at higher tiers (marketplace, enterprise) are more broadly
    shared; lower tiers (dev, project) are more narrowly scoped.

    Note:
        ``local`` is NOT a member of this enum.  It is a parser-level alias
        that normalises to ``project`` during FQAN resolution.  Any code
        that sees the string ``"local"`` should map it to
        ``CollectionTier.project`` before persisting.

    Attributes:
        marketplace: Globally published artifacts from the Claude marketplace.
        enterprise: Organisation-wide artifacts shared across all teams.
        team: Team-scoped artifacts visible within a business unit.
        dev: Developer personal workspace artifacts.
        project: Project-local artifacts scoped to a single ``.claude/``
                 directory.

    Example:
        >>> CollectionTier.enterprise.value
        'enterprise'
        >>> CollectionTier.project == "project"
        True
        >>> str(CollectionTier.dev)
        'dev'
    """

    marketplace = "marketplace"
    enterprise = "enterprise"
    team = "team"
    dev = "dev"
    project = "project"


# =============================================================================
# ArtifactTier Enum (ADR-008: Artifact Tiering and Composition Hierarchy)
# =============================================================================

# Deferred import to avoid circular dependency at module load time.
# skillmeat.core.artifact_detection does not import from skillmeat.core.enums,
# so this import direction is safe.
from skillmeat.core.artifact_detection import ArtifactType  # noqa: E402


class ArtifactTier(int, Enum):
    """4-tier artifact hierarchy per ADR-008.

    Implements the Downward Dependency Rule: an artifact may only contain,
    compose, or execute artifacts at its own tier or a lower tier.

    Tiers:
        TIER_0: Atomic Primitives — foundational, indivisible leaf nodes.
        TIER_1: First-Order Composites — organize/bundle Tier 0 primitives.
        TIER_2: Recursive Aggregators — meta-containers for Tier 0 and Tier 1.
        TIER_3: Process & Distribution — execution over time or cross-environment
                transport; the top of the hierarchy.

    Example:
        >>> ArtifactTier.TIER_0.value
        0
        >>> ArtifactTier.TIER_3 > ArtifactTier.TIER_1
        True
    """

    # ADR-008: Tier 0 — Atomic Primitives (leaf nodes)
    TIER_0 = 0
    # ADR-008: Tier 1 — First-Order Composites (structural layer)
    TIER_1 = 1
    # ADR-008: Tier 2 — Recursive Aggregators (orchestration scope)
    TIER_2 = 2
    # ADR-008: Tier 3 — Process & Distribution (top level)
    TIER_3 = 3


# Mapping of every current ArtifactType value to its tier per ADR-008.
#
# Tier 0 — Atomic Primitives: Compute/Execution + Knowledge/State leaf nodes
#   AGENT, COMMAND, HOOK, MCP      → Compute / Execution primitives
#   PROJECT_CONFIG, SPEC_FILE, RULE_FILE, CONTEXT_FILE, PROGRESS_TEMPLATE
#                                  → Context Entity / Knowledge primitives
#
# Tier 1 — First-Order Composites: Structural wrappers for Tier 0
#   SKILL          → Compute Wrapper (embeds Commands, Agents, Hooks)
#   COMPOSITE      → Generic composite type (e.g., Plugin variant)
#   CONTEXT_MODULE → Curated set of context files (.md, rules, specs)
#   TEMPLATE       → Parameterised scaffold that generates a project structure
#   GROUP          → Named collection of artifacts deployed together as a unit
#
# Tier 2 — Recursive Aggregators: Meta-containers for Tier 0 and Tier 1
#   DEPLOYMENT_SET → Versioned, deployable set of artifacts for CI/CD pipelines
#   CONTEXT_PACK   → Portable bundle of context modules and supporting files
#
# Tier 3 — Process & Distribution: Top-level execution/transport envelope
#   WORKFLOW       → Multi-stage execution process
#   BUNDLE         → Distribution unit for cross-environment transport
ARTIFACT_TYPE_TIER_MAP: Dict[ArtifactType, ArtifactTier] = {
    # --- Tier 0: Atomic Primitives (ADR-008 §Tier 0) ---
    ArtifactType.AGENT: ArtifactTier.TIER_0,  # Compute / Execution primitive
    ArtifactType.COMMAND: ArtifactTier.TIER_0,  # Compute / Execution primitive
    ArtifactType.HOOK: ArtifactTier.TIER_0,  # Compute / Execution primitive
    ArtifactType.MCP: ArtifactTier.TIER_0,  # Compute / Execution primitive (MCP Server)
    ArtifactType.PROJECT_CONFIG: ArtifactTier.TIER_0,  # Context Entity / Knowledge primitive
    ArtifactType.SPEC_FILE: ArtifactTier.TIER_0,  # Context Entity / Knowledge primitive
    ArtifactType.RULE_FILE: ArtifactTier.TIER_0,  # Context Entity / Knowledge primitive
    ArtifactType.CONTEXT_FILE: ArtifactTier.TIER_0,  # Context Entity / Knowledge primitive
    ArtifactType.PROGRESS_TEMPLATE: ArtifactTier.TIER_0,  # Context Entity / Knowledge primitive
    # --- Tier 1: First-Order Composites (ADR-008 §Tier 1) ---
    ArtifactType.SKILL: ArtifactTier.TIER_1,  # Compute Wrapper (embeds Tier 0 artifacts)
    ArtifactType.COMPOSITE: ArtifactTier.TIER_1,  # Explicit composite bundle (e.g., Plugin)
    ArtifactType.CONTEXT_MODULE: ArtifactTier.TIER_1,  # Curated set of context files
    ArtifactType.TEMPLATE: ArtifactTier.TIER_1,  # Parameterised project scaffold
    ArtifactType.GROUP: ArtifactTier.TIER_1,  # Named collection deployed as a unit
    # --- Tier 2: Recursive Aggregators (ADR-008 §Tier 2) ---
    ArtifactType.DEPLOYMENT_SET: ArtifactTier.TIER_2,  # Versioned deployable artifact set
    ArtifactType.CONTEXT_PACK: ArtifactTier.TIER_2,  # Portable bundle of context modules
    # --- Tier 3: Process & Distribution (ADR-008 §Tier 3) ---
    ArtifactType.WORKFLOW: ArtifactTier.TIER_3,  # Multi-stage execution process
    ArtifactType.BUNDLE: ArtifactTier.TIER_3,  # Distribution unit for cross-environment transport
}


def get_artifact_tier(artifact_type: ArtifactType) -> Optional[ArtifactTier]:
    """Return the tier for an artifact type, or None if unknown.

    Args:
        artifact_type: The artifact type to look up.

    Returns:
        The ``ArtifactTier`` for the given type, or ``None`` if the type is
        not present in ``ARTIFACT_TYPE_TIER_MAP``.  Callers should treat
        ``None`` as an unknown / unclassified type and apply whatever
        policy is appropriate (e.g. reject as per ``TierEnforcementEngine``).

    Example:
        >>> get_artifact_tier(ArtifactType.SKILL)
        <ArtifactTier.TIER_1: 1>
        >>> get_artifact_tier(ArtifactType.WORKFLOW)
        <ArtifactTier.TIER_3: 3>
    """
    return ARTIFACT_TYPE_TIER_MAP.get(artifact_type)
