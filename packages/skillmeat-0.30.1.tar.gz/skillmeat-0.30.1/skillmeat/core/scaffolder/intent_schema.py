"""Intent Set schema, dataclasses, validation, and serialization.

Defines the structured output of the project-analyzer subagent and the
input consumed by the artifact-curator subagent.

Schema reference: .claude/skills/project-scaffolder/schemas/intent-schema.yaml
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

# ─────────────────────────────────────────────────────────────────────────────
# Enumerations (as frozensets for O(1) membership checks)
# ─────────────────────────────────────────────────────────────────────────────

CAPABILITY_ENUM: frozenset[str] = frozenset(
    {
        "python-backend",
        "typescript-backend",
        "react-frontend",
        "angular-frontend",
        "vue-frontend",
        "relational-database",
        "document-store",
        "vector-search",
        "ci-cd",
        "auth",
        "caching",
        "logging",
        "testing",
        "containerization",
        "graphql",
        "background-jobs",
        "message-queue",
        "api-gateway",
        "monitoring",
        "secret-management",
        "infrastructure-as-code",
    }
)

SCOPE_VARIANT_ENUM: frozenset[str] = frozenset(
    {
        "whole-project",
        "feature",
        "artifact-type-scoped",
    }
)

PRIORITY_ENUM: frozenset[str] = frozenset({"high", "medium", "low"})

# Priority weights used in aggregate_confidence calculation
PRIORITY_WEIGHTS: Dict[str, float] = {
    "high": 1.0,
    "medium": 0.6,
    "low": 0.3,
}

# Regex for scaffold_run_id validation
_RUN_ID_PATTERN = re.compile(r"^scaf_\d{8}_[0-9a-f]{8}$")


# ─────────────────────────────────────────────────────────────────────────────
# Dataclasses
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class Intent:
    """A single detected capability requirement extracted from project context.

    Attributes:
        id: Sequential identifier within this Intent Set (format: "int_NNN").
        capability: Primary capability detected. Must be a member of CAPABILITY_ENUM.
        stack: Optional specific technology within the capability (e.g., "fastapi").
        confidence: Analyzer confidence score, 0.0–1.0.
        source: Human-readable reference to the evidence for this intent.
        priority: Importance level — "high", "medium", or "low".
    """

    id: str
    capability: str
    stack: Optional[str]
    confidence: float
    source: str
    priority: str

    def __post_init__(self) -> None:
        if not self.id:
            raise ValueError("Intent.id must not be empty")
        if self.capability not in CAPABILITY_ENUM:
            raise ValueError(
                f"Intent.capability '{self.capability}' is not a valid capability. "
                f"Valid values: {sorted(CAPABILITY_ENUM)}"
            )
        if not (0.0 <= self.confidence <= 1.0):
            raise ValueError(
                f"Intent.confidence must be between 0.0 and 1.0, got {self.confidence}"
            )
        if self.priority not in PRIORITY_ENUM:
            raise ValueError(
                f"Intent.priority '{self.priority}' must be one of {sorted(PRIORITY_ENUM)}"
            )


@dataclass
class IntentSet:
    """Complete output of a single project-analyzer run.

    Attributes:
        scaffold_run_id: Unique run identifier (format: "scaf_YYYYMMDD_<8-hex>").
        generated_at: ISO 8601 timestamp of when this set was produced.
        scope_variant: Curation scope — "whole-project", "feature", or "artifact-type-scoped".
        source_summary: One-line summary of the input context (max 200 chars).
        intents: Ordered list of detected requirements.
        aggregate_confidence: Weighted mean confidence by priority.
        interview_triggered: Whether the interview flow was triggered.
    """

    scaffold_run_id: str
    generated_at: str
    scope_variant: str
    source_summary: str
    intents: List[Intent] = field(default_factory=list)
    aggregate_confidence: float = 0.0
    interview_triggered: bool = False

    def __post_init__(self) -> None:
        if not _RUN_ID_PATTERN.match(self.scaffold_run_id):
            raise ValueError(
                f"scaffold_run_id '{self.scaffold_run_id}' must match pattern "
                "scaf_YYYYMMDD_<8-char hex> (e.g., scaf_20260407_a1b2c3d4)"
            )
        if self.scope_variant not in SCOPE_VARIANT_ENUM:
            raise ValueError(
                f"scope_variant '{self.scope_variant}' must be one of "
                f"{sorted(SCOPE_VARIANT_ENUM)}"
            )
        if len(self.source_summary) > 200:
            raise ValueError("source_summary must not exceed 200 characters")
        if not (0.0 <= self.aggregate_confidence <= 1.0):
            raise ValueError(
                f"aggregate_confidence must be between 0.0 and 1.0, "
                f"got {self.aggregate_confidence}"
            )


# ─────────────────────────────────────────────────────────────────────────────
# Confidence computation
# ─────────────────────────────────────────────────────────────────────────────


def compute_aggregate_confidence(intents: List[Intent]) -> float:
    """Compute weighted mean confidence across intents, weighted by priority.

    Formula:
        weights = {high: 1.0, medium: 0.6, low: 0.3}
        aggregate = sum(confidence[i] * weight[priority[i]]) / sum(weight[priority[i]])

    Returns 0.0 for an empty intent list.

    Args:
        intents: List of Intent objects.

    Returns:
        Weighted aggregate confidence in [0.0, 1.0].
    """
    if not intents:
        return 0.0

    weighted_sum = 0.0
    weight_total = 0.0

    for intent in intents:
        w = PRIORITY_WEIGHTS.get(intent.priority, 0.0)
        weighted_sum += intent.confidence * w
        weight_total += w

    if weight_total == 0.0:
        return 0.0

    return round(weighted_sum / weight_total, 4)


# ─────────────────────────────────────────────────────────────────────────────
# Validation
# ─────────────────────────────────────────────────────────────────────────────


def validate_intent_set(data: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """Validate a raw dict (e.g., from yaml.safe_load) against the Intent Set schema.

    Does not require the dict to be a fully constructed IntentSet — validates
    field presence, types, and enum membership without raising exceptions.

    Args:
        data: Raw dictionary to validate.

    Returns:
        Tuple of (is_valid, errors) where errors is a list of human-readable
        error strings. is_valid is True only when errors is empty.
    """
    errors: List[str] = []

    if not isinstance(data, dict):
        return False, [
            "Top-level value must be a mapping (dict), got: " + type(data).__name__
        ]

    # Required top-level string fields
    for field_name in (
        "scaffold_run_id",
        "generated_at",
        "scope_variant",
        "source_summary",
    ):
        if field_name not in data:
            errors.append(f"Missing required field: '{field_name}'")
        elif not isinstance(data[field_name], str):
            errors.append(
                f"Field '{field_name}' must be a string, got {type(data[field_name]).__name__}"
            )

    # scaffold_run_id format
    run_id = data.get("scaffold_run_id", "")
    if isinstance(run_id, str) and run_id and not _RUN_ID_PATTERN.match(run_id):
        errors.append(
            f"scaffold_run_id '{run_id}' must match pattern scaf_YYYYMMDD_<8-char hex>"
        )

    # scope_variant enum
    scope = data.get("scope_variant", "")
    if isinstance(scope, str) and scope and scope not in SCOPE_VARIANT_ENUM:
        errors.append(
            f"scope_variant '{scope}' must be one of: {sorted(SCOPE_VARIANT_ENUM)}"
        )

    # source_summary length
    summary = data.get("source_summary", "")
    if isinstance(summary, str) and len(summary) > 200:
        errors.append("source_summary must not exceed 200 characters")

    # aggregate_confidence
    if "aggregate_confidence" not in data:
        errors.append("Missing required field: 'aggregate_confidence'")
    else:
        ac = data["aggregate_confidence"]
        if not isinstance(ac, (int, float)):
            errors.append(
                f"aggregate_confidence must be a number, got {type(ac).__name__}"
            )
        elif not (0.0 <= float(ac) <= 1.0):
            errors.append(f"aggregate_confidence must be between 0.0 and 1.0, got {ac}")

    # interview_triggered
    if "interview_triggered" not in data:
        errors.append("Missing required field: 'interview_triggered'")
    elif not isinstance(data["interview_triggered"], bool):
        errors.append(
            f"interview_triggered must be a boolean, got {type(data['interview_triggered']).__name__}"
        )

    # intents list
    if "intents" not in data:
        errors.append("Missing required field: 'intents'")
    elif not isinstance(data["intents"], list):
        errors.append(f"intents must be a list, got {type(data['intents']).__name__}")
    else:
        for idx, intent in enumerate(data["intents"]):
            prefix = f"intents[{idx}]"
            if not isinstance(intent, dict):
                errors.append(
                    f"{prefix}: must be a mapping, got {type(intent).__name__}"
                )
                continue
            for sub_field in ("id", "capability", "source", "priority"):
                if sub_field not in intent:
                    errors.append(f"{prefix}: missing required field '{sub_field}'")
                elif not isinstance(intent[sub_field], str):
                    errors.append(
                        f"{prefix}.{sub_field}: must be a string, got {type(intent[sub_field]).__name__}"
                    )
            # capability enum
            cap = intent.get("capability", "")
            if isinstance(cap, str) and cap and cap not in CAPABILITY_ENUM:
                errors.append(
                    f"{prefix}.capability '{cap}' is not valid. "
                    f"Valid values: {sorted(CAPABILITY_ENUM)}"
                )
            # priority enum
            pri = intent.get("priority", "")
            if isinstance(pri, str) and pri and pri not in PRIORITY_ENUM:
                errors.append(
                    f"{prefix}.priority '{pri}' must be one of: {sorted(PRIORITY_ENUM)}"
                )
            # confidence
            if "confidence" not in intent:
                errors.append(f"{prefix}: missing required field 'confidence'")
            else:
                conf = intent["confidence"]
                if not isinstance(conf, (int, float)):
                    errors.append(
                        f"{prefix}.confidence must be a number, got {type(conf).__name__}"
                    )
                elif not (0.0 <= float(conf) <= 1.0):
                    errors.append(
                        f"{prefix}.confidence must be between 0.0 and 1.0, got {conf}"
                    )
            # stack is optional — only type-check if present
            if "stack" in intent and intent["stack"] is not None:
                if not isinstance(intent["stack"], str):
                    errors.append(
                        f"{prefix}.stack must be a string or null, got {type(intent['stack']).__name__}"
                    )

    return len(errors) == 0, errors


# ─────────────────────────────────────────────────────────────────────────────
# YAML serialization
# ─────────────────────────────────────────────────────────────────────────────


def _intent_to_dict(intent: Intent) -> Dict[str, Any]:
    """Convert an Intent dataclass to a plain dict suitable for YAML serialization."""
    return {
        "id": intent.id,
        "capability": intent.capability,
        "stack": intent.stack,
        "confidence": intent.confidence,
        "source": intent.source,
        "priority": intent.priority,
    }


def _dict_to_intent(data: Dict[str, Any]) -> Intent:
    """Construct an Intent from a dict (e.g., from yaml.safe_load)."""
    return Intent(
        id=data["id"],
        capability=data["capability"],
        stack=data.get("stack"),
        confidence=float(data["confidence"]),
        source=data["source"],
        priority=data["priority"],
    )


def load_intent_set(path: Path) -> IntentSet:
    """Load an IntentSet from a YAML file.

    Validates the file contents before constructing the IntentSet.
    Raises ValueError with a summary of validation errors if invalid.

    Args:
        path: Path to the YAML file (e.g., scaffold-intents.yaml).

    Returns:
        Fully constructed IntentSet.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the YAML content fails schema validation.
        yaml.YAMLError: If the file is not valid YAML.
    """
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)

    is_valid, errors = validate_intent_set(data)
    if not is_valid:
        raise ValueError(
            f"Intent Set YAML at '{path}' failed validation:\n"
            + "\n".join(f"  - {e}" for e in errors)
        )

    intents = [_dict_to_intent(i) for i in data.get("intents", [])]

    return IntentSet(
        scaffold_run_id=data["scaffold_run_id"],
        generated_at=data["generated_at"],
        scope_variant=data["scope_variant"],
        source_summary=data["source_summary"],
        intents=intents,
        aggregate_confidence=float(data["aggregate_confidence"]),
        interview_triggered=bool(data["interview_triggered"]),
    )


def dump_intent_set(iset: IntentSet, path: Path) -> None:
    """Write an IntentSet to a YAML file.

    Serializes in a human-readable format compatible with yaml.safe_load.
    Creates parent directories if they do not exist.

    Args:
        iset: The IntentSet to serialize.
        path: Destination file path (e.g., scaffold-intents.yaml).
    """
    path.parent.mkdir(parents=True, exist_ok=True)

    data: Dict[str, Any] = {
        "scaffold_run_id": iset.scaffold_run_id,
        "generated_at": iset.generated_at,
        "scope_variant": iset.scope_variant,
        "source_summary": iset.source_summary,
        "intents": [_intent_to_dict(i) for i in iset.intents],
        "aggregate_confidence": iset.aggregate_confidence,
        "interview_triggered": iset.interview_triggered,
    }

    with open(path, "w", encoding="utf-8") as fh:
        yaml.safe_dump(
            data, fh, default_flow_style=False, sort_keys=False, allow_unicode=True
        )
