"""HTTP orchestration layer for the artifact-curator three-leg search.

This module is the thin I/O wrapper around the three API endpoints the curator
uses.  All scoring and ranking logic lives in
:mod:`skillmeat.core.scaffolder.curator`.

Public API::

    search_all_legs — call match, metadata, and marketplace endpoints in parallel

Logging:

    Each leg emits ``leg_start``, ``leg_complete``, and (on failure) ``leg_error``
    structured log records at DEBUG / WARNING level.  Use the standard Python
    logging infrastructure to capture them.

Environment:

    ``SKILLMEAT_API_URL`` — overrides the default base URL (``http://localhost:8080``).
"""

from __future__ import annotations

import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple

import httpx

from skillmeat.core.scaffolder.curator import CuratorError, build_query
from skillmeat.core.scaffolder.intent_schema import Intent

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "http://localhost:8080"


# ─────────────────────────────────────────────────────────────────────────────
# Internal per-leg fetch helpers
# ─────────────────────────────────────────────────────────────────────────────


def _fetch_match(
    intent: Intent,
    base_url: str,
    client: httpx.Client,
) -> List[Dict]:
    """Call ``GET /api/v1/match`` and return the artifacts list.

    Args:
        intent:   The intent to search for.
        base_url: API base URL (no trailing slash).
        client:   Shared ``httpx.Client`` instance.

    Returns:
        List of raw match result dicts.

    Raises:
        CuratorError: On HTTP error or unexpected response shape.
    """
    query = build_query(intent)
    url = f"{base_url}/api/v1/match"
    params = {"q": query, "limit": 10, "min_confidence": 0}

    leg_name = "match"
    t0 = time.monotonic()
    logger.debug(
        "leg_start",
        extra={
            "leg": leg_name,
            "intent_id": intent.id,
            "query": query,
            "url": url,
        },
    )

    try:
        resp = client.get(url, params=params)
        resp.raise_for_status()
    except httpx.HTTPStatusError as exc:
        raise CuratorError(
            f"Match leg HTTP error {exc.response.status_code} for intent {intent.id!r}: {exc}"
        ) from exc
    except httpx.RequestError as exc:
        raise CuratorError(
            f"Match leg request error for intent {intent.id!r}: {exc}"
        ) from exc

    duration_ms = int((time.monotonic() - t0) * 1000)
    body = resp.json()
    results: List[Dict] = body.get("artifacts", [])

    logger.debug(
        "leg_complete",
        extra={
            "leg": leg_name,
            "intent_id": intent.id,
            "duration_ms": duration_ms,
            "result_count": len(results),
            "status": resp.status_code,
        },
    )
    return results


def _fetch_metadata(
    intent: Intent,
    base_url: str,
    client: httpx.Client,
) -> List[Dict]:
    """Call ``GET /api/v1/artifacts`` filtered by capability tag.

    Args:
        intent:   The intent whose capability drives the tag filter.
        base_url: API base URL.
        client:   Shared ``httpx.Client`` instance.

    Returns:
        List of raw artifact dicts.

    Raises:
        CuratorError: On HTTP error or unexpected response shape.
    """
    # Build a CSV tag filter from capability + optional stack
    tag_parts = [intent.capability]
    if intent.stack:
        tag_parts.append(intent.stack)
    tags_csv = ",".join(tag_parts)

    url = f"{base_url}/api/v1/artifacts"
    params: Dict[str, Any] = {"tags": tags_csv, "page_size": 50}

    leg_name = "metadata"
    t0 = time.monotonic()
    logger.debug(
        "leg_start",
        extra={
            "leg": leg_name,
            "intent_id": intent.id,
            "tags": tags_csv,
            "url": url,
        },
    )

    try:
        resp = client.get(url, params=params)
        resp.raise_for_status()
    except httpx.HTTPStatusError as exc:
        raise CuratorError(
            f"Metadata leg HTTP error {exc.response.status_code} for intent {intent.id!r}: {exc}"
        ) from exc
    except httpx.RequestError as exc:
        raise CuratorError(
            f"Metadata leg request error for intent {intent.id!r}: {exc}"
        ) from exc

    duration_ms = int((time.monotonic() - t0) * 1000)
    body = resp.json()
    # Paginated response: items may be under "items" or "artifacts" key
    results: List[Dict] = body.get("items") or body.get("artifacts") or []

    logger.debug(
        "leg_complete",
        extra={
            "leg": leg_name,
            "intent_id": intent.id,
            "duration_ms": duration_ms,
            "result_count": len(results),
            "status": resp.status_code,
        },
    )
    return results


def _fetch_marketplace(
    intent: Intent,
    base_url: str,
    client: httpx.Client,
) -> List[Dict]:
    """Call ``GET /api/v1/marketplace/listings`` for marketplace candidates.

    Failures (timeout, HTTP error, network error) are caught here and logged
    as warnings.  The caller receives an empty list, enabling graceful local-
    only fallback.

    Args:
        intent:   The intent to search for.
        base_url: API base URL.
        client:   Shared ``httpx.Client`` instance.

    Returns:
        List of raw marketplace listing dicts, or ``[]`` on any error.
    """
    query = build_query(intent)
    tag_parts = [intent.capability]
    if intent.stack:
        tag_parts.append(intent.stack)
    tags_csv = ",".join(tag_parts)

    url = f"{base_url}/api/v1/marketplace/listings"
    params: Dict[str, Any] = {"query": query, "tags": tags_csv, "page_size": 10}

    leg_name = "marketplace"
    t0 = time.monotonic()
    logger.debug(
        "leg_start",
        extra={
            "leg": leg_name,
            "intent_id": intent.id,
            "query": query,
            "url": url,
        },
    )

    try:
        resp = client.get(url, params=params)
        resp.raise_for_status()
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as exc:
        duration_ms = int((time.monotonic() - t0) * 1000)
        logger.warning(
            "leg_error — marketplace unavailable, using local-only fallback",
            extra={
                "leg": leg_name,
                "intent_id": intent.id,
                "duration_ms": duration_ms,
                "error": str(exc),
            },
        )
        return []

    duration_ms = int((time.monotonic() - t0) * 1000)
    body = resp.json()
    results: List[Dict] = body.get("items") or body.get("listings") or []

    logger.debug(
        "leg_complete",
        extra={
            "leg": leg_name,
            "intent_id": intent.id,
            "duration_ms": duration_ms,
            "result_count": len(results),
            "status": resp.status_code,
        },
    )
    return results


# ─────────────────────────────────────────────────────────────────────────────
# Public orchestration function
# ─────────────────────────────────────────────────────────────────────────────


def search_all_legs(
    intent: Intent,
    *,
    base_url: Optional[str] = None,
    timeout_s: float = 10.0,
    marketplace_enabled: bool = True,
) -> Tuple[List[Dict], List[Dict], List[Dict]]:
    """Fetch results from all three search legs concurrently.

    Calls the following endpoints in parallel (via a :class:`ThreadPoolExecutor`
    with up to 3 workers):

    - ``GET /api/v1/match`` — semantic/TF-IDF artifact matching
    - ``GET /api/v1/artifacts`` — metadata tag filter
    - ``GET /api/v1/marketplace/listings`` — marketplace browse (optional)

    Each leg has its own *timeout_s* timeout.  Marketplace failures are
    swallowed and returned as an empty list (graceful fallback).  Non-
    marketplace failures raise :exc:`~skillmeat.core.scaffolder.curator.CuratorError`.

    Args:
        intent:              The Intent to search for.
        base_url:            API base URL.  Defaults to the ``SKILLMEAT_API_URL``
                             environment variable or ``http://localhost:8080``.
        timeout_s:           Per-leg HTTP timeout in seconds (default 10.0).
        marketplace_enabled: When ``False``, the marketplace leg is skipped
                             entirely and returns an empty list.  Controlled
                             by the ``SCAFFOLD_MARKETPLACE_ENABLED`` feature flag.

    Returns:
        A three-tuple ``(match_results, metadata_results, marketplace_results)``
        where each element is a list of raw API response dicts.

    Raises:
        CuratorError: When the match or metadata legs fail.

    Example::

        from skillmeat.core.scaffolder.search import search_all_legs
        from skillmeat.core.scaffolder.intent_schema import Intent

        intent = Intent("int_001", "python-backend", "fastapi", 0.9, "PRD", "high")
        match, meta, mkt = search_all_legs(intent, base_url="http://localhost:8080")
    """
    resolved_url = (
        base_url or os.environ.get("SKILLMEAT_API_URL") or _DEFAULT_BASE_URL
    ).rstrip("/")

    # Use a separate client per call so timeouts are independent.
    timeout = httpx.Timeout(timeout_s)

    with httpx.Client(timeout=timeout) as client:
        if marketplace_enabled:
            legs = [
                ("match", _fetch_match),
                ("metadata", _fetch_metadata),
                ("marketplace", _fetch_marketplace),
            ]
        else:
            legs = [
                ("match", _fetch_match),
                ("metadata", _fetch_metadata),
            ]

        results: Dict[str, List[Dict]] = {}
        exceptions: Dict[str, Exception] = {}

        with ThreadPoolExecutor(max_workers=3) as executor:
            future_to_name = {
                executor.submit(fn, intent, resolved_url, client): name
                for name, fn in legs
            }

            for future in as_completed(future_to_name):
                name = future_to_name[future]
                try:
                    results[name] = future.result()
                except Exception as exc:  # noqa: BLE001
                    exceptions[name] = exc

        # Marketplace errors are already handled inside _fetch_marketplace.
        # Propagate non-marketplace errors as CuratorError.
        for name, exc in exceptions.items():
            if name != "marketplace":
                raise CuratorError(
                    f"Search leg {name!r} failed for intent {intent.id!r}: {exc}"
                ) from exc

    match_results = results.get("match", [])
    metadata_results = results.get("metadata", [])
    marketplace_results = results.get("marketplace", [])

    return match_results, metadata_results, marketplace_results
