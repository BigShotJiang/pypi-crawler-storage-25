"""Deterministic fallback analyzer for the project-scaffolder CLI.

This module provides keyword-based intent extraction when the LLM-powered
``project-analyzer`` subagent is unavailable (e.g., CLI invoked without an
active Claude Code session).

**This is explicitly a fallback.**  For production-quality analysis, invoke
the ``project-analyzer`` LLM subagent via Claude Code and supply the resulting
``.intent-set.yaml`` file with ``--from-context``.  The heuristic analyzer
detects common technology keywords but cannot reason about architecture, infer
implicit requirements, or ask clarifying questions.

Public API::

    KEYWORD_MAP   — extensible mapping from token → (capability, stack, confidence)
    analyze_text  — scan free text and return an IntentSet
    analyze_context — load text from a file, directory, or free-text string
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from skillmeat.core.scaffolder.intent_schema import (
    Intent,
    IntentSet,
    compute_aggregate_confidence,
)

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Keyword map
# Format: lowercase_token → (capability, stack_or_None, confidence)
# Extend this dict to add new technology detections without touching any other
# logic.  Tokens are matched as whole words (space / punctuation boundaries).
# ─────────────────────────────────────────────────────────────────────────────

KEYWORD_MAP: Dict[str, Tuple[str, Optional[str], float]] = {
    # Python backend
    "fastapi": ("python-backend", "fastapi", 0.85),
    "flask": ("python-backend", "flask", 0.80),
    "django": ("python-backend", "django", 0.85),
    "starlette": ("python-backend", "starlette", 0.75),
    "tornado": ("python-backend", "tornado", 0.70),
    # TypeScript backend
    "express": ("typescript-backend", "express", 0.75),
    "nestjs": ("typescript-backend", "nestjs", 0.85),
    "hono": ("typescript-backend", "hono", 0.80),
    "koa": ("typescript-backend", "koa", 0.70),
    "elysia": ("typescript-backend", "elysia", 0.70),
    # React / frontend
    "react": ("react-frontend", "react", 0.80),
    "next.js": ("react-frontend", "nextjs", 0.85),
    "nextjs": ("react-frontend", "nextjs", 0.85),
    "remix": ("react-frontend", "remix", 0.80),
    # Angular
    "angular": ("angular-frontend", "angular", 0.85),
    # Vue
    "vue": ("vue-frontend", "vue", 0.80),
    "nuxt": ("vue-frontend", "nuxt", 0.85),
    # Relational database
    "postgres": ("relational-database", "postgresql", 0.85),
    "postgresql": ("relational-database", "postgresql", 0.85),
    "mysql": ("relational-database", "mysql", 0.85),
    "sqlite": ("relational-database", "sqlite", 0.80),
    "sqlalchemy": ("relational-database", "sqlalchemy", 0.80),
    "prisma": ("relational-database", "prisma", 0.80),
    "drizzle": ("relational-database", "drizzle", 0.75),
    # Document store
    "mongodb": ("document-store", "mongodb", 0.85),
    "firestore": ("document-store", "firestore", 0.80),
    "dynamodb": ("document-store", "dynamodb", 0.80),
    # Vector search
    "pinecone": ("vector-search", "pinecone", 0.85),
    "weaviate": ("vector-search", "weaviate", 0.85),
    "qdrant": ("vector-search", "qdrant", 0.85),
    "chroma": ("vector-search", "chroma", 0.80),
    "pgvector": ("vector-search", "pgvector", 0.80),
    # Auth
    "auth": ("auth", None, 0.65),
    "authentication": ("auth", None, 0.70),
    "oauth": ("auth", "oauth2", 0.80),
    "jwt": ("auth", "jwt", 0.80),
    "clerk": ("auth", "clerk", 0.85),
    "auth0": ("auth", "auth0", 0.85),
    "supabase": ("auth", "supabase", 0.80),
    # Caching
    "redis": ("caching", "redis", 0.85),
    "memcached": ("caching", "memcached", 0.80),
    "cache": ("caching", None, 0.55),
    # CI/CD
    "github actions": ("ci-cd", "github-actions", 0.85),
    "ci/cd": ("ci-cd", None, 0.70),
    "pipeline": ("ci-cd", None, 0.55),
    "jenkins": ("ci-cd", "jenkins", 0.80),
    "circleci": ("ci-cd", "circleci", 0.80),
    # Logging
    "logging": ("logging", None, 0.65),
    "structured logs": ("logging", None, 0.70),
    "logfire": ("logging", "logfire", 0.80),
    "opentelemetry": ("monitoring", "opentelemetry", 0.80),
    # Testing
    "pytest": ("testing", "pytest", 0.85),
    "jest": ("testing", "jest", 0.85),
    "vitest": ("testing", "vitest", 0.80),
    "playwright": ("testing", "playwright", 0.80),
    "cypress": ("testing", "cypress", 0.80),
    # Containerization
    "docker": ("containerization", "docker", 0.85),
    "kubernetes": ("containerization", "kubernetes", 0.85),
    "k8s": ("containerization", "kubernetes", 0.85),
    "podman": ("containerization", "podman", 0.80),
    # GraphQL
    "graphql": ("graphql", None, 0.85),
    "apollo": ("graphql", "apollo", 0.80),
    # Background jobs
    "celery": ("background-jobs", "celery", 0.85),
    "rq": ("background-jobs", "rq", 0.75),
    "dramatiq": ("background-jobs", "dramatiq", 0.80),
    # Message queue
    "rabbitmq": ("message-queue", "rabbitmq", 0.85),
    "kafka": ("message-queue", "kafka", 0.85),
    "sqs": ("message-queue", "sqs", 0.80),
    "nats": ("message-queue", "nats", 0.80),
    # API gateway
    "kong": ("api-gateway", "kong", 0.80),
    "nginx": ("api-gateway", "nginx", 0.75),
    "traefik": ("api-gateway", "traefik", 0.80),
    # Monitoring
    "prometheus": ("monitoring", "prometheus", 0.85),
    "grafana": ("monitoring", "grafana", 0.80),
    "datadog": ("monitoring", "datadog", 0.85),
    "sentry": ("monitoring", "sentry", 0.80),
    # Secret management
    "vault": ("secret-management", "vault", 0.85),
    "aws secrets": ("secret-management", "aws-secrets-manager", 0.85),
    "doppler": ("secret-management", "doppler", 0.80),
    # Infrastructure as code
    "terraform": ("infrastructure-as-code", "terraform", 0.85),
    "pulumi": ("infrastructure-as-code", "pulumi", 0.85),
    "cdk": ("infrastructure-as-code", "aws-cdk", 0.80),
    "ansible": ("infrastructure-as-code", "ansible", 0.80),
}

# ─────────────────────────────────────────────────────────────────────────────
# Context loading
# ─────────────────────────────────────────────────────────────────────────────

_MAX_CHARS = 40_000  # ~10K tokens


def analyze_context(context: str) -> Tuple[str, str]:
    """Load and normalise text from a file path, directory, or free-text string.

    Detection order:
    1. Existing file path → read its contents.
    2. Existing directory path → concatenate top-level ``*.md`` files (capped).
    3. Plain text → return as-is.

    Args:
        context: File path, directory path, or free-text description.

    Returns:
        ``(text, source_summary)`` where *text* is the content to analyse and
        *source_summary* is a short label describing the input origin.
    """
    path = Path(context)

    if path.is_file():
        try:
            raw = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.warning("Could not read file %s: %s", path, exc)
            raw = context
        if len(raw) > _MAX_CHARS:
            logger.warning(
                "Input file %s exceeds %d chars — truncating", path, _MAX_CHARS
            )
            raw = raw[:_MAX_CHARS]
        return raw, path.name

    if path.is_dir():
        parts: List[str] = []
        total = 0
        # Prioritise README.md, then remaining .md files alphabetically
        md_files: List[Path] = []
        readme = path / "README.md"
        if readme.is_file():
            md_files.append(readme)
        for f in sorted(path.glob("*.md")):
            if f != readme:
                md_files.append(f)

        for md in md_files:
            try:
                chunk = md.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            remaining = _MAX_CHARS - total
            if remaining <= 0:
                break
            if len(chunk) > remaining:
                logger.warning("Truncating %s to fit within context budget", md.name)
                chunk = chunk[:remaining]
            parts.append(f"# {md.name}\n{chunk}")
            total += len(chunk)

        text = "\n\n".join(parts) if parts else ""
        return text, path.name

    # Free text
    text = context
    if len(text) > _MAX_CHARS:
        logger.warning("Free-text input exceeds %d chars — truncating", _MAX_CHARS)
        text = text[:_MAX_CHARS]
    source_summary = text[:80].replace("\n", " ")
    return text, source_summary


# ─────────────────────────────────────────────────────────────────────────────
# Heuristic analysis
# ─────────────────────────────────────────────────────────────────────────────


def _generate_run_id(text: str) -> str:
    """Generate a deterministic scaffold_run_id from input text and current date."""
    digest = hashlib.md5(text.encode("utf-8")).hexdigest()[:8]  # noqa: S324
    date_str = datetime.now(tz=timezone.utc).strftime("%Y%m%d")
    return f"scaf_{date_str}_{digest}"


def analyze_text(
    text: str,
    *,
    source_summary: str = "",
    scope_variant: str = "whole-project",
) -> IntentSet:
    """Scan *text* for capability keywords and return an IntentSet.

    **This is a deterministic fallback.**  It uses a fixed keyword map and
    cannot reason about implicit requirements.  For accurate analysis, use the
    ``project-analyzer`` LLM subagent and pass the resulting intent-set YAML
    via ``--from-context``.

    The function deduplicates by *capability*: when the same capability is
    matched by multiple keywords the highest-confidence match wins.  The
    returned IntentSet has intents ordered by confidence (descending).

    Args:
        text:           Raw text to scan (file contents, README, free text).
        source_summary: Short label describing the input source.  Truncated to
                        195 chars to stay within IntentSet's 200-char limit.
        scope_variant:  Scope for the generated IntentSet; must be a member of
                        ``SCOPE_VARIANT_ENUM``.  Defaults to ``"whole-project"``.

    Returns:
        An ``IntentSet`` containing one ``Intent`` per detected capability.
        Returns an IntentSet with an empty intents list when no keywords match.
    """
    normalised = text.lower()

    # capability → (stack, confidence, matched_token)
    best: Dict[str, Tuple[Optional[str], float, str]] = {}

    for token, (capability, stack, confidence) in KEYWORD_MAP.items():
        # Simple substring match on the normalised text.
        # Multi-word tokens (e.g. "github actions") are matched as a phrase.
        if token in normalised:
            existing = best.get(capability)
            if existing is None or confidence > existing[1]:
                best[capability] = (stack, confidence, token)

    # Build Intent objects ordered by confidence descending
    sorted_caps = sorted(best.items(), key=lambda kv: kv[1][1], reverse=True)

    intents: List[Intent] = []
    for idx, (capability, (stack, confidence, token)) in enumerate(sorted_caps):
        intent_id = f"int_{idx + 1:03d}"
        priority = (
            "high"
            if confidence >= 0.80
            else ("medium" if confidence >= 0.65 else "low")
        )
        intents.append(
            Intent(
                id=intent_id,
                capability=capability,
                stack=stack,
                confidence=confidence,
                source=f"heuristic keyword match: '{token}'",
                priority=priority,
            )
        )

    run_id = _generate_run_id(text)
    generated_at = datetime.now(tz=timezone.utc).isoformat()
    # Clamp source_summary to 195 chars (IntentSet validates ≤200)
    safe_summary = (
        source_summary[:195] if source_summary else text[:80].replace("\n", " ")[:195]
    )
    aggregate_confidence = compute_aggregate_confidence(intents)

    logger.debug(
        "heuristic_analyzer: detected %d intent(s) from %d chars of text",
        len(intents),
        len(text),
    )

    return IntentSet(
        scaffold_run_id=run_id,
        generated_at=generated_at,
        scope_variant=scope_variant,
        source_summary=safe_summary,
        intents=intents,
        aggregate_confidence=aggregate_confidence,
        interview_triggered=False,
    )
