"""Project Scaffolder core module.

Provides the Intent Set schema, validation, serialization, interview
trigger logic, and deterministic artifact curation for the
project-scaffolder skill.

Public API:
    Intent                     — dataclass for a single detected capability requirement
    IntentSet                  — dataclass for a complete scaffold analysis output
    CAPABILITY_ENUM            — valid capability identifiers
    SCOPE_VARIANT_ENUM         — valid scope variant identifiers
    validate_intent_set        — validate a raw dict against the Intent Set schema
    load_intent_set            — load an IntentSet from a YAML file
    dump_intent_set            — write an IntentSet to a YAML file
    compute_aggregate_confidence — weighted mean confidence by priority
    should_trigger_interview   — interview trigger heuristic
    generate_questions         — produce targeted clarifying questions
    CandidateArtifact          — scored artifact candidate dataclass
    CuratorError               — raised on unrecoverable curator errors
    build_query                — format an Intent into a search query string
    compute_final_score        — weighted blend of the three sub-scores
    merge_search_results       — merge raw API responses into CandidateArtifacts
    dedupe_candidates          — keep highest-scoring entry per uuid
    rank_candidates            — sort, threshold-filter, and cap per intent
    apply_scope_filter         — remove candidates present in an exclusion set
    search_all_legs            — fetch all three search legs concurrently
    CLAUDE_DIR_TYPE_MAP        — .claude/ subdir-name → artifact type mapping
    scan_deployed_artifacts    — return (type, name) set from .claude/ filesystem scan
    build_scope_filter         — predicate factory: keep candidates not already deployed
    get_filter_for_scope       — convenience: wire scan + build based on scope_variant
    PreviewDecision            — dataclass capturing the user's confirmation choice
    render_preview             — render rich Table preview of scaffold candidates
    prompt_for_confirmation    — interactive confirm / remove / abort prompt
    apply_decision             — filter candidates by PreviewDecision
    run_preview_flow           — orchestrate render → prompt → apply in one call
"""

from __future__ import annotations

from skillmeat.core.scaffolder.curator import (
    CandidateArtifact,
    CuratorError,
    apply_scope_filter,
    build_query,
    compute_final_score,
    compute_marketplace_score,
    compute_metadata_score,
    dedupe_candidates,
    merge_search_results,
    normalize_semantic,
    rank_candidates,
)
from skillmeat.core.scaffolder.intent_schema import (
    CAPABILITY_ENUM,
    SCOPE_VARIANT_ENUM,
    Intent,
    IntentSet,
    compute_aggregate_confidence,
    dump_intent_set,
    load_intent_set,
    validate_intent_set,
)
from skillmeat.core.scaffolder.interview import (
    generate_questions,
    should_trigger_interview,
)
from skillmeat.core.scaffolder.scope_filter import (
    CLAUDE_DIR_TYPE_MAP,
    build_scope_filter,
    get_filter_for_scope,
    scan_deployed_artifacts,
)
from skillmeat.core.scaffolder.assembly import (
    AssemblyError,
    AssemblyResult,
    assemble_bundle,
    build_bundle_metadata,
    sort_candidates_deterministic,
)
from skillmeat.core.scaffolder.search import search_all_legs
from skillmeat.core.scaffolder.preview import (
    PreviewDecision,
    apply_decision,
    prompt_for_confirmation,
    render_preview,
    run_preview_flow,
)
from skillmeat.core.scaffolder.heuristic_analyzer import (
    KEYWORD_MAP,
    analyze_context,
    analyze_text,
)

__all__ = [
    # Intent schema
    "CAPABILITY_ENUM",
    "SCOPE_VARIANT_ENUM",
    "Intent",
    "IntentSet",
    "compute_aggregate_confidence",
    "dump_intent_set",
    "load_intent_set",
    "validate_intent_set",
    # Interview flow
    "generate_questions",
    "should_trigger_interview",
    # Curator (pure scoring)
    "CandidateArtifact",
    "CuratorError",
    "apply_scope_filter",
    "build_query",
    "compute_final_score",
    "compute_marketplace_score",
    "compute_metadata_score",
    "dedupe_candidates",
    "merge_search_results",
    "normalize_semantic",
    "rank_candidates",
    # Scope filtering (feature variant)
    "CLAUDE_DIR_TYPE_MAP",
    "build_scope_filter",
    "get_filter_for_scope",
    "scan_deployed_artifacts",
    # Search (HTTP orchestration)
    "search_all_legs",
    # Assembly (Bundle API integration)
    "AssemblyError",
    "AssemblyResult",
    "assemble_bundle",
    "build_bundle_metadata",
    "sort_candidates_deterministic",
    # Preview + confirmation flow
    "PreviewDecision",
    "apply_decision",
    "prompt_for_confirmation",
    "render_preview",
    "run_preview_flow",
    # Heuristic fallback analyzer
    "KEYWORD_MAP",
    "analyze_context",
    "analyze_text",
]
