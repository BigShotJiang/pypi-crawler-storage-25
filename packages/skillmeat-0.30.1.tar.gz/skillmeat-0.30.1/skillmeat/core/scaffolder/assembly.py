"""Bundle assembly layer for the project-scaffolder.

Thin I/O wrapper that converts a ranked list of :class:`CandidateArtifact`
objects into a live Bundle entity via the SkillMeat Bundle API.

Public API::

    sort_candidates_deterministic — alphabetically stable ordering (type, name)
    build_bundle_metadata         — construct the Bundle create payload dict
    AssemblyResult                — dataclass returned by assemble_bundle
    AssemblyError                 — raised on API failures during assembly
    assemble_bundle               — orchestrate the full create + member-add flow

Logging:

    ``bundle_create``, ``member_add``, and ``sidecar_write`` structured log
    records at DEBUG level.  On failure, WARNING-level ``assembly_error``
    records include the offending member uuid when applicable.

Environment:

    ``SKILLMEAT_API_URL`` — overrides the default base URL
    (``http://localhost:8080``).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import httpx

from skillmeat.core.scaffolder.curator import CandidateArtifact
from skillmeat.core.scaffolder.intent_schema import IntentSet, dump_intent_set

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "http://localhost:8080"

# ─────────────────────────────────────────────────────────────────────────────
# Exceptions
# ─────────────────────────────────────────────────────────────────────────────


class AssemblyError(Exception):
    """Raised when the Bundle API returns an error during assembly.

    Attributes:
        member_uuid: UUID of the member whose addition triggered the failure,
            or ``None`` when the error occurred during bundle creation.
    """

    def __init__(self, message: str, member_uuid: Optional[str] = None) -> None:
        super().__init__(message)
        self.member_uuid = member_uuid


# ─────────────────────────────────────────────────────────────────────────────
# Result dataclass
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class AssemblyResult:
    """Output of a successful (or dry-run) bundle assembly.

    Attributes:
        bundle_id:       UUID of the created Bundle entity, or the synthetic
                         ``"dry-run-{scaffold_run_id}"`` string in dry-run mode.
        bundle_name:     Human-readable name that was assigned to the bundle.
        member_count:    Number of artifact members successfully added.
        member_uuids:    Ordered list of artifact UUIDs that were added.
        intent_set_path: Absolute path where the Intent Set YAML sidecar was
                         written, or ``None`` in dry-run mode or when
                         ``intent_set_dir`` was not provided.
    """

    bundle_id: str
    bundle_name: str
    member_count: int
    member_uuids: List[str] = field(default_factory=list)
    intent_set_path: Optional[Path] = None


# ─────────────────────────────────────────────────────────────────────────────
# Pure helpers
# ─────────────────────────────────────────────────────────────────────────────


def sort_candidates_deterministic(
    candidates: List[CandidateArtifact],
) -> List[CandidateArtifact]:
    """Sort candidates by ``(artifact_type asc, name asc)`` for idempotent ordering.

    Bundle contents are ordered alphabetically so that repeated scaffolding runs
    with the same intent set produce the same member sequence, regardless of
    the order that the curator returned results.

    Args:
        candidates: Unsorted list of scored candidates.

    Returns:
        New list with the same elements in deterministic order.  The input
        list is not mutated.
    """
    return sorted(candidates, key=lambda c: (c.artifact_type, c.name))


def build_bundle_metadata(
    iset: IntentSet,
    candidates: List[CandidateArtifact],
) -> Dict:
    """Construct the payload dict for ``POST /api/v1/bundles/entities``.

    The returned dict is JSON-serialisable and matches
    :class:`~skillmeat.api.schemas.bundles.BundleEntityCreateRequest`.

    Fields:
        - ``name`` — ``"scaffold-{iset.scaffold_run_id}"``
        - ``description`` — derived from the first 120 chars of
          ``iset.source_summary``
        - ``tags`` — deduplicated, sorted list of capabilities from the
          Intent Set (one per intent)
        - ``metadata`` — structured provenance dict with ``scaffold_run_id``,
          ``scaffold_generated_at``, ``scope_variant``, ``intent_count``,
          ``artifact_count``, and ``intent_set_ref="sidecar"``

    Args:
        iset:       The Intent Set produced by the project-analyzer.
        candidates: Curated candidate list (used for ``artifact_count`` only).

    Returns:
        Dict suitable for passing as JSON body to the Bundle create endpoint.
    """
    # Deduplicated, sorted capability tags from intents
    capabilities: List[str] = sorted({intent.capability for intent in iset.intents})

    return {
        "name": f"scaffold-{iset.scaffold_run_id}",
        "description": (f"Scaffolded bundle for {iset.source_summary[:120]}"),
        "tags": capabilities,
        "metadata": {
            "scaffold_run_id": iset.scaffold_run_id,
            "scaffold_generated_at": iset.generated_at,
            "scope_variant": iset.scope_variant,
            "intent_count": len(iset.intents),
            "artifact_count": len(candidates),
            "intent_set_ref": "sidecar",
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# Assembly orchestration
# ─────────────────────────────────────────────────────────────────────────────


def assemble_bundle(
    iset: IntentSet,
    candidates: List[CandidateArtifact],
    *,
    base_url: str = _DEFAULT_BASE_URL,
    timeout_s: float = 30.0,
    intent_set_dir: Optional[Path] = None,
    dry_run: bool = False,
) -> AssemblyResult:
    """Assemble a Bundle entity from a ranked candidate list.

    Orchestrates three steps:

    1. ``POST /api/v1/bundles/entities`` — create the bundle.
    2. ``POST /api/v1/bundles/entities/{bundle_id}/members`` — add each
       candidate in deterministic order (stops on first failure).
    3. Write the Intent Set YAML sidecar to
       ``{intent_set_dir or Path.cwd()}/{scaffold_run_id}.intent-set.yaml``.

    In dry-run mode all three steps are skipped; a synthetic
    :class:`AssemblyResult` is returned immediately with no network or disk
    I/O.

    Args:
        iset:           Intent Set produced by the project-analyzer.
        candidates:     Ranked candidates from the curator.
        base_url:       SkillMeat API base URL (no trailing slash).
        timeout_s:      Per-request HTTP timeout in seconds.
        intent_set_dir: Directory for the sidecar YAML; defaults to
                        ``Path.cwd()``.
        dry_run:        When ``True``, skip all I/O and return a synthetic
                        result.

    Returns:
        :class:`AssemblyResult` describing the created bundle.

    Raises:
        :class:`AssemblyError`: On HTTP errors during bundle create or member
            add.  Includes ``member_uuid`` when the failure is member-specific.
    """
    sorted_candidates = sort_candidates_deterministic(candidates)
    bundle_name = f"scaffold-{iset.scaffold_run_id}"

    # ── Dry-run fast path ────────────────────────────────────────────────────
    if dry_run:
        logger.debug(
            "assembly_dry_run",
            extra={
                "scaffold_run_id": iset.scaffold_run_id,
                "candidate_count": len(sorted_candidates),
            },
        )
        return AssemblyResult(
            bundle_id=f"dry-run-{iset.scaffold_run_id}",
            bundle_name=bundle_name,
            member_count=len(sorted_candidates),
            member_uuids=[c.uuid for c in sorted_candidates],
            intent_set_path=None,
        )

    payload = build_bundle_metadata(iset, candidates)
    base_url = base_url.rstrip("/")
    timeout = httpx.Timeout(timeout_s)

    with httpx.Client(timeout=timeout) as client:
        # ── Step 1: create bundle ────────────────────────────────────────────
        t0 = time.monotonic()
        try:
            resp = client.post(
                f"{base_url}/api/v1/bundles/entities",
                json=payload,
            )
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            logger.warning(
                "assembly_error",
                extra={
                    "step": "bundle_create",
                    "status_code": exc.response.status_code,
                    "scaffold_run_id": iset.scaffold_run_id,
                },
            )
            raise AssemblyError(
                f"Bundle create failed with HTTP {exc.response.status_code}: {exc}"
            ) from exc
        except httpx.RequestError as exc:
            logger.warning(
                "assembly_error",
                extra={
                    "step": "bundle_create",
                    "error": str(exc),
                    "scaffold_run_id": iset.scaffold_run_id,
                },
            )
            raise AssemblyError(f"Bundle create request error: {exc}") from exc

        bundle_data = resp.json()
        bundle_id: str = bundle_data["id"]
        duration_ms = int((time.monotonic() - t0) * 1000)

        logger.debug(
            "bundle_create",
            extra={
                "bundle_id": bundle_id,
                "bundle_name": bundle_name,
                "duration_ms": duration_ms,
            },
        )

        # ── Step 2: add members ──────────────────────────────────────────────
        member_uuids: List[str] = []
        member_url = f"{base_url}/api/v1/bundles/entities/{bundle_id}/members"

        for candidate in sorted_candidates:
            member_payload = {
                "member_type": "artifact",
                "artifact_uuid": candidate.uuid,
                "artifact_type": candidate.artifact_type,
                "artifact_tier": 0,
                "relationship_type": "contains",
            }

            t1 = time.monotonic()
            try:
                member_resp = client.post(member_url, json=member_payload)
                member_resp.raise_for_status()
            except httpx.HTTPStatusError as exc:
                logger.warning(
                    "assembly_error",
                    extra={
                        "step": "member_add",
                        "member_uuid": candidate.uuid,
                        "bundle_id": bundle_id,
                        "status_code": exc.response.status_code,
                    },
                )
                raise AssemblyError(
                    f"Member add failed for uuid={candidate.uuid!r} "
                    f"with HTTP {exc.response.status_code}: {exc}",
                    member_uuid=candidate.uuid,
                ) from exc
            except httpx.RequestError as exc:
                logger.warning(
                    "assembly_error",
                    extra={
                        "step": "member_add",
                        "member_uuid": candidate.uuid,
                        "bundle_id": bundle_id,
                        "error": str(exc),
                    },
                )
                raise AssemblyError(
                    f"Member add request error for uuid={candidate.uuid!r}: {exc}",
                    member_uuid=candidate.uuid,
                ) from exc

            member_add_ms = int((time.monotonic() - t1) * 1000)
            member_uuids.append(candidate.uuid)

            logger.debug(
                "member_add",
                extra={
                    "bundle_id": bundle_id,
                    "member_uuid": candidate.uuid,
                    "member_count": len(member_uuids),
                    "duration_ms": member_add_ms,
                },
            )

    # ── Step 3: write Intent Set sidecar ────────────────────────────────────
    sidecar_dir = intent_set_dir or Path.cwd()
    sidecar_path = sidecar_dir / f"{iset.scaffold_run_id}.intent-set.yaml"

    t2 = time.monotonic()
    dump_intent_set(iset, sidecar_path)
    sidecar_ms = int((time.monotonic() - t2) * 1000)

    logger.debug(
        "sidecar_write",
        extra={
            "bundle_id": bundle_id,
            "sidecar_path": str(sidecar_path),
            "member_count": len(member_uuids),
            "duration_ms": sidecar_ms,
        },
    )

    return AssemblyResult(
        bundle_id=bundle_id,
        bundle_name=bundle_name,
        member_count=len(member_uuids),
        member_uuids=member_uuids,
        intent_set_path=sidecar_path,
    )
