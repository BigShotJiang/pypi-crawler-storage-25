"""Scope filtering for the project-scaffolder feature-variant.

This module is PURE I/O — only filesystem reads, no network or DB access.

When the user runs the feature-scoped variant (``scope_variant == "feature"``),
the curator must exclude artifacts that are already deployed to the target
project's ``.claude/`` directory.  The whole-project variant must NOT apply
this filter (preserves existing ranking behaviour).

Public API::

    CLAUDE_DIR_TYPE_MAP        — mapping of .claude/ subdir name → artifact type
    scan_deployed_artifacts    — scan .claude/ and return (type, name) pairs
    build_scope_filter         — build a predicate that excludes deployed artifacts
    get_filter_for_scope       — convenience: wire scan + build based on scope_variant
"""

from __future__ import annotations

from pathlib import Path
from typing import Callable, Set, Tuple

from skillmeat.core.scaffolder.curator import CandidateArtifact

# ─────────────────────────────────────────────────────────────────────────────
# Directory → artifact-type mapping
# ─────────────────────────────────────────────────────────────────────────────

#: Maps the name of a ``.claude/`` subdirectory to its canonical artifact type.
#:
#: Only directories that contain deployable, curator-visible artifact types are
#: listed.  Infrastructure / meta directories (progress, worknotes, specs, …)
#: are intentionally absent so that they are never treated as deployed artifacts.
CLAUDE_DIR_TYPE_MAP: dict[str, str] = {
    "skills": "skill",
    "agents": "agent",
    "commands": "command",
    "hooks": "hook",
    "mcp": "mcp",
    "rules": "rule",
    "context": "context",
    "workflows": "workflow",
    "templates": "template",
    "composites": "composite",
    "plugins": "composite",  # older alias for composite
    "bundles": "bundle",
    "specs": "spec",
}

# File extensions to strip when deriving the artifact name from a file stem.
_STRIP_EXTENSIONS: frozenset[str] = frozenset(
    {".md", ".yaml", ".yml", ".json", ".toml", ".sh", ".py"}
)

# Files to skip regardless of directory.
_SKIP_FILENAMES: frozenset[str] = frozenset({"CLAUDE.md", "README.md"})


# ─────────────────────────────────────────────────────────────────────────────
# scan_deployed_artifacts
# ─────────────────────────────────────────────────────────────────────────────


def scan_deployed_artifacts(project_root: Path) -> Set[Tuple[str, str]]:
    """Scan ``{project_root}/.claude/`` and return deployed artifact identifiers.

    Each entry in the returned set is a ``(artifact_type, name)`` tuple where
    ``artifact_type`` comes from :data:`CLAUDE_DIR_TYPE_MAP` and ``name`` is
    the bare name of the artifact (directory name for directory-based artifacts,
    file stem for file-based ones) in **lower-case**.

    Detection rules per known sub-directory:

    * ``skills/`` — each *immediate* sub-directory that contains a ``SKILL.md``
      file is treated as one deployed skill; name = directory name.
    * ``agents/``, ``commands/`` — every ``.md`` file found *recursively*
      (because both may be nested); name = file stem.
    * ``hooks/`` — every file in the immediate directory; name = file stem
      (stripping :data:`_STRIP_EXTENSIONS`).
    * All other mapped directories — every file found *non-recursively*; name =
      file stem (stripping :data:`_STRIP_EXTENSIONS`).

    Hidden files (starting with ``.``) and files listed in
    :data:`_SKIP_FILENAMES` are always skipped.

    Args:
        project_root: Root directory of the target project.  The function
            looks for a ``.claude/`` sub-directory here.

    Returns:
        A set of ``(artifact_type, name)`` tuples.  Returns an empty set when
        ``.claude/`` does not exist or is empty.
    """
    claude_dir = project_root / ".claude"
    if not claude_dir.is_dir():
        return set()

    deployed: Set[Tuple[str, str]] = set()

    for subdir_name, artifact_type in CLAUDE_DIR_TYPE_MAP.items():
        subdir = claude_dir / subdir_name
        if not subdir.is_dir():
            continue

        if artifact_type == "skill":
            # Directory-based: each immediate child dir with a SKILL.md inside.
            for entry in subdir.iterdir():
                if not entry.is_dir():
                    continue
                if entry.name.startswith("."):
                    continue
                if (entry / "SKILL.md").exists():
                    deployed.add((artifact_type, entry.name.lower()))

        elif artifact_type in ("agent", "command"):
            # File-based, recursive — agents and commands can be nested.
            for fpath in subdir.rglob("*.md"):
                if fpath.name.startswith("."):
                    continue
                if fpath.name in _SKIP_FILENAMES:
                    continue
                deployed.add((artifact_type, fpath.stem.lower()))

        elif artifact_type == "hook":
            # Flat directory, any file.
            for fpath in subdir.iterdir():
                if not fpath.is_file():
                    continue
                if fpath.name.startswith("."):
                    continue
                if fpath.name in _SKIP_FILENAMES:
                    continue
                name = fpath.stem if fpath.suffix in _STRIP_EXTENSIONS else fpath.name
                deployed.add((artifact_type, name.lower()))

        else:
            # Generic: flat directory scan, strip known extensions.
            for fpath in subdir.iterdir():
                if not fpath.is_file():
                    continue
                if fpath.name.startswith("."):
                    continue
                if fpath.name in _SKIP_FILENAMES:
                    continue
                name = fpath.stem if fpath.suffix in _STRIP_EXTENSIONS else fpath.name
                deployed.add((artifact_type, name.lower()))

    return deployed


# ─────────────────────────────────────────────────────────────────────────────
# build_scope_filter
# ─────────────────────────────────────────────────────────────────────────────


def build_scope_filter(
    deployed: Set[Tuple[str, str]],
) -> Callable[[CandidateArtifact], bool]:
    """Return a predicate that keeps candidates NOT already deployed.

    The returned callable is suitable as the ``filter_fn`` argument of
    :func:`skillmeat.core.scaffolder.curator.rank_candidates`.

    Matching is done case-insensitively on both ``artifact_type`` and ``name``.
    A candidate is **kept** (predicate returns ``True``) when no entry in
    *deployed* matches both its type and name.

    Args:
        deployed: Set of ``(artifact_type, name)`` tuples from
            :func:`scan_deployed_artifacts`.

    Returns:
        A callable ``(CandidateArtifact) -> bool``.
    """

    def _keep(candidate: CandidateArtifact) -> bool:
        key = (candidate.artifact_type.lower(), candidate.name.lower())
        return key not in deployed

    return _keep


# ─────────────────────────────────────────────────────────────────────────────
# get_filter_for_scope
# ─────────────────────────────────────────────────────────────────────────────


def get_filter_for_scope(
    scope_variant: str,
    project_root: Path,
) -> Callable[[CandidateArtifact], bool] | None:
    """Return a scope filter appropriate for *scope_variant*, or ``None``.

    This is the primary convenience entry point for the scaffolder CLI.

    * ``"feature"`` — scans ``.claude/`` and returns a filter that excludes
      already-deployed artifacts.
    * ``"whole-project"`` — returns ``None`` (no filter; preserves current
      curator behaviour).
    * ``"artifact-type-scoped"`` — returns ``None`` (type scoping uses a
      different filter mechanism that is out of scope for this module).
    * Any other value — returns ``None`` and logs nothing (defensive).

    Args:
        scope_variant: One of the values in ``SCOPE_VARIANT_ENUM``
            (``"whole-project"``, ``"feature"``, ``"artifact-type-scoped"``).
        project_root: Root directory of the target project.  Only used when
            *scope_variant* is ``"feature"``.

    Returns:
        A ``(CandidateArtifact) -> bool`` predicate, or ``None``.
    """
    if scope_variant != "feature":
        return None

    deployed = scan_deployed_artifacts(project_root)
    return build_scope_filter(deployed)
