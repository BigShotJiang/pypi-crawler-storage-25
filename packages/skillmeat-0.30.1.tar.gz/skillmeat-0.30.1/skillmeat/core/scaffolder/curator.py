"""Artifact curator: deterministic scoring and ranking for the project-scaffolder.

This module is PURE — no I/O, no LLM calls, fully testable.  HTTP
orchestration lives in :mod:`skillmeat.core.scaffolder.search`.

Public API::

    CandidateArtifact   — scored artifact candidate dataclass
    CuratorError        — raised on unrecoverable curator errors
    build_query         — format an Intent into a search query string
    normalize_semantic  — map a 0-100 confidence to 0.0–1.0
    compute_metadata_score   — tag-match ratio
    compute_marketplace_score — popularity ratio
    compute_final_score — weighted blend of the three sub-scores
    merge_search_results — merge raw API responses into CandidateArtifacts
    dedupe_candidates   — keep highest-scoring entry per uuid
    rank_candidates     — sort, threshold-filter, and cap per intent
    apply_scope_filter  — remove candidates present in an exclusion set
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Set

from skillmeat.core.scaffolder.intent_schema import Intent

# ─────────────────────────────────────────────────────────────────────────────
# Exceptions
# ─────────────────────────────────────────────────────────────────────────────


class CuratorError(Exception):
    """Raised when the curator encounters an unrecoverable error.

    Does NOT cover marketplace timeouts — those are handled as graceful
    fallbacks (empty list) in the search layer.
    """


# ─────────────────────────────────────────────────────────────────────────────
# CandidateArtifact dataclass
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class CandidateArtifact:
    """A single artifact candidate with traceability and scoring metadata.

    Attributes:
        uuid:              Stable artifact UUID (ADR-007 identity).
        name:              Human-readable artifact name.
        artifact_type:     Artifact type string (e.g., "skill", "command").
        source:            Origin — ``"local"`` or ``"marketplace"``.
        intent_id:         The ``Intent.id`` this candidate was found for.
        semantic_score:    Normalized [0, 1] semantic/keyword match score.
        metadata_score:    Normalized [0, 1] tag-match score.
        marketplace_score: Normalized [0, 1] marketplace popularity score.
        final_score:       Weighted blend rounded to 4 decimal places.
        tags:              Tags attached to this artifact.
        description:       Optional artifact description.
    """

    uuid: str
    name: str
    artifact_type: str
    source: str
    intent_id: str
    semantic_score: float
    metadata_score: float
    marketplace_score: float
    final_score: float
    tags: List[str] = field(default_factory=list)
    description: str = ""


# ─────────────────────────────────────────────────────────────────────────────
# Query construction
# ─────────────────────────────────────────────────────────────────────────────


def build_query(intent: Intent) -> str:
    """Format a search query string from an Intent.

    Args:
        intent: A single Intent from an IntentSet.

    Returns:
        Query string: ``"{capability} {stack}"`` when stack is present,
        otherwise just ``"{capability}"``.

    Examples:
        >>> from skillmeat.core.scaffolder.intent_schema import Intent
        >>> i = Intent("int_001", "python-backend", "fastapi", 0.9, "PRD", "high")
        >>> build_query(i)
        'python-backend fastapi'
        >>> i2 = Intent("int_002", "auth", None, 0.8, "PRD", "medium")
        >>> build_query(i2)
        'auth'
    """
    parts = [intent.capability]
    if intent.stack:
        parts.append(intent.stack)
    return " ".join(parts)


# ─────────────────────────────────────────────────────────────────────────────
# Normalization helpers
# ─────────────────────────────────────────────────────────────────────────────


def normalize_semantic(confidence_0_100: float) -> float:
    """Map a 0–100 API confidence value to the [0, 1] range.

    Values outside [0, 100] are clamped before division.

    Args:
        confidence_0_100: Raw confidence from the ``/api/v1/match`` response.

    Returns:
        Normalized score in [0.0, 1.0].
    """
    clamped = max(0.0, min(100.0, confidence_0_100))
    return clamped / 100.0


def compute_metadata_score(candidate_tag_matches: int, max_tag_matches: int) -> float:
    """Compute a normalized tag-match score.

    Args:
        candidate_tag_matches: Number of query tags this candidate matched.
        max_tag_matches:       Maximum tag matches observed across all candidates
                               in the current merge batch (used for normalization).

    Returns:
        ``candidate_tag_matches / max_tag_matches`` clamped to [0, 1],
        or ``0.0`` when *max_tag_matches* is 0.
    """
    if max_tag_matches <= 0:
        return 0.0
    return max(0.0, min(1.0, candidate_tag_matches / max_tag_matches))


def compute_marketplace_score(popularity: int, max_popularity: int) -> float:
    """Compute a normalized marketplace popularity score.

    Args:
        popularity:     Raw popularity count for this candidate.
        max_popularity: Maximum popularity observed across all marketplace
                        results in the current merge batch.

    Returns:
        ``popularity / max_popularity`` clamped to [0, 1],
        or ``0.0`` when *max_popularity* is 0.
    """
    if max_popularity <= 0:
        return 0.0
    return max(0.0, min(1.0, popularity / max_popularity))


# ─────────────────────────────────────────────────────────────────────────────
# Final score formula
# ─────────────────────────────────────────────────────────────────────────────


def compute_final_score(semantic: float, metadata: float, marketplace: float) -> float:
    """Compute the deterministic weighted blend of sub-scores.

    Formula::

        final = 0.5 × semantic + 0.3 × metadata + 0.2 × marketplace

    Result is rounded to 4 decimal places for determinism and to avoid
    floating-point drift between runs.

    Args:
        semantic:    Normalized semantic score [0, 1].
        metadata:    Normalized metadata tag-match score [0, 1].
        marketplace: Normalized marketplace popularity score [0, 1].

    Returns:
        Final weighted score in [0.0, 1.0], rounded to 4 decimal places.

    Examples:
        >>> compute_final_score(1.0, 1.0, 1.0)
        1.0
        >>> compute_final_score(0.8, 0.6, 0.0)
        0.58
    """
    raw = 0.5 * semantic + 0.3 * metadata + 0.2 * marketplace
    return round(raw, 4)


# ─────────────────────────────────────────────────────────────────────────────
# Merge
# ─────────────────────────────────────────────────────────────────────────────


def merge_search_results(
    intent: Intent,
    match_results: List[Dict],
    metadata_results: List[Dict],
    marketplace_results: List[Dict],
) -> List[CandidateArtifact]:
    """Merge the three API result lists into scored CandidateArtifact objects.

    Each input list contains raw API response dicts:

    - *match_results*: ``[{"artifact": {...}, "confidence": 0-100, "breakdown": {...}}]``
      from ``GET /api/v1/match``.
    - *metadata_results*: ``[{"uuid": "...", "name": "...", "artifact_type": "...",
      "tags": [...], "description": "..."}]`` from ``GET /api/v1/artifacts``.
    - *marketplace_results*: ``[{"uuid": "...", "name": "...", "artifact_type": "...",
      "popularity": 0, "tags": [...], "description": "..."}]`` from
      ``GET /api/v1/marketplace/listings``.

    Missing fields always default to neutral values (``0``, ``[]``, ``""``).

    The function:

    1. Indexes match_results by uuid for O(1) lookup.
    2. Computes per-batch normalization factors (max tag matches, max popularity).
    3. Builds one ``CandidateArtifact`` per unique uuid seen across all three legs.
    4. When a uuid appears in multiple legs its scores are combined (max, not sum).

    Args:
        intent:              The Intent these results were fetched for.
        match_results:       Raw match API response list.
        metadata_results:    Raw artifacts API response list.
        marketplace_results: Raw marketplace API response list (may be empty on timeout).

    Returns:
        Unsorted list of ``CandidateArtifact`` objects (one per uuid).
    """
    # ── Index match results ───────────────────────────────────────────────
    # Match results may be nested under "artifact" key.
    match_by_uuid: Dict[str, Dict] = {}
    for item in match_results:
        artifact = item.get("artifact") or item
        uuid = artifact.get("uuid") or artifact.get("id", "")
        if uuid:
            match_by_uuid[uuid] = {
                "artifact": artifact,
                "confidence": float(item.get("confidence", 0)),
            }

    # ── Tag-match counting ────────────────────────────────────────────────
    # Count how many intent-relevant tags each metadata candidate shares with
    # the intent capability (lightweight proxy for tag relevance).
    intent_tags: Set[str] = {intent.capability}
    if intent.stack:
        intent_tags.add(intent.stack)

    def _count_tag_matches(tags: List[str]) -> int:
        return sum(1 for t in tags if t in intent_tags)

    # Count matches for metadata leg
    meta_tag_counts: Dict[str, int] = {}
    for item in metadata_results:
        uuid = item.get("uuid", "")
        if not uuid:
            continue
        tags = item.get("tags") or []
        meta_tag_counts[uuid] = _count_tag_matches(tags)

    max_meta_tags = max(meta_tag_counts.values(), default=0)

    # ── Popularity normalization ──────────────────────────────────────────
    marketplace_by_uuid: Dict[str, Dict] = {}
    for item in marketplace_results:
        uuid = item.get("uuid", "")
        if not uuid:
            continue
        marketplace_by_uuid[uuid] = item

    max_popularity = max(
        (int(v.get("popularity", 0)) for v in marketplace_by_uuid.values()), default=0
    )

    # ── Collect all unique uuids ──────────────────────────────────────────
    all_uuids: Dict[str, None] = {}  # ordered by first occurrence
    for item in match_results:
        artifact = item.get("artifact") or item
        uuid = artifact.get("uuid") or artifact.get("id", "")
        if uuid:
            all_uuids[uuid] = None

    for item in metadata_results:
        uuid = item.get("uuid", "")
        if uuid:
            all_uuids[uuid] = None

    for item in marketplace_results:
        uuid = item.get("uuid", "")
        if uuid:
            all_uuids[uuid] = None

    # ── Build CandidateArtifact for each uuid ─────────────────────────────
    candidates: List[CandidateArtifact] = []

    # Build fast lookup for metadata results by uuid
    meta_by_uuid: Dict[str, Dict] = {
        item.get("uuid", ""): item for item in metadata_results if item.get("uuid", "")
    }

    for uuid in all_uuids:
        # Resolve name, type, tags, description from whichever leg has them
        match_entry = match_by_uuid.get(uuid)
        meta_entry = meta_by_uuid.get(uuid)
        mkt_entry = marketplace_by_uuid.get(uuid)

        best_entry = (
            match_entry["artifact"] if match_entry else (meta_entry or mkt_entry or {})
        )
        name = best_entry.get("name", "")
        artifact_type = best_entry.get("artifact_type") or best_entry.get("type", "")
        tags = best_entry.get("tags") or []
        description = best_entry.get("description", "")

        # Source classification: marketplace beats local
        source = "marketplace" if mkt_entry else "local"

        # ── Semantic score ────────────────────────────────────────────────
        raw_confidence = float(match_entry["confidence"]) if match_entry else 0.0
        semantic = normalize_semantic(raw_confidence)

        # ── Metadata score ────────────────────────────────────────────────
        tag_hits = meta_tag_counts.get(uuid, 0)
        metadata = compute_metadata_score(tag_hits, max_meta_tags)

        # ── Marketplace score ─────────────────────────────────────────────
        raw_popularity = int(mkt_entry.get("popularity", 0)) if mkt_entry else 0
        marketplace = compute_marketplace_score(raw_popularity, max_popularity)

        final = compute_final_score(semantic, metadata, marketplace)

        candidates.append(
            CandidateArtifact(
                uuid=uuid,
                name=name,
                artifact_type=artifact_type,
                source=source,
                intent_id=intent.id,
                semantic_score=semantic,
                metadata_score=metadata,
                marketplace_score=marketplace,
                final_score=final,
                tags=tags,
                description=description,
            )
        )

    return candidates


# ─────────────────────────────────────────────────────────────────────────────
# Deduplication
# ─────────────────────────────────────────────────────────────────────────────


def dedupe_candidates(
    candidates: List[CandidateArtifact],
) -> List[CandidateArtifact]:
    """Deduplicate candidates by uuid, keeping the highest-scoring variant.

    When the same uuid appears multiple times (e.g., from different intents),
    the entry with the highest ``final_score`` is retained.  The output
    preserves the order of first occurrence of each uuid.

    Args:
        candidates: Flat list of ``CandidateArtifact`` objects (may contain
                    duplicates from multi-intent merges).

    Returns:
        Deduplicated list maintaining first-seen uuid order.
    """
    seen: Dict[str, CandidateArtifact] = {}
    order: List[str] = []

    for cand in candidates:
        if cand.uuid not in seen:
            seen[cand.uuid] = cand
            order.append(cand.uuid)
        elif cand.final_score > seen[cand.uuid].final_score:
            seen[cand.uuid] = cand

    return [seen[uuid] for uuid in order]


# ─────────────────────────────────────────────────────────────────────────────
# Ranking
# ─────────────────────────────────────────────────────────────────────────────


def rank_candidates(
    candidates: List[CandidateArtifact],
    score_threshold: float = 0.3,
    max_per_intent: int = 5,
    filter_fn: Optional[Callable[[CandidateArtifact], bool]] = None,
) -> List[CandidateArtifact]:
    """Sort, filter, and cap artifact candidates for the preview step.

    Processing order:

    1. Apply *filter_fn* (if provided) — for feature-scope exclusions or
       custom filtering logic added by SCAF-008.
    2. Remove candidates with ``final_score < score_threshold``.
    3. Sort by ``(-final_score, artifact_type, name)`` for fully deterministic
       tie-breaking (stable sort on identical inputs).
    4. Cap at *max_per_intent* candidates per ``intent_id``.

    Args:
        candidates:      List of ``CandidateArtifact`` objects (may contain
                         candidates for multiple intents).
        score_threshold: Minimum ``final_score`` to pass through (default 0.3).
        max_per_intent:  Maximum number of candidates retained per intent
                         (default 5).
        filter_fn:       Optional predicate; return ``True`` to *keep* a
                         candidate.  Hook for SCAF-008 feature-scope filtering.
                         When ``None``, no additional filtering is applied.

    Returns:
        Sorted and capped list of ``CandidateArtifact`` objects.
    """
    # Step 1: apply external filter hook
    if filter_fn is not None:
        candidates = [c for c in candidates if filter_fn(c)]

    # Step 2: threshold filter
    candidates = [c for c in candidates if c.final_score >= score_threshold]

    # Step 3: deterministic sort — highest score first; ties broken alphabetically
    candidates = sorted(
        candidates, key=lambda c: (-c.final_score, c.artifact_type, c.name)
    )

    # Step 4: cap per intent
    per_intent_count: Dict[str, int] = {}
    result: List[CandidateArtifact] = []
    for cand in candidates:
        count = per_intent_count.get(cand.intent_id, 0)
        if count < max_per_intent:
            result.append(cand)
            per_intent_count[cand.intent_id] = count + 1

    return result


# ─────────────────────────────────────────────────────────────────────────────
# Feature-scope filter helper (integration point for SCAF-008)
# ─────────────────────────────────────────────────────────────────────────────


def apply_scope_filter(
    candidates: List[CandidateArtifact],
    deployed_uuids: Set[str],
) -> List[CandidateArtifact]:
    """Remove candidates whose uuid is already deployed in the project.

    This is the integration point for SCAF-008 (feature-scope variant).
    Pass the result of this function to :func:`rank_candidates` or use
    the ``filter_fn`` hook directly.

    Args:
        candidates:     Unfiltered candidate list.
        deployed_uuids: Set of UUIDs already present in the project's
                        ``.claude/`` artifact inventory.

    Returns:
        Candidates with deployed artifacts removed.
    """
    return [c for c in candidates if c.uuid not in deployed_uuids]
