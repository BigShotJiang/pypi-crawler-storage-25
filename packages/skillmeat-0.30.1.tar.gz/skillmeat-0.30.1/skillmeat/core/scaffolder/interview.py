"""Interview trigger heuristic and question generation for project-scaffolder.

This module is pure logic — no LLM calls, no I/O, fully unit-testable.
It operates entirely on IntentSet values already computed by the analyzer.

Interview trigger conditions (either must be true):
    1. aggregate_confidence < 0.65
    2. count(intents where confidence < 0.5 AND priority == "high") >= 2
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from skillmeat.core.scaffolder.intent_schema import Intent, IntentSet

# Confidence threshold below which the interview is triggered
AGGREGATE_CONFIDENCE_THRESHOLD: float = 0.65

# Minimum number of low-confidence high-priority intents to trigger interview
HIGH_PRIORITY_LOW_CONFIDENCE_THRESHOLD: int = 2

# Low-confidence cutoff for individual high-priority intents
HIGH_PRIORITY_CONFIDENCE_CUTOFF: float = 0.5


def should_trigger_interview(iset: "IntentSet") -> bool:
    """Determine whether the interview flow should be triggered.

    Trigger conditions (OR logic — either condition triggers the interview):
        1. aggregate_confidence < AGGREGATE_CONFIDENCE_THRESHOLD (0.65)
        2. count of high-priority intents with confidence < HIGH_PRIORITY_CONFIDENCE_CUTOFF (0.5)
           is >= HIGH_PRIORITY_LOW_CONFIDENCE_THRESHOLD (2)

    Args:
        iset: The IntentSet produced by project-analyzer.

    Returns:
        True if the interview should be triggered, False otherwise.
    """
    # Condition 1: low aggregate confidence
    if iset.aggregate_confidence < AGGREGATE_CONFIDENCE_THRESHOLD:
        return True

    # Condition 2: multiple high-priority intents are low-confidence
    low_confidence_high_priority = sum(
        1
        for intent in iset.intents
        if intent.priority == "high"
        and intent.confidence < HIGH_PRIORITY_CONFIDENCE_CUTOFF
    )
    if low_confidence_high_priority >= HIGH_PRIORITY_LOW_CONFIDENCE_THRESHOLD:
        return True

    return False


def _question_for_intent(intent: "Intent") -> str:
    """Generate a targeted clarifying question for a low-confidence intent.

    Questions are concrete and prefer binary/multiple-choice phrasing where possible.
    The question targets the specific gap: either the capability is uncertain,
    or the stack within a known capability is uncertain.

    Args:
        intent: The low-confidence Intent requiring clarification.

    Returns:
        A single clarifying question string.
    """
    capability = intent.capability
    stack = intent.stack

    # Stack-specific questions (capability known, technology uncertain)
    if stack is None or intent.confidence < 0.4:
        # Capability is uncertain — ask whether it is needed at all
        _capability_questions = {
            "python-backend": (
                "Will this project include a Python backend? If so, which framework: "
                "FastAPI, Django, Flask, or another?"
            ),
            "typescript-backend": (
                "Will this project include a TypeScript backend? If so, which runtime: "
                "Node.js/Express, NestJS, Bun, or another?"
            ),
            "react-frontend": (
                "Will this project include a React frontend? If so, which setup: "
                "Next.js, Vite+React, Create React App, or another?"
            ),
            "angular-frontend": (
                "Will this project use Angular as the frontend framework?"
            ),
            "vue-frontend": (
                "Will this project use Vue.js as the frontend framework? If so, Nuxt or plain Vue?"
            ),
            "relational-database": (
                "Which relational database will this project use: "
                "PostgreSQL, MySQL, SQLite, or another?"
            ),
            "document-store": (
                "Will this project use a document/NoSQL store? If so, which one: "
                "MongoDB, DynamoDB, Firestore, or another?"
            ),
            "vector-search": (
                "Will this project use vector/semantic search? If so, which provider: "
                "Pinecone, Weaviate, pgvector, Qdrant, or another?"
            ),
            "ci-cd": (
                "Which CI/CD platform will this project use: "
                "GitHub Actions, GitLab CI, CircleCI, Jenkins, or another?"
            ),
            "auth": (
                "What authentication approach will this project use: "
                "OAuth2/OIDC (e.g., Clerk, Auth0), JWT-only, session-based, or another?"
            ),
            "caching": (
                "Will this project use a caching layer? If so, which one: "
                "Redis, Memcached, in-process cache, or another?"
            ),
            "logging": (
                "What observability approach will this project use: "
                "OpenTelemetry, Datadog, Prometheus+Grafana, or basic structured logging?"
            ),
            "testing": (
                "What testing frameworks will this project use: "
                "pytest (Python), Jest (JS), both, or another combination?"
            ),
            "containerization": (
                "Will this project be containerized? If so, which tooling: "
                "Docker + Compose, Podman, Kubernetes, or another?"
            ),
            "graphql": (
                "Will this project expose a GraphQL API? If so, which library: "
                "Apollo Server, Strawberry (Python), Hasura, or another?"
            ),
            "background-jobs": (
                "Will this project use async background workers? If so, which framework: "
                "Celery, ARQ, RQ, BullMQ (Node), or another?"
            ),
            "message-queue": (
                "What message queue will this project use: "
                "RabbitMQ, Kafka, AWS SQS, Redis Streams, or another?"
            ),
            "api-gateway": (
                "Will this project use an API gateway or reverse proxy: "
                "Nginx, Traefik, Kong, AWS API Gateway, or another?"
            ),
            "monitoring": (
                "How will this project handle monitoring and alerting: "
                "Prometheus+Grafana, Datadog, New Relic, Sentry, or another?"
            ),
            "secret-management": (
                "How will secrets be managed: HashiCorp Vault, AWS Secrets Manager, "
                "GitHub Actions secrets, dotenv, or another approach?"
            ),
            "infrastructure-as-code": (
                "What infrastructure-as-code tooling will this project use: "
                "Terraform, Pulumi, CDK, Helm, or another?"
            ),
        }
        return _capability_questions.get(
            capability,
            f"Can you clarify the '{capability}' requirement? "
            "What specific technology or approach will you use?",
        )

    # Stack is known but confidence is moderate — ask for confirmation
    return (
        f"I detected you may be using {stack} for {capability.replace('-', ' ')}, "
        f"but I'm not fully confident. Can you confirm: will this project use {stack}?"
    )


def generate_questions(iset: "IntentSet", max_questions: int = 3) -> List[str]:
    """Generate up to max_questions targeted clarifying questions.

    Questions focus on the lowest-confidence high-priority intents first,
    then fall back to lowest-confidence medium-priority intents if max_questions
    is not yet reached.

    The total number of questions returned never exceeds max_questions.

    Args:
        iset: The IntentSet with intents to generate questions for.
        max_questions: Maximum number of questions to return. Default: 3.

    Returns:
        List of question strings (length <= max_questions).
    """
    if max_questions <= 0:
        return []

    questions: List[str] = []

    # Sort intents: high-priority first, then medium; within priority sort by confidence asc
    def sort_key(intent: "Intent") -> tuple:
        priority_order = {"high": 0, "medium": 1, "low": 2}
        return (priority_order.get(intent.priority, 3), intent.confidence)

    sorted_intents = sorted(iset.intents, key=sort_key)

    for intent in sorted_intents:
        if len(questions) >= max_questions:
            break
        # Only ask about intents that are genuinely uncertain
        if intent.confidence < HIGH_PRIORITY_CONFIDENCE_CUTOFF or (
            intent.priority == "medium" and intent.confidence < 0.6
        ):
            questions.append(_question_for_intent(intent))

    return questions
