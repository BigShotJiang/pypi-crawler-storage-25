"""Preview and confirmation flow for the project scaffolder.

After the curator produces ranked candidates, this module renders a rich
terminal preview and prompts the user to confirm, remove individual
artifacts, or abort the scaffold entirely.

Public API::

    PreviewDecision          — dataclass capturing the user's choice
    render_preview           — render a rich Table of candidates to stdout
    prompt_for_confirmation  — interactive user prompt (confirm / remove / abort)
    apply_decision           — filter the candidate list based on the decision
    run_preview_flow         — orchestrate render → prompt → apply in one call

This module is PURE UI — it never calls ``assemble_bundle``.  The caller is
responsible for wiring the returned candidates to the assembly step.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

from rich.console import Console
from rich.table import Table
from rich.text import Text

from skillmeat.core.scaffolder.curator import CandidateArtifact
from skillmeat.core.scaffolder.intent_schema import IntentSet

# ─────────────────────────────────────────────────────────────────────────────
# PreviewDecision dataclass
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class PreviewDecision:
    """The outcome of the user confirmation prompt.

    Attributes:
        confirmed:      True when the user accepted (even with removals).
        removed_uuids:  Set of candidate UUIDs the user elected to remove.
        aborted:        True when the user chose to abort the scaffold run.
    """

    confirmed: bool
    removed_uuids: set = field(default_factory=set)
    aborted: bool = False


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────


def _score_bar(score: float, width: int = 8) -> str:
    """Return a compact ASCII bar representing *score* in [0, 1]."""
    filled = round(score * width)
    return "[" + "#" * filled + "." * (width - filled) + "]"


def _group_by_intent(
    candidates: List[CandidateArtifact],
) -> Dict[str, List[CandidateArtifact]]:
    """Preserve insertion order while grouping by intent_id."""
    groups: Dict[str, List[CandidateArtifact]] = {}
    for cand in candidates:
        groups.setdefault(cand.intent_id, []).append(cand)
    return groups


# ─────────────────────────────────────────────────────────────────────────────
# render_preview
# ─────────────────────────────────────────────────────────────────────────────


def render_preview(
    iset: IntentSet,
    candidates: List[CandidateArtifact],
    *,
    console: Optional[Console] = None,
) -> None:
    """Render a rich table preview of the ranked scaffold candidates.

    Groups candidates by ``intent_id`` and prints a header with run metadata
    and a footer with a summary line.

    Args:
        iset:       The ``IntentSet`` produced by the analyzer — supplies run
                    metadata (run ID, scope variant, aggregate confidence).
        candidates: Ordered list of ``CandidateArtifact`` objects from the
                    curator.  Must not be empty for a meaningful preview.
        console:    Optional ``rich.console.Console`` instance.  When ``None``
                    a new ``Console()`` is created that writes to stdout.
    """
    if console is None:
        console = Console()

    unique_intents = len({c.intent_id for c in candidates})

    # ── Header ────────────────────────────────────────────────────────────────
    console.print()
    console.print(
        f"[bold cyan]Scaffold Preview[/bold cyan]  "
        f"[dim]run=[/dim][green]{iset.scaffold_run_id}[/green]  "
        f"[dim]scope=[/dim][yellow]{iset.scope_variant}[/yellow]  "
        f"[dim]confidence=[/dim][magenta]{iset.aggregate_confidence:.0%}[/magenta]"
    )
    console.print()

    # ── Table — one section per intent ────────────────────────────────────────
    groups = _group_by_intent(candidates)
    row_index = 1  # global 1-based row counter across all groups

    for intent_id, group_candidates in groups.items():
        # Find the matching Intent object for the section header
        intent_obj = next((i for i in iset.intents if i.id == intent_id), None)
        if intent_obj is not None:
            header_label = (
                f"[bold]{intent_id}[/bold]  "
                f"[cyan]{intent_obj.capability}[/cyan]"
                + (f" / [dim]{intent_obj.stack}[/dim]" if intent_obj.stack else "")
                + f"  [dim](priority: {intent_obj.priority})[/dim]"
            )
        else:
            header_label = f"[bold]{intent_id}[/bold]"

        console.print(f"  {header_label}")

        table = Table(
            show_header=True,
            header_style="bold dim",
            box=None,
            padding=(0, 1),
            expand=False,
        )
        table.add_column("#", style="dim", width=4, no_wrap=True)
        table.add_column("Type", style="cyan", min_width=10, no_wrap=True)
        table.add_column("Name", style="bold white", min_width=20)
        table.add_column("Source", style="dim", min_width=12, no_wrap=True)
        table.add_column("Score", min_width=12, no_wrap=True)

        for cand in group_candidates:
            score_pct = f"{cand.final_score:.0%}"
            bar = _score_bar(cand.final_score)
            if cand.final_score >= 0.7:
                score_text = Text(f"{score_pct} {bar}", style="green")
            elif cand.final_score >= 0.4:
                score_text = Text(f"{score_pct} {bar}", style="yellow")
            else:
                score_text = Text(f"{score_pct} {bar}", style="red")

            table.add_row(
                str(row_index),
                cand.artifact_type,
                cand.name,
                cand.source,
                score_text,
            )
            row_index += 1

        console.print(table)
        console.print()

    # ── Footer ────────────────────────────────────────────────────────────────
    console.print(
        f"[dim]{len(candidates)} artifact(s) across "
        f"{unique_intents} intent(s)[/dim] — "
        "[bold]confirm[/bold], [bold]remove[/bold], or [bold]abort[/bold]?"
    )


# ─────────────────────────────────────────────────────────────────────────────
# prompt_for_confirmation
# ─────────────────────────────────────────────────────────────────────────────

_PROMPT_TEXT = "\nConfirm scaffold? [Y]es / [n]o / [r]emove <indices>: "
_MAX_ATTEMPTS = 3


def prompt_for_confirmation(
    candidates: List[CandidateArtifact],
    *,
    auto_confirm: bool = False,
    input_fn: Callable[[str], str] = input,
) -> PreviewDecision:
    """Prompt the user to confirm, remove individual candidates, or abort.

    Args:
        candidates:    The ordered list of candidates shown in the preview.
                       Row numbers are 1-based indices into this list.
        auto_confirm:  When ``True`` skip all prompting and return a confirmed
                       decision immediately.  Use for ``--yes`` / CI flags.
        input_fn:      Callable used to read user input.  Defaults to the
                       built-in ``input``.  Override in tests to inject
                       synthetic responses.

    Returns:
        A :class:`PreviewDecision` describing the user's choice.

    Accepted responses:
        - ``y``, ``yes``, or empty string → confirm all
        - ``n``, ``no``, ``abort`` → abort
        - ``remove 1,3,5`` or ``r 1,3,5`` → remove those rows and confirm

    After *_MAX_ATTEMPTS* invalid inputs the call defaults to abort.
    """
    if auto_confirm:
        return PreviewDecision(confirmed=True, removed_uuids=set(), aborted=False)

    for attempt in range(_MAX_ATTEMPTS):
        try:
            raw = input_fn(_PROMPT_TEXT).strip().lower()
        except EOFError:
            # Non-interactive context — treat as abort
            return PreviewDecision(confirmed=False, removed_uuids=set(), aborted=True)

        # ── Yes / confirm ─────────────────────────────────────────────────────
        if raw in ("", "y", "yes"):
            return PreviewDecision(confirmed=True, removed_uuids=set(), aborted=False)

        # ── No / abort ────────────────────────────────────────────────────────
        if raw in ("n", "no", "abort"):
            return PreviewDecision(confirmed=False, removed_uuids=set(), aborted=True)

        # ── Remove <indices> ─────────────────────────────────────────────────
        if raw.startswith(("remove ", "r ")):
            prefix = "remove " if raw.startswith("remove ") else "r "
            indices_str = raw[len(prefix) :].strip()
            removed_uuids: set = set()
            parse_error = False

            for part in indices_str.split(","):
                part = part.strip()
                if not part.isdigit():
                    parse_error = True
                    break
                idx = int(part)
                if idx < 1 or idx > len(candidates):
                    parse_error = True
                    break
                removed_uuids.add(candidates[idx - 1].uuid)

            if parse_error:
                remaining = _MAX_ATTEMPTS - attempt - 1
                print(
                    f"  Invalid indices — must be comma-separated numbers between "
                    f"1 and {len(candidates)}.  {remaining} attempt(s) left."
                )
                continue

            return PreviewDecision(
                confirmed=True, removed_uuids=removed_uuids, aborted=False
            )

        # ── Unknown input ─────────────────────────────────────────────────────
        remaining = _MAX_ATTEMPTS - attempt - 1
        print(
            f"  Unrecognised response '{raw}'.  "
            f"Enter y, n, or 'remove <indices>'.  {remaining} attempt(s) left."
        )

    # Exhausted all attempts → abort
    return PreviewDecision(confirmed=False, removed_uuids=set(), aborted=True)


# ─────────────────────────────────────────────────────────────────────────────
# apply_decision
# ─────────────────────────────────────────────────────────────────────────────


def apply_decision(
    candidates: List[CandidateArtifact],
    decision: PreviewDecision,
) -> List[CandidateArtifact]:
    """Filter the candidate list according to *decision*.

    Args:
        candidates: Full ranked candidate list as shown in the preview.
        decision:   The :class:`PreviewDecision` returned by
                    :func:`prompt_for_confirmation`.

    Returns:
        - Empty list if ``decision.aborted`` is True.
        - Unchanged list if ``decision.confirmed`` and no removals.
        - Filtered list (removals excluded) otherwise.
    """
    if decision.aborted:
        return []
    if not decision.removed_uuids:
        return list(candidates)
    return [c for c in candidates if c.uuid not in decision.removed_uuids]


# ─────────────────────────────────────────────────────────────────────────────
# run_preview_flow  (main entry point)
# ─────────────────────────────────────────────────────────────────────────────


def run_preview_flow(
    iset: IntentSet,
    candidates: List[CandidateArtifact],
    *,
    dry_run: bool = False,
    auto_confirm: bool = False,
    console: Optional[Console] = None,
    input_fn: Callable[[str], str] = input,
) -> Tuple[List[CandidateArtifact], PreviewDecision]:
    """Orchestrate the full preview → confirm → filter flow.

    This is the primary entry point for callers that want the complete
    preview experience in one call.  It is purely UI — it does **not**
    call ``assemble_bundle``; that is the caller's responsibility.

    Processing order:

    1. :func:`render_preview` — display the rich table.
    2. :func:`prompt_for_confirmation` — collect the user's decision.
    3. :func:`apply_decision` — filter candidates accordingly.
    4. If *dry_run* and the decision was confirmed: print a dry-run notice
       and return the filtered list without writing anything.

    Args:
        iset:         The ``IntentSet`` from the analyzer.
        candidates:   Ranked ``CandidateArtifact`` list from the curator.
        dry_run:      When ``True`` suppress all file writes (the assembly
                      step must honour this flag; this function only prints
                      the dry-run notice).
        auto_confirm: Skip interactive prompting and confirm immediately.
        console:      Optional ``rich.console.Console``.  Created if ``None``.
        input_fn:     Input function override for testing.

    Returns:
        ``(final_candidates, decision)`` where *final_candidates* is the
        post-decision filtered list (empty on abort).
    """
    if console is None:
        console = Console()

    render_preview(iset, candidates, console=console)
    decision = prompt_for_confirmation(
        candidates, auto_confirm=auto_confirm, input_fn=input_fn
    )
    final_candidates = apply_decision(candidates, decision)

    if dry_run and decision.confirmed:
        console.print("[dim]DRY-RUN: no bundle will be created[/dim]")

    return final_candidates, decision
