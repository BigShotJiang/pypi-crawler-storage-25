"""CCDash webhook processing service for DVCS-6.3.

Implements workflow degradation monitoring and circuit breaker functionality
for automated rollback when CCDash reports workflow effectiveness below
configured thresholds.

Circuit Breaker State Machine:
- CLOSED: Normal operation, accepting deployments
- OPEN: Blocking updates due to degradation, triggering rollbacks
- HALF_OPEN: Testing recovery after timeout period

The service integrates with BundleCommitService for rollback execution.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, Optional

from sqlalchemy.orm import Session

from skillmeat.core.services.bundle_commit_service import BundleCommitService

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Circuit Breaker State Machine
# ---------------------------------------------------------------------------


class CircuitBreakerState(str, Enum):
    """Circuit breaker state values."""

    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Blocking updates
    HALF_OPEN = "half_open"  # Testing recovery


# ---------------------------------------------------------------------------
# Domain Models
# ---------------------------------------------------------------------------


class RollbackTrigger:
    """Represents a rollback action triggered by circuit breaker."""

    def __init__(
        self,
        severity: str,
        action: str,
        reason: str,
        workflow_id: str,
        deployment_id: Optional[str] = None,
    ):
        self.severity = severity
        self.action = action
        self.reason = reason
        self.workflow_id = workflow_id
        self.deployment_id = deployment_id
        self.triggered_at = datetime.now(timezone.utc)


class CCDashWebhookPayload:
    """Structured representation of CCDash webhook payload."""

    def __init__(self, payload_dict: Dict[str, Any]):
        self.event_type = payload_dict.get("event_type", "")
        self.timestamp = payload_dict.get("timestamp", "")
        self.workflow_id = payload_dict.get("workflow_id", "")

        metrics = payload_dict.get("metrics", {})
        self.effectiveness_score = metrics.get("effectiveness_score", 0.0)
        self.error_rate = metrics.get("error_rate", 0.0)
        self.p95_latency_ms = metrics.get("p95_latency_ms", 0.0)
        self.sample_size = metrics.get("sample_size", 0)
        self.time_window_seconds = metrics.get("time_window_seconds", 0)

        thresholds = payload_dict.get("thresholds", {})
        self.min_effectiveness = thresholds.get("min_effectiveness", 0.7)
        self.max_error_rate = thresholds.get("max_error_rate", 0.2)
        self.max_p95_latency_ms = thresholds.get("max_p95_latency_ms", 5000.0)

        metadata = payload_dict.get("metadata", {})
        self.deployment_id = metadata.get("deployment_id")
        self.artifact_versions = metadata.get("artifact_versions", {})
        self.environment = metadata.get("environment", "unknown")
        self.source = metadata.get("source", "ccdash")


class WorkflowCircuitBreaker:
    """Circuit breaker for a specific workflow."""

    def __init__(self, workflow_id: str):
        self.workflow_id = workflow_id
        self.state = CircuitBreakerState.CLOSED
        self.failure_count = 0
        self.last_failure_time: Optional[datetime] = None
        self.recovery_timeout = timedelta(minutes=30)

    def record_degradation(
        self, payload: CCDashWebhookPayload, rollback_threshold: float = 0.75
    ) -> Optional[RollbackTrigger]:
        """Process degradation event and potentially trigger rollback.

        Args:
            payload: CCDash webhook payload with metrics
            rollback_threshold: Effectiveness threshold below which to trigger rollback

        Returns:
            RollbackTrigger if rollback should be initiated, None otherwise
        """
        effectiveness = payload.effectiveness_score
        error_rate = payload.error_rate

        # Critical threshold - immediate rollback
        if effectiveness < 0.5 or error_rate > 0.5:
            self.state = CircuitBreakerState.OPEN
            self.last_failure_time = datetime.now(timezone.utc)

            logger.critical(
                "Circuit breaker OPEN for workflow %s: critical degradation "
                "(effectiveness=%.2f%%, error_rate=%.2f%%)",
                self.workflow_id,
                effectiveness * 100,
                error_rate * 100,
            )

            return RollbackTrigger(
                severity="critical",
                action="immediate_rollback",
                reason=f"Critical degradation: effectiveness={effectiveness:.1%}, errors={error_rate:.1%}",
                workflow_id=self.workflow_id,
                deployment_id=payload.deployment_id,
            )

        # Configured threshold - rollback if below limit
        if effectiveness < rollback_threshold:
            self.failure_count += 1
            self.last_failure_time = datetime.now(timezone.utc)

            # Multiple failures - trigger rollback
            if self.failure_count >= 3:
                self.state = CircuitBreakerState.OPEN

                logger.warning(
                    "Circuit breaker OPEN for workflow %s: repeated degradations "
                    "(effectiveness=%.2f%%, failures=%d)",
                    self.workflow_id,
                    effectiveness * 100,
                    self.failure_count,
                )

                return RollbackTrigger(
                    severity="high",
                    action="rollback_after_confirmation",
                    reason=f"Repeated degradations: {self.failure_count} failures, effectiveness {effectiveness:.1%}",
                    workflow_id=self.workflow_id,
                    deployment_id=payload.deployment_id,
                )
            else:
                logger.warning(
                    "Workflow %s degradation detected (effectiveness=%.2f%%, failure %d/3)",
                    self.workflow_id,
                    effectiveness * 100,
                    self.failure_count,
                )

        # Warning threshold - increment counter but don't rollback yet
        elif effectiveness < 0.85 or error_rate > 0.1:
            self.failure_count += 1
            self.last_failure_time = datetime.now(timezone.utc)

            logger.info(
                "Workflow %s warning threshold breached (effectiveness=%.2f%%, error_rate=%.2f%%)",
                self.workflow_id,
                effectiveness * 100,
                error_rate * 100,
            )

        return None

    def record_recovery(self) -> None:
        """Record workflow recovery event."""
        if self.state == CircuitBreakerState.OPEN:
            self.state = CircuitBreakerState.HALF_OPEN
            logger.info("Circuit breaker HALF_OPEN for workflow %s", self.workflow_id)
        elif self.state == CircuitBreakerState.HALF_OPEN:
            self.state = CircuitBreakerState.CLOSED
            self.failure_count = 0
            self.last_failure_time = None
            logger.info(
                "Circuit breaker CLOSED for workflow %s - recovery complete",
                self.workflow_id,
            )

    def should_allow_updates(self) -> bool:
        """Check if updates should be allowed based on circuit breaker state."""
        if self.state == CircuitBreakerState.CLOSED:
            return True

        # Check if recovery timeout has elapsed
        if (
            self.state == CircuitBreakerState.OPEN
            and self.last_failure_time
            and datetime.now(timezone.utc) - self.last_failure_time
            > self.recovery_timeout
        ):
            self.state = CircuitBreakerState.HALF_OPEN
            logger.info(
                "Circuit breaker HALF_OPEN for workflow %s after timeout",
                self.workflow_id,
            )
            return True

        return self.state != CircuitBreakerState.OPEN


# ---------------------------------------------------------------------------
# Service Class
# ---------------------------------------------------------------------------


class CCDashService:
    """Service for processing CCDash webhooks and managing circuit breaker state."""

    def __init__(self, session: Session):
        self.session = session
        self._circuit_breakers: Dict[str, WorkflowCircuitBreaker] = {}

    def get_or_create_circuit_breaker(self, workflow_id: str) -> WorkflowCircuitBreaker:
        """Get or create a circuit breaker for the specified workflow.

        Args:
            workflow_id: Unique identifier for the workflow

        Returns:
            WorkflowCircuitBreaker instance for the workflow
        """
        if workflow_id not in self._circuit_breakers:
            self._circuit_breakers[workflow_id] = WorkflowCircuitBreaker(workflow_id)

        return self._circuit_breakers[workflow_id]

    def process_webhook(
        self,
        payload: CCDashWebhookPayload,
        rollback_threshold: float = 0.75,
    ) -> Dict[str, Any]:
        """Process CCDash webhook payload and potentially trigger rollback.

        Args:
            payload: CCDash webhook payload
            rollback_threshold: Effectiveness threshold for rollback trigger

        Returns:
            Dict with processing results including rollback status
        """
        breaker = self.get_or_create_circuit_breaker(payload.workflow_id)
        rollback_trigger = None

        if payload.event_type == "workflow_degradation":
            rollback_trigger = breaker.record_degradation(payload, rollback_threshold)
        elif payload.event_type == "workflow_recovery":
            breaker.record_recovery()

        result = {
            "status": "processed",
            "workflow_id": payload.workflow_id,
            "circuit_state": breaker.state.value,
            "rollback_triggered": rollback_trigger is not None,
            "failure_count": breaker.failure_count,
        }

        if rollback_trigger:
            result.update(
                {
                    "rollback_severity": rollback_trigger.severity,
                    "rollback_reason": rollback_trigger.reason,
                    "rollback_action": rollback_trigger.action,
                }
            )

        logger.info(
            "CCDash webhook processed for workflow %s: %s",
            payload.workflow_id,
            result,
        )

        return result

    def execute_rollback(
        self,
        rollback_trigger: RollbackTrigger,
        composite_artifact_id: str,
        created_by: Optional[str] = None,
    ) -> Optional[str]:
        """Execute rollback using BundleCommitService.

        Args:
            rollback_trigger: Rollback trigger with context
            composite_artifact_id: ID of composite artifact to rollback
            created_by: User ID executing the rollback

        Returns:
            New rollback commit ID if successful, None if no rollback needed
        """
        bundle_svc = BundleCommitService(self.session)

        try:
            # Find the most recent successful commit before current
            # This is a simplified implementation - in practice, we'd need
            # more sophisticated logic to find the right target commit

            rollback_message = f"CCDash automatic rollback: {rollback_trigger.reason}"

            # For now, we'll need the target commit ID to be provided
            # In a full implementation, we'd query for the previous stable commit

            logger.warning(
                "Rollback execution not fully implemented - would rollback %s for reason: %s",
                composite_artifact_id,
                rollback_trigger.reason,
            )

            return None  # Placeholder

        except Exception as exc:
            logger.exception(
                "Failed to execute rollback for workflow %s: %s",
                rollback_trigger.workflow_id,
                exc,
            )
            return None

    @staticmethod
    def verify_webhook_signature(
        body: bytes,
        signature: str,
        secret: str,
    ) -> bool:
        """Verify HMAC-SHA256 signature for webhook payload.

        Args:
            body: Raw request body as bytes
            signature: X-CCDash-Signature header value
            secret: Shared HMAC secret

        Returns:
            True if signature is valid
        """
        import hmac

        if not signature.startswith("sha256="):
            return False

        expected_digest = hmac.new(
            secret.encode("utf-8"),
            body,
            hashlib.sha256,
        ).hexdigest()
        expected_signature = f"sha256={expected_digest}"

        # Constant-time comparison to prevent timing attacks
        return hmac.compare_digest(signature, expected_signature)

    @staticmethod
    def generate_idempotency_key(body: bytes) -> str:
        """Generate idempotency key from webhook body.

        Args:
            body: Raw webhook body as bytes

        Returns:
            SHA-256 hash of the body as hex string
        """
        return hashlib.sha256(body).hexdigest()
