"""Compliance Gate Service for DVCS Phase 6 Hard Update Option B.

Provides fast compliance checking to determine if a project has pending
artifact updates that would trigger enforcement actions. Used as a
pre-execution gate to prevent operations when enforced updates are pending.
"""

import json
import logging
import hashlib
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Dict, Any

from sqlalchemy.orm import Session

from skillmeat.core.upstream_cascade import UpstreamCascadeService
from skillmeat.storage.deployment import DeploymentTracker
from skillmeat.cache.models import Artifact

logger = logging.getLogger(__name__)

__all__ = [
    "ComplianceStatus",
    "ComplianceGateService",
]


@dataclass
class ComplianceStatus:
    """Compliance status for a project.

    Attributes:
        project_id: Base64-encoded project path
        is_compliant: True if project is compliant (safe to proceed)
        pending_updates_count: Number of artifacts with pending updates
        enforcement_required: True if hard enforcement is required
        checked_at: When the check was performed
        cache_hit: Whether this result came from cache
        pending_artifacts: List of artifact IDs with pending updates
    """

    project_id: str
    is_compliant: bool
    pending_updates_count: int = 0
    enforcement_required: bool = False
    checked_at: Optional[datetime] = None
    cache_hit: bool = False
    pending_artifacts: List[str] = None

    def __post_init__(self):
        """Initialize default values."""
        if self.checked_at is None:
            self.checked_at = datetime.now(timezone.utc)
        if self.pending_artifacts is None:
            self.pending_artifacts = []


class ComplianceGateService:
    """Service for checking project compliance status with fast response times.

    Determines if a project has pending artifact updates that would require
    enforcement actions. Designed for sub-200ms response times with Redis caching.

    Args:
        session: Database session for artifact queries
        redis_client: Optional Redis client for caching (if None, no caching)
        cache_ttl: Cache TTL in seconds (default: 300 = 5 minutes)
    """

    def __init__(
        self, session: Session, redis_client: Optional[Any] = None, cache_ttl: int = 300
    ):
        """Initialize the compliance gate service.

        Args:
            session: Database session
            redis_client: Optional Redis client for caching
            cache_ttl: Cache time-to-live in seconds
        """
        self.session = session
        self.redis_client = redis_client
        self.cache_ttl = cache_ttl
        self.cascade_service = UpstreamCascadeService(session)

    def check_compliance(
        self, project_id: str, project_path: Path, idempotency_key: Optional[str] = None
    ) -> ComplianceStatus:
        """Check if project is compliant for execution.

        A project is considered non-compliant if:
        1. It has deployed artifacts that are marked as outdated (is_outdated=True)
        2. Hard update enforcement is enabled

        Args:
            project_id: Base64-encoded project identifier
            project_path: Path to project directory
            idempotency_key: Optional idempotency key for caching

        Returns:
            ComplianceStatus indicating whether project can proceed
        """
        start_time = time.monotonic()
        cache_key = self._build_cache_key(project_id, idempotency_key)

        # Try cache first if Redis is available
        cached_result = self._get_cached_status(cache_key)
        if cached_result:
            logger.debug(f"Compliance check cache HIT for {project_id}")
            return cached_result

        logger.debug(f"Compliance check cache MISS for {project_id}")

        try:
            # Check if project has deployments
            deployment_file = DeploymentTracker.get_deployment_file_path(project_path)
            if not deployment_file.exists():
                # No deployments = compliant
                status = ComplianceStatus(
                    project_id=project_id,
                    is_compliant=True,
                    pending_updates_count=0,
                    enforcement_required=False,
                )
                self._cache_status(cache_key, status)
                return status

            # Get all deployed artifacts for this project
            deployments = DeploymentTracker.read_deployments(project_path)
            if not deployments:
                # No deployments = compliant
                status = ComplianceStatus(
                    project_id=project_id,
                    is_compliant=True,
                    pending_updates_count=0,
                    enforcement_required=False,
                )
                self._cache_status(cache_key, status)
                return status

            # Check for outdated artifacts in database
            pending_artifacts = []
            artifact_ids = []

            for deployment in deployments:
                # Build artifact identifier from deployment info
                # This matches the pattern used in the cache models
                artifact_id = f"{deployment.artifact_type}:{deployment.artifact_name}"
                artifact_ids.append(artifact_id)

            if artifact_ids:
                # Query database for outdated artifacts
                outdated_artifacts = (
                    self.session.query(Artifact)
                    .filter(Artifact.id.in_(artifact_ids), Artifact.is_outdated == True)
                    .all()
                )

                pending_artifacts = [artifact.id for artifact in outdated_artifacts]

            # Determine compliance status
            pending_count = len(pending_artifacts)
            enforcement_required = pending_count > 0
            is_compliant = not enforcement_required

            status = ComplianceStatus(
                project_id=project_id,
                is_compliant=is_compliant,
                pending_updates_count=pending_count,
                enforcement_required=enforcement_required,
                pending_artifacts=pending_artifacts,
            )

            # Cache the result
            self._cache_status(cache_key, status)

            elapsed_ms = (time.monotonic() - start_time) * 1000
            logger.info(
                f"Compliance check completed for {project_id}: "
                f"compliant={is_compliant}, pending={pending_count}, "
                f"time={elapsed_ms:.2f}ms"
            )

            return status

        except Exception as e:
            logger.error(
                f"Error checking compliance for {project_id}: {e}", exc_info=True
            )
            # On error, default to non-compliant for safety
            return ComplianceStatus(
                project_id=project_id,
                is_compliant=False,
                pending_updates_count=0,
                enforcement_required=True,
            )

    def _build_cache_key(
        self, project_id: str, idempotency_key: Optional[str] = None
    ) -> str:
        """Build Redis cache key for compliance status.

        Args:
            project_id: Project identifier
            idempotency_key: Optional idempotency key

        Returns:
            Redis key string
        """
        if idempotency_key:
            # Include idempotency key in cache key for request deduplication
            key_data = f"compliance:{project_id}:{idempotency_key}"
        else:
            key_data = f"compliance:{project_id}"

        # Hash the key to keep it reasonable length
        key_hash = hashlib.sha256(key_data.encode()).hexdigest()[:16]
        return f"skillmeat:compliance:{key_hash}"

    def _get_cached_status(self, cache_key: str) -> Optional[ComplianceStatus]:
        """Get cached compliance status from Redis.

        Args:
            cache_key: Redis key

        Returns:
            ComplianceStatus if found in cache, None otherwise
        """
        if not self.redis_client:
            return None

        try:
            cached_data = self.redis_client.get(cache_key)
            if cached_data:
                data = json.loads(cached_data)

                # Parse datetime if present
                checked_at = None
                if data.get("checked_at"):
                    checked_at = datetime.fromisoformat(data["checked_at"])

                return ComplianceStatus(
                    project_id=data["project_id"],
                    is_compliant=data["is_compliant"],
                    pending_updates_count=data["pending_updates_count"],
                    enforcement_required=data["enforcement_required"],
                    checked_at=checked_at,
                    cache_hit=True,
                    pending_artifacts=data.get("pending_artifacts", []),
                )
        except Exception as e:
            logger.warning(f"Failed to get cached compliance status: {e}")

        return None

    def _cache_status(self, cache_key: str, status: ComplianceStatus) -> None:
        """Cache compliance status in Redis.

        Args:
            cache_key: Redis key
            status: Status to cache
        """
        if not self.redis_client:
            return

        try:
            data = {
                "project_id": status.project_id,
                "is_compliant": status.is_compliant,
                "pending_updates_count": status.pending_updates_count,
                "enforcement_required": status.enforcement_required,
                "checked_at": (
                    status.checked_at.isoformat() if status.checked_at else None
                ),
                "pending_artifacts": status.pending_artifacts or [],
            }

            self.redis_client.setex(cache_key, self.cache_ttl, json.dumps(data))

        except Exception as e:
            logger.warning(f"Failed to cache compliance status: {e}")

    def invalidate_project_cache(self, project_id: str) -> None:
        """Invalidate all cached compliance statuses for a project.

        Should be called when project deployments change.

        Args:
            project_id: Project identifier
        """
        if not self.redis_client:
            return

        try:
            # Find all keys for this project
            pattern = f"skillmeat:compliance:*"
            keys = self.redis_client.keys(pattern)

            if keys:
                # Delete all matching keys
                # Note: This is a simple implementation. In production with many projects,
                # consider a more targeted approach using key naming conventions.
                self.redis_client.delete(*keys)
                logger.debug(
                    f"Invalidated {len(keys)} compliance cache entries for {project_id}"
                )

        except Exception as e:
            logger.warning(
                f"Failed to invalidate compliance cache for {project_id}: {e}"
            )
