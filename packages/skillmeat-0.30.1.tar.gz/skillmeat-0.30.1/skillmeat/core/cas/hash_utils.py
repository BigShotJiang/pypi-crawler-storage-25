"""Bundle hash computation utilities for DVCS atomic composite versioning.

This module provides the canonical hash algorithm used to produce the
``bundle_hash`` field stored on ``BundleCommit`` rows.  The algorithm is
designed to be:

- **Deterministic**: identical member sets always produce the same hash.
- **Order-independent**: member dicts may arrive in any order; the sort step
  normalises them before hashing.
- **Tamper-evident**: any change to a member's ``artifact_uuid`` or
  ``content_hash`` changes the bundle hash.

Algorithm (from DVCS SPIKE § 4)
--------------------------------
1. Extract ``(artifact_uuid, content_hash)`` from each member dict.
2. Sort the pairs lexicographically by ``artifact_uuid``.
3. Serialise as a canonical JSON array of ``[uuid, hash]`` two-element
   arrays, with no extra whitespace.
4. Compute the SHA-256 hex digest of the UTF-8 encoded JSON string.

References
----------
- SPIKE: ``docs/dev/architecture/spikes/dvcs-atomic-versioning/dvcs-atomic-versioning-findings.md``
- Repository: ``skillmeat/cache/bundle_commit_repository.py``
- BundleCommit model: ``skillmeat/cache/models.py``
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, List


def compute_bundle_hash(members: List[Dict[str, Any]]) -> str:
    """Compute a SHA-256 bundle hash over sorted (artifact_uuid, content_hash) pairs.

    The hash is deterministic and order-independent: members may be supplied in
    any order and the result is always identical for the same logical member set.

    Algorithm:

    1. Extract ``(artifact_uuid, content_hash)`` from each entry in *members*.
    2. Sort the extracted pairs lexicographically by ``artifact_uuid`` (first
       element), breaking ties by ``content_hash`` (second element).
    3. Serialise as a compact JSON array of two-element arrays, e.g.
       ``[["uuid-a","hash1"],["uuid-b","hash2"]]``, encoded to UTF-8 with no
       extra whitespace (``separators=(",", ":")``, ``sort_keys=False``).
    4. Return the lowercase SHA-256 hex digest of the serialised bytes.

    An empty *members* list is valid and produces a well-defined hash (the
    SHA-256 of the serialisation of ``[]``).

    Args:
        members: List of dicts, each containing at minimum the keys
            ``"artifact_uuid"`` (str) and ``"content_hash"`` (str).
            Additional keys are ignored.

    Returns:
        64-character lowercase SHA-256 hex digest string.

    Raises:
        KeyError: If any entry in *members* is missing ``"artifact_uuid"`` or
            ``"content_hash"``.

    Example::

        from skillmeat.core.cas.hash_utils import compute_bundle_hash

        members = [
            {"artifact_uuid": "b-uuid", "content_hash": "b-hash"},
            {"artifact_uuid": "a-uuid", "content_hash": "a-hash"},
        ]
        # Always the same regardless of input order:
        h = compute_bundle_hash(members)
        assert len(h) == 64
    """
    pairs = [(member["artifact_uuid"], member["content_hash"]) for member in members]
    pairs.sort(key=lambda pair: (pair[0], pair[1]))

    canonical = json.dumps(pairs, separators=(",", ":"), ensure_ascii=True)
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return digest
