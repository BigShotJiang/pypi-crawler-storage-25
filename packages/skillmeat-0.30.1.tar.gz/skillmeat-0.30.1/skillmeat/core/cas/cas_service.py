"""CASService: orchestrates content-addressed ArtifactVersion creation.

Responsibilities
----------------
1. Accept a dict of ``{relative_path: content_str}`` pairs.
2. Upsert each file's content through ``BlobRepository``, collecting hashes.
3. Build the ``content_tree`` JSON map ``{relative_path: sha256_hex}``.
4. Compute a deterministic ``upstream_hash`` as the SHA-256 of the
   JSON-serialised (sorted-key) content_tree string.
5. Construct and flush an ``ArtifactVersion`` row with the CAS fields
   populated and ``content_payload = None`` (CAS replaces inline storage).
6. Return the new ``ArtifactVersion`` to the caller.

The caller controls the SQLAlchemy transaction (``session.commit()``).

Usage
-----
::

    from skillmeat.core.cas.blob_backend import get_blob_backend
    from skillmeat.core.cas.blob_repository import BlobRepository
    from skillmeat.core.cas.cas_service import CASService

    backend = get_blob_backend(session)
    blob_repo = BlobRepository(session, backend)
    svc = CASService(blob_repo, session)

    version = svc.create_version_cas(
        artifact_id="skill:my-skill",
        content={"SKILL.md": "# My Skill\\n...", "prompts/system.md": "You are…"},
        change_origin="deployment",
        content_hash="<caller-supplied-hash>",  # required by ArtifactVersion
    )
    session.commit()

References
----------
- ADR-013: ``docs/dev/architecture/decisions/adr-013-cas-blob-architecture.md``
- SPIKE findings § 1.2: content_tree JSON format
- BlobRepository: ``skillmeat/core/cas/blob_repository.py``
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Dict, Optional

from sqlalchemy.orm import Session

from skillmeat.cache.models import ArtifactVersion
from skillmeat.core.cas.blob_repository import BlobRepository

logger = logging.getLogger(__name__)


class CASService:
    """Orchestrates content-addressed version creation.

    Converts a dict of ``{relative_path: content_str}`` into a stored
    ``ArtifactVersion`` backed by deduplicated blobs in ``artifact_blobs``.

    Args:
        blob_repository: ``BlobRepository`` instance bound to an active session.
        session: Active SQLAlchemy session.  The caller controls commit/rollback.
    """

    def __init__(self, blob_repository: BlobRepository, session: Session) -> None:
        self._blob_repo = blob_repository
        self._session = session

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def create_version_cas(
        self,
        artifact_id: str,
        content: Dict[str, str],
        change_origin: str,
        **version_kwargs: Any,
    ) -> ArtifactVersion:
        """Create an ``ArtifactVersion`` using CAS blob storage.

        Steps:

        1. For each ``(path, file_content)`` pair in *content*:
           - Upsert the blob via ``BlobRepository`` (returns its SHA-256 hash).
           - Add ``{path: hash}`` to the content tree.
        2. Compute ``upstream_hash`` = SHA-256 of the sorted JSON-serialised
           content tree (deterministic regardless of dict insertion order).
        3. Construct an ``ArtifactVersion`` with:
           - ``content_tree`` = JSON-serialised content tree.
           - ``upstream_hash`` = hash computed in step 2.
           - ``is_complete_capture`` = ``True`` (all blobs successfully stored).
           - ``content_payload`` = ``None`` (CAS replaces inline storage).
        4. Flush to obtain a row ID without committing the transaction.

        Args:
            artifact_id: FK value for ``ArtifactVersion.artifact_id``
                (the ``Artifact.id`` string, e.g. ``"skill:my-skill"``).
            content: Mapping of relative file paths to raw text content.
                Single-file artifacts use one key (the canonical filename).
                Multi-file artifacts use relative paths as keys, e.g.
                ``{"SKILL.md": "...", "prompts/system.md": "..."}``.
            change_origin: Must be one of the values accepted by the
                ``check_artifact_versions_change_origin`` DB constraint.
            **version_kwargs: Additional keyword arguments forwarded directly
                to the ``ArtifactVersion`` constructor.  At minimum,
                ``content_hash`` is required (the unique dedup key per
                ``ArtifactVersion``'s unique index on ``(artifact_id, content_hash)``).

        Returns:
            The newly constructed ``ArtifactVersion`` ORM object (not yet
            committed — callers must call ``session.commit()``).

        Example::

            version = svc.create_version_cas(
                artifact_id="skill:canvas-design",
                content={"SKILL.md": "# Canvas Design"},
                change_origin="deployment",
                content_hash="abc123...",
            )
            session.commit()
        """
        if not content:
            raise ValueError(
                "content must contain at least one file entry; "
                "an empty content dict cannot produce a meaningful ArtifactVersion."
            )

        # Step 1: upsert each file blob and collect the content tree.
        content_tree: Dict[str, str] = {}
        for path, file_content in content.items():
            blob_hash = self._blob_repo.upsert(file_content)
            content_tree[path] = blob_hash
            logger.debug(
                "CASService: stored blob for %r hash=%s...", path, blob_hash[:8]
            )

        # Step 2: compute deterministic upstream_hash from sorted content_tree JSON.
        content_tree_json = json.dumps(content_tree, sort_keys=True)
        upstream_hash = hashlib.sha256(content_tree_json.encode()).hexdigest()
        logger.debug(
            "CASService: content_tree_paths=%r upstream_hash=%s...",
            list(content_tree.keys()),
            upstream_hash[:8],
        )

        # Step 3 & 4: construct the ArtifactVersion and flush.
        version = ArtifactVersion(
            artifact_id=artifact_id,
            change_origin=change_origin,
            content_tree=content_tree_json,
            upstream_hash=upstream_hash,
            is_complete_capture=True,
            content_payload=None,
            **version_kwargs,
        )
        self._session.add(version)
        self._session.flush()

        logger.info(
            "CASService: created ArtifactVersion id=%r artifact_id=%r "
            "files=%d upstream_hash=%s...",
            version.id,
            artifact_id,
            len(content_tree),
            upstream_hash[:8],
        )
        return version
