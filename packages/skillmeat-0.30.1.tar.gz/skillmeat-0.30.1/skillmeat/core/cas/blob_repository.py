"""BlobRepository: session-managed wrapper around BlobBackend for CAS operations.

This module provides a thin application-layer wrapper over the low-level
``BlobBackend`` implementations.  It adds:

- Automatic SHA-256 hashing of raw content (callers pass text, not hashes).
- Hash re-validation on ``fetch`` to detect storage corruption or tampering.
- A ``gc_sweep`` delegation for the GC worker.

Design
------
``BlobRepository`` is intentionally *not* a ``BaseRepository`` subclass — it
does not operate on a single ORM model class with standard CRUD.  Instead it
follows the Hexagonal/Port pattern: the session is used only as a transaction
boundary holder; the backend performs all SQL.

Usage
-----
::

    from skillmeat.core.cas.blob_backend import get_blob_backend
    from skillmeat.core.cas.blob_repository import BlobRepository

    backend = get_blob_backend(session)
    repo = BlobRepository(session, backend)

    hash_ = repo.upsert("# My Skill\\nDo things.")
    content = repo.fetch(hash_)  # Returns the stored text

References
----------
- ADR-013: ``docs/dev/architecture/decisions/adr-013-cas-blob-architecture.md``
- BlobBackend: ``skillmeat/core/cas/blob_backend.py``
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

from skillmeat.core.cas.blob_backend import BlobBackend

logger = logging.getLogger(__name__)


class BlobRepository:
    """Session-managed wrapper around BlobBackend for CAS blob operations.

    Provides a higher-level interface over ``BlobBackend`` by handling SHA-256
    hashing internally so callers work with plain content strings rather than
    pre-computed hashes.

    Hash re-validation on ``fetch`` detects storage corruption or deliberate
    tampering: if the content retrieved from the backend hashes differently from
    the requested key, a ``ValueError`` is raised.

    Args:
        session: Active SQLAlchemy session.  The caller controls commit/rollback.
        backend: Concrete ``BlobBackend`` instance (SQLite or Postgres).
    """

    def __init__(self, session: Session, backend: BlobBackend) -> None:
        self._session = session
        self._backend = backend

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def upsert(self, content: str, encoding: str = "utf8") -> str:
        """Hash *content* (SHA-256), upsert blob into the backend, return the hash.

        The operation is idempotent: calling ``upsert`` twice with identical
        content stores exactly one row and returns the same hash both times.

        Args:
            content: Raw text content to store.
            encoding: Encoding descriptor passed to the backend.  Defaults to
                ``'utf8'``.  Pass ``'base64'`` for binary content pre-encoded
                as a base64 string.

        Returns:
            The SHA-256 hex digest of *content* (64 lowercase hex characters).
        """
        content_bytes = content.encode(encoding)
        hash_ = hashlib.sha256(content_bytes).hexdigest()
        size_bytes = len(content_bytes)

        self._backend.upsert(hash_, content, encoding, size_bytes)
        logger.debug(
            "BlobRepository.upsert hash=%s... encoding=%s", hash_[:8], encoding
        )
        return hash_

    def fetch(self, hash: str) -> Optional[str]:
        """Fetch blob content by *hash* with re-validation.

        Re-hashes the returned content to detect storage corruption or tampering.
        If the stored content does not match the requested hash a ``ValueError``
        is raised rather than silently returning corrupt data.

        Args:
            hash: SHA-256 hex digest (64 chars) to look up.

        Returns:
            Stored content string, or ``None`` if the hash is not present.

        Raises:
            ValueError: If the stored content's SHA-256 hash does not match
                *hash* (indicates corruption or backend integrity violation).
        """
        content = self._backend.fetch(hash)
        if content is None:
            logger.debug("BlobRepository.fetch hash=%s... not found", hash[:8])
            return None

        # Re-validate: hash the returned content and compare to the requested key.
        actual_hash = hashlib.sha256(content.encode()).hexdigest()
        if actual_hash != hash:
            logger.error(
                "BlobRepository.fetch hash mismatch: requested=%s actual=%s "
                "— possible storage corruption",
                hash,
                actual_hash,
            )
            raise ValueError(
                f"Blob integrity violation: requested hash {hash!r} but stored "
                f"content hashes to {actual_hash!r}.  Storage may be corrupt."
            )

        logger.debug("BlobRepository.fetch hash=%s... ok", hash[:8])
        return content

    def gc_sweep(self, eligible_before: datetime) -> int:
        """Delegate GC sweep to the backend.

        Deletes all blobs whose ``gc_eligible_at`` timestamp is set and falls
        before *eligible_before*.  Protected blobs (``gc_eligible_at = NULL``)
        are never deleted.

        Args:
            eligible_before: Cutoff timestamp.

        Returns:
            Number of blob rows deleted.
        """
        count = self._backend.gc_sweep(eligible_before)
        logger.debug(
            "BlobRepository.gc_sweep deleted=%d cutoff=%s", count, eligible_before
        )
        return count
