"""Content-Addressed Storage (CAS) module for SkillMeat artifact versioning.

This package provides the BlobBackend abstraction and concrete implementations
for storing and retrieving immutable, deduplicated artifact content keyed by
SHA-256 hash.  See ADR-013 and the DVCS CAS Architecture SPIKE for design
rationale.

Public API
----------
BlobBackend
    Abstract base class for blob storage backends.
PostgresBlobBackend
    PostgreSQL implementation using INSERT ... ON CONFLICT DO NOTHING.
SQLiteBlobBackend
    SQLite implementation using query-then-insert (IntegrityError guard).
get_blob_backend
    Factory that inspects the SQLAlchemy engine dialect and returns the
    appropriate concrete backend.
"""

from __future__ import annotations

from skillmeat.core.cas.blob_backend import (
    BlobBackend,
    PostgresBlobBackend,
    SQLiteBlobBackend,
    get_blob_backend,
)
from skillmeat.core.cas.blob_repository import BlobRepository
from skillmeat.core.cas.cas_service import CASService
from skillmeat.core.cas.hash_utils import compute_bundle_hash

__all__ = [
    "BlobBackend",
    "PostgresBlobBackend",
    "SQLiteBlobBackend",
    "get_blob_backend",
    "BlobRepository",
    "CASService",
    "compute_bundle_hash",
]
