"""BlobBackend ABC and concrete implementations for CAS blob storage.

Design
------
``BlobBackend`` is a minimal port (hexagonal architecture) that provides three
operations:

- ``upsert`` — idempotently store a blob keyed by its SHA-256 hash.
- ``fetch``   — retrieve blob content by hash, returning None if missing.
- ``gc_sweep`` — delete blobs whose ``gc_eligible_at`` timestamp is in the
  past relative to *eligible_before*, returning the count of deleted rows.

Concrete Implementations
------------------------
PostgresBlobBackend
    Uses ``INSERT ... ON CONFLICT (hash) DO NOTHING`` which is both atomic and
    idempotent.  This syntax is also valid on SQLite >= 3.24, so the Postgres
    backend can be used against SQLite in unit tests.

SQLiteBlobBackend
    Uses a query-then-insert approach that matches the existing
    ``_upsert_artifact_version`` pattern in the local repositories.  The
    IntegrityError guard ensures idempotency without relying on SQL dialect
    extensions.

Factory
-------
``get_blob_backend(session_or_engine)`` inspects the bound dialect and returns
the correct concrete backend.  Both backends accept a SQLAlchemy ``Session``;
the factory parameter may be a ``Session`` or an ``Engine`` (the engine is
used solely to determine the dialect — callers must still pass a ``Session``
when constructing a backend directly).

Usage Example
-------------
::

    from sqlalchemy.orm import Session
    from skillmeat.core.cas import get_blob_backend

    def store_blob(session: Session, blob_hash: str, content: str) -> None:
        backend = get_blob_backend(session)
        backend.upsert(blob_hash, content, encoding="utf8", size_bytes=len(content.encode()))

References
----------
- ADR-013: ``docs/dev/architecture/decisions/adr-013-cas-blob-architecture.md``
- CAS SPIKE: ``docs/dev/architecture/spikes/dvcs-cas-architecture/dvcs-cas-architecture-findings.md``
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional, Union

from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from skillmeat.cache.models import ArtifactBlob

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Abstract base class
# ---------------------------------------------------------------------------


class BlobBackend(ABC):
    """Abstract blob storage backend for content-addressed artifact content.

    Concrete subclasses must implement three operations:

    - ``upsert`` — idempotent write; duplicate hashes are silently ignored.
    - ``fetch`` — read content by hash; returns None if the hash is unknown.
    - ``gc_sweep`` — delete blobs eligible for garbage collection.

    All implementations receive a SQLAlchemy ``Session`` and operate within
    the session's transaction lifecycle.  Callers are responsible for
    ``commit()`` / ``rollback()``.
    """

    @abstractmethod
    def upsert(
        self,
        hash: str,
        content: str,
        encoding: str,
        size_bytes: int,
    ) -> None:
        """Idempotently store a blob.

        If a blob with the given *hash* already exists this method is a no-op.
        Callers must never pass content that hashes differently from *hash* —
        blob content is immutable once written.

        Args:
            hash: SHA-256 hex digest of *content* (64 hex characters).
            content: Raw blob content (UTF-8 text or base64-encoded binary).
            encoding: Encoding descriptor — ``'utf8'`` or ``'base64'``.
            size_bytes: Byte length of the decoded content.
        """

    @abstractmethod
    def fetch(self, hash: str) -> Optional[str]:
        """Return the stored content for *hash*, or None if not found.

        Args:
            hash: SHA-256 hex digest to look up.

        Returns:
            Blob content string, or ``None`` if the hash is unknown.
        """

    @abstractmethod
    def gc_sweep(self, eligible_before: datetime) -> int:
        """Delete blobs eligible for garbage collection.

        Deletes all blobs where ``gc_eligible_at IS NOT NULL`` and
        ``gc_eligible_at < eligible_before``.  Protected blobs (those with
        ``gc_eligible_at = NULL``) are never touched.

        Args:
            eligible_before: Cutoff timestamp.  Blobs whose ``gc_eligible_at``
                is earlier than this value are deleted.

        Returns:
            Number of blob rows deleted.
        """


# ---------------------------------------------------------------------------
# PostgreSQL implementation
# ---------------------------------------------------------------------------


class PostgresBlobBackend(BlobBackend):
    """Blob backend for PostgreSQL (and SQLite >= 3.24).

    Uses ``INSERT INTO artifact_blobs ... ON CONFLICT (hash) DO NOTHING`` for
    idempotent writes.  This is a single round-trip to the database and
    requires no application-level locking.

    Args:
        session: Bound SQLAlchemy session.  The caller controls transactions.
    """

    def __init__(self, session: Session) -> None:
        self._session = session

    def upsert(
        self,
        hash: str,
        content: str,
        encoding: str,
        size_bytes: int,
    ) -> None:
        """Insert blob if absent; silently skip if hash already exists."""
        stmt = text("""
            INSERT INTO artifact_blobs (hash, content, encoding, size_bytes,
                                        compression, created_at)
            VALUES (:hash, :content, :encoding, :size_bytes,
                    'none', CURRENT_TIMESTAMP)
            ON CONFLICT (hash) DO NOTHING
            """)
        self._session.execute(
            stmt,
            {
                "hash": hash,
                "content": content,
                "encoding": encoding,
                "size_bytes": size_bytes,
            },
        )
        logger.debug("PostgresBlobBackend.upsert hash=%s...", hash[:8])

    def fetch(self, hash: str) -> Optional[str]:
        """Return content for *hash* or None if not present."""
        stmt = text("SELECT content FROM artifact_blobs WHERE hash = :hash")
        row = self._session.execute(stmt, {"hash": hash}).fetchone()
        if row is None:
            return None
        return row[0]

    def gc_sweep(self, eligible_before: datetime) -> int:
        """Delete GC-eligible blobs older than *eligible_before*."""
        stmt = text("""
            DELETE FROM artifact_blobs
            WHERE gc_eligible_at IS NOT NULL
              AND gc_eligible_at < :cutoff
            """)
        result = self._session.execute(stmt, {"cutoff": eligible_before})
        count: int = result.rowcount
        logger.debug(
            "PostgresBlobBackend.gc_sweep deleted=%d cutoff=%s", count, eligible_before
        )
        return count


# ---------------------------------------------------------------------------
# SQLite implementation
# ---------------------------------------------------------------------------


class SQLiteBlobBackend(BlobBackend):
    """Blob backend for SQLite using query-then-insert deduplication.

    Matches the ``_upsert_artifact_version`` pattern in the local
    repositories.  An ``IntegrityError`` from a concurrent writer is caught
    and treated as success (the blob already exists).

    Args:
        session: Bound SQLAlchemy session.  The caller controls transactions.
    """

    def __init__(self, session: Session) -> None:
        self._session = session

    def upsert(
        self,
        hash: str,
        content: str,
        encoding: str,
        size_bytes: int,
    ) -> None:
        """Insert blob if absent; silently ignore duplicate hashes."""
        # Fast path: check existence first to avoid an unnecessary INSERT.
        existing = (
            self._session.query(ArtifactBlob).filter(ArtifactBlob.hash == hash).first()
        )
        if existing is not None:
            logger.debug(
                "SQLiteBlobBackend.upsert hash=%s... already exists (no-op)", hash[:8]
            )
            return

        blob = ArtifactBlob(
            hash=hash,
            content=content,
            encoding=encoding,
            size_bytes=size_bytes,
            compression="none",
            created_at=datetime.utcnow(),
        )
        try:
            self._session.add(blob)
            self._session.flush()
            logger.debug("SQLiteBlobBackend.upsert hash=%s... stored", hash[:8])
        except IntegrityError:
            # Another writer stored the same blob concurrently — roll back the
            # failed INSERT and continue normally.
            self._session.rollback()
            logger.debug(
                "SQLiteBlobBackend.upsert hash=%s... IntegrityError (concurrent write, ignored)",
                hash[:8],
            )

    def fetch(self, hash: str) -> Optional[str]:
        """Return content for *hash* or None if not present."""
        blob = (
            self._session.query(ArtifactBlob).filter(ArtifactBlob.hash == hash).first()
        )
        return blob.content if blob is not None else None

    def gc_sweep(self, eligible_before: datetime) -> int:
        """Delete GC-eligible blobs older than *eligible_before*."""
        stmt = text("""
            DELETE FROM artifact_blobs
            WHERE gc_eligible_at IS NOT NULL
              AND gc_eligible_at < :cutoff
            """)
        result = self._session.execute(stmt, {"cutoff": eligible_before})
        count: int = result.rowcount
        logger.debug(
            "SQLiteBlobBackend.gc_sweep deleted=%d cutoff=%s", count, eligible_before
        )
        return count


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def get_blob_backend(session: Session) -> BlobBackend:
    """Return the appropriate BlobBackend for the session's database dialect.

    Inspects the dialect of the engine bound to *session* and returns:

    - ``PostgresBlobBackend`` for ``postgresql`` dialects.
    - ``SQLiteBlobBackend`` for ``sqlite`` dialects (and as the default
      fallback for any other dialect not explicitly mapped).

    Args:
        session: Active SQLAlchemy session.

    Returns:
        A concrete ``BlobBackend`` bound to *session*.

    Example::

        from skillmeat.core.cas import get_blob_backend

        backend = get_blob_backend(db_session)
        backend.upsert(sha256_hex, content, encoding="utf8", size_bytes=len_bytes)
    """
    dialect_name: str = session.bind.dialect.name  # type: ignore[union-attr]
    if dialect_name == "postgresql":
        return PostgresBlobBackend(session)
    # Default: SQLite (used for local edition and tests).
    return SQLiteBlobBackend(session)
