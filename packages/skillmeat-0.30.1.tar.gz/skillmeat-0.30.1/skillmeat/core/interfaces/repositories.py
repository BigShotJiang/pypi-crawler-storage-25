"""Abstract repository interfaces for SkillMeat's hexagonal architecture.

These ABCs define the data-access contracts that every storage backend must
satisfy.  Infrastructure implementations (e.g. the SQLAlchemy cache adapter)
live outside the core and fulfil these interfaces; the core never depends on
any concrete storage technology.

Design invariants:
- All classes inherit from ``abc.ABC``.
- All methods are decorated with ``@abc.abstractmethod`` and raise
  ``NotImplementedError`` to prevent accidental instantiation of partial
  implementations.
- ``ctx: RequestContext | None = None`` is the last parameter of every method
  so that callers that do not care about per-request metadata can omit it.
- Filter arguments use ``dict[str, Any] | None`` for now; typed filter objects
  can be introduced in a later phase without breaking the contract.
- No Pydantic, no SQLAlchemy — stdlib only (plus the sibling interfaces
  modules).

Usage::

    from skillmeat.core.interfaces.repositories import (
        IArtifactRepository,
        IProjectRepository,
        ICollectionRepository,
        IDeploymentRepository,
        ITagRepository,
        ISettingsRepository,
    )
"""

from __future__ import annotations

import abc
import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any

from skillmeat.core.interfaces.context import RequestContext

if TYPE_CHECKING:
    from skillmeat.api.schemas.auth import AuthContext
    from skillmeat.core.ownership import OwnerTarget
from skillmeat.core.interfaces.dtos import (
    ActivityEventDTO,
    ArtifactDTO,
    ArtifactVersionDTO,
    BundleDTO,
    BundleListDTO,
    BundleMembershipDTO,
    CacheArtifactSummaryDTO,
    CatalogEntryDTO,
    CatalogItemDTO,
    CategoryDTO,
    CollectionArtifactDTO,
    CollectionDTO,
    CollectionMembershipDTO,
    CollectionStatsDTO,
    ContextEntityDTO,
    DeploymentDTO,
    EntityTypeConfigDTO,
    GitRepoConnectionDTO,
    GitRepoScanDTO,
    GitScanArtifactDTO,
    GroupArtifactDTO,
    GroupDTO,
    GroupMembershipEntryDTO,
    MarketplaceSourceDTO,
    ProjectDTO,
    ProjectTemplateDTO,
    SettingsDTO,
    StalenessStatsDTO,
    SourceDeploymentEntryDTO,
    TagDTO,
    TemplateDeployResultDTO,
    MemoryItemDTO,
    UserCollectionDTO,
    WorkflowDTO,
    WorkflowExecutionDTO,
    AttestationRecordDTO,
    BomSnapshotDTO,
    GitCredentialDTO,
    ProjectGitConnectionDTO,
)

__all__ = [
    "IArtifactRepository",
    "IProjectRepository",
    "ICollectionRepository",
    "IDbUserCollectionRepository",
    "IDeploymentRepository",
    "ITagRepository",
    "ISettingsRepository",
    "IGroupRepository",
    "IContextEntityRepository",
    "IMarketplaceSourceRepository",
    "IProjectTemplateRepository",
    "IDbCollectionArtifactRepository",
    "IDbArtifactHistoryRepository",
    "IMembershipRepository",
    "IArtifactActivityRepository",
    "IBundleRepository",
    "IGitRepoConnectionRepository",
    "IGitRepoScanRepository",
    "IGitScanArtifactRepository",
    "IWorkflowRepository",
    "IMemoryItemRepository",
    "IBomRepository",
]


# =============================================================================
# IArtifactRepository
# =============================================================================


class IArtifactRepository(abc.ABC):
    """Contract for all artifact storage backends.

    Covers the full lifecycle of an artifact: creation, retrieval, update,
    deletion, search, and file-content access.  The operations reflect what
    the ``/api/v1/artifacts`` router exposes.
    """

    # ------------------------------------------------------------------
    # Single-item lookup
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get(
        self,
        id: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> ArtifactDTO | None:
        """Return the artifact with the given ``type:name`` primary key.

        Args:
            id: Artifact primary key in ``"type:name"`` format
                (e.g. ``"skill:frontend-design"``).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            An :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO` when the
            artifact exists, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_uuid(
        self,
        uuid: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> ArtifactDTO | None:
        """Return the artifact identified by its stable UUID.

        The UUID is the ADR-007 identity and remains stable across renames.

        Args:
            uuid: 32-char hex UUID string.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            An :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO` when
            found, ``None`` otherwise.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Collection queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list(
        self,
        filters: dict[str, Any] | None = None,
        offset: int = 0,
        limit: int = 50,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> list[ArtifactDTO]:
        """Return a page of artifacts matching optional filter criteria.

        Args:
            filters: Optional key/value filter map.  Recognised keys are
                implementation-defined but should include at minimum
                ``artifact_type``, ``project_id``, ``scope``, and
                ``is_outdated``.
            offset: Zero-based record offset for pagination.
            limit: Maximum number of records to return.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO` objects.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def count(
        self,
        filters: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> int:
        """Return the total number of artifacts matching optional filter criteria.

        Intended to back ``page_info.total`` in paginated list responses.

        Args:
            filters: Same filter map accepted by :meth:`list`.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            Non-negative integer count.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def search(
        self,
        query: str,
        filters: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> list[ArtifactDTO]:
        """Full-text / fuzzy search across artifact names and metadata.

        Args:
            query: Free-form search string.
            filters: Optional additional filter constraints applied on top
                of the text match.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            Ranked list of matching
            :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO` objects.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Mutations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def create(
        self,
        dto: ArtifactDTO,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
        owner_target: OwnerTarget | None = None,
    ) -> ArtifactDTO:
        """Persist a new artifact record and return the stored representation.

        Args:
            dto: Fully populated artifact data.  The implementation may
                ignore ``created_at`` / ``updated_at`` and set them itself.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).
            owner_target: Explicit ownership target for the new artifact.
                When provided, the implementation MUST use this instead of
                deriving ownership from ``auth_context`` (e.g. team-owned or
                enterprise-owned artifacts).  When ``None``, defaults to
                user-owned (backward-compatible behaviour).

        Returns:
            The persisted :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO`
            (may differ from *dto* if the backend generates fields such as
            ``uuid`` or timestamps).
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        id: str,
        updates: dict[str, Any],
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> ArtifactDTO:
        """Apply a partial update to an existing artifact.

        Args:
            id: Artifact primary key (``"type:name"``).
            updates: Map of field names to new values.  Only provided
                fields are changed; others remain untouched.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            The updated :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO`.

        Raises:
            KeyError: If no artifact with *id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(
        self,
        id: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> bool:
        """Delete an artifact and all its associated records.

        Args:
            id: Artifact primary key (``"type:name"``).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            ``True`` when the artifact was found and deleted, ``False`` when
            no matching record existed.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # File-content access
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_content(
        self,
        id: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> str:
        """Return the raw text content of an artifact's primary file.

        Args:
            id: Artifact primary key (``"type:name"``).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            File content as a UTF-8 string.

        Raises:
            KeyError: If no artifact with *id* exists.
            FileNotFoundError: If the content file cannot be located.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_content(
        self,
        id: str,
        content: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> bool:
        """Overwrite the primary file content of an artifact.

        Args:
            id: Artifact primary key (``"type:name"``).
            content: New file content (UTF-8 string).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            ``True`` on success.

        Raises:
            KeyError: If no artifact with *id* exists.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Tag associations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_tags(
        self,
        id: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> list[TagDTO]:
        """Return all tags currently assigned to an artifact.

        Args:
            id: Artifact primary key (``"type:name"``).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.TagDTO` objects.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def set_tags(
        self,
        id: str,
        tag_ids: list[str],
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> bool:
        """Replace the complete tag set for an artifact.

        Args:
            id: Artifact primary key (``"type:name"``).
            tag_ids: New complete list of tag IDs.  Any previous tags not
                present in this list are removed.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            ``True`` on success.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # UUID resolution
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def resolve_uuid_by_type_name(
        self,
        artifact_type: str,
        name: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> str | None:
        """Resolve the stable UUID for an artifact identified by type and name.

        Args:
            artifact_type: Artifact type string (e.g. ``"skill"``).
            name: Artifact name string.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            32-char hex UUID string when found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_ids_by_uuids(
        self,
        uuids: list[str],
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> dict[str, str]:
        """Batch-map artifact UUIDs to their ``type:name`` ID strings.

        Executes a single round-trip against the DB cache and returns a
        mapping of every UUID that has a matching artifact row.  UUIDs with
        no corresponding row are absent from the returned dict.

        Args:
            uuids: List of 32-char hex UUID strings to look up.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            Dict mapping each UUID to its ``"type:name"`` artifact ID string.
            Unresolvable UUIDs are omitted.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def batch_resolve_uuids(
        self,
        artifacts: list[tuple[str, str]],
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> dict[tuple[str, str], str]:
        """Batch-resolve UUIDs for multiple ``(artifact_type, name)`` pairs.

        Executes a single round-trip (when possible) rather than N individual
        lookups.  Pairs that cannot be resolved are absent from the returned
        dict.

        Args:
            artifacts: List of ``(artifact_type, name)`` tuples.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            Dict mapping each ``(artifact_type, name)`` tuple to its 32-char
            hex UUID.  Unresolvable pairs are omitted.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Collection-context queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_with_collection_context(
        self,
        uuid: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> ArtifactDTO | None:
        """Return an artifact with enriched collection-membership context.

        The returned DTO may carry additional collection-level metadata
        (e.g. collection description, collection tags) compared to the
        plain :meth:`get_by_uuid` result.

        Args:
            uuid: Stable artifact UUID (32-char hex).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            An :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO` when
            found (with collection context populated where available),
            ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_collection_memberships(
        self,
        uuid: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> list[CollectionMembershipDTO]:
        """Return all collections that contain the artifact identified by *uuid*.

        Args:
            uuid: Stable artifact UUID (32-char hex).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.CollectionMembershipDTO`
            objects, one per collection membership.  Returns an empty list
            when the artifact is not found or has no collection memberships.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_collection_description(
        self,
        uuid: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> str | None:
        """Return the collection-level description for an artifact.

        The collection-level description may differ from the artifact's
        intrinsic description (e.g. it may be set by the collection owner
        rather than the artifact author).

        Args:
            uuid: Stable artifact UUID (32-char hex).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            Collection-level description string, or ``None`` when not set
            or the artifact does not exist.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Deduplication cluster queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_duplicate_cluster_members(
        self,
        cluster_id: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> list[ArtifactDTO]:
        """Return all artifacts that belong to the given deduplication cluster.

        Deduplication clusters group semantically equivalent artifacts
        discovered during import or sync.

        Args:
            cluster_id: Opaque cluster identifier (implementation-defined).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO`
            objects representing every cluster member.  Returns an empty
            list when the cluster does not exist or has no members.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Existence and type queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def validate_exists(
        self,
        uuid: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> bool:
        """Check whether an artifact with the given UUID exists.

        Lighter-weight alternative to :meth:`get_by_uuid` when only
        existence is needed.

        Args:
            uuid: Stable artifact UUID (32-char hex).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            ``True`` when an artifact with *uuid* exists, ``False`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_type(
        self,
        artifact_type: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> list[ArtifactDTO]:
        """Return all artifacts of the specified type.

        Equivalent to calling :meth:`list` with ``filters={"artifact_type": artifact_type}``
        and no pagination, but expressed as a first-class method for clarity.

        Args:
            artifact_type: Artifact type string (e.g. ``"skill"``, ``"command"``).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO`
            objects matching *artifact_type*.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Collection-level mutations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def update_collection_tags(
        self,
        uuid: str,
        tags: list[str],
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> None:
        """Replace the collection-level tags for an artifact.

        Collection-level tags are distinct from intrinsic artifact tags:
        they are set by the collection owner and stored alongside the
        collection membership record rather than in the artifact manifest.

        Args:
            uuid: Stable artifact UUID (32-char hex).
            tags: New complete list of tag name strings.  Replaces any
                previously set collection-level tags.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Raises:
            KeyError: If no artifact with *uuid* exists.
        """
        raise NotImplementedError


# =============================================================================
# IProjectRepository
# =============================================================================


class IProjectRepository(abc.ABC):
    """Contract for project storage backends.

    A project represents a directory on disk that has one or more artifacts
    deployed into it.  Operations map to the ``/api/v1/projects`` router.
    """

    @abc.abstractmethod
    def get(
        self,
        id: str,
        ctx: RequestContext | None = None,
    ) -> ProjectDTO | None:
        """Return the project with the given identifier.

        Args:
            id: Base64-encoded project path (primary key).
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.ProjectDTO` when
            found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list(
        self,
        filters: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> list[ProjectDTO]:
        """Return all known projects.

        Args:
            filters: Optional filter map (e.g. ``{"status": "active"}``).
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.ProjectDTO`
            objects.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create(
        self,
        dto: ProjectDTO,
        ctx: RequestContext | None = None,
    ) -> ProjectDTO:
        """Register a new project.

        Args:
            dto: Project data including at minimum ``id``, ``name``, and
                ``path``.
            ctx: Optional per-request metadata.

        Returns:
            The persisted :class:`~skillmeat.core.interfaces.dtos.ProjectDTO`.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        id: str,
        updates: dict[str, Any],
        ctx: RequestContext | None = None,
    ) -> ProjectDTO:
        """Apply a partial update to an existing project.

        Args:
            id: Project primary key (base64-encoded path).
            updates: Map of field names to new values.
            ctx: Optional per-request metadata.

        Returns:
            The updated :class:`~skillmeat.core.interfaces.dtos.ProjectDTO`.

        Raises:
            KeyError: If no project with *id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(
        self,
        id: str,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Remove a project record.

        Does not delete anything on disk — only removes the DB/registry entry.

        Args:
            id: Project primary key (base64-encoded path).
            ctx: Optional per-request metadata.

        Returns:
            ``True`` when the project was found and deleted, ``False``
            otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_artifacts(
        self,
        project_id: str,
        ctx: RequestContext | None = None,
    ) -> list[ArtifactDTO]:
        """Return all artifacts deployed to a project.

        Args:
            project_id: Base64-encoded project path.
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO`
            objects representing each deployed artifact.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def refresh(
        self,
        id: str,
        ctx: RequestContext | None = None,
    ) -> ProjectDTO:
        """Trigger a cache refresh for a single project.

        Rescans the project's deployment tracking files and updates the
        cached artifact list.

        Args:
            id: Project primary key (base64-encoded path).
            ctx: Optional per-request metadata.

        Returns:
            The refreshed :class:`~skillmeat.core.interfaces.dtos.ProjectDTO`.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_path(
        self,
        path: str,
        ctx: RequestContext | None = None,
    ) -> ProjectDTO | None:
        """Return the project whose filesystem path matches *path*.

        Args:
            path: Absolute filesystem path (resolved).
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.ProjectDTO` when a
            project with the given path is found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_or_create_by_path(
        self,
        path: str,
        ctx: RequestContext | None = None,
    ) -> ProjectDTO:
        """Return the project for *path*, creating a DB record if absent.

        Resolves the absolute path, looks up an existing project by path,
        and creates a new one if none is found.  Used by endpoints that
        accept base64-encoded paths that may not yet have a DB entry.

        Args:
            path: Absolute filesystem path (will be resolved).
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.ProjectDTO` (existing
            or newly created).
        """
        raise NotImplementedError


# =============================================================================
# ICollectionRepository
# =============================================================================


class ICollectionRepository(abc.ABC):
    """Contract for collection storage backends.

    A collection is the user's personal artifact library managed under
    ``~/.skillmeat/``.  There is typically one active collection per user.
    Operations map to the ``/api/v1/user-collections`` router.
    """

    @abc.abstractmethod
    def get(
        self,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> CollectionDTO | None:
        """Return the active collection metadata.

        Args:
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.CollectionDTO` when a
            collection exists, ``None`` if none has been initialised.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_id(
        self,
        id: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> CollectionDTO | None:
        """Return a specific collection by its identifier.

        Args:
            id: Collection unique identifier (usually the collection name).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.CollectionDTO` when
            found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list(
        self,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> list[CollectionDTO]:
        """Return all known collections.

        Args:
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.CollectionDTO`
            objects.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_stats(
        self,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> CollectionStatsDTO:
        """Return aggregate statistics for the active collection.

        Args:
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            :class:`~skillmeat.core.interfaces.dtos.CollectionStatsDTO`
            containing ``artifact_count``, ``total_size_bytes``,
            ``last_synced``, and ``collection_root``.  Returns a
            zero-value instance when no active collection exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def refresh(
        self,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> CollectionDTO:
        """Re-scan the filesystem and rebuild the collection cache.

        Args:
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            The refreshed :class:`~skillmeat.core.interfaces.dtos.CollectionDTO`.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_artifacts(
        self,
        collection_id: str,
        filters: dict[str, Any] | None = None,
        offset: int = 0,
        limit: int = 50,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> list[ArtifactDTO]:
        """Return the artifacts that belong to a collection.

        Args:
            collection_id: Collection unique identifier.
            filters: Optional filter constraints (e.g. ``artifact_type``).
            offset: Zero-based pagination offset.
            limit: Maximum number of records to return.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO`
            objects.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Mutations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def create(
        self,
        name: str,
        description: str | None = None,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
        owner_target: OwnerTarget | None = None,
    ) -> CollectionDTO:
        """Create a new collection.

        Args:
            name: Human-readable name for the new collection.  Must be
                unique within the storage backend.
            description: Optional description text.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).
            owner_target: Explicit ownership target for the new collection.
                When provided, the implementation MUST use this instead of
                deriving ownership from ``auth_context`` (e.g. team-owned
                collections).  When ``None``, defaults to user-owned
                (backward-compatible behaviour).

        Returns:
            The created :class:`~skillmeat.core.interfaces.dtos.CollectionDTO`.

        Raises:
            ValueError: If a collection with the same *name* already exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        collection_id: str,
        updates: dict[str, Any],
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> CollectionDTO:
        """Apply a partial update to an existing collection.

        Args:
            collection_id: Collection unique identifier.
            updates: Map of field names to new values (e.g. ``{"name": "new-name"}``).
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            The updated :class:`~skillmeat.core.interfaces.dtos.CollectionDTO`.

        Raises:
            KeyError: If no collection with *collection_id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> None:
        """Delete a collection and remove all its membership records.

        Does not delete artifact files from disk — only removes the
        collection registry entry and associated memberships.

        Args:
            collection_id: Collection unique identifier.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Raises:
            KeyError: If no collection with *collection_id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def add_artifacts(
        self,
        collection_id: str,
        artifact_uuids: list[str],
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> None:
        """Add one or more artifacts to a collection by UUID.

        Idempotent: artifacts already in the collection are silently skipped.

        Args:
            collection_id: Collection unique identifier.
            artifact_uuids: List of stable artifact UUIDs (32-char hex
                strings) to add to the collection.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Raises:
            KeyError: If *collection_id* does not exist.
            ValueError: If any UUID in *artifact_uuids* does not correspond
                to a known artifact.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def remove_artifact(
        self,
        collection_id: str,
        artifact_uuid: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> None:
        """Remove a single artifact from a collection.

        Args:
            collection_id: Collection unique identifier.
            artifact_uuid: Stable artifact UUID (32-char hex) to remove.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Raises:
            KeyError: If *collection_id* does not exist or *artifact_uuid* is
                not a member of the collection.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Entity management within a collection
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_entities(
        self,
        collection_id: str,
        entity_type: str | None = None,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> list[Any]:
        """Return entities belonging to a collection, optionally filtered by type.

        Args:
            collection_id: Collection unique identifier.
            entity_type: Optional entity type string to filter by
                (e.g. ``"workflow"``, ``"dataset"``).  When ``None``, all
                entity types are returned.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Returns:
            List of entity records.  The exact element type is
            implementation-defined; callers should treat them as plain
            dicts or typed DTOs depending on the backend.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def add_entity(
        self,
        collection_id: str,
        entity_type: str,
        entity_id: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> None:
        """Associate an entity with a collection.

        Args:
            collection_id: Collection unique identifier.
            entity_type: Entity type string (e.g. ``"workflow"``).
            entity_id: Unique identifier of the entity to associate.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Raises:
            KeyError: If *collection_id* does not exist.
            ValueError: If *entity_id* does not correspond to a known entity
                of the given *entity_type*.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def remove_entity(
        self,
        collection_id: str,
        entity_type: str,
        entity_id: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> None:
        """Remove an entity association from a collection.

        Args:
            collection_id: Collection unique identifier.
            entity_type: Entity type string (e.g. ``"workflow"``).
            entity_id: Unique identifier of the entity to disassociate.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Raises:
            KeyError: If *collection_id* does not exist or the entity is not
                associated with the collection.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def migrate_to_default(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> None:
        """Migrate a collection's artifacts and entities to the default collection.

        Intended for use when a non-default collection is being retired.
        All member artifacts and entity associations are moved to the active
        default collection; the source collection record is then removed.

        Args:
            collection_id: Collection unique identifier of the source collection
                to migrate away from.
            ctx: Optional per-request metadata.
            auth_context: Optional authentication and authorisation context.
                When ``None`` the operation is performed without tenant
                scoping (local zero-auth mode).

        Raises:
            KeyError: If *collection_id* does not exist.
            ValueError: If *collection_id* refers to the current default
                collection (cannot migrate to itself).
        """
        raise NotImplementedError


# =============================================================================
# IDeploymentRepository
# =============================================================================


class IDeploymentRepository(abc.ABC):
    """Contract for deployment storage backends.

    A deployment represents an artifact that has been installed into a project
    directory.  Operations map to the ``/api/v1/deploy`` router.
    """

    @abc.abstractmethod
    def get(
        self,
        id: str,
        ctx: RequestContext | None = None,
    ) -> DeploymentDTO | None:
        """Return a deployment record by its identifier.

        Args:
            id: Deployment record identifier (often ``"type:name"``).
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.DeploymentDTO` when
            found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list(
        self,
        filters: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> list[DeploymentDTO]:
        """Return deployment records matching optional filter criteria.

        Args:
            filters: Optional filter map.  Recognised keys typically include
                ``project_id``, ``artifact_id``, ``artifact_type``, and
                ``status``.
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.DeploymentDTO`
            objects.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def deploy(
        self,
        artifact_id: str,
        project_id: str,
        options: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> DeploymentDTO:
        """Deploy an artifact from the collection to a project.

        Args:
            artifact_id: Artifact primary key (``"type:name"``).
            project_id: Target project identifier (base64-encoded path).
            options: Optional deployment options such as ``scope``,
                ``dest_path``, ``overwrite``, and ``profile_id``.
            ctx: Optional per-request metadata.

        Returns:
            The created :class:`~skillmeat.core.interfaces.dtos.DeploymentDTO`.

        Raises:
            KeyError: If *artifact_id* or *project_id* does not exist.
            ValueError: If the deployment would result in a conflict and
                *options* does not permit overwrite.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def undeploy(
        self,
        id: str,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Remove a deployed artifact from its project.

        Args:
            id: Deployment record identifier.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` when the deployment was found and removed, ``False``
            otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_status(
        self,
        id: str,
        ctx: RequestContext | None = None,
    ) -> str:
        """Return the current status string for a deployment.

        Args:
            id: Deployment record identifier.
            ctx: Optional per-request metadata.

        Returns:
            Status string (e.g. ``"deployed"``, ``"modified"``,
            ``"outdated"``).

        Raises:
            KeyError: If no deployment with *id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_artifact(
        self,
        identifier: str | uuid.UUID,
        ctx: RequestContext | None = None,
    ) -> list[DeploymentDTO]:
        """Return all active deployments for a given artifact.

        Args:
            identifier: Artifact identity in one of two forms:

                * **UUID** (canonical, preferred) — pass the artifact's stable
                  ``uuid.UUID`` as sourced from ``DeploymentDTO.uuid`` or an
                  artifact's ADR-007 UUID field.  Implementations dispatch on
                  ``isinstance(identifier, uuid.UUID)`` for this path.
                * **``"type:name"`` string** (legacy fallback) — the composite
                  primary-key string retained during the deprecation window.
                  Callers should migrate to UUID form; string support will be
                  removed once the deprecation window closes.

                See ADR-007 for the UUID-keyed reads convention.  The Union
                pattern here follows the precedent set by
                ``EnterpriseArtifactRepository.get()`` in
                ``skillmeat/cache/enterprise_repositories.py``.
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.DeploymentDTO`
            objects (may be empty if the artifact has never been deployed).
        """
        raise NotImplementedError

    @abc.abstractmethod
    def upsert_idp_deployment_set(
        self,
        *,
        remote_url: str,
        name: str,
        provisioned_by: str,
        description: str | None = None,
        bundle_id: str | None = None,
        bundle_version: str | None = None,
        platform: str | None = None,
        requested_by: str | None = None,
        ctx: RequestContext | None = None,
    ) -> tuple[str, bool]:
        """Idempotently create or update a DeploymentSet for an IDP registration.

        Looks up an existing ``DeploymentSet`` by the ``(remote_url, name)``
        pair.  If a match is found the record is updated with the supplied
        fields; otherwise a new record is created.

        Args:
            remote_url: Remote Git repository URL (e.g. the Backstage repo URL).
            name: Artifact target identifier (used as the set name).
            provisioned_by: Audit field identifying the provisioning agent
                (e.g. ``"idp"``).
            description: Optional JSON-serialised metadata string.
            bundle_id: Optional UUID or slug of the associated bundle.
            bundle_version: Optional version string of the associated bundle.
            platform: Optional deployment platform identifier
                (e.g. ``"backstage"``, ``"remote_git"``).
            requested_by: Optional user identity string extracted from the
                ``X-Backstage-User-Entity`` header
                (e.g. ``"user:default/alice"``).  Stored verbatim; truncation
                to 255 chars is the caller's responsibility.
            ctx: Optional per-request metadata.

        Returns:
            A ``(deployment_set_id, created)`` tuple where *created* is
            ``True`` when a new record was inserted and ``False`` when an
            existing record was updated.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def sync_deployment_cache(
        self,
        artifact_id: str,
        project_path: str,
        project_name: str,
        deployed_at: Any,
        content_hash: str | None = None,
        deployment_profile_id: str | None = None,
        local_modifications: bool = False,
        platform: str | None = None,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Upsert a single deployment entry into the artifact cache.

        Performs a write-through update of the ``deployments_json`` column in
        ``collection_artifacts`` so the cache reflects the most-recent
        deployment state without a full cache refresh.

        Args:
            artifact_id: Artifact primary key in ``"type:name"`` format.
            project_path: Absolute filesystem path of the deployment target.
            project_name: Human-readable project directory name.
            deployed_at: Deployment timestamp (``datetime`` or ISO string).
            content_hash: Optional SHA of the deployed content snapshot.
            deployment_profile_id: Optional deployment profile identifier.
            local_modifications: Whether local modifications are present.
            platform: Optional platform identifier string.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` when the cache entry was updated, ``False`` when the
            artifact was not found in the cache (non-fatal).
        """
        raise NotImplementedError

    @abc.abstractmethod
    def remove_deployment_cache(
        self,
        artifact_id: str,
        project_path: str,
        profile_id: str | None = None,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Remove a deployment entry from the artifact cache.

        Performs a write-through removal of the matching entry from the
        ``deployments_json`` column in ``collection_artifacts`` so the cache
        reflects the current deployment state without a full cache refresh.

        Args:
            artifact_id: Artifact primary key in ``"type:name"`` format.
            project_path: Absolute filesystem path of the deployment target.
            profile_id: Optional profile ID to narrow the removal to a
                specific deployment profile entry.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` when the cache entry was updated, ``False`` when the
            artifact was not found in the cache (non-fatal).
        """
        raise NotImplementedError


# =============================================================================
# ITagRepository
# =============================================================================


class ITagRepository(abc.ABC):
    """Contract for tag storage backends.

    Tags are workspace-scoped labels that can be assigned to one or more
    artifacts.  Operations map to the ``/api/v1/tags`` router and the
    tag-association sub-resources on ``/api/v1/artifacts``.
    """

    @abc.abstractmethod
    def get(
        self,
        id: str,
        ctx: RequestContext | None = None,
    ) -> TagDTO | None:
        """Return a tag by its identifier.

        Args:
            id: Tag unique identifier.
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.TagDTO` when found,
            ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_slug(
        self,
        slug: str,
        ctx: RequestContext | None = None,
    ) -> TagDTO | None:
        """Return a tag by its URL-friendly slug.

        Args:
            slug: Kebab-case slug string.
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.TagDTO` when found,
            ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list(
        self,
        filters: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> list[TagDTO]:
        """Return all tags.

        Args:
            filters: Optional filter map (e.g. ``{"name": "ai"}`` for
                prefix/search filtering).
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.TagDTO` objects.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create(
        self,
        name: str,
        color: str | None = None,
        ctx: RequestContext | None = None,
    ) -> TagDTO:
        """Create a new tag.

        The slug is automatically derived from *name* by the implementation.

        Args:
            name: Human-readable tag name (must be unique).
            color: Optional hex color code (e.g. ``"#FF5733"``).
            ctx: Optional per-request metadata.

        Returns:
            The created :class:`~skillmeat.core.interfaces.dtos.TagDTO`.

        Raises:
            ValueError: If a tag with the same name (or derived slug) already
                exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        id: str,
        updates: dict[str, Any],
        ctx: RequestContext | None = None,
    ) -> TagDTO:
        """Apply a partial update to an existing tag.

        Args:
            id: Tag unique identifier.
            updates: Map of field names to new values (e.g. ``{"color": "#00FF00"}``).
            ctx: Optional per-request metadata.

        Returns:
            The updated :class:`~skillmeat.core.interfaces.dtos.TagDTO`.

        Raises:
            KeyError: If no tag with *id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(
        self,
        id: str,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Delete a tag and remove all its artifact associations.

        Args:
            id: Tag unique identifier.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` when the tag was found and deleted, ``False`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def assign(
        self,
        tag_id: str,
        artifact_id: str,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Associate a tag with an artifact.

        Idempotent: calling this when the association already exists is
        a no-op and returns ``True``.

        Args:
            tag_id: Tag unique identifier.
            artifact_id: Artifact primary key (``"type:name"``).
            ctx: Optional per-request metadata.

        Returns:
            ``True`` on success.

        Raises:
            KeyError: If *tag_id* or *artifact_id* does not exist.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def unassign(
        self,
        tag_id: str,
        artifact_id: str,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Remove the association between a tag and an artifact.

        Args:
            tag_id: Tag unique identifier.
            artifact_id: Artifact primary key (``"type:name"``).
            ctx: Optional per-request metadata.

        Returns:
            ``True`` when the association existed and was removed, ``False``
            if there was no such association.
        """
        raise NotImplementedError


# =============================================================================
# ISettingsRepository
# =============================================================================


class ISettingsRepository(abc.ABC):
    """Contract for application settings storage backends.

    Settings are a single, user-scoped configuration record.  Operations map
    to the ``/api/v1/settings`` router.
    """

    @abc.abstractmethod
    def get(
        self,
        ctx: RequestContext | None = None,
    ) -> SettingsDTO:
        """Return the current application settings snapshot.

        Args:
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.SettingsDTO` populated
            with the current configuration values.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        updates: dict[str, Any],
        ctx: RequestContext | None = None,
    ) -> SettingsDTO:
        """Apply a partial update to the application settings.

        Only provided keys are changed; unmentioned settings remain at their
        current values.

        Args:
            updates: Map of setting keys to new values.  Recognised keys
                mirror :class:`~skillmeat.core.interfaces.dtos.SettingsDTO`
                fields: ``github_token``, ``collection_path``,
                ``default_scope``, ``edition``, ``indexing_mode``.
                Additional keys are stored in ``extra``.
            ctx: Optional per-request metadata.

        Returns:
            The updated :class:`~skillmeat.core.interfaces.dtos.SettingsDTO`.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def validate_github_token(
        self,
        token: str,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Validate a GitHub Personal Access Token against the API.

        Args:
            token: Raw GitHub PAT string.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` if the token is valid and authenticated, ``False``
            otherwise.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Entity type configuration
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_entity_type_configs(
        self,
        ctx: RequestContext | None = None,
    ) -> list[EntityTypeConfigDTO]:
        """Return all registered entity type configurations.

        Args:
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.EntityTypeConfigDTO`
            objects, including both system-defined and user-created entries.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create_entity_type_config(
        self,
        entity_type: str,
        display_name: str,
        description: str | None = None,
        icon: str | None = None,
        color: str | None = None,
        ctx: RequestContext | None = None,
    ) -> EntityTypeConfigDTO:
        """Create a new user-defined entity type configuration.

        Args:
            entity_type: Machine-readable entity type key
                (e.g. ``"workflow"``).  Must be unique.
            display_name: Human-readable display name.
            description: Optional description of this entity type.
            icon: Optional icon identifier or URL.
            color: Optional hex color code (e.g. ``"#FF5733"``).
            ctx: Optional per-request metadata.

        Returns:
            The created :class:`~skillmeat.core.interfaces.dtos.EntityTypeConfigDTO`.

        Raises:
            ValueError: If an entity type config with the same *entity_type*
                already exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_entity_type_config(
        self,
        config_id: str,
        updates: dict[str, Any],
        ctx: RequestContext | None = None,
    ) -> EntityTypeConfigDTO:
        """Apply a partial update to an existing entity type configuration.

        Args:
            config_id: Unique identifier of the entity type config record.
            updates: Map of field names to new values.  Recognised keys
                mirror :class:`~skillmeat.core.interfaces.dtos.EntityTypeConfigDTO`
                fields: ``display_name``, ``description``, ``icon``,
                ``color``.  The ``entity_type`` and ``is_system`` fields
                are immutable after creation.
            ctx: Optional per-request metadata.

        Returns:
            The updated :class:`~skillmeat.core.interfaces.dtos.EntityTypeConfigDTO`.

        Raises:
            KeyError: If no config with *config_id* exists.
            ValueError: If the update attempts to mutate an immutable field.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete_entity_type_config(
        self,
        config_id: str,
        ctx: RequestContext | None = None,
    ) -> None:
        """Delete a user-defined entity type configuration.

        System-defined entity type configs (``is_system=True``) cannot be
        deleted.

        Args:
            config_id: Unique identifier of the entity type config record.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If no config with *config_id* exists.
            ValueError: If the config is system-defined.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Category management
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_categories(
        self,
        entity_type: str | None = None,
        platform: str | None = None,
        ctx: RequestContext | None = None,
    ) -> list[CategoryDTO]:
        """Return all categories, optionally filtered by entity type and platform.

        Args:
            entity_type: When provided, return only categories scoped to this
                entity type.  When omitted, all categories are returned.
            platform: When provided, return only categories scoped to this
                platform.
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.CategoryDTO`
            objects ordered by sort_order.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create_category(
        self,
        name: str,
        slug: str | None = None,
        entity_type: str | None = None,
        description: str | None = None,
        color: str | None = None,
        platform: str | None = None,
        sort_order: int | None = None,
        ctx: RequestContext | None = None,
    ) -> CategoryDTO:
        """Create a new category.

        Args:
            name: Human-readable category name.
            slug: Optional URL-safe slug; auto-generated from *name* when
                omitted.
            entity_type: Optional entity type this category applies to.
                Pass ``None`` for a cross-type (universal) category.
            description: Optional description text.
            color: Optional hex color code for UI display (e.g. ``"#00FF00"``).
            platform: Optional platform scope filter.
            sort_order: Optional explicit display order; auto-computed when
                omitted.
            ctx: Optional per-request metadata.

        Returns:
            The created :class:`~skillmeat.core.interfaces.dtos.CategoryDTO`.

        Raises:
            ValueError: If a category with the same resolved slug already
                exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_category(
        self,
        category_id: int,
        updates: dict[str, Any],
        ctx: RequestContext | None = None,
    ) -> CategoryDTO:
        """Apply a partial update to an existing category.

        Args:
            category_id: Integer primary key of the category to update.
            updates: Map of field names to new values.
            ctx: Optional per-request metadata.

        Returns:
            The updated :class:`~skillmeat.core.interfaces.dtos.CategoryDTO`.

        Raises:
            KeyError: If no category with *category_id* exists.
            ValueError: If the requested new slug is already taken.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete_category(
        self,
        category_id: int,
        ctx: RequestContext | None = None,
    ) -> None:
        """Delete a category by integer primary key.

        Args:
            category_id: Integer primary key of the category to delete.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If no category with *category_id* exists.
            ValueError: If the category has artifact associations.
        """
        raise NotImplementedError


# =============================================================================
# IGroupRepository
# =============================================================================


class IGroupRepository(abc.ABC):
    """Contract for group storage backends.

    Groups let users organise artifacts within a collection into named,
    position-ordered buckets.  Operations map to the ``/api/v1/groups``
    router.
    """

    # ------------------------------------------------------------------
    # Single-item lookup
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_with_artifacts(
        self,
        group_id: int,
        ctx: RequestContext | None = None,
    ) -> GroupDTO | None:
        """Return a group by ID, including its artifact membership list.

        Args:
            group_id: Integer primary key of the group.
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.GroupDTO` when the
            group exists (with ``artifact_count`` populated), ``None``
            otherwise.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Collection queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list(
        self,
        collection_id: str,
        filters: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> list[GroupDTO]:
        """Return all groups belonging to a collection.

        Args:
            collection_id: Collection unique identifier.
            filters: Optional additional filter map (e.g. ``{"name": "…"}``).
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.GroupDTO` objects
            ordered by ``position`` ascending.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Mutations — groups
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def create(
        self,
        name: str,
        collection_id: str,
        description: str | None = None,
        position: int | None = None,
        ctx: RequestContext | None = None,
        owner_target: OwnerTarget | None = None,
    ) -> GroupDTO:
        """Create a new group in the given collection.

        Args:
            name: Human-readable group name (must be unique within the
                collection).
            collection_id: Owning collection identifier.
            description: Optional group description.
            position: Explicit display position.  When ``None`` the
                implementation appends the group at the end.
            ctx: Optional per-request metadata.
            owner_target: Explicit ownership target for the new group.
                When provided, the implementation MUST use this instead of
                deriving ownership from request context (e.g. team-owned
                groups).  When ``None``, defaults to user-owned
                (backward-compatible behaviour).

        Returns:
            The created :class:`~skillmeat.core.interfaces.dtos.GroupDTO`.

        Raises:
            ValueError: If a group with the same *name* already exists in
                *collection_id*.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        group_id: int,
        updates: dict[str, Any],
        ctx: RequestContext | None = None,
    ) -> GroupDTO:
        """Apply a partial update to an existing group's metadata.

        Args:
            group_id: Integer primary key of the group.
            updates: Map of field names to new values (e.g. ``{"name": "…",
                "description": "…"}``).
            ctx: Optional per-request metadata.

        Returns:
            The updated :class:`~skillmeat.core.interfaces.dtos.GroupDTO`.

        Raises:
            KeyError: If no group with *group_id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(
        self,
        group_id: int,
        ctx: RequestContext | None = None,
    ) -> None:
        """Delete a group and all its artifact membership records.

        Args:
            group_id: Integer primary key of the group.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If no group with *group_id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def copy_to_collection(
        self,
        group_id: int,
        target_collection_id: str,
        ctx: RequestContext | None = None,
    ) -> GroupDTO:
        """Duplicate a group (and its artifact memberships) into another collection.

        Artifact UUIDs are preserved; positions are reset to match the source
        group.

        Args:
            group_id: Integer primary key of the source group.
            target_collection_id: Identifier of the destination collection.
            ctx: Optional per-request metadata.

        Returns:
            The newly created :class:`~skillmeat.core.interfaces.dtos.GroupDTO`
            in the target collection.

        Raises:
            KeyError: If *group_id* or *target_collection_id* does not exist.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def reorder_groups(
        self,
        collection_id: str,
        ordered_ids: list[int],
        ctx: RequestContext | None = None,
    ) -> None:
        """Bulk-update the display positions of all groups in a collection.

        The ``position`` of each group is set to its zero-based index in
        *ordered_ids*.

        Args:
            collection_id: Collection unique identifier.
            ordered_ids: Complete list of group primary keys in the desired
                display order.  Must include all groups in the collection.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If *collection_id* does not exist.
            ValueError: If *ordered_ids* does not contain every group in the
                collection.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Mutations — artifact membership
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def add_artifacts(
        self,
        group_id: int,
        artifact_uuids: list[str],
        ctx: RequestContext | None = None,
    ) -> None:
        """Add one or more artifacts to a group.

        Artifacts already present in the group are silently skipped.  Newly
        added artifacts are appended after existing members.

        Args:
            group_id: Integer primary key of the target group.
            artifact_uuids: List of stable artifact UUIDs to add.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If *group_id* does not exist.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def remove_artifact(
        self,
        group_id: int,
        artifact_uuid: str,
        ctx: RequestContext | None = None,
    ) -> None:
        """Remove a single artifact from a group.

        Args:
            group_id: Integer primary key of the group.
            artifact_uuid: Stable artifact UUID to remove.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If *group_id* does not exist or *artifact_uuid* is not
                a member of the group.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_artifact_position(
        self,
        group_id: int,
        artifact_uuid: str,
        position: int,
        ctx: RequestContext | None = None,
    ) -> None:
        """Update the display position of a single artifact within a group.

        Args:
            group_id: Integer primary key of the group.
            artifact_uuid: Stable artifact UUID whose position to update.
            position: New zero-based display position.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If *group_id* does not exist or *artifact_uuid* is not
                a member of the group.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def reorder_artifacts(
        self,
        group_id: int,
        ordered_uuids: list[str],
        ctx: RequestContext | None = None,
    ) -> None:
        """Bulk-update the display positions of all artifacts in a group.

        The ``position`` of each membership record is set to the artifact's
        zero-based index in *ordered_uuids*.

        Args:
            group_id: Integer primary key of the group.
            ordered_uuids: Complete list of artifact UUIDs in the desired
                display order.  Must include all current members.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If *group_id* does not exist.
            ValueError: If *ordered_uuids* does not cover all current members.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_group_artifacts(
        self,
        group_id: str,
        ctx: RequestContext | None = None,
    ) -> list[GroupArtifactDTO]:
        """Return the ordered list of artifact membership records for a group.

        Args:
            group_id: Group primary key string.
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.GroupArtifactDTO`
            objects ordered by ``position`` ascending.  Returns an empty list
            when the group does not exist or has no members.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def add_artifacts_at_position(
        self,
        group_id: str,
        artifact_uuids: list[str],
        position: int,
        ctx: RequestContext | None = None,
    ) -> None:
        """Insert artifacts at a specific position within a group.

        Existing artifacts at or after *position* are shifted down to
        accommodate the new insertions.  Artifacts already in the group
        are silently skipped (deduplicated).

        Args:
            group_id: Group primary key string.
            artifact_uuids: Ordered list of artifact UUIDs to insert.
            position: Zero-based target position for the first inserted artifact.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If *group_id* does not exist.
            RuntimeError: On unexpected database errors.
        """
        raise NotImplementedError


# =============================================================================
# IContextEntityRepository
# =============================================================================


class IContextEntityRepository(abc.ABC):
    """Contract for context entity storage backends.

    Context entities are special artifacts (CLAUDE.md, spec files, rule files,
    context files, and progress templates) that define project structure and
    context for Claude Code projects.  Operations map to the
    ``/api/v1/context-entities`` router.
    """

    # ------------------------------------------------------------------
    # Collection queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list(
        self,
        filters: dict[str, Any] | None = None,
        limit: int = 20,
        after: str | None = None,
        ctx: RequestContext | None = None,
    ) -> list[ContextEntityDTO]:
        """Return a page of context entities matching optional filter criteria.

        Filters may include ``entity_type``, ``category``, ``auto_load``,
        ``search`` (full-text across name, description, path_pattern), and
        ``context_module_id`` (exact match on the module association).

        Args:
            filters: Optional key/value filter map.
            limit: Maximum number of records to return (1-100).
            after: Opaque cursor value for the next page (base64-encoded ID).
            ctx: Optional per-request metadata.

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.ContextEntityDTO` objects.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Single-item lookup
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get(
        self,
        entity_id: str,
        ctx: RequestContext | None = None,
    ) -> ContextEntityDTO | None:
        """Return a context entity by its identifier.

        Args:
            entity_id: Artifact primary key (e.g. ``"ctx_abc123"``).
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.ContextEntityDTO` when
            found, ``None`` otherwise.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Mutations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def create(
        self,
        name: str,
        entity_type: str,
        content: str,
        path_pattern: str,
        description: str | None = None,
        category: str | None = None,
        auto_load: bool = False,
        version: str | None = None,
        target_platforms: list[str] | None = None,
        category_ids: list[int] | None = None,
        ctx: RequestContext | None = None,
    ) -> ContextEntityDTO:
        """Persist a new context entity and return the stored representation.

        Args:
            name: Human-readable entity name.
            entity_type: Entity type key (``"project_config"``,
                ``"spec_file"``, ``"rule_file"``, ``"context_file"``,
                ``"progress_template"``).
            content: Assembled markdown content.
            path_pattern: Target deployment path (must start with
                ``".claude/"`` or a supported prefix).
            description: Optional description.
            category: Optional category label (e.g. ``"api"``).
            auto_load: Whether to auto-load the entity on platform startup.
            version: Optional version string.
            target_platforms: Optional list of platform identifiers to
                target on deploy.
            category_ids: Ordered list of category IDs to associate.
            ctx: Optional per-request metadata.

        Returns:
            The persisted
            :class:`~skillmeat.core.interfaces.dtos.ContextEntityDTO`.

        Raises:
            ValueError: If *path_pattern* is invalid or *entity_type* is
                unrecognised.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        entity_id: str,
        updates: dict[str, Any],
        ctx: RequestContext | None = None,
    ) -> ContextEntityDTO:
        """Apply a partial update to an existing context entity.

        Args:
            entity_id: Artifact primary key.
            updates: Map of field names to new values.  Supported keys mirror
                :class:`~skillmeat.core.interfaces.dtos.ContextEntityDTO`
                fields (``name``, ``entity_type``, ``content``,
                ``path_pattern``, ``description``, ``category``,
                ``auto_load``, ``version``, ``target_platforms``,
                ``category_ids``).
            ctx: Optional per-request metadata.

        Returns:
            The updated
            :class:`~skillmeat.core.interfaces.dtos.ContextEntityDTO`.

        Raises:
            KeyError: If no entity with *entity_id* exists.
            ValueError: If *updates* contains invalid field values.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(
        self,
        entity_id: str,
        ctx: RequestContext | None = None,
    ) -> None:
        """Delete a context entity permanently.

        Args:
            entity_id: Artifact primary key.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If no entity with *entity_id* exists.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Deployment
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def deploy(
        self,
        entity_id: str,
        project_path: str,
        options: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> None:
        """Deploy a context entity's content to a filesystem project path.

        Writes the assembled content to the location specified by the entity's
        ``path_pattern``, resolved against *project_path*.

        Args:
            entity_id: Artifact primary key.
            project_path: Absolute filesystem path to the target project
                directory.
            options: Optional deployment options such as ``overwrite``,
                ``deployment_profile_id``, and ``all_profiles``.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If *entity_id* does not exist.
            FileExistsError: If the target file already exists and
                ``options["overwrite"]`` is ``False``.
            ValueError: If *project_path* does not exist or *entity_id* has
                no ``path_pattern``.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Content access
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_content(
        self,
        entity_id: str,
        ctx: RequestContext | None = None,
    ) -> str | None:
        """Return the raw markdown content of a context entity.

        Args:
            entity_id: Artifact primary key.
            ctx: Optional per-request metadata.

        Returns:
            Raw content string when the entity exists, ``None`` otherwise.
        """
        raise NotImplementedError


# =============================================================================
# IMarketplaceSourceRepository
# =============================================================================


class IMarketplaceSourceRepository(abc.ABC):
    """Contract for marketplace broker/source configuration backends.

    A marketplace source is a configured endpoint (broker) that provides
    artifact listings for installation.  This interface covers both source
    configuration management and the catalog operations delegated to each
    broker.  Operations map to ``/api/v1/marketplace-sources`` and the
    primary ``/api/v1/marketplace`` router.
    """

    # ------------------------------------------------------------------
    # Source CRUD
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_sources(
        self,
        filters: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> list[MarketplaceSourceDTO]:
        """Return all configured marketplace sources.

        Args:
            filters: Optional filter map (e.g. ``{"enabled": True}``).
            ctx: Optional per-request metadata.

        Returns:
            List of
            :class:`~skillmeat.core.interfaces.dtos.MarketplaceSourceDTO`
            objects.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_source(
        self,
        source_id: str,
        ctx: RequestContext | None = None,
    ) -> MarketplaceSourceDTO | None:
        """Return a marketplace source by its identifier.

        Args:
            source_id: Source unique identifier (broker name).
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.MarketplaceSourceDTO`
            when found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create_source(
        self,
        name: str,
        endpoint: str,
        enabled: bool = True,
        description: str | None = None,
        supports_publish: bool = False,
        ctx: RequestContext | None = None,
    ) -> MarketplaceSourceDTO:
        """Register a new marketplace source.

        Args:
            name: Human-readable source name (must be unique).
            endpoint: Base URL for the broker API.
            enabled: Whether to activate the source immediately.
            description: Optional description of this source.
            supports_publish: Whether the source allows publishing.
            ctx: Optional per-request metadata.

        Returns:
            The created
            :class:`~skillmeat.core.interfaces.dtos.MarketplaceSourceDTO`.

        Raises:
            ValueError: If a source with the same *name* already exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_source(
        self,
        source_id: str,
        updates: dict[str, Any],
        ctx: RequestContext | None = None,
    ) -> MarketplaceSourceDTO:
        """Apply a partial update to a marketplace source configuration.

        Args:
            source_id: Source unique identifier.
            updates: Map of field names to new values (``enabled``,
                ``endpoint``, ``description``, ``supports_publish``).
            ctx: Optional per-request metadata.

        Returns:
            The updated
            :class:`~skillmeat.core.interfaces.dtos.MarketplaceSourceDTO`.

        Raises:
            KeyError: If no source with *source_id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete_source(
        self,
        source_id: str,
        ctx: RequestContext | None = None,
    ) -> None:
        """Remove a marketplace source configuration.

        Args:
            source_id: Source unique identifier.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If no source with *source_id* exists.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Catalog operations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_catalog_items(
        self,
        source_id: str | None = None,
        filters: dict[str, Any] | None = None,
        page: int = 1,
        limit: int = 50,
        ctx: RequestContext | None = None,
    ) -> list[CatalogItemDTO]:
        """Return paginated catalog listings from one or all sources.

        Filters may include ``query`` (search term), ``tags``
        (``list[str]``), ``license``, and ``publisher``.

        Args:
            source_id: When provided, restrict results to this broker.
                When ``None``, aggregate listings from all enabled sources.
            filters: Optional key/value filter map.
            page: One-based page number for pagination.
            limit: Maximum number of items per page (1-100).
            ctx: Optional per-request metadata.

        Returns:
            List of
            :class:`~skillmeat.core.interfaces.dtos.CatalogItemDTO` objects.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def import_item(
        self,
        listing_id: str,
        source_id: str | None = None,
        strategy: str = "keep",
        ctx: RequestContext | None = None,
    ) -> list[ArtifactDTO]:
        """Download and import a marketplace listing into the local collection.

        Args:
            listing_id: Unique identifier of the listing within its broker.
            source_id: Optional broker identifier.  When ``None`` the
                implementation auto-detects the broker that owns this listing.
            strategy: Conflict resolution strategy (``"keep"``, ``"replace"``,
                or ``"fork"``).
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO`
            objects representing all imported artifacts.

        Raises:
            KeyError: If *listing_id* is not found in any enabled source.
            ValueError: If *strategy* is not a recognised value.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_composite_members(
        self,
        composite_id: str,
        ctx: RequestContext | None = None,
    ) -> list[ArtifactDTO]:
        """Return the child artifacts that make up a composite listing.

        Args:
            composite_id: Artifact primary key of the composite artifact
                (``"composite:<name>"``).
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO`
            objects for each member artifact, ordered by ``position``.

        Raises:
            KeyError: If *composite_id* does not exist or is not a composite
                artifact.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Catalog entry mutations (encapsulate direct session access)
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_catalog_entry(
        self,
        entry_id: str,
        source_id: str | None = None,
        ctx: RequestContext | None = None,
    ) -> CatalogEntryDTO | None:
        """Return a typed DTO for a catalog entry.

        Args:
            entry_id: Catalog entry primary key.
            source_id: When provided, verify that the entry belongs to this
                source; returns ``None`` otherwise.
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.CatalogEntryDTO` when
            found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_catalog_entry_exclusion(
        self,
        entry_id: str,
        source_id: str,
        excluded: bool,
        reason: str | None = None,
        ctx: RequestContext | None = None,
    ) -> CatalogEntryDTO:
        """Toggle the exclusion status of a catalog entry.

        When *excluded* is ``True`` the entry is stamped with ``excluded_at``
        and ``excluded_reason`` and its ``status`` is set to ``"excluded"``.
        When *excluded* is ``False`` the exclusion fields are cleared and
        ``status`` is restored to ``"new"`` or ``"imported"`` depending on
        whether the entry was previously imported.

        Args:
            entry_id: Catalog entry primary key.
            source_id: Source the entry must belong to.
            excluded: ``True`` to exclude, ``False`` to restore.
            reason: Optional reason for the exclusion (ignored when restoring).
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.CatalogEntryDTO` for the
            updated entry.

        Raises:
            KeyError: If *entry_id* is not found or does not belong to
                *source_id*.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_catalog_entry_path_tags(
        self,
        entry_id: str,
        source_id: str,
        path_segments_json: str,
        ctx: RequestContext | None = None,
    ) -> CatalogEntryDTO:
        """Persist updated ``path_segments`` JSON for a catalog entry.

        Args:
            entry_id: Catalog entry primary key.
            source_id: Source the entry must belong to.
            path_segments_json: Serialised JSON string for the
                ``path_segments`` column.
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.CatalogEntryDTO` for the
            updated entry.

        Raises:
            KeyError: If *entry_id* is not found or does not belong to
                *source_id*.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def upsert_composite_memberships(
        self,
        composite_id: str,
        child_artifact_ids: list[str],
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> int:
        """Create or update ``CompositeMembership`` rows for a composite artifact.

        For each child artifact ID the method resolves the ``Artifact.uuid``
        and inserts a ``CompositeMembership`` row if one does not already exist.
        Existing rows are updated to reflect the current position.

        Args:
            composite_id: Primary key of the composite artifact
                (``"composite:<name>"``).
            child_artifact_ids: Ordered list of child ``type:name`` artifact
                primary keys.
            collection_id: Collection the composite belongs to.
            ctx: Optional per-request metadata.

        Returns:
            Number of new membership rows created.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def commit_source_session(
        self,
        ctx: RequestContext | None = None,
    ) -> None:
        """Flush pending changes on the source repository session.

        Convenience wrapper used when mutations have been applied directly to
        ORM objects retrieved via the source repository's own session and those
        changes must be persisted without opening a new transaction.

        Args:
            ctx: Optional per-request metadata.
        """
        raise NotImplementedError


# =============================================================================
# IProjectTemplateRepository
# =============================================================================


class IProjectTemplateRepository(abc.ABC):
    """Contract for project template storage backends.

    Project templates are reusable collections of context entities that can
    be deployed together to initialise Claude Code project structures.
    Templates support variable substitution for customisation.  Operations
    map to the ``/api/v1/project-templates`` router.
    """

    # ------------------------------------------------------------------
    # Collection queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list(
        self,
        filters: dict[str, Any] | None = None,
        limit: int = 50,
        offset: int = 0,
        ctx: RequestContext | None = None,
    ) -> list[ProjectTemplateDTO]:
        """Return a page of project templates.

        Args:
            filters: Optional key/value filter map (e.g.
                ``{"collection_id": "default"}``).
            limit: Maximum number of records to return (1-100).
            offset: Zero-based record offset for pagination.
            ctx: Optional per-request metadata.

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.ProjectTemplateDTO`
            objects ordered by ``created_at`` descending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def count(
        self,
        filters: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> int:
        """Return the total number of project templates matching optional filters.

        Args:
            filters: Optional key/value filter map (same keys as :meth:`list`).
            ctx: Optional per-request metadata.

        Returns:
            Integer count of matching project templates.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Single-item lookup
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get(
        self,
        template_id: str,
        ctx: RequestContext | None = None,
    ) -> ProjectTemplateDTO | None:
        """Return a project template by its identifier, including full entity details.

        Args:
            template_id: Template hex-UUID identifier.
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.ProjectTemplateDTO`
            (with ``entities`` populated) when found, ``None`` otherwise.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Mutations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def create(
        self,
        name: str,
        entity_ids: list[str],
        description: str | None = None,
        collection_id: str | None = None,
        default_project_config_id: str | None = None,
        ctx: RequestContext | None = None,
    ) -> ProjectTemplateDTO:
        """Create a new project template from an ordered list of entity IDs.

        Args:
            name: Human-readable template name (must be unique).
            entity_ids: Ordered list of artifact primary keys to include.
                The deploy order is derived from the list order.
            description: Optional template description.
            collection_id: Optional owning collection identifier.
            default_project_config_id: Optional artifact ID of the default
                CLAUDE.md config to include.
            ctx: Optional per-request metadata.

        Returns:
            The created
            :class:`~skillmeat.core.interfaces.dtos.ProjectTemplateDTO`
            with full entity details.

        Raises:
            ValueError: If any element of *entity_ids* does not correspond
                to a known artifact.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        template_id: str,
        updates: dict[str, Any],
        ctx: RequestContext | None = None,
    ) -> ProjectTemplateDTO:
        """Apply a partial update to an existing project template.

        Supported update keys: ``name``, ``description``, ``entity_ids``
        (full replacement of the entity list).

        Args:
            template_id: Template hex-UUID identifier.
            updates: Map of field names to new values.
            ctx: Optional per-request metadata.

        Returns:
            The updated
            :class:`~skillmeat.core.interfaces.dtos.ProjectTemplateDTO`.

        Raises:
            KeyError: If no template with *template_id* exists.
            ValueError: If ``entity_ids`` contains unknown artifact IDs.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(
        self,
        template_id: str,
        ctx: RequestContext | None = None,
    ) -> None:
        """Delete a project template and all its entity associations.

        Args:
            template_id: Template hex-UUID identifier.
            ctx: Optional per-request metadata.

        Raises:
            KeyError: If no template with *template_id* exists.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Deployment
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def deploy(
        self,
        template_id: str,
        project_path: str,
        options: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
        auth_context: AuthContext | None = None,
    ) -> TemplateDeployResultDTO:
        """Deploy all template entities to a target project directory.

        Performs variable substitution (if ``options["variables"]`` is
        provided) and writes each entity's content to the path resolved
        from ``path_pattern`` relative to *project_path*.

        Args:
            template_id: Template hex-UUID identifier.
            project_path: Absolute filesystem path to the target project
                directory.
            options: Optional deployment options, including:
                - ``variables`` (``dict[str, str]``): substitution variables,
                - ``selected_entity_ids`` (``list[str]``): subset of entities
                  to deploy (default: all),
                - ``overwrite`` (``bool``): overwrite existing files
                  (default: ``False``),
                - ``deployment_profile_id`` (``str``): profile to use.
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.TemplateDeployResultDTO`
            with ``success``, ``project_path``, ``deployed_files``,
            ``skipped_files``, and ``message`` fields.

        Raises:
            KeyError: If *template_id* does not exist.
            ValueError: If *project_path* does not exist or is invalid.
        """
        raise NotImplementedError


# =============================================================================
# IDbCollectionArtifactRepository
# =============================================================================


class IDbCollectionArtifactRepository(abc.ABC):
    """Repository ABC for DB-backed collection artifact membership.

    Covers the :class:`~skillmeat.cache.models.CollectionArtifact` ORM join
    table that tracks which artifacts belong to which user collections.
    All operations are scoped to a *collection_id* and operate on
    ``artifact_uuid`` stable identifiers (ADR-007).

    Operations map to the artifact-membership sub-resources of the
    ``/api/v1/user-collections`` router.
    """

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_by_collection(
        self,
        collection_id: str,
        *,
        limit: int = 50,
        offset: int = 0,
        search: str | None = None,
        artifact_type: str | None = None,
        ctx: RequestContext | None = None,
    ) -> list[CollectionArtifactDTO]:
        """Return a paginated list of artifact memberships for a collection.

        Args:
            collection_id: Unique identifier of the owning user collection.
            limit: Maximum number of records to return (default 50).
            offset: Zero-based pagination offset (default 0).
            search: Optional free-text search applied to artifact name or
                description fields.
            artifact_type: Optional artifact type filter
                (e.g. ``"skill"``, ``"command"``).
            ctx: Optional per-request metadata.

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.CollectionArtifactDTO`
            objects.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_pk(
        self,
        collection_id: str,
        artifact_uuid: str,
        ctx: RequestContext | None = None,
    ) -> CollectionArtifactDTO | None:
        """Return a single membership record by composite primary key.

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_uuid: Stable 32-char hex UUID of the artifact.
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.CollectionArtifactDTO`
            when the membership exists, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def count_by_collection(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> int:
        """Return the total number of artifacts in a collection.

        Intended to back ``page_info.total`` in paginated list responses.

        Args:
            collection_id: Unique identifier of the user collection.
            ctx: Optional per-request metadata.

        Returns:
            Non-negative integer count of collection memberships.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_with_tags(
        self,
        collection_id: str,
        *,
        tag: str | None = None,
        ctx: RequestContext | None = None,
    ) -> list[CollectionArtifactDTO]:
        """Return collection artifact memberships, optionally filtered by tag.

        Args:
            collection_id: Unique identifier of the user collection.
            tag: Optional tag name to filter by.  When provided, only
                memberships whose artifact carries this tag are returned.
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.CollectionArtifactDTO`
            objects (possibly empty).
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_deployment_info(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> list[CollectionArtifactDTO]:
        """Return collection memberships enriched with deployment tracking data.

        The returned DTOs include ``source``, ``origin``, ``resolved_sha``,
        ``resolved_version``, and ``synced_at`` fields where available.

        Args:
            collection_id: Unique identifier of the user collection.
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.CollectionArtifactDTO`
            objects with deployment fields populated.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_source_deployments_batch(
        self,
        artifact_ids: list[str],
        ctx: RequestContext | None = None,
    ) -> list[SourceDeploymentEntryDTO]:
        """Return source and deployments_json for a batch of artifact IDs.

        Executes a single JOIN query against the ``artifacts`` and
        ``collection_artifacts`` tables to retrieve the ``source`` and
        ``deployments_json`` columns for the given ``type:name`` artifact
        identifiers.

        Args:
            artifact_ids: List of ``"type:name"`` artifact identifier strings.
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.SourceDeploymentEntryDTO`
            instances, one per artifact that has a matching ``CollectionArtifact``
            row.  Only artifacts with a matching row are included in the result.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Mutations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def add_artifacts(
        self,
        collection_id: str,
        artifact_uuids: list[str],
        ctx: RequestContext | None = None,
    ) -> list[CollectionArtifactDTO]:
        """Add one or more artifacts to a collection by UUID.

        Idempotent: artifacts already present in the collection are
        silently skipped rather than duplicated.

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_uuids: List of stable 32-char hex UUIDs to add.
            ctx: Optional per-request metadata.

        Returns:
            List of created (or pre-existing)
            :class:`~skillmeat.core.interfaces.dtos.CollectionArtifactDTO`
            records for the given UUIDs.

        Raises:
            KeyError: If *collection_id* does not correspond to a known
                user collection.
            ValueError: If any UUID in *artifact_uuids* is unknown.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def remove_artifact(
        self,
        collection_id: str,
        artifact_uuid: str,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Remove a single artifact from a collection.

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_uuid: Stable 32-char hex UUID of the artifact to remove.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` when the membership was found and removed,
            ``False`` when no matching membership existed.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def upsert_metadata(
        self,
        collection_id: str,
        artifact_uuid: str,
        ctx: RequestContext | None = None,
        **metadata: Any,
    ) -> CollectionArtifactDTO:
        """Create or update arbitrary metadata fields on a membership record.

        If the membership does not yet exist it is created with the supplied
        metadata.  If it already exists, only the provided fields are updated
        (partial update semantics).

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_uuid: Stable 32-char hex UUID of the artifact.
            ctx: Optional per-request metadata.
            **metadata: Keyword arguments corresponding to writable fields
                on :class:`~skillmeat.core.interfaces.dtos.CollectionArtifactDTO`
                (e.g. ``description``, ``notes``, ``custom_tags``).

        Returns:
            The updated
            :class:`~skillmeat.core.interfaces.dtos.CollectionArtifactDTO`.

        Raises:
            ValueError: If any key in *metadata* is not a recognised field.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_source_tracking(
        self,
        collection_id: str,
        artifact_uuid: str,
        *,
        source: str | None = None,
        origin: str | None = None,
        resolved_sha: str | None = None,
        resolved_version: str | None = None,
        ctx: RequestContext | None = None,
    ) -> CollectionArtifactDTO:
        """Update upstream source-tracking fields on a membership record.

        Used by the sync subsystem to record the resolved upstream coordinates
        for an artifact after a fetch or sync operation.

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_uuid: Stable 32-char hex UUID of the artifact.
            source: Optional GitHub source spec
                (e.g. ``"owner/repo/path@version"``).
            origin: Optional human-readable origin label
                (e.g. ``"github"``).
            resolved_sha: Optional resolved commit SHA for the artifact.
            resolved_version: Optional resolved semantic version string.
            ctx: Optional per-request metadata.

        Returns:
            The updated
            :class:`~skillmeat.core.interfaces.dtos.CollectionArtifactDTO`.

        Raises:
            KeyError: If no membership for *(collection_id, artifact_uuid)*
                exists.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Bootstrap / migration helpers
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_existing_artifact_ids(self) -> set[str]:
        """Return the set of all ``type:name`` Artifact IDs currently in the DB.

        Used during bootstrap to avoid redundant INSERT attempts for artifact
        rows that already exist.

        Returns:
            Set of ``"type:name"`` strings (e.g. ``{"skill:canvas", ...}``).
            Returns an empty set when no artifact rows exist.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def ensure_artifact_rows(
        self,
        artifacts: list,
        *,
        project_id: str,
    ) -> int:
        """Ensure every filesystem artifact has a corresponding Artifact ORM row.

        Idempotent: artifacts already present in the ``artifacts`` table are
        skipped.  Inserts are committed as a single transaction.

        Args:
            artifacts: List of filesystem :class:`~skillmeat.core.artifact.Artifact`
                objects whose ``type``, ``name``, ``upstream``, and ``metadata``
                attributes are used to build the Artifact ORM row.
            project_id: Sentinel project ID assigned as ``project_id`` FK on
                every inserted row.

        Returns:
            Number of new Artifact rows inserted.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_artifact_ids_in_collection(
        self,
        collection_id: str,
    ) -> set[str]:
        """Return the set of ``type:name`` Artifact IDs present in a collection.

        Resolves UUIDs back to ``type:name`` strings by joining through the
        ``artifacts`` table so that callers can use set arithmetic against
        filesystem artifact lists.

        Args:
            collection_id: Unique identifier of the user collection.

        Returns:
            Set of ``"type:name"`` strings for all artifacts in the collection.
            Returns an empty set when the collection has no members.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def resolve_uuid_by_id(
        self,
        artifact_id: str,
    ) -> str | None:
        """Resolve the stable UUID for an artifact by its ``type:name`` ID.

        Args:
            artifact_id: ``"type:name"`` artifact identifier string.

        Returns:
            32-char hex UUID string when found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_all_with_tags(self) -> list[CollectionArtifactDTO]:
        """Return all CollectionArtifact rows that carry at least one tag.

        Unlike :meth:`list_with_tags`, this method is not scoped to a single
        collection and is intended for global tag-sync bootstrap operations.

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.CollectionArtifactDTO`
            objects with ``tags_json`` populated.  Returns an empty list when
            no tagged rows exist.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def resolve_uuid_to_id_batch(
        self,
        uuids: list[str],
        ctx: RequestContext | None = None,
    ) -> dict[str, str]:
        """Batch-resolve artifact UUIDs to ``type:name`` ID strings.

        Executes a single query against the ``artifacts`` table and returns a
        mapping from 32-char hex UUID to the corresponding ``type:name`` ID
        string for every UUID in *uuids* that exists in the database.

        Args:
            uuids: List of 32-char hex UUID strings to resolve.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            Dict mapping ``artifact_uuid`` → ``type:name`` ID.  UUIDs not
            found in the database are omitted from the result.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_all_ordered(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> list[CollectionArtifactDTO]:
        """Return all memberships for a collection ordered by artifact ``type:name`` ID.

        Joins through the ``artifacts`` table to order results by the stable
        ``Artifact.id`` string (``type:name``), enabling stable cursor-based
        pagination at the endpoint layer.

        Args:
            collection_id: Unique identifier of the user collection.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            All :class:`~skillmeat.core.interfaces.dtos.CollectionArtifactDTO`
            records for the collection, ordered by artifact ID.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_group_artifact_uuids(
        self,
        group_id: str,
        ctx: RequestContext | None = None,
    ) -> set[str]:
        """Return the set of artifact UUIDs belonging to a group.

        Args:
            group_id: Unique identifier of the group.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            Set of 32-char hex UUID strings.  Empty set when the group has no
            members or does not exist.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_source_for_uuids(
        self,
        artifact_uuids: list[str],
        ctx: RequestContext | None = None,
    ) -> dict[str, str]:
        """Return a mapping from ``type:name`` ID to source value for a batch.

        Joins ``artifacts`` to ``collection_artifacts`` and returns the
        ``source`` column for each UUID in *artifact_uuids* that has a
        non-null source.

        Args:
            artifact_uuids: List of 32-char hex UUID strings to look up.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            Dict mapping ``type:name`` artifact ID → source string.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_group_memberships_batch(
        self,
        artifact_uuids: list[str],
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> list[GroupMembershipEntryDTO]:
        """Return group-membership rows for a batch of artifact UUIDs.

        Args:
            artifact_uuids: List of 32-char hex UUID strings.
            collection_id: Scope results to groups belonging to this
                collection.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.GroupMembershipEntryDTO`
            instances, each representing one artifact-to-group association within
            the specified collection.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_staleness_stats(
        self,
        collection_id: str,
        ttl_seconds: int,
        ctx: RequestContext | None = None,
    ) -> StalenessStatsDTO:
        """Return staleness statistics for a collection.

        Computes counts of fresh vs stale memberships based on
        ``CollectionArtifact.synced_at`` relative to *ttl_seconds*.

        Args:
            collection_id: Unique identifier of the collection to analyse.
            ttl_seconds: Age in seconds after which a membership is
                considered stale.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.StalenessStatsDTO`
            instance with aggregate staleness statistics for the collection.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_deployments_by_name(
        self,
        collection_id: str,
        artifact_name: str,
        deployments_json: str,
        ctx: RequestContext | None = None,
    ) -> int:
        """Update ``deployments_json`` on all memberships matching *artifact_name*.

        Finds all ``Artifact`` rows whose ``name`` column equals *artifact_name*
        and updates the corresponding ``CollectionArtifact.deployments_json``
        column within the specified collection.

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_name: Short artifact name (without the ``type:`` prefix).
            deployments_json: Serialised JSON string to store in
                ``deployments_json``.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            Number of rows updated.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def bulk_update_metadata(
        self,
        updates: list[dict],
        ctx: RequestContext | None = None,
    ) -> int:
        """Apply metadata field updates to multiple membership rows.

        Each element of *updates* must contain an ``artifact_uuid`` key that
        identifies the row to update plus any combination of the recognised
        metadata fields (``description``, ``author``, ``license``, ``version``,
        ``tags_json``, ``tools_json``, ``source``, ``origin``,
        ``origin_source``, ``resolved_sha``, ``resolved_version``,
        ``synced_at``).  Unknown keys are silently ignored.

        Args:
            updates: List of dicts, each with ``artifact_uuid`` and the fields
                to write.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            Number of rows successfully updated.
        """
        raise NotImplementedError


# =============================================================================
# IDbUserCollectionRepository
# =============================================================================


class IDbUserCollectionRepository(abc.ABC):
    """Contract for DB-backed user collection storage backends.

    User collections are named, persisted groups of artifacts stored in the
    ``Collection`` ORM model.  Unlike the filesystem-oriented
    :class:`ICollectionRepository`, this interface operates entirely against
    the DB cache and supports multi-collection, filtered queries, and
    group associations.  Operations back the ``/api/v1/user-collections``
    router.
    """

    # ------------------------------------------------------------------
    # Collection queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list(
        self,
        *,
        created_by: str | None = None,
        collection_type: str | None = None,
        context_category: str | None = None,
        owner_type: str | None = None,
        owner_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
        ctx: RequestContext | None = None,
    ) -> list[UserCollectionDTO]:
        """Return a filtered, paginated list of user collections.

        Args:
            created_by: When provided, return only collections owned by this
                user/agent identifier.
            collection_type: When provided, restrict to collections of this
                type (e.g. ``"default"``, ``"user"``).
            context_category: When provided, restrict to collections tagged
                with this context category string.
            owner_type: When provided, restrict to collections with this
                ownership tier (e.g. ``"user"``, ``"team"``, ``"enterprise"``).
            owner_id: When provided, restrict to collections owned by this
                specific owner ID string.
            limit: Maximum number of records to return.
            offset: Zero-based record offset for pagination.
            ctx: Optional per-request metadata.

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.UserCollectionDTO` objects.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Single-item lookup
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_by_id(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> UserCollectionDTO | None:
        """Return a user collection by its UUID.

        Args:
            collection_id: Collection hex-UUID primary key.
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.UserCollectionDTO` when
            found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_name(
        self,
        name: str,
        ctx: RequestContext | None = None,
    ) -> UserCollectionDTO | None:
        """Return a user collection by its human-readable name.

        Args:
            name: Collection name string (case-sensitive).
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.UserCollectionDTO` when
            found, ``None`` otherwise.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Mutations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def create(
        self,
        *,
        name: str,
        description: str | None = None,
        created_by: str | None = None,
        collection_type: str | None = None,
        context_category: str | None = None,
        ctx: RequestContext | None = None,
    ) -> UserCollectionDTO:
        """Persist a new user collection and return the stored representation.

        Args:
            name: Human-readable collection name.  Must be unique within the
                scope of *created_by*.
            description: Optional free-text description.
            created_by: Optional owner identifier (user ID or agent name).
            collection_type: Optional type discriminator (e.g. ``"default"``).
            context_category: Optional context category tag string.
            ctx: Optional per-request metadata.

        Returns:
            The persisted
            :class:`~skillmeat.core.interfaces.dtos.UserCollectionDTO`.

        Raises:
            ValueError: If a collection with the same *name* already exists
                for the given *created_by*.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
        **kwargs: Any,
    ) -> UserCollectionDTO:
        """Apply a partial update to an existing user collection.

        Only provided keyword arguments are changed; unmentioned fields remain
        at their current values.  Recognised keys mirror
        :class:`~skillmeat.core.interfaces.dtos.UserCollectionDTO` fields:
        ``name``, ``description``, ``collection_type``, ``context_category``.

        Args:
            collection_id: Collection hex-UUID primary key.
            ctx: Optional per-request metadata.
            **kwargs: Field names to new values for the partial update.

        Returns:
            The updated
            :class:`~skillmeat.core.interfaces.dtos.UserCollectionDTO`.

        Raises:
            KeyError: If no collection with *collection_id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Delete a user collection and all its membership records.

        Does not delete artifact files — only removes the DB collection record
        and associated ``CollectionArtifact`` rows.

        Args:
            collection_id: Collection hex-UUID primary key.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` when the collection was found and deleted, ``False``
            when no matching record existed.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Default collection management
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def ensure_default(
        self,
        *,
        created_by: str | None = None,
        ctx: RequestContext | None = None,
    ) -> UserCollectionDTO:
        """Return the default collection, creating it if it does not exist.

        The implementation must be idempotent: concurrent callers must not
        produce duplicate default collections.

        Args:
            created_by: Optional owner identifier.  When provided the default
                collection is scoped to this owner.
            ctx: Optional per-request metadata.

        Returns:
            The existing or newly created default
            :class:`~skillmeat.core.interfaces.dtos.UserCollectionDTO`.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Enriched queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_with_artifact_stats(
        self,
        *,
        created_by: str | None = None,
        limit: int = 50,
        offset: int = 0,
        ctx: RequestContext | None = None,
    ) -> list[UserCollectionDTO]:
        """Return collections with ``artifact_count`` and ``total_size_bytes`` populated.

        Performs an aggregation join so that the returned DTOs carry up-to-date
        counts without additional round-trips by the caller.

        Args:
            created_by: When provided, return only collections owned by this
                identifier.
            limit: Maximum number of records to return.
            offset: Zero-based record offset for pagination.
            ctx: Optional per-request metadata.

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.UserCollectionDTO` objects
            with ``artifact_count`` and ``total_size_bytes`` set.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Group associations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def add_group(
        self,
        collection_id: str,
        group_id: str,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Associate an existing group with a user collection.

        Idempotent: associating a group that is already linked is a no-op and
        returns ``True``.

        Args:
            collection_id: Collection hex-UUID primary key.
            group_id: Group identifier to associate.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` on success (including when the association already existed),
            ``False`` when *collection_id* or *group_id* does not exist.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def remove_group(
        self,
        collection_id: str,
        group_id: str,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Disassociate a group from a user collection.

        Args:
            collection_id: Collection hex-UUID primary key.
            group_id: Group identifier to remove.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` when the association existed and was removed, ``False``
            if the association was not found.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_groups(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> list[str]:
        """Return the identifiers of all groups associated with a collection.

        Args:
            collection_id: Collection hex-UUID primary key.
            ctx: Optional per-request metadata.

        Returns:
            List of group identifier strings.  Returns an empty list when the
            collection does not exist or has no group associations.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Aggregate helpers
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_artifact_count(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> int:
        """Return the number of artifacts currently in a collection.

        Args:
            collection_id: Collection hex-UUID primary key.
            ctx: Optional per-request metadata.

        Returns:
            Non-negative integer artifact count.  Returns ``0`` when the
            collection does not exist.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Sentinel project bootstrap
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def ensure_sentinel_project(self) -> None:
        """Ensure the sentinel Project row used by collection artifacts exists.

        Artifact rows require a ``project_id`` foreign-key.  Collection-level
        (filesystem) artifacts are not tied to any deployed project, so a
        sentinel project row satisfies the constraint.  The sentinel ID is
        the module-level constant ``COLLECTION_ARTIFACTS_PROJECT_ID``.

        This method is idempotent: if the sentinel row already exists the
        call is a no-op.
        """
        raise NotImplementedError


# =============================================================================
# IDbArtifactHistoryRepository
# =============================================================================


class IDbArtifactHistoryRepository(abc.ABC):
    """Repository ABC for artifact history queries.

    Encapsulates the two cache-model lookups and the version-lineage query
    used by the ``/api/v1/artifacts/{id}/history`` endpoint so that the
    router holds no raw SQLAlchemy session references.

    All methods are read-only; the history endpoint does not mutate state.
    """

    # ------------------------------------------------------------------
    # Artifact lookups
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_cache_artifact_by_uuid(
        self,
        uuid: str,
        ctx: RequestContext | None = None,
    ) -> CacheArtifactSummaryDTO | None:
        """Return a summary of the ``artifacts`` row identified by UUID.

        Args:
            uuid: Stable 32-char hex UUID (ADR-007 identity).
            ctx: Optional per-request metadata.

        Returns:
            A :class:`~skillmeat.core.interfaces.dtos.CacheArtifactSummaryDTO`
            when the artifact exists, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_cache_artifacts_by_name_type(
        self,
        name: str,
        artifact_type: str,
        ctx: RequestContext | None = None,
    ) -> list[CacheArtifactSummaryDTO]:
        """Return all ``artifacts`` rows matching *name* and *artifact_type*.

        Multiple rows can exist for the same logical artifact because each
        deployed project has its own row.

        Args:
            name: Artifact name (normalised, without file extension).
            artifact_type: Artifact type string (e.g. ``"skill"``).
            ctx: Optional per-request metadata.

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.CacheArtifactSummaryDTO`.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Version lineage
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_versions_for_artifacts(
        self,
        artifact_ids: list[str],
        ctx: RequestContext | None = None,
    ) -> list[ArtifactVersionDTO]:
        """Return version lineage records for a set of artifact primary keys.

        Args:
            artifact_ids: List of ``artifacts.id`` values (``type:name``
                strings).  The query is skipped and an empty list returned
                when *artifact_ids* is empty.
            ctx: Optional per-request metadata.

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.ArtifactVersionDTO`
            ordered by ``created_at`` descending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_composite_key(
        self,
        artifact_id: str,
        content_hash: str,
        ctx: RequestContext | None = None,
    ) -> ArtifactVersionDTO | None:
        """Return the ``ArtifactVersion`` matching the ``(artifact_id, content_hash)`` pair.

        Args:
            artifact_id: The ``artifacts.id`` value (``type:name`` for local,
                UUID string for enterprise).
            content_hash: SHA-256 content hash of the target version.
            ctx: Optional per-request metadata.

        Returns:
            :class:`~skillmeat.core.interfaces.dtos.ArtifactVersionDTO` when
            the composite key matches a row, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_paginated_version_history(
        self,
        artifact_id: str,
        limit: int = 50,
        after: str | None = None,
        owner_type: str | None = None,
        owner_id: str | None = None,
        ctx: RequestContext | None = None,
    ) -> tuple[list[dict[Any, Any]], bool]:
        """Return paginated version history for a single artifact.

        Args:
            artifact_id: Artifact identifier.  ``type:name`` format for local
                edition; UUID string for enterprise edition.
            limit: Maximum number of items to return (1–100).
            after: Opaque cursor for keyset pagination (content hash or
                encoded timestamp, depending on edition).
            owner_type: Optional owner type filter for enterprise scoping
                (``"user"``, ``"team"``, ``"enterprise"``).
            owner_id: Optional owner ID for enterprise scoping.
            ctx: Optional per-request metadata.

        Returns:
            A two-element tuple ``(items, has_next_page)``.  Each item dict
            must contain at minimum: ``content_hash``, ``created_at``,
            ``change_origin``, ``event_type``, and ``actor_id``.  Enterprise
            implementations may also include ``version_tag``, ``version_label``,
            ``changelog``, and ``message``.
        """
        raise NotImplementedError


# =============================================================================
# IMembershipRepository
# =============================================================================


class IMembershipRepository(abc.ABC):
    """Lookup interface for team/org membership, used by OwnershipResolver.

    Implementations are responsible for tenant scoping internally (e.g. via a
    ContextVar).  Callers do not pass ``tenant_id`` directly — this keeps the
    interface simple and aligns with how enterprise repositories already manage
    per-request tenant context.
    """

    # ------------------------------------------------------------------
    # Membership queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_team_ids_for_user(self, user_id: uuid.UUID) -> list[uuid.UUID]:
        """Return the IDs of every team the user is a member of.

        Args:
            user_id: The UUID of the user whose team memberships are queried.

        Returns:
            A (possibly empty) list of team UUIDs.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_team_role(self, user_id: uuid.UUID, team_id: uuid.UUID) -> str | None:
        """Return the user's role in a specific team, or ``None`` if not a member.

        Args:
            user_id: The UUID of the user.
            team_id: The UUID of the team.

        Returns:
            A role string (e.g. ``"owner"``, ``"member"``) when the user
            belongs to the team, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def is_member_of(self, user_id: uuid.UUID, team_id: uuid.UUID) -> bool:
        """Check whether a user is a member of the given team.

        Args:
            user_id: The UUID of the user.
            team_id: The UUID of the team.

        Returns:
            ``True`` when the user is a member, ``False`` otherwise.
        """
        raise NotImplementedError


# =============================================================================
# IArtifactActivityRepository
# =============================================================================


class IArtifactActivityRepository(abc.ABC):
    """Repository ABC for artifact activity / audit-log events.

    Manages :class:`ActivityEventDTO` records which form the immutable
    append-only activity ledger for every artifact in the collection.

    Design invariants:

    - **Insert-only**: Events are immutable once written.  There are no
      ``update`` or ``delete`` methods on this interface.
    - **Append-only queries**: All read methods filter and page over the
      existing event log; they do not modify state.
    - Valid ``event_type`` values: ``'create'``, ``'update'``, ``'delete'``,
      ``'deploy'``, ``'undeploy'``, ``'sync'``.
    - ``ctx: RequestContext | None = None`` is the last parameter of every
      method so callers that do not need per-request metadata can omit it.
    """

    # ------------------------------------------------------------------
    # Mutations (insert-only)
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def create_event(
        self,
        artifact_id: str,
        event_type: str,
        actor_id: str | None,
        owner_type: str,
        diff_json: str | None,
        content_hash: str | None,
        ctx: RequestContext | None = None,
    ) -> ActivityEventDTO:
        """Append a new lifecycle event to the activity log.

        Args:
            artifact_id: Primary key of the artifact (``"type:name"`` format).
            event_type: One of ``'create'``, ``'update'``, ``'delete'``,
                ``'deploy'``, ``'undeploy'``, or ``'sync'``.
            actor_id: Opaque identifier for the user or system that triggered
                the event; ``None`` for automated/system events.
            owner_type: Owner context at the time of the event (e.g. the
                ``.value`` of :class:`~skillmeat.cache.auth_types.OwnerType`).
            diff_json: JSON-serialised diff payload describing the change, or
                ``None`` when no diff is available.
            content_hash: SHA-256 hex digest of artifact content at event
                time, or ``None`` when not applicable.
            ctx: Optional per-request metadata.

        Returns:
            The newly created :class:`ActivityEventDTO`
            instance (id populated after flush/commit).
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_events(
        self,
        artifact_id: str | None = None,
        event_type: str | None = None,
        actor_id: str | None = None,
        owner_type: str | None = None,
        time_range: tuple[datetime, datetime] | None = None,
        limit: int = 100,
        offset: int = 0,
        ctx: RequestContext | None = None,
    ) -> list[ActivityEventDTO]:
        """Return a filtered, paginated slice of activity events.

        All filter arguments are optional and combinable.  When multiple
        filters are provided they are AND-ed together.

        Args:
            artifact_id: Restrict to events for this artifact primary key.
            event_type: Restrict to events of this type.
            actor_id: Restrict to events triggered by this actor.
            owner_type: Restrict to events with this owner context.
            time_range: ``(start, end)`` inclusive window in UTC; restricts
                to events where ``timestamp >= start`` and
                ``timestamp <= end``.
            limit: Maximum number of events to return (default 100).
            offset: Number of events to skip for pagination (default 0).
            ctx: Optional per-request metadata.

        Returns:
            A (possibly empty) list of
            :class:`ActivityEventDTO` ordered
            by ``timestamp`` ascending, then ``id`` ascending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_event(
        self,
        event_id: str,
        ctx: RequestContext | None = None,
    ) -> ActivityEventDTO | None:
        """Return a single event by its primary key.

        ``event_id`` is a string to support both the local SQLite backend
        (where the PK is an auto-increment integer stringified as ``"42"``)
        and the enterprise PostgreSQL backend (where the PK is a UUID hex
        string).  Implementations are responsible for coercing to the
        appropriate DB type before querying.

        Args:
            event_id: String-form primary key of the event row.
            ctx: Optional per-request metadata.

        Returns:
            The matching :class:`ActivityEventDTO`
            when found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def count_events(
        self,
        artifact_id: str | None = None,
        event_type: str | None = None,
        owner_type: str | None = None,
        ctx: RequestContext | None = None,
    ) -> int:
        """Return the count of events matching the given filters.

        Useful for pagination metadata and analytics without transferring
        full event rows.

        Args:
            artifact_id: Restrict count to events for this artifact.
            event_type: Restrict count to events of this type.
            owner_type: Restrict count to events with this owner context.
            ctx: Optional per-request metadata.

        Returns:
            Non-negative integer count of matching event rows.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_provenance_slice(
        self,
        artifact_id: str,
        since: datetime | None = None,
        until: datetime | None = None,
        ctx: RequestContext | None = None,
    ) -> list[ActivityEventDTO]:
        """Return the ordered provenance timeline for a single artifact.

        Returns all events for *artifact_id* within the optional time window,
        ordered chronologically ascending.  Intended for provenance/lineage
        views where the full event sequence matters.

        Args:
            artifact_id: Primary key of the artifact whose provenance is
                requested.
            since: Lower bound (inclusive) of the time window in UTC.
                When ``None``, no lower bound is applied.
            until: Upper bound (inclusive) of the time window in UTC.
                When ``None``, no upper bound is applied.
            ctx: Optional per-request metadata.

        Returns:
            A (possibly empty) list of
            :class:`ActivityEventDTO` ordered
            by ``timestamp`` ascending, then ``id`` ascending.
        """
        raise NotImplementedError


# =============================================================================
# IBundleRepository
# =============================================================================


class IBundleRepository(abc.ABC):
    """Contract for bundle storage backends.

    A bundle is a publishable, versioned collection of artifacts that can be
    shared and installed as a single unit.  Operations map to the
    ``/api/v1/bundles`` router and the ADR-008 bundle lifecycle model.

    All methods return typed DTOs (:class:`~skillmeat.core.interfaces.dtos.BundleDTO`,
    :class:`~skillmeat.core.interfaces.dtos.BundleMembershipDTO`, and
    :class:`~skillmeat.core.interfaces.dtos.BundleListDTO`) so callers receive
    type-safe values that remain independent of the storage technology.
    """

    # ------------------------------------------------------------------
    # Bundle CRUD
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def create_bundle(
        self,
        name: str,
        collection_id: str,
        description: str | None = None,
        version: str | None = None,
        tags: list[str] | None = None,
        license: str | None = None,
        homepage: str | None = None,
        repository: str | None = None,
        ctx: RequestContext | None = None,
    ) -> BundleDTO:
        """Create a new bundle in draft status.

        Args:
            name: Human-readable bundle name (unique within the collection).
            collection_id: Owning collection identifier.
            description: Optional free-text description.
            version: Optional initial semver string.
            tags: Optional list of tag strings.
            license: Optional SPDX license identifier (e.g. ``"MIT"``).
            homepage: Optional URL for documentation or homepage.
            repository: Optional URL for the source repository.
            ctx: Optional per-request metadata.

        Returns:
            :class:`BundleDTO` representing the newly created bundle (status
            ``"draft"``).

        Raises:
            ValueError: If a bundle with *name* already exists in
                *collection_id*.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_bundle(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
    ) -> BundleDTO:
        """Return the bundle with the given identifier.

        Args:
            bundle_id: UUID hex primary key.
            ctx: Optional per-request metadata.

        Returns:
            :class:`BundleDTO` including the embedded membership list.

        Raises:
            ValueError: If no bundle with *bundle_id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_bundle_by_name(
        self,
        name: str,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> BundleDTO | None:
        """Return the bundle matching *name* within *collection_id*.

        Args:
            name: Bundle name to look up.
            collection_id: Owning collection identifier.
            ctx: Optional per-request metadata.

        Returns:
            :class:`BundleDTO` when found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_bundles(
        self,
        collection_id: str | None = None,
        status: str | None = None,
        tags: list[str] | None = None,
        page: int = 1,
        page_size: int = 50,
        ctx: RequestContext | None = None,
    ) -> BundleListDTO:
        """Return a paginated list of bundles matching the given filters.

        Args:
            collection_id: Restrict results to a specific collection.
            status: Restrict results to a specific lifecycle status
                (``"draft"``, ``"published"``, or ``"deprecated"``).
            tags: Restrict results to bundles containing all listed tags.
            page: 1-based page number.
            page_size: Maximum items per page.
            ctx: Optional per-request metadata.

        Returns:
            :class:`BundleListDTO` with ``items``, ``total``, ``page``, and
            ``page_size`` fields.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_bundle(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
        **kwargs: Any,
    ) -> BundleDTO:
        """Apply a partial update to an existing draft bundle.

        Only bundles in ``"draft"`` status may be updated.  Attempting to
        update a ``"published"`` or ``"deprecated"`` bundle raises an error.

        Args:
            bundle_id: UUID hex primary key of the bundle to update.
            ctx: Optional per-request metadata.
            **kwargs: Field names and new values to apply (e.g.
                ``name="new-name"``, ``description="updated"``).

        Returns:
            :class:`BundleDTO` representing the updated bundle.

        Raises:
            ValueError: If no bundle with *bundle_id* exists, or if the
                bundle is not in ``"draft"`` status.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete_bundle(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
    ) -> None:
        """Delete or deprecate a bundle depending on its current status.

        * ``"draft"`` -> hard delete (removes all membership rows via cascade).
        * ``"published"`` -> set status to ``"deprecated"`` (soft delete).
        * ``"deprecated"`` -> no-op (already deprecated).

        Args:
            bundle_id: UUID hex primary key of the bundle.
            ctx: Optional per-request metadata.

        Raises:
            ValueError: If no bundle with *bundle_id* exists.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Membership management
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def add_member(
        self,
        bundle_id: str,
        artifact_uuid: str | None = None,
        artifact_tier: int = 0,
        relationship_type: str = "contains",
        pinned_version_hash: str | None = None,
        member_type: str = "artifact",
        context_entity_id: str | None = None,
        ctx: RequestContext | None = None,
    ) -> BundleMembershipDTO:
        """Add an artifact or context entity to a bundle.

        Exactly one of ``artifact_uuid`` (when ``member_type="artifact"``) or
        ``context_entity_id`` (when ``member_type="context_entity"``) must be
        provided.  The caller is responsible for validating that the referenced
        entity exists before calling this method.

        Args:
            bundle_id: UUID hex primary key of the bundle.
            artifact_uuid: Stable ``artifacts.uuid`` of the artifact to add.
                Required when ``member_type="artifact"``.
            artifact_tier: Tier classification -- 0=standalone, 1=composable,
                2=orchestrator.
            relationship_type: Semantic edge label (default ``"contains"``).
            pinned_version_hash: Optional content hash pinning the artifact to
                a specific snapshot.  ``None`` means "always use latest".
            member_type: Discriminator -- ``"artifact"`` (default) or
                ``"context_entity"``.
            context_entity_id: Context entity identifier.  Required when
                ``member_type="context_entity"``.
            ctx: Optional per-request metadata.

        Returns:
            :class:`BundleMembershipDTO` representing the created membership row.

        Raises:
            ValueError: If the artifact is already a member of the bundle, or
                if the bundle does not exist.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def remove_member(
        self,
        bundle_id: str,
        artifact_uuid: str,
        ctx: RequestContext | None = None,
    ) -> None:
        """Remove an artifact from a bundle.

        Only bundles in ``"draft"`` status permit member removal.

        Args:
            bundle_id: UUID hex primary key of the bundle.
            artifact_uuid: Stable ``artifacts.uuid`` of the artifact to
                remove.
            ctx: Optional per-request metadata.

        Raises:
            ValueError: If the bundle is not in ``"draft"`` status, or if the
                membership record does not exist.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_members(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
    ) -> list[BundleMembershipDTO]:
        """Return all membership records for a bundle.

        Args:
            bundle_id: UUID hex primary key of the bundle.
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`BundleMembershipDTO` ordered by ``added_at``
            ascending.

        Raises:
            ValueError: If no bundle with *bundle_id* exists.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Lifecycle transitions
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def publish_bundle(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
    ) -> BundleDTO:
        """Transition a bundle from ``"draft"`` to ``"published"``.

        Sets ``published_at`` to the current UTC timestamp on first publish.

        Args:
            bundle_id: UUID hex primary key of the bundle.
            ctx: Optional per-request metadata.

        Returns:
            :class:`BundleDTO` representing the newly published bundle.

        Raises:
            ValueError: If the bundle is not in ``"draft"`` status, or if no
                bundle with *bundle_id* exists.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def deprecate_bundle(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
    ) -> BundleDTO:
        """Transition a bundle from ``"published"`` to ``"deprecated"``.

        Args:
            bundle_id: UUID hex primary key of the bundle.
            ctx: Optional per-request metadata.

        Returns:
            :class:`BundleDTO` representing the deprecated bundle.

        Raises:
            ValueError: If the bundle is not in ``"published"`` status, or if
                no bundle with *bundle_id* exists.
        """
        raise NotImplementedError


# =============================================================================
# IGitRepoConnectionRepository
# =============================================================================


class IGitRepoConnectionRepository(abc.ABC):
    """Contract for Git repository connection storage backends.

    Covers the full lifecycle of a GitRepoConnection: registration, retrieval,
    update, and deletion.  Implementations exist for the local SQLite edition
    (``GitRepoConnectionRepository``) and the enterprise PostgreSQL edition
    (``EnterpriseGitRepoConnectionRepository``).
    """

    @abc.abstractmethod
    def create(
        self,
        project_id: str | None,
        repo_url: str,
        branch: str = "main",
        developer_id: int | None = None,
        scan_schedule: str | None = None,
        webhook_secret: str | None = None,
        ctx: RequestContext | None = None,
    ) -> GitRepoConnectionDTO:
        """Register a new Git repository connection.

        Args:
            project_id: FK to ``projects.id``; nullable for enterprise tenant scope.
            repo_url: Full clone URL of the Git repository.
            branch: Branch to scan (default ``'main'``).
            developer_id: Optional FK to the owning developer/user row.
            scan_schedule: Reserved cron expression for scheduled scans.
            webhook_secret: HMAC secret for webhook push-event validation.
            ctx: Optional per-request metadata.

        Returns:
            The newly created connection as a :class:`GitRepoConnectionDTO`.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_id(
        self,
        id: int | Any,
        ctx: RequestContext | None = None,
    ) -> GitRepoConnectionDTO | None:
        """Return the connection with the given primary key, or ``None``.

        Args:
            id: Integer PK for local edition; UUID for enterprise edition.
            ctx: Optional per-request metadata.

        Returns:
            :class:`GitRepoConnectionDTO` when found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_by_project_id(
        self,
        project_id: str,
        limit: int = 50,
        offset: int = 0,
        ctx: RequestContext | None = None,
    ) -> list[GitRepoConnectionDTO]:
        """Return a page of connections belonging to *project_id*.

        Args:
            project_id: FK value to filter on.
            limit: Maximum records to return (default 50).
            offset: Records to skip for pagination (default 0).
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`GitRepoConnectionDTO` ordered by ``created_at`` descending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_url(
        self,
        project_id: str,
        repo_url: str,
        branch: str,
        ctx: RequestContext | None = None,
    ) -> GitRepoConnectionDTO | None:
        """Return the connection matching the (project_id, repo_url, branch) unique key.

        Used for uniqueness checks before creating a new connection.

        Args:
            project_id: FK to the owning project.
            repo_url: Full clone URL.
            branch: Branch name.
            ctx: Optional per-request metadata.

        Returns:
            :class:`GitRepoConnectionDTO` when found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_repo_url_branch(
        self,
        repo_url: str,
        branch: str,
        ctx: RequestContext | None = None,
    ) -> GitRepoConnectionDTO | None:
        """Return the connection matching the (repo_url, branch) unique key.

        Used for M2M-decoupled uniqueness checks where connections are not
        tied to a single project.

        Args:
            repo_url: Full clone URL.
            branch: Branch name.
            ctx: Optional per-request metadata.

        Returns:
            :class:`GitRepoConnectionDTO` when found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        id: int | Any,
        ctx: RequestContext | None = None,
        **kwargs: Any,
    ) -> GitRepoConnectionDTO | None:
        """Update fields on an existing connection and return the refreshed row.

        Args:
            id: Primary key of the connection to update.
            ctx: Optional per-request metadata.
            **kwargs: Column names and their new values.

        Returns:
            Refreshed :class:`GitRepoConnectionDTO`, or ``None`` if the row was not found.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(
        self,
        id: int | Any,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Delete the connection with the given primary key.

        Args:
            id: Primary key of the connection to delete.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` if a row was deleted, ``False`` if it was not found.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_all(
        self,
        ctx: RequestContext | None = None,
    ) -> list[GitRepoConnectionDTO]:
        """List all git repo connections.

        Args:
            ctx: Optional per-request metadata.

        Returns:
            List of all :class:`GitRepoConnectionDTO` ordered by
            ``created_at`` descending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_by_team_id(
        self,
        team_id: int | Any,
        ctx: RequestContext | None = None,
    ) -> list[GitRepoConnectionDTO]:
        """List git repo connections filtered by team ID.

        Returns an empty list on the local (single-tenant) edition where the
        concept of teams does not exist.

        Args:
            team_id: Primary key of the team to filter on.
            ctx: Optional per-request metadata.

        Returns:
            List of matching :class:`GitRepoConnectionDTO` ordered by
            ``created_at`` descending, or an empty list when teams are not
            supported.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_unlinked(
        self,
        ctx: RequestContext | None = None,
    ) -> list[GitRepoConnectionDTO]:
        """List git repo connections not linked to any project.

        A connection is considered *unlinked* when it has no entries in the
        ``project_git_connections`` join table.

        Args:
            ctx: Optional per-request metadata.

        Returns:
            List of unlinked :class:`GitRepoConnectionDTO` ordered by
            ``created_at`` descending.
        """
        raise NotImplementedError


# =============================================================================
# IProjectGitConnectionRepository
# =============================================================================


class IProjectGitConnectionRepository(abc.ABC):
    """Contract for the ``project_git_connections`` join-table storage backends.

    Manages the many-to-many relationship between Projects and
    GitRepoConnections.  A connection is a long-lived, project-independent
    object; this interface covers creating and destroying those links and
    querying them from either side.

    Implementations exist for the local SQLite edition
    (``LocalProjectGitConnectionRepository``) and the enterprise PostgreSQL
    edition (``EnterpriseProjectGitConnectionRepository``).
    """

    @abc.abstractmethod
    def link(
        self,
        project_id: str | Any,
        connection_id: int | Any,
        linked_by: str | None = None,
        ctx: "RequestContext | None" = None,
    ) -> "ProjectGitConnectionDTO":
        """Link a git connection to a project.

        Creates a row in the ``project_git_connections`` join table for
        the given ``(project_id, connection_id)`` pair.

        Args:
            project_id: FK to ``projects.id``; string for local edition,
                UUID for enterprise edition.
            connection_id: FK to ``git_repo_connections.id``; integer PK
                for local edition, UUID for enterprise edition.
            linked_by: Optional actor identifier (user ID,
                ``'migration'``, CLI username, etc.).
            ctx: Optional per-request metadata.

        Returns:
            DTO for the newly created join-table row.

        Raises:
            ConstraintError: If the ``(project_id, connection_id)`` pair
                already exists (duplicate composite PK).
        """
        raise NotImplementedError

    @abc.abstractmethod
    def unlink(
        self,
        project_id: str | Any,
        connection_id: int | Any,
        ctx: "RequestContext | None" = None,
    ) -> bool:
        """Unlink a git connection from a project.

        Deletes the row in the ``project_git_connections`` join table for
        the given ``(project_id, connection_id)`` pair.

        Args:
            project_id: FK to ``projects.id``.
            connection_id: FK to ``git_repo_connections.id``.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` if the link existed and was deleted, ``False`` if it
            was not found.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_by_project(
        self,
        project_id: str | Any,
        ctx: "RequestContext | None" = None,
    ) -> "list[ProjectGitConnectionDTO]":
        """List all git connections linked to a project.

        Args:
            project_id: FK to ``projects.id``; filters the join table on
                this column.
            ctx: Optional per-request metadata.

        Returns:
            List of DTOs ordered by ``linked_at`` ascending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_by_connection(
        self,
        connection_id: int | Any,
        ctx: "RequestContext | None" = None,
    ) -> "list[ProjectGitConnectionDTO]":
        """List all projects linked to a connection.

        Args:
            connection_id: FK to ``git_repo_connections.id``; filters the
                join table on this column.
            ctx: Optional per-request metadata.

        Returns:
            List of DTOs ordered by ``linked_at`` ascending.
        """
        raise NotImplementedError


# =============================================================================
# IGitRepoScanRepository
# =============================================================================


class IGitRepoScanRepository(abc.ABC):
    """Contract for Git repository scan record storage backends.

    Covers the full lifecycle of a GitRepoScan: creation, retrieval,
    status/count updates, and idempotency checking by commit SHA.
    """

    @abc.abstractmethod
    def create(
        self,
        connection_id: int | Any,
        triggered_by: str,
        trigger_sha: str | None = None,
        ctx: RequestContext | None = None,
    ) -> GitRepoScanDTO:
        """Create a new scan record in ``'pending'`` status.

        Args:
            connection_id: FK to the parent ``GitRepoConnection`` row.
            triggered_by: How the scan was initiated (``'manual'``, ``'schedule'``,
                or ``'webhook'``).
            trigger_sha: 40-char git commit SHA that triggered the scan; ``None``
                for manual/schedule triggers.
            ctx: Optional per-request metadata.

        Returns:
            The newly created scan as a :class:`GitRepoScanDTO`.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_id(
        self,
        id: int | Any,
        ctx: RequestContext | None = None,
    ) -> GitRepoScanDTO | None:
        """Return the scan with the given primary key, or ``None``.

        Args:
            id: Integer PK for local edition; UUID for enterprise edition.
            ctx: Optional per-request metadata.

        Returns:
            :class:`GitRepoScanDTO` when found, ``None`` otherwise.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_by_connection_id(
        self,
        connection_id: int | Any,
        limit: int = 20,
        offset: int = 0,
        ctx: RequestContext | None = None,
    ) -> list[GitRepoScanDTO]:
        """Return a page of scans belonging to *connection_id*.

        Args:
            connection_id: FK value to filter on.
            limit: Maximum records to return (default 20).
            offset: Records to skip for pagination (default 0).
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`GitRepoScanDTO` ordered by ``created_at`` descending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_status(
        self,
        scan_id: int | Any,
        status: str,
        error_message: str | None = None,
        ctx: RequestContext | None = None,
    ) -> GitRepoScanDTO | None:
        """Update the lifecycle status of a scan and optionally set an error message.

        Args:
            scan_id: Primary key of the scan to update.
            status: New status value (``'pending'``, ``'running'``, ``'completed'``,
                or ``'failed'``).
            error_message: Human-readable failure detail; only meaningful when
                ``status == 'failed'``.  Pass ``None`` to leave the existing value
                unchanged.
            ctx: Optional per-request metadata.

        Returns:
            Refreshed :class:`GitRepoScanDTO`, or ``None`` if the scan was not found.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_counts(
        self,
        scan_id: int | Any,
        found: int,
        new: int,
        changed: int,
        removed: int,
        ctx: RequestContext | None = None,
    ) -> GitRepoScanDTO | None:
        """Update the artifact count fields once a scan run completes.

        Args:
            scan_id: Primary key of the scan to update.
            found: Total artifacts detected.
            new: Artifacts not seen in previous scans.
            changed: Artifacts whose content changed.
            removed: Artifacts absent from this scan vs. the previous one.
            ctx: Optional per-request metadata.

        Returns:
            Refreshed :class:`GitRepoScanDTO`, or ``None`` if the scan was not found.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_connection_and_sha(
        self,
        connection_id: int | Any,
        trigger_sha: str,
        ctx: RequestContext | None = None,
    ) -> GitRepoScanDTO | None:
        """Return an existing scan for the given connection and commit SHA.

        Used for idempotency checking: if a scan already exists for this
        (connection_id, trigger_sha) pair the caller can skip creating a
        duplicate.

        Args:
            connection_id: FK to the parent ``GitRepoConnection`` row.
            trigger_sha: 40-char git commit SHA to match.
            ctx: Optional per-request metadata.

        Returns:
            :class:`GitRepoScanDTO` when found, ``None`` otherwise.
        """
        raise NotImplementedError


# =============================================================================
# IGitCredentialRepository
# =============================================================================


class IGitCredentialRepository(abc.ABC):
    """Contract for git credential storage backends.

    Manages encrypted personal access tokens and app-installation tokens that
    are scoped to an org, team, or developer and optionally pinned to a
    specific :class:`GitRepoConnection`.

    Implementations exist for the local SQLite edition
    (``LocalGitCredentialRepository``) and the enterprise PostgreSQL edition
    (``EnterpriseGitCredentialRepository``).
    """

    @abc.abstractmethod
    def create(
        self,
        scope_type: str,
        scope_id: str,
        token: str,
        credential_type: str = "pat",
        connection_id: "str | None" = None,
        created_by: "str | None" = None,
    ) -> "GitCredentialDTO":
        """Create a new git credential.

        The token is stored encrypted via the ``EncryptedString`` column type;
        callers pass the plaintext value and encryption is applied transparently
        at the ORM layer.

        Args:
            scope_type: Owner scope label — one of ``'org'``, ``'team'``, or
                ``'developer'``.
            scope_id: Identifier of the scope owner (org slug, team ID, or user
                ID as a string).
            token: Plaintext credential token (PAT or app-installation token).
                Encrypted before persistence.
            credential_type: Token kind — ``'pat'`` (default) or
                ``'app_installation'``.
            connection_id: Optional FK to the parent ``GitRepoConnection``; when
                set the credential is cascade-deleted with the connection.
            created_by: Optional actor identifier (user ID, CLI username, etc.).

        Returns:
            DTO for the newly created credential (token not included).
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_id(self, credential_id: str) -> "GitCredentialDTO | None":
        """Get a credential by its primary-key ID.

        Args:
            credential_id: String UUID PK for the local edition; UUID object for
                the enterprise edition.

        Returns:
            DTO for the matching credential, or ``None`` if not found.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_by_scope(self, scope_type: str, scope_id: str) -> "list[GitCredentialDTO]":
        """List credentials filtered by scope type and scope ID.

        Args:
            scope_type: Owner scope label (``'org'``, ``'team'``, or
                ``'developer'``).
            scope_id: Identifier of the scope owner.

        Returns:
            List of DTOs matching both ``scope_type`` and ``scope_id``,
            ordered by ``created_at`` ascending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_by_connection(self, connection_id: str) -> "list[GitCredentialDTO]":
        """List credentials pinned to a specific connection.

        Args:
            connection_id: FK to the parent ``GitRepoConnection``/
                ``EnterpriseGitRepoConnection`` row.

        Returns:
            List of DTOs with a matching ``connection_id``, ordered by
            ``created_at`` ascending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(self, credential_id: str) -> bool:
        """Delete a credential by its primary-key ID.

        Args:
            credential_id: PK of the credential to delete.

        Returns:
            ``True`` if the credential existed and was deleted, ``False`` if it
            was not found.
        """
        raise NotImplementedError


# =============================================================================
# IGitScanArtifactRepository
# =============================================================================


class IGitScanArtifactRepository(abc.ABC):
    """Contract for Git scan artifact observation storage backends.

    Covers creating individual artifact observations produced by a scan,
    listing them, bulk-upserting a complete set, and marking individual rows
    as indexed once they have been imported into the main artifact cache.
    """

    @abc.abstractmethod
    def create(
        self,
        scan_id: int | Any,
        artifact_path: str,
        artifact_type: str,
        change_type: str,
        detected_name: str | None = None,
        content_hash: str | None = None,
        ctx: RequestContext | None = None,
    ) -> GitScanArtifactDTO:
        """Create a single artifact observation for a scan run.

        Args:
            scan_id: FK to the parent ``GitRepoScan`` row.
            artifact_path: Repository-relative path to the artifact directory/file.
            artifact_type: Detected artifact type label (e.g. ``'skill'``, ``'agent'``).
            change_type: Classification relative to previous scan (``'new'``,
                ``'changed'``, ``'removed'``, or ``'unchanged'``).
            detected_name: Human-readable name parsed from frontmatter; ``None``
                when not available.
            content_hash: SHA-256 hex digest (64 chars) of artifact content at
                scan time; ``None`` when content could not be hashed.
            ctx: Optional per-request metadata.

        Returns:
            The newly created observation as a :class:`GitScanArtifactDTO`.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list_by_scan_id(
        self,
        scan_id: int | Any,
        ctx: RequestContext | None = None,
    ) -> list[GitScanArtifactDTO]:
        """Return all artifact observations for a completed scan.

        Args:
            scan_id: FK value to filter on.
            ctx: Optional per-request metadata.

        Returns:
            List of :class:`GitScanArtifactDTO` ordered by ``artifact_path`` ascending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def bulk_upsert(
        self,
        scan_id: int | Any,
        artifacts: list[dict[str, Any]],
        ctx: RequestContext | None = None,
    ) -> list[GitScanArtifactDTO]:
        """Efficiently insert or update a complete set of artifact observations.

        Each dict in *artifacts* must contain at minimum the keys required by
        :meth:`create` (``artifact_path``, ``artifact_type``, ``change_type``).
        Optional keys (``detected_name``, ``content_hash``) are passed through
        when present.

        Existing rows for *scan_id* that match on ``artifact_path`` are updated;
        rows that do not yet exist are inserted.

        Args:
            scan_id: FK to the parent ``GitRepoScan`` row.
            artifacts: List of artifact dicts to upsert.
            ctx: Optional per-request metadata.

        Returns:
            List of created/updated :class:`GitScanArtifactDTO` instances.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update_indexed(
        self,
        artifact_id: int | Any,
        indexed_at: datetime,
        artifact_id_ref: str,
        ctx: RequestContext | None = None,
    ) -> GitScanArtifactDTO | None:
        """Mark an artifact observation as indexed into the main artifact cache.

        Sets ``indexed_at`` to the given timestamp and ``artifact_id`` to the
        cache artifact's ``type:name`` primary key.

        Args:
            artifact_id: Primary key of the ``GitScanArtifact`` row to update.
            indexed_at: UTC timestamp when the artifact was imported.
            artifact_id_ref: ``artifacts.id`` value (``type:name`` format) of
                the corresponding ``Artifact`` row in the main cache.
            ctx: Optional per-request metadata.

        Returns:
            Refreshed :class:`GitScanArtifactDTO`, or ``None`` if the row was not found.
        """
        raise NotImplementedError


# =============================================================================
# IWorkflowRepository
# =============================================================================


class IWorkflowRepository(abc.ABC):
    """Contract for enterprise workflow storage backends.

    Covers CRUD for :class:`EnterpriseWorkflow` definitions and lightweight
    read/write for :class:`EnterpriseWorkflowExecution` instances.

    Design notes
    ------------
    * All IDs are ``uuid.UUID`` objects — never bare strings.
    * ``ctx: RequestContext | None = None`` is the last parameter of every
      method so callers that do not need per-request metadata can omit it.
    * Workflow executions are treated as append-mostly records: updates are
      not exposed through this interface.  Callers mutate execution state
      directly on the returned ORM instance and flush via their own session.
    """

    # ------------------------------------------------------------------
    # Workflow CRUD
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list(
        self,
        offset: int = 0,
        limit: int = 50,
        status: str | None = None,
        after: str | None = None,
        ctx: RequestContext | None = None,
    ) -> list[WorkflowDTO]:
        """Return a paginated list of workflow definitions.

        Args:
            offset: Number of rows to skip (0-based, used when *after* is
                ``None``).
            limit: Maximum number of rows to return (capped at 100).
            status: Optional lifecycle-status filter (e.g. ``"active"``).
            after: Opaque cursor string returned by a previous call; when
                provided, *offset* is ignored and cursor-based pagination is
                used instead.
            ctx: Optional per-request metadata.

        Returns:
            List of WorkflowDTOs ordered by ``created_at`` ascending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get(
        self,
        workflow_id: uuid.UUID,
        ctx: RequestContext | None = None,
    ) -> WorkflowDTO | None:
        """Return the workflow with *workflow_id*, or ``None`` if absent.

        Args:
            workflow_id: UUID primary key of the workflow.
            ctx: Optional per-request metadata.

        Returns:
            The WorkflowDTO, or ``None``.

        Raises:
            TenantIsolationError: If the record belongs to a different tenant.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create(
        self,
        name: str,
        description: str | None = None,
        status: str = "draft",
        config: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> WorkflowDTO:
        """Create a new workflow definition.

        Args:
            name: Human-readable name; must be unique per tenant.
            description: Optional free-text description.
            status: Initial lifecycle status (default ``"draft"``).
            config: Arbitrary JSONB configuration blob.
            ctx: Optional per-request metadata.

        Returns:
            The newly persisted WorkflowDTO (added and flushed).

        Raises:
            ValueError: If a workflow with *name* already exists for the
                current tenant.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        workflow_id: uuid.UUID,
        name: str | None = None,
        description: str | None = None,
        status: str | None = None,
        config: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> WorkflowDTO:
        """Update mutable fields on an existing workflow.

        Only non-``None`` arguments are applied; passing ``None`` leaves the
        corresponding field unchanged.

        Args:
            workflow_id: UUID of the workflow to update.
            name: New name (must remain unique per tenant if provided).
            description: New description.
            status: New lifecycle status.
            config: Replacement configuration blob.
            ctx: Optional per-request metadata.

        Returns:
            The updated WorkflowDTO (already flushed).

        Raises:
            ValueError: If the workflow does not exist.
            TenantIsolationError: If the workflow belongs to a different tenant.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(
        self,
        workflow_id: uuid.UUID,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Delete a workflow and its associated executions and stages.

        Args:
            workflow_id: UUID of the workflow to delete.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` if the workflow existed and was deleted; ``False`` if it
            was not found.

        Raises:
            TenantIsolationError: If the workflow belongs to a different tenant.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Workflow execution helpers
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_executions(
        self,
        workflow_id: uuid.UUID,
        offset: int = 0,
        limit: int = 50,
        status: str | None = None,
        ctx: RequestContext | None = None,
    ) -> list[WorkflowExecutionDTO]:
        """Return executions for *workflow_id* ordered by ``started_at`` descending.

        Args:
            workflow_id: UUID of the parent workflow.
            offset: Number of rows to skip.
            limit: Maximum number of rows to return (capped at 100).
            status: Optional status filter (e.g. ``"failed"``).
            ctx: Optional per-request metadata.

        Returns:
            List of WorkflowExecutionDTOs.

        Raises:
            TenantIsolationError: If the parent workflow belongs to a different tenant.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_execution(
        self,
        execution_id: uuid.UUID,
        ctx: RequestContext | None = None,
    ) -> WorkflowExecutionDTO | None:
        """Return the execution with *execution_id*, or ``None`` if absent.

        Args:
            execution_id: UUID primary key of the execution.
            ctx: Optional per-request metadata.

        Returns:
            The WorkflowExecutionDTO, or ``None``.

        Raises:
            TenantIsolationError: If the record belongs to a different tenant.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create_execution(
        self,
        workflow_id: uuid.UUID,
        context: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> WorkflowExecutionDTO:
        """Create a new execution record for *workflow_id*.

        Args:
            workflow_id: UUID of the parent workflow.
            context: Arbitrary JSONB input context for the run.
            ctx: Optional per-request metadata.

        Returns:
            The newly persisted WorkflowExecutionDTO (added and flushed).

        Raises:
            ValueError: If the parent workflow does not exist.
            TenantIsolationError: If the parent workflow belongs to a different tenant.
        """
        raise NotImplementedError


# =============================================================================
# IMemoryItemRepository
# =============================================================================


class IMemoryItemRepository(abc.ABC):
    """Contract for enterprise memory-item storage backends.

    Covers CRUD for :class:`EnterpriseMemoryItem` records and a case-insensitive
    full-text search across ``content`` fields.

    Design notes
    ------------
    * All IDs are ``uuid.UUID`` objects — never bare strings.
    * ``ctx: RequestContext | None = None`` is the last parameter of every
      method so callers that do not need per-request metadata can omit it.
    * The ``search()`` method filters by ``content ILIKE '%query%'``; callers
      must handle empty-string queries (returns all items for the tenant).
    """

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list(
        self,
        offset: int = 0,
        limit: int = 50,
        status: str | None = None,
        after: str | None = None,
        ctx: RequestContext | None = None,
    ) -> list[MemoryItemDTO]:
        """Return a paginated list of memory items for the current tenant.

        Args:
            offset: Number of rows to skip (0-based, used when *after* is
                ``None``).
            limit: Maximum number of rows to return (capped at 100).
            status: Optional lifecycle-status filter (e.g. ``"candidate"``).
            after: Opaque cursor string returned by a previous call; when
                provided, *offset* is ignored and cursor-based pagination is
                used instead.
            ctx: Optional per-request metadata.

        Returns:
            List of memory-item ORM instances ordered by ``created_at``
            ascending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get(
        self,
        item_id: uuid.UUID,
        ctx: RequestContext | None = None,
    ) -> MemoryItemDTO | None:
        """Return the memory item with *item_id*, or ``None`` if absent.

        Args:
            item_id: UUID primary key of the memory item.
            ctx: Optional per-request metadata.

        Returns:
            The ORM instance, or ``None``.

        Raises:
            TenantIsolationError: If the record belongs to a different tenant.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create(
        self,
        content: str,
        type: str,
        status: str = "candidate",
        confidence: float | None = None,
        anchor: str | None = None,
        provenance: dict[str, Any] | None = None,
        project_id: uuid.UUID | None = None,
        ctx: RequestContext | None = None,
    ) -> MemoryItemDTO:
        """Create a new memory item scoped to the current tenant.

        Args:
            content: Full-text content of the memory item (required).
            type: Memory type — one of ``'decision'``, ``'constraint'``,
                ``'gotcha'``, ``'style_rule'``, or ``'learning'``.
            status: Initial lifecycle status (default ``"candidate"``).
            confidence: Confidence score in ``[0.0, 1.0]``; ``None`` when
                not assessed.
            anchor: Optional source-location anchor string.
            provenance: Arbitrary JSONB provenance metadata.
            project_id: Optional FK to the owning enterprise project.
            ctx: Optional per-request metadata.

        Returns:
            The newly persisted ORM instance (added and flushed).
        """
        raise NotImplementedError

    @abc.abstractmethod
    def update(
        self,
        item_id: uuid.UUID,
        content: str | None = None,
        type: str | None = None,
        status: str | None = None,
        confidence: float | None = None,
        anchor: str | None = None,
        provenance: dict[str, Any] | None = None,
        ctx: RequestContext | None = None,
    ) -> MemoryItemDTO:
        """Update mutable fields on an existing memory item.

        Only non-``None`` arguments are applied; passing ``None`` leaves the
        corresponding field unchanged.

        Args:
            item_id: UUID of the memory item to update.
            content: Replacement full-text content.
            type: New memory type.
            status: New lifecycle status.
            confidence: New confidence score.
            anchor: New source-location anchor.
            provenance: Replacement provenance blob.
            ctx: Optional per-request metadata.

        Returns:
            The updated ORM instance (already flushed).

        Raises:
            ValueError: If the memory item does not exist.
            TenantIsolationError: If the record belongs to a different tenant.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete(
        self,
        item_id: uuid.UUID,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Delete a memory item.

        Args:
            item_id: UUID of the memory item to delete.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` if the item existed and was deleted; ``False`` if it was
            not found.

        Raises:
            TenantIsolationError: If the record belongs to a different tenant.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def search(
        self,
        query: str,
        offset: int = 0,
        limit: int = 50,
        ctx: RequestContext | None = None,
    ) -> list[MemoryItemDTO]:
        """Search memory items by content using case-insensitive matching.

        Filters rows where ``content ILIKE '%query%'``.  An empty *query*
        string returns all items for the current tenant (up to *limit*).

        Args:
            query: Free-form search string; wrapped in ``%…%`` wildcards.
            offset: Number of rows to skip.
            limit: Maximum number of rows to return (capped at 100).
            ctx: Optional per-request metadata.

        Returns:
            List of matching memory-item ORM instances ordered by
            ``created_at`` ascending.
        """
        raise NotImplementedError


# =============================================================================
# IBomRepository
# =============================================================================


class IBomRepository(abc.ABC):
    """Contract for enterprise BOM (Bill of Materials) / attestation backends.

    Covers CRUD for :class:`EnterpriseBomSnapshot` records and read/create
    for :class:`EnterpriseAttestationRecord` records.

    Design notes
    ------------
    * All IDs are ``uuid.UUID`` objects — never bare strings.
    * ``ctx: RequestContext | None = None`` is the last parameter of every
      method so callers that do not need per-request metadata can omit it.
    * Attestations are append-mostly audit records; deletion is intentionally
      excluded from this interface.
    """

    # ------------------------------------------------------------------
    # Snapshot CRUD
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_snapshots(
        self,
        artifact_id: uuid.UUID | None = None,
        offset: int = 0,
        limit: int = 50,
        after: str | None = None,
        ctx: "RequestContext | None" = None,
    ) -> list[BomSnapshotDTO]:
        """Return a paginated list of BOM snapshots for the current tenant.

        Args:
            artifact_id: Optional filter to restrict results to snapshots for
                a specific artifact UUID.
            offset: Number of rows to skip (0-based, used when *after* is
                ``None``).
            limit: Maximum number of rows to return (capped at 100).
            after: Opaque cursor string returned by a previous call; when
                provided, *offset* is ignored and cursor-based pagination is
                used instead.
            ctx: Optional per-request metadata.

        Returns:
            List of BomSnapshotDTOs ordered by ``created_at`` ascending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_snapshot(
        self,
        snapshot_id: uuid.UUID,
        ctx: "RequestContext | None" = None,
    ) -> BomSnapshotDTO | None:
        """Return the BOM snapshot with *snapshot_id*, or ``None`` if absent.

        Args:
            snapshot_id: UUID primary key of the snapshot.
            ctx: Optional per-request metadata.

        Returns:
            The BomSnapshotDTO, or ``None``.

        Raises:
            TenantIsolationError: If the record belongs to a different tenant.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create_snapshot(
        self,
        artifact_id: uuid.UUID,
        snapshot_data: dict[str, Any],
        format_version: str | None = None,
        generated_at: Any | None = None,
        ctx: "RequestContext | None" = None,
    ) -> BomSnapshotDTO:
        """Create a new BOM snapshot scoped to the current tenant.

        Args:
            artifact_id: FK to the enterprise artifact this snapshot describes.
            snapshot_data: JSONB BOM payload (components, dependencies, etc.).
            format_version: Optional format discriminator, e.g. ``'spdx-2.3'``,
                ``'cyclonedx-1.5'``; ``None`` means unspecified/custom.
            generated_at: Optional timezone-aware datetime when the BOM was
                generated; defaults to server time when ``None``.
            ctx: Optional per-request metadata.

        Returns:
            The newly persisted BomSnapshotDTO (added and flushed).
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete_snapshot(
        self,
        snapshot_id: uuid.UUID,
        ctx: "RequestContext | None" = None,
    ) -> bool:
        """Delete a BOM snapshot (and cascade-delete its attestation records).

        Args:
            snapshot_id: UUID of the snapshot to delete.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` if the snapshot existed and was deleted; ``False`` if it
            was not found.

        Raises:
            TenantIsolationError: If the record belongs to a different tenant.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Attestation operations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def list_attestations(
        self,
        snapshot_id: uuid.UUID | None = None,
        offset: int = 0,
        limit: int = 50,
        after: str | None = None,
        ctx: "RequestContext | None" = None,
    ) -> list[AttestationRecordDTO]:
        """Return a paginated list of attestation records for the current tenant.

        Args:
            snapshot_id: Optional filter to restrict results to attestations
                for a specific snapshot UUID.
            offset: Number of rows to skip (0-based, used when *after* is
                ``None``).
            limit: Maximum number of rows to return (capped at 100).
            after: Opaque cursor string returned by a previous call; when
                provided, *offset* is ignored.
            ctx: Optional per-request metadata.

        Returns:
            List of AttestationRecordDTOs ordered by ``created_at`` ascending.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_attestation(
        self,
        attestation_id: uuid.UUID,
        ctx: "RequestContext | None" = None,
    ) -> AttestationRecordDTO | None:
        """Return the attestation record with *attestation_id*, or ``None``.

        Args:
            attestation_id: UUID primary key of the attestation record.
            ctx: Optional per-request metadata.

        Returns:
            The AttestationRecordDTO, or ``None``.

        Raises:
            TenantIsolationError: If the record belongs to a different tenant.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create_attestation(
        self,
        snapshot_id: uuid.UUID,
        result: str,
        policy_id: uuid.UUID | None = None,
        attested_at: Any | None = None,
        evidence: dict[str, Any] | None = None,
        ctx: "RequestContext | None" = None,
    ) -> AttestationRecordDTO:
        """Create a new attestation record for a BOM snapshot.

        Args:
            snapshot_id: FK to the ``EnterpriseBomSnapshot`` being attested.
            result: Attestation outcome — one of ``'pass'``, ``'fail'``,
                ``'warning'``, or ``'error'``.
            policy_id: Optional FK to ``EnterpriseAttestationPolicy``; ``None``
                when no formal policy is referenced.
            attested_at: Optional timezone-aware datetime when the attestation
                was run; defaults to server time when ``None``.
            evidence: Optional JSONB supporting data (rule failures, scores,
                tool output).
            ctx: Optional per-request metadata.

        Returns:
            The newly persisted AttestationRecordDTO (added and flushed).

        Raises:
            ValueError: If the referenced snapshot does not exist or belongs to
                a different tenant.
        """
        raise NotImplementedError
