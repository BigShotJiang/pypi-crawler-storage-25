"""Domain Data Transfer Objects for SkillMeat's hexagonal architecture.

Pure Python dataclasses that carry data across layer boundaries without leaking
ORM models (SQLAlchemy) or API framework types (Pydantic) into the core.

Design invariants:
- No Pydantic, no SQLAlchemy — stdlib only.
- Only allowed skillmeat import: ``skillmeat.core.enums``.
- All optional fields default to ``None``; list fields default to ``[]``.
- Dates are stored as ISO-8601 strings so the core stays timezone-naive.
- DTOs are frozen to enforce immutability at the layer boundary.
- Each DTO exposes a ``from_dict`` classmethod for convenient construction
  from plain dicts (e.g. repository query results, JSON payloads).

Usage::

    from skillmeat.core.interfaces import ArtifactDTO, ProjectDTO

    artifact = ArtifactDTO.from_dict(row)
    project  = ProjectDTO(id="abc", name="my-project", path="/home/user/proj")
"""

from __future__ import annotations

import dataclasses
import sys
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Self compat shim: typing.Self was added in Python 3.11; use the backport
# from typing_extensions on older interpreters.
# ---------------------------------------------------------------------------
if sys.version_info >= (3, 11):
    from typing import Self
else:
    try:
        from typing_extensions import Self
    except ImportError:  # typing_extensions not installed — define a fallback
        from typing import TypeVar as _TypeVar

        Self = _TypeVar("Self")  # type: ignore[assignment,misc]


__all__ = [
    "ArtifactDTO",
    "ProjectDTO",
    "CollectionDTO",
    "DeploymentDTO",
    "TagDTO",
    "SettingsDTO",
    "CollectionMembershipDTO",
    "EntityTypeConfigDTO",
    "CategoryDTO",
    # Groups
    "GroupDTO",
    "GroupArtifactDTO",
    # Context entities
    "ContextEntityDTO",
    # Marketplace
    "MarketplaceSourceDTO",
    "CatalogEntryDTO",
    "CatalogItemDTO",
    # Project templates
    "ProjectTemplateDTO",
    "TemplateEntityDTO",
    # User collections (DB-backed)
    "UserCollectionDTO",
    "CollectionArtifactDTO",
    # Artifact history (DB-backed)
    "CacheArtifactSummaryDTO",
    "ArtifactVersionDTO",
    # VCS v2 (artifact-vcs-v2)
    "ArtifactCollectionVersionDTO",
    "ProjectVersionDeploymentDTO",
    # Deployment sets (repository-dto-migration)
    "DeploymentSetDTO",
    "DeploymentSetMemberDTO",
    # Governance (repository-dto-migration)
    "GovernancePolicyDTO",
    # Enterprise polymorphic response (repository-dto-migration)
    "EnterpriseArtifactResponseDTO",
    # Enterprise collection (repository-dto-migration Phase 2)
    "EnterpriseCollectionDTO",
    # Git repo connections / scanning (repository-dto-migration v2)
    "GitRepoConnectionDTO",
    "GitRepoScanDTO",
    "GitScanArtifactDTO",
    # Artifact activity (repository-dto-migration v2)
    "ActivityEventDTO",
    # Bundle domain (repository-dto-migration v2 Phase 3)
    "BundleMembershipDTO",
    "BundleDTO",
    "BundleListDTO",
    # Collection stats (repository-dto-migration v2 Phase 5)
    "CollectionStatsDTO",
    # Template deploy result (repository-dto-migration v2 Phase 5)
    "TemplateDeployResultDTO",
    # Batch helper DTOs (repository-dto-migration v2 Phase 5)
    "SourceDeploymentEntryDTO",
    "GroupMembershipEntryDTO",
    "StalenessStatsDTO",
    # Enterprise-only DTOs (repository-dto-migration v2 Phase 8 gap closure)
    "ProjectGitConnectionDTO",
    "GitCredentialDTO",
    "DeploymentProfileDTO",
    "ArtifactVersionScopeDTO",
]


# =============================================================================
# ArtifactDTO
# =============================================================================


@dataclass(frozen=True)
class ArtifactDTO:
    """Lightweight representation of a cached artifact.

    Maps from the ``Artifact`` ORM model.  All mutable collections are
    represented as tuples to preserve the frozen contract.

    Attributes:
        id: Primary-key string in ``"type:name"`` format.
        uuid: Stable cross-context UUID (hex, 32 chars).
        name: Human-readable artifact name.
        artifact_type: Artifact category (skill, command, agent, …).
        source: Upstream source spec (e.g. ``"github:owner/repo/path"``).
        version: Resolved version string at the time of caching.
        scope: Deployment scope (user / local).
        description: Short human-readable description.
        content_path: Filesystem path to the artifact content.
        metadata: Arbitrary key/value metadata from YAML frontmatter.
        tags: Tag name strings associated with this artifact.
        is_outdated: True when an upstream update is available.
        local_modified: True when local edits have been detected.
        project_id: ID of the project that owns this artifact entry.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    name: str
    artifact_type: str
    uuid: str | None = None
    source: str | None = None
    version: str | None = None
    scope: str | None = None
    description: str | None = None
    content_path: str | None = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: Tuple[str, ...] = field(default_factory=tuple)
    is_outdated: bool = False
    local_modified: bool = False
    project_id: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct an ArtifactDTO from a plain dictionary.

        Unknown keys are silently ignored so callers can pass raw ORM
        ``to_dict()`` output without pre-filtering.

        Args:
            data: Mapping that contains at minimum ``id``, ``name``, and
                ``artifact_type`` (or ``type`` as an alias).

        Returns:
            A fully populated :class:`ArtifactDTO`.
        """
        return cls(
            id=data["id"],
            name=data["name"],
            # Accept both "artifact_type" (DTO convention) and "type" (ORM column)
            artifact_type=data.get("artifact_type") or data.get("type") or "",
            uuid=data.get("uuid"),
            source=data.get("source"),
            version=data.get("deployed_version") or data.get("version"),
            scope=data.get("scope"),
            description=data.get("description"),
            content_path=data.get("content_path"),
            metadata=dict(data.get("metadata") or {}),
            tags=tuple(data.get("tags") or []),
            is_outdated=bool(data.get("is_outdated", False)),
            local_modified=bool(data.get("local_modified", False)),
            project_id=data.get("project_id"),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# ProjectDTO
# =============================================================================


@dataclass(frozen=True)
class ProjectDTO:
    """Lightweight representation of a cached project.

    Maps from the ``Project`` ORM model.

    Attributes:
        id: Base64-encoded project path (primary key).
        name: Project directory name.
        path: Absolute filesystem path.
        description: Optional project description.
        status: Project cache status (active / stale / error).
        artifact_count: Number of artifacts deployed to this project.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
        last_fetched: ISO-8601 timestamp of most-recent cache refresh.
    """

    id: str
    name: str
    path: str
    description: str | None = None
    status: str = "active"
    artifact_count: int = 0
    created_at: str | None = None
    updated_at: str | None = None
    last_fetched: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a ProjectDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id``, ``name``,
                and ``path``.

        Returns:
            A fully populated :class:`ProjectDTO`.
        """
        return cls(
            id=data["id"],
            name=data["name"],
            path=data["path"],
            description=data.get("description"),
            status=data.get("status", "active"),
            artifact_count=int(data.get("artifact_count", 0)),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
            last_fetched=_to_iso(data.get("last_fetched")),
        )


# =============================================================================
# CollectionDTO
# =============================================================================


@dataclass(frozen=True)
class CollectionDTO:
    """Lightweight representation of an artifact collection.

    A collection is a named set of artifacts managed by the user.

    Attributes:
        id: Collection unique identifier (usually the collection name).
        name: Human-readable collection name.
        path: Absolute filesystem path to the collection directory.
        version: Collection format version string.
        artifact_count: Number of artifacts in this collection.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    name: str
    path: str | None = None
    version: str = "1.0.0"
    artifact_count: int = 0
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a CollectionDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id`` and ``name``.

        Returns:
            A fully populated :class:`CollectionDTO`.
        """
        return cls(
            id=data["id"],
            name=data["name"],
            path=data.get("path"),
            version=data.get("version", "1.0.0"),
            artifact_count=int(data.get("artifact_count", 0)),
            created_at=_to_iso(data.get("created_at") or data.get("created")),
            updated_at=_to_iso(data.get("updated_at") or data.get("updated")),
        )


# =============================================================================
# DeploymentDTO
# =============================================================================


@dataclass(frozen=True)
class DeploymentDTO:
    """Lightweight representation of a single artifact deployment.

    Captures the result of deploying an artifact from a collection to a
    project directory.

    Attributes:
        id: Deployment record identifier (often ``"type:name"``).
        artifact_id: Identifier of the deployed artifact.
        artifact_name: Human-readable artifact name.
        artifact_type: Artifact category (skill, command, …).
        project_id: Identifier of the target project.
        project_path: Absolute filesystem path to the target project.
        project_name: Display name of the target project.
        from_collection: Source collection name.
        scope: Deployment scope (user / local).
        status: Current deployment status string.
        deployed_at: ISO-8601 timestamp when the deployment occurred.
        source_path: Filesystem path of the artifact in the collection.
        target_path: Filesystem path where the artifact was deployed.
        collection_sha: Content hash at deployment time.
        local_modifications: True when post-deploy edits have been detected.
        deployment_profile_id: Profile identifier used for this deployment.
        platform: Target platform string.
    """

    id: str
    artifact_id: str
    artifact_name: str
    artifact_type: str
    project_id: str | None = None
    project_path: str | None = None
    project_name: str | None = None
    from_collection: str | None = None
    scope: str | None = None
    status: str = "deployed"
    deployed_at: str | None = None
    source_path: str | None = None
    target_path: str | None = None
    collection_sha: str | None = None
    local_modifications: bool = False
    deployment_profile_id: str | None = None
    platform: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a DeploymentDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id``, ``artifact_id``,
                ``artifact_name``, and ``artifact_type``.

        Returns:
            A fully populated :class:`DeploymentDTO`.
        """
        return cls(
            id=data["id"],
            artifact_id=data["artifact_id"],
            artifact_name=data.get("artifact_name", ""),
            artifact_type=data.get("artifact_type", ""),
            project_id=data.get("project_id"),
            project_path=data.get("project_path"),
            project_name=data.get("project_name"),
            from_collection=data.get("from_collection"),
            scope=data.get("scope"),
            status=data.get("status", "deployed"),
            deployed_at=_to_iso(data.get("deployed_at")),
            source_path=data.get("source_path"),
            target_path=data.get("target_path") or data.get("deployed_path"),
            collection_sha=data.get("collection_sha") or data.get("content_hash"),
            local_modifications=bool(data.get("local_modifications", False)),
            deployment_profile_id=data.get("deployment_profile_id"),
            platform=data.get("platform"),
        )


# =============================================================================
# TagDTO
# =============================================================================


@dataclass(frozen=True)
class TagDTO:
    """Lightweight representation of an artifact tag.

    Attributes:
        id: Tag unique identifier.
        name: Human-readable tag name.
        slug: URL-friendly kebab-case slug.
        color: Optional hex color code (e.g. ``"#FF5733"``).
        artifact_count: Number of artifacts carrying this tag.
        deployment_set_count: Number of deployment sets carrying this tag.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    name: str
    slug: str
    color: str | None = None
    artifact_count: int = 0
    deployment_set_count: int = 0
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a TagDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id``, ``name``,
                and ``slug``.

        Returns:
            A fully populated :class:`TagDTO`.
        """
        return cls(
            id=data["id"],
            name=data["name"],
            slug=data["slug"],
            color=data.get("color"),
            artifact_count=int(data.get("artifact_count") or 0),
            deployment_set_count=int(data.get("deployment_set_count") or 0),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# SettingsDTO
# =============================================================================


@dataclass(frozen=True)
class SettingsDTO:
    """Application-level settings snapshot.

    Carries the current user configuration for consumption by routers and
    services without exposing the underlying config manager or Pydantic models.

    Attributes:
        github_token: Configured GitHub Personal Access Token (masked or raw).
        collection_path: Absolute path to the user's artifact collection.
        default_scope: Default deployment scope (``"user"`` or ``"local"``).
        edition: Application edition identifier (e.g. ``"community"``).
        indexing_mode: Global artifact search indexing mode
            (``"off"`` | ``"on"`` | ``"opt_in"``).
        extra: Any additional key/value settings not covered above.
    """

    github_token: str | None = None
    collection_path: str | None = None
    default_scope: str = "user"
    edition: str = "community"
    indexing_mode: str = "opt_in"
    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a SettingsDTO from a plain dictionary.

        All keys in *data* that do not map to known fields are collected into
        ``extra`` so no information is silently discarded.

        Args:
            data: Flat configuration mapping (e.g. from ConfigManager).

        Returns:
            A fully populated :class:`SettingsDTO`.
        """
        known = {
            "github_token",
            "collection_path",
            "default_scope",
            "edition",
            "indexing_mode",
        }
        return cls(
            github_token=data.get("github_token"),
            collection_path=data.get("collection_path"),
            default_scope=data.get("default_scope", "user"),
            edition=data.get("edition", "community"),
            indexing_mode=data.get("indexing_mode", "opt_in"),
            extra={k: v for k, v in data.items() if k not in known},
        )


# =============================================================================
# CollectionMembershipDTO
# =============================================================================


@dataclass(frozen=True)
class CollectionMembershipDTO:
    """Records that an artifact belongs to a named collection.

    Attributes:
        collection_id: Unique identifier of the collection (collection name).
        collection_name: Human-readable collection name.
        artifact_uuid: Stable UUID of the artifact (per ADR-007).
        artifact_id: Artifact primary key in ``"type:name"`` format.
        added_at: ISO-8601 timestamp when the artifact was added to the
            collection, or ``None`` when not tracked.
    """

    collection_id: str
    collection_name: str
    artifact_uuid: str | None = None
    artifact_id: str | None = None
    added_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a CollectionMembershipDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``collection_id``
                and ``collection_name``.

        Returns:
            A fully populated :class:`CollectionMembershipDTO`.
        """
        return cls(
            collection_id=data["collection_id"],
            collection_name=data["collection_name"],
            artifact_uuid=data.get("artifact_uuid"),
            artifact_id=data.get("artifact_id"),
            added_at=_to_iso(data.get("added_at")),
        )


# =============================================================================
# EntityTypeConfigDTO
# =============================================================================


@dataclass(frozen=True)
class EntityTypeConfigDTO:
    """Configuration record for a custom entity type.

    Entity types extend the artifact model with user-defined groupings
    (e.g. ``"workflow"``, ``"dataset"``).

    Attributes:
        id: Unique identifier for the entity type config record.
        entity_type: Machine-readable entity type key (e.g. ``"workflow"``).
        display_name: Human-readable display name.
        description: Optional description of this entity type.
        icon: Optional icon identifier or URL.
        color: Optional hex color code for UI display (e.g. ``"#FF5733"``).
        is_system: True when this config is built-in (not user-created).
        sort_order: Display ordering (ascending).
        path_prefix: Default filesystem path prefix for this type.
        required_frontmatter_keys: Frontmatter keys that must be present.
        optional_frontmatter_keys: Frontmatter keys that may be present.
        validation_rules: Additional validation configuration dict.
        example_path: Example path illustrating this entity type.
        content_template: Default Markdown template for new entities.
        applicable_platforms: Platform slugs this type applies to; ``None``
            means all platforms.
        frontmatter_schema: JSON Schema subset for frontmatter validation.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    entity_type: str
    display_name: str
    description: str | None = None
    icon: str | None = None
    color: str | None = None
    is_system: bool = False
    sort_order: int = 0
    path_prefix: str | None = None
    required_frontmatter_keys: Tuple[str, ...] | None = None
    optional_frontmatter_keys: Tuple[str, ...] | None = None
    validation_rules: Dict[str, Any] | None = None
    example_path: str | None = None
    content_template: str | None = None
    applicable_platforms: Tuple[str, ...] | None = None
    frontmatter_schema: Dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct an EntityTypeConfigDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id``, ``entity_type``,
                and ``display_name``.

        Returns:
            A fully populated :class:`EntityTypeConfigDTO`.
        """
        return cls(
            id=data["id"],
            entity_type=data["entity_type"],
            display_name=data["display_name"],
            description=data.get("description"),
            icon=data.get("icon"),
            color=data.get("color"),
            is_system=bool(data.get("is_system", False)),
            sort_order=int(data.get("sort_order") or 0),
            path_prefix=data.get("path_prefix"),
            required_frontmatter_keys=(
                tuple(data["required_frontmatter_keys"])
                if data.get("required_frontmatter_keys") is not None
                else None
            ),
            optional_frontmatter_keys=(
                tuple(data["optional_frontmatter_keys"])
                if data.get("optional_frontmatter_keys") is not None
                else None
            ),
            validation_rules=data.get("validation_rules"),
            example_path=data.get("example_path"),
            content_template=data.get("content_template"),
            applicable_platforms=(
                tuple(data["applicable_platforms"])
                if data.get("applicable_platforms") is not None
                else None
            ),
            frontmatter_schema=data.get("frontmatter_schema"),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# CategoryDTO
# =============================================================================


@dataclass(frozen=True)
class CategoryDTO:
    """A user-defined category that can be applied to entities.

    Categories provide a secondary classification axis beyond artifact type,
    allowing users to group entities by purpose, domain, or any other
    meaningful attribute.

    Attributes:
        id: Unique identifier for the category record.
        name: Human-readable category name (must be unique within
            ``entity_type``).
        slug: URL-safe machine identifier.
        entity_type: The entity type this category applies to, or ``None``
            for cross-type categories.
        description: Optional description of what this category represents.
        color: Optional hex color code for UI display (e.g. ``"#00FF00"``).
        platform: Optional platform scope filter.
        sort_order: Ascending display order in the UI.
        is_builtin: True when this category is system-seeded.
        artifact_count: Number of artifacts assigned to this category.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    name: str
    slug: str = ""
    entity_type: str | None = None
    description: str | None = None
    color: str | None = None
    platform: str | None = None
    sort_order: int = 0
    is_builtin: bool = False
    artifact_count: int = 0
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a CategoryDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id`` and ``name``.

        Returns:
            A fully populated :class:`CategoryDTO`.
        """
        return cls(
            id=data["id"],
            name=data["name"],
            slug=data.get("slug", ""),
            entity_type=data.get("entity_type"),
            description=data.get("description"),
            color=data.get("color"),
            platform=data.get("platform"),
            sort_order=int(data.get("sort_order") or 0),
            is_builtin=bool(data.get("is_builtin", False)),
            artifact_count=int(data.get("artifact_count") or 0),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# GroupDTO
# =============================================================================


@dataclass(frozen=True)
class GroupDTO:
    """Lightweight representation of an artifact group within a collection.

    Groups let users organise collection artifacts into named, position-ordered
    buckets.  Each group belongs to exactly one collection.

    Attributes:
        id: Integer primary key (stored as ``str`` for DTO uniformity).
        name: Human-readable group name.
        collection_id: Identifier of the owning collection.
        description: Optional group description.
        position: Zero-based display order within the collection.
        artifact_count: Number of artifacts currently in this group.
        tags: List of tag strings attached to the group.
        color: Display colour slug (e.g. ``"slate"``).  Defaults to ``"slate"``.
        icon: Display icon slug (e.g. ``"layers"``).  Defaults to ``"layers"``.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    name: str
    collection_id: str
    description: str | None = None
    position: int = 0
    artifact_count: int = 0
    tags: Tuple[str, ...] = field(default_factory=tuple)
    color: str = "slate"
    icon: str = "layers"
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a GroupDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id``, ``name``,
                and ``collection_id``.

        Returns:
            A fully populated :class:`GroupDTO`.
        """
        return cls(
            id=str(data["id"]),
            name=data["name"],
            collection_id=str(data["collection_id"]),
            description=data.get("description"),
            position=int(data.get("position") or 0),
            artifact_count=int(data.get("artifact_count") or 0),
            tags=tuple(data.get("tags") or []),
            color=data.get("color") or "slate",
            icon=data.get("icon") or "layers",
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# GroupArtifactDTO
# =============================================================================


@dataclass(frozen=True)
class GroupArtifactDTO:
    """Records that an artifact is a member of a group.

    Carries the position-based ordering of artifacts within a group.

    Attributes:
        group_id: Integer primary key of the owning group (as ``str``).
        artifact_uuid: Stable ADR-007 UUID of the artifact.
        position: Zero-based display order within the group.
        added_at: ISO-8601 timestamp when the artifact was added to the group.
    """

    group_id: str
    artifact_uuid: str
    position: int = 0
    added_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a GroupArtifactDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``group_id`` and
                ``artifact_uuid``.

        Returns:
            A fully populated :class:`GroupArtifactDTO`.
        """
        return cls(
            group_id=str(data["group_id"]),
            artifact_uuid=data["artifact_uuid"],
            position=int(data.get("position") or 0),
            added_at=_to_iso(data.get("added_at")),
        )


# =============================================================================
# ContextEntityDTO
# =============================================================================


@dataclass(frozen=True)
class ContextEntityDTO:
    """Lightweight representation of a context entity artifact.

    Context entities are special artifacts (CLAUDE.md, spec files, rule files,
    context files, progress templates) that define project structure, rules, and
    context for Claude Code projects.

    Attributes:
        id: Artifact primary key (e.g. ``"ctx_abc123"``).
        name: Human-readable entity name.
        entity_type: Entity type key (``"project_config"``, ``"spec_file"``,
            ``"rule_file"``, ``"context_file"``, ``"progress_template"``).
        content: Assembled markdown content.
        path_pattern: Target path pattern for deployment (e.g. ``".claude/CLAUDE.md"``).
        description: Optional description.
        category: Optional category for progressive disclosure (e.g. ``"api"``).
        auto_load: Whether the entity should be auto-loaded by the platform.
        version: Optional version string.
        target_platforms: Optional list of target platform identifiers.
        content_hash: SHA-256 hex hash of the current content for change detection.
        category_ids: Ordered list of category IDs associated with this entity.
        core_content: Platform-agnostic source content (modular content architecture).
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    name: str
    entity_type: str
    content: str = ""
    path_pattern: str = ""
    description: str | None = None
    category: str | None = None
    auto_load: bool = False
    version: str | None = None
    target_platforms: Tuple[str, ...] = field(default_factory=tuple)
    content_hash: str | None = None
    category_ids: Tuple[int, ...] = field(default_factory=tuple)
    core_content: str | None = None
    context_module_id: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a ContextEntityDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id``, ``name``,
                and ``entity_type`` (or ``type`` as an alias).

        Returns:
            A fully populated :class:`ContextEntityDTO`.
        """
        raw_platforms = data.get("target_platforms") or []
        return cls(
            id=data["id"],
            name=data["name"],
            entity_type=data.get("entity_type") or data.get("type") or "",
            content=data.get("content") or "",
            path_pattern=data.get("path_pattern") or "",
            description=data.get("description"),
            category=data.get("category"),
            auto_load=bool(data.get("auto_load", False)),
            version=data.get("version") or data.get("deployed_version"),
            target_platforms=tuple(raw_platforms),
            content_hash=data.get("content_hash"),
            category_ids=tuple(data.get("category_ids") or []),
            core_content=data.get("core_content"),
            context_module_id=data.get("context_module_id"),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# MarketplaceSourceDTO
# =============================================================================


@dataclass(frozen=True)
class MarketplaceSourceDTO:
    """Lightweight representation of a marketplace broker/source.

    A marketplace source is a configured endpoint (broker) that provides
    listings of artifacts available for installation.

    Attributes:
        id: Source unique identifier (usually the broker name).
        name: Human-readable source name.
        enabled: Whether this source is currently active.
        endpoint: Base URL for the broker API.
        description: Optional description of this source.
        supports_publish: Whether this source allows publishing new listings.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    name: str
    enabled: bool = False
    endpoint: str = ""
    description: str | None = None
    supports_publish: bool = False
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a MarketplaceSourceDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id`` and ``name``.

        Returns:
            A fully populated :class:`MarketplaceSourceDTO`.
        """
        return cls(
            id=data["id"],
            name=data["name"],
            enabled=bool(data.get("enabled", False)),
            endpoint=data.get("endpoint") or "",
            description=data.get("description"),
            supports_publish=bool(data.get("supports_publish", False)),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# CatalogEntryDTO
# =============================================================================


@dataclass(frozen=True)
class CatalogEntryDTO:
    """Typed representation of a ``MarketplaceCatalogEntry`` row.

    Carries all fields that API endpoints need after a catalog-entry read or
    mutation, without exposing the ORM object across layer boundaries.

    Dates are stored as ISO-8601 strings (``None`` when not set) following the
    project-wide DTO convention.

    Attributes:
        id: Primary key (catalog entry identifier).
        source_id: FK to the owning marketplace source.
        artifact_type: Artifact type label (e.g. ``"skill"``, ``"command"``).
        name: Artifact name.
        path: Relative path inside the source repository.
        upstream_url: Full URL to the artifact in its upstream repository.
        detected_version: Extracted version string, if any.
        detected_sha: Git commit SHA at detection time, if any.
        detected_at: ISO-8601 timestamp of when the artifact was detected.
        confidence_score: Heuristic confidence 0-100.
        raw_score: Raw confidence score before normalisation, if present.
        score_breakdown: JSON-serialisable dict of scoring components, if
            present.
        status: Current lifecycle status (``"new"``, ``"imported"``,
            ``"excluded"``, etc.).
        import_date: ISO-8601 timestamp of when the entry was imported.
        import_id: Reference to the imported artifact identifier.
        excluded_at: ISO-8601 timestamp when the entry was excluded, or
            ``None``.
        excluded_reason: Human-readable exclusion reason, or ``None``.
        path_segments: Serialised JSON string of extracted path segments with
            approval status, or ``None`` when not yet extracted.
    """

    id: str
    source_id: str
    artifact_type: str
    name: str
    path: str
    upstream_url: str
    detected_at: str | None = None
    confidence_score: int = 0
    raw_score: int | None = None
    score_breakdown: Dict[str, Any] | None = None
    detected_version: str | None = None
    detected_sha: str | None = None
    status: str = "new"
    import_date: str | None = None
    import_id: str | None = None
    excluded_at: str | None = None
    excluded_reason: str | None = None
    path_segments: str | None = None

    @classmethod
    def from_orm(cls, entry: Any) -> "CatalogEntryDTO":
        """Build a :class:`CatalogEntryDTO` from a ``MarketplaceCatalogEntry``
        ORM instance.

        The ORM object is accessed attribute-by-attribute so no SQLAlchemy
        import is required in this module.

        Args:
            entry: A ``MarketplaceCatalogEntry`` SQLAlchemy model instance.

        Returns:
            An immutable :class:`CatalogEntryDTO`.
        """
        return cls(
            id=entry.id,
            source_id=entry.source_id,
            artifact_type=entry.artifact_type,
            name=entry.name,
            path=entry.path,
            upstream_url=entry.upstream_url,
            detected_version=entry.detected_version,
            detected_sha=entry.detected_sha,
            detected_at=_to_iso(entry.detected_at),
            confidence_score=int(entry.confidence_score),
            raw_score=int(entry.raw_score) if entry.raw_score is not None else None,
            score_breakdown=entry.score_breakdown,
            status=entry.status,
            import_date=_to_iso(entry.import_date),
            import_id=entry.import_id,
            excluded_at=_to_iso(entry.excluded_at),
            excluded_reason=entry.excluded_reason,
            path_segments=entry.path_segments,
        )


# =============================================================================
# CatalogItemDTO
# =============================================================================


@dataclass(frozen=True)
class CatalogItemDTO:
    """Lightweight representation of a single marketplace catalog listing.

    Each catalog item represents one publishable artifact bundle available
    from a marketplace source/broker.

    Attributes:
        listing_id: Unique identifier for this listing within its source.
        name: Human-readable listing name.
        source_id: Identifier of the broker/source that provides this listing.
        publisher: Publisher or author name.
        description: Optional listing description.
        license: SPDX license identifier (e.g. ``"MIT"``).
        version: Version string.
        artifact_count: Number of artifacts bundled in this listing.
        tags: Tag strings categorising this listing.
        source_url: URL to the upstream source repository or page.
        bundle_url: URL to the downloadable bundle archive.
        signature: Bundle signature for integrity verification.
        downloads: Total download count.
        rating: Average rating (0-5 scale).
        price: Price string (``None`` or ``"0"`` for free listings).
        created_at: ISO-8601 creation timestamp.
    """

    listing_id: str
    name: str
    source_id: str | None = None
    publisher: str | None = None
    description: str | None = None
    license: str | None = None
    version: str | None = None
    artifact_count: int = 0
    tags: Tuple[str, ...] = field(default_factory=tuple)
    source_url: str | None = None
    bundle_url: str | None = None
    signature: str | None = None
    downloads: int = 0
    rating: float | None = None
    price: str | None = None
    created_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a CatalogItemDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``listing_id`` and ``name``.

        Returns:
            A fully populated :class:`CatalogItemDTO`.
        """
        return cls(
            listing_id=data["listing_id"],
            name=data["name"],
            source_id=data.get("source_id"),
            publisher=data.get("publisher"),
            description=data.get("description"),
            license=data.get("license"),
            version=data.get("version"),
            artifact_count=int(data.get("artifact_count") or 0),
            tags=tuple(data.get("tags") or []),
            source_url=data.get("source_url"),
            bundle_url=data.get("bundle_url"),
            signature=data.get("signature"),
            downloads=int(data.get("downloads") or 0),
            rating=float(data["rating"]) if data.get("rating") is not None else None,
            price=data.get("price"),
            created_at=_to_iso(data.get("created_at")),
        )


# =============================================================================
# ProjectTemplateDTO
# =============================================================================


@dataclass(frozen=True)
class TemplateEntityDTO:
    """A single entity entry within a project template.

    Captures the relationship between a :class:`ProjectTemplateDTO` and one
    of its constituent context-entity artifacts.

    Attributes:
        artifact_id: Artifact primary key (``"type:name"``).
        name: Artifact display name.
        artifact_type: Artifact type string (e.g. ``"spec_file"``).
        deploy_order: Zero-based position controlling deployment sequence.
        required: Whether this entity is mandatory for template deployment.
        path_pattern: Target path pattern from the artifact.
    """

    artifact_id: str
    name: str
    artifact_type: str = ""
    deploy_order: int = 0
    required: bool = True
    path_pattern: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a TemplateEntityDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``artifact_id`` and ``name``.

        Returns:
            A fully populated :class:`TemplateEntityDTO`.
        """
        return cls(
            artifact_id=data["artifact_id"],
            name=data["name"],
            artifact_type=data.get("artifact_type") or data.get("type") or "",
            deploy_order=int(data.get("deploy_order") or 0),
            required=bool(data.get("required", True)),
            path_pattern=data.get("path_pattern"),
        )


@dataclass(frozen=True)
class ProjectTemplateDTO:
    """Lightweight representation of a project template.

    Project templates are reusable collections of context entities that can
    be deployed together to initialise Claude Code project structures.
    Templates support variable substitution for customisation.

    Attributes:
        id: Template unique identifier (hex UUID).
        name: Human-readable template name.
        description: Optional template description.
        collection_id: Identifier of the owning collection.
        default_project_config_id: Artifact ID of the default CLAUDE.md to use.
        entities: Ordered list of template entity records.
        entity_count: Total number of entities in this template.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    name: str
    description: str | None = None
    collection_id: str | None = None
    default_project_config_id: str | None = None
    entities: Tuple[TemplateEntityDTO, ...] = field(default_factory=tuple)
    entity_count: int = 0
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a ProjectTemplateDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id`` and ``name``.

        Returns:
            A fully populated :class:`ProjectTemplateDTO`.
        """
        raw_entities = data.get("entities") or []
        entities = tuple(
            TemplateEntityDTO.from_dict(e) if isinstance(e, dict) else e
            for e in raw_entities
        )
        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description"),
            collection_id=data.get("collection_id"),
            default_project_config_id=data.get("default_project_config_id"),
            entities=entities,
            entity_count=int(data.get("entity_count") or len(entities)),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# UserCollectionDTO
# =============================================================================


@dataclass(frozen=True)
class UserCollectionDTO:
    """Lightweight representation of a DB-backed user collection.

    Maps from the ``Collection`` ORM model in ``skillmeat.cache.models``.
    Unlike the filesystem-oriented :class:`CollectionDTO`, this DTO is keyed
    by the database UUID primary key and carries the full set of metadata
    columns used by the web API.

    Attributes:
        id: UUID hex primary key (e.g. ``"a1b2c3d4..."``).
        name: Human-readable collection name (1-255 characters).
        description: Optional detailed description.
        created_by: User identifier for future multi-user support.
        collection_type: Optional collection type (e.g. ``"context"``
            or ``"artifacts"``).
        context_category: Optional sub-category for context collections
            (e.g. ``"rules"`` or ``"specs"``).
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
        artifact_count: Number of artifacts currently in the collection
            (derived, not a stored column).
    """

    id: str
    name: str
    description: str | None = None
    created_by: str | None = None
    collection_type: str | None = None
    context_category: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    artifact_count: int = 0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a UserCollectionDTO from a plain dictionary.

        Unknown keys are silently ignored so callers can pass raw ORM
        ``to_dict()`` output or query-result rows without pre-filtering.

        Args:
            data: Mapping that contains at minimum ``id`` and ``name``.

        Returns:
            A fully populated :class:`UserCollectionDTO`.
        """
        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description"),
            created_by=data.get("created_by"),
            collection_type=data.get("collection_type"),
            context_category=data.get("context_category"),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
            artifact_count=int(data.get("artifact_count") or 0),
        )


# =============================================================================
# CollectionArtifactDTO
# =============================================================================


@dataclass(frozen=True)
class CollectionArtifactDTO:
    """Lightweight representation of a collection–artifact association row.

    Maps from the ``CollectionArtifact`` ORM model (the rich join table in
    ``skillmeat.cache.models``).  Carries both the join keys and the cached
    metadata columns that allow the web API to serve collection pages without
    re-reading every artifact from the filesystem.

    Attributes:
        collection_id: UUID hex FK to ``collections.id``.
        artifact_uuid: Stable ADR-007 UUID FK to ``artifacts.uuid``.
        added_at: ISO-8601 timestamp when the artifact was added to the
            collection.
        description: Cached artifact description.
        author: Cached artifact author string.
        license: Cached SPDX license identifier (e.g. ``"MIT"``).
        tags: Cached tag name strings (deserialised from ``tags_json``).
        tools: Cached tool name strings (deserialised from ``tools_json``).
        deployments: Cached deployment objects or path strings (from ``deployments_json``).
        artifact_content_hash: SHA-256 hash of artifact file contents.
        artifact_structure_hash: Hash of the artifact directory structure.
        artifact_file_count: Number of files in the artifact.
        artifact_total_size: Total byte size of all artifact files.
        source: Upstream source spec string.
        origin: Origin URL or identifier.
        resolved_sha: Resolved VCS commit SHA.
        resolved_version: Resolved version string.
        synced_at: ISO-8601 timestamp of the most-recent metadata sync.
    """

    collection_id: str
    artifact_uuid: str
    added_at: str | None = None
    description: str | None = None
    author: str | None = None
    license: str | None = None
    tags: Tuple[str, ...] = field(default_factory=tuple)
    tools: Tuple[str, ...] = field(default_factory=tuple)
    deployments: Tuple[Any, ...] = field(default_factory=tuple)
    artifact_content_hash: str | None = None
    artifact_structure_hash: str | None = None
    artifact_file_count: int | None = None
    artifact_total_size: int | None = None
    source: str | None = None
    origin: str | None = None
    origin_source: str | None = None
    version: str | None = None
    resolved_sha: str | None = None
    resolved_version: str | None = None
    synced_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a CollectionArtifactDTO from a plain dictionary.

        Handles JSON-serialised list columns (``tags_json``, ``tools_json``,
        ``deployments_json``) transparently — pass the raw ORM ``__dict__``
        or a pre-deserialised mapping; both are accepted.

        Args:
            data: Mapping that contains at minimum ``collection_id`` and
                ``artifact_uuid``.

        Returns:
            A fully populated :class:`CollectionArtifactDTO`.
        """
        import json as _json

        def _parse_json_tuple(raw: Any) -> tuple:
            """Return a tuple from a JSON string, a list, or None/empty."""
            if raw is None:
                return ()
            if isinstance(raw, (list, tuple)):
                return tuple(raw)
            if isinstance(raw, str):
                try:
                    parsed = _json.loads(raw)
                    return tuple(parsed) if isinstance(parsed, list) else ()
                except (_json.JSONDecodeError, TypeError):
                    return ()
            return ()

        file_count = data.get("artifact_file_count")
        total_size = data.get("artifact_total_size")

        return cls(
            collection_id=data["collection_id"],
            artifact_uuid=data["artifact_uuid"],
            added_at=_to_iso(data.get("added_at")),
            description=data.get("description"),
            author=data.get("author"),
            license=data.get("license"),
            tags=_parse_json_tuple(data.get("tags") or data.get("tags_json")),
            tools=_parse_json_tuple(data.get("tools") or data.get("tools_json")),
            deployments=_parse_json_tuple(
                data.get("deployments") or data.get("deployments_json")
            ),
            artifact_content_hash=data.get("artifact_content_hash"),
            artifact_structure_hash=data.get("artifact_structure_hash"),
            artifact_file_count=int(file_count) if file_count is not None else None,
            artifact_total_size=int(total_size) if total_size is not None else None,
            source=data.get("source"),
            origin=data.get("origin"),
            origin_source=data.get("origin_source"),
            version=data.get("version"),
            resolved_sha=data.get("resolved_sha"),
            resolved_version=data.get("resolved_version"),
            synced_at=_to_iso(data.get("synced_at")),
        )


# =============================================================================
# CacheArtifactSummaryDTO
# =============================================================================


@dataclass(frozen=True)
class CacheArtifactSummaryDTO:
    """Lightweight summary of a cached artifact row (``artifacts`` table).

    Used by the artifact history router to resolve artifact metadata without
    leaking ORM objects across the layer boundary.

    Attributes:
        id: Artifact primary key in ``type:name`` format.
        uuid: Stable 32-char hex UUID (ADR-007 identity).
        name: Human-readable artifact name.
        type: Artifact type string (e.g. ``"skill"``, ``"command"``).
        project_path: Filesystem path of the owning project, or ``None`` when
            the artifact is not tied to a specific project.
    """

    id: str
    uuid: str
    name: str
    type: str
    project_path: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a :class:`CacheArtifactSummaryDTO` from a plain dict.

        Args:
            data: Mapping with at minimum ``id``, ``uuid``, ``name``,
                and ``type`` keys.

        Returns:
            A fully populated :class:`CacheArtifactSummaryDTO`.
        """
        return cls(
            id=data["id"],
            uuid=data["uuid"],
            name=data["name"],
            type=data["type"],
            project_path=data.get("project_path"),
        )


# =============================================================================
# ArtifactVersionDTO
# =============================================================================


@dataclass(frozen=True)
class ArtifactVersionDTO:
    """Lightweight representation of an ``artifact_versions`` row.

    Used by the artifact history router to build version-lineage timeline
    events without leaking ORM objects across the layer boundary.

    Attributes:
        id: Version primary key (UUID hex).
        artifact_id: FK to ``artifacts.id`` (``type:name``).
        content_hash: SHA-256 hash of artifact content.
        parent_hash: Content hash of the parent version; ``None`` for roots.
        change_origin: Origin tag (``"deployment"``, ``"sync"``,
            ``"local_modification"``).
        version_lineage: JSON-encoded list of ancestor content hashes, or
            ``None`` when no lineage was recorded.
        created_at: ISO-8601 timestamp when the version was created.
        metadata_json: Raw JSON metadata string, or ``None``.
    """

    id: str
    artifact_id: str
    content_hash: str
    change_origin: str
    created_at: str | None = None
    parent_hash: str | None = None
    version_lineage: str | None = None
    metadata_json: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct an :class:`ArtifactVersionDTO` from a plain dict.

        Args:
            data: Mapping with at minimum ``id``, ``artifact_id``,
                ``content_hash``, and ``change_origin`` keys.

        Returns:
            A fully populated :class:`ArtifactVersionDTO`.
        """
        return cls(
            id=data["id"],
            artifact_id=data["artifact_id"],
            content_hash=data["content_hash"],
            change_origin=data["change_origin"],
            created_at=_to_iso(data.get("created_at")),
            parent_hash=data.get("parent_hash"),
            version_lineage=data.get("version_lineage"),
            metadata_json=data.get("metadata_json") or data.get("metadata"),
        )


# =============================================================================
# ArtifactCollectionVersionDTO
# =============================================================================


@dataclass(frozen=True)
class ArtifactCollectionVersionDTO:
    """Lightweight representation of an ``artifact_collection_versions`` row.

    Tracks the current collection-side version pointer for a single artifact.
    One row exists per artifact (enforced by UNIQUE constraint on
    ``artifact_id`` in the DB).

    Attributes:
        id: Primary key (UUID hex).
        artifact_id: FK to ``artifacts.id`` (``type:name``).
        version_id: FK to ``artifact_versions.id`` — the current collection
            version for this artifact.
        current_hash: SHA-256 content hash matching the version's
            ``content_hash``.
        updated_at: ISO-8601 timestamp, refreshed on every upsert.
    """

    id: str
    artifact_id: str
    version_id: str
    current_hash: str
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ArtifactCollectionVersionDTO":
        """Construct from a plain dict."""
        return cls(
            id=data["id"],
            artifact_id=data["artifact_id"],
            version_id=data["version_id"],
            current_hash=data["current_hash"],
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# ProjectVersionDeploymentDTO
# =============================================================================


@dataclass(frozen=True)
class ProjectVersionDeploymentDTO:
    """Lightweight representation of a ``project_version_deployments`` row.

    Records a single append-only deployment event: which artifact was deployed
    to which project, its content hash, and whether the deployment was pinned.

    Attributes:
        id: Primary key (UUID hex).
        artifact_id: FK to ``artifacts.id`` (``type:name``).
        project_id: FK to ``projects.id``.
        content_hash: SHA-256 hash of the deployed artifact content.
        pinned: ``True`` when the deployed version is locked against
            auto-updates.
        deployed_at: ISO-8601 timestamp of the deployment event.
        updated_at: ISO-8601 timestamp (set once at insert).
    """

    id: str
    artifact_id: str
    project_id: str
    content_hash: str
    pinned: bool
    deployed_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProjectVersionDeploymentDTO":
        """Construct from a plain dict."""
        return cls(
            id=data["id"],
            artifact_id=data["artifact_id"],
            project_id=data["project_id"],
            content_hash=data["content_hash"],
            pinned=bool(data.get("pinned", False)),
            deployed_at=_to_iso(data.get("deployed_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# DeploymentSetDTO
# =============================================================================


@dataclass(frozen=True)
class DeploymentSetDTO:
    """Lightweight representation of a deployment set.

    Normalises both local (SQLite ``DeploymentSet``) and enterprise
    (PostgreSQL ``EnterpriseDeploymentSet``) records into a single DTO that
    can be safely passed across layer boundaries.

    Divergence resolutions applied here:
    - DIV-5: local ``id: str`` (UUID hex) vs enterprise ``id: UUID`` — both
      normalised to ``str`` via ``UUID.hex``.
    - DIV-8: enterprise ``tenant_id`` is stripped; it must never be exposed to
      router or client layers.

    Attributes:
        id: Primary key as a hex string (32 chars, no hyphens).
        name: Human-readable set name.
        description: Optional free-text description.
        owner_id: Owning user / identity scope (local only; ``None`` for
            enterprise records where ownership is implicit from tenant).
        icon: Optional icon identifier string (e.g. ``"layers"``).
        tags: List of tag name strings (from tags_json or join table).
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
        member_count: Number of members in this set (derived, not stored).
    """

    id: str
    name: str
    description: str | None = None
    owner_id: str | None = None
    icon: str | None = None
    tags: Tuple[str, ...] = field(default_factory=tuple)
    created_at: str | None = None
    updated_at: str | None = None
    member_count: int = 0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a DeploymentSetDTO from a plain dictionary.

        Accepts raw ORM ``to_dict()`` output from both local and enterprise
        repositories.  Unknown keys are silently ignored.

        Args:
            data: Mapping that contains at minimum ``id`` and ``name``.
                The ``id`` value may be a plain string (local) or a UUID
                object (enterprise); both are coerced to ``str``.

        Returns:
            A fully populated :class:`DeploymentSetDTO`.
        """
        raw_id = data["id"]
        # Enterprise PKs are uuid.UUID objects; normalise to hex string.
        id_str = raw_id.hex if hasattr(raw_id, "hex") else str(raw_id)

        # Tags: accept a pre-parsed list or a JSON string (local tags_json).
        raw_tags = data.get("tags") or []
        if isinstance(raw_tags, str):
            import json as _json

            try:
                raw_tags = _json.loads(raw_tags)
            except Exception:
                raw_tags = []
        tags = tuple(raw_tags)

        return cls(
            id=id_str,
            name=data["name"],
            description=data.get("description"),
            owner_id=data.get("owner_id"),
            icon=data.get("icon"),
            tags=tags,
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
            member_count=int(data.get("member_count") or 0),
        )


# =============================================================================
# DeploymentSetMemberDTO
# =============================================================================


@dataclass(frozen=True)
class DeploymentSetMemberDTO:
    """Lightweight representation of a single deployment set member row.

    Normalises both local (``DeploymentSetMember``) and enterprise
    (``EnterpriseDeploymentSetMember``) member records into a unified DTO.

    Divergence resolutions applied here:
    - DIV-1 (reads): closed 2026-04-08 (ADR-007; enterprise-artifact-uuid-keyed-reads-v1 PRD) —
      ``IDeploymentRepository.get_by_artifact`` now accepts ``Union[str, uuid.UUID]`` as
      its ``identifier`` parameter, unifying the read contract across local and enterprise
      editions. Both implementations honour the UUID branch for efficient lookups.
      Storage-level divergence remains informational: local stores ``artifact_uuid`` as
      ``str`` (ADR-007 stable UUID hex); enterprise stores it as ``uuid.UUID`` at the
      column level.  Enterprise converters must still map ``artifact_id`` → ``artifact_uuid``
      before calling ``from_dict``.
    - DIV-5: all PK/FK UUID objects normalised to hex strings.

    Attributes:
        id: Primary key as a hex string.
        deployment_set_id: FK to the owning deployment set (hex string).
        artifact_uuid: Normalised artifact reference.  For local records this
            is the ADR-007 stable UUID hex; for enterprise records it is the
            text-format artifact identifier mapped to the ``artifact_uuid``
            key by the enterprise converter.
        artifact_type: Optional artifact type string (e.g. ``"skill"``).
        artifact_name: Optional artifact display name.
        position: Zero-based ordering position within the set.
        config_overrides: Optional JSON string with per-member config.
        created_at: ISO-8601 creation timestamp.
    """

    id: str
    deployment_set_id: str
    artifact_uuid: str
    artifact_type: str | None = None
    artifact_name: str | None = None
    position: int = 0
    config_overrides: str | None = None
    created_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a DeploymentSetMemberDTO from a plain dictionary.

        Accepts raw ORM ``to_dict()`` output from both local and enterprise
        repositories (after the enterprise converter has normalised field
        names).  Unknown keys are silently ignored.

        Args:
            data: Mapping that contains at minimum ``id``,
                ``deployment_set_id`` (or ``set_id`` as an alias), and
                ``artifact_uuid``.

        Returns:
            A fully populated :class:`DeploymentSetMemberDTO`.
        """
        raw_id = data["id"]
        id_str = raw_id.hex if hasattr(raw_id, "hex") else str(raw_id)

        # Accept both "deployment_set_id" (DTO convention) and "set_id" (ORM column).
        raw_set_id = data.get("deployment_set_id") or data.get("set_id") or ""
        set_id_str = raw_set_id.hex if hasattr(raw_set_id, "hex") else str(raw_set_id)

        return cls(
            id=id_str,
            deployment_set_id=set_id_str,
            artifact_uuid=data["artifact_uuid"],
            artifact_type=data.get("artifact_type"),
            artifact_name=data.get("artifact_name"),
            position=int(data.get("position") or 0),
            config_overrides=data.get("config_overrides"),
            created_at=_to_iso(data.get("created_at")),
        )


# =============================================================================
# GovernancePolicyDTO
# =============================================================================


@dataclass(frozen=True)
class GovernancePolicyDTO:
    """Lightweight representation of a governance policy.

    Normalises both local per-project governance policies and enterprise
    tenant-scoped governance policies into a single DTO.

    Divergence resolutions applied here:
    - DIV-9: local policies are scoped per-project; enterprise policies are
      scoped per-tenant.  The ``scope`` field is always set to the string
      ``"project"`` by local converters and ``"tenant"`` by enterprise
      converters.
    - DIV-5: enterprise UUID PKs normalised to hex strings.

    Attributes:
        id: Primary key as a hex string.
        name: Human-readable policy name.
        description: Optional free-text description.
        policy_type: Category/type of the policy (e.g. ``"allow"``,
            ``"deny"``, ``"require"``).
        rules: JSON string encoding the policy rule set.
        scope: ``"project"`` for local per-project policies or ``"tenant"``
            for enterprise tenant-scoped policies.
        enabled: ``True`` when the policy is active.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    name: str
    policy_type: str
    rules: str
    scope: str
    description: str | None = None
    enabled: bool = True
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct a GovernancePolicyDTO from a plain dictionary.

        Accepts raw ORM ``to_dict()`` output from both local and enterprise
        repositories.  Unknown keys are silently ignored.

        Args:
            data: Mapping that contains at minimum ``id``, ``name``,
                ``policy_type``, ``rules``, and ``scope``.  ``rules`` may be
                a pre-serialised JSON string or a dict/list; in the latter
                case it is JSON-encoded automatically.

        Returns:
            A fully populated :class:`GovernancePolicyDTO`.
        """
        import json as _json

        raw_id = data["id"]
        id_str = raw_id.hex if hasattr(raw_id, "hex") else str(raw_id)

        # rules may arrive as a JSON string (local) or a dict/list (enterprise JSONB).
        raw_rules = data.get("rules") or "{}"
        if not isinstance(raw_rules, str):
            raw_rules = _json.dumps(raw_rules)

        return cls(
            id=id_str,
            name=data["name"],
            description=data.get("description"),
            policy_type=data.get("policy_type") or "",
            rules=raw_rules,
            scope=data.get("scope") or "project",
            enabled=bool(data.get("enabled", True)),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# EnterpriseArtifactResponseDTO
# =============================================================================


@dataclass(frozen=True)
class EnterpriseArtifactResponseDTO:
    """Polymorphic artifact response DTO for routers that must handle both
    local and enterprise artifact representations transparently.

    Provides a superset of fields that covers both the local ``Artifact``
    ORM model and the enterprise ``EnterpriseArtifact`` ORM model.  Routers
    that serve endpoints under both editions should accept this DTO rather
    than edition-specific models.

    Divergence resolutions applied here:
    - DIV-5: enterprise UUID PKs normalised to hex strings.
    - DIV-6: enterprise ``source_url`` mapped to ``source``.
    - DIV-7: enterprise JSONB ``metadata`` dict JSON-encoded into
      ``metadata_json`` string.

    Attributes:
        id: Primary key as ``"type:name"`` string (local) or UUID hex
            (enterprise).
        name: Human-readable artifact name.
        artifact_type: Artifact category string (e.g. ``"skill"``).
        source: Upstream source spec.  Local: ``source`` column; enterprise:
            ``source_url`` column mapped here.
        version: Resolved version string.
        description: Optional free-text description.
        metadata_json: JSON string encoding artifact metadata.  Local:
            stored as-is; enterprise: JSONB dict JSON-encoded by converter.
        content_hash: Optional SHA-256 hex content hash.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    name: str
    artifact_type: str
    source: str
    version: str | None = None
    description: str | None = None
    metadata_json: str = "{}"
    content_hash: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct an EnterpriseArtifactResponseDTO from a plain dictionary.

        Accepts raw ORM ``to_dict()`` output from both local and enterprise
        repositories (after the enterprise converter has normalised field
        names).  Unknown keys are silently ignored.

        Args:
            data: Mapping that contains at minimum ``id``, ``name``,
                ``artifact_type`` (or ``type``), and ``source`` (or
                ``source_url``).  ``metadata_json`` may be a pre-serialised
                JSON string or a dict; dicts are JSON-encoded automatically.

        Returns:
            A fully populated :class:`EnterpriseArtifactResponseDTO`.
        """
        import json as _json

        raw_id = data["id"]
        id_str = raw_id.hex if hasattr(raw_id, "hex") else str(raw_id)

        # Accept both "artifact_type" (DTO convention) and "type" (ORM column).
        artifact_type = data.get("artifact_type") or data.get("type") or ""

        # Accept both "source" (local) and "source_url" (enterprise).
        source = data.get("source") or data.get("source_url") or ""

        # metadata_json: accept JSON string (local) or dict (enterprise JSONB).
        raw_meta = data.get("metadata_json") or data.get("metadata") or {}
        if not isinstance(raw_meta, str):
            raw_meta = _json.dumps(raw_meta)

        return cls(
            id=id_str,
            name=data["name"],
            artifact_type=artifact_type,
            source=source,
            version=data.get("version"),
            description=data.get("description"),
            metadata_json=raw_meta,
            content_hash=data.get("content_hash"),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# EnterpriseCollectionDTO
# =============================================================================


@dataclass(frozen=True)
class EnterpriseCollectionDTO:
    """Lightweight representation of an enterprise-edition user collection.

    Wraps ``EnterpriseCollection`` ORM rows.  Strips internal tenant fields
    (``tenant_id``) and embeds a pre-aggregated ``binding_count`` to avoid
    N+1 queries in the list endpoint.

    Divergence resolutions applied here:
    - DIV-5: enterprise ``id: UUID`` normalised to ``str`` via ``UUID.hex``.

    Attributes:
        id: Primary key as a hex string (32 chars, no hyphens).
        name: Human-readable collection name.
        description: Optional free-text description.
        is_default: True when this is the tenant's default collection.
        binding_count: Number of artifact bindings in this collection
            (aggregated at query time, not stored in the model).
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    id: str
    name: str
    description: str | None = None
    is_default: bool = False
    binding_count: int = 0
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Construct an EnterpriseCollectionDTO from a plain dictionary.

        Accepts raw ORM ``to_dict()`` output.  Enterprise UUID PKs are
        normalised to hex strings automatically.  Unknown keys are silently
        ignored.

        Args:
            data: Mapping that contains at minimum ``id`` and ``name``.
                The ``id`` value may be a ``uuid.UUID`` object or a string;
                both are coerced to a 32-char hex string.

        Returns:
            A fully populated :class:`EnterpriseCollectionDTO`.
        """
        raw_id = data["id"]
        # DIV-5: enterprise PKs are uuid.UUID objects — normalise to hex string.
        id_str = raw_id.hex if hasattr(raw_id, "hex") else str(raw_id)

        return cls(
            id=id_str,
            name=data["name"],
            description=data.get("description"),
            is_default=bool(data.get("is_default", False)),
            binding_count=int(data.get("binding_count") or 0),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# GitRepoConnectionDTO
# =============================================================================


@dataclass(frozen=True)
class GitRepoConnectionDTO:
    """Lightweight representation of a registered Git repository connection.

    Maps from the ``GitRepoConnection`` ORM model.

    Attributes:
        id: Integer primary key.
        project_id: Optional FK to projects.id.
        repo_url: Full clone URL of the Git repository.
        branch: Branch to scan (default 'main').
        developer_id: Optional FK to users.id for the owning developer.
        scan_schedule: Reserved cron expression for scheduled scans.
        webhook_secret: HMAC secret for webhook push-event validation.
        last_scan_at: ISO-8601 timestamp of the most recently completed scan.
        last_scan_id: Plain reference to the latest GitRepoScan id.
        is_active: When False the connection is paused.
        created_at: ISO-8601 creation timestamp.
        created_by: Optional FK to users.id of the registering user.
        access_token: Encrypted personal access token (opaque string).
    """

    id: int
    repo_url: str
    branch: str = "main"
    is_active: bool = True
    project_id: Optional[str] = None
    developer_id: Optional[int] = None
    scan_schedule: Optional[str] = None
    webhook_secret: Optional[str] = None
    last_scan_at: Optional[str] = None
    last_scan_id: Optional[int] = None
    created_at: Optional[str] = None
    created_by: Optional[int] = None
    access_token: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GitRepoConnectionDTO":
        """Construct a GitRepoConnectionDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id`` and ``repo_url``.

        Returns:
            A fully populated :class:`GitRepoConnectionDTO`.
        """
        return cls(
            id=int(data["id"]),
            repo_url=data["repo_url"],
            branch=data.get("branch", "main"),
            is_active=bool(data.get("is_active", True)),
            project_id=data.get("project_id"),
            developer_id=(
                int(data["developer_id"])
                if data.get("developer_id") is not None
                else None
            ),
            scan_schedule=data.get("scan_schedule"),
            webhook_secret=data.get("webhook_secret"),
            last_scan_at=_to_iso(data.get("last_scan_at")),
            last_scan_id=(
                int(data["last_scan_id"])
                if data.get("last_scan_id") is not None
                else None
            ),
            created_at=_to_iso(data.get("created_at")),
            created_by=(
                int(data["created_by"]) if data.get("created_by") is not None else None
            ),
            access_token=data.get("access_token"),
        )

    def __repr__(self) -> str:
        """Return a safe repr that redacts sensitive credential fields."""
        _REDACTED = {"access_token", "webhook_secret"}
        parts = []
        for f in dataclasses.fields(self):
            val = getattr(self, f.name)
            if f.name in _REDACTED:
                val = "[REDACTED]" if val is not None else None
            parts.append(f"{f.name}={val!r}")
        return f"{self.__class__.__name__}({', '.join(parts)})"


# =============================================================================
# GitRepoScanDTO
# =============================================================================


@dataclass(frozen=True)
class GitRepoScanDTO:
    """Lightweight representation of a Git repository scan execution.

    Maps from the ``GitRepoScan`` ORM model.

    Attributes:
        id: Integer primary key.
        connection_id: FK to git_repo_connections.id.
        triggered_by: How the scan was initiated ('manual', 'schedule', 'webhook').
        status: Current lifecycle state ('pending', 'running', 'completed', 'failed').
        trigger_sha: Git commit SHA that triggered the scan; nullable.
        started_at: ISO-8601 timestamp when the worker started.
        completed_at: ISO-8601 timestamp when the scan finished.
        artifacts_found: Total artifacts detected.
        artifacts_new: Artifacts not seen in previous scans.
        artifacts_changed: Artifacts whose content changed.
        artifacts_removed: Artifacts absent from this scan vs. the previous one.
        error_message: Human-readable failure detail when status is 'failed'.
        created_at: ISO-8601 creation timestamp.
    """

    id: int
    connection_id: int
    triggered_by: str
    status: str = "pending"
    trigger_sha: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    artifacts_found: int = 0
    artifacts_new: int = 0
    artifacts_changed: int = 0
    artifacts_removed: int = 0
    error_message: Optional[str] = None
    created_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GitRepoScanDTO":
        """Construct a GitRepoScanDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id``, ``connection_id``,
                and ``triggered_by``.

        Returns:
            A fully populated :class:`GitRepoScanDTO`.
        """
        return cls(
            id=int(data["id"]),
            connection_id=int(data["connection_id"]),
            triggered_by=data["triggered_by"],
            status=data.get("status", "pending"),
            trigger_sha=data.get("trigger_sha"),
            started_at=_to_iso(data.get("started_at")),
            completed_at=_to_iso(data.get("completed_at")),
            artifacts_found=int(data.get("artifacts_found", 0)),
            artifacts_new=int(data.get("artifacts_new", 0)),
            artifacts_changed=int(data.get("artifacts_changed", 0)),
            artifacts_removed=int(data.get("artifacts_removed", 0)),
            error_message=data.get("error_message"),
            created_at=_to_iso(data.get("created_at")),
        )


# =============================================================================
# GitScanArtifactDTO
# =============================================================================


@dataclass(frozen=True)
class GitScanArtifactDTO:
    """Lightweight representation of a single artifact observation from a scan.

    Maps from the ``GitScanArtifact`` ORM model.

    Attributes:
        id: Integer primary key.
        scan_id: FK to git_repo_scans.id.
        artifact_path: Repository-relative path to the artifact directory/file.
        artifact_type: Detected artifact type label (e.g. 'skill', 'agent').
        change_type: Classification relative to previous scan
            ('new', 'changed', 'removed', 'unchanged').
        detected_name: Human-readable name parsed from frontmatter; nullable.
        content_hash: SHA-256 hex digest of artifact content at scan time.
        indexed_at: ISO-8601 timestamp when imported into cache; None until import.
        artifact_id: FK to artifacts.id once indexed; None until import.
        created_at: ISO-8601 creation timestamp.
    """

    id: int
    scan_id: int
    artifact_path: str
    artifact_type: str
    change_type: str
    detected_name: Optional[str] = None
    content_hash: Optional[str] = None
    indexed_at: Optional[str] = None
    artifact_id: Optional[str] = None
    created_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GitScanArtifactDTO":
        """Construct a GitScanArtifactDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``id``, ``scan_id``,
                ``artifact_path``, ``artifact_type``, and ``change_type``.

        Returns:
            A fully populated :class:`GitScanArtifactDTO`.
        """
        return cls(
            id=int(data["id"]),
            scan_id=int(data["scan_id"]),
            artifact_path=data["artifact_path"],
            artifact_type=data["artifact_type"],
            change_type=data["change_type"],
            detected_name=data.get("detected_name"),
            content_hash=data.get("content_hash"),
            indexed_at=_to_iso(data.get("indexed_at")),
            artifact_id=data.get("artifact_id"),
            created_at=_to_iso(data.get("created_at")),
        )


# =============================================================================
# ActivityEventDTO
# =============================================================================


@dataclass(frozen=True)
class ActivityEventDTO:
    """Lightweight representation of an artifact lifecycle audit event.

    Maps from the ``ArtifactHistoryEvent`` ORM model (local SQLite, integer
    PK) and the ``EnterpriseArtifactHistoryEvent`` ORM model (enterprise
    PostgreSQL, UUID PK).

    ``id`` is typed as ``str`` so that both backends can be served without
    coercion.  For the local SQLite backend the integer PK is stringified at
    construction time (``str(event.id)``).  For the enterprise backend the
    UUID is stringified (``str(event.id)``).  Callers that previously assumed
    ``int`` must convert: ``int(dto.id)`` is valid only for the local backend.

    Attributes:
        id: String-form primary key.  Holds a stringified integer for the
            local SQLite backend and a UUID hex string for the enterprise
            PostgreSQL backend.
        artifact_id: FK to artifacts.id.
        event_type: One of 'create', 'update', 'delete', 'deploy', 'undeploy',
            'sync', 'restore', 'promote', 'force_sync', 'baseline_set'.
        owner_type: Owner context at the time of the event.
        timestamp: ISO-8601 wall-clock time of the event (UTC).
        actor_id: Opaque identifier for the user or system that triggered
            the event; None for automated/system events.
        diff_json: JSON-serialised diff payload describing what changed.
        content_hash: SHA-256 hash of artifact content at event time.
    """

    id: str
    artifact_id: str
    event_type: str
    owner_type: str
    timestamp: Optional[str] = None
    actor_id: Optional[str] = None
    diff_json: Optional[str] = None
    content_hash: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ActivityEventDTO":
        """Construct an ActivityEventDTO from a plain dictionary.

        ``id`` is accepted as ``int``, ``str``, or ``uuid.UUID`` and is
        always stored as a ``str``.  This avoids the previous ``int(data["id"])``
        coercion which raised ``ValueError`` when the enterprise backend
        supplies a UUID string.

        Args:
            data: Mapping that contains at minimum ``id``, ``artifact_id``,
                ``event_type``, and ``owner_type``.

        Returns:
            A fully populated :class:`ActivityEventDTO`.
        """
        return cls(
            id=str(data["id"]),
            artifact_id=data["artifact_id"],
            event_type=data["event_type"],
            owner_type=data.get("owner_type", "user"),
            timestamp=_to_iso(data.get("timestamp")),
            actor_id=data.get("actor_id"),
            diff_json=data.get("diff_json"),
            content_hash=data.get("content_hash"),
        )


# =============================================================================
# BundleMembershipDTO
# =============================================================================


@dataclass(frozen=True)
class BundleMembershipDTO:
    """Lightweight representation of a single bundle membership row.

    Maps from the ``BundleMembership`` ORM model and ``_member_to_dict()``
    output in ``local_bundle_repository``.

    Attributes:
        bundle_id: FK to ``bundle_entities.id``.
        member_type: Discriminator — ``"artifact"`` or ``"context_entity"``.
        artifact_uuid: Stable ``artifacts.uuid`` when ``member_type="artifact"``;
            ``None`` for context entity members.
        context_entity_id: Context entity identifier when
            ``member_type="context_entity"``; ``None`` for artifact members.
        artifact_tier: Tier classification (0=standalone, 1=composable,
            2=orchestrator).
        relationship_type: Semantic edge label (e.g. ``"contains"``).
        pinned_version_hash: Optional content hash snapshot pin.  ``None``
            means "always use latest".
        added_at: ISO-8601 timestamp when the member was added.
    """

    bundle_id: str
    member_type: str = "artifact"
    artifact_uuid: Optional[str] = None
    context_entity_id: Optional[str] = None
    artifact_tier: int = 0
    relationship_type: str = "contains"
    pinned_version_hash: Optional[str] = None
    added_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BundleMembershipDTO":
        """Construct a BundleMembershipDTO from a plain dictionary.

        Args:
            data: Mapping that contains at minimum ``bundle_id``.

        Returns:
            A fully populated :class:`BundleMembershipDTO`.
        """
        return cls(
            bundle_id=data["bundle_id"],
            member_type=data.get("member_type", "artifact"),
            artifact_uuid=data.get("artifact_uuid"),
            context_entity_id=data.get("context_entity_id"),
            artifact_tier=int(data.get("artifact_tier") or 0),
            relationship_type=data.get("relationship_type", "contains"),
            pinned_version_hash=data.get("pinned_version_hash"),
            added_at=_to_iso(data.get("added_at")),
        )


# =============================================================================
# BundleDTO
# =============================================================================


@dataclass(frozen=True)
class BundleDTO:
    """Lightweight representation of a bundle entity.

    Maps from the ``BundleEntity`` ORM model and ``_to_dict()`` output in
    ``local_bundle_repository``.  Embeds the bundle's membership list so that
    callers receive the full bundle in a single DTO.

    Attributes:
        id: Primary key (UUID hex, 32 chars, no hyphens).
        name: Human-readable bundle name (unique within the collection).
        collection_id: Owning collection identifier.
        description: Optional free-text description.
        version: Optional semver string.
        status: Lifecycle status — ``"draft"``, ``"published"``, or
            ``"deprecated"``.
        tags: Tag strings categorising the bundle.
        license: SPDX license identifier (e.g. ``"MIT"``).
        homepage: Optional URL for documentation or homepage.
        repository: Optional URL for the source repository.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
        published_at: ISO-8601 timestamp of first publication; ``None`` while
            still in draft.
        memberships: Embedded list of :class:`BundleMembershipDTO` records.
    """

    id: str
    name: str
    collection_id: str
    description: Optional[str] = None
    version: Optional[str] = None
    status: str = "draft"
    tags: Tuple[str, ...] = field(default_factory=tuple)
    license: Optional[str] = None
    homepage: Optional[str] = None
    repository: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    published_at: Optional[str] = None
    memberships: Tuple[BundleMembershipDTO, ...] = field(default_factory=tuple)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BundleDTO":
        """Construct a BundleDTO from a plain dictionary.

        Accepts the output of ``_to_dict()`` from ``local_bundle_repository``.
        Nested membership dicts under the ``"memberships"`` key are
        automatically converted to :class:`BundleMembershipDTO` instances.

        Args:
            data: Mapping that contains at minimum ``id``, ``name``, and
                ``collection_id``.

        Returns:
            A fully populated :class:`BundleDTO`.
        """
        raw_memberships = data.get("memberships") or []
        memberships = tuple(
            BundleMembershipDTO.from_dict(m) if isinstance(m, dict) else m
            for m in raw_memberships
        )
        return cls(
            id=data["id"],
            name=data["name"],
            collection_id=data["collection_id"],
            description=data.get("description"),
            version=data.get("version"),
            status=data.get("status", "draft"),
            tags=tuple(data.get("tags") or []),
            license=data.get("license"),
            homepage=data.get("homepage"),
            repository=data.get("repository"),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
            published_at=_to_iso(data.get("published_at")),
            memberships=memberships,
        )


# =============================================================================
# CollectionStatsDTO
# =============================================================================


@dataclass(frozen=True)
class CollectionStatsDTO:
    """Aggregate statistics for the active collection.

    Returned by :meth:`~skillmeat.core.interfaces.repositories.ICollectionRepository.get_stats`.
    All fields have sensible defaults so callers can safely access them even
    when the collection does not yet exist (the implementation may return a
    zero-value instance rather than raise).

    Attributes:
        artifact_count: Total number of artifacts registered in the active
            collection's manifest.
        total_size_bytes: Approximate combined on-disk size (bytes) of every
            file under the collection's artifacts directory.  ``0`` when the
            directory is missing or cannot be walked.
        last_synced: ISO-8601 timestamp of the last manifest ``updated`` field,
            or ``None`` when the collection has never been synced.
        collection_root: Absolute path to the collection root directory, or
            ``None`` when no active collection is configured.
    """

    artifact_count: int = 0
    total_size_bytes: int = 0
    last_synced: Optional[str] = None
    collection_root: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CollectionStatsDTO":
        """Construct a CollectionStatsDTO from a plain dictionary.

        Args:
            data: Mapping that may contain ``artifact_count``,
                ``total_size_bytes``, ``last_synced``, and ``collection_root``.
                Missing keys default to their zero values.

        Returns:
            A fully populated :class:`CollectionStatsDTO`.
        """
        return cls(
            artifact_count=int(data.get("artifact_count") or 0),
            total_size_bytes=int(data.get("total_size_bytes") or 0),
            last_synced=_to_iso(data.get("last_synced")),
            collection_root=data.get("collection_root"),
        )


# =============================================================================
# TemplateDeployResultDTO
# =============================================================================


@dataclass(frozen=True)
class TemplateDeployResultDTO:
    """Result of deploying a project template to a target directory.

    Returned by
    :meth:`~skillmeat.core.interfaces.repositories.IProjectTemplateRepository.deploy`.
    All file-path lists default to empty so callers can iterate them
    unconditionally.

    Attributes:
        success: ``True`` when all required entities were deployed without
            error.
        project_path: Absolute filesystem path to the target project
            directory that was written to.
        deployed_files: Relative paths (from *project_path*) of every file
            that was successfully written during this deploy run.
        skipped_files: Relative paths of files that already existed and were
            not overwritten (``overwrite=False``), or that were excluded via
            ``selected_entity_ids``.
        message: Human-readable summary of the deploy outcome.
    """

    success: bool = False
    project_path: str = ""
    deployed_files: Tuple[str, ...] = field(default_factory=tuple)
    skipped_files: Tuple[str, ...] = field(default_factory=tuple)
    message: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TemplateDeployResultDTO":
        """Construct a TemplateDeployResultDTO from a plain dictionary.

        Args:
            data: Mapping that may contain ``success``, ``project_path``,
                ``deployed_files``, ``skipped_files``, and ``message``.
                Missing keys default to their zero values.

        Returns:
            A fully populated :class:`TemplateDeployResultDTO`.
        """
        return cls(
            success=bool(data.get("success", False)),
            project_path=str(data.get("project_path") or ""),
            deployed_files=tuple(data.get("deployed_files") or []),
            skipped_files=tuple(data.get("skipped_files") or []),
            message=str(data.get("message") or ""),
        )


# =============================================================================
# BundleListDTO
# =============================================================================


@dataclass(frozen=True)
class BundleListDTO:
    """Typed wrapper for paginated bundle list responses.

    Replaces the raw ``dict[str, Any]`` returned by ``IBundleRepository.
    list_bundles()`` with a typed, immutable envelope.

    Attributes:
        items: Page of :class:`BundleDTO` records matching the query.
        total: Total number of bundles across all pages.
        page: Current 1-based page number.
        page_size: Maximum items per page requested.
    """

    items: Tuple[BundleDTO, ...] = field(default_factory=tuple)
    total: int = 0
    page: int = 1
    page_size: int = 50

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BundleListDTO":
        """Construct a BundleListDTO from a paginated response dictionary.

        Args:
            data: Mapping with ``"items"`` (list of bundle dicts), ``"total"``,
                ``"page"``, and ``"page_size"`` keys.

        Returns:
            A fully populated :class:`BundleListDTO`.
        """
        raw_items = data.get("items") or []
        items = tuple(
            BundleDTO.from_dict(i) if isinstance(i, dict) else i for i in raw_items
        )
        return cls(
            items=items,
            total=int(data.get("total") or 0),
            page=int(data.get("page") or 1),
            page_size=int(data.get("page_size") or 50),
        )


# =============================================================================
# SourceDeploymentEntryDTO
# =============================================================================


@dataclass(frozen=True)
class SourceDeploymentEntryDTO:
    """Single row returned by ``IDbCollectionArtifactRepository.get_source_deployments_batch``.

    Each instance corresponds to one artifact that has a matching
    ``CollectionArtifact`` row.  The ``deployments_json`` field is the raw JSON
    string stored in the DB column; callers are responsible for decoding it.

    Attributes:
        id: ``"type:name"`` artifact identifier string.
        source: Upstream source spec (e.g. ``"owner/repo/path"``), or ``None``
            when no upstream source is recorded.
        deployments_json: Raw JSON string storing deployment records, or
            ``None`` when no deployments have been persisted yet.
    """

    id: str = ""
    source: Optional[str] = None
    deployments_json: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SourceDeploymentEntryDTO":
        """Construct a SourceDeploymentEntryDTO from a plain dictionary.

        Args:
            data: Mapping with keys ``id``, ``source``, and
                ``deployments_json``.  Missing keys default to their zero
                values.

        Returns:
            A fully populated :class:`SourceDeploymentEntryDTO`.
        """
        return cls(
            id=str(data.get("id") or ""),
            source=data.get("source"),
            deployments_json=data.get("deployments_json"),
        )


# =============================================================================
# GroupMembershipEntryDTO
# =============================================================================


@dataclass(frozen=True)
class GroupMembershipEntryDTO:
    """Single row returned by ``IDbCollectionArtifactRepository.get_group_memberships_batch``.

    Each instance represents one artifact-to-group association within a
    collection.

    Attributes:
        artifact_id: ``"type:name"`` identifier of the artifact.
        group_id: Unique identifier of the group.
        group_name: Display name of the group.
        position: Integer position of the artifact within the group.
    """

    artifact_id: str = ""
    group_id: str = ""
    group_name: str = ""
    position: int = 0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GroupMembershipEntryDTO":
        """Construct a GroupMembershipEntryDTO from a plain dictionary.

        Args:
            data: Mapping with keys ``artifact_id``, ``group_id``,
                ``group_name``, and ``position``.  Missing keys default to
                their zero values.

        Returns:
            A fully populated :class:`GroupMembershipEntryDTO`.
        """
        return cls(
            artifact_id=str(data.get("artifact_id") or ""),
            group_id=str(data.get("group_id") or ""),
            group_name=str(data.get("group_name") or ""),
            position=int(data.get("position") or 0),
        )


# =============================================================================
# StalenessStatsDTO
# =============================================================================


@dataclass(frozen=True)
class StalenessStatsDTO:
    """Staleness statistics returned by ``IDbCollectionArtifactRepository.get_staleness_stats``.

    Summarises how many ``CollectionArtifact`` memberships within a collection
    are fresh vs stale relative to a caller-supplied TTL.

    Attributes:
        total_artifacts: Total number of artifact memberships in the collection.
        stale_count: Number of memberships whose ``synced_at`` is older than
            *ttl_seconds* or is ``None``.
        fresh_count: Number of memberships that were synced within *ttl_seconds*.
        oldest_sync_age_seconds: Age in seconds of the oldest ``synced_at``
            value that is not ``None``.  ``0`` when all memberships are
            un-synced or the collection is empty.
        percentage_stale: Percentage of memberships that are stale, rounded to
            one decimal place.  ``0.0`` when *total_artifacts* is zero.
        ttl_seconds: The TTL value (in seconds) that was used to compute these
            statistics — echoed back for caller convenience.
        collection_id: The collection identifier that was queried.
    """

    total_artifacts: int = 0
    stale_count: int = 0
    fresh_count: int = 0
    oldest_sync_age_seconds: float = 0.0
    percentage_stale: float = 0.0
    ttl_seconds: int = 0
    collection_id: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StalenessStatsDTO":
        """Construct a StalenessStatsDTO from a plain dictionary.

        Args:
            data: Mapping with keys ``total_artifacts``, ``stale_count``,
                ``fresh_count``, ``oldest_sync_age_seconds``,
                ``percentage_stale``, ``ttl_seconds``, and ``collection_id``.
                Missing keys default to their zero values.

        Returns:
            A fully populated :class:`StalenessStatsDTO`.
        """
        return cls(
            total_artifacts=int(data.get("total_artifacts") or 0),
            stale_count=int(data.get("stale_count") or 0),
            fresh_count=int(data.get("fresh_count") or 0),
            oldest_sync_age_seconds=float(data.get("oldest_sync_age_seconds") or 0.0),
            percentage_stale=float(data.get("percentage_stale") or 0.0),
            ttl_seconds=int(data.get("ttl_seconds") or 0),
            collection_id=str(data.get("collection_id") or ""),
        )


# =============================================================================
# Enterprise-only DTOs
# =============================================================================


@dataclass(frozen=True)
class WorkflowDTO:
    """DTO for EnterpriseWorkflow — tenant-scoped workflow definition.

    Attributes:
        id:          UUID primary key as string.
        tenant_id:   Tenant scope as string.
        name:        Human-readable workflow name (unique per tenant).
        description: Optional description of the workflow's purpose.
        status:      Lifecycle status — 'draft', 'active', or 'archived'.
        config:      Arbitrary configuration dict for workflow-level settings.
        created_at:  ISO-8601 creation timestamp or ``None``.
        updated_at:  ISO-8601 last-modified timestamp or ``None``.
    """

    id: str = ""
    tenant_id: str = ""
    name: str = ""
    description: Optional[str] = None
    status: str = "draft"
    config: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkflowDTO":
        """Construct a WorkflowDTO from a plain dictionary.

        Args:
            data: Mapping with keys matching the DTO attributes.  UUID fields
                are coerced to ``str``; datetime fields are coerced via
                ``_to_iso``; missing keys default to their zero values.

        Returns:
            A fully populated :class:`WorkflowDTO`.
        """
        return cls(
            id=str(data.get("id") or ""),
            tenant_id=str(data.get("tenant_id") or ""),
            name=str(data.get("name") or ""),
            description=data.get("description"),
            status=str(data.get("status") or "draft"),
            config=dict(data.get("config") or {}),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


@dataclass(frozen=True)
class WorkflowExecutionDTO:
    """DTO for EnterpriseWorkflowExecution — a single run of a workflow.

    Attributes:
        id:           UUID primary key as string.
        workflow_id:  FK to the parent workflow as string.
        tenant_id:    Denormalised tenant scope as string.
        status:       Run status — 'pending', 'running', 'completed', 'failed',
                      or 'cancelled'.
        started_at:   ISO-8601 timestamp when execution began; ``None`` until started.
        completed_at: ISO-8601 timestamp when execution finished; ``None`` until done.
        context:      JSONB input context supplied at launch time.
        result:       JSONB result payload written on completion or failure.
        created_at:   ISO-8601 creation timestamp or ``None``.
        updated_at:   ISO-8601 last-modified timestamp or ``None``.
    """

    id: str = ""
    workflow_id: str = ""
    tenant_id: str = ""
    status: str = "pending"
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)
    result: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkflowExecutionDTO":
        """Construct a WorkflowExecutionDTO from a plain dictionary.

        Args:
            data: Mapping with keys matching the DTO attributes.  UUID fields
                are coerced to ``str``; datetime fields are coerced via
                ``_to_iso``; missing keys default to their zero values.

        Returns:
            A fully populated :class:`WorkflowExecutionDTO`.
        """
        return cls(
            id=str(data.get("id") or ""),
            workflow_id=str(data.get("workflow_id") or ""),
            tenant_id=str(data.get("tenant_id") or ""),
            status=str(data.get("status") or "pending"),
            started_at=_to_iso(data.get("started_at")),
            completed_at=_to_iso(data.get("completed_at")),
            context=dict(data.get("context") or {}),
            result=dict(data.get("result") or {}),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


@dataclass(frozen=True)
class MemoryItemDTO:
    """DTO for EnterpriseMemoryItem — persistent project-level development knowledge.

    Attributes:
        id:          UUID primary key as string.
        tenant_id:   Denormalised tenant scope as string.
        project_id:  FK to the parent project as string; ``None`` if unscoped.
        type:        Memory type — 'decision', 'constraint', 'gotcha',
                     'style_rule', or 'learning'.
        status:      Lifecycle status — 'candidate', 'validated', 'rejected',
                     or 'superseded'.
        content:     Full-text content of the memory item.
        confidence:  Confidence score in [0.0, 1.0]; ``None`` when not assessed.
        anchor:      Optional source location anchor, e.g. 'path/to/file.py:code:42-58'.
        provenance:  JSONB metadata dict recording how this item was produced.
        created_at:  ISO-8601 creation timestamp or ``None``.
        updated_at:  ISO-8601 last-modified timestamp or ``None``.
    """

    id: str = ""
    tenant_id: str = ""
    project_id: Optional[str] = None
    type: str = ""
    status: str = "candidate"
    content: str = ""
    confidence: Optional[float] = None
    anchor: Optional[str] = None
    provenance: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryItemDTO":
        """Construct a MemoryItemDTO from a plain dictionary.

        Args:
            data: Mapping with keys matching the DTO attributes.  UUID fields
                are coerced to ``str``; datetime fields are coerced via
                ``_to_iso``; missing keys default to their zero values.

        Returns:
            A fully populated :class:`MemoryItemDTO`.
        """
        raw_project_id = data.get("project_id")
        raw_confidence = data.get("confidence")
        return cls(
            id=str(data.get("id") or ""),
            tenant_id=str(data.get("tenant_id") or ""),
            project_id=str(raw_project_id) if raw_project_id is not None else None,
            type=str(data.get("type") or ""),
            status=str(data.get("status") or "candidate"),
            content=str(data.get("content") or ""),
            confidence=float(raw_confidence) if raw_confidence is not None else None,
            anchor=data.get("anchor"),
            provenance=dict(data.get("provenance") or {}),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


@dataclass(frozen=True)
class BomSnapshotDTO:
    """DTO for EnterpriseBomSnapshot — bill-of-materials snapshot for an artifact.

    Attributes:
        id:             UUID primary key as string.
        tenant_id:      Tenant scope as string.
        artifact_id:    FK to the parent artifact as string.
        snapshot_data:  JSONB BOM payload (components, dependencies, etc.).
        generated_at:   ISO-8601 timestamp when the BOM was generated; ``None`` if unknown.
        format_version: Optional format discriminator, e.g. 'spdx-2.3',
                        'cyclonedx-1.5'; ``None`` means unspecified.
        created_at:     ISO-8601 creation timestamp or ``None``.
    """

    id: str = ""
    tenant_id: str = ""
    artifact_id: str = ""
    snapshot_data: Dict[str, Any] = field(default_factory=dict)
    generated_at: Optional[str] = None
    format_version: Optional[str] = None
    created_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BomSnapshotDTO":
        """Construct a BomSnapshotDTO from a plain dictionary.

        Args:
            data: Mapping with keys matching the DTO attributes.  UUID fields
                are coerced to ``str``; datetime fields are coerced via
                ``_to_iso``; missing keys default to their zero values.

        Returns:
            A fully populated :class:`BomSnapshotDTO`.
        """
        return cls(
            id=str(data.get("id") or ""),
            tenant_id=str(data.get("tenant_id") or ""),
            artifact_id=str(data.get("artifact_id") or ""),
            snapshot_data=dict(data.get("snapshot_data") or {}),
            generated_at=_to_iso(data.get("generated_at")),
            format_version=data.get("format_version"),
            created_at=_to_iso(data.get("created_at")),
        )


@dataclass(frozen=True)
class AttestationRecordDTO:
    """DTO for EnterpriseAttestationRecord — result of an attestation check.

    Attributes:
        id:          UUID primary key as string.
        tenant_id:   Denormalised tenant scope as string.
        snapshot_id: FK to the parent BOM snapshot as string.
        policy_id:   FK to the attestation policy as string; ``None`` when the
                     policy has been deleted (SET NULL).
        result:      Attestation outcome — 'pass', 'fail', 'warning', or 'error'.
        attested_at: ISO-8601 timestamp when the attestation was run; ``None``
                     if not yet executed.
        evidence:    JSONB supporting data (rule failures, scores, tool output).
        created_at:  ISO-8601 creation timestamp or ``None``.
    """

    id: str = ""
    tenant_id: str = ""
    snapshot_id: str = ""
    policy_id: Optional[str] = None
    result: str = ""
    attested_at: Optional[str] = None
    evidence: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AttestationRecordDTO":
        """Construct an AttestationRecordDTO from a plain dictionary.

        Args:
            data: Mapping with keys matching the DTO attributes.  UUID fields
                are coerced to ``str``; datetime fields are coerced via
                ``_to_iso``; missing keys default to their zero values.

        Returns:
            A fully populated :class:`AttestationRecordDTO`.
        """
        raw_policy_id = data.get("policy_id")
        return cls(
            id=str(data.get("id") or ""),
            tenant_id=str(data.get("tenant_id") or ""),
            snapshot_id=str(data.get("snapshot_id") or ""),
            policy_id=str(raw_policy_id) if raw_policy_id is not None else None,
            result=str(data.get("result") or ""),
            attested_at=_to_iso(data.get("attested_at")),
            evidence=dict(data.get("evidence") or {}),
            created_at=_to_iso(data.get("created_at")),
        )


@dataclass(frozen=True)
class ProjectGitConnectionDTO:
    """DTO for EnterpriseProjectGitConnection — join-table record linking a project to a git-repo connection.

    Attributes:
        project_id:    UUID FK to ``enterprise_projects.id`` as string.
        connection_id: UUID FK to ``enterprise_git_repo_connections.id`` as string.
        tenant_id:     Denormalised tenant scope as string.
        linked_at:     ISO-8601 timestamp when the connection was linked to the
                       project; ``None`` if not set.
        linked_by:     Optional UUID of the enterprise user who created the link;
                       ``None`` when not recorded.
    """

    project_id: str = ""
    connection_id: str = ""
    tenant_id: str = ""
    linked_at: Optional[str] = None
    linked_by: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProjectGitConnectionDTO":
        """Construct a ProjectGitConnectionDTO from a plain dictionary.

        Args:
            data: Mapping with keys matching the DTO attributes.  UUID fields
                are coerced to ``str``; datetime fields are coerced via
                ``_to_iso``; missing keys default to their zero values.

        Returns:
            A fully populated :class:`ProjectGitConnectionDTO`.
        """
        raw_linked_by = data.get("linked_by")
        return cls(
            project_id=str(data.get("project_id") or ""),
            connection_id=str(data.get("connection_id") or ""),
            tenant_id=str(data.get("tenant_id") or ""),
            linked_at=_to_iso(data.get("linked_at")),
            linked_by=str(raw_linked_by) if raw_linked_by is not None else None,
        )


@dataclass(frozen=True)
class GitCredentialDTO:
    """DTO for EnterpriseGitCredential — tenant-scoped encrypted git credential record.

    Sensitive fields (``token_encrypted``) are intentionally excluded from this
    DTO to prevent accidental token leakage through the API or logging layers.
    Callers that need the plaintext token must access the ORM model directly via
    a privileged, server-side code path.

    Attributes:
        id:              UUID primary key as string.
        tenant_id:       Tenant scope as string.
        scope_type:      Owner scope: ``'org'``, ``'team'``, or ``'developer'``.
        scope_id:        UUID identifying the scope owner as string.
        connection_id:   Optional UUID FK to the parent git-repo connection; ``None``
                         when the credential is not pinned to a specific connection.
        credential_type: Token kind — ``'pat'`` or ``'app_installation'``.
        created_by:      Optional UUID of the enterprise user who created this
                         credential; ``None`` when not recorded.
        created_at:      ISO-8601 creation timestamp or ``None``.
    """

    id: str = ""
    tenant_id: str = ""
    scope_type: str = ""
    scope_id: str = ""
    connection_id: Optional[str] = None
    credential_type: str = "pat"
    created_by: Optional[str] = None
    created_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GitCredentialDTO":
        """Construct a GitCredentialDTO from a plain dictionary.

        Args:
            data: Mapping with keys matching the DTO attributes.  UUID fields
                are coerced to ``str``; datetime fields are coerced via
                ``_to_iso``; missing keys default to their zero values.
                The ``token_encrypted`` key is intentionally ignored.

        Returns:
            A fully populated :class:`GitCredentialDTO`.
        """
        raw_connection_id = data.get("connection_id")
        raw_created_by = data.get("created_by")
        return cls(
            id=str(data.get("id") or ""),
            tenant_id=str(data.get("tenant_id") or ""),
            scope_type=str(data.get("scope_type") or ""),
            scope_id=str(data.get("scope_id") or ""),
            connection_id=(
                str(raw_connection_id) if raw_connection_id is not None else None
            ),
            credential_type=str(data.get("credential_type") or "pat"),
            created_by=str(raw_created_by) if raw_created_by is not None else None,
            created_at=_to_iso(data.get("created_at")),
        )


@dataclass(frozen=True)
class DeploymentProfileDTO:
    """DTO for EnterpriseDeploymentProfile — tenant-scoped deployment configuration profile.

    Maps from the ``EnterpriseDeploymentProfile`` ORM model.  The ORM stores
    flexible configuration (``project_id``, ``profile_id``, ``root_dir``,
    ``artifact_path_map``, etc.) in the ``extra_metadata`` JSONB column; that
    dict is preserved here as-is so callers can read any field they need.

    Attributes:
        id:             UUID primary key as string.
        tenant_id:      Tenant scope as string.
        name:           Human-readable profile name (unique within tenant);
                        formatted as ``"{project_id}/{profile_id}"``.
        scope:          Deployment scope — ``'user'``, ``'local'``, or ``'project'``.
        dest_path:      Destination path template for deployed artifacts; ``None``
                        until explicitly configured.
        overwrite:      When ``True``, existing destination files are overwritten
                        without prompting.
        platform:       Target platform string (e.g. ``'claude_code'``,
                        ``'cursor'``); ``None`` when not platform-specific.
        extra_metadata: Arbitrary extension bag (JSONB) for forward-compatible
                        fields such as ``artifact_path_map``, ``config_filenames``,
                        ``context_prefixes``, and ``supported_types``.
        created_at:     ISO-8601 creation timestamp or ``None``.
        updated_at:     ISO-8601 last-modified timestamp or ``None``.
    """

    id: str = ""
    tenant_id: str = ""
    name: str = ""
    scope: Optional[str] = None
    dest_path: Optional[str] = None
    overwrite: bool = False
    platform: Optional[str] = None
    extra_metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DeploymentProfileDTO":
        """Construct a DeploymentProfileDTO from a plain dictionary.

        Args:
            data: Mapping with keys matching the DTO attributes.  UUID fields
                are coerced to ``str``; datetime fields are coerced via
                ``_to_iso``; missing keys default to their zero values.

        Returns:
            A fully populated :class:`DeploymentProfileDTO`.
        """
        return cls(
            id=str(data.get("id") or ""),
            tenant_id=str(data.get("tenant_id") or ""),
            name=str(data.get("name") or ""),
            scope=data.get("scope"),
            dest_path=data.get("dest_path"),
            overwrite=bool(data.get("overwrite") or False),
            platform=data.get("platform"),
            extra_metadata=dict(data.get("extra_metadata") or {}),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


@dataclass(frozen=True)
class ArtifactVersionScopeDTO:
    """DTO for EnterpriseArtifactVersionScope — per-owner version scope state.

    Maps from the ``EnterpriseArtifactVersionScope`` ORM model.  Each row
    tracks the current ``head_hash``, optional ``baseline_hash``, divergence
    flag, and promotion state for a specific ``(tenant, project, artifact,
    owner)`` combination.

    Attributes:
        id:               UUID primary key as string.
        tenant_id:        Tenant scope as string.
        project_id:       FK to ``enterprise_projects.id`` as string.
        artifact_id:      FK to ``enterprise_artifacts.id`` as string.
        owner_type:       Owner category: ``'user'``, ``'team'``, or
                          ``'enterprise'``.
        owner_id:         UUID of the owning entity as string.
        head_hash:        SHA-256 hex digest (64 chars) of the current head
                          content.
        baseline_hash:    SHA-256 hex digest of the last approved baseline;
                          ``None`` when no baseline has been established.
        is_diverged:      ``True`` when ``head_hash != baseline_hash``.
        promotion_state:  Current promotion workflow state string (e.g.
                          ``'none'``, ``'pending'``, ``'approved'``); ``None``
                          when not set.
        created_at:       ISO-8601 creation timestamp or ``None``.
        updated_at:       ISO-8601 last-modified timestamp or ``None``.
    """

    id: str = ""
    tenant_id: str = ""
    project_id: str = ""
    artifact_id: str = ""
    owner_type: str = ""
    owner_id: str = ""
    head_hash: str = ""
    baseline_hash: Optional[str] = None
    is_diverged: bool = False
    promotion_state: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ArtifactVersionScopeDTO":
        """Construct an ArtifactVersionScopeDTO from a plain dictionary.

        Args:
            data: Mapping with keys matching the DTO attributes.  UUID fields
                are coerced to ``str``; datetime fields are coerced via
                ``_to_iso``; missing keys default to their zero values.

        Returns:
            A fully populated :class:`ArtifactVersionScopeDTO`.
        """
        return cls(
            id=str(data.get("id") or ""),
            tenant_id=str(data.get("tenant_id") or ""),
            project_id=str(data.get("project_id") or ""),
            artifact_id=str(data.get("artifact_id") or ""),
            owner_type=str(data.get("owner_type") or ""),
            owner_id=str(data.get("owner_id") or ""),
            head_hash=str(data.get("head_hash") or ""),
            baseline_hash=data.get("baseline_hash"),
            is_diverged=bool(data.get("is_diverged") or False),
            promotion_state=data.get("promotion_state"),
            created_at=_to_iso(data.get("created_at")),
            updated_at=_to_iso(data.get("updated_at")),
        )


# =============================================================================
# Internal helpers
# =============================================================================


def _to_iso(value: Any) -> str | None:
    """Coerce *value* to an ISO-8601 string or ``None``.

    Accepts ``datetime`` objects (calls ``.isoformat()``), existing strings
    (returned as-is), and ``None`` (returned as ``None``).

    Args:
        value: A ``datetime``, ISO string, or ``None``.

    Returns:
        ISO-8601 string or ``None``.
    """
    if value is None:
        return None
    if isinstance(value, str):
        return value
    # datetime / date objects
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)
