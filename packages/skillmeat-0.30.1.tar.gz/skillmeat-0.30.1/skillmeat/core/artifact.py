"""Core artifact data models and manager for SkillMeat."""

import logging
import shutil
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from urllib.parse import urlparse

import requests
from rich.prompt import Confirm

from skillmeat.core.enums import Platform, Tool
from skillmeat.utils.logging import redact_path

# Handle tomli/tomllib import for different Python versions
if sys.version_info >= (3, 11):
    import tomllib

    TOML_LOADS = tomllib.loads
else:
    import tomli as tomllib

    TOML_LOADS = tomllib.loads

import tomli_w

TOML_DUMPS = tomli_w.dumps

# Import canonical enums from the detection module
from skillmeat.core.artifact_detection import ArtifactType, CompositeType

# ---------------------------------------------------------------------------
# Frontmatter field validators
# ---------------------------------------------------------------------------

_VALID_EFFORT = frozenset({"low", "medium", "high", "auto"})
_VALID_PERMISSION_MODE = frozenset(
    {"plan", "acceptEdits", "bypassPermissions", "default", "dontAsk", "auto"}
)
_VALID_SCOPE = frozenset({"user", "local", "project"})
_VALID_CONTEXT = frozenset({"fork"})


def validate_effort(value: Optional[str]) -> Optional[str]:
    """Validate the ``effort`` frontmatter field.

    Args:
        value: Raw value from frontmatter, or None.

    Returns:
        The validated value unchanged.

    Raises:
        ValueError: If *value* is not one of the accepted strings.
    """
    if value is None:
        return None
    if value not in _VALID_EFFORT:
        raise ValueError(
            f"Invalid effort value {value!r}. Must be one of: {sorted(_VALID_EFFORT)}"
        )
    return value


def validate_permission_mode(value: Optional[str]) -> Optional[str]:
    """Validate the ``permissionMode`` frontmatter field.

    Args:
        value: Raw value from frontmatter, or None.

    Returns:
        The validated value unchanged.

    Raises:
        ValueError: If *value* is not one of the accepted strings.
    """
    if value is None:
        return None
    if value not in _VALID_PERMISSION_MODE:
        raise ValueError(
            f"Invalid permissionMode value {value!r}. "
            f"Must be one of: {sorted(_VALID_PERMISSION_MODE)}"
        )
    return value


def validate_scope(value: Optional[str]) -> Optional[str]:
    """Validate the ``scope`` frontmatter field.

    Args:
        value: Raw value from frontmatter, or None.

    Returns:
        The validated value unchanged.

    Raises:
        ValueError: If *value* is not one of the accepted strings.
    """
    if value is None:
        return None
    if value not in _VALID_SCOPE:
        raise ValueError(
            f"Invalid scope value {value!r}. Must be one of: {sorted(_VALID_SCOPE)}"
        )
    return value


def validate_context(value: Optional[str]) -> Optional[str]:
    """Validate the ``context`` frontmatter field.

    Args:
        value: Raw value from frontmatter, or None.

    Returns:
        The validated value unchanged.

    Raises:
        ValueError: If *value* is not one of the accepted strings.
    """
    if value is None:
        return None
    if value not in _VALID_CONTEXT:
        raise ValueError(
            f"Invalid context value {value!r}. Must be one of: {sorted(_VALID_CONTEXT)}"
        )
    return value


class UpdateStrategy(str, Enum):
    """Strategies for updating artifacts with local modifications."""

    PROMPT = "prompt"  # Default: ask user what to do
    TAKE_UPSTREAM = "upstream"  # Always take upstream (lose local changes)
    KEEP_LOCAL = "local"  # Keep local modifications (skip update)
    # Phase 2: MERGE = "merge"  # 3-way merge (deferred)


@dataclass
class ArtifactMetadata:
    """Metadata extracted from artifact files (SKILL.md, COMMAND.md, AGENT.md)."""

    title: Optional[str] = None
    description: Optional[str] = None
    author: Optional[str] = None
    license: Optional[str] = None
    version: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    tools: List[Tool] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)
    linked_artifacts: List["LinkedArtifactReference"] = field(default_factory=list)
    unlinked_references: List[str] = field(default_factory=list)
    # Claude Code frontmatter fields
    effort: Optional[str] = None
    model: Optional[str] = None
    allowed_tools: Optional[List[str]] = None
    disallowed_tools: Optional[List[str]] = None
    permission_mode: Optional[str] = None
    context: Optional[str] = None
    scope: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for TOML serialization."""
        result = {}
        if self.title is not None:
            result["title"] = self.title
        if self.description is not None:
            result["description"] = self.description
        if self.author is not None:
            result["author"] = self.author
        if self.license is not None:
            result["license"] = self.license
        if self.version is not None:
            result["version"] = self.version
        if self.dependencies:
            result["dependencies"] = self.dependencies
        if self.tools:
            result["tools"] = [tool.value for tool in self.tools]
        if self.extra:
            result["extra"] = self.extra
        if self.linked_artifacts:
            result["linked_artifacts"] = [la.to_dict() for la in self.linked_artifacts]
        if self.unlinked_references:
            result["unlinked_references"] = self.unlinked_references
        # Claude Code frontmatter fields — use original frontmatter key names
        if self.effort is not None:
            result["effort"] = self.effort
        if self.model is not None:
            result["model"] = self.model
        if self.allowed_tools is not None:
            result["allowed-tools"] = self.allowed_tools
        if self.disallowed_tools is not None:
            result["disallowedTools"] = self.disallowed_tools
        if self.permission_mode is not None:
            result["permissionMode"] = self.permission_mode
        if self.context is not None:
            result["context"] = self.context
        if self.scope is not None:
            result["scope"] = self.scope
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ArtifactMetadata":
        """Create from dictionary (TOML deserialization)."""
        # Parse tools from string values
        tools_data = data.get("tools", [])
        tools = []
        for tool_str in tools_data:
            try:
                tools.append(Tool(tool_str))
            except ValueError:
                # Unknown tool - skip (graceful handling)
                pass

        # Parse linked_artifacts - deferred to avoid circular reference
        # LinkedArtifactReference.from_dict is called after that class is defined
        linked_artifacts_data = data.get("linked_artifacts", [])
        # Store raw data; will be parsed in __post_init__ or lazily
        # For now, we'll parse them here since LinkedArtifactReference is defined below
        linked_artifacts = []
        for la_data in linked_artifacts_data:
            if isinstance(la_data, dict):
                # Defer to LinkedArtifactReference.from_dict (forward reference)
                # This will work at runtime since the class is defined by then
                linked_artifacts.append(la_data)  # Store as dict, parse later

        # Extract and validate Claude Code frontmatter fields
        # Key mapping: frontmatter key → python attribute
        #   allowed-tools   → allowed_tools
        #   disallowedTools → disallowed_tools
        #   permissionMode  → permission_mode
        #   others keep the same name
        raw_effort = data.get("effort")
        raw_permission_mode = data.get("permissionMode")
        raw_scope = data.get("scope")
        raw_context = data.get("context")

        try:
            effort = validate_effort(raw_effort)
        except ValueError:
            effort = None

        try:
            permission_mode = validate_permission_mode(raw_permission_mode)
        except ValueError:
            permission_mode = None

        try:
            scope = validate_scope(raw_scope)
        except ValueError:
            scope = None

        try:
            context = validate_context(raw_context)
        except ValueError:
            context = None

        return cls(
            title=data.get("title"),
            description=data.get("description"),
            author=data.get("author"),
            license=data.get("license"),
            version=data.get("version"),
            tags=data.get("tags", []),
            dependencies=data.get("dependencies", []),
            tools=tools,
            extra=data.get("extra", {}),
            linked_artifacts=linked_artifacts,  # Will be parsed in resolve_linked_artifacts()
            unlinked_references=data.get("unlinked_references", []),
            effort=effort,
            model=data.get("model"),
            allowed_tools=data.get("allowed-tools"),
            disallowed_tools=data.get("disallowedTools"),
            permission_mode=permission_mode,
            context=context,
            scope=scope,
        )

    def resolve_linked_artifacts(self) -> None:
        """Resolve linked_artifacts from dict to LinkedArtifactReference objects.

        Called after LinkedArtifactReference is available to convert raw dicts
        to proper dataclass instances.
        """
        resolved = []
        for la in self.linked_artifacts:
            if isinstance(la, dict):
                resolved.append(LinkedArtifactReference.from_dict(la))
            else:
                resolved.append(la)
        self.linked_artifacts = resolved


@dataclass
class LinkedArtifactReference:
    """Reference to a linked artifact.

    Represents a relationship between two artifacts. Used for:
    - Skills required by agents (link_type='requires')
    - Agents enabled by skills (link_type='enables')
    - General related artifacts (link_type='related')

    Attributes:
        artifact_name: Display name of target artifact
        artifact_type: Type of target artifact (skill, agent, etc.)
        artifact_id: ID of target artifact (None if external/unresolved)
        source_name: Source where target was found (GitHub repo, etc.)
        link_type: Type of relationship (requires, enables, related)
        created_at: When link was created
    """

    artifact_name: str
    artifact_type: "ArtifactType"
    artifact_id: Optional[str] = None
    source_name: Optional[str] = None
    link_type: str = "requires"  # requires, enables, related
    created_at: Optional[datetime] = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    def __post_init__(self):
        """Validate link_type."""
        valid_types = ("requires", "enables", "related")
        if self.link_type not in valid_types:
            raise ValueError(
                f"link_type must be one of {valid_types}, got {self.link_type}"
            )

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "artifact_id": self.artifact_id,
            "artifact_name": self.artifact_name,
            "artifact_type": (
                self.artifact_type.value
                if isinstance(self.artifact_type, ArtifactType)
                else str(self.artifact_type)
            ),
            "source_name": self.source_name,
            "link_type": self.link_type,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LinkedArtifactReference":
        """Deserialize from dictionary."""
        artifact_type = data.get("artifact_type")
        if isinstance(artifact_type, str):
            try:
                artifact_type = ArtifactType(artifact_type)
            except ValueError:
                artifact_type = ArtifactType.SKILL  # Default fallback

        created_at = data.get("created_at")
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at.replace("Z", "+00:00"))

        return cls(
            artifact_id=data.get("artifact_id"),
            artifact_name=data["artifact_name"],
            artifact_type=artifact_type,
            source_name=data.get("source_name"),
            link_type=data.get("link_type", "requires"),
            created_at=created_at,
        )


@dataclass
class Artifact:
    """Unified artifact representation."""

    name: str
    type: ArtifactType
    path: str  # relative to collection root (e.g., "skills/python-skill/")
    origin: str  # "local", "github", or "marketplace"
    metadata: ArtifactMetadata
    added: datetime
    upstream: Optional[str] = None  # GitHub URL if from GitHub
    version_spec: Optional[str] = None  # "latest", "v1.0.0", "branch-name"
    resolved_sha: Optional[str] = None
    resolved_version: Optional[str] = None
    last_updated: Optional[datetime] = None
    discovered_at: Optional[datetime] = (
        None  # When artifact was first discovered or last changed
    )
    tags: List[str] = field(default_factory=list)
    origin_source: Optional[str] = (
        None  # Platform type when origin="marketplace" (e.g., "github", "gitlab", "bitbucket")
    )
    target_platforms: Optional[List[Platform]] = (
        None  # None means deployable on all platforms; otherwise restricted to listed platforms
    )
    import_id: Optional[str] = None  # Catalog entry import batch ID
    uuid: Optional[str] = (
        None  # Stable cross-context identity UUID from DB cache (ADR-007); 32-char hex, no dashes
    )

    def __post_init__(self):
        """Validate artifact configuration.

        Security: This validation prevents path traversal attacks by ensuring
        artifact names cannot contain path separators or directory references.
        See security review CRITICAL-1 for details.
        """
        if not self.name:
            raise ValueError("Artifact name cannot be empty")

        # CRITICAL SECURITY: Prevent path traversal attacks
        # Artifact names must be simple identifiers without path components
        if "/" in self.name or "\\" in self.name:
            raise ValueError(
                f"Invalid artifact name '{self.name}': "
                "artifact names cannot contain path separators (/ or \\)"
            )

        if ".." in self.name:
            raise ValueError(
                f"Invalid artifact name '{self.name}': "
                "artifact names cannot contain parent directory references (..)"
            )

        # Prevent hidden/system files (security consideration)
        if self.name.startswith("."):
            raise ValueError(
                f"Invalid artifact name '{self.name}': "
                "artifact names cannot start with '.'"
            )

        if self.origin not in ("local", "github", "marketplace"):
            raise ValueError(
                f"Invalid origin: {self.origin}. Must be 'local', 'github', or 'marketplace'."
            )

        # Validate origin_source: only allowed when origin is "marketplace"
        valid_origin_sources = ("github", "gitlab", "bitbucket")
        if self.origin_source is not None:
            if self.origin != "marketplace":
                raise ValueError(
                    f"origin_source can only be set when origin is 'marketplace', "
                    f"but origin is '{self.origin}'"
                )
            if self.origin_source not in valid_origin_sources:
                raise ValueError(
                    f"Invalid origin_source: {self.origin_source}. "
                    f"Must be one of: {', '.join(valid_origin_sources)}"
                )

        # Validate/normalize target_platforms
        if self.target_platforms is not None:
            if len(self.target_platforms) == 0:
                raise ValueError(
                    "target_platforms cannot be an empty list. "
                    "Use None for deployable-on-all semantics."
                )
            normalized_platforms: List[Platform] = []
            for platform in self.target_platforms:
                if isinstance(platform, str):
                    normalized_platforms.append(Platform(platform))
                else:
                    normalized_platforms.append(platform)
            self.target_platforms = normalized_platforms

        # Ensure type is ArtifactType enum
        if isinstance(self.type, str):
            self.type = ArtifactType(self.type)

        # Consolidate: merge metadata.tags into top-level tags (single source of truth)
        if self.metadata and self.metadata.tags:
            self.tags = list(dict.fromkeys(self.tags + self.metadata.tags))
            self.metadata.tags = []

    def composite_key(self) -> tuple:
        """Return unique composite key (name, type)."""
        return (self.name, self.type.value)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for TOML serialization."""
        result = {
            "name": self.name,
            "type": self.type.value,
            "path": self.path,
            "origin": self.origin,
            "added": self.added.isoformat(),
        }

        # Add metadata if present
        metadata_dict = self.metadata.to_dict()
        if metadata_dict:
            result["metadata"] = metadata_dict

        # Add optional fields
        if self.upstream is not None:
            result["upstream"] = self.upstream
        if self.version_spec is not None:
            result["version_spec"] = self.version_spec
        if self.resolved_sha is not None:
            result["resolved_sha"] = self.resolved_sha
        if self.resolved_version is not None:
            result["resolved_version"] = self.resolved_version
        if self.last_updated is not None:
            result["last_updated"] = self.last_updated.isoformat()
        if self.discovered_at is not None:
            result["discovered_at"] = self.discovered_at.isoformat()
        if self.tags:
            result["tags"] = self.tags
        if self.origin_source is not None:
            result["origin_source"] = self.origin_source
        if self.target_platforms is not None:
            result["target_platforms"] = [
                platform.value for platform in self.target_platforms
            ]
        if self.import_id is not None:
            result["import_id"] = self.import_id
        if self.uuid is not None:
            result["uuid"] = self.uuid

        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Artifact":
        """Create from dictionary (TOML deserialization)."""
        # Parse metadata
        metadata_data = data.get("metadata", {})
        metadata = ArtifactMetadata.from_dict(metadata_data)

        # Parse datetimes
        added = datetime.fromisoformat(data["added"])
        last_updated = None
        if "last_updated" in data and data["last_updated"] is not None:
            last_updated = datetime.fromisoformat(data["last_updated"])
        discovered_at = None
        if "discovered_at" in data and data["discovered_at"] is not None:
            discovered_at = datetime.fromisoformat(data["discovered_at"])

        return cls(
            name=data["name"],
            type=ArtifactType(data["type"]),
            path=data["path"],
            origin=data["origin"],
            metadata=metadata,
            added=added,
            upstream=data.get("upstream"),
            version_spec=data.get("version_spec"),
            resolved_sha=data.get("resolved_sha"),
            resolved_version=data.get("resolved_version"),
            last_updated=last_updated,
            discovered_at=discovered_at,
            tags=data.get("tags", []),
            origin_source=data.get("origin_source"),
            target_platforms=data.get("target_platforms"),
            import_id=data.get("import_id"),
            uuid=data.get("uuid"),
        )


@dataclass
class UpdateFetchResult:
    """Result of fetching an update from upstream (before applying).

    This represents a fetched update cached in a temp workspace for inspection.
    """

    artifact: Artifact
    has_update: bool
    update_info: Optional[Any] = None  # UpdateInfo from sources.base
    fetch_result: Optional[Any] = None  # FetchResult from sources.base
    temp_workspace: Optional[Path] = None  # Persistent temp path for inspection
    error: Optional[str] = None  # Error message if fetch failed


@dataclass
class UpdateResult:
    """Result of attempting to update an artifact."""

    artifact: Artifact
    updated: bool
    status: str
    previous_version: Optional[str] = None
    new_version: Optional[str] = None
    previous_sha: Optional[str] = None
    new_sha: Optional[str] = None
    local_modifications: bool = False


class ArtifactManager:
    """Manages artifacts within collections."""

    def __init__(self, collection_mgr=None):
        """Initialize artifact manager.

        Args:
            collection_mgr: CollectionManager instance (creates default if None)
        """
        if collection_mgr is None:
            from skillmeat.core.collection import CollectionManager

            collection_mgr = CollectionManager()

        self.collection_mgr = collection_mgr
        config = self.collection_mgr.config
        github_token = config.get("settings.github-token")

        from skillmeat.sources.github import GitHubSource
        from skillmeat.sources.local import LocalSource
        from skillmeat.utils.filesystem import FilesystemManager, compute_content_hash
        from skillmeat.utils.validator import ArtifactValidator

        self.github_source = GitHubSource(github_token)
        self.local_source = LocalSource()
        self.filesystem_mgr = FilesystemManager()
        self.validator = ArtifactValidator()
        self.compute_content_hash = compute_content_hash

    def add_from_github(
        self,
        spec: str,
        artifact_type: ArtifactType,
        collection_name: Optional[str] = None,
        custom_name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        target_platforms: Optional[List[Platform]] = None,
        force: bool = False,
    ) -> Artifact:
        """Add artifact from GitHub.

        Args:
            spec: GitHub spec (e.g., "username/repo/path@version")
            artifact_type: Type of artifact
            collection_name: Target collection (uses active if None)
            custom_name: Custom artifact name (derives from spec if None)
            tags: Optional tags to add
            target_platforms: Optional platform restrictions for deployment
            force: If True, overwrite existing artifact

        Returns:
            Added Artifact object

        Raises:
            ValueError: Invalid spec or artifact already exists (when force=False)
            RuntimeError: Fetch or validation failed
        """
        from skillmeat.sources.github import ArtifactSpec

        # Load collection
        collection = self.collection_mgr.load_collection(collection_name)

        # Fetch from GitHub
        fetch_result = self.github_source.fetch(spec, artifact_type)

        # Determine artifact name
        if custom_name:
            artifact_name = custom_name
        else:
            # Extract name from spec (last path component)
            parsed_spec = ArtifactSpec.parse(spec)
            if parsed_spec.path:
                artifact_name = Path(parsed_spec.path).stem
            else:
                # If no path, use repo name
                artifact_name = parsed_spec.repo

        # Check for duplicates (composite key)
        existing = collection.find_artifact(artifact_name, artifact_type)
        if existing:
            if force:
                # Remove existing artifact before adding new one
                self.remove(artifact_name, artifact_type, collection_name)
                # Reload collection after removal
                collection = self.collection_mgr.load_collection(collection_name)
            else:
                raise ValueError(
                    f"Artifact '{artifact_name}' of type '{artifact_type.value}' already exists in collection"
                )

        # Determine storage path within collection
        collection_path = self.collection_mgr.config.get_collection_path(
            collection.name
        )
        if artifact_type == ArtifactType.SKILL:
            artifact_storage_path = collection_path / "skills" / artifact_name
        elif artifact_type == ArtifactType.COMMAND:
            artifact_storage_path = collection_path / "commands" / f"{artifact_name}.md"
        elif artifact_type == ArtifactType.AGENT:
            artifact_storage_path = collection_path / "agents" / f"{artifact_name}.md"
        elif artifact_type == ArtifactType.COMPOSITE:
            artifact_storage_path = collection_path / "composites" / artifact_name
        elif artifact_type == ArtifactType.WORKFLOW:
            artifact_storage_path = collection_path / "workflows" / artifact_name
        else:
            raise ValueError(f"Unsupported artifact type: {artifact_type}")

        # Copy artifact to collection
        self.filesystem_mgr.copy_artifact(
            fetch_result.artifact_path, artifact_storage_path, artifact_type
        )

        # Apply auto-linking (non-blocking)
        # Extract source name from spec for link tracking
        parsed_spec = ArtifactSpec.parse(spec)
        source_name = f"{parsed_spec.username}/{parsed_spec.repo}"
        self._apply_auto_linking(
            metadata=fetch_result.metadata,
            artifact_type=artifact_type,
            artifact_name=artifact_name,
            collection_name=collection_name,
            source_name=source_name,
        )

        # Create Artifact object
        artifact = Artifact(
            name=artifact_name,
            type=artifact_type,
            path=str(artifact_storage_path.relative_to(collection_path)),
            origin="github",
            metadata=fetch_result.metadata,
            added=datetime.utcnow(),
            upstream=fetch_result.upstream_url,
            version_spec=ArtifactSpec.parse(spec).version,
            resolved_sha=fetch_result.resolved_sha,
            resolved_version=fetch_result.resolved_version,
            tags=tags or [],
            target_platforms=target_platforms,
            uuid=self._lookup_collection_artifact_uuid(
                artifact_name, artifact_type.value
            ),
        )

        # Add to collection
        collection.add_artifact(artifact)
        self.collection_mgr.save_collection(collection)

        # Update lock file
        content_hash = self.compute_content_hash(artifact_storage_path)
        self.collection_mgr.lock_mgr.update_entry(
            collection_path,
            artifact.name,
            artifact.type,
            artifact.upstream,
            artifact.resolved_sha,
            artifact.resolved_version,
            content_hash,
        )

        # TODO: VCS v2 — version seed after DB cache sync
        # CLI path has no DB session; version seeding must happen in the
        # post-add cache refresh (refresh_single_artifact_cache) instead.

        return artifact

    def add_from_local(
        self,
        path: str,
        artifact_type: ArtifactType,
        collection_name: Optional[str] = None,
        custom_name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        target_platforms: Optional[List[Platform]] = None,
        force: bool = False,
    ) -> Artifact:
        """Add artifact from local filesystem.

        Args:
            path: Local path to artifact
            artifact_type: Type of artifact
            collection_name: Target collection (uses active if None)
            custom_name: Custom artifact name (derives from path if None)
            tags: Optional tags to add
            target_platforms: Optional platform restrictions for deployment
            force: If True, overwrite existing artifact

        Returns:
            Added Artifact object

        Raises:
            ValueError: Invalid path or artifact already exists (when force=False)
            RuntimeError: Fetch or validation failed
        """
        # Load collection
        collection = self.collection_mgr.load_collection(collection_name)

        # Fetch from local
        fetch_result = self.local_source.fetch(path, artifact_type)

        # Determine artifact name
        if custom_name:
            artifact_name = custom_name
        else:
            artifact_name = Path(path).stem

        # Check for duplicates
        existing = collection.find_artifact(artifact_name, artifact_type)
        if existing:
            if force:
                # Remove existing artifact before adding new one
                self.remove(artifact_name, artifact_type, collection_name)
                # Reload collection after removal
                collection = self.collection_mgr.load_collection(collection_name)
            else:
                raise ValueError(
                    f"Artifact '{artifact_name}' of type '{artifact_type.value}' already exists"
                )

        # Determine storage path
        collection_path = self.collection_mgr.config.get_collection_path(
            collection.name
        )
        if artifact_type == ArtifactType.SKILL:
            artifact_storage_path = collection_path / "skills" / artifact_name
        elif artifact_type == ArtifactType.COMMAND:
            artifact_storage_path = collection_path / "commands" / f"{artifact_name}.md"
        elif artifact_type == ArtifactType.AGENT:
            artifact_storage_path = collection_path / "agents" / f"{artifact_name}.md"
        elif artifact_type == ArtifactType.COMPOSITE:
            artifact_storage_path = collection_path / "composites" / artifact_name
        elif artifact_type == ArtifactType.WORKFLOW:
            artifact_storage_path = collection_path / "workflows" / artifact_name
        else:
            raise ValueError(f"Unsupported artifact type: {artifact_type}")

        # Copy artifact to collection
        self.filesystem_mgr.copy_artifact(
            fetch_result.artifact_path, artifact_storage_path, artifact_type
        )

        # Apply auto-linking (non-blocking)
        # For local imports, use the path as source identifier
        source_name = f"local:{Path(path).name}"
        self._apply_auto_linking(
            metadata=fetch_result.metadata,
            artifact_type=artifact_type,
            artifact_name=artifact_name,
            collection_name=collection_name,
            source_name=source_name,
        )

        # Create Artifact object (no upstream)
        artifact = Artifact(
            name=artifact_name,
            type=artifact_type,
            path=str(artifact_storage_path.relative_to(collection_path)),
            origin="local",
            metadata=fetch_result.metadata,
            added=datetime.utcnow(),
            tags=tags or [],
            target_platforms=target_platforms,
            uuid=self._lookup_collection_artifact_uuid(
                artifact_name, artifact_type.value
            ),
        )

        # Add to collection
        collection.add_artifact(artifact)
        self.collection_mgr.save_collection(collection)

        # Update lock file
        content_hash = self.compute_content_hash(artifact_storage_path)
        self.collection_mgr.lock_mgr.update_entry(
            collection_path,
            artifact.name,
            artifact.type,
            None,  # No upstream
            None,  # No SHA
            None,  # No version
            content_hash,
        )

        # TODO: VCS v2 — version seed after DB cache sync
        # CLI path has no DB session; version seeding must happen in the
        # post-add cache refresh (refresh_single_artifact_cache) instead.

        return artifact

    def remove(
        self,
        artifact_name: str,
        artifact_type: ArtifactType,
        collection_name: Optional[str] = None,
    ) -> None:
        """Remove artifact from collection.

        Args:
            artifact_name: Name of artifact to remove
            artifact_type: Type of artifact
            collection_name: Collection name (uses active if None)

        Raises:
            ValueError: Artifact not found
        """
        # Create auto-snapshot before removal
        from skillmeat.core.version import VersionManager

        version_mgr = VersionManager(self.collection_mgr)
        version_mgr.auto_snapshot(
            collection_name, f"Before removing {artifact_type.value}/{artifact_name}"
        )

        collection = self.collection_mgr.load_collection(collection_name)

        # Find artifact
        artifact = collection.find_artifact(artifact_name, artifact_type)
        if not artifact:
            raise ValueError(
                f"Artifact '{artifact_name}' of type '{artifact_type.value}' not found"
            )

        # Remove from filesystem
        collection_path = self.collection_mgr.config.get_collection_path(
            collection.name
        )
        artifact_path = collection_path / artifact.path
        self.filesystem_mgr.remove_artifact(artifact_path)

        # Remove from collection
        collection.remove_artifact(artifact_name, artifact_type)
        self.collection_mgr.save_collection(collection)

        # Remove from lock file
        self.collection_mgr.lock_mgr.remove_entry(
            collection_path, artifact_name, artifact_type
        )

        # Track remove event
        self._record_remove_event(
            artifact_name=artifact_name,
            artifact_type=artifact_type.value,
            collection_name=collection.name,
            reason="user_action",
            from_project=False,
        )

    def list_artifacts(
        self,
        collection_name: Optional[str] = None,
        artifact_type: Optional[Union[ArtifactType, List[ArtifactType]]] = None,
        tags: Optional[List[str]] = None,
    ) -> List[Artifact]:
        """List artifacts with optional filters.

        Args:
            collection_name: Collection name (uses active if None)
            artifact_type: Filter by type (single or list of ArtifactType)
            tags: Filter by tags (any match)

        Returns:
            List of matching artifacts
        """
        collection = self.collection_mgr.load_collection(collection_name)

        artifacts = collection.artifacts

        # Filter by type (supports single value or list)
        if artifact_type:
            if isinstance(artifact_type, list):
                type_set = set(artifact_type)
                artifacts = [a for a in artifacts if a.type in type_set]
            else:
                artifacts = [a for a in artifacts if a.type == artifact_type]

        # Filter by tags
        if tags:
            artifacts = [a for a in artifacts if any(tag in a.tags for tag in tags)]

        return artifacts

    def show(
        self,
        artifact_name: str,
        artifact_type: Optional[ArtifactType] = None,
        collection_name: Optional[str] = None,
    ) -> Artifact:
        """Get detailed artifact information.

        Args:
            artifact_name: Artifact name
            artifact_type: Artifact type (required if name is ambiguous)
            collection_name: Collection name (uses active if None)

        Returns:
            Artifact object

        Raises:
            ValueError: Artifact not found or name ambiguous
        """
        collection = self.collection_mgr.load_collection(collection_name)
        artifact = collection.find_artifact(artifact_name, artifact_type)

        if not artifact:
            raise ValueError(f"Artifact '{artifact_name}' not found")

        return artifact

    def check_updates(self, collection_name: Optional[str] = None) -> Dict[str, Any]:
        """Check all artifacts for updates.

        Args:
            collection_name: Collection name (uses active if None)

        Returns:
            Dict mapping artifact composite key to UpdateInfo
        """
        from skillmeat.sources.base import UpdateInfo

        collection = self.collection_mgr.load_collection(collection_name)
        updates = {}

        for artifact in collection.artifacts:
            is_github_backed = artifact.origin == "github" or (
                artifact.origin == "marketplace" and artifact.origin_source == "github"
            )
            if is_github_backed:
                update_info = self.github_source.check_updates(artifact)
                if update_info and update_info.has_update:
                    key = f"{artifact.name}::{artifact.type.value}"
                    updates[key] = update_info

        return updates

    def fetch_update(
        self,
        artifact_name: str,
        artifact_type: Optional[ArtifactType] = None,
        collection_name: Optional[str] = None,
    ) -> UpdateFetchResult:
        """Fetch update from upstream and cache in temp workspace for inspection.

        This method fetches the latest version of an artifact from its upstream source
        and stores it in a persistent temporary workspace without applying the update.
        This allows inspection and comparison before deciding to apply changes.

        Args:
            artifact_name: Artifact name
            artifact_type: Artifact type (required if ambiguous)
            collection_name: Collection name (uses active if None)

        Returns:
            UpdateFetchResult with fetch details and temp workspace path

        Raises:
            ValueError: Artifact not found or unsupported origin
        """
        import tempfile
        from skillmeat.sources.base import UpdateInfo

        # Load collection and find artifact
        try:
            collection = self.collection_mgr.load_collection(collection_name)
        except Exception as e:
            # Return error result if collection loading fails
            return UpdateFetchResult(
                artifact=None,
                has_update=False,
                error=f"Failed to load collection: {e}",
            )

        try:
            artifact = collection.find_artifact(artifact_name, artifact_type)
        except Exception as e:
            return UpdateFetchResult(
                artifact=None,
                has_update=False,
                error=f"Error finding artifact: {e}",
            )

        if not artifact:
            return UpdateFetchResult(
                artifact=None,
                has_update=False,
                error=f"Artifact '{artifact_name}' not found in collection",
            )

        # Only GitHub-backed artifacts support updates
        is_github_backed = artifact.origin == "github" or (
            artifact.origin == "marketplace" and artifact.origin_source == "github"
        )
        if not is_github_backed:
            return UpdateFetchResult(
                artifact=artifact,
                has_update=False,
                error=f"Artifact origin '{artifact.origin}' does not support upstream updates",
            )

        # Check if upstream reference exists
        if not artifact.upstream:
            return UpdateFetchResult(
                artifact=artifact,
                has_update=False,
                error="Artifact does not have an upstream reference",
            )

        # Check for updates
        try:
            update_info = self.github_source.check_updates(artifact)
        except Exception as e:
            return UpdateFetchResult(
                artifact=artifact,
                has_update=False,
                error=f"Failed to check for updates: {e}",
            )

        # No updates available
        if not update_info or not update_info.has_update:
            return UpdateFetchResult(
                artifact=artifact,
                has_update=False,
                update_info=update_info,
            )

        # Create persistent temp workspace
        temp_workspace = None
        fetch_result = None

        try:
            # Create temp directory with descriptive prefix
            temp_workspace = Path(
                tempfile.mkdtemp(
                    prefix=f"skillmeat_update_{artifact.name}_{artifact.type.value}_"
                )
            )

            # Build spec for fetching updated version
            override_version = update_info.latest_sha or artifact.version_spec
            spec = self._build_spec_from_artifact(
                artifact, version_override=override_version
            )

            # Fetch the updated artifact to temp workspace
            # Note: GitHubSource.fetch creates its own temp dir inside,
            # so we copy the result to our persistent temp workspace
            fetch_result = self.github_source.fetch(spec, artifact.type)

            # Copy fetched artifact to persistent workspace for inspection
            workspace_artifact_path = temp_workspace / "artifact"
            self.filesystem_mgr.copy_artifact(
                fetch_result.artifact_path, workspace_artifact_path, artifact.type
            )

            # Update fetch_result to point to persistent workspace
            fetch_result.artifact_path = workspace_artifact_path

            logging.info(
                f"Fetched update for {artifact.type.value}/{artifact.name} "
                f"to {redact_path(temp_workspace)}"
            )

            return UpdateFetchResult(
                artifact=artifact,
                has_update=True,
                update_info=update_info,
                fetch_result=fetch_result,
                temp_workspace=temp_workspace,
            )

        except ValueError as e:
            # Validation or parsing errors
            error_msg = f"Invalid artifact source: {e}"
            logging.error(error_msg)

            # Clean up temp workspace on error
            if temp_workspace and temp_workspace.exists():
                shutil.rmtree(temp_workspace, ignore_errors=True)

            return UpdateFetchResult(
                artifact=artifact,
                has_update=False,
                update_info=update_info,
                error=error_msg,
            )

        except requests.exceptions.RequestException as e:
            # Network failures
            error_msg = f"Network error while fetching update: {e}"
            logging.error(error_msg)

            # Clean up temp workspace on error
            if temp_workspace and temp_workspace.exists():
                shutil.rmtree(temp_workspace, ignore_errors=True)

            return UpdateFetchResult(
                artifact=artifact,
                has_update=False,
                update_info=update_info,
                error=error_msg,
            )

        except PermissionError as e:
            # Permission issues
            error_msg = (
                f"Permission denied while fetching update: {e}. "
                "Check GitHub token configuration if accessing private repositories."
            )
            logging.error(error_msg)

            # Clean up temp workspace on error
            if temp_workspace and temp_workspace.exists():
                shutil.rmtree(temp_workspace, ignore_errors=True)

            return UpdateFetchResult(
                artifact=artifact,
                has_update=False,
                update_info=update_info,
                error=error_msg,
            )

        except Exception as e:
            # Unexpected errors
            error_msg = f"Unexpected error while fetching update: {e}"
            logging.error(error_msg)

            # Clean up temp workspace on error
            if temp_workspace and temp_workspace.exists():
                shutil.rmtree(temp_workspace, ignore_errors=True)

            return UpdateFetchResult(
                artifact=artifact,
                has_update=False,
                update_info=update_info,
                error=error_msg,
            )

    def _show_update_preview(
        self,
        artifact_ref: str,
        current_path: Path,
        update_path: Path,
        strategy: str,
        console,
    ) -> Dict[str, Any]:
        """Show comprehensive preview of what update will change.

        Args:
            artifact_ref: Artifact reference (type/name)
            current_path: Path to current version
            update_path: Path to updated version
            strategy: Update strategy being used
            console: Rich console for output

        Returns:
            Dict with preview data including:
            - diff_result: DiffResult from DiffEngine
            - three_way_diff: Optional[ThreeWayDiffResult] for merge strategy
            - conflicts_detected: bool
            - can_auto_merge: bool
            - recommendation: str (recommended strategy)
            - recommendation_reason: str
        """
        from skillmeat.core.diff_engine import DiffEngine
        from skillmeat.core.merge_engine import MergeEngine

        diff_engine = DiffEngine()
        preview_data = {}

        # Generate diff between current and updated versions
        diff_result = diff_engine.diff_directories(current_path, update_path)
        preview_data["diff_result"] = diff_result

        # Show summary header
        console.print(f"\n[bold]Update Preview for {artifact_ref}[/bold]")
        console.print(f"Strategy: [cyan]{strategy}[/cyan]\n")

        # Summary statistics
        total_changes = (
            len(diff_result.files_added)
            + len(diff_result.files_removed)
            + len(diff_result.files_modified)
        )
        console.print(f"[bold]Summary:[/bold]")
        console.print(f"  Files changed: {total_changes}")
        console.print(f"  Files added: [green]{len(diff_result.files_added)}[/green]")
        console.print(f"  Files removed: [red]{len(diff_result.files_removed)}[/red]")
        console.print(
            f"  Files modified: [yellow]{len(diff_result.files_modified)}[/yellow]"
        )

        if diff_result.total_lines_added or diff_result.total_lines_removed:
            console.print(
                f"  Lines: [green]+{diff_result.total_lines_added}[/green] "
                f"[red]-{diff_result.total_lines_removed}[/red]"
            )

        # For merge strategy, show merge preview with conflict detection
        if strategy == "merge":
            console.print(f"\n[bold]Merge Analysis:[/bold]")
            merge_engine = MergeEngine()

            # Perform three-way diff to detect conflicts
            # Phase 0: Use current as base (base == local)
            three_way_diff = diff_engine.three_way_diff(
                base_path=current_path,
                local_path=current_path,
                remote_path=update_path,
            )
            preview_data["three_way_diff"] = three_way_diff

            auto_mergeable_count = len(three_way_diff.auto_mergeable)
            conflicts_count = len(three_way_diff.conflicts)

            console.print(
                f"  Auto-mergeable files: [green]{auto_mergeable_count}[/green]"
            )
            console.print(f"  Conflicted files: [yellow]{conflicts_count}[/yellow]")

            preview_data["conflicts_detected"] = conflicts_count > 0
            preview_data["can_auto_merge"] = conflicts_count == 0

            if conflicts_count > 0:
                console.print(
                    f"\n[yellow]Warning: {conflicts_count} files have conflicts:[/yellow]"
                )
                for conflict in three_way_diff.conflicts[:5]:
                    console.print(
                        f"  - {conflict.file_path} ({conflict.conflict_type})"
                    )
                if conflicts_count > 5:
                    console.print(f"  ... and {conflicts_count - 5} more")

                console.print(
                    f"\n[yellow]Files with conflicts will contain Git-style markers:[/yellow]"
                )
                console.print("  <<<<<<< LOCAL (current)")
                console.print("  [your local changes]")
                console.print("  =======")
                console.print("  [incoming upstream changes]")
                console.print("  >>>>>>> REMOTE (incoming)")
        else:
            preview_data["conflicts_detected"] = False
            preview_data["can_auto_merge"] = True

        # Show file details (limited)
        if diff_result.files_added:
            console.print(f"\n[bold]Added Files:[/bold]")
            for file in diff_result.files_added[:5]:
                console.print(f"  [green]+[/green] {file}")
            if len(diff_result.files_added) > 5:
                console.print(
                    f"  ... and {len(diff_result.files_added) - 5} more files"
                )

        if diff_result.files_removed:
            console.print(f"\n[bold]Removed Files:[/bold]")
            for file in diff_result.files_removed[:5]:
                console.print(f"  [red]-[/red] {file}")
            if len(diff_result.files_removed) > 5:
                console.print(
                    f"  ... and {len(diff_result.files_removed) - 5} more files"
                )

        if diff_result.files_modified:
            console.print(f"\n[bold]Modified Files:[/bold]")
            for file_diff in diff_result.files_modified[:5]:
                console.print(
                    f"  [yellow]M[/yellow] {file_diff.path} "
                    f"([green]+{file_diff.lines_added}[/green] "
                    f"[red]-{file_diff.lines_removed}[/red])"
                )
            if len(diff_result.files_modified) > 5:
                console.print(
                    f"  ... and {len(diff_result.files_modified) - 5} more files"
                )

        return preview_data

    def _recommend_strategy(
        self,
        diff_result,
        has_local_modifications: bool,
        three_way_diff=None,
    ) -> tuple:
        """Recommend update strategy based on changes.

        Args:
            diff_result: DiffResult from comparing current vs upstream
            has_local_modifications: Whether local modifications exist
            three_way_diff: Optional ThreeWayDiffResult if available

        Returns:
            Tuple of (strategy: str, reason: str)

        Logic:
        - No local modifications → "overwrite" (safe to replace)
        - Local mods + no conflicts → "merge" (auto-merge possible)
        - Local mods + conflicts → "prompt" (user decision needed)
        - Complex changes (many files) → "prompt" (review recommended)
        """
        # No local modifications - safe to overwrite
        if not has_local_modifications:
            return ("overwrite", "No local modifications detected - safe to replace")

        # Check if we have three-way diff info (merge strategy)
        if three_way_diff is not None:
            conflicts_count = len(three_way_diff.conflicts)

            if conflicts_count == 0:
                return (
                    "merge",
                    f"All {len(three_way_diff.auto_mergeable)} changes can auto-merge",
                )
            elif conflicts_count < 3:
                return (
                    "prompt",
                    f"{conflicts_count} conflicts detected - review recommended",
                )
            else:
                return (
                    "prompt",
                    f"{conflicts_count} conflicts detected - manual resolution required",
                )

        # Check complexity based on file counts
        total_changes = (
            len(diff_result.files_added)
            + len(diff_result.files_removed)
            + len(diff_result.files_modified)
        )

        if total_changes == 0:
            return ("overwrite", "No changes detected")

        if total_changes < 5:
            return (
                "merge",
                f"{total_changes} files changed - merge recommended",
            )

        if total_changes < 20:
            return (
                "prompt",
                f"{total_changes} files changed - review recommended",
            )

        return (
            "prompt",
            f"{total_changes} files changed - extensive changes require review",
        )

    def apply_update_strategy(
        self,
        fetch_result: UpdateFetchResult,
        strategy: str = "prompt",
        interactive: bool = True,
        auto_resolve: str = "abort",
        collection_name: Optional[str] = None,
    ) -> UpdateResult:
        """Apply update using specified strategy.

        Takes the result from fetch_update() and applies it using one of three strategies:
        - overwrite: Replace local artifact completely with upstream version
        - merge: Use MergeEngine to perform 3-way merge (Phase 0 implementation)
        - prompt: Show diff summary and ask user for confirmation before applying

        Args:
            fetch_result: Result from fetch_update() containing temp workspace
            strategy: Update strategy ("overwrite", "merge", or "prompt")
            interactive: Whether to prompt user (for prompt strategy)
            auto_resolve: How to handle conflicts in non-interactive mode
                         - "abort": Cancel update on conflicts (safe default)
                         - "ours": Keep local changes when conflicts occur
                         - "theirs": Take upstream changes when conflicts occur
            collection_name: Collection name (uses active if None)

        Returns:
            UpdateResult describing outcome

        Raises:
            ValueError: Invalid strategy or fetch_result has error or invalid auto_resolve
        """
        import logging
        from rich.console import Console
        from rich.prompt import Confirm

        console = Console()

        # Validate fetch result
        if fetch_result.error:
            raise ValueError(f"Cannot apply update: {fetch_result.error}")

        if not fetch_result.has_update:
            raise ValueError("No update available to apply")

        if not fetch_result.temp_workspace or not fetch_result.temp_workspace.exists():
            raise ValueError("Temp workspace not found in fetch result")

        artifact = fetch_result.artifact
        update_info = fetch_result.update_info

        # Validate strategy
        valid_strategies = {"overwrite", "merge", "prompt"}
        if strategy not in valid_strategies:
            raise ValueError(
                f"Invalid strategy '{strategy}'. Must be one of {valid_strategies}"
            )

        # Validate auto_resolve
        valid_auto_resolve = {"abort", "ours", "theirs"}
        if auto_resolve not in valid_auto_resolve:
            raise ValueError(
                f"Invalid auto_resolve '{auto_resolve}'. Must be one of {valid_auto_resolve}"
            )

        # Handle non-interactive mode with prompt strategy
        if not interactive and strategy == "prompt":
            # Convert to appropriate strategy based on auto_resolve
            if auto_resolve == "abort":
                logging.info(
                    "Non-interactive mode with 'prompt' strategy and 'abort' resolution: "
                    "Skipping update"
                )
                return UpdateResult(
                    artifact=artifact,
                    updated=False,
                    status="skipped_non_interactive",
                    previous_version=artifact.resolved_version,
                    new_version=artifact.resolved_version,
                    previous_sha=artifact.resolved_sha,
                    new_sha=artifact.resolved_sha,
                )
            elif auto_resolve == "theirs":
                # Take upstream - use overwrite strategy
                strategy = "overwrite"
                logging.info(
                    "Non-interactive mode: Converting 'prompt' to 'overwrite' "
                    "(taking upstream)"
                )
            elif auto_resolve == "ours":
                # Keep local - skip update
                logging.info(
                    "Non-interactive mode: Keeping local changes (skipping update)"
                )
                return UpdateResult(
                    artifact=artifact,
                    updated=False,
                    status="kept_local_non_interactive",
                    previous_version=artifact.resolved_version,
                    new_version=artifact.resolved_version,
                    previous_sha=artifact.resolved_sha,
                    new_sha=artifact.resolved_sha,
                )

        # Load collection and get artifact paths
        collection = self.collection_mgr.load_collection(collection_name)
        collection_path, artifact_path = self._get_artifact_paths(collection, artifact)

        # Store previous version info for result
        previous_version = artifact.resolved_version
        previous_sha = artifact.resolved_sha

        # Get upstream artifact from temp workspace
        upstream_path = fetch_result.temp_workspace / "artifact"
        if not upstream_path.exists():
            raise ValueError(f"Artifact not found in temp workspace: {upstream_path}")

        # Create snapshot before applying update (for rollback safety)
        snapshot = None
        try:
            snapshot = self._auto_snapshot(
                collection.name,
                artifact,
                f"Before {strategy} update of {artifact.type.value}/{artifact.name}",
            )
        except Exception as snapshot_error:
            # Snapshot creation failed - log warning but continue
            # Update will proceed without rollback safety net
            logging.warning(
                f"Failed to create snapshot before update: {snapshot_error}. "
                f"Proceeding without rollback capability."
            )

        try:
            # Apply strategy
            if strategy == "overwrite":
                success = self._apply_overwrite_strategy(
                    artifact_path, upstream_path, artifact
                )
                if not success:
                    return UpdateResult(
                        artifact=artifact,
                        updated=False,
                        status="overwrite_failed",
                        previous_version=previous_version,
                        new_version=previous_version,
                        previous_sha=previous_sha,
                        new_sha=previous_sha,
                    )

            elif strategy == "merge":
                success = self._apply_merge_strategy(
                    artifact_path, upstream_path, artifact, collection_path, console
                )
                if not success:
                    return UpdateResult(
                        artifact=artifact,
                        updated=False,
                        status="merge_failed",
                        previous_version=previous_version,
                        new_version=previous_version,
                        previous_sha=previous_sha,
                        new_sha=previous_sha,
                    )

            elif strategy == "prompt":
                success = self._apply_prompt_strategy(
                    artifact_path,
                    upstream_path,
                    artifact,
                    interactive,
                    console,
                )
                if not success:
                    return UpdateResult(
                        artifact=artifact,
                        updated=False,
                        status="user_cancelled",
                        previous_version=previous_version,
                        new_version=previous_version,
                        previous_sha=previous_sha,
                        new_sha=previous_sha,
                    )

            # Update artifact metadata
            artifact.resolved_sha = (
                update_info.latest_sha if update_info else artifact.resolved_sha
            )
            artifact.resolved_version = (
                update_info.latest_version if update_info else artifact.resolved_version
            )
            artifact.last_updated = datetime.utcnow()

            # Extract metadata from updated artifact
            try:
                from skillmeat.utils.metadata import extract_artifact_metadata

                artifact.metadata = extract_artifact_metadata(
                    artifact_path, artifact.type
                )
            except Exception as e:
                logging.warning(f"Could not extract metadata: {e}")

            # Save collection (atomic write of manifest)
            self.collection_mgr.save_collection(collection)

            # Update lock file (atomic write)
            new_hash = self.compute_content_hash(artifact_path)
            self.collection_mgr.lock_mgr.update_entry(
                collection_path,
                artifact.name,
                artifact.type,
                artifact.upstream,
                artifact.resolved_sha,
                artifact.resolved_version,
                new_hash,
            )

            # Clean up temp workspace on success
            if fetch_result.temp_workspace and fetch_result.temp_workspace.exists():
                shutil.rmtree(fetch_result.temp_workspace, ignore_errors=True)

            # Track successful update event
            self._record_update_event(
                artifact=artifact,
                strategy=strategy,
                version_before=previous_version,
                version_after=artifact.resolved_version,
                conflicts_detected=0,  # Would need to track this from merge
                rollback=False,
            )

            return UpdateResult(
                artifact=artifact,
                updated=True,
                status=f"{strategy}_applied",
                previous_version=previous_version,
                new_version=artifact.resolved_version,
                previous_sha=previous_sha,
                new_sha=artifact.resolved_sha,
            )

        except Exception as e:
            # Rollback on failure - restore from snapshot if available
            if snapshot is not None:
                logging.error(
                    f"Update failed: {e}. Rolling back to snapshot {snapshot.id}..."
                )

                try:
                    # Restore collection from snapshot (includes manifest, lock, and artifact files)
                    from skillmeat.storage.snapshot import SnapshotManager

                    snapshots_dir = self.collection_mgr.config.get_snapshots_dir()
                    snapshot_mgr = SnapshotManager(snapshots_dir)
                    snapshot_mgr.restore_snapshot(snapshot, collection_path)

                    logging.info(f"Successfully rolled back to snapshot {snapshot.id}")

                    # Track rollback event
                    self._record_update_event(
                        artifact=artifact,
                        strategy=strategy,
                        version_before=previous_version,
                        version_after=previous_version,  # Rolled back
                        conflicts_detected=0,
                        rollback=True,
                    )
                except Exception as rollback_error:
                    logging.error(
                        f"CRITICAL: Rollback failed: {rollback_error}. "
                        f"Collection may be in inconsistent state. "
                        f"Manual restore from snapshot {snapshot.id} required."
                    )
                    # Re-raise original exception with rollback error context
                    raise RuntimeError(
                        f"Update failed and rollback also failed. "
                        f"Original error: {e}. Rollback error: {rollback_error}. "
                        f"Manual restore from snapshot {snapshot.id} may be required."
                    ) from e
                finally:
                    # Always clean up temp workspace, even on rollback failure
                    if (
                        fetch_result.temp_workspace
                        and fetch_result.temp_workspace.exists()
                    ):
                        try:
                            shutil.rmtree(
                                fetch_result.temp_workspace, ignore_errors=True
                            )
                        except Exception as cleanup_error:
                            logging.warning(
                                f"Failed to clean up temp workspace: {cleanup_error}"
                            )
            else:
                # No snapshot available - cannot rollback
                logging.error(
                    f"Update failed: {e}. No snapshot available for rollback. "
                    f"Collection may be in inconsistent state."
                )

                # Clean up temp workspace
                if fetch_result.temp_workspace and fetch_result.temp_workspace.exists():
                    try:
                        shutil.rmtree(fetch_result.temp_workspace, ignore_errors=True)
                    except Exception as cleanup_error:
                        logging.warning(
                            f"Failed to clean up temp workspace: {cleanup_error}"
                        )

            # Re-raise original exception after rollback attempt
            raise

    def _apply_overwrite_strategy(
        self, local_path: Path, upstream_path: Path, artifact: Artifact
    ) -> bool:
        """Apply overwrite strategy - replace local with upstream.

        Args:
            local_path: Path to local artifact
            upstream_path: Path to upstream artifact
            artifact: Artifact being updated

        Returns:
            True if successful, False otherwise
        """
        import logging

        try:
            logging.info(
                f"Applying overwrite strategy for {artifact.type.value}/{artifact.name}"
            )

            # Use FilesystemManager for atomic copy
            self.filesystem_mgr.copy_artifact(upstream_path, local_path, artifact.type)

            logging.info(
                f"Successfully overwrote {artifact.type.value}/{artifact.name}"
            )
            return True

        except Exception as e:
            logging.error(f"Overwrite failed: {e}")
            return False

    def _apply_merge_strategy(
        self,
        local_path: Path,
        upstream_path: Path,
        artifact: Artifact,
        collection_path: Path,
        console,
    ) -> bool:
        """Apply merge strategy - use MergeEngine for 3-way merge.

        For Phase 0, uses simple 3-way merge logic:
        - Base: Current artifact in collection
        - Local: Current artifact in collection (same as base for now)
        - Remote: Upstream artifact from temp workspace

        Phase 1 will enhance this with proper base version tracking.

        Args:
            local_path: Path to local artifact
            upstream_path: Path to upstream artifact
            artifact: Artifact being updated
            collection_path: Path to collection root
            console: Rich console for output

        Returns:
            True if successful, False otherwise
        """
        import logging
        import tempfile
        from skillmeat.core.merge_engine import MergeEngine

        try:
            logging.info(
                f"Applying merge strategy for {artifact.type.value}/{artifact.name}"
            )

            # For Phase 0: base == local (no separate base version tracking yet)
            # This will be enhanced in Phase 1 with proper base version from snapshots
            console.print(
                f"[yellow]Note: Phase 0 merge uses current version as base. "
                f"Full 3-way merge with tracked base version coming in Phase 1.[/yellow]"
            )

            # Create merge engine
            merge_engine = MergeEngine()

            # Create temp directory for merge output
            with tempfile.TemporaryDirectory() as temp_dir:
                merge_output = Path(temp_dir) / "merged"

                # Perform 3-way merge
                # Base and local are the same (current artifact)
                merge_result = merge_engine.merge(
                    base_path=local_path,
                    local_path=local_path,
                    remote_path=upstream_path,
                    output_path=merge_output,
                )

                if merge_result.has_conflicts:
                    console.print(
                        f"[yellow]Merge resulted in {len(merge_result.conflicts)} conflicts.[/yellow]"
                    )
                    console.print(
                        f"[yellow]Conflict files will be preserved with markers.[/yellow]"
                    )

                # Log merge statistics
                console.print(f"[green]{merge_result.summary()}[/green]")

                # Copy merged result to local path
                self.filesystem_mgr.copy_artifact(
                    merge_output, local_path, artifact.type
                )

                logging.info(
                    f"Successfully merged {artifact.type.value}/{artifact.name}"
                )
                return True

        except Exception as e:
            logging.error(f"Merge failed: {e}")
            console.print(f"[red]Merge failed: {e}[/red]")
            return False

    def _apply_prompt_strategy(
        self,
        local_path: Path,
        upstream_path: Path,
        artifact: Artifact,
        interactive: bool,
        console,
    ) -> bool:
        """Apply prompt strategy - show diff and ask user for confirmation.

        Args:
            local_path: Path to local artifact
            upstream_path: Path to upstream artifact
            artifact: Artifact being updated
            interactive: Whether to prompt user
            console: Rich console for output

        Returns:
            True if user confirmed and update applied, False otherwise
        """
        import logging
        from skillmeat.core.diff_engine import DiffEngine
        from rich.prompt import Confirm

        try:
            logging.info(
                f"Applying prompt strategy for {artifact.type.value}/{artifact.name}"
            )

            # Show enhanced preview with conflict detection
            artifact_ref = f"{artifact.type.value}/{artifact.name}"
            preview_data = self._show_update_preview(
                artifact_ref=artifact_ref,
                current_path=local_path,
                update_path=upstream_path,
                strategy="prompt",
                console=console,
            )

            # Get strategy recommendation
            # Note: For prompt strategy, we don't have local modifications info here
            # so we use the diff result only
            recommended_strategy, reason = self._recommend_strategy(
                diff_result=preview_data["diff_result"],
                has_local_modifications=False,  # Assume no local mods for prompt
            )

            # Show recommendation
            if recommended_strategy != "prompt":
                console.print(
                    f"\n[bold]Recommendation:[/bold] [cyan]{recommended_strategy}[/cyan]"
                )
                console.print(f"  Reason: {reason}")

            # Prompt user if interactive
            if interactive:
                console.print()
                if not Confirm.ask(
                    f"Apply this update to {artifact.type.value}/{artifact.name}?",
                    default=False,
                ):
                    console.print("[yellow]Update cancelled by user.[/yellow]")
                    return False
            else:
                console.print("[yellow]Non-interactive mode: skipping update.[/yellow]")
                return False

            # User confirmed - apply overwrite
            console.print(f"[green]Applying update...[/green]")
            return self._apply_overwrite_strategy(local_path, upstream_path, artifact)

        except Exception as e:
            logging.error(f"Prompt strategy failed: {e}")
            console.print(f"[red]Error: {e}[/red]")
            return False

    def update(
        self,
        artifact_name: str,
        artifact_type: Optional[ArtifactType] = None,
        collection_name: Optional[str] = None,
        strategy: UpdateStrategy = UpdateStrategy.PROMPT,
    ) -> UpdateResult:
        """Update artifact from upstream or refresh local artifacts.

        Args:
            artifact_name: Artifact name
            artifact_type: Artifact type (required if ambiguous)
            collection_name: Collection name (uses active if None)
            strategy: Update strategy (PROMPT, TAKE_UPSTREAM, KEEP_LOCAL)

        Returns:
            UpdateResult describing outcome

        Raises:
            ValueError: Artifact not found or unsupported origin
        """
        collection = self.collection_mgr.load_collection(collection_name)
        artifact = collection.find_artifact(artifact_name, artifact_type)

        if not artifact:
            raise ValueError(f"Artifact '{artifact_name}' not found")

        is_github_backed = artifact.origin == "github" or (
            artifact.origin == "marketplace" and artifact.origin_source == "github"
        )
        if is_github_backed:
            return self._update_github_artifact(collection, artifact, strategy)
        if artifact.origin == "local":
            return self._refresh_local_artifact(collection, artifact)

        raise ValueError(f"Unsupported artifact origin: {artifact.origin}")

    def _update_github_artifact(
        self, collection, artifact: Artifact, strategy: UpdateStrategy
    ) -> UpdateResult:
        """Update GitHub-backed artifact."""
        if not artifact.upstream:
            return UpdateResult(
                artifact=artifact,
                updated=False,
                status="no_upstream",
                previous_version=artifact.resolved_version,
                new_version=artifact.resolved_version,
                previous_sha=artifact.resolved_sha,
                new_sha=artifact.resolved_sha,
            )

        collection_path, artifact_path = self._get_artifact_paths(collection, artifact)
        has_local_modifications = self._detect_local_modifications(
            collection_path, artifact, artifact_path
        )

        update_info = self.github_source.check_updates(artifact)
        if not update_info or not update_info.has_update:
            return UpdateResult(
                artifact=artifact,
                updated=False,
                status="up_to_date",
                previous_version=artifact.resolved_version,
                new_version=artifact.resolved_version,
                previous_sha=artifact.resolved_sha,
                new_sha=artifact.resolved_sha,
                local_modifications=has_local_modifications,
            )

        if has_local_modifications:
            if strategy == UpdateStrategy.KEEP_LOCAL:
                return UpdateResult(
                    artifact=artifact,
                    updated=False,
                    status="local_changes_kept",
                    previous_version=artifact.resolved_version,
                    new_version=artifact.resolved_version,
                    previous_sha=artifact.resolved_sha,
                    new_sha=artifact.resolved_sha,
                    local_modifications=True,
                )
            if strategy == UpdateStrategy.PROMPT:
                prompt = (
                    f"Local modifications detected for "
                    f"{artifact.type.value}/{artifact.name}. "
                    "Overwrite with upstream changes?"
                )
                if not Confirm.ask(prompt, default=False):
                    return UpdateResult(
                        artifact=artifact,
                        updated=False,
                        status="cancelled",
                        previous_version=artifact.resolved_version,
                        new_version=artifact.resolved_version,
                        previous_sha=artifact.resolved_sha,
                        new_sha=artifact.resolved_sha,
                        local_modifications=True,
                    )

        previous_version = artifact.resolved_version
        previous_sha = artifact.resolved_sha

        override_version = update_info.latest_sha or artifact.version_spec
        spec = self._build_spec_from_artifact(
            artifact, version_override=override_version
        )

        self._auto_snapshot(
            collection.name,
            artifact,
            f"Before updating {artifact.type.value}/{artifact.name}",
        )

        fetch_result = self.github_source.fetch(spec, artifact.type)

        self.filesystem_mgr.copy_artifact(
            fetch_result.artifact_path, artifact_path, artifact.type
        )

        artifact.metadata = fetch_result.metadata
        artifact.upstream = fetch_result.upstream_url or artifact.upstream
        artifact.resolved_sha = fetch_result.resolved_sha or update_info.latest_sha
        artifact.resolved_version = (
            fetch_result.resolved_version
            if fetch_result.resolved_version is not None
            else update_info.latest_version or artifact.resolved_version
        )
        artifact.last_updated = datetime.utcnow()

        self.collection_mgr.save_collection(collection)

        new_hash = self.compute_content_hash(artifact_path)
        self.collection_mgr.lock_mgr.update_entry(
            collection_path,
            artifact.name,
            artifact.type,
            artifact.upstream,
            artifact.resolved_sha,
            artifact.resolved_version,
            new_hash,
        )

        return UpdateResult(
            artifact=artifact,
            updated=True,
            status="updated_github",
            previous_version=previous_version,
            new_version=artifact.resolved_version,
            previous_sha=previous_sha,
            new_sha=artifact.resolved_sha,
            local_modifications=has_local_modifications,
        )

    def _refresh_local_artifact(self, collection, artifact: Artifact) -> UpdateResult:
        """Refresh metadata/hash for local artifacts."""
        collection_path, artifact_path = self._get_artifact_paths(collection, artifact)

        try:
            from skillmeat.utils.metadata import extract_artifact_metadata

            metadata = extract_artifact_metadata(artifact_path, artifact.type)
        except Exception:
            metadata = artifact.metadata

        previous_version = artifact.metadata.version

        self._auto_snapshot(
            collection.name,
            artifact,
            f"Before refreshing {artifact.type.value}/{artifact.name}",
        )

        artifact.metadata = metadata
        artifact.last_updated = datetime.utcnow()

        self.collection_mgr.save_collection(collection)

        new_hash = self.compute_content_hash(artifact_path)
        self.collection_mgr.lock_mgr.update_entry(
            collection_path,
            artifact.name,
            artifact.type,
            None,
            None,
            None,
            new_hash,
        )

        return UpdateResult(
            artifact=artifact,
            updated=True,
            status="refreshed_local",
            previous_version=previous_version,
            new_version=metadata.version,
        )

    def _get_artifact_paths(self, collection, artifact: Artifact) -> tuple[Path, Path]:
        """Return collection and artifact paths (validate existence)."""
        collection_path = self.collection_mgr.config.get_collection_path(
            collection.name
        )
        artifact_path = collection_path / artifact.path

        if not artifact_path.exists():
            raise ValueError(
                f"Artifact files missing for {artifact.type.value}/{artifact.name}"
            )

        return collection_path, artifact_path

    def _detect_local_modifications(
        self, collection_path: Path, artifact: Artifact, artifact_path: Path
    ) -> bool:
        """Check if artifact has diverged from lock entry."""
        lock_entry = self.collection_mgr.lock_mgr.get_entry(
            collection_path, artifact.name, artifact.type
        )

        if not lock_entry:
            return False

        try:
            current_hash = self.compute_content_hash(artifact_path)
        except FileNotFoundError:
            return False

        return current_hash != lock_entry.content_hash

    def _build_spec_from_artifact(
        self, artifact: Artifact, version_override: Optional[str] = None
    ) -> str:
        """Reconstruct GitHub spec from stored upstream URL."""
        if not artifact.upstream:
            raise ValueError(
                f"Artifact '{artifact.name}' does not have an upstream reference"
            )

        parsed = urlparse(artifact.upstream)
        parts = parsed.path.strip("/").split("/")

        if len(parts) < 3 or parts[2] != "tree":
            raise ValueError(f"Unsupported upstream URL format: {artifact.upstream}")

        username, repo = parts[0], parts[1]
        path_parts = parts[4:] if len(parts) > 4 else []
        rel_path = "/".join(path_parts) if path_parts else ""
        version_spec = version_override or artifact.version_spec or "latest"

        if rel_path:
            return f"{username}/{repo}/{rel_path}@{version_spec}"
        return f"{username}/{repo}@{version_spec}"

    def _record_update_event(
        self,
        artifact: Artifact,
        strategy: str,
        version_before: Optional[str] = None,
        version_after: Optional[str] = None,
        conflicts_detected: int = 0,
        rollback: bool = False,
        user_choice: Optional[str] = None,
    ) -> None:
        """Record update event for analytics.

        Args:
            artifact: Artifact being updated
            strategy: Update strategy (overwrite, merge, prompt)
            version_before: Optional version before update
            version_after: Optional version after update
            conflicts_detected: Number of conflicts detected
            rollback: Whether update was rolled back
            user_choice: Optional user choice (proceed, cancel)
        """
        try:
            from skillmeat.core.analytics import EventTracker

            # Get collection name
            collection_name = "default"
            try:
                collection = self.collection_mgr.get_active_collection()
                collection_name = collection.name if collection else "default"
            except Exception:
                pass

            # Record update event
            with EventTracker() as tracker:
                tracker.track_update(
                    artifact_name=artifact.name,
                    artifact_type=artifact.type.value,
                    collection_name=collection_name,
                    strategy=strategy,
                    version_before=version_before,
                    version_after=version_after,
                    conflicts_detected=conflicts_detected,
                    user_choice=user_choice,
                    rollback=rollback,
                )

        except Exception as e:
            # Never fail update due to analytics
            logging.debug(f"Failed to record update analytics: {e}")

    def _record_remove_event(
        self,
        artifact_name: str,
        artifact_type: str,
        collection_name: str,
        reason: str = "user_action",
        from_project: bool = False,
    ) -> None:
        """Record remove event for analytics.

        Args:
            artifact_name: Name of artifact being removed
            artifact_type: Type of artifact
            collection_name: Name of collection
            reason: Reason for removal (default: user_action)
            from_project: Whether removing from project (default: False)
        """
        try:
            from skillmeat.core.analytics import EventTracker

            # Record remove event
            with EventTracker() as tracker:
                tracker.track_remove(
                    artifact_name=artifact_name,
                    artifact_type=artifact_type,
                    collection_name=collection_name,
                    reason=reason,
                    from_project=from_project,
                )

        except Exception as e:
            # Never fail remove due to analytics
            logging.debug(f"Failed to record remove analytics: {e}")

    def _auto_snapshot(self, collection_name: str, artifact: Artifact, message: str):
        """Create safety snapshot before mutating artifact.

        Returns:
            Snapshot object if successful, None if snapshot creation failed
        """
        from skillmeat.core.version import VersionManager

        try:
            version_mgr = VersionManager(self.collection_mgr)
            snapshot = version_mgr.auto_snapshot(collection_name, message)
            return snapshot
        except Exception as e:
            # Snapshot best-effort; don't block updates if snapshot fails
            # But log warning so user knows rollback may not be available
            logging.warning(
                f"Failed to create snapshot before updating {artifact.name}: {e}. "
                "Rollback may not be available if update fails."
            )
            return None

    def _apply_auto_linking(
        self,
        metadata: ArtifactMetadata,
        artifact_type: ArtifactType,
        artifact_name: str,
        collection_name: Optional[str] = None,
        source_name: Optional[str] = None,
    ) -> None:
        """Apply auto-linking to artifact metadata based on frontmatter references.

        Resolves artifact references (skills, agents, related) from frontmatter
        and populates the metadata's linked_artifacts and unlinked_references fields.

        This operation is non-blocking - failures are logged but do not prevent import.

        Args:
            metadata: ArtifactMetadata to enrich with linking information
            artifact_type: Type of the artifact being imported
            artifact_name: Name of the artifact (for logging)
            collection_name: Collection to search for linkable artifacts (uses active if None)
            source_name: Source identifier for the linked references (e.g., GitHub repo)

        Note:
            - Auto-linking failures do NOT prevent artifact import
            - Linked artifacts are stored in metadata.linked_artifacts
            - Unlinked references are stored in metadata.unlinked_references
            - Performance target: < 100ms per artifact
        """
        import logging
        import time

        start_time = time.perf_counter()

        try:
            # Check if metadata has frontmatter to process
            if not metadata.extra or "frontmatter" not in metadata.extra:
                logging.debug(
                    f"No frontmatter for {artifact_name}, skipping auto-linking"
                )
                return

            frontmatter = metadata.extra["frontmatter"]
            if not frontmatter:
                return

            # Import linking utilities (deferred to avoid circular imports)
            from skillmeat.utils.metadata import resolve_artifact_references

            # Get available artifacts from collection for matching
            try:
                collection = self.collection_mgr.load_collection(collection_name)
                available_artifacts = collection.artifacts
            except Exception as e:
                logging.debug(f"Could not load collection for linking: {e}")
                available_artifacts = []

            # Resolve references
            linked, unlinked = resolve_artifact_references(
                frontmatter=frontmatter,
                artifact_type=artifact_type,
                available_artifacts=available_artifacts,
                source_name=source_name,
            )

            # Store results in metadata
            if linked:
                metadata.linked_artifacts = linked
                logging.info(
                    f"Auto-linked {len(linked)} artifacts for {artifact_name}: "
                    f"{[la.artifact_name for la in linked]}"
                )

            if unlinked:
                metadata.unlinked_references = unlinked
                logging.debug(f"Unlinked references for {artifact_name}: {unlinked}")

        except Exception as e:
            # Non-blocking: log warning and continue without linking
            logging.warning(f"Auto-linking failed for {artifact_name}: {e}")

        finally:
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            if elapsed_ms > 100:
                logging.warning(
                    f"Auto-linking for {artifact_name} took {elapsed_ms:.1f}ms "
                    "(exceeds 100ms target)"
                )

    def _lookup_collection_artifact_uuid(
        self,
        artifact_name: str,
        artifact_type: str,
    ) -> Optional[str]:
        """Look up a stable UUID for an artifact from the DB cache.

        Searches for any cached deployment with the given name and type across all
        projects.  Returns the first match found, or None when the artifact has never
        been deployed (and therefore has no cache entry yet).

        This is a best-effort, non-blocking helper.  It never raises — failures
        silently return None so callers can always omit the UUID field gracefully.

        Args:
            artifact_name: Artifact name
            artifact_type: Artifact type string (e.g. "skill")

        Returns:
            32-char hex UUID string from CachedArtifact.uuid, or None if not found
        """
        try:
            from skillmeat.cache.models import Artifact as CacheArtifact
            from skillmeat.cache.models import get_session

            session = get_session()
            try:
                cache_artifact = (
                    session.query(CacheArtifact)
                    .filter_by(name=artifact_name, type=artifact_type)
                    .first()
                )
                if cache_artifact is not None:
                    return cache_artifact.uuid
            finally:
                session.close()
        except Exception as exc:
            logging.debug(
                "UUID lookup for collection artifact %s/%s failed: %s",
                artifact_type,
                artifact_name,
                exc,
            )
        return None
