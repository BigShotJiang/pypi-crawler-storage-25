"""Ghost version detector for artifact VCS v2 (artifact-vcs-v2).

A *ghost* version is an ``ArtifactVersion`` row with ``is_ghost=True`` that
represents upstream GitHub changes not yet pulled into the local collection.
``GhostVersionDetector`` compares the latest ``ArtifactVersion.content_hash``
for an artifact against the HEAD SHA on GitHub.  When they differ it inserts
(or upserts) a ghost row so that the topology layer can surface the divergence
to the user.

Design contract
---------------
* ``detect`` is non-fatal.  Any ``GitHubClientError`` is caught, logged at
  DEBUG level, and ``False`` is returned.  The caller is never blocked.
* Ghost rows carry ``is_ghost=True`` and ``change_origin='github_update'``.
* When the upstream SHA already matches an existing ``ArtifactVersion`` row the
  method returns ``False`` (no new ghost needed).
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

from skillmeat.cache.models import Artifact, ArtifactVersion
from skillmeat.core.github_client import GitHubClientError, get_github_client

logger = logging.getLogger(__name__)


class GhostVersionDetector:
    """Detects upstream GitHub changes not yet reflected in the collection.

    Instantiate with an active SQLAlchemy ``Session``.  Call :meth:`detect`
    per-artifact; it writes ghost ``ArtifactVersion`` rows as a side-effect.

    Args:
        session: Live SQLAlchemy session for ORM reads and writes.
    """

    def __init__(self, session: Session) -> None:
        self._session = session

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    async def detect(self, artifact_id: str) -> bool:
        """Check whether upstream GitHub has changes not yet pulled.

        Steps:

        1. Load the ``Artifact`` row to obtain its ``source`` field.
        2. Parse the GitHub ``owner/repo`` and optional path from ``source``.
        3. Fetch the upstream HEAD SHA via :func:`~skillmeat.core.github_client.get_github_client`.
        4. Compare with the latest ``ArtifactVersion.content_hash`` for this artifact.
        5. If they differ, insert/upsert a ghost ``ArtifactVersion`` row with
           ``is_ghost=True`` and ``change_origin='github_update'``.
        6. Return ``True`` when a ghost version exists (new or pre-existing).

        Non-fatal: any :class:`~skillmeat.core.github_client.GitHubClientError`
        is caught and ``False`` is returned.

        Args:
            artifact_id: ``artifacts.id`` value (``type:name`` format).

        Returns:
            ``True`` when a ghost version exists after the call; ``False`` when
            no upstream divergence was detected or when any error occurred.
        """
        try:
            return await self._detect_internal(artifact_id)
        except GitHubClientError as exc:
            logger.debug(
                "GhostVersionDetector: GitHub error for artifact_id=%r — skipping. %s",
                artifact_id,
                exc,
            )
            return False
        except Exception:
            logger.debug(
                "GhostVersionDetector: unexpected error for artifact_id=%r — skipping.",
                artifact_id,
                exc_info=True,
            )
            return False

    # -------------------------------------------------------------------------
    # Private helpers
    # -------------------------------------------------------------------------

    async def _detect_internal(self, artifact_id: str) -> bool:
        """Core detection logic (may raise; :meth:`detect` wraps it)."""
        # ------------------------------------------------------------------
        # Step 1: Load Artifact row
        # ------------------------------------------------------------------
        artifact_row: Optional[Artifact] = (
            self._session.query(Artifact).filter(Artifact.id == artifact_id).first()
        )
        if artifact_row is None or not artifact_row.source:
            logger.debug(
                "GhostVersionDetector: artifact_id=%r has no source — skipping.",
                artifact_id,
            )
            return False

        # ------------------------------------------------------------------
        # Step 2: Parse owner/repo and optional file path from source
        # ------------------------------------------------------------------
        owner_repo, file_path = self._parse_source(artifact_row.source)
        if owner_repo is None:
            logger.debug(
                "GhostVersionDetector: artifact_id=%r source=%r is not a GitHub source — skipping.",
                artifact_id,
                artifact_row.source,
            )
            return False

        # ------------------------------------------------------------------
        # Step 3: Fetch upstream SHA
        # ------------------------------------------------------------------
        client = get_github_client()
        upstream_sha = self._fetch_upstream_sha(client, owner_repo, file_path)
        if upstream_sha is None:
            return False

        # ------------------------------------------------------------------
        # Step 4: Compare with latest ArtifactVersion content_hash
        # ------------------------------------------------------------------
        latest_version: Optional[ArtifactVersion] = (
            self._session.query(ArtifactVersion)
            .filter(ArtifactVersion.artifact_id == artifact_id)
            .order_by(ArtifactVersion.created_at.desc())
            .first()
        )

        if latest_version is not None and latest_version.content_hash == upstream_sha:
            # Already up-to-date; check for existing ghost rows.
            return self._has_ghost(artifact_id)

        # ------------------------------------------------------------------
        # Step 5: Check if a ghost row for this SHA already exists
        # ------------------------------------------------------------------
        existing_ghost: Optional[ArtifactVersion] = (
            self._session.query(ArtifactVersion)
            .filter(
                ArtifactVersion.artifact_id == artifact_id,
                ArtifactVersion.content_hash == upstream_sha,
                ArtifactVersion.is_ghost.is_(True),
            )
            .first()
        )
        if existing_ghost is not None:
            return True

        # ------------------------------------------------------------------
        # Step 6: Insert new ghost row
        # ------------------------------------------------------------------
        ghost_row = ArtifactVersion(
            id=uuid.uuid4().hex,
            artifact_id=artifact_id,
            content_hash=upstream_sha,
            change_origin="github_update",
            is_ghost=True,
            parent_hash=latest_version.content_hash if latest_version else None,
            created_at=datetime.utcnow(),
        )
        self._session.add(ghost_row)
        self._session.flush()

        logger.info(
            "GhostVersionDetector: inserted ghost version for artifact_id=%r upstream_sha=%s",
            artifact_id,
            upstream_sha[:8],
        )
        return True

    def _parse_source(self, source: str):
        """Parse a GitHub source string into (owner_repo, file_path).

        Supported formats:
        * ``owner/repo/path/to/artifact`` — ``owner/repo`` + path
        * ``owner/repo`` — ``owner/repo`` with no path
        * ``github:owner/repo/path`` — strip leading ``github:`` prefix

        Returns:
            Tuple of ``(owner_repo, file_path)`` where ``file_path`` may be
            ``None`` when no sub-path is present.  Returns ``(None, None)``
            when the source cannot be parsed as a GitHub reference.
        """
        if not source:
            return None, None

        # Strip optional scheme prefix (e.g. "github:owner/repo/...")
        raw = source
        if raw.startswith("github:"):
            raw = raw[len("github:") :]

        # Source format uses @ for version — strip version specifier
        if "@" in raw:
            raw = raw.split("@")[0]

        parts = raw.split("/")
        if len(parts) < 2:
            return None, None

        owner_repo = "/".join(parts[:2])
        file_path = "/".join(parts[2:]) if len(parts) > 2 else None
        return owner_repo, file_path

    def _fetch_upstream_sha(
        self, client, owner_repo: str, file_path: Optional[str]
    ) -> Optional[str]:
        """Fetch the upstream SHA for the artifact.

        Uses :meth:`~skillmeat.core.github_client.GitHubClient.resolve_version`
        to obtain the latest commit SHA for the repository HEAD, which is a
        stable proxy for detecting upstream changes.

        Args:
            client: Authenticated :class:`~skillmeat.core.github_client.GitHubClient`.
            owner_repo: ``owner/repo`` string.
            file_path: Optional sub-path within the repository.  Currently
                unused — repo-level HEAD SHA is used for change detection.

        Returns:
            Upstream SHA string, or ``None`` on any GitHub error.
        """
        try:
            sha = client.resolve_version(owner_repo, "latest")
            return sha
        except GitHubClientError as exc:
            logger.debug(
                "GhostVersionDetector._fetch_upstream_sha: %s/%s — %s",
                owner_repo,
                file_path or "",
                exc,
            )
            raise

    def _has_ghost(self, artifact_id: str) -> bool:
        """Return True when at least one ghost row exists for *artifact_id*."""
        row: Optional[ArtifactVersion] = (
            self._session.query(ArtifactVersion)
            .filter(
                ArtifactVersion.artifact_id == artifact_id,
                ArtifactVersion.is_ghost.is_(True),
            )
            .first()
        )
        return row is not None
