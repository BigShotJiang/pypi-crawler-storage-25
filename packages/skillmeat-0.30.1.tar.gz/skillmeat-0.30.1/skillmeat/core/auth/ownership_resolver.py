"""OwnershipResolver: request-scoped service for resolving ownership context.

Transforms an ``AuthContext`` + team membership data into a
``ResolvedOwnershipContext`` that carries all data needed for ownership-aware
read/write filtering without additional I/O.

Also exposes helpers for determining the create-target scope and validating
write permission, implementing the five design rules from the enterprise
governance spec (EG-2).

References:
    skillmeat/core/auth/membership_repository.py  — IMembershipRepository
    skillmeat/core/auth/ownership_context.py      — ResolvedOwnershipContext
    skillmeat/api/schemas/auth.py                 — AuthContext
    .claude/progress/enterprise-governance-3-tier/ — EG-2 spec
"""

from __future__ import annotations

from typing import Optional, Sequence, Tuple

from skillmeat.api.schemas.auth import AuthContext
from skillmeat.core.auth.membership_repository import IMembershipRepository
from skillmeat.core.auth.ownership_context import (
    ResolvedOwnerScope,
    ResolvedOwnershipContext,
    ResolvedTeamMembership,
)

__all__ = ["OwnershipResolver"]

# Role string checked against AuthContext.roles
_SYSTEM_ADMIN_ROLE = "system_admin"


class OwnershipResolver:
    """Resolves the full ownership context for an authenticated actor.

    Constructed once per application (or per edition boundary) and called
    once per request.  All I/O happens inside :meth:`resolve`; the returned
    :class:`ResolvedOwnershipContext` is immutable and can be passed freely
    through the request stack.

    Parameters
    ----------
    membership_repo:
        Implementation of :class:`IMembershipRepository` appropriate for
        the current edition (``LocalMembershipRepository`` or
        ``EnterpriseMembershipRepository``).
    edition:
        Deployment edition string — ``"local"`` or ``"enterprise"``.
        Controls which owner types are offered by default and how
        enterprise scope eligibility is determined.
    """

    def __init__(
        self,
        membership_repo: IMembershipRepository,
        edition: str,
    ) -> None:
        self._repo = membership_repo
        self._edition = edition

    # ------------------------------------------------------------------
    # Primary resolution
    # ------------------------------------------------------------------

    def resolve(self, auth_ctx: AuthContext) -> ResolvedOwnershipContext:
        """Build the full ownership context for *auth_ctx*.

        Performs one membership lookup, then constructs the immutable
        :class:`ResolvedOwnershipContext` from the results.

        Parameters
        ----------
        auth_ctx:
            The authenticated request context for the current caller.

        Returns
        -------
        ResolvedOwnershipContext
            Fully populated ownership context, ready for read/write
            filtering and create-target resolution.
        """
        user_id_str = str(auth_ctx.user_id)
        tenant_id_str: Optional[str] = (
            str(auth_ctx.tenant_id) if auth_ctx.tenant_id is not None else None
        )

        # 1. Resolve team memberships.
        raw_memberships = self._repo.list_user_team_memberships(
            user_id=user_id_str,
            tenant_id=tenant_id_str,
        )

        # Normalise roles: membership_repository uses "team_admin"/"team_member";
        # ownership_context expects "admin"/"member".
        team_memberships: Tuple[ResolvedTeamMembership, ...] = tuple(
            ResolvedTeamMembership(
                team_id=m.team_id,
                role="admin" if m.role == "team_admin" else "member",
            )
            for m in raw_memberships
        )

        # 2. Determine system-admin status from roles list.
        is_system_admin = _SYSTEM_ADMIN_ROLE in auth_ctx.roles

        # 3. Build allowed_owner_types based on edition + membership + admin.
        allowed_owner_types = self._build_allowed_owner_types(
            is_system_admin=is_system_admin,
            has_teams=len(team_memberships) > 0,
        )

        # 4. Build visible_owner_scopes (union of user + team + enterprise).
        visible_owner_scopes = self._build_visible_owner_scopes(
            user_id_str=user_id_str,
            tenant_id_str=tenant_id_str,
            team_memberships=team_memberships,
            is_system_admin=is_system_admin,
        )

        return ResolvedOwnershipContext(
            actor_user_id=user_id_str,
            tenant_id=tenant_id_str,
            is_system_admin=is_system_admin,
            team_memberships=team_memberships,
            allowed_owner_types=allowed_owner_types,
            default_owner_type="user",
            default_owner_id=user_id_str,
            visible_owner_scopes=visible_owner_scopes,
        )

    # ------------------------------------------------------------------
    # Create-target resolution (Rules 1–3)
    # ------------------------------------------------------------------

    def resolve_create_target(
        self,
        ownership_ctx: ResolvedOwnershipContext,
        requested_owner_type: Optional[str] = None,
        requested_owner_id: Optional[str] = None,
    ) -> ResolvedOwnerScope:
        """Determine the ownership scope for a new resource being created.

        Implements Rules 1–3 from the enterprise governance ownership spec.

        Rule 1 — Default owner is the requesting user
            When *requested_owner_type* is ``None`` the create target is the
            caller's own user scope, regardless of team memberships or admin
            status.

        Rule 2 — Team creates require verified membership
            When *requested_owner_type* is ``"team"`` the caller must belong
            to the target team.  If no *requested_owner_id* is supplied the
            team is auto-inferred only when the caller belongs to exactly one
            team.

        Rule 3 — Enterprise creates require system_admin
            When *requested_owner_type* is ``"enterprise"`` the caller must
            hold the ``system_admin`` role and a ``tenant_id`` must be present
            in the context.

        Parameters
        ----------
        ownership_ctx:
            The resolved context for the current actor (output of
            :meth:`resolve`).
        requested_owner_type:
            Caller-supplied owner type discriminator, or ``None`` to accept
            the default (``"user"``).
        requested_owner_id:
            Caller-supplied owner identifier.  Interpretation depends on
            *requested_owner_type* — a team UUID/int, or omitted for user/
            single-team inference.

        Returns
        -------
        ResolvedOwnerScope
            The scope to use as the ``owner_type`` / ``owner_id`` on the new
            resource.

        Raises
        ------
        ValueError
            For invalid team selections (no membership, 0 teams, ambiguous
            selection) or missing tenant_id on enterprise creates.
        PermissionError
            When *requested_owner_type* is ``"enterprise"`` and the caller is
            not a system admin.
        """
        # Rule 1: default → user-owned.
        if requested_owner_type is None:
            return ResolvedOwnerScope("user", ownership_ctx.actor_user_id)

        if requested_owner_type == "user":
            # Explicit user selection — always the actor's own scope.
            return ResolvedOwnerScope("user", ownership_ctx.actor_user_id)

        # Rule 2: team-owned create.
        if requested_owner_type == "team":
            return self._resolve_team_create_target(
                ownership_ctx=ownership_ctx,
                requested_owner_id=requested_owner_id,
            )

        # Rule 3: enterprise-owned create.
        if requested_owner_type == "enterprise":
            return self._resolve_enterprise_create_target(
                ownership_ctx=ownership_ctx,
            )

        raise ValueError(
            f"Unknown owner type: {requested_owner_type!r}. "
            "Expected one of: 'user', 'team', 'enterprise'."
        )

    # ------------------------------------------------------------------
    # Write permission validation
    # ------------------------------------------------------------------

    def validate_write_permission(
        self,
        ownership_ctx: ResolvedOwnershipContext,
        target_owner_type: str,
        target_owner_id: str,
    ) -> bool:
        """Return ``True`` if the actor may write to the given owner scope.

        Permission rules:
        - ``"user"`` scope: the actor can write only to their own user scope,
          unless they are a system admin.
        - ``"team"`` scope: the actor must hold the ``"admin"`` role in that
          team, or be a system admin.
        - ``"enterprise"`` scope: requires ``is_system_admin``.

        Parameters
        ----------
        ownership_ctx:
            The resolved context for the current actor.
        target_owner_type:
            One of ``"user"``, ``"team"``, or ``"enterprise"``.
        target_owner_id:
            The identifier of the target owning principal.

        Returns
        -------
        bool
            ``True`` when the actor is permitted to write; ``False`` otherwise.
        """
        if ownership_ctx.is_system_admin:
            return True

        if target_owner_type == "user":
            return target_owner_id == ownership_ctx.actor_user_id

        if target_owner_type == "team":
            return ownership_ctx.is_admin_of(target_owner_id)

        if target_owner_type == "enterprise":
            # Already handled by is_system_admin check above.
            return False

        # Unknown owner type — deny by default.
        return False

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _build_allowed_owner_types(
        self,
        is_system_admin: bool,
        has_teams: bool,
    ) -> Tuple[str, ...]:
        """Compute the ``allowed_owner_types`` tuple.

        Parameters
        ----------
        is_system_admin:
            Whether the actor holds ``system_admin``.
        has_teams:
            Whether the actor has at least one team membership.

        Returns
        -------
        tuple[str, ...]
            Ordered from least to most privileged.
        """
        types: list[str] = ["user"]

        if self._edition == "local":
            # Local: "team" added only when teams exist; "enterprise" only for admins.
            if has_teams:
                types.append("team")
            if is_system_admin:
                types.append("enterprise")
        else:
            # Enterprise: team always available (may be empty list); enterprise for admins.
            types.append("team")
            if is_system_admin:
                types.append("enterprise")

        return tuple(types)

    def _build_visible_owner_scopes(
        self,
        user_id_str: str,
        tenant_id_str: Optional[str],
        team_memberships: Sequence[ResolvedTeamMembership],
        is_system_admin: bool,
    ) -> Tuple[ResolvedOwnerScope, ...]:
        """Compute the union of all owner scopes visible to the actor.

        Parameters
        ----------
        user_id_str:
            String form of the actor's user ID.
        tenant_id_str:
            String form of the tenant ID, or ``None``.
        team_memberships:
            Resolved team memberships for the actor.
        is_system_admin:
            Whether the actor holds ``system_admin``.

        Returns
        -------
        tuple[ResolvedOwnerScope, ...]
        """
        scopes: list[ResolvedOwnerScope] = []

        # Own user scope — always visible.
        scopes.append(ResolvedOwnerScope("user", user_id_str))

        # Team scopes — one per membership.
        for membership in team_memberships:
            scopes.append(ResolvedOwnerScope("team", membership.team_id))

        # Enterprise scope — visible when system_admin and tenant_id is known.
        if is_system_admin and tenant_id_str is not None:
            scopes.append(ResolvedOwnerScope("enterprise", tenant_id_str))

        return tuple(scopes)

    def _resolve_team_create_target(
        self,
        ownership_ctx: ResolvedOwnershipContext,
        requested_owner_id: Optional[str],
    ) -> ResolvedOwnerScope:
        """Resolve a team-owned create target (Rule 2 implementation).

        Parameters
        ----------
        ownership_ctx:
            The resolved context for the current actor.
        requested_owner_id:
            Explicit team identifier supplied by the caller, or ``None``
            to trigger auto-inference.

        Returns
        -------
        ResolvedOwnerScope

        Raises
        ------
        ValueError
            On membership failure, no teams, or ambiguous selection.
        """
        team_memberships = ownership_ctx.team_memberships

        if requested_owner_id is not None:
            # Explicit team — verify membership.
            if not ownership_ctx.is_member_of(requested_owner_id):
                raise ValueError(
                    f"User is not a member of team '{requested_owner_id}'."
                )
            return ResolvedOwnerScope("team", requested_owner_id)

        # Auto-infer from memberships.
        if len(team_memberships) == 0:
            raise ValueError("User has no team memberships.")

        if len(team_memberships) == 1:
            return ResolvedOwnerScope("team", team_memberships[0].team_id)

        # Multiple teams — ambiguous.
        raise ValueError(
            "Ambiguous team selection: user belongs to multiple teams. "
            "Provide explicit owner_id."
        )

    def _resolve_enterprise_create_target(
        self,
        ownership_ctx: ResolvedOwnershipContext,
    ) -> ResolvedOwnerScope:
        """Resolve an enterprise-owned create target (Rule 3 implementation).

        Parameters
        ----------
        ownership_ctx:
            The resolved context for the current actor.

        Returns
        -------
        ResolvedOwnerScope

        Raises
        ------
        PermissionError
            When the actor is not a system admin.
        ValueError
            When no tenant_id is available.
        """
        if not ownership_ctx.is_system_admin:
            raise PermissionError(
                "Enterprise-owned creates require the 'system_admin' role."
            )

        if ownership_ctx.tenant_id is None:
            raise ValueError(
                "Cannot create enterprise-owned resource: no tenant_id in context."
            )

        return ResolvedOwnerScope("enterprise", str(ownership_ctx.tenant_id))
