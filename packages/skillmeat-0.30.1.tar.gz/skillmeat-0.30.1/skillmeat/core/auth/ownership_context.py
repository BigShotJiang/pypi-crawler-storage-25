"""Resolved ownership context dataclasses for enterprise governance.

These frozen dataclasses represent the fully resolved ownership state for an
authenticated actor. They are computed once per request (or session boundary)
and carried through the authorization layer without further I/O.

Design rules encoded here:
- Rule 1: default_owner_type is always "user"; default_owner_id is the actor.
- Write access to team scope requires role == "admin" in that team.
- Write access to enterprise scope requires is_system_admin == True.
- Read access (visible_owner_scopes) is broader than write access.
"""

from __future__ import annotations

from dataclasses import dataclass

__all__ = [
    "ResolvedTeamMembership",
    "ResolvedOwnerScope",
    "ResolvedOwnershipContext",
]


@dataclass(frozen=True)
class ResolvedTeamMembership:
    """A single team membership record for the resolved actor.

    Attributes:
        team_id: Unique identifier for the team.
        role: The actor's role in the team — either ``"member"`` or ``"admin"``.
    """

    team_id: str
    role: str  # "member" or "admin"


@dataclass(frozen=True)
class ResolvedOwnerScope:
    """A single ownership scope visible or writable by the resolved actor.

    Attributes:
        owner_type: One of ``"user"``, ``"team"``, or ``"enterprise"``.
        owner_id: The identifier of the owner entity.
    """

    owner_type: str  # "user", "team", or "enterprise"
    owner_id: str


@dataclass(frozen=True)
class ResolvedOwnershipContext:
    """Fully resolved ownership context for an authenticated actor.

    This object is immutable (``frozen=True``) and carries all data needed to
    evaluate ownership and access rules without additional I/O.

    Attributes:
        actor_user_id: The unique identifier of the authenticated user.
        tenant_id: The tenant identifier (``None`` for single-tenant deployments).
        is_system_admin: Whether the actor holds the system-admin role.
        team_memberships: All team memberships for the actor.
        allowed_owner_types: Owner types this actor may use, ordered by
            increasing privilege:
            - ``("user",)``
            - ``("user", "team")``
            - ``("user", "team", "enterprise")``
        default_owner_type: The owner type used when none is specified.
            Always ``"user"`` per Rule 1.
        default_owner_id: The owner id used when none is specified.
            Always ``str(actor_user_id)`` per Rule 1.
        visible_owner_scopes: All owner scopes this actor may read from,
            including their own user scope, all team scopes, and the enterprise
            scope when applicable.
    """

    actor_user_id: str
    tenant_id: str | None
    is_system_admin: bool
    team_memberships: tuple[ResolvedTeamMembership, ...]
    allowed_owner_types: tuple[str, ...]
    default_owner_type: str
    default_owner_id: str
    visible_owner_scopes: tuple[ResolvedOwnerScope, ...]

    # ------------------------------------------------------------------
    # Read-access helpers
    # ------------------------------------------------------------------

    @property
    def readable_owner_scopes(self) -> tuple[ResolvedOwnerScope, ...]:
        """All owner scopes this actor can read from.

        Returns ``visible_owner_scopes`` unchanged; the property exists to
        make the read/write symmetry explicit at call sites.
        """
        return self.visible_owner_scopes

    # ------------------------------------------------------------------
    # Write-access helpers
    # ------------------------------------------------------------------

    @property
    def writable_owner_scopes(self) -> tuple[ResolvedOwnerScope, ...]:
        """Subset of ``visible_owner_scopes`` that this actor may write to.

        Rules:
        - ``"user"`` scope: writable only for the actor's own user id.
        - ``"team"`` scope: writable only when the actor's role in that team
          is ``"admin"``.
        - ``"enterprise"`` scope: writable only when ``is_system_admin`` is
          ``True``.
        """
        admin_team_ids = frozenset(
            m.team_id for m in self.team_memberships if m.role == "admin"
        )
        result: list[ResolvedOwnerScope] = []
        for scope in self.visible_owner_scopes:
            if scope.owner_type == "user" and scope.owner_id == self.actor_user_id:
                result.append(scope)
            elif scope.owner_type == "team" and scope.owner_id in admin_team_ids:
                result.append(scope)
            elif scope.owner_type == "enterprise" and self.is_system_admin:
                result.append(scope)
        return tuple(result)

    # ------------------------------------------------------------------
    # Team membership helpers
    # ------------------------------------------------------------------

    @property
    def team_ids(self) -> frozenset[str]:
        """Frozenset of all team ids this actor belongs to."""
        return frozenset(m.team_id for m in self.team_memberships)

    def is_member_of(self, team_id: str) -> bool:
        """Return ``True`` if the actor is a member (any role) of *team_id*."""
        return any(m.team_id == team_id for m in self.team_memberships)

    def is_admin_of(self, team_id: str) -> bool:
        """Return ``True`` if the actor holds the ``"admin"`` role in *team_id*."""
        return any(
            m.team_id == team_id and m.role == "admin" for m in self.team_memberships
        )
