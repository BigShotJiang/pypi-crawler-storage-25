"""Enterprise collection auto-bind service.

When a new User or Team is provisioned under a tenant this module creates
read-only ``EnterpriseCollectionBinding`` rows for every active global
enterprise collection (``is_global_collection=True AND auto_bind=True``).

This ensures Day-0 inheritance of enterprise artifacts without requiring
any manual configuration by the tenant administrator.

Public API:
    auto_bind_global_collections: Create bindings for a newly-provisioned entity.
    list_bindings:                 List all collection bindings for an entity.
    unbind_collection:             Remove a binding (read-only bindings require
                                   system_admin privilege).

Design invariants:
    - All operations require the caller to supply a live SQLAlchemy ``Session``
      that already has the correct tenant scope applied.
    - Every query includes a ``tenant_id`` predicate — omitting it is a
      security defect.
    - ``auto_bind_global_collections`` is idempotent: calling it twice for the
      same entity does NOT create duplicate bindings.
    - ``unbind_collection`` raises ``PermissionError`` when
      ``binding.is_readonly=True`` and ``is_system_admin=False``.

References:
    skillmeat/cache/models_enterprise.py  (EnterpriseCollection,
                                           EnterpriseCollectionBinding)
    EG-2.6 enterprise-governance auto-bind feature.
"""

from __future__ import annotations

import logging
import uuid
from typing import List

from sqlalchemy import select
from sqlalchemy.orm import Session

from skillmeat.cache.models_enterprise import (
    EnterpriseCollection,
    EnterpriseCollectionBinding,
)

logger = logging.getLogger(__name__)


def auto_bind_global_collections(
    session: Session,
    tenant_id: str,
    entity_type: str,
    entity_id: str,
) -> List[EnterpriseCollectionBinding]:
    """Auto-bind a newly-provisioned entity to all active global enterprise
    collections for the given tenant.

    For each ``EnterpriseCollection`` in the tenant where both
    ``is_global_collection=True`` and ``auto_bind=True``, this function checks
    whether a binding already exists and, if not, creates one with
    ``is_readonly=True``.  The operation is idempotent: duplicate calls for
    the same (tenant, entity_type, entity_id) are safe.

    Args:
        session:     Live SQLAlchemy ``Session`` scoped to the enterprise DB.
        tenant_id:   String UUID of the tenant that owns both the collections
                     and the entity being provisioned.
        entity_type: ``"user"`` or ``"team"``.
        entity_id:   String UUID of the newly-provisioned user or team.

    Returns:
        List of ``EnterpriseCollectionBinding`` rows that were newly created
        by this call.  Already-existing bindings are not included.

    Raises:
        ValueError: If ``entity_type`` is not ``"user"`` or ``"team"``.
    """
    if entity_type not in ("user", "team"):
        raise ValueError(f"entity_type must be 'user' or 'team', got {entity_type!r}")

    tenant_uuid = _to_uuid(tenant_id)
    entity_uuid = _to_uuid(entity_id)

    # 1. Find all global, auto-bind collections for this tenant.
    global_collections: List[EnterpriseCollection] = list(
        session.execute(
            select(EnterpriseCollection).where(
                EnterpriseCollection.tenant_id == tenant_uuid,
                EnterpriseCollection.is_global_collection.is_(True),
                EnterpriseCollection.auto_bind.is_(True),
            )
        ).scalars()
    )

    if not global_collections:
        logger.debug(
            "auto_bind_global_collections: no eligible global collections for "
            "tenant=%s — nothing to bind",
            tenant_id,
        )
        return []

    created: List[EnterpriseCollectionBinding] = []

    for collection in global_collections:
        # 2. Check for an existing binding (idempotency guard).
        existing = session.execute(
            select(EnterpriseCollectionBinding).where(
                EnterpriseCollectionBinding.tenant_id == tenant_uuid,
                EnterpriseCollectionBinding.collection_id == collection.id,
                EnterpriseCollectionBinding.bound_entity_type == entity_type,
                EnterpriseCollectionBinding.bound_entity_id == entity_uuid,
            )
        ).scalar_one_or_none()

        if existing is not None:
            logger.debug(
                "auto_bind_global_collections: binding already exists for "
                "tenant=%s collection=%s %s=%s — skipping",
                tenant_id,
                collection.id,
                entity_type,
                entity_id,
            )
            continue

        # 3. Create a new read-only binding.
        binding = EnterpriseCollectionBinding(
            tenant_id=tenant_uuid,
            collection_id=collection.id,
            bound_entity_type=entity_type,
            bound_entity_id=entity_uuid,
            is_readonly=True,
        )
        session.add(binding)
        created.append(binding)
        logger.info(
            "auto_bind_global_collections: created binding "
            "tenant=%s collection=%s %s=%s",
            tenant_id,
            collection.id,
            entity_type,
            entity_id,
        )

    return created


def list_bindings(
    session: Session,
    tenant_id: str,
    entity_type: str,
    entity_id: str,
) -> List[EnterpriseCollectionBinding]:
    """List all collection bindings for a given entity within a tenant.

    Args:
        session:     Live SQLAlchemy ``Session`` scoped to the enterprise DB.
        tenant_id:   String UUID of the tenant.
        entity_type: ``"user"`` or ``"team"``.
        entity_id:   String UUID of the user or team.

    Returns:
        All ``EnterpriseCollectionBinding`` rows for the specified entity,
        ordered by ``created_at`` ascending.

    Raises:
        ValueError: If ``entity_type`` is not ``"user"`` or ``"team"``.
    """
    if entity_type not in ("user", "team"):
        raise ValueError(f"entity_type must be 'user' or 'team', got {entity_type!r}")

    tenant_uuid = _to_uuid(tenant_id)
    entity_uuid = _to_uuid(entity_id)

    rows = list(
        session.execute(
            select(EnterpriseCollectionBinding)
            .where(
                EnterpriseCollectionBinding.tenant_id == tenant_uuid,
                EnterpriseCollectionBinding.bound_entity_type == entity_type,
                EnterpriseCollectionBinding.bound_entity_id == entity_uuid,
            )
            .order_by(EnterpriseCollectionBinding.created_at)
        ).scalars()
    )
    return rows


def unbind_collection(
    session: Session,
    binding_id: str,
    *,
    is_system_admin: bool = False,
) -> bool:
    """Remove a collection binding by ID.

    Read-only bindings (``is_readonly=True``) may only be deleted when
    ``is_system_admin=True``.

    Args:
        session:         Live SQLAlchemy ``Session`` scoped to the enterprise DB.
        binding_id:      String UUID of the ``EnterpriseCollectionBinding`` to remove.
        is_system_admin: When ``True`` the caller is a system administrator and
                         may remove read-only bindings.

    Returns:
        ``True`` if the binding was found and deleted; ``False`` if no binding
        with the given ID exists.

    Raises:
        PermissionError: If the binding is read-only and ``is_system_admin`` is
                         ``False``.
    """
    binding_uuid = _to_uuid(binding_id)

    binding = session.execute(
        select(EnterpriseCollectionBinding).where(
            EnterpriseCollectionBinding.id == binding_uuid,
        )
    ).scalar_one_or_none()

    if binding is None:
        return False

    if binding.is_readonly and not is_system_admin:
        raise PermissionError(
            f"Binding {binding_id!r} is read-only; only a system administrator "
            "may remove it."
        )

    session.delete(binding)
    logger.info(
        "unbind_collection: removed binding id=%s (is_readonly=%s, by_admin=%s)",
        binding_id,
        binding.is_readonly,
        is_system_admin,
    )
    return True


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _to_uuid(value: str) -> uuid.UUID:
    """Coerce a string to ``uuid.UUID``, raising ``ValueError`` on failure."""
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError) as exc:
        raise ValueError(f"Invalid UUID value: {value!r}") from exc
