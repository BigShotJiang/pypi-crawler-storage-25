"""IMembershipRepository abstraction for team membership lookups.

Provides a ``typing.Protocol`` that both local (SQLite) and enterprise
(PostgreSQL) implementations satisfy, along with the two concrete
implementations:

- ``LocalMembershipRepository``   — reads from ``team_members`` (local mode)
- ``EnterpriseMembershipRepository`` — reads from ``enterprise_team_members``
  (enterprise mode, SQLAlchemy 2.x style)

The ``TeamMembershipInfo`` frozen dataclass is the shared return type for
membership queries.

References:
    skillmeat/cache/models.py              — Team, TeamMember (local)
    skillmeat/cache/models_enterprise.py   — EnterpriseTeam, EnterpriseTeamMember
    skillmeat/cache/auth_types.py          — UserRole enum
    skillmeat/core/auth/__init__.py        — re-exports from here
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, List, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

if TYPE_CHECKING:
    pass


__all__ = [
    "TeamMembershipInfo",
    "IMembershipRepository",
    "LocalMembershipRepository",
    "EnterpriseMembershipRepository",
]


# =============================================================================
# TeamMembershipInfo dataclass
# =============================================================================


@dataclass(frozen=True)
class TeamMembershipInfo:
    """Immutable record of a user's membership in a single team.

    Attributes:
        team_id:  String identifier of the team (int PK for local, UUID for
                  enterprise — callers receive it as a plain ``str`` so that
                  the consumer is insulated from backend differences).
        role:     Team-level role string; one of ``"team_member"`` or
                  ``"team_admin"``.
    """

    team_id: str
    role: str


# =============================================================================
# IMembershipRepository Protocol
# =============================================================================


class IMembershipRepository:
    """Structural subtyping contract for team membership repositories.

    Any class that provides these three methods with compatible signatures is
    considered to satisfy this protocol.  The ``@runtime_checkable`` decorator
    is intentionally omitted — use static type checking (mypy) rather than
    runtime ``isinstance`` checks.
    """

    def list_user_team_memberships(
        self,
        user_id: str,
        tenant_id: Optional[str] = None,
    ) -> List[TeamMembershipInfo]:
        """Return all teams the user belongs to.

        Parameters
        ----------
        user_id:
            String representation of the user's primary key.
        tenant_id:
            Optional tenant scope.  Ignored by ``LocalMembershipRepository``
            (local mode has no multi-tenancy); required for reliable results
            from ``EnterpriseMembershipRepository``.

        Returns
        -------
        list[TeamMembershipInfo]
            One entry per team membership, in undefined order.  Returns an
            empty list when the user has no memberships.
        """
        raise NotImplementedError

    def is_team_member(
        self,
        user_id: str,
        team_id: str,
        tenant_id: Optional[str] = None,
    ) -> bool:
        """Return ``True`` if the user has any membership in *team_id*.

        Parameters
        ----------
        user_id:
            String representation of the user's primary key.
        team_id:
            String representation of the team's primary key.
        tenant_id:
            Optional tenant scope.

        Returns
        -------
        bool
        """
        raise NotImplementedError

    def is_team_admin(
        self,
        user_id: str,
        team_id: str,
        tenant_id: Optional[str] = None,
    ) -> bool:
        """Return ``True`` if the user holds the ``team_admin`` role in *team_id*.

        Parameters
        ----------
        user_id:
            String representation of the user's primary key.
        team_id:
            String representation of the team's primary key.
        tenant_id:
            Optional tenant scope.

        Returns
        -------
        bool
        """
        raise NotImplementedError


# =============================================================================
# LocalMembershipRepository
# =============================================================================


class LocalMembershipRepository:
    """Reads team membership from the local ``team_members`` table.

    Uses SQLAlchemy 1.x ``session.query()`` style, consistent with other local
    repositories in ``skillmeat/cache/repositories.py``.

    Local mode has no multi-tenancy; the ``tenant_id`` parameter is accepted
    for interface parity but always ignored.

    Parameters
    ----------
    session:
        An active SQLAlchemy ``Session`` bound to the local SQLite database.
    """

    def __init__(self, session: Session) -> None:
        self._session = session

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def list_user_team_memberships(
        self,
        user_id: str,
        tenant_id: Optional[str] = None,
    ) -> List[TeamMembershipInfo]:
        """Return all teams the user belongs to (local mode).

        Parameters
        ----------
        user_id:
            String form of the user's integer primary key.
        tenant_id:
            Ignored in local mode (no multi-tenancy).

        Returns
        -------
        list[TeamMembershipInfo]
        """
        from skillmeat.cache.models import (
            TeamMember,
        )  # local import avoids circular dep

        rows = (
            self._session.query(TeamMember)
            .filter(TeamMember.user_id == int(user_id))
            .all()
        )
        return [
            TeamMembershipInfo(team_id=str(row.team_id), role=row.role) for row in rows
        ]

    def is_team_member(
        self,
        user_id: str,
        team_id: str,
        tenant_id: Optional[str] = None,
    ) -> bool:
        """Return ``True`` if the user has any membership in *team_id* (local mode).

        Parameters
        ----------
        user_id:
            String form of the user's integer primary key.
        team_id:
            String form of the team's integer primary key.
        tenant_id:
            Ignored in local mode.

        Returns
        -------
        bool
        """
        from skillmeat.cache.models import TeamMember

        row = (
            self._session.query(TeamMember)
            .filter(
                TeamMember.user_id == int(user_id),
                TeamMember.team_id == int(team_id),
            )
            .first()
        )
        return row is not None

    def is_team_admin(
        self,
        user_id: str,
        team_id: str,
        tenant_id: Optional[str] = None,
    ) -> bool:
        """Return ``True`` if the user holds ``team_admin`` in *team_id* (local mode).

        Parameters
        ----------
        user_id:
            String form of the user's integer primary key.
        team_id:
            String form of the team's integer primary key.
        tenant_id:
            Ignored in local mode.

        Returns
        -------
        bool
        """
        from skillmeat.cache.models import TeamMember

        row = (
            self._session.query(TeamMember)
            .filter(
                TeamMember.user_id == int(user_id),
                TeamMember.team_id == int(team_id),
                TeamMember.role == "team_admin",
            )
            .first()
        )
        return row is not None


# =============================================================================
# EnterpriseMembershipRepository
# =============================================================================


class EnterpriseMembershipRepository:
    """Reads team membership from the ``enterprise_team_members`` table.

    Uses SQLAlchemy 2.x ``select()`` style, consistent with other enterprise
    repositories in ``skillmeat/cache/enterprise_repositories.py``.

    Enterprise mode requires tenant isolation.  When ``tenant_id`` is provided
    every query includes a ``WHERE tenant_id = ?`` predicate.

    Parameters
    ----------
    session:
        An active SQLAlchemy ``Session`` bound to the enterprise PostgreSQL
        database.
    """

    def __init__(self, session: Session) -> None:
        self._session = session

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def list_user_team_memberships(
        self,
        user_id: str,
        tenant_id: Optional[str] = None,
    ) -> List[TeamMembershipInfo]:
        """Return all teams the user belongs to (enterprise mode).

        Parameters
        ----------
        user_id:
            UUID string of the enterprise user.
        tenant_id:
            UUID string of the tenant.  Strongly recommended — omitting it
            returns memberships across all tenants, which is only appropriate
            for system-admin tooling.

        Returns
        -------
        list[TeamMembershipInfo]
        """
        import uuid as _uuid

        from skillmeat.cache.models_enterprise import EnterpriseTeamMember

        stmt = select(EnterpriseTeamMember).where(
            EnterpriseTeamMember.user_id == _uuid.UUID(user_id)
        )
        if tenant_id is not None:
            stmt = stmt.where(EnterpriseTeamMember.tenant_id == _uuid.UUID(tenant_id))

        rows = self._session.execute(stmt).scalars().all()
        return [
            TeamMembershipInfo(team_id=str(row.team_id), role=row.role) for row in rows
        ]

    def is_team_member(
        self,
        user_id: str,
        team_id: str,
        tenant_id: Optional[str] = None,
    ) -> bool:
        """Return ``True`` if the user has any membership in *team_id* (enterprise mode).

        Parameters
        ----------
        user_id:
            UUID string of the enterprise user.
        team_id:
            UUID string of the enterprise team.
        tenant_id:
            UUID string of the tenant for scoping.

        Returns
        -------
        bool
        """
        import uuid as _uuid

        from skillmeat.cache.models_enterprise import EnterpriseTeamMember

        stmt = select(EnterpriseTeamMember).where(
            EnterpriseTeamMember.user_id == _uuid.UUID(user_id),
            EnterpriseTeamMember.team_id == _uuid.UUID(team_id),
        )
        if tenant_id is not None:
            stmt = stmt.where(EnterpriseTeamMember.tenant_id == _uuid.UUID(tenant_id))

        row = self._session.execute(stmt).scalars().first()
        return row is not None

    def is_team_admin(
        self,
        user_id: str,
        team_id: str,
        tenant_id: Optional[str] = None,
    ) -> bool:
        """Return ``True`` if the user holds ``team_admin`` in *team_id* (enterprise mode).

        Parameters
        ----------
        user_id:
            UUID string of the enterprise user.
        team_id:
            UUID string of the enterprise team.
        tenant_id:
            UUID string of the tenant for scoping.

        Returns
        -------
        bool
        """
        import uuid as _uuid

        from skillmeat.cache.models_enterprise import EnterpriseTeamMember

        stmt = select(EnterpriseTeamMember).where(
            EnterpriseTeamMember.user_id == _uuid.UUID(user_id),
            EnterpriseTeamMember.team_id == _uuid.UUID(team_id),
            EnterpriseTeamMember.role == "team_admin",
        )
        if tenant_id is not None:
            stmt = stmt.where(EnterpriseTeamMember.tenant_id == _uuid.UUID(tenant_id))

        row = self._session.execute(stmt).scalars().first()
        return row is not None
