"""Authentication and token management for SkillMeat web interface.

This module provides secure token-based authentication for local CLI-to-web
communication. It supports multiple storage backends including OS keychains
and encrypted file storage.

It also exposes the enterprise collection auto-bind service (EG-2.6) which
creates Day-0 read-only bindings between newly-provisioned users/teams and
all active global enterprise collections in their tenant.
"""

from .auto_bind import (
    auto_bind_global_collections,
    list_bindings,
    unbind_collection,
)
from .membership_repository import (
    EnterpriseMembershipRepository,
    IMembershipRepository,
    LocalMembershipRepository,
    TeamMembershipInfo,
)
from .ownership_context import (
    ResolvedTeamMembership,
    ResolvedOwnerScope,
    ResolvedOwnershipContext,
)
from .ownership_resolver import OwnershipResolver
from .scope_enforcement import enforce_enterprise_scope
from .storage import TokenStorage, KeychainStorage, EncryptedFileStorage
from .token_manager import TokenManager, Token, TokenInfo

__all__ = [
    # Auto-bind service (EG-2.6)
    "auto_bind_global_collections",
    "list_bindings",
    "unbind_collection",
    # Token management
    "TokenStorage",
    "KeychainStorage",
    "EncryptedFileStorage",
    "TokenManager",
    "Token",
    "TokenInfo",
    # Ownership / membership
    "ResolvedTeamMembership",
    "ResolvedOwnerScope",
    "ResolvedOwnershipContext",
    "OwnershipResolver",
    "enforce_enterprise_scope",
    "TeamMembershipInfo",
    "IMembershipRepository",
    "LocalMembershipRepository",
    "EnterpriseMembershipRepository",
]
