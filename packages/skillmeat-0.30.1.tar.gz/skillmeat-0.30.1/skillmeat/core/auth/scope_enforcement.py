"""Enterprise scope isolation enforcement.

Provides authorization guards ensuring only system_admin can mutate
enterprise-scoped resources. Used by API routers for write operations
on artifacts and collections.
"""

from fastapi import HTTPException

from skillmeat.core.auth.ownership_context import ResolvedOwnershipContext

__all__ = ["enforce_enterprise_scope"]


def enforce_enterprise_scope(
    ownership_ctx: ResolvedOwnershipContext,
    target_owner_type: str,
    operation: str = "modify",
) -> None:
    """Raise 403 if non-system_admin tries to mutate enterprise resources.

    Args:
        ownership_ctx: Resolved ownership context for the current request
        target_owner_type: The owner_type of the target resource ("user", "team", "enterprise")
        operation: Human-readable operation name for error message

    Raises:
        HTTPException: 403 if caller is not system_admin and target is enterprise-scoped
    """
    if target_owner_type == "enterprise" and not ownership_ctx.is_system_admin:
        raise HTTPException(
            status_code=403,
            detail=f"Cannot {operation} enterprise-scoped resources. Requires system_admin role.",
        )
