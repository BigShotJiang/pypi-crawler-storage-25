"""Enterprise version scope management service for SkillMeat.

Manages per-owner-per-project version scope state for enterprise artifacts:
divergence detection, and a promotion state machine
(none → pending → approved/rejected → none).

Usage::

    from skillmeat.core.enterprise_version_scope import EnterpriseVersionScopeService

    svc = EnterpriseVersionScopeService(session)
    result = svc.detect_divergence(
        tenant_id=tenant_id,
        project_id=project_id,
        artifact_id=artifact_id,
        owner_type="user",
        owner_id=user_id,
    )
    if result["is_diverged"]:
        scope_id = result["scope_id"]
        svc.create_promotion_request(scope_id, tenant_id, requesting_user_id=user_id)
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from sqlalchemy.orm import Session

from skillmeat.cache.enterprise_repositories import (
    EnterpriseArtifactVersionScopeRepository,
)

logger = logging.getLogger(__name__)


def _derive_sync_status(
    head_hash: str,
    baseline_hash: Optional[str],
    is_diverged: bool,
) -> str:
    """Derive ``sync_status`` from scope hash fields.

    Mirrors the SQL CASE expression in migration ent_022 and the identical
    helper in ``enterprise_context_sync`` so all mutation sites stay consistent.

    Priority: diverged > pending (no baseline) > current (equal hashes) > outdated.
    """
    if is_diverged:
        return "diverged"
    if baseline_hash is None:
        return "pending"
    if head_hash == baseline_hash:
        return "current"
    return "outdated"

__all__ = ["EnterpriseVersionScopeService"]

# ---------------------------------------------------------------------------
# Valid promotion state transitions
# ---------------------------------------------------------------------------

# States from which a promotion request can be submitted.
_CAN_REQUEST_FROM = {"none", "rejected", None}

# States from which approval is valid (strictly 'pending' only).
_CAN_APPROVE_FROM = {"pending"}

# States from which rejection is valid (strictly 'pending' only).
_CAN_REJECT_FROM = {"pending"}


class EnterpriseVersionScopeService:
    """Manages enterprise version scopes — divergence detection and promotion.

    All mutations flush via the repository but do NOT commit; transaction
    lifecycle is the caller's responsibility (typically a FastAPI route that
    commits on clean exit and rolls back on exception).

    Parameters
    ----------
    session:
        SQLAlchemy ``Session`` bound to the PostgreSQL enterprise database.
        Typically injected via ``DbSessionDep`` in FastAPI routes.
    """

    def __init__(self, session: Session) -> None:
        self._session = session
        self._repo = EnterpriseArtifactVersionScopeRepository(session)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _scope_to_dict(scope: Any) -> Dict[str, Any]:
        """Convert an ``EnterpriseArtifactVersionScope`` ORM row to a dict.

        Returns a plain dict suitable for JSON serialisation.  All UUID
        fields are converted to strings; datetime fields to ISO-8601 strings.
        """
        return {
            "id": str(scope.id),
            "tenant_id": str(scope.tenant_id),
            "project_id": str(scope.project_id),
            "artifact_id": str(scope.artifact_id),
            "owner_type": scope.owner_type,
            "owner_id": str(scope.owner_id),
            "head_hash": scope.head_hash,
            "baseline_hash": scope.baseline_hash,
            "is_diverged": scope.is_diverged,
            "promotion_state": scope.promotion_state,
            "promotion_requested_at": (
                scope.promotion_requested_at.isoformat()
                if scope.promotion_requested_at is not None
                else None
            ),
            "promotion_reviewed_by": (
                str(scope.promotion_reviewed_by)
                if scope.promotion_reviewed_by is not None
                else None
            ),
            "promotion_reviewed_at": (
                scope.promotion_reviewed_at.isoformat()
                if scope.promotion_reviewed_at is not None
                else None
            ),
            "created_at": (
                scope.created_at.isoformat() if scope.created_at is not None else None
            ),
            "updated_at": (
                scope.updated_at.isoformat() if scope.updated_at is not None else None
            ),
        }

    def _get_scope_or_raise(
        self,
        scope_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> Any:
        """Fetch a scope row by PK and validate tenant ownership.

        Parameters
        ----------
        scope_id:
            Primary key of the scope row.
        tenant_id:
            Expected tenant; raises ``ValueError`` if the row belongs to a
            different tenant.

        Returns
        -------
        EnterpriseArtifactVersionScope
            The scope row.

        Raises
        ------
        ValueError
            If no row is found for *scope_id* or the row's tenant does not
            match *tenant_id*.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope

        scope = self._session.get(EnterpriseArtifactVersionScope, scope_id)
        if scope is None:
            raise ValueError(
                f"EnterpriseArtifactVersionScope id={scope_id!s} not found"
            )
        if scope.tenant_id != tenant_id:
            raise ValueError(
                f"Scope id={scope_id!s} belongs to tenant {scope.tenant_id!s}, "
                f"not {tenant_id!s}"
            )
        return scope

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_scope_by_artifact(
        self,
        tenant_id: uuid.UUID,
        project_id: uuid.UUID,
        artifact_id: uuid.UUID,
        owner_type: str,
        owner_id: uuid.UUID,
    ) -> Optional[Dict[str, Any]]:
        """Return the scope dict for a specific owner, or ``None`` if absent.

        Delegates to
        :meth:`EnterpriseArtifactVersionScopeRepository.read_by_owner`.
        All queries are tenant-scoped by the repository.

        Parameters
        ----------
        tenant_id:
            Tenant scope.
        project_id:
            Project UUID the scope belongs to.
        artifact_id:
            FK to ``enterprise_artifacts.id``.
        owner_type:
            Owner category: ``'user'``, ``'team'``, or ``'enterprise'``.
        owner_id:
            UUID of the owning entity.

        Returns
        -------
        dict or None
            Scope fields as a plain dict, or ``None`` if no row exists.
        """
        scope = self._repo.read_by_owner(
            tenant_id=tenant_id,
            project_id=project_id,
            artifact_id=artifact_id,
            owner_type=owner_type,
            owner_id=owner_id,
        )
        if scope is None:
            logger.debug(
                "get_scope_by_artifact: no scope for artifact=%s owner=%s/%s",
                artifact_id,
                owner_type,
                owner_id,
            )
            return None
        return self._scope_to_dict(scope)

    def detect_divergence(
        self,
        tenant_id: uuid.UUID,
        project_id: uuid.UUID,
        artifact_id: uuid.UUID,
        owner_type: str,
        owner_id: uuid.UUID,
        head_hash: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Compute and persist divergence state for an owner's scope.

        Uses O(1) hash comparison: ``head_hash != baseline_hash``.  If no
        scope row exists yet, ``lazy_bootstrap_scope`` creates one using
        *head_hash* as both the head and baseline (no divergence at init).

        When *head_hash* is ``None`` the caller must ensure the scope already
        exists (``lazy_bootstrap_scope`` is skipped and the current
        ``head_hash`` on the row is used for comparison).

        Parameters
        ----------
        tenant_id:
            Tenant scope.
        project_id:
            Project UUID the scope belongs to.
        artifact_id:
            FK to ``enterprise_artifacts.id``.
        owner_type:
            Owner category: ``'user'``, ``'team'``, or ``'enterprise'``.
        owner_id:
            UUID of the owning entity.
        head_hash:
            Current content hash for the owner's copy.  Pass ``None`` only
            when the scope is already known to exist and you want to
            re-evaluate divergence against the stored ``head_hash``.

        Returns
        -------
        dict
            ``{is_diverged, head_hash, baseline_hash, scope_id}``

        Raises
        ------
        ValueError
            If *head_hash* is ``None`` and no scope row exists yet.
        """
        if head_hash is not None:
            scope = self._repo.lazy_bootstrap_scope(
                tenant_id=tenant_id,
                project_id=project_id,
                artifact_id=artifact_id,
                owner_type=owner_type,
                owner_id=owner_id,
                head_hash=head_hash,
            )
        else:
            scope = self._repo.read_by_owner(
                tenant_id=tenant_id,
                project_id=project_id,
                artifact_id=artifact_id,
                owner_type=owner_type,
                owner_id=owner_id,
            )
            if scope is None:
                raise ValueError(
                    f"No scope found for artifact={artifact_id!s} "
                    f"owner={owner_type}/{owner_id!s} — provide head_hash to bootstrap."
                )

        current_head = scope.head_hash
        current_baseline = scope.baseline_hash

        # O(1) comparison: diverged when hashes differ (None baseline = not diverged)
        is_diverged = current_baseline is not None and current_head != current_baseline

        if scope.is_diverged != is_diverged:
            logger.debug(
                "detect_divergence: updating is_diverged=%s for scope id=%s",
                is_diverged,
                scope.id,
            )
            scope = self._repo.mark_diverged(
                scope_id=scope.id,
                tenant_id=tenant_id,
                is_diverged=is_diverged,
            )

        logger.debug(
            "detect_divergence: scope id=%s is_diverged=%s head=%s... baseline=%s...",
            scope.id,
            is_diverged,
            current_head[:12] if current_head else "",
            current_baseline[:12] if current_baseline else "None",
        )

        return {
            "scope_id": str(scope.id),
            "is_diverged": is_diverged,
            "head_hash": current_head,
            "baseline_hash": current_baseline,
        }

    def create_promotion_request(
        self,
        scope_id: uuid.UUID,
        tenant_id: uuid.UUID,
        requesting_user_id: uuid.UUID,
    ) -> Dict[str, Any]:
        """Transition scope to ``promotion_state='pending'``.

        Valid from: ``'none'``, ``'rejected'``, or ``None`` (unset).

        Parameters
        ----------
        scope_id:
            PK of the scope row.
        tenant_id:
            Tenant that must own the row.
        requesting_user_id:
            UUID of the user submitting the promotion request.

        Returns
        -------
        dict
            Updated scope as a plain dict.

        Raises
        ------
        ValueError
            If the current ``promotion_state`` is ``'pending'`` or
            ``'approved'`` (invalid transition).
        """
        scope = self._get_scope_or_raise(scope_id, tenant_id)

        current_state = scope.promotion_state
        if current_state not in _CAN_REQUEST_FROM:
            raise ValueError(
                f"Cannot create promotion request from state '{current_state}'. "
                f"Valid source states: {sorted(s for s in _CAN_REQUEST_FROM if s is not None)}. "
                f"Current state must be reset before re-requesting."
            )

        now = datetime.now(timezone.utc)
        scope.promotion_state = "pending"
        scope.promotion_requested_at = now
        # Clear any stale review fields from a previous cycle.
        scope.promotion_reviewed_by = None
        scope.promotion_reviewed_at = None
        scope.updated_at = now

        self._session.flush()

        logger.info(
            "create_promotion_request: scope id=%s tenant=%s "
            "requested_by=%s — state → pending",
            scope_id,
            tenant_id,
            requesting_user_id,
        )

        return self._scope_to_dict(scope)

    def approve_promotion(
        self,
        scope_id: uuid.UUID,
        tenant_id: uuid.UUID,
        reviewer_id: uuid.UUID,
    ) -> Dict[str, Any]:
        """Approve a pending promotion: accept user's head as new baseline.

        Transitions ``promotion_state`` from ``'pending'`` to ``'approved'``,
        sets ``baseline_hash = head_hash``, clears ``is_diverged``, and
        appends an ``ArtifactHistoryEvent`` with ``event_type='promote'``.

        Parameters
        ----------
        scope_id:
            PK of the scope row.
        tenant_id:
            Tenant that must own the row.
        reviewer_id:
            UUID of the reviewer approving the promotion.

        Returns
        -------
        dict
            Updated scope as a plain dict.

        Raises
        ------
        ValueError
            If the current ``promotion_state`` is not ``'pending'``.
        """
        scope = self._get_scope_or_raise(scope_id, tenant_id)

        current_state = scope.promotion_state
        if current_state not in _CAN_APPROVE_FROM:
            raise ValueError(
                f"Cannot approve promotion from state '{current_state}'. "
                f"Scope must be in 'pending' state."
            )

        now = datetime.now(timezone.utc)
        accepted_hash = scope.head_hash

        scope.baseline_hash = accepted_hash
        scope.is_diverged = False
        scope.sync_status = _derive_sync_status(
            head_hash=accepted_hash,
            baseline_hash=accepted_hash,
            is_diverged=False,
        )
        scope.promotion_state = "approved"
        scope.promotion_reviewed_by = reviewer_id
        scope.promotion_reviewed_at = now
        scope.updated_at = now

        self._session.flush()

        # Record the promotion event in the shared history table.
        self._record_history_event(
            artifact_id=str(scope.artifact_id),
            event_type="promote",
            actor_id=str(reviewer_id),
            owner_type=scope.owner_type,
            content_hash=accepted_hash,
        )

        logger.info(
            "approve_promotion: scope id=%s tenant=%s "
            "reviewed_by=%s — state → approved, baseline_hash=%s...",
            scope_id,
            tenant_id,
            reviewer_id,
            accepted_hash[:12],
        )

        return self._scope_to_dict(scope)

    def reject_promotion(
        self,
        scope_id: uuid.UUID,
        tenant_id: uuid.UUID,
        reviewer_id: uuid.UUID,
    ) -> Dict[str, Any]:
        """Reject a pending promotion request.

        Transitions ``promotion_state`` from ``'pending'`` to ``'rejected'``.
        Does NOT alter ``is_diverged`` or either hash — the user's version
        remains diverged from the baseline.

        Parameters
        ----------
        scope_id:
            PK of the scope row.
        tenant_id:
            Tenant that must own the row.
        reviewer_id:
            UUID of the reviewer rejecting the promotion.

        Returns
        -------
        dict
            Updated scope as a plain dict.

        Raises
        ------
        ValueError
            If the current ``promotion_state`` is not ``'pending'``.
        """
        scope = self._get_scope_or_raise(scope_id, tenant_id)

        current_state = scope.promotion_state
        if current_state not in _CAN_REJECT_FROM:
            raise ValueError(
                f"Cannot reject promotion from state '{current_state}'. "
                f"Scope must be in 'pending' state."
            )

        now = datetime.now(timezone.utc)
        scope.promotion_state = "rejected"
        scope.promotion_reviewed_by = reviewer_id
        scope.promotion_reviewed_at = now
        scope.updated_at = now

        self._session.flush()

        logger.info(
            "reject_promotion: scope id=%s tenant=%s "
            "reviewed_by=%s — state → rejected",
            scope_id,
            tenant_id,
            reviewer_id,
        )

        return self._scope_to_dict(scope)

    def reset_promotion_state(
        self,
        scope_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> Dict[str, Any]:
        """Reset the promotion state machine to ``'none'``.

        Clears ``promotion_requested_at``, ``promotion_reviewed_by``, and
        ``promotion_reviewed_at``.  Used after force-sync or baseline update.
        Valid from any state.

        Parameters
        ----------
        scope_id:
            PK of the scope row.
        tenant_id:
            Tenant that must own the row.

        Returns
        -------
        dict
            Updated scope as a plain dict.
        """
        scope = self._get_scope_or_raise(scope_id, tenant_id)

        now = datetime.now(timezone.utc)
        scope.promotion_state = "none"
        scope.promotion_requested_at = None
        scope.promotion_reviewed_by = None
        scope.promotion_reviewed_at = None
        scope.updated_at = now

        self._session.flush()

        logger.info(
            "reset_promotion_state: scope id=%s tenant=%s — state → none",
            scope_id,
            tenant_id,
        )

        return self._scope_to_dict(scope)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _record_history_event(
        self,
        artifact_id: str,
        event_type: str,
        actor_id: Optional[str],
        owner_type: str,
        content_hash: Optional[str] = None,
        diff_json: Optional[str] = None,
    ) -> None:
        """Append an ``ArtifactHistoryEvent`` row to the shared history table.

        Uses the local (SQLite-backed) ``ArtifactHistoryEvent`` model from
        ``skillmeat.cache.models``.  The insert is flushed immediately so the
        event is included in the caller's transaction.

        Parameters
        ----------
        artifact_id:
            String FK matching ``artifacts.id`` (``type:name`` format).
        event_type:
            One of the valid event types: ``'promote'``, ``'force_sync'``, etc.
        actor_id:
            Opaque actor identifier (typically a UUID string).  ``None`` for
            system-triggered events.
        owner_type:
            Owner context at the time of the event.
        content_hash:
            Optional SHA-256 content hash at the time of the event.
        diff_json:
            Optional JSON-serialised diff payload.
        """
        from skillmeat.cache.models import ArtifactHistoryEvent

        event = ArtifactHistoryEvent(
            artifact_id=artifact_id,
            event_type=event_type,
            actor_id=actor_id,
            owner_type=owner_type,
            timestamp=datetime.now(timezone.utc),
            content_hash=content_hash,
            diff_json=diff_json,
        )
        self._session.add(event)
        self._session.flush()

        logger.debug(
            "_record_history_event: artifact_id=%s event_type=%s actor=%s",
            artifact_id,
            event_type,
            actor_id,
        )
