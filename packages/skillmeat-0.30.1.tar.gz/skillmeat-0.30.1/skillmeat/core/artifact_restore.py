"""ArtifactRestoreService — restore an artifact to a previous version.

This service implements the write-through restore pattern:
  1. Retrieve target version content (filesystem snapshot or enterprise DB payload).
  2. Write content to the artifact's filesystem path.
  3. Sync the DB cache via ``refresh_single_artifact_cache``.
  4. Append a new ``ArtifactVersion`` row (``change_origin='restore'``).
  5. Append an ``ArtifactHistoryEvent`` row (``event_type='restore'``).

Edition branching
-----------------
* **Local**: The local ``ArtifactVersion`` ORM model does not store raw content.
  Historical content is retrieved by scanning collection snapshots (tarballs
  managed by :class:`~skillmeat.storage.snapshot.SnapshotManager`).  Each
  snapshot captures the full collection state; the service extracts the relevant
  artifact path from the first snapshot whose content hash matches.
* **Enterprise**: ``EnterpriseArtifactVersion.markdown_payload`` stores the
  full content inline.  No snapshot scanning is needed.

Session lifecycle
-----------------
The caller owns the session lifecycle.  When ``db_path`` is provided the
service opens (and closes) its own session.  When ``session`` is provided the
service uses it as-is and **does not** commit or close it — the caller is
responsible.
"""

from __future__ import annotations

import difflib
import json
import logging
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Generator, Optional, TYPE_CHECKING

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

if TYPE_CHECKING:
    from skillmeat.api.schemas.auth import AuthContext

from skillmeat.cache.models import ArtifactHistoryEvent, ArtifactVersion, get_session
from skillmeat.core.version_lineage import build_version_lineage

logger = logging.getLogger(__name__)

__all__ = ["ArtifactRestoreService", "CompositeArtifactRestoreService"]


class ArtifactRestoreService:
    """Restore a single artifact to a previous version.

    Args:
        db_path: Path to the local SQLite database file.  When provided the
            service manages its own session lifecycle (local edition).
        session: Injected SQLAlchemy session.  When provided ``db_path`` is
            ignored and the caller owns the session lifecycle (enterprise
            edition, or tests that supply a session directly).

    Example — local edition::

        svc = ArtifactRestoreService(db_path=Path.home() / ".skillmeat" / "cache.db")
        result = svc.restore_single("skill:my-skill", target_content_hash="abc123...")

    Example — enterprise edition (session injected by FastAPI DI)::

        svc = ArtifactRestoreService(session=db_session)
        result = svc.restore_single("skill:my-skill", target_content_hash="abc123...",
                                    restoring_user="user_xyz")
    """

    def __init__(
        self,
        db_path: Optional[Path] = None,
        session: Optional[Session] = None,
    ) -> None:
        self._db_path = db_path
        self._external_session = session

    # ------------------------------------------------------------------
    # Session helpers
    # ------------------------------------------------------------------

    @contextmanager
    def _get_session(self) -> Generator[Session, None, None]:
        """Yield a database session, managing lifecycle when db_path is set."""
        if self._external_session is not None:
            # Caller owns session — yield as-is, no commit/close
            yield self._external_session
        else:
            session = get_session(self._db_path)
            try:
                yield session
                session.commit()
            except Exception:
                session.rollback()
                raise
            finally:
                session.close()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def restore_single(
        self,
        artifact_id: str,
        target_content_hash: str,
        restoring_user: Optional[str] = None,
        db_session: Optional[Session] = None,
    ) -> Dict[str, Any]:
        """Restore a single artifact to the state captured by *target_content_hash*.

        The write-through sequence is:
        1. Retrieve the target version content.
        2. Write content to the artifact's filesystem path.
        3. Sync the DB cache (``refresh_single_artifact_cache``).
        4. Insert a new ``ArtifactVersion`` row (``change_origin='restore'``).
        5. Insert an ``ArtifactHistoryEvent`` row (``event_type='restore'``).

        Idempotency: if ``target_content_hash`` matches the artifact's current
        head version an ``IntegrityError`` on the UNIQUE constraint is caught
        and the method returns successfully without modifying anything.

        Args:
            artifact_id: Artifact identifier in ``type:name`` format
                (e.g. ``"skill:my-skill"``).
            target_content_hash: SHA-256 content hash of the version to restore.
            restoring_user: Optional opaque user identifier recorded in the
                history event and version metadata.
            db_session: Optional session override.  When provided it takes
                precedence over the session configured in ``__init__``.

        Returns:
            Dictionary with keys:
            - ``artifact_id`` (str)
            - ``restored_hash`` (str) — hash that was written
            - ``previous_hash`` (str | None) — hash that was current before restore
            - ``success`` (bool)
            - ``message`` (str)

        Raises:
            ValueError: If ``artifact_id`` format is invalid, the artifact is
                not found on the filesystem, or the target version content
                cannot be retrieved.
        """
        if ":" not in artifact_id:
            raise ValueError(
                f"Invalid artifact_id format '{artifact_id}': expected 'type:name'."
            )

        artifact_type_str, artifact_name = artifact_id.split(":", 1)

        # Use override session when provided
        effective_session = db_session or self._external_session

        if effective_session is not None:
            return self._restore_with_session(
                session=effective_session,
                artifact_id=artifact_id,
                artifact_type_str=artifact_type_str,
                artifact_name=artifact_name,
                target_content_hash=target_content_hash,
                restoring_user=restoring_user,
            )

        with self._get_session() as session:
            return self._restore_with_session(
                session=session,
                artifact_id=artifact_id,
                artifact_type_str=artifact_type_str,
                artifact_name=artifact_name,
                target_content_hash=target_content_hash,
                restoring_user=restoring_user,
            )

    def get_restore_preview(
        self,
        artifact_id: str,
        target_content_hash: str,
        db_session: Optional[Session] = None,
    ) -> Dict[str, Any]:
        """Preview the diff between current content and a previous version.

        This method has **no side effects**: it does not write to the filesystem
        or the database.

        Args:
            artifact_id: Artifact identifier in ``type:name`` format.
            target_content_hash: SHA-256 hash of the version to preview.
            db_session: Optional session override.

        Returns:
            Dictionary with keys:
            - ``artifact_id`` (str)
            - ``target_hash`` (str)
            - ``current_hash`` (str | None)
            - ``diff`` (str) — unified diff string (empty string if identical)
            - ``lines_added`` (int)
            - ``lines_removed`` (int)
            - ``is_binary`` (bool)

        Raises:
            ValueError: If ``artifact_id`` format is invalid or the target
                version content cannot be retrieved.
        """
        if ":" not in artifact_id:
            raise ValueError(
                f"Invalid artifact_id format '{artifact_id}': expected 'type:name'."
            )

        artifact_type_str, artifact_name = artifact_id.split(":", 1)

        effective_session = db_session or self._external_session

        if effective_session is not None:
            return self._preview_with_session(
                session=effective_session,
                artifact_id=artifact_id,
                artifact_type_str=artifact_type_str,
                artifact_name=artifact_name,
                target_content_hash=target_content_hash,
            )

        with self._get_session() as session:
            return self._preview_with_session(
                session=session,
                artifact_id=artifact_id,
                artifact_type_str=artifact_type_str,
                artifact_name=artifact_name,
                target_content_hash=target_content_hash,
            )

    # ------------------------------------------------------------------
    # Internal restore implementation
    # ------------------------------------------------------------------

    def _restore_with_session(
        self,
        session: Session,
        artifact_id: str,
        artifact_type_str: str,
        artifact_name: str,
        target_content_hash: str,
        restoring_user: Optional[str],
    ) -> Dict[str, Any]:
        """Core restore logic executed within a live session."""
        # 1. Resolve the artifact's filesystem path.
        artifact_path = self._resolve_artifact_path(
            session, artifact_id, artifact_type_str, artifact_name
        )

        # 2. Capture previous head hash (best-effort, None if path missing).
        previous_hash: Optional[str] = None
        if artifact_path is not None and artifact_path.exists():
            try:
                from skillmeat.core.services.content_hash import compute_content_hash

                previous_hash = compute_content_hash(
                    artifact_path.read_text(encoding="utf-8")
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Could not compute current content hash for %s: %s",
                    artifact_id,
                    exc,
                )

        # 3. Retrieve target version content.
        target_content = self._retrieve_version_content(
            session=session,
            artifact_id=artifact_id,
            artifact_path=artifact_path,
            target_content_hash=target_content_hash,
        )
        if target_content is None:
            raise ValueError(
                f"Cannot retrieve content for hash '{target_content_hash}' "
                f"(artifact: {artifact_id}).  Ensure a snapshot containing "
                "this version exists."
            )

        # 4. Write content to filesystem.
        if artifact_path is None:
            raise ValueError(
                f"Artifact '{artifact_id}' has no resolvable filesystem path. "
                "Cannot write restored content."
            )
        self._write_artifact_content(artifact_path, target_content)
        logger.info(
            "Restored artifact %s to hash %s (previous: %s)",
            artifact_id,
            target_content_hash[:12],
            (previous_hash or "")[:12] or "<none>",
        )

        # 5. Sync DB cache (write-through).
        self._sync_cache(session, artifact_id)

        # 6. Insert ArtifactVersion row — idempotent on UNIQUE content_hash.
        metadata_payload = {
            "source_hash": target_content_hash,
            "restoring_user": restoring_user,
        }
        self._insert_artifact_version(
            session=session,
            artifact_id=artifact_id,
            content_hash=target_content_hash,
            parent_hash=previous_hash,
            metadata_payload=metadata_payload,
        )

        # 7. Insert ArtifactHistoryEvent row.
        self._insert_history_event(
            session=session,
            artifact_id=artifact_id,
            content_hash=target_content_hash,
            actor_id=restoring_user,
        )

        return {
            "artifact_id": artifact_id,
            "restored_hash": target_content_hash,
            "previous_hash": previous_hash,
            "success": True,
            "message": (
                f"Artifact '{artifact_id}' successfully restored to "
                f"version {target_content_hash[:12]}."
            ),
        }

    # ------------------------------------------------------------------
    # Internal preview implementation
    # ------------------------------------------------------------------

    def _preview_with_session(
        self,
        session: Session,
        artifact_id: str,
        artifact_type_str: str,
        artifact_name: str,
        target_content_hash: str,
    ) -> Dict[str, Any]:
        """Core preview logic — read-only, no side effects."""
        # Resolve artifact filesystem path (may be None for enterprise).
        artifact_path = self._resolve_artifact_path(
            session, artifact_id, artifact_type_str, artifact_name
        )

        # Read current head content.
        current_content: Optional[str] = None
        current_hash: Optional[str] = None
        if artifact_path is not None and artifact_path.exists():
            try:
                current_content = self._read_path_content(artifact_path)
                if artifact_path.is_dir():
                    from skillmeat.core.hashing import compute_artifact_hash

                    current_hash = compute_artifact_hash(str(artifact_path))
                else:
                    from skillmeat.core.services.content_hash import (
                        compute_content_hash,
                    )

                    current_hash = compute_content_hash(current_content)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Could not read current content for %s: %s", artifact_id, exc
                )

        # Retrieve target version content.
        target_content = self._retrieve_version_content(
            session=session,
            artifact_id=artifact_id,
            artifact_path=artifact_path,
            target_content_hash=target_content_hash,
        )
        if target_content is None:
            raise ValueError(
                f"Cannot retrieve content for hash '{target_content_hash}' "
                f"(artifact: {artifact_id})."
            )

        # Detect binary content.
        is_binary = self._is_binary(target_content)

        if is_binary:
            return {
                "artifact_id": artifact_id,
                "target_hash": target_content_hash,
                "current_hash": current_hash,
                "diff": "",
                "lines_added": 0,
                "lines_removed": 0,
                "is_binary": True,
            }

        # Generate unified diff.
        current_lines = (current_content or "").splitlines(keepends=True)
        target_lines = target_content.splitlines(keepends=True)

        raw_diff = list(
            difflib.unified_diff(
                current_lines,
                target_lines,
                fromfile=f"a/{artifact_id}",
                tofile=f"b/{artifact_id}",
                lineterm="",
            )
        )
        diff_str = "\n".join(raw_diff)

        lines_added = sum(
            1
            for line in raw_diff
            if line.startswith("+") and not line.startswith("+++")
        )
        lines_removed = sum(
            1
            for line in raw_diff
            if line.startswith("-") and not line.startswith("---")
        )

        return {
            "artifact_id": artifact_id,
            "target_hash": target_content_hash,
            "current_hash": current_hash,
            "diff": diff_str,
            "lines_added": lines_added,
            "lines_removed": lines_removed,
            "is_binary": False,
        }

    # ------------------------------------------------------------------
    # Content retrieval helpers
    # ------------------------------------------------------------------

    def _retrieve_version_content(
        self,
        session: Session,
        artifact_id: str,
        artifact_path: Optional[Path],
        target_content_hash: str,
    ) -> Optional[str]:
        """Return artifact content for *target_content_hash*.

        Strategy:
        1. Try enterprise ``EnterpriseArtifactVersion.markdown_payload`` first.
           This works for both enterprise and local editions if such a row exists.
        2. For local edition: scan collection snapshots via ``SnapshotManager``,
           extract to a temp directory, and read the artifact file.
        3. Fall back to reading the current filesystem file if its hash matches
           (handles the common "restore to current" no-op case gracefully).

        Args:
            session: SQLAlchemy session for database operations
            artifact_id: Identifier of the artifact in 'type:name' format
            artifact_path: Optional filesystem path to the artifact
            target_content_hash: SHA-256 hash of the target version content

        Returns:
            The content string if found, None if not retrievable
        """
        # --- Enterprise path: inline markdown_payload ---
        enterprise_content = self._get_enterprise_content(
            session, artifact_id, target_content_hash
        )
        if enterprise_content is not None:
            return enterprise_content

        # --- Local path: inline content_payload ---
        try:
            from skillmeat.cache.models import ArtifactVersion as AV

            payload_row = (
                session.query(AV.content_payload)
                .filter(
                    AV.artifact_id == artifact_id,
                    AV.content_hash == target_content_hash,
                    AV.content_payload.isnot(None),
                )
                .first()
            )
            if payload_row is not None and isinstance(payload_row[0], str):
                return payload_row[0]
        except Exception:  # noqa: BLE001
            pass

        # --- Local path: current file short-circuit ---
        if artifact_path is not None and artifact_path.exists():
            try:
                current_text = self._read_path_content(artifact_path)
                if artifact_path.is_dir():
                    from skillmeat.core.hashing import compute_artifact_hash

                    current_hash = compute_artifact_hash(str(artifact_path))
                else:
                    from skillmeat.core.services.content_hash import (
                        compute_content_hash,
                    )

                    current_hash = compute_content_hash(current_text)
                if current_hash == target_content_hash:
                    return current_text
            except Exception:  # noqa: BLE001
                pass

        # --- Local path: snapshot scan ---
        return self._get_content_from_snapshot(
            artifact_id=artifact_id,
            artifact_path=artifact_path,
            target_content_hash=target_content_hash,
        )

    @staticmethod
    def _read_path_content(path: "Path") -> str:
        """Read content from a file or directory artifact path.

        For single files, returns the file text.
        For directories, returns a concatenated representation of all text files
        sorted by relative POSIX path, suitable for text-based diffing.
        """
        if path.is_file():
            return path.read_text(encoding="utf-8")

        if not path.is_dir():
            raise FileNotFoundError(f"Path not found: {path}")

        parts = []
        files = sorted(
            (f for f in path.rglob("*") if f.is_file()),
            key=lambda f: f.relative_to(path).as_posix(),
        )
        for f in files:
            rel = f.relative_to(path).as_posix()
            try:
                text = f.read_text(encoding="utf-8")
                parts.append(f"--- {rel} ---\n{text}")
            except (UnicodeDecodeError, OSError):
                parts.append(f"--- {rel} ---\n[binary file]")
        return "\n".join(parts)

    def _get_enterprise_content(
        self,
        session: Session,
        artifact_id: str,
        target_content_hash: str,
    ) -> Optional[str]:
        """Query ``EnterpriseArtifactVersion.markdown_payload`` by content hash.

        Returns ``None`` if the enterprise models are not available or no
        matching row exists.
        """
        try:
            from skillmeat.cache.models_enterprise import EnterpriseArtifactVersion
            from sqlalchemy import select

            stmt = select(EnterpriseArtifactVersion).where(
                EnterpriseArtifactVersion.content_hash == target_content_hash
            )
            row = session.execute(stmt).scalar_one_or_none()
            if row is not None and row.markdown_payload is not None:
                return row.markdown_payload
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "Enterprise version lookup failed (expected for local edition): %s",
                exc,
            )
        return None

    def _get_content_from_snapshot(
        self,
        artifact_id: str,
        artifact_path: Optional[Path],
        target_content_hash: str,
    ) -> Optional[str]:
        """Scan collection snapshots for an artifact file matching *target_content_hash*.

        Extracts each snapshot (newest first) into a temporary directory and
        checks whether the artifact file at *artifact_path* (relative to the
        collection root) has the expected hash.

        Returns the file content string on match, or ``None`` if no snapshot
        contains a matching version.
        """
        if artifact_path is None:
            logger.debug(
                "No artifact_path — cannot scan snapshots for hash %s",
                target_content_hash[:12],
            )
            return None

        try:
            from skillmeat.core.services.content_hash import compute_content_hash
            from skillmeat.core.collection import CollectionManager
            from skillmeat.storage.snapshot import SnapshotManager

            coll_mgr = CollectionManager()
            collection_name = coll_mgr.get_active_collection_name()
            snapshots_dir = coll_mgr.config.get_snapshots_dir()
            snap_mgr = SnapshotManager(snapshots_dir)

            # Determine the artifact's path relative to the collection root.
            collection_path = coll_mgr.config.get_collection_path(collection_name)
            try:
                rel_artifact_path = artifact_path.relative_to(collection_path)
            except ValueError:
                logger.warning(
                    "artifact_path %s is not under collection root %s — "
                    "cannot scan snapshots.",
                    artifact_path,
                    collection_path,
                )
                return None

            # Iterate snapshots newest-first.
            cursor = None
            while True:
                snapshots, next_cursor = snap_mgr.list_snapshots(
                    collection_name, limit=20, cursor=cursor
                )
                for snapshot in snapshots:
                    content = self._read_artifact_from_snapshot(
                        snap_mgr=snap_mgr,
                        snapshot=snapshot,
                        rel_artifact_path=rel_artifact_path,
                        target_content_hash=target_content_hash,
                        compute_fn=compute_content_hash,
                    )
                    if content is not None:
                        return content
                if next_cursor is None:
                    break
                cursor = next_cursor

        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Snapshot scan failed for artifact %s hash %s: %s",
                artifact_id,
                target_content_hash[:12],
                exc,
            )
        return None

    def _read_artifact_from_snapshot(
        self,
        snap_mgr,
        snapshot,
        rel_artifact_path: Path,
        target_content_hash: str,
        compute_fn,
    ) -> Optional[str]:
        """Extract *snapshot* to a temp dir and return artifact content if hash matches."""
        try:
            with tempfile.TemporaryDirectory() as tmp_dir:
                tmp_path = Path(tmp_dir) / "collection"
                tmp_path.mkdir()
                snap_mgr.restore_snapshot(snapshot, tmp_path)

                candidate = tmp_path / rel_artifact_path
                if not candidate.exists():
                    return None

                text = self._read_path_content(candidate)
                if candidate.is_dir():
                    from skillmeat.core.hashing import compute_artifact_hash

                    candidate_hash = compute_artifact_hash(str(candidate))
                else:
                    candidate_hash = compute_fn(text)
                if candidate_hash == target_content_hash:
                    return text
        except Exception as exc:  # noqa: BLE001
            logger.debug("Could not read snapshot %s: %s", snapshot.id, exc)
        return None

    # ------------------------------------------------------------------
    # Artifact path resolution
    # ------------------------------------------------------------------

    def _resolve_artifact_path(
        self,
        session: Session,
        artifact_id: str,
        artifact_type_str: str,
        artifact_name: str,
    ) -> Optional[Path]:
        """Return the full filesystem path for the artifact.

        Attempts to locate the artifact via ``ArtifactManager`` (local
        edition).  For enterprise deployments where no local filesystem is
        available this may return ``None`` — callers must handle that case.
        """
        try:
            from skillmeat.core.artifact import ArtifactManager

            artifact_mgr = ArtifactManager()
            artifact = artifact_mgr.show(artifact_name)

            coll_mgr = artifact_mgr.collection_mgr
            collection_name = coll_mgr.get_active_collection_name()
            collection_path = coll_mgr.config.get_collection_path(collection_name)
            return collection_path / artifact.path
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "Could not resolve filesystem path for %s: %s", artifact_id, exc
            )
        return None

    # ------------------------------------------------------------------
    # Filesystem write
    # ------------------------------------------------------------------

    def _write_artifact_content(self, artifact_path: Path, content: str) -> None:
        """Overwrite the artifact file with *content* atomically via a temp file."""
        artifact_path.parent.mkdir(parents=True, exist_ok=True)

        # Write to a sibling temp file and atomically replace.
        tmp_path = artifact_path.with_suffix(artifact_path.suffix + ".restore_tmp")
        try:
            tmp_path.write_text(content, encoding="utf-8")
            tmp_path.replace(artifact_path)
        except Exception:
            if tmp_path.exists():
                tmp_path.unlink(missing_ok=True)
            raise

    # ------------------------------------------------------------------
    # Cache sync
    # ------------------------------------------------------------------

    def _sync_cache(self, session: Session, artifact_id: str) -> None:
        """Call ``refresh_single_artifact_cache`` to sync the DB cache.

        Failures are logged as warnings — the restore is still considered
        successful even if the cache refresh fails, because the filesystem
        write has already completed.
        """
        try:
            from skillmeat.api.services.artifact_cache_service import (
                refresh_single_artifact_cache,
            )
            from skillmeat.core.artifact import ArtifactManager

            artifact_mgr = ArtifactManager()
            refresh_single_artifact_cache(
                session=session,
                artifact_mgr=artifact_mgr,
                artifact_id=artifact_id,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Cache refresh failed for %s after restore: %s", artifact_id, exc
            )

    # ------------------------------------------------------------------
    # ORM row helpers
    # ------------------------------------------------------------------

    def _insert_artifact_version(
        self,
        session: Session,
        artifact_id: str,
        content_hash: str,
        parent_hash: Optional[str],
        metadata_payload: Dict[str, Any],
    ) -> None:
        """Insert an ``ArtifactVersion`` row for the restore operation.

        Idempotent: if the UNIQUE constraint on ``content_hash`` fires (the
        same content is already the head version), the ``IntegrityError`` is
        caught and logged — no exception is raised to the caller.
        """
        lineage = build_version_lineage(
            session=session,
            parent_hash=parent_hash,
            current_hash=content_hash,
        )

        version_row = ArtifactVersion(
            artifact_id=artifact_id,
            content_hash=content_hash,
            parent_hash=parent_hash,
            change_origin="restore",
            version_lineage=json.dumps(lineage),
            metadata_json=json.dumps(metadata_payload),
        )
        session.add(version_row)
        try:
            session.flush()
        except IntegrityError:
            session.rollback()
            logger.info(
                "ArtifactVersion for hash %s already exists (idempotent restore).",
                content_hash[:12],
            )

    def _insert_history_event(
        self,
        session: Session,
        artifact_id: str,
        content_hash: str,
        actor_id: Optional[str],
    ) -> None:
        """Append an ``ArtifactHistoryEvent`` row for the restore."""
        event = ArtifactHistoryEvent(
            artifact_id=artifact_id,
            event_type="restore",
            actor_id=actor_id,
            content_hash=content_hash,
        )
        session.add(event)
        try:
            session.flush()
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Could not record history event for %s restore: %s",
                artifact_id,
                exc,
            )

    # ------------------------------------------------------------------
    # Utility helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_binary(content: str) -> bool:
        """Return True if *content* appears to be binary (contains null bytes)."""
        return "\x00" in content


class CompositeArtifactRestoreService:
    """Orchestrate restoring a composite artifact and all its member artifacts atomically.

    Implements all-or-nothing semantics: if any member restore fails, every
    previously restored member is rolled back from the pre-save safety tarball
    (or a temporary copy when ``SnapshotManager`` is unavailable).

    Args:
        restore_service: An existing :class:`ArtifactRestoreService` instance
            used for per-member and composite-parent restores.
        snapshot_manager: Optional :class:`~skillmeat.storage.snapshot.SnapshotManager`
            instance used to create a full-collection safety tarball before any
            writes.  When ``None``, the service falls back to copying affected
            artifact files to a temporary directory.

    Example::

        svc = CompositeArtifactRestoreService(
            restore_service=ArtifactRestoreService(db_path=db_path),
            snapshot_manager=snap_mgr,
        )
        result = svc.restore_with_members(
            composite_artifact_id="composite:my-bundle",
            member_hashes={
                "skill:skill-a": "abc123...",
                "command:cmd-b": "def456...",
            },
            restoring_user="alice",
        )
    """

    def __init__(
        self,
        restore_service: ArtifactRestoreService,
        snapshot_manager=None,
    ) -> None:
        self._restore_service = restore_service
        self._snapshot_manager = snapshot_manager

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def restore_with_members(
        self,
        composite_artifact_id: str,
        member_hashes: Dict[str, str],
        restoring_user: Optional[str] = None,
        db_session: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """Restore a composite artifact and all its member artifacts atomically.

        All member restores succeed or none do.  The composite parent receives
        an ``ArtifactHistoryEvent`` with ``event_type='restore'`` in all cases
        where members succeeded (or is itself restored when a target hash is
        present in *member_hashes* under the composite's own key — though
        composite parent hashes are typically tracked separately from members).

        Args:
            composite_artifact_id: Artifact identifier for the composite parent
                in ``type:name`` format (e.g. ``"composite:my-bundle"``).
            member_hashes: Mapping of ``{member_artifact_id: target_content_hash}``
                for each member to restore.  Keys must use ``type:name`` format.
            restoring_user: Optional opaque user identifier recorded in history
                events and version metadata.
            db_session: Optional SQLAlchemy session override passed through to
                each :meth:`ArtifactRestoreService.restore_single` call.

        Returns:
            Dictionary (``CompositeRestoreResponse``) with keys:

            - ``composite_artifact_id`` (str)
            - ``members_restored`` (list[dict]) — per-member result dicts, each
              containing ``artifact_id``, ``restored_hash``, ``success``.
            - ``total_members`` (int)
            - ``successful_members`` (int)
            - ``failed_members`` (int)
            - ``success`` (bool) — ``True`` only when ALL members succeeded.
            - ``safety_tarball_path`` (str | None) — path to the pre-save backup.
            - ``rolled_back`` (bool) — ``True`` when rollback was triggered.
            - ``message`` (str) — human-readable summary.
        """
        total_members = len(member_hashes)
        logger.info(
            "CompositeArtifactRestoreService: starting restore for %s with %d members",
            composite_artifact_id,
            total_members,
        )

        # 1. Create a pre-save safety backup.
        safety_tarball_path: Optional[str] = None
        temp_backup_dir: Optional[Any] = None  # tempfile.TemporaryDirectory handle

        safety_tarball_path, temp_backup_dir = self._create_safety_backup(
            composite_artifact_id=composite_artifact_id,
            member_artifact_ids=list(member_hashes.keys()),
        )

        # 2. Restore each member, accumulating results.
        members_restored: list = []
        successfully_restored_ids: list = []
        rolled_back = False

        try:
            for member_id, target_hash in member_hashes.items():
                member_result = self._restore_member(
                    member_id=member_id,
                    target_hash=target_hash,
                    restoring_user=restoring_user,
                    db_session=db_session,
                )
                members_restored.append(member_result)

                if member_result["success"]:
                    successfully_restored_ids.append(member_id)
                else:
                    # Failure: roll back all previously restored members.
                    logger.warning(
                        "Member restore failed for %s — triggering rollback for %d "
                        "previously restored members.",
                        member_id,
                        len(successfully_restored_ids),
                    )
                    rolled_back = self._rollback(
                        safety_tarball_path=safety_tarball_path,
                        temp_backup_dir=temp_backup_dir,
                        restored_ids=successfully_restored_ids,
                    )
                    # Mark remaining members as not attempted.
                    remaining = [
                        mid
                        for mid in member_hashes
                        if mid not in {r["artifact_id"] for r in members_restored}
                    ]
                    for remaining_id in remaining:
                        members_restored.append(
                            {
                                "artifact_id": remaining_id,
                                "restored_hash": member_hashes[remaining_id],
                                "success": False,
                            }
                        )
                    break  # Stop processing further members.

            else:
                # All members succeeded — record composite parent event.
                self._record_composite_event(
                    composite_artifact_id=composite_artifact_id,
                    restoring_user=restoring_user,
                    db_session=db_session,
                )

        finally:
            # Clean up the temp backup directory if it was created.
            if temp_backup_dir is not None:
                try:
                    temp_backup_dir.cleanup()
                except Exception as exc:  # noqa: BLE001
                    logger.debug("Could not clean up temp backup dir: %s", exc)

        successful_count = sum(1 for r in members_restored if r["success"])
        failed_count = total_members - successful_count
        all_success = failed_count == 0 and not rolled_back

        if all_success:
            message = (
                f"Composite '{composite_artifact_id}' and all {total_members} "
                "member(s) restored successfully."
            )
        elif rolled_back:
            message = (
                f"Restore failed: {failed_count} member(s) could not be restored. "
                f"Rolled back {successful_count} previously restored member(s)."
            )
        else:
            message = (
                f"Restore partially failed: {successful_count}/{total_members} "
                "member(s) restored."
            )

        return {
            "composite_artifact_id": composite_artifact_id,
            "members_restored": members_restored,
            "total_members": total_members,
            "successful_members": successful_count,
            "failed_members": failed_count,
            "success": all_success,
            "safety_tarball_path": safety_tarball_path,
            "rolled_back": rolled_back,
            "message": message,
        }

    # ------------------------------------------------------------------
    # Safety backup helpers
    # ------------------------------------------------------------------

    def _create_safety_backup(
        self,
        composite_artifact_id: str,
        member_artifact_ids: list,
    ):
        """Create a pre-save safety backup before any writes.

        Attempts to create a full-collection snapshot via ``SnapshotManager``
        (preferred).  Falls back to copying individual artifact files to a
        temporary directory when ``SnapshotManager`` is unavailable.

        Returns:
            Tuple of ``(safety_tarball_path_str_or_None, temp_dir_handle_or_None)``.
            Exactly one of the two will be non-None when a backup was created.
        """
        # --- Preferred path: SnapshotManager full-collection tarball ---
        if self._snapshot_manager is not None:
            try:
                from skillmeat.core.collection import CollectionManager

                coll_mgr = CollectionManager()
                collection_name = coll_mgr.get_active_collection_name()
                collection_path = coll_mgr.config.get_collection_path(collection_name)

                snapshot = self._snapshot_manager.create_snapshot(
                    collection_path=collection_path,
                    collection_name=collection_name,
                    message=(
                        f"Pre-restore safety backup for composite "
                        f"'{composite_artifact_id}' "
                        f"({len(member_artifact_ids)} member(s))"
                    ),
                )
                tarball_str = str(snapshot.tarball_path)
                logger.info(
                    "Safety tarball created at %s (snapshot id: %s)",
                    tarball_str,
                    snapshot.id,
                )
                return tarball_str, None
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "SnapshotManager backup failed (%s) — falling back to "
                    "per-artifact temp copy.",
                    exc,
                )

        # --- Fallback: copy individual artifact files to a temp dir ---
        temp_dir = self._create_temp_backup(
            composite_artifact_id=composite_artifact_id,
            member_artifact_ids=member_artifact_ids,
        )
        return None, temp_dir

    def _create_temp_backup(
        self,
        composite_artifact_id: str,
        member_artifact_ids: list,
    ):
        """Copy current artifact files to a temporary directory.

        Returns a ``tempfile.TemporaryDirectory`` handle (caller must call
        ``.cleanup()`` when done).  Returns ``None`` on failure (logged as
        warning — the restore proceeds without a backup).
        """
        import tempfile
        import shutil

        try:
            tmp = tempfile.TemporaryDirectory(prefix="skillmeat_restore_backup_")
            tmp_path = Path(tmp.name)

            all_ids = [composite_artifact_id] + member_artifact_ids
            for artifact_id in all_ids:
                artifact_path = self._resolve_artifact_path(artifact_id)
                if artifact_path is not None and artifact_path.exists():
                    dest = tmp_path / artifact_path.name
                    if artifact_path.is_dir():
                        shutil.copytree(artifact_path, dest)
                    else:
                        shutil.copy2(artifact_path, dest)

            logger.info(
                "Temp backup created at %s for %d artifact(s).",
                tmp.name,
                len(all_ids),
            )
            return tmp
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Could not create temp backup for composite restore: %s — "
                "proceeding without pre-save backup.",
                exc,
            )
            return None

    # ------------------------------------------------------------------
    # Member restore helper
    # ------------------------------------------------------------------

    def _restore_member(
        self,
        member_id: str,
        target_hash: str,
        restoring_user: Optional[str],
        db_session: Optional[Any],
    ) -> Dict[str, Any]:
        """Delegate a single member restore to ``ArtifactRestoreService``.

        Catches all exceptions so that the caller can accumulate results and
        decide on rollback without an unhandled exception propagating.

        Returns:
            Dict with ``artifact_id``, ``restored_hash``, ``success``, and
            optionally ``error``.
        """
        try:
            result = self._restore_service.restore_single(
                artifact_id=member_id,
                target_content_hash=target_hash,
                restoring_user=restoring_user,
                db_session=db_session,
            )
            logger.debug(
                "Member %s restored to hash %s.",
                member_id,
                target_hash[:12],
            )
            return {
                "artifact_id": member_id,
                "restored_hash": target_hash,
                "success": result.get("success", False),
            }
        except Exception as exc:  # noqa: BLE001
            logger.error(
                "Failed to restore member %s to hash %s: %s",
                member_id,
                target_hash[:12],
                exc,
            )
            return {
                "artifact_id": member_id,
                "restored_hash": target_hash,
                "success": False,
                "error": str(exc),
            }

    # ------------------------------------------------------------------
    # Rollback helpers
    # ------------------------------------------------------------------

    def _rollback(
        self,
        safety_tarball_path: Optional[str],
        temp_backup_dir: Optional[Any],
        restored_ids: list,
    ) -> bool:
        """Attempt to roll back all members that were already restored.

        Prefers the safety tarball (full-collection restore) when available.
        Falls back to overwriting individual files from the temp backup dir.

        Returns:
            ``True`` if rollback was attempted (regardless of full success),
            ``False`` if no backup was available to roll back from.
        """
        if safety_tarball_path is not None:
            return self._rollback_from_tarball(safety_tarball_path)

        if temp_backup_dir is not None:
            return self._rollback_from_temp(
                temp_backup_dir=temp_backup_dir,
                restored_ids=restored_ids,
            )

        logger.error(
            "No safety backup available — cannot roll back %d restored member(s). "
            "Manual recovery may be required.",
            len(restored_ids),
        )
        return False

    def _rollback_from_tarball(self, safety_tarball_path: str) -> bool:
        """Restore the full collection from the safety tarball snapshot.

        Locates the snapshot via ``SnapshotManager`` and calls
        ``restore_snapshot`` on the active collection path.

        Returns ``True`` on success, ``False`` on failure.
        """
        if self._snapshot_manager is None:
            logger.error(
                "Rollback from tarball requested but SnapshotManager is not set."
            )
            return False

        try:
            from skillmeat.core.collection import CollectionManager

            coll_mgr = CollectionManager()
            collection_name = coll_mgr.get_active_collection_name()
            collection_path = coll_mgr.config.get_collection_path(collection_name)

            # Find the snapshot matching the tarball path.
            tarball_path_obj = Path(safety_tarball_path)
            snapshot_id = tarball_path_obj.stem.replace(".tar", "")

            snapshot = self._snapshot_manager.get_snapshot(snapshot_id, collection_name)
            if snapshot is None:
                logger.error(
                    "Could not locate snapshot '%s' in SnapshotManager for rollback.",
                    snapshot_id,
                )
                return False

            self._snapshot_manager.restore_snapshot(snapshot, collection_path)
            logger.info(
                "Rollback complete: collection restored from snapshot '%s'.",
                snapshot_id,
            )
            return True
        except Exception as exc:  # noqa: BLE001
            logger.error("Rollback from tarball failed: %s", exc)
            return False

    def _rollback_from_temp(
        self,
        temp_backup_dir: Any,
        restored_ids: list,
    ) -> bool:
        """Restore individual artifact files from the temporary backup directory.

        Returns ``True`` if at least one file was rolled back, ``False``
        if no files could be found to restore.
        """
        import shutil

        tmp_path = Path(temp_backup_dir.name)
        any_restored = False

        for artifact_id in restored_ids:
            try:
                artifact_path = self._resolve_artifact_path(artifact_id)
                if artifact_path is None:
                    logger.warning(
                        "Cannot resolve path for %s during rollback — skipping.",
                        artifact_id,
                    )
                    continue

                backup_candidate = tmp_path / artifact_path.name
                if not backup_candidate.exists():
                    logger.warning(
                        "No backup found for %s in temp dir — skipping rollback for "
                        "this member.",
                        artifact_id,
                    )
                    continue

                if backup_candidate.is_dir():
                    if artifact_path.exists():
                        shutil.rmtree(artifact_path)
                    shutil.copytree(backup_candidate, artifact_path)
                else:
                    shutil.copy2(backup_candidate, artifact_path)

                logger.info("Rolled back %s from temp backup.", artifact_id)
                any_restored = True
            except Exception as exc:  # noqa: BLE001
                logger.error("Could not roll back %s: %s", artifact_id, exc)

        return any_restored

    # ------------------------------------------------------------------
    # Composite parent event
    # ------------------------------------------------------------------

    def _record_composite_event(
        self,
        composite_artifact_id: str,
        restoring_user: Optional[str],
        db_session: Optional[Any],
    ) -> None:
        """Append an ``ArtifactHistoryEvent`` for the composite parent.

        This records that a composite restore operation completed successfully,
        without necessarily rewriting the composite's own filesystem content
        (composite manifests may update themselves automatically as a result
        of member restores, or may be managed separately).
        """
        try:
            from skillmeat.cache.models import ArtifactHistoryEvent

            event = ArtifactHistoryEvent(
                artifact_id=composite_artifact_id,
                event_type="restore",
                actor_id=restoring_user,
                content_hash=None,
            )

            if db_session is not None:
                db_session.add(event)
                try:
                    db_session.flush()
                except Exception as exc:  # noqa: BLE001
                    logger.warning(
                        "Could not flush composite history event for %s: %s",
                        composite_artifact_id,
                        exc,
                    )
            else:
                # Use restore_service's session context.
                with self._restore_service._get_session() as session:
                    session.add(event)
                    try:
                        session.flush()
                    except Exception as exc:  # noqa: BLE001
                        logger.warning(
                            "Could not record composite history event for %s: %s",
                            composite_artifact_id,
                            exc,
                        )

            logger.info(
                "Recorded composite restore event for %s.", composite_artifact_id
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Failed to record composite history event for %s: %s",
                composite_artifact_id,
                exc,
            )

    # ------------------------------------------------------------------
    # Path resolution (lightweight wrapper)
    # ------------------------------------------------------------------

    def _resolve_artifact_path(self, artifact_id: str) -> Optional[Path]:
        """Return the filesystem path for *artifact_id* via ArtifactManager.

        Delegates to the underlying restore service's path-resolution logic.
        Returns ``None`` if the path cannot be determined.
        """
        if ":" not in artifact_id:
            return None

        artifact_type_str, artifact_name = artifact_id.split(":", 1)

        try:
            # Reuse the restore service's own helper by calling it with a
            # throw-away session obtained from its context manager.
            with self._restore_service._get_session() as session:
                return self._restore_service._resolve_artifact_path(
                    session=session,
                    artifact_id=artifact_id,
                    artifact_type_str=artifact_type_str,
                    artifact_name=artifact_name,
                )
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "Could not resolve path for %s in CompositeArtifactRestoreService: %s",
                artifact_id,
                exc,
            )
            return None
