"""FQAN Resolver Service for DVCS Phase 3.

Resolves Fully Qualified Artifact Names (FQANs) to concrete :class:`Artifact`
ORM rows using the 4-tier collection inheritance hierarchy.

Resolution order (bare-name walk):
    project > dev > team > enterprise > marketplace

For explicit FQANs (``scope://namespace/name@version``), the resolver queries
the specified tier directly without a tier walk.

Marketplace is NOT a governance tier — it is the external trust root and
lowest-priority fallback for bare-name resolution.

Ambiguity policies:
    ``warn-and-return-closest`` (default):
        Return the closest-tier match (lowest index in the tier walk).
        Log a warning when more than one tier has a candidate.
    ``error``:
        Raise :exc:`AmbiguousFQANError` when more than one tier has a candidate.
    ``return-all``:
        Return every candidate found during the tier walk in ``candidates``
        and set ``artifact`` to the closest-tier match.

Single-team-per-request (v1):
    Every resolution call is scoped to at most one ``team_namespace``.
    The ``team`` tier step only matches artifacts whose ``namespace`` column
    equals ``team_namespace``.  When ``team_namespace`` is ``None``, the
    ``team`` step is skipped entirely.

Public API
----------
- :class:`FQANResolver` — main resolver class.
- :class:`ResolveResult` — result dataclass returned by :meth:`FQANResolver.resolve`.
- :exc:`AmbiguousFQANError` — raised by the ``error`` ambiguity policy.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import List, Optional

from sqlalchemy.orm import Session

from skillmeat.cache.fqan_utils import parse_fqan, ParsedFQAN
from skillmeat.cache.models import Artifact
from skillmeat.core.enums import CollectionTier

__all__ = [
    "AmbiguousFQANError",
    "FQANResolver",
    "ResolveResult",
]

logger = logging.getLogger(__name__)

# -------------------------------------------------------------------------
# Tier walk order: highest-priority (project-local) first
# -------------------------------------------------------------------------
_TIER_WALK: List[str] = [
    CollectionTier.project.value,
    CollectionTier.dev.value,
    CollectionTier.team.value,
    CollectionTier.enterprise.value,
    CollectionTier.marketplace.value,
]

# Valid ambiguity policy strings
_VALID_AMBIGUITY_POLICIES = frozenset(
    {"warn-and-return-closest", "error", "return-all"}
)


# -------------------------------------------------------------------------
# Exceptions
# -------------------------------------------------------------------------


class AmbiguousFQANError(Exception):
    """Raised when the ``error`` ambiguity policy is active and multiple
    tiers contain candidates for the same bare name.

    Attributes:
        reference: The bare name or FQAN that was being resolved.
        candidates: All :class:`Artifact` rows found across tiers.
    """

    def __init__(self, reference: str, candidates: List[Artifact]) -> None:
        self.reference = reference
        self.candidates = candidates
        tier_summary = ", ".join(
            f"{a.collection_tier}:{a.namespace}/{a.name}" for a in candidates
        )
        super().__init__(
            f"Ambiguous reference {reference!r}: found candidates in multiple "
            f"tiers — {tier_summary}. "
            "Use an explicit FQAN (scope://namespace/name@version) to disambiguate."
        )


# -------------------------------------------------------------------------
# Result dataclass
# -------------------------------------------------------------------------


@dataclass
class ResolveResult:
    """Result of a :meth:`FQANResolver.resolve` call.

    Attributes:
        artifact: Primary resolved artifact (closest tier, or ``None`` when
            no match is found).
        candidates: All candidates discovered across all tiers that were
            checked during resolution.  For explicit FQANs this list contains
            at most one entry.
        tier_walk: Ordered list of tier names checked during resolution (in
            the order they were queried).
        ambiguity_warning: Human-readable warning message when multiple tiers
            have candidates and the ``warn-and-return-closest`` policy is
            active.  ``None`` otherwise.
    """

    artifact: Optional[Artifact]
    candidates: List[Artifact] = field(default_factory=list)
    tier_walk: List[str] = field(default_factory=list)
    ambiguity_warning: Optional[str] = None


# -------------------------------------------------------------------------
# FQANResolver
# -------------------------------------------------------------------------


class FQANResolver:
    """Resolves FQANs and bare artifact names using the 4-tier hierarchy.

    Args:
        session: A SQLAlchemy ``Session`` (local edition — uses
            ``session.query()`` style per codebase conventions).

    Example:
        >>> resolver = FQANResolver(session)
        >>> result = resolver.resolve("canvas", project_id="proj-abc")
        >>> result.artifact  # closest-tier match, or None
        >>> result.candidates  # all matches found
        >>> result.tier_walk  # tiers that were checked
    """

    def __init__(self, session: Session) -> None:
        self.session = session

    # ------------------------------------------------------------------
    # Primary public API
    # ------------------------------------------------------------------

    def resolve(
        self,
        reference: str,
        project_id: Optional[str] = None,
        team_namespace: Optional[str] = None,
        ambiguity_policy: str = "warn-and-return-closest",
    ) -> ResolveResult:
        """Resolve a reference (bare name or FQAN) to artifact(s).

        When *reference* contains ``://`` it is treated as an explicit FQAN
        and delegated to :meth:`resolve_fqan`.  Otherwise a tier walk is
        performed.

        Args:
            reference: A bare artifact name (e.g. ``"canvas"``) or a full
                FQAN (e.g. ``"team://platform-eng/canvas@v1.2"``).
            project_id: Optional project identifier; when supplied, the
                ``project`` tier step is restricted to artifacts whose
                ``project_id`` matches.
            team_namespace: Namespace for the ``team`` tier step.  When
                ``None`` the ``team`` tier is skipped.
            ambiguity_policy: One of ``"warn-and-return-closest"``,
                ``"error"``, or ``"return-all"``.  Controls behaviour when
                more than one tier has a matching artifact.

        Returns:
            A :class:`ResolveResult` with ``artifact``, ``candidates``,
            ``tier_walk``, and ``ambiguity_warning`` populated.

        Raises:
            ValueError: If *ambiguity_policy* is not a recognised value.
            AmbiguousFQANError: If *ambiguity_policy* is ``"error"`` and
                multiple tiers have candidates.
            ValueError: If *reference* looks like an FQAN but is malformed.
        """
        if ambiguity_policy not in _VALID_AMBIGUITY_POLICIES:
            raise ValueError(
                f"Invalid ambiguity_policy {ambiguity_policy!r}. "
                f"Must be one of: {sorted(_VALID_AMBIGUITY_POLICIES)}."
            )

        # Explicit FQAN path (contains "://")
        if "://" in reference:
            artifact = self._resolve_explicit_fqan(reference)
            return ResolveResult(
                artifact=artifact,
                candidates=[artifact] if artifact is not None else [],
                tier_walk=[_parse_scope_from_fqan(reference)],
                ambiguity_warning=None,
            )

        # Bare-name tier walk
        return self._tier_walk(
            name=reference,
            project_id=project_id,
            team_namespace=team_namespace,
            ambiguity_policy=ambiguity_policy,
        )

    def resolve_fqan(self, fqan: str) -> Optional[Artifact]:
        """Resolve an explicit FQAN to a single :class:`Artifact` row.

        Args:
            fqan: A fully qualified artifact name, e.g.
                ``"team://platform-eng/canvas@v1.2"``.

        Returns:
            The matching :class:`Artifact`, or ``None`` when not found.

        Raises:
            ValueError: If *fqan* is malformed (delegated from
                :func:`~skillmeat.cache.fqan_utils.parse_fqan`).
        """
        return self._resolve_explicit_fqan(fqan)

    def list_by_tier(
        self,
        tier: str,
        namespace: Optional[str] = None,
    ) -> List[Artifact]:
        """List all artifacts at a given tier, optionally filtered by namespace.

        Args:
            tier: Collection tier value (e.g. ``"team"``).  Accepts the
                ``"local"`` alias (normalised to ``"project"`` before querying).
            namespace: When provided, only return artifacts whose ``namespace``
                column matches this value.

        Returns:
            List of matching :class:`Artifact` rows (empty list when none
            found).

        Raises:
            ValueError: If *tier* is not a recognised :class:`CollectionTier`
                value (or the ``"local"`` alias).
        """
        # Normalise "local" alias
        normalised_tier = "project" if tier == "local" else tier
        _validate_tier(normalised_tier)

        query = self.session.query(Artifact).filter(
            Artifact.collection_tier == normalised_tier
        )
        if namespace is not None:
            query = query.filter(Artifact.namespace == namespace)
        return query.all()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_explicit_fqan(self, fqan: str) -> Optional[Artifact]:
        """Parse *fqan* and query the DB for a direct match.

        If *fqan* includes a version, it is matched against
        ``deployed_version``.  This allows callers to specify an exact
        pinned version.

        Returns:
            Matching :class:`Artifact` row, or ``None``.
        """
        parsed: ParsedFQAN = parse_fqan(fqan)  # raises ValueError on bad input

        query = self.session.query(Artifact).filter(
            Artifact.collection_tier == parsed.scope,
            Artifact.namespace == parsed.namespace,
            Artifact.name == parsed.name,
        )
        if parsed.version and parsed.version not in ("latest",):
            query = query.filter(Artifact.deployed_version == parsed.version)

        return query.first()

    def _tier_walk(
        self,
        name: str,
        project_id: Optional[str],
        team_namespace: Optional[str],
        ambiguity_policy: str,
    ) -> ResolveResult:
        """Walk the tier hierarchy from project → marketplace looking for *name*.

        Stops at the first tier that produces a match (for
        ``warn-and-return-closest`` and ``error`` policies).  For
        ``return-all``, continues through all tiers.

        Returns:
            :class:`ResolveResult` with the primary artifact and all
            candidates found.
        """
        tiers_checked: List[str] = []
        all_candidates: List[Artifact] = []
        # Track which tiers had at least one hit
        tier_hits: List[str] = []

        for tier in _TIER_WALK:
            # The team tier requires a team_namespace; skip if not provided
            if tier == CollectionTier.team.value and team_namespace is None:
                continue

            tiers_checked.append(tier)
            candidates = self._query_tier(
                tier=tier,
                name=name,
                project_id=project_id if tier == CollectionTier.project.value else None,
                namespace=team_namespace if tier == CollectionTier.team.value else None,
            )

            if candidates:
                tier_hits.append(tier)
                all_candidates.extend(candidates)

                # For warn-and-return-closest / error: stop after first hit tier
                if ambiguity_policy in ("warn-and-return-closest", "error"):
                    # Keep walking to detect ambiguity across *remaining* tiers
                    # only if we have not yet decided to break.  The spec says:
                    # "log a warning if multiple tiers have candidates" — so we
                    # finish the walk but exit early after collecting all hits.
                    # Efficient approach: break here, then do a second cheap pass
                    # to detect whether other tiers also have candidates.
                    break

        # For return-all: we already walked everything above via the loop.
        # For warn-and-return-closest / error: we broke at the first hit tier
        # but we should still check remaining tiers for ambiguity detection.
        if ambiguity_policy in ("warn-and-return-closest", "error") and tier_hits:
            first_hit_tier = tier_hits[0]
            first_hit_idx = _TIER_WALK.index(first_hit_tier)
            remaining_tiers = _TIER_WALK[first_hit_idx + 1 :]

            for tier in remaining_tiers:
                if tier == CollectionTier.team.value and team_namespace is None:
                    continue
                tiers_checked.append(tier)
                extra = self._query_tier(
                    tier=tier,
                    name=name,
                    project_id=(
                        project_id if tier == CollectionTier.project.value else None
                    ),
                    namespace=(
                        team_namespace if tier == CollectionTier.team.value else None
                    ),
                )
                if extra:
                    tier_hits.append(tier)
                    all_candidates.extend(extra)

        # Build result
        primary = all_candidates[0] if all_candidates else None
        warning: Optional[str] = None

        if len(tier_hits) > 1:
            tier_summary = ", ".join(tier_hits)
            if ambiguity_policy == "error":
                raise AmbiguousFQANError(name, all_candidates)
            elif ambiguity_policy == "warn-and-return-closest":
                warning = (
                    f"Ambiguous bare name {name!r}: candidates found in tiers "
                    f"[{tier_summary}]. Returning closest-tier match "
                    f"(tier={primary.collection_tier if primary else 'none'})."
                )
                logger.warning(warning)

        return ResolveResult(
            artifact=primary,
            candidates=all_candidates,
            tier_walk=tiers_checked,
            ambiguity_warning=warning,
        )

    def _query_tier(
        self,
        tier: str,
        name: str,
        project_id: Optional[str] = None,
        namespace: Optional[str] = None,
    ) -> List[Artifact]:
        """Execute a DB query for artifacts matching *name* at *tier*.

        Args:
            tier: ``collection_tier`` value to filter on.
            name: Artifact name to match.
            project_id: When provided, also filter on ``project_id``
                (used for the ``project`` tier).
            namespace: When provided, also filter on ``namespace``
                (used for the ``team`` tier).

        Returns:
            List of matching :class:`Artifact` rows.
        """
        query = self.session.query(Artifact).filter(
            Artifact.collection_tier == tier,
            Artifact.name == name,
        )
        if project_id is not None:
            query = query.filter(Artifact.project_id == project_id)
        if namespace is not None:
            query = query.filter(Artifact.namespace == namespace)
        return query.all()


# -------------------------------------------------------------------------
# Module-level helpers
# -------------------------------------------------------------------------


def _validate_tier(tier: str) -> None:
    """Raise :exc:`ValueError` if *tier* is not a valid CollectionTier value."""
    valid = {t.value for t in CollectionTier}
    if tier not in valid:
        raise ValueError(
            f"Invalid collection tier {tier!r}. "
            f"Must be one of: {sorted(valid)} (or 'local' as alias for 'project')."
        )


def _parse_scope_from_fqan(fqan: str) -> str:
    """Return the scope from *fqan* without full validation (best-effort).

    Used only to populate ``tier_walk`` in :meth:`FQANResolver.resolve` when
    the reference is an explicit FQAN.  Full parsing/validation is done
    inside :meth:`_resolve_explicit_fqan`.
    """
    try:
        return parse_fqan(fqan).scope
    except ValueError:
        # Return raw scope prefix so tier_walk is still informative even on
        # malformed FQANs (the full error will surface in _resolve_explicit_fqan)
        return fqan.split("://")[0] if "://" in fqan else "unknown"
