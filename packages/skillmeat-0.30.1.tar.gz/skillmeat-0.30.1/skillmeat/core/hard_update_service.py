"""Hard Update Service for DVCS Phase 6 - GitOps PR implementation.

This service creates GitOps pull requests on linked GitHub repositories when
hard update enforcement is enabled. It provides automated PR creation for
artifact updates to ensure downstream repositories stay compliant.

The service integrates with:
- GitHubClient for PR creation
- UpstreamCascadeService for artifact update detection
- Existing governance endpoints for compliance checking

Feature flag: dvcs.hard_update_enforcement
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from sqlalchemy.orm import Session

from skillmeat.cache.models import Artifact, Project
from skillmeat.core.github_client import (
    GitHubClient,
    GitHubClientError,
    GitHubAuthError,
    GitHubNotFoundError,
    GitHubRateLimitError,
    get_github_client,
)
from skillmeat.core.upstream_cascade import UpstreamCascadeService, CascadeResult

__all__ = [
    "ArtifactUpdate",
    "HardUpdateResult",
    "HardUpdateService",
    "PRCreationError",
    "GitRepoConnection",
]

logger = logging.getLogger(__name__)


# -------------------------------------------------------------------------
# Exception Classes
# -------------------------------------------------------------------------


class PRCreationError(Exception):
    """Base exception for PR creation failures."""

    def __init__(
        self, message: str, repo_path: str, original_error: Optional[Exception] = None
    ):
        super().__init__(message)
        self.message = message
        self.repo_path = repo_path
        self.original_error = original_error


# -------------------------------------------------------------------------
# Data Classes
# -------------------------------------------------------------------------


class ArtifactUpdate:
    """Represents a single artifact update for PR creation."""

    def __init__(
        self,
        artifact_id: str,
        artifact_name: str,
        artifact_type: str,
        current_version: str,
        new_version: str,
        new_content_hash: str,
        update_reason: Optional[str] = None,
        breaking_changes: Optional[List[str]] = None,
    ):
        self.artifact_id = artifact_id
        self.artifact_name = artifact_name
        self.artifact_type = artifact_type
        self.current_version = current_version
        self.new_version = new_version
        self.new_content_hash = new_content_hash
        self.update_reason = update_reason or "Upstream artifact updated"
        self.breaking_changes = breaking_changes or []

    @property
    def is_breaking_change(self) -> bool:
        """Check if this update contains breaking changes."""
        return len(self.breaking_changes) > 0

    @property
    def severity(self) -> str:
        """Determine update severity based on version change."""
        if self.is_breaking_change:
            return "major"
        # Simple heuristic - could be enhanced with proper semver parsing
        if "." in self.current_version and "." in self.new_version:
            current_parts = self.current_version.split(".")
            new_parts = self.new_version.split(".")
            if len(current_parts) >= 2 and len(new_parts) >= 2:
                if current_parts[0] != new_parts[0]:
                    return "major"
                elif current_parts[1] != new_parts[1]:
                    return "minor"
        return "patch"


class HardUpdateResult:
    """Result of a hard update PR creation operation."""

    def __init__(
        self,
        success: bool,
        pr_url: Optional[str] = None,
        pr_number: Optional[int] = None,
        updates_count: int = 0,
        repo_path: Optional[str] = None,
        error_message: Optional[str] = None,
        updates: Optional[List[ArtifactUpdate]] = None,
    ):
        self.success = success
        self.pr_url = pr_url
        self.pr_number = pr_number
        self.updates_count = updates_count
        self.repo_path = repo_path
        self.error_message = error_message
        self.updates = updates or []
        self.created_at = datetime.utcnow()


class GitRepoConnection:
    """Represents a connection to a GitHub repository for GitOps updates."""

    def __init__(
        self,
        project_id: str,
        repo_path: str,
        branch: Optional[str] = None,
        enabled: bool = True,
        last_pr_url: Optional[str] = None,
        last_pr_created_at: Optional[datetime] = None,
    ):
        self.project_id = project_id
        self.repo_path = repo_path  # e.g., "owner/repo"
        self.branch = branch or "main"
        self.enabled = enabled
        self.last_pr_url = last_pr_url
        self.last_pr_created_at = last_pr_created_at

    @property
    def owner(self) -> str:
        """Extract owner from repo_path."""
        return self.repo_path.split("/")[0]

    @property
    def repo_name(self) -> str:
        """Extract repo name from repo_path."""
        return self.repo_path.split("/")[1]


# -------------------------------------------------------------------------
# HardUpdateService
# -------------------------------------------------------------------------


class HardUpdateService:
    """Service for creating GitOps pull requests for hard update enforcement.

    This service handles the creation and management of pull requests on
    linked GitHub repositories when artifacts need to be updated due to
    hard update enforcement policies.

    Args:
        session: SQLAlchemy database session
        github_client: Optional GitHubClient instance (uses default if None)
        cascade_service: Optional UpstreamCascadeService instance

    Example:
        >>> service = HardUpdateService(session)
        >>> connection = GitRepoConnection(
        ...     project_id="proj-123",
        ...     repo_path="myorg/my-project"
        ... )
        >>> updates = [ArtifactUpdate(...)]
        >>> result = await service.create_hard_update_pr(connection, updates)
        >>> if result.success:
        ...     print(f"PR created: {result.pr_url}")
    """

    def __init__(
        self,
        session: Session,
        github_client: Optional[GitHubClient] = None,
        cascade_service: Optional[UpstreamCascadeService] = None,
    ):
        self.session = session
        self.github = github_client or get_github_client()
        self.cascade_service = cascade_service or UpstreamCascadeService(session)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def create_hard_update_pr(
        self,
        connection: GitRepoConnection,
        updates: List[ArtifactUpdate],
        pr_template: Optional[str] = None,
    ) -> HardUpdateResult:
        """Create a GitOps pull request for artifact updates.

        Creates a new branch and pull request on the specified GitHub repository
        with the updated artifact content. If an existing PR is open for the same
        purpose, it will be updated instead.

        Args:
            connection: GitHub repository connection details
            updates: List of artifact updates to include in the PR
            pr_template: Optional custom PR template (uses default if None)

        Returns:
            HardUpdateResult with success status and PR details

        Raises:
            PRCreationError: If PR creation fails due to GitHub API issues
        """
        if not updates:
            logger.warning(
                f"No updates provided for hard update PR on {connection.repo_path}"
            )
            return HardUpdateResult(
                success=False,
                repo_path=connection.repo_path,
                error_message="No updates provided",
            )

        if not connection.enabled:
            logger.info(f"GitOps connection disabled for {connection.repo_path}")
            return HardUpdateResult(
                success=False,
                repo_path=connection.repo_path,
                error_message="GitOps connection disabled",
            )

        try:
            # Generate unique branch name
            branch_name = self._generate_branch_name()

            # Check for existing open PR
            existing_pr = self._find_existing_hard_update_pr(connection)

            if existing_pr:
                logger.info(
                    f"Updating existing hard update PR #{existing_pr['number']} for {connection.repo_path}"
                )
                return self._update_existing_pr(connection, existing_pr, updates)
            else:
                logger.info(f"Creating new hard update PR for {connection.repo_path}")
                return self._create_new_pr(
                    connection, branch_name, updates, pr_template
                )

        except GitHubAuthError as e:
            error_msg = (
                f"GitHub authentication failed for {connection.repo_path}: {e.message}"
            )
            logger.error(error_msg)
            raise PRCreationError(error_msg, connection.repo_path, e)

        except GitHubRateLimitError as e:
            error_msg = (
                f"GitHub rate limit exceeded for {connection.repo_path}: {e.message}"
            )
            logger.error(error_msg)
            raise PRCreationError(error_msg, connection.repo_path, e)

        except GitHubNotFoundError as e:
            error_msg = (
                f"GitHub repository not found: {connection.repo_path}: {e.message}"
            )
            logger.error(error_msg)
            raise PRCreationError(error_msg, connection.repo_path, e)

        except GitHubClientError as e:
            error_msg = f"GitHub API error for {connection.repo_path}: {e.message}"
            logger.error(error_msg)
            raise PRCreationError(error_msg, connection.repo_path, e)

        except Exception as e:
            error_msg = f"Unexpected error creating hard update PR for {connection.repo_path}: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise PRCreationError(error_msg, connection.repo_path, e)

    def check_project_compliance(self, project_id: str) -> Dict[str, any]:
        """Check if a project has any artifacts that need hard updates.

        Args:
            project_id: Project ID to check for compliance

        Returns:
            Dictionary with compliance status and pending updates
        """
        try:
            # Query for outdated artifacts in the project
            outdated_artifacts = (
                self.session.query(Artifact)
                .filter(Artifact.project_id == project_id, Artifact.is_outdated == True)
                .all()
            )

            pending_updates = []
            critical_count = 0
            major_count = 0
            minor_count = 0

            for artifact in outdated_artifacts:
                update = ArtifactUpdate(
                    artifact_id=artifact.id,
                    artifact_name=artifact.name,
                    artifact_type=artifact.type,
                    current_version=artifact.deployed_version or "unknown",
                    new_version=artifact.upstream_version or "latest",
                    new_content_hash=artifact.content_hash or "",
                    update_reason="Upstream cascade update",
                )
                pending_updates.append(update)

                # Count by severity
                severity = update.severity
                if severity == "major":
                    major_count += 1
                elif severity == "minor":
                    minor_count += 1
                else:
                    minor_count += 1  # treat patch as minor for counting

                # Check for critical breaking changes
                if update.is_breaking_change:
                    critical_count += 1

            is_compliant = len(pending_updates) == 0

            return {
                "compliant": is_compliant,
                "update_count": len(pending_updates),
                "critical_count": critical_count,
                "major_count": major_count,
                "minor_count": minor_count,
                "max_severity": self._determine_max_severity(
                    critical_count, major_count, minor_count
                ),
                "pending_updates": pending_updates,
                "last_check": datetime.utcnow(),
            }

        except Exception as e:
            logger.error(
                f"Failed to check project compliance for {project_id}: {str(e)}"
            )
            return {
                "compliant": False,
                "update_count": 0,
                "error": str(e),
                "last_check": datetime.utcnow(),
            }

    def trigger_cascade_update(
        self,
        source_artifact_id: str,
        new_version: str,
        new_content_hash: str,
        auto_create_prs: bool = True,
    ) -> Tuple[CascadeResult, List[HardUpdateResult]]:
        """Trigger an upstream cascade and optionally create PRs for affected projects.

        This method combines the cascade propagation with PR creation for any
        linked GitHub repositories.

        Args:
            source_artifact_id: ID of the source artifact that was updated
            new_version: New version of the source artifact
            new_content_hash: Content hash of the new version
            auto_create_prs: Whether to automatically create PRs for affected projects

        Returns:
            Tuple of (CascadeResult, list of HardUpdateResults)
        """
        logger.info(f"Triggering cascade update for artifact {source_artifact_id}")

        # Perform the upstream cascade
        cascade_result = self.cascade_service.propagate_update(
            source_artifact_id=source_artifact_id,
            new_version=new_version,
            new_content_hash=new_content_hash,
        )

        pr_results = []

        if auto_create_prs and cascade_result.affected_count > 0:
            logger.info(
                f"Creating PRs for {cascade_result.affected_count} affected artifacts"
            )

            # Group affected artifacts by project and create PRs
            project_updates = self._group_updates_by_project(
                cascade_result.affected_ids
            )

            for project_id, artifact_ids in project_updates.items():
                # Get GitOps connections for this project
                connections = self._get_project_git_connections(project_id)

                if not connections:
                    logger.debug(
                        f"No GitOps connections found for project {project_id}"
                    )
                    continue

                # Create update objects for the affected artifacts
                updates = self._create_artifact_updates(
                    artifact_ids, new_version, new_content_hash
                )

                # Create PRs for each connection
                for connection in connections:
                    try:
                        result = self.create_hard_update_pr(connection, updates)
                        pr_results.append(result)

                        if result.success:
                            logger.info(
                                f"Created PR for project {project_id}: {result.pr_url}"
                            )
                        else:
                            logger.warning(
                                f"Failed to create PR for project {project_id}: {result.error_message}"
                            )

                    except PRCreationError as e:
                        logger.error(
                            f"PR creation failed for project {project_id}: {e.message}"
                        )
                        pr_results.append(
                            HardUpdateResult(
                                success=False,
                                repo_path=connection.repo_path,
                                error_message=e.message,
                                updates=updates,
                            )
                        )

        return cascade_result, pr_results

    # ------------------------------------------------------------------
    # Private Implementation Methods
    # ------------------------------------------------------------------

    def _generate_branch_name(self) -> str:
        """Generate a unique branch name for the hard update PR."""
        timestamp = int(time.time())
        return f"skillmeat/hard-update-{timestamp}"

    def _find_existing_hard_update_pr(
        self, connection: GitRepoConnection
    ) -> Optional[Dict]:
        """Find an existing open hard update PR for the repository."""
        try:
            # Use PyGithub to search for open PRs with our label/title pattern
            repo = self.github.get_repo(connection.repo_path)
            pulls = repo.get_pulls(
                state="open", head=f"{connection.owner}:skillmeat/hard-update"
            )

            for pr in pulls:
                if pr.title.startswith("[SkillMeat Hard Update]"):
                    return {
                        "number": pr.number,
                        "url": pr.html_url,
                        "head_sha": pr.head.sha,
                        "branch": pr.head.ref,
                    }

            return None

        except Exception as e:
            logger.warning(
                f"Failed to check for existing PRs in {connection.repo_path}: {str(e)}"
            )
            return None

    def _create_new_pr(
        self,
        connection: GitRepoConnection,
        branch_name: str,
        updates: List[ArtifactUpdate],
        pr_template: Optional[str] = None,
    ) -> HardUpdateResult:
        """Create a new hard update PR."""
        try:
            repo = self.github.get_repo(connection.repo_path)

            # Get the base branch reference
            base_ref = repo.get_git_ref(f"heads/{connection.branch}")
            base_sha = base_ref.object.sha

            # Create new branch
            new_ref = repo.create_git_ref(ref=f"refs/heads/{branch_name}", sha=base_sha)

            # Generate file changes for the updates
            file_changes = self._generate_file_changes(updates)

            # Commit the changes
            for file_path, file_content in file_changes.items():
                try:
                    # Try to get existing file
                    existing_file = repo.get_contents(file_path, ref=branch_name)
                    repo.update_file(
                        path=file_path,
                        message=f"Update {file_path} for hard update enforcement",
                        content=file_content,
                        sha=existing_file.sha,
                        branch=branch_name,
                    )
                except GitHubNotFoundError:
                    # File doesn't exist, create it
                    repo.create_file(
                        path=file_path,
                        message=f"Create {file_path} for hard update enforcement",
                        content=file_content,
                        branch=branch_name,
                    )

            # Generate PR content
            pr_title = self._generate_pr_title(updates)
            pr_body = self._generate_pr_body(connection, updates, pr_template)

            # Create the pull request
            pr = repo.create_pull(
                title=pr_title, body=pr_body, head=branch_name, base=connection.branch
            )

            # Add labels
            pr.add_to_labels("skillmeat", "hard-update", "automation")

            logger.info(
                f"Created hard update PR #{pr.number} in {connection.repo_path}"
            )

            return HardUpdateResult(
                success=True,
                pr_url=pr.html_url,
                pr_number=pr.number,
                updates_count=len(updates),
                repo_path=connection.repo_path,
                updates=updates,
            )

        except Exception as e:
            error_msg = f"Failed to create PR in {connection.repo_path}: {str(e)}"
            logger.error(error_msg)
            return HardUpdateResult(
                success=False,
                repo_path=connection.repo_path,
                error_message=error_msg,
                updates=updates,
            )

    def _update_existing_pr(
        self,
        connection: GitRepoConnection,
        existing_pr: Dict,
        updates: List[ArtifactUpdate],
    ) -> HardUpdateResult:
        """Update an existing hard update PR with new changes."""
        try:
            repo = self.github.get_repo(connection.repo_path)
            pr = repo.get_pull(existing_pr["number"])

            # Generate new file changes
            file_changes = self._generate_file_changes(updates)
            branch_name = existing_pr["branch"]

            # Update files on the existing branch
            for file_path, file_content in file_changes.items():
                try:
                    existing_file = repo.get_contents(file_path, ref=branch_name)
                    repo.update_file(
                        path=file_path,
                        message=f"Update {file_path} - additional hard update changes",
                        content=file_content,
                        sha=existing_file.sha,
                        branch=branch_name,
                    )
                except GitHubNotFoundError:
                    repo.create_file(
                        path=file_path,
                        message=f"Create {file_path} - additional hard update changes",
                        content=file_content,
                        branch=branch_name,
                    )

            # Update PR body with new information
            pr_body = self._generate_pr_body(connection, updates)
            pr.edit(body=pr_body)

            logger.info(
                f"Updated existing hard update PR #{pr.number} in {connection.repo_path}"
            )

            return HardUpdateResult(
                success=True,
                pr_url=pr.html_url,
                pr_number=pr.number,
                updates_count=len(updates),
                repo_path=connection.repo_path,
                updates=updates,
            )

        except Exception as e:
            error_msg = f"Failed to update existing PR #{existing_pr['number']} in {connection.repo_path}: {str(e)}"
            logger.error(error_msg)
            return HardUpdateResult(
                success=False,
                repo_path=connection.repo_path,
                error_message=error_msg,
                updates=updates,
            )

    def _generate_pr_title(self, updates: List[ArtifactUpdate]) -> str:
        """Generate a descriptive PR title for the updates."""
        if len(updates) == 1:
            update = updates[0]
            return f"[SkillMeat Hard Update] Update {update.artifact_name} to v{update.new_version}"
        else:
            return f"[SkillMeat Hard Update] Update {len(updates)} artifacts to latest versions"

    def _generate_pr_body(
        self,
        connection: GitRepoConnection,
        updates: List[ArtifactUpdate],
        template: Optional[str] = None,
    ) -> str:
        """Generate the pull request description."""
        if template:
            # Use custom template if provided
            return template.format(
                connection=connection,
                updates=updates,
                timestamp=datetime.utcnow().isoformat(),
            )

        # Build version comparison table
        version_table = self._build_version_table(updates)

        # Check for breaking changes
        breaking_changes = [u for u in updates if u.is_breaking_change]
        breaking_section = ""
        if breaking_changes:
            breaking_section = f"""
### ⚠️ Breaking Changes

{len(breaking_changes)} update(s) contain breaking changes:

""" + "\n".join(
                [
                    f"- **{u.artifact_name}**: {', '.join(u.breaking_changes)}"
                    for u in breaking_changes
                ]
            )

        return f"""## 🚨 SkillMeat Hard Update Required

This automated pull request contains **mandatory artifact updates** that must be applied to maintain compliance with your organization's governance policies.

### 📋 Summary

- **{len(updates)} artifact(s)** require immediate updates
- **Repository**: `{connection.repo_path}`
- **Policy**: Hard update enforcement enabled
- **Generated**: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}

### 📊 Version Updates

{version_table}

{breaking_section}

### 🔧 Required Actions

1. **Review Changes**: Examine all modified files in the "Files changed" tab
2. **Test Compatibility**: Run your test suite to verify compatibility
3. **Merge**: This PR must be merged to maintain policy compliance
4. **Deploy**: Follow your deployment process to activate the updates

### 📚 Documentation

- [SkillMeat Hard Update Policy](https://docs.skillmeat.dev/governance/hard-updates)
- [Artifact Version Management](https://docs.skillmeat.dev/artifacts/versioning)

### 🤖 Automation Details

- **Connection ID**: `{connection.project_id}`
- **Branch**: `{connection.branch}`
- **Update Method**: GitOps Pull Request
- **Enforcement Level**: Hard Update

---

*This PR was automatically generated by SkillMeat DVCS v1.0 hard update enforcement.*
*Contact your system administrator if you have questions about this policy.*
"""

    def _build_version_table(self, updates: List[ArtifactUpdate]) -> str:
        """Build a markdown table of version updates."""
        lines = [
            "| Artifact | Type | Current Version | New Version | Severity | Status |",
            "|----------|------|-----------------|-------------|----------|--------|",
        ]

        for update in updates:
            status_icon = (
                "🔴"
                if update.is_breaking_change
                else "🟡" if update.severity == "major" else "🟢"
            )
            lines.append(
                f"| `{update.artifact_name}` | {update.artifact_type} | "
                f"`{update.current_version}` | `{update.new_version}` | "
                f"{update.severity.title()} | {status_icon} |"
            )

        return "\n".join(lines)

    def _generate_file_changes(self, updates: List[ArtifactUpdate]) -> Dict[str, str]:
        """Generate the file content changes for the PR."""
        file_changes = {}

        for update in updates:
            # Generate updated artifact files
            artifact_dir = f".skillmeat/{update.artifact_type}s/{update.artifact_name}"

            # Update the main artifact file
            artifact_file = f"{artifact_dir}/ARTIFACT.md"
            file_changes[artifact_file] = self._generate_updated_artifact_content(
                update
            )

            # Update metadata file if needed
            metadata_file = f"{artifact_dir}/metadata.json"
            file_changes[metadata_file] = self._generate_updated_metadata(update)

        return file_changes

    def _generate_updated_artifact_content(self, update: ArtifactUpdate) -> str:
        """Generate updated content for an artifact file."""
        # This is a simplified version - in practice, this would fetch
        # the actual new content from the artifact service
        return f"""---
name: {update.artifact_name}
type: {update.artifact_type}
version: {update.new_version}
updated_by: skillmeat-hard-update
updated_at: {datetime.utcnow().isoformat()}
---

# {update.artifact_name.title()}

This artifact has been updated to version {update.new_version} as part of a hard update enforcement policy.

**Update Details:**
- Previous version: {update.current_version}
- New version: {update.new_version}
- Reason: {update.update_reason}
- Content hash: {update.new_content_hash[:12]}...

**Breaking Changes:**
{chr(10).join([f'- {change}' for change in update.breaking_changes]) if update.breaking_changes else 'None detected.'}

---

*Auto-updated by SkillMeat DVCS Hard Update Service*
"""

    def _generate_updated_metadata(self, update: ArtifactUpdate) -> str:
        """Generate updated metadata for an artifact."""
        metadata = {
            "artifact_id": update.artifact_id,
            "name": update.artifact_name,
            "type": update.artifact_type,
            "version": update.new_version,
            "content_hash": update.new_content_hash,
            "updated_at": datetime.utcnow().isoformat(),
            "update_method": "hard_update_enforcement",
            "severity": update.severity,
            "breaking_changes": update.breaking_changes,
        }
        return json.dumps(metadata, indent=2, sort_keys=True)

    def _group_updates_by_project(
        self, affected_artifact_ids: List[str]
    ) -> Dict[str, List[str]]:
        """Group affected artifacts by their project ID."""
        project_updates = {}

        for artifact_id in affected_artifact_ids:
            artifact = (
                self.session.query(Artifact).filter(Artifact.id == artifact_id).first()
            )
            if artifact and hasattr(artifact, "project_id") and artifact.project_id:
                project_id = artifact.project_id
                if project_id not in project_updates:
                    project_updates[project_id] = []
                project_updates[project_id].append(artifact_id)

        return project_updates

    def _get_project_git_connections(self, project_id: str) -> List[GitRepoConnection]:
        """Get GitOps connections for a project."""
        # In a real implementation, this would query a git_repo_connections table
        # For now, return an empty list as we don't have that table structure
        logger.debug(f"Getting GitOps connections for project {project_id}")
        return []

    def _create_artifact_updates(
        self, artifact_ids: List[str], new_version: str, new_content_hash: str
    ) -> List[ArtifactUpdate]:
        """Create ArtifactUpdate objects for the given artifact IDs."""
        updates = []

        for artifact_id in artifact_ids:
            artifact = (
                self.session.query(Artifact).filter(Artifact.id == artifact_id).first()
            )
            if artifact:
                update = ArtifactUpdate(
                    artifact_id=artifact.id,
                    artifact_name=artifact.name,
                    artifact_type=artifact.type,
                    current_version=artifact.deployed_version or "unknown",
                    new_version=new_version,
                    new_content_hash=new_content_hash,
                    update_reason="Upstream cascade update",
                )
                updates.append(update)

        return updates

    def _determine_max_severity(
        self, critical_count: int, major_count: int, minor_count: int
    ) -> str:
        """Determine the maximum severity level from counts."""
        if critical_count > 0:
            return "critical"
        elif major_count > 0:
            return "major"
        elif minor_count > 0:
            return "minor"
        else:
            return "none"
