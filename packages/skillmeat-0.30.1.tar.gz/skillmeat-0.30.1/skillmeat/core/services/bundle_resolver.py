"""Bundle dependency-graph resolver for IDP scaffold endpoint.

This module provides :class:`BundleResolver`, which traverses a
``BundleEntity`` dependency graph depth-first and returns a
:class:`BundleResolutionResult` containing an ordered, deduplicated list of
:class:`ResolvedArtifact` objects and an ordered list of
:class:`ResolvedContextEntity` objects suitable for Backstage / IDP scaffold
generation.

Algorithm
---------
Traversal is iterative (not recursive) to avoid Python call-stack limits when
Bundle-of-Bundle graphs are deeply nested.  Cycle detection is O(1) via a
``visited`` set keyed on node ID.  The algorithm also enforces:

- **max_depth**: configurable hard ceiling on DFS depth (default 10).
- **Same-tier rejection**: a Bundle may not directly reference another Bundle
  at the same tier (e.g., a Tier-2 Bundle pointing to a Tier-2 Bundle).

Tier semantics
--------------
Tier values are inherited from ``BundleMembership.artifact_tier``:

    0 — primitive artifact (skill / command / agent / hook / mcp_server)
    1 — composite artifact (multi-artifact package without sub-bundles)
    2 — bundle of composites (Tier-1 members only)
    3 — bundle of bundles   (Tier-2 sub-bundles, ultimately resolves to Tier 0/1)

File content loading
--------------------
``ResolvedArtifact.file_content_map`` is populated for filesystem-backed
artifacts by reading the collection path returned from the DB ``Artifact``
row's ``path`` field.  Missing files are silently skipped to keep the
resolver fault-tolerant.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from sqlalchemy.orm import Session

from skillmeat.cache.models import Artifact, BundleEntity, BundleMembership
from skillmeat.observability.tracing import trace_operation

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class BundleResolutionError(Exception):
    """Base exception for all bundle resolution failures."""


class CircularDependencyError(BundleResolutionError):
    """Raised when a cycle is detected in the Bundle dependency graph.

    Attributes:
        node_path: Ordered list of bundle / artifact IDs forming the cycle.
    """

    def __init__(self, message: str, node_path: List[str]) -> None:
        super().__init__(message)
        self.node_path = node_path


class ResolutionDepthError(BundleResolutionError):
    """Raised when traversal exceeds the configured maximum depth.

    Attributes:
        current_depth: Depth at which the limit was exceeded.
        max_depth: The configured ceiling.
    """

    def __init__(self, message: str, current_depth: int, max_depth: int) -> None:
        super().__init__(message)
        self.current_depth = current_depth
        self.max_depth = max_depth


class SameTierRecursionError(BundleResolutionError):
    """Raised when a Bundle references another Bundle at the same tier.

    Same-tier Bundle→Bundle edges create ambiguous ordering and are rejected
    immediately during traversal.

    Attributes:
        parent_id: ID of the offending parent bundle.
        child_id: ID of the child bundle that shares the parent's tier.
        tier: The shared tier value.
    """

    def __init__(
        self,
        message: str,
        parent_id: str,
        child_id: str,
        tier: int,
    ) -> None:
        super().__init__(message)
        self.parent_id = parent_id
        self.child_id = child_id
        self.tier = tier


# ---------------------------------------------------------------------------
# Output type
# ---------------------------------------------------------------------------

#: Set of artifact type strings that represent primitive leaf nodes.
_PRIMITIVE_TYPES: frozenset[str] = frozenset(
    {"skill", "command", "agent", "hook", "mcp_server"}
)

#: Sentinel used when an artifact's ``type:name`` ID cannot be determined.
_UNKNOWN_ID = "<unknown>"


@dataclass
class ResolvedArtifact:
    """A single artifact node produced by :class:`BundleResolver`.

    Attributes:
        id: Canonical ``type:name`` artifact identifier (e.g. ``"skill:canvas"``).
        name: Human-readable artifact name.
        type: Artifact type string — one of ``skill``, ``command``, ``agent``,
            ``hook``, ``mcp_server``.
        tier: Membership tier inherited from ``BundleMembership.artifact_tier``.
            0 = primitive, 1 = composite, 2 = bundle-of-composites,
            3 = bundle-of-bundles.
        platform_targets: List of platform target strings.  Empty list means
            the artifact targets all platforms.
        file_content_map: Mapping of relative file path → UTF-8 text content
            for all files belonging to the artifact.  Binary files are skipped.
    """

    id: str
    name: str
    type: str
    tier: int
    platform_targets: List[str] = field(default_factory=list)
    file_content_map: Dict[str, str] = field(default_factory=dict)


@dataclass
class ResolvedContextEntity:
    """A single context entity (spec/rule file) resolved from a Bundle.

    Context entities are non-artifact bundle members such as spec files,
    rule files, or other structured documents that accompany artifacts in
    a scaffold template.

    Attributes:
        id: Stable identifier for the context entity (e.g. ``"spec_file:my-spec"``).
        name: Human-readable entity name.
        entity_type: Category of context entity — e.g. ``"spec_file"``,
            ``"rule_file"``, ``"doc_file"``.
        category: Broad grouping for the entity — e.g. ``"general"``,
            ``"security"``, ``"testing"``.
        content: Raw text content of the entity file.  ``None`` if the content
            has not yet been loaded or the file was not found.
        path_pattern: Deployment path pattern describing where the entity
            should be written relative to the scaffold root.  ``None`` if not
            specified.
    """

    id: str
    name: str
    entity_type: str
    category: str
    content: Optional[str] = None
    path_pattern: Optional[str] = None


@dataclass
class BundleResolutionResult:
    """Aggregated output of a full Bundle resolution pass.

    Groups the two distinct output categories produced by
    :class:`BundleResolver.resolve` so callers can handle artifacts and
    context entities independently.

    Attributes:
        artifacts: Ordered, deduplicated list of resolved artifact nodes.
        context_entities: Ordered list of resolved context entity nodes.
    """

    artifacts: List[ResolvedArtifact] = field(default_factory=list)
    context_entities: List[ResolvedContextEntity] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _artifact_row_to_resolved(
    artifact: Artifact,
    tier: int,
) -> ResolvedArtifact:
    """Convert an ORM :class:`~skillmeat.cache.models.Artifact` row to a
    :class:`ResolvedArtifact`, loading file content where possible.

    Args:
        artifact: ORM Artifact instance (must be attached to an active session).
        tier: Membership tier from the ``BundleMembership`` edge.

    Returns:
        Populated :class:`ResolvedArtifact`.
    """
    artifact_type = (
        artifact.type if isinstance(artifact.type, str) else str(artifact.type)
    )
    # Strip enum prefix if present (e.g. "ArtifactType.skill" → "skill")
    if "." in artifact_type:
        artifact_type = artifact_type.rsplit(".", 1)[-1]

    artifact_id = artifact.id or f"{artifact_type}:{artifact.name}"

    file_content_map: Dict[str, str] = {}
    artifact_path = getattr(artifact, "source", None) or getattr(artifact, "path", None)
    if artifact_path:
        artifact_fs_path = Path(artifact_path)
        if artifact_fs_path.exists():
            if artifact_fs_path.is_file():
                _try_read_file(
                    artifact_fs_path, artifact_fs_path.name, file_content_map
                )
            elif artifact_fs_path.is_dir():
                for child_path in sorted(artifact_fs_path.rglob("*")):
                    if child_path.is_file():
                        rel = str(child_path.relative_to(artifact_fs_path))
                        _try_read_file(child_path, rel, file_content_map)

    return ResolvedArtifact(
        id=artifact_id,
        name=artifact.name,
        type=artifact_type,
        tier=tier,
        platform_targets=[],
        file_content_map=file_content_map,
    )


def _context_entity_row_to_resolved(artifact: Artifact) -> ResolvedContextEntity:
    """Convert an ORM :class:`~skillmeat.cache.models.Artifact` row that
    represents a context entity to a :class:`ResolvedContextEntity`.

    Context entities are stored as ``Artifact`` rows with ``ctx_*`` IDs.
    The mapping follows the same field conventions used by
    ``LocalContextEntityRepository._orm_to_dto()``.

    Args:
        artifact: ORM Artifact instance (must be attached to an active session).

    Returns:
        Populated :class:`ResolvedContextEntity`.
    """
    entity_type = (
        artifact.type if isinstance(artifact.type, str) else str(artifact.type)
    )
    # Strip enum prefix if present (e.g. "ArtifactType.spec_file" → "spec_file")
    if "." in entity_type:
        entity_type = entity_type.rsplit(".", 1)[-1]

    return ResolvedContextEntity(
        id=artifact.id or "",
        name=artifact.name or "",
        entity_type=entity_type,
        category=getattr(artifact, "category", None) or "",
        content=getattr(artifact, "content", None),
        path_pattern=getattr(artifact, "path_pattern", None),
    )


def _try_read_file(path: Path, key: str, target: Dict[str, str]) -> None:
    """Read *path* as UTF-8 text into *target[key]*, skipping binary files."""
    try:
        target[key] = path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        # Binary file or unreadable — skip silently
        pass


# ---------------------------------------------------------------------------
# Resolver
# ---------------------------------------------------------------------------


class BundleResolver:
    """Resolves the dependency graph of a ``BundleEntity`` for IDP scaffold.

    The resolver performs an iterative depth-first search starting from the
    top-level bundle, accumulating primitive and composite artifacts in
    discovery order while deduplicating by artifact ID.

    Usage::

        resolver = BundleResolver()
        result = resolver.resolve(bundle_id, session)
        artifacts = result.artifacts
        context_entities = result.context_entities

    Args:
        N/A — stateless; all state is local to :meth:`resolve`.

    Note:
        The ``session`` argument must remain open for the lifetime of the
        :meth:`resolve` call.  Lazy-loaded ORM relationships are accessed
        during traversal.
    """

    def resolve(
        self,
        bundle_id: str,
        session: Session,
        max_depth: int = 10,
    ) -> BundleResolutionResult:
        """Traverse the Bundle dependency graph and return artifacts and context entities.

        Implements iterative DFS with:
        - Cycle detection via a ``visited`` set on bundle IDs.
        - Hard depth limit (``max_depth``, default 10).
        - Same-tier Bundle→Bundle rejection.
        - Deduplication: first occurrence wins; duplicates by artifact ``id``
          are skipped.
        - Membership partitioning: ``member_type="artifact"`` members are
          resolved through the existing artifact path; ``member_type=
          "context_entity"`` members are looked up in the ``Artifact`` table
          (context entities are stored as Artifact rows with ``ctx_*`` IDs)
          and collected as :class:`ResolvedContextEntity` instances.

        Args:
            bundle_id: UUID hex primary key of the root ``BundleEntity``.
            session: Active SQLAlchemy session used for ORM queries.
            max_depth: Maximum DFS depth before :class:`ResolutionDepthError`
                is raised.  Default is 10.

        Returns:
            :class:`BundleResolutionResult` containing an ordered list of
            :class:`ResolvedArtifact` (DFS discovery order, deduplicated) and
            an ordered list of :class:`ResolvedContextEntity`.

        Raises:
            ValueError: If no bundle with *bundle_id* exists in the session.
            CircularDependencyError: If a cycle is detected in the graph.
            ResolutionDepthError: If traversal exceeds *max_depth*.
            SameTierRecursionError: If a Bundle references a same-tier Bundle.
        """
        with trace_operation(
            "bundle.resolve",
            bundle_id=bundle_id,
            max_depth=max_depth,
        ) as span:
            result = self._resolve_inner(bundle_id, session, max_depth)
            span.set_attribute("resolved_artifact_count", len(result.artifacts))
            span.set_attribute(
                "resolved_context_entity_count", len(result.context_entities)
            )
            return result

    # ------------------------------------------------------------------
    # Private implementation
    # ------------------------------------------------------------------

    def _resolve_inner(
        self,
        bundle_id: str,
        session: Session,
        max_depth: int,
    ) -> BundleResolutionResult:
        """Core iterative DFS implementation.

        The DFS stack holds ``(bundle_id, parent_tier, depth, ancestor_path)``
        tuples where:
        - ``bundle_id``: the bundle to expand next.
        - ``parent_tier``: the tier of the parent Bundle (used for same-tier
          rejection of nested bundles).
        - ``depth``: current depth (root = 0).
        - ``ancestor_path``: ordered list of bundle IDs from root to current
          node, used for constructing meaningful cycle error messages.

        Args:
            bundle_id: UUID hex of the root bundle.
            session: Active SQLAlchemy session.
            max_depth: Hard depth ceiling.

        Returns:
            :class:`BundleResolutionResult` with ordered, deduplicated
            :class:`ResolvedArtifact` list and ordered
            :class:`ResolvedContextEntity` list.
        """
        # Load the root bundle first to provide a clear error for missing IDs.
        root_bundle = self._load_bundle(bundle_id, session)

        # DFS stack: (bundle_entity, parent_tier, depth, ancestor_path)
        stack: List[Tuple[BundleEntity, Optional[int], int, List[str]]] = [
            (root_bundle, None, 0, [bundle_id]),
        ]

        # Tracks which bundle IDs have been visited to detect cycles.
        visited_bundles: Set[str] = set()

        # Tracks which artifact IDs have been emitted to deduplicate.
        seen_artifact_ids: Set[str] = set()

        # Tracks which context entity IDs have been emitted to deduplicate.
        seen_context_entity_ids: Set[str] = set()

        # Output lists (ordered, deduplicated).
        resolved: List[ResolvedArtifact] = []
        resolved_context_entities: List[ResolvedContextEntity] = []

        while stack:
            bundle, parent_tier, depth, ancestor_path = stack.pop()

            # --- Depth guard -------------------------------------------
            if depth > max_depth:
                raise ResolutionDepthError(
                    f"Bundle resolution exceeded max depth {max_depth} "
                    f"at bundle '{bundle.id}' (depth {depth}).",
                    current_depth=depth,
                    max_depth=max_depth,
                )

            # --- Cycle guard -------------------------------------------
            if bundle.id in visited_bundles:
                raise CircularDependencyError(
                    f"Circular dependency detected: bundle '{bundle.id}' "
                    f"appears more than once in path {ancestor_path!r}.",
                    node_path=ancestor_path,
                )
            visited_bundles.add(bundle.id)

            logger.debug(
                "Resolving bundle '%s' (depth=%d, memberships=%d)",
                bundle.name,
                depth,
                len(bundle.memberships),
            )

            # Process memberships in reverse so DFS stack produces correct order.
            for membership in reversed(bundle.memberships):
                member_type = (
                    getattr(membership, "member_type", "artifact") or "artifact"
                )
                if member_type == "context_entity":
                    self._process_context_entity_membership(
                        membership=membership,
                        bundle=bundle,
                        session=session,
                        seen_context_entity_ids=seen_context_entity_ids,
                        resolved_context_entities=resolved_context_entities,
                    )
                else:
                    self._process_membership(
                        membership=membership,
                        bundle=bundle,
                        depth=depth,
                        max_depth=max_depth,
                        ancestor_path=ancestor_path,
                        session=session,
                        stack=stack,
                        seen_artifact_ids=seen_artifact_ids,
                        resolved=resolved,
                    )

        return BundleResolutionResult(
            artifacts=resolved,
            context_entities=resolved_context_entities,
        )

    def _process_membership(
        self,
        membership: BundleMembership,
        bundle: BundleEntity,
        depth: int,
        max_depth: int,
        ancestor_path: List[str],
        session: Session,
        stack: List[Tuple[BundleEntity, Optional[int], int, List[str]]],
        seen_artifact_ids: Set[str],
        resolved: List[ResolvedArtifact],
    ) -> None:
        """Process a single ``BundleMembership`` edge during DFS.

        If the member artifact is itself a ``BundleEntity`` (resolved via a
        second DB query on ``artifact_uuid``), it is pushed onto the DFS stack
        after same-tier and depth checks.  Otherwise, the artifact is emitted
        as a :class:`ResolvedArtifact` if not already seen.

        Args:
            membership: The ``BundleMembership`` ORM row being processed.
            bundle: The owning ``BundleEntity`` (parent).
            depth: Current DFS depth.
            max_depth: Hard depth ceiling.
            ancestor_path: Ordered bundle-ID path from root to *bundle*.
            session: Active SQLAlchemy session.
            stack: Mutable DFS stack (items appended = pushed for next pop).
            seen_artifact_ids: Mutable set of already-emitted artifact IDs.
            resolved: Mutable output list.
        """
        tier = membership.artifact_tier
        artifact_uuid = membership.artifact_uuid

        # Attempt to resolve the membership as a nested BundleEntity.
        # Bundles are identified by matching artifact_uuid against bundles
        # whose primary key corresponds to an artifact row uuid.
        # artifact_uuid is Optional[str] (NULL for context_entity members) —
        # guard against None before passing to the helper which expects str.
        if not artifact_uuid:
            logger.warning(
                "BundleResolver: artifact membership in bundle '%s' has null "
                "artifact_uuid; skipping.",
                bundle.id,
            )
            return
        child_bundle = self._find_bundle_by_artifact_uuid(artifact_uuid, session)

        if child_bundle is not None:
            # --- Nested bundle: same-tier rejection --------------------
            bundle_tier = self._infer_bundle_tier(bundle)
            if bundle_tier is not None and bundle_tier == tier:
                raise SameTierRecursionError(
                    f"Same-tier Bundle→Bundle edge rejected: parent bundle "
                    f"'{bundle.id}' (tier {bundle_tier}) → child bundle "
                    f"'{child_bundle.id}' (tier {tier}).",
                    parent_id=bundle.id,
                    child_id=child_bundle.id,
                    tier=tier,
                )

            next_depth = depth + 1
            if next_depth > max_depth:
                raise ResolutionDepthError(
                    f"Bundle resolution would exceed max depth {max_depth} "
                    f"while queuing child bundle '{child_bundle.id}'.",
                    current_depth=next_depth,
                    max_depth=max_depth,
                )

            stack.append(
                (child_bundle, tier, next_depth, ancestor_path + [child_bundle.id])
            )
            return

        # --- Primitive / composite artifact ----------------------------
        artifact = membership.child_artifact
        if artifact is None:
            # Relationship may not have loaded — fall back to direct query.
            artifact = (
                session.query(Artifact).filter(Artifact.uuid == artifact_uuid).first()
            )

        if artifact is None:
            logger.warning(
                "BundleResolver: artifact with uuid '%s' not found; "
                "skipping membership in bundle '%s'.",
                artifact_uuid,
                bundle.id,
            )
            return

        resolved_artifact = _artifact_row_to_resolved(artifact, tier)

        if resolved_artifact.id in seen_artifact_ids:
            logger.debug(
                "BundleResolver: skipping duplicate artifact '%s'.",
                resolved_artifact.id,
            )
            return

        seen_artifact_ids.add(resolved_artifact.id)
        resolved.append(resolved_artifact)

    def _process_context_entity_membership(
        self,
        membership: BundleMembership,
        bundle: BundleEntity,
        session: Session,
        seen_context_entity_ids: Set[str],
        resolved_context_entities: List[ResolvedContextEntity],
    ) -> None:
        """Process a ``member_type="context_entity"`` ``BundleMembership`` edge.

        Looks up the referenced context entity in the ``Artifact`` table by
        ``context_entity_id`` (which is the ``Artifact.id`` string, e.g.
        ``"ctx_abc123"``).  Missing entities are logged as warnings and
        skipped, consistent with how missing artifacts are handled in
        :meth:`_process_membership`.  Duplicates (by entity ID) are also
        skipped.

        Args:
            membership: The ``BundleMembership`` ORM row with
                ``member_type="context_entity"``.
            bundle: The owning ``BundleEntity`` (used for warning messages).
            session: Active SQLAlchemy session.
            seen_context_entity_ids: Mutable set of already-emitted entity IDs
                (first occurrence wins).
            resolved_context_entities: Mutable output list.
        """
        context_entity_id = membership.context_entity_id
        if not context_entity_id:
            logger.warning(
                "BundleResolver: context_entity membership in bundle '%s' "
                "has null context_entity_id; skipping.",
                bundle.id,
            )
            return

        if context_entity_id in seen_context_entity_ids:
            logger.debug(
                "BundleResolver: skipping duplicate context entity '%s'.",
                context_entity_id,
            )
            return

        artifact = (
            session.query(Artifact).filter(Artifact.id == context_entity_id).first()
        )
        if artifact is None:
            logger.warning(
                "BundleResolver: context entity with id '%s' not found in "
                "Artifact table; skipping membership in bundle '%s'.",
                context_entity_id,
                bundle.id,
            )
            return

        resolved_entity = _context_entity_row_to_resolved(artifact)
        seen_context_entity_ids.add(context_entity_id)
        resolved_context_entities.append(resolved_entity)

    # ------------------------------------------------------------------
    # DB helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _load_bundle(bundle_id: str, session: Session) -> BundleEntity:
        """Load a ``BundleEntity`` by primary key, raising ``ValueError`` if
        absent.

        Args:
            bundle_id: UUID hex primary key.
            session: Active SQLAlchemy session.

        Returns:
            The ``BundleEntity`` ORM instance.

        Raises:
            ValueError: If no row with *bundle_id* exists.
        """
        bundle = (
            session.query(BundleEntity).filter(BundleEntity.id == bundle_id).first()
        )
        if bundle is None:
            raise ValueError(
                f"BundleResolver: no BundleEntity found with id '{bundle_id}'."
            )
        return bundle

    @staticmethod
    def _find_bundle_by_artifact_uuid(
        artifact_uuid: str,
        session: Session,
    ) -> Optional[BundleEntity]:
        """Return a ``BundleEntity`` whose ``id`` matches *artifact_uuid*, or
        ``None`` if the UUID belongs to a plain artifact rather than a bundle.

        ``BundleEntity.id`` is a UUID hex string, while individual artifact
        UUIDs come from ``Artifact.uuid``.  A membership can point to a nested
        bundle only if a ``BundleEntity`` row exists whose ``id`` equals the
        ``BundleMembership.artifact_uuid`` value.

        Args:
            artifact_uuid: The ``artifact_uuid`` from the membership edge.
            session: Active SQLAlchemy session.

        Returns:
            ``BundleEntity`` if the UUID is a bundle ID, otherwise ``None``.
        """
        return (
            session.query(BundleEntity).filter(BundleEntity.id == artifact_uuid).first()
        )

    @staticmethod
    def _infer_bundle_tier(bundle: BundleEntity) -> Optional[int]:
        """Infer the effective tier of *bundle* from its membership list.

        The bundle tier is the maximum ``artifact_tier`` across all loaded
        memberships.  Returns ``None`` if the bundle has no memberships
        (cannot determine tier).

        Args:
            bundle: A ``BundleEntity`` with its ``memberships`` relationship
                already loaded.

        Returns:
            Maximum ``artifact_tier`` among memberships, or ``None``.
        """
        if not bundle.memberships:
            return None
        return max(m.artifact_tier for m in bundle.memberships)
