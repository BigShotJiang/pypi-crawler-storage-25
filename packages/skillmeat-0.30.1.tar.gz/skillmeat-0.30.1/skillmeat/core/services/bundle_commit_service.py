"""Service for atomic composite versioning via BundleCommit (DVCS-2.3).

Orchestrates the SERIALIZABLE transaction boundary for composite snapshot
creation.  This layer sits between API routers and the repository, handling:

- Input validation (non-empty member list, valid ``change_origin``)
- Composite artifact existence check
- Idempotency detection via ``bundle_hash``
- Atomic commit creation with parent-chain tracking
- Post-commit ``ArtifactCollectionVersion.composite_commit_id`` update

Algorithm (DVCS SPIKE § 5)
--------------------------
1. Validate inputs — raise ``ValueError`` on empty members or bad origin.
2. Assert composite artifact exists in the ``artifacts`` table.
3. Compute ``bundle_hash`` from ``member_versions`` via
   :func:`~skillmeat.core.cas.hash_utils.compute_bundle_hash`.
4. Check idempotency — return the existing commit if the hash matches.
5. Set ``SERIALIZABLE`` isolation on the connection.
6. Resolve ``parent_id`` to the current latest commit for this composite.
7. Delegate insert to :meth:`BundleCommitRepository.create_with_members`.
8. Update ``ArtifactCollectionVersion.composite_commit_id`` for every member
   whose ``artifact_version_id`` matches a row in the ACV table.
9. Commit the transaction.

References
----------
- SPIKE: ``docs/dev/architecture/spikes/dvcs-atomic-versioning/dvcs-atomic-versioning-findings.md``
- Repository: ``skillmeat/cache/bundle_commit_repository.py``
- Hash utility: ``skillmeat/core/cas/hash_utils.py``
- Models: ``skillmeat/cache/models.py``
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from skillmeat.cache.bundle_commit_repository import BundleCommitRepository
from skillmeat.cache.models import (
    Artifact,
    ArtifactCollectionVersion,
    ArtifactVersion,
    BundleCommit,
)
from skillmeat.cache.repositories import RepositoryError
from skillmeat.core.cas.hash_utils import compute_bundle_hash
from skillmeat.core.schemas.bundle_commit import ConflictEntry, RollbackPreview

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Valid change origins (mirrors BundleCommit DB constraint)
# ---------------------------------------------------------------------------
_VALID_CHANGE_ORIGINS = frozenset({"manual", "sync", "deploy", "capture", "rollback"})

# ---------------------------------------------------------------------------
# Domain exceptions
# ---------------------------------------------------------------------------


class CompositeNotFoundError(ValueError):
    """Raised when ``composite_artifact_id`` does not exist in the artifacts table.

    Args:
        composite_artifact_id: The ID that could not be resolved.

    Example:
        >>> raise CompositeNotFoundError("bundle:my-plugin")
        CompositeNotFoundError: Composite artifact not found: 'bundle:my-plugin'
    """

    def __init__(self, composite_artifact_id: str) -> None:
        self.composite_artifact_id = composite_artifact_id
        super().__init__(
            f"Composite artifact not found: {composite_artifact_id!r}. "
            "The artifact must exist in the cache before a BundleCommit can be created."
        )


# ---------------------------------------------------------------------------
# Service class
# ---------------------------------------------------------------------------


class BundleCommitService:
    """Service for atomic composite versioning via BundleCommit.

    Orchestrates the SERIALIZABLE transaction boundary for composite snapshot
    creation.  Accepts a session via constructor injection; the caller is
    responsible for committing or rolling back the transaction.

    Args:
        session: Active SQLAlchemy ORM session (local / SQLite backend).

    Example::

        from sqlalchemy.orm import Session
        from skillmeat.core.services.bundle_commit_service import BundleCommitService

        svc = BundleCommitService(session)
        commit = svc.create(
            composite_artifact_id="composite:my-plugin",
            composite_type="plugin",
            member_versions=[
                {
                    "artifact_id": "skill:canvas",
                    "artifact_uuid": "abc123...",
                    "artifact_version_id": "ver1...",
                    "content_hash": "deadbeef...",
                },
            ],
            change_origin="manual",
            message="Initial snapshot",
            created_by="alice",
        )
        session.commit()
    """

    def __init__(self, session: Session) -> None:
        """Initialise the service with an injected session.

        Args:
            session: An active SQLAlchemy session.  The caller controls the
                transaction lifecycle (commit / rollback / close).
        """
        self.session = session
        self.repo = BundleCommitRepository(session)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def create(
        self,
        composite_artifact_id: str,
        composite_type: str,
        member_versions: List[Dict[str, Any]],
        change_origin: str = "manual",
        message: Optional[str] = None,
        created_by: Optional[str] = None,
    ) -> BundleCommit:
        """Create an atomic composite snapshot.

        Algorithm (DVCS SPIKE § 5):

        1. Validate ``member_versions`` is non-empty and ``change_origin`` is
           one of ``manual | sync | deploy | capture | rollback``.
        2. Assert ``composite_artifact_id`` exists in the ``artifacts`` table.
        3. Compute ``bundle_hash`` from ``member_versions``.
        4. Check idempotency: if an identical hash already exists for this
           composite, return the existing :class:`BundleCommit` (no-op).
        5. Set ``SERIALIZABLE`` isolation on the connection.
        6. Resolve ``parent_id`` to the latest commit for this composite
           (``None`` for the first commit).
        7. Insert :class:`BundleCommit` + :class:`BundleCommitMember` rows via
           :meth:`BundleCommitRepository.create_with_members`.
        8. Update :attr:`ArtifactCollectionVersion.composite_commit_id` for
           every member whose ``artifact_version_id`` appears in the ACV table.

        Args:
            composite_artifact_id: ``type:name`` primary key (or UUID) of the
                composite artifact that owns this snapshot.  Must already exist
                in the ``artifacts`` table.
            composite_type: Artifact type label (e.g. ``"plugin"``,
                ``"context_module"``, ``"bundle"``).
            member_versions: Non-empty list of member dicts.  Each entry must
                contain:

                - ``artifact_id`` (str): Human-readable ``type:name`` key.
                - ``artifact_uuid`` (str): Stable UUID from ``artifacts.uuid``.
                - ``artifact_version_id`` (str): FK to ``artifact_versions.id``.
                - ``content_hash`` (str): SHA-256 snapshot at commit time.

            change_origin: Event that triggered this snapshot.  One of
                ``manual``, ``sync``, ``deploy``, ``capture``, ``rollback``.
                Defaults to ``"manual"``.
            message: Optional human-readable description for this commit.
            created_by: Optional actor identifier (username / agent label).

        Returns:
            :class:`~skillmeat.cache.models.BundleCommit` with ``members``
            eagerly loaded.  When an identical hash already exists, returns the
            cached commit without writing any new rows.

        Raises:
            ValueError: When ``member_versions`` is empty or ``change_origin``
                is not a recognised value.
            CompositeNotFoundError: When ``composite_artifact_id`` does not
                exist in the ``artifacts`` table.
            RepositoryError: On unexpected database errors during insert.

        Example::

            commit = svc.create(
                composite_artifact_id="composite:my-plugin",
                composite_type="plugin",
                member_versions=[
                    {
                        "artifact_id": "skill:canvas",
                        "artifact_uuid": "abc123...",
                        "artifact_version_id": "ver1...",
                        "content_hash": "deadbeef...",
                    },
                ],
                change_origin="sync",
                message="Synced from upstream",
            )
        """
        try:
            from skillmeat.observability.tracing import trace_operation

            _trace = trace_operation
        except ImportError:
            from contextlib import nullcontext

            _trace = lambda *a, **kw: nullcontext()  # noqa: E731

        with _trace(
            "bundle_commit_service.create",
            composite_artifact_id=composite_artifact_id,
            composite_type=composite_type,
            change_origin=change_origin,
        ) as span:
            result = self._create(
                composite_artifact_id=composite_artifact_id,
                composite_type=composite_type,
                member_versions=member_versions,
                change_origin=change_origin,
                message=message,
                created_by=created_by,
                span=span,
            )
            return result

    def rollback(
        self,
        commit_id: str,
        dry_run: bool = True,
        message: Optional[str] = None,
        created_by: Optional[str] = None,
    ) -> RollbackPreview:
        """Rollback to a previous bundle commit state.

        Uses the "forward commit" pattern: rollback NEVER rewrites history.
        It creates a new :class:`~skillmeat.cache.models.BundleCommit` with
        ``is_rollback=1`` and ``rolled_back_to=commit_id`` that represents the
        restored state.

        Algorithm:

        1. Load the target commit (``commit_id``) with its members.
        2. For each member in the snapshot, fetch the *current* latest
           :class:`~skillmeat.cache.models.ArtifactVersion` for that artifact.
        3. Compare ``current_version.content_hash`` vs ``member.content_hash``:

           - **Same hash** → member is *clean* (already at target state).
           - **Different hash** → member is *conflicted* (has changed since snapshot).

        4. If ``dry_run=True``: return :class:`~skillmeat.core.schemas.bundle_commit.RollbackPreview`
           with conflict report — no DB changes are made.
        5. If ``dry_run=False``:

           a. Call :meth:`create` with ``change_origin='rollback'`` and the
              target commit's member list (both clean and conflicted members are
              included — the new commit records the TARGET state we want to restore).
           b. Set ``is_rollback=1`` and ``rolled_back_to=commit_id`` on the new
              commit directly (``create()`` does not expose these fields).
           c. Flush the session so the updated row is visible within the
              transaction.

        Args:
            commit_id: Primary key of the ``BundleCommit`` to roll back *to*.
            dry_run: When ``True`` (default), perform conflict analysis only and
                make no DB changes.  When ``False``, create the rollback commit.
            message: Optional human-readable message for the rollback commit.
                Defaults to an auto-generated description when ``None``.
            created_by: Optional actor identifier (username / agent label).

        Returns:
            :class:`~skillmeat.core.schemas.bundle_commit.RollbackPreview` with
            the conflict analysis and, when ``dry_run=False``, the new commit ID.

        Raises:
            ValueError: When ``commit_id`` does not exist in the database.
            RepositoryError: On unexpected database errors.

        Example::

            # Dry-run first to inspect conflicts
            preview = svc.rollback("abc123", dry_run=True)
            if not preview.conflicted_members:
                # Safe to proceed — no conflicts
                result = svc.rollback("abc123", dry_run=False, message="Restore v1")
                session.commit()
        """
        try:
            from skillmeat.observability.tracing import trace_operation

            _trace = trace_operation
        except ImportError:
            from contextlib import nullcontext

            _trace = lambda *a, **kw: nullcontext()  # noqa: E731

        with _trace(
            "bundle_commit_service.rollback",
            commit_id=commit_id,
            dry_run=dry_run,
        ) as span:
            result = self._rollback(
                commit_id=commit_id,
                dry_run=dry_run,
                message=message,
                created_by=created_by,
                span=span,
            )
            return result

    # ------------------------------------------------------------------
    # Internal implementation
    # ------------------------------------------------------------------

    def _create(
        self,
        composite_artifact_id: str,
        composite_type: str,
        member_versions: List[Dict[str, Any]],
        change_origin: str,
        message: Optional[str],
        created_by: Optional[str],
        span: Any = None,
    ) -> BundleCommit:
        """Internal create implementation (called inside tracing context).

        Separated from ``create()`` so that the tracing wrapper remains thin
        and the core logic is testable without tracing overhead.
        """
        # ------------------------------------------------------------------
        # Step 1: Validate inputs
        # ------------------------------------------------------------------
        if not member_versions:
            raise ValueError(
                "member_versions must not be empty. "
                "A BundleCommit requires at least one member artifact."
            )

        if change_origin not in _VALID_CHANGE_ORIGINS:
            raise ValueError(
                f"Invalid change_origin {change_origin!r}. "
                f"Must be one of: {sorted(_VALID_CHANGE_ORIGINS)}"
            )

        # ------------------------------------------------------------------
        # Step 2: Assert composite artifact exists
        # ------------------------------------------------------------------
        self._assert_composite_exists(composite_artifact_id)

        # ------------------------------------------------------------------
        # Step 3: Compute bundle_hash
        # ------------------------------------------------------------------
        bundle_hash = compute_bundle_hash(member_versions)
        logger.debug(
            "BundleCommitService.create: computed bundle_hash=%s for composite=%s",
            bundle_hash,
            composite_artifact_id,
        )

        if span is not None:
            try:
                span.set_attribute("bundle_hash", bundle_hash)
                span.set_attribute("member_count", len(member_versions))
            except Exception:
                pass

        # ------------------------------------------------------------------
        # Step 4: Idempotency check — return existing if hash matches
        # ------------------------------------------------------------------
        existing = self.repo.find_by_hash(composite_artifact_id, bundle_hash)
        if existing is not None:
            logger.info(
                "BundleCommitService.create: idempotent — returning existing "
                "commit_id=%s composite=%s bundle_hash=%s",
                existing.id,
                composite_artifact_id,
                bundle_hash,
            )
            return existing

        # ------------------------------------------------------------------
        # Step 5: Set SERIALIZABLE isolation on the connection (before reads
        # that feed into the insert, so the sequence-number allocation is
        # atomic with the insert).
        # ------------------------------------------------------------------
        try:
            self.session.connection().execution_options(isolation_level="SERIALIZABLE")
        except Exception as exc:
            # Some backends (e.g. in-memory SQLite used in unit tests) may not
            # support runtime isolation-level changes.  Log a warning and
            # continue — the caller is responsible for any isolation guarantees
            # in that environment.
            logger.warning(
                "BundleCommitService.create: could not set SERIALIZABLE "
                "isolation (%s) — proceeding without it.",
                exc,
            )

        # ------------------------------------------------------------------
        # Step 6: Resolve parent_id (latest commit before this one)
        # ------------------------------------------------------------------
        parent = self.repo.get_latest(composite_artifact_id)
        parent_id: Optional[str] = parent.id if parent is not None else None

        # ------------------------------------------------------------------
        # Step 7: Insert BundleCommit + BundleCommitMembers
        # ------------------------------------------------------------------
        commit_id = uuid.uuid4().hex
        commit_data: Dict[str, Any] = {
            "id": commit_id,
            "composite_artifact_id": composite_artifact_id,
            "composite_type": composite_type,
            "bundle_hash": bundle_hash,
            "parent_id": parent_id,
            "change_origin": change_origin,
            "message": message,
            "created_by": created_by,
        }

        commit = self.repo.create_with_members(
            commit_data=commit_data,
            members=member_versions,
        )

        logger.info(
            "BundleCommitService.create: created commit_id=%s composite=%s "
            "sequence=%d parent_id=%s members=%d",
            commit.id,
            composite_artifact_id,
            commit.sequence_number,
            parent_id,
            len(member_versions),
        )

        # ------------------------------------------------------------------
        # Step 8: Update ArtifactCollectionVersion.composite_commit_id
        # ------------------------------------------------------------------
        self._update_acv_composite_commit(
            commit_id=commit.id,
            member_versions=member_versions,
        )

        return commit

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _assert_composite_exists(self, composite_artifact_id: str) -> None:
        """Assert the composite artifact exists in the ``artifacts`` table.

        Args:
            composite_artifact_id: ``type:name`` primary key of the composite.

        Raises:
            CompositeNotFoundError: When no matching artifact row is found.
        """
        from skillmeat.cache.models import Artifact

        exists = (
            self.session.query(Artifact.id)
            .filter(Artifact.id == composite_artifact_id)
            .first()
        )
        if exists is None:
            raise CompositeNotFoundError(composite_artifact_id)

    def _update_acv_composite_commit(
        self,
        commit_id: str,
        member_versions: List[Dict[str, Any]],
    ) -> None:
        """Update ``composite_commit_id`` on matching ArtifactCollectionVersion rows.

        For each member in ``member_versions``, find the
        :class:`ArtifactCollectionVersion` row whose ``version_id`` matches
        ``member["artifact_version_id"]`` and stamp it with the new
        ``commit_id``.

        This is a best-effort update: if no ACV row exists for a given
        ``artifact_version_id`` (e.g. for artifacts not yet in the collection),
        the member is silently skipped and a debug log is emitted.

        Args:
            commit_id: The newly created :class:`BundleCommit` primary key.
            member_versions: Member list passed to :meth:`create`.
        """
        version_ids = [
            m["artifact_version_id"]
            for m in member_versions
            if m.get("artifact_version_id")
        ]
        if not version_ids:
            return

        acv_rows = (
            self.session.query(ArtifactCollectionVersion)
            .filter(ArtifactCollectionVersion.version_id.in_(version_ids))
            .all()
        )

        updated_ids = set()
        for acv in acv_rows:
            acv.composite_commit_id = commit_id
            self.session.add(acv)
            updated_ids.add(acv.version_id)

        # Log any member version_ids that had no ACV row
        missing = set(version_ids) - updated_ids
        if missing:
            logger.debug(
                "BundleCommitService._update_acv_composite_commit: "
                "no ACV rows found for version_ids=%s (commit_id=%s) — skipped.",
                sorted(missing),
                commit_id,
            )

        self.session.flush()
        logger.debug(
            "BundleCommitService._update_acv_composite_commit: "
            "updated %d ACV rows with composite_commit_id=%s",
            len(acv_rows),
            commit_id,
        )

    def _rollback(
        self,
        commit_id: str,
        dry_run: bool,
        message: Optional[str],
        created_by: Optional[str],
        span: Any = None,
    ) -> RollbackPreview:
        """Internal rollback implementation (called inside tracing context).

        Separated from ``rollback()`` so the tracing wrapper stays thin and the
        core logic is testable without tracing overhead.
        """
        # ------------------------------------------------------------------
        # Step 1: Load the target commit with its members
        # ------------------------------------------------------------------
        target_commit = (
            self.session.query(BundleCommit)
            .filter(BundleCommit.id == commit_id)
            .first()
        )
        if target_commit is None:
            raise ValueError(
                f"BundleCommit not found: {commit_id!r}. "
                "Cannot roll back to a commit that does not exist."
            )

        # Eagerly resolve members to avoid lazy-load issues during dry-run
        members = list(target_commit.members)

        logger.debug(
            "BundleCommitService.rollback: target commit_id=%s members=%d dry_run=%s",
            commit_id,
            len(members),
            dry_run,
        )

        if span is not None:
            try:
                span.set_attribute("target_commit_id", commit_id)
                span.set_attribute("member_count", len(members))
                span.set_attribute("dry_run", dry_run)
            except Exception:
                pass

        # ------------------------------------------------------------------
        # Step 2: Conflict detection — compare snapshot hashes to current
        # ------------------------------------------------------------------
        clean_uuids: List[str] = []
        conflicted_entries: List[ConflictEntry] = []

        for member in members:
            current_version = self._get_current_version_for_uuid(member.artifact_uuid)

            if current_version is None:
                # Artifact has no version history at all — treat as clean
                # (member can be included in the rollback commit as-is).
                logger.debug(
                    "BundleCommitService.rollback: no current version for "
                    "artifact_uuid=%s — treating as clean",
                    member.artifact_uuid,
                )
                clean_uuids.append(member.artifact_uuid)
                continue

            if current_version.content_hash == member.content_hash:
                clean_uuids.append(member.artifact_uuid)
            else:
                conflicted_entries.append(
                    ConflictEntry(
                        artifact_uuid=member.artifact_uuid,
                        artifact_id=member.artifact_id,
                        snapshot_content_hash=member.content_hash,
                        current_content_hash=current_version.content_hash,
                        current_version_id=current_version.id,
                    )
                )

        logger.info(
            "BundleCommitService.rollback: conflict analysis commit_id=%s "
            "clean=%d conflicted=%d dry_run=%s",
            commit_id,
            len(clean_uuids),
            len(conflicted_entries),
            dry_run,
        )

        if span is not None:
            try:
                span.set_attribute("clean_count", len(clean_uuids))
                span.set_attribute("conflict_count", len(conflicted_entries))
            except Exception:
                pass

        # ------------------------------------------------------------------
        # Step 3: Dry-run early return — no DB modifications
        # ------------------------------------------------------------------
        if dry_run:
            return RollbackPreview(
                commit_id=commit_id,
                target_commit_id=commit_id,
                clean_members=clean_uuids,
                conflicted_members=conflicted_entries,
                total_members=len(members),
                bundle_hash=target_commit.bundle_hash,
                is_dry_run=True,
                new_commit_id=None,
            )

        # ------------------------------------------------------------------
        # Step 4: Execute rollback — create a new forward commit
        # ------------------------------------------------------------------
        # Build member_versions list from the target commit's members.
        # Both clean and conflicted members are included: the new commit
        # records the TARGET state we want, regardless of current divergence.
        rollback_member_versions: List[Dict[str, Any]] = [
            {
                "artifact_id": m.artifact_id,
                "artifact_uuid": m.artifact_uuid,
                "artifact_version_id": m.artifact_version_id,
                "content_hash": m.content_hash,
            }
            for m in members
        ]

        auto_message = (
            message if message is not None else f"Rollback to commit {commit_id[:8]}"
        )

        new_commit = self.create(
            composite_artifact_id=target_commit.composite_artifact_id,
            composite_type=target_commit.composite_type,
            member_versions=rollback_member_versions,
            change_origin="rollback",
            message=auto_message,
            created_by=created_by,
        )

        # Stamp the rollback-specific fields that create() does not set.
        new_commit.is_rollback = 1
        new_commit.rolled_back_to = commit_id
        self.session.add(new_commit)
        self.session.flush()

        logger.info(
            "BundleCommitService.rollback: created rollback commit new_id=%s "
            "target_id=%s composite=%s",
            new_commit.id,
            commit_id,
            target_commit.composite_artifact_id,
        )

        if span is not None:
            try:
                span.set_attribute("new_commit_id", new_commit.id)
            except Exception:
                pass

        return RollbackPreview(
            commit_id=commit_id,
            target_commit_id=commit_id,
            clean_members=clean_uuids,
            conflicted_members=conflicted_entries,
            total_members=len(members),
            bundle_hash=target_commit.bundle_hash,
            is_dry_run=False,
            new_commit_id=new_commit.id,
        )

    def _get_current_version_for_uuid(
        self, artifact_uuid: str
    ) -> Optional[ArtifactVersion]:
        """Return the current latest ArtifactVersion for a given artifact UUID.

        Bridges the UUID-based identity in ``BundleCommitMember`` to the
        ``artifact_id``-keyed ``artifact_versions`` table via a join through
        ``artifacts``.

        The "current" version is defined as the most recently created
        :class:`~skillmeat.cache.models.ArtifactVersion` for the artifact,
        ordered by ``created_at DESC``.  Ghost versions
        (``is_ghost=True``) are excluded — they represent upstream changes not
        yet pulled into the collection and should not influence conflict analysis
        for local rollback operations.

        Args:
            artifact_uuid: The ``artifacts.uuid`` value (32-char hex).

        Returns:
            The latest non-ghost :class:`~skillmeat.cache.models.ArtifactVersion`
            for the artifact, or ``None`` if no versions exist.
        """
        result = (
            self.session.query(ArtifactVersion)
            .join(Artifact, Artifact.id == ArtifactVersion.artifact_id)
            .filter(Artifact.uuid == artifact_uuid)
            .filter(
                (ArtifactVersion.is_ghost == False)  # noqa: E712
                | (ArtifactVersion.is_ghost == None)  # noqa: E711
            )
            .order_by(ArtifactVersion.created_at.desc())
            .first()
        )
        return result
