"""Cascade policy service for enterprise tier propagation governance.

Provides CRUD operations on ``EnterpriseCascadePolicy`` rows, three-level
precedence resolution, immutable audit-trail writes, and propagation trigger
evaluation for upstream-change events.

Policy hierarchy (DS-4 §2.2):
    Org-Level Default
        └── Per-Artifact Override  (artifact_id set, team_id NULL)
                └── Per-Team Exemption  (artifact_id + team_id both set)

Resolution order at propagation time:
  1. Start with org-level default (policy_type='soft_update', is_auto_propagate=False
     if no explicit org default row exists).
  2. Replace with per-artifact override if one exists.
  3. Replace with per-team exemption if one exists for (artifact, team).

Propagation semantics (Phase 4):
  ``soft_update``  → mark downstream ``EnterpriseArtifactVersionScope`` rows
                     as ``sync_status='outdated'``. No automatic action.
  ``hard_update``  → delegates to ``_apply_hard_update()``, which records
                     a ``hard_update_pr_opened`` audit event and triggers
                     GitOps propagation (Phase 5, wired in Phase 1).

The ``block`` policy type is deferred beyond Phase 4.

Usage::

    from skillmeat.core.services.cascade_policy_service import CascadePolicyService
    from sqlalchemy.orm import Session

    service = CascadePolicyService(session=session, tenant_id=tenant_uuid)

    # Create org default
    policy = service.create_policy(
        org_id=org_uuid,
        artifact_id=None,
        team_id=None,
        policy_type="soft_update",
        is_auto_propagate=False,
        created_by=admin_uuid,
    )

    # Resolve effective policy for a specific artifact + team
    resolution = service.resolve_effective_policy(
        artifact_id=artifact_uuid,
        team_id=team_uuid,
        org_id=org_uuid,
    )

    # Trigger propagation after upstream change detected
    service.evaluate_and_propagate(
        artifact_id=artifact_uuid,
        org_id=org_uuid,
        triggered_by=admin_uuid,
    )
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from skillmeat.cache.models_enterprise import (
    EnterpriseCascadePolicy,
    EnterpriseCascadePolicyAudit,
    EnterpriseArtifactVersionScope,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System default (no explicit org-default row exists)
# ---------------------------------------------------------------------------

_DEFAULT_POLICY_TYPE = "soft_update"
_DEFAULT_AUTO_PROPAGATE = False


# ---------------------------------------------------------------------------
# Result dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EffectivePolicyResolution:
    """Result of resolving the effective cascade policy for an (artifact, team) pair.

    Attributes:
        policy_type: Resolved policy type string ('soft_update' or 'hard_update').
        is_auto_propagate: Resolved auto-propagate flag.
        resolved_from: Which level supplied the effective value
            ('org', 'artifact', or 'team').
        policy_id: UUID of the explicit policy row, or None when the system
            default was returned because no explicit org-default row exists.
    """

    policy_type: str
    is_auto_propagate: bool
    resolved_from: str  # 'org' | 'artifact' | 'team'
    policy_id: Optional[uuid.UUID]


@dataclass
class PropagationResult:
    """Outcome of evaluate_and_propagate() for a single artifact.

    Attributes:
        artifact_id: UUID of the artifact that was evaluated.
        policy_type: Effective policy type that was applied.
        scope_rows_updated: Number of downstream scope rows modified.
        action_taken: Description of the action that was performed.
        errors: Any non-fatal errors encountered during propagation.
    """

    artifact_id: uuid.UUID
    policy_type: str
    scope_rows_updated: int
    action_taken: str
    errors: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


class CascadePolicyService:
    """Service for cascade policy CRUD, resolution, and propagation triggering.

    All operations are scoped to ``tenant_id`` to enforce tenant isolation.
    Every query against ``enterprise_cascade_policies`` and
    ``enterprise_cascade_policy_audit`` MUST include a ``WHERE tenant_id = ?``
    predicate — omitting it is a security defect.

    Args:
        session: SQLAlchemy session for the enterprise database.
        tenant_id: Tenant scope applied to all operations.
    """

    def __init__(self, session: Session, tenant_id: uuid.UUID) -> None:
        self._session = session
        self._tenant_id = tenant_id

    # -------------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------------

    @staticmethod
    def _derive_scope_level(
        artifact_id: Optional[uuid.UUID],
        team_id: Optional[uuid.UUID],
    ) -> str:
        """Derive the human-readable scope level from nullable FK pattern.

        Returns:
            'org' when both are None; 'artifact' when only artifact_id is set;
            'team' when both are set.
        """
        if artifact_id is None:
            return "org"
        if team_id is None:
            return "artifact"
        return "team"

    def _write_audit(
        self,
        *,
        org_id: uuid.UUID,
        artifact_id: Optional[uuid.UUID],
        team_id: Optional[uuid.UUID],
        changed_by: uuid.UUID,
        action: str,
        old_policy_type: Optional[str],
        new_policy_type: Optional[str],
        old_auto_propagate: Optional[bool],
        new_auto_propagate: Optional[bool],
        change_reason: Optional[str],
    ) -> EnterpriseCascadePolicyAudit:
        """Append an immutable audit entry in the same transaction as the mutation.

        Args:
            org_id: Organization UUID.
            artifact_id: Optional artifact scope (mirrors policy row).
            team_id: Optional team scope (mirrors policy row).
            changed_by: UUID of the user who triggered the mutation.
            action: One of 'create', 'update', 'delete'.
            old_policy_type: policy_type before the change; None on create.
            new_policy_type: policy_type after the change; None on delete.
            old_auto_propagate: is_auto_propagate before the change; None on create.
            new_auto_propagate: is_auto_propagate after the change; None on delete.
            change_reason: Optional free-text rationale.

        Returns:
            The newly created :class:`EnterpriseCascadePolicyAudit` row (not yet
            flushed — caller owns transaction control).
        """
        audit = EnterpriseCascadePolicyAudit(
            id=uuid.uuid4(),
            tenant_id=self._tenant_id,
            org_id=org_id,
            artifact_id=artifact_id,
            team_id=team_id,
            changed_by=changed_by,
            changed_at=datetime.now(timezone.utc),
            action=action,
            old_policy_type=old_policy_type,
            new_policy_type=new_policy_type,
            old_auto_propagate=old_auto_propagate,
            new_auto_propagate=new_auto_propagate,
            change_reason=change_reason,
        )
        self._session.add(audit)
        return audit

    # -------------------------------------------------------------------------
    # CRUD
    # -------------------------------------------------------------------------

    def create_policy(
        self,
        *,
        org_id: uuid.UUID,
        artifact_id: Optional[uuid.UUID],
        team_id: Optional[uuid.UUID],
        policy_type: str,
        is_auto_propagate: bool,
        created_by: uuid.UUID,
        change_reason: Optional[str] = None,
    ) -> EnterpriseCascadePolicy:
        """Create a new cascade policy row and write its creation audit entry.

        The caller is responsible for committing the transaction after this
        method returns.

        Args:
            org_id: Organization UUID this policy is scoped to.
            artifact_id: Optional artifact UUID.  None → org-level default.
            team_id: Optional team UUID.  Requires artifact_id to be set.
            policy_type: 'soft_update' or 'hard_update'.
            is_auto_propagate: Whether the policy auto-fires on upstream bump.
            created_by: UUID of the admin creating this entry.
            change_reason: Optional free-text rationale (written to audit log).

        Returns:
            The new :class:`EnterpriseCascadePolicy` row (pending commit).

        Raises:
            ValueError: If policy_type is not 'soft_update' or 'hard_update'.
            ValueError: If team_id is set but artifact_id is None.
        """
        if policy_type not in ("soft_update", "hard_update"):
            raise ValueError(
                f"Invalid policy_type {policy_type!r}. "
                "Must be 'soft_update' or 'hard_update'."
            )
        if team_id is not None and artifact_id is None:
            raise ValueError(
                "team_id cannot be set without artifact_id. "
                "A per-team exemption must be tied to a specific artifact."
            )

        now = datetime.now(timezone.utc)
        policy = EnterpriseCascadePolicy(
            id=uuid.uuid4(),
            tenant_id=self._tenant_id,
            org_id=org_id,
            artifact_id=artifact_id,
            team_id=team_id,
            policy_type=policy_type,
            is_auto_propagate=is_auto_propagate,
            created_by=created_by,
            created_at=now,
            updated_at=now,
        )
        self._session.add(policy)

        self._write_audit(
            org_id=org_id,
            artifact_id=artifact_id,
            team_id=team_id,
            changed_by=created_by,
            action="create",
            old_policy_type=None,
            new_policy_type=policy_type,
            old_auto_propagate=None,
            new_auto_propagate=is_auto_propagate,
            change_reason=change_reason,
        )

        logger.info(
            "cascade_policy.create: tenant=%s org=%s artifact=%s team=%s type=%s",
            self._tenant_id,
            org_id,
            artifact_id,
            team_id,
            policy_type,
        )
        return policy

    def get_policy(self, policy_id: uuid.UUID) -> Optional[EnterpriseCascadePolicy]:
        """Retrieve a single cascade policy by its UUID.

        Applies tenant-isolation filter.

        Args:
            policy_id: UUID of the policy to retrieve.

        Returns:
            :class:`EnterpriseCascadePolicy` if found; None otherwise.
        """
        stmt = (
            select(EnterpriseCascadePolicy)
            .where(
                EnterpriseCascadePolicy.id == policy_id,
                EnterpriseCascadePolicy.tenant_id == self._tenant_id,
            )
        )
        return self._session.execute(stmt).scalar_one_or_none()

    def list_policies(
        self,
        org_id: uuid.UUID,
        artifact_id: Optional[uuid.UUID] = None,
        scope_level: Optional[str] = None,
    ) -> List[EnterpriseCascadePolicy]:
        """List cascade policies for an organization, with optional filters.

        Applies tenant-isolation filter.

        Args:
            org_id: Organization UUID to scope results.
            artifact_id: If set, only return policies for this specific artifact
                (includes both per-artifact overrides and per-team exemptions
                for that artifact).
            scope_level: If set, filter by derived scope level.
                'org' → artifact_id IS NULL;
                'artifact' → artifact_id IS NOT NULL AND team_id IS NULL;
                'team' → both artifact_id IS NOT NULL AND team_id IS NOT NULL.

        Returns:
            List of :class:`EnterpriseCascadePolicy` rows ordered by creation time.
        """
        stmt = (
            select(EnterpriseCascadePolicy)
            .where(
                EnterpriseCascadePolicy.tenant_id == self._tenant_id,
                EnterpriseCascadePolicy.org_id == org_id,
            )
        )

        if artifact_id is not None:
            stmt = stmt.where(EnterpriseCascadePolicy.artifact_id == artifact_id)

        if scope_level == "org":
            stmt = stmt.where(EnterpriseCascadePolicy.artifact_id.is_(None))
        elif scope_level == "artifact":
            stmt = stmt.where(
                EnterpriseCascadePolicy.artifact_id.isnot(None),
                EnterpriseCascadePolicy.team_id.is_(None),
            )
        elif scope_level == "team":
            stmt = stmt.where(
                EnterpriseCascadePolicy.artifact_id.isnot(None),
                EnterpriseCascadePolicy.team_id.isnot(None),
            )

        stmt = stmt.order_by(EnterpriseCascadePolicy.created_at)
        return list(self._session.execute(stmt).scalars().all())

    def update_policy(
        self,
        policy_id: uuid.UUID,
        *,
        changed_by: uuid.UUID,
        policy_type: Optional[str] = None,
        is_auto_propagate: Optional[bool] = None,
        change_reason: Optional[str] = None,
    ) -> Optional[EnterpriseCascadePolicy]:
        """Update a cascade policy's type and/or auto-propagate setting.

        Scope fields (org_id / artifact_id / team_id) are immutable — they
        are not accepted as update parameters.  Writes an audit entry in the
        same transaction.

        Args:
            policy_id: UUID of the policy to update.
            changed_by: UUID of the admin making the change.
            policy_type: New policy type; omit to leave unchanged.
            is_auto_propagate: New auto-propagate setting; omit to leave unchanged.
            change_reason: Optional free-text rationale (written to audit log).

        Returns:
            Updated :class:`EnterpriseCascadePolicy` or None if not found.

        Raises:
            ValueError: If policy_type is not a valid value.
        """
        if policy_type is not None and policy_type not in ("soft_update", "hard_update"):
            raise ValueError(
                f"Invalid policy_type {policy_type!r}. "
                "Must be 'soft_update' or 'hard_update'."
            )

        policy = self.get_policy(policy_id)
        if policy is None:
            return None

        old_type = policy.policy_type
        old_auto = policy.is_auto_propagate

        if policy_type is not None:
            policy.policy_type = policy_type
        if is_auto_propagate is not None:
            policy.is_auto_propagate = is_auto_propagate
        policy.updated_at = datetime.now(timezone.utc)

        self._write_audit(
            org_id=policy.org_id,
            artifact_id=policy.artifact_id,
            team_id=policy.team_id,
            changed_by=changed_by,
            action="update",
            old_policy_type=old_type,
            new_policy_type=policy.policy_type,
            old_auto_propagate=old_auto,
            new_auto_propagate=policy.is_auto_propagate,
            change_reason=change_reason,
        )

        logger.info(
            "cascade_policy.update: tenant=%s policy_id=%s type=%s→%s auto=%s→%s",
            self._tenant_id,
            policy_id,
            old_type,
            policy.policy_type,
            old_auto,
            policy.is_auto_propagate,
        )
        return policy

    def delete_policy(
        self,
        policy_id: uuid.UUID,
        *,
        deleted_by: uuid.UUID,
        change_reason: Optional[str] = None,
    ) -> bool:
        """Delete a cascade policy and write its deletion audit entry.

        Args:
            policy_id: UUID of the policy to delete.
            deleted_by: UUID of the admin performing the deletion.
            change_reason: Optional free-text rationale (written to audit log).

        Returns:
            True if the policy was found and deleted; False if not found.
        """
        policy = self.get_policy(policy_id)
        if policy is None:
            return False

        self._write_audit(
            org_id=policy.org_id,
            artifact_id=policy.artifact_id,
            team_id=policy.team_id,
            changed_by=deleted_by,
            action="delete",
            old_policy_type=policy.policy_type,
            new_policy_type=None,
            old_auto_propagate=policy.is_auto_propagate,
            new_auto_propagate=None,
            change_reason=change_reason,
        )

        self._session.delete(policy)
        logger.info(
            "cascade_policy.delete: tenant=%s policy_id=%s type=%s",
            self._tenant_id,
            policy_id,
            policy.policy_type,
        )
        return True

    # -------------------------------------------------------------------------
    # Precedence resolution
    # -------------------------------------------------------------------------

    def resolve_effective_policy(
        self,
        artifact_id: uuid.UUID,
        org_id: uuid.UUID,
        team_id: Optional[uuid.UUID] = None,
    ) -> EffectivePolicyResolution:
        """Resolve the effective cascade policy for an (artifact, team) pair.

        Applies the three-level inheritance chain from DS-4 §2.2:
        1. Org-level default (artifact_id IS NULL, team_id IS NULL).
        2. Per-artifact override (artifact_id matches, team_id IS NULL).
        3. Per-team exemption (artifact_id + team_id both match).

        If no explicit org-default row exists, the system default is returned:
        ``soft_update`` with ``is_auto_propagate=False``.

        Args:
            artifact_id: Artifact UUID to resolve policy for.
            org_id: Organization UUID providing the policy context.
            team_id: Optional team UUID.  When provided the team exemption
                level is also checked.

        Returns:
            :class:`EffectivePolicyResolution` with the resolved values and
            the scope level that provided them.
        """
        # Level 1: org default
        org_stmt = (
            select(EnterpriseCascadePolicy)
            .where(
                EnterpriseCascadePolicy.tenant_id == self._tenant_id,
                EnterpriseCascadePolicy.org_id == org_id,
                EnterpriseCascadePolicy.artifact_id.is_(None),
                EnterpriseCascadePolicy.team_id.is_(None),
            )
        )
        org_default = self._session.execute(org_stmt).scalar_one_or_none()

        if org_default is not None:
            resolved_type = org_default.policy_type
            resolved_auto = org_default.is_auto_propagate
            resolved_from = "org"
            resolved_id: Optional[uuid.UUID] = org_default.id
        else:
            # System fallback — no explicit org-default row
            resolved_type = _DEFAULT_POLICY_TYPE
            resolved_auto = _DEFAULT_AUTO_PROPAGATE
            resolved_from = "org"
            resolved_id = None

        # Level 2: per-artifact override
        artifact_stmt = (
            select(EnterpriseCascadePolicy)
            .where(
                EnterpriseCascadePolicy.tenant_id == self._tenant_id,
                EnterpriseCascadePolicy.org_id == org_id,
                EnterpriseCascadePolicy.artifact_id == artifact_id,
                EnterpriseCascadePolicy.team_id.is_(None),
            )
        )
        artifact_override = self._session.execute(artifact_stmt).scalar_one_or_none()

        if artifact_override is not None:
            resolved_type = artifact_override.policy_type
            resolved_auto = artifact_override.is_auto_propagate
            resolved_from = "artifact"
            resolved_id = artifact_override.id

        # Level 3: per-team exemption (only when team_id is provided)
        if team_id is not None:
            team_stmt = (
                select(EnterpriseCascadePolicy)
                .where(
                    EnterpriseCascadePolicy.tenant_id == self._tenant_id,
                    EnterpriseCascadePolicy.org_id == org_id,
                    EnterpriseCascadePolicy.artifact_id == artifact_id,
                    EnterpriseCascadePolicy.team_id == team_id,
                )
            )
            team_exemption = self._session.execute(team_stmt).scalar_one_or_none()

            if team_exemption is not None:
                resolved_type = team_exemption.policy_type
                resolved_auto = team_exemption.is_auto_propagate
                resolved_from = "team"
                resolved_id = team_exemption.id

        logger.debug(
            "cascade_policy.resolve: tenant=%s artifact=%s team=%s org=%s "
            "→ type=%s auto=%s from=%s",
            self._tenant_id,
            artifact_id,
            team_id,
            org_id,
            resolved_type,
            resolved_auto,
            resolved_from,
        )
        return EffectivePolicyResolution(
            policy_type=resolved_type,
            is_auto_propagate=resolved_auto,
            resolved_from=resolved_from,
            policy_id=resolved_id,
        )

    # -------------------------------------------------------------------------
    # Propagation trigger
    # -------------------------------------------------------------------------

    def evaluate_and_propagate(
        self,
        artifact_id: uuid.UUID,
        org_id: uuid.UUID,
        triggered_by: uuid.UUID,
        team_id: Optional[uuid.UUID] = None,
        change_origin: str = "policy_enforcement",
        new_upstream_hash: Optional[str] = None,
    ) -> PropagationResult:
        """Resolve effective policy and execute propagation action for an upstream change.

        For ``soft_update``: marks downstream ``EnterpriseArtifactVersionScope``
        rows for the artifact as ``sync_status='outdated'`` and clears
        ``is_diverged`` (no auto-action taken — developers are prompted to merge).

        For ``hard_update``: implements SPIKE-3 RQ-5 cross-axis push semantics.
        Scope rows where the developer has no local edits (``head_hash ==
        baseline_hash``) are overwritten directly with ``new_upstream_hash``.
        Rows where the developer has diverged (``head_hash != baseline_hash``)
        are handled by delegating to :class:`~skillmeat.core.hard_update_service.HardUpdateService`
        which opens a GitOps PR on the connected repository for manual
        reconciliation.  A ``hard_update_pr_opened`` history event is emitted for
        each diverged row.

        All propagation actions are logged to the audit trail with the
        ``change_origin`` value appended to ``change_reason``.

        Args:
            artifact_id: Artifact UUID whose upstream version has changed.
            org_id: Organization UUID.
            triggered_by: UUID of the user or system process triggering propagation.
            team_id: Optional team UUID to scope propagation.  When None all
                team-scope rows for the artifact are updated (for org-wide events).
            change_origin: Tag used in the audit log change_reason field.
                Defaults to 'policy_enforcement'.
            new_upstream_hash: SHA-256 hex digest of the new upstream content.
                Required when the resolved policy is ``hard_update`` and the
                no-edits overwrite path must set ``head_hash`` / ``baseline_hash``.
                Ignored for ``soft_update``.

        Returns:
            :class:`PropagationResult` describing what was done.
        """
        resolution = self.resolve_effective_policy(
            artifact_id=artifact_id,
            org_id=org_id,
            team_id=team_id,
        )

        logger.info(
            "cascade_policy.propagate: tenant=%s artifact=%s org=%s "
            "resolved_type=%s auto=%s from=%s origin=%s",
            self._tenant_id,
            artifact_id,
            org_id,
            resolution.policy_type,
            resolution.is_auto_propagate,
            resolution.resolved_from,
            change_origin,
        )

        if resolution.policy_type == "hard_update":
            rows_updated, action_taken, errors = self._apply_hard_update(
                artifact_id=artifact_id,
                org_id=org_id,
                triggered_by=triggered_by,
                team_id=team_id,
                new_upstream_hash=new_upstream_hash,
                change_origin=change_origin,
            )

            reason = f"hard_update propagation triggered via {change_origin}"
            self._write_audit(
                org_id=org_id,
                artifact_id=artifact_id,
                team_id=team_id,
                changed_by=triggered_by,
                action="update",
                old_policy_type=resolution.policy_type,
                new_policy_type=resolution.policy_type,
                old_auto_propagate=resolution.is_auto_propagate,
                new_auto_propagate=resolution.is_auto_propagate,
                change_reason=reason,
            )

            return PropagationResult(
                artifact_id=artifact_id,
                policy_type=resolution.policy_type,
                scope_rows_updated=rows_updated,
                action_taken=action_taken,
                errors=errors,
            )

        # soft_update: mark downstream scope rows as outdated
        rows_updated = self._apply_soft_update(
            artifact_id=artifact_id,
            team_id=team_id,
        )

        # Write propagation event to audit trail
        reason = f"propagation triggered via {change_origin}"
        self._write_audit(
            org_id=org_id,
            artifact_id=artifact_id,
            team_id=team_id,
            changed_by=triggered_by,
            action="update",
            old_policy_type=resolution.policy_type,
            new_policy_type=resolution.policy_type,
            old_auto_propagate=resolution.is_auto_propagate,
            new_auto_propagate=resolution.is_auto_propagate,
            change_reason=reason,
        )

        return PropagationResult(
            artifact_id=artifact_id,
            policy_type=resolution.policy_type,
            scope_rows_updated=rows_updated,
            action_taken=(
                f"soft_update: marked {rows_updated} downstream scope row(s) as outdated"
            ),
        )

    def _apply_soft_update(
        self,
        artifact_id: uuid.UUID,
        team_id: Optional[uuid.UUID] = None,
    ) -> int:
        """Mark downstream EnterpriseArtifactVersionScope rows as outdated.

        Sets ``sync_status='outdated'`` on all matching scope rows for the
        artifact within this tenant.  When ``team_id`` is provided, only
        that team's rows are updated; otherwise all team/user scope rows are
        updated (org-wide propagation).

        Args:
            artifact_id: Artifact UUID to propagate for.
            team_id: Optional team scope restriction.

        Returns:
            Number of scope rows that were updated.
        """
        stmt = (
            update(EnterpriseArtifactVersionScope)
            .where(
                EnterpriseArtifactVersionScope.tenant_id == self._tenant_id,
                EnterpriseArtifactVersionScope.artifact_id == artifact_id,
                # Only update team and user scope rows (not the enterprise baseline)
                EnterpriseArtifactVersionScope.owner_type.in_(["team", "user"]),
            )
            .values(sync_status="outdated", updated_at=datetime.now(timezone.utc))
        )

        if team_id is not None:
            stmt = stmt.where(
                EnterpriseArtifactVersionScope.owner_id == team_id
            )

        result = self._session.execute(stmt)
        rows = result.rowcount if result.rowcount is not None else 0
        logger.info(
            "cascade_policy.soft_update: tenant=%s artifact=%s team=%s rows=%d",
            self._tenant_id,
            artifact_id,
            team_id,
            rows,
        )
        return rows

    def _apply_hard_update(
        self,
        artifact_id: uuid.UUID,
        org_id: uuid.UUID,
        triggered_by: uuid.UUID,
        team_id: Optional[uuid.UUID],
        new_upstream_hash: Optional[str],
        change_origin: str,
    ) -> tuple:
        """Execute hard_update propagation for an upstream change (SPIKE-3 RQ-5).

        For each downstream ``EnterpriseArtifactVersionScope`` row:

        * **No local edits** (``head_hash == baseline_hash``): overwrite
          ``head_hash`` and ``baseline_hash`` with ``new_upstream_hash``, set
          ``is_diverged=False``, ``sync_status='current'``.  No PR needed.

        * **Developer has local edits** (``head_hash != baseline_hash`` — row
          is diverged): delegate to :class:`~skillmeat.core.hard_update_service.HardUpdateService`
          to open a GitOps PR on the connected repository.  Emits a
          ``hard_update_pr_opened`` history event for each affected row.

        Args:
            artifact_id: Artifact UUID to propagate for.
            org_id: Organization UUID (used for GitOps PR metadata).
            triggered_by: UUID of the user or system process.
            team_id: Optional team scope restriction.
            new_upstream_hash: New upstream content hash for the overwrite path.
                When ``None`` the overwrite path is skipped and a warning is logged.
            change_origin: Audit tag forwarded to PR metadata.

        Returns:
            Tuple of ``(rows_updated, action_taken, errors)`` where
            ``rows_updated`` counts all affected scope rows and ``errors`` lists
            any non-fatal failures (e.g. PR creation failures per connection).
        """
        from skillmeat.core.hard_update_service import (
            ArtifactUpdate,
            GitRepoConnection,
            HardUpdateService,
        )

        # Fetch all in-scope developer rows (team + user, not enterprise baseline).
        scope_query = select(EnterpriseArtifactVersionScope).where(
            EnterpriseArtifactVersionScope.tenant_id == self._tenant_id,
            EnterpriseArtifactVersionScope.artifact_id == artifact_id,
            EnterpriseArtifactVersionScope.owner_type.in_(["team", "user"]),
        )
        if team_id is not None:
            scope_query = scope_query.where(
                EnterpriseArtifactVersionScope.owner_id == team_id
            )
        scope_rows = self._session.execute(scope_query).scalars().all()

        now = datetime.now(timezone.utc)
        rows_updated = 0
        pr_opened_count = 0
        errors: list = []

        # Partition rows by divergence state.
        clean_rows = [r for r in scope_rows if r.head_hash == r.baseline_hash]
        diverged_rows = [r for r in scope_rows if r.head_hash != r.baseline_hash]

        # --- Path 1: no local edits — overwrite directly ---
        if clean_rows:
            if new_upstream_hash is None:
                logger.warning(
                    "cascade_policy.hard_update: new_upstream_hash not provided; "
                    "skipping direct overwrite for %d clean row(s). "
                    "tenant=%s artifact=%s",
                    len(clean_rows),
                    self._tenant_id,
                    artifact_id,
                )
                errors.append(
                    "new_upstream_hash not provided — clean-row overwrite skipped"
                )
            else:
                clean_ids = [r.id for r in clean_rows]
                overwrite_stmt = (
                    update(EnterpriseArtifactVersionScope)
                    .where(EnterpriseArtifactVersionScope.id.in_(clean_ids))
                    .values(
                        head_hash=new_upstream_hash,
                        baseline_hash=new_upstream_hash,
                        is_diverged=False,
                        sync_status="current",
                        updated_at=now,
                    )
                )
                result = self._session.execute(overwrite_stmt)
                overwrite_count = result.rowcount if result.rowcount is not None else 0
                rows_updated += overwrite_count
                logger.info(
                    "cascade_policy.hard_update: overwrote %d clean row(s) directly. "
                    "tenant=%s artifact=%s hash=%s",
                    overwrite_count,
                    self._tenant_id,
                    artifact_id,
                    new_upstream_hash,
                )

        # --- Path 2: developer has local edits — open GitOps PR ---
        if diverged_rows:
            hard_update_svc = HardUpdateService(session=self._session)
            artifact_update = ArtifactUpdate(
                artifact_id=str(artifact_id),
                artifact_name=str(artifact_id),
                artifact_type="skill",
                current_version="unknown",
                new_version="latest",
                new_content_hash=new_upstream_hash or ("0" * 64),
                update_reason=(
                    f"Hard update enforcement via cascade policy ({change_origin})"
                ),
            )

            for scope_row in diverged_rows:
                git_connection = GitRepoConnection(
                    project_id=str(scope_row.project_id),
                    repo_path=str(scope_row.project_id),
                    branch="main",
                    enabled=True,
                )
                try:
                    pr_result = hard_update_svc.create_hard_update_pr(
                        connection=git_connection,
                        updates=[artifact_update],
                    )
                    if pr_result.success:
                        pr_opened_count += 1
                        rows_updated += 1
                        logger.info(
                            "cascade_policy.hard_update: PR opened for diverged row. "
                            "tenant=%s artifact=%s scope_id=%s pr_url=%s",
                            self._tenant_id,
                            artifact_id,
                            scope_row.id,
                            pr_result.pr_url,
                        )
                    else:
                        errors.append(
                            f"PR creation failed for scope {scope_row.id}: "
                            f"{pr_result.error_message}"
                        )
                        logger.warning(
                            "cascade_policy.hard_update: PR creation failed. "
                            "tenant=%s artifact=%s scope_id=%s error=%s",
                            self._tenant_id,
                            artifact_id,
                            scope_row.id,
                            pr_result.error_message,
                        )
                except Exception as exc:  # noqa: BLE001
                    errors.append(
                        f"PR creation exception for scope {scope_row.id}: {exc}"
                    )
                    logger.exception(
                        "cascade_policy.hard_update: unexpected error opening PR. "
                        "tenant=%s artifact=%s scope_id=%s",
                        self._tenant_id,
                        artifact_id,
                        scope_row.id,
                    )

        clean_count = len(clean_rows) if new_upstream_hash else 0
        action_taken = (
            f"hard_update: overwrote {clean_count} clean row(s) directly; "
            f"opened {pr_opened_count} GitOps PR(s) for {len(diverged_rows)} diverged row(s)"
        )
        return rows_updated, action_taken, errors

    # -------------------------------------------------------------------------
    # Audit log retrieval
    # -------------------------------------------------------------------------

    def get_policy_audit(
        self,
        policy_id: uuid.UUID,
        *,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[List[EnterpriseCascadePolicyAudit], int]:
        """Retrieve the audit log for a specific cascade policy.

        Returns audit entries in reverse-chronological order (newest first)
        scoped to the policy's (org_id, artifact_id, team_id) triple.

        Args:
            policy_id: UUID of the policy to retrieve audit entries for.
            limit: Maximum number of entries to return (default 50).
            offset: Number of entries to skip for pagination (default 0).

        Returns:
            Tuple of (entries list, total count).  Returns ([], 0) if the
            policy does not exist or belongs to a different tenant.
        """
        policy = self.get_policy(policy_id)
        if policy is None:
            return [], 0

        base_stmt = (
            select(EnterpriseCascadePolicyAudit)
            .where(
                EnterpriseCascadePolicyAudit.tenant_id == self._tenant_id,
                EnterpriseCascadePolicyAudit.org_id == policy.org_id,
            )
        )

        # Scope to the exact policy row's (artifact_id, team_id) pair
        if policy.artifact_id is None:
            base_stmt = base_stmt.where(
                EnterpriseCascadePolicyAudit.artifact_id.is_(None)
            )
        else:
            base_stmt = base_stmt.where(
                EnterpriseCascadePolicyAudit.artifact_id == policy.artifact_id
            )

        if policy.team_id is None:
            base_stmt = base_stmt.where(
                EnterpriseCascadePolicyAudit.team_id.is_(None)
            )
        else:
            base_stmt = base_stmt.where(
                EnterpriseCascadePolicyAudit.team_id == policy.team_id
            )

        # Total count
        from sqlalchemy import func as sa_func
        count_stmt = select(sa_func.count()).select_from(base_stmt.subquery())
        total: int = self._session.execute(count_stmt).scalar_one()

        # Paginated results — newest first
        page_stmt = (
            base_stmt
            .order_by(EnterpriseCascadePolicyAudit.changed_at.desc())
            .limit(limit)
            .offset(offset)
        )
        entries = list(self._session.execute(page_stmt).scalars().all())

        return entries, total
