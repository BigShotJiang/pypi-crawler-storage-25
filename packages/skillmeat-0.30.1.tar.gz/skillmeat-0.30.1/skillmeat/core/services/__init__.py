"""Core services package for SkillMeat.

This package contains business logic services that are used by API routers
and other application layers.
"""

from skillmeat.core.services.template_service import (
    DeploymentResult,
    deploy_template,
    render_content,
    validate_variables,
    ALLOWED_VARIABLES,
)
from skillmeat.core.services.content_hash import (
    compute_content_hash,
    detect_changes,
    read_file_with_hash,
    update_artifact_hash,
    verify_content_integrity,
)
from skillmeat.core.services.context_sync import (
    IContextSyncService,
    LocalContextSyncService,
    ContextSyncService,
    SyncConflict,
    SyncResult,
)
from skillmeat.core.services.artifact_service import ArtifactService
from skillmeat.core.services.collection_service import (
    CollectionService as CoreCollectionService,
)
from skillmeat.core.services.tag_service import TagService
from skillmeat.core.services.tag_write_service import TagWriteService
from skillmeat.core.services.context_module_service import ContextModuleService
from skillmeat.core.services.context_packer_service import ContextPackerService
from skillmeat.core.services.memory_service import MemoryService
from skillmeat.core.services.custom_color_service import (
    CustomColorService,
    NotFoundError as CustomColorNotFoundError,
)
from skillmeat.core.services.enterprise_content import (
    EnterpriseContentService,
    ArtifactNotFoundError as EnterpriseArtifactNotFoundError,
    ArtifactVersionNotFoundError,
    ArtifactFilesystemError,
)
from skillmeat.core.services.workflow_artifact_sync_service import (
    WorkflowArtifactSyncService,
)
from skillmeat.core.services.bundle_resolver import (
    BundleResolver,
    BundleResolutionResult,
    ResolvedArtifact,
    ResolvedContextEntity,
    BundleResolutionError,
    CircularDependencyError,
    ResolutionDepthError,
    SameTierRecursionError,
)
from skillmeat.core.services.signature_verification_service import (
    SignatureVerificationService,
    VerificationResult,
    GovernanceResult,
    SignatureStatus,
    VerificationError,
    CryptographicError,
    GovernanceError,
)

__all__ = [
    # Template service
    "DeploymentResult",
    "deploy_template",
    "render_content",
    "validate_variables",
    "ALLOWED_VARIABLES",
    # Content hash service
    "compute_content_hash",
    "detect_changes",
    "read_file_with_hash",
    "update_artifact_hash",
    "verify_content_integrity",
    # Context sync service
    "IContextSyncService",
    "LocalContextSyncService",
    "ContextSyncService",
    "SyncConflict",
    "SyncResult",
    # Core repository-wrapping services (SVR-007)
    "ArtifactService",
    "CoreCollectionService",
    # Tag service
    "TagService",
    # Tag write service (filesystem persistence)
    "TagWriteService",
    # Context module service (memory system)
    "ContextModuleService",
    # Context packer service (memory system)
    "ContextPackerService",
    # Memory service (memory system)
    "MemoryService",
    # Custom color service
    "CustomColorService",
    "CustomColorNotFoundError",
    # Enterprise content service
    "EnterpriseContentService",
    "EnterpriseArtifactNotFoundError",
    "ArtifactVersionNotFoundError",
    "ArtifactFilesystemError",
    # Workflow artifact sync service
    "WorkflowArtifactSyncService",
    # Bundle resolver (IDP scaffold dependency graph)
    "BundleResolver",
    "BundleResolutionResult",
    "ResolvedArtifact",
    "ResolvedContextEntity",
    "BundleResolutionError",
    "CircularDependencyError",
    "ResolutionDepthError",
    "SameTierRecursionError",
    # Signature verification service (DVCS-4.2)
    "SignatureVerificationService",
    "VerificationResult",
    "GovernanceResult",
    "SignatureStatus",
    "VerificationError",
    "CryptographicError",
    "GovernanceError",
]
