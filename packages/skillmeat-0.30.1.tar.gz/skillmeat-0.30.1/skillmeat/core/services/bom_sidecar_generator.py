"""BOM (Bill of Materials) sidecar generator for resolved artifact lists.

Produces a :class:`BomSidecar` that records each artifact's name, type,
optional version, and a deterministic SHA-256 content hash derived from
``ResolvedArtifact.file_content_map``.  The sidecar is intended to be
attached to IDP scaffold bundles so consumers can verify artifact integrity
and detect upstream changes without unpacking file trees.

Typical usage::

    from skillmeat.core.services.bom_sidecar_generator import BomSidecarGenerator

    sidecar = BomSidecarGenerator.generate(
        artifacts=resolved_list,
        bundle_id="my-bundle",
        bundle_version="1.0.0",
    )
    print(sidecar.model_dump_json(indent=2))
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime, timezone
from typing import List, Optional

from pydantic import BaseModel

from skillmeat.core.services.bundle_resolver import ResolvedArtifact

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Output models
# ---------------------------------------------------------------------------


class BomSidecarArtifact(BaseModel):
    """BOM entry for a single resolved artifact.

    Attributes:
        name: Human-readable artifact name.
        type: Artifact type string (e.g. ``"skill"``, ``"command"``).
        version: Optional version string.  ``None`` when no version metadata
            is available for the artifact.
        content_hash: SHA-256 hex digest of all file contents in the artifact,
            concatenated in sorted key order.  An empty artifact yields the
            SHA-256 of the empty string.
    """

    name: str
    type: str
    version: Optional[str] = None
    content_hash: str  # SHA-256 hex digest


class BomSidecar(BaseModel):
    """Bill of Materials sidecar for a scaffold bundle.

    Attributes:
        artifacts: Ordered list of BOM entries, one per resolved artifact.
        generated_at: ISO-8601 UTC timestamp marking when the sidecar was
            produced.
        bundle_id: Optional identifier of the parent bundle.  ``None`` when
            the sidecar is generated outside a named bundle context.
        bundle_version: Optional version string of the parent bundle.
    """

    artifacts: List[BomSidecarArtifact]
    generated_at: str  # ISO-8601 UTC
    bundle_id: Optional[str] = None
    bundle_version: Optional[str] = None


# ---------------------------------------------------------------------------
# Generator service
# ---------------------------------------------------------------------------


def _compute_content_hash(file_content_map: dict[str, str]) -> str:
    """Return a deterministic SHA-256 hex digest for an artifact's file set.

    File contents are concatenated in ascending key (path) order so that the
    hash is stable regardless of the order in which files were discovered.
    An empty ``file_content_map`` yields the SHA-256 of the empty string,
    which provides a consistent sentinel value for artifacts with no content.

    Args:
        file_content_map: Mapping of relative file path to UTF-8 text content.

    Returns:
        Lowercase hexadecimal SHA-256 digest string (64 characters).
    """
    concatenated = "".join(
        content for _key, content in sorted(file_content_map.items())
    )
    return hashlib.sha256(concatenated.encode("utf-8")).hexdigest()


class BomSidecarGenerator:
    """Generates a :class:`BomSidecar` from a filtered list of resolved artifacts.

    This is a stateless utility class; all public methods are static.
    """

    @staticmethod
    def generate(
        artifacts: list[ResolvedArtifact],
        bundle_id: Optional[str] = None,
        bundle_version: Optional[str] = None,
    ) -> BomSidecar:
        """Build a :class:`BomSidecar` from a list of resolved artifacts.

        For each artifact a :class:`BomSidecarArtifact` is created with:

        - ``name`` — taken directly from :attr:`ResolvedArtifact.name`.
        - ``type`` — taken directly from :attr:`ResolvedArtifact.type`.
        - ``version`` — always ``None`` (``ResolvedArtifact`` does not carry a
          version field; callers may post-process the sidecar to populate this).
        - ``content_hash`` — SHA-256 hex digest of
          :attr:`ResolvedArtifact.file_content_map` contents, keyed in sorted
          order.

        Args:
            artifacts: Ordered, deduplicated list of resolved artifacts as
                returned by :class:`~skillmeat.core.services.bundle_resolver.BundleResolver`.
            bundle_id: Optional identifier of the parent bundle.
            bundle_version: Optional version string of the parent bundle.

        Returns:
            A fully populated :class:`BomSidecar` ready for serialisation.
        """
        bom_artifacts: list[BomSidecarArtifact] = []

        for artifact in artifacts:
            content_hash = _compute_content_hash(artifact.file_content_map)
            logger.debug(
                "BOM entry: name=%s type=%s hash=%s files=%d",
                artifact.name,
                artifact.type,
                content_hash[:12],
                len(artifact.file_content_map),
            )
            bom_artifacts.append(
                BomSidecarArtifact(
                    name=artifact.name,
                    type=artifact.type,
                    version=None,
                    content_hash=content_hash,
                )
            )

        generated_at = datetime.now(timezone.utc).isoformat()

        return BomSidecar(
            artifacts=bom_artifacts,
            generated_at=generated_at,
            bundle_id=bundle_id,
            bundle_version=bundle_version,
        )
