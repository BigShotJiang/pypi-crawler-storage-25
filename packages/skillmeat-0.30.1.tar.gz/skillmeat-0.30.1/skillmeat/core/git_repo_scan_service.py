"""Git repository scan service for artifact discovery (GRC feature).

This module implements the core scan engine that discovers Claude Code artifacts
in GitHub repositories.  It is entirely stateless — all state lives in the
injected repositories — and can therefore be used both synchronously (during an
HTTP request) and from a background worker.

Artifact detection is based on the detection signals documented in
``docs/dev/architecture/artifact-type-reference.md``.  The detector covers all
17 artifact types across Tiers 0–3.

Example::

    from skillmeat.core.git_repo_scan_service import GitRepoScanService

    service = GitRepoScanService(
        connection_repo=connection_repo,
        scan_repo=scan_repo,
        artifact_repo=artifact_repo,
    )

    result = service.trigger_scan(connection_id=1, triggered_by="manual")
    scan_id = result["scan_id"]

    outcome = service.run_scan(scan_id)
"""

from __future__ import annotations

import hashlib
import logging
import re
from datetime import datetime, timezone
from typing import Any, Optional

from skillmeat.core.github_client import (
    GitHubAuthError,
    GitHubClientError,
    GitHubNotFoundError,
    GitHubRateLimitError,
    get_github_client,
)
from skillmeat.core.interfaces.repositories import (
    IGitRepoConnectionRepository,
    IGitRepoScanRepository,
    IGitScanArtifactRepository,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Artifact detection helpers
# ---------------------------------------------------------------------------

# Filename-based exact matches (case-sensitive) → artifact type
_EXACT_FILENAME_MAP: dict[str, str] = {
    "SKILL.md": "skill",
    "AGENT.md": "agent",
    "agent.md": "agent",
    "COMMAND.md": "command",
    "command.md": "command",
    "WORKFLOW.yaml": "workflow",
    "WORKFLOW.json": "workflow",
    "workflow.yaml": "workflow",
    "workflow.json": "workflow",
    "CLAUDE.md": "project_config",
    ".mcp.json": "mcp",
    "mcp.json": "mcp",
    "composite.toml": "composite",
    "COMPOSITE.md": "composite",
    "PLUGIN.md": "composite",
    "plugin.toml": "composite",
    "bundle.toml": "bundle",
    "context-pack.yaml": "context_pack",
}

# Parent directory name → artifact type (for files sitting inside these dirs)
_PARENT_DIR_MAP: dict[str, str] = {
    "skills": "skill",
    "agents": "agent",
    "subagents": "agent",
    "claude-agents": "agent",
    "commands": "command",
    "claude-commands": "command",
    "hooks": "hook",
    "claude-hooks": "hook",
    "mcp": "mcp",
    "mcp-servers": "mcp",
    "mcp_servers": "mcp",
    "claude-mcp": "mcp",
    "workflows": "workflow",
    "claude-workflows": "workflow",
    "composites": "composite",
    "plugins": "composite",
    "context-modules": "context_module",
    "bundles": "bundle",
    "context-packs": "context_pack",
}

# .claude/ sub-directory name → artifact type
_CLAUDE_SUBDIR_MAP: dict[str, str] = {
    "specs": "spec_file",
    "rules": "rule_file",
    "context": "context_file",
}

# File extension-based detection (lower-cased extension)
_WORKFLOW_EXTENSIONS = {".workflow.yaml", ".workflow.json"}


def _basename(path: str) -> str:
    """Return the final component of a repository-relative path."""
    return path.rsplit("/", 1)[-1] if "/" in path else path


def _parent_dir(path: str) -> str:
    """Return the immediate parent directory name (empty string for root files)."""
    if "/" not in path:
        return ""
    parts = path.rsplit("/", 1)
    parent_path = parts[0]
    return parent_path.rsplit("/", 1)[-1] if "/" in parent_path else parent_path


def _path_parts(path: str) -> list[str]:
    """Split a path into its directory components (excluding the basename)."""
    parts = path.split("/")
    return parts[:-1] if len(parts) > 1 else []


def _detect_artifact_type(path: str, entry: dict[str, Any]) -> Optional[str]:
    """Determine the artifact type for a single tree entry.

    Args:
        path: Repository-relative path of the entry.
        entry: Tree entry dict with at minimum ``type`` (``'blob'`` / ``'tree'``).

    Returns:
        Artifact type string (e.g. ``'skill'``, ``'agent'``) or ``None`` if the
        entry does not correspond to a known artifact.
    """
    entry_type = entry.get("type", "blob")
    filename = _basename(path)
    parent = _parent_dir(path)
    dir_parts = _path_parts(path)

    # --- Exact filename matches (blobs only) --------------------------------
    if entry_type == "blob":
        if filename in _EXACT_FILENAME_MAP:
            return _EXACT_FILENAME_MAP[filename]

        # *.workflow.yaml / *.workflow.json  (e.g. deploy.workflow.yaml)
        lower = filename.lower()
        if lower.endswith(".workflow.yaml") or lower.endswith(".workflow.json"):
            return "workflow"

        # .claude/ sub-directory scoped files (.md files only)
        if filename.endswith(".md") and ".claude" in dir_parts:
            claude_idx = len(dir_parts) - 1 - dir_parts[::-1].index(".claude")
            # Exactly one level below .claude/ (e.g. .claude/specs/foo.md)
            if claude_idx == len(dir_parts) - 2:
                subdir = dir_parts[claude_idx + 1]
                if subdir in _CLAUDE_SUBDIR_MAP:
                    return _CLAUDE_SUBDIR_MAP[subdir]

        # Hook scripts in hooks/ directories
        if parent in ("hooks", "claude-hooks") and (
            filename.endswith(".sh")
            or filename.endswith(".py")
            or filename.endswith(".js")
        ):
            return "hook"

        # MCP server JSON files in mcp directories
        if parent in (
            "mcp",
            "mcp-servers",
            "mcp_servers",
            "claude-mcp",
        ) and filename.endswith(".json"):
            return "mcp"

        # Command markdown files in commands/ directory
        if parent in ("commands", "claude-commands") and filename.endswith(".md"):
            return "command"

        # Agent markdown files in agents/ directory
        if parent in ("agents", "subagents", "claude-agents") and filename.endswith(
            ".md"
        ):
            return "agent"

    # --- Directory-based detection (trees) ----------------------------------
    if entry_type == "tree":
        # Direct parent directory name
        if parent in _PARENT_DIR_MAP:
            return _PARENT_DIR_MAP[parent]

        # Directories ending with .skillmeat-pack → bundle
        if filename.endswith(".skillmeat-pack"):
            return "bundle"

    return None


# ---------------------------------------------------------------------------
# URL parsing helper
# ---------------------------------------------------------------------------

_GITHUB_URL_RE = re.compile(
    r"^(?:https?://github\.com/|git@github\.com:)(?P<owner>[^/]+)/(?P<repo>[^/.]+?)(?:\.git)?/?$"
)


def _parse_repo_url(repo_url: str) -> str:
    """Convert a repo URL to ``owner/repo`` format.

    Accepts:
    - ``https://github.com/owner/repo``
    - ``https://github.com/owner/repo.git``
    - ``git@github.com:owner/repo.git``
    - ``owner/repo``

    Args:
        repo_url: Repository URL or ``owner/repo`` string.

    Returns:
        Normalised ``owner/repo`` string.

    Raises:
        ValueError: If the URL cannot be parsed.
    """
    stripped = repo_url.strip()

    # Already in owner/repo format (no scheme, no dots in repo)
    if re.match(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$", stripped):
        return stripped

    m = _GITHUB_URL_RE.match(stripped)
    if m:
        return f"{m.group('owner')}/{m.group('repo')}"

    raise ValueError(
        f"Cannot parse repository URL '{repo_url}'. "
        "Expected 'owner/repo', 'https://github.com/owner/repo', or SSH format."
    )


# ---------------------------------------------------------------------------
# SHA-256 content hashing
# ---------------------------------------------------------------------------


def _sha256_hex(content: bytes) -> str:
    """Return the hex-encoded SHA-256 digest of *content*."""
    return hashlib.sha256(content).hexdigest()


# ---------------------------------------------------------------------------
# GitRepoScanService
# ---------------------------------------------------------------------------


class GitRepoScanService:
    """Core scan engine for Git repository artifact discovery.

    This service is **stateless**: all persistent state is managed through the
    injected repositories.  The class is safe to instantiate once per request
    (via FastAPI DI) and can also be used from background workers.

    Responsibilities:
        - Creating scan records with idempotency guarantees.
        - Fetching the repository tree from GitHub via the centralised client.
        - Detecting artifacts by applying detection signals from the artifact
          type reference.
        - Comparing detected artifacts against the previous scan to classify
          each observation as ``new``, ``changed``, ``removed``, or
          ``unchanged``.
        - Persisting artifact observations through the repository layer.
        - Marking selected observations as indexed once they have been imported
          into the main artifact cache.

    Args:
        connection_repo: Storage backend for ``GitRepoConnection`` rows.
        scan_repo: Storage backend for ``GitRepoScan`` rows.
        artifact_repo: Storage backend for ``GitScanArtifact`` rows.
    """

    def __init__(
        self,
        connection_repo: IGitRepoConnectionRepository,
        scan_repo: IGitRepoScanRepository,
        artifact_repo: IGitScanArtifactRepository,
    ) -> None:
        self._connection_repo = connection_repo
        self._scan_repo = scan_repo
        self._artifact_repo = artifact_repo

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    def trigger_scan(
        self,
        connection_id: int | Any,
        triggered_by: str,
        trigger_sha: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new scan record (or return an existing one for idempotency).

        When *trigger_sha* is provided and a scan already exists for the same
        ``(connection_id, trigger_sha)`` pair, the existing scan is returned
        unchanged.  This prevents duplicate scans when webhooks fire more than
        once for the same push event.

        Args:
            connection_id: PK of the ``GitRepoConnection`` that should be scanned.
            triggered_by: How the scan was initiated: ``'manual'``, ``'schedule'``,
                or ``'webhook'``.
            trigger_sha: Optional 40-char git commit SHA that triggered the scan.

        Returns:
            Dictionary with keys ``scan_id`` (int) and ``status`` (str).

        Raises:
            ValueError: If *connection_id* does not exist.
        """
        connection = self._connection_repo.get_by_id(connection_id)
        if connection is None:
            raise ValueError(f"GitRepoConnection {connection_id!r} not found")

        # Idempotency: reuse existing scan for same (connection, sha)
        if trigger_sha:
            existing = self._scan_repo.get_by_connection_and_sha(
                connection_id, trigger_sha
            )
            if existing is not None:
                logger.info(
                    "Reusing existing scan %s for connection %s / sha %s",
                    existing.id,
                    connection_id,
                    trigger_sha,
                )
                return {"scan_id": existing.id, "status": existing.status}

        scan = self._scan_repo.create(
            connection_id=connection_id,
            triggered_by=triggered_by,
            trigger_sha=trigger_sha,
        )
        logger.info(
            "Created scan %s for connection %s (triggered_by=%s, sha=%s)",
            scan.id,
            connection_id,
            triggered_by,
            trigger_sha,
        )
        return {"scan_id": scan.id, "status": scan.status}

    def run_scan(
        self, scan_id: int | Any, token: Optional[str] = None
    ) -> dict[str, Any]:
        """Execute a pending scan end-to-end.

        The scan transitions: ``pending`` → ``running`` → ``completed`` /
        ``failed``.  A ``try/finally`` block guarantees that the scan is never
        left in ``running`` state regardless of the failure mode.

        Steps:
            1. Validate the scan record.
            2. Transition to ``running`` and record ``started_at``.
            3. Retrieve the parent connection for ``repo_url`` / ``branch``.
            4. Fetch the repository tree via the GitHub client.
            5. Detect artifacts by applying detection signals.
            6. For each candidate: fetch file content and compute SHA-256.
            7. Compare to the previous completed scan to classify ``change_type``.
            8. Persist observations via ``bulk_upsert``.
            9. Update aggregate counts and transition to ``completed``.

        Args:
            scan_id: PK of the ``GitRepoScan`` to execute.
            token: Optional GitHub token resolved by ``TokenResolverService``.
                When provided, it overrides the default client token for all
                GitHub API calls in this scan run.  ``None`` falls back to the
                client's built-in token resolution.

        Returns:
            Dictionary with keys ``scan_id``, ``status``, ``artifacts_found``,
            ``artifacts_new``, ``artifacts_changed``, ``artifacts_removed``.

        Raises:
            ValueError: If *scan_id* does not exist.
            GitHubRateLimitError: Re-raised after marking scan as failed.
            GitHubAuthError: Re-raised after marking scan as failed.
            GitHubNotFoundError: Re-raised after marking scan as failed.
            GitHubClientError: Re-raised after marking scan as failed.
            Exception: Any unexpected error is wrapped and re-raised after
                marking the scan as failed.
        """
        scan = self._scan_repo.get_by_id(scan_id)
        if scan is None:
            raise ValueError(f"GitRepoScan {scan_id!r} not found")

        connection = self._connection_repo.get_by_id(scan.connection_id)
        if connection is None:
            raise ValueError(
                f"GitRepoConnection {scan.connection_id!r} not found for scan {scan_id!r}"
            )

        self._scan_repo.update_status(scan_id, "running")
        logger.info(
            "Running scan %s for connection %s (%s@%s)",
            scan_id,
            connection.id,
            connection.repo_url,
            connection.branch,
        )

        try:
            owner_repo = _parse_repo_url(connection.repo_url)
            branch = connection.branch or "main"

            # ------------------------------------------------------------------
            # 1. Fetch repository tree
            # ------------------------------------------------------------------
            client = get_github_client()
            tree_entries: list[dict[str, Any]] = client.get_repo_tree(
                owner_repo, ref=branch, token=token
            )
            logger.debug(
                "Fetched %d tree entries from %s@%s",
                len(tree_entries),
                owner_repo,
                branch,
            )

            # ------------------------------------------------------------------
            # 2. Detect artifact candidates
            # ------------------------------------------------------------------
            candidates: list[dict[str, Any]] = []
            for entry in tree_entries:
                artifact_type = _detect_artifact_type(entry["path"], entry)
                if artifact_type is not None:
                    candidates.append(
                        {
                            "path": entry["path"],
                            "artifact_type": artifact_type,
                            "entry": entry,
                        }
                    )

            logger.debug(
                "Detected %d artifact candidates in scan %s",
                len(candidates),
                scan_id,
            )

            # ------------------------------------------------------------------
            # 3. Fetch content + compute hashes for blob candidates
            # ------------------------------------------------------------------
            artifact_records: list[dict[str, Any]] = []
            for candidate in candidates:
                path = candidate["path"]
                artifact_type = candidate["artifact_type"]
                entry = candidate["entry"]
                content_hash: Optional[str] = None
                detected_name: Optional[str] = None

                if entry.get("type") == "blob":
                    try:
                        content: bytes = client.get_file_content(
                            owner_repo, path, ref=branch, token=token
                        )
                        content_hash = _sha256_hex(content)
                        detected_name = _extract_name_from_content(content, path)
                    except GitHubClientError as exc:
                        logger.warning(
                            "Could not fetch content for %s in scan %s: %s",
                            path,
                            scan_id,
                            exc,
                        )
                else:
                    # Directory artifact — hash is not applicable
                    detected_name = _basename(path)

                artifact_records.append(
                    {
                        "artifact_path": path,
                        "artifact_type": artifact_type,
                        "detected_name": detected_name,
                        "content_hash": content_hash,
                    }
                )

            # ------------------------------------------------------------------
            # 4. Compare to previous scan to classify change_type
            # ------------------------------------------------------------------
            previous: dict[str, dict[str, Any]] = self.get_previous_scan_artifacts(
                connection.id, exclude_scan_id=scan_id
            )
            current_paths = {rec["artifact_path"] for rec in artifact_records}

            # Classify current artifacts
            for rec in artifact_records:
                prev = previous.get(rec["artifact_path"])
                if prev is None:
                    rec["change_type"] = "new"
                elif prev.get("content_hash") != rec["content_hash"]:
                    rec["change_type"] = "changed"
                else:
                    rec["change_type"] = "unchanged"

            # Add removed artifacts (present in previous but not in current tree)
            removed_records: list[dict[str, Any]] = []
            for prev_path, prev_data in previous.items():
                if prev_path not in current_paths:
                    removed_records.append(
                        {
                            "artifact_path": prev_path,
                            "artifact_type": prev_data.get("artifact_type", "unknown"),
                            "detected_name": prev_data.get("detected_name"),
                            "content_hash": prev_data.get("content_hash"),
                            "change_type": "removed",
                        }
                    )

            all_records = artifact_records + removed_records

            # ------------------------------------------------------------------
            # 5. Persist observations
            # ------------------------------------------------------------------
            if all_records:
                self._artifact_repo.bulk_upsert(scan_id=scan_id, artifacts=all_records)

            # ------------------------------------------------------------------
            # 6. Compute aggregate counts
            # ------------------------------------------------------------------
            count_found = len(artifact_records)
            count_new = sum(1 for r in artifact_records if r["change_type"] == "new")
            count_changed = sum(
                1 for r in artifact_records if r["change_type"] == "changed"
            )
            count_removed = len(removed_records)

            self._scan_repo.update_counts(
                scan_id,
                found=count_found,
                new=count_new,
                changed=count_changed,
                removed=count_removed,
            )
            self._scan_repo.update_status(scan_id, "completed")

            # Update last_scan_at / last_scan_id on the connection (best-effort)
            try:
                self._connection_repo.update(
                    connection.id,
                    last_scan_at=datetime.now(timezone.utc),
                    last_scan_id=scan_id,
                )
            except Exception as exc:  # pragma: no cover
                logger.warning(
                    "Could not update last_scan fields on connection %s: %s",
                    connection.id,
                    exc,
                )

            logger.info(
                "Scan %s completed: found=%d new=%d changed=%d removed=%d",
                scan_id,
                count_found,
                count_new,
                count_changed,
                count_removed,
            )
            return {
                "scan_id": scan_id,
                "status": "completed",
                "artifacts_found": count_found,
                "artifacts_new": count_new,
                "artifacts_changed": count_changed,
                "artifacts_removed": count_removed,
            }

        except (
            GitHubRateLimitError,
            GitHubAuthError,
            GitHubNotFoundError,
            GitHubClientError,
        ) as exc:
            error_msg = str(exc)
            logger.error("Scan %s failed (GitHub error): %s", scan_id, error_msg)
            self._scan_repo.update_status(scan_id, "failed", error_message=error_msg)
            raise

        except Exception as exc:
            error_msg = f"Unexpected error: {exc}"
            logger.exception("Scan %s failed (unexpected): %s", scan_id, exc)
            self._scan_repo.update_status(scan_id, "failed", error_message=error_msg)
            raise

    def index_scan(
        self,
        scan_id: int | Any,
        artifact_ids: list[int | Any],
    ) -> dict[str, Any]:
        """Mark selected scan artifact observations as indexed.

        Sets ``indexed_at`` to the current UTC time on each specified artifact
        row identified by PK.  The ``artifact_id_ref`` field is intentionally
        left empty here (set to an empty string); callers that know the resolved
        ``type:name`` PK of the imported artifact should call
        ``artifact_repo.update_indexed()`` directly.

        Args:
            scan_id: PK of the parent ``GitRepoScan`` (used for logging only).
            artifact_ids: List of ``GitScanArtifact`` primary keys to mark indexed.

        Returns:
            Dictionary with keys ``scan_id``, ``indexed_count``.
        """
        now = datetime.now(timezone.utc)
        indexed_count = 0
        for artifact_id in artifact_ids:
            result = self._artifact_repo.update_indexed(
                artifact_id=artifact_id,
                indexed_at=now,
                artifact_id_ref="",
            )
            if result is not None:
                indexed_count += 1

        logger.info(
            "Indexed %d/%d artifacts for scan %s",
            indexed_count,
            len(artifact_ids),
            scan_id,
        )
        return {"scan_id": scan_id, "indexed_count": indexed_count}

    def get_previous_scan_artifacts(
        self,
        connection_id: int | Any,
        exclude_scan_id: int | Any,
    ) -> dict[str, dict[str, Any]]:
        """Return artifacts from the most recently completed scan for comparison.

        Excludes the currently running scan (*exclude_scan_id*) so that the
        in-progress scan is never compared against itself.

        Args:
            connection_id: PK of the ``GitRepoConnection``.
            exclude_scan_id: PK of the scan currently being executed (excluded
                from the lookup).

        Returns:
            Mapping of ``artifact_path`` → artifact info dict (with at least
            ``content_hash`` and ``artifact_type`` keys).  An empty dict is
            returned when no prior completed scan exists.
        """
        scans = self._scan_repo.list_by_connection_id(
            connection_id=connection_id,
            limit=20,
        )

        # Find the most recent completed scan that isn't the current one
        previous_scan = None
        for scan in scans:
            if scan.id != exclude_scan_id and scan.status == "completed":
                previous_scan = scan
                break

        if previous_scan is None:
            return {}

        artifacts = self._artifact_repo.list_by_scan_id(previous_scan.id)
        return {
            art.artifact_path: {
                "content_hash": art.content_hash,
                "artifact_type": art.artifact_type,
                "detected_name": art.detected_name,
            }
            for art in artifacts
        }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _extract_name_from_content(content: bytes, path: str) -> Optional[str]:
    """Attempt to extract a human-readable artifact name from file content.

    Tries YAML/TOML frontmatter ``name:`` field first, then falls back to the
    basename (without extension) of the path.

    Args:
        content: Raw file content bytes.
        path: Repository-relative file path (used for fallback name).

    Returns:
        Extracted name string, or ``None`` if extraction fails entirely.
    """
    try:
        text = content.decode("utf-8", errors="replace")
    except Exception:
        return _basename_no_ext(path) or None

    # YAML frontmatter: --- ... name: foo ... ---
    fm_match = re.search(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if fm_match:
        name_match = re.search(
            r"^name:\s*['\"]?([^'\"#\n]+)['\"]?", fm_match.group(1), re.MULTILINE
        )
        if name_match:
            return name_match.group(1).strip() or None

    # TOML frontmatter or inline: name = "foo"
    toml_match = re.search(r'^name\s*=\s*["\']?([^"\'#\n]+)["\']?', text, re.MULTILINE)
    if toml_match:
        return toml_match.group(1).strip() or None

    # Fallback: basename without extension
    return _basename_no_ext(path) or None


def _basename_no_ext(path: str) -> str:
    """Return the basename of a path with any single extension removed."""
    name = _basename(path)
    if "." in name:
        return name.rsplit(".", 1)[0]
    return name
