"""Artifact importer for bulk import operations."""

import logging
import os
import re
import shutil
import tempfile
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING

from skillmeat.core.artifact import ArtifactManager, ArtifactType
from skillmeat.core.artifact_detection import (
    ArtifactType as DetectionArtifactType,
    ARTIFACT_SIGNATURES,
)
from skillmeat.core.enums import Platform

if TYPE_CHECKING:
    from skillmeat.api.schemas.discovery import ImportStatus


# Local ImportStatus enum to avoid circular import
class ImportStatus(str, Enum):
    """Status of an import operation (local definition to avoid circular import)."""

    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


from skillmeat.core.collection import CollectionManager
from skillmeat.core.discovery_metrics import (
    bulk_import_artifacts_total,
    bulk_import_duration,
    bulk_import_requests_total,
    discovery_metrics,
    log_performance,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional OpenTelemetry integration (graceful no-op fallback)
# ---------------------------------------------------------------------------

try:
    from opentelemetry import metrics as _otel_metrics
    from opentelemetry import trace as _otel_trace

    _tracer = _otel_trace.get_tracer(__name__)
    _meter = _otel_metrics.get_meter(__name__)

    # Counters
    _plugin_import_total = _meter.create_counter(
        name="plugin_import_total",
        description="Total plugin (composite artifact) import operations",
        unit="1",
    )
    _dedup_hit_total = _meter.create_counter(
        name="dedup_hit_total",
        description="Total artifacts reused via deduplication (LINK_EXISTING)",
        unit="1",
    )
    _dedup_miss_total = _meter.create_counter(
        name="dedup_miss_total",
        description="Total new artifacts created (CREATE_NEW_ARTIFACT or CREATE_NEW_VERSION)",
        unit="1",
    )

    # Histograms
    _plugin_import_duration = _meter.create_histogram(
        name="plugin_import_duration_seconds",
        description="Duration of transactional plugin import operations in seconds",
        unit="s",
    )
    _artifact_hash_compute_duration = _meter.create_histogram(
        name="artifact_hash_compute_duration_seconds",
        description="Duration of per-artifact hash computation in seconds",
        unit="s",
    )

    _OTEL_AVAILABLE = True

except ImportError:  # pragma: no cover
    _tracer = None  # type: ignore[assignment]
    _meter = None  # type: ignore[assignment]
    _plugin_import_total = None  # type: ignore[assignment]
    _dedup_hit_total = None  # type: ignore[assignment]
    _dedup_miss_total = None  # type: ignore[assignment]
    _plugin_import_duration = None  # type: ignore[assignment]
    _artifact_hash_compute_duration = None  # type: ignore[assignment]
    _OTEL_AVAILABLE = False


def _get_tracer():
    """Return the OTel tracer if available, else None."""
    return _tracer if _OTEL_AVAILABLE else None


@dataclass
class BulkImportArtifactData:
    """Data for a single artifact to import (internal representation)."""

    source: str
    artifact_type: str
    name: Optional[str] = None
    description: Optional[str] = None
    author: Optional[str] = None
    tags: List[str] = None
    target_platforms: Optional[List[str]] = None
    scope: str = "user"
    path: Optional[str] = None

    def __post_init__(self):
        """Initialize default values."""
        if self.tags is None:
            self.tags = []


@dataclass
class ImportResultData:
    """Result for a single artifact import (internal representation)."""

    artifact_id: str
    success: bool
    message: str
    error: Optional[str] = None
    status: Optional[ImportStatus] = None
    skip_reason: Optional[str] = None
    reason_code: Optional[str] = None  # ErrorReasonCode enum value
    details: Optional[str] = None  # Additional error details (e.g., line numbers)
    path: Optional[str] = None  # Path to the artifact
    tags_applied: int = 0  # Count of tags applied from path segments


@dataclass
class BulkImportResultData:
    """Result of bulk import operation (internal representation)."""

    total_requested: int
    total_imported: int
    total_failed: int
    results: List[ImportResultData]
    duration_ms: float
    total_tags_applied: int = 0  # Sum of tags applied across all imports


class ArtifactImporter:
    """
    Handles bulk import of artifacts with validation and atomic transactions.

    The importer validates all artifacts before importing any, and if one fails
    during import, it attempts to rollback all changes.
    """

    def __init__(
        self,
        artifact_manager: ArtifactManager,
        collection_manager: CollectionManager,
    ):
        """Initialize with managers.

        Args:
            artifact_manager: Artifact manager for import operations
            collection_manager: Collection manager for collection operations
        """
        self.artifact_manager = artifact_manager
        self.collection_manager = collection_manager

    def determine_import_status(
        self,
        artifact_key: str,
        import_success: bool,
        error: Optional[str] = None,
        already_exists: bool = False,
        exists_location: Optional[str] = None,  # "collection", "project", "both"
    ) -> tuple[ImportStatus, Optional[str]]:
        """
        Determine the import status and skip reason for an artifact.

        Args:
            artifact_key: Identifier for the artifact
            import_success: Whether the import operation succeeded
            error: Error message if import failed
            already_exists: Whether the artifact already exists
            exists_location: Where the artifact exists ("collection", "project", "both")

        Returns:
            tuple of (ImportStatus, skip_reason or None)
        """
        if already_exists:
            if exists_location == "both":
                return (
                    ImportStatus.SKIPPED,
                    "Already exists in both Collection and Project",
                )
            elif exists_location == "collection":
                return ImportStatus.SKIPPED, "Already exists in Collection"
            elif exists_location == "project":
                return ImportStatus.SKIPPED, "Already exists in Project"
            else:
                return ImportStatus.SKIPPED, "Already exists"

        if import_success:
            return ImportStatus.SUCCESS, None

        # Failed case
        return ImportStatus.FAILED, None

    @log_performance("bulk_import")
    def bulk_import(
        self,
        artifacts: List[BulkImportArtifactData],
        collection_name: str = "default",
        auto_resolve_conflicts: bool = False,
        apply_path_tags: bool = True,
    ) -> BulkImportResultData:
        """
        Import multiple artifacts with atomic transaction.

        Process:
        1. Validate all artifacts before import
        2. Check for duplicates/conflicts
        3. Import all or rollback on first error (if not auto_resolve)
        4. Update manifest and lock file

        Args:
            artifacts: List of artifacts to import
            collection_name: Target collection
            auto_resolve_conflicts: If True, skip duplicates instead of failing

        Returns:
            BulkImportResultData with per-artifact status
        """
        start_time = time.perf_counter()
        results: List[ImportResultData] = []
        imported_count = 0
        failed_count = 0

        logger.info(
            "Starting bulk import",
            extra={
                "artifact_count": len(artifacts),
                "collection": collection_name,
                "auto_resolve_conflicts": auto_resolve_conflicts,
            },
        )

        # Phase 1: Validate all artifacts
        validation_errors = self._validate_batch(artifacts)
        if validation_errors and not auto_resolve_conflicts:
            # Return all validation errors
            for artifact, error in validation_errors:
                artifact_id = self._get_artifact_id(artifact)
                status, skip_reason = self.determine_import_status(
                    artifact_key=artifact_id, import_success=False, error=error
                )
                results.append(
                    ImportResultData(
                        artifact_id=artifact_id,
                        success=False,
                        message="Validation failed",
                        error=error,
                        status=status,
                    )
                )
                failed_count += 1

            return BulkImportResultData(
                total_requested=len(artifacts),
                total_imported=0,
                total_failed=failed_count,
                results=results,
                duration_ms=(time.perf_counter() - start_time) * 1000,
            )

        # Phase 2: Import artifacts
        for artifact in artifacts:
            try:
                # Check for duplicate
                is_duplicate, location = self._check_duplicate(
                    artifact, collection_name
                )
                if is_duplicate:
                    artifact_id = self._get_artifact_id(artifact)
                    if auto_resolve_conflicts:
                        status, skip_reason = self.determine_import_status(
                            artifact_key=artifact_id,
                            import_success=False,
                            already_exists=True,
                            exists_location=location,
                        )
                        results.append(
                            ImportResultData(
                                artifact_id=artifact_id,
                                success=True,  # Count as success for backward compatibility
                                message=f"Skipped: {skip_reason}",
                                status=status,
                                skip_reason=skip_reason,
                            )
                        )
                        imported_count += 1  # Count as success since it exists
                        continue
                    else:
                        status, skip_reason = self.determine_import_status(
                            artifact_key=artifact_id,
                            import_success=False,
                            already_exists=True,
                            exists_location=location,
                        )
                        results.append(
                            ImportResultData(
                                artifact_id=artifact_id,
                                success=False,
                                message="Import failed",
                                error=f"Artifact already exists in {location}",
                                status=ImportStatus.FAILED,
                            )
                        )
                        failed_count += 1
                        continue

                # Import the artifact
                result = self._import_single(artifact, collection_name)

                # Apply path tags if enabled and import succeeded
                if apply_path_tags and result.success:
                    try:
                        tags_count = self._apply_path_tags(artifact, collection_name)
                        result.tags_applied = tags_count
                    except Exception as e:
                        logger.warning(
                            f"Failed to apply path tags for {artifact.name}: {e}"
                        )
                        # Don't fail the import, just log the warning

                results.append(result)
                if result.success:
                    imported_count += 1
                else:
                    failed_count += 1

            except Exception as e:
                logger.exception(f"Failed to import {artifact.name}: {e}")
                artifact_id = self._get_artifact_id(artifact)
                status, skip_reason = self.determine_import_status(
                    artifact_key=artifact_id, import_success=False, error=str(e)
                )
                results.append(
                    ImportResultData(
                        artifact_id=artifact_id,
                        success=False,
                        message="Import failed",
                        error=str(e),
                        status=status,
                    )
                )
                failed_count += 1

        duration_sec = time.perf_counter() - start_time
        duration_ms = duration_sec * 1000

        # Determine batch size range for metrics
        batch_size = len(artifacts)
        if batch_size <= 10:
            batch_size_range = "1-10"
        elif batch_size <= 50:
            batch_size_range = "11-50"
        else:
            batch_size_range = "51+"

        # Record metrics
        status = "success" if failed_count == 0 else "partial_success"
        bulk_import_requests_total.labels(status=status).inc()
        bulk_import_artifacts_total.labels(result="success").inc(imported_count)
        bulk_import_artifacts_total.labels(result="failed").inc(failed_count)
        bulk_import_duration.labels(batch_size_range=batch_size_range).observe(
            duration_sec
        )
        discovery_metrics.record_import(imported_count, failed_count)

        logger.info(
            f"Bulk import completed: {imported_count} imported, {failed_count} failed",
            extra={
                "imported_count": imported_count,
                "failed_count": failed_count,
                "duration_ms": round(duration_ms, 2),
                "status": status,
            },
        )

        # Calculate total tags applied
        total_tags = sum(r.tags_applied for r in results)

        return BulkImportResultData(
            total_requested=len(artifacts),
            total_imported=imported_count,
            total_failed=failed_count,
            results=results,
            duration_ms=duration_ms,
            total_tags_applied=total_tags,
        )

    def _apply_path_tags(
        self,
        artifact: BulkImportArtifactData,
        collection_name: str,
    ) -> int:
        """Apply path-based tags to an imported artifact.

        Extracts path segments from the artifact's source path,
        finds approved/pending segments, and adds them as tags.

        Args:
            artifact: The imported artifact data
            collection_name: Target collection name

        Returns:
            Number of tags applied

        Note:
            Only applies segments with status='approved' or 'pending'.
            Skips if artifact has no path or path extraction fails.
            For local filesystem paths, skips the first few segments
            which typically contain system paths and usernames.
        """
        from skillmeat.core.path_tags import PathSegmentExtractor, PathTagConfig

        # Need a path to extract from
        source_path = artifact.path or artifact.source
        if not source_path:
            return 0

        # Detect and handle local filesystem paths
        # If path looks like a local filesystem path (starts with / or contains common prefixes),
        # we need to skip the leading segments that are system/user paths
        config = PathTagConfig.defaults()

        # Check if this is a local filesystem path (absolute path or contains system dirs)
        local_fs_prefixes = ("/Users/", "/home/", "/var/", "/tmp/", "/opt/")
        is_local_fs = source_path.startswith("/") or any(
            prefix in source_path for prefix in local_fs_prefixes
        )

        if is_local_fs:
            # For local filesystem paths, skip first 3 segments (e.g., /Users/username/dev)
            # to avoid tagging with system paths and usernames
            config.skip_segments = [0, 1, 2]

        # Extract segments
        extractor = PathSegmentExtractor(config)
        segments = extractor.extract(source_path)

        # Filter to approved/pending segments (not excluded)
        # For initial import, "pending" is treated as approved since user selected them
        approved_segments = [
            seg.normalized
            for seg in segments
            if seg.status in ("approved", "pending") and seg.status != "excluded"
        ]

        if not approved_segments:
            return 0

        # Get artifact name for tagging
        artifact_name = artifact.name or artifact.source.split("/")[-1].split("@")[0]
        artifact_type_str = artifact.artifact_type

        # Add tags to artifact in collection
        try:
            artifact_type = ArtifactType(artifact_type_str)

            # Load collection and find the artifact
            collection = self.collection_manager.load_collection(collection_name)
            target_artifact = collection.find_artifact(artifact_name, artifact_type)

            if not target_artifact:
                logger.warning(f"Could not find artifact {artifact_name} to apply tags")
                return 0

            # Add each unique tag
            tags_added = 0
            existing_tags = set(target_artifact.tags or [])

            for tag_name in approved_segments:
                if tag_name not in existing_tags:
                    existing_tags.add(tag_name)
                    tags_added += 1

            # Update artifact tags if any were added
            if tags_added > 0:
                target_artifact.tags = list(existing_tags)
                self.collection_manager.save_collection(collection)
                logger.info(
                    f"Applied {tags_added} path tags to {artifact_name}: "
                    f"{approved_segments[:3]}{'...' if len(approved_segments) > 3 else ''}"
                )

            return tags_added

        except Exception as e:
            logger.warning(f"Error applying path tags to {artifact_name}: {e}")
            return 0

    def _get_artifact_id(self, artifact: BulkImportArtifactData) -> str:
        """Generate artifact ID from artifact data.

        Args:
            artifact: Artifact to generate ID for

        Returns:
            Artifact ID in format "type:name"
        """
        name = artifact.name or artifact.source.split("/")[-1].split("@")[0]
        return f"{artifact.artifact_type}:{name}"

    def _validate_batch(
        self, artifacts: List[BulkImportArtifactData]
    ) -> List[Tuple[BulkImportArtifactData, str]]:
        """Validate all artifacts, return list of (artifact, error) tuples.

        Args:
            artifacts: List of artifacts to validate

        Returns:
            List of (artifact, error_message) tuples for invalid artifacts
        """
        errors = []
        valid_types = {"skill", "command", "agent", "hook", "mcp"}

        for artifact in artifacts:
            # Validate type
            if artifact.artifact_type not in valid_types:
                errors.append(
                    (artifact, f"Invalid artifact type: {artifact.artifact_type}")
                )
                continue

            # Validate source format (basic check)
            if not artifact.source or "/" not in artifact.source:
                errors.append((artifact, f"Invalid source format: {artifact.source}"))
                continue

            # Validate scope
            if artifact.scope not in ("user", "local"):
                errors.append((artifact, f"Invalid scope: {artifact.scope}"))

        return errors

    def _check_duplicate(
        self, artifact: BulkImportArtifactData, collection_name: str
    ) -> tuple[bool, Optional[str]]:
        """Check if artifact already exists in collection.

        Args:
            artifact: Artifact to check
            collection_name: Collection to check in

        Returns:
            tuple of (is_duplicate, location) where location is "collection", "project", "both", or None
        """
        try:
            # Load collection
            collection = self.collection_manager.load_collection(collection_name)

            # Derive name
            name = artifact.name or artifact.source.split("/")[-1].split("@")[0]

            # Convert string type to ArtifactType enum
            artifact_type = ArtifactType(artifact.artifact_type)

            # Check if artifact exists
            existing = collection.find_artifact(name, artifact_type)
            if existing is not None:
                # For now, we only check collection existence
                # Future: check project-level deployments for "project" or "both"
                return (True, "collection")
            return (False, None)
        except Exception as e:
            logger.warning(f"Error checking duplicate for {artifact.name}: {e}")
            return (False, None)

    def _infer_target_platforms_from_source(
        self, artifact: BulkImportArtifactData
    ) -> Optional[List[Platform]]:
        """Infer target platforms from source/path profile roots."""
        source_candidates = [artifact.path, artifact.source]
        source_candidates = [candidate for candidate in source_candidates if candidate]

        profile_root_to_platform = {
            ".claude": Platform.CLAUDE_CODE,
            ".codex": Platform.CODEX,
            ".gemini": Platform.GEMINI,
            ".cursor": Platform.CURSOR,
        }

        detected: List[Platform] = []
        for candidate in source_candidates:
            normalized = str(candidate).replace("\\", "/")
            for root_dir, platform in profile_root_to_platform.items():
                root_token = f"/{root_dir}/"
                if normalized.startswith(f"{root_dir}/") or root_token in normalized:
                    if platform not in detected:
                        detected.append(platform)

        return detected or None

    def _resolve_target_platforms(
        self, artifact: BulkImportArtifactData
    ) -> Optional[List[Platform]]:
        """Resolve explicit or inferred target platforms for import."""
        if artifact.target_platforms:
            resolved: List[Platform] = []
            for value in artifact.target_platforms:
                platform = (
                    value if isinstance(value, Platform) else Platform(str(value))
                )
                if platform not in resolved:
                    resolved.append(platform)
            return resolved or None

        return self._infer_target_platforms_from_source(artifact)

    def _classify_error(
        self, error: Exception, artifact_path: Optional[str] = None
    ) -> tuple[str, str, Optional[str]]:
        """Classify an exception into reason code, message, and details.

        Args:
            error: The exception that occurred
            artifact_path: Optional path to the artifact for context

        Returns:
            tuple of (reason_code, error_message, details)
        """
        import yaml

        error_str = str(error)
        error_type = type(error).__name__

        # YAML parsing errors
        if isinstance(error, yaml.YAMLError):
            details = None
            if hasattr(error, "problem_mark") and error.problem_mark:
                mark = error.problem_mark
                details = f"Line {mark.line + 1}, Column {mark.column + 1}: {getattr(error, 'problem', 'syntax error')}"
            return ("yaml_parse_error", f"YAML parsing failed: {error_str}", details)

        # Permission errors (check first since PermissionError inherits from OSError)
        if isinstance(error, PermissionError):
            return (
                "permission_error",
                f"Permission denied: {error_str}",
                artifact_path,
            )

        # File I/O errors
        if isinstance(error, (IOError, OSError)):
            if "Permission denied" in error_str:
                return (
                    "permission_error",
                    f"Permission denied: {error_str}",
                    artifact_path,
                )
            return ("io_error", f"I/O error: {error_str}", artifact_path)

        # Network errors (typically from GitHub)
        if "network" in error_str.lower() or "connection" in error_str.lower():
            return ("network_error", f"Network error: {error_str}", None)
        if "timeout" in error_str.lower():
            return ("network_error", f"Connection timeout: {error_str}", None)
        if "404" in error_str or "not found" in error_str.lower():
            return ("network_error", f"Resource not found: {error_str}", None)

        # Validation errors
        if isinstance(error, ValueError):
            if "invalid" in error_str.lower() and "type" in error_str.lower():
                return ("invalid_type", f"Invalid artifact type: {error_str}", None)
            if "source" in error_str.lower() or "path" in error_str.lower():
                return ("invalid_source", f"Invalid source: {error_str}", None)
            if "structure" in error_str.lower() or "directory" in error_str.lower():
                return (
                    "invalid_structure",
                    f"Invalid artifact structure: {error_str}",
                    artifact_path,
                )
            if "metadata" in error_str.lower() or "missing" in error_str.lower():
                return (
                    "missing_metadata",
                    f"Missing metadata: {error_str}",
                    artifact_path,
                )

        if isinstance(error, KeyError):
            return (
                "missing_metadata",
                f"Missing required field: {error_str}",
                None,
            )

        # Generic import error
        return ("import_error", f"Import failed: {error_str}", None)

    def _validate_artifact_structure(
        self, artifact: BulkImportArtifactData
    ) -> Optional[ImportResultData]:
        """Validate artifact structure before import.

        Checks for common issues like missing SKILL.md, invalid YAML, etc.

        Args:
            artifact: Artifact to validate

        Returns:
            ImportResultData if validation fails, None if valid
        """
        import os
        from pathlib import Path
        import yaml

        # Skip validation for GitHub sources (validated during fetch)
        if not artifact.source.startswith("local/"):
            return None

        # Local sources require path
        if not artifact.path:
            artifact_id = f"{artifact.artifact_type}:{artifact.name or 'unknown'}"
            return ImportResultData(
                artifact_id=artifact_id,
                success=False,
                message="Validation failed",
                error=f"Local source '{artifact.source}' requires 'path' field",
                status=ImportStatus.FAILED,
                reason_code="invalid_source",
                path=None,
            )

        artifact_path = Path(artifact.path)

        # Check path exists
        if not artifact_path.exists():
            artifact_id = (
                f"{artifact.artifact_type}:{artifact.name or artifact_path.name}"
            )
            return ImportResultData(
                artifact_id=artifact_id,
                success=False,
                message="Validation failed",
                error=f"Artifact path does not exist: {artifact.path}",
                status=ImportStatus.FAILED,
                reason_code="invalid_structure",
                path=artifact.path,
            )

        # Determine if this artifact type requires a directory or allows single files
        # Look up the signature from ARTIFACT_SIGNATURES for authoritative is_directory info
        try:
            detection_type = DetectionArtifactType(artifact.artifact_type)
            signature = ARTIFACT_SIGNATURES.get(detection_type)
            requires_directory = signature.is_directory if signature else True
        except ValueError:
            # Unknown artifact type - default to requiring directory (conservative)
            requires_directory = True

        if requires_directory:
            # Directory-based artifacts (skills): must be a directory
            if not artifact_path.is_dir():
                artifact_id = (
                    f"{artifact.artifact_type}:{artifact.name or artifact_path.name}"
                )
                return ImportResultData(
                    artifact_id=artifact_id,
                    success=False,
                    message="Validation failed",
                    error=f"Artifact path is not a directory: {artifact.path}",
                    status=ImportStatus.FAILED,
                    reason_code="invalid_structure",
                    path=artifact.path,
                )
        else:
            # File-based artifacts (commands, agents, hooks, mcp): must be a file
            if not artifact_path.is_file():
                artifact_id = (
                    f"{artifact.artifact_type}:{artifact.name or artifact_path.name}"
                )
                return ImportResultData(
                    artifact_id=artifact_id,
                    success=False,
                    message="Validation failed",
                    error=f"Artifact path is not a file: {artifact.path}",
                    status=ImportStatus.FAILED,
                    reason_code="invalid_structure",
                    path=artifact.path,
                )

            # For file-based artifacts, validate the file itself
            # Check file extension for markdown-based types
            if artifact.artifact_type in ("command", "agent"):
                if not artifact_path.suffix.lower() == ".md":
                    artifact_id = f"{artifact.artifact_type}:{artifact.name or artifact_path.name}"
                    return ImportResultData(
                        artifact_id=artifact_id,
                        success=False,
                        message="Validation failed",
                        error=f"Expected .md file for {artifact.artifact_type}, got: {artifact_path.suffix}",
                        status=ImportStatus.FAILED,
                        reason_code="invalid_structure",
                        path=artifact.path,
                    )

            # Validate YAML frontmatter in the file itself for markdown-based artifacts
            if artifact_path.suffix.lower() == ".md":
                try:
                    content = artifact_path.read_text(encoding="utf-8")
                    if content.startswith("---"):
                        # Extract YAML frontmatter
                        parts = content.split("---", 2)
                        if len(parts) >= 3:
                            yaml_content = parts[1].strip()
                            if yaml_content:
                                yaml.safe_load(yaml_content)
                except yaml.YAMLError as e:
                    artifact_id = f"{artifact.artifact_type}:{artifact.name or artifact_path.name}"
                    details = None
                    if hasattr(e, "problem_mark") and e.problem_mark:
                        mark = e.problem_mark
                        details = f"Line {mark.line + 1}, Column {mark.column + 1}: {getattr(e, 'problem', 'syntax error')}"
                    return ImportResultData(
                        artifact_id=artifact_id,
                        success=False,
                        message="Validation failed",
                        error=f"Invalid YAML frontmatter in {artifact_path.name}",
                        status=ImportStatus.FAILED,
                        reason_code="yaml_parse_error",
                        details=details,
                        path=artifact.path,
                    )
                except Exception as e:
                    artifact_id = f"{artifact.artifact_type}:{artifact.name or artifact_path.name}"
                    return ImportResultData(
                        artifact_id=artifact_id,
                        success=False,
                        message="Validation failed",
                        error=f"Failed to read {artifact_path.name}: {str(e)}",
                        status=ImportStatus.FAILED,
                        reason_code="io_error",
                        path=artifact.path,
                    )

            # Validation passed for file-based artifact
            return None

        # Check for metadata file based on artifact type (directory-based artifacts only)
        metadata_files = {
            "skill": "SKILL.md",
            "command": "command.md",
            "agent": "agent.md",
            "hook": "hook.md",
            "mcp": "mcp.json",
        }

        expected_file = metadata_files.get(artifact.artifact_type)
        if expected_file:
            metadata_path = artifact_path / expected_file
            if not metadata_path.exists():
                artifact_id = (
                    f"{artifact.artifact_type}:{artifact.name or artifact_path.name}"
                )
                return ImportResultData(
                    artifact_id=artifact_id,
                    success=False,
                    message="Validation failed",
                    error=f"Missing required metadata file: {expected_file}",
                    status=ImportStatus.FAILED,
                    reason_code="missing_metadata",
                    details=f"Expected file at: {metadata_path}",
                    path=artifact.path,
                )

            # For markdown files, validate YAML frontmatter
            if expected_file.endswith(".md"):
                try:
                    content = metadata_path.read_text(encoding="utf-8")
                    if content.startswith("---"):
                        # Extract YAML frontmatter
                        parts = content.split("---", 2)
                        if len(parts) >= 3:
                            yaml_content = parts[1].strip()
                            if yaml_content:
                                yaml.safe_load(yaml_content)
                except yaml.YAMLError as e:
                    artifact_id = f"{artifact.artifact_type}:{artifact.name or artifact_path.name}"
                    details = None
                    if hasattr(e, "problem_mark") and e.problem_mark:
                        mark = e.problem_mark
                        details = f"Line {mark.line + 1}, Column {mark.column + 1}: {getattr(e, 'problem', 'syntax error')}"
                    return ImportResultData(
                        artifact_id=artifact_id,
                        success=False,
                        message="Validation failed",
                        error=f"Invalid YAML frontmatter in {expected_file}",
                        status=ImportStatus.FAILED,
                        reason_code="yaml_parse_error",
                        details=details,
                        path=artifact.path,
                    )
                except Exception as e:
                    artifact_id = f"{artifact.artifact_type}:{artifact.name or artifact_path.name}"
                    return ImportResultData(
                        artifact_id=artifact_id,
                        success=False,
                        message="Validation failed",
                        error=f"Failed to read {expected_file}: {str(e)}",
                        status=ImportStatus.FAILED,
                        reason_code="io_error",
                        path=artifact.path,
                    )

        return None  # Validation passed

    def _import_single(
        self, artifact: BulkImportArtifactData, collection_name: str
    ) -> ImportResultData:
        """Import a single artifact.

        Args:
            artifact: Artifact to import
            collection_name: Target collection

        Returns:
            ImportResultData with import status
        """
        # Pre-validate structure for local artifacts
        validation_result = self._validate_artifact_structure(artifact)
        if validation_result is not None:
            return validation_result

        try:
            # Extract name from source
            name = artifact.name or artifact.source.split("/")[-1].split("@")[0]
            artifact_type = ArtifactType(artifact.artifact_type)
            target_platforms = self._resolve_target_platforms(artifact)

            # Route based on source type
            if artifact.source.startswith("local/"):
                # Local source - requires path field
                if not artifact.path:
                    raise ValueError(
                        f"Local source '{artifact.source}' requires 'path' field with actual filesystem location"
                    )
                added_artifact = self.artifact_manager.add_from_local(
                    path=artifact.path,
                    artifact_type=artifact_type,
                    collection_name=collection_name,
                    custom_name=name,
                    tags=artifact.tags if artifact.tags else None,
                    target_platforms=target_platforms,
                    force=False,
                )
            else:
                # GitHub source
                added_artifact = self.artifact_manager.add_from_github(
                    spec=artifact.source,
                    artifact_type=artifact_type,
                    collection_name=collection_name,
                    custom_name=name,
                    tags=artifact.tags if artifact.tags else None,
                    target_platforms=target_platforms,
                    force=False,
                )

            artifact_id = f"{artifact.artifact_type}:{added_artifact.name}"
            status, skip_reason = self.determine_import_status(
                artifact_key=artifact_id, import_success=True, already_exists=False
            )
            return ImportResultData(
                artifact_id=artifact_id,
                success=True,
                message="Imported successfully",
                status=status,
                skip_reason=skip_reason,
                path=artifact.path,
            )
        except Exception as e:
            logger.error(f"Failed to import artifact: {e}")
            artifact_id = f"{artifact.artifact_type}:{artifact.name or 'unknown'}"
            reason_code, error_msg, details = self._classify_error(e, artifact.path)
            status, skip_reason = self.determine_import_status(
                artifact_key=artifact_id, import_success=False, error=str(e)
            )
            return ImportResultData(
                artifact_id=artifact_id,
                success=False,
                message="Import failed",
                error=error_msg,
                status=status,
                skip_reason=skip_reason,
                reason_code=reason_code,
                details=details,
                path=artifact.path,
            )


# =============================================================================
# Plugin meta-file storage (CAI-P3-06)
# =============================================================================


def slugify_plugin_name(name: str) -> str:
    """Convert a plugin name to a safe directory slug.

    Transforms the name to lowercase, replaces spaces and consecutive
    non-alphanumeric characters with a single hyphen, and strips leading/
    trailing hyphens.

    Args:
        name: Raw plugin name (e.g. ``"Git Workflow Pro"``).

    Returns:
        URL-safe slug (e.g. ``"git-workflow-pro"``).

    Examples::

        >>> slugify_plugin_name("Git Workflow Pro")
        'git-workflow-pro'
        >>> slugify_plugin_name("MY_PLUGIN  v2")
        'my-plugin-v2'
        >>> slugify_plugin_name("  leading/trailing  ")
        'leading-trailing'
    """
    lowered = name.lower()
    # Replace any run of non-alphanumeric characters with a single hyphen
    slugged = re.sub(r"[^a-z0-9]+", "-", lowered)
    # Strip leading/trailing hyphens
    return slugged.strip("-")


def write_plugin_meta_files(
    plugin_name: str,
    meta_files: Dict[str, bytes],
    collection_path: str,
) -> str:
    """Write plugin meta-files to the collection filesystem atomically.

    Creates ``<collection_path>/plugins/<slug>/`` and writes every entry in
    *meta_files* into that directory.  The write is performed via a temporary
    directory that is atomically moved into place, so a partial failure never
    leaves a corrupt plugin directory.

    Children are **not** stored here — they go to their type-specific
    directories (``skills/``, ``commands/``, etc.).  This function only
    handles the plugin-level meta-files such as ``plugin.json``,
    ``README.md``, and ``manifest.toml``.

    Args:
        plugin_name: Human-readable or machine plugin name.  Will be
            slugified (lowercase, hyphens for spaces/punctuation) before
            use as a directory name.
        meta_files: Mapping of filename → raw bytes.  Keys are plain
            filenames (no path components).  Values are the file contents.
            An empty dict is valid and results in an empty plugin directory.
        collection_path: Absolute path to the root of the collection
            directory (i.e. the directory that contains ``skills/``,
            ``commands/``, etc.).

    Returns:
        Absolute path to the newly created plugin directory as a string.

    Raises:
        OSError: If the filesystem operation fails (permissions, disk full,
            etc.).
        ValueError: If *plugin_name* slugifies to an empty string.

    Example::

        plugin_dir = write_plugin_meta_files(
            plugin_name="Git Workflow Pro",
            meta_files={
                "plugin.json": b'{"name": "git-workflow-pro"}',
                "README.md": b"# Git Workflow Pro\\n",
            },
            collection_path="/home/user/.skillmeat/collections/default",
        )
        # plugin_dir == "/home/user/.skillmeat/collections/default/plugins/git-workflow-pro"
    """
    slug = slugify_plugin_name(plugin_name)
    if not slug:
        raise ValueError(
            f"Plugin name {plugin_name!r} produced an empty slug after slugification."
        )

    collection_root = Path(collection_path)
    plugins_dir = collection_root / "plugins"
    final_plugin_dir = plugins_dir / slug

    # Write via temp directory inside the same filesystem (plugins_dir) so
    # that the atomic rename is guaranteed to be on the same device.
    plugins_dir.mkdir(parents=True, exist_ok=True)

    temp_dir_path = tempfile.mkdtemp(dir=plugins_dir, prefix=f".{slug}.")
    try:
        temp_plugin_dir = Path(temp_dir_path)

        for filename, content in meta_files.items():
            dest_file = temp_plugin_dir / filename
            # Write file content
            with open(dest_file, "wb") as fh:
                fh.write(content)
                fh.flush()
                os.fsync(fh.fileno())

        # If a previous plugin directory exists, remove it before the rename
        # so the atomic replace always succeeds regardless of OS rename
        # semantics (on Windows, rename fails if target exists).
        if final_plugin_dir.exists():
            shutil.rmtree(final_plugin_dir)

        # Atomic rename: temp_dir → final destination
        Path(temp_dir_path).rename(final_plugin_dir)

    except Exception:
        # Best-effort cleanup of the temp directory on failure
        try:
            shutil.rmtree(temp_dir_path, ignore_errors=True)
        except Exception:
            pass
        raise

    logger.info(
        "write_plugin_meta_files: wrote %d meta-file(s) for plugin %r to %s",
        len(meta_files),
        slug,
        final_plugin_dir,
    )
    return str(final_plugin_dir)


# =============================================================================
# Transactional plugin import (CAI-P3-03 + CAI-P3-04)
# =============================================================================


@dataclass
class ImportResult:
    """Result of a transactional plugin import via :func:`import_plugin_transactional`.

    Attributes:
        success: ``True`` when the full transaction committed without error.
        plugin_id: The ``CompositeArtifact.id`` for the imported plugin
            (format: ``"composite:<name>"``).
        children_imported: Number of child ``Artifact`` / ``ArtifactVersion``
            rows that were newly created during this import.
        children_reused: Number of child artifacts that already existed in the
            cache and were linked via deduplication rather than re-created.
        errors: Human-readable error messages.  Empty on success; populated on
            partial or total failure.
        transaction_id: UUID string generated per call for distributed tracing
            and log correlation.
    """

    success: bool
    plugin_id: str
    children_imported: int
    children_reused: int
    errors: List[str]
    transaction_id: str = field(default_factory=lambda: str(uuid.uuid4()))


def import_plugin_transactional(
    discovered_graph: "DiscoveredGraph",
    source_url: str,
    session: "Session",
    project_id: str,
    collection_id: str,
) -> ImportResult:
    """Import a composite plugin and all its children in a single DB transaction.

    Executes the full import pipeline within the supplied SQLAlchemy ``session``:

    1. For each child in ``discovered_graph.children``:

       a. Compute a SHA-256 content hash via :func:`~skillmeat.core.hashing.compute_artifact_hash`.
       b. Run deduplication via :func:`~skillmeat.core.deduplication.resolve_artifact_for_import`.
       c. Execute the decision:

          * ``LINK_EXISTING`` — the content hash already lives in
            ``ArtifactVersion``; reuse the existing artifact and version IDs.
          * ``CREATE_NEW_VERSION`` — same name+type exists but with different
            content; append a new ``ArtifactVersion`` row to the existing
            ``Artifact``.
          * ``CREATE_NEW_ARTIFACT`` — no match; create a new ``Artifact`` row
            and its initial ``ArtifactVersion``.

    2. Create a ``CompositeArtifact`` row for the plugin (idempotent: skips if
       a row with the same id already exists).

    3. Create one ``CompositeMembership`` row per child, storing
       ``pinned_version_hash`` equal to the content hash at import time
       (CAI-P3-04 version pinning).

    4. Commit the transaction.  Any exception triggers an automatic rollback and
       the function returns a failure ``ImportResult`` — no orphaned rows are
       left in the database.

    Args:
        discovered_graph: Composite artifact hierarchy produced by the Phase 2
            discovery pipeline (a :class:`~skillmeat.core.discovery.DiscoveredGraph`
            instance).
        source_url: URL or filesystem path identifying the upstream source of
            the composite artifact.  Stored on ``CompositeArtifact`` metadata for
            provenance tracking.
        session: An *active* SQLAlchemy ``Session``.  The caller owns session
            lifecycle; this function issues DML within the supplied session and
            calls ``session.commit()`` on success or ``session.rollback()`` on
            failure — it does **not** close the session.
        project_id: The ``Project.id`` that owns the newly created ``Artifact``
            rows.  Required because ``artifacts.project_id`` is a non-null
            foreign key.
        collection_id: The collection identifier used as the owning scope for
            ``CompositeArtifact`` and ``CompositeMembership`` rows.

    Returns:
        :class:`ImportResult` describing the outcome.  On success,
        ``success=True`` and ``plugin_id`` contains the composite's
        ``type:name`` key.  On failure, ``success=False`` and ``errors``
        contains one or more diagnostic messages.

    Raises:
        This function never propagates exceptions — all errors are caught,
        the transaction is rolled back, and a failure ``ImportResult`` is
        returned.

    Example::

        from sqlalchemy.orm import Session
        from skillmeat.core.importer import import_plugin_transactional

        result = import_plugin_transactional(
            discovered_graph=graph,
            source_url="github:owner/repo",
            session=session,
            project_id="proj-abc",
            collection_id="col-xyz",
        )
        if result.success:
            print(f"Imported plugin {result.plugin_id}")
        else:
            print(f"Import failed: {result.errors}")
    """
    # Deferred imports — these modules sit below `importer` in the dependency
    # graph, but `importer` is imported early by api/routers/artifacts.py which
    # is loaded during the API server's import chain.  Deferring here prevents
    # the circular import: cache.models → cache → cache.marketplace →
    # api.schemas → api → api.routers → core.importer → cache.models.
    from skillmeat.cache.models import (
        Artifact,
        ArtifactVersion,
        CompositeArtifact,
        CompositeMembership,
    )
    from skillmeat.core.deduplication import (
        DeduplicationDecision,
        resolve_artifact_for_import,
    )
    from skillmeat.core.hashing import compute_artifact_hash

    transaction_id = str(uuid.uuid4())
    plugin_name = discovered_graph.parent.name
    composite_id = f"composite:{plugin_name}"
    child_count = len(discovered_graph.children)

    _log = logging.getLogger(__name__)
    _log.info(
        "import_plugin_transactional started",
        extra={
            "transaction_id": transaction_id,
            "composite_id": composite_id,
            "plugin_name": plugin_name,
            "child_count": child_count,
        },
    )

    children_imported = 0
    children_reused = 0
    errors: List[str] = []

    # Map child name → (artifact_uuid, content_hash) for membership creation
    child_records: List[Dict[str, Any]] = []

    tracer = _get_tracer()
    import_start = time.perf_counter()

    def _run_import() -> ImportResult:
        nonlocal children_imported, children_reused

        try:
            # ------------------------------------------------------------------
            # Step 1: Process each child artifact
            # ------------------------------------------------------------------
            for child in discovered_graph.children:
                child_id = f"{child.type}:{child.name}"

                # (a) Compute content hash
                hash_start = time.perf_counter()
                try:
                    content_hash = compute_artifact_hash(child.path)
                except (FileNotFoundError, ValueError) as exc:
                    _log.warning(
                        "import_plugin_transactional: hash failed for child %s path=%s: %s",
                        child_id,
                        child.path,
                        exc,
                    )
                    errors.append(
                        f"Hash computation failed for '{child_id}' (path={child.path}): {exc}"
                    )
                    raise  # abort entire transaction
                finally:
                    hash_duration = time.perf_counter() - hash_start
                    if _OTEL_AVAILABLE and _artifact_hash_compute_duration is not None:
                        _artifact_hash_compute_duration.record(
                            hash_duration,
                            {"artifact_name": child.name},
                        )

                # (b) Run deduplication
                dedup_result = resolve_artifact_for_import(
                    name=child.name,
                    artifact_type=child.type,
                    content_hash=content_hash,
                    session=session,
                )

                # Log dedup decision at DEBUG level with structured fields
                _log.debug(
                    "Deduplication decision for child artifact",
                    extra={
                        "artifact_name": child.name,
                        "decision": dedup_result.decision.value,
                        "content_hash": content_hash[:16],
                        "transaction_id": transaction_id,
                    },
                )

                # Update OTel dedup counters
                if _OTEL_AVAILABLE:
                    if dedup_result.decision == DeduplicationDecision.LINK_EXISTING:
                        if _dedup_hit_total is not None:
                            _dedup_hit_total.add(
                                1,
                                {
                                    "plugin_name": plugin_name,
                                    "artifact_name": child.name,
                                },
                            )
                    else:
                        if _dedup_miss_total is not None:
                            _dedup_miss_total.add(
                                1,
                                {
                                    "plugin_name": plugin_name,
                                    "artifact_name": child.name,
                                    "decision": dedup_result.decision.value,
                                },
                            )

                # (c) Execute decision
                if dedup_result.decision == DeduplicationDecision.LINK_EXISTING:
                    # Reuse existing artifact + version — no new rows needed
                    artifact_uuid_row = (
                        session.query(Artifact)
                        .filter(Artifact.id == dedup_result.artifact_id)
                        .first()
                    )
                    if artifact_uuid_row is None:
                        # Defensive: artifact disappeared between queries
                        raise RuntimeError(
                            f"Deduplication returned LINK_EXISTING for '{child_id}' "
                            f"but artifact id={dedup_result.artifact_id!r} was not found."
                        )
                    child_artifact_uuid = artifact_uuid_row.uuid
                    children_reused += 1
                    _log.debug(
                        "LINK_EXISTING: child=%s artifact_id=%s version_id=%s",
                        child_id,
                        dedup_result.artifact_id,
                        dedup_result.artifact_version_id,
                    )

                elif dedup_result.decision == DeduplicationDecision.CREATE_NEW_VERSION:
                    # Append a new ArtifactVersion to the existing Artifact row
                    existing_artifact = (
                        session.query(Artifact)
                        .filter(Artifact.id == dedup_result.artifact_id)
                        .first()
                    )
                    if existing_artifact is None:
                        raise RuntimeError(
                            f"Deduplication returned CREATE_NEW_VERSION for '{child_id}' "
                            f"but artifact id={dedup_result.artifact_id!r} was not found."
                        )
                    new_version = ArtifactVersion(
                        artifact_id=existing_artifact.id,
                        content_hash=content_hash,
                        change_origin="sync",
                        parent_hash=None,
                    )
                    session.add(new_version)
                    session.flush()  # populate new_version.id
                    child_artifact_uuid = existing_artifact.uuid
                    children_imported += 1
                    _log.debug(
                        "CREATE_NEW_VERSION: child=%s artifact_id=%s new_version_id=%s",
                        child_id,
                        existing_artifact.id,
                        new_version.id,
                    )

                else:
                    # CREATE_NEW_ARTIFACT — new Artifact + initial ArtifactVersion
                    artifact_type_name_id = f"{child.type}:{child.name}"
                    new_artifact = Artifact(
                        id=artifact_type_name_id,
                        project_id=project_id,
                        name=child.name,
                        type=child.type,
                        source=source_url,
                        description=child.description,
                    )
                    session.add(new_artifact)
                    session.flush()  # populate new_artifact.uuid

                    new_version = ArtifactVersion(
                        artifact_id=new_artifact.id,
                        content_hash=content_hash,
                        change_origin="sync",
                        parent_hash=None,
                    )
                    session.add(new_version)
                    session.flush()
                    child_artifact_uuid = new_artifact.uuid
                    children_imported += 1
                    _log.debug(
                        "CREATE_NEW_ARTIFACT: child=%s artifact_uuid=%s version_id=%s",
                        child_id,
                        child_artifact_uuid,
                        new_version.id,
                    )

                # Accumulate (uuid, content_hash) for membership creation in step 3
                child_records.append(
                    {
                        "child_artifact_uuid": child_artifact_uuid,
                        "pinned_version_hash": content_hash,
                    }
                )

            # ------------------------------------------------------------------
            # Step 2: Upsert CompositeArtifact row
            # ------------------------------------------------------------------
            existing_composite = (
                session.query(CompositeArtifact)
                .filter(CompositeArtifact.id == composite_id)
                .first()
            )
            if existing_composite is None:
                composite_row = CompositeArtifact(
                    id=composite_id,
                    collection_id=collection_id,
                    composite_type="plugin",
                    display_name=discovered_graph.parent.name,
                    description=discovered_graph.parent.description,
                    metadata_json=None,
                )
                session.add(composite_row)
                session.flush()
                _log.debug("Created CompositeArtifact: id=%s", composite_id)
            else:
                _log.debug("CompositeArtifact already exists: id=%s", composite_id)

            # ------------------------------------------------------------------
            # Step 3: Create CompositeMembership rows with pinned_version_hash
            # ------------------------------------------------------------------
            for record in child_records:
                existing_membership = (
                    session.query(CompositeMembership)
                    .filter(
                        CompositeMembership.collection_id == collection_id,
                        CompositeMembership.composite_id == composite_id,
                        CompositeMembership.child_artifact_uuid
                        == record["child_artifact_uuid"],
                    )
                    .first()
                )
                if existing_membership is not None:
                    # Already linked — update the pin
                    existing_membership.pinned_version_hash = record[
                        "pinned_version_hash"
                    ]
                    _log.debug(
                        "Updated pinned_version_hash on existing membership: "
                        "composite=%s child_uuid=%s",
                        composite_id,
                        record["child_artifact_uuid"],
                    )
                else:
                    membership = CompositeMembership(
                        collection_id=collection_id,
                        composite_id=composite_id,
                        child_artifact_uuid=record["child_artifact_uuid"],
                        relationship_type="contains",
                        pinned_version_hash=record["pinned_version_hash"],
                    )
                    session.add(membership)
                    _log.debug(
                        "Created CompositeMembership: composite=%s child_uuid=%s hash=%s",
                        composite_id,
                        record["child_artifact_uuid"],
                        record["pinned_version_hash"][:8],
                    )

            # ------------------------------------------------------------------
            # Step 4: Commit the transaction
            # ------------------------------------------------------------------
            session.commit()
            duration_ms = (time.perf_counter() - import_start) * 1000
            _log.info(
                "import_plugin_transactional committed",
                extra={
                    "transaction_id": transaction_id,
                    "composite_id": composite_id,
                    "plugin_name": plugin_name,
                    "child_count": child_count,
                    "children_imported": children_imported,
                    "children_reused": children_reused,
                    "duration_ms": round(duration_ms, 2),
                },
            )

            # Record OTel metrics on success
            if _OTEL_AVAILABLE:
                if _plugin_import_total is not None:
                    _plugin_import_total.add(
                        1, {"status": "success", "plugin_name": plugin_name}
                    )
                if _plugin_import_duration is not None:
                    _plugin_import_duration.record(
                        (time.perf_counter() - import_start),
                        {"status": "success", "plugin_name": plugin_name},
                    )

            return ImportResult(
                success=True,
                plugin_id=composite_id,
                children_imported=children_imported,
                children_reused=children_reused,
                errors=[],
                transaction_id=transaction_id,
            )

        except Exception as exc:
            session.rollback()
            error_msg = str(exc)
            duration_ms = (time.perf_counter() - import_start) * 1000
            _log.error(
                "import_plugin_transactional rolled back",
                extra={
                    "transaction_id": transaction_id,
                    "composite_id": composite_id,
                    "plugin_name": plugin_name,
                    "child_count": child_count,
                    "duration_ms": round(duration_ms, 2),
                    "error": error_msg,
                },
                exc_info=True,
            )
            errors.append(error_msg)

            # Record OTel metrics on failure
            if _OTEL_AVAILABLE:
                if _plugin_import_total is not None:
                    _plugin_import_total.add(
                        1, {"status": "failure", "plugin_name": plugin_name}
                    )
                if _plugin_import_duration is not None:
                    _plugin_import_duration.record(
                        (time.perf_counter() - import_start),
                        {"status": "failure", "plugin_name": plugin_name},
                    )

            return ImportResult(
                success=False,
                plugin_id=composite_id,
                children_imported=0,
                children_reused=0,
                errors=errors,
                transaction_id=transaction_id,
            )

    # ------------------------------------------------------------------
    # Wrap execution in an OTel parent span when available
    # ------------------------------------------------------------------
    if tracer is not None:
        with tracer.start_as_current_span("plugin.import_transactional") as span:
            span.set_attribute("plugin_name", plugin_name)
            span.set_attribute("child_count", child_count)
            span.set_attribute("transaction_id", transaction_id)
            result = _run_import()
            # Write association span after child processing
            if result.success:
                with tracer.start_as_current_span("association.write") as assoc_span:
                    assoc_span.set_attribute("composite_id", composite_id)
                    assoc_span.set_attribute("child_count", len(child_records))
            return result
    else:
        return _run_import()
