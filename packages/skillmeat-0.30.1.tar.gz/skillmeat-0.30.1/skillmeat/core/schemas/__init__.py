"""Pydantic schemas for SkillMeat core services."""
