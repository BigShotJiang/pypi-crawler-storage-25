"""Pydantic schemas for BundleCommit API and service responses (DVCS-2.4).

These DTOs decouple the API surface and service return types from the SQLAlchemy
ORM layer, enabling clean serialization and validation without leaking DB
implementation details.

References
----------
- Service: ``skillmeat/core/services/bundle_commit_service.py``
- Repository: ``skillmeat/cache/bundle_commit_repository.py``
- Models: ``skillmeat/cache/models.py``
"""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel


class ConflictEntry(BaseModel):
    """A member whose current version differs from the snapshot.

    Returned as part of :class:`RollbackPreview` to indicate which artifacts
    have diverged from the target commit state.

    Attributes:
        artifact_uuid: Stable UUID of the artifact (FK to ``artifacts.uuid``).
        artifact_id: Human-readable identifier (e.g. ``"skill:canvas"``).
        snapshot_content_hash: Content hash recorded in the target commit member.
        current_content_hash: Content hash of the artifact's latest version now.
        current_version_id: Primary key of the artifact's current ``ArtifactVersion``.
    """

    artifact_uuid: str
    artifact_id: str
    snapshot_content_hash: str
    current_content_hash: str
    current_version_id: str


class RollbackPreview(BaseModel):
    """Result of a dry-run or executed rollback.

    Returned by :meth:`~skillmeat.core.services.bundle_commit_service.BundleCommitService.rollback`
    for both ``dry_run=True`` (conflict analysis only) and ``dry_run=False``
    (conflict analysis + new commit created).

    Attributes:
        commit_id: The ID of the commit that ``rollback()`` was called on (the
            source/current commit, used as the reference point).
        target_commit_id: The commit being rolled back *to*.
        clean_members: Artifact UUIDs that are already at the target state
            (no hash divergence — no action needed for these).
        conflicted_members: Members whose current version differs from the
            target snapshot.
        total_members: Total count of members in the target commit.
        bundle_hash: SHA-256 bundle hash of the target commit.
        is_dry_run: ``True`` when no DB changes were made; ``False`` when the
            rollback commit was actually created.
        new_commit_id: PK of the newly created rollback ``BundleCommit``.
            ``None`` when ``is_dry_run=True``.
    """

    commit_id: str
    target_commit_id: str
    clean_members: List[str]
    conflicted_members: List[ConflictEntry]
    total_members: int
    bundle_hash: str
    is_dry_run: bool
    new_commit_id: Optional[str] = None


class BundleCommitMemberResponse(BaseModel):
    """Serializable representation of a single BundleCommitMember row.

    Attributes:
        artifact_id: Human-readable artifact identifier.
        artifact_uuid: Stable UUID from ``artifacts.uuid``.
        artifact_version_id: FK to ``artifact_versions.id``.
        content_hash: SHA-256 content hash at commit time.
    """

    artifact_id: str
    artifact_uuid: str
    artifact_version_id: str
    content_hash: str


class BundleCommitResponse(BaseModel):
    """API response for a single BundleCommit.

    Attributes:
        id: UUIDv4 hex primary key.
        composite_artifact_id: FK to ``artifacts.uuid``.
        composite_type: Artifact type label (e.g. ``"plugin"``).
        bundle_hash: Deterministic SHA-256 of sorted member (uuid, hash) pairs.
        parent_id: ID of the prior commit; ``None`` for the first commit.
        sequence_number: Monotonic per-composite sequence counter.
        change_origin: One of ``manual``, ``sync``, ``deploy``, ``capture``,
            ``rollback``.
        created_at: ISO 8601 UTC timestamp string.
        created_by: Optional actor identifier.
        message: Optional human-readable commit message.
        is_rollback: ``True`` when this commit is a rollback/restore operation.
        rolled_back_to: ID of the target commit when ``is_rollback=True``.
        members: Eagerly serialized member list.
    """

    id: str
    composite_artifact_id: str
    composite_type: str
    bundle_hash: str
    parent_id: Optional[str]
    sequence_number: int
    change_origin: str
    created_at: str
    created_by: Optional[str]
    message: Optional[str]
    is_rollback: bool
    rolled_back_to: Optional[str]
    members: List[BundleCommitMemberResponse]


class BundleCommitCreateRequest(BaseModel):
    """Request body for creating a new BundleCommit snapshot.

    Attributes:
        composite_artifact_id: ``type:name`` primary key (or UUID) of the
            composite artifact.
        composite_type: Artifact type label.
        member_versions: Non-empty list of member payloads.
        change_origin: Event that triggered this snapshot.  Defaults to
            ``"manual"``.
        message: Optional human-readable commit message.
        created_by: Optional actor identifier.
    """

    composite_artifact_id: str
    composite_type: str
    member_versions: List[BundleCommitMemberResponse]
    change_origin: str = "manual"
    message: Optional[str] = None
    created_by: Optional[str] = None


class BundleCommitHistoryResponse(BaseModel):
    """Paginated list of BundleCommit records.

    Attributes:
        commits: Page of BundleCommit responses.
        total: Total number of commits for this composite.
        limit: Page size used for this response.
        offset: Number of records skipped before this page.
    """

    commits: List[BundleCommitResponse]
    total: int
    limit: int
    offset: int
