"""DB-backed CRUD repository for ``sync_capture_config``.

Implements per-scope configuration management for the Sync-as-Version-Capture
(SaVC) subsystem introduced by SYNC-5.2.

Design notes
------------
* Uses the local repository pattern: accepts ``db_path``, inherits from
  :class:`~skillmeat.cache.repositories.BaseRepository`, uses SQLAlchemy 1.x
  ``session.query()`` style, and binds a per-instance session factory.
* Hierarchy resolution: project > tier > global.  When
  :meth:`get_effective_config` is called, it tries the most-specific scope
  first and falls back to progressively broader ones.
* The ``global`` scope row always has ``scope_id=None``; inserting a global
  override requires passing ``scope_id=None`` explicitly.
* All timestamps are naive UTC (``datetime.utcnow()``), matching the rest of
  the SkillMeat cache layer.
* Python 3.9+ compatible — no ``X | Y`` union syntax in runtime-evaluated
  positions.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from skillmeat.cache.repositories import BaseRepository

logger = logging.getLogger(__name__)

__all__ = ["SyncCaptureConfigRepository"]

# Ordered list of scope names from most-specific to least-specific.
_SCOPE_HIERARCHY = ("project", "tier", "global")

# Fields that callers may set or update via upsert / update helpers.
_SETTABLE_FIELDS = frozenset(
    {
        "quiet_window_seconds",
        "auto_scan_enabled",
        "sync_capture_enabled",
        "max_captures_per_hour",
    }
)


class SyncCaptureConfigRepository(BaseRepository):
    """CRUD repository for :class:`~skillmeat.cache.models.SyncCaptureConfig`.

    Manages per-scope configuration overrides for the sync-capture subsystem.

    Args:
        db_path: Optional path to the SQLite DB file.  Uses the default
            ``~/.skillmeat/cache/cache.db`` when ``None``.

    Example::

        repo = SyncCaptureConfigRepository(db_path="/tmp/test.db")

        # Upsert a global fallback
        repo.upsert_config("global", None, quiet_window_seconds=45)

        # Upsert a tier-level override
        repo.upsert_config("tier", "enterprise", quiet_window_seconds=120)

        # Upsert a project-level override
        repo.upsert_config("project", "proj-abc", sync_capture_enabled=False)

        # Resolve effective config for a project in the enterprise tier
        cfg = repo.get_effective_config(scope_id="proj-abc", tier="enterprise")
        print(cfg.quiet_window_seconds)   # 120 (tier wins over global)

        # List all tier-level configs
        configs = repo.list_configs(scope="tier")
    """

    def __init__(self, db_path: Optional[Path] = None) -> None:
        # Import here to avoid circular imports at module load time.
        from skillmeat.cache.models import SyncCaptureConfig

        super().__init__(db_path=db_path, model_class=SyncCaptureConfig)
        self._model = SyncCaptureConfig

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def upsert_config(
        self,
        scope: str,
        scope_id: Optional[str],
        **settings: Any,
    ):
        """Create or update a config row for the given ``(scope, scope_id)``.

        If a row already exists for this pair the provided *settings* fields
        are merged into it and ``updated_at`` is refreshed.  Unknown keyword
        arguments are silently ignored to keep callers forward-compatible.

        Args:
            scope: Scope level — ``'global'``, ``'tier'``, or ``'project'``.
            scope_id: Discriminator within the scope.  Must be ``None`` for
                ``scope='global'``; must be non-``None`` for other scopes.
            **settings: Keyword arguments for overridable fields:
                ``quiet_window_seconds``, ``auto_scan_enabled``,
                ``sync_capture_enabled``, ``max_captures_per_hour``.

        Returns:
            The inserted or updated
            :class:`~skillmeat.cache.models.SyncCaptureConfig` ORM instance.

        Raises:
            ValueError: If *scope* is not one of the supported values, or if
                the ``scope_id`` / ``scope`` combination violates the NULL
                invariant.
        """
        _validate_scope(scope, scope_id)
        known_settings = {k: v for k, v in settings.items() if k in _SETTABLE_FIELDS}

        now = datetime.utcnow()
        session = self._get_session()
        try:
            existing = (
                session.query(self._model)
                .filter(
                    self._model.scope == scope,
                    self._model.scope_id == scope_id,
                )
                .first()
            )

            if existing is not None:
                for field, value in known_settings.items():
                    setattr(existing, field, value)
                existing.updated_at = now
                session.commit()
                session.refresh(existing)
                logger.debug(
                    "upsert_config: updated scope=%s scope_id=%s fields=%s",
                    scope,
                    scope_id,
                    list(known_settings.keys()),
                )
                return existing

            row = self._model(
                scope=scope,
                scope_id=scope_id,
                created_at=now,
                updated_at=now,
                **known_settings,
            )
            session.add(row)
            session.commit()
            session.refresh(row)
            logger.debug(
                "upsert_config: inserted scope=%s scope_id=%s id=%s",
                scope,
                scope_id,
                row.id,
            )
            return row
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def delete_config(self, scope: str, scope_id: Optional[str]) -> bool:
        """Remove the config override for the given ``(scope, scope_id)``.

        Args:
            scope: Scope level.
            scope_id: Discriminator within the scope (``None`` for global).

        Returns:
            ``True`` if a row was found and deleted, ``False`` otherwise.
        """
        session = self._get_session()
        try:
            row = (
                session.query(self._model)
                .filter(
                    self._model.scope == scope,
                    self._model.scope_id == scope_id,
                )
                .first()
            )
            if row is None:
                logger.debug(
                    "delete_config: no row found for scope=%s scope_id=%s",
                    scope,
                    scope_id,
                )
                return False

            session.delete(row)
            session.commit()
            logger.debug("delete_config: removed scope=%s scope_id=%s", scope, scope_id)
            return True
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def get_effective_config(
        self,
        scope_id: Optional[str] = None,
        tier: Optional[str] = None,
    ):
        """Resolve the effective config using the hierarchy: project > tier > global.

        Attempts candidates in order:
        1. ``scope='project', scope_id=scope_id`` (when *scope_id* is provided)
        2. ``scope='tier',    scope_id=tier``     (when *tier* is provided)
        3. ``scope='global',  scope_id=None``

        Returns the first row found, or ``None`` if no config exists at any level.

        Args:
            scope_id: Optional project-level discriminator (project ID).
                When provided, a project-scope row is tried first.
            tier: Optional tier name.  When provided, a tier-scope row is
                tried if no project-scope row is found.

        Returns:
            The resolved :class:`~skillmeat.cache.models.SyncCaptureConfig`
            instance, or ``None`` if no config exists at any scope level.
        """
        session = self._get_session()
        try:
            candidates: List[tuple[str, Optional[str]]] = []
            if scope_id is not None:
                candidates.append(("project", scope_id))
            if tier is not None:
                candidates.append(("tier", tier))
            candidates.append(("global", None))

            for cand_scope, cand_id in candidates:
                row = (
                    session.query(self._model)
                    .filter(
                        self._model.scope == cand_scope,
                        self._model.scope_id == cand_id,
                    )
                    .first()
                )
                if row is not None:
                    logger.debug(
                        "get_effective_config: resolved via scope=%s scope_id=%s",
                        cand_scope,
                        cand_id,
                    )
                    return row

            logger.debug(
                "get_effective_config: no config found for scope_id=%s tier=%s",
                scope_id,
                tier,
            )
            return None
        finally:
            session.close()

    def list_configs(self, scope: Optional[str] = None) -> List:
        """List all config rows, optionally filtered by *scope*.

        Args:
            scope: When provided, only rows with ``scope == scope`` are
                returned.  Pass ``None`` to list all scopes.

        Returns:
            List of :class:`~skillmeat.cache.models.SyncCaptureConfig`
            instances ordered by ``scope`` then ``scope_id``.
        """
        session = self._get_session()
        try:
            q = session.query(self._model)
            if scope is not None:
                q = q.filter(self._model.scope == scope)
            return q.order_by(self._model.scope.asc(), self._model.scope_id.asc()).all()
        finally:
            session.close()

    def get_config(self, scope: str, scope_id: Optional[str]):
        """Return the config row for an exact ``(scope, scope_id)`` pair.

        Args:
            scope: Scope level.
            scope_id: Discriminator (``None`` for global).

        Returns:
            The :class:`~skillmeat.cache.models.SyncCaptureConfig` instance,
            or ``None`` if no matching row exists.
        """
        session = self._get_session()
        try:
            return (
                session.query(self._model)
                .filter(
                    self._model.scope == scope,
                    self._model.scope_id == scope_id,
                )
                .first()
            )
        finally:
            session.close()


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _validate_scope(scope: str, scope_id: Optional[str]) -> None:
    """Raise :class:`ValueError` if *scope* / *scope_id* combination is invalid."""
    if scope not in _SCOPE_HIERARCHY:
        raise ValueError(
            f"Invalid scope {scope!r}. " f"Must be one of {sorted(_SCOPE_HIERARCHY)!r}."
        )
    if scope == "global" and scope_id is not None:
        raise ValueError(
            "scope_id must be None for scope='global'. " f"Got scope_id={scope_id!r}."
        )
    if scope != "global" and scope_id is None:
        raise ValueError(
            f"scope_id must be provided for scope={scope!r}. " "Got scope_id=None."
        )
