"""Local DB-backed implementation of IBundleRepository.

Delegates all persistence to the SQLAlchemy cache layer
(``skillmeat.cache.models``).  Every mutation flushes (to capture
auto-generated IDs) and then commits; reads use ``select()`` exclusively
(SQLAlchemy 2.x style) to stay consistent with the enterprise repository
pattern.

Design notes
------------
* All methods accept an injected ``Session`` rather than calling
  ``get_session()`` internally, following the DI pattern used by
  ``LocalProjectTemplateRepository`` and the enterprise repos.  The session
  lifecycle is managed by FastAPI's ``get_db_session`` dependency.
* Business-rule enforcement (draft-only updates, lifecycle transitions) is
  implemented here rather than in the router, keeping the router thin.
* No ``HTTPException`` is raised — callers (routers) translate
  ``ValueError``/``KeyError`` to appropriate HTTP status codes.
* Tags are stored as a JSON array in a single ``Text`` column to avoid schema
  migration overhead (matching ``BundleEntity.tags`` definition).
* ``IntegrityError`` on ``add_member`` is caught and re-raised as
  ``ValueError`` so the router can return 409 Conflict without knowing the
  storage backend.
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

from skillmeat.core.interfaces.context import RequestContext
from skillmeat.core.interfaces.dtos import BundleDTO, BundleListDTO, BundleMembershipDTO
from skillmeat.core.interfaces.repositories import IBundleRepository

# ---------------------------------------------------------------------------
# Optional DB imports — graceful degradation in minimal test environments.
# ---------------------------------------------------------------------------
try:
    from skillmeat.cache.models import (
        Artifact as _DBArtifact,
        BundleEntity as _DBBundleEntity,
        BundleMembership as _DBBundleMembership,
        BundleStatus as _BundleStatus,
    )

    _db_available = True
except ImportError:  # pragma: no cover
    _DBArtifact = None  # type: ignore[assignment]
    _DBBundleEntity = None  # type: ignore[assignment]
    _DBBundleMembership = None  # type: ignore[assignment]
    _BundleStatus = None  # type: ignore[assignment]
    _db_available = False

logger = logging.getLogger(__name__)

__all__ = ["LocalBundleRepository"]


# ---------------------------------------------------------------------------
# Private serialisation helpers
# ---------------------------------------------------------------------------


def _to_dict(entity: Any) -> dict[str, Any]:
    """Convert a ``BundleEntity`` ORM instance to a plain dictionary.

    Args:
        entity: SQLAlchemy ``BundleEntity`` ORM object.

    Returns:
        Plain ``dict`` suitable for JSON serialisation.  The ``tags`` field
        is always a ``list[str]`` (never a raw JSON string).
    """
    raw_tags = getattr(entity, "tags", None)
    if raw_tags:
        try:
            parsed = json.loads(raw_tags)
            tags: list[str] = (
                [t for t in parsed if isinstance(t, str)]
                if isinstance(parsed, list)
                else []
            )
        except (json.JSONDecodeError, TypeError):
            tags = []
    else:
        tags = []

    created_at = entity.created_at
    updated_at = entity.updated_at
    published_at = entity.published_at

    memberships = getattr(entity, "memberships", []) or []

    return {
        "id": entity.id,
        "collection_id": entity.collection_id,
        "name": entity.name,
        "description": entity.description,
        "version": entity.version,
        "status": entity.status,
        "tags": tags,
        "license": entity.license,
        "homepage": entity.homepage,
        "repository": entity.repository,
        "created_at": (
            created_at.isoformat()
            if created_at and hasattr(created_at, "isoformat")
            else (created_at if isinstance(created_at, str) else None)
        ),
        "updated_at": (
            updated_at.isoformat()
            if updated_at and hasattr(updated_at, "isoformat")
            else (updated_at if isinstance(updated_at, str) else None)
        ),
        "published_at": (
            published_at.isoformat()
            if published_at and hasattr(published_at, "isoformat")
            else (published_at if isinstance(published_at, str) else None)
        ),
        "memberships": [_member_to_dict(m) for m in memberships],
    }


def _member_to_dict(membership: Any) -> dict[str, Any]:
    """Convert a ``BundleMembership`` ORM instance to a plain dictionary.

    Args:
        membership: SQLAlchemy ``BundleMembership`` ORM object.

    Returns:
        Plain ``dict`` suitable for JSON serialisation.
    """
    added_at = membership.added_at
    return {
        "bundle_id": membership.bundle_id,
        "member_type": getattr(membership, "member_type", "artifact") or "artifact",
        "artifact_uuid": membership.artifact_uuid,
        "context_entity_id": getattr(membership, "context_entity_id", None),
        "artifact_tier": membership.artifact_tier,
        "relationship_type": membership.relationship_type,
        "pinned_version_hash": membership.pinned_version_hash,
        "added_at": (
            added_at.isoformat()
            if added_at and hasattr(added_at, "isoformat")
            else (added_at if isinstance(added_at, str) else None)
        ),
    }


# ---------------------------------------------------------------------------
# DTO converter helpers
# ---------------------------------------------------------------------------


def _membership_to_dto(membership: Any) -> BundleMembershipDTO:
    """Convert a ``BundleMembership`` ORM instance to a :class:`BundleMembershipDTO`.

    Args:
        membership: SQLAlchemy ``BundleMembership`` ORM object.

    Returns:
        Immutable :class:`BundleMembershipDTO` instance.
    """
    return BundleMembershipDTO.from_dict(_member_to_dict(membership))


def _entity_to_dto(entity: Any) -> BundleDTO:
    """Convert a ``BundleEntity`` ORM instance to a :class:`BundleDTO`.

    Args:
        entity: SQLAlchemy ``BundleEntity`` ORM object.

    Returns:
        Immutable :class:`BundleDTO` instance (with embedded memberships).
    """
    return BundleDTO.from_dict(_to_dict(entity))


# ---------------------------------------------------------------------------
# Repository implementation
# ---------------------------------------------------------------------------


class LocalBundleRepository(IBundleRepository):
    """SQLite-backed implementation of :class:`IBundleRepository`.

    Uses the injected ``session`` for all database operations.  Mutations
    flush then commit; reads never commit.

    Args:
        session: A SQLAlchemy ``Session`` injected via FastAPI's
            ``get_db_session`` dependency.
    """

    def __init__(self, session: Session) -> None:
        """Initialise with an injected SQLAlchemy session.

        Args:
            session: Active SQLAlchemy session for this request.
        """
        self._session = session

    # ------------------------------------------------------------------
    # Bundle CRUD
    # ------------------------------------------------------------------

    def create_bundle(
        self,
        name: str,
        collection_id: str,
        description: str | None = None,
        version: str | None = None,
        tags: list[str] | None = None,
        license: str | None = None,
        homepage: str | None = None,
        repository: str | None = None,
        ctx: RequestContext | None = None,
    ) -> BundleDTO:
        """Create a new bundle in draft status.

        Args:
            name: Human-readable bundle name (unique within the collection).
            collection_id: Owning collection identifier.
            description: Optional free-text description.
            version: Optional initial semver string.
            tags: Optional list of tag strings.
            license: Optional SPDX license identifier (e.g. ``"MIT"``).
            homepage: Optional URL for documentation or homepage.
            repository: Optional URL for the source repository.
            ctx: Optional per-request metadata (unused, reserved for future
                tenant scoping).

        Returns:
            Dict representation of the newly created bundle.

        Raises:
            ValueError: If a bundle with *name* already exists in
                *collection_id*.
        """
        # Check for name collision within the collection
        existing = self._session.execute(
            select(_DBBundleEntity).where(
                _DBBundleEntity.collection_id == collection_id,
                _DBBundleEntity.name == name,
            )
        ).scalar_one_or_none()
        if existing is not None:
            raise ValueError(
                f"Bundle '{name}' already exists in collection '{collection_id}'"
            )

        tags_json = json.dumps(tags) if tags else None
        entity = _DBBundleEntity(
            id=uuid.uuid4().hex,
            name=name,
            collection_id=collection_id,
            description=description,
            version=version,
            status=_BundleStatus.draft.value,
            tags=tags_json,
            license=license,
            homepage=homepage,
            repository=repository,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        self._session.add(entity)
        try:
            self._session.flush()
            self._session.commit()
        except Exception:
            self._session.rollback()
            raise
        logger.debug("Created bundle '%s' (id=%s)", name, entity.id)
        return _entity_to_dto(entity)

    def get_bundle(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
    ) -> BundleDTO:
        """Return the bundle with the given identifier.

        Args:
            bundle_id: UUID hex primary key.
            ctx: Optional per-request metadata.

        Returns:
            Dict representation of the bundle including its membership list.

        Raises:
            ValueError: If no bundle with *bundle_id* exists.
        """
        entity = self._session.execute(
            select(_DBBundleEntity).where(_DBBundleEntity.id == bundle_id)
        ).scalar_one_or_none()
        if entity is None:
            raise ValueError(f"Bundle '{bundle_id}' not found")
        return _entity_to_dto(entity)

    def get_bundle_by_name(
        self,
        name: str,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> BundleDTO | None:
        """Return the bundle matching *name* within *collection_id*.

        Args:
            name: Bundle name to look up.
            collection_id: Owning collection identifier.
            ctx: Optional per-request metadata.

        Returns:
            Dict representation of the bundle when found, ``None`` otherwise.
        """
        entity = self._session.execute(
            select(_DBBundleEntity).where(
                _DBBundleEntity.name == name,
                _DBBundleEntity.collection_id == collection_id,
            )
        ).scalar_one_or_none()
        if entity is None:
            return None
        return _entity_to_dto(entity)

    def list_bundles(
        self,
        collection_id: str | None = None,
        status: str | None = None,
        tags: list[str] | None = None,
        page: int = 1,
        page_size: int = 50,
        ctx: RequestContext | None = None,
    ) -> BundleListDTO:
        """Return a paginated list of bundles matching the given filters.

        Args:
            collection_id: Restrict results to a specific collection.
            status: Restrict results to a specific lifecycle status.
            tags: Restrict results to bundles containing all listed tags.
                Tag filtering is done in Python after the DB query because tags
                are stored as a JSON blob.
            page: 1-based page number.
            page_size: Maximum items per page.
            ctx: Optional per-request metadata.

        Returns:
            Dict with keys ``"items"``, ``"total"``, ``"page"``,
            ``"page_size"``.
        """
        stmt = select(_DBBundleEntity)
        if collection_id is not None:
            stmt = stmt.where(_DBBundleEntity.collection_id == collection_id)
        if status is not None:
            stmt = stmt.where(_DBBundleEntity.status == status)

        all_entities = list(self._session.execute(stmt).scalars().all())

        # Apply tag filter in Python (tags stored as JSON Text column)
        if tags:
            filtered: list[Any] = []
            for entity in all_entities:
                raw = getattr(entity, "tags", None)
                try:
                    entity_tags: list[str] = json.loads(raw) if raw else []
                except (json.JSONDecodeError, TypeError):
                    entity_tags = []
                if all(t in entity_tags for t in tags):
                    filtered.append(entity)
        else:
            filtered = all_entities

        total = len(filtered)
        offset = (page - 1) * page_size
        page_entities = filtered[offset : offset + page_size]

        return BundleListDTO(
            items=[_entity_to_dto(e) for e in page_entities],
            total=total,
            page=page,
            page_size=page_size,
        )

    def update_bundle(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
        **kwargs: Any,
    ) -> BundleDTO:
        """Apply a partial update to an existing draft bundle.

        Only bundles in ``"draft"`` status may be updated.

        Args:
            bundle_id: UUID hex primary key.
            ctx: Optional per-request metadata.
            **kwargs: Field names and new values.  The ``tags`` field may be
                passed as a ``list[str]`` and is serialised to JSON
                automatically.

        Returns:
            Dict representation of the updated bundle.

        Raises:
            ValueError: If the bundle does not exist or is not in ``"draft"``
                status.
        """
        entity = self._session.execute(
            select(_DBBundleEntity).where(_DBBundleEntity.id == bundle_id)
        ).scalar_one_or_none()
        if entity is None:
            raise ValueError(f"Bundle '{bundle_id}' not found")
        if entity.status != _BundleStatus.draft.value:
            raise ValueError(
                f"Bundle '{bundle_id}' is in status '{entity.status}'; "
                "only draft bundles may be updated"
            )

        allowed_fields = {
            "name",
            "description",
            "version",
            "tags",
            "license",
            "homepage",
            "repository",
        }
        for key, value in kwargs.items():
            if key not in allowed_fields:
                logger.warning("update_bundle: ignoring unknown field '%s'", key)
                continue
            if key == "tags":
                value = json.dumps(value) if value is not None else None
            setattr(entity, key, value)
        entity.updated_at = datetime.utcnow()

        try:
            self._session.flush()
            self._session.commit()
        except Exception:
            self._session.rollback()
            raise

        return _entity_to_dto(entity)

    def delete_bundle(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
    ) -> None:
        """Delete or deprecate a bundle depending on its current status.

        * ``"draft"`` -> hard delete.
        * ``"published"`` -> soft-delete (set status to ``"deprecated"``).
        * ``"deprecated"`` -> no-op.

        Args:
            bundle_id: UUID hex primary key.
            ctx: Optional per-request metadata.

        Raises:
            ValueError: If no bundle with *bundle_id* exists.
        """
        entity = self._session.execute(
            select(_DBBundleEntity).where(_DBBundleEntity.id == bundle_id)
        ).scalar_one_or_none()
        if entity is None:
            raise ValueError(f"Bundle '{bundle_id}' not found")

        if entity.status == _BundleStatus.deprecated.value:
            # Already deprecated — nothing to do
            return

        if entity.status == _BundleStatus.published.value:
            entity.status = _BundleStatus.deprecated.value
            entity.updated_at = datetime.utcnow()
            try:
                self._session.flush()
                self._session.commit()
            except Exception:
                self._session.rollback()
                raise
            logger.debug("Deprecated bundle '%s'", bundle_id)
            return

        # draft -> hard delete
        try:
            self._session.delete(entity)
            self._session.commit()
        except Exception:
            self._session.rollback()
            raise
        logger.debug("Deleted bundle '%s'", bundle_id)

    # ------------------------------------------------------------------
    # Membership management
    # ------------------------------------------------------------------

    def add_member(
        self,
        bundle_id: str,
        artifact_uuid: str | None = None,
        artifact_tier: int = 0,
        relationship_type: str = "contains",
        pinned_version_hash: str | None = None,
        member_type: str = "artifact",
        context_entity_id: str | None = None,
        ctx: RequestContext | None = None,
    ) -> BundleMembershipDTO:
        """Add an artifact or context entity to a bundle.

        Args:
            bundle_id: UUID hex primary key of the bundle.
            artifact_uuid: Stable ``artifacts.uuid`` of the artifact to add.
                Must be provided when ``member_type="artifact"``.
            artifact_tier: Tier classification (0/1/2).
            relationship_type: Semantic edge label.
            pinned_version_hash: Optional content hash snapshot pin.
            member_type: Discriminator — ``"artifact"`` (default) or
                ``"context_entity"``.
            context_entity_id: Context entity identifier.  Must be provided
                when ``member_type="context_entity"``.
            ctx: Optional per-request metadata.

        Returns:
            Dict representation of the created membership row.

        Raises:
            ValueError: If the bundle does not exist or the member is already
                present.
        """
        # Ensure bundle exists
        entity = self._session.execute(
            select(_DBBundleEntity).where(_DBBundleEntity.id == bundle_id)
        ).scalar_one_or_none()
        if entity is None:
            raise ValueError(f"Bundle '{bundle_id}' not found")

        membership = _DBBundleMembership(
            bundle_id=bundle_id,
            member_type=member_type,
            artifact_uuid=artifact_uuid,
            context_entity_id=context_entity_id,
            artifact_tier=artifact_tier,
            relationship_type=relationship_type,
            pinned_version_hash=pinned_version_hash,
            added_at=datetime.utcnow(),
        )
        self._session.add(membership)
        try:
            self._session.flush()
            self._session.commit()
        except IntegrityError:
            self._session.rollback()
            member_ref = artifact_uuid or context_entity_id
            raise ValueError(
                f"Member '{member_ref}' is already a member of bundle '{bundle_id}'"
            )
        except Exception:
            self._session.rollback()
            raise

        if member_type == "context_entity":
            logger.debug(
                "Added context entity '%s' to bundle '%s'",
                context_entity_id,
                bundle_id,
            )
        else:
            logger.debug("Added artifact '%s' to bundle '%s'", artifact_uuid, bundle_id)
        return _membership_to_dto(membership)

    def remove_member(
        self,
        bundle_id: str,
        artifact_uuid: str,
        ctx: RequestContext | None = None,
    ) -> None:
        """Remove an artifact from a bundle.

        Only ``"draft"`` bundles permit member removal.

        Args:
            bundle_id: UUID hex primary key of the bundle.
            artifact_uuid: Stable ``artifacts.uuid`` to remove.
            ctx: Optional per-request metadata.

        Raises:
            ValueError: If the bundle is not in ``"draft"`` status or the
                membership does not exist.
        """
        entity = self._session.execute(
            select(_DBBundleEntity).where(_DBBundleEntity.id == bundle_id)
        ).scalar_one_or_none()
        if entity is None:
            raise ValueError(f"Bundle '{bundle_id}' not found")
        if entity.status != _BundleStatus.draft.value:
            raise ValueError(
                f"Bundle '{bundle_id}' is in status '{entity.status}'; "
                "members can only be removed from draft bundles"
            )

        membership = self._session.execute(
            select(_DBBundleMembership).where(
                _DBBundleMembership.bundle_id == bundle_id,
                _DBBundleMembership.artifact_uuid == artifact_uuid,
            )
        ).scalar_one_or_none()
        if membership is None:
            raise ValueError(
                f"Artifact '{artifact_uuid}' is not a member of bundle '{bundle_id}'"
            )

        try:
            self._session.delete(membership)
            self._session.commit()
        except Exception:
            self._session.rollback()
            raise
        logger.debug("Removed artifact '%s' from bundle '%s'", artifact_uuid, bundle_id)

    def list_members(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
    ) -> list[BundleMembershipDTO]:
        """Return all membership records for a bundle.

        Args:
            bundle_id: UUID hex primary key of the bundle.
            ctx: Optional per-request metadata.

        Returns:
            List of membership dicts ordered by ``added_at`` ascending.

        Raises:
            ValueError: If no bundle with *bundle_id* exists.
        """
        entity = self._session.execute(
            select(_DBBundleEntity).where(_DBBundleEntity.id == bundle_id)
        ).scalar_one_or_none()
        if entity is None:
            raise ValueError(f"Bundle '{bundle_id}' not found")

        memberships = (
            self._session.execute(
                select(_DBBundleMembership)
                .where(_DBBundleMembership.bundle_id == bundle_id)
                .order_by(_DBBundleMembership.added_at)
            )
            .scalars()
            .all()
        )

        return [_membership_to_dto(m) for m in memberships]

    # ------------------------------------------------------------------
    # Lifecycle transitions
    # ------------------------------------------------------------------

    def publish_bundle(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
    ) -> BundleDTO:
        """Transition a bundle from ``"draft"`` to ``"published"``.

        Args:
            bundle_id: UUID hex primary key.
            ctx: Optional per-request metadata.

        Returns:
            Dict representation of the published bundle.

        Raises:
            ValueError: If the bundle does not exist or is not in ``"draft"``
                status.
        """
        entity = self._session.execute(
            select(_DBBundleEntity).where(_DBBundleEntity.id == bundle_id)
        ).scalar_one_or_none()
        if entity is None:
            raise ValueError(f"Bundle '{bundle_id}' not found")
        if entity.status != _BundleStatus.draft.value:
            raise ValueError(
                f"Bundle '{bundle_id}' is in status '{entity.status}'; "
                "only draft bundles can be published"
            )

        now = datetime.utcnow()
        entity.status = _BundleStatus.published.value
        entity.updated_at = now
        if entity.published_at is None:
            entity.published_at = now

        try:
            self._session.flush()
            self._session.commit()
        except Exception:
            self._session.rollback()
            raise

        logger.debug("Published bundle '%s'", bundle_id)
        return _entity_to_dto(entity)

    def deprecate_bundle(
        self,
        bundle_id: str,
        ctx: RequestContext | None = None,
    ) -> BundleDTO:
        """Transition a bundle from ``"published"`` to ``"deprecated"``.

        Args:
            bundle_id: UUID hex primary key.
            ctx: Optional per-request metadata.

        Returns:
            Dict representation of the deprecated bundle.

        Raises:
            ValueError: If the bundle does not exist or is not in
                ``"published"`` status.
        """
        entity = self._session.execute(
            select(_DBBundleEntity).where(_DBBundleEntity.id == bundle_id)
        ).scalar_one_or_none()
        if entity is None:
            raise ValueError(f"Bundle '{bundle_id}' not found")
        if entity.status != _BundleStatus.published.value:
            raise ValueError(
                f"Bundle '{bundle_id}' is in status '{entity.status}'; "
                "only published bundles can be deprecated"
            )

        entity.status = _BundleStatus.deprecated.value
        entity.updated_at = datetime.utcnow()

        try:
            self._session.flush()
            self._session.commit()
        except Exception:
            self._session.rollback()
            raise

        logger.debug("Deprecated bundle '%s'", bundle_id)
        return _entity_to_dto(entity)
