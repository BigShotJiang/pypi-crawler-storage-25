"""DB-backed CRUD repository for ``sync_debounce_entries``.

Implements the debounce entry lifecycle for the Sync-as-Version-Capture (SaVC)
subsystem introduced by the dvcs-unified-sync feature.

Design notes
------------
* Uses the local repository pattern: accepts ``db_path``, inherits from
  :class:`~skillmeat.cache.repositories.BaseRepository`, uses SQLAlchemy 1.x
  ``session.query()`` style, and binds a per-instance session factory.
* The upsert semantic enforces the invariant that at most one ``pending`` row
  exists per ``(artifact_id, project_id)`` pair.  Concurrent writers may
  produce two rows momentarily; the polling path is idempotent and will
  process both, so this is safe without a DB-level lock.
* All timestamps are naive UTC (``datetime.utcnow()``), matching the rest of
  the SkillMeat cache layer.
* Python 3.9+ compatible — no ``X | Y`` union syntax in runtime-evaluated
  positions.
"""

from __future__ import annotations

import logging
import random
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

from skillmeat.cache.repositories import BaseRepository

logger = logging.getLogger(__name__)

__all__ = ["SyncDebounceRepository"]

# Default valid statuses for prune_old; defined here to avoid mutable default args.
_PRUNABLE_STATUSES = ("captured", "expired", "rate_limited")

# Maximum stagger offset (seconds) applied per entry in batch_create_entries to
# prevent thundering-herd load on the background poller when a cascade fires.
# Each entry receives a uniform-random offset in [0, _MAX_JITTER_S].
_MAX_JITTER_S: int = 5


class SyncDebounceRepository(BaseRepository):
    """CRUD repository for :class:`~skillmeat.cache.models.SyncDebounceEntry`.

    Manages the lifecycle of debounce entries used by the periodic background
    scanner and the on-access sync capture path.

    Args:
        db_path: Optional path to the SQLite DB file.  Uses the default
            ``~/.skillmeat/cache/cache.db`` when ``None``.

    Example::

        repo = SyncDebounceRepository(db_path="/tmp/test.db")

        # Record a detected change
        entry = repo.upsert_pending(
            artifact_id="skill:my-skill",
            content_hash="abc123",
            trigger_source="on_access",
            quiet_seconds=30,
        )

        # Poll for entries whose quiet window has expired
        expired = repo.get_expired_pending(limit=50)
        for e in expired:
            # ... re-check hash and capture version ...
            repo.mark_captured(e.id)
    """

    def __init__(self, db_path: Optional[Path] = None) -> None:
        # Import here to avoid circular imports at module load time.
        from skillmeat.cache.models import SyncDebounceEntry

        super().__init__(db_path=db_path, model_class=SyncDebounceEntry)
        self._model = SyncDebounceEntry

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def upsert_pending(
        self,
        artifact_id: str,
        content_hash: str,
        trigger_source: str = "manual",
        quiet_seconds: int = 30,
        project_id: Optional[str] = None,
    ) -> Optional["SyncDebounceEntry"]:  # type: ignore[name-defined]  # noqa: F821
        """Create or refresh a pending debounce entry for *artifact_id*.

        If a ``pending`` entry already exists for this
        ``(artifact_id, project_id)`` pair, update its ``detected_hash``,
        reset ``quiet_until`` to ``now + quiet_seconds``, update
        ``trigger_source``, and update ``detected_at``.  Otherwise insert a
        fresh row.

        If *artifact_id* does not exist in the ``artifacts`` table the insert
        would violate the foreign-key constraint.  In that case the method
        logs a debug message and returns ``None`` without raising.  This can
        happen when a filesystem artifact has been detected but has not yet
        been synced into the DB cache.

        Args:
            artifact_id: Artifact primary key (``"type:name"`` string matching
                ``artifacts.id``).
            content_hash: Current content hash detected for the artifact.
            trigger_source: Attribution for who triggered detection.  One of
                ``'manual'``, ``'on_access'``, ``'periodic'``,
                ``'fs_watcher'``.
            quiet_seconds: Number of seconds to wait before the background
                poller should re-check this entry.  Defaults to ``30``.
            project_id: Optional project identifier (``projects.id``).  Pass
                ``None`` for collection-level debounce.

        Returns:
            The inserted or updated
            :class:`~skillmeat.cache.models.SyncDebounceEntry` ORM instance,
            or ``None`` when *artifact_id* is not present in the cache.
        """
        now = datetime.utcnow()
        quiet_until = now + timedelta(seconds=quiet_seconds)

        session = self._get_session()
        try:
            existing = (
                session.query(self._model)
                .filter(
                    self._model.artifact_id == artifact_id,
                    self._model.project_id == project_id,
                    self._model.status == "pending",
                )
                .first()
            )

            if existing is not None:
                # Refresh the quiet window for the ongoing change.
                existing.detected_hash = content_hash
                existing.quiet_until = quiet_until
                existing.detected_at = now
                existing.trigger_source = trigger_source
                session.commit()
                session.refresh(existing)
                logger.debug(
                    "upsert_pending: refreshed quiet window for artifact_id=%s "
                    "project_id=%s quiet_until=%s",
                    artifact_id,
                    project_id,
                    quiet_until.isoformat(),
                )
                return existing

            # Guard: ensure the artifact exists in the DB cache before
            # attempting an insert that would violate the FK constraint.
            # An artifact may be present on the filesystem but not yet synced
            # into the cache (e.g. detected during drift check before the
            # first full cache refresh).
            from skillmeat.cache.models import Artifact as _Artifact  # noqa: PLC0415

            artifact_row = (
                session.query(_Artifact).filter(_Artifact.id == artifact_id).first()
            )
            if artifact_row is None:
                logger.debug(
                    "upsert_pending: artifact_id=%s not in cache, skipping "
                    "debounce entry",
                    artifact_id,
                )
                return None

            if project_id is not None:
                from skillmeat.cache.models import Project as _Project  # noqa: PLC0415

                project_row = (
                    session.query(_Project).filter(_Project.id == project_id).first()
                )
                if project_row is None:
                    logger.debug(
                        "upsert_pending: project_id=%s not in cache, skipping "
                        "debounce entry",
                        project_id,
                    )
                    return None

            # No pending entry — insert a new one.
            entry = self._model(
                id=uuid.uuid4().hex,
                artifact_id=artifact_id,
                project_id=project_id,
                detected_hash=content_hash,
                detected_at=now,
                quiet_until=quiet_until,
                status="pending",
                trigger_source=trigger_source,
                created_at=now,
            )
            session.add(entry)
            session.commit()
            session.refresh(entry)
            logger.debug(
                "upsert_pending: inserted new entry id=%s artifact_id=%s "
                "project_id=%s quiet_until=%s",
                entry.id,
                artifact_id,
                project_id,
                quiet_until.isoformat(),
            )
            return entry
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def batch_create_entries(
        self,
        artifact_changes: Sequence[Tuple[str, str]],
        upstream_hash: str,
        change_source: str = "cascade",
        quiet_seconds: int = 30,
        project_id: Optional[str] = None,
    ) -> int:
        """Bulk-insert debounce entries for a list of downstream artifacts.

        Designed for use by :class:`~skillmeat.core.upstream_cascade.UpstreamCascadeService`
        after a cascade propagation: each downstream artifact that needs version
        capture gets a debounce entry in a single transaction.

        Cascade-aware dedup
        -------------------
        An entry is **skipped** when the artifact's current ``content_hash``
        already equals *upstream_hash* — meaning the downstream artifact is
        already at the new version and no actual change occurred.  This avoids
        polluting the debounce queue with no-op entries.

        Thundering-herd mitigation
        --------------------------
        Each entry's ``detected_at`` timestamp is staggered by a uniformly
        distributed random offset in ``[0, _MAX_JITTER_S]`` seconds.
        ``quiet_until`` is derived from ``detected_at + quiet_seconds``, so
        entries naturally expire at different times and distribute poller load.

        The ``trigger_source`` stored in the DB is ``"manual"`` because
        ``"cascade"`` is not in the schema CHECK constraint.  The *change_source*
        parameter is used for logging and caller attribution only.

        Args:
            artifact_changes: Sequence of ``(artifact_id, content_hash)`` tuples
                identifying downstream artifacts and their current content hashes.
                The *content_hash* is the downstream artifact's current hash —
                used for cascade-aware dedup against *upstream_hash*.
            upstream_hash: The new upstream content hash that triggered the
                cascade.  Entries are skipped when
                ``artifact_content_hash == upstream_hash``.
            change_source: Attribution label for logging (e.g. ``"cascade"``).
                Not stored directly in DB due to CHECK constraint; logged at
                DEBUG level for traceability.
            quiet_seconds: Quiet window duration in seconds applied to every
                entry (before jitter).  Defaults to ``30``.
            project_id: Optional project scope for all entries.  Pass ``None``
                for collection-level debounce.

        Returns:
            Number of debounce entries actually inserted (after dedup filtering).

        Example::

            repo = SyncDebounceRepository(db_path=db_path)
            created = repo.batch_create_entries(
                artifact_changes=[
                    ("skill:canvas", "old-hash-1"),
                    ("skill:writer", "new-upstream-hash"),  # same → skipped
                ],
                upstream_hash="new-upstream-hash",
                change_source="cascade",
                quiet_seconds=30,
            )
            # created == 1 (second entry skipped — hash already matches)
        """
        if not artifact_changes:
            return 0

        now = datetime.utcnow()
        entries_to_add = []
        skipped_count = 0

        for artifact_id, current_hash in artifact_changes:
            # Cascade-aware dedup: skip if the artifact's hash already equals
            # the upstream hash — no actual change propagated to this artifact.
            if current_hash == upstream_hash:
                logger.debug(
                    "batch_create_entries: skipping artifact_id=%s "
                    "(hash already matches upstream hash=%s, source=%s)",
                    artifact_id,
                    upstream_hash,
                    change_source,
                )
                skipped_count += 1
                continue

            # Apply per-entry random jitter to stagger quiet_until expiry times.
            jitter_s = random.uniform(0, _MAX_JITTER_S)
            detected_at = now + timedelta(seconds=jitter_s)
            quiet_until = detected_at + timedelta(seconds=quiet_seconds)

            entries_to_add.append(
                self._model(
                    id=uuid.uuid4().hex,
                    artifact_id=artifact_id,
                    project_id=project_id,
                    detected_hash=upstream_hash,
                    detected_at=detected_at,
                    quiet_until=quiet_until,
                    status="pending",
                    # "cascade" is not in the DB CHECK constraint; use "manual"
                    # as the stored value and record attribution via the log.
                    trigger_source="manual",
                    created_at=now,
                )
            )

        if not entries_to_add:
            logger.debug(
                "batch_create_entries: all %d artifact(s) skipped via dedup "
                "(source=%s)",
                skipped_count,
                change_source,
            )
            return 0

        session = self._get_session()
        try:
            session.bulk_save_objects(entries_to_add)
            session.commit()
            created_count = len(entries_to_add)
            logger.info(
                "batch_create_entries: inserted %d debounce entries "
                "(skipped=%d, source=%s, project_id=%s)",
                created_count,
                skipped_count,
                change_source,
                project_id,
            )
            return created_count
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def mark_captured(
        self,
        entry_id: str,
        version_id: Optional[str] = None,
    ) -> bool:
        """Transition entry *entry_id* to ``'captured'`` status.

        Sets ``status='captured'`` and ``captured_at=now``.  If *version_id*
        is provided it is stored in a debug log (the model has no dedicated
        column for it; callers may associate via the ``ArtifactVersion``
        row directly).

        Args:
            entry_id: Primary key (UUID hex) of the debounce entry.
            version_id: Optional identifier of the ``ArtifactVersion`` that
                was created for this capture (informational only).

        Returns:
            ``True`` if the row was found and updated, ``False`` otherwise.
        """
        session = self._get_session()
        try:
            entry = (
                session.query(self._model).filter(self._model.id == entry_id).first()
            )
            if entry is None:
                logger.warning("mark_captured: entry_id=%s not found", entry_id)
                return False

            entry.status = "captured"
            entry.captured_at = datetime.utcnow()
            session.commit()
            logger.debug(
                "mark_captured: entry_id=%s version_id=%s", entry_id, version_id
            )
            return True
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def mark_rate_limited(
        self,
        entry_id: str,
    ) -> bool:
        """Transition entry *entry_id* to ``'rate_limited'`` status.

        Used when the per-artifact capture rate limit is exceeded.  The entry
        is preserved (not deleted) so that the rate-limit event is auditable.

        Args:
            entry_id: Primary key (UUID hex) of the debounce entry.

        Returns:
            ``True`` if the row was found and updated, ``False`` otherwise.
        """
        session = self._get_session()
        try:
            entry = (
                session.query(self._model).filter(self._model.id == entry_id).first()
            )
            if entry is None:
                logger.warning("mark_rate_limited: entry_id=%s not found", entry_id)
                return False

            entry.status = "rate_limited"
            session.commit()
            logger.debug("mark_rate_limited: entry_id=%s", entry_id)
            return True
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def mark_skipped(
        self,
        entry_id: str,
        reason: Optional[str] = None,
    ) -> bool:
        """Transition entry *entry_id* to ``'skipped'`` status.

        Args:
            entry_id: Primary key (UUID hex) of the debounce entry.
            reason: Optional human-readable reason (logged at DEBUG level).

        Returns:
            ``True`` if the row was found and updated, ``False`` otherwise.
        """
        session = self._get_session()
        try:
            entry = (
                session.query(self._model).filter(self._model.id == entry_id).first()
            )
            if entry is None:
                logger.warning("mark_skipped: entry_id=%s not found", entry_id)
                return False

            entry.status = "skipped"
            session.commit()
            logger.debug("mark_skipped: entry_id=%s reason=%s", entry_id, reason)
            return True
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def get_expired_pending(self, limit: int = 100) -> List:
        """Return pending entries whose quiet window has expired.

        Queries rows with ``status='pending'`` and ``quiet_until <= now()``,
        ordered by ``quiet_until ASC`` so oldest-expired entries are
        processed first.

        Args:
            limit: Maximum number of entries to return.  Defaults to ``100``.

        Returns:
            List of :class:`~skillmeat.cache.models.SyncDebounceEntry`
            instances, possibly empty.
        """
        now = datetime.utcnow()
        session = self._get_session()
        try:
            entries = (
                session.query(self._model)
                .filter(
                    self._model.status == "pending",
                    self._model.quiet_until <= now,
                )
                .order_by(self._model.quiet_until.asc())
                .limit(limit)
                .all()
            )
            return entries
        finally:
            session.close()

    def get_pending_for_artifact(
        self,
        artifact_id: str,
        project_id: Optional[str] = None,
    ):
        """Return the current pending entry for *artifact_id*, if any.

        Args:
            artifact_id: Artifact primary key (``"type:name"`` string).
            project_id: Optional project scope.  Pass ``None`` to match
                collection-level entries (``project_id IS NULL``).

        Returns:
            A :class:`~skillmeat.cache.models.SyncDebounceEntry` instance,
            or ``None`` if no pending entry exists.
        """
        session = self._get_session()
        try:
            return (
                session.query(self._model)
                .filter(
                    self._model.artifact_id == artifact_id,
                    self._model.project_id == project_id,
                    self._model.status == "pending",
                )
                .first()
            )
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def prune_old(
        self,
        status_list: Optional[List[str]] = None,
        older_than_days: int = 7,
    ) -> int:
        """Delete stale entries by status and age.

        Removes entries whose ``created_at`` is older than *older_than_days*
        days AND whose ``status`` is in *status_list*.  This keeps the
        debounce table lean over time without discarding actionable pending
        entries.

        Args:
            status_list: Statuses eligible for deletion.  Defaults to
                ``['captured', 'expired']``.  Pass an explicit list to
                include ``'skipped'`` or restrict the set further.
            older_than_days: Age threshold in days.  Rows with
                ``created_at < now - older_than_days`` are deleted.
                Defaults to ``7``.

        Returns:
            Number of rows deleted.
        """
        if status_list is None:
            status_list = list(_PRUNABLE_STATUSES)

        cutoff = datetime.utcnow() - timedelta(days=older_than_days)
        session = self._get_session()
        try:
            deleted_count = (
                session.query(self._model)
                .filter(
                    self._model.status.in_(status_list),
                    self._model.created_at < cutoff,
                )
                .delete(synchronize_session="fetch")
            )
            session.commit()
            logger.debug(
                "prune_old: deleted %d rows (status_list=%s older_than_days=%d)",
                deleted_count,
                status_list,
                older_than_days,
            )
            return deleted_count
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
