"""Forced rollout implementation for enterprise governance.

When an enterprise artifact with enforce_override=True is updated by a system_admin,
this module cascades the change to all downstream team and user collections
via fast-forward overwrite (no merge prompt).

Each overwrite is logged as an "Administrative Override" in artifact history.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, List, Optional, Protocol

logger = logging.getLogger(__name__)


class ArtifactHistoryWriter(Protocol):
    """Protocol for writing to artifact history."""

    def write_history_entry(
        self,
        artifact_id: str,
        action: str,
        actor_id: str,
        details: dict[str, Any],
    ) -> None: ...


@dataclass(frozen=True)
class RolloutTarget:
    """A downstream collection that should receive the enterprise artifact."""

    owner_id: str
    owner_type: str  # "team" or "user"
    collection_id: Optional[str] = None


@dataclass
class RolloutResult:
    """Result of rolling out to a single downstream target."""

    target: RolloutTarget
    success: bool
    error: Optional[str] = None
    applied_at: Optional[datetime] = None


@dataclass
class ForcedRolloutSummary:
    """Summary of a complete forced rollout operation."""

    artifact_id: str
    tenant_id: str
    admin_id: str
    total_targets: int = 0
    successful: int = 0
    failed: int = 0
    results: list[RolloutResult] = field(default_factory=list)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    is_destructive: bool = False  # True if this is a delete cascade

    @property
    def all_succeeded(self) -> bool:
        return self.failed == 0 and self.successful == self.total_targets


class ForcedRolloutExecutor:
    """Executes forced rollout of enterprise artifacts to downstream collections.

    The executor iterates over all downstream targets and applies a fast-forward
    overwrite. Each application is logged as an Administrative Override.
    """

    def __init__(
        self,
        history_writer: Optional[ArtifactHistoryWriter] = None,
    ) -> None:
        self._history_writer = history_writer

    def execute(
        self,
        artifact_id: str,
        tenant_id: str,
        admin_id: str,
        targets: List[RolloutTarget],
        apply_fn: Optional[Callable[[str, RolloutTarget], bool]] = None,
        is_destructive: bool = False,
    ) -> ForcedRolloutSummary:
        """Execute forced rollout to all downstream targets.

        Args:
            artifact_id: The enterprise artifact ID being rolled out
            tenant_id: Enterprise tenant ID
            admin_id: The system_admin who triggered the rollout
            targets: List of downstream collections to update
            apply_fn: Function that applies the artifact to a target.
                     Signature: (artifact_id, target) -> bool (success).
                     If None, simulates success (for testing).
            is_destructive: If True, this is a delete cascade (logs warning)

        Returns:
            ForcedRolloutSummary with results for each target
        """
        summary = ForcedRolloutSummary(
            artifact_id=artifact_id,
            tenant_id=tenant_id,
            admin_id=admin_id,
            total_targets=len(targets),
            started_at=datetime.now(timezone.utc),
            is_destructive=is_destructive,
        )

        if is_destructive:
            logger.warning(
                "WARNING: Destructive Sync — enterprise artifact deletion cascade",
                extra={
                    "artifact_id": artifact_id,
                    "tenant_id": tenant_id,
                    "admin_id": admin_id,
                    "target_count": len(targets),
                },
            )

        for target in targets:
            result = self._apply_to_target(
                artifact_id=artifact_id,
                admin_id=admin_id,
                target=target,
                apply_fn=apply_fn,
                is_destructive=is_destructive,
            )
            summary.results.append(result)
            if result.success:
                summary.successful += 1
            else:
                summary.failed += 1

        summary.completed_at = datetime.now(timezone.utc)

        logger.info(
            "Forced rollout complete",
            extra={
                "artifact_id": artifact_id,
                "total": summary.total_targets,
                "successful": summary.successful,
                "failed": summary.failed,
            },
        )

        return summary

    def _apply_to_target(
        self,
        artifact_id: str,
        admin_id: str,
        target: RolloutTarget,
        apply_fn: Optional[Callable] = None,
        is_destructive: bool = False,
    ) -> RolloutResult:
        """Apply the enterprise artifact to a single downstream target."""
        try:
            if apply_fn is not None:
                success = apply_fn(artifact_id, target)
            else:
                # Simulate success when no apply_fn provided
                success = True

            if success:
                self._log_administrative_override(
                    artifact_id=artifact_id,
                    admin_id=admin_id,
                    target=target,
                    is_destructive=is_destructive,
                )

            return RolloutResult(
                target=target,
                success=success,
                applied_at=datetime.now(timezone.utc) if success else None,
            )

        except Exception as e:
            logger.error(
                "Failed to apply forced rollout to target",
                extra={
                    "artifact_id": artifact_id,
                    "target_owner_id": target.owner_id,
                    "error": str(e),
                },
            )
            return RolloutResult(
                target=target,
                success=False,
                error=str(e),
            )

    def _log_administrative_override(
        self,
        artifact_id: str,
        admin_id: str,
        target: RolloutTarget,
        is_destructive: bool = False,
    ) -> None:
        """Log the administrative override in artifact history."""
        action = (
            "Administrative Override: Destructive Sync"
            if is_destructive
            else "Administrative Override"
        )

        details = {
            "admin_id": admin_id,
            "target_owner_id": target.owner_id,
            "target_owner_type": target.owner_type,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "is_destructive": is_destructive,
        }

        if self._history_writer is not None:
            try:
                self._history_writer.write_history_entry(
                    artifact_id=artifact_id,
                    action=action,
                    actor_id=admin_id,
                    details=details,
                )
            except Exception as e:
                logger.error(
                    "Failed to write history entry for administrative override",
                    extra={"artifact_id": artifact_id, "error": str(e)},
                )

        logger.info(
            action,
            extra=details,
        )
