"""Cross-Tier Diff Service for DVCS Phase 3.

Generates unified diffs and 3-way merge previews between artifacts at
different tiers in the collection hierarchy.

Uses Python's standard ``difflib`` library — no external dependencies.
"""

from __future__ import annotations

import difflib
import hashlib
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from sqlalchemy.orm import Session

from skillmeat.cache.models import Artifact, ArtifactVersion

__all__ = [
    "CrossTierDiff",
    "ThreeWayPreview",
    "CrossTierDiffService",
]

logger = logging.getLogger(__name__)


# -------------------------------------------------------------------------
# Dataclasses
# -------------------------------------------------------------------------


@dataclass
class CrossTierDiff:
    """Result of a two-way cross-tier diff.

    Attributes:
        source_id: ``artifacts.id`` of the source (higher-tier) artifact.
        source_tier: ``collection_tier`` of the source artifact.
        source_version: ``upstream_version`` of the source artifact.
        target_id: ``artifacts.id`` of the target (lower-tier) artifact.
        target_tier: ``collection_tier`` of the target artifact.
        target_version: ``deployed_version`` of the target artifact.
        unified_diff: Standard unified diff string (empty when identical).
        has_changes: ``True`` when the content differs.
        content_hash_match: ``True`` when both artifacts share the same
            ``content_hash`` value.
    """

    source_id: str
    source_tier: Optional[str]
    source_version: Optional[str]
    target_id: str
    target_tier: Optional[str]
    target_version: Optional[str]
    unified_diff: str
    has_changes: bool
    content_hash_match: bool


@dataclass
class ThreeWayPreview:
    """Result of a 3-way merge preview.

    Attributes:
        base_content: Content of the common ancestor version.  ``None`` when
            no base is available (treated as empty).
        upstream_content: Current content of the upstream (higher-tier) artifact.
        local_content: Current content of the local (lower-tier) artifact.
        has_conflicts: ``True`` when conflict markers were detected.
        conflict_regions: List of dicts with ``start``, ``end``, and ``type``
            keys describing each conflict region in the merged output.
        auto_mergeable: ``True`` when there are no conflicts.
    """

    base_content: Optional[str]
    upstream_content: Optional[str]
    local_content: Optional[str]
    has_conflicts: bool
    conflict_regions: List[Dict] = field(default_factory=list)
    auto_mergeable: bool = True


# -------------------------------------------------------------------------
# CrossTierDiffService
# -------------------------------------------------------------------------


class CrossTierDiffService:
    """Generates diffs between artifacts at different collection tiers.

    Uses SQLAlchemy 1.x ``session.query()`` style per local-edition
    conventions.

    Args:
        session: An active SQLAlchemy ``Session``.

    Example:
        >>> svc = CrossTierDiffService(session)
        >>> diff = svc.diff_across_tiers("ent:canvas", "dev:canvas")
        >>> print(diff.unified_diff)
    """

    def __init__(self, session: Session) -> None:
        self.session = session

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def diff_across_tiers(
        self,
        source_artifact_id: str,
        target_artifact_id: str,
    ) -> CrossTierDiff:
        """Compare two artifacts from (potentially) different tiers.

        Content is read from ``Artifact.content`` when present.  When
        ``content`` is ``None``, an empty string is used as a fallback so
        diffs always succeed.

        Args:
            source_artifact_id: ``artifacts.id`` of the reference artifact
                (typically the higher-tier / upstream one).
            target_artifact_id: ``artifacts.id`` of the artifact to compare
                against the source.

        Returns:
            :class:`CrossTierDiff` with unified diff and metadata.

        Raises:
            ValueError: When either artifact is not found.
        """
        source = self._get_artifact(source_artifact_id)
        target = self._get_artifact(target_artifact_id)

        source_content = source.content or ""
        target_content = target.content or ""

        # Content-hash comparison (fast path).
        source_hash = source.content_hash or _sha256(source_content)
        target_hash = target.content_hash or _sha256(target_content)
        content_hash_match = source_hash == target_hash

        unified_diff = ""
        if not content_hash_match:
            unified_diff = _compute_unified_diff(
                a=source_content,
                b=target_content,
                fromfile=f"{source.collection_tier or 'source'}:{source.name}",
                tofile=f"{target.collection_tier or 'target'}:{target.name}",
            )

        return CrossTierDiff(
            source_id=source_artifact_id,
            source_tier=source.collection_tier,
            source_version=source.upstream_version,
            target_id=target_artifact_id,
            target_tier=target.collection_tier,
            target_version=target.deployed_version,
            unified_diff=unified_diff,
            has_changes=not content_hash_match,
            content_hash_match=content_hash_match,
        )

    def three_way_merge_preview(
        self,
        upstream_artifact_id: str,
        local_artifact_id: str,
        base_version: Optional[str] = None,
    ) -> ThreeWayPreview:
        """Generate a 3-way merge preview between upstream and local artifacts.

        The merge is computed as follows:

        1. **Base**: The content from the most recent :class:`ArtifactVersion`
           whose ``content_hash`` matches *base_version* (if provided).  Falls
           back to the oldest known version payload of the local artifact when
           *base_version* is ``None`` or not found.  When no version history
           is available, the base is treated as empty (``""``) to represent a
           "new file from upstream" scenario.

        2. **Upstream**: ``Artifact.content`` of *upstream_artifact_id*.

        3. **Local**: ``Artifact.content`` of *local_artifact_id*.

        Conflict detection uses a simple line-by-line 3-way merge algorithm:
        a line is a *conflict* when it was changed in both upstream and local
        relative to the base.

        Args:
            upstream_artifact_id: ``artifacts.id`` of the upstream (higher-tier)
                artifact.
            local_artifact_id: ``artifacts.id`` of the local (lower-tier)
                artifact.
            base_version: Optional content hash string to identify the common
                ancestor version.  When ``None``, the oldest available version
                payload of the local artifact is used as the base.

        Returns:
            :class:`ThreeWayPreview` with content, conflict flags, and region
            list.

        Raises:
            ValueError: When either artifact is not found.
        """
        upstream = self._get_artifact(upstream_artifact_id)
        local = self._get_artifact(local_artifact_id)

        upstream_content = upstream.content or ""
        local_content = local.content or ""
        base_content = self._resolve_base(local, base_version)

        conflict_regions, auto_mergeable = _three_way_merge(
            base=base_content,
            upstream=upstream_content,
            local=local_content,
        )

        return ThreeWayPreview(
            base_content=base_content if base_content else None,
            upstream_content=upstream_content if upstream_content else None,
            local_content=local_content if local_content else None,
            has_conflicts=not auto_mergeable,
            conflict_regions=conflict_regions,
            auto_mergeable=auto_mergeable,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_artifact(self, artifact_id: str) -> Artifact:
        """Load an :class:`Artifact` by primary key or raise :exc:`ValueError`."""
        artifact = (
            self.session.query(Artifact).filter(Artifact.id == artifact_id).first()
        )
        if artifact is None:
            raise ValueError(f"Artifact not found: {artifact_id!r}")
        return artifact

    def _resolve_base(self, artifact: Artifact, base_version: Optional[str]) -> str:
        """Resolve the base content for a 3-way merge.

        Args:
            artifact: The local artifact whose version history to inspect.
            base_version: Optional content hash identifying the base version.

        Returns:
            Base content string, or ``""`` when no base can be found.
        """
        versions: List[ArtifactVersion] = artifact.versions or []

        if base_version:
            for v in versions:
                if v.content_hash == base_version and v.content_payload:
                    return v.content_payload

        # Fallback: oldest version with a content_payload.
        with_payload = [v for v in versions if v.content_payload]
        if with_payload:
            # versions are ordered desc by created_at (per model relationship)
            oldest = with_payload[-1]
            return oldest.content_payload  # type: ignore[return-value]

        return ""


# -------------------------------------------------------------------------
# Pure diff / merge helpers (no DB access)
# -------------------------------------------------------------------------


def _sha256(text: str) -> str:
    """Return the SHA-256 hex digest of *text*."""
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def _compute_unified_diff(
    a: str,
    b: str,
    fromfile: str = "source",
    tofile: str = "target",
    context_lines: int = 3,
) -> str:
    """Compute a unified diff between strings *a* and *b*.

    Args:
        a: The "from" content (source / upstream).
        b: The "to" content (target / local).
        fromfile: Label for the left-hand side of the diff.
        tofile: Label for the right-hand side of the diff.
        context_lines: Number of surrounding context lines to include.

    Returns:
        Unified diff string.  Empty string when *a* == *b*.
    """
    a_lines = a.splitlines(keepends=True)
    b_lines = b.splitlines(keepends=True)

    diff_lines = list(
        difflib.unified_diff(
            a_lines,
            b_lines,
            fromfile=fromfile,
            tofile=tofile,
            n=context_lines,
        )
    )
    return "".join(diff_lines)


def _three_way_merge(
    base: str,
    upstream: str,
    local: str,
) -> tuple[List[Dict], bool]:
    """Perform a simple line-level 3-way merge analysis.

    Detects lines that were changed in *both* upstream and local relative
    to *base* — these are conflicts.  Purely additive or single-side changes
    are considered auto-mergeable.

    Args:
        base: Common ancestor content.
        upstream: Higher-tier (upstream) current content.
        local: Lower-tier (local) current content.

    Returns:
        A tuple of ``(conflict_regions, auto_mergeable)`` where:
        - ``conflict_regions`` is a list of dicts with keys ``start``,
          ``end``, ``upstream_lines``, and ``local_lines``.
        - ``auto_mergeable`` is ``True`` when the list is empty.
    """
    base_lines = base.splitlines()
    upstream_lines = upstream.splitlines()
    local_lines = local.splitlines()

    # Compute the set of line numbers changed vs base for each side.
    upstream_changed = _changed_line_indices(base_lines, upstream_lines)
    local_changed = _changed_line_indices(base_lines, local_lines)

    conflict_indices = upstream_changed & local_changed

    if not conflict_indices:
        return [], True

    # Group consecutive conflict indices into regions.
    regions: List[Dict] = _group_conflict_regions(
        sorted(conflict_indices),
        upstream_lines,
        local_lines,
    )

    return regions, False


def _changed_line_indices(base: List[str], changed: List[str]) -> set:
    """Return the set of 0-based line indices that differ between *base* and *changed*.

    Uses :class:`difflib.SequenceMatcher` to identify replaced/deleted blocks.
    Inserted lines in *changed* are represented by the index of the insertion
    point in *base*.

    Args:
        base: Original lines.
        changed: Modified lines.

    Returns:
        Set of integer indices (relative to *base*) that were modified.
    """
    matcher = difflib.SequenceMatcher(None, base, changed, autojunk=False)
    changed_set: set = set()
    for tag, i1, i2, _j1, _j2 in matcher.get_opcodes():
        if tag != "equal":
            for i in range(i1, max(i2, i1 + 1)):
                changed_set.add(i)
    return changed_set


def _group_conflict_regions(
    indices: List[int],
    upstream_lines: List[str],
    local_lines: List[str],
) -> List[Dict]:
    """Group a sorted list of conflict line indices into contiguous regions.

    Args:
        indices: Sorted list of conflicting base-line indices.
        upstream_lines: Lines from the upstream artifact.
        local_lines: Lines from the local artifact.

    Returns:
        List of conflict region dicts.
    """
    if not indices:
        return []

    regions: List[Dict] = []
    start = indices[0]
    end = indices[0]

    for idx in indices[1:]:
        if idx == end + 1:
            end = idx
        else:
            regions.append(_make_region(start, end, upstream_lines, local_lines))
            start = idx
            end = idx

    regions.append(_make_region(start, end, upstream_lines, local_lines))
    return regions


def _make_region(
    start: int,
    end: int,
    upstream_lines: List[str],
    local_lines: List[str],
) -> Dict:
    """Build a conflict region dict for the given base-line range.

    Args:
        start: First conflicting base-line index (inclusive).
        end: Last conflicting base-line index (inclusive).
        upstream_lines: All upstream content lines.
        local_lines: All local content lines.

    Returns:
        Dict with ``start``, ``end``, ``upstream_lines``, and ``local_lines``.
    """
    # Clamp slice bounds to actual line counts.
    u_start = min(start, len(upstream_lines))
    u_end = min(end + 1, len(upstream_lines))
    l_start = min(start, len(local_lines))
    l_end = min(end + 1, len(local_lines))

    return {
        "start": start,
        "end": end,
        "upstream_lines": upstream_lines[u_start:u_end],
        "local_lines": local_lines[l_start:l_end],
    }
