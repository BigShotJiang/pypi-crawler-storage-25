"""Filesystem watcher for real-time artifact change detection.

Wraps the optional ``watchdog`` library to monitor ``.claude/`` directories
inside project paths.  When a file is created or modified, a content hash is
computed and a :class:`ChangeEvent` is emitted via a caller-supplied callback.

The module degrades gracefully when ``watchdog`` is not installed: the guard
block at module level sets :data:`HAS_WATCHDOG` to ``False`` and
:class:`FSWatcher` will raise :class:`RuntimeError` on :meth:`FSWatcher.start`
instead of crashing at import time.

Install the optional dependency::

    pip install "skillmeat[watch]"
    # or
    uv add watchdog

Typical usage::

    from skillmeat.core.fs_watcher import FSWatcher, ChangeEvent

    def handle_change(event: ChangeEvent) -> None:
        print(f"Changed: {event.path} ({event.event_type}) hash={event.content_hash[:8]}")

    watcher = FSWatcher(
        project_paths=[Path("/home/user/my-project")],
        on_change=handle_change,
    )
    watcher.start()
    # ... later ...
    watcher.stop()
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, List, Optional, Sequence

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional watchdog import guard
# ---------------------------------------------------------------------------

try:
    from watchdog.events import (
        FileSystemEventHandler,
    )
    from watchdog.observers import Observer

    HAS_WATCHDOG = True
except ImportError:  # pragma: no cover
    HAS_WATCHDOG = False
    Observer = None  # type: ignore[assignment,misc]
    FileSystemEventHandler = object  # type: ignore[assignment,misc]

# ---------------------------------------------------------------------------
# Re-use exclusion constants from hashing.py
# ---------------------------------------------------------------------------

from skillmeat.core.hashing import (  # noqa: E402
    _hash_file_content,
    _is_excluded,
)

# ---------------------------------------------------------------------------
# Public data types
# ---------------------------------------------------------------------------


@dataclass
class ChangeEvent:
    """Represents a detected filesystem change for a single file.

    Attributes:
        path: Absolute path to the changed file.
        content_hash: SHA-256 hex digest of the file's current content at the
            moment the event was handled.  Empty string if the file could not
            be read (e.g. already deleted by the time the handler ran).
        event_type: One of ``"created"`` or ``"modified"``.
        timestamp: UTC datetime when the event was processed.
    """

    path: Path
    content_hash: str
    event_type: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=timezone.utc))


# ---------------------------------------------------------------------------
# Watchdog event handler
# ---------------------------------------------------------------------------

# Subdirectory name that limits watching to artifact directories.
_ARTIFACT_SUBDIR = ".claude"


class FileChangeHandler(FileSystemEventHandler):  # type: ignore[misc]
    """Watchdog event handler that filters and hashes file change events.

    Only files inside a ``.claude/`` directory subtree are processed.
    Files and directories matching the exclusion rules from
    :mod:`skillmeat.core.hashing` are silently ignored.

    Args:
        on_change: Callback invoked with a :class:`ChangeEvent` for each
            qualifying change.  The callback is called from the watchdog
            observer thread — it must be thread-safe.
        watch_root: The root path being observed (used for log messages only).
    """

    def __init__(
        self,
        on_change: Callable[[ChangeEvent], None],
        watch_root: Path,
    ) -> None:
        super().__init__()
        self._on_change = on_change
        self._watch_root = watch_root

    # ------------------------------------------------------------------
    # watchdog interface
    # ------------------------------------------------------------------

    def on_modified(self, event) -> None:  # type: ignore[override]
        if not event.is_directory:
            self._handle(event.src_path, "modified")

    def on_created(self, event) -> None:  # type: ignore[override]
        if not event.is_directory:
            self._handle(event.src_path, "created")

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _handle(self, src_path: str, event_type: str) -> None:
        """Validate, hash, and forward a raw watchdog file event."""
        path = Path(src_path)

        if not self._is_in_artifact_dir(path):
            return

        if self._is_excluded_path(path):
            return

        content_hash = self._compute_hash(path)
        if content_hash is None:
            # File disappeared or unreadable — skip silently.
            return

        change_event = ChangeEvent(
            path=path,
            content_hash=content_hash,
            event_type=event_type,
        )

        logger.debug(
            "FileChangeHandler: %s %s hash=%s",
            event_type,
            path,
            content_hash[:8],
        )

        try:
            self._on_change(change_event)
        except Exception:
            logger.warning(
                "FileChangeHandler: on_change callback raised for path=%s",
                path,
                exc_info=True,
            )

    def _is_in_artifact_dir(self, path: Path) -> bool:
        """Return True if *path* is inside a ``.claude/`` subtree."""
        return _ARTIFACT_SUBDIR in path.parts

    def _is_excluded_path(self, path: Path) -> bool:
        """Return True if any part of *path* matches the exclusion rules."""
        for part in path.parts:
            if _is_excluded(part):
                return True
        return False

    def _compute_hash(self, path: Path) -> Optional[str]:
        """Return SHA-256 hex digest of *path*'s content, or None on error."""
        try:
            if not path.is_file():
                return None
            return _hash_file_content(path)
        except (OSError, PermissionError):
            logger.debug("FileChangeHandler: could not read %s for hashing", path)
            return None


# ---------------------------------------------------------------------------
# FSWatcher
# ---------------------------------------------------------------------------


class FSWatcher:
    """Manages watchdog ``Observer`` instances for a set of project paths.

    Watches the ``.claude/`` subdirectory of each project path.  File
    create/modify events are filtered by :class:`FileChangeHandler` and
    forwarded to the supplied callback.

    Args:
        project_paths: Sequence of project root directories to watch.  For
            each path, ``<project_path>/.claude/`` is scheduled as a
            recursive watch.  Paths that do not have a ``.claude/``
            subdirectory are skipped with a debug log.
        on_change: Callback invoked for every qualifying change event.
            Called from the observer background thread — must be thread-safe.
        settings: Optional settings object.  Not currently used directly, but
            accepted for forward-compatibility with callers that pass settings.

    Raises:
        RuntimeError: On :meth:`start` when ``watchdog`` is not installed.

    Example::

        watcher = FSWatcher(
            project_paths=[Path("/home/user/project")],
            on_change=my_callback,
        )
        watcher.start()
        # ... work ...
        watcher.stop()
    """

    def __init__(
        self,
        project_paths: Sequence[Path],
        on_change: Callable[[ChangeEvent], None],
        settings=None,
    ) -> None:
        self._project_paths: List[Path] = list(project_paths)
        self._on_change = on_change
        self._settings = settings

        self._observer: Optional[object] = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    @property
    def is_running(self) -> bool:
        """True when the underlying watchdog ``Observer`` is alive."""
        with self._lock:
            return (
                self._observer is not None
                and getattr(self._observer, "is_alive", lambda: False)()
            )

    def start(self) -> None:
        """Start the filesystem observer.

        Schedules a recursive watch for the ``.claude/`` subdirectory of each
        configured project path and starts the observer thread.

        Raises:
            RuntimeError: If ``watchdog`` is not installed.
            RuntimeError: If the watcher is already running.
        """
        if not HAS_WATCHDOG:
            raise RuntimeError(
                "watchdog is not installed.  Install it with: "
                "pip install 'skillmeat[watch]'  or  pip install watchdog>=3.0.0"
            )

        with self._lock:
            if (
                self._observer is not None
                and getattr(self._observer, "is_alive", lambda: False)()
            ):
                raise RuntimeError("FSWatcher is already running")

            observer = Observer()  # type: ignore[operator]

            scheduled_count = 0
            for project_path in self._project_paths:
                watch_dir = project_path / _ARTIFACT_SUBDIR
                if not watch_dir.is_dir():
                    logger.debug(
                        "FSWatcher: skipping %s — .claude/ not found", project_path
                    )
                    continue

                handler = FileChangeHandler(
                    on_change=self._on_change,
                    watch_root=project_path,
                )
                observer.schedule(handler, str(watch_dir), recursive=True)
                scheduled_count += 1
                logger.debug("FSWatcher: watching %s", watch_dir)

            if scheduled_count == 0:
                logger.warning(
                    "FSWatcher: no .claude/ directories found in project paths; "
                    "observer started but will not emit events"
                )

            observer.start()
            self._observer = observer

        logger.info(
            "FSWatcher: started — watching %d .claude/ director%s",
            scheduled_count,
            "y" if scheduled_count == 1 else "ies",
        )

    def stop(self) -> None:
        """Stop the filesystem observer and wait for it to finish.

        Safe to call even when the watcher is not running.  Blocks until the
        observer thread has fully exited.
        """
        with self._lock:
            observer = self._observer
            self._observer = None

        if observer is None:
            return

        try:
            observer.stop()  # type: ignore[union-attr]
        except Exception:
            logger.warning("FSWatcher: error stopping observer", exc_info=True)

        try:
            observer.join()  # type: ignore[union-attr]
        except Exception:
            logger.warning("FSWatcher: error joining observer thread", exc_info=True)

        logger.info("FSWatcher: stopped")
