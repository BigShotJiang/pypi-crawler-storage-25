"""Tests for verify_url, verify_file, and extract_text."""

from __future__ import annotations

import base64
import json
from pathlib import Path

import httpx
import pytest

from factivelabs import ExtractedText, FactiveClient
from factivelabs._extraction import (
    build_file_body,
    build_url_body,
    detect_file_content_type,
    detect_url_content_type,
)


# ── Pure helpers ─────────────────────────────────────────────────────────────


def test_detect_url_content_type_youtube():
    assert detect_url_content_type("https://www.youtube.com/watch?v=abc") == "youtube"
    assert detect_url_content_type("https://youtu.be/xyz") == "youtube"


def test_detect_url_content_type_tiktok():
    assert detect_url_content_type("https://www.tiktok.com/@user/video/12345") == "tiktok"


def test_detect_url_content_type_default_url():
    assert detect_url_content_type("https://example.com/article") == "url"
    assert detect_url_content_type("https://nytimes.com/2026/01/01/abc") == "url"


def test_detect_file_content_type_known_extensions():
    assert detect_file_content_type("paper.pdf") == "pdf"
    assert detect_file_content_type("Doc.DOCX") == "docx"
    assert detect_file_content_type("/tmp/photo.JPEG") == "image"


def test_detect_file_content_type_unknown_extension_raises():
    with pytest.raises(ValueError, match="auto-detect"):
        detect_file_content_type("data.xyz")


def test_build_url_body_passes_content_type_through():
    assert build_url_body("https://x", content_type="url") == {
        "url": "https://x",
        "content_type": "url",
    }


def test_build_url_body_rejects_invalid_content_type():
    with pytest.raises(ValueError, match="content_type for a URL"):
        build_url_body("https://x", content_type="pdf")


def test_build_file_body_from_bytes_with_filename(tmp_path):
    raw = b"%PDF-1.4 fake pdf bytes"
    body = build_file_body(raw, filename="ignored_for_path.pdf")
    assert body["content_type"] == "pdf"
    assert base64.b64decode(body["file"]) == raw


def test_build_file_body_from_path(tmp_path):
    p = tmp_path / "doc.docx"
    p.write_bytes(b"PK\x03\x04 fake docx zip header")
    body = build_file_body(p)
    assert body["content_type"] == "docx"
    assert base64.b64decode(body["file"]).startswith(b"PK")


def test_build_file_body_bytes_without_filename_or_content_type_raises():
    with pytest.raises(ValueError, match="content_type"):
        build_file_body(b"\x00\x01")


def test_build_file_body_missing_path_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        build_file_body(tmp_path / "does-not-exist.pdf")


# ── End-to-end via mock transport ────────────────────────────────────────────


def _mock_handler(extract_response: dict, verify_response: dict, captured: dict):
    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        body = json.loads(request.content) if request.content else {}
        captured.setdefault(path, []).append(body)
        if path == "/api/v1/extract-text":
            return httpx.Response(200, json=extract_response)
        if path == "/api/v1/verify":
            return httpx.Response(200, json=verify_response)
        return httpx.Response(404, text=f"unexpected path {path}")

    return handler


def _client(handler) -> FactiveClient:
    return FactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )


def test_verify_url_calls_both_endpoints():
    captured: dict = {}
    extract_response = {
        "id": "et_123",
        "status": "complete",
        "input_type": "url",
        "text": "Article body text.",
        "title": "Article Title",
        "char_count": 18,
        "processing_time_ms": 50,
    }
    verify_response = {
        "claims": [{"text": "X is Y.", "verdict": "confirmed", "summary": "Yes."}],
        "title": "",
        "counts": {"confirmed": 1},
    }
    handler = _mock_handler(extract_response, verify_response, captured)
    client = _client(handler)

    result = client.verify_url("https://example.com/article", context="user q")

    # Both endpoints called, in the right order, with the right shapes:
    assert "/api/v1/extract-text" in captured
    assert "/api/v1/verify" in captured
    assert captured["/api/v1/extract-text"][0]["url"] == "https://example.com/article"
    assert captured["/api/v1/extract-text"][0]["content_type"] == "url"
    assert captured["/api/v1/verify"][0]["text"] == "Article body text."
    assert captured["/api/v1/verify"][0]["context"] == "user q"

    # Result merges title and extracted text:
    assert result.extracted_text == "Article body text."
    assert result.title == "Article Title"
    assert len(result.claims) == 1
    assert result.confirmed[0].text == "X is Y."


def test_verify_url_youtube_auto_detected():
    captured: dict = {}
    handler = _mock_handler(
        {"text": "Video transcript.", "title": "Video", "char_count": 17, "input_type": "youtube", "id": "et_yt"},
        {"claims": [], "counts": {}},
        captured,
    )
    client = _client(handler)
    client.verify_url("https://www.youtube.com/watch?v=abc")
    assert captured["/api/v1/extract-text"][0]["content_type"] == "youtube"


def test_verify_file_from_path(tmp_path):
    captured: dict = {}
    fake_pdf = tmp_path / "report.pdf"
    fake_pdf.write_bytes(b"%PDF-1.4 hello world")
    handler = _mock_handler(
        {"text": "PDF body.", "title": "Report", "char_count": 9, "input_type": "pdf", "id": "et_pdf"},
        {"claims": [], "counts": {}},
        captured,
    )
    client = _client(handler)
    result = client.verify_file(fake_pdf)

    assert captured["/api/v1/extract-text"][0]["content_type"] == "pdf"
    assert base64.b64decode(captured["/api/v1/extract-text"][0]["file"]).startswith(b"%PDF")
    assert result.title == "Report"
    assert result.extracted_text == "PDF body."


def test_verify_file_from_bytes_with_filename():
    captured: dict = {}
    handler = _mock_handler(
        {"text": "DOCX body.", "title": "", "char_count": 10, "input_type": "docx", "id": "et_docx"},
        {"claims": [], "counts": {}},
        captured,
    )
    client = _client(handler)
    raw = b"PK\x03\x04 fake docx zip"
    client.verify_file(raw, filename="something.docx")
    assert captured["/api/v1/extract-text"][0]["content_type"] == "docx"


def test_extract_text_only():
    captured: dict = {}
    handler = _mock_handler(
        {"text": "raw extracted text", "title": "T", "char_count": 18, "input_type": "url", "id": "et_only"},
        {"claims": [], "counts": {}},
        captured,
    )
    client = _client(handler)
    extracted = client.extract_text(url="https://example.com/x")
    assert isinstance(extracted, ExtractedText)
    assert extracted.text == "raw extracted text"
    # extract_text must NOT call /verify:
    assert "/api/v1/verify" not in captured


def test_extract_text_rejects_both_url_and_file(tmp_path):
    handler = _mock_handler({"text": ""}, {"claims": []}, {})
    client = _client(handler)
    p = tmp_path / "x.pdf"
    p.write_bytes(b"%PDF")
    with pytest.raises(ValueError):
        client.extract_text(url="https://x", file=p)


def test_extract_text_rejects_neither_url_nor_file():
    handler = _mock_handler({"text": ""}, {"claims": []}, {})
    client = _client(handler)
    with pytest.raises(ValueError):
        client.extract_text()
