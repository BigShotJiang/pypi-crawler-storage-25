"""Tests for the v0.2 ergonomic additions:

* ``client.verify_stream_events(...)`` — iterator API on top of the
  callback-based streaming flow (sync and async).
* ``with FactiveClient(...) as c:`` — context-manager support that
  reuses one ``httpx.Client`` across method calls.

Updated in v0.3.0 to use the new stateless ``/verify/paragraph`` endpoint.
"""

from __future__ import annotations

import json

import httpx
import pytest

from factivelabs import (
    AsyncFactiveClient,
    FactiveClient,
    StreamEvent,
    StreamResult,
)


# ── Shared mock helper ──────────────────────────────────────────────────────


def _make_paragraph_handler(paragraph_responses=None, capture=None):
    """Mock /api/v1/verify/paragraph. Returns deterministic claims by default."""
    capture = capture if capture is not None else []
    paragraph_responses = list(paragraph_responses or [])
    response_iter = iter(paragraph_responses)

    def handler(request: httpx.Request) -> httpx.Response:
        if (
            request.url.path == "/api/v1/verify/paragraph"
            and request.method == "POST"
        ):
            try:
                body = json.loads(request.content)
            except Exception:
                body = {}
            capture.append(body)
            try:
                return next(response_iter)
            except StopIteration:
                text = body.get("text") or ""
                sentences = [s.strip() for s in text.split(".") if s.strip()]
                claims = [
                    {"text": s + ".", "verdict": "confirmed", "summary": "ok"}
                    for s in sentences[:5]
                ]
                return httpx.Response(
                    200,
                    json={
                        "paragraph_id": f"pg_{len(capture):08x}",
                        "chars_received": len(text),
                        "claims": claims,
                        "counts": {
                            "confirmed": len(claims),
                            "disputed": 0,
                            "inconclusive": 0,
                            "subjective": 0,
                            "skipped": 0,
                        },
                        "processing_time_ms": 5,
                    },
                )
        return httpx.Response(404)

    return handler, capture


# ── verify_stream_events (sync) ─────────────────────────────────────────────


def test_events_iterator_yields_typed_events():
    handler, _ = _make_paragraph_handler()
    client = FactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )

    events: list[StreamEvent] = []
    for ev in client.verify_stream_events(["First paragraph.", "\n\n"]):
        events.append(ev)

    types = [e.type for e in events]
    # We must see at least one token, the claim, and the final done event:
    assert "token" in types
    assert "claim" in types
    assert types[-1] == "done"

    claim_event = next(e for e in events if e.type == "claim")
    assert claim_event.claim is not None
    assert claim_event.claim.verdict == "confirmed"
    done_event = events[-1]
    assert isinstance(done_event.result, StreamResult)
    assert done_event.result.byte_equality is True


def test_events_iterator_propagates_exceptions():
    """A 4xx on a paragraph POST should surface as an exception in the iterator."""
    handler, _ = _make_paragraph_handler(
        paragraph_responses=[httpx.Response(400, text="bad chunk")]
    )
    client = FactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
    )

    from factivelabs.exceptions import ParagraphRejectedError

    with pytest.raises(ParagraphRejectedError):
        list(client.verify_stream_events(["x", "\n\n"]))


# ── verify_stream_events (async) ────────────────────────────────────────────


@pytest.mark.asyncio
async def test_async_events_iterator_yields_typed_events():
    handler, _ = _make_paragraph_handler()
    client = AsyncFactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )

    events: list[StreamEvent] = []
    async for ev in client.verify_stream_events(["First paragraph.", "\n\n"]):
        events.append(ev)

    types = [e.type for e in events]
    assert "token" in types
    assert "claim" in types
    assert types[-1] == "done"


# ── Context manager (sync) ──────────────────────────────────────────────────


def test_with_factive_client_reuses_one_underlying_client():
    """All method calls inside `with ...` block should reuse the same httpx.Client."""

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"claims": [], "counts": {}})

    transport = httpx.MockTransport(handler)
    with FactiveClient(api_key="fk_test", base_url="https://x", transport=transport) as c:
        first_shared = c._shared_client
        assert first_shared is not None

        c.verify_text("doc 1")
        c.verify_text("doc 2")
        c.verify_text("doc 3")

        # The shared client must not be replaced between calls:
        assert c._shared_client is first_shared

    # After exiting the with-block, the shared client is closed:
    assert c._shared_client is None


def test_methods_outside_with_block_still_work():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"claims": [], "counts": {}})

    client = FactiveClient(
        api_key="fk_test",
        base_url="https://x",
        transport=httpx.MockTransport(handler),
    )
    assert client._shared_client is None
    client.verify_text("doc")
    assert client._shared_client is None  # not promoted to shared


def test_close_idempotent():
    client = FactiveClient(api_key="fk_test", base_url="https://x")
    client.close()  # no-op
    client.close()  # still no-op


# ── Context manager (async) ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_async_with_reuses_one_underlying_client():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"claims": [], "counts": {}})

    transport = httpx.MockTransport(handler)
    async with AsyncFactiveClient(
        api_key="fk_test", base_url="https://x", transport=transport
    ) as c:
        first_shared = c._shared_client
        assert first_shared is not None
        await c.verify_text("doc 1")
        await c.verify_text("doc 2")
        assert c._shared_client is first_shared
    assert c._shared_client is None


@pytest.mark.asyncio
async def test_async_methods_outside_with_still_work():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"claims": [], "counts": {}})

    client = AsyncFactiveClient(
        api_key="fk_test",
        base_url="https://x",
        transport=httpx.MockTransport(handler),
    )
    assert client._shared_client is None
    await client.verify_text("doc")
    assert client._shared_client is None
