"""Async-client smoke tests for batch + corpus.

Sync tests already cover body construction, normalization, and HTTP-error
paths. These tests only confirm the async client correctly hits the same
endpoints and round-trips the same payload shapes.
"""

from __future__ import annotations

import httpx
import pytest

from factivelabs import AsyncFactiveClient, BatchSubmission, CorpusDocument, JobStatus


pytestmark = pytest.mark.asyncio


def _client(handler) -> AsyncFactiveClient:
    return AsyncFactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )


# ── Batch ────────────────────────────────────────────────────────────────────


async def test_async_submit_batch():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            202,
            json={
                "batch_id": "batch_async",
                "total": 1,
                "jobs": [{"index": 0, "job_id": "fc_a", "status": "queued"}],
            },
        )

    sub = await _client(handler).submit_batch([{"text": "doc"}])
    assert isinstance(sub, BatchSubmission)
    assert sub.batch_id == "batch_async"


async def test_async_get_job():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "fc_a",
                "status": "complete",
                "progress": {},
                "result": {"claims": [], "counts": {}},
                "created_at": "",
                "completed_at": "now",
            },
        )

    status = await _client(handler).get_job("fc_a")
    assert isinstance(status, JobStatus)
    assert status.is_complete


async def test_async_wait_for_batch():
    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if path == "/api/v1/verify/batch":
            return httpx.Response(
                202,
                json={
                    "batch_id": "b",
                    "total": 1,
                    "jobs": [{"index": 0, "job_id": "fc_a", "status": "queued"}],
                },
            )
        return httpx.Response(
            200,
            json={
                "id": "fc_a",
                "status": "complete",
                "progress": {},
                "result": {"claims": [], "counts": {}},
                "created_at": "",
                "completed_at": "now",
            },
        )

    client = _client(handler)
    sub = await client.submit_batch([{"text": "doc"}])
    results = await client.wait_for_batch(sub, timeout=2, poll_interval=0.01)
    assert results["fc_a"].is_complete


# ── Corpus ───────────────────────────────────────────────────────────────────


async def test_async_corpus_list():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "docs": [
                    {"doc_id": "d1", "file_name": "x.pdf", "file_type": "pdf", "status": "ready"}
                ],
                "count": 1,
            },
        )

    docs = await _client(handler).corpus.list()
    assert len(docs) == 1
    assert isinstance(docs[0], CorpusDocument)


async def test_async_corpus_upload(tmp_path):
    p = tmp_path / "y.pdf"
    p.write_bytes(b"%PDF y")

    def handler(request: httpx.Request) -> httpx.Response:
        ct = request.headers.get("content-type", "")
        assert "multipart/form-data" in ct
        assert request.url.path == "/api/v1/private-corpus/upload"
        return httpx.Response(202, json={"queued": [{"file_name": "y.pdf"}], "failed": []})

    result = await _client(handler).corpus.upload([p])
    assert result["queued"][0]["file_name"] == "y.pdf"


async def test_async_corpus_clear_requires_confirm():
    handler = lambda r: httpx.Response(200, json={"deleted_count": 0})
    client = _client(handler)
    with pytest.raises(ValueError, match="confirm=True"):
        await client.corpus.clear()


async def test_async_corpus_scope_round_trip():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "scope_text": "Initial scope.",
                    "status": "idle",
                    "edited_by_user": False,
                },
            )
        if request.method == "PUT":
            return httpx.Response(
                200,
                json={
                    "scope_text": "Updated.",
                    "status": "idle",
                    "edited_by_user": True,
                },
            )
        return httpx.Response(404)

    client = _client(handler)
    initial = await client.corpus.get_scope()
    assert initial.scope_text == "Initial scope."
    updated = await client.corpus.update_scope("Updated.")
    assert updated.edited_by_user is True
