"""Tests for FactiveClient.verify_text — the one-shot fact-check call."""

from __future__ import annotations

import httpx
import pytest

from factivelabs import FactiveClient
from factivelabs.exceptions import (
    AuthenticationError,
    QuotaExceededError,
    RateLimitError,
)


def _client(handler) -> FactiveClient:
    return FactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )


def test_verify_text_happy_path():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["auth"] = request.headers.get("authorization")
        captured["user_agent"] = request.headers.get("user-agent", "")
        captured["body"] = request.content
        return httpx.Response(
            200,
            json={
                "claims": [
                    {"text": "X is true.", "verdict": "confirmed", "summary": "Yes."},
                    {"text": "Y is false.", "verdict": "disputed", "summary": "No."},
                ],
                "title": "Test doc",
                "counts": {"confirmed": 1, "disputed": 1},
            },
        )

    result = _client(handler).verify_text(
        "Some document.", context="Q: tell me", profile="production_athena"
    )

    assert captured["path"] == "/api/v1/verify"
    assert captured["auth"] == "Bearer fk_test"
    assert captured["user_agent"].startswith("factivelabs-python/")
    assert b"production_athena" in captured["body"]
    assert result.title == "Test doc"
    assert len(result.claims) == 2
    assert result.claims[0].verdict == "confirmed"


def test_verify_text_401():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"detail": "bad key"})

    with pytest.raises(AuthenticationError):
        _client(handler).verify_text("x")


def test_verify_text_402():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            402,
            json={"detail": {"message": "Free tier limit reached", "credits_quota": 500}},
        )

    with pytest.raises(QuotaExceededError) as exc_info:
        _client(handler).verify_text("x")
    assert "Free tier" in str(exc_info.value)


def test_verify_text_429():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(429, headers={"retry-after": "5"})

    with pytest.raises(RateLimitError) as exc_info:
        _client(handler).verify_text("x")
    assert exc_info.value.retry_after == 5.0


def test_constructor_rejects_empty_api_key():
    with pytest.raises(ValueError):
        FactiveClient(api_key="")


def test_corpus_options_serialized_correctly():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        import json as _json

        captured["body"] = _json.loads(request.content)
        return httpx.Response(200, json={"claims": []})

    _client(handler).verify_text(
        "doc", use_private_corpus=True, corpus_scope="Internal HR docs."
    )
    assert captured["body"]["use_private_corpus"] is True
    assert captured["body"]["corpus_scope"] == "Internal HR docs."
