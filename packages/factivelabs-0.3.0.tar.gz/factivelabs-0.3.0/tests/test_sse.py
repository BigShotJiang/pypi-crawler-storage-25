"""Tests for the SSE event parser."""

from __future__ import annotations

import httpx

from factivelabs._sse import parse_sse_events


def _response_with_body(body: str) -> httpx.Response:
    return httpx.Response(
        200,
        content=body.encode("utf-8"),
        headers={"content-type": "text/event-stream"},
    )


def test_single_event():
    body = 'event: hello\ndata: {"a": 1}\n\n'
    events = list(parse_sse_events(_response_with_body(body)))
    assert events == [("hello", {"a": 1})]


def test_multiple_events_with_default_event_name():
    body = 'data: {"first": true}\n\nevent: ping\ndata: {"second": true}\n\n'
    events = list(parse_sse_events(_response_with_body(body)))
    assert events == [("message", {"first": True}), ("ping", {"second": True})]


def test_comment_lines_are_skipped():
    body = ': keepalive\nevent: x\ndata: {"y": 2}\n\n'
    events = list(parse_sse_events(_response_with_body(body)))
    assert events == [("x", {"y": 2})]


def test_unparseable_data_is_returned_as_raw():
    body = "event: weird\ndata: not-json\n\n"
    events = list(parse_sse_events(_response_with_body(body)))
    assert events == [("weird", {"_raw": "not-json"})]


def test_multi_line_data_is_joined():
    body = 'event: x\ndata: {"a":\ndata: 1}\n\n'
    events = list(parse_sse_events(_response_with_body(body)))
    assert events == [("x", {"a": 1})]


def test_trailing_event_without_blank_line_is_flushed():
    body = 'event: x\ndata: {"a": 1}'
    events = list(parse_sse_events(_response_with_body(body)))
    assert events == [("x", {"a": 1})]


def test_event_name_resets_between_events():
    body = (
        'event: first\ndata: {}\n\n'
        'data: {}\n\n'  # no event field — should default to "message"
    )
    events = list(parse_sse_events(_response_with_body(body)))
    assert [e[0] for e in events] == ["first", "message"]
