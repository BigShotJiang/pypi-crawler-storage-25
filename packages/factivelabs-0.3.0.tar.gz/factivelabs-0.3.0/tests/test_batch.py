"""Tests for submit_batch, get_job, wait_for_batch."""

from __future__ import annotations

import base64
import json

import httpx
import pytest

from factivelabs import BatchSubmission, FactiveClient, JobStatus
from factivelabs._batch import build_batch_body, normalize_batch_item
from factivelabs.exceptions import FactiveError


# ── Body-builder unit tests ─────────────────────────────────────────────────


def test_normalize_text_item():
    norm = normalize_batch_item({"text": "Hello.", "context": "ctx"})
    assert norm["content"] == "Hello."
    assert norm["content_type"] == "text"
    assert norm["context"] == "ctx"


def test_normalize_url_item_youtube_autodetect():
    norm = normalize_batch_item({"url": "https://youtu.be/abc"})
    assert norm["url"] == "https://youtu.be/abc"
    assert norm["content_type"] == "youtube"


def test_normalize_file_item_from_path(tmp_path):
    p = tmp_path / "x.pdf"
    p.write_bytes(b"%PDF body")
    norm = normalize_batch_item({"file": p})
    assert norm["content_type"] == "pdf"
    assert base64.b64decode(norm["file"]) == b"%PDF body"


def test_normalize_file_item_from_bytes_with_filename():
    norm = normalize_batch_item({"file": b"abc", "filename": "x.docx"})
    assert norm["content_type"] == "docx"


def test_normalize_rejects_multiple_input_keys():
    with pytest.raises(ValueError, match="exactly one"):
        normalize_batch_item({"text": "x", "url": "https://x"})


def test_normalize_rejects_no_input_keys():
    with pytest.raises(ValueError, match="exactly one"):
        normalize_batch_item({"context": "ctx only"})


def test_build_batch_body_includes_webhook():
    body = build_batch_body(
        [{"text": "a"}, {"text": "b"}], webhook_url="https://hook"
    )
    assert body["webhook_url"] == "https://hook"
    assert len(body["items"]) == 2


def test_build_batch_body_empty_raises():
    with pytest.raises(ValueError, match="at least one"):
        build_batch_body([])


# ── End-to-end via mock transport ───────────────────────────────────────────


def _client(handler) -> FactiveClient:
    return FactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )


def test_submit_batch_calls_endpoint():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["body"] = json.loads(request.content)
        return httpx.Response(
            202,
            json={
                "batch_id": "batch_abc",
                "total": 2,
                "jobs": [
                    {"index": 0, "job_id": "fc_1", "status": "queued"},
                    {"index": 1, "job_id": "fc_2", "status": "queued"},
                ],
            },
        )

    sub = _client(handler).submit_batch(
        [{"text": "doc 1"}, {"url": "https://example.com"}]
    )

    assert captured["path"] == "/api/v1/verify/batch"
    assert isinstance(sub, BatchSubmission)
    assert sub.batch_id == "batch_abc"
    assert len(sub.jobs) == 2
    assert sub.jobs[0].job_id == "fc_1"
    assert captured["body"]["items"][0]["content"] == "doc 1"
    assert captured["body"]["items"][1]["url"] == "https://example.com"


def test_get_job_returns_typed_status():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/jobs/fc_1"
        return httpx.Response(
            200,
            json={
                "id": "fc_1",
                "status": "complete",
                "progress": {"claims_extracted": 5, "claims_verified": 5, "claims_total": 5},
                "result": {
                    "claims": [{"text": "X.", "verdict": "confirmed"}],
                    "title": "Doc title",
                    "counts": {"confirmed": 1},
                },
                "created_at": "2026-05-05T16:00:00Z",
                "completed_at": "2026-05-05T16:01:00Z",
            },
        )

    status = _client(handler).get_job("fc_1")
    assert isinstance(status, JobStatus)
    assert status.is_complete is True
    assert status.is_done is True
    assert status.result is not None
    assert status.result.title == "Doc title"
    assert len(status.result.claims) == 1


def test_wait_for_batch_polls_until_done():
    poll_counts = {"fc_1": 0, "fc_2": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if path == "/api/v1/verify/batch":
            return httpx.Response(
                202,
                json={
                    "batch_id": "b",
                    "total": 2,
                    "jobs": [
                        {"index": 0, "job_id": "fc_1", "status": "queued"},
                        {"index": 1, "job_id": "fc_2", "status": "queued"},
                    ],
                },
            )
        if path.startswith("/api/v1/jobs/"):
            job_id = path.rsplit("/", 1)[-1]
            poll_counts[job_id] += 1
            # fc_1 finishes immediately; fc_2 takes 2 polls
            if job_id == "fc_1" or poll_counts[job_id] >= 2:
                return httpx.Response(
                    200,
                    json={
                        "id": job_id,
                        "status": "complete",
                        "progress": {},
                        "result": {"claims": [], "counts": {}},
                        "created_at": "",
                        "completed_at": "now",
                    },
                )
            return httpx.Response(
                200,
                json={
                    "id": job_id,
                    "status": "running",
                    "progress": {},
                    "result": None,
                    "created_at": "",
                    "completed_at": None,
                },
            )
        return httpx.Response(404)

    client = _client(handler)
    sub = client.submit_batch([{"text": "a"}, {"text": "b"}])
    progress_calls: list[tuple[str, str]] = []

    results = client.wait_for_batch(
        sub,
        timeout=5,
        poll_interval=0.01,
        on_progress=lambda jid, st: progress_calls.append((jid, st.status)),
    )

    assert results["fc_1"].is_complete
    assert results["fc_2"].is_complete
    # fc_2 took 2 polls; fc_1 took 1
    assert poll_counts["fc_2"] >= 2


def test_wait_for_batch_timeout_raises():
    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if path == "/api/v1/verify/batch":
            return httpx.Response(
                202,
                json={
                    "batch_id": "b",
                    "total": 1,
                    "jobs": [{"index": 0, "job_id": "fc_x", "status": "queued"}],
                },
            )
        return httpx.Response(
            200,
            json={
                "id": "fc_x",
                "status": "running",
                "progress": {},
                "result": None,
                "created_at": "",
                "completed_at": None,
            },
        )

    client = _client(handler)
    sub = client.submit_batch([{"text": "a"}])
    with pytest.raises(FactiveError, match="timed out"):
        client.wait_for_batch(sub, timeout=0.05, poll_interval=0.01)
