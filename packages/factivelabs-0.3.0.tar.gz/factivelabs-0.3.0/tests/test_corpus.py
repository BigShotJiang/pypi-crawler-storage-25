"""Tests for the corpus namespace: upload, list, delete, clear, scope CRUD."""

from __future__ import annotations

import json

import httpx
import pytest

from factivelabs import CorpusDocument, CorpusScope, FactiveClient
from factivelabs._corpus import normalize_corpus_files


# ── normalize_corpus_files unit tests ───────────────────────────────────────


def test_normalize_path(tmp_path):
    p = tmp_path / "doc.pdf"
    p.write_bytes(b"%PDF body")
    out = normalize_corpus_files([p])
    assert len(out) == 1
    field, (filename, raw, ct) = out[0]
    assert field == "files"
    assert filename == "doc.pdf"
    assert raw == b"%PDF body"
    assert ct == "application/pdf"


def test_normalize_tuple_2():
    out = normalize_corpus_files([("memo.txt", b"hello")])
    field, (filename, raw, ct) = out[0]
    assert filename == "memo.txt"
    assert raw == b"hello"
    assert ct == "text/plain"


def test_normalize_tuple_3_explicit_content_type():
    out = normalize_corpus_files([("x.bin", b"\x00\x01", "application/octet-stream")])
    _, (_, _, ct) = out[0]
    assert ct == "application/octet-stream"


def test_normalize_empty_raises():
    with pytest.raises(ValueError, match="At least one file"):
        normalize_corpus_files([])


def test_normalize_path_not_found(tmp_path):
    with pytest.raises(FileNotFoundError):
        normalize_corpus_files([tmp_path / "nope.pdf"])


# ── End-to-end via mock transport ───────────────────────────────────────────


def _client(handler) -> FactiveClient:
    return FactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )


def test_corpus_upload(tmp_path):
    pdf = tmp_path / "x.pdf"
    pdf.write_bytes(b"%PDF abc")

    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["method"] = request.method
        captured["content_type"] = request.headers.get("content-type", "")
        # multipart body contains the bytes; we just confirm it's multipart
        return httpx.Response(
            202, json={"queued": [{"file_name": "x.pdf", "status": "queued"}], "failed": []}
        )

    result = _client(handler).corpus.upload([pdf])
    assert captured["path"] == "/api/v1/private-corpus/upload"
    assert captured["method"] == "POST"
    assert "multipart/form-data" in captured["content_type"]
    assert result["queued"][0]["file_name"] == "x.pdf"


def test_corpus_list():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/private-corpus"
        assert request.method == "GET"
        return httpx.Response(
            200,
            json={
                "docs": [
                    {"doc_id": "d_1", "file_name": "a.pdf", "file_type": "pdf", "status": "ready"},
                    {"doc_id": "d_2", "file_name": "b.docx", "file_type": "docx", "status": "embedding"},
                ],
                "count": 2,
            },
        )

    docs = _client(handler).corpus.list()
    assert len(docs) == 2
    assert isinstance(docs[0], CorpusDocument)
    assert docs[0].doc_id == "d_1"
    assert docs[1].status == "embedding"


def test_corpus_delete():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/private-corpus/d_1"
        assert request.method == "DELETE"
        return httpx.Response(200, json={"doc_id": "d_1", "deleted": True})

    _client(handler).corpus.delete("d_1")  # no exception = pass


def test_corpus_clear_requires_confirm():
    handler = lambda r: httpx.Response(200, json={"deleted_count": 0})
    client = _client(handler)
    with pytest.raises(ValueError, match="confirm=True"):
        client.corpus.clear()


def test_corpus_clear_with_confirm():
    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["body"] = request.content.decode()
        return httpx.Response(200, json={"deleted_count": 5})

    n = _client(handler).corpus.clear(confirm=True)
    assert n == 5
    assert "confirm=true" in captured["body"]


def test_corpus_get_scope():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/private-corpus/scope"
        return httpx.Response(
            200,
            json={
                "scope_text": "HR documentation about benefits and policies.",
                "status": "idle",
                "edited_by_user": False,
                "generated_at": "2026-05-05T15:00:00Z",
                "last_error": None,
                "updated_at": "2026-05-05T15:00:00Z",
            },
        )

    scope = _client(handler).corpus.get_scope()
    assert isinstance(scope, CorpusScope)
    assert "HR" in scope.scope_text
    assert scope.status == "idle"


def test_corpus_update_scope():
    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "scope_text": "Updated scope.",
                "status": "idle",
                "edited_by_user": True,
                "generated_at": None,
                "updated_at": "2026-05-05T16:00:00Z",
            },
        )

    scope = _client(handler).corpus.update_scope("Updated scope.")
    assert captured["body"]["scope_text"] == "Updated scope."
    assert scope.edited_by_user is True


def test_corpus_regenerate_scope():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/private-corpus/scope/regenerate"
        return httpx.Response(
            200,
            json={
                "scope_text": "",
                "status": "regenerating",
                "edited_by_user": False,
                "generated_at": None,
                "updated_at": "2026-05-05T16:00:00Z",
            },
        )

    scope = _client(handler).corpus.regenerate_scope()
    assert scope.status == "regenerating"
