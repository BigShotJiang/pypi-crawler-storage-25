"""End-to-end tests for the streaming verify flow against the v0.3 stateless endpoint.

Each test mocks ``POST /api/v1/verify/paragraph`` at the transport layer
via httpx.MockTransport. The mock returns one paragraph's worth of
verified claims per call.
"""

from __future__ import annotations

import json

import httpx
import pytest

from factivelabs import Claim, FactiveClient, StreamResult
from factivelabs.exceptions import (
    AuthenticationError,
    ParagraphRejectedError,
)


def _build_handler(*, paragraph_responses=None, capture: list = None):
    """Return a transport handler that responds to /api/v1/verify/paragraph.

    ``paragraph_responses`` — optional list of httpx.Response to return
    in order. If exhausted, falls back to a default 200 response with
    deterministic claims.
    """
    capture = capture if capture is not None else []
    paragraph_responses = list(paragraph_responses or [])
    response_iter = iter(paragraph_responses)

    def handler(request: httpx.Request) -> httpx.Response:
        if (
            request.url.path == "/api/v1/verify/paragraph"
            and request.method == "POST"
        ):
            try:
                body = json.loads(request.content)
            except Exception:
                body = {}
            capture.append(body)
            try:
                return next(response_iter)
            except StopIteration:
                # Default response: one fake claim per sentence in the input.
                text = body.get("text") or ""
                sentences = [s.strip() for s in text.split(".") if s.strip()]
                claims = [
                    {
                        "text": s + ".",
                        "verdict": ["confirmed", "disputed", "unclear"][i % 3],
                        "summary": "ok",
                    }
                    for i, s in enumerate(sentences[:5])
                ]
                return httpx.Response(
                    200,
                    json={
                        "paragraph_id": f"pg_{len(capture):08x}",
                        "chars_received": len(text),
                        "claims": claims,
                        "counts": {
                            "confirmed": sum(1 for c in claims if c["verdict"] == "confirmed"),
                            "disputed": sum(1 for c in claims if c["verdict"] == "disputed"),
                            "inconclusive": 0,
                            "subjective": 0,
                            "skipped": 0,
                        },
                        "processing_time_ms": 50,
                    },
                )
        return httpx.Response(404, text=f"unexpected: {request.method} {request.url.path}")

    return handler, capture


def _client_with_handler(handler) -> FactiveClient:
    return FactiveClient(
        api_key="fk_test_xxx",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )


# ── Happy path ───────────────────────────────────────────────────────────────


def test_basic_streaming_two_paragraphs():
    handler, capture = _build_handler()
    client = _client_with_handler(handler)

    tokens = ["First paragraph.", "\n\n", "Second paragraph.", "\n\n"]
    result = client.verify_stream(tokens, context="user question")

    assert isinstance(result, StreamResult)
    assert result.complete is True
    # 2 real paragraphs (no final empty flush — buffer is empty after last \n\n)
    assert len(capture) == 2
    assert capture[0]["text"] == "First paragraph.\n\n"
    assert capture[1]["text"] == "Second paragraph.\n\n"
    assert capture[0]["context"] == "user question"

    # Claims accumulated across paragraphs.
    assert len(result.claims) == 2  # one per paragraph
    assert result.confirmed[0].text == "First paragraph."

    # chars_sent matches what we POSTed; chars_received echoes from server
    assert result.chars_sent == len("First paragraph.\n\n") + len("Second paragraph.\n\n")
    assert result.chars_received == result.chars_sent


def test_byte_equality_property():
    handler, _ = _build_handler()
    client = _client_with_handler(handler)
    result = client.verify_stream(["Hello.", "\n\n"])
    assert result.byte_equality is True


def test_byte_equality_detects_mismatch():
    """Server claims to have received fewer chars than we sent — byte_equality=False."""
    paragraph_responses = [
        httpx.Response(
            200,
            json={
                "paragraph_id": "pg_drop",
                "chars_received": 3,  # but we sent more
                "claims": [],
                "counts": {
                    "confirmed": 0,
                    "disputed": 0,
                    "inconclusive": 0,
                    "subjective": 0,
                    "skipped": 0,
                },
                "processing_time_ms": 5,
            },
        )
    ]
    handler, _ = _build_handler(paragraph_responses=paragraph_responses)
    client = _client_with_handler(handler)
    result = client.verify_stream(["Hello.", "\n\n"])
    assert result.chars_sent > result.chars_received
    assert result.byte_equality is False


# ── Callbacks ────────────────────────────────────────────────────────────────


def test_callbacks_fire_in_order():
    handler, _ = _build_handler()
    client = _client_with_handler(handler)

    tokens_seen: list[str] = []
    paragraphs_sent: list[str] = []
    claims_seen: list[Claim] = []
    events_seen: list[str] = []

    tokens = ["First paragraph.", "\n\n"]
    client.verify_stream(
        tokens,
        on_token=lambda t: tokens_seen.append(t),
        on_paragraph_sent=lambda p: paragraphs_sent.append(p),
        on_claim=lambda c: claims_seen.append(c),
        on_event=lambda name, data: events_seen.append(name),
    )

    assert tokens_seen == ["First paragraph.", "\n\n"]
    assert paragraphs_sent == ["First paragraph.\n\n"]
    assert len(claims_seen) == 1
    assert "paragraph_received" in events_seen
    assert "claim_verified" in events_seen
    assert "complete" in events_seen


# ── Error paths ──────────────────────────────────────────────────────────────


def test_paragraph_post_4xx_raises_paragraph_rejected():
    paragraph_responses = [httpx.Response(400, text="bad chunk")]
    handler, _ = _build_handler(paragraph_responses=paragraph_responses)
    client = _client_with_handler(handler)

    with pytest.raises(ParagraphRejectedError):
        client.verify_stream(["Hello.", "\n\n"])


def test_paragraph_post_401_raises_auth_error():
    paragraph_responses = [httpx.Response(401, text="bad key")]
    handler, _ = _build_handler(paragraph_responses=paragraph_responses)
    client = _client_with_handler(handler)
    with pytest.raises(AuthenticationError):
        client.verify_stream(["Hello.", "\n\n"])


# ── Single-paragraph flush ──────────────────────────────────────────────────


def test_input_with_no_paragraph_break_is_flushed_as_one_paragraph():
    handler, capture = _build_handler()
    client = _client_with_handler(handler)

    tokens = ["A short ", "single ", "paragraph."]
    result = client.verify_stream(tokens)

    assert len(capture) == 1
    assert capture[0]["text"].rstrip("\n") == "A short single paragraph."
    assert result.complete is True
