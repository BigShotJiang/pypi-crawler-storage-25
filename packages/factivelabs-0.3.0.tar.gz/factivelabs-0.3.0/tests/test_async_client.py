"""Tests for AsyncFactiveClient — async twin of FactiveClient."""

from __future__ import annotations

import asyncio
import json

import httpx
import pytest

from factivelabs import AsyncFactiveClient, Claim, StreamResult
from factivelabs.exceptions import (
    AuthenticationError,
    ParagraphRejectedError,
    QuotaExceededError,
)


pytestmark = pytest.mark.asyncio


def _client(handler) -> AsyncFactiveClient:
    return AsyncFactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )


# ── verify_text ──────────────────────────────────────────────────────────────


async def test_async_verify_text_happy_path():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["auth"] = request.headers.get("authorization")
        return httpx.Response(
            200,
            json={
                "claims": [
                    {"text": "X.", "verdict": "confirmed", "summary": "Yes."},
                ],
                "title": "Test",
                "counts": {"confirmed": 1},
            },
        )

    client = _client(handler)
    result = await client.verify_text("doc")
    assert captured["path"] == "/api/v1/verify"
    assert captured["auth"] == "Bearer fk_test"
    assert len(result.claims) == 1


async def test_async_verify_text_401():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, text="bad key")

    with pytest.raises(AuthenticationError):
        await _client(handler).verify_text("x")


async def test_async_verify_text_402():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            402,
            json={"detail": {"message": "Out of credits", "credits_quota": 500}},
        )

    with pytest.raises(QuotaExceededError):
        await _client(handler).verify_text("x")


# ── verify_url and verify_file ──────────────────────────────────────────────


async def test_async_verify_url_calls_both_endpoints():
    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        body = json.loads(request.content) if request.content else {}
        captured.setdefault(path, []).append(body)
        if path == "/api/v1/extract-text":
            return httpx.Response(
                200,
                json={
                    "id": "et_1",
                    "status": "complete",
                    "input_type": "url",
                    "text": "Article body.",
                    "title": "Title",
                    "char_count": 13,
                    "processing_time_ms": 50,
                },
            )
        if path == "/api/v1/verify":
            return httpx.Response(
                200,
                json={
                    "claims": [{"text": "C.", "verdict": "confirmed"}],
                    "counts": {"confirmed": 1},
                },
            )
        return httpx.Response(404)

    client = _client(handler)
    result = await client.verify_url("https://example.com/x")
    assert captured["/api/v1/extract-text"][0]["url"] == "https://example.com/x"
    assert captured["/api/v1/verify"][0]["text"] == "Article body."
    assert result.title == "Title"
    assert result.extracted_text == "Article body."


async def test_async_verify_file_from_path(tmp_path):
    captured: dict = {}
    pdf = tmp_path / "x.pdf"
    pdf.write_bytes(b"%PDF-1.4 hi")

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        body = json.loads(request.content) if request.content else {}
        captured.setdefault(path, []).append(body)
        if path == "/api/v1/extract-text":
            return httpx.Response(
                200,
                json={
                    "id": "et_2",
                    "status": "complete",
                    "input_type": "pdf",
                    "text": "PDF body.",
                    "title": "",
                    "char_count": 9,
                    "processing_time_ms": 50,
                },
            )
        if path == "/api/v1/verify":
            return httpx.Response(200, json={"claims": [], "counts": {}})
        return httpx.Response(404)

    client = _client(handler)
    result = await client.verify_file(pdf)
    assert captured["/api/v1/extract-text"][0]["content_type"] == "pdf"
    assert result.extracted_text == "PDF body."


# ── verify_stream (against the new stateless /verify/paragraph endpoint) ────


def _make_paragraph_handler(paragraph_responses=None, capture=None):
    capture = capture if capture is not None else []
    paragraph_responses = list(paragraph_responses or [])
    response_iter = iter(paragraph_responses)

    def handler(request: httpx.Request) -> httpx.Response:
        if (
            request.url.path == "/api/v1/verify/paragraph"
            and request.method == "POST"
        ):
            try:
                body = json.loads(request.content)
            except Exception:
                body = {}
            capture.append(body)
            try:
                return next(response_iter)
            except StopIteration:
                text = body.get("text") or ""
                sentences = [s.strip() for s in text.split(".") if s.strip()]
                claims = [
                    {"text": s + ".", "verdict": "confirmed", "summary": "ok"}
                    for s in sentences[:5]
                ]
                return httpx.Response(
                    200,
                    json={
                        "paragraph_id": f"pg_{len(capture):08x}",
                        "chars_received": len(text),
                        "claims": claims,
                        "counts": {
                            "confirmed": len(claims),
                            "disputed": 0,
                            "inconclusive": 0,
                            "subjective": 0,
                            "skipped": 0,
                        },
                        "processing_time_ms": 50,
                    },
                )
        return httpx.Response(404, text=f"unexpected: {request.url.path}")

    return handler, capture


async def test_async_streaming_basic_flow():
    handler, capture = _make_paragraph_handler()
    client = AsyncFactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )

    tokens = ["First paragraph.", "\n\n"]
    result = await client.verify_stream(tokens, context="user q")

    assert isinstance(result, StreamResult)
    assert result.complete is True
    assert len(capture) == 1
    assert capture[0]["text"] == "First paragraph.\n\n"
    assert capture[0]["context"] == "user q"
    assert len(result.claims) == 1
    assert result.claims[0].verdict == "confirmed"


async def test_async_streaming_accepts_async_iterator():
    """The async client must accept an async iterable as the token source."""
    handler, _ = _make_paragraph_handler()
    client = AsyncFactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )

    async def my_async_tokens():
        for tok in ["Hello", "\n\n"]:
            await asyncio.sleep(0)
            yield tok

    result = await client.verify_stream(my_async_tokens())
    assert result.complete is True


async def test_async_streaming_async_callbacks_are_awaited():
    handler, _ = _make_paragraph_handler()
    client = AsyncFactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )

    awaited_tokens: list[str] = []
    awaited_claims: list[Claim] = []

    async def on_token(t: str) -> None:
        await asyncio.sleep(0)
        awaited_tokens.append(t)

    async def on_claim(c: Claim) -> None:
        await asyncio.sleep(0)
        awaited_claims.append(c)

    await client.verify_stream(
        ["First paragraph.", "\n\n"], on_token=on_token, on_claim=on_claim
    )

    assert awaited_tokens == ["First paragraph.", "\n\n"]
    assert len(awaited_claims) == 1


async def test_async_streaming_paragraph_4xx_raises():
    handler, _ = _make_paragraph_handler(
        paragraph_responses=[httpx.Response(400, text="bad chunk")]
    )
    client = AsyncFactiveClient(
        api_key="fk_test",
        base_url="https://api.factivelabs.com",
        transport=httpx.MockTransport(handler),
        timeout=10.0,
    )

    with pytest.raises(ParagraphRejectedError):
        await client.verify_stream(["Hello", "\n\n"])
