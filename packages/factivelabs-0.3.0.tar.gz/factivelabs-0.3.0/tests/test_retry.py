"""Tests for the retry helper.

Contract:
* 200 → return immediately
* 401 → AuthenticationError, no retry
* 402 → QuotaExceededError, no retry
* 429 → RateLimitError, no retry (Retry-After honored on 429-then-retry path
        is also exercised, but we keep that as a single follow-up retry)
* 4xx (other) → ParagraphRejectedError, no retry
* 5xx → retry up to N times, then raise the final response
* network error → retry up to N times, then re-raise
"""

from __future__ import annotations

import httpx
import pytest

from factivelabs._retry import post_with_retry
from factivelabs.exceptions import (
    AuthenticationError,
    ParagraphRejectedError,
    QuotaExceededError,
    RateLimitError,
)


def _make_client(handler) -> httpx.Client:
    transport = httpx.MockTransport(handler)
    return httpx.Client(transport=transport)


def test_2xx_returns_response_no_retry():
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        return httpx.Response(200, json={"ok": True})

    with _make_client(handler) as c:
        r = post_with_retry(c, "https://x/y", json_body={}, headers={}, max_retries=3, backoff_base=0.0)
    assert r.status_code == 200
    assert calls["n"] == 1


def test_401_raises_authentication_error():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, text="bad key")

    with _make_client(handler) as c:
        with pytest.raises(AuthenticationError):
            post_with_retry(c, "https://x/y", json_body={}, headers={}, max_retries=3, backoff_base=0.0)


def test_402_raises_quota_exceeded():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            402,
            json={"detail": {"message": "Free tier limit reached", "credits_used": 500}},
        )

    with _make_client(handler) as c:
        with pytest.raises(QuotaExceededError) as exc_info:
            post_with_retry(c, "https://x/y", json_body={}, headers={}, max_retries=3, backoff_base=0.0)
    assert "Free tier" in str(exc_info.value)
    assert exc_info.value.detail.get("credits_used") == 500


def test_429_raises_rate_limit():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(429, headers={"retry-after": "2.5"})

    with _make_client(handler) as c:
        with pytest.raises(RateLimitError) as exc_info:
            post_with_retry(c, "https://x/y", json_body={}, headers={}, max_retries=0, backoff_base=0.0)
    assert exc_info.value.retry_after == 2.5


def test_400_raises_paragraph_rejected_no_retry():
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        return httpx.Response(400, text="bad request body")

    with _make_client(handler) as c:
        with pytest.raises(ParagraphRejectedError) as exc_info:
            post_with_retry(c, "https://x/y", json_body={}, headers={}, max_retries=3, backoff_base=0.0)

    assert calls["n"] == 1, "4xx must not be retried"
    assert exc_info.value.status_code == 400


def test_5xx_is_retried_then_succeeds():
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] < 3:
            return httpx.Response(503, text="upstream busy")
        return httpx.Response(200, json={"ok": True})

    with _make_client(handler) as c:
        r = post_with_retry(c, "https://x/y", json_body={}, headers={}, max_retries=4, backoff_base=0.0)
    assert r.status_code == 200
    assert calls["n"] == 3, "Should have retried twice, succeeded on third try"


def test_5xx_exhausted_raises():
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        return httpx.Response(500, text="server boom")

    with _make_client(handler) as c:
        with pytest.raises(httpx.HTTPStatusError):
            post_with_retry(c, "https://x/y", json_body={}, headers={}, max_retries=2, backoff_base=0.0)
    assert calls["n"] == 3, "1 initial attempt + 2 retries"


def test_network_error_retried_then_succeeds():
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] < 2:
            raise httpx.ConnectError("simulated network blip", request=request)
        return httpx.Response(200, json={"ok": True})

    with _make_client(handler) as c:
        r = post_with_retry(c, "https://x/y", json_body={}, headers={}, max_retries=3, backoff_base=0.0)
    assert r.status_code == 200
    assert calls["n"] == 2
