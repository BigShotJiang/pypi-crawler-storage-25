"""Unit tests for ParagraphBuffer — the core token-to-paragraph splitter."""

from __future__ import annotations

from factivelabs._buffer import ParagraphBuffer


def test_no_break_returns_nothing():
    buf = ParagraphBuffer()
    out = buf.add("hello world ")
    assert out == []
    assert buf.chars_consumed == len("hello world ")


def test_single_paragraph_break_emits_one_paragraph():
    buf = ParagraphBuffer()
    out = buf.add("First paragraph.\n\nStart of second")
    assert out == ["First paragraph.\n\n"]


def test_paragraph_break_split_across_tokens():
    """The break can arrive split across multiple add() calls."""
    buf = ParagraphBuffer()
    pieces = ["First", " paragraph.", "\n", "\n", "Second", " starts"]
    emitted: list[str] = []
    for tok in pieces:
        emitted.extend(buf.add(tok))
    assert emitted == ["First paragraph.\n\n"]
    # Tail is buffered; flush returns it stripped of trailing whitespace.
    tail = buf.flush()
    assert tail == "Second starts"


def test_two_paragraphs_in_single_token():
    buf = ParagraphBuffer()
    out = buf.add("Para A.\n\nPara B.\n\nPara C in progress")
    assert out == ["Para A.\n\n", "Para B.\n\n"]
    assert buf.flush() == "Para C in progress"


def test_whitespace_only_paragraph_dropped():
    buf = ParagraphBuffer()
    # "\n\n" between two real paragraphs but extra blank lines in the middle:
    out = buf.add("Real one.\n\n   \n\nReal two starts")
    # The whitespace-only middle paragraph is dropped; "Real one." flushes;
    # "Real two starts" is the tail.
    assert out == ["Real one.\n\n"]
    assert buf.flush() == "Real two starts"


def test_flush_on_empty_buffer():
    buf = ParagraphBuffer()
    assert buf.flush() is None


def test_flush_strips_trailing_whitespace():
    buf = ParagraphBuffer()
    buf.add("trailing tokens   \n  ")
    assert buf.flush() == "trailing tokens"


def test_chars_consumed_counts_every_token():
    buf = ParagraphBuffer()
    buf.add("abc")
    buf.add("de")
    buf.add("\n\nf")
    assert buf.chars_consumed == 3 + 2 + 3


def test_empty_token_is_a_noop():
    buf = ParagraphBuffer()
    assert buf.add("") == []
    assert buf.chars_consumed == 0
