"""Async client for the factivelabs SDK.

Mirrors :class:`factivelabs.FactiveClient` method-for-method, but every
network operation is a coroutine. Use this from async/await codebases
(FastAPI handlers, asyncio scripts, anyio code, etc.).
"""

from __future__ import annotations

import asyncio
import os
import time
from typing import Any, AsyncIterable, Awaitable, Callable, Iterable, Mapping, Union

import httpx

from ._batch import build_batch_body
from ._corpus import CorpusFileInput, normalize_corpus_files
from ._extraction import build_file_body, build_url_body
from ._streaming_async import stream_verify_async
from ._version import __version__
from .exceptions import (
    AuthenticationError,
    FactiveError,
    QuotaExceededError,
    RateLimitError,
)
from .types import (
    BatchSubmission,
    Claim,
    CorpusDocument,
    CorpusScope,
    ExtractedText,
    JobStatus,
    StreamEvent,
    StreamResult,
    VerifyResult,
)


DEFAULT_BASE_URL = "https://api.factivelabs.com"


class _AsyncNoopCloseClient:
    """Wrap an httpx.AsyncClient so ``async with`` exit does NOT close it."""

    __slots__ = ("_inner",)

    def __init__(self, inner: httpx.AsyncClient) -> None:
        self._inner = inner

    async def __aenter__(self) -> httpx.AsyncClient:
        return self._inner

    async def __aexit__(self, *exc_info: Any) -> None:
        return None


class AsyncFactiveClient:
    """Async client for the Factive fact-checking API.

    Use this in async codebases. The method names and arguments mirror
    :class:`FactiveClient` exactly — every method is a coroutine.

    Example::

        import asyncio
        from factivelabs import AsyncFactiveClient

        async def main():
            client = AsyncFactiveClient(api_key="fk_...")
            result = await client.verify_text("The Sahara is the largest desert.")
            for c in result.claims:
                print(c.verdict, "—", c.text)

        asyncio.run(main())
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 300.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._transport = transport
        self._shared_client: httpx.AsyncClient | None = None
        # Sub-clients (namespaced for discoverability):
        self.corpus = _AsyncCorpusNamespace(self)

    # ── Context-manager support ──────────────────────────────────────────

    async def __aenter__(self) -> "AsyncFactiveClient":
        if self._shared_client is None:
            self._shared_client = self._make_raw_client()
        return self

    async def __aexit__(self, *exc_info: Any) -> None:
        if self._shared_client is not None:
            await self._shared_client.aclose()
            self._shared_client = None

    async def aclose(self) -> None:
        """Close the shared HTTP client. Safe to call repeatedly."""
        if self._shared_client is not None:
            await self._shared_client.aclose()
            self._shared_client = None

    # ── Public API ────────────────────────────────────────────────────────

    async def verify_text(
        self,
        text: str,
        *,
        context: str | None = None,
        profile: str | None = None,
        use_private_corpus: bool = False,
        corpus_scope: str | None = None,
        second_pass: bool | None = None,
    ) -> VerifyResult:
        body: dict[str, Any] = {"text": text}
        if context:
            body["context"] = context
        if profile:
            body["profile"] = profile
        if use_private_corpus:
            body["use_private_corpus"] = True
            if corpus_scope:
                body["corpus_scope"] = corpus_scope
        if second_pass is not None:
            body["second_pass"] = second_pass

        async with self._build_client() as client:
            response = await client.post(
                f"{self.base_url}/api/v1/verify",
                json=body,
                headers=self._headers(),
                timeout=self.timeout,
            )

        self._raise_typed_error(response)
        response.raise_for_status()
        return VerifyResult.from_json(response.json())

    async def verify_url(
        self,
        url: str,
        *,
        content_type: str | None = None,
        context: str | None = None,
        profile: str | None = None,
        use_private_corpus: bool = False,
        corpus_scope: str | None = None,
        second_pass: bool | None = None,
    ) -> VerifyResult:
        body = build_url_body(url, content_type=content_type)
        extracted = await self._extract_text_via_api(body)
        verify_result = await self.verify_text(
            extracted.text,
            context=context,
            profile=profile,
            use_private_corpus=use_private_corpus,
            corpus_scope=corpus_scope,
            second_pass=second_pass,
        )
        verify_result.extracted_text = extracted.text
        if not verify_result.title:
            verify_result.title = extracted.title or None
        return verify_result

    async def verify_file(
        self,
        file: Union[str, bytes, "os.PathLike[str]"],
        *,
        content_type: str | None = None,
        filename: str | None = None,
        context: str | None = None,
        profile: str | None = None,
        use_private_corpus: bool = False,
        corpus_scope: str | None = None,
        second_pass: bool | None = None,
    ) -> VerifyResult:
        body = build_file_body(file, content_type=content_type, filename=filename)
        extracted = await self._extract_text_via_api(body)
        verify_result = await self.verify_text(
            extracted.text,
            context=context,
            profile=profile,
            use_private_corpus=use_private_corpus,
            corpus_scope=corpus_scope,
            second_pass=second_pass,
        )
        verify_result.extracted_text = extracted.text
        if not verify_result.title:
            verify_result.title = extracted.title or None
        return verify_result

    async def extract_text(
        self,
        *,
        url: str | None = None,
        file: Union[str, bytes, "os.PathLike[str]", None] = None,
        content_type: str | None = None,
        filename: str | None = None,
    ) -> ExtractedText:
        if url and file is not None:
            raise ValueError("Pass either url=... or file=..., not both.")
        if not url and file is None:
            raise ValueError("Pass url=... or file=...")
        if url:
            body = build_url_body(url, content_type=content_type)
        else:
            body = build_file_body(
                file, content_type=content_type, filename=filename
            )  # type: ignore[arg-type]
        return await self._extract_text_via_api(body)

    # ── Batch API ─────────────────────────────────────────────────────────

    async def submit_batch(
        self,
        items: list[Mapping[str, Any]],
        *,
        webhook_url: str | None = None,
    ) -> BatchSubmission:
        """Async twin of :meth:`FactiveClient.submit_batch`."""
        body = build_batch_body(items, webhook_url=webhook_url)
        async with self._build_client() as client:
            response = await client.post(
                f"{self.base_url}/api/v1/verify/batch",
                json=body,
                headers=self._headers(),
                timeout=self.timeout,
            )
        self._raise_typed_error(response)
        response.raise_for_status()
        return BatchSubmission.from_json(response.json())

    async def get_job(self, job_id: str) -> JobStatus:
        """Async twin of :meth:`FactiveClient.get_job`."""
        async with self._build_client() as client:
            response = await client.get(
                f"{self.base_url}/api/v1/jobs/{job_id}",
                headers=self._headers(),
                timeout=self.timeout,
            )
        self._raise_typed_error(response)
        response.raise_for_status()
        return JobStatus.from_json(response.json())

    async def wait_for_batch(
        self,
        submission: BatchSubmission,
        *,
        timeout: float = 600.0,
        poll_interval: float = 2.0,
        on_progress: Callable[[str, JobStatus], Union[None, Awaitable[None]]] | None = None,
    ) -> dict[str, JobStatus]:
        """Async twin of :meth:`FactiveClient.wait_for_batch`."""
        deadline = time.monotonic() + timeout
        results: dict[str, JobStatus] = {}
        pending = {ref.job_id for ref in submission.jobs}

        while pending and time.monotonic() < deadline:
            statuses = await asyncio.gather(
                *(self.get_job(job_id) for job_id in pending)
            )
            for job_id, status in zip(list(pending), statuses):
                results[job_id] = status
                if on_progress is not None:
                    try:
                        result = on_progress(job_id, status)
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception:
                        pass
                if status.is_done:
                    pending.discard(job_id)
            if pending:
                await asyncio.sleep(poll_interval)

        if pending:
            raise FactiveError(
                f"wait_for_batch timed out after {timeout:.0f}s with "
                f"{len(pending)} job(s) still running: {sorted(pending)}"
            )
        return results

    async def verify_stream(
        self,
        token_iterator: Union[Iterable[str], AsyncIterable[str]],
        *,
        context: str | None = None,
        profile: str | None = None,
        use_private_corpus: bool = False,
        corpus_scope: str | None = None,
        second_pass: bool | None = None,
        on_token: Callable[[str], Union[None, Awaitable[None]]] | None = None,
        on_paragraph_sent: Callable[[str], Union[None, Awaitable[None]]] | None = None,
        on_claim: Callable[[Claim], Union[None, Awaitable[None]]] | None = None,
        on_event: Callable[[str, dict[str, Any]], Union[None, Awaitable[None]]] | None = None,
    ) -> StreamResult:
        """Async streaming verify.

        ``token_iterator`` may be either a sync iterable or an async iterable
        of strings. Callbacks may be sync OR async — both are supported and
        awaited correctly.
        """
        async with self._build_client() as client:
            return await stream_verify_async(
                http=client,
                base_url=self.base_url,
                headers=self._headers(),
                token_iterator=token_iterator,
                context=context,
                profile=profile,
                use_private_corpus=use_private_corpus,
                corpus_scope=corpus_scope,
                second_pass=second_pass,
                on_token=on_token,
                on_paragraph_sent=on_paragraph_sent,
                on_claim=on_claim,
                on_event=on_event,
            )

    async def verify_stream_events(
        self,
        token_iterator: Union[Iterable[str], AsyncIterable[str]],
        *,
        context: str | None = None,
        profile: str | None = None,
        use_private_corpus: bool = False,
        corpus_scope: str | None = None,
        second_pass: bool | None = None,
    ):
        """Async events-iterator. Yields :class:`StreamEvent` objects as
        they happen. Async twin of :meth:`FactiveClient.verify_stream_events`.

        Example::

            async for ev in client.verify_stream_events(my_async_tokens):
                if ev.type == "token":
                    await write_to_user(ev.text)
                elif ev.type == "claim":
                    await save_claim(ev.claim)
                elif ev.type == "done":
                    log.info("byte_equality=%s", ev.result.byte_equality)
        """
        q: asyncio.Queue = asyncio.Queue()
        SENTINEL = object()

        async def worker() -> None:
            try:
                result = await self.verify_stream(
                    token_iterator,
                    context=context,
                    profile=profile,
                    use_private_corpus=use_private_corpus,
                    corpus_scope=corpus_scope,
                    second_pass=second_pass,
                    on_token=lambda t: q.put_nowait(StreamEvent(type="token", text=t)),
                    on_paragraph_sent=lambda p: q.put_nowait(
                        StreamEvent(type="paragraph_sent", text=p)
                    ),
                    on_claim=lambda c: q.put_nowait(StreamEvent(type="claim", claim=c)),
                    on_event=lambda n, d: q.put_nowait(
                        StreamEvent(type="event", name=n, data=d)
                    ),
                )
                await q.put(StreamEvent(type="done", result=result))
            except Exception as exc:
                await q.put(exc)
            finally:
                await q.put(SENTINEL)

        task = asyncio.create_task(worker(), name="factivelabs-events-worker")

        try:
            while True:
                item = await q.get()
                if item is SENTINEL:
                    break
                if isinstance(item, Exception):
                    raise item
                yield item
        finally:
            if not task.done():
                task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass

    # ── Internal helpers ──────────────────────────────────────────────────

    async def _extract_text_via_api(self, body: dict[str, Any]) -> ExtractedText:
        async with self._build_client() as client:
            response = await client.post(
                f"{self.base_url}/api/v1/extract-text",
                json=body,
                headers=self._headers(),
                timeout=self.timeout,
            )
        self._raise_typed_error(response)
        response.raise_for_status()
        return ExtractedText.from_json(response.json())

    def _raise_typed_error(self, response: httpx.Response) -> None:
        if response.status_code == 401:
            raise AuthenticationError(
                "Invalid or missing API key (HTTP 401). "
                "Pass api_key=... to AsyncFactiveClient(...)."
            )
        if response.status_code == 402:
            detail: dict[str, Any] = {}
            try:
                detail = response.json().get("detail", {}) or {}
            except Exception:
                pass
            raise QuotaExceededError(
                detail.get("message") or "Credit quota exceeded",
                detail=detail,
            )
        if response.status_code == 429:
            ra = response.headers.get("retry-after")
            try:
                retry_after = float(ra) if ra else None
            except ValueError:
                retry_after = None
            raise RateLimitError(retry_after=retry_after)

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": f"factivelabs-python/{__version__}",
        }

    def _make_raw_client(self) -> httpx.AsyncClient:
        kwargs: dict[str, Any] = {"timeout": self.timeout}
        if self._transport is not None:
            kwargs["transport"] = self._transport
        return httpx.AsyncClient(**kwargs)

    def _build_client(self):
        """Return an async context manager that yields an httpx.AsyncClient.

        Inside an ``async with AsyncFactiveClient(...) as c:`` block, the
        same client is reused across calls. Otherwise each call gets a
        fresh client.
        """
        if self._shared_client is not None:
            return _AsyncNoopCloseClient(self._shared_client)
        return self._make_raw_client()


# ── Sub-client: private corpus management ──────────────────────────────────


class _AsyncCorpusNamespace:
    """Async twin of :class:`factivelabs.client._CorpusNamespace`.

    Reached as ``async_client.corpus.*``.
    """

    _BASE_PATH = "/api/v1/private-corpus"

    def __init__(self, parent: "AsyncFactiveClient") -> None:
        self._p = parent

    async def upload(self, files: Iterable[CorpusFileInput]) -> dict[str, Any]:
        normalized = normalize_corpus_files(files)
        async with self._p._build_client() as client:
            response = await client.post(
                f"{self._p.base_url}{self._BASE_PATH}/upload",
                files=normalized,
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        return response.json()

    async def list(self) -> list[CorpusDocument]:
        async with self._p._build_client() as client:
            response = await client.get(
                f"{self._p.base_url}{self._BASE_PATH}",
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        payload = response.json()
        return [CorpusDocument.from_json(d) for d in payload.get("docs") or []]

    async def delete(self, doc_id: str) -> None:
        async with self._p._build_client() as client:
            response = await client.delete(
                f"{self._p.base_url}{self._BASE_PATH}/{doc_id}",
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()

    async def clear(self, *, confirm: bool = False) -> int:
        if not confirm:
            raise ValueError(
                "corpus.clear() refuses to wipe without explicit confirmation. "
                "Pass confirm=True to delete every document."
            )
        async with self._p._build_client() as client:
            response = await client.post(
                f"{self._p.base_url}{self._BASE_PATH}/clear",
                data={"confirm": "true"},
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        return int(response.json().get("deleted_count") or 0)

    async def get_scope(self) -> CorpusScope:
        async with self._p._build_client() as client:
            response = await client.get(
                f"{self._p.base_url}{self._BASE_PATH}/scope",
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        return CorpusScope.from_json(response.json())

    async def update_scope(self, scope_text: str) -> CorpusScope:
        async with self._p._build_client() as client:
            response = await client.put(
                f"{self._p.base_url}{self._BASE_PATH}/scope",
                json={"scope_text": scope_text},
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        return CorpusScope.from_json(response.json())

    async def regenerate_scope(self) -> CorpusScope:
        async with self._p._build_client() as client:
            response = await client.post(
                f"{self._p.base_url}{self._BASE_PATH}/scope/regenerate",
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        return CorpusScope.from_json(response.json())
