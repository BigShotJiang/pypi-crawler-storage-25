"""Exception types raised by the factivelabs SDK."""

from __future__ import annotations


class FactiveError(Exception):
    """Base exception for all factivelabs errors."""


class AuthenticationError(FactiveError):
    """Invalid or missing API key (HTTP 401)."""


class QuotaExceededError(FactiveError):
    """Account credit limit reached (HTTP 402)."""

    def __init__(self, message: str = "Credit quota exceeded", detail: dict | None = None):
        super().__init__(message)
        self.detail = detail or {}


class RateLimitError(FactiveError):
    """Rate limit exceeded (HTTP 429)."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: float | None = None):
        super().__init__(message)
        self.retry_after = retry_after


class ParagraphRejectedError(FactiveError):
    """A paragraph POST was rejected with a 4xx status. Will not be retried."""

    def __init__(self, status_code: int, body: str):
        self.status_code = status_code
        self.body = body
        super().__init__(f"Paragraph rejected with status {status_code}: {body[:200]}")


class StreamError(FactiveError):
    """An error event was received on the SSE stream."""

    def __init__(self, message: str, event_data: dict | None = None):
        super().__init__(message)
        self.event_data = event_data or {}


class StreamTimeoutError(FactiveError):
    """The streaming session did not complete within the configured timeout."""
