"""HTTP POST helper with the project's standard retry policy.

Contract (mirrors the docs at api.factivelabs.com/docs):

* 2xx → silent success, return the response.
* 4xx → loud reject. Raise ``ParagraphRejectedError`` (or a more specific
  ``AuthenticationError`` / ``QuotaExceededError`` / ``RateLimitError``).
  Do **not** retry — the caller should treat the paragraph as dropped.
* 5xx or network/timeout → retry with exponential backoff and jitter.
  After ``max_retries`` failed attempts the final response is raised
  via ``response.raise_for_status()``.
"""

from __future__ import annotations

import random
import time
from typing import Any

import httpx

from .exceptions import (
    AuthenticationError,
    ParagraphRejectedError,
    QuotaExceededError,
    RateLimitError,
)


def _classify_4xx(response: httpx.Response) -> Exception:
    body_text = ""
    try:
        body_text = response.text
    except Exception:
        body_text = ""

    if response.status_code == 401:
        return AuthenticationError(
            "Invalid or missing API key (HTTP 401). "
            "Pass api_key=... to FactiveClient(...)."
        )
    if response.status_code == 402:
        detail: dict[str, Any] = {}
        try:
            detail = response.json().get("detail", {}) or {}
        except Exception:
            pass
        msg = detail.get("message") or "Credit quota exceeded for this API key."
        return QuotaExceededError(msg, detail=detail)
    if response.status_code == 429:
        retry_after_str = response.headers.get("retry-after")
        retry_after = None
        if retry_after_str:
            try:
                retry_after = float(retry_after_str)
            except ValueError:
                retry_after = None
        return RateLimitError(
            "Rate limit exceeded (HTTP 429). Slow down or upgrade your plan.",
            retry_after=retry_after,
        )
    return ParagraphRejectedError(response.status_code, body_text)


def post_with_retry(
    client: httpx.Client,
    url: str,
    *,
    json_body: dict[str, Any],
    headers: dict[str, str],
    max_retries: int = 4,
    backoff_base: float = 0.5,
    backoff_max: float = 30.0,
    timeout: float = 60.0,
) -> httpx.Response:
    """POST with retry-on-5xx-and-network. Raises on 4xx (no retry)."""
    last_exc: Exception | None = None
    last_response: httpx.Response | None = None

    for attempt in range(max_retries + 1):
        try:
            response = client.post(url, json=json_body, headers=headers, timeout=timeout)
        except (httpx.NetworkError, httpx.TimeoutException) as exc:
            last_exc = exc
            if attempt >= max_retries:
                raise
            _sleep_backoff(attempt, backoff_base, backoff_max)
            continue

        last_response = response

        if 200 <= response.status_code < 300:
            return response

        if 400 <= response.status_code < 500 and response.status_code not in (408, 425):
            # 408 (request timeout) and 425 (too early) are retryable network-ish
            # signals. Everything else in the 4xx range is a hard reject — we
            # raise immediately so the caller sees the typed error and can
            # decide whether to back off (e.g. 429 with Retry-After).
            raise _classify_4xx(response)

        # 5xx or 408/425 — retry.
        if attempt >= max_retries:
            response.raise_for_status()
            return response  # not reached
        _sleep_backoff(attempt, backoff_base, backoff_max)

    if last_response is not None:
        last_response.raise_for_status()
        return last_response  # not reached
    if last_exc is not None:
        raise last_exc
    raise RuntimeError("post_with_retry exhausted retries with no response")


def _sleep_backoff(attempt: int, base: float, cap: float) -> None:
    sleep = min(cap, base * (2**attempt))
    jitter = random.uniform(0, sleep / 4)
    time.sleep(sleep + jitter)
