"""Async twin of :func:`factivelabs.streaming.stream_verify`.

As of 0.3.0, this implementation no longer opens an SSE stream — it just
posts each paragraph to the stateless ``/verify/paragraph`` endpoint and
parses the JSON response. The public API of
``AsyncFactiveClient.verify_stream`` is unchanged.

The token iterator may be either a regular iterable or an async iterable
of strings. Callbacks may be sync OR async — both are supported and
awaited correctly.
"""

from __future__ import annotations

import inspect
import logging
from typing import Any, AsyncIterable, AsyncIterator, Awaitable, Callable, Iterable, Union

import httpx

from ._buffer import ParagraphBuffer
from ._retry_async import post_with_retry_async
from .exceptions import StreamError
from .types import Claim, StreamResult

logger = logging.getLogger(__name__)


_TokenCallback = Callable[[str], Union[None, Awaitable[None]]]
_ParagraphCallback = Callable[[str], Union[None, Awaitable[None]]]
_ClaimCallback = Callable[[Claim], Union[None, Awaitable[None]]]
_EventCallback = Callable[[str, dict[str, Any]], Union[None, Awaitable[None]]]


async def _maybe_await(callback: Callable | None, *args: Any) -> None:
    if callback is None:
        return
    try:
        result = callback(*args)
        if inspect.isawaitable(result):
            await result
    except Exception:
        logger.exception("user callback raised; continuing")


async def _normalize_to_async_iter(
    source: Union[Iterable[str], AsyncIterable[str]],
) -> AsyncIterator[str]:
    if hasattr(source, "__aiter__"):
        async for item in source:  # type: ignore[union-attr]
            yield item
        return
    for item in source:  # type: ignore[union-attr]
        yield item


async def stream_verify_async(
    *,
    http: httpx.AsyncClient,
    base_url: str,
    headers: dict[str, str],
    token_iterator: Union[Iterable[str], AsyncIterable[str]],
    context: str | None,
    profile: str | None,
    use_private_corpus: bool,
    corpus_scope: str | None,
    second_pass: bool | None,
    on_token: _TokenCallback | None,
    on_paragraph_sent: _ParagraphCallback | None,
    on_claim: _ClaimCallback | None,
    on_event: _EventCallback | None,
) -> StreamResult:
    buf = ParagraphBuffer()
    chars_sent = 0
    chars_received = 0
    paragraphs_sent = 0
    claims_collected: list[Claim] = []
    last_paragraph_id = ""
    final_payload: dict[str, Any] = {}

    paragraph_url = f"{base_url}/api/v1/verify/paragraph"

    def _build_body(paragraph_text: str) -> dict[str, Any]:
        body: dict[str, Any] = {"text": paragraph_text}
        if context:
            body["context"] = context
        if profile:
            body["profile"] = profile
        if use_private_corpus:
            body["use_private_corpus"] = True
            if corpus_scope:
                body["corpus_scope"] = corpus_scope
        if second_pass is not None:
            body["second_pass"] = second_pass
        return body

    async def _send(paragraph: str) -> None:
        nonlocal chars_sent, chars_received, paragraphs_sent, last_paragraph_id, final_payload

        if not paragraph or not paragraph.strip():
            return

        body = _build_body(paragraph)
        response = await post_with_retry_async(
            http,
            paragraph_url,
            json_body=body,
            headers=headers,
            max_retries=4,
            timeout=120.0,
        )

        try:
            payload: dict[str, Any] = response.json()
        except Exception as exc:
            raise StreamError(
                f"Server returned non-JSON response to /verify/paragraph: {exc}"
            )

        chars_sent += len(paragraph)
        chars_received += int(payload.get("chars_received") or 0)
        paragraphs_sent += 1
        last_paragraph_id = payload.get("paragraph_id") or last_paragraph_id
        final_payload = payload

        await _maybe_await(on_paragraph_sent, paragraph)
        await _maybe_await(on_event, "paragraph_received", payload)

        for raw_claim in payload.get("claims") or []:
            try:
                claim = Claim.from_event_data({"claim": raw_claim})
            except Exception:
                logger.exception("Failed to parse claim record; skipping")
                continue
            claims_collected.append(claim)
            await _maybe_await(on_claim, claim)
            await _maybe_await(on_event, "claim_verified", {"claim": raw_claim})

    async for token in _normalize_to_async_iter(token_iterator):
        if not isinstance(token, str):
            token = str(token)
        await _maybe_await(on_token, token)
        for complete_paragraph in buf.add(token):
            await _send(complete_paragraph)

    tail = buf.flush()
    if tail:
        await _send(tail + "\n\n")

    await _maybe_await(
        on_event,
        "complete",
        {
            "chars_sent": chars_sent,
            "chars_received": chars_received,
            "paragraphs_sent": paragraphs_sent,
        },
    )

    return StreamResult(
        session_id=last_paragraph_id,
        chars_sent=chars_sent,
        chars_received=chars_received,
        paragraphs_sent=paragraphs_sent,
        claims=list(claims_collected),
        complete=True,
        final_event=final_payload or None,
    )
