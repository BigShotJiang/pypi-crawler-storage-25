"""Helpers for the URL / file extraction flow.

The Factive API exposes ``POST /api/v1/extract-text`` which takes either a
URL, base64-encoded file bytes, or raw text plus a ``content_type``
selector. This module normalizes any of those inputs into a single
request body that both the sync and async clients can post.
"""

from __future__ import annotations

import base64
import os
import re
from pathlib import Path
from typing import Any, Union

# Content types accepted by /api/v1/extract-text.
VALID_CONTENT_TYPES = {"text", "url", "youtube", "tiktok", "pdf", "docx", "image"}

# Suffix → content_type mapping for verify_file auto-detection.
_FILE_EXTENSIONS: dict[str, str] = {
    ".pdf": "pdf",
    ".docx": "docx",
    ".doc": "docx",  # the server's docx extractor handles both.
    ".png": "image",
    ".jpg": "image",
    ".jpeg": "image",
    ".gif": "image",
    ".bmp": "image",
    ".tiff": "image",
    ".webp": "image",
}


def detect_url_content_type(url: str) -> str:
    """Return the right content_type for a URL.

    Special-cases YouTube and TikTok because the server has dedicated
    extractors for them that pull transcripts/captions.
    """
    lower = url.lower()
    if re.search(r"(youtube\.com/|youtu\.be/)", lower):
        return "youtube"
    if "tiktok.com/" in lower:
        return "tiktok"
    return "url"


def detect_file_content_type(filename: str) -> str:
    """Return the right content_type from a filename's extension.

    Raises ``ValueError`` if the extension isn't supported.
    """
    suffix = Path(filename).suffix.lower()
    ct = _FILE_EXTENSIONS.get(suffix)
    if ct is None:
        raise ValueError(
            f"Could not auto-detect content type from filename '{filename}'. "
            f"Supported extensions: {sorted(_FILE_EXTENSIONS)}. "
            f"Pass content_type=... explicitly to override."
        )
    return ct


def build_url_body(url: str, content_type: str | None = None) -> dict[str, Any]:
    """Build the /extract-text body for a URL input."""
    ct = content_type or detect_url_content_type(url)
    if ct not in {"url", "youtube", "tiktok"}:
        raise ValueError(
            f"content_type for a URL must be one of: 'url', 'youtube', 'tiktok' "
            f"(got '{ct}')"
        )
    return {"url": url, "content_type": ct}


def build_file_body(
    file: Union[str, bytes, "os.PathLike[str]"],
    *,
    content_type: str | None = None,
    filename: str | None = None,
) -> dict[str, Any]:
    """Build the /extract-text body for a file input.

    Args:
        file: Either a path-like (``str`` / ``Path``) or the file's raw bytes.
        content_type: Override auto-detection. One of ``pdf``, ``docx``, ``image``.
        filename: When ``file`` is bytes, used to auto-detect ``content_type``.
            Ignored when content_type is explicitly provided.
    """
    if isinstance(file, (bytes, bytearray)):
        raw_bytes = bytes(file)
        if content_type is None:
            if filename is None:
                raise ValueError(
                    "When passing raw bytes to verify_file/extract_text you must "
                    "either provide content_type=... or filename=... so the SDK "
                    "knows how to tell the API to parse the file."
                )
            content_type = detect_file_content_type(filename)
    else:
        path = Path(os.fspath(file))
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        raw_bytes = path.read_bytes()
        if content_type is None:
            content_type = detect_file_content_type(path.name)

    if content_type not in {"pdf", "docx", "image"}:
        raise ValueError(
            f"content_type for a file must be one of: 'pdf', 'docx', 'image' "
            f"(got '{content_type}')"
        )

    encoded = base64.b64encode(raw_bytes).decode("ascii")
    return {"file": encoded, "content_type": content_type}


def build_text_body(content: str) -> dict[str, Any]:
    """Build the /extract-text body for a plain-text input."""
    return {"content": content, "content_type": "text"}
