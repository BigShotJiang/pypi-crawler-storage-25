"""Minimal Server-Sent Events parser for streaming HTTP responses.

We avoid taking ``sseclient-py`` as a dependency because (a) httpx already
streams lines and (b) the SSE format we consume is narrow.

Two parsers are exposed: :func:`parse_sse_events` (sync) and
:func:`parse_sse_events_async` (async). Both share the same line-by-line
state-machine logic — kept inline rather than factored out for clarity.
"""

from __future__ import annotations

import json
from typing import Any, AsyncIterator, Iterator, Tuple

import httpx


def parse_sse_events(response: httpx.Response) -> Iterator[Tuple[str, dict[str, Any]]]:
    """Yield ``(event_name, parsed_data)`` tuples from an open SSE response.

    Each SSE event has zero or more ``data:`` lines. We concatenate them
    and attempt to JSON-decode; if decoding fails the data is yielded
    as ``{"_raw": <string>}`` so callers can see something useful.

    Comment lines (``:foo``) are treated as keepalives and skipped.
    """
    event_name = "message"
    data_lines: list[str] = []

    for raw_line in response.iter_lines():
        # httpx yields str by default when the response is text/event-stream.
        line = raw_line if isinstance(raw_line, str) else raw_line.decode("utf-8", errors="replace")

        if line == "":
            # Blank line: dispatch the buffered event (if any).
            if data_lines:
                data_str = "\n".join(data_lines)
                try:
                    parsed: dict[str, Any] = json.loads(data_str)
                except (ValueError, json.JSONDecodeError):
                    parsed = {"_raw": data_str}
                yield event_name, parsed
            event_name = "message"
            data_lines = []
            continue

        if line.startswith(":"):
            # SSE comment / heartbeat — ignore.
            continue

        if line.startswith("event:"):
            event_name = line[len("event:") :].strip()
        elif line.startswith("data:"):
            data_lines.append(line[len("data:") :].lstrip())
        # Other fields (id:, retry:) are ignored.

    # Flush a trailing event if the stream ended without a blank line.
    if data_lines:
        data_str = "\n".join(data_lines)
        try:
            parsed = json.loads(data_str)
        except (ValueError, json.JSONDecodeError):
            parsed = {"_raw": data_str}
        yield event_name, parsed


async def parse_sse_events_async(
    response: httpx.Response,
) -> AsyncIterator[Tuple[str, dict[str, Any]]]:
    """Async twin of :func:`parse_sse_events` — yields events from an open
    streaming :class:`httpx.Response` opened by an :class:`httpx.AsyncClient`.
    """
    event_name = "message"
    data_lines: list[str] = []

    async for raw_line in response.aiter_lines():
        line = raw_line if isinstance(raw_line, str) else raw_line.decode("utf-8", errors="replace")

        if line == "":
            if data_lines:
                data_str = "\n".join(data_lines)
                try:
                    parsed: dict[str, Any] = json.loads(data_str)
                except (ValueError, json.JSONDecodeError):
                    parsed = {"_raw": data_str}
                yield event_name, parsed
            event_name = "message"
            data_lines = []
            continue

        if line.startswith(":"):
            continue

        if line.startswith("event:"):
            event_name = line[len("event:") :].strip()
        elif line.startswith("data:"):
            data_lines.append(line[len("data:") :].lstrip())

    if data_lines:
        data_str = "\n".join(data_lines)
        try:
            parsed = json.loads(data_str)
        except (ValueError, json.JSONDecodeError):
            parsed = {"_raw": data_str}
        yield event_name, parsed
