"""Async twin of ``_retry.post_with_retry``."""

from __future__ import annotations

import asyncio
import random
from typing import Any

import httpx

from ._retry import _classify_4xx  # reuse the typed-error mapping


async def post_with_retry_async(
    client: httpx.AsyncClient,
    url: str,
    *,
    json_body: dict[str, Any],
    headers: dict[str, str],
    max_retries: int = 4,
    backoff_base: float = 0.5,
    backoff_max: float = 30.0,
    timeout: float = 60.0,
) -> httpx.Response:
    """Async POST with retry-on-5xx-and-network. Raises on 4xx (no retry)."""
    last_exc: Exception | None = None
    last_response: httpx.Response | None = None

    for attempt in range(max_retries + 1):
        try:
            response = await client.post(
                url, json=json_body, headers=headers, timeout=timeout
            )
        except (httpx.NetworkError, httpx.TimeoutException) as exc:
            last_exc = exc
            if attempt >= max_retries:
                raise
            await _sleep_backoff(attempt, backoff_base, backoff_max)
            continue

        last_response = response

        if 200 <= response.status_code < 300:
            return response

        if 400 <= response.status_code < 500 and response.status_code not in (408, 425):
            raise _classify_4xx(response)

        if attempt >= max_retries:
            response.raise_for_status()
            return response  # not reached
        await _sleep_backoff(attempt, backoff_base, backoff_max)

    if last_response is not None:
        last_response.raise_for_status()
        return last_response  # not reached
    if last_exc is not None:
        raise last_exc
    raise RuntimeError("post_with_retry_async exhausted retries with no response")


async def _sleep_backoff(attempt: int, base: float, cap: float) -> None:
    sleep = min(cap, base * (2**attempt))
    jitter = random.uniform(0, sleep / 4)
    await asyncio.sleep(sleep + jitter)
