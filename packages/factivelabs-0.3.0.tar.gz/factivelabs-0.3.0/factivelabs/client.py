"""Public client class for the factivelabs SDK."""

from __future__ import annotations

import contextlib
import os
import queue
import threading
import time
from typing import Any, Callable, Iterable, Iterator, Mapping, Union

import httpx

from ._batch import build_batch_body
from ._corpus import CorpusFileInput, normalize_corpus_files
from ._extraction import build_file_body, build_url_body
from ._version import __version__
from .exceptions import AuthenticationError, FactiveError, QuotaExceededError, RateLimitError
from .streaming import stream_verify
from .types import (
    BatchSubmission,
    Claim,
    CorpusDocument,
    CorpusScope,
    ExtractedText,
    JobStatus,
    StreamEvent,
    StreamResult,
    VerifyResult,
)


DEFAULT_BASE_URL = "https://api.factivelabs.com"


class _NoopCloseClient:
    """Wrap an ``httpx.Client`` so that exiting a ``with`` block does NOT
    close it. Used inside :class:`FactiveClient` so per-method ``with``
    blocks can share a single client when the FactiveClient itself is in
    use as a context manager.
    """

    __slots__ = ("_inner",)

    def __init__(self, inner: httpx.Client) -> None:
        self._inner = inner

    def __enter__(self) -> httpx.Client:
        return self._inner

    def __exit__(self, *exc_info: Any) -> None:
        return None


class FactiveClient:
    """Synchronous client for the Factive fact-checking API.

    Two main entry points:

    * :meth:`verify_text` — one-shot fact-check of a static document or
      string. Sends one request, gets back a list of verified claims.
    * :meth:`verify_stream` — streaming fact-check of an in-progress LLM
      output. Buffers tokens into paragraphs, posts each paragraph
      atomically with retry, and surfaces verification events as they
      arrive.

    Args:
        api_key: Your Factive API key (starts with ``fk_...``).
        base_url: API root. Defaults to ``https://api.factivelabs.com``.
        timeout: Default HTTP timeout in seconds for one-shot requests.
        transport: Optional ``httpx.BaseTransport`` for testing or proxying.
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 300.0,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._transport = transport
        self._shared_client: httpx.Client | None = None
        # Sub-clients (namespaced for discoverability):
        self.corpus = _CorpusNamespace(self)

    # ── Context-manager support ──────────────────────────────────────────
    #
    # Optional. Use ``with FactiveClient(...) as client:`` to keep one
    # underlying HTTP connection open across many method calls (TCP +
    # TLS reuse, faster for tight loops). Outside a ``with`` block, every
    # method call still creates and tears down its own client.

    def __enter__(self) -> "FactiveClient":
        if self._shared_client is None:
            self._shared_client = self._make_raw_client()
        return self

    def __exit__(self, *exc_info: Any) -> None:
        if self._shared_client is not None:
            self._shared_client.close()
            self._shared_client = None

    def close(self) -> None:
        """Close the shared HTTP client if one is open. Safe to call repeatedly."""
        if self._shared_client is not None:
            self._shared_client.close()
            self._shared_client = None

    # ── Public API ────────────────────────────────────────────────────────

    def verify_text(
        self,
        text: str,
        *,
        context: str | None = None,
        profile: str | None = None,
        use_private_corpus: bool = False,
        corpus_scope: str | None = None,
        second_pass: bool | None = None,
    ) -> VerifyResult:
        """Synchronous one-shot fact-check of a static text document.

        Args:
            text: The document to fact-check.
            context: Optional surrounding context (e.g. user question).
            profile: Optional pipeline profile override.
            use_private_corpus: Route claims through the user's private corpus.
            corpus_scope: One-paragraph description of the corpus contents
                (improves routing accuracy when ``use_private_corpus=True``).
            second_pass: Optional override for the verifier's second-pass behavior.

        Returns:
            :class:`VerifyResult` containing parsed claims.
        """
        body: dict[str, Any] = {"text": text}
        if context:
            body["context"] = context
        if profile:
            body["profile"] = profile
        if use_private_corpus:
            body["use_private_corpus"] = True
            if corpus_scope:
                body["corpus_scope"] = corpus_scope
        if second_pass is not None:
            body["second_pass"] = second_pass

        with self._build_client() as client:
            response = client.post(
                f"{self.base_url}/api/v1/verify",
                json=body,
                headers=self._headers(),
                timeout=self.timeout,
            )

        self._raise_typed_error(response)
        response.raise_for_status()
        return VerifyResult.from_json(response.json())

    def verify_url(
        self,
        url: str,
        *,
        content_type: str | None = None,
        context: str | None = None,
        profile: str | None = None,
        use_private_corpus: bool = False,
        corpus_scope: str | None = None,
        second_pass: bool | None = None,
    ) -> VerifyResult:
        """Fact-check the contents of a URL.

        The SDK first calls ``/api/v1/extract-text`` to fetch and extract
        the URL's text, then ``/api/v1/verify`` to fact-check it. The
        returned :class:`VerifyResult` includes the extracted text in
        ``result.extracted_text`` and the document title in ``result.title``.

        Args:
            url: The URL to fetch. Web pages, YouTube, and TikTok all work.
            content_type: Override the SDK's URL-type auto-detection. One of
                ``"url"``, ``"youtube"``, ``"tiktok"``.
            context: Optional surrounding context for the verifier (e.g. user question).
            profile: Optional pipeline profile override.
            use_private_corpus: Route claims through the user's private corpus.
            corpus_scope: Description of the corpus when ``use_private_corpus=True``.
            second_pass: Optional override for verifier second-pass behavior.

        Returns:
            :class:`VerifyResult` with claims plus extracted text + title.
        """
        body = build_url_body(url, content_type=content_type)
        extracted = self._extract_text_via_api(body)
        verify_result = self.verify_text(
            extracted.text,
            context=context,
            profile=profile,
            use_private_corpus=use_private_corpus,
            corpus_scope=corpus_scope,
            second_pass=second_pass,
        )
        verify_result.extracted_text = extracted.text
        if not verify_result.title:
            verify_result.title = extracted.title or None
        return verify_result

    def verify_file(
        self,
        file: Union[str, bytes, "os.PathLike[str]"],
        *,
        content_type: str | None = None,
        filename: str | None = None,
        context: str | None = None,
        profile: str | None = None,
        use_private_corpus: bool = False,
        corpus_scope: str | None = None,
        second_pass: bool | None = None,
    ) -> VerifyResult:
        """Fact-check the contents of a PDF, Word, or image file.

        The SDK base64-encodes the file, posts it to ``/api/v1/extract-text``,
        then runs the extracted text through ``/api/v1/verify``.

        Args:
            file: Either a path (``str`` or ``pathlib.Path``) to a file on
                disk, or the raw bytes of the file already loaded into memory.
            content_type: Override extension-based detection. One of
                ``"pdf"``, ``"docx"``, ``"image"``.
            filename: Required only if ``file`` is bytes and ``content_type``
                is not provided — used to auto-detect content type from extension.
            context: Optional surrounding context for the verifier.
            profile: Optional pipeline profile override.
            use_private_corpus: Route claims through the user's private corpus.
            corpus_scope: Description of the corpus when ``use_private_corpus=True``.
            second_pass: Optional override for verifier second-pass behavior.

        Returns:
            :class:`VerifyResult` with claims plus extracted text + title.
        """
        body = build_file_body(file, content_type=content_type, filename=filename)
        extracted = self._extract_text_via_api(body)
        verify_result = self.verify_text(
            extracted.text,
            context=context,
            profile=profile,
            use_private_corpus=use_private_corpus,
            corpus_scope=corpus_scope,
            second_pass=second_pass,
        )
        verify_result.extracted_text = extracted.text
        if not verify_result.title:
            verify_result.title = extracted.title or None
        return verify_result

    def extract_text(
        self,
        *,
        url: str | None = None,
        file: Union[str, bytes, "os.PathLike[str]", None] = None,
        content_type: str | None = None,
        filename: str | None = None,
    ) -> ExtractedText:
        """Run only the text-extraction step (no fact-checking).

        Useful when you want to display extracted text in a UI before
        deciding whether to spend credits on verification, or when you
        want to cache extracted text for later.

        Pass exactly one of ``url=`` or ``file=``.
        """
        if url and file is not None:
            raise ValueError("Pass either url=... or file=..., not both.")
        if not url and file is None:
            raise ValueError("Pass url=... or file=...")
        if url:
            body = build_url_body(url, content_type=content_type)
        else:
            body = build_file_body(file, content_type=content_type, filename=filename)  # type: ignore[arg-type]
        return self._extract_text_via_api(body)

    # ── Batch API ─────────────────────────────────────────────────────────

    def submit_batch(
        self,
        items: list[Mapping[str, Any]],
        *,
        webhook_url: str | None = None,
    ) -> BatchSubmission:
        """Submit 1–100 documents for asynchronous fact-checking.

        Each item is a dict using exactly one of these convenience keys:

        * ``{"text": "..."}``                — plain text
        * ``{"url": "..."}``                 — webpage / YouTube / TikTok
        * ``{"file": "/path/x.pdf"}``        — file path or raw bytes

        Optional keys: ``content_type`` (override auto-detection),
        ``filename`` (when ``file`` is bytes), ``mode``, ``max_claims``,
        ``context``, ``profile``, ``use_private_corpus``, ``corpus_scope``.

        Args:
            items: 1–100 batch items.
            webhook_url: Optional URL the server POSTs each completed
                job's result to.

        Returns:
            :class:`BatchSubmission` with a ``job_id`` per item. Poll each
            via :meth:`get_job`, or call :meth:`wait_for_batch` to block.
        """
        body = build_batch_body(items, webhook_url=webhook_url)
        with self._build_client() as client:
            response = client.post(
                f"{self.base_url}/api/v1/verify/batch",
                json=body,
                headers=self._headers(),
                timeout=self.timeout,
            )
        self._raise_typed_error(response)
        response.raise_for_status()
        return BatchSubmission.from_json(response.json())

    def get_job(self, job_id: str) -> JobStatus:
        """Poll a single async job by its ID. See :meth:`submit_batch`."""
        with self._build_client() as client:
            response = client.get(
                f"{self.base_url}/api/v1/jobs/{job_id}",
                headers=self._headers(),
                timeout=self.timeout,
            )
        self._raise_typed_error(response)
        response.raise_for_status()
        return JobStatus.from_json(response.json())

    def wait_for_batch(
        self,
        submission: BatchSubmission,
        *,
        timeout: float = 600.0,
        poll_interval: float = 2.0,
        on_progress: Callable[[str, JobStatus], None] | None = None,
    ) -> dict[str, JobStatus]:
        """Block until every job in a batch reaches a terminal state.

        Returns a mapping ``{job_id: JobStatus}``. Raises
        :class:`FactiveError` if the timeout elapses while jobs are still
        running.

        Args:
            submission: The :class:`BatchSubmission` returned by
                :meth:`submit_batch`.
            timeout: Maximum total seconds to wait. Default 10 minutes.
            poll_interval: Seconds between polls per job.
            on_progress: Optional callback fired each time a job's status
                is updated. Useful for progress bars / log output.
        """
        deadline = time.monotonic() + timeout
        results: dict[str, JobStatus] = {}
        pending = {ref.job_id for ref in submission.jobs}

        while pending and time.monotonic() < deadline:
            for job_id in list(pending):
                status = self.get_job(job_id)
                results[job_id] = status
                if on_progress is not None:
                    try:
                        on_progress(job_id, status)
                    except Exception:
                        pass
                if status.is_done:
                    pending.discard(job_id)
            if pending:
                time.sleep(poll_interval)

        if pending:
            raise FactiveError(
                f"wait_for_batch timed out after {timeout:.0f}s with "
                f"{len(pending)} job(s) still running: {sorted(pending)}"
            )
        return results

    def verify_stream(
        self,
        token_iterator: Iterable[str],
        *,
        context: str | None = None,
        profile: str | None = None,
        use_private_corpus: bool = False,
        corpus_scope: str | None = None,
        second_pass: bool | None = None,
        on_token: Callable[[str], None] | None = None,
        on_paragraph_sent: Callable[[str], None] | None = None,
        on_claim: Callable[[Claim], None] | None = None,
        on_event: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> StreamResult:
        """Stream LLM tokens through the fact-checker.

        Hand this method any iterable of strings (an LLM streaming-token
        generator is the canonical input). The SDK buffers tokens until
        a paragraph break is reached, posts each complete paragraph
        atomically to the API with retry, and collects verified claims
        as they come back.

        Args:
            token_iterator: Iterable of token strings produced by an LLM
                or any other streaming source. Whitespace and the
                paragraph-break separator (``\\n\\n``) are honored as-is.
            context: Optional surrounding context (e.g. the user's prompt).
            profile: Optional pipeline profile override.
            use_private_corpus: Route claims through the user's private corpus.
            corpus_scope: Description of the corpus when ``use_private_corpus=True``.
            second_pass: Optional override for verifier second-pass behavior.
            on_token: Called for every token as it arrives, from the
                main thread (where ``token_iterator`` runs). Use this to
                surface tokens to your UI in real time.
            on_paragraph_sent: Called once per paragraph after a successful
                POST. Fires from the main thread.
            on_claim: Called for each verified claim as soon as the API
                streams it back. **Fires from a background SSE-reader
                thread** — use thread-safe state (``queue.Queue``, locks)
                if you also mutate shared data from ``on_token``.
            on_event: Low-level hook — called for every SSE event with
                ``(event_name, data_dict)``. **Also fires from the
                background SSE-reader thread.**

        Returns:
            :class:`StreamResult`. Check ``result.byte_equality`` to
            confirm every byte sent was received and processed.
        """
        with self._build_client() as client:
            return stream_verify(
                http=client,
                base_url=self.base_url,
                headers=self._headers(),
                token_iterator=token_iterator,
                context=context,
                profile=profile,
                use_private_corpus=use_private_corpus,
                corpus_scope=corpus_scope,
                second_pass=second_pass,
                on_token=on_token,
                on_paragraph_sent=on_paragraph_sent,
                on_claim=on_claim,
                on_event=on_event,
            )

    def verify_stream_events(
        self,
        token_iterator: Iterable[str],
        *,
        context: str | None = None,
        profile: str | None = None,
        use_private_corpus: bool = False,
        corpus_scope: str | None = None,
        second_pass: bool | None = None,
    ) -> Iterator[StreamEvent]:
        """Iterator-style streaming verify — yields :class:`StreamEvent`
        objects as they happen.

        Better fit than :meth:`verify_stream`'s callback API when you're
        plumbing the events into a streaming HTTP response or otherwise
        need a generator-shaped iterator.

        Example::

            for ev in client.verify_stream_events(my_llm_tokens):
                if ev.type == "token":
                    print(ev.text, end="", flush=True)
                elif ev.type == "claim":
                    print("\\n→", ev.claim.verdict, ev.claim.text)
                elif ev.type == "done":
                    print("byte equality:", ev.result.byte_equality)

        Internally this runs :meth:`verify_stream` in a worker thread
        whose callbacks push :class:`StreamEvent` instances into a
        ``queue.Queue`` that the iterator drains. Any exception raised by
        the underlying call is re-raised on the caller's thread once the
        iterator is exhausted.
        """
        q: "queue.Queue[StreamEvent | Exception | object]" = queue.Queue()
        SENTINEL = object()

        def worker() -> None:
            try:
                result = self.verify_stream(
                    token_iterator,
                    context=context,
                    profile=profile,
                    use_private_corpus=use_private_corpus,
                    corpus_scope=corpus_scope,
                    second_pass=second_pass,
                    on_token=lambda t: q.put(StreamEvent(type="token", text=t)),
                    on_paragraph_sent=lambda p: q.put(
                        StreamEvent(type="paragraph_sent", text=p)
                    ),
                    on_claim=lambda c: q.put(StreamEvent(type="claim", claim=c)),
                    on_event=lambda n, d: q.put(
                        StreamEvent(type="event", name=n, data=d)
                    ),
                )
                q.put(StreamEvent(type="done", result=result))
            except Exception as exc:
                q.put(exc)
            finally:
                q.put(SENTINEL)

        thread = threading.Thread(
            target=worker, daemon=True, name="factivelabs-events-worker"
        )
        thread.start()

        try:
            while True:
                item = q.get()
                if item is SENTINEL:
                    break
                if isinstance(item, Exception):
                    raise item
                yield item  # type: ignore[misc]
        finally:
            thread.join(timeout=5.0)

    # ── Internal helpers ──────────────────────────────────────────────────

    def _extract_text_via_api(self, body: dict[str, Any]) -> ExtractedText:
        """POST to /api/v1/extract-text and return the parsed result."""
        with self._build_client() as client:
            response = client.post(
                f"{self.base_url}/api/v1/extract-text",
                json=body,
                headers=self._headers(),
                timeout=self.timeout,
            )
        self._raise_typed_error(response)
        response.raise_for_status()
        return ExtractedText.from_json(response.json())

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": f"factivelabs-python/{__version__}",
        }

    def _make_raw_client(self) -> httpx.Client:
        kwargs: dict[str, Any] = {"timeout": self.timeout}
        if self._transport is not None:
            kwargs["transport"] = self._transport
        return httpx.Client(**kwargs)

    def _build_client(self):
        """Return a context manager that yields an ``httpx.Client``.

        If we're inside a ``with FactiveClient(...) as c:`` block, the
        same client is reused across every method call (and not closed
        on per-method exit). Otherwise each call gets a fresh client.
        """
        if self._shared_client is not None:
            return _NoopCloseClient(self._shared_client)
        return self._make_raw_client()

    def _raise_typed_error(self, response: httpx.Response) -> None:
        if response.status_code == 401:
            raise AuthenticationError(
                "Invalid or missing API key (HTTP 401). "
                "Pass api_key=... to FactiveClient(...)."
            )
        if response.status_code == 402:
            detail: dict[str, Any] = {}
            try:
                detail = response.json().get("detail", {}) or {}
            except Exception:
                pass
            raise QuotaExceededError(
                detail.get("message") or "Credit quota exceeded",
                detail=detail,
            )
        if response.status_code == 429:
            ra = response.headers.get("retry-after")
            try:
                retry_after = float(ra) if ra else None
            except ValueError:
                retry_after = None
            raise RateLimitError(retry_after=retry_after)


# ── Sub-client: private corpus management ──────────────────────────────────


class _CorpusNamespace:
    """Methods for managing the customer's private corpus.

    Reached as ``client.corpus.*``. Wraps ``/api/v1/private-corpus/*``.
    """

    _BASE_PATH = "/api/v1/private-corpus"

    def __init__(self, parent: "FactiveClient") -> None:
        self._p = parent

    def upload(self, files: Iterable[CorpusFileInput]) -> dict[str, Any]:
        """Upload 1–10 documents to the private corpus.

        Each ``file`` may be a path (``str`` / ``Path``), or a tuple of
        ``(filename, raw_bytes)`` / ``(filename, raw_bytes, content_type)``.

        Returns the API's ``{"queued": [...], "failed": [...]}`` response.
        Ingestion runs server-side in the background — poll :meth:`list`
        to watch documents move from ``queued`` → ``processing`` →
        ``embedding`` → ``ready``.
        """
        normalized = normalize_corpus_files(files)
        with self._p._build_client() as client:
            # Multipart upload — httpx handles the encoding from `files=`.
            response = client.post(
                f"{self._p.base_url}{self._BASE_PATH}/upload",
                files=normalized,
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        return response.json()

    def list(self) -> list[CorpusDocument]:
        """List every document currently in the customer's corpus."""
        with self._p._build_client() as client:
            response = client.get(
                f"{self._p.base_url}{self._BASE_PATH}",
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        payload = response.json()
        docs = payload.get("docs") or []
        return [CorpusDocument.from_json(d) for d in docs]

    def delete(self, doc_id: str) -> None:
        """Delete one document by its ID. Raises if not found."""
        with self._p._build_client() as client:
            response = client.delete(
                f"{self._p.base_url}{self._BASE_PATH}/{doc_id}",
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()

    def clear(self, *, confirm: bool = False) -> int:
        """Wipe the entire corpus. ``confirm=True`` is required.

        Returns the number of documents deleted.
        """
        if not confirm:
            raise ValueError(
                "corpus.clear() refuses to wipe without explicit confirmation. "
                "Pass confirm=True to delete every document."
            )
        with self._p._build_client() as client:
            response = client.post(
                f"{self._p.base_url}{self._BASE_PATH}/clear",
                data={"confirm": "true"},
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        return int(response.json().get("deleted_count") or 0)

    def get_scope(self) -> CorpusScope:
        """Return the current corpus scope description and metadata."""
        with self._p._build_client() as client:
            response = client.get(
                f"{self._p.base_url}{self._BASE_PATH}/scope",
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        return CorpusScope.from_json(response.json())

    def update_scope(self, scope_text: str) -> CorpusScope:
        """Save a customer-edited scope description (max 2,000 chars).

        Note: the next document add or remove auto-regenerates the scope
        and overwrites the manual edit (per design choice 2026-05-03).
        """
        with self._p._build_client() as client:
            response = client.put(
                f"{self._p.base_url}{self._BASE_PATH}/scope",
                json={"scope_text": scope_text},
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        return CorpusScope.from_json(response.json())

    def regenerate_scope(self) -> CorpusScope:
        """Manually trigger a scope regeneration. Returns the current row;
        the regeneration runs in the background server-side.
        """
        with self._p._build_client() as client:
            response = client.post(
                f"{self._p.base_url}{self._BASE_PATH}/scope/regenerate",
                headers=self._p._headers(),
                timeout=self._p.timeout,
            )
        self._p._raise_typed_error(response)
        response.raise_for_status()
        return CorpusScope.from_json(response.json())
