"""Helpers for building batch-submit request bodies.

Customers pass simple dicts to ``submit_batch``. This module normalizes
each dict into the canonical ``BatchItem`` shape the API expects:
``{content|url|file, content_type, ...}``.
"""

from __future__ import annotations

import base64
import os
from pathlib import Path
from typing import Any, Mapping, Union

from ._extraction import detect_file_content_type, detect_url_content_type


_OPTIONAL_PASSTHROUGH_KEYS = {
    "mode",
    "max_claims",
    "context",
    "callback_metadata",
    "profile",
    "use_private_corpus",
    "corpus_scope",
    "second_pass",
}


def normalize_batch_item(item: Mapping[str, Any]) -> dict[str, Any]:
    """Turn a customer-friendly batch-item dict into the API's expected shape.

    Recognized convenience keys (use exactly one):

    * ``text=...``                 → plain text
    * ``url=...``                  → URL (``content_type`` auto-detected for YouTube/TikTok)
    * ``file=`` (path or bytes)    → file upload (base64-encoded, ``content_type`` auto-detected)

    Optional passthrough keys: ``mode``, ``max_claims``, ``context``,
    ``callback_metadata``, ``profile``, ``use_private_corpus``,
    ``corpus_scope``, ``second_pass``, ``content_type`` (override
    auto-detection), ``filename`` (used for ``content_type`` detection
    when ``file`` is bytes).
    """
    if not isinstance(item, Mapping):
        raise TypeError(
            f"Each batch item must be a dict-like mapping, got {type(item).__name__}"
        )

    convenience_keys = [k for k in ("text", "url", "file") if item.get(k) is not None]
    if len(convenience_keys) != 1:
        raise ValueError(
            f"Each batch item must have exactly one of 'text', 'url', or 'file' "
            f"(got: {convenience_keys or 'none'})"
        )

    out: dict[str, Any] = {}
    explicit_ct = item.get("content_type")
    filename = item.get("filename")

    key = convenience_keys[0]
    if key == "text":
        out["content"] = str(item["text"])
        out["content_type"] = explicit_ct or "text"
    elif key == "url":
        out["url"] = str(item["url"])
        out["content_type"] = explicit_ct or detect_url_content_type(out["url"])
    else:  # file
        file_value = item["file"]
        if isinstance(file_value, (bytes, bytearray)):
            raw_bytes = bytes(file_value)
            if explicit_ct is None and filename is None:
                raise ValueError(
                    "When passing raw bytes as 'file' you must also pass either "
                    "'content_type' or 'filename'."
                )
            ct = explicit_ct or detect_file_content_type(filename or "")
        else:
            path = Path(os.fspath(file_value))
            if not path.exists():
                raise FileNotFoundError(f"Batch file not found: {path}")
            raw_bytes = path.read_bytes()
            ct = explicit_ct or detect_file_content_type(path.name)

        if ct not in {"pdf", "docx", "image"}:
            raise ValueError(
                f"content_type for a file must be one of 'pdf', 'docx', 'image' (got '{ct}')"
            )
        out["file"] = base64.b64encode(raw_bytes).decode("ascii")
        out["content_type"] = ct

    for passthrough in _OPTIONAL_PASSTHROUGH_KEYS:
        if passthrough in item and item[passthrough] is not None:
            out[passthrough] = item[passthrough]

    return out


def build_batch_body(
    items: list[Mapping[str, Any]],
    *,
    webhook_url: str | None = None,
) -> dict[str, Any]:
    """Build the full ``POST /api/v1/verify/batch`` body."""
    if not items:
        raise ValueError("Batch must contain at least one item.")
    body: dict[str, Any] = {"items": [normalize_batch_item(it) for it in items]}
    if webhook_url:
        body["webhook_url"] = webhook_url
    return body
