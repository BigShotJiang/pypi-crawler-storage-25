"""Public dataclasses returned to the caller."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Claim:
    """A single fact-checked claim."""

    claim_id: int | str | None
    text: str
    verdict: str  # "confirmed" | "disputed" | "unclear" | "skipped"
    summary: str = ""
    explanation: str = ""
    sources: list[dict[str, Any]] = field(default_factory=list)
    paragraph_text: str = ""
    skipped: bool = False
    context_flags: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_event_data(cls, data: dict[str, Any]) -> "Claim":
        """Build a Claim from a `claim_verified` SSE event payload."""
        # The server emits the claim under several shapes depending on path.
        # Be liberal in what we accept.
        claim_dict = data.get("claim") if isinstance(data.get("claim"), dict) else data
        return cls(
            claim_id=claim_dict.get("claim_id") or claim_dict.get("id"),
            text=claim_dict.get("text") or claim_dict.get("claim_text") or "",
            verdict=claim_dict.get("verdict") or "unknown",
            summary=claim_dict.get("summary") or "",
            explanation=claim_dict.get("explanation") or "",
            sources=claim_dict.get("sources") or [],
            paragraph_text=claim_dict.get("paragraph_text") or claim_dict.get("para_text") or "",
            skipped=bool(claim_dict.get("skipped")),
            context_flags=claim_dict.get("context_flags") or {},
            raw=claim_dict,
        )


@dataclass
class StreamResult:
    """Returned by `client.verify_stream(...)` after the stream completes."""

    session_id: str
    chars_sent: int
    chars_received: int
    paragraphs_sent: int
    claims: list[Claim] = field(default_factory=list)
    complete: bool = False
    final_event: dict[str, Any] | None = None

    @property
    def byte_equality(self) -> bool:
        """True if every byte we sent was confirmed received by the API.

        If False, at least one paragraph was dropped or rejected and the
        caller should treat the result as incomplete.
        """
        return self.chars_sent == self.chars_received and self.complete

    @property
    def confirmed(self) -> list[Claim]:
        return [c for c in self.claims if c.verdict == "confirmed"]

    @property
    def disputed(self) -> list[Claim]:
        return [c for c in self.claims if c.verdict == "disputed"]

    @property
    def unclear(self) -> list[Claim]:
        return [c for c in self.claims if c.verdict == "unclear"]

    @property
    def skipped(self) -> list[Claim]:
        return [c for c in self.claims if c.skipped or c.verdict == "skipped"]


@dataclass
class VerifyResult:
    """Returned by ``verify_text`` / ``verify_url`` / ``verify_file``."""

    claims: list[Claim] = field(default_factory=list)
    title: str | None = None
    counts: dict[str, int] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)
    extracted_text: str | None = None
    """Populated by ``verify_url`` / ``verify_file``: the plain text the
    server extracted before fact-checking. Useful for caching or display."""

    @classmethod
    def from_json(cls, payload: dict[str, Any]) -> "VerifyResult":
        claims_raw = payload.get("claims") or []
        return cls(
            claims=[Claim.from_event_data({"claim": c}) for c in claims_raw],
            title=payload.get("title"),
            counts=payload.get("counts") or {},
            raw=payload,
        )

    @property
    def confirmed(self) -> list[Claim]:
        return [c for c in self.claims if c.verdict == "confirmed"]

    @property
    def disputed(self) -> list[Claim]:
        return [c for c in self.claims if c.verdict == "disputed"]

    @property
    def unclear(self) -> list[Claim]:
        return [c for c in self.claims if c.verdict == "unclear"]

    @property
    def skipped(self) -> list[Claim]:
        return [c for c in self.claims if c.skipped or c.verdict == "skipped"]


@dataclass
class BatchJobRef:
    """One row in a batch submission response."""

    index: int
    job_id: str
    status: str = "queued"
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class BatchSubmission:
    """Returned by ``client.submit_batch(...)``."""

    batch_id: str
    total: int
    jobs: list[BatchJobRef] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_json(cls, payload: dict[str, Any]) -> "BatchSubmission":
        jobs = [
            BatchJobRef(
                index=int(j.get("index") or 0),
                job_id=j.get("job_id") or "",
                status=j.get("status") or "queued",
                raw=j,
            )
            for j in payload.get("jobs") or []
        ]
        return cls(
            batch_id=payload.get("batch_id") or "",
            total=int(payload.get("total") or len(jobs)),
            jobs=jobs,
            raw=payload,
        )


@dataclass
class JobStatus:
    """Returned by ``client.get_job(job_id)``."""

    id: str
    status: str  # "queued" | "running" | "complete" | "failed"
    progress: dict[str, Any] = field(default_factory=dict)
    result: VerifyResult | None = None
    created_at: str = ""
    completed_at: str | None = None
    error: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def is_complete(self) -> bool:
        return self.status == "complete"

    @property
    def is_failed(self) -> bool:
        return self.status == "failed"

    @property
    def is_done(self) -> bool:
        return self.status in {"complete", "failed"}

    @classmethod
    def from_json(cls, payload: dict[str, Any]) -> "JobStatus":
        result_payload = payload.get("result")
        verified: VerifyResult | None = None
        if isinstance(result_payload, dict):
            verified = VerifyResult.from_json(result_payload)
        return cls(
            id=payload.get("id") or "",
            status=payload.get("status") or "",
            progress=payload.get("progress") or {},
            result=verified,
            created_at=payload.get("created_at") or "",
            completed_at=payload.get("completed_at"),
            error=payload.get("error_message") or payload.get("error"),
            raw=payload,
        )


@dataclass
class CorpusDocument:
    """A document in a customer's private corpus."""

    doc_id: str
    file_name: str
    file_type: str
    status: str  # queued | processing | embedding | ready | error
    chunk_count: int = 0
    char_count: int = 0
    created_at: str = ""
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_json(cls, payload: dict[str, Any]) -> "CorpusDocument":
        return cls(
            doc_id=payload.get("doc_id") or payload.get("id") or "",
            file_name=payload.get("file_name") or "",
            file_type=payload.get("file_type") or "",
            status=payload.get("status") or "",
            chunk_count=int(payload.get("chunk_count") or 0),
            char_count=int(payload.get("char_count") or 0),
            created_at=payload.get("created_at") or "",
            raw=payload,
        )


@dataclass
class CorpusScope:
    """Customer's corpus scope description (auto-generated or user-edited)."""

    scope_text: str = ""
    status: str = "idle"  # idle | regenerating | error
    edited_by_user: bool = False
    generated_at: str | None = None
    last_error: str | None = None
    updated_at: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_json(cls, payload: dict[str, Any]) -> "CorpusScope":
        return cls(
            scope_text=payload.get("scope_text") or "",
            status=payload.get("status") or "idle",
            edited_by_user=bool(payload.get("edited_by_user")),
            generated_at=payload.get("generated_at"),
            last_error=payload.get("last_error"),
            updated_at=payload.get("updated_at"),
            raw=payload,
        )


@dataclass
class StreamEvent:
    """One event yielded by ``client.verify_stream_events(...)``.

    The ``type`` field is a tag — exactly one of the optional fields will
    be populated for each event type:

    * ``type="token"``           → ``text`` set
    * ``type="paragraph_sent"``  → ``text`` set (the paragraph that was POSTed)
    * ``type="claim"``           → ``claim`` set
    * ``type="event"``           → ``name`` and ``data`` set (low-level SSE event)
    * ``type="done"``            → ``result`` set (the final :class:`StreamResult`)

    A typical loop::

        for ev in client.verify_stream_events(my_tokens):
            if ev.type == "token":
                print(ev.text, end="", flush=True)
            elif ev.type == "claim":
                print("\\n→", ev.claim.verdict, ev.claim.text)
            elif ev.type == "done":
                if not ev.result.byte_equality:
                    log.warning("byte mismatch")
    """

    type: str
    text: str | None = None
    claim: Claim | None = None
    name: str | None = None
    data: dict[str, Any] | None = None
    result: StreamResult | None = None


@dataclass
class ExtractedText:
    """Returned by ``client.extract_text(...)`` — plain text only."""

    text: str
    title: str = ""
    char_count: int = 0
    input_type: str = ""
    id: str = ""
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_json(cls, payload: dict[str, Any]) -> "ExtractedText":
        return cls(
            text=payload.get("text") or "",
            title=payload.get("title") or "",
            char_count=int(payload.get("char_count") or 0),
            input_type=payload.get("input_type") or "",
            id=payload.get("id") or "",
            raw=payload,
        )
