"""factivelabs — Python SDK for the Factive fact-checking API.

Quickstart::

    from factivelabs import FactiveClient

    client = FactiveClient(api_key="fk_...")

    # Stream an LLM's output through the fact-checker as it generates:
    result = client.verify_stream(
        my_llm_stream(),                       # any iterable of token strings
        context="What were Q4 hiring numbers?",
        on_token=lambda t: print(t, end="", flush=True),
        on_claim=lambda c: print(f"\\n[{c.verdict}] {c.text}"),
    )

    if not result.byte_equality:
        print(f"WARNING: only {result.chars_received}/{result.chars_sent} chars confirmed")
"""

from ._version import __version__
from .async_client import AsyncFactiveClient
from .client import FactiveClient
from .exceptions import (
    AuthenticationError,
    FactiveError,
    ParagraphRejectedError,
    QuotaExceededError,
    RateLimitError,
    StreamError,
    StreamTimeoutError,
)
from .types import (
    BatchJobRef,
    BatchSubmission,
    Claim,
    CorpusDocument,
    CorpusScope,
    ExtractedText,
    JobStatus,
    StreamEvent,
    StreamResult,
    VerifyResult,
)

__all__ = [
    "__version__",
    "FactiveClient",
    "AsyncFactiveClient",
    "Claim",
    "ExtractedText",
    "StreamEvent",
    "StreamResult",
    "VerifyResult",
    "BatchSubmission",
    "BatchJobRef",
    "JobStatus",
    "CorpusDocument",
    "CorpusScope",
    "FactiveError",
    "AuthenticationError",
    "QuotaExceededError",
    "RateLimitError",
    "ParagraphRejectedError",
    "StreamError",
    "StreamTimeoutError",
]
