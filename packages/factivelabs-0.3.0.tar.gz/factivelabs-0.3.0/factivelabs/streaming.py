"""Streaming verifier — buffers an LLM token iterator into paragraphs and
posts each paragraph to the stateless /verify/paragraph endpoint.

As of factivelabs 0.3.0, this implementation no longer opens a long-lived
SSE session. Each paragraph POST is a single, self-contained HTTP request
that returns the verified claims as JSON. This removes the worker-affinity
concerns of the previous design (see DEVLOG 2026-05-04 PM late for the
byte-loss bug that motivated the redesign).

The public API of FactiveClient.verify_stream is unchanged — same
arguments, same StreamResult shape, same callbacks. Only the wire
protocol underneath changes.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Iterable

import httpx

from ._buffer import ParagraphBuffer
from ._retry import post_with_retry
from .exceptions import StreamError
from .types import Claim, StreamResult

logger = logging.getLogger(__name__)


def stream_verify(
    *,
    http: httpx.Client,
    base_url: str,
    headers: dict[str, str],
    token_iterator: Iterable[str],
    context: str | None,
    profile: str | None,
    use_private_corpus: bool,
    corpus_scope: str | None,
    second_pass: bool | None,
    on_token: Callable[[str], None] | None,
    on_paragraph_sent: Callable[[str], None] | None,
    on_claim: Callable[[Claim], None] | None,
    on_event: Callable[[str, dict[str, Any]], None] | None,
) -> StreamResult:
    """Buffer tokens, POST each paragraph to /verify/paragraph, accumulate results.

    Internal — called from FactiveClient.verify_stream.
    """
    buf = ParagraphBuffer()
    chars_sent = 0
    chars_received = 0
    paragraphs_sent = 0
    claims_collected: list[Claim] = []
    last_paragraph_id = ""
    final_payload: dict[str, Any] = {}

    paragraph_url = f"{base_url}/api/v1/verify/paragraph"

    def _build_body(paragraph_text: str) -> dict[str, Any]:
        body: dict[str, Any] = {"text": paragraph_text}
        if context:
            body["context"] = context
        if profile:
            body["profile"] = profile
        if use_private_corpus:
            body["use_private_corpus"] = True
            if corpus_scope:
                body["corpus_scope"] = corpus_scope
        if second_pass is not None:
            body["second_pass"] = second_pass
        return body

    def _send(paragraph: str) -> None:
        nonlocal chars_sent, chars_received, paragraphs_sent, last_paragraph_id, final_payload

        if not paragraph or not paragraph.strip():
            # Don't waste a round-trip on a whitespace-only paragraph.
            return

        body = _build_body(paragraph)
        response = post_with_retry(
            http,
            paragraph_url,
            json_body=body,
            headers=headers,
            max_retries=4,
            timeout=120.0,
        )

        try:
            payload: dict[str, Any] = response.json()
        except Exception as exc:
            raise StreamError(
                f"Server returned non-JSON response to /verify/paragraph: {exc}"
            )

        chars_sent += len(paragraph)
        chars_received += int(payload.get("chars_received") or 0)
        paragraphs_sent += 1
        last_paragraph_id = payload.get("paragraph_id") or last_paragraph_id
        final_payload = payload

        if on_paragraph_sent is not None:
            try:
                on_paragraph_sent(paragraph)
            except Exception:
                logger.exception("on_paragraph_sent callback raised; continuing")

        # Fire a synthetic 'paragraph_received' event for callers using
        # the low-level on_event hook.
        if on_event is not None:
            try:
                on_event("paragraph_received", payload)
            except Exception:
                logger.exception("on_event callback raised; continuing")

        # Stream each claim through on_claim as if it had arrived
        # individually — preserves v0.2 behavior for callers that iterate
        # claims as they come back.
        for raw_claim in payload.get("claims") or []:
            try:
                claim = Claim.from_event_data({"claim": raw_claim})
            except Exception:
                logger.exception("Failed to parse claim record; skipping")
                continue
            claims_collected.append(claim)
            if on_claim is not None:
                try:
                    on_claim(claim)
                except Exception:
                    logger.exception("on_claim callback raised; continuing")
            if on_event is not None:
                try:
                    on_event("claim_verified", {"claim": raw_claim})
                except Exception:
                    logger.exception("on_event callback raised; continuing")

    # Drive the iterator.
    for token in token_iterator:
        if not isinstance(token, str):
            token = str(token)
        if on_token is not None:
            try:
                on_token(token)
            except Exception:
                logger.exception("on_token callback raised; continuing")
        for complete_paragraph in buf.add(token):
            _send(complete_paragraph)

    # Flush any remaining buffered text as a final paragraph.
    tail = buf.flush()
    if tail:
        _send(tail + "\n\n")

    if on_event is not None:
        try:
            on_event(
                "complete",
                {
                    "chars_sent": chars_sent,
                    "chars_received": chars_received,
                    "paragraphs_sent": paragraphs_sent,
                },
            )
        except Exception:
            logger.exception("on_event callback raised; continuing")

    return StreamResult(
        session_id=last_paragraph_id,  # back-compat: was session id, now last paragraph id
        chars_sent=chars_sent,
        chars_received=chars_received,
        paragraphs_sent=paragraphs_sent,
        claims=list(claims_collected),
        complete=True,
        final_event=final_payload or None,
    )
