"""Token-stream paragraph buffer.

Accumulates incoming tokens and yields complete paragraphs whenever a
paragraph break (``\\n\\n``) is detected. The buffer never emits a
sub-paragraph: each emitted paragraph is a complete, self-contained
unit per the API's ``/paragraph`` contract.
"""

from __future__ import annotations


class ParagraphBuffer:
    """Accumulate tokens until a paragraph break appears."""

    def __init__(self) -> None:
        self._buf: list[str] = []
        self._chars_in: int = 0

    def add(self, token: str) -> list[str]:
        """Append a token. Return a list of any complete paragraphs ready to send.

        Each returned paragraph includes its trailing ``\\n\\n`` (per the
        API contract) and has non-whitespace content. Whitespace-only
        runs between paragraph breaks are dropped.
        """
        if not token:
            return []
        self._buf.append(token)
        self._chars_in += len(token)
        return self._flush_complete()

    def _flush_complete(self) -> list[str]:
        joined = "".join(self._buf)
        if "\n\n" not in joined:
            return []
        parts = joined.split("\n\n")
        # All but the last element are complete paragraphs; the last is
        # the in-progress tail that we hold onto until the next break.
        complete_raw = parts[:-1]
        tail = parts[-1]
        # Reset internal buffer to just the tail.
        self._buf = [tail] if tail else []
        # Drop empty / whitespace-only paragraphs and reattach the
        # paragraph-break suffix to each surviving paragraph.
        return [p + "\n\n" for p in complete_raw if p.strip()]

    def flush(self) -> str | None:
        """Return any remaining content as a single final paragraph.

        Returns ``None`` if the buffer is empty or whitespace-only.
        Resets the internal state.
        """
        joined = "".join(self._buf).strip()
        self._buf = []
        return joined or None

    @property
    def chars_consumed(self) -> int:
        """Total characters fed into ``add()`` over the buffer's lifetime."""
        return self._chars_in
