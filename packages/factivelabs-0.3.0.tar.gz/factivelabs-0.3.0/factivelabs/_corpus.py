"""Helpers for building Private Corpus upload requests.

The corpus upload endpoint takes multipart form data. Customers pass
either paths or ``(filename, bytes)`` tuples; this module turns those
into the ``files=`` shape ``httpx`` expects.
"""

from __future__ import annotations

import mimetypes
import os
from pathlib import Path
from typing import Iterable, Tuple, Union


# What the SDK accepts as "a file to upload".
CorpusFileInput = Union[
    str,                       # path
    "os.PathLike[str]",        # pathlib.Path, etc.
    Tuple[str, bytes],         # (filename, raw_bytes)
    Tuple[str, bytes, str],    # (filename, raw_bytes, content_type)
]


def normalize_corpus_files(
    files: Iterable[CorpusFileInput],
) -> list[Tuple[str, Tuple[str, bytes, str]]]:
    """Normalize a heterogeneous ``files`` argument into ``httpx``'s
    ``files=[("files", (filename, fileobj, content_type)), ...]`` shape.
    """
    out: list[Tuple[str, Tuple[str, bytes, str]]] = []
    for item in files:
        if isinstance(item, tuple):
            if len(item) == 2:
                filename, raw = item
                ct = mimetypes.guess_type(filename)[0] or "application/octet-stream"
            elif len(item) == 3:
                filename, raw, ct = item
            else:
                raise ValueError(
                    f"File tuple must be (filename, bytes) or (filename, bytes, content_type), "
                    f"got tuple of length {len(item)}"
                )
            if not isinstance(raw, (bytes, bytearray)):
                raise TypeError(
                    f"File tuple's second element must be bytes, got {type(raw).__name__}"
                )
            out.append(("files", (filename, bytes(raw), ct)))
        else:
            path = Path(os.fspath(item))
            if not path.exists():
                raise FileNotFoundError(f"Corpus file not found: {path}")
            ct = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            out.append(("files", (path.name, path.read_bytes(), ct)))
    if not out:
        raise ValueError("At least one file must be provided to corpus.upload().")
    return out
