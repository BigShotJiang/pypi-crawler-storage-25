"""Tests for AgentDrop.list_agents() method.

TDD: Tests written BEFORE implementation.
Covers: response structure, empty state, field mapping, error handling.

Parity goal: match Node SDK's listAgents() shape, keyed snake_case to match
the API response directly (Python idiom, consistent with list_connections).
"""

from unittest.mock import patch

import pytest

from agentdrop.client import AgentDrop, AgentDropError


# ── Fixtures ──────────────────────────────────────────────────────────

def _make_client(**overrides) -> AgentDrop:
    """Build an AgentDrop client with mocked config loading."""
    defaults = dict(
        api_key="agd_test_key",
        agent_id="test-agent",
        agent_uuid="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
        shield=False,
        config_dir="/tmp/agentdrop_test_nonexistent",
    )
    defaults.update(overrides)
    with patch.object(AgentDrop, "_load_config"):
        return AgentDrop(**defaults)


FULL_RESPONSE = {
    "agents": [
        {
            "id": "uuid-1",
            "agent_id": "claude-main-pc",
            "name": "Claude Main PC",
            "description": None,
            "webhook_url": None,
            "agent_type": "custom",
            "connection_status": "connected",
            "key_version": 1,
            "last_seen_at": "2026-04-19T10:00:00Z",
            "metadata": None,
            "created_at": "2026-04-01T00:00:00Z",
        },
        {
            "id": "uuid-2",
            "agent_id": "giany-marketing",
            "name": "Giany Marketing",
            "description": "Marketing agent for campaigns",
            "webhook_url": None,
            "agent_type": "custom",
            "connection_status": "connected",
            "key_version": 1,
            "last_seen_at": None,
            "metadata": {"team": "marketing"},
            "created_at": "2026-04-19T11:00:00Z",
        },
    ],
}

EMPTY_RESPONSE = {"agents": []}


# ── Tests ─────────────────────────────────────────────────────────────

class TestListAgents:
    """Tests for list_agents()."""

    @patch.object(AgentDrop, "_request")
    def test_returns_list_of_agents(self, mock_request):
        """Full response with two agents is returned unwrapped as a list."""
        mock_request.return_value = FULL_RESPONSE
        client = _make_client()

        result = client.list_agents()

        assert isinstance(result, list)
        assert len(result) == 2

    @patch.object(AgentDrop, "_request")
    def test_agent_fields_preserved(self, mock_request):
        """Each agent dict preserves all API fields in snake_case."""
        mock_request.return_value = FULL_RESPONSE
        client = _make_client()

        result = client.list_agents()

        first = result[0]
        assert first["id"] == "uuid-1"
        assert first["agent_id"] == "claude-main-pc"
        assert first["name"] == "Claude Main PC"
        assert first["agent_type"] == "custom"
        assert first["connection_status"] == "connected"
        assert first["key_version"] == 1
        assert first["last_seen_at"] == "2026-04-19T10:00:00Z"
        assert first["created_at"] == "2026-04-01T00:00:00Z"

    @patch.object(AgentDrop, "_request")
    def test_metadata_preserved(self, mock_request):
        """Metadata dict passes through untouched."""
        mock_request.return_value = FULL_RESPONSE
        client = _make_client()

        result = client.list_agents()

        assert result[0]["metadata"] is None
        assert result[1]["metadata"] == {"team": "marketing"}

    @patch.object(AgentDrop, "_request")
    def test_empty_state(self, mock_request):
        """Empty response yields empty list (not None or error)."""
        mock_request.return_value = EMPTY_RESPONSE
        client = _make_client()

        result = client.list_agents()

        assert result == []

    @patch.object(AgentDrop, "_request")
    def test_calls_correct_endpoint(self, mock_request):
        """Hits GET /v1/agents with no params."""
        mock_request.return_value = EMPTY_RESPONSE
        client = _make_client()

        client.list_agents()

        mock_request.assert_called_once_with("GET", "/v1/agents")

    @patch.object(AgentDrop, "_request")
    def test_missing_agents_key_returns_empty(self, mock_request):
        """Defensive: if API omits the agents key, return empty list."""
        mock_request.return_value = {}
        client = _make_client()

        result = client.list_agents()

        assert result == []

    @patch.object(AgentDrop, "_request")
    def test_api_error_propagates(self, mock_request):
        """API errors surface as AgentDropError."""
        mock_request.side_effect = AgentDropError(
            "Unauthorized", code="UNAUTHORIZED", status=401
        )
        client = _make_client()

        with pytest.raises(AgentDropError) as exc_info:
            client.list_agents()

        assert exc_info.value.status == 401
        assert exc_info.value.code == "UNAUTHORIZED"
