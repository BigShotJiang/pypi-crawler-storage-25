"""Tests for AgentDrop Python SDK - bounded-concurrency file uploads.

Contract:
  1. Multiple files upload in parallel via ThreadPoolExecutor.
  2. max_concurrency caps in-flight uploads.
  3. max_concurrency > file_count clamps to file_count.
  4. Upload failures propagate (transfer raises).
  5. Body bytes for each slot correctly match its own file.
"""

import base64
import json
import os
import threading
import time
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from agentdrop.client import (
    AgentDrop,
    AgentDropError,
    PRESIGNED_UPLOAD_THRESHOLD,
)
from agentdrop.crypto import KeyPair, decrypt_file, decrypt_symmetric_key


def _setup_client(tmp_path: Path):
    config_dir = tmp_path / ".agentdrop"
    config_dir.mkdir(parents=True, exist_ok=True)
    sender_keys = KeyPair.generate()
    recipient_keys = KeyPair.generate()
    (config_dir / "config.json").write_text(
        json.dumps(
            {
                "agent_id": "sender-agent",
                "agent_uuid": "uuid-1",
                "private_key": sender_keys.private_key_b64,
                "public_key": sender_keys.public_key_b64,
                "api_key": "agd_par_test",
            }
        )
    )
    client = AgentDrop(
        api_key="agd_par_test",
        api_base="https://test.agentdrop.io",
        shield=False,
        config_dir=str(config_dir),
    )
    return client, sender_keys, recipient_keys


def _make_big_file(path: Path, size: int) -> None:
    chunk = os.urandom(16 * 1024)
    with open(path, "wb") as f:
        written = 0
        while written < size:
            remaining = size - written
            f.write(chunk if remaining >= len(chunk) else chunk[:remaining])
            written += min(len(chunk), remaining)


def _mock_response(status, body):
    resp = MagicMock()
    resp.status_code = status
    if isinstance(body, (dict, list)):
        resp.json.return_value = body
        resp.text = json.dumps(body)
    else:
        resp.json.side_effect = ValueError("not json")
        resp.text = body or ""
    return resp


def _build_concurrency_stubs(recipient_keys, hold_seconds, observed):
    lock = threading.Lock()
    in_flight = [0]
    transfer_id = "txfr_par_py"

    def session_get(url, *args, **kwargs):
        if "/v1/agents/resolve" in url:
            return _mock_response(
                200,
                {
                    "id": "uuid-r",
                    "agent_uuid": "uuid-r",
                    "public_key": recipient_keys.public_key_b64,
                },
            )
        if "/v1/channels" in url:
            return _mock_response(404, {"error": {"code": "NOT_FOUND"}})
        return _mock_response(418, {"error": {"message": url}})

    def session_post(url, *args, **kwargs):
        if url.endswith("/v1/transfers/presigned"):
            files = kwargs.get("json", {}).get("files", [])
            return _mock_response(
                201,
                {
                    "id": transfer_id,
                    "upload_urls": [
                        {
                            "file_id": f"file_{i}",
                            "file_name": f["name"],
                            "upload_url": f"https://r2.mock/upload/{transfer_id}/{i}-{f['name']}",
                            "method": "PUT",
                            "headers": {"Content-Type": "application/octet-stream"},
                        }
                        for i, f in enumerate(files)
                    ],
                    "confirm_url": f"https://test.agentdrop.io/v1/transfers/{transfer_id}/confirm",
                    "expires_at": "2026-04-20T12:00:00Z",
                },
            )
        if url.endswith(f"/v1/transfers/{transfer_id}/confirm"):
            return _mock_response(200, {"id": transfer_id, "status": "active"})
        return _mock_response(418, {"error": {"message": url}})

    def requests_put(url, *args, **kwargs):
        with lock:
            in_flight[0] += 1
            observed["max"] = max(observed["max"], in_flight[0])
        # Drain the generator so its progress counters fire
        body = kwargs.get("data")
        if body is not None and not isinstance(body, (bytes, bytearray)):
            for _ in body:
                pass
        time.sleep(hold_seconds)
        with lock:
            in_flight[0] -= 1
        return _mock_response(200, "")

    return session_get, session_post, requests_put


def test_multiple_files_upload_concurrently_by_default(tmp_path):
    client, _, recipient_keys = _setup_client(tmp_path)
    paths = []
    for i in range(5):
        p = tmp_path / f"f{i}.bin"
        _make_big_file(p, PRESIGNED_UPLOAD_THRESHOLD + 1024)
        paths.append(str(p))

    observed = {"max": 0}
    session_get, session_post, requests_put = _build_concurrency_stubs(
        recipient_keys, 0.08, observed
    )

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send("recipient-agent", paths)

    assert observed["max"] >= 2  # default concurrency is 4


def test_max_concurrency_1_is_serial(tmp_path):
    client, _, recipient_keys = _setup_client(tmp_path)
    paths = []
    for i in range(4):
        p = tmp_path / f"g{i}.bin"
        _make_big_file(p, PRESIGNED_UPLOAD_THRESHOLD + 1024)
        paths.append(str(p))

    observed = {"max": 0}
    session_get, session_post, requests_put = _build_concurrency_stubs(
        recipient_keys, 0.04, observed
    )

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send("recipient-agent", paths, max_concurrency=1)

    assert observed["max"] == 1


def test_max_concurrency_2_caps_at_2(tmp_path):
    client, _, recipient_keys = _setup_client(tmp_path)
    paths = []
    for i in range(6):
        p = tmp_path / f"h{i}.bin"
        _make_big_file(p, PRESIGNED_UPLOAD_THRESHOLD + 1024)
        paths.append(str(p))

    observed = {"max": 0}
    session_get, session_post, requests_put = _build_concurrency_stubs(
        recipient_keys, 0.06, observed
    )

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send("recipient-agent", paths, max_concurrency=2)

    assert observed["max"] <= 2


def test_max_concurrency_greater_than_file_count(tmp_path):
    client, _, recipient_keys = _setup_client(tmp_path)
    paths = []
    for i in range(2):
        p = tmp_path / f"i{i}.bin"
        _make_big_file(p, PRESIGNED_UPLOAD_THRESHOLD + 1024)
        paths.append(str(p))

    observed = {"max": 0}
    session_get, session_post, requests_put = _build_concurrency_stubs(
        recipient_keys, 0.03, observed
    )

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send("recipient-agent", paths, max_concurrency=16)

    assert observed["max"] <= 2


def test_order_preserved_each_slot_gets_its_own_file_bytes(tmp_path):
    client, sender_keys, recipient_keys = _setup_client(tmp_path)

    contents = [
        b"A" * (PRESIGNED_UPLOAD_THRESHOLD + 100),
        b"B" * (PRESIGNED_UPLOAD_THRESHOLD + 200),
        b"C" * (PRESIGNED_UPLOAD_THRESHOLD + 300),
    ]
    paths = []
    for i, content in enumerate(contents):
        p = tmp_path / f"letter-{i}.bin"
        p.write_bytes(content)
        paths.append(str(p))

    put_bodies = {}
    presigned_body = {}

    def session_get(url, *args, **kwargs):
        if "/v1/agents/resolve" in url:
            return _mock_response(
                200,
                {
                    "id": "uuid-r",
                    "agent_uuid": "uuid-r",
                    "public_key": recipient_keys.public_key_b64,
                },
            )
        if "/v1/channels" in url:
            return _mock_response(404, {"error": {"code": "NOT_FOUND"}})
        return _mock_response(418, {"error": {"message": url}})

    def session_post(url, *args, **kwargs):
        if url.endswith("/v1/transfers/presigned"):
            body = kwargs.get("json") or {}
            presigned_body.update(body)
            files = body.get("files", [])
            return _mock_response(
                201,
                {
                    "id": "txfr_order_py",
                    "upload_urls": [
                        {
                            "file_id": f"file_{i}",
                            "file_name": f["name"],
                            "upload_url": f"https://r2.mock/upload/txfr_order_py/{i}-{f['name']}",
                            "method": "PUT",
                            "headers": {"Content-Type": "application/octet-stream"},
                        }
                        for i, f in enumerate(files)
                    ],
                    "confirm_url": "https://test.agentdrop.io/v1/transfers/txfr_order_py/confirm",
                    "expires_at": "2026-04-20T12:00:00Z",
                },
            )
        if url.endswith("/confirm"):
            return _mock_response(200, {"id": "txfr_order_py", "status": "active"})
        return _mock_response(418, {"error": {"message": url}})

    def requests_put(url, *args, **kwargs):
        body = kwargs.get("data")
        parts = []
        if body is not None and not isinstance(body, (bytes, bytearray)):
            for chunk in body:
                parts.append(chunk if isinstance(chunk, (bytes, bytearray)) else bytes(chunk))
        put_bodies[url] = b"".join(parts)
        return _mock_response(200, "")

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send("recipient-agent", paths)

    # Decrypt each slot's body and check it matches its source file
    sym_key = decrypt_symmetric_key(
        presigned_body["encrypted_key"],
        recipient_keys,
        sender_keys.public_key_b64,
    )
    for i, original in enumerate(contents):
        file_meta = presigned_body["files"][i]
        upload_url = f"https://r2.mock/upload/txfr_order_py/{i}-{file_meta['name']}"
        ciphertext = put_bodies[upload_url]
        iv = base64.b64decode(file_meta["encryption_iv"])
        plaintext = decrypt_file(ciphertext, sym_key, iv)
        assert plaintext == original


def test_upload_failure_propagates(tmp_path):
    client, _, recipient_keys = _setup_client(tmp_path)
    paths = []
    for i in range(3):
        p = tmp_path / f"fail-{i}.bin"
        _make_big_file(p, PRESIGNED_UPLOAD_THRESHOLD + 1024)
        paths.append(str(p))

    put_count = [0]
    lock = threading.Lock()

    def session_get(url, *args, **kwargs):
        if "/v1/agents/resolve" in url:
            return _mock_response(
                200,
                {
                    "id": "uuid-r",
                    "agent_uuid": "uuid-r",
                    "public_key": recipient_keys.public_key_b64,
                },
            )
        if "/v1/channels" in url:
            return _mock_response(404, {"error": {"code": "NOT_FOUND"}})
        return _mock_response(418, {"error": {"message": url}})

    def session_post(url, *args, **kwargs):
        if url.endswith("/v1/transfers/presigned"):
            files = kwargs.get("json", {}).get("files", [])
            return _mock_response(
                201,
                {
                    "id": "txfr_fail_py",
                    "upload_urls": [
                        {
                            "file_id": f"file_{i}",
                            "file_name": f["name"],
                            "upload_url": f"https://r2.mock/upload/txfr_fail_py/{i}-{f['name']}",
                            "method": "PUT",
                            "headers": {"Content-Type": "application/octet-stream"},
                        }
                        for i, f in enumerate(files)
                    ],
                    "confirm_url": "https://test.agentdrop.io/v1/transfers/txfr_fail_py/confirm",
                    "expires_at": "2026-04-20T12:00:00Z",
                },
            )
        return _mock_response(418, {"error": {"message": url}})

    def requests_put(url, *args, **kwargs):
        body = kwargs.get("data")
        if body is not None and not isinstance(body, (bytes, bytearray)):
            for _ in body:
                pass
        with lock:
            put_count[0] += 1
            n = put_count[0]
        if n == 2:
            return _mock_response(500, {"error": {"message": "boom"}})
        return _mock_response(200, "")

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        with pytest.raises(AgentDropError):
            client.send("recipient-agent", paths)
