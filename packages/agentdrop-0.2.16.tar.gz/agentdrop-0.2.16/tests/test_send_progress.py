"""Tests for AgentDrop.send() on_progress callback.

Contract under test:
  1. on_progress fires during the presigned upload path (not multipart).
  2. Phase transitions: uploading -> confirming -> done.
  3. bytes_uploaded is monotonically non-decreasing.
  4. Final "done" event reports 100% across all bytes.
  5. Per-file and aggregate fields are accurate.
  6. Callback exceptions abort the upload.
"""

import json
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from agentdrop.client import (
    AgentDrop,
    AgentDropError,
    PRESIGNED_UPLOAD_THRESHOLD,
    SendProgress,
)
from agentdrop.crypto import KeyPair


def _setup_client(tmp_path: Path):
    config_dir = tmp_path / ".agentdrop"
    config_dir.mkdir(parents=True, exist_ok=True)
    sender_keys = KeyPair.generate()
    recipient_keys = KeyPair.generate()
    (config_dir / "config.json").write_text(
        json.dumps(
            {
                "agent_id": "sender-agent",
                "agent_uuid": "uuid-1",
                "private_key": sender_keys.private_key_b64,
                "public_key": recipient_keys.public_key_b64,
                "api_key": "agd_progress_test",
            }
        )
    )
    client = AgentDrop(
        api_key="agd_progress_test",
        api_base="https://test.agentdrop.io",
        shield=False,
        config_dir=str(config_dir),
    )
    return client, sender_keys, recipient_keys


def _make_big_file(path: Path, size: int) -> None:
    chunk = os.urandom(64 * 1024)
    with open(path, "wb") as f:
        written = 0
        while written < size:
            remaining = size - written
            f.write(chunk if remaining >= len(chunk) else chunk[:remaining])
            written += min(len(chunk), remaining)


def _make_mock_response(status: int, body):
    resp = MagicMock()
    resp.status_code = status
    if isinstance(body, (dict, list)):
        resp.json.return_value = body
        resp.text = json.dumps(body)
    else:
        resp.json.side_effect = ValueError("not json")
        resp.text = body or ""
    return resp


def _build_stubs(recipient_keys, transfer_id="txfr_prog"):
    r2_base = "https://r2.mock.io/upload"

    def session_get(url, *args, **kwargs):
        if "/v1/agents/resolve" in url:
            return _make_mock_response(
                200,
                {
                    "id": "uuid-r",
                    "agent_uuid": "uuid-r",
                    "public_key": recipient_keys.public_key_b64,
                },
            )
        if "/v1/channels" in url:
            return _make_mock_response(404, {"error": {"code": "NOT_FOUND"}})
        return _make_mock_response(418, {"error": {"message": f"unmocked {url}"}})

    def session_post(url, *args, **kwargs):
        if url.endswith("/v1/transfers/presigned"):
            body = kwargs.get("json") or {}
            files = body.get("files", [])
            return _make_mock_response(
                201,
                {
                    "id": transfer_id,
                    "upload_urls": [
                        {
                            "file_id": f"file_{i}",
                            "file_name": f["name"],
                            "upload_url": f"{r2_base}/{transfer_id}/{i}-{f['name']}",
                            "method": "PUT",
                            "headers": {"Content-Type": "application/octet-stream"},
                        }
                        for i, f in enumerate(files)
                    ],
                    "confirm_url": f"https://test.agentdrop.io/v1/transfers/{transfer_id}/confirm",
                    "expires_at": "2026-04-20T12:00:00Z",
                },
            )
        if url.endswith(f"/v1/transfers/{transfer_id}/confirm"):
            return _make_mock_response(
                200, {"id": transfer_id, "status": "active"}
            )
        if url.endswith("/v1/transfers"):
            return _make_mock_response(
                201, {"id": "txfr_small_multipart", "status": "active"}
            )
        return _make_mock_response(418, {"error": {"message": f"unmocked {url}"}})

    def requests_put(url, *args, **kwargs):
        # Drain the generator so the counting wrapper fires on each chunk
        body = kwargs.get("data")
        if body is not None and not isinstance(body, (bytes, bytearray)):
            for _ in body:
                pass
        return _make_mock_response(200, "")

    return session_get, session_post, requests_put


def test_on_progress_fires_during_large_upload(tmp_path):
    client, _, recipient_keys = _setup_client(tmp_path)
    big = tmp_path / "big.bin"
    _make_big_file(big, PRESIGNED_UPLOAD_THRESHOLD + 2 * 1024 * 1024)

    session_get, session_post, requests_put = _build_stubs(recipient_keys)
    events = []

    def on_prog(info: SendProgress):
        events.append(info)

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send("recipient-agent", [str(big)], on_progress=on_prog)

    uploading = [e for e in events if e.phase == "uploading"]
    assert len(uploading) > 0
    assert uploading[0].file_name == "big.bin"
    assert uploading[0].file_index == 0
    assert uploading[0].total_files == 1


def test_phase_transitions_ordered(tmp_path):
    client, _, recipient_keys = _setup_client(tmp_path)
    big = tmp_path / "big.bin"
    _make_big_file(big, PRESIGNED_UPLOAD_THRESHOLD + 1024)

    session_get, session_post, requests_put = _build_stubs(recipient_keys)
    phases = []

    def on_prog(info: SendProgress):
        if not phases or phases[-1] != info.phase:
            phases.append(info.phase)

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send("recipient-agent", [str(big)], on_progress=on_prog)

    assert phases[0] == "uploading"
    assert phases[-2] == "confirming"
    assert phases[-1] == "done"


def test_bytes_uploaded_is_monotonic(tmp_path):
    client, _, recipient_keys = _setup_client(tmp_path)
    big = tmp_path / "big.bin"
    _make_big_file(big, PRESIGNED_UPLOAD_THRESHOLD + 4 * 1024 * 1024)

    session_get, session_post, requests_put = _build_stubs(recipient_keys)
    events = []

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send(
            "recipient-agent",
            [str(big)],
            on_progress=lambda i: events.append(i),
        )

    for prev, curr in zip(events, events[1:]):
        assert curr.bytes_uploaded >= prev.bytes_uploaded


def test_final_done_reports_100_percent(tmp_path):
    client, _, recipient_keys = _setup_client(tmp_path)
    big = tmp_path / "big.bin"
    _make_big_file(big, PRESIGNED_UPLOAD_THRESHOLD + 1024)

    session_get, session_post, requests_put = _build_stubs(recipient_keys)
    events = []

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send(
            "recipient-agent",
            [str(big)],
            on_progress=lambda i: events.append(i),
        )

    last = events[-1]
    assert last.phase == "done"
    assert last.bytes_uploaded == last.bytes_total
    assert last.percent == 100.0


def test_small_files_do_not_fire_progress(tmp_path):
    client, _, recipient_keys = _setup_client(tmp_path)
    small = tmp_path / "tiny.txt"
    small.write_bytes(b"hello")

    session_get, session_post, requests_put = _build_stubs(recipient_keys)
    events = []

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send(
            "recipient-agent",
            [str(small)],
            on_progress=lambda i: events.append(i),
        )

    assert events == []


def test_callback_error_aborts_upload(tmp_path):
    client, _, recipient_keys = _setup_client(tmp_path)
    big = tmp_path / "big.bin"
    _make_big_file(big, PRESIGNED_UPLOAD_THRESHOLD + 1024)

    session_get, session_post, requests_put = _build_stubs(recipient_keys)

    def failing(info):
        raise RuntimeError("agent aborted")

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        with pytest.raises(RuntimeError, match="agent aborted"):
            client.send("recipient-agent", [str(big)], on_progress=failing)
