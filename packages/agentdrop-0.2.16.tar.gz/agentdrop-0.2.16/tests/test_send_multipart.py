"""Tests for AgentDrop Python SDK - R2 multipart resumable uploads."""

import base64
import hashlib
import json
import os
import threading
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from agentdrop.client import (
    AgentDrop,
    AgentDropError,
    MULTIPART_PART_SIZE,
    PRESIGNED_UPLOAD_THRESHOLD,
)
from agentdrop.crypto import KeyPair, decrypt_file, decrypt_symmetric_key


def _setup_client(tmp_path: Path):
    config_dir = tmp_path / ".agentdrop"
    config_dir.mkdir(parents=True, exist_ok=True)
    sender = KeyPair.generate()
    recipient = KeyPair.generate()
    (config_dir / "config.json").write_text(
        json.dumps(
            {
                "agent_id": "sender-agent",
                "agent_uuid": "uuid-s",
                "private_key": sender.private_key_b64,
                "public_key": sender.public_key_b64,
                "api_key": "agd_mp_test",
            }
        )
    )
    client = AgentDrop(
        api_key="agd_mp_test",
        api_base="https://test.agentdrop.io",
        shield=False,
        config_dir=str(config_dir),
    )
    return client, sender, recipient


def _make_big_file(path: Path, size: int) -> None:
    chunk = os.urandom(64 * 1024)
    with open(path, "wb") as f:
        written = 0
        while written < size:
            remaining = size - written
            f.write(chunk if remaining >= len(chunk) else chunk[:remaining])
            written += min(len(chunk), remaining)


def _mk_resp(status: int, body, headers=None):
    resp = MagicMock()
    resp.status_code = status
    if isinstance(body, (dict, list)):
        resp.json.return_value = body
        resp.text = json.dumps(body)
    else:
        resp.json.side_effect = ValueError("not json")
        resp.text = body or ""
    resp.headers = headers or {}
    return resp


def _build_multipart_stubs(
    recipient_keys: KeyPair,
    part_size: int,
    transfer_id: str = "txfr_mp_py",
    fail_part: dict | None = None,  # {"part_number": 1, "transient_count": 2}
    fail_complete_status: int | None = None,
):
    transient_counts = {}
    put_bodies = {}
    calls = []

    def session_get(url, *args, **kwargs):
        calls.append(("GET", url, None))
        if "/v1/agents/resolve" in url:
            return _mk_resp(
                200,
                {
                    "id": "uuid-r",
                    "agent_uuid": "uuid-r",
                    "public_key": recipient_keys.public_key_b64,
                },
            )
        if "/v1/channels" in url:
            return _mk_resp(404, {"error": {"code": "NOT_FOUND"}})
        return _mk_resp(418, {"error": {"message": url}})

    def session_post(url, *args, **kwargs):
        body = kwargs.get("json")
        calls.append(("POST", url, body))
        if url.endswith("/v1/transfers/presigned/multipart"):
            files = (body or {}).get("files", [])
            return _mk_resp(
                201,
                {
                    "id": transfer_id,
                    "files": [
                        {
                            "file_id": f"file-{i}",
                            "file_name": f["name"],
                            "upload_id": f"upl-{i}",
                            "part_size": f["part_size"],
                            "part_count": max(
                                1, -(-f["size"] // f["part_size"])
                            ),
                            "part_urls": [
                                {
                                    "part_number": p + 1,
                                    "upload_url": f"https://r2.mock/part-{p + 1}-file-{i}",
                                }
                                for p in range(
                                    max(1, -(-f["size"] // f["part_size"]))
                                )
                            ],
                        }
                        for i, f in enumerate(files)
                    ],
                    "confirm_url": f"https://test.agentdrop.io/v1/transfers/{transfer_id}/confirm",
                    "expires_at": "2026-04-20T12:00:00Z",
                },
            )
        if url.endswith("/complete-multipart"):
            if fail_complete_status:
                return _mk_resp(
                    fail_complete_status, {"error": {"message": "complete failed"}}
                )
            return _mk_resp(200, {"ok": True, "status": "completed"})
        if url.endswith("/abort-multipart"):
            return _mk_resp(200, {"ok": True, "status": "aborted"})
        if url.endswith(f"/v1/transfers/{transfer_id}/confirm"):
            return _mk_resp(200, {"id": transfer_id, "status": "active"})
        if url.endswith("/v1/transfers"):
            return _mk_resp(
                201, {"id": "txfr_small_multipart", "status": "active"}
            )
        return _mk_resp(418, {"error": {"message": url}})

    def requests_put(url, *args, **kwargs):
        body = kwargs.get("data")
        calls.append(("PUT", url, None))
        if "/part-" in url:
            import re

            m = re.search(r"part-(\d+)", url)
            part_number = int(m.group(1)) if m else 0
            if (
                fail_part
                and fail_part["part_number"] == part_number
                and transient_counts.get(part_number, 0) < fail_part["transient_count"]
            ):
                transient_counts[part_number] = transient_counts.get(part_number, 0) + 1
                return _mk_resp(503, {"error": {"message": "transient"}})
            # Capture body bytes for reassembly
            if body is not None:
                put_bodies[url] = body if isinstance(body, (bytes, bytearray)) else bytes(body)
            return _mk_resp(
                200, "", headers={"ETag": f'"etag-{part_number}"'}
            )
        return _mk_resp(418, {"error": {"message": url}})

    return session_get, session_post, requests_put, calls, put_bodies


def test_routes_to_multipart_endpoint_for_large_file(tmp_path: Path):
    client, _, recipient_keys = _setup_client(tmp_path)
    big = tmp_path / "big.bin"
    _make_big_file(big, 55 * 1024 * 1024)
    part_size = 20 * 1024 * 1024

    session_get, session_post, requests_put, calls, _ = _build_multipart_stubs(
        recipient_keys, part_size
    )

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send(
            "recipient-agent",
            [str(big)],
            multipart_threshold=20 * 1024 * 1024,
            multipart_part_size=part_size,
        )

    mp_posts = [c for c in calls if c[0] == "POST" and c[1].endswith("/presigned/multipart")]
    assert len(mp_posts) == 1


def test_splits_and_completes_multipart(tmp_path: Path):
    client, _, recipient_keys = _setup_client(tmp_path)
    big = tmp_path / "three-parts.bin"
    _make_big_file(big, 55 * 1024 * 1024)  # ciphertext ~55MB + 16 -> 3 parts at 20 MB
    part_size = 20 * 1024 * 1024

    session_get, session_post, requests_put, calls, _ = _build_multipart_stubs(
        recipient_keys, part_size
    )

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        result = client.send(
            "recipient-agent",
            [str(big)],
            multipart_threshold=20 * 1024 * 1024,
            multipart_part_size=part_size,
        )

    puts = [c for c in calls if c[0] == "PUT"]
    assert len(puts) == 3
    completes = [c for c in calls if c[0] == "POST" and c[1].endswith("/complete-multipart")]
    assert len(completes) == 1
    complete_body = completes[0][2]
    assert len(complete_body["parts"]) == 3
    assert complete_body["parts"][0]["etag"] == "etag-1"
    assert result["id"] == "txfr_mp_py"
    assert result["upload_path"] == "multipart"


def test_ciphertext_parts_roundtrip_decrypt(tmp_path: Path):
    client, sender_keys, recipient_keys = _setup_client(tmp_path)
    big = tmp_path / "roundtrip.bin"
    _make_big_file(big, 55 * 1024 * 1024)
    plaintext_hash = hashlib.sha256()
    with open(big, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            plaintext_hash.update(chunk)
    plaintext_hash_hex = plaintext_hash.hexdigest()

    part_size = 20 * 1024 * 1024
    session_get, session_post, requests_put, calls, put_bodies = _build_multipart_stubs(
        recipient_keys, part_size
    )

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send(
            "recipient-agent",
            [str(big)],
            multipart_threshold=20 * 1024 * 1024,
            multipart_part_size=part_size,
        )

    # Reassemble ciphertext in part order
    import re

    def part_num(url):
        return int(re.search(r"part-(\d+)", url).group(1))

    sorted_urls = sorted(put_bodies.keys(), key=part_num)
    ciphertext = b"".join(put_bodies[u] for u in sorted_urls)

    presigned_post = next(
        c for c in calls if c[0] == "POST" and c[1].endswith("/presigned/multipart")
    )
    encrypted_key = presigned_post[2]["encrypted_key"]
    iv = base64.b64decode(presigned_post[2]["files"][0]["encryption_iv"])

    sym_key = decrypt_symmetric_key(
        encrypted_key, recipient_keys, sender_keys.public_key_b64
    )
    decrypted = decrypt_file(ciphertext, sym_key, iv)
    decrypted_hash = hashlib.sha256(decrypted).hexdigest()
    assert decrypted_hash == plaintext_hash_hex


def test_retry_transient_part_failure(tmp_path: Path):
    client, _, recipient_keys = _setup_client(tmp_path)
    big = tmp_path / "retry.bin"
    _make_big_file(big, 55 * 1024 * 1024)  # 3 parts
    part_size = 20 * 1024 * 1024

    session_get, session_post, requests_put, calls, _ = _build_multipart_stubs(
        recipient_keys,
        part_size,
        fail_part={"part_number": 1, "transient_count": 2},
    )

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        client.send(
            "recipient-agent",
            [str(big)],
            multipart_threshold=20 * 1024 * 1024,
            multipart_part_size=part_size,
            max_retries=3,
        )

    # 3 parts + 2 retries on part 1 = 5 PUTs
    puts = [c for c in calls if c[0] == "PUT"]
    assert len(puts) == 5


def test_abort_on_permanent_part_failure(tmp_path: Path):
    client, _, recipient_keys = _setup_client(tmp_path)
    big = tmp_path / "doomed.bin"
    _make_big_file(big, 55 * 1024 * 1024)
    part_size = 20 * 1024 * 1024

    session_get, session_post, requests_put, calls, _ = _build_multipart_stubs(
        recipient_keys,
        part_size,
        fail_part={"part_number": 1, "transient_count": 10},
    )

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        with pytest.raises(AgentDropError):
            client.send(
                "recipient-agent",
                [str(big)],
                multipart_threshold=20 * 1024 * 1024,
                multipart_part_size=part_size,
                max_retries=1,
            )

    aborts = [c for c in calls if c[0] == "POST" and c[1].endswith("/abort-multipart")]
    assert len(aborts) >= 1


def test_abort_on_complete_failure(tmp_path: Path):
    client, _, recipient_keys = _setup_client(tmp_path)
    big = tmp_path / "complete-fails.bin"
    _make_big_file(big, 55 * 1024 * 1024)
    part_size = 20 * 1024 * 1024

    session_get, session_post, requests_put, calls, _ = _build_multipart_stubs(
        recipient_keys,
        part_size,
        fail_complete_status=500,
    )

    with patch.object(client._session, "get", side_effect=session_get), \
         patch.object(client._session, "post", side_effect=session_post), \
         patch("agentdrop.client.requests.put", side_effect=requests_put), \
         patch.object(
             client, "_request", side_effect=lambda m, u, **kw: session_get(u).json()
         ):
        with pytest.raises(AgentDropError):
            client.send(
                "recipient-agent",
                [str(big)],
                multipart_threshold=20 * 1024 * 1024,
                multipart_part_size=part_size,
            )

    aborts = [c for c in calls if c[0] == "POST" and c[1].endswith("/abort-multipart")]
    assert len(aborts) >= 1
