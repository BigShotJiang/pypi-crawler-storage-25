"""Tests for streaming AES-256-GCM encryption primitive.

Contract: output bytes MUST match what encrypt_file(open(path).read(), key)
would produce for the same (key, nonce, input). Receivers decrypt the same
way regardless of which path the sender took.
"""

import os
from pathlib import Path

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from agentdrop.crypto import (
    encrypting_file_iterator,
    expected_ciphertext_size,
    decrypt_file,
    AUTH_TAG_BYTES,
    STREAMING_CHUNK_BYTES,
)


def _one_shot(plaintext: bytes, key: bytes, nonce: bytes) -> bytes:
    """Produce ciphertext via the one-shot cipher for parity comparison."""
    c = Cipher(algorithms.AES(key), modes.GCM(nonce)).encryptor()
    body = c.update(plaintext) + c.finalize()
    return body + c.tag


def test_expected_size_matches_plaintext_plus_tag(tmp_path: Path):
    file_path = tmp_path / "small.bin"
    file_path.write_bytes(b"x" * 777)
    assert expected_ciphertext_size(str(file_path)) == 777 + 16


def test_streaming_output_equals_one_shot_for_small_file(tmp_path: Path):
    plaintext = os.urandom(1024)
    key = os.urandom(32)
    nonce = os.urandom(12)

    file_path = tmp_path / "small.bin"
    file_path.write_bytes(plaintext)

    streamed = b"".join(encrypting_file_iterator(str(file_path), key, nonce))
    one_shot = _one_shot(plaintext, key, nonce)

    assert streamed == one_shot
    assert len(streamed) == len(plaintext) + AUTH_TAG_BYTES


def test_streaming_output_equals_one_shot_across_chunk_boundaries(tmp_path: Path):
    # 3.5x the streaming chunk size to exercise multiple update() calls
    size = int(STREAMING_CHUNK_BYTES * 3.5)
    plaintext = os.urandom(size)
    key = os.urandom(32)
    nonce = os.urandom(12)

    file_path = tmp_path / "big.bin"
    file_path.write_bytes(plaintext)

    streamed = b"".join(encrypting_file_iterator(str(file_path), key, nonce))
    one_shot = _one_shot(plaintext, key, nonce)

    assert streamed == one_shot


def test_streaming_roundtrips_via_decrypt_file(tmp_path: Path):
    plaintext = os.urandom(500 * 1024)
    key = os.urandom(32)
    nonce = os.urandom(12)

    file_path = tmp_path / "rt.bin"
    file_path.write_bytes(plaintext)

    ciphertext = b"".join(encrypting_file_iterator(str(file_path), key, nonce))
    decrypted = decrypt_file(ciphertext, key, nonce)

    assert decrypted == plaintext


def test_streaming_roundtrips_for_100_mb_file(tmp_path: Path):
    # 100 MB file - proves the streaming path works at a scale where the
    # in-memory approach (plaintext + ciphertext = ~200 MB RAM) becomes
    # uncomfortable on constrained runners. If the iterator ever starts
    # buffering the whole file this will OOM on a small agent.
    size = 100 * 1024 * 1024
    file_path = tmp_path / "scale.bin"
    with open(file_path, "wb") as f:
        block = os.urandom(64 * 1024)
        written = 0
        while written < size:
            remaining = size - written
            f.write(block if remaining >= len(block) else block[:remaining])
            written += min(len(block), remaining)

    key = os.urandom(32)
    nonce = os.urandom(12)

    # Compute hash of plaintext without holding it twice in memory
    import hashlib
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    plaintext_hash = h.hexdigest()

    # Collect ciphertext chunks
    ciphertext = b"".join(encrypting_file_iterator(str(file_path), key, nonce))
    assert len(ciphertext) == size + AUTH_TAG_BYTES
    assert len(ciphertext) == expected_ciphertext_size(str(file_path))

    # Decrypt and verify hash matches
    decrypted = decrypt_file(ciphertext, key, nonce)
    decrypted_hash = hashlib.sha256(decrypted).hexdigest()
    assert decrypted_hash == plaintext_hash


def test_streaming_empty_file_still_emits_tag(tmp_path: Path):
    file_path = tmp_path / "empty.bin"
    file_path.write_bytes(b"")

    key = os.urandom(32)
    nonce = os.urandom(12)
    ciphertext = b"".join(encrypting_file_iterator(str(file_path), key, nonce))

    assert len(ciphertext) == 16  # just the auth tag
    decrypted = decrypt_file(ciphertext, key, nonce)
    assert decrypted == b""


def test_streaming_respects_custom_chunk_size(tmp_path: Path):
    plaintext = os.urandom(10_000)
    key = os.urandom(32)
    nonce = os.urandom(12)

    file_path = tmp_path / "chunked.bin"
    file_path.write_bytes(plaintext)

    # Small chunks should produce the same final bytes as default chunks
    small = b"".join(
        encrypting_file_iterator(str(file_path), key, nonce, chunk_size=256)
    )

    # Can't reuse the same nonce across ciphers (GCM rule), so use a fresh nonce
    # and compare with one-shot for that nonce.
    file_path2 = tmp_path / "chunked2.bin"
    file_path2.write_bytes(plaintext)
    nonce2 = os.urandom(12)
    big = b"".join(
        encrypting_file_iterator(str(file_path2), key, nonce2, chunk_size=1024 * 1024)
    )
    one_shot_big = _one_shot(plaintext, key, nonce2)

    # The big-chunk result should equal the one-shot for its nonce
    assert big == one_shot_big
    # And the small-chunk result should equal the one-shot for ITS nonce
    one_shot_small = _one_shot(plaintext, key, nonce)
    assert small == one_shot_small
