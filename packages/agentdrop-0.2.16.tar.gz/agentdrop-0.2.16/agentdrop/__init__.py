"""AgentDrop - Agent communication infrastructure."""

from .client import (
    AgentDrop,
    AgentDropError,
    AgentDropAmbiguousRecipientError,
    ShieldBlockError,
    Transfer,
)
from .crypto import KeyPair
from .shield import (
    Shield,
    ShieldError,
    ScanConfig,
    ScanResult,
    InjectionFinding,
    ThreatLevel,
    Strictness,
    ShieldMetadata,
    extract_metadata,
    ServerVerdict,
    ServerScanResult,
)

__version__ = "0.2.16"
__all__ = [
    "AgentDrop",
    "AgentDropError",
    "AgentDropAmbiguousRecipientError",
    "ShieldBlockError",
    "Transfer",
    "KeyPair",
    "Shield",
    "ShieldError",
    "ScanConfig",
    "ScanResult",
    "InjectionFinding",
    "ThreatLevel",
    "Strictness",
    "ShieldMetadata",
    "extract_metadata",
    "ServerVerdict",
    "ServerScanResult",
]
