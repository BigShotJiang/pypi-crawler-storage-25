"""
AgentDrop Shield -- Server-side verdict types for Shield v2.

These types represent the response from the server-side "smart brain"
classification endpoint (POST /v1/shield/analyze).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .models import ScanResult


@dataclass
class ServerVerdict:
    """Classification verdict from the server-side smart brain.

    The server applies private weights, cross-user intelligence,
    and sender reputation - none of which are exposed in the SDK.
    """

    verdict: str
    """Server-determined threat level: 'clean', 'suspicious', 'dangerous', 'blocked'."""

    score: float
    """Server-computed threat score: 0.0 (safe) to 1.0 (certain threat)."""

    safe: bool
    """True if the server considers the file safe to process."""

    adjustments: dict[str, float] = field(default_factory=dict)
    """Score adjustments applied by the server:
    - senderReputation: reputation-based adjustment
    - crossUserIntelligence: cross-user flag adjustment
    - serverWeighting: private weight rebalancing
    """

    recommendations: list[str] = field(default_factory=list)
    """Suggested actions: 'block_sender', 'quarantine_file', 'review_file', etc."""


@dataclass
class ServerScanResult:
    """Combined result from local scan + server classification.

    The server verdict takes precedence for the final decision.
    The local result is preserved for inspection and audit.
    """

    local: ScanResult
    """Full local scan result from the client-side sensor."""

    server: ServerVerdict
    """Server-side classification verdict."""

    final_verdict: str
    """The authoritative verdict - uses server's classification."""

    final_score: float
    """The authoritative score - from server."""

    safe: bool
    """Whether the file is considered safe (server's determination)."""
