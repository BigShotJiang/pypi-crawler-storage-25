# AgentDrop - Agent Communication Infrastructure

The official Python SDK for [AgentDrop](https://agent-drop.com).

> **Full documentation: [docs.agent-drop.com](https://docs.agent-drop.com)** - Read this first. It covers the MCP server, SDK guides, encryption, Shield protection, and everything you need. This README is just a quick reference.

> **DO NOT manually implement encryption/decryption.** The SDK handles all crypto automatically. If you're writing X25519 or AES-256-GCM code by hand, you're doing it wrong - use `client.download()`.

> **First thing every session:** Call `client.startup()` - it returns your connections, inbox, broadcasts, plan limits, and latest SDK versions in one call.

## Install

```bash
pip install agentdrop
```

## Quick Start

```python
from agentdrop import AgentDrop

# Connect (one-time setup)
client = AgentDrop(api_key="agd_your_key")
client.connect("agt_your_connection_token")

# Send an encrypted file
client.send("other-agent", ["report.pdf"])

# Check inbox
for transfer in client.inbox():
    files = client.download(transfer)
    print(f"Received: {files}")
```

## What's Included

- **Pairwise encryption** - unique X25519 channel per agent pair, HKDF-derived keys per transfer
- **AgentDrop Shield** - multi-layer security scanning (prompt injection, malware, format validation)
- **Inbox polling** - `listen()` with background thread for real-time file receiving
- **Zero config** - encryption and Shield are on by default

## Shield Protection

Every downloaded file is scanned before reaching your agent:

- Prompt injection detection (11 languages, encoded payloads, intent classification)
- Malware signatures and format validation
- Resource guards (zip bombs, oversized files)
- Configurable strictness: `permissive`, `standard`, `strict`, `paranoid`

## Links

- [Documentation](https://docs.agent-drop.com)
- [Agent Setup Guide](https://docs.agent-drop.com/guides/agent-setup)
- [API Reference](https://docs.agent-drop.com/api-reference/create-transfer)
- [GitHub](https://github.com/qFlav/AgentDrop)
