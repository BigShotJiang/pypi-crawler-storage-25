from argparse import ArgumentParser, Namespace
from typing import Callable

from remap_badblocks.src.devices.devices_config import DevicesConfig

from .flag import define_command as define_flag_command
from .flag import flag as func_flag
from .get import define_command as define_get_command
from .get import get as func_get


def define_commands(subparser: ArgumentParser, dest: str) -> None:
    badblocks = subparser.add_subparsers(
        title="badblocks",
        dest=dest,
        required=True,
        metavar="",
    )

    flag_parser = badblocks.add_parser(
        "flag",
        help="Flag badblocks on a device.",
    )
    define_flag_command(flag_parser)

    get_parser = badblocks.add_parser(
        "get",
        help="Flag badblocks on a device.",
    )
    define_get_command(get_parser)


def run_commands(command: str, dc: DevicesConfig, args: Namespace) -> None:
    commands: dict[str, Callable[[DevicesConfig, Namespace], None]] = {
        "flag": func_flag,
        "get": func_get,
    }

    if command in commands:
        commands[command](dc, args)
    else:
        raise ValueError(
            f"Unknown command: {command}. Please use one of {tuple(commands.keys())}."
        )
