from argparse import ArgumentParser, Namespace
from itertools import chain
from pathlib import Path
from typing import Optional, TypedDict

from remap_badblocks.src.devices.device_config import DeviceConfig
from remap_badblocks.src.devices.devices_config import DevicesConfig

from ..update_tools.scan import get_known_badblocks


class FlagArgs(TypedDict):
    device_id: Optional[int]
    device_name: Optional[str]
    badblocks: set[int]
    known_badblocks_file: Optional[Path]


def parse_args(args: Namespace) -> FlagArgs:
    return {
        "device_id": args.id,
        "device_name": args.name,
        "badblocks": set(args.badblocks),
        "known_badblocks_file": args.known_badblocks_file,
    }


def get_device(args: FlagArgs, dc: DevicesConfig) -> DeviceConfig:
    if args["device_id"] is not None:
        return dc.get_device(id=args["device_id"])
    elif args["device_name"] is not None:
        return dc.get_device(name=args["device_name"])
    else:
        raise ValueError("Either --id or --name must be provided.")


def flag(dc: DevicesConfig, _args: Namespace) -> None:
    """
    Flag badblocks on a device.
    """
    args = parse_args(_args)

    device = get_device(args, dc)

    old_badblocks = get_known_badblocks(
        external_known_badblocks_file=args["known_badblocks_file"],
        device=device,
    )
    badblocks = chain(old_badblocks, args["badblocks"])

    dc.update_device(
        id=device.id,
        badblocks=badblocks,
    )
    print(f"Flagged {len(args['badblocks'])} badblocks on device {device.name}")


def define_command(flag_parser: ArgumentParser) -> None:
    flag_parser.add_argument(
        "--id",
        type=int,
        default=None,
        help="The ID of a device. Either --id or --name must be provided.",
    )
    flag_parser.add_argument(
        "--name",
        type=str,
        default=None,
        help="The name of a device. Either --id or --name must be provided.",
    )
    flag_parser.add_argument(
        "badblocks",
        type=int,
        nargs="+",
        help="The badblock(s) to flag on the device.",
    )
    flag_parser.add_argument(
        "--known-badblocks-file",
        type=Path,
        default=None,
        help=(
            "Path to file with known badblocks (a sector number for each line) that will be merged to those found"
            " so far. Take care the sector size is the same as configured into remap_badblocks"
        ),
    )
