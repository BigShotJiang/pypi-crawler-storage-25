from argparse import ArgumentParser, Namespace
from typing import Optional, TypedDict

from remap_badblocks.src.devices.device_config import DeviceConfig
from remap_badblocks.src.devices.devices_config import DevicesConfig


class GetArgs(TypedDict):
    device_id: Optional[int]
    device_name: Optional[str]


def parse_args(args: Namespace) -> GetArgs:
    return {
        "device_id": args.id,
        "device_name": args.name,
    }


def get_device(args: GetArgs, dc: DevicesConfig) -> DeviceConfig:
    if args["device_id"] is not None:
        return dc.get_device(id=args["device_id"])
    elif args["device_name"] is not None:
        return dc.get_device(name=args["device_name"])
    else:
        raise ValueError("Either --id or --name must be provided.")


def get(dc: DevicesConfig, _args: Namespace) -> None:
    """
    Get known device badblocks.
    """
    args = parse_args(_args)

    device = get_device(args, dc)

    badblocks = device.badblocks

    print(f"Device {device.name} has {len(badblocks)} known badblocks:")
    for badblock in badblocks:
        print(badblock)


def define_command(flag_parser: ArgumentParser) -> None:
    flag_parser.add_argument(
        "--id",
        type=int,
        default=None,
        help="The ID of a device. Either --id or --name must be provided.",
    )
    flag_parser.add_argument(
        "--name",
        type=str,
        default=None,
        help="The name of a device. Either --id or --name must be provided.",
    )
