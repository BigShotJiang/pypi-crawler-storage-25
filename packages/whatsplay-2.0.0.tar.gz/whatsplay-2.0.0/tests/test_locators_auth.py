"""
Tests de selectores de autenticación WhatsApp Web 2026
"""

import pytest
from playwright.async_api import Page
from whatsplay.constants import locator as loc


class TestAuthLocators:
    """Tests para selectores de autenticación"""

    @pytest.mark.asyncio
    async def test_qr_code_exists(self, page: Page):
        """El QR code existe en pantalla de login"""
        qr_code = await page.query_selector(loc.QR_CODE)
        assert qr_code is not None, "No se encontró el QR code"

    @pytest.mark.asyncio
    async def test_auth_message_exists(self, page: Page):
        """El mensaje de autenticación existe"""
        auth_msg = await page.query_selector(loc.AUTH)
        assert auth_msg is not None, "No se encontró el mensaje de autenticación"

    @pytest.mark.asyncio
    async def test_encryption_banner_exists(self, page: Page):
        """El banner de cifrado existe"""
        loading = await page.query_selector(loc.LOADING)
        assert loading is not None, "No se encontró el banner de cifrado"


class TestLoggedInLocators:
    """Tests para selectores de estado logueado"""

    @pytest.mark.asyncio
    async def test_whatsapp_logo_exists(self, page: Page):
        """El logo de WhatsApp existe (indica sesión activa)"""
        logo = await page.query_selector(loc.LOGGED_IN)
        assert logo is not None, "No se encontró el logo de WhatsApp"

    @pytest.mark.asyncio
    async def test_chat_list_pane_exists(self, page: Page):
        """El panel de lista de chats existe"""
        chat_list = await page.query_selector(loc.CHAT_LIST_PANE)
        assert chat_list is not None, "No se encontró el panel de chats"

    @pytest.mark.asyncio
    async def test_chat_grid_exists(self, page: Page):
        """La grilla de chats existe"""
        grid = await page.query_selector(loc.CHAT_LIST_GRID)
        assert grid is not None, "No se encontró la grilla de chats"


class TestInvalidNumberWarning:
    """Tests para selector de número inválido"""

    @pytest.mark.asyncio
    async def test_invalid_number_selector_exists(self, page: Page):
        """El selector de advertencia de número inválido existe"""
        selector = await page.query_selector(loc.INVALID_NUMBER_WARNING)
        assert selector is not None, "No se encontró el selector de advertencia"


class TestLoadingState:
    """Tests para estados de carga"""

    @pytest.mark.asyncio
    async def test_loading_chats_selector_exists(self, page: Page):
        """El selector de carga de chats existe"""
        loading = await page.query_selector(loc.LOADING_CHATS)
        assert loading is not None, "No se encontró el selector de carga"
