"""
Tests de selectores de creación de grupos WhatsApp Web 2026
"""

import pytest
import uuid
from playwright.async_api import Page
from whatsplay.constants import locator as loc


class TestNewChatButton:
    """Tests para botón de nuevo chat"""

    @pytest.mark.asyncio
    async def test_new_chat_button_exists(self, page: Page):
        """El botón de nuevo chat existe"""
        btn = await page.query_selector(loc.NEW_CHAT_BUTTON)
        assert btn is not None, "No se encontró el botón Nuevo chat"

    @pytest.mark.asyncio
    async def test_new_chat_button_opens_dialog(self, page: Page):
        """El botón de nuevo chat abre el diálogo"""
        btn = await page.query_selector(loc.NEW_CHAT_BUTTON)

        if btn:
            await btn.click()
            await page.wait_for_timeout(500)

            search_field = await page.query_selector(loc.INPUT_MEMBERS_GROUP)
            print(f"Diálogo de nuevo chat abierto: {search_field is not None}")


class TestNewGroupButton:
    """Tests para botón de nuevo grupo"""

    @pytest.mark.asyncio
    async def test_new_group_button_exists(self, page: Page):
        """El botón de nuevo grupo existe"""
        btn = await page.query_selector(loc.NEW_GROUP_BUTTON)
        print(f"Botón nuevo grupo encontrado: {btn is not None}")


class TestGroupCreationLocators:
    """Tests para selectores de creación de grupo"""

    @pytest.mark.asyncio
    async def test_input_members_group_exists(self, page: Page):
        """El input de búsqueda de miembros existe"""
        search_input = await page.query_selector(loc.INPUT_MEMBERS_GROUP)
        print(f"Input de miembros encontrado: {search_input is not None}")

    @pytest.mark.asyncio
    async def test_enter_group_name_exists(self, page: Page):
        """El campo de nombre de grupo existe"""
        name_field = await page.query_selector(loc.ENTER_GROUP_NAME)
        print(f"Campo de nombre encontrado: {name_field is not None}")

    @pytest.mark.asyncio
    async def test_group_info_button_exists(self, page: Page):
        """El botón de info de grupo existe"""
        info_btn = await page.query_selector(loc.GROUP_INFO_BUTTON)
        print(f"Botón de info encontrado: {info_btn is not None}")

    @pytest.mark.asyncio
    async def test_add_members_button_exists(self, page: Page):
        """El botón de agregar miembros existe"""
        add_btn = await page.query_selector(loc.ADD_MEMBERS_BUTTON)
        print(f"Botón agregar miembros encontrado: {add_btn is not None}")

    @pytest.mark.asyncio
    async def test_confirm_add_members_button_exists(self, page: Page):
        """El botón de confirmar existe"""
        confirm_btn = await page.query_selector(loc.CONFIRM_ADD_MEMBERS_BUTTON)
        print(f"Botón confirmar encontrado: {confirm_btn is not None}")

    @pytest.mark.asyncio
    async def test_remove_member_button_exists(self, page: Page):
        """El botón de remover miembro existe"""
        remove_btn = await page.query_selector(loc.REMOVE_MEMBER_BUTTON)
        print(f"Botón remover encontrado: {remove_btn is not None}")


class TestGroupCreationFunctionality:
    """Tests de funcionalidad de creación de grupos"""

    @pytest.mark.asyncio
    async def test_create_group_flow(self, page: Page):
        """El flujo de creación de grupo funciona"""
        new_chat_btn = await page.query_selector(loc.NEW_CHAT_BUTTON)

        if not new_chat_btn:
            pytest.skip("Botón de nuevo chat no disponible")

        await new_chat_btn.click()
        await page.wait_for_timeout(500)

        new_group_btn = await page.query_selector(loc.NEW_GROUP_BUTTON)

        if new_group_btn:
            await new_group_btn.click()
            await page.wait_for_timeout(500)

            name_field = await page.query_selector(loc.ENTER_GROUP_NAME)
            assert name_field is not None, "No se encontró el campo de nombre"

            group_name = f"Test Group {uuid.uuid4().hex[:4]}"
            await name_field.fill(group_name)
            await name_field.press("Enter")

            await page.wait_for_timeout(1000)
            print(f"Grupo '{group_name}' creado")

    @pytest.mark.asyncio
    async def test_search_members_in_group(self, page: Page):
        """La búsqueda de miembros funciona"""
        new_chat_btn = await page.query_selector(loc.NEW_CHAT_BUTTON)

        if new_chat_btn:
            await new_chat_btn.click()
            await page.wait_for_timeout(500)

            new_group_btn = await page.query_selector(loc.NEW_GROUP_BUTTON)

            if new_group_btn:
                await new_group_btn.click()
                await page.wait_for_timeout(500)

                search_input = await page.query_selector(loc.INPUT_MEMBERS_GROUP)

                if search_input:
                    await search_input.fill("Mama")
                    await page.wait_for_timeout(1000)

                    results = await page.query_selector_all("//div[@role='row']")
                    print(f"Búsqueda de miembros encontró: {len(results)} resultados")
