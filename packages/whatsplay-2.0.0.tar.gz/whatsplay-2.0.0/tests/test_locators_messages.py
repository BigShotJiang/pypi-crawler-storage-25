"""
Tests de selectores de mensajes WhatsApp Web 2026
"""

import pytest
import uuid
from playwright.async_api import Page
from whatsplay.constants import locator as loc


CHAT_MESSAGE_TEXT_SELECTORS = [
    ".//span[@data-testid='selectable-text']",
    ".//div[@data-pre-plain-text]//span[@dir='auto']",
]

CHAT_MESSAGE_STATUS_SELECTORS = [
    ".//span[@data-icon='msg-dblcheck']",
    ".//span[@data-icon='msg-check']",
    ".//span[@aria-label='Entregado']",
    ".//span[@aria-label='Delivered']",
]


class TestMessageComponentLocators:
    """Tests para componentes de mensajes"""

    @pytest.mark.asyncio
    async def test_chat_component_exists(self, page: Page):
        """El componente de chat existe"""
        component = await page.query_selector(loc.CHAT_COMPONENT)
        assert component is not None, "No se encontró el componente de chat"

    @pytest.mark.asyncio
    async def test_chat_message_exists(self, page: Page):
        """El mensaje con data-pre-plain-text existe"""
        message = await page.query_selector(loc.CHAT_MESSAGE)
        print(f"Mensaje encontrado: {message is not None}")


class TestMessageTextLocators:
    """Tests para selectores de texto de mensaje"""

    @pytest.mark.parametrize("selector", CHAT_MESSAGE_TEXT_SELECTORS)
    @pytest.mark.asyncio
    async def test_message_text_selector_exists(self, page: Page, selector: str):
        """Cada selector de texto de mensaje debe encontrar un elemento"""
        elements = await page.query_selector_all(selector)
        print(f"Selector {selector[:30]}... encontró {len(elements)} elementos")


class TestMessageStatusLocators:
    """Tests para selectores de estado de mensaje"""

    @pytest.mark.parametrize("selector", CHAT_MESSAGE_STATUS_SELECTORS)
    @pytest.mark.asyncio
    async def test_message_status_selector_exists(self, page: Page, selector: str):
        """Cada selector de estado debe encontrar un elemento"""
        element = await page.query_selector(selector)
        print(f"Selector {selector[:40]}... encontró: {element is not None}")


class TestMessageQuoteLocator:
    """Tests para selector de mensaje citado"""

    @pytest.mark.asyncio
    async def test_message_quote_selector_exists(self, page: Page):
        """El selector de mensaje citado existe"""
        quote = await page.query_selector(loc.CHAT_MESSAGE_QUOTE)
        print(f"Mensaje citado encontrado: {quote is not None}")


class TestMessageImageLocators:
    """Tests para selectores de imagen"""

    @pytest.mark.asyncio
    async def test_message_image_selector_exists(self, page: Page):
        """El selector de imagen existe"""
        img = await page.query_selector(loc.CHAT_MESSAGE_IMAGE)
        print(f"Imagen encontrada: {img is not None}")

    @pytest.mark.asyncio
    async def test_message_image_element_selector_exists(self, page: Page):
        """El selector de elemento de imagen existe"""
        img_el = await page.query_selector(loc.CHAT_MESSAGE_IMAGE_ELEMENT)
        print(f"Elemento de imagen encontrado: {img_el is not None}")


class TestDownloadIconLocator:
    """Tests para selector de icono de descarga"""

    @pytest.mark.asyncio
    async def test_download_icon_selector_exists(self, page: Page):
        """El selector de icono de descarga existe"""
        icon = await page.query_selector(loc.ANY_DOWNLOAD_ICON)
        print(f"Icono de descarga encontrado: {icon is not None}")


class TestMessageFunctionality:
    """Tests de funcionalidad de mensajes"""

    @pytest.mark.asyncio
    async def test_send_and_receive_message(self, page: Page):
        """Enviar y recibir un mensaje funciona"""
        chat_input = await page.query_selector(
            "//div[contains(@class, 'lexical-rich-text-input')]"
        )

        if chat_input:
            test_msg = f"Test {uuid.uuid4().hex[:6]}"
            await chat_input.fill(test_msg)
            await page.keyboard.press("Enter")

            await page.wait_for_timeout(3000)

            messages = await page.query_selector_all(".//div[@data-pre-plain-text]")
            assert len(messages) > 0, "No se encontró el mensaje enviado"

    @pytest.mark.asyncio
    async def test_message_has_timestamp(self, page: Page):
        """El mensaje tiene marca de tiempo"""
        messages = await page.query_selector_all(".//div[@data-pre-plain-text]")

        if len(messages) > 0:
            last_msg = messages[-1]
            pre_plain_text = await last_msg.get_attribute("data-pre-plain-text")
            assert pre_plain_text is not None, "El mensaje no tiene marca de tiempo"
            assert "[" in pre_plain_text, "El formato de timestamp no es válido"

    @pytest.mark.asyncio
    async def test_message_status_visible(self, page: Page):
        """El estado del mensaje (enviado/entregado) es visible"""
        messages = await page.query_selector_all(".//div[@data-pre-plain-text]")

        if len(messages) > 0:
            last_msg = messages[-1]
            status = await last_msg.query_selector(
                ".//span[@data-icon='msg-dblcheck'] | .//span[@data-icon='msg-check']"
            )
            print(f"Estado del mensaje encontrado: {status is not None}")

    @pytest.mark.asyncio
    async def test_click_message_opens_it(self, page: Page):
        """Hacer click en un mensaje de la lista lo abre"""
        rows = await page.query_selector_all(loc.CHAT_LIST_ROWS)

        if len(rows) > 0:
            first_chat = rows[0]
            await first_chat.click()
            await page.wait_for_timeout(1000)

            messages = await page.query_selector_all(".//div[@data-pre-plain-text]")
            print(f"Chat abierto, mensajes: {len(messages)}")


class TestUnreadChatDivLocator:
    """Tests para selector de chat no leído"""

    @pytest.mark.asyncio
    async def test_unread_chat_div_selector_exists(self, page: Page):
        """El selector de chat no leído existe"""
        unread_div = await page.query_selector(loc.UNREAD_CHAT_DIV)
        assert unread_div is not None, "No se encontró el div de chat no leído"
