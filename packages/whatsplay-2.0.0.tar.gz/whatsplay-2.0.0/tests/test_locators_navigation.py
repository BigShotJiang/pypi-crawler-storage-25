"""
Tests de selectores de navegación WhatsApp Web 2026
"""

import pytest
from playwright.async_api import Page
from whatsplay.constants import locator as loc


class TestNavigationButtons:
    """Tests para botones de navegación principales"""

    @pytest.mark.asyncio
    async def test_chats_button_exists(self, page: Page):
        """El botón de Chats existe"""
        btn = await page.query_selector(loc.CHATS_BUTTON)
        assert btn is not None, "No se encontró el botón Chats"

    @pytest.mark.asyncio
    async def test_chats_button_is_clickable(self, page: Page):
        """El botón de Chats es clickeable"""
        btn = await page.query_selector(loc.CHATS_BUTTON)
        if btn:
            is_visible = await btn.is_visible()
            assert is_visible, "El botón Chats no es visible"

    @pytest.mark.asyncio
    async def test_status_button_exists(self, page: Page):
        """El botón de Estados existe"""
        btn = await page.query_selector(loc.STATUS_BUTTON)
        assert btn is not None, "No se encontró el botón Estados"

    @pytest.mark.asyncio
    async def test_channels_button_exists(self, page: Page):
        """El botón de Canales existe"""
        btn = await page.query_selector(loc.CHANNELS_BUTTON)
        assert btn is not None, "No se encontró el botón Canales"

    @pytest.mark.asyncio
    async def test_communities_button_exists(self, page: Page):
        """El botón de Comunidades existe"""
        btn = await page.query_selector(loc.COMMUNITIES_BUTTON)
        assert btn is not None, "No se encontró el botón Comunidades"


class TestNavigationFunctionality:
    """Tests de funcionalidad de navegación"""

    @pytest.mark.asyncio
    async def test_click_chats_opens_chat_list(self, page: Page):
        """Hacer click en Chats abre la lista de chats"""
        chats_btn = await page.query_selector(loc.CHATS_BUTTON)

        if chats_btn:
            await chats_btn.click()
            await page.wait_for_timeout(500)

            grid = await page.query_selector(loc.CHAT_LIST_GRID)
            assert grid is not None, "No se mostró la lista de chats"

    @pytest.mark.asyncio
    async def test_navigation_tabs_work(self, page: Page):
        """Las tabs de navegación funcionan"""
        all_btn = await page.query_selector(loc.ALL_CHATS_BUTTON)

        if all_btn:
            await all_btn.click()
            await page.wait_for_timeout(300)
            print("Click en 'Todos' funcionó")
