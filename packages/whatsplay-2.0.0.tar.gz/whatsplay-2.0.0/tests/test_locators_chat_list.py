"""
Tests de selectores de lista de chats WhatsApp Web 2026
"""

import pytest
from playwright.async_api import Page
from whatsplay.constants import locator as loc


class TestChatListPaneLocators:
    """Tests para selectores del panel de chats"""

    @pytest.mark.asyncio
    async def test_chat_list_pane_exists(self, page: Page):
        """El panel de lista de chats existe"""
        pane = await page.query_selector(loc.CHAT_LIST_PANE)
        assert pane is not None, "No se encontró el panel de chats"

    @pytest.mark.asyncio
    async def test_chat_list_grid_exists(self, page: Page):
        """La grilla de chats existe"""
        grid = await page.query_selector(loc.CHAT_LIST_GRID)
        assert grid is not None, "No se encontró la grilla de chats"

    @pytest.mark.asyncio
    async def test_chat_list_rows_exist(self, page: Page):
        """Las filas de chats existen"""
        rows = await page.query_selector_all(loc.CHAT_LIST_ROWS)
        assert len(rows) > 0, "No se encontraron filas de chats"


class TestChatListElements:
    """Tests para elementos individuales de la lista"""

    @pytest.mark.asyncio
    async def test_chat_title_selector(self, page: Page):
        """El selector de título de chat funciona"""
        titles = await page.query_selector_all(loc.SPAN_TITLE)
        assert len(titles) > 0, "No se encontraron títulos de chat"

    @pytest.mark.asyncio
    async def test_chat_time_selector(self, page: Page):
        """El selector de hora de chat funciona"""
        times = await page.query_selector_all(
            ".//div[@role='gridcell' and @aria-colindex='2'] | "
            ".//div[contains(@class,'_ak8i')]"
        )
        assert len(times) > 0, "No se encontraron marcas de tiempo"

    @pytest.mark.asyncio
    async def test_unread_badge_selector(self, page: Page):
        """El selector de badge no leído funciona"""
        unread = await page.query_selector_all(loc.UNREAD_BADGE)
        print(f"Se encontraron {len(unread)} badges de no leídos")


class TestChatFiltersLocators:
    """Tests para filtros de chat"""

    @pytest.mark.asyncio
    async def test_all_chats_button_exists(self, page: Page):
        """El botón 'Todos' existe"""
        btn = await page.query_selector(loc.ALL_CHATS_BUTTON)
        assert btn is not None, "No se encontró el botón Todos"

    @pytest.mark.asyncio
    async def test_unread_chats_button_exists(self, page: Page):
        """El botón 'No leídos' existe"""
        btn = await page.query_selector(loc.UNREAD_CHATS_BUTTON)
        assert btn is not None, "No se encontró el botón No leídos"

    @pytest.mark.asyncio
    async def test_favourites_chats_button_exists(self, page: Page):
        """El botón 'Favoritos' existe"""
        btn = await page.query_selector(loc.FAVOURITES_CHATS_BUTTON)
        assert btn is not None, "No se encontró el botón Favoritos"

    @pytest.mark.asyncio
    async def test_groups_chats_button_exists(self, page: Page):
        """El botón 'Grupos' existe"""
        btn = await page.query_selector(loc.GROUPS_CHATS_BUTTON)
        assert btn is not None, "No se encontró el botón Grupos"


class TestNavigationButtons:
    """Tests para botones de navegación"""

    @pytest.mark.asyncio
    async def test_chats_button_exists(self, page: Page):
        """El botón de Chats existe"""
        btn = await page.query_selector(loc.CHATS_BUTTON)
        assert btn is not None, "No se encontró el botón Chats"

    @pytest.mark.asyncio
    async def test_status_button_exists(self, page: Page):
        """El botón de Estados existe"""
        btn = await page.query_selector(loc.STATUS_BUTTON)
        assert btn is not None, "No se encontró el botón Estados"

    @pytest.mark.asyncio
    async def test_channels_button_exists(self, page: Page):
        """El botón de Canales existe"""
        btn = await page.query_selector(loc.CHANNELS_BUTTON)
        assert btn is not None, "No se encontró el botón Canales"

    @pytest.mark.asyncio
    async def test_communities_button_exists(self, page: Page):
        """El botón de Comunidades existe"""
        btn = await page.query_selector(loc.COMMUNITIES_BUTTON)
        assert btn is not None, "No se encontró el botón Comunidades"


class TestChatListFunctionality:
    """Tests de funcionalidad de la lista de chats"""

    @pytest.mark.asyncio
    async def test_can_click_first_chat(self, page: Page):
        """Se puede hacer click en el primer chat"""
        rows = await page.query_selector_all(loc.CHAT_LIST_ROWS)

        if len(rows) > 0:
            first_chat = rows[0]
            await first_chat.click()
            await page.wait_for_timeout(500)

            chat_input = await page.query_selector(
                "//div[contains(@class, 'lexical-rich-text-input')]"
            )
            assert chat_input is not None, "No se abrió el chat"

    @pytest.mark.asyncio
    async def test_chat_list_scrolls(self, page: Page):
        """La lista de chats puede hacer scroll"""
        grid = await page.query_selector(loc.CHAT_LIST_GRID)

        if grid:
            initial_height = await grid.evaluate("el => el.scrollHeight")

            await page.evaluate(
                "el => el.scrollBy(0, 500)", await grid.evaluate_handle("el => el")
            )
            await page.wait_for_timeout(300)

            final_height = await grid.evaluate("el => el.scrollHeight")
            assert final_height >= initial_height, "El scroll no funcionó"
