# upvertex-store

Namespace reservation for UpVertex Inc. (www.upvertex.com)