__version__ = "0.73.0"
__author__ = "pengyeqin"
__email__ = "xxbj433@qq.com"

from .reasoning.logical import LogicalReasoning
from .reasoning.common_sense import CommonSense
from .reasoning.decision import DecisionReasoning
from .reasoning.metacognition import MetaCognition
from .reasoning.active_learning import ActiveLearning
from .reasoning.error_reflection import ErrorReflection
from .reasoning.knowledge_update import KnowledgeUpdate
from .reasoning.transfer_learning import TransferLearning
from .reasoning.dialogue import DialogueManager
from .reasoning.swarm import SwarmIntelligence
from .reasoning.human_robot import HumanRobotCollaboration
from .reasoning.strategy import StrategyGeneration
from .reasoning.universal import UniversalReasoning

def hello():
    print("Hello from 灵犀紫 (Lingxi Purple)!")