import json
import os

class UnitreeExperiences:
    def __init__(self):
        self.experiences = {}
        self._load_all()
    
    def _load_all(self):
        base_path = os.path.dirname(__file__)
        
        # 加载捡枕头经验
        pickup_path = os.path.join(base_path, "all_pickup_experiences.json")
        if os.path.exists(pickup_path):
            with open(pickup_path, 'r') as f:
                self.experiences["pickup"] = json.load(f)
            print(f"? 加载捡枕头经验: {len(self.experiences['pickup'])} 个")
        
        # 加载堆叠积木经验
        block_path = os.path.join(base_path, "blockstacking_experiences.json")
        if os.path.exists(block_path):
            with open(block_path, 'r') as f:
                self.experiences["blockstacking"] = json.load(f)
            print(f"? 加载堆叠积木经验: {len(self.experiences['blockstacking'])} 个")
    
    def query(self, task):
        task_lower = task.lower()
        
        # 捡枕头相关
        if "捡" in task_lower or "pickup" in task_lower or "枕头" in task_lower:
            if "pickup" in self.experiences:
                exps = self.experiences["pickup"]
                return {
                    "found": True,
                    "task": "pickup_pillow",
                    "sample_count": len(exps),
                    "avg_frames": sum(e['frames'] for e in exps) / len(exps),
                    "avg_change": sum(e['avg_change'] for e in exps) / len(exps)
                }
        
        # 堆叠积木相关
        if "堆" in task_lower or "积木" in task_lower or "block" in task_lower or "stack" in task_lower:
            if "blockstacking" in self.experiences:
                exps = self.experiences["blockstacking"]
                return {
                    "found": True,
                    "task": "block_stacking",
                    "sample_count": len(exps),
                    "avg_frames": sum(e['frames'] for e in exps) / len(exps),
                    "avg_change": sum(e['avg_change'] for e in exps) / len(exps)
                }
        
        return {"found": False}
