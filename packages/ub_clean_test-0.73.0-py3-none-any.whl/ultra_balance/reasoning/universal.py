from typing import Dict, List, Any, Optional
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import time


class TaskType(Enum):
    PERCEPTION = "perception"
    REASONING = "reasoning"
    DECISION = "decision"
    LEARNING = "learning"
    DIALOGUE = "dialogue"
    COLLABORATION = "collaboration"
    PLANNING = "planning"


@dataclass
class UnifiedRequest:
    task_type: TaskType
    input: Any
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class UnifiedResponse:
    success: bool
    result: Any
    confidence: float
    explanation: str
    task_type: TaskType
    processing_time: float


class UniversalReasoning:
    
    def __init__(self):
        self.version = "0.73.0"
        self.request_history = []
        self._modules = {}
        
        # 加载宇树经验
        try:
            from ultra_balance.knowledge.load_experiences import UnitreeExperiences
            self.unitree_exp = UnitreeExperiences()
        except Exception as e:
            print(f"?? 宇树经验加载失败: {e}")
            self.unitree_exp = None
        
        self._init_modules()
    
    def _init_modules(self):
        try:
            from ultra_balance.reasoning.logical import LogicalReasoning
            self._modules["logical"] = LogicalReasoning()
        except:
            self._modules["logical"] = None
        
        try:
            from ultra_balance.reasoning.common_sense import CommonSense
            self._modules["common_sense"] = CommonSense()
        except:
            self._modules["common_sense"] = None
        
        try:
            from ultra_balance.reasoning.decision import DecisionReasoning
            self._modules["decision"] = DecisionReasoning()
        except:
            self._modules["decision"] = None
    
    def reason(self, request: UnifiedRequest) -> UnifiedResponse:
        start_time = time.time()
        
        try:
            result = self._route(request)
            success = True
            confidence = 0.8
            explanation = f"处理了{request.task_type.value}任务"
        except Exception as e:
            result = {"error": str(e)}
            success = False
            confidence = 0.0
            explanation = f"处理出错: {str(e)}"
        
        processing_time = time.time() - start_time
        
        return UnifiedResponse(
            success=success,
            result=result,
            confidence=confidence,
            explanation=explanation,
            task_type=request.task_type,
            processing_time=processing_time
        )
    
    def _route(self, request: UnifiedRequest) -> Any:
        if request.task_type == TaskType.REASONING:
            return self._handle_reasoning(request)
        elif request.task_type == TaskType.DECISION:
            return self._handle_decision(request)
        elif request.task_type == TaskType.DIALOGUE:
            return self._handle_dialogue(request)
        elif request.task_type == TaskType.PLANNING:
            return self._handle_planning(request)
        else:
            return {"message": f"处理{request.task_type.value}任务", "input": request.input}
    
    def _handle_reasoning(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        input_str = str(input_data).lower()
        
        # 宇树经验查询
        if hasattr(self, 'unitree_exp') and self.unitree_exp:
            if any(k in input_str for k in ["捡", "pickup", "枕头"]):
                result = self.unitree_exp.query("pickup")
                if result.get("found"):
                    return {
                        "type": "unitree_experience",
                        "task": result.get("task"),
                        "sample_count": result.get("sample_count"),
                        "avg_frames": result.get("avg_frames"),
                        "avg_change": result.get("avg_change"),
                        "message": f"根据 {result.get('sample_count')} 次宇树真机经验，"
                                  f"捡枕头任务平均需要 {result.get('avg_frames'):.0f} 帧，"
                                  f"平均动作变化 {result.get('avg_change'):.4f}"
                    }
            
            if any(k in input_str for k in ["堆", "积木", "block", "stack"]):
                result = self.unitree_exp.query("blockstacking")
                if result.get("found"):
                    return {
                        "type": "unitree_experience",
                        "task": result.get("task"),
                        "sample_count": result.get("sample_count"),
                        "avg_frames": result.get("avg_frames"),
                        "avg_change": result.get("avg_change"),
                        "message": f"根据 {result.get('sample_count')} 次宇树真机经验，"
                                  f"堆叠积木任务平均需要 {result.get('avg_frames'):.0f} 帧，"
                                  f"平均动作变化 {result.get('avg_change'):.4f}"
                    }
        
        # 逻辑推理
        if self._modules.get("logical") and isinstance(input_data, dict):
            if "major" in input_data:
                return self._modules["logical"].syllogism(
                    input_data.get("major", ""),
                    input_data.get("minor", ""),
                    input_data.get("conclusion", "")
                )
        
        # 常识推理
        if self._modules.get("common_sense") and isinstance(input_data, str):
            return self._modules["common_sense"].daily(input_data)
        
        return {"type": "reasoning_result", "input": input_data}
    
    def _handle_decision(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        if self._modules.get("decision") and isinstance(input_data, dict):
            if "options" in input_data:
                return self._modules["decision"].compare_options(input_data["options"])
        return {"type": "decision_result", "input": input_data}
    
    def _handle_dialogue(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        return {"type": "dialogue_result", "response": f"收到: {input_data}"}
    
    def _handle_planning(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        return {"type": "planning_result", "plan": f"规划: {input_data}"}
    
    def reason_text(self, text: str, task_type: str = "reasoning") -> UnifiedResponse:
        task_map = {
            "reasoning": TaskType.REASONING,
            "decision": TaskType.DECISION,
            "dialogue": TaskType.DIALOGUE,
            "planning": TaskType.PLANNING,
        }
        ttype = task_map.get(task_type, TaskType.REASONING)
        return self.reason(UnifiedRequest(task_type=ttype, input=text))
    
    def get_statistics(self) -> Dict:
        success_count = sum(1 for r in self.request_history if r.success)
        return {
            "version": self.version,
            "total_requests": len(self.request_history),
            "success_rate": success_count / len(self.request_history) if self.request_history else 1.0,
            "avg_confidence": sum(r.confidence for r in self.request_history) / len(self.request_history) if self.request_history else 0,
        }
