from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING
from unittest.mock import MagicMock

import pytest
from sqlalchemy import func, select

from spellbot.database import DatabaseSession
from spellbot.models import Block, Game, Guild, Queue, User, Watch
from spellbot.services import users
from tests.factories import UserFactory

if TYPE_CHECKING:
    from tests.fixtures import Factories

pytestmark = pytest.mark.use_db


@pytest.mark.asyncio
class TestServiceUsers:
    async def test_users_upsert(self) -> None:
        user = UserFactory.create(xid=201)

        discord_user = MagicMock()
        discord_user.id = 201
        discord_user.display_name = "user-name"

        await users.upsert(discord_user)

        DatabaseSession.expire_all()
        user = await DatabaseSession.get(User, discord_user.id)
        assert user
        assert user.xid == discord_user.id
        assert user.name == "user-name"

        discord_user.display_name = "new-name"
        await users.upsert(discord_user)

        DatabaseSession.expire_all()
        user = await DatabaseSession.get(User, discord_user.id)
        assert user
        assert user.xid == discord_user.id
        assert user.name == "new-name"

    async def test_users_get(self) -> None:
        assert await users.get(201) is None

        UserFactory.create(xid=201)

        DatabaseSession.expire_all()
        user_data = await users.get(201)
        assert user_data is not None
        assert user_data.xid == 201

    async def test_users_is_banned(self) -> None:
        user1 = UserFactory.create(banned=False)
        user2 = UserFactory.create(banned=True)

        user1_data = await users.get(user1.xid)
        user2_data = await users.get(user2.xid)
        assert user1_data is not None
        assert user2_data is not None
        assert not user1_data.banned
        assert user2_data.banned

    async def test_users_set_banned(self) -> None:
        user = UserFactory.create(banned=False)

        updated = await users.set_banned(user.xid, banned=True)
        assert updated.banned

    async def test_users_set_admin_promotes_existing_user(self) -> None:
        user = UserFactory.create(is_admin=False)

        updated = await users.set_admin(user.xid, is_admin=True)
        assert updated.is_admin

        DatabaseSession.expire_all()
        fresh = await DatabaseSession.get(User, user.xid)
        assert fresh is not None
        assert fresh.is_admin
        assert fresh.name == user.name

    async def test_users_set_admin_demotes_existing_user(self) -> None:
        user = UserFactory.create(is_admin=True)

        updated = await users.set_admin(user.xid, is_admin=False)
        assert not updated.is_admin

    async def test_users_set_admin_creates_missing_user(self) -> None:
        assert await DatabaseSession.get(User, 9999) is None

        updated = await users.set_admin(9999, is_admin=True)
        assert updated.is_admin
        assert updated.xid == 9999
        assert updated.name == "Unknown User"

    async def test_users_is_admin_true(self) -> None:
        user = UserFactory.create(is_admin=True)
        assert await users.is_admin(user.xid) is True

    async def test_users_is_admin_false(self) -> None:
        user = UserFactory.create(is_admin=False)
        assert await users.is_admin(user.xid) is False

    async def test_users_is_admin_missing_user(self) -> None:
        assert await users.is_admin(8888) is False

    async def test_users_current_game_id(self, game: Game) -> None:
        user = UserFactory.create(game=game)

        user_data = await users.get(user.xid)
        assert user_data is not None
        assert await users.current_game_id(user_data, game.channel_xid) == game.id

    async def test_users_is_waiting(self, game: Game) -> None:
        user1 = UserFactory.create(game=game)
        user2 = UserFactory.create()

        user1_data = await users.get(user1.xid)
        assert user1_data is not None
        result = await users.is_waiting(user1_data, game.channel_xid)
        assert result is not None
        assert result.id == game.id

        user2_data = await users.get(user2.xid)
        assert user2_data is not None
        assert await users.is_waiting(user2_data, game.channel_xid) is None

    async def test_users_block(self) -> None:
        user1 = UserFactory.create()
        user2 = UserFactory.create()

        await users.block(user1.xid, user2.xid)

        DatabaseSession.expire_all()
        block = (
            await DatabaseSession.execute(
                select(Block).where(
                    Block.user_xid == user1.xid,
                    Block.blocked_user_xid == user2.xid,
                ),
            )
        ).scalar_one()
        assert block.user_xid == user1.xid
        assert block.blocked_user_xid == user2.xid

    async def test_users_unblock(self) -> None:
        user1 = UserFactory.create()
        user2 = UserFactory.create()

        await users.block(user1.xid, user2.xid)

        DatabaseSession.expire_all()
        block = (
            await DatabaseSession.execute(
                select(Block).where(
                    Block.user_xid == user1.xid,
                    Block.blocked_user_xid == user2.xid,
                ),
            )
        ).scalar_one()
        assert block is not None

        await users.unblock(user1.xid, user2.xid)

        DatabaseSession.expire_all()
        block = (
            await DatabaseSession.execute(
                select(Block).where(
                    Block.user_xid == user1.xid,
                    Block.blocked_user_xid == user2.xid,
                ),
            )
        ).scalar_one_or_none()
        assert block is None

    async def test_users_watch(self, guild: Guild) -> None:
        user = UserFactory.create()

        await users.watch(guild_xid=guild.xid, user_xid=user.xid, note="note")

        DatabaseSession.expire_all()
        watch = (
            await DatabaseSession.execute(
                select(Watch).where(
                    Watch.guild_xid == guild.xid,
                    Watch.user_xid == user.xid,
                ),
            )
        ).scalar_one()
        assert watch.note == "note"

    async def test_users_watch_upsert(self, guild: Guild) -> None:
        user = UserFactory.create()

        await users.watch(guild_xid=guild.xid, user_xid=user.xid, note="note1")
        await users.watch(guild_xid=guild.xid, user_xid=user.xid, note="note2")

        DatabaseSession.expire_all()
        watch = (
            await DatabaseSession.execute(
                select(Watch).where(
                    Watch.guild_xid == guild.xid,
                    Watch.user_xid == user.xid,
                ),
            )
        ).scalar_one()
        assert watch.note == "note2"

    async def test_users_watch_without_note(self, guild: Guild) -> None:
        user = UserFactory.create()

        await users.watch(guild_xid=guild.xid, user_xid=user.xid)

        DatabaseSession.expire_all()
        watch = (
            await DatabaseSession.execute(
                select(Watch).where(
                    Watch.guild_xid == guild.xid,
                    Watch.user_xid == user.xid,
                ),
            )
        ).scalar_one()
        assert watch.note is None

    async def test_users_unwatch(self, guild: Guild) -> None:
        user = UserFactory.create()

        await users.watch(guild_xid=guild.xid, user_xid=user.xid, note="note")

        DatabaseSession.expire_all()
        watch = (
            await DatabaseSession.execute(
                select(Watch).where(
                    Watch.guild_xid == guild.xid,
                    Watch.user_xid == user.xid,
                ),
            )
        ).scalar_one()
        assert watch.note == "note"

        await users.unwatch(guild_xid=guild.xid, user_xid=user.xid)

        DatabaseSession.expire_all()
        watch = (
            await DatabaseSession.execute(
                select(Watch).where(
                    Watch.guild_xid == guild.xid,
                    Watch.user_xid == user.xid,
                ),
            )
        ).scalar_one_or_none()
        assert watch is None

    async def test_users_leave_game(self, game: Game) -> None:
        user1 = UserFactory.create(game=game)
        user2 = UserFactory.create()

        assert (
            (await DatabaseSession.execute(select(func.count()).select_from(Queue))).scalar() or 0
        ) == 1

        user1_data = await users.get(user1.xid)
        assert user1_data is not None
        await users.leave_game(user1_data, game.channel_xid)

        user2_data = await users.get(user2.xid)
        assert user2_data is not None
        await users.leave_game(user2_data, game.channel_xid)

        assert (
            (await DatabaseSession.execute(select(func.count()).select_from(Queue))).scalar() or 0
        ) == 0

    async def test_users_current_game_id_deleted_game(self, factories: Factories) -> None:
        guild = factories.guild.create()
        channel = factories.channel.create(guild=guild)
        game = factories.game.create(
            guild=guild,
            channel=channel,
            deleted_at=datetime(2021, 11, 1, tzinfo=UTC),
        )
        user = factories.user.create(game=game)

        user_data = await users.get(user.xid)
        assert user_data is not None
        assert await users.current_game_id(user_data, channel.xid) is None

    async def test_users_is_waiting_deleted_game(self, factories: Factories) -> None:
        guild = factories.guild.create()
        channel = factories.channel.create(guild=guild)
        game = factories.game.create(
            guild=guild,
            channel=channel,
            deleted_at=datetime(2021, 11, 1, tzinfo=UTC),
        )
        user = factories.user.create(game=game)

        user_data = await users.get(user.xid)
        assert user_data is not None
        assert await users.is_waiting(user_data, channel.xid) is None

    async def test_users_leave_game_deleted_game(self, factories: Factories) -> None:
        guild = factories.guild.create()
        channel = factories.channel.create(guild=guild)
        game = factories.game.create(
            guild=guild,
            channel=channel,
            deleted_at=datetime(2021, 11, 1, tzinfo=UTC),
        )
        user = factories.user.create(game=game)

        user_data = await users.get(user.xid)
        assert user_data is not None

        # Queue entry still exists (game was soft-deleted but queue wasn't cleaned up)
        assert (
            (await DatabaseSession.execute(select(func.count()).select_from(Queue))).scalar() or 0
        ) == 1

        # leave_game should not find the deleted game, so queue should remain
        await users.leave_game(user_data, channel.xid)

        # Queue entry should still exist since the game was deleted
        assert (
            (await DatabaseSession.execute(select(func.count()).select_from(Queue))).scalar() or 0
        ) == 1

    async def test_set_playgroup_user_id(self) -> None:
        user = UserFactory.create(xid=999)
        assert user.playgroup_user_id is None

        await users.set_playgroup_user_id(user.xid, 4242)

        DatabaseSession.expire_all()
        refreshed = (
            await DatabaseSession.execute(select(User).where(User.xid == user.xid))
        ).scalar_one()
        assert refreshed.playgroup_user_id == 4242
