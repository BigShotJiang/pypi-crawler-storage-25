from __future__ import annotations

import asyncio
import json
import logging
from typing import TYPE_CHECKING, Any, cast

import aiohttp
import tenacity
from aiohttp import web
from dateutil import tz
from ddtrace.trace import tracer

from spellbot import services
from spellbot.database import db_session_manager
from spellbot.metrics import add_span_request_id, generate_request_id
from spellbot.settings import settings
from spellbot.web.tools import rate_limited

if TYPE_CHECKING:
    from datetime import datetime

    from spellbot.data import GameData, UserData

logger = logging.getLogger(__name__)

routes = web.RouteTableDef()

UNRECOVERABLE = {400, 401, 403, 404}

# Process-wide aiohttp client session, lazily created on first use and reused
# for the lifetime of the process. aiohttp recommends a single long-lived
# session per application rather than creating a new one per request.
_http_session: aiohttp.ClientSession | None = None


def get_http_session() -> aiohttp.ClientSession:
    global _http_session  # noqa: PLW0603
    if _http_session is None or _http_session.closed:
        _http_session = aiohttp.ClientSession()
    return _http_session


async def close_http_session() -> None:
    global _http_session  # noqa: PLW0603
    if _http_session is not None and not _http_session.closed:
        await _http_session.close()
    _http_session = None


def reply(
    data: dict[str, Any] | None = None,
    *,
    status: int | None = None,
    error: str | None = None,
) -> web.Response:
    data = data or {}
    status = status or (200 if error is None else 500)
    if error is None:
        return web.json_response({"result": data}, status=status)
    return web.json_response({"error": error}, status=status)


@routes.post(r"/api/game/{game}/verify")
@tracer.wrap(name="rest", resource="game_verify_endpoint")
async def game_verify_endpoint(request: web.Request) -> web.Response:
    add_span_request_id(generate_request_id())
    try:
        async with db_session_manager():
            game_id = int(request.match_info["game"])
            payload = await request.json()
            user_xid = int(payload["user_xid"])
            guild_xid = int(payload["guild_xid"])
            pin = payload["pin"]
            verified = await services.plays.verify_game_pin(
                game_id=game_id,
                user_xid=user_xid,
                guild_xid=guild_xid,
                pin=pin,
            )
            if not verified and await rate_limited(request, key=f"game_verify:{game_id}"):
                return reply({}, error="Rate limited", status=429)
            return reply({"verified": verified})
    except ValueError as e:
        if await rate_limited(request):
            return reply({}, error="Rate limited", status=429)
        return reply(error=str(e), status=400)
    except KeyError as e:
        if await rate_limited(request):
            return reply({}, error="Rate limited", status=429)
        return reply(error=f"missing key: {e}", status=400)
    except Exception as e:
        if await rate_limited(request):
            return reply({}, error="Rate limited", status=429)
        return reply(error=str(e))


@tracer.wrap(name="rest", resource="game_record_embed")
def game_record_embed(
    *,
    game_data: GameData,
    players: list[UserData],
    commanders: dict[int | None, str],
    winner_xid: int | None,
    tracker_xid: int,
) -> dict[str, Any]:
    fields: list[dict[str, Any]] = []
    winner_name = next((p.name for p in players if p.xid == winner_xid), None)
    winner_commander = commanders.get(winner_xid)
    tracker_name = next(p.name for p in players if p.xid == tracker_xid)
    has_winner = winner_xid and winner_name and winner_commander
    if has_winner:
        value = f"<@{winner_xid}> ({winner_name}) - {winner_commander}"
        fields = [{"name": "🎉 Winner 🎉", "value": value}]
    else:
        fields = [{"name": "No Winner", "value": "Draw game"}]
    fields.append(
        {
            "name": "Players",
            "value": "\n".join(f"• <@{p.xid}> ({p.name}) - {commanders[p.xid]}" for p in players),
        },
    )
    description = f"A game you played was tracked by <@{tracker_xid}> ({tracker_name})."
    if has_winner:
        description += f" The winner was marked as <@{winner_xid}> ({winner_name})."
    else:
        description += " No winner was marked, the game ended in a draw."
    jump_link = game_data.jump_links.get(game_data.guild_xid)
    channel_xid = game_data.channel_xid
    started_at = game_data.started_at
    assert started_at is not None
    started_at_ts = int(cast("datetime", started_at).replace(tzinfo=tz.UTC).timestamp())
    game_start = f"<t:{started_at_ts}>"
    description += (
        f"\n\nThe game was played in <#{channel_xid}> on {game_start}. "
        f"[Jump to the original game post]({jump_link}) to see more details."
        f"\n\n_If the winner is incorrect, please contact the server mods for help._"
    )
    return {
        "content": "",
        "embeds": [
            {
                "author": {
                    "name": "Your game was tracked on Mythic Track!",
                    "icon_url": settings.ICO_URL,
                },
                "description": description,
                "fields": fields,
                "color": settings.INFO_EMBED_COLOR,
                "footer": {"text": f"SpellBot Game ID: #SB{game_data.id}"},
            },
        ],
    }


def retry_if_not_unrecoverable(exc: BaseException) -> bool:
    return not isinstance(exc, aiohttp.ClientResponseError) or exc.status not in UNRECOVERABLE


@tenacity.retry(
    stop=tenacity.stop_after_attempt(5),
    before_sleep=tenacity.before_sleep_log(logger, logging.WARNING),
    after=tenacity.after_log(logger, logging.INFO),
    wait=tenacity.wait_exponential(multiplier=1, min=4, max=10),
    retry=tenacity.retry_if_exception(retry_if_not_unrecoverable),
)
async def post_with_retry(
    session: aiohttp.ClientSession,
    path: str,
    payload: dict[str, Any] | None = None,
    method: str = "post",
) -> dict[str, Any]:
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bot {settings.BOT_TOKEN}",
    }
    op = getattr(session, method)
    async with op(
        f"https://discord.com/api{path}",
        headers=headers,
        json=payload,
    ) as response:
        response.raise_for_status()
        return await response.json()


@tracer.wrap(name="rest", resource="send_message")
async def send_message(channel_xid: int, message: dict[str, Any]) -> dict[str, Any] | None:
    logger.info("Sending message to channel %s...", channel_xid)
    try:
        return await post_with_retry(
            get_http_session(),
            f"/channels/{channel_xid}/messages",
            message,
        )
    except Exception as ex:
        logger.warning("Send message failure: %s", ex, exc_info=True)
    return None


@tracer.wrap(name="rest", resource="update_message")
async def update_message(
    channel_xid: int,
    message_xid: int,
    message: dict[str, Any],
) -> dict[str, Any] | None:
    logger.info("Sending message to channel %s...", channel_xid)
    try:
        return await post_with_retry(
            get_http_session(),
            f"/channels/{channel_xid}/messages/{message_xid}",
            message,
            method="patch",
        )
    except Exception as ex:
        logger.warning("Send message failure: %s", ex, exc_info=True)
    return None


@tracer.wrap(name="rest", resource="delete_message")
async def delete_message(
    channel_xid: int,
    message_xid: int,
) -> dict[str, Any] | None:
    logger.info("Deleting message in channel %s...", channel_xid)
    try:
        return await post_with_retry(
            get_http_session(),
            f"/channels/{channel_xid}/messages/{message_xid}",
            method="delete",
        )
    except Exception as ex:
        logger.warning("Delete message failure: %s", ex, exc_info=True)
    return None


@tracer.wrap(name="rest", resource="send_dm")
async def send_dm(user_xid: int, message: dict[str, Any]) -> None:
    logger.info("Beginning DM send to user %s...", user_xid)
    try:
        session = get_http_session()
        # create dm channel
        dm_channel = await post_with_retry(
            session,
            "/users/@me/channels",
            {"recipient_id": user_xid},
        )
        logger.info("DM channel to user %s created", user_xid)

        # then send message to dm channel
        channel_xid = dm_channel["id"]
        logger.info("Sending DM to user %s...", user_xid)
        dm_message = await post_with_retry(
            session,
            f"/channels/{channel_xid}/messages",
            message,
        )
        logger.info("Sent DM to user %s with response: %s", user_xid, json.dumps(dm_message))

    except aiohttp.ClientResponseError as ex:
        if ex.status in UNRECOVERABLE:
            logger.info("Not allowed to DM this user: %s", user_xid)
    except Exception as ex:
        logger.warning("Discord API failure: %s", ex, exc_info=True)


async def resolve_user_xid(value: Any) -> int | None:
    """Resolve a user xid from either an int, string int, or username."""
    if value is None:
        return None
    # Try to parse as int first
    try:
        return int(value)
    except ValueError, TypeError:
        pass
    # If it's a string, try to look up by name
    if isinstance(value, str):
        return await services.users.get_xid_by_name(value)
    return None


@routes.post(r"/api/game/{game}/record")
@tracer.wrap(name="rest", resource="game_record_endpoint")
async def game_record_endpoint(request: web.Request) -> web.Response:
    add_span_request_id(generate_request_id())
    async with db_session_manager():
        try:
            game_id = int(request.match_info["game"])
        except ValueError:
            return reply(error="Invalid game ID", status=400)
        if not (game_data := await services.games.get(game_id)):
            return reply(error="Game not found", status=404)
        payload = await request.json()

        # Resolve tracker (required)
        if not payload.get("tracker"):
            return reply(error="Tracker ID is required", status=400)
        tracker_xid = await resolve_user_xid(payload.get("tracker"))
        if tracker_xid is None:
            return reply(error="Tracker not found", status=400)

        # Resolve winner (optional)
        winner_xid = await resolve_user_xid(payload.get("winner"))

        # Process players data
        players_data = payload.get("players", []) or []
        if not players_data:
            return reply(error="No players provided", status=400)

        # Resolve player xids and build commanders dict
        commanders: dict[int | None, str] = {}
        player_xids: list[int] = []
        for p in players_data:
            if "xid" not in p or "commander" not in p:
                return reply(error="Invalid player data", status=400)
            xid = await resolve_user_xid(p["xid"])
            if xid is None:
                return reply(error=f"Player not found: {p['xid']}", status=400)
            player_xids.append(xid)
            commanders[xid] = p["commander"]

        plays = await services.plays.get_plays_by_game_id(game_id)
        players = await services.users.get_players_by_xid(player_xids)
        if len(plays) != len(players) or len(players) != len(players_data):
            return reply(error="Mismatched player count", status=400)
        embed = game_record_embed(
            game_data=game_data,
            players=players,
            commanders=commanders,
            winner_xid=winner_xid,
            tracker_xid=tracker_xid,
        )
        logger.info("Sending DMs to players %s...", ", ".join(str(x) for x in player_xids))
        notify_player_tasks = [send_dm(player_xid, embed) for player_xid in player_xids]
        await asyncio.gather(*notify_player_tasks)
        return reply({"success": True})
