from __future__ import annotations

import asyncio
import json
import logging
import re
import urllib.parse
from typing import TYPE_CHECKING

import discord
from ddtrace.trace import tracer

from spellbot import services
from spellbot.enums import GameBracket, GameFormat, GameService
from spellbot.i18n import guild_locale, t, user_locale
from spellbot.integrations import playgroup_live
from spellbot.models import MAX_RULES_LENGTH, GameStatus, generate_pin
from spellbot.operations import (
    VoiceChannelSuggestion,
    safe_add_role,
    safe_channel_reply,
    safe_create_channel_invite,
    safe_create_voice_channel,
    safe_ensure_voice_category,
    safe_fetch_text_channel,
    safe_fetch_user,
    safe_followup_channel,
    safe_get_partial_message,
    safe_send_user,
    safe_suggest_voice_channel,
    safe_update_embed,
    safe_update_embed_origin,
)
from spellbot.settings import settings
from spellbot.views import BaseView, GameView

from .base_action import BaseAction

if TYPE_CHECKING:
    from spellbot import SpellBot
    from spellbot.data import GameData

logger = logging.getLogger(__name__)


class LookingForGameAction(BaseAction):
    def __init__(self, bot: SpellBot, interaction: discord.Interaction) -> None:
        super().__init__(bot, interaction)

    async def block_if_no_player_linked(self, game_data: GameData) -> bool:
        if game_data.service != GameService.PLAYGROUP_LIVE.value:
            return False
        if playgroup_live.find_linked_player(game_data) is not None:
            return False
        locale = guild_locale(self.guild)
        await safe_followup_channel(
            self.interaction,
            t("lfg.playgroup_link_required", locale=locale),
        )
        return True

    @tracer.wrap()
    async def get_friends(self, friends: str | None = None) -> str:
        return friends or ""

    @tracer.wrap()
    async def get_seats(
        self,
        format: int | None = None,
        service: int | None = None,
        seats: int | None = None,
    ) -> int:
        requested_seats = 0
        if format and not seats:
            requested_seats = GameFormat(format).players
        else:
            requested_seats = seats or self.channel_data.default_seats
        return min(requested_seats, GameService(service).max_seats)

    @tracer.wrap()
    async def get_service(self, service: int | None = None) -> int:
        if service is not None:
            return service
        if self.channel_data.default_service is not None:
            return self.channel_data.default_service.value
        return GameService.CONVOKE.value

    @tracer.wrap()
    async def get_format(self, format: int | None = None) -> int:
        if format is not None:
            return format
        if self.channel_data.default_format is not None:
            return self.channel_data.default_format.value
        return GameFormat.COMMANDER.value

    @tracer.wrap()
    async def get_bracket(self, format: int | None, bracket: int | None = None) -> int:
        if format == GameFormat.CEDH.value:
            return GameBracket.BRACKET_5.value
        if format == GameFormat.PRE_CONS.value:
            return GameBracket.BRACKET_2.value
        if bracket is not None:
            return bracket
        if self.channel_data.default_bracket is not None:
            return self.channel_data.default_bracket.value
        return GameBracket.NONE.value

    @tracer.wrap()
    async def filter_friend_xids(self, friend_xids: list[int]) -> list[int]:
        assert self.guild
        if friend_xids:
            friend_xids = await self.ensure_users_exist(friend_xids)
        if friend_xids:
            friend_xids = await services.users.filter_blocked_list(
                self.interaction.user.id,
                friend_xids,
            )
        if friend_xids:
            friend_xids = await services.users.filter_pending_games(friend_xids)
        return friend_xids

    @tracer.wrap()
    async def upsert_game(
        self,
        friend_xids: list[int],
        seats: int,
        rules: str | None,
        format: int,
        bracket: int,
        service: int,
        message_xid: int | None,
    ) -> tuple[bool | None, GameData | None]:
        """Return True if the game is new, False if existing, or None of user can not join."""
        assert self.guild
        assert self.channel

        # True if user clicked on a Join Game button.
        # False if user issued a /lfg command in chat.
        origin = bool(message_xid is not None)

        assert isinstance(service, int), "Expected service to be an integer."

        if not origin:
            assert self.interaction.guild_id is not None
            new, game = await services.games.upsert(
                guild_xid=self.interaction.guild_id,
                channel_xid=self.channel.id,
                author_xid=self.interaction.user.id,
                friends=friend_xids,
                seats=seats,
                rules=rules,
                format=format,
                bracket=bracket,
                service=service,
                blind=bool(self.channel_data.blind_games),
                locale=guild_locale(self.guild),
            )
            return new, game

        assert message_xid
        found = await services.games.get_by_message_xid(message_xid)
        locale = found.locale if found else "en"
        if not found or await services.games.blocked(found, self.interaction.user.id):
            await safe_send_user(self.interaction.user, t("lfg.cannot_join", locale=locale))
            return None, None

        if found.status == GameStatus.STARTED.value:
            logger.warning("User tried to join a game that has already started.")
            # inform the player that their interaction failed
            await safe_send_user(
                self.interaction.user,
                t("lfg.game_started", locale=locale),
            )
            return None, None

        found = await services.games.add_player(found, self.interaction.user.id)
        return False, found

    @tracer.wrap()
    async def execute_rematch(self) -> None:
        locale = guild_locale(self.guild)
        if not self.guild or not self.channel:
            # Someone tried to lfg in a Discord thread rather than in the channel itself.
            await safe_send_user(
                self.interaction.user,
                t("lfg.run_in_channel", locale=locale),
            )
            return

        assert self.user_data is not None
        if await services.users.pending_games(self.user_data):
            await safe_followup_channel(
                self.interaction,
                t("lfg.already_pending", locale=locale),
            )
            return

        game_data = await services.games.get_last_game(
            user_xid=self.interaction.user.id,
            guild_xid=self.guild.id,
        )
        if not game_data:
            await safe_followup_channel(
                self.interaction,
                t("lfg.no_previous_game", locale=locale),
            )
            return

        player_xids = [player.xid for player in game_data.players]
        players = " ".join(f"<@{xid}>" for xid in player_xids)

        await self.create_game(
            players=players,
            format=game_data.format,
            bracket=game_data.bracket,
            service=GameService.NOT_ANY.value,
            rematch=True,
        )

    @tracer.wrap()
    async def execute_start(self) -> None:
        locale = user_locale(self.interaction)
        if not self.guild or not self.channel:
            await safe_send_user(
                self.interaction.user,
                t("lfg.run_in_game_channel", locale=locale),
                ephemeral=True,
            )
            return

        assert self.user_data
        game_data = await services.users.is_waiting(self.user_data, self.channel.id)
        if not game_data:
            await safe_followup_channel(
                self.interaction,
                t("lfg.not_pending_here", locale=locale),
                ephemeral=True,
            )
            return

        if await self.block_if_no_player_linked(game_data):
            return

        original_seats = (
            game_data.seats if game_data.service == GameService.PLAYGROUP_LIVE.value else None
        )
        game_data = await services.games.shrink_game(game_data)
        player_xids = [player.xid for player in game_data.players]
        game_data, suggested_vc = await self.make_game_ready(
            game_data,
            player_xids=player_xids,
            original_seats=original_seats,
        )
        assert self.interaction.guild_id
        game_data = await self.handle_voice_creation(game_data, self.interaction.guild_id)
        game_data = await self.handle_embed_creation(
            game_data,
            new=False,
            origin=False,
            fully_seated=True,
            suggested_vc=suggested_vc,
            rematch=False,
            force_start=True,
        )
        await self.handle_direct_messages(game_data, suggested_vc=suggested_vc, rematch=False)

    @tracer.wrap()
    async def execute(  # noqa: C901
        self,
        friends: str | None = None,
        seats: int | None = None,
        rules: str | None = None,
        format: int | None = None,
        bracket: int | None = None,
        service: int | None = None,
        message_xid: int | None = None,
    ) -> None:
        locale = guild_locale(self.guild)
        if not self.guild or not self.channel:
            # Someone tried to lfg in a Discord thread rather than in the channel itself.
            await safe_send_user(
                self.interaction.user,
                t("lfg.unsupported_context", locale=locale),
            )
            return None

        # True if user clicked on a Join Game button.
        # False if user issued a /lfg command in chat.
        origin = bool(message_xid is not None)

        actual_friends: str = await self.get_friends(friends)
        actual_format: int = await self.get_format(format)
        actual_bracket: int = await self.get_bracket(actual_format, bracket)
        actual_service: int = await self.get_service(service)
        actual_seats: int = await self.get_seats(actual_format, actual_service, seats)
        rules = None if not rules else rules[:MAX_RULES_LENGTH]

        assert self.user_data
        if await services.users.is_waiting(self.user_data, self.channel.id):
            msg = t("lfg.already_in_channel", locale=locale)
            if origin:
                return await safe_send_user(self.interaction.user, msg)
            await safe_followup_channel(self.interaction, msg)
            return None

        if await services.users.pending_games(self.user_data) + 1 > settings.MAX_PENDING_GAMES:
            msg = t("lfg.too_many_pending", locale=locale)
            if origin:
                return await safe_send_user(self.interaction.user, msg)
            await safe_followup_channel(self.interaction, msg)
            return None

        friend_xids = list(map(int, re.findall(r"<@!?(\d+)>", actual_friends)))

        if len(friend_xids) + 1 > actual_seats:
            await safe_send_user(self.interaction.user, t("lfg.too_many_friends", locale=locale))
            return None

        friend_xids = await self.filter_friend_xids(friend_xids)

        new, game_data = await self.upsert_game(
            friend_xids,
            actual_seats,
            rules,
            actual_format,
            actual_bracket,
            actual_service,
            message_xid,
        )
        if new is None:
            return None
        assert game_data is not None

        other_game_ids: list[int] = []
        suggested_vc = None
        if game_data.fully_seated:
            if await self.block_if_no_player_linked(game_data):
                return None
            other_game_ids = await services.games.other_game_ids(game_data)
            player_xids = [player.xid for player in game_data.players]
            game_data, suggested_vc = await self.make_game_ready(game_data, player_xids)
            game_data = await self.handle_voice_creation(game_data, self.guild.id)

        game_data = await self.handle_embed_creation(
            game_data,
            new=new,
            origin=origin,
            fully_seated=game_data.fully_seated,
            suggested_vc=suggested_vc,
        )

        if game_data.fully_seated:
            await self.handle_direct_messages(game_data, suggested_vc=suggested_vc)
            await self.update_other_game_posts(other_game_ids)
            return None
        return None

    @tracer.wrap()
    async def update_other_game_posts(self, other_game_ids: list[int]) -> None:
        """Update any other pending games to show that some players are no longer available."""
        assert self.channel is not None
        assert self.guild is not None
        if not other_game_ids:
            return

        message_xids = await services.games.message_xids(other_game_ids)
        for message_xid in message_xids:
            data = await services.games.get_by_message_xid(message_xid)
            if not data:
                continue

            channel_xid = data.channel_xid
            guild_xid = data.guild_xid
            if (channel := await safe_fetch_text_channel(self.bot, guild_xid, channel_xid)) and (
                message := safe_get_partial_message(channel, guild_xid, message_xid)
            ):
                embed = data.to_embed(
                    guild=self.guild,
                    emojis=self.bot.emojis_cache,
                    supporters=self.bot.supporters,
                )
                await safe_update_embed(
                    message,
                    embed=embed,
                    view=GameView(bot=self.bot, locale=data.locale),
                )

    @tracer.wrap()
    async def create_game(
        self,
        players: str,
        format: int | None = None,
        bracket: int | None = None,
        service: int | None = None,
        rematch: bool = False,
    ) -> None:
        assert self.channel
        locale = guild_locale(self.guild)

        game_format = GameFormat(format or GameFormat.COMMANDER.value)
        game_bracket = GameBracket(bracket or GameBracket.NONE.value)
        game_service = GameService(service or GameService.CONVOKE.value)
        player_xids = list(map(int, re.findall(r"<@!?(\d+)>", players)))
        requested_seats = len(player_xids)
        if requested_seats < 2 or requested_seats > game_format.players:
            await safe_followup_channel(
                self.interaction,
                t(
                    "lfg.invalid_player_count",
                    locale=locale,
                    format=str(game_format),
                    count=requested_seats,
                ),
            )
            return

        found_players: list[int] = []
        found_players = await self.ensure_users_exist(player_xids, exclude_self=False)

        if len(found_players) != requested_seats:
            excluded_player_xids = set(player_xids) - set(found_players)
            excluded_players_s = ", ".join(f"<@{xid}>" for xid in excluded_player_xids)
            await safe_followup_channel(
                self.interaction,
                t("lfg.excluded_players", locale=locale, players=excluded_players_s),
            )
            return

        assert self.interaction.guild_id
        preferred_locale = self.guild.preferred_locale if self.guild else None
        _, game_data = await services.games.upsert(
            guild_xid=self.interaction.guild_id,
            channel_xid=self.channel.id,
            author_xid=found_players[0],
            friends=found_players[1:],
            seats=requested_seats,
            rules=None,
            format=game_format.value,
            bracket=game_bracket.value,
            service=game_service.value,
            create_new=True,
            blind=bool(self.channel_data.blind_games),
            locale=preferred_locale.language_code if preferred_locale else "en",
        )
        game_data, suggested_vc = await self.make_game_ready(game_data, player_xids)
        game_data = await self.handle_voice_creation(game_data, self.interaction.guild_id)
        game_data = await self.handle_embed_creation(
            game_data,
            new=True,
            origin=False,
            fully_seated=True,
            suggested_vc=suggested_vc,
            rematch=rematch,
        )
        await self.handle_direct_messages(game_data, suggested_vc=suggested_vc, rematch=rematch)

    @tracer.wrap()
    async def make_game_ready(
        self,
        game_data: GameData,
        player_xids: list[int],
        original_seats: int | None = None,
    ) -> tuple[GameData, VoiceChannelSuggestion | None]:
        # Convoke needs player pins, so we have to generate them before creating the game link.
        # Initially the design was to let the DB do this later, in the `make_ready()` method.
        # This could be revisited later to better factor this code. Note that we always generate
        # pin for a player, even if Mythic Track is not enabled for the guild. The `player_pins()`
        # method of the Game object will return None for players if MT is not enabled.
        pins = [generate_pin() for _ in player_xids]

        details = await self.bot.create_game_link(game_data, pins, original_seats=original_seats)

        suggested_vc = None
        if (
            not game_data.voice_xid
            and not game_data.voice_invite_link
            and self.guild_data
            and (suggest_voice_category := self.guild_data.suggest_voice_category)
            and self.guild is not None
        ):
            suggested_vc = safe_suggest_voice_channel(
                guild=self.guild,
                category=suggest_voice_category,
                player_xids=player_xids,
            )

        if span := tracer.current_span():  # pragma: no cover
            span.set_tags(
                {
                    "game_id": str(game_data),
                    "voice_xid": str(game_data.voice_xid),
                    "voice_invite_link": str(game_data.voice_invite_link),
                    "guild_data__isnull": str(bool(self.guild_data is None)),
                    "already_picked": str(suggested_vc.already_picked if suggested_vc else None),
                    "random_empty": str(suggested_vc.random_empty if suggested_vc else None),
                },
            )

        ready_game = await services.games.make_ready(
            game_data,
            details.link,
            details.password,
            pins,
        )
        return ready_game, suggested_vc

    @tracer.wrap()
    async def handle_voice_creation(self, game_data: GameData, guild_xid: int) -> GameData:
        assert self.guild_data is not None
        if not self.guild_data.voice_create:
            return game_data

        category_prefix = self.channel_data.voice_category
        if not category_prefix:
            return game_data
        category = await safe_ensure_voice_category(self.bot, guild_xid, category_prefix)
        if not category:
            return game_data

        voice_channel = await safe_create_voice_channel(
            self.bot,
            guild_xid,
            f"Game-SB{game_data.id}",
            category=category,
            use_max_bitrate=self.guild_data.use_max_bitrate,
        )
        if not voice_channel:
            return game_data

        should_create_invite = self.channel_data.voice_invite
        invite: discord.Invite | None = None
        if should_create_invite:
            invite = await safe_create_channel_invite(
                voice_channel,
                max_age=2 * 60 * 60,  # 2 hours
                max_uses=0,  # unlimited uses
                temporary=True,
                reason=f"Creating temporary voice channel invite for Game-SB{game_data.id}",
            )

        return await services.games.set_voice(
            game_data,
            voice_xid=voice_channel.id,
            voice_invite_link=invite.url if invite else None,
        )

    @tracer.wrap()
    async def create_initial_post(
        self,
        game_data: GameData,
        embed: discord.Embed,
        view: BaseView | None = None,
        content: str | None = None,
    ) -> GameData:
        assert self.guild
        assert self.channel
        allowed_mentions = discord.AllowedMentions(everyone=True, users=False, roles=True)
        if message := await safe_followup_channel(
            self.interaction,
            content=content,
            embed=embed,
            view=view,
            allowed_mentions=allowed_mentions,
        ) or (
            message := await safe_channel_reply(
                self.channel,
                content=content,
                embed=embed,
                view=view,
                allowed_mentions=allowed_mentions,
            )
        ):
            return await services.games.add_post(
                game_data,
                self.guild.id,
                self.channel.id,
                message.id,
            )
        return game_data

    @tracer.wrap()
    async def handle_embed_creation(
        self,
        game_data: GameData,
        *,
        new: bool,
        origin: bool,
        fully_seated: bool,
        suggested_vc: VoiceChannelSuggestion | None = None,
        rematch: bool = False,
        force_start: bool = False,
    ) -> GameData:
        assert self.guild
        assert self.channel

        # build the game post's embed and view:
        embed: discord.Embed = game_data.to_embed(
            guild=self.guild,
            suggested_vc=suggested_vc,
            rematch=rematch,
            emojis=self.bot.emojis_cache,
            supporters=self.bot.supporters,
        )
        content = self.channel_data.extra

        view = None if fully_seated else GameView(bot=self.bot, locale=game_data.locale)
        if new:  # create the initial game post:
            return await self.create_initial_post(game_data, embed, view, content)

        # update the game post(s) for this game, which should already exist
        return await self.handle_embed_update(
            game_data,
            embed=embed,
            view=view,
            origin=origin,
            force_start=force_start,
        )

    @tracer.wrap()
    async def handle_embed_update(
        self,
        game_data: GameData,
        *,
        embed: discord.Embed,
        view: GameView | None,
        origin: bool = False,
        force_start: bool = False,
    ) -> GameData:
        assert self.guild
        assert self.channel

        for post in game_data.posts:
            message: discord.Message | discord.PartialMessage | None = None
            guild_xid = post.guild_xid
            channel_xid = post.channel_xid
            message_xid = post.message_xid

            channel: discord.TextChannel | None = None
            if self.guild.id == guild_xid and self.channel.id == channel_xid:
                # this post is for the current channel and guild
                channel = self.channel
            else:
                # the post is in a different channel/guild, so we need to fetch it
                channel = await safe_fetch_text_channel(self.bot, guild_xid, channel_xid)

            if channel is None:
                # failed for find the channel for this post
                continue

            # The post we're going to update here is the origin post:
            if self.interaction.message and self.interaction.message.id == message_xid:
                content = self.channel_data.extra
                if await safe_update_embed_origin(
                    self.interaction,
                    content=content,
                    embed=embed,
                    view=view,
                ):
                    # successfully updated the origin post
                    continue

            message = safe_get_partial_message(channel, guild_xid, message_xid)
            if not message:
                # failed to find the message for this post
                continue

            if not await safe_update_embed(message, embed=embed, view=view):
                # failed to update the message for this post
                continue

        if force_start:
            await self.reply_force_start_embed(game_data)
        elif not origin:
            await self.reply_found_embed(game_data)

        return game_data

    @tracer.wrap()
    async def reply_found_embed(self, game_data: GameData) -> None:
        assert self.guild is not None
        locale = game_data.locale
        embed = discord.Embed()
        embed.set_thumbnail(url=settings.ICO_URL)
        links = game_data.jump_links
        format = game_data.format
        embed.set_author(name=t("lfg.found_game", locale=locale, format=str(GameFormat(format))))
        embed.color = settings.INFO_EMBED_COLOR
        if link := links.get(self.guild.id):
            embed.description = t("lfg.jump_to_game", locale=locale, link=link)
        else:
            embed.description = t("lfg.joined_game", locale=locale, game_id=game_data.id)
        await safe_followup_channel(self.interaction, embed=embed)

    @tracer.wrap()
    async def reply_force_start_embed(self, game_data: GameData) -> None:
        assert self.guild is not None
        locale = game_data.locale
        embed = discord.Embed()
        embed.set_thumbnail(url=settings.ICO_URL)
        links = game_data.jump_links
        format = game_data.format
        embed.set_author(name=t("lfg.started_game", locale=locale, format=str(GameFormat(format))))
        embed.color = settings.INFO_EMBED_COLOR
        if link := links.get(self.guild.id):
            embed.description = t("lfg.jump_to_game", locale=locale, link=link)
        else:
            embed.description = t("lfg.game_started_id", locale=locale, game_id=game_data.id)
        await safe_followup_channel(self.interaction, embed=embed)

    @tracer.wrap()
    async def handle_direct_messages(
        self,
        game_data: GameData,
        suggested_vc: VoiceChannelSuggestion | None = None,
        rematch: bool = False,
    ) -> None:
        guild_locale_fallback = game_data.locale
        player_pins = game_data.player_pins
        player_names = {player.xid: player.name for player in game_data.players}
        player_xids = list(player_pins.keys())

        # Fetch stored user locales from the database
        player_data_list = await services.users.get_players_by_xid(player_xids)
        player_locales = {pd.xid: pd.locale or guild_locale_fallback for pd in player_data_list}

        # notify players
        fetched_players: dict[int, discord.User] = {}
        failed_xids: list[int] = []

        def mythic_track_link(player_xid: int) -> str:
            assert self.guild
            players_data = urllib.parse.quote(
                json.dumps(
                    [
                        {
                            "user_xid": f"{pid}",
                            "username": pn,
                        }
                        for pid, pn in player_names.items()
                    ],
                    separators=(",", ":"),
                ),
                safe="",
                encoding=None,
                errors=None,
            )
            return (
                "https://www.mythictrack.com/gamelobby"
                f"/{self.guild.id}"
                f"/{game_data.id}"
                f"/{game_data.format}"
                f"/{game_data.service}"
                f"/{player_xid}"
                f"/{players_data}"
                f"/{game_data.bracket - 1}"
            )

        async def notify_player(player_xid: int) -> None:
            player = await safe_fetch_user(self.bot, player_xid)
            if not player:
                failed_xids.append(player_xid)
                return

            fetched_players[player_xid] = player

            # Use the stored locale from database, falling back to guild locale
            player_locale = player_locales.get(player_xid, guild_locale_fallback)

            # Generate a personalized embed for this player with their locale
            embed = game_data.to_embed(
                guild=self.guild,
                dm=True,
                suggested_vc=suggested_vc,
                rematch=rematch,
                emojis=self.bot.emojis_cache,
                supporters=self.bot.supporters,
                locale_override=player_locale,
            )

            if pin := player_pins[player_xid]:
                mt_emoji = ""
                emojis = self.bot.emojis_cache
                if emoji := next((e for e in emojis if e.name == "mythic_track"), None):
                    mt_emoji = f"{emoji} "
                embed.description = f"{embed.description}\n\n" + t(
                    "lfg.mythic_track",
                    locale=player_locale,
                    emoji=mt_emoji,
                    link=mythic_track_link(player_xid),
                    pin=pin,
                )

            await safe_send_user(player, embed=embed)

        notify_player_tasks = [notify_player(player_xid) for player_xid in player_xids]
        await asyncio.gather(*notify_player_tasks)

        # give out awards
        assert self.interaction.guild_id is not None
        new_roles = await services.awards.give_awards(
            self.interaction.guild_id,
            player_xids,
        )
        assert self.interaction.guild
        for player_xid, new_awards in new_roles.items():
            for new_award in new_awards:
                if player_xid not in fetched_players:
                    action = "take" if new_award.remove else "give"
                    direction = "from" if new_award.remove else "to"
                    warning = t(
                        "lfg.award_failure",
                        locale=guild_locale_fallback,
                        action=action,
                        role=new_award.role,
                        direction=direction,
                        user_id=player_xid,
                    )
                    await safe_followup_channel(self.interaction, warning)
                    continue
                player = fetched_players[player_xid]
                await safe_add_role(
                    player,
                    self.interaction.guild,
                    new_award.role,
                    new_award.remove,
                )
                await safe_send_user(player, new_award.message)

        # notify issues with player permissions
        if failed_xids:
            failures = ", ".join(f"<@!{xid}>" for xid in failed_xids)
            warning = t("lfg.dm_failures", locale=guild_locale_fallback, players=failures)
            await safe_followup_channel(self.interaction, warning)

        await self.handle_watched_players(game_data, player_xids)

    @tracer.wrap()
    async def handle_watched_players(self, game_data: GameData, player_xids: list[int]) -> None:
        """Notify moderators about watched players."""
        assert self.interaction.guild
        locale = game_data.locale
        mod_role: discord.Role | None = None
        for role in self.interaction.guild.roles:
            if role.name.startswith(settings.MOD_PREFIX):
                mod_role = role
                break

        if not mod_role:
            return

        watch_notes = await services.games.watch_notes(game_data, player_xids)
        if not watch_notes:
            return

        embed = discord.Embed()
        embed.set_thumbnail(url=settings.ICO_URL)
        embed.set_author(name=t("watch.title", locale=locale))
        embed.color = settings.INFO_EMBED_COLOR
        description = ""
        for jump_link in game_data.jump_links.values():
            description += t("watch.jump_to_game", locale=locale, link=jump_link) + "\n"
        description += f"\n\n{t('watch.users_header', locale=locale)}"
        for user_xid, note in watch_notes.items():
            description += f"\n• <@{user_xid}>: {note}"
        embed.description = description
        embed.add_field(
            name=t("watch.game_id", locale=locale),
            value=f"SB{game_data.id}",
            inline=False,
        )

        for member in mod_role.members:
            await safe_send_user(member, embed=embed)

    @tracer.wrap()
    async def ensure_users_exist(
        self,
        user_xids: list[int],
        *,
        exclude_self: bool = True,
    ) -> list[int]:
        """
        Ensure DB users exist for the given list of external IDs.

        When exclude_self is True, don't create a user for IDs matching the author's.
        """
        found_users: list[int] = []
        guild_xid = self.interaction.guild_id
        for user_xid in user_xids:
            if exclude_self and user_xid == self.interaction.user.id:
                continue
            user = await safe_fetch_user(self.bot, user_xid)
            if not user:
                continue
            user_data = await services.users.upsert(user, guild_xid=guild_xid)
            if user_data.banned:
                continue
            found_users.append(user_xid)
        return found_users
