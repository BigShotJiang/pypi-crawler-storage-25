# amd-torchvision-device-gfx908

Placeholder for amd-torchvision-device-gfx908

Uploaded using Twine.
