# Changelog

## Unreleased

### Features

- `Model.notes` changed to `str | None` (previously `str`) so you can branch when they're absent. Note that this field is only populated for models authored by your organisation.
- Add `description: str` to `Model` type — exposes the new top-level model description from the API.
- **Breaking:** Remove the high specificity `ModelMetadata` Pydantic class. `model.model_metadata` is now `dict[str, Any]` and contains the arbitrary bag of metadata specific to the model. If you were previously reading this field, use `model.model_metadata["<field>"]`, and remove any`from pd4castr_api_sdk.models import ModelMetadata` imports.
