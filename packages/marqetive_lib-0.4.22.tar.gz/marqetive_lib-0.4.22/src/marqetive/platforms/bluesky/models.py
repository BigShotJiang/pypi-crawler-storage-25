"""BlueSky-specific models for post creation and interaction data."""

from datetime import datetime

from pydantic import BaseModel, Field

from marqetive.core.models import InteractionUser


class BlueSkyPostRequest(BaseModel):
    """BlueSky-specific post creation request.

    Attributes:
        text: Post text content.
        langs: Optional BCP-47 language tags (e.g., ["en"]).
        reply_to_uri: Optional post URI to reply to.
        created_at: Optional custom creation timestamp.
    """

    text: str
    langs: list[str] = Field(default_factory=list)
    reply_to_uri: str | None = None
    created_at: datetime | None = None


class BatchMessageItem(BaseModel):
    """Single item for batch message sending on BlueSky.

    Attributes:
        conversation_id: The conversation to send the message to.
        text: Message text content.
    """

    conversation_id: str
    text: str


# ==================== Interaction Models ====================


class BlueSkyInteractionUser(InteractionUser):
    """BlueSky-specific interaction user with additional fields.

    Attributes:
        did: Decentralized Identifier.
        handle: BlueSky handle (e.g., user.bsky.social).
        followers_count: Number of followers.
        following_count: Number of accounts followed.
        posts_count: Total number of posts.
        description: User's bio/description.
        indexed_at: When the account was indexed.
    """

    did: str | None = None
    handle: str | None = None
    followers_count: int = 0
    following_count: int = 0
    posts_count: int = 0
    description: str | None = None
    indexed_at: datetime | None = None
