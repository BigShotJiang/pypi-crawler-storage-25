# ❄️ Sunfer Clima

Librería Python para el **cálculo de acciones climáticas en estructuras** según distintas normativas.

`sunfer_clima` está diseñada como el módulo climático del ecosistema **Sunfer**, orientado a aplicaciones de:

* 🏗️ cálculo estructural
* ☀️ estructuras fotovoltaicas
* 🌬️ viento
* ❄️ nieve
* 🇪🇺 Eurocódigo (España, Portugal)
* 🇪🇸 CTE

La arquitectura está preparada para integrarse con motores FEM, generadores de combinaciones EN 1990 y módulos de dimensionamiento.

---

# ✨ Características

## ✅ Acciones de nieve implementadas

Actualmente incluye:

### 🇪🇸 España

* `NieveCTE`
* `NieveEurocodeES`
* `VientoEurocodeES`
* `VientoCTE`


### 🇵🇹 Portugal

* `NieveEurocodePT`
* `VientoEurocodePT`

Con soporte para:

* zonas climáticas
* altitud
* interpolación por tablas normativas
* periodos de retorno
* coeficientes probabilísticos
* densidad de nieve y aire
* carga accidental
* tablas de resultados en `pandas`
* etc

---

## 🌬️ Base para acciones de viento

La librería incluye clases base para viento según Eurocódigo, preparadas para especializaciones por país (Anejos Nacionales).

---

## 🔄 Conversor de unidades integrado

Incluye utilidades para conversión entre:

### Velocidad

* `m/s`
* `km/h`
* `mph`

### Presión

* `Pa`
* `kPa`
* `kgf/cm2`
* `ton/cm2`

También permite conversión física entre:

* **velocidad → presión dinámica**
* **presión → velocidad equivalente**

---

# 📦 Instalación

```bash
pip install sunfer-clima
```

---

# 🚀 Uso rápido

## Ejemplo 1 — nieve CTE

```python
from sunfer_clima.acciones.nieve.cte import NieveCTE

nieve = NieveCTE(zona_nieve=3, altitud=450)
nieve.calcular()

print(nieve.obtener("SKN"))
print(nieve.obtener("SAD"))
print(nieve.tabla())
```

---

## Ejemplo 2 — Eurocódigo España

```python
from sunfer_clima.acciones.nieve.es import NieveEurocodeES

nieve = NieveEurocodeES(3, 750)
nieve.calcular()

print(nieve.tabla())
```

---

## Ejemplo 3 — Eurocódigo Portugal

```python
from sunfer_clima.acciones.pt.nieve import NieveEurocodePT

nieve = NieveEurocodePT("Z2", 850)
nieve.calcular()

print(nieve.obtener("SKN"))
```

---

## Ejemplo 4 — conversión de unidades

```python
from sunfer_clima.utilidades.conversor import convertir

v = convertir(36, "km/h", "m/s")
q = convertir(10, "m/s", "Pa")
```

---

# 🧠 Filosofía de diseño

La librería está construida sobre una clase abstracta base:

```python
AccionClimatica
```

que garantiza una API homogénea:

```python
calcular()
tabla()
normativa()
obtener()
parametros()
ver_parametros()
```

Esto permite que cualquier acción climática futura comparta la misma interfaz.

Ejemplo:

```python
accion.calcular()
valor = accion.obtener("SKN")
```

Ideal para integrarse con:

* generadores de combinaciones
* motores FEM
* GUIs
* APIs REST
* informes automáticos

---

# 🧪 Testing

La librería dispone de **tests automáticos completos con `pytest`**.

Cobertura actual:

* ✅ clases abstractas
* ✅ setters y validaciones
* ✅ interpolación de tablas
* ✅ ramas de error
* ✅ periodos de retorno
* ✅ conversor físico de unidades
* ✅ DataFrames de resultados
* ✅ métodos auxiliares
* ✅ normativa

Ejecutar tests:

```bash
pytest -v
```

Con cobertura:

```bash
pytest --cov=sunfer_clima --cov-report=html
```

---

# 🏗️ Roadmap

Próximas funcionalidades previstas:

* 🌍 mapas GIS de acciones climáticas
* 🇪🇺 más anejos nacionales

---

# 🌍 Ecosistema Sunfer

`sunfer_clima` forma parte del ecosistema:

* `sunfer-clima`
* `sunfer-loads`
* `sunfer-combinaciones`
* `sunfer-fem`
* `sunfer-core`

orientado a construir un **framework open-source de cálculo estructural profesional**.

---

# 📄 Licencia

MIT License

---

# 👨‍💻 Autor

**Rafa Crespo**
Ingeniería civil
