import pytest

from sunfer_clima.acciones.viento.base import EurocodeViento


class DummyViento(EurocodeViento):
    _ZONAS_VIENTO = {"A": 26.0, "B": 27.0}

    # -------------------- MÉTODOS ABSTRACTOS FALTANTES --------------------
    def consultar_parametros(self):
        return {}

    def consultar_terrenos(self):
        return {}

    def consultar_zonas(self):
        return self._ZONAS_VIENTO

    # ----------------------------------------------------------------------

    def _velocidad_basica_fundamental(self):
        return self._ZONAS_VIENTO[self.zona_viento]

    def _n(self):
        return 0.5

    def _K(self):
        return 0.2

    def _Kr(self):
        return 0.19

    def _K1(self):
        return 1.0

    def normativa(self):
        return "Dummy Eurocode"

    def _z0(self):
        return 0.05

    def _zmin(self):
        return 2.0

    def calcular(self):
        self._datos = {"VB": self._velocidad_basica()}
        self.calculo_realizado = True

    def tabla(self):
        return {"VB": self._velocidad_basica()}


# --------------------------------------------------------------------------------------
# TESTS DE INICIALIZACIÓN
# --------------------------------------------------------------------------------------
def test_init_ok():
    v = DummyViento("A", 10)
    assert v.zona_viento == "A"
    assert v.altura_instalacion == 10.0


def test_altura_cero():
    v = DummyViento("A", 0)
    assert v.altura_instalacion == 0.01


def test_zona_invalida():
    with pytest.raises(ValueError):
        DummyViento("X", 10)


def test_altura_invalida():
    with pytest.raises(ValueError):
        DummyViento("A", -1)

    with pytest.raises(ValueError):
        DummyViento("A", 300)


# --------------------------------------------------------------------------------------
# TESTS DE DEFAULTS
# --------------------------------------------------------------------------------------
def test_defaults():
    v = DummyViento("A", 10)

    assert v.periodo_retorno == 25
    assert v.densidad_aire == 1.25
    assert v.c_dir == 1.0
    assert v.c_season == 1.0
    assert v.c_topografico == 1.0


def test_getters_defaults_explicitos():
    v = DummyViento("A", 10)

    assert v.periodo_retorno == 25
    assert v.densidad_aire == 1.25
    assert v.c_dir == 1.0
    assert v.c_season == 1.0
    assert v.c_topografico == 1.0


# --------------------------------------------------------------------------------------
# TESTS DE SETTERS
# --------------------------------------------------------------------------------------
def test_setters_validos():
    v = DummyViento("A", 10)

    v.periodo_retorno = 50
    v.densidad_aire = 1.2
    v.c_dir = 0.9
    v.c_season = 0.95
    v.c_topografico = 1.1

    assert v.periodo_retorno == 50
    assert v.densidad_aire == 1.2
    assert v.c_dir == 0.9
    assert v.c_season == 0.95
    assert v.c_topografico == 1.1


@pytest.mark.parametrize("valor", [0, -1])
def test_periodo_retorno_invalido(valor):
    v = DummyViento("A", 10)
    with pytest.raises(ValueError):
        v.periodo_retorno = valor


@pytest.mark.parametrize("valor", [0, -1, 2.0])
def test_densidad_aire_invalida(valor):
    v = DummyViento("A", 10)
    with pytest.raises(ValueError):
        v.densidad_aire = valor


@pytest.mark.parametrize("valor", [0, -1])
def test_c_dir_invalido(valor):
    v = DummyViento("A", 10)
    with pytest.raises(ValueError):
        v.c_dir = valor


@pytest.mark.parametrize("valor", [0, -1])
def test_c_season_invalido(valor):
    v = DummyViento("A", 10)
    with pytest.raises(ValueError):
        v.c_season = valor


@pytest.mark.parametrize("valor", [0, -1])
def test_c_topografico_invalido(valor):
    v = DummyViento("A", 10)
    with pytest.raises(ValueError):
        v.c_topografico = valor


# --------------------------------------------------------------------------------------
# TESTS DE MÉTODOS INTERNOS
# --------------------------------------------------------------------------------------
def test_cprob():
    v = DummyViento("A", 10)
    assert v._cprob() > 0


def test_cr_z_menor_zmin():
    v = DummyViento("A", 1)
    assert v._cr() > 0


def test_cr_z_mayor_zmin():
    v = DummyViento("A", 10)
    assert v._cr() > 0


def test_velocidades_y_presiones():
    v = DummyViento("A", 10)

    assert v._velocidad_basica() > 0
    assert v._velocidad_basica_retorno() > 0
    assert v._velocidad_media() > 0
    assert v._presion_basica() > 0
    assert v._presion_basica_50() > 0
    assert v._desviacion_turbulenta() > 0
    assert v._intensidad_turbulencia() > 0
    assert v._presion_dinamica() > 0
    assert v._velocidad_pico() > 0
    assert v._ce() > 0


def test_metodos_intermedios_explicitamente():
    v = DummyViento("A", 10)

    assert v._velocidad_basica_retorno() > 0
    assert v._presion_basica_50() > 0


# --------------------------------------------------------------------------------------
# TESTS DE REGRESIÓN
# --------------------------------------------------------------------------------------
def test_velocidad_pico_usa_property_densidad_por_defecto():
    v = DummyViento("A", 10)

    assert v._densidad_aire is None
    assert v._velocidad_pico() > 0


def test_presion_basica_usa_density_default():
    v = DummyViento("A", 10)

    assert v._densidad_aire is None
    assert v._presion_basica() > 0
    assert v._presion_basica_50() > 0


def test_cprob_usa_periodo_retorno_default():
    v = DummyViento("A", 10)

    assert v._periodo_retorno is None
    assert v._cprob() > 0


def test_velocidad_basica_usa_coeficientes_default():
    v = DummyViento("A", 10)

    assert v._c_dir is None
    assert v._c_season is None
    assert v._velocidad_basica() == pytest.approx(26.0)


def test_velocidad_media_usa_topografico_default():
    v = DummyViento("A", 10)

    assert v._c_topografico is None
    assert v._velocidad_media() > 0


def test_todos_los_metodos_internos_con_defaults():
    v = DummyViento("A", 10)

    metodos = [
        v._cprob,
        v._cr,
        v._velocidad_basica,
        v._velocidad_basica_retorno,
        v._velocidad_media,
        v._presion_basica,
        v._presion_basica_50,
        v._desviacion_turbulenta,
        v._intensidad_turbulencia,
        v._presion_dinamica,
        v._velocidad_pico,
        v._ce,
    ]

    for metodo in metodos:
        assert metodo() > 0


# --------------------------------------------------------------------------------------
# TESTS DE CÁLCULO Y TABLA
# --------------------------------------------------------------------------------------
def test_calcular_y_tabla():
    v = DummyViento("A", 10)

    v.calcular()

    assert v.calculo_realizado is True
    assert "VB" in v._datos
    assert "VB" in v.tabla()


# --------------------------------------------------------------------------------------
# TESTS DE COBERTURA DE ABSTRACTOS
# --------------------------------------------------------------------------------------
def test_metodos_abstractos_base_directamente():
    class Minimal(EurocodeViento):
        _ZONAS_VIENTO = {"A": 26.0}

        # 👇 NECESARIO PARA PODER INSTANCIAR
        def consultar_parametros(self):
            return None

        def consultar_terrenos(self):
            return None

        def consultar_zonas(self):
            return None

        def _velocidad_basica_fundamental(self):
            return super()._velocidad_basica_fundamental()

        def _n(self):
            return super()._n()

        def _K(self):
            return super()._K()

        def _Kr(self):
            return super()._Kr()

        def _K1(self):
            return super()._K1()

        def normativa(self):
            return super().normativa()

        def _z0(self):
            return super()._z0()

        def _zmin(self):
            return super()._zmin()

        def calcular(self):
            return super().calcular()

        def tabla(self):
            return super().tabla()

    v = Minimal("A", 10)

    assert v._velocidad_basica_fundamental() is None
    assert v._n() is None
    assert v._K() is None
    assert v._Kr() is None
    assert v._K1() is None
    assert v.normativa() is None
    assert v._z0() is None
    assert v._zmin() is None
    assert v.calcular() is None
    assert v.tabla() is None