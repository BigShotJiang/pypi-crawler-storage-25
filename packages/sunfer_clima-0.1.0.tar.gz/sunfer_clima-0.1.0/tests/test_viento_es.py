import pandas as pd
import pytest

from sunfer_clima.acciones.viento.es import VientoEurocodeES


# ======================================
# INICIALIZACIÓN Y VALIDACIONES
# ======================================

def test_init_valido():
    viento = VientoEurocodeES("B", 10, "II")
    assert viento.zona_viento == "B"
    assert viento.altura_instalacion == 10
    assert viento.categoria_terreno == "II"


@pytest.mark.parametrize("categoria", ["X", "V", "", "AA"])
def test_categoria_terreno_invalida(categoria):
    with pytest.raises(ValueError):
        VientoEurocodeES("B", 10, categoria)


# ======================================
# MÉTODOS INTERNOS ESPECÍFICOS ES
# ======================================

def test_velocidad_basica_fundamental():
    viento = VientoEurocodeES("A", 10, "II")
    assert viento._velocidad_basica_fundamental() == 26.0


def test_parametros_terreno():
    viento = VientoEurocodeES("B", 10, "III")
    assert viento._z0() == 0.30
    assert viento._zmin() == 5.0
    assert viento._z0II() == 0.05


def test_coeficientes_normativos():
    viento = VientoEurocodeES("B", 10, "II")
    assert viento._n() == 0.5
    assert viento._K() == 0.2
    assert viento._K1() == 1.0
    assert viento._Kr() > 0


# ======================================
# CÁLCULO COMPLETO
# ======================================

def test_calcular():
    viento = VientoEurocodeES("B", 10, "II")
    viento.calcular()

    assert viento.calculo_realizado is True
    assert viento.obtener("VB0") == 27.0
    assert viento.obtener("QP") > 0
    assert viento.obtener("VP") > 0


# ======================================
# TABLA
# ======================================

def test_tabla_devuelve_dataframe():
    viento = VientoEurocodeES("B", 10, "II")
    viento.calcular()

    df = viento.tabla()

    assert isinstance(df, pd.DataFrame)
    assert len(df) > 0
    assert "" in df.columns



def test_tabla_sin_calcular():
    viento = VientoEurocodeES("B", 10, "II")
    with pytest.raises(RuntimeError):
        viento.tabla()


# ======================================
# MÉTODOS PÚBLICOS AUXILIARES
# ======================================

def test_normativa():
    viento = VientoEurocodeES("B", 10, "II")
    assert viento.normativa() == "UNE-EN 1991-1-4:2018 + AN/UNE-EN 1991-1-4 + UNE-EN 1990"


def test_consultar_zonas(capsys):
    viento = VientoEurocodeES("B", 10, "II")
    viento.consultar_zonas()

    captured = capsys.readouterr()
    assert "ZONAS DE VIENTO:" in captured.out
    assert "A : 26.0 m/s" in captured.out



def test_consultar_parametros_ok(capsys):
    viento = VientoEurocodeES("B", 10, "II")
    viento.calcular()
    viento.consultar_parametros()

    captured = capsys.readouterr()
    assert "PARÁMETROS DISPONIBLES" in captured.out
    assert "VB0" in captured.out



def test_consultar_parametros_sin_calcular():
    viento = VientoEurocodeES("B", 10, "II")
    with pytest.raises(ValueError):
        viento.consultar_parametros()


# ======================================
# SETTER INVALIDA CÁLCULO
# ======================================

def test_setter_categoria_invalida_calculo():
    viento = VientoEurocodeES("B", 10, "II")
    viento.calcular()
    assert viento.calculo_realizado is True

    viento.categoria_terreno = "III"
    assert viento.calculo_realizado is False

def test_tabla_keyerror_branch():
    viento = VientoEurocodeES("B", 10, "II")
    viento.calcular()

    # Forzar ausencia de una clave usada por tabla()
    del viento._datos["QP"]

    df = viento.tabla()

    # Debe devolver "-" en vez de lanzar error
    assert "-" in df.to_string()