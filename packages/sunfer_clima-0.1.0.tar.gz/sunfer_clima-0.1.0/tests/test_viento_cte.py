import math 
import pandas as pd 
import pytest

from sunfer_clima.acciones.viento.cte import VientoCTE 

def test_init_valido():
    v = VientoCTE("A", 10, "II")

    assert v.zona_viento == "A"
    assert v.altura_instalacion == 10
    assert v.grado_aspereza == "II"
    assert v.calculo_realizado is False


@pytest.mark.parametrize("zona, esperado", [
    ("A", 26.0),
    ("B", 27.0),
    ("C", 29.0),
])
def test_vb50_zonas(zona, esperado):
    v = VientoCTE(zona, 10, "II")
    assert v._vb50() == esperado


def test_zona_invalida():
    with pytest.raises(ValueError):
        VientoCTE("D", 10, "II")


def test_aspereza_invalida():
    with pytest.raises(ValueError):
        VientoCTE("A", 10, "VI")


def test_altura_negativa():
    with pytest.raises(ValueError):
        VientoCTE("A", -1, "II")


def test_altura_excesiva():
    with pytest.raises(ValueError):
        VientoCTE("A", 201, "II")


def test_altura_cero():
    v = VientoCTE("A", 0, "II")
    assert v.altura_instalacion == 0.01


def test_densidad_aire_invalida():
    v = VientoCTE("A", 10, "II")
    with pytest.raises(ValueError):
        v.densidad_aire = -1


def test_periodo_retorno_invalido():
    v = VientoCTE("A", 10, "II")
    with pytest.raises(ValueError):
        v.periodo_retorno = 0


def test_qb50_formula():
    v = VientoCTE("A", 10, "II")

    esperado = 0.5 * v.densidad_aire * v._vb50() ** 2
    assert math.isclose(v._qb50(), esperado, rel_tol=1e-6)


def test_calcular():
    v = VientoCTE("A", 10, "II")
    v.calcular()

    assert v.calculo_realizado is True
    assert v._datos["VB50"] > 0
    assert v._datos["QP"] > 0
    assert v._datos["VP"] > 0


def test_invalidar_calculo():
    v = VientoCTE("A", 10, "II")
    v.calcular()

    v.altura_instalacion = 20

    assert v.calculo_realizado is False
    assert v._datos == {}


def test_tabla():
    v = VientoCTE("A", 10, "II")
    v.calcular()

    df = v.tabla()

    assert isinstance(df, pd.DataFrame)
    assert not df.empty


def test_tabla_sin_calcular():
    v = VientoCTE("A", 10, "II")

    with pytest.raises(RuntimeError):
        v.tabla()


def test_setters_validos_invalidan():
    v = VientoCTE("A", 10, "II")
    v.calcular()

    v.densidad_aire = 1.2
    assert v.densidad_aire == 1.2
    assert v.calculo_realizado is False

    v.calcular()
    v.c_dir = 0.9
    assert v.c_dir == 0.9
    assert v.calculo_realizado is False

    v.calcular()
    v.c_season = 0.8
    assert v.c_season == 0.8

    v.calcular()
    v.c_topografico = 1.1
    assert v.c_topografico == 1.1


def test_densidad_aire_excesiva():
    v = VientoCTE("A", 10, "II")
    with pytest.raises(ValueError):
        v.densidad_aire = 2.0


def test_parametro_terreno_invalido():
    v = VientoCTE("A", 10, "II")
    with pytest.raises(ValueError):
        v._parametro_terreno("X")


def test_cprob_periodo_bajo():
    v = VientoCTE("A", 10, "II")
    v.periodo_retorno = 1

    assert v._cprob() == 0.41


def test_metodos_internos():
    v = VientoCTE("A", 10, "II")

    assert v._vb() > 0
    assert v._qb() > 0
    assert v._F() > 0
    assert v._ce() > 0
    assert v._qp() > 0
    assert v._vp() > 0


def test_verificar_calculado_error():
    v = VientoCTE("A", 10, "II")

    with pytest.raises(RuntimeError):
        v._verificar_calculado()


def test_tabla_clave_inexistente():
    v = VientoCTE("A", 10, "II")
    v.calcular()

    # eliminar clave para forzar KeyError
    del v._datos["VB50"]

    df = v.tabla()

    # comprobar que aparece "-"
    assert "-" in df.to_string()


def test_consultar_zonas(capsys):
    v = VientoCTE("A", 10, "II")
    v.consultar_zonas()

    captured = capsys.readouterr()
    assert "ZONAS DE VIENTO" in captured.out
    assert "A" in captured.out


def test_normativa():
    v = VientoCTE("A", 10, "II")
    assert "CTE" in v.normativa()


def test_c_dir_invalido():
    v = VientoCTE("A", 10, "II")
    with pytest.raises(ValueError):
        v.c_dir = 0


def test_c_season_invalido():
    v = VientoCTE("A", 10, "II")
    with pytest.raises(ValueError):
        v.c_season = 0


def test_c_topografico_invalido():
    v = VientoCTE("A", 10, "II")
    with pytest.raises(ValueError):
        v.c_topografico = 0



# COMO EJECUTARLOS TESTS:
# python -m pytest

#porcentaje de cobertura:
#python -m pytest --cov=sunfer_clima --cov-report=term-missing

#porcentaje de cobertura en html:
#python -m pytest --cov=sunfer_clima --cov-report=html --> genera carpeta htmlcov con el reporte detallado en html, abrir index.html para ver resultados.










