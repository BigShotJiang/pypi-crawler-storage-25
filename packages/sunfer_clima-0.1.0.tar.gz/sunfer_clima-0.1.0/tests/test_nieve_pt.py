import math
import pandas as pd
import pytest

from sunfer_clima.acciones.nieve.pt import NieveEurocodePT


class TestNieveEurocodePT:
    def test_normaliza_zona_desde_int_y_str(self):
        assert NieveEurocodePT(1, 100).zona_nieve == "Z1"
        assert NieveEurocodePT("z2", 100).zona_nieve == "Z2"
        assert NieveEurocodePT("3", 100).zona_nieve == "Z3"

    def test_zona_invalida_lanza_error(self):
        with pytest.raises(ValueError, match="Z1, Z2 o Z3"):
            NieveEurocodePT("Z4", 100)

    def test_altitud_fuera_de_rango_lanza_error(self):
        with pytest.raises(ValueError, match="entre 0 y 1800"):
            NieveEurocodePT("Z1", -1)

        with pytest.raises(ValueError, match="entre 0 y 1800"):
            NieveEurocodePT("Z1", 2000)

    @pytest.mark.parametrize(
        "altitud,esperada",
        [
            (0, 150),
            (799.9, 150),
            (800, 200),
            (999.9, 200),
            (1000, 270),
            (1499.9, 270),
            (1500, 330),
        ],
    )
    def test_densidad_nieve_por_tramos(self, altitud, esperada):
        nieve = NieveEurocodePT("Z1", altitud)
        assert nieve._densidad_nieve() == esperada

    def test_periodo_retorno_invalido(self):
        nieve = NieveEurocodePT("Z1", 100)
        with pytest.raises(ValueError, match="mayor que 0"):
            nieve.periodo_retorno = 0

    def test_calculo_resultados_principales(self):
        nieve = NieveEurocodePT("Z1", 500)
        nieve.periodo_retorno = 25
        nieve.calcular()

        # Valores esperados según la propia formulación de la clase
        cz = 0.3
        sk50 = cz * (1 + (500 / 500) ** 2) * 1000  # 600.0
        V = 0.2
        Pn = 1 / 25
        cprob = (
            1
            - (V * (math.sqrt(6) / math.pi) * (math.log(-math.log(1 - Pn)) + 0.57722))
        ) / (1 + 2.5923 * V)
        skn = sk50 * cprob
        sad = skn * 2.5

        assert nieve.obtener("CZ") == cz
        assert nieve.obtener("SK50") == round(sk50, 3)
        assert nieve.obtener("CPROB") == round(cprob, 5)
        assert nieve.obtener("SKN") == round(skn, 3)
        assert nieve.obtener("SAD") == round(sad, 3)

    def test_tabla_devuelve_dataframe(self):
        nieve = NieveEurocodePT("Z2", 750)
        nieve.calcular()

        tabla = nieve.tabla()

        assert isinstance(tabla, pd.DataFrame)
        assert list(tabla.columns) == ["", "", ""]
        assert not tabla.empty

        contenido = tabla.to_string()
        assert "CONFIGURACIÓN GENERAL" in contenido
        assert "RESULTADOS PRINCIPALES" in contenido
        assert "Carga de nieve [skn]:" in contenido

    def test_normativa(self):
        nieve = NieveEurocodePT("Z1", 100)
        assert nieve.normativa() == "NP-EN 1991-1-3:2009"
