import pytest

from sunfer_clima.acciones.viento.pt import VientoEurocodePT


# --------------------------------------------------------------------------------------
# TESTS DE INICIALIZACIÓN
# --------------------------------------------------------------------------------------
def test_init_zona_B_por_costa():
    v = VientoEurocodePT(
        altura_instalacion=10,
        categoria_terreno="II",
        distancia_costa=1000,
        altitud=100,
    )
    assert v.zona_viento == "B"


def test_init_zona_B_por_altitud():
    v = VientoEurocodePT(
        altura_instalacion=10,
        categoria_terreno="II",
        distancia_costa=6000,
        altitud=700,
    )
    assert v.zona_viento == "B"


def test_init_zona_A():
    v = VientoEurocodePT(
        altura_instalacion=10,
        categoria_terreno="II",
        distancia_costa=6000,
        altitud=100,
    )
    assert v.zona_viento == "A"


def test_categoria_invalida():
    with pytest.raises(ValueError):
        VientoEurocodePT(10, "X", 1000, 100)


def test_altitud_invalida():
    with pytest.raises(ValueError):
        VientoEurocodePT(10, "II", 1000, -10)


# --------------------------------------------------------------------------------------
# TESTS DE PROPIEDADES
# --------------------------------------------------------------------------------------
def test_setters_validos():
    v = VientoEurocodePT(10, "II", 1000, 100)

    v.categoria_terreno = "III"
    v.distancia_costa = 2000
    v.altitud = 200

    assert v.categoria_terreno == "III"
    assert v.distancia_costa == 2000
    assert v.altitud == 200


def test_categoria_setter_invalido():
    v = VientoEurocodePT(10, "II", 1000, 100)

    with pytest.raises(ValueError):
        v.categoria_terreno = "X"


def test_altitud_setter_invalido():
    v = VientoEurocodePT(10, "II", 1000, 100)

    with pytest.raises(ValueError):
        v.altitud = -1


# --------------------------------------------------------------------------------------
# TESTS DE MÉTODOS INTERNOS
# --------------------------------------------------------------------------------------
def test_metodos_basicos():
    v = VientoEurocodePT(10, "II", 1000, 100)

    assert v._velocidad_basica_fundamental() > 0
    assert v._n() > 0
    assert v._K() > 0
    assert v._Kr() > 0
    assert v._K1() > 0
    assert v._z0() > 0
    assert v._zmin() > 0
    assert v._z0II() > 0


# --------------------------------------------------------------------------------------
# TESTS DE CÁLCULO
# --------------------------------------------------------------------------------------
def test_calcular():
    v = VientoEurocodePT(10, "II", 1000, 100)

    v.calcular()

    assert v.calculo_realizado is True
    assert "VB" in v._datos
    assert "QP" in v._datos
    assert "VP" in v._datos


def test_tabla():
    v = VientoEurocodePT(10, "II", 1000, 100)
    v.calcular()

    df = v.tabla()

    assert df is not None
    assert len(df) > 0


def test_tabla_sin_calcular():
    v = VientoEurocodePT(10, "II", 1000, 100)

    with pytest.raises(RuntimeError):
        v.tabla()


# --------------------------------------------------------------------------------------
# TESTS DE REGRESIÓN (DEFAULTS HEREDADOS)
# --------------------------------------------------------------------------------------
def test_defaults_base():
    v = VientoEurocodePT(10, "II", 1000, 100)

    assert v.periodo_retorno == 25
    assert v.densidad_aire == 1.25
    assert v.c_dir == 1.0
    assert v.c_season == 1.0
    assert v.c_topografico == 1.0


# --------------------------------------------------------------------------------------
# TESTS DE CONSULTA (PRINTS)
# --------------------------------------------------------------------------------------
def test_consultar_zonas(capsys):
    v = VientoEurocodePT(10, "II", 1000, 100)

    v.consultar_zonas()
    captured = capsys.readouterr()

    assert "ZONAS DE VIENTO" in captured.out
    assert "A" in captured.out
    assert "B" in captured.out


def test_consultar_terrenos(capsys):
    v = VientoEurocodePT(10, "II", 1000, 100)

    v.consultar_terrenos()
    captured = capsys.readouterr()

    assert "CATEGORÍAS DE TERRENO" in captured.out
    assert "I" in captured.out
    assert "IV" in captured.out


def test_consultar_parametros_sin_calcular():
    v = VientoEurocodePT(10, "II", 1000, 100)

    with pytest.raises(ValueError):
        v.consultar_parametros()


def test_consultar_parametros_con_calculo(capsys):
    v = VientoEurocodePT(10, "II", 1000, 100)
    v.calcular()

    v.consultar_parametros()
    captured = capsys.readouterr()

    assert "PARÁMETROS DISPONIBLES" in captured.out
    assert "VB" in captured.out


# --------------------------------------------------------------------------------------
# TEST EXTRA: cubrir getter seguro (KeyError en tabla)
# --------------------------------------------------------------------------------------
def test_tabla_keyerror():
    v = VientoEurocodePT(10, "II", 1000, 100)
    v.calcular()

    # Forzamos error eliminando clave
    del v._datos["VB"]

    df = v.tabla()

    assert "-" in df.to_string()