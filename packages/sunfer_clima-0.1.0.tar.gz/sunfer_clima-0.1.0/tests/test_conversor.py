import pytest
import math
from sunfer_clima.utilidades.conversor import convertir

# ---------------------------------------
# 1) Velocidad → velocidad
# ---------------------------------------
def test_velocidad_a_velocidad():
    assert math.isclose(convertir(36, 'km/h', 'm/s'), 10.0, rel_tol=1e-6)
    assert math.isclose(convertir(10, 'm/s', 'km/h'), 36.0, rel_tol=1e-6)
    assert math.isclose(convertir(1, 'mph', 'm/s'), 0.44704, rel_tol=1e-5)


# ---------------------------------------
# 2) Presión → presión
# ---------------------------------------
def test_presion_a_presion():
    assert math.isclose(convertir(1000, 'Pa', 'kPa'), 1.0, rel_tol=1e-6)
    assert math.isclose(convertir(1, 'kPa', 'Pa'), 1000.0, rel_tol=1e-6)
    assert math.isclose(convertir(1, 'kgf/cm2', 'Pa'), 9.80665e4, rel_tol=1e-6)
    assert math.isclose(convertir(1, 'ton/cm2', 'Pa'), 9.80665e7, rel_tol=1e-6)


# ---------------------------------------
# 3) Velocidad → presión
# ---------------------------------------
def test_velocidad_a_presion():
    # velocidad 10 m/s → presión dinámica con rho=1.25
    q = 0.5 * 1.25 * 10**2
    assert math.isclose(convertir(10, 'm/s', 'Pa'), q, rel_tol=1e-6)
    # unidad de salida kPa
    assert math.isclose(convertir(10, 'm/s', 'kPa'), q / 1e3, rel_tol=1e-6)


# ---------------------------------------
# 4) Presión → velocidad
# ---------------------------------------
def test_presion_a_velocidad():
    # presión 62.5 Pa → velocidad con rho=1.25
    v = math.sqrt(2 * 62.5 / 1.25)
    assert math.isclose(convertir(62.5, 'Pa', 'm/s'), v, rel_tol=1e-6)
    # convertir a km/h
    assert math.isclose(convertir(62.5, 'Pa', 'km/h'), v * 3.6, rel_tol=1e-6)


# ---------------------------------------
# 5) Mayúsculas, minúsculas y espacios
# ---------------------------------------
def test_mayusculas_minusculas_espacios():
    assert math.isclose(convertir(10, ' M/S ', 'KM/H '), 36.0, rel_tol=1e-6)
    assert math.isclose(convertir(10, 'kPa', 'pa'), 10000.0, rel_tol=1e-6)


# ---------------------------------------
# 6) Densidad personalizada
# ---------------------------------------
def test_rho_personalizada():
    rho = 1.225
    q = 0.5 * rho * 10**2
    assert math.isclose(convertir(10, 'm/s', 'Pa', rho=rho), q, rel_tol=1e-6)


# ---------------------------------------
# 7) Conversiones inválidas
# ---------------------------------------
def test_conversion_invalidas():
    # velocidad → unidad desconocida
    with pytest.raises(ValueError):
        convertir(10, 'm/s', 'kg/m3')
    # presión → unidad desconocida
    with pytest.raises(ValueError):
        convertir(1000, 'Pa', 'bar')  # 'bar' no está en PRESION
