import pytest
import pandas as pd

from sunfer_clima.acciones.nieve.cte import NieveCTE


# =========================================================
# FIXTURES
# =========================================================

@pytest.fixture
def nieve_base():
    return NieveCTE(
        zona_nieve=3,
        altitud=450,
    )


# =========================================================
# TESTS DE INICIALIZACIÓN
# =========================================================

def test_inicializacion_correcta(nieve_base):
    assert nieve_base.zona_nieve == 3
    assert nieve_base.altitud == 450.0
    assert nieve_base.periodo_retorno == 25


# =========================================================
# VALIDACIONES
# =========================================================

@pytest.mark.parametrize("zona", [0, 8, -1])
def test_zona_nieve_invalida(zona):
    with pytest.raises(ValueError):
        NieveCTE(zona_nieve=zona, altitud=500)


@pytest.mark.parametrize("altitud", [-1, 2500])
def test_altitud_invalida(altitud):
    with pytest.raises(ValueError):
        NieveCTE(zona_nieve=3, altitud=altitud)


def test_periodo_retorno_invalido(nieve_base):
    with pytest.raises(ValueError):
        nieve_base.periodo_retorno = 0


# =========================================================
# TABLA AN.2 E INTERPOLACIÓN
# =========================================================

def test_nieve_tabla_inferior(nieve_base):
    # altitud 450 -> inferior 400 en zona 3 = 0.2
    assert nieve_base._nieve_tabla_inferior() == 0.2


def test_nieve_tabla_superior(nieve_base):
    # altitud 450 -> superior 500 en zona 3 = 0.3
    assert nieve_base._nieve_tabla_superior() == 0.3


def test_interpolacion_nieve50(nieve_base):
    # entre 400 (0.2) y 500 (0.3)
    # para 450 -> 0.25
    assert nieve_base._nieve50() == pytest.approx(0.25, rel=1e-3)


def test_incremento_por_altitud(nieve_base):
    # 0.25 - 0.2 = 0.05
    assert nieve_base._incremento_por_altitud() == pytest.approx(0.05, rel=1e-3)


# =========================================================
# CÁLCULO PRINCIPAL
# =========================================================

def test_calculo_completo(nieve_base):
    nieve_base.calcular()

    assert nieve_base.obtener("PAIS") == "ESPAÑA"
    assert nieve_base.obtener("ZONA_NIEVE") == "3"
    assert nieve_base.obtener("ALTITUD") == 450.0

    assert nieve_base.obtener("SK50") == pytest.approx(0.25, rel=1e-3)
    assert nieve_base.obtener("SKN") > 0
    assert nieve_base.obtener("SAD") > 0
    assert nieve_base.obtener("CES1") == 1.0


# =========================================================
# TABLA DE RESULTADOS
# =========================================================

def test_tabla_devuelve_dataframe(nieve_base):
    nieve_base.calcular()
    df = nieve_base.tabla()

    assert isinstance(df, pd.DataFrame)
    assert not df.empty


def test_tabla_contiene_resultados(nieve_base):
    nieve_base.calcular()
    df = nieve_base.tabla()

    contenido = df.to_string()
    assert "Carga de nieve accidental" in contenido


# =========================================================
# CASOS AUXILIARES / BRANCHES
# =========================================================

def test_cprob_periodo_menor_igual_1():
    nieve = NieveCTE(3, 500)
    nieve.periodo_retorno = 1
    assert nieve._cprob() == 0.41


def test_cprob_periodo_normal():
    nieve = NieveCTE(3, 500)
    nieve.periodo_retorno = 25

    valor = nieve._cprob()

    assert 0 < valor < 1


def test_tabla_keyerror_branch(monkeypatch):
    nieve = NieveCTE(3, 500)
    nieve.calcular()

    def fake_obtener(_):
        raise KeyError("clave inexistente")

    monkeypatch.setattr(nieve, "obtener", fake_obtener)

    df = nieve.tabla()

    assert "-" in df.to_string()


def test_nieve50_altitud_exacta_tabla():
    nieve = NieveCTE(3, 400)
    assert nieve._nieve50() == 0.2


def test_nieve_tabla_inferior_superior_con_guion():
    # zona 1, altitud 1800 -> tabla AN.2 tiene "-"
    nieve = NieveCTE(zona_nieve=1, altitud=1800)

    valor_superior = nieve._nieve_tabla_superior()
    valor_inferior = nieve._nieve_tabla_inferior()

    assert valor_superior == "-"
    assert valor_inferior == "-"

    with pytest.raises(TypeError):
        nieve._incremento_por_altitud()


# =========================================================
# MÉTODOS AUXILIARES
# =========================================================

def test_densidad_nieve():
    nieve = NieveCTE(3, 500)
    assert nieve._densidad_nieve() == 150


def test_coeficiente_variacion_v():
    nieve = NieveCTE(3, 500)
    assert nieve._V() == 0.2


def test_parametros_disponibles():
    nieve = NieveCTE(3, 500)
    nieve.calcular()

    params = nieve.parametros()

    assert isinstance(params, dict)
    assert "SK50" in params
    assert "SAD" in params


def test_ver_parametros(capsys):
    nieve = NieveCTE(3, 500)
    nieve.calcular()

    nieve.ver_parametros()

    captured = capsys.readouterr()

    assert "SK50" in captured.out
    assert "SAD" in captured.out


def test_normativa():
    nieve = NieveCTE(3, 500)
    assert nieve.normativa() == "CTE DB-SE-AE — Nieve"

