import pytest
import pandas as pd

from sunfer_clima.acciones.nieve.es import NieveEurocodeES


# --------------------------------------------------------------------------------------
# TESTS DE INICIALIZACIÓN
# --------------------------------------------------------------------------------------
def test_init_ok():
    n = NieveEurocodeES(3, 500)

    assert n.zona_nieve == 3
    assert n.altitud == 500


def test_zona_invalida():
    with pytest.raises(ValueError):
        NieveEurocodeES(0, 500)

    with pytest.raises(ValueError):
        NieveEurocodeES(8, 500)


def test_altitud_invalida():
    with pytest.raises(ValueError):
        NieveEurocodeES(3, -1)

    with pytest.raises(ValueError):
        NieveEurocodeES(3, 2000)


# --------------------------------------------------------------------------------------
# TESTS DE PROPIEDADES
# --------------------------------------------------------------------------------------
def test_periodo_retorno_default():
    n = NieveEurocodeES(3, 500)
    assert n.periodo_retorno == 25


def test_periodo_retorno_setter():
    n = NieveEurocodeES(3, 500)
    n.periodo_retorno = 50

    assert n.periodo_retorno == 50


def test_periodo_retorno_invalido():
    n = NieveEurocodeES(3, 500)

    with pytest.raises(ValueError):
        n.periodo_retorno = 0

    with pytest.raises(ValueError):
        n.periodo_retorno = -1


# --------------------------------------------------------------------------------------
# TESTS DE MÉTODOS PRIVADOS
# --------------------------------------------------------------------------------------
def test_densidad_nieve():
    n = NieveEurocodeES(3, 700)
    assert n._densidad_nieve() == 150

    n.altitud = 900
    assert n._densidad_nieve() == 200

    n.altitud = 1200
    assert n._densidad_nieve() == 270

    n.altitud = 1600
    assert n._densidad_nieve() == 330


def test_V_constante():
    n = NieveEurocodeES(3, 500)
    assert n._V() == 0.2


def test_cprob_valido():
    n = NieveEurocodeES(3, 500)
    assert n._cprob() > 0


def test_nieve_tabla_inferior_superior():
    n = NieveEurocodeES(1, 750)

    inferior = n._nieve_tabla_inferior()
    superior = n._nieve_tabla_superior()

    assert inferior > 0
    assert superior > 0
    assert superior >= inferior


def test_nieve50_interpolacion():
    n = NieveEurocodeES(1, 750)

    s = n._nieve50()

    assert s > 0


def test_nieve50_altitud_exacta():
    n = NieveEurocodeES(1, 800)

    s = n._nieve50()
    s_tabla = n._TABLA_AN2[800][1]

    assert s == pytest.approx(s_tabla)


def test_incremento_por_altitud():
    n = NieveEurocodeES(1, 750)

    incremento = n._incremento_por_altitud()

    assert incremento >= 0


def test_ces1():
    n = NieveEurocodeES(3, 500)
    assert n._Ces1() == 1.0


# --------------------------------------------------------------------------------------
# TESTS DE CÁLCULO
# --------------------------------------------------------------------------------------
def test_calcular():
    n = NieveEurocodeES(3, 750)

    n.calcular()

    assert n.calculo_realizado is True
    assert isinstance(n._datos, dict)
    assert "SKN" in n._datos
    assert "SAD" in n._datos


def test_calcular_valores_coherentes():
    n = NieveEurocodeES(3, 750)

    n.calcular()

    assert n._datos["SK50"] >= n._datos["CARGA_BASE"]
    assert n._datos["SKN"] > 0
    assert n._datos["SAD"] > 0


# --------------------------------------------------------------------------------------
# TESTS DE TABLA
# --------------------------------------------------------------------------------------
def test_tabla_devuelve_dataframe():
    n = NieveEurocodeES(3, 750)
    n.calcular()

    df = n.tabla()

    assert isinstance(df, pd.DataFrame)


def test_tabla_sin_calcular():
    n = NieveEurocodeES(3, 750)

    with pytest.raises(Exception):
        n.tabla()


def test_tabla_contiene_resultados():
    n = NieveEurocodeES(3, 750)
    n.calcular()

    df = n.tabla()

    texto = df.to_string()

    assert "Carga de nieve" in texto or "SKN" in texto


# --------------------------------------------------------------------------------------
# TESTS DE MÉTODOS PÚBLICOS
# --------------------------------------------------------------------------------------
def test_normativa():
    n = NieveEurocodeES(3, 500)
    assert "1991-1-3" in n.normativa()


def test_consultar_zonas(capsys):
    n = NieveEurocodeES(3, 500)

    n.consultar_zonas()

    captured = capsys.readouterr()
    assert "Zona" in captured.out


def test_consultar_zonas_output(capsys):
    from sunfer_clima.acciones.nieve.es import NieveEurocodeES

    nieve = NieveEurocodeES(3, 500)
    nieve.consultar_zonas()

    captured = capsys.readouterr()

    assert "ZONAS DE NIEVE" in captured.out
    assert "Zona 1" in captured.out
    assert "Zona 7" in captured.out


def test_metodos_consulta_no_implementados_base():
    from sunfer_clima.acciones.viento.base import EurocodeViento

    class MinimalFull(EurocodeViento):
        _ZONAS_VIENTO = {"A": 26.0}

        def _velocidad_basica_fundamental(self): return 26.0
        def _n(self): return 0.5
        def _K(self): return 0.2
        def _Kr(self): return 0.2
        def _K1(self): return 1.0
        def normativa(self): return "X"
        def _z0(self): return 0.05
        def _zmin(self): return 2.0
        def calcular(self): pass
        def tabla(self): return {}

        # 👇 cubrir abstractos nuevos
        def consultar_zonas(self): return ["A"]
        def consultar_terrenos(self): return ["I", "II"]
        def consultar_parametros(self): return {}

    v = MinimalFull("A", 10)

    assert v.consultar_zonas() == ["A"]
    assert v.consultar_terrenos() == ["I", "II"]
    assert v.consultar_parametros() == {}


def test_tabla_keyerror_handling():
    from sunfer_clima.acciones.nieve.es import NieveEurocodeES

    nieve = NieveEurocodeES(3, 750)
    nieve.calcular()

    # Eliminamos una clave para forzar el except
    del nieve._datos["SKN"]

    df = nieve.tabla()

    # Debe aparecer "-" en algún sitio
    assert "-" in df.to_string()



def test_nieve_interpolacion_altitud_exacta():
    from sunfer_clima.acciones.nieve.es import NieveEurocodeES

    nieve = NieveEurocodeES(3, 1000)  # está en tabla exacta

    assert nieve._nieve50() == nieve._nieve_tabla_inferior()


def test_nieve_tablas_extremos():
    from sunfer_clima.acciones.nieve.es import NieveEurocodeES

    nieve = NieveEurocodeES(2, 0)

    assert nieve._nieve_tabla_inferior() >= 0
    assert nieve._nieve_tabla_superior() >= 0

