import pytest

from sunfer_clima.utilidades.topografia import (
    _calcular_factor_final,
    _calcular_s_acantilado_sotavento,
    _calcular_s_barlovento,
    _calcular_s_colina_sotavento,
    _coeficiente_a_polinomico,
    calcular_co,
)


# =========================================================
# HELPERS PRIVADOS
# =========================================================
def test_coeficiente_a_polinomico():
    valor = _coeficiente_a_polinomico(0.2)
    assert valor == pytest.approx(0.69602032, rel=1e-6)


def test_calcular_s_barlovento_valido():
    s = _calcular_s_barlovento(-0.5, 0.2)
    assert s > 0


def test_calcular_s_barlovento_fuera_rango():
    s = _calcular_s_barlovento(-2.0, 0.2)
    assert s == 0.0


def test_calcular_s_acantilado_sotavento_interpolado():
    s = _calcular_s_acantilado_sotavento(0.05, 0.2)
    assert isinstance(s, float)


def test_calcular_s_acantilado_sotavento_logaritmico():
    s = _calcular_s_acantilado_sotavento(0.5, 0.2)
    assert isinstance(s, float)


def test_calcular_s_acantilado_sotavento_fuera_rango():
    s = _calcular_s_acantilado_sotavento(5.0, 0.2)
    assert s == 0.0


def test_calcular_s_colina_sotavento_valido():
    s = _calcular_s_colina_sotavento(0.5, 0.2)
    assert s > 0


def test_calcular_s_colina_sotavento_fuera_rango():
    s = _calcular_s_colina_sotavento(5.0, 0.2)
    assert s == 0.0


def test_factor_final_phi_bajo():
    assert _calcular_factor_final(0.04, 1.0) == 1.0


def test_factor_final_phi_medio():
    valor = _calcular_factor_final(0.1, 0.5)
    assert valor == pytest.approx(1.1)


def test_factor_final_phi_alto():
    valor = _calcular_factor_final(0.3, 0.5)
    assert valor == pytest.approx(1.3)


# =========================================================
# API PÚBLICA
# =========================================================
def test_tipo_accidente_invalido():
    with pytest.raises(ValueError, match="Tipo de accidente inválido"):
        calcular_co(
            tipo_accidente="montaña",
            altura_efectiva_accidente=10,
            longitud_pendiente_barlovento=100,
            longitud_pendiente_sotavento=100,
            distancia_horizontal_estructura_cresta=0,
            altura_estructura=10,
        )


def test_sin_efecto_topografico():
    co = calcular_co(
        tipo_accidente="colina_barlovento",
        altura_efectiva_accidente=2,
        longitud_pendiente_barlovento=100,
        longitud_pendiente_sotavento=100,
        distancia_horizontal_estructura_cresta=0,
        altura_estructura=10,
    )
    assert co == 1.0


def test_colina_barlovento():
    co = calcular_co(
        tipo_accidente="colina_barlovento",
        altura_efectiva_accidente=10,
        longitud_pendiente_barlovento=100,
        longitud_pendiente_sotavento=100,
        distancia_horizontal_estructura_cresta=-50,
        altura_estructura=20,
    )
    assert co > 1.0


def test_acantilado_barlovento():
    co = calcular_co(
        tipo_accidente="acantilado_barlovento",
        altura_efectiva_accidente=30,
        longitud_pendiente_barlovento=50,
        longitud_pendiente_sotavento=100,
        distancia_horizontal_estructura_cresta=-25,
        altura_estructura=20,
    )
    assert co > 1.0


def test_colina_sotavento():
    co = calcular_co(
        tipo_accidente="colina_sotavento",
        altura_efectiva_accidente=10,
        longitud_pendiente_barlovento=100,
        longitud_pendiente_sotavento=100,
        distancia_horizontal_estructura_cresta=50,
        altura_estructura=20,
    )
    assert co > 1.0


def test_acantilado_sotavento():
    co = calcular_co(
        tipo_accidente="acantilado_sotavento",
        altura_efectiva_accidente=10,
        longitud_pendiente_barlovento=100,
        longitud_pendiente_sotavento=100,
        distancia_horizontal_estructura_cresta=50,
        altura_estructura=20,
    )
    assert co == pytest.approx(0.8867343382860022, rel=1e-6)


def test_fuera_rango_geom():
    co = calcular_co(
        tipo_accidente="colina_sotavento",
        altura_efectiva_accidente=10,
        longitud_pendiente_barlovento=100,
        longitud_pendiente_sotavento=100,
        distancia_horizontal_estructura_cresta=500,
        altura_estructura=20,
    )
    assert co == 1.0


def test_longitudes_cero():
    co = calcular_co(
        tipo_accidente="colina_barlovento",
        altura_efectiva_accidente=1,
        longitud_pendiente_barlovento=0,
        longitud_pendiente_sotavento=0,
        distancia_horizontal_estructura_cresta=0,
        altura_estructura=1,
    )
    assert isinstance(co, float)