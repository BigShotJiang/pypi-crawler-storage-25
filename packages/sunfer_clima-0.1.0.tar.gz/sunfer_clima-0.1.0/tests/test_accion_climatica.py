import pytest
from sunfer_clima.acciones.comunes.accion_climatica import AccionClimatica


class DummyAccion(AccionClimatica):
    def calcular(self):
        self._datos = {"TEST": 123}
        self._parametros = {"TEST": "Parámetro de prueba"}
        self.calculo_realizado = True

    def tabla(self):
        return "tabla"

    def normativa(self):
        return "normativa dummy"


def test_no_instanciable():
    with pytest.raises(TypeError):
        AccionClimatica()


def test_invalidar_calculo():
    d = DummyAccion()
    d.calcular()

    assert d.calculo_realizado is True
    assert d._datos["TEST"] == 123

    d._invalidar_calculo()

    assert d.calculo_realizado is False
    assert d._datos == {}


def test_verificar_calculado_ok():
    d = DummyAccion()
    d.calcular()

    # no debe lanzar excepción
    d._verificar_calculado()


def test_verificar_calculado_error():
    d = DummyAccion()

    with pytest.raises(RuntimeError):
        d._verificar_calculado()


def test_obtener_ok():
    d = DummyAccion()
    d.calcular()

    assert d.obtener("test") == 123
    assert d.obtener("TEST") == 123


def test_obtener_sin_calcular():
    d = DummyAccion()

    with pytest.raises(RuntimeError):
        d.obtener("TEST")


def test_obtener_clave_inexistente():
    d = DummyAccion()
    d.calcular()

    with pytest.raises(KeyError):
        d.obtener("NO_EXISTE")


def test_parametros_ok():
    d = DummyAccion()
    d.calcular()

    params = d.parametros()

    assert isinstance(params, dict)
    assert params["TEST"] == "Parámetro de prueba"


def test_parametros_sin_calcular():
    d = DummyAccion()

    with pytest.raises(RuntimeError):
        d.parametros()


def test_ver_parametros(capsys):
    d = DummyAccion()
    d.calcular()

    d.ver_parametros()

    captured = capsys.readouterr()

    assert "Parámetros disponibles:" in captured.out
    assert "TEST: Parámetro de prueba" in captured.out

def test_ver_parametros_sin_calcular():
    d = DummyAccion()

    with pytest.raises(RuntimeError):
        d.ver_parametros()

