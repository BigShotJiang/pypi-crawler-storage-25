from abc import ABC, abstractmethod

class AccionClimatica(ABC):
    """
    Clase base abstracta para acciones climáticas del Eurocódigo.
    """
    def __init__(self):
        self._datos = {}
        self._parametros = {}
        self.calculo_realizado = False  # uso consistente con EurocodeViento

    @abstractmethod # pragma: no cover
    def calcular(self):
        """
        Realiza el cálculo de la acción climática.
        Debe implementarse en clases derivadas.
        """
        pass

    @abstractmethod # pragma: no cover
    def tabla(self):
        """
        Genera una tabla de resultados del cálculo.
        Debe implementarse en clases derivadas.
        """
        pass

    @abstractmethod # pragma: no cover
    def normativa(self):
        """
        Retorna la normativa aplicable.
        """
        pass

# METODOS PRIVADOS COMUNES -------------------------------------------------------------------------------------------------------------------------------------------------
    def _invalidar_calculo(self):
        self._datos.clear()
        self.calculo_realizado = False
    
    def _verificar_calculado(self):
        if not self.calculo_realizado:
            raise RuntimeError("Debe llamar a calcular() antes de acceder a resultados.")

# METODOS PÚBLICOS COMUNES --------------------------------------------------------------------------------------------------------------------------------------------------    
    def obtener(self, clave: str):
        """
        Devuelve el valor asociado a una clave de resultados.
        """
        if not self.calculo_realizado:
            raise RuntimeError("El cálculo no ha sido ejecutado. Llame primero a calcular().")
        clave = clave.upper()
        try:
            return self._datos[clave]
        except KeyError:
            claves_disponibles = ", ".join(self._datos.keys())
            raise KeyError(
                f"Clave '{clave}' no encontrada. Claves disponibles: {claves_disponibles}"
            )

    def parametros(self)-> dict:
        """
        Devuelve un diccionario de las claves:descripcion disponibles en los resultados.
        """
        if not self.calculo_realizado:
            raise RuntimeError("El cálculo no ha sido ejecutado. Llame primero a calcular().")
        return self._parametros
    
    def ver_parametros(self):
        self._verificar_calculado()
        print("Parámetros disponibles:")
        for clave, descripcion in self._parametros.items():
            print(f"{clave}: {descripcion}")
    
    