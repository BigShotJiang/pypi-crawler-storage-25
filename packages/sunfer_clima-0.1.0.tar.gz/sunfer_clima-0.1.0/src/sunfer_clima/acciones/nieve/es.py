"""
MÓDULO: es
===========================

Implementación del cálculo de acciones de nieve en España según:

    • UNE-EN 1991-1-3:2018
      Eurocódigo 1: Acciones en estructuras.
      Parte 1-3: Acciones generales. Acciones de nieve.
    
    • AN/UNE-EN 1991-1-3
      Anejo Nacional Español (NDP – Nationally Determined Parameters).

Autor: Rafa Crespo
Versión: 1.1
"""

from sunfer_clima.acciones.comunes.accion_climatica import AccionClimatica
import pandas as pd
import math


class NieveEurocodeES(AccionClimatica):
    """
        Cálculo de acciones de nieve en España según Eurocódigo.

        Implementa el cálculo de la carga de nieve sobre el terreno conforme a:

            - UNE-EN 1991-1-3:2018 — Eurocódigo 1 (Acciones de nieve)
            - AN/UNE-EN 1991-1-3 — Anejo Nacional Español

        La carga de nieve se obtiene a partir de la Tabla AN.2 del Anejo Nacional,
        en función de la zona climática y la altitud, aplicando interpolación lineal
        entre valores tabulados.

        Parameters
        ----------
        zona_nieve : int
            Zona climática de nieve según Anejo Nacional Español.
            Valores permitidos: 1 a 7.

        altitud : float
            Altitud de la ubicación en metros.
            Rango válido: 0 ≤ altitud ≤ 1800 m.

        Raises
        ------
        ValueError
            Si la zona de nieve no está entre 1 y 7.
            Si la altitud está fuera del rango permitido.
            Si el periodo de retorno no es positivo.

        Notes
        -----
        - La carga base de nieve se obtiene de la Tabla AN.2.
        - Para altitudes intermedias se realiza interpolación lineal.
        - El periodo de retorno por defecto es 25 años.
        - Se aplica un ajuste probabilístico mediante distribución tipo Gumbel.
        - La densidad de la nieve depende de la altitud.

        Tabla AN.2 (resumen):
            Relación entre altitud y carga de nieve base (kN/m²),
            dependiente de la zona climática (1–7).

        Attributes
        ----------
        zona_nieve : int
            Zona climática de nieve.

        altitud : float
            Altitud de la ubicación en metros.

        periodo_retorno : float
            Periodo de retorno en años.

        calculo_realizado : bool
            Indica si el cálculo ha sido ejecutado.

        Methods
        -------
        calcular()
            Ejecuta el cálculo completo de la carga de nieve.

        tabla()
            Devuelve un pandas.DataFrame con los resultados formateados.

        normativa()
            Devuelve la normativa aplicada como texto.

        Examples
        --------
        >>> nieve = NieveEurocodeES(zona_nieve=3, altitud=750)
        >>> nieve.calcular()
        >>> df = nieve.tabla()
        >>> print(df)

    """

    # Tabla AN.2 Carga de nieve en función de la altitud (kN/m²)
    _TABLA_AN2 = {
        0:    {1:0.3, 2:0.4, 3:0.2, 4:0.2, 5:0.2, 6:0.2, 7:0.0},
        200:  {1:0.5, 2:0.5, 3:0.2, 4:0.2, 5:0.3, 6:0.2, 7:0.0},
        400:  {1:0.6, 2:0.6, 3:0.2, 4:0.3, 5:0.4, 6:0.2, 7:0.0},
        500:  {1:0.7, 2:0.7, 3:0.3, 4:0.4, 5:0.4, 6:0.3, 7:0.0},
        600:  {1:0.9, 2:0.9, 3:0.3, 4:0.5, 5:0.5, 6:0.4, 7:0.0},
        700:  {1:1.0, 2:1.0, 3:0.4, 4:0.6, 5:0.6, 6:0.5, 7:0.0},
        800:  {1:1.2, 2:1.1, 3:0.5, 4:0.8, 5:0.7, 6:0.7, 7:0.0},
        900:  {1:1.4, 2:1.3, 3:0.6, 4:1.0, 5:0.8, 6:0.9, 7:0.0},
        1000: {1:1.7, 2:1.5, 3:0.7, 4:1.2, 5:0.9, 6:1.2, 7:0.0},
        1200: {1:2.3, 2:2.0, 3:1.1, 4:1.9, 5:1.3, 6:2.0, 7:0.0},
        1400: {1:3.2, 2:2.6, 3:1.7, 4:3.0, 5:1.8, 6:3.3, 7:0.0},
        1600: {1:4.3, 2:3.5, 3:2.6, 4:4.6, 5:2.5, 6:4.3, 7:0.0},
        1800: {1:4.3, 2:4.6, 3:4.0, 4:4.6, 5:2.5, 6:4.3, 7:0.0},
    }

    def __init__(self, zona_nieve: int, altitud: float):

        super().__init__()

        self._zona_nieve: int | None = None
        self._altitud: float | None = None
        self._periodo_retorno: float = 25  # Valor normativo por defecto

        self.zona_nieve = zona_nieve
        self.altitud = altitud

    # ----------  PROPIEDADES  ------------------------------------------------------------------------------------

    @property
    def zona_nieve(self) -> int:
        return self._zona_nieve
    @zona_nieve.setter
    def zona_nieve(self, value: int):
        if value not in range(1, 8):
            raise ValueError("La zona de nieve debe estar entre 1 y 7.")
        self._zona_nieve = value
        self._invalidar_calculo()

    @property
    def altitud(self) -> float:
        return self._altitud
    @altitud.setter
    def altitud(self, value: float):
        if value < 0 or value > 1800:
            raise ValueError("La altitud debe estar entre 0 y 1800 m.")
        self._altitud = float(value)
        self._invalidar_calculo()

    @property
    def periodo_retorno(self) -> float:
        return self._periodo_retorno
    @periodo_retorno.setter
    def periodo_retorno(self, value: float):
        if value <= 0:
            raise ValueError("El periodo de retorno debe ser mayor que 0 años.")
        self._periodo_retorno = float(value)
        self._invalidar_calculo()
    

# METODOS PRIVADOS ---------------------------------------------------------------------------------------------------- 
    def _densidad_nieve(self) -> float:
        if self.altitud < 800:
            return 150 #kg/m³
        elif self.altitud < 1000:
            return 200 #kg/m³
        elif self.altitud < 1500:
            return 270 #kg/m³
        else:
            return 330 #kg/m³

    def _V(self) -> float:
        return 0.2

    def _cprob(self) -> float:
        """
        Factor de probabilidad según expresión tipo Gumbel.
        """
        Pn = 1 / self.periodo_retorno  # Probabilidad de excedencia anual
        # Factor X según la fórmula
        numerador =1-((self._V()*((math.sqrt(6)) / math.pi)) * (math.log(-math.log(1 - Pn)) + 0.57722))
        denominador = (1 + 2.5923 * self._V())
        X = numerador / denominador
        return X

    def _nieve_tabla_inferior(self) -> float:
        """
        Devuelve la carga de nieve base de la tabla AN.2
        tomando la altitud inmediatamente inferior.
        """
        altitudes = sorted(self._TABLA_AN2.keys())
        # Buscar la altitud de tabla inmediatamente inferior
        altitud_tabla = max(altitud for altitud in altitudes if altitud <= self.altitud)
        # Devolver el valor para la zona de nieve
        return self._TABLA_AN2[altitud_tabla][self.zona_nieve]
    
    def _nieve_tabla_superior(self) -> float:
        """
        Devuelve la carga de nieve base de la tabla AN.2
        tomando la altitud inmediatamente superior.
        """
        altitudes = sorted(self._TABLA_AN2.keys())
        # Buscar la altitud de tabla inmediatamente superior
        altitud_tabla = min(a for a in altitudes if a >= self.altitud)
        # Devolver el valor para la zona de nieve
        return self._TABLA_AN2[altitud_tabla][self.zona_nieve]
    
    def _nieve50(self) -> float:
        """
        Devuelve la carga de nieve base interpolada
        entre las altitudes inferior y superior de la tabla.
        """
        h = self.altitud
        altitudes = sorted(self._TABLA_AN2.keys())
        h1 = max(altitud for altitud in altitudes if altitud <= self.altitud)
        h2 = altitud_tabla = min(a for a in altitudes if a >= self.altitud)
        s1 = self._nieve_tabla_inferior()
        s2 = self._nieve_tabla_superior()
        # Si coincide exactamente con una altitud de la tabla
        if h1 == h2:
            return s1
        # Interpolación lineal
        return s1 + (s2 - s1) * (h - h1) / (h2 - h1)
    
    def _incremento_por_altitud(self) -> float:
        """
        Incremento de carga de nieve debido a la altitud respecto
        al valor base de la altitud inferior de la tabla.
        """
        nieve_interp = self._nieve50()  # Carga de nieve interpolada para la altitud dada
        nieve_base = self._nieve_tabla_inferior()  # la de altitud inferior
        return nieve_interp - nieve_base

    def _Ces1(self) -> float:
        """
        Coeficiente de carga excepcional
        """
        return 1.0


# METODOS PÚBLICOS -------------------------------------------------------------------------------------------------------

    def calcular(self):

        sk_tabla = self._nieve_tabla_inferior()   # Carga de nieve base de la tabla AN.2 para altitud inferior
        incremento = self._incremento_por_altitud()  # Incremento por altitud respecto al valor base de la tabla
        sk = sk_tabla + incremento  # Carga de nieve para la altitud de
        cprob = self._cprob()  # Factor de probabilidad
        skn = sk * cprob  # Carga de nieve sobre el terreno
        Ces1 = self._Ces1()  # Coeficiente de carga excepcional
        sad = skn * Ces1  # Carga de nieve accidentalsobre la estructura (con coeficiente de carga excepcional)


        self._datos = {
            "PAIS": "ESPAÑA",
            "NORMATIVA": "UNE-EN 1991-1-3:2018",
            "DENSIDAD_NIEVE": self._densidad_nieve(),
            "RETORNO": self.periodo_retorno,
            "ZONA_NIEVE": str(self.zona_nieve),
            "ALTITUD": self.altitud,
            "CARGA_BASE": round(sk_tabla, 3),
            "INCREMENTO": round(incremento, 3),
            "SK50": round(sk, 3),
            "V": self._V(),
            "CPROB": round(cprob, 5),
            "SKN": round(skn, 3),
            "CES1": round(Ces1, 3),
            "SAD": round(sad, 3)
        }

        self._parametros = {
            "PAIS": "Descripción del país",
            "NORMATIVA": "Normativa aplicada para el cálculo",
            "DENSIDAD_NIEVE": "Densidad de la nieve en kg/m³",
            "RETORNO": "Periodo de retorno en años",
            "ZONA_NIEVE": "Zona climatica de nieve (1 a 7)",
            "ALTITUD": "Altitud de la ubicación en metros",
            "CARGA_BASE": "Valor de carga de nieve base según tabla AN.2 para la altitud inferior",
            "INCREMENTO": "Incremento por altitud interpolada",
            "SK50": "Carga de nieve para la altitud de la ubicación (50 años)",
            "V": "Coeficiente de variación por retorno",
            "CPROB": "Factor de retorno",
            "SKN": "Carga de nieve sobre el terreno para el periodo de retorno considerado",
            "CES1": "Coeficiente de carga excepcional",
            "SAD": "Carga de nieve accidental sobre el terreno para el periodo de retorno considerado"
        }

        self.calculo_realizado = True

    def tabla(self):
        """
        Devuelve un DataFrame con los resultados estructurados en bloques, con encabezados intercalados para mostrar en Streamlit.
        """
        # Asegurar que el calculo està actualizado
        self._verificar_calculado()
        # Getter seguro: no lanza excepción
        def g(clave, dec=5):
            try:
                valor = self.obtener(clave)
                if isinstance(valor, (int, float)):
                    return f"{valor:.{dec}f}"
                return valor
            except KeyError:
                return "-"
        filas = [] 
        # ------- Configuracion -------------------------------------------------------
        filas.append(("CONFIGURACIÓN GENERAL", "", ""))
        filas.append(("País:", "España", ""))
        filas.append(("Normativa:", "UNE EN 1991-1-3", ""))
        filas.append(("Densidad de la nieve [ρ]:", g("DENSIDAD_NIEVE",0), "kg/m³"))
        filas.append(("Periodo de retorno [T]:", g("RETORNO",0), "años"))
        filas.append(("", "", ""))
        # ------- Características de la instalación ------------------------------------
        filas.append(("CARACTERÍSTICAS DE LA INSTALACIÓN", "", ""))
        filas.append(("Zona climática de nieve:", g("ZONA_NIEVE"), ""))
        filas.append(("Altitud de la ubicación:", g("ALTITUD",2), "m"))
        filas.append(("", "", ""))
        # ------- Resultados principales -----------------------------------------------
        filas.append(("RESULTADOS PRINCIPALES", "", ""))
        filas.append(("Carga de nieve sobre el terreno [skn]:", g("SKN",2), "kN/m²"))
        filas.append(("Carga de nieve accidental [sad]:", g("SAD",2), "kN/m²"))
        filas.append(("", "", ""))
        # ------- Cálculos intermedios y coeficientes empleados ------------------------
        filas.append(("CÁLCULOS INTERMEDIOS Y COEFICIENTES EMPLEADOS", "", ""))
        filas.append(("Carga de nieve base de referencia [s50 Tabla AN.2]", g("CARGA_BASE",2), ""))
        filas.append(("Incremento por altitud interpolada", g("INCREMENTO",2), ""))
        filas.append(("Carga de nieve para la altitud de la ubicación (50 años) [sk]", g("SK50",2), "kN/m²"))
        filas.append(("Coeficiente de variación por retorno [V]", g("V",2), ""))
        filas.append(("Factor de retorno [cprob]", g("CPROB",3), ""))
        filas.append(("Coeficiente de carga excepcional [Ces1]", g("CES1",2), ""))

        df = pd.DataFrame(filas, columns = ["","",""])
        return df

    def normativa(self):
        return "UNE-EN 1991-1-3:2018"
    
    def consultar_zonas(self):
        print("ZONAS DE NIEVE (según ANEXO NACIONAL):")
        zonas = [1,2,3,4,5,6,7]
        for zona in zonas:
            print(f"Zona {zona}")