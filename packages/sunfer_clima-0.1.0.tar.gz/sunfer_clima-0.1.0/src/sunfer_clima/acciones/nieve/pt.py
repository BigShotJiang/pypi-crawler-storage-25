"""
MÓDULO: pt
===========================

Implementación del cálculo de acciones de nieve en Portugal según:

    • NP-EN 1991-1-3:2009
      Eurocódigo 1: Acciones en estructuras.
      Parte 1-3: Acciones generales. Acciones de nieve.
    
    • AN/NP-EN 1991-1-3
      Anejo Nacional Portugués (NDP – Nationally Determined Parameters).

Autor: Rafa Crespo
Versión: 1.11
"""

from sunfer_clima.acciones.comunes.accion_climatica import AccionClimatica
import pandas as pd
import math


class NieveEurocodePT(AccionClimatica):
    """
    Cálculo de cargas de nieve en Portugal según Eurocódigo.

    Parameters
    ----------
    zona_nieve : str | int
        Zona climática de nieve ("Z1", "Z2", "Z3", 1, 2, 3)

    altitud : float
        Altitud en metros (0 - 1800)

    Notes
    -----
    - El periodo de retorno por defecto es 25 años.
    """

    _CZ = {
        "Z1": 0.3,
        "Z2": 0.2,
        "Z3": 0.1
    }

    def __init__(self, zona_nieve: str | int, altitud: float):
        super().__init__()

        self._zona_nieve: str | None = None
        self._altitud: float | None = None
        self._periodo_retorno: float = 25.0

        self.zona_nieve = zona_nieve
        self.altitud = altitud

    # ---------- PROPIEDADES ------------------------------------------------------

    @property
    def zona_nieve(self) -> str:
        return self._zona_nieve

    @zona_nieve.setter
    def zona_nieve(self, value: str | int):
        value_str = str(value).upper()

        if value_str in ("1", "Z1"):
            self._zona_nieve = "Z1"
        elif value_str in ("2", "Z2"):
            self._zona_nieve = "Z2"
        elif value_str in ("3", "Z3"):
            self._zona_nieve = "Z3"
        else:
            raise ValueError("La zona de nieve debe ser Z1, Z2 o Z3.")

        self._invalidar_calculo()

    @property
    def altitud(self) -> float:
        return self._altitud

    @altitud.setter
    def altitud(self, value: float):
        if not (0 <= value <= 1800):
            raise ValueError("La altitud debe estar entre 0 y 1800 m.")
        self._altitud = float(value)
        self._invalidar_calculo()

    @property
    def periodo_retorno(self) -> float:
        return self._periodo_retorno

    @periodo_retorno.setter
    def periodo_retorno(self, value: float):
        if value <= 0:
            raise ValueError("El periodo de retorno debe ser mayor que 0.")
        self._periodo_retorno = float(value)
        self._invalidar_calculo()

    # ---------- MÉTODOS PRIVADOS -------------------------------------------------

    def _densidad_nieve(self) -> float:
        if self.altitud < 800:
            return 150
        elif self.altitud < 1000:
            return 200
        elif self.altitud < 1500:
            return 270
        return 330

    def _V(self) -> float:
        return 0.2

    def _cprob(self) -> float:
        """
        Factor de probabilidad según distribución tipo Gumbel.
        """
        Pn = 1 / self.periodo_retorno

        numerador = 1 - (
            self._V() * (math.sqrt(6) / math.pi)
            * (math.log(-math.log(1 - Pn)) + 0.57722)
        )
        denominador = 1 + 2.5923 * self._V()

        return numerador / denominador

    def _cz(self) -> float:
        return self._CZ[self.zona_nieve] # Coeficiente Cz en N/m2

    def _nieve50(self) -> float:
        return self._cz() * (1 + (self.altitud / 500) ** 2) * 1000 # Carga de nieve para periodo de retorno de 50 años en N/m2

    def _Ces1(self) -> float:
        return 2.5

    # ---------- MÉTODOS PÚBLICOS -------------------------------------------------

    def calcular(self):
        """
        Ejecuta el cálculo completo de la carga de nieve.
        """

        sk50 = self._nieve50()
        cprob = self._cprob()
        skn = sk50 * cprob
        Ces1 = self._Ces1()
        sad = skn * Ces1
        cz = self._cz()

        self._datos = {
            "PAIS": "PORTUGAL",
            "NORMATIVA": "NP-EN 1991-1-3:2009",
            "DENSIDAD_NIEVE": self._densidad_nieve(),
            "RETORNO": self.periodo_retorno,
            "ZONA_NIEVE": self.zona_nieve,
            "CZ": cz,
            "ALTITUD": self.altitud,
            "SK50": round(sk50, 3),
            "V": self._V(),
            "CPROB": round(cprob, 5),
            "SKN": round(skn, 3),
            "CES1": round(Ces1, 3),
            "SAD": round(sad, 3),
        }

        self._parametros = {
            "PAIS": "País de cálculo",
            "NORMATIVA": "Normativa aplicada",
            "DENSIDAD_NIEVE": "Densidad de la nieve [kg/m³]",
            "RETORNO": "Periodo de retorno [años]",
            "ZONA_NIEVE": "Zona climática",
            "CZ": "Coeficiente Cz",
            "ALTITUD": "Altitud [m]",
            "SK50": "Carga de nieve (T=50 años) [N/m²]",
            "V": "Coeficiente de variación",
            "CPROB": "Factor de probabilidad",
            "SKN": "Carga de nieve sobre el terreno [N/m²]",
            "CES1": "Coeficiente de carga excepcional",
            "SAD": "Carga de nieve accidental [N/m²]",
        }

        self.calculo_realizado = True

    def tabla(self) -> pd.DataFrame:
        """
        Devuelve un DataFrame con los resultados formateados.
        """
        self._verificar_calculado()

        def g(clave, dec=5):
            try:
                valor = self.obtener(clave)
                if isinstance(valor, (int, float)):
                    return f"{valor:.{dec}f}"
                return valor
            except KeyError:
                return "-"

        filas = []

        filas.append(("CONFIGURACIÓN GENERAL", "", ""))
        filas.append(("País:", "Portugal", ""))
        filas.append(("Normativa:", "NP EN 1991-1-3:2009", ""))
        filas.append(("Densidad de la nieve [ρ]:", g("DENSIDAD_NIEVE", 0), "kg/m³"))
        filas.append(("Periodo de retorno [T]:", g("RETORNO", 0), "años"))
        filas.append(("", "", ""))

        filas.append(("CARACTERÍSTICAS DE LA INSTALACIÓN", "", ""))
        filas.append(("Zona climática:", g("ZONA_NIEVE"), ""))
        filas.append(("Altitud:", g("ALTITUD", 2), "m"))
        filas.append(("", "", ""))

        filas.append(("RESULTADOS PRINCIPALES", "", ""))
        filas.append(("Carga de nieve [skn]:", g("SKN", 2), "N/m²"))
        filas.append(("Carga accidental [sad]:", g("SAD", 2), "N/m²"))
        filas.append(("", "", ""))

        filas.append(("CÁLCULOS INTERMEDIOS", "", ""))
        filas.append(("Coeficiente Cz:", g("CZ", 2), ""))
        filas.append(("Carga nieve (50 años):", g("SK50", 2), "N/m²"))
        filas.append(("Coeficiente V:", g("V", 2), ""))
        filas.append(("Factor cprob:", g("CPROB", 3), ""))
        filas.append(("Coeficiente Ces1:", g("CES1", 2), ""))

        return pd.DataFrame(filas, columns=["", "", ""])

    def normativa(self) -> str:
        return "NP-EN 1991-1-3:2009"