"""
MÓDULO: es
===========================

Implementación del cálculo de acciones de nieve en España según:

    • UNE-EN 1991-1-3:2018
      Eurocódigo 1: Acciones en estructuras.
      Parte 1-3: Acciones generales. Acciones de nieve.
    
    • AN/UNE-EN 1991-1-3
      Anejo Nacional Español (NDP – Nationally Determined Parameters).

Autor: Rafa Crespo
Versión: 1.1
"""

from sunfer_clima.acciones.comunes.accion_climatica import AccionClimatica
import pandas as pd
import math


class NieveCTE(AccionClimatica):
    """
    Calcula la acción de nieve en España según el CTE.

    Implementa el cálculo de la carga de nieve sobre el terreno y la carga
    accidental de nieve conforme a:

    - CTE DB-SE-AE

    La carga se obtiene a partir de la zona de nieve y la altitud,
    interpolando linealmente la tabla AN.2 cuando la cota no coincide
    exactamente con un valor tabulado.

    Args:
        zona_nieve (int): Zona climática de nieve (1 a 7).
        altitud (float): Altitud de la ubicación en metros sobre el nivel del mar.

    Raises:
        ValueError: Si la zona no está entre 1 y 7.
        ValueError: Si la altitud no está entre 0 y 2200 m.

    Example:
        >>> nieve = NieveCTE(zona_nieve=3, altitud=650)
        >>> nieve.calcular()
        >>> nieve.obtener("SKN")
        0.31
    """

    # Tabla AN.2 Carga de nieve en función de la altitud (kN/m²)
    _TABLA_AN2 = {
        0:    {1:0.3, 2:0.4, 3:0.2, 4:0.2, 5:0.2, 6:0.2, 7:0.2},
        200:  {1:0.5, 2:0.5, 3:0.2, 4:0.2, 5:0.3, 6:0.2, 7:0.2},
        400:  {1:0.6, 2:0.6, 3:0.2, 4:0.3, 5:0.4, 6:0.2, 7:0.2},
        500:  {1:0.7, 2:0.7, 3:0.3, 4:0.4, 5:0.4, 6:0.3, 7:0.2},
        600:  {1:0.9, 2:0.9, 3:0.3, 4:0.5, 5:0.5, 6:0.4, 7:0.2},
        700:  {1:1.0, 2:1.0, 3:0.4, 4:0.6, 5:0.6, 6:0.5, 7:0.2},
        800:  {1:1.2, 2:1.1, 3:0.5, 4:0.8, 5:0.7, 6:0.7, 7:0.2},
        900:  {1:1.4, 2:1.3, 3:0.6, 4:1.0, 5:0.8, 6:0.9, 7:0.2},
        1000: {1:1.7, 2:1.5, 3:0.7, 4:1.2, 5:0.9, 6:1.2, 7:0.2},
        1200: {1:2.3, 2:2.0, 3:1.1, 4:1.9, 5:1.3, 6:2.0, 7:0.2},
        1400: {1:3.2, 2:2.6, 3:1.7, 4:3.0, 5:1.8, 6:3.3, 7:0.2},
        1600: {1:4.3, 2:3.5, 3:2.6, 4:4.6, 5:2.5, 6:5.5, 7:0.2},
        1800: {1:"-", 2:4.6, 3:4.0, 4:"-", 5:"-", 6:9.3, 7:0.2},
        2200: {1:"-", 2:8.0, 3:"-", 4:"-", 5:"-", 6:"-", 7:"-"},
    }

    _ZONAS_NIEVE = [1, 2, 3, 4, 5, 6, 7]

    def __init__(self, zona_nieve: int, 
                 altitud: float, 
                 ):
        
        """
        Inicializa el cálculo de nieve para una ubicación concreta.

        Args:
            zona_nieve (int): Zona climática de nieve (1–7).
            altitud (float): Altitud de la ubicación en metros.
        """

        super().__init__()

        self._zona_nieve: int | None = None
        self._altitud: float | None = None
        self._periodo_retorno: float = 25  # Valor normativo por defecto
        self._pendiente_cubierta = None
        self._exposicion_viento = "normal"

        self.zona_nieve = zona_nieve
        self.altitud = altitud

    # ----------  PROPIEDADES  ------------------------------------------------------------------------------------

    @property
    def zona_nieve(self) -> int:
        """int: Zona climática de nieve asignada al emplazamiento."""
        return self._zona_nieve
    @zona_nieve.setter
    def zona_nieve(self, value: int):
        if value not in range(1, 8):
            raise ValueError("La zona de nieve debe estar entre 1 y 7.")
        self._zona_nieve = value
        self._invalidar_calculo()

    @property
    def altitud(self) -> float:
        """float: Altitud del emplazamiento en metros."""
        return self._altitud
    @altitud.setter
    def altitud(self, value: float):
        if value < 0 or value > 2200:
            raise ValueError("La altitud debe estar entre 0 y 2200 m.")
        self._altitud = float(value)
        self._invalidar_calculo()

    @property
    def periodo_retorno(self) -> float:
        """
        float: Periodo de retorno en años.

        Por defecto se utiliza 25 años, según el valor normativo adoptado
        en esta implementación.
        """
        return self._periodo_retorno
    @periodo_retorno.setter
    def periodo_retorno(self, value: float):
        if value <= 0:
            raise ValueError("El periodo de retorno debe ser mayor que 0 años.")
        self._periodo_retorno = float(value)
        self._invalidar_calculo()
    

# METODOS PRIVADOS ---------------------------------------------------------------------------------------------------- 
    def _densidad_nieve(self) -> float:
        return 150 #kg/m³

    def _V(self) -> float:
        return 0.2

    def _cprob(self) -> float:
        """
        Factor de probabilidad según expresión tipo Gumbel.
        """
        if self.periodo_retorno >0 and self.periodo_retorno <= 1:
            return 0.41
        else: 
            Pn = 1 / self.periodo_retorno  # Probabilidad de excedencia anual
            # Factor X según la fórmula
            numerador =1-((self._V()*((math.sqrt(6)) / math.pi)) * (math.log(-math.log(1 - Pn)) + 0.57722))
            denominador = (1 + 2.5923 * self._V())
            X = numerador / denominador
            return X

    def _nieve_tabla_inferior(self) -> float:
        """
        Devuelve la carga de nieve base de la tabla AN.2
        tomando la altitud inmediatamente inferior.
        """
        altitudes = sorted(self._TABLA_AN2.keys())
        # Buscar la altitud de tabla inmediatamente inferior
        altitud_tabla = max(altitud for altitud in altitudes if altitud <= self.altitud)
        # Devolver el valor para la zona de nieve
        return self._TABLA_AN2[altitud_tabla][self.zona_nieve]
    
    def _nieve_tabla_superior(self) -> float:
        """
        Devuelve la carga de nieve base de la tabla AN.2
        tomando la altitud inmediatamente superior.
        """
        altitudes = sorted(self._TABLA_AN2.keys())
        # Buscar la altitud de tabla inmediatamente superior
        altitud_tabla = min(a for a in altitudes if a >= self.altitud)
        # Devolver el valor para la zona de nieve
        return self._TABLA_AN2[altitud_tabla][self.zona_nieve]
    
    def _nieve50(self) -> float:
        """
        Devuelve la carga de nieve base interpolada
        entre las altitudes inferior y superior de la tabla.
        """
        h = self.altitud
        altitudes = sorted(self._TABLA_AN2.keys())
        h1 = max(altitud for altitud in altitudes if altitud <= self.altitud)
        h2 = min(a for a in altitudes if a >= self.altitud)
        s1 = self._nieve_tabla_inferior()
        s2 = self._nieve_tabla_superior()
        # Si coincide exactamente con una altitud de la tabla
        if h1 == h2:
            return s1
        # Interpolación lineal
        return s1 + (s2 - s1) * (h - h1) / (h2 - h1)
    
    def _incremento_por_altitud(self) -> float:
        """
        Incremento de carga de nieve debido a la altitud respecto
        al valor base de la altitud inferior de la tabla.
        """
        nieve_interp = self._nieve50()  # Carga de nieve interpolada para la altitud dada
        nieve_base = self._nieve_tabla_inferior()  # la de altitud inferior
        return nieve_interp - nieve_base

    def _Ces1(self) -> float:
        """
        Coeficiente de carga excepcional
        """
        return 1.0
    

# METODOS PÚBLICOS -------------------------------------------------------------------------------------------------------

    def calcular(self) -> None:
        """
        Ejecuta el cálculo completo de la acción de nieve.

        Calcula:
            - Carga base tabulada
            - Incremento por altitud
            - Carga para 50 años
            - Factor probabilístico
            - Carga sobre el terreno
            - Carga accidental

        Además almacena los resultados en `self._datos` y marca el cálculo
        como realizado.
        """

        sk_tabla = self._nieve_tabla_inferior()   # Carga de nieve base de la tabla AN.2 para altitud inferior
        incremento = self._incremento_por_altitud()  # Incremento por altitud respecto al valor base de la tabla
        sk = sk_tabla + incremento  # Carga de nieve para la altitud de
        cprob = self._cprob()  # Factor de probabilidad
        skn = sk * cprob  # Carga de nieve sobre el terreno
        Ces1 = self._Ces1()  # Coeficiente de carga excepcional
        sad = skn * Ces1  # Carga de nieve accidentalsobre la estructura (con coeficiente de carga excepcional)
        scubierta = sad 


        self._datos = {
            "PAIS": "ESPAÑA",
            "NORMATIVA": "UNE-EN 1991-1-3:2018 + AN/UNE-EN 1991-1-3",
            "DENSIDAD_NIEVE": self._densidad_nieve(),
            "RETORNO": self.periodo_retorno,
            "ZONA_NIEVE": str(self.zona_nieve),
            "ALTITUD": self.altitud,
            "CARGA_BASE": round(sk_tabla, 3),
            "INCREMENTO": round(incremento, 3),
            "SK50": round(sk, 3),
            "V": self._V(),
            "CPROB": round(cprob, 5),
            "SKN": round(skn, 3),
            "CES1": round(Ces1, 3),
            "SAD": round(sad, 3),
        }

        self._parametros = {
            "PAIS": "Descripción del país",
            "NORMATIVA": "Normativa aplicada para el cálculo",
            "DENSIDAD_NIEVE": "Densidad de la nieve en kg/m³",
            "RETORNO": "Periodo de retorno en años",
            "ZONA_NIEVE": "Zona climatica de nieve (1 a 7)",
            "ALTITUD": "Altitud de la ubicación en metros",
            "CARGA_BASE": "Valor de carga de nieve base según tabla AN.2 para la altitud inferior",
            "INCREMENTO": "Incremento por altitud interpolada",
            "SK50": "Carga de nieve para la altitud de la ubicación (50 años)",
            "V": "Coeficiente de variación por retorno",
            "CPROB": "Factor de retorno",
            "SKN": "Carga de nieve sobre el terreno para el periodo de retorno considerado",
            "CES1": "Coeficiente de carga excepcional",
            "SAD": "Carga de nieve accidental sobre el terreno para el periodo de retorno considerado",
        }

        self.calculo_realizado = True

    def tabla(self) -> pd.DataFrame:
        """
        Genera una tabla resumen de resultados.

        Returns:
            pd.DataFrame: Tabla con columnas `Concepto`, `Valor` y `Unidad`,
            lista para consola, exportación o Streamlit.

        Raises:
            RuntimeError: Si el cálculo aún no ha sido ejecutado.
        """
        self._verificar_calculado()
        
        def g(clave, dec=5, unidad=""):
            try:
                valor = self.obtener(clave)
                if valor is None:
                    return "-"
                if isinstance(valor, (int, float)):
                    return f"{valor:.{dec}f}"
                return str(valor)
            except KeyError:
                return "-"
        
        filas = []

        # --- CONFIGURACIÓN GENERAL ---
        filas.append(("CONFIGURACIÓN GENERAL", "", ""))
        filas.append(("País:", "España", ""))
        filas.append(("Normativa:", "CTE DB-SE-AE ", ""))
        filas.append(("Densidad de la nieve [ρ]:", g("DENSIDAD_NIEVE",0), "kg/m³"))
        filas.append(("Periodo de retorno [T]:", g("RETORNO",0), "años"))
        filas.append(("", "", ""))

        # --- CARACTERÍSTICAS DE LA UBICACIÓN ---
        filas.append(("CARACTERÍSTICAS DE LA UBICACIÓN", "", ""))
        filas.append(("Zona climática de invierno:", g("ZONA_NIEVE"), ""))
        filas.append(("Altitud de la ubicación:", g("ALTITUD",2), "m"))
        filas.append(("", "", ""))

        # --- RESULTADOS PRINCIPALES ---
        filas.append(("RESULTADOS PRINCIPALES", "", ""))
        filas.append(("Carga de nieve sobre el terreno [skn]:", g("SKN",2), "kN/m²"))
        filas.append(("Carga de nieve accidental [sad]:", g("SAD",2), "kN/m²"))
        filas.append(("", "", ""))

        # --- CÁLCULOS INTERMEDIOS Y COEFICIENTES ---
        filas.append(("CÁLCULOS INTERMEDIOS Y COEFICIENTES EMPLEADOS", "", ""))
        filas.append(("Carga de nieve de referencia [s50 Tabla AN.2]", g("CARGA_BASE",2), ""))
        filas.append(("Incremento por altitud interpolada", g("INCREMENTO",2), ""))
        filas.append(("Carga de nieve (50 años) [sk]", g("SK50",2), "kN/m²"))
        filas.append(("Coeficiente de variación por retorno [V]", g("V",2), ""))
        filas.append(("Factor de retorno [cprob]", g("CPROB",3), ""))
        filas.append(("Coeficiente de carga excepcional [Ces1]", g("CES1",2), ""))

        # --- DataFrame con tres columnas ---
        df = pd.DataFrame(filas, columns=["Concepto", "Valor", "Unidad"])

        # Limpiar celdas de unidad cuando están vacías
        df["Unidad"] = df["Unidad"].replace("-", "")
        
        return df

    def normativa(self):
        """
        Devuelve la referencia normativa aplicada.

        Returns:
            str: Nombre de la normativa de acciones empleada.
        """
        return "CTE DB-SE-AE — Nieve"
    
    def consultar_parametros(self):
        """
        Muestra por consola la descripción de parámetros calculados.

        Raises:
            ValueError: Si aún no se ha ejecutado :meth:`calcular`.
        """
        if self.calculo_realizado:
            print("PARÁMETROS DISPONIBLES TRAS EL CÁLCULO:")
            for llave, valor in self._parametros.items():
                print(f"{llave} : {valor} ")
        else:
            raise ValueError("El cálculo no se ha realizado aún. Por favor, ejecute el método calcular() antes de consultar los parámetros disponibles.")
    
    def consultar_zonas(self):
        """
        Muestra por consola las zonas de nieve disponibles.

        Imprime cada zona junto a su descripción.
        """
        print("ZONAS DE NIEVE SEGÚN CTE DB-SE-AE:")
        for zona in self._ZONAS_NIEVE:
            print(f"Zona {zona}")