""" Las acciones del viento consideradas en el presente cálculo estructural se han determinado de acuerdo con:
        * CTE: DB -SE-AE "Acciones en la edificación   
    Contiene las clases:
    -  VientoCTE: Cálculo según CTE: DB -SE-AE
"""

from typing import Any, Dict
from sunfer_clima.utilidades.conversor import convertir
from sunfer_clima.acciones.comunes.accion_climatica import AccionClimatica
import math
import pandas as pd

class VientoCTE(AccionClimatica):
    limite_altura = 200  # Altitud máxima para aplicación del método CTE DB-SE-AE
    limite_altitud = 2000  # Altitud máxima para aplicación del método CTE DB-SE-AE
    """
    Cálculo de acciones de viento en España según CTE: DB-SE-AE. Aplicable hasta altitudes inferiores a 2000m 
    """

    #-------- DATOS NORMATIVOS FIJOS PARA ESPAÑA ------------------------------------------------------------------------------------------------------------------
    _ZONAS_VIENTO: dict[str, float] = {
        "A": 26.0,
        "B": 27.0,
        "C": 29.0,}

    _PARAMETROS_TERRENO = {
    "I": {"K": 0.156, "L": 0.003, "Z":1.0},
    "II": {"K": 0.170, "L": 0.010, "Z":1.0},
    "III": {"K": 0.190, "L": 0.050, "Z":2.0},
    "IV":{"K": 0.220, "L": 0.30, "Z":5.0},
    "V": {"K": 0.24, "L": 1.0, "Z":10.0},
    }

    # ---- CONFIGURACION GLOBAL: Propiedades de clase ------------------------------------------------------------------------------------------
    _densidad_aire_defecto: float = 1.25       # kg/m3
    _periodo_retorno_defecto: int = 25         # años
    _c_dir_defecto: float = 1.0                # coeficiente de dirección
    _c_season_defecto: float = 1.0             # coeficiente estacional
    _c_topografico_defecto: float = 1.0        # coeficiente topográfico


    #-------- CONSTRUCTOR  ----------------------------------------------------------------------------------------------------------------------------------------

    def __init__(self, zona_viento: str, altura_instalacion: float, grado_aspereza: str) -> None:
        """
        Parámetros mínimos según Anejo Nacional Español:
        - zona_viento: A, B o C
        - altura_instalacion: z [m]
        - grado_aspereza: I, II, III, IV o V
        """
        #Contenedor de datos de calculo de cada instancia e indicador de calculo ejecutado
        self._datos: Dict[str, Any] = {}
        self.calculo_realizado: bool = False

        self._periodo_retorno: int | None = None
        self._densidad_aire: float | None = None
        self._c_dir: float | None = None
        self._c_season: float | None = None
        self._c_topografico: float | None = None    
        self._zona_viento: str | None = None
        self._altura_instalacion: float | None = None
        self._grado_aspereza: str | None = None

        # Validación vía setters
        self.zona_viento = zona_viento
        self.altura_instalacion = altura_instalacion
        self.grado_aspereza = grado_aspereza

    #------ PROPIEDADES DE INSTANCIA ------------------------------------------------------------------------------------------------------------------------------
    @property
    def periodo_retorno(self) -> int:
        return (
            self._periodo_retorno
            if self._periodo_retorno is not None
            else self.__class__._periodo_retorno_defecto
        )
    @periodo_retorno.setter
    def periodo_retorno(self, value: int) -> None:
        if value <= 0:
            raise ValueError("El periodo de retorno debe ser un entero mayor que cero.")
        self._periodo_retorno = int(value)
        self._invalidar_calculo()

    @property
    def densidad_aire(self) -> float:
        return (
            self._densidad_aire
            if self._densidad_aire is not None
            else self.__class__._densidad_aire_defecto
        )
    @densidad_aire.setter
    def densidad_aire(self, value: float) -> None:
        if value <= 0:
            raise ValueError("La densidad del aire debe ser positiva.")
        if value > 1.8:
            raise ValueError("No se permiten densidades > 1.8 kg/m3.")
        self._densidad_aire = float(value)
        self._invalidar_calculo()

    @property
    def c_dir(self) -> float:
        return (
            self._c_dir
            if self._c_dir is not None
            else self.__class__._c_dir_defecto
        )
    @c_dir.setter
    def c_dir(self, value: float) -> None:
        if value <= 0:
            raise ValueError("El coeficiente de dirección debe ser positivo.")
        self._c_dir = float(value)
        self._invalidar_calculo()

    @property
    def c_season(self) -> float:
        return (
            self._c_season
            if self._c_season is not None
            else self.__class__._c_season_defecto
        )
    @c_season.setter
    def c_season(self, value: float) -> None:
        if value <= 0:
            raise ValueError("El coeficiente estacional debe ser positivo.")
        self._c_season = float(value)
        self._invalidar_calculo()

    @property
    def c_topografico(self) -> float:
        return (
            self._c_topografico
            if self._c_topografico is not None
            else self.__class__._c_topografico_defecto
        )
    @c_topografico.setter
    def c_topografico(self, value: float) -> None:
        if value <= 0:
            raise ValueError("El coeficiente topográfico debe ser positivo.")
        self._c_topografico = float(value)
        self._invalidar_calculo()

    @property
    def zona_viento(self) -> str:
        return self._zona_viento
    @zona_viento.setter
    def zona_viento(self, value: str) -> None:
        value = value.upper()
        if value not in self._ZONAS_VIENTO.keys():
            raise ValueError(
                "Zona de viento inválida. Opciones: A, B o C."
            )
        self._zona_viento = value
        self._invalidar_calculo()
    
    @property
    def grado_aspereza(self) -> str:
        return self._grado_aspereza
    @grado_aspereza.setter
    def grado_aspereza(self, value: str) -> None:
        value = value.upper()
        if value not in self._PARAMETROS_TERRENO.keys():
            raise ValueError(
                "Grado de aspereza inválido. Opciones: I, II, III, IV o V."
            )
        self._grado_aspereza = value
        self._invalidar_calculo()

    @property
    def altura_instalacion(self) -> float:
        """Altura sobre el terreno en metros."""
        return self._altura_instalacion
    @altura_instalacion.setter
    def altura_instalacion(self, value: float) -> None:
        if value < 0 or value > self.limite_altura:
            raise ValueError(f"La altura de instalación debe ser >= 0 y ≤ {self.limite_altura} m.")
        if value == 0:
            self._altura_instalacion = 0.01  # Evitar división por cero en perfil logarítmico
        else:
            self._altura_instalacion = float(value)
        self._invalidar_calculo()
    # -------------------- MÉTODOS INTERNOS ------------------------------------------------------------------------------------------------------------------------------------------------------

    def _invalidar_calculo(self): 
        """Invalida el estado interno de resultados."""
        self._datos.clear()
        self.calculo_realizado = False
    
    def _verificar_calculado(self) -> None:
        if not self.calculo_realizado:
            raise RuntimeError("Debe llamar a calcular() antes de acceder a resultados.")

    def _parametro_terreno(self, value:str) -> float:
        value = value.upper()
        if value not in self._PARAMETROS_TERRENO[self.grado_aspereza].keys():
            raise ValueError ("Parámetro inválido. Debe ser K, L o Z")
        
        return self._PARAMETROS_TERRENO[self.grado_aspereza][value]

    def _vb50(self): 
        return self._ZONAS_VIENTO[self.zona_viento]  
    
    def _qb50(self): 
        return 0.5 * self.densidad_aire * self._vb50()**2

    def _vb(self): 
        return self._vb50() * self._cprob()
    
    def _qb(self): 
        return 0.5 * self.densidad_aire * self._vb()**2

    def _F(self):
        return self._parametro_terreno("K") * math.log(max(self.altura_instalacion,self._parametro_terreno("Z"))/self._parametro_terreno("L"))

    def _ce(self):
        return self._F() * (self._F() + 7 * self._parametro_terreno("K"))
    
    def _qp(self) : 
        return self._qb() * self._ce()
    
    def _vp(self): 
        return convertir(self._qp(),"N/m2","km/h", self.densidad_aire)
    
    def _n(self) -> float:
        return 0.5
    
    def _K(self) -> float:
        return 0.2

    def _cprob(self) -> float:
        if self.periodo_retorno > 0 and self.periodo_retorno <=1:
            return 0.41
        else:
            T = self.periodo_retorno
            Tref = 50
            p = 1 - 0.98 ** (Tref / T)
            n = self._n()
            K = self._K()
            num = 1 - K * math.log(-math.log(1 - p))
            den = 1 - K * math.log(-math.log(0.98))
            return (num / den) ** n
    # -------------------- MÉTODOS PÚBLICOS ------------------------------------------------------------------------------------------------------------------------------------------------------
    def normativa(self):
        return "CTE DB-SE-AE — Acciones en la edificación"
    
    def calcular(self):
        """
        Ejecuta el cálculo completo y almacena todos los resultados internos.
        """
        
        vb50 = self._vb50()
        qb50 = self._qb50()
        n = self._n()
        FF = self._K()
        cprob = self._cprob()
        vb = self._vb()
        qb = self._qb()
        k = self._parametro_terreno("K")
        Z = self._parametro_terreno("Z")
        L = self._parametro_terreno("L")
        F = self._F()
        ce = self._ce()
        qp = self._qp()
        vp = convertir(qp, "N/m2", "km/h")

        self._datos= {
            "PAIS": "ESPAÑA",
            "NORMATIVA": "CTE DB-SE-AE — Acciones en la edificación",
            "DENSIDAD_AIRE": self.densidad_aire,
            "RETORNO": self.periodo_retorno,
            "CDIR": self.c_dir,
            "CSEASON": self.c_season,
            "CTOPOGRAFICO": self.c_topografico,
            "TERRENO": self.grado_aspereza,
            "ALTURA": self.altura_instalacion,
            "ZONA": self.zona_viento,
            "VB50": vb50,
            "QB50": qb50,
            "CPROB": cprob,
            "N": n,
            "FFORMA": FF,
            "VB": vb,
            "QB": qb,
            "K": k,
            "Z": Z,
            "L": L,
            "QP": qp,
            "CE": ce,
            "F": F,
            "VP": vp
        }

        self.parametros = {
            "PAIS": "Descripción del país",
            "NORMATIVA": "Descripción de la normativa aplicada",
            "DENSIDAD_AIRE": "Densidad del aire en kg/m³",
            "RETORNO": "Periodo de retorno en años",
            "CDIR": "Factor de dirección",
            "CSEASON": "Factor estacional",
            "CTOPOGRAFICO": "Factor topográfico",
            "ALTURA": "Altura de instalación en metros",
            "ZONA": "Zona de viento según CTE",
            "TERRENO": "Grado de aspereza del terreno (I, II, III, IV o V)",
            "VB50": "Velocidad básica de referencia [50 años]en m/s",
            "QB50": "Presión básica de referencia [50 años]en N/m²",
            "N": "Exponente de la fórmula de probabilidad",
            "FFORMA": "Factor de forma de la fórmula de probabilidad",
            "CPROB": "Factor de probabilidad para el periodo de retorno",
            "VB": "Velocidad básica ajustada al periodo de retorno en m/s",
            "QB": "Presión básica del viento ajustada al periodo de retorno en N/m²",
            "K": "Parámetro K de la tabla D.2 del CTE",
            "Z": "Parámetro Z de la tabla D.2 del CTE en m",
            "L": "Parámetro L de la tabla D.2 del CTE en m",
            "QP": "Presión dinámica ajustada al periodo de retorno en N/m²",
            "CE": "Coeficiente de exposición",
            "F": "Coeficiente F de la fórmula de cálculo de la presión dinámica",
            "VP": "Velocidad pico del viento ajustada al periodo de retorno en km/h",
        }

        self.calculo_realizado = True
    
    def tabla(self): 
        """
        Devuelve un DataFrame con los resultados estructurados en bloques, con encabezados intercalados para mostrar en Streamlit.
        """

        # Asegurar que el calculo està actualizado
        self._verificar_calculado()

        # Getter seguro: no lanza excepción
        def g(clave, dec=5):
            try:
                valor = self.obtener(clave)
                if isinstance(valor, (int, float)):
                    return f"{valor:.{dec}f}"
                return valor
            except KeyError:
                return "-"

        filas = [] 

        # ------- Configuracion -------------------------------------------------------
        filas.append(("CONFIGURACIÓN GENERAL", "", ""))
        filas.append(("País:", "España", ""))
        filas.append(("Normativa:", "CTE DB-SE-AE", ""))
        filas.append(("Densidad del aire [ρ]:", g("DENSIDAD_AIRE",3), "kg/m³")) 
        filas.append(("Periodo de retorno [T]:", g("RETORNO",0), "años"))
        filas.append(("", "", ""))
        # ------- Características de la instalación ------------------------------------
        filas.append(("CARACTERÍSTICAS DE LA UBICACIÓN"
        "", "", ""))
        filas.append(("Zona de viento:", g("ZONA"), ""))
        filas.append(("Grado de aspereza:", g("TERRENO"), ""))
        filas.append(("Altura de instalación:", g("ALTURA",2), "m"))
        filas.append(("", "", ""))
        # ------- Resultados principales -----------------------------------------------
        filas.append(("RESULTADOS PRINCIPALES", "", ""))
        filas.append(("Velocidad máxima del viento [vmax]:", g("VP",2), "km/h"))
        filas.append(("Presión dinámica asociada [qp]:", g("QP",2), "N/m²"))
        filas.append(("", "", ""))
        # ------- Cálculos intermedios y coeficientes empleados ------------------------
        filas.append(("CÁLCULOS INTERMEDIOS Y COEFICIENTES EMPLEADOS", "", ""))
        filas.append(("Coeficiente de dirección [cdir]", g("CDIR",2), ""))
        filas.append(("Coeficiente estacional [cseason]", g("CSEASON",2), ""))
        filas.append(("Coeficiente topográfico [co]", g("CTOPOGRAFICO",2), ""))
        filas.append(("Velocidad básica mapa[vb,map,50años]", g("VB50",2), "m/s"))
        filas.append(("Factor de retorno  [cprob]", g("CPROB",), ""))
        filas.append(("Exponente de la fórmula de probabilidad [n]", g("N",3), ""))
        filas.append(("Factor de forma de la fórmula de probabilidad [K]", g("FFORMA",3), ""))
        filas.append((f"Velocidad básica ajustada ({g('RETORNO',0)} años) [vb]", g("VB",2), "m/s"))
        filas.append(("Parametro K [Tabla D.2]", g("K",3), ""))
        filas.append(("Parametro L [Tabla D.2]", g("L",3), "m"))
        filas.append(("Parametro Z [Tabla D.2]", g("Z",3), "m"))
        filas.append(("Coeficiente F [F]", g("F"), ""))
        filas.append(("Coeficiente de exposicion [ce]", g("CE",2) , ""))
        filas.append(("Presión básica del viento 50 años [qb,50]", g("QB50",2) , "N/m²")),
        filas.append((f"Presión básica ajustada ({g('RETORNO',0)} años) [qb]", g("QB",2), "N/m²"))

        df = pd.DataFrame(filas, columns = ["","",""])
        return df
    
    def consultar_zonas(self):
        print("ZONAS DE VIENTO:")
        for llave, valor in self._ZONAS_VIENTO.items():
            print(f"{llave} : {valor} m/s")
    
    def consultar_terrenos(self):
        print("CATEGORÍAS DE TERRENO:")
        for llave, valor in self._PARAMETROS_TERRENO.items():
            print(f"{llave} : {valor['z0']} m")
    
    def consultar_parametros(self):
        """
        Muestra por consola la descripción de parámetros calculados.

        Raises:
            ValueError: Si aún no se ha ejecutado :meth:`calcular`.
        """
        if self.calculo_realizado:
            print("PARÁMETROS DISPONIBLES TRAS EL CÁLCULO:")
            for llave, valor in self._parametros.items():
                print(f"{llave} : {valor} ")
        else:
            raise ValueError("El cálculo no se ha realizado aún. Por favor, ejecute el método calcular() antes de consultar los parámetros disponibles.")