""" Las acciones del viento consideradas en el presente cálculo estructural se han determinado de acuerdo con:
        * EN 1991-1-4:2005 + A1:2010 — Eurocódigo 1: Acciones en estructuras. Parte 1-4: Acciones generales. Acciones de viento.
        * NP EN 1991-1-4 2010 (para EN 1991-1-4:2005) — Anejo Nacional Portugúes, que establece los Parámetros de Determinación Nacional (NDP) y criterios de aplicación específicos para el territorio portugués
        * EN 1990 — Eurocódigo: Bases de diseño estructural.
    
    Contiene las clases:
    -  VientoEurocodeFR: Cálculo según EN 1991-1-4
"""


# ---------- IMPORTACION DE LIBRERIAS Y PAQUETES -----------------------------------------------------------------------------------------------------------------
import math 
from typing import Dict
from sunfer_clima.utilidades.conversor import convertir
from sunfer_clima.utilidades.topografia import calcular_co 
from .base import EurocodeViento
import pandas as pd


class VientoEurocodePT(EurocodeViento):
    """
    Cálculo de acciones de viento en estructuras situadas en Portugal
    según el Eurocódigo 1 (EN 1991-1-4) y su Anejo Nacional Portugués.

    Esta clase extiende ``EurocodeViento`` incorporando los parámetros
    específicos definidos en la normativa portuguesa (NP EN 1991-1-4/NA).

    Normativa aplicada:
        - NP EN 1991-1-4:2010 — Acciones de viento
        - NP EN 1991-1-4/NA — Anejo Nacional Portugués
        - NP EN 1990 — Bases de diseño estructural

    Parameters
    ----------
    altura_instalacion : float
        Altura de cálculo sobre el terreno (z) en metros.

    categoria_terreno : str
        Categoría de rugosidad del terreno. Valores permitidos:
        "I", "II", "III", "IV".

    distancia_costa : float
        Distancia a la costa en metros.

    altitud : float
        Altitud sobre el nivel del mar en metros (>= 0).

    Raises
    ------
    ValueError
        Si la categoría de terreno no es válida o la altitud es negativa.

    Notes
    -----
    - La zona de viento se determina automáticamente:
        * Zona B: distancia a costa ≤ 5 km o altitud > 600 m
        * Zona A: resto de casos

    - Velocidades básicas:
        * Zona A: 27 m/s
        * Zona B: 30 m/s

    - Categorías de terreno:

        ======  ======  ======
        Tipo    z0 (m)  zmin (m)
        ======  ======  ======
        I       0.005   1.0
        II      0.05    3.0
        III     0.30    8.0
        IV      1.00    15.0
        ======  ======  ======

    Attributes
    ----------
    categoria_terreno : str
        Categoría del terreno.

    distancia_costa : float
        Distancia a la costa en metros.

    altitud : float
        Altitud sobre el nivel del mar en metros.

    zona_viento : str
        Zona de viento asignada ("A" o "B").

    calculo_realizado : bool
        Indica si el cálculo ha sido ejecutado.

    Methods
    -------
    calcular()
        Ejecuta el cálculo completo del viento y almacena los resultados.

    tabla()
        Devuelve un pandas.DataFrame con los resultados formateados.

    normativa()
        Devuelve la normativa aplicada como texto.

    Examples
    --------
    >>> viento = VientoEurocodePT(
    ...     altura_instalacion=10,
    ...     categoria_terreno="II",
    ...     distancia_costa=2000,
    ...     altitud=100
    ... )
    >>> viento.calcular()
    >>> df = viento.tabla()
    >>> print(df)
    """

    #-------- DATOS NORMATIVOS FIJOS PARA PORTUGAL ------------------------------------------------------------------------------------------------------------------
    _ZONAS_VIENTO: dict[str, float] = {
        "A": 27.0,
        "B": 30.0,}

    _PARAMETROS_TERRENO = {
    "I": {"z0": 0.005, "zmin": 1.0},
    "II": {"z0": 0.05,  "zmin": 3.0},
    "III": {"z0": 0.3, "zmin": 8.0},
    "IV": {"z0": 1.00, "zmin":15.0},
    }


    #-------- CONSTRUCTOR  ----------------------------------------------------------------------------------------------------------------------------------------

    def __init__(self, altura_instalacion: float, categoria_terreno: str, distancia_costa: float, altitud: float, ) -> None:
        """
        Parámetros mínimos según Anejo Nacional Portugués:
        - distancia a la costa: metros.
        - altitud : metros
        - categoria_terreno: I, II, III, o IV
        - altura_instalacion: z [m]
        """
        # Inicializar atributos directamente (sin setters)
        self._categoria_terreno: str | None = categoria_terreno.upper()
        self._distancia_costa: float | None = distancia_costa
        self._altitud: float | None = altitud

        # Validaciones manuales mínimas
        if self._categoria_terreno not in self._PARAMETROS_TERRENO:
            raise ValueError("Categoría de terreno inválida. Opciones: I, II, III, IV.")

        if self._altitud < 0:
            raise ValueError("La altitud debe ser positiva.")

        # Ahora sí podemos determinar la zona
        zona_viento = self._determinar_zona()

        # Construimos el padre (crea _datos, etc.)
        super().__init__(
            zona_viento=zona_viento,
            altura_instalacion=altura_instalacion,
        )


    #------ PROPIEDADES DE INSTANCIA (Con override opcional) No contenidas el el general --------------------------------------------------------------------------------------------------
    @property
    def categoria_terreno(self) -> str:
        return self._categoria_terreno
    @categoria_terreno.setter
    def categoria_terreno(self, value: str) -> None:
        value = value.upper()
        if value not in self._PARAMETROS_TERRENO:
            raise ValueError(
                "Categoría de terreno inválida. Opciones: I, II, III, o IV."
            )
        self._categoria_terreno = value
        self._invalidar_calculo()
    
    @property
    def distancia_costa(self) -> str:
        return self._distancia_costa
    @distancia_costa.setter
    def distancia_costa(self, value: float) -> None:
        self._distancia_costa = value
        self._invalidar_calculo()
    
    @property
    def altitud(self) -> float:
        return self._altitud
    @altitud.setter
    def altitud(self, value: float) -> float:
        if value < 0: 
            raise ValueError ("La altitud debe ser positiva.")
        self._altitud = value
        self._invalidar_calculo()


    # ------------- IMPLEMENTACION DE LOS METODOS ABSTRACTOS ----------------------------------------------------------------------------------------------------- 
    def _velocidad_basica_fundamental(self) -> float: 
        return self._ZONAS_VIENTO[self.zona_viento]
    
    def _n(self): 
        return 1
    
    def _K(self):
        return 0.11
    
    def _Kr(self): 
        return 0.19*(self._z0()/self._z0II())**0.07

    def _K1(self):
        return 1.0 
    
    def normativa(self): 
        return """* NP EN 1991-1-4:2010 — Eurocódigo 1: Acciones en estructuras. Parte 1-4: Acciones generales. Acciones de viento.
        * NP EN 1991-1-4:2010/NA — Anejo Nacional Portugúes, que establece los Parámetros de Determinación Nacional (NDP) y criterios de aplicación específicos para el territorio portugués.
        * NP-EN 1990 — Eurocódigo: Bases de diseño estructural."""
    
    def _z0(self):
        return self._PARAMETROS_TERRENO[self.categoria_terreno]["z0"]
    
    def _zmin(self):
        return self._PARAMETROS_TERRENO[self.categoria_terreno]["zmin"]

    
    # ------------- MÉTODOS COMPLEMENTARIOS  ----------------------------------------------------------------------------------------------------- 
    def _z0II(self): 
        return self._PARAMETROS_TERRENO["II"]["z0"]
    
    def _determinar_zona(self) -> str:
        if self.distancia_costa <= 5000:
            return "B"
        if self.altitud > 600:
            return "B"
        return "A"

# METODOS PUBLICOS -----------------------------------------------------------------------------------------------------------------------------------------   
    def calcular(self):
        """
        Ejecuta el cálculo completo de las acciones de viento.

        Calcula y almacena internamente:

        - Velocidades: vb0, vb, vbr, vm
        - Coeficientes: cdir, cseason, ctopo, cr, Kr, K1
        - Turbulencia: sigma_v, Iv
        - Presiones: qb, qp
        - Coeficiente de exposición: ce

        Los resultados se almacenan en el atributo interno ``self._datos``.

        Notes
        -----
        Debe ejecutarse antes de llamar a ``tabla()`` o acceder a resultados.
        """

        
        vb0 = self._velocidad_basica_fundamental()
        vb50 = self._velocidad_basica()
        n = self._n()
        k = self._K()
        cprob = self._cprob()
        vb = self._velocidad_basica_retorno()
        z0 = self._z0()
        z0II = self._z0II()
        zmin = self._zmin()
        kr = self._Kr()
        cr = self._cr()
        vm = self._velocidad_media()
        K1 = self._K1()
        sigma_v = self._desviacion_turbulenta()
        Iv = self._intensidad_turbulencia() *100
        qb = self._presion_basica()
        qp = self._presion_dinamica()
        ce = self._ce()
        vp = convertir(qp, "N/m2", "km/h")
        qb50 = self._presion_basica_50()
        

        self._datos= {
            "PAIS": "PORTUGAL",
            "NORMATIVA": "NP-EN 1991-1-4:2010 — Anejo Nacional Portugés",
            "DENSIDAD_AIRE": self.densidad_aire,
            "RETORNO": self.periodo_retorno,
            "CDIR": self.c_dir,
            "CSEASON": self.c_season,
            "CTOPOGRAFICO": self.c_topografico,
            "TERRENO": self.categoria_terreno,
            "ALTURA": self.altura_instalacion,
            "COSTA": self.distancia_costa,
            "ALTITUD": self.altitud,
            "ZONA": self.zona_viento,
            "VB0": vb0,
            "VB50": vb50,
            "QB50": qb50,
            "CPROB": cprob,
            "N": n,
            "K": k,
            "VB": vb,
            "Z0": z0,
            "ZREF": z0II,
            "ZMIN": zmin,
            "KR": kr,
            "CR": cr,
            "K1": K1,
            "DESVIACION_TURBULENTA": sigma_v,
            "IV": Iv,
            "QB": qb,
            "QP": qp,
            "CE": ce,
            "VM": vm,
            "VP": vp
        }

        self._parametros = {
            "PAIS": "Descripción del país",
            "NORMATIVA": "Normativa aplicada para el cálculo",
            "DENSIDAD_AIRE": "Densidad del aire en kg/m³",
            "RETORNO": "Periodo de retorno en años",
            "CDIR": "Factor de dirección",
            "CSEASON": "Factor de estación",
            "CTOPOGRAFICO": "Factor topográfico",
            "TERRENO": "Categoría de terreno (0, I, II, III, IV)",
            "ALTURA": "Altura de instalación en metros",
            "COSTA": "Distancia a la costa en metros",
            "ALTITUD": "Altitud en metros",
            "ZONA": "Zona de viento según EN 1991-1-4 + Anejo Nacional",
            "VB0": "Velocidad básica fundamental en m/s",
            "VB50": "Velocidad básica de Referencia 50 años en m/s",
            "QB50": "Presión básica de Referencia 50 años en N/m²",
            "CPROB": "Factor de probabilidad para el periodo de retorno",
            "N": "Exponente de la fórmula de probabilidad",
            "K": "Factor de forma de la fórmula de probabilidad",
            "VB": "Velocidad básica ajustada al periodo de retorno en m/s",
            "Z0": "Longitud de rugosidad del terreno en metros",
            "ZREF": "Longitud de rugosidad de referencia en metros",
            "ZMIN": "Altura mínima en metros",
            "KR": "Factor de rugosidad",
            "CR": "Factor de exposición",
            "K1": "Factor de turbulencia",
            "DESVIACION_TURBULENTA": "Desviación estándar de la turbulencia en m/s",
            "IV": "Intensidad de turbulencia en %",
            "QB": "Presión básica ajustada al periodo de retorno en N/m²",
            "QP": "Presión dinámica ajustada al periodo de retorno en N/m²",
            "CE": "Coeficiente de exposición",
            "VM": "Velocidad media ajustada al periodo de retorno",
            "VP": "Velocidad pico ajustada al periodo de retorno en km/h",}

        self.calculo_realizado = True

    def tabla(self): 
        """
        Genera una tabla con los resultados del cálculo de viento.

        Returns
        -------
        pandas.DataFrame
            DataFrame estructurado con:
            - Configuración general
            - Características de la instalación
            - Resultados principales
            - Cálculos intermedios

        Raises
        ------
        RuntimeError
            Si el cálculo no ha sido ejecutado previamente.
        """

        # Asegurar que el calculo està actualizado
        self._verificar_calculado()

        # Getter seguro: no lanza excepción
        def g(clave, dec=5):
            try:
                valor = self.obtener(clave)
                if isinstance(valor, (int, float)):
                    return f"{valor:.{dec}f}"
                return valor
            except KeyError:
                return "-"

        filas = [] 

        # ------- Configuracion -------------------------------------------------------
        filas.append(("CONFIGURACIÓN GENERAL", "", ""))
        filas.append(("País:", "Portugal", ""))
        filas.append(("Normativa:", "NP EN 1991-1-4", ""))
        filas.append(("Densidad del aire [ρ]:", g("DENSIDAD_AIRE",3), "kg/m³"))
        filas.append(("Periodo de retorno [T]:", g("RETORNO",0), "años"))
        filas.append(("", "", ""))
        # ------- Características de la instalación ------------------------------------
        filas.append(("CARACTERÍSTICAS DE LA UBICACIÓN", "", ""))
        filas.append(("Distancia a la costa:", g("COSTA",2), "m"))
        filas.append(("Altitud:", g("ALTITUD",2), "m"))
        filas.append(("Zona de viento:", g("ZONA"), ""))
        filas.append(("Categoría de terreno:", g("TERRENO"), ""))
        filas.append(("Altura de instalación:", g("ALTURA",2), "m"))
        filas.append(("", "", ""))
        # ------- Resultados principales -----------------------------------------------
        filas.append(("RESULTADOS PRINCIPALES", "", ""))
        filas.append(("Velocidad máxima del viento [vmax]:", g("VP",2), "km/h"))
        filas.append(("Presión dinámica asociada [qp]:", g("QP",2), "N/m²"))
        filas.append(("", "", ""))
        # ------- Cálculos intermedios y coeficientes empleados ------------------------
        filas.append(("CÁLCULOS INTERMEDIOS Y COEFICIENTES EMPLEADOS", "", ""))
        filas.append(("Coeficiente de dirección [cdir]", g("CDIR",2), ""))
        filas.append(("Coeficiente estacional [cseason]", g("CSEASON",2), ""))
        filas.append(("Coeficiente topográfico [co]", g("CTOPOGRAFICO",2), ""))
        filas.append(("Velocidad básica fundamental [vb,0]", g("VB0",2), "m/s"))
        filas.append(("Velocidad básica de referencia [vb,50]", g("VB50",2), "m/s"))
        filas.append(("Factor de retorno  [cprob]", g("CPROB",), ""))
        filas.append(("Exponente de la fórmula de probabilidad [n]", g("N",3), ""))
        filas.append(("Factor de forma de la fórmula de probabilidad [K]", g("K",3), ""))
        filas.append((f"Velocidad básica ajustada ({g('RETORNO',0)} años) [vb,r]", g("VB",2), "m/s"))
        filas.append(("Longitud de rugosidad [z0]", g("Z0",2), "m"))
        filas.append(("Longitud de rugosidad de referencia [z0II]", g("ZREF",2), "m"))
        filas.append(("Altura mínima [zmin]", g("ZMIN",2), "m"))
        filas.append(("Factor de terreno [Kr]", g("KR"), ""))
        filas.append(("Factor de rugosidad [cr(z)]", g("CR"), ""))
        filas.append((f"Velocidad media ajustada ({g('RETORNO',0)} años) [vm(z)]", g("VM",2), "m/s"))
        filas.append(("Factor de turbulencia [K1]", g("K1",2), ""))
        filas.append(("Desviacion típica de la turbulencia [σv]", g("DESVIACION_TURBULENTA",3), "m/s"))
        filas.append(("Intensida de turbulencia [Iv(z)]", g("IV",2) , "%"))
        filas.append((f"Presión básica del viento ({g('RETORNO',0)} años) [qb)]", g("QB",2) , "N/m²"))
        filas.append(("Coeficiente de exposicion calculado [ce)]", g("CE",2) , ""))

        df = pd.DataFrame(filas, columns = ["","",""])
        return df
    
    def normativa(self):
        """
        Devuelve la normativa aplicada.

        Returns:
            str: Referencia normativa completa.
        """
        return "NP EN 1991-1-4 + Anejo Nacional Portugués"

    def consultar_zonas(self):
        """
        Muestra por consola las zonas de viento disponibles.

        Imprime cada zona junto a su velocidad básica fundamental.
        """
        print("ZONAS DE VIENTO:")
        for llave, valor in self._ZONAS_VIENTO.items():
            print(f"{llave} : {valor} m/s")
    
    def consultar_terrenos(self):
        """
        Muestra por consola las categorías de terreno disponibles.

        Imprime cada categoría junto a su longitud de rugosidad de referencia.
        """
        print("CATEGORÍAS DE TERRENO:")
        for llave, valor in self._PARAMETROS_TERRENO.items():
            print(f"{llave} : {valor} m")

    def consultar_parametros(self):
        """
        Muestra por consola la descripción de parámetros calculados.

        Raises:
            ValueError: Si aún no se ha ejecutado :meth:`calcular`.
        """
        if self.calculo_realizado:
            print("PARÁMETROS DISPONIBLES TRAS EL CÁLCULO:")
            for llave, valor in self._parametros.items():
                print(f"{llave} : {valor} ")
        else:
            raise ValueError("El cálculo no se ha realizado aún. Por favor, ejecute el método calcular() antes de consultar los parámetros disponibles.")  
