"""
MÓDULO: es
===========================

Implementación del cálculo de acciones de viento en España según:

    • UNE-EN 1991-1-4:2018
      Eurocódigo 1: Acciones en estructuras.
      Parte 1-4: Acciones generales. Acciones de viento.
    
    • AN/UNE-EN 1991-1-4
      Anejo Nacional Español (NDP – Nationally Determined Parameters).


Este módulo define las clases:

    - VientoEurocodeES : Implementación específica para España de las cargas de viento
      según EN 1991-1-4 + AN. Extiende la clase base EurocodeViento para integrar todas las acciones climáticas.


Diseñada para integrarse dentro de una librería estructural propia, manteniendo separación entre:

    • Modelo general europeo (EurocodeViento)
    • Implementación específica para España (VientoEurocodeES)

Autor: [Rafa Crespo]
Versión: 1.0
"""


from sunfer_clima.acciones.viento.base import EurocodeViento
from sunfer_clima.utilidades.conversor import convertir
import pandas as pd


class VientoEurocodeES(EurocodeViento):
    """
    Cálculo de acciones de viento en España según Eurocódigo.

    Implementa el cálculo de cargas de viento conforme a:

        - UNE-EN 1991-1-4:2018 — Eurocódigo 1 (Acciones de viento)
        - AN/UNE-EN 1991-1-4 — Anejo Nacional Español
        - UNE-EN 1990 — Bases de diseño estructural

    Esta clase extiende ``EurocodeViento`` incorporando los parámetros
    específicos definidos para el territorio español.

    Parameters
    ----------
    zona_viento : str
        Zona de viento según Anejo Nacional Español.
        Valores permitidos: "A", "B", "C".

    altura_instalacion : float
        Altura de cálculo sobre el terreno (z) en metros.

    categoria_terreno : str
        Categoría de rugosidad del terreno.
        Valores permitidos: "0", "I", "II", "III", "IV".

    Raises
    ------
    ValueError
        Si la categoría de terreno no es válida.

    Notes
    -----
    - Velocidades básicas fundamentales (vb0):
        * Zona A: 26 m/s
        * Zona B: 27 m/s
        * Zona C: 29 m/s

    - Categorías de terreno:

        ======  ======  ======
        Tipo    z0 (m)  zmin (m)
        ======  ======  ======
        0       0.003   1.0
        I       0.01    1.0
        II      0.05    2.0
        III     0.30    5.0
        IV      1.00    10.0
        ======  ======  ======

    Attributes
    ----------
    zona_viento : str
        Zona de viento asignada.

    categoria_terreno : str
        Categoría de rugosidad del terreno.

    altura_instalacion : float
        Altura de cálculo en metros.

    calculo_realizado : bool
        Indica si el cálculo ha sido ejecutado.

    Methods
    -------
    calcular()
        Ejecuta el cálculo completo de las acciones de viento.

    tabla()
        Devuelve un pandas.DataFrame con los resultados formateados.

    normativa()
        Devuelve la normativa aplicada como texto.

    consultar_zonas()
        Muestra por consola las zonas de viento disponibles.

    consultar_parametros()
        Muestra por consola la descripción de los parámetros calculados.

    Examples
    --------
    >>> viento = VientoEurocodeES(
    ...     zona_viento="B",
    ...     altura_instalacion=10,
    ...     categoria_terreno="II"
    ... )
    >>> viento.calcular()
    >>> df = viento.tabla()
    >>> print(df)

    """

    _ZONAS_VIENTO = {"A": 26.0, "B": 27.0, "C": 29.0}

    _PARAMETROS_TERRENO = {
        "0": {"z0": 0.003, "zmin": 1.0},
        "I": {"z0": 0.01, "zmin": 1.0},
        "II": {"z0": 0.05, "zmin": 2.0},
        "III": {"z0": 0.30, "zmin": 5.0},
        "IV": {"z0": 1.00, "zmin": 10.0},
    }

    def __init__(self, zona_viento: str, altura_instalacion: float, categoria_terreno: str) -> None:
        super().__init__(zona_viento, altura_instalacion)
        self._categoria_terreno: str | None = None
        self.categoria_terreno = categoria_terreno

    # ----- SETTERS ------------------------------------------------------------------------------------------------
    @property
    def categoria_terreno(self):
        """str: Categoría de rugosidad del terreno asignada."""
        return self._categoria_terreno
    @categoria_terreno.setter
    def categoria_terreno(self, value: str):
        value = value.upper()
        if value not in self._PARAMETROS_TERRENO:
            raise ValueError("Categoría de terreno inválida. Opciones: 0, I, II, III, IV.")
        self._categoria_terreno = value
        self._invalidar_calculo()

    # ----- IMPLEMENTACIÓN DE MÉTODOS ABSTRACTOS ----------------------------------------------------------------------
    def _velocidad_basica_fundamental(self) -> float:
        return self._ZONAS_VIENTO[self.zona_viento]

    def _n(self):
        return 0.5

    def _K(self):
        return 0.2

    def _Kr(self):
        return 0.19 * (self._z0() / self._z0II()) ** 0.07

    def _K1(self):
        return 1.0

    def _z0(self):
        return self._PARAMETROS_TERRENO[self.categoria_terreno]["z0"]

    def _zmin(self):
        return self._PARAMETROS_TERRENO[self.categoria_terreno]["zmin"]

    def _z0II(self):
        return self._PARAMETROS_TERRENO["II"]["z0"]

# METODOS PUBLICOS --------------------------------------------------------------------------------------------------------------------------------------------------
    def calcular(self):
        """
        Ejecuta el cálculo completo de la acción de viento.

        Calcula y almacena:
            - Velocidad básica y de retorno
            - Presiones básica y dinámica
            - Factores de exposición y turbulencia
            - Velocidad pico
            - Conversión final a km/h

        Los resultados se guardan en ``self._datos`` y las descripciones
        de claves en ``self._parametros``.
        """
        vb0 = self._velocidad_basica_fundamental()
        vb50 = self._velocidad_basica()
        cprob = self._cprob()
        vb = self._velocidad_basica_retorno()
        z0 = self._z0()
        z0II = self._z0II()
        zmin = self._zmin()
        kr = self._Kr()
        cr = self._cr()
        vm = self._velocidad_media()
        K1 = self._K1()
        sigma_v = self._desviacion_turbulenta()
        Iv = self._intensidad_turbulencia() * 100
        qb = self._presion_basica()
        qb50 = self._presion_basica_50()
        qp = self._presion_dinamica()
        ce = self._ce()
        vp = convertir(qp, "N/m2", "km/h")
        n = self._n()
        K = self._K()

        self._datos = {
            "PAIS": "ESPAÑA",
            "NORMATIVA": "UNE-EN 1991-1-4:2018 — Eurocódigo 1 | AN/UNE-EN 1991-1-4 — Anejo Nacional Español",
            "DENSIDAD_AIRE": self.densidad_aire,
            "RETORNO": self.periodo_retorno,
            "CDIR": self.c_dir,
            "CSEASON": self.c_season,
            "CTOPOGRAFICO": self.c_topografico,
            "TERRENO": self.categoria_terreno,
            "ALTURA": self.altura_instalacion,
            "ZONA": self.zona_viento,
            "VB0": vb0,
            "VB50": vb50,
            "QB50": qb50,
            "CPROB": cprob,
            "N": n,
            "K": K,
            "VB": vb,
            "Z0": z0,
            "ZREF": z0II,
            "ZMIN": zmin,
            "KR": kr,
            "CR": cr,
            "K1": K1,
            "DESVIACION_TURBULENTA": sigma_v,
            "IV": Iv,
            "QB": qb,
            "QP": qp,
            "CE": ce,
            "VM":vm,
            "VP": vp,
        }

        self._parametros = {
            "PAIS": "Descripción del país",
            "NORMATIVA": "Normativa aplicada para el cálculo",
            "DENSIDAD_AIRE": "Densidad del aire en kg/m³",
            "RETORNO": "Periodo de retorno en años",
            "CDIR": "Factor de dirección",
            "CSEASON": "Factor de estación",
            "CTOPOGRAFICO": "Factor topográfico",
            "TERRENO": "Categoría de terreno (0, I, II, III, IV)",
            "ALTURA": "Altura de instalación en metros", 
            "ZONA": "Zona de viento según EN 1991-1-4 + Anejo Nacional",
            "VB0": "Velocidad básica fundamental en m/s",
            "VB50": "Velocidad básica de Referencia 50 años en m/s",
            "QB50": "Presión básica de Referencia 50 años en N/m²",
            "CPROB": "Factor de probabilidad para el periodo de retorno",
            "N": "Exponente de la fórmula de probabilidad",
            "K": "Factor de forma de la fórmula de probabilidad",
            "VB": "Velocidad básica ajustada al periodo de retorno en m/s",
            "Z0": "Longitud de rugosidad del terreno en metros",
            "ZREF": "Longitud de rugosidad de referencia en metros",
            "ZMIN": "Altura mínima en metros",
            "KR": "Factor de rugosidad",
            "CR": "Factor de exposición",
            "K1": "Factor de turbulencia",
            "DESVIACION_TURBULENTA": "Desviación estándar de la turbulencia en m/s",
            "IV": "Intensidad de turbulencia en %",
            "QB": "Presión básica ajustada al periodo de retorno en N/m²",
            "QP": "Presión dinámica ajustada al periodo de retorno en N/m²",
            "CE": "Coeficiente de exposición",
            "VM": "Velocidad media ajustada al periodo de retorno",
            "VP": "Velocidad pico ajustada al periodo de retorno en km/h",}

        self.calculo_realizado = True

    def tabla(self):
        """
        Genera una tabla estructurada de resultados.

        Returns:
            pd.DataFrame: Tabla lista para consola, exportación o Streamlit.

        Raises:
            RuntimeError: Si el cálculo aún no ha sido ejecutado.
        """

        # Asegurar que el calculo està actualizado
        self._verificar_calculado()

        # Getter seguro: no lanza excepción
        def g(clave, dec=5):
            try:
                valor = self.obtener(clave)
                if isinstance(valor, (int, float)):
                    return f"{valor:.{dec}f}"
                return valor
            except KeyError:
                return "-"

        filas = [] 

        # ------- Configuracion -------------------------------------------------------
        filas.append(("CONFIGURACIÓN GENERAL", "", ""))
        filas.append(("País:", "España", ""))
        filas.append(("Normativa:", "UNE EN 1991-1-4 + Anejo Nacional Español", ""))
        filas.append(("Densidad del aire [ρ]:", g("DENSIDAD_AIRE",2), "kg/m³"))
        filas.append(("Periodo de retorno [T]:", g("RETORNO",0), "años"))
        filas.append(("", "", ""))
        # ------- Características de la instalación ------------------------------------
        filas.append(("CARACTERÍSTICAS DE LA INSTALACIÓN", "", ""))
        filas.append(("Zona de viento:", g("ZONA"), ""))
        filas.append(("Categoría de terreno:", g("TERRENO"), ""))
        filas.append(("Altura de instalación:", g("ALTURA",2), "m"))
        filas.append(("", "", ""))
        # ------- Resultados principales -----------------------------------------------
        filas.append(("RESULTADOS PRINCIPALES", "", ""))
        filas.append(("Velocidad máxima del viento [vmax]:", g("VP",2), "km/h"))
        filas.append(("Presión dinámica asociada [qp]:", g("QP",2), "N/m²"))
        filas.append(("", "", ""))
        # ------- Cálculos intermedios y coeficientes empleados ------------------------
        filas.append(("CÁLCULOS INTERMEDIOS Y COEFICIENTES EMPLEADOS", "", ""))
        filas.append(("Coeficiente de dirección [cdir]", g("CDIR",2), ""))
        filas.append(("Coeficiente estacional [cseason]", g("CSEASON",2), ""))
        filas.append(("Coeficiente topográfico [co]", g("CTOPOGRAFICO",2), ""))
        filas.append(("Velocidad básica fundamental [vb,0]", g("VB0",2), "m/s"))
        filas.append(("Velocidad básica de referencia[vb,50]", g("VB50",2), "m/s"))
        filas.append(("Presión básica de referencia [qb,50]", g("QB50",2), "N/m²"))
        filas.append(("Factor de retorno  [cprob]", g("CPROB",), ""))
        filas.append(("Exponente de la fórmula de probabilidad [n]", g("N",3), ""))
        filas.append(("Factor de forma de la fórmula de probabilidad [K]", g("K",3), ""))
        filas.append((f"Velocidad básica ajustada ({g('RETORNO', 0)} años) [vb,r]", g("VB",2), "m/s"))
        filas.append(("Longitud de rugosidad [z0]", g("Z0",2), "m"))
        filas.append(("Longitud de rugosidad de referencia [z0II]", g("ZREF",2), "m"))
        filas.append(("Altura mínima [zmin]", g("ZMIN",2), "m"))
        filas.append(("Factor de terreno [Kr]", g("KR"), ""))
        filas.append(("Factor de rugosidad [cr(z)]", g("CR"), ""))
        filas.append(("Velocidad media ajustada al periodo de retorno [vm(z)]", g("VM",2), ""))
        filas.append(("Factor de turbulencia [K1]", g("K1",2), ""))
        filas.append(("Desviacion típica de la turbulencia [σv]", g("DESVIACION_TURBULENTA"), "m/s"))
        filas.append(("Intensida de turbulencia [Iv(z)]", g("IV",2) , "%"))
        filas.append(("Presión básica del viento ajustada al periodo de retorno [qb)]", g("QB",2) , "N/m²"))
        filas.append(("Coeficiente de exposicion calculado [ce)]", g("CE",2) , ""))

        df = pd.DataFrame(filas, columns = ["","",""])
        return df
    
    def normativa(self):
        """
        Devuelve la normativa aplicada.

        Returns:
            str: Referencia normativa completa.
        """
        return "UNE-EN 1991-1-4:2018 + AN/UNE-EN 1991-1-4 + UNE-EN 1990"

    def consultar_zonas(self):
        """
        Muestra por consola las zonas de viento disponibles.

        Imprime cada zona junto a su velocidad básica fundamental.
        """
        print("ZONAS DE VIENTO:")
        for llave, valor in self._ZONAS_VIENTO.items():
            print(f"{llave} : {valor} m/s")
    
    def consultar_terrenos(self):
        """
        Muestra por consola las categorías de terreno disponibles.

        Imprime cada categoría junto a su longitud de rugosidad de referencia.
        """
        print("CATEGORÍAS DE TERRENO:")
        for llave, valor in self._PARAMETROS_TERRENO.items():
            print(f"{llave} : {valor} m")

    def consultar_parametros(self):
        """
        Muestra por consola la descripción de parámetros calculados.

        Raises:
            ValueError: Si aún no se ha ejecutado :meth:`calcular`.
        """
        if self.calculo_realizado:
            print("PARÁMETROS DISPONIBLES TRAS EL CÁLCULO:")
            for llave, valor in self._parametros.items():
                print(f"{llave} : {valor} ")
        else:
            raise ValueError("El cálculo no se ha realizado aún. Por favor, ejecute el método calcular() antes de consultar los parámetros disponibles.")