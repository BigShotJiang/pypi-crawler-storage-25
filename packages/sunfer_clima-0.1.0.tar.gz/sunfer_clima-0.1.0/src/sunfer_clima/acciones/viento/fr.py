""" Las acciones del viento consideradas en el presente cálculo estructural se han determinado de acuerdo con:
        * EN 1991-1-4:2005 + A1:2010 — Eurocódigo 1: Acciones en estructuras. Parte 1-4: Acciones generales. Acciones de viento.
        * NF EN 1991-1-4/NA (para EN 1991-1-4:2005) — Anejo Nacional Francés, que establece los Parámetros de Determinación Nacional (NDP) y criterios de aplicación específicos para el territorio frances.
        * EN 1990 — Eurocódigo: Bases de diseño estructural.
    
    Contiene las clases:
    -  VientoEurocodeFR: Cálculo según EN 1991-1-4
"""


# ---------- IMPORTACION DE LIBRERIAS Y PAQUETES -----------------------------------------------------------------------------------------------------------------
import math 
from typing import Dict
from sunfer_clima.utilidades.conversor import convertir
from sunfer_clima.utilidades.topografia import calcular_co 
from .base import EurocodeViento
import pandas as pd


class VientoEurocodeFR(EurocodeViento):
    """
    Cálculo de acciones de viento en Francia según EN 1991-1-4 + Anejo nacional francés.
    """

    #-------- DATOS NORMATIVOS FIJOS PARA ESPAÑA ------------------------------------------------------------------------------------------------------------------
    _ZONAS_VIENTO: dict[str, float] = {
        "1": 22.0,
        "2": 24.0,
        "3": 26.0,
        "4": 28.0,
        "GUYANE": 17.0,
        "MAYOTTE": 29.0,
        "MARTINIQUE": 32.0,
        "REUNION": 34.0,
        "GUADELOUPE": 36.0,}

    _PARAMETROS_TERRENO = {
    "0": {"z0": 0.005, "zmin": 1.0},
    "II": {"z0": 0.05,  "zmin": 2.0},
    "IIIA": {"z0": 0.20, "zmin": 5.0},
    "IIIB":{"z0": 0.50, "zmin": 9.0},
    "IV": {"z0": 1.00, "zmin":15.0},
    }


    #-------- CONSTRUCTOR  ----------------------------------------------------------------------------------------------------------------------------------------

    def __init__(self, zona_viento: str, altura_instalacion: float, categoria_terreno: str, ) -> None:
        """
        Parámetros mínimos según Anejo Nacional Francés:
        - zona_viento: 1, 2, 3, 4, GUYANE, MAYOTTE, MARTINIQUE, REUNION, GUADELOUPE.
        - categoria_terreno: 0, II, IIA, IIIB o IV
        - altura_instalacion: z [m]
        """
        super().__init__(zona_viento=zona_viento, altura_instalacion=altura_instalacion,)

        self._categoria_terreno: str | None = None

        # Validación vía setters
        self.categoria_terreno = categoria_terreno

        #Densidad de aire modificada por defecto en francia
        self.densidad_aire = 1.225 #kg/m3

    #------ PROPIEDADES DE INSTANCIA (Con override opcional) No contenidas el el general --------------------------------------------------------------------------------------------------
    @property
    def categoria_terreno(self) -> str:
        return self._categoria_terreno
    @categoria_terreno.setter
    def categoria_terreno(self, value: str) -> None:
        value = value.upper()
        if value not in self._PARAMETROS_TERRENO:
            raise ValueError(
                "Categoría de terreno inválida. Opciones: 0, II, IIIA, IIIB, IV."
            )
        self._categoria_terreno = value
        self._invalidar_calculo()

    # ------------- IMPLEMENTACION DE LOS METODOS ABSTRACTOS ----------------------------------------------------------------------------------------------------- 
    def _velocidad_basica_fundamental(self) -> float: 
        return self._ZONAS_VIENTO[self._zona_viento]
    
    def _n(self): 
        return 0.5
    
    def _K(self):
        return 2
    
    def _Kr(self): 
        return 0.19*(self._z0()/self._z0II())**0.07

    def _K1(self):
        return 1.0 
    
    def _z0(self):
        return self._PARAMETROS_TERRENO[self.categoria_terreno]["z0"]
    
    def _zmin(self):
        return self._PARAMETROS_TERRENO[self.categoria_terreno]["zmin"]

# ------------- MÉTODOS COMPLEMENTARIOS  ----------------------------------------------------------------------------------------------------- 
    def _z0II(self): 
        return self._PARAMETROS_TERRENO["II"]["z0"]
    
# METODOS PUBLICOS --------------------------------------------------------------------------------------------------------------------------------------------------
    def normativa(self): 
            return """* NF-EN 1991-1-4:2018 — Eurocódigo 1: Acciones en estructuras. Parte 1-4: Acciones generales. Acciones de viento.
            * NF-EN 1991-1-4/NA — Anejo Nacional Francés, que establece los Parámetros de Determinación Nacional (NDP) y criterios de aplicación específicos para el territorio francés.
            * NF-EN 1990 — Eurocódigo: Bases de diseño estructural."""  
    
    def calcular(self):
        """
        Ejecuta el cálculo completo y almacena todos los resultados internos.
        """
        
        vb0 = self._velocidad_basica_fundamental()
        vb50 = self._velocidad_basica()
        qb50 = self._presion_basica_50()
        n = self._n()
        k = self._K()
        cprob = self._cprob()
        vb = self._velocidad_basica_retorno()
        z0 = self._z0()
        z0II = self._z0II()
        zmin = self._zmin()
        kr = self._Kr()
        cr = self._cr()
        vm = self._velocidad_media()
        K1 = self._K1()
        sigma_v = self._desviacion_turbulenta()
        Iv = self._intensidad_turbulencia() *100
        qb = self._presion_basica()
        qp = self._presion_dinamica()
        ce = self._ce()
        vp = convertir(qp, "N/m2", "km/h")

        self._datos= {
            "PAIS": "FRANCIA",
            "NORMATIVA": "NF-EN 1991-1-4:2018 — Eurocódigo 1 | NF-EN 1991-1-4/NA — Anejo Nacional Francés",
            "DENSIDAD": self.densidad_aire,
            "RETORNO": self.periodo_retorno,
            "CDIR": self.c_dir,
            "CSEASON": self.c_season,
            "CTOPOGRAFICO": self.c_topografico,
            "TERRENO": self.categoria_terreno,
            "ALTURA": self.altura_instalacion,
            "ZONA": self.zona_viento,
            "VB0": vb0,
            "VB50": vb50,
            "QB50": qb50,
            "CPROB": cprob,
            "N": n,
            "K": k,
            "VB": vb,
            "Z0": z0,
            "ZREF": z0II,
            "ZMIN": zmin,
            "KR": kr,
            "CR": cr,
            "VM": vm,
            "K1": K1,
            "DESVIACION_TURBULENTA": sigma_v,
            "IV": Iv,
            "QB": qb,
            "QP": qp,
            "CE": ce,
            "VP": vp
        }

        self._parametros = {
            "PAIS": "Descripción del país",
            "NORMATIVA": "Normativa aplicada para el cálculo",
            "DENSIDAD_AIRE": "Densidad del aire en kg/m³",
            "RETORNO": "Periodo de retorno en años",
            "CDIR": "Factor de dirección",
            "CSEASON": "Factor de estación",
            "CTOPOGRAFICO": "Factor topográfico",
            "TERRENO": "Categoría de terreno (0, I, II, III, IV)",
            "ALTURA": "Altura de instalación en metros", 
            "ZONA": "Zona de viento según EN 1991-1-4",
            "ZONA": "Zona de viento según EN 1991-1-4 + Anejo Nacional",
            "VB0": "Velocidad básica fundamental en m/s",
            "VB50": "Velocidad básica de Referencia 50 años en m/s",
            "QB50": "Presión básica de Referencia 50 años en N/m²",
            "CPROB": "Factor de probabilidad para el periodo de retorno",
            "N": "Exponente de la fórmula de probabilidad",
            "K": "Factor de forma de la fórmula de probabilidad",
            "VB": "Velocidad básica ajustada al periodo de retorno en m/s",
            "Z0": "Longitud de rugosidad del terreno en metros",
            "ZREF": "Longitud de rugosidad de referencia en metros",
            "ZMIN": "Altura mínima en metros",
            "KR": "Factor de rugosidad",
            "CR": "Factor de exposición",
            "VM": "Velocidad media en m/s",
            "K1": "Factor de turbulencia",
            "DESVIACION_TURBULENTA": "Desviación estándar de la turbulencia en m/s",
            "IV": "Intensidad de turbulencia en %",
            "QB": "Presión básica ajustada al periodo de retorno en N/m²",
            "QP": "Presión dinámica ajustada al periodo de retorno en N/m²",
            "CE": "Coeficiente de exposición",
            "VP": "Velocidad pico ajustada al periodo de retorno en km/h",}

        self.calculo_realizado = True

    def tabla(self): 
        """
        Devuelve un DataFrame con los resultados estructurados en bloques, con encabezados intercalados para mostrar en Streamlit.
        """

        # Asegurar que el calculo està actualizado
        self._verificar_calculado()

        # Getter seguro: no lanza excepción
        def g(clave, dec=5):
            try:
                valor = self.obtener(clave)
                if isinstance(valor, (int, float)):
                    return f"{valor:.{dec}f}"
                return valor
            except KeyError:
                return "-"

        filas = [] 

        # ------- Configuracion -------------------------------------------------------
        filas.append(("CONFIGURACIÓN GENERAL", "", ""))
        filas.append(("País:", "Francia", ""))
        filas.append(("Normativa:", "NF EN 1991-1-4 + Anejo Nacional Francés", ""))
        filas.append(("Densidad del aire [ρ]:", g("DENSIDAD",3), "kg/m³"))
        filas.append(("Periodo de retorno [T]:", g("RETORNO",0), "años"))
        filas.append(("", "", ""))
        # ------- Características de la instalación ------------------------------------
        filas.append(("CARACTERÍSTICAS DE LA INSTALACIÓN", "", ""))
        filas.append(("Zona de viento:", g("ZONA"), ""))
        filas.append(("Categoría de terreno:", g("TERRENO"), ""))
        filas.append(("Altura de instalación:", g("ALTURA",2), "m"))
        filas.append(("", "", ""))
        # ------- Resultados principales -----------------------------------------------
        filas.append(("RESULTADOS PRINCIPALES", "", ""))
        filas.append(("Velocidad máxima del viento [vmax]:", g("VP",2), "km/h"))
        filas.append(("Presión dinámica asociada [qp]:", g("QP",2), "N/m²"))
        filas.append(("", "", ""))
        # ------- Cálculos intermedios y coeficientes empleados ------------------------
        filas.append(("CÁLCULOS INTERMEDIOS Y COEFICIENTES EMPLEADOS", "", ""))
        filas.append(("Coeficiente de dirección [cdir]", g("CDIR",2), ""))
        filas.append(("Coeficiente estacional [cseason]", g("CSEASON",2), ""))
        filas.append(("Coeficiente topográfico [co]", g("CTOPO",2), ""))
        filas.append(("Velocidad básica fundamental [vb,0]", g("VB0",2), "m/s"))
        filas.append(("Velocidad básica [vb]", g("VB",2), "m/s"))
        filas.append(("Factor de retorno  [cprob]", g("CPROB",), ""))
        filas.append(("Exponente de la fórmula de probabilidad [n]", g("N",3), ""))
        filas.append(("Factor de forma de la fórmula de probabilidad [K]", g("K",3), ""))
        filas.append((f"Velocidad básica de referencia ({g("RETORNO",0)} años) [vb,r]", g("VBR",2), "m/s"))
        filas.append(("Longitud de rugosidad [z0]", g("Z0",2), "m"))
        filas.append(("Longitud de rugosidad de referencia [z0II]", g("Z0II",2), "m"))
        filas.append(("Altura mínima [zmin]", g("ZMIN",2), "m"))
        filas.append(("Factor de terreno [Kr]", g("KR"), ""))
        filas.append(("Factor de rugosidad [cr(z)]", g("CR"), ""))
        filas.append(("Velocidad media [vm(z)]", g("VM",2), ""))
        filas.append(("Factor de turbulencia [K1]", g("K1",2), ""))
        filas.append(("Desviacion típica de la turbulencia [σv]", g("DESVIACION_TURBULENTA"), ""))
        filas.append(("Intensida de turbulencia [Iv(z)]", g("IV",2) , "%"))
        filas.append(("Presión básica del vientoa [qb)]", g("QB",2) , "N/m²"))
        filas.append(("Coeficiente de exposicion calculado [ce)]", g("CE",2) , ""))

        df = pd.DataFrame(filas, columns = ["","",""])
        return df
    
    def consultar_zonas(self):
        print("ZONAS DE VIENTO:")
        for llave, valor in self._ZONAS_VIENTO.items():
            print(f"{llave} : {valor} m/s")

    def consultar_parametros(self):
            if self.calculo_realizado:
                print("PARÁMETROS DISPONIBLES TRAS EL CÁLCULO:")
                for llave, valor in self._parametros.items():
                    print(f"{llave} : {valor} ")
            else:
                raise ValueError("El cálculo no se ha realizado aún. Por favor, ejecute el método calcular() antes de consultar los parámetros disponibles.")