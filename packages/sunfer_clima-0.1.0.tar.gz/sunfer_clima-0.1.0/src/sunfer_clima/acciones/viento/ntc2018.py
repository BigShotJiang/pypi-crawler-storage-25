""" Las acciones del viento consideradas en el presente cálculo estructural se han determinado de acuerdo con:
        * NTC-2018 - Norme tecniche per le costruzioni.
    
    Contiene la clase:
    - VientoNTC2018: Cálculo según NTC-2018, Italia.
"""


# ---------- IMPORTACION DE LIBRERIAS Y PAQUETES -----------------------------------------------------------------------------------------------------------------
import math 
from typing import Dict, Any
from sunfer_clima.utilidades.conversor import convertir
from sunfer_clima.utilidades.topografia import calcular_co 
import pandas as pd


class VientoNTC2018():
    """
    Cálculo de acciones de viento en Italia según NTC-2018.
    """

    #-------- DATOS NORMATIVOS FIJOS PARA ITALIA ------------------------------------------------------------------------------------------------------------------
    _ZONAS_VIENTO: dict[str, float] = {
        "1": {"vb0":25.0,"a0":1000, "ks":0.40},
        "2": {"vb0":25.0,"a0":750, "ks":0.45},
        "3": {"vb0":27.0,"a0":500, "ks":0.37},
        "4": {"vb0":28.0,"a0":500, "ks":0.36},
        "5": {"vb0":28.0,"a0":750, "ks":0.40},
        "6": {"vb0":28.0,"a0":500, "ks":0.36},
        "7": {"vb0":28.0,"a0":1000, "ks":0.54},
        "8": {"vb0":30.0,"a0":1500, "ks":0.50},
        "9": {"vb0":31.0,"a0":500, "ks":0.32},
        }
    
    _CLASE_RUGOSIDAD = ["A", "B", "C", "D"]

    _PARAMETROS_TERRENO = {
    "I":{"kr":0.17, "z0": 0.01, "zmin": 2.0},
    "II":{"kr":0.19, "z0": 0.05, "zmin": 4.0},
    "III":{"kr":0.20, "z0": 0.10, "zmin": 5.0},
    "IV":{"kr":0.22, "z0": 0.3, "zmin": 8.0},
    "V": {"kr":0.23, "z0": 0.7, "zmin": 12.0},
    }

    # ---- CONFIGURACION GLOBAL: Propiedades de clase ------------------------------------------------------------------------------------------
    _densidad_aire_defecto: float = 1.25       # kg/m3
    _periodo_retorno_defecto: int = 25         # años
    _c_dir_defecto: float = 1.0                # coeficiente de dirección
    _c_season_defecto: float = 1.0             # coeficiente estacional
    _c_topografico_defecto: float = 1.0        # coeficiente topográfico


    #-------- CONSTRUCTOR  ----------------------------------------------------------------------------------------------------------------------------------------

    def __init__(self, zona_viento: str, altura_instalacion: float, clase_rugosidad:str, distancia_costa:float, altitud: float) -> None:
        """
        Parámetros mínimos según NTC-2018 para el cálculo de viento en Italia:
        - zona_viento: 1, 2, 3, 4, 5, 6, 7, 8, 9
        - categoria_terreno: A, B, C, D
        - altura_instalacion: z [m]
        -distancia a la costa: dcoast [m] (si es negativo se entiende que es desde el mar a la costa)
        -altitud: alt [m]
        """
        #Contenedor de datos de calculo de cada instancia e indicador de calculo ejecutado
        self._datos: Dict[str, Any] = {}
        self.calculo_realizado: bool = False

        self._periodo_retorno: int | None = None
        self._densidad_aire: float | None = None
        self._c_dir: float | None = None
        self._c_season: float | None = None
        self._c_topografico: float | None = None    
        
        self._zona_viento: str | None = None
        self._altura_instalacion: float | None = None

        # Validación vía setters
        self.zona_viento = zona_viento
        self.altura_instalacion = altura_instalacion
        self._clase_rugosidad: str | None = None
        self._distancia_costa: float | None = None
        self._altitud: float | None = None

        # Validación vía setters
        self.zona_viento = zona_viento
        self.altura_instalacion = altura_instalacion
        self.clase_rugosidad = clase_rugosidad
        self.distancia_costa = distancia_costa
        self.altitud = altitud

    #------ PROPIEDADES DE INSTANCIA (Con override opcional) No contenidas el el general --------------------------------------------------------------------------------------------------
    @property
    def periodo_retorno(self) -> int:
        return (
            self._periodo_retorno
            if self._periodo_retorno is not None
            else self.__class__._periodo_retorno_defecto
        )
    @periodo_retorno.setter
    def periodo_retorno(self, value: int) -> None:
        if value <= 0:
            raise ValueError("El periodo de retorno debe ser mayor que cero.")
        self._periodo_retorno = int(value)
        self._invalidar_calculo()

    @property
    def densidad_aire(self) -> float:
        return (
            self._densidad_aire
            if self._densidad_aire is not None
            else self.__class__._densidad_aire_defecto
        )
    @densidad_aire.setter
    def densidad_aire(self, value: float) -> None:
        if value <= 0:
            raise ValueError("La densidad del aire debe ser positiva.")
        if value > 1.8:
            raise ValueError("No se permiten densidades > 1.8 kg/m3.")
        self._densidad_aire = float(value)
        self._invalidar_calculo()

    @property
    def c_dir(self) -> float:
        return (
            self._c_dir
            if self._c_dir is not None
            else self.__class__._c_dir_defecto
        )
    @c_dir.setter
    def c_dir(self, value: float) -> None:
        if value <= 0:
            raise ValueError("El coeficiente de dirección debe ser positivo.")
        self._c_dir = float(value)
        self._invalidar_calculo()

    @property
    def c_season(self) -> float:
        return (
            self._c_season
            if self._c_season is not None
            else self.__class__._c_season_defecto
        )
    @c_season.setter
    def c_season(self, value: float) -> None:
        if value <= 0:
            raise ValueError("El coeficiente estacional debe ser positivo.")
        self._c_season = float(value)
        self._invalidar_calculo()

    @property
    def c_topografico(self) -> float:
        return (
            self._c_topografico
            if self._c_topografico is not None
            else self.__class__._c_topografico_defecto
        )
    @c_topografico.setter
    def c_topografico(self, value: float) -> None:
        if value <= 0:
            raise ValueError("El coeficiente topográfico debe ser positivo.")
        self._c_topografico = float(value)
        self._invalidar_calculo()

    @property
    def zona_viento(self) -> str:
        return self._zona_viento
    @zona_viento.setter
    def zona_viento(self, value: str) -> None:
        if value not in self._ZONAS_VIENTO:
            raise ValueError(
                f"Zona de viento no válida. Opciones: {list(self._ZONAS_VIENTO.keys())}"
            )
        self._zona_viento = value
        self._invalidar_calculo()

    @property
    def altura_instalacion(self) -> float:
        return self._altura_instalacion
    @altura_instalacion.setter
    def altura_instalacion(self, value: float) -> None:
        if value <= 0 or value > 200:
            raise ValueError("La altura de instalación debe ser > 0 y ≤ 200 m.")
        self._altura_instalacion = float(value)
        self._invalidar_calculo()
    
    @property
    def clase_rugosidad(self) -> str:
        return self._clase_rugosidad
    @clase_rugosidad.setter
    def clase_rugosidad(self, value: str) -> None:
        if value.upper() not in self._CLASE_RUGOSIDAD:
            raise ValueError(f"La clase de rugosidad es incorrecta. Elige entre ({self._CLASE_RUGOSIDAD}).")
        self._clase_rugosidad = value
        self._invalidar_calculo()
    
    @property
    def distancia_costa(self) -> float:
        return self._distancia_costa
    @distancia_costa.setter
    def distancia_costa(self, value: float) -> None:
        self._distancia_costa = value
        self._invalidar_calculo()
    
    @property
    def altitud(self) -> float:
        return self._altitud
    @altitud.setter
    def altitud(self, value: float) -> float:
        if value < 0: 
            raise ValueError ("La altitud debe ser positiva.")
        self._altitud = value
        self._invalidar_calculo()


    # ------------- IMPLEMENTACION DE LOS METODOS ABSTRACTOS ----------------------------------------------------------------------------------------------------- 
    def _velocidad_basica_fundamental(self) -> float: 
            return self._ZONAS_VIENTO[self.zona_viento]["vb0"]

    def _a0(self): 
        return self._ZONAS_VIENTO[self.zona_viento]["a0"]
    
    def _ks(self): 
        return self._ZONAS_VIENTO[self.zona_viento]["ks"]
    
    def _ca(self):
        if self.altitud <= self._a0():
            return 1.0
        elif self.altitud > self._a0() and self.altitud <= 1500:
            return 1 + self._ks() * (self.altitud / self._a0() -1)
        else:
            raise ValueError("La altitud debe ser menor o igual a 1500 m.")
    
    def _velocidad_basica_50(self):
        return self._velocidad_basica_fundamental() * self._ca() * self.c_dir * self.c_season * self.c_topografico
    
    def _cprob(self): 
        return 0.75 * math.sqrt(1-0.2*math.log(-1*math.log(1-1/self.periodo_retorno)))
    
    def _velocidad_basica_retorno(self): 
        return self._velocidad_basica() * self._cprob()
    
    def _presion_basica_50(self):
        return 0.5 * self.densidad_aire * self._velocidad_basica_50()**2

    def _presion_basica(self):
        return 0.5 * self.densidad_aire * self._velocidad_basica_retorno()**2  
    
    def _categoria_exposicion(self) -> float:
        if self.zona_viento in ["1", "2", "3", "4", "5"]:
            if self.clase_rugosidad == "A": #=========================================================================================
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno A en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 40000:
                    return "IV"
                else:
                    return "V"
            elif self.clase_rugosidad == "B":#=========================================================================================
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno B en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 40000:
                    return "III"
                else:
                    return "IV"
            elif self.clase_rugosidad == "C":#=========================================================================================
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno C en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 10000:
                    if self.zona_viento == "5":
                        return "III"
                    else:
                        return "II"
                elif self.altitud <= 500:
                    return "III"
                else:
                    return "IV"
            else: 
                if self.distancia_costa < 0:
                    return "I"
                elif self.altitud <= 500:
                    return "II"
                elif self.altitud <= 750:
                    return "III"
                else:
                    return "IV" if self.zona_viento == "1" else "III"
        elif self.zona_viento == "6":
            if self.clase_rugosidad == "A": 
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno A en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 10000:
                    return "III"
                elif 10000 < self.distancia_costa <= 40000:
                    return "IV"
                else:
                    return "V"
            elif self.clase_rugosidad == "B":
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno B en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 10000:
                    return "II"
                elif 10000 < self.distancia_costa <= 40000:
                    return "III"
                else:
                    return "IV"
            elif self.clase_rugosidad == "C":
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno C en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 10000:
                    return "II"
                elif 10000 < self.distancia_costa <= 40000:
                    return "III"
                else:
                    if self.altitud <= 500:
                        return "III"
                    else:
                        return "IV"
            else: 
                if self.distancia_costa < 10000:
                    return "I"
                elif self.altitud <= 500:
                    return "II"
                else:
                    return "III"
        elif self.zona_viento in ["7", "8"]:
            if self.clase_rugosidad in ["A", "B", "C"]: 
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno A , B o C en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa > 0:
                    return "III" if self.clase_rugosidad == "C" else "IV"
                else:
                    if self.distancia_costa < -500:
                        return "I"
                    elif self.altitud < 0:
                        return "II"
                    else:
                        return "III" if self.zona_viento == "7" else "II"
        else: #zona 9
            if self.distancia_costa > 0:
                return "I"
            else:
                if self.clase_rugosidad == "D":
                    return "I"
                else:
                    raise ValueError("No es posible la categoria de terreno A , B o C en interior de mar.Distancia costa < 0 m.")

    def _kr(self): 
        return self._PARAMETROS_TERRENO[self._categoria_exposicion()]["kr"]
    
    def _z0(self): 
        return self._PARAMETROS_TERRENO[self._categoria_exposicion()]["z0"]
    
    def _zmin(self): 
        return self._PARAMETROS_TERRENO[self._categoria_exposicion()]["zmin"]
    
    def _coeficiente_exposicion(self):
        z = max(self.altura_instalacion, self._zmin())
        return self._kr()**2 * math.log(z / self._z0())*(7 + self.c_topografico * math.log(z / self._z0())) 
    
    def _qp(self): 
        return self._presion_basica() * self._coeficiente_exposicion()
    
    def _vp(self): 
        return convertir(self._qp(), "N/m2", "km/h")

# METODOS PÚBLICOS -------------------------------------------------------------------------------------------------------------------------------------------------    
    def normativa(self): 
        return """* NTC-2018 - Norme tecniche per le costruzioni."""
    
    def calcular(self):
        """
        Ejecuta el cálculo completo y almacena todos los resultados internos.
        """
        vb0= self._velocidad_basica_fundamental()
        a0 = self._a0()
        ks = self._ks()
        ca = self._ca()
        vb50 = self._velocidad_basica_50()
        qb50 = self._presion_basica_50()
        cprob = self._cprob()
        vb = self._velocidad_basica_retorno()
        qb = self._presion_basica()
        catexp = self._categoria_exposicion()
        kr = self._kr()
        z0 = self._z0()
        zmin = self._zmin()
        ce = self._coeficiente_exposicion()
        qp = self._qp()
        vp = self._vp()



        self._datos= {
            "PAIS": "ITALIA",
            "NORMATIVA": "NTC-2018 - Norme tecniche per le costruzioni.",
            "DENSIDAD": self.densidad_aire,
            "RETORNO": self.periodo_retorno,
            "CDIR": self.c_dir,
            "CSEASON": self.c_season,
            "CTOPO": self.c_topografico,
            "ALTURA": self.altura_instalacion,
            "COSTA": self.distancia_costa,
            "ALTITUD": self.altitud,
            "ZONA": self.zona_viento,
            "CLASE_RUGOSIDAD": self.clase_rugosidad,
            "VB0": vb0,
            "A0": a0,
            "KS": ks,
            "CA": ca,
            "VB50": vb50,
            "QB50": qb50,
            "CPROB": cprob,
            "VB": vb,
            "CATEGORIA_EXPOSICION": catexp,
            "Z0": z0,
            "ZMIN": zmin,
            "KR": kr,
            "QB": qb,
            "QP": qp,
            "CE": ce,
            "VP": vp
        }

        self._parametros= {
            "PAIS": "Descripción del país para el que se realiza el cálculo.",
            "NORMATIVA": "UNI-EN 1991-1-4:2018 — Eurocódigo 1 | AN/UNI-EN 1991-1-4 — Anejo Nacional Italiano",
            "DENSIDAD": "Densidad del aire en kg/m³",
            "RETORNO": "Periodo de retorno en años",
            "CDIR": "Factor de dirección",
            "CSEASON": "Factor de estación",
            "CTOPO": "Factor topográfico",
            "ALTURA": "Altura de instalación en metros", 
            "COSTA": "Distancia a la costa en metros",
            "ALTITUD": "Altitud en metros",
            "ZONA": "Zona de viento según EN 1991-1-4",
            "CLASE_RUGOSIDAD": "Clase de rugosidad del terreno",
            "VB0": "Velocidad básica fundamental a nivel del mar en m/s",
            "A0": "Factor de corrección para la velocidad básica fundamental",
            "KA": "Factor de corrección para la velocidad básica fundamental",
            "VB50": "Velocidad básica para periodo de retorno 50 años [m/s]",
            "QB50": "Presión básica para periodo de retorno 50 años [N/m²]",
            "CPROB": "Factor de probabilidad asociado al periodo de retorno",
            "VB": "Velocidad básica ajustada al periodo de retorno [m/s]",
            "CATEGORIA_EXPOSICION": "Categoría de exposición del terreno",
            "Z0": "Longitud de rugosidad del terreno [m]",
            "ZMIN": "Altura mínima [m]",
            "KR": "Factor de terreno",
            "QB": "Presión básica ajustada al periodo de retorno en N/m²",
            "QP": "Presión dinámica ajustada al periodo de retorno en N/m²",
            "CE": "Coeficiente de exposición",
            "VP": "Velocidad pico ajustada al periodo de retorno en km/h",
        }


        self.calculo_realizado = True

    def tabla(self): 
        """
        Devuelve un DataFrame con los resultados estructurados en bloques, con encabezados intercalados para mostrar en Streamlit.
        """

        # Asegurar que el calculo està actualizado
        self._verificar_calculado()

        # Getter seguro: no lanza excepción
        def g(clave, dec=5):
            try:
                valor = self.obtener(clave)
                if isinstance(valor, (int, float)):
                    return f"{valor:.{dec}f}"
                return valor
            except KeyError:
                return "-"

        filas = [] 

        # ------- Configuracion -------------------------------------------------------
        filas.append(("CONFIGURACIÓN GENERAL", "", ""))
        filas.append(("País:", g("PAIS"), ""))
        filas.append(("Normativa:",  g("NORMATIVA"), ""))
        filas.append(("Densidad del aire [ρ]:", g("DENSIDAD",3), "kg/m³"))
        filas.append(("Periodo de retorno [T]:", g("RETORNO",0), "años"))
        filas.append(("", "", ""))
        # ------- Características de la instalación ------------------------------------
        filas.append(("CARACTERÍSTICAS DE LA INSTALACIÓN", "", ""))
        filas.append(("Zona de viento:", g("ZONA"), ""))
        filas.append(("Clase de rugosidad:", g("CLASE_RUGOSIDAD"), ""))
        filas.append(("Altura de instalación:", g("ALTURA",2), "m"))
        filas.append(("Distancia a la costa:", g("COSTA",2), "m"))
        filas.append(("Altitud:", g("ALTITUD",2), "m"))
        filas.append(("", "", ""))
        # ------- Resultados principales -----------------------------------------------
        filas.append(("RESULTADOS PRINCIPALES", "", ""))
        filas.append(("Velocidad máxima del viento [vmax]:", g("VP",2), "km/h"))
        filas.append(("Presión dinámica asociada [qp]:", g("QP",2), "N/m²"))
        filas.append(("", "", ""))
        # ------- Cálculos intermedios y coeficientes empleados ------------------------
        filas.append(("CÁLCULOS INTERMEDIOS Y COEFICIENTES EMPLEADOS", "", ""))
        filas.append(("Coeficiente de dirección [cdir]", g("CDIR",2), ""))
        filas.append(("Coeficiente estacional [cseason]", g("CSEASON",2), ""))
        filas.append(("Coeficiente topográfico [co]", g("CTOPO",2), ""))
        filas.append(("Velocidad básica fundamental referencial [vb,0*]", g("VB0",2), "m/s"))
        filas.append(("Coeficiente de altitud[ca]", g("CA",3), ""))
        filas.append(("Velocidad básica (T=50 años) [vb,50]", g("VB",2), "m/s"))
        filas.append(("Factor de retorno  [cprob]", g("RETORNO",0), ""))
        filas.append((f"Velocidad básica de referencia ({g("RETORNO",0)} años) [vb,r]", g("VBR",2), "m/s"))
        filas.append(("Categoria de exposición ", g("CATEGORIA_EXPOSICION",2), ""))
        filas.append(("Longitud de rugosidad [z0]", g("Z0",2), "m"))
        filas.append(("Altura mínima [zmin]", g("ZMIN",2), "m"))
        filas.append(("Factor de terreno [ks]", g("KR"), ""))
        filas.append(("Presión básica del vientoa [qb)]", g("QB",2) , "N/m²"))

        df = pd.DataFrame(filas, columns = ["","",""])
        return df
    
    def consultar_zonas(self):
        print("ZONAS DE VIENTO:")
        for llave, valor in self._ZONAS_VIENTO.items():
            print(f"{llave} : {valor} m/s")