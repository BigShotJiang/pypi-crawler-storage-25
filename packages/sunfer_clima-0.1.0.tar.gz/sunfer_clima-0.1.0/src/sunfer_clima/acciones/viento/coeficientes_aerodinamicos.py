

Tabla_cubiertas_planas = {

"afilado": {
    "F": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.8, "cp1": -2.5}},
    "G": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.2, "cp1": -2.0}},
    "H": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.7, "cp1": -1.2}},
    "I": {"presion": {"cp10": 0.2, "cp1": 0.2}, "succion": {"cp10": -0.2, "cp1": -0.2}},
},

"barandilla": {
    0.025: {
        "F": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.6, "cp1": -2.2}},
        "G": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.1, "cp1": -1.8}},
        "H": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.7, "cp1": -1.2}},
        "I": {"presion": {"cp10": 0.2, "cp1": 0.2}, "succion": {"cp10": -0.2, "cp1": -0.2}},
    },
    0.05: {
        "F": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.4, "cp1": -2.0}},
        "G": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.9, "cp1": -1.6}},
        "H": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.7, "cp1": -1.2}},
        "I": {"presion": {"cp10": 0.2, "cp1": 0.2}, "succion": {"cp10": -0.2, "cp1": -0.2}},
    },
    0.10: {
        "F": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.2, "cp1": -1.8}},
        "G": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.8, "cp1": -1.4}},
        "H": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.7, "cp1": -1.2}},
        "I": {"presion": {"cp10": 0.2, "cp1": 0.2}, "succion": {"cp10": -0.2, "cp1": -0.2}},
    },
},

"curvado": {
    0.05: {
        "F": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.0, "cp1": -1.5}},
        "G": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.2, "cp1": -1.8}},
        "H": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.4, "cp1": -0.4}},
        "I": {"presion": {"cp10": 0.2, "cp1": 0.2}, "succion": {"cp10": -0.2, "cp1": -0.2}},
    },
    0.10: {
        "F": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.7, "cp1": -1.2}},
        "G": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.8, "cp1": -1.4}},
        "H": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.3, "cp1": -0.3}},
        "I": {"presion": {"cp10": 0.2, "cp1": 0.2}, "succion": {"cp10": -0.2, "cp1": -0.2}},
    },
    0.20: {
        "F": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.5, "cp1": -0.8}},
        "G": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.5, "cp1": -0.8}},
        "H": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.3, "cp1": -0.3}},
        "I": {"presion": {"cp10": 0.2, "cp1": 0.2}, "succion": {"cp10": -0.2, "cp1": -0.2}},
    },
},

"amansardado": {
    30: {
        "F": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.0, "cp1": -1.5}},
        "G": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.0, "cp1": -1.5}},
        "H": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.3, "cp1": -0.3}},
        "I": {"presion": {"cp10": 0.2, "cp1": 0.2}, "succion": {"cp10": -0.2, "cp1": -0.2}},
    },
    45: {
        "F": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.2, "cp1": -1.8}},
        "G": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.3, "cp1": -1.9}},
        "H": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.4, "cp1": -0.4}},
        "I": {"presion": {"cp10": 0.2, "cp1": 0.2}, "succion": {"cp10": -0.2, "cp1": -0.2}},
    },
    60: {
        "F": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.3, "cp1": -1.9}},
        "G": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -1.3, "cp1": -1.9}},
        "H": {"presion": {"cp10": 0, "cp1": 0}, "succion": {"cp10": -0.5, "cp1": -0.5}},
        "I": {"presion": {"cp10": 0.2, "cp1": 0.2}, "succion": {"cp10": -0.2, "cp1": -0.2}},
    },
}}


Tabla_marquesinas = {

0: {
    "presion": {"global": 0.2, "A": 0.5, "B": 1.8, "C": 1.1},
    "succion_0": {"global": -0.5, "A": -0.6, "B": -1.3, "C": -1.4},
    "succion_1": {"global": -1.3, "A": -1.5, "B": -1.8, "C": -2.2},
},

5: {
    "presion": {"global": 0.4, "A": 0.8, "B": 2.1, "C": 1.3},
    "succion_0": {"global": -0.7, "A": -1.1, "B": -1.7, "C": -1.8},
    "succion_1": {"global": -1.4, "A": -1.6, "B": -2.2, "C": -2.5},
},

10: {
    "presion": {"global": 0.5, "A": 1.2, "B": 2.4, "C": 1.6},
    "succion_0": {"global": -0.9, "A": -1.5, "B": -2.0, "C": -2.1},
    "succion_1": {"global": -1.4, "A": -1.6, "B": -2.6, "C": -2.7},
},

15: {
    "presion": {"global": 0.7, "A": 1.4, "B": 2.7, "C": 1.8},
    "succion_0": {"global": -1.1, "A": -1.8, "B": -2.4, "C": -2.5},
    "succion_1": {"global": -1.4, "A": -1.6, "B": -2.9, "C": -3.0},
},

20: {
    "presion": {"global": 0.8, "A": 1.7, "B": 2.9, "C": 2.1},
    "succion_0": {"global": -1.3, "A": -2.2, "B": -2.8, "C": -2.9},
    "succion_1": {"global": -1.4, "A": -1.6, "B": -2.9, "C": -3.0},
},

25: {
    "presion": {"global": 1.0, "A": 2.0, "B": 3.1, "C": 2.3},
    "succion_0": {"global": -1.6, "A": -2.6, "B": -3.2, "C": -3.2},
    "succion_1": {"global": -1.4, "A": -1.5, "B": -2.5, "C": -2.8},
},

30: {
    "presion": {"global": 1.2, "A": 2.2, "B": 3.2, "C": 2.4},
    "succion_0": {"global": -1.8, "A": -3.0, "B": -3.8, "C": -3.6},
    "succion_1": {"global": -1.4, "A": -1.5, "B": -2.2, "C": -2.7},
}}


def interpolar(x,x1,x2,y1,y2):
        """Interpolación lineal"""
        return y1 + (x - x1) * (y2 - y1) / (x2 - x1)
    
def cp_cubierta_plana(tipo, zona, caso="succion", cp="cp10", **kwargs):

    if tipo not in Tabla_cubiertas_planas:
        raise ValueError(f"Tipo de cubierta '{tipo}' no reconocido")
    datos_tipo = Tabla_cubiertas_planas[tipo]
    # --- CASO SIN PARÁMETROS ---
    if tipo == "afilado":
        if zona not in datos_tipo:
            raise ValueError(f"Zona '{zona}' no válida")
        return datos_tipo[zona][caso][cp]
    # --- OBTENER PARÁMETRO GEOMÉTRICO ---
    if tipo == "barandilla":
        hp = kwargs.get("hp")
        h = kwargs.get("h")
        if hp is None or h is None:
            raise ValueError("Para cubierta con barandilla debes introducir hp y h")
        valor = hp / h
    elif tipo == "curvado":
        r = kwargs.get("r")
        h = kwargs.get("h")
        if r is None or h is None:
            raise ValueError("Para alero curvado debes introducir r y h")
        valor = r / h
    elif tipo == "mansardado":
        valor = kwargs.get("alpha")
        if valor is None:
            raise ValueError("Para alero mansardado debes introducir alpha")
    else:
        raise ValueError("Tipo de cubierta no reconocido")

    # --- INTERPOLACIÓN ---
    claves = sorted(datos_tipo.keys())
    xmin = claves[0]
    xmax = claves[-1]
    # saturación inferior
    if valor <= xmin:
        return datos_tipo[xmin][zona][caso][cp]
    # saturación superior
    if valor >= xmax:
        return datos_tipo[xmax][zona][caso][cp]
    # valor exacto en tabla
    if valor in datos_tipo:
        return datos_tipo[valor][zona][caso][cp]
    # interpolación lineal
    for i in range(len(claves) - 1):
        x1 = claves[i]
        x2 = claves[i + 1]
        if x1 <= valor <= x2:
            y1 = datos_tipo[x1][zona][caso][cp]
            y2 = datos_tipo[x2][zona][caso][cp]
            return round(interpolar(valor, x1, x2, y1, y2),2)
    raise ValueError("Error en interpolación de tabla")

def cp_marquesina(inclinacion, zona="global", caso="presion", bloqueo=0):
    bloqueo = bloqueo/100 #ya que el bloquo se introduce como porcentaje
    tabla = Tabla_marquesinas
    angulos = sorted(tabla.keys())
    amin = angulos[0]
    amax = angulos[-1]

    # saturación de ángulo
    if inclinacion <= amin:
        a1 = a2 = amin
    elif inclinacion >= amax:
        a1 = a2 = amax
    else:
        for i in range(len(angulos) - 1):
            if angulos[i] <= inclinacion <= angulos[i+1]:
                a1 = angulos[i]
                a2 = angulos[i+1]
                break

    # --- CASO MAXIMO ---
    if caso == "presion":
        y1 = tabla[a1]["presion"][zona]
        y2 = tabla[a2]["presion"][zona]
        if a1 == a2:
            return y1
        return interpolar(inclinacion, a1, a2, y1, y2)

    # --- CASO MINIMO ---
    elif caso == "succion":
        if bloqueo is None:
            raise ValueError("Debes proporcionar el porcentaje de bloqueo para el caso mínimo")
        # limitar phi al rango
        phi = max(0, min(1, bloqueo))

        # valores para φ = 0
        y1_phi0 = tabla[a1]["succion_0"][zona]
        y2_phi0 = tabla[a2]["succion_0"][zona]

        # valores para φ = 1
        y1_phi1 = tabla[a1]["succion_1"][zona]
        y2_phi1 = tabla[a2]["succion_1"][zona]

        # interpolación en ángulo
        if a1 == a2:
            v_phi0 = y1_phi0
            v_phi1 = y1_phi1
        else:
            v_phi0 = interpolar(inclinacion, a1, a2, y1_phi0, y2_phi0)
            v_phi1 = interpolar(inclinacion, a1, a2, y1_phi1, y2_phi1)

        # interpolación en bloqueo
        return round(interpolar(phi, 0, 1, v_phi0, v_phi1),2)

    else:
        raise ValueError("caso debe ser 'presion' o 'succion'")

