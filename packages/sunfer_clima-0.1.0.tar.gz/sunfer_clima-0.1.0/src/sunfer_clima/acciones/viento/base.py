"""
Módulo: base.py
===============

Define la clase abstracta EurocodeViento, base para el cálculo de la acción
del viento conforme al Eurocódigo EN 1991-1-4.

Esta clase implementa:

- La formulación general del modelo aerodinámico del Eurocódigo.
- La gestión de parámetros físicos y coeficientes normativos.
- Validaciones de entrada.
- Métodos comunes de cálculo.
- La interfaz obligatoria que deben implementar las normativas nacionales.

Está diseñada para ser extendida por clases específicas de cada país,
las cuales deben definir los parámetros del Anejo Nacional correspondiente.

Autor: Rafa Crespo
Versión: 1.0
"""

from abc import ABC, abstractmethod
import math
from typing import Any, Dict
from sunfer_clima.utilidades.conversor import convertir
from sunfer_clima.acciones.comunes.accion_climatica import AccionClimatica
import numpy as np


class EurocodeViento(AccionClimatica, ABC):
    """
    Clase base abstracta para el cálculo del viento según EN 1991-1-4.

    Proporciona la implementación común del modelo de viento del Eurocódigo,
    incluyendo:

    - Velocidad básica fundamental
    - Corrección por periodo de retorno
    - Perfil logarítmico del viento
    - Intensidad de turbulencia
    - Presión dinámica de pico
    - Coeficiente de exposición

    Cada país debe implementar una subclase que defina:

    - Velocidad básica fundamental por zona
    - Parámetros estadísticos (n, K)
    - Parámetros de rugosidad
    - Parámetros topográficos
    - Tabla de resultados

    No puede instanciarse directamente.
    """

    limite_altura = 200  # Altura de instalación válida en metros

    # ---- PROPIEDADES DE CLASE POR DEFECTO ------------------------------------------------------------------------------------------
    _densidad_aire_defecto: float = 1.25
    _periodo_retorno_defecto: int = 25
    _c_dir_defecto: float = 1.0
    _c_season_defecto: float = 1.0
    _c_topografico_defecto: float = 1.0

    #---- CONSTRUCTOR  -------------------------------------------------------------------------------------------------------
    def __init__(self, zona_viento: str, altura_instalacion: float) -> None:
        """
        Inicializa la acción de viento.

        Parameters
        ----------
        zona_viento : str
            Zona eólica según normativa nacional.
        altura_instalacion : float
            Altura sobre el terreno en metros.

        Raises
        ------
        ValueError
            Si la zona no es válida o la altura está fuera de rango.
        """
        super().__init__()
        self._datos: Dict[str, Any] = {}
        self._zona_viento: str | None = None
        self._altura_instalacion: float | None = None
        self._periodo_retorno: int | None = None
        self._densidad_aire: float | None = None
        self._c_dir: float | None = None
        self._c_season: float | None = None
        self._c_topografico: float | None = None

        # Validación mediante setters
        self.zona_viento = zona_viento
        self.altura_instalacion = altura_instalacion

    # ------ PROPIEDADES DE INSTANCIA --------------------------------------------------------------------------------------------------
    @property
    def zona_viento(self) -> str:
        """Zona eólica según Anejo Nacional."""
        return self._zona_viento
    @zona_viento.setter
    def zona_viento(self, value: str) -> None:
        if value not in self._ZONAS_VIENTO:
            raise ValueError(f"Zona de viento no válida. Opciones: {list(self._ZONAS_VIENTO.keys())}")
        self._zona_viento = value
        self._invalidar_calculo()

    @property
    def altura_instalacion(self) -> float:
        """Altura sobre el terreno en metros."""
        return self._altura_instalacion
    @altura_instalacion.setter
    def altura_instalacion(self, value: float) -> None:
        if value < 0 or value > self.limite_altura:
            raise ValueError(f"La altura de instalación debe ser >= 0 y ≤ {self.limite_altura} m.")
        if value == 0:
            self._altura_instalacion = 0.01  # Evitar división por cero en perfil logarítmico
        else:
            self._altura_instalacion = float(value)
        self._invalidar_calculo()

    @property
    def periodo_retorno(self) -> int:
        """
        Periodo de retorno en años.

        Por defecto: 25 años.
        """
        return self._periodo_retorno if self._periodo_retorno is not None else self.__class__._periodo_retorno_defecto
    @periodo_retorno.setter
    def periodo_retorno(self, value: int) -> None:
        if value <= 0:
            raise ValueError("El periodo de retorno debe ser mayor que cero.")
        self._periodo_retorno = int(value)
        self._invalidar_calculo()
    
    @property
    def densidad_aire(self) -> float:
        """
        Densidad del aire en kg/m³.
        Por defecto: 1.25 kg/m³.
        """
        return self._densidad_aire if self._densidad_aire is not None else self.__class__._densidad_aire_defecto
    @densidad_aire.setter
    def densidad_aire(self, value: float) -> None:
        if value <= 0 or value > 1.8:
            raise ValueError("La densidad del aire debe estar entre 0 y 1.8 kg/m3.")
        self._densidad_aire = float(value)
        self._invalidar_calculo()

    @property
    def c_dir(self) -> float:
        """Coeficiente direccional."""
        return self._c_dir if self._c_dir is not None else self.__class__._c_dir_defecto
    @c_dir.setter
    def c_dir(self, value: float) -> None:
        if value <= 0:
            raise ValueError("El coeficiente de dirección debe ser positivo.")
        self._c_dir = float(value)
        self._invalidar_calculo()

    @property
    def c_season(self) -> float:
        """Coeficiente estacional."""
        return self._c_season if self._c_season is not None else self.__class__._c_season_defecto
    @c_season.setter
    def c_season(self, value: float) -> None:
        if value <= 0:
            raise ValueError("El coeficiente estacional debe ser positivo.")
        self._c_season = float(value)
        self._invalidar_calculo()

    @property
    def c_topografico(self) -> float:
        """Coeficiente topográfico."""
        return self._c_topografico if self._c_topografico is not None else self.__class__._c_topografico_defecto
    @c_topografico.setter
    def c_topografico(self, value: float) -> None:
        if value <= 0:
            raise ValueError("El coeficiente topográfico debe ser positivo.")
        self._c_topografico = float(value)
        self._invalidar_calculo()

# ------ MÉTODOS ABSTRACTOS QUE DEBEN IMPLEMENTARSE POR PAÍS -------------------------------------------------------------
    @abstractmethod
    def _velocidad_basica_fundamental(self) -> float:
        """Devuelve la velocidad básica fundamental vb,0 según zona."""
        pass

    @abstractmethod
    def _n(self) -> float:
        """Parámetro estadístico n."""
        pass

    @abstractmethod
    def _K(self) -> float:
        """Parámetro estadístico K."""
        pass

    @abstractmethod
    def _Kr(self) -> float:
        """Factor de rugosidad."""
        pass

    @abstractmethod
    def _K1(self) -> float:
        """Factor de turbulencia."""
        pass

    @abstractmethod
    def normativa(self) -> str:
        pass

    @abstractmethod
    def _z0(self) -> float:
        """Longitud de rugosidad."""
        pass

    @abstractmethod
    def _zmin(self) -> float:
        """Altura mínima reglamentaria."""
        pass

    @abstractmethod
    def calcular(self):
        """Ejecuta el cálculo completo."""
        pass

    @abstractmethod
    def tabla(self):
        """Devuelve tabla resumen de resultados."""
        pass

    @abstractmethod
    def consultar_zonas(self):
        """Devuelve las zonas de viento disponibles."""
        pass

    @abstractmethod
    def consultar_terrenos(self):
        """Devuelve las categorias de terreno disponibles."""
        pass

    @abstractmethod
    def consultar_parametros(self):
        """Devuelve los parametros calculados accesibles mediante el metodo obtener()."""
        pass
   
# ------ MÉTODOS COMUNES RESULTADOS CLIMATICOS ------------------------------------------------------------------------------------------------
    def _cprob(self) -> float:
        """Coeficiente de probabilidad para periodo de retorno."""
        T= self.periodo_retorno
        Tref = 50
        p = 1 - 0.98 ** (Tref / T)
        n = self._n()
        K = self._K()
        num = 1 - K * math.log(-math.log(1 - p))
        den = 1 - K * math.log(-math.log(0.98))
        return (num / den) ** n

    def _cr(self) -> float:
        """Coeficiente de rugosidad por perfil logarítmico."""
        z = self.altura_instalacion
        z0 = self._z0()
        zmin = self._zmin()
        kr = self._Kr()
        if z <= zmin:
            return kr * math.log(zmin / z0)
        return kr * math.log(z / z0)

    def _velocidad_basica(self):
        """Velocidad básica corregida por dirección y estación."""
        return self._velocidad_basica_fundamental() * self.c_dir * self.c_season

    def _velocidad_basica_retorno(self):
        """Velocidad básica corregida por periodo de retorno."""
        return self._velocidad_basica() * self._cprob()

    def _velocidad_media(self):
        """Velocidad media a la altura z."""
        return self._cr() * self.c_topografico * self._velocidad_basica_retorno()

    def _presion_basica(self):
        """Presión básica qb asosiada al periodo de retorno."""
        return 0.5 * self.densidad_aire * self._velocidad_basica_retorno() ** 2

    def _presion_basica_50(self):
        """Presión básica para periodo de retorno de referencia (50 años)."""
        return 0.5 * self.densidad_aire * self._velocidad_basica() ** 2 
    
    def _desviacion_turbulenta(self):
        """Desviación estándar de la turbulencia."""
        return self._Kr() * self._velocidad_basica_retorno() * self._K1()

    def _intensidad_turbulencia(self):
        """Intensidad de turbulencia Iv."""
        return self._K1() / (self.c_topografico * math.log(max(self.altura_instalacion, self._zmin()) / self._z0()))

    def _presion_dinamica(self):
        """Presión dinámica de pico qp."""
        Iv = self._intensidad_turbulencia()
        return ((1 + 7 * Iv) * 0.5 * self.densidad_aire * self._velocidad_media() ** 2)

    def _velocidad_pico(self) -> float:
        """Velocidad pico equivalente."""
        qp = self._presion_dinamica()
        return convertir(qp, "Pa", "m/s", self.densidad_aire)

    def _ce(self) -> float:
        """Coeficiente de exposición."""
        return self._presion_dinamica() / self._presion_basica()
