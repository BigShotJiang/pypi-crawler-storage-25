""" Las acciones del viento consideradas en el presente cálculo estructural se han determinado de acuerdo con:
        * UNI-EN 1991-1-4:2018 — Eurocódigo 1: Acciones en estructuras. Parte 1-4: Acciones generales. Acciones de viento.
        * AN/UNI-EN 1991-1-4 — Anejo Nacional Italiano, que establece los Parámetros de Determinación Nacional (NDP) y criterios de aplicación específicos para el territorio Italiano.
        * UNI-EN 1990 — Eurocódigo: Bases de diseño estructural.
    
    Contiene las clases:
    - VientoEurocodeIT: Cálculo según EN 1991-1-4
"""


# ---------- IMPORTACION DE LIBRERIAS Y PAQUETES -----------------------------------------------------------------------------------------------------------------
import math 
from typing import Dict
from sunfer_clima.utilidades.conversor import convertir
from sunfer_clima.utilidades.topografia import calcular_co 
from .base import EurocodeViento
import pandas as pd


class VientoEurocodeIT(EurocodeViento):
    """
    Cálculo de acciones de viento en Italia según EN 1991-1-4 + Anejo nacional Italiano.
    """

    #-------- DATOS NORMATIVOS FIJOS PARA ITALIA ------------------------------------------------------------------------------------------------------------------
    _ZONAS_VIENTO: dict[str, float] = {
        "1": {"vb0":25.0,"a0":1000, "ka":0.01},
        "2": {"vb0":25.0,"a0":750, "ka":0.01},
        "3": {"vb0":27.0,"a0":500, "ka":0.01},
        "4": {"vb0":28.0,"a0":500, "ka":0.01},
        "5": {"vb0":28.0,"a0":750, "ka":0.01},
        "6": {"vb0":28.0,"a0":500, "ka":0.01},
        "7": {"vb0":28.0,"a0":1000, "ka":0.01},
        "8": {"vb0":30.0,"a0":1500, "ka":0.01},
        "9": {"vb0":31.0,"a0":500, "ka":0.01},
        }
    
    _CLASE_RUGOSIDAD = ["A", "B", "C", "D"]

    _PARAMETROS_TERRENO = {
    "I":{"kr":0.17, "z0": 0.01, "zmin": 2.0},
    "II":{"kr":0.19, "z0": 0.05, "zmin": 4.0},
    "III":{"kr":0.20, "z0": 0.10, "zmin": 5.0},
    "IV":{"kr":0.22, "z0": 0.3, "zmin": 8.0},
    "V": {"kr":0.23, "z0": 0.7, "zmin": 12.0},
    }


    #-------- CONSTRUCTOR  ----------------------------------------------------------------------------------------------------------------------------------------

    def __init__(self, zona_viento: str, altura_instalacion: float, clase_rugosidad:str, distancia_costa:float, altitud: float) -> None:
        """
        Parámetros mínimos según Anejo Nacional Italiano:
        - zona_viento: 1, 2, 3, 4, 5, 6, 7, 8, 9
        - categoria_terreno: A, B, C, D
        - altura_instalacion: z [m]
        -distancia a la costa: dcoast [m] (si es negativo se entiende que es desde el mar a la costa)
        -altitud: alt [m]
        """
        super().__init__(zona_viento=zona_viento, altura_instalacion=altura_instalacion,)

        self._clase_rugosidad: str | None = None
        self._distancia_costa: float | None = None
        self._altitud: float | None = None

        # Validación vía setters
        self.clase_rugosidad = clase_rugosidad
        self.distancia_costa = distancia_costa
        self.altitud = altitud

    #------ PROPIEDADES DE INSTANCIA (Con override opcional) No contenidas el el general --------------------------------------------------------------------------------------------------
    @property
    def clase_rugosidad(self) -> str:
        return self._clase_rugosidad
    @clase_rugosidad.setter
    def clase_rugosidad(self, value: str) -> None:
        if value.upper() not in self._CLASE_RUGOSIDAD:
            raise ValueError(f"La clase de rugosidad es incorrecta. Elige entre ({self._CLASE_RUGOSIDAD}).")
        self._clase_rugosidad = value
        self._invalidar_calculo()
    
    @property
    def distancia_costa(self) -> float:
        return self._distancia_costa
    @distancia_costa.setter
    def distancia_costa(self, value: float) -> None:
        self._distancia_costa = value
        self._invalidar_calculo()
    
    @property
    def altitud(self) -> float:
        return self._altitud
    @altitud.setter
    def altitud(self, value: float) -> float:
        if value < 0: 
            raise ValueError ("La altitud debe ser positiva.")
        self._altitud = value
        self._invalidar_calculo()


    # ------------- IMPLEMENTACION DE LOS METODOS ABSTRACTOS ----------------------------------------------------------------------------------------------------- 
    def _velocidad_basica_fundamental(self) -> float: 
        if self.altitud <= self._a0(): 
            return self._vb0_tabla() 
        else: 
            if self.altitud >1500:
                return self._vb0_tabla() + self._ka() * (1500 - self._a0())
            return self._vb0_tabla() + self._ka() * (self.altitud - self._a0())
    
    def _n(self): 
        return 0.5 if self.periodo_retorno <=50 else 1.0
    
    def _K(self):
        return 0.2 if self.periodo_retorno <=50 else 0.138
    
    def _Kr(self): 
        return self._PARAMETROS_TERRENO[self._categoria_exposicion()]["kr"]

    def _K1(self):
        return 1.0 
    
    def normativa(self): 
        return """* UNI-EN 1991-1-4:2018 — Eurocódigo 1: Acciones en estructuras. Parte 1-4: Acciones generales. Acciones de viento.
        * AN/UNI-EN 1991-1-4 — Anejo Nacional Italiano, que establece los Parámetros de Determinación Nacional (NDP) y criterios de aplicación específicos para el territorio italiano.
        * UNI-EN 1990 — Eurocódigo: Bases de diseño estructural."""
    
    def _z0(self):
        return self._PARAMETROS_TERRENO[self._categoria_exposicion()]["z0"]
    
    def _zmin(self):
        return self._PARAMETROS_TERRENO[self._categoria_exposicion()]["zmin"]
    
    # ------------- MÉTODOS COMPLEMENTARIOS  ----------------------------------------------------------------------------------------------------- 
    def _vb0_tabla(self): 
        return self._ZONAS_VIENTO[self.zona_viento]["vb0"]
    
    def _a0(self): 
        return self._ZONAS_VIENTO[self.zona_viento]["a0"]
    
    def _ka(self): 
        return self._ZONAS_VIENTO[self.zona_viento]["ka"]
    
    def _categoria_exposicion(self) -> float:
        if self.zona_viento in ["1", "2", "3", "4", "5"]:
            if self.clase_rugosidad == "A": #=========================================================================================
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno A en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 40000:
                    return "IV"
                else:
                    return "V"
            elif self.clase_rugosidad == "B":#=========================================================================================
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno B en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 40000:
                    return "III"
                else:
                    return "IV"
            elif self.clase_rugosidad == "C":#=========================================================================================
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno C en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 10000:
                    if self.zona_viento == "5":
                        return "III"
                    else:
                        return "II"
                elif self.altitud <= 500:
                    return "III"
                else:
                    return "IV"
            else: 
                if self.distancia_costa < 0:
                    return "I"
                elif self.altitud <= 500:
                    return "II"
                elif self.altitud <= 750:
                    return "III"
                else:
                    return "IV" if self.zona_viento == "1" else "III"
        elif self.zona_viento == "6":
            if self.clase_rugosidad == "A": 
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno A en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 10000:
                    return "III"
                elif 10000 < self.distancia_costa <= 40000:
                    return "IV"
                else:
                    return "V"
            elif self.clase_rugosidad == "B":
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno B en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 10000:
                    return "II"
                elif 10000 < self.distancia_costa <= 40000:
                    return "III"
                else:
                    return "IV"
            elif self.clase_rugosidad == "C":
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno C en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa <= 10000:
                    return "II"
                elif 10000 < self.distancia_costa <= 40000:
                    return "III"
                else:
                    if self.altitud <= 500:
                        return "III"
                    else:
                        return "IV"
            else: 
                if self.distancia_costa < 10000:
                    return "I"
                elif self.altitud <= 500:
                    return "II"
                else:
                    return "III"
        elif self.zona_viento in ["7", "8"]:
            if self.clase_rugosidad in ["A", "B", "C"]: 
                if self.distancia_costa < 0:
                    raise ValueError("No es posible la categoria de terreno A , B o C en interior de mar.Distancia costa < 0 m.")
                elif self.distancia_costa > 0:
                    return "III" if self.clase_rugosidad == "C" else "IV"
                else:
                    if self.distancia_costa < -500:
                        return "I"
                    elif self.altitud < 0:
                        return "II"
                    else:
                        return "III" if self.zona_viento == "7" else "II"
        else: #zona 9
            if self.distancia_costa > 0:
                return "I"
            else:
                if self.clase_rugosidad == "D":
                    return "I"
                else:
                    raise ValueError("No es posible la categoria de terreno A , B o C en interior de mar.Distancia costa < 0 m.")

# METODOS PÚBLICOS --------------------------------------------------------------------------------------------------------------------------------------   

    def calcular(self):
        """
        Ejecuta el cálculo completo y almacena todos los resultados internos.
        """
        vb0_tabla = self._vb0_tabla()
        vb0 = self._velocidad_basica_fundamental()
        a0 = self._a0()
        ka = self._ka()
        vb50 = self._velocidad_basica()
        qb50 = self._presion_basica_50()
        n = self._n()
        k = self._K()
        cprob = self._cprob()
        vb = self._velocidad_basica_retorno()
        catexp = self._categoria_exposicion()
        z0 = self._z0()
        zmin = self._zmin()
        kr = self._Kr()
        cr = self._cr()
        vm = self._velocidad_media()
        K1 = self._K1()
        sigma_v = self._desviacion_turbulenta()
        Iv = self._intensidad_turbulencia()*100
        qb = self._presion_basica()
        qp = self._presion_dinamica()
        ce = self._ce()
        vp = convertir(qp, "N/m2", "km/h")

        self._datos= {
            "PAIS": "ITALIA",
            "NORMATIVA": "UNI-EN 1991-1-4:2018 — Eurocódigo 1 | AN/UNI-EN 1991-1-4 — Anejo Nacional Italiano",
            "DENSIDAD": self.densidad_aire,
            "RETORNO": self.periodo_retorno,
            "CDIR": self.c_dir,
            "CSEASON": self.c_season,
            "CTOPO": self.c_topografico,
            "ALTURA": self.altura_instalacion,
            "COSTA": self.distancia_costa,
            "ALTITUD": self.altitud,
            "ZONA": self.zona_viento,
            "CLASE_RUGOSIDAD": self.clase_rugosidad,
            "VB0*": vb0_tabla,
            "VB0": vb0,
            "A0": a0,
            "KA": ka,
            "VB50": vb50,
            "QB50": qb50,
            "N": n,
            "K": k,
            "CPROB": cprob,
            "VB": vb,
            "CATEGORIA_EXPOSICION": catexp,
            "Z0": z0,
            "ZMIN": zmin,
            "KR": kr,
            "CR": cr,
            "VM": vm,
            "K1": K1,
            "DESVIACION_TURBULENTA": sigma_v,
            "IV": Iv,
            "QB": qb,
            "QP": qp,
            "CE": ce,
            "VP": vp
        }

        self._parametros= {
            "PAIS": "Descripción del país para el que se realiza el cálculo.",
            "NORMATIVA": "UNI-EN 1991-1-4:2018 — Eurocódigo 1 | AN/UNI-EN 1991-1-4 — Anejo Nacional Italiano",
            "DENSIDAD": "Densidad del aire en kg/m³",
            "RETORNO": "Periodo de retorno en años",
            "CDIR": "Factor de dirección",
            "CSEASON": "Factor de estación",
            "CTOPO": "Factor topográfico",
            "ALTURA": "Altura de instalación en metros", 
            "COSTA": "Distancia a la costa en metros",
            "ALTITUD": "Altitud en metros",
            "ZONA": "Zona de viento según EN 1991-1-4",
            "CLASE_RUGOSIDAD": "Clase de rugosidad del terreno",
            "VB0*": "Velocidad básica fundamental según tabla",
            "VB0": "Velocidad básica fundamental ajustada a la altitud",
            "A0": "Factor de corrección para la velocidad básica fundamental",
            "KA": "Factor de corrección para la velocidad básica fundamental",
            "VB50": "Velocidad básica para periodo de retorno 50 años [m/s]",
            "QB50": "Presión básica para periodo de retorno 50 años [N/m²]",
            "N": "Exponente del modelo de velocidad",
            "K": "Factor de corrección para el exponente del modelo de velocidad",
            "CPROB": "Factor de probabilidad asociado al periodo de retorno",
            "VB": f"Velocidad básica ajustada al periodo de retorno [m/s]",
            "CATEGORIA_EXPOSICION": "Categoría de exposición del terreno",
            "Z0": "Longitud de rugosidad del terreno [m]",
            "ZMIN": "Altura mínima [m]",
            "KR": "Factor de terreno",
            "CR": "Factor de exposición",
            "VM": "Velocidad media en m/s",
            "K1": "Factor de turbulencia",
            "DESVIACION_TURBULENTA": "Desviación estándar de la turbulencia en m/s",
            "IV": "Intensidad de turbulencia en %",
            "QB": "Presión básica ajustada al periodo de retorno en N/m²",
            "QP": "Presión dinámica ajustada al periodo de retorno en N/m²",
            "CE": "Coeficiente de exposición",
            "VP": "Velocidad pico ajustada al periodo de retorno en km/h",
        }

        self.calculo_realizado = True

    def tabla(self): 
        """
        Devuelve un DataFrame con los resultados estructurados en bloques, con encabezados intercalados para mostrar en Streamlit.
        """

        # Asegurar que el calculo està actualizado
        self._verificar_calculado()

        # Getter seguro: no lanza excepción
        def g(clave, dec=5):
            try:
                valor = self.obtener(clave)
                if isinstance(valor, (int, float)):
                    return f"{valor:.{dec}f}"
                return valor
            except KeyError:
                return "-"

        filas = [] 

        # ------- Configuracion -------------------------------------------------------
        filas.append(("CONFIGURACIÓN GENERAL", "", ""))
        filas.append(("País:", "Italia", ""))
        filas.append(("Normativa:", "UNI EN 1991-1-4 + Anejo Nacional Italiano", ""))
        filas.append(("Densidad del aire [ρ]:", g("DENSIDAD",3), "kg/m³"))
        filas.append(("Periodo de retorno [T]:", g("RETORNO",0), "años"))
        filas.append(("", "", ""))
        # ------- Características de la instalación ------------------------------------
        filas.append(("CARACTERÍSTICAS DE LA INSTALACIÓN", "", ""))
        filas.append(("Zona de viento:", g("ZONA"), ""))
        filas.append(("Clase de rugosidad:", g("CLASE_RUGOSIDAD"), ""))
        filas.append(("Altura de instalación:", g("ALTURA",2), "m"))
        filas.append(("Distancia a la costa:", g("COSTA",2), "m"))
        filas.append(("Altitud:", g("ALTITUD",2), "m"))
        filas.append(("", "", ""))
        # ------- Resultados principales -----------------------------------------------
        filas.append(("RESULTADOS PRINCIPALES", "", ""))
        filas.append(("Velocidad máxima del viento [vmax]:", g("VP",2), "km/h"))
        filas.append(("Presión dinámica asociada [qp]:", g("QP",2), "N/m²"))
        filas.append(("", "", ""))
        # ------- Cálculos intermedios y coeficientes empleados ------------------------
        filas.append(("CÁLCULOS INTERMEDIOS Y COEFICIENTES EMPLEADOS", "", ""))
        filas.append(("Coeficiente de dirección [cdir]", g("CDIR",2), ""))
        filas.append(("Coeficiente estacional [cseason]", g("CSEASON",2), ""))
        filas.append(("Coeficiente topográfico [co]", g("CTOPO",2), ""))
        filas.append(("Velocidad básica fundamental referencial [vb,0*]", g("VB0*",2), "m/s"))
        filas.append(("Velocidad básica fundamental ajustada [vb,0]", g("VB0",2), "m/s"))
        filas.append(("Velocidad básica [vb]", g("VB",2), "m/s"))
        filas.append(("Factor de retorno  [cprob]", g("CPROB",2), ""))
        filas.append(("Exponente de la fórmula de probabilidad [n]", g("N"), ""))
        filas.append(("Factor de forma de la fórmula de probabilidad [K]", g("K",), ""))
        filas.append((f"Velocidad básica ajustada ({g("RETORNO",0)} años) [vb]", g("VB",2), "m/s"))
        filas.append(("Categoria de exposición ", g("CATEGORIA_EXPOSICION",2), ""))
        filas.append(("Longitud de rugosidad [z0]", g("Z0",2), "m"))
        filas.append(("Altura mínima [zmin]", g("ZMIN",2), "m"))
        filas.append(("Factor de terreno [Kr]", g("KR"), ""))
        filas.append(("Factor de rugosidad [cr(z)]", g("CR"), ""))
        filas.append(("Velocidad media [vm(z)]", g("VM",2), ""))
        filas.append(("Factor de turbulencia [K1]", g("K1",2), ""))
        filas.append(("Desviacion típica de la turbulencia [σv]", g("DESVIACION_TURBULENTA",2), "m/s"))
        filas.append(("Intensida de turbulencia [Iv(z)]", g("IV",2) , "%"))
        filas.append((f"Presión básica ajustada ({g("RETORNO",0)} años) [qb]", g("QB",2), "N/m²"))
        filas.append(("Coeficiente de exposicion calculado [ce]", g("CE",2) , ""))

        df = pd.DataFrame(filas, columns = ["","",""])
        return df
    
    def normativa(self):
        return "UNI-EN 1991-1-4:2018 + AN/UNI-EN 1991-1-4 + UNI-EN 1990"

    def consultar_zonas(self):
        print("ZONAS DE VIENTO:")
        for llave, valor in self._ZONAS_VIENTO.items():
            print(f"{llave} : {valor} m/s")

    def consultar_parametros(self):
        if self.calculo_realizado:
            print("PARÁMETROS DISPONIBLES TRAS EL CÁLCULO:")
            for llave, valor in self._parametros.items():
                print(f"{llave} : {valor} ")
        else:
            raise ValueError("El cálculo no se ha realizado aún. Por favor, ejecute el método calcular() antes de consultar los parámetros disponibles.")

    