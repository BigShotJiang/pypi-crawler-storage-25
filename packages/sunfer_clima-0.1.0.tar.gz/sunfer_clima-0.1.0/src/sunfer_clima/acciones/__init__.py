"""
sunfer_clima.acciones
=====================

Subpaquete responsable de la definición e implementación de las acciones
climáticas sobre estructuras según los Eurocódigos.

Este módulo constituye el núcleo de cálculo de la librería, proporcionando
una arquitectura común basada en clases abstractas y extensiones específicas
por tipo de acción (viento, nieve) y normativa nacional.

-------------------------------------------------------------------------------

Descripción General
-------------------

El subpaquete `acciones` implementa distintos modelos de acciones climáticas
siguiendo el Eurocódigo 1 y otras normativas disponibles:

    • EN 1991-1-4 → Acciones de viento
    • CTE DB SE AE → España-Viento
    • NTC2018 → Italia-Viento

    • EN 1991-1-3 → Acciones de nieve
    • CTE DB SE AE → España-Nieve
    • NTC2018 → Italia-Nieve
    

Cada acción se modela mediante clases que:

    • Encapsulan la lógica de cálculo normativa
    • Gestionan parámetros de entrada
    • Generan resultados estructurados y trazables

-------------------------------------------------------------------------------

Estructura del Subpaquete
------------------------

    sunfer_clima.acciones.comunes
        Define la clase base abstracta:

            AccionClimatica

        Esta clase establece la interfaz común y la lógica compartida para
        todas las acciones climáticas.

    sunfer_clima.acciones.viento
        Implementaciones del cálculo de viento según Eurocódigo y otras normativas.

        Incluye:
            • Modelos base
            • Adaptaciones por país (ANEJOS NACIONALES)
            • Cálculo de coeficientes aerodinámicos

    sunfer_clima.acciones.nieve
        Implementaciones del cálculo de nieve según Eurocódigo.

        Incluye:
            • Modelos basados en tablas normativas
            • Interpolaciones según altitud
            • Adaptaciones nacionales

-------------------------------------------------------------------------------

Clase Base: AccionClimatica
---------------------------

La clase `AccionClimatica` define el contrato que deben cumplir todas las
acciones climáticas.

Métodos abstractos (obligatorios):

    calcular() -> None
        Ejecuta el cálculo completo y almacena los resultados.

    tabla() -> pandas.DataFrame
        Devuelve los resultados en formato estructurado.

    normativa() -> str
        Retorna la normativa aplicada.

Funcionalidades comunes implementadas:

    • Gestión interna de resultados:
        _datos: dict
            Almacena resultados calculados

        _parametros: dict
            Describe cada resultado disponible

    • Control de estado:
        calculo_realizado: bool
            Indica si el cálculo ha sido ejecutado

    • Métodos auxiliares:
        _invalidar_calculo()
        _verificar_calculado()

    • API pública común:

        obtener(clave: str) -> Any
            Acceso seguro a resultados

        parametros() -> dict
            Devuelve metadatos de resultados

        ver_parametros() -> None
            Imprime los parámetros disponibles

-------------------------------------------------------------------------------

Acciones Implementadas
----------------------

Viento:

    Modelos basados en EN 1991-1-4 que incluyen:

        • Cálculo de velocidad básica
        • Factores de exposición
        • Intensidad de turbulencia
        • Presión dinámica del viento

    Soporta diferentes normativas nacionales (ej: España, CTE, etc.)

Nieve:

    Modelos basados en EN 1991-1-3 que incluyen:

        • Cargas de nieve en función de altitud
        • Interpolación entre valores tabulados
        • Factores de probabilidad
        • Ajustes por periodo de retorno

-------------------------------------------------------------------------------

Flujo de Uso
------------

Todas las acciones siguen el mismo patrón de uso:

```python
accion = ClaseAccion(...)

accion.calcular()

valor = accion.obtener("CLAVE")
tabla = accion.tabla()
"""