

# EJEMPLOS DE VIENTO Y NIEVE SEGÚN CTE DB-SE-AE 

# Importar las clases de acciones climáticas para su uso en el ejemplo
from sunfer_clima.acciones.viento.es import VientoEurocodeES
from sunfer_clima.acciones.nieve.es import NieveEurocodeES


# pd.set_option('display.max_rows', None)
# pd.set_option('display.max_columns', None)


# ----------------------------------------------------------------------------------------------------------------------------------------------------------
# EJEMPLO 1: UNE EN 1991-1-4 -> CÁLCULO DE VIENTO 
# ----------------------------------------------------------------------------------------------------------------------------------------------------------
# titulo = " Cálculo de acción de viento según Eurocódigo EN 1991-1-4 y Anejo NAcional español "
# print("\n" + titulo.upper())
# print(" -" * len(titulo) + "\n")

# # Datos de entrada para el cálculo
# zona_viento = "A"  # Zona de viento (A, B, C)
# altura_instalacion = 5  # Altura de instalación en metros
# categoria_terreno = "IV"  #Categoria de terreno (I, II, III, IV)
# # Crear instancia de la clase VientoCTE con los datos de entrada
# v = VientoEurocodeES(zona_viento, altura_instalacion, categoria_terreno)
# # Realizar el cálculo
# v.calcular()
# #creas tabla para visualizar resultados
# tabla_viento = v.tabla()

# #Formato de salida
# print( "Datos de entrada:")
# print( f"  Zona de viento: {zona_viento}")
# print( f"  Altura de instalación: {altura_instalacion} m")
# print( f"  Categoria de terreno: {categoria_terreno}")

# print("\nTabla de resultados de viento según el EUROCODIGO:\n")
# print(tabla_viento)
# print("")


# v.consultar_zonas()
# print()
# v.consultar_terrenos()


# ----------------------------------------------------------------------------------------------------------------------------------------------------------
# EJEMPLO 2: UNE EN 1991-1-4 -> CREACION DE TABLA DE VELOCIDADES MÁXIMAS DE VIENTO PARA DISTINTOS CASOS
# ----------------------------------------------------------------------------------------------------------------------------------------------------------
# titulo = " Cálculo de acción de viento según Eurocódigo EN 1991-1-4 y Anejo NAcional español para distintos casos"
# print("\n" + titulo.upper())
# print(" -" * len(titulo) + "\n")

# # Datos de entrada para el cálculo
# zonas = ["A", "B", "C"]  # Zonas de viento (A, B, C)
# alturas = [5, 12, 25]  # Alturas de instalación en metros
# categorias_terreno = ["0", "I", "II", "III", "IV"]  # Categorías de terreno (I, II, III, IV)

# # Crear una lista para almacenar los resultados
# resultados = []
# # Realizar el cálculo para cada combinación de datos de entrada
# for zona in zonas:
#     for altura in alturas:
#         for categoria in categorias_terreno:
#             v = VientoEurocodeES(zona, altura, categoria)
#             v.calcular()
#             resultados.append({
#                 "Zona de viento": zona,
#                 "Altura de instalación (m)": altura,
#                 "Categoría de terreno": categoria,
#                 "Velocidad máxima de viento (m/s)": round(v.obtener("VP"), 2)
#             })
# # Crear un DataFrame para visualizar los resultados
# import pandas as pd
# tabla_resultados = pd.DataFrame(resultados)
# # Formato de salida
# print("Tabla de resultados de viento según el EUROCODIGO para distintos casos:\n")
# print(tabla_resultados)
# print("")


# ----------------------------------------------------------------------------------------------------------------------------------------------------------
# EJEMPLO 3: UNE EN 1991-1-3 -> CÁLCULO DE NIEVE
# ----------------------------------------------------------------------------------------------------------------------------------------------------------
titulo = " Cálculo de acción de nieve según Eurocódigo EN 1991-1-3 y Anejo NAcional español "
print("\n" + titulo.upper())
print(" -" * len(titulo) + "\n")

# Datos de entrada para el cálculo
zona_nieve = 3  # Zona de nieve (1 a 7)
altitud = 750  # Altitud en metros
# Crear instancia de la clase NieveEurocodeES con los datos de entrada
n = NieveEurocodeES(zona_nieve, altitud)
# Realizar el cálculo
n.calcular()
#creas tabla para visualizar resultados
tabla_nieve = n.tabla()

#Formato de salida
print( "Datos de entrada:")
print( f"  Zona de nieve: {zona_nieve}")
print( f"  Altitud: {altitud} m")

print("\nTabla de resultados de nieve según el EUROCODIGO:\n")
print(tabla_nieve)
print("")


# ----------------------------------------------------------------------------------------------------------------------------------------------------------
# EJEMPLO 4: UNE EN 1991-1-3 -> TABLA DE NIEVE PARA DISTINTOS CASOS
# ----------------------------------------------------------------------------------------------------------------------------------------------------------
import pandas as pd
titulo = " EJEMPLO 4: Cálculo de acción de nieve según Eurocódigo EN 1991-1-3 y Anejo NAcional español para distintos casos "
print("\n" + titulo.upper())
print(" -" * len(titulo) + "\n")

# Datos de entrada para el cálculo
zonas_nieve = [1, 2, 3, 4, 5, 6, 7]  # Zonas de nieve (1 a 7)
altitudes = [10, 250, 669]
# Crear una lista para almacenar los resultados
resultados_nieve = []
# Realizar el cálculo para cada combinación de datos de entrada
for zona in zonas_nieve:
    for altitud in altitudes:
        n = NieveEurocodeES(zona, altitud)
        n.calcular()
        resultados_nieve.append({
            "Zona de nieve": zona,
            "Altitud (m)": altitud,
            "Carga de nieve en cubierta (kN/m²)": round(n.obtener("Skn"), 2)
        })
# Crear un DataFrame para visualizar los resultados
tabla_resultados_nieve = pd.DataFrame(resultados_nieve)
# Formato de salida
print("Tabla de resultados de nieve según el EUROCODIGO para distintos casos:\n")
print(tabla_resultados_nieve)
print("")

