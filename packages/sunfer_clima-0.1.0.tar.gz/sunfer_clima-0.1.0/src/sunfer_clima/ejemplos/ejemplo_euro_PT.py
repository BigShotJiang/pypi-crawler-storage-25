

# EJEMPLOS DE VIENTO Y NIEVE SEGÚN CTE DB-SE-AE 

# Importar las clases de acciones climáticas para su uso en el ejemplo
from sunfer_clima.acciones.viento.pt import VientoEurocodePT
from sunfer_clima.acciones.nieve.pt import NieveEurocodePT
import numpy as np
import matplotlib.pyplot as plt


# pd.set_option('display.max_rows', None)
# pd.set_option('display.max_columns', None)


#----------------------------------------------------------------------------------------------------------------------------------------------------------
# EJEMPLO 1: UNE EN 1991-1-4 -> CÁLCULO DE VIENTO 
# ----------------------------------------------------------------------------------------------------------------------------------------------------------
titulo = " EJEMPLO 1: Cálculo de acción de viento según Eurocódigo NP 1991-1-4 y Anejo NAcional portugués "
print("\n" + titulo.upper())
print(" -" * len(titulo) + "\n")

# Datos de entrada para el cálculo
categoria_terreno = "III"  #Categoria de terreno (I, II, III, IV)
altura_instalacion = 25  # Altura de instalación en metros
distancia_costa= 2800  # Distancia a la costa en metros
altitud = 650  # Altitud sobre el nivel del mar en metros
# Crear instancia de la clase VientoCTE con los datos de entrada
v = VientoEurocodePT(altura_instalacion, categoria_terreno, distancia_costa, altitud)
# Realizar el cálculo
v.calcular()
#creas tabla para visualizar resultados
tabla_viento = v.tabla()

#Formato de salida
print( "Datos de entrada:")
print( f"  Categoría de terreno : {v.categoria_terreno}")
print( f"  Altura de instalación: {altura_instalacion} m")
print( f"  Distancia a la costa: {distancia_costa} m")
print( f"  Altitud: {altitud} m")

print("\nTabla de resultados de viento según el EUROCODIGO:\n")
print(tabla_viento)
print("")


v.consultar_zonas()
print()
v.consultar_terrenos()


# ----------------------------------------------------------------------------------------------------------------------------------------------------------
# EJEMPLO 2: NP EN 1991-1-4 -> GRAFICO DE VELOCIDAD DE VIENTO EN FUNCIÓN DE LA ALTURA PARA DISTINTOS TERRENOS
# ----------------------------------------------------------------------------------------------------------------------------------------------------------
print("\n" + "-" * 80 + "\n")
titulo = "EJEMPLO 2: Gráfico de la velocidad máxima de viento según Eurocódigo NP 1991-1-4 y Anejo NAcional portugués para distintos terrenos" 
print("\n" + titulo.upper())
print("-" * len(titulo) + "\n")

#Parámetros
terrenos = ["I", "II", "III", "IV"]
alturas = np.arange(0, 26, 1)  # alturas de 0 a 25 m
distancia_costa = 6500  # Distancia a la costa en metros
altitud = 300  # Altitud sobre el nivel del mar en metros

# Diccionario para guardar velocidades por terreno
velocidades = {terreno: [] for terreno in terrenos}
ultima_instancia = None
# Calcular velocidades
for terreno in terrenos:
    # print(f"Calculando terreno {terreno}...")
    for altura in alturas:
        viento = VientoEurocodePT( altura_instalacion=altura, categoria_terreno=terreno, distancia_costa=distancia_costa, altitud=altitud)
        viento.calcular()
        velocidades[terreno].append(viento.obtener("VP"))
        ultima_instancia = viento  # Guardar la última instancia para mostrar resultados al final

# Determinar el rango de velocidades para los ticks
vel_min = min(min(v) for v in velocidades.values())
vel_max = max(max(v) for v in velocidades.values())

# Crear gráfico rotado: velocidad en X, altura en Y
plt.figure(figsize=(10, 6))
colores = ["tab:blue", "tab:orange", "tab:green", "tab:red", "tab:purple"]

for terreno, color in zip(terrenos, colores):
    plt.plot(
        velocidades[terreno],  # eje X = velocidad
        alturas,               # eje Y = altura
        marker='o',
        linestyle='-',
        color=color,
        label=f"Grado de aspereza {terreno}"
    )

# Configuración del gráfico
plt.title(f"Velocidad máxima del viento VP vs Altura\nZona: {ultima_instancia.obtener('zona')} - Distancia a costa: {distancia_costa} m - Altitud: {altitud} m")
plt.xlabel("Velocidad máxima del viento VP (km/h)")
plt.ylabel("Altura de instalación (m)")
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend(title="Terreno")
plt.tight_layout()

# Poner ticks cada 5 km/h en eje X
plt.xticks(np.arange(int(vel_min // 5) * 5, int(vel_max // 5 + 2) * 5, 5))
plt.yticks(np.arange(0, 110, 5))  # ticks cada 5 m en eje Y

plt.show()





# # ----------------------------------------------------------------------------------------------------------------------------------------------------------
# # EJEMPLO 3: UNE EN 1991-1-3 -> CÁLCULO DE NIEVE
# # ----------------------------------------------------------------------------------------------------------------------------------------------------------
titulo = "EJEMPLO 3: Cálculo de acción de nieve según Eurocódigo NP 1991-1-3 y Anejo NAcional portugués "
print("\n" + titulo.upper())
print(" -" * len(titulo) + "\n")

# Datos de entrada para el cálculo
zona_nieve = 3  # Zona de nieve (1 a 7)
altitud = 750  # Altitud en metros
# Crear instancia de la clase NieveEurocodePT con los datos de entrada
n = NieveEurocodePT(zona_nieve, altitud)
# Realizar el cálculo
n.calcular()
#creas tabla para visualizar resultados
tabla_nieve = n.tabla()

#Formato de salida
print( "Datos de entrada:")
print( f"  Zona de nieve: {zona_nieve}")
print( f"  Altitud: {altitud} m")

print("\nTabla de resultados de nieve según el EUROCODIGO:\n")
print(tabla_nieve)
print("")


# # ----------------------------------------------------------------------------------------------------------------------------------------------------------
# # EJEMPLO 4: UNE EN 1991-1-3 -> TABLA DE NIEVE PARA DISTINTOS CASOS
# # ----------------------------------------------------------------------------------------------------------------------------------------------------------
# import pandas as pd
# titulo = " EJEMPLO 4: Cálculo de acción de nieve según Eurocódigo EN 1991-1-3 y Anejo NAcional español para distintos casos "
# print("\n" + titulo.upper())
# print(" -" * len(titulo) + "\n")

# # Datos de entrada para el cálculo
# zonas_nieve = [1, 2, 3, 4, 5, 6, 7]  # Zonas de nieve (1 a 7)
# altitudes = [10, 250, 669]
# # Crear una lista para almacenar los resultados
# resultados_nieve = []
# # Realizar el cálculo para cada combinación de datos de entrada
# for zona in zonas_nieve:
#     for altitud in altitudes:
#         n = NieveEurocodeES(zona, altitud)
#         n.calcular()
#         resultados_nieve.append({
#             "Zona de nieve": zona,
#             "Altitud (m)": altitud,
#             "Carga de nieve en cubierta (kN/m²)": round(n.obtener("Skn"), 2)
#         })
# # Crear un DataFrame para visualizar los resultados
# tabla_resultados_nieve = pd.DataFrame(resultados_nieve)
# # Formato de salida
# print("Tabla de resultados de nieve según el EUROCODIGO para distintos casos:\n")
# print(tabla_resultados_nieve)
# print("")

