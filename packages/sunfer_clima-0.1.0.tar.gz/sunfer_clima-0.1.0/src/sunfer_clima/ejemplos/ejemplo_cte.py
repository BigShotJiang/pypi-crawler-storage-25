# Importar las clases de acciones climáticas para su uso en el ejemplo

from sunfer_clima.acciones.viento.cte import VientoCTE
from sunfer_clima.acciones.nieve.cte import NieveCTE
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
# from sunfer_clima.acciones.viento.coeficientes_aerodinamicos import cp_cubierta_plana, cp_marquesina

# pd.set_option('display.max_rows', None)
# pd.set_option('display.max_columns', None)


# # ----------------------------------------------------------------------------------------------------------------------------------------------------------
# # EJEMPLO 1: VIENTO SEGUN CTE DB-SE-AE -> CALCULO DE VIENTO 
# # ----------------------------------------------------------------------------------------------------------------------------------------------------------
titulo = "Ejemplo 1: Cálculo de acción de viento según Eurocódigo EN 1991-1-4 y Anejo NAcional español ---------------------"
print("\n" + titulo.upper() + "\n")


#Datos de entrada para el ejemplo
zona = "B"  # Zona de viento según CTE (A, B, C)
altura = 5  # Altura de instalación en metros
grado_aspereza = "I"  # Grado de aspereza del terreno (I, II, III, IV, V)


v = VientoCTE(zona_viento=zona, altura_instalacion=altura, grado_aspereza=grado_aspereza)
v.calcular()
tabla_viento = v.tabla()
print(tabla_viento)


# # # ----------------------------------------------------------------------------------------------------------------------------------------------------------
# # # EJEMPLO 2: CTE ESPAÑA (VIENTO) -> CREACION DE TABLAS PARA VISUALIZAR VIENTO segun altura instalacion, zona y grado aspereza
# # # -----------------------------------------------------------------------------------------------------------------------------------------------------------
titulo = "Ejemplo 2: Tabla segun zona, altura y grado de aspereza    ---------------------"
zonas = ["A", "B", "C"]
alturas = [0, 3, 5, 10, 15, 20]
terrenos = [ "I", "II", "III", "IV", "V" ]

# Creacion de bucle para generar las tablas de resultados de viento  
filas_viento = []
for zona in zonas:
    for altura in alturas:
        for terreno in terrenos:
            viento = VientoCTE(zona_viento=zona, altura_instalacion=altura, grado_aspereza=terreno)
            viento.calcular()
            filas_viento.append({
                "Zona": zona,
                "Terreno": terreno,
                "Altura (m)": altura,
                "VP (km/h)": round(viento.obtener("VP"), 2),
                "QP (N/m²)": round(viento.obtener("QP"), 2),
            })

tabla_viento_CTE = pd.DataFrame(filas_viento)
print("\nTabla de VIENTO:\n")
print(tabla_viento_CTE)


# # # ----------------------------------------------------------------------------------------------------------------------------------------------------------
# # # EJEMPLO 3: CTE ESPAÑA (VIENTO) -> COMPARACION DE RESULTADOS SEGUN GRADO DE ASPEREZA
# # # -----------------------------------------------------------------------------------------------------------------------------------------------------------
titulo = "\nEjemplo 3: Comparación de resultados según grado de aspereza    ---------------------\n"
zona = "A"
altura = 15
terrenos = [ "I", "II", "III", "IV", "V" ]

# Creacion de bucle para generar las tablas de resultados de viento  
velocidades_viento = []

for terreno in terrenos:
    viento = VientoCTE(zona_viento=zona, altura_instalacion=altura, grado_aspereza=terreno)
    viento.calcular()
    velocidades_viento.append(round(viento.obtener("VP"), 2))

tabla_comparacion_aspereza = pd.DataFrame({
    "Grado de aspereza": terrenos,
    "Velocidad del viento VP (km/h)": velocidades_viento
})
print(titulo)
print(tabla_comparacion_aspereza)

# # # ----------------------------------------------------------------------------------------------------------------------------------------------------------
# # # EJEMPLO 4: CTE ESPAÑA (VIENTO) -> GRAFICO DE VELOCIDAD DE VIENTO SEGÚN GRADO DE ASPEREZA
# # # -----------------------------------------------------------------------------------------------------------------------------------------------------------

#Parámetros
zona = "B"
terrenos = ["I", "II", "III", "IV", "V"]
alturas = np.arange(5, 105, 5)  # alturas de 5 a 100 m

# Diccionario para guardar velocidades por terreno
velocidades = {terreno: [] for terreno in terrenos}

# Calcular velocidades
for terreno in terrenos:
    print(f"Calculando terreno {terreno}...")
    for altura in alturas:
        viento = VientoCTE(zona_viento=zona, altura_instalacion=altura, grado_aspereza=terreno)
        viento.calcular()
        velocidades[terreno].append(viento.obtener("VP"))

# Determinar el rango de velocidades para los ticks
vel_min = min(min(v) for v in velocidades.values())
vel_max = max(max(v) for v in velocidades.values())

# Crear gráfico rotado: velocidad en X, altura en Y
plt.figure(figsize=(10, 6))
colores = ["tab:blue", "tab:orange", "tab:green", "tab:red", "tab:purple"]

for terreno, color in zip(terrenos, colores):
    plt.plot(
        velocidades[terreno],  # eje X = velocidad
        alturas,               # eje Y = altura
        marker='o',
        linestyle='-',
        color=color,
        label=f"Grado de aspereza {terreno}"
    )

# Configuración del gráfico
plt.title(f"Velocidad máxima del viento VP vs Altura\nZona: {zona}")
plt.xlabel("Velocidad máxima del viento VP (km/h)")
plt.ylabel("Altura de instalación (m)")
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend(title="Terreno")
plt.tight_layout()

# Poner ticks cada 5 km/h en eje X
plt.xticks(np.arange(int(vel_min // 5) * 5, int(vel_max // 5 + 2) * 5, 5))
plt.yticks(np.arange(0, 110, 5))  # ticks cada 5 m en eje Y

plt.show()


# NIEVE ---------------------------------------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------------------------------------------
# EJEMPLO 5: EUROCÓDIGO ESPAÑA NIEVE -> CTE ESPAÑA (NIEVE) -> calculo de la nieve segun CTE
# ---------------------------------------------------------------------------------------------------------------------------------------------------------
titulo = "\nEjemplo 5: Tabla de nieve según zona y altura de instalación    ---------------------\n"
zona = 3
altitud = 468 
n = NieveCTE(zona_nieve=zona, altitud=altitud)
n.calcular()
tabla_nieve_CTE = n.tabla()
print(titulo)
print("Tabla de NIEVE:")
print(tabla_nieve_CTE)


# ----------------------------------------------------------------------------------------------------------------------------------------------------------
# EJEMPLO 5: CTE -> CREACION DE TABLAS PARA VISUALIZAR VIENTO Y COMPROBAR RESULTADOS
# ----------------------------------------------------------------------------------------------------------------------------------------------------------
titulo = "Ejemplo 5: Comprobación mediante comparacion con excel CTE viento   ---------------------"
zonas = ["A", "B", "C"]
alturas = [0, 3, 5, 10, 15, 20]
terrenos = ["I", "II", "III", "IV", "V"]

# Creacion de bucle para generar las tablas de resultados de viento  
filas_viento = []
for zona in zonas:
    for altura in alturas:
        for terreno in terrenos:
            viento = VientoCTE(zona_viento=zona, altura_instalacion=altura, grado_aspereza=terreno)
            viento.periodo_retorno = 25  # Establecer periodo de retorno para obtener valores de VP y QP correspondientes
            viento.calcular()
            filas_viento.append({
                "Zona": zona,
                "Terreno": terreno,
                "Altura (m)": altura,
                "QB (N/m²)": round(viento.obtener("QB"), 2),
                "VP (km/h)": round(viento.obtener("VP"), 2),
                "QP (N/m²)": round(viento.obtener("QP"), 2),
            })

tabla = pd.DataFrame(filas_viento)
print("\nTabla de VIENTO para comprobación:\n")
print(tabla)


# # --------------------------------------------------------------------------------------------
# # EJEMPLO 6: CTE DB-SE-AE
# # --------------------------------------------------------------------------------------------

titulo = "Ejemplo 6: Cálculo de acción de viento según CTE DB-SE-AE ---------------------------------------------------------------------------------"
print("\n" + titulo.upper() + "\n")

#Crear instancia CTE: zona C, altura 20 m, aspereza IV
viento_cte = VientoCTE(zona_viento="B", altura_instalacion=0.1, grado_aspereza="I")
#Ejecutar cálculo
viento_cte.calcular()
viento_cte.consultar_zonas()  # Mostrar zonas disponibles para verificación
print("")

# # Obtener algunos valores
print("K:", viento_cte.obtener("K"), "")
print("L:", viento_cte.obtener("L"), "")
print("Z:", viento_cte.obtener("Z"), "")
print("z:", viento_cte.obtener("ALTURA"), "")
print("F:", viento_cte.obtener("F"), "")
print("Ce:", viento_cte.obtener("CE"), "")

# Generar tabla
tabla_cte = viento_cte.tabla()
print(tabla_cte)  # primeras filas para visualización


# # --------------------------------------------------------------------------------------------
# # EJEMPLO 7: COMPARACIÓN ENTRE NORMATIVAS PARA DISTINTAS ALTURAS Y DISTINTO TERRENO
# # --------------------------------------------------------------------------------------------
from sunfer_clima.acciones.viento.es import VientoEurocodeES
print("\nEJEMPLO 7: Comparación CTE vs Eurocódigo (incluye coeficiente de exposición)\n")

zona = "B"
alturas = [6, 17, 100]

# Terrenos correlativos por posición
terrenos_euro = ["0", "I", "II", "III", "IV"]
terrenos_cte = ["I", "II", "III", "IV", "V"]

filas = []

for terreno_ec, terreno_cte in zip(terrenos_euro, terrenos_cte):
    for altura in alturas:

        # --- Eurocódigo ---
        viento_ec = VientoEurocodeES(
            zona_viento=zona,
            altura_instalacion=altura,
            categoria_terreno=terreno_ec
        )
        viento_ec.calcular()

        vp_ec = viento_ec.obtener("VP")
        qp_ec = viento_ec.obtener("QP")
        ce_ec = viento_ec.obtener("CE")
        qb_ec = viento_ec.obtener("QB")
        

        # --- CTE ---
        viento_cte = VientoCTE(
            zona_viento=zona,
            altura_instalacion=altura,
            grado_aspereza=terreno_cte
        )
        viento_cte.calcular()

        vp_cte = viento_cte.obtener("VP")
        qp_cte = viento_cte.obtener("QP")
        ce_cte = viento_cte.obtener("CE")
        qb_cte = viento_cte.obtener("QB")

        filas.append({
            "Zona": zona,
            "Terreno EC": terreno_ec,
            "Terreno CTE": terreno_cte,
            "Altura (m)": altura,
            "CE Eurocódigo": round(ce_ec, 3),
            "CE CTE": round(ce_cte, 3),
            "Δ CE (%)": round((ce_ec - ce_cte) / ce_cte * 100, 2) if ce_cte != 0 else 0,
            "VP Eurocódigo (km/h)": round(vp_ec, 2),
            "VP CTE (km/h)": round(vp_cte, 2),
            "Δ VP (%)": round((vp_ec - vp_cte) / vp_cte * 100, 2) if vp_cte != 0 else 0,
            "QB Eurocódigo (N/m²)": round(qb_ec, 2),
            "QB CTE (N/m²)": round(qb_cte, 2),
            "Δ QB (%)": round((qb_ec - qb_cte) / qb_cte * 100, 2) if qb_cte != 0 else 0
        })

df_comparacion = pd.DataFrame(filas)
print(df_comparacion)
