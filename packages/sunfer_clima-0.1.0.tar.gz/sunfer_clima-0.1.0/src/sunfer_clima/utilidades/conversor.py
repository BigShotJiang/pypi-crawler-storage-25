import math


def convertir(value, unit_in, unit_out, rho=1.25):
    """
    Convierte automáticamente entre:
    - velocidad ↔ presión dinámica del viento
    - velocidad ↔ velocidad
    - presión ↔ presión

    Usa siempre como base:
    - velocidad en m/s
    - presión en Pa (N/m²)

    Admite unidades en mayúsculas y minúsculas.

    rho: densidad del aire (kg/m3), por defecto 1.25
    """

    # -------------------------------
    # Factores de conversión a Pa
    # -------------------------------
    PRESION = {
        "pa": 1.0,
        "n/m2": 1.0,

        "n/mm2": 1e6,
        "n/cm2": 1e4,

        "kn/m2": 1e3,
        "kn/cm2": 1e7,
        "kn/mm2": 1e9,

        "kpa": 1e3,
        "mpa": 1e6,

        "kgf/m2": 9.80665,
        "kgf/cm2": 9.80665e4,
        "kgf/mm2": 9.80665e6,

        "ton/m2": 9.80665e3,
        "ton/cm2": 9.80665e7,
        "ton/mm2": 9.80665e9,
    }

    # -------------------------------
    # Factores de conversión a m/s
    # -------------------------------
    VELOCIDAD = {
        "m/s": 1.0,
        "km/h": 1.0 / 3.6,
        "mph": 0.44704,
    }

    # Normalizar unidades
    unit_in = unit_in.strip().lower()
    unit_out = unit_out.strip().lower()

    es_presion_in = unit_in in PRESION
    es_presion_out = unit_out in PRESION

    es_velocidad_in = unit_in in VELOCIDAD
    es_velocidad_out = unit_out in VELOCIDAD

    # -------------------------------------------------
    # 1) Velocidad → Velocidad
    # -------------------------------------------------
    if es_velocidad_in and es_velocidad_out:
        V_mps = value * VELOCIDAD[unit_in]
        result = V_mps / VELOCIDAD[unit_out]
        return result

    # -------------------------------------------------
    # 2) Presión → Presión
    # -------------------------------------------------
    if es_presion_in and es_presion_out:
        q_pa = value * PRESION[unit_in]
        result = q_pa / PRESION[unit_out]
        return result

    # -------------------------------------------------
    # 3) Velocidad → Presión
    # -------------------------------------------------
    if es_velocidad_in and es_presion_out:
        # a) velocidad a m/s
        V_mps = value * VELOCIDAD[unit_in]

        # b) presión dinámica en Pa
        q_pa = 0.5 * rho * V_mps**2

        # c) Pa → unidad de salida
        result = q_pa / PRESION[unit_out]
        return result

    # -------------------------------------------------
    # 4) Presión → Velocidad
    # -------------------------------------------------
    if es_presion_in and es_velocidad_out:
        # a) presión a Pa
        q_pa = value * PRESION[unit_in]

        # b) velocidad en m/s
        V_mps = math.sqrt(2.0 * q_pa / rho)

        # c) m/s → unidad de salida
        result = V_mps / VELOCIDAD[unit_out]
        return result

    # -------------------------------------------------
    # Casos no válidos
    # -------------------------------------------------
    raise ValueError(
        f"Conversión no válida: '{unit_in}' → '{unit_out}'. "
        f"Use solo unidades de presión o velocidad soportadas."
    )


# ========================================================================================================================================
# EJEMPLOS DE USO
# ========================================================================================================================================
if __name__ == "__main__": # pragma: no cover

    # Velocidad → velocidad
    print(f"100 km/h → m/s: {convertir(100, 'km/h', 'm/s'):.3f} m/s")

    # Velocidad → velocidad
    print(f"39,88 m/s → km/h: {convertir(39.88, 'm/s', 'km/h'):.3f} km/h")

    # Velocidad → presion
    print(f"39,88 m/s → N/m2: {convertir(39.88, 'm/s', 'N/m2', rho=1.225):.3f} N/m2")

    # Presion → presion
    print(f"974.129 N/m2 → kg/m2: {convertir(974.129, 'N/m2', 'Kgf/m2', rho=1.225):.3f} Kg/m2")

    # Presion → presion
    print(f"974.129 N/m2 → KN/m2: {convertir(974.129, 'N/m2', 'KN/m2', rho=1.225):.3f} KN/m2")

