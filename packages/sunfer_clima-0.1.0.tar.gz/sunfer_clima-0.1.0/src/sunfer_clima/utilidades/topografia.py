import math


TIPOS_ACCIDENTE_VALIDOS = {
    "colina_barlovento",
    "colina_sotavento",
    "acantilado_barlovento",
    "acantilado_sotavento",
}


def _coeficiente_a_polinomico(p: float) -> float:
    return (
        0.1552 * p**4
        - 0.8575 * p**3
        + 1.8133 * p**2
        - 1.9115 * p
        + 1.0124
    )


def _coeficientes_logaritmicos(p: float) -> tuple[float, float, float]:
    log_p = math.log(p)

    a = (
        -1.3420 * log_p**3
        - 0.8222 * log_p**2
        + 0.4609 * log_p
        - 0.0791
    )
    b = (
        -1.0196 * log_p**3
        - 0.8910 * log_p**2
        + 0.5343 * log_p
        - 0.1156
    )
    c = (
        0.8030 * log_p**3
        + 0.4236 * log_p**2
        - 0.5738 * log_p
        + 0.1606
    )

    return a, b, c


def _calcular_s_barlovento(x_rel: float, p: float) -> float:
    if not (-1.5 <= x_rel <= 0 and 0 <= p <= 2):
        return 0.0

    a = _coeficiente_a_polinomico(p)
    b = 0.3542 * p**2 - 1.0577 * p + 2.6456

    return a * math.exp(b * x_rel)


def _calcular_s_acantilado_sotavento(x_rel2: float, p: float) -> float:
    if not (0 <= x_rel2 <= 3.5 and 0.1 <= p <= 2):
        return 0.0

    a, b, c = _coeficientes_logaritmicos(p)

    # Tramo interpolado
    if 0 <= x_rel2 <= 0.1:
        a0 = _coeficiente_a_polinomico(p)
        log_01 = math.log(0.1)
        s_01 = a * log_01**2 + b * log_01 + c
        return a0 + (s_01 - a0) * (x_rel2 / 0.1)

    # Tramo logarítmico
    log_x = math.log(x_rel2)
    return a * log_x**2 + b * log_x + c


def _calcular_s_colina_sotavento(x_rel3: float, p: float) -> float:
    if not (0 <= x_rel3 <= 2 and 0 <= p <= 2):
        return 0.0

    a = _coeficiente_a_polinomico(p)
    b = -0.3056 * p**2 + 1.0212 * p - 1.7637

    return a * math.exp(b * x_rel3)


def _calcular_factor_final(phi: float, s: float) -> float:
    if 0.05 <= phi < 0.3:
        return 1 + 2 * s * phi

    if phi >= 0.3:
        return 1 + 0.6 * s

    return 1.0


def calcular_co(
    tipo_accidente: str,
    altura_efectiva_accidente: float,
    longitud_pendiente_barlovento: float,
    longitud_pendiente_sotavento: float,
    distancia_horizontal_estructura_cresta: float,
    altura_estructura: float,
) -> float:
    """
    Calcula el coeficiente topográfico c0 según EN 1991-1-4 Anexo A.
    """
    if tipo_accidente not in TIPOS_ACCIDENTE_VALIDOS:
        raise ValueError(f"Tipo de accidente inválido: {tipo_accidente}")

    h = altura_efectiva_accidente
    lu = longitud_pendiente_barlovento or 0.01
    ld = longitud_pendiente_sotavento or 0.01
    x = distancia_horizontal_estructura_cresta
    z = altura_estructura

    phi = h / lu

    if phi < 0.05:
        return 1.0

    le = lu if 0.05 < phi < 0.3 else h / 0.3

    x_rel = x / lu
    x_rel2 = x / le
    x_rel3 = x / ld
    p = z / le

    if tipo_accidente in {"colina_barlovento", "acantilado_barlovento"}:
        s = _calcular_s_barlovento(x_rel, p)

    elif tipo_accidente == "acantilado_sotavento":
        s = _calcular_s_acantilado_sotavento(x_rel2, p)

    else:  # colina_sotavento
        s = _calcular_s_colina_sotavento(x_rel3, p)

    return _calcular_factor_final(phi, s)