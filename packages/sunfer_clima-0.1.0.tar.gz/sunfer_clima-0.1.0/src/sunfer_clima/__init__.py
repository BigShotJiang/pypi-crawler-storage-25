"""

sunfer_clima
============

Paquete principal para el cálculo de acciones climáticas sobre estructuras
según los Eurocódigos incluyendo la implementación de Anejos Nacionales , y
otras normativas de determinados paises (Por el momento CTE (España) y 
NTC2018 (Italia)).

Este paquete constituye el núcleo de la librería y organiza los distintos
módulos necesarios para el cálculo, utilidades y ejemplos de uso.

-------------------------------------------------------------------------------

Descripción General
-------------------------------------------------------------------------------

`sunfer_clima` proporciona una API coherente y extensible para el cálculo de:

    • Acciones de viento (EN 1991-1-4)
    • Acciones de viento (CTE - España)
    • Acciones de viento (NTC-2018 - Italia)

    • Acciones de nieve (EN 1991-1-3)
    • Acciones de nieve (CTE - España)
    • Acciones de nieve (NTC-2018 - Italia)

incluyendo adaptaciones específicas por país mediante Anejos Nacionales: 

    • España
    • Francia
    • Italia
    • Portugal

También incluye métodos para la obtencion de coeficientes aerodinamicos 
tabulados según distintas normativas.

El diseño está orientado a:

    • Reutilización en proyectos de ingeniería estructural
    • Extensibilidad a nuevas normativas o países
    • Separación clara entre modelo base y parámetros nacionales

-------------------------------------------------------------------------------

Estructura del Paquete
-------------------------------------------------------------------------------

El paquete se organiza en los siguientes submódulos:

    sunfer_clima.acciones
        Contiene la lógica principal de cálculo de acciones climáticas.

        • comunes
            Clases base y abstracciones compartidas.
            - AccionClimatica (clase abstracta principal)

        • viento
            Modelos de cálculo de viento según Eurocódigo.
            Incluye implementaciones base y específicas por país:
                - es (España)
                - fr (Francia)
                - it (Italia)
                - pt (Portugal)
                - ntc2018 (Italia NTC)
                - cte (Código Técnico España)
                - coeficientes_aerodinámicos 

        • nieve
            Modelos de cálculo de nieve según Eurocódigo:
                - es (España)
                - cte

    sunfer_clima.utilidades
        Funciones auxiliares reutilizables:
            - conversiones de unidades
            - funciones topográficas

    sunfer_clima.ejemplos
        Ejemplos de uso de la librería para validación y aprendizaje.

-------------------------------------------------------------------------------

Arquitectura
-------------------------------------------------------------------------------

El diseño se basa en una clase abstracta común:

    AccionClimatica

que define la interfaz estándar:

    - calcular()
    - tabla()
    - normativa()
    - obtener(clave)
    - parametros()

Las implementaciones específicas heredan de esta clase y encapsulan:

    • Lógica de cálculo
    • Parámetros normativos
    • Resultados estructurados

-------------------------------------------------------------------------------

Flujo de Uso
------------------------------------------------------------------------------

El uso típico de la librería sigue el patrón:

    1. Instanciar la clase correspondiente
    2. Ejecutar el cálculo
    3. Consultar resultados

Ejemplo:

```python
from sunfer_clima.acciones.viento.es import VientoEurocodeES

viento = VientoEurocodeES(
    zona_viento="B",
    altura_instalacion=10,
    categoria_terreno="II"
)

viento.calcular()

resultado = viento.obtener("VP")
tabla = viento.tabla()

-------------------------------------------------------------------------------

Extensibilidad
------------------------------------------------------------------------------

El paquete permite añadir fácilmente nuevas implementaciones:

• Nuevos países (Anejos Nacionales)
• Nuevos tipos de acciones climáticas

Para ello:

1. Crear una clase que herede de `AccionClimatica`
2. Implementar los métodos requeridos
3. Definir los parámetros normativos correspondientes

Autor: Rafa Crespo
Versión: 1.0

"""