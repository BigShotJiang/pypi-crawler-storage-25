---
created_at: '2025-11-13'
status: enforced
tags:
- dependencies
- technology
- stack
- architecture
name: "project-dependencies"
description: "Project dependencies management"
updated_at: '2025-11-13'
---

## Purpose

This policy establishes standardized technology choices and dependency management practices to
ensure consistent implementation, reduce maintenance complexity, and prevent technology
fragmentation across the MCP server project.

It prevents risks such as incompatible dependencies, excessive external dependencies, and
inconsistent toolchain usage.

## Principles

- **Technology Coherence** : All dependencies must work together seamlessly without conflicts
- **Minimal Dependency Footprint** : Add only essential dependencies that provide clear value
- **Proven Stability** : Prefer mature, well-maintained libraries over experimental alternatives
- **MCP Protocol Alignment** : All core dependencies must support or enhance MCP protocol
  implementation

## Rules

### Core Framework Requirements

- **FastMCP MUST be used** as the primary framework for MCP protocol handling over `stdin/stdout`
- **pydantic MUST be used** for all data validation and settings management
- **Purpose**: Ensures type safety, validation, and consistent data modeling patterns

### Database and ORM Requirements

- **sqlmodel MUST be used** for simple queries and primary data modeling
- **sqlalchemy MUST be used** for complex queries requiring advanced ORM features
- **Purpose** : Provides consistent database abstraction while supporting both simple and advanced
  use cases

### Development and Management Tools

- **typer MUST be used** for CLI interfaces and management scripts
- **watchdog MUST be used** for file system monitoring functionality
- **Purpose**: Standardizes CLI patterns and enables reliable file change detection

### Dependency Addition Process

- **All new dependencies MUST be justified** with clear functional requirements
- **Dependencies MUST be documented** in project specifications with usage rationale
- **Version constraints MUST be specified** to prevent compatibility issues
- **Security implications MUST be evaluated** before adding external dependencies

### Dependency Management Standards

- **Use semantic versioning constraints** to balance stability and updates
- **Pin critical dependencies** to specific versions when stability is paramount
- **Document upgrade paths** for major dependency changes
- **Avoid redundant dependencies** that duplicate existing functionality

## Exceptions

- **Testing dependencies** may use additional specialized libraries with proper justification
- **Development-only dependencies** may deviate from production constraints with documentation
- **Platform-specific dependencies** may be required for certain deployment environments

## References

- [DevOps Policy](./devops.md) - General dependency management guidelines
- [Development Tools Policy](./development-tools.md) - Development toolchain standards
- [ADR-001: In-Memory SQLite Database](../_adrs/001-choose-in-memory-sqlite-database.md) - Database technology decision
