---
created_at: '2025-11-13'
status: enforced
tags:
- resource
- naming
- frontmatter
- database
- schema
- types
- dependencies
name: "resource-base"
description: "Resource management policy"
updated_at: '2025-11-13'
---

## Purpose

This policy establishes comprehensive conventions for all MCP resource types to ensure
consistency, maintainability, and interoperability across the project. It prevents
fragmentation of naming patterns, frontmatter formats, database schemas, types,
dependencies, and assessments that would lead to maintenance overhead and integration
difficulties.

## Principles

- **Consistency**: All resources of the same type follow identical patterns
- **Readability**: Resource identifiers should be self-descriptive and human-readable
- **Interoperability**: Common base schema enables cross-resource operations
- **Maintainability**: Standardized patterns reduce cognitive load and development time
- **Single Responsibility** : Each resource type focuses on one business domain for focused
  evolution
- **Domain-Driven Design** : Resource types reflect distinct domains with specialized models,
  workflows, and validations
- **Independent Evolution** : Changes to one type should not impact others, allowing isolated
  migrations and optimizations
- **Clarity**: Dependencies must be explicit and traceable
- **Simplicity**: Prefer simple referencing over complex relationship modeling
- **Navigability**: Resource relationships should form a coherent, browsable graph
- **Efficiency**: Quick assessment process that doesn't become a bottleneck

## Rules

### File Naming Conventions

- **All multi-word components MUST use kebab-case** (lowercase with hyphens)
- **File names MUST be self-descriptive** and indicate the resource content
- **File extensions MUST be `.md`** for all resource content

#### ADR-Specific Naming

- **ADR sequential numbering MUST use 3-digit zero-padded format** (001, 002, 123)
- **ADR file names combine sequential number with descriptive name** (e.g., `001-choose-database.md`
  )

### Frontmatter Format Requirements

- **All resource files MUST contain YAML frontmatter** for metadata indexing
- **Frontmatter MUST be valid YAML** enclosed in triple dashes (`---`)
- **Frontmatter MUST be parsed using python-frontmatter** for metadata extraction
- **Markdown content MUST be processed using markdown-it-py** for parsing
- **Frontmatter fields MUST follow the base schema** defined below

### Base Frontmatter Schema

All resource types MUST implement these common field categories:

**Identity Fields:**

- `id` (PRIMARY KEY): Pattern `{prefix}_{name}` (project) or `+{prefix}_{name}` (shared),
  auto-generated if missing
- `path` (UNIQUE NOT NULL): File path (absolute), derived from filesystem (SQL only)

**Content Fields:**

- `title` (NOT NULL): Human-readable display name
- `description` (NOT NULL): Brief resource description
- `status` (NOT NULL): Resource lifecycle state, enum values per resource type
- `tags` (JSON array): Classification tags for organization

**Timestamp Fields:**

- `created_at` (NOT NULL, immutable): ISO datetime, auto-set at creation
- `updated_at` (NOT NULL): ISO datetime, auto-updated on changes

### Field Generation Rules

- **ID Generation**: `{prefix}_{name}` (project) or `+{prefix}_{name}` (shared)
  - Generated automatically during resource creation OR indexation
  - Applied when handling via remlezrd for user-created files missing id
- **Timestamp Management**:
  - `created_at`: Immutable timestamp set at resource creation
  - `updated_at`: Automatically updated on any state change or content update

### Database Schema Requirements

- **Each resource type MUST have a dedicated table** (separate tables strategy)
- **All tables MUST implement the base field pattern** defined above
- **Status fields MUST use Literal types** for type-specific enum values
- **JSON fields MUST be properly validated** during indexation
- **Foreign key relationships** are handled via JSON arrays for flexibility

### Resource Types

Resource types must align with distinct business domains and evolve independently, with
specialized models, workflows, validations, and user interfaces.

### Resource Dependencies

#### Dependency Models

Two dependency models are supported:

##### Explicit Dependencies (Primary Method)

- **Implementation**: Front matter fields define relationships between resources
- **Usage**: Primary method for creating navigable resource graphs
- **Fields** : Use descriptive field names ( `depends_on` , `references` , `supersedes` ,
  `blocks` )
- **Format**: List of resource IDs or slugs in YAML arrays
- **Example**:

  ```yaml
  depends_on:
    - policy-error-handling
    - adr-0001-database-selection
  references:
    - spec-authentication-flow
  ```

##### Implicit Dependencies (Secondary Method)

- **Implementation**: Directory structure creates hierarchical relationships
- **Usage**: Parent-child relationships for detailed sub-resources
- **Pattern**: `resource.md` with `resource/sub-resource.md` structure
- **Application**: Defined per resource type, not universally applied

#### Dependency Documentation

- **Dependency matrices SHOULD be used** to document cross-domain relationships
- **Status documentation**: Mark unspecified relationships clearly

#### Reference Standards

- **Use consistent field names** for similar relationship types across all resource types
- **Reference by ID** for stability across file renames
- **Document relationship purpose** when relationship type is not obvious from field name
- **Maintain bidirectional traceability** when relationships are symmetric

#### Reference Validation

- **Avoid circular dependencies** within same resource type
- **Cross-domain cycles are acceptable** when they represent legitimate business
  relationships
- **Validate referenced resources exist** during indexing
- **Handle broken references gracefully** without failing entire operations
- **Support forward references** for resources not yet created

## Exceptions

- **Legacy resources** may retain existing naming patterns until migration is completed
- **Emergency operations** may bypass validation with proper documentation and review

## References

- [Errors and Logging Policy](./errors_and_logging.md) - Error handling for dependency resolution
