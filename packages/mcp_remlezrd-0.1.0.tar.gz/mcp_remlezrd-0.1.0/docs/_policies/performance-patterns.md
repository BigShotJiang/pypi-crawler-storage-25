---
created_at: '2025-11-13'
status: draft
tags:
- performance
- regex
- optimization
name: "performance-patterns"
description: "Performance optimization patterns"
updated_at: '2025-11-13'
---

## Purpose

Establish performance optimization patterns that provide measurable benefits without
over-engineering. Focuses on precomputing expensive operations that are executed
frequently, preventing performance degradation in critical code paths.

## Principles

- **Performance First** : Expensive operations like regex compilation must be optimized
  for frequent use
- **Avoid Over-Engineering**: Only optimize code paths that actually impact performance

## Rules

### Regex Precompilation Requirements

- Regex patterns used in validation logic MUST be compiled once at application startup or
  pattern definition time
- Frequently used regex patterns MUST be precompiled when the pattern is defined or at
  application startup
- Field validation patterns (ID formats, path patterns) MUST be precompiled at application
  startup
- Precompiled patterns MUST be stored in accessible locations for validation functions

### Performance Optimization Guidelines

- Validation optimizations SHOULD target frequently executed code paths only
- Micro-optimizations for rarely used features SHOULD be avoided
- Performance benefits MUST be measurable before implementing optimization patterns

## Exceptions

- Simple string comparison validation does not require optimization (enum values, boolean
  flags)
- One-time patterns used in scripts may skip precompilation

## References

- [Resource Base Policy](resource-base.md) for base validation requirements
- [Testing Policy](testing.md) for validation test requirements
