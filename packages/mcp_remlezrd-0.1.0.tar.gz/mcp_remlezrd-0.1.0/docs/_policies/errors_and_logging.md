---
created_at: '2025-11-13'
status: enforced
tags:
- policy
- error-handling
- logging
- exceptions
- debugging
name: "errors-and-logging"
description: "Error handling and logging policy"
updated_at: '2025-11-13'
---

## Purpose

This policy establishes guidelines for error handling and logging to prevent risks such as unclear
failures, unpredictable behavior, security breaches from exposed data, and maintenance difficulties.
It ensures consistent debugging capabilities while maintaining system reliability.

## Principles

- **Simplicity (KISS)** : Prefer standard exceptions and clear, predictable patterns to reduce
  complexity
- **Consistency** : Use standardized error types, logging modules, levels, and message formats
- **Security**: Never expose sensitive information in errors or logs
- **Predictability** : Ensure errors and logs are handled consistently across the application
- **Usefulness** : Focus on relevant context to facilitate debugging without overwhelming
  maintenance

## Rules

### Error Handling

- Use standard Python exceptions when sufficient
- Create a single base for application errors using `class RemLezrdError(Exception)` as base class
  for expected errors
- Raise `RemLezrdError` (or explicit subclass) for expected errors
- Create new exceptions **only if**:
  - Recovery code needs it (`except SpecificError`)
  - User message really differs
- Error message format: short sentence + useful context like "Invalid config file: missing 'path'
  key"
- Never include secrets, credentials, or sensitive paths in error messages
- Always clean up resources (`finally` or context managers)
- Balance strict validation with user experience:
  - **Strict validation** for operations that could cause data inconsistency
  - **Permissive validation** for redundant operations that don't cause harm

### FastMCP Error Handling Middleware

- **Minimum configuration** with the unique application logger, traceback inclusion based on debug
  mode, and error transformation enabled
- **ToolError and ResourceError coexist perfectly** with middleware - they are always transmitted to
  clients
- **Custom business exceptions should inherit from ToolError** for client visibility and consistent
  error handling
- **Standard exceptions may be masked** by middleware when not in debug mode for security purposes
- **Middleware provides automatic error statistics** for monitoring and debugging purposes

### FastMCP Error Types

- Use `ToolError` for client-facing business logic errors
  - Always transmitted to client, never masked
  - Usage: Invalid inputs, constraint failures, user-correctable issues
- Use `ResourceError` for data access errors
  - Always transmitted to client, never masked
  - Usage: Missing files, database unavailable, permission denied
- Use standard exceptions for system errors and unexpected conditions
  - Only these are affected by `mask_error_details=True`
  - Usage: Database connection failures, internal exceptions

### Logging Standards

- Use the module logger with `logging.getLogger(__name__)` pattern
- Recommended levels:
  - `DEBUG` → internal, temporary details
  - `INFO` → normal events, success operations
  - `WARNING` → expected problems, recoverable issues
  - `ERROR` → unexpected or critical failures
- Never log sensitive data (tokens, PII, passwords, credentials)
- Use automatic log rotation with standard Python handlers for file-based logging
- Log only what helps diagnose issues - avoid noise from excessive logging

#### Structured Logging

Use structured logging with the `extra` parameter and a dedicated `event.*` namespace:

**Classification (`event.*`):**

- `event.name` (REQUIRED): `<object>.<action>` format, lowercase, no dynamic values
  - Examples: `"content.parse"`, `"file.write"`, `"resource.create"`
- `event.domain` (optional): Business domain for filtering
  - Examples: `"skill"`, `"rule"`, `"glossary"`, `"adr"`
- `event.outcome` (optional): `"success"`, `"failure"`, or `"unknown"`

**Context (attributes):**

- All other data goes in attributes (NOT `event.*`)
- Examples: `user.id`, `file.path`, `duration_ms`, `error.message`

**Example:**

```python
logger.debug(
    "Parsing skill content",
    extra={
        "event.name": "content.parse",
        "event.domain": "skill",
    },
)

logger.debug(
    "Parsed skill content",
    extra={
        "event.name": "content.parse",
        "event.domain": "skill",
        "event.outcome": "success",
        "triggers.count": len(triggers),
        "instructions.count": len(instructions),
    },
)
```

### FastMCP Logging Middleware

- **Minimum configuration** with the unique application logger, payload inclusion based on debug
  mode, and log level adapted to debug mode
- **Middleware automatically captures all MCP operations** (tools, resources, prompts) in addition
  to existing application logging
- **Preserves existing logging infrastructure** - middleware adds MCP operation visibility while
  maintaining file handlers, log levels, and custom formatters
- **Payload logging is optional** and configurable for debugging purposes

### Error and Logging Integration

- For FastMCP operations, use Context.log() methods: Context.debug() for development details,
  Context.info() for operation success, Context.warning() for recoverable issues, Context.error()
  for error context without client exposure
- For exception logging: log RemLezrdError with warning level including class name, log unexpected
  exceptions with error level and exc_info=True for full traceback
- For JSON exception logging with structured data: include operation context, relevant IDs, retry
  counts, and full traceback information in extra fields
- When operations fail, provide fallback mechanisms where reasonable
- For batch operations, continue processing remaining items when individual items fail
- Return partial results rather than complete failures when possible

## Exceptions

- **Security-critical operations** may require strict validation even for harmless redundancies
- **Legacy system integrations** may need custom error handling patterns
- **Emergency debugging** may temporarily require exposing internal errors with proper approval
- **High-volume operations** may need reduced logging to prevent performance impact

## References

- [Python Errors and Exceptions](https://docs.python.org/3/tutorial/errors.html) - Official Python documentation
- [Python Logging Documentation](https://docs.python.org/3/library/logging.html) - Official logging module documentation
- [FastMCP Documentation](https://fastmcp.dev/) - Framework-specific error handling patterns
