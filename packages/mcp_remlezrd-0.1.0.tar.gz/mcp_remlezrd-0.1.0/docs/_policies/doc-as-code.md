---
authors:
- ai-assistant@example.com
created_at: '2025-11-13'
last_updated: '2025-11-20'
status: enforced
tags:
- policy
- documentation
- doc-as-code
- ADR
- POLICY
- SPEC
name: "doc-as-code"
description: "Documentation as code policy"
updated_at: '2025-11-13'
version: 1.0.0
---

# Doc-as-Code Policy (KISS+)

## Purpose

This policy establishes guidelines for treating documentation as code to ensure
consistency, maintainability, and version control in a small open-source project.

## Principles

- **Consistency** : Use uniform structures for ADR, POLICY, and SPEC to facilitate
  navigation and contributions.
- **Simplicity** : Keep formats straightforward and distinguishable by purpose, avoiding
  over-complexity.
- **Versioning** : Treat docs as code with proper Git history, reviews, and updates
  aligned with code changes.

## Rules

### Definitions

- **ADR (Architecture Decision Record)** : Document architectural decisions, including
  context, chosen option, alternatives, consequences, and rationale. Used for governance
  and historical reference.
- **POLICY** : Establish project-wide guidelines, standards, or rules for processes,
  tools, or behaviors. Mandatory or recommended practices.
- **SPEC (Specification)** : Detail technical or functional requirements, implementation
  details, or system behaviors. Covers domain, infra, and operations aspects.

### Formatting Guidelines

- **ADR**:
  - ## Context: Background and problem description.
  - ## Decision: Chosen option clearly stated.
  - ## Alternatives Considered: Other options evaluated.
  - ## Consequences: Implications, trade-offs, risks, next steps.
  - ## References: Links to related docs.
- **POLICY**:
  - ## Purpose: Why the policy exists and risks it prevents.
  - ## Principles: High-level philosophy guiding rules.
  - ## Rules: Mandatory or recommended practices.
  - ## Exceptions: How and when deviations are allowed.
  - ## References: Linked ADRs, specs, or external standards.
- **SPEC** : Format libre (free-form); organize with headings as needed for clarity (e.g.,
  Overview, Requirements, Implementation).

### File Organization

- docs/_adrs/*.md: Flat structure for all ADRs.
- docs/_glossary/*.md: Flat structure for glossary terms.
- docs/_policies/*.md: Flat structure for all policies.
- docs/_specs/domain/ docs/_specs/domain/ **subdomain** / * .md: Domain-specific specs
  under subdomains (e.g., docs/_specs/domain/authentication/login.md).
- docs/_specs/infra/ docs/_specs/infra/ **subdomain** / * .md: Infra specs under
  subdomains (e.g., docs/_specs/infra/database/connections.md).
- docs/_specs/operations/ docs/_specs/operations/ **subdomain** / * .md: Operations specs
  under subdomains (e.g., docs/_specs/operations/monitoring/alerts.md).

### Why Underscore Prefix

Underscore prefix follows established conventions (Jekyll, Python, SASS) for
internal/contributor files vs public/user files.

### Compliance Rules

- All new internal documentation must follow this naming convention.
- Files are visible by default in Git (not hidden).
- Maintains clear separation between internal and user documentation.

## Exceptions

None defined.

## References

- [Markdown Guide](https://www.markdownguide.org/) - Standard for markdown formatting.
