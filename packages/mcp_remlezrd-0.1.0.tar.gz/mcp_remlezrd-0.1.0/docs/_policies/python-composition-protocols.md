---
name: "python-composition-protocols"
description: "Favor composition over inheritance, use Protocols for interfaces"
tags:
  - python
  - architecture
  - composition
  - protocols
  - inheritance
  - design-patterns
created_at: "2026-02-19"
updated_at: "2026-02-19"
status: draft
---

## Purpose

This policy provides guidelines for using **composition** and **protocols** as alternatives to
**class inheritance** in Python code. It promotes flexible, testable designs while acknowledging
when inheritance is appropriate.

Without awareness of these patterns, codebases tend to accumulate rigid class hierarchies that:

- Create tight coupling between parent and child classes
- Make unit testing more complex (requires understanding entire inheritance chain)
- Reduce flexibility (behaviors locked in hierarchy)
- Complicate future refactoring

## Principles

- **"Favor composition over inheritance"** - Prefer assembling objects from smaller components
  rather than inheriting behaviors
- **"Use Protocols for interfaces"** - Consider `typing.Protocol` for defining contracts without
  imposing inheritance
- **"Explicit dependencies are better"** - Constructor injection makes dependencies visible and
  replaceable
- **"Inheritance is for 'is-a', composition is for 'has-a'"** - Reserve inheritance for true
  taxonomic relationships

## Rules

### General Guidelines

- **SHOULD** prefer composition when assembling behaviors from multiple sources
- **SHOULD** consider `typing.Protocol` for defining interfaces, especially for duck typing
  scenarios
- **SHOULD** use constructor injection for external dependencies
- **SHOULD** question inheritance hierarchies deeper than 2-3 levels
- **MAY** use inheritance when frameworks require it (SQLModel, Django ORM, etc.)

### Protocol Guidelines

- **SHOULD** use `typing.Protocol` for defining structural interfaces
- **SHOULD** keep protocols focused and minimal (Interface Segregation Principle)
- **MAY** use `@runtime_checkable` when runtime type checking is needed
- **SHOULD** use descriptive names (e.g., `Logger`, `Serializer`, `Validator`)

### Examples

#### ✅ Composition simple

```python
class EmailSender:
    def send(self, to: str, body: str) -> None:
        print(f"Sending email to {to}")


class NotificationService:
    """Composed with concrete dependency."""

    def __init__(self, sender: EmailSender):
        self._sender = sender

    def notify(self, user: str) -> None:
        self._sender.send(user, "Hello!")
```

#### ✅ Composition + Protocol

```python
from typing import Protocol


class Sender(Protocol):
    def send(self, to: str, body: str) -> None: ...


class EmailSender:
    def send(self, to: str, body: str) -> None:
        print(f"Email to {to}")


class SmsSender:
    def send(self, to: str, body: str) -> None:
        print(f"SMS to {to}")


class NotificationService:
    """Composed with protocol - any Sender implementation works."""

    def __init__(self, sender: Sender):
        self._sender = sender

    def notify(self, user: str) -> None:
        self._sender.send(user, "Hello!")


# Usage: easily swap implementations
service = NotificationService(EmailSender())
service = NotificationService(SmsSender())  # Same interface
```

## Exceptions

- **Framework constraints**: SQLModel, Django ORM, or other frameworks requiring inheritance
- **Simple shared code**: Small utility methods may be shared via inheritance or mixins
- **Data transfer objects**: Pydantic models for API schemas may use inheritance for shared fields
- **Legacy code**: Existing hierarchies can remain until refactoring is justified
- **True taxonomic relationships** : When "is-a" semantics are genuinely correct (rare in business
  logic)

## Decision Guide

Use this guide when designing new classes:

| Question | If YES | If NO |
|----------|--------|-------|
| Is this a data model with database persistence? | Inheritance (SQLModel) | Consider composition |
| Do multiple unrelated classes need this behavior? | Protocol + composition | Inheritance may work |
| Will this need different implementations for testing? | Protocol | Concrete class |
| Is this a framework requirement? | Follow framework | Choose freely |
| Is this purely about code reuse? | Composition | — |

## References

- **Python Patterns**: "Favor composition over inheritance" - Modern Python best practice
- **PEP 544**: Protocols - Structural subtyping
- **External**: [Python Design Patterns](https://python-patterns.guide/) - Composition patterns
