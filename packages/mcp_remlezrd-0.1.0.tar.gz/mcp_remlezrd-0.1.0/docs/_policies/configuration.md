---
created_at: '2025-11-13'
status: enforced
tags:
- configuration
- cli
- environment
- storage
- logging
name: "configuration"
description: "Configuration management policy"
updated_at: '2025-11-13'
---

## Purpose

This policy establishes standardized configuration management patterns to ensure consistent,
predictable, and maintainable application configuration across all deployment environments. It
prevents configuration drift, reduces deployment errors, and improves troubleshooting capabilities.

## Principles

- **Precedence Clarity**: Clear hierarchy for configuration source priority
- **Environment Parity**: Same configuration mechanisms across all environments
- **Discoverability**: All configuration options must be documented and accessible
- **Security**: Sensitive configuration handled through secure channels
- **Flexibility**: Support for both development and production deployment patterns

## Rules

### Configuration Precedence Order

Configuration MUST follow this precedence order (highest to lowest priority):

1. **CLI arguments** (highest priority)
2. **Environment variables** (prefixed `REMLEZRD_`)
3. **Default values** (defined in Pydantic model, lowest priority)

### CLI Argument Conventions

- **All CLI arguments MUST use kebab-case** (e.g., `--my-param`, `--custom-dir`)
- **Arguments MUST have both short and long forms** where appropriate
- **Help text MUST be descriptive** and include default values
- **Boolean flags MUST use --flag/--no-flag pattern** as provided natively by Typer

### Environment Variable Conventions

- **All environment variables MUST be prefixed with `REMLEZRD_`**
- **Variable names MUST use UPPER_SNAKE_CASE** after the prefix
- **Examples**:
  - `REMLEZRD_MY_STORAGE` for `--my-storage` argument
  - `REMLEZRD_PARAM1` for `--param1` argument

### Storage Configuration Requirements

- **Shared storage path MUST be configurable**
- **All project storage subdirectories MUST be configurable** relative to CWD

### Logging Configuration Requirements

- **Log level MUST be configurable** for debugging purposes
- **Log file path MUST be configurable** for different deployment scenarios
- **Debug mode MUST enable verbose logging** and framework internals
- **Production mode MUST use appropriate log levels** for performance

### Configuration Exposure Requirements

- **Every configuration option MUST be exposed via both CLI argument and environment variable**
- **Configuration validation MUST occur at startup** with clear error messages
- **Default values MUST be documented** in help text and configuration schemas
- **Configuration state MUST be logged** at startup (excluding sensitive values)

### Development Tools Configuration

- **pyproject.toml SHOULD be used** for centralized configuration of development tools
- **Global scope**: Configuration precedence and validation patterns apply to all tools
- **Avoid configuration fragmentation** : Prefer single configuration files over multiple
  tool-specific files
- **Integration**: Development toolchain configurations follow the same precedence order

### Configuration Validation

- **Path configurations MUST be validated** for basic accessibility
- **Invalid configurations MUST provide clear error messages**
- **Relative paths MUST be resolved consistently**
- **Environment variable parsing MUST handle basic type conversion**

## Exceptions

- **Container deployments** may require different default paths with proper documentation
- **CI/CD environments** may need special configuration handling for ephemeral filesystems
- **Development setups** may use different default values with proper environment
  detection

## References

- [Server Configuration Specification](../_specs/infra/configuration.md) - Detailed configuration parameters
- [Environment Setup Guide](../../README.md#configuration) - User-facing configuration documentation
- [Pydantic Settings](https://docs.pydantic.dev/latest/concepts/pydantic_settings/) - Configuration model implementation
