---
created_at: '2025-11-13'
status: enforced
tags:
- development
- tools
- ci
- code-quality
- debugging
name: "development-tools"
description: "Development tools and workflow policy"
updated_at: '2025-11-13'
---

## Purpose

This policy establishes standardized development toolchain and practices to ensure consistent code
quality, maintainable build processes, and efficient debugging capabilities across the project. It
prevents tool fragmentation, reduces onboarding complexity, and maintains uniform development
experience.

## Principles

- **Toolchain Consistency** : Same tools and configurations across all development environments
- **Configuration Centralization**: Single source of truth for tool configurations
- **Quality Automation**: Automated code formatting, linting, and type checking
- **Efficient Debugging** : Standardized debugging and inspection tools for development workflow
- **Build Reproducibility**: Consistent build orchestration and dependency management

## Rules

### Code Quality Tools

- **ruff MUST be used** for both code formatting and linting
  - **Formatting**: Enforce consistent code style automatically
  - **Linting**: Catch code quality issues and potential bugs
  - **Configuration** : `[tool.ruff.format]` and `[tool.ruff.lint]` sections in `pyproject.toml`
- **Static type checking MUST use one of** (in order of preference):
  - **ty** (preferred) - Fast, modern Python type checker written in Rust
  - **pyrefly** or **basedpyright** - Alternative high-performance type checkers
  - **pyright** - Microsoft's standard Python type checker
  - **Purpose**: Catch type-related errors before runtime
  - **Configuration** : `[tool.ty]` , `[tool.pyrefly]` , `[tool.basedpyright]` , or `[tool.pyright]`
    section in `pyproject.toml`

### Testing Framework

- **pytest MUST be used** as the primary test engine
  - **Purpose**: Run and validate functionality tests
  - **Configuration**: `[tool.pytest.ini_options]` section in `pyproject.toml`
  - **Integration**: Follow Testing Policy for test strategy and patterns

### Package Management

- **uv MUST be used** for Python dependency management
  - **Purpose**: Manage dependencies and virtual environments efficiently
  - **Integration** : Tasks in `Taskfile.yml` for dependency operations (e.g., `uv:deps:update` )

### Build Orchestration

- **Taskfile MUST be used** for build, test, and development task orchestration
  - **Configuration**: `Taskfile.yml` in project root
  - **Purpose**: Provide consistent interface for all development operations
  - **Tasks** : Include standard tasks for build, test, lint, format, and dependency management

### Configuration Management

- **pyproject.toml MUST be the primary configuration file** for all Python tools
  - **Avoid configuration fragmentation** : Do not create additional config files when
    centralization is possible
  - **Centralization** : All tool configurations (ruff, type checker, pytest, uv) in single file
  - **Consistency**: Standardized configuration patterns across projects
  - **Maintenance**: Single location for tool configuration updates

### MCP Debugging Tools

- **mcp-inspector SHOULD be integrated** for MCP server debugging and inspection
  - **Purpose**: Real-time monitoring of MCP tools, resources, and interactions
  - **Integration**: `task run:inspector` for piping MCP server output to inspector
  - **Usage**: Development and debugging workflow enhancement

### Tool Integration Requirements

- **All tools MUST be integrated** into the build pipeline
- **Configuration consistency MUST be maintained** across development and CI environments
- **Documentation MUST include** setup instructions for the complete toolchain

## Exceptions

- **Legacy projects** may maintain existing toolchain until migration is feasible with proper
  documentation
- **Specialized tools** may be added for specific domains with justification and integration plan
- **External tool constraints** may require alternative configurations with documented rationale

## References

- [Configuration Management Policy](./configuration.md) - Configuration precedence and patterns
- [Testing Policy](./testing.md) - Test strategy and framework integration
- [ruff Documentation](https://docs.astral.sh/ruff/) - Formatting and linting tool
- [ty Documentation](https://github.com/astral-sh/ty) - Preferred static type checker
- [pyrefly Documentation](https://pyrefly.org/) - Alternative static type checker
- [basedpyright Documentation](https://github.com/detachhead/basedpyright) - Alternative static type checker
- [pyright Documentation](https://microsoft.github.io/pyright/) - Standard static type checker
- [pytest Documentation](https://docs.pytest.org/) - Testing framework
- [Taskfile Documentation](https://taskfile.dev/) - Build orchestration tool
