# mcp-remlezrd

[![python](https://img.shields.io/badge/python-3.13%2B-blue)](https://www.python.org/)
[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![latest](https://gitlab.com/gp3t1/ai/mcp-remlezrd/-/badges/release.svg?order_by=release_at&key_text=latest&key_width=55)](https://gitlab.com/gp3t1/ai/mcp-remlezrd/-/releases/permalink/latest)
[![coverage](https://gitlab.com/gp3t1/ai/mcp-remlezrd/badges/master/coverage.svg)](https://gitlab.com/gp3t1/ai/mcp-remlezrd)
[![license](https://img.shields.io/gitlab/license/75754026)](https://gitlab.com/gp3t1/ai/mcp-remlezrd/-/blob/master/LICENSE.md)

MCP server for AI agent collaboration through structured, shareable resources.

## Features

### 1. Agent Autonomy for Context Loading

The server empowers AI agents to self-discover and load team standards (development, design,
architecture, etc.) without hard-coding context:

- **Discovery tools** — Provide a searchable index of all project and shared standards so the agent
  knows what resources exist before reading them.
- **Native MCP resources** — Standards are exposed as MCP resources in Markdown format, directly
  accessible by the client.
- **Tool fallback** — If the MCP client does not support resources, the same content is available
  via dedicated read tools.

### 2. (Agent|Human)-Friendly Workflow

Designed for collaboration between developers and AI agents:

- **Human-first editing** — All resources are plain Markdown files with YAML frontmatter. Developers
  can read, edit, and version them with standard tools.
- **Agent consumption** — Agents read resources natively via MCP (or through tools when resource
  support is absent).
- **Agent-assisted maintenance** — Agents can create, update, and delete standards through CRUD
  tools, keeping conventions alive without manual boilerplate.

### 3. Modular Standards, Universal Access

- **Specialized resources** — Standards, procedures, and knowledge are stored in dedicated,
  maintainable files instead of monolithic `README.md` or `AGENTS.md` .
- **Universal format** — Uses the MCP protocol, avoiding IDE-specific formats such as `.cursorrules`
  , `.windsurfrules` , or `CLAUDE.md` .

### 4. Project-Only Resources (scoped to `cwd`)

| Resource | Status | Description |
|---|---|---|
| **ADR** | `experiment` | Architecture Decision Records — capture technical choices, trade-offs, and their rationale. |
| **Glossary** | `experiment` | Term definitions and domain vocabulary — ensure consistent language across the team. |

### 5. Shareable Resources (external directory)

| Resource | Status | Description |
|---|---|---|
| **Rule** | `experiment` | Coding standards and constraints — enforceable guidelines for agent behavior. |
| **Skill** | `experiment` | Actionable procedures and how-to guides — step-by-step recipes for common tasks. |

## Getting Started

### Starting RemLezrd MCP Server

Run with default settings:

```bash
uv run mcp-remlezrd
uv run mcp-remlezrd --no-shared
uv run mcp-remlezrd --disable-resources skill,glossary
uv run mcp-remlezrd --no-write-servers project,shareable
```

Run with custom paths and logging:

```bash
uv run mcp-remlezrd --log-file /tmp/remlezrd.log
uv run mcp-remlezrd --no-write-resources rule,skill --resource-as-tool
```

> **NOTE:** `--shared` controls whether the shared directory is mounted at startup (a physical
> storage concern). Use `--disable-servers`, `--disable-resources`, `--no-write-servers`, or
> `--no-write-resources` to control which MCP components are exposed and their access mode
> (read-write vs read-only). These are independent mechanisms.

### Configure MCP Clients (IDE, Agents, etc)

TODO

### CLI Options and environment variables

```txt
Usage: mcp-remlezrd [OPTIONS]

╭─ Options ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────╮
│ --shared              --no-shared                    Enable/disable shared directory (Disable to use project-only mode)                  │
│                                                      [env var: REMLEZRD_ENABLE_SHARED_DIR]                                               │
│                                                      [default: shared]                                                                   │
│ --resource-as-tool    --no-resource-as-tool          Only for CLIENT with NO 'MCP Resources' Support                                     │
│                                                      [env var: REMLEZRD_RESOURCES_AS_TOOLS]                                              │
│                                                      [default: no-resource-as-tool]                                                      │
│ --log-file                                     PATH  Path to log file [env var: REMLEZRD_LOG_FILE]                                       │
│ --help                                               Show this message and exit.                                                         │
╰──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────╯
╭─ Options: RemLezrd Features Activation (support comma-separated lists) ──────────────────────────────────────────────────────────────────╮
│ --disable-servers           [project|shareable|onboarding]  List of servers to disable [env var: REMLEZRD_DISABLE_SERVERS]               │
│ --no-write-servers          [project|shareable|onboarding]  List of servers to disable RW tools from                                     │
│                                                             [env var: REMLEZRD_NO_WRITE_SERVERS]                                         │
│ --disable-resources         [adr|glossary|rule|skill]       List of resource types to disable [env var: REMLEZRD_DISABLE_RESOURCES]      │
│ --no-write-resources        [adr|glossary|rule|skill]       List of resource types to disable RW tools from                              │
│                                                             [env var: REMLEZRD_NO_WRITE_RESOURCES]                                       │
╰──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────╯

Other Environment Variables:
🔹 Console handler log level  [env var: REMLEZRD_LOG_LEVEL]         [default: 'WARNING']
🔹 File handler log level     [env var: REMLEZRD_LOG_FILE_LEVEL]    [default: 'INFO']
🔹 Abs. path to Project dir   [env var: REMLEZRD_OVERRIDE_CWD]      [default: '<cwd>']
🔹 Abs. path to Shared dir    [env var: REMLEZRD_SHARED_DIR]        [default: '~/.local/share/remlezrd']
🔹 Subdir for ADRs            [env var: REMLEZRD_SUBDIR_ADR]        [default: 'docs/_adrs']
🔹 Subdir for Glossaries      [env var: REMLEZRD_SUBDIR_GLOSSARY]   [default: 'docs/_glossary']
🔹 Subdir for Rules           [env var: REMLEZRD_SUBDIR_RULE]       [default: 'docs/_rules']
🔹 Subdir for Skills          [env var: REMLEZRD_SUBDIR_SKILL]      [default: 'docs/_skills']
```
