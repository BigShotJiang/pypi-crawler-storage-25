from typing import Any

from dependency_injector import containers, providers

from mcp_remlezrd.features.project.adr import ProjectAdrService
from mcp_remlezrd.features.project.glossary import ProjectGlossaryService
from mcp_remlezrd.features.shareable.rule import ShareableRuleService
from mcp_remlezrd.features.shareable.skill import ShareableSkillService
from mcp_remlezrd.infra.config.args import ResourceArgValues, ServerArgValues
from mcp_remlezrd.infra.external.file_watcher import FileWatcherService
from mcp_remlezrd.infra.persistence import DBManager, FileBackupTransaction, MarkdownFileManager


class Container(containers.DeclarativeContainer):
    """Dependency injection container for the MCP RemLezrd application."""

    # Application settings object for property access (set via override)
    app_settings = providers.Object(None)

    # Infrastructure singletons
    db_manager = providers.Singleton(DBManager)

    # File manager singleton
    mdfile_manager = providers.Singleton(MarkdownFileManager)

    # Session provider for database operations
    db_session = providers.Factory(lambda dm: dm.get_session(), db_manager)

    # Factory for file transaction (injects callable for dynamic path)
    file_tx_factory = providers.Object(lambda path: FileBackupTransaction(path))

    # File watcher for automatic reindexation
    file_watcher = providers.Singleton(FileWatcherService)

    # Service singletons (ensures single instance per service type)
    project_adr_service = providers.Singleton(
        ProjectAdrService,
        files_manager=mdfile_manager,
        session=db_session,
        file_tx_factory=file_tx_factory,
        project_res_path=providers.Callable(lambda s: s.adr_project_path, app_settings),
        rw=providers.Callable(
            lambda s: (
                ServerArgValues.PROJECT not in s.activation.no_write_servers
                and ResourceArgValues.ADR not in s.activation.no_write_resources
            ),
            app_settings,
        ),
    )

    project_glossary_service = providers.Singleton(
        ProjectGlossaryService,
        files_manager=mdfile_manager,
        session=db_session,
        file_tx_factory=file_tx_factory,
        project_res_path=providers.Callable(lambda s: s.glossary_project_path, app_settings),
        rw=providers.Callable(
            lambda s: (
                ServerArgValues.PROJECT not in s.activation.no_write_servers
                and ResourceArgValues.GLOSSARY not in s.activation.no_write_resources
            ),
            app_settings,
        ),
    )

    shareable_rule_service = providers.Singleton(
        ShareableRuleService,
        files_manager=mdfile_manager,
        session=db_session,
        file_tx_factory=file_tx_factory,
        project_res_path=providers.Callable(lambda s: s.rule_project_path, app_settings),
        shared_res_path=providers.Callable(lambda s: s.rule_shared_path if s.shared_dir else None, app_settings),
        rw=providers.Callable(
            lambda s: (
                ServerArgValues.PROJECT not in s.activation.no_write_servers
                and ResourceArgValues.RULE not in s.activation.no_write_resources
            ),
            app_settings,
        ),
        rw_shared=providers.Callable(
            lambda s: (
                ServerArgValues.SHAREABLE not in s.activation.no_write_servers
                and ResourceArgValues.RULE not in s.activation.no_write_resources
            ),
            app_settings,
        ),
    )

    shareable_skill_service = providers.Singleton(
        ShareableSkillService,
        files_manager=mdfile_manager,
        session=db_session,
        file_tx_factory=file_tx_factory,
        project_res_path=providers.Callable(lambda s: s.skill_project_path, app_settings),
        shared_res_path=providers.Callable(lambda s: s.skill_shared_path if s.shared_dir else None, app_settings),
        rw=providers.Callable(
            lambda s: (
                ServerArgValues.PROJECT not in s.activation.no_write_servers
                and ResourceArgValues.SKILL not in s.activation.no_write_resources
            ),
            app_settings,
        ),
        rw_shared=providers.Callable(
            lambda s: (
                ServerArgValues.SHAREABLE not in s.activation.no_write_servers
                and ResourceArgValues.SKILL not in s.activation.no_write_resources
            ),
            app_settings,
        ),
    )


def get_services_dict(container: Container) -> dict[str, Any]:
    """Get all services as a dict.

    Args:
        container: Container instance

    Returns:
        Dictionary mapping service names to service instances
    """
    return {
        "shareable_rule": container.shareable_rule_service(),
        "shareable_skill": container.shareable_skill_service(),
        "project_adr": container.project_adr_service(),
        "project_glossary": container.project_glossary_service(),
    }
