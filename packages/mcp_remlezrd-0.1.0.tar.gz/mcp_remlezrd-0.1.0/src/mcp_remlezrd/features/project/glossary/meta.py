"""Glossary resource metadata."""

from mcp_remlezrd.features.shared.app_meta import APP
from mcp_remlezrd.features.shared.meta_types import ResourceMeta

META = ResourceMeta(
    pretty_name="Glossary",
    resource_type="glossary",
    pretty_plural="Glossaries",
    short_plural="glossaries",
    tag="res:glossary",
    create_tool="create_glossary",
    update_tool="update_glossary",
    delete_tool="delete_glossary",
    discover_tool="discover_glossaries_only",
    base_uri=f"{APP.server_name}://glossary/",
    shared_base_uri="",
    resource_component="read_glossary",
    shared_resource_component="",
)
