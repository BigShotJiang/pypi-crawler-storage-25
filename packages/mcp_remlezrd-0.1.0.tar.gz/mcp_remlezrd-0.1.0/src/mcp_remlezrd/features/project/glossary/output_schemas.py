"""Output schemas for Glossary operations.

These Pydantic models define the structure of responses from glossary operations,
used by both the service layer and MCP tools.
"""

from pydantic import BaseModel, Field


class GlossaryCreateResult(BaseModel):
    """Result of glossary creation operation."""

    name: str = Field(description="Glossary name (kebab-case)")
    created_at: str = Field(description="Creation timestamp (ISO 8601)")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")


class GlossaryUpdateResult(BaseModel):
    """Result of glossary update operation."""

    name: str = Field(description="Glossary name")
    updated_at: str = Field(description="Last update timestamp (ISO 8601)")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")


class GlossaryDeleteResult(BaseModel):
    """Result of glossary deletion operation."""

    name: str = Field(description="deleted Glossary name")
    deleted_at: str = Field(description="Deletion timestamp (ISO 8601)")


class GlossaryDiscoverEntry(BaseModel):
    """Single entry in the glossary discovery catalog."""

    name: str = Field(description="Glossary name (kebab-case)")
    description: str = Field(description="Brief description")
    terms: list[str] = Field(description="List of key terms defined in this glossary")
    alias: list[str] | None = Field(
        default=None, exclude_if=lambda v: v is None, description="List of synonyms, acronyms, and abbreviations"
    )
    tags: list[str] | None = Field(default=None, exclude_if=lambda v: v is None, description="Classification tags")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")
    uri: str = Field(description="Resource URI for reading this glossary entry")


class GlossaryDiscoverResult(BaseModel):
    """Result of glossary discovery operation."""

    glossaries: list[GlossaryDiscoverEntry] = Field(description="Catalog of available glossary entries")
