"""Content strategy for ProjectGlossary resources.

Uses marko for markdown parsing with section-based approach.
"""

import logging

from marko import Markdown
from pydantic import BaseModel, Field

from mcp_remlezrd.features.shared.domain import (
    MarkdownList,
    MarkdownListItem,
    SimpleMarkdownContent,
    SimpleMarkdownParagraphs,
)
from mcp_remlezrd.features.shared.exceptions import SectionParsingError
from mcp_remlezrd.features.shared.markdown import extract_h1_preamble, validate_no_unexpected_h2_sections
from mcp_remlezrd.features.shared.markdown.normalized_renderer import normalize_markdown
from mcp_remlezrd.features.shared.md_sections import CodeBlock, ReferencesSection

from .md_sections import (
    KeyTermsSection,
    RelationsSection,
    UsageContextSection,
)

logger = logging.getLogger(__name__)

REQUIRED_SECTIONS = {"Key Terms"}
OPTIONAL_SECTIONS = {"Usage Context", "Relations", "References"}
ALLOWED_SECTIONS = REQUIRED_SECTIONS | OPTIONAL_SECTIONS


class ProjectGlossaryData(BaseModel):
    """Structured data for a ProjectGlossary resource (content only)."""

    preamble: SimpleMarkdownParagraphs = Field(..., min_length=1)
    key_terms: dict[str, MarkdownListItem] = Field(..., min_length=1)
    usage_context: SimpleMarkdownContent | None = None
    usage_examples: list[CodeBlock] | None = None
    relations: MarkdownList | None = None
    references: MarkdownList = Field(default_factory=list)


def parse_project_glossary(content: str) -> ProjectGlossaryData:
    """Parse markdown content into structured ProjectGlossary data.

    Note: The H1 title is ignored - name comes from frontmatter.

    Raises:
        SectionNotFoundError: If required sections are missing
        SectionParsingError: If sections are malformed
    """
    logger.debug(
        "Parsing glossary content",
        extra={
            "event.name": "content.parse",
            "event.domain": "glossary",
        },
    )

    doc = Markdown().parse(normalize_markdown(content))

    # Validate no unexpected sections
    validate_no_unexpected_h2_sections(doc, ALLOWED_SECTIONS)

    # Parse required sections
    preamble_parts = extract_h1_preamble(doc)
    if not preamble_parts:
        raise SectionParsingError("Glossary must have a preamble under the H1 heading")
    key_terms = KeyTermsSection.from_doc(doc)

    # Parse optional sections
    usage_context = UsageContextSection.from_doc(doc)
    if usage_context:
        # Validate Usage Context subsections (H3 level)
        invalid = [s for s in usage_context.subsections if s != "Examples"]
        if invalid:
            raise SectionParsingError(f"Usage Context section only supports 'Examples' H3 subsection, found: {invalid}")
    relations = RelationsSection.from_doc(doc)
    references = ReferencesSection.from_doc(doc)

    logger.debug(
        "Parsed glossary content",
        extra={
            "event.name": "content.parse",
            "event.domain": "glossary",
            "event.outcome": "success",
            "terms.count": len(key_terms.terms),
            "has.usage_context": usage_context is not None,
            "has.relations": relations is not None,
            "references.count": len(references.items),
        },
    )

    return ProjectGlossaryData(
        preamble=preamble_parts,
        key_terms=key_terms.terms,
        usage_context=usage_context.context if usage_context else None,
        usage_examples=usage_context.examples if usage_context else None,
        relations=relations.items if relations else None,
        references=references.items,
    )


def render_project_glossary(name: str, data: ProjectGlossaryData) -> str:
    """Render structured ProjectGlossary data back to markdown.

    Args:
        name: Resource name (from frontmatter)
        data: Structured content data
    """
    lines = [f"# ProjectGlossary '{name}'", ""]

    # Preamble (required, under H1)
    for para in data.preamble:
        lines.append(para)
        lines.append("")
    lines.append("")

    # Required sections
    lines.append(KeyTermsSection(terms=data.key_terms).render())

    # Optional sections - Usage Context with Examples
    if data.usage_context or data.usage_examples:
        lines.append("")
        lines.append(
            UsageContextSection(
                context=data.usage_context,
                examples=data.usage_examples,
            ).render()
        )

    if data.relations:
        lines.append("")
        lines.append(RelationsSection(items=data.relations).render())

    if data.references:
        lines.append("")
        lines.append(ReferencesSection(items=data.references).render())

    return "\n".join(lines)
