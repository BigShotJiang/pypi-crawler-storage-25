"""Canonical identifiers and descriptions for Glossary resources and tools."""

# =============================================================================
# Tool Descriptions - Purpose
# =============================================================================

CREATE_PURPOSE = "Create a new glossary entry to define domain terminology and concepts"
UPDATE_PURPOSE = "Update an existing glossary entry by modifying only the provided fields"
DELETE_PURPOSE = "Delete a glossary entry by name"

# =============================================================================
# Tool Descriptions - When To Use
# =============================================================================

CREATE_WHEN_TO_USE: list[str] = [
    "Use for documenting important domain-specific terminology",
    "Use for establishing consistent language across the project",
    "Use for defining acronyms, abbreviations, and their meanings",
    "Do NOT use for general vocabulary or standard language terms",
]

UPDATE_WHEN_TO_USE: list[str] = [
    "Use for refining definitions based on better understanding",
    "Use for adding aliases or synonyms",
    "Use for updating usage context or examples",
    "Do NOT use to completely change the meaning: create a new entry instead",
]

DELETE_WHEN_TO_USE: list[str] = [
    "Use for removing mistakenly created entries",
    "Use when a term is no longer used in the project",
    "Use for cleaning up duplicates",
    "Consider updating rather than deleting for evolved definitions",
]

# =============================================================================
# Tool Descriptions - Constraints
# =============================================================================

CREATE_CONSTRAINTS: list[str] = [
    "Project scope only: glossary entries cannot be created in shared scope",
    "Consider linking related terms via relations field",
]

UPDATE_CONSTRAINTS: list[str] = [
    "Only provided fields are modified; others remain unchanged",
    'To remove an optional field, pass an empty value of its type ("" for strings, [] for lists, {} for dicts). Passing null or omitting the field leaves it unchanged',
    "Cannot change the glossary entry name",
    "Entry must exist in the project",
]

DELETE_CONSTRAINTS: list[str] = [
    "Deletion is permanent and cannot be undone",
    "May break references from other documentation",
    "Entry must exist in the project",
]

# =============================================================================
# Discover Tool Descriptions
# =============================================================================

DISCOVER_PURPOSE = "Discovery tool for glossary entries: returns a catalog of all available glossary entries"

DISCOVER_WHEN_TO_USE: list[str] = [
    "Before creating/updating glossary to check for existing entries",
    "To discover domain terminology and concepts",
    "To find glossary names for use with read_glossary resource template",
    "To check relationships between related terms",
]

DISCOVER_CONSTRAINTS: list[str] = [
    "Read-only tool",
    "Returns JSON catalog",
    "Project scope only",
]

# =============================================================================
# Resource Descriptions - Purpose & Content Summary
# =============================================================================

INDEX_PURPOSE = "Discovery resource for glossary entries"
INDEX_CONTENT_SUMMARY = "Catalog of all glossary entries with preview metadata including name, preamble, key terms, and relationships"

# Short description for onboarding
INDEX_SHORT_DESCRIPTION = "domain terminology and definitions"
READ_PURPOSE = "Context resource for glossary entries"
READ_CONTENT_SUMMARY = "Full glossary content in Markdown format including preamble, key terms, aliases, and relationships"

# =============================================================================
# Resource Descriptions - When To Use
# =============================================================================

INDEX_WHEN_TO_USE: list[str] = [
    "Before creating/updating glossary to check for existing entries",
    "To discover domain terminology and concepts",
    "To find glossary names for use with read_glossary resource template",
    "To check relationships between related terms",
]

READ_WHEN_TO_USE: list[str] = [
    "When you need to understand domain-specific terminology",
    "To review definitions and usage context",
    "To check aliases and relationships to other terms",
    "Before using technical terms to ensure proper usage",
]

# =============================================================================
# Resource Descriptions - Constraints
# =============================================================================

INDEX_CONSTRAINTS: list[str] = [
    "Read-only resource",
    "JSON format",
    "Project scope only",
]

READ_CONSTRAINTS: list[str] = [
    "Read-only resource",
    "Markdown format",
    "Project scope only",
    "Requires valid glossary name from index",
]
