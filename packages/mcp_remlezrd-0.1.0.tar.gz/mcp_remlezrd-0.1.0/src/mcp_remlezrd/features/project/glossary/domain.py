"""Domain models for ProjectGlossary feature."""

from typing import Any, Self

from pydantic import field_validator, model_validator
from sqlalchemy import Column
from sqlalchemy.dialects.sqlite import JSON
from sqlmodel import Field as SQLField

from mcp_remlezrd.features.shared.domain import (
    MarkdownList,
    MarkdownListItem,
    ResourceBase,
    SimpleMarkdownContent,
    SimpleMarkdownParagraphs,
)
from mcp_remlezrd.features.shared.md_sections import CodeBlock

from .content_strategy import (
    ProjectGlossaryData,
    render_project_glossary,
)


class ProjectGlossary(ResourceBase, table=True):
    """Glossary resource for PROJECT_CONTEXT domain.

    Represents term definitions and vocabulary management for common
    understanding. Contains terms defined and their aliases/synonyms.
    """

    # Override base fields with Glossary-specific defaults
    id: str = SQLField(primary_key=True, description="Glossary ID with pattern glossary_<name>")

    # Glossary-specific fields
    alias: list[str] = SQLField(
        default_factory=list,
        sa_column=Column("alias", JSON),
        description="Synonyms, acronyms, and abbreviations",
    )

    # Structured content fields (stored as JSON)
    preamble: SimpleMarkdownParagraphs = SQLField(
        sa_column=Column("preamble", JSON),
        description="Preamble paragraphs under H1 heading",
    )

    key_terms: dict[str, MarkdownListItem] = SQLField(
        sa_column=Column("key_terms", JSON),
        description="Key terms as dict: term -> definition",
    )

    usage_context: SimpleMarkdownContent | None = SQLField(
        default=None,
        description="Usage context section content",
    )

    examples: list[dict[str, str]] | None = SQLField(
        default=None,
        sa_column=Column("examples", JSON),
        description="Examples as list of CodeBlock dicts",
    )

    relations: MarkdownList | None = SQLField(
        default=None,
        sa_column=Column("relations", JSON),
        description="Relations as list of strings",
    )

    references: MarkdownList = SQLField(
        default_factory=list,
        sa_column=Column("references", JSON),
        description="References as list of strings",
    )

    @property
    def terms(self) -> list[str]:
        """Terms are derived from key_terms keys."""
        return list(self.key_terms.keys())

    @field_validator("alias")
    @classmethod
    def validate_alias(cls, v: list[str]) -> list[str]:
        """Validate alias is a list of non-empty strings."""
        if not isinstance(v, list):
            raise ValueError("Alias must be a list")

        validated_alias: list[str] = []
        for alias_item in v:
            if not isinstance(alias_item, str):
                raise ValueError("All alias items must be strings")
            alias_item = alias_item.strip()
            if alias_item:
                validated_alias.append(alias_item)

        return validated_alias

    @model_validator(mode="after")
    def validate_no_alias_in_terms(self) -> Self:
        """Validate that no alias is also a term (case-insensitive).

        Aliases should be distinct from primary terms to avoid ambiguity.
        """
        if not self.alias or not self.terms:
            return self

        terms_lower = {term.lower() for term in self.terms}

        for alias_item in self.alias:
            if alias_item.lower() in terms_lower:
                raise ValueError(f"Alias {alias_item!r} cannot also be a defined term")
        return self

    def to_frontmatter(self) -> dict[str, Any]:
        """Convert Glossary model fields to frontmatter dict (id is internal, not persisted)."""
        result: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "tags": self.tags,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "terms": self.terms,
            "alias": self.alias,
        }
        if self.extra_metadata:
            result["metadata"] = self.extra_metadata
        return result

    def update_metadata(
        self,
        tags: list[str] | None = None,
        description: str | None = None,
        alias: list[str] | None = None,
        extra_metadata: dict[str, Any] | None = None,
    ) -> None:
        """Update resource metadata fields.

        Content updates are handled by the service layer via ContentEngine.
        Note: terms are automatically derived from key_terms keys.
        """
        if tags is not None:
            self.tags = tags
        if description is not None:
            self.description = description
        if alias is not None:
            self.alias = alias
        if extra_metadata is not None:
            self.extra_metadata = extra_metadata

    def update_content(
        self,
        preamble: SimpleMarkdownParagraphs | None = None,
        key_terms: dict[str, MarkdownListItem] | None = None,
        usage_context: SimpleMarkdownContent | None = None,
        examples: list[dict[str, str]] | None = None,
        relations: MarkdownList | None = None,
        references: MarkdownList | None = None,
    ) -> None:
        """Update markdown body content fields.

        Only provided fields are modified. Others remain unchanged.
        Note: terms are automatically derived from key_terms keys.
        """
        if preamble is not None:
            self.preamble = preamble
        if key_terms is not None:
            self.key_terms = key_terms
        if usage_context is not None:
            self.usage_context = usage_context
        if examples is not None:
            self.examples = examples
        if relations is not None:
            self.relations = relations
        if references is not None:
            self.references = references

    def to_markdown(self) -> str:
        """Generate markdown content from structured fields."""
        # Convert examples from JSON dicts to CodeBlock objects
        usage_examples: list[CodeBlock] | None = None
        if self.examples:
            usage_examples = [CodeBlock.model_validate(ex) for ex in self.examples]

        data = ProjectGlossaryData(
            preamble=self.preamble,
            key_terms=self.key_terms,
            usage_context=self.usage_context,
            usage_examples=usage_examples,
            relations=self.relations,
            references=self.references,
        )
        return render_project_glossary(self.name, data)

    def __repr__(self) -> str:
        term_info = f", terms={len(self.terms)}" if self.terms else ""
        alias_info = f", aliases={len(self.alias)}" if self.alias else ""
        return f"<Glossary(id={self.id}, name={self.name!r}{term_info}{alias_info})>"
