"""Markdown sections specific to ProjectGlossary domain.

Provides BaseModel classes for parsing and rendering ProjectGlossary-specific sections.
"""

from contextlib import suppress
from typing import Self

from marko import block
from marko.block import Document
from pydantic import BaseModel, Field

from mcp_remlezrd.features.shared.domain import MarkdownList, MarkdownListItem
from mcp_remlezrd.features.shared.exceptions import SectionNotFoundError, SectionParsingError
from mcp_remlezrd.features.shared.markdown import get_heading_title, render_element_to_markdown
from mcp_remlezrd.features.shared.md_sections import CodeBlock, KeyValueSection, ListSection


class KeyTermsSection(BaseModel):
    """Section Key Terms (required)."""

    model_config = {"frozen": True}
    terms: dict[str, MarkdownListItem] = Field(..., min_length=1)

    @classmethod
    def from_doc(cls, doc: Document) -> Self:
        """Parse Key Terms section from document."""
        section = KeyValueSection.from_h2(doc, "Key Terms")
        if not section.items:
            raise SectionParsingError("Key Terms section is empty")
        return cls(terms=section.items)

    def render(self) -> str:
        """Render section as markdown."""
        return KeyValueSection(name="Key Terms", items=self.terms).render(level=2)


class UsageContextSection(BaseModel):
    """Section Usage Context with optional Examples H3 subsection."""

    model_config = {"frozen": True}
    context: str | None = None
    examples: list[CodeBlock] | None = None
    subsections: list[str] = Field(default_factory=list, description="H3 subsection names found")

    @classmethod
    def from_doc(cls, doc: Document) -> Self | None:
        """Parse Usage Context section from document."""
        from mcp_remlezrd.features.shared.markdown import iter_h2_section_elements

        # Check if section exists (has any content)
        try:
            next(iter_h2_section_elements(doc, "Usage Context"))
        except (SectionNotFoundError, StopIteration):
            return None

        context, subsections = cls._parse_context_content(doc)
        examples = cls._parse_examples(doc) if "Examples" in subsections else []

        return cls(
            context=context if context else None,
            examples=examples if examples else None,
            subsections=subsections,
        )

    @staticmethod
    def _parse_context_content(doc: Document) -> tuple[str, list[str]]:
        """Parse text content from Usage Context section and collect H3 subsections.

        Returns:
            Tuple of (context_text, list_of_h3_subsection_names)
        """
        from mcp_remlezrd.features.shared.markdown import iter_h2_section_elements

        parts: list[str] = []
        subsections: list[str] = []
        examples_found = False

        for elem in iter_h2_section_elements(doc, "Usage Context"):
            match elem:
                case block.Heading(level=3):
                    subsection_title = get_heading_title(elem)
                    subsections.append(subsection_title)
                    if subsection_title == "Examples":
                        examples_found = True
                    # Continue collecting subsections after Examples too

                case block.Paragraph():
                    if not examples_found:
                        text = render_element_to_markdown(elem)
                        if text:
                            parts.append(text)

                case block.List():
                    if not examples_found:
                        for item in elem.children:
                            if isinstance(item, block.ListItem):
                                text = render_element_to_markdown(item)
                                if text:
                                    parts.append(text)

                case block.BlankLine():
                    pass

                case _:
                    # Skip other elements (fenced code is handled in Examples H3)
                    pass

        return "\n\n".join(parts) if parts else "", subsections

    @staticmethod
    def _parse_examples(doc: Document) -> list[CodeBlock]:
        """Parse Examples H3 subsection from Usage Context section."""
        from mcp_remlezrd.features.shared.markdown import iter_h3_section_elements_in_h2_section

        examples: list[CodeBlock] = []

        try:
            for elem in iter_h3_section_elements_in_h2_section(doc, "Usage Context", "Examples"):
                match elem:
                    case block.FencedCode():
                        code_block = CodeBlock.from_fenced_code(elem)
                        if code_block:
                            examples.append(code_block)

                    case block.BlankLine():
                        pass

                    case _:
                        raise SectionParsingError(f"Examples subsection can only contain fenced code blocks, found: {type(elem).__name__}")
        except SectionNotFoundError:
            pass  # Examples subsection is optional

        return examples

    def render(self) -> str:
        """Render section as markdown."""
        if not self.context and not self.examples:
            return ""

        lines = ["## Usage Context"]

        if self.context:
            lines.extend(["", self.context])

        if self.examples:
            lines.extend(["", "### Examples"])
            for example in self.examples:
                lines.extend(["", example.render()])

        return "\n".join(lines)


class RelationsSection(BaseModel):
    """Section Relations (optional)."""

    model_config = {"frozen": True}
    items: MarkdownList | None = None

    @classmethod
    def from_doc(cls, doc: Document) -> Self | None:
        """Parse Relations section from document."""
        with suppress(SectionNotFoundError):
            section = ListSection.from_h2(doc, "Relations")
            return cls(items=section.items)
        return None

    def render(self) -> str:
        """Render section as markdown."""
        if not self.items:
            return ""
        return ListSection(name="Relations", items=self.items).render(level=2)
