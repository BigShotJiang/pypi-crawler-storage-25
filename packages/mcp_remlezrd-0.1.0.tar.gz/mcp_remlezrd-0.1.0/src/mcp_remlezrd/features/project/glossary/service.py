"""Project Glossary service."""

from datetime import UTC, datetime
import logging
from pathlib import Path
from typing import Any

from sqlalchemy import or_
from sqlmodel import select

from mcp_remlezrd.features.shared.services import BaseResourcesService, ResourceIDGenerator
from mcp_remlezrd.features.shared.services_utils import build_tags_filter_condition

from .content_strategy import parse_project_glossary
from .domain import ProjectGlossary
from .meta import META
from .output_schemas import GlossaryCreateResult, GlossaryDeleteResult, GlossaryDiscoverEntry, GlossaryDiscoverResult, GlossaryUpdateResult

logger = logging.getLogger(__name__)


class ProjectGlossaryService(BaseResourcesService):
    """Service for Glossary management."""

    _id_prefix = META.resource_type
    _model_class = ProjectGlossary
    _upsert_fields = [
        "name",
        "description",
        "tags",
        "updated_at",
        "alias",
        "extra_metadata",
        "preamble",
        "key_terms",
        "usage_context",
        "examples",
        "relations",
        "references",
    ]

    def search(
        self,
        name_filter: str | None = None,
        tags: list[str] | None = None,
    ) -> list[ProjectGlossary]:
        """List glossaries with optional filtering.

        Args:
            name_filter: Optional substring to filter by name (case-insensitive)
            tags: Optional list of tags to filter by

        Returns:
            List of ProjectGlossary domain objects
        """
        try:
            query = select(ProjectGlossary)

            # Filter by tags using SQL JSON if provided
            if tags:
                tag_conditions = build_tags_filter_condition(tags)
                query = query.where(or_(*tag_conditions))

            glossaries = list(self.session.exec(query).all())

            # Filter by name substring (case-insensitive) if provided
            if name_filter:
                filter_lower = name_filter.lower()
                glossaries = [g for g in glossaries if filter_lower in g.name.lower()]

            logger.debug(
                f"Listing {len(glossaries)} glossaries",
                extra={
                    "event.name": "glossary.list",
                    "event.domain": "glossary",
                    "glossaries.count": len(glossaries),
                },
            )

            return glossaries

        except Exception as e:
            logger.error(
                f"Failed to list glossaries: {e}",
                extra={
                    "event.name": "glossary.list",
                    "event.domain": "glossary",
                    "event.outcome": "failure",
                    "error.message": str(e),
                },
            )
            raise

    # save_resource inherited from BaseResourcesService uses resource.to_markdown()

    def discover(self) -> GlossaryDiscoverResult:
        """Discovery tool: catalog of all available glossary entries."""
        try:
            logger.debug("Discovering glossaries")
            glossaries = self.search()

            entries = [
                GlossaryDiscoverEntry(
                    name=glossary.name,
                    description=glossary.description,
                    terms=glossary.terms,
                    alias=glossary.alias,
                    tags=glossary.tags,
                    estimated_tokens=glossary.estimated_tokens,
                    uri=f"{META.base_uri}{glossary.name}",
                )
                for glossary in glossaries
            ]

            return GlossaryDiscoverResult(glossaries=entries)

        except Exception as e:
            logger.error(f"Failed to discover glossaries: {e}")
            raise

    def load_from_file(self, file_path: Path) -> ProjectGlossary:
        """Load and validate a ProjectGlossary from a markdown file.

        Args:
            file_path: Path to the markdown file to load.

        Returns:
            The loaded and validated ProjectGlossary entity.

        Raises:
            ValidationError: If the file content is invalid.
            PermissionError: If the path is not allowed.
        """
        # Parse the file using file manager
        frontmatter, raw_content = self.md_file_manager.parse_file(file_path)

        # Parse markdown content using marko
        data = parse_project_glossary(raw_content)

        # Generate semantic ID
        is_shared = self._is_shared_path(file_path)
        name = frontmatter.get("name", file_path.stem)
        resource_id = ResourceIDGenerator.generate(self._id_prefix, name, is_shared)

        # Parse timestamps
        created_at = datetime.now(UTC)
        updated_at = datetime.now(UTC)
        if "created_at" in frontmatter:
            created_at = datetime.fromisoformat(frontmatter["created_at"])
        if "updated_at" in frontmatter:
            updated_at = datetime.fromisoformat(frontmatter["updated_at"])

        # Build ProjectGlossary instance with structured fields
        # Note: terms is a property derived from key_terms keys
        glossary = ProjectGlossary(
            id=resource_id,
            path=str(file_path),
            name=name,
            description=frontmatter.get("description", ""),
            tags=frontmatter.get("tags", []),
            extra_metadata=frontmatter.get("metadata"),
            alias=frontmatter.get("alias", []),
            preamble=data.preamble,
            key_terms=data.key_terms,
            usage_context=data.usage_context,
            examples=[ex.model_dump() for ex in data.usage_examples] if data.usage_examples else None,
            relations=data.relations,
            references=data.references,
            created_at=created_at,
            updated_at=updated_at,
        )

        return glossary

    def get_as_dict(self, name: str) -> dict[str, Any]:
        """Get a single Glossary by name.

        Args:
            name: The Glossary name (kebab-case)

        Returns:
            Dictionary with Glossary data

        Raises:
            ValueError: If Glossary not found
        """
        try:
            glossary = self.session.exec(select(ProjectGlossary).where(ProjectGlossary.name == name)).first()
            if not glossary:
                raise ValueError(f"Glossary not found: {name}")

            return {
                "name": glossary.name,
                "description": glossary.description,
                "terms": getattr(glossary, "terms", []),
                "alias": getattr(glossary, "alias", []),
                "tags": glossary.tags,
                "created_at": glossary.created_at.isoformat(),
                "updated_at": glossary.updated_at.isoformat(),
            }

        except Exception as e:
            logger.error(
                f"Failed to get glossary '{name}': {e}",
                extra={
                    "event.name": "glossary.get",
                    "event.domain": "glossary",
                    "event.outcome": "failure",
                    "glossary.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def render(self, name: str) -> str:
        """Individual resource: Get specific glossary content in Markdown format."""
        try:
            logger.debug(f"Retrieving glossary: {name}")

            # Lookup by name
            glossary = self.session.exec(select(ProjectGlossary).where(ProjectGlossary.name == name)).first()
            if not glossary:
                raise ValueError(f"Glossary not found: {name}")

            # Delegate to domain for full content rendering
            return glossary.to_markdown()

        except Exception as e:
            logger.error(f"Failed to retrieve glossary {name}: {e}")
            raise

    def create(
        self,
        name: str,
        description: str,
        preamble: list[str],
        key_terms: dict[str, str],
        alias: list[str] | None = None,
        tags: list[str] | None = None,
        usage_context: str | None = None,
        examples: list[dict[str, str]] | None = None,  # [{"lang": ..., "content": ...}]
        relations: list[str] | None = None,
        references: list[str] | None = None,
        extra_metadata: dict[str, Any] | None = None,
    ) -> GlossaryCreateResult:
        """Create a new glossary and save to file and database.

        Args:
            name: Resource name (kebab-case)
            description: Brief description
            preamble: Introductory paragraphs under H1 (required)
            key_terms: Dict of term -> definition. Keys define the terms list (required)
            alias: List of synonyms, acronyms, and abbreviations
            tags: Classification tags
            usage_context: Where these terms apply and how they're used together
            examples: List of concrete examples showing terms in use
            relations: List of essential relations to other terms
            references: List of links to external standards
            extra_metadata: Additional metadata

        Returns:
            GlossaryCreateResult with name and creation timestamp
        """
        self._check_rw()
        try:
            base_dir = self._project_res_path

            now = datetime.now(UTC)
            glossary = ProjectGlossary(
                id="",
                path=str(base_dir / f"{name}.md"),
                name=name,
                description=description,
                tags=tags or [],
                alias=alias or [],
                extra_metadata=extra_metadata,
                preamble=preamble,
                key_terms=key_terms,
                usage_context=usage_context or "",
                examples=examples,
                relations=relations,
                references=references or [],
                created_at=now,
                updated_at=now,
            )

            self.save_resource(glossary)

            logger.info(
                f"Created glossary: {glossary.id} - {name}",
                extra={
                    "event.name": "glossary.create",
                    "event.domain": "glossary",
                    "event.outcome": "success",
                    "glossary.id": glossary.id,
                    "glossary.name": name,
                },
            )
            return GlossaryCreateResult(
                name=glossary.name, created_at=glossary.created_at.isoformat(), estimated_tokens=glossary.estimated_tokens
            )

        except Exception as e:
            logger.error(
                f"Failed to create glossary '{name}': {e}",
                extra={
                    "event.name": "glossary.create",
                    "event.domain": "glossary",
                    "event.outcome": "failure",
                    "glossary.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def update(
        self,
        name: str,
        preamble: list[str] | None = None,
        key_terms: dict[str, str] | None = None,
        usage_context: str | None = None,
        examples: list[dict[str, str]] | None = None,  # [{"lang": ..., "content": ...}]
        relations: list[str] | None = None,
        references: list[str] | None = None,
        tags: list[str] | None = None,
        description: str | None = None,
        alias: list[str] | None = None,
        extra_metadata: dict[str, Any] | None = None,
    ) -> GlossaryUpdateResult:
        """Update glossary metadata and/or content sections.

        Args:
            name: The Glossary name (kebab-case)
            preamble: Introductory paragraphs under H1
            key_terms: Dict of term -> definition (updates both content and terms field)
            usage_context: Where these terms apply
            examples: List of concrete examples
            relations: List of essential relations
            references: List of links to external standards
            tags: Classification tags
            description: Brief description
            alias: List of synonyms, acronyms, and abbreviations
            extra_metadata: Additional metadata

        Only provided fields are modified. Others remain unchanged.
        Note: When key_terms is provided, terms are automatically derived from its keys.

        Returns:
            GlossaryUpdateResult with name and update timestamp
        """
        self._check_rw()
        try:
            glossary = self._get_from_project(name)
            if not glossary:
                raise ValueError(f"Glossary not found: {name}")

            glossary.update_metadata(tags=tags, description=description, alias=alias, extra_metadata=extra_metadata)

            glossary.update_content(
                preamble=preamble,
                key_terms=key_terms,
                usage_context=usage_context,
                examples=examples,
                relations=relations,
                references=references,
            )

            self.save_resource(glossary)

            logger.info(
                f"Updated glossary: {glossary.id}",
                extra={
                    "event.name": "glossary.update",
                    "event.domain": "glossary",
                    "event.outcome": "success",
                    "glossary.id": glossary.id,
                },
            )
            return GlossaryUpdateResult(
                name=glossary.name, updated_at=glossary.updated_at.isoformat(), estimated_tokens=glossary.estimated_tokens
            )

        except Exception as e:
            logger.error(
                f"Failed to update glossary '{name}': {e}",
                extra={
                    "event.name": "glossary.update",
                    "event.domain": "glossary",
                    "event.outcome": "failure",
                    "glossary.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def delete(self, name: str) -> GlossaryDeleteResult:
        """Delete Glossary by name.

        Args:
            name: Glossary name (kebab-case)

        Returns:
            GlossaryDeleteResult with name and deletion timestamp

        Raises:
            ValueError: If glossary not found
        """
        self._check_rw()
        logger.debug(f"Deleting glossary: {name}")

        if self._delete_resource_by_name(name):
            logger.info(
                f"Deleted Glossary: {name}",
                extra={
                    "event.name": "glossary.delete",
                    "event.domain": "glossary",
                    "event.outcome": "success",
                    "glossary.name": name,
                },
            )
            return GlossaryDeleteResult(name=name, deleted_at=datetime.now(UTC).isoformat())
        else:
            raise ValueError(f"Glossary not found: {name}")
