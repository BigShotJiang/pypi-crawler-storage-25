"""Output schemas for ADR operations.

These Pydantic models define the structure of responses from ADR operations,
used by both the service layer and MCP tools.
"""

from pydantic import BaseModel, Field


class AdrCreateResult(BaseModel):
    """Result of ADR creation operation."""

    name: str = Field(description="ADR name (kebab-case prefixed with sequential number")
    created_at: str = Field(description="Creation timestamp (ISO 8601)")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")


class AdrUpdateResult(BaseModel):
    """Result of ADR update operation."""

    name: str = Field(description="ADR name")
    updated_at: str = Field(description="Last update timestamp (ISO 8601)")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")


class AdrDeleteResult(BaseModel):
    """Result of ADR deletion operation."""

    name: str = Field(description="deleted ADR name")
    deleted_at: str = Field(description="Deletion timestamp (ISO 8601)")


class AdrDiscoverEntry(BaseModel):
    """Single entry in the ADR discovery catalog."""

    name: str = Field(description="ADR name (kebab-case prefixed with sequential number)")
    description: str = Field(description="Brief description")
    decision_chosen_option: str = Field(description="Name of the chosen option")
    tags: list[str] | None = Field(default=None, exclude_if=lambda v: v is None, description="Classification tags")
    is_superseded: bool = Field(description="Whether this ADR has been superseded")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")
    uri: str = Field(description="Resource URI for reading this ADR")
    superseded_by: list[str] | None = Field(
        default=None, exclude_if=lambda v: v is None, description="List of ADR names that supersede this ADR"
    )
    superseding: list[str] | None = Field(default=None, exclude_if=lambda v: v is None, description="List of ADR names this ADR supersedes")


class AdrDiscoverResult(BaseModel):
    """Result of ADR discovery operation."""

    adrs: list[AdrDiscoverEntry] = Field(description="Catalog of available ADRs")
