"""Project ADR Service."""

from datetime import UTC, datetime
import logging
from pathlib import Path
from typing import Any

from sqlalchemy import or_
from sqlmodel import select

from mcp_remlezrd.features.shared.services import BaseResourcesService, ResourceIDGenerator
from mcp_remlezrd.features.shared.services_utils import build_tags_filter_condition

from .content_strategy import parse_project_adr
from .domain import ProjectAdr
from .meta import META
from .output_schemas import AdrCreateResult, AdrDeleteResult, AdrDiscoverEntry, AdrDiscoverResult, AdrUpdateResult
from .service_utils import build_superseded_filter_condition

logger = logging.getLogger(__name__)


class ProjectAdrService(BaseResourcesService):
    """Service for ADR management.

    Extends BaseResourcesService with explicit path injection.
    ADR is not shareable, so it extends BaseResourcesService directly.
    """

    _id_prefix = META.resource_type
    _model_class = ProjectAdr
    _upsert_fields = [
        "name",
        "description",
        "tags",
        "updated_at",
        "superseding",
        "superseded_by",
        "extra_metadata",
        "context_and_problem_statement",
        "decision_drivers",
        "considered_options",
        "decision_chosen_option",
        "decision_justification",
        "positive_consequences",
        "negative_consequences",
        "rejected_options",
        "references",
    ]

    def _generate_path(self, name: str, base_dir: Path) -> tuple[str, str]:
        """Generate sequential ADR path in base_dir.

        Scans existing ``.md`` files to determine the next sequential number.

        Returns:
            Tuple of ``(prefixed_name, full_path)``.
        """
        existing_files = list(base_dir.glob("*.md"))
        max_num = 0
        for f in existing_files:
            prefix = f.stem.split("-")[0]
            if prefix.isdigit():
                max_num = max(max_num, int(prefix))
        next_num = max_num + 1
        prefixed_name = f"{next_num:03d}-{name}"
        return prefixed_name, str(base_dir / f"{prefixed_name}.md")

    # save_resource inherited from BaseResourcesService uses resource.to_markdown()

    def search(
        self,
        name_filter: str | None = None,
        tags: list[str] | None = None,
        include_superseded: bool = False,
    ) -> list[ProjectAdr]:
        """List ADRs with optional filtering.

        Args:
            name_filter: Optional substring to filter by name (case-insensitive)
            tags: Optional list of tags to filter by.
            include_superseded: If True, include superseded ADRs in results. Defaults to False.

        Returns:
            List of ProjectAdr domain objects
        """
        try:
            query = select(ProjectAdr)

            # Filter by superseded status using SQL JSON
            superseded_condition = build_superseded_filter_condition(include_superseded)
            if superseded_condition is not None:
                query = query.where(superseded_condition)

            # Filter by tags using SQL JSON if provided
            if tags:
                tag_conditions = build_tags_filter_condition(tags)
                query = query.where(or_(*tag_conditions))

            adrs = list(self.session.exec(query).all())

            # Filter by name substring (case-insensitive) if provided
            if name_filter:
                filter_lower = name_filter.lower()
                adrs = [a for a in adrs if filter_lower in a.name.lower()]

            logger.debug(
                f"Listing {len(adrs)} ADRs",
                extra={
                    "event.name": "adr.list",
                    "event.domain": "adr",
                    "adrs.count": len(adrs),
                },
            )

            return adrs

        except Exception as e:
            logger.error(
                f"Failed to list ADRs: {e}",
                extra={
                    "event.name": "adr.list",
                    "event.domain": "adr",
                    "event.outcome": "failure",
                    "error.message": str(e),
                },
            )
            raise

    def discover(self, include_superseded: bool = False) -> AdrDiscoverResult:
        """Discovery tool: catalog of all available ADRs."""
        try:
            logger.debug("Discovering ADRs")
            adrs = self.search(include_superseded=include_superseded)

            entries = [
                AdrDiscoverEntry(
                    name=adr.name,
                    description=adr.description,
                    decision_chosen_option=adr.decision_chosen_option,
                    tags=adr.tags,
                    is_superseded=bool(adr.superseded_by),
                    estimated_tokens=adr.estimated_tokens,
                    uri=f"{META.base_uri}{adr.name}",
                    superseded_by=adr.superseded_by,
                    superseding=adr.superseding,
                )
                for adr in adrs
            ]

            return AdrDiscoverResult(adrs=entries)

        except Exception as e:
            logger.error(f"Failed to discover ADRs: {e}")
            raise

    def load_from_file(self, file_path: Path) -> ProjectAdr:
        """Load and validate a ProjectAdr from a markdown file.

        Args:
            file_path: Path to the markdown file to load.

        Returns:
            The loaded and validated ProjectAdr entity.

        Raises:
            ValidationError: If the file content is invalid.
            PermissionError: If the path is not allowed.
        """
        # Parse file
        frontmatter_data, raw_content = self.md_file_manager.parse_file(file_path)

        # Parse sections using marko
        parsed = parse_project_adr(raw_content)

        # Generate semantic ID
        name = frontmatter_data.get("name", file_path.stem)
        is_shared = self._is_shared_path(file_path)
        resource_id = ResourceIDGenerator.generate(self._id_prefix, name, is_shared)

        # Parse timestamps
        created_at = datetime.now(UTC)
        updated_at = datetime.now(UTC)
        if "created_at" in frontmatter_data:
            created_at = datetime.fromisoformat(frontmatter_data["created_at"])
        if "updated_at" in frontmatter_data:
            updated_at = datetime.fromisoformat(frontmatter_data["updated_at"])

        # Build ProjectAdr instance with structured fields
        adr = ProjectAdr(
            id=resource_id,
            path=str(file_path),
            name=name,
            description=frontmatter_data.get("description", ""),
            tags=frontmatter_data.get("tags", []),
            superseding=frontmatter_data.get("superseding", []),
            superseded_by=frontmatter_data.get("superseded_by", []),
            extra_metadata=frontmatter_data.get("metadata"),
            context_and_problem_statement=parsed.context_problem,
            decision_drivers=parsed.decision_drivers or [],
            considered_options=parsed.considered_options or [],
            decision_chosen_option=parsed.decision_outcome,
            decision_justification=parsed.decision_justification,
            positive_consequences=parsed.positive_consequences or [],
            negative_consequences=parsed.negative_consequences or [],
            rejected_options=({opt.name: opt.reasons for opt in parsed.rejected_options} if parsed.rejected_options else None),
            references=parsed.references,
            created_at=created_at,
            updated_at=updated_at,
        )

        return adr

    def get_as_dict(self, name: str) -> dict[str, Any]:
        """Get a single ADR by name.

        Args:
            name: The ADR name (e.g., '001-choose-database')

        Returns:
            Dictionary with ADR data

        Raises:
            ValueError: If ADR not found
        """
        try:
            adr = self.session.exec(select(ProjectAdr).where(ProjectAdr.name == name)).first()
            if not adr:
                raise ValueError(f"ADR not found: {name}")

            return {
                "name": adr.name,
                "description": adr.description,
                "superseding": adr.superseding if adr.superseding else [],
                "superseded_by": adr.superseded_by if adr.superseded_by else [],
                "tags": adr.tags,
                "created_at": adr.created_at.isoformat(),
                "updated_at": adr.updated_at.isoformat(),
            }

        except Exception as e:
            logger.error(
                f"Failed to get ADR '{name}': {e}",
                extra={
                    "event.name": "adr.get",
                    "event.domain": "adr",
                    "event.outcome": "failure",
                    "adr.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def render(self, name: str) -> str:
        """Individual resource: Get specific ADR content in Markdown format."""
        try:
            logger.debug(f"Retrieving ADR: {name}")

            # Lookup by name
            adr = self.session.exec(select(ProjectAdr).where(ProjectAdr.name == name)).first()
            if not adr:
                raise ValueError(f"ADR not found: {name}")

            # Delegate to domain for full content rendering
            return adr.to_markdown()

        except Exception as e:
            logger.error(f"Failed to retrieve ADR {name}: {e}")
            raise

    def create(
        self,
        name: str,
        description: str,
        context: str,
        decision_chosen_option: str,
        decision_justification: str,
        decision_drivers: list[str],
        considered_options: list[str],
        positive_consequences: list[str],
        negative_consequences: list[str],
        rejected_options: dict[str, list[str]] | None = None,
        references: list[str] | None = None,
        tags: list[str] | None = None,
        superseding: list[str] | None = None,
        extra_metadata: dict[str, Any] | None = None,
    ) -> AdrCreateResult:
        """Create a new ADR and save to file and database.

        Args:
            name: Base name for the ADR (will be prefixed with sequential number)
            description: Brief description
            context: Context and Problem Statement section content (required)
            decision_chosen_option: Name of the chosen option (required)
            decision_justification: Why this option was selected over the alternatives (required)
            decision_drivers: List of forces and concerns that influenced the decision (required)
            considered_options: List of alternatives evaluated (required)
            positive_consequences: List of benefits of the chosen option (required)
            negative_consequences: List of trade-offs and drawbacks of the chosen option (required)
            rejected_options: Dict mapping rejected option names to list of rejection reasons
            references: List of reference links
            tags: Classification tags
            superseding: List of ADR names this ADR supersedes
            extra_metadata: Additional metadata

        Returns:
            AdrCreateResult with name and creation timestamp
        """
        self._check_rw()
        try:
            base_dir = self._project_res_path
            prefixed_name, adr_path = self._generate_path(name, base_dir)
            now = datetime.now(UTC)
            adr = ProjectAdr(
                id="",
                path=adr_path,
                name=prefixed_name,
                description=description,
                tags=tags or [],
                context_and_problem_statement=context,
                decision_drivers=decision_drivers,
                considered_options=considered_options,
                decision_chosen_option=decision_chosen_option,
                decision_justification=decision_justification,
                positive_consequences=positive_consequences,
                negative_consequences=negative_consequences,
                rejected_options=rejected_options,
                references=references or [],
                superseding=superseding or [],
                superseded_by=[],
                extra_metadata=extra_metadata,
                created_at=now,
                updated_at=now,
            )

            self.save_resource(adr)

            # Sync bidirectional superseding relationships
            self._sync_superseding_on_create(adr)

            logger.info(
                f"Created ADR: {adr.id} - {prefixed_name} (chosen: {decision_chosen_option!r})",
                extra={
                    "event.name": "adr.create",
                    "event.domain": "adr",
                    "event.outcome": "success",
                    "adr.id": adr.id,
                    "adr.name": prefixed_name,
                },
            )
            return AdrCreateResult(name=adr.name, created_at=adr.created_at.isoformat(), estimated_tokens=adr.estimated_tokens)

        except Exception as e:
            logger.error(
                f"Failed to create ADR '{name}' (chosen: {decision_chosen_option!r}): {e}",
                extra={
                    "event.name": "adr.create",
                    "event.domain": "adr",
                    "event.outcome": "failure",
                    "adr.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def update(
        self,
        name: str,
        context_and_problem: str | None = None,
        decision_drivers: list[str] | None = None,
        considered_options: list[str] | None = None,
        decision_chosen_option: str | None = None,
        decision_justification: str | None = None,
        positive_consequences: list[str] | None = None,
        negative_consequences: list[str] | None = None,
        rejected_options: dict[str, list[str]] | None = None,
        references: list[str] | None = None,
        tags: list[str] | None = None,
        description: str | None = None,
        superseding: list[str] | None = None,
        superseded_by: list[str] | None = None,
        extra_metadata: dict[str, Any] | None = None,
    ) -> AdrUpdateResult:
        """Update ADR metadata and/or content sections.

        Args:
            name: The ADR name (e.g., '001-choose-database')
            context_and_problem: Context and Problem Statement section content
            decision_drivers: List of forces and concerns that influenced the decision
            considered_options: List of alternatives evaluated
            decision_chosen_option: Name of the chosen option
            decision_justification: Why this option was selected over the alternatives
            positive_consequences: List of benefits of the chosen option
            negative_consequences: List of trade-offs and drawbacks of the chosen option
            rejected_options: Dict mapping rejected option names to reasons
            references: List of reference links
            tags: Classification tags
            description: Brief description
            superseding: List of ADR names this ADR supersedes
            superseded_by: List of ADR names that supersede this ADR
            extra_metadata: Additional metadata

        Only provided fields are modified. Others remain unchanged.

        Returns:
            AdrUpdateResult with name and update timestamp
        """
        self._check_rw()
        try:
            adr = self._get_from_project(name)
            if not adr:
                raise ValueError(f"ADR not found: {name}")

            # Save old values for coherence sync
            old_superseding = list(adr.superseding) if adr.superseding else []
            old_superseded_by = list(adr.superseded_by) if adr.superseded_by else []

            adr.update_metadata(
                tags=tags,
                description=description,
                superseding=superseding,
                superseded_by=superseded_by,
                extra_metadata=extra_metadata,
            )

            adr.update_content(
                context_and_problem=context_and_problem,
                decision_drivers=decision_drivers,
                considered_options=considered_options,
                decision_chosen_option=decision_chosen_option,
                decision_justification=decision_justification,
                positive_consequences=positive_consequences,
                negative_consequences=negative_consequences,
                rejected_options=rejected_options,
                references=references,
            )

            self.save_resource(adr)

            # Sync bidirectional superseding relationships
            self._sync_superseding_on_update(adr, old_superseding, old_superseded_by)

            logger.info(
                f"Updated ADR: {adr.id}",
                extra={
                    "event.name": "adr.update",
                    "event.domain": "adr",
                    "event.outcome": "success",
                    "adr.id": adr.id,
                },
            )
            return AdrUpdateResult(name=adr.name, updated_at=adr.updated_at.isoformat(), estimated_tokens=adr.estimated_tokens)

        except Exception as e:
            logger.error(
                f"Failed to update ADR '{name}': {e}",
                extra={
                    "event.name": "adr.update",
                    "event.domain": "adr",
                    "event.outcome": "failure",
                    "adr.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def delete(self, name: str) -> AdrDeleteResult:
        """Delete ADR by name.

        Args:
            name: ADR name (e.g., '001-choose-database')

        Returns:
            AdrDeleteResult with name and deletion timestamp

        Raises:
            ValueError: If ADR not found
        """
        self._check_rw()
        logger.debug(f"Deleting ADR: {name}")

        # Get ADR data before deletion for coherence cleanup
        adr = self._get_from_project(name)
        if not adr:
            raise ValueError(f"ADR not found: {name}")

        old_superseding = list(adr.superseding) if adr.superseding else []
        old_superseded_by = list(adr.superseded_by) if adr.superseded_by else []

        if self._delete_resource_by_name(name):
            # Cleanup bidirectional references after successful deletion
            self._sync_superseding_on_delete(name, old_superseding, old_superseded_by)

            logger.info(
                f"Deleted ADR: {name}",
                extra={
                    "event.name": "adr.delete",
                    "event.domain": "adr",
                    "event.outcome": "success",
                    "adr.name": name,
                },
            )
            return AdrDeleteResult(name=name, deleted_at=datetime.now(UTC).isoformat())
        else:
            raise ValueError(f"ADR not found: {name}")

    # --- Superseding coherence management ---

    def _detect_changes(self, old: list[str], new: list[str]) -> tuple[set[str], set[str]]:
        """Detect added and removed items between two lists.

        Returns:
            Tuple of ``(added, removed)``.
        """
        old_set = set(old) if old else set()
        new_set = set(new) if new else set()
        added = new_set - old_set
        removed = old_set - new_set
        return added, removed

    def _add_to_superseded_by(self, target_name: str, source_name: str) -> None:
        """Add source_name to target's superseded_by list (idempotent)."""
        try:
            target = self._get_from_project(target_name)
            if target and source_name not in target.superseded_by:
                # Replace list to ensure SQLAlchemy detects the change
                target.superseded_by = target.superseded_by + [source_name]
                self.save_resource(target)
                logger.debug(
                    f"Updated {target_name}.superseded_by: added {source_name}",
                    extra={
                        "event.name": "adr.superseding.sync",
                        "event.domain": "adr",
                        "event.outcome": "success",
                        "adr.name": target_name,
                        "adr.superseded_by": source_name,
                    },
                )
        except Exception as e:
            logger.warning(
                f"Failed to update {target_name}.superseded_by: {e}",
                extra={
                    "event.name": "adr.superseding.sync",
                    "event.domain": "adr",
                    "event.outcome": "failure",
                    "adr.name": target_name,
                    "error.message": str(e),
                },
            )

    def _remove_from_superseded_by(self, target_name: str, source_name: str) -> None:
        """Remove source_name from target's superseded_by list."""
        try:
            target = self._get_from_project(target_name)
            if target and source_name in target.superseded_by:
                # Replace list to ensure SQLAlchemy detects the change
                target.superseded_by = [x for x in target.superseded_by if x != source_name]
                self.save_resource(target)
                logger.debug(
                    f"Updated {target_name}.superseded_by: removed {source_name}",
                    extra={
                        "event.name": "adr.superseding.sync",
                        "event.domain": "adr",
                        "event.outcome": "success",
                        "adr.name": target_name,
                    },
                )
        except Exception as e:
            logger.warning(
                f"Failed to update {target_name}.superseded_by: {e}",
                extra={
                    "event.name": "adr.superseding.sync",
                    "event.domain": "adr",
                    "event.outcome": "failure",
                    "error.message": str(e),
                },
            )

    def _add_to_superseding(self, target_name: str, source_name: str) -> None:
        """Add source_name to target's superseding list (idempotent)."""
        try:
            target = self._get_from_project(target_name)
            if target and source_name not in target.superseding:
                # Replace list to ensure SQLAlchemy detects the change
                target.superseding = target.superseding + [source_name]
                self.save_resource(target)
                logger.debug(
                    f"Updated {target_name}.superseding: added {source_name}",
                    extra={
                        "event.name": "adr.superseded_by.sync",
                        "event.domain": "adr",
                        "event.outcome": "success",
                        "adr.name": target_name,
                        "adr.superseding": source_name,
                    },
                )
        except Exception as e:
            logger.warning(
                f"Failed to update {target_name}.superseding: {e}",
                extra={
                    "event.name": "adr.superseded_by.sync",
                    "event.domain": "adr",
                    "event.outcome": "failure",
                    "error.message": str(e),
                },
            )

    def _remove_from_superseding(self, target_name: str, source_name: str) -> None:
        """Remove source_name from target's superseding list."""
        try:
            target = self._get_from_project(target_name)
            if target and source_name in target.superseding:
                # Replace list to ensure SQLAlchemy detects the change
                target.superseding = [x for x in target.superseding if x != source_name]
                self.save_resource(target)
                logger.debug(
                    f"Updated {target_name}.superseding: removed {source_name}",
                    extra={
                        "event.name": "adr.superseded_by.sync",
                        "event.domain": "adr",
                        "event.outcome": "success",
                        "adr.name": target_name,
                    },
                )
        except Exception as e:
            logger.warning(
                f"Failed to update {target_name}.superseding: {e}",
                extra={
                    "event.name": "adr.superseded_by.sync",
                    "event.domain": "adr",
                    "event.outcome": "failure",
                    "error.message": str(e),
                },
            )

    def _sync_superseding_on_create(self, adr: ProjectAdr) -> None:
        """Update target ADRs when a new ADR is created with superseding."""
        if not adr.superseding:
            return

        for target_name in adr.superseding:
            self._add_to_superseded_by(target_name, adr.name)

    def _sync_superseding_on_update(
        self,
        adr: ProjectAdr,
        old_superseding: list[str],
        old_superseded_by: list[str],
    ) -> None:
        """Synchronize bidirectional relationships after update.

        Args:
            adr: Updated ADR.
            old_superseding: Previous superseding list.
            old_superseded_by: Previous superseded_by list.
        """
        # Changes in superseding (this ADR supersedes others)
        added_superseding, removed_superseding = self._detect_changes(old_superseding, adr.superseding)

        for target_name in added_superseding:
            self._add_to_superseded_by(target_name, adr.name)

        for target_name in removed_superseding:
            self._remove_from_superseded_by(target_name, adr.name)

        # Changes in superseded_by (this ADR is superseded by others)
        added_superseded_by, removed_superseded_by = self._detect_changes(old_superseded_by, adr.superseded_by)

        for source_name in added_superseded_by:
            self._add_to_superseding(source_name, adr.name)

        for source_name in removed_superseded_by:
            self._remove_from_superseding(source_name, adr.name)

    def _sync_superseding_on_delete(
        self,
        adr_name: str,
        old_superseding: list[str],
        old_superseded_by: list[str],
    ) -> None:
        """Cleanup references to this ADR from other ADRs when deleted.

        Args:
            adr_name: Deleted ADR name.
            old_superseding: Previous superseding list.
            old_superseded_by: Previous superseded_by list.
        """
        # Cleanup references in superseding of other ADRs
        if old_superseded_by:
            for source_name in old_superseded_by:
                self._remove_from_superseding(source_name, adr_name)

        # Cleanup references in superseded_by of other ADRs
        if old_superseding:
            for target_name in old_superseding:
                self._remove_from_superseded_by(target_name, adr_name)
