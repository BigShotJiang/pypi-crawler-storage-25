"""Content strategy for ProjectAdr resources.

Uses marko for markdown parsing with section-based approach.
"""

import logging

from marko import Markdown
from pydantic import BaseModel, Field

from mcp_remlezrd.features.shared.domain import (
    MarkdownList,
    SimpleMarkdownContent,
    SimpleMarkdownParagraph,
)
from mcp_remlezrd.features.shared.markdown import (
    validate_no_unexpected_h2_sections,
    validate_no_unexpected_h3_sections_in_h2_section,
)
from mcp_remlezrd.features.shared.markdown.normalized_renderer import normalize_markdown
from mcp_remlezrd.features.shared.md_sections import ReferencesSection

from .md_sections import (
    ConsideredOptionsSection,
    ContextProblemSection,
    DecisionDriversSection,
    DecisionOutcomeSection,
    RejectedOption,
    RejectedOptionsSection,
)

logger = logging.getLogger(__name__)

REQUIRED_SECTIONS = {"Context and Problem Statement", "Decision Outcome"}
OPTIONAL_SECTIONS = {
    "Decision Drivers",
    "Considered Options",
    "Rejected Options",
    "References",
}
ALLOWED_SECTIONS = REQUIRED_SECTIONS | OPTIONAL_SECTIONS

# H3 subsections allowed within Decision Outcome
DECISION_OUTCOME_H3_SECTIONS = {
    "Positive Consequences",
    "Negative Consequences",
}


class ProjectAdrData(BaseModel):
    """Structured data for a ProjectAdr resource (content only)."""

    context_problem: SimpleMarkdownContent = Field(..., min_length=10)
    decision_outcome: str = Field(..., min_length=10)
    decision_justification: SimpleMarkdownParagraph | None = None
    positive_consequences: MarkdownList | None = None
    negative_consequences: MarkdownList | None = None
    decision_drivers: MarkdownList | None = None
    considered_options: MarkdownList | None = None
    rejected_options: list[RejectedOption] | None = None
    references: MarkdownList = Field(default_factory=list)


def parse_project_adr(content: str) -> ProjectAdrData:
    """Parse markdown content into structured ProjectAdr data.

    Note: The H1 title is ignored - name comes from frontmatter.

    Raises:
        SectionNotFoundError: If required sections are missing
        SectionParsingError: If sections are malformed
    """
    logger.debug(
        "Parsing ADR content",
        extra={
            "event.name": "content.parse",
            "event.domain": "adr",
        },
    )

    doc = Markdown().parse(normalize_markdown(content))

    # Validate no unexpected sections
    validate_no_unexpected_h2_sections(doc, ALLOWED_SECTIONS)

    # Validate Decision Outcome H3 subsections
    try:
        validate_no_unexpected_h3_sections_in_h2_section(doc, "Decision Outcome", DECISION_OUTCOME_H3_SECTIONS)
    except Exception as e:
        raise e

    # Parse required sections
    context_problem = ContextProblemSection.from_doc(doc)
    decision_outcome = DecisionOutcomeSection.from_doc(doc)

    # Parse optional sections
    decision_drivers = DecisionDriversSection.from_doc(doc)
    considered_options = ConsideredOptionsSection.from_doc(doc)
    rejected_options = RejectedOptionsSection.from_doc(doc)
    references = ReferencesSection.from_doc(doc)

    driver_count = len(decision_drivers.items) if decision_drivers and decision_drivers.items else 0
    logger.debug(
        "Parsed ADR content",
        extra={
            "event.name": "content.parse",
            "event.domain": "adr",
            "event.outcome": "success",
            "drivers.count": driver_count,
            "has.considered_options": considered_options is not None,
            "has.rejected_options": rejected_options is not None,
            "references.count": len(references.items),
        },
    )

    return ProjectAdrData(
        context_problem=context_problem.content,
        decision_outcome=decision_outcome.outcome,
        decision_justification=decision_outcome.justification,
        positive_consequences=decision_outcome.positive_consequences,
        negative_consequences=decision_outcome.negative_consequences,
        decision_drivers=decision_drivers.items if decision_drivers else None,
        considered_options=considered_options.items if considered_options else None,
        rejected_options=rejected_options.options if rejected_options else None,
        references=references.items,
    )


def render_project_adr(name: str, data: ProjectAdrData) -> str:
    """Render structured ProjectAdr data back to markdown.

    Args:
        name: Resource name (from frontmatter)
        data: Structured content data
    """
    lines = [f"# ProjectAdr '{name}'", ""]

    # Required sections
    lines.append(ContextProblemSection(content=data.context_problem).render())
    lines.append("")
    lines.append(
        DecisionOutcomeSection(
            outcome=data.decision_outcome,
            justification=data.decision_justification or "",
            positive_consequences=data.positive_consequences,
            negative_consequences=data.negative_consequences,
        ).render()
    )

    # Optional sections
    if data.decision_drivers:
        lines.append("")
        lines.append(DecisionDriversSection(items=data.decision_drivers).render())

    if data.considered_options:
        lines.append("")
        lines.append(ConsideredOptionsSection(items=data.considered_options).render())

    if data.rejected_options:
        lines.append("")
        lines.append(RejectedOptionsSection(options=data.rejected_options).render())

    if data.references:
        lines.append("")
        lines.append(ReferencesSection(items=data.references).render())

    return "\n".join(lines)
