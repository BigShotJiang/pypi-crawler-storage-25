"""Domain models for ProjectAdr feature."""

from typing import Any, Self

from pydantic import model_validator
from sqlalchemy import Column
from sqlalchemy.dialects.sqlite import JSON
from sqlmodel import Field as SQLField

from mcp_remlezrd.features.shared.domain import (
    MarkdownList,
    ResourceBase,
    SimpleMarkdownContent,
    SimpleMarkdownParagraph,
)

from .content_strategy import (
    ProjectAdrData,
    render_project_adr,
)
from .md_sections import RejectedOption


def _is_substring_match(target: str, options: list[str]) -> bool:
    """Check if target is a substring of any option, case-insensitively.

    Returns:
        Whether target matches any option.
    """
    target_lower = target.lower()
    return any(target_lower in opt.lower() for opt in options)


class ProjectAdr(ResourceBase, table=True):
    """Architectural Decision Record resource.

    ADRs have a simple lifecycle managed through relationships:
    - Default state: active (empty superseded_by list)
    - Superseded state: when superseded_by contains ADR ID(s)
    """

    # Override base fields with ADR-specific defaults
    id: str = SQLField(primary_key=True, description="ADR ID with pattern adr_<name>")

    # Structured content fields (stored as JSON for list fields)
    context_and_problem_statement: SimpleMarkdownContent = SQLField(
        description="Context and Problem Statement section content",
    )

    decision_drivers: MarkdownList = SQLField(
        default_factory=list,
        sa_column=Column("decision_drivers", JSON),
        description="List of forces and concerns that influenced the decision",
    )

    considered_options: MarkdownList = SQLField(
        default_factory=list,
        sa_column=Column("considered_options", JSON),
        description="List of alternatives evaluated",
    )

    decision_chosen_option: str = SQLField(
        description="Name of the chosen option",
    )

    decision_justification: SimpleMarkdownParagraph | None = SQLField(
        default=None,
        description="Why this option was selected over the alternatives",
    )

    positive_consequences: MarkdownList = SQLField(
        default_factory=list,
        sa_column=Column("positive_consequences", JSON),
        description="List of benefits of the chosen option",
    )

    negative_consequences: MarkdownList = SQLField(
        default_factory=list,
        sa_column=Column("negative_consequences", JSON),
        description="List of trade-offs and drawbacks of the chosen option",
    )

    rejected_options: dict[str, MarkdownList] | None = SQLField(
        default=None,
        sa_column=Column("rejected_options", JSON),
        description="Dict mapping rejected option names to list of rejection reasons",
    )

    references: MarkdownList = SQLField(
        default_factory=list,
        sa_column=Column("references", JSON),
        description="List of reference links",
    )

    # ADR-specific relationship fields (using names, not IDs, for stability)
    superseding: list[str] = SQLField(
        default_factory=list,
        sa_column=Column("superseding", JSON),
        description="List of ADR names that this ADR supersedes (e.g., ['001-old-adr'])",
    )
    superseded_by: list[str] = SQLField(
        default_factory=list,
        sa_column=Column("superseded_by", JSON),
        description="List of ADR names that supersede this ADR (empty = active)",
    )

    def is_superseded(self) -> bool:
        """Check if this ADR is superseded by another ADR."""
        return len(self.superseded_by) > 0

    def is_superseding_others(self) -> bool:
        """Check if this ADR supersedes any other ADRs."""
        return len(self.superseding) > 0

    def to_frontmatter(self) -> dict[str, Any]:
        """Convert ADR model fields to frontmatter dict (id is internal, not persisted)."""
        result: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "tags": self.tags,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "superseding": self.superseding,
            "superseded_by": self.superseded_by,
        }
        if self.extra_metadata:
            result["metadata"] = self.extra_metadata
        return result

    def update_metadata(
        self,
        tags: list[str] | None = None,
        description: str | None = None,
        superseding: list[str] | None = None,
        superseded_by: list[str] | None = None,
        extra_metadata: dict[str, Any] | None = None,
    ) -> None:
        """Update resource metadata fields.

        Content updates are handled by the service layer via ContentEngine.
        """
        if tags is not None:
            self.tags = tags
        if description is not None:
            self.description = description
        if superseding is not None:
            self.superseding = superseding
        if superseded_by is not None:
            self.superseded_by = superseded_by
        if extra_metadata is not None:
            self.extra_metadata = extra_metadata

    def update_content(
        self,
        context_and_problem: SimpleMarkdownContent | None = None,
        decision_drivers: MarkdownList | None = None,
        considered_options: MarkdownList | None = None,
        decision_chosen_option: str | None = None,
        decision_justification: SimpleMarkdownParagraph | None = None,
        positive_consequences: MarkdownList | None = None,
        negative_consequences: MarkdownList | None = None,
        rejected_options: dict[str, MarkdownList] | None = None,
        references: MarkdownList | None = None,
    ) -> None:
        """Update markdown body content fields.

        Only provided fields are modified. Others remain unchanged.
        """
        if context_and_problem is not None:
            self.context_and_problem_statement = context_and_problem
        if decision_drivers is not None:
            self.decision_drivers = decision_drivers
        if considered_options is not None:
            self.considered_options = considered_options
        if decision_chosen_option is not None:
            self.decision_chosen_option = decision_chosen_option
        if decision_justification is not None:
            self.decision_justification = decision_justification
        if positive_consequences is not None:
            self.positive_consequences = positive_consequences
        if negative_consequences is not None:
            self.negative_consequences = negative_consequences
        if rejected_options is not None:
            self.rejected_options = rejected_options
        if references is not None:
            self.references = references

    def to_markdown(self) -> str:
        """Generate markdown content from structured fields."""
        data = ProjectAdrData(
            context_problem=self.context_and_problem_statement,
            decision_outcome=self.decision_chosen_option,
            decision_justification=self.decision_justification,
            positive_consequences=self.positive_consequences or None,
            negative_consequences=self.negative_consequences or None,
            decision_drivers=self.decision_drivers or None,
            considered_options=self.considered_options or None,
            rejected_options=[RejectedOption(name=opt_name, reasons=reasons) for opt_name, reasons in self.rejected_options.items()]
            if self.rejected_options
            else None,
            references=self.references,
        )
        return render_project_adr(self.name, data)

    @model_validator(mode="after")
    def validate_no_duplicate_considered_options(self) -> Self:
        """Validate that considered_options has no duplicates (case-insensitive).

        Duplicates are detected by exact string match after lowercasing.
        """
        if not self.considered_options:
            return self

        seen: set[str] = set()
        for opt in self.considered_options:
            opt_lower = opt.lower()
            if opt_lower in seen:
                raise ValueError(f"Duplicate option in considered_options: {opt!r}")
            seen.add(opt_lower)
        return self

    @model_validator(mode="after")
    def validate_chosen_in_considered(self) -> Self:
        """Validate that chosen option is in considered_options (substring match).

        Only validates if considered_options is not empty.
        The chosen option must be a substring of at least one considered option
        (case-insensitive).
        """
        if not self.considered_options:
            return self

        if not _is_substring_match(self.decision_chosen_option, self.considered_options):
            raise ValueError(
                f"Chosen option {self.decision_chosen_option!r} must be a substring "
                f"of at least one considered option: {self.considered_options!r}"
            )
        return self

    @model_validator(mode="after")
    def validate_rejected_in_considered(self) -> Self:
        """Validate that rejected options are in considered_options (substring match).

        Fails if considered_options is empty or if any rejected option is not
        a substring of any considered option (case-insensitive).
        """
        if not self.rejected_options:
            return self

        if not self.considered_options:
            raise ValueError("Cannot have rejected_options without considered_options")

        for rejected_name in self.rejected_options:
            if not _is_substring_match(rejected_name, self.considered_options):
                raise ValueError(
                    f"Rejected option {rejected_name!r} must be a substring of at least one considered option: {self.considered_options!r}"
                )
        return self

    @model_validator(mode="after")
    def validate_superseding_order(self) -> Self:
        r"""Validate that superseding ADRs have lexicographically smaller names.

        This prevents cycles by ensuring ADRs can only supersede earlier ADRs.
        Example: \"003-XXX\" can supersede [\"001-XXX\", \"002-XXX\"] but not [\"004-XXX\"].
        """
        if not self.superseding:
            return self

        for target_name in self.superseding:
            if target_name >= self.name:
                raise ValueError(f"Cannot supersede '{target_name}' (must be < '{self.name}')")
        return self

    @model_validator(mode="after")
    def validate_superseded_by_order(self) -> Self:
        r"""Validate that superseded-by ADRs have lexicographically larger names.

        This prevents cycles by ensuring ADRs can only be superseded by later ADRs.
        Example: \"003-XXX\" can be superseded by [\"004-XXX\", \"005-XXX\"] but not [\"002-XXX\"].
        """
        if not self.superseded_by:
            return self

        for source_name in self.superseded_by:
            if source_name <= self.name:
                raise ValueError(f"Cannot be superseded by '{source_name}' (must be > '{self.name}')")
        return self

    def __repr__(self) -> str:
        superseding_info = f", superseding={len(self.superseding)}" if self.superseding else ""
        superseded_info = ", superseded" if self.is_superseded() else ""
        return f"<ADR(id={self.id}, name={self.name!r}{superseding_info}{superseded_info})>"
