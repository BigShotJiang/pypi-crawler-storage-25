"""Utility functions for ADR service.

Standalone functions specific to ADR operations.
"""

from sqlalchemy import text


def build_superseded_filter_condition(include_superseded: bool):
    """Build SQL JSON filter condition for superseded status.

    Uses SQLite json_array_length() to check if superseded_by array is empty.

    Args:
        include_superseded: If True, returns condition that includes all ADRs.
                           If False, returns condition that excludes superseded ADRs.

    Returns:
        SQL text condition for use with query.where(), or None if no filter needed.

    Example:
        query = select(ProjectAdr)
        if not include_superseded:
            condition = build_superseded_filter_condition(False)
            query = query.where(condition)
    """
    if include_superseded:
        # Include all ADRs (no filter needed)
        return None
    # Filter for active ADRs only (empty superseded_by array)
    # json_array_length returns 0 for empty arrays
    return text("json_array_length(superseded_by) = 0")
