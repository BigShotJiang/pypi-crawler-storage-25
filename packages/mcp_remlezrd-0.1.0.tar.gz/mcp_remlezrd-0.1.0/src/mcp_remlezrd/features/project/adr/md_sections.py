"""Markdown sections specific to ProjectAdr domain.

Provides BaseModel classes for parsing and rendering ProjectAdr-specific sections.
"""

from contextlib import suppress
from typing import Self

from marko import block
from marko.block import Document
from pydantic import BaseModel, Field

from mcp_remlezrd.features.shared.domain import MarkdownList, SimpleMarkdownContent, SimpleMarkdownParagraph
from mcp_remlezrd.features.shared.exceptions import SectionNotFoundError, SectionParsingError
from mcp_remlezrd.features.shared.markdown import (
    iter_h2_section_elements,
    iter_h3_section_names_in_h2_section,
    render_element_to_markdown,
)
from mcp_remlezrd.features.shared.md_sections import ListSection, RawSection


class ContextProblemSection(BaseModel):
    """Section Context and Problem Statement (required)."""

    model_config = {"frozen": True}
    content: SimpleMarkdownContent = Field(..., min_length=10)

    @classmethod
    def from_doc(cls, doc: Document) -> Self:
        """Parse Context and Problem Statement section from document."""
        section = RawSection.from_h2(doc, "Context and Problem Statement")
        if not section.content:
            raise SectionParsingError("Context and Problem Statement section is empty")
        return cls(content=section.content)

    def render(self) -> str:
        """Render section as markdown."""
        return RawSection.from_content_str(name="Context and Problem Statement", content=self.content).render(level=2)


class DecisionOutcomeSection(BaseModel):
    """Section Decision Outcome (required) with optional H3 subsections."""

    model_config = {"frozen": True}
    outcome: str = Field(..., min_length=1)
    justification: SimpleMarkdownParagraph = Field(..., min_length=1)
    positive_consequences: MarkdownList | None = None
    negative_consequences: MarkdownList | None = None

    @classmethod
    def from_doc(cls, doc: Document) -> Self:
        """Parse Decision Outcome section from document."""
        # Verify section exists first
        try:
            next(iter_h2_section_elements(doc, "Decision Outcome"))
        except StopIteration as e:
            raise SectionNotFoundError("Section 'Decision Outcome' not found") from e

        # Parse preamble paragraphs
        decision_outcome, decision_justification = cls._parse_preamble(doc)

        # Parse optional H3 subsections
        positive: list[str] | None = None
        negative: list[str] | None = None

        with suppress(SectionNotFoundError):
            section = ListSection.from_h3(doc, "Decision Outcome", "Positive Consequences", strict=False)
            positive = section.items or None

        with suppress(SectionNotFoundError):
            section = ListSection.from_h3(doc, "Decision Outcome", "Negative Consequences", strict=False)
            negative = section.items or None

        return cls(
            outcome=decision_outcome,
            justification=decision_justification,
            positive_consequences=positive,
            negative_consequences=negative,
        )

    @staticmethod
    def _parse_preamble(doc: Document) -> tuple[str, str]:
        """Parse required preamble paragraphs from Decision Outcome section."""
        decision_outcome: str | None = None
        decision_justification: str | None = None

        for elem in iter_h2_section_elements(doc, "Decision Outcome"):
            # Stop at first H3 - preamble ends there
            if isinstance(elem, block.Heading) and elem.level == 3:
                break

            if isinstance(elem, block.Paragraph):
                para_rendered = render_element_to_markdown(elem)

                if para_rendered.startswith("Chosen option:"):
                    decision_outcome = para_rendered[len("Chosen option:") :].strip()
                elif para_rendered.startswith("Justification:"):
                    decision_justification = para_rendered[len("Justification:") :].strip()
                else:
                    raise SectionParsingError(
                        f"Decision Outcome paragraphs must start with 'Chosen option:' or 'Justification:', got: {para_rendered[:50]}"
                    )

        if not decision_outcome:
            raise SectionParsingError("Decision Outcome must contain 'Chosen option:' paragraph")

        if not decision_justification:
            raise SectionParsingError("Decision Outcome must contain 'Justification:' paragraph")

        return decision_outcome, decision_justification

    def render(self) -> str:
        """Render section as markdown."""
        lines = [
            "## Decision Outcome",
            "",
            f"Chosen option: {self.outcome}",
            "",
            f"Justification: {self.justification}",
        ]

        if self.positive_consequences:
            lines.extend(["", ListSection(name="Positive Consequences", items=self.positive_consequences).render(level=3)])

        if self.negative_consequences:
            lines.extend(["", ListSection(name="Negative Consequences", items=self.negative_consequences).render(level=3)])

        return "\n".join(lines)


class DecisionDriversSection(BaseModel):
    """Section Decision Drivers (optional)."""

    model_config = {"frozen": True}
    items: MarkdownList | None = None

    @classmethod
    def from_doc(cls, doc: Document) -> Self | None:
        """Parse Decision Drivers section from document."""
        with suppress(SectionNotFoundError):
            section = ListSection.from_h2(doc, "Decision Drivers")
            return cls(items=section.items)
        return None

    def render(self) -> str:
        """Render section as markdown."""
        if not self.items:
            return ""
        return ListSection(name="Decision Drivers", items=self.items).render(level=2)


class ConsideredOptionsSection(BaseModel):
    """Section Considered Options (optional)."""

    model_config = {"frozen": True}
    items: MarkdownList | None = None

    @classmethod
    def from_doc(cls, doc: Document) -> Self | None:
        """Parse Considered Options section from document."""
        with suppress(SectionNotFoundError):
            section = ListSection.from_h2(doc, "Considered Options")
            return cls(items=section.items)
        return None

    def render(self) -> str:
        """Render section as markdown."""
        if not self.items:
            return ""
        return ListSection(name="Considered Options", items=self.items).render(level=2)


class RejectedOption(BaseModel):
    """A single rejected option with reasons (H3 subsection)."""

    model_config = {"frozen": True}
    name: str = Field(..., min_length=1)
    reasons: MarkdownList = Field(..., min_length=1)

    @classmethod
    def from_h3(cls, doc: Document, parent_h2: str, name: str) -> Self:
        """Parse rejected option from H3 subsection.

        Args:
            doc: Parsed marko document
            parent_h2: Parent H2 section name ("Rejected Options")
            name: H3 subsection name (option name)

        Returns:
            RejectedOption with name and reasons
        """
        section = ListSection.from_h3(doc, parent_h2, name)
        return cls(name=name, reasons=section.items)

    def render(self) -> str:
        """Render option as markdown."""
        lines = [f"### {self.name}"]
        for reason in self.reasons:
            lines.append(f"- {reason}")
        lines.append("")
        return "\n".join(lines)


class RejectedOptionsSection(BaseModel):
    """Section Rejected Options (optional) with H3 subsections."""

    model_config = {"frozen": True}
    options: list[RejectedOption] | None = None

    @classmethod
    def from_doc(cls, doc: Document) -> Self | None:
        """Parse Rejected Options section from document."""
        # Check if section exists
        try:
            section_elements = list(iter_h2_section_elements(doc, "Rejected Options"))
        except SectionNotFoundError:
            return None

        # Check for H3 subsections
        h3_names = list(iter_h3_section_names_in_h2_section(doc, "Rejected Options"))
        if not h3_names:
            if section_elements:
                # Section exists but has no H3 - invalid format
                raise SectionParsingError("Rejected Options section must contain H3 subsections for each option")
            return None

        options: list[RejectedOption] = []
        for name in h3_names:
            option = RejectedOption.from_h3(doc, "Rejected Options", name)
            options.append(option)

        return cls(options=options)

    def render(self) -> str:
        """Render section as markdown."""
        if not self.options:
            return ""

        lines = ["## Rejected Options", ""]
        for option in self.options:
            lines.append(option.render())
        return "\n".join(lines)
