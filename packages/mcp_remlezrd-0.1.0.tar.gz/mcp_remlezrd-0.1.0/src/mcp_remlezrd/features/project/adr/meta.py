"""ADR resource metadata."""

from mcp_remlezrd.features.shared.app_meta import APP
from mcp_remlezrd.features.shared.meta_types import ResourceMeta

META = ResourceMeta(
    pretty_name="ArchitecturalDecisionRecord",
    resource_type="adr",
    pretty_plural="Architectural Decision Records",
    short_plural="adrs",
    tag="res:adr",
    create_tool="create_adr",
    update_tool="update_adr",
    delete_tool="delete_adr",
    discover_tool="discover_adrs_only",
    base_uri=f"{APP.server_name}://adr/",
    shared_base_uri="",
    resource_component="read_adr",
    shared_resource_component="",
)
