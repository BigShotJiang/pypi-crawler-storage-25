"""Canonical identifiers and descriptions for ADR resources and tools."""

# =============================================================================
# Tool Descriptions - Purpose
# =============================================================================

CREATE_PURPOSE = "Create a new Architectural Decision Record (ADR) to document significant technical decisions"
UPDATE_PURPOSE = "Update an existing ADR by modifying only the provided fields"
DELETE_PURPOSE = "Delete an Architectural Decision Record by name"

# =============================================================================
# Tool Descriptions - When To Use
# =============================================================================

CREATE_WHEN_TO_USE: list[str] = [
    "Use when making significant technical or architectural decisions",
    "Use for documenting technology choices and their rationale",
    "Use when multiple alternatives were considered before deciding",
    "Do NOT use for trivial decisions with no long-term impact",
]

UPDATE_WHEN_TO_USE: list[str] = [
    "Use for correcting errors in existing ADRs",
    "Use for updating consequences as they become apparent",
    "Use for adding references or related decisions",
    "Do NOT use to fundamentally change a decision: create a new ADR instead",
]

DELETE_WHEN_TO_USE: list[str] = [
    "Use for removing mistakenly created ADRs",
    "Use when an ADR was created in error",
    "Prefer marking as superseded over deletion for obsolete decisions",
    "Do NOT delete ADRs that have been referenced or discussed",
]

# =============================================================================
# Tool Descriptions - Constraints
# =============================================================================

CREATE_CONSTRAINTS: list[str] = [
    "Project scope only: ADRs cannot be created in shared scope",
    "Names are prefixed with sequential numbers automatically",
    "Consider linking related ADRs via superseding relationships",
]

UPDATE_CONSTRAINTS: list[str] = [
    "Only provided fields are modified; others remain unchanged",
    'To remove an optional field, pass an empty value of its type ("" for strings, [] for lists, {} for dicts). Passing null or omitting the field leaves it unchanged',
    "Cannot change ADR number or creation date",
    "Consider marking as superseded rather than updating significantly",
]

DELETE_CONSTRAINTS: list[str] = [
    "Deletion is permanent and cannot be undone",
    "May break links from other ADRs or documentation",
    "Consider the historical record before deleting",
]

# =============================================================================
# Discover Tool Descriptions
# =============================================================================

DISCOVER_PURPOSE = "Discovery tool for ADRs: returns a catalog of all available architectural decision records"

DISCOVER_WHEN_TO_USE: list[str] = [
    "Before creating/updating ADRs to check for existing entries",
    "To discover architectural decisions and their rationale",
    "To find ADR names for use with read_adr resource template",
    "To check superseding/superseded relationships between ADRs",
]

DISCOVER_CONSTRAINTS: list[str] = [
    "Read-only tool",
    "Returns JSON catalog",
    "Project scope only",
]

# =============================================================================
# Resource Descriptions - Purpose & Content Summary
# =============================================================================

INDEX_PURPOSE = "Discovery resource for Architectural Decision Records"
INDEX_CONTENT_SUMMARY = "Catalog of all ADRs with preview metadata including name, description, status, and relationships"

# Short description for onboarding
INDEX_SHORT_DESCRIPTION = "architectural decisions and rationale"
READ_PURPOSE = "Context resource for Architectural Decision Records"
READ_CONTENT_SUMMARY = "Full ADR content in Markdown format including context, decision, consequences, and relationships"

# =============================================================================
# Resource Descriptions - When To Use
# =============================================================================

INDEX_WHEN_TO_USE: list[str] = [
    "Before creating/updating ADRs to check for existing entries",
    "To discover architectural decisions and their rationale",
    "To find ADR names for use with read_adr resource template",
    "To check superseding/superseded relationships between ADRs",
]

READ_WHEN_TO_USE: list[str] = [
    "When you need to understand the rationale behind a decision",
    "To review considered alternatives and why they were rejected",
    "To check if an ADR supersedes or is superseded by another",
    "Before proposing changes that might impact past decisions",
]

# =============================================================================
# Resource Descriptions - Constraints
# =============================================================================

INDEX_CONSTRAINTS: list[str] = [
    "Read-only resource",
    "JSON format",
    "Project scope only",
]

READ_CONSTRAINTS: list[str] = [
    "Read-only resource",
    "Markdown format",
    "Project scope only",
    "Requires valid ADR name from index",
]
