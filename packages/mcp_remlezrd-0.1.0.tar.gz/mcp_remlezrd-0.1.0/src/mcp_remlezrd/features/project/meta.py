"""Project scope metadata."""

from mcp_remlezrd.features.shared.meta_types import ScopeMeta

PROJECT = ScopeMeta(
    pretty_name="Project",
    scope_type="project",
    tag="scope:project",
)
