"""Canonical identifiers and descriptions for Onboarding tool and prompt."""


# =============================================================================
# Tool names
# =============================================================================

DISCOVER_STANDARDS_TOOL_NAME = "discover_standards"
# =============================================================================
# Tool Descriptions - discover_standards
# =============================================================================

DISCOVER_STANDARDS_PURPOSE = "Initialize RemLezrd context by aggregating available resource indexes"

DISCOVER_STANDARDS_WHEN_TO_USE: list[str] = [
    "MANDATORY: Call at the start of every session to discover available resources",
    "Before any work to ensure you have full project context",
]

# Note: First constraint is dynamic (includes domain list)
DISCOVER_STANDARDS_CONSTRAINTS_SUFFIX = "Use resource names from indexes to read specific resources"

# discover_standards tool: prefix for the constraint that lists available domains
DISCOVER_STANDARDS_DOMAINS_CONSTRAINT_PREFIX = "Returns aggregated indexes from available domains:"
