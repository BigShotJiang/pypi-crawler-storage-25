"""Onboarding feature schemas."""

from typing import Self

from pydantic import BaseModel, model_validator


class DiscoverStandardsResult(BaseModel):
    """Result schema for discover_standards tool.

    Aggregates index data from all enabled domains.
    Validates that skills/rules and adrs/glossaries are consistent pairs.
    """

    skills: dict | None = None
    rules: dict | None = None
    adrs: dict | None = None
    glossaries: dict | None = None
    loaded_at: str

    @model_validator(mode="after")
    def validate_pairs(self) -> Self:
        """Ensure skills/rules and adrs/glossaries are consistent pairs."""
        # Validate skills <-> rules consistency
        if self.skills is not None and self.rules is None:
            raise ValueError("rules must be set if skills is set")
        if self.rules is not None and self.skills is None:
            raise ValueError("skills must be set if rules is set")

        # Validate adrs <-> glossaries consistency
        if self.adrs is not None and self.glossaries is None:
            raise ValueError("glossaries must be set if adrs is set")
        if self.glossaries is not None and self.adrs is None:
            raise ValueError("adrs must be set if glossaries is set")

        return self
