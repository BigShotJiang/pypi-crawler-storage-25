"""Onboarding scope metadata."""

from mcp_remlezrd.features.shared.meta_types import ScopeMeta

ONBOARDING = ScopeMeta(
    pretty_name="Onboarding",
    scope_type="onboarding",
    tag="scope:onboarding",
)
