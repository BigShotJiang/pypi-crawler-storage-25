from datetime import UTC, datetime
import logging
from pathlib import Path
from typing import Any

from sqlalchemy import or_
from sqlmodel import select

from mcp_remlezrd.features.shared.services import ResourceIDGenerator, ShareableResourcesService
from mcp_remlezrd.features.shared.services_utils import build_tags_filter_condition

from .content_strategy import parse_shareable_rule
from .domain import ShareableRule
from .meta import META
from .output_schemas import RuleCreateResult, RuleDeleteResult, RuleDiscoverEntry, RuleDiscoverResult, RuleUpdateResult

logger = logging.getLogger(__name__)


class ShareableRuleService(ShareableResourcesService):
    """Service for Shareable Rule management with shareable storage.

    Uses explicit path injection and factorized project-over-shared logic.
    """

    _id_prefix = META.resource_type
    _model_class = ShareableRule
    _upsert_fields = [
        "name",
        "description",
        "tags",
        "updated_at",
        "license",
        "compatibility",
        "extra_metadata",
        "purpose",
        "rules",
        "examples",
        "references",
    ]

    def search(
        self,
        name_filter: str | None = None,
        tags: list[str] | None = None,
        show_hidden: bool = False,
    ) -> list[ShareableRule]:
        """List rules with optional filtering.

        Args:
            name_filter: Optional substring to filter by name (case-insensitive)
            tags: Optional list of tags to filter by
            show_hidden: If True, include shared resources that are overridden by project resources.
                If False (default), hide overridden shared resources.

        Returns:
            List of ShareableRule domain objects
        """
        try:
            query = select(ShareableRule)

            # Filter by tags using SQL JSON if provided
            if tags:
                tag_conditions = build_tags_filter_condition(tags)
                query = query.where(or_(*tag_conditions))

            rules = list(self.session.exec(query).all())

            # Filter by name substring (case-insensitive) if provided
            if name_filter:
                filter_lower = name_filter.lower()
                rules = [r for r in rules if filter_lower in r.name.lower()]

            # Deduplicate: hide overridden shared resources unless show_hidden is True
            if not show_hidden:
                by_name: dict[str, ShareableRule] = {}
                for rule in rules:
                    existing = by_name.get(rule.name)
                    is_shared = self._is_shared_path(Path(rule.path))
                    if not existing:
                        by_name[rule.name] = rule
                    elif self._is_shared_path(Path(existing.path)) and not is_shared:
                        # Replace shared with project
                        by_name[rule.name] = rule
                rules = list(by_name.values())
            logger.debug(
                f"Listing {len(rules)} rules",
                extra={
                    "event.name": "rule.list",
                    "event.domain": "rule",
                    "rules.count": len(rules),
                },
            )

            return rules

        except Exception as e:
            logger.error(
                f"Failed to list rules: {e}",
                extra={
                    "event.name": "rule.list",
                    "event.domain": "rule",
                    "event.outcome": "failure",
                    "error.message": str(e),
                },
            )
            raise

    # save_resource inherited from BaseResourcesService uses resource.to_markdown()

    def discover(self) -> RuleDiscoverResult:
        """Discovery tool: catalog of all available rules."""
        try:
            logger.debug("Discovering rules")
            rules = self.search(show_hidden=False)

            entries = [
                RuleDiscoverEntry(
                    name=rule.name,
                    description=rule.description,
                    tags=rule.tags,
                    estimated_tokens=rule.estimated_tokens,
                    uri=f"{META.base_uri}{rule.name}",
                    compatibility=rule.compatibility,
                )
                for rule in rules
            ]

            return RuleDiscoverResult(rules=entries)

        except Exception as e:
            logger.error(f"Failed to discover rules: {e}")
            raise

    def load_from_file(self, file_path: Path) -> ShareableRule:
        """Load and validate an ShareableRule from a markdown file.

        Args:
            file_path: Path to the markdown file to load.

        Returns:
            The loaded and validated ShareableRule instance.

        Raises:
            ValidationError: If the file content is invalid.
            PermissionError: If the path is not allowed.
        """
        # Parse the file using file manager
        frontmatter, raw_content = self.md_file_manager.parse_file(file_path)

        # Parse markdown content using marko
        data = parse_shareable_rule(raw_content)
        purpose_content = data.purpose
        rules_dict = data.rules
        examples_content = data.examples
        references_list = data.references

        # Generate semantic ID
        is_shared = self._is_shared_path(file_path)
        name = frontmatter.get("name", file_path.stem)
        resource_id = ResourceIDGenerator.generate(self._id_prefix, name, is_shared)

        # Parse timestamps
        created_at = datetime.now(UTC)
        updated_at = datetime.now(UTC)
        if "created_at" in frontmatter:
            created_at = datetime.fromisoformat(frontmatter["created_at"])
        if "updated_at" in frontmatter:
            updated_at = datetime.fromisoformat(frontmatter["updated_at"])

        # Build ShareableRule instance with structured fields
        rule = ShareableRule(
            id=resource_id,
            path=str(file_path),
            name=name,
            description=frontmatter.get("description", ""),
            tags=frontmatter.get("tags", []),
            license=frontmatter.get("license"),
            compatibility=frontmatter.get("compatibility"),
            extra_metadata=frontmatter.get("metadata"),
            purpose=purpose_content,
            rules=rules_dict,
            examples=examples_content,
            references=references_list,
            created_at=created_at,
            updated_at=updated_at,
        )

        return rule

    def get_as_dict(self, name: str, force_shared: bool = False) -> dict[str, Any]:
        """Get a single Rule by name.

        Args:
            name: The Rule name (kebab-case)
            force_shared: If True, force access to shared resources only.
                If False (default), uses project-over-shared fallback:
                returns project resource if found, otherwise returns shared resource.
                Only use True if you explicitly need to access a shared resource
                that is being overridden by a project resource.

        Returns:
            Dictionary with Rule data

        Raises:
            ValueError: If Rule not found
        """
        try:
            rule = self._get_from_shared(name) if force_shared else self._get_from_project_or_shared(name)

            if not rule:
                raise ValueError(f"Rule not found: {name}")

            return {
                "name": rule.name,
                "description": rule.description,
                "tags": rule.tags,
                "created_at": rule.created_at.isoformat(),
                "updated_at": rule.updated_at.isoformat(),
            }

        except Exception as e:
            logger.error(
                f"Failed to get rule '{name}': {e}",
                extra={
                    "event.name": "rule.get",
                    "event.domain": "rule",
                    "event.outcome": "failure",
                    "rule.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def render(self, name: str, force_shared: bool = False) -> str:
        """Individual resource: Get specific rule content in Markdown format.

        Args:
            name: Rule name (kebab-case)
            force_shared: If True, force access to shared resources only.
                If False (default), uses project-over-shared fallback:
                returns project resource if found, otherwise returns shared resource.
                Only use True if you explicitly need to access a shared resource
                that is being overridden by a project resource.
        """
        try:
            logger.debug(f"Retrieving rule: {name}")

            rule = self._get_from_shared(name) if force_shared else self._get_from_project_or_shared(name)
            if not rule:
                raise ValueError(f"Rule not found: {name}")

            # Delegate to domain for full content rendering
            return rule.to_markdown()

        except Exception as e:
            logger.error(f"Failed to retrieve rule {name}: {e}")
            raise

    def create(
        self,
        name: str,
        description: str,
        purpose: str,
        rules: dict[str, list[str]],
        tags: list[str] | None = None,
        examples: str | None = None,
        references: list[str] | None = None,
        license: str | None = None,  # noqa: A002
        compatibility: str | None = None,
        extra_metadata: dict[str, Any] | None = None,
        shared: bool = False,
    ) -> RuleCreateResult:
        """Create a new rule and save to file and database.

        Args:
            name: Resource name (kebab-case)
            description: Brief description
            purpose: Purpose section content (required)
            rules: Rules organized by subsection (keys = H3 headers, values = rule lists) (required)
            tags: Classification tags
            examples: Examples section content
            references: List of reference items
            license: License name or reference
            compatibility: Environment requirements
            extra_metadata: Additional metadata
            shared: If True, create in shared directory; if False (default), create in project directory

        Returns:
            RuleCreateResult with name and creation timestamp
        """
        base_dir = self._get_target_path(shared=shared)
        self._check_rw_for_path(base_dir)
        try:
            now = datetime.now(UTC)
            rule = ShareableRule(
                id="",
                path=str(base_dir / f"{name}.md"),
                name=name,
                description=description,
                tags=tags or [],
                license=license,
                compatibility=compatibility,
                extra_metadata=extra_metadata,
                purpose=purpose,
                rules=rules,
                examples=examples,
                references=references or [],
                created_at=now,
                updated_at=now,
            )

            self.save_resource(rule)

            logger.info(
                f"Created rule: {rule.id} - {name}",
                extra={
                    "event.name": "rule.create",
                    "event.domain": "rule",
                    "event.outcome": "success",
                    "rule.id": rule.id,
                    "rule.name": name,
                },
            )
            return RuleCreateResult(name=rule.name, created_at=rule.created_at.isoformat(), estimated_tokens=rule.estimated_tokens)

        except Exception as e:
            logger.error(
                f"Failed to create rule '{name}': {e}",
                extra={
                    "event.name": "rule.create",
                    "event.domain": "rule",
                    "event.outcome": "failure",
                    "rule.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def update(
        self,
        name: str,
        purpose: str | None = None,
        rules: dict[str, list[str]] | None = None,
        examples: str | None = None,
        references: list[str] | None = None,
        tags: list[str] | None = None,
        description: str | None = None,
        license: str | None = None,  # noqa: A002
        compatibility: str | None = None,
        extra_metadata: dict[str, Any] | None = None,
        shared: bool = False,
    ) -> RuleUpdateResult:
        """Update rule metadata and/or content sections.

        Args:
            name: The Rule name (kebab-case)
            purpose: Purpose section content
            rules: Rules organized by subsection (keys = H3 headers, values = rule lists)
            examples: Examples section content
            references: List of reference items
            tags: Classification tags
            description: Brief description
            license: License name or reference
            compatibility: Environment requirements
            extra_metadata: Additional metadata
            shared: If True, update shared resource; if False (default), update project resource

        Only provided fields are modified. Others remain unchanged.

        Returns:
            RuleUpdateResult with name and update timestamp
        """
        try:
            rule = self._get_from_shared(name) if shared else self._get_from_project_or_shared(name)
            if not rule:
                raise ValueError(f"Rule not found: {name}")

            self._check_rw_for_path(Path(rule.path))

            rule.update_metadata(
                tags=tags, description=description, license=license, compatibility=compatibility, extra_metadata=extra_metadata
            )

            rule.update_content(
                purpose=purpose,
                rules=rules,
                examples=examples,
                references=references,
            )

            self.save_resource(rule)

            logger.info(
                f"Updated rule: {rule.id}",
                extra={
                    "event.name": "rule.update",
                    "event.domain": "rule",
                    "event.outcome": "success",
                    "rule.id": rule.id,
                },
            )
            return RuleUpdateResult(name=rule.name, updated_at=rule.updated_at.isoformat(), estimated_tokens=rule.estimated_tokens)

        except Exception as e:
            logger.error(
                f"Failed to update rule '{name}': {e}",
                extra={
                    "event.name": "rule.update",
                    "event.domain": "rule",
                    "event.outcome": "failure",
                    "rule.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def delete(self, name: str, force_shared: bool = False) -> RuleDeleteResult:
        """Delete Rule by name.

        Args:
            name: Rule name (kebab-case)
            force_shared: If True, delete from shared only; if False, delete from project

        Returns:
            RuleDeleteResult with name and deletion timestamp

        Raises:
            ValueError: If rule not found
        """
        logger.debug(f"Deleting rule: {name}")

        if self._delete_by_name(name, from_shared=force_shared):
            logger.info(
                f"Deleted Rule: {name}",
                extra={
                    "event.name": "rule.delete",
                    "event.domain": "rule",
                    "event.outcome": "success",
                    "rule.name": name,
                    "rule.force_shared": force_shared,
                },
            )
            return RuleDeleteResult(name=name, deleted_at=datetime.now(UTC).isoformat())
        else:
            raise ValueError(f"Rule not found: {name}")
