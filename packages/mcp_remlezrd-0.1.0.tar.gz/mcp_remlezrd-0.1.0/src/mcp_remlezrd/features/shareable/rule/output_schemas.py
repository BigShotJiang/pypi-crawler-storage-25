"""Output schemas for Shareable Rule operations.

These Pydantic models define the structure of responses from rule operations,
used by both the service layer and MCP tools.
"""

from pydantic import BaseModel, Field


class RuleCreateResult(BaseModel):
    """Result of rule creation operation."""

    name: str = Field(description="Rule name (kebab-case)")
    created_at: str = Field(description="Creation timestamp (ISO 8601)")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")


class RuleUpdateResult(BaseModel):
    """Result of rule update operation."""

    name: str = Field(description="Rule name")
    updated_at: str = Field(description="Last update timestamp (ISO 8601)")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")


class RuleDeleteResult(BaseModel):
    """Result of rule deletion operation."""

    name: str = Field(description="deleted Rule name")
    deleted_at: str = Field(description="Deletion timestamp (ISO 8601)")


class RuleDiscoverEntry(BaseModel):
    """Single entry in the rule discovery catalog."""

    name: str = Field(description="Rule name (kebab-case)")
    description: str = Field(description="Brief description")
    tags: list[str] | None = Field(default=None, exclude_if=lambda v: v is None, description="Classification tags")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")
    uri: str = Field(description="Resource URI for reading this rule")
    compatibility: str | None = Field(default=None, exclude_if=lambda v: v is None, description="Environment requirements")


class RuleDiscoverResult(BaseModel):
    """Result of rule discovery operation."""

    rules: list[RuleDiscoverEntry] = Field(description="Catalog of available rules")
