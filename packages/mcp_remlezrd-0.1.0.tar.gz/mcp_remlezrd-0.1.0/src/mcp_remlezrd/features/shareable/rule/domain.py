from typing import Any

from sqlalchemy import Column
from sqlalchemy.dialects.sqlite import JSON
from sqlmodel import Field as SQLField

from mcp_remlezrd.features.shared.domain import RichMarkdownContent, ShareableResourceBase, SimpleMarkdownParagraph

from .content_strategy import (
    ShareableRuleData,
    render_shareable_rule,
)


class ShareableRule(ShareableResourceBase, table=True):
    """Shareable Rule resource for AGENT_CONTEXT domain.

    Represents AI agent resources and tools enabling dynamic context feeding
    and autonomous behavior.
    """

    # Override base fields with ShareableRule-specific defaults
    id: str = SQLField(
        primary_key=True,
        description="Shareable Rule ID with pattern [+]rule_<name>",
    )

    # Structured content fields (stored as JSON)
    purpose: SimpleMarkdownParagraph = SQLField(
        description="Purpose section content",
    )

    rules: dict[str, list[str]] = SQLField(
        default_factory=dict,
        sa_column=Column("rules", JSON),
        description="Rules organized by subsection (keys = H3 headers, values = rule lists)",
    )

    examples: RichMarkdownContent | None = SQLField(
        default=None,
        description="Examples section content (free text)",
    )

    references: list[str] = SQLField(
        default_factory=list,
        sa_column=Column("references", JSON),
        description="List of reference items",
    )

    def to_frontmatter(self) -> dict[str, Any]:
        """Convert ShareableRule model fields to frontmatter dict (id is internal, not persisted)."""
        result: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "tags": self.tags,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }
        if self.license:
            result["license"] = self.license
        if self.compatibility:
            result["compatibility"] = self.compatibility
        if self.extra_metadata:
            result["metadata"] = self.extra_metadata
        return result

    def update_metadata(
        self,
        tags: list[str] | None = None,
        description: str | None = None,
        license: str | None = None,  # noqa: A002
        compatibility: str | None = None,
        extra_metadata: dict[str, Any] | None = None,
    ) -> None:
        """Update resource metadata fields.

        Content updates are handled by the service layer via ContentEngine.
        """
        if tags is not None:
            self.tags = tags
        if description is not None:
            self.description = description
        if license is not None:
            self.license = license
        if compatibility is not None:
            self.compatibility = compatibility
        if extra_metadata is not None:
            self.extra_metadata = extra_metadata

    def update_content(
        self,
        purpose: str | None = None,
        rules: dict[str, list[str]] | None = None,
        examples: str | None = None,
        references: list[str] | None = None,
    ) -> None:
        """Update markdown body content fields.

        Only provided fields are modified. Others remain unchanged.
        """
        if purpose is not None:
            self.purpose = purpose
        if rules is not None:
            self.rules = rules
        if examples is not None:
            self.examples = examples
        if references is not None:
            self.references = references

    # note: No @model_validator needed for ShareableRule.
    # @model_validator is used for complex cross-field validations (e.g., validating
    # relationships between multiple fields). ShareableRule fields are independent and
    # validated individually via @field_validator in ShareableResourceBase.

    def to_markdown(self) -> str:
        """Generate markdown content from structured fields."""
        data = ShareableRuleData(
            purpose=self.purpose,
            rules=self.rules,
            examples=self.examples,
            references=self.references,
        )
        return render_shareable_rule(self.name, data)

    def __repr__(self) -> str:
        return f"<ShareableRule(id={self.id}, name={self.name!r})>"
