"""Content strategy for ShareableRule resources.

Uses marko for markdown parsing with section-based approach.
"""

import logging

from marko import Markdown
from pydantic import BaseModel, Field

from mcp_remlezrd.features.shared.domain import MarkdownList, MarkdownListItem, RichMarkdownContent, SimpleMarkdownParagraph
from mcp_remlezrd.features.shared.exceptions import SectionParsingError
from mcp_remlezrd.features.shared.markdown import validate_no_unexpected_h2_sections
from mcp_remlezrd.features.shared.markdown.normalized_renderer import normalize_markdown
from mcp_remlezrd.features.shared.md_sections import ReferencesSection

from .md_sections import ExamplesSection, PurposeSection, RulesSection

logger = logging.getLogger(__name__)

REQUIRED_SECTIONS = {"Purpose", "Rules"}
OPTIONAL_SECTIONS = {"Examples", "References"}
ALLOWED_SECTIONS = REQUIRED_SECTIONS | OPTIONAL_SECTIONS


class ShareableRuleData(BaseModel):
    """Structured data for an ShareableRule resource (content only)."""

    purpose: SimpleMarkdownParagraph = Field(..., min_length=10)
    rules: dict[str, list[MarkdownListItem]] = Field(..., min_length=1)
    examples: RichMarkdownContent | None = None
    references: MarkdownList = Field(default_factory=list)


def parse_shareable_rule(content: str) -> ShareableRuleData:
    """Parse markdown content into structured ShareableRule data.

    Note: The H1 title is ignored - name comes from frontmatter.

    Raises:
        SectionNotFoundError: If required sections are missing
        SectionParsingError: If sections are malformed
    """
    logger.debug(
        "Parsing rule content",
        extra={
            "event.name": "content.parse",
            "event.domain": "rule",
        },
    )

    doc = Markdown().parse(normalize_markdown(content))

    # Validate no unexpected sections
    validate_no_unexpected_h2_sections(doc, ALLOWED_SECTIONS)

    # Parse required sections
    purpose = PurposeSection.from_doc(doc)
    rules = RulesSection.from_doc(doc)

    # Validate rules subsections are not empty
    for subsection, rules_list in rules.subsections.items():
        if not rules_list:
            raise SectionParsingError(f"Rules subsection '{subsection}' cannot be empty")

    # Parse optional sections
    examples = ExamplesSection.from_doc(doc)
    references = ReferencesSection.from_doc(doc)

    logger.debug(
        "Parsed rule content",
        extra={
            "event.name": "content.parse",
            "event.domain": "rule",
            "event.outcome": "success",
            "subsections.count": len(rules.subsections),
            "has.examples": examples is not None,
            "references.count": len(references.items),
        },
    )

    return ShareableRuleData(
        purpose=purpose.content,
        rules=rules.subsections,
        examples=examples.content if examples else None,
        references=references.items,
    )


def render_shareable_rule(name: str, data: ShareableRuleData) -> str:
    """Render structured ShareableRule data back to markdown.

    Args:
        name: Resource name (from frontmatter)
        data: Structured content data
    """
    lines = [f"# ShareableRule '{name}'", ""]

    # Required sections
    lines.append(PurposeSection(content=data.purpose).render())
    lines.append("")
    lines.append(RulesSection(subsections=data.rules).render())

    # Optional sections
    if data.examples:
        lines.append("")
        lines.append(ExamplesSection(content=data.examples).render())

    if data.references:
        lines.append("")
        lines.append(ReferencesSection(items=data.references).render())

    return "\n".join(lines)
