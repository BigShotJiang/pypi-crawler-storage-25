"""Rule resource metadata."""

from mcp_remlezrd.features.shared.app_meta import APP
from mcp_remlezrd.features.shared.meta_types import ResourceMeta

META = ResourceMeta(
    pretty_name="Rule",
    resource_type="rule",
    pretty_plural="Rules",
    short_plural="rules",
    tag="res:rule",
    create_tool="create_rule",
    update_tool="update_rule",
    delete_tool="delete_rule",
    discover_tool="discover_rules_only",
    base_uri=f"{APP.server_name}://rule/",
    shared_base_uri=f"{APP.server_name}://shared_rule/",
    resource_component="read_rule",
    shared_resource_component="read_shared_rule",
)
