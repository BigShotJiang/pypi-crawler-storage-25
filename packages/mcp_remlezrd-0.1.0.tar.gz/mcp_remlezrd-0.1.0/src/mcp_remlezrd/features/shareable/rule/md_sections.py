"""Markdown sections specific to ShareableRule domain.

Provides BaseModel classes for parsing and rendering ShareableRule-specific sections.
"""

from contextlib import suppress
from typing import Self

from marko.block import Document
from pydantic import BaseModel, Field

from mcp_remlezrd.features.shared.domain import MarkdownList, RichMarkdownContent, SimpleMarkdownParagraph
from mcp_remlezrd.features.shared.exceptions import SectionNotFoundError, SectionParsingError
from mcp_remlezrd.features.shared.markdown import iter_h3_section_names_in_h2_section
from mcp_remlezrd.features.shared.md_sections import ListSection, RawSection


class PurposeSection(BaseModel):
    """Section Purpose (required)."""

    model_config = {"frozen": True}
    content: SimpleMarkdownParagraph = Field(..., min_length=10)

    @classmethod
    def from_doc(cls, doc: Document) -> Self:
        """Parse Purpose section from document."""
        section = RawSection.from_h2(doc, "Purpose")
        if not section.content:
            raise SectionParsingError("Purpose section is empty")
        return cls(content=section.content)

    def render(self) -> str:
        """Render section as markdown."""
        return RawSection.from_content_str(name="Purpose", content=self.content).render(level=2)


class RulesSection(BaseModel):
    """Section Rules with optional H3 subsections.

    Supports two formats:
    1. H3 subsections: ### General, ### Specific, etc.
    2. Direct list: creates "General" subsection
    """

    model_config = {"frozen": True}
    subsections: dict[str, MarkdownList] = Field(..., min_length=1)

    @classmethod
    def from_doc(cls, doc: Document) -> Self:
        """Parse Rules section from document."""
        h3_names = list(iter_h3_section_names_in_h2_section(doc, "Rules"))

        if h3_names:
            # Case 1: H3 subsections
            subsections: dict[str, list[str]] = {}
            for h3_name in h3_names:
                with suppress(SectionNotFoundError):
                    section = ListSection.from_h3(doc, "Rules", h3_name)
                    subsections[h3_name] = section.items
        else:
            # Case 2: Direct list under H2
            section = ListSection.from_h2(doc, "Rules")
            subsections = {"General": section.items}

        if not subsections:
            raise SectionParsingError("Rules section is empty")

        return cls(subsections=subsections)

    def render(self) -> str:
        """Render section as markdown."""
        lines = ["## Rules", ""]
        for subsection, rules in self.subsections.items():
            lines.append(f"### {subsection}")
            lines.append("")
            for rule in rules:
                lines.append(f"- {rule}")
            lines.append("")
        return "\n".join(lines)


class ExamplesSection(BaseModel):
    """Section Examples (optional)."""

    model_config = {"frozen": True}
    content: RichMarkdownContent | None = None

    @classmethod
    def from_doc(cls, doc: Document) -> Self | None:
        """Parse Examples section from document."""
        with suppress(SectionNotFoundError):
            section = RawSection.from_h2(doc, "Examples")
            return cls(content=section.content)
        return None

    def render(self) -> str:
        """Render section as markdown."""
        if not self.content:
            return ""
        return RawSection.from_content_str(name="Examples", content=self.content).render(level=2)
