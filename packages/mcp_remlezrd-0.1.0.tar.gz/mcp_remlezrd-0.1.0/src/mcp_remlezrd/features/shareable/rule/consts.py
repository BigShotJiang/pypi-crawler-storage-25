"""Canonical identifiers and descriptions for Rule resources and tools."""


# =============================================================================
# Tool Descriptions - Purpose
# =============================================================================

CREATE_PURPOSE = "Create a new Rule for establishing coding standards and conventions"
UPDATE_PURPOSE = "Update an existing Rule by modifying only the provided fields"
DELETE_PURPOSE = "Delete a Rule by name"

# =============================================================================
# Tool Descriptions - When To Use
# =============================================================================

CREATE_WHEN_TO_USE: list[str] = [
    "Use when establishing project-wide coding standards or conventions",
    "Use for documenting architectural patterns and best practices",
    "Use for onboarding documentation that should persist across sessions",
    "Do NOT use for temporary or one-off instructions",
]

UPDATE_WHEN_TO_USE: list[str] = [
    "Use when evolving existing coding standards or conventions",
    "Use for adding new examples or references to existing rules",
    "Use for refining rule content based on feedback",
    "Do NOT use when you intend to replace the entire rule content",
]

DELETE_WHEN_TO_USE: list[str] = [
    "Use when a rule is no longer relevant or accurate",
    "Use for cleaning up obsolete coding standards",
    "Use when consolidating multiple rules into one",
    "Do NOT use lightly: prefer updating over deleting for minor changes",
]

# =============================================================================
# Tool Descriptions - Constraints
# =============================================================================

CREATE_CONSTRAINTS: list[str] = [
    "Project rules override shared rules with the same name",
]

UPDATE_CONSTRAINTS: list[str] = [
    "Only provided fields are modified; others remain unchanged",
    'To remove an optional field, pass an empty value of its type ("" for strings, [] for lists, {} for dicts). Passing null or omitting the field leaves it unchanged',
    "Cannot change a project rule to shared or vice versa",
    "Rule must exist in the specified scope",
]

DELETE_CONSTRAINTS: list[str] = [
    "Deletion is permanent and cannot be undone",
    "Deleting a shared rule does not affect project overrides",
    "Rule must exist in the specified scope",
]

# =============================================================================
# Discover Tool Descriptions
# =============================================================================

DISCOVER_PURPOSE = "Discovery tool for Rules: returns a catalog of all available rules"

DISCOVER_WHEN_TO_USE: list[str] = [
    "Before creating/updating rules to check for existing entries",
    "To discover available rules for reference in tools",
    "To find rule names for use with read_rule resource template",
]

DISCOVER_CONSTRAINTS: list[str] = [
    "Read-only tool",
    "Returns JSON catalog",
]

# =============================================================================
# Resource Descriptions - Purpose & Content Summary
# =============================================================================

INDEX_PURPOSE = "Discovery resource for Rules"
INDEX_CONTENT_SUMMARY = "Catalog of all Rules with preview metadata including name, description, tags, and scope"

# Short description for onboarding
INDEX_SHORT_DESCRIPTION = "coding standards and constraints"
READ_PURPOSE = "Context resource for Rules (Project-first resolution)"
READ_CONTENT_SUMMARY = "Full Rule content in Markdown format for context enrichment. Uses project-first resolution: returns project Rule if exists, otherwise returns shared Rule. This is the default resource to use for reading Rules."
READ_SHARED_PURPOSE = "Context resource for shared Rules (Shared-only, bypasses project overrides)"
READ_SHARED_CONTENT_SUMMARY = "Full shared Rule content in Markdown format. FORCE shared-only access: bypasses project overrides and returns the shared version even if a project Rule with the same name exists. Use with caution."

# =============================================================================
# Resource Descriptions - When To Use
# =============================================================================

INDEX_WHEN_TO_USE: list[str] = [
    "Before creating/updating rules to check for existing entries",
    "To discover available rules for reference in tools",
    "To find rule names for use with read_rule resource template",
]

READ_WHEN_TO_USE: list[str] = [
    "When you need to inject complete rule content into context",
    "To understand specific coding standards or conventions",
    "Before suggesting changes to existing rules",
    "Default choice: always use this unless you specifically need the shared-only version",
]

READ_SHARED_WHEN_TO_USE: list[str] = [
    "ONLY when you need to inspect a shared rule that is masked by a project override",
    "To compare drift between project rule and shared rule with same name",
    "For maintenance: debugging rule inheritance or migration issues",
    "AVOID in normal workflows: use read_rule instead for standard access",
]

# =============================================================================
# Resource Descriptions - Constraints
# =============================================================================

INDEX_CONSTRAINTS: list[str] = [
    "Read-only resource",
    "JSON format",
]

READ_CONSTRAINTS: list[str] = [
    "Read-only resource",
    "Markdown format",
    "Requires valid rule name from index",
    "Project rules override shared rules with same name",
]

READ_SHARED_CONSTRAINTS: list[str] = [
    "Read-only resource",
    "Markdown format",
    "FORCE shared-only: ignores project overrides",
    "Requires valid rule name from index",
]
