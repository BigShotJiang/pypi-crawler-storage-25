"""Shareable scope metadata."""

from mcp_remlezrd.features.shared.meta_types import ScopeMeta

SHAREABLE = ScopeMeta(
    pretty_name="Shareable",
    scope_type="shareable",
    tag="scope:shareable",
)
