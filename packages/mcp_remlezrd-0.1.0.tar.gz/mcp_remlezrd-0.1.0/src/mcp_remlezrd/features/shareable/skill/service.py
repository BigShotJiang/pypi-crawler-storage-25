from datetime import UTC, datetime
import logging
from pathlib import Path
from typing import Any

from sqlalchemy import or_
from sqlmodel import select

from mcp_remlezrd.features.shared.services import ResourceIDGenerator, ShareableResourcesService
from mcp_remlezrd.features.shared.services_utils import build_tags_filter_condition

from .content_strategy import parse_shareable_skill
from .domain import ShareableSkill
from .meta import META
from .output_schemas import SkillCreateResult, SkillDeleteResult, SkillDiscoverEntry, SkillDiscoverResult, SkillUpdateResult

logger = logging.getLogger(__name__)


class ShareableSkillService(ShareableResourcesService):
    """Service for Shareable Skill management with shareable storage."""

    _id_prefix = META.resource_type
    _model_class = ShareableSkill
    _upsert_fields = [
        "name",
        "description",
        "tags",
        "updated_at",
        "license",
        "compatibility",
        "extra_metadata",
        "purpose",
        "when_to_use",
        "instructions",
        "examples",
        "common_edge_cases",
        "references",
    ]

    def search(
        self,
        name_filter: str | None = None,
        tags: list[str] | None = None,
        show_hidden: bool = False,
    ) -> list[ShareableSkill]:
        """List skills with optional filtering.

        Args:
            name_filter: Optional substring to filter by name (case-insensitive)
            tags: Optional list of tags to filter by
            show_hidden: If True, include shared resources that are overridden by project resources.
                If False (default), hide overridden shared resources.

        Returns:
            List of ShareableSkill domain objects
        """
        try:
            query = select(ShareableSkill)

            if tags:
                tag_conditions = build_tags_filter_condition(tags)
                query = query.where(or_(*tag_conditions))

            skills = list(self.session.exec(query).all())

            # Filter by name substring (case-insensitive) if provided
            if name_filter:
                filter_lower = name_filter.lower()
                skills = [s for s in skills if filter_lower in s.name.lower()]

            # Deduplicate: hide overridden shared resources unless show_hidden is True
            if not show_hidden:
                by_name: dict[str, ShareableSkill] = {}
                for skill in skills:
                    existing = by_name.get(skill.name)
                    is_shared = self._is_shared_path(Path(skill.path))
                    if not existing:
                        by_name[skill.name] = skill
                    elif self._is_shared_path(Path(existing.path)) and not is_shared:
                        # Replace shared with project
                        by_name[skill.name] = skill
                skills = list(by_name.values())
            logger.debug(
                f"Listing {len(skills)} skills",
                extra={
                    "event.name": "skill.list",
                    "event.domain": "skill",
                    "skills.count": len(skills),
                },
            )

            return skills

        except Exception as e:
            logger.error(
                f"Failed to list skills: {e}",
                extra={
                    "event.name": "skill.list",
                    "event.domain": "skill",
                    "event.outcome": "failure",
                    "error.message": str(e),
                },
            )
            raise

    # save_resource inherited from BaseResourcesService uses resource.to_markdown()

    def discover(self) -> SkillDiscoverResult:
        """Discovery tool: catalog of all available skills."""
        try:
            logger.debug("Discovering skills")
            skills = self.search(show_hidden=False)

            entries = [
                SkillDiscoverEntry(
                    name=skill.name,
                    description=skill.description,
                    when_to_use=skill.when_to_use,
                    tags=skill.tags,
                    estimated_tokens=skill.estimated_tokens,
                    uri=f"{META.base_uri}{skill.name}",
                    compatibility=skill.compatibility,
                )
                for skill in skills
            ]

            return SkillDiscoverResult(skills=entries)

        except Exception as e:
            logger.error(f"Failed to discover skills: {e}")
            raise

    def load_from_file(self, file_path: Path) -> ShareableSkill:
        """Load and validate an ShareableSkill from a markdown file.

        Args:
            file_path: Path to the markdown file to load.

        Returns:
            The loaded and validated ShareableSkill instance.

        Raises:
            ValidationError: If the file content is invalid.
            PermissionError: If the path is not allowed.
        """
        # Parse the file using file manager
        frontmatter, raw_content = self.md_file_manager.parse_file(file_path)

        # Parse markdown content using marko
        data = parse_shareable_skill(raw_content)

        # Generate semantic ID
        is_shared = self._is_shared_path(file_path)
        name = frontmatter.get("name", file_path.stem)
        resource_id = ResourceIDGenerator.generate(self._id_prefix, name, is_shared)

        # Parse timestamps
        created_at = datetime.now(UTC)
        updated_at = datetime.now(UTC)
        if "created_at" in frontmatter:
            created_at = datetime.fromisoformat(frontmatter["created_at"])
        if "updated_at" in frontmatter:
            updated_at = datetime.fromisoformat(frontmatter["updated_at"])

        # Build ShareableSkill instance with structured fields
        skill = ShareableSkill(
            id=resource_id,
            path=str(file_path),
            name=name,
            description=frontmatter.get("description", ""),
            tags=frontmatter.get("tags", []),
            license=frontmatter.get("license"),
            compatibility=frontmatter.get("compatibility"),
            extra_metadata=frontmatter.get("metadata"),
            purpose=data.purpose,
            when_to_use=data.when_to_use,
            instructions=[
                {
                    step.name: {
                        "instruction": step.instruction or "",
                        "code-block": step.code_block.model_dump() if step.code_block else None,
                    }
                }
                for step in (data.instructions or [])
            ],
            examples=data.examples,
            common_edge_cases=data.common_edge_cases,
            references=data.references,
            created_at=created_at,
            updated_at=updated_at,
        )

        return skill

    def get_as_dict(self, name: str, force_shared: bool = False) -> dict[str, Any]:
        """Get a single Skill by name.

        Args:
            name: The Skill name (kebab-case)
            force_shared: If True, force access to shared resources only.
                If False (default), uses project-over-shared fallback:
                returns project resource if found, otherwise returns shared resource.
                Only use True if you explicitly need to access a shared resource
                that is being overridden by a project resource.

        Returns:
            Dictionary with Skill data

        Raises:
            ValueError: If Skill not found
        """
        try:
            skill = self._get_from_shared(name) if force_shared else self._get_from_project_or_shared(name)

            if not skill:
                raise ValueError(f"Skill not found: {name}")

            return {
                "name": skill.name,
                "description": skill.description,
                "tags": skill.tags,
                "created_at": skill.created_at.isoformat(),
                "updated_at": skill.updated_at.isoformat(),
            }

        except Exception as e:
            logger.error(
                f"Failed to get skill '{name}': {e}",
                extra={
                    "event.name": "skill.get",
                    "event.domain": "skill",
                    "event.outcome": "failure",
                    "skill.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def render(self, name: str, force_shared: bool = False) -> str:
        """Individual resource: Get specific skill content in Markdown format.

        Args:
            name: Skill name (kebab-case)
            force_shared: If True, force access to shared resources only.
                If False (default), uses project-over-shared fallback:
                returns project resource if found, otherwise returns shared resource.
                Only use True if you explicitly need to access a shared resource
                that is being overridden by a project resource.
        """
        try:
            logger.debug(f"Retrieving skill: {name}")

            skill = self._get_from_shared(name) if force_shared else self._get_from_project_or_shared(name)
            if not skill:
                raise ValueError(f"Skill not found: {name}")

            # Delegate to domain for full content rendering
            return skill.to_markdown()

        except Exception as e:
            logger.error(f"Failed to retrieve skill {name}: {e}")
            raise

    def create(
        self,
        name: str,
        description: str,
        purpose: str,
        when_to_use: list[str],
        instructions: list[dict[str, dict[str, str]]],
        tags: list[str] | None = None,
        examples: str | None = None,
        edge_cases: dict[str, str] | None = None,
        references: list[str] | None = None,
        license: str | None = None,  # noqa: A002
        compatibility: str | None = None,
        extra_metadata: dict[str, Any] | None = None,
        shared: bool = False,
    ) -> SkillCreateResult:
        """Create a new skill and save to file and database.

        Args:
            name: Resource name (kebab-case)
            description: Brief description
            purpose: Purpose section content
            when_to_use: List of trigger conditions
            instructions: Step-by-step instructions
            tags: Classification tags
            examples: Examples section content
            edge_cases: Dict of edge case titles to descriptions
            references: List of reference links
            license: License name or reference
            compatibility: Environment requirements
            extra_metadata: Additional metadata
            shared: If True, create in shared directory; if False (default), create in project directory

        Returns:
            SkillCreateResult with name and creation timestamp
        """
        base_dir = self._get_target_path(shared=shared)
        self._check_rw_for_path(base_dir)
        try:
            now = datetime.now(UTC)
            skill = ShareableSkill(
                id="",
                path=str(base_dir / f"{name}.md"),
                name=name,
                description=description,
                tags=tags or [],
                license=license,
                compatibility=compatibility,
                extra_metadata=extra_metadata,
                purpose=purpose,
                when_to_use=when_to_use,
                instructions=instructions,
                examples=examples,
                common_edge_cases=edge_cases,
                references=references or [],
                created_at=now,
                updated_at=now,
            )

            self.save_resource(skill)

            logger.info(
                f"Created skill: {skill.id} - {name}",
                extra={
                    "event.name": "skill.create",
                    "event.domain": "skill",
                    "event.outcome": "success",
                    "skill.id": skill.id,
                    "skill.name": name,
                },
            )
            return SkillCreateResult(name=skill.name, created_at=skill.created_at.isoformat(), estimated_tokens=skill.estimated_tokens)

        except Exception as e:
            logger.error(
                f"Failed to create skill '{name}': {e}",
                extra={
                    "event.name": "skill.create",
                    "event.domain": "skill",
                    "event.outcome": "failure",
                    "skill.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def update(
        self,
        name: str,
        purpose: str | None = None,
        when_to_use: list[str] | None = None,
        instructions: list[dict[str, dict[str, str]]] | None = None,
        examples: str | None = None,
        edge_cases: dict[str, str] | None = None,
        references: list[str] | None = None,
        tags: list[str] | None = None,
        description: str | None = None,
        license: str | None = None,  # noqa: A002
        compatibility: str | None = None,
        extra_metadata: dict[str, Any] | None = None,
        shared: bool = False,
    ) -> SkillUpdateResult:
        """Update skill metadata and/or content sections.

        Args:
            name: The Skill name (kebab-case)
            purpose: Purpose section content
            when_to_use: List of trigger conditions
            instructions: Step-by-step instructions
            examples: Examples section content
            edge_cases: Dict of edge case titles to descriptions
            references: List of reference links
            tags: Classification tags
            description: Brief description
            license: License name or reference
            compatibility: Environment requirements
            extra_metadata: Additional metadata
            shared: If True, update shared resource; if False (default), update project resource

        Only provided fields are modified. Others remain unchanged.

        Returns:
            SkillUpdateResult with name and update timestamp
        """
        try:
            skill = self._get_from_shared(name) if shared else self._get_from_project_or_shared(name)
            if not skill:
                raise ValueError(f"Skill not found: {name}")

            self._check_rw_for_path(Path(skill.path))

            skill.update_metadata(
                tags=tags, description=description, license=license, compatibility=compatibility, extra_metadata=extra_metadata
            )

            skill.update_content(
                purpose=purpose,
                when_to_use=when_to_use,
                instructions=instructions,
                examples=examples,
                edge_cases=edge_cases,
                references=references,
            )

            self.save_resource(skill)

            logger.info(
                f"Updated skill: {skill.id}",
                extra={
                    "event.name": "skill.update",
                    "event.domain": "skill",
                    "event.outcome": "success",
                    "skill.id": skill.id,
                },
            )
            return SkillUpdateResult(name=skill.name, updated_at=skill.updated_at.isoformat(), estimated_tokens=skill.estimated_tokens)

        except Exception as e:
            logger.error(
                f"Failed to update skill '{name}': {e}",
                extra={
                    "event.name": "skill.update",
                    "event.domain": "skill",
                    "event.outcome": "failure",
                    "skill.name": name,
                    "error.message": str(e),
                },
            )
            raise

    def delete(self, name: str, force_shared: bool = False) -> SkillDeleteResult:
        """Delete Skill by name.

        Args:
            name: Skill name (kebab-case)
            force_shared: If True, delete from shared only; if False, delete from project

        Returns:
            SkillDeleteResult with name and deletion timestamp

        Raises:
            ValueError: If skill not found
        """
        logger.debug(f"Deleting skill: {name}")

        if self._delete_by_name(name, from_shared=force_shared):
            logger.info(
                f"Deleted Skill: {name}",
                extra={
                    "event.name": "skill.delete",
                    "event.domain": "skill",
                    "event.outcome": "success",
                    "skill.name": name,
                },
            )
            return SkillDeleteResult(name=name, deleted_at=datetime.now(UTC).isoformat())
        else:
            raise ValueError(f"Skill not found: {name}")
