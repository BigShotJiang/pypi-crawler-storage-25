"""Markdown sections specific to ShareableSkill domain.

Provides BaseModel classes for parsing and rendering ShareableSkill-specific sections.
"""

from contextlib import suppress
from typing import Self

from marko import block
from marko.block import Document
from pydantic import BaseModel, Field

from mcp_remlezrd.features.shared.domain import MarkdownList, MarkdownListItem, RichMarkdownContent, SimpleMarkdownParagraph
from mcp_remlezrd.features.shared.exceptions import SectionNotFoundError, SectionParsingError
from mcp_remlezrd.features.shared.markdown import render_element_to_markdown
from mcp_remlezrd.features.shared.md_sections import CodeBlock, KeyValueSection, ListSection, RawSection


class PurposeSection(BaseModel):
    """Section Purpose (required)."""

    model_config = {"frozen": True}
    content: SimpleMarkdownParagraph = Field(..., min_length=10)

    @classmethod
    def from_doc(cls, doc: Document) -> Self:
        """Parse Purpose section from document."""
        section = RawSection.from_h2(doc, "Purpose")
        if not section.content:
            raise SectionParsingError("Purpose section is empty")
        return cls(content=section.content)

    def render(self) -> str:
        """Render section as markdown."""
        return RawSection.from_content_str(name="Purpose", content=self.content).render(level=2)


class WhenToUseSection(BaseModel):
    """Section 'When to Use' with optional preamble."""

    model_config = {"frozen": True}
    triggers: MarkdownList = Field(..., min_length=1)

    @classmethod
    def from_doc(cls, doc: Document) -> Self:
        """Parse When to Use section from document."""
        section = ListSection.from_h2(doc, "When to Use", strict=False)
        return cls(triggers=section.items)

    def render(self) -> str:
        """Render section as markdown."""
        return ListSection(
            name="When to Use",
            preamble="Use this skill when:",
            items=self.triggers,
        ).render(level=2)


class InstructionStep(BaseModel):
    """A single instruction step (H3 subsection)."""

    model_config = {"frozen": True}
    name: str = Field(..., min_length=1)
    instruction: str = Field(..., min_length=1)
    code_block: CodeBlock | None = None

    @classmethod
    def from_h3(cls, doc: Document, parent_h2: str, name: str) -> Self:
        """Parse instruction step from H3 subsection.

        Args:
            doc: Parsed marko document
            parent_h2: Parent H2 section name ("Instructions")
            name: H3 subsection name (step name)

        Returns:
            InstructionStep with name, instruction text, and optional code block
        """
        text_parts, code_block = cls._parse_step_content(doc, parent_h2, name)

        if not text_parts:
            raise SectionParsingError(f"Instruction step '{name}' must contain text")

        return cls(
            name=name,
            instruction="\n\n".join(text_parts).strip(),
            code_block=code_block,
        )

    @staticmethod
    def _parse_step_content(doc: Document, parent_h2: str, name: str) -> tuple[list[str], CodeBlock | None]:
        """Parse text content and optional code block from an instruction step.

        Args:
            doc: Marko document.
            parent_h2: Parent H2 section name.
            name: H3 step name.

        Returns:
            Tuple of ``(text_parts, optional_code_block)``.
        """
        from mcp_remlezrd.features.shared.markdown import iter_h3_section_elements_in_h2_section

        text_parts: list[str] = []
        code_block: CodeBlock | None = None

        for elem in iter_h3_section_elements_in_h2_section(doc, parent_h2, name):
            match elem:
                case block.Paragraph():
                    text = render_element_to_markdown(elem)
                    if text:
                        text_parts.append(text)

                case block.List():
                    text = render_element_to_markdown(elem)
                    if text:
                        text_parts.append(text)

                case block.FencedCode():
                    code_block = CodeBlock.from_fenced_code(elem)

                case block.CodeBlock():
                    raise SectionParsingError(
                        "Instructions section only supports fenced code blocks (```), "
                        "not indented code blocks. Please use ```lang\ncode\n``` format."
                    )

                case block.BlankLine():
                    pass

                case _:
                    raise SectionParsingError(
                        f"Instruction step can only contain paragraphs, lists and code blocks, found: {type(elem).__name__}"
                    )

        return text_parts, code_block

    def render(self) -> str:
        """Render step as markdown lines."""
        lines = [f"### {self.name}", "", self.instruction]
        if self.code_block:
            lines.extend(["", self.code_block.render()])
        lines.append("")
        return "\n".join(lines)


class InstructionsSection(BaseModel):
    """Section Instructions with H3 steps.

    Complex section containing H3 subsections, each with text and optional code blocks.
    """

    model_config = {"frozen": True}
    steps: list[InstructionStep] = Field(..., min_length=1)

    @classmethod
    def from_doc(cls, doc: Document) -> Self:
        """Parse Instructions section from document."""
        from mcp_remlezrd.features.shared.markdown import iter_h3_section_names_in_h2_section

        try:
            h3_names = list(iter_h3_section_names_in_h2_section(doc, "Instructions"))
        except SectionNotFoundError as e:
            raise SectionNotFoundError("Section 'Instructions' not found") from e

        if not h3_names:
            raise SectionParsingError("Instructions section must contain at least one H3 step")

        steps = [InstructionStep.from_h3(doc, "Instructions", name) for name in h3_names]
        return cls(steps=steps)

    def render(self) -> str:
        """Render section as markdown."""
        lines = ["## Instructions", ""]
        for step in self.steps:
            lines.append(step.render())
        return "\n".join(lines)


class EdgeCasesSection(BaseModel):
    """Section Common Edge Cases (optional)."""

    model_config = {"frozen": True}
    cases: dict[str, MarkdownListItem] | None = None

    @classmethod
    def from_doc(cls, doc: Document) -> Self | None:
        """Parse Common Edge Cases section from document."""
        with suppress(SectionNotFoundError):
            section = KeyValueSection.from_h2(doc, "Common Edge Cases")
            return cls(cases=section.items)
        return None

    def render(self) -> str:
        """Render section as markdown."""
        if not self.cases:
            return ""
        return KeyValueSection(name="Common Edge Cases", items=self.cases).render(level=2)


class ExamplesSection(BaseModel):
    """Section Examples (optional)."""

    model_config = {"frozen": True}
    content: RichMarkdownContent | None = None

    @classmethod
    def from_doc(cls, doc: Document) -> Self | None:
        """Parse Examples section from document."""
        with suppress(SectionNotFoundError):
            section = RawSection.from_h2(doc, "Examples")
            return cls(content=section.content)
        return None

    def render(self) -> str:
        """Render section as markdown."""
        if not self.content:
            return ""
        return RawSection.from_content_str(name="Examples", content=self.content).render(level=2)
