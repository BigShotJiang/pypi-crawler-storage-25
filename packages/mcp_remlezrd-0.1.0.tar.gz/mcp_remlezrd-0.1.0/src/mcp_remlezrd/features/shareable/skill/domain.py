from typing import Any, Self

from pydantic import model_validator
from sqlalchemy import Column
from sqlalchemy.dialects.sqlite import JSON
from sqlmodel import Field as SQLField

from mcp_remlezrd.features.shared.domain import RichMarkdownContent, ShareableResourceBase, SimpleMarkdownParagraph
from mcp_remlezrd.features.shared.md_sections import CodeBlock

from .content_strategy import (
    InstructionStep,
    ShareableSkillData,
    render_shareable_skill,
)


class ShareableSkill(ShareableResourceBase, table=True):
    """Shareable Skill resource for AGENT_CONTEXT domain.

    Represents reusable skills/capabilities that agents can apply to specific tasks.
    Simpler than legacy skill specifications - single file with frontmatter.
    """

    # Override base fields with ShareableSkill-specific defaults
    id: str = SQLField(
        primary_key=True,
        description="Shareable Skill ID with pattern [+]skill_<name>",
    )

    # Structured content fields (stored as JSON)
    purpose: SimpleMarkdownParagraph = SQLField(
        description="Purpose section content",
    )

    when_to_use: list[str] = SQLField(
        default_factory=list,
        sa_column=Column("when_to_use", JSON),
        description="List of trigger conditions for the skill",
    )

    instructions: list[dict[str, dict[str, Any]]] = SQLField(
        default_factory=list,
        sa_column=Column("instructions", JSON),
        description="Step-by-step instructions as list of single-step dicts",
    )

    examples: RichMarkdownContent | None = SQLField(
        default=None,
        description="Examples section content (free text)",
    )

    common_edge_cases: dict[str, str] | None = SQLField(
        default=None,
        sa_column=Column("common_edge_cases", JSON),
        description="Edge cases as dict: title -> description",
    )

    references: list[str] = SQLField(
        default_factory=list,
        sa_column=Column("references", JSON),
        description="List of reference links/items",
    )

    def to_frontmatter(self) -> dict[str, Any]:
        """Convert ShareableSkill model fields to frontmatter dict (id is internal, not persisted)."""
        result: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "tags": self.tags,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }
        if self.license:
            result["license"] = self.license
        if self.compatibility:
            result["compatibility"] = self.compatibility
        if self.extra_metadata:
            result["metadata"] = self.extra_metadata
        return result

    def update_metadata(
        self,
        tags: list[str] | None = None,
        description: str | None = None,
        license: str | None = None,  # noqa: A002
        compatibility: str | None = None,
        extra_metadata: dict[str, Any] | None = None,
    ) -> None:
        """Update resource metadata fields.

        Content updates are handled by the service layer via ContentEngine.
        """
        if tags is not None:
            self.tags = tags
        if description is not None:
            self.description = description
        if license is not None:
            self.license = license
        if compatibility is not None:
            self.compatibility = compatibility
        if extra_metadata is not None:
            self.extra_metadata = extra_metadata

    def update_content(
        self,
        purpose: str | None = None,
        when_to_use: list[str] | None = None,
        instructions: list[dict[str, dict[str, Any]]] | None = None,
        examples: str | None = None,
        edge_cases: dict[str, str] | None = None,
        references: list[str] | None = None,
    ) -> None:
        """Update markdown body content fields.

        Only provided fields are modified. Others remain unchanged.
        """
        if purpose is not None:
            self.purpose = purpose
        if when_to_use is not None:
            self.when_to_use = when_to_use
        if instructions is not None:
            self.instructions = instructions
        if examples is not None:
            self.examples = examples
        if edge_cases is not None:
            self.common_edge_cases = edge_cases
        if references is not None:
            self.references = references

    @model_validator(mode="after")
    def validate_no_duplicate_instruction_names(self) -> Self:
        """Validate that instruction step names are unique (case-insensitive).

        Duplicate step names would cause ambiguity in the instructions section.
        """
        if not self.instructions:
            return self

        seen: set[str] = set()
        for step in self.instructions:
            # step is a dict with single key: the step name
            step_name = list(step.keys())[0]
            name_lower = step_name.lower()
            if name_lower in seen:
                raise ValueError(f"Duplicate instruction step name: {step_name!r}")
            seen.add(name_lower)
        return self

    def to_markdown(self) -> str:
        """Generate markdown content from structured fields."""
        # Convert instructions from storage format to InstructionStep
        instruction_steps = []
        for step in self.instructions:
            step_name = list(step.keys())[0]
            step_data = step[step_name]

            # Parse code-block from JSON dict
            code_block_raw = step_data.get("code-block")
            code_block: CodeBlock | None = None
            if code_block_raw and isinstance(code_block_raw, dict):
                code_block = CodeBlock.model_validate(code_block_raw)

            instruction_steps.append(
                InstructionStep(
                    name=step_name,
                    instruction=step_data.get("instruction", ""),
                    code_block=code_block,
                )
            )

        data = ShareableSkillData(
            purpose=self.purpose,
            when_to_use=self.when_to_use,
            instructions=instruction_steps,
            examples=self.examples,
            common_edge_cases=self.common_edge_cases,
            references=self.references,
        )
        return render_shareable_skill(self.name, data)

    def __repr__(self) -> str:
        return f"<ShareableSkill(id={self.id}, name={self.name!r})>"
