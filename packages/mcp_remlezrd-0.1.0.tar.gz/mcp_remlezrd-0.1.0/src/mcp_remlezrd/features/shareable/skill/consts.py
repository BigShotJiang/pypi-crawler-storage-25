"""Canonical identifiers and descriptions for Skill resources and tools."""


# =============================================================================
# Tool Descriptions - Purpose
# =============================================================================

CREATE_PURPOSE = "Create a new Skill for reusable capabilities and workflows"
UPDATE_PURPOSE = "Update an existing Skill by modifying only the provided fields"
DELETE_PURPOSE = "Delete a Skill by name"

# =============================================================================
# Tool Descriptions - When To Use
# =============================================================================

CREATE_WHEN_TO_USE: list[str] = [
    "Use for documenting reusable procedures and workflows",
    "Use for establishing standardized approaches to common tasks",
    "Use for capturing complex multi-step processes",
    "Do NOT use for simple one-time instructions",
]

UPDATE_WHEN_TO_USE: list[str] = [
    "Use when refining skill instructions based on feedback",
    "Use for adding new edge cases or examples",
    "Use for updating trigger conditions",
    "Do NOT use when you intend to replace the entire skill",
]

DELETE_WHEN_TO_USE: list[str] = [
    "Use when a skill is no longer relevant or accurate",
    "Use for cleaning up obsolete or redundant skills",
    "Use when consolidating multiple skills into one",
    "Do NOT use lightly: prefer updating over deleting",
]

# =============================================================================
# Tool Descriptions - Constraints
# =============================================================================

CREATE_CONSTRAINTS: list[str] = [
    "Project skills override shared skills with the same name",
]

UPDATE_CONSTRAINTS: list[str] = [
    "Only provided fields are modified; others remain unchanged",
    'To remove an optional field, pass an empty value of its type ("" for strings, [] for lists, {} for dicts). Passing null or omitting the field leaves it unchanged',
    "Cannot change a project skill to shared or vice versa",
    "Skill must exist in the specified scope",
]

DELETE_CONSTRAINTS: list[str] = [
    "Deletion is permanent and cannot be undone",
    "Deleting a shared skill does not affect project overrides",
    "Skill must exist in the specified scope",
]

# =============================================================================
# Discover Tool Descriptions
# =============================================================================

DISCOVER_PURPOSE = "Discovery tool for Skills: returns a catalog of all available skills"

DISCOVER_WHEN_TO_USE: list[str] = [
    "Before creating/updating skills to check for existing entries",
    "To discover available skills for reference in tools",
    "To find skill names for use with read_skill resource template",
]

DISCOVER_CONSTRAINTS: list[str] = [
    "Read-only tool",
    "Returns JSON catalog",
]

# =============================================================================
# Resource Descriptions - Purpose & Content Summary
# =============================================================================

INDEX_PURPOSE = "Discovery resource for Skills"
INDEX_CONTENT_SUMMARY = "Catalog of all Skills with preview metadata including name, description, trigger conditions, and scope"

# Short description for onboarding
INDEX_SHORT_DESCRIPTION = "workflows and procedures"
READ_PURPOSE = "Context resource for Skills (Project-first resolution)"
READ_CONTENT_SUMMARY = "Full Skill content in Markdown format for context enrichment. Uses project-first resolution: returns project Skill if exists, otherwise returns shared Skill. This is the default resource to use for reading Skills."
READ_SHARED_PURPOSE = "Context resource for shared Skills (Shared-only, bypasses project overrides)"
READ_SHARED_CONTENT_SUMMARY = "Full shared Skill content in Markdown format. FORCE shared-only access: bypasses project overrides and returns the shared version even if a project Skill with the same name exists. Use with caution."

# =============================================================================
# Resource Descriptions - When To Use
# =============================================================================

INDEX_WHEN_TO_USE: list[str] = [
    "Before creating/updating skills to check for existing entries",
    "To discover available skills for reference in tools",
    "To find skill names for use with read_skill resource template",
]

READ_WHEN_TO_USE: list[str] = [
    "When you need to understand a specific skill's capabilities",
    "To review step-by-step instructions before applying them",
    "To check edge cases and examples for a skill",
    "Default choice: always use this unless you specifically need the shared-only version",
]

READ_SHARED_WHEN_TO_USE: list[str] = [
    "ONLY when you need to inspect a shared skill that is masked by a project override",
    "To compare drift between project skill and shared skill with same name",
    "For maintenance: debugging skill inheritance or migration issues",
    "AVOID in normal workflows: use read_skill instead for standard access",
]

# =============================================================================
# Resource Descriptions - Constraints
# =============================================================================

INDEX_CONSTRAINTS: list[str] = [
    "Read-only resource",
    "JSON format",
]

READ_CONSTRAINTS: list[str] = [
    "Read-only resource",
    "Markdown format",
    "Requires valid skill name from index",
    "Project skills override shared skills with same name",
]

READ_SHARED_CONSTRAINTS: list[str] = [
    "Read-only resource",
    "Markdown format",
    "FORCE shared-only: ignores project overrides",
    "Requires valid skill name from index",
]
