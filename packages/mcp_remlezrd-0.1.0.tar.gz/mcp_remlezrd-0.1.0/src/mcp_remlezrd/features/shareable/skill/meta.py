"""Skill resource metadata."""

from mcp_remlezrd.features.shared.app_meta import APP
from mcp_remlezrd.features.shared.meta_types import ResourceMeta

META = ResourceMeta(
    pretty_name="Skill",
    resource_type="skill",
    pretty_plural="Skills",
    short_plural="skills",
    tag="res:skill",
    create_tool="create_skill",
    update_tool="update_skill",
    delete_tool="delete_skill",
    discover_tool="discover_skills_only",
    base_uri=f"{APP.server_name}://skill/",
    shared_base_uri=f"{APP.server_name}://shared_skill/",
    resource_component="read_skill",
    shared_resource_component="read_shared_skill",
)
