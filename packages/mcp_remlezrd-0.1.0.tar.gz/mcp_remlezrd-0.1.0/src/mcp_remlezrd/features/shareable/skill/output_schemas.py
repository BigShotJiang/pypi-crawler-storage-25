"""Output schemas for Shareable Skill operations.

These Pydantic models define the structure of responses from skill operations,
used by both the service layer and MCP tools.
"""

from pydantic import BaseModel, Field


class SkillCreateResult(BaseModel):
    """Result of skill creation operation."""

    name: str = Field(description="Skill name (kebab-case)")
    created_at: str = Field(description="Creation timestamp (ISO 8601)")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")


class SkillUpdateResult(BaseModel):
    """Result of skill update operation."""

    name: str = Field(description="Skill name")
    updated_at: str = Field(description="Last update timestamp (ISO 8601)")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")


class SkillDeleteResult(BaseModel):
    """Result of skill deletion operation."""

    name: str = Field(description="deleted Skill name")
    deleted_at: str = Field(description="Deletion timestamp (ISO 8601)")


class SkillDiscoverEntry(BaseModel):
    """Single entry in the skill discovery catalog."""

    name: str = Field(description="Skill name (kebab-case)")
    description: str = Field(description="Brief description")
    when_to_use: list[str] = Field(description="Trigger conditions for using this skill")
    tags: list[str] | None = Field(default=None, exclude_if=lambda v: v is None, description="Classification tags")
    estimated_tokens: int = Field(description="Estimated token count of the markdown content")
    uri: str = Field(description="Resource URI for reading this skill")
    compatibility: str | None = Field(default=None, exclude_if=lambda v: v is None, description="Environment requirements")


class SkillDiscoverResult(BaseModel):
    """Result of skill discovery operation."""

    skills: list[SkillDiscoverEntry] = Field(description="Catalog of available skills")
