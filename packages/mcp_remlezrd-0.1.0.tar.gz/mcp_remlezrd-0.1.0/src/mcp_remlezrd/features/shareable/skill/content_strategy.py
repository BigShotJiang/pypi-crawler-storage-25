"""Content strategy for ShareableSkill resources.

Uses marko for markdown parsing with section-based approach.
"""

import logging

from marko import Markdown
from pydantic import BaseModel, Field

from mcp_remlezrd.features.shared.domain import MarkdownList, MarkdownListItem, RichMarkdownContent, SimpleMarkdownParagraph
from mcp_remlezrd.features.shared.markdown import validate_no_unexpected_h2_sections
from mcp_remlezrd.features.shared.markdown.normalized_renderer import normalize_markdown
from mcp_remlezrd.features.shared.md_sections import ReferencesSection

from .md_sections import (
    EdgeCasesSection,
    ExamplesSection,
    InstructionsSection,
    InstructionStep,
    PurposeSection,
    WhenToUseSection,
)

logger = logging.getLogger(__name__)

REQUIRED_SECTIONS = {"Purpose", "When to Use", "Instructions"}
OPTIONAL_SECTIONS = {"Examples", "Common Edge Cases", "References"}
ALLOWED_SECTIONS = REQUIRED_SECTIONS | OPTIONAL_SECTIONS


class ShareableSkillData(BaseModel):
    """Structured data for an ShareableSkill resource (content only)."""

    purpose: SimpleMarkdownParagraph = Field(..., min_length=10)
    when_to_use: MarkdownList = Field(..., min_length=1)
    instructions: list[InstructionStep] = Field(..., min_length=1)
    examples: RichMarkdownContent | None = None
    common_edge_cases: dict[str, MarkdownListItem] | None = None
    references: MarkdownList = Field(default_factory=list)


def parse_shareable_skill(content: str) -> ShareableSkillData:
    """Parse markdown content into structured ShareableSkill data.

    Note: The H1 title is ignored - name comes from frontmatter.

    Raises:
        SectionNotFoundError: If required sections are missing
        SectionParsingError: If sections are malformed
    """
    logger.debug(
        "Parsing skill content",
        extra={
            "event.name": "content.parse",
            "event.domain": "skill",
        },
    )

    doc = Markdown().parse(normalize_markdown(content))

    # Validate no unexpected sections
    validate_no_unexpected_h2_sections(doc, ALLOWED_SECTIONS)

    # Parse required sections
    purpose = PurposeSection.from_doc(doc)
    when_to_use = WhenToUseSection.from_doc(doc)
    instructions = InstructionsSection.from_doc(doc)

    # Parse optional sections
    examples = ExamplesSection.from_doc(doc)
    edge_cases = EdgeCasesSection.from_doc(doc)
    references = ReferencesSection.from_doc(doc)

    logger.debug(
        "Parsed skill content",
        extra={
            "event.name": "content.parse",
            "event.domain": "skill",
            "event.outcome": "success",
            "triggers.count": len(when_to_use.triggers),
            "instructions.count": len(instructions.steps),
            "has.examples": examples is not None,
            "has.edge_cases": edge_cases is not None,
            "references.count": len(references.items),
        },
    )

    return ShareableSkillData(
        purpose=purpose.content,
        when_to_use=when_to_use.triggers,
        instructions=instructions.steps,
        examples=examples.content if examples else None,
        common_edge_cases=edge_cases.cases if edge_cases else None,
        references=references.items,
    )


def render_shareable_skill(name: str, data: ShareableSkillData) -> str:
    """Render structured ShareableSkill data back to markdown.

    Args:
        name: Resource name (from frontmatter)
        data: Structured content data
    """
    lines = [f"# ShareableSkill '{name}'", ""]

    # Required sections
    lines.append(PurposeSection(content=data.purpose).render())
    lines.append("")
    lines.append(WhenToUseSection(triggers=data.when_to_use).render())
    lines.append("")
    lines.append(InstructionsSection(steps=data.instructions).render())

    # Optional sections
    if data.examples:
        lines.append("")
        lines.append(ExamplesSection(content=data.examples).render())

    if data.common_edge_cases:
        lines.append("")
        lines.append(EdgeCasesSection(cases=data.common_edge_cases).render())

    if data.references:
        lines.append("")
        lines.append(ReferencesSection(items=data.references).render())

    return "\n".join(lines)
