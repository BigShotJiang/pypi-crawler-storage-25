from abc import ABC, abstractmethod
from datetime import UTC, datetime
import logging
from pathlib import Path
from typing import Any

from sqlalchemy import delete
from sqlmodel import Session, select

from .domain import ResourceBase
from .ports import FileManagerPort
from .services_utils import sanitize_path

logger = logging.getLogger(__name__)


class ResourceIDGenerator:
    """Utility for generating semantic resource IDs.

    Format:
    - Project: {prefix}_{name}  (e.g., "rule_auth-best-practices")
    - Shared: +{prefix}_{name}  (e.g., "+rule_auth-best-practices")

    The '+' prefix indicates a shared resource that can be overridden
    by a project resource with the same name.
    """

    @staticmethod
    def generate(prefix: str, name: str, is_shared: bool = False) -> str:
        """Generate a semantic resource ID.

        Args:
            prefix: Resource type prefix (e.g., "rule", "adr", "skill")
            name: Resource name in kebab-case
            is_shared: True if resource is from shared directory

        Returns:
            Semantic ID string
        """
        marker = "+" if is_shared else ""
        return f"{marker}{prefix}_{name}"

    @staticmethod
    def parse(resource_id: str) -> tuple[str, str, bool]:
        """Parse a semantic resource ID.

        Args:
            resource_id: The ID to parse

        Returns:
            Tuple of (prefix, name, is_shared)

        Example:
            >>> ResourceIDGenerator.parse("+rule_auth-best-practices")
            ("rule", "auth-best-practices", True)
        """
        is_shared = resource_id.startswith("+")
        clean_id = resource_id.lstrip("+")

        parts = clean_id.split("_", 1)
        prefix = parts[0]
        name = parts[1] if len(parts) > 1 else ""

        return prefix, name, is_shared


class BaseResourcesService(ABC):
    """Base service with explicit path injection.

    Uses explicit project_res_path parameter. No introspection, no strategies.
    File watching triggers reindexation via sync_dirs().
    """

    # Class attributes to be overridden by subclasses
    _id_prefix: str = ""
    _model_class: type[ResourceBase] = ResourceBase
    _upsert_fields: list[str] = []

    def __init__(
        self,
        files_manager: FileManagerPort,
        session: Session,
        file_tx_factory,
        project_res_path: Path,
        rw: bool = True,
    ):
        self.session = session
        self.md_file_manager: FileManagerPort = files_manager
        self.file_tx_factory = file_tx_factory
        self._project_res_path = project_res_path
        self._rw = rw

        # Note: Initial indexation is done explicitly after construction
        # to avoid issues with subclass attribute initialization order

    def _check_rw(self) -> None:
        """Check if project resources are writable."""
        if not self._rw:
            raise PermissionError("Project resources are read-only")

    @property
    def resource_dir(self) -> Path:
        """Expose resource directory for compatibility."""
        return self._project_res_path

    def get_resources_paths(self) -> list[Path]:
        """Return paths to monitor for changes. Override in subclasses."""
        return [self._project_res_path]

    def _get_from_project(self, name: str):
        """Get resource from project directory by name.

        Returns:
            Resource instance or None.
        """
        from sqlmodel import select

        query = select(self._model_class).where(
            self._model_class.name == name,
            self._model_class.path.startswith(str(self._project_res_path)),
        )
        return self.session.exec(query).first()

    def sync_dirs(self) -> None:
        """Synchronize directories with database (reindexation)."""
        try:
            # File discovery in all resource paths (project + shared)
            files: list[Path] = []
            for path in self.get_resources_paths():
                if path.exists():
                    files.extend(path.rglob("*.md"))

            indexed_count = 0
            for file_path in files:
                try:
                    resource = self.load_from_file(file_path)
                    self._persist_to_db(resource)
                    indexed_count += 1
                except Exception as e:
                    logger.warning(
                        f"Failed to index {sanitize_path(file_path)}: {e}",
                        extra={
                            "event.name": "sync.index.file",
                            "event.domain": "persistence",
                            "event.outcome": "failure",
                            "file.path": sanitize_path(file_path),
                            "error.message": str(e),
                        },
                    )

            # Cleanup deleted files
            self._cleanup_orphan_db_entries()

            logger.info(
                f"Indexed {indexed_count} resources from {self._project_res_path}",
                extra={
                    "event.name": "sync.index.complete",
                    "event.domain": "persistence",
                    "event.outcome": "success",
                    "resources.count": indexed_count,
                    "path": str(self._project_res_path),
                },
            )

        except Exception as e:
            logger.error(
                f"Failed to sync index: {e}",
                extra={
                    "event.name": "sync.index.complete",
                    "event.domain": "persistence",
                    "event.outcome": "failure",
                    "error.message": str(e),
                },
            )

    @abstractmethod
    def load_from_file(self, file_path: Path) -> ResourceBase:
        """Load and validate a resource from a markdown file.

        Args:
            file_path: Path to the markdown file to load.

        Returns:
            The loaded and validated resource entity.

        Raises:
            ValidationError: If the file content is invalid.
            PermissionError: If the path is not allowed.
        """
        ...

    def _is_shared_path(self, file_path: Path) -> bool:
        """Check if file path is in shared directory. Override in subclasses."""
        return False

    def _persist_to_db(self, resource: ResourceBase) -> None:
        """Persist resource to database (idempotent)."""
        # Check if object already exists in DB (by path)
        existing = self.session.exec(select(self._model_class).where(self._model_class.path == resource.path)).first()

        if existing and existing is not resource:
            # Object exists in DB but is a different instance - update it
            for field in self._upsert_fields:
                if hasattr(resource, field):
                    setattr(existing, field, getattr(resource, field))
            existing.updated_at = datetime.now(UTC)
        elif not existing:
            # New object - add it
            self.session.add(resource)

        self.session.commit()

    def _cleanup_orphan_db_entries(self) -> None:
        """Remove database entries for files that no longer exist."""
        all_resources = self.session.exec(select(self._model_class)).all()
        current_files = set()

        for path in self.get_resources_paths():
            if path.exists():
                current_files.update(path.rglob("*.md"))

        db_paths = {Path(r.path) for r in all_resources}
        notfound = db_paths - current_files

        for path in notfound:
            stmt = delete(self._model_class).where(self._model_class.path == str(path))  # ty:ignore[invalid-argument-type]
            self.session.exec(stmt)
            logger.debug(
                f"Deleted notfound: {path}",
                extra={
                    "event.name": "sync.cleanup.file",
                    "event.domain": "persistence",
                    "file.path": sanitize_path(path),
                },
            )

        if notfound:
            self.session.commit()
            logger.info(
                f"Cleaned up {len(notfound)} deleted resources",
                extra={
                    "event.name": "sync.cleanup",
                    "event.domain": "persistence",
                    "event.outcome": "success",
                    "resources.count": len(notfound),
                },
            )

    def save_resource(self, resource: ResourceBase, *, update_timestamp: bool = True) -> None:
        """Save resource atomically: file backup + DB commit.

        Args:
            resource: The resource to save.
            update_timestamp: If True (default), update updated_at to current time.
                Set to False only for operations requiring timestamp preservation
                (e.g., data migration, sync operations).
        """
        if update_timestamp:
            resource._update_timestamp()

        file_path = Path(resource.path)

        # Always generate semantic ID from path and name
        # This ensures consistency between indexation and creation
        is_shared = self._is_shared_path(file_path)
        resource.id = ResourceIDGenerator.generate(self._id_prefix, resource.name, is_shared)

        with self.file_tx_factory(file_path):
            frontmatter = resource.to_frontmatter()
            content = resource.to_markdown()
            self.md_file_manager.create_file(file_path, frontmatter, content)
            self._persist_to_db(resource)

        logger.info(
            f"Saved resource: {resource.id}",
            extra={
                "event.name": "resource.save",
                "event.domain": "persistence",
                "event.outcome": "success",
                "resource.id": resource.id,
            },
        )

    def _delete_resource_by_name(self, name: str) -> bool:
        """Delete resource by name from database and filesystem.

        Returns:
            Whether the resource was deleted.
        """
        resource = self.session.exec(select(self._model_class).where(self._model_class.name == name)).first()

        if not resource:
            return False

        file_path = Path(resource.path)
        with self.file_tx_factory(file_path):
            self.md_file_manager.delete_file(file_path)
            self.session.delete(resource)
            self.session.commit()

        logger.info(
            f"Deleted resource: {resource.id}",
            extra={
                "event.name": "resource.delete",
                "event.domain": "persistence",
                "event.outcome": "success",
                "resource.id": resource.id,
            },
        )
        return True

    @abstractmethod
    def delete(self, name: str) -> Any:
        """Delete a resource by name.

        Args:
            name: Resource name to delete.

        Returns:
            Delete result specific to the resource type.
        """
        raise NotImplementedError


class ShareableResourcesService(BaseResourcesService):
    """Service for resources that can exist in both project and shared directories.

    Project resources take priority over shared resources.
    """

    def __init__(
        self,
        files_manager: FileManagerPort,
        session: Session,
        file_tx_factory,
        project_res_path: Path,
        shared_res_path: Path | None,
        rw: bool = True,
        rw_shared: bool = True,
    ):
        super().__init__(
            files_manager=files_manager,
            session=session,
            file_tx_factory=file_tx_factory,
            project_res_path=project_res_path,
            rw=rw,
        )
        self._shared_res_path = shared_res_path
        self._rw_shared = rw_shared

    @abstractmethod
    def delete(self, name: str, force_shared: bool = False) -> Any:
        """Delete a resource by name.

        Args:
            name: Resource name to delete.
            force_shared: If True, target shared storage; if False, target project storage.

        Returns:
            Delete result specific to the resource type.
        """
        raise NotImplementedError

    def _check_rw_shared(self) -> None:
        """Check if shared resources are writable."""
        if not self._rw_shared:
            raise PermissionError("Shared resources are read-only")

    def _get_target_path(self, shared: bool = False) -> Path:
        """Return the target directory for resource operations.

        Args:
            shared: Return shared directory if True, project directory otherwise.

        Returns:
            Target directory path.

        Raises:
            ValueError: If shared directory is not configured.
        """
        if shared:
            if self._shared_res_path is None:
                raise ValueError("Shared directory not configured")
            return self._shared_res_path
        return self._project_res_path

    def _check_rw_for_path(self, file_path: Path) -> None:
        """Check if resources are writable for the given path."""
        if self._is_shared_path(file_path):
            self._check_rw_shared()
        else:
            self._check_rw()

    def get_resources_paths(self) -> list[Path]:
        """Return both project and shared paths to monitor."""
        paths = [self._project_res_path]
        if self._shared_res_path:
            paths.append(self._shared_res_path)
        return paths

    def _is_shared_path(self, file_path: Path) -> bool:
        """Check if file path is in shared directory."""
        if not self._shared_res_path:
            return False
        return file_path.is_relative_to(self._shared_res_path)

    def _get_from_shared(self, name: str):
        """Get resource from shared directory by name."""
        if not self._shared_res_path:
            return None

        from sqlmodel import select

        query = select(self._model_class).where(
            self._model_class.name == name,
            self._model_class.path.startswith(str(self._shared_res_path)),
        )
        return self.session.exec(query).first()

    def _get_from_project_or_shared(self, name: str):
        """Get resource with project taking priority over shared.

        Returns:
            Resource instance or None.
        """
        # Try project first, fall back to shared
        return self._get_from_project(name) or self._get_from_shared(name)

    def _delete_by_name(self, name: str, from_shared: bool = False) -> bool:
        """Delete resource by name from database and filesystem.

        Args:
            name: Resource name.
            from_shared: Target shared storage if True, project storage otherwise.

        Returns:
            Whether the resource was deleted.
        """
        if from_shared:
            resource = self._get_from_shared(name)
            self._check_rw_shared()
        else:
            resource = self._get_from_project(name)
            self._check_rw()

        if not resource:
            return False

        file_path = Path(resource.path)
        with self.file_tx_factory(file_path):
            self.md_file_manager.delete_file(file_path)
            self.session.delete(resource)
            self.session.commit()

        logger.info(
            f"Deleted resource: {resource.id}",
            extra={
                "event.name": "resource.delete",
                "event.domain": "persistence",
                "event.outcome": "success",
                "resource.id": resource.id,
            },
        )
        return True
