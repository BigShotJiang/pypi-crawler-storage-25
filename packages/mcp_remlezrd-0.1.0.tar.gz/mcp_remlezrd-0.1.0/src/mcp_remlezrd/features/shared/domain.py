from abc import abstractmethod
from datetime import UTC, datetime
import logging
from pathlib import Path
import re
from typing import Annotated, Any, TypeVar

from pydantic import AfterValidator, field_validator
from sqlalchemy.dialects.sqlite import JSON
from sqlmodel import Field, SQLModel
import tiktoken

logger = logging.getLogger(__name__)

# TypeVar for generic return types
T = TypeVar("T", bound="ResourceBase")

# ShareableSkill-compatible name pattern
NAME_PATTERN = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$")


class ResourceBase(SQLModel):
    """Base model for all MCP resources following resource-base policy.

    Provides common fields required by all resource types:
    - Identity fields (id, path)
    - Content fields (name, description, tags, content)
    - Timestamp fields (created_at, updated_at)
    """

    # Identity Fields
    id: str = Field(primary_key=True, description="Primary key with pattern {prefix}_{name} or +{prefix}_{name} for shared")
    path: str = Field(index=True, unique=True, description="Absolute filesystem path")

    # Content Fields
    name: str = Field(
        description="Resource name (1-64 chars, lowercase alphanumeric and hyphens, no leading/trailing hyphen)",
    )
    description: str = Field(description="Brief resource description")
    tags: list[str] = Field(default_factory=list, sa_type=JSON, description="Classification tags")
    # Note: content is NOT stored in DB anymore - generated dynamically via to_markdown()

    # Timestamp Fields
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="Resource creation timestamp (immutable)",
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="Last modification timestamp (auto-updated)",
    )

    # Metadata Field (common to all resources)
    extra_metadata: dict[str, Any] | None = Field(
        default=None,
        sa_type=JSON,
        description="Arbitrary key-value mapping for additional metadata.",
    )

    @field_validator("created_at", "updated_at", mode="before")
    @classmethod
    def validate_datetime_fields(cls, v: datetime | str) -> datetime:
        """Validate datetime fields, converting ISO strings to datetime objects."""
        if isinstance(v, str):
            # Parse ISO format string to datetime
            try:
                return datetime.fromisoformat(v.replace("Z", "+00:00"))
            except ValueError as e:
                raise ValueError(f"Invalid datetime format: {v}") from e
        return v

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate name follows ShareableSkill specification.

        Rules:
        - 1-64 characters
        - Lowercase letters, numbers, and hyphens only
        - Must not start or end with hyphen
        - Must not contain consecutive hyphens
        """
        if not v:
            raise ValueError("Name cannot be empty")

        if len(v) > 64:
            raise ValueError(f"Name must be 64 characters or less, got {len(v)}")

        if not NAME_PATTERN.match(v):
            raise ValueError(
                f"Name '{v}' must contain only lowercase letters, numbers, and hyphens, and must not start or end with a hyphen"
            )

        # Check for consecutive hyphens
        if "--" in v:
            raise ValueError(f"Name '{v}' must not contain consecutive hyphens")

        return v

    @field_validator("tags")
    @classmethod
    def validate_tags(cls, v: list[str]) -> list[str]:
        """Validate tags are non-empty strings."""
        if not isinstance(v, list):
            raise ValueError("Tags must be a list")

        validated_tags: list[str] = []
        for tag in v:
            if not isinstance(tag, str):
                raise ValueError("All tags must be strings")
            tag = tag.strip()
            if tag:  # Only add non-empty tags
                validated_tags.append(tag)

        return validated_tags

    @field_validator("path")
    @classmethod
    def validate_path(cls, v: str) -> str:
        """Validate path is absolute and normalized."""
        if not v:
            raise ValueError("Path cannot be empty")

        path_obj = Path(v)
        if not path_obj.is_absolute():
            raise ValueError("Path must be absolute")

        return str(path_obj.resolve())

    def _update_timestamp(self) -> None:
        """Update the updated_at timestamp to current time."""
        self.updated_at = datetime.now(UTC)

    @abstractmethod
    def to_frontmatter(self) -> dict[str, Any]:
        """Convert model fields to frontmatter dict."""
        raise NotImplementedError()

    @abstractmethod
    def to_markdown(self) -> str:
        """Generate markdown content from structured fields.

        Each entity implements its own rendering logic using Pydantic models
        from its content_strategy module.
        """
        raise NotImplementedError()

    @property
    def estimated_tokens(self) -> int:
        """Calculate estimated token count using tiktoken o200k_base encoding.

        Returns:
            Number of tokens in the rendered markdown content.
        """
        enc = tiktoken.get_encoding("o200k_base")
        return len(enc.encode(self.to_markdown()))

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}(id={self.id}, name={self.name!r})>"


class ShareableResourceBase(ResourceBase):
    """Base class for shareable resources with license and compatibility metadata.

    Resources that can be shared across projects (ShareableRule, ShareableSkill) inherit
    from this class to get license and compatibility fields with their validators.
    """

    license: str | None = Field(
        default=None,
        description="License name or reference to a bundled license file.",
    )
    compatibility: str | None = Field(
        default=None,
        description="Max 500 characters. Indicates environment requirements (intended product, system packages, network access, etc.)",
    )

    @field_validator("license")
    @classmethod
    def validate_license(cls, v: str | None) -> str | None:
        """Validate license is either SPDX identifier or relative file path.

        Examples:
        - SPDX: "MIT", "Apache-2.0", "GPL-3.0-or-later"
        - File path: "LICENSE", "licenses/CUSTOM.txt"
        """
        if not v:
            return None

        v = v.strip()
        if not v:
            return None

        # If it looks like a path (contains / or has file extension), validate as file
        if "/" in v or v.endswith((".md", ".txt", ".rst")):
            if v.startswith("/") or ".." in v:
                raise ValueError(f"License file path must be relative and safe: {v}")
            return v

        # Otherwise validate as SPDX identifier (letters, numbers, dots, hyphens)
        if not re.match(r"^[A-Za-z0-9\.\-]+$", v):
            raise ValueError(f"License must be SPDX identifier (e.g., 'MIT', 'Apache-2.0') or relative file path: {v}")

        return v

    @field_validator("compatibility")
    @classmethod
    def validate_compatibility(cls, v: str | None) -> str | None:
        """Validate compatibility is within max length (500 chars)."""
        if not v:
            return None

        v = v.strip()
        if not v:
            return None

        if len(v) > 500:
            raise ValueError(f"Compatibility must be 500 characters or less, got {len(v)}")

        return v


# =============================================================================
# Shared Markdown validators
# =============================================================================


def _reject_horizontal_rule(v: str) -> None:
    """Raise ValueError if the stripped content is or begins with a horizontal rule."""
    stripped = v.strip()
    if stripped in ("***", "---", "___") or re.match(r"^\*{3,}$|^-{3,}$|^_{3,}$", stripped):
        raise ValueError("Horizontal rules are not allowed.")


def _reject_fenced_code(v: str) -> None:
    """Raise ValueError if the stripped content starts with a fenced code block delimiter."""
    stripped = v.strip()
    if stripped.startswith(("```", "~~~")):
        raise ValueError("Fenced code block delimiters are not allowed.")


def _reject_heading(v: str) -> None:
    """Raise ValueError if the stripped content starts with a markdown heading."""
    if re.match(r"^#{1,6}\s", v.strip()):
        raise ValueError("Markdown headings are not allowed.")


def _reject_table_row(v: str) -> None:
    """Raise ValueError if the stripped content appears to be a markdown table row.

    Heuristic: starts and ends with `|` and contains at least one additional pipe.
    """
    stripped = v.strip()
    if stripped.startswith("|") and stripped.endswith("|") and "|" in stripped[1:-1]:
        raise ValueError("Markdown table rows are not allowed.")


def _reject_line_breaks(v: str) -> None:
    """Raise ValueError if the content contains any line break.

    Intended for fields that must be a single paragraph.
    """
    if "\n" in v or "\r" in v:
        raise ValueError("Must be a single line. No line breaks allowed.")


def _validate_simple_markdown_paragraph(v: str) -> str:
    """Validate a single plain-text line with no block-level markdown elements.

    Rejects: line breaks, horizontal rules, fenced code blocks, headings, table rows.
    """
    _reject_line_breaks(v)
    _reject_horizontal_rule(v)
    _reject_fenced_code(v)
    _reject_heading(v)
    _reject_table_row(v)
    return v


SimpleMarkdownParagraph = Annotated[str, AfterValidator(_validate_simple_markdown_paragraph)]
"""A single plain-text paragraph without any markdown block formatting.

Use for list items, dict values, and short text that must render as a single line.
"""

SimpleMarkdownParagraphs = list[SimpleMarkdownParagraph]
"""A list of plain-text paragraphs without markdown block formatting.

Use for multi-paragraph narrative content where each paragraph renders as a single line
with an empty line separating paragraphs in the generated Markdown.
"""


def _validate_markdown_list_item(v: str) -> str:
    """Validate a markdown list item: single line with no leading bullet marker."""
    _validate_simple_markdown_paragraph(v)

    stripped = v.strip()
    if stripped.startswith(("- ", "* ")):
        raise ValueError(
            "List item must not be prefixed with markdown bullet markers ('- ' or '* '). "
            "Provide the plain text content only; the renderer adds the bullet."
        )
    return v


MarkdownListItem = Annotated[str, AfterValidator(_validate_markdown_list_item)]
"""A single plain-text line suitable for rendering as a markdown list item.

Extends SimpleMarkdownParagraph by rejecting bullet prefixes.
Use for all fields typed as list[str] or dict[str, list[str]] values.
"""

MarkdownList = list[MarkdownListItem]
"""A list of markdown list item values.

Use for fields typed as list[str] that render as markdown bullet list items.
"""


def _validate_simple_markdown_content(v: str) -> str:
    """Validate multi-line content that must not contain block-level elements that break section structure.

    Rejects: horizontal rules, fenced code blocks, headings, table rows.
    """
    _reject_horizontal_rule(v)
    _reject_fenced_code(v)
    _reject_heading(v)
    _reject_table_row(v)
    return v


SimpleMarkdownContent = Annotated[str, AfterValidator(_validate_simple_markdown_content)]
"""Multi-line markdown content without block-level structure violations.

Use for narrative sections (Context and Problem Statement, Usage Context)
that may contain paragraphs, lists, and inline markdown.
"""


def _validate_free_markdown_content(v: str) -> str:
    """Validate multi-line content allowing fenced code blocks but rejecting other block-level elements.

    Rejects: horizontal rules, headings, table rows.
    """
    _reject_horizontal_rule(v)
    _reject_heading(v)
    _reject_table_row(v)
    return v


RichMarkdownContent = Annotated[str, AfterValidator(_validate_free_markdown_content)]
"""Multi-line markdown content allowing fenced code blocks.

Use for sections where code examples may appear.
"""
