"""Shared markdown parsing exceptions.

Provides common exception types for markdown parsing errors.
The actual parsing is now handled by marko in individual content_strategy modules.
"""


class SectionNotFoundError(ValueError):
    """Raised when a requested section is not found in the document.

    This is normal behavior for optional sections.
    """

    pass


class SectionParsingError(ValueError):
    """Raised when a section is found but its content cannot be parsed correctly.

    This indicates a malformed section that needs investigation.
    """

    pass
