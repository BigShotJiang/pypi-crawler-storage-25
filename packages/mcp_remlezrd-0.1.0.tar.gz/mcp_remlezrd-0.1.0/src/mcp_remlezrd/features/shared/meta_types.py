"""Shared metadata schemas for features."""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class AppMeta:
    """Application-level metadata."""

    pretty_name: str
    server_name: str
    app_name: str


@dataclass(frozen=True, slots=True)
class ScopeMeta:
    """Canonical metadata for a server scope."""

    pretty_name: str
    scope_type: str
    tag: str


@dataclass(frozen=True, slots=True)
class ResourceMeta:
    """Canonical metadata for a resource type."""

    pretty_name: str
    resource_type: str
    pretty_plural: str
    short_plural: str
    tag: str
    create_tool: str
    update_tool: str
    delete_tool: str
    discover_tool: str
    base_uri: str
    shared_base_uri: str
    resource_component: str
    shared_resource_component: str
