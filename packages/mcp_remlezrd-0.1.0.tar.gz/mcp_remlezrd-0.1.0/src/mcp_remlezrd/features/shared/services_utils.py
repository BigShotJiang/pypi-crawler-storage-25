"""Utility functions for resource services.

Standalone functions extracted from BaseResourcesService to improve
modularity and testability without breaking the inheritance structure.
"""

from pathlib import Path

from sqlalchemy import bindparam, text


def sanitize_path(path: Path | str | None) -> str:
    """Extract just the filename from a path for safe logging.

    Prevents exposure of sensitive absolute paths in logs.
    Returns only the filename (e.g., 'file.md' instead of '/home/user/project/file.md').

    Args:
        path: Path to sanitize (Path object, string, or None)

    Returns:
        Filename only, safe for logging (or "<none>" if path is None)
    """
    if path is None:
        return "<none>"
    return Path(path).name


def build_tags_filter_condition(tags: list[str]) -> list:
    """Build SQL JSON filter conditions for tags using SQLite json_each().

    This function creates SQL conditions to filter resources by tags stored
    as JSON arrays in SQLite. Uses the json_each() function from JSON1 extension.

    Args:
        tags: List of tag strings to filter by

    Returns:
        List of SQL text conditions for use with sqlalchemy.or_()

    Example:
        query = select(Model)
        if tags:
            conditions = build_tags_filter_condition(tags)
            query = query.where(or_(*conditions))
    """
    conditions = []
    for tag in tags:
        # Use json_each to iterate over JSON array elements
        # Use bindparam with unique=True to avoid name collisions
        condition = text("EXISTS (SELECT 1 FROM json_each(tags) WHERE value = :tag_value)").bindparams(
            bindparam("tag_value", value=tag, unique=True)
        )
        conditions.append(condition)
    return conditions


def scan_files(resources_dir: Path) -> dict[Path, tuple[float, int]]:
    """Scan a single directory for .md files.

    Args:
        resources_dir: Directory to scan for .md files

    Returns:
        Dictionary mapping file paths to (mtime, size) tuples
    """
    files: dict[Path, tuple[float, int]] = {}

    if resources_dir.exists():
        for file_path in resources_dir.rglob("*.md"):
            stat = file_path.stat()
            files[file_path] = (stat.st_mtime, stat.st_size)

    return files
