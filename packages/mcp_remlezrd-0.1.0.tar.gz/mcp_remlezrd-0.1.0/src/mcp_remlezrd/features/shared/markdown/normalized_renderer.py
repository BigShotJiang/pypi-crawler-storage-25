"""Markdown normalization utilities.

Provides a Marko renderer that collapses cosmetic soft line breaks to spaces,
making IDE auto-formatting transparent to downstream parsers.
"""

from marko import Markdown
from marko.inline import LineBreak
from marko.md_renderer import MarkdownRenderer


class NormalizedMarkdownRenderer(MarkdownRenderer):
    """Renderer that converts soft line breaks to spaces.

    Soft breaks (cosmetic wrapping by IDE formatters) are collapsed to a single
    space, matching CommonMark semantics. Hard breaks (intentional, via trailing
    spaces or backslash before newline) are preserved.
    """

    def render_line_break(self, element: LineBreak) -> str:
        """Normalize soft breaks to spaces, preserving hard breaks."""
        if element.soft:
            return " "
        return "\\\n"


def normalize_markdown(content: str) -> str:
    """Normalize markdown content by collapsing soft line breaks to spaces.

    This makes IDE auto-formatting transparent to downstream parsers and
    validators. The operation is idempotent: normalize(normalize(x)) == normalize(x).

    Args:
        content: Raw markdown content that may contain cosmetic line breaks.

    Returns:
        Normalized markdown with soft breaks collapsed to spaces.
    """
    return Markdown(renderer=NormalizedMarkdownRenderer).convert(content)
