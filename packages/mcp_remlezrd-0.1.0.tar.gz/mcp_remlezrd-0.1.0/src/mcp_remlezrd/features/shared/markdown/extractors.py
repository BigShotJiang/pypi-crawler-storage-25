"""Text extraction utilities from markdown elements."""

from marko import block, inline

from mcp_remlezrd.features.shared.exceptions import SectionParsingError

from .renderers import render_element_to_markdown


def extract_h1_preamble(doc: block.Document) -> list[str]:
    """Extract rendered paragraph elements between the first H1 and the first H2.

    Skips blank lines and headings. Returns individual rendered block elements
    as a list (source of truth), matching RawSection.parts semantics.

    Args:
        doc: Parsed marko document.

    Returns:
        List of rendered markdown strings (one per block element).
    """
    parts: list[str] = []
    after_h1 = False
    for elem in doc.children:
        if isinstance(elem, block.Heading) and elem.level == 1:
            after_h1 = True
            continue
        if isinstance(elem, block.Heading) and elem.level == 2:
            break
        if after_h1:
            if isinstance(elem, block.BlankLine):
                continue
            rendered = render_element_to_markdown(elem)
            if rendered:
                parts.append(rendered)
    return parts


def _extract_plain_text(elem: block.Element | inline.InlineElement) -> str:
    """Extract plain text from a marko element, stripping all markdown formatting.

    Returns:
        Plain text content.
    """
    texts: list[str] = []

    def traverse(node: object) -> None:
        # RawText is the marko type for actual text content in inline elements
        if isinstance(node, inline.RawText):
            texts.append(node.children)
            return
        # Handle elements with children attribute
        if hasattr(node, "children"):
            if isinstance(node.children, str):
                # Some inline elements (CodeSpan, Link, etc.) store text directly
                texts.append(node.children)
            elif isinstance(node.children, list):
                for child in node.children:
                    traverse(child)

    traverse(elem)
    return "".join(texts).strip()


def get_heading_title(heading_elem: block.Heading) -> str:
    """Extract plain text from a heading element (H1-H6).

    Used for section title extraction where formatting is not needed.
    Strips all inline formatting (bold, italic, links, etc.).

    Args:
        heading_elem: A marko heading element

    Returns:
        Plain text title without formatting
    """
    return _extract_plain_text(heading_elem)


def _parse_key_value_item(
    elem: block.ListItem | block.Paragraph,
    section_name: str,
) -> tuple[str, str]:
    """Parse a key:value item from a list item or paragraph.

    Expected format: ``**key**: value`` or ``key: value``.
    The key's emphasis/bold markers are stripped; the value is preserved as markdown.

    Args:
        elem: Element containing ``key: value``.
        section_name: Section name for error messages.

    Returns:
        Tuple of ``(key, value)``.

    Raises:
        SectionParsingError: If the item doesn't contain a ``:`` separator.
    """
    full_text = render_element_to_markdown(elem)
    if not full_text:
        return "", ""

    if ":" not in full_text:
        raise SectionParsingError(f"Item in section '{section_name}' must be in format 'key: value', got: {full_text[:50]}")

    _, value_part = full_text.split(":", 1)
    key_plain = _extract_plain_text(elem).split(":", 1)[0].strip()
    value_rendered = value_part.strip()

    return key_plain, value_rendered
