"""Markdown rendering utilities."""

from marko import block
from marko.md_renderer import MarkdownRenderer


def render_element_to_markdown(elem: block.Element) -> str:
    """Render a marko element back to markdown string.

    Preserves original formatting including emphasis, links, code spans, etc.
    Uses marko's MarkdownRenderer for accurate round-trip conversion.

    A new MarkdownRenderer instance is created per call because marko's
    renderer is not thread-safe (stores state during rendering).

    Args:
        elem: A marko element (paragraph, list_item, etc.)

    Returns:
        Markdown string representation of the element
    """
    renderer = MarkdownRenderer()
    return renderer.render(elem).strip()
