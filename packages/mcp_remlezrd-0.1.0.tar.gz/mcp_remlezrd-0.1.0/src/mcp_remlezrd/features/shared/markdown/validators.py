"""Validation utilities for markdown sections."""

from marko import block

from mcp_remlezrd.features.shared.exceptions import SectionParsingError

from .extractors import get_heading_title
from .iterators import iter_h2_section_elements


def validate_no_unexpected_h2_sections(doc: block.Document, allowed: set[str]) -> None:
    """Check for unexpected H2 sections in document.

    Args:
        doc: Parsed marko document
        allowed: Set of allowed H2 section names

    Raises:
        SectionParsingError: If an unexpected H2 section is found
    """
    for elem in doc.children:
        match elem:
            case block.Heading(level=2):
                title = get_heading_title(elem)
                if title and title not in allowed:
                    raise SectionParsingError(f"Unexpected section: {title}")


def validate_no_unexpected_h3_sections_in_h2_section(doc: block.Document, h2_section_name: str, allowed: set[str]) -> None:
    """Check for unexpected H3 subsections within an H2 section.

    Args:
        doc: Parsed marko document
        h2_section_name: Name of the parent H2 section to check
        allowed: Set of allowed H3 subsection names

    Raises:
        SectionNotFoundError: If the H2 section is not found
        SectionParsingError: If an unexpected H3 subsection is found
    """
    for elem in iter_h2_section_elements(doc, h2_section_name):
        match elem:
            case block.Heading(level=3):
                title = get_heading_title(elem)
                if title and title not in allowed:
                    raise SectionParsingError(f"Unexpected H3 subsection in '{h2_section_name}': {title}")
