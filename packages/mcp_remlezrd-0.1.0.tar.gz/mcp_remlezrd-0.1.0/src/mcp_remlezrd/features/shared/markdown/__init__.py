"""Markdown parsing utilities.

Provides iterators, extractors, renderers and validators for markdown processing.
"""

from .extractors import _extract_plain_text, _parse_key_value_item, extract_h1_preamble, get_heading_title
from .iterators import (
    iter_h2_section_elements,
    iter_h3_section_elements_in_h2_section,
    iter_h3_section_names_in_h2_section,
)
from .renderers import render_element_to_markdown
from .validators import (
    validate_no_unexpected_h2_sections,
    validate_no_unexpected_h3_sections_in_h2_section,
)

__all__ = [
    # Iterators
    "iter_h2_section_elements",
    "iter_h3_section_elements_in_h2_section",
    "iter_h3_section_names_in_h2_section",
    # Extractors
    "_extract_plain_text",
    "_parse_key_value_item",
    "extract_h1_preamble",
    "get_heading_title",
    # Renderers
    "render_element_to_markdown",
    # Validators
    "validate_no_unexpected_h2_sections",
    "validate_no_unexpected_h3_sections_in_h2_section",
]
