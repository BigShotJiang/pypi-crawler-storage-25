"""Section iteration utilities for markdown documents."""

from collections.abc import Iterator

from marko import block

from mcp_remlezrd.features.shared.exceptions import SectionNotFoundError

from .extractors import get_heading_title


def iter_h2_section_elements(doc: block.Document, section_name: str) -> Iterator[block.Element]:
    """Yield elements belonging to the named H2 section.

    Iterates through the document's top-level children, yielding every element
    between the target H2 heading and the next H2 heading (or end of document).

    Args:
        doc: Parsed marko document
        section_name: Name of the H2 section to iterate over

    Yields:
        Each marko block element within the section

    Raises:
        SectionNotFoundError: If the section is not found in the document
    """
    in_section = False
    section_found = False

    for elem in doc.children:
        match elem:
            case block.Heading(level=2):
                title = get_heading_title(elem)
                if title == section_name:
                    in_section = True
                    section_found = True
                    continue
                elif in_section:
                    break

        if in_section:
            yield elem

    if not section_found:
        raise SectionNotFoundError(f"Section '{section_name}' not found")


def iter_h3_section_elements_in_h2_section(doc: block.Document, h2_section_name: str, h3_section_name: str) -> Iterator[block.Element]:
    """Yield elements belonging to an H3 subsection within an H2 section.

    Iterates through elements within the named H2 section, yielding every element
    between the target H3 heading and the next H3 or H2 heading.

    Args:
        doc: Parsed marko document
        h2_section_name: Name of the parent H2 section
        h3_section_name: Name of the H3 subsection to iterate over

    Yields:
        Each marko block element within the H3 subsection

    Raises:
        SectionNotFoundError: If the H2 section or H3 subsection is not found
    """
    in_h3 = False
    h3_found = False

    for elem in iter_h2_section_elements(doc, h2_section_name):
        match elem:
            case block.Heading(level=3):
                title = get_heading_title(elem)
                if title == h3_section_name:
                    in_h3 = True
                    h3_found = True
                    continue
                elif in_h3:
                    # Another H3 - exit this H3 subsection
                    break

        if in_h3:
            yield elem

    if not h3_found:
        raise SectionNotFoundError(f"H3 subsection '{h3_section_name}' not found in '{h2_section_name}'")


def iter_h3_section_names_in_h2_section(doc: block.Document, h2_section_name: str) -> Iterator[str]:
    """Yield H3 subsection names within an H2 section without raising.

    Unlike iter_h3_section_elements_in_h2_section, this does not raise
    if the H2 section exists but has no H3 - it simply yields nothing.

    Args:
        doc: Parsed marko document
        h2_section_name: Name of the parent H2 section

    Yields:
        H3 subsection names (plain text)
    """
    try:
        for elem in iter_h2_section_elements(doc, h2_section_name):
            if isinstance(elem, block.Heading) and elem.level == 3:
                yield get_heading_title(elem)
    except SectionNotFoundError:
        # H2 doesn't exist, nothing to iterate
        return
