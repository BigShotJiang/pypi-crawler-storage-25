"""Shared constants across all features."""

# Mode tags (common to all features)
TAG_MODE_RO = "mode:ro"
TAG_MODE_RW = "mode:rw"
