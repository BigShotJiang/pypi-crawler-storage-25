"""Application metadata instance."""

from .meta_types import AppMeta

APP = AppMeta(
    pretty_name="RemLezrd",
    server_name="remlezrd",
    app_name="mcp-remlezrd",
)
