"""Shared Pydantic models for content structures.

Provides reusable BaseModel classes for common content patterns
across all content strategy features.
"""

from typing import Self

from marko import block
from marko.block import Document
from pydantic import BaseModel, Field

from mcp_remlezrd.features.shared.exceptions import SectionParsingError
from mcp_remlezrd.features.shared.markdown import (
    iter_h2_section_elements,
    iter_h3_section_elements_in_h2_section,
    render_element_to_markdown,
)


class CodeBlock(BaseModel):
    """Represents a fenced code block with language and content.

    Immutable model with factory methods for parsing from marko elements
    and rendering back to markdown.
    """

    model_config = {"frozen": True}

    lang: str = Field(
        default="text",
        description="Language identifier (e.g., 'python', 'bash'). Defaults to 'text'.",
    )
    content: str = Field(
        ...,
        min_length=1,
        description="Code content (must be non-empty after stripping)",
    )

    @classmethod
    def from_fenced_code(cls, elem: block.FencedCode) -> Self | None:
        """Create a CodeBlock from a marko FencedCode element.

        Args:
            elem: A FencedCode block element from marko

        Returns:
            CodeBlock instance if content exists, None otherwise
        """
        if not elem.children:
            return None

        first_child = elem.children[0]
        content = ""
        if hasattr(first_child, "children") and isinstance(first_child.children, str):
            content = first_child.children.rstrip("\n")

        if not content:
            return None

        # Default to "text" if no language specified
        lang = elem.lang or "text"

        return cls(lang=lang, content=content)

    def render(self) -> str:
        """Render the code block as markdown string.

        Returns:
            Markdown string with fences (no leading/trailing newlines)
        """
        return f"```{self.lang}\n{self.content}\n```"

    def __bool__(self) -> bool:
        """Always True since content is validated non-empty."""
        return True


class RawSection(BaseModel):
    r"""Section containing raw markdown content (H2 or H3).

    'parts' stores individual rendered block elements as a list (source of truth).
    'content' is a computed property joining parts with '\\n\\n'.

    Replaces extract_h2_section_raw() and extract_h3_section_raw_in_h2_section().
    """

    model_config = {"frozen": True}

    name: str = Field(..., description="Section name (heading text)")
    parts: list[str] = Field(default_factory=list, description="Paragraph-level parts")

    @property
    def content(self) -> str:
        """Raw markdown content, assembled from parts."""
        return "\n\n".join(self.parts)

    @classmethod
    def from_h2(cls, doc: Document, name: str) -> Self:
        """Parse an H2 section from the document.

        Args:
            doc: Parsed marko document
            name: H2 section name to extract

        Returns:
            RawSection instance

        Raises:
            SectionNotFoundError: If section not found
        """
        parts: list[str] = []
        for elem in iter_h2_section_elements(doc, name):
            rendered = render_element_to_markdown(elem)
            if rendered:
                parts.append(rendered)

        return cls(name=name, parts=parts)

    @classmethod
    def from_content_str(cls, name: str, content: str) -> Self:
        r"""Create from a pre-assembled content string.

        Splits on '\\n\\n' to populate parts. Used by renderers that hold
        a single string and need to reconstruct element-level parts.
        """
        if not content:
            return cls(name=name, parts=[])
        parts = [p.strip() for p in content.split("\n\n") if p.strip()]
        return cls(name=name, parts=parts)

    @classmethod
    def from_h3(cls, doc: Document, parent_h2: str, name: str) -> Self:
        """Parse an H3 subsection within an H2 section.

        Args:
            doc: Parsed marko document
            parent_h2: Parent H2 section name
            name: H3 subsection name to extract

        Returns:
            RawSection instance

        Raises:
            SectionNotFoundError: If section not found
        """
        parts: list[str] = []
        for elem in iter_h3_section_elements_in_h2_section(doc, parent_h2, name):
            rendered = render_element_to_markdown(elem)
            if rendered:
                parts.append(rendered)

        return cls(name=name, parts=parts)

    def render(self, level: int = 2) -> str:
        """Render the section as markdown string.

        Args:
            level: Heading level (2 for H2, 3 for H3)

        Returns:
            Markdown string with heading and content
        """
        prefix = "#" * level
        if not self.parts:
            return f"{prefix} {self.name}"
        return f"{prefix} {self.name}\n\n{self.content}"


class ListSection(BaseModel):
    """Section containing a list of items (H2 or H3).

    Replaces extract_h2_section_list() and extract_h3_section_list_in_h2_section().
    Supports optional preamble text before the list.
    """

    model_config = {"frozen": True}

    name: str = Field(..., description="Section name (heading text)")
    preamble: str | None = Field(default=None, description="Optional text before the list")
    items: list[str] = Field(default_factory=list, description="List item strings")

    @classmethod
    def _parse_list_from_iterator(
        cls,
        iterator,
        name: str,
        strict: bool,
        error_prefix: str,
    ) -> Self:
        """Parse list items and optional preamble from an element iterator.

        Args:
            iterator: Marko block element iterator.
            name: Section name.
            strict: Raise on non-list elements if True.
            error_prefix: Error message prefix.

        Returns:
            Parsed ``ListSection``.

        Raises:
            SectionParsingError: If ``strict=True`` and a non-list element is found.
        """
        preamble_parts: list[str] = []
        items: list[str] = []
        list_started = False

        for elem in iterator:
            match elem:
                case block.List():
                    list_started = True
                    for item in elem.children:
                        if isinstance(item, block.ListItem):
                            rendered = render_element_to_markdown(item)
                            if rendered:
                                items.append(rendered)
                case block.Paragraph() if not list_started and not strict:
                    # Capture preamble text only if not strict
                    rendered = render_element_to_markdown(elem)
                    if rendered:
                        preamble_parts.append(rendered)
                case block.BlankLine():
                    continue
                case _ if strict:
                    raise SectionParsingError(f"{error_prefix} '{name}' should contain only a list, found: {type(elem).__name__}")

        preamble = "\n\n".join(preamble_parts) if preamble_parts else None
        return cls(name=name, preamble=preamble, items=items)

    @classmethod
    def from_h2(cls, doc: Document, name: str, *, strict: bool = True) -> Self:
        """Parse an H2 section containing a list.

        Args:
            doc: Parsed marko document
            name: H2 section name to extract
            strict: If True, raise error for non-list elements

        Returns:
            ListSection instance

        Raises:
            SectionNotFoundError: If section not found
            SectionParsingError: If strict=True and non-list element found
        """
        from mcp_remlezrd.features.shared.markdown import iter_h2_section_elements

        return cls._parse_list_from_iterator(
            iter_h2_section_elements(doc, name),
            name=name,
            strict=strict,
            error_prefix="Section",
        )

    @classmethod
    def from_h3(cls, doc: Document, parent_h2: str, name: str, *, strict: bool = True) -> Self:
        """Parse an H3 subsection containing a list.

        Args:
            doc: Parsed marko document
            parent_h2: Parent H2 section name
            name: H3 subsection name to extract
            strict: If True, raise error for non-list elements

        Returns:
            ListSection instance

        Raises:
            SectionNotFoundError: If section not found
            SectionParsingError: If strict=True and non-list element found
        """
        from mcp_remlezrd.features.shared.markdown import iter_h3_section_elements_in_h2_section

        return cls._parse_list_from_iterator(
            iter_h3_section_elements_in_h2_section(doc, parent_h2, name),
            name=name,
            strict=strict,
            error_prefix="H3 subsection",
        )

    def render(self, level: int = 2) -> str:
        """Render the section as markdown string.

        Args:
            level: Heading level (2 for H2, 3 for H3)

        Returns:
            Markdown string with heading, optional preamble, and bullet list
        """
        prefix = "#" * level
        lines = [f"{prefix} {self.name}", ""]
        if self.preamble:
            lines.extend([self.preamble, ""])
        for item in self.items:
            lines.append(f"- {item}")
        return "\n".join(lines)


class KeyValueSection(BaseModel):
    """Section containing key:value pairs (H2 or H3).

    Replaces extract_h2_section_list_as_dict() and extract_h3_section_list_as_dict_in_h2_section().
    """

    model_config = {"frozen": True}

    name: str = Field(..., description="Section name (heading text)")
    items: dict[str, str] = Field(default_factory=dict, description="Key-value pairs")

    @classmethod
    def from_h2(cls, doc: Document, name: str) -> Self:
        """Parse an H2 section containing key:value pairs.

        Args:
            doc: Parsed marko document
            name: H2 section name to extract

        Returns:
            KeyValueSection instance

        Raises:
            SectionNotFoundError: If section not found
            SectionParsingError: If invalid format found
        """
        from mcp_remlezrd.features.shared.markdown import (
            _parse_key_value_item,
            iter_h2_section_elements,
        )

        result: dict[str, str] = {}
        for elem in iter_h2_section_elements(doc, name):
            match elem:
                case block.List():
                    for item in elem.children:
                        if not isinstance(item, block.ListItem):
                            continue
                        key, value = _parse_key_value_item(item, name)
                        if key:
                            result[key] = value
                case block.BlankLine():
                    continue
                case block.Paragraph():
                    key, value = _parse_key_value_item(elem, name)
                    if key:
                        result[key] = value
                case _:
                    raise SectionParsingError(f"Section '{name}' should contain only list items, found: {type(elem).__name__}")

        return cls(name=name, items=result)

    @classmethod
    def from_h3(cls, doc: Document, parent_h2: str, name: str) -> Self:
        """Parse an H3 subsection containing key:value pairs.

        Args:
            doc: Parsed marko document
            parent_h2: Parent H2 section name
            name: H3 subsection name to extract

        Returns:
            KeyValueSection instance

        Raises:
            SectionNotFoundError: If section not found
            SectionParsingError: If invalid format found
        """
        from mcp_remlezrd.features.shared.markdown import (
            _parse_key_value_item,
            iter_h3_section_elements_in_h2_section,
        )

        result: dict[str, str] = {}
        for elem in iter_h3_section_elements_in_h2_section(doc, parent_h2, name):
            match elem:
                case block.List():
                    for item in elem.children:
                        if not isinstance(item, block.ListItem):
                            continue
                        key, value = _parse_key_value_item(item, name)
                        if key:
                            result[key] = value
                case block.BlankLine():
                    continue
                case block.Paragraph():
                    key, value = _parse_key_value_item(elem, name)
                    if key:
                        result[key] = value
                case _:
                    raise SectionParsingError(f"H3 subsection '{name}' should contain only list items, found: {type(elem).__name__}")

        return cls(name=name, items=result)

    def render(self, level: int = 2) -> str:
        """Render the section as markdown string.

        Args:
            level: Heading level (2 for H2, 3 for H3)

        Returns:
            Markdown string with heading and key:value list
        """
        prefix = "#" * level
        lines = [f"{prefix} {self.name}", ""]
        for key, value in self.items.items():
            lines.append(f"- **{key}**: {value}")
        return "\n".join(lines)


# =============================================================================
# Universal Sections (shared across all domains)
# =============================================================================


class ReferencesSection(BaseModel):
    """Section References (optional, present in all domains).

    Universal pattern for References sections containing a simple bullet list.
    """

    model_config = {"frozen": True}
    items: list[str] = Field(default_factory=list, description="Reference items")

    @classmethod
    def from_doc(cls, doc: Document) -> Self:
        """Parse References section from document.

        Args:
            doc: Parsed marko document

        Returns:
            ReferencesSection with items (empty if section not found)
        """
        from contextlib import suppress

        from mcp_remlezrd.features.shared.exceptions import SectionNotFoundError

        with suppress(SectionNotFoundError):
            section = ListSection.from_h2(doc, "References")
            return cls(items=section.items)
        return cls()

    def render(self) -> str:
        """Render the section as markdown string.

        Returns:
            Markdown string with heading and bullet list (empty if no items)
        """
        if not self.items:
            return ""
        lines = ["## References", ""]
        for item in self.items:
            lines.append(f"- {item}")
        return "\n".join(lines)
