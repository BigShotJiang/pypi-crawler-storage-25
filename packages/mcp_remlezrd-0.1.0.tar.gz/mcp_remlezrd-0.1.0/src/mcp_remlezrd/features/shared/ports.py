"""Protocol definitions for clean architecture without circular dependencies."""

from pathlib import Path
from typing import Any, Protocol, Self


class WatchableService(Protocol):
    """Port for services that can be watched for file changes.

    FileWatcherService uses this interface to monitor resource directories
    and trigger reindexation. Decouples FileWatcher from concrete services.
    """

    def get_resources_paths(self) -> list[Path]:
        """Return paths to monitor for changes."""
        ...

    def sync_dirs(self) -> None:
        """Synchronize directories with database (reindexation)."""
        ...


class FileManagerPort(Protocol):
    """Port for file management operations."""

    def parse_file(self, path: Path) -> tuple[dict[str, Any], str]:
        """Parse a file and return its frontmatter data and body content."""
        ...

    def create_file(self, path: Path, frontmatter_data: dict[str, Any], content: str) -> None:
        """Create a new file with the given frontmatter and body content."""
        ...

    def update_file(self, path: Path, frontmatter_data: dict[str, Any] | None, content: str | None) -> None:
        """Update an existing file's frontmatter and/or body content."""
        ...

    def delete_file(self, path: Path) -> None:
        """Delete the file at the given path."""
        ...


class FileTransactionPort(Protocol):
    """Port for atomic file operations with backup/rollback."""

    def __enter__(self) -> Self: ...

    def __exit__(self, exc_type, exc_val, _exc_tb) -> bool: ...
