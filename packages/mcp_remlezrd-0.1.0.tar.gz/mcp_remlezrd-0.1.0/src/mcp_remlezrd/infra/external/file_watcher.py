"""File watching service using watchfiles.

Monitors resource directories and triggers reindexation on changes.
"""

import asyncio
import contextlib
import logging
from pathlib import Path

from watchfiles import Change, awatch

from mcp_remlezrd.features.shared.ports import WatchableService

logger = logging.getLogger(__name__)


class FileWatcherService:
    """Centralized file watcher for all resource services.

    Uses watchfiles (Rust backend) with debouncing.
    Paths are provided by registered services.
    """

    def __init__(
        self,
        # SUGGESTION: Make debounce_ms configurable via settings when needed
        debounce_ms: int = 1000,
    ):
        """Initialize file watcher.

        Args:
            debounce_ms: Debounce time in milliseconds
        """
        self._debounce_ms = debounce_ms
        self._services: list[WatchableService] = []
        self._stop_event = asyncio.Event()
        self._task: asyncio.Task | None = None

        # State tracking to avoid log spam
        self._last_invalid_paths: frozenset[Path] | None = None
        self._last_valid_count: int | None = None
        self._logged_empty_state: bool = False

    def register_service(self, service: WatchableService) -> None:
        """Register a service to watch."""
        self._services.append(service)
        logger.debug(
            "Registered service",
            extra={
                "event.name": "filewatcher.register",
                "event.domain": "infra",
                "service.name": service.__class__.__name__,
            },
        )

    def start(self) -> None:
        """Start watching in background."""
        if self._task is not None:
            logger.warning("FileWatcher already started")
            return

        self._task = asyncio.create_task(self._watch_loop())
        logger.info(
            "FileWatcher started",
            extra={
                "event.name": "filewatcher.start",
                "event.domain": "infra",
                "event.outcome": "success",
            },
        )

    async def stop(self) -> None:
        """Stop watching gracefully."""
        if self._task is None:
            return

        self._stop_event.set()
        self._task.cancel()

        with contextlib.suppress(asyncio.CancelledError):
            await self._task

        self._task = None
        logger.info(
            "FileWatcher stopped",
            extra={
                "event.name": "filewatcher.stop",
                "event.domain": "infra",
                "event.outcome": "success",
            },
        )

    async def _watch_loop(self) -> None:
        """Main watch loop."""
        try:
            while not self._stop_event.is_set():
                # Collect all paths from services
                paths = self._collect_paths()

                if not paths:
                    self._handle_empty_paths()
                    await asyncio.sleep(5.0)
                    continue

                self._handle_paths_available(len(paths))

                valid_paths, invalid_paths = self._partition_paths(paths)

                self._log_invalid_paths_change(valid_paths, invalid_paths)
                self._log_no_valid_paths_warning(valid_paths)

                if not valid_paths:
                    await asyncio.sleep(5.0)
                    continue

                # Log once when we start watching valid paths
                if self._last_valid_count is None or self._last_valid_count == 0:
                    logger.info(
                        f"Started watching {len(valid_paths)} path(s)",
                        extra={
                            "event.name": "filewatcher.watch",
                            "event.domain": "infra",
                            "event.outcome": "success",
                            "paths.count": len(valid_paths),
                        },
                    )

                # Watch with debounce
                try:
                    async for changes in awatch(
                        *[str(p) for p in valid_paths],
                        debounce=self._debounce_ms,
                        stop_event=self._stop_event,
                    ):
                        await self._handle_changes(changes)

                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    # TODO: Implement exponential backoff retry for transient errors
                    # (e.g., permission denied on a path, filesystem unmount, etc.)
                    # SUGGESTION: Add max_retries and circuit breaker pattern
                    logger.error(
                        f"Watch error on paths {valid_paths}: {e}",
                        extra={
                            "event.name": "filewatcher.watch",
                            "event.domain": "infra",
                            "event.outcome": "failure",
                            "error.message": str(e),
                            "paths.valid": [str(p) for p in valid_paths],
                        },
                    )
                    # Brief pause before retry
                    await asyncio.sleep(1.0)

        except asyncio.CancelledError:
            logger.debug(
                "FileWatcher watch loop cancelled",
                extra={
                    "event.name": "filewatcher.watch",
                    "event.domain": "infra",
                },
            )
            raise
        except Exception as e:
            logger.error(
                f"FileWatcher fatal error: {e}",
                extra={
                    "event.name": "filewatcher.watch",
                    "event.domain": "infra",
                    "event.outcome": "failure",
                    "error.message": str(e),
                },
            )
            raise

    def _handle_empty_paths(self) -> None:
        """Log empty paths state only on first occurrence."""
        if not self._logged_empty_state:
            logger.warning(
                "No paths to watch, waiting...",
                extra={
                    "event.name": "filewatcher.watch",
                    "event.domain": "infra",
                    "event.outcome": "unknown",
                },
            )
            self._logged_empty_state = True

    def _handle_paths_available(self, count: int) -> None:
        """Log when paths become available after empty state."""
        if self._logged_empty_state:
            self._logged_empty_state = False
            logger.info(
                f"Now watching {count} path(s)",
                extra={
                    "event.name": "filewatcher.watch",
                    "event.domain": "infra",
                    "event.outcome": "success",
                    "paths.count": count,
                },
            )

    def _partition_paths(self, paths: list[Path]) -> tuple[list[Path], list[Path]]:
        """Separate paths into valid (existent) and invalid (non-existent) lists."""
        valid_paths = [p for p in paths if p.exists()]
        invalid_paths = [p for p in paths if p not in valid_paths]
        return valid_paths, invalid_paths

    def _log_invalid_paths_change(self, valid_paths: list[Path], invalid_paths: list[Path]) -> None:
        """Log when invalid paths change (new missing paths or all paths now exist)."""
        current_invalid = frozenset(invalid_paths)
        if current_invalid != self._last_invalid_paths:
            if invalid_paths:
                logger.warning(
                    f"Skipping non-existent paths: {[str(p) for p in invalid_paths]}",
                    extra={
                        "event.name": "filewatcher.watch",
                        "event.domain": "infra",
                        "event.outcome": "warning",
                        "paths.invalid": [str(p) for p in invalid_paths],
                    },
                )
            elif self._last_invalid_paths:
                # All paths now exist
                logger.info(
                    f"All paths now exist ({len(valid_paths)} valid)",
                    extra={
                        "event.name": "filewatcher.watch",
                        "event.domain": "infra",
                        "event.outcome": "success",
                        "paths.count": len(valid_paths),
                    },
                )
            self._last_invalid_paths = current_invalid

    def _log_no_valid_paths_warning(self, valid_paths: list[Path]) -> None:
        """Log when no valid paths exist, only on state transition."""
        current_valid_count = len(valid_paths)
        if not valid_paths and current_valid_count != self._last_valid_count:
            logger.warning(
                "No valid paths to watch, waiting...",
                extra={
                    "event.name": "filewatcher.watch",
                    "event.domain": "infra",
                    "event.outcome": "warning",
                },
            )
        self._last_valid_count = current_valid_count

    def _collect_paths(self) -> list[Path]:
        """Collect all paths from registered services."""
        paths: list[Path] = []
        for service in self._services:
            paths.extend(service.get_resources_paths())
        return paths

    async def _handle_changes(self, changes: set[tuple[Change, str]]) -> None:
        """Route changes to appropriate services."""
        services_to_refresh: set[WatchableService] = set()

        for _change, path_str in changes:
            path = Path(path_str)

            service = self._find_service_for_path(path)
            if service:
                services_to_refresh.add(service)

        if not services_to_refresh:
            return

        # Refresh services in parallel
        logger.debug(
            f"Refreshing {len(services_to_refresh)} services",
            extra={
                "event.name": "filewatcher.refresh",
                "event.domain": "infra",
                "services.count": len(services_to_refresh),
            },
        )

        await asyncio.gather(*[asyncio.to_thread(service.sync_dirs) for service in services_to_refresh])

    def _find_service_for_path(self, path: Path) -> WatchableService | None:
        """Find service that manages this path."""
        for service in self._services:
            for service_path in service.get_resources_paths():
                if path.is_relative_to(service_path):
                    return service
        return None
