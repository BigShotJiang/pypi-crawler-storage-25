"""Infrastructure package for MCP RemLezrd.

This package contains infrastructure components (database, filesystem, transactions)
that support the business logic layers.
"""

# This package uses direct imports from modules
