# Application logger factory using global settings for MCP RemLezrd.
#
# This module provides ultra-simple logger access using the global settings instance,
# prioritizing DRY/KISS principles over architectural purity.
import logging.config

from ..config import LoggingSettings


def setup_logging(settings: LoggingSettings) -> None:
    """Configure the logging system from a LoggingSettings instance."""
    log_cfg = settings.dict_config
    logging.config.dictConfig(log_cfg)

    logger = logging.getLogger(__name__)
    logger.debug(
        "Logging configured",
        extra={
            "event.name": "server.config",
            "event.domain": "infra",
            "event.outcome": "success",
        },
    )
