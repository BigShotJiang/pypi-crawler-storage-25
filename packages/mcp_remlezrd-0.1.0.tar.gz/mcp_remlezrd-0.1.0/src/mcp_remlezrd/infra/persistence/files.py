import logging
from pathlib import Path
import shutil
from typing import Any, Self

import frontmatter

from mcp_remlezrd.features.shared.ports import FileManagerPort, FileTransactionPort
from mcp_remlezrd.features.shared.services_utils import sanitize_path

logger = logging.getLogger(__name__)


class FileBackupTransaction(FileTransactionPort):
    """Context manager for atomic file operations with backup/restore functionality.

    Implements FileTransactionPort for clean architecture decoupling.

    Provides RAII-style resource management for file operations:
    - Creates backup on enter (if file exists)
    - Restores backup on exception
    - Cleans up backup on success

    Usage:
        with FileBackupTransaction(Path("important.txt")):
            # Modify file - if exception occurs, original is restored
            Path("important.txt").write_text("new content")
    """

    def __init__(self, resource_path: Path):
        """Initialize file backup transaction.

        Args:
            resource_path: Path to file that will be modified
        """
        self.resource_path = resource_path
        self.backup_path: Path | None = None
        self.had_original_file = False

    def __enter__(self) -> Self:
        """Create backup of file if it exists.

        Returns:
            Self for use in 'with ... as' statements
        """
        try:
            if self.resource_path.exists():
                self.had_original_file = True
                # Create backup in same directory with .bak extension
                self.backup_path = self.resource_path.with_suffix(self.resource_path.suffix + ".bak")

                # Copy file with metadata preservation
                shutil.copy2(self.resource_path, self.backup_path)
                logger.debug(
                    f"Created backup: {self.backup_path}",
                    extra={
                        "event.name": "transaction.backup.create",
                        "event.domain": "persistence",
                        "event.outcome": "success",
                        "file.path": sanitize_path(self.backup_path),
                    },
                )
            else:
                self.had_original_file = False
                logger.debug(
                    f"No existing file to backup: {self.resource_path}",
                    extra={
                        "event.name": "transaction.backup.create",
                        "event.domain": "persistence",
                        "file.path": sanitize_path(self.resource_path),
                    },
                )

        except (OSError, PermissionError) as e:
            logger.error(
                f"Failed to create backup of {self.resource_path}: {e}",
                extra={
                    "event.name": "transaction.backup.create",
                    "event.domain": "persistence",
                    "event.outcome": "failure",
                    "file.path": sanitize_path(self.resource_path),
                    "error.message": str(e),
                },
            )
            raise

        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        _exc_tb: Any,
    ) -> bool:
        """Handle cleanup: restore on error, clean up on success.

        Args:
            exc_type: Exception type if exception occurred
            exc_val: Exception value if exception occurred
            _exc_tb: Exception traceback if exception occurred (unused)

        Returns:
            False to let exceptions propagate
        """
        try:
            if exc_type is not None:
                # Exception occurred - restore original file
                self._restore_backup()
                error_msg = str(exc_val) if exc_val else "unknown"
                logger.warning(
                    f"Restored backup due to exception: {exc_type.__name__}",
                    extra={
                        "event.name": "transaction.backup.restore",
                        "event.domain": "persistence",
                        "event.outcome": "success",
                        "error.type": exc_type.__name__,
                        "error.message": error_msg,
                    },
                )
            else:
                # Success - clean up backup
                self._cleanup_backup()
                logger.debug(
                    "Transaction successful, cleaned up backup",
                    extra={
                        "event.name": "transaction.backup.cleanup",
                        "event.domain": "persistence",
                        "event.outcome": "success",
                    },
                )

        except Exception as cleanup_error:
            # Log cleanup errors but don't mask original exception
            logger.error(
                f"Cleanup failed for {self.resource_path}: {cleanup_error}",
                extra={
                    "event.name": "transaction.backup.cleanup",
                    "event.domain": "persistence",
                    "event.outcome": "failure",
                    "file.path": sanitize_path(self.resource_path),
                    "error.message": str(cleanup_error),
                },
            )

        # Always return False to let exceptions propagate
        return False

    def _restore_backup(self) -> None:
        """Restore original file from backup."""
        if self.backup_path and self.backup_path.exists():
            try:
                # Move backup back to original location
                shutil.move(str(self.backup_path), str(self.resource_path))
            except (OSError, PermissionError) as e:
                logger.error(
                    f"Failed to restore backup {self.backup_path}: {e}",
                    extra={
                        "event.name": "transaction.backup.restore",
                        "event.domain": "persistence",
                        "event.outcome": "failure",
                        "file.path": sanitize_path(self.backup_path),
                        "error.message": str(e),
                    },
                )
                raise
        elif self.had_original_file:
            # Had original but no backup - something went wrong
            logger.warning(
                f"Cannot restore {self.resource_path}: backup missing",
                extra={
                    "event.name": "transaction.backup.restore",
                    "event.domain": "persistence",
                    "event.outcome": "failure",
                    "file.path": sanitize_path(self.resource_path),
                },
            )
        else:
            # No original file - remove created file if it exists
            try:
                if self.resource_path.exists():
                    self.resource_path.unlink()
            except (OSError, PermissionError) as e:
                logger.error(
                    f"Failed to remove created file {self.resource_path}: {e}",
                    extra={
                        "event.name": "transaction.file.remove",
                        "event.domain": "persistence",
                        "event.outcome": "failure",
                        "file.path": sanitize_path(self.resource_path),
                        "error.message": str(e),
                    },
                )

    def _cleanup_backup(self) -> None:
        """Clean up backup file."""
        try:
            if self.backup_path and self.backup_path.exists():
                self.backup_path.unlink()
        except (OSError, PermissionError) as e:
            logger.warning(
                f"Failed to cleanup backup {self.backup_path}: {e}",
                extra={
                    "event.name": "transaction.backup.cleanup",
                    "event.domain": "persistence",
                    "event.outcome": "failure",
                    "file.path": sanitize_path(self.backup_path),
                    "error.message": str(e),
                },
            )
            # Not critical - don't raise


class MarkdownFileManager(FileManagerPort):
    """Manager for markdown file operations."""

    def __init__(self) -> None:
        """Initialize file manager."""
        pass

    def parse_file(self, path: Path) -> tuple[dict[str, Any], str]:
        """Read frontmatter and content."""
        with open(path, encoding="utf-8") as f:
            post = frontmatter.load(f)
        return post.metadata, post.content

    def create_file(self, path: Path, frontmatter_data: dict[str, Any], content: str) -> None:
        """Create new file with frontmatter and content."""
        path.parent.mkdir(parents=True, exist_ok=True)
        post = frontmatter.Post(content, **frontmatter_data)
        with open(path, "w", encoding="utf-8") as f:
            f.write(frontmatter.dumps(post))

    def update_file(self, path: Path, frontmatter_data: dict[str, Any] | None, content: str | None) -> None:
        """Update existing file's frontmatter and/or content."""
        with FileBackupTransaction(path):
            with open(path, encoding="utf-8") as f:
                post = frontmatter.load(f)

            if frontmatter_data:
                post.metadata.update(frontmatter_data)
            if content:
                post.content = content

            with open(path, "w", encoding="utf-8") as f:
                f.write(frontmatter.dumps(post))

    def delete_file(self, path: Path) -> None:
        """Delete markdown file."""
        if path.exists():
            path.unlink()
