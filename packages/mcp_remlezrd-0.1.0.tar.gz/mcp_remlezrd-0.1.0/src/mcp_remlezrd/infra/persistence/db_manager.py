import logging

from sqlalchemy import text
from sqlalchemy.pool import StaticPool
from sqlmodel import Session, SQLModel, create_engine

logger = logging.getLogger(__name__)


class DBManager:
    """Simplified database manager with essential operations."""

    def __init__(self):
        """Initialize in-memory SQLite database."""
        self.engine = create_engine(
            "sqlite:///:memory:",
            echo=False,
            connect_args={"check_same_thread": False},
            poolclass=StaticPool,
        )
        self._create_tables()

    def _create_tables(self):
        """Create all tables with optimized PRAGMA settings."""
        with self.engine.begin() as conn:
            # Performance and concurrency optimizations
            conn.execute(text("PRAGMA journal_mode=WAL"))
            conn.execute(text("PRAGMA foreign_keys=ON"))
            conn.execute(text("PRAGMA synchronous=NORMAL"))
            conn.execute(text("PRAGMA temp_store=MEMORY"))

            # SQLModel magic: create all defined tables
            SQLModel.metadata.create_all(conn)

        logger.debug(
            "Database tables created",
            extra={
                "event.name": "database.init",
                "event.domain": "persistence",
                "event.outcome": "success",
            },
        )

    def get_session(self) -> Session:
        """Get a new database session."""
        return Session(self.engine)
