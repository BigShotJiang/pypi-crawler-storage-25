import enum

from mcp_remlezrd.features.onboarding.meta import ONBOARDING
from mcp_remlezrd.features.project.adr.meta import META as ADR_META
from mcp_remlezrd.features.project.glossary.meta import META as GLOSSARY_META
from mcp_remlezrd.features.project.meta import PROJECT
from mcp_remlezrd.features.shareable.meta import SHAREABLE
from mcp_remlezrd.features.shareable.rule.meta import META as RULE_META
from mcp_remlezrd.features.shareable.skill.meta import META as SKILL_META


class ServerArgValues(enum.StrEnum):
    """CLI choices for server scopes."""

    PROJECT = PROJECT.scope_type
    SHAREABLE = SHAREABLE.scope_type
    ONBOARDING = ONBOARDING.scope_type


class ResourceArgValues(enum.StrEnum):
    """CLI choices for resources."""

    ADR = ADR_META.resource_type
    GLOSSARY = GLOSSARY_META.resource_type
    RULE = RULE_META.resource_type
    SKILL = SKILL_META.resource_type
