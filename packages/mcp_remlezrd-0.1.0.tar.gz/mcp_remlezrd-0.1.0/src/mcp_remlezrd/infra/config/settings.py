import logging
from pathlib import Path
from typing import Any, Self

from pydantic import BaseModel, Field, field_validator, model_validator
from pydantic.fields import FieldInfo
from pydantic_settings import BaseSettings, SettingsConfigDict

from mcp_remlezrd.features.shared.app_meta import APP
from mcp_remlezrd.features.shared.consts import TAG_MODE_RW

from .args import ResourceArgValues, ServerArgValues

_DATE_FMT = "%Y-%m-%d %H:%M:%S"

_DEFAULT_LOGLVL_FILE = logging.INFO
_DEFAULT_LOGLVL_STDERR = logging.WARNING

_DEFAULT_SHARED_DIR = Path.home() / ".local/share/remlezrd"

_DEFAULT_GLOSSARY_SUBDIR = Path("docs") / "_glossary"
_DEFAULT_ADR_SUBDIR = Path("docs") / "_adrs"
_DEFAULT_RULE_SUBDIR = Path("docs") / "_rules"
_DEFAULT_SKILL_SUBDIR = Path("docs") / "_skills"

ENVVAR_PREFIX = APP.server_name.upper()


def _get_project_dir() -> Path:
    """Factory function for project_dir default value."""
    return Path.cwd().resolve()


class LoggingSettings(BaseSettings):
    """Logging configuration including paths and levels."""

    model_config = SettingsConfigDict(validate_by_name=True, validate_by_alias=True)

    level_stderr: int = Field(
        default=_DEFAULT_LOGLVL_STDERR,
        validation_alias=f"{ENVVAR_PREFIX}_LOG_LEVEL",
        description=f"Console handler log level (default: {logging.getLevelName(_DEFAULT_LOGLVL_STDERR)})",
    )
    level_file: int = Field(
        default=_DEFAULT_LOGLVL_FILE,
        validation_alias=f"{ENVVAR_PREFIX}_LOG_FILE_LEVEL",
        description=f"File handler log level (default: {logging.getLevelName(_DEFAULT_LOGLVL_FILE)})",
    )
    file: Path | None = Field(default=None, description="path for the MCP Server Log file")

    @field_validator("level_stderr", "level_file", mode="before")
    @classmethod
    def _parse_log_level(cls, v: Any) -> int:
        """Parse log level from string name (e.g., 'INFO', 'DEBUG') or int."""
        if isinstance(v, str) and not v.isdigit():
            level = getattr(logging, v.upper(), None)
            if level is None:
                raise ValueError(f"Invalid log level: {v}")
            return level
        return int(v)

    @property
    def formatter_dict(self) -> dict[str, Any]:
        """Return JSON formatter configuration."""
        return {
            "json": {
                "()": "pythonjsonlogger.json.JsonFormatter",
                "datefmt": _DATE_FMT,
                "fmt": "%(asctime)s %(levelname)s %(name)s %(message)s",
            }
        }

    @property
    def _stderr_handler_dict(self) -> dict[str, Any]:
        # Console handler mode (stderr to avoid interfering with MCP stdio protocol)
        return {
            "class": "logging.StreamHandler",
            "formatter": "json",
            "stream": "ext://sys.stderr",
            "level": self.level_stderr,
        }

    @property
    def _file_handler_dict(self) -> dict[str, Any]:
        if self.file is None:
            return {}
        return {
            "class": "logging.handlers.RotatingFileHandler",
            "formatter": "json",
            "filename": self.file,
            "encoding": "utf-8",
            "maxBytes": 100_000_000,
            "backupCount": 1,
            "level": self.level_file,
        }

    @property
    def _handlers_dict(self) -> dict[str, Any]:
        if self.file is not None and self._file_handler_dict:
            return {"cli_stderr": self._stderr_handler_dict, "srv_file": self._file_handler_dict}
        return {"cli_stderr": self._stderr_handler_dict}

    @property
    def _loggers_dict(self) -> dict[str, Any]:
        handlers_names: set[str] = set(self._handlers_dict)
        lvl_min = min(self.level_stderr, self.level_file) if self.file is not None and self._file_handler_dict else self.level_stderr
        return {
            "mcp_remlezrd": {"handlers": handlers_names, "level": lvl_min, "propagate": False},
            "fastmcp": {"handlers": handlers_names, "level": lvl_min, "propagate": False},
            "mcp": {"handlers": handlers_names, "level": lvl_min, "propagate": False},
        }

    @property
    def dict_config(self) -> dict[str, Any]:
        """Return the logging configuration dict for use with logging.config.dictConfig."""
        config: dict[str, Any] = {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": self.formatter_dict,
            "handlers": self._handlers_dict,
            "loggers": self._loggers_dict,
        }

        return config


class ComponentsActivationSettings(BaseModel):
    """Filter for scope tags (project or shareable)."""

    disable_servers: list[ServerArgValues] = Field(
        default=[],
        validation_alias=None,
        description="List of server scopes completely disabled",
    )
    disable_resources: list[ResourceArgValues] = Field(
        default=[],
        validation_alias=None,
        description="List of resource types completely disabled",
    )
    no_write_servers: list[ServerArgValues] = Field(
        default=[],
        validation_alias=None,
        description="List of server scopes in Read-Only mode",
    )
    no_write_resources: list[ResourceArgValues] = Field(
        default=[],
        validation_alias=None,
        description="List of resource types in Read-Only mode",
    )

    @field_validator("disable_servers", "disable_resources", "no_write_servers", "no_write_resources", mode="before")
    @classmethod
    def decode_str_list(cls, v: str | list) -> list:
        """Decode a comma-separated string into a list of resource types."""
        if isinstance(v, str):
            return v.split(",")
        return v

    @model_validator(mode="after")
    def validate_at_least_one_server_enabled(self) -> Self:
        """Ensure at least one server is enabled."""
        if ServerArgValues.PROJECT.value in self.disable_servers and ServerArgValues.SHAREABLE.value in self.disable_servers:
            raise ValueError("Cannot disable all servers!")
        if (
            ResourceArgValues.ADR.value in self.disable_resources
            and ResourceArgValues.GLOSSARY.value in self.disable_resources
            and ResourceArgValues.RULE.value in self.disable_resources
            and ResourceArgValues.SKILL.value in self.disable_resources
        ):
            raise ValueError("Cannot disable all resources!")
        return self

    @property
    def enable_project_server(self) -> bool:
        """Return True if the project server must be mounted."""
        return ServerArgValues.PROJECT.value not in self.disable_servers

    @property
    def enable_shareable_server(self) -> bool:
        """Return True if the shareable server must be mounted."""
        return ServerArgValues.SHAREABLE.value not in self.disable_servers

    @property
    def enable_onboarding_components(self) -> bool:
        """Return True if onboarding components must be enabled."""
        return ServerArgValues.ONBOARDING.value not in self.disable_servers

    @property
    def disabled_tag_sets(self) -> list[set[str]]:
        """Return tag sets intended for ``FastMCP.disable(tags=...)`` to disable onboarding components.

        Each set groups tags identifying the project server capabilities
        (scope, resource type, or access mode) that should be disabled.
        """
        sets: list[set[str]] = []

        for s in ServerArgValues:
            if s.value in self.disable_servers:
                sets.append({f"scope:{s.value}"})
            if s.value in self.no_write_servers:
                sets.append({f"scope:{s.value}", TAG_MODE_RW})

        for r in ResourceArgValues:
            if r.value in self.disable_resources:
                sets.append({f"res:{r.value}"})
            if r.value in self.no_write_resources:
                sets.append({f"res:{r.value}", TAG_MODE_RW})

        return sets


class ServerSettings(BaseSettings):
    """Manages the configuration for the MCP server.

    Settings are loaded with the following priority:
    1. Command-line arguments (handled by Typer in main.py).
    2. Environment variables (prefixed with 'REMLEZRD_').
    3. Default values defined in this class.

    Follows the Server Configuration Specification.
    """

    model_config = SettingsConfigDict(
        env_prefix=f"{APP.server_name}_",
        env_prefix_target="variable",
        env_ignore_empty=True,
        validate_by_name=True,
        validate_by_alias=True,
    )

    # Server Configuration
    logging: LoggingSettings = Field(
        default_factory=LoggingSettings,
        description="Logging configuration.",
    )
    activation: ComponentsActivationSettings = Field(
        default_factory=ComponentsActivationSettings,
        description="Server and Components activation settings.",
    )

    resource_as_tool: bool = Field(
        default=False,
        description="Show Resources as Tools (if MCP Resources NOT supported)",
    )

    # Storage Configuration
    project_dir: Path = Field(
        default_factory=_get_project_dir,
        validation_alias=f"{ENVVAR_PREFIX}_OVERRIDE_CWD",  # Variable d'env (nom complet)
        description=f"Abs. path to Project dir (default: {Path.cwd()})",
    )
    shared_dir: Path | None = Field(
        default=_DEFAULT_SHARED_DIR,
        validation_alias=f"{ENVVAR_PREFIX}_SHARED_DIR",
        description=f"Abs. path to Shared dir (default: {_DEFAULT_SHARED_DIR})",
    )

    # Domain Subdirectories (relative to current working directory)
    adr_project_subdir: Path = Field(
        default=_DEFAULT_ADR_SUBDIR,
        validation_alias=f"{ENVVAR_PREFIX}_SUBDIR_ADR",
        description=f"Subdir for ADRs (default: {_DEFAULT_ADR_SUBDIR})",
    )
    glossary_project_subdir: Path = Field(
        default=_DEFAULT_GLOSSARY_SUBDIR,
        validation_alias=f"{ENVVAR_PREFIX}_SUBDIR_GLOSSARY",
        description=f"Subdir for Glossaries (default: {_DEFAULT_GLOSSARY_SUBDIR})",
    )
    rule_project_subdir: Path = Field(
        default=_DEFAULT_RULE_SUBDIR,
        validation_alias=f"{ENVVAR_PREFIX}_SUBDIR_RULE",
        description=f"Subdir for Rules (default: {_DEFAULT_RULE_SUBDIR})",
    )
    skill_project_subdir: Path = Field(
        default=_DEFAULT_SKILL_SUBDIR,
        validation_alias=f"{ENVVAR_PREFIX}_SUBDIR_SKILL",
        description=f"Subdir for Skills (default: {_DEFAULT_SKILL_SUBDIR})",
    )

    # Validation
    @field_validator("project_dir")
    @classmethod
    def validate_absolute_dirs(cls, v: Path) -> Path:
        """Ensure project_dir is an absolute resolved path."""
        resolved = v.resolve()
        if not resolved.is_absolute():
            raise ValueError(f"Directory must be an absolute path, got: {v}")
        return resolved

    @field_validator("shared_dir")
    @classmethod
    def validate_shared_dir(cls, v: Path | None) -> Path | None:
        """Validate shared_dir if provided."""
        if v is None:
            return v
        resolved = v.resolve()
        if not resolved.is_absolute():
            raise ValueError(f"Directory must be an absolute path, got: {v}")
        return resolved

    @field_validator(
        "glossary_project_subdir",
        "adr_project_subdir",
        "rule_project_subdir",
        "skill_project_subdir",
    )
    @classmethod
    def validate_subdirs_relative(cls, v: Path) -> Path:
        """Ensure subdirectories are relative paths."""
        if v.is_absolute():
            raise ValueError("Subdirectories must be relative paths")
        return v

    # Calculated paths properties
    @property
    def glossary_project_path(self) -> Path:
        """Return the absolute path to the project glossary directory."""
        return self.project_dir / self.glossary_project_subdir

    @property
    def adr_project_path(self) -> Path:
        """Return the absolute path to the project ADR directory."""
        return self.project_dir / self.adr_project_subdir

    @property
    def rule_project_path(self) -> Path:
        """Return the absolute path to the project rules directory."""
        return self.project_dir / self.rule_project_subdir

    @property
    def skill_project_path(self) -> Path:
        """Return the absolute path to the project skills directory."""
        return self.project_dir / self.skill_project_subdir

    @property
    def rule_shared_path(self) -> Path:
        """Return the absolute path to the shared rules directory."""
        if self.shared_dir is None:
            raise ValueError("shared_dir must be set to access shared rules directory")
        return self.shared_dir / "_rules"

    @property
    def skill_shared_path(self) -> Path:
        """Return the absolute path to the shared skills directory."""
        if self.shared_dir is None:
            raise ValueError("shared_dir must be set to access shared skills directory")
        return self.shared_dir / "_skills"


def format_env_vars_for_help(settings_class: type[BaseModel], prefix: str = "") -> str:
    """Generate help text for environment variables from BaseModel validation_alias.

    Scans all fields with validation_alias and returns formatted help text.
    Recursively handles nested BaseModel (like LoggingSettings).

    Args:
        settings_class: The BaseModel class to scan
        prefix: Prefix for nested settings (e.g., "REMLEZRD_LOG_")

    Returns:
        Formatted string with env var names and descriptions
    """
    lines: list[str] = []

    def format_envvar_line(fi: FieldInfo) -> str:
        name = fi.validation_alias

        desc = field_info.description or ""
        # every desc looks like `<short_desc>[ ]*(default:)?`
        short_desc = desc.split("(default:")[0]

        # defaults = fi.default if isinstance(fi.default, str) else ""
        defaults = desc.split("(default:")[1].rstrip(")").lstrip() if "(default:" in desc else ""
        rich_envvar = f"[dim yellow]\\[env var: {name}][/dim yellow]"
        rich_default = f"[dim]\\[default: '{defaults}'][/dim]" if len(defaults) > 0 else ""
        return f"\n :small_blue_diamond: {short_desc:<26} {rich_envvar:<62}  {rich_default}"

    def extract_annotation(fi: FieldInfo) -> Any:
        annotation: Any = field_info.annotation
        if annotation and hasattr(annotation, "__origin__"):
            args = getattr(annotation, "__args__", None)
            if args:
                annotation = args[0]
        return annotation

    for _field_name, field_info in settings_class.model_fields.items():
        envvar_name = field_info.validation_alias
        if envvar_name and isinstance(envvar_name, str):
            lines.append(format_envvar_line(field_info))

        # Handle nested BaseModel (like logging: LoggingSettings)
        annotation = extract_annotation(field_info)

        # Recurse into nested BaseModel
        if isinstance(annotation, type) and issubclass(annotation, BaseModel):
            nested_help = format_env_vars_for_help(annotation)
            if nested_help:
                lines.append(nested_help)
    return "\n".join(lines) if lines else ""
