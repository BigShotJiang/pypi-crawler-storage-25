import logging
from pathlib import Path
from typing import Annotated, Any

from fastmcp import FastMCP
from fastmcp.server.lifespan import lifespan
from fastmcp.server.middleware.error_handling import ErrorHandlingMiddleware
from fastmcp.server.middleware.logging import StructuredLoggingMiddleware
from fastmcp.server.transforms import ResourcesAsTools
import typer

from mcp_remlezrd import __version__
from mcp_remlezrd.bootstrap.container import (
    Container,
    get_services_dict,
)
from mcp_remlezrd.features.shared.app_meta import APP
from mcp_remlezrd.infra.config import (
    ComponentsActivationSettings,
    LoggingSettings,
    ResourceArgValues,
    ServerArgValues,
    ServerSettings,
    format_env_vars_for_help,
)
from mcp_remlezrd.infra.config.settings import _DEFAULT_SHARED_DIR, ENVVAR_PREFIX
from mcp_remlezrd.infra.entrypoints.fastmcp.formatters.descriptions import ServerInstructionsConfig
from mcp_remlezrd.infra.entrypoints.fastmcp.middleware_connection import ClientConnectionMiddleware
from mcp_remlezrd.infra.entrypoints.fastmcp.onboarding.onboarding import register_onboarding_components
from mcp_remlezrd.infra.entrypoints.fastmcp.project import create_project_server
from mcp_remlezrd.infra.entrypoints.fastmcp.shareable import create_shareable_server
from mcp_remlezrd.infra.logging.logging import setup_logging

# --- Typer App ---
app = typer.Typer(
    name=APP.app_name,
    help="A Model Context Protocol (MCP) server for AI agents.",
    add_completion=False,
    rich_markup_mode="rich",
)


def _mkdir(path: Path, desc: str, logger: logging.Logger) -> None:
    if not path.exists():
        try:
            path.mkdir(parents=True, exist_ok=True)
            logger.info(
                f"Created {desc} directory: {path}",
                extra={
                    "event.name": "server.init.dirs",
                    "event.domain": "infra",
                    "event.outcome": "success",
                    "directory.path": str(path),
                    "directory.type": desc,
                },
            )
        except Exception as e:
            logger.warning(
                f"Failed to create {desc} directory: {e}",
                extra={
                    "event.name": "server.init.dirs",
                    "event.domain": "infra",
                    "event.outcome": "failure",
                    "directory.path": str(path),
                    "directory.type": desc,
                    "error.message": str(e),
                },
            )


def _setup_middlewares(mcp: FastMCP[Any], settings: ServerSettings, log_settings: LoggingSettings) -> None:
    """Register standard FastMCP middlewares based on settings."""
    mcp.add_middleware(ClientConnectionMiddleware())
    if settings.resource_as_tool:
        mcp.add_transform(ResourcesAsTools(mcp))

    mcp.add_middleware(
        ErrorHandlingMiddleware(
            logger=logging.getLogger("fastmcp.errors"),
            include_traceback=min(log_settings.level_stderr, log_settings.level_file) == logging.DEBUG,
            transform_errors=True,
        )
    )
    mcp.add_middleware(
        StructuredLoggingMiddleware(
            logger=logging.getLogger("fastmcp.structured"),
            log_level=logging.DEBUG,
            include_payloads=True,
            include_payload_length=True,
            estimate_payload_tokens=True,
        )
    )


def _initialize_services(
    container: Container,
    services_dict: dict[str, Any],
    logger: logging.Logger,
) -> Any:
    """Initialize all services: indexation + file watcher registration.

    Returns:
        File watcher instance.
    """
    # Initial indexation - scan files to database
    for service_name, service in services_dict.items():
        service_name = service.__class__.__name__
        try:
            service.sync_dirs()
        except Exception as e:
            logger.warning(
                f"Initial indexation failed for {service_name} resources: {e}",
                extra={
                    "event.name": "server.index",
                    "event.domain": "infra",
                    "event.outcome": "failure",
                    "service.name": service_name,
                    "error.message": str(e),
                },
            )

    logger.info(
        "Initial indexation completed",
        extra={
            "event.name": "server.index",
            "event.domain": "infra",
            "event.outcome": "success",
        },
    )

    # Initialize file watcher (construction + registration)
    file_watcher = container.file_watcher()
    for service in services_dict.values():
        file_watcher.register_service(service)
    logger.debug(
        "File watcher initialized and services registered",
        extra={
            "event.name": "server.init.watcher",
            "event.domain": "infra",
            "event.outcome": "success",
        },
    )

    return file_watcher


def _disable_components(mcp: FastMCP[Any], settings: ServerSettings, logger: logging.Logger) -> None:
    """Disable components based on activation settings."""
    for s in settings.activation.disabled_tag_sets:
        mcp.disable(tags=s)
        logger.info(
            "Components disabled",
            extra={
                "event.name": "mcp.component.disable",
                "event.domain": "mcp",
                "event.outcome": "success",
                "component.tags": s,
            },
        )


def _build_server_instructions(
    onboarding_enable: bool,
    shareable_refs: bool,
    project_refs: bool,
) -> str:
    """Build compact server instructions based on enabled features.

    Returns:
        Server instructions string.
    """
    first_steps: list[str] = []

    if onboarding_enable:
        first_steps.append("STEP 1 (MANDATORY): Call discover_standards tool at session start")

    first_steps.append("Only upon explicit user request: Create or modify conventions, following established patterns")

    constraints: list[str] = [
        "Content is authoritative - established by the organization",
        "MUST respect existing conventions unless explicitly requested otherwise",
        "All resources identified by unique 'name' (kebab-case, used in URIs and file paths)",
        "Data freshness: Real-time from file-based catalog",
    ]

    if shareable_refs and project_refs:
        constraints.append("Project resources override shared resources with the same name")

    return ServerInstructionsConfig(
        purpose="MCP RemLezrd - Collaborative knowledge management",
        first_steps=first_steps,
        constraints=constraints,
    ).rendered


async def _components_count(server: FastMCP[Any]) -> dict[str, int]:
    return {
        "tools": len(await server._list_tools()),
        "resources": len(await server._list_resources()),
        "resource_templates": len(await server._list_resource_templates()),
        "prompts": len(await server._list_prompts()),
    }


def _watcher_lifespan(file_watcher, logger):

    @lifespan
    async def _lifespan(server):
        file_watcher.start()

        logger.info(
            "File watcher started",
            extra={
                "event.name": "server.init.watcher",
                "event.domain": "infra",
                "event.outcome": "success",
                "components_stats": await _components_count(server=server),
            },
        )

        try:
            yield {}
        finally:
            await file_watcher.stop()

            logger.info(
                "File watcher stopped",
                extra={
                    "event.name": "server.shutdown.watcher",
                    "event.domain": "infra",
                    "event.outcome": "success",
                },
            )

    return _lifespan


_panel_title_fastmcp = "Options: MCP Features Support"
_panel_title_activation = "Options: RemLezrd Features Activation (support comma-separated lists)"
_panel_title_access = "Options: Access Control"


@app.command(
    help=f"[bold blue]MCP RemLezrd server[/bold blue] ({__version__}) - [italic]Context manager for AI agents[/italic]",
    epilog=f"[bold yellow]Other Environment Variables:[/bold yellow]\n{format_env_vars_for_help(ServerSettings)}",
)
def main(
    shared: Annotated[
        bool,
        typer.Option(
            envvar=f"{ENVVAR_PREFIX}_ENABLE_SHARED_DIR",
            help="Enable/disable shared directory (Disable to use project-only mode)",
            # rich_help_panel=_panel_title_access,
        ),
    ] = True,
    disable_servers: Annotated[
        list[ServerArgValues] | None,
        typer.Option(
            envvar=f"{ENVVAR_PREFIX}_DISABLE_SERVERS",
            help="List of servers to disable",
            rich_help_panel=_panel_title_activation,
        ),
    ] = None,
    no_write_servers: Annotated[
        list[ServerArgValues] | None,
        typer.Option(
            envvar=f"{ENVVAR_PREFIX}_NO_WRITE_SERVERS",
            help="List of servers to disable RW tools from",
            rich_help_panel=_panel_title_activation,
        ),
    ] = None,
    disable_resources: Annotated[
        list[ResourceArgValues] | None,
        typer.Option(
            envvar=f"{ENVVAR_PREFIX}_DISABLE_RESOURCES",
            help="List of resource types to disable",
            rich_help_panel=_panel_title_activation,
        ),
    ] = None,
    no_write_resources: Annotated[
        list[ResourceArgValues] | None,
        typer.Option(
            envvar=f"{ENVVAR_PREFIX}_NO_WRITE_RESOURCES",
            help="List of resource types to disable RW tools from",
            rich_help_panel=_panel_title_activation,
        ),
    ] = None,
    resource_as_tool: Annotated[
        bool,
        typer.Option(
            help="Only for CLIENT with NO 'MCP Resources' Support",
            envvar=f"{ENVVAR_PREFIX}_RESOURCES_AS_TOOLS",
            # rich_help_panel=_panel_title_fastmcp,
        ),
    ] = False,
    log_file: Annotated[
        Path | None,
        typer.Option(
            help="Path to log file",
            envvar=f"{ENVVAR_PREFIX}_LOG_FILE",
        ),
    ] = None,
):
    """Initializes and runs the MCP RemLezrd server."""
    log_settings = LoggingSettings(file=log_file)
    setup_logging(log_settings)
    logger = logging.getLogger(__name__)

    activation = ComponentsActivationSettings(
        disable_servers=disable_servers if disable_servers else [],
        disable_resources=disable_resources if disable_resources else [],
        no_write_servers=no_write_servers if no_write_servers else [],
        no_write_resources=no_write_resources if no_write_resources else [],
    )
    settings = ServerSettings(
        activation=activation,
        logging=log_settings,
        resource_as_tool=resource_as_tool,
        # Désactive les ressources partagées
        shared_dir=None if not shared else _DEFAULT_SHARED_DIR,
    )

    # Ensure shared directories exist if features are enabled
    if settings.shared_dir is not None and settings.activation.enable_shareable_server:
        _mkdir(path=settings.rule_shared_path, desc="shared rules", logger=logger)
        _mkdir(path=settings.skill_shared_path, desc="shared skills", logger=logger)

    container = Container()

    container.app_settings.override(settings)
    logger.debug(
        "Application configured",
        extra={
            "event.name": "server.configure",
            "event.domain": "infra",
            "event.outcome": "success",
        },
    )

    services_dict = get_services_dict(container)
    file_watcher = _initialize_services(container, services_dict, logger)

    # Create main server
    main = FastMCP(
        name=APP.server_name,
        version=__version__,
        lifespan=_watcher_lifespan(file_watcher, logger),
        instructions=_build_server_instructions(
            onboarding_enable=settings.activation.enable_onboarding_components,
            shareable_refs=settings.activation.enable_shareable_server,
            project_refs=settings.activation.enable_project_server,
        ),
    )

    _setup_middlewares(main, settings, log_settings)

    # Mount shareable_refs server (rules + skills)
    if settings.activation.enable_shareable_server:
        shareable = create_shareable_server(
            services_dict["shareable_rule"],
            services_dict["shareable_skill"],
        )
        main.mount(shareable)

    # Mount project_refs server (adrs + glossaries)
    if settings.activation.enable_project_server:
        project = create_project_server(
            services_dict["project_adr"],
            services_dict["project_glossary"],
        )
        main.mount(project)

    # Register onboarding components
    register_onboarding_components(
        main,
        services_dict.get("shareable_skill"),
        services_dict.get("shareable_rule"),
        services_dict.get("project_adr"),
        services_dict.get("project_glossary"),
    )

    _disable_components(main, settings, logger)

    # Run the server's main loop (lifespan handles startup/shutdown)
    try:
        main.run(show_banner=False)

    except KeyboardInterrupt:
        logger.info(
            "Shutdown requested by user",
            extra={
                "event.name": "server.shutdown",
                "event.domain": "infra",
            },
        )
        raise typer.Exit(0) from None
    except Exception as e:
        logger.error(
            f"Server error: {e}",
            extra={
                "event.name": "server.run",
                "event.domain": "infra",
                "event.outcome": "failure",
                "error.message": str(e),
            },
        )
        raise


if __name__ == "__main__":
    app()
