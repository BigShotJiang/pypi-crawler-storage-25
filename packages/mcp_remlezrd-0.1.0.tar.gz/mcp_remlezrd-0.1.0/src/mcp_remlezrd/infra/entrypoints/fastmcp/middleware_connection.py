"""FastMCP middleware for client connection logging."""

import logging

from fastmcp.server.middleware.middleware import Middleware, MiddlewareContext


class ClientConnectionMiddleware(Middleware):
    """Middleware for logging client connections and capabilities."""

    async def on_initialize(self, context: MiddlewareContext, call_next):
        """Called when a client connects and initializes the session."""
        logger = logging.getLogger(__name__)

        ctx = context.fastmcp_context
        if ctx and ctx.session.client_params:
            client_info = ctx.session.client_params.clientInfo
            cli_params = ctx.session.client_params

            # Log basic connection info
            logger.info(
                f"Client connected: {client_info.name} v{client_info.version}",
                extra={
                    "event.name": "client.connect",
                    "event.domain": "mcp",
                    "event.outcome": "success",
                    "client.name": client_info.name,
                    "client.version": client_info.version,
                    "session.id": ctx.session_id,
                },
            )

            # Log client capabilities (debug level)
            capabilities = [c for c in cli_params.capabilities.model_dump() if c is not None]
            logger.debug(
                "Client capabilities",
                extra={
                    "event.name": "client.capabilities",
                    "event.domain": "mcp",
                    "client.capabilities": capabilities,
                    "session.id": ctx.session_id,
                },
            )

            # Log roots support if available
            if cli_params.capabilities.roots is not None:
                logger.debug(
                    "Client roots support",
                    extra={
                        "event.name": "client.roots",
                        "event.domain": "mcp",
                        "client.roots": cli_params.capabilities.roots.model_dump(),
                        "session.id": ctx.session_id,
                    },
                )

        result = await call_next(context)
        return result
