"""Formatters for MCP component descriptions."""

from abc import abstractmethod
from typing import Self

from pydantic import BaseModel, Field, field_validator, model_validator
import tiktoken


class DescriptionConfig(BaseModel):
    """Base configuration for all MCP component descriptions."""

    purpose: str = Field(..., description="Main purpose of the component")
    max_tokens: int = Field(200, ge=50, le=500, description="Maximum token count for the final description")

    @field_validator("purpose")
    @classmethod
    def purpose_must_be_clear(cls, v: str) -> str:
        """Validate that purpose is sufficiently descriptive."""
        v = v.strip()
        if len(v) < 15:
            raise ValueError("Purpose must be at least 15 characters long and descriptive.")
        return v

    @model_validator(mode="after")
    def validate_rendered_length(self) -> Self:
        """Validate that the rendered description does not exceed max_tokens."""
        enc = tiktoken.get_encoding("o200k_base")
        token_count = len(enc.encode(self.rendered))
        if token_count > self.max_tokens:
            raise ValueError(f"Description exceeds maximum of {self.max_tokens} tokens (got {token_count}). Please shorten the content.")
        return self

    def _join_list_or_str(self, value: str | list[str] | None) -> str | None:
        """Join a list of strings into a bulleted list, or return string as-is."""
        if value is None:
            return None
        if isinstance(value, list):
            return "* " + "\n* ".join(str(item).strip() for item in value if str(item).strip())
        return str(value).strip()

    def _finalize(self, parts: list[str]) -> str:
        """Join parts and clean up empty lines."""
        description = "".join(parts).strip()
        return "\n".join(line.strip() for line in description.splitlines() if line.strip())

    @abstractmethod
    def _build_parts(self) -> list[str]:
        """Build the parts of the description. Subclasses must override this method."""
        raise NotImplementedError("Subclasses must implement _build_parts()")

    @property
    def rendered(self) -> str:
        """Render the formatted description."""
        return self._finalize(self._build_parts())


class ToolDescriptionConfig(DescriptionConfig):
    """Validated config for @mcp.tool(description=...)."""

    when_to_use: str | list[str] | None = Field(None, description="When to use this tool (and explicitly when NOT to use it)")
    constraints: str | list[str] | None = Field(None, description="Limitations, side-effects, permissions, security notes")
    example: str | None = Field(None, description="Short usage example")

    def _build_parts(self) -> list[str]:
        """Build parts for tool description."""
        parts: list[str] = [self.purpose]

        when = self._join_list_or_str(self.when_to_use)
        if when:
            parts.append(f"\n\nWhen to use:\n{when}")

        constraints = self._join_list_or_str(self.constraints)
        if constraints:
            parts.append(f"\n\nConstraints:\n{constraints}")

        if self.example:
            parts.append(f"\n\nExample:\n{self.example.strip()}")

        return parts


class PromptDescriptionConfig(DescriptionConfig):
    """Validated config for @mcp.prompt(description=...)."""

    role: str | None = Field(None, description="Role the prompt should play")
    when_to_use: str | list[str] | None = None
    variables: str | list[str] | None = Field(None, description="Variables that will be injected into the prompt")
    output_format: str | None = Field(None, description="Expected output format or structure")
    constraints: str | list[str] | None = None

    def _build_parts(self) -> list[str]:
        """Build parts for prompt description."""
        parts: list[str] = [self.purpose]

        if self.role:
            parts.append(f"\n\nRole: {self.role.strip()}")

        when = self._join_list_or_str(self.when_to_use)
        if when:
            parts.append(f"\n\nWhen to use:\n{when}")

        variables = self._join_list_or_str(self.variables)
        if variables:
            parts.append(f"\n\nVariables injected:\n{variables}")

        if self.output_format:
            parts.append(f"\n\nExpected output format:\n{self.output_format.strip()}")

        constraints = self._join_list_or_str(self.constraints)
        if constraints:
            parts.append(f"\n\nConstraints:\n{constraints}")

        return parts


class ResourceDescriptionConfig(DescriptionConfig):
    """Validated config for static @mcp.resource()."""

    content_summary: str = Field(..., description="What the resource contains")
    freshness: str | None = Field(None, description="How fresh/up-to-date the data is")
    when_to_use: str | list[str] | None = None
    constraints: str | list[str] | None = Field(None, description="Access constraints, size limits, read-only, etc.")

    def _build_parts(self) -> list[str]:
        """Build parts for resource description."""
        parts: list[str] = [self.purpose, f"\n\n{self.content_summary.strip()}"]

        if self.freshness:
            parts.append(f"\n\nData freshness: {self.freshness.strip()}")

        when = self._join_list_or_str(self.when_to_use)
        if when:
            parts.append(f"\n\nWhen to load this resource:\n{when}")

        constraints = self._join_list_or_str(self.constraints)
        if constraints:
            parts.append(f"\n\nConstraints:\n{constraints}")

        return parts


class ResourceTemplateDescriptionConfig(DescriptionConfig):
    """Validated config for dynamic @mcp.resource() templates (with URI parameters)."""

    content_summary: str = Field(..., description="What the resource template provides")
    freshness: str | None = Field(None, description="How fresh/up-to-date the data is")
    when_to_use: str | list[str] | None = None
    constraints: str | list[str] | None = Field(None, description="Limitations, permissions, caching behavior, etc.")
    example_uri: str | None = Field(None, description="Concrete example of a valid URI")

    def _build_parts(self) -> list[str]:
        """Build parts for resource template description."""
        parts: list[str] = [self.purpose, f"\n\n{self.content_summary.strip()}"]

        if self.freshness:
            parts.append(f"\n\nData freshness: {self.freshness.strip()}")

        when = self._join_list_or_str(self.when_to_use)
        if when:
            parts.append(f"\n\nWhen to load this resource:\n{when}")

        constraints = self._join_list_or_str(self.constraints)
        if constraints:
            parts.append(f"\n\nConstraints:\n{constraints}")

        if self.example_uri:
            parts.append(f"\n\nExample URI: {self.example_uri.strip()}")

        return parts


class ServerInstructionsConfig(DescriptionConfig):
    """Validated config for FastMCP server instructions."""

    first_steps: str | list[str] | None = Field(None, description="Guidance on how to start using the server")
    constraints: str | list[str] | None = Field(None, description="Limitations or important notes")
    # Override default to allow more tokens for server instructions
    max_tokens: int = Field(300, ge=50, le=500)

    def _build_parts(self) -> list[str]:
        """Build parts for server instructions."""
        parts: list[str] = [self.purpose.strip()]

        first_steps = self._join_list_or_str(self.first_steps)
        if first_steps:
            parts.append(f"\n\n{first_steps}")

        constraints = self._join_list_or_str(self.constraints)
        if constraints:
            parts.append(f"\n\n{constraints}")

        return parts
