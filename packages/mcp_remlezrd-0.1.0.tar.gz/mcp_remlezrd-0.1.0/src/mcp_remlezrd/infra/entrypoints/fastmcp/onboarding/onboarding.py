"""Onboarding components for RemLezrd - tool and prompt for context discovery."""

from datetime import UTC, datetime
import logging

from fastmcp import FastMCP
from fastmcp.dependencies import CurrentContext
from fastmcp.tools import ToolResult
from mcp.server.fastmcp.exceptions import ToolError
from mcp.server.fastmcp.server import Context

from mcp_remlezrd.features.onboarding import DiscoverStandardsResult
from mcp_remlezrd.features.onboarding.consts import (
    DISCOVER_STANDARDS_CONSTRAINTS_SUFFIX,
    DISCOVER_STANDARDS_DOMAINS_CONSTRAINT_PREFIX,
    DISCOVER_STANDARDS_PURPOSE,
    DISCOVER_STANDARDS_TOOL_NAME,
    DISCOVER_STANDARDS_WHEN_TO_USE,
)
from mcp_remlezrd.features.onboarding.meta import ONBOARDING
from mcp_remlezrd.features.project.adr import (
    INDEX_SHORT_DESCRIPTION as ADR_INDEX_DESC,
    ProjectAdrService,
)
from mcp_remlezrd.features.project.glossary import (
    INDEX_SHORT_DESCRIPTION as GLOSSARY_INDEX_DESC,
    ProjectGlossaryService,
)
from mcp_remlezrd.features.shareable.rule import (
    INDEX_SHORT_DESCRIPTION as RULE_INDEX_DESC,
    ShareableRuleService,
)
from mcp_remlezrd.features.shareable.skill import (
    INDEX_SHORT_DESCRIPTION as SKILL_INDEX_DESC,
    ShareableSkillService,
)
from mcp_remlezrd.features.shared.consts import TAG_MODE_RO

from ..formatters.descriptions import ToolDescriptionConfig
from ..formatters.results import ToolResultFormat, tool_result

logger = logging.getLogger(__name__)


def _build_discover_standards_description(shareable_refs: bool, project_refs: bool) -> str:
    """Build description for the discover_standards tool.

    Returns:
        Tool description.
    """
    domain_details: list[str] = []

    if shareable_refs:
        domain_details.extend([
            f"- Skills index: discover available {SKILL_INDEX_DESC}",
            f"- Rules index: discover {RULE_INDEX_DESC}",
        ])

    if project_refs:
        domain_details.extend([
            f"- ADRs index: discover {ADR_INDEX_DESC}",
            f"- Glossaries index: discover {GLOSSARY_INDEX_DESC}",
        ])

    domains_text = "\n".join(domain_details)

    description = ToolDescriptionConfig(
        purpose=DISCOVER_STANDARDS_PURPOSE,
        when_to_use=DISCOVER_STANDARDS_WHEN_TO_USE,
        constraints=[
            f"{DISCOVER_STANDARDS_DOMAINS_CONSTRAINT_PREFIX}\n{domains_text}",
            DISCOVER_STANDARDS_CONSTRAINTS_SUFFIX,
        ],
    ).rendered
    return f"[FIRST] {description}"


def register_onboarding_components(
    mcp: FastMCP,
    skill_service: ShareableSkillService | None,
    rule_service: ShareableRuleService | None,
    adr_service: ProjectAdrService | None,
    glossary_service: ProjectGlossaryService | None,
) -> None:
    """Register onboarding tool and prompt based on onboarding mode.

    Args:
        mcp: FastMCP server instance
        skill_service: Skill service if shareable_refs enabled, None otherwise
        rule_service: Rule service if shareable_refs enabled, None otherwise
        adr_service: ADR service if project_refs enabled, None otherwise
        glossary_service: Glossary service if project_refs enabled, None otherwise
        onboarding: Onboarding mode (encouraged, enabled, disabled)
    """
    shareable_refs = skill_service is not None and rule_service is not None
    project_refs = adr_service is not None and glossary_service is not None

    @mcp.tool(
        name=DISCOVER_STANDARDS_TOOL_NAME,
        description=_build_discover_standards_description(shareable_refs, project_refs),
        tags={ONBOARDING.tag, TAG_MODE_RO},
        annotations={"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
    )
    async def discover_standards(
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ) -> ToolResult:
        """Aggregate index data from all enabled domains."""
        try:
            result: dict[str, dict | None] = {}

            if skill_service is not None:
                result["skills"] = skill_service.discover().model_dump()
            if rule_service is not None:
                result["rules"] = rule_service.discover().model_dump()
            if adr_service is not None:
                result["adrs"] = adr_service.discover().model_dump()
            if glossary_service is not None:
                result["glossaries"] = glossary_service.discover().model_dump()

            data = DiscoverStandardsResult(
                skills=result.get("skills"),
                rules=result.get("rules"),
                adrs=result.get("adrs"),
                glossaries=result.get("glossaries"),
                loaded_at=datetime.now(UTC).isoformat(),
            )
            return tool_result(data, fmt=ToolResultFormat.YAML)
        except Exception as e:
            logger.error(f"Failed to aggregate indexes: {e}")
            raise ToolError(f"Failed to load context indexes: {e}") from e

    logger.debug("Registered discover_standards tool")
