"""Project resources server (ADRs and glossaries)."""

from fastmcp import FastMCP

from mcp_remlezrd import __version__
from mcp_remlezrd.features.project.adr import ProjectAdrService
from mcp_remlezrd.features.project.glossary import ProjectGlossaryService

from .adr import register_project_adr_components
from .glossary import register_project_glossary_components


def create_project_server(
    adr_service: ProjectAdrService,
    glossary_service: ProjectGlossaryService,
) -> FastMCP:
    """Create the project_refs server with ADR and glossary components."""
    server = FastMCP(
        name="project_refs",
        version=__version__,
        instructions="Project scope: ADRs for architectural decisions and Glossaries for terminology.",
    )

    register_project_adr_components(server, adr_service)
    register_project_glossary_components(server, glossary_service)

    return server
