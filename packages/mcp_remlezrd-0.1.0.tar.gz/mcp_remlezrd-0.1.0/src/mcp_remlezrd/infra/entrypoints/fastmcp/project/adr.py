"""MCP Project ADR Components.

Provides MCP tools, resources, and prompts for architectural decision record management.
"""

import logging
from typing import Annotated, Any

from fastmcp import FastMCP
from fastmcp.dependencies import CurrentContext
from fastmcp.tools import ToolResult
from mcp.server.fastmcp import Context
from mcp.server.fastmcp.exceptions import ToolError

from mcp_remlezrd.features.project.adr import (
    AdrUpdateResult,
    ProjectAdrService,
)
from mcp_remlezrd.features.project.adr.consts import (
    CREATE_CONSTRAINTS,
    CREATE_PURPOSE,
    CREATE_WHEN_TO_USE,
    DELETE_CONSTRAINTS,
    DELETE_PURPOSE,
    DELETE_WHEN_TO_USE,
    DISCOVER_CONSTRAINTS,
    DISCOVER_PURPOSE,
    DISCOVER_WHEN_TO_USE,
    READ_CONSTRAINTS,
    READ_CONTENT_SUMMARY,
    READ_PURPOSE,
    READ_WHEN_TO_USE,
    UPDATE_CONSTRAINTS,
    UPDATE_PURPOSE,
    UPDATE_WHEN_TO_USE,
)
from mcp_remlezrd.features.project.adr.meta import META
from mcp_remlezrd.features.project.meta import PROJECT
from mcp_remlezrd.features.shared.consts import TAG_MODE_RO, TAG_MODE_RW
from mcp_remlezrd.features.shared.domain import (
    MarkdownList,
    MarkdownListItem,
    SimpleMarkdownContent,
    SimpleMarkdownParagraph,
)

from ..formatters.descriptions import (
    ResourceTemplateDescriptionConfig,
    ToolDescriptionConfig,
)
from ..formatters.results import ToolResultFormat, resource_result, tool_result

logger = logging.getLogger(__name__)


def register_project_adr_components(mcp: FastMCP[Any], adr_service: ProjectAdrService):
    """Register ADR MCP tools, prompts and resources on the given FastMCP server."""
    logger.debug(
        "Initializing MCPAdr component",
        extra={
            "event": "mcp.component.init",
            "component": "MCPAdr",
            "service_available": adr_service is not None,
        },
    )
    # MCP Tools

    @mcp.tool(
        name=META.discover_tool,
        description=ToolDescriptionConfig(
            purpose=DISCOVER_PURPOSE,
            when_to_use=DISCOVER_WHEN_TO_USE,
            constraints=DISCOVER_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={PROJECT.tag, META.tag, TAG_MODE_RO},
    )
    async def discover_adrs_only(
        include_superseded: Annotated[bool, "Include superseded ADRs in the catalog"] = False,
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ) -> ToolResult:
        """Discovery tool: returns a catalog of all available ADRs."""
        try:
            return tool_result(adr_service.discover(include_superseded=include_superseded), fmt=ToolResultFormat.YAML)
        except Exception as e:
            await ctx.error(f"Failed to discover ADRs: {e}")
            raise ToolError(f"Failed to discover ADRs: {e}") from e

    @mcp.tool(
        name=META.create_tool,
        description=ToolDescriptionConfig(
            purpose=CREATE_PURPOSE,
            when_to_use=CREATE_WHEN_TO_USE,
            constraints=CREATE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
        tags={PROJECT.tag, META.tag, TAG_MODE_RW},
    )
    async def create(
        name: Annotated[str, "Base ADR name (will be prefixed with sequential number) in kebab-case (used in filepath)"],
        description: Annotated[str, "Brief description"],
        context: Annotated[SimpleMarkdownContent, "Context and Problem Statement section content (required)"],
        decision_chosen_option: Annotated[str, "Name of the chosen option (required)"],
        decision_justification: Annotated[SimpleMarkdownParagraph, "Why this option was selected over the alternatives (required)"],
        decision_drivers: Annotated[MarkdownList, "List of forces and concerns that influenced the decision (required)"],
        considered_options: Annotated[MarkdownList, "List of alternatives evaluated (required)"],
        positive_consequences: Annotated[MarkdownList, "List of benefits of the chosen option (required)"],
        negative_consequences: Annotated[MarkdownList, "List of trade-offs and drawbacks of the chosen option (required)"],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
        tags: Annotated[list[str] | None, "Classification tags"] = None,
        superseding: Annotated[list[str] | None, "List of ADR names this ADR supersedes"] = None,
        rejected_options: Annotated[
            dict[str, list[MarkdownListItem]] | None, "Dict mapping rejected option names to list of rejection reasons"
        ] = None,
        references: Annotated[MarkdownList | None, "List of reference links"] = None,
    ) -> ToolResult:
        """Create a new Architectural Decision Record (ADR)."""
        try:
            await ctx.info(f"Creating ADR: {name}")
            return tool_result(
                adr_service.create(
                    name=name,
                    description=description,
                    context=context,
                    decision_chosen_option=decision_chosen_option,
                    decision_justification=decision_justification,
                    decision_drivers=decision_drivers,
                    considered_options=considered_options,
                    positive_consequences=positive_consequences,
                    negative_consequences=negative_consequences,
                    tags=tags,
                    superseding=superseding,
                    rejected_options=rejected_options,
                    references=references,
                ),
                fmt=ToolResultFormat.JSON_COMPACT,
            )
        except Exception as e:
            await ctx.error(f"Failed to create ADR '{name}': {e}")
            raise ToolError(f"Failed to create ADR: {e}") from e

    @mcp.tool(
        name=META.update_tool,
        description=ToolDescriptionConfig(
            purpose=UPDATE_PURPOSE,
            when_to_use=UPDATE_WHEN_TO_USE,
            constraints=UPDATE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={PROJECT.tag, META.tag, TAG_MODE_RW},
    )
    async def update(
        name: Annotated[str, "ADR name"],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
        context_and_problem: Annotated[SimpleMarkdownContent | None, "Context and Problem Statement section content"] = None,
        decision_drivers: Annotated[MarkdownList | None, "List of forces and concerns that influenced the decision"] = None,
        considered_options: Annotated[MarkdownList | None, "List of alternatives evaluated"] = None,
        decision_chosen_option: Annotated[str | None, "Name of the chosen option"] = None,
        decision_justification: Annotated[
            SimpleMarkdownParagraph | None,
            "Why this option was selected over the alternatives (updates Justification subsection)",
        ] = None,
        positive_consequences: Annotated[MarkdownList | None, "List of benefits of the chosen option"] = None,
        negative_consequences: Annotated[MarkdownList | None, "List of trade-offs and drawbacks of the chosen option"] = None,
        rejected_options: Annotated[
            dict[str, list[MarkdownListItem]] | None, "Dict mapping rejected option names to list of rejection reasons"
        ] = None,
        references: Annotated[MarkdownList | None, "List of reference links"] = None,
        tags: Annotated[list[str] | None, "Classification tags"] = None,
        description: Annotated[str | None, "Brief description"] = None,
        superseding: Annotated[list[str] | None, "List of ADR names this ADR supersedes"] = None,
        superseded_by: Annotated[list[str] | None, "List of ADR names that supersede this ADR"] = None,
    ) -> ToolResult:
        """Update ADR metadata and/or content sections.

        Only provided fields are modified. Others remain unchanged.
        """
        try:
            await ctx.info(f"Updating ADR: {name}")
            updated = adr_service.update(
                name=name,
                context_and_problem=context_and_problem,
                decision_drivers=decision_drivers,
                considered_options=considered_options,
                decision_chosen_option=decision_chosen_option,
                decision_justification=decision_justification,
                positive_consequences=positive_consequences,
                negative_consequences=negative_consequences,
                rejected_options=rejected_options,
                references=references,
                tags=tags,
                description=description,
                superseding=superseding,
                superseded_by=superseded_by,
            )
            return tool_result(
                AdrUpdateResult(name=updated.name, updated_at=updated.updated_at, estimated_tokens=updated.estimated_tokens),
                fmt=ToolResultFormat.JSON_COMPACT,
            )
        except Exception as e:
            await ctx.error(f"Failed to update ADR '{name}': {e}")
            raise ToolError(f"Failed to update ADR: {e}") from e

    @mcp.tool(
        name=META.delete_tool,
        description=ToolDescriptionConfig(
            purpose=DELETE_PURPOSE,
            when_to_use=DELETE_WHEN_TO_USE,
            constraints=DELETE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": True, "idempotentHint": False, "openWorldHint": False},
        tags={PROJECT.tag, META.tag, TAG_MODE_RW},
    )
    async def delete(
        name: Annotated[str, "ADR name"],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ) -> ToolResult:
        """Delete an ADR by name."""
        try:
            return tool_result(adr_service.delete(name), fmt=ToolResultFormat.JSON_COMPACT)
        except ValueError as e:
            await ctx.error(f"ADR not found: {name}")
            raise ToolError(f"ADR not found: {name}") from e
        except Exception as e:
            await ctx.error(f"Failed to delete ADR '{name}': {e}")
            raise ToolError(f"Failed to delete ADR: {e}") from e

    # MCP Resources

    @mcp.resource(
        uri=f"{META.base_uri}{{adr_name}}",
        name=META.resource_component,
        description=ResourceTemplateDescriptionConfig(
            purpose=READ_PURPOSE,
            content_summary=READ_CONTENT_SUMMARY,
            when_to_use=READ_WHEN_TO_USE,
            constraints=READ_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={PROJECT.tag, META.tag, TAG_MODE_RO},
        mime_type="text/markdown",
    )
    async def read(
        adr_name: str,
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ):
        """Context resource: Returns the full ADR content in Markdown.

        Use this resource when you need to inject the complete ADR content
        into the conversation context. The adr_name parameter can be
        discovered from the 'read_adr_index' resource.
        """
        try:
            return resource_result(adr_service.render(adr_name))
        except Exception as e:
            await ctx.error(f"Failed to retrieve ADR '{adr_name}': {e}")
            raise
