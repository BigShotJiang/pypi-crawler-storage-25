"""MCP Shareable Skill Components.

Provides MCP tools, resources, and prompts for shareable skills management.
"""

import logging
from typing import Annotated, Any

from fastmcp import FastMCP
from fastmcp.dependencies import CurrentContext
from fastmcp.tools import ToolResult
from mcp.server.fastmcp.exceptions import ToolError
from mcp.server.fastmcp.server import Context

from mcp_remlezrd.features.shareable.meta import SHAREABLE
from mcp_remlezrd.features.shareable.skill import (
    ShareableSkillService,
    SkillUpdateResult,
)
from mcp_remlezrd.features.shareable.skill.consts import (
    CREATE_CONSTRAINTS,
    CREATE_PURPOSE,
    CREATE_WHEN_TO_USE,
    DELETE_CONSTRAINTS,
    DELETE_PURPOSE,
    DELETE_WHEN_TO_USE,
    DISCOVER_CONSTRAINTS,
    DISCOVER_PURPOSE,
    DISCOVER_WHEN_TO_USE,
    READ_CONSTRAINTS,
    READ_CONTENT_SUMMARY,
    READ_PURPOSE,
    READ_SHARED_CONSTRAINTS,
    READ_SHARED_CONTENT_SUMMARY,
    READ_SHARED_PURPOSE,
    READ_SHARED_WHEN_TO_USE,
    READ_WHEN_TO_USE,
    UPDATE_CONSTRAINTS,
    UPDATE_PURPOSE,
    UPDATE_WHEN_TO_USE,
)
from mcp_remlezrd.features.shareable.skill.meta import META
from mcp_remlezrd.features.shared.consts import TAG_MODE_RO, TAG_MODE_RW
from mcp_remlezrd.features.shared.domain import (
    MarkdownList,
    MarkdownListItem,
    RichMarkdownContent,
    SimpleMarkdownParagraph,
)

from ..formatters.descriptions import (
    ResourceTemplateDescriptionConfig,
    ToolDescriptionConfig,
)
from ..formatters.results import ToolResultFormat, resource_result, tool_result

logger = logging.getLogger(__name__)


def register_shareable_skill_components(mcp: FastMCP[Any], skill_service: ShareableSkillService):
    """Register shareable skill MCP tools, prompts and resources on the given FastMCP server."""
    logger.debug(
        "Initializing MCPShareableSkill component",
        extra={
            "event": "mcp.component.init",
            "component": "MCPShareableSkill",
            "service_available": skill_service is not None,
        },
    )
    # MCP Tools

    @mcp.tool(
        name=META.discover_tool,
        description=ToolDescriptionConfig(
            purpose=DISCOVER_PURPOSE,
            when_to_use=DISCOVER_WHEN_TO_USE,
            constraints=DISCOVER_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={META.tag, SHAREABLE.tag, TAG_MODE_RO},
    )
    async def discover_skills_only(
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ) -> ToolResult:
        """Discovery tool: returns a catalog of all available skills."""
        try:
            return tool_result(skill_service.discover(), fmt=ToolResultFormat.YAML)
        except Exception as e:
            await ctx.error(f"Failed to discover skills: {e}")
            raise ToolError(f"Failed to discover skills: {e}") from e

    @mcp.tool(
        name=META.create_tool,
        description=ToolDescriptionConfig(
            purpose=CREATE_PURPOSE,
            when_to_use=CREATE_WHEN_TO_USE,
            constraints=CREATE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
        tags={SHAREABLE.tag, META.tag, TAG_MODE_RW},
    )
    async def create(
        name: Annotated[str, "Skill name in kebab-case (used in filepath)"],
        description: Annotated[str, "Brief description"],
        purpose: Annotated[SimpleMarkdownParagraph, "Purpose section content (required)"],
        when_to_use: Annotated[MarkdownList, "List of trigger conditions (required)"],
        instructions: Annotated[
            list[dict[str, dict[str, str]]],
            "Step-by-step instructions as single-step dicts. Each step: one concrete action with specific values (commands, paths, criteria). No vague qualifiers. BAD: 'handle errors', 'optimize if needed'. GOOD: 'Run: ruff check src/', 'Verify status == 200'. (required)",
        ],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
        tags: Annotated[list[str] | None, "Classification tags"] = None,
        examples: Annotated[RichMarkdownContent | None, "Examples section content"] = None,
        edge_cases: Annotated[dict[str, MarkdownListItem] | None, "Dict mapping edge case title to description"] = None,
        references: Annotated[MarkdownList | None, "List of reference links"] = None,
        license: Annotated[str | None, "License name or reference"] = None,  # noqa: A002
        compatibility: Annotated[str | None, "Environment requirements"] = None,
        shared: Annotated[bool, "If True, create in shared directory; if False (default), create in project directory"] = False,
    ) -> ToolResult:
        """Create a new skill for reusable capabilities."""
        try:
            await ctx.info(f"Creating skill: {name}")
            return tool_result(
                skill_service.create(
                    name=name,
                    description=description,
                    purpose=purpose,
                    when_to_use=when_to_use,
                    instructions=instructions,
                    tags=tags,
                    examples=examples,
                    edge_cases=edge_cases,
                    references=references,
                    license=license,
                    compatibility=compatibility,
                    shared=shared,
                ),
                fmt=ToolResultFormat.JSON_COMPACT,
            )
        except Exception as e:
            await ctx.error(f"Failed to create skill '{name}': {e}")
            raise ToolError(f"Failed to create skill: {e}") from e

    @mcp.tool(
        name=META.update_tool,
        description=ToolDescriptionConfig(
            purpose=UPDATE_PURPOSE,
            when_to_use=UPDATE_WHEN_TO_USE,
            constraints=UPDATE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={SHAREABLE.tag, META.tag, TAG_MODE_RW},
    )
    async def update(
        name: Annotated[str, "Skill name"],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
        purpose: Annotated[SimpleMarkdownParagraph | None, "Purpose section content"] = None,
        when_to_use: Annotated[MarkdownList | None, "List of trigger conditions"] = None,
        instructions: Annotated[
            list[dict[str, dict[str, str]]] | None,
            "Step-by-step instructions as single-step dicts. Each step: one concrete action with specific values (commands, paths, criteria). No vague qualifiers. BAD: 'handle errors', 'optimize if needed'. GOOD: 'Run: ruff check src/', 'Verify status == 200'.",
        ] = None,
        examples: Annotated[RichMarkdownContent | None, "Examples section content"] = None,
        edge_cases: Annotated[dict[str, MarkdownListItem] | None, "Dict mapping edge case title to description"] = None,
        references: Annotated[MarkdownList | None, "List of reference links"] = None,
        tags: Annotated[list[str] | None, "Classification tags"] = None,
        description: Annotated[str | None, "Brief description"] = None,
        license: Annotated[str | None, "License name or reference"] = None,  # noqa: A002
        compatibility: Annotated[str | None, "Environment requirements"] = None,
        shared: Annotated[bool, "If True, update shared resource; if False (default), update project resource"] = False,
    ) -> ToolResult:
        """Update skill metadata and/or content sections.

        Only provided fields are modified. Others remain unchanged.
        """
        try:
            await ctx.info(f"Updating skill: {name}")
            updated = skill_service.update(
                name=name,
                purpose=purpose,
                when_to_use=when_to_use,
                instructions=instructions,
                examples=examples,
                edge_cases=edge_cases,
                references=references,
                tags=tags,
                description=description,
                license=license,
                compatibility=compatibility,
                shared=shared,
            )
            return tool_result(
                SkillUpdateResult(name=updated.name, updated_at=updated.updated_at, estimated_tokens=updated.estimated_tokens),
                fmt=ToolResultFormat.JSON_COMPACT,
            )
        except Exception as e:
            await ctx.error(f"Failed to update skill '{name}': {e}")
            raise ToolError(f"Failed to update skill: {e}") from e

    @mcp.tool(
        name=META.delete_tool,
        description=ToolDescriptionConfig(
            purpose=DELETE_PURPOSE,
            when_to_use=DELETE_WHEN_TO_USE,
            constraints=DELETE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": True, "idempotentHint": False, "openWorldHint": False},
        tags={SHAREABLE.tag, META.tag, TAG_MODE_RW},
    )
    async def delete(
        name: Annotated[str, "Skill name"],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
        shared: Annotated[bool, "If True, delete from shared directory; if False (default), delete from project directory"] = False,
    ) -> ToolResult:
        """Delete a skill by name."""
        try:
            return tool_result(skill_service.delete(name, force_shared=shared), fmt=ToolResultFormat.JSON_COMPACT)
        except ValueError as e:
            await ctx.error(f"Skill not found: {name}")
            raise ToolError(f"Shareable skill not found: {name}") from e
        except Exception as e:
            await ctx.error(f"Failed to delete skill '{name}': {e}")
            raise ToolError(f"Failed to delete skill: {e}") from e

    # MCP Resources

    @mcp.resource(
        uri=f"{META.base_uri}{{skill_name}}",
        name=META.resource_component,
        description=ResourceTemplateDescriptionConfig(
            purpose=READ_PURPOSE,
            content_summary=READ_CONTENT_SUMMARY,
            when_to_use=READ_WHEN_TO_USE,
            constraints=READ_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={META.tag, SHAREABLE.tag, TAG_MODE_RO},
        mime_type="text/markdown",
    )
    async def read(
        skill_name: str,
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ):
        """Context resource: Returns the full skill content in Markdown.

        Use this resource when you need to inject the complete skill content
        into the conversation context. The skill_name parameter can be
        discovered from the 'read_skill_index' resource.
        """
        try:
            return resource_result(skill_service.render(skill_name, force_shared=False))
        except Exception as e:
            await ctx.error(f"Failed to retrieve skill '{skill_name}': {e}")
            raise

    @mcp.resource(
        uri=f"{META.shared_base_uri}{{skill_name}}",
        name=META.shared_resource_component,
        description=ResourceTemplateDescriptionConfig(
            purpose=READ_SHARED_PURPOSE,
            content_summary=READ_SHARED_CONTENT_SUMMARY,
            when_to_use=READ_SHARED_WHEN_TO_USE,
            constraints=READ_SHARED_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={META.tag, SHAREABLE.tag, TAG_MODE_RO},
        mime_type="text/markdown",
    )
    async def read_shared(
        skill_name: str,
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ):
        """Context resource: Returns the full shared skill content in Markdown.

        Use this resource to access shared skills explicitly, bypassing
        project overrides. The skill_name parameter can be discovered
        from the 'read_skill_index' resource.
        """
        try:
            return resource_result(skill_service.render(skill_name, force_shared=True))
        except Exception as e:
            await ctx.error(f"Failed to retrieve shared skill '{skill_name}': {e}")
            raise
