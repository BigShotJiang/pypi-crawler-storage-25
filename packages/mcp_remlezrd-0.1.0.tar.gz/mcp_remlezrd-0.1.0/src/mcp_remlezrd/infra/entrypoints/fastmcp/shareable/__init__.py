"""Shareable resources server (rules and skills)."""

from fastmcp import FastMCP

from mcp_remlezrd import __version__
from mcp_remlezrd.features.shareable.rule import ShareableRuleService
from mcp_remlezrd.features.shareable.skill import ShareableSkillService

from .rule import register_shareable_rule_components
from .skill import register_shareable_skill_components


def create_shareable_server(
    rule_service: ShareableRuleService,
    skill_service: ShareableSkillService,
) -> FastMCP:
    """Create the shareable_refs server with rule and skill components."""
    server = FastMCP(
        name="shareable_refs",
        version=__version__,
        instructions="Shareable scope: Rules for coding standards and Skills for reusable workflows.",
    )

    register_shareable_rule_components(server, rule_service)
    register_shareable_skill_components(server, skill_service)

    return server
