"""MCP Project Glossary Components.

Provides MCP tools, resources, and prompts for glossary management.
"""

import logging
from typing import Annotated, Any

from fastmcp import FastMCP
from fastmcp.dependencies import CurrentContext
from fastmcp.tools import ToolResult
from mcp.server.fastmcp import Context
from mcp.server.fastmcp.exceptions import ToolError

from mcp_remlezrd.features.project.glossary import (
    GlossaryUpdateResult,
    ProjectGlossaryService,
)
from mcp_remlezrd.features.project.glossary.consts import (
    CREATE_CONSTRAINTS,
    CREATE_PURPOSE,
    CREATE_WHEN_TO_USE,
    DELETE_CONSTRAINTS,
    DELETE_PURPOSE,
    DELETE_WHEN_TO_USE,
    DISCOVER_CONSTRAINTS,
    DISCOVER_PURPOSE,
    DISCOVER_WHEN_TO_USE,
    READ_CONSTRAINTS,
    READ_CONTENT_SUMMARY,
    READ_PURPOSE,
    READ_WHEN_TO_USE,
    UPDATE_CONSTRAINTS,
    UPDATE_PURPOSE,
    UPDATE_WHEN_TO_USE,
)
from mcp_remlezrd.features.project.glossary.meta import META
from mcp_remlezrd.features.project.meta import PROJECT
from mcp_remlezrd.features.shared.consts import TAG_MODE_RO, TAG_MODE_RW
from mcp_remlezrd.features.shared.domain import (
    MarkdownList,
    MarkdownListItem,
    SimpleMarkdownContent,
    SimpleMarkdownParagraphs,
)

from ..formatters.descriptions import (
    ResourceTemplateDescriptionConfig,
    ToolDescriptionConfig,
)
from ..formatters.results import ToolResultFormat, resource_result, tool_result

logger = logging.getLogger(__name__)


def register_project_glossary_components(mcp: FastMCP[Any], glossary_service: ProjectGlossaryService):
    """Register glossary MCP tools, prompts and resources on the given FastMCP server."""
    logger.debug(
        "Initializing MCPGlossary component",
        extra={
            "event": "mcp.component.init",
            "component": "MCPGlossary",
            "service_available": glossary_service is not None,
        },
    )
    # MCP Tools

    @mcp.tool(
        name=META.discover_tool,
        description=ToolDescriptionConfig(
            purpose=DISCOVER_PURPOSE,
            when_to_use=DISCOVER_WHEN_TO_USE,
            constraints=DISCOVER_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={PROJECT.tag, META.tag, TAG_MODE_RO},
    )
    async def discover_glossary_only(
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ) -> ToolResult:
        """Discovery tool: returns a catalog of all available glossary entries."""
        try:
            return tool_result(glossary_service.discover(), fmt=ToolResultFormat.YAML)
        except Exception as e:
            await ctx.error(f"Failed to discover glossaries: {e}")
            raise ToolError(f"Failed to discover glossaries: {e}") from e

    @mcp.tool(
        name=META.create_tool,
        description=ToolDescriptionConfig(
            purpose=CREATE_PURPOSE,
            when_to_use=CREATE_WHEN_TO_USE,
            constraints=CREATE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
        tags={PROJECT.tag, META.tag, TAG_MODE_RW},
    )
    async def create(
        name: Annotated[str, "Glossary name in kebab-case (used in filepath)"],
        description: Annotated[str, "Brief description"],
        preamble: Annotated[SimpleMarkdownParagraphs, "Introductory paragraphs for the group of key terms (required)"],
        key_terms: Annotated[dict[str, MarkdownListItem], "Dict mapping term to definition (required)"],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
        alias: Annotated[list[str] | None, "List of synonyms, acronyms, and abbreviations"] = None,
        tags: Annotated[list[str] | None, "Classification tags"] = None,
        usage_context: Annotated[SimpleMarkdownContent | None, "Where these terms apply and how they're used together"] = None,
        examples: Annotated[list[dict[str, str]] | None, "List of {lang, content} dicts for fenced code blocks"] = None,
        relations: Annotated[MarkdownList | None, "List of essential relations to other terms"] = None,
        references: Annotated[MarkdownList | None, "List of reference links"] = None,
    ) -> ToolResult:
        """Create a new glossary entry."""
        try:
            await ctx.info(f"Creating glossary: {name}")
            return tool_result(
                glossary_service.create(
                    name=name,
                    description=description,
                    preamble=preamble,
                    key_terms=key_terms,
                    alias=alias,
                    tags=tags,
                    usage_context=usage_context,
                    examples=examples,
                    relations=relations,
                    references=references,
                ),
                fmt=ToolResultFormat.JSON_COMPACT,
            )
        except Exception as e:
            await ctx.error(f"Failed to create glossary '{name}': {e}")
            raise ToolError(f"Failed to create glossary: {e}") from e

    @mcp.tool(
        name=META.update_tool,
        description=ToolDescriptionConfig(
            purpose=UPDATE_PURPOSE,
            when_to_use=UPDATE_WHEN_TO_USE,
            constraints=UPDATE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={PROJECT.tag, META.tag, TAG_MODE_RW},
    )
    async def update(
        name: Annotated[str, "Glossary name"],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
        preamble: Annotated[SimpleMarkdownParagraphs | None, "Introductory paragraphs for the group of key terms"] = None,
        key_terms: Annotated[dict[str, MarkdownListItem] | None, "Dict mapping term to definition"] = None,
        usage_context: Annotated[SimpleMarkdownContent | None, "Where these terms apply and how they're used together"] = None,
        examples: Annotated[list[dict[str, str]] | None, "List of {lang, content} dicts for fenced code blocks"] = None,
        relations: Annotated[MarkdownList | None, "List of essential relations to other terms"] = None,
        references: Annotated[MarkdownList | None, "List of reference links"] = None,
        tags: Annotated[list[str] | None, "Classification tags"] = None,
        description: Annotated[str | None, "Brief description"] = None,
        alias: Annotated[list[str] | None, "List of synonyms, acronyms, and abbreviations"] = None,
    ) -> ToolResult:
        """Update glossary metadata and/or content sections.

        Only provided fields are modified. Others remain unchanged.
        Note: terms are automatically derived from key_terms keys when provided.
        """
        try:
            await ctx.info(f"Updating glossary: {name}")
            updated = glossary_service.update(
                name=name,
                preamble=preamble,
                key_terms=key_terms,
                usage_context=usage_context,
                examples=examples,
                relations=relations,
                references=references,
                tags=tags,
                description=description,
                alias=alias,
            )
            return tool_result(
                GlossaryUpdateResult(name=updated.name, updated_at=updated.updated_at, estimated_tokens=updated.estimated_tokens),
                fmt=ToolResultFormat.JSON_COMPACT,
            )
        except Exception as e:
            await ctx.error(f"Failed to update glossary '{name}': {e}")
            raise ToolError(f"Failed to update glossary: {e}") from e

    @mcp.tool(
        name=META.delete_tool,
        description=ToolDescriptionConfig(
            purpose=DELETE_PURPOSE,
            when_to_use=DELETE_WHEN_TO_USE,
            constraints=DELETE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": True, "idempotentHint": False, "openWorldHint": False},
        tags={PROJECT.tag, META.tag, TAG_MODE_RW},
    )
    async def delete(
        name: Annotated[str, "Glossary name"],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ) -> ToolResult:
        """Delete a glossary by name."""
        try:
            return tool_result(glossary_service.delete(name), fmt=ToolResultFormat.JSON_COMPACT)
        except ValueError as e:
            await ctx.error(f"Glossary not found: {name}")
            raise ToolError(f"Glossary not found: {name}") from e
        except Exception as e:
            await ctx.error(f"Failed to delete glossary '{name}': {e}")
            raise ToolError(f"Failed to delete glossary: {e}") from e

    # MCP Resources

    @mcp.resource(
        uri=f"{META.base_uri}{{glossary_name}}",
        name=META.resource_component,
        description=ResourceTemplateDescriptionConfig(
            purpose=READ_PURPOSE,
            content_summary=READ_CONTENT_SUMMARY,
            when_to_use=READ_WHEN_TO_USE,
            constraints=READ_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={PROJECT.tag, META.tag, TAG_MODE_RO},
        mime_type="text/markdown",
    )
    async def read(
        glossary_name: str,
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ):
        """Context resource: Returns the full glossary content in Markdown.

        Use this resource when you need to inject the complete glossary content
        into the conversation context. The glossary_name parameter can be
        discovered from the 'read_glossary_index' resource.
        """
        try:
            return resource_result(glossary_service.render(glossary_name))
        except Exception as e:
            await ctx.error(f"Failed to retrieve glossary '{glossary_name}': {e}")
            raise
