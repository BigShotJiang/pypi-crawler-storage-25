"""MCP Shareable Rule Components.

Provides MCP tools, resources, and prompts for shareable rules management.
"""

import logging
from typing import Annotated, Any

from fastmcp import FastMCP
from fastmcp.dependencies import CurrentContext
from fastmcp.tools import ToolResult
from mcp.server.fastmcp.exceptions import ToolError
from mcp.server.fastmcp.server import Context

from mcp_remlezrd.features.shareable.meta import SHAREABLE
from mcp_remlezrd.features.shareable.rule import (
    RuleUpdateResult,
    ShareableRuleService,
)
from mcp_remlezrd.features.shareable.rule.consts import (
    CREATE_CONSTRAINTS,
    CREATE_PURPOSE,
    CREATE_WHEN_TO_USE,
    DELETE_CONSTRAINTS,
    DELETE_PURPOSE,
    DELETE_WHEN_TO_USE,
    DISCOVER_CONSTRAINTS,
    DISCOVER_PURPOSE,
    DISCOVER_WHEN_TO_USE,
    READ_CONSTRAINTS,
    READ_CONTENT_SUMMARY,
    READ_PURPOSE,
    READ_SHARED_CONSTRAINTS,
    READ_SHARED_CONTENT_SUMMARY,
    READ_SHARED_PURPOSE,
    READ_SHARED_WHEN_TO_USE,
    READ_WHEN_TO_USE,
    UPDATE_CONSTRAINTS,
    UPDATE_PURPOSE,
    UPDATE_WHEN_TO_USE,
)
from mcp_remlezrd.features.shareable.rule.meta import META
from mcp_remlezrd.features.shared.consts import TAG_MODE_RO, TAG_MODE_RW
from mcp_remlezrd.features.shared.domain import (
    MarkdownList,
    RichMarkdownContent,
    SimpleMarkdownParagraph,
)

from ..formatters.descriptions import (
    ResourceTemplateDescriptionConfig,
    ToolDescriptionConfig,
)
from ..formatters.results import ToolResultFormat, resource_result, tool_result

logger = logging.getLogger(__name__)


def register_shareable_rule_components(mcp: FastMCP[Any], rule_service: ShareableRuleService):
    """Register shareable rule MCP tools, prompts and resources on the given FastMCP server."""
    logger.debug(
        "Initializing MCPShareableRule component",
        extra={
            "event": "mcp.component.init",
            "component": "MCPShareableRule",
            "service_available": rule_service is not None,
        },
    )
    # MCP Tools

    @mcp.tool(
        name=META.discover_tool,
        description=ToolDescriptionConfig(
            purpose=DISCOVER_PURPOSE,
            when_to_use=DISCOVER_WHEN_TO_USE,
            constraints=DISCOVER_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={SHAREABLE.tag, META.tag, TAG_MODE_RO},
    )
    async def discover_rules_only(
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ) -> ToolResult:
        """Discovery tool: returns a catalog of all available rules."""
        try:
            return tool_result(rule_service.discover(), fmt=ToolResultFormat.YAML)
        except Exception as e:
            await ctx.error(f"Failed to discover rules: {e}")
            raise ToolError(f"Failed to discover rules: {e}") from e

    @mcp.tool(
        name=META.create_tool,
        description=ToolDescriptionConfig(
            purpose=CREATE_PURPOSE,
            when_to_use=CREATE_WHEN_TO_USE,
            constraints=CREATE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
        tags={SHAREABLE.tag, META.tag, TAG_MODE_RW},
    )
    async def create(
        name: Annotated[str, "Rule name in kebab-case (used in filepath)"],
        description: Annotated[str, "Brief description"],
        purpose: Annotated[SimpleMarkdownParagraph, "Purpose section content (required)"],
        rules: Annotated[dict[str, MarkdownList], "Rules organized by category (required)"],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
        tags: Annotated[list[str] | None, "Classification tags"] = None,
        examples: Annotated[RichMarkdownContent | None, "Examples section content"] = None,
        references: Annotated[MarkdownList | None, "List of reference links"] = None,
        license: Annotated[str | None, "License name or reference"] = None,  # noqa: A002
        compatibility: Annotated[str | None, "Environment requirements"] = None,
        shared: Annotated[bool, "If True, create in shared directory; if False (default), create in project directory"] = False,
    ) -> ToolResult:
        """Create a new rule for AI context injection."""
        try:
            await ctx.info(f"Creating rule: {name}")
            return tool_result(
                rule_service.create(
                    name=name,
                    description=description,
                    purpose=purpose,
                    rules=rules,
                    tags=tags,
                    examples=examples,
                    references=references,
                    license=license,
                    compatibility=compatibility,
                    shared=shared,
                ),
                fmt=ToolResultFormat.JSON_COMPACT,
            )
        except Exception as e:
            await ctx.error(f"Failed to create rule '{name}': {e}")
            raise ToolError(f"Failed to create rule: {e}") from e

    @mcp.tool(
        name=META.update_tool,
        description=ToolDescriptionConfig(
            purpose=UPDATE_PURPOSE,
            when_to_use=UPDATE_WHEN_TO_USE,
            constraints=UPDATE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={SHAREABLE.tag, META.tag, TAG_MODE_RW},
    )
    async def update(
        name: Annotated[str, "Rule name"],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
        purpose: Annotated[SimpleMarkdownParagraph | None, "Purpose section content"] = None,
        rules: Annotated[dict[str, MarkdownList] | None, "Rules organized by category"] = None,
        examples: Annotated[RichMarkdownContent | None, "Examples section content"] = None,
        references: Annotated[MarkdownList | None, "List of reference links"] = None,
        tags: Annotated[list[str] | None, "Classification tags"] = None,
        description: Annotated[str | None, "Brief description"] = None,
        license: Annotated[str | None, "License name or reference"] = None,  # noqa: A002
        compatibility: Annotated[str | None, "Environment requirements"] = None,
        shared: Annotated[bool, "If True, update shared resource; if False (default), update project resource"] = False,
    ) -> ToolResult:
        """Update rule metadata and/or content sections.

        Only provided fields are modified. Others remain unchanged.
        """
        try:
            await ctx.info(f"Updating rule: {name}")
            updated = rule_service.update(
                name=name,
                purpose=purpose,
                rules=rules,
                examples=examples,
                references=references,
                tags=tags,
                description=description,
                license=license,
                compatibility=compatibility,
                shared=shared,
            )
            return tool_result(
                RuleUpdateResult(name=updated.name, updated_at=updated.updated_at, estimated_tokens=updated.estimated_tokens),
                fmt=ToolResultFormat.JSON_COMPACT,
            )
        except Exception as e:
            await ctx.error(f"Failed to update rule '{name}': {e}")
            raise ToolError(f"Failed to update rule: {e}") from e

    @mcp.tool(
        name=META.delete_tool,
        description=ToolDescriptionConfig(
            purpose=DELETE_PURPOSE,
            when_to_use=DELETE_WHEN_TO_USE,
            constraints=DELETE_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": False, "destructiveHint": True, "idempotentHint": False, "openWorldHint": False},
        tags={SHAREABLE.tag, META.tag, TAG_MODE_RW},
    )
    async def delete(
        name: Annotated[str, "Rule name"],
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
        shared: Annotated[bool, "If True, delete from shared directory; if False (default), delete from project directory"] = False,
    ) -> ToolResult:
        """Delete a rule by name."""
        try:
            return tool_result(rule_service.delete(name, force_shared=shared), fmt=ToolResultFormat.JSON_COMPACT)
        except ValueError as e:
            await ctx.error(f"Rule not found: {name}")
            raise ToolError(f"Shareable rule not found: {name}") from e
        except Exception as e:
            await ctx.error(f"Failed to delete rule '{name}': {e}")
            raise ToolError(f"Failed to delete rule: {e}") from e

    # MCP Resources

    @mcp.resource(
        uri=f"{META.base_uri}{{rule_name}}",
        name=META.resource_component,
        description=ResourceTemplateDescriptionConfig(
            purpose=READ_PURPOSE,
            content_summary=READ_CONTENT_SUMMARY,
            when_to_use=READ_WHEN_TO_USE,
            constraints=READ_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={SHAREABLE.tag, META.tag, TAG_MODE_RO},
        mime_type="text/markdown",
    )
    async def read(
        rule_name: str,
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ):
        """Context resource: Returns the full rule content in Markdown.

        Use this resource when you need to inject the complete rule content
        into the conversation context. The rule_name parameter can be
        discovered from the 'read_rule_index' resource.
        """
        try:
            return resource_result(rule_service.render(rule_name, force_shared=False))
        except Exception as e:
            await ctx.error(f"Failed to retrieve rule '{rule_name}': {e}")
            raise

    @mcp.resource(
        uri=f"{META.shared_base_uri}{{rule_name}}",
        name=META.shared_resource_component,
        description=ResourceTemplateDescriptionConfig(
            purpose=READ_SHARED_PURPOSE,
            content_summary=READ_SHARED_CONTENT_SUMMARY,
            when_to_use=READ_SHARED_WHEN_TO_USE,
            constraints=READ_SHARED_CONSTRAINTS,
        ).rendered,
        annotations={"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        tags={SHAREABLE.tag, META.tag, TAG_MODE_RO},
        mime_type="text/markdown",
    )
    async def read_shared(
        rule_name: str,
        ctx: Context = CurrentContext(),  # noqa: B008 # ty:ignore[invalid-parameter-default]
    ):
        """Context resource: Returns the full shared rule content in Markdown.

        Use this resource to access shared rules explicitly, bypassing
        project overrides. The rule_name parameter can be discovered
        from the 'read_rule_index' resource.
        """
        try:
            return resource_result(rule_service.render(rule_name, force_shared=True))
        except Exception as e:
            await ctx.error(f"Failed to retrieve shared rule '{rule_name}': {e}")
            raise
