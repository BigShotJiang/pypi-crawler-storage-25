"""Utilities for formatting MCP resource and tool results."""

import enum
import json

from fastmcp.resources import ResourceContent, ResourceResult
from fastmcp.tools import ToolResult
from mcp.types import TextContent
from pydantic import BaseModel
import yaml


def resource_result(content: str, mime_type: str = "text/markdown") -> ResourceResult:
    """Create a ResourceResult with a single ResourceContent.

    Args:
        content: The content string to return
        mime_type: The MIME type of the content (default: text/markdown)

    Returns:
        ResourceResult wrapping the content with proper MIME type
    """
    return ResourceResult(contents=[ResourceContent(content=content, mime_type=mime_type)])


class ToolResultFormat(enum.StrEnum):
    """Supported serialization formats for tool result ``content``."""

    JSON = "json"
    """Pretty-printed JSON (human-readable, higher token cost)."""

    JSON_COMPACT = "json_compact"
    """Compact JSON (minimal token cost)."""

    YAML = "yaml"
    """YAML block format (good readability for nested structures)."""


def tool_result(
    data: BaseModel,
    *,
    fmt: ToolResultFormat = ToolResultFormat.JSON_COMPACT,
) -> ToolResult:
    """Convert a Pydantic result to a ToolResult, suppressing outputSchema generation.

    This avoids inflating the ``tools/list`` payload with automatic output
    schemas while still returning structured data in the tool call response.
    The ``content`` field is serialized according to *fmt* so the LLM
    always sees the actual data regardless of client behaviour.

    Args:
        data: The Pydantic model to serialize as structured content.
        fmt: Serialization format for the ``content`` text field.
            Defaults to compact JSON for token efficiency.

    Returns:
        ToolResult with both readable content and structured data.
    """
    raw = data.model_dump(mode="json")

    match fmt:
        case ToolResultFormat.JSON:
            text = json.dumps(raw, indent=2, ensure_ascii=False)
        case ToolResultFormat.JSON_COMPACT:
            text = json.dumps(raw, separators=(",", ":"), ensure_ascii=False)
        case ToolResultFormat.YAML:
            text = yaml.dump(raw, sort_keys=False, allow_unicode=True, default_flow_style=False)
        case _:
            text = json.dumps(raw, separators=(",", ":"), ensure_ascii=False)

    return ToolResult(
        content=[TextContent(type="text", text=text)],
        structured_content=raw,
    )
