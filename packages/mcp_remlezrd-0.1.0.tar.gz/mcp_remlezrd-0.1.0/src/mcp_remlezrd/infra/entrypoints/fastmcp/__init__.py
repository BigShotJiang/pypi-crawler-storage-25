"""MCP entrypoint components.

This package provides MCP resource registration functions.
"""
