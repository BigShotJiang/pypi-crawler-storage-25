# mcp-remlezrd package initialization
# This file makes src/mcp_remlezrd a Python package.

# Imports for convenience (optional, can be empty)

import importlib.metadata
import os

from mcp_remlezrd.features.shared.app_meta import APP

try:
    __version__ = importlib.metadata.version(distribution_name=APP.app_name)
except importlib.metadata.PackageNotFoundError:
    __version__ = os.getenv("APP_VERSION", "0.0.0-dev")
