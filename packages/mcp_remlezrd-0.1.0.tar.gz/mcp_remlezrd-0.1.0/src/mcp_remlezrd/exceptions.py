"""Custom exceptions for the MCP RemLezrd application.

This module defines application-specific exceptions following the Error Handling Policy.
Use RemLezrdError and its subclasses for expected business logic errors that should
be handled gracefully by the application.
"""


class RemLezrdError(Exception):
    """Base exception for MCP RemLezrd application errors.

    Use for expected business logic errors that can be handled gracefully.
    Create subclasses when recovery code needs to distinguish specific error types.

    """

    def __init__(self, message: str, *args, **kwargs):
        """Initialize RemLezrdError with a descriptive message.

        Args:
            message: Clear, concise error description with context
            *args: Additional positional arguments passed to Exception
            **kwargs: Additional keyword arguments (for future extension)
        """
        super().__init__(message, *args)
        self.message = message
