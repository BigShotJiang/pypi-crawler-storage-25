"""Canonical map of form_type → backend endpoint, name, JSON DTO field name.

Single source of truth for the four service-level form types (applicant,
guide, send_file, payment). All historical caller sites import from here:

- ``tools/forms.py`` — FORM_TYPES alias for tool-level path lookup
- ``patch/adapters/service_form.py`` — ServiceFormAdapter routing
- ``tools/behaviours.py`` — componentbehaviour_repair_metadata form scan
- ``tools/component_formulas.py`` — preflight validator's allowed-endpoint list
- ``mcp_eregistrations_translations/tools/context.py`` — translation brief
  builder (strips the leading slash locally)

Backend routes verified against ApplicantFormPageController,
GuideFormPageController, PaymentFormController, and SendFileFormController
Spring annotations (BPA-backend, v1.37.2 / issue #165). Naming asymmetry
(``*FormPageController`` uses ``-form`` URLs; ``*FormController`` does not)
is intentional on the backend; the canonical map captures it once.
"""

from __future__ import annotations

from typing import TypedDict


class FormEndpointConfig(TypedDict):
    get_endpoint: str
    put_endpoint: str
    name: str
    json_field: str


FORM_ENDPOINTS: dict[str, FormEndpointConfig] = {
    "applicant": {
        "get_endpoint": "/service/{id}/applicant-form",
        "put_endpoint": "/applicant-form/{form_id}",
        "name": "Applicant Form",
        "json_field": "applicantForm",
    },
    "guide": {
        "get_endpoint": "/service/{id}/guide-form",
        "put_endpoint": "/guide-form/{form_id}",
        "name": "Guide Form",
        "json_field": "guideForm",
    },
    "send_file": {
        "get_endpoint": "/service/{id}/sendfile",
        "put_endpoint": "/sendfile/{form_id}",
        "name": "Send File Form",
        "json_field": "sendFileForm",
    },
    "payment": {
        "get_endpoint": "/service/{id}/payment",
        "put_endpoint": "/payment/{form_id}",
        "name": "Payment Form",
        "json_field": "paymentForm",
    },
}

VALID_FORM_TYPES: frozenset[str] = frozenset(FORM_ENDPOINTS)
