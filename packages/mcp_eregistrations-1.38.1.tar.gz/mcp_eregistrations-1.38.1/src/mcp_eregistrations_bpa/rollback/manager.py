"""Rollback manager for BPA operations.

This module provides the RollbackManager class for executing rollback operations
on BPA objects. It handles endpoint resolution, state retrieval, and API calls
to restore objects to their previous state.

Rollback strategies by operation type:
- create: DELETE the created object
- update: PUT with previous_state values to restore
- delete: POST to recreate object with previous_state
- link: Reverse the link operation (unlink)
- unlink: Reverse the unlink operation (link)
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from mcp_eregistrations_bpa.bpa_client import BPAClient
from mcp_eregistrations_bpa.bpa_client.errors import BPAClientError
from mcp_eregistrations_bpa.constants.form_endpoints import FORM_ENDPOINTS
from mcp_eregistrations_bpa.db import get_connection

__all__ = [
    "RollbackManager",
    "RollbackError",
    "RollbackNotPossibleError",
    "ROLLBACK_ENDPOINTS",
]


class RollbackError(Exception):
    """Base exception for rollback operations."""

    pass


class RollbackNotPossibleError(RollbackError):
    """Raised when rollback cannot be performed for a given audit entry."""

    pass


# Mapping: object_type -> (delete_endpoint, update_endpoint, create_endpoint)
# Endpoints use {id}, {service_id}, {registration_id} placeholders for substitution
# IMPORTANT: These endpoints must match the actual BPA API specification
# See: _bmad-output/implementation-artifacts/bpa-api-reference.md
ROLLBACK_ENDPOINTS: dict[str, tuple[str | None, str | None, str | None]] = {
    # Service: PUT /service with ID in body, DELETE /service/{id}
    "service": ("/service/{id}", "/service", "/service"),
    # Registration: No PUT endpoint exists in BPA API, create via service
    "registration": (
        "/registration/{id}",
        None,  # No PUT /registration endpoint in BPA API
        "/service/{service_id}/registration",
    ),
    # Determinants: Generic type used by determinant_delete, type-specific used by
    # individual create/update tools. All share the same generic DELETE endpoint.
    # Create endpoint for "determinant" is resolved by _get_create_endpoint using
    # the determinant_type param.
    "determinant": (
        "/service/{service_id}/determinant/{id}",
        None,  # Update is type-specific, use the typed entries below
        None,  # Create is type-specific, handled in _get_create_endpoint
    ),
    "textdeterminant": (
        "/service/{service_id}/determinant/{id}",
        "/service/{service_id}/textdeterminant",
        "/service/{service_id}/textdeterminant",
    ),
    "selectdeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/selectdeterminant",
    ),
    "radiodeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/radiodeterminant",
    ),
    "booleandeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/booleandeterminant",
    ),
    "numericdeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/numericdeterminant",
    ),
    "datedeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/datedeterminant",
    ),
    "classificationdeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/classificationdeterminant",
    ),
    "griddeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/griddeterminant",
    ),
    # Bot: No DELETE endpoint, PUT /bot with ID in body
    "bot": (
        None,  # No DELETE /bot endpoint in BPA API
        "/bot",
        "/service/{service_id}/bot",
    ),
    # Role: DELETE /role/{id}, PUT /role with ID in body
    "role": (
        "/role/{id}",
        "/role",
        "/service/{service_id}/role",
    ),
    # Document Requirement: Uses underscore in endpoint path
    "documentrequirement": (
        "/document_requirement/{id}",
        "/document_requirement",
        "/registration/{registration_id}/document_requirement",
    ),
    # Cost: DELETE /cost/{id}, PUT /cost with ID in body
    # Note: Create has fixcost/formulacost variants, handled by cost_type param
    "cost": (
        "/cost/{id}",
        "/cost",
        None,  # Create endpoint depends on cost_type, handled in _get_create_endpoint
    ),
    # Message: Global templates, DELETE /message/{id}, PUT /message, POST /message
    "message": (
        "/message/{id}",
        "/message",
        "/message",
    ),
    # Classification group (issue #103):
    #   create→DELETE /classification_group/{id} (uses standard branch)
    #   update→PUT /classification_group with body{id,...} — custom branch
    #     strips internal _operation marker before sending
    #   delete→POST /classification_group/{classification_id} + per-field
    #     re-add — custom branch in execute_rollback (the standard
    #     create-on-delete-rollback is insufficient because it can't recreate
    #     the lost ClassificationFieldGroup join rows).
    # The {classification_id} placeholder is substituted by _get_create_endpoint
    # from audit params['classification_id']. Group update has no path id
    # (id goes in body); group delete uses {id} not {classification_id}.
    "classification_group": (
        "/classification_group/{id}",
        "/classification_group",
        "/classification_group/{classification_id}",
    ),
    # Classification field group-set (issue #103):
    # All None — DO NOT REMOVE this entry. The custom branch in
    # execute_rollback dispatches `classification_field` BEFORE the standard
    # endpoint resolvers ever see it. The entry exists solely so the
    # `if object_type not in ROLLBACK_ENDPOINTS` registration check passes.
    # If this entry were dropped, validate_rollback() would reject every
    # entry_set_groups audit row as "not supported".
    "classification_field": (
        None,
        None,
        None,
    ),
    # BotRoleBots: No DELETE endpoint (backend). Delete is implemented as
    # PUT /botrolebots/{id} with actions=[]. See botrolebots module and
    # issue #94. Rollback routed via special-case branch below because the
    # shape doesn't fit the standard (delete, update, create) triple.
    "botrolebots": (
        None,  # Custom delete via PUT with empty actions
        "/botrolebots/{id}",
        "/role/{role_id}/botrolebots",
    ),
    # ComponentFormula + ComponentFormulaRow (issue #158):
    # All None — DO NOT REMOVE these entries. The custom branch in
    # execute_rollback dispatches both object_types to
    # _apply_componentformula_rollback BEFORE the standard endpoint resolvers
    # see them. The entries exist solely so the `if object_type not in
    # ROLLBACK_ENDPOINTS` registration check in validate_rollback() passes.
    # Rollback semantics: re-fetch current state, drift-check against
    # post_write_state, then apply before_state via DELETE (if before_state
    # is None — formula was created) or PUT (if before_state existed —
    # formula was modified or deleted).
    "component_formula": (None, None, None),
    "component_formula_row": (None, None, None),
    # Forms (issue #169): all three audit object_types share the same rollback
    # semantics — PUT the previous form envelope back to the form_type-specific
    # endpoint. Endpoints differ per form_type (applicant/guide/send_file/payment),
    # so they're resolved dynamically from FORM_ENDPOINTS in
    # _get_update_endpoint's special-case branch. Entries exist solely so the
    # `if object_type not in ROLLBACK_ENDPOINTS` registration check in
    # validate_rollback()/_get_update_endpoint() passes.
    "form": (None, None, None),
    "form_component": (None, None, None),
    "form_component_copy": (None, None, None),
}

# Alias for document_requirement (audit logs use underscore variant)
ROLLBACK_ENDPOINTS["document_requirement"] = ROLLBACK_ENDPOINTS["documentrequirement"]


class RollbackManager:
    """Manages rollback operations for BPA write operations.

    This class handles:
    1. Validation of rollback eligibility
    2. Retrieval of previous state from rollback_states
    3. Endpoint resolution based on object type
    4. Execution of the rollback via BPA API
    5. Marking the original operation as rolled back
    """

    def __init__(
        self, db_path: Path | None = None, instance: str | None = None
    ) -> None:
        """Initialize the RollbackManager.

        Args:
            db_path: Optional path to SQLite database. Uses default if not provided.
            instance: Instance profile name for BPA API calls.
        """
        self._db_path = db_path
        self._instance = instance

    async def _get_audit_entry(self, audit_id: str) -> dict[str, Any] | None:
        """Fetch an audit entry by ID.

        Args:
            audit_id: The UUID of the audit entry.

        Returns:
            Dict with audit entry data, or None if not found.
        """
        async with get_connection(self._db_path) as conn:
            cursor = await conn.execute(
                """
                SELECT id, timestamp, user_email, operation_type, object_type,
                       object_id, params, status, result, rollback_state_id
                FROM audit_logs
                WHERE id = ?
                """,
                (audit_id,),
            )
            row = await cursor.fetchone()
            if row is None:
                return None
            return dict(row)

    async def _get_rollback_state(
        self, rollback_state_id: str
    ) -> dict[str, Any] | None:
        """Fetch a rollback state by ID.

        Args:
            rollback_state_id: The UUID of the rollback state.

        Returns:
            Dict with rollback state data, or None if not found.
        """
        async with get_connection(self._db_path) as conn:
            cursor = await conn.execute(
                """
                SELECT id, audit_log_id, object_type, object_id,
                       previous_state, created_at
                FROM rollback_states
                WHERE id = ?
                """,
                (rollback_state_id,),
            )
            row = await cursor.fetchone()
            if row is None:
                return None
            return dict(row)

    def _check_already_rolled_back(self, result: dict[str, Any] | None) -> bool:
        """Check if an operation was already rolled back.

        Args:
            result: The result field from audit_logs (parsed JSON).

        Returns:
            True if already rolled back, False otherwise.
        """
        if result is None:
            return False
        return "rolled_back_at" in result

    async def validate_rollback(self, audit_id: str) -> dict[str, Any]:
        """Validate that a rollback can be performed for the given audit entry.

        This performs all pre-flight checks:
        1. Audit entry exists
        2. Operation status is 'success' (not failed or pending)
        3. Operation has not already been rolled back
        4. Rollback state exists

        Args:
            audit_id: The UUID of the audit entry to validate.

        Returns:
            The audit entry dict if validation passes.

        Raises:
            RollbackNotPossibleError: If rollback cannot be performed.
        """
        # Check audit entry exists
        entry = await self._get_audit_entry(audit_id)
        if entry is None:
            raise RollbackNotPossibleError(
                f"Audit entry '{audit_id}' not found. "
                "Use 'audit_list' to see available entries."
            )

        # Check status
        status = entry["status"]
        if status == "failed":
            raise RollbackNotPossibleError(
                f"Operation '{audit_id}' failed and made no changes. "
                "Nothing to rollback."
            )
        if status == "pending":
            raise RollbackNotPossibleError(
                f"Operation '{audit_id}' is still pending. "
                "Wait for it to complete before attempting rollback."
            )

        # Check if already rolled back
        result = json.loads(entry["result"]) if entry["result"] else None
        if self._check_already_rolled_back(result):
            # result is guaranteed to be a dict if check returns True
            assert result is not None
            rolled_back_at = result.get("rolled_back_at", "unknown time")
            raise RollbackNotPossibleError(
                f"Operation '{audit_id}' was already rolled back at {rolled_back_at}. "
                "Use 'audit_get' to see current state."
            )

        # Check rollback state exists
        if entry["rollback_state_id"] is None:
            raise RollbackNotPossibleError(
                f"Operation '{audit_id}' has no saved state for rollback. "
                "This may be an older operation before rollback was enabled."
            )

        return entry

    def _get_delete_endpoint(
        self, object_type: str, object_id: str, params: dict[str, Any]
    ) -> str:
        """Resolve the DELETE endpoint for an object type.

        Args:
            object_type: The type of object (service, registration, etc.)
            object_id: The ID of the object to delete.
            params: Additional parameters for endpoint resolution (service_id, etc.)

        Returns:
            The resolved DELETE endpoint path.

        Raises:
            RollbackError: If object type not supported or endpoint not available.
        """
        if object_type not in ROLLBACK_ENDPOINTS:
            raise RollbackError(
                f"Rollback not supported for object type '{object_type}'."
            )

        delete_endpoint, _, _ = ROLLBACK_ENDPOINTS[object_type]
        if delete_endpoint is None:
            raise RollbackError(
                f"DELETE operation not available for object type '{object_type}'."
            )

        # Substitute placeholders
        endpoint = delete_endpoint.replace("{id}", str(object_id))
        if "{service_id}" in endpoint:
            service_id = params.get("service_id")
            if not service_id:
                raise RollbackError(
                    f"Cannot resolve DELETE endpoint for '{object_type}': "
                    "service_id not found in params."
                )
            endpoint = endpoint.replace("{service_id}", str(service_id))

        return endpoint

    def _get_update_endpoint(
        self, object_type: str, object_id: str, params: dict[str, Any]
    ) -> str:
        """Resolve the PUT endpoint for an object type.

        Args:
            object_type: The type of object (service, registration, etc.)
            object_id: The ID of the object to update.
            params: Additional parameters for endpoint resolution.

        Returns:
            The resolved PUT endpoint path.

        Raises:
            RollbackError: If object type not supported or endpoint not available.
        """
        if object_type not in ROLLBACK_ENDPOINTS:
            raise RollbackError(
                f"Rollback not supported for object type '{object_type}'."
            )

        # Special case (issue #169): form rollback endpoint depends on form_type.
        # All three form-related audit object_types share the same restore path —
        # PUT the previous envelope back to the form_type's PUT endpoint.
        if object_type in {"form", "form_component", "form_component_copy"}:
            form_type = params.get("form_type")
            if not form_type:
                raise RollbackError(
                    f"Cannot resolve UPDATE endpoint for '{object_type}': "
                    "form_type not found in audit params."
                )
            cfg = FORM_ENDPOINTS.get(form_type)
            if cfg is None:
                raise RollbackError(
                    f"Cannot resolve UPDATE endpoint for '{object_type}': "
                    f"unknown form_type '{form_type}' (expected one of: "
                    f"{', '.join(sorted(FORM_ENDPOINTS))})."
                )
            return cfg["put_endpoint"].replace("{form_id}", str(object_id))

        _, update_endpoint, _ = ROLLBACK_ENDPOINTS[object_type]
        if update_endpoint is None:
            raise RollbackError(
                f"UPDATE operation not available for object type '{object_type}'."
            )

        # Substitute placeholders
        endpoint = update_endpoint.replace("{id}", str(object_id))
        if "{service_id}" in endpoint:
            service_id = params.get("service_id")
            if not service_id:
                raise RollbackError(
                    f"Cannot resolve UPDATE endpoint for '{object_type}': "
                    "service_id not found in params."
                )
            endpoint = endpoint.replace("{service_id}", str(service_id))

        return endpoint

    def _get_create_endpoint(self, object_type: str, params: dict[str, Any]) -> str:
        """Resolve the POST endpoint for an object type.

        Args:
            object_type: The type of object (service, registration, etc.)
            params: Additional parameters for endpoint resolution.

        Returns:
            The resolved POST endpoint path.

        Raises:
            RollbackError: If object type not supported or endpoint not available.
        """
        if object_type not in ROLLBACK_ENDPOINTS:
            raise RollbackError(
                f"Rollback not supported for object type '{object_type}'."
            )

        # Special case: cost has two create endpoints depending on cost_type
        if object_type == "cost":
            cost_type = params.get("cost_type", "fixed")
            registration_id = params.get("registration_id")
            if not registration_id:
                raise RollbackError(
                    "Cannot resolve CREATE endpoint for 'cost': "
                    "registration_id not found in params."
                )
            if cost_type == "formula":
                return f"/registration/{registration_id}/formulacost"
            return f"/registration/{registration_id}/fixcost"

        # Special case: generic "determinant" resolves to type-specific endpoint
        if object_type == "determinant":
            det_type = params.get("determinant_type", "")
            service_id = params.get("service_id")
            if not service_id:
                raise RollbackError(
                    "Cannot resolve CREATE endpoint for 'determinant': "
                    "service_id not found in params."
                )
            type_map = {
                "text": "textdeterminant",
                "boolean": "booleandeterminant",
                "selection": "selectdeterminant",
                "numeric": "numericdeterminant",
                "date": "datedeterminant",
                "classification": "classificationdeterminant",
                "grid": "griddeterminant",
            }
            endpoint_type = type_map.get(det_type)
            if not endpoint_type:
                raise RollbackError(
                    f"Cannot resolve CREATE endpoint for determinant: "
                    f"unknown determinant_type '{det_type}' in params."
                )
            return f"/service/{service_id}/{endpoint_type}"

        _, _, create_endpoint = ROLLBACK_ENDPOINTS[object_type]
        if create_endpoint is None:
            # Defensive: classification_field has (None,None,None) on purpose
            # (custom branch in execute_rollback handles it before we get here).
            # If anyone routes around the special-case branches in the future,
            # we want a clean RollbackError, not None.replace() AttributeError.
            raise RollbackError(
                f"CREATE operation not available for object type '{object_type}'."
            )

        # Substitute placeholders
        endpoint = create_endpoint
        if "{service_id}" in endpoint:
            service_id = params.get("service_id")
            if not service_id:
                raise RollbackError(
                    f"Cannot resolve CREATE endpoint for '{object_type}': "
                    "service_id not found in params."
                )
            endpoint = endpoint.replace("{service_id}", str(service_id))
        if "{registration_id}" in endpoint:
            registration_id = params.get("registration_id")
            if not registration_id:
                raise RollbackError(
                    f"Cannot resolve CREATE endpoint for '{object_type}': "
                    "registration_id not found in params."
                )
            endpoint = endpoint.replace("{registration_id}", str(registration_id))
        if "{classification_id}" in endpoint:
            classification_id = params.get("classification_id")
            if not classification_id:
                raise RollbackError(
                    f"Cannot resolve CREATE endpoint for '{object_type}': "
                    "classification_id not found in params."
                )
            endpoint = endpoint.replace("{classification_id}", str(classification_id))

        return endpoint

    async def execute_rollback(
        self,
        operation_type: str,
        object_type: str,
        object_id: str,
        previous_state: dict[str, Any] | None,
        params: dict[str, Any],
        result: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute the rollback operation via BPA API.

        Strategy by operation type:
        - create: DELETE the object (no previous state needed)
        - update: PUT with previous_state values
        - delete: POST to recreate with previous_state
        - link: Call unlink operation
        - unlink: Call link operation

        Args:
            operation_type: The original operation type (create, update, delete, etc.)
            object_type: The type of object.
            object_id: The ID of the object.
            previous_state: The state to restore (None for create operations).
            params: Additional context parameters from the original operation.
            result: Optional post-write state from the original operation's audit
                `result` field (stored by mark_success). Used by component_formula
                rollback for drift detection (compare current state vs what MCP
                wrote). None for standard rollback paths.

        Returns:
            Dict with rollback execution result.

        Raises:
            RollbackError: If the BPA API call fails.
        """
        try:
            async with BPAClient.for_instance(self._instance) as client:
                # Special-case: botrolebots has no DELETE endpoint and needs
                # a wrapped previous_state ({role_id, record, _was_create}).
                # Issue #94.
                if object_type == "botrolebots":
                    return await self._rollback_botrolebots(
                        client,
                        operation_type=operation_type,
                        object_id=object_id,
                        previous_state=previous_state,
                    )

                # Special-case: classification_group delete needs to recreate
                # group AND restore field-group joins. Issue #103.
                if object_type == "classification_group" and operation_type == "delete":
                    return await self._rollback_classification_group_delete(
                        client,
                        object_id=object_id,
                        previous_state=previous_state,
                    )

                # Special-case: classification_group update strips internal
                # markers from the PUT body. Issue #103.
                if object_type == "classification_group" and operation_type == "update":
                    body = {
                        k: v
                        for k, v in (previous_state or {}).items()
                        if not k.startswith("_")
                    }
                    await client.put("/classification_group", json=body)
                    return {"action": "restored", "state": body}

                # Special-case: classification_field (entry_set_groups)
                # rollback uses POST /classification/{type_id}/field with
                # the captured pre-state entry. Issue #103.
                if object_type == "classification_field" and operation_type == "update":
                    return await self._rollback_classification_field_update(
                        client,
                        previous_state=previous_state,
                    )

                # Special-case: component_formula + component_formula_row (#158).
                # Both share the same rollback semantics: restore the whole formula
                # state with drift protection. Uses the result field (post_write_state)
                # from the audit log for content-based drift comparison (UUIDs change
                # on every PUT — CLAUDE.md § "Row UUIDs are NOT stable across writes").
                # Routes to _apply_componentformula_rollback.
                if object_type in ("component_formula", "component_formula_row"):
                    from fastmcp.exceptions import ToolError

                    from mcp_eregistrations_bpa.tools.component_formulas import (
                        _apply_componentformula_rollback,
                    )

                    # object_id format: "{service_id}/{component_key}" (set by all 5
                    # write tools' record_pending calls).
                    if "/" not in object_id:
                        raise RollbackError(
                            f"component_formula rollback: object_id '{object_id}' is "
                            f"not in expected 'service_id/component_key' format."
                        )
                    service_id, component_key = object_id.split("/", 1)

                    # before_state is wrapped in {"before_state": ...} by all 5 tools'
                    # save_rollback_state calls. previous_state itself comes from
                    # rollback_state['previous_state'] (already parsed by
                    # perform_rollback).
                    before_state = (previous_state or {}).get("before_state")
                    # post_write_state is the result dict from mark_success.
                    # For row tools and upsert: shape is {id, service_id,
                    #     component_key, rows: [...], audit_id, ...}.
                    # For delete: shape is {deleted: ...} or {no_op: ...} —
                    #     these have no formulaRows to drift-check.
                    # _apply_componentformula_rollback tolerates either shape via
                    # its `(post_write_state or {}).get("formulaRows")` extraction.
                    post_write_state = result

                    try:
                        await _apply_componentformula_rollback(
                            instance=self._instance,
                            service_id=service_id,
                            component_key=component_key,
                            before_state=before_state,
                            post_write_state=post_write_state,
                        )
                    except ToolError as e:
                        raise RollbackNotPossibleError(
                            f"Rollback refused: {e}. Inspect audit log via "
                            "audit_get(audit_id=...) and recover manually if needed."
                        ) from e
                    return {
                        "action": "restored" if before_state is not None else "deleted",
                        "object_id": object_id,
                    }

                if operation_type == "create":
                    # Delete the created object
                    endpoint = self._get_delete_endpoint(object_type, object_id, params)
                    await client.delete(endpoint)
                    return {"action": "deleted", "object_id": object_id}

                elif operation_type == "update":
                    # Restore previous values
                    endpoint = self._get_update_endpoint(object_type, object_id, params)
                    api_result = await client.put(endpoint, json=previous_state)
                    return {"action": "restored", "state": api_result}

                elif operation_type == "delete":
                    # Recreate the object
                    endpoint = self._get_create_endpoint(object_type, params)

                    # Messages: strip ID fields (BPA rejects recreating with same ID)
                    # Other types: preserve original payload
                    if object_type == "message":
                        create_payload = {
                            k: v
                            for k, v in (previous_state or {}).items()
                            if k not in ("id", "businessKey", "business_key")
                        }
                        api_result = await client.post(endpoint, json=create_payload)
                        return {
                            "action": "recreated",
                            "new_id": api_result.get("id") if api_result else None,
                            "original_id": (
                                previous_state.get("id") if previous_state else None
                            ),
                        }
                    else:
                        api_result = await client.post(endpoint, json=previous_state)
                        return {
                            "action": "recreated",
                            "new_id": api_result.get("id") if api_result else None,
                        }

                elif operation_type == "link":
                    # TODO: Implement link rollback (unlink)
                    raise RollbackError(
                        f"Rollback for '{operation_type}' operations "
                        "is not yet implemented."
                    )

                elif operation_type == "unlink":
                    # TODO: Implement unlink rollback (link)
                    raise RollbackError(
                        f"Rollback for '{operation_type}' operations "
                        "is not yet implemented."
                    )

                else:
                    raise RollbackError(
                        f"Unknown operation type '{operation_type}'. "
                        "Cannot determine rollback strategy."
                    )

        except BPAClientError as e:
            raise RollbackError(f"BPA API error during rollback: {e}") from e

    async def _rollback_botrolebots(
        self,
        client: BPAClient,
        *,
        operation_type: str,
        object_id: str,
        previous_state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Rollback for BotRoleBots (issue #94).

        The backend has no DELETE endpoint, and the previous_state shape
        carries a `_was_create` marker + the raw record. Rollback strategy:

        - operation_type=create: PUT /botrolebots/{id} with actions=[] to
          delete the created record. `object_id` must be the botrolebots_id,
          which the save tool stores when was_create=True (from post-write
          verify) or None if the POST failed mid-flight.
        - operation_type=update: PUT /botrolebots/{id} with the captured
          previous actions to restore prior state.
        - operation_type=delete: POST /role/{role_id}/botrolebots with the
          saved actions to recreate.
        """
        if previous_state is None:
            raise RollbackError(
                "Cannot rollback botrolebots: previous_state is missing."
            )

        record = previous_state.get("record") or {}
        role_id = previous_state.get("role_id")
        actions = record.get("actions") or []

        if operation_type == "create":
            # Delete the created record via empty-actions PUT.
            if not object_id or object_id in ("None", ""):
                raise RollbackError(
                    "Cannot rollback botrolebots create: botrolebots_id "
                    "was not captured. The save may have failed before "
                    "the record was committed."
                )
            await client.put(
                f"/botrolebots/{object_id}",
                json={"actions": []},
            )
            return {"action": "deleted", "object_id": object_id}

        if operation_type == "update":
            if not object_id:
                raise RollbackError(
                    "Cannot rollback botrolebots update: object_id missing."
                )
            # Strip server-assigned ids so backend treats this as fresh save.
            clean_actions = [{k: v for k, v in a.items() if k != "id"} for a in actions]
            await client.put(
                f"/botrolebots/{object_id}",
                json={"actions": clean_actions},
            )
            return {"action": "restored", "object_id": object_id}

        if operation_type == "delete":
            if not role_id:
                raise RollbackError(
                    "Cannot rollback botrolebots delete: role_id missing "
                    "in previous_state."
                )
            clean_actions = [{k: v for k, v in a.items() if k != "id"} for a in actions]
            await client.post(
                f"/role/{role_id}/botrolebots",
                json={"actions": clean_actions},
            )
            return {"action": "recreated", "role_id": role_id}

        raise RollbackError(
            f"Unknown operation_type '{operation_type}' for botrolebots."
        )

    async def _rollback_classification_group_delete(
        self,
        client: BPAClient,
        *,
        object_id: str,
        previous_state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Recreate a deleted classification_group + restore its field joins.

        Backend deletes ClassificationFieldGroup rows when a group is deleted.
        Rollback re-creates the group (new ID assigned by backend) and then,
        for each affected field_id, re-fetches the entry and POSTs it with
        the new group appended to its classificationGroups list.

        Continues on per-field error so a single failure doesn't abort the
        whole rollback — the failed_field_ids list lets operators investigate.
        """
        if not previous_state or "group" not in previous_state:
            raise RollbackError(
                "previous_state must contain 'group' for classification_group "
                "delete rollback."
            )
        group = previous_state["group"]
        type_id = group.get("classification_type_id")
        if not type_id:
            raise RollbackError(
                "previous_state.group.classification_type_id required for "
                "classification_group delete rollback."
            )

        # 1. Recreate the group. If a concurrent caller has already created
        # a group with this name, surface clearly — manual intervention is
        # required, we can't silently merge.
        group_payload: dict[str, Any] = {"name": group.get("name")}
        if group.get("sort_order") is not None:
            group_payload["sortOrder"] = group["sort_order"]
        if group.get("visible") is not None:
            group_payload["visible"] = group["visible"]
        try:
            created = await client.post(
                f"/classification_group/{type_id}", json=group_payload
            )
        except BPAClientError as e:
            if "already exists" in str(e).lower():
                raise RollbackError(
                    f"Cannot rollback delete of group '{group.get('name')}': "
                    f"a group with this name was created in the interim. "
                    f"Manual intervention required to reconcile. "
                    f"Field IDs that lost their membership: "
                    f"{previous_state.get('field_ids') or []}. "
                    f"Backend message: {e}"
                ) from e
            raise
        new_group_id = created.get("id") if isinstance(created, dict) else None

        # 2. Restore each field's group membership
        field_ids = previous_state.get("field_ids") or []
        restored: list[str] = []
        failed: list[dict[str, Any]] = []
        if field_ids and new_group_id:
            try:
                pageable = await client.get_all_pageable(
                    "/classification/{id}/pageable",
                    path_params={"id": type_id},
                    resource_type="classification",
                )
                entries_by_id = {
                    e.get("id"): e for e in (pageable.get("content") or [])
                }
            except Exception as e:
                # Couldn't enumerate fields — surface the failure but keep
                # the new group already recreated.
                return {
                    "action": "recreated_with_join_rows",
                    "new_group_id": new_group_id,
                    "restored_field_count": 0,
                    "failed_field_ids": [
                        {"id": fid, "error": f"pre-fetch: {e}"} for fid in field_ids
                    ],
                }

            for fid in field_ids:
                target = entries_by_id.get(fid)
                if target is None:
                    failed.append({"id": fid, "error": "field not found"})
                    continue
                try:
                    payload = {
                        k: v
                        for k, v in target.items()
                        if k
                        not in (
                            "createdBy",
                            "createdWhen",
                            "lastChangedBy",
                            "lastChangedWhen",
                        )
                    }
                    existing_groups = list(payload.get("classificationGroups") or [])
                    # Append new group only if not already present
                    if not any(g.get("id") == new_group_id for g in existing_groups):
                        existing_groups.append(
                            {
                                "id": new_group_id,
                                "name": group.get("name"),
                                "sortOrder": group.get("sort_order"),
                            }
                        )
                    payload["classificationGroups"] = existing_groups
                    await client.post(
                        f"/classification/{type_id}/field",
                        json=payload,
                    )
                    restored.append(fid)
                except Exception as e:
                    failed.append({"id": fid, "error": str(e)})

        return {
            "action": "recreated_with_join_rows",
            "new_group_id": new_group_id,
            "restored_field_count": len(restored),
            "failed_field_ids": failed,
        }

    async def _rollback_classification_field_update(
        self,
        client: BPAClient,
        *,
        previous_state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Re-POST the captured pre-state entry to restore its groups verbatim.

        previous_state must contain previous_entry (the deepcopy captured at
        write-time). Internal markers (_operation, etc.) are stripped before
        sending.
        """
        if not previous_state or "previous_entry" not in previous_state:
            raise RollbackError(
                "previous_state must contain 'previous_entry' for "
                "classification_field update rollback."
            )
        type_id = previous_state.get("classification_id")
        if not type_id:
            raise RollbackError(
                "previous_state.classification_id required for "
                "classification_field update rollback."
            )
        entry = previous_state["previous_entry"]
        # Strip stale audit fields just in case they slipped into capture
        body = {
            k: v
            for k, v in entry.items()
            if k
            not in (
                "createdBy",
                "createdWhen",
                "lastChangedBy",
                "lastChangedWhen",
            )
        }
        await client.post(
            f"/classification/{type_id}/field",
            json=body,
        )
        return {
            "action": "restored",
            "entry_id": previous_state.get("entry_id"),
            "classification_id": type_id,
        }

    async def _mark_rolled_back(
        self,
        audit_id: str,
        rollback_audit_id: str,
        rolled_back_at: str,
    ) -> None:
        """Mark the original audit entry as rolled back.

        Updates the result field of the original audit entry to include
        rollback metadata, preventing double-rollback.

        Args:
            audit_id: The original audit entry ID.
            rollback_audit_id: The ID of the rollback audit entry.
            rolled_back_at: ISO 8601 timestamp of when rollback occurred.
        """
        async with get_connection(self._db_path) as conn:
            # Get current result
            cursor = await conn.execute(
                "SELECT result FROM audit_logs WHERE id = ?",
                (audit_id,),
            )
            row = await cursor.fetchone()
            if row is None:
                return

            # Update result with rollback info
            current_result = json.loads(row["result"]) if row["result"] else {}
            current_result["rolled_back_at"] = rolled_back_at
            current_result["rollback_audit_id"] = rollback_audit_id

            await conn.execute(
                "UPDATE audit_logs SET result = ? WHERE id = ?",
                (json.dumps(current_result), audit_id),
            )
            await conn.commit()

    async def perform_rollback(self, audit_id: str) -> dict[str, Any]:
        """Perform a complete rollback operation.

        This is the main entry point for rollback operations. It:
        1. Validates the rollback can be performed
        2. Retrieves the previous state
        3. Executes the rollback via BPA API
        4. Marks the original operation as rolled back

        Note: This method does NOT create an audit record for the rollback
        operation itself - that should be done by the calling tool.

        Args:
            audit_id: The UUID of the audit entry to rollback.

        Returns:
            Dict with rollback result including:
            - status: "success"
            - message: Human-readable description
            - original_operation: Details of what was rolled back
            - restored_state: The restored object state (if applicable)

        Raises:
            RollbackNotPossibleError: If validation fails.
            RollbackError: If execution fails.
        """
        # Validate rollback
        entry = await self.validate_rollback(audit_id)

        # Get rollback state
        rollback_state = await self._get_rollback_state(entry["rollback_state_id"])
        if rollback_state is None:
            raise RollbackError(
                f"Rollback state '{entry['rollback_state_id']}' not found. "
                "Database may be corrupted."
            )

        # Parse previous state
        previous_state = (
            json.loads(rollback_state["previous_state"])
            if rollback_state["previous_state"]
            else None
        )

        # Parse params for context (service_id, registration_id, etc.)
        params = json.loads(entry["params"]) if entry["params"] else {}

        # Parse post-write state from audit result field (used by
        # component_formula rollback for drift detection).
        result_field = json.loads(entry["result"]) if entry.get("result") else None

        # Execute rollback
        operation_type = entry["operation_type"]
        object_type = entry["object_type"]
        # For create operations, object_id in audit_logs is None (we don't know ID
        # until after creation). Use object_id from rollback_state as fallback.
        object_id = entry["object_id"] or rollback_state["object_id"]

        exec_result = await self.execute_rollback(
            operation_type=operation_type,
            object_type=object_type,
            object_id=object_id,
            previous_state=previous_state,
            params=params,
            result=result_field,
        )

        # Invalidate form cache after form rollback (issue #169 expanded to
        # cover all three form-related audit object_types).
        if object_type in {"form", "form_component", "form_component_copy"}:
            service_id = params.get("service_id")
            form_type = params.get("form_type")
            if service_id and form_type:
                try:
                    from mcp_eregistrations_bpa.db.form_cache import (
                        invalidate_form_cache,
                    )

                    await invalidate_form_cache(
                        str(service_id), form_type, self._db_path
                    )
                except Exception:  # noqa: S110 — best-effort cache invalidation after rollback; SQLite/import errors are non-fatal.
                    pass

        # Build message
        action = exec_result.get("action", "unknown")
        if action == "deleted":
            message = (
                f"Rolled back 'create' on {object_type} '{object_id}' - object deleted"
            )
        elif action == "restored":
            message = f"Rolled back 'update' on {object_type} '{object_id}'"
        elif action == "recreated":
            new_id = exec_result.get("new_id", "unknown")
            message = (
                f"Rolled back 'delete' on {object_type} '{object_id}' - "
                f"object recreated as '{new_id}'"
            )
        else:
            message = f"Rolled back '{operation_type}' on {object_type} '{object_id}'"

        # Build response
        rolled_back_at = datetime.now(UTC).isoformat()
        result: dict[str, Any] = {
            "status": "success",
            "message": message,
            "original_operation": {
                "audit_id": entry["id"],
                "operation_type": operation_type,
                "object_type": object_type,
                "object_id": object_id,
                "timestamp": entry["timestamp"],
            },
            "restored_state": previous_state,
            "rolled_back_at": rolled_back_at,
        }

        # Add new_id for recreated objects
        if action == "recreated" and exec_result.get("new_id"):
            result["new_object_id"] = exec_result["new_id"]

        return result
