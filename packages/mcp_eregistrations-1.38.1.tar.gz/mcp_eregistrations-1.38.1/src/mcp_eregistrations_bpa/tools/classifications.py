"""MCP tools for BPA classification/catalog operations.

This module provides tools for listing, retrieving, creating, and updating
BPA classifications (catalog data sources used for dropdown fields in forms),
plus group management (issue #103) — listing/creating/updating/deleting
ClassificationGroups and setting an entry's group memberships in REPLACE mode.

Write operations follow the audit-before-write pattern:
1. Validate parameters (pre-flight, no audit record if validation fails)
2. Create PENDING audit record
3. Execute BPA API call
4. Update audit record to SUCCESS or FAILED
"""

from __future__ import annotations

import copy
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_bpa.audit.context import (
    NotAuthenticatedError,
    get_current_user_email,
)
from mcp_eregistrations_bpa.audit.logger import AuditLogger
from mcp_eregistrations_bpa.bpa_client import BPAClient
from mcp_eregistrations_bpa.bpa_client.errors import (
    BPAClientError,
    BPANotFoundError,
    translate_error,
)
from mcp_eregistrations_bpa.config import resolve_db_path
from mcp_eregistrations_bpa.tools.large_response import large_response_handler

__all__ = [
    "classification_list",
    "classification_get",
    "classification_search",
    "classification_create",
    "classification_update",
    "classification_delete",
    "classification_export_csv",
    "classification_apply_country_codes",
    "classification_groups_list",
    "classification_group_create",
    "classification_group_update",
    "classification_group_delete",
    "classification_entry_set_groups",
    "register_classification_tools",
]


def _validate_group_name(name: str) -> str:
    """Validate group name (1-255 chars). Returns the trimmed name."""
    if not name or not name.strip():
        raise ToolError("Cannot operate on classification group: 'name' is required.")
    trimmed = name.strip()
    if len(trimmed) > 255:
        raise ToolError(
            "Cannot operate on classification group: 'name' must be 255 "
            "characters or less."
        )
    return trimmed


async def _assert_classification_exists(
    client: Any, classification_id: str | int
) -> dict[str, Any]:
    """Pre-flight: raise ToolError with friendly message if classification missing.

    Returns the /classification_type/{id} response dict on success — callers
    that need parent-classification metadata (id, name, businessKey, ...)
    can use it directly instead of issuing a second HTTP call.

    The /type_classification_group/{id} endpoint silently leaks groups from
    other classifications when the id is unknown — this helper is the only
    cheap way to surface a clean 'not found' to the caller.
    """
    try:
        meta: dict[str, Any] = await client.get(
            "/classification_type/{id}",
            path_params={"id": classification_id},
            resource_type="classification",
            resource_id=classification_id,
        )
        return meta
    except BPANotFoundError:
        raise ToolError(
            f"Classification '{classification_id}' not found. "
            "Use 'classification_list' to see available classifications."
        ) from None


# Backend-managed audit fields that must NEVER be echoed back on a write —
# Jackson @PrePersist/@PreUpdate will overwrite or reject stale values.
_AUDIT_FIELDS_TO_STRIP = (
    "createdBy",
    "createdWhen",
    "lastChangedBy",
    "lastChangedWhen",
)


def _is_group_already_exists_error(err: BPAClientError) -> bool:
    """Detect backend's ObjectAlreadyExists for ClassificationGroup specifically.

    Backend message format: "ClassificationGroup with name '...' already exists!"
    Match BOTH 'classificationgroup' and 'already exists' so a generic
    ObjectAlreadyExists for some unrelated resource doesn't false-positive.
    """
    msg = (str(err) or "").lower()
    return "classificationgroup" in msg and "already exists" in msg


def _transform_classification_group(
    group: dict[str, Any], queried_classification_id: str
) -> dict[str, Any]:
    """Transform a ClassificationGroup payload to snake_case.

    Sets is_parent_group=True when the group's classificationTypeId differs
    from the queried classification — flags inherited groups so callers can
    avoid mutating data owned by another classification. Comparison is
    case-insensitive to defend against UUID casing drift.
    """
    own_type_id = group.get("classificationTypeId")
    return {
        "id": group.get("id"),
        "name": group.get("name"),
        "sort_order": group.get("sortOrder"),
        "visible": group.get("visible"),
        "classification_type_id": own_type_id,
        "is_parent_group": (
            own_type_id is not None
            and str(own_type_id).lower() != str(queried_classification_id).lower()
        ),
        "created_by": group.get("createdBy"),
        "created_when": group.get("createdWhen"),
        "last_changed_by": group.get("lastChangedBy"),
        "last_changed_when": group.get("lastChangedWhen"),
    }


def _transform_classification_summary(classification: dict[str, Any]) -> dict[str, Any]:
    """Transform classification to summary format with snake_case keys."""
    return {
        "id": classification.get("id"),
        "name": classification.get("name"),
        "type": classification.get("type") or classification.get("classificationType"),
        "entry_count": (
            classification.get("entryCount") or classification.get("size", 0)
        ),
    }


def _transform_classification_detail(
    classification: dict[str, Any],
    meta: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Transform classification to detailed format with entries.

    Args:
        classification: Source of entries — either a Spring Page wrapper
            (`/classification/{id}/pageable`, with entries in `content`) or
            a flat dict with `entries`. Spring Page wrappers do NOT carry
            parent id/name at the top level, hence the `meta` argument.
        meta: Optional parent-classification metadata (typically the
            response from `/classification_type/{id}`). When provided,
            its `id` and `name` win over anything found in `classification`.

    Note on legacy/vestigial fields: `type`, `created_at`, `updated_at`
    are surfaced for backward compatibility but the BPA backend does not
    expose them on either endpoint — they will always be `null` in
    practice. They are kept in the response shape to avoid breaking
    existing consumers that introspect the dict keys.
    """
    # Parent metadata: prefer explicit meta, fall back to fields that
    # might exist on the source dict (kept for legacy callsites and
    # defensive safety).
    src_meta = meta or {}
    parent_id = src_meta.get("id") or classification.get("id")
    parent_name = src_meta.get("name") or classification.get("name")

    # Handle entries - may be in 'content' (pageable) or 'entries' field
    raw_entries = classification.get("content") or classification.get("entries") or []
    entries = []
    for entry in raw_entries:
        transformed: dict[str, Any] = {
            # Issue #128: entry UUID — required by classification_entry_set_groups
            # which keys on this id. Surfaced as None when the source dict has no
            # id (defensive; backend always populates it on persisted entities).
            "id": entry.get("id"),
            "value": entry.get("value") or entry.get("key"),
            "label": entry.get("label") or entry.get("name") or entry.get("value"),
        }
        # Include key if present (custom identifier, distinct from value)
        if entry.get("key"):
            transformed["key"] = entry["key"]
        # Group memberships — backend already populates these on
        # /classification/{id} and /classification/{id}/pageable. Issue #103.
        raw_groups = entry.get("classificationGroups") or []
        transformed["groups"] = [
            {
                "id": g.get("id"),
                "name": g.get("name"),
                "sort_order": g.get("sortOrder"),
                "visible": g.get("visible"),
            }
            for g in raw_groups
        ]
        entries.append(transformed)

    return {
        "id": parent_id,
        "name": parent_name,
        # Vestigial — see docstring. Kept for backward compatibility.
        "type": classification.get("type") or classification.get("classificationType"),
        "entries": entries,
        "entry_count": len(entries),
        "created_at": classification.get("createdAt"),
        "updated_at": classification.get("updatedAt"),
    }


async def classification_list(
    limit: int = 50,
    offset: int = 0,
    name_filter: str | None = None,
    include_system_catalogs: bool = True,
    instance: str | None = None,
) -> dict[str, Any]:
    """List all classifications (catalog data sources).

    Args:
        limit: Maximum to return (default: 50).
        offset: Skip count (default: 0).
        name_filter: Filter by name (contains, case-insensitive).
        include_system_catalogs: Include GDB system catalogs (default: true).
        instance: Instance profile name (from instance_list).

    Returns:
        dict with classifications, total, has_more.
    """
    # Normalize pagination parameters
    if limit <= 0:
        limit = 50
    if offset < 0:
        offset = 0

    try:
        async with BPAClient.for_instance(instance) as client:
            # GET /classification returns Spring Data Page — use pageable iterator
            pageable_result = await client.get_all_pageable(
                "/classification",
                sort="name,asc",
                resource_type="classification",
            )
            classifications_data: list[dict[str, Any]] = pageable_result.get(
                "content", []
            )

            # Merge GDB system catalogs (e.g. country_selection) if requested
            if include_system_catalogs:
                gdb_catalogs = await client.get_list(
                    "/classifications",
                    params={"showGdbCatalogs": True},
                    resource_type="classification",
                )
                # Deduplicate by ID — GDB catalogs have id+name only
                existing_ids = {c.get("id") for c in classifications_data}
                for gdb in gdb_catalogs:
                    if gdb.get("id") not in existing_ids:
                        classifications_data.append(
                            {
                                "id": gdb.get("id"),
                                "name": gdb.get("name"),
                                "type": "gdb",
                            }
                        )
    except BPAClientError as e:
        raise translate_error(e, resource_type="classification") from e

    # Transform to consistent output format with snake_case keys
    all_classifications = [
        _transform_classification_summary(c) for c in classifications_data
    ]

    # Apply name filter if provided
    if name_filter:
        name_filter_lower = name_filter.lower()
        all_classifications = [
            c
            for c in all_classifications
            if name_filter_lower in (c.get("name") or "").lower()
        ]

    # Sort by name for consistent pagination ordering
    all_classifications.sort(key=lambda c: c.get("name") or "")

    # Calculate total before pagination
    total = len(all_classifications)

    # Apply pagination
    paginated = all_classifications[offset : offset + limit]

    # Calculate has_more
    has_more = (offset + limit) < total

    return {
        "classifications": paginated,
        "total": total,
        "has_more": has_more,
    }


@large_response_handler(
    navigation={
        "list_entries": "jq '.entries'",
        "find_by_value": "jq '.entries[] | select(.value == \"CODE\")'",
        "find_by_label": "jq '.entries[] | select(.label | contains(\"search\"))'",
        "entry_count": "jq '.entry_count'",
    }
)
async def classification_get(
    classification_id: str | int, instance: str | None = None
) -> dict[str, Any]:
    """Get classification details by ID including entries.

    Large responses (>100KB) are saved to file with navigation hints.

    Args:
        classification_id: The classification ID.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with id, name, type, entries, entry_count, created_at, updated_at.
        type/created_at/updated_at are vestigial and always null — the BPA
        backend does not expose them on any classification endpoint.
    """
    try:
        async with BPAClient.for_instance(instance) as client:
            # Pre-fetch parent metadata. /classification/{id}/pageable returns
            # a Spring Page<ClassificationField> wrapper that has NO top-level
            # id/name — without this round trip, those fields surface as null.
            meta = await _assert_classification_exists(client, classification_id)
            try:
                # Use pageable endpoint with full iteration to get ALL entries
                classification_data = await client.get_all_pageable(
                    "/classification/{id}/pageable",
                    path_params={"id": classification_id},
                    resource_type="classification",
                    resource_id=classification_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Classification '{classification_id}' not found. "
                    "Use 'classification_list' to see available classifications."
                ) from None
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="classification", resource_id=classification_id
        ) from e

    return _transform_classification_detail(classification_data, meta=meta)


async def classification_search(
    name: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Search classifications by name substring. Server-side search.

    Args:
        name: Search term (matches catalog names, case-insensitive).
        instance: Instance profile name (from instance_list).

    Returns:
        dict with classifications, total.
    """
    if not name or not name.strip():
        raise ToolError(
            "Cannot search classifications: 'name' is required. "
            "Provide a search term to find matching catalogs."
        )

    try:
        async with BPAClient.for_instance(instance) as client:
            results = await client.get_list(
                "/search_classification/{name}",
                path_params={"name": name.strip()},
                resource_type="classification",
            )
    except BPAClientError as e:
        raise translate_error(e, resource_type="classification") from e

    classifications = [_transform_classification_summary(c) for c in results]
    classifications.sort(key=lambda c: c.get("name") or "")

    return {
        "classifications": classifications,
        "total": len(classifications),
    }


async def classification_groups_list(
    classification_id: str | int,
    instance: str | None = None,
) -> dict[str, Any]:
    """List groups defined for a classification.

    Includes parent-catalog groups when useGroupsForSubCatalogs is enabled
    on the queried type (see classification_get's response). Groups owned
    by a different classification are flagged with is_parent_group=true.

    A pre-flight GET /classification_type/{id} is used to validate the
    classification exists, because the backend's /type_classification_group
    endpoint does NOT 404 on unknown IDs — it silently returns groups from
    other classifications whose fields have null childClassificationType.

    Args:
        classification_id: The classification (catalog) ID.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with classification_id, groups (list with id, name, sort_order,
        visible, classification_type_id, is_parent_group, created_by/when,
        last_changed_by/when), total.
    """
    try:
        async with BPAClient.for_instance(instance) as client:
            await _assert_classification_exists(client, classification_id)
            # /type_classification_group/{id} is a plain list (NOT a Spring
            # Page<T>) — use get_list, not get_all_pageable.
            raw = await client.get_list(
                "/type_classification_group/{id}",
                path_params={"id": classification_id},
                resource_type="classification_group",
            )
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="classification_group", resource_id=classification_id
        ) from e

    groups = [_transform_classification_group(g, str(classification_id)) for g in raw]
    return {
        "classification_id": str(classification_id),
        "groups": groups,
        "total": len(groups),
    }


async def classification_group_create(
    classification_id: str | int,
    name: str,
    sort_order: int | None = None,
    visible: bool = True,
    instance: str | None = None,
) -> dict[str, Any]:
    """Create a group on a classification. Audited write operation.

    Args:
        classification_id: The classification (catalog) ID this group belongs to.
        name: Group display name (1-255 chars). Unique per classification.
        sort_order: Sort order (optional; backend assigns if omitted).
        visible: Whether the group renders in the UI (default: true).
        instance: Instance profile name (from instance_list).

    Returns:
        dict with group (id, name, sort_order, visible, classification_type_id,
        is_parent_group, ...), audit_id.
    """
    # Pre-flight validation (no audit record on validation failure)
    if not classification_id:
        raise ToolError(
            "Cannot create classification group: 'classification_id' is required."
        )
    trimmed_name = _validate_group_name(name)

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    payload: dict[str, Any] = {"name": trimmed_name, "visible": visible}
    if sort_order is not None:
        payload["sortOrder"] = sort_order

    try:
        async with BPAClient.for_instance(instance) as client:
            await _assert_classification_exists(client, classification_id)

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="create",
                object_type="classification_group",
                params={
                    "classification_id": str(classification_id),
                    **payload,
                },
            )

            try:
                created = await client.post(
                    "/classification_group/{type_id}",
                    path_params={"type_id": str(classification_id)},
                    json=payload,
                    resource_type="classification_group",
                )

                created_id = created.get("id")
                # _operation: "create" tells the rollback dispatcher to DELETE
                await audit_logger.save_rollback_state(
                    audit_id=audit_id,
                    object_type="classification_group",
                    object_id=str(created_id),
                    previous_state={
                        "id": created_id,
                        "name": created.get("name"),
                        "classification_type_id": str(classification_id),
                        "_operation": "create",
                    },
                )

                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "group_id": created_id,
                        "name": created.get("name"),
                    },
                )

                return {
                    "group": _transform_classification_group(
                        created, str(classification_id)
                    ),
                    "audit_id": audit_id,
                }

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                if _is_group_already_exists_error(e):
                    raise ToolError(
                        f"Group '{trimmed_name}' already exists in this "
                        "classification (groups must be unique by name within "
                        "a classification). Use a different name, or call "
                        "classification_groups_list to inspect existing groups."
                    ) from e
                raise translate_error(
                    e,
                    resource_type="classification_group",
                    resource_id=classification_id,
                ) from e

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e,
            resource_type="classification_group",
            resource_id=classification_id,
        ) from e


async def classification_group_update(
    group_id: str,
    name: str | None = None,
    sort_order: int | None = None,
    visible: bool | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Update a classification group's metadata. Audited write operation.

    Pre-fetches the current group; merges in the supplied changes; PUTs the
    full {id, name, sortOrder, visible} body. Omitted MCP params keep their
    current values. Audit metadata fields (createdBy, etc.) are NOT echoed
    back to avoid Jackson @Valid issues.

    Args:
        group_id: The classification group ID.
        name: New display name (1-255 chars). Omit to keep current.
        sort_order: New sort order. Omit to keep current.
        visible: New visibility flag. Omit to keep current.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with group (id, name, sort_order, visible, ...), audit_id.
    """
    if not group_id:
        raise ToolError("Cannot update classification group: 'group_id' is required.")
    if name is None and sort_order is None and visible is None:
        raise ToolError(
            "Cannot update classification group: At least one of name, "
            "sort_order, or visible must be provided."
        )
    trimmed_name = _validate_group_name(name) if name is not None else None

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                current = await client.get(
                    "/classification_group/{id}",
                    path_params={"id": group_id},
                    resource_type="classification_group",
                    resource_id=group_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Classification group '{group_id}' not found."
                ) from None

            # Pre-fetch + merge: only the 4 fields the backend update reads.
            merged = {
                "id": current.get("id") or group_id,
                "name": (
                    trimmed_name if trimmed_name is not None else current.get("name")
                ),
                "sortOrder": (
                    sort_order if sort_order is not None else current.get("sortOrder")
                ),
                "visible": (visible if visible is not None else current.get("visible")),
            }

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="update",
                object_type="classification_group",
                object_id=str(group_id),
                params=merged,
            )

            try:
                updated = await client.put(
                    "/classification_group",
                    json=merged,
                    resource_type="classification_group",
                    resource_id=group_id,
                )

                # PUT succeeded — save rollback + mark success now.
                # Re-fetch failures below MUST NOT flip this to mark_failed.
                await audit_logger.save_rollback_state(
                    audit_id=audit_id,
                    object_type="classification_group",
                    object_id=str(group_id),
                    previous_state={
                        "id": current.get("id") or group_id,
                        "name": current.get("name"),
                        "sortOrder": current.get("sortOrder"),
                        "visible": current.get("visible"),
                        "_operation": "update",
                    },
                )
                await audit_logger.mark_success(
                    audit_id,
                    result={"group_id": str(group_id), "name": merged["name"]},
                )

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(
                    e,
                    resource_type="classification_group",
                    resource_id=group_id,
                ) from e

            # Build the returned `group` shape from the merged payload (what
            # we sent and the backend accepted). Live PUT returns void; an
            # additional GET is wasteful and its failure must not corrupt the
            # already-committed audit row above.
            effective: dict[str, Any]
            if isinstance(updated, dict) and updated:
                effective = updated
            else:
                effective = {
                    "id": merged["id"],
                    "name": merged["name"],
                    "sortOrder": merged["sortOrder"],
                    "visible": merged["visible"],
                    "classificationTypeId": current.get("classificationTypeId"),
                }

            queried_type = effective.get("classificationTypeId") or current.get(
                "classificationTypeId"
            )
            return {
                "group": _transform_classification_group(
                    effective, str(queried_type) if queried_type else ""
                ),
                "audit_id": audit_id,
            }

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="classification_group", resource_id=group_id
        ) from e


async def classification_group_delete(
    group_id: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete a classification group. Audited destructive write.

    The backend automatically wipes ClassificationFieldGroup join rows when a
    group is deleted, so existing entries don't disappear — they just lose
    membership in this group. The pre-delete capture records every field_id
    that had this group so a rollback can restore the join rows by
    re-running entry_set_groups per affected field.

    Backend rejects deletion when grouping determinants reference the group
    (CannotDeleteIntegratedClassificationGroup). The error is translated to
    an actionable ToolError listing the offending determinants.

    Args:
        group_id: The classification group ID.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with deleted (bool), group_id, deleted_group, affected_field_count,
        audit_id.
    """
    if not group_id:
        raise ToolError("Cannot delete classification group: 'group_id' is required.")

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            # Pre-fetch the group itself
            try:
                current = await client.get(
                    "/classification_group/{id}",
                    path_params={"id": group_id},
                    resource_type="classification_group",
                    resource_id=group_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Classification group '{group_id}' not found."
                ) from None

            # Pre-fetch the fields that reference this group, for rollback
            fields = await client.get_list(
                "/classification_field_by_groups/{id}",
                path_params={"id": group_id},
                resource_type="classification_field",
            )
            field_ids = [f.get("id") for f in fields if f.get("id")]

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="delete",
                object_type="classification_group",
                object_id=str(group_id),
                params={"group_id": str(group_id)},
            )

            classification_type_id = current.get("classificationTypeId")
            rollback_state = {
                "group": {
                    "id": current.get("id") or group_id,
                    "name": current.get("name"),
                    "sort_order": current.get("sortOrder"),
                    "visible": current.get("visible"),
                    "classification_type_id": classification_type_id,
                },
                "field_ids": field_ids,
                "_operation": "delete",
            }

            try:
                # Save rollback state first (inside try so a serialization
                # error marks the audit failed cleanly instead of leaking PENDING).
                await audit_logger.save_rollback_state(
                    audit_id=audit_id,
                    object_type="classification_group",
                    object_id=str(group_id),
                    previous_state=rollback_state,
                )

                await client.delete(
                    "/classification_group/{id}",
                    path_params={"id": group_id},
                    resource_type="classification_group",
                    resource_id=group_id,
                )
            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                msg_lower = str(e).lower()
                if "determinant" in msg_lower or "integrated" in msg_lower:
                    raise ToolError(
                        f"Cannot delete group '{current.get('name')}': it is "
                        f"referenced by grouping determinants. Backend message: "
                        f"{e}. Use 'determinant_list' to find and detach the "
                        f"offending determinants, then retry."
                    ) from e
                raise translate_error(
                    e,
                    resource_type="classification_group",
                    resource_id=group_id,
                ) from e
            except Exception as e:
                # Audit DB lock / serialization error must not leak as PENDING
                await audit_logger.mark_failed(audit_id, f"audit-write: {e}")
                raise

            await audit_logger.mark_success(
                audit_id,
                result={
                    "deleted": True,
                    "group_id": str(group_id),
                    "affected_field_count": len(field_ids),
                },
            )

            return {
                "deleted": True,
                "group_id": str(group_id),
                "deleted_group": {
                    "id": current.get("id") or group_id,
                    "name": current.get("name"),
                    "classification_type_id": classification_type_id,
                },
                "affected_field_count": len(field_ids),
                "affected_field_ids": field_ids,
                "audit_id": audit_id,
            }

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="classification_group", resource_id=group_id
        ) from e


async def classification_entry_set_groups(
    classification_id: str | int,
    entry_id: str | None = None,
    group_ids: list[str] | None = None,
    entry_key: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Set the group memberships of a classification entry. REPLACE semantics.

    Audited write operation.

    The supplied group_ids list IS the new full membership: any current group
    not in the list is removed; any in the list that wasn't previously
    assigned is added. Calling with the same list twice is idempotent.

    Address the entry by one of:
        - entry_id: the entry's UUID (from classification_get response)
        - entry_key: the entry's key (e.g. "1010" for ISIC); resolved to UUID
          internally. Backend does NOT enforce key uniqueness — if multiple
          entries share the key, ambiguity is raised with the matched UUIDs.

    Args:
        classification_id: The classification (catalog) ID.
        entry_id: Entry UUID (mutually exclusive with entry_key).
        group_ids: Full new group membership (deduped server-side). [] to
            clear all groups; None is rejected.
        entry_key: Entry key — alternative to entry_id (issue #128).
        instance: Instance profile name (from instance_list).

    Returns:
        dict with entry_id (resolved UUID), classification_id, groups,
        warnings, audit_id. When called via entry_key, the input key is
        echoed as entry_key in the response.
    """
    # Pre-flight validation — no audit record on failure
    if not classification_id:
        raise ToolError("Cannot set entry groups: 'classification_id' is required.")
    # Treat empty string identically to None for both addressing forms.
    has_entry_id = bool(entry_id)
    has_entry_key = bool(entry_key)
    if has_entry_id and has_entry_key:
        raise ToolError(
            "Cannot set entry groups: provide exactly one of 'entry_id' or "
            "'entry_key', not both."
        )
    if not has_entry_id and not has_entry_key:
        raise ToolError(
            "Cannot set entry groups: 'entry_id' or 'entry_key' is required."
        )
    if group_ids is None:
        raise ToolError(
            "Cannot set entry groups: 'group_ids' is required (use [] to clear)."
        )
    # De-dupe while preserving caller order
    seen: set[str] = set()
    deduped_ids: list[str] = []
    for gid in group_ids:
        if gid and gid not in seen:
            seen.add(gid)
            deduped_ids.append(gid)

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            await _assert_classification_exists(client, classification_id)

            # Pre-fetch the classification's entries; locate target by id.
            pageable = await client.get_all_pageable(
                "/classification/{id}/pageable",
                path_params={"id": classification_id},
                resource_type="classification",
                resource_id=classification_id,
            )
            entries = pageable.get("content") or []
            # Resolve to entry UUID via either path. Backend uniqueness is
            # on (classification_type_id, business_key) and (classification_type_id,
            # id) — NOT on key — so duplicate keys are theoretically possible.
            # See ClassificationField.java:40-43 in BPA-backend.
            if has_entry_id:
                target = next(
                    (e for e in entries if str(e.get("id")) == str(entry_id)), None
                )
                if target is None:
                    sample_ids = [str(e.get("id")) for e in entries[:5] if e.get("id")]
                    raise ToolError(
                        f"Entry '{entry_id}' not found in classification "
                        f"'{classification_id}'. First entry IDs available: "
                        f"{sample_ids}."
                    )
                resolved_entry_id = str(entry_id)
            else:
                # entry_key path
                matches = [e for e in entries if e.get("key") == entry_key]
                if not matches:
                    sample_keys = [
                        str(e.get("key")) for e in entries[:5] if e.get("key")
                    ]
                    raise ToolError(
                        f"Entry with key '{entry_key}' not found in classification "
                        f"'{classification_id}'. First entry keys available: "
                        f"{sample_keys}."
                    )
                if len(matches) > 1:
                    matched_ids = [str(e.get("id")) for e in matches if e.get("id")]
                    raise ToolError(
                        f"Entry key '{entry_key}' is ambiguous — multiple "
                        f"entries match: {matched_ids}. Use 'entry_id' to "
                        "disambiguate."
                    )
                target = matches[0]
                resolved_entry_id = str(target.get("id"))

            # Validate every requested group_id resolves; build warning list
            # for parent-catalog groups (assigned via useGroupsForSubCatalogs).
            available = await client.get_list(
                "/type_classification_group/{id}",
                path_params={"id": classification_id},
                resource_type="classification_group",
            )
            group_by_id = {g.get("id"): g for g in available if g.get("id")}
            unknown = [gid for gid in deduped_ids if gid not in group_by_id]
            if unknown:
                known_summary = ", ".join(
                    f"{g.get('id')} ({g.get('name')})" for g in available if g.get("id")
                )
                raise ToolError(
                    f"Unknown group_id(s) for classification "
                    f"'{classification_id}': {unknown}. "
                    f"Valid groups (id, name): {known_summary or '<none>'}. "
                    "Use 'classification_groups_list' to refresh."
                )
            warnings = []
            for gid in deduped_ids:
                g = group_by_id[gid]
                own_type = g.get("classificationTypeId")
                if (
                    own_type is not None
                    and str(own_type).lower() != str(classification_id).lower()
                ):
                    warnings.append(
                        f"Group '{gid}' ({g.get('name')}) is inherited from "
                        f"parent classification '{own_type}'. The assignment "
                        "will succeed but mutating the group itself requires "
                        "operating on the parent classification."
                    )

            # Build POST body — deep-copy entry, strip stale audit fields,
            # overwrite classificationGroups. previous_entry is captured
            # for the rollback dispatcher to re-POST verbatim on undo.
            previous_entry = copy.deepcopy(target)
            for f in _AUDIT_FIELDS_TO_STRIP:
                previous_entry.pop(f, None)

            payload = copy.deepcopy(previous_entry)
            payload["classificationGroups"] = [
                {
                    "id": gid,
                    "name": group_by_id[gid].get("name"),
                    "sortOrder": group_by_id[gid].get("sortOrder"),
                }
                for gid in deduped_ids
            ]

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            # Audit params: object_id is always the resolved UUID. When the
            # caller addressed via entry_key, both forms are recorded for
            # forensic searchability (issue #128).
            audit_params: dict[str, Any] = {
                "classification_id": str(classification_id),
                "entry_id": resolved_entry_id,
                "group_ids": deduped_ids,
            }
            if has_entry_key:
                audit_params["entry_key"] = entry_key
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="update",
                object_type="classification_field",
                object_id=resolved_entry_id,
                params=audit_params,
            )

            # POST the write. If it fails, mark_failed and propagate.
            try:
                await client.post(
                    "/classification/{type_id}/field",
                    path_params={"type_id": str(classification_id)},
                    json=payload,
                    resource_type="classification_field",
                )
            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(
                    e,
                    resource_type="classification_field",
                    resource_id=resolved_entry_id,
                ) from e

            # POST succeeded — save rollback + mark success FIRST so a
            # verification failure below doesn't corrupt the audit row.
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="classification_field",
                object_id=resolved_entry_id,
                previous_state={
                    "entry_id": resolved_entry_id,
                    "classification_id": str(classification_id),
                    "previous_group_ids": [
                        g.get("id")
                        for g in (target.get("classificationGroups") or [])
                        if g.get("id")
                    ],
                    # Full pre-state entry — rollback POSTs this verbatim
                    # to restore the entry exactly. previous_group_ids is
                    # kept for callers that just want the IDs.
                    "previous_entry": previous_entry,
                    "_operation": "update",
                },
            )
            await audit_logger.mark_success(
                audit_id,
                result={
                    "entry_id": resolved_entry_id,
                    "group_count": len(deduped_ids),
                },
            )

            # Post-write verification — wrapped so a network blip on the
            # GET doesn't cause a re-mark_failed on an already-committed
            # write. Verification failure → ToolError but audit stays
            # SUCCESS with a 'verification_unverified' marker.
            verified_groups: list[dict[str, Any]] = []
            try:
                verify = await client.get_list(
                    "/field_classification_group/{id}",
                    path_params={"id": resolved_entry_id},
                    resource_type="classification_group",
                )
                actual_ids = sorted(
                    str(g.get("id") or "").lower() for g in verify if g.get("id")
                )
                expected_ids = sorted(str(g).lower() for g in deduped_ids)
                if actual_ids != expected_ids or len(actual_ids) != len(expected_ids):
                    raise ToolError(
                        f"Post-write verification failed for entry "
                        f"'{resolved_entry_id}': expected groups={expected_ids}, "
                        f"actual={actual_ids}. Audit_id={audit_id}. "
                        "Concurrent edit possible — re-fetch and retry."
                    )
                verified_groups = verify
            except ToolError:
                raise
            except BPAClientError as e:
                # Verification GET failed (network blip etc.). The write
                # itself was already marked success — surface as a
                # warning but don't pretend the write failed.
                warnings.append(
                    f"Post-write verification GET failed: {e}. "
                    "The write succeeded; call classification_get to confirm."
                )

            response: dict[str, Any] = {
                "entry_id": resolved_entry_id,
                "classification_id": str(classification_id),
                "groups": [
                    {
                        "id": g.get("id"),
                        "name": g.get("name"),
                        "sort_order": g.get("sortOrder"),
                    }
                    for g in verified_groups
                ],
                "warnings": warnings,
                "audit_id": audit_id,
            }
            # Echo the input key when caller addressed via entry_key, so
            # bulk loops can correlate the response with their CSV row.
            if has_entry_key:
                response["entry_key"] = entry_key
            return response

    except ToolError:
        raise
    except BPAClientError as e:
        # resolved_entry_id may not exist if the error fired before resolution
        # (e.g. classification doesn't exist). Fall back to the input form.
        err_resource_id = (
            locals().get("resolved_entry_id") or entry_id or entry_key or ""
        )
        raise translate_error(
            e, resource_type="classification_field", resource_id=err_resource_id
        ) from e


def _validate_classification_create_params(
    name: str,
    entries: list[dict[str, str]] | None,
    classification_on_form: bool | None,
    is_rejection_catalog: bool,
) -> dict[str, Any]:
    """Validate classification_create parameters (pre-flight).

    Args:
        name: The classification name.
        entries: Optional list of entries with 'value' (and optional 'key').
        classification_on_form: Whether the catalog appears on forms.
        is_rejection_catalog: Whether this is a rejection catalog.

    Returns:
        dict: Validated type payload + validated entries list.

    Raises:
        ToolError: If validation fails.
    """
    errors = []

    if not name or not name.strip():
        errors.append("'name' is required and cannot be empty")

    if name and len(name.strip()) > 255:
        errors.append("'name' must be 255 characters or less")

    # Validate entry structure if provided
    validated_entries: list[dict[str, Any]] = []
    for i, entry in enumerate(entries or []):
        if not isinstance(entry, dict):
            errors.append(f"Entry {i} must be a dict with at least a 'value' key")
            continue
        if not entry.get("value"):
            errors.append(f"Entry {i} missing required 'value' field")
        else:
            field: dict[str, Any] = {"value": entry["value"]}
            if entry.get("key"):
                field["key"] = entry["key"]
            validated_entries.append(field)

    if errors:
        error_msg = "; ".join(errors)
        raise ToolError(
            f"Cannot create classification: {error_msg}. Check required fields."
        )

    # Build ClassificationType payload matching frontend defaults
    type_payload: dict[str, Any] = {
        "name": name.strip(),
        "useCustomOrder": True,
        "showGroups": False,
        "isRejectionCatalog": is_rejection_catalog,
        "serviceIds": [],
    }
    if classification_on_form is not None:
        type_payload["classificationOnForm"] = classification_on_form

    return {"type_payload": type_payload, "entries": validated_entries}


async def classification_create(
    name: str,
    entries: list[dict[str, str]] | None = None,
    classification_on_form: bool | None = None,
    is_rejection_catalog: bool = False,
    instance: str | None = None,
) -> dict[str, Any]:
    """Create a classification catalog. Audited write operation.

    Creates the catalog type, then adds entries one-by-one if provided.

    Args:
        name: The classification name.
        entries: Optional entries, each with 'value' (and optional 'key').
        classification_on_form: Whether usable in forms (default: None).
        is_rejection_catalog: Rejection catalog flag (default: false).
        instance: Instance profile name (from instance_list).

    Returns:
        dict with id, name, type, entries, entry_count, audit_id.
    """
    # Pre-flight validation (no audit record for validation failures)
    validated = _validate_classification_create_params(
        name, entries, classification_on_form, is_rejection_catalog
    )
    type_payload = validated["type_payload"]
    validated_entries: list[dict[str, Any]] = validated["entries"]

    # Get authenticated user for audit
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            # Create audit record BEFORE API call
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="create",
                object_type="classification",
                params=type_payload,
            )

            try:
                # Step 1: Create the classification type
                classification_data = await client.post(
                    "/classification",
                    json=type_payload,
                    resource_type="classification",
                )

                created_id = classification_data.get("id")

                # Step 2: Add entries one-by-one if provided
                added_entries = []
                for i, entry in enumerate(validated_entries):
                    field_payload: dict[str, Any] = {
                        "value": entry["value"],
                        "customOrder": i,
                        "translations": [],
                        "classificationGroups": [],
                        "classificationFieldExternalIdList": [],
                        "sayRejectionReason": False,
                    }
                    if entry.get("key"):
                        field_payload["key"] = entry["key"]
                    field_data = await client.post(
                        "/classification/{type_id}/field",
                        path_params={"type_id": str(created_id)},
                        json=field_payload,
                        resource_type="classification_field",
                    )
                    added_entries.append(field_data)

                # Save rollback state (for create, save ID to enable deletion)
                await audit_logger.save_rollback_state(
                    audit_id=audit_id,
                    object_type="classification",
                    object_id=str(created_id),
                    previous_state={
                        "id": created_id,
                        "name": classification_data.get("name"),
                        "_operation": "create",  # Marker for rollback to DELETE
                    },
                )

                # Mark audit as success
                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "classification_id": created_id,
                        "name": classification_data.get("name"),
                        "entries_added": len(added_entries),
                    },
                )

                # Re-fetch entries via the pageable endpoint (the singular
                # /classification/{id} returns List<ClassificationField>, not
                # a wrapper, so we cannot reuse _transform_classification_detail
                # on it). The POST response is itself the parent metadata.
                if added_entries:
                    entries_data = await client.get_all_pageable(
                        "/classification/{id}/pageable",
                        path_params={"id": str(created_id)},
                        resource_type="classification",
                        resource_id=str(created_id),
                    )
                else:
                    entries_data = {"content": []}

                result = _transform_classification_detail(
                    entries_data, meta=classification_data
                )
                result["audit_id"] = audit_id
                return result

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type="classification") from e

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="classification") from e


def _validate_classification_update_params(
    classification_id: str | int,
    name: str | None,
    entries: list[dict[str, str]] | None,
    use_custom_key: bool | None = None,
    use_custom_order: bool | None = None,
    classification_on_form: bool | None = None,
    use_groups_for_sub_catalogs: bool | None = None,
) -> dict[str, Any]:
    """Validate classification_update parameters (pre-flight).

    Args:
        classification_id: The classification ID to update.
        name: New name (optional).
        entries: New entries list (optional).
        use_custom_key: Enable custom keys (optional).
        use_custom_order: Enable custom ordering (optional).
        classification_on_form: Show classification on form (optional).
        use_groups_for_sub_catalogs: Enable groups for sub-catalogs (optional).

    Returns:
        dict: Validated parameters ready for API call.

    Raises:
        ToolError: If validation fails.
    """
    errors = []

    if not classification_id:
        errors.append("'classification_id' is required")

    if name is not None and not name.strip():
        errors.append("'name' cannot be empty when provided")

    if name and len(name.strip()) > 255:
        errors.append("'name' must be 255 characters or less")

    # Validate entry structure if provided
    if entries is not None:
        if not entries:
            errors.append("'entries' cannot be empty when provided")
        for i, entry in enumerate(entries):
            if not isinstance(entry, dict):
                errors.append(f"Entry {i} must be a dict with 'value' and 'label'")
                continue
            if not entry.get("value"):
                errors.append(f"Entry {i} missing required 'value' field")
            if not entry.get("label"):
                errors.append(f"Entry {i} missing required 'label' field")

    # At least one field must be provided
    has_metadata = any(
        v is not None
        for v in [
            use_custom_key,
            use_custom_order,
            classification_on_form,
            use_groups_for_sub_catalogs,
        ]
    )
    if name is None and entries is None and not has_metadata:
        errors.append("At least one field must be provided")

    if errors:
        error_msg = "; ".join(errors)
        raise ToolError(
            f"Cannot update classification: {error_msg}. Check required fields."
        )

    # Build API payload with only provided fields
    params: dict[str, Any] = {}
    if name is not None:
        params["name"] = name.strip()
    if entries is not None:
        params["entries"] = [
            {"value": e["value"], "label": e["label"]} for e in entries
        ]

    # Map snake_case metadata params to camelCase API keys
    if use_custom_key is not None:
        params["useCustomKey"] = use_custom_key
    if use_custom_order is not None:
        params["useCustomOrder"] = use_custom_order
    if classification_on_form is not None:
        params["classificationOnForm"] = classification_on_form
    if use_groups_for_sub_catalogs is not None:
        params["useGroupsForSubCatalogs"] = use_groups_for_sub_catalogs

    return params


async def classification_update(
    classification_id: str | int,
    name: str | None = None,
    entries: list[dict[str, str]] | None = None,
    use_custom_key: bool | None = None,
    use_custom_order: bool | None = None,
    classification_on_form: bool | None = None,
    use_groups_for_sub_catalogs: bool | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Update a classification catalog. Audited write operation.

    Args:
        classification_id: The classification ID to update.
        name: New display name -- NOT the classification_id (e.g.
            "all countries", not "country_selection"). Omit to keep current.
        entries: New entries list (optional).
        use_custom_key: Enable custom keys for entries (optional).
        use_custom_order: Enable custom ordering of entries (optional).
        classification_on_form: Show classification on form (optional).
        use_groups_for_sub_catalogs: Enable groups for sub-catalogs (optional).
        instance: Instance profile name (from instance_list).

    Returns:
        dict with id, name, type, entries, entry_count, audit_id.
    """
    # Pre-flight validation
    validated_params = _validate_classification_update_params(
        classification_id,
        name,
        entries,
        use_custom_key=use_custom_key,
        use_custom_order=use_custom_order,
        classification_on_form=classification_on_form,
        use_groups_for_sub_catalogs=use_groups_for_sub_catalogs,
    )

    # Get authenticated user for audit
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            # Fetch parent metadata (for previous_name, rollback) and entries
            # separately. /classification/{id}/pageable returns a Spring Page
            # wrapper with NO top-level id/name, so we need /classification_type
            # for the name. Both calls also serve as a 404 pre-flight.
            current_meta = await _assert_classification_exists(
                client, classification_id
            )
            try:
                current_entries = await client.get(
                    "/classification/{id}/pageable",
                    path_params={"id": classification_id},
                    resource_type="classification",
                    resource_id=classification_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Classification '{classification_id}' not found. "
                    "Use 'classification_list' to see available classifications."
                ) from None

            # Create audit record BEFORE API call
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="update",
                object_type="classification",
                object_id=str(classification_id),
                params=validated_params,
            )

            try:
                # PUT /classification (no {id} in path, id in JSON body)
                # Include name from current metadata if not being updated
                # (backend @Valid requires non-empty name)
                previous_name = current_meta.get("name") or ""
                update_payload = {"id": classification_id, **validated_params}
                if "name" not in update_payload:
                    if not previous_name:
                        raise ToolError(
                            f"Classification '{classification_id}' has no name "
                            "in API response. Cannot update without a name "
                            "(backend @Valid requires it). Check the catalog "
                            "in the BPA UI."
                        )
                    update_payload["name"] = previous_name

                # PUT /classification returns void — we cannot read fresh
                # metadata from its response. Use the in-flight payload as
                # the post-update meta (its `name` is what the backend just
                # persisted, modulo backend-side rewrites we cannot observe
                # without an extra GET).
                await client.put(
                    "/classification",
                    json=update_payload,
                    resource_type="classification",
                    resource_id=classification_id,
                )
                post_meta = {**current_meta, **update_payload}

                # Save rollback state (previous state for restore)
                await audit_logger.save_rollback_state(
                    audit_id=audit_id,
                    object_type="classification",
                    object_id=str(classification_id),
                    previous_state={
                        "id": current_meta.get("id"),
                        "name": previous_name,
                        "type": current_meta.get("type"),
                        "entries": current_entries.get("content")
                        or current_entries.get("entries"),
                        "_operation": "update",
                    },
                )

                # Mark audit as success
                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "classification_id": classification_id,
                        "name": post_meta.get("name"),
                    },
                )

                result = _transform_classification_detail(
                    current_entries, meta=post_meta
                )
                result["audit_id"] = audit_id

                # Warn if the name was changed (the new value is what we sent)
                actual_name = post_meta.get("name", "")
                if actual_name != previous_name:
                    result["name_change_warning"] = (
                        f"Catalog name changed from "
                        f'"{previous_name}" to "{actual_name}". '
                        f"If unintentional, use classification_update with "
                        f'name="{previous_name}" to restore, or rollback '
                        f"with audit_id={audit_id!r}."
                    )

                return result

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(
                    e, resource_type="classification", resource_id=classification_id
                ) from e

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="classification", resource_id=classification_id
        ) from e


def _validate_classification_delete_params(
    classification_id: str | int,
) -> None:
    """Validate classification_delete parameters (pre-flight).

    Raises ToolError if validation fails.

    Args:
        classification_id: Classification ID to delete (required).

    Raises:
        ToolError: If validation fails.
    """
    if not classification_id:
        raise ToolError(
            "Cannot delete classification: 'classification_id' is required. "
            "Use 'classification_list' to find valid classification IDs."
        )


async def classification_delete(
    classification_id: str | int,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete a BPA classification. Audited write operation.

    Saves state before deletion; use rollback with audit_id to restore.

    Args:
        classification_id: Classification ID to delete.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with deleted (bool), classification_id,
        deleted_classification, audit_id.
    """
    # Pre-flight validation (no audit record for validation failures)
    _validate_classification_delete_params(classification_id)

    # Get authenticated user for audit
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    # Capture current state for rollback BEFORE making changes.
    # /classification/{id}/pageable returns a Spring Page wrapper with NO
    # top-level id/name — we need /classification_type/{id} for parent meta.
    try:
        async with BPAClient.for_instance(instance) as client:
            previous_meta = await _assert_classification_exists(
                client, classification_id
            )
            try:
                previous_entries = await client.get(
                    "/classification/{id}/pageable",
                    path_params={"id": classification_id},
                    resource_type="classification",
                    resource_id=classification_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Classification '{classification_id}' not found. "
                    "Use 'classification_list' to see available classifications."
                ) from None
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="classification", resource_id=classification_id
        ) from e

    # Build rollback state (full classification data for restore)
    rollback_previous_state = {
        "id": previous_meta.get("id"),
        "name": previous_meta.get("name"),
        "type": previous_meta.get("type") or previous_meta.get("classificationType"),
        "entries": previous_entries.get("content") or previous_entries.get("entries"),
    }

    # Normalize previous_state to snake_case for response
    normalized_previous_state = {
        "id": previous_meta.get("id"),
        "name": previous_meta.get("name"),
        "type": rollback_previous_state["type"],
        "entry_count": len(rollback_previous_state.get("entries") or []),
    }

    # Create audit record BEFORE API call (audit-before-write pattern)
    audit_logger = AuditLogger(db_path=resolve_db_path(instance))
    audit_id = await audit_logger.record_pending(
        user_email=user_email,
        operation_type="delete",
        object_type="classification",
        object_id=str(classification_id),
        params={"classification_id": str(classification_id)},
    )

    # Save rollback state for undo capability (recreate on rollback)
    await audit_logger.save_rollback_state(
        audit_id=audit_id,
        object_type="classification",
        object_id=str(classification_id),
        previous_state=rollback_previous_state,
    )

    try:
        async with BPAClient.for_instance(instance) as client:
            await client.delete(
                "/classification/{id}",
                path_params={"id": classification_id},
                resource_type="classification",
                resource_id=classification_id,
            )

        # Mark audit as success
        await audit_logger.mark_success(
            audit_id,
            result={
                "deleted": True,
                "classification_id": str(classification_id),
            },
        )

        return {
            "deleted": True,
            "classification_id": classification_id,
            "deleted_classification": {
                "id": normalized_previous_state["id"],
                "name": normalized_previous_state["name"],
                "type": normalized_previous_state["type"],
            },
            "audit_id": audit_id,
        }

    except BPAClientError as e:
        # Mark audit as failed
        await audit_logger.mark_failed(audit_id, str(e))
        raise translate_error(
            e, resource_type="classification", resource_id=classification_id
        ) from e


async def classification_export_csv(
    classification_id: str | int, instance: str | None = None
) -> dict[str, Any]:
    """Export classification entries as CSV content.

    Args:
        classification_id: The classification ID to export.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with classification_id, name, csv_content, entry_count.
    """
    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                # First get classification details for metadata
                classification_data = await client.get(
                    "/classification/{id}/pageable",
                    path_params={"id": classification_id},
                    resource_type="classification",
                    resource_id=classification_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Classification '{classification_id}' not found. "
                    "Use 'classification_list' to see available classifications."
                ) from None

            # Get CSV export (endpoint returns text/csv, not JSON)
            try:
                csv_content = await client.get_text(
                    "/classification/{id}/exportCsv",
                    path_params={"id": classification_id},
                    resource_type="classification",
                    resource_id=classification_id,
                )
            except BPAClientError as e:
                raise translate_error(
                    e, resource_type="classification", resource_id=classification_id
                ) from e

            # Count entries from original data
            raw_entries = (
                classification_data.get("content")
                or classification_data.get("entries")
                or []
            )

            return {
                "classification_id": classification_id,
                "name": classification_data.get("name"),
                "csv_content": csv_content,
                "entry_count": len(raw_entries),
            }

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="classification", resource_id=classification_id
        ) from e


def _match_entries(
    existing_entries: list[dict[str, Any]],
    requested_entries: list[dict[str, str]],
) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    """Match AI-provided entries to existing classification field objects by label.

    In the BPA ClassificationField model:
    - ``value`` is the display name (e.g. "Afghanistan")
    - ``key`` is the custom identifier (e.g. "AFG")

    Matching is case-insensitive and strips whitespace. Matches against the
    field's ``value`` (display name). On match, sets the ``key`` field.
    Only matched fields are returned (for per-field POST).

    Args:
        existing_entries: Raw ClassificationField objects from BPA pageable endpoint.
        requested_entries: AI-provided entries with key (code) and label (display name).

    Returns:
        Tuple of (matched_fields, unmatched) where matched_fields contains only
        the existing entries that matched with their key updated, and unmatched
        is the list of requested entries that did not match any existing entry.
    """
    # Build lookup from normalized label -> requested key
    label_to_key: dict[str, str] = {}
    for entry in requested_entries:
        normalized = entry["label"].strip().lower()
        label_to_key[normalized] = entry["key"]

    matched_fields: list[dict[str, Any]] = []
    matched_labels: set[str] = set()

    for existing in existing_entries:
        # BPA field 'value' is the display name
        existing_display = (
            existing.get("value") or existing.get("label") or existing.get("name") or ""
        )
        normalized = existing_display.strip().lower()

        if normalized in label_to_key:
            # Match found: set the 'key' field to the ISO code
            updated_field = {**existing, "key": label_to_key[normalized]}
            matched_fields.append(updated_field)
            matched_labels.add(normalized)

    # Determine which requested entries were not matched
    unmatched = [
        entry
        for entry in requested_entries
        if entry["label"].strip().lower() not in matched_labels
    ]

    return matched_fields, unmatched


async def classification_apply_country_codes(
    classification_id: str | int,
    entries: list[dict[str, str]],
    enable_custom_key: bool = True,
    dry_run: bool = False,
    instance: str | None = None,
) -> dict[str, Any]:
    """Apply custom keys to classification entries by label matching. Audited write.

    Use classification_get first to retrieve entries, then provide label-to-code
    mappings. Matches by label (case-insensitive) against the entry's display
    name, then sets the entry's key via POST /classification/{id}/field per
    field. Optionally enables useCustomKey via PUT /classification metadata.

    Args:
        classification_id: Classification ID.
        entries: Mapped entries, each with 'key' (code) and 'label'.
        enable_custom_key: Set useCustomKey=true (default: True).
        dry_run: Preview matches without applying (default: False).
        instance: Instance profile name (from instance_list).

    Returns:
        dict with matched_count, unmatched, total_entries, dry_run,
        audit_id (if applied).
    """
    # Validate entries
    if not entries:
        raise ToolError(
            "Cannot apply country codes: 'entries' must contain at least one entry. "
            "Use classification_get to retrieve entries first, then map each label "
            "to its code."
        )

    errors = []
    for i, entry in enumerate(entries):
        if not isinstance(entry, dict):
            errors.append(f"Entry {i} must be a dict with 'key' and 'label'")
            continue
        if not entry.get("key"):
            errors.append(f"Entry {i} missing 'key' (the code, e.g. 'AFG')")
        if not entry.get("label"):
            errors.append(f"Entry {i} missing 'label' (the display name)")
    if errors:
        raise ToolError(f"Invalid entries: {'; '.join(errors)}")

    # Fetch current classification with ALL field objects (paginated)
    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                classification_data = await client.get_all_pageable(
                    "/classification/{id}/pageable",
                    path_params={"id": classification_id},
                    resource_type="classification",
                    resource_id=classification_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Classification '{classification_id}' not found. "
                    "Use 'classification_list' to see available classifications."
                ) from None
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="classification", resource_id=classification_id
        ) from e

    raw_entries = (
        classification_data.get("content") or classification_data.get("entries") or []
    )

    # Match AI-provided entries to existing fields by display name (value)
    matched_fields, unmatched = _match_entries(raw_entries, entries)
    matched_count = len(matched_fields)

    # Dry run: return preview without modifying
    if dry_run:
        preview_matched = [
            {"label": f.get("value", ""), "key": f["key"]} for f in matched_fields[:20]
        ]
        return {
            "dry_run": True,
            "classification_id": classification_id,
            "classification_name": classification_data.get("name"),
            "total_entries": len(raw_entries),
            "matched_count": matched_count,
            "unmatched": [{"key": u["key"], "label": u["label"]} for u in unmatched],
            "enable_custom_key": enable_custom_key,
            "preview": preview_matched,
        }

    # Apply changes with audit-before-write
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="update",
                object_type="classification",
                object_id=str(classification_id),
                params={
                    "action": "apply_custom_keys",
                    "enable_custom_key": enable_custom_key,
                    "matched_count": matched_count,
                    "unmatched_count": len(unmatched),
                },
            )

            try:
                # Fail fast if the catalog has no name (broken state)
                catalog_name = classification_data.get("name")
                if not catalog_name:
                    raise ToolError(
                        f"Classification '{classification_id}' has no name "
                        "in API response. Cannot safely proceed without a "
                        "name (backend @Valid requires it). Check the "
                        "catalog in the BPA UI."
                    )

                # Step 1: Enable custom keys on the classification metadata
                if enable_custom_key:
                    await client.put(
                        "/classification",
                        json={
                            "id": classification_id,
                            "name": catalog_name,
                            "useCustomKey": True,
                        },
                        resource_type="classification",
                        resource_id=classification_id,
                    )

                # Step 2: POST each matched field individually
                succeeded: list[str] = []
                failed: list[dict[str, str]] = []

                for field in matched_fields:
                    try:
                        await client.post(
                            "/classification/{classification_type_id}/field",
                            path_params={
                                "classification_type_id": classification_id,
                            },
                            json=field,
                            resource_type="classification_field",
                        )
                        succeeded.append(field.get("value", ""))
                    except BPAClientError as field_err:
                        failed.append(
                            {
                                "value": field.get("value", ""),
                                "key": field.get("key", ""),
                                "error": str(field_err),
                            }
                        )

                # Save rollback state (previous entries for restore)
                await audit_logger.save_rollback_state(
                    audit_id=audit_id,
                    object_type="classification",
                    object_id=str(classification_id),
                    previous_state={
                        "id": classification_data.get("id"),
                        "name": classification_data.get("name"),
                        "type": classification_data.get("type"),
                        "entries": raw_entries,
                        "useCustomKey": classification_data.get("useCustomKey"),
                        "_operation": "update",
                    },
                )

                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "classification_id": classification_id,
                        "matched_count": matched_count,
                        "succeeded_count": len(succeeded),
                        "failed_count": len(failed),
                    },
                )

                return {
                    "dry_run": False,
                    "classification_id": classification_id,
                    "classification_name": classification_data.get("name"),
                    "total_entries": len(raw_entries),
                    "matched_count": matched_count,
                    "succeeded_count": len(succeeded),
                    "failed": failed,
                    "unmatched": [
                        {"key": u["key"], "label": u["label"]} for u in unmatched
                    ],
                    "custom_key_enabled": enable_custom_key,
                    "audit_id": audit_id,
                }

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(
                    e, resource_type="classification", resource_id=classification_id
                ) from e

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="classification", resource_id=classification_id
        ) from e


def register_classification_tools(mcp: Any) -> None:
    """Register classification tools with the MCP server.

    Args:
        mcp: The FastMCP server instance.
    """
    from mcp_eregistrations_bpa.tools.annotations import DESTRUCTIVE, READ, WRITE

    # Read operations
    mcp.tool(annotations=READ)(classification_list)
    mcp.tool(annotations=READ)(classification_get)
    mcp.tool(annotations=READ)(classification_search)
    mcp.tool(annotations=READ)(classification_export_csv)
    mcp.tool(annotations=READ)(classification_groups_list)
    # Write operations
    mcp.tool(annotations=WRITE)(classification_create)
    mcp.tool(annotations=WRITE)(classification_update)
    mcp.tool(annotations=DESTRUCTIVE)(classification_delete)
    mcp.tool(annotations=WRITE)(classification_apply_country_codes)
    mcp.tool(annotations=WRITE)(classification_group_create)
    mcp.tool(annotations=WRITE)(classification_group_update)
    mcp.tool(annotations=DESTRUCTIVE)(classification_group_delete)
    mcp.tool(annotations=WRITE)(classification_entry_set_groups)
