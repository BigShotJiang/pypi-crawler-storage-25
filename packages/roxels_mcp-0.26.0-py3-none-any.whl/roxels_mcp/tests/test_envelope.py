"""Unit tests for the canonical response envelope."""
import json

from roxels_mcp._envelope import (
    error,
    format_gap_as_next_action,
    next_action,
    not_found,
    ok,
    pending,
    register_path_recommender,
    wrap_warnings,
)


class TestNextAction:
    def test_basic_shape(self):
        block = next_action(tool="update_template", args={"template_id": "abc"}, why="to patch")
        assert block["call"]["tool"] == "update_template"
        assert block["call"]["args"] == {"template_id": "abc"}
        assert "update_template(template_id='abc')" in block["call_string"]
        assert block["why"] == "to patch"

    def test_with_question(self):
        block = next_action(tool="x", why="y", question="which field?")
        assert block["question"] == "which field?"

    def test_dict_arg_serializes(self):
        block = next_action(tool="x", args={"schema": {"name": "string"}})
        assert "schema" in block["call_string"]


class TestOk:
    def test_minimal(self):
        result = json.loads(ok())
        assert result["status"] == "ok"
        assert "meta" in result
        assert "mcp_version" in result["meta"]

    def test_with_data_and_action(self):
        result = json.loads(ok(action="created", data={"id": "t1"}))
        assert result["action"] == "created"
        assert result["data"] == {"id": "t1"}

    def test_with_warnings(self):
        result = json.loads(ok(warnings=[{"rule": "r", "message": "m", "severity": "HIGH"}]))
        assert result["warnings"][0]["severity"] == "HIGH"

    def test_with_next_action(self):
        na = next_action(tool="update_template", args={"id": "t1"}, why="continue")
        result = json.loads(ok(next_action_block=na))
        assert result["next_action"]["call"]["tool"] == "update_template"


class TestError:
    def test_shape(self):
        result = json.loads(error(error_message="nope", hint="do X", details="500"))
        assert result["status"] == "error"
        assert result["error"] == "nope"
        assert result["hint"] == "do X"
        assert result["details"] == "500"

    def test_with_next_action(self):
        na = next_action(tool="retry", why="fix first")
        result = json.loads(error(error_message="failed", next_action_block=na))
        assert result["next_action"]["call"]["tool"] == "retry"


class TestNotFound:
    def test_shape(self):
        result = json.loads(not_found(resource="template", identifier="abc"))
        assert result["status"] == "not_found"
        assert "template" in result["error"]
        assert "abc" in result["error"]


class TestPending:
    def test_shape(self):
        result = json.loads(pending(message="processing"))
        assert result["status"] == "pending"
        assert result["message"] == "processing"


class TestWrapWarnings:
    def test_basic(self):
        warnings = wrap_warnings(["w1", "w2"], rule="deprecated_field", severity="HIGH")
        assert len(warnings) == 2
        assert all(w["rule"] == "deprecated_field" for w in warnings)
        assert all(w["severity"] == "HIGH" for w in warnings)

    def test_filters_empty(self):
        warnings = wrap_warnings(["", "w", None], rule="x")  # type: ignore
        assert len(warnings) == 1


class TestV2MetaFields:
    """V2 added meta.loop_phase, meta.on_recommended_path, meta.template_state."""

    def teardown_method(self):
        # Reset recommender after each test
        register_path_recommender(lambda *_: None)

    def test_loop_phase_passes_through(self):
        result = json.loads(ok(loop_phase="primary"))
        assert result["meta"]["loop_phase"] == "primary"

    def test_loop_phase_on_error(self):
        result = json.loads(error(error_message="x", loop_phase="setup"))
        assert result["meta"]["loop_phase"] == "setup"

    def test_no_loop_phase_when_unset(self):
        result = json.loads(ok())
        assert "loop_phase" not in result["meta"]

    def test_recommender_on_path(self):
        """When agent calls the recommended tool, on_recommended_path=True."""
        register_path_recommender(lambda tool, tid: ("check_template", {"score": 80}))
        result = json.loads(ok(tool_name="check_template", template_id_for_state="t1"))
        assert result["meta"]["on_recommended_path"] is True
        assert result["meta"]["template_state"] == {"score": 80}
        # No warning when on path
        assert "off_script_warning" not in (result.get("data") or {})

    def test_recommender_off_path_adds_warning(self):
        """When agent calls a different tool than recommended, warning surfaces."""
        register_path_recommender(lambda tool, tid: ("check_template", {"score": 80}))
        result = json.loads(ok(tool_name="simulate_output", template_id_for_state="t1"))
        assert result["meta"]["on_recommended_path"] is False
        assert result["meta"]["recommended_tool"] == "check_template"
        assert "off_script_warning" in result["data"]
        assert "check_template" in result["data"]["off_script_warning"]

    def test_recommender_none_result(self):
        """Recommender returns None → no path awareness fields."""
        register_path_recommender(lambda *_: None)
        result = json.loads(ok(tool_name="whoami"))
        assert "on_recommended_path" not in result["meta"]
        assert "template_state" not in result["meta"]

    def test_recommender_preserves_existing_data(self):
        """When data is a dict and off-path, warning is prepended not replacing."""
        register_path_recommender(lambda *_: ("other_tool", None))
        result = json.loads(ok(tool_name="this_tool", data={"x": 1, "y": 2}))
        assert result["data"]["off_script_warning"]
        assert result["data"]["x"] == 1
        assert result["data"]["y"] == 2

    def test_template_state_via_recommender(self):
        register_path_recommender(lambda tool, tid: (tool, {"score": 100, "gaps_remaining": {"HIGH": 0}}))
        result = json.loads(ok(tool_name="check_template", template_id_for_state="t1"))
        assert result["meta"]["template_state"]["score"] == 100

    def test_pending_accepts_new_kwargs(self):
        register_path_recommender(lambda *_: ("x", None))
        result = json.loads(pending(message="wait", tool_name="x", loop_phase="secondary"))
        assert result["meta"]["loop_phase"] == "secondary"
        assert result["meta"]["on_recommended_path"] is True

    def test_not_found_accepts_new_kwargs(self):
        register_path_recommender(lambda *_: None)
        result = json.loads(not_found(resource="goal", identifier="g1", tool_name="x", loop_phase="primary"))
        assert result["meta"]["loop_phase"] == "primary"
        assert result["status"] == "not_found"

    def test_recommender_exception_is_swallowed(self):
        """If recommender raises, envelope still works."""
        register_path_recommender(lambda *_: (_ for _ in ()).throw(RuntimeError("boom")))
        result = json.loads(ok(tool_name="x"))
        # Graceful: envelope still produced; no meta.on_recommended_path
        assert result["status"] == "ok"
        assert "on_recommended_path" not in result["meta"]


class TestErrorEnvelopeHygiene:
    """Structural guards: every error envelope must be actionable.

    The rule: error responses always carry at least a `hint` OR a `next_action`.
    Bare errors like `{status: "error", error: str(e)}` — which the cohesion
    overhaul explicitly retired — must not return via the envelope helpers.
    """

    def test_error_requires_hint_or_next_action_at_call_time(self):
        # An error with hint → ok
        result = json.loads(error(error_message="x", hint="do Y"))
        assert "hint" in result

    def test_error_with_next_action_only_is_fine(self):
        na = next_action(tool="retry", why="fix first")
        result = json.loads(error(error_message="x", next_action_block=na))
        assert "next_action" in result

    def test_error_without_hint_or_next_action_should_be_flagged(self):
        """This test asserts the shape CURRENTLY allowed (bare error with no
        guidance) — so tests break if a new validation rule adds this as a
        hard requirement. Intentionally lenient today; codifies the ambition
        that we MOVE toward always-actionable errors."""
        result = json.loads(error(error_message="x"))
        # Currently allowed; this is documented rather than enforced.
        # If one day we enforce it, this test should assert the opposite.
        assert result["status"] == "error"
        # But: the guidance is that errors should have actionable info.
        # Flag if the envelope produced neither:
        has_guidance = ("hint" in result) or ("next_action" in result)
        # Intentionally not asserting — this is a SOFT contract for now.
        # Future hardening: `assert has_guidance, "error must have hint or next_action"`
        _ = has_guidance  # keep the probe


class TestFormatGap:
    def test_basic_gap(self):
        gap = {
            "severity": "HIGH",
            "field": "settings.outputs[0].config.schema",
            "problem": "No schema set",
            "answer_this": "Which fields?",
            "then_call": "update_webhook_schema(template_id='t1', goal_id='g1', schema={})",
        }
        na = format_gap_as_next_action(gap)
        assert na is not None
        assert na["call"]["tool"] == "update_webhook_schema"
        assert na["why"] == "No schema set"
        assert na["question"] == "Which fields?"
        assert "update_webhook_schema" in na["call_string"]

    def test_gap_without_then_call_returns_none(self):
        gap = {"severity": "LOW", "problem": "minor"}
        assert format_gap_as_next_action(gap) is None

    def test_non_dict_returns_none(self):
        assert format_gap_as_next_action("not a gap") is None  # type: ignore
