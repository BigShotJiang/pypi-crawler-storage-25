"""Cohesion tests — verify the MCP's surface is self-consistent.

These tests enforce the P1/P2/P3 design principles from the 0.21 overhaul:
  P1 (ONE LANGUAGE): deleted names are truly gone; new names are registered.
  P2 (ONE SHAPE): tool responses use the canonical envelope.
  P3 (ONE THREAD): mutating tools include next_action.
"""
import json

import pytest
from unittest.mock import AsyncMock, MagicMock

from roxels_mcp.server import create_server
from roxels_mcp.client import RoxelsClient


def _make_client() -> RoxelsClient:
    client = MagicMock(spec=RoxelsClient)
    client.get_template = AsyncMock(return_value={
        "id": "t1",
        "goals": [{"id": "g1"}],
        "settings": {"outputs": [{"type": "webhook", "config": {"trigger_goal": "g1"}}]},
    })
    client.list_templates = AsyncMock(return_value=[])
    client.update_template = AsyncMock(return_value={
        "id": "t1",
        "goals": [{"id": "g1"}],
        "settings": {"outputs": [{"type": "webhook", "config": {"trigger_goal": "g1"}}]},
    })
    client._request = AsyncMock(return_value=[])
    return client


def _tool(mcp, name):
    return mcp._tool_manager._tools[name].fn


def _tool_names(mcp):
    return set(mcp._tool_manager._tools.keys())


# ── P1: deleted names are truly gone ─────────────────────────────────────────

def test_deleted_tool_names_are_absent():
    mcp = create_server(_make_client())
    names = _tool_names(mcp)
    for deleted in [
        "set_goal_schema",
        "test_webhook",
        "validate_template_data_sources",
        "test_output",
        "test_data_source",
        "start_test_session",
        "template_readiness_score",
        "guided_setup_questions",
        "set_webhook_schema",  # renamed to update_webhook_schema
        "set_goal_commit_rules",
        "describe_complete_template",
        "get_id_resolution_guidance",
        "get_template_schema",
        "get_data_source_schema",
        "get_validation_schema",
        "get_embed_config",
    ]:
        assert deleted not in names, f"{deleted} should be deleted / renamed but is still registered"


def test_renamed_tool_names_are_present():
    mcp = create_server(_make_client())
    names = _tool_names(mcp)
    for new in [
        "update_webhook_schema",
        "update_goal_commit_rules",
        "check_template",
        # V2: 6 reference tools collapsed to get_reference
        "get_reference",
        # V2: 7 testing tools collapsed to verify
        "verify",
        # V2: 4 shape tools collapsed to integration_shape
        "integration_shape",
        # meta tools
        "get_next_action",
        "get_mcp_index",
    ]:
        assert new in names, f"{new} should be registered"


def test_v2_verify_replaces_seven_testing_tools():
    """The 7 old testing tools should be deleted; verify(scope) replaces all."""
    mcp = create_server(_make_client())
    names = _tool_names(mcp)
    assert "verify" in names
    for deleted in [
        "check_template_config",
        "probe_data_source",
        "simulate_output",
        "send_http_request",
        "preview_webhook_payload",
        "check_embed_permissions_policy",
        "start_live_session",
    ]:
        assert deleted not in names, (
            f"V2 collapsed {deleted} into verify(scope=...) — should be absent"
        )


def test_v2_integration_shape_replaces_four_shape_tools():
    mcp = create_server(_make_client())
    names = _tool_names(mcp)
    assert "integration_shape" in names
    for deleted in [
        "get_integration_shape",
        "revise_integration_shape",
        "confirm_integration_shape",
        "propose_integration_shape",
    ]:
        assert deleted not in names, (
            f"V2 collapsed {deleted} into integration_shape(action=...) — should be absent"
        )


def test_v2_get_reference_replaces_six_tools():
    """The 6 old reference tools should be deleted; get_reference(topic) replaces all."""
    mcp = create_server(_make_client())
    names = _tool_names(mcp)
    assert "get_reference" in names
    for deleted in [
        "get_template_reference",
        "get_data_source_reference",
        "get_validation_reference",
        "get_embed_reference",
        "get_id_resolution_guide",
        "get_canonical_template_spec",
    ]:
        assert deleted not in names, (
            f"V2 collapsed {deleted} into get_reference(topic=...) — should be absent"
        )


def test_mcp_has_instructions():
    """FastMCP should be constructed with an instructions banner pointing at entry points."""
    mcp = create_server(_make_client())
    # FastMCP stores instructions on the low-level server
    instructions = getattr(mcp, "instructions", None) or getattr(
        getattr(mcp, "_mcp_server", None), "instructions", None
    )
    assert instructions, "MCP should have instructions set"
    assert "get_next_action" in instructions
    assert "get_reference" in instructions or "canonical_spec" in instructions


# ── P2: canonical envelope shape ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_check_template_returns_canonical_envelope():
    mcp = create_server(_make_client())
    tool_fn = _tool(mcp, "check_template")
    result = json.loads(await tool_fn(template_id="t1"))
    # Canonical keys
    assert "status" in result
    assert "data" in result
    assert "meta" in result
    assert "mcp_version" in result["meta"]


@pytest.mark.asyncio
async def test_get_mcp_index_returns_canonical_envelope():
    mcp = create_server(_make_client())
    tool_fn = _tool(mcp, "get_mcp_index")
    result = json.loads(await tool_fn())
    assert result["status"] == "ok"
    assert "data" in result
    assert "meta" in result


@pytest.mark.asyncio
async def test_get_next_action_returns_next_action_block():
    mcp = create_server(_make_client())
    tool_fn = _tool(mcp, "get_next_action")
    result = json.loads(await tool_fn(template_id="t1"))
    assert result["status"] == "ok"
    assert "next_action" in result
    na = result["next_action"]
    assert "call" in na
    assert "tool" in na["call"]
    assert "why" in na


# ── P3: next_action points at registered tools ──────────────────────────────

@pytest.mark.asyncio
async def test_get_next_action_points_at_real_tool():
    mcp = create_server(_make_client())
    names = _tool_names(mcp)
    tool_fn = _tool(mcp, "get_next_action")
    result = json.loads(await tool_fn(template_id="t1"))
    na_tool = result["next_action"]["call"]["tool"]
    assert na_tool in names, f"next_action points at {na_tool} which is not registered"


# ── Terminology sweep verification ──────────────────────────────────────────

@pytest.mark.asyncio
async def test_configure_output_surfaces_template_state_and_loop_phase():
    """V2-D wiring: configure_output should emit meta.template_state +
    meta.loop_phase + (when applicable) meta.on_recommended_path."""
    template = {
        "id": "t1",
        "goals": [{"id": "g1"}],
        "settings": {
            "outputs": [],
            # No integration_shape → no shape-negotiation gap, so not forcing path-1 logic.
        },
    }
    client = _make_client()
    client.get_template = AsyncMock(return_value=template)
    client.update_template = AsyncMock(return_value=template)
    mcp = create_server(client)
    tool = _tool(mcp, "configure_output")
    result = json.loads(await tool(
        template_id="t1",
        output_type="webhook",
        config={"url": "https://example.com/hook", "trigger_goal": "g1"},
    ))
    assert result["status"] == "ok"
    meta = result["meta"]
    # loop_phase populated
    assert meta.get("loop_phase") == "primary"
    # template_state populated with the 4 expected keys
    ts = meta.get("template_state") or {}
    assert "score" in ts
    assert "gaps_remaining" in ts
    assert "shape_status" in ts
    assert "has_live_sessions" in ts


def test_server_py_has_no_raw_json_dumps_returns():
    """Every tool must go through the canonical envelope — no raw `return json.dumps(...)` allowed.

    This prevents response-shape drift. If a new tool forgets the envelope helpers, this
    test fails. The envelope helpers wrap json.dumps internally; code outside them should
    not call json.dumps as a return statement.
    """
    import inspect
    import roxels_mcp.server as s
    import re

    src = inspect.getsource(s)
    # Find `return json.dumps(` occurrences
    matches = re.findall(r'return json\.dumps\(', src)
    assert not matches, (
        f"server.py contains {len(matches)} raw `return json.dumps(...)` calls. "
        f"Wrap with _env_ok / _env_error / _env_not_found / _env_pending instead — "
        f"this keeps response shape consistent across every tool."
    )


def test_server_client_method_names_match():
    """Every client.XXX(...) call from server.py must reference a real method on RoxelsClient.

    This catches the class of bug where we rename a tool but forget to rename the
    corresponding client method — AttributeError at runtime, silent in mock-based tests.
    """
    import inspect
    import re
    import roxels_mcp.server as s
    from roxels_mcp.client import RoxelsClient

    server_src = inspect.getsource(s)
    called = set(re.findall(r"client\.([a-z_]+)\(", server_src))
    # _request is internal; skip it
    called.discard("_request")

    client_methods = {
        name for name, _ in inspect.getmembers(RoxelsClient, predicate=inspect.iscoroutinefunction)
    }
    client_methods |= {
        name for name, _ in inspect.getmembers(RoxelsClient, predicate=inspect.isfunction)
    }

    missing = called - client_methods
    assert not missing, (
        f"server.py calls client methods that don't exist on RoxelsClient: {sorted(missing)}. "
        f"This would AttributeError at runtime. Fix: add or rename these methods on RoxelsClient."
    )


def test_stale_tool_names_absent_from_references():
    """References/_references.py should not mention renamed or deleted tools."""
    import roxels_mcp._references as r
    import inspect

    src = inspect.getsource(r)
    for stale in [
        "set_goal_schema",
        "set_webhook_schema",  # renamed to update_webhook_schema
        "set_goal_commit_rules",  # renamed to update_goal_commit_rules
        "test_webhook",
        "test_output",
        "test_data_source",
        "start_test_session",
        "validate_template_data_sources",
        "template_readiness_score",
        "guided_setup_questions",
        "describe_complete_template",
        "get_id_resolution_guidance",
        "get_template_schema",
        "get_data_source_schema",
        "get_validation_schema",
        "get_embed_config",
    ]:
        assert stale not in src, (
            f"Stale tool name '{stale}' still appears in _references.py — "
            f"agents reading the reference blob will be told to call a tool that doesn't exist."
        )


@pytest.mark.asyncio
async def test_check_template_gaps_have_no_legacy_then_call_field():
    """Gap dicts returned by check_template must use next_action, not then_call.

    The legacy then_call field was a plain string including placeholder syntax
    (e.g. <goal_id>). It's been replaced by a structured next_action block.
    Agents must see exactly one field, not both.
    """
    template = {
        "id": "t1",
        "goals": [{"id": "g1"}],
        "settings": {
            "outputs": [{
                "type": "webhook",
                "config": {
                    "trigger_goal": "g1",
                    "commit_policy": "require_all_required",
                    "schema": {"name": "string"},  # HIGH gap: no required_before_commit
                },
            }]
        },
    }
    client = MagicMock(spec=RoxelsClient)
    client.get_template = AsyncMock(return_value=template)
    client._request = AsyncMock(return_value=[])
    mcp = create_server(client)
    result = json.loads(await _tool(mcp, "check_template")(template_id="t1"))
    gaps = result.get("data", {}).get("gaps", [])
    assert gaps, "expected at least one gap to exercise the assertion"
    for g in gaps:
        assert "then_call" not in g, (
            f"gap still has legacy then_call field: {g}"
        )
        assert "next_action" in g, (
            f"gap missing canonical next_action field: {g}"
        )


@pytest.mark.asyncio
async def test_no_deleted_tool_names_in_reference_blobs():
    """Reference blobs recommend tools to agents — they must never recommend
    a tool that was deleted. The 'Bearer {{context.authToken}}' auth-form bug
    class would have been caught earlier if we had enforced that our docs only
    point at tools that actually exist.

    Sweep every reference topic and confirm no deleted V1 tool name appears.
    """
    client = _make_client()
    mcp = create_server(client)
    get_reference = _tool(mcp, "get_reference")
    deleted_names = [
        "set_goal_schema",
        "test_webhook",
        "validate_template_data_sources",
        "test_output",
        "test_data_source",
        "start_test_session",
        "template_readiness_score",
        "guided_setup_questions",
        "set_webhook_schema",
        "set_goal_commit_rules",
        "describe_complete_template",
        "get_id_resolution_guidance",
        "get_template_schema",
        "get_data_source_schema",
        "get_validation_schema",
        "get_embed_config",
        "patch_output",
        "patch_data_source",
        "create_template_interactive",
        "modify_template_interactive",
    ]
    topics = ["template", "data_source", "validation", "embed", "id_resolution", "canonical_spec"]
    import re
    for topic in topics:
        result = json.loads(await get_reference(topic=topic))
        assert result["status"] == "ok"
        blob = json.dumps(result["data"])
        for stale in deleted_names:
            assert not re.search(r"\b" + re.escape(stale) + r"\b", blob), (
                f"Reference topic='{topic}' recommends deleted tool {stale!r}. "
                f"Docs must not point agents at tools that no longer exist."
            )


def test_docstrings_avoid_user_facing_interview_terminology():
    """No user-facing "AI interviewer" or "interviewees" should remain in docstrings."""
    import roxels_mcp.server as s
    import roxels_mcp._references as r
    import inspect

    server_src = inspect.getsource(s)
    ref_src = inspect.getsource(r)

    combined = server_src + "\n" + ref_src
    # These are user-facing phrases that should no longer appear
    for bad in ["AI interviewer", "interviewees"]:
        assert bad not in combined, (
            f"Found stale user-facing term '{bad}' — terminology sweep missed it"
        )
