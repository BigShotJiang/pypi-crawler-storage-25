"""Roxels MCP Server — tool definitions for AI agent integration.

GUIDING PRINCIPLE — Information-complete outcomes
=================================================
Every tool in this server must guide the caller toward a configuration that the
engine can execute reliably — not just accept input and return "saved."

Concretely:
  - After every configure call, return what's still missing.
  - Surface natural pairings unprompted (e.g. if a DS has args-sourced params,
    tell the author to set cache_key_fields for those param names).
  - Tell the author what a wrong setup produces at runtime (silent failures,
    missing data) so they understand the stakes, not just the mechanics.
  - On error responses from probe_data_source, pattern-match the error body and
    suggest the exact fix — never just echo the raw error.

An author (human or AI) who follows the MCP's prompts from start to finish
must arrive at a config the engine can execute reliably without reading docs
or debugging a live session.

WHEN IN DOUBT — ASK
===================
This MCP has a natural-language Q&A tool: `ask_roxels(question, template_id?)`.
It answers free-form questions about integrating Roxels, with full context on
the product, the schema, the complete-template spec, and — when a template_id
is given — the template's current state, runtime learnings, and the onboarding
transcript that created it. Every answer ends with a concrete next action.

Coding agents integrating Roxels should lean on `ask_roxels` whenever:
  - a structured tool's output does not fully resolve the question,
  - they need an opinion (per-goal vs end-of-session, where to put auth, etc.),
  - they are about to ask the user a question — check ask_roxels first.

Cheaper than guessing, cheaper than trial-and-error, and every Q&A is persisted
so the MCP itself gets smarter over time about what coding agents find unclear.
"""

import asyncio
import json
import os
import re
import textwrap
import webbrowser
from typing import Literal

from mcp.server.fastmcp import FastMCP

from .client import RoxelsClient
from ._envelope import (
    error as _env_error,
    format_gap_as_next_action as _env_format_gap,
    next_action as _env_next_action,
    not_found as _env_not_found,
    ok as _env_ok,
    pending as _env_pending,
    wrap_warnings as _env_wrap_warnings,
)
from ._references import (
    COMPLETE_TEMPLATE_SPEC,
    DATA_SOURCE_REFERENCE,
    EMBED_CONFIG_REFERENCE,
    EMBED_JS_URL,
    ID_RESOLUTION_GUIDANCE,
    TEMPLATE_SCHEMA_REFERENCE,
    VALIDATION_REFERENCE,
)

ALLOWED_OPEN_ORIGINS = ("https://app.roxels.ai/",)


def _validate_join_url(url: str) -> None:
    """Ensure the URL points to a trusted Roxels origin before opening in browser."""
    if not any(url.startswith(origin) for origin in ALLOWED_OPEN_ORIGINS):
        raise ValueError(
            f"Refusing to open untrusted URL: {url}. "
            f"Expected origin: {ALLOWED_OPEN_ORIGINS[0]}"
        )


_SECRET_VALUE_PATTERNS = [
    re.compile(r"^Bearer\s+\S{10,}"),
    re.compile(r"^sk_(live|test)_"),
    re.compile(r"^rk_(live|test)_"),
    re.compile(r"^ghp_|^ghs_|^github_pat_"),
    re.compile(r"^[A-Za-z0-9+/]{40,}={0,2}$"),
]


def _looks_like_raw_secret(value: str) -> bool:
    """Return True if a string looks like a plaintext credential that should be stored via store_secret.

    Template placeholders ({{context.X}}, {{secret:uuid}}, {{args.X}}, {{phrase}})
    are pre-resolved at runtime — never raw credentials — so we short-circuit
    False when any are present. Without this short-circuit the '^Bearer\\s+\\S{10,}'
    pattern matches 'Bearer {{context.authToken}}' (23 non-whitespace chars after
    'Bearer ') — exactly the form the canonical docs recommend — and rejects it
    as a raw credential, steering clients toward broken workarounds.
    """
    v = value.strip()
    # Template placeholders are pre-resolved at runtime; never a raw credential.
    if "{{" in v and "}}" in v:
        return False
    return any(p.match(v) for p in _SECRET_VALUE_PATTERNS)


def _content_type_for_encoding(encoding: str) -> str:
    return {
        "json": "application/json",
        "form": "application/x-www-form-urlencoded",
        "form-nested": "application/x-www-form-urlencoded",
    }.get(encoding, "application/json")


def _sample_value_for_type(type_str: str):
    return {
        "string": "sample_string",
        "number": 42,
        "boolean": True,
        "array": [],
        "array of strings": ["item1", "item2"],
        "object": {},
    }.get(type_str, "sample_value")


def _generate_sample_from_schema(schema: dict, overrides: dict) -> dict | list:
    """Produce a sample commit body matching a webhook schema. Overrides win."""
    if not isinstance(schema, dict):
        return overrides
    if schema.get("type") == "array":
        item = _generate_sample_from_schema(schema.get("item_schema", {}), overrides)
        return [item] if item else []
    sample: dict = {}
    for field, spec in schema.items():
        if field in overrides:
            sample[field] = overrides[field]
            continue
        if isinstance(spec, str):
            sample[field] = _sample_value_for_type(spec)
        elif isinstance(spec, dict):
            ftype = spec.get("type", "string")
            if ftype == "array":
                inner = _generate_sample_from_schema(spec.get("item_schema", {}), {})
                sample[field] = [inner] if inner else []
            elif ftype == "resolved_reference":
                sample[field] = {"id": "resolved_id_placeholder", "label": "Resolved Label"}
            else:
                sample[field] = _sample_value_for_type(ftype)
    return sample


def _interpolate_body_template(
    template_val, sample_data: dict, schema: dict
) -> tuple[object, list[str], list[str]]:
    """Walk body_template; replace {{context.X}} and {{field}} tokens.

    Returns (rendered, resolved_keys, unresolved_placeholders).
    """
    resolved: list[str] = []
    unresolved: list[str] = []

    def _render(value):
        if isinstance(value, str):
            # Find all placeholders
            tokens = re.findall(r"\{\{([^}]+)\}\}", value)
            if not tokens:
                return value
            out = value
            for tok in tokens:
                tok = tok.strip()
                if tok.startswith("context."):
                    key = tok[len("context."):]
                    # For a preview, fabricate a plausible context value
                    val = sample_data.get(f"context.{key}") or sample_data.get(key) or f"<{tok}>"
                    if val == f"<{tok}>":
                        unresolved.append(tok)
                    else:
                        resolved.append(tok)
                    out = out.replace("{{" + tok + "}}", str(val))
                elif tok in (schema or {}):
                    sample_default = sample_data.get(tok) or _sample_value_for_type(
                        schema[tok] if isinstance(schema[tok], str) else schema[tok].get("type", "string")
                    )
                    out = out.replace("{{" + tok + "}}", str(sample_default))
                else:
                    unresolved.append(tok)
                    out = out.replace("{{" + tok + "}}", f"<{tok}>")
            return out
        if isinstance(value, dict):
            return {k: _render(v) for k, v in value.items()}
        if isinstance(value, list):
            return [_render(v) for v in value]
        return value

    rendered = _render(template_val)
    return rendered, sorted(set(resolved)), sorted(set(unresolved))


def _format_template_result_with_warnings(result: dict, action: str) -> str:
    """Wrap a create/update_template response in the canonical envelope.

    ALWAYS returns valid JSON. Warnings (if any) go in the canonical `warnings`
    array and a human-readable `warnings_summary` string is added for agents
    that want a pre-formatted overview.
    """
    raw_warnings = result.get("warnings") or []
    template_id = result.get("id") or result.get("template_id")

    # Build a next_action that nudges the agent to verify readiness
    na = None
    if template_id:
        na = _env_next_action(
            tool="check_template",
            args={"template_id": str(template_id)},
            why=f"Verify the {action} template passes all reliability checks before going live.",
        )

    # Normalize warnings to the canonical shape
    normalized_warnings: list[dict] = []
    summary_lines: list[str] = []
    for i, w in enumerate(raw_warnings, 1):
        if not isinstance(w, dict):
            continue
        entry = {
            "rule": w.get("rule", "unknown"),
            "message": w.get("message", "(no message)"),
            "severity": w.get("severity", "MEDIUM"),
        }
        normalized_warnings.append(entry)
        summary_lines.append(f"  {i}. [{entry['rule']}] {entry['message']}")

    data = {k: v for k, v in result.items() if k != "warnings"}
    if summary_lines:
        data["warnings_summary"] = (
            f"Template {action} with {len(normalized_warnings)} advisory warning(s):\n"
            + "\n".join(summary_lines)
        )

    return _env_ok(
        action=action,
        data=data,
        warnings=normalized_warnings or None,
        next_action_block=na,
        meta={"template_id": str(template_id)} if template_id else None,
    )


def _interrogate_source(
    ds: dict,
    template_id: str,
    outputs: list[dict] | None = None,
) -> list[dict]:
    """Diagnose a data source and return blocking questions for any missing reliability fields.

    Called immediately after configure_data_source and from check_template.
    Returns questions the calling agent must answer before the source is production-ready.

    When `outputs` is provided, the auth check is sharpened: if any webhook output
    targets the same host as this data source AND that webhook is authenticated,
    the "missing auth" gap upgrades to a very specific message citing the matching
    webhook's auth shape. Almost certainly a misconfiguration — same-domain endpoints
    nearly always share auth.
    """
    name = ds.get("name", "unnamed")
    default_params = ds.get("default_params", {})
    items = []

    if not ds.get("description"):
        items.append({
            "severity": "HIGH",
            "field": f"data_source '{name}' → description",
            "problem": (
                "No description. The description is the CONTRACT SURFACE between this source and the "
                "conversational agent — it is injected verbatim into the agent's system prompt and is "
                "how the agent learns what the source does and what params it must pass at call time. "
                "Without it the agent cannot reliably pass scope params (level, category, etc.), cannot "
                "generate good query variations, and misses domain-specific abbreviations."
            ),
            "answer_this": (
                f"Write a plain-English description of '{name}' that covers, at minimum:\n"
                f"  1. What the endpoint searches over (e.g. 'company account directory', 'US geographic locations').\n"
                f"  2. What scope params the caller MUST pass, with valid values — e.g. "
                f"'always pass level as one of: metro, state, country'. Be explicit: if the source needs "
                f"a param to disambiguate results, say so here. The agent reads this and passes scope "
                f"accordingly at resolve time — nothing else tells it what to pass.\n"
                f"  3. What kinds of phrases it accepts (full names, abbreviations, codes, colloquialisms).\n"
                f"  4. What a typical result object looks like."
            ),
            "then_call": f"configure_data_source(template_id='{template_id}', name='{name}', description='<your answer>')",
        })

    if not ds.get("examples"):
        items.append({
            "severity": "HIGH",
            "field": f"data_source '{name}' → examples",
            "problem": "No few-shot examples. Without anchors, the query generator and candidate picker make arbitrary choices on ambiguous phrases — semi-consistent behavior is guaranteed.",
            "answer_this": (
                f"Give 3–5 concrete examples of phrases a user might say that '{name}' should resolve, "
                f"and what the correct structured result is for each. "
                f"Include edge cases: abbreviations, colloquialisms, partial names, accented variants."
            ),
            "then_call": (
                f"configure_data_source(template_id='{template_id}', name='{name}', "
                f"examples=[{{\"phrase\": \"<phrase>\", \"expected_result\": {{\"id\": ..., \"name\": \"...\"}}}}])"
            ),
        })

    if not ds.get("canonicalization_rules"):
        items.append({
            "severity": "MEDIUM",
            "field": f"data_source '{name}' → canonicalization_rules",
            "problem": "No tiebreaker rules. When the endpoint returns multiple plausible candidates for the same phrase, the agent makes an arbitrary choice.",
            "answer_this": (
                f"When '{name}' returns multiple candidates for the same phrase, how should the agent choose? "
                f"Are there params (like 'type', 'category', 'tier') that determine which result is correct? "
                f"Are there preferred result types when ambiguous (e.g. prefer a more specific record over a more general one)?"
            ),
            "then_call": (
                f"configure_data_source(template_id='{template_id}', name='{name}', "
                f"canonicalization_rules='<your rules>')"
            ),
        })

    if not ds.get("cache_key_fields"):
        items.append({
            "severity": "MEDIUM",
            "field": f"data_source '{name}' → cache_key_fields",
            "problem": (
                f"No cache_key_fields declared. If the agent passes a narrowing scope param at call time "
                f"(e.g. level=metro vs level=state, or category=hardware vs category=software) and the same "
                f"phrase can legitimately resolve to different objects depending on that param, "
                f"subsequent lookups of the same phrase will return a stale cached result from a prior "
                f"call with a different param value."
            ),
            "answer_this": (
                f"Are there any scope params the agent passes to '{name}' where the same phrase resolves "
                f"to different objects depending on the param value? For example, does 'Springfield' resolve "
                f"differently when level=state vs level=metro? If yes, list those param names."
            ),
            "then_call": (
                f"configure_data_source(template_id='{template_id}', name='{name}', "
                f"cache_key_fields=[\"<param_that_changes_the_result>\"])"
            ),
        })

    # relaxable_params — narrowing params safe to drop on 0-results retry
    if default_params and not ds.get("relaxable_params"):
        # Only surface this for params that look like narrowing filters (not context injections like {{context.*}})
        static_params = [
            k for k, v in default_params.items()
            if isinstance(v, str) and not v.startswith("{{context.")
        ]
        if static_params:
            items.append({
                "severity": "MEDIUM",
                "field": f"data_source '{name}' → relaxable_params",
                "problem": (
                    f"Has narrowing params {static_params} but no relaxable_params declared. "
                    f"When a lookup returns 0 results, the agent's recovery cascade can automatically "
                    f"drop declared params and retry — catching cases where the extraction model picked "
                    f"the wrong filter value. Without this, the cascade skips straight to world-knowledge "
                    f"fallback even if the entity exists in the database under a different filter value."
                ),
                "answer_this": (
                    f"Which of these params — {static_params} — are safe to omit on a retry? "
                    f"A param is safe to relax if omitting it broadens the search without leaking data "
                    f"across tenancy boundaries (e.g. a 'type' or 'category' filter is safe; an account_id "
                    f"or org_id that isolates data to one customer is NOT safe and must never be relaxed). "
                    f"List only the params that are narrowing filters, not tenancy guards."
                ),
                "then_call": (
                    f"configure_data_source(template_id='{template_id}', name='{name}', "
                    f"relaxable_params=[\"<safe_narrowing_param>\"])"
                ),
            })

    # v2 checks — declared params with value_from=args
    _req = ds.get("request", {})
    _params_decl = _req.get("params", []) if isinstance(_req, dict) else []
    _args_params = [p for p in _params_decl if isinstance(p, dict) and p.get("value_from") == "args"]
    for _ap in _args_params:
        _pname = _ap.get("name", "?")
        if _ap.get("required") and not _ap.get("description"):
            items.append({
                "severity": "HIGH",
                "field": f"data_source '{name}' → request.params[{_pname}] → description",
                "problem": (
                    f"Required args param '{_pname}' has no description. The agent reads param "
                    f"descriptions to know what value to pass when calling resolve_id(args={{...}}). "
                    f"Without a description, the agent guesses — and guesses wrong under ambiguous phrases."
                ),
                "answer_this": (
                    f"What is '{_pname}' for, and what are the correct values? "
                    f"Be specific: include valid values, what each means, and any default rule "
                    f"(e.g. 'default to metro for city names; use state for state names')."
                ),
                "then_call": (
                    f"configure_data_source(template_id='{template_id}', name='{name}', "
                    f"params=[{{...existing params..., 'name': '{_pname}', 'description': '<your answer>'}}])"
                ),
            })
        if _ap.get("type") == "enum" and not _ap.get("values"):
            items.append({
                "severity": "HIGH",
                "field": f"data_source '{name}' → request.params[{_pname}] → values",
                "problem": (
                    f"Param '{_pname}' is declared as type=enum but has no values list. "
                    f"The agent needs the valid enum values to pass the right one at call time, "
                    f"and the engine needs them for the automatic enum sweep on 0-results fallback."
                ),
                "answer_this": f"What are the valid enum values for '{_pname}'?",
                "then_call": (
                    f"configure_data_source(template_id='{template_id}', name='{name}', "
                    f"params=[{{...existing params..., 'name': '{_pname}', 'values': ['<val1>', '<val2>']}}])"
                ),
            })
    if _args_params:
        args_names = [p.get("name") for p in _args_params]
        if not ds.get("cache_key_fields"):
            items.append({
                "severity": "MEDIUM",
                "field": f"data_source '{name}' → cache_key_fields",
                "problem": (
                    f"Has args-sourced params {args_names} but no cache_key_fields. "
                    f"The same phrase can resolve to a different object depending on which arg value "
                    f"the agent passes (e.g. 'Springfield' at level=state vs level=metro). "
                    f"Without cache_key_fields including those param names, a cached result from one "
                    f"arg value will be returned for a different arg value."
                ),
                "answer_this": f"Do different values of {args_names} return different objects for the same phrase? (Almost certainly yes.)",
                "then_call": (
                    f"configure_data_source(template_id='{template_id}', name='{name}', "
                    f"cache_key_fields={json.dumps(args_names)})"
                ),
            })
        if not ds.get("relaxable_params"):
            items.append({
                "severity": "MEDIUM",
                "field": f"data_source '{name}' → relaxable_params",
                "problem": (
                    f"Has args-sourced params {args_names} but no relaxable_params. "
                    f"If the agent passes a wrong arg value and gets 0 results, the recovery cascade "
                    f"needs to know it can drop those params and retry to find the entity."
                ),
                "answer_this": f"Are {args_names} safe to drop on a 0-results retry (narrowing filters, not tenancy guards)?",
                "then_call": (
                    f"configure_data_source(template_id='{template_id}', name='{name}', "
                    f"relaxable_params={json.dumps(args_names)})"
                ),
            })

    # Auth check — almost all production data sources hit authenticated backends.
    # auth_type=None is a reasonable choice ONLY for truly public endpoints (rare).
    # Unless we can prove this is one, flag it — the failure mode (401 from the
    # endpoint) surfaces silently: resolve_id returns no match, agent falls back to
    # world knowledge, and webhooks post free-text strings. Silent data corruption.
    #
    # AGGRESSIVE CROSS-CHECK: if `outputs` is provided and any webhook posts to
    # the SAME HOST as this data source AND has an Authorization header, it's
    # near-certain the data source needs the same auth. Upgrade the gap message
    # to cite the matching webhook.
    endpoint = ds.get("endpoint") or {}
    auth = endpoint.get("auth") if isinstance(endpoint, dict) else None
    auth_type = (auth or {}).get("type") if isinstance(auth, dict) else None
    url = endpoint.get("url") if isinstance(endpoint, dict) else ""
    if not auth_type:
        is_plausibly_public = isinstance(url, str) and any(
            pat in url.lower()
            for pat in [
                "wikipedia.org", "wikidata.org",
                "api.github.com/repos",  # public repo metadata
                "restcountries", "open-meteo", "ipapi.co",
            ]
        )

        # Extract host of the data source URL for cross-checking against webhooks.
        ds_host = None
        if isinstance(url, str) and url:
            try:
                from urllib.parse import urlparse
                parsed = urlparse(url)
                ds_host = (parsed.netloc or "").lower() or None
            except Exception:
                ds_host = None

        # Look for a matching webhook on the same host with an Authorization header.
        matching_webhook = None
        if ds_host and outputs:
            for o in outputs:
                if not isinstance(o, dict) or o.get("type") != "webhook":
                    continue
                cfg = o.get("config") or {}
                w_url = cfg.get("url") or ""
                w_headers = cfg.get("headers") or {}
                if not isinstance(w_url, str) or not w_url:
                    continue
                try:
                    from urllib.parse import urlparse
                    w_host = (urlparse(w_url).netloc or "").lower()
                except Exception:
                    w_host = ""
                if w_host != ds_host:
                    continue
                # Same host. Does this webhook authenticate?
                auth_header = None
                for hk, hv in w_headers.items() if isinstance(w_headers, dict) else []:
                    if isinstance(hk, str) and hk.lower() == "authorization":
                        auth_header = hv
                        break
                if auth_header:
                    matching_webhook = {
                        "url": w_url,
                        "trigger_goal": cfg.get("trigger_goal"),
                        "authorization": str(auth_header),
                    }
                    break

        if matching_webhook:
            # VERY HIGH confidence — same host, webhook has auth, data source has none.
            items.append({
                "severity": "HIGH",
                "field": f"data_source '{name}' → auth  (mismatch vs webhook on same host)",
                "problem": (
                    f"Data source '{name}' has NO auth, but webhook "
                    f"{('trigger_goal=' + matching_webhook['trigger_goal']) if matching_webhook.get('trigger_goal') else 'at the same host'} "
                    f"sends 'Authorization: {matching_webhook['authorization']}' to the SAME host "
                    f"({ds_host}). Same-domain endpoints almost always share auth — this is nearly "
                    f"certain to be a misconfiguration. At runtime, resolve_id will 401 silently, "
                    f"return 'no match,' and the agent will fall back to free-text world-knowledge "
                    f"guesses. Your webhooks then post strings instead of structured IDs.\n\n"
                    f"Data source URL: {url}\n"
                    f"Matching webhook URL: {matching_webhook['url']}\n"
                    f"Matching webhook auth: {matching_webhook['authorization']}"
                ),
                "answer_this": (
                    f"Set the SAME auth shape on the data source as the webhook already uses. "
                    f"If the webhook uses `{{{{context.authToken}}}}`, the data source should too. "
                    f"If it uses `{{{{secret:sec_xxx}}}}`, match that reference. "
                    f"If for some reason this data source genuinely needs no auth while webhooks to "
                    f"the same host do, document that in the description — otherwise fix it."
                ),
                "then_call": (
                    f"configure_data_source(template_id='{template_id}', name='{name}', "
                    f"auth_type='bearer', auth_token='<paste the same token shape as the webhook>')"
                ),
            })
        elif not is_plausibly_public:
            items.append({
                "severity": "HIGH",
                "field": f"data_source '{name}' → auth",
                "problem": (
                    f"Data source '{name}' has no auth configured (auth_type is None). Almost every "
                    f"production backend rejects unauthenticated requests — the endpoint will 401, "
                    f"but resolve_id treats a failed call as 'no match found' and the agent falls "
                    f"back to world-knowledge guesses. Your webhooks will then post free-text "
                    f"strings instead of structured IDs, silently. You won't see an error surface; "
                    f"you'll just see bad data downstream.\n\n"
                    f"URL: {url or '(unset)'}\n\n"
                    f"auth_type=None is only correct for truly public endpoints "
                    f"(Wikipedia, open data portals, etc.). If your endpoint is behind ANY login, "
                    f"SSO, org scope, or rate-limited API key, you need auth."
                ),
                "answer_this": (
                    f"What authenticates a request to '{name}'? "
                    f"(a) The same user JWT the host page already has → auth_type='bearer' + "
                    f"auth_token='{{{{context.authToken}}}}' (preferred — calls hit the backend AS THE USER). "
                    f"(b) A long-lived service credential → store_secret(name='...') + "
                    f"auth_token='{{{{secret:sec_xxx}}}}' (only when no user session applies). "
                    f"(c) Truly public, no auth → leave as None AND document why in the description."
                ),
                "then_call": (
                    f"configure_data_source(template_id='{template_id}', name='{name}', "
                    f"auth_type='bearer', auth_token='{{{{context.authToken}}}}')"
                ),
            })

    return items


def _interrogate_schema(goal: dict, template_id: str, data_sources: list[dict]) -> list[dict]:
    """Diagnose a goal schema and return blocking questions for any missing reliability fields.

    Called immediately after update_webhook_schema and from check_template.
    """
    gid = goal.get("id", "unknown")
    schema = goal.get("schema", {})
    items = []

    if not schema or not isinstance(schema, dict):
        return items

    # Determine if array schema and get the item schema to walk
    is_array = schema.get("type") == "array"
    field_map = schema.get("item_schema", {}) if is_array else schema

    def _walk_fields(fmap: dict, path_prefix: str = ""):
        for field_name, field_def in fmap.items():
            if not isinstance(field_def, dict):
                continue
            path = f"{path_prefix}{field_name}"
            ftype = field_def.get("type")

            # Resolved-reference fields with a thin description. The Commit Author
            # reads each field's `description` / `prompt` at commit time to decide
            # which resolved value from the conversation goes where. If multiple
            # resolved fields in the same goal have vague descriptions, the author
            # has to guess from position alone — the class of failure that
            # produced the origin/destination mix-up in the carrier incident.
            _desc_text = field_def.get("description") or field_def.get("prompt") or ""
            is_ref_like = ftype == "resolved_reference" or (
                ftype == "array" and field_def.get("item_type") == "resolved_reference"
            )
            if is_ref_like and len(str(_desc_text).strip()) < 20:
                items.append({
                    "severity": "MEDIUM",
                    "field": f"goal '{gid}' → schema.{path} (resolved_reference)",
                    "problem": (
                        f"Field '{path}' has no rich description. At commit time, a dedicated Commit "
                        f"Author LLM reads each field's `description`/`prompt` to decide which resolved "
                        f"value from the conversation belongs in this field. Without clear descriptions "
                        f"on resolved_reference fields — especially when multiple fields in the same goal "
                        f"resolve against the same data source — the author must guess from position. "
                        f"This is the class of bug that maps 'from X to Y' incorrectly across origin / "
                        f"destination fields."
                    ),
                    "answer_this": (
                        f"Write a plain-English description of what '{path}' represents from the user's "
                        f"perspective (not the data source's — the user's). What question would the agent "
                        f"ask to elicit this specific value? How does it differ from sibling fields in "
                        f"the same item?"
                    ),
                    "then_call": (
                        f"Re-call update_webhook_schema with a `description` (or `prompt`) string on the "
                        f"'{path}' field spec."
                    ),
                })

            # resolved_reference without require_resolved
            if ftype == "resolved_reference" and not field_def.get("require_resolved"):
                ds_name = field_def.get("data_source", "(unknown)")
                items.append({
                    "severity": "HIGH",
                    "field": f"goal '{gid}' → schema.{path} (resolved_reference)",
                    "problem": (
                        f"require_resolved is not set. If the '{ds_name}' lookup fails or is ambiguous, "
                        f"this field commits as a plain string. Your webhook receives a string instead "
                        f"of the structured object it expects — silent data corruption."
                    ),
                    "answer_this": (
                        f"Does your downstream endpoint require '{path}' to be a structured object "
                        f"(not a raw string)? If your API would reject or mishandle a string value "
                        f"here, set require_resolved: true."
                    ),
                    "then_call": (
                        f"Re-call update_webhook_schema with require_resolved: true added to the '{path}' field spec."
                    ),
                })

            # resolved_reference without required_before_commit
            if ftype == "resolved_reference" and not field_def.get("required_before_commit"):
                items.append({
                    "severity": "MEDIUM",
                    "field": f"goal '{gid}' → schema.{path} (resolved_reference)",
                    "problem": (
                        f"required_before_commit is not set. A commit can fire with '{path}' missing entirely "
                        f"if the agent never collected it."
                    ),
                    "answer_this": (
                        f"Is '{path}' a required field in your downstream API? "
                        f"Would a commit without it be rejected or stored incorrectly?"
                    ),
                    "then_call": (
                        f"Re-call update_webhook_schema with required_before_commit: true on the '{path}' field if required."
                    ),
                })

            # array with item_type=resolved_reference
            if ftype == "array" and field_def.get("item_type") == "resolved_reference" and not field_def.get("require_resolved"):
                ds_name = field_def.get("data_source", "(unknown)")
                items.append({
                    "severity": "HIGH",
                    "field": f"goal '{gid}' → schema.{path}[] (array of resolved_reference)",
                    "problem": (
                        f"require_resolved is not set on array field '{path}'. "
                        f"Array items that fail '{ds_name}' resolution commit as plain strings. "
                        f"Your webhook receives ['raw string'] instead of [{{id, ...}}]."
                    ),
                    "answer_this": (
                        f"Does your downstream endpoint require each item in '{path}' to be a structured object? "
                        f"If yes, set require_resolved: true."
                    ),
                    "then_call": (
                        f"Re-call update_webhook_schema with require_resolved: true on the '{path}' array field spec."
                    ),
                })

            # recurse into item_schema
            if ftype == "array" and isinstance(field_def.get("item_schema"), dict):
                _walk_fields(field_def["item_schema"], path_prefix=f"{path}[].")

    _walk_fields(field_map, path_prefix="[*]." if is_array else "")

    # Goal-level: missing commit_policy when has resolved_references
    has_resolved = any(
        isinstance(fd, dict) and (
            fd.get("type") == "resolved_reference" or
            (fd.get("type") == "array" and fd.get("item_type") == "resolved_reference")
        )
        for fd in field_map.values()
        if isinstance(fd, dict)
    )
    if has_resolved and not goal.get("commit_policy"):
        items.append({
            "severity": "MEDIUM",
            "field": f"goal '{gid}' → commit_policy",
            "problem": (
                "No commit_policy set. With resolved_reference fields, auto-commits may fire "
                "before all required lookups complete or before the user has confirmed the data."
            ),
            "answer_this": (
                f"For goal '{gid}': should the commit fire automatically once data is collected, "
                f"only after ALL required fields are present, or only after explicit user confirmation? "
                f"Options: 'auto' | 'require_all_required' | 'human_confirm'."
            ),
            "then_call": (
                f"update_goal_commit_rules(template_id='{template_id}', goal_id='{gid}', "
                f"commit_policy='<your choice>')"
            ),
        })

    # Goal-level: multiple resolved_reference fields pointing to the same data source,
    # but no type_agreement invariant declared. This is the single most common source of
    # silent level-mismatch bugs (e.g. origin resolved at metro + destination at
    # municipality). The validator will not enforce agreement unless the template opts in.
    declared_invariants = goal.get("invariants") or []
    has_type_agreement = any(
        isinstance(inv, dict) and inv.get("kind") == "type_agreement"
        for inv in declared_invariants
    )
    ds_to_paths: dict[str, list[str]] = {}
    def _collect_ds_paths(fmap: dict, path_prefix: str = ""):
        for fname, fdef in fmap.items():
            if not isinstance(fdef, dict):
                continue
            p = f"{path_prefix}{fname}"
            ftype = fdef.get("type")
            if ftype == "resolved_reference":
                ds = fdef.get("data_source")
                if ds:
                    ds_to_paths.setdefault(ds, []).append(p)
            elif ftype == "array" and fdef.get("item_type") == "resolved_reference":
                ds = fdef.get("data_source")
                if ds:
                    ds_to_paths.setdefault(ds, []).append(f"{p}[*]")
            if ftype == "array" and isinstance(fdef.get("item_schema"), dict):
                _collect_ds_paths(fdef["item_schema"], path_prefix=f"{p}[*].")
    _collect_ds_paths(field_map, path_prefix="[*]." if is_array else "")
    _shared_ds = {ds: ps for ds, ps in ds_to_paths.items() if len(ps) >= 2}
    if _shared_ds and not has_type_agreement:
        ds_name, paths_list = next(iter(_shared_ds.items()))
        items.append({
            "severity": "MEDIUM",
            "field": f"goal '{gid}' → invariants (type_agreement)",
            "problem": (
                f"Multiple resolved_reference fields ({paths_list}) in goal '{gid}' all resolve "
                f"against data source '{ds_name}', but no `type_agreement` invariant is declared. "
                f"If these fields must resolve at the same category/level (e.g. all metros or all "
                f"municipalities, never a mix), the commit can currently fire with a mismatch. "
                f"This is the validator check that prevents 'metro × municipality' routes from "
                f"shipping — it is opt-in, so without it the check simply does not run."
            ),
            "answer_this": (
                f"Within each item in goal '{gid}', do '{paths_list[0]}' and '{paths_list[1]}' "
                f"(and any other fields resolving against '{ds_name}') need to share the same "
                f"`.type`? If yes, add a type_agreement invariant. If no (they can legitimately "
                f"resolve at different levels), omit it."
            ),
            "then_call": (
                f"update_goal_commit_rules(template_id='{template_id}', goal_id='{gid}', "
                f"invariants=[{{\"kind\": \"type_agreement\", \"paths\": {paths_list}, "
                f"\"key\": \"type\"}}])"
            ),
        })

    # Goal-level: missing invariants when array schema with resolved_references
    if is_array and has_resolved and not goal.get("invariants"):
        items.append({
            "severity": "MEDIUM",
            "field": f"goal '{gid}' → invariants",
            "problem": (
                "Array schema with resolved_reference fields but no cross-field invariants. "
                "If any resolved field depends on a sibling field's value (e.g. a category field determines "
                "which type of product is correct), mismatches will reach your endpoint silently."
            ),
            "answer_this": (
                f"Within each item in goal '{gid}': are there fields that must agree with each other? "
                f"For example, if an item has a 'category' field and a 'product' resolved_reference, "
                f"does category=hardware require product.type=hardware? List any such rules."
            ),
            "then_call": (
                f"update_goal_commit_rules(template_id='{template_id}', goal_id='{gid}', "
                f"invariants=[{{\"when\": {{\"[*].field\": \"value\"}}, \"then\": {{\"[*].other_field\": \"expected_value\"}}}}])"
            ),
        })

    return items


_MCP_INSTRUCTIONS = """\
Roxels MCP — build a working conversational AI integration in ONE shot.

HOW TO USE THIS MCP:
  1. Call get_next_action(template_id) — it tells you the SINGLE next call.
  2. Make that call. Read the response.
  3. The response's `next_action` field contains the exact next call.
  4. Repeat until meta.template_state.score = 100.
  5. Then verify(scope='live_session', template_id=...) once.
  6. Then get_session_diagnostics(session_id) on the result.

DO NOT pick tools yourself unless you know exactly what you're doing —
get_next_action is cheaper and more reliable than scanning docstrings.

IF YOU'RE CONFUSED: ask_roxels(question, template_id) answers freeform
questions with full product + template context. Every answer ends with
a concrete next_action.

WHERE TO START (without a template yet):
  - get_reference(topic='canonical_spec') — what a great Roxels template looks like.
  - list_templates() — find an existing template in your org.
  - setup_by_voice() — have Roxels build a template for you via voice conversation.
  - create_template(name, ...) — create one programmatically.

RESPONSE SHAPE — every tool uses the same envelope:
  {
    status: "ok" | "error" | "pending" | "not_found",
    action: "created" | "updated" | "configured" | ...,
    data: { ... },
    warnings?: [{rule, message, severity}],
    next_action?: {why, call: {tool, args}, call_string},
    meta: {
      mcp_version,
      loop_phase: "primary" | "secondary" | "setup" | "reference" | "utility" | "meta",
      on_recommended_path?: bool,       // False → you went off-script
      recommended_tool?: str,           // The tool get_next_action would have suggested
      template_state?: {score, gaps_remaining, shape_status, has_live_sessions},
      template_id?: str
    }
  }

THREE DISPATCH TOOLS — one name, multiple behaviors via a selector arg:
  - verify(scope, ...)             — 7 scopes, cheap → expensive:
      template_config, webhook_preview, data_source, output,
      http_endpoint, embed_permissions, live_session.
  - integration_shape(action, ...) — 4 actions: read, revise, confirm, propose.
  - get_reference(topic)           — 6 topics: template, data_source, validation,
      embed, id_resolution, canonical_spec.
"""


def create_server(client: RoxelsClient) -> FastMCP:
    """Create and configure the MCP server with all Roxels tools."""
    mcp = FastMCP("roxels", instructions=_MCP_INSTRUCTIONS)

    # ══════════════════════════════════════════════════════════════════════
    # Group 1 — TEMPLATES
    # Create, read, update, delete conversation templates.
    # ══════════════════════════════════════════════════════════════════════

    @mcp.tool()
    async def list_templates(
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
        name_contains: str | None = None,
    ) -> str:
        """List conversation templates in your Roxels organization.

        USE WHEN:
          - You need to find a template to work on but don't have the UUID.
          - You want to audit what's configured across the org.

        Args:
            status: Optional filter — "active", "archived", etc.
            limit: Max results (default 50).
            offset: Pagination offset (default 0).
            name_contains: Optional case-insensitive substring filter on name.
        """
        templates = await client.list_templates()
        if not isinstance(templates, list):
            return _env_ok(data=templates)
        filtered = templates
        if status:
            filtered = [t for t in filtered if t.get("status") == status]
        if name_contains:
            needle = name_contains.lower()
            filtered = [t for t in filtered if needle in (t.get("name") or "").lower()]
        total = len(filtered)
        paged = filtered[offset : offset + limit]
        return _env_ok(
            action="listed",
            data={"count": len(paged), "total_matching": total, "templates": paged},
        )

    @mcp.tool()
    async def list_template_versions(template_id: str) -> str:
        """List every version in the lineage that includes this template id.

        Templates are versioned copy-on-write — admins can clone a template
        into a new inactive version, edit it, test against it, and promote
        when ready. Each lineage has exactly one is_active_version (the row
        that new sessions land on). Sessions stay pinned to whichever
        version they started on, so promoting a new active version does
        not affect in-flight conversations.

        USE WHEN:
          - You want to see the full history of a template.
          - You're trying to figure out which version a session ran on
            (sessions.template_id always points at the specific version
            row, never the lineage root).
          - You're advising a creator on whether to clone-and-test a
            change vs. edit the active version in place.

        Returns each version with: id, name, version_label
        (e.g. "v1", "v2", "haiku trial"), is_active_version (bool),
        version_root_id (the lineage root), created_at, updated_at.

        Args:
            template_id: Any version's UUID in the lineage (root or sibling
                — the response lists all versions either way).
        """
        try:
            versions = await client.list_template_versions(template_id)
        except Exception as exc:
            return _env_error(
                code="list_versions_failed",
                message=f"Could not list versions for template {template_id}: {exc!s}",
            )
        return _env_ok(
            action="listed",
            data={
                "count": len(versions) if isinstance(versions, list) else 0,
                "versions": versions,
            },
        )

    @mcp.tool()
    async def get_template(
        template_id: str,
        fields: list[str] | str | None = None,
    ) -> str:
        """Get full details of a template (goals, settings, outputs, data sources, schemas).

        USE WHEN:
          - You need to see the current state before making a change.
          - You're auditing a template's configuration.

        Args:
            template_id: UUID of the template.
            fields: Optional list (or JSON string) of top-level keys to project.
                E.g. ["id", "name", "goals"] — trims response size.
        """
        template = await client.get_template(template_id)
        if fields:
            parsed = json.loads(fields) if isinstance(fields, str) else fields
            if isinstance(parsed, list):
                template = {k: v for k, v in template.items() if k in parsed}
        return _env_ok(data=template)

    @mcp.tool()
    async def get_setup_conversation(template_id: str) -> str:
        """Retrieve the raw onboarding conversation that created this template.

        Returns every artifact from the setup call that produced this template:
        transcript (verbatim turns + any chat messages), frame captures
        (screenshots the user shared), and any attachments they uploaded.
        Nothing is summarized or interpreted — this is the lossless record of
        what the user actually said they wanted.

        USE THIS WHEN:
          (a) About to make a non-trivial template change — verify your understanding
              matches the user's stated intent before acting.
          (b) check_template surfaces a gap
              whose right fix depends on context only visible in the original
              conversation.
          (c) About to ask the user a clarifying question — check here first;
              they may have already answered it during setup.

        Returns {"status": "no_seed_interview", ...} for templates created outside
        the setup-assistant flow. That is a valid state, not an error.

        Args:
            template_id: UUID of the template
        """
        result = await client.get_setup_conversation(template_id)
        return _env_ok(data=result)

    @mcp.tool()
    async def get_setup_intent(template_id: str) -> str:
        """Return the structured setup intent captured during onboarding.

        When an onboarding session creates a template using a setup-assistant
        template that opted into intent capture (currently: the Embedded
        onboarding template), the backend extracts a structured list of things
        the user asked for — goals, desired outputs, constraints, product
        capabilities, integrations, open questions — plus a free-form prose
        catch-all for anything that didn't fit the structured shape.

        USE THIS WHEN:
          - You want to audit whether the current template actually reflects
            what the user said they wanted (unaddressed items are integration
            gaps that mechanical checks cannot surface).
          - You are deciding whether to configure a new output/goal/skill and
            want to check whether the user asked for it.
          - check_template returned healthy, but you want the third
            layer of convergence: intent-vs-template delta.

        Envelope status values:
          - "no_setup_intent": the setup template didn't opt into intent
            capture, or the template pre-dates the feature. Valid, not an error.
          - "pending": extraction is in-flight (Phase 4 runs as a background
            task after the onboarding webhook returns — typical completion
            20–40s). Call again in a moment.
          - "ok": items[] and notes are populated.
          - "failed": extraction errored out; setup_intent.error has the reason.

        Args:
            template_id: UUID of the template
        """
        result = await client.get_setup_intent(template_id)
        return _env_ok(data=result)

    # ══════════════════════════════════════════════════════════════════════
    # Group 2 — SETUP CONTEXT & INTEGRATION SHAPE
    # Read the onboarding conversation, setup intent, and negotiate the
    # integration shape between what Roxels heard and what the codebase does.
    # ══════════════════════════════════════════════════════════════════════
    #
    # The shape is a LIVING PROPOSAL, not a spec. Roxels drafts it from the
    # setup conversation (which the agent heard with words and sometimes
    # screen share); the coding agent is expected to CHALLENGE and REVISE it
    # using knowledge of the actual codebase (which Roxels has never seen).
    # The MCP keeps the negotiation alive until both sides agree, and only
    # then runs coverage-gap checks against the agreed shape.

    @mcp.tool()
    async def integration_shape(
        template_id: str,
        action: Literal["read", "revise", "confirm", "propose"],
        patch: dict | str | None = None,
        reason: str | None = None,
    ) -> str:
        """Negotiate the integration shape — read, revise, confirm, or re-propose.

        The integration shape is the agreed proposal for where each goal's data
        goes when it commits. Roxels drafts a FIRST proposal from the onboarding
        conversation; your coding agent CHALLENGES it using codebase knowledge.
        Until status='confirmed', check_template keeps this negotiation as the
        top gap — nothing else can be graded until both sides agree.

        USE WHEN:
          - action='read'     — inspect the current proposal (delivery, surfaces,
                                per_goal_expectations, open_questions, revision_log).
          - action='revise'   — change the shape with a codebase-grounded reason.
                                REQUIRES `patch` + `reason`. Each revision is
                                logged so drift from the original proposal is
                                detectable.
          - action='confirm'  — lock in the shape once the codebase matches. This
                                unlocks coverage-gap checks in check_template.
          - action='propose'  — ESCAPE HATCH. Re-draft from scratch by replaying
                                Phase 4+5 extraction on the onboarding transcript.
                                Overwrites both setup_intent and integration_shape;
                                revision_log resets. Use only when the original
                                draft failed or goals changed significantly.

        DELIVERY SURFACES a committed goal can use:
          - "webhook"           — POST to a backend endpoint on commit.
          - "frontend_callback" — event delivered to the embedding page
                                   (onUnderstanding / onComplete).
          - "chained_api"       — captured response feeds a later goal's webhook
                                   (via response_capture).

        STATUS MEANINGS:
          - "confirmed"            — both sides agree; coverage-gap checks active.
          - "proposed_by_roxels"   — Roxels drafted; agent hasn't reviewed yet.
          - "under_revision"       — revisions in progress.

        Args:
            template_id: UUID of the template.
            action:      "read" | "revise" | "confirm" | "propose".
            patch:       REQUIRED for action='revise'. Dict with any of:
                         delivery, surfaces, per_goal_expectations, rationale,
                         open_questions. Top-level keys replace; per_goal_expectations
                         sub-dict merges by goal_id.
            reason:      REQUIRED for action='revise'. Cite the file/endpoint/
                         pattern in the codebase that informed this revision —
                         the thing Roxels didn't know.

        Returns:
            Canonical envelope. Response includes integration_shape + next_steps
            + next_action routing back to check_template.
        """
        meta_common = {"template_id": template_id}

        if action == "read":
            result = await client.get_integration_shape(template_id)
            return _env_ok(
                action="read",
                data=result,
                tool_name="integration_shape",
                loop_phase="setup",
                template_id_for_state=template_id,
                meta=meta_common,
            )

        if action == "revise":
            if patch is None:
                return _env_error(
                    error_message="action='revise' requires `patch`.",
                    hint=(
                        "Pass a dict (or JSON string) with keys like delivery, "
                        "surfaces, per_goal_expectations, rationale, open_questions."
                    ),
                    tool_name="integration_shape",
                    loop_phase="setup",
                    meta=meta_common,
                )
            patch_dict = json.loads(patch) if isinstance(patch, str) else patch
            if not isinstance(patch_dict, dict):
                return _env_error(
                    error_message="patch must be a JSON object.",
                    hint="Keys: delivery / surfaces / per_goal_expectations / rationale / open_questions.",
                    tool_name="integration_shape",
                    loop_phase="setup",
                    meta=meta_common,
                )
            if not reason or not reason.strip():
                return _env_error(
                    error_message="action='revise' requires `reason` (non-empty).",
                    hint=(
                        "Explain WHY the codebase evidence warrants this change — "
                        "e.g. 'Checked web/src/app/leads/page.tsx; UI does not "
                        "consume goal commits, so frontend_callback is unnecessary.'"
                    ),
                    tool_name="integration_shape",
                    loop_phase="setup",
                    meta=meta_common,
                )
            result = await client.revise_integration_shape(template_id, patch_dict, reason.strip())
            shape = result.get("integration_shape", {})
            current = shape.get("current", {})
            remaining = current.get("open_questions") or []
            next_steps = []
            if remaining:
                next_steps.append(
                    f"{len(remaining)} open_questions still unresolved — revise again with "
                    f"codebase evidence, then remove them from open_questions in the patch."
                )
            else:
                next_steps.append(
                    "No open_questions remain. If the current shape matches what your "
                    "codebase can do, call integration_shape(template_id, action='confirm'). "
                    "Only after confirmation will check_template run coverage-gap checks."
                )
            next_steps.append(
                "ITERATE — call check_template(template_id) to see the current gap list. "
                "While status='under_revision', the top item IS the shape negotiation."
            )
            return _env_ok(
                action="revised",
                data={
                    "next_steps": next_steps,
                    "integration_shape": shape,
                },
                next_action_block=_env_next_action(
                    tool="check_template",
                    args={"template_id": template_id},
                    why="See updated gap list; shape revision may have changed coverage.",
                ),
                tool_name="integration_shape",
                loop_phase="setup",
                template_id_for_state=template_id,
                meta=meta_common,
            )

        if action == "confirm":
            result = await client.confirm_integration_shape(template_id)
            return _env_ok(
                action="confirmed",
                data={
                    "integration_shape": result.get("integration_shape"),
                    "next_steps": [
                        "Run check_template(template_id) — coverage-gap checks are now active.",
                        "If a coverage gap surfaces that requires revisiting the shape "
                        "(e.g. 'orphan goal' for a goal you meant to leave unused), "
                        "call integration_shape(action='revise') to update, then confirm again.",
                    ],
                },
                next_action_block=_env_next_action(
                    tool="check_template",
                    args={"template_id": template_id},
                    why="Coverage-gap checks just unlocked — see the full gap list now.",
                ),
                tool_name="integration_shape",
                loop_phase="setup",
                template_id_for_state=template_id,
                meta=meta_common,
            )

        if action == "propose":
            try:
                result = await client.extract_setup_intent_now(template_id)
            except Exception as e:
                return _env_error(
                    error_message="Propose failed — backend couldn't draft a shape.",
                    details=str(e),
                    hint=(
                        "This happens when the backend can't complete Phase 5 extraction "
                        "(rare — usually an LLM or network issue). Try again; if it keeps "
                        "failing, skip shape negotiation and call check_template directly — "
                        "coverage-gap checks will stay dormant but other gaps still surface."
                    ),
                    next_action_block=_env_next_action(
                        tool="check_template",
                        args={"template_id": template_id},
                        why="Propose is failing. Proceed without shape for now — check_template still gives you the actionable gap list.",
                    ),
                    tool_name="integration_shape",
                    loop_phase="setup",
                    meta=meta_common,
                )
            shape_status = result.get("integration_shape_status") if isinstance(result, dict) else None
            # Phase 5 wraps its own failure into a "draft_failed: ..." string.
            # Surface that as a real error so the agent knows.
            if isinstance(shape_status, str) and shape_status.startswith("draft_failed"):
                return _env_error(
                    error_message=f"Shape draft failed: {shape_status.removeprefix('draft_failed: ').strip()}",
                    hint=(
                        "The backend's Phase 5 draft errored. Skip shape negotiation "
                        "and call check_template directly — you'll still get the full "
                        "gap list minus the shape-coverage checks."
                    ),
                    next_action_block=_env_next_action(
                        tool="check_template",
                        args={"template_id": template_id},
                        why="Shape draft failed; proceed without shape via check_template.",
                    ),
                    tool_name="integration_shape",
                    loop_phase="setup",
                    template_state={"shape_status": None} if result is None else None,
                    meta=meta_common,
                )
            if not shape_status:
                # Empty / missing shape_status = the backend call succeeded but
                # didn't produce a shape. Treat as error.
                return _env_error(
                    error_message="Propose returned no shape_status.",
                    details=json.dumps(result, default=str)[:500] if result else "(empty backend response)",
                    hint=(
                        "The backend responded but did not draft a shape. This usually "
                        "means the source session is unreachable AND the template-only "
                        "fallback also couldn't produce a proposal. Call check_template "
                        "directly to proceed without a shape."
                    ),
                    next_action_block=_env_next_action(
                        tool="check_template",
                        args={"template_id": template_id},
                        why="No shape was produced; proceed without one via check_template.",
                    ),
                    tool_name="integration_shape",
                    loop_phase="setup",
                    meta=meta_common,
                )
            transcript_available = result.get("transcript_available", True) if isinstance(result, dict) else True
            note = (
                ""
                if transcript_available
                else " (Drafted from template goals + outputs alone — source onboarding transcript was unavailable. Revise against the codebase.)"
            )
            return _env_ok(
                action="proposed",
                data={
                    "shape_status": shape_status,
                    "shape_generation_ms": result.get("integration_shape_generation_ms"),
                    "intent_items": result.get("items_count"),
                    "transcript_available": transcript_available,
                    "note": note.strip() or None,
                    "next_steps": [
                        f"Read the new proposal: integration_shape(template_id='{template_id}', action='read').",
                        "Compare against the actual codebase and either revise or confirm.",
                    ],
                },
                next_action_block=_env_next_action(
                    tool="integration_shape",
                    args={"template_id": template_id, "action": "read"},
                    why="A fresh proposal was drafted — read it before acting on it.",
                ),
                tool_name="integration_shape",
                loop_phase="setup",
                template_id_for_state=template_id,
                meta=meta_common,
            )

        return _env_error(
            error_message=f"Unknown action '{action}'.",
            hint="Valid actions: 'read', 'revise', 'confirm', 'propose'.",
            tool_name="integration_shape",
            loop_phase="setup",
            meta=meta_common,
        )

    @mcp.tool()
    async def ask_roxels(question: str, template_id: str | None = None) -> str:
        """Ask an expert Roxels Q&A assistant a free-form question.

        This is the convergence-loop natural-language surface. Use it when the
        other MCP tools' structured outputs don't cover your question, or when
        you need an opinion rather than a specification.

        The assistant has rich context:
          - The full Roxels product-capabilities document.
          - The complete-template spec (get_reference(topic='canonical_spec')).
          - The schema reference for outputs, goals, data sources.
          - When template_id is supplied: this template's current state,
            runtime learnings, and the onboarding transcript that created it.

        Good questions include:
          - "How should I decide between a per-goal webhook and an
             end-of-session webhook for this template?"
          - "Why does this data source need `cache_key_fields` set?"
          - "What's the right way to embed Roxels on a page served by
             Cloudflare if Permissions-Policy is restrictive?"
          - "Based on the onboarding transcript, did the user ask for any
             outputs we haven't configured yet?"
          - "Is there a Roxels-native way to do X, or do I need back-end code?"

        Every answer ends with a concrete next action. The Q&A is persisted
        server-side (org-scoped) so the platform can see what's confusing coding
        agents and improve docs/tools over time.

        Args:
            question: your free-form question
            template_id: optional — scopes the answer to a specific template;
                         the assistant will see its state, learnings, and
                         onboarding transcript.
        """
        result = await client.ask_roxels(question, template_id=template_id)
        return _env_ok(data=result)

    @mcp.tool()
    async def get_runtime_learnings(template_id: str) -> str:
        """Return a human-readable summary of what the system has learned from live conversation sessions.

        Shows two types of learnings:
          1. Data source learnings — resolved examples (phrase → result) and synthesized
             do/don't rules for each configured data source.
          2. Webhook output learnings — do/don't rules derived from successful and failed
             webhook POST observations.

        HOW LEARNINGS WORK: after each webhook terminal outcome (success, max retries reached,
        or fatal error), the platform synthesizes rules from the HTTP observation and stores them
        on the template. On the next session, these rules are injected into attempt 1 — so a
        payload mistake that caused a retry in session N is already fixed before the first request
        in session N+1. Data source learned rules are similarly injected into both the
        query-generation step and the candidate-evaluation step automatically.

        Also returns suggested_actions: concrete MCP calls to consider making based on
        what has been learned. Use these to update the template configuration so that
        future sessions benefit from the learnings without relying on runtime injection.

        Args:
            template_id: UUID of the template
        """
        template = await client.get_template(template_id)
        settings_data = template.get("settings", {})
        goals = template.get("goals", [])
        learnings = template.get("learnings") or {}
        if isinstance(learnings, str):
            try:
                learnings = json.loads(learnings)
            except Exception:
                learnings = {}

        data_sources = settings_data.get("data_sources", [])
        outputs_config = settings_data.get("outputs", [])

        ds_learnings = learnings.get("data_sources", {})
        output_learnings = learnings.get("outputs", {})

        # Build structured data source section
        ds_section = {}
        for src in data_sources:
            src_name = src.get("name", "<unnamed>")
            src_entry = ds_learnings.get(src_name, {})
            examples = src.get("examples", [])
            ds_section[src_name] = {
                "examples_count": len(examples),
                "recent_example_phrases": [ex.get("phrase") for ex in examples[-5:] if ex.get("phrase")],
                "learned_rules": src_entry.get("_learned_rules", {"do": [], "dont": []}),
                "rules_last_synthesized": src_entry.get("_rules_last_synthesized"),
            }

        # Build structured webhook output section
        webhook_outputs = []
        for i, output in enumerate(outputs_config):
            if output.get("type") != "webhook":
                continue
            config = output.get("config", {})
            out_entry = output_learnings.get(str(i), {})
            webhook_outputs.append({
                "index": i,
                "url": config.get("url", ""),
                "trigger_goal": config.get("trigger_goal"),
                "learned_rules": out_entry.get("_learned_rules", {"do": [], "dont": []}),
                "rules_last_synthesized": out_entry.get("_rules_last_synthesized"),
            })

        # Build suggested_actions from what has been learned
        suggested_actions = []
        for src_name, src_data in ds_section.items():
            dont_rules = src_data["learned_rules"].get("dont", [])
            if dont_rules:
                suggested_actions.append({
                    "reason": (
                        f"'{src_name}' has {len(dont_rules)} don't rule(s) from live sessions. "
                        f"Consider updating canonicalization_rules or examples to bake these insights "
                        f"into the template config so they work even when LEARNINGS_ENABLED=false."
                    ),
                    "call": (
                        f"configure_data_source(template_id='{template_id}', name='{src_name}', "
                        f"canonicalization_rules='...<incorporate dont rules>...')"
                    ),
                })
            if src_data["examples_count"] > 0 and not src_data["learned_rules"].get("do") and not src_data["learned_rules"].get("dont"):
                suggested_actions.append({
                    "reason": (
                        f"'{src_name}' has accumulated {src_data['examples_count']} resolved examples "
                        f"but no synthesized rules yet. Consider running a test conversation with intentional "
                        f"failures to surface don't rules that can be acted on."
                    ),
                    "call": f"probe_data_source(template_id='{template_id}', source_name='{src_name}', params={{\"search\": \"<ambiguous phrase>\"}})",
                })

        for wh in webhook_outputs:
            dont_rules = wh["learned_rules"].get("dont", [])
            if dont_rules:
                suggested_actions.append({
                    "reason": (
                        f"Webhook output {wh['index']} ({wh['url']}) has {len(dont_rules)} don't rule(s). "
                        f"Review the rules and consider updating the goal schema or webhook config "
                        f"to prevent these payload errors at the source."
                    ),
                    "call": (
                        f"update_webhook_schema(template_id='{template_id}', goal_id='<goal_id>', "
                        f"schema={{...updated to prevent known payload errors...}})"
                    ),
                })

        # Build human-readable summary
        template_name = template.get("name", "Unknown Template")
        summary_lines = [f"# Runtime Learnings — {template_name}\n"]

        if ds_section:
            summary_lines.append("## Data Sources\n")
            for src_name, src_data in ds_section.items():
                summary_lines.append(f"### {src_name}")
                summary_lines.append(f"- Examples accumulated: {src_data['examples_count']}")
                if src_data["recent_example_phrases"]:
                    summary_lines.append(f"- Recent phrases: {', '.join(repr(p) for p in src_data['recent_example_phrases'])}")
                do_rules = src_data["learned_rules"].get("do", [])
                dont_rules = src_data["learned_rules"].get("dont", [])
                if do_rules:
                    summary_lines.append("- DO rules:")
                    for r in do_rules:
                        summary_lines.append(f"  ✓ {r}")
                if dont_rules:
                    summary_lines.append("- DON'T rules:")
                    for r in dont_rules:
                        summary_lines.append(f"  ✗ {r}")
                if not do_rules and not dont_rules:
                    summary_lines.append("- No rules synthesized yet")
                summary_lines.append("")

        if webhook_outputs:
            summary_lines.append("## Webhook Outputs\n")
            for wh in webhook_outputs:
                summary_lines.append(f"### Output {wh['index']}: {wh['url']}")
                do_rules = wh["learned_rules"].get("do", [])
                dont_rules = wh["learned_rules"].get("dont", [])
                if do_rules:
                    summary_lines.append("- DO rules:")
                    for r in do_rules:
                        summary_lines.append(f"  ✓ {r}")
                if dont_rules:
                    summary_lines.append("- DON'T rules:")
                    for r in dont_rules:
                        summary_lines.append(f"  ✗ {r}")
                if not do_rules and not dont_rules:
                    summary_lines.append("- No rules synthesized yet")
                summary_lines.append("")

        if not ds_section and not webhook_outputs:
            summary_lines.append("No data sources or webhook outputs configured.\n")
        elif not any(
            src["examples_count"] > 0 or src["learned_rules"].get("do") or src["learned_rules"].get("dont")
            for src in ds_section.values()
        ) and not any(
            wh["learned_rules"].get("do") or wh["learned_rules"].get("dont")
            for wh in webhook_outputs
        ):
            summary_lines.append("_No learnings accumulated yet. Run live conversations to build up the knowledge base._\n")

        return _env_ok(data={
            "summary": "\n".join(summary_lines),
            "data_sources": ds_section,
            "webhook_outputs": webhook_outputs,
            "suggested_actions": suggested_actions,
        })

    @mcp.tool()
    async def clear_runtime_learnings(
        template_id: str,
        scope: Literal["all", "data_sources", "webhooks", "one_source"] = "all",
        data_source_name: str | None = None,
    ) -> str:
        """Clear accumulated runtime learnings for a template.

        Use this when you've made structural changes to the template (new data source
        config, fixed endpoint params, updated schema) and want to start fresh so
        stale rules from the old config don't contaminate future sessions.

        IMPORTANT: This only clears the learnings column — it does NOT clear the
        'examples' list inside settings.data_sources. To clear accumulated examples
        you must update the template settings directly via update_template.

        Args:
            template_id: UUID of the template
            scope: What to clear. One of:
              "all" — clear all learnings (data sources + webhook outputs)
              "data_sources" — clear only data source rules
              "webhooks" — clear only webhook output rules
              "one_source" — clear rules for one data source; pass data_source_name
            data_source_name: Required when scope='one_source'. The data source name.
        """
        template = await client.get_template(template_id)
        learnings = template.get("learnings") or {}
        if isinstance(learnings, str):
            try:
                learnings = json.loads(learnings)
            except Exception:
                learnings = {}

        if scope == "all":
            learnings = {}
            cleared = "all learnings"
        elif scope == "data_sources":
            learnings.pop("data_sources", None)
            cleared = "all data source learnings"
        elif scope == "webhooks":
            learnings.pop("outputs", None)
            cleared = "all webhook output learnings"
        elif scope == "one_source":
            if not data_source_name:
                return _env_error(
                    error_message="scope='one_source' requires data_source_name argument.",
                    hint="Pass data_source_name='<name>' — see list_data_sources for known names.",
                )
            ds_section = learnings.get("data_sources", {})
            if data_source_name in ds_section:
                del ds_section[data_source_name]
                learnings["data_sources"] = ds_section
                cleared = f"learnings for data source '{data_source_name}'"
            else:
                return _env_not_found(
                    resource="data source learnings",
                    identifier=data_source_name,
                    hint=f"Known data sources: {list(ds_section.keys())}",
                )

        await client.update_template(template_id, {"learnings": learnings})
        return _env_ok(
            action="cleared",
            data={"cleared": cleared},
            meta={"template_id": template_id},
        )

    @mcp.tool()
    async def create_template(
        name: str,
        description: str = "",
        goals: list | str = "[]",
        settings: dict | str = "{}",
    ) -> str:
        """Create a new conversation template programmatically.

        For complex templates, consider using setup_by_voice instead —
        it opens a voice conversation with the AI setup assistant that builds the
        template for you.

        Args:
            name: Template name (e.g. "Customer Onboarding")
            description: Internal description (not shown during conversations)
            goals: Array of goal objects, or JSON string. Use get_reference(topic='template') to see valid goal types and fields.
            settings: Settings object, or JSON string. Use get_reference(topic='template') to see valid fields.

        After running test conversations, use get_template_recent_sessions(template_id)
        to see a health overview of recent sessions and spot any failures.
        get_session_diagnostics(session_id) drills into any individual session with
        suggested fixes — especially useful for templates with webhooks or complex
        multi-goal flows.
        """
        parsed_settings = json.loads(settings) if isinstance(settings, str) else (settings or {})
        data = {
            "name": name,
            "description": description,
            "goals": json.loads(goals) if isinstance(goals, str) else goals,
            "settings": parsed_settings,
        }
        result = await client.create_template(data)
        return _format_template_result_with_warnings(result, action="created")

    @mcp.tool()
    async def update_template(
        template_id: str,
        name: str | None = None,
        description: str | None = None,
        goals: list | str | None = None,
        settings: dict | str | None = None,
        status: str | None = None,
    ) -> str:
        """Update an existing template's fields.

        REPLACEMENT SEMANTICS — read before calling:
          - name, description, status: scalar overwrite. Omit to leave unchanged.
          - goals:    REPLACES the entire goals array. Every goal must be included —
                      omitted goals are deleted. Pass None to leave goals unchanged.
                      IMPORTANT: each goal's `schema` is the canonical contract the
                      agent runtime enforces against. If you're updating goals for
                      reasons other than schema (e.g. prompt edits) and you pass a
                      goal object without `schema`, the schema is wiped. Always
                      include the existing schema (fetch via get_template) when
                      replacing goals, or use update_webhook_schema for schema
                      changes.
          - settings: REPLACES the entire settings object including all outputs and config.
                      To make a partial change: fetch current settings with get_template,
                      merge your change into the full object, pass the merged result.
                      NOTE: Webhook output schemas (set via update_webhook_schema) are
                      auto-preserved by the MCP through this replacement — they survive
                      update_template automatically. All other settings fields are replaced.

        For every update_template call, run check_template(template_id) after to
        confirm no gaps were introduced. goals and settings are replaced wholesale — webhook
        output schemas are the ONLY thing auto-preserved. Everything else (outputs,
        data_sources, config, skills, goal-level schemas) must be passed in full or it
        will be lost.

        Args:
            template_id: UUID of the template to update
            name: New template name
            description: New description
            goals: New goals array (or JSON string) — REPLACES all existing goals
            settings: New settings object (or JSON string) — REPLACES all settings
                      (webhook output schemas are auto-preserved, everything else replaced)
            status: "active" or "archived"
        """
        data = {}
        if name is not None:
            data["name"] = name
        if description is not None:
            data["description"] = description
        warnings_goal_schema: list[str] = []
        if goals is not None:
            parsed_goals = json.loads(goals) if isinstance(goals, str) else goals
            data["goals"] = parsed_goals
            # Goals with a `schema` set directly on the goal object are CANONICAL.
            # The agent runtime reads the contract from `template.goals[].schema`
            # first; the webhook output's config.schema is only a fallback. No
            # warning needed — declaring schema on the goal is the recommended
            # shape. We surface a hint instead if a goal declares schema and there
            # is no matching webhook output, since the wire delivery side is then
            # missing.
        if settings is not None:
            parsed_settings = json.loads(settings) if isinstance(settings, str) else settings
            # Reject raw secrets in any webhook output headers
            for out in (parsed_settings.get("outputs") or []):
                if out.get("type") == "webhook":
                    for hval in (out.get("config", {}).get("headers") or {}).values():
                        if _looks_like_raw_secret(str(hval)):
                            return _env_error(
                                error_message="Raw credential detected in webhook output header.",
                                hint=(
                                    "Call store_secret(name='<descriptive name>') first, then use "
                                    "the returned {{secret:ref}} as the header value. "
                                    "This keeps the credential out of this conversation and any logs."
                                ),
                                next_action_block=_env_next_action(
                                    tool="store_secret",
                                    args={"name": "<descriptive name>"},
                                    why="Store the credential securely before referencing it in headers.",
                                ),
                            )
            data["settings"] = parsed_settings

        # Auto-preserve schemas (both the canonical goal.schema and the webhook
        # output config.schema mirror) across update_template calls. Either is
        # easy to wipe by accident: the setup assistant typically calls this with
        # `goals` to update prompts (so goal.schema gets cleared) or with
        # `settings` to update outputs (so the webhook mirror gets cleared).
        # Snapshot both before the write, restore any that come back empty.
        needs_schema_preserve = goals is not None or (
            settings is not None and "outputs" in (
                json.loads(settings) if isinstance(settings, str) else settings
            )
        )
        webhook_schema_snapshot: dict[str, dict] = {}  # by trigger_goal
        goal_schema_snapshot: dict[str, dict] = {}  # by goal_id
        if needs_schema_preserve:
            try:
                current = await client.get_template(template_id)
                for out in current.get("settings", {}).get("outputs", []):
                    if out.get("type") == "webhook":
                        tg = out.get("config", {}).get("trigger_goal")
                        sc = out.get("config", {}).get("schema")
                        if tg and sc:
                            webhook_schema_snapshot[tg] = sc
                for g in current.get("goals", []) or []:
                    if isinstance(g, dict) and g.get("id") and isinstance(g.get("schema"), dict) and g["schema"]:
                        goal_schema_snapshot[g["id"]] = g["schema"]
            except Exception:
                pass

        if status is not None:
            data["status"] = status
        result = await client.update_template(template_id, data)

        # Re-apply any schemas (both layers) that were wiped by the replacement.
        if webhook_schema_snapshot or goal_schema_snapshot:
            try:
                updated = await client.get_template(template_id)
                restored_webhooks: list[str] = []
                restored_goals: list[str] = []
                # Restore goal-level schemas
                updated_goals = updated.get("goals", []) or []
                for g in updated_goals:
                    if not isinstance(g, dict) or not g.get("id"):
                        continue
                    if g["id"] in goal_schema_snapshot and not (isinstance(g.get("schema"), dict) and g["schema"]):
                        g["schema"] = goal_schema_snapshot[g["id"]]
                        restored_goals.append(g["id"])
                # Restore webhook-level schemas (mirror)
                for out in updated.get("settings", {}).get("outputs", []):
                    if out.get("type") == "webhook":
                        tg = out.get("config", {}).get("trigger_goal")
                        if tg and tg in webhook_schema_snapshot and not out.get("config", {}).get("schema"):
                            out.setdefault("config", {})["schema"] = webhook_schema_snapshot[tg]
                            restored_webhooks.append(tg)
                if restored_goals or restored_webhooks:
                    payload = {}
                    if restored_goals:
                        payload["goals"] = updated_goals
                    if restored_webhooks:
                        payload["settings"] = updated.get("settings", {})
                    await client.update_template(template_id, payload)
                    result = await client.get_template(template_id)
                    notes: list[str] = []
                    if restored_goals:
                        notes.append(f"goal.schema restored for: {restored_goals}")
                    if restored_webhooks:
                        notes.append(f"webhook output schema restored for: {restored_webhooks}")
                    result["mcp_note"] = (
                        "Schemas auto-preserved through this update_template call — "
                        + "; ".join(notes)
                    )
            except Exception:
                pass

        if warnings_goal_schema:
            result.setdefault("warnings", [])
            result["warnings"] = [{"rule": "deprecated_fields", "message": w} for w in warnings_goal_schema] + result["warnings"]
        return _format_template_result_with_warnings(result, action="updated")

    @mcp.tool()
    async def setup_by_voice(context: str = "") -> str:
        """Create a template by having a voice conversation with the Roxels AI setup assistant.

        This opens your browser to a voice conversation where the AI asks you about
        what you want to build — whose conversations you'll run, what data to collect, what
        tone to use, etc. When the conversation finishes, the template is
        automatically created.

        This is the recommended way to create templates. It's faster and produces
        better results than filling in fields manually.

        This tool will block until the conversation is complete (up to 30 minutes).

        Args:
            context: Optional hint for the setup assistant about what you want to build
                     (e.g. "customer satisfaction survey for a logistics company")
        """
        session = await client.start_setup_assistant()
        join_url = session["join_url"]
        interview_id = str(session["interview_id"])

        _validate_join_url(join_url)
        webbrowser.open(join_url)

        timeout = 30 * 60  # 30 minutes
        poll_interval = 5
        elapsed = 0

        while elapsed < timeout:
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

            interview = await client.get_interview(interview_id)
            interview_status = interview.get("status", "")

            if interview_status == "completed":
                ctx = interview.get("context", {})
                created_template_id = ctx.get("created_template_id")

                if created_template_id:
                    template = await client.get_template(str(created_template_id))
                    return _env_ok(
                        action="completed",
                        data={
                            "template_id": str(created_template_id),
                            "template": template,
                            "interview_id": interview_id,
                        })
                else:
                    return _env_error(
                        error_message="Conversation completed but no template was created.",
                        hint="Check the conversation results via get_interview.",
                        meta={"interview_id": interview_id},
                    )

            if interview_status == "processing_failed":
                return _env_error(
                    error_message="Conversation processing failed.",
                    hint="You can try create_template to build one programmatically.",
                    meta={"interview_id": interview_id},
                )

        return _env_pending(
            message=(
                f"Setup conversation was not completed within {timeout // 60} minutes. "
                f"You can rejoin at: {join_url}"
            ),
            meta={"interview_id": interview_id, "join_url": join_url},
        )

    @mcp.tool()
    async def modify_by_voice(template_id: str) -> str:
        """Modify an existing template by having a voice conversation with the AI.

        Opens your browser to a conversation where you can describe what you want
        to change. The AI knows the current template configuration and will update
        it based on your instructions.

        This tool will block until the conversation is complete (up to 30 minutes).

        Args:
            template_id: UUID of the template to modify
        """
        session = await client.start_modify_assistant(template_id)
        join_url = session["join_url"]
        interview_id = str(session["interview_id"])

        _validate_join_url(join_url)
        webbrowser.open(join_url)

        timeout = 30 * 60
        poll_interval = 5
        elapsed = 0

        while elapsed < timeout:
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

            interview = await client.get_interview(interview_id)
            interview_status = interview.get("status", "")

            if interview_status == "completed":
                template = await client.get_template(template_id)
                return _env_ok(
                    action="completed",
                    data={
                        "template_id": template_id,
                        "template": template,
                        "interview_id": interview_id,
                    })

            if interview_status == "processing_failed":
                return _env_error(
                    error_message="Modification failed.",
                    hint="You can use update_template to make changes programmatically.",
                    meta={"interview_id": interview_id},
                )

        return _env_ok(

            action="timeout",

            data={
                "message": f"Modify session was not completed within {timeout // 60} minutes. "
                f"You can rejoin at: {join_url}",
                "interview_id": interview_id,
                "join_url": join_url,
            })

    # ══════════════════════════════════════════════════════════════════════
    # Group 3 — SESSIONS & PARTICIPANTS
    # Read conversation-level records and the persons who participate.
    # ══════════════════════════════════════════════════════════════════════

    @mcp.tool()
    async def list_interviews(
        template_id: str | None = None,
        person_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> str:
        """List conversations (interview-level records) with optional filters.

        In the Roxels data model, an "interview" is the top-level conversation
        record. Each interview contains one or more sessions (separate calls).
        The `interview_id` is the stable URL / code identifier; the user-facing
        noun is "conversation."

        Args:
            template_id: Filter by template UUID
            person_id: Filter by person UUID
            status: Filter by status — "not_started", "in_progress", "processing", "completed", "processing_failed"
            limit: Max results (1-200, default 50)
            offset: Pagination offset
        """
        interviews = await client.list_interviews(
            template_id=template_id,
            person_id=person_id,
            status=status,
            limit=limit,
            offset=offset,
        )
        return _env_ok(data=interviews)

    @mcp.tool()
    async def get_interview(interview_id: str) -> str:
        """Get full conversation results including summary, structured findings, outputs, transcript, and attached files.

        Args:
            interview_id: UUID of the conversation (URL / code identifier; user-facing noun is "conversation")
        """
        interview = await client.get_interview(interview_id)
        return _env_ok(data=interview)

    @mcp.tool()
    async def list_persons() -> str:
        """List all persons (conversation participants) in your organization."""
        persons = await client.list_persons()
        return _env_ok(data=persons)

    @mcp.tool()
    async def create_person(
        name: str,
        email: str | None = None,
        phone: str | None = None,
        metadata: dict | str = "{}",
    ) -> str:
        """Create a person record. Persons are the conversation participants.

        Args:
            name: Full name
            email: Email address (used for deduplication)
            phone: Phone number
            metadata: Arbitrary key-value metadata (object or JSON string)
        """
        data: dict = {"name": name, "metadata": json.loads(metadata) if isinstance(metadata, str) else metadata}
        if email is not None:
            data["email"] = email
        if phone is not None:
            data["phone"] = phone
        result = await client.create_person(data)
        return _env_ok(data=result)

    # ══════════════════════════════════════════════════════════════════════
    # Group 4 — OUTPUTS, SCHEMAS, DATA SOURCES, EMBEDDING
    # Configure what happens with committed data (webhooks, structured
    # extraction), set extraction schemas, register data sources, mint
    # embed keys. The bulk of a template's wiring lives here.
    # ══════════════════════════════════════════════════════════════════════

    @mcp.tool()
    async def configure_output(
        template_id: str,
        output_type: Literal["webhook", "structured", "report", "email", "excel"],
        config: dict | str,
        replace: bool = True,
        match_trigger_goal: str | None = None,
    ) -> str:
        """Add, replace, or merge-update an output on a template.

        Outputs define what happens with committed conversation data: webhooks POST
        to your backend, structured extraction writes JSON, reports/emails/excel
        produce artifacts.

        USE WHEN:
          - Adding a new output:       `configure_output(template_id, output_type, config)`.
          - Fully replacing an output: `configure_output(..., replace=True)` (default).
          - Merge-updating one field on an existing output:
            `configure_output(..., match_trigger_goal='g1', replace=False, config={'url': 'new'})`.
            Only fields present in `config` are changed; omitted fields stay put.

        ⚠️ CAUTION — SECRETS: raw API keys in headers are rejected. Call
        store_secret(name=...) first, then use {{secret:uuid}} in headers. For
        user-session calls use {{context.authToken}} instead. See
        get_reference(topic='canonical_spec') for the full auth + chained-webhook + retry
        reference.

        Args:
            template_id: UUID of the template.
            output_type: "webhook" | "structured" | "report" | "email" | "excel".
            config: Output config dict (or JSON string). For webhook, see
                get_reference(topic='template') → output_types.webhook.config.
            replace: If true (default), replaces any existing output of the same
                type. If false and match_trigger_goal is set, merges the provided
                fields into the matched output. If false and no match, the output
                is ADDED alongside existing outputs.
            match_trigger_goal: When provided, target the output with this
                trigger_goal for either replace or merge. Required when there are
                multiple per-goal webhooks and you want to update a specific one.

        Returns:
            Canonical envelope with action="configured" | "replaced" | "patched".
        """
        config_dict = json.loads(config) if isinstance(config, str) else config

        # Reject raw secret values in webhook headers — they must go through store_secret
        if output_type == "webhook":
            for header_val in (config_dict.get("headers") or {}).values():
                if _looks_like_raw_secret(str(header_val)):
                    return _env_error(
                        error_message="Raw credential detected in header value.",
                        hint=(
                            "Call store_secret(name='<descriptive name>') first, then use "
                            "the returned {{secret:ref}} as the header value. "
                            "This keeps the credential out of this conversation and any logs."
                        ),
                        next_action_block=_env_next_action(
                            tool="store_secret",
                            args={"name": "<descriptive name>"},
                            why="Store the credential securely before referencing it in headers.",
                        ),
                    )

        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        outputs = settings.get("outputs", [])

        # Merge-update path: match_trigger_goal set and replace=False → patch semantics
        if match_trigger_goal is not None and not replace:
            target = next(
                (o for o in outputs
                 if o.get("type") == output_type
                 and o.get("config", {}).get("trigger_goal") == match_trigger_goal),
                None,
            )
            if target is None:
                return _env_not_found(
                    resource=f"{output_type} output",
                    identifier=f"trigger_goal='{match_trigger_goal}'",
                    hint=(
                        "No output matches that trigger_goal. To CREATE a new output "
                        "for this goal, call configure_output without match_trigger_goal "
                        "(or with replace=True and trigger_goal in config)."
                    ),
                    next_action_block=_env_next_action(
                        tool="get_template",
                        args={"template_id": template_id, "fields": ["settings"]},
                        why="Inspect existing outputs to find the right trigger_goal.",
                    ),
                    meta={"template_id": template_id},
                )
            merged_config = {**target.get("config", {}), **config_dict}
            outputs = [o for o in outputs if o is not target]
            outputs.append({**target, "config": merged_config})
            settings["outputs"] = outputs
            result = await client.update_template(template_id, {"settings": settings})
            return _env_ok(
                action="patched",
                data={
                    "template_id": template_id,
                    "output_type": output_type,
                    "matched_trigger_goal": match_trigger_goal,
                    "updated_fields": list(config_dict.keys()),
                    "template": result,
                },
                next_action_block=_env_next_action(
                    tool="check_template",
                    args={"template_id": template_id},
                    why="Verify the patch didn't introduce gaps and see the new readiness score.",
                ),
                tool_name="configure_output",
                loop_phase="primary",
                template_id_for_state=template_id,
                meta={"template_id": template_id},
            )

        # Replace or add path
        new_output = {"type": output_type, "config": config_dict}

        if replace:
            if match_trigger_goal is not None:
                # Replace specifically the matched output
                outputs = [
                    o for o in outputs
                    if not (o.get("type") == output_type
                            and o.get("config", {}).get("trigger_goal") == match_trigger_goal)
                ]
            else:
                outputs = [o for o in outputs if o.get("type") != output_type]

        outputs.append(new_output)
        settings["outputs"] = outputs

        result = await client.update_template(template_id, {"settings": settings})

        # ── Convergence loop: every configure_output nudges the caller toward iteration.
        # Saved configs are almost never complete on the first try. The MCP's job is to
        # keep the coding agent iterating — add info, diagnose, fill gaps, repeat — until
        # check_template returns 'healthy'. Do not let the agent treat a successful
        # save as "done."
        next_steps = []
        if output_type == "webhook":
            cfg = config_dict
            has_trigger = bool(cfg.get("trigger_goal"))
            has_schema = bool(cfg.get("schema"))
            has_body_template = bool(cfg.get("body_template"))
            next_steps.append(
                f"ITERATE — call check_template(template_id='{template_id}') now. "
                f"It will list remaining gaps (orphan trigger_goals, missing required fields, "
                f"resolved_reference fields without data sources, extraction_mode drift, "
                f"schema/body_template mismatches, webhook coverage per goal, etc.). "
                f"Fix each gap, then call it AGAIN. Keep iterating until it returns status='healthy'."
            )
            next_steps.append(
                f"VERIFY — call send_http_request(template_id='{template_id}'"
                + (f", trigger_goal='{cfg.get('trigger_goal')}'" if has_trigger else "")
                + ") with a realistic sample payload. Read the full response body — catch auth "
                "errors, content-type mismatches, missing-field errors, and wrong field names NOW, "
                "not in the first live session."
            )
            if not has_trigger:
                next_steps.append(
                    "SHAPE WARNING — this webhook has no trigger_goal, so it fires only at "
                    "end-of-session. Unless the receiver explicitly needs one combined payload, "
                    "set trigger_goal=<goal_id> and add one webhook per goal. See get_reference(topic='template') "
                    "→ output_types.webhook for the decision heuristic."
                )
            if has_trigger and not has_schema and not has_body_template:
                next_steps.append(
                    "SHAPE GAP — this per-goal webhook has neither schema nor body_template. "
                    "Without a schema the extraction model has nothing to anchor on; without a "
                    "body_template the payload defaults to an envelope. Add at least one."
                )
            if cfg.get("response_capture"):
                next_steps.append(
                    "CHAIN CHECK — you configured response_capture. Verify at least one DOWNSTREAM "
                    "webhook references {{context.<captured_key>}} in its body_template, headers, "
                    "or url — otherwise the captured value is never consumed and response_capture "
                    "is doing nothing useful."
                )
            # ID-resolution nudge — detect fields shaped like references and
            # point at the three-tier decision tool. False positives are cheap;
            # silent free-text-to-ID leakage at runtime is expensive.
            schema_for_id_check = cfg.get("schema") or {}
            body_for_id_check = cfg.get("body_template") or {}

            def _looks_like_id_field(key: str, value) -> bool:
                k = (key or "").lower()
                if any(k.endswith(suf) for suf in ("_id", "_ref", "_sku", "_code", "_uuid", "id")):
                    if k in ("id", "_id"):
                        return False  # skip the outer record's own id field
                    return True
                if isinstance(value, str):
                    token = value.strip().lower()
                    if token in ("string", "number") and any(hint in k for hint in ("customer", "product", "site", "location", "lead", "account", "order", "supplier", "vendor", "route", "part", "item")):
                        return True
                return False

            id_fields_detected = []
            for k, v in schema_for_id_check.items():
                if _looks_like_id_field(k, v):
                    id_fields_detected.append(k)
            for k, v in body_for_id_check.items():
                if _looks_like_id_field(k, v) and k not in id_fields_detected:
                    id_fields_detected.append(k)
            if id_fields_detected:
                next_steps.append(
                    f"ID RESOLUTION — fields that look like ID references: {id_fields_detected}. "
                    f"Free-text extraction will not produce a usable structured ID — the webhook "
                    f"will fire with a plain string and your receiver will almost certainly 400. "
                    f"Call get_reference(topic='id_resolution') to pick the right tier (inline enum / "
                    f"context options dict / data source) for each field, then materialize it "
                    f"(update_webhook_schema with type='enum', init context with {{ options: [...] }}, "
                    f"or configure_data_source + resolved_reference field)."
                )
            next_steps.append(
                f"IF UNSURE — call ask_roxels('<your question>', template_id='{template_id}'). "
                "It has full product context plus this template's state and the onboarding "
                "transcript. Use it for any decision you're guessing at (auth shape, body "
                "structure, error handling, whether you even need this webhook)."
            )

        recommended, state = await _compute_path_awareness("configure_output", template_id)
        return _env_ok(
            action="configured",
            data={
                "template_id": template_id,
                "output_type": output_type,
                "total_outputs": len(outputs),
                "next_steps": next_steps,
                "convergence_rule": (
                    "Saving an output is never the final step. Loop: configure → "
                    "check_template → fill gaps → configure again → repeat. "
                    "A successful save tells you the write happened — it tells you NOTHING "
                    "about whether the config is correct, complete, or reliable."
                ),
                "template": result,
            },
            next_action_block=_env_next_action(
                tool="check_template",
                args={"template_id": template_id},
                why="Verify the new output didn't introduce gaps; see your current readiness score.",
            ),
            tool_name="configure_output",
            loop_phase="primary",
            recommended_tool=recommended,
            template_state=state,
            meta={"template_id": template_id},
        )

    # V2: patch_output REMOVED — use configure_output(match_trigger_goal=, replace=False)
    # with only the fields you want to change in `config`.

    @mcp.tool()
    async def create_embed_key(
        template_id: str, allowed_domains: list | str = "[]"
    ) -> str:
        """Generate a publishable embed key for a template.

        Embed keys (rk_ prefix) are safe for client-side use. They're scoped to
        a single template and can only create sessions.

        CRITICAL — the embed key is NOT the template_id. You PASS template_id (UUID)
        to this tool; this tool RETURNS an embed key like 'rk_live_abc...' or
        'rk_test_abc...'. That returned string — not the UUID — is what goes into
        `RoxelsEmbed.init({ templateKey: ... })` on the host page. If you try to
        embed with the UUID directly, session creation will reject it.

        YOU MUST call this before embedding. No runtime shortcut bypasses it —
        template_id is a server-side identifier, embed key is a host-page authorization
        credential. They are different concepts with different shapes.

        Args:
            template_id: UUID of the template (NOT the embed key you're minting — that's the return value).
            allowed_domains: Array of domains (or JSON string) — e.g. ["myapp.com", "staging.myapp.com"]. Empty array allows all domains.
        """
        domains = json.loads(allowed_domains) if isinstance(allowed_domains, str) else allowed_domains
        result = await client.create_embed_key(template_id, domains)
        return _env_ok(data=result)

    @mcp.tool()
    async def list_embed_keys(template_id: str) -> str:
        """List all embed keys for a template, showing their IDs, allowed domains, and revocation status.

        Args:
            template_id: UUID of the template
        """
        keys = await client.list_embed_keys(template_id)
        return _env_ok(data=keys)

    @mcp.tool()
    async def revoke_embed_key(embed_key_id: str) -> str:
        """Revoke an embed key so it can no longer be used to create sessions.

        Args:
            embed_key_id: UUID of the embed key record (NOT the rk_ key itself — get
                the UUID from list_embed_keys).
        """
        result = await client.revoke_embed_key(embed_key_id)
        return _env_ok(data=result)

    @mcp.tool()
    async def get_embed_code(
        embed_key: str,
        mode: str = "modal",
        person_name: str = "Guest",
        redirect_url: str = "",
    ) -> str:
        """Generate a ready-to-paste HTML/JS snippet for embedding the Roxels widget.

        Args:
            embed_key: The embed key (rk_live_... or rk_test_...) — create one
                with create_embed_key. NOT the template_id UUID.
            mode: "modal" (centered dialog) or "compact" (floating corner panel)
            person_name: Default person name shown to the agent
            redirect_url: URL to navigate to after the conversation completes
                (e.g. "/thank-you"). If empty, stays on the current page.
        """
        redirect_part = f", redirectUrl: '{redirect_url}'" if redirect_url else ""
        snippet = textwrap.dedent(f"""\
            <!-- Roxels Widget -->
            <script src="{EMBED_JS_URL}"></script>
            <script>
              Roxels.init({{
                templateKey: "{embed_key}",
                onUnderstanding: function(data) {{
                  // Real-time structured data — fires each conversation turn
                  console.log("Roxels extracted:", data);
                }},
                onComplete: function(results) {{
                  // Full results after processing
                  console.log("Roxels complete:", results);
                }},
                onError: function(err) {{
                  console.error("Roxels error:", err);
                }},
              }});
            </script>

            <button onclick="Roxels.open({{ mode: '{mode}', personName: '{person_name}'{redirect_part} }})">
              Start Conversation
            </button>""")

        return _env_ok(data={
                "snippet": snippet,
                "instructions": "Add the snippet to your HTML page. The button opens the Roxels widget. "
                "Customize the onUnderstanding callback to handle real-time data, and onComplete for final results. "
                "For React/Next.js, put the script tag in a useEffect and call Roxels.open() from your button handler.",
                "sdk_url": EMBED_JS_URL,
                "template_key": template_key,
            })

    @mcp.tool()
    async def update_goal_commit_rules(
        template_id: str,
        goal_id: str,
        commit_policy: str | None = None,
        invariants: list | str | None = None,
    ) -> str:
        """Set commit_policy and invariants on a goal's linked webhook output (Layer 2 validation rules).

        These live on the webhook output (output.config), not the goal. The webhook output must
        have trigger_goal set to this goal's ID. If no such webhook exists, this call fails.

        commit_policy controls when the webhook fires:
          'auto'                — default. Fires automatically after each extraction turn.
          'require_all_required' — only fires when all required_before_commit fields are satisfied.
          'human_confirm'       — fires only after explicit user confirmation (propose → confirm flow).

        invariants are cross-field rules using the shape-match DSL:
          [{\"when\": {\"field.path\": value}, \"then\": {\"other.path\": expected_value}}]
          If the 'when' subset matches the committed snapshot, the 'then' subset must also match.
          Commit is blocked if violated.

        Example invariant — category and product type must agree:
          [{\"when\": {\"item.category\": \"hardware\"}, \"then\": {\"item.product.type\": \"hardware\"}}]

        To set field-level rules (require_resolved, required_before_commit), use update_webhook_schema.

        Args:
            template_id: UUID of the template
            goal_id: The 'id' field of the goal
            commit_policy: 'auto', 'require_all_required', or 'human_confirm'. Omit to leave unchanged.
            invariants: List of {when, then} dicts (or JSON string). Omit to leave unchanged.
        """
        template = await client.get_template(template_id)
        goals = template.get("goals", [])

        if not any(g.get("id") == goal_id for g in goals):
            available = [g.get("id") for g in goals if g.get("id")]
            return _env_not_found(
                resource="goal",
                identifier=goal_id,
                hint=f"Known goal IDs: {available}. Use get_template to see the full goal list.",
                meta={"template_id": template_id},
            )

        settings_obj = template.get("settings", {})
        outputs = settings_obj.get("outputs", [])
        webhook = next(
            (o for o in outputs if o.get("type") == "webhook"
             and o.get("config", {}).get("trigger_goal") == goal_id),
            None,
        )
        if webhook is None:
            return _env_error(
                error_message="No webhook output is linked to this goal.",
                hint=(
                    "commit_policy and invariants live on the webhook output, not on the goal. "
                    "Call configure_output to create a webhook for this goal first."
                ),
                next_action_block=_env_next_action(
                    tool="configure_output",
                    args={"template_id": template_id, "output_type": "webhook", "config": {"trigger_goal": goal_id, "url": "..."}},
                    why="No webhook output references this goal yet.",
                ),
                meta={"template_id": template_id, "goal_id": goal_id},
            )

        cfg = webhook.setdefault("config", {})
        if commit_policy is not None:
            cfg["commit_policy"] = commit_policy
        if invariants is not None:
            cfg["invariants"] = json.loads(invariants) if isinstance(invariants, str) else invariants

        # Warn if require_all_required is set but the schema has no required_before_commit fields
        policy_warning = None
        if cfg.get("commit_policy") == "require_all_required":
            schema = cfg.get("schema", {})
            def _has_required_before_commit(s: dict) -> bool:
                if not isinstance(s, dict):
                    return False
                for v in s.values():
                    if isinstance(v, dict):
                        if v.get("required_before_commit"):
                            return True
                        if v.get("type") == "array":
                            if _has_required_before_commit(v.get("item_schema", {})):
                                return True
                return False
            if not _has_required_before_commit(schema):
                policy_warning = (
                    "commit_policy set to 'require_all_required' but no required_before_commit "
                    "fields found on this webhook's schema — goals will silently never commit. "
                    "Call update_webhook_schema(template_id, goal_id, {field: {type: '...', "
                    "required_before_commit: true}}) before running a test."
                )

        settings_obj["outputs"] = outputs
        await client.update_template(template_id, {"settings": settings_obj})
        warnings = None
        next_action_block = None
        if policy_warning:
            warnings = [{
                "rule": "inert_commit_policy",
                "severity": "HIGH",
                "message": policy_warning,
            }]
            next_action_block = _env_next_action(
                tool="update_webhook_schema",
                args={"template_id": template_id, "goal_id": goal_id, "schema": "<schema with required_before_commit fields>"},
                why="Without required_before_commit fields, require_all_required never fires.",
            )
        return _env_ok(
            action="updated",
            data={
                "goal_id": goal_id,
                "commit_policy": cfg.get("commit_policy"),
                "invariants": cfg.get("invariants"),
            },
            warnings=warnings,
            next_action_block=next_action_block,
            meta={"template_id": template_id},
        )

    async def _compute_path_awareness(
        current_tool: str,
        template_id: str | None,
    ) -> tuple[str | None, dict | None]:
        """Return (recommended_tool, template_state) for envelope nudges.

        Computes what get_next_action would recommend right now, without
        actually dispatching to that tool. Used by tools that want to
        surface meta.on_recommended_path + meta.template_state.

        Keeps the logic in sync with get_next_action by reading the same
        state (_collect_template_gaps + integration_shape status).

        Returns (None, None) on any error — envelope nudges are best-effort.
        """
        if template_id is None:
            return None, None
        try:
            template, all_gaps = await _collect_template_gaps(template_id)
        except Exception:
            return None, None

        settings = template.get("settings", {}) or {}
        shape = settings.get("integration_shape") or {}
        shape_status = shape.get("status")

        weights = {"HIGH": 10, "MEDIUM": 3, "LOW": 1}
        severity_counts = {
            "HIGH": sum(1 for g in all_gaps if g.get("severity") == "HIGH"),
            "MEDIUM": sum(1 for g in all_gaps if g.get("severity") == "MEDIUM"),
            "LOW": sum(1 for g in all_gaps if g.get("severity") == "LOW"),
        }
        score = max(0, 100 - sum(weights.get(g.get("severity", ""), 0) for g in all_gaps))

        template_state = {
            "score": score,
            "gaps_remaining": severity_counts,
            "shape_status": shape_status,
            "has_live_sessions": bool(template.get("has_recent_sessions") or False),
        }

        # Priority tiers matching get_next_action:
        if shape_status and shape_status != "confirmed":
            recommended = "integration_shape"
        elif all_gaps:
            # Pick the tool the highest-severity gap's next_action points at
            severity_rank = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
            top = min(all_gaps, key=lambda g: severity_rank.get(g.get("severity", "LOW"), 99))
            na = _env_format_gap(top)
            recommended = na["call"]["tool"] if na else "check_template"
        else:
            recommended = "verify"  # scope=live_session once ready

        return recommended, template_state

    async def _collect_template_gaps(template_id: str) -> tuple[dict, list[dict]]:
        """Shared reliability-check engine. Returns (template, gaps).

        Used by check_template (which returns score + gaps + next_action).
        check_template (which weight-aggregates gaps into a 0-100 score).
        Keeping this as one codepath ensures the diagnostic and the score never
        drift from each other.
        """
        template = await client.get_template(template_id)
        goals = template.get("goals", [])
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])
        outputs = settings.get("outputs", [])
        integration_shape = settings.get("integration_shape") or {}

        all_gaps: list[dict] = []

        # ── Integration-shape negotiation step (always surfaced while unconfirmed) ──
        #
        # Shape is a proposal that needs the coding agent's codebase-level review
        # before coverage checks can fire meaningfully. While unconfirmed, this
        # item sits at the top of the gap list so the negotiation stays visible.
        shape_status = integration_shape.get("status")
        if integration_shape and shape_status != "confirmed":
            current_shape = integration_shape.get("current") or {}
            open_qs = current_shape.get("open_questions") or []
            if shape_status == "proposed_by_roxels":
                severity = "HIGH"
                problem = (
                    "Integration shape is a Roxels-authored PROPOSAL and has not been "
                    "reviewed against your codebase yet. Roxels drafted it from what the "
                    "user said in the setup conversation — but Roxels has never seen your "
                    "repo, so the proposal is almost certainly incomplete. Nothing else "
                    "should be configured until you (the coding agent) read this proposal, "
                    "compare it to the actual code, and either revise or confirm it."
                )
            else:
                # under_revision (or any other non-confirmed value)
                severity = "MEDIUM" if open_qs else "LOW"
                problem = (
                    "Integration shape is under revision. "
                    + (f"{len(open_qs)} open questions still need codebase-grounded answers. "
                       if open_qs else "No open questions remain — confirm once the codebase matches. ")
                    + "Until the shape is confirmed, coverage-gap checks (orphan goals, "
                    + "missing chain links, frontend subscription gaps) are deferred."
                )
            if open_qs:
                q_summary = "\n    - " + "\n    - ".join(str(q) for q in open_qs[:5])
            else:
                q_summary = " (none)"
            all_gaps.append({
                "severity": severity,
                "field": "settings.integration_shape (negotiation step)",
                "problem": problem,
                "answer_this": (
                    "Read the proposal: integration_shape(template_id, action='read'). For EACH "
                    "per_goal_expectation, look at the actual codebase — does the "
                    "surface (webhook / frontend_callback / chained_api) match what "
                    "exists or what you will build? Answer each of the open_questions "
                    f"from code-reading:{q_summary}"
                ),
                "then_call": (
                    f"integration_shape(template_id='{template_id}', action='revise', "
                    "patch={...codebase-grounded changes...}, "
                    "reason='what you found in the repo that warranted the change') "
                    f"OR integration_shape(template_id='{template_id}', action='confirm') "
                    "once the current shape matches the codebase."
                ),
            })

        # ── Skills/skillsets/advisors checks ──

        # Skills with advisor-recommended placement attached to speaker directly
        speaker_skills = settings.get("speaker_skills", [])
        if speaker_skills:
            try:
                skills_resp = await client._request("GET", "/v1/skills")
                all_skills_map = {str(s["id"]): s for s in (skills_resp if isinstance(skills_resp, list) else skills_resp.get("skills", []))}
                misplaced = [
                    s for sid in speaker_skills
                    if (s := all_skills_map.get(str(sid)))
                    and s.get("recommended_placement") == "advisor"
                ]
                if misplaced:
                    names = [s["name"] for s in misplaced]
                    all_gaps.append({
                        "severity": "MEDIUM",
                        "field": "settings.speaker_skills",
                        "problem": (
                            f"The following skill(s) are attached to the speaker but are recommended "
                            f"as advisor-only: {names}. Advisor-recommended skills need a dedicated "
                            f"observer loop — running them inline on the speaker means their analysis "
                            f"gets attention-diluted by the full conversation."
                        ),
                        "answer_this": (
                            "Do these skills require a second pair of eyes (precision-critical, e.g. form "
                            "validation, compliance checklists, screen narration)? If so, create an Advisor "
                            "for them. If you intentionally want belt-and-suspenders coverage, keep them on "
                            "the speaker AND also add them to an Advisor."
                        ),
                        "then_call": (
                            f"Create an Advisor via the Roxels admin UI (/dashboard/skills → Advisors tab) "
                            f"with these skills, then update_template(template_id='{template_id}', "
                            f"settings={{...existing settings, 'advisors': [<new advisor UUID>]}})"
                        ),
                    })

                heavy_inlined = [
                    s for sid in speaker_skills
                    if (s := all_skills_map.get(str(sid)))
                    and s.get("complexity") == "heavy"
                    and s.get("recommended_placement") != "speaker"
                ]
                if heavy_inlined:
                    names = [s["name"] for s in heavy_inlined]
                    all_gaps.append({
                        "severity": "MEDIUM",
                        "field": "settings.speaker_skills",
                        "problem": (
                            f"Heavy-complexity skill(s) inlined on the speaker: {names}. "
                            f"Heavy skills contain multi-step analysis or extensive checklists — "
                            f"they crowd the conversation prompt and may dilute the speaker's focus."
                        ),
                        "answer_this": (
                            "Are these skills behavioral (should shape how the conversation flows) or "
                            "analytical (should review/observe the conversation)? If analytical, move "
                            "them to an Advisor to give them undivided attention."
                        ),
                        "then_call": (
                            f"Create an Advisor for the heavy skill(s) via /dashboard/skills, then "
                            f"update_template(template_id='{template_id}', settings={{..., 'advisors': [<UUID>]}})"
                        ),
                    })

                # 3. Many direct speaker_skills with no skillsets — suggest grouping
                if len(speaker_skills) >= 3 and not settings.get("speaker_skillsets"):
                    all_gaps.append({
                        "severity": "LOW",
                        "field": "settings.speaker_skills",
                        "problem": (
                            f"This template has {len(speaker_skills)} direct speaker_skills and no skillsets. "
                            f"If you reuse the same combination across multiple templates, a skillset lets you "
                            f"edit the bundle once and have all templates update automatically."
                        ),
                        "answer_this": (
                            "Do other templates in your org use the same combination of skills? "
                            "If yes, create a named Skillset for them."
                        ),
                        "then_call": (
                            f"Create a Skillset via the Roxels admin UI (/dashboard/skills → Skillsets tab), "
                            f"then update_template(template_id='{template_id}', settings={{..., "
                            f"'speaker_skillsets': [<skillset UUID>], 'speaker_skills': []}})"
                        ),
                    })
            except Exception:
                pass  # skill metadata unavailable — skip these checks silently

        for ds in data_sources:
            all_gaps.extend(_interrogate_source(ds, template_id, outputs=outputs))

        def _schema_has_required_before_commit(s: dict) -> bool:
            if not isinstance(s, dict):
                return False
            for v in s.values():
                if isinstance(v, dict):
                    if v.get("required_before_commit"):
                        return True
                    if v.get("type") == "array" and _schema_has_required_before_commit(v.get("item_schema", {})):
                        return True
            return False

        for output in outputs:
            if output.get("type") != "webhook":
                continue
            cfg = output.get("config", {})
            trigger_goal = cfg.get("trigger_goal")
            schema = cfg.get("schema")
            if trigger_goal and schema:
                synthetic_goal = {
                    "id": trigger_goal,
                    "schema": schema,
                    "commit_policy": cfg.get("commit_policy"),
                    "invariants": cfg.get("invariants"),
                }
                all_gaps.extend(_interrogate_schema(synthetic_goal, template_id, data_sources))

            # Fix 3: require_all_required + no required_before_commit fields → goal silently never commits
            if trigger_goal and cfg.get("commit_policy") == "require_all_required":
                if not _schema_has_required_before_commit(schema or {}):
                    all_gaps.append({
                        "severity": "HIGH",
                        "field": f"settings.outputs[trigger_goal={trigger_goal}].config.schema",
                        "problem": (
                            f"Webhook for goal '{trigger_goal}' has commit_policy='require_all_required' "
                            f"but no required_before_commit fields in its schema — this goal will silently "
                            f"never commit and the webhook will never fire."
                        ),
                        "answer_this": "Which fields must be captured before this goal can commit?",
                        "then_call": (
                            f"update_webhook_schema(template_id='{template_id}', goal_id='{trigger_goal}', "
                            f"schema={{field_name: {{type: 'string', required_before_commit: true}}}})"
                        ),
                    })

        # Webhook shape check: prefer per-goal webhooks over a single end-of-session webhook.
        webhook_outs = [o for o in outputs if o.get("type") == "webhook"]
        untriggered_webhooks = [o for o in webhook_outs if not o.get("config", {}).get("trigger_goal")]
        triggered_webhooks = [o for o in webhook_outs if o.get("config", {}).get("trigger_goal")]
        goal_ids_with_trigger = {o["config"]["trigger_goal"] for o in triggered_webhooks}
        goals_without_trigger = [g for g in goals if g.get("id") and g["id"] not in goal_ids_with_trigger]

        # Case A: multi-goal template with only end-of-session webhook(s) and no per-goal routing.
        if len(goals) >= 2 and untriggered_webhooks and not triggered_webhooks:
            goal_list = ", ".join(f"'{g.get('id', '?')}'" for g in goals if g.get("id"))
            all_gaps.append({
                "severity": "HIGH",
                "field": "settings.outputs (webhook shape)",
                "problem": (
                    f"This template has {len(goals)} goals but only {len(untriggered_webhooks)} end-of-session webhook(s) "
                    f"with no trigger_goal — meaning the back end receives nothing until the whole conversation ends. "
                    f"Roxels' canonical pattern is ONE WEBHOOK PER GOAL (set trigger_goal=<goal_id> on each), which "
                    f"delivers progressively, survives user drop-off, enables sequential flows via response_capture, "
                    f"and lets the front end react via JS callbacks as each goal commits. Single end-of-session webhooks "
                    f"are appropriate only when the receiver truly needs one combined payload."
                ),
                "answer_this": (
                    f"Is there a real reason all goal data has to arrive in one combined payload at the end? "
                    f"If not, split this into per-goal webhooks — one configure_output call per goal in {goal_list}, "
                    f"each pointing at the right back-end endpoint for that goal's entity. If yes (e.g. the receiver "
                    f"only accepts a final summary), keep the end-of-session webhook and document why in the template."
                ),
                "then_call": (
                    f"For each goal, call configure_output(template_id='{template_id}', output_type='webhook', "
                    f"config={{url: <endpoint for this goal>, trigger_goal: <goal_id>, schema: {{...}}, ...}}, "
                    f"replace=False). Then remove the untriggered webhook if it's no longer needed."
                ),
            })
        # Case B: template has per-goal webhooks for SOME goals but not all.
        elif triggered_webhooks and goals_without_trigger and len(goals) >= 2:
            missing_ids = [g.get("id", "?") for g in goals_without_trigger]
            all_gaps.append({
                "severity": "MEDIUM",
                "field": "settings.outputs (webhook coverage)",
                "problem": (
                    f"Goals {missing_ids} have no webhook with trigger_goal pointing at them. "
                    f"Other goals in this template DO have per-goal webhooks, so the pattern is already "
                    f"per-goal — the uncovered goals will silently produce no commit delivery. "
                    f"Either add a per-goal webhook for each uncovered goal, or confirm they genuinely "
                    f"have no back-end side-effect (e.g. the goal is conversational only)."
                ),
                "answer_this": (
                    f"For each of {missing_ids}: does this goal need to send data to a back-end endpoint "
                    f"at commit time? If yes, configure its webhook. If no (the goal is purely for shaping "
                    f"the conversation and has no side-effect), no change is needed."
                ),
                "then_call": (
                    f"For each goal that needs one: configure_output(template_id='{template_id}', "
                    f"output_type='webhook', config={{url: <endpoint>, trigger_goal: <goal_id>, schema: {{...}}}}, "
                    f"replace=False)."
                ),
            })

        # Orphan trigger_goal: webhook points at a goal id that doesn't exist on this template.
        goal_id_set = {g.get("id") for g in goals if g.get("id")}
        for o in webhook_outs:
            cfg = o.get("config", {})
            tg = cfg.get("trigger_goal")
            if tg and tg not in goal_id_set:
                all_gaps.append({
                    "severity": "HIGH",
                    "field": f"webhook trigger_goal='{tg}'",
                    "problem": (
                        f"Webhook is configured with trigger_goal='{tg}' but no goal with that id "
                        f"exists on this template. The webhook will never fire. Likely causes: a "
                        f"goal was renamed/deleted after the webhook was wired, or the trigger_goal "
                        f"value is a typo of an existing goal id."
                    ),
                    "answer_this": (
                        f"Which existing goal should this webhook fire for? Current goal ids: "
                        f"{sorted(goal_id_set) or '[]'}."
                    ),
                    "then_call": (
                        f"configure_output(template_id='{template_id}', output_type='webhook', "
                        f"match_trigger_goal='{tg}', replace=False, config={{'trigger_goal': '<correct_goal_id>'}}) "
                        f"— or remove the output if it's stale."
                    ),
                })

        # Missing schema AND missing body_template on a per-goal webhook — nothing shaping the payload.
        for o in triggered_webhooks:
            cfg = o.get("config", {})
            if not cfg.get("schema") and not cfg.get("body_template") and not cfg.get("raw_payload"):
                tg = cfg.get("trigger_goal")
                all_gaps.append({
                    "severity": "HIGH",
                    "field": f"webhook trigger_goal='{tg}' → schema/body_template",
                    "problem": (
                        f"Per-goal webhook for '{tg}' has neither a schema nor a body_template, "
                        f"and raw_payload is not set. The extraction model has nothing to anchor "
                        f"field shapes on, and the payload will fall back to a generic envelope — "
                        f"the target endpoint almost certainly expects specific field names that "
                        f"this config does not guarantee."
                    ),
                    "answer_this": (
                        f"What exact field names does the endpoint receiving '{tg}' expect, and "
                        f"what types? Set schema={{field: type, ...}} so the commit extraction is "
                        f"anchored; use body_template for precise payload shaping when field names "
                        f"differ between the goal's natural schema and the endpoint's expected keys."
                    ),
                    "then_call": (
                        f"configure_output(template_id='{template_id}', output_type='webhook', "
                        f"match_trigger_goal='{tg}', replace=False, "
                        f"config={{'schema': {{'<field>': '<type>', ...}}}})"
                    ),
                })

        # response_capture configured but no downstream webhook references the captured keys.
        captured_keys_in_play = set()
        for o in webhook_outs:
            rc = o.get("config", {}).get("response_capture") or {}
            captured_keys_in_play.update(rc.keys())
        if captured_keys_in_play:
            def _template_consumes(key: str) -> bool:
                token = "{{context." + key + "}}"
                for o in webhook_outs:
                    cfg = o.get("config", {})
                    if token in (cfg.get("url") or ""):
                        return True
                    for v in (cfg.get("headers") or {}).values():
                        if token in str(v):
                            return True
                    bt = cfg.get("body_template") or {}
                    if token in json.dumps(bt):
                        return True
                return False

            unconsumed = [k for k in captured_keys_in_play if not _template_consumes(k)]
            if unconsumed:
                all_gaps.append({
                    "severity": "MEDIUM",
                    "field": "webhook response_capture (unused keys)",
                    "problem": (
                        f"These captured context keys are never consumed by any downstream webhook "
                        f"body_template, header, or URL: {unconsumed}. Either you meant to use them "
                        f"(in which case a downstream webhook is missing its {{{{context.KEY}}}} "
                        f"reference) or the response_capture is dead config."
                    ),
                    "answer_this": (
                        f"For each of {unconsumed}: which downstream webhook is supposed to use it, "
                        f"and in which field (url / headers / body_template)? If none, remove the "
                        f"response_capture entry to keep the config honest."
                    ),
                    "then_call": (
                        f"configure_output(..., match_trigger_goal=, replace=False) on the downstream webhook to add the {{{{context.KEY}}}} "
                        f"reference, OR configure_output(..., match_trigger_goal=, replace=False) on the upstream to remove the unused "
                        f"response_capture key."
                    ),
                })

        # Webhook with URL that's a bare template placeholder (e.g. still literal 'https://...') — user forgot to fill.
        for o in webhook_outs:
            url_val = (o.get("config", {}).get("url") or "").strip()
            if url_val in ("", "https://", "http://") or url_val.startswith("https://example") or url_val.startswith("https://your"):
                all_gaps.append({
                    "severity": "HIGH",
                    "field": "webhook url",
                    "problem": (
                        f"Webhook url is a placeholder or empty: '{url_val}'. Every commit will fail."
                    ),
                    "answer_this": "What is the actual endpoint URL for this webhook?",
                    "then_call": (
                        f"configure_output(template_id='{template_id}', output_type='webhook', "
                        f"match_trigger_goal='{o.get('config', {}).get('trigger_goal') or '<trigger_goal>'}', "
                        f"replace=False, config={{'url': '<real url>'}})"
                    ),
                })

        # extraction_mode check: for any goal that has a trigger_goal webhook pointing at it
        # and no extraction_mode set, ask whether the endpoint is replace-all or delta.
        goals_with_streaming_webhook = {
            o.get("config", {}).get("trigger_goal")
            for o in outputs
            if o.get("type") == "webhook" and o.get("config", {}).get("trigger_goal")
        }
        for goal in goals:
            gid = goal.get("id")
            if gid and gid in goals_with_streaming_webhook and not goal.get("extraction_mode"):
                all_gaps.append({
                    "severity": "MEDIUM",
                    "field": f"goal '{gid}' → extraction_mode",
                    "problem": (
                        f"Goal '{gid}' has a streaming webhook (trigger_goal) but extraction_mode is not set. "
                        f"If the receiving endpoint replaces all existing records before saving, each webhook "
                        f"only delivers the delta from that turn — previous data is silently wiped."
                    ),
                    "answer_this": (
                        f"Does the endpoint receiving the '{gid}' webhook replace all existing records "
                        f"for this entity before saving (replace-all/upsert), or does it append/merge new "
                        f"data into existing records (delta)? "
                        f"If it replaces: set extraction_mode='cumulative' so each webhook fires a complete "
                        f"snapshot. If it merges: leave extraction_mode unset."
                    ),
                    "then_call": (
                        f"update_template(template_id='{template_id}', "
                        f"goals=[{{...existing goal '{gid}' fields..., 'extraction_mode': 'cumulative'}}]) "
                        f"— only if your endpoint is replace-all."
                    ),
                })

        # ── Shape-aware coverage checks (only when shape is confirmed) ──
        if shape_status == "confirmed":
            current_shape = integration_shape.get("current") or {}
            delivery = (current_shape.get("delivery") or "batch").lower()
            per_goal = current_shape.get("per_goal_expectations") or {}

            # ID-resolution coverage — each id_resolution_needs entry must be
            # materialized into the right tier (enum, context_options, or
            # data_source). Missing tier-3 data sources are HIGH; tier-1/2
            # misalignment is MEDIUM.
            ds_names = {ds.get("name") for ds in data_sources if ds.get("name")}
            for goal in goals:
                gid = goal.get("id")
                if not gid:
                    continue
                expectation = per_goal.get(gid) or {}
                for idr in (expectation.get("id_resolution_needs") or []):
                    concept = idr.get("concept") or "<unknown>"
                    tier = (idr.get("recommended_tier") or "unknown").lower()
                    rationale = idr.get("rationale") or ""
                    open_qs = idr.get("open_questions") or []

                    if tier == "data_source":
                        # Look for a plausibly-matching data source.
                        # Loose heuristic: any ds whose name contains the concept noun.
                        matched = any(
                            concept.lower() in (n or "").lower()
                            or (n or "").lower() in concept.lower()
                            for n in ds_names
                        )
                        if not matched:
                            qs_block = "\n    - " + "\n    - ".join(open_qs[:4]) if open_qs else ""
                            all_gaps.append({
                                "severity": "HIGH",
                                "field": f"integration_shape.per_goal_expectations['{gid}'].id_resolution_needs['{concept}']",
                                "problem": (
                                    f"Goal '{gid}' needs Tier-3 ID resolution for '{concept}' "
                                    f"({rationale}) but no matching data_source is configured. "
                                    f"At runtime, the webhook for this goal will either fire with "
                                    f"a free-text '{concept}' value (your receiver probably 400s) "
                                    f"or the agent will get stuck asking the user to disambiguate "
                                    f"without a lookup to ground the match."
                                ),
                                "answer_this": (
                                    f"Answer each of these from your codebase before configuring "
                                    f"the data source:{qs_block}\n    "
                                    f"If your codebase CANNOT support a tier-3 lookup, "
                                    f"integration_shape(action='revise') to a lower tier (enum or "
                                    f"context_options) that your setup can actually supply, "
                                    f"citing what you found."
                                ),
                                "then_call": (
                                    f"get_reference(topic='id_resolution') for the tier-3 example config, "
                                    f"then configure_data_source(template_id='{template_id}', "
                                    f"name='{concept}_lookup', type='api_call', request={{...}}, "
                                    f"description='...', examples=[...]) — OR "
                                    f"integration_shape(template_id='{template_id}', action='revise', "
                                    f"patch={{'per_goal_expectations': {{'{gid}': "
                                    f"{{'id_resolution_needs': [{{..., 'recommended_tier': 'enum'}}]}}}}}}, "
                                    f"reason='...')"
                                ),
                            })
                    elif tier == "enum":
                        # The webhook schema should carry an enum-typed field for this concept.
                        # We can't definitively find it (field naming varies), so emit MEDIUM
                        # guidance rather than a hard claim.
                        all_gaps.append({
                            "severity": "MEDIUM",
                            "field": f"integration_shape.per_goal_expectations['{gid}'].id_resolution_needs['{concept}']",
                            "problem": (
                                f"Goal '{gid}' plans Tier-1 (inline enum) resolution for '{concept}'. "
                                f"Verify the webhook schema has an enum-typed field for this concept "
                                f"with the valid values inline — otherwise the LLM has nothing to "
                                f"match against and will fall back to free-text extraction."
                            ),
                            "answer_this": (
                                f"Is there a schema field on '{gid}' that represents '{concept}' "
                                f"with type='enum' and values=[...] declared inline? If not, "
                                f"add one via update_webhook_schema. If the list is actually larger "
                                f"than a handful, revise the shape to tier 2 or 3."
                            ),
                            "then_call": (
                                f"get_reference(topic='id_resolution') for Tier-1 example schema, then "
                                f"update_webhook_schema(template_id='{template_id}', goal_id='{gid}', "
                                f"schema={{...'{concept}': {{'type': 'enum', 'values': [...], "
                                f"'description': '...'}}...}})"
                            ),
                        })
                    elif tier in ("context_options", "context"):
                        all_gaps.append({
                            "severity": "MEDIUM",
                            "field": f"integration_shape.per_goal_expectations['{gid}'].id_resolution_needs['{concept}']",
                            "problem": (
                                f"Goal '{gid}' plans Tier-2 (context options dict) resolution "
                                f"for '{concept}'. Verify (a) the schema field's description "
                                f"references {{{{context.<key>}}}} so the LLM knows which "
                                f"context list to match against, and (b) the embedding page "
                                f"actually supplies that context at init."
                            ),
                            "answer_this": (
                                f"Does the embedding page (or API session-create call) pass "
                                f"a '{concept}' list via context? Where in your frontend code "
                                f"will you call Roxels.open({{ context: {{ {concept}s: [...] }} }})? "
                                f"If the list is actually too big to inline, revise to tier 3."
                            ),
                            "then_call": (
                                f"get_reference(topic='id_resolution') for Tier-2 example; then wire "
                                f"the embed init call to supply {concept} options in context. "
                                f"No MCP tool is required for tier 2 — it is all client-side."
                            ),
                        })
                    # tier == "unknown" — the shape itself is not yet committed to a tier.
                    # That's caught by the negotiation gap; no extra gap here.



            webhook_trigger_goals = {
                o.get("config", {}).get("trigger_goal")
                for o in webhook_outs
                if o.get("config", {}).get("trigger_goal")
            }

            if delivery in ("per_goal", "mixed"):
                # Orphan goal: expected per-goal delivery but nothing routes the commit.
                for goal in goals:
                    gid = goal.get("id")
                    if not gid:
                        continue
                    expectation = per_goal.get(gid) or {}
                    surfaces = [s.lower() for s in (expectation.get("surfaces") or [])]
                    has_webhook = gid in webhook_trigger_goals
                    has_frontend_surface = "frontend_callback" in surfaces
                    if not surfaces and not has_webhook:
                        all_gaps.append({
                            "severity": "HIGH",
                            "field": f"integration_shape.per_goal_expectations['{gid}']",
                            "problem": (
                                f"Goal '{gid}' has no declared delivery surface and no "
                                f"webhook pointed at it. Delivery mode is '{delivery}', "
                                f"so every goal needs at least one surface (webhook, "
                                f"frontend_callback, or chained_api) or an explicit "
                                f"note that it's intentionally backend-silent."
                            ),
                            "answer_this": (
                                f"For goal '{gid}': does the codebase consume its commit "
                                f"(via webhook, an onUnderstanding subscriber, or a later "
                                f"goal's chained call)? If yes, which surface? If no "
                                f"(conversational-only), mark surfaces=['none'] in the "
                                f"expectation with a note explaining why."
                            ),
                            "then_call": (
                                f"integration_shape(template_id='{template_id}', action='revise', "
                                f"patch={{'per_goal_expectations': {{'{gid}': {{'surfaces': "
                                f"[...], 'notes': '...'}}}}}}, reason='...')"
                            ),
                        })
                    elif "webhook" in surfaces and not has_webhook:
                        all_gaps.append({
                            "severity": "HIGH",
                            "field": f"settings.outputs (webhook for goal '{gid}')",
                            "problem": (
                                f"Shape declares goal '{gid}' delivers via webhook, but "
                                f"no webhook output has trigger_goal='{gid}'. The commit "
                                f"will fire nothing until a webhook is configured for it."
                            ),
                            "answer_this": (
                                f"What endpoint should receive goal '{gid}' commits, and "
                                f"what is the payload schema?"
                            ),
                            "then_call": (
                                f"configure_output(template_id='{template_id}', "
                                f"output_type='webhook', config={{'url': '...', "
                                f"'trigger_goal': '{gid}', 'schema': {{...}}}}, "
                                f"replace=False)"
                            ),
                        })
                    elif has_frontend_surface:
                        # Frontend callbacks flow from the streaming pipeline. For the
                        # onUnderstanding path specifically, a streaming webhook must
                        # exist or the frontend will never see per-turn events.
                        has_streaming = any(
                            o.get("config", {}).get("streaming")
                            and (o.get("config", {}).get("trigger_goal") in (None, gid))
                            for o in webhook_outs
                        )
                        if not has_streaming and not (expectation.get("notes") or ""):
                            all_gaps.append({
                                "severity": "MEDIUM",
                                "field": f"integration_shape.per_goal_expectations['{gid}']",
                                "problem": (
                                    f"Goal '{gid}' is expected to update the frontend "
                                    f"via onUnderstanding callbacks, but no streaming "
                                    f"webhook is configured. onUnderstanding events flow "
                                    f"from the streaming extraction pipeline; without it "
                                    f"the embedding page will not receive per-turn updates "
                                    f"for this goal."
                                ),
                                "answer_this": (
                                    f"Does the frontend want per-turn updates (require "
                                    f"streaming webhook), or is onComplete at end-of-call "
                                    f"sufficient (no streaming needed)?"
                                ),
                                "then_call": (
                                    f"If per-turn: configure_output(template_id='{template_id}', "
                                    f"output_type='webhook', config={{'streaming': true, "
                                    f"'trigger_goal': '{gid}', 'schema': {{...}}}}, "
                                    f"replace=False). If onComplete only: revise the shape "
                                    f"to note 'onComplete-only'."
                                ),
                            })

            # Missing chain link: goal surface declares chained_api but no response_capture upstream.
            for goal in goals:
                gid = goal.get("id")
                if not gid:
                    continue
                expectation = per_goal.get(gid) or {}
                surfaces = [s.lower() for s in (expectation.get("surfaces") or [])]
                if "chained_api" not in surfaces:
                    continue
                # Find this goal's webhook
                goal_webhook = next(
                    (o for o in webhook_outs if o.get("config", {}).get("trigger_goal") == gid),
                    None,
                )
                body_str = json.dumps((goal_webhook or {}).get("config", {}).get("body_template") or {})
                url_str = str((goal_webhook or {}).get("config", {}).get("url") or "")
                uses_captured = ("{{context." in body_str) or ("{{context." in url_str)
                # Also check: is there any upstream webhook that defines a response_capture?
                upstream_has_capture = any(
                    (o.get("config", {}).get("response_capture") or {})
                    for o in webhook_outs
                    if o.get("config", {}).get("trigger_goal") != gid
                )
                if not uses_captured or not upstream_has_capture:
                    all_gaps.append({
                        "severity": "HIGH",
                        "field": f"integration_shape.per_goal_expectations['{gid}'] (chained_api)",
                        "problem": (
                            f"Goal '{gid}' is declared to chain off an upstream webhook's "
                            f"response, but the chain is not wired: "
                            + ("no upstream webhook defines response_capture. "
                               if not upstream_has_capture else "")
                            + ("this goal's webhook does not reference "
                               f"{{{{context.<captured_key>}}}} in its body_template/url. "
                               if not uses_captured else "")
                            + "Chained flows require both halves to be present."
                        ),
                        "answer_this": (
                            f"Which upstream goal produces the id goal '{gid}' needs, and "
                            f"what field name in the upstream response carries it? "
                            f"E.g. upstream returns {{id: 'xxx'}}; capture as "
                            f"response_capture={{'upstream_id': 'id'}}; downstream body "
                            f"references {{{{context.upstream_id}}}}."
                        ),
                        "then_call": (
                            f"configure_output(..., match_trigger_goal=, replace=False) on the upstream webhook to add "
                            f"response_capture, then configure_output(..., match_trigger_goal=, replace=False) on '{gid}''s "
                            f"webhook to reference {{{{context.<key>}}}} in body_template "
                            f"or url."
                        ),
                    })

        return template, all_gaps

    @mcp.tool()
    async def check_template(
        template_id: str,
        format: Literal["score", "gaps", "both"] = "both",
    ) -> str:
        """Score a template's readiness and return the actionable gap list.

        The primary convergence tool. One call gives you both: a 0-100 score and
        the full work queue of reliability gaps with `next_action` blocks.

        USE WHEN:
          - You just configured or updated something and want to see if the
            template is ready to go live.
          - You want the single most impactful next action (picked automatically
            from the HIGH-severity gaps).
          - You want to track progress across iterations — watch the score
            climb toward 100 as you close gaps.

        Args:
            template_id: UUID of the template to analyze
            format: "score" returns just the numeric score + next-best-action.
                    "gaps" returns just the full gap list.
                    "both" (default) returns everything.

        Returns:
            {
              "status": "ok" | "error",
              "action": "checked",
              "data": {
                "score": 0-100,
                "severity_counts": {"HIGH": n, "MEDIUM": n, "LOW": n},
                "category_breakdown": {category: {count, deduction, severities}},
                "gaps": [{severity, field, problem, answer_this, next_action}, ...],
                "unresolved_questions": [...],
                "interpretation": "..."
              },
              "next_action": { ... the single highest-impact call ... }
            }
        """
        template, all_gaps = await _collect_template_gaps(template_id)

        weights = {"HIGH": 10, "MEDIUM": 3, "LOW": 1}
        severity_counts = {
            "HIGH": sum(1 for g in all_gaps if g.get("severity") == "HIGH"),
            "MEDIUM": sum(1 for g in all_gaps if g.get("severity") == "MEDIUM"),
            "LOW": sum(1 for g in all_gaps if g.get("severity") == "LOW"),
        }
        deductions = sum(weights.get(g.get("severity", ""), 0) for g in all_gaps)
        score = max(0, 100 - deductions)

        def _bucket(field: str) -> str:
            f = (field or "").lower()
            if f.startswith("settings.speaker_skills") or f.startswith("settings.advisors"):
                return "skills_and_advisors"
            if f.startswith("settings.outputs") or f.startswith("webhook"):
                return "webhooks_and_outputs"
            if f.startswith("goal ") or ("goal" in f and "→" in f):
                return "goals_and_schemas"
            if "data_source" in f or "data source" in f:
                return "data_sources"
            return "other"

        category_breakdown: dict[str, dict] = {}
        for g in all_gaps:
            b = _bucket(g.get("field", ""))
            cb = category_breakdown.setdefault(b, {"count": 0, "deduction": 0, "severities": []})
            cb["count"] += 1
            cb["deduction"] += weights.get(g.get("severity", ""), 0)
            cb["severities"].append(g.get("severity", ""))

        # Build unresolved_questions from integration_shape open_questions
        unresolved_questions: list[dict] = []
        settings = template.get("settings", {}) or {}
        shape = settings.get("integration_shape") or {}
        shape_status = shape.get("status")
        current_shape = shape.get("current") or {}
        if shape_status and shape_status != "confirmed":
            for q in (current_shape.get("open_questions") or []):
                unresolved_questions.append({
                    "about": "integration_shape",
                    "question": str(q),
                    "why_we_need_to_know": (
                        "Roxels cannot verify this from the setup conversation alone — "
                        "it requires reading the client's codebase."
                    ),
                    "answer_format": "Narrative answer grounded in a specific file/endpoint/pattern.",
                    "next_action": _env_next_action(
                        tool="integration_shape",
                        args={"template_id": template_id, "patch": "<dict>", "reason": "<your answer>"},
                        why="Answer this open question with codebase-grounded evidence.",
                    ),
                })

        # Build canonical next_action for each gap and strip the legacy then_call
        # field so agents see ONE field, not two.
        for g in all_gaps:
            if "next_action" not in g:
                na = _env_format_gap(g)
                if na:
                    g["next_action"] = na
            g.pop("then_call", None)

        # Pick the single highest-impact gap as top-level next_action
        severity_rank = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
        top_next_action = None
        if all_gaps:
            next_gap = min(all_gaps, key=lambda g: severity_rank.get(g.get("severity", "LOW"), 99))
            top_next_action = next_gap.get("next_action") or _env_format_gap(next_gap)
            if top_next_action:
                top_next_action["why"] = (
                    f"[{next_gap.get('severity')}] {next_gap.get('problem') or ''} "
                    f"(+{weights.get(next_gap.get('severity', ''), 0)} pts if fixed)"
                )

        if score == 100:
            interpretation = (
                "Healthy. Before going live: check_template_config, probe_data_source on each DS, "
                "send_http_request on each per-goal webhook URL, check_embed_permissions_policy if "
                "embedded, then start_live_session for one end-to-end run."
            )
        elif score >= 85:
            interpretation = "Close. A small number of MEDIUM/LOW gaps remain; safe to test but polish before going live."
        elif score >= 60:
            interpretation = "Workable but brittle. Several HIGH or many MEDIUM gaps — live sessions will hit runtime failures."
        else:
            interpretation = "Not ready. Multiple HIGH gaps mean commits will fail or produce corrupt data. Iterate."

        data: dict = {
            "score": score,
            "healthy_threshold": 100,
            "interpretation": interpretation,
            "severity_counts": severity_counts,
            "category_breakdown": category_breakdown,
        }
        if format in ("gaps", "both"):
            data["gaps"] = all_gaps
            data["unresolved_questions"] = unresolved_questions
        if format == "score":
            # Score-only: drop gaps/questions
            pass

        return _env_ok(
            action="checked",
            data=data,
            next_action_block=top_next_action,
            meta={"template_id": template_id},
        )

    @mcp.tool()
    async def configure_data_source(
        template_id: str,
        name: str,
        endpoint_url: str = "",
        description: str = "",
        auth_type: str | None = None,
        auth_token: str | None = None,
        output_template: dict | str | None = None,
        default_params: dict | str | None = None,
        params: list | str | None = None,
        method: str = "GET",
        examples: list | str | None = None,
        canonicalization_rules: str | None = None,
        cache_key_fields: list | str | None = None,
        relaxable_params: list | str | None = None,
    ) -> str:
        """Add or update a data source on a template.

        A data source is an external API endpoint the agent calls in real time to
        resolve a user's free-text phrase into a structured object from your database.
        The agent extracts what the user said as a plain string; the data source turns
        it into a typed record with IDs that your webhook backend can consume directly.

        IMPORTANT — two steps are required:
          1. Call configure_data_source to register the endpoint (this step)
          2. Call update_webhook_schema to mark which fields trigger this lookup
             (fields must use type="resolved_reference", not a text description)

        ── V2 PARAMS (PREFERRED) ────────────────────────────────────────────────────
        Use `params` to declare the full HTTP contract for this data source. This is
        the structured replacement for `default_params` and the only way to declare
        per-call args that the agent must supply via resolve_id(args=...).

        Each param is a dict:
          {
            "name":       "level",           # query param / header name
            "in":         "query",           # "query" | "header" | "path"
            "value_from": "args",            # where the value comes from:
                                             #   "phrase"   — the user's free-text (the search string)
                                             #   "args"     — supplied per-call by the agent via resolve_id(args=...)
                                             #   "context"  — from session context (interview_context[name])
                                             #   "literal"  — a fixed value (set via "value" key)
            "required":   True,              # if True + value_from=args + no value supplied → call refused
            "type":       "enum",            # optional: "enum" | "string"
            "values":     ["metro","state"], # valid enum values (used for enum sweep fallback)
            "description": "...",           # required for args params — the agent reads this
            "value":      "fixed_val",       # for value_from=literal
          }

        The "phrase" param name is configurable — defaults to "search" in v1.
        One param must have value_from="phrase" to receive the user's free text.

        Natural pairing: if any param has value_from="args" and required=True, you
        almost certainly want cache_key_fields to include that param name, and
        relaxable_params to include it too. Call configure_data_source again with
        those fields, or check_template will flag it.

        ── AUTH ─────────────────────────────────────────────────────────────────────
          1. PREFERRED — session context (ephemeral, zero credential management):
               auth_type="bearer", auth_token="{{context.authToken}}"
          2. FALLBACK — long-lived service key: call store_secret() first, then:
               auth_type="bearer", auth_token="{{secret:sec_xxxxx}}"
          NEVER pass a raw API key as auth_token — it will be rejected.

        ── RELIABILITY FIELDS ────────────────────────────────────────────────────────
          - description: what the endpoint contains + what params it requires (injected into agent prompt)
          - examples: phrase→result pairs for query generation
          - canonicalization_rules: tiebreaker rules for ambiguous candidates
          - cache_key_fields: param names that change which object the same phrase resolves to
          - relaxable_params: narrowing filter params safe to drop on 0-results retry

        ── OUTPUT TEMPLATE ───────────────────────────────────────────────────────────
          output_template is a TRANSFORMATION MAP: {"recordId": "<id>", "label": "<name>"}
          Placeholders like "<id>" are filled from the API result's matching key.

        Args:
            template_id: UUID of the template
            name: Unique identifier for this data source
            endpoint_url: GET endpoint URL (deprecated — prefer params with value_from="phrase").
                          Supports {{context.fieldName}} interpolation.
            description: What the endpoint contains and what terms it accepts.
            auth_type: Auth type — "bearer" is the only supported value.
            auth_token: Token for bearer auth. Supports {{context.X}} and {{secret:id}}.
            output_template: Transformation map (object or JSON string).
            default_params: (deprecated) Static params merged into every request.
                            Use params=[{name, in, value_from, ...}] instead.
            params: Structured params list (v2). Replaces default_params.
            method: HTTP method (default "GET").
            examples: List of {phrase, expected_result} dicts (or JSON string).
            canonicalization_rules: Plain-English tiebreaker rules for ambiguous candidates.
            cache_key_fields: Param names to include in the phrase-level cache key.
            relaxable_params: Narrowing filter params safe to drop on 0-results retry.
        """
        # Reject raw secret values in auth_token — they must go through store_secret
        if auth_token and _looks_like_raw_secret(auth_token):
            return _env_error(
                error_message="Raw credential detected in auth_token.",
                hint=(
                    "Call store_secret(name='<descriptive name>') first, then use "
                    "the returned {{secret:ref}} as auth_token. "
                    "This keeps the credential out of this conversation and any logs."
                ),
                next_action_block=_env_next_action(
                    tool="store_secret",
                    args={"name": "<descriptive name>"},
                    why="Store the credential securely before referencing it as auth_token.",
                ),
            )

        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])

        # Preserve existing source so we can merge (update doesn't replace everything)
        existing = next((s for s in data_sources if s.get("name") == name), {})
        source_def: dict = {**existing, "name": name}

        # Parse v2 params if provided
        parsed_params: list | None = None
        if params is not None:
            parsed_params = json.loads(params) if isinstance(params, str) else params

        if parsed_params is not None:
            # v2 path: build request block
            _url = endpoint_url or (existing.get("request") or {}).get("url") or (existing.get("endpoint") or {}).get("url") or ""
            _auth: dict = {}
            if auth_type:
                _auth = {"type": auth_type}
                if auth_token:
                    _auth["token"] = auth_token
            elif existing.get("request", {}).get("auth"):
                _auth = existing["request"]["auth"]
            elif existing.get("endpoint", {}).get("auth"):
                _auth = existing["endpoint"]["auth"]
            source_def["request"] = {
                "method": method,
                "url": _url,
                "auth": _auth,
                "params": parsed_params,
            }
            # Keep endpoint block for validator backward-compat if url is known
            if _url:
                source_def.setdefault("endpoint", {})["url"] = _url
        else:
            # v1 path: build endpoint block (deprecated but kept for compat)
            if not source_def.get("endpoint"):
                source_def["endpoint"] = {}
            if endpoint_url:
                source_def["endpoint"]["url"] = endpoint_url
            source_def["endpoint"]["method"] = method
            if auth_type:
                source_def["endpoint"]["auth"] = {"type": auth_type}
                if auth_token:
                    source_def["endpoint"]["auth"]["token"] = auth_token

        if description:
            source_def["description"] = description

        if output_template is not None:
            parsed_template = json.loads(output_template) if isinstance(output_template, str) else output_template
            source_def["output_schema"] = {"template": parsed_template}

        if default_params is not None:
            source_def["default_params"] = json.loads(default_params) if isinstance(default_params, str) else default_params

        if examples is not None:
            source_def["examples"] = json.loads(examples) if isinstance(examples, str) else examples

        if canonicalization_rules:
            source_def["canonicalization_rules"] = canonicalization_rules

        if cache_key_fields is not None:
            source_def["cache_key_fields"] = json.loads(cache_key_fields) if isinstance(cache_key_fields, str) else cache_key_fields

        if relaxable_params is not None:
            source_def["relaxable_params"] = json.loads(relaxable_params) if isinstance(relaxable_params, str) else relaxable_params

        # Replace existing source with same name, or append
        data_sources = [s for s in data_sources if s.get("name") != name]
        data_sources.append(source_def)
        settings["data_sources"] = data_sources

        result = await client.update_template(template_id, {"settings": settings})

        # Run diagnosis on the source we just saved. Pass outputs so the auth
        # cross-check can flag same-host mismatches against existing webhooks.
        saved_source = next((s for s in data_sources if s.get("name") == name), source_def)
        gaps = _interrogate_source(saved_source, template_id, outputs=settings.get("outputs") or [])
        high_gaps = [g for g in gaps if g["severity"] == "HIGH"]
        med_gaps = [g for g in gaps if g["severity"] == "MEDIUM"]

        response: dict = {
            "status": "configured",
            "template_id": template_id,
            "data_source_name": name,
        }

        if gaps:
            response["reliability_diagnosis"] = {
                "summary": (
                    f"Data source '{name}' was saved, but {len(high_gaps)} high-priority and "
                    f"{len(med_gaps)} medium-priority reliability gaps were found. "
                    f"Please answer each question below and call the suggested tool with your answer "
                    f"before running a conversation — these gaps are the leading cause of semi-consistent behavior."
                ),
                "gaps": gaps,
            }
        else:
            response["reliability_diagnosis"] = {
                "summary": f"Data source '{name}' looks well-configured. Proceed to update_webhook_schema.",
            }

        response["next_steps"] = [
            {
                "step": 1,
                "action": "probe_data_source",
                "required": True,
                "why": (
                    "Data sources have high setup entropy — auth tokens, URL patterns, required params, "
                    "and response shapes all vary. A misconfigured source fails silently during conversations "
                    "(the agent gets no results and cannot resolve locations/IDs). "
                    "Verify it works before wiring it into a schema."
                ),
                "call": (
                    f"probe_data_source(template_id='{template_id}', source_name='{name}', "
                    f"params={{\"search\": \"<a real example value>\"}}"
                    + (
                        ", args={\"<param_name>\": \"<value>\"}"
                        if any(
                            p.get("value_from") == "args"
                            for p in (source_def.get("request") or {}).get("params", [])
                        )
                        else ""
                    )
                    + (
                        ", context={\"<context_key>\": \"<value>\"}"
                        if "{{context." in endpoint_url + (auth_token or "")
                        else ""
                    )
                    + ")"
                ),
                "success_criteria": "status_code=200 and result_count > 0 and template_applied_to_first_result looks correct",
            },
            {
                "step": 2,
                "action": "update_webhook_schema",
                "required": True,
                "why": f"Wire '{name}' into a goal by adding resolved_reference fields pointing to it.",
                "note": "Include require_resolved: true on each field so commits are blocked if resolution fails.",
            },
        ]
        return _env_ok(data=response)

    @mcp.tool()
    async def list_data_sources(template_id: str) -> str:
        """List all data sources configured on a template.

        Data sources are external lookup endpoints used to resolve user phrases
        (e.g. "Acme Corp") into structured objects (e.g. {accountId: 4712}) at extraction time.

        Use this to see what's configured before adding resolved_reference fields
        to a goal schema, or to verify a configure_data_source call worked.

        Args:
            template_id: UUID of the template
        """
        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])
        return _env_ok(data={
                "template_id": template_id,
                "count": len(data_sources),
                "data_sources": data_sources,
                "hint": "Use configure_data_source to add/update sources. Use configure_data_source (merge-mode) to update specific fields on an existing source without touching the rest. Use update_webhook_schema to add resolved_reference fields that reference these sources.",
            })

    # V2: patch_data_source REMOVED — configure_data_source is already
    # merge-semantic (it preserves unchanged fields). To update one field,
    # call configure_data_source with only that field set.

    async def _verify_data_source(
        template_id: str,
        source_name: str,
        params: dict | str = "{}",
        context: dict | str = "{}",
        args: dict | str = "{}",
    ) -> str:
        """Call a configured data source endpoint directly and return the raw response.

        Use this to verify auth, URL, query params, and response shape before
        running a full conversation. Much faster than burning a session to find out
        whether your endpoint returns the right structure.

        What it does:
          1. Loads the data source config from the template (supports both v1 endpoint and v2 request blocks)
          2. Interpolates {{context.X}}, {{args.X}}, {{phrase}} placeholders
          3. Merges declared params (phrase_param, literal params, args params) with your explicit `params`
          4. Makes the HTTP request
          5. Returns the raw response + shows what the output_schema template would produce

        On non-2xx errors: pattern-matches the error body to suggest a likely fix
        (missing required param, bad auth, wrong URL, etc.) with a concrete
        configure_data_source call you can copy.

        Args:
            template_id: UUID of the template
            source_name: Name of the data source to test (as set in configure_data_source)
            params: Extra query params to send (object or JSON string), e.g. {"search": "Acme Corp"}.
                    For v2 sources, phrase/literal/args params are auto-applied from the config;
                    use this only for overrides or extra params.
            context: Session context values for {{context.X}} interpolation (object or JSON string),
                     e.g. {"authToken": "your-token-here"}
            args: Per-call args for {{args.X}} params (object or JSON string).
                  If the data source has declared params with value_from='args' (e.g. level, category),
                  pass them here — this simulates what the agent passes via resolve_id(args=...).
                  Example: {"level": "municipality"}
        """
        import httpx
        import re
        import time

        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])

        source_def = next((s for s in data_sources if s.get("name") == source_name), None)
        if not source_def:
            available = [s.get("name") for s in data_sources]
            return _env_ok(data={"error": f"Data source '{source_name}' not found", "available_sources": available})

        parsed_params = json.loads(params) if isinstance(params, str) else params
        parsed_context = json.loads(context) if isinstance(context, str) else context
        parsed_args = json.loads(args) if isinstance(args, str) else (args or {})

        def _interpolate(s: str) -> str:
            """Interpolate {{context.X}}, {{args.X}}, {{phrase}} in a string."""
            for k, v in parsed_context.items():
                s = s.replace(f"{{{{context.{k}}}}}", str(v))
            for k, v in parsed_args.items():
                s = s.replace(f"{{{{args.{k}}}}}", str(v))
            # {{phrase}} becomes the search value from params if present
            phrase_val = parsed_params.get("search") or parsed_params.get("q") or parsed_params.get("query") or ""
            s = s.replace("{{phrase}}", phrase_val)
            return s

        # Prefer v2 request block; fall back to v1 endpoint
        req_block = source_def.get("request") or {}
        endpoint = source_def.get("endpoint", {})
        url = _interpolate(req_block.get("url") or endpoint.get("url", ""))
        auth = req_block.get("auth") or endpoint.get("auth", {})

        headers: dict = {}
        # v1 endpoint.headers
        for hk, hv in endpoint.get("headers", {}).items():
            headers[hk] = _interpolate(hv)
        # v2 request._headers (stored by configure_data_source)
        for hk, hv in req_block.get("_headers", {}).items():
            headers[hk] = _interpolate(hv)

        if auth.get("type") == "bearer":
            token = _interpolate(auth.get("token", ""))
            headers["Authorization"] = f"Bearer {token}"

        # Build query params from declared v2 params, then overlay explicit `params`
        declared_params = req_block.get("params", [])
        merged_query: dict = {}
        phrase_param_name = "search"
        for p in declared_params:
            pname = p.get("name")
            vf = p.get("value_from", "literal")
            if vf == "phrase":
                phrase_param_name = pname  # track but don't set yet
            elif vf == "literal":
                merged_query[pname] = _interpolate(str(p.get("value", "")))
            elif vf == "args":
                if pname in parsed_args:
                    merged_query[pname] = parsed_args[pname]
        # explicit params override
        merged_query.update(parsed_params)
        # if the caller passed a phrase via "search" key but phrase_param differs, remap
        if phrase_param_name != "search" and "search" in merged_query and phrase_param_name not in merged_query:
            merged_query[phrase_param_name] = merged_query.pop("search")

        method = (req_block.get("method") or endpoint.get("method") or "GET").upper()

        unresolved = re.findall(r"\{\{(?:context|args)\.\w+\}\}", url + " ".join(str(v) for v in headers.values()))

        start = time.time()
        try:
            async with httpx.AsyncClient(timeout=10) as http:
                if method == "GET":
                    resp = await http.get(url, params=merged_query, headers=headers)
                else:
                    resp = await http.request(method, url, json=merged_query, headers=headers)
                elapsed_ms = int((time.time() - start) * 1000)
                try:
                    raw_result = resp.json()
                except Exception:
                    raw_result = resp.text
        except Exception as e:
            return _env_ok(data={"error": str(e), "error_type": type(e).__name__, "url": url, "params": merged_query})

        # Non-2xx: pattern-match error body for actionable suggestions
        likely_fix: dict | None = None
        if resp.status_code >= 400 and isinstance(raw_result, dict):
            error_text = " ".join(str(v) for v in raw_result.values()).lower()
            # Patterns: "X parameter is required", "missing X", "unknown X", "invalid X"
            required_match = re.search(
                r"['\"]?(\w+)['\"]?\s+(?:parameter\s+)?(?:is\s+)?(?:required|missing)", error_text
            ) or re.search(r"missing\s+(?:required\s+)?(?:parameter\s+)?['\"]?(\w+)['\"]?", error_text)
            invalid_match = re.search(r"(?:unknown|invalid)\s+(?:parameter\s+)?['\"]?(\w+)['\"]?", error_text)
            param_name = (required_match.group(1) if required_match else None) or (
                invalid_match.group(1) if invalid_match else None
            )
            already_declared = any(p.get("name") == param_name for p in declared_params) if param_name else False
            if param_name and not already_declared:
                likely_fix = {
                    "reason": (
                        f"API responded with a message that suggests '{param_name}' is required or invalid. "
                        "This param is not yet declared in the data source config."
                    ),
                    "suggested_param": {
                        "name": param_name,
                        "in": "query",
                        "value_from": "args",
                        "required": True,
                        "description": f"Required by the API. Add a description and valid values if known.",
                    },
                    "then_call": (
                        f"configure_data_source(template_id='{template_id}', name='{source_name}', "
                        f"params=[..., {{\"name\": \"{param_name}\", \"in\": \"query\", "
                        f"\"value_from\": \"args\", \"required\": true, \"description\": \"...\", "
                        f"\"type\": \"enum\", \"values\": [\"...\"]}}])"
                    ),
                }
            elif param_name and already_declared:
                p = next((p for p in declared_params if p.get("name") == param_name), {})
                vf = p.get("value_from", "literal")
                if vf == "args" and param_name not in parsed_args:
                    likely_fix = {
                        "reason": (
                            f"'{param_name}' is declared with value_from='args' but you didn't pass it in `args`. "
                            f"Pass it via args={{'{param_name}': '<value>'}} when calling probe_data_source."
                        ),
                        "suggested_values": p.get("values"),
                        "then_call": (
                            f"probe_data_source(template_id='{template_id}', source_name='{source_name}', "
                            f"params=..., args={{'{param_name}': '<value>'}})"
                        ),
                    }
            if not likely_fix and resp.status_code == 401:
                likely_fix = {
                    "reason": "HTTP 401 Unauthorized — auth token is missing, expired, or wrong.",
                    "then_call": (
                        f"probe_data_source(..., context={{\"authToken\": \"<your-token>\"}})"
                        " or check configure_data_source auth settings."
                    ),
                }

        # Apply output_schema template to first result as a preview
        output_template = source_def.get("output_schema", {}).get("template")
        template_preview = None
        template_note = None
        if output_template:
            first = raw_result[0] if isinstance(raw_result, list) and raw_result else (raw_result if isinstance(raw_result, dict) else None)
            if first:
                out = {}
                for k, v in output_template.items():
                    if isinstance(v, str) and v.startswith("<") and v.endswith(">"):
                        path = v[1:-1].split(".")
                        val = first
                        for part in path:
                            val = val.get(part) if isinstance(val, dict) else None
                        out[k] = val
                    else:
                        out[k] = v
                template_preview = out
                if any(v is None for v in out.values()):
                    template_note = "Some template placeholders resolved to null — check that your API result keys match the template."
            else:
                template_note = "Could not apply template — response is not a non-empty array or object."

        result_count = len(raw_result) if isinstance(raw_result, list) else "object"
        is_success = resp.status_code == 200 and isinstance(raw_result, list) and len(raw_result) > 0
        template_ok = is_success and (template_preview is not None) and not template_note if output_template else True

        verified = is_success and template_ok and not unresolved

        result: dict = {
            "status_code": resp.status_code,
            "url": str(resp.url),
            "params_sent": merged_query,
            "elapsed_ms": elapsed_ms,
            "result_count": result_count,
            "raw_response_preview": raw_result[:3] if isinstance(raw_result, list) else raw_result,
            "template_applied_to_first_result": template_preview,
            "verification_status": "verified" if verified else "failed",
        }
        if likely_fix:
            result["likely_fix"] = likely_fix
        if template_note:
            result["template_warning"] = template_note
        if unresolved:
            result["unresolved_placeholders"] = unresolved
            result["hint"] = "Pass context={...} or args={...} with the missing keys to resolve these placeholders."

        if not verified:
            reasons = []
            if resp.status_code != 200:
                reasons.append(f"HTTP {resp.status_code} (expected 200)")
            elif not isinstance(raw_result, list):
                reasons.append("response is not a list — endpoint must return a flat array")
            elif len(raw_result) == 0:
                reasons.append("result_count=0 — endpoint returned no matches for the given params")
            if template_note:
                reasons.append(f"output_schema issue: {template_note}")
            if unresolved:
                reasons.append(f"unresolved placeholders: {unresolved}")
            result["verification_failure_reasons"] = reasons
            result["next_step"] = (
                "Fix the issues above and call probe_data_source again. "
                "Do not proceed to update_webhook_schema until verification_status='verified'."
            )

        # Persist test result back to the template so the verification state is visible
        # in list_data_sources, check_template_config, and future configure calls.
        import datetime as _dt
        _last_tested = {
            "timestamp": _dt.datetime.utcnow().isoformat() + "Z",
            "params": parsed_params,
            "status_code": resp.status_code,
            "result_count": result_count,
            "verified": verified,
        }
        try:
            _tmpl = await client.get_template(template_id)
            _settings = _tmpl.get("settings", {})
            _sources = _settings.get("data_sources", [])
            for _s in _sources:
                if _s.get("name") == source_name:
                    _s["_last_tested"] = _last_tested
                    break
            _settings["data_sources"] = _sources
            await client.update_template(template_id, {"settings": _settings})
        except Exception:
            pass  # Don't fail the test response if the persist fails

        # Record learning from this test (fire-and-forget — errors are silently swallowed)
        _search_phrase = merged_query.get(phrase_param_name) or merged_query.get("search") or merged_query.get("q") or merged_query.get("query")
        if _search_phrase:
            try:
                if verified and template_preview:
                    # Success: teach the expected result for this phrase
                    await client.record_learning(template_id, {
                        "type": "data_source",
                        "source_name": source_name,
                        "phrase": str(_search_phrase),
                        "success": True,
                        "result": template_preview,
                    })
                elif isinstance(raw_result, list) and len(raw_result) == 0:
                    # 0-result failure: synthesize a don't rule from this test
                    await client.record_learning(template_id, {
                        "type": "data_source",
                        "source_name": source_name,
                        "phrase": str(_search_phrase),
                        "success": False,
                        "queries_tried": [merged_query],
                    })
            except Exception:
                pass  # Never let learning errors affect the test response

        if verified:
            result["next_step"] = (
                "Verification passed. Proceed to update_webhook_schema to wire this source into your goal fields."
            )

        return _env_ok(data=result)

    @mcp.tool()
    async def remove_data_source(template_id: str, source_name: str) -> str:
        """Remove a data source from a template by name.

        This removes the data source definition from settings.data_sources.
        Any goal schema fields that reference this source (type='resolved_reference',
        data_source='source_name') will stop resolving and fall back to raw strings.

        Args:
            template_id: UUID of the template
            source_name: The name of the data source to remove (as set in configure_data_source)
        """
        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])

        before = len(data_sources)
        data_sources = [s for s in data_sources if s.get("name") != source_name]
        settings["data_sources"] = data_sources

        if len(data_sources) == before:
            return _env_not_found(
                resource="data source",
                identifier=source_name,
                meta={"template_id": template_id},
            )

        result = await client.update_template(template_id, {"settings": settings})
        return _env_ok(
            action="removed",
            data={
                "source_name": source_name,
                "remaining_data_sources": len(data_sources),
                "template": result,
            },
            meta={"template_id": template_id},
        )

    @mcp.tool()
    async def update_webhook_schema(
        template_id: str,
        goal_id: str,
        schema: dict | str,
    ) -> str:
        """Set or replace the extraction schema for a goal.

        The schema is the **canonical contract** for what the agent collects under
        this goal — what each field is (a string, a number, a structured ref, an
        array, etc.), what's required, and which data sources resolve which fields.
        Every runtime safety net (save_array_item field validation, inline-resolution,
        the validator, the commit author) walks this schema. The schema is the
        *only* place opinions about field shapes live; the engine itself is
        unopinionated and supports whatever a template declares (raw strings,
        resolved references, nested arrays — anything a webhook or downstream API
        might require).

        Storage: this tool writes the schema to **both**
          (a) `template.goals[goal_id].schema` — the canonical location read by
              the agent runtime, and
          (b) `template.settings.outputs[trigger_goal=goal_id].config.schema` —
              a mirror retained as a backwards-compat fallback.
        The webhook output linked to this goal (matched by `trigger_goal`) must
        already exist; if not, this call fails — use configure_output to create
        one first.

        NOTE: Schema fields do not declare DS query params. Params the data source
        needs are passed by the agent at call time via resolve_id(source, phrase, args={...}).
        Put param documentation in the data source's `description` field.

        The schema maps field names to types or field spec objects. Simple:
            {"company_name": "string", "headcount": "number", "active": "boolean"}

        For arrays of plain strings:
            {"tags": "array of strings"}

        For arrays of objects, use item_schema to define the shape of each item:
            {
              "items": {
                "type": "array",
                "item_schema": {
                  "product_name": "string",
                  "quantity": "number"
                }
              }
            }

        For fields that require a live lookup against an external API, use
        type='resolved_reference'. This REPLACES the user's free-text phrase with
        the structured object your data source returns. You MUST have a matching
        entry in settings.data_sources (configure it first with configure_data_source).

        IMPORTANT: The lookup is triggered ONLY by fields explicitly typed as
        'resolved_reference'. Using a text description like "resolve via my_source"
        on a string field does nothing — the type must be set.

        Single resolved_reference field:
            {
              "account_id": {
                "type": "resolved_reference",
                "data_source": "my_source"
              }
            }

        Array of objects where each item has a resolved_reference field:
            {
              "line_items": {
                "type": "array",
                "item_schema": {
                  "category": "string",
                  "product": {
                    "type": "resolved_reference",
                    "data_source": "my_source"
                  },
                  "quantity": "number"
                }
              }
            }

        Flat array of resolved objects — use item_type: "resolved_reference" when your
        webhook needs [{id, label}, ...] directly (not [{fieldName: {id, label}}, ...]):
            {
              "category": "string",
              "items": {
                "type": "array",
                "item_type": "resolved_reference",
                "data_source": "my_source"
              }
            }

        See get_reference(topic='data_source') for the full resolved_reference reference.

        Args:
            template_id: UUID of the template
            goal_id: The 'id' field of the goal to update
            schema: Extraction schema object (or JSON string). Maps field names to types
                    or field spec objects. Replaces the goal's current schema.
        """
        template = await client.get_template(template_id)
        goals = template.get("goals", [])

        parsed_schema = json.loads(schema) if isinstance(schema, str) else schema

        # Validate goal exists
        target = next((g for g in goals if g.get("id") == goal_id), None)
        if target is None:
            available = [g.get("id") for g in goals if g.get("id")]
            return _env_not_found(
                resource="goal",
                identifier=goal_id,
                hint=f"Known goal IDs: {available}.",
                meta={"template_id": template_id},
            )

        # Schema lives on the webhook output, not the goal.
        # Find the webhook output that triggers this goal.
        settings = template.get("settings", {})
        outputs = settings.get("outputs", [])
        webhook = next(
            (o for o in outputs if o.get("type") == "webhook"
             and o.get("config", {}).get("trigger_goal") == goal_id),
            None,
        )
        if webhook is None:
            return _env_error(
                error_message="No webhook output is linked to this goal.",
                hint=(
                    "Schema lives on the webhook output, not the goal. "
                    "Call configure_output to create a webhook for this goal first."
                ),
                next_action_block=_env_next_action(
                    tool="configure_output",
                    args={"template_id": template_id, "output_type": "webhook", "config": {"trigger_goal": goal_id, "url": "..."}},
                    why="No webhook output references this goal yet — create one, then set its schema.",
                ),
                meta={"template_id": template_id, "goal_id": goal_id},
            )

        # Write the schema to BOTH the goal (canonical contract source — read by
        # the agent runtime: speaker tools, validators, commit author) and the
        # webhook output's config (mirror, retained for backwards compat with
        # templates that still read schema from the webhook). The goal-level copy
        # is what every type-aware safety net walks; the webhook-level copy is
        # only consulted as a fallback when a goal has no schema declared.
        target["schema"] = parsed_schema
        webhook.setdefault("config", {})["schema"] = parsed_schema
        settings["outputs"] = outputs
        await client.update_template(template_id, {"goals": goals, "settings": settings})
        data_sources = settings.get("data_sources", [])
        gaps = _interrogate_schema(target, template_id, data_sources)
        high_gaps = [g for g in gaps if g["severity"] == "HIGH"]
        med_gaps = [g for g in gaps if g["severity"] == "MEDIUM"]

        response: dict = {
            "status": "updated",
            "template_id": template_id,
            "goal_id": goal_id,
            "schema_field_count": len(parsed_schema),
        }

        if gaps:
            response["reliability_diagnosis"] = {
                "summary": (
                    f"Schema for goal '{goal_id}' was saved, but {len(high_gaps)} high-priority and "
                    f"{len(med_gaps)} medium-priority reliability gaps were found. "
                    f"Each gap below includes the reason it matters and a specific question — please "
                    f"answer each one and apply the suggested call before running a conversation."
                ),
                "gaps": gaps,
            }
            if high_gaps:
                response["reliability_diagnosis"]["blocking_note"] = (
                    "HIGH severity gaps mean commits can fire with corrupt or missing data reaching "
                    "your endpoint. Please address these first."
                )
        else:
            response["reliability_diagnosis"] = {
                "summary": f"Goal '{goal_id}' schema looks well-configured. Consider calling check_template_config as a final check.",
            }

        return _env_ok(data=response)

    # ══════════════════════════════════════════════════════════════════════
    # Group 5 — TESTING
    # One tool. Seven scopes. Pick the cheapest scope that answers your
    # question; every response suggests the next-cheaper or next-more-expensive
    # scope to try.
    # ══════════════════════════════════════════════════════════════════════

    @mcp.tool()
    async def verify(
        scope: Literal[
            "template_config",
            "data_source",
            "output",
            "http_endpoint",
            "webhook_preview",
            "embed_permissions",
            "live_session",
        ],
        template_id: str | None = None,
        # data_source args
        source_name: str | None = None,
        params: dict | str | None = None,
        context: dict | str | None = None,
        args: dict | str | None = None,
        # output args
        trigger_goal: str | None = None,
        output_index: int | None = None,
        # http_endpoint + embed_permissions args
        url: str | None = None,
        method: str = "POST",
        headers: dict | None = None,
        body: dict | list | None = None,
        body_encoding: str = "json",
        timeout_seconds: int = 15,
        # webhook_preview args
        sample_data: dict | str | None = None,
    ) -> str:
        """Test one aspect of a template at the cheapest level that answers your question.

        Seven scopes, ordered cheap → expensive:

          "template_config"    — Structural integrity check. NO network.
                                 START HERE. Catches schema-reference mismatches,
                                 items-vs-item_schema mistakes, orphan data sources,
                                 untested sources. Required args: template_id.

          "webhook_preview"    — Dry-run body_template + {{context.*}} interpolation.
                                 NO network. Required args: template_id, trigger_goal.
                                 Optional: sample_data (dict | JSON string).

          "data_source"        — Real HTTP call to a data source endpoint. Verifies
                                 auth, URL, params, response shape. Pattern-matches
                                 API errors and suggests fixes. Required args:
                                 template_id, source_name. Optional: params, context,
                                 args (each dict | JSON string).

          "output"             — Fire a configured webhook with schema-generated
                                 sample data. Real HTTP. Required args: template_id
                                 + (trigger_goal PREFERRED or output_index fallback).

          "http_endpoint"      — Raw HTTP passthrough. Zero template binding. Useful
                                 for verifying an endpoint before wiring it into a
                                 template. Required args: url. Optional: method,
                                 headers, body, body_encoding (json / form / form-nested),
                                 timeout_seconds.

          "embed_permissions"  — Check a host URL's Permissions-Policy for microphone.
                                 Inspects response headers, meta tags, fingerprints
                                 the hosting platform (Cloudflare, Vercel, etc.).
                                 Required args: url.

          "live_session"       — ⚠️ EXPENSIVE. Creates a real test conversation. Only
                                 call when check_template returns score=100 and cheap
                                 scopes pass. Required args: template_id.

        Every response includes a scope-specific diagnosis + next_action
        suggesting the next scope to verify (or a concrete fix if this one failed).

        Args:
            scope: Which verification to run.
            template_id: Required for template_config / data_source / output /
                         webhook_preview / live_session.
            source_name: Required for data_source.
            params: Data-source param overrides (dict | JSON string).
            context: Data-source context values for {{context.X}} interpolation.
            args: Data-source per-call args for {{args.X}} params.
            trigger_goal: Identifies the output to simulate (preferred over output_index).
            output_index: Fallback identifier for output scope.
            url: Required for http_endpoint and embed_permissions.
            method / headers / body / body_encoding / timeout_seconds: http_endpoint args.
            sample_data: Optional sample for webhook_preview interpolation.
        """
        if scope == "template_config":
            if not template_id:
                return _env_error(
                    error_message="scope='template_config' requires `template_id`.",
                    tool_name="verify",
                    loop_phase="primary",
                )
            return await _verify_template_config(template_id)

        if scope == "data_source":
            if not template_id or not source_name:
                return _env_error(
                    error_message="scope='data_source' requires `template_id` and `source_name`.",
                    hint="Call list_data_sources(template_id) to see source names.",
                    tool_name="verify",
                    loop_phase="primary",
                    meta={"template_id": template_id} if template_id else None,
                )
            return await _verify_data_source(
                template_id=template_id,
                source_name=source_name,
                params=params or "{}",
                context=context or "{}",
                args=args or "{}",
            )

        if scope == "output":
            if not template_id:
                return _env_error(
                    error_message="scope='output' requires `template_id`.",
                    hint="Also pass `trigger_goal` (preferred) or `output_index`.",
                    tool_name="verify",
                    loop_phase="secondary",
                )
            return await _verify_output(
                template_id=template_id,
                trigger_goal=trigger_goal,
                output_index=output_index,
            )

        if scope == "http_endpoint":
            if not url:
                return _env_error(
                    error_message="scope='http_endpoint' requires `url`.",
                    tool_name="verify",
                    loop_phase="secondary",
                )
            return await _verify_http_endpoint(
                url=url,
                method=method,
                headers=headers,
                body=body,
                body_encoding=body_encoding,
                timeout_seconds=timeout_seconds,
            )

        if scope == "webhook_preview":
            if not template_id or not trigger_goal:
                return _env_error(
                    error_message="scope='webhook_preview' requires `template_id` and `trigger_goal`.",
                    tool_name="verify",
                    loop_phase="primary",
                    meta={"template_id": template_id} if template_id else None,
                )
            return await _verify_webhook_preview(
                template_id=template_id,
                trigger_goal=trigger_goal,
                sample_data=sample_data,
            )

        if scope == "embed_permissions":
            if not url:
                return _env_error(
                    error_message="scope='embed_permissions' requires `url`.",
                    tool_name="verify",
                    loop_phase="secondary",
                )
            return await _verify_embed_permissions(url)

        if scope == "live_session":
            if not template_id:
                return _env_error(
                    error_message="scope='live_session' requires `template_id`.",
                    tool_name="verify",
                    loop_phase="secondary",
                )
            return await _verify_live_session(template_id)

        return _env_error(
            error_message=f"Unknown scope '{scope}'.",
            hint=(
                "Valid scopes (cheap → expensive): template_config, webhook_preview, "
                "data_source, output, http_endpoint, embed_permissions, live_session."
            ),
            tool_name="verify",
            loop_phase="primary",
        )

    async def _verify_template_config(template_id: str) -> str:
        """Check a template's data source configuration for common errors before running a conversation.

        Catches misconfigurations that silently prevent data source resolution:
          1. Webhook output schema fields referencing a data_source name that isn't registered
          2. Webhook output schema fields typed 'resolved_reference' inside arrays, but nested under
             'items' instead of 'item_schema' (a common schema structure mistake)
          3. Data sources registered in settings but no webhook output schema field uses them
             (the data source exists but is never triggered)
          4. output_schema.template values that look like JSON Schema descriptions
             (e.g. {"type": "array", "description": "..."}) instead of transformation maps
             (e.g. {"myField": "<api_result_key>"}) — the wrong form is silently ignored

        Use this after configure_data_source + update_webhook_schema and before running a
        live conversation. Also run it to diagnose why a data source isn't triggering.

        Structural checks are delegated to the backend validate endpoint so they stay
        in sync with PATCH validation. Runtime checks (DS testing status, suggestions)
        are performed here.

        Args:
            template_id: UUID of the template
        """
        # --- Structural violations from the backend (single source of truth) ---
        validate_result = await client.validate_template(template_id)
        structural_violations = validate_result.get("violations") or []

        errors = [v for v in structural_violations if v.get("rule") != "ds_items_vs_item_schema"]
        warnings = [
            {
                "goal_id": v.get("goal_id"),
                "field": v.get("field"),
                "warning": v["message"],
                "detail": (
                    "Change 'items' to 'item_schema' so the resolution code finds these fields."
                ),
            }
            for v in structural_violations
            if v.get("rule") == "ds_items_vs_item_schema"
        ]

        # Also fetch template for runtime checks (DS testing status, suggestions)
        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        goals = template.get("goals", [])
        data_sources = settings.get("data_sources", [])
        outputs = settings.get("outputs", [])
        registered_source_names = {s.get("name") for s in data_sources if s.get("name")}

        # Derive which sources are triggered by webhook output schemas (for unused-source check)
        triggered_sources: set[str] = set()
        for v in structural_violations:
            if v.get("rule") in ("ds_unknown_data_source",):
                pass  # reference exists but target doesn't — not triggered
        # Re-walk goals to find triggered sources (structural violations already caught bad refs)
        def _find_triggered(schema_obj: dict) -> None:
            if not isinstance(schema_obj, dict):
                return
            for fspec in schema_obj.values():
                if not isinstance(fspec, dict):
                    continue
                ftype = fspec.get("type")
                if ftype == "resolved_reference":
                    src = fspec.get("data_source")
                    if src and src in registered_source_names:
                        triggered_sources.add(src)
                elif ftype == "array":
                    if fspec.get("item_type") == "resolved_reference":
                        src = fspec.get("data_source")
                        if src and src in registered_source_names:
                            triggered_sources.add(src)
                    item = fspec.get("item_schema") or fspec.get("items") or {}
                    if isinstance(item, dict):
                        if item.get("type") == "resolved_reference":
                            src = item.get("data_source")
                            if src and src in registered_source_names:
                                triggered_sources.add(src)
                        else:
                            _find_triggered(item)
                elif "type" not in fspec or fspec.get("type") == "object":
                    _find_triggered(fspec)

        for output in outputs:
            if output.get("type") == "webhook":
                schema_obj = output.get("config", {}).get("schema") or {}
                _find_triggered(schema_obj)

        # --- Check for registered sources with no goal field referencing them ---
        unused_sources = registered_source_names - triggered_sources
        for src_name in sorted(unused_sources):
            warnings.append({
                "source": src_name,
                "warning": "Data source is registered but no goal schema field references it",
                "detail": "No goal has a field with type='resolved_reference' and data_source='" + src_name + "'. "
                          "The source will never be called. Either add a resolved_reference field or remove the source.",
            })

        # --- Check for sources that have never been tested or whose last test failed ---
        for src in data_sources:
            src_name = src.get("name", "<unnamed>")
            last_tested = src.get("_last_tested")
            if not last_tested:
                warnings.append({
                    "source": src_name,
                    "warning": "Data source has never been tested",
                    "detail": (
                        "Call probe_data_source to verify auth, params, and response shape before running conversations. "
                        "Untested sources commonly fail silently — the agent gets no results and cannot resolve values."
                    ),
                    "fix": f"probe_data_source(template_id='{template_id}', source_name='{src_name}', params={{\"search\": \"<example value>\"}})",
                })
            elif not last_tested.get("verified"):
                warnings.append({
                    "source": src_name,
                    "warning": "Last test did not pass verification",
                    "detail": (
                        f"Tested at {last_tested.get('timestamp', '?')} — "
                        f"status_code={last_tested.get('status_code')}, "
                        f"result_count={last_tested.get('result_count')}, verified=False. "
                        "Fix the endpoint config and re-run probe_data_source until verification_status='verified'."
                    ),
                    "last_tested_params": last_tested.get("params"),
                    "fix": f"probe_data_source(template_id='{template_id}', source_name='{src_name}', params={{\"search\": \"<example value>\"}})",
                })

        # --- Suggestions: reliability improvements that aren't errors but reduce failure rate ---
        suggestions = []
        for src in data_sources:
            src_name = src.get("name", "<unnamed>")
            default_params = src.get("default_params", {})
            # Narrowing filter params: static values that aren't context injections
            static_narrowing = [
                k for k, v in default_params.items()
                if isinstance(v, str) and not v.startswith("{{context.")
            ]
            if static_narrowing and not src.get("relaxable_params"):
                suggestions.append({
                    "source": src_name,
                    "suggestion": "Consider declaring relaxable_params",
                    "detail": (
                        f"'{src_name}' has narrowing filter params {static_narrowing} but no relaxable_params set. "
                        f"When a lookup returns 0 results, the agent's recovery cascade can automatically drop "
                        f"these params and retry — catching cases where the extraction model picked the wrong "
                        f"filter value. Without relaxable_params the cascade skips straight to world-knowledge "
                        f"fallback (or silent skip), even if the entity exists in the database under a different "
                        f"filter value."
                    ),
                    "answer_this": (
                        f"Which of {static_narrowing} are safe to drop on a retry? "
                        f"A param is safe if omitting it broadens the search without leaking data across "
                        f"tenancy boundaries. Narrowing filters (type, category, tier) are usually safe. "
                        f"Tenancy guards (account_id, org_id) are NEVER safe."
                    ),
                    "fix": (
                        f"configure_data_source(template_id='{template_id}', name='{src_name}', "
                        f"relaxable_params=[\"<safe_narrowing_param>\"])"
                    ),
                })

        # --- Check for unacted-upon learned rules (from runtime learnings) ---
        learnings = template.get("learnings") or {}
        if isinstance(learnings, str):
            try:
                learnings = json.loads(learnings)
            except Exception:
                learnings = {}
        ds_learnings = learnings.get("data_sources", {})
        for src_name_lr, src_lr in ds_learnings.items():
            dont_rules = src_lr.get("_learned_rules", {}).get("dont", [])
            if dont_rules:
                suggestions.append({
                    "source": src_name_lr,
                    "suggestion": f"{len(dont_rules)} learned 'don't' rule(s) from live sessions not yet acted on",
                    "detail": (
                        f"'{src_name_lr}' has accumulated don't rules from real conversation failures. "
                        f"These rules are automatically injected into future sessions (when LEARNINGS_ENABLED=true), "
                        f"but they represent failure modes that could be eliminated by updating the template config."
                    ),
                    "learned_dont_rules": dont_rules,
                    "fix": f"get_runtime_learnings(template_id='{template_id}') — then act on suggested_actions",
                })

        if not errors and not warnings and not suggestions:
            return _env_ok(
                action="ok",
                data={
                "message": "No issues found. Data source configuration looks correct.",
                "data_sources_registered": sorted(registered_source_names),
                "sources_triggered_by_goals": sorted(triggered_sources),
            })

        result: dict = {
            "status": "issues_found" if (errors or warnings) else "ok_with_suggestions",
            "error_count": len(errors),
            "warning_count": len(warnings),
            "suggestion_count": len(suggestions),
        }
        if errors:
            result["errors"] = errors
        if warnings:
            result["warnings"] = warnings
        if suggestions:
            result["suggestions"] = suggestions
        result["hint"] = (
            "Fix all errors before running a conversation — errors silently prevent resolution. "
            "Warnings indicate likely misconfiguration. "
            "Suggestions are optional improvements that reduce the failure rate of data source resolution."
        )
        return _env_ok(data=result)

    async def _verify_live_session(template_id: str) -> str:
        """Create a live test conversation for a template and return the join URL.

        ⚠️ CAUTION — EXPENSIVE. Live sessions hit real endpoints and consume
        compute. Do not call this until check_template returns score=100.
        After running, read get_session_diagnostics BEFORE running another test.

        USE WHEN:
          - check_template returned score=100 and you want end-to-end verification.
          - You need to exercise the full flow (goals, agent, webhooks, capture).

        Args:
            template_id: UUID of the template to test.

        Returns:
            {status, action="started", data: {join_url, session_id, interview_id},
             next_action: open join_url → then get_template_recent_sessions →
             get_session_diagnostics}
        """
        result = await client.start_live_session(template_id)
        return _env_ok(
            action="started",
            data=result,
            next_action_block=_env_next_action(
                tool="get_template_recent_sessions",
                args={"template_id": template_id, "limit": 5},
                why=(
                    "Open join_url in a browser to run the conversation. When done, "
                    "list recent sessions to find the session_id, then call "
                    "get_session_diagnostics(session_id) to read the full breakdown."
                ),
            ),
            meta={"template_id": template_id},
        )

    async def _verify_output(
        template_id: str,
        trigger_goal: str | None = None,
        output_index: int | None = None,
    ) -> str:
        """Fire a configured output against its real endpoint with realistic sample data.

        USE WHEN:
          - You want to verify a webhook endpoint accepts the shape you configured
            without running a full live session.
          - You want to see what structured extraction would produce for a given
            webhook schema.

        For webhooks: generates sample data matching the schema, POSTs to the URL,
        returns the HTTP status + response body.
        For structured outputs: returns sample extracted data matching the schema.

        ⚠️ CAUTION: this hits the real endpoint. Don't point templates at production
        endpoints you care about side effects on while iterating.

        Args:
            template_id: UUID of the template
            trigger_goal: Preferred — identify the output by its trigger_goal (the
                goal whose commit fires it). Stable across template edits.
            output_index: Fallback — 0-based index into settings.outputs. Brittle
                if outputs are reordered. Omit both to simulate output 0.

        After running, use get_session_diagnostics(session_id) on any real sessions
        to diagnose failures. get_template_issues(template_id) surfaces patterns
        repeated across multiple sessions.
        """
        # Resolve trigger_goal → output_index if needed (backend still takes index)
        if trigger_goal is not None:
            template = await client.get_template(template_id)
            outputs = template.get("settings", {}).get("outputs", [])
            resolved_index = next(
                (i for i, o in enumerate(outputs)
                 if o.get("config", {}).get("trigger_goal") == trigger_goal),
                None,
            )
            if resolved_index is None:
                return _env_not_found(
                    resource="webhook output",
                    identifier=f"trigger_goal='{trigger_goal}'",
                    hint="No webhook output has this trigger_goal. Check get_template for configured outputs.",
                    meta={"template_id": template_id},
                )
            output_index = resolved_index
        elif output_index is None:
            output_index = 0

        result = await client.simulate_output(template_id, output_index)
        return _env_ok(
            action="simulated",
            data=result,
            meta={"template_id": template_id, "output_index": output_index},
        )

    # ══════════════════════════════════════════════════════════════════════
    # Group 5 — TESTING
    # Simulate outputs, hit raw endpoints, start live sessions. Use the
    # cheapest test that exercises what you want to verify.
    # ══════════════════════════════════════════════════════════════════════

    async def _verify_http_endpoint(
        url: str,
        method: str = "POST",
        headers: dict | None = None,
        body: dict | list | None = None,
        body_encoding: str = "json",
        timeout_seconds: int = 15,
    ) -> str:
        """Send a real HTTP request to verify a webhook configuration before saving it.

        SECONDARY LOOP — hits a real endpoint. After you've run this (or a live
        session), read get_session_diagnostics(session_id) before iterating.

        Use this to confirm that an endpoint accepts the method, content-type, auth,
        and body shape you plan to configure — before wiring it into a live template.

        Returns the raw response (status code, headers, body) so you can read error
        messages and correct the configuration. A 4xx response is not an error here —
        it is useful signal. Read the response body to understand what the API rejected.

        body_encoding values:
          'json'        — application/json (default)
          'form'        — application/x-www-form-urlencoded, standard flat encoding
          'form-nested' — application/x-www-form-urlencoded, Stripe/Twilio bracket notation

        Does NOT interact with any Roxels template or conversation data — pure HTTP passthrough.
        """
        import time as _time
        from urllib.parse import urlencode, urlparse

        def _flatten_nested(payload, prefix=""):
            pairs = []
            if isinstance(payload, dict):
                for k, v in payload.items():
                    full_key = f"{prefix}[{k}]" if prefix else k
                    pairs.extend(_flatten_nested(v, full_key))
            elif isinstance(payload, list):
                for i, v in enumerate(payload):
                    pairs.extend(_flatten_nested(v, f"{prefix}[{i}]"))
            elif payload is None:
                pass
            elif isinstance(payload, bool):
                pairs.append((prefix, "true" if payload else "false"))
            else:
                pairs.append((prefix, str(payload)))
            return pairs

        if body_encoding == "form":
            body_content = urlencode(body if isinstance(body, dict) else {}, doseq=True)
            default_ct = "application/x-www-form-urlencoded"
        elif body_encoding == "form-nested":
            body_content = urlencode(_flatten_nested(body or {}))
            default_ct = "application/x-www-form-urlencoded"
        else:
            body_content = json.dumps(body or {})
            default_ct = "application/json"

        req_headers = dict(headers or {})
        req_headers.setdefault("Content-Type", default_ct)

        parsed = urlparse(url)
        safe_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"

        start_ms = int(_time.monotonic() * 1000)
        try:
            async with httpx.AsyncClient(timeout=timeout_seconds) as http:
                resp = await http.request(
                    method.upper(), url, content=body_content, headers=req_headers
                )
            duration_ms = int(_time.monotonic() * 1000) - start_ms
            try:
                resp_body = resp.json()
            except Exception:
                resp_body = resp.text[:4096] if resp.text else None

            result = {
                "url": safe_url,
                "method": method.upper(),
                "body_encoding": body_encoding,
                "status_code": resp.status_code,
                "duration_ms": duration_ms,
                "response_headers": dict(resp.headers),
                "response_body": resp_body,
                "ok": 200 <= resp.status_code < 300,
            }
            if not result["ok"]:
                result["hint"] = (
                    "Non-2xx response. Read response_body for the API's error message. "
                    "Common causes: wrong auth header, wrong body_encoding (try 'form-nested' for Stripe/Twilio), "
                    "missing required field, or wrong method."
                )
            return _env_ok(data=result)
        except Exception as e:
            duration_ms = int(_time.monotonic() * 1000) - start_ms
            return _env_ok(data={
                "url": safe_url,
                "method": method.upper(),
                "body_encoding": body_encoding,
                "status_code": None,
                "duration_ms": duration_ms,
                "error": str(e),
                "hint": "Request failed before receiving a response. Check the URL, network access, and timeout.",
            })

    # ══════════════════════════════════════════════════════════════════════
    # Group 6 — DIAGNOSTICS
    # Read what happened in past sessions. Use AFTER live tests — never as a
    # substitute for them. The primary convergence tool is check_template.
    # ══════════════════════════════════════════════════════════════════════
    # These tools analyze your template's outgoing webhook calls to external APIs.
    # They tell you what YOUR configuration sent, what the TARGET API responded,
    # and what to change in your template. They say nothing about Roxels platform health.

    @mcp.tool()
    async def get_template_recent_sessions(template_id: str, limit: int = 10) -> str:
        """List recent sessions for a template with top-level health indicators.

        Analyzes your template's outgoing webhook calls to external APIs — not Roxels
        platform health. Failures here mean something in your webhook config needs fixing.

        Returns status, duration, person name, and issue count for each session.
        Sessions with webhook failures or processing errors are flagged.

        Use this as the starting point when a template isn't behaving as expected —
        it gives you a quick health overview and tells you which sessions to drill into.

        Each row includes a session_id. Pass that to get_session_diagnostics(session_id)
        for a full breakdown. Do not pass interview_id — it is a different identifier.

        For patterns repeated across multiple sessions, call get_template_issues(template_id).

        Args:
            template_id: UUID of the template
            limit: Number of recent sessions to return (max 50, default 10)
        """
        result = await client.get_template_recent_sessions(template_id, limit=limit)
        return _env_ok(data=result)

    @mcp.tool()
    async def get_session_diagnostics(session_id: str) -> str:
        """Get a diagnostic report for a single session.

        This is the second half of the SECONDARY LOOP — every live test
        produces diagnostics, and every test you don't read diagnostics for
        is a test you paid for and threw away. Read this before running
        another test.

        Analyzes your template's outgoing webhook calls to external APIs — not Roxels
        platform health. Suggested fixes describe changes to make in your template config.

        Returns committed goals, all outgoing webhook calls with status and response
        body previews, and suggested fixes for anything that went wrong — 400 errors,
        auth failures, encoding mismatches, unresolved context placeholders,
        response_capture misses, and more.

        No dashboard required. All the signal is here.

        Typical workflow:
          1. Run a test conversation
          2. Call get_template_recent_sessions(template_id) to get a session_id
          3. Call this tool with that session_id
          4. Read suggested_fixes_summary — it tells you exactly what to change
          5. Fix the template config and retest

        The session_id is the `session_id` field from get_template_recent_sessions —
        not the interview_id. They are different UUIDs.

        Call get_template_issues(template_id) if you want to see if the same
        failure pattern is happening across multiple sessions.

        Args:
            session_id: UUID of the session — use the session_id field from
                        get_template_recent_sessions, not the interview_id
        """
        result = await client.get_session_diagnostics(session_id)

        # Post-process: surface root cause for goals that never committed
        try:
            if isinstance(result, dict):
                goals_data = result.get("goals") or []
                uncommitted = []
                for g in (goals_data if isinstance(goals_data, list) else []):
                    status_val = (g.get("status") or "").lower()
                    if "never" in status_val or status_val in ("not_committed", "uncommitted", "pending"):
                        uncommitted.append(g)

                # Also scan webhook calls for "never committed" error text
                webhook_calls = result.get("webhook_calls") or []
                for wc in (webhook_calls if isinstance(webhook_calls, list) else []):
                    err = str(wc.get("error") or wc.get("message") or "").lower()
                    if "never commit" in err or "not commit" in err:
                        fix = (
                            "Likely cause: webhook output schema has no required_before_commit "
                            "fields, or commit_policy is not 'require_all_required'. "
                            "Fix: call update_webhook_schema(template_id, goal_id, "
                            "{field: {type: 'string', required_before_commit: true}}) "
                            "then update_goal_commit_rules(template_id, goal_id, "
                            "commit_policy='require_all_required'), then retest."
                        )
                        if "suggested_fix" in wc and "url" in (wc.get("suggested_fix") or "").lower():
                            wc["suggested_fix"] = fix
                        elif "suggested_fix" not in wc:
                            wc["suggested_fix"] = fix

                if uncommitted:
                    goal_ids = [g.get("goal_id") or g.get("id") for g in uncommitted]
                    result["uncommitted_goals_analysis"] = {
                        "uncommitted_goal_ids": goal_ids,
                        "likely_causes": [
                            "commit_policy='require_all_required' but no required_before_commit fields in schema",
                            "Schema not set on the webhook output (update_webhook_schema was never called)",
                            "Goal was never triggered — the conversation ended before reaching this topic",
                        ],
                        "next_step": (
                            "For each uncommitted goal, call get_template to check: "
                            "(1) does the webhook output have a schema? "
                            "(2) does the schema have required_before_commit: true on any field? "
                            "(3) is commit_policy set to 'require_all_required'? "
                            "All three must be present for the commit gate to work. "
                            "Fix missing pieces with update_webhook_schema + update_goal_commit_rules."
                        ),
                    }
        except Exception:
            pass

        return _env_ok(data=result)

    @mcp.tool()
    async def get_template_issues(
        template_id: str,
        since: str | None = None,
    ) -> str:
        """Get aggregated failure patterns across recent sessions for a template.

        Analyzes your template's outgoing webhook calls to external APIs — not Roxels
        platform health. Suggested fixes describe changes to make in your template config.

        Groups repeated webhook errors by endpoint and failure type so you can
        spot systemic issues at a glance — e.g. "6 sessions failed with 400 on
        the Stripe products endpoint" rather than reviewing sessions one by one.

        Use this when:
          - You've run multiple test sessions and want to see if failures are consistent
          - A template is live and you want a health check across recent traffic
          - You want to prioritize which issue to fix first (sorted by frequency)

        Call get_session_diagnostics(session_id) on any sample_session_id in the
        results for the full request/response breakdown of that failure.

        Args:
            template_id: UUID of the template
            since: Optional ISO 8601 timestamp to limit the window (e.g. "2026-04-01T00:00:00Z")
        """
        result = await client.get_template_issues(template_id, since=since)
        return _env_ok(data=result)

    # ══════════════════════════════════════════════════════════════════════
    # Group 7 — SECRETS
    # Store / list / rotate / delete credentials for webhook headers and data
    # source auth_tokens. Raw values are rejected; always use store_secret.
    # ══════════════════════════════════════════════════════════════════════

    @mcp.tool()
    async def store_secret(name: str, description: str = "") -> str:
        """Store a long-lived secret (API key, service token, webhook signing key) securely
        in Roxels using AWS Secrets Manager.

        ANY API KEY OR STATIC CREDENTIAL that will appear in a webhook header or data-source
        auth_token MUST go through store_secret first. Do not put raw credentials in
        configure_output, update_template, or configure_data_source — the MCP
        will reject them. Always store the secret first, then use the returned {{secret:uuid}}
        reference in your config.

        The two cases and what to use for each:
          A) CALLING AN API ON BEHALF OF THE USER (user is already authenticated in the session)
             Use {{context.authToken}} or other session-context values. These are ephemeral,
             scoped to the user's session, and require no storage.
               headers={"Authorization": "Bearer {{context.authToken}}"}

          B) CALLING A SERVICE API WITH A PLATFORM CREDENTIAL (Stripe, CRM, etc.)
             Use store_secret. The credential is a long-lived service key that belongs to
             your integration, not the user. It goes directly to AWS Secrets Manager —
             never into this conversation or any log — and you get back a reference.
               headers={"Authorization": "Bearer {{secret:uuid}}"}

        This tool does NOT accept the secret value as a parameter. You will be prompted
        to enter it directly in the terminal — it will NOT appear in this conversation,
        in any log, or in the Roxels database. It goes directly to AWS Secrets Manager.
        Only a reference ID is saved.

        Returns a reference like {{secret:uuid}} to use in header/auth_token config.

        Args:
            name: Human-readable name for this secret (e.g. "Stripe Live API Key")
            description: Optional description of what this secret is used for
        """
        import sys
        import getpass

        if sys.stdin.isatty():
            # Interactive terminal — capture value via getpass (hidden, not in logs or agent context)
            border = "─" * 62
            sys.stderr.write(f"\n┌{border}┐\n")
            sys.stderr.write(f"│ Storing: {name:<52}│\n")
            sys.stderr.write(f"│{' ' * 62}│\n")
            sys.stderr.write(f"│ What happens to your secret:                                 │\n")
            sys.stderr.write(f"│   • Sent over TLS to Roxels, written to AWS Secrets Manager  │\n")
            sys.stderr.write(f"│   • Immediately discarded from server memory — never logged  │\n")
            sys.stderr.write(f"│   • Never stored in the Roxels database                      │\n")
            sys.stderr.write(f"│   • Never visible to the AI assistant                        │\n")
            sys.stderr.write(f"│   • Only a reference ID is saved ({{secret:...}})            │\n")
            sys.stderr.write(f"└{border}┘\n")
            sys.stderr.flush()
            value = getpass.getpass("Enter value (hidden, not logged): ")

            if not value:
                return _env_error(error_message="No value entered — secret not stored.")

            try:
                resp = await client._request(
                    "POST", "/v1/secrets",
                    json={"name": name, "value": value, "description": description},
                )
            except Exception as e:
                return _env_error(error_message=f"Failed to store secret: {e}")
            finally:
                del value  # explicit cleanup regardless of success or failure

            secret_id = resp["secret_id"]
        else:
            # Non-interactive (Claude Desktop, CI, piped stdin) — return a one-time submission URL.
            # Print to stderr only (stdout is the MCP stdio protocol stream).
            slot = await client._request("POST", "/v1/secrets/prepare", json={"name": name, "description": description})
            secret_id = slot["secret_id"]
            otp_resp = await client._request("POST", f"/v1/secrets/{secret_id}/prepare-otp")
            sys.stderr.write(f"\n⚠  Non-interactive terminal — secret submission URL generated.\n")
            sys.stderr.flush()
            return _env_ok(
                action="pending",
                data={
                "secret_id": secret_id,
                "reference": f"{{{{secret:{secret_id}}}}}",
                "submission_url": otp_resp["url"],
                "message": (
                    f"Visit the submission URL to enter your secret value securely in the browser "
                    f"(expires in 15 minutes). Once submitted, the reference above is ready to use."
                ),
            })

        return _env_ok(

            action="stored",

            data={
            "secret_id": secret_id,
            "reference": f"{{{{secret:{secret_id}}}}}",
            "message": "Use the reference in configure_output headers or configure_data_source auth_token.",
        })

    @mcp.tool()
    async def list_secrets() -> str:
        """List all secrets stored for your organization.

        Returns id, name, description, status, and created_at for each secret.
        Never returns values or ARNs.
        """
        result = await client._request("GET", "/v1/secrets")
        return _env_ok(data=result)

    @mcp.tool()
    async def update_secret(secret_id: str, name: str | None = None, description: str | None = None) -> str:
        """Update the name or description of a stored secret.

        Does NOT change the secret value — use rotate_secret for that.

        Args:
            secret_id: UUID of the secret (from list_secrets or the reference {{secret:uuid}})
            name: New human-readable name (optional)
            description: New description (optional)
        """
        body = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        result = await client._request("PATCH", f"/v1/secrets/{secret_id}", json=body)
        return _env_ok(data=result)

    @mcp.tool()
    async def rotate_secret(secret_id: str) -> str:
        """Replace the value of an existing secret (e.g. after rotating a compromised key).

        The new value is captured directly in your terminal — it will NOT appear in this
        conversation. All templates referencing this secret update automatically; no
        template edits needed.

        Args:
            secret_id: UUID of the secret to rotate (from list_secrets)
        """
        import sys
        import getpass

        if sys.stdin.isatty():
            border = "─" * 62
            sys.stderr.write(f"\n┌{border}┐\n")
            sys.stderr.write(f"│ Rotating secret {secret_id[:8]}...{' ' * 41}│\n")
            sys.stderr.write(f"│{' ' * 62}│\n")
            sys.stderr.write(f"│ The new value is sent over TLS, written to AWS Secrets       │\n")
            sys.stderr.write(f"│ Manager, and immediately discarded — never logged.           │\n")
            sys.stderr.write(f"└{border}┘\n")
            sys.stderr.flush()
            value = getpass.getpass("Enter new value (hidden, not logged): ")

            if not value:
                return _env_error(error_message="No value entered — secret not rotated.")

            try:
                await client._request(
                    "PUT", f"/v1/secrets/{secret_id}/value",
                    json={"value": value},
                )
            except Exception as e:
                return _env_error(error_message=f"Failed to rotate secret: {e}")
            finally:
                del value
        else:
            otp_resp = await client._request("POST", f"/v1/secrets/{secret_id}/prepare-otp")
            sys.stderr.write(f"\n⚠  Non-interactive terminal — secret rotation URL generated.\n")
            sys.stderr.flush()
            return _env_ok(
                action="pending",
                data={
                "submission_url": otp_resp["url"],
                "message": "Visit the submission URL to enter the new secret value securely in the browser (expires in 15 minutes). All templates referencing this secret will use the new value once submitted.",
            })

        return _env_ok(

            action="rotated",

            data={
            "secret_id": secret_id,
            "message": "Secret value replaced. All templates referencing this secret now use the new value.",
        })

    @mcp.tool()
    async def delete_secret(secret_id: str) -> str:
        """Permanently delete a stored secret.

        Returns an error listing all templates that still reference this secret —
        remove those references first (update configure_output headers or
        configure_data_source auth_token), then call delete_secret again.

        Args:
            secret_id: UUID of the secret to delete (from list_secrets)
        """
        try:
            result = await client._request("DELETE", f"/v1/secrets/{secret_id}")
            return _env_ok(data=result)
        except Exception as e:
            return _env_error(error_message=str(e))

    @mcp.tool()
    async def list_skills(include_system_defaults: bool = True) -> str:
        """List available skills visible to your org.

        Returns skills with pre-digested metadata (summary, recommended_placement, complexity,
        advisor_rationale) — read these to decide where to attach each skill without needing
        to read the full prompt body. Full prompt_section is omitted from this listing.

        Args:
            include_system_defaults: If true (default), includes system-wide default skills
                plus org-owned skills. If false, returns only org-owned skills.

        Use this before configuring template speaker_skills or creating Advisors to see
        what's available and what placement each skill recommends.
        """
        try:
            resp = await client._request("GET", "/v1/skills")
            skills = resp if isinstance(resp, list) else resp.get("skills", [])
            filtered = [
                {k: v for k, v in s.items() if k != "prompt_section"}
                for s in skills
                if include_system_defaults or not s.get("is_default")
            ]
            return _env_ok(data={
                "count": len(filtered),
                "skills": filtered,
                "tip": (
                    "Use recommended_placement ('speaker'/'advisor'/'either') and complexity "
                    "('light'/'medium'/'heavy') to choose where to attach each skill. "
                    "Set speaker_skills on a template to inline skills, or create an Advisor "
                    "(/dashboard/skills) and set advisors on the template for observer loops."
                ),
            })
        except Exception as e:
            return _env_error(error_message=str(e))

    @mcp.tool()
    async def list_skillsets(include_system_defaults: bool = True) -> str:
        """List available skillsets visible to your org.

        A skillset is a named bundle of skills. Use skillsets to attach a coherent group
        of behaviors to a template's speaker side in one reference, and to keep multiple
        templates in sync (editing the skillset updates all templates that reference it).

        Args:
            include_system_defaults: If true (default), includes system-wide default skillsets
                plus org-owned skillsets.
        """
        try:
            resp = await client._request("GET", "/v1/skillsets")
            skillsets = resp if isinstance(resp, list) else resp.get("skillsets", [])
            filtered = [
                s for s in skillsets
                if include_system_defaults or not s.get("is_default")
            ]
            return _env_ok(data={
                "count": len(filtered),
                "skillsets": filtered,
                "tip": (
                    "Set speaker_skillsets on a template to expand the skillset's skills into the "
                    "speaker's system prompt. Skillsets deduplicate with speaker_skills — if a skill "
                    "appears in both, it is included once."
                ),
            })
        except Exception as e:
            return _env_error(error_message=str(e))

    @mcp.tool()
    async def list_advisors() -> str:
        """List advisors owned by your org.

        An advisor is a composable observer persona — each advisor becomes one independent
        observer loop at runtime that reads the live transcript and surfaces suggestions.
        Advisors are org-scoped (no system defaults).

        Use this to see existing advisors before creating new ones — reuse where possible
        rather than duplicating advisor configurations.
        """
        try:
            resp = await client._request("GET", "/v1/advisors")
            advisors = resp if isinstance(resp, list) else resp.get("advisors", [])
            return _env_ok(data={
                "count": len(advisors),
                "advisors": advisors,
                "tip": (
                    "Set advisors on a template's settings to attach observer loops. "
                    "Each advisor adds one LLM call per turn — reserve for precision-critical "
                    "concerns (form validation, compliance, screen narration). "
                    "Create new advisors at /dashboard/skills (Advisors tab)."
                ),
            })
        except Exception as e:
            return _env_error(error_message=str(e))

    @mcp.tool()
    async def get_reference(
        topic: Literal[
            "template",
            "data_source",
            "validation",
            "embed",
            "id_resolution",
            "canonical_spec",
        ],
    ) -> str:
        """Read a Roxels reference document by topic.

        USE WHEN:
          - You need to know what fields, types, or enum values are valid before
            constructing a config.
          - You want to see what a great Roxels template looks like before
            starting an integration.
          - check_template flagged a gap whose fix depends on content that lives
            in one of these references.

        TOPICS:
          "canonical_spec"  — START HERE. What a great Roxels template looks like,
                              by category, with done-criteria + common gaps +
                              tools per category. The big-picture guide.
          "template"        — Full template schema: goal types, goal fields,
                              settings fields, schema field types, output types.
          "data_source"     — Data source configuration reference (shape,
                              fields, auth types, examples, response-shape
                              inference).
          "validation"      — Layer 2 validation rules (require_resolved,
                              required_before_commit, commit_policy, invariants).
          "embed"           — Embed widget configuration (init options,
                              callbacks, security notes, Permissions-Policy).
          "id_resolution"   — Three-tier decision guide (inline enum →
                              context options → data source) for fields that
                              expect structured IDs.

        This tool is read-only and stateless.

        Args:
            topic: One of the six topics above.
        """
        topic_map = {
            "template": TEMPLATE_SCHEMA_REFERENCE,
            "data_source": DATA_SOURCE_REFERENCE,
            "validation": VALIDATION_REFERENCE,
            "embed": EMBED_CONFIG_REFERENCE,
            "id_resolution": ID_RESOLUTION_GUIDANCE,
            "canonical_spec": COMPLETE_TEMPLATE_SPEC,
        }
        return _env_ok(
            action="read",
            data={"topic": topic, "reference": topic_map[topic]},
            tool_name="get_reference",
            loop_phase="reference",
        )

    # ══════════════════════════════════════════════════════════════════════
    # Group 8 — SELF-GUIDING META-TOOLS
    # Ask the MCP what to do next. These tools return concrete next_action
    # blocks derived from the template's current state.
    # ══════════════════════════════════════════════════════════════════════

    @mcp.tool()
    async def get_next_action(template_id: str | None = None) -> str:
        """Return the single most impactful next call for the agent to make.

        The top-level entry point for any confused agent. Reads the current state
        (template gaps, integration_shape status, recent sessions) and returns
        ONE concrete `next_action` with the exact tool + args to call.

        USE WHEN:
          - You don't know what to do next.
          - You just finished some work and want to know what to do next.
          - You want the single highest-impact action without reading every
            docstring or diagnostic output.

        Args:
            template_id: Optional — if given, recommends the next action for
                this specific template. If omitted, recommends an org-level
                next step (find a template, create one, etc.).

        Returns:
            {status, action="recommended", data: {reasoning, alternatives}, next_action}
        """
        if template_id is None:
            # Org-level: suggest listing or creating a template
            return _env_ok(
                action="recommended",
                data={
                    "reasoning": (
                        "No template_id supplied. Without a specific template, the two "
                        "most common next steps are: (1) list existing templates to find "
                        "one to work on, or (2) create a new one interactively by voice."
                    ),
                    "alternatives": [
                        {
                            "tool": "list_templates",
                            "why": "See what already exists in your org.",
                        },
                        {
                            "tool": "setup_by_voice",
                            "why": "Start a voice conversation that builds a new template for you.",
                        },
                    ],
                },
                next_action_block=_env_next_action(
                    tool="list_templates",
                    args={"limit": 20},
                    why="Inspect existing templates before deciding to create a new one.",
                ),
            )

        template, all_gaps = await _collect_template_gaps(template_id)
        settings = template.get("settings", {}) or {}
        shape = settings.get("integration_shape") or {}
        shape_status = shape.get("status")

        # Priority 1: unconfirmed integration_shape blocks coverage-gap checks
        if shape_status and shape_status != "confirmed":
            return _env_ok(
                action="recommended",
                data={
                    "reasoning": (
                        f"Integration shape status is '{shape_status}'. Until it's confirmed, "
                        f"coverage-gap checks are deferred. Read the shape proposal, compare it "
                        f"against your codebase, and either revise or confirm it."
                    ),
                    "gap_count": len(all_gaps),
                },
                next_action_block=_env_next_action(
                    tool="integration_shape",
                    args={"template_id": template_id},
                    why="Read the current shape proposal before anything else.",
                ),
                meta={"template_id": template_id},
            )

        # Priority 2: highest-severity gap from _collect_template_gaps
        if all_gaps:
            severity_rank = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
            top = min(all_gaps, key=lambda g: severity_rank.get(g.get("severity", "LOW"), 99))
            na = _env_format_gap(top)
            return _env_ok(
                action="recommended",
                data={
                    "reasoning": (
                        f"Template has {len(all_gaps)} gap(s). Starting with the "
                        f"{top.get('severity')} one: {top.get('problem')}"
                    ),
                    "remaining_gap_count": len(all_gaps),
                },
                next_action_block=na,
                meta={"template_id": template_id},
            )

        # Priority 3: no gaps — suggest a live test
        return _env_ok(
            action="recommended",
            data={
                "reasoning": (
                    "No gaps detected. The template looks well-configured. The next step "
                    "is to verify live behavior end-to-end: run a test session and read "
                    "the diagnostics before iterating further."
                ),
                "alternatives": [
                    {"tool": "check_template_config", "why": "Run a final structural integrity check."},
                    {"tool": "start_live_session", "why": "Run one end-to-end test conversation."},
                    {"tool": "get_template_recent_sessions", "why": "Check whether real sessions already exposed issues."},
                ],
            },
            next_action_block=_env_next_action(
                tool="start_live_session",
                args={"template_id": template_id},
                why="Run one end-to-end test conversation and read get_session_diagnostics.",
            ),
            meta={"template_id": template_id},
        )

    @mcp.tool()
    async def get_mcp_index() -> str:
        """Return a categorized index of every tool this MCP exposes.

        USE WHEN:
          - You want a map of the tool surface without reading 50+ docstrings.
          - You're looking for the right tool for a task but don't know its name.

        Returns:
            {status, data: {categories: {<category>: [{tool, summary, use_when}]}}}
        """
        index = {
            "Templates": [
                ("list_templates", "Find existing templates in your org."),
                ("get_template", "Read full config for a specific template."),
                ("create_template", "Create a template programmatically."),
                ("update_template", "Update a template's fields (REPLACEMENT semantics — see docstring)."),
                ("setup_by_voice", "[BLOCKING] Create via voice conversation with the setup assistant."),
                ("modify_by_voice", "[BLOCKING] Modify via voice conversation."),
            ],
            "Setup context": [
                ("get_setup_conversation", "Read the onboarding transcript that created a template."),
                ("get_setup_intent", "Read the structured setup intent extracted from onboarding."),
                ("integration_shape(template_id, action)", "Negotiate the delivery shape. action: read / revise / confirm / propose."),
                ("get_runtime_learnings", "See do/don't rules learned from live sessions."),
                ("clear_runtime_learnings", "Reset learnings for a scope or data source."),
                ("ask_roxels", "Freeform Q&A with full product + template context."),
            ],
            "Sessions & participants": [
                ("list_interviews", "List conversations with filters."),
                ("get_interview", "Read one conversation's full results."),
                ("list_persons", "List persons (conversation participants)."),
                ("create_person", "Create a person record."),
            ],
            "Outputs & data sources": [
                ("configure_output", "Add or replace an output on a template."),
                ("configure_output (merge-mode)", "Merge-update fields on an existing output."),
                ("update_webhook_schema", "Set or replace the extraction schema on a webhook output."),
                ("update_goal_commit_rules", "Set commit_policy + invariants on a webhook output."),
                ("configure_data_source", "Register a data source endpoint for resolved_reference fields."),
                ("configure_data_source (merge-mode)", "Merge-update fields on an existing data source."),
                ("list_data_sources", "List a template's data sources."),
                ("remove_data_source", "Delete a data source from a template."),
                ("probe_data_source", "Hit a real data source endpoint with test args."),
            ],
            "Testing": [
                ("check_template_config", "Structural integrity check (no network)."),
                ("simulate_output", "Fire a configured output against its real endpoint with sample data."),
                ("send_http_request", "Raw HTTP passthrough (unbound to template)."),
                ("start_live_session", "Start a real test conversation end-to-end."),
            ],
            "Diagnostics": [
                ("check_template", "Score + gap list + top next_action. The primary convergence tool."),
                ("get_template_recent_sessions", "List recent sessions with health indicators."),
                ("get_session_diagnostics", "Read one session's failure breakdown with fixes."),
                ("get_template_issues", "Aggregated failure patterns across sessions."),
                ("get_next_action", "Single most impactful next call given current state."),
            ],
            "Embedding": [
                ("create_embed_key", "Mint an rk_live_/rk_test_ embed key."),
                ("list_embed_keys", "List embed keys for a template."),
                ("revoke_embed_key", "Revoke an embed key."),
                ("get_embed_code", "Generate HTML/JS snippet for a given embed key."),
                ("check_embed_permissions_policy", "Verify a host page allows microphone."),
            ],
            "Secrets": [
                ("store_secret", "Store an API key securely; returns {{secret:uuid}} reference."),
                ("list_secrets", "List stored secrets."),
                ("update_secret", "Update secret metadata (not the value)."),
                ("rotate_secret", "Rotate the secret value."),
                ("delete_secret", "Delete a secret."),
            ],
            "Skills & advisors": [
                ("list_skills", "List available skills (with placement recommendations)."),
                ("list_skillsets", "List skillsets (named bundles of skills)."),
                ("list_advisors", "List advisors (observer personas) in your org."),
            ],
            "Reference": [
                ("get_reference(topic)", "One tool, six topics: template / data_source / validation / embed / id_resolution / canonical_spec."),
            ],
            "Utility": [
                ("whoami", "Verify API key + org + MCP version."),
                ("get_mcp_index", "This tool — categorized listing of all tools."),
            ],
        }
        categories = {
            cat: [{"tool": t, "summary": s} for (t, s) in entries]
            for cat, entries in index.items()
        }
        return _env_ok(
            action="indexed",
            data={
                "categories": categories,
                "entry_points": [
                    "get_reference(topic='canonical_spec') — read this first for the big picture.",
                    "get_next_action(template_id?) — ask the MCP what to do next.",
                    "ask_roxels(question, template_id?) — freeform Q&A.",
                ],
            },
        )

    async def _verify_webhook_preview(
        template_id: str,
        trigger_goal: str,
        sample_data: dict | str | None = None,
    ) -> str:
        """Dry-run a webhook's body_template + {{context.*}} interpolation — no network.

        USE WHEN:
          - You configured a body_template with {{context.*}} references and want
            to see what the actual POST body will look like before running a live
            test.
          - You suspect interpolation is producing the wrong shape for the target API.

        Resolves the webhook identified by trigger_goal, runs the body_template
        through interpolation with the given sample_data (and sensible defaults
        for missing context keys), and returns the resulting JSON body.

        Args:
            template_id: UUID of the template.
            trigger_goal: The goal id whose webhook to preview.
            sample_data: Optional dict (or JSON string) of sample commit fields.
                Missing fields use the schema's default-or-example value.

        Returns:
            {status, action="previewed", data: {body, content_type, resolved_context_keys, unresolved_placeholders}}
        """
        template = await client.get_template(template_id)
        outputs = template.get("settings", {}).get("outputs", [])
        webhook = next(
            (o for o in outputs
             if o.get("type") == "webhook"
             and o.get("config", {}).get("trigger_goal") == trigger_goal),
            None,
        )
        if webhook is None:
            return _env_not_found(
                resource="webhook output",
                identifier=f"trigger_goal='{trigger_goal}'",
                hint="Use get_template to see configured webhook outputs.",
                next_action_block=_env_next_action(
                    tool="get_template",
                    args={"template_id": template_id, "fields": ["settings"]},
                    why="Inspect the outputs array to find the right trigger_goal.",
                ),
                meta={"template_id": template_id},
            )

        cfg = webhook.get("config", {})
        body_template = cfg.get("body_template")
        schema = cfg.get("schema") or {}
        parsed_sample = (
            json.loads(sample_data) if isinstance(sample_data, str)
            else (sample_data or {})
        )

        # If no body_template, the payload IS the schema-shaped commit data.
        if not body_template:
            sample_body = _generate_sample_from_schema(schema, parsed_sample)
            return _env_ok(
                action="previewed",
                data={
                    "body": sample_body,
                    "content_type": _content_type_for_encoding(cfg.get("body_encoding", "json")),
                    "source": "schema (no body_template configured)",
                    "resolved_context_keys": [],
                    "unresolved_placeholders": [],
                },
                meta={"template_id": template_id, "trigger_goal": trigger_goal},
            )

        # Interpolate {{context.key}} and {{field}} using sample_data + defaults
        rendered, resolved, unresolved = _interpolate_body_template(
            body_template, parsed_sample, schema
        )
        return _env_ok(
            action="previewed",
            data={
                "body": rendered,
                "content_type": _content_type_for_encoding(cfg.get("body_encoding", "json")),
                "source": "body_template",
                "resolved_context_keys": resolved,
                "unresolved_placeholders": unresolved,
            },
            meta={"template_id": template_id, "trigger_goal": trigger_goal},
        )

    @mcp.tool()
    async def whoami() -> str:
        """Check that your API key is valid, see basic org info, and verify MCP version.

        Use this to verify your Roxels connection is working and check which version you're running.
        """
        from importlib.metadata import version as pkg_version
        try:
            mcp_version = pkg_version("roxels-mcp")
        except Exception:
            mcp_version = "unknown"
        result = await client.whoami()
        result["mcp_version"] = mcp_version
        return _env_ok(data=result)

    async def _verify_embed_permissions(url: str) -> str:
        """Check whether a page allows the microphone for a Roxels embed.

        The Roxels widget needs microphone access to listen. When the host page
        sets a restrictive Permissions-Policy (or legacy Feature-Policy) that
        blocks microphone, the embedded agent cannot hear the user — and the
        failure is typically silent. This is the most common reason a Roxels
        embed appears to "just not work."

        This tool:
          1. Fetches the URL (GET, no auth, short timeout).
          2. Inspects the Permissions-Policy and Feature-Policy response headers.
          3. Inspects any <meta http-equiv="Permissions-Policy" ...> in the HTML.
          4. Fingerprints the hosting platform (Cloudflare, Vercel, Netlify,
             CloudFront, Fastly, nginx) from response headers so the caller
             knows where to change the policy.
          5. Returns a structured verdict plus concrete guidance.

        Use this BEFORE embedding the Roxels widget on a host page. If the
        verdict is `blocked` or `restricted`, fix the policy first — no amount
        of widget-side tweaking can override a Permissions-Policy block.

        Args:
            url: The full URL of the page where the Roxels widget will be
                 embedded (e.g. "https://app.example.com/onboarding"). Must
                 include scheme.

        Returns:
            JSON with:
              - microphone_status: "allowed" | "same_origin_only" | "allowlist"
                | "blocked" | "unknown" (policy header absent → browser default
                applies, which IS "allowed" for same-origin iframes; flagged
                as "unknown" when no policy is set so the caller confirms).
              - allows_roxels_embed: true | false | "unknown" — whether the
                policy as written will permit the Roxels widget iframe
                (served from app.roxels.ai) to use the microphone.
              - source: where the microphone directive was found
                ("permissions_policy_header", "feature_policy_header",
                "meta_tag", or "default_no_policy_set").
              - raw_directive: the exact microphone=... clause we parsed,
                if any.
              - platform_hint: best-guess hosting platform
                ("cloudflare", "vercel", "netlify", "cloudfront", "fastly",
                "nginx", "unknown").
              - guidance: human-readable next steps, platform-specific when
                possible.
              - fetched_status: HTTP status code of the GET.
              - error: present only if the fetch itself failed.
        """
        import httpx
        from urllib.parse import urlparse

        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            return _env_ok(data={
                "error": "Invalid URL — must include scheme (http/https) and host.",
                "url": url,
            })

        headers_out = {
            "User-Agent": "Mozilla/5.0 (compatible; RoxelsMCP/1.0; +https://roxels.ai)",
            "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
        }

        try:
            async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as http:
                resp = await http.get(url, headers=headers_out)
        except httpx.TimeoutException:
            return _env_ok(data={
                "error": "Request timed out after 10s.",
                "url": url,
                "guidance": "The host page took too long to respond. Try again, or verify the URL is reachable.",
            })
        except httpx.HTTPError as e:
            return _env_ok(data={
                "error": f"HTTP error fetching URL: {e}",
                "url": url,
            })

        resp_headers = {k.lower(): v for k, v in resp.headers.items()}
        body_text = resp.text[:200_000] if resp.text else ""

        # ── Platform fingerprint ──────────────────────────────────────────────
        platform = "unknown"
        if "cf-ray" in resp_headers or "cloudflare" in resp_headers.get("server", "").lower():
            platform = "cloudflare"
        elif "x-vercel-id" in resp_headers or "vercel" in resp_headers.get("server", "").lower():
            platform = "vercel"
        elif "x-nf-request-id" in resp_headers or "netlify" in resp_headers.get("server", "").lower():
            platform = "netlify"
        elif "x-amz-cf-id" in resp_headers or "cloudfront" in resp_headers.get("via", "").lower():
            platform = "cloudfront"
        elif "x-served-by" in resp_headers and "fastly" in resp_headers.get("x-served-by", "").lower():
            platform = "fastly"
        elif "nginx" in resp_headers.get("server", "").lower():
            platform = "nginx"
        elif resp_headers.get("server"):
            platform = resp_headers["server"].split("/")[0].lower() or "unknown"

        # ── Collect candidate policy strings (in priority order) ──────────────
        # Meta tags OVERRIDE response headers in the browser for Permissions-Policy,
        # but the header is the more common place to set it. We parse both and
        # report whichever expresses a microphone directive.
        candidates = []  # list of (source, raw_value)
        if "permissions-policy" in resp_headers:
            candidates.append(("permissions_policy_header", resp_headers["permissions-policy"]))
        if "feature-policy" in resp_headers:
            candidates.append(("feature_policy_header", resp_headers["feature-policy"]))

        # Meta tags — cheap regex, not a full HTML parse
        for m in re.finditer(
            r'<meta\s+[^>]*http-equiv\s*=\s*["\']?(?P<equiv>[^"\'>\s]+)["\']?[^>]*content\s*=\s*["\'](?P<content>[^"\']+)["\']',
            body_text,
            re.IGNORECASE,
        ):
            equiv = m.group("equiv").lower()
            content = m.group("content")
            if equiv in ("permissions-policy", "feature-policy"):
                candidates.append(("meta_tag", content))

        # ── Parse microphone directive from candidates ────────────────────────
        def parse_mic(policy_str: str) -> tuple[str | None, str | None]:
            """Return (directive_text, status) where status is one of:
            'allowed', 'same_origin_only', 'allowlist', 'blocked'."""
            # Permissions-Policy syntax: "microphone=(), camera=*, geolocation=(self)"
            # Feature-Policy syntax:     "microphone 'none'; camera *; geolocation 'self'"
            # Try Permissions-Policy form first (comma-separated, = with parens)
            for directive in re.split(r",\s*", policy_str):
                d = directive.strip()
                pp_match = re.match(r"microphone\s*=\s*(.+)$", d, re.IGNORECASE)
                if pp_match:
                    val = pp_match.group(1).strip()
                    if val == "()" or val == "( )":
                        return d, "blocked"
                    if val == "*":
                        return d, "allowed"
                    if val.lower() in ("(self)", "self", "'self'"):
                        return d, "same_origin_only"
                    # parenthesized list with origins
                    if val.startswith("(") and val.endswith(")"):
                        inner = val[1:-1].strip()
                        if not inner:
                            return d, "blocked"
                        if "self" in inner.lower() and not any(
                            c in inner for c in ['"', "'"]
                        ) and inner.lower() == "self":
                            return d, "same_origin_only"
                        return d, "allowlist"
            # Try Feature-Policy form (semicolon-separated, space, quoted tokens)
            for directive in re.split(r";\s*", policy_str):
                d = directive.strip()
                fp_match = re.match(r"microphone\s+(.+)$", d, re.IGNORECASE)
                if fp_match:
                    val = fp_match.group(1).strip()
                    if val.lower() in ("'none'", "none"):
                        return d, "blocked"
                    if val == "*":
                        return d, "allowed"
                    if val.lower() in ("'self'", "self"):
                        return d, "same_origin_only"
                    return d, "allowlist"
            return None, None

        verdict = {
            "url": url,
            "fetched_status": resp.status_code,
            "platform_hint": platform,
        }

        found_source = None
        found_directive = None
        found_status = None
        allowlist_has_roxels = False
        for source, raw in candidates:
            directive, status = parse_mic(raw)
            if status is not None:
                found_source = source
                found_directive = directive
                found_status = status
                if status == "allowlist":
                    allowlist_has_roxels = "app.roxels.ai" in (directive or "")
                break  # first match wins (mirrors browser behavior for header)

        if found_status is None:
            verdict["microphone_status"] = "unknown"
            verdict["allows_roxels_embed"] = "unknown"
            verdict["source"] = "default_no_policy_set"
            verdict["raw_directive"] = None
            verdict["guidance"] = (
                "No Permissions-Policy or Feature-Policy for microphone was found on this "
                "response. By browser default, iframes can request microphone permission — "
                "so the Roxels embed should work. However, confirm by testing: if mic access "
                "is denied in the live embed, a policy may be applied at a CDN or edge layer "
                "that didn't appear on this GET (e.g. auth-gated routes). Load the actual "
                "page in a browser, open DevTools → Network → main document response, and "
                "inspect `permissions-policy` there."
            )
        else:
            verdict["microphone_status"] = found_status
            verdict["source"] = found_source
            verdict["raw_directive"] = found_directive
            if found_status == "allowed":
                verdict["allows_roxels_embed"] = True
            elif found_status == "allowlist":
                verdict["allows_roxels_embed"] = bool(allowlist_has_roxels)
            elif found_status == "same_origin_only":
                verdict["allows_roxels_embed"] = False  # Roxels iframe is cross-origin
            else:  # blocked
                verdict["allows_roxels_embed"] = False

        # ── Build platform-specific guidance when needed ──────────────────────
        if verdict["allows_roxels_embed"] is True:
            verdict["guidance"] = (
                "Microphone is permitted for this page. The Roxels embed should "
                "be able to capture audio. Proceed with embedding."
            )
        elif verdict["allows_roxels_embed"] == "unknown":
            # guidance already set to the "no policy header found" message above.
            # Leave it — the default-permissive case should NOT read as a block.
            pass
        else:
            base_fix = (
                "The Roxels widget iframe is served from app.roxels.ai. To let it "
                "use the microphone, the host page must send a Permissions-Policy "
                'header like: `Permissions-Policy: microphone=(self "https://app.roxels.ai")`. '
                "Alternatively, use `microphone=*` if you want to allow microphone for "
                "any iframe."
            )
            platform_guidance = {
                "cloudflare": (
                    "Detected Cloudflare. Response headers can be set via: "
                    "(a) a Cloudflare Transform Rule → Modify Response Header, or "
                    "(b) a Workers route that sets headers on origin responses. "
                    "If Cloudflare is ADDING a restrictive policy, check Rules → "
                    "Transform Rules or any Workers in front of this route."
                ),
                "vercel": (
                    "Detected Vercel. Set the header in `vercel.json` under "
                    '`"headers"` for the relevant route, or in `next.config.js` '
                    "via the `headers()` async function. Deploy to apply."
                ),
                "netlify": (
                    "Detected Netlify. Add the header to `netlify.toml` under "
                    "`[[headers]]` with the path pattern for this page, or to a "
                    "`_headers` file in your publish directory."
                ),
                "cloudfront": (
                    "Detected CloudFront. Use a Response Headers Policy attached "
                    "to the distribution's behavior, or a Lambda@Edge / "
                    "CloudFront Function that adds the header."
                ),
                "fastly": (
                    "Detected Fastly. Add a VCL snippet in the `deliver` subroutine "
                    "that sets `resp.http.Permissions-Policy`, or configure via the "
                    "Fastly UI → Content → Headers."
                ),
                "nginx": (
                    "Detected nginx. In the relevant `server` or `location` block, "
                    'add: `add_header Permissions-Policy \'microphone=(self "https://app.roxels.ai")\' always;` '
                    "and reload nginx."
                ),
            }.get(platform)
            verdict["guidance"] = (
                f"Microphone is {verdict['microphone_status'].replace('_', ' ')} "
                f"for this page — the Roxels embed will NOT be able to listen "
                f"unless you change this. "
                f"{base_fix} "
                + (platform_guidance + " " if platform_guidance else "")
                + "After changing the header, re-run check_embed_permissions_policy on this URL to confirm."
            )

        return _env_ok(data=verdict)

    return mcp
