from typing import List, Literal, Optional, Union

import torch
from PIL.Image import Image

from .asthana_iclr2026 import asthana_iclr2026 as _asthana_iclr2026
from .hintersdorf_nips2024 import hintersdorf_nips2024 as _hintersdorf_nips2024
from .jain_cvpr2025 import jain_cvpr2025_dynamic as _jain_cvpr2025_dynamic
from .ren_eccv2024 import ren_eccv2024 as _ren_eccv2024
from .wen_iclr2024 import wen_iclr2024 as _wen_iclr2024

__all__ = [
    "MemorizationMitigator",
]


class MemorizationMitigator:
    def __init__(
        self,
        pipe,
        strategy: Literal[
            "wen_iclr2024",
            "ren_eccv2024",
            "hintersdorf_nips2024",
            "jain_cvpr2025",
            "asthana_iclr2026",
        ] = "jain_cvpr2025",
    ) -> None:
        self._pipe = pipe
        self._strategy = strategy
        self._strategies = {
            "wen_iclr2024": _wen_iclr2024,
            "ren_eccv2024": _ren_eccv2024,
            "hintersdorf_nips2024": _hintersdorf_nips2024,
            "jain_cvpr2025": _jain_cvpr2025_dynamic,
            "asthana_iclr2026": _asthana_iclr2026,
        }

    def to(self, device: Optional[Union[str, torch.device]]) -> "MemorizationMitigator":
        self._pipe.to(device)
        return self

    def __call__(
        self,
        prompt: List[str],
        seed: Optional[Union[int, List[int]]] = None,
        verbose: bool = False,
        **kwargs,
    ) -> List[Image]:
        return self._strategies[self._strategy](
            prompt, self._pipe, seed, verbose, **kwargs
        )
