"""
Todo list formatting utilities for terminal display.

Provides a clean, aligned rendering shared by both
TodoReadToolResolver and TodoWriteToolResolver.
"""

from typing import Any, Dict, List, Optional
import shutil

STATUS_ICONS = {
    "pending": "\u2610",       # ☐
    "in_progress": "\u25b6",   # ▶
    "completed": "\u2714",     # ✔
    "cancelled": "\u2716",     # ✖
}

PRIORITY_MARKERS = {
    "high": "!!!",
    "medium": "!!",
    "low": "!",
}


def _terminal_width() -> int:
    try:
        return shutil.get_terminal_size((80, 24)).columns
    except Exception:
        return 80


def _short_id(todo_id: str, length: int = 0) -> str:
    if not todo_id:
        return "???"
    if length <= 0:
        return todo_id
    return todo_id[:length]


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "\u2026"  # …


def format_todo_list(
    todos: List[Dict[str, Any]],
    stats: Optional[Dict[str, Any]] = None,
    title: str = "Todo List",
    highlight_ids: Optional[set] = None,
) -> str:
    """Render a todo list as a compact, aligned table.

    Parameters
    ----------
    todos : list
        Each item should have keys: todo_id, content, status, priority.
        Optional: notes, dependencies.
    stats : dict or None
        Pre-computed statistics (total, pending, in_progress, completed, cancelled).
        If *None*, stats are derived from *todos*.
    title : str
        Title shown above the list.
    highlight_ids : set or None
        If given, items whose ``todo_id`` is in this set get a leading marker.
    """
    if not todos:
        return f"  {title}: (empty)"

    tw = _terminal_width()

    # ── header ──────────────────────────────────
    lines: list[str] = []
    header_bar = "\u2500" * min(tw, 60)  # ─
    lines.append(f"  {header_bar}")
    lines.append(f"  {title}")
    lines.append(f"  {header_bar}")

    # ── items ───────────────────────────────────
    idx_width = len(str(len(todos)))
    # Fixed prefix: "  {idx}. {status} {prio} [{id}] "
    #                2 + idx_width + 2 + 1 + 1 + 3 + 1 + 1 + 7 + 2 + 1 = ~21
    prefix_overhead = 2 + idx_width + 2 + 1 + 1 + 3 + 1 + 1 + 7 + 2 + 1
    max_content = max(tw - prefix_overhead, 30)

    for idx, todo in enumerate(todos, 1):
        status = todo.get("status", "pending")
        priority = todo.get("priority", "medium")
        todo_id = todo.get("todo_id", "???")
        content = todo.get("content", "")

        s_icon = STATUS_ICONS.get(status, "?")
        p_mark = PRIORITY_MARKERS.get(priority, " ")
        sid = _short_id(todo_id)
        mark = "*" if (highlight_ids and todo_id in highlight_ids) else " "

        content_display = _truncate(content, max_content)

        lines.append(
            f" {mark}{idx:>{idx_width}}. {s_icon} {p_mark:<3} [{sid}] {content_display}"
        )

        if todo.get("notes"):
            note = _truncate(todo["notes"], max_content - 4)
            lines.append(f"  {' ' * idx_width}          \u2514\u2500 {note}")

        if todo.get("dependencies"):
            deps = ", ".join(todo["dependencies"])
            deps = _truncate(deps, max_content - 10)
            lines.append(
                f"  {' ' * idx_width}          \u2514\u2500 deps: {deps}"
            )

    # ── summary ─────────────────────────────────
    if stats is None:
        stats = _compute_stats(todos)

    total = stats.get("total", len(todos))
    parts: list[str] = [f"total {total}"]
    for key, icon in STATUS_ICONS.items():
        cnt = stats.get(key, 0)
        if cnt > 0:
            label = key.replace("_", " ")
            parts.append(f"{icon} {label} {cnt}")

    lines.append(f"  {header_bar}")
    lines.append(f"  {' | '.join(parts)}")

    return "\n".join(lines)


def _compute_stats(todos: List[Dict[str, Any]]) -> Dict[str, Any]:
    stats: Dict[str, Any] = {"total": len(todos)}
    for key in ("pending", "in_progress", "completed", "cancelled"):
        stats[key] = sum(1 for t in todos if t.get("status") == key)
    return stats
