"""
Unified helpers for locating and invoking ``auto-coder.run`` as a subprocess.

Every call-site that needs to spawn ``auto-coder.run`` (SubagentClient CLI
backend, AsyncExecutor, run_named_subagents, …) should import from here instead
of maintaining its own ``_get_command_path`` / ``_build_env`` copy.
"""

import os
import platform
import shutil
import sys
from pathlib import Path
from typing import Dict, Optional


def get_command_path(command: str) -> str:
    """Resolve the full path to *command*.

    Resolution priority:
    1. Already an absolute path → return as-is.
    2. Inside the **current Python interpreter's environment** (``bin`` /
       ``Scripts`` next to ``sys.executable``).  This handles ``conda pack``
       / ``unpack`` where the env's ``bin`` is not on ``$PATH``.
    3. ``shutil.which()`` — standard ``$PATH`` lookup.
    4. On Windows, also try the ``.exe`` variant.
    5. Last resort: return the bare *command* name.
    """
    if os.path.isabs(command):
        return command

    env_path = _find_in_current_env(command)
    if env_path is not None:
        return env_path

    full_path = shutil.which(command)
    if full_path:
        return full_path

    if platform.system() == "Windows":
        full_path = shutil.which(f"{command}.exe")
        if full_path:
            return full_path

    return command


def build_env() -> Dict[str, str]:
    """Build environment variables dict for a child process.

    On Windows, automatically injects UTF-8 encoding variables.
    """
    env = os.environ.copy()

    if platform.system() == "Windows":
        env.update(
            {
                "PYTHONIOENCODING": "utf-8",
                "LANG": "zh_CN.UTF-8",
                "LC_ALL": "zh_CN.UTF-8",
            }
        )

    return env


def _find_in_current_env(command: str) -> Optional[str]:
    """Try to locate *command* inside the current Python environment.

    On Unix / macOS the script lives next to ``sys.executable``
    (e.g. ``/path/to/env/bin/auto-coder.run``).

    On Windows, ``pip install`` places scripts either in the same
    directory as ``python.exe`` or in the ``Scripts`` sub-directory,
    and the script may have an ``.exe`` extension.
    """
    env_bin = Path(sys.executable).resolve().parent

    if platform.system() == "Windows":
        candidates = [
            env_bin / f"{command}.exe",
            env_bin / command,
            env_bin / "Scripts" / f"{command}.exe",
            env_bin / "Scripts" / command,
        ]
    else:
        candidates = [env_bin / command]

    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)

    return None
