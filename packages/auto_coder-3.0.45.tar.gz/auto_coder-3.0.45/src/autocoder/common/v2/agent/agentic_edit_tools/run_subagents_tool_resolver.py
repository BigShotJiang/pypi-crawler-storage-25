"""
Run Subagents Tool Resolver

通过 SubagentClient 统一 API 执行子代理，支持 in_process / cli_process /
external_cli_process 后端切换和并发控制（max_concurrency）。

每个 subagent 强制使用全新独立会话（share_mode=NEW），禁止任何会话共享或恢复。

实现了 resolve_stream()，在子代理执行期间向 TUI 推送进度信息
（ToolStreamEvent），避免长时间无反馈。
"""

import json
import typing
from concurrent.futures import Future, as_completed
from typing import Any, Dict, Generator, List, Optional

import yaml
from loguru import logger

from autocoder.common import AutoCoderArgs
from autocoder.common.v2.agent.agentic_edit_tools.base_tool_resolver import (
    BaseToolResolver,
)
from autocoder.common.v2.agent.agentic_edit_types import (
    RunSubagentsTool,
    ToolResult,
)

if typing.TYPE_CHECKING:
    from autocoder.common.v2.agent.agentic_edit import AgenticEdit
    from autocoder.common.v2.agent.subagents import (
        SubagentBackend,
        SubagentClient,
        SubagentRequest,
        SubagentResult,
    )


class RunSubagentsToolResolver(BaseToolResolver):
    """通过 SubagentClient 执行子代理的工具解析器。

    与 RunNamedSubagentsToolResolver 的区别：
    - 使用 SubagentClient 统一 API 而非 shell 命令拼接
    - 支持 in_process（默认）、cli_process 和 external_cli_process 三种后端
    - 通过 max_concurrency 参数控制并行度
    - 返回结构化 SubagentResult
    - 强制每个 subagent 使用全新独立会话（share_mode=NEW）
    """

    def __init__(
        self,
        agent: Optional["AgenticEdit"],
        tool: RunSubagentsTool,
        args: AutoCoderArgs,
    ):
        super().__init__(agent, tool, args)
        self.tool: RunSubagentsTool = tool

    def resolve(self) -> ToolResult:
        from autocoder.common.v2.agent.agentic_edit_tools.run_named_subagents_tool_resolver import (
            _check_subagent_recursion,
        )

        blocked = _check_subagent_recursion(self.agent)
        if blocked is not None:
            return blocked

        from autocoder.common.v2.agent.subagents import (
            SubagentBackend,
            SubagentClient,
        )

        subagents_str = self.tool.subagents
        backend_str = (self.tool.backend or "in_process").strip().lower()
        max_concurrency = self.tool.max_concurrency

        logger.info(
            f"RunSubagentsToolResolver: backend={backend_str}, "
            f"max_concurrency={max_concurrency}"
        )

        try:
            backend = self._parse_backend(backend_str)
        except ValueError as e:
            return ToolResult(
                success=False,
                message=str(e),
                content={"error_type": "invalid_backend"},
            )

        try:
            parsed = self._parse_subagents_config(subagents_str)
            if not parsed["success"]:
                return ToolResult(
                    success=False,
                    message=parsed["error"],
                    content={"error_type": "config_parse_error"},
                )

            subagents_list: List[Dict[str, str]] = parsed["subagents"]
            execution_mode: str = parsed["mode"]

            logger.info(
                f"Parsed {len(subagents_list)} subagents, mode={execution_mode}"
            )

            validation = self._validate_subagents(subagents_list)
            if not validation["success"]:
                return ToolResult(
                    success=False,
                    message=validation["error"],
                    content={
                        "error_type": "agent_validation_error",
                        "details": validation["details"],
                    },
                )

            requests = self._build_requests(subagents_list, backend)

            llm = self.agent.llm if self.agent else None
            client = SubagentClient(
                args=self.args,
                llm=llm,
                project_root=self.args.source_dir or ".",
            )

            parallel = execution_mode == "parallel"
            results = client.run_many(
                requests,
                parallel=parallel,
                max_workers=max_concurrency,
            )

            return self._build_tool_result(results, subagents_list, execution_mode)

        except Exception as e:
            logger.exception("RunSubagentsToolResolver error")
            return ToolResult(
                success=False,
                message=f"执行子代理时发生错误: {e}",
                content={"error_type": "execution_error", "error_details": str(e)},
            )

    # ── streaming interface ──

    def resolve_stream(self) -> Generator[str, None, ToolResult]:
        """流式执行子代理，逐步 yield 进度文本，最终 return ToolResult。

        在 terminal_v3 TUI 中，ToolStreamEvent 会实时显示在对话区，
        让用户了解子代理的执行进展，而不是长时间看到 "Generating..."。
        """
        from autocoder.common.v2.agent.agentic_edit_tools.run_named_subagents_tool_resolver import (
            _check_subagent_recursion as _guard,
        )

        blocked = _guard(self.agent)
        if blocked is not None:
            return blocked

        from autocoder.common.v2.agent.subagents import (
            SubagentBackend,
            SubagentClient,
            SubagentResult,
        )

        subagents_str = self.tool.subagents
        backend_str = (self.tool.backend or "in_process").strip().lower()
        max_concurrency = self.tool.max_concurrency

        try:
            backend = self._parse_backend(backend_str)
        except ValueError as e:
            return ToolResult(
                success=False,
                message=str(e),
                content={"error_type": "invalid_backend"},
            )

        try:
            parsed = self._parse_subagents_config(subagents_str)
            if not parsed["success"]:
                return ToolResult(
                    success=False,
                    message=parsed["error"],
                    content={"error_type": "config_parse_error"},
                )

            subagents_list: List[Dict[str, str]] = parsed["subagents"]
            execution_mode: str = parsed["mode"]

            validation = self._validate_subagents(subagents_list)
            if not validation["success"]:
                return ToolResult(
                    success=False,
                    message=validation["error"],
                    content={
                        "error_type": "agent_validation_error",
                        "details": validation["details"],
                    },
                )

            requests = self._build_requests(subagents_list, backend)
            llm = self.agent.llm if self.agent else None
            client = SubagentClient(
                args=self.args,
                llm=llm,
                project_root=self.args.source_dir or ".",
            )

            total = len(requests)
            agent_names = [
                subagents_list[i].get("name", f"agent-{i}")
                for i in range(total)
            ]
            parallel = execution_mode == "parallel"

            if backend_str == "external_cli_process":
                model_display = "external CLI default"
            else:
                model_display = self.args.model or "unknown"
            yield f"Starting {total} sub-agents ({execution_mode} mode, backend={backend_str}, model={model_display})...\n"
            for i, name in enumerate(agent_names):
                task_preview = subagents_list[i]["task"][:60]
                yield f"  [{i+1}] {name}: {task_preview}...\n"

            if not parallel or total == 1:
                results = self._run_serial_with_progress(
                    client, requests, agent_names,
                )
            else:
                results = self._run_parallel_with_progress(
                    client, requests, agent_names, max_concurrency,
                )

            return self._build_tool_result(results, subagents_list, execution_mode)

        except Exception as e:
            logger.exception("RunSubagentsToolResolver stream error")
            return ToolResult(
                success=False,
                message=f"执行子代理时发生错误: {e}",
                content={"error_type": "execution_error", "error_details": str(e)},
            )

    @staticmethod
    def _needs_stdio_suppression(requests: List["SubagentRequest"]) -> bool:
        """Only suppress stdio when at least one request uses IN_PROCESS backend."""
        from autocoder.common.v2.agent.subagents import SubagentBackend

        return any(
            (r.backend or SubagentBackend.IN_PROCESS) == SubagentBackend.IN_PROCESS
            for r in requests
        )

    def _run_serial_with_progress(
        self,
        client: "SubagentClient",
        requests: List["SubagentRequest"],
        agent_names: List[str],
    ) -> List["SubagentResult"]:
        """串行执行并返回结果列表。"""
        from autocoder.common.v2.agent.subagents.client import _suppress_stdio, _noop_ctx

        ctx = _suppress_stdio if self._needs_stdio_suppression(requests) else _noop_ctx
        with ctx():
            return [client.run(r) for r in requests]

    def _run_parallel_with_progress(
        self,
        client: "SubagentClient",
        requests: List["SubagentRequest"],
        agent_names: List[str],
        max_concurrency: Optional[int],
    ) -> List["SubagentResult"]:
        """并行执行，通过 logger 记录进度。"""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        from autocoder.common.v2.agent.subagents import SubagentResult
        from autocoder.common.v2.agent.subagents.client import _suppress_stdio, _noop_ctx

        results: List[Optional[SubagentResult]] = [None] * len(requests)
        effective_workers = (
            max_concurrency if max_concurrency is not None and max_concurrency > 0
            else len(requests)
        )

        ctx = _suppress_stdio if self._needs_stdio_suppression(requests) else _noop_ctx
        with ctx():
            with ThreadPoolExecutor(max_workers=effective_workers) as pool:
                future_to_idx = {
                    pool.submit(client.run, req): idx
                    for idx, req in enumerate(requests)
                }
                for future in as_completed(future_to_idx):
                    idx = future_to_idx[future]
                    name = agent_names[idx]
                    try:
                        results[idx] = future.result()
                        status = "✓" if results[idx].success else "✗"
                        logger.info(f"Sub-agent [{idx+1}] {name} completed: {status}")
                    except Exception:
                        logger.exception(f"Sub-agent [{idx+1}] {name} failed")
                        import traceback
                        results[idx] = SubagentResult(
                            success=False,
                            backend=requests[idx].backend,
                            error=traceback.format_exc(),
                        )

        return results  # type: ignore[return-value]

    @staticmethod
    def _parse_backend(backend_str: str) -> "SubagentBackend":
        from autocoder.common.v2.agent.subagents import SubagentBackend

        mapping = {
            "in_process": SubagentBackend.IN_PROCESS,
            "cli_process": SubagentBackend.CLI_PROCESS,
            "external_cli_process": SubagentBackend.EXTERNAL_CLI_PROCESS,
        }
        if backend_str not in mapping:
            raise ValueError(
                f"无效的 backend: '{backend_str}'，"
                f"必须是 'in_process'、'cli_process' 或 'external_cli_process'"
            )
        return mapping[backend_str]

    @staticmethod
    def _parse_subagents_config(subagents_str: str) -> Dict[str, Any]:
        """解析 JSON / YAML 格式的子代理配置。"""
        try:
            try:
                json_data = json.loads(subagents_str)
                if isinstance(json_data, list):
                    return {"success": True, "subagents": json_data, "mode": "parallel"}
                return {
                    "success": False,
                    "error": "JSON 格式必须是数组: [{\"name\": ..., \"task\": ...}]",
                }
            except json.JSONDecodeError:
                pass

            try:
                yaml_data = yaml.safe_load(subagents_str)
                if isinstance(yaml_data, dict) and "subagents" in yaml_data:
                    mode = yaml_data.get("mode", "parallel")
                    if mode not in ("parallel", "serial"):
                        return {
                            "success": False,
                            "error": f"无效的执行模式: {mode}，必须是 'parallel' 或 'serial'",
                        }
                    subagents = yaml_data["subagents"]
                    if not isinstance(subagents, list):
                        return {
                            "success": False,
                            "error": "YAML 中 subagents 必须是列表",
                        }
                    return {"success": True, "subagents": subagents, "mode": mode}
                elif isinstance(yaml_data, list):
                    return {"success": True, "subagents": yaml_data, "mode": "parallel"}
                else:
                    return {
                        "success": False,
                        "error": "YAML 格式必须包含 'subagents' 字段或直接为列表",
                    }
            except yaml.YAMLError as e:
                return {"success": False, "error": f"YAML 解析错误: {e}"}

        except Exception as e:
            return {"success": False, "error": f"配置解析失败: {e}"}

    def _validate_subagents(
        self, subagents_list: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """校验格式和必填字段。

        注意：run_subagents 是通用工具，不会加载 .autocoderagents 中的 agent
        定义。name 仅用于展示标签，不会触发 agent spec 查找或模型回填。
        如需使用预定义 agent，请使用 run_named_subagents。
        """
        errors: List[str] = []

        for i, entry in enumerate(subagents_list):
            if not isinstance(entry, dict):
                errors.append(f"子代理 {i}: 必须是字典格式")
                continue
            if "task" not in entry:
                errors.append(f"子代理 {i}: 缺少 'task' 字段")
                continue
            if not entry["task"] or not entry["task"].strip():
                errors.append(f"子代理 {i}: task 不能为空")

        if errors:
            msg = "子代理验证失败:\n" + "\n".join(errors)
            return {"success": False, "error": msg, "details": errors}

        return {"success": True}

    def _build_requests(
        self,
        subagents_list: List[Dict[str, str]],
        backend: "SubagentBackend",
    ) -> List["SubagentRequest"]:
        from autocoder.common.v2.agent.subagents import (
            ExternalCLIType,
            SubagentBackend as _SubagentBackend,
            SubagentRequest,
            SubagentSessionOptions,
            SubagentSessionShareMode,
        )

        requests: List[SubagentRequest] = []
        timeout = self.args.call_subagent_timeout
        tool_external_cli = self.tool.external_cli

        for entry in subagents_list:
            task = entry["task"]
            agent_name = entry.get("name") or None
            model = entry.get("model") or None

            external_cli: Optional[ExternalCLIType] = None
            if backend == _SubagentBackend.EXTERNAL_CLI_PROCESS:
                external_cli_str = entry.get("external_cli") or tool_external_cli
                if external_cli_str:
                    external_cli = ExternalCLIType(external_cli_str)

            requests.append(
                SubagentRequest(
                    task=task,
                    agent_name=agent_name,
                    backend=backend,
                    external_cli=external_cli,
                    model=model,
                    timeout_seconds=int(timeout) if timeout else None,
                    session=SubagentSessionOptions(
                        share_mode=SubagentSessionShareMode.NEW,
                    ),
                    resolve_agent_spec=False,
                )
            )

        return requests

    @staticmethod
    def _build_tool_result(
        results: List["SubagentResult"],
        subagents_list: List[Dict[str, str]],
        execution_mode: str,
    ) -> ToolResult:
        successful = 0
        failed = 0
        detailed: List[Dict[str, Any]] = []

        for i, result in enumerate(results):
            entry = (
                subagents_list[i]
                if i < len(subagents_list)
                else {"task": "unknown"}
            )
            status = "success" if result.success else "failed"
            if result.success:
                successful += 1
            else:
                failed += 1

            detailed.append(
                {
                    "agent_name": entry.get("name", f"agent-{i}"),
                    "task": entry["task"],
                    "status": status,
                    "backend": result.backend.value if result.backend else None,
                    "conversation_id": result.conversation_id,
                    "attempt_result": result.attempt_result or None,
                    "error": result.error,
                }
            )

        all_ok = failed == 0
        total = len(subagents_list)

        if all_ok:
            message = f"所有 {total} 个子代理执行成功"
        else:
            message = (
                f"子代理执行完成: {successful}/{total} 成功, {failed}/{total} 失败"
            )

        return ToolResult(
            success=all_ok,
            message=message,
            content={
                "execution_mode": execution_mode,
                "total_subagents": total,
                "successful_count": successful,
                "failed_count": failed,
                "results": detailed,
            },
        )
