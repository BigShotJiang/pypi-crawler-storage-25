from typing import Dict, Any, Optional, List
from autocoder.common.v2.agent.agentic_edit_tools.base_tool_resolver import BaseToolResolver
from autocoder.common.v2.agent.agentic_edit_types import TodoReadTool, ToolResult
from loguru import logger
import typing
from autocoder.common import AutoCoderArgs

# Import the new todos module
from autocoder.common.todos.get_todo_manager import get_todo_manager
from autocoder.common.todos.exceptions import TodoManagerError

if typing.TYPE_CHECKING:
    from autocoder.common.v2.agent.agentic_edit import AgenticEdit


class TodoReadToolResolver(BaseToolResolver):
    def __init__(self, agent: Optional['AgenticEdit'], tool: TodoReadTool, args: AutoCoderArgs):
        super().__init__(agent, tool, args)
        self.tool: TodoReadTool = tool  # For type hinting
        
        # Initialize todo manager
        self.todo_manager = get_todo_manager()

    def _get_conversation_id(self) -> Optional[str]:
        if self.agent and getattr(self.agent, 'conversation_config', None):
            return self.agent.conversation_config.conversation_id
        return None
    
    def _format_todo_display(self, todos: List[Dict[str, Any]]) -> str:
        """Format todos for display using the shared formatter."""
        from autocoder.common.todos.formatting import format_todo_list

        if not todos:
            return "  Todo List: (empty)"

        try:
            stats = self.todo_manager.get_statistics(conversation_id=self._get_conversation_id())
        except Exception as e:
            logger.error(f"Failed to get statistics: {e}")
            stats = None

        return format_todo_list(todos, stats=stats, title="Todo List")

    def resolve(self) -> ToolResult:
        """
        Read the current todo list and return it in a formatted display.
        """
        try:
            logger.info("Reading current todo list")
            
            conversation_id = self._get_conversation_id()
            todos = self.todo_manager.get_todos(conversation_id=conversation_id)
            
            # Format for display
            formatted_display = self._format_todo_display(todos)
            
            logger.info(f"Found {len(todos)} todos in current conversation")
            
            return ToolResult(
                success=True,
                message="Todo list retrieved successfully.",
                content=formatted_display
            )
            
        except TodoManagerError as e:
            logger.error(f"Todo manager error reading todo list: {e}")
            return ToolResult(
                success=False,
                message=f"Failed to read todo list: {str(e)}",
                content=None
            )
        except Exception as e:
            logger.error(f"Error reading todo list: {e}")
            return ToolResult(
                success=False,
                message=f"Failed to read todo list: {str(e)}",
                content=None
            ) 