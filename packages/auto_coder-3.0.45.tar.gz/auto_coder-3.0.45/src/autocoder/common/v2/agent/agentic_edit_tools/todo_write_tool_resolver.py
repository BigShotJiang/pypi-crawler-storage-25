from typing import Dict, Any, Optional, List
from autocoder.common.v2.agent.agentic_edit_tools.base_tool_resolver import BaseToolResolver
from autocoder.common.v2.agent.agentic_edit_types import TodoWriteTool, ToolResult
from loguru import logger
import typing
from autocoder.common import AutoCoderArgs

# Import the new todos module
from autocoder.common.todos.get_todo_manager import get_todo_manager
from autocoder.common.todos.exceptions import TodoManagerError, TodoNotFoundError

if typing.TYPE_CHECKING:
    from autocoder.common.v2.agent.agentic_edit import AgenticEdit


class TodoWriteToolResolver(BaseToolResolver):
    def __init__(self, agent: Optional['AgenticEdit'], tool: TodoWriteTool, args: AutoCoderArgs):
        super().__init__(agent, tool, args)
        self.tool: TodoWriteTool = tool  # For type hinting
        
        # Initialize todo manager
        self.todo_manager = get_todo_manager()

    def _get_conversation_id(self) -> Optional[str]:
        if self.agent and getattr(self.agent, 'conversation_config', None):
            return self.agent.conversation_config.conversation_id
        return None

    def _format_todo_response(self, todos: List[Dict[str, Any]], action_performed: str,
                              highlight_ids: Optional[set] = None) -> str:
        """Format the response message after todo operations.

        Always renders the full conversation todo list so the reader
        sees every item in context instead of a partial view.
        """
        from autocoder.common.todos.formatting import format_todo_list

        parts = [f"  {action_performed}"]
        parts.append(self._format_full_todo_list(highlight_ids=highlight_ids))
        return "\n".join(parts)

    def _format_full_todo_list(self, highlight_ids: Optional[set] = None) -> str:
        """Format the complete todo list using the shared formatter."""
        from autocoder.common.todos.formatting import format_todo_list

        try:
            conversation_id = self._get_conversation_id()
            all_todos = self.todo_manager.get_todos(conversation_id=conversation_id)

            if not all_todos:
                return "  (no todos)"

            stats = self.todo_manager.get_statistics(conversation_id=conversation_id)
            return format_todo_list(
                all_todos, stats=stats, title="Todo List",
                highlight_ids=highlight_ids,
            )
        except Exception as e:
            logger.error(f"Failed to format full todo list: {e}")
            return "  Error retrieving todo list."

    def resolve(self) -> ToolResult:
        """
        Create and manage a structured task list based on the action specified.
        """
        try:
            action = self.tool.action.lower()
            logger.info(f"Performing todo action: {action}")

            if action == "create":
                if not self.tool.content:
                    return ToolResult(
                        success=False,
                        message="Error: Content is required for creating todos.",
                        content=None
                    )

                # Create new todos using the todo manager
                try:
                    conversation_id = self._get_conversation_id()
                    todo_ids = self.todo_manager.create_todos(
                        content=self.tool.content,
                        conversation_id=conversation_id,
                        priority=self.tool.priority or "medium",
                        notes=self.tool.notes
                    )
                    
                    response = self._format_todo_response(
                        [], f"Created {len(todo_ids)} new todo items",
                        highlight_ids=set(todo_ids))
                    return ToolResult(
                        success=True,
                        message="Todo list created successfully.",
                        content=response
                    )
                    
                except TodoManagerError as e:
                    return ToolResult(
                        success=False,
                        message=f"Failed to create todos: {str(e)}",
                        content=None
                    )

            elif action == "add_task":
                if not self.tool.content:
                    return ToolResult(
                        success=False,
                        message="Error: Content is required for adding a task.",
                        content=None
                    )

                try:
                    conversation_id = self._get_conversation_id()
                    todo_id = self.todo_manager.add_todo(
                        content=self.tool.content,
                        conversation_id=conversation_id,
                        status=self.tool.status or "pending",
                        priority=self.tool.priority or "medium",
                        notes=self.tool.notes
                    )
                    
                    response = self._format_todo_response(
                        [], f"Added new task [{todo_id}]",
                        highlight_ids={todo_id})
                    
                    return ToolResult(
                        success=True,
                        message="Task added successfully.",
                        content=response
                    )
                    
                except TodoManagerError as e:
                    return ToolResult(
                        success=False,
                        message=f"Failed to add task: {str(e)}",
                        content=None
                    )

            elif action in ["update", "mark_progress", "mark_completed"]:
                if not self.tool.task_id:
                    return ToolResult(
                        success=False,
                        message="Error: Task ID is required for update operations.",
                        content=None
                    )

                try:
                    # Prepare update parameters
                    update_kwargs = {}
                    action_msg = ""
                    
                    if action == "mark_progress":
                        update_kwargs['status'] = "in_progress"
                        action_msg = "Marked task as in progress"
                    elif action == "mark_completed":
                        update_kwargs['status'] = "completed"
                        action_msg = "Marked task as completed"
                    else:  # update
                        if self.tool.content:
                            update_kwargs['content'] = self.tool.content
                        if self.tool.status:
                            update_kwargs['status'] = self.tool.status
                        if self.tool.priority:
                            update_kwargs['priority'] = self.tool.priority
                        if self.tool.notes:
                            update_kwargs['notes'] = self.tool.notes
                        action_msg = "Updated task"
                    
                    conversation_id = self._get_conversation_id()
                    success = self.todo_manager.update_todo(
                        todo_id=self.tool.task_id,
                        conversation_id=conversation_id,
                        **update_kwargs
                    )
                    
                    if success:
                        response = self._format_todo_response(
                            [], f"{action_msg} [{self.tool.task_id}]",
                            highlight_ids={self.tool.task_id})
                        
                        return ToolResult(
                            success=True,
                            message="Task updated successfully.",
                            content=response
                        )
                    else:
                        return ToolResult(
                            success=False,
                            message=f"Task with ID '{self.tool.task_id}' not found.",
                            content=None
                        )
                        
                except TodoNotFoundError:
                    return ToolResult(
                        success=False,
                        message=f"Error: Task with ID '{self.tool.task_id}' not found.",
                        content=None
                    )
                except TodoManagerError as e:
                    return ToolResult(
                        success=False,
                        message=f"Failed to update task: {str(e)}",
                        content=None
                    )

            else:
                return ToolResult(
                    success=False,
                    message=f"Error: Unknown action '{action}'. Supported actions: create, add_task, update, mark_progress, mark_completed.",
                    content=None
                )

        except Exception as e:
            logger.error(f"Error in todo write operation: {e}")
            return ToolResult(
                success=False,
                message=f"Failed to perform todo operation: {str(e)}",
                content=None
            )
