"""Terminal paste handling module for auto-coder.

This module provides functionality to intercept terminal paste events,
save pasted content to files, resolve placeholders in user input,
and detect/save clipboard images (macOS and Windows).
"""

from .paste_handler import register_paste_handler, resolve_paste_placeholders
from .paste_manager import PasteManager
from .clipboard_image import get_clipboard_image

__all__ = [
    "register_paste_handler",
    "resolve_paste_placeholders",
    "PasteManager",
    "get_clipboard_image",
]
