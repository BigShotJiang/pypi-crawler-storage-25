"""Clipboard image detection and saving for macOS and Windows.

Detects image data in the system clipboard, saves it to a temporary directory,
and returns the file path. Used by the paste handler to support Ctrl+V image pasting.
"""

import platform
import subprocess
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional


def _get_image_output_dir() -> Path:
    output_dir = Path.home() / ".auto-coder" / "autocoder_clipboard_images"
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir


def _generate_image_path() -> Path:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    short_id = uuid.uuid4().hex[:8]
    filename = f"clipboard_{timestamp}_{short_id}.png"
    return _get_image_output_dir() / filename


def _try_save_macos(output_path: Path) -> bool:
    """Save clipboard image on macOS using AppleScript.

    Uses «class PNGf» to read PNG data directly from the clipboard.
    Works for screenshots (Cmd+Shift+4, etc.) and images copied from
    native macOS apps (Preview, Safari, etc.).
    """
    script = (
        "try\n"
        f'    set theFile to open for access POSIX file "{output_path}" '
        f"with write permission\n"
        "    set theData to the clipboard as \u00abclass PNGf\u00bb\n"
        "    write theData to theFile\n"
        "    close access theFile\n"
        '    return "SAVED"\n'
        "on error\n"
        '    return "NO_IMAGE"\n'
        "end try"
    )
    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return (
            "SAVED" in result.stdout
            and output_path.exists()
            and output_path.stat().st_size > 0
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


def _try_save_windows(output_path: Path) -> bool:
    """Save clipboard image on Windows using PowerShell.

    Uses System.Windows.Forms.Clipboard to read image data
    and save as PNG.
    """
    ps_path = str(output_path).replace("'", "''")
    script = (
        "Add-Type -AssemblyName System.Windows.Forms;"
        "$img = [System.Windows.Forms.Clipboard]::GetImage();"
        "if ($img -ne $null) {"
        f"  $img.Save('{ps_path}', [System.Drawing.Imaging.ImageFormat]::Png);"
        '  Write-Output "SAVED"'
        "} else {"
        '  Write-Output "NO_IMAGE"'
        "}"
    )
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return (
            "SAVED" in result.stdout
            and output_path.exists()
            and output_path.stat().st_size > 0
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


def get_clipboard_image() -> Optional[Path]:
    """Check system clipboard for image data, save to temp directory.

    Returns:
        Path to the saved PNG file, or None if no image in clipboard.
    """
    system = platform.system()
    if system not in ("Darwin", "Windows"):
        return None

    output_path = _generate_image_path()

    if system == "Darwin":
        success = _try_save_macos(output_path)
    else:
        success = _try_save_windows(output_path)

    if success:
        return output_path

    if output_path.exists():
        output_path.unlink(missing_ok=True)
    return None
