"""
RuleFile 数据模型

规则文件的 Pydantic 模型定义。
"""

from pydantic import BaseModel, Field


class RuleFile(BaseModel):
    """规则文件的Pydantic模型"""

    description: str = Field(default="", description="规则的描述")
    globs: list[str] = Field(default_factory=list, description="文件匹配模式列表")
    always_apply: bool = Field(default=False, description="是否总是应用规则")
    subagents: list[str] | None = Field(
        default=None,
        description=(
            "指定该规则仅对哪些子代理生效。"
            '["*"] 或未配置时的 None 有不同语义：'
            "None=未配置(子 agent 不加载)；"
            '["*"]=任何子 agent 都加载'
        ),
    )
    variables: dict = Field(default_factory=dict, description="规则文件中定义的模板变量")
    content: str = Field(default="", description="规则文件的正文内容")
    file_path: str = Field(default="", description="规则文件的路径")
