"""
测试 rulefiles 模块的 subagents frontmatter 过滤功能。

覆盖:
- subagents 字段的解析（字符串/列表/缺失）
- filter_rules_for_agent 的过滤逻辑
- get_rules_for_conversation 对主/子 agent 的正确行为
"""

import json
import os
import tempfile
from unittest.mock import patch

import pytest

from autocoder.common.rulefiles import (
    get_parsed_rules,
    reset_rules_manager,
)
from autocoder.common.rulefiles.api import (
    filter_rules_for_agent,
    get_rules_for_conversation,
)
from autocoder.common.rulefiles.models.rule_file import RuleFile


@pytest.fixture
def temp_project_dir():
    with tempfile.TemporaryDirectory() as temp_dir:
        yield temp_dir


@pytest.fixture
def rules_dir(temp_project_dir):
    rules_path = os.path.join(temp_project_dir, ".autocoderrules")
    os.makedirs(rules_path, exist_ok=True)
    return rules_path


@pytest.fixture(autouse=True)
def cleanup():
    yield
    reset_rules_manager()


def _create_rule(
    rules_dir: str,
    filename: str,
    content: str,
    always_apply: bool = False,
    subagents=None,
) -> str:
    yaml_lines = [
        "---",
        f'description: "test"',
        f"alwaysApply: {str(always_apply).lower()}",
    ]
    if subagents is not None:
        if isinstance(subagents, str):
            yaml_lines.append(f'subagents: "{subagents}"')
        elif isinstance(subagents, list):
            yaml_lines.append(f"subagents: {json.dumps(subagents)}")
    yaml_lines.append("---")
    yaml_lines.append(content)

    file_path = os.path.join(rules_dir, filename)
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("\n".join(yaml_lines))
    return file_path


def _find_rule(rules: list, filename: str) -> RuleFile:
    """从规则列表中按文件名查找。"""
    for r in rules:
        if os.path.basename(r.file_path) == filename:
            return r
    raise AssertionError(f"Rule {filename} not found in {[os.path.basename(r.file_path) for r in rules]}")


class TestSubagentsParsing:
    def test_wildcard_string(self, temp_project_dir, rules_dir):
        _create_rule(rules_dir, "wild.md", "body", subagents="*")
        with patch("os.getcwd", return_value=temp_project_dir):
            rules = get_parsed_rules(project_root=temp_project_dir)
        rule = _find_rule(rules, "wild.md")
        assert rule.subagents == ["*"]

    def test_wildcard_list(self, temp_project_dir, rules_dir):
        _create_rule(rules_dir, "wild2.md", "body", subagents=["*"])
        with patch("os.getcwd", return_value=temp_project_dir):
            rules = get_parsed_rules(project_root=temp_project_dir)
        rule = _find_rule(rules, "wild2.md")
        assert rule.subagents == ["*"]

    def test_name_list(self, temp_project_dir, rules_dir):
        _create_rule(rules_dir, "named.md", "body", subagents=["a", "b"])
        with patch("os.getcwd", return_value=temp_project_dir):
            rules = get_parsed_rules(project_root=temp_project_dir)
        rule = _find_rule(rules, "named.md")
        assert rule.subagents == ["a", "b"]

    def test_absent(self, temp_project_dir, rules_dir):
        _create_rule(rules_dir, "plain.md", "body")
        with patch("os.getcwd", return_value=temp_project_dir):
            rules = get_parsed_rules(project_root=temp_project_dir)
        rule = _find_rule(rules, "plain.md")
        assert rule.subagents is None


class TestFilterRulesForAgent:
    def test_main_agent_keeps_no_subagents(self):
        rules = [
            RuleFile(content="main", always_apply=True, subagents=None),
            RuleFile(content="sub", always_apply=True, subagents=["*"]),
            RuleFile(content="named", always_apply=True, subagents=["explorer"]),
        ]
        filtered = filter_rules_for_agent(rules, is_sub_agent=False)
        assert len(filtered) == 1
        assert filtered[0].content == "main"

    def test_subagent_skips_no_subagents(self):
        rules = [
            RuleFile(content="main only", always_apply=True, subagents=None),
            RuleFile(content="all subs", always_apply=True, subagents=["*"]),
        ]
        filtered = filter_rules_for_agent(
            rules, is_sub_agent=True, subagent_name="explorer"
        )
        assert len(filtered) == 1
        assert filtered[0].content == "all subs"

    def test_subagent_by_name(self):
        rules = [
            RuleFile(content="for explorer", subagents=["explorer"]),
            RuleFile(content="for writer", subagents=["writer"]),
            RuleFile(content="for all", subagents=["*"]),
        ]
        filtered = filter_rules_for_agent(
            rules, is_sub_agent=True, subagent_name="explorer"
        )
        assert len(filtered) == 2
        contents = {r.content for r in filtered}
        assert contents == {"for explorer", "for all"}

    def test_subagent_no_name_only_wildcard(self):
        rules = [
            RuleFile(content="for explorer", subagents=["explorer"]),
            RuleFile(content="for all", subagents=["*"]),
        ]
        filtered = filter_rules_for_agent(
            rules, is_sub_agent=True, subagent_name=None
        )
        assert len(filtered) == 1
        assert filtered[0].content == "for all"

    def test_empty_subagents_matches_nothing(self):
        rules = [
            RuleFile(content="empty", subagents=[]),
        ]
        filtered = filter_rules_for_agent(
            rules, is_sub_agent=True, subagent_name="explorer"
        )
        assert len(filtered) == 0


class TestGetRulesForConversation:
    def test_main_agent(self, temp_project_dir, rules_dir):
        _create_rule(rules_dir, "main.md", "主规则", always_apply=True)
        _create_rule(
            rules_dir, "sub.md", "子agent专属", always_apply=True, subagents=["*"]
        )

        with patch("os.getcwd", return_value=temp_project_dir):
            text = get_rules_for_conversation(
                project_root=temp_project_dir, is_sub_agent=False
            )
        assert text is not None
        assert "主规则" in text
        assert "子agent专属" not in text

    def test_subagent(self, temp_project_dir, rules_dir):
        _create_rule(rules_dir, "main.md", "主规则", always_apply=True)
        _create_rule(
            rules_dir, "sub.md", "子agent通用", always_apply=True, subagents=["*"]
        )

        with patch("os.getcwd", return_value=temp_project_dir):
            text = get_rules_for_conversation(
                project_root=temp_project_dir,
                is_sub_agent=True,
                subagent_name="contexer",
            )
        assert text is not None
        assert "子agent通用" in text
        assert "主规则" not in text

    def test_subagent_named_match(self, temp_project_dir, rules_dir):
        _create_rule(
            rules_dir, "match.md", "匹配规则",
            always_apply=True, subagents=["contexer"]
        )
        _create_rule(
            rules_dir, "nomatch.md", "不匹配",
            always_apply=True, subagents=["writer"]
        )

        with patch("os.getcwd", return_value=temp_project_dir):
            text = get_rules_for_conversation(
                project_root=temp_project_dir,
                is_sub_agent=True,
                subagent_name="contexer",
            )
        assert "匹配规则" in text
        assert "不匹配" not in text
