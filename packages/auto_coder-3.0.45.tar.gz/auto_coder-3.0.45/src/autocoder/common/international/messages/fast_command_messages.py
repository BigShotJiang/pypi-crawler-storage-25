"""
Fast command messages for internationalization
Contains all messages used by the /fast command functionality
"""

FAST_COMMAND_MESSAGES = {
    "fast_usage": {
        "en": "Please provide a coding request. Usage: /fast <query>",
        "zh": "请提供编码请求。用法: /fast <查询>",
    },
    "fast_cancelled_force_timeout": {
        "en": "Fast coding cancelled (force timeout)",
        "zh": "快速编码已取消（强制超时）",
    },
    "fast_cancelled": {
        "en": "Fast coding cancelled",
        "zh": "快速编码已取消",
    },
    "fast_step1_exploring": {
        "en": "[1/3] Initializing and exploring project...",
        "zh": "[1/3] 正在初始化并探索项目...",
    },
    "fast_exploration_failed": {
        "en": "File exploration failed: {{error}}",
        "zh": "文件探索失败: {{error}}",
    },
    "fast_no_relevant_files": {
        "en": "No relevant files found during exploration",
        "zh": "探索过程中未发现相关文件",
    },
    "fast_discovered_files": {
        "en": "Discovered files:",
        "zh": "发现的文件:",
    },
    "fast_step2_reading": {
        "en": "[2/3] Reading source files...",
        "zh": "[2/3] 正在读取源文件...",
    },
    "fast_no_readable_files": {
        "en": "No readable source files found in discovered files",
        "zh": "在发现的文件中没有可读的源文件",
    },
    "fast_step2_done": {
        "en": "[2/3] Done ({{count}} files read, {{elapsed}}s)",
        "zh": "[2/3] 完成（已读取 {{count}} 个文件，耗时 {{elapsed}}s）",
    },
    "fast_step3_generating": {
        "en": "[3/3] Generating code changes ({{count}} files in context)...",
        "zh": "[3/3] 正在生成代码变更（上下文包含 {{count}} 个文件）...",
    },
    "fast_llm_init_failed": {
        "en": "Failed to initialize LLM",
        "zh": "LLM 初始化失败",
    },
    "fast_no_completion_result": {
        "en": "Fast coding finished without a completion result",
        "zh": "快速编码完成但未生成结果",
    },
    "fast_completed": {
        "en": "Fast coding completed",
        "zh": "快速编码完成",
    },
    "fast_files_explored": {
        "en": "  Files explored: {{count}}",
        "zh": "  探索的文件数: {{count}}",
    },
    "fast_files_in_context": {
        "en": "  Files in context: {{count}}",
        "zh": "  上下文文件数: {{count}}",
    },
    "fast_changes_merged": {
        "en": "  Changes generated and merged",
        "zh": "  变更已生成并合并",
    },
    "fast_time_summary": {
        "en": "  Time: explore {{t1}}s + read {{t2}}s + generate {{t3}}s = {{total}}s",
        "zh": "  耗时: 探索 {{t1}}s + 读取 {{t2}}s + 生成 {{t3}}s = 总计 {{total}}s",
    },
    "fast_desc": {
        "en": "Fast coding: explore files then generate changes",
        "zh": "快速编码：探索文件后生成变更",
    },
}
