"""
Auto Coder Chat V3 - 入口文件

重构后的终端交互入口，使用 prompt_toolkit 全屏 TUI。
"""

from loguru import logger

logger.remove()

from autocoder.run_context import get_run_context, RunMode

get_run_context().set_mode(RunMode.TERMINAL)

import asyncio
import argparse
import io
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from autocoder.auto_coder_runner import (
    load_tokenizer,
    initialize_system,
    InitializeSystemRequest,
    configure,
    start as start_engine,
    completer,
    ask,
    coding,
    chat,
    design,
    voice_input,
    auto_command,
    run_agentic,
    execute_shell_command,
    stop as stop_engine,
)

V3_COMMANDS = [
    "/async",
    "/auto",
    "/clear",
    "/commit",
    "/conf",
    "/connect",
    "/exit",
    "/fast",
    "/help",
    "/memory",
    "/models",
    "/new",
    "/rules",
    "/status",
    "/tunnel",
    "/workflow",
]
from autocoder.common.core_config import (
    cycle_mode,
    get_mode,
    toggle_human_as_model,
    get_human_as_model_string,
    toggle_agentic_mode,
    get_agentic_mode_string,
)
from autocoder.chat_auto_coder_lang import (
    get_message,
    get_message_with_format as get_message_with_format_local,
)
from autocoder.plugins import PluginManager
from autocoder.terminal_v3 import AutoCoderChatApp


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Auto-Coder V3 - Claude-style Chat Interface"
    )
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument(
        "--quick",
        action="store_true",
        help="Enter the auto-coder.chat without initializing the system",
    )
    parser.add_argument(
        "--skip_provider_selection",
        action="store_true",
        help="Skip the provider selection",
    )
    parser.add_argument(
        "--product_mode",
        type=str,
        default="lite",
        help="The mode of the auto-coder.chat, lite/pro default is lite",
    )
    parser.add_argument("--lite", action="store_true", help="Lite mode")
    parser.add_argument("--pro", action="store_true", help="Pro mode")

    from autocoder.terminal_core.cloud_config import (
        DEFAULT_BASE_URL,
        ENV_API_KEY,
        ENV_BASE_URL,
        ENV_INSTANCE_NAME,
        load_cloud_config,
        save_cloud_config,
    )

    cloud = parser.add_argument_group("cloud", "Cloud integration options")
    cloud.add_argument(
        "--cloud-api-key",
        type=str,
        default=None,
        help=f"API key for cloud registration (env: {ENV_API_KEY})",
    )
    cloud.add_argument(
        "--cloud-base-url",
        type=str,
        default=DEFAULT_BASE_URL,
        help=f"Base URL of the auto-coder.chat server (env: {ENV_BASE_URL})",
    )
    cloud.add_argument(
        "--instance-name",
        type=str,
        default=None,
        help=(
            f"Display name for this instance (env: {ENV_INSTANCE_NAME}, "
            "default: current directory name)"
        ),
    )

    args = parser.parse_args()

    cloud_cfg = load_cloud_config(
        cli_api_key=args.cloud_api_key,
        cli_base_url=args.cloud_base_url,
        cli_instance_name=args.instance_name,
    )
    args.cloud_api_key = cloud_cfg.api_key or None
    args.cloud_base_url = cloud_cfg.base_url
    args.instance_name = cloud_cfg.instance_name
    args.cloud_connection = cloud_cfg

    save_cloud_config(cloud_cfg)

    return args


def load_builtin_plugins(plugin_manager):
    """加载内置插件"""
    try:
        discovered_plugins = plugin_manager.discover_plugins()

        excluded_plugins = {
            "autocoder.plugins.dynamic_completion_example",
            "autocoder.plugins.sample_plugin",
        }

        builtin_loaded = 0
        for plugin_class in discovered_plugins:
            module_name = plugin_class.__module__
            if (
                module_name.startswith("autocoder.plugins.")
                and not module_name.endswith(".__init__")
                and module_name not in excluded_plugins
            ):
                try:
                    if plugin_manager.load_plugin(plugin_class):
                        builtin_loaded += 1
                        logger.info(
                            f"Loaded builtin plugin: {plugin_class.plugin_name()}"
                        )
                except Exception as e:
                    logger.error(
                        f"Failed to load builtin plugin {plugin_class.plugin_name()}: {e}"
                    )

        if builtin_loaded > 0:
            logger.info(
                get_message_with_format_local(
                    "loaded_plugins_builtin", count=builtin_loaded
                )
            )
        else:
            logger.info(get_message("no_builtin_plugins_loaded"))

    except Exception as e:
        logger.exception(f"Error loading builtin plugins: {e}")


async def async_main():
    load_tokenizer()
    args = parse_arguments()

    if args.lite:
        args.product_mode = "lite"

    if args.pro:
        args.product_mode = "pro"

    if not args.quick:
        initialize_system(
            InitializeSystemRequest(
                product_mode=args.product_mode,
                skip_provider_selection=args.skip_provider_selection,
                debug=args.debug,
                quick=args.quick,
                lite=args.lite,
                pro=args.pro,
            )
        )

    start_engine()

    plugin_manager = PluginManager()
    startup_logs: list[str] = []

    def bootstrap_plugins_quietly() -> None:
        buf = io.StringIO()
        with redirect_stdout(buf), redirect_stderr(buf):
            plugin_manager.load_global_plugin_dirs()
            plugins_dir = Path(__file__).resolve().parent / "plugins"
            _, add_plugins_dir_message = plugin_manager.add_plugin_directory(
                str(plugins_dir)
            )
            plugin_manager.load_runtime_cfg()
            load_builtin_plugins(plugin_manager)

        raw_logs = buf.getvalue().strip()
        if add_plugins_dir_message.startswith("Invalid directory:"):
            startup_logs.append(add_plugins_dir_message)
        if raw_logs:
            for line in raw_logs.splitlines():
                cleaned = line.strip()
                if not cleaned:
                    continue
                if cleaned.startswith("Saved global plugin dirs"):
                    continue
                if cleaned.startswith("✓ Loaded builtin plugin:"):
                    continue
                if "已初始化" in cleaned:
                    continue
                if "已加载" in cleaned and "内置插件" in cleaned:
                    continue
                startup_logs.append(cleaned)

    bootstrap_plugins_quietly()

    configure(f"product_mode:{args.product_mode}")

    completer.base_commands = V3_COMMANDS

    original_functions = {
        "ask": ask,
        "coding": coding,
        "chat": chat,
        "design": design,
        "voice_input": voice_input,
        "auto_command": auto_command,
        "run_agentic": run_agentic,
        "execute_shell_command": execute_shell_command,
    }

    wrapped_functions = {}
    for func_name, original_func in original_functions.items():
        wrapped_functions[func_name] = plugin_manager.wrap_function(
            original_func, func_name
        )

    cloud_bridge = None
    if args.cloud_connection.is_complete:
        from autocoder.terminal_core.cloud_bridge import CloudBridge, CloudConfig
        from autocoder.terminal_core.execution_broker import ExecutionBroker

        broker = ExecutionBroker(configure_func=configure)
        cloud_config = CloudConfig.from_connection(
            args.cloud_connection, project_path=str(Path.cwd())
        )
        cloud_bridge = CloudBridge(config=cloud_config, broker=broker)
        ok = await cloud_bridge.start()
        if ok:
            startup_logs.append(
                f"Cloud: connected to {args.cloud_base_url} "
                f"(instance={cloud_bridge.instance_id})"
            )
        else:
            startup_logs.append("Cloud: registration failed, running in local-only mode")
            cloud_bridge = None

    chat_app = AutoCoderChatApp(
        plugin_manager=plugin_manager,
        wrapped_functions=wrapped_functions,
        configure_func=configure,
        base_completer=completer,
        get_mode_func=get_mode,
        get_human_as_model_string_func=get_human_as_model_string,
        get_agentic_mode_string_func=get_agentic_mode_string,
        cycle_mode_func=cycle_mode,
        toggle_human_as_model_func=toggle_human_as_model,
        toggle_agentic_mode_func=toggle_agentic_mode,
        stop_engine_func=stop_engine,
        startup_logs=startup_logs,
        debug=args.debug,
        cloud_bridge=cloud_bridge,
    )
    try:
        await chat_app.run()
    finally:
        if cloud_bridge:
            await cloud_bridge.stop()


def main():
    """同步入口函数，供 console_scripts 使用"""
    asyncio.run(async_main())


if __name__ == "__main__":
    main()
