from __future__ import annotations
import json as json_lib,time
from typing import Any
import click
from.client import ProfileNotFound,create_profile_apply_job,get_profile,get_profile_job,put_profile
from.detect import detect_editor,detect_git_config,detect_shell,detect_tools
from.format import render_profile
def _collect_local_profile()->dict[str,Any]:return{'shell':detect_shell(),'editor':detect_editor(),**detect_git_config(),'tools':detect_tools()}
def handle_profile_show(json_out:bool)->int:
	A=_collect_local_profile()
	if json_out:click.echo(json_lib.dumps(A,indent=2));return 0
	click.echo(render_profile(A));return 0
def handle_profile_push(json_out:bool,env_name:str|None=None,no_wait:bool=False)->int:
	B=env_name;A=json_out;E=_collect_local_profile();F=put_profile(E);C=F.get('profile')or{};D=C.get('tools')or[]
	if B is None:
		if A:click.echo(json_lib.dumps(C,indent=2));return 0
		click.echo(f"Saved dev profile: {len(D)} tool(s).");return 0
	if not A:click.echo(f"Saved dev profile: {len(D)} tool(s).")
	return handle_profile_apply(B,json_out=A,no_wait=no_wait)
def handle_profile_apply(env_name:str,*,json_out:bool,no_wait:bool=False)->int:
	B=env_name;A=json_out;G=create_profile_apply_job(B);F=G.get('job')or{};C=F.get('id')
	if not isinstance(C,str):raise RuntimeError('TabTabTab could not start profile mirroring.')
	if no_wait:
		if A:click.echo(json_lib.dumps(F,indent=2))
		else:click.echo(f"Mirroring dev profile to {B} in the background.");click.echo(f"Check progress with: tabtabtab profile job {C}")
		return 0
	if not A:click.echo(f"Mirroring dev profile to {B}...");click.echo('(Ctrl+C to stop watching; mirroring keeps running.)')
	D=_poll_profile_job(C,json_out=A);E=D.get('status')
	if A:click.echo(json_lib.dumps(D,indent=2))
	if E=='ready':
		if not A:click.echo('Dev profile mirrored successfully.')
		return 0
	if E=='failed':H=D.get('errorMessage')or'Profile apply failed.';raise RuntimeError(H)
	raise RuntimeError(f"Unexpected profile job status: {E}")
def _poll_profile_job(job_id:str,*,json_out:bool,interval_seconds:float=3.)->dict[str,Any]:
	C=''
	while True:
		F=get_profile_job(job_id);A=F.get('job')or{};B=A.get('status')or'';D=A.get('step')or'';E=f"{B}:{D}"
		if not json_out and E!=C:click.echo(f"- {_format_profile_status(B,D)}");C=E
		if B in('ready','failed'):return A
		time.sleep(interval_seconds)
def handle_profile_job(job_id:str,*,json_out:bool,watch:bool)->int:
	D=job_id;B=json_out
	if watch:
		C=_poll_profile_job(D,json_out=B)
		if B:click.echo(json_lib.dumps(C,indent=2))
		F=C.get('status')
		if F=='failed':raise RuntimeError(C.get('errorMessage')or'Profile apply failed.')
		return 0
	G=get_profile_job(D);A=G.get('job')or{}
	if B:click.echo(json_lib.dumps(A,indent=2))
	else:
		click.echo(_format_profile_status(A.get('status'),A.get('step')));E=A.get('errorMessage')
		if E:click.echo(f"error: {E}",err=True)
	return 0
def _format_profile_status(status:Any,step:Any)->str:
	A=status
	if A=='ready':return'Done'
	if A=='failed':return'Failed'
	if step in{'queued','requested'}:return'Queued'
	if A in{'running','requested'}:return'Mirroring'
	return'Working'
def handle_profile_pull(json_out:bool)->int:
	try:B=get_profile()
	except ProfileNotFound:click.echo('No profile pushed yet. Run `tabtabtab profile push` first.');return 0
	A=B.get('profile')or{}
	if json_out:click.echo(json_lib.dumps(A,indent=2));return 0
	click.echo(render_profile(A));return 0