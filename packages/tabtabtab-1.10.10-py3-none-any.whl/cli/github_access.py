from __future__ import annotations
import subprocess,sys
from textwrap import dedent
from.import ssh_access
LOCAL_GH_INSTALL_MESSAGE='GitHub CLI (`gh`) is required for this command. Install it from https://cli.github.com/ and run `gh auth login --git-protocol https`.'
LOCAL_GH_HTTPS_REAUTH_HINT='Re-authenticate local GitHub CLI for HTTPS git access with:\n  gh auth logout\n  gh auth login --git-protocol https\nChoose: GitHub.com and HTTPS. If you paste a classic PAT, include `repo` and `read:org`.\nVerify it with: gh auth status -h github.com'
LOCAL_GH_SSH_REAUTH_HINT='Re-authenticate local GitHub CLI for GitHub SSH key management with:\n  gh auth logout\n  gh auth login --git-protocol https\nChoose: GitHub.com, HTTPS, Skip uploading your local SSH key, then paste a classic PAT with `repo`, `read:org`, and `admin:public_key`.\nVerify it with: gh api user/keys'
LOCAL_GH_REFRESH_COMMAND='gh auth refresh -h github.com -s repo,read:org,admin:public_key'
REMOTE_GH_SSH_KEY_PERMISSION_HINT=f"Failed to inspect GitHub SSH keys. Ensure the local gh token grants SSH key management access.\n{LOCAL_GH_SSH_REAUTH_HINT}"
LOCAL_GH_REFRESH_HINT=f"Refresh local GitHub CLI permissions with:\n  {LOCAL_GH_REFRESH_COMMAND}"
LOCAL_GH_REFRESH_MESSAGE='Your local GitHub CLI token cannot manage SSH keys yet. Running `gh auth refresh` to request `admin:public_key` so GitHub access can be enabled.\n'
MANUAL_PAT_TOKEN_PATH='$HOME/.config/gv/github-token'
MANUAL_PAT_ENV_PATH='$HOME/.config/gv/env.d/github.sh'
LOCAL_GH_CREDENTIAL_HELPER='!gh auth git-credential'
MANUAL_PAT_CREDENTIAL_HELPER='!f() { test "$1" = get || exit 0; token_file="$HOME/.config/gv/github-token"; test -r "$token_file" || exit 0; printf "username=x-access-token\\n"; printf "password=%s\\n" "$(cat "$token_file")"; }; f'
GITHUB_SSH_CONFIG=dedent('    Host github.com\n      HostName github.com\n      User git\n      IdentityFile ~/.ssh/id_ed25519_github\n      IdentitiesOnly yes\n    ')
GITHUB_APP_GH_CONFIG_DIR='/opt/nero/config/gh'
GITHUB_APP_TOKEN_METADATA_PATH='/opt/nero/config/github-app-token.json'
GITHUB_APP_CREDENTIAL_HELPER='!GH_CONFIG_DIR=/opt/nero/config/gh gh auth git-credential'
FIND_EXISTING_SSH_KEY_ID_PYTHON="import json, os, sys; data=json.load(sys.stdin); pub=os.environ['PUBKEY']; print(next((str(item['id']) for item in data if item.get('key') == pub), ''), end='')"
FIND_EXISTING_SSH_KEY_IDS_PYTHON="import json, os, sys; data=json.load(sys.stdin) if sys.stdin.readable() else []; pub=os.environ['PUBKEY']; print(' '.join(str(item['id']) for item in data if item.get('key') == pub), end='')"
REMOVE_MANAGED_SSH_CONFIG_PYTHON=dedent(f"""    from pathlib import Path

    config_path = Path.home() / '.ssh' / 'config'
    if config_path.exists():
        text = config_path.read_text()
        managed = {GITHUB_SSH_CONFIG!r}
        if text == managed:
            config_path.unlink()
    """)
HAS_MANAGED_SSH_CONFIG_PYTHON=dedent(f"""    from pathlib import Path

    config_path = Path.home() / '.ssh' / 'config'
    if not config_path.exists():
        raise SystemExit(1)
    text = config_path.read_text()
    managed = {GITHUB_SSH_CONFIG!r}
    raise SystemExit(0 if managed in text else 1)
    """)
def read_local_github_token(*,require_ssh_key_management:bool=True)->str:
	C=require_ssh_key_management;_check_local_gh_installed();A=LOCAL_GH_SSH_REAUTH_HINT if C else LOCAL_GH_HTTPS_REAUTH_HINT;B=_read_authenticated_local_github_token(A)
	if C and not _local_github_can_manage_ssh_keys():
		_refresh_local_github_permissions();B=_read_authenticated_local_github_token(A)
		if not _local_github_can_manage_ssh_keys():raise RuntimeError(f"Local GitHub CLI still cannot inspect SSH keys after refresh.\n{LOCAL_GH_REFRESH_HINT}\n{LOCAL_GH_SSH_REAUTH_HINT}")
	if not B:raise RuntimeError(f"GitHub CLI did not return a token.\n{A}")
	return B
def _check_local_gh_installed()->None:
	try:subprocess.run(['gh','--version'],check=True,capture_output=True,text=True)
	except FileNotFoundError as A:raise RuntimeError(LOCAL_GH_INSTALL_MESSAGE)from A
	except subprocess.CalledProcessError as A:raise RuntimeError('GitHub CLI (`gh`) is installed but could not be executed.')from A
def _read_authenticated_local_github_token(reauth_hint:str)->str:
	try:B=subprocess.run(['gh','auth','token'],check=True,capture_output=True,text=True)
	except FileNotFoundError as A:raise RuntimeError(LOCAL_GH_INSTALL_MESSAGE)from A
	except subprocess.CalledProcessError as A:raise RuntimeError(f"GitHub CLI is installed but not authenticated.\n{reauth_hint}")from A
	return B.stdout.strip()
def _local_github_can_manage_ssh_keys()->bool:A=subprocess.run(['gh','api','user/keys','--paginate'],capture_output=True,text=True,check=False);return A.returncode==0
def _refresh_local_github_permissions()->None:
	try:sys.stderr.write(LOCAL_GH_REFRESH_MESSAGE);sys.stderr.flush();subprocess.run(['gh','auth','refresh','-h','github.com','-s','repo,read:org,admin:public_key'],check=True)
	except FileNotFoundError as A:raise RuntimeError(LOCAL_GH_INSTALL_MESSAGE)from A
	except subprocess.CalledProcessError as A:raise RuntimeError(f"GitHub CLI needs additional permissions to manage SSH keys, and `gh auth refresh` did not complete.\n{LOCAL_GH_REFRESH_HINT}\n{LOCAL_GH_SSH_REAUTH_HINT}")from A
def enable_github(env_id:str,ssh_details:ssh_access.EnvSshAccess,github_token:str,*,enable_ssh:bool=True)->None:
	A=ssh_access.run_ssh_process(env_id,ssh_details,('bash','-se'),input_text=_enable_script(github_token,enable_ssh=enable_ssh),capture_output=True)
	if A.returncode!=0:raise RuntimeError(_stderr_message(A,'Failed to enable GitHub auth.'))
def enable_github_with_pat(env_id:str,ssh_details:ssh_access.EnvSshAccess,github_token:str)->None:
	A=ssh_access.run_ssh_process(env_id,ssh_details,('bash','-se'),input_text=_enable_manual_pat_script(github_token),capture_output=True)
	if A.returncode!=0:raise RuntimeError(_stderr_message(A,'Failed to enable GitHub auth.'))
def disable_github(env_id:str,ssh_details:ssh_access.EnvSshAccess)->None:
	A=ssh_access.run_ssh_process(env_id,ssh_details,('bash','-se'),input_text=_disable_script(),capture_output=True)
	if A.returncode!=0:raise RuntimeError(_stderr_message(A,'Failed to disable GitHub auth.'))
def github_status(env_id:str,ssh_details:ssh_access.EnvSshAccess)->str:
	A=ssh_access.run_ssh_process(env_id,ssh_details,('bash','-se'),input_text=_status_script(),capture_output=True)
	if A.returncode==0:return A.stdout.strip()or'enabled'
	if A.returncode==10:return'disabled'
	raise RuntimeError(_stderr_message(A,'Failed to read GitHub auth status.'))
def _enable_script(github_token:str,*,enable_ssh:bool=True)->str:
	C=enable_ssh;D=github_token.replace("'",'\'"\'"\'');E=_ssh_key_title('$HOSTNAME');F=_shell_single_quote(REMOTE_GH_SSH_KEY_PERMISSION_HINT);A=['set -euo pipefail',dedent(f"""            # Validate remote prerequisites and declare shared paths.
            command -v gh >/dev/null || {{
              printf 'gh is not installed on the env. Reprovision with the latest bootstrap.
' >&2
              exit 1
            }}
            token='{D}'
            ssh_key_path=\"$HOME/.ssh/id_ed25519_github\"
            ssh_key_title=\"{E}\"
            """),dedent('            # Log gh into GitHub for HTTPS git operations.\n            printf \'%s\n\' "$token" | gh auth login --hostname github.com --git-protocol https --with-token\n            gh config set -h github.com git_protocol https >/dev/null\n            ')]
	if C:A.extend([dedent(f"""            # Verify the token can inspect SSH keys before configuring SSH access.
            if ! existing_keys_json=\"$(gh api user/keys --paginate 2>/dev/null)\"; then
              printf '{F}
' >&2
              exit 1
            fi
            gh config set -h github.com git_protocol ssh >/dev/null
            """),dedent(f'''            # Create or reuse the dedicated GitHub SSH key on the VM.
            install -d -m 700 "$HOME/.ssh"
            if [[ ! -f "$ssh_key_path" ]]; then
              ssh-keygen -t ed25519 -N \'\' -f "$ssh_key_path" -C "$ssh_key_title" >/dev/null
            fi
            touch "$HOME/.ssh/known_hosts"
            chmod 600 "$HOME/.ssh/known_hosts"
            if ! ssh-keygen -F github.com -f "$HOME/.ssh/known_hosts" >/dev/null; then
              ssh-keyscan github.com >> "$HOME/.ssh/known_hosts" 2>/dev/null
            fi
            pubkey="$(cat "$ssh_key_path.pub")"
            existing_id="$(PUBKEY="$pubkey" python3 -c "{FIND_EXISTING_SSH_KEY_ID_PYTHON}" <<<"$existing_keys_json")"
            if [[ -z "$existing_id" ]]; then
              if ! gh ssh-key add "$ssh_key_path.pub" --title "$ssh_key_title" >/dev/null 2>&1; then
                printf \'Failed to register the env SSH key with GitHub. Ensure the local gh token grants SSH key management access.
\' >&2
                exit 1
              fi
            fi
            ''')])
	B=['# Persist the HTTPS git credential helper.','git config --global --unset-all credential.https://github.com.helper || true',"git config --global --add credential.https://github.com.helper ''","git config --global --add credential.https://github.com.helper '!gh auth git-credential'"]
	if C:B=['# Persist the GitHub SSH host config and HTTPS git credential helper.','cat > "$HOME/.ssh/config" <<\'EOF_GV_GITHUB_SSH\'',GITHUB_SSH_CONFIG.rstrip(),'EOF_GV_GITHUB_SSH','chmod 600 "$HOME/.ssh/config"',*B[1:]]
	A.append('\n'.join((*B,"printf 'GitHub auth enabled.\\n'")));return _join_script_sections(*A)
def _enable_manual_pat_script(github_token:str)->str:A=_shell_single_quote(github_token);B=_shell_single_quote(MANUAL_PAT_CREDENTIAL_HELPER);return _join_script_sections('set -euo pipefail',dedent(f'''            # Store the pasted token in a user-owned file readable only by this account.
            install -d -m 700 "$HOME/.config/gv" "$HOME/.config/gv/env.d"
            token_file="{MANUAL_PAT_TOKEN_PATH}"
            env_file="{MANUAL_PAT_ENV_PATH}"
            umask 077
            printf \'%s\' \'{A}\' > "$token_file"
            chmod 600 "$token_file"
            '''),dedent('            # Expose GH_TOKEN for future interactive shells so gh can use fine-grained PATs.\n            cat > "$env_file" <<\'EOF_GV_GITHUB_PAT_ENV\'\n            # Generated by tabtabtab github enable.\n            _gv_github_token_file="$HOME/.config/gv/github-token"\n            if [ -r "$_gv_github_token_file" ]; then\n              export GH_TOKEN="$(cat "$_gv_github_token_file")"\n            fi\n            unset _gv_github_token_file\n            EOF_GV_GITHUB_PAT_ENV\n            chmod 600 "$env_file"\n            '),_managed_shell_source_script(),_remove_managed_git_helpers_script(),dedent(rf"""            # Persist an HTTPS git credential helper that reads the token from disk.
            manual_helper='{B}'
            git config --global --add credential.https://github.com.helper "$manual_helper"
            printf 'GitHub auth enabled.\n'
            """))
def _disable_script()->str:return _join_script_sections('set -euo pipefail','\n'.join(('# Remove VM-side GitHub App auth, refresh runtime, legacy SSH material, and HTTPS git helper config.','sudo systemctl disable --now gv-github-app-token-refresh.timer >/dev/null 2>&1 || true','sudo systemctl disable --now gv-github-app-token-refresh.service >/dev/null 2>&1 || true','sudo rm -f /etc/systemd/system/gv-github-app-token-refresh.timer','sudo rm -f /etc/systemd/system/gv-github-app-token-refresh.service','sudo rm -f /opt/nero/bin/gv-github-app-token-refresh','sudo systemctl daemon-reload >/dev/null 2>&1 || true',f"sudo rm -rf {GITHUB_APP_GH_CONFIG_DIR}",f"sudo rm -f {GITHUB_APP_TOKEN_METADATA_PATH}",'rm -f "$HOME/.config/gh/hosts.yml"',f'rm -f "{MANUAL_PAT_TOKEN_PATH}" "{MANUAL_PAT_ENV_PATH}"','rm -f "$HOME/.ssh/id_ed25519_github" "$HOME/.ssh/id_ed25519_github.pub"','if [[ -f "$HOME/.ssh/config" ]]; then',"python3 - <<'PY'",REMOVE_MANAGED_SSH_CONFIG_PYTHON.rstrip(),'PY','fi',_remove_managed_shell_source_script(),_remove_managed_git_helpers_script(),"printf 'GitHub auth disabled.\\n'")))
def _status_script()->str:A=_shell_single_quote(MANUAL_PAT_CREDENTIAL_HELPER);return _join_script_sections('set -euo pipefail','\n'.join(('# Report enabled when gh auth and the managed git credential helper are present.',f"GH_CONFIG_DIR={GITHUB_APP_GH_CONFIG_DIR}",'command -v gh >/dev/null || {',"  printf 'gh not installed\\n' >&2",'  exit 1','}','if [ -f "$GH_CONFIG_DIR/hosts.yml" ] && GH_CONFIG_DIR="$GH_CONFIG_DIR" gh auth status --hostname github.com >/dev/null 2>&1; then',f"  if git config --global --get-all credential.https://github.com.helper | grep -Fxq '{GITHUB_APP_CREDENTIAL_HELPER}'; then","    printf 'enabled\\n'",'    exit 0','  fi','fi',"printf 'disabled\\n'",'exit 10')))
def _managed_shell_source_script()->str:A='# >>> gv github token >>>';B='# <<< gv github token <<<';C=dedent(f'''        {A}
        if [ -r "{MANUAL_PAT_ENV_PATH}" ]; then
          . "{MANUAL_PAT_ENV_PATH}"
        fi
        {B}
        ''').rstrip();D=_shell_single_quote(C);return'\n'.join(('# Source the TabTabTab GitHub token snippet from common interactive shell profiles.',f"managed_block='{D}'",'for profile in "$HOME/.profile" "$HOME/.bashrc" "$HOME/.zshrc"; do','  touch "$profile"',f"  if ! grep -Fqx '{A}' \"$profile\"; then",'    printf \'\\n%s\\n\' "$managed_block" >> "$profile"','  fi','done'))
def _remove_managed_shell_source_script()->str:A='# >>> gv github token >>>';B='# <<< gv github token <<<';return dedent(rf"""        python3 - <<'PY'
        from pathlib import Path

        marker_start = {A!r}
        marker_end = {B!r}
        for path in (Path.home() / '.profile', Path.home() / '.bashrc', Path.home() / '.zshrc'):
            if not path.exists():
                continue
            lines = path.read_text().splitlines()
            output = []
            skipping = False
            changed = False
            for line in lines:
                if line == marker_start:
                    skipping = True
                    changed = True
                    continue
                if skipping and line == marker_end:
                    skipping = False
                    continue
                if not skipping:
                    output.append(line)
            if changed:
                text = '\n'.join(output).rstrip() + ('\n' if output else '')
                path.write_text(text)
        PY
        """).rstrip()
def _remove_managed_git_helpers_script()->str:A=_shell_single_quote(LOCAL_GH_CREDENTIAL_HELPER);B=_shell_single_quote(MANUAL_PAT_CREDENTIAL_HELPER);C=_shell_single_quote(GITHUB_APP_CREDENTIAL_HELPER);return dedent(f'''        local_helper=\'{A}\'
        manual_helper=\'{B}\'
        app_helper=\'{C}\'
        mapfile -t existing_helpers < <(git config --global --get-all credential.https://github.com.helper 2>/dev/null || true)
        git config --global --unset-all credential.https://github.com.helper || true
        for helper in "${{existing_helpers[@]}}"; do
          if [[ "$helper" == "$local_helper" || "$helper" == "$manual_helper" || "$helper" == "$app_helper" || -z "$helper" ]]; then
            continue
          fi
          git config --global --add credential.https://github.com.helper "$helper"
        done
        ''').rstrip()
def _stderr_message(result:subprocess.CompletedProcess[str],fallback:str)->str:A=result;B=(A.stderr or A.stdout or'').strip();return B or fallback
def _ssh_key_title(hostname:str)->str:return f"gv-{hostname}-github"
def _shell_single_quote(value:str)->str:return value.replace("'",'\'"\'"\'')
def _join_script_sections(*A:str)->str:return'\n\n'.join(A.strip('\n')for A in A if A).strip()+'\n'