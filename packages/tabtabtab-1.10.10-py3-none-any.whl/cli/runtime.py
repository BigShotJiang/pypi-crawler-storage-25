from __future__ import annotations
import hashlib,json,os,re,subprocess
from dataclasses import dataclass
from datetime import datetime,timezone
from pathlib import Path
from typing import Any,Literal
from urllib import error,request
GV_ENVIRONMENT_FILE=Path('/etc/gv/environment')
RUNTIME_DIR_NAME='.gv'
RUNTIME_METADATA_NAME='runtime.json'
RUNTIME_ID_PREFIX='gv-'
RUNTIME_LABEL='gv.runtime'
DEVCONTAINER_LABEL='devcontainer.local_folder'
OUTSIDE_GV_MESSAGE='`tabtabtab runtime {command}` must be run inside a TabTabTab environment workspace.\nUse `tabtabtab ssh <env>` or ask the agent to start the app.'
RuntimeMode=Literal['devcontainer','none']
DevcontainerShape=Literal['compose','single']
@dataclass(frozen=True)
class RuntimeContext:worktree:Path;project_root:Path;repo_root:Path;runtime_id:str;metadata_path:Path
@dataclass(frozen=True)
class RuntimePort:runtime:str;service:str;container:str;container_port:int;host_port:int|None;protocol:str
@dataclass(frozen=True)
class DevcontainerConfig:shape:DevcontainerShape;config_path:Path;workspace_folder:Path;compose_files:tuple[Path,...]=();service:str|None=None
def ensure_gv_environment(command:str)->None:
	A=Path(os.environ.get('GV_ENVIRONMENT_FILE',str(GV_ENVIRONMENT_FILE)))
	if not A.is_file():raise RuntimeError(OUTSIDE_GV_MESSAGE.format(command=command))
def runtime_context(command:str='up')->RuntimeContext:
	B=command;ensure_gv_environment(B);E=Path.cwd().resolve();A=_git_toplevel(E)
	if A is None:raise RuntimeError(f"`tabtabtab runtime {B}` must be run from a repository workspace inside a TabTabTab environment.")
	C=A;D=_git_project_root(A);F=build_runtime_id(D,C);G=A/RUNTIME_DIR_NAME/RUNTIME_METADATA_NAME;return RuntimeContext(worktree=C,project_root=D,repo_root=A,runtime_id=F,metadata_path=G)
def build_runtime_id(repo_root:Path,worktree:Path)->str:A=worktree;B=_runtime_id_part(repo_root.name);C=_runtime_id_part(A.name);D=hashlib.sha256(str(A).encode('utf-8')).hexdigest()[:6];return f"{RUNTIME_ID_PREFIX}{B}-{C}-{D}"
def handle_runtime_up()->int:
	A=runtime_context('up');B=_detect_runtime_mode(A.repo_root)
	if B=='none':raise RuntimeError('`tabtabtab runtime` requires `.devcontainer/devcontainer.json`. This repo is not yet onboarded to the TabTabTab runtime contract.')
	C=load_devcontainer_config(A.repo_root);_run_devcontainer_up(A,C);_write_metadata(A,B,detail=C.shape);print(f"Runtime {A.runtime_id} is running.");return 0
def handle_runtime_status()->int:
	A=runtime_context('status');C=_read_metadata(A.metadata_path);B=_runtime_mode_for_context(A,C);D=_runtime_detail_for_context(A,C,B);print(f"Runtime: {A.runtime_id}");print(f"Mode: {B}{f" ({D})"if D else""}");print(f"Worktree: {A.worktree}");print(f"Compose project: {A.runtime_id}")
	if B=='devcontainer':
		E=_docker_ps_for_runtime(A.runtime_id)
		if E:print('');print(E)
		else:print('Status: not running or unavailable')
	else:print('Status: no managed runtime found')
	F=list_runtime_ports(A.runtime_id)
	if F:print('');_print_ports(F,include_runtime=False)
	return 0
def handle_runtime_ports(*,all_runtimes:bool)->int:
	if all_runtimes:ensure_gv_environment('ports');A=list_all_runtime_ports();_print_ports(A,include_runtime=True);return 0
	B=runtime_context('ports');A=list_runtime_ports(B.runtime_id);_print_ports(A,include_runtime=False);return 0
def handle_runtime_preview(target:str)->int:A=runtime_context('preview');B=_resolve_preview_port(A.runtime_id,target);C=create_preview_url(B);print(C);return 0
def handle_runtime_logs()->int:
	A=runtime_context('logs');E=_runtime_mode_for_context(A,_read_metadata(A.metadata_path))
	if E=='devcontainer':
		B=_container_ids_for_runtime(A.runtime_id)
		if not B:raise RuntimeError('No devcontainer runtime is currently running.')
		C=0
		for F in B:
			D=_run_docker(['logs',F],check=False)
			if D.returncode!=0:C=D.returncode
		return C
	raise RuntimeError('No managed runtime found for this workspace.')
def handle_runtime_down()->int:
	A=runtime_context('down');B=_read_metadata(A.metadata_path);C=_runtime_mode_for_context(A,B)
	if C=='devcontainer':D=load_devcontainer_config(A.repo_root);_run_devcontainer_down(A,D)
	else:raise RuntimeError('No managed runtime found for this workspace.')
	print(f"Runtime {A.runtime_id} stopped.");return 0
def handle_runtime_rebuild()->int:
	A=runtime_context('rebuild');C=_detect_runtime_mode(A.repo_root)
	if C=='devcontainer':B=load_devcontainer_config(A.repo_root);_run_devcontainer_down(A,B,ignore_missing=True);_run_devcontainer_up(A,B,rebuild=True);_write_metadata(A,C,detail=B.shape);print(f"Runtime {A.runtime_id} rebuilt and running.");return 0
	raise RuntimeError('No managed runtime found for this workspace.')
def list_runtime_ports(runtime_id:str)->list[RuntimePort]:return[A for A in _docker_ports()if A.runtime==runtime_id]
def list_all_runtime_ports()->list[RuntimePort]:return[A for A in _docker_ports()if A.runtime.startswith(RUNTIME_ID_PREFIX)]
def create_preview_url(host_port:int)->str:
	E=os.environ.get('GV_PREVIEW_API_URL','http://127.0.0.1:42557/preview');C=os.environ.get('GV_PREVIEW_API_TOKEN','');F=json.dumps({'port':host_port}).encode('utf-8');D={'Content-Type':'application/json'}
	if C:D['Authorization']=f"Bearer {C}"
	G=request.Request(E,data=F,headers=D,method='POST')
	try:
		with request.urlopen(G,timeout=30)as H:I=H.read().decode('utf-8')
	except error.HTTPError as A:J=A.read().decode('utf-8',errors='replace').strip();raise RuntimeError(f"Preview request failed: HTTP {A.code} {J}")from A
	except error.URLError as A:raise RuntimeError(f"Preview request failed: {A}")from A
	K=json.loads(I or'{}');B=K.get('url')
	if not isinstance(B,str)or not B:raise RuntimeError('Preview request succeeded but did not return a URL')
	return B
def load_devcontainer_config(repo_root:Path)->DevcontainerConfig:
	C=repo_root;A=C/'.devcontainer'/'devcontainer.json'
	try:B=json.loads(A.read_text(encoding='utf-8'))
	except FileNotFoundError as E:raise RuntimeError(f"Devcontainer config not found at {A}.")from E
	except json.JSONDecodeError as E:raise RuntimeError(f"Invalid devcontainer JSON at {A}: {E}")from E
	if not isinstance(B,dict):raise RuntimeError(f"Invalid devcontainer config at {A}: top level must be an object.")
	if'dockerComposeFile'in B:
		H=_resolve_devcontainer_compose_files(A,B['dockerComposeFile']);F=B.get('service')
		if not isinstance(F,str)or not F.strip():raise RuntimeError('Unsupported devcontainer shape: `dockerComposeFile` requires a string `service`.')
		return DevcontainerConfig(shape='compose',config_path=A,workspace_folder=C,compose_files=H,service=F.strip())
	if isinstance(B.get('image'),str)and B['image'].strip():return DevcontainerConfig(shape='single',config_path=A,workspace_folder=C)
	D=B.get('build')
	if isinstance(D,dict):
		G=D.get('dockerfile')or D.get('dockerFile')
		if isinstance(G,str)and G.strip():return DevcontainerConfig(shape='single',config_path=A,workspace_folder=C)
	if isinstance(D,str)and D.strip():return DevcontainerConfig(shape='single',config_path=A,workspace_folder=C)
	raise RuntimeError('This devcontainer shape is not supported by `tabtabtab runtime` yet. Supported shapes: `dockerComposeFile`, `image`, and `build.dockerfile`.')
def _runtime_id_part(value:str)->str:A=re.sub('[^a-z0-9]+','-',value.lower());A=re.sub('-+','-',A).strip('-');return(A or'workspace')[:12]
def _git_toplevel(path:Path)->Path|None:
	A=subprocess.run(['git','-C',str(path),'rev-parse','--show-toplevel'],text=True,capture_output=True,check=False)
	if A.returncode!=0:return
	return Path(A.stdout.strip()).resolve()
def _git_project_root(repo_root:Path)->Path:
	B=repo_root;C=subprocess.run(['git','-C',str(B),'rev-parse','--git-common-dir'],text=True,capture_output=True,check=False)
	if C.returncode!=0:return B
	A=Path(C.stdout.strip())
	if not A.is_absolute():A=(B/A).resolve()
	else:A=A.resolve()
	if A.name=='.git':return A.parent
	return B
def _detect_runtime_mode(repo_root:Path)->RuntimeMode:
	if(repo_root/'.devcontainer'/'devcontainer.json').is_file():return'devcontainer'
	return'none'
def _runtime_mode_for_context(ctx:RuntimeContext,metadata:dict[str,Any])->RuntimeMode:
	A=metadata.get('mode')
	if A in{'devcontainer','none'}:return A
	return _detect_runtime_mode(ctx.repo_root)
def _runtime_detail_for_context(ctx:RuntimeContext,metadata:dict[str,Any],mode:RuntimeMode)->str|None:
	A=metadata.get('detail')
	if isinstance(A,str)and A:return A
	if mode!='devcontainer':return
	try:return load_devcontainer_config(ctx.repo_root).shape
	except RuntimeError:return
def _compose_env(ctx:RuntimeContext)->dict[str,str]:A=os.environ.copy();A['COMPOSE_PROJECT_NAME']=ctx.runtime_id;return A
def _run_docker(args:list[str],*,check:bool,capture_output:bool=False,cwd:Path|None=None)->subprocess.CompletedProcess[str]:return subprocess.run(['docker',*args],text=True,capture_output=capture_output,check=check,cwd=cwd)
def _run_devcontainer_up(ctx:RuntimeContext,config:DevcontainerConfig,*,rebuild:bool=False)->None:
	A=ctx;B=['devcontainer','up','--workspace-folder',str(config.workspace_folder),'--id-label',f"{RUNTIME_LABEL}={A.runtime_id}"]
	if rebuild:B.append('--remove-existing-container')
	subprocess.run(B,cwd=A.repo_root,env=_compose_env(A),text=True,check=True)
def _run_devcontainer_down(ctx:RuntimeContext,config:DevcontainerConfig,*,ignore_missing:bool=False)->None:
	B=ignore_missing;A=config
	if A.shape=='compose':_run_devcontainer_compose_down(ctx,A,ignore_missing=B);return
	C=_container_ids_for_runtime(ctx.runtime_id)
	if not C:
		if B:return
		raise RuntimeError('No devcontainer runtime is currently running.')
	_run_docker(['rm','-f',*C],check=True)
def _run_devcontainer_compose_down(ctx:RuntimeContext,config:DevcontainerConfig,*,ignore_missing:bool)->None:
	C=config;A=['docker','compose']
	for D in C.compose_files:A.extend(['-f',str(D)])
	A.append('down');B=subprocess.run(A,cwd=C.config_path.parent,env=_compose_env(ctx),text=True,capture_output=True,check=False)
	if B.returncode==0:return
	if ignore_missing:return
	E=(B.stderr or B.stdout or'').strip();raise RuntimeError(E or'Failed to stop devcontainer compose runtime.')
def _write_metadata(ctx:RuntimeContext,mode:RuntimeMode,detail:str|None=None)->None:
	B=detail;A=ctx;A.metadata_path.parent.mkdir(parents=True,exist_ok=True);C:dict[str,Any]={'id':A.runtime_id,'mode':mode,'worktree':str(A.worktree),'repoRoot':str(A.repo_root),'composeProject':A.runtime_id,'startedAt':datetime.now(timezone.utc).isoformat()}
	if B:C['detail']=B
	A.metadata_path.write_text(json.dumps(C,indent=2,sort_keys=True)+'\n')
def _read_metadata(path:Path)->dict[str,Any]:
	if not path.is_file():return{}
	try:A=json.loads(path.read_text(encoding='utf-8'))
	except(OSError,json.JSONDecodeError):return{}
	return A if isinstance(A,dict)else{}
def _docker_ps_for_runtime(runtime_id:str)->str:A=_run_docker(['ps','--filter',f"label={RUNTIME_LABEL}={runtime_id}"],check=False,capture_output=True);return A.stdout.strip()
def _container_ids_for_runtime(runtime_id:str)->list[str]:A=_run_docker(['ps','-aq','--filter',f"label={RUNTIME_LABEL}={runtime_id}"],check=False,capture_output=True);return[A.strip()for A in A.stdout.splitlines()if A.strip()]
def _docker_ports()->list[RuntimePort]:
	G=_run_docker(['ps','--format','{{json .}}'],check=False,capture_output=True)
	if G.returncode!=0:return[]
	E:list[dict[str,Any]]=[]
	for C in G.stdout.splitlines():
		C=C.strip()
		if not C:continue
		try:H=json.loads(C)
		except json.JSONDecodeError:continue
		I=H.get('ID')
		if isinstance(I,str)and I:E.append(H)
	if not E:return[]
	U=[str(A['ID'])for A in E];J=_run_docker(['inspect',*U],check=False,capture_output=True)
	if J.returncode!=0:return[]
	try:K=json.loads(J.stdout)
	except json.JSONDecodeError:return[]
	D:list[RuntimePort]=[]
	if not isinstance(K,list):return D
	for A in K:
		if not isinstance(A,dict):continue
		B=A.get('Config',{}).get('Labels',{})
		if not isinstance(B,dict):B={}
		L=str(B.get(RUNTIME_LABEL)or B.get('com.docker.compose.project')or'');M=str(B.get('com.docker.compose.service')or B.get('devcontainer.metadata.service')or _container_name(A));N=A.get('NetworkSettings',{});O=N.get('Ports',{})if isinstance(N,dict)else{}
		if not isinstance(O,dict):continue
		for(V,F)in O.items():
			P=_parse_container_port(str(V))
			if P is None:continue
			Q,R=P
			if not F:D.append(RuntimePort(runtime=L,service=M,container=_container_name(A),container_port=Q,host_port=None,protocol=R));continue
			if not isinstance(F,list):continue
			for S in F:
				if not isinstance(S,dict):continue
				W=S.get('HostPort')
				try:T=int(str(W))
				except(TypeError,ValueError):T=None
				D.append(RuntimePort(runtime=L,service=M,container=_container_name(A),container_port=Q,host_port=T,protocol=R))
	return D
def _parse_container_port(value:str)->tuple[int,str]|None:
	A,D,B=value.partition('/')
	try:C=int(A)
	except ValueError:return
	return C,B or'tcp'
def _container_name(container:dict[str,Any])->str:A=container;B=str(A.get('Name')or'').lstrip('/');return B or str(A.get('Id')or'')[:12]
def _print_ports(ports:list[RuntimePort],*,include_runtime:bool)->None:
	G=include_runtime;F=ports
	if not F:print('No runtime ports found.');return
	C=['SERVICE','CONTAINER','HOST','PROTO'];E:list[list[str]]=[]
	if G:C.insert(0,'RUNTIME')
	for B in F:
		A=[B.service,str(B.container_port),str(B.host_port)if B.host_port else'-',B.protocol]
		if G:A.insert(0,B.runtime)
		E.append(A)
	D=[len(A)for A in C]
	for A in E:
		for(H,I)in enumerate(A):D[H]=max(D[H],len(I))
	print('  '.join(C[A].ljust(D[A])for A in range(len(C))))
	for A in E:print('  '.join(A[B].ljust(D[B])for B in range(len(A))))
def _resolve_preview_port(runtime_id:str,target:str)->int:
	A=target
	if A.isdigit():
		C=int(A)
		if C<1 or C>65535:raise RuntimeError('Preview port must be between 1 and 65535.')
		return C
	B=[B for B in list_runtime_ports(runtime_id)if B.service==A and B.host_port is not None]
	if not B:raise RuntimeError(f"No published host port found for service `{A}`.")
	if len(B)>1:D=', '.join(f"{A.service}:{A.container_port}->{A.host_port}"for A in B);raise RuntimeError(f"Service `{A}` has multiple published ports. Use a host port instead: {D}")
	return int(B[0].host_port)
def _resolve_devcontainer_compose_files(config_path:Path,value:Any)->tuple[Path,...]:
	A=value;B:list[str]
	if isinstance(A,str)and A.strip():B=[A.strip()]
	elif isinstance(A,list):B=[A.strip()for A in A if isinstance(A,str)and A.strip()]
	else:raise RuntimeError('Unsupported devcontainer shape: `dockerComposeFile` must be a string or list of strings.')
	if not B:raise RuntimeError('Unsupported devcontainer shape: `dockerComposeFile` must not be empty.')
	C=config_path.parent;return tuple((C/A).resolve()for A in B)