from __future__ import annotations
import base64,json,subprocess
from typing import Any,Protocol
from.import ssh_access
from.auth_session import get_valid_access_token,load_cli_config
CURRENT_ENV_CONFIG_KEY='current_env_by_api_url'
REMOTE_GV_CONFIG_PATH='$HOME/.config/gv/config.json'
OAUTH_CONFIG_KEYS='access_token','refresh_token','expires_at','token_endpoint','client_id'
class EnvLike(Protocol):id:str;name:str
def build_local_remote_config(api_url:str,env:EnvLike)->dict[str,Any]:get_valid_access_token();return build_remote_config(api_url,env,load_cli_config())
def build_remote_config(api_url:str,env:EnvLike,local_config:dict[str,Any])->dict[str,Any]:A=api_url;B=_remote_oauth_config(local_config.get('oauth'));return{'api_url':A,CURRENT_ENV_CONFIG_KEY:{A:{'id':env.id,'name':env.name}},'oauth':B}
def install_local_gv_config(api_url:str,env:EnvLike,ssh_details:ssh_access.EnvSshAccess)->None:install_gv_config(env.id,ssh_details,build_local_remote_config(api_url,env))
def install_gv_config(env_id:str,ssh_details:ssh_access.EnvSshAccess,remote_config:dict[str,Any])->None:
	A=ssh_access.run_ssh_process(env_id,ssh_details,('bash','-se'),input_text=_install_script(remote_config),capture_output=True)
	if A.returncode!=0:raise RuntimeError(_stderr_message(A,'Failed to install gv config.'))
def _remote_oauth_config(value:Any)->dict[str,Any]:
	A=value
	if not isinstance(A,dict):raise RuntimeError('Not logged in. Run `tabtabtab auth login` first.')
	B=A.get('access_token')
	if not isinstance(B,str)or not B.strip():raise RuntimeError('Not logged in. Run `tabtabtab auth login` first.')
	C:dict[str,Any]={}
	for D in OAUTH_CONFIG_KEYS:
		E=A.get(D)
		if E is not None:C[D]=E
	return C
def _install_script(remote_config:dict[str,Any])->str:A=json.dumps(remote_config,indent=2,sort_keys=True);B=base64.b64encode(A.encode('utf-8')).decode('ascii');return _join_script_sections('set -euo pipefail','\n'.join(('# Decode the config as base64 so token values are not embedded raw in shell syntax.',f"config_json=\"$(printf '%s' '{B}' | base64 -d)\"",f'config_path="{REMOTE_GV_CONFIG_PATH}"')),'\n'.join(('# Write the gv CLI config for the SSH user.','install -d -m 700 "$HOME/.config/gv"','umask 077','printf \'%s\\n\' "$config_json" > "$config_path"','chmod 600 "$config_path"',"printf 'gv config installed.\\n'")))
def _stderr_message(result:subprocess.CompletedProcess[str],fallback:str)->str:A=result;B=(A.stderr or A.stdout or'').strip();return B or fallback
def _join_script_sections(*A:str)->str:return'\n\n'.join(A.strip('\n')for A in A if A).strip()+'\n'