from __future__ import annotations
import time
from collections.abc import Callable
from typing import Any,Protocol
import click
from.browser_launcher import open_url
GITHUB_AUTH_POLL_INTERVAL_SECONDS=5
GITHUB_AUTH_TIMEOUT_SECONDS=600
GITHUB_APP_INSTALL_URL='https://github.com/apps/ttt-gv/installations/new'
GITHUB_APP_ORG_INSTALL_INSTRUCTIONS=f"\nNEXT STEP: Grant repo access before adding repositories:\n{GITHUB_APP_INSTALL_URL}\nThis is separate from the account authorization that was just installed.\n"
GITHUB_AUTH_STEP_LABELS={'installing_on_vm':'installing access','installed':'connected','waiting_for_callback':'waiting for approval'}
class GitHubAuthEnv(Protocol):id:str;name:str
RequestApiJson=Callable[[str,str,str],dict[str,Any]]
InteractiveCheck=Callable[[],bool]
def create_github_app_auth_session(api_url:str,env:GitHubAuthEnv,*,request_api_json:RequestApiJson)->tuple[str,str]:
	C=request_api_json(api_url,'POST',f"/v1/envs/{env.id}/github-app-auth/sessions");A=C.get('state');B=C.get('authorizationUrl')
	if not isinstance(A,str)or not A:raise RuntimeError('TabTabTab returned an invalid GitHub auth session response')
	if not isinstance(B,str)or not B:raise RuntimeError('TabTabTab returned an invalid GitHub authorization URL')
	return A,B
def poll_github_app_auth_session(api_url:str,env:GitHubAuthEnv,state:str,*,request_api_json:RequestApiJson,timeout_seconds:int=GITHUB_AUTH_TIMEOUT_SECONDS,poll_interval_seconds:int=GITHUB_AUTH_POLL_INTERVAL_SECONDS)->str:
	E=time.monotonic()+timeout_seconds;D:str|None=None
	while time.monotonic()<E:
		F=request_api_json(api_url,'GET',f"/v1/envs/{env.id}/github-app-auth/sessions/{state}");A=F.get('session')
		if not isinstance(A,dict):raise RuntimeError('TabTabTab returned an invalid GitHub auth status response')
		C=str(A.get('status')or'');B=str(A.get('step')or C)
		if B and B!=D:G=GITHUB_AUTH_STEP_LABELS.get(B,B.replace('_',' '));click.echo(f"Account authorization: {G}");D=B
		if C=='installed':H=A.get('githubLogin');return str(H or'GitHub')
		if C in{'failed','expired'}:I=A.get('errorMessage');raise RuntimeError(str(I or'GitHub authorization did not complete.'))
		time.sleep(poll_interval_seconds)
	raise RuntimeError('Timed out waiting for GitHub authorization to finish.')
def run_github_app_auth_flow(api_url:str,env:GitHubAuthEnv,*,request_api_json:RequestApiJson,is_interactive_input:InteractiveCheck,poll_interval_seconds:int=GITHUB_AUTH_POLL_INTERVAL_SECONDS)->str:
	C=request_api_json;B=api_url;A=env;F,D=create_github_app_auth_session(B,A,request_api_json=C);click.echo(f"Open this GitHub URL to authorize {A.name}:");click.echo(D)
	if is_interactive_input():
		E=open_url(D)
		if E.opened:click.echo('Opened GitHub in your browser.')
		elif E.attempted:click.echo('Could not open a browser automatically; use the URL above.')
		else:click.echo('No local browser launcher was detected; use the URL above.')
	return poll_github_app_auth_session(B,A,F,request_api_json=C,poll_interval_seconds=poll_interval_seconds)
def confirm_github_app_install_instructions(*,is_interactive_input:InteractiveCheck)->bool:
	click.echo(GITHUB_APP_ORG_INSTALL_INSTRUCTIONS)
	if not is_interactive_input():return False
	A=click.prompt("Type 'done' after repo access is granted, or 'skip' to finish without repo setup",type=click.Choice(['done','skip'],case_sensitive=False),show_choices=False)
	if A.lower()=='skip':return False
	return True