from __future__ import annotations
import os,re,subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any,Callable
from.auth_session import CONFIG_DIR
SSH_KEYS_DIR=CONFIG_DIR/'ssh'
LOCAL_SSH_DIR=Path.home()/'.ssh'
LOCAL_SSH_CONFIG_PATH=LOCAL_SSH_DIR/'config'
MANAGED_BLOCK_PATTERN=re.compile('# >>> gv env [^\\n]+ >>>\\n.*?# <<< gv env [^\\n]+ <<<\\n?',re.DOTALL)
@dataclass(frozen=True)
class EnvSshAccess:
	public_ip:str;private_key:str;username:str='ubuntu';fingerprint:str|None=None
	@classmethod
	def from_payload(B,payload:dict[str,Any])->'EnvSshAccess':A=payload;return B(public_ip=str(A['publicIp']),private_key=str(A['privateKey']),username=str(A.get('username')or'ubuntu'),fingerprint=_optional_string(A.get('fingerprint')))
def fetch_env_ssh_access(api_url:str,env_id:str,request_api_json:Callable[[str,str,str],dict[str,Any]])->EnvSshAccess:
	B=request_api_json(api_url,'GET',f"/v1/envs/{env_id}/ssh");A=B.get('ssh')
	if not isinstance(A,dict):raise RuntimeError('TabTabTab returned an invalid SSH response')
	return EnvSshAccess.from_payload(A)
def write_private_key_to_config(env_id:str,private_key:str)->str:SSH_KEYS_DIR.mkdir(parents=True,exist_ok=True);os.chmod(SSH_KEYS_DIR,448);A=SSH_KEYS_DIR/f"{env_id}.key";A.write_text(private_key,encoding='utf-8');os.chmod(A,384);return str(A)
def build_env_ssh_alias(env_name:str)->str:A=re.sub('[^a-zA-Z0-9-]+','-',env_name).strip('-');B=re.sub('-{2,}','-',A);return f"gv-{B or"env"}"
def install_ssh_config_entry(env_id:str,env_name:str,ssh_access:EnvSshAccess)->str:
	D=ssh_access;C=env_id;J=write_private_key_to_config(C,D.private_key);E=build_env_ssh_alias(env_name);LOCAL_SSH_DIR.mkdir(parents=True,exist_ok=True);os.chmod(LOCAL_SSH_DIR,448);F=f"# >>> gv env {C} >>>";G=f"# <<< gv env {C} <<<";H='\n'.join([F,f"Host {E}",f"  HostName {D.public_ip}",f"  User {D.username}",f"  IdentityFile {J}",'  IdentitiesOnly yes','  StrictHostKeyChecking accept-new',G,'']);B=''
	if LOCAL_SSH_CONFIG_PATH.exists():B=LOCAL_SSH_CONFIG_PATH.read_text(encoding='utf-8')
	I=re.compile(rf"{re.escape(F)}\n.*?{re.escape(G)}\n?",re.DOTALL)
	if I.search(B):A=I.sub(H,B)
	else:
		A=B
		if A and not A.endswith('\n'):A+='\n'
		A+=H
	LOCAL_SSH_CONFIG_PATH.write_text(A,encoding='utf-8');os.chmod(LOCAL_SSH_CONFIG_PATH,384);return E
def clear_managed_ssh_state()->tuple[int,int]:A=_remove_cached_private_keys();B=_remove_managed_ssh_config_blocks();return A,B
def build_ssh_transport_command(key_path:str,*,allocate_tty:bool=False)->list[str]:
	A=['ssh']
	if allocate_tty:A.append('-tt')
	A.extend(['-i',key_path,'-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=accept-new']);return A
def build_ssh_command(host:str,username:str,key_path:str,ssh_args:tuple[str,...],*,allocate_tty:bool=False)->list[str]:A=build_ssh_transport_command(key_path,allocate_tty=allocate_tty);A.append(f"{username}@{host}");A.extend(ssh_args);return A
def run_ssh_process(env_id:str,ssh_access:EnvSshAccess,ssh_args:tuple[str,...],*,input_text:str|None=None,capture_output:bool=False)->subprocess.CompletedProcess[str]:
	A=ssh_access;B=write_private_key_to_config(env_id,A.private_key);C=build_ssh_command(A.public_ip,A.username,B,ssh_args)
	try:return subprocess.run(C,check=False,input=input_text,text=True,capture_output=capture_output)
	except FileNotFoundError as D:raise RuntimeError('OpenSSH client (`ssh`) is required for this command.')from D
def run_ssh(env_id:str,ssh_access:EnvSshAccess,ssh_args:tuple[str,...])->int:A=run_ssh_process(env_id,ssh_access,ssh_args);return int(A.returncode)
def exec_ssh(env_id:str,ssh_access:EnvSshAccess,ssh_args:tuple[str,...],*,allocate_tty:bool=False)->None:
	A=ssh_access;C=write_private_key_to_config(env_id,A.private_key);B=build_ssh_command(A.public_ip,A.username,C,ssh_args,allocate_tty=allocate_tty)
	try:os.execvpe(B[0],B,os.environ.copy())
	except FileNotFoundError as D:raise RuntimeError('OpenSSH client (`ssh`) is required for this command.')from D
def _optional_string(value:Any)->str|None:
	A=value
	if A is None:return
	return str(A)
def _remove_cached_private_keys()->int:
	if not SSH_KEYS_DIR.exists():return 0
	A=0
	for B in SSH_KEYS_DIR.glob('*.key'):
		if not B.is_file():continue
		B.unlink();A+=1
	try:SSH_KEYS_DIR.rmdir()
	except OSError:pass
	return A
def _remove_managed_ssh_config_blocks()->int:
	if not LOCAL_SSH_CONFIG_PATH.exists():return 0
	C=LOCAL_SSH_CONFIG_PATH.read_text(encoding='utf-8');A,B=MANAGED_BLOCK_PATTERN.subn('',C)
	if B==0:return 0
	A=A.lstrip('\n')
	if A.strip():LOCAL_SSH_CONFIG_PATH.write_text(A,encoding='utf-8');os.chmod(LOCAL_SSH_CONFIG_PATH,384)
	else:LOCAL_SSH_CONFIG_PATH.unlink()
	return B