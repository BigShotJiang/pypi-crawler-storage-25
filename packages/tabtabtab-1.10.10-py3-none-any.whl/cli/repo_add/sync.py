from __future__ import annotations
import httpx
from..http_client import api_base_url,auth_headers,raise_for_response
from..repo_env.resolve import RepoRef
from.schema import RepoAddRequest
async def post_repo_add(request:RepoAddRequest)->RepoRef:
	async with httpx.AsyncClient(timeout=30,headers=auth_headers())as C:A=await C.post(f"{api_base_url()}/v1/repos",json=request.model_dump(mode='json',by_alias=True));raise_for_response(A);D=A.json()
	B=D.get('repo')
	if not isinstance(B,dict):raise RuntimeError('TabTabTab returned an invalid repo response')
	return RepoRef.from_payload(B)