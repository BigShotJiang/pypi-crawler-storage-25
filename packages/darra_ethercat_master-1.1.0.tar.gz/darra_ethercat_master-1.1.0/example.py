# -*- coding: utf-8 -*-
"""
DarraEtherCAT Python SDK 使用示例
"""

import time
import struct
from darra_ethercat import (
    EtherCATMaster, EcState, Slave,
    TRANS_IP, TRANS_PS, TIMING_AFTER,
)


def example_basic():
    """基本用法: 手动初始化流程"""

    # 创建主站 (上下文管理器自动关闭)
    with EtherCATMaster() as master:

        # 打印 DLL 版本
        ver = master.dll_version
        if ver:
            print(f"DLL 版本: {ver['major']}.{ver['minor']}.{ver['patch']}.{ver['build']}")

        # 设置网络适配器 (替换为实际的网卡名)
        adapter = "\\Device\\NPF_{YOUR-GUID-HERE}"
        slave_count = master.set_network(adapter)
        print(f"发现 {slave_count} 个从站")

        if slave_count == 0:
            print("未发现从站, 退出")
            return

        # 设置 PDO 循环周期 (1ms)
        master.set_cycle_time(1_000_000)

        # 自动状态转换到 OP (Init→PreOp→SafeOp→OP)
        if not master.set_state_sequence(EcState.OP, timeout_ms=10000):
            print("状态转换失败")
            return

        print("已进入 OP 状态")

        # 启动 PDO 循环
        master.start()

        # 访问从站 (1-based 索引)
        slave1 = master[1]

        # 读取从站身份
        ident = slave1.identity
        if ident:
            print(f"从站 1: VendorID=0x{ident['vendor_id']:08X}, "
                  f"ProductCode=0x{ident['product_code']:08X}")

        # CoE: 读取状态字 (StatusWord, 0x6041:00)
        status = slave1.coe.sdo_read_value(0x6041, 0, dtype='u16')
        if status is not None:
            print(f"StatusWord = 0x{status:04X}")

        # CoE: 写入控制字 (ControlWord, 0x6040:00)
        slave1.coe.sdo_write_value(0x6040, 0, 0x0006, dtype='u16')

        # 读取 IO 数据
        io = master.get_io(1)
        if io:
            out_data, in_data = io
            print(f"输出: {out_data.hex()}, 输入: {in_data.hex()}")

        # 运行 5 秒
        time.sleep(5)

        # 停止
        master.stop()
        print("已停止")


def example_one_step():
    """一步初始化: 通过 JSON 配置"""

    config = '''{
        "adapter": "\\\\Device\\\\NPF_{YOUR-GUID-HERE}",
        "redundant_adapter": "",
        "cycle_time_ns": 1000000,
        "target_state": "OP",
        "slaves": [
            {
                "index": 1,
                "startup_params": [
                    {
                        "index": "0x1C12", "subindex": 0,
                        "data": "00", "transition": "IP", "timing": "After"
                    }
                ]
            }
        ]
    }'''

    with EtherCATMaster.from_json(config) as master:
        print(f"一步初始化完成, 主站索引 = {master.master_index}")

        master.start()
        time.sleep(5)
        master.stop()


def example_callbacks():
    """事件回调示例"""

    with EtherCATMaster() as master:

        # 日志回调
        def on_log(category, message):
            labels = {0: "信息", 1: "警告", 2: "错误", 3: "调试"}
            print(f"[{labels.get(category, category)}] {message}")

        master.set_log_callback(on_log)

        # 状态变化回调
        def on_state_change(mi, si, old, new):
            old_s = EcState(old & 0x0F).format()
            new_s = EcState(new & 0x0F).format()
            print(f"从站 {si}: {old_s} → {new_s}")

        master.on_state_change(on_state_change)

        # 紧急消息回调
        def on_emergency(mi, si, err_code, err_reg, b1, w1, w2):
            print(f"紧急! 从站 {si}: 错误码=0x{err_code:04X}")

        master.on_emergency(on_emergency)

        # 输入数据变化回调
        def on_input_changed(mi, changed_slaves):
            print(f"输入变化: 从站 {changed_slaves}")

        master.on_input_changed(on_input_changed)

        # ... 连接和运行 ...


def example_protocols():
    """各协议使用示例"""

    with EtherCATMaster() as master:
        adapter = "\\Device\\NPF_{YOUR-GUID-HERE}"
        master.set_network(adapter)
        master.set_state_sequence(EcState.OP)
        master.start()

        slave = master[1]

        # ---- CoE (CANopen over EtherCAT) ----
        # 读取对象字典
        data = slave.coe.sdo_read(0x1018, 1)  # Vendor ID
        if data:
            vendor_id = struct.unpack('<I', data[:4])[0]
            print(f"Vendor ID: 0x{vendor_id:08X}")

        # 便捷数值读取
        value = slave.coe.sdo_read_value(0x6064, 0, dtype='i32')  # 实际位置
        print(f"实际位置: {value}")

        # ---- SoE (Servo over EtherCAT) ----
        # SERCOS 参数读取
        name = slave.soe.read_name(idn=1)
        if name:
            print(f"IDN 1 名称: {name}")

        data = slave.soe.read(idn=47)  # S-0-0047 Position feedback
        if data:
            print(f"位置反馈: {data.hex()}")

        # ---- FoE (File over EtherCAT) ----
        # 固件升级
        with open("firmware.bin", "rb") as f:
            fw_data = f.read()
        slave.foe.write("firmware.bin", fw_data, password=0)

        # 进度回调
        def on_progress(slave_idx, packet, size):
            print(f"FoE 进度: 包 {packet}, 大小 {size}")
        slave.foe.set_progress_callback(on_progress)

        # ---- EoE (Ethernet over EtherCAT) ----
        # 设置从站 IP
        import socket
        ip = struct.unpack('!I', socket.inet_aton("192.168.1.100"))[0]
        mask = struct.unpack('!I', socket.inet_aton("255.255.255.0"))[0]
        gw = struct.unpack('!I', socket.inet_aton("192.168.1.1"))[0]
        slave.eoe.set_ip(ip, mask, gw)

        # 读取 IP 配置
        result = slave.eoe.get_ip()
        if result:
            ip, mask, gw = result
            print(f"IP: {socket.inet_ntoa(struct.pack('!I', ip))}")

        # ---- AoE (ADS over EtherCAT) ----
        info = slave.aoe.read_device_info()
        if info:
            print(f"ADS 设备: {info['name']} v{info['major']}.{info['minor']}")

        # ---- VoE (Vendor specific) ----
        if slave.voe.is_supported:
            slave.voe.send(vendor_id=0x00000002, vendor_type=1, data=b'\x01\x02\x03')

        master.stop()


def example_dc():
    """DC 同步配置示例"""

    with EtherCATMaster() as master:
        adapter = "\\Device\\NPF_{YOUR-GUID-HERE}"
        master.set_network(adapter)

        # 配置 DC: SYNC0 = 1ms
        dc_count = master.configure_dc(sync0_ns=1_000_000)
        print(f"已配置 {dc_count} 个 DC 从站")

        # 单独配置某个从站的 DC
        master[2].set_sync(sync0_ns=1_000_000, sync1_ns=0, shift_ns=100_000)

        # 启用持续传播延迟补偿
        master.enable_continuous_measurement(enable=True, interval_sec=10)

        # 设置同步窗口阈值
        master.set_sync_window_threshold(1000)  # 1000ns

        master.set_state_sequence(EcState.OP)
        master.start()

        # 检查同步状态
        time.sleep(2)
        print(f"全部同步: {master.all_slaves_in_sync}")
        print(f"最大时差: {master.max_sync_difference} ns")

        # 检查单个从站同步窗口
        status = master[2].sync_window_status
        if status:
            print(f"从站 2 同步差: {status['diff_ns']} ns, 同步: {status['in_sync']}")

        master.stop()


def example_startup_params():
    """启动参数配置示例"""

    with EtherCATMaster() as master:
        adapter = "\\Device\\NPF_{YOUR-GUID-HERE}"
        master.set_network(adapter)

        slave = master[1]

        # 添加启动参数: IP 转换后写入 PDO Mapping
        # 清除 RxPDO Assignment
        slave.add_startup_param(
            index=0x1C12, subindex=0,
            data=b'\x00',
            transition=TRANS_IP, timing=TIMING_AFTER,
        )
        # 添加 RxPDO
        slave.add_startup_param(
            index=0x1C12, subindex=1,
            data=struct.pack('<H', 0x1600),
            transition=TRANS_IP, timing=TIMING_AFTER,
        )
        # 设置 Assignment 数量
        slave.add_startup_param(
            index=0x1C12, subindex=0,
            data=b'\x01',
            transition=TRANS_IP, timing=TIMING_AFTER,
        )

        print(f"启动参数数量: {slave.startup_param_count}")

        # 使用自动状态转换 (自动执行启动参数)
        master.set_state_sequence(EcState.OP)
        master.start()
        time.sleep(5)
        master.stop()


def example_redundancy():
    """冗余模式示例"""

    with EtherCATMaster() as master:
        # 设置冗余模式 (需要两张网卡)
        master.set_redundancy_mode(2)  # Mode 2

        primary = "\\Device\\NPF_{PRIMARY-GUID}"
        secondary = "\\Device\\NPF_{SECONDARY-GUID}"
        master.set_network(primary, secondary)

        # 注册冗余模式变化回调
        def on_red_change(mi, old, new):
            modes = {0: "Inactive", 1: "Dual", 2: "Degraded"}
            print(f"冗余模式: {modes.get(old)} → {modes.get(new)}")

        master.on_redundancy_mode_changed(on_red_change)

        master.set_state_sequence(EcState.OP)
        master.start()

        # 检查冗余状态
        print(f"链路状态: {master.link_status.name}")
        print(f"冗余模式: {master.ring_mode.name}")
        print(f"冗余链路正常: {master.secondary_link_ok}")

        # 检查故障点
        breaks = master.get_break_points()
        for bp in breaks:
            bp_type = "断线" if bp['type'] == 0 else "CRC劣化"
            print(f"故障: 从站 {bp['slave']} 端口 {bp['port']} ({bp_type})")

        time.sleep(10)
        master.stop()


if __name__ == "__main__":
    print("=== DarraEtherCAT Python SDK 示例 ===\n")
    print("请取消注释要运行的示例:\n")
    print("  example_basic()          # 基本用法")
    print("  example_one_step()       # 一步初始化")
    print("  example_callbacks()      # 事件回调")
    print("  example_protocols()      # 协议使用")
    print("  example_dc()             # DC 同步")
    print("  example_startup_params() # 启动参数")
    print("  example_redundancy()     # 冗余模式")

    # 取消注释要运行的示例:
    # example_basic()
