# Darra EtherCAT — Python SDK

Python 3.8+ 平台的 Darra EtherCAT Master 封装. 基于 `ctypes` 绑定 `Darra.Core.dll` (Windows) / `libDarraCore.so` (Linux), Pythonic 风格 + type hints.

## 安装

### PyPI

```bash
pip install darra-ethercat
```

### 本地 wheel

```bash
python build_wheel.py        # 生成 dist/darra_ethercat-0.x-cp3x-*.whl
pip install dist/darra_ethercat-*.whl
```

原生库随包发布, 自动加载.

### 类型检查

本包带 `py.typed` (PEP 561), mypy/pyright 可直接识别.

```bash
pip install darra-ethercat[dev]   # 可选: mypy + pytest
```

## 快速 Hello World

```python
from darra_ethercat import EtherCATMaster, EcState

# 1. 扫描网卡
adapters = EtherCATMaster.get_network_info(need_slaves_num=True)
for nic in adapters:
    print(f"{nic.description}  slaves={nic.slave_count}")

target = next((n for n in adapters if n.slave_count > 0), None)
if target is None:
    print("未找到带从站的网卡")
    exit(1)

# 2. 构建主站 (context manager 自动 close)
with EtherCATMaster() as master:
    master.set_network(target.name)
    master.enable_auto_startup()
    master.build()

    # 3. 扫描从站
    print(f"主站 #{master.master_number} 发现从站 {master.slave_count} 台")
    for s in master.slaves:
        print(f"  [{s.slave_index}] {s.name}  State={s.state}")

    # 4. 进入 OP
    if not master.set_state(EcState.OP, timeout_ms=10_000):
        raise RuntimeError("进入 OP 失败")

    # 5. 读取 Statusword
    if master.slave_count > 0:
        data = master.slaves[0].coe.sdo_read(0x6041, 0x00)
        if data is not None:
            statusword = int.from_bytes(data[:2], "little")
            print(f"Statusword=0x{statusword:04X}")

    # 6. 退出 (with 自动触发 SetState(Init) + close)
    master.set_state(EcState.INIT, timeout_ms=5_000)
```

## API 要点

- **入口**: `EtherCATMaster()` / `EtherCATMaster.from_json(json_str)` / `EtherCATMaster.from_json_file(path)`
- **配置**: `master.set_network(primary)` / `master.set_eni(path)` / `master.enable_auto_startup()` / `master.build()`
- **从站**: `master.slaves` (List[Slave]) 或 `master.slaves[i]`
- **协议实例**: `slave.coe` / `.foe` / `.soe` / `.eoe` / `.aoe` / `.voe` / `.fsoe` / `.dc` / `.pdo`
- **诊断**: `master.diagnostics` (property)
- **状态机**: `master.set_state(EcState.OP, timeout_ms=10_000)` 返回 `bool`
- **版本**: `darra_ethercat.__version__`

## 异步模型

Python SDK 主干方法同步. 异步封装在模块级 `*_async` 函数 (基于 `asyncio`):

```python
import asyncio
from darra_ethercat.slave.coe import sdo_read_async, sdo_write_async

async def main(slave):
    data = await sdo_read_async(slave.coe, 0x6041, 0x00, timeout_ms=5000)
    await sdo_write_async(slave.coe, 0x6040, 0x00, b"\x0F\x00", timeout_ms=5000)

    # 批量
    results = await asyncio.gather(*[
        sdo_read_async(slave.coe, idx, 0x00) for idx in (0x6041, 0x6064, 0x606C)
    ])

asyncio.run(main(master.slaves[0]))
```

对于原生同步方法, 可用 `asyncio.to_thread(...)` 包装:

```python
ok = await asyncio.to_thread(master.set_state, EcState.OP, 10_000)
```

## 与 C# 对齐

| C# | Python |
|---|---|
| `DarraEtherCAT` | `EtherCATMaster` |
| `SDORead(0x6041, 0x00)` | `sdo_read(0x6041, 0x00)` |
| `SetState(EcState.OP)` | `set_state(EcState.OP, timeout_ms=10_000)` |
| `slave.CoE.LastSdoError` | `slave.coe.last_sdo_error` |
| `Dispose()` / `using` | `close()` / `with ...:` |

命名风格: Pythonic `snake_case` (类名保留 `PascalCase`).

## 日志

```python
from darra_ethercat.logging import init, enable_debug, enable_mailbox

init()
enable_debug(True)
enable_mailbox(True)
```

## 协议支持

以 C# SDK 为对齐基准, 通过 ctypes 直调 Darra Core DLL. 详细对比见 [`../SDK_ALIGNMENT.md`](../SDK_ALIGNMENT.md).

| 协议 / 能力 | 状态 | 说明 |
|------|------|------|
| CoE | ✓ 完整 | SDO 同步, `sdo_read_async` (asyncio), PDO 映射, OD, CiA402 |
| EoE | ✓ 完整 | IP/MAC 配置, 帧透传 |
| FoE | ✓ 完整 | 上下载, Cancel, 进度回调 |
| SoE | ✓ 完整 | IDN 读写 |
| AoE | ✓ 完整 | ADS 透传 |
| VoE | ✓ 完整 | 厂商邮箱透传 |
| FSoE | ✓ 完整 | SIL3, 多连接 |
| DC | ✓ 完整 | sync0/sync1, drift 补偿 |
| Cable Redundancy | ✓ 完整 | 双网口 failover |
| Hot-Connect | ✓ 完整 | 热插拔 |
| Mailbox Gateway | ✓ 完整 | ETG.8200 TCP 网关 |
| ESI 解析 | ✓ 完整 | XML 自动加载 |
| ENI 配置 | ✓ 完整 | ETG.1510 ENI init |
| ETG.1510 Diagnostics | ✓ 完整 | 0x10F3 历史 + 聚合状态 + Emergency Recorder asyncio Stream (`async for entry in master.emergency_stream():`) |

**对齐度: 100% vs C#** (Phase 4 后, asyncio Stream wrapper 在 managed 层实装).

## 字节级一致性保证

Python SDK 通过 ctypes 转发到 `Darra.Core.dll`, 与 C# 基准做字节级对齐:

- **CRC16 (FSoE)**: `darra_ethercat.fsoe.crc16(data: bytes)` 直调 C ABI, byte-by-byte 与 C# 输出一致
- **IDN 编码 (SoE)**: `darra_ethercat.soe.encode_idn(set, type, block)` 返回 `int` 与 C# 同值, `int.to_bytes(2, "little")` 与线缆字节序一致
- **枚举值**: `EcState.OP.value == 0x08`, 与 C/C#/Java/Rust 同值; `IntEnum` 子类保证序列化字节稳定
- **结构体**: `ctypes.Structure` 用 `_pack_ = 1` 与 C `#pragma pack(1)` 字段偏移一致
- **bytes 语义**: SDO 数据 `bytes` 按 EtherCAT 帧字节序透传, 不做隐式字节交换

字节级一致性由 `Darra_EtherCAT_SDKTest_Python` 测试套件 + `pytest` 与 C# 基准每次 CI 比对.

## 已知限制

下列能力在 `Darra.Core.dll` 中未导出 native symbol, Python SDK 在 managed (Python) 层提供 fallback, 用户 API 不变:

- **ENI 回写** (`master.export_eni(path)`): DLL 无 export, fallback 用 Python `xml.etree.ElementTree` 重建 ENI XML
- **Emergency Recorder 历史深度**: DLL 默认 256 项, fallback 用 `collections.deque(maxlen=...)` 容量可配
- **Diagnostics 变化推送**: DLL 仅支持轮询, fallback 用 `asyncio.create_task()` 周期对比, 通过 `AsyncIterator[DiagnosticsChange]` 推送
- **MailboxGateway 会话上限**: DLL 默认 16 路, fallback 用 `asyncio.Semaphore` 限流

> Python fallback 100% 纯 Python 实现, 字节输出与 native 一致. asyncio 轮询周期默认 100 ms, 可通过 `master.set_poll_interval(ms)` 调整.

## 如何升级到完整功能

DLL 端补以下 export 后, ctypes 绑定切换为 native 路径, managed fallback 自动停用:

| 待补 export | Python SDK 受益 |
|-------------|------------------|
| `Master_ExportENI` | `master.export_eni()` 走 native, 移除 ElementTree 解析开销 |
| `EmergencyRecorder_SetMaxHistory` | 历史下沉 DLL, 减少 Python heap 占用 |
| `Diagnostics_RegisterChangeCallback` | ctypes `CFUNCTYPE` 回调推送, 延迟从 100 ms 降至 < 1 ms (注意 GIL) |
| `MailboxGateway_SetSessionLimit` | DLL 限流, 移除 asyncio.Semaphore |

切换无需修改用户代码: SDK 在 import 时探测 `lib.Master_ExportENI` 是否存在, 自动选路径.

## 相关文档

- [SDK 对齐对比](../SDK_ALIGNMENT.md)
- [统一 API 参考](../docs/api-reference.md)
- [7 邮箱协议](../docs/mailbox-protocols.md)
- [快速入门](../docs/quick-start.md)

## License

Proprietary — Darra Technology.
