# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/MDP.cs
MDP (Modular Device Profile) 模块发现 (ETG.5001)

包含:
- MdpModule: MDP 模块信息
- MdpSlotInfo: 模块槽位信息
- MdpModulePdoInfo: 模块 PDO 布局信息
- MdpDiscovery: MDP 模块发现工具

轻量方法 (configured_modules / detected_modules / check_module_match) 直接转调
native MDPGetConfigModuleList / MDPGetDetectedModuleList / MDPCheckModuleMatch,
不再走 SDORead 0xF030 / 0xF050.
"""

import ctypes
from ctypes import c_int, c_uint, c_uint16, c_ushort, byref
from typing import List, Optional, Tuple

from .core import CoE


class MdpModule:
    """MDP 模块信息"""

    def __init__(self, slot: int, profile_id: int, vendor_id: int,
                 module_type: int, revision: int):
        self.slot = slot
        self.profile_id = profile_id
        self.vendor_id = vendor_id
        self.module_type = module_type
        self.revision = revision

    def __repr__(self) -> str:
        return (f"MdpModule(slot={self.slot}, profile=0x{self.profile_id:04X}, "
                f"vendor=0x{self.vendor_id:08X}, type=0x{self.module_type:04X})")


class MdpSlotInfo:
    """MDP 模块槽位信息 (ETG.5001)"""

    def __init__(self):
        self.slot_index: int = 0
        self.module_ident: int = 0
        self.module_name: str = ""
        self.module_type: int = 0
        self.status: str = ""
        self.object_dictionary_index: int = 0
        self.module_io_type: str = "Unknown"

    def __repr__(self) -> str:
        return f"Slot {self.slot_index}: {self.module_name} (0x{self.module_ident:08X})"


class MdpModulePdoInfo:
    """MDP 模块 PDO 布局信息"""

    def __init__(self):
        self.slot_index: int = 0
        self.input_offset: int = 0
        self.input_size: int = 0
        self.output_offset: int = 0
        self.output_size: int = 0


class MdpDiscovery:
    """
    MDP 模块发现工具

    通过读取 0xF050 (MDP 模块列表对象) 发现从站上的模块配置。
    """

    _OD_MODULAR_DEVICE_PROFILE = 0xF000
    _OD_CONFIGURED_MODULE_LIST = 0xF030
    _OD_DETECTED_MODULE_LIST = 0xF050
    _MDP_MODULE_LIST_IDX = 0xF050

    def __init__(self, coe: CoE):
        self._coe = coe
        self._modules: List[MdpModule] = []
        self._configured_slots: List[MdpSlotInfo] = []
        self._detected_slots: List[MdpSlotInfo] = []
        self._module_index_distance: Optional[int] = None
        self._max_module_count: Optional[int] = None

    @property
    def module_index_distance(self) -> int:
        """模块索引间距 (0xF000:01)"""
        if self._module_index_distance is None:
            self._module_index_distance = self._read_module_index_distance()
        return self._module_index_distance

    @property
    def max_module_count(self) -> int:
        """最大模块数量 (0xF000:02)"""
        if self._max_module_count is None:
            self._max_module_count = self._read_max_module_count()
        return self._max_module_count

    @property
    def configured_modules(self) -> List[MdpSlotInfo]:
        """已配置模块列表 (0xF030, 转调 native MDPGetConfigModuleList)"""
        return self._build_slot_list_from_native(self.config_module_idents, "已配置")

    @property
    def detected_modules(self) -> List[MdpSlotInfo]:
        """已检测模块列表 (0xF050, 转调 native MDPGetDetectedModuleList)"""
        return self._build_slot_list_from_native(self.detected_module_idents, "已检测")

    @property
    def config_module_idents(self) -> List[int]:
        """从 native 直读 0xF030 ConfigModuleIdent 数组."""
        return self._native_get_module_list("MDPGetConfigModuleList")

    @property
    def detected_module_idents(self) -> List[int]:
        """从 native 直读 0xF050 DetectedModuleIdent 数组."""
        return self._native_get_module_list("MDPGetDetectedModuleList")

    def check_module_match(self) -> Tuple[bool, int]:
        """转调 native MDPCheckModuleMatch. 返回 (is_match, first_mismatch_slot)."""
        try:
            fn = getattr(self._coe._dll, "MDPCheckModuleMatch")
            fn.restype = c_int
            fn.argtypes = [c_ushort, c_ushort, ctypes.POINTER(c_int)]
            first = c_int(-1)
            rc = fn(c_ushort(self._coe._mi), c_ushort(self._coe._si), byref(first))
            return (rc == 1, first.value)
        except Exception:
            return (False, -1)

    def _native_get_module_list(self, fn_name: str) -> List[int]:
        """通用: 调用 native MDPGet{Config,Detected}ModuleList 直读 ident 数组."""
        try:
            fn = getattr(self._coe._dll, fn_name)
            fn.restype = c_int
            fn.argtypes = [c_ushort, c_ushort, ctypes.POINTER(c_uint), c_int]
            buf_len = 32
            buf = (c_uint * buf_len)()
            n = fn(c_ushort(self._coe._mi), c_ushort(self._coe._si), buf, c_int(buf_len))
            if n <= 0:
                return []
            return [int(buf[i]) for i in range(n)]
        except Exception:
            return []

    def _build_slot_list_from_native(self, idents: List[int], status_label: str) -> List[MdpSlotInfo]:
        """从 native 返回的 ident 数组组装 MdpSlotInfo."""
        slots: List[MdpSlotInfo] = []
        if not idents:
            return slots
        dist = self.module_index_distance
        for i, ident in enumerate(idents):
            if ident == 0:
                continue
            slot_index = i + 1
            slot = MdpSlotInfo()
            slot.slot_index = slot_index
            slot.module_ident = ident
            slot.module_type = ident & 0xFFFF
            slot.status = status_label
            slot.object_dictionary_index = dist * slot_index
            slot.module_name = f"Module 0x{ident:08X}"
            slots.append(slot)
        return slots

    def discover(self) -> List[MdpModule]:
        """执行 MDP 模块发现"""
        self._modules.clear()
        num_modules = self._coe.sdo_read_value(self._MDP_MODULE_LIST_IDX, 0, 'u8')
        if not num_modules:
            return []

        for slot in range(1, num_modules + 1):
            raw = self._coe.sdo_read_value(self._MDP_MODULE_LIST_IDX, slot, 'u32')
            if raw is None:
                continue
            profile_id = (raw >> 16) & 0xFFFF
            module_type = raw & 0xFFFF
            vendor_id = self._coe.sdo_read_value(0xF051, slot, 'u32') or 0
            revision = self._coe.sdo_read_value(0xF052, slot, 'u32') or 0
            self._modules.append(MdpModule(slot, profile_id, vendor_id, module_type, revision))

        return list(self._modules)

    def rescan(self) -> List[MdpSlotInfo]:
        """重新扫描模块列表"""
        self._module_index_distance = None
        self._max_module_count = None
        self._configured_slots = self._read_module_list(self._OD_CONFIGURED_MODULE_LIST, "已配置")
        self._detected_slots = self._read_module_list(self._OD_DETECTED_MODULE_LIST, "已检测")
        return list(self._detected_slots)

    @property
    def modules(self) -> List[MdpModule]:
        return list(self._modules)

    def _read_module_list(self, od_index: int, status_label: str) -> List[MdpSlotInfo]:
        results = []
        try:
            num = self._coe.sdo_read_value(od_index, 0, 'u8')
            if not num:
                return results
            dist = self.module_index_distance
            for i in range(1, num + 1):
                raw = self._coe.sdo_read_value(od_index, i, 'u32')
                if raw is None:
                    continue
                slot = MdpSlotInfo()
                slot.slot_index = i
                slot.module_ident = raw
                slot.module_type = raw & 0xFFFF
                slot.status = status_label
                slot.object_dictionary_index = dist * i
                slot.module_name = f"Module 0x{raw:08X}"
                results.append(slot)
        except Exception:
            pass
        return results

    def _read_module_index_distance(self) -> int:
        try:
            val = self._coe.sdo_read_value(self._OD_MODULAR_DEVICE_PROFILE, 1, 'u16')
            if val is not None and val > 0:
                return val
        except Exception:
            pass
        return 0x0800

    def _read_max_module_count(self) -> int:
        try:
            val = self._coe.sdo_read_value(self._OD_MODULAR_DEVICE_PROFILE, 2, 'u16')
            if val is not None:
                return val
        except Exception:
            pass
        return 0

    def get_module_pdo_layout(self) -> Optional[List[MdpModulePdoInfo]]:
        """
        获取各模块在从站 IOmap 中的 PDO 布局。
        通过 CoE SDORead 读取 PDO Assignment (0x1C12/0x1C13) 和 PDO Mapping 条目，
        累积计算各模块在 IOmap 中的字节偏移。

        返回:
            PDO 布局列表, 失败返回 None
        """
        detected = self._read_module_list(self._OD_DETECTED_MODULE_LIST, "已检测")
        if not detected:
            return None

        input_pdo_sizes = self._read_pdo_assignment_sizes(0x1C13)   # TxPDO → 主站输入
        output_pdo_sizes = self._read_pdo_assignment_sizes(0x1C12)  # RxPDO → 主站输出

        if not input_pdo_sizes and not output_pdo_sizes:
            return None

        result = []
        input_cursor = 0
        output_cursor = 0

        input_pdos_per_module = max(1, len(input_pdo_sizes) // len(detected)) if input_pdo_sizes else 0
        output_pdos_per_module = max(1, len(output_pdo_sizes) // len(detected)) if output_pdo_sizes else 0

        for i, slot in enumerate(detected):
            input_bytes = 0
            output_bytes = 0

            if input_pdos_per_module > 0:
                start = i * input_pdos_per_module
                for j in range(start, min(start + input_pdos_per_module, len(input_pdo_sizes))):
                    input_bytes += input_pdo_sizes[j]

            if output_pdos_per_module > 0:
                start = i * output_pdos_per_module
                for j in range(start, min(start + output_pdos_per_module, len(output_pdo_sizes))):
                    output_bytes += output_pdo_sizes[j]

            info = MdpModulePdoInfo()
            info.slot_index = slot.slot_index
            info.input_offset = input_cursor
            info.input_size = input_bytes
            info.output_offset = output_cursor
            info.output_size = output_bytes
            result.append(info)

            input_cursor += input_bytes
            output_cursor += output_bytes

        return result

    def auto_configure_from_detected_modules(self) -> int:
        """
        根据检测到的模块自动配置 - 将检测到的模块列表写入已配置列表 (0xF030)。

        读取 0xF050 (已检测模块), 然后逐个写入 0xF030 (已配置模块),
        使已配置模块与已检测模块保持一致。

        返回:
            成功配置的模块数量, -1 表示失败
        """
        import struct

        detected = self._read_module_list(self._OD_DETECTED_MODULE_LIST, "已检测")
        if not detected:
            return 0

        count = len(detected)

        # 写入子索引0 (模块数量)
        count_data = struct.pack('<B', count)
        try:
            self._coe.sdo_write(self._OD_CONFIGURED_MODULE_LIST, 0x00, count_data)
        except Exception:
            return -1

        # 逐个写入模块标识
        configured = 0
        for i, slot in enumerate(detected):
            ident_data = struct.pack('<I', slot.module_ident)
            try:
                self._coe.sdo_write(self._OD_CONFIGURED_MODULE_LIST, i + 1, ident_data)
                configured += 1
            except Exception:
                pass

        return configured

    def _read_pdo_assignment_sizes(self, assignment_index: int) -> List[int]:
        """读取 PDO Assignment 中各 PDO 的字节大小列表"""
        import struct
        sizes = []
        try:
            count_data = self._coe.sdo_read(assignment_index, 0)
            if not count_data or len(count_data) == 0:
                return sizes
            count = count_data[0]

            for i in range(1, count + 1):
                pdo_data = self._coe.sdo_read(assignment_index, i)
                if not pdo_data or len(pdo_data) < 2:
                    continue
                pdo_mapping_index = struct.unpack_from('<H', pdo_data, 0)[0]
                if pdo_mapping_index == 0:
                    continue
                pdo_bytes = self._read_pdo_mapping_size(pdo_mapping_index)
                sizes.append(pdo_bytes)
        except Exception:
            pass
        return sizes

    def _read_pdo_mapping_size(self, pdo_mapping_index: int) -> int:
        """读取单个 PDO Mapping 对象的总字节数"""
        total_bits = 0
        try:
            count_data = self._coe.sdo_read(pdo_mapping_index, 0)
            if not count_data or len(count_data) == 0:
                return 0
            entry_count = count_data[0]

            for i in range(1, entry_count + 1):
                entry_data = self._coe.sdo_read(pdo_mapping_index, i)
                if not entry_data or len(entry_data) < 4:
                    continue
                # Byte[0] = BitLength (小端序 32位 PDO Mapping Entry 的低8位)
                total_bits += entry_data[0]
        except Exception:
            pass
        return (total_bits + 7) // 8

    def __repr__(self) -> str:
        return f"MdpDiscovery(modules={len(self._modules)})"
