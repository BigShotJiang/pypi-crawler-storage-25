# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/PDO.cs
PDO (Process Data Object) 高性能访问与变化检测

包含:
- PDOArrayInstance: 按字节索引访问 PDO 数据
- PDODataItem: 单个 PDO 数据项的类型化访问
- PDOWatcher: 单个从站的 PDO 监视记录
- PDOMonitor: PDO 变化检测器
- Slave 扩展: 零拷贝指针与直接读写
"""

import ctypes
import struct
import threading
import time
from ctypes import c_uint, c_int, c_void_p, byref, POINTER, c_ubyte
from typing import Callable, List, Optional

from ..utils.dll import DarraCoreDLL


# ===================== PDODataItem =====================

class PDODataItem:
    """
    单个 PDO 数据项 - 类型化访问

    对应 C# PDODataItem: Content, AsInt16, AsInt32, AsUInt16, AsUInt32,
    AsFloat, AsDouble, GetBit, SetBit
    """

    def __init__(self, base_ptr: int, offset: int, is_input: bool):
        """
        初始化 PDO 数据项

        参数:
            base_ptr:  基础指针地址 (整数)
            offset:    在基础指针中的字节偏移
            is_input:  是否为输入 PDO (只读)
        """
        self._base_ptr = base_ptr
        self._offset = offset
        self._is_input = is_input

    def _validate(self, required_bytes: int = 1) -> int:
        """校验指针有效性, 返回实际地址"""
        if self._base_ptr == 0 or self._base_ptr is None:
            raise ValueError("基础指针为空")
        return self._base_ptr + self._offset

    def _check_writable(self):
        """检查是否可写"""
        if self._is_input:
            raise PermissionError("不能写入输入 PDO")

    # ---- 字节访问 ----

    @property
    def content(self) -> int:
        """获取字节值 (0-255)"""
        addr = self._validate(1)
        return ctypes.cast(addr, POINTER(c_ubyte))[0]

    @content.setter
    def content(self, value: int):
        """设置字节值"""
        self._check_writable()
        addr = self._validate(1)
        ctypes.cast(addr, POINTER(c_ubyte))[0] = value & 0xFF

    # ---- Int16 访问 ----

    @property
    def as_int16(self) -> int:
        """获取 Int16 值 (小端)"""
        addr = self._validate(2)
        return ctypes.cast(addr, POINTER(ctypes.c_int16))[0]

    @as_int16.setter
    def as_int16(self, value: int):
        """设置 Int16 值"""
        self._check_writable()
        addr = self._validate(2)
        ctypes.cast(addr, POINTER(ctypes.c_int16))[0] = value

    # ---- UInt16 访问 ----

    @property
    def as_uint16(self) -> int:
        """获取 UInt16 值 (小端)"""
        addr = self._validate(2)
        return ctypes.cast(addr, POINTER(ctypes.c_uint16))[0]

    @as_uint16.setter
    def as_uint16(self, value: int):
        """设置 UInt16 值"""
        self._check_writable()
        addr = self._validate(2)
        ctypes.cast(addr, POINTER(ctypes.c_uint16))[0] = value

    # ---- Int32 访问 ----

    @property
    def as_int32(self) -> int:
        """获取 Int32 值 (小端)"""
        addr = self._validate(4)
        return ctypes.cast(addr, POINTER(ctypes.c_int32))[0]

    @as_int32.setter
    def as_int32(self, value: int):
        """设置 Int32 值"""
        self._check_writable()
        addr = self._validate(4)
        ctypes.cast(addr, POINTER(ctypes.c_int32))[0] = value

    # ---- UInt32 访问 ----

    @property
    def as_uint32(self) -> int:
        """获取 UInt32 值 (小端)"""
        addr = self._validate(4)
        return ctypes.cast(addr, POINTER(ctypes.c_uint32))[0]

    @as_uint32.setter
    def as_uint32(self, value: int):
        """设置 UInt32 值"""
        self._check_writable()
        addr = self._validate(4)
        ctypes.cast(addr, POINTER(ctypes.c_uint32))[0] = value

    # ---- Float 访问 ----

    @property
    def as_float(self) -> float:
        """获取 Float 值 (小端)"""
        addr = self._validate(4)
        return ctypes.cast(addr, POINTER(ctypes.c_float))[0]

    @as_float.setter
    def as_float(self, value: float):
        """设置 Float 值"""
        self._check_writable()
        addr = self._validate(4)
        ctypes.cast(addr, POINTER(ctypes.c_float))[0] = value

    # ---- Double 访问 ----

    @property
    def as_double(self) -> float:
        """获取 Double 值 (小端)"""
        addr = self._validate(8)
        return ctypes.cast(addr, POINTER(ctypes.c_double))[0]

    @as_double.setter
    def as_double(self, value: float):
        """设置 Double 值"""
        self._check_writable()
        addr = self._validate(8)
        ctypes.cast(addr, POINTER(ctypes.c_double))[0] = value

    # ---- 位操作 ----

    def get_bit(self, bit_index: int) -> bool:
        """
        获取指定索引处的位值

        参数:
            bit_index: 位索引 (0-7)
        返回:
            位的布尔值
        """
        if bit_index < 0 or bit_index > 7:
            raise ValueError("位索引必须在 0-7 之间")
        return (self.content & (1 << bit_index)) != 0

    def set_bit(self, bit_index: int, value: bool):
        """
        设置指定索引处的位值

        参数:
            bit_index: 位索引 (0-7)
            value:     要设置的布尔值
        """
        self._check_writable()
        if bit_index < 0 or bit_index > 7:
            raise ValueError("位索引必须在 0-7 之间")
        current = self.content
        if value:
            current |= (1 << bit_index)
        else:
            current &= ~(1 << bit_index)
        self.content = current

    def as_base_data(self, data_type: int) -> "BaseDataWrapper":
        """
        创建具有指定数据类型的 BaseData 包装器以进行类型安全访问

        参数:
            data_type: EtherCAT 数据类型编号
        返回:
            BaseDataWrapper 实例
        """
        type_sizes = {
            0x01: 1, 0x02: 1, 0x03: 1, 0x04: 2, 0x05: 2,
            0x06: 3, 0x07: 3, 0x08: 4, 0x09: 4,
            0x0A: 8, 0x0B: 8, 0x11: 4, 0x12: 8,
        }
        size = type_sizes.get(data_type, 1)
        addr = self._validate(size)
        raw = (ctypes.c_ubyte * size)()
        ctypes.memmove(raw, addr, size)
        return BaseDataWrapper(data_type, bytes(raw))

    def __repr__(self) -> str:
        return f"PDODataItem(offset={self._offset}, input={self._is_input})"


class BaseDataWrapper:
    """
    类型化数据包装器
    对应 C# BaseData: 提供 as_int16/as_float 等类型化访问
    """

    def __init__(self, data_type: int, raw: bytes):
        self._data_type = data_type
        self._raw = bytearray(raw)

    @property
    def raw(self) -> bytes:
        """获取原始字节数据"""
        return bytes(self._raw)

    @property
    def as_int16(self) -> int:
        """获取 Int16 值"""
        if len(self._raw) >= 2:
            return struct.unpack('<h', self._raw[:2])[0]
        return 0

    @property
    def as_uint16(self) -> int:
        """获取 UInt16 值"""
        if len(self._raw) >= 2:
            return struct.unpack('<H', self._raw[:2])[0]
        return 0

    @property
    def as_int32(self) -> int:
        """获取 Int32 值"""
        if len(self._raw) >= 4:
            return struct.unpack('<i', self._raw[:4])[0]
        return 0

    @property
    def as_uint32(self) -> int:
        """获取 UInt32 值"""
        if len(self._raw) >= 4:
            return struct.unpack('<I', self._raw[:4])[0]
        return 0

    @property
    def as_float(self) -> float:
        """获取 Float 值"""
        if len(self._raw) >= 4:
            return struct.unpack('<f', self._raw[:4])[0]
        return 0.0

    @property
    def as_double(self) -> float:
        """获取 Double 值"""
        if len(self._raw) >= 8:
            return struct.unpack('<d', self._raw[:8])[0]
        return 0.0

    def __repr__(self) -> str:
        hex_str = ' '.join(f'{b:02X}' for b in self._raw)
        return f"BaseDataWrapper(type={self._data_type}, data=[{hex_str}])"


# ===================== PDOArrayInstance =====================

class PDOArrayInstance:
    """
    基于数组的 PDO 数据访问

    对应 C# PDOArrayInstance
    通过索引器按字节访问 PDO 数据区。

    用法:
        item = array_instance[0]         # 获取 PDODataItem
        value = array_instance[0].content # 读取字节值
        array_instance[0].content = 0x55  # 写入字节值 (仅输出)
    """

    def __init__(self, data_ptr: int, length: int, is_input: bool):
        """
        初始化 PDO 数组实例

        参数:
            data_ptr:  数据指针地址 (整数)
            length:    数据长度 (字节)
            is_input:  是否为输入 PDO (只读)
        """
        self._data_ptr = data_ptr
        self._length = length
        self._is_input = is_input

    def __getitem__(self, index: int) -> PDODataItem:
        """按字节索引获取 PDODataItem"""
        if index < 0 or index >= self._length:
            raise IndexError(f"索引 {index} 超出范围 [0, {self._length})")
        return PDODataItem(self._data_ptr, index, self._is_input)

    def __setitem__(self, index: int, value: int):
        """按字节索引写入单字节"""
        if index < 0 or index >= self._length:
            raise IndexError(f"索引 {index} 超出范围 [0, {self._length})")
        if self._is_input:
            raise PermissionError("不能写入输入 PDO")
        item = PDODataItem(self._data_ptr, index, self._is_input)
        item.content = value

    @property
    def length(self) -> int:
        """获取 PDO 数据的总长度（字节）"""
        return self._length

    def __len__(self) -> int:
        return self._length

    def __repr__(self) -> str:
        kind = "输入" if self._is_input else "输出"
        return f"PDOArrayInstance({kind}, length={self._length})"


# ===================== 从站 PDO 扩展方法 =====================

def get_input_data_pointer(dll: DarraCoreDLL, master_index: int, slave_index: int) -> int:
    """
    获取输入数据的直接指针（零拷贝访问）

    警告: 仅在 PDO 循环中使用, 指针在 IOmap 重新映射后会失效

    参数:
        dll:          DLL 接口
        master_index: 主站索引
        slave_index:  从站索引
    返回:
        指向输入数据的指针地址, 失败返回 0
    """
    out_size = c_int(0)
    out_ptr = c_void_p(0)
    in_size = c_int(0)
    in_ptr = c_void_p(0)
    try:
        ok = dll.GetIO(master_index, slave_index,
                       byref(out_size), byref(out_ptr),
                       byref(in_size), byref(in_ptr))
        if ok == 1 and in_ptr.value and in_ptr.value != 0:
            return in_ptr.value
    except Exception:
        pass
    return 0


def get_output_data_pointer(dll: DarraCoreDLL, master_index: int, slave_index: int) -> int:
    """
    获取输出数据的直接指针（零拷贝访问）

    警告: 仅在 PDO 循环中使用, 指针在 IOmap 重新映射后会失效

    参数:
        dll:          DLL 接口
        master_index: 主站索引
        slave_index:  从站索引
    返回:
        指向输出数据的指针地址, 失败返回 0
    """
    out_size = c_int(0)
    out_ptr = c_void_p(0)
    in_size = c_int(0)
    in_ptr = c_void_p(0)
    try:
        ok = dll.GetIO(master_index, slave_index,
                       byref(out_size), byref(out_ptr),
                       byref(in_size), byref(in_ptr))
        if ok == 1 and out_ptr.value and out_ptr.value != 0:
            return out_ptr.value
    except Exception:
        pass
    return 0


def read_input_data_direct(dll: DarraCoreDLL, master_index: int, slave_index: int,
                           buffer: bytearray, offset: int = 0, length: int = 0) -> int:
    """
    读取输入数据（零拷贝，直接从 IOmap）

    参数:
        dll:          DLL 接口
        master_index: 主站索引
        slave_index:  从站索引
        buffer:       目标缓冲区
        offset:       目标缓冲区偏移
        length:       要读取的字节数, 0 表示全部
    返回:
        实际读取的字节数
    """
    out_size = c_int(0)
    out_ptr = c_void_p(0)
    in_size = c_int(0)
    in_ptr = c_void_p(0)
    try:
        ok = dll.GetIO(master_index, slave_index,
                       byref(out_size), byref(out_ptr),
                       byref(in_size), byref(in_ptr))
        if ok != 1 or not in_ptr.value or in_size.value <= 0:
            return 0
        bytes_to_read = length if length > 0 else in_size.value
        bytes_to_read = min(bytes_to_read, in_size.value)
        bytes_to_read = min(bytes_to_read, len(buffer) - offset)
        if bytes_to_read <= 0:
            return 0
        ctypes.memmove(
            (c_ubyte * len(buffer)).from_buffer(buffer),
            in_ptr.value,
            bytes_to_read
        )
        return bytes_to_read
    except Exception:
        return 0


def write_output_data_direct(dll: DarraCoreDLL, master_index: int, slave_index: int,
                             data: bytes, offset: int = 0, length: int = 0) -> int:
    """
    写入输出数据（零拷贝，直接到 IOmap）

    参数:
        dll:          DLL 接口
        master_index: 主站索引
        slave_index:  从站索引
        data:         源数据
        offset:       源数据偏移
        length:       要写入的字节数, 0 表示全部
    返回:
        实际写入的字节数
    """
    out_size = c_int(0)
    out_ptr = c_void_p(0)
    in_size = c_int(0)
    in_ptr = c_void_p(0)
    try:
        ok = dll.GetIO(master_index, slave_index,
                       byref(out_size), byref(out_ptr),
                       byref(in_size), byref(in_ptr))
        if ok != 1 or not out_ptr.value or out_size.value <= 0:
            return 0
        bytes_to_write = length if length > 0 else (len(data) - offset)
        bytes_to_write = min(bytes_to_write, out_size.value)
        bytes_to_write = min(bytes_to_write, len(data) - offset)
        if bytes_to_write <= 0:
            return 0
        src_buf = (c_ubyte * bytes_to_write).from_buffer_copy(data[offset:offset + bytes_to_write])
        ctypes.memmove(out_ptr.value, src_buf, bytes_to_write)
        return bytes_to_write
    except Exception:
        return 0


# ===================== PDO 变化检测 =====================

class PDOWatcher:
    """单个从站的 PDO 监视记录"""

    def __init__(self, slave_index: int, pdo_index: int,
                 callback: Callable[[int, int, bytes, bytes], None],
                 buffer_size: int = 256):
        self.slave_index = slave_index
        self.pdo_index = pdo_index
        self.callback = callback
        self.buffer_size = buffer_size
        self._snapshot: Optional[bytes] = None

    def __repr__(self) -> str:
        return f"PDOWatcher(slave={self.slave_index}, pdo={self.pdo_index})"


class PDOMonitor:
    """
    PDO 变化检测器

    周期性比对 PDO 快照, 在数据发生变化时触发回调。
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int):
        self._dll = dll
        self._mi = master_index
        self._watchers: List[Optional[PDOWatcher]] = []
        self._lock = threading.Lock()
        self._running = False

    def watch(self, slave_index: int,
              callback: Callable[[int, int, bytes, bytes], None],
              pdo_index: int = 0, buffer_size: int = 256) -> int:
        """添加 PDO 监视项, 返回监视项 ID"""
        watcher = PDOWatcher(slave_index, pdo_index, callback, buffer_size)
        with self._lock:
            self._watchers.append(watcher)
            return len(self._watchers) - 1

    def unwatch(self, watcher_id: int) -> bool:
        """移除监视项"""
        with self._lock:
            if 0 <= watcher_id < len(self._watchers):
                self._watchers[watcher_id] = None
                return True
        return False

    def clear(self) -> None:
        """移除所有监视项"""
        with self._lock:
            self._watchers.clear()

    def check(self) -> int:
        """执行一次 PDO 快照比对, 返回变化数量"""
        changed = 0
        with self._lock:
            watchers = [w for w in self._watchers if w is not None]

        for watcher in watchers:
            buf = ctypes.create_string_buffer(watcher.buffer_size)
            bytes_read = c_uint(0)
            ok = self._dll.PDOReadDirect(
                self._mi, watcher.slave_index, watcher.pdo_index,
                ctypes.cast(buf, c_void_p), watcher.buffer_size, byref(bytes_read)
            )
            if not ok or bytes_read.value == 0:
                continue

            current = bytes(buf.raw[:bytes_read.value])
            if watcher._snapshot is None:
                watcher._snapshot = current
                continue

            if current != watcher._snapshot:
                old_snapshot = watcher._snapshot
                watcher._snapshot = current
                changed += 1
                try:
                    watcher.callback(watcher.slave_index, watcher.pdo_index,
                                     old_snapshot, current)
                except Exception:
                    pass

        return changed

    def start_background(self, interval_ms: float = 10.0) -> threading.Thread:
        """启动后台检测线程"""
        self._running = True

        def _loop():
            while self._running:
                self.check()
                time.sleep(interval_ms / 1000.0)

        thread = threading.Thread(target=_loop, daemon=True, name='PDOMonitor')
        thread.start()
        return thread

    def stop_background(self) -> None:
        """停止后台检测线程"""
        self._running = False

    @property
    def watcher_count(self) -> int:
        with self._lock:
            return sum(1 for w in self._watchers if w is not None)

    def __repr__(self) -> str:
        return f"PDOMonitor(master={self._mi}, watchers={self.watcher_count})"


# ===================== PDO 统计属性 =====================

class PDOManager:
    """
    PDO 管理器 - 提供主站级 PDO 统计信息

    对应 C# PDOManager: 批量读写、监控、统计属性
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int):
        """
        初始化 PDO 管理器

        参数:
            dll:          DLL 接口
            master_index: 主站索引
        """
        self._dll = dll
        self._mi = master_index

    @property
    def avg_cycle_time_ns(self) -> int:
        """获取平均周期时间（纳秒）"""
        return self._dll.GetPDOAvgCycleTimeNs(self._mi)

    @property
    def error_count(self) -> int:
        """获取 PDO 错误计数"""
        return self._dll.GetPDOErrorCount(self._mi)

    @property
    def is_valid(self) -> bool:
        """检查 PDO 数据是否有效（至少接收到一帧且 WKC 正确）"""
        return bool(self._dll.IsPDOValid(self._mi))

    @property
    def changed(self) -> bool:
        """检查 PDO 数据是否发生变化（自上次调用后）"""
        return bool(self._dll.IsPDOChanged(self._mi))

    @property
    def expected_size(self) -> int:
        """获取 PDO 预期数据大小（所有从站输入+输出总字节数）"""
        return self._dll.GetPDOExpectedSize(self._mi)

    def start_monitoring(self, interval_ms: int = 100):
        """启动 PDO 监控"""
        self._dll.EnablePDOMonitoring(True)

    def stop_monitoring(self):
        """停止 PDO 监控"""
        self._dll.EnablePDOMonitoring(False)

    def get_performance_stats(self, slave_index: int) -> Optional[dict]:
        """
        获取从站的 PDO 性能统计

        参数:
            slave_index: 从站索引
        返回:
            性能统计字典, 包含 avg_cycle_ns, min_cycle_ns, max_cycle_ns, jitter_ns 等
        """
        try:
            ptr = self._dll.GetPDOStats(self._mi, slave_index)
            if not ptr:
                return None
            # 使用 PDOStats 结构体正确解析 (5 个 uint32 + 4 个 uint64, Pack=1)
            from ..utils.dll import PDOStats as _PDOStats
            stats = _PDOStats.from_address(ptr)
            return {
                'read_count': stats.read_count,
                'write_count': stats.write_count,
                'error_count': stats.error_count,
                'total_bytes_read': stats.total_bytes_read,
                'total_bytes_written': stats.total_bytes_written,
                'last_cycle_ns': stats.last_cycle_time_ns,
                'min_cycle_ns': stats.min_cycle_time_ns,
                'max_cycle_ns': stats.max_cycle_time_ns,
                'avg_cycle_ns': stats.avg_cycle_time_ns,
            }
        except Exception:
            return None

    def reset_performance_stats(self, slave_index: int = 0):
        """
        重置从站的性能统计

        参数:
            slave_index: 从站索引, 0 表示所有从站
        """
        self._dll.ResetPDOStats(self._mi, slave_index)

    def get_cached_data(self, slave_index: int) -> Optional[dict]:
        """
        获取从站的缓存 PDO 数据

        参数:
            slave_index: 从站索引
        返回:
            缓存数据字典, 或 None
        """
        try:
            out_size = c_int(0)
            out_ptr = c_void_p(0)
            in_size = c_int(0)
            in_ptr = c_void_p(0)
            ok = self._dll.GetIO(self._mi, slave_index,
                                 byref(out_size), byref(out_ptr),
                                 byref(in_size), byref(in_ptr))
            if ok != 1:
                return None
            result = {'slave_index': slave_index}
            if in_ptr.value and in_size.value > 0:
                buf = (ctypes.c_ubyte * in_size.value).from_address(in_ptr.value)
                result['input_data'] = bytes(buf)
            if out_ptr.value and out_size.value > 0:
                buf = (ctypes.c_ubyte * out_size.value).from_address(out_ptr.value)
                result['output_data'] = bytes(buf)
            return result
        except Exception:
            return None

    def batch_read_pooled(self, slave_indices: List[int],
                          expected_sizes: List[int]) -> dict:
        """
        执行批量读取（复用预分配缓冲区，减少内存分配）

        参数:
            slave_indices:  从站索引列表
            expected_sizes: 预期数据大小列表
        返回:
            以从站索引为键、bytes 为值的字典
        """
        results = {}
        if len(slave_indices) != len(expected_sizes):
            return results
        for si, sz in zip(slave_indices, expected_sizes):
            out_size = c_int(0)
            out_ptr = c_void_p(0)
            in_size = c_int(0)
            in_ptr = c_void_p(0)
            try:
                ok = self._dll.GetIO(self._mi, si,
                                     byref(out_size), byref(out_ptr),
                                     byref(in_size), byref(in_ptr))
                if ok == 1 and in_ptr.value and in_size.value > 0:
                    to_read = min(sz, in_size.value)
                    buf = (ctypes.c_ubyte * to_read).from_address(in_ptr.value)
                    results[si] = bytes(buf)
            except Exception:
                pass
        return results

    def batch_write_pooled(self, slave_indices: List[int],
                           data_list: List[bytes]) -> int:
        """
        执行批量写入（复用预分配缓冲区）

        参数:
            slave_indices: 从站索引列表
            data_list:     要写入的数据列表
        返回:
            成功写入的从站数量
        """
        if len(slave_indices) != len(data_list):
            return 0
        success_count = 0
        for si, data in zip(slave_indices, data_list):
            out_size = c_int(0)
            out_ptr = c_void_p(0)
            in_size = c_int(0)
            in_ptr = c_void_p(0)
            try:
                ok = self._dll.GetIO(self._mi, si,
                                     byref(out_size), byref(out_ptr),
                                     byref(in_size), byref(in_ptr))
                if ok == 1 and out_ptr.value and out_size.value > 0:
                    to_write = min(len(data), out_size.value)
                    src = (c_ubyte * to_write).from_buffer_copy(data[:to_write])
                    ctypes.memmove(out_ptr.value, src, to_write)
                    success_count += 1
            except Exception:
                pass
        return success_count

    # ===================== IOmap 锁定 (对应 C# LockIOmap/UnlockIOmap) =====================

    def lock_iomap(self):
        """
        锁定 IOmap

        当 MutexProtection = False 时需手动调用, 与 unlock_iomap 配对使用
        """
        self._dll.LockIOmap(self._mi)

    def unlock_iomap(self):
        """
        解锁 IOmap

        与 lock_iomap 配对使用
        """
        self._dll.UnlockIOmap(self._mi)

    # ===================== 组周期分频 (对应 C# GroupCycleDivider) =====================

    def get_group_cycle_divider(self, group: int) -> int:
        """
        获取指定组的周期分频值

        参数:
            group: 组索引
        返回:
            分频值
        """
        return self._dll.GetGroupCycleDivider(self._mi, group)

    def set_group_cycle_divider(self, group: int, divider: int) -> bool:
        """
        设置指定组的周期分频值

        参数:
            group:   组索引
            divider: 分频值 (1=每周期, 2=每2周期, ...)
        返回:
            是否成功
        """
        return bool(self._dll.SetGroupCycleDivider(self._mi, group, divider))

    # ===================== PDO 统计 (对应 C# GetPDOStats/ResetPDOStats) =====================

    def get_pdo_stats(self, slave_index: int = 0) -> Optional[dict]:
        """
        获取 PDO 统计信息

        参数:
            slave_index: 从站索引, 0 表示主站级统计
        返回:
            统计信息字典, 包含读写次数、错误数、字节数、周期时间等
        """
        return self.get_performance_stats(slave_index)

    def reset_pdo_stats(self, slave_index: int = 0):
        """
        重置 PDO 统计信息

        参数:
            slave_index: 从站索引, 0 表示全部
        """
        self.reset_performance_stats(slave_index)

    # ===================== PDO 映射查询 (对应 C# GetPDOMapping) =====================

    def get_pdo_mapping(self, slave_index: int) -> Optional[list]:
        """
        获取从站的 PDO 映射信息

        参数:
            slave_index: 从站索引
        返回:
            PDO 映射项列表, 每项为 dict; 失败返回 None
        """
        try:
            buf_size = 256
            buf = ctypes.create_string_buffer(buf_size * 8)  # 每项 8 字节
            count = c_uint(0)
            ok = self._dll.GetPDOMapping(
                self._mi, slave_index, 0,
                ctypes.cast(buf, c_void_p), buf_size, byref(count)
            )
            if not ok or count.value == 0:
                return None
            result = []
            for i in range(count.value):
                offset = i * 8
                raw = buf.raw[offset:offset + 8]
                if len(raw) >= 8:
                    import struct as _struct
                    index, subindex, bit_len, bit_offset = _struct.unpack_from('<HHHH', raw)
                    result.append({
                        'index': index,
                        'subindex': subindex,
                        'bit_length': bit_len,
                        'bit_offset': bit_offset,
                    })
            return result
        except Exception:
            return None

    # ===================== 直接读写 (对应 C# PDOReadDirect/PDOWriteDirect) =====================

    def pdo_read_direct(self, slave_index: int, offset: int, size: int) -> Optional[bytes]:
        """
        直接从 IOmap 读取指定从站的输入数据

        参数:
            slave_index: 从站索引
            offset:      输入数据区的字节偏移
            size:        要读取的字节数
        返回:
            读取到的字节数据, 失败返回 None
        """
        out_size = ctypes.c_int(0)
        out_ptr = c_void_p(0)
        in_size = ctypes.c_int(0)
        in_ptr = c_void_p(0)
        try:
            ok = self._dll.GetIO(self._mi, slave_index,
                                 ctypes.byref(out_size), ctypes.byref(out_ptr),
                                 ctypes.byref(in_size), ctypes.byref(in_ptr))
            if ok != 1 or not in_ptr.value or in_size.value <= 0:
                return None
            if offset + size > in_size.value:
                return None
            arr = (ctypes.c_ubyte * size).from_address(in_ptr.value + offset)
            return bytes(arr)
        except Exception:
            return None

    def pdo_write_direct(self, slave_index: int, offset: int, data: bytes) -> bool:
        """
        直接向 IOmap 写入指定从站的输出数据

        参数:
            slave_index: 从站索引
            offset:      输出数据区的字节偏移
            data:        要写入的字节数据
        返回:
            是否成功
        """
        out_size = ctypes.c_int(0)
        out_ptr = c_void_p(0)
        in_size = ctypes.c_int(0)
        in_ptr = c_void_p(0)
        try:
            ok = self._dll.GetIO(self._mi, slave_index,
                                 ctypes.byref(out_size), ctypes.byref(out_ptr),
                                 ctypes.byref(in_size), ctypes.byref(in_ptr))
            if ok != 1 or not out_ptr.value or out_size.value <= 0:
                return False
            if offset + len(data) > out_size.value:
                return False
            src = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
            ctypes.memmove(out_ptr.value + offset, src, len(data))
            return True
        except Exception:
            return False

    # ===================== 帧丢失统计 (对应 C# GetPDOFrameLossStats) =====================

    def get_pdo_frame_loss_stats(self, group: int = 0) -> Optional[dict]:
        """
        获取 PDO 帧丢失统计

        参数:
            group: 组索引
        返回:
            统计信息字典, 包含 total_loss, consecutive_loss, max_consecutive_loss
        """
        try:
            total = c_uint(0)
            consecutive = c_uint(0)
            max_consecutive = c_uint(0)
            self._dll.GetPDOFrameLossStats(
                self._mi, group,
                byref(total), byref(consecutive), byref(max_consecutive)
            )
            return {
                'total_loss': total.value,
                'consecutive_loss': consecutive.value,
                'max_consecutive_loss': max_consecutive.value,
            }
        except Exception:
            return None

    def reset_pdo_frame_loss_stats(self, group: int = 0):
        """
        重置 PDO 帧丢失统计

        参数:
            group: 组索引
        """
        self._dll.ResetPDOFrameLossStats(self._mi, group)

    # ===================== Mutex 保护 (对应 C# SetMutexProtection) =====================

    def set_mutex_protection(self, enable: bool):
        """
        设置 IOmap 互斥保护

        启用后, PDO 循环会自动加锁; 禁用后需手动调用 lock_iomap/unlock_iomap。

        参数:
            enable: 是否启用
        """
        self._dll.SetMutexProtection(self._mi, enable)

    def get_mutex_protection(self) -> bool:
        """获取 IOmap 互斥保护状态"""
        return bool(self._dll.GetMutexProtection(self._mi))

    def __repr__(self) -> str:
        return f"PDOManager(master={self._mi})"


# ===================== 批量 PDO 读写 =====================

def batch_read(dll: DarraCoreDLL, master_index: int, slave_index: int,
               offsets: List[int], sizes: List[int]) -> List[Optional[memoryview]]:
    """
    批量读取多个 PDO 值 (零拷贝, 使用 memoryview)

    通过一次 GetIO 调用获取输入数据指针, 然后按偏移量切片,
    避免多次 DLL 调用和内存拷贝。

    参数:
        dll:          DLL 接口
        master_index: 主站索引
        slave_index:  从站索引
        offsets:      各 PDO 项在输入数据区的字节偏移列表
        sizes:        各 PDO 项的字节长度列表

    返回:
        memoryview 列表, 每项对应一个 PDO 值; 读取失败的项为 None
    """
    if len(offsets) != len(sizes):
        raise ValueError("offsets 和 sizes 长度必须一致")

    results: List[Optional[memoryview]] = [None] * len(offsets)

    # 获取输入数据指针和大小
    out_size = c_int(0)
    out_ptr = c_void_p(0)
    in_size = c_int(0)
    in_ptr = c_void_p(0)
    try:
        ok = dll.GetIO(master_index, slave_index,
                       byref(out_size), byref(out_ptr),
                       byref(in_size), byref(in_ptr))
        if ok != 1 or not in_ptr.value or in_size.value <= 0:
            return results

        # 将整个输入区域映射为 ctypes 数组, 再用 memoryview 切片
        total_size = in_size.value
        array_type = (ctypes.c_ubyte * total_size)
        buf = array_type.from_address(in_ptr.value)
        mv = memoryview(buf)

        for i, (offset, size) in enumerate(zip(offsets, sizes)):
            if offset >= 0 and offset + size <= total_size:
                results[i] = mv[offset:offset + size]

    except Exception:
        pass

    return results


def batch_write(dll: DarraCoreDLL, master_index: int, slave_index: int,
                offsets: List[int], values: List[bytes]) -> int:
    """
    批量写入多个 PDO 值 (零拷贝, 直接写入 IOmap)

    通过一次 GetIO 调用获取输出数据指针, 然后按偏移量依次写入,
    避免多次 DLL 调用。

    参数:
        dll:          DLL 接口
        master_index: 主站索引
        slave_index:  从站索引
        offsets:      各 PDO 项在输出数据区的字节偏移列表
        values:       各 PDO 项要写入的字节数据列表

    返回:
        成功写入的 PDO 项数量
    """
    if len(offsets) != len(values):
        raise ValueError("offsets 和 values 长度必须一致")

    out_size = c_int(0)
    out_ptr = c_void_p(0)
    in_size = c_int(0)
    in_ptr = c_void_p(0)
    written = 0

    try:
        ok = dll.GetIO(master_index, slave_index,
                       byref(out_size), byref(out_ptr),
                       byref(in_size), byref(in_ptr))
        if ok != 1 or not out_ptr.value or out_size.value <= 0:
            return 0

        total_size = out_size.value

        for offset, data in zip(offsets, values):
            if offset >= 0 and offset + len(data) <= total_size:
                src = (c_ubyte * len(data)).from_buffer_copy(data)
                ctypes.memmove(out_ptr.value + offset, src, len(data))
                written += 1

    except Exception:
        pass

    return written


# ===================== AsSpan / ReadInputDataToSpan / WriteOutputDataFromSpan / WriteFromBaseData / EnsureCapacity =====================

def as_memoryview(dll: DarraCoreDLL, master_index: int, slave_index: int,
                  is_input: bool = True) -> memoryview:
    """
    获取 PDO 数据区的 memoryview (零拷贝)

    对应 C# AsSpan: 直接返回 IOmap 内存视图, 无需拷贝。

    参数:
        dll:          DLL 接口
        master_index: 主站索引
        slave_index:  从站索引
        is_input:     True=输入数据, False=输出数据
    返回:
        memoryview, 失败返回空 memoryview
    """
    out_size = c_int(0)
    out_ptr = c_void_p(0)
    in_size = c_int(0)
    in_ptr = c_void_p(0)
    try:
        ok = dll.GetIO(master_index, slave_index,
                       byref(out_size), byref(out_ptr),
                       byref(in_size), byref(in_ptr))
        if ok != 1:
            return memoryview(b'')
        if is_input:
            ptr, sz = in_ptr.value, in_size.value
        else:
            ptr, sz = out_ptr.value, out_size.value
        if not ptr or sz <= 0:
            return memoryview(b'')
        arr = (ctypes.c_ubyte * sz).from_address(ptr)
        return memoryview(arr)
    except Exception:
        return memoryview(b'')


def read_input_to_buffer(dll: DarraCoreDLL, master_index: int, slave_index: int,
                         buf: bytearray) -> int:
    """
    读取 PDO 输入数据到用户提供的 buffer (对应 C# ReadInputDataToSpan)

    参数:
        dll:          DLL 接口
        master_index: 主站索引
        slave_index:  从站索引
        buf:          目标 bytearray
    返回:
        实际读取的字节数
    """
    return read_input_data_direct(dll, master_index, slave_index, buf, 0, len(buf))


def write_output_from_buffer(dll: DarraCoreDLL, master_index: int, slave_index: int,
                             buf: bytes) -> int:
    """
    从用户 buffer 写入 PDO 输出数据 (对应 C# WriteOutputDataFromSpan)

    参数:
        dll:          DLL 接口
        master_index: 主站索引
        slave_index:  从站索引
        buf:          源 bytes/bytearray
    返回:
        实际写入的字节数
    """
    return write_output_data_direct(dll, master_index, slave_index, buf, 0, len(buf))


def write_from_typed(dll: DarraCoreDLL, master_index: int, slave_index: int,
                     data_item: BaseDataWrapper, byte_offset: int = 0) -> bool:
    """
    从类型化 BaseData 包装写入 PDO 输出 (对应 C# WriteFromBaseData)

    参数:
        dll:          DLL 接口
        master_index: 主站索引
        slave_index:  从站索引
        data_item:    BaseDataWrapper 实例
        byte_offset:  目标输出区偏移
    返回:
        是否成功
    """
    raw = data_item.raw
    if not raw:
        return False
    out_size = c_int(0)
    out_ptr = c_void_p(0)
    in_size = c_int(0)
    in_ptr = c_void_p(0)
    try:
        ok = dll.GetIO(master_index, slave_index,
                       byref(out_size), byref(out_ptr),
                       byref(in_size), byref(in_ptr))
        if ok != 1 or not out_ptr.value or out_size.value <= 0:
            return False
        if byte_offset + len(raw) > out_size.value:
            return False
        src = (c_ubyte * len(raw)).from_buffer_copy(raw)
        ctypes.memmove(out_ptr.value + byte_offset, src, len(raw))
        return True
    except Exception:
        return False


def ensure_capacity(current_buffer: bytearray, required_size: int) -> bytearray:
    """
    确保内部 buffer 足够大 (对应 C# EnsureCapacity)

    如果 current_buffer 已经满足大小要求, 直接返回;
    否则创建更大的 buffer 并拷贝已有数据。

    参数:
        current_buffer: 当前 buffer
        required_size:  所需最小大小(字节)
    返回:
        满足大小要求的 bytearray (可能是原始 buffer 或新分配的)
    """
    if len(current_buffer) >= required_size:
        return current_buffer
    new_buf = bytearray(required_size)
    new_buf[:len(current_buffer)] = current_buffer
    return new_buf
