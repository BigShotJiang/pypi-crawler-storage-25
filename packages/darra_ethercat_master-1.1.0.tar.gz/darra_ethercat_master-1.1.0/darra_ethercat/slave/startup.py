# -*- coding: utf-8 -*-
"""
启动参数管理
对应 C# Startup.cs
提供 StartupParameter 和 StartupParameterList
"""

from dataclasses import dataclass, field
from typing import Optional, List, Iterator
from enum import IntEnum

from ..utils.dll import (
    DarraCoreDLL, StartupParam,
    TRANS_IP, TRANS_PS, TRANS_SO,
    TIMING_BEFORE, TIMING_AFTER,
)
from ..data.types import StartupTransition, StartupWriteTiming


# ===================== 启动参数 =====================

@dataclass
class StartupParameter:
    """
    单个启动参数 (SDO 写入配置)
    对应 C# StartupParameter 类
    """
    index: int = 0
    """SDO 索引 (0x0000-0xFFFF)"""
    sub_index: int = 0
    """SDO 子索引"""
    data: bytes = b''
    """要写入的数据"""
    transition: StartupTransition = StartupTransition.IP
    """状态转换阶段"""
    priority: int = 100
    """优先级 (数值越小优先级越高, 相同优先级按添加顺序)"""
    write_timing: StartupWriteTiming = StartupWriteTiming.AFTER_TRANSITION
    """写入时机 (状态转换前/后)"""
    complete_access: bool = False
    """是否使用 Complete Access"""
    is_read_operation: bool = False
    """是否为读操作 (False=写, True=读)"""
    is_register_write: bool = False
    """是否为寄存器写入 (非SDO)"""
    register_address: int = 0
    """寄存器地址 (仅当 is_register_write=True)"""
    register_type: int = 0
    """寄存器类型 (仅当 is_register_write=True)"""
    description: str = ""
    """参数描述"""

    @property
    def phase(self) -> int:
        """兼容旧代码的 Phase 属性 (返回 DLL transition 值)"""
        return self.transition.value

    @phase.setter
    def phase(self, value: int):
        """通过 Phase 值设置 transition"""
        _map = {
            0: StartupTransition.IP,
            1: StartupTransition.PS,
            2: StartupTransition.SO,
            3: StartupTransition.OS,
            4: StartupTransition.SP,
            5: StartupTransition.PI,
        }
        self.transition = _map.get(value, StartupTransition.PS)

    def to_dll_param(self) -> StartupParam:
        """转换为 DLL StartupParam 结构体"""
        param = StartupParam()
        param.index = self.index
        param.sub_index = self.sub_index
        param.data_len = len(self.data)
        param.transition = self.transition.value
        param.timing = self.write_timing.value
        param.complete_access = 1 if self.complete_access else 0
        param.priority = self.priority
        # 将 data 复制到结构体
        for i, b in enumerate(self.data[:256]):  # 最大 256 字节
            param.data[i] = b
        return param

    def apply(self, slave) -> bool:
        """
        将此参数应用到指定从站

        参数:
            slave: Slave 实例

        返回:
            是否成功
        """
        if self.is_register_write:
            return slave.write_register(self.register_address, self.data)
        elif self.is_read_operation:
            result = slave.coe.sdo_read(self.index, self.sub_index,
                                        self.complete_access)
            return result is not None
        else:
            return slave.coe.sdo_write(self.index, self.sub_index,
                                       self.data, self.complete_access)


# ===================== 启动参数列表 =====================

class StartupParameterList:
    """
    启动参数列表 (可迭代, 类列表操作)
    管理从站的所有启动参数并与 DLL 同步
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        self._params: List[StartupParameter] = []

    @property
    def count(self) -> int:
        """参数数量"""
        return len(self._params)

    def __len__(self) -> int:
        return len(self._params)

    def __iter__(self) -> Iterator[StartupParameter]:
        return iter(self._params)

    def __getitem__(self, index: int) -> StartupParameter:
        return self._params[index]

    def add(self, index: int, sub_index: int, data: bytes,
            transition: StartupTransition = StartupTransition.IP,
            priority: int = 0,
            write_timing: Optional[StartupWriteTiming] = None,
            complete_access: bool = False,
            description: str = "") -> StartupParameter:
        """
        添加启动参数

        参数:
            index: SDO 索引
            sub_index: SDO 子索引
            data: 写入数据
            transition: 状态转换阶段
            priority: 优先级
            write_timing: 写入时机 (None=使用默认)
            complete_access: 是否完整访问
            description: 描述

        返回:
            创建的 StartupParameter
        """
        if write_timing is None:
            # 根据转换阶段设置默认写入时机
            _defaults = {
                StartupTransition.IP: StartupWriteTiming.AFTER_TRANSITION,
                StartupTransition.PS: StartupWriteTiming.BEFORE_TRANSITION,
                StartupTransition.SO: StartupWriteTiming.BEFORE_TRANSITION,
                StartupTransition.OS: StartupWriteTiming.AFTER_TRANSITION,
                StartupTransition.SP: StartupWriteTiming.AFTER_TRANSITION,
                StartupTransition.PI: StartupWriteTiming.BEFORE_TRANSITION,
            }
            write_timing = _defaults.get(transition, StartupWriteTiming.AFTER_TRANSITION)

        param = StartupParameter(
            index=index,
            sub_index=sub_index,
            data=data,
            transition=transition,
            priority=priority,
            write_timing=write_timing,
            complete_access=complete_access,
            description=description,
        )
        self._params.append(param)

        # 同步到 DLL
        try:
            dll_param = param.to_dll_param()
            from ctypes import byref
            self._dll.AddStartupParameter(self._mi, self._si, byref(dll_param))
        except Exception:
            pass

        return param

    def add_parameter(self, param: StartupParameter):
        """添加已创建的启动参数"""
        self._params.append(param)
        try:
            dll_param = param.to_dll_param()
            from ctypes import byref
            self._dll.AddStartupParameter(self._mi, self._si, byref(dll_param))
        except Exception:
            pass

    def remove(self, param: StartupParameter) -> bool:
        """
        移除启动参数

        参数:
            param: 要移除的参数

        返回:
            是否成功移除
        """
        try:
            self._params.remove(param)
            self._sync_to_dll()
            return True
        except ValueError:
            return False

    def clear(self):
        """清除所有启动参数"""
        self._params.clear()
        try:
            self._dll.ClearStartupParameters(self._mi, self._si)
        except Exception:
            pass

    def _sync_to_dll(self):
        """将所有参数重新同步到 DLL"""
        try:
            self._dll.ClearStartupParameters(self._mi, self._si)
            from ctypes import byref
            for p in self._params:
                dll_param = p.to_dll_param()
                self._dll.AddStartupParameter(self._mi, self._si, byref(dll_param))
        except Exception:
            pass

    def apply_all(self, slave) -> int:
        """
        按优先级和转换阶段顺序应用所有参数

        参数:
            slave: Slave 实例

        返回:
            成功应用的参数数量
        """
        sorted_params = sorted(self._params, key=lambda p: (p.priority, p.phase))
        success = 0
        for p in sorted_params:
            if p.apply(slave):
                success += 1
        return success


# ===================== 自动启动配置 =====================

class StartupAutoConfig:
    """
    启动参数自动配置器
    对应 C# Startup 中的 AutoStartupFromESI/MDP/SM 等方法
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int,
                 startup_params: StartupParameterList):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        self._params = startup_params
        self._has_executed = False
        self._config_source = ""

    # ESI/MDP 自动启动参数功能仅在 C# SDK 中可用

    def enumerate_default_pdo(self, direction: int, max_count: int = 16) -> List[int]:
        """
        枚举从站默认 PDO Assignment (协议算法下沉, 见 native default_pdo.c, 2026-05-02)

        从从站对象字典读取当前 PDO 索引列表 (RxPDO 或 TxPDO).
        SDK 公开层不再循环 SDORead PDO Assignment SubIndex; 由 native 处理协议细节.

        参数:
            direction: 0=RxPDO (master→slave 输出), 1=TxPDO (slave→master 输入)
            max_count: 最多枚举的 PDO 数量 (默认 16)

        返回:
            PDO 索引列表 (e.g. [0x1600, 0x1601, ...]); 失败返回空列表
        """
        from ctypes import c_ushort
        if direction not in (0, 1):
            return []
        if max_count <= 0:
            return []
        BufType = c_ushort * max_count
        buf = BufType()
        try:
            n = self._dll.EnumerateDefaultPdo(self._mi, self._si,
                                              direction, buf, max_count)
        except Exception:
            return []
        if n <= 0:
            return []
        return [int(buf[i]) for i in range(min(n, max_count))]

    def set_config_source_eni(self):
        """标记已从 ENI 文件加载配置"""
        self._has_executed = True
        self._config_source = "ENI"

    def set_config_source_deni(self):
        """标记已从 DENI 文件加载配置"""
        self._has_executed = True
        self._config_source = "DENI"

    @property
    def has_executed(self) -> bool:
        """是否已执行过自动配置"""
        return self._has_executed

    @property
    def config_source(self) -> str:
        """配置来源"""
        return self._config_source
