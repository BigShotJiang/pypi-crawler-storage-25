# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/SlavePdo.cs
从站 PDO 数据访问封装

提供从站级别的 PDO 输入/输出数据读写接口。
"""

import ctypes
from ctypes import c_uint, c_void_p, byref
from typing import Optional

from ..utils.dll import DarraCoreDLL


class SlavePdo:
    """
    从站 PDO 数据访问封装
    对应 C# SlavePdo 类

    提供从站的输入/输出 PDO 数据的直接读写接口。
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int):
        """
        初始化从站 PDO 访问

        参数:
            dll:          DLL 接口
            master_index: 主站索引
            slave_index:  从站索引
        """
        self._dll = dll
        self._mi = master_index
        self._si = slave_index

    @property
    def inputs(self) -> Optional[bytes]:
        """读取从站输入 PDO 数据 (通过 GetIO 获取指针后拷贝)"""
        try:
            out_size = ctypes.c_int(0)
            out_ptr = ctypes.c_void_p(0)
            in_size = ctypes.c_int(0)
            in_ptr = ctypes.c_void_p(0)
            ok = self._dll.GetIO(self._mi, self._si,
                                 byref(out_size), byref(out_ptr),
                                 byref(in_size), byref(in_ptr))
            if ok == 1 and in_ptr.value and in_size.value > 0:
                arr = (ctypes.c_ubyte * in_size.value).from_address(in_ptr.value)
                return bytes(arr)
        except Exception:
            pass
        return None

    @property
    def outputs(self) -> Optional[bytes]:
        """读取从站输出 PDO 数据 (通过 GetIO 获取指针后拷贝)"""
        try:
            out_size = ctypes.c_int(0)
            out_ptr = ctypes.c_void_p(0)
            in_size = ctypes.c_int(0)
            in_ptr = ctypes.c_void_p(0)
            ok = self._dll.GetIO(self._mi, self._si,
                                 byref(out_size), byref(out_ptr),
                                 byref(in_size), byref(in_ptr))
            if ok == 1 and out_ptr.value and out_size.value > 0:
                arr = (ctypes.c_ubyte * out_size.value).from_address(out_ptr.value)
                return bytes(arr)
        except Exception:
            pass
        return None

    def write_outputs(self, data: bytes) -> bool:
        """写入从站输出 PDO 数据 (通过 WriteSlaveOutput)"""
        buf = ctypes.create_string_buffer(data)
        self._dll.WriteSlaveOutput(
            self._mi, self._si,
            ctypes.cast(buf, c_void_p), len(data)
        )
        return True

    # ===================== 零拷贝指针访问 =====================

    def get_input_data_pointer(self) -> int:
        """
        获取输入数据的直接指针（零拷贝访问）

        警告: 仅在 PDO 循环中使用, 指针在 IOmap 重新映射后会失效
        返回: 指向输入数据的指针地址, 失败返回 0
        """
        from .pdo import get_input_data_pointer
        return get_input_data_pointer(self._dll, self._mi, self._si)

    def get_output_data_pointer(self) -> int:
        """
        获取输出数据的直接指针（零拷贝访问）

        警告: 仅在 PDO 循环中使用, 指针在 IOmap 重新映射后会失效
        返回: 指向输出数据的指针地址, 失败返回 0
        """
        from .pdo import get_output_data_pointer
        return get_output_data_pointer(self._dll, self._mi, self._si)

    # ===================== 直接读写 =====================

    def read_input_data_direct(self, buffer: bytearray, offset: int = 0, length: int = 0) -> int:
        """
        读取输入数据（零拷贝，直接从 IOmap）

        参数:
            buffer: 目标缓冲区
            offset: 目标缓冲区偏移
            length: 要读取的字节数, 0 表示全部
        返回:
            实际读取的字节数
        """
        from .pdo import read_input_data_direct
        return read_input_data_direct(self._dll, self._mi, self._si, buffer, offset, length)

    def write_output_data_direct(self, data: bytes, offset: int = 0, length: int = 0) -> int:
        """
        写入输出数据（零拷贝，直接到 IOmap）

        参数:
            data:   源数据
            offset: 源数据偏移
            length: 要写入的字节数, 0 表示全部
        返回:
            实际写入的字节数
        """
        from .pdo import write_output_data_direct
        return write_output_data_direct(self._dll, self._mi, self._si, data, offset, length)

    # ===================== 零拷贝内存视图 =====================

    def get_input_memoryview(self) -> memoryview:
        """
        获取输入 PDO 数据的 memoryview（零拷贝访问）

        返回: 输入数据的 memoryview, 失败返回空 memoryview
        警告: 仅在 PDO 循环中使用, IOmap 重新映射后视图会失效
        """
        out_size = ctypes.c_int(0)
        out_ptr = ctypes.c_void_p(0)
        in_size = ctypes.c_int(0)
        in_ptr = ctypes.c_void_p(0)
        try:
            ok = self._dll.GetIO(self._mi, self._si,
                                 ctypes.byref(out_size), ctypes.byref(out_ptr),
                                 ctypes.byref(in_size), ctypes.byref(in_ptr))
            if ok == 1 and in_ptr.value and in_size.value > 0:
                arr = (ctypes.c_ubyte * in_size.value).from_address(in_ptr.value)
                return memoryview(arr)
        except Exception:
            pass
        return memoryview(b'')

    def get_output_memoryview(self) -> memoryview:
        """
        获取输出 PDO 数据的 memoryview（零拷贝访问）

        返回: 输出数据的 memoryview, 失败返回空 memoryview
        警告: 仅在 PDO 循环中使用, IOmap 重新映射后视图会失效
        """
        out_size = ctypes.c_int(0)
        out_ptr = ctypes.c_void_p(0)
        in_size = ctypes.c_int(0)
        in_ptr = ctypes.c_void_p(0)
        try:
            ok = self._dll.GetIO(self._mi, self._si,
                                 ctypes.byref(out_size), ctypes.byref(out_ptr),
                                 ctypes.byref(in_size), ctypes.byref(in_ptr))
            if ok == 1 and out_ptr.value and out_size.value > 0:
                arr = (ctypes.c_ubyte * out_size.value).from_address(out_ptr.value)
                return memoryview(arr)
        except Exception:
            pass
        return memoryview(b'')

    # ===================== PDO 映射信息查询 =====================

    @property
    def inputs_mapping_info(self) -> dict:
        """
        获取输入 PDO 映射信息

        返回: 包含指针地址、大小、从站索引的字典
        """
        out_size = ctypes.c_int(0)
        out_ptr = ctypes.c_void_p(0)
        in_size = ctypes.c_int(0)
        in_ptr = ctypes.c_void_p(0)
        try:
            ok = self._dll.GetIO(self._mi, self._si,
                                 ctypes.byref(out_size), ctypes.byref(out_ptr),
                                 ctypes.byref(in_size), ctypes.byref(in_ptr))
            if ok == 1:
                return {
                    'pointer': in_ptr.value or 0,
                    'size': in_size.value,
                    'slave_index': self._si,
                }
        except Exception:
            pass
        return {'pointer': 0, 'size': 0, 'slave_index': self._si}

    @property
    def outputs_mapping_info(self) -> dict:
        """
        获取输出 PDO 映射信息

        返回: 包含指针地址、大小、从站索引的字典
        """
        out_size = ctypes.c_int(0)
        out_ptr = ctypes.c_void_p(0)
        in_size = ctypes.c_int(0)
        in_ptr = ctypes.c_void_p(0)
        try:
            ok = self._dll.GetIO(self._mi, self._si,
                                 ctypes.byref(out_size), ctypes.byref(out_ptr),
                                 ctypes.byref(in_size), ctypes.byref(in_ptr))
            if ok == 1:
                return {
                    'pointer': out_ptr.value or 0,
                    'size': out_size.value,
                    'slave_index': self._si,
                }
        except Exception:
            pass
        return {'pointer': 0, 'size': 0, 'slave_index': self._si}

    # ===================== 结构体绑定 =====================

    def bind_pdo_struct(self, struct_type, is_input: bool = True):
        """
        将 PDO 映射绑定到用户 ctypes.Structure (对应 C# BindPdoStruct)

        直接将 IOmap 中的 PDO 数据区视为指定的 ctypes.Structure,
        实现零拷贝的结构化访问。

        参数:
            struct_type: ctypes.Structure 子类
            is_input:    True=绑定输入数据, False=绑定输出数据
        返回:
            指向 IOmap 的 struct_type 实例, 失败返回 None

        用法::

            class MyPdo(ctypes.Structure):
                _fields_ = [("status", ctypes.c_uint16), ("position", ctypes.c_int32)]

            pdo_view = slave_pdo.bind_pdo_struct(MyPdo, is_input=True)
            if pdo_view:
                print(pdo_view.status, pdo_view.position)
        """
        out_size = ctypes.c_int(0)
        out_ptr = ctypes.c_void_p(0)
        in_size = ctypes.c_int(0)
        in_ptr = ctypes.c_void_p(0)
        try:
            ok = self._dll.GetIO(self._mi, self._si,
                                 ctypes.byref(out_size), ctypes.byref(out_ptr),
                                 ctypes.byref(in_size), ctypes.byref(in_ptr))
            if ok != 1:
                return None
            if is_input:
                ptr, sz = in_ptr.value, in_size.value
            else:
                ptr, sz = out_ptr.value, out_size.value
            if not ptr or sz < ctypes.sizeof(struct_type):
                return None
            return struct_type.from_address(ptr)
        except Exception:
            return None

    # ===================== 类型化读取 (对应 C# SlavePdo 类型化访问) =====================

    def read_int8(self, offset: int) -> int:
        """读取输入 PDO 有符号 8 位整数"""
        return self._dll.PdoReadInt8(self._mi, self._si, offset)

    def read_int16(self, offset: int) -> int:
        """读取输入 PDO 有符号 16 位整数"""
        return self._dll.PdoReadInt16(self._mi, self._si, offset)

    def read_int32(self, offset: int) -> int:
        """读取输入 PDO 有符号 32 位整数"""
        return self._dll.PdoReadInt32(self._mi, self._si, offset)

    def read_int64(self, offset: int) -> int:
        """读取输入 PDO 有符号 64 位整数"""
        import struct as _struct
        mv = self.get_input_memoryview()
        if len(mv) >= offset + 8:
            return _struct.unpack_from('<q', mv, offset)[0]
        return 0

    def read_uint8(self, offset: int) -> int:
        """读取输入 PDO 无符号 8 位整数"""
        return self._dll.PdoReadUint8(self._mi, self._si, offset)

    def read_uint16(self, offset: int) -> int:
        """读取输入 PDO 无符号 16 位整数"""
        return self._dll.PdoReadUint16(self._mi, self._si, offset)

    def read_uint32(self, offset: int) -> int:
        """读取输入 PDO 无符号 32 位整数"""
        return self._dll.PdoReadUint32(self._mi, self._si, offset)

    def read_uint64(self, offset: int) -> int:
        """读取输入 PDO 无符号 64 位整数"""
        import struct as _struct
        mv = self.get_input_memoryview()
        if len(mv) >= offset + 8:
            return _struct.unpack_from('<Q', mv, offset)[0]
        return 0

    def read_float(self, offset: int) -> float:
        """读取输入 PDO 32 位浮点数"""
        import struct as _struct
        mv = self.get_input_memoryview()
        if len(mv) >= offset + 4:
            return _struct.unpack_from('<f', mv, offset)[0]
        return 0.0

    def read_double(self, offset: int) -> float:
        """读取输入 PDO 64 位双精度浮点数"""
        import struct as _struct
        mv = self.get_input_memoryview()
        if len(mv) >= offset + 8:
            return _struct.unpack_from('<d', mv, offset)[0]
        return 0.0

    def read_string(self, offset: int, length: int) -> str:
        """
        读取输入 PDO 字符串

        参数:
            offset: 字节偏移
            length: 最大字符串长度
        返回:
            解码后的 ASCII 字符串
        """
        mv = self.get_input_memoryview()
        if len(mv) >= offset + length:
            raw = bytes(mv[offset:offset + length])
            null_idx = raw.find(b'\x00')
            if null_idx >= 0:
                raw = raw[:null_idx]
            return raw.decode('ascii', errors='replace')
        return ""

    # ===================== 类型化写入 (对应 C# SlavePdo 类型化访问) =====================

    def write_int8(self, offset: int, value: int) -> bool:
        """写入输出 PDO 有符号 8 位整数"""
        self._dll.PdoWriteInt8(self._mi, self._si, offset, value)
        return True

    def write_int16(self, offset: int, value: int) -> bool:
        """写入输出 PDO 有符号 16 位整数"""
        self._dll.PdoWriteInt16(self._mi, self._si, offset, value)
        return True

    def write_int32(self, offset: int, value: int) -> bool:
        """写入输出 PDO 有符号 32 位整数"""
        self._dll.PdoWriteInt32(self._mi, self._si, offset, value)
        return True

    def write_int64(self, offset: int, value: int) -> bool:
        """写入输出 PDO 有符号 64 位整数"""
        import struct as _struct
        data = _struct.pack('<q', value)
        return self.write_output_data_direct(data, offset, 8) == 8

    def write_uint8(self, offset: int, value: int) -> bool:
        """写入输出 PDO 无符号 8 位整数"""
        self._dll.PdoWriteUint8(self._mi, self._si, offset, value)
        return True

    def write_uint16(self, offset: int, value: int) -> bool:
        """写入输出 PDO 无符号 16 位整数"""
        self._dll.PdoWriteUint16(self._mi, self._si, offset, value)
        return True

    def write_uint32(self, offset: int, value: int) -> bool:
        """写入输出 PDO 无符号 32 位整数"""
        self._dll.PdoWriteUint32(self._mi, self._si, offset, value)
        return True

    def write_uint64(self, offset: int, value: int) -> bool:
        """写入输出 PDO 无符号 64 位整数"""
        import struct as _struct
        data = _struct.pack('<Q', value)
        return self.write_output_data_direct(data, offset, 8) == 8

    def write_float(self, offset: int, value: float) -> bool:
        """写入输出 PDO 32 位浮点数"""
        import struct as _struct
        data = _struct.pack('<f', value)
        return self.write_output_data_direct(data, offset, 4) == 4

    def write_double(self, offset: int, value: float) -> bool:
        """写入输出 PDO 64 位双精度浮点数"""
        import struct as _struct
        data = _struct.pack('<d', value)
        return self.write_output_data_direct(data, offset, 8) == 8

    def write_string(self, offset: int, value: str, max_length: int) -> bool:
        """
        写入输出 PDO 字符串

        参数:
            offset:     字节偏移
            value:      要写入的字符串
            max_length: 最大字符串长度 (含末尾 null)
        返回:
            是否成功
        """
        encoded = value.encode('ascii', errors='replace')[:max_length - 1]
        # 补 null 填充到 max_length
        data = encoded + b'\x00' * (max_length - len(encoded))
        return self.write_output_data_direct(data, offset, max_length) == max_length

    # ===================== 批量读写 =====================

    def batch_read(self, requests: list) -> list:
        """
        批量读取输入 PDO 数据

        参数:
            requests: 请求列表, 每项为 (offset, size) 元组
        返回:
            bytes 列表, 读取失败的项为 None
        """
        from .pdo import batch_read
        offsets = [r[0] for r in requests]
        sizes = [r[1] for r in requests]
        results = batch_read(self._dll, self._mi, self._si, offsets, sizes)
        return [bytes(mv) if mv is not None else None for mv in results]

    def batch_write(self, requests: list) -> int:
        """
        批量写入输出 PDO 数据

        参数:
            requests: 请求列表, 每项为 (offset, data) 元组
        返回:
            成功写入的项数量
        """
        from .pdo import batch_write
        offsets = [r[0] for r in requests]
        values = [r[1] for r in requests]
        return batch_write(self._dll, self._mi, self._si, offsets, values)

    def __repr__(self) -> str:
        return f"SlavePdo(master={self._mi}, slave={self._si})"
