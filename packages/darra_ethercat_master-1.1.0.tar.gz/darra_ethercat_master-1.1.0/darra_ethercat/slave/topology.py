# -*- coding: utf-8 -*-
"""
从站拓扑管理
对应 C# Slave/Topology.cs
提供 MII/EBUS 拓扑树结构、耦合器检测、子模块访问
"""

from typing import Optional, List, Dict, TYPE_CHECKING

if TYPE_CHECKING:
    from .core import Slave


# ===================== 端口物理类型常量 =====================

PTYPE_NOT_IMPLEMENTED = 0
"""未实现"""
PTYPE_NOT_CONFIGURED = 1
"""未配置"""
PTYPE_EBUS = 2
"""EBUS (背板总线)"""
PTYPE_MII = 3
"""MII (外部接口)"""


# ===================== 从站拓扑访问器 =====================

class SlaveTopology:
    """
    从站拓扑访问器
    对应 C# SlaveTopology 类

    支持按拓扑索引访问从站:
    - topology[0] 获取第一个耦合器/根节点从站
    - topology["0x1001"] 通过地址获取从站

    用法:
        topology = SlaveTopology(master)
        root = topology[0]
        children = topology.get_children(root)
    """

    def __init__(self, master):
        """
        构造拓扑访问器

        参数:
            master: EtherCATMaster 实例
        """
        self._master = master
        self._root_slaves: List['Slave'] = []
        self._child_map: Dict[int, List['Slave']] = {}
        self._address_map: Dict[int, 'Slave'] = {}
        self.rebuild()

    def rebuild(self):
        """重建拓扑结构（当从站列表变化时调用）"""
        self._root_slaves = []
        self._child_map = {}
        self._address_map = {}

        if self._master is None or self._master.slave_count == 0:
            return

        slaves = []
        for i in range(1, self._master.slave_count + 1):
            slaves.append(self._master[i])

        # 读取每个从站的拓扑信息
        slave_info = {}
        for slv in slaves:
            si = slv.index
            try:
                parent = slv.parent_index
                active = slv.active_ports
                # 使用 DLL 获取物理端口类型和入口端口
                ptype = self._master._dll.GetSlavePhysicalType(
                    self._master._mi, si) if hasattr(
                        self._master._dll, 'GetSlavePhysicalType') else 0
                entry_port = self._master._dll.GetSlaveEntryPort(
                    self._master._mi, si) if hasattr(
                        self._master._dll, 'GetSlaveEntryPort') else 0
                config_addr = self._master._dll.GetSlaveConfigAddr(
                    self._master._mi, si) if hasattr(
                        self._master._dll, 'GetSlaveConfigAddr') else 0
            except Exception:
                parent = 0
                active = 0
                ptype = 0
                entry_port = 0
                config_addr = 0

            slave_info[si] = {
                'slave': slv,
                'parent': parent,
                'active_ports': active,
                'physical_type': ptype,
                'entry_port': entry_port,
                'config_addr': config_addr,
            }
            # 建立地址映射
            if config_addr > 0:
                self._address_map[config_addr] = slv

        # 计算每个 EBUS 设备所属的耦合器
        for si, info in slave_info.items():
            entry_port_type = (info['physical_type'] >> (info['entry_port'] * 2)) & 0x03

            if entry_port_type == PTYPE_MII or info['parent'] == 0:
                # MII 入口设备或直连主站的设备 → 作为根节点
                self._root_slaves.append(info['slave'])
            elif entry_port_type == PTYPE_EBUS:
                # EBUS 入口设备 → 向上查找所属的耦合器
                current = info['parent']
                found_coupler = 0
                while current > 0 and current in slave_info:
                    parent_info = slave_info[current]
                    parent_entry_type = (
                        parent_info['physical_type'] >>
                        (parent_info['entry_port'] * 2)) & 0x03
                    if parent_entry_type == PTYPE_MII or parent_info['parent'] == 0:
                        found_coupler = current
                        break
                    current = parent_info['parent']

                if found_coupler > 0:
                    if found_coupler not in self._child_map:
                        self._child_map[found_coupler] = []
                    self._child_map[found_coupler].append(info['slave'])
            else:
                # 其他情况作为根节点
                self._root_slaves.append(info['slave'])

        # 按从站编号排序
        self._root_slaves.sort(key=lambda s: s.index)
        for key in self._child_map:
            self._child_map[key].sort(key=lambda s: s.index)

    @property
    def count(self) -> int:
        """根节点从站数量"""
        return len(self._root_slaves)

    @property
    def root_slaves(self) -> List['Slave']:
        """获取所有根节点从站"""
        return list(self._root_slaves)

    def __len__(self) -> int:
        return len(self._root_slaves)

    def __getitem__(self, key):
        """
        按索引或地址获取从站

        参数:
            key: int 为拓扑索引, str 为地址 ("0x1001" 或 "4097")
        """
        if isinstance(key, int):
            if 0 <= key < len(self._root_slaves):
                return self._root_slaves[key]
            return None
        elif isinstance(key, str):
            return self._get_by_address(key)
        return None

    def _get_by_address(self, address: str) -> Optional['Slave']:
        """通过地址字符串查找从站"""
        if not address:
            return None
        try:
            if address.lower().startswith("0x"):
                addr = int(address, 16)
            else:
                addr = int(address)
        except ValueError:
            return None
        return self._address_map.get(addr)

    def get_children(self, parent: 'Slave') -> List['Slave']:
        """
        获取指定从站的子模块列表

        参数:
            parent: 父从站

        返回:
            子从站列表
        """
        if parent is None:
            return []
        return list(self._child_map.get(parent.index, []))

    def get_child_count(self, parent: 'Slave') -> int:
        """
        获取指定从站的子模块数量

        参数:
            parent: 父从站

        返回:
            子模块数量
        """
        if parent is None:
            return 0
        children = self._child_map.get(parent.index)
        return len(children) if children else 0

    def find_by_vendor_product(self, vendor_id: int,
                               product_code: int) -> List['Slave']:
        """
        按厂商ID和产品码查找从站

        参数:
            vendor_id: 厂商ID
            product_code: 产品代码

        返回:
            匹配的从站列表
        """
        results = []
        for i in range(1, self._master.slave_count + 1):
            slv = self._master[i]
            ident = slv.identity
            if ident and ident.get('vendor_id') == vendor_id and \
               ident.get('product_code') == product_code:
                results.append(slv)
        return results
