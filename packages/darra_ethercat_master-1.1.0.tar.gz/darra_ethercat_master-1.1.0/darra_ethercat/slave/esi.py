# -*- coding: utf-8 -*-
"""
ESI (EtherCAT Slave Information) 文件加载器

提供 ESI XML 文件的加载和解析功能，
从 ESI 文件中提取从站启动参数（SDO 初始化配置）。
"""

import os
import struct
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Tuple


class EsiStartupParam:
    """ESI 启动参数（从 ESI XML 中提取的 SDO 初始化项）"""

    def __init__(self, transition: int, index: int, subindex: int,
                 data: bytes, comment: str = ""):
        """
        初始化启动参数

        参数:
            transition: 状态转换标识 (如 IP=0x01, PS=0x02, SO=0x04 等)
            index: 对象字典索引
            subindex: 子索引
            data: 要写入的数据
            comment: 注释
        """
        self.transition = transition
        self.index = index
        self.subindex = subindex
        self.data = data
        self.comment = comment

    def __repr__(self) -> str:
        return (
            f"EsiStartupParam("
            f"transition=0x{self.transition:02X}, "
            f"index=0x{self.index:04X}:{self.subindex:02X}, "
            f"data={self.data.hex()}, "
            f"comment='{self.comment}')"
        )


class EsiDeviceInfo:
    """ESI 设备信息"""

    def __init__(self):
        self.vendor_id: int = 0
        self.product_code: int = 0
        self.revision_no: int = 0
        self.device_type: str = ""
        self.device_name: str = ""
        self.group_name: str = ""

    def __repr__(self) -> str:
        return (
            f"EsiDeviceInfo("
            f"vendor=0x{self.vendor_id:08X}, "
            f"product=0x{self.product_code:08X}, "
            f"name='{self.device_name}')"
        )


class EsiLoader:
    """
    ESI 文件加载器

    加载 ESI XML 文件并提取启动参数

    用法::

        esi = slave.esi
        if esi.load("device.xml"):
            print(f"设备: {esi.device_info.device_name}")
            for param in esi.startup_params:
                print(f"  {param}")
    """

    # ESI XML 命名空间
    _NS = {'esi': 'http://www.2ics.de/EtherCATDeviceDescription'}

    # 状态转换映射
    TRANSITION_IP = 0x01  # INIT -> PRE_OP
    TRANSITION_PS = 0x02  # PRE_OP -> SAFE_OP
    TRANSITION_SO = 0x04  # SAFE_OP -> OP
    TRANSITION_OS = 0x08  # OP -> SAFE_OP
    TRANSITION_SP = 0x10  # SAFE_OP -> PRE_OP
    TRANSITION_PI = 0x20  # PRE_OP -> INIT

    _TRANSITION_MAP = {
        'IP': TRANSITION_IP,
        'PS': TRANSITION_PS,
        'SO': TRANSITION_SO,
        'OS': TRANSITION_OS,
        'SP': TRANSITION_SP,
        'PI': TRANSITION_PI,
    }

    def __init__(self, slave=None):
        """
        初始化 ESI 加载器

        参数:
            slave: 可选的从站实例引用
        """
        self._slave = slave
        self._is_loaded: bool = False
        self._file_path: Optional[str] = None
        self._device_info: EsiDeviceInfo = EsiDeviceInfo()
        self._startup_params: List[EsiStartupParam] = []
        self._tree: Optional[ET.ElementTree] = None
        self._root: Optional[ET.Element] = None

    @property
    def is_loaded(self) -> bool:
        """ESI 文件是否已加载"""
        return self._is_loaded

    @property
    def file_path(self) -> Optional[str]:
        """已加载的 ESI 文件路径"""
        return self._file_path

    @property
    def device_info(self) -> EsiDeviceInfo:
        """设备信息"""
        return self._device_info

    @property
    def startup_params(self) -> List[EsiStartupParam]:
        """启动参数列表"""
        return list(self._startup_params)

    def load(self, file_path: str) -> bool:
        """
        加载 ESI XML 文件

        参数:
            file_path: ESI 文件路径

        返回:
            加载成功返回 True
        """
        if not file_path:
            return False

        if not os.path.isfile(file_path):
            return False

        try:
            self._tree = ET.parse(file_path)
            self._root = self._tree.getroot()
            self._file_path = file_path

            # 提取设备信息
            self._extract_device_info()

            # 提取启动参数
            self._startup_params = self._extract_startup_params()

            self._is_loaded = True
            return True

        except ET.ParseError:
            self._is_loaded = False
            return False
        except Exception:
            self._is_loaded = False
            return False

    def _find_element(self, path: str) -> Optional[ET.Element]:
        """
        查找 XML 元素，自动处理命名空间

        参数:
            path: 元素路径

        返回:
            找到的元素或 None
        """
        if self._root is None:
            return None

        # 先尝试不带命名空间
        elem = self._root.find(path)
        if elem is not None:
            return elem

        # 尝试带命名空间
        ns_path = '/'.join(
            f"esi:{part}" if not part.startswith('{') else part
            for part in path.split('/')
        )
        return self._root.find(ns_path, self._NS)

    def _find_all(self, parent: ET.Element, path: str) -> list:
        """查找所有匹配元素，自动处理命名空间"""
        results = parent.findall(path)
        if results:
            return results

        ns_path = '/'.join(
            f"esi:{part}" if not part.startswith('{') else part
            for part in path.split('/')
        )
        return parent.findall(ns_path, self._NS)

    def _get_text(self, parent: ET.Element, tag: str, default: str = "") -> str:
        """获取子元素文本内容"""
        elem = parent.find(tag)
        if elem is None:
            elem = parent.find(f"esi:{tag}", self._NS)
        if elem is not None and elem.text:
            return elem.text.strip()
        return default

    def _extract_device_info(self):
        """提取设备信息"""
        if self._root is None:
            return

        info = EsiDeviceInfo()

        # 查找 Vendor ID
        vendor_elem = self._find_element('.//Vendor/Id')
        if vendor_elem is not None and vendor_elem.text:
            info.vendor_id = self._parse_int(vendor_elem.text)

        # 查找设备描述
        descriptions = self._root.findall('.//Device')
        if not descriptions:
            descriptions = self._root.findall('.//esi:Device', self._NS)
        if not descriptions:
            # 尝试 Descriptions/Devices/Device 路径
            descriptions = self._root.findall('.//Descriptions/Devices/Device')
            if not descriptions:
                descriptions = self._root.findall(
                    './/esi:Descriptions/esi:Devices/esi:Device', self._NS)

        if descriptions:
            device = descriptions[0]

            # Type
            type_elem = device.find('Type')
            if type_elem is None:
                type_elem = device.find('esi:Type', self._NS)
            if type_elem is not None:
                info.device_type = type_elem.text.strip() if type_elem.text else ""
                # 提取 ProductCode 和 RevisionNo 属性
                pc = type_elem.get('ProductCode', '')
                if pc:
                    info.product_code = self._parse_int(pc)
                rn = type_elem.get('RevisionNo', '')
                if rn:
                    info.revision_no = self._parse_int(rn)

            # Name
            name_elem = device.find('Name')
            if name_elem is None:
                name_elem = device.find('esi:Name', self._NS)
            if name_elem is not None and name_elem.text:
                info.device_name = name_elem.text.strip()

            # GroupType
            group_elem = device.find('GroupType')
            if group_elem is None:
                group_elem = device.find('esi:GroupType', self._NS)
            if group_elem is not None and group_elem.text:
                info.group_name = group_elem.text.strip()

        self._device_info = info

    def _extract_startup_params(self) -> List[EsiStartupParam]:
        """
        从 ESI 文件提取启动参数（SDO 初始化配置）

        返回:
            启动参数列表
        """
        params = []
        if self._root is None:
            return params

        # 查找所有 InitCmd 元素
        # 路径: //Device/Mailbox/CoE/InitCmd
        init_cmds = self._root.findall('.//InitCmd')
        if not init_cmds:
            init_cmds = self._root.findall('.//esi:InitCmd', self._NS)

        for cmd in init_cmds:
            param = self._parse_init_cmd(cmd)
            if param is not None:
                params.append(param)

        return params

    def _parse_init_cmd(self, cmd: ET.Element) -> Optional[EsiStartupParam]:
        """
        解析单个 InitCmd 元素

        参数:
            cmd: InitCmd XML 元素

        返回:
            启动参数，解析失败返回 None
        """
        try:
            # 状态转换
            transition_str = self._get_text(cmd, 'Transition', 'PS')
            transition = self._TRANSITION_MAP.get(transition_str, self.TRANSITION_PS)

            # 索引
            index_str = self._get_text(cmd, 'Index', '')
            if not index_str:
                return None
            index = self._parse_int(index_str)

            # 子索引
            subindex_str = self._get_text(cmd, 'SubIndex', '0')
            subindex = self._parse_int(subindex_str)

            # 数据
            data_str = self._get_text(cmd, 'Data', '')
            if data_str:
                data = self._parse_hex_data(data_str)
            else:
                data = b''

            # 注释
            comment = self._get_text(cmd, 'Comment', '')

            return EsiStartupParam(transition, index, subindex, data, comment)

        except Exception:
            return None

    @staticmethod
    def _parse_int(text: str) -> int:
        """解析整数字符串，支持十六进制 (0x/0X/#) 和十进制"""
        text = text.strip()
        if text.startswith(('#', '0x', '0X')):
            return int(text.lstrip('#').replace('0x', '').replace('0X', ''), 16)
        return int(text, 0)

    @staticmethod
    def _parse_hex_data(text: str) -> bytes:
        """解析十六进制数据字符串为字节"""
        text = text.strip().replace(' ', '').replace(',', '')
        if text.startswith(('0x', '0X')):
            text = text[2:]
        # 确保偶数长度
        if len(text) % 2 != 0:
            text = '0' + text
        return bytes.fromhex(text)

    def __repr__(self) -> str:
        if self._is_loaded:
            return f"EsiLoader(loaded='{os.path.basename(self._file_path)}', params={len(self._startup_params)})"
        return "EsiLoader(not loaded)"

    def __bool__(self) -> bool:
        """允许在布尔上下文中使用"""
        return self._is_loaded
