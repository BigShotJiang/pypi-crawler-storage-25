# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/EoE.cs
EoE (Ethernet over EtherCAT) 高级功能模块

包含:
- EoEPingResult: Ping 测试结果数据类
- EoEAdvanced: EoE 高级接口 (帧收发、地址过滤、Ping、ARP 缓存)
- EoEPinger: EoE Ping 工具 (ICMP Echo)
- 辅助函数: IPv4/ICMP/以太网帧构建
"""

import asyncio
import struct
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import ctypes

from .core import EoE
from ..utils.dll import EcMbxStatsT
from ..abstractions import IMailboxProtocol, MailboxStatistics


# =============================================================================
# EoE 能力检测 (对齐 C# EoEInstance.IsSupported)
# =============================================================================
# 通过 DLL.GetSlaveMailboxProto 读 SII mbx_proto bit 1 (ECT_MBXPROT_EOE = 0x02).
# DLL 调用失败时保守返回 True (未知能力视为支持).
#
# 注意: EoEAdvanced 子类保留自己的 is_supported(mailbox_protocols) 方法,
#       该方法签名未变, 与基类属性在 MRO 查找时由子类优先.

def _eoe_is_supported(self) -> bool:
    """
    从站是否支持 EoE 邮箱协议 (对齐 C# EoEInstance.IsSupported).

    读取 SII mbx_proto bit 1 (ECT_MBXPROT_EOE = 0x02) 判断支持情况.
    DLL 调用失败时保守返回 True.
    """
    try:
        mbx_proto = self._dll.GetSlaveMailboxProto(self._mi, self._si)
        return (mbx_proto & 0x02) != 0
    except Exception:
        return True


# 在 EoE 基类上挂载 is_supported 属性 (不修改 core.py)
# EoEAdvanced 子类已自定义同名方法, MRO 规则下子类优先, 二者互不干扰.
EoE.is_supported = property(_eoe_is_supported)


# =============================================================================
# IMailboxProtocol 接口实现 (对齐 C# IMailboxProtocol)
# =============================================================================

_EOE_PROTOCOL_TYPE = 0x02  # ECT_MBXT_EOE


def _eoe_protocol_type(self) -> int:
    return _EOE_PROTOCOL_TYPE


def _eoe_protocol_name(self) -> str:
    return "EoE"


def _eoe_statistics(self) -> MailboxStatistics:
    """读取 EoE 邮箱统计快照."""
    try:
        stats = EcMbxStatsT()
        rc = self._dll.ecx_mbx_get_stats_by_master(
            self._mi, self._si, _EOE_PROTOCOL_TYPE, ctypes.byref(stats)
        )
        if rc == 1:
            avg = (stats.total_latency_us / stats.total_received
                   if stats.total_received > 0 else 0.0)
            t = None
            if stats.last_error_time_us > 0:
                from datetime import datetime, timezone
                t = datetime.fromtimestamp(
                    stats.last_error_time_us / 1_000_000, tz=timezone.utc
                )
            return MailboxStatistics(
                total_sent=stats.total_sent,
                total_received=stats.total_received,
                total_timeout=stats.total_timeout,
                total_mailbox_error=stats.total_mbx_error,
                total_protocol_error=stats.total_proto_error,
                total_cancelled=stats.total_cancelled,
                last_error_code=stats.last_error_code,
                last_error_time=t,
                average_latency_us=avg,
            )
    except Exception:
        pass
    return MailboxStatistics.empty()


def _eoe_reset_statistics(self) -> None:
    """重置 EoE 邮箱统计."""
    try:
        self._dll.ecx_mbx_reset_stats_by_master(
            self._mi, self._si, _EOE_PROTOCOL_TYPE
        )
    except Exception:
        pass


EoE.protocol_type = property(_eoe_protocol_type)
EoE.protocol_name = property(_eoe_protocol_name)
EoE.statistics = property(_eoe_statistics)
EoE.reset_statistics = _eoe_reset_statistics

IMailboxProtocol.register(EoE)


# =============================================================================
# 异步支持 (asyncio) — 对齐 C# EoEInstance.*Async
# =============================================================================
# EoE 帧收发是"流式"IO, 通常延迟 10-500ms (Ping), 批量 IP 配置可能秒级。
# 使用独立线程池。

_eoe_async_executor: Optional[ThreadPoolExecutor] = None
_eoe_executor_lock = threading.Lock()


def _get_eoe_executor() -> ThreadPoolExecutor:
    """懒创建 EoE 协议专用线程池"""
    global _eoe_async_executor
    if _eoe_async_executor is None:
        with _eoe_executor_lock:
            if _eoe_async_executor is None:
                _eoe_async_executor = ThreadPoolExecutor(
                    max_workers=4, thread_name_prefix="darra-eoe-async"
                )
    return _eoe_async_executor


def shutdown_eoe_async_executor(wait: bool = True) -> None:
    """关闭 EoE 异步线程池"""
    global _eoe_async_executor
    with _eoe_executor_lock:
        if _eoe_async_executor is not None:
            _eoe_async_executor.shutdown(wait=wait)
            _eoe_async_executor = None


async def _run_eoe_async(func, *args, timeout_ms: Optional[int] = None):
    """通用 EoE 异步执行辅助"""
    loop = asyncio.get_event_loop()
    fut = loop.run_in_executor(_get_eoe_executor(), func, *args)
    if timeout_ms and timeout_ms > 0:
        return await asyncio.wait_for(fut, timeout=timeout_ms / 1000.0)
    return await fut


def _ip4_checksum(data: bytes) -> int:
    """计算 IPv4/ICMP 校验和 (RFC 1071)"""
    if len(data) % 2:
        data = data + b'\x00'
    total = 0
    for i in range(0, len(data), 2):
        word = (data[i] << 8) + data[i + 1]
        total += word
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return ~total & 0xFFFF


def _build_icmp_echo(seq: int, payload: bytes = b'EtherCAT') -> bytes:
    """构造 ICMP Echo Request"""
    icmp_type = 8
    icmp_code = 0
    identifier = 0xEC47
    header = struct.pack('!BBHHH', icmp_type, icmp_code, 0, identifier, seq)
    raw = header + payload
    checksum = _ip4_checksum(raw)
    return struct.pack('!BBHHH', icmp_type, icmp_code, checksum, identifier, seq) + payload


def _build_ip4_packet(src_ip: int, dst_ip: int, payload: bytes,
                      protocol: int = 1, ttl: int = 64) -> bytes:
    """构造 IPv4 数据包"""
    version_ihl = 0x45
    tos = 0
    total_length = 20 + len(payload)
    ip_id = 0x0001
    flags_offset = 0x4000
    header = struct.pack('!BBHHHBBHII',
                         version_ihl, tos, total_length, ip_id,
                         flags_offset, ttl, protocol, 0, src_ip, dst_ip)
    checksum = _ip4_checksum(header)
    header = struct.pack('!BBHHHBBHII',
                         version_ihl, tos, total_length, ip_id,
                         flags_offset, ttl, protocol, checksum, src_ip, dst_ip)
    return header + payload


def _build_eth_frame(dst_mac: bytes, src_mac: bytes, payload: bytes,
                     ethertype: int = 0x0800) -> bytes:
    """构造以太网帧"""
    return dst_mac + src_mac + struct.pack('!H', ethertype) + payload


def _ip_to_int(ip_str: str) -> int:
    """将点分十进制 IP 转换为 uint32"""
    parts = [int(p) for p in ip_str.split('.')]
    return (parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]


def _int_to_ip(ip_int: int) -> str:
    """将 uint32 转换为点分十进制 IP"""
    return f"{(ip_int >> 24) & 0xFF}.{(ip_int >> 16) & 0xFF}.{(ip_int >> 8) & 0xFF}.{ip_int & 0xFF}"


@dataclass
class EoEPingResult:
    """
    EoE Ping 测试结果
    对应 C# EoEPingResult 类
    """
    success: bool = False
    """Ping 是否成功"""
    round_trip_time_ms: float = 0.0
    """往返时间（毫秒）"""
    target_address: str = ""
    """目标地址"""
    ttl: int = 0
    """生存时间"""
    error_message: str = ""
    """错误消息（失败时）"""

    def __str__(self) -> str:
        if self.success:
            return (f"来自 {self.target_address} 的回复: "
                    f"时间={self.round_trip_time_ms:.2f}ms TTL={self.ttl}")
        return f"Ping {self.target_address} 失败: {self.error_message}"


class EoEAdvanced(EoE):
    """
    EoE 高级接口: 在基础 EoE 之上提供帧收发、地址过滤管理、
    ICMP Ping、ARP 缓存等完整功能。

    对应 C# EoEInstance 类的完整功能集。
    """

    # 默认超时时间（毫秒）
    DEFAULT_TIMEOUT_MS = 500
    # 最大地址过滤器数量
    MAX_ADDRESS_FILTERS = 16
    # MAC 地址长度
    MAC_ADDRESS_LENGTH = 6

    _MASTER_MAC = bytes([0x02, 0x00, 0xDA, 0xEE, 0xCA, 0x7E])
    _MASTER_IP = _ip_to_int('192.168.100.1')

    def __init__(self, dll, master_index: int, slave_index: int,
                 port: int = 0, timeout: int = 5000):
        """
        初始化 EoE 高级接口

        参数:
            dll: DarraCoreDLL 实例
            master_index: 主站索引
            slave_index: 从站索引
            port: EoE 端口号
            timeout: 默认超时时间（微秒）
        """
        super().__init__(dll, master_index, slave_index, port, timeout)
        self._arp_cache: Dict[int, bytes] = {}
        self._seq = 0

    # ========== 帧收发 ==========

    def send_frame_data(self, frame_data: bytes,
                        timeout_ms: int = DEFAULT_TIMEOUT_MS) -> bool:
        """
        通过 EoE 发送以太网帧
        对应 C# SendFrame 方法

        参数:
            frame_data: 以太网帧数据
            timeout_ms: 超时时间（毫秒）

        返回:
            发送是否成功
        """
        if not frame_data:
            raise ValueError("帧数据不能为空")
        # 临时保存并恢复超时
        old_timeout = self._timeout
        self._timeout = timeout_ms * 1000
        try:
            return self.send_frame(frame_data)
        finally:
            self._timeout = old_timeout

    def receive_frame_data(self,
                           timeout_ms: int = DEFAULT_TIMEOUT_MS) -> Optional[bytes]:
        """
        通过 EoE 接收以太网帧
        对应 C# ReceiveFrame 方法

        参数:
            timeout_ms: 超时时间（毫秒）

        返回:
            接收到的帧数据，失败返回 None
        """
        old_timeout = self._timeout
        self._timeout = timeout_ms * 1000
        try:
            return self.receive_frame()
        finally:
            self._timeout = old_timeout

    def send_frame_with_timestamp(self, frame_data: bytes, timestamp: int,
                                  timeout_ms: int = DEFAULT_TIMEOUT_MS) -> bool:
        """
        通过 EoE 发送以太网帧（附加时间戳）
        对应 C# SendFrameWithTimestamp 方法
        在帧末尾附加 8 字节时间戳 (ETG.1000.6 \u00a75.7 TimeAppended)

        参数:
            frame_data: 以太网帧数据
            timestamp: 要附加的时间戳（DC 时间，纳秒）
            timeout_ms: 超时时间（毫秒）

        返回:
            发送是否成功
        """
        if not frame_data:
            raise ValueError("帧数据不能为空")
        # 在帧末尾附加 8 字节时间戳
        frame_with_ts = frame_data + struct.pack('<Q', timestamp)
        return self.send_frame_data(frame_with_ts, timeout_ms)

    # ========== ICMP Ping ==========

    def ping(self, target_ip: str, timeout_ms: int = 5000,
             ttl: int = 64) -> EoEPingResult:
        """
        通过 EoE 发送 ICMP Ping 并等待响应
        对应 C# EoEInstance.Ping 方法

        参数:
            target_ip: 目标 IP 地址（点分十进制）
            timeout_ms: 超时时间（毫秒）
            ttl: 生存时间

        返回:
            EoEPingResult 结果对象
        """
        try:
            dst_ip_int = _ip_to_int(target_ip)
            self._seq = (self._seq + 1) & 0xFFFF
            dst_mac = self._arp_cache.get(dst_ip_int, bytes([0xFF] * 6))

            # 获取本机配置
            config = self.get_full_param()
            if config is not None:
                src_ip_int = config[0]
                src_mac = config[3]
            else:
                src_ip_int = self._MASTER_IP
                src_mac = self._MASTER_MAC

            # 构建 ICMP Echo Request
            icmp_pkt = _build_icmp_echo(self._seq, b'DarraECat')
            ip_pkt = _build_ip4_packet(src_ip_int, dst_ip_int, icmp_pkt,
                                       protocol=1, ttl=ttl)
            eth_frame = _build_eth_frame(dst_mac, src_mac, ip_pkt)

            # 发送
            t_send = time.perf_counter()
            if not self.send_frame_data(eth_frame, timeout_ms):
                return EoEPingResult(success=False,
                                     target_address=target_ip,
                                     error_message="发送 Ping 请求失败")

            # 等待回复
            deadline = t_send + timeout_ms / 1000.0
            while time.perf_counter() < deadline:
                remaining_ms = max(1, int((deadline - time.perf_counter()) * 1000))
                frame = self.receive_frame_data(min(remaining_ms, 100))
                if frame is None:
                    time.sleep(0.0001)
                    continue

                # 解析响应
                if len(frame) < 34:
                    continue
                ethertype = struct.unpack('!H', frame[12:14])[0]
                if ethertype != 0x0800:
                    continue
                ip_header = frame[14:34]
                protocol = ip_header[9]
                src_ip = struct.unpack('!I', ip_header[12:16])[0]
                if protocol != 1 or src_ip != dst_ip_int:
                    continue
                ihl = (ip_header[0] & 0x0F) * 4
                icmp_offset = 14 + ihl
                if len(frame) < icmp_offset + 8:
                    continue
                icmp_type = frame[icmp_offset]
                icmp_seq = struct.unpack('!H',
                                         frame[icmp_offset + 6:icmp_offset + 8])[0]
                if icmp_type == 0 and icmp_seq == self._seq:
                    rtt = (time.perf_counter() - t_send) * 1000.0
                    # 缓存源 MAC
                    if len(frame) >= 12:
                        self._arp_cache[dst_ip_int] = bytes(frame[6:12])
                    return EoEPingResult(
                        success=True,
                        round_trip_time_ms=rtt,
                        target_address=target_ip,
                        ttl=ttl,
                    )

            return EoEPingResult(success=False,
                                 target_address=target_ip,
                                 error_message="超时，未收到响应")
        except Exception as ex:
            return EoEPingResult(success=False,
                                 target_address=target_ip,
                                 error_message=f"Ping 失败: {ex}")

    # ========== 地址过滤器管理 ==========

    def set_address_filter(self, filter_count: int, mac_filters: List[bytes],
                           timeout_ms: int = DEFAULT_TIMEOUT_MS) -> bool:
        """
        设置 MAC 地址过滤器列表
        对应 C# SetAddressFilters 方法

        参数:
            filter_count: 过滤器数量
            mac_filters: MAC 地址列表 (每个 6 字节)
            timeout_ms: 超时时间（毫秒）

        返回:
            设置是否成功
        """
        if filter_count > self.MAX_ADDRESS_FILTERS:
            raise ValueError(f"过滤器数量超过最大值 ({self.MAX_ADDRESS_FILTERS})")
        filters_to_set = mac_filters[:filter_count] if mac_filters else []
        old_timeout = self._timeout
        self._timeout = timeout_ms * 1000
        try:
            return self.set_address_filters(filters_to_set)
        finally:
            self._timeout = old_timeout

    def get_address_filter(self, max_filters: int = MAX_ADDRESS_FILTERS,
                           timeout_ms: int = DEFAULT_TIMEOUT_MS) -> Optional[List[bytes]]:
        """
        获取 MAC 地址过滤器列表
        对应 C# GetAddressFilters 方法

        参数:
            max_filters: 最大过滤器数量
            timeout_ms: 超时时间（毫秒）

        返回:
            MAC 地址列表，失败返回 None
        """
        old_timeout = self._timeout
        self._timeout = timeout_ms * 1000
        try:
            return self.get_address_filters(max_filters)
        finally:
            self._timeout = old_timeout

    def add_address_filter(self, mac_address: bytes,
                           timeout_ms: int = DEFAULT_TIMEOUT_MS) -> bool:
        """
        添加单个 MAC 地址过滤器
        对应 C# AddAddressFilter 方法

        参数:
            mac_address: MAC 地址 (6 字节)
            timeout_ms: 超时时间（毫秒）

        返回:
            添加是否成功
        """
        if len(mac_address) != self.MAC_ADDRESS_LENGTH:
            raise ValueError("MAC 地址必须为 6 字节")
        current = self.get_address_filter(self.MAX_ADDRESS_FILTERS, timeout_ms)
        if current is None:
            current = []
        if len(current) >= self.MAX_ADDRESS_FILTERS:
            return False
        # 检查是否已存在
        if mac_address not in current:
            current.append(mac_address)
        return self.set_address_filter(len(current), current, timeout_ms)

    def remove_address_filter(self, mac_address: bytes,
                              timeout_ms: int = DEFAULT_TIMEOUT_MS) -> bool:
        """
        移除单个 MAC 地址过滤器
        对应 C# RemoveAddressFilter 方法

        参数:
            mac_address: 要移除的 MAC 地址 (6 字节)
            timeout_ms: 超时时间（毫秒）

        返回:
            移除是否成功
        """
        if len(mac_address) != self.MAC_ADDRESS_LENGTH:
            raise ValueError("MAC 地址必须为 6 字节")
        current = self.get_address_filter(self.MAX_ADDRESS_FILTERS, timeout_ms)
        if current is None:
            current = []
        current = [f for f in current if f != mac_address]
        return self.set_address_filter(len(current), current, timeout_ms)

    def clear_address_filters(self,
                              timeout_ms: int = DEFAULT_TIMEOUT_MS) -> bool:
        """
        清空所有地址过滤器
        对应 C# ClearAddressFilters 方法

        参数:
            timeout_ms: 超时时间（毫秒）

        返回:
            清空是否成功
        """
        return self.set_address_filter(0, [], timeout_ms)

    # ========== ARP 缓存 ==========

    def set_arp_entry(self, ip: str, mac: bytes) -> None:
        """
        设置 ARP 缓存条目
        对应 C# SetArpEntry 方法

        参数:
            ip: IP 地址字符串 (如 "192.168.1.1")
            mac: MAC 地址字节 (6 字节)
        """
        if len(mac) != self.MAC_ADDRESS_LENGTH:
            raise ValueError("MAC 地址必须为 6 字节")
        self._arp_cache[_ip_to_int(ip)] = bytes(mac)

    def clear_arp_cache(self) -> None:
        """
        清除 ARP 缓存
        对应 C# ClearArpCache 方法
        """
        self._arp_cache.clear()

    @property
    def arp_cache(self) -> Dict[str, str]:
        """返回 ARP 缓存 (IP -> MAC 字符串映射)"""
        return {
            _int_to_ip(ip): ':'.join(f'{b:02X}' for b in mac)
            for ip, mac in self._arp_cache.items()
        }

    # ========== 能力检测 ==========

    def is_supported(self, mailbox_protocols: int = 0) -> bool:
        """
        检查从站是否支持 EoE (邮箱协议 bit 5)
        对应 C# 检查 EcEoEDetails

        参数:
            mailbox_protocols: 从站邮箱协议位域 (从 ESI 或 SII 读取)
                              bit 5 (0x20) 表示支持 EoE

        返回:
            True 表示支持 EoE
        """
        return bool(mailbox_protocols & 0x20)

    # ========== 异步接收 Hook (FFI 已绑定 EOESetReceiveHook / EOEClearReceiveHook) ==========

    # native delegate 必须用类级 dict 持有, 防止 GC 把 ctypes 函数指针回收掉
    # key: master_index, value: (native_callback_ref, user_callback)
    _eoe_hook_refs: Dict[int, tuple] = {}

    def set_receive_hook(self, callback) -> bool:
        """
        注册 EoE 异步接收 Hook (对齐 C# EoEInstance.FrameReceived 事件).

        callback 签名: callback(slave_index: int, frame: bytes) -> None
        当 PDO 主循环收到 EoE Fragment Data 帧时回调.

        每个 master 共享一个 native 回调; 重复调用会覆盖前一次注册.
        """
        from ..utils.dll import EOEFrameCallbackType

        fn = getattr(self._dll, "EOESetReceiveHook", None)
        if fn is None:
            return False

        def _trampoline(master_index, slave, data_ptr, frame_size):
            try:
                if data_ptr and frame_size > 0:
                    buf = (ctypes.c_ubyte * frame_size).from_address(data_ptr)
                    frame = bytes(buf)
                else:
                    frame = b""
                callback(int(slave), frame)
            except Exception:
                # 回调跑在 DLL 主循环线程, 异常必须吞掉避免崩溃
                pass

        native_cb = EOEFrameCallbackType(_trampoline)
        # 持有引用, 否则 GC 会把回调函数指针释放
        EoEAdvanced._eoe_hook_refs[self._mi] = (native_cb, callback)
        try:
            return bool(fn(self._mi, native_cb))
        except (OSError, AttributeError, NotImplementedError):
            EoEAdvanced._eoe_hook_refs.pop(self._mi, None)
            return False

    def clear_receive_hook(self) -> bool:
        """清除 EoE 异步接收 Hook."""
        fn = getattr(self._dll, "EOEClearReceiveHook", None)
        if fn is None:
            EoEAdvanced._eoe_hook_refs.pop(self._mi, None)
            return False
        try:
            ok = bool(fn(self._mi))
        except (OSError, AttributeError, NotImplementedError):
            ok = False
        EoEAdvanced._eoe_hook_refs.pop(self._mi, None)
        return ok

    # ========== 异步接口 (对齐 C# EoEInstance *Async) ==========

    async def send_frame_async(self, frame_data: bytes,
                               timeout_ms: int = DEFAULT_TIMEOUT_MS
                               ) -> bool:
        """异步发送以太网帧 (对齐 C# SendFrameAsync)"""
        return await _run_eoe_async(
            self.send_frame_data, frame_data, timeout_ms,
            timeout_ms=timeout_ms,
        )

    async def receive_frame_async(self,
                                  timeout_ms: int = DEFAULT_TIMEOUT_MS
                                  ) -> Optional[bytes]:
        """异步接收以太网帧 (对齐 C# ReceiveFrameAsync)"""
        return await _run_eoe_async(
            self.receive_frame_data, timeout_ms,
            timeout_ms=timeout_ms + 100,  # 给 DLL 100ms 余量
        )

    async def ping_async(self, target_ip: str, timeout_ms: int = 5000,
                         ttl: int = 64) -> EoEPingResult:
        """
        异步 Ping (对齐 C# EoEInstance.PingAsync)

        注意: 底层 ping() 包含循环接收帧的轮询逻辑,
        asyncio 超时可让 await 返回, 但后台线程会跑完一次 ping 循环。
        """
        return await _run_eoe_async(
            self.ping, target_ip, timeout_ms, ttl,
            timeout_ms=timeout_ms + 500,
        )

    async def set_address_filter_async(self, filter_count: int,
                                       mac_filters: List[bytes],
                                       timeout_ms: int = DEFAULT_TIMEOUT_MS
                                       ) -> bool:
        """异步设置 MAC 地址过滤器 (对齐 C# SetAddressFiltersAsync)"""
        return await _run_eoe_async(
            self.set_address_filter, filter_count, mac_filters, timeout_ms,
            timeout_ms=timeout_ms + 100,
        )

    async def get_address_filter_async(self,
                                       max_filters: int = MAX_ADDRESS_FILTERS,
                                       timeout_ms: int = DEFAULT_TIMEOUT_MS
                                       ) -> Optional[List[bytes]]:
        """异步获取 MAC 地址过滤器列表 (对齐 C# GetAddressFiltersAsync)"""
        return await _run_eoe_async(
            self.get_address_filter, max_filters, timeout_ms,
            timeout_ms=timeout_ms + 100,
        )

    async def add_address_filter_async(self, mac_address: bytes,
                                       timeout_ms: int = DEFAULT_TIMEOUT_MS
                                       ) -> bool:
        """异步添加 MAC 地址过滤器"""
        return await _run_eoe_async(
            self.add_address_filter, mac_address, timeout_ms,
            timeout_ms=timeout_ms * 2 + 200,  # 包含 get + set 两步
        )

    async def remove_address_filter_async(self, mac_address: bytes,
                                          timeout_ms: int = DEFAULT_TIMEOUT_MS
                                          ) -> bool:
        """异步移除 MAC 地址过滤器"""
        return await _run_eoe_async(
            self.remove_address_filter, mac_address, timeout_ms,
            timeout_ms=timeout_ms * 2 + 200,
        )

    def __repr__(self) -> str:
        return (f"EoEAdvanced(master={self._mi}, slave={self._si}, "
                f"arp_entries={len(self._arp_cache)})")


class EoEPinger:
    """
    EoE Ping 工具

    通过 EoE 向从站发送 ICMP Echo Request 并测量 RTT。
    """

    _MASTER_MAC = bytes([0x02, 0x00, 0xDA, 0xEE, 0xCA, 0x7E])
    _MASTER_IP = _ip_to_int('192.168.100.1')

    def __init__(self, eoe: EoE, local_ip: str = '192.168.100.1'):
        self._eoe = eoe
        self._local_ip = _ip_to_int(local_ip)
        self._seq = 0
        self._arp_cache: Dict[int, bytes] = {}

    def ping(self, target_ip: str, timeout_ms: int = 1000,
             payload: bytes = b'DarraECat') -> Optional[float]:
        """发送 ICMP Echo 并等待回复, 返回 RTT (毫秒)"""
        dst_ip_int = _ip_to_int(target_ip)
        self._seq = (self._seq + 1) & 0xFFFF
        dst_mac = self._arp_cache.get(dst_ip_int, bytes([0xFF] * 6))
        icmp_pkt = _build_icmp_echo(self._seq, payload)
        ip_pkt = _build_ip4_packet(self._local_ip, dst_ip_int, icmp_pkt)
        eth_frame = _build_eth_frame(dst_mac, self._MASTER_MAC, ip_pkt)

        t_send = time.perf_counter()
        if not self._eoe.send_frame(eth_frame):
            return None

        deadline = t_send + timeout_ms / 1000.0
        while time.perf_counter() < deadline:
            frame = self._eoe.receive_frame()
            if frame is None:
                time.sleep(0.0001)
                continue
            rtt = self._parse_icmp_reply(frame, dst_ip_int, self._seq)
            if rtt is not None:
                t_recv = time.perf_counter()
                if len(frame) >= 12:
                    self._arp_cache[dst_ip_int] = bytes(frame[6:12])
                return (t_recv - t_send) * 1000.0

        return None

    def _parse_icmp_reply(self, frame: bytes, expected_src_ip: int,
                          expected_seq: int) -> Optional[float]:
        """解析以太网帧, 检查是否为 ICMP Echo Reply"""
        if len(frame) < 34:
            return None
        ethertype = struct.unpack('!H', frame[12:14])[0]
        if ethertype != 0x0800:
            return None
        ip_header = frame[14:34]
        protocol = ip_header[9]
        src_ip = struct.unpack('!I', ip_header[12:16])[0]
        if protocol != 1 or src_ip != expected_src_ip:
            return None
        ihl = (ip_header[0] & 0x0F) * 4
        icmp_offset = 14 + ihl
        if len(frame) < icmp_offset + 8:
            return None
        icmp_type = frame[icmp_offset]
        icmp_seq = struct.unpack('!H', frame[icmp_offset + 6: icmp_offset + 8])[0]
        if icmp_type != 0 or icmp_seq != expected_seq:
            return None
        return 0.0

    def update_arp_cache(self, ip: str, mac: bytes) -> None:
        """手动更新 ARP 缓存"""
        if len(mac) != 6:
            raise ValueError("MAC 地址必须为 6 字节")
        self._arp_cache[_ip_to_int(ip)] = bytes(mac)

    def clear_arp_cache(self) -> None:
        """清除 ARP 缓存"""
        self._arp_cache.clear()

    @property
    def arp_cache(self) -> Dict[str, str]:
        """返回 ARP 缓存"""
        return {
            _int_to_ip(ip): ':'.join(f'{b:02X}' for b in mac)
            for ip, mac in self._arp_cache.items()
        }

    def set_arp_entry(self, ip: str, mac: bytes) -> None:
        """
        设置 ARP 表条目
        对应 C# SetArpEntry 方法

        参数:
            ip:  IP 地址字符串 (如 "192.168.1.1")
            mac: MAC 地址字节 (6 字节)
        """
        if len(mac) != 6:
            raise ValueError("MAC 地址必须为 6 字节")
        parts = ip.split('.')
        if len(parts) != 4:
            raise ValueError("无效的 IP 地址格式")
        ip_int = 0
        for p in parts:
            ip_int = (ip_int << 8) | int(p)
        self._arp_cache[ip_int] = mac

    async def ping_async(self, target_ip: str, timeout_ms: int = 1000,
                         payload: bytes = b'DarraECat') -> Optional[float]:
        """
        异步 ICMP Ping (对齐 C# EoEInstance.PingAsync)

        返回 RTT (毫秒), 超时或错误返回 None。
        """
        return await _run_eoe_async(
            self.ping, target_ip, timeout_ms, payload,
            timeout_ms=timeout_ms + 500,
        )

    def __repr__(self) -> str:
        return f"EoEPinger(local_ip={_int_to_ip(self._local_ip)}, arp_entries={len(self._arp_cache)})"
