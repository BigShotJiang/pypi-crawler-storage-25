# -*- coding: utf-8 -*-
"""
从站诊断信息
对应 C# SlaveStats.cs
提供从站级 DC 诊断和端口错误统计
"""

from ctypes import c_int, c_bool, c_uint, c_ubyte, c_ushort, byref, POINTER
from dataclasses import dataclass, field
from typing import Optional, List

from ..utils.dll import DarraCoreDLL


# ===================== ESC 端口错误计数器 =====================

@dataclass
class EscPortErrors:
    """
    ESC 端口错误计数器 (ETG.1000 5.3, 寄存器 0x0300-0x0313)
    包含各端口的 RX 错误、无效帧、链路丢失计数
    """
    rx_error: List[int] = field(default_factory=lambda: [0, 0, 0, 0])
    """各端口 RX 错误计数 [Port0..Port3]"""
    invalid_frame: List[int] = field(default_factory=lambda: [0, 0, 0, 0])
    """各端口无效帧计数 [Port0..Port3]"""
    lost_link: List[int] = field(default_factory=lambda: [0, 0, 0, 0])
    """各端口链路丢失计数 [Port0..Port3]"""

    @property
    def has_errors(self) -> bool:
        """是否存在任何错误"""
        return (any(v > 0 for v in self.rx_error) or
                any(v > 0 for v in self.invalid_frame) or
                any(v > 0 for v in self.lost_link))

    def __str__(self) -> str:
        return (f"RX错误={self.rx_error}, "
                f"无效帧={self.invalid_frame}, "
                f"链路丢失={self.lost_link}")


# ===================== 同步窗口状态 =====================

@dataclass
class SyncWindowStatus:
    """
    DC 同步窗口状态 (ETG.1500 5.13.3)
    """
    diff_ns: int = 0
    """当前时间差 (纳秒)"""
    max_diff_ns: int = 0
    """最大时间差 (纳秒)"""
    min_diff_ns: int = 0
    """最小时间差 (纳秒)"""
    in_sync: bool = False
    """是否在同步窗口内"""
    out_of_sync_count: int = 0
    """超出同步窗口次数"""

    def __str__(self) -> str:
        return (f"Diff={self.diff_ns}ns, InSync={self.in_sync}, "
                f"Max={self.max_diff_ns}ns, Min={self.min_diff_ns}ns, "
                f"OutOfSync={self.out_of_sync_count}")


# ===================== 从站 DC 诊断 =====================

class SlaveDCDiagnostics:
    """
    从站 DC 诊断信息
    通过 slave.diagnostics.dc 访问
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int,
                 has_dc_fn):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        self._has_dc = has_dc_fn

    @property
    def is_in_sync(self) -> bool:
        """是否在同步窗口内"""
        if not self._has_dc():
            return False
        try:
            diff = c_int(0)
            max_d = c_int(0)
            min_d = c_int(0)
            in_sync = c_int(0)  # Windows BOOL 是 4 字节, 不能用 c_bool(1字节)
            count = c_uint(0)
            ok = self._dll.GetSlaveSyncWindowStatus(
                self._mi, self._si,
                byref(diff), byref(max_d), byref(min_d),
                byref(in_sync), byref(count))
            return bool(ok) and bool(in_sync.value)
        except Exception:
            return False

    @property
    def sync_time_difference(self) -> int:
        """当前时间差 (纳秒) - 0x092C System Time Difference 寄存器"""
        if not self._has_dc():
            return 0
        try:
            diff = c_int(0)
            max_d = c_int(0)
            min_d = c_int(0)
            in_sync = c_int(0)  # Windows BOOL 是 4 字节, 不能用 c_bool(1字节)
            count = c_uint(0)
            ok = self._dll.GetSlaveSyncWindowStatus(
                self._mi, self._si,
                byref(diff), byref(max_d), byref(min_d),
                byref(in_sync), byref(count))
            return diff.value if ok else 0
        except Exception:
            return 0


# ===================== 从站诊断 =====================

class SlaveDiagnostics:
    """
    从站诊断信息访问类
    通过 slave.diagnostics 属性获取
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int,
                 has_dc_fn, slave_ref):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        self._has_dc = has_dc_fn
        self._slave = slave_ref
        self._dc: Optional[SlaveDCDiagnostics] = None

    @property
    def dc(self) -> SlaveDCDiagnostics:
        """DC 同步诊断"""
        if self._dc is None:
            self._dc = SlaveDCDiagnostics(
                self._dll, self._mi, self._si, self._has_dc)
        return self._dc

    def read_port_errors(self) -> Optional[EscPortErrors]:
        """
        读取 ESC 端口错误计数器 (寄存器 0x0300-0x0313, ETG.1000 5.3)
        实时读取从站 ESC 寄存器，返回各端口的 RX 错误、无效帧、链路丢失计数

        返回:
            端口错误计数器，读取失败返回 None
        """
        rx_err = (c_ubyte * 4)()
        inv_frm = (c_ubyte * 4)()
        lost_lnk = (c_ubyte * 4)()

        try:
            ok = self._dll.ReadSlavePortErrorCounters(
                self._mi, self._si,
                rx_err, inv_frm, lost_lnk)
            if ok:
                return EscPortErrors(
                    rx_error=list(rx_err),
                    invalid_frame=list(inv_frm),
                    lost_link=list(lost_lnk),
                )
        except Exception:
            pass
        return None

    @property
    def redundancy_activated(self) -> bool:
        """冗余被激活（主线路或冗余线路存在断线）"""
        # 通过从站属性获取
        return getattr(self._slave, '_redundancy_activated', False)

    @property
    def primary_link_broken(self) -> bool:
        """主线路断路"""
        return getattr(self._slave, '_primary_link_broken', False)

    @property
    def secondary_link_broken(self) -> bool:
        """冗余线路断路"""
        return getattr(self._slave, '_secondary_link_broken', False)
