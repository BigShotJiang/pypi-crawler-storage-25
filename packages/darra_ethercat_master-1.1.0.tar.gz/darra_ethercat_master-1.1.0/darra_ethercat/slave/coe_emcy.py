# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/CoE_Emcy.cs
CoE EMCY (紧急消息) 历史记录管理

包含:
- EmergencyMessage: 紧急消息数据结构
- CoEEmcyRecorder: EMCY 历史记录器
"""

import threading
from datetime import datetime
from typing import List, Optional


class EmergencyMessage:
    """
    紧急消息数据结构 (CiA 301)
    对应 C# EmergencyMessage
    """

    def __init__(self, error_code: int = 0, error_register: int = 0,
                 data: bytes = b'', slave_index: int = 0):
        """
        初始化紧急消息

        参数:
            error_code:     紧急错误代码 (CiA 301 Table 24)
            error_register: 错误寄存器 (对象 0x1001)
            data:           厂商特定数据 (5 字节)
            slave_index:    来源从站编号
        """
        self.error_code = error_code
        self.error_register = error_register
        self.data = data
        self.slave_index = slave_index
        self.timestamp = datetime.now()

    def get_error_description(self) -> str:
        """获取错误代码的文本描述 (CiA 301 标准错误分类)"""
        category = self.error_code >> 8
        descriptions = {
            0x00: "已复位/无错误",
            0x10: "通用错误",
            0x20: "电流错误",
            0x21: "设备输入侧电流错误",
            0x22: "设备内部电流错误",
            0x23: "设备输出侧电流错误",
            0x30: "电压错误",
            0x31: "主电源电压错误",
            0x32: "设备内部电压错误",
            0x33: "输出电压错误",
            0x40: "温度错误",
            0x41: "环境温度错误",
            0x42: "设备温度错误",
            0x50: "设备硬件错误",
            0x60: "设备软件错误",
            0x61: "内部软件错误",
            0x62: "用户软件错误",
            0x63: "数据集错误",
            0x70: "附加模块错误",
            0x80: "监控错误",
            0x81: "通信错误",
            0x82: "协议错误",
            0x90: "外部错误",
            0xF0: "附加功能错误",
            0xFF: "设备特定错误",
        }
        return descriptions.get(category, f"未知错误类别 (0x{self.error_code:04X})")

    def __repr__(self) -> str:
        return (f"EMCY[从站{self.slave_index}] 0x{self.error_code:04X} "
                f"({self.get_error_description()}) "
                f"寄存器=0x{self.error_register:02X} "
                f"时间={self.timestamp:%H:%M:%S.%f}")


class CoEEmcyRecorder:
    """
    CoE EMCY 紧急消息历史记录器
    对应 C# CoEInstance 的 EMCY 历史记录扩展 (partial class)

    最多保留最近 256 条紧急消息记录。
    """

    MAX_HISTORY_SIZE = 256

    def __init__(self, slave_index: int):
        """
        初始化 EMCY 记录器

        参数:
            slave_index: 从站索引
        """
        self._slave_index = slave_index
        self._history: List[EmergencyMessage] = []
        self._lock = threading.Lock()

    def get_emergency_history(self) -> List[EmergencyMessage]:
        """获取 EMCY 历史记录 (副本)"""
        with self._lock:
            return list(self._history)

    def clear_emergency_history(self) -> None:
        """清除 EMCY 历史记录"""
        with self._lock:
            self._history.clear()

    def record_emergency(self, error_code: int, error_reg: int,
                         b1: int, w1: int, w2: int) -> None:
        """
        记录一条 EMCY 紧急消息 (由事件系统内部调用)

        参数:
            error_code: 紧急错误代码
            error_reg:  错误寄存器
            b1:         厂商特定字节
            w1:         厂商特定字 1
            w2:         厂商特定字 2
        """
        data = bytes([b1, w1 & 0xFF, (w1 >> 8) & 0xFF,
                      w2 & 0xFF, (w2 >> 8) & 0xFF])
        msg = EmergencyMessage(
            error_code=error_code,
            error_register=error_reg & 0xFF,
            data=data,
            slave_index=self._slave_index
        )
        with self._lock:
            if len(self._history) >= self.MAX_HISTORY_SIZE:
                self._history.pop(0)
            self._history.append(msg)

    @property
    def count(self) -> int:
        """当前记录数量"""
        with self._lock:
            return len(self._history)

    def __repr__(self) -> str:
        return f"CoEEmcyRecorder(slave={self._slave_index}, count={self.count})"
