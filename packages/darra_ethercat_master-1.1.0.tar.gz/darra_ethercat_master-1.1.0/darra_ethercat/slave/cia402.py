# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/CiA402.cs
CiA 402 驱动器高级功能模块

包含:
- StateCiA402: CiA 402 状态枚举
- ModeCiA402: 操作模式枚举
- CiA402Advanced: CiA 402 PDO 映射扫描、状态机控制、运动参数、回零、Touch Probe 等
"""

import struct
import time
from enum import IntEnum
from typing import Dict, List, Optional, Tuple

from ..utils.dll import DarraCoreDLL
from .core import CoE, CiA402


# ========== 枚举类型 ==========

class StateCiA402(IntEnum):
    """CiA 402 驱动器状态机状态"""
    NOT_READY_TO_SWITCH_ON = 0   # 初始化中
    SWITCH_ON_DISABLED = 1       # 驱动禁用
    READY_TO_SWITCH_ON = 2       # 准备就绪
    SWITCHED_ON = 3              # 已开启
    OPERATION_ENABLED = 4        # 运行使能
    QUICK_STOP_ACTIVE = 5        # 快速停止
    FAULT_REACTION_ACTIVE = 6    # 故障反应中
    FAULT = 7                    # 故障
    UNKNOWN = 99                 # 未知状态


class ModeCiA402(IntEnum):
    """CiA 402 操作模式"""
    PP = 1       # 轮廓位置 (Profile Position)
    VL = 2       # 速度 (Velocity)
    PV = 3       # 轮廓速度 (Profile Velocity)
    PT = 4       # 轮廓转矩 (Profile Torque)
    HM = 6       # 回零 (Homing)
    IP = 7       # 插补位置 (Interpolated Position)
    CSP = 8      # 周期同步位置 (Cyclic Synchronous Position)
    CSV = 9      # 周期同步速度 (Cyclic Synchronous Velocity)
    CST = 10     # 周期同步转矩 (Cyclic Synchronous Torque)
    CSTCA = 11   # 周期同步转矩加速度 (Cyclic Synchronous Torque with Commutation Angle)


# ========== CiA402 常用对象索引定义 ==========

OD_CONTROLWORD              = 0x6040  # 控制字
OD_STATUSWORD               = 0x6041  # 状态字
OD_QUICK_STOP_OPTION_CODE   = 0x605A  # 快速停止选项码
OD_MODES_OF_OPERATION       = 0x6060  # 操作模式
OD_MODES_DISPLAY            = 0x6061  # 操作模式显示
OD_POSITION_ACTUAL          = 0x6064  # 实际位置
OD_TARGET_TORQUE            = 0x6071  # 目标转矩
OD_MAX_TORQUE               = 0x6072  # 最大转矩
OD_MOTOR_RATED_TORQUE       = 0x6076  # 电机额定转矩
OD_TORQUE_ACTUAL            = 0x6077  # 实际转矩
OD_TARGET_POSITION          = 0x607A  # 目标位置
OD_HOME_OFFSET              = 0x607C  # 回零偏移
OD_SOFTWARE_POSITION_LIMIT  = 0x607D  # 软件位置限制
OD_POLARITY                 = 0x607E  # 极性
OD_MAX_PROFILE_VELOCITY     = 0x6080  # 最大轮廓速度
OD_PROFILE_VELOCITY         = 0x6081  # 轮廓速度
OD_PROFILE_ACCELERATION     = 0x6083  # 轮廓加速度
OD_PROFILE_DECELERATION     = 0x6084  # 轮廓减速度
OD_QUICK_STOP_DECEL         = 0x6085  # 快速停止减速度
OD_MOTION_PROFILE_TYPE      = 0x6086  # 运动轮廓类型
OD_HOMING_METHOD            = 0x6098  # 回零方式
OD_HOMING_SPEEDS            = 0x6099  # 回零速度
OD_HOMING_ACCELERATION      = 0x609A  # 回零加速度
OD_POSITION_OFFSET          = 0x60B0  # 位置偏移
OD_VELOCITY_OFFSET          = 0x60B1  # 速度偏移
OD_TORQUE_OFFSET            = 0x60B2  # 转矩偏移
OD_TOUCH_PROBE_FUNCTION     = 0x60B8  # Touch Probe 功能控制
OD_TOUCH_PROBE_STATUS       = 0x60B9  # Touch Probe 1 状态
OD_TOUCH_PROBE_POS_EDGE     = 0x60BA  # Touch Probe 1 正边沿位置
OD_TOUCH_PROBE_NEG_EDGE     = 0x60BB  # Touch Probe 1 负边沿位置
OD_INTERPOLATION_TIME_PERIOD = 0x60C2  # 插补时间周期
OD_SYNCHRONIZATION_SETTINGS = 0x60D9  # 同步设置
OD_DRIVE_SYNC_STATUS        = 0x60DA  # 驱动同步状态
OD_POSITIVE_TORQUE_LIMIT    = 0x60E0  # 正方向力矩限制
OD_NEGATIVE_TORQUE_LIMIT    = 0x60E1  # 负方向力矩限制
OD_SUPPORTED_HOMING_METHODS = 0x60E3  # 支持的回零方法列表
OD_VELOCITY_ACTUAL          = 0x606C  # 实际速度
OD_TARGET_VELOCITY          = 0x60FF  # 目标速度
OD_DIGITAL_INPUTS           = 0x60FD  # 数字输入
OD_DIGITAL_OUTPUTS          = 0x60FE  # 数字输出
OD_SUPPORTED_MODES          = 0x6502  # 支持的驱动模式
OD_TXPDO_DATA_INVALID       = 0x603E  # TxPDO 数据无效标志

# ========== 控制字命令 ==========

CW_SHUTDOWN          = 0x06   # Shutdown (→ Ready to switch on)
CW_SWITCH_ON         = 0x07   # Switch On (→ Switched on)
CW_ENABLE_OPERATION  = 0x0F   # Enable Operation (→ Operation enabled)
CW_DISABLE_VOLTAGE   = 0x00   # Disable Voltage (→ Switch on disabled)
CW_QUICK_STOP        = 0x02   # Quick Stop (→ Quick stop active)
CW_FAULT_RESET       = 0x80   # Fault Reset (上升沿清除故障)
CW_HALT              = 0x0100  # Halt 位 (Bit 8, 暂停运动但不禁用)

# ========== 状态字位定义 ==========

SW_READY_TO_SWITCH_ON = 0x0001  # Bit 0
SW_SWITCHED_ON        = 0x0002  # Bit 1
SW_OPERATION_ENABLED  = 0x0004  # Bit 2
SW_FAULT              = 0x0008  # Bit 3
SW_VOLTAGE_ENABLED    = 0x0010  # Bit 4
SW_QUICK_STOP         = 0x0020  # Bit 5 (0=activated)
SW_SWITCH_ON_DISABLED = 0x0040  # Bit 6
SW_WARNING            = 0x0080  # Bit 7
SW_REMOTE             = 0x0200  # Bit 9
SW_TARGET_REACHED     = 0x0400  # Bit 10
SW_INTERNAL_LIMIT     = 0x0800  # Bit 11
SW_OP_MODE_SPECIFIC_1 = 0x1000  # Bit 12: Set-point acknowledge (PP) / Homing attained (HM)
SW_OP_MODE_SPECIFIC_2 = 0x2000  # Bit 13: Following error (CSP) / Homing error (HM)


def parse_cia402_state(statusword: int) -> StateCiA402:
    """
    从状态字解析驱动器状态

    参数:
        statusword: 状态字值

    返回:
        驱动器状态枚举
    """
    # 按 CiA 402 状态机位掩码判断
    # Bit 0,1,2,3,5,6 确定状态
    mask = statusword & 0x006F

    if (statusword & SW_FAULT) != 0:
        # Bit 3 = 1
        if (mask & 0x0F) == 0x0F:
            return StateCiA402.FAULT_REACTION_ACTIVE
        return StateCiA402.FAULT

    state_map = {
        0x0000: StateCiA402.NOT_READY_TO_SWITCH_ON,   # xxxx xxxx x0xx 0000
        0x0040: StateCiA402.SWITCH_ON_DISABLED,        # xxxx xxxx x1xx 0000
        0x0021: StateCiA402.READY_TO_SWITCH_ON,        # xxxx xxxx x01x 0001
        0x0023: StateCiA402.SWITCHED_ON,               # xxxx xxxx x01x 0011
        0x0027: StateCiA402.OPERATION_ENABLED,          # xxxx xxxx x01x 0111
        0x0007: StateCiA402.QUICK_STOP_ACTIVE,          # xxxx xxxx x00x 0111
    }
    return state_map.get(mask, StateCiA402.UNKNOWN)


class CiA402Advanced(CiA402):
    """
    CiA 402 高级接口: 支持 PDO 映射扫描、状态机控制、运动参数、
    回零、Touch Probe、数字 IO 等完整 CiA 402 功能。

    扫描 0x1C12 (RxPDO 映射) 和 0x1C13 (TxPDO 映射)
    找到各信号的 IOmap 字节偏移, 后续访问优先使用 PDO 直接读写。
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int):
        """初始化 CiA402 高级接口"""
        super().__init__(dll, master_index, slave_index)
        self._coe = CoE(dll, master_index, slave_index)
        # PDO 偏移缓存: {对象索引: (字节偏移, 是否为输出)}
        self._pdo_offsets: Dict[int, Tuple[int, bool]] = {}
        self._pdo_mapped = False

    # ========== PDO 映射扫描 ==========

    def scan_pdo_mapping(self) -> bool:
        """
        扫描从站的 PDO 映射配置 (0x1C12 / 0x1C13)

        返回:
            扫描是否成功 (至少找到一个已知信号)
        """
        self._pdo_offsets.clear()
        self._scan_sm_assign(0x1C12, is_output=True)
        self._scan_sm_assign(0x1C13, is_output=False)
        self._pdo_mapped = len(self._pdo_offsets) > 0
        return self._pdo_mapped

    def reset_pdo_offsets(self) -> None:
        """重置 PDO 偏移缓存 (状态降级时调用)"""
        self._pdo_offsets.clear()
        self._pdo_mapped = False

    def _scan_sm_assign(self, sm_assign_index: int, is_output: bool) -> None:
        """扫描 SM 分配对象中的 PDO 映射"""
        num_pdo = self._coe.sdo_read_value(sm_assign_index, 0, 'u8')
        if not num_pdo:
            return

        # 累积位偏移, 仅在匹配目标时转换为字节 (与 C# FindPdoOffset 一致)
        total_bit_offset = 0
        for pdo_slot in range(1, num_pdo + 1):
            pdo_index = self._coe.sdo_read_value(sm_assign_index, pdo_slot, 'u16')
            if not pdo_index:
                continue
            num_entries = self._coe.sdo_read_value(pdo_index, 0, 'u8')
            if not num_entries:
                continue

            for entry_slot in range(1, num_entries + 1):
                mapping = self._coe.sdo_read_value(pdo_index, entry_slot, 'u32')
                if mapping is None:
                    continue
                obj_index = (mapping >> 16) & 0xFFFF
                bit_length = mapping & 0xFF
                if obj_index != 0:
                    # 记录当前位偏移对应的字节偏移
                    self._pdo_offsets[obj_index] = (total_bit_offset // 8, is_output)
                total_bit_offset += bit_length

    # ========== PDO 读写底层方法 ==========

    def _pdo_read_i32(self, obj_index: int) -> Optional[int]:
        """通过 PDO 读取 int32 (若无映射则使用 SDO)"""
        info = self._pdo_offsets.get(obj_index)
        if info is not None:
            offset, _ = info
            return self._dll.PDOReadInputI32(self._mi, self._si, offset)
        return self._coe.sdo_read_value(obj_index, 0, 'i32')

    def _pdo_read_i16(self, obj_index: int) -> Optional[int]:
        """通过 PDO 读取 int16"""
        info = self._pdo_offsets.get(obj_index)
        if info is not None:
            offset, _ = info
            return self._dll.PDOReadInputI16(self._mi, self._si, offset)
        return self._coe.sdo_read_value(obj_index, 0, 'i16')

    def _pdo_read_u16(self, obj_index: int) -> Optional[int]:
        """通过 PDO 读取 uint16"""
        info = self._pdo_offsets.get(obj_index)
        if info is not None:
            offset, _ = info
            return self._dll.PDOReadInputU16(self._mi, self._si, offset)
        return self._coe.sdo_read_value(obj_index, 0, 'u16')

    def _pdo_write_i32(self, obj_index: int, value: int) -> bool:
        """通过 PDO 写入 int32"""
        info = self._pdo_offsets.get(obj_index)
        if info is not None:
            offset, is_out = info
            if is_out:
                return bool(self._dll.PDOWriteOutputI32(self._mi, self._si, offset, value))
        return self._coe.sdo_write_value(obj_index, 0, value, 'i32')

    def _pdo_write_i16(self, obj_index: int, value: int) -> bool:
        """通过 PDO 写入 int16"""
        info = self._pdo_offsets.get(obj_index)
        if info is not None:
            offset, is_out = info
            if is_out:
                return bool(self._dll.PDOWriteOutputI16(self._mi, self._si, offset, value))
        return self._coe.sdo_write_value(obj_index, 0, value, 'i16')

    def _pdo_write_u16(self, obj_index: int, value: int) -> bool:
        """通过 PDO 写入 uint16"""
        info = self._pdo_offsets.get(obj_index)
        if info is not None:
            offset, is_out = info
            if is_out:
                return bool(self._dll.PDOWriteOutputU16(self._mi, self._si, offset, value))
        return self._coe.sdo_write_value(obj_index, 0, value, 'u16')

    def _pdo_write_u8(self, obj_index: int, value: int) -> bool:
        """通过 PDO 写入 uint8"""
        info = self._pdo_offsets.get(obj_index)
        if info is not None:
            offset, is_out = info
            if is_out:
                return bool(self._dll.PDOWriteOutputU8(self._mi, self._si, offset, value))
        return self._coe.sdo_write_value(obj_index, 0, value, 'u8')

    # ========== 状态读取 ==========

    @property
    def statusword(self) -> int:
        """
        读取当前状态字 (PDO 优先, 无网络开销)
        0x6041
        """
        val = self._pdo_read_u16(OD_STATUSWORD)
        return val if val is not None else 0

    @property
    def controlword(self) -> int:
        """
        读取或写入控制字 (0x6040)
        """
        val = self._pdo_read_u16(OD_CONTROLWORD)
        return val if val is not None else 0

    @controlword.setter
    def controlword(self, value: int) -> None:
        """写入控制字 (PDO 优先, SDO 回退)"""
        self._pdo_write_u16(OD_CONTROLWORD, value)

    @property
    def state_drive(self) -> StateCiA402:
        """解析当前驱动器状态"""
        return parse_cia402_state(self.statusword)

    @property
    def target_reached(self) -> bool:
        """目标已到达 (Bit 10)"""
        return (self.statusword & SW_TARGET_REACHED) != 0

    @property
    def has_fault(self) -> bool:
        """是否有故障 (Bit 3)"""
        return (self.statusword & SW_FAULT) != 0

    @property
    def has_warning(self) -> bool:
        """是否有警告 (Bit 7)"""
        return (self.statusword & SW_WARNING) != 0

    @property
    def is_remote(self) -> bool:
        """远程模式 (Bit 9)"""
        return (self.statusword & SW_REMOTE) != 0

    @property
    def internal_limit_active(self) -> bool:
        """内部限位激活 (Bit 11)"""
        return (self.statusword & SW_INTERNAL_LIMIT) != 0

    # ========== 操作模式 ==========

    @property
    def operation_mode(self) -> int:
        """
        读取当前操作模式 (0x6061, PDO 优先)
        返回 ModeCiA402 枚举值对应的整数
        """
        info = self._pdo_offsets.get(OD_MODES_DISPLAY)
        if info is not None:
            offset, _ = info
            raw = self._dll.PDOReadInputU8(self._mi, self._si, offset)
            return struct.unpack('<b', struct.pack('<B', raw & 0xFF))[0]
        val = self._coe.sdo_read_value(OD_MODES_DISPLAY, 0, 'i8')
        return val if val is not None else 0

    @operation_mode.setter
    def operation_mode(self, value: int) -> None:
        """
        设置操作模式 (0x6060, PDO 优先, SDO 回退)
        """
        self._pdo_write_u8(OD_MODES_OF_OPERATION, value & 0xFF)

    # ========== 使能/停止 (全部非阻塞) ==========

    def enable(self, max_retries: int = 10) -> bool:
        """
        使能驱动器: 状态机推进逻辑由 native DLL (CiA402_Enable) 承载,
        内部按 CiA 402-2 完成 SwitchOnDisabled→ReadyToSwitchOn→SwitchedOn→OperationEnabled
        全套时序、Fault 复位、QuickStop 恢复 (含 0x605A 选项码判断), 不在 Python 层暴露状态机 IP.

        参数:
            max_retries: 最大重试次数 (默认 10)

        返回:
            True = 已使能到 OperationEnabled, False = 失败/超时
        """
        return bool(self._dll.CiA402_Enable(self._mi, self._si, max_retries))

    def disable_operation(self) -> None:
        """
        禁用运行 (非阻塞, Transition 5: OperationEnabled -> SwitchedOn)
        电机仍通电，可快速重新 Enable
        """
        self.controlword = CW_SWITCH_ON

    def disable(self) -> None:
        """
        禁用伺服 (非阻塞, -> SwitchOnDisabled)。完全断电。
        """
        self.controlword = CW_DISABLE_VOLTAGE

    def quick_stop(self) -> None:
        """
        快速停止 (非阻塞, -> QuickStopActive)
        """
        self.controlword = CW_QUICK_STOP

    def fault_reset(self) -> None:
        """
        清除故障 (发送 Fault Reset 上升沿)。
        按 ETG.6010 要求，Bit7 必须产生 0->1 上升沿才能触发故障复位。
        先清除 Bit7 确保低电平，再置位 Bit7 产生上升沿。

        注意: 包含 sleep(1ms), 不适合在 PDO 实时回调中使用。
        PDO 场景请分两个周期: 第一个周期写 0x00, 第二个周期写 CW_FAULT_RESET (0x80)。
        """
        self.controlword = 0x00
        time.sleep(0.001)
        self.controlword = CW_FAULT_RESET

    def switch_on(self) -> None:
        """Shutdown -> Ready to switch on (发送 CW_SHUTDOWN)"""
        self.controlword = CW_SHUTDOWN

    def switch_off(self) -> None:
        """关闭伺服 (发送 CW_DISABLE_VOLTAGE, -> SwitchOnDisabled)"""
        self.controlword = CW_DISABLE_VOLTAGE

    def ready_to_switch_on(self) -> None:
        """发送 Shutdown 命令, 转换到 ReadyToSwitchOn 状态"""
        self.controlword = CW_SHUTDOWN

    # ========== 运动参数 (PDO 优先) ==========

    @property
    def target_position(self) -> Optional[int]:
        """目标位置 (0x607A, int32, PDO 优先)"""
        return self._pdo_read_i32(OD_TARGET_POSITION)

    @target_position.setter
    def target_position(self, value: int) -> None:
        self._pdo_write_i32(OD_TARGET_POSITION, value)

    @property
    def actual_position(self) -> Optional[int]:
        """实际位置 (0x6064, int32, PDO 优先)"""
        return self._pdo_read_i32(OD_POSITION_ACTUAL)

    @property
    def target_velocity(self) -> Optional[int]:
        """目标速度 (0x60FF, int32, PDO 优先)"""
        return self._pdo_read_i32(OD_TARGET_VELOCITY)

    @target_velocity.setter
    def target_velocity(self, value: int) -> None:
        self._pdo_write_i32(OD_TARGET_VELOCITY, value)

    @property
    def velocity_actual(self) -> Optional[int]:
        """实际速度 (0x606C, int32, PDO 优先)"""
        return self._pdo_read_i32(OD_VELOCITY_ACTUAL)

    @property
    def target_torque(self) -> Optional[int]:
        """目标转矩 (0x6071, int16, PDO 优先)"""
        return self._pdo_read_i16(OD_TARGET_TORQUE)

    @target_torque.setter
    def target_torque(self, value: int) -> None:
        self._pdo_write_i16(OD_TARGET_TORQUE, value)

    @property
    def torque_actual(self) -> Optional[int]:
        """实际转矩 (0x6077, int16, 单位千分之额定转矩)"""
        return self._pdo_read_i16(OD_TORQUE_ACTUAL)

    @property
    def status_word_pdo(self) -> Optional[int]:
        """通过 PDO 读取状态字 (0x6041) - 兼容旧接口"""
        return self._pdo_read_u16(OD_STATUSWORD)

    @property
    def control_word_pdo(self) -> Optional[int]:
        """通过 PDO 读取控制字 (0x6040) - 兼容旧接口"""
        return self._pdo_read_u16(OD_CONTROLWORD)

    @control_word_pdo.setter
    def control_word_pdo(self, value: int) -> None:
        self._pdo_write_u16(OD_CONTROLWORD, value)

    @property
    def modes_of_operation_display(self) -> Optional[int]:
        """操作模式显示 (0x6061, int8) - 兼容旧接口"""
        return self.operation_mode

    # ========== 轮廓参数 (SDO 读写) ==========

    @property
    def profile_velocity(self) -> Optional[int]:
        """轮廓速度 (0x6081, uint32)"""
        return self._coe.sdo_read_value(OD_PROFILE_VELOCITY, 0, 'u32')

    @profile_velocity.setter
    def profile_velocity(self, value: int) -> None:
        self._coe.sdo_write_value(OD_PROFILE_VELOCITY, 0, value, 'u32')

    @property
    def max_profile_velocity(self) -> Optional[int]:
        """最大轮廓速度 (0x6080, uint32)"""
        return self._coe.sdo_read_value(OD_MAX_PROFILE_VELOCITY, 0, 'u32')

    @max_profile_velocity.setter
    def max_profile_velocity(self, value: int) -> None:
        self._coe.sdo_write_value(OD_MAX_PROFILE_VELOCITY, 0, value, 'u32')

    @property
    def profile_acceleration(self) -> Optional[int]:
        """轮廓加速度 (0x6083, uint32)"""
        return self._coe.sdo_read_value(OD_PROFILE_ACCELERATION, 0, 'u32')

    @profile_acceleration.setter
    def profile_acceleration(self, value: int) -> None:
        self._coe.sdo_write_value(OD_PROFILE_ACCELERATION, 0, value, 'u32')

    @property
    def profile_deceleration(self) -> Optional[int]:
        """轮廓减速度 (0x6084, uint32)"""
        return self._coe.sdo_read_value(OD_PROFILE_DECELERATION, 0, 'u32')

    @profile_deceleration.setter
    def profile_deceleration(self, value: int) -> None:
        self._coe.sdo_write_value(OD_PROFILE_DECELERATION, 0, value, 'u32')

    @property
    def quick_stop_deceleration(self) -> Optional[int]:
        """快速停止减速度 (0x6085, uint32)"""
        return self._coe.sdo_read_value(OD_QUICK_STOP_DECEL, 0, 'u32')

    @quick_stop_deceleration.setter
    def quick_stop_deceleration(self, value: int) -> None:
        self._coe.sdo_write_value(OD_QUICK_STOP_DECEL, 0, value, 'u32')

    @property
    def polarity(self) -> Optional[int]:
        """
        极性设置 (0x607E, uint8)
        Bit 6: 速度极性 (1=反向), Bit 7: 位置极性 (1=反向)
        """
        return self._coe.sdo_read_value(OD_POLARITY, 0, 'u8')

    @polarity.setter
    def polarity(self, value: int) -> None:
        self._coe.sdo_write_value(OD_POLARITY, 0, value, 'u8')

    @property
    def motion_profile_type(self) -> Optional[int]:
        """
        运动轮廓类型 (0x6086, int16)
        0 = 线性斜坡 (梯形), 1 = 正弦, 2 = 抛物线 (S 曲线)
        """
        return self._coe.sdo_read_value(OD_MOTION_PROFILE_TYPE, 0, 'i16')

    @motion_profile_type.setter
    def motion_profile_type(self, value: int) -> None:
        self._coe.sdo_write_value(OD_MOTION_PROFILE_TYPE, 0, value, 'i16')

    @property
    def software_position_limit_min(self) -> Optional[int]:
        """软件位置最小限制 (0x607D:01, int32)"""
        return self._coe.sdo_read_value(OD_SOFTWARE_POSITION_LIMIT, 1, 'i32')

    @software_position_limit_min.setter
    def software_position_limit_min(self, value: int) -> None:
        self._coe.sdo_write_value(OD_SOFTWARE_POSITION_LIMIT, 1, value, 'i32')

    @property
    def software_position_limit_max(self) -> Optional[int]:
        """软件位置最大限制 (0x607D:02, int32)"""
        return self._coe.sdo_read_value(OD_SOFTWARE_POSITION_LIMIT, 2, 'i32')

    @software_position_limit_max.setter
    def software_position_limit_max(self, value: int) -> None:
        self._coe.sdo_write_value(OD_SOFTWARE_POSITION_LIMIT, 2, value, 'i32')

    @property
    def quick_stop_option_code(self) -> Optional[int]:
        """
        快速停止选项码 (0x605A, int16)
        0=禁用驱动, 1/2=减速停止->SwitchOnDisabled,
        5/6=减速停止->保持在QuickStopActive(允许Transition 16恢复)
        """
        return self._coe.sdo_read_value(OD_QUICK_STOP_OPTION_CODE, 0, 'i16')

    @quick_stop_option_code.setter
    def quick_stop_option_code(self, value: int) -> None:
        self._coe.sdo_write_value(OD_QUICK_STOP_OPTION_CODE, 0, value, 'i16')

    # ========== 回零参数 ==========

    @property
    def homing_method(self) -> Optional[int]:
        """回零方法 (0x6098, int8)"""
        return self._coe.sdo_read_value(OD_HOMING_METHOD, 0, 'i8')

    @homing_method.setter
    def homing_method(self, value: int) -> None:
        self._coe.sdo_write_value(OD_HOMING_METHOD, 0, value, 'i8')

    @property
    def home_offset(self) -> Optional[int]:
        """回零偏移 (0x607C, int32)"""
        return self._coe.sdo_read_value(OD_HOME_OFFSET, 0, 'i32')

    @home_offset.setter
    def home_offset(self, value: int) -> None:
        self._coe.sdo_write_value(OD_HOME_OFFSET, 0, value, 'i32')

    @property
    def homing_speed_search(self) -> Optional[int]:
        """回零搜索速度 (0x6099:01, uint32, 快速接近开关)"""
        return self._coe.sdo_read_value(OD_HOMING_SPEEDS, 1, 'u32')

    @homing_speed_search.setter
    def homing_speed_search(self, value: int) -> None:
        self._coe.sdo_write_value(OD_HOMING_SPEEDS, 1, value, 'u32')

    @property
    def homing_speed_zero(self) -> Optional[int]:
        """回零零脉冲速度 (0x6099:02, uint32, 精确定位零脉冲)"""
        return self._coe.sdo_read_value(OD_HOMING_SPEEDS, 2, 'u32')

    @homing_speed_zero.setter
    def homing_speed_zero(self, value: int) -> None:
        self._coe.sdo_write_value(OD_HOMING_SPEEDS, 2, value, 'u32')

    @property
    def homing_acceleration(self) -> Optional[int]:
        """回零加速度 (0x609A, uint32)"""
        return self._coe.sdo_read_value(OD_HOMING_ACCELERATION, 0, 'u32')

    @homing_acceleration.setter
    def homing_acceleration(self, value: int) -> None:
        self._coe.sdo_write_value(OD_HOMING_ACCELERATION, 0, value, 'u32')

    def start_homing(self) -> None:
        """HM 模式: 启动回零 (Bit 4 = Homing Start)"""
        self.controlword = CW_ENABLE_OPERATION | 0x10

    @property
    def homing_attained(self) -> bool:
        """回零完成 (Bit 12)"""
        return (self.statusword & SW_OP_MODE_SPECIFIC_1) != 0

    @property
    def homing_error(self) -> bool:
        """回零错误 (Bit 13)"""
        return (self.statusword & SW_OP_MODE_SPECIFIC_2) != 0

    @property
    def supported_homing_methods(self) -> List[int]:
        """
        读取支持的回零方法列表 (0x60E3)
        返回驱动器支持的所有回零方法编号
        """
        try:
            count = self._coe.sdo_read_value(OD_SUPPORTED_HOMING_METHODS, 0, 'u8')
            if not count:
                return []
            methods = []
            for i in range(1, count + 1):
                val = self._coe.sdo_read_value(OD_SUPPORTED_HOMING_METHODS, i, 'i8')
                if val is not None:
                    methods.append(val)
            return methods
        except Exception:
            return []

    # ========== 扩展运动参数 ==========

    @property
    def max_torque(self) -> Optional[int]:
        """最大转矩 (0x6072, uint16, 单位千分之额定转矩)"""
        return self._coe.sdo_read_value(OD_MAX_TORQUE, 0, 'u16')

    @max_torque.setter
    def max_torque(self, value: int) -> None:
        self._coe.sdo_write_value(OD_MAX_TORQUE, 0, value, 'u16')

    @property
    def motor_rated_torque(self) -> Optional[int]:
        """电机额定转矩 (0x6076, uint32, 单位 mNm)"""
        return self._coe.sdo_read_value(OD_MOTOR_RATED_TORQUE, 0, 'u32')

    @motor_rated_torque.setter
    def motor_rated_torque(self, value: int) -> None:
        self._coe.sdo_write_value(OD_MOTOR_RATED_TORQUE, 0, value, 'u32')

    @property
    def position_offset(self) -> Optional[int]:
        """位置偏移 (0x60B0, int32, CSP 模式下叠加到目标位置)"""
        return self._coe.sdo_read_value(OD_POSITION_OFFSET, 0, 'i32')

    @position_offset.setter
    def position_offset(self, value: int) -> None:
        self._coe.sdo_write_value(OD_POSITION_OFFSET, 0, value, 'i32')

    @property
    def velocity_offset(self) -> Optional[int]:
        """速度偏移 (0x60B1, int32, CSV 模式下叠加到目标速度)"""
        return self._coe.sdo_read_value(OD_VELOCITY_OFFSET, 0, 'i32')

    @velocity_offset.setter
    def velocity_offset(self, value: int) -> None:
        self._coe.sdo_write_value(OD_VELOCITY_OFFSET, 0, value, 'i32')

    @property
    def torque_offset(self) -> Optional[int]:
        """转矩偏移 (0x60B2, int16)"""
        return self._coe.sdo_read_value(OD_TORQUE_OFFSET, 0, 'i16')

    @torque_offset.setter
    def torque_offset(self, value: int) -> None:
        self._coe.sdo_write_value(OD_TORQUE_OFFSET, 0, value, 'i16')

    @property
    def interpolation_time_period_value(self) -> Optional[int]:
        """插补时间周期值 (0x60C2:01, uint8)"""
        return self._coe.sdo_read_value(OD_INTERPOLATION_TIME_PERIOD, 1, 'u8')

    @interpolation_time_period_value.setter
    def interpolation_time_period_value(self, value: int) -> None:
        self._coe.sdo_write_value(OD_INTERPOLATION_TIME_PERIOD, 1, value, 'u8')

    @property
    def interpolation_time_period_index(self) -> Optional[int]:
        """
        插补时间周期指数 (0x60C2:02, int8)
        实际周期 = Value * 10^Index 秒
        """
        return self._coe.sdo_read_value(OD_INTERPOLATION_TIME_PERIOD, 2, 'i8')

    @interpolation_time_period_index.setter
    def interpolation_time_period_index(self, value: int) -> None:
        self._coe.sdo_write_value(OD_INTERPOLATION_TIME_PERIOD, 2, value, 'i8')

    # ========== Touch Probe (ETG.6010) ==========

    def configure_touch_probe(self, function: int) -> None:
        """
        配置 Touch Probe 功能 (0x60B8)
        Bit 0: 启用 Probe 1, Bit 1: 正边沿触发, Bit 2: 第一个事件

        参数:
            function: Touch Probe 功能配置字
        """
        self._coe.sdo_write_value(OD_TOUCH_PROBE_FUNCTION, 0, function, 'u16')

    def enable_touch_probe(self, positive_edge: bool = True,
                           first_event_only: bool = True) -> None:
        """
        启用 Touch Probe 1

        参数:
            positive_edge: True=正边沿触发, False=负边沿触发
            first_event_only: True=仅第一个事件, False=持续捕获
        """
        func = 0x0001  # Bit 0: 启用 Probe 1
        if positive_edge:
            func |= 0x0002  # Bit 1: 正边沿触发
        if first_event_only:
            func |= 0x0004  # Bit 2: 第一个事件
        self.configure_touch_probe(func)

    @property
    def touch_probe_status(self) -> Optional[int]:
        """Touch Probe 1 状态 (0x60B9, uint16, 只读)"""
        return self._coe.sdo_read_value(OD_TOUCH_PROBE_STATUS, 0, 'u16')

    @property
    def touch_probe_positive_value(self) -> Optional[int]:
        """Touch Probe 1 正边沿捕获位置 (0x60BA, int32)"""
        return self._coe.sdo_read_value(OD_TOUCH_PROBE_POS_EDGE, 0, 'i32')

    @property
    def touch_probe_negative_value(self) -> Optional[int]:
        """Touch Probe 1 负边沿捕获位置 (0x60BB, int32)"""
        return self._coe.sdo_read_value(OD_TOUCH_PROBE_NEG_EDGE, 0, 'i32')

    # ========== 数字 IO (CiA 402) ==========

    @property
    def digital_inputs(self) -> Optional[int]:
        """数字输入状态 (0x60FD, uint32, 只读)"""
        return self._coe.sdo_read_value(OD_DIGITAL_INPUTS, 0, 'u32')

    @property
    def digital_outputs(self) -> Optional[int]:
        """数字输出控制 (0x60FE:01, uint32)"""
        return self._coe.sdo_read_value(OD_DIGITAL_OUTPUTS, 1, 'u32')

    @digital_outputs.setter
    def digital_outputs(self, value: int) -> None:
        self._coe.sdo_write_value(OD_DIGITAL_OUTPUTS, 1, value, 'u32')

    # ========== 驱动器信息 ==========

    @property
    def supported_drive_modes(self) -> Optional[int]:
        """
        支持的驱动模式位掩码 (0x6502, uint32, 只读)
        Bit 0=PP, Bit 1=VL, Bit 2=PV, Bit 3=PT, Bit 5=HM,
        Bit 6=IP, Bit 7=CSP, Bit 8=CSV, Bit 9=CST, Bit 10=CSTCA
        """
        return self._coe.sdo_read_value(OD_SUPPORTED_MODES, 0, 'u32')

    def is_mode_supported(self, mode: ModeCiA402) -> bool:
        """
        检查驱动器是否支持指定操作模式

        参数:
            mode: 要检查的操作模式 (ModeCiA402)

        返回:
            True = 驱动器支持该模式
        """
        supported = self.supported_drive_modes
        if supported is None:
            return False

        # 模式值到位掩码位置的映射
        mode_bit_map = {
            ModeCiA402.PP: 0,
            ModeCiA402.VL: 1,
            ModeCiA402.PV: 2,
            ModeCiA402.PT: 3,
            ModeCiA402.HM: 5,
            ModeCiA402.IP: 6,
            ModeCiA402.CSP: 7,
            ModeCiA402.CSV: 8,
            ModeCiA402.CST: 9,
            ModeCiA402.CSTCA: 10,
        }
        bit = mode_bit_map.get(mode, -1)
        if bit < 0:
            return False
        return (supported & (1 << bit)) != 0

    # ========== 力矩限制 (0x60E0/0x60E1) ==========

    @property
    def positive_torque_limit(self) -> Optional[int]:
        """正方向力矩限制 (0x60E0, uint16, 千分之额定转矩)"""
        return self._coe.sdo_read_value(OD_POSITIVE_TORQUE_LIMIT, 0, 'u16')

    @positive_torque_limit.setter
    def positive_torque_limit(self, value: int) -> None:
        self._coe.sdo_write_value(OD_POSITIVE_TORQUE_LIMIT, 0, value, 'u16')

    @property
    def negative_torque_limit(self) -> Optional[int]:
        """负方向力矩限制 (0x60E1, uint16, 千分之额定转矩)"""
        return self._coe.sdo_read_value(OD_NEGATIVE_TORQUE_LIMIT, 0, 'u16')

    @negative_torque_limit.setter
    def negative_torque_limit(self, value: int) -> None:
        self._coe.sdo_write_value(OD_NEGATIVE_TORQUE_LIMIT, 0, value, 'u16')

    # ========== 同步功能 (0x60D9/0x60DA) ==========

    @property
    def synchronization_settings(self) -> Optional[int]:
        """同步设置 (0x60D9:01, uint16, 同步使能位掩码)"""
        return self._coe.sdo_read_value(OD_SYNCHRONIZATION_SETTINGS, 1, 'u16')

    @synchronization_settings.setter
    def synchronization_settings(self, value: int) -> None:
        self._coe.sdo_write_value(OD_SYNCHRONIZATION_SETTINGS, 1, value, 'u16')

    @property
    def drive_sync_status(self) -> Optional[int]:
        """驱动同步状态 (0x60DA, uint16, 只读, 指示驱动器是否已同步到主站时钟)"""
        return self._coe.sdo_read_value(OD_DRIVE_SYNC_STATUS, 0, 'u16')

    # ========== TxPDO 数据有效性 (0x603E) ==========

    @property
    def txpdo_data_invalid(self) -> bool:
        """
        TxPDO 数据是否无效 (0x603E:00, 非零表示数据无效)
        用于判断驱动器 TxPDO 数据是否可信
        """
        try:
            data = self._coe.sdo_read(OD_TXPDO_DATA_INVALID, 0)
            return data is not None and len(data) > 0 and data[0] != 0
        except Exception:
            return False

    # ========== 快速运动控制 ==========

    def new_setpoint(self, position: int, relative: bool = False) -> None:
        """
        PP 模式: 发送新定位命令 (仅 PP 模式有效, CSP 下 bit4-6 无意义)

        参数:
            position: 目标位置
            relative: True = 相对定位, False = 绝对定位
        """
        self.target_position = position
        cw = CW_ENABLE_OPERATION | 0x10  # Bit 4 = New Setpoint
        if relative:
            cw |= 0x40  # Bit 6 = Relative
        self.controlword = cw

    def clear_new_setpoint(self) -> None:
        """PP 模式: 清除 NewSetpoint 标志 (Bit4=0), 用于 SetPointAck 握手完成后"""
        self.controlword = CW_ENABLE_OPERATION

    # ========== 轮廓参数验证 (CiA 402 PP/PV) ==========

    def validate_profile_parameters(self, configured_mode: int = 0) -> List[str]:
        """
        检查驱动器轮廓参数是否满足 PP/PV 模式运动需求。
        仅在配置的操作模式为 PP(1) 或 PV(3) 时执行检测。
        参照 TwinCAT 行为: 仅检测并报警, 不自动写入。

        参数:
            configured_mode: Startup 配置的操作模式, 0 表示自动从驱动器读取

        返回:
            警告消息列表 (空 = 通过)
        """
        warnings: List[str] = []
        try:
            mode = configured_mode
            if mode == 0:
                val = self._coe.sdo_read_value(OD_MODES_OF_OPERATION, 0, 'u8')
                mode = val if val is not None else 0

            # 仅 PP(1) 和 PV(3) 依赖驱动器内部轨迹生成器
            if mode not in (ModeCiA402.PP, ModeCiA402.PV):
                return warnings

            mode_name = "PP" if mode == 1 else "PV"

            checks = [
                (OD_MAX_PROFILE_VELOCITY, "Max Profile Velocity (0x6080)"),
                (OD_PROFILE_ACCELERATION, "Profile Acceleration (0x6083)"),
                (OD_PROFILE_DECELERATION, "Profile Deceleration (0x6084)"),
            ]

            for index, name in checks:
                try:
                    val = self._coe.sdo_read_value(index, 0, 'u32')
                    if val is not None and val == 0:
                        warnings.append(
                            f"{mode_name} 模式: {name} = 0, "
                            f"驱动器无法生成运动曲线, 请在 Startup 中配置此参数"
                        )
                except Exception:
                    warnings.append(
                        f"{mode_name} 模式: {name} 读取失败 (驱动器可能不支持此对象)"
                    )
        except Exception:
            # CoE 不可用, 跳过验证
            pass
        return warnings

    # ========== PDO 信息 ==========

    @property
    def pdo_offsets(self) -> Dict[int, Tuple[int, bool]]:
        """返回扫描到的 PDO 偏移映射"""
        return dict(self._pdo_offsets)

    @property
    def is_pdo_mapped(self) -> bool:
        """是否已完成 PDO 映射扫描"""
        return self._pdo_mapped

    # ========== 摘要 ==========

    def __repr__(self) -> str:
        try:
            sw = self.statusword
            state = parse_cia402_state(sw)
            mode = self.operation_mode
            return (
                f"CiA402Advanced(slave={self._si}, "
                f"state={state.name}, mode={mode}, "
                f"SW=0x{sw:04X}, mapped={len(self._pdo_offsets)})"
            )
        except Exception:
            return f"CiA402Advanced(slave={self._si}, mapped={len(self._pdo_offsets)})"
