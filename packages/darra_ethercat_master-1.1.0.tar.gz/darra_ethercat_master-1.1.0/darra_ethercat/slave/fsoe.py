# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/FSoE.cs
FSoE (Functional Safety over EtherCAT) 功能模块

包含:
- FSoE 状态枚举、错误码、命令类型、结构体
- FSoEMdp: MDP 包装器 (单从站多连接)
- FSoEManager: 多连接管理器
- fsoe_crc16 / fsoe_crc16_fast: CRC16 校验计算
"""

import ctypes
import threading
from ctypes import c_int, c_uint, c_ushort, c_void_p, c_bool, byref
from datetime import datetime
from enum import IntEnum
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

from ..utils.dll import (
    DarraCoreDLL, FsoEMdpConfig, FsoEStatus, FsoEState, FsoEError,
    EcMbxStatsT,
)
from .core import FSoE as _FSoECore
from ..abstractions import IMailboxProtocol, MailboxStatistics


# ===================== FSoE 状态枚举 (ETG.5100 section 4.2.6) =====================

class FSoEState(IntEnum):
    """FSoE 状态机状态"""
    RESET = 0x100       # 初始/重置状态
    SESSION = 0x101     # 会话建立
    CONNECTION = 0x102  # 连接建立
    PARAMETER = 0x103   # 参数下载
    DATA = 0x104        # 数据交换
    FAILSAFE = 0x105    # 失效安全


class FSoEError(IntEnum):
    """FSoE 错误代码 (ETG.5001.4)"""
    NONE = 0x0000                    # 无错误
    WRONG_COMMAND = 0x0001           # 错误的命令
    UNKNOWN_COMMAND = 0x0002         # 未知命令
    WRONG_CONNECTION_ID = 0x0003     # 连接ID不匹配
    CRC_ERROR = 0x0004               # CRC校验失败
    WATCHDOG = 0x0005                # 看门狗超时
    WRONG_ADDRESS = 0x0006           # 错误的FSoE地址
    WRONG_DATA = 0x0007              # 无效数据
    COMM_PARAM_LENGTH = 0x0008       # 通信参数长度错误
    COMM_PARAM = 0x0009              # 通信参数错误
    APP_PARAM_LENGTH = 0x000A        # 应用参数长度错误
    APP_PARAM = 0x000B               # 应用参数错误
    UNEXPECTED_SESSION = 0x000C      # 意外的会话命令
    FAILSAFE_DATA = 0x000D           # 收到失效安全数据
    NOT_INITIALIZED = 0x0100         # FSoE未初始化
    MAX_CONNECTIONS = 0x0101         # 达到最大连接数
    INVALID_STATE_TRANSITION = 0x0102  # 无效状态转换


class FSoECommand(IntEnum):
    """FSoE 命令类型 (ETG.5100)"""
    RESET = 0x00       # 重置命令
    SESSION = 0x01     # 会话请求/响应
    CONNECTION = 0x02  # 连接请求/响应
    PARAMETER = 0x03   # 参数下载
    FAILSAFE = 0x04    # 失效安全模式
    DATA = 0x05        # 正常数据交换


class FSoEFailsafeReason(IntEnum):
    """FSoE 失效安全触发原因"""
    WATCHDOG_TIMEOUT = 0      # 看门狗超时
    CRC_ERROR = 1             # CRC错误
    COMMUNICATION_ERROR = 2   # 通信错误
    APPLICATION_REQUEST = 3   # 应用请求
    SLAVE_REQUEST = 4         # 从站请求
    MASTER_REQUEST = 5        # 主站请求
    RECOVERY_TO_DATA = 6      # 恢复到数据模式


class FSoEConnectionMode(IntEnum):
    """FSoE 连接模式"""
    SINGLE = 0    # 单连接模式 - 所有模块共用一个 FSoE 连接和安全地址
    MULTIPLE = 1  # 多连接模式 - 每个模块有独立的 FSoE 连接和安全地址


class FSoEConnectionType(IntEnum):
    """FSoE 连接类型 (ETG.5120 SI6)"""
    MASTER = 0  # FSoE 主站连接
    SLAVE = 1   # FSoE 从站连接


class FSoEModuleProfile(IntEnum):
    """FSoE MDP 模块配置文件编号 (ETG.5001.4)"""
    DIGITAL_INPUT = 190      # FSoE Digital Input
    DIGITAL_IN_OUT = 195     # FSoE Digital In-/Output
    DIGITAL_OUTPUT = 290     # FSoE Digital Output
    DRIVE_CONNECTION = 790   # FSoE MDP Drive Connection
    MASTER = 6900            # FSoE Master


# ===================== FSoE 结构体 =====================

@dataclass
class FSoEConnectionConfig:
    """FSoE 连接配置"""
    connection_id: int = 0          # 唯一连接标识符
    safety_address: int = 0         # FSoE从站安全地址
    watchdog_time_ms: int = 100     # 看门狗超时(毫秒)
    safe_input_size: int = 0        # 安全输入数据大小(字节)
    safe_output_size: int = 0       # 安全输出数据大小(字节)
    pdo_input_offset: int = 0       # IOmap中输入偏移
    pdo_output_offset: int = 0      # IOmap中输出偏移


@dataclass
class FSoEConnectionStatus:
    """FSoE 连接状态"""
    state: FSoEState = FSoEState.RESET           # 当前FSoE状态
    last_error: FSoEError = FSoEError.NONE       # 最后的错误代码
    error_count: int = 0                          # 总错误计数
    frames_sent: int = 0                          # 发送帧数
    frames_received: int = 0                      # 接收有效帧数
    crc_errors: int = 0                           # CRC错误计数
    watchdog_errors: int = 0                      # 看门狗超时计数
    watchdog_expired: bool = False                # 看门狗是否过期
    in_failsafe: bool = False                     # 是否处于失效安全模式
    toggle_bit: int = 0                           # 当前切换位值
    is_initialized: bool = False                  # 连接是否已初始化


@dataclass
class FSoECommParameters:
    """FSoE 通信参数 (ETG.5120 section 5.2.3)"""
    connection_id: int = 0          # 连接ID (SI3)
    safety_address: int = 0         # FSoE从站安全地址 (SI2)
    watchdog_time_ms: int = 0       # 看门狗超时(毫秒) (SI4)
    comm_param_length: int = 0      # 通信参数长度 (SI7)
    app_param_length: int = 0       # 应用参数长度 (SI8)
    version: str = "01"             # 版本 (SI1)
    connection_type: int = 0        # 连接类型 (SI6): 0=Master, 1=Slave


# ===================== FSoE 数据交换事件 (对齐 C# DataExchanged) =====================

@dataclass
class FSoEDataExchangeEvent:
    """
    FSoE 数据交换事件参数 (对齐 C# FSoEDataExchangeEventArgs).

    每个 PDO 周期, 输入刷新后输出提交前触发, 携带当前 FSoE 状态快照.
    """
    slave_index: int = 0                          # 从站索引
    current_state: FSoEState = FSoEState.RESET    # 本周期当前 FSoE 状态
    safe_inputs: bytes = b""                       # 本周期安全输入快照 (拷贝)
    safe_outputs: bytes = b""                      # 本周期安全输出快照 (拷贝)
    in_failsafe: bool = False                      # 是否处于失效安全模式
    cycle_count: int = 0                           # 累计 PDO 周期计数
    timestamp: Optional[datetime] = None           # 事件触发时间戳 (UTC)


# 数据交换回调类型别名
FSoEDataExchangeCallback = Callable[[FSoEDataExchangeEvent], None]


class FSoEDataExchangeDispatcher:
    """
    FSoE 数据交换事件分发器 (对齐 C# DataExchanged 事件机制).

    Python 惯例: 使用回调列表 + threading.RLock 保证线程安全.
    每个 FSoEMdp / FSoEManager 实例可持有一个 dispatcher, 通过
    add_data_exchanged_callback / remove_data_exchanged_callback 注册回调.
    """

    def __init__(self) -> None:
        self._callbacks: List[FSoEDataExchangeCallback] = []
        self._lock = threading.RLock()
        self._cycle_count: int = 0

    def add_data_exchanged_callback(self, cb: FSoEDataExchangeCallback) -> None:
        """注册 DataExchanged 回调"""
        if cb is None:
            return
        with self._lock:
            self._callbacks.append(cb)

    def remove_data_exchanged_callback(self, cb: FSoEDataExchangeCallback) -> None:
        """注销 DataExchanged 回调"""
        with self._lock:
            if cb in self._callbacks:
                self._callbacks.remove(cb)

    def fire_data_exchanged(self, slave_index: int, current_state: FSoEState,
                            safe_inputs: bytes, safe_outputs: bytes,
                            in_failsafe: bool) -> None:
        """
        触发 DataExchanged 事件 (由 PDO 周期内部调用).

        参数:
            slave_index:    从站索引
            current_state:  当前 FSoE 状态
            safe_inputs:    本周期安全输入 (会被拷贝)
            safe_outputs:   本周期安全输出 (会被拷贝)
            in_failsafe:    是否处于失效安全模式
        """
        with self._lock:
            self._cycle_count += 1
            cycle = self._cycle_count
            # 快照回调列表, 调用阶段释放锁避免死锁
            cbs = list(self._callbacks)

        event = FSoEDataExchangeEvent(
            slave_index=slave_index,
            current_state=current_state,
            safe_inputs=bytes(safe_inputs) if safe_inputs else b"",
            safe_outputs=bytes(safe_outputs) if safe_outputs else b"",
            in_failsafe=in_failsafe,
            cycle_count=cycle,
            timestamp=datetime.utcnow(),
        )

        for cb in cbs:
            try:
                cb(event)
            except Exception:
                # 回调异常不影响其他回调 / PDO 周期
                pass


class FSoEMdp:
    """
    FSoE MDP (模块化设备配置) 包装器

    封装所有 FSoEMdp* DLL 函数, 支持单从站上的多 FSoE 连接。
    适用于安全 I/O 模块等支持 MDP 的从站 (ETG.5120)。
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        # DataExchanged 事件分发器 (对齐 C# event DataExchanged)
        self._data_exchanged = FSoEDataExchangeDispatcher()

    def add_data_exchanged_callback(self, cb: FSoEDataExchangeCallback) -> None:
        """
        注册 DataExchanged 回调 — 每个 PDO 周期触发, 携带当前 FSoE 状态快照.
        对齐 C# event DataExchanged.
        """
        self._data_exchanged.add_data_exchanged_callback(cb)

    def remove_data_exchanged_callback(self, cb: FSoEDataExchangeCallback) -> None:
        """注销 DataExchanged 回调"""
        self._data_exchanged.remove_data_exchanged_callback(cb)

    def _fire_data_exchanged(self, current_state: FSoEState,
                             safe_inputs: bytes, safe_outputs: bytes,
                             in_failsafe: bool) -> None:
        """触发 DataExchanged 事件 (PDO 周期内部调用)"""
        self._data_exchanged.fire_data_exchanged(
            slave_index=self._si,
            current_state=current_state,
            safe_inputs=safe_inputs,
            safe_outputs=safe_outputs,
            in_failsafe=in_failsafe,
        )

    def init_connection(self, connection_id: int, safety_address: int,
                        watchdog_time_ms: int, safe_input_size: int,
                        safe_output_size: int, pdo_input_offset: int = 0,
                        pdo_output_offset: int = 0, module_number: int = 0,
                        module_profile: int = 0, axis_number: int = 0,
                        connection_type: int = 0) -> bool:
        """初始化 MDP FSoE 连接"""
        cfg = FsoEMdpConfig()
        cfg.connection_id      = connection_id
        cfg.safety_address     = safety_address
        cfg.watchdog_time_ms   = watchdog_time_ms
        cfg.safe_input_size    = safe_input_size
        cfg.safe_output_size   = safe_output_size
        cfg.pdo_input_offset   = pdo_input_offset
        cfg.pdo_output_offset  = pdo_output_offset
        cfg.module_number      = module_number
        cfg.module_profile     = module_profile
        cfg.axis_number        = axis_number
        cfg.connection_type    = connection_type
        return bool(self._dll.FSoEMdpInitConnection(
            self._mi, self._si, connection_id, byref(cfg)
        ))

    def close_connection(self, connection_id: int) -> bool:
        """关闭指定的 MDP FSoE 连接"""
        return bool(self._dll.FSoEMdpCloseConnection(self._mi, self._si, connection_id))

    def get_status(self, connection_id: int) -> Optional[dict]:
        """获取 MDP FSoE 连接状态"""
        st = FsoEStatus()
        if not self._dll.FSoEMdpGetStatus(self._mi, self._si, connection_id, byref(st)):
            return None
        return {
            'state':            FsoEState(st.state) if st.state in FsoEState._value2member_map_ else st.state,
            'last_error':       FsoEError(st.last_error) if st.last_error in FsoEError._value2member_map_ else st.last_error,
            'error_count':      st.error_count,
            'frames_sent':      st.frames_sent,
            'frames_received':  st.frames_received,
            'crc_errors':       st.crc_errors,
            'watchdog_errors':  st.watchdog_errors,
            'watchdog_expired': bool(st.watchdog_expired),
            'in_failsafe':      bool(st.in_failsafe),
            'toggle_bit':       st.toggle_bit,
            'initialized':      bool(st.initialized),
        }

    def request_state(self, connection_id: int, target_state: int) -> bool:
        """请求 MDP FSoE 状态转换"""
        return bool(self._dll.FSoEMdpRequestState(self._mi, self._si, connection_id, target_state))

    def get_state(self, connection_id: int) -> int:
        """获取 MDP FSoE 当前状态"""
        return self._dll.FSoEMdpGetState(self._mi, self._si, connection_id)

    def reset(self, connection_id: int) -> bool:
        """重置 MDP FSoE 连接到初始状态"""
        return bool(self._dll.FSoEMdpReset(self._mi, self._si, connection_id))

    def write_safe_output(self, connection_id: int, data: bytes) -> bool:
        """写入 MDP 安全输出数据"""
        buf = ctypes.create_string_buffer(data)
        return bool(self._dll.FSoEMdpWriteSafeOutput(
            self._mi, self._si, connection_id,
            ctypes.cast(buf, c_void_p), len(data)
        ))

    def read_safe_input(self, connection_id: int, buffer_size: int = 256) -> Optional[bytes]:
        """读取 MDP 安全输入数据"""
        buf = ctypes.create_string_buffer(buffer_size)
        size = c_uint(buffer_size)
        ok = self._dll.FSoEMdpReadSafeInput(
            self._mi, self._si, connection_id,
            ctypes.cast(buf, c_void_p), byref(size)
        )
        if not ok or size.value == 0:
            return None
        return bytes(buf.raw[:size.value])

    def download_parameters(self, connection_id: int, param_data: bytes) -> Optional[int]:
        """下载 MDP 安全参数, 返回 SRA CRC 值"""
        buf = ctypes.create_string_buffer(param_data)
        sra_crc = c_uint(0)
        ok = self._dll.FSoEMdpDownloadParameters(
            self._mi, self._si, connection_id,
            ctypes.cast(buf, c_void_p), len(param_data), byref(sra_crc)
        )
        return sra_crc.value if ok else None

    def set_failsafe_output(self, connection_id: int, data: bytes) -> bool:
        """设置 MDP 失效安全输出值"""
        buf = ctypes.create_string_buffer(data)
        return bool(self._dll.FSoEMdpSetFailsafeOutput(
            self._mi, self._si, connection_id,
            ctypes.cast(buf, c_void_p), len(data)
        ))

    def check_watchdog(self, connection_id: int) -> bool:
        """检查 MDP 看门狗状态 (True=正常)"""
        return bool(self._dll.FSoEMdpCheckWatchdog(self._mi, self._si, connection_id))

    def get_last_error(self, connection_id: int) -> int:
        """获取 MDP 连接最后的错误代码"""
        return self._dll.FSoEMdpGetLastError(self._mi, self._si, connection_id)

    def clear_error(self, connection_id: int) -> None:
        """清除 MDP 连接错误"""
        self._dll.FSoEMdpClearError(self._mi, self._si, connection_id)

    def get_slave_connection_count(self) -> int:
        """获取该从站的 MDP 连接数量"""
        return self._dll.FSoEMdpGetSlaveConnectionCount(self._mi, self._si)

    def detect_connections(self) -> int:
        """自动探测从站支持的 MDP 连接数量"""
        return self._dll.FSoEMdpDetectConnections(self._mi, self._si)

    def get_device_address(self) -> Optional[int]:
        """获取 FSoE MDP 设备地址"""
        addr = c_ushort(0)
        if self._dll.FSoEMdpGetDeviceAddress(self._mi, self._si, byref(addr)):
            return addr.value
        return None

    def get_module_comm_param(self, connection_id: int, buffer_size: int = 256) -> Optional[bytes]:
        """获取模块通信参数"""
        buf = ctypes.create_string_buffer(buffer_size)
        size = c_uint(buffer_size)
        ok = self._dll.FSoEMdpGetModuleCommParam(
            self._mi, self._si, connection_id,
            ctypes.cast(buf, c_void_p), byref(size)
        )
        if not ok or size.value == 0:
            return None
        return bytes(buf.raw[:size.value])

    def get_module_diagnosis(self, connection_id: int) -> Optional[Tuple[int, int]]:
        """获取模块诊断信息, 返回 (故障代码, 警告代码)"""
        fault_code = c_ushort(0)
        warning_code = c_ushort(0)
        ok = self._dll.FSoEMdpGetModuleDiagnosis(
            self._mi, self._si, connection_id,
            byref(fault_code), byref(warning_code)
        )
        if not ok:
            return None
        return (fault_code.value, warning_code.value)

    def __repr__(self) -> str:
        return f"FSoEMdp(master={self._mi}, slave={self._si})"


class FSoEManager:
    """FSoE 多连接管理器"""

    def __init__(self, dll: DarraCoreDLL, master_index: int):
        self._dll = dll
        self._mi = master_index
        self._connections: Dict[Tuple[int, int], FSoEMdp] = {}

    def add_connection(self, slave_index: int, connection_id: int,
                       safety_address: int, watchdog_time_ms: int,
                       safe_input_size: int, safe_output_size: int,
                       pdo_input_offset: int = 0, pdo_output_offset: int = 0,
                       module_number: int = 0) -> bool:
        """添加并初始化一个 FSoE MDP 连接"""
        mdp = FSoEMdp(self._dll, self._mi, slave_index)
        ok = mdp.init_connection(
            connection_id, safety_address, watchdog_time_ms,
            safe_input_size, safe_output_size,
            pdo_input_offset, pdo_output_offset, module_number
        )
        if ok:
            self._connections[(slave_index, connection_id)] = mdp
        return ok

    def remove_connection(self, slave_index: int, connection_id: int) -> bool:
        """关闭并移除一个 FSoE 连接"""
        key = (slave_index, connection_id)
        mdp = self._connections.get(key)
        if mdp is None:
            return False
        ok = mdp.close_connection(connection_id)
        del self._connections[key]
        return ok

    def get_mdp(self, slave_index: int, connection_id: int) -> Optional[FSoEMdp]:
        """获取指定连接的 FSoEMdp 对象"""
        return self._connections.get((slave_index, connection_id))

    def process_cycle(self) -> None:
        """执行主站 FSoE 周期处理"""
        self._dll.FSoEProcessCycle(self._mi)

    def get_all_statuses(self) -> Dict[Tuple[int, int], Optional[dict]]:
        """获取所有连接的状态"""
        return {key: mdp.get_status(key[1]) for key, mdp in self._connections.items()}

    def close_all(self) -> None:
        """关闭所有 FSoE 连接"""
        for (si, cid), mdp in list(self._connections.items()):
            try:
                mdp.close_connection(cid)
            except Exception:
                pass
        self._connections.clear()

    def find_by_address(self, safety_address: int) -> Optional[FSoEMdp]:
        """
        按安全地址查找连接

        参数:
            safety_address: FSoE 安全地址
        返回:
            匹配的 FSoEMdp 对象, 未找到返回 None
        """
        for (si, cid), mdp in self._connections.items():
            addr = mdp.get_device_address()
            if addr == safety_address:
                return mdp
        return None

    def find_by_connection_id(self, connection_id: int) -> Optional[FSoEMdp]:
        """
        按连接 ID 查找连接

        参数:
            connection_id: 连接 ID
        返回:
            匹配的 FSoEMdp 对象, 未找到返回 None
        """
        for (si, cid), mdp in self._connections.items():
            if cid == connection_id:
                return mdp
        return None

    def find_connection_by_address(self, safety_address: int) -> Optional[FSoEMdp]:
        """
        按安全地址查找连接 (FSoEManager 级别的查找)

        参数:
            safety_address: FSoE 安全地址
        返回:
            匹配的 FSoEMdp 对象, 未找到返回 None
        """
        return self.find_by_address(safety_address)

    # ===================== 批量操作 (对齐 C# FSoEManager) =====================

    def all_in_data_state(self) -> bool:
        """
        检查所有连接是否处于数据交换状态 (DATA)

        对应 C# FSoEManager.AllInDataState

        返回:
            所有连接都处于 DATA 状态返回 True, 否则返回 False
        """
        if not self._connections:
            return False
        for (si, cid), mdp in self._connections.items():
            state = mdp.get_state(cid)
            if state != int(FSoEState.DATA):
                return False
        return True

    def any_in_failsafe(self) -> bool:
        """
        检查是否有任何连接处于失效安全状态 (FAILSAFE)

        对应 C# FSoEManager.AnyInFailsafe

        返回:
            任一连接处于 FAILSAFE 状态返回 True, 否则返回 False
        """
        for (si, cid), mdp in self._connections.items():
            status = mdp.get_status(cid)
            if status and status.get('in_failsafe', False):
                return True
        return False

    def enter_all_failsafe(self) -> None:
        """
        令所有连接进入失效安全模式

        对应 C# FSoEManager.EnterAllFailsafe
        向所有连接请求 FAILSAFE 状态转换
        """
        for (si, cid), mdp in self._connections.items():
            try:
                mdp.request_state(cid, int(FSoEState.FAILSAFE))
            except Exception:
                pass  # 忽略单个连接的错误, 继续处理其余连接

    def reset_all(self) -> None:
        """
        重置所有连接到初始状态

        对应 C# FSoEManager.ResetAll
        对所有连接执行重置操作
        """
        for (si, cid), mdp in self._connections.items():
            try:
                mdp.reset(cid)
            except Exception:
                pass  # 忽略单个连接的错误, 继续处理其余连接

    def bind_safe_input(self, slave_index: int, connection_id: int,
                        safety_address: int, input_size: int,
                        watchdog_ms: int = 100) -> bool:
        """
        绑定安全输入到指定连接

        参数:
            slave_index:    从站索引
            connection_id:  连接 ID
            safety_address: 安全地址
            input_size:     安全输入数据大小 (字节)
            watchdog_ms:    看门狗超时 (毫秒)
        返回:
            是否成功
        """
        return self.add_connection(
            slave_index, connection_id, safety_address,
            watchdog_ms, input_size, 0
        )

    def bind_safe_output(self, slave_index: int, connection_id: int,
                         safety_address: int, output_size: int,
                         watchdog_ms: int = 100) -> bool:
        """
        绑定安全输出到指定连接

        参数:
            slave_index:    从站索引
            connection_id:  连接 ID
            safety_address: 安全地址
            output_size:    安全输出数据大小 (字节)
            watchdog_ms:    看门狗超时 (毫秒)
        返回:
            是否成功
        """
        return self.add_connection(
            slave_index, connection_id, safety_address,
            watchdog_ms, 0, output_size
        )

    def bind_mdp_safe_input(self, slave_index: int, safety_address: int,
                            input_size: int, module_number: int = 0,
                            watchdog_ms: int = 100) -> bool:
        """
        MDP 版本: 绑定安全输入

        参数:
            slave_index:    从站索引
            safety_address: 安全地址
            input_size:     安全输入数据大小 (字节)
            module_number:  模块编号
            watchdog_ms:    看门狗超时 (毫秒)
        返回:
            是否成功
        """
        cid = module_number + 1
        mdp = FSoEMdp(self._dll, self._mi, slave_index)
        ok = mdp.init_connection(
            cid, safety_address, watchdog_ms,
            input_size, 0, 0, 0, module_number
        )
        if ok:
            self._connections[(slave_index, cid)] = mdp
        return ok

    def bind_mdp_safe_output(self, slave_index: int, safety_address: int,
                             output_size: int, module_number: int = 0,
                             watchdog_ms: int = 100) -> bool:
        """
        MDP 版本: 绑定安全输出

        参数:
            slave_index:    从站索引
            safety_address: 安全地址
            output_size:    安全输出数据大小 (字节)
            module_number:  模块编号
            watchdog_ms:    看门狗超时 (毫秒)
        返回:
            是否成功
        """
        cid = module_number + 1
        mdp = FSoEMdp(self._dll, self._mi, slave_index)
        ok = mdp.init_connection(
            cid, safety_address, watchdog_ms,
            0, output_size, 0, 0, module_number
        )
        if ok:
            self._connections[(slave_index, cid)] = mdp
        return ok

    def bind_safe_io(self, slave_index: int, safe_input_offset: int,
                     safe_input_size: int, safe_output_offset: int,
                     safe_output_size: int, safety_address: int = 0,
                     watchdog_ms: int = 100) -> bool:
        """
        同时绑定安全输入和安全输出

        对应 C# BindSafeIO

        参数:
            slave_index:       从站索引
            safe_input_offset:  输入PDO中安全数据的字节偏移
            safe_input_size:    安全输入数据大小 (字节)
            safe_output_offset: 输出PDO中安全数据的字节偏移
            safe_output_size:   安全输出数据大小 (字节)
            safety_address:     安全地址
            watchdog_ms:        看门狗超时 (毫秒)
        返回:
            两者都成功返回 True
        """
        cid = slave_index + 1
        input_ok = self.bind_safe_input(
            slave_index, cid, safety_address, safe_input_size, watchdog_ms
        )
        output_ok = self.bind_safe_output(
            slave_index, cid, safety_address, safe_output_size, watchdog_ms
        )
        return input_ok and output_ok

    def bind_mdp_drive_axis(self, slave_index: int, axis_index: int,
                            safety_address: int = 0,
                            watchdog_ms: int = 100) -> bool:
        """
        MDP 驱动轴安全绑定 (自动从 MDP 模块信息发现安全 PDO 偏移)

        对应 C# BindMdpDriveAxis

        参数:
            slave_index:    从站索引
            axis_index:     MDP 轴/模块索引
            safety_address: 安全地址
            watchdog_ms:    看门狗超时 (毫秒)
        返回:
            成功返回 True
        """
        # 通过 MDP 模块索引查询安全 PDO 偏移和大小
        conn_index = axis_index + 1
        mdp = FSoEMdp(self._dll, self._mi, slave_index)
        # 安全数据大小由 DLL 从 MDP 模块信息自动发现
        ok = mdp.init_connection(
            conn_index, safety_address, watchdog_ms,
            0, 0, 0, 0, axis_index,
            int(FSoEModuleProfile.DRIVE_CONNECTION), axis_index, 0
        )
        if ok:
            self._connections[(slave_index, conn_index)] = mdp
        return ok

    def write_output_frame(self, slave_index: int, connection_id: int,
                           frame_data: bytes) -> bool:
        """
        写入 FSoE 原始输出帧 (对应 C# WriteOutputFrame)

        将完整的 FSoE 输出帧数据写入指定连接的安全输出区域。
        帧数据应包含命令字节、连接ID、数据和CRC。

        参数:
            slave_index:   从站索引
            connection_id: 连接 ID
            frame_data:    原始帧字节数据
        返回:
            是否成功
        """
        mdp = self._connections.get((slave_index, connection_id))
        if mdp is None:
            return False
        return mdp.write_safe_output(connection_id, frame_data)

    def read_input_frame(self, slave_index: int, connection_id: int,
                         buffer_size: int = 256) -> Optional[bytes]:
        """
        读取指定连接的原始输入帧

        参数:
            slave_index:   从站索引
            connection_id: 连接 ID
            buffer_size:   缓冲区大小
        返回:
            原始帧字节数据, 失败返回 None
        """
        mdp = self._connections.get((slave_index, connection_id))
        if mdp is None:
            return None
        return mdp.read_safe_input(connection_id, buffer_size)

    def get_status_summary(self) -> str:
        """
        返回所有连接的状态摘要字符串

        返回:
            格式化的状态摘要
        """
        if not self._connections:
            return "未初始化"
        lines = [f"FSoE Manager: 连接数={len(self._connections)}"]
        for (si, cid), mdp in self._connections.items():
            status = mdp.get_status(cid)
            if status:
                state_str = str(status.get('state', '未知'))
                error_str = str(status.get('last_error', '无'))
                lines.append(f"  连接[从站={si},ID={cid}]: 状态={state_str}, 错误={error_str}")
            else:
                lines.append(f"  连接[从站={si},ID={cid}]: 状态获取失败")
        return '\n'.join(lines)

    @property
    def connection_count(self) -> int:
        return len(self._connections)

    def __repr__(self) -> str:
        return f"FSoEManager(master={self._mi}, connections={len(self._connections)})"


# =============================================================================
# FSoE CRC16 (CCITT-False)
# =============================================================================

def fsoe_crc16(data: bytes) -> int:
    """计算 FSoE CRC16 校验值 (CCITT-False 算法)"""
    crc = 0xFFFF
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF
    return crc


def _build_crc16_table() -> List[int]:
    """构建 CCITT-False CRC16 查找表"""
    table = []
    for i in range(256):
        crc = i << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF
        table.append(crc)
    return table


_CRC16_TABLE: List[int] = _build_crc16_table()


def fsoe_crc16_fast(data: bytes) -> int:
    """使用查找表加速计算 FSoE CRC16"""
    crc = 0xFFFF
    for byte in data:
        tbl_idx = ((crc >> 8) ^ byte) & 0xFF
        crc = ((crc << 8) ^ _CRC16_TABLE[tbl_idx]) & 0xFFFF
    return crc


# ===================== FSoE 诊断位定义 (ETG.5001.4 Table 9) =====================

class FSoEDiagnosisBits(IntEnum):
    """FSoE 诊断位定义 (ETG.5001.4 Table 9)"""
    NO_ERROR = 0x0000               # 无错误
    WRONG_COMMAND = 0x0001          # 错误的命令
    UNKNOWN_COMMAND = 0x0002        # 未知命令
    WRONG_CONNECTION_ID = 0x0003    # 连接ID不匹配
    WRONG_CRC = 0x0004              # CRC校验失败
    WATCHDOG_EXPIRED = 0x0005       # 看门狗过期
    WRONG_FSOE_ADDRESS = 0x0006     # 错误的FSoE地址
    WRONG_DATA = 0x0007             # 无效数据
    WRONG_COMM_PARAM_LENGTH = 0x0008  # 通信参数长度错误
    WRONG_COMM_PARAM = 0x0009       # 通信参数错误
    WRONG_APPL_PARAM_LENGTH = 0x000A  # 应用参数长度错误
    WRONG_APPL_PARAM = 0x000B       # 应用参数错误
    UNEXPECTED_SESSION_CMD = 0x000C   # 意外的会话命令
    FAILSAFE_DATA_RECEIVED = 0x000D   # 收到失效安全数据
    ERROR_MASK = 0x000F             # 错误掩码
    ERROR_IN_MASTER = 0x0000        # 错误发生在主站
    ERROR_IN_SLAVE = 0x0010         # 错误发生在从站
    SLAVE_IN_FAILSAFE = 0x0020      # 从站处于失效安全
    CONNECTION_IN_STARTUP = 0x0040  # 连接处于启动
    MASTER_IN_FAILSAFE = 0x0080    # 主站处于失效安全


# ===================== FSoE 常量定义 =====================

class FSoEConstants:
    """FSoE 常量定义"""
    MAX_CONNECTIONS = 64        # 每个主站的最大FSoE连接数
    MAX_SAFE_DATA_SIZE = 64     # 每个连接的最大SafeData大小(字节)
    MAX_CRC_SEGMENTS = 32       # 最大CRC段数 (数据大于2字节时)
    FRAME_HEADER_SIZE = 3       # FSoE帧头大小 (Command + ConnID)
    FRAME_CRC_SIZE = 2          # FSoE帧CRC大小
    CRC16_POLY = 0x1021         # FSoE CRC16多项式 (ETG.5100)
    CRC16_INITIAL = 0xFFFF      # FSoE CRC16初始值
    SRA_CRC32_POLY = 0x814141AB  # FSoE SRA CRC32多项式 (ETG.5120 section 6.3)
    DEFAULT_WATCHDOG_TIME_MS = 100  # 默认看门狗超时(毫秒)
    COMMAND_TYPE_MASK = 0x0F    # 命令类型掩码
    TOGGLE_BIT_MASK = 0x80      # 切换位掩码
    MASTER_RESET_MASK = 0x40    # 主站重置请求掩码
    SLAVE_RESET_MASK = 0x20     # 从站重置请求掩码


# ===================== FSoE 帮助类 =====================

class FSoEHelper:
    """FSoE 帮助类"""

    @staticmethod
    def get_command_type(command: int) -> FSoECommand:
        """提取命令类型"""
        return FSoECommand(command & FSoEConstants.COMMAND_TYPE_MASK)

    @staticmethod
    def get_toggle_bit(command: int) -> bool:
        """提取切换位"""
        return (command & FSoEConstants.TOGGLE_BIT_MASK) != 0

    @staticmethod
    def is_master_reset_request(command: int) -> bool:
        """检查是否为主站重置请求"""
        return (command & FSoEConstants.MASTER_RESET_MASK) != 0

    @staticmethod
    def is_slave_reset_request(command: int) -> bool:
        """检查是否为从站重置请求"""
        return (command & FSoEConstants.SLAVE_RESET_MASK) != 0

    @staticmethod
    def build_command(cmd_type: FSoECommand, toggle_bit: bool,
                      master_reset: bool = False, slave_reset: bool = False) -> int:
        """构建命令字节"""
        cmd = int(cmd_type)
        if toggle_bit:
            cmd |= FSoEConstants.TOGGLE_BIT_MASK
        if master_reset:
            cmd |= FSoEConstants.MASTER_RESET_MASK
        if slave_reset:
            cmd |= FSoEConstants.SLAVE_RESET_MASK
        return cmd

    @staticmethod
    def is_valid_state_transition(current: FSoEState, target: FSoEState) -> bool:
        """检查状态转换是否有效"""
        valid_transitions = {
            FSoEState.RESET: (FSoEState.SESSION,),
            FSoEState.SESSION: (FSoEState.CONNECTION, FSoEState.RESET),
            FSoEState.CONNECTION: (FSoEState.PARAMETER, FSoEState.RESET),
            FSoEState.PARAMETER: (FSoEState.DATA, FSoEState.RESET),
            FSoEState.DATA: (FSoEState.FAILSAFE, FSoEState.RESET),
            FSoEState.FAILSAFE: (FSoEState.DATA, FSoEState.RESET),
        }
        return target in valid_transitions.get(current, ())

    @staticmethod
    def get_error_description(error: FSoEError) -> str:
        """获取错误描述"""
        descriptions = {
            FSoEError.NONE: "无错误",
            FSoEError.WRONG_COMMAND: "错误的命令",
            FSoEError.UNKNOWN_COMMAND: "未知命令",
            FSoEError.WRONG_CONNECTION_ID: "连接ID不匹配",
            FSoEError.CRC_ERROR: "CRC校验失败",
            FSoEError.WATCHDOG: "看门狗超时",
            FSoEError.WRONG_ADDRESS: "错误的FSoE地址",
            FSoEError.WRONG_DATA: "无效数据",
            FSoEError.COMM_PARAM_LENGTH: "通信参数长度错误",
            FSoEError.COMM_PARAM: "通信参数错误",
            FSoEError.APP_PARAM_LENGTH: "应用参数长度错误",
            FSoEError.APP_PARAM: "应用参数错误",
            FSoEError.UNEXPECTED_SESSION: "意外的会话命令",
            FSoEError.FAILSAFE_DATA: "收到失效安全数据",
            FSoEError.NOT_INITIALIZED: "FSoE未初始化",
            FSoEError.MAX_CONNECTIONS: "达到最大连接数",
            FSoEError.INVALID_STATE_TRANSITION: "无效状态转换",
        }
        return descriptions.get(error, f"未知错误 (0x{int(error):04X})")


# ===================== FSoE 事件参数 =====================

@dataclass
class FSoEStateChangedEventArgs:
    """FSoE 状态变化事件参数"""
    slave_index: int = 0            # 从站索引
    connection_index: int = 0       # 连接索引 (多连接模式)
    old_state: FSoEState = FSoEState.RESET  # 旧状态
    new_state: FSoEState = FSoEState.RESET  # 新状态


@dataclass
class FSoEErrorEventArgs:
    """FSoE 错误事件参数"""
    slave_index: int = 0            # 从站索引
    connection_index: int = 0       # 连接索引
    error: FSoEError = FSoEError.NONE  # 错误代码
    current_state: FSoEState = FSoEState.RESET  # 当前状态

    @property
    def description(self) -> str:
        """错误描述"""
        return FSoEHelper.get_error_description(self.error)


@dataclass
class FSoEFailsafeEventArgs:
    """FSoE 失效安全事件参数"""
    slave_index: int = 0            # 从站索引
    connection_index: int = 0       # 连接索引
    reason: FSoEFailsafeReason = FSoEFailsafeReason.WATCHDOG_TIMEOUT  # 触发原因
    entering_failsafe: bool = True  # 是否进入失效安全


@dataclass
class FSoEDataUpdatedEventArgs:
    """FSoE 安全数据更新事件参数"""
    slave_index: int = 0            # 从站索引
    connection_index: int = 0       # 连接索引
    is_input: bool = True           # 是否为输入数据
    data: bytes = b""               # 数据内容


# ===================== FSoE 模块结构体 =====================

@dataclass
class FSoEModuleCommParam:
    """FSoE 模块通信参数 (0x9nn1)"""
    version: bytes = b"\x00\x00"     # 版本 (2字节)
    safety_address: int = 0          # 安全地址
    connection_id: int = 0           # 连接ID
    watchdog_time: int = 0           # 看门狗超时
    unique_device_id: bytes = b"\x00" * 6  # 唯一设备ID (6字节)
    connection_type: int = 0         # 连接类型
    comm_param_length: int = 0       # 通信参数长度
    appl_param_length: int = 0       # 应用参数长度
    sra_crc: int = 0                 # SRA CRC


@dataclass
class FSoEModuleDiag:
    """FSoE 模块诊断 (0xAnn0)"""
    connection_state: int = 0        # 连接状态
    connection_diagnosis: int = 0    # 连接诊断


@dataclass
class FSoEModuleInfo:
    """FSoE 模块信息 (0x9nn0)"""
    connection_id: int = 0           # 连接ID
    device_type: int = 0             # 设备类型
    vendor_id: int = 0               # 供应商ID
    product_code: int = 0            # 产品代码
    revision_number: int = 0         # 修订号
    serial_number: int = 0           # 序列号


# ===================== FSoE MDP 对象索引定义 (ETG.5001.4) =====================

class FSoEMdpIndex:
    """FSoE MDP 对象索引区域定义 (ETG.5001.4)"""
    AXIS_INDEX_OFFSET = 0x0800       # 轴索引偏移
    CONFIG_AREA_BASE = 0x8000        # 配置区域基地址
    DEVICE_FSOE_ADDRESS = 0xF980     # 设备FSoE地址
    DIAG_AREA_BASE = 0xA000          # 诊断区域基地址
    DRIVE_CONFIG_AREA_BASE = 0xE800  # 驱动配置区域基地址
    DRIVE_DIAG_AREA_BASE = 0xEA00   # 驱动诊断区域基地址
    DRIVE_INFO_AREA_BASE = 0xE900   # 驱动信息区域基地址
    DRIVE_INPUT_AREA_BASE = 0xE600  # 驱动输入区域基地址
    DRIVE_OUTPUT_AREA_BASE = 0xE700  # 驱动输出区域基地址
    INFO_AREA_BASE = 0x9000          # 信息区域基地址
    INPUT_AREA_BASE = 0x6000         # 输入区域基地址
    MODULE_INDEX_OFFSET = 0x0010     # 模块索引偏移
    OUTPUT_AREA_BASE = 0x7000        # 输出区域基地址
    PARAM_SET_MAPPING_BASE = 0x1E00  # 参数集映射基地址
    RX_PDO_MAPPING_BASE = 0x1600     # 接收PDO映射基地址
    TX_PDO_MAPPING_BASE = 0x1A00     # 发送PDO映射基地址

    @staticmethod
    def get_axis_index(base_index: int, axis_number: int) -> int:
        """获取轴索引"""
        return base_index + axis_number * FSoEMdpIndex.AXIS_INDEX_OFFSET

    @staticmethod
    def get_module_index(base_index: int, module_number: int) -> int:
        """获取模块索引"""
        return base_index + module_number * FSoEMdpIndex.MODULE_INDEX_OFFSET


# ===================== FSoE MDP 设备配置 =====================

@dataclass
class FSoEModuleConfig:
    """FSoE MDP 模块配置"""
    module_number: int = 0           # 模块编号
    axis_number: int = 0             # 轴编号
    profile: FSoEModuleProfile = FSoEModuleProfile.DIGITAL_IN_OUT  # 模块配置文件
    safety_address: int = 0          # 安全地址
    connection_id: int = 0           # 连接ID
    connection_type: FSoEConnectionType = FSoEConnectionType.SLAVE  # 连接类型
    safe_input_size: int = 0         # 安全输入数据大小(字节)
    safe_output_size: int = 0        # 安全输出数据大小(字节)
    pdo_input_offset: int = 0        # PDO输入偏移
    pdo_output_offset: int = 0       # PDO输出偏移
    watchdog_time_ms: int = 100      # 看门狗超时(毫秒)

    def to_connection_config(self) -> FSoEConnectionConfig:
        """转换为连接配置"""
        return FSoEConnectionConfig(
            connection_id=self.connection_id,
            safety_address=self.safety_address,
            watchdog_time_ms=self.watchdog_time_ms,
            safe_input_size=self.safe_input_size,
            safe_output_size=self.safe_output_size,
            pdo_input_offset=self.pdo_input_offset,
            pdo_output_offset=self.pdo_output_offset,
        )


@dataclass
class FSoEMdpDeviceConfig:
    """FSoE MDP 设备配置"""
    connection_mode: FSoEConnectionMode = FSoEConnectionMode.SINGLE  # 连接模式
    device_safety_address: int = 0   # 设备级安全地址
    is_drive: bool = False           # 是否为驱动设备
    axis_count: int = 1              # 轴数量
    modules: List[FSoEModuleConfig] = field(default_factory=list)  # 模块列表

    def add_module(self, profile: FSoEModuleProfile, safety_address: int) -> FSoEModuleConfig:
        """添加模块配置"""
        module = FSoEModuleConfig(
            module_number=len(self.modules),
            profile=profile,
            safety_address=safety_address,
            connection_id=0x0001 + len(self.modules),
        )
        self.modules.append(module)
        return module

    def add_drive_axis(self, axis_number: int, safety_address: int) -> FSoEModuleConfig:
        """添加驱动轴配置"""
        module = FSoEModuleConfig(
            module_number=len(self.modules),
            axis_number=axis_number,
            profile=FSoEModuleProfile.DRIVE_CONNECTION,
            safety_address=safety_address,
            connection_id=0x0001 + len(self.modules),
        )
        self.modules.append(module)
        return module

    def get_connection_count(self) -> int:
        """获取连接数量"""
        if self.connection_mode == FSoEConnectionMode.SINGLE:
            return 1
        return len(self.modules)


# ===================== FSoE PDO 帧布局 =====================

@dataclass
class FSoEPdoLayout:
    """FSoE PDO 帧布局配置"""
    command_offset: int = 0          # 命令偏移
    flags_offset: int = 1            # 标志偏移
    connection_id_offset: int = 2    # 连接ID偏移
    sequence_offset: int = 4         # 序列号偏移
    data_offset: int = 6             # 数据偏移
    data_length: int = 0             # 数据区长度
    crc_length: int = 2              # CRC长度

    @property
    def total_length(self) -> int:
        """帧总长度"""
        return self.data_offset + self.data_length + self.crc_length

    def validate(self) -> None:
        """验证布局参数"""
        if self.command_offset < 0 or self.flags_offset < 0 or \
           self.connection_id_offset < 0 or self.sequence_offset < 0 or self.data_offset < 0:
            raise ValueError("PDO 布局偏移不能为负数。")
        if self.data_length < 0:
            raise ValueError("数据区长度不能为负数。")
        if self.crc_length <= 0:
            raise ValueError("CRC 长度必须大于 0。")
        if self.data_offset < self.sequence_offset:
            raise ValueError("DataOffset 必须大于等于 SequenceOffset。")


@dataclass
class FSoEPdoFrame:
    """FSoE PDO 帧结构"""
    command: FSoECommand = FSoECommand.RESET  # 命令
    flags: int = 0                    # 标志字节
    connection_id: int = 0            # 连接ID
    sequence: int = 0                 # 序列号
    data: bytes = b""                 # 数据
    crc: int = 0                      # CRC校验值

    def to_bytes(self, layout: FSoEPdoLayout, crc_func=None) -> bytes:
        """序列化为字节数组"""
        layout.validate()
        if len(self.data) != layout.data_length:
            raise ValueError(f"Data 长度必须为 {layout.data_length} 字节，但收到 {len(self.data)}。")

        buf = bytearray(layout.total_length)
        buf[layout.command_offset] = int(self.command) & 0xFF
        buf[layout.flags_offset] = self.flags & 0xFF
        buf[layout.connection_id_offset] = self.connection_id & 0xFF
        buf[layout.connection_id_offset + 1] = (self.connection_id >> 8) & 0xFF
        buf[layout.sequence_offset] = self.sequence & 0xFF
        buf[layout.sequence_offset + 1] = (self.sequence >> 8) & 0xFF
        buf[layout.data_offset:layout.data_offset + layout.data_length] = self.data

        if crc_func is not None:
            self.crc = crc_func(bytes(buf[:layout.total_length - layout.crc_length]))

        crc_offset = layout.data_offset + layout.data_length
        buf[crc_offset] = self.crc & 0xFF
        buf[crc_offset + 1] = (self.crc >> 8) & 0xFF
        return bytes(buf)

    @classmethod
    def from_bytes(cls, data: bytes, layout: FSoEPdoLayout, crc_func=None) -> "FSoEPdoFrame":
        """从字节数组反序列化"""
        layout.validate()
        if len(data) < layout.total_length:
            raise ValueError(f"数据长度不足，期望 {layout.total_length} 字节，实际 {len(data)}。")

        frame = cls()
        frame.command = FSoECommand(data[layout.command_offset])
        frame.flags = data[layout.flags_offset]
        frame.connection_id = data[layout.connection_id_offset] | (data[layout.connection_id_offset + 1] << 8)
        frame.sequence = data[layout.sequence_offset] | (data[layout.sequence_offset + 1] << 8)
        frame.data = data[layout.data_offset:layout.data_offset + layout.data_length]
        crc_offset = layout.data_offset + layout.data_length
        frame.crc = data[crc_offset] | (data[crc_offset + 1] << 8)

        if crc_func is not None:
            computed = crc_func(data[:layout.total_length - layout.crc_length])
            if computed != frame.crc:
                raise ValueError(
                    f"FSoE CRC 校验失败：期望 0x{frame.crc:04X}，计算值 0x{computed:04X}。"
                )

        return frame


# ===================== 可配置 CRC-16 实现 =====================

class FSoECrc16:
    """可配置的 CRC-16 实现（默认：CRC-16/CCITT-FALSE）"""

    def __init__(self, polynomial: int = 0x1021, initial: int = 0xFFFF, xor_out: int = 0x0000):
        self._polynomial = polynomial
        self._initial = initial
        self._xor_out = xor_out

    def compute(self, data: bytes) -> int:
        """计算 CRC-16"""
        crc = self._initial
        for b in data:
            crc ^= b << 8
            for _ in range(8):
                if crc & 0x8000:
                    crc = ((crc << 1) ^ self._polynomial) & 0xFFFF
                else:
                    crc = (crc << 1) & 0xFFFF
        return (crc ^ self._xor_out) & 0xFFFF


# 预置的 CCITT-False 实例
FSOE_CRC16_CCITT_FALSE = FSoECrc16(0x1021, 0xFFFF, 0x0000)


# ===================== ConnID 校验 (对齐 C# FSoEValidateConnId) =====================

def validate_conn_id(conn_id: int) -> bool:
    """
    校验指定 ConnID 是否可用 (未被占用). 对齐 C# FSoEValidateConnId.

    ETG.5120 §5.2.3: ConnectionID 0 保留, 合法范围 [1, 65535]. 已被其他
    连接占用的 ID 返回 False.

    Args:
        conn_id: 待校验的连接 ID (0 总是非法).

    Returns:
        True = 可用 (available / not taken); False = 已占用 / 非法 / DLL 未导出.
    """
    try:
        from ..utils.dll import DarraCoreDLL
        dll = DarraCoreDLL()  # 复用内部加载的单例
    except Exception:
        return False
    fn = getattr(dll._dll, 'FSoEValidateConnId', None)
    if fn is None:
        return False
    try:
        return bool(fn(ctypes.c_uint16(conn_id)))
    except Exception:
        return False


# 模块级别名 (对齐 C# 方法名 IsConnectionIdAvailable 便于跨语言检索)
def is_connection_id_available(conn_id: int) -> bool:
    """
    别名, 对齐 C# FSoE.IsConnectionIdAvailable 方法名.
    Alias of :func:`validate_conn_id`, mirrors the C# public API name.
    """
    return validate_conn_id(conn_id)


# =============================================================================
# IMailboxProtocol 接口实现 (对齐 C# IMailboxProtocol)
# =============================================================================
# FSoE 协议类在 core.py 定义, 这里通过模块导入时注入
# protocol_type/protocol_name/is_supported/statistics/reset_statistics.

_FSOE_PROTOCOL_TYPE = 0x08  # ECT_MBXT_FSOE


def _fsoe_protocol_type(self) -> int:
    return _FSOE_PROTOCOL_TYPE


def _fsoe_protocol_name(self) -> str:
    return "FSoE"


def _fsoe_is_supported(self) -> bool:
    """
    FSoE 走 CoE 邮箱承载, 故按 SII mbx_proto CoE 位 (0x04) 判断.
    DLL 调用失败时保守返回 True.
    """
    try:
        mbx_proto = self._dll.GetSlaveMailboxProto(self._mi, self._si)
        return (mbx_proto & 0x04) != 0
    except Exception:
        return True


def _fsoe_statistics(self) -> MailboxStatistics:
    """读取 FSoE 邮箱统计快照."""
    try:
        stats = EcMbxStatsT()
        rc = self._dll.ecx_mbx_get_stats_by_master(
            self._mi, self._si, _FSOE_PROTOCOL_TYPE, ctypes.byref(stats)
        )
        if rc == 1:
            avg = (stats.total_latency_us / stats.total_received
                   if stats.total_received > 0 else 0.0)
            t = None
            if stats.last_error_time_us > 0:
                from datetime import datetime as _dt, timezone as _tz
                t = _dt.fromtimestamp(
                    stats.last_error_time_us / 1_000_000, tz=_tz.utc
                )
            return MailboxStatistics(
                total_sent=stats.total_sent,
                total_received=stats.total_received,
                total_timeout=stats.total_timeout,
                total_mailbox_error=stats.total_mbx_error,
                total_protocol_error=stats.total_proto_error,
                total_cancelled=stats.total_cancelled,
                last_error_code=stats.last_error_code,
                last_error_time=t,
                average_latency_us=avg,
            )
    except Exception:
        pass
    return MailboxStatistics.empty()


def _fsoe_reset_statistics(self) -> None:
    """重置 FSoE 邮箱统计."""
    try:
        self._dll.ecx_mbx_reset_stats_by_master(
            self._mi, self._si, _FSOE_PROTOCOL_TYPE
        )
    except Exception:
        pass


_FSoECore.protocol_type = property(_fsoe_protocol_type)
_FSoECore.protocol_name = property(_fsoe_protocol_name)
_FSoECore.is_supported = property(_fsoe_is_supported)
_FSoECore.statistics = property(_fsoe_statistics)
_FSoECore.reset_statistics = _fsoe_reset_statistics

IMailboxProtocol.register(_FSoECore)
