# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/VoE.cs
VoE (Vendor specific over EtherCAT) 协议接口
提供厂商自定义数据传输
支持 ETG.1000.6 Mailbox 通信规范 (Mailbox Type 0x0F)
"""

import asyncio
import ctypes
import struct
import threading
from concurrent.futures import ThreadPoolExecutor
from ctypes import c_int, c_uint, c_ushort, c_void_p, byref
from typing import Optional

from ..utils.dll import DarraCoreDLL, EcMbxStatsT
from ..abstractions import IMailboxProtocol, MailboxStatistics


# =============================================================================
# 异步支持 (asyncio) — 对齐 C# VoEInstance.*Async
# =============================================================================
# VoE 为厂商自定义, 帧大小和延迟不定, 使用独立线程池。

_voe_async_executor: Optional[ThreadPoolExecutor] = None
_voe_executor_lock = threading.Lock()


def _get_voe_executor() -> ThreadPoolExecutor:
    """懒创建 VoE 协议专用线程池"""
    global _voe_async_executor
    if _voe_async_executor is None:
        with _voe_executor_lock:
            if _voe_async_executor is None:
                _voe_async_executor = ThreadPoolExecutor(
                    max_workers=4, thread_name_prefix="darra-voe-async"
                )
    return _voe_async_executor


def shutdown_voe_async_executor(wait: bool = True) -> None:
    """关闭 VoE 异步线程池"""
    global _voe_async_executor
    with _voe_executor_lock:
        if _voe_async_executor is not None:
            _voe_async_executor.shutdown(wait=wait)
            _voe_async_executor = None


async def _run_voe_async(func, *args, timeout_ms: Optional[int] = None):
    """通用 VoE 异步执行辅助"""
    loop = asyncio.get_event_loop()
    fut = loop.run_in_executor(_get_voe_executor(), func, *args)
    if timeout_ms and timeout_ms > 0:
        return await asyncio.wait_for(fut, timeout=timeout_ms / 1000.0)
    return await fut


class VoEResponse:
    """
    VoE 响应数据结构
    对应 C# VoEResponse 类
    """

    def __init__(self, vendor_id: int = 0, vendor_type: int = 0,
                 data: bytes = b''):
        self.vendor_id = vendor_id
        """厂商ID"""
        self.vendor_type = vendor_type
        """厂商类型"""
        self.data = data
        """响应数据"""

    @property
    def data_length(self) -> int:
        """数据长度"""
        return len(self.data)

    def to_hex_string(self) -> str:
        """格式化为十六进制字符串"""
        return ' '.join(f'{b:02X}' for b in self.data)

    def __str__(self) -> str:
        return (f"VoE Response: VendorID=0x{self.vendor_id:08X}, "
                f"VendorType=0x{self.vendor_type:04X}, "
                f"DataLength={self.data_length}")


class VoE:
    """
    VoE (Vendor specific over EtherCAT) 协议接口
    提供厂商自定义数据传输
    支持 ETG.1000.6 Mailbox 通信规范 (Mailbox Type 0x0F)
    """

    # VoE 头部大小（VendorID 4字节 + VendorType 2字节）
    VOE_HEADER_SIZE = 6

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int,
                 timeout: int = 5000):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        self._timeout = timeout

    # ---- 属性 ----

    @property
    def default_timeout_ms(self) -> int:
        """默认超时时间（毫秒）"""
        return self._timeout

    @default_timeout_ms.setter
    def default_timeout_ms(self, value: int):
        self._timeout = value

    @property
    def voe_header_size(self) -> int:
        """VoE 头部大小（只读）"""
        return self.VOE_HEADER_SIZE

    @property
    def is_supported(self) -> bool:
        """
        检查从站是否支持 VoE 邮箱协议 (对齐 C# VoEInstance.IsSupported).

        读取 SII mbx_proto bit 5 (ECT_MBXPROT_VOE = 0x20) 判断支持情况,
        DLL 调用失败时保守返回 True (未知能力视为支持, 不阻塞用户调用).
        """
        try:
            mbx_proto = self._dll.GetSlaveMailboxProto(self._mi, self._si)
            return (mbx_proto & 0x20) != 0
        except Exception:
            return True

    # ---- 基本操作 ----

    def send(self, vendor_id: int, vendor_type: int, data: bytes,
             timeout_ms: int = 0) -> bool:
        """
        发送 VoE 数据到从站

        参数:
            vendor_id: 厂商ID (4字节)
            vendor_type: 厂商类型 (2字节)
            data: 要发送的数据
            timeout_ms: 超时时间 (毫秒, 0=使用默认)
        """
        t = timeout_ms if timeout_ms > 0 else self._timeout
        buf = ctypes.create_string_buffer(data)
        # DLL 期望微秒, 将毫秒转换为微秒
        return bool(self._dll.VOESend(
            self._mi, self._si, vendor_id, vendor_type,
            ctypes.cast(buf, c_void_p), len(data), t * 1000
        ))

    def receive(self, timeout_ms: int = 0) -> Optional[VoEResponse]:
        """
        从从站接收 VoE 数据

        参数:
            timeout_ms: 超时时间 (毫秒, 0=使用默认)

        返回:
            VoEResponse 对象，失败返回 None
        """
        t = timeout_ms if timeout_ms > 0 else self._timeout
        vid = c_uint(0)
        vtype = c_ushort(0)
        data_ptr = c_void_p(0)
        data_size = c_int(0)
        # DLL 期望微秒, 将毫秒转换为微秒
        ok = self._dll.VOEReceive(
            self._mi, self._si, byref(vid), byref(vtype),
            byref(data_ptr), byref(data_size), t * 1000
        )
        if not ok or not data_ptr.value:
            return None
        try:
            data = bytes(ctypes.string_at(data_ptr.value, data_size.value))
            return VoEResponse(vid.value, vtype.value, data)
        finally:
            self._dll.FreeMemory(data_ptr)

    def send_and_receive(self, vendor_id: int, vendor_type: int,
                         data: bytes, timeout_ms: int = 0) -> Optional[VoEResponse]:
        """
        发送 VoE 数据并等待响应

        参数:
            vendor_id: 厂商ID
            vendor_type: 厂商类型
            data: 要发送的数据
            timeout_ms: 超时时间 (毫秒, 0=使用默认)

        返回:
            VoEResponse 对象，失败返回 None
        """
        t = timeout_ms if timeout_ms > 0 else self._timeout
        if not self.send(vendor_id, vendor_type, data, t):
            return None
        return self.receive(t)

    # ---- 原始帧操作 ----

    def send_raw(self, frame_data: bytes, timeout_ms: int = 0) -> bool:
        """
        发送原始 VoE 帧（用户自行组织帧格式，包括 VoE 头）

        参数:
            frame_data: 完整的 VoE 帧数据
            timeout_ms: 超时时间 (毫秒, 0=使用默认)
        """
        if not frame_data:
            raise ValueError("帧数据不能为空")
        t = timeout_ms if timeout_ms > 0 else self._timeout
        buf = ctypes.create_string_buffer(frame_data)
        # DLL 期望微秒, 将毫秒转换为微秒
        return bool(self._dll.VOESendRaw(
            self._mi, self._si,
            ctypes.cast(buf, c_void_p), len(frame_data), t * 1000
        ))

    def receive_raw(self, timeout_ms: int = 0) -> Optional[bytes]:
        """
        接收原始 VoE 帧

        参数:
            timeout_ms: 超时时间 (毫秒, 0=使用默认)

        返回:
            原始帧数据，失败返回 None
        """
        t = timeout_ms if timeout_ms > 0 else self._timeout
        data_ptr = c_void_p(0)
        data_size = c_int(0)
        # DLL 期望微秒, 将毫秒转换为微秒
        ok = self._dll.VOEReceiveRaw(
            self._mi, self._si, byref(data_ptr), byref(data_size), t * 1000
        )
        if not ok or not data_ptr.value or data_size.value <= 0:
            if data_ptr.value:
                self._dll.FreeMemory(data_ptr)
            return None
        try:
            return bytes(ctypes.string_at(data_ptr.value, data_size.value))
        finally:
            self._dll.FreeMemory(data_ptr)

    def send_raw_and_receive(self, frame_data: bytes,
                             timeout_ms: int = 0) -> Optional[bytes]:
        """
        发送原始帧并等待响应

        参数:
            frame_data: 要发送的帧数据
            timeout_ms: 超时时间 (毫秒, 0=使用默认)

        返回:
            响应帧数据，失败返回 None
        """
        t = timeout_ms if timeout_ms > 0 else self._timeout
        if not self.send_raw(frame_data, t):
            return None
        return self.receive_raw(t)

    # ---- 异步接口 (对齐 C# VoEInstance *Async) ----

    async def send_async(self, vendor_id: int, vendor_type: int, data: bytes,
                         timeout_ms: int = 0) -> bool:
        """异步发送 VoE 数据 (对齐 C# SendAsync)"""
        t = timeout_ms if timeout_ms > 0 else self._timeout
        return await _run_voe_async(
            self.send, vendor_id, vendor_type, data, timeout_ms,
            timeout_ms=t + 200,  # 给 DLL 余量
        )

    async def receive_async(self, timeout_ms: int = 0) -> Optional['VoEResponse']:
        """异步接收 VoE 数据 (对齐 C# ReceiveAsync)"""
        t = timeout_ms if timeout_ms > 0 else self._timeout
        return await _run_voe_async(
            self.receive, timeout_ms, timeout_ms=t + 200,
        )

    async def send_and_receive_async(self, vendor_id: int, vendor_type: int,
                                     data: bytes, timeout_ms: int = 0
                                     ) -> Optional['VoEResponse']:
        """异步发送并接收 (对齐 C# SendAndReceiveAsync)"""
        t = timeout_ms if timeout_ms > 0 else self._timeout
        return await _run_voe_async(
            self.send_and_receive, vendor_id, vendor_type, data, timeout_ms,
            timeout_ms=t * 2 + 400,
        )

    async def send_raw_async(self, frame_data: bytes,
                             timeout_ms: int = 0) -> bool:
        """异步发送原始 VoE 帧 (对齐 C# SendRawAsync)"""
        t = timeout_ms if timeout_ms > 0 else self._timeout
        return await _run_voe_async(
            self.send_raw, frame_data, timeout_ms, timeout_ms=t + 200,
        )

    async def receive_raw_async(self,
                                timeout_ms: int = 0) -> Optional[bytes]:
        """异步接收原始 VoE 帧 (对齐 C# ReceiveRawAsync)"""
        t = timeout_ms if timeout_ms > 0 else self._timeout
        return await _run_voe_async(
            self.receive_raw, timeout_ms, timeout_ms=t + 200,
        )

    async def send_raw_and_receive_async(self, frame_data: bytes,
                                         timeout_ms: int = 0
                                         ) -> Optional[bytes]:
        """异步原始帧发送并接收 (对齐 C# SendRawAndReceiveAsync)"""
        t = timeout_ms if timeout_ms > 0 else self._timeout
        return await _run_voe_async(
            self.send_raw_and_receive, frame_data, timeout_ms,
            timeout_ms=t * 2 + 400,
        )

    # ---- 辅助方法 ----

    @staticmethod
    def build_frame(vendor_id: int, vendor_type: int,
                    data: Optional[bytes] = None) -> bytes:
        """
        构建标准 VoE 帧（VoE 头 + 数据）

        参数:
            vendor_id: 厂商ID
            vendor_type: 厂商类型
            data: 用户数据

        返回:
            完整的 VoE 帧
        """
        header = struct.pack('<IH', vendor_id, vendor_type)
        if data:
            return header + data
        return header

    @staticmethod
    def parse_frame(frame: bytes) -> Optional[VoEResponse]:
        """
        解析 VoE 帧头部

        参数:
            frame: VoE 帧数据

        返回:
            VoEResponse 对象，帧太短则返回 None
        """
        if not frame or len(frame) < 6:
            return None
        vendor_id, vendor_type = struct.unpack_from('<IH', frame, 0)
        data = frame[6:]
        return VoEResponse(vendor_id, vendor_type, data)


# =============================================================================
# IMailboxProtocol 接口实现 (对齐 C# IMailboxProtocol)
# =============================================================================

_VOE_PROTOCOL_TYPE = 0x0F  # ECT_MBXT_VOE


def _voe_protocol_type(self) -> int:
    return _VOE_PROTOCOL_TYPE


def _voe_protocol_name(self) -> str:
    return "VoE"


def _voe_statistics(self) -> MailboxStatistics:
    """读取 VoE 邮箱统计快照."""
    try:
        stats = EcMbxStatsT()
        rc = self._dll.ecx_mbx_get_stats_by_master(
            self._mi, self._si, _VOE_PROTOCOL_TYPE, ctypes.byref(stats)
        )
        if rc == 1:
            avg = (stats.total_latency_us / stats.total_received
                   if stats.total_received > 0 else 0.0)
            t = None
            if stats.last_error_time_us > 0:
                from datetime import datetime, timezone
                t = datetime.fromtimestamp(
                    stats.last_error_time_us / 1_000_000, tz=timezone.utc
                )
            return MailboxStatistics(
                total_sent=stats.total_sent,
                total_received=stats.total_received,
                total_timeout=stats.total_timeout,
                total_mailbox_error=stats.total_mbx_error,
                total_protocol_error=stats.total_proto_error,
                total_cancelled=stats.total_cancelled,
                last_error_code=stats.last_error_code,
                last_error_time=t,
                average_latency_us=avg,
            )
    except Exception:
        pass
    return MailboxStatistics.empty()


def _voe_reset_statistics(self) -> None:
    """重置 VoE 邮箱统计."""
    try:
        self._dll.ecx_mbx_reset_stats_by_master(
            self._mi, self._si, _VOE_PROTOCOL_TYPE
        )
    except Exception:
        pass


VoE.protocol_type = property(_voe_protocol_type)
VoE.protocol_name = property(_voe_protocol_name)
VoE.statistics = property(_voe_statistics)
VoE.reset_statistics = _voe_reset_statistics

IMailboxProtocol.register(VoE)


# =============================================================================
# Vendor-initiated 异步通知 (对齐 C# VoE NotificationReceived event)
# =============================================================================
#
# 已通过 utils/dll.py 绑定 DLL.VOEStartNotificationListener / VOEStopNotificationListener /
# VOEIsNotificationListening / VOERegisterNotification / VOEUnregisterNotification.
# 注册的 native 回调用模块级字典持有, 防止 GC 释放函数指针.

from ..utils.dll import VoENotificationCallbackType as _VoENotifCbT

# {(master_index, slave_index): (native_cb_ref, subscription_index)}
_voe_native_subs: dict = {}
# 全局: master 是否已 StartNotificationListener (按 master_index)
_voe_listener_started: dict = {}


class VoENotificationEventArgs:
    """Vendor-initiated VoE 通知事件参数 (对齐 C# VoENotificationEventArgs)."""

    def __init__(self, slave_index: int, vendor_id: int, vendor_type: int, data: bytes):
        import time as _t
        self.slave_index = slave_index
        self.vendor_id = vendor_id
        self.vendor_type = vendor_type
        self.data = data or b''
        self.timestamp = _t.time()

    def __str__(self) -> str:
        return (f"VoE Notification: Slave={self.slave_index}, "
                f"VendorID=0x{self.vendor_id:08X}, "
                f"VendorType=0x{self.vendor_type:04X}, "
                f"DataLen={len(self.data)}")


def _voe_start_notification_listener(self) -> bool:
    """启动 VoE 监听线程 + 订阅本从站通知 (对齐 C# StartNotificationListener).

    流程:
      1. 第一次调用本 master 的 VOEStartNotificationListener (重入安全, 内部计数)
      2. VOERegisterNotification(slave, 0, 0, callback) 订阅本从站全部 vendor 通知
      3. 收到通知时由 native 回调进入 _trampoline, 再分发到 _notification_listeners
    """
    fn_start = getattr(self._dll, "VOEStartNotificationListener", None)
    fn_reg = getattr(self._dll, "VOERegisterNotification", None)
    if fn_start is None or fn_reg is None:
        return False

    key = (self._mi, self._si)
    if key in _voe_native_subs:
        # 已订阅, 幂等返回成功
        return True

    # 1) 启动 master 的监听线程 (幂等)
    try:
        if not _voe_listener_started.get(self._mi, False):
            ok = bool(fn_start(self._mi))
            if not ok:
                return False
            _voe_listener_started[self._mi] = True
    except (OSError, AttributeError, NotImplementedError):
        return False

    # 2) 注册本从站通知回调
    def _trampoline(slave, vendor_id, vendor_type, data_ptr, data_size, _user_data):
        try:
            if data_ptr and data_size > 0:
                buf = (ctypes.c_ubyte * int(data_size)).from_address(data_ptr)
                payload = bytes(buf)
            else:
                payload = b""
            args = VoENotificationEventArgs(
                slave_index=int(slave),
                vendor_id=int(vendor_id),
                vendor_type=int(vendor_type),
                data=payload,
            )
            self._dispatch_notification(args)
        except Exception:
            # 回调跑在 DLL 监听线程, 不能让异常逃逸
            pass

    native_cb = _VoENotifCbT(_trampoline)
    try:
        sub_idx = int(fn_reg(self._si, 0, 0, native_cb, None))
    except (OSError, AttributeError, NotImplementedError):
        return False
    if sub_idx < 0:
        return False

    # 持有引用 + 记录订阅索引
    _voe_native_subs[key] = (native_cb, sub_idx)
    return True


def _voe_stop_notification_listener(self) -> None:
    """注销本从站订阅 (对齐 C# StopNotificationListener).

    不关闭 master 监听线程 (其他从站可能仍在订阅), 仅 unregister 当前从站回调.
    """
    if hasattr(self, '_notification_listeners'):
        self._notification_listeners.clear()
    key = (self._mi, self._si)
    entry = _voe_native_subs.pop(key, None)
    if entry is None:
        return
    _native_cb, sub_idx = entry
    fn = getattr(self._dll, "VOEUnregisterNotification", None)
    if fn is None:
        return
    try:
        fn(int(sub_idx))
    except (OSError, AttributeError, NotImplementedError):
        pass


def _voe_stop_all_listeners(self) -> None:
    """停止本 master 监听线程 + 注销所有订阅 (对齐 C# StopAllListeners).

    需 self 提供 _dll / _mi (从已绑定 VoE 实例上调用).
    """
    fn_stop = getattr(self._dll, "VOEStopNotificationListener", None)
    fn_unreg = getattr(self._dll, "VOEUnregisterNotification", None)

    # 注销所有当前 master 的订阅
    if fn_unreg is not None:
        for key in list(_voe_native_subs.keys()):
            mi, _si = key
            if mi != self._mi:
                continue
            _native_cb, sub_idx = _voe_native_subs.pop(key)
            try:
                fn_unreg(int(sub_idx))
            except (OSError, AttributeError, NotImplementedError):
                pass

    # 停止 master 的监听线程
    if fn_stop is not None and _voe_listener_started.get(self._mi, False):
        try:
            fn_stop()
        except (OSError, AttributeError, NotImplementedError):
            pass
        _voe_listener_started[self._mi] = False


def _voe_is_listener_running(self) -> bool:
    """监听线程是否运行 (对齐 C# IsListenerRunning).

    DLL.VOEIsNotificationListening 是全局状态 (无参数), 任何已订阅的 VoE
    实例调用本属性返回相同结果.
    """
    fn = getattr(self._dll, "VOEIsNotificationListening", None)
    if fn is None:
        return False
    try:
        return bool(fn())
    except (OSError, AttributeError, NotImplementedError):
        return False


def _voe_add_notification_listener(self, listener) -> None:
    """添加通知监听器: callable(VoENotificationEventArgs) -> None"""
    if not hasattr(self, '_notification_listeners'):
        self._notification_listeners = []
    if callable(listener):
        self._notification_listeners.append(listener)


def _voe_remove_notification_listener(self, listener) -> None:
    if hasattr(self, '_notification_listeners'):
        try:
            self._notification_listeners.remove(listener)
        except ValueError:
            pass


def _voe_dispatch_notification(self, args: 'VoENotificationEventArgs') -> None:
    """内部分发入口 - FFI 回调到达时由 ctypes 包装层调用."""
    if not hasattr(self, '_notification_listeners'):
        return
    for cb in list(self._notification_listeners):
        try:
            cb(args)
        except Exception:
            # 单个 handler 异常不影响其他订阅者
            pass


VoE.start_notification_listener = _voe_start_notification_listener
VoE.stop_notification_listener = _voe_stop_notification_listener
# 注: 实装后 stop_all_listeners / is_listener_running 都需 self.dll, 改成实例方法
VoE.stop_all_listeners = _voe_stop_all_listeners
VoE.is_listener_running = property(_voe_is_listener_running)
VoE.add_notification_listener = _voe_add_notification_listener
VoE.remove_notification_listener = _voe_remove_notification_listener
VoE._dispatch_notification = _voe_dispatch_notification


__all__ = ['VoE', 'VoEResponse', 'VoENotificationEventArgs']
