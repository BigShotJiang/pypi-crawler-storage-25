# -*- coding: utf-8 -*-
"""
CiA 401 I/O 模块协议辅助类

实现 CiA 401 (IEC 61131-9) 标准的通用 I/O 设备访问，
包括数字输入/输出、模拟输入/输出的标准对象字典访问。
纯 Python 实现，通过 slave.coe 的 SDO 读写操作。
"""

import struct
from typing import Optional


class CiA401ErrorMode:
    """通信丢失时的输出错误模式"""
    HOLD = 0        # 保持当前值
    SAFE_VALUE = 1  # 使用安全值


class CiA401:
    """
    CiA 401 I/O 模块，封装数字/模拟输入输出的标准对象字典访问

    用法::

        cia = slave.cia401
        # 读取数字输入通道 0
        state = cia.read_di(0)
        # 写入数字输出通道 3
        cia.write_do(3, True)
        # 读取模拟输入通道 1
        value = cia.read_ai(1)
    """

    # ========== 标准对象索引 (CiA 401) ==========

    # 数字输入
    OD_DI = 0x6000              # 数字输入 (8位组)
    OD_DI_16BIT = 0x6001        # 16位数字输入
    OD_DI_POLARITY = 0x6002     # 数字输入极性
    OD_DI_FILTER = 0x6003       # 数字输入滤波使能
    OD_DI_32BIT = 0x6020        # 32位数字输入

    # 数字输出
    OD_DO = 0x6200              # 数字输出 (8位组)
    OD_DO_16BIT = 0x6201        # 16位数字输出
    OD_DO_ERROR_MODE = 0x6206   # 数字输出错误模式
    OD_DO_ERROR_VALUE = 0x6207  # 数字输出错误值
    OD_DO_32BIT = 0x6220        # 32位数字输出

    # 模拟输入
    OD_AI = 0x6400              # 模拟输入 (16位)
    OD_AI_SI_UNIT = 0x6420      # 模拟输入量程
    OD_AI_GLOBAL_INTERRUPT = 0x6423  # 模拟输入全局中断使能
    OD_AI_UPPER_LIMIT = 0x6424  # 模拟输入中断上限
    OD_AI_LOWER_LIMIT = 0x6425  # 模拟输入中断下限

    # 模拟输出
    OD_AO = 0x6411              # 模拟输出 (16位)
    OD_AO_32BIT = 0x6412        # 32位模拟输出
    OD_AO_SI_UNIT = 0x6430      # 模拟输出量程
    OD_AO_ERROR_MODE = 0x6443   # 模拟输出错误模式
    OD_AO_ERROR_VALUE = 0x6444  # 模拟输出错误值

    def __init__(self, slave):
        """
        初始化 CiA 401 实例

        参数:
            slave: 从站实例，需要提供 coe 属性
        """
        self._slave = slave

    # ========== 数字输入 ==========

    def read_di(self, channel: int) -> bool:
        """
        读取指定通道的数字输入状态

        参数:
            channel: 通道号（从 0 开始）

        返回:
            通道状态（True = 高电平）
        """
        group = channel // 8 + 1
        bit = channel % 8
        data = self._slave.coe.sdo_read(self.OD_DI, group)
        raw = data[0] if data and len(data) >= 1 else 0
        return (raw & (1 << bit)) != 0

    def read_di16(self, group: int) -> int:
        """
        读取 16 位数字输入组 (0x6001)

        参数:
            group: 组号（子索引，从 1 开始）

        返回:
            16 位输入值
        """
        data = self._slave.coe.sdo_read(self.OD_DI_16BIT, group)
        if data and len(data) >= 2:
            return struct.unpack('<H', data[:2])[0]
        return 0

    def read_di_byte(self, index: int) -> int:
        """
        按字节索引读取数字输入 (0x6000)

        参数:
            index: 字节索引（子索引，从 1 开始）

        返回:
            8 位输入值
        """
        data = self._slave.coe.sdo_read(self.OD_DI, index)
        return data[0] if data and len(data) >= 1 else 0

    def read_all_di(self) -> Optional[bytes]:
        """
        读取所有数字输入 (0x6000, 完整访问)

        返回:
            所有数字输入数据字节，失败返回 None
        """
        return self._slave.coe.sdo_read(self.OD_DI, 0, complete_access=True)

    def read_di32(self, group: int) -> int:
        """
        读取 32 位数字输入组 (0x6020)

        参数:
            group: 组号（子索引，从 1 开始）

        返回:
            32 位输入值
        """
        data = self._slave.coe.sdo_read(self.OD_DI_32BIT, group)
        if data and len(data) >= 4:
            return struct.unpack('<I', data[:4])[0]
        return 0

    def set_di_polarity(self, group: int, polarity: int):
        """
        设置数字输入极性 (0x6002)，每位对应一个通道，1=反转

        参数:
            group: 组号（子索引，从 1 开始）
            polarity: 极性掩码
        """
        self._slave.coe.sdo_write(self.OD_DI_POLARITY, group,
                                  struct.pack('<B', polarity & 0xFF))

    def get_di_polarity(self, group: int) -> int:
        """
        读取数字输入极性 (0x6002)

        参数:
            group: 组号（子索引，从 1 开始）

        返回:
            极性掩码
        """
        data = self._slave.coe.sdo_read(self.OD_DI_POLARITY, group)
        return data[0] if data and len(data) >= 1 else 0

    def set_di_filter(self, group: int, filter_enable: int):
        """
        设置数字输入滤波使能 (0x6003)

        参数:
            group: 组号（子索引，从 1 开始）
            filter_enable: 滤波使能掩码
        """
        self._slave.coe.sdo_write(self.OD_DI_FILTER, group,
                                  struct.pack('<B', filter_enable & 0xFF))

    def get_di_filter(self, group: int) -> int:
        """
        读取数字输入滤波使能 (0x6003)

        参数:
            group: 组号（子索引，从 1 开始）

        返回:
            滤波使能掩码
        """
        data = self._slave.coe.sdo_read(self.OD_DI_FILTER, group)
        return data[0] if data and len(data) >= 1 else 0

    # ========== 数字输出 ==========

    def read_do(self, channel: int) -> bool:
        """
        读取指定通道的数字输出状态

        参数:
            channel: 通道号（从 0 开始）

        返回:
            通道状态（True = 高电平）
        """
        group = channel // 8 + 1
        bit = channel % 8
        data = self._slave.coe.sdo_read(self.OD_DO, group)
        raw = data[0] if data and len(data) >= 1 else 0
        return (raw & (1 << bit)) != 0

    def write_do(self, channel: int, state: bool):
        """
        设置指定通道的数字输出，不影响同组其他通道

        参数:
            channel: 通道号（从 0 开始）
            state: 目标状态（True = 高电平）
        """
        group = channel // 8 + 1
        bit = channel % 8
        data = self._slave.coe.sdo_read(self.OD_DO, group)
        current = data[0] if data and len(data) >= 1 else 0
        if state:
            current |= (1 << bit)
        else:
            current &= ~(1 << bit) & 0xFF
        self._slave.coe.sdo_write(self.OD_DO, group,
                                  struct.pack('<B', current))

    def write_do_byte(self, index: int, value: int):
        """
        按字节索引写入数字输出 (0x6200)

        参数:
            index: 字节索引（子索引，从 1 开始）
            value: 8 位输出值
        """
        self._slave.coe.sdo_write(self.OD_DO, index,
                                  struct.pack('<B', value & 0xFF))

    def write_all_do(self, data: bytes):
        """
        写入所有数字输出 (0x6200, 完整访问)

        参数:
            data: 所有数字输出数据字节
        """
        self._slave.coe.sdo_write(self.OD_DO, 0, data, complete_access=True)

    def read_do16(self, group: int) -> int:
        """
        读取 16 位数字输出组 (0x6201)

        参数:
            group: 组号（子索引，从 1 开始）

        返回:
            16 位输出值
        """
        data = self._slave.coe.sdo_read(self.OD_DO_16BIT, group)
        if data and len(data) >= 2:
            return struct.unpack('<H', data[:2])[0]
        return 0

    def write_do16(self, group: int, value: int):
        """
        写入 16 位数字输出组 (0x6201)

        参数:
            group: 组号（子索引，从 1 开始）
            value: 16 位输出值
        """
        self._slave.coe.sdo_write(self.OD_DO_16BIT, group,
                                  struct.pack('<H', value & 0xFFFF))

    def read_do32(self, group: int) -> int:
        """
        读取 32 位数字输出组 (0x6220)

        参数:
            group: 组号（子索引，从 1 开始）

        返回:
            32 位输出值
        """
        data = self._slave.coe.sdo_read(self.OD_DO_32BIT, group)
        if data and len(data) >= 4:
            return struct.unpack('<I', data[:4])[0]
        return 0

    def write_do32(self, group: int, value: int):
        """
        写入 32 位数字输出组 (0x6220)

        参数:
            group: 组号（子索引，从 1 开始）
            value: 32 位输出值
        """
        self._slave.coe.sdo_write(self.OD_DO_32BIT, group,
                                  struct.pack('<I', value & 0xFFFFFFFF))

    # ========== 模拟输入 ==========

    def read_ai(self, channel: int) -> int:
        """
        读取模拟输入值，自动适应 16 位和 32 位设备

        参数:
            channel: 通道号（从 0 开始）

        返回:
            模拟值（有符号）
        """
        sub = channel + 1  # SDO 子索引从 1 开始
        data = self._slave.coe.sdo_read(self.OD_AI, sub)
        # 根据返回数据长度自适应 16/32 位
        if data and len(data) >= 4:
            return struct.unpack('<i', data[:4])[0]
        if data and len(data) >= 2:
            return struct.unpack('<h', data[:2])[0]
        return 0

    def read_ai_raw(self, channel: int) -> int:
        """
        读取模拟输入原始值（无符号 16 位）
        适用于 AI 数据范围为 0~65535 的设备

        参数:
            channel: 通道号（从 0 开始）

        返回:
            无符号 16 位原始值
        """
        sub = channel + 1
        data = self._slave.coe.sdo_read(self.OD_AI, sub)
        if data and len(data) >= 2:
            return struct.unpack('<H', data[:2])[0]
        return 0

    def read_ai32(self, channel: int) -> int:
        """
        读取 32 位模拟输入值（无符号）
        适用于高精度 AI 设备

        参数:
            channel: 通道号（从 0 开始）

        返回:
            无符号 32 位模拟值
        """
        sub = channel + 1
        data = self._slave.coe.sdo_read(self.OD_AI, sub)
        if data and len(data) >= 4:
            return struct.unpack('<I', data[:4])[0]
        return 0

    # ========== 模拟输出 ==========

    def read_ao(self, channel: int) -> int:
        """
        读取 16 位模拟输出值

        参数:
            channel: 通道号（从 0 开始）

        返回:
            16 位模拟值（有符号）
        """
        sub = channel + 1
        data = self._slave.coe.sdo_read(self.OD_AO, sub)
        if data and len(data) >= 2:
            return struct.unpack('<h', data[:2])[0]
        return 0

    def write_ao(self, channel: int, value: int):
        """
        写入 16 位模拟输出值

        参数:
            channel: 通道号（从 0 开始）
            value: 16 位输出值（有符号）
        """
        sub = channel + 1
        self._slave.coe.sdo_write(self.OD_AO, sub,
                                  struct.pack('<h', value))

    def write_ao_raw(self, channel: int, value: int):
        """
        写入模拟输出原始值（无符号 16 位）

        参数:
            channel: 通道号（从 0 开始）
            value: 无符号 16 位输出值
        """
        sub = channel + 1
        self._slave.coe.sdo_write(self.OD_AO, sub,
                                  struct.pack('<H', value & 0xFFFF))

    def read_ao32(self, channel: int) -> int:
        """
        读取 32 位模拟输出值 (0x6412)

        参数:
            channel: 通道号（从 0 开始）

        返回:
            32 位模拟值（有符号）
        """
        sub = channel + 1
        data = self._slave.coe.sdo_read(self.OD_AO_32BIT, sub)
        if data and len(data) >= 4:
            return struct.unpack('<i', data[:4])[0]
        return 0

    def write_ao32(self, channel: int, value: int):
        """
        写入 32 位模拟输出值 (0x6412)

        参数:
            channel: 通道号（从 0 开始）
            value: 32 位输出值（有符号）
        """
        sub = channel + 1
        self._slave.coe.sdo_write(self.OD_AO_32BIT, sub,
                                  struct.pack('<i', value))

    # ========== 错误处理 ==========

    def set_do_error_mode(self, group: int, mode: int):
        """
        设置数字输出错误模式，通信丢失时的输出行为

        参数:
            group: 组号（从 0 开始，对应 DO 通道 0-7, 8-15, ...）
            mode: 错误模式 (CiA401ErrorMode.HOLD 或 CiA401ErrorMode.SAFE_VALUE)
        """
        self._slave.coe.sdo_write(self.OD_DO_ERROR_MODE, group + 1,
                                  struct.pack('<B', mode & 0xFF))

    def get_do_error_mode(self, group: int) -> int:
        """
        读取数字输出错误模式 (0x6206)

        参数:
            group: 组号（从 0 开始）

        返回:
            错误模式值
        """
        data = self._slave.coe.sdo_read(self.OD_DO_ERROR_MODE, group + 1)
        return data[0] if data and len(data) >= 1 else 0

    def set_do_error_value(self, group: int, value: int):
        """
        设置数字输出安全值，通信丢失且错误模式启用时使用

        参数:
            group: 组号（从 0 开始）
            value: 安全输出值
        """
        self._slave.coe.sdo_write(self.OD_DO_ERROR_VALUE, group + 1,
                                  struct.pack('<B', value & 0xFF))

    def get_do_error_value(self, group: int) -> int:
        """
        读取数字输出安全值 (0x6207)

        参数:
            group: 组号（从 0 开始）

        返回:
            安全输出值
        """
        data = self._slave.coe.sdo_read(self.OD_DO_ERROR_VALUE, group + 1)
        return data[0] if data and len(data) >= 1 else 0

    def set_ao_error_mode(self, channel: int, mode: int):
        """
        设置模拟输出错误模式

        参数:
            channel: 通道号（从 0 开始）
            mode: 错误模式 (CiA401ErrorMode.HOLD 或 CiA401ErrorMode.SAFE_VALUE)
        """
        self._slave.coe.sdo_write(self.OD_AO_ERROR_MODE, channel + 1,
                                  struct.pack('<B', mode & 0xFF))

    def set_ao_error_value(self, channel: int, value: int):
        """
        设置模拟输出安全值

        参数:
            channel: 通道号（从 0 开始）
            value: 安全输出值（有符号 16 位）
        """
        self._slave.coe.sdo_write(self.OD_AO_ERROR_VALUE, channel + 1,
                                  struct.pack('<h', value))

    def get_ao_error_mode(self, channel: int) -> int:
        """
        读取模拟输出错误模式 (0x6443)

        参数:
            channel: 通道号（从 0 开始）

        返回:
            错误模式值
        """
        data = self._slave.coe.sdo_read(self.OD_AO_ERROR_MODE, channel + 1)
        return data[0] if data and len(data) >= 1 else 0

    def get_ao_error_value(self, channel: int) -> int:
        """
        读取模拟输出安全值 (0x6444)

        参数:
            channel: 通道号（从 0 开始）

        返回:
            安全输出值（有符号 16 位）
        """
        data = self._slave.coe.sdo_read(self.OD_AO_ERROR_VALUE, channel + 1)
        if data and len(data) >= 2:
            return struct.unpack('<h', data[:2])[0]
        return 0

    # ========== 模拟输入中断与限值 ==========

    def read_global_interrupt_enable(self) -> bool:
        """
        读取模拟输入全局中断使能 (0x6423)

        返回:
            True = 全局中断已使能
        """
        data = self._slave.coe.sdo_read(self.OD_AI_GLOBAL_INTERRUPT, 0x00)
        return bool(data[0]) if data and len(data) >= 1 else False

    def write_global_interrupt_enable(self, enable: bool):
        """
        设置模拟输入全局中断使能 (0x6423)

        参数:
            enable: True = 使能, False = 禁用
        """
        self._slave.coe.sdo_write(self.OD_AI_GLOBAL_INTERRUPT, 0x00,
                                  struct.pack('<B', 1 if enable else 0))

    def read_ai_upper_limit(self, channel: int) -> int:
        """
        读取模拟输入中断上限值 (0x6424)

        参数:
            channel: 通道号（从 0 开始）

        返回:
            上限值
        """
        sub = channel + 1
        data = self._slave.coe.sdo_read(self.OD_AI_UPPER_LIMIT, sub)
        if data and len(data) >= 4:
            return struct.unpack('<i', data[:4])[0]
        if data and len(data) >= 2:
            return struct.unpack('<h', data[:2])[0]
        return 0

    def write_ai_upper_limit(self, channel: int, value: int):
        """
        写入模拟输入中断上限值 (0x6424)

        参数:
            channel: 通道号（从 0 开始）
            value: 上限值（有符号 16 位）
        """
        sub = channel + 1
        self._slave.coe.sdo_write(self.OD_AI_UPPER_LIMIT, sub,
                                  struct.pack('<h', value))

    def read_ai_lower_limit(self, channel: int) -> int:
        """
        读取模拟输入中断下限值 (0x6425)

        参数:
            channel: 通道号（从 0 开始）

        返回:
            下限值
        """
        sub = channel + 1
        data = self._slave.coe.sdo_read(self.OD_AI_LOWER_LIMIT, sub)
        if data and len(data) >= 4:
            return struct.unpack('<i', data[:4])[0]
        if data and len(data) >= 2:
            return struct.unpack('<h', data[:2])[0]
        return 0

    def write_ai_lower_limit(self, channel: int, value: int):
        """
        写入模拟输入中断下限值 (0x6425)

        参数:
            channel: 通道号（从 0 开始）
            value: 下限值（有符号 16 位）
        """
        sub = channel + 1
        self._slave.coe.sdo_write(self.OD_AI_LOWER_LIMIT, sub,
                                  struct.pack('<h', value))

    def __repr__(self) -> str:
        return f"CiA401(slave={self._slave.index})"
