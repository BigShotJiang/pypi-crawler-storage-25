# -*- coding: utf-8 -*-
"""
EtherCAT 从站类
封装单个从站的 CoE/SoE/FoE/EoE/AoE/VoE 协议操作
"""

import ctypes
from ctypes import c_int, c_uint, c_ushort, c_ubyte, c_void_p, c_bool, c_char_p, byref, POINTER
from typing import Optional, Tuple, List, Callable

from ..data.types import SoEError, SDOError, EcALState
from ..utils.dll import (
    DarraCoreDLL, EcState, SlaveIdentity, SlaveEsmTimeouts,
    WatchdogConfig, WatchdogStatus, StartupParam,
    CiA402State, EmcyRecord, FsoEConfig, FsoEStatus, FsoEState, FsoEError,
    TRANS_IP, TRANS_PS, TRANS_SO, TIMING_BEFORE, TIMING_AFTER,
    DARRA_CORE_OP_25, DARRA_CORE_OP_26,
)


class CoE:
    """
    CoE (CANopen over EtherCAT) 协议接口
    提供 SDO 读写功能
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        self._last_sdo_error: SDOError = SDOError.NO_ERROR

    @property
    def last_sdo_error(self) -> SDOError:
        """
        最后一次 SDO 操作的错误码 (对齐 C# LastSdoError)
        当 sdo_read/sdo_write 失败时，可通过此属性获取 SDO 中止码 (Abort Code)。
        成功操作后重置为 NO_ERROR。
        """
        return self._last_sdo_error

    def sdo_read(self, index: int, subindex: int = 0,
                 complete_access: bool = False) -> Optional[bytes]:
        """
        读取 SDO 对象

        参数:
            index: 对象字典索引 (0x0000-0xFFFF)
            subindex: 子索引
            complete_access: 是否完整访问

        返回:
            读取到的字节数据，失败返回 None
        """
        size = c_int(0)
        ptr = self._dll.SDOread(
            self._mi, self._si, index, subindex, complete_access, byref(size)
        )
        if not ptr or size.value <= 0:
            # 负值可能编码了 SDO abort code
            if size.value < 0:
                try:
                    self._last_sdo_error = SDOError((-size.value) & 0xFFFFFFFF)
                except ValueError:
                    self._last_sdo_error = SDOError.GENERAL_ERROR
            else:
                self._last_sdo_error = SDOError.GENERAL_ERROR
            return None
        try:
            data = ctypes.string_at(ptr, size.value)
            self._last_sdo_error = SDOError.NO_ERROR
            return bytes(data)
        finally:
            self._dll.FreeMemory(ptr)

    def sdo_read_value(self, index: int, subindex: int = 0,
                       dtype: str = 'u32') -> Optional[int]:
        """
        读取 SDO 并解析为数值

        参数:
            dtype: 数据类型 ('u8', 'u16', 'u32', 'i8', 'i16', 'i32')
        """
        import struct
        data = self.sdo_read(index, subindex)
        if data is None:
            return None
        fmt_map = {
            'u8': '<B', 'i8': '<b', 'u16': '<H', 'i16': '<h',
            'u32': '<I', 'i32': '<i', 'u64': '<Q', 'i64': '<q',
        }
        fmt = fmt_map.get(dtype)
        if not fmt:
            raise ValueError(f"不支持的数据类型: {dtype}")
        expected = struct.calcsize(fmt)
        if len(data) < expected:
            data = data.ljust(expected, b'\x00')
        return struct.unpack(fmt, data[:expected])[0]

    def sdo_write(self, index: int, subindex: int, data: bytes,
                  complete_access: bool = False) -> bool:
        """
        写入 SDO 对象

        参数:
            index: 对象字典索引
            subindex: 子索引
            data: 要写入的字节数据
            complete_access: 是否完整访问

        返回:
            写入是否成功
        """
        buf = ctypes.create_string_buffer(data)
        ptr = ctypes.cast(buf, c_void_p)
        ok = bool(self._dll.SDOwrite(
            self._mi, self._si, index, subindex, complete_access, ptr, len(data)
        ))
        if not ok:
            self._last_sdo_error = SDOError.GENERAL_ERROR
            # 尝试通过读取触发错误栈获取精确的 abort code
            try:
                probe_size = c_int(0)
                probe = self._dll.SDOread(
                    self._mi, self._si, index, subindex, False, byref(probe_size)
                )
                if not probe and probe_size.value < 0:
                    try:
                        self._last_sdo_error = SDOError((-probe_size.value) & 0xFFFFFFFF)
                    except ValueError:
                        pass
                elif probe:
                    self._dll.FreeMemory(probe)
            except Exception:
                pass
        else:
            self._last_sdo_error = SDOError.NO_ERROR
        return ok

    def sdo_write_value(self, index: int, subindex: int, value: int,
                        dtype: str = 'u32') -> bool:
        """
        写入数值类型的 SDO

        参数:
            dtype: 数据类型 ('u8', 'u16', 'u32', 'i8', 'i16', 'i32')
        """
        import struct
        fmt_map = {
            'u8': '<B', 'i8': '<b', 'u16': '<H', 'i16': '<h',
            'u32': '<I', 'i32': '<i', 'u64': '<Q', 'i64': '<q',
        }
        fmt = fmt_map.get(dtype)
        if not fmt:
            raise ValueError(f"不支持的数据类型: {dtype}")
        return self.sdo_write(index, subindex, struct.pack(fmt, value))

    async def read_multiple_async(self, entries: list,
                                  cancel_event=None) -> dict:
        """
        批量 SDO 读取 — 一次调用读取多个对象

        内部通过 asyncio.run_in_executor 在线程池中顺序执行多个 SDO 读取，
        避免逐个 await 造成的上下文切换开销。

        参数:
            entries: [(index, subindex), ...] 待读取的对象列表
            cancel_event: 可选的 asyncio.Event，set 后中止剩余读取

        返回:
            dict: {(index, subindex): bytes 或 None}

        示例::

            results = await slave.coe.read_multiple_async([
                (0x6041, 0), (0x6064, 0), (0x6077, 0)
            ])
            for key, data in results.items():
                print(f"0x{key[0]:04X}:{key[1]} = {data}")
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _read():
            results = {}
            for index, subindex in entries:
                if cancel_event and cancel_event.is_set():
                    raise asyncio.CancelledError()
                try:
                    results[(index, subindex)] = self.sdo_read(index, subindex)
                except Exception:
                    results[(index, subindex)] = None
            return results

        return await loop.run_in_executor(None, _read)


class SoE:
    """
    SoE (Servo over EtherCAT) 协议接口
    提供 SERCOS III 参数读写
    """

    # 元素标志位常量 (SERCOS III / IEC 61491)
    DATA = 0x40       # Element 7: 操作数据 (Value)
    NAME = 0x02       # Element 2: 名称
    ATTRIBUTE = 0x04  # Element 3: 属性
    UNIT = 0x08       # Element 4: 单位
    MIN = 0x10        # Element 5: 最小值
    MAX = 0x20        # Element 6: 最大值

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int,
                 drive_no: int = 0, timeout: int = 5000):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        self._drive = drive_no
        self._timeout = timeout * 1000  # 毫秒转微秒, DLL 期望微秒
        self.last_soe_error: Optional[SoEError] = None  # 最近一次SoE错误码

    def read(self, idn: int, element_flags: int = 0x40) -> Optional[bytes]:
        """读取 SoE 参数"""
        data_ptr = c_void_p(0)
        data_size = c_int(0)
        ok = self._dll.SoERead(
            self._mi, self._si, self._drive, element_flags, idn,
            byref(data_ptr), byref(data_size), self._timeout
        )
        if not ok or not data_ptr.value or data_size.value <= 0:
            if data_ptr.value:
                self._dll.FreeMemory(data_ptr)
            return None
        try:
            return bytes(ctypes.string_at(data_ptr.value, data_size.value))
        finally:
            self._dll.FreeMemory(data_ptr)

    def write(self, idn: int, data: bytes, element_flags: int = 0x40) -> bool:
        """写入 SoE 参数"""
        buf = ctypes.create_string_buffer(data)
        return bool(self._dll.SoEWrite(
            self._mi, self._si, self._drive, element_flags, idn,
            ctypes.cast(buf, c_void_p), len(data), self._timeout
        ))

    def read_name(self, idn: int) -> Optional[str]:
        """读取 IDN 名称"""
        name_ptr = c_void_p(0)
        name_len = c_int(0)
        ok = self._dll.SoEReadName(
            self._mi, self._si, self._drive, idn,
            byref(name_ptr), byref(name_len), self._timeout
        )
        if not ok or not name_ptr.value:
            return None
        try:
            return ctypes.string_at(name_ptr.value, name_len.value).decode('utf-8', errors='replace')
        finally:
            self._dll.FreeMemory(name_ptr)

    def read_attributes(self, idn: int) -> Optional[int]:
        """读取 IDN 属性"""
        attrs = c_uint(0)
        ok = self._dll.SoEReadAttributes(
            self._mi, self._si, self._drive, idn, byref(attrs), self._timeout
        )
        return attrs.value if ok else None

    def read_unit(self, idn: int) -> Optional[str]:
        """读取 IDN 单位"""
        unit_ptr = c_void_p(0)
        unit_len = c_int(0)
        ok = self._dll.SoEReadUnit(
            self._mi, self._si, self._drive, idn,
            byref(unit_ptr), byref(unit_len), self._timeout
        )
        if not ok or not unit_ptr.value:
            return None
        try:
            return ctypes.string_at(unit_ptr.value, unit_len.value).decode('utf-8', errors='replace')
        finally:
            self._dll.FreeMemory(unit_ptr)

    def read_idn_list(self) -> Optional[List[int]]:
        """
        读取 IDN 列表

        返回:
            IDN 编号列表，失败返回 None
        """
        list_ptr = c_void_p(0)
        list_count = c_int(0)
        ok = self._dll.SoEReadIDNList(
            self._mi, self._si, self._drive,
            byref(list_ptr), byref(list_count), self._timeout
        )
        if not ok or not list_ptr.value or list_count.value <= 0:
            return None
        try:
            # IDN 列表为 uint16 数组
            arr = ctypes.cast(list_ptr.value, ctypes.POINTER(c_ushort * list_count.value)).contents
            return [arr[i] for i in range(list_count.value)]
        finally:
            self._dll.FreeMemory(list_ptr)

    def read_min_max(self, idn: int) -> Optional[Tuple[bytes, bytes]]:
        """
        读取 IDN 最小值和最大值

        返回:
            (min_data, max_data) 元组，失败返回 None
        """
        min_ptr = c_void_p(0)
        min_size = c_int(0)
        max_ptr = c_void_p(0)
        max_size = c_int(0)
        ok = self._dll.SoEReadMinMax(
            self._mi, self._si, self._drive, idn,
            byref(min_ptr), byref(min_size),
            byref(max_ptr), byref(max_size), self._timeout
        )
        if not ok:
            if min_ptr.value:
                self._dll.FreeMemory(min_ptr)
            if max_ptr.value:
                self._dll.FreeMemory(max_ptr)
            return None
        try:
            min_data = bytes(ctypes.string_at(min_ptr.value, min_size.value)) if min_ptr.value else b''
            max_data = bytes(ctypes.string_at(max_ptr.value, max_size.value)) if max_ptr.value else b''
            return (min_data, max_data)
        finally:
            if min_ptr.value:
                self._dll.FreeMemory(min_ptr)
            if max_ptr.value:
                self._dll.FreeMemory(max_ptr)

    # ---- 类型化读取方法 (对应 C# SoEInstance) ----

    def read_int16(self, idn: int, element_flags: int = 0x40) -> Optional[int]:
        """读取 IDN 参数并转换为 Int16"""
        import struct
        data = self.read(idn, element_flags)
        if data is not None and len(data) >= 2:
            return struct.unpack_from('<h', data)[0]
        return None

    def read_int32(self, idn: int, element_flags: int = 0x40) -> Optional[int]:
        """读取 IDN 参数并转换为 Int32"""
        import struct
        data = self.read(idn, element_flags)
        if data is not None and len(data) >= 4:
            return struct.unpack_from('<i', data)[0]
        return None

    def read_uint16(self, idn: int, element_flags: int = 0x40) -> Optional[int]:
        """读取 IDN 参数并转换为 UInt16"""
        import struct
        data = self.read(idn, element_flags)
        if data is not None and len(data) >= 2:
            return struct.unpack_from('<H', data)[0]
        return None

    def read_uint32(self, idn: int, element_flags: int = 0x40) -> Optional[int]:
        """读取 IDN 参数并转换为 UInt32"""
        import struct
        data = self.read(idn, element_flags)
        if data is not None and len(data) >= 4:
            return struct.unpack_from('<I', data)[0]
        return None

    def read_float(self, idn: int, element_flags: int = 0x40) -> Optional[float]:
        """读取 IDN 参数并转换为 Float"""
        import struct
        data = self.read(idn, element_flags)
        if data is not None and len(data) >= 4:
            return struct.unpack_from('<f', data)[0]
        return None

    def read_double(self, idn: int, element_flags: int = 0x40) -> Optional[float]:
        """读取 IDN 参数并转换为 Double"""
        import struct
        data = self.read(idn, element_flags)
        if data is not None and len(data) >= 8:
            return struct.unpack_from('<d', data)[0]
        return None

    def read_string(self, idn: int, element_flags: int = 0x40) -> Optional[str]:
        """读取 IDN 参数并转换为字符串"""
        data = self.read(idn, element_flags)
        if data is not None and len(data) > 0:
            return data.rstrip(b'\x00').decode('ascii', errors='replace')
        return None

    def read_default_value(self, idn: int) -> Optional[bytes]:
        """读取 IDN 参数的默认值 (ElementFlag 0x80)"""
        return self.read(idn, 0x80)

    def read_min_value(self, idn: int) -> Optional[bytes]:
        """读取 IDN 参数最小值 (ElementFlag 0x10)"""
        return self.read(idn, 0x10)

    def read_max_value(self, idn: int) -> Optional[bytes]:
        """读取 IDN 参数最大值 (ElementFlag 0x20)"""
        return self.read(idn, 0x20)

    def read_data_state(self, idn: int) -> Optional[int]:
        """读取 IDN 的 Data State 元素 (Element 1, Flag 0x01)"""
        import struct
        data = self.read(idn, 0x01)
        if data is not None and len(data) >= 2:
            return struct.unpack_from('<H', data)[0]
        return None

    # ---- 类型化写入方法 (对应 C# SoEInstance) ----

    def write_int16(self, idn: int, value: int, element_flags: int = 0x40) -> bool:
        """将 Int16 写入 IDN 参数"""
        import struct
        return self.write(idn, struct.pack('<h', value), element_flags)

    def write_int32(self, idn: int, value: int, element_flags: int = 0x40) -> bool:
        """将 Int32 写入 IDN 参数"""
        import struct
        return self.write(idn, struct.pack('<i', value), element_flags)

    def write_uint16(self, idn: int, value: int, element_flags: int = 0x40) -> bool:
        """将 UInt16 写入 IDN 参数"""
        import struct
        return self.write(idn, struct.pack('<H', value), element_flags)

    def write_uint32(self, idn: int, value: int, element_flags: int = 0x40) -> bool:
        """将 UInt32 写入 IDN 参数"""
        import struct
        return self.write(idn, struct.pack('<I', value), element_flags)

    # ---- 程序命令执行 (对应 C# SoEInstance.ExecuteCommand) ----

    def execute_command(self, idn: int, timeout_ms: int = 5000,
                        poll_interval_ms: int = 50) -> bool:
        """
        执行 SoE 程序命令 (SERCOS Procedure Command)。
        通过写入 Data State 元素 bit 0 = 1 启动命令，
        然后轮询 Data State 直到 bit 0 = 0（完成）或超时。

        参数:
            idn: 命令 IDN 编号
            timeout_ms: 超时时间（毫秒）
            poll_interval_ms: 轮询间隔（毫秒）

        返回:
            成功返回 True，失败或超时返回 False
        """
        import struct
        import time

        # 读取当前 Data State
        current = self.read(idn, 0x01)
        if current is None or len(current) < 2:
            return False

        # 设置 bit 0 = 1 并清除 bit 1
        state_val = struct.unpack_from('<H', current)[0]
        state_val = (state_val & 0xFFFC) | 0x0001
        if not self.write(idn, struct.pack('<H', state_val), 0x01):
            return False

        # 轮询等待
        start = time.monotonic()
        while (time.monotonic() - start) * 1000 < timeout_ms:
            time.sleep(poll_interval_ms / 1000.0)
            poll = self.read(idn, 0x01)
            if poll is None or len(poll) < 2:
                continue
            poll_val = struct.unpack_from('<H', poll)[0]
            if poll_val & 0x0002:
                return False  # 命令执行错误
            if not (poll_val & 0x0001):
                return True   # 命令完成
        return False

    # ---- 获取可用 IDN (对应 C# GetAvailableIDNs) ----

    def get_available_idns(self) -> List[int]:
        """获取驱动器支持的所有 IDN 列表"""
        result = self.read_idn_list()
        return result if result is not None else []

    # ---- 获取参数详情 (对应 C# GetParameterInfo) ----

    def get_parameter_info(self, idn: int) -> dict:
        """
        获取指定 IDN 的详细参数信息

        返回:
            包含 idn, name, unit, attributes, value, min_value, max_value, default_value 的字典
        """
        info = {'idn': idn, 'name': '', 'unit': '', 'attributes': None,
                'value': b'', 'min_value': b'', 'max_value': b'', 'default_value': b''}
        name = self.read_name(idn)
        if name:
            info['name'] = name
        unit = self.read_unit(idn)
        if unit:
            info['unit'] = unit
        attrs = self.read_attributes(idn)
        if attrs is not None:
            info['attributes'] = attrs
        value = self.read(idn, 0x40)
        if value:
            info['value'] = value
        mm = self.read_min_max(idn)
        if mm:
            info['min_value'] = mm[0]
            info['max_value'] = mm[1]
        default = self.read_default_value(idn)
        if default:
            info['default_value'] = default
        return info

    # ---- 通知系统 (对应 C# SoEInstance.EnableNotification 等) ----

    def enable_notification(self, idn: int) -> bool:
        """
        启用指定 IDN 的参数变化通知。
        将该 IDN 加入轮询监控列表。

        参数:
            idn: 要监控的 IDN 编号

        返回:
            是否成功
        """
        if not hasattr(self, '_monitored_idns'):
            self._monitored_idns = {}
        import struct
        # 尝试通过 S-0-0127 启用硬件通知
        try:
            self.write(0x007F, struct.pack('<H', idn), 0)
        except Exception:
            pass
        # 读取当前值作为基线
        current = self.read(idn, 0x40)
        self._monitored_idns[idn] = current
        return True

    def disable_notification(self, idn: int):
        """禁用指定 IDN 的参数变化通知"""
        if hasattr(self, '_monitored_idns'):
            self._monitored_idns.pop(idn, None)

    def disable_all_notifications(self):
        """禁用所有通知"""
        if hasattr(self, '_monitored_idns'):
            self._monitored_idns.clear()

    def get_monitored_idns(self) -> List[int]:
        """获取当前正在监控的 IDN 列表"""
        if not hasattr(self, '_monitored_idns'):
            return []
        return list(self._monitored_idns.keys())

    def poll_notifications(self, callback: Optional[Callable] = None) -> int:
        """
        轮询检测所有已监控 IDN 的参数变化

        参数:
            callback: 变化回调 callback(idn, old_value, new_value)

        返回:
            本次轮询检测到变化的 IDN 数量
        """
        if not hasattr(self, '_monitored_idns') or not self._monitored_idns:
            return 0
        changed = 0
        for idn in list(self._monitored_idns.keys()):
            try:
                new_val = self.read(idn, 0x40)
                old_val = self._monitored_idns.get(idn)
                if new_val != old_val:
                    self._monitored_idns[idn] = new_val
                    changed += 1
                    if callback:
                        try:
                            callback(idn, old_val, new_val)
                        except Exception:
                            pass
            except Exception:
                pass
        return changed


# FoE 实现已移至 foe.py
from .foe import FoE


class EoE:
    """
    EoE (Ethernet over EtherCAT) 协议接口
    提供 IP 配置功能
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int,
                 port: int = 0, timeout: int = 5000):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        self._port = port
        self._timeout = timeout * 1000  # 毫秒转微秒, DLL 期望微秒

    def set_ip(self, ip: int, subnet: int, gateway: int) -> bool:
        """设置 IP 配置 (参数为 uint32 形式的 IP 地址)"""
        return bool(self._dll.EOESetIP(
            self._mi, self._si, self._port, ip, subnet, gateway, self._timeout
        ))

    def get_ip(self) -> Optional[Tuple[int, int, int]]:
        """获取 IP 配置，返回 (ip, subnet, gateway)"""
        ip = c_uint(0)
        subnet = c_uint(0)
        gateway = c_uint(0)
        ok = self._dll.EOEGetIP(
            self._mi, self._si, self._port,
            byref(ip), byref(subnet), byref(gateway), self._timeout
        )
        if not ok:
            return None
        return (ip.value, subnet.value, gateway.value)

    def set_mac(self, mac: bytes) -> bool:
        """
        设置 MAC 地址

        参数:
            mac: 6 字节的 MAC 地址
        """
        if len(mac) != 6:
            raise ValueError("MAC 地址必须为 6 字节")
        buf = ctypes.create_string_buffer(mac)
        return bool(self._dll.EOESetMAC(
            self._mi, self._si, self._port, buf, self._timeout
        ))

    def get_mac(self) -> Optional[bytes]:
        """获取 MAC 地址，返回 6 字节数据"""
        buf = ctypes.create_string_buffer(6)
        ok = self._dll.EOEGetMAC(
            self._mi, self._si, self._port, buf, self._timeout
        )
        if not ok:
            return None
        return bytes(buf.raw)


    def set_dns(self, dns_ip: int, dns_name: str = "") -> bool:
        """
        设置 DNS 配置

        参数:
            dns_ip: DNS 服务器 IP (uint32 网络字节序)
            dns_name: DNS 名称
        """
        return bool(self._dll.EOESetDNS(
            self._mi, self._si, self._port,
            dns_ip, dns_name.encode('utf-8'), self._timeout
        ))

    def get_dns(self) -> Optional[Tuple[int, str]]:
        """
        获取 DNS 配置

        返回:
            (dns_ip, dns_name) 元组，失败返回 None
        """
        dns_ip = c_uint(0)
        dns_name_buf = ctypes.create_string_buffer(256)
        ok = self._dll.EOEGetDNS(
            self._mi, self._si, self._port,
            byref(dns_ip), dns_name_buf, self._timeout
        )
        if not ok:
            return None
        return (dns_ip.value, dns_name_buf.value.decode('utf-8', errors='replace'))

    def get_full_param(self) -> Optional[Tuple[int, int, int, bytes, int, str]]:
        """
        获取完整网络配置

        返回:
            (ip, subnet, gateway, mac, dns_ip, dns_name) 元组，失败返回 None
        """
        ip = c_uint(0)
        subnet = c_uint(0)
        gateway = c_uint(0)
        mac_buf = ctypes.create_string_buffer(6)
        dns_ip = c_uint(0)
        dns_name_buf = ctypes.create_string_buffer(256)
        ok = self._dll.EOEGetFullParam(
            self._mi, self._si, self._port,
            byref(ip), byref(subnet), byref(gateway),
            mac_buf, byref(dns_ip), dns_name_buf, self._timeout
        )
        if not ok:
            return None
        return (
            ip.value, subnet.value, gateway.value,
            bytes(mac_buf.raw[:6]), dns_ip.value,
            dns_name_buf.value.decode('utf-8', errors='replace')
        )

    def set_full_param(self, ip: int, subnet: int, gateway: int,
                       mac: bytes, dns_ip: int, dns_name: str = "") -> bool:
        """
        设置完整网络配置

        参数:
            ip: IP 地址 (uint32)
            subnet: 子网掩码 (uint32)
            gateway: 默认网关 (uint32)
            mac: 6 字节的 MAC 地址
            dns_ip: DNS 服务器 IP (uint32)
            dns_name: DNS 名称
        """
        if len(mac) != 6:
            raise ValueError("MAC 地址必须为 6 字节")
        mac_buf = ctypes.create_string_buffer(mac)
        return bool(self._dll.EOESetFullParam(
            self._mi, self._si, self._port,
            ip, subnet, gateway,
            mac_buf, dns_ip, dns_name.encode('utf-8'), self._timeout
        ))

    def get_address_filters(self, max_filters: int = 16) -> Optional[List[bytes]]:
        """
        获取地址过滤器列表

        参数:
            max_filters: 最大过滤器数量

        返回:
            MAC 地址过滤器列表 (每个 6 字节)，失败返回 None
        """
        filter_count = c_ubyte(0)
        mac_buf = ctypes.create_string_buffer(max_filters * 6)
        ok = self._dll.EOEGetAddressFilter(
            self._mi, self._si, self._port,
            byref(filter_count), mac_buf, max_filters, self._timeout
        )
        if not ok:
            return None
        result = []
        for i in range(filter_count.value):
            result.append(bytes(mac_buf.raw[i * 6:(i + 1) * 6]))
        return result

    def set_address_filters(self, filters: List[bytes]) -> bool:
        """
        设置地址过滤器列表

        参数:
            filters: MAC 地址过滤器列表 (每个 6 字节)，空列表清空过滤器
        """
        if not filters:
            # 清空过滤器
            return bool(self._dll.EOESetAddressFilter(
                self._mi, self._si, self._port,
                0, None, self._timeout
            ))
        for f in filters:
            if len(f) != 6:
                raise ValueError("每个过滤器 MAC 地址必须为 6 字节")
        mac_data = b''.join(filters)
        mac_buf = ctypes.create_string_buffer(mac_data)
        return bool(self._dll.EOESetAddressFilter(
            self._mi, self._si, self._port,
            len(filters), mac_buf, self._timeout
        ))

    def send_frame(self, data: bytes) -> bool:
        """
        发送 EoE 以太网帧

        参数:
            data: 以太网帧数据

        返回:
            发送是否成功
        """
        buf = ctypes.create_string_buffer(data)
        return bool(self._dll.EOESendFrame(
            self._mi, self._si, self._port,
            ctypes.cast(buf, c_void_p), len(data), self._timeout
        ))

    def receive_frame(self) -> Optional[bytes]:
        """
        接收 EoE 以太网帧

        返回:
            接收到的帧数据，失败返回 None
        """
        data_ptr = c_void_p(0)
        data_size = c_int(0)
        ok = self._dll.EOEReceiveFrame(
            self._mi, self._si, self._port,
            byref(data_ptr), byref(data_size), self._timeout
        )
        if not ok or not data_ptr.value or data_size.value <= 0:
            if data_ptr.value:
                self._dll.FreeMemory(data_ptr)
            return None
        try:
            return bytes(ctypes.string_at(data_ptr.value, data_size.value))
        finally:
            self._dll.FreeMemory(data_ptr)


class AoE:
    """
    AoE (ADS over EtherCAT) 协议接口
    提供 Beckhoff ADS 协议访问
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int,
                 timeout: int = 5000):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        self._timeout = timeout * 1000  # 毫秒转微秒, DLL 期望微秒

    def read_device_info(self) -> Optional[dict]:
        """读取设备信息"""
        major = c_ubyte(0)
        minor = c_ubyte(0)
        build = c_ushort(0)
        name_buf = ctypes.create_string_buffer(128)
        ok = self._dll.AOEReadDeviceInfo(
            self._mi, self._si, byref(major), byref(minor), byref(build),
            name_buf, 128, self._timeout
        )
        if not ok:
            return None
        return {
            'major': major.value, 'minor': minor.value, 'build': build.value,
            'name': name_buf.value.decode('utf-8', errors='replace'),
        }

    def read_state(self) -> Optional[Tuple[int, int]]:
        """读取 ADS 状态，返回 (ads_state, device_state)"""
        ads = c_ushort(0)
        dev = c_ushort(0)
        ok = self._dll.AOEReadState(
            self._mi, self._si, byref(ads), byref(dev), self._timeout
        )
        return (ads.value, dev.value) if ok else None

    def write_control(self, ads_state: int, device_state: int,
                      data: bytes = b'') -> bool:
        """
        写入 ADS 控制命令

        参数:
            ads_state: ADS 状态
            device_state: 设备状态
            data: 附加数据
        """
        buf = ctypes.create_string_buffer(data) if data else None
        ptr = ctypes.cast(buf, c_void_p) if buf else c_void_p(0)
        return bool(self._dll.AOEWriteControl(
            self._mi, self._si, ads_state, device_state,
            ptr, len(data), self._timeout
        ))

    def add_notification(self, index_group: int, index_offset: int,
                         length: int, trans_mode: int = 0,
                         max_delay: int = 0, cycle_time: int = 0) -> Optional[int]:
        """
        添加 ADS 通知

        参数:
            index_group: 索引组
            index_offset: 索引偏移
            length: 数据长度
            trans_mode: 传输模式
            max_delay: 最大延迟
            cycle_time: 周期时间

        返回:
            通知句柄，失败返回 None
        """
        handle = c_uint(0)
        ok = self._dll.AOEAddNotification(
            self._mi, self._si, index_group, index_offset, length,
            trans_mode, max_delay, cycle_time, byref(handle), self._timeout
        )
        return handle.value if ok else None

    def del_notification(self, handle: int) -> bool:
        """删除 ADS 通知"""
        return bool(self._dll.AOEDelNotification(
            self._mi, self._si, handle, self._timeout
        ))

    def set_config(self, target_net_id: bytes, target_port: int,
                   source_net_id: bytes, source_port: int) -> bool:
        """
        设置 AoE 路由配置

        参数:
            target_net_id: 目标 NetID (6 字节)
            target_port: 目标端口
            source_net_id: 源 NetID (6 字节)
            source_port: 源端口
        """
        t_buf = ctypes.create_string_buffer(target_net_id)
        s_buf = ctypes.create_string_buffer(source_net_id)
        return bool(self._dll.AOESetConfig(
            self._mi, self._si, t_buf, target_port, s_buf, source_port
        ))

    def get_config(self) -> Optional[dict]:
        """
        获取 AoE 路由配置

        返回:
            {'target_net_id': bytes, 'target_port': int,
             'source_net_id': bytes, 'source_port': int}
        """
        t_buf = ctypes.create_string_buffer(6)
        s_buf = ctypes.create_string_buffer(6)
        t_port = c_ushort(0)
        s_port = c_ushort(0)
        ok = self._dll.AOEGetConfig(
            self._mi, self._si,
            t_buf, byref(t_port), s_buf, byref(s_port)
        )
        if not ok:
            return None
        return {
            'target_net_id': bytes(t_buf.raw),
            'target_port': t_port.value,
            'source_net_id': bytes(s_buf.raw),
            'source_port': s_port.value,
        }

    def read_write(self, index_group: int, index_offset: int,
                   read_length: int, write_data: bytes = b'') -> Optional[bytes]:
        """AoE 读写操作"""
        write_buf = ctypes.create_string_buffer(write_data) if write_data else None
        write_ptr = ctypes.cast(write_buf, c_void_p) if write_buf else c_void_p(0)
        read_ptr = c_void_p(0)
        bytes_read = c_uint(0)
        ok = self._dll.AOEReadWrite(
            self._mi, self._si, index_group, index_offset,
            read_length, len(write_data), write_ptr,
            byref(read_ptr), byref(bytes_read), self._timeout
        )
        if not ok or not read_ptr.value or bytes_read.value == 0:
            return None
        try:
            return bytes(ctypes.string_at(read_ptr.value, bytes_read.value))
        finally:
            self._dll.FreeMemory(read_ptr)

    def write(self, index_group: int, index_offset: int,
              data: bytes) -> bool:
        """
        AoE 写操作 (read_length=0 的 read_write)

        参数:
            index_group: 索引组
            index_offset: 索引偏移
            data: 写入数据

        返回:
            是否成功
        """
        write_buf = ctypes.create_string_buffer(data) if data else None
        write_ptr = ctypes.cast(write_buf, c_void_p) if write_buf else c_void_p(0)
        read_ptr = c_void_p(0)
        bytes_read = c_uint(0)
        ok = self._dll.AOEReadWrite(
            self._mi, self._si, index_group, index_offset,
            0, len(data), write_ptr,
            byref(read_ptr), byref(bytes_read), self._timeout
        )
        if read_ptr.value:
            self._dll.FreeMemory(read_ptr)
        return bool(ok)

    # ===================== 邮箱协议路由常量 (ETG.1020) =====================

    # CoE (CANopen over EtherCAT) 路由 IndexGroup
    COE_INDEX_GROUP = 0xF302
    # SoE (Servo over EtherCAT) 路由 IndexGroup
    SOE_INDEX_GROUP = 0xF420

    # ===================== 邮箱协议路由便捷方法 =====================

    def read_coe_via_aoe(self, index: int, subindex: int,
                         read_length: int) -> Optional[bytes]:
        """
        通过 AoE 路由读取 CoE 对象 (IndexGroup=0xF302)
        IndexOffset 编码: (index << 16) | subindex

        参数:
            index: CoE 对象索引
            subindex: CoE 子索引
            read_length: 期望读取长度

        返回:
            读取数据，失败返回 None
        """
        index_offset = (index << 16) | (subindex & 0xFF)
        return self.read_write(self.COE_INDEX_GROUP, index_offset, read_length)

    def write_coe_via_aoe(self, index: int, subindex: int,
                          data: bytes) -> bool:
        """
        通过 AoE 路由写入 CoE 对象 (IndexGroup=0xF302)
        IndexOffset 编码: (index << 16) | subindex

        参数:
            index: CoE 对象索引
            subindex: CoE 子索引
            data: 写入数据

        返回:
            是否成功
        """
        index_offset = (index << 16) | (subindex & 0xFF)
        return self.write(self.COE_INDEX_GROUP, index_offset, data)

    def read_soe_via_aoe(self, idn: int, read_length: int) -> Optional[bytes]:
        """
        通过 AoE 路由读取 SoE IDN (IndexGroup=0xF420)
        IndexOffset 编码: IDN 编号

        参数:
            idn: SoE IDN 编号
            read_length: 期望读取长度

        返回:
            读取数据，失败返回 None
        """
        return self.read_write(self.SOE_INDEX_GROUP, idn, read_length)

    def write_soe_via_aoe(self, idn: int, data: bytes) -> bool:
        """
        通过 AoE 路由写入 SoE IDN (IndexGroup=0xF420)
        IndexOffset 编码: IDN 编号

        参数:
            idn: SoE IDN 编号
            data: 写入数据

        返回:
            是否成功
        """
        return self.write(self.SOE_INDEX_GROUP, idn, data)

    def initialize_slave_net_id(self, net_id: bytes) -> bool:
        """
        初始化从站 AoE Net ID (ETG.1020 §9.4)
        在 IP→PreOp 状态切换期间调用，将 Net ID 写入从站 ADS 路由表。
        写入 IndexGroup=1, IndexOffset=3。

        参数:
            net_id: 6 字节的 AMS Net ID

        返回:
            是否成功

        异常:
            ValueError: Net ID 不是 6 字节
        """
        if not net_id or len(net_id) != 6:
            raise ValueError("Net ID 必须为 6 字节")
        return self.write(1, 3, net_id)

    def send_command(self, target_port: int, command_id: int,
                     command_data: bytes = b'') -> Optional[bytes]:
        """
        发送 AoE 命令并接收响应

        参数:
            target_port: 目标端口
            command_id: 命令 ID
            command_data: 命令数据

        返回:
            响应数据，失败返回 None
        """
        cmd_buf = ctypes.create_string_buffer(command_data) if command_data else None
        cmd_ptr = ctypes.cast(cmd_buf, c_void_p) if cmd_buf else c_void_p(0)
        resp_ptr = c_void_p(0)
        resp_size = c_uint(0)
        ok = self._dll.AOESendCommand(
            self._mi, self._si, target_port, command_id,
            cmd_ptr, len(command_data),
            byref(resp_ptr), byref(resp_size), self._timeout
        )
        if not ok or not resp_ptr.value or resp_size.value == 0:
            return None
        try:
            return bytes(ctypes.string_at(resp_ptr.value, resp_size.value))
        finally:
            self._dll.FreeMemory(resp_ptr)


# VoE/VoEResponse 实现已移至 voe.py
from .voe import VoE, VoEResponse


class FSoE:
    """
    FSoE (Fail Safe over EtherCAT) 协议接口
    提供功能安全通信 (ETG.5100/5120)
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index


    def init_connection(self, connection_id: int, safety_address: int,
                        watchdog_time_ms: int, safe_input_size: int,
                        safe_output_size: int, pdo_input_offset: int = 0,
                        pdo_output_offset: int = 0) -> bool:
        """
        初始化 FSoE 连接

        参数:
            connection_id: 唯一连接标识符
            safety_address: FSoE从站安全地址
            watchdog_time_ms: 看门狗超时(毫秒)
            safe_input_size: 安全输入数据大小(字节)
            safe_output_size: 安全输出数据大小(字节)
            pdo_input_offset: IOmap中输入偏移
            pdo_output_offset: IOmap中输出偏移
        """
        cfg = FsoEConfig()
        cfg.connection_id = connection_id
        cfg.safety_address = safety_address
        cfg.watchdog_time_ms = watchdog_time_ms
        cfg.safe_input_size = safe_input_size
        cfg.safe_output_size = safe_output_size
        cfg.pdo_input_offset = pdo_input_offset
        cfg.pdo_output_offset = pdo_output_offset
        return bool(self._dll.FSoEInitConnection(self._mi, self._si, byref(cfg)))

    def close_connection(self) -> bool:
        """关闭 FSoE 连接"""
        return bool(self._dll.FSoECloseConnection(self._mi, self._si))

    def get_status(self) -> Optional[dict]:
        """
        获取 FSoE 连接状态

        返回:
            状态字典，失败返回 None
        """
        st = FsoEStatus()
        if not self._dll.FSoEGetStatus(self._mi, self._si, byref(st)):
            return None
        return {
            'state': FsoEState(st.state) if st.state in FsoEState._value2member_map_ else st.state,
            'last_error': FsoEError(st.last_error) if st.last_error in FsoEError._value2member_map_ else st.last_error,
            'error_count': st.error_count,
            'frames_sent': st.frames_sent,
            'frames_received': st.frames_received,
            'crc_errors': st.crc_errors,
            'watchdog_errors': st.watchdog_errors,
            'watchdog_expired': bool(st.watchdog_expired),
            'in_failsafe': bool(st.in_failsafe),
            'toggle_bit': st.toggle_bit,
            'initialized': bool(st.initialized),
        }

    def request_state(self, target_state: int) -> bool:
        """
        请求 FSoE 状态转换

        参数:
            target_state: 目标状态 (使用 FsoEState 枚举值)
        """
        return bool(self._dll.FSoERequestState(self._mi, self._si, target_state))

    @property
    def state(self) -> int:
        """获取当前 FSoE 状态"""
        return self._dll.FSoEGetState(self._mi, self._si)

    def reset(self) -> bool:
        """重置 FSoE 连接到初始状态"""
        return bool(self._dll.FSoEReset(self._mi, self._si))

    def write_safe_output(self, data: bytes) -> bool:
        """
        写入安全输出数据

        参数:
            data: 安全输出数据
        """
        buf = ctypes.create_string_buffer(data)
        return bool(self._dll.FSoEWriteSafeOutput(
            self._mi, self._si, ctypes.cast(buf, c_void_p), len(data)
        ))

    def read_safe_input(self, buffer_size: int = 256) -> Optional[bytes]:
        """
        读取安全输入数据

        参数:
            buffer_size: 缓冲区大小

        返回:
            安全输入数据，失败返回 None
        """
        buf = ctypes.create_string_buffer(buffer_size)
        size = c_uint(buffer_size)
        ok = self._dll.FSoEReadSafeInput(
            self._mi, self._si, ctypes.cast(buf, c_void_p), byref(size)
        )
        if not ok or size.value == 0:
            return None
        return bytes(buf.raw[:size.value])

    def download_parameters(self, param_data: bytes) -> Optional[int]:
        """
        下载安全参数 (在 PARAMETER 状态)

        参数:
            param_data: 安全参数数据

        返回:
            SRA CRC 值，失败返回 None
        """
        buf = ctypes.create_string_buffer(param_data)
        sra_crc = c_uint(0)
        ok = self._dll.FSoEDownloadParameters(
            self._mi, self._si, ctypes.cast(buf, c_void_p),
            len(param_data), byref(sra_crc)
        )
        return sra_crc.value if ok else None

    def set_failsafe_output(self, data: bytes) -> bool:
        """
        设置失效安全输出值

        参数:
            data: 失效安全输出数据
        """
        buf = ctypes.create_string_buffer(data)
        return bool(self._dll.FSoESetFailsafeOutput(
            self._mi, self._si, ctypes.cast(buf, c_void_p), len(data)
        ))

    def check_watchdog(self) -> bool:
        """检查看门狗状态 (True=正常, False=已超时)"""
        return bool(self._dll.FSoECheckWatchdog(self._mi, self._si))

    def get_last_error(self) -> int:
        """获取最后的 FSoE 错误代码"""
        return self._dll.FSoEGetLastError(self._mi, self._si)

    def clear_error(self):
        """清除 FSoE 错误"""
        self._dll.FSoEClearError(self._mi, self._si)

    @property
    def is_capable(self) -> bool:
        """检查从站是否支持 FSoE"""
        return bool(self._dll.FSoEIsSlaveCapable(self._mi, self._si))

    @property
    def connection_count(self) -> int:
        """获取主站的 FSoE 连接数"""
        return self._dll.FSoEGetConnectionCount(self._mi)


class ModeCiA402:
    """
    CiA 402 操作模式常量
    对应 ETG.6010 标准定义的操作模式
    """
    PP = 1
    """轮廓位置模式 (Profile Position)"""
    VL = 2
    """速度模式 (Velocity)"""
    PV = 3
    """轮廓速度模式 (Profile Velocity)"""
    TQ = 4
    """轮廓力矩模式 (Profile Torque)"""
    HM = 6
    """回原模式 (Homing Mode)"""
    IP = 7
    """插值位置模式 (Interpolated Position)"""
    CSP = 8
    """循环同步位置模式 (Cyclic Synchronous Position)"""
    CSV = 9
    """循环同步速度模式 (Cyclic Synchronous Velocity)"""
    CST = 10
    """循环同步力矩模式 (Cyclic Synchronous Torque)"""
    CSTCA = 11
    """周期同步转矩加速度模式 (Cyclic Synchronous Torque with Commutation Angle)"""


class CiA402:
    """
    CiA 402 驱动协议接口
    提供伺服/步进驱动的状态机控制
    """

    # ========== 标准对象索引 (CiA 402 / ETG.6010) ==========
    OD_CONTROLWORD = 0x6040
    OD_STATUSWORD = 0x6041
    OD_MODES_OF_OPERATION = 0x6060
    OD_MODES_OF_OPERATION_DISPLAY = 0x6061
    OD_TARGET_POSITION = 0x607A
    OD_POSITION_ACTUAL = 0x6064
    OD_TARGET_VELOCITY = 0x60FF
    OD_VELOCITY_ACTUAL = 0x606C
    OD_TARGET_TORQUE = 0x6071
    OD_TORQUE_ACTUAL = 0x6077
    OD_MAX_PROFILE_VELOCITY = 0x6080
    OD_PROFILE_VELOCITY = 0x6081
    OD_PROFILE_ACCELERATION = 0x6083
    OD_PROFILE_DECELERATION = 0x6084
    OD_QUICK_STOP_DECELERATION = 0x6085
    OD_HOMING_METHOD = 0x6098
    OD_HOMING_SPEEDS = 0x6099
    OD_HOME_OFFSET = 0x607C
    OD_TORQUE_OFFSET = 0x60B2
    OD_SOFTWARE_POSITION_LIMIT = 0x607D
    OD_SUPPORTED_DRIVE_MODES = 0x6502
    OD_POLARITY = 0x607E
    OD_MOTION_PROFILE_TYPE = 0x6086
    OD_HOMING_ACCELERATION = 0x609A
    OD_DIGITAL_INPUTS = 0x60FD
    OD_DIGITAL_OUTPUTS = 0x60FE

    # ========== 控制字常量 ==========
    CW_SHUTDOWN = 0x06
    CW_SWITCH_ON = 0x07
    CW_ENABLE_OPERATION = 0x0F
    CW_DISABLE_VOLTAGE = 0x00
    CW_QUICK_STOP = 0x02
    CW_FAULT_RESET = 0x80
    CW_HALT = 0x0100

    # ========== 状态字位定义 ==========
    SW_READY_TO_SWITCH_ON = 0x0001
    SW_SWITCHED_ON = 0x0002
    SW_OPERATION_ENABLED = 0x0004
    SW_FAULT = 0x0008
    SW_VOLTAGE_ENABLED = 0x0010
    SW_QUICK_STOP = 0x0020
    SW_SWITCH_ON_DISABLED = 0x0040
    SW_WARNING = 0x0080
    SW_REMOTE = 0x0200
    SW_TARGET_REACHED = 0x0400
    SW_INTERNAL_LIMIT = 0x0800
    SW_OP_MODE_SPECIFIC_1 = 0x1000
    SW_OP_MODE_SPECIFIC_2 = 0x2000

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index


    @property
    def state(self) -> CiA402State:
        """获取驱动状态 (读取 StatusWord 并解析)"""
        sw = self._dll.CiA402_ReadStatusWord(self._mi, self._si)
        return CiA402State(self._dll.CiA402_ParseState(sw))

    @property
    def status_word(self) -> int:
        """读取状态字 (0x6041)"""
        return self._dll.CiA402_ReadStatusWord(self._mi, self._si)

    @property
    def control_word(self) -> int:
        """获取使能命令 (基于当前状态字计算)"""
        sw = self._dll.CiA402_ReadStatusWord(self._mi, self._si)
        return self._dll.CiA402_GetEnableCommand(sw)

    @control_word.setter
    def control_word(self, value: int):
        """写入控制字 (0x6040)"""
        self._dll.CiA402_WriteControlWord(self._mi, self._si, value)

    @property
    def mode(self) -> int:
        """获取操作模式 (0x6061)"""
        return self._dll.CiA402_GetMode(self._mi, self._si)

    @mode.setter
    def mode(self, value: int):
        """设置操作模式 (0x6060)"""
        if not self._dll.CiA402_SetMode(self._mi, self._si, value):
            raise RuntimeError(f"设置操作模式 {value} 失败")

    def enable(self, max_retries: int = 10) -> bool:
        """使能驱动 (自动状态机转换)"""
        return bool(self._dll.CiA402_Enable(self._mi, self._si, max_retries))

    def disable(self) -> bool:
        """
        禁用驱动 (Disable Operation)
        通过写入控制字 ControlWord bit0-3 = 0x07 实现
        """
        # CiA402 Disable Operation: CW = xxxx.xxxx.0xxx.0111
        self._dll.CiA402_WriteControlWord(self._mi, self._si, 0x0007)
        return True

    def quick_stop(self) -> bool:
        """
        快速停止 (Quick Stop)
        通过写入控制字 ControlWord bit0-3 = 0x02 实现
        """
        # CiA402 Quick Stop: CW = xxxx.xxxx.0xxx.x01x
        self._dll.CiA402_WriteControlWord(self._mi, self._si, 0x0002)
        return True

    def fault_reset(self) -> bool:
        """故障复位"""
        return bool(self._dll.CiA402_FaultReset(self._mi, self._si))

    def set_target_position(self, position: int) -> bool:
        """
        设置目标位置 (0x607A)

        参数:
            position: 目标位置 (单位取决于从站配置)
        """
        import struct
        coe = CoE(self._dll, self._mi, self._si)
        data = struct.pack('<i', position)
        return coe.sdo_write(0x607A, 0, data)

    def set_target_velocity(self, velocity: int) -> bool:
        """
        设置目标速度 (0x60FF)

        参数:
            velocity: 目标速度 (单位取决于从站配置)
        """
        import struct
        coe = CoE(self._dll, self._mi, self._si)
        data = struct.pack('<i', velocity)
        return coe.sdo_write(0x60FF, 0, data)

    def set_target_torque(self, torque: int) -> bool:
        """
        设置目标力矩 (0x6071)

        参数:
            torque: 目标力矩 (0.1% 额定力矩)
        """
        import struct
        coe = CoE(self._dll, self._mi, self._si)
        data = struct.pack('<h', torque)
        return coe.sdo_write(0x6071, 0, data)

    @property
    def actual_position(self) -> Optional[int]:
        """读取实际位置 (0x6064)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x6064, 0, 'i32')

    @property
    def actual_velocity(self) -> Optional[int]:
        """读取实际速度 (0x606C)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x606C, 0, 'i32')

    @property
    def actual_torque(self) -> Optional[int]:
        """读取实际力矩 (0x6077)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x6077, 0, 'i16')

    # ---- Touch Probe (CiA 402 Part 2) ----

    # 对象字典索引常量
    OD_TOUCH_PROBE_FUNCTION = 0x60B8
    """Touch Probe 功能设置"""
    OD_TOUCH_PROBE_STATUS = 0x60B9
    """Touch Probe 状态"""
    OD_TOUCH_PROBE_POS_EDGE = 0x60BA
    """Touch Probe 正沿捕获位置"""
    OD_TOUCH_PROBE_NEG_EDGE = 0x60BB
    """Touch Probe 负沿捕获位置"""

    def set_touch_probe_function(self, value: int) -> bool:
        """
        设置 Touch Probe 功能 (0x60B8)

        参数:
            value: 功能设置值 (参考 CiA 402 Part 2)
                   Bit 0: 启用 Touch Probe 1
                   Bit 1: Touch Probe 1 边沿选择 (0=正沿, 1=负沿)
                   Bit 2: 启用 Touch Probe 1 连续模式
                   Bit 8: 启用 Touch Probe 2
        """
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_write_value(self.OD_TOUCH_PROBE_FUNCTION, 0, value, 'u16')

    @property
    def touch_probe_status(self) -> Optional[int]:
        """读取 Touch Probe 状态 (0x60B9)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(self.OD_TOUCH_PROBE_STATUS, 0, 'u16')

    @property
    def touch_probe_pos_edge(self) -> Optional[int]:
        """读取 Touch Probe 正沿捕获位置 (0x60BA)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(self.OD_TOUCH_PROBE_POS_EDGE, 0, 'i32')

    @property
    def touch_probe_neg_edge(self) -> Optional[int]:
        """读取 Touch Probe 负沿捕获位置 (0x60BB)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(self.OD_TOUCH_PROBE_NEG_EDGE, 0, 'i32')

    # ---- 状态字位属性 (对应 C# CiA402Instance) ----

    @property
    def state_drive(self) -> int:
        """解析当前驱动器状态 (对应 C# StateDrive)"""
        return self.state

    @property
    def target_reached(self) -> bool:
        """目标已到达 (StatusWord Bit 10, 对应 C# TargetReached)"""
        return (self.status_word & 0x0400) != 0

    @property
    def has_fault(self) -> bool:
        """是否有故障 (StatusWord Bit 3, 对应 C# HasFault)"""
        return (self.status_word & 0x0008) != 0

    @property
    def has_warning(self) -> bool:
        """是否有警告 (StatusWord Bit 7, 对应 C# HasWarning)"""
        return (self.status_word & 0x0080) != 0

    @property
    def is_remote(self) -> bool:
        """远程模式 (StatusWord Bit 9, 对应 C# IsRemote)"""
        return (self.status_word & 0x0200) != 0

    # ---- 操作模式 (对应 C# OperationMode 可读写) ----

    @property
    def operation_mode(self) -> int:
        """获取操作模式 (0x6061, 对应 C# OperationMode getter)"""
        return self.mode

    @operation_mode.setter
    def operation_mode(self, value: int):
        """设置操作模式 (0x6060, 对应 C# OperationMode setter)"""
        self.mode = value

    # ---- 实际值属性 (对应 C# PositionActual 等) ----

    @property
    def position_actual(self) -> Optional[int]:
        """读取实际位置 (0x6064, 对应 C# PositionActual)"""
        return self.actual_position

    @property
    def velocity_actual(self) -> Optional[int]:
        """读取实际速度 (0x606C, 对应 C# VelocityActual)"""
        return self.actual_velocity

    @property
    def torque_actual(self) -> Optional[int]:
        """读取实际力矩 (0x6077, 对应 C# TorqueActual)"""
        return self.actual_torque

    # ---- 目标值属性 (对应 C# TargetPosition/TargetVelocity/TargetTorque 可读写) ----

    @property
    def target_position(self) -> Optional[int]:
        """读取目标位置 (0x607A, 对应 C# TargetPosition getter)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x607A, 0, 'i32')

    @target_position.setter
    def target_position(self, position: int):
        """设置目标位置 (0x607A, 对应 C# TargetPosition setter)"""
        self.set_target_position(position)

    @property
    def target_velocity(self) -> Optional[int]:
        """读取目标速度 (0x60FF, 对应 C# TargetVelocity getter)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x60FF, 0, 'i32')

    @target_velocity.setter
    def target_velocity(self, velocity: int):
        """设置目标速度 (0x60FF, 对应 C# TargetVelocity setter)"""
        self.set_target_velocity(velocity)

    @property
    def target_torque(self) -> Optional[int]:
        """读取目标力矩 (0x6071, 对应 C# TargetTorque getter)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x6071, 0, 'i16')

    @target_torque.setter
    def target_torque(self, torque: int):
        """设置目标力矩 (0x6071, 对应 C# TargetTorque setter)"""
        self.set_target_torque(torque)

    # ---- 轮廓参数 (对应 C# ProfileVelocity 等可读写) ----

    @property
    def profile_velocity(self) -> Optional[int]:
        """轮廓速度 (0x6081, 对应 C# ProfileVelocity)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x6081, 0, 'u32')

    @profile_velocity.setter
    def profile_velocity(self, value: int):
        """设置轮廓速度 (0x6081)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x6081, 0, value, 'u32')

    @property
    def profile_acceleration(self) -> Optional[int]:
        """轮廓加速度 (0x6083, 对应 C# ProfileAcceleration)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x6083, 0, 'u32')

    @profile_acceleration.setter
    def profile_acceleration(self, value: int):
        """设置轮廓加速度 (0x6083)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x6083, 0, value, 'u32')

    @property
    def profile_deceleration(self) -> Optional[int]:
        """轮廓减速度 (0x6084, 对应 C# ProfileDeceleration)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x6084, 0, 'u32')

    @profile_deceleration.setter
    def profile_deceleration(self, value: int):
        """设置轮廓减速度 (0x6084)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x6084, 0, value, 'u32')

    @property
    def quick_stop_deceleration(self) -> Optional[int]:
        """快速停止减速度 (0x6085, 对应 C# QuickStopDeceleration)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x6085, 0, 'u32')

    @quick_stop_deceleration.setter
    def quick_stop_deceleration(self, value: int):
        """设置快速停止减速度 (0x6085)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x6085, 0, value, 'u32')

    # ---- 驱动器支持模式 (对应 C# SupportedDriveModes) ----

    @property
    def supported_drive_modes(self) -> int:
        """
        支持的驱动模式位掩码 (0x6502, 只读, 对应 C# SupportedDriveModes)
        Bit 0=PP, Bit 1=VL, Bit 2=PV, Bit 3=PT, Bit 5=HM, Bit 6=IP,
        Bit 7=CSP, Bit 8=CSV, Bit 9=CST
        """
        coe = CoE(self._dll, self._mi, self._si)
        val = coe.sdo_read_value(0x6502, 0, 'u32')
        return val if val is not None else 0

    def is_mode_supported(self, mode: int) -> bool:
        """
        检查驱动器是否支持指定操作模式 (对应 C# IsModeSupported)

        参数:
            mode: 操作模式值 (参考 ModeCiA402 常量)

        返回:
            是否支持
        """
        bit_map = {1: 0, 2: 1, 3: 2, 4: 3, 6: 5, 7: 6, 8: 7, 9: 8, 10: 9, 11: 10}
        bit = bit_map.get(mode, -1)
        if bit < 0:
            return False
        return (self.supported_drive_modes & (1 << bit)) != 0

    # ---- 使能/停止方法补充 (对应 C# DisableOperation/Disable) ----

    def disable_operation(self) -> bool:
        """
        禁用运行 (对应 C# DisableOperation)
        Transition 5: OperationEnabled -> SwitchedOn
        电机仍通电，可快速重新 Enable
        """
        self._dll.CiA402_WriteControlWord(self._mi, self._si, 0x0007)
        return True

    # ---- 运动控制方法 (对应 C# NewSetpoint/ClearNewSetpoint/StartHoming) ----

    def new_setpoint(self, position: int, relative: bool = False):
        """
        PP 模式: 发送新定位命令 (对应 C# NewSetpoint)

        参数:
            position: 目标位置
            relative: True = 相对定位, False = 绝对定位
        """
        self.set_target_position(position)
        cw = 0x000F | 0x0010  # Enable + NewSetpoint
        if relative:
            cw |= 0x0040  # Relative
        self._dll.CiA402_WriteControlWord(self._mi, self._si, cw)

    def clear_new_setpoint(self):
        """PP 模式: 清除 NewSetpoint 标志 (对应 C# ClearNewSetpoint)"""
        self._dll.CiA402_WriteControlWord(self._mi, self._si, 0x000F)

    def start_homing(self):
        """HM 模式: 启动回零 (对应 C# StartHoming)"""
        self._dll.CiA402_WriteControlWord(self._mi, self._si, 0x000F | 0x0010)

    @property
    def homing_attained(self) -> bool:
        """回零完成 (StatusWord Bit 12, 对应 C# HomingAttained)"""
        return (self.status_word & 0x1000) != 0

    @property
    def homing_error(self) -> bool:
        """回零错误 (StatusWord Bit 13, 对应 C# HomingError)"""
        return (self.status_word & 0x2000) != 0

    # ---- 回零参数 (对应 C# HomingMethod/HomeOffset/HomingSpeedSearch 等) ----

    @property
    def homing_method(self) -> Optional[int]:
        """回零方法 (0x6098, 对应 C# HomingMethod)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x6098, 0, 'i8')

    @homing_method.setter
    def homing_method(self, value: int):
        """设置回零方法 (0x6098)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x6098, 0, value, 'i8')

    @property
    def home_offset(self) -> Optional[int]:
        """回零偏移 (0x607C, 对应 C# HomeOffset)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x607C, 0, 'i32')

    @home_offset.setter
    def home_offset(self, value: int):
        """设置回零偏移 (0x607C)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x607C, 0, value, 'i32')

    @property
    def homing_speed_search(self) -> Optional[int]:
        """回零搜索速度 (0x6099:01, 对应 C# HomingSpeedSearch)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x6099, 1, 'u32')

    @homing_speed_search.setter
    def homing_speed_search(self, value: int):
        """设置回零搜索速度 (0x6099:01)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x6099, 1, value, 'u32')

    @property
    def homing_speed_zero(self) -> Optional[int]:
        """回零零脉冲速度 (0x6099:02, 对应 C# HomingSpeedZero)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x6099, 2, 'u32')

    @homing_speed_zero.setter
    def homing_speed_zero(self, value: int):
        """设置回零零脉冲速度 (0x6099:02)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x6099, 2, value, 'u32')

    @property
    def homing_acceleration(self) -> Optional[int]:
        """回零加速度 (0x609A, 对应 C# HomingAcceleration)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x609A, 0, 'u32')

    @homing_acceleration.setter
    def homing_acceleration(self, value: int):
        """设置回零加速度 (0x609A)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x609A, 0, value, 'u32')

    # ---- 极性/运动轮廓/数字IO (对应 C# Polarity/MotionProfileType/DigitalInputs) ----

    @property
    def polarity(self) -> Optional[int]:
        """极性设置 (0x607E, 对应 C# Polarity)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x607E, 0, 'u8')

    @polarity.setter
    def polarity(self, value: int):
        """设置极性 (0x607E)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x607E, 0, value, 'u8')

    @property
    def motion_profile_type(self) -> Optional[int]:
        """运动轮廓类型 (0x6086, 对应 C# MotionProfileType)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x6086, 0, 'i16')

    @motion_profile_type.setter
    def motion_profile_type(self, value: int):
        """设置运动轮廓类型 (0x6086)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x6086, 0, value, 'i16')

    @property
    def digital_inputs(self) -> Optional[int]:
        """数字输入状态 (0x60FD, 只读, 对应 C# DigitalInputs)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x60FD, 0, 'u32')

    @property
    def digital_outputs(self) -> Optional[int]:
        """数字输出控制 (0x60FE:01, 对应 C# DigitalOutputs)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x60FE, 1, 'u32')

    @digital_outputs.setter
    def digital_outputs(self, value: int):
        """设置数字输出 (0x60FE:01)"""
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x60FE, 1, value, 'u32')

    @property
    def software_position_limit_min(self) -> Optional[int]:
        """软件位置最小限制 (0x607D:01, 对应 C# SoftwarePositionLimitMin)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x607D, 1, 'i32')

    @software_position_limit_min.setter
    def software_position_limit_min(self, value: int):
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x607D, 1, value, 'i32')

    @property
    def software_position_limit_max(self) -> Optional[int]:
        """软件位置最大限制 (0x607D:02, 对应 C# SoftwarePositionLimitMax)"""
        coe = CoE(self._dll, self._mi, self._si)
        return coe.sdo_read_value(0x607D, 2, 'i32')

    @software_position_limit_max.setter
    def software_position_limit_max(self, value: int):
        coe = CoE(self._dll, self._mi, self._si)
        coe.sdo_write_value(0x607D, 2, value, 'i32')

    # ---- PDO 偏移管理 (对应 C# InitializePdoOffsets/ResetPdoOffsets) ----

    def initialize_pdo_offsets(self):
        """初始化 PDO 偏移缓存 (对应 C# InitializePdoOffsets)"""
        try:
            self._dll.CiA402_InitializePdoOffsets(self._mi, self._si)
        except Exception:
            pass

    def reset_pdo_offsets(self):
        """重置 PDO 偏移缓存 (对应 C# ResetPdoOffsets)"""
        try:
            self._dll.CiA402_ResetPdoOffsets(self._mi, self._si)
        except Exception:
            pass

    # ---- StatusWord 可读写 (对应 C# Statusword 只读 / Controlword 可读写) ----

    @property
    def statusword(self) -> int:
        """读取状态字 (0x6041, 对应 C# Statusword, status_word 的别名)"""
        return self.status_word

    @property
    def controlword(self) -> int:
        """读取控制字 (对应 C# Controlword getter, control_word 的别名)"""
        return self.control_word

    @controlword.setter
    def controlword(self, value: int):
        """写入控制字 (对应 C# Controlword setter)"""
        self.control_word = value

    def validate_profile_parameters(self) -> bool:
        """
        验证 CiA 402 配置参数有效性
        检查操作模式、目标位置/速度/力矩等是否在合理范围

        返回:
            参数是否有效
        """
        try:
            # 验证基本读取能力
            sw = self.status_word
            if sw is None:
                return False
            mode = self.mode
            if mode is None:
                return False
            return True
        except Exception:
            return False


class Slave:
    """
    EtherCAT 从站封装
    提供对单个从站的所有协议访问和配置操作
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index


        # 协议实例 (延迟创建)
        self._coe: Optional[CoE] = None
        self._soe: Optional[SoE] = None
        self._foe: Optional[FoE] = None
        self._eoe: Optional[EoE] = None
        self._aoe: Optional[AoE] = None
        self._voe: Optional[VoE] = None
        self._fsoe: Optional[FSoE] = None
        self._cia402: Optional[CiA402] = None
        self._cia401 = None
        self._esi_loader = None
        self._pdo_instance = None
        self._events = None
        self._dc_config_instance = None
        self._startup_list_instance = None
        self._diagnostics_instance = None
        self._mdp_instance = None

    @property
    def index(self) -> int:
        """从站索引"""
        return self._si

    @property
    def slave_num(self) -> int:
        """从站编号 (1-based, index 的别名)"""
        return self._si

    # ---- 协议接口属性 ----

    @property
    def coe(self) -> CoE:
        """CoE (CANopen over EtherCAT) 接口"""
        if self._coe is None:
            self._coe = CoE(self._dll, self._mi, self._si)
        return self._coe

    @property
    def soe(self) -> SoE:
        """SoE (Servo over EtherCAT) 接口"""
        if self._soe is None:
            self._soe = SoE(self._dll, self._mi, self._si)
        return self._soe

    @property
    def foe(self) -> FoE:
        """FoE (File over EtherCAT) 接口"""
        if self._foe is None:
            self._foe = FoE(self._dll, self._mi, self._si)
        return self._foe

    @property
    def eoe(self) -> EoE:
        """EoE (Ethernet over EtherCAT) 接口"""
        if self._eoe is None:
            self._eoe = EoE(self._dll, self._mi, self._si)
        return self._eoe

    @property
    def aoe(self) -> AoE:
        """AoE (ADS over EtherCAT) 接口"""
        if self._aoe is None:
            self._aoe = AoE(self._dll, self._mi, self._si)
        return self._aoe

    @property
    def voe(self) -> VoE:
        """VoE (Vendor specific) 接口"""
        if self._voe is None:
            self._voe = VoE(self._dll, self._mi, self._si)
        return self._voe

    @property
    def fsoe(self) -> FSoE:
        """FSoE (Fail Safe over EtherCAT) 接口"""
        if self._fsoe is None:
            self._fsoe = FSoE(self._dll, self._mi, self._si)
        return self._fsoe

    @property
    def cia402(self) -> CiA402:
        """CiA 402 驱动协议接口"""
        if self._cia402 is None:
            self._cia402 = CiA402(self._dll, self._mi, self._si)
        return self._cia402

    @property
    def cia401(self):
        """CiA 401 I/O 模块协议接口"""
        if self._cia401 is None:
            from .cia401 import CiA401
            self._cia401 = CiA401(self)
        return self._cia401

    @property
    def pdo(self):
        """
        PDO 数据读写接口 (SlavePdo)

        提供从站的输入/输出 PDO 数据的直接读写、零拷贝指针访问和结构体绑定。
        """
        if self._pdo_instance is None:
            from .slave_pdo import SlavePdo
            self._pdo_instance = SlavePdo(self._dll, self._mi, self._si)
        return self._pdo_instance

    @property
    def events(self):
        """
        从站级事件集合 (SlaveEvents)

        提供从站状态变化、紧急消息、上线/离线、DC 同步丢失等事件注册。
        """
        if self._events is None:
            from ..master.events import SlaveEvents
            self._events = SlaveEvents()
        return self._events

    @property
    def dc_config(self):
        """
        DC 分布式时钟配置 (DcConfig)

        提供从站 DC 时钟同步的配置和诊断接口。
        """
        if self._dc_config_instance is None:
            from .dc import DcConfig
            self._dc_config_instance = DcConfig(self._dll, self._mi, self._si)
        return self._dc_config_instance

    @property
    def startup(self):
        """
        启动参数列表 (StartupParameterList)

        提供从站启动参数的管理接口。
        """
        if self._startup_list_instance is None:
            from .startup import StartupParameterList
            self._startup_list_instance = StartupParameterList(self._dll, self._mi, self._si)
        return self._startup_list_instance

    @property
    def diagnostics(self):
        """
        从站诊断信息 (SlaveDiagnostics)

        提供从站级 DC 诊断、端口错误统计、冗余状态等诊断接口。
        """
        if self._diagnostics_instance is None:
            from .slave_stats import SlaveDiagnostics
            self._diagnostics_instance = SlaveDiagnostics(
                self._dll, self._mi, self._si,
                lambda: self.has_dc, self
            )
        return self._diagnostics_instance

    @property
    def mdp(self):
        """
        MDP 模块发现工具 (MdpDiscovery)

        提供模块化设备的模块检测和 PDO 布局查询。
        从站不支持 MDP 时返回 None。
        """
        if self._mdp_instance is None:
            if not self.has_mdp:
                return None
            from .mdp import MdpDiscovery
            self._mdp_instance = MdpDiscovery(self.coe)
        return self._mdp_instance

    @property
    def esi(self):
        """ESI 文件加载器接口"""
        if self._esi_loader is None:
            from .esi import EsiLoader
            self._esi_loader = EsiLoader(self)
        return self._esi_loader

    # ---- 拓扑 (对应 C# Slave/Topology.cs Children/ChildCount) ----

    @property
    def children(self) -> List['Slave']:
        """
        获取当前从站的子模块列表
        对应 C# Slave.Children 属性
        通过 DLL 查询拓扑子节点
        """
        try:
            max_results = 64
            buf = (c_ushort * max_results)()
            count = self._dll.TopologyGetChildren(self._mi, self._si, buf, max_results)
            result = []
            if count > 0:
                # 延迟导入避免循环依赖
                for i in range(count):
                    child_idx = buf[i]
                    if child_idx > 0:
                        result.append(Slave(self._dll, self._mi, child_idx))
            return result
        except Exception:
            return []

    @property
    def child_count(self) -> int:
        """
        获取当前从站的子模块数量
        对应 C# Slave.ChildCount 属性
        """
        try:
            max_results = 64
            buf = (c_ushort * max_results)()
            count = self._dll.TopologyGetChildren(self._mi, self._si, buf, max_results)
            return max(0, count)
        except Exception:
            return 0

    # ---- 身份与配置 ----

    @property
    def identity(self) -> Optional[dict]:
        """获取从站身份信息"""
        ident = SlaveIdentity()
        if self._dll.GetSlaveIdentity(self._mi, self._si, byref(ident)):
            return {
                'vendor_id': ident.vendor_id,
                'product_code': ident.product_code,
                'revision_no': ident.revision_no,
                'serial_no': ident.serial_no,
            }
        return None

    def verify_identity(self, expected_identity: SlaveIdentity,
                        check_revision: bool = True,
                        check_serial: bool = False) -> bool:
        """验证从站身份信息是否匹配

        Args:
            expected_identity: 期望的从站身份 (SlaveIdentity)
            check_revision: 是否检查修订号
            check_serial: 是否检查序列号

        Returns:
            bool: 身份验证是否通过
        """
        return bool(self._dll.VerifySlaveIdentity(
            self._mi, self._si,
            byref(expected_identity),
            check_revision, check_serial
        ))

    @property
    def group(self) -> int:
        """获取从站所属组"""
        return self._dll.GetSlaveGroup(self._mi, self._si)

    @group.setter
    def group(self, value: int):
        """设置从站所属组"""
        self._dll.SetSlaveGroup(self._mi, self._si, value)

    @property
    def optional(self) -> bool:
        """是否为可选从站"""
        return bool(self._dll.GetSlaveOptional(self._mi, self._si))

    @optional.setter
    def optional(self, value: bool):
        """设置是否为可选从站"""
        self._dll.SetSlaveOptional(self._mi, self._si, value)

    @property
    def supports_frame_repeat(self) -> bool:
        """是否支持帧重发"""
        return bool(self._dll.GetSlaveSupportsFrameRepeat(self._mi, self._si))

    @supports_frame_repeat.setter
    def supports_frame_repeat(self, value: bool):
        """设置帧重发支持标志"""
        self._dll.SetSlaveSupportsFrameRepeat(self._mi, self._si, value)

    @property
    def op_only(self) -> bool:
        """是否设置了 OpOnly 标志"""
        return bool(self._dll.GetSlaveOpOnlyFlag(self._mi, self._si))

    @property
    def device_emulation(self) -> bool:
        """是否为 Device Emulation 设备"""
        return bool(self._dll.GetSlaveDeviceEmulationFlag(self._mi, self._si))

    # ---- 状态管理 ----

    def set_state(self, state: EcState, timeout_ms: int = 5000) -> bool:
        """设置从站状态"""
        return bool(self._dll.SetSlaveStateWithTimeout(
            self._mi, self._si, state.value, timeout_ms
        ))

    def set_error_ack(self, ack: bool = True) -> bool:
        """设置 Error Indication Acknowledge"""
        return bool(self._dll.SetSlaveErrorAck(self._mi, self._si, ack))

    # ---- 看门狗 ----

    def set_watchdog(self, timeout_ms: int) -> bool:
        """设置过程数据看门狗超时"""
        return bool(self._dll.SetSlaveWatchdog(self._mi, self._si, timeout_ms))

    def set_pdi_watchdog(self, timeout_ms: int) -> bool:
        """设置 PDI 看门狗超时"""
        return bool(self._dll.SetSlavePdiWatchdog(self._mi, self._si, timeout_ms))

    @property
    def watchdog_config(self) -> Optional[dict]:
        """获取看门狗配置"""
        cfg = WatchdogConfig()
        if self._dll.GetSlaveWatchdogConfig(self._mi, self._si, byref(cfg)):
            return {
                'divider': cfg.wd_divider,
                'pdi_timeout': cfg.wd_time_pdi,
                'pd_timeout': cfg.wd_time_pd,
            }
        return None

    @property
    def watchdog_status(self) -> Optional[dict]:
        """获取看门狗状态"""
        st = WatchdogStatus()
        if self._dll.GetSlaveWatchdogStatus(self._mi, self._si, byref(st)):
            return {
                'status': st.wd_status,
                'counter': st.wd_counter,
                'divider': st.wd_divider,
                'pd_timeout': st.wd_time_pd,
            }
        return None

    # ---- ESM 超时 ----

    @property
    def esm_timeouts(self) -> Optional[SlaveEsmTimeouts]:
        """获取 ESM 超时配置"""
        t = SlaveEsmTimeouts()
        if self._dll.GetSlaveEsmTimeouts(self._mi, self._si, byref(t)):
            return t
        return None

    @esm_timeouts.setter
    def esm_timeouts(self, timeouts: SlaveEsmTimeouts):
        """设置 ESM 超时配置"""
        self._dll.SetSlaveEsmTimeouts(self._mi, self._si, byref(timeouts))

    # ---- DC 同步 ----

    def set_sync(self, sync0_ns: int, sync1_ns: int = 0, shift_ns: int = 0):
        """设置 DC 同步参数"""
        self._dll.SetSyncBySlaveIndex(self._mi, self._si, sync0_ns, sync1_ns, shift_ns)

    @property
    def propagation_delay(self) -> int:
        """获取传播延迟 (纳秒)"""
        return self._dll.GetSlavePropagationDelay(self._mi, self._si)

    # ---- 启动参数 ----

    def add_startup_param(self, index: int, subindex: int, data: bytes,
                          transition: int = TRANS_IP, timing: int = TIMING_AFTER,
                          complete_access: bool = False, priority: int = 0) -> int:
        """添加启动参数"""
        param = StartupParam()
        param.index = index
        param.sub_index = subindex
        for i, b in enumerate(data[:256]):
            param.data[i] = b
        param.data_len = len(data)
        param.transition = transition
        param.timing = timing
        param.priority = priority
        param.complete_access = 1 if complete_access else 0
        param.is_register_write = 0
        return self._dll.AddStartupParameter(self._mi, self._si, byref(param))

    def clear_startup_params(self) -> int:
        """清除启动参数"""
        return self._dll.ClearStartupParameters(self._mi, self._si)

    @property
    def startup_param_count(self) -> int:
        """获取启动参数数量"""
        return self._dll.GetStartupParameterCount(self._mi, self._si)

    def apply_startup_params(self, transition: int = TRANS_IP,
                             timing: int = TIMING_AFTER) -> int:
        """执行启动参数"""
        return self._dll.DarraCoreInvoke(
            self._mi, DARRA_CORE_OP_26, self._si, 1 << transition, 1 << timing)

    # ---- 寄存器读写 ----

    def read_register(self, addr: int, length: int) -> Optional[bytes]:
        """读取从站寄存器 (FPRD)"""
        buf = ctypes.create_string_buffer(length)
        ok = self._dll.ReadSlaveRegister(
            self._mi, self._si, addr, buf, length
        )
        return bytes(buf.raw) if ok else None

    def write_register(self, addr: int, data: bytes) -> bool:
        """写入从站寄存器 (FPWR)"""
        buf = ctypes.create_string_buffer(data)
        return bool(self._dll.WriteSlaveRegister(
            self._mi, self._si, addr, buf, len(data)
        ))

    def read_eeprom(self, byte_offset: int, byte_length: int) -> bytes:
        """读取 SII EEPROM 字节区域 (按 word 循环, 内部走 SIIReadWord)"""
        if byte_length <= 0 or byte_offset < 0:
            return b""
        word_addr = byte_offset >> 1
        word_count = (byte_length + 1) >> 1
        first_byte_odd = byte_offset & 1
        result = bytearray()
        for i in range(word_count):
            w = ctypes.c_uint16(0)
            if not self._dll.SIIReadWord(self._mi, self._si, word_addr + i, ctypes.byref(w)):
                return b""
            lo = w.value & 0xFF
            hi = (w.value >> 8) & 0xFF
            if i == 0 and first_byte_odd:
                if len(result) < byte_length: result.append(hi)
            else:
                if len(result) < byte_length: result.append(lo)
                if len(result) < byte_length: result.append(hi)
        return bytes(result)

    def write_eeprom(self, byte_offset: int, data: bytes) -> bool:
        """写入 SII EEPROM 字节区域 (要求 byte_offset 和 len(data) 偶数). 调用方需先 SIIAcquire."""
        if not data or byte_offset < 0 or (byte_offset & 1) or (len(data) & 1):
            return False
        word_addr = byte_offset >> 1
        word_count = len(data) >> 1
        for i in range(word_count):
            w = data[i * 2] | (data[i * 2 + 1] << 8)
            if not self._dll.SIIWriteWord(self._mi, self._si, word_addr + i, w):
                return False
        return True

    # ---- DL Port 端口控制 (0x0101 寄存器) ----

    def write_dl_port(self, value: int) -> bool:
        """
        写入从站 DL Port 控制寄存器 (0x0101) — 端口故障注入 / P1 管理

        自动 primary -> secondary -> APWR 三级回退, P0 关闭后仍可恢复。

        DLPORT 值:
            0x00 = Auto      (所有端口由 ESC 自动管理, 默认)
            0x03 = P0 关闭
            0x0C = P1 关闭
            0x30 = P2 关闭
            0xC0 = P3 关闭

        参数:
            value: DLPORT 值 (0-255)

        返回:
            是否成功
        """
        try:
            return bool(self._dll.WriteSlaveDLPORT(self._mi, self._si, value & 0xFF))
        except AttributeError:
            return False

    def read_dl_port(self) -> int:
        """
        读取从站 DL Port 控制寄存器 (0x0101) 当前值

        DLPORT 值:
            0x00 = Auto      (所有端口由 ESC 自动管理, 默认)
            0x03 = P0 关闭
            0x0C = P1 关闭
            0x30 = P2 关闭
            0xC0 = P3 关闭

        返回:
            当前 DLPORT 值 (0-255); 读取失败返回 0
        """
        try:
            val = ctypes.c_ubyte(0)
            ok = self._dll.ReadSlaveDLPORT(self._mi, self._si, ctypes.byref(val))
            return int(val.value) if ok else 0
        except AttributeError:
            return 0

    # ---- FMMU 配置 ----

    def configure_fmmu(self, fmmu_index: int, logical_addr: int, length: int,
                       logical_start_bit: int = 0, logical_end_bit: int = 7,
                       physical_addr: int = 0, physical_start_bit: int = 0,
                       fmmu_type: int = 0, enable: bool = True) -> bool:
        """
        配置 FMMU 映射

        参数:
            fmmu_index: FMMU 索引
            logical_addr: 逻辑地址
            length: 映射长度
            logical_start_bit: 逻辑起始位
            logical_end_bit: 逻辑结束位
            physical_addr: 物理地址
            physical_start_bit: 物理起始位
            fmmu_type: FMMU 类型
            enable: 是否启用
        """
        return bool(self._dll.ConfigureFMMU(
            self._mi, self._si, fmmu_index, logical_addr, length,
            logical_start_bit, logical_end_bit,
            physical_addr, physical_start_bit, fmmu_type, enable
        ))

    # ---- SyncManager 配置 (对应 C# ConfigureSyncManager) ----

    def configure_sync_manager(self, sm_index: int, start_addr: int,
                               length: int, sm_type: int = 0,
                               enable: bool = True) -> bool:
        """
        配置 SyncManager

        参数:
            sm_index:   SM 索引 (0-7)
            start_addr: 物理起始地址
            length:     数据长度 (字节)
            sm_type:    SM 类型 (0=未用, 1=MBoxOut, 2=MBoxIn, 3=PdOut, 4=PdIn)
            enable:     是否启用
        返回:
            是否成功
        """
        return bool(self._dll.ConfigureSyncManager(
            self._mi, self._si, sm_index, start_addr, length, sm_type, enable
        ))

    def enable_output_sync_manager(self) -> bool:
        """
        启用输出 SyncManager (对应 C# EnableOutputSyncManager)

        在从站进入 SafeOp/OP 状态前调用, 激活输出 SM。
        返回:
            是否成功
        """
        return bool(self._dll.EnableOutputSyncManager(self._mi, self._si))

    def disable_output_sync_manager(self) -> bool:
        """
        禁用输出 SyncManager (对应 C# DisableOutputSyncManager)

        返回:
            是否成功
        """
        return bool(self._dll.DisableOutputSyncManager(self._mi, self._si))

    # ---- 从站状态查询 ----

    @property
    def state(self) -> EcState:
        """从站当前 EtherCAT 状态"""
        raw = self._dll.GetSlaveState(self._mi, self._si)
        try:
            return EcState(raw & 0x0F)
        except ValueError:
            return EcState.NONE

    @property
    def al_status_code(self) -> EcALState:
        """AL Status Code (错误码)"""
        raw = self._dll.GetSlaveALStatusCode(self._mi, self._si)
        try:
            return EcALState(raw)
        except ValueError:
            return EcALState.UNKNOWN

    # ---- 无锁输出写入 ----

    def write_output(self, data: bytes):
        """
        无锁写入从站输出数据 (~10-15ns)

        参数:
            data: 输出数据
        """
        buf = ctypes.create_string_buffer(data)
        self._dll.WriteSlaveOutput(
            self._mi, self._si, ctypes.cast(buf, c_void_p), len(data)
        )

    def write_output_byte(self, offset: int, value: int):
        """
        无锁写入从站输出单字节

        参数:
            offset: 字节偏移
            value: 字节值
        """
        self._dll.WriteSlaveOutputByte(self._mi, self._si, offset, value)

    # ---- PDO 直接读写 ----

    def pdo_read(self, pdo_index: int, buffer_size: int = 256) -> Optional[bytes]:
        """直接读取 PDO"""
        buf = ctypes.create_string_buffer(buffer_size)
        bytes_read = c_uint(0)
        ok = self._dll.PDOReadDirect(
            self._mi, self._si, pdo_index,
            ctypes.cast(buf, c_void_p), buffer_size, byref(bytes_read)
        )
        if not ok or bytes_read.value == 0:
            return None
        return bytes(buf.raw[:bytes_read.value])

    def pdo_write(self, pdo_index: int, data: bytes) -> bool:
        """直接写入 PDO"""
        buf = ctypes.create_string_buffer(data)
        return bool(self._dll.PDOWriteDirect(
            self._mi, self._si, pdo_index,
            ctypes.cast(buf, c_void_p), len(data)
        ))

    # ---- 热插拔 ----

    @property
    def needs_reconfig(self) -> bool:
        """是否需要重新配置 (热插拔后)"""
        return bool(self._dll.GetSlaveNeedsStartupReconfig(self._mi, self._si))

    def clear_reconfig_flag(self):
        """清除重新配置标志"""
        self._dll.ClearSlaveNeedsStartupReconfig(self._mi, self._si)

    # ---- 同步窗口 ----

    @property
    def sync_window_status(self) -> Optional[dict]:
        """获取同步窗口状态"""
        diff = c_int(0)
        max_diff = c_int(0)
        min_diff = c_int(0)
        in_sync = c_int(0)  # Windows BOOL 是 4 字节, 不能用 c_bool(1字节)
        oos_count = c_uint(0)
        ok = self._dll.GetSlaveSyncWindowStatus(
            self._mi, self._si,
            byref(diff), byref(max_diff), byref(min_diff),
            byref(in_sync), byref(oos_count)
        )
        if not ok:
            return None
        return {
            'diff_ns': diff.value,
            'max_diff_ns': max_diff.value,
            'min_diff_ns': min_diff.value,
            'in_sync': in_sync.value,
            'out_of_sync_count': oos_count.value,
        }

    def reset_sync_stats(self):
        """重置同步窗口统计"""
        self._dll.ResetSlaveSyncWindowStats(self._mi, self._si)

    # ---- EMCY 紧急消息 ----

    @property
    def emcy_count(self) -> int:
        """获取 EMCY 消息数量"""
        return self._dll.EmcyGetCount(self._mi, self._si)

    @property
    def emcy_history(self) -> List[dict]:
        """
        获取 EMCY 消息历史

        返回:
            EMCY 记录列表 [{'error_code', 'error_register', 'data', 'timestamp_ms'}, ...]
        """
        count = self._dll.EmcyGetCount(self._mi, self._si)
        if count <= 0:
            return []
        buf = (EmcyRecord * count)()
        actual = self._dll.EmcyGetHistory(self._mi, self._si, buf, count)
        result = []
        for i in range(max(0, actual)):
            r = buf[i]
            result.append({
                'error_code': r.error_code,
                'error_register': r.error_register,
                'data': bytes(r.data),
                'slave_index': r.slave_index,
                'timestamp_ms': r.timestamp_ms,
            })
        return result

    def clear_emcy(self):
        """清除 EMCY 消息历史"""
        self._dll.EmcyClearHistory(self._mi, self._si)

    # ---- PDO 类型化读取 ----

    def read_input_u8(self, offset: int) -> int:
        """读取输入 PDO (uint8)"""
        return self._dll.PDOReadInputU8(self._mi, self._si, offset)

    def read_input_i16(self, offset: int) -> int:
        """读取输入 PDO (int16)"""
        return self._dll.PDOReadInputI16(self._mi, self._si, offset)

    def read_input_u16(self, offset: int) -> int:
        """读取输入 PDO (uint16)"""
        return self._dll.PDOReadInputU16(self._mi, self._si, offset)

    def read_input_i32(self, offset: int) -> int:
        """读取输入 PDO (int32)"""
        return self._dll.PDOReadInputI32(self._mi, self._si, offset)

    def read_input_u32(self, offset: int) -> int:
        """读取输入 PDO (uint32)"""
        return self._dll.PDOReadInputU32(self._mi, self._si, offset)

    def read_input_f32(self, offset: int) -> float:
        """读取输入 PDO (float32)"""
        return self._dll.PDOReadInputF32(self._mi, self._si, offset)

    # ---- PDO 类型化写入 ----

    def write_output_u8(self, offset: int, value: int) -> bool:
        """写入输出 PDO (uint8)"""
        return bool(self._dll.PDOWriteOutputU8(self._mi, self._si, offset, value))

    def write_output_i16(self, offset: int, value: int) -> bool:
        """写入输出 PDO (int16)"""
        return bool(self._dll.PDOWriteOutputI16(self._mi, self._si, offset, value))

    def write_output_u16(self, offset: int, value: int) -> bool:
        """写入输出 PDO (uint16)"""
        return bool(self._dll.PDOWriteOutputU16(self._mi, self._si, offset, value))

    def write_output_i32(self, offset: int, value: int) -> bool:
        """写入输出 PDO (int32)"""
        return bool(self._dll.PDOWriteOutputI32(self._mi, self._si, offset, value))

    def write_output_u32(self, offset: int, value: int) -> bool:
        """写入输出 PDO (uint32)"""
        return bool(self._dll.PDOWriteOutputU32(self._mi, self._si, offset, value))

    def write_output_f32(self, offset: int, value: float) -> bool:
        """写入输出 PDO (float32)"""
        return bool(self._dll.PDOWriteOutputF32(self._mi, self._si, offset, value))

    # ===================== 诊断 =====================

    @property
    def link_quality(self) -> int:
        """获取链路质量 (0-100%)"""
        return self._dll.GetSlaveLinkQuality(self._mi, self._si)

    def reset_port_error_counters(self) -> bool:
        """重置端口错误计数器"""
        return bool(self._dll.ResetSlavePortErrorCounters(self._mi, self._si))

    def read_port_error_counters(self) -> Optional[dict]:
        """
        读取端口错误计数器

        返回:
            {'rx_error': [4], 'invalid_frame': [4], 'lost_link': [4]} 或 None
        """
        rx_error = (c_ubyte * 4)()
        invalid_frame = (c_ubyte * 4)()
        lost_link = (c_ubyte * 4)()
        ok = self._dll.ReadSlavePortErrorCounters(
            self._mi, self._si, rx_error, invalid_frame, lost_link
        )
        if not ok:
            return None
        return {
            'rx_error': list(rx_error),
            'invalid_frame': list(invalid_frame),
            'lost_link': list(lost_link),
        }

    def port_error_stats(self):
        """获取端口错误统计指针"""
        return self._dll.GetSlavePortErrorStats(self._mi, self._si)

    # ===================== 拓扑 =====================

    @property
    def active_ports(self) -> int:
        """获取活跃端口数"""
        return self._dll.GetSlaveActivePorts(self._mi, self._si)

    @property
    def parent_index(self) -> int:
        """获取父从站编号"""
        return self._dll.GetSlaveParent(self._mi, self._si)

    @property
    def op_only_flag(self) -> bool:
        """获取 OpOnly 标志"""
        return bool(self._dll.GetSlaveOpOnlyFlag(self._mi, self._si))

    @property
    def device_emulation_flag(self) -> bool:
        """获取设备仿真标志"""
        return bool(self._dll.GetSlaveDeviceEmulationFlag(self._mi, self._si))

    # ---- DC 只读属性 (对应 C# Core.cs DC 属性) ----

    @property
    def dc_active(self) -> int:
        """DC AssignActivate 值 (16位), 0=禁用"""
        try:
            return self._dll.GetSlaveDCActive(self._mi, self._si)
        except Exception:
            return 0

    @property
    def dc_cycle0(self) -> int:
        """SYNC0 周期（纳秒）"""
        try:
            return self._dll.GetSlaveDCCycle0(self._mi, self._si)
        except Exception:
            return 0

    @property
    def dc_cycle1(self) -> int:
        """SYNC1 周期（纳秒）"""
        try:
            return self._dll.GetSlaveDCCycle1(self._mi, self._si)
        except Exception:
            return 0

    @property
    def dc_shift(self) -> int:
        """DC 相位偏移（纳秒）"""
        try:
            return self._dll.GetSlaveDCShift(self._mi, self._si)
        except Exception:
            return 0

    @property
    def dc_next(self) -> int:
        """DC 链中下一个从站的索引"""
        try:
            return self._dll.GetSlaveDCNext(self._mi, self._si)
        except Exception:
            return 0

    @property
    def dc_previous(self) -> int:
        """DC 链中上一个从站的索引"""
        try:
            return self._dll.GetSlaveDCPrevious(self._mi, self._si)
        except Exception:
            return 0

    @property
    def has_dc(self) -> bool:
        """从站是否支持DC同步"""
        try:
            return bool(self._dll.GetSlaveHasDC(self._mi, self._si))
        except Exception:
            return False

    # ---- 设备信息属性 (对应 C# Core.cs) ----

    @property
    def name(self) -> str:
        """从站名称 (SDO 0x1008 Device Name)"""
        try:
            name_buf = ctypes.create_string_buffer(128)
            ok = self._dll.GetSlaveName(self._mi, self._si, name_buf, 128)
            if ok:
                return name_buf.value.decode('utf-8', errors='replace')
        except Exception:
            pass
        return ""

    @property
    def config_addr(self) -> int:
        """物理配置地址"""
        try:
            return self._dll.GetSlaveConfigAddr(self._mi, self._si)
        except Exception:
            return 0

    @property
    def alias_addr(self) -> int:
        """别名地址"""
        try:
            return self._dll.GetSlaveAliasAddr(self._mi, self._si)
        except Exception:
            return 0

    @property
    def vendor_id(self) -> int:
        """厂商 ID"""
        ident = self.identity
        return ident.get('vendor_id', 0) if ident else 0

    @property
    def product_code(self) -> int:
        """产品代码"""
        ident = self.identity
        return ident.get('product_code', 0) if ident else 0

    @property
    def revision(self) -> int:
        """修订号"""
        ident = self.identity
        return ident.get('revision_no', 0) if ident else 0

    @property
    def serial_number(self) -> int:
        """序列号"""
        ident = self.identity
        return ident.get('serial_no', 0) if ident else 0

    @property
    def dtype(self) -> int:
        """设备类型"""
        try:
            return self._dll.GetSlaveDtype(self._mi, self._si)
        except Exception:
            return 0

    @property
    def ebus_current(self) -> int:
        """E-bus 电流消耗 (mA)"""
        try:
            return self._dll.GetSlaveEbusCurrent(self._mi, self._si)
        except Exception:
            return 0

    @property
    def coe_details(self) -> int:
        """CoE 协议详情 (来自 SII EEPROM)"""
        try:
            return self._dll.GetSlaveCoEDetails(self._mi, self._si)
        except Exception:
            return 0

    @property
    def eoe_details(self) -> int:
        """EoE 协议详情 (来自 SII EEPROM)"""
        try:
            return self._dll.GetSlaveEoEDetails(self._mi, self._si)
        except Exception:
            return 0

    @property
    def foe_details(self) -> int:
        """FoE 协议详情 (来自 SII EEPROM)"""
        try:
            return self._dll.GetSlaveFoEDetails(self._mi, self._si)
        except Exception:
            return 0

    @property
    def entry_port(self) -> int:
        """入口端口"""
        try:
            return self._dll.GetSlaveEntryPort(self._mi, self._si)
        except Exception:
            return 0

    @property
    def physical_type(self) -> int:
        """物理端口类型寄存器 (0x0007)"""
        try:
            return self._dll.GetSlavePhysicalType(self._mi, self._si)
        except Exception:
            return 0

    @property
    def topology(self) -> int:
        """拓扑类型"""
        try:
            return self._dll.GetSlaveTopology(self._mi, self._si)
        except Exception:
            return 0

    @property
    def block_lrw(self) -> bool:
        """是否阻止 LRW 操作"""
        try:
            return bool(self._dll.GetSlaveBlockLRW(self._mi, self._si))
        except Exception:
            return False

    @property
    def error_code(self) -> EcALState:
        """AL Status Code (错误码, al_status_code 的别名)"""
        return self.al_status_code

    @property
    def is_lost(self) -> bool:
        """从站是否丢失"""
        try:
            return bool(self._dll.GetSlaveIsLost(self._mi, self._si))
        except Exception:
            return False

    @property
    def is_optional(self) -> bool:
        """是否为可选从站 (optional 属性的别名)"""
        return self.optional

    @is_optional.setter
    def is_optional(self, value: bool):
        """设置是否为可选从站"""
        self.optional = value

    @property
    def ibits(self) -> int:
        """输入数据位数"""
        try:
            return self._dll.GetSlaveIBits(self._mi, self._si)
        except Exception:
            return 0

    @property
    def ibytes(self) -> int:
        """输入数据字节数"""
        try:
            return self._dll.GetSlaveIBytes(self._mi, self._si)
        except Exception:
            return 0

    @property
    def obits(self) -> int:
        """输出数据位数"""
        try:
            return self._dll.GetSlaveOBits(self._mi, self._si)
        except Exception:
            return 0

    @property
    def obytes(self) -> int:
        """输出数据字节数"""
        try:
            return self._dll.GetSlaveOBytes(self._mi, self._si)
        except Exception:
            return 0

    @property
    def ioffset(self) -> int:
        """输入在 IOmap 中的偏移"""
        try:
            return self._dll.GetSlaveIOffset(self._mi, self._si)
        except Exception:
            return 0

    @property
    def ooffset(self) -> int:
        """输出在 IOmap 中的偏移"""
        try:
            return self._dll.GetSlaveOOffset(self._mi, self._si)
        except Exception:
            return 0

    # ---- FMMU 函数类型 ----

    @property
    def fmmu0_function(self) -> int:
        """FMMU0 功能类型"""
        try:
            return self._dll.GetSlaveFMMU0Func(self._mi, self._si)
        except Exception:
            return 0

    @property
    def fmmu1_function(self) -> int:
        """FMMU1 功能类型"""
        try:
            return self._dll.GetSlaveFMMU1Func(self._mi, self._si)
        except Exception:
            return 0

    # ---- SM 配置 ----

    @property
    def sm_count(self) -> int:
        """同步管理器数量"""
        try:
            return self._dll.GetSlaveSMCount(self._mi, self._si)
        except Exception:
            return 0

    # ---- 冗余状态属性 ----

    @property
    def redundancy_activated(self) -> bool:
        """冗余是否已激活"""
        try:
            return bool(self._dll.GetSlaveRedundancyActivated(self._mi, self._si))
        except Exception:
            return False

    # ---- 别名地址 (匹配 C# AliasAddress 命名) ----

    @property
    def alias_address(self) -> int:
        """别名地址 (alias_addr 的别名, 匹配 C# AliasAddress)"""
        return self.alias_addr

    # ---- 产品信息属性 (对应 C# Slave/Core.cs) ----

    @property
    def product_id(self) -> int:
        """产品 ID (product_code 的别名, 匹配 C# ProductId)"""
        return self.product_code

    @property
    def rev_id(self) -> int:
        """修订版本号 (revision 的别名, 匹配 C# RevId)"""
        return self.revision

    # ---- 设备名称 (对应 C# DriveName) ----

    @property
    def drive_name(self) -> str:
        """设备名称 (SDO 0x1008 Device Name, 对应 C# DriveName)"""
        try:
            name_buf = ctypes.create_string_buffer(128)
            ok = self._dll.GetSlaveDeviceName(self._mi, self._si, name_buf, 128)
            if ok:
                return name_buf.value.decode('utf-8', errors='replace')
        except Exception:
            pass
        return ""

    # ---- 邮箱属性 (对应 C# MbxLength/MbxReadLength/MbxWriteOffset 等) ----

    @property
    def mbx_length(self) -> int:
        """邮箱发送缓冲区大小 (字节, 对应 C# MbxLength)"""
        try:
            return self._dll.GetSlaveMbxLength(self._mi, self._si)
        except Exception:
            return 0

    @property
    def mbx_read_length(self) -> int:
        """邮箱接收缓冲区大小 (字节, 对应 C# MbxReadLength)"""
        try:
            return self._dll.GetSlaveMbxReadLength(self._mi, self._si)
        except Exception:
            return 0

    @property
    def mbx_write_offset(self) -> int:
        """邮箱写入偏移 (对应 C# MbxWriteOffset)"""
        try:
            return self._dll.GetSlaveMbxWriteOffset(self._mi, self._si)
        except Exception:
            return 0

    @property
    def mbx_read_offset(self) -> int:
        """邮箱读取偏移 (对应 C# MbxReadOffset)"""
        try:
            return self._dll.GetSlaveMbxReadOffset(self._mi, self._si)
        except Exception:
            return 0

    @property
    def mbx_proto(self) -> int:
        """邮箱协议类型位图 (对应 C# MbxProto)"""
        try:
            # [2026-05-04] 修: dll 导出名是 GetSlaveMailboxProto (@1200), 不是 GetSlaveMbxProto
            return self._dll.GetSlaveMailboxProto(self._mi, self._si)
        except Exception:
            return 0

    @property
    def mbx_count(self) -> int:
        """邮箱计数器 (对应 C# MbxCount)"""
        try:
            return self._dll.GetSlaveMbxCount(self._mi, self._si)
        except Exception:
            return 0

    # ---- DC 补充属性 (对应 C# DCParentPort/DCReceiveTimeA-D) ----

    @property
    def dc_parent_port(self) -> int:
        """DC 父端口号 (对应 C# DCParentPort)"""
        try:
            return self._dll.GetSlaveDCParentPort(self._mi, self._si)
        except Exception:
            return 0

    @property
    def dc_receive_time_a(self) -> int:
        """端口 A 接收时间 (纳秒, 对应 C# DCReceiveTimeA)"""
        try:
            return self._dll.GetSlaveDCReceiveTimeA(self._mi, self._si)
        except Exception:
            return 0

    @property
    def dc_receive_time_b(self) -> int:
        """端口 B 接收时间 (纳秒, 对应 C# DCReceiveTimeB)"""
        try:
            return self._dll.GetSlaveDCReceiveTimeB(self._mi, self._si)
        except Exception:
            return 0

    @property
    def dc_receive_time_c(self) -> int:
        """端口 C 接收时间 (纳秒, 对应 C# DCReceiveTimeC)"""
        try:
            return self._dll.GetSlaveDCReceiveTimeC(self._mi, self._si)
        except Exception:
            return 0

    @property
    def dc_receive_time_d(self) -> int:
        """端口 D 接收时间 (纳秒, 对应 C# DCReceiveTimeD)"""
        try:
            return self._dll.GetSlaveDCReceiveTimeD(self._mi, self._si)
        except Exception:
            return 0

    # ---- EEPROM 属性 (对应 C# Eep8ByteAddressing/EepPDI) ----

    @property
    def eep_8byte_addressing(self) -> bool:
        """EEPROM 8字节寻址模式 (对应 C# Eep8ByteAddressing)"""
        try:
            return bool(self._dll.GetSlaveEep8ByteAddressing(self._mi, self._si))
        except Exception:
            return False

    @property
    def eep_pdi(self) -> int:
        """物理接口 (PDI) 类型 (来自 SII EEPROM, 对应 C# EepPDI)"""
        try:
            return self._dll.GetSlaveEepPDI(self._mi, self._si)
        except Exception:
            return 0

    # ---- 传播延迟 (对应 C# PDelay) ----

    @property
    def pdelay(self) -> int:
        """传播延迟 (纳秒, 对应 C# PDelay)"""
        return self.propagation_delay

    # ---- 拓扑补充属性 (对应 C# ParentStation/ParentPort) ----

    @property
    def parent_station(self) -> int:
        """父从站站地址 (对应 C# ParentStation)"""
        try:
            return self._dll.GetSlaveParentStation(self._mi, self._si)
        except Exception:
            return 0

    @property
    def parent_port(self) -> int:
        """父端口号 (对应 C# ParentPort)"""
        try:
            return self._dll.GetSlaveParentPort(self._mi, self._si)
        except Exception:
            return 0

    # ---- PDO 起始位 (对应 C# Istartbit/Ostartbit) ----

    @property
    def istartbit(self) -> int:
        """输入起始位 (对应 C# Istartbit)"""
        try:
            return self._dll.GetSlaveIStartBit(self._mi, self._si)
        except Exception:
            return 0

    @property
    def ostartbit(self) -> int:
        """输出起始位 (对应 C# Ostartbit)"""
        try:
            return self._dll.GetSlaveOStartBit(self._mi, self._si)
        except Exception:
            return 0

    # ---- SII 配置 (对应 C# SIIindex) ----

    @property
    def sii_index(self) -> int:
        """SII EEPROM 配置索引 (对应 C# SIIindex)"""
        try:
            return self._dll.GetSlaveSIIIndex(self._mi, self._si)
        except Exception:
            return 0

    # ---- SoE 协议详情 (对应 C# SoEdetails) ----

    @property
    def soe_details(self) -> int:
        """SoE 协议详情 (来自 SII EEPROM, 对应 C# SoEdetails)"""
        try:
            return self._dll.GetSlaveSoEDetails(self._mi, self._si)
        except Exception:
            return 0

    # ---- FMMU 补充属性 (对应 C# FMMU2Function/FMMU3Function) ----

    @property
    def fmmu2_function(self) -> int:
        """FMMU2 功能类型 (对应 C# FMMU2Function)"""
        try:
            return self._dll.GetSlaveFMMU2Func(self._mi, self._si)
        except Exception:
            return 0

    @property
    def fmmu3_function(self) -> int:
        """FMMU3 功能类型 (对应 C# FMMU3Function)"""
        try:
            return self._dll.GetSlaveFMMU3Func(self._mi, self._si)
        except Exception:
            return 0

    # ---- PDO 写入控制属性 (对应 C# ShouldWritePDOAssignment 等) ----

    @property
    def should_write_pdo_assignment(self) -> bool:
        """是否写入 PDO Assignment (0x1C12/0x1C13, 对应 C# ShouldWritePDOAssignment)"""
        try:
            return bool(self._dll.GetSlavePDOAssignmentEnabled(self._mi, self._si))
        except Exception:
            return True

    @should_write_pdo_assignment.setter
    def should_write_pdo_assignment(self, value: bool):
        """设置是否写入 PDO Assignment"""
        try:
            self._dll.SetSlavePDOAssignmentEnabled(self._mi, self._si, value)
        except Exception:
            pass

    @property
    def should_write_pdo_configuration(self) -> bool:
        """是否写入 PDO Configuration (0x1600-0x17FF 等, 对应 C# ShouldWritePDOConfiguration)"""
        try:
            return bool(self._dll.GetSlavePDOConfigurationEnabled(self._mi, self._si))
        except Exception:
            return False

    @should_write_pdo_configuration.setter
    def should_write_pdo_configuration(self, value: bool):
        """设置是否写入 PDO Configuration"""
        try:
            self._dll.SetSlavePDOConfigurationEnabled(self._mi, self._si, value)
        except Exception:
            pass

    @property
    def supports_complete_access(self) -> bool:
        """是否支持 SDO Complete Access (对应 C# SupportsCompleteAccess)"""
        try:
            return bool(self._dll.GetSlaveSupportsCompleteAccess(self._mi, self._si))
        except Exception:
            return False

    @supports_complete_access.setter
    def supports_complete_access(self, value: bool):
        """设置是否支持 Complete Access"""
        try:
            self._dll.SetSlaveSupportsCompleteAccess(self._mi, self._si, value)
        except Exception:
            pass

    # ---- ESI 相关属性 (对应 C# HasEsi/EsiName/EsiVersion/VendorName) ----

    @property
    def has_esi(self) -> bool:
        """是否已加载 ESI 文件 (对应 C# HasEsi)"""
        try:
            return bool(self._dll.GetSlaveHasEsi(self._mi, self._si))
        except Exception:
            return False

    @property
    def esi_name(self) -> str:
        """ESI 文件名 (对应 C# Esiname)"""
        try:
            buf = ctypes.create_string_buffer(256)
            ok = self._dll.GetSlaveEsiName(self._mi, self._si, buf, 256)
            if ok:
                return buf.value.decode('utf-8', errors='replace')
        except Exception:
            pass
        return ""

    @property
    def esi_version(self) -> str:
        """ESI 文件版本 (对应 C# EsiVersion)"""
        try:
            buf = ctypes.create_string_buffer(64)
            ok = self._dll.GetSlaveEsiVersion(self._mi, self._si, buf, 64)
            if ok:
                return buf.value.decode('utf-8', errors='replace')
        except Exception:
            pass
        return ""

    @property
    def vendor_name(self) -> str:
        """厂商名称 (对应 C# VendorName)"""
        try:
            buf = ctypes.create_string_buffer(128)
            ok = self._dll.GetSlaveVendorName(self._mi, self._si, buf, 128)
            if ok:
                return buf.value.decode('utf-8', errors='replace')
        except Exception:
            pass
        return ""

    @property
    def has_mdp(self) -> bool:
        """是否支持 Modular Device Profile (对应 C# HasMDP)"""
        try:
            return bool(self._dll.GetSlaveHasMDP(self._mi, self._si))
        except Exception:
            return False

    # DLL 不支持批量获取 SM/FMMU, 请使用单独的属性访问器

    # ---- 指针/ESI 管理方法 (对应 C# RefreshPointer/SetEsiFile) ----

    def refresh_pointer(self):
        """刷新从站指针 (对应 C# RefreshPointer)"""
        try:
            self._dll.RefreshSlavePointer(self._mi, self._si)
        except Exception:
            pass

    def set_esi_file(self, esi_file_name: str) -> bool:
        """
        设置从站 ESI 文件 (对应 C# SetEsiFile)

        参数:
            esi_file_name: ESI 文件名

        返回:
            是否成功
        """
        try:
            return bool(self._dll.SetSlaveEsiFile(
                self._mi, self._si, esi_file_name.encode('utf-8')
            ))
        except Exception:
            return False

    # ---- 冗余状态补充 (对应 C# PrimaryLinkBroken/SecondaryLinkBroken) ----

    @property
    def primary_link_broken(self) -> bool:
        """主线路是否断路 (对应 C# PrimaryLinkBroken)"""
        try:
            return bool(self._dll.GetSlavePrimaryLinkBroken(self._mi, self._si))
        except Exception:
            return False

    @property
    def secondary_link_broken(self) -> bool:
        """冗余线路是否断路 (对应 C# SecondaryLinkBroken)"""
        try:
            return bool(self._dll.GetSlaveSecondaryLinkBroken(self._mi, self._si))
        except Exception:
            return False

    def __str__(self) -> str:
        """字符串表示: 从站索引、名称、厂商ID:产品ID"""
        try:
            _name = self.name
            _vid = self.vendor_id
            _pid = self.product_id
        except Exception:
            _name = ""
            _vid = 0
            _pid = 0
        return f"Slave[{self._si}] {_name} ({_vid:#010x}:{_pid:#010x})"

    def __repr__(self) -> str:
        return f"Slave(index={self._si})"

    def configure_from_esi(self) -> bool:
        """
        从 ESI 文件自动配置从站 (SM/FMMU/PDO 映射)

        读取从站 ESI 信息, 自动配置 SyncManager、FMMU 和 PDO 映射。
        需要在 PreOp 或更高状态下调用。

        返回:
            配置是否成功
        """
        try:
            # 1. 通过 ESI 获取从站信息
            esi = self.esi
            if esi is None:
                return False

            # 2. 读取 ESI 中的 SM 配置并应用
            sm_configs = esi.get_sm_configs() if hasattr(esi, 'get_sm_configs') else None
            if sm_configs:
                for sm_idx, sm_cfg in enumerate(sm_configs):
                    try:
                        self._dll.ConfigureSM(self._mi, self._si, sm_idx,
                                              sm_cfg.get('start_addr', 0),
                                              sm_cfg.get('length', 0),
                                              sm_cfg.get('flags', 0))
                    except Exception:
                        pass

            # 3. 读取 ESI 中的 PDO 映射并应用
            pdo_assign = esi.get_pdo_assign() if hasattr(esi, 'get_pdo_assign') else None
            if pdo_assign:
                for pdo in pdo_assign:
                    try:
                        self._dll.AssignPDO(self._mi, self._si,
                                            pdo.get('sm_index', 0),
                                            pdo.get('pdo_index', 0))
                    except Exception:
                        pass

            # 4. 自动配置 SM 物理参数
            self._dll.DarraCoreInvoke(self._mi, DARRA_CORE_OP_25, self._si, 0, 0)
            return True
        except Exception:
            return False

    def config_by_esi(self) -> bool:
        """
        根据 ESI 文件自动配置从站 (对应 C# ConfigByEsi)

        综合执行: AutoConfigureSM + ConfigureDC, 一步完成从站配置。
        内部调用 configure_from_esi() 后, 额外配置 DC 同步参数。

        返回:
            是否成功
        """
        try:
            # 先执行基础 ESI 配置 (SM + PDO)
            if not self.configure_from_esi():
                return False

            # 再配置 DC (如果从站支持)
            esi = self.esi
            if esi is not None:
                dc_config = None
                if hasattr(esi, 'dc_configuration'):
                    dc_config = esi.dc_configuration
                elif hasattr(esi, 'get_dc_configuration'):
                    dc_config = esi.get_dc_configuration()

                if dc_config is not None:
                    sync0_ns = 0
                    sync1_ns = 0
                    assign_activate = 0
                    if hasattr(dc_config, 'op_modes') and dc_config.op_modes:
                        for mode in dc_config.op_modes:
                            if hasattr(mode, 'assign_activate') and mode.assign_activate != 0:
                                assign_activate = mode.assign_activate
                                sync0_ns = getattr(mode, 'cycle_time_sync0', 0)
                                sync1_ns = getattr(mode, 'cycle_time_sync1', 0)
                                break
                    if assign_activate != 0 and sync0_ns > 0:
                        try:
                            self._dll.SetSyncBySlaveIndex(
                                self._mi, self._si,
                                sync0_ns, sync1_ns,
                                assign_activate
                            )
                        except Exception:
                            pass
            return True
        except Exception:
            return False
