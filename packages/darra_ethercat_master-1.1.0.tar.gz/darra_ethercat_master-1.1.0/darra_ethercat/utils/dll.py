# -*- coding: utf-8 -*-
"""
Darra.Core.dll 原生绑定层
通过 ctypes 加载 DLL 并声明所有函数签名
"""

import ctypes
import ctypes.util
import os
import sys
import struct
import marshal
import base64
from ctypes import (
    c_bool, c_byte, c_ubyte, c_short, c_ushort, c_int, c_uint,
    c_int16, c_uint16, c_uint32, c_uint64, c_float, c_double, c_char_p,
    c_void_p, c_size_t, POINTER, Structure, byref, cast, CFUNCTYPE,
    create_string_buffer,
)
from enum import IntEnum, IntFlag
from typing import Optional


# ===================== Opaque native command bridge =====================
# 这些常量是底层调度器 DarraCoreInvoke / DarraCoreInvokeText 的命令 id;
# 语义映射对发行版本不公开 (semantic mapping intentionally redacted).
# 名字保留 _NN 形式仅为兼容历史调用点, 不代表任何稳定的对外 ABI.
DARRA_CORE_OP_21 = 0x44525421
DARRA_CORE_OP_22 = 0x44525422
DARRA_CORE_OP_23 = 0x44525423
DARRA_CORE_OP_24 = 0x44525424
DARRA_CORE_OP_25 = 0x44525425
DARRA_CORE_OP_26 = 0x44525426
DARRA_CORE_OP_27 = 0x44525427
DARRA_CORE_OP_28 = 0x44525428
DARRA_CORE_FLAG_01 = 0x00000001
DARRA_CORE_FLAG_04 = 0x00000004
DARRA_CORE_FLAG_08 = 0x00000008


# ===================== 枚举定义 =====================

class EcState(IntEnum):
    """EtherCAT 从站状态"""
    NONE = 0x00
    INIT = 0x01
    PRE_OP = 0x02
    BOOT = 0x03
    SAFE_OP = 0x04
    OP = 0x08
    ACK = 0x10
    ERROR = 0x10

    @property
    def base_state(self) -> 'EcState':
        """获取基础状态 (低4位)"""
        return EcState(self.value & 0x0F)

    @property
    def has_error(self) -> bool:
        """是否包含 Error 标志"""
        return bool(self.value & 0x10)

    def format(self) -> str:
        """格式化为可读字符串"""
        base = self.base_state
        names = {
            EcState.NONE: "None", EcState.INIT: "Init",
            EcState.PRE_OP: "PreOp", EcState.BOOT: "Boot",
            EcState.SAFE_OP: "SafeOp", EcState.OP: "OP",
        }
        name = names.get(base, f"0x{base.value:02X}")
        return f"{name}+Error" if self.has_error else name


class EcLinkState(IntEnum):
    """链路状态"""
    DISCONNECTED = 0
    CONNECTED = 1
    PRIMARY_ONLY = 3
    SECONDARY_ONLY = 4


class RingMode(IntEnum):
    """环拓扑冗余运行模式"""
    INACTIVE = 0    # 未激活
    DUAL = 1        # 双向冗余
    DEGRADED = 2    # 降级模式


class EcErr(IntEnum):
    """错误码"""
    OK = 0
    ALREADY_INITIALIZED = 1
    NOT_INITIALIZED = 2
    TIMEOUT = 3
    NO_SLAVES = 4
    NOK = 5


# ===================== 结构体定义 =====================

class DllVersionInfo(Structure):
    """DLL 版本信息"""
    _pack_ = 1
    _fields_ = [
        ("major", c_ushort),
        ("minor", c_ushort),
        ("patch", c_ushort),
        ("build", c_ushort),
        ("build_date", ctypes.c_char * 32),
    ]


class SlaveIdentity(Structure):
    """从站身份信息"""
    _fields_ = [
        ("vendor_id", c_uint),
        ("product_code", c_uint),
        ("revision_no", c_uint),
        ("serial_no", c_uint),
    ]


class SlaveEsmTimeouts(Structure):
    """ESM 超时配置"""
    _fields_ = [
        ("ip", c_uint), ("ps", c_uint), ("so", c_uint), ("os", c_uint),
        ("sp", c_uint), ("pi", c_uint), ("bi", c_uint), ("ib", c_uint),
    ]


class WatchdogConfig(Structure):
    """看门狗配置"""
    _fields_ = [
        ("wd_divider", c_ushort),
        ("wd_time_pdi", c_ushort),
        ("wd_time_pd", c_ushort),
    ]


class WatchdogStatus(Structure):
    """看门狗状态"""
    _fields_ = [
        ("wd_status", c_ubyte),
        ("wd_counter", c_ubyte),
        ("wd_divider", c_ushort),
        ("wd_time_pd", c_ushort),
    ]


class MasterIdentity(Structure):
    """主站身份信息"""
    _fields_ = [
        ("vendor_id", c_uint),
        ("product_code", c_uint),
        ("revision_no", c_uint),
        ("serial_no", c_uint),
        ("device_name", ctypes.c_char * 64),
        ("hw_version", ctypes.c_char * 32),
        ("sw_version", ctypes.c_char * 32),
    ]


class MasterDiagData(Structure):
    """主站诊断数据"""
    _fields_ = [
        ("cyclic_lost_frames", c_uint),
        ("acyclic_lost_frames", c_uint),
        ("cyclic_frames_per_sec", c_uint),
        ("acyclic_frames_per_sec", c_uint),
        ("master_state", c_ushort),
    ]


class StartupParam(Structure):
    """启动参数 (匹配 C DLL ec_startup_param_t)"""
    _pack_ = 1
    _fields_ = [
        ("index", c_ushort),
        ("sub_index", c_ubyte),
        ("data", c_ubyte * 256),
        ("data_len", c_ushort),
        ("transition", c_ubyte),    # 0=IP, 1=PS, 2=SO, 3=OS, 4=SP, 5=PI
        ("timing", c_ubyte),        # 0=Before, 1=After
        ("priority", c_ushort),
        ("complete_access", c_ubyte),
        ("is_register_write", c_ubyte),
    ]


class FoEOptions(Structure):
    """FoE 扩展选项 (匹配 C DLL ec_foe_options_t)"""
    _fields_ = [
        ("enable_crc", c_ubyte),
        ("strict_mode", c_ubyte),
        ("auto_append_crc", c_ubyte),
        ("expected_crc", c_uint),
        ("crc_progress_callback", c_void_p),
        ("crc_callback_userdata", c_void_p),
        ("reserved", c_uint * 8),
    ]


class RedundancyStatus(Structure):
    """冗余状态信息 (匹配 C DLL ec_redundancy_status_t)"""
    _fields_ = [
        ("state", c_int),
        ("primary_link_up", c_int),
        ("secondary_link_up", c_int),
        ("primary_tx_frames", c_uint),
        ("primary_rx_frames", c_uint),
        ("secondary_tx_frames", c_uint),
        ("secondary_rx_frames", c_uint),
        ("failover_count", c_uint),
        ("last_failover_time", c_uint),
    ]


class CommunicationStats(Structure):
    """通信统计信息 (匹配 C DLL ec_communication_stats_t)"""
    _fields_ = [
        ("total_cycles", c_uint),
        ("successful_cycles", c_uint),
        ("failed_cycles", c_uint),
        ("timeout_cycles", c_uint),
        ("average_cycle_time_us", c_double),
        ("max_cycle_time_us", c_double),
        ("min_cycle_time_us", c_double),
    ]


class PDOStats(Structure):
    """PDO 性能统计结构体 (对应 C# Structures.PDOStats, Pack=1, uint*5 + ulong*4)"""
    _pack_ = 1
    _fields_ = [
        ("read_count", c_uint),
        ("write_count", c_uint),
        ("error_count", c_uint),
        ("total_bytes_read", c_uint),
        ("total_bytes_written", c_uint),
        ("last_cycle_time_ns", c_uint64),
        ("min_cycle_time_ns", c_uint64),
        ("max_cycle_time_ns", c_uint64),
        ("avg_cycle_time_ns", c_uint64),
    ]


class FsoEState(IntEnum):
    """FSoE 状态机状态 (ETG.5100)"""
    RESET = 0x100       # 初始/重置状态
    SESSION = 0x101     # 会话建立
    CONNECTION = 0x102  # 连接建立
    PARAMETER = 0x103   # 参数下载
    DATA = 0x104        # 数据交换
    FAILSAFE = 0x105    # 失效安全


class FsoEError(IntEnum):
    """FSoE 错误代码 (ETG.5001.4)"""
    NONE = 0x0000               # 无错误
    WRONG_COMMAND = 0x0001      # 错误的命令
    UNKNOWN_COMMAND = 0x0002    # 未知命令
    WRONG_CONN_ID = 0x0003      # 连接ID不匹配
    CRC = 0x0004                # CRC校验失败
    WATCHDOG = 0x0005           # 看门狗超时
    WRONG_ADDRESS = 0x0006      # 错误的FSoE地址
    WRONG_DATA = 0x0007         # 无效数据
    COMM_PARAM_LENGTH = 0x0008  # 通信参数长度错误
    COMM_PARAM = 0x0009         # 通信参数错误
    APP_PARAM_LENGTH = 0x000A   # 应用参数长度错误
    APP_PARAM = 0x000B          # 应用参数错误
    UNEXPECTED_SESSION = 0x000C # 意外的会话命令
    FAILSAFE_DATA = 0x000D      # 收到失效安全数据
    NOT_INITIALIZED = 0x0100    # FSoE未初始化
    MAX_CONNECTIONS = 0x0101    # 达到最大连接数
    INVALID_STATE = 0x0102      # 无效状态转换


class CiA402State(IntEnum):
    """CiA 402 驱动状态"""
    NOT_READY = 0           # 未就绪
    SWITCH_ON_DISABLED = 1  # 使能关闭
    READY_TO_SWITCH_ON = 2  # 准备使能
    SWITCHED_ON = 3         # 已使能
    OPERATION_ENABLED = 4   # 运行
    QUICK_STOP_ACTIVE = 5   # 快速停止
    FAULT_REACTION = 6      # 故障反应中
    FAULT = 7               # 故障
    UNKNOWN = 99            # 未知


class EmcyRecord(Structure):
    """EMCY 紧急消息记录"""
    _pack_ = 1
    _fields_ = [
        ("error_code", c_ushort),
        ("error_register", c_ubyte),
        ("data", c_ubyte * 5),
        ("slave_index", c_ushort),
        ("timestamp_ms", c_uint),
    ]


class CoeDiagMetaNative(Structure):
    """
    CoE 0x10F3 诊断历史元数据 (非 DLL 结构, 仅 Python 容器用于 out 参数聚合).
    对应 DLL ``coe_diag_read_meta`` 回填的 4 个 out 参数 + abort code.
    """
    _pack_ = 1
    _fields_ = [
        ("max_messages", c_ubyte),
        ("newest_message", c_ubyte),
        ("newest_acknowledged", c_ubyte),
        ("flags", c_ushort),
        ("abort_code", c_uint),
    ]


class HotConnectGroupNative(Structure):
    """
    Hot-Connect 组原生结构 (匹配 C 端 ec_hotconnect_group_t / hotconnect.h struct hotconnect_group_s).

    与 C# DLL.HotConnectGroupNative 对齐 (Pack=1, 16 字节).
    """
    _pack_ = 1
    _fields_ = [
        ("group_id", c_ushort),            # 组 ID
        ("alias_address", c_ushort),       # 期望 Alias 地址
        ("vendor_id", c_uint),             # 期望 VendorID
        ("product_code", c_uint),          # 期望 ProductCode
        ("is_present", c_int),             # 是否在当前扫描中探测到 (BOOL=int)
        ("detected_slave_index", c_ushort),# 匹配的从站索引
        ("reserved", c_ushort),            # 对齐填充
    ]


class TopologyNode(Structure):
    """网络拓扑节点"""
    _pack_ = 1
    _fields_ = [
        ("slave_index", c_ushort),
        ("config_addr", c_ushort),
        ("parent_index", c_ushort),
        ("entry_port", c_ubyte),
        ("active_ports", c_ubyte),
        ("topology", c_ubyte),
        ("port_type", c_ubyte),
    ]


class EscPortErrorStats(Structure):
    """ESC 端口错误统计 (匹配 C DLL ec_esc_port_error_stats_t)"""
    _fields_ = [
        ("rx_error_count", c_ubyte * 4),       # 端口 0-3 的 RX 错误计数
        ("invalid_frame_count", c_ubyte * 4),   # 端口 0-3 的无效帧计数
        ("lost_link_count", c_ubyte * 4),       # 端口 0-3 的链路丢失计数
    ]


class FsoEConfig(Structure):
    """FSoE 连接配置 (匹配 C DLL fsoe_config_t)"""
    _fields_ = [
        ("connection_id", c_ushort),        # 唯一连接标识符
        ("safety_address", c_ushort),       # FSoE从站安全地址
        ("watchdog_time_ms", c_uint),       # 看门狗超时(毫秒)
        ("safe_input_size", c_ushort),      # 安全输入数据大小(字节)
        ("safe_output_size", c_ushort),     # 安全输出数据大小(字节)
        ("pdo_input_offset", c_uint),       # IOmap中输入偏移
        ("pdo_output_offset", c_uint),      # IOmap中输出偏移
    ]


class FsoEStatus(Structure):
    """FSoE 连接状态 (匹配 C DLL fsoe_status_t)"""
    _fields_ = [
        ("state", c_int),                  # 当前FSoE状态
        ("last_error", c_int),             # 最后的错误代码
        ("error_count", c_uint),           # 总错误计数
        ("frames_sent", c_uint),           # 发送帧数
        ("frames_received", c_uint),       # 接收有效帧数
        ("crc_errors", c_uint),            # CRC错误计数
        ("watchdog_errors", c_uint),       # 看门狗超时计数
        ("watchdog_expired", c_ubyte),     # 当前看门狗状态
        ("in_failsafe", c_ubyte),          # 是否处于失效安全模式
        ("toggle_bit", c_ubyte),           # 当前切换位值
        ("initialized", c_ubyte),          # 连接是否已初始化
    ]


class EcMbxStatsT(Structure):
    """
    邮箱协议统计 (对齐 C 层 ec_mbx_stats_t, x64 自然对齐 72 字节).

    字段含义:
      total_sent/total_received: 发送/接收事务累计
      total_timeout/total_mbx_error/total_proto_error/total_cancelled: 各类错误累计
      last_error_code: 最近一次错误码 (u32) + _pad1 (u32 对齐)
      last_error_time_us: 最近错误时间戳 (微秒)
      total_latency_us: 累计延迟 (微秒, 用于计算平均延迟)
    """
    _fields_ = [
        ("total_sent", c_uint64),
        ("total_received", c_uint64),
        ("total_timeout", c_uint64),
        ("total_mbx_error", c_uint64),
        ("total_proto_error", c_uint64),
        ("total_cancelled", c_uint64),
        ("last_error_code", c_uint32),
        ("_pad1", c_uint32),  # x64 自然对齐 padding, 保证后续 u64 在 8 字节边界
        ("last_error_time_us", c_uint64),
        ("total_latency_us", c_uint64),
    ]


class FsoEMdpConfig(Structure):
    """FSoE MDP 多连接配置 (匹配 C DLL fsoe_mdp_config_t)"""
    _fields_ = [
        ("connection_id", c_ushort),        # 唯一连接标识符
        ("safety_address", c_ushort),       # FSoE从站安全地址
        ("watchdog_time_ms", c_uint),       # 看门狗超时(毫秒)
        ("safe_input_size", c_ushort),      # 安全输入数据大小(字节)
        ("safe_output_size", c_ushort),     # 安全输出数据大小(字节)
        ("pdo_input_offset", c_uint),       # IOmap中输入偏移
        ("pdo_output_offset", c_uint),      # IOmap中输出偏移
        ("module_number", c_ushort),        # 模块编号 (槽位号)
        ("module_profile", c_ushort),       # 模块配置文件
        ("axis_number", c_ushort),          # 轴编号
        ("connection_type", c_ushort),      # 连接类型: 0=Master, 1=Slave
    ]


# ===================== 回调类型定义 =====================

LogCallbackType = CFUNCTYPE(None, c_int, c_void_p)
ProcessDataCyclicCallbackType = CFUNCTYPE(None, c_ushort)
SlaveStateChangeCallbackType = CFUNCTYPE(None, c_ushort, c_ushort, c_int, c_int)
EmergencyEventCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_ushort, c_ushort, c_ubyte, c_ushort, c_ushort
)
SlaveDiscoveryCallbackType = CFUNCTYPE(None, c_ushort, c_ushort, c_int)  # C BOOL = int
RedundancyModeChangedCallbackType = CFUNCTYPE(None, c_ushort, c_int, c_int)
InputDataChangedCallbackType = CFUNCTYPE(None, c_ushort, c_void_p, c_ushort)
FoEProgressCallbackType = CFUNCTYPE(None, c_ushort, c_int, c_int)
DCSyncLostCallbackType = CFUNCTYPE(None, c_ushort, c_ushort, c_int)
CrashNotifyCallbackType = CFUNCTYPE(None, c_int, c_void_p)
PDOFrameLossCallbackType = CFUNCTYPE(None, c_ushort, c_ubyte, c_uint, c_uint)
SlavePreOpReconfigCallbackType = CFUNCTYPE(None, c_ushort, c_ushort)
# 从站身份不符回调 (v2 热插拔自修复):
# (master_index, slave_index, expected_vendor, expected_product, expected_revision,
#                              actual_vendor,   actual_product,   actual_revision)
SlaveIdentityMismatchCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_uint, c_uint, c_uint, c_uint, c_uint, c_uint
)
# 从站端口链路变化回调: (master_index, slave_index, port, is_up)
# port: 0-3 对应 P0/P1/P2/P3; is_up: 1=link 恢复, 0=link 断开 (C BOOL = int)
SlavePortLinkChangedCallbackType = CFUNCTYPE(None, c_ushort, c_ushort, c_ubyte, c_int)

# SoE Notification / Emergency 回调 (ETG.1020 OpCode=5/6)
# 对应 C# DLL.SoENotificationCallback / DLL.SoEEmergencyCallback.
# Notification: (master_index, slave_index, drive_no, idn, element_flags,
#                data_ptr, data_len); data 仅回调期间有效, 必要时立即复制。
# Emergency   : (master_index, slave_index, drive_no, error_code)
SoENotificationCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_ubyte, c_ushort, c_ubyte, c_void_p, c_ushort
)
SoEEmergencyCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_ubyte, c_ushort
)

# FoE BUSY 回调 (ETG.1000.6 Table 93 Done/Entire/BusyText)
# 对应 C# DLL.FoEBusyCallback:
#   (slave, done, entire, text_cstr_or_null, retry_idx)
FoEBusyCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_ushort, c_char_p, c_int
)

# EoE 异步接收 Hook 回调 (对齐 C# DLL.EOEFrameCallback).
#   (master_index, slave, frame_data_ptr, frame_size)
# data 仅回调期间有效, 必要时立即拷贝为 bytes.
EOEFrameCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_void_p, c_int
)

# VoE 异步通知回调 (对齐 C# DLL.VoENotificationCallback).
#   (slave, vendor_id, vendor_type, data_ptr, data_size, user_data)
VoENotificationCallbackType = CFUNCTYPE(
    None, c_ushort, c_uint, c_ushort, c_void_p, c_uint, c_void_p
)


# ===================== 启动参数常量 =====================

TRANS_IP = 0  # Init → PreOp
TRANS_PS = 1  # PreOp → SafeOp
TRANS_SO = 2  # SafeOp → OP
TRANS_OS = 3  # OP → SafeOp
TRANS_SP = 4  # SafeOp → PreOp
TRANS_PI = 5  # PreOp → Init

TIMING_BEFORE = 0
TIMING_AFTER = 1


# ===================== Opaque ordinal lookup =====================
# 该映射表对发行版本不公开明文 (semantic names intentionally redacted).
# 编码方案: marshal -> XOR(_XK) -> base85; 仅运行时解码到内存字典, 源码层不可见.
# 调度器 DarraCoreInvoke / DarraCoreInvokeText 保留命名导出 (公开 ABI), 不在此映射内.
_XK = 0x5A


def _od():
    """运行时解出 ordinal 字典 (模块加载时一次性, 之后只读字典)."""
    raw = base64.b85decode(_ORDINAL_MAP_ENC)
    return marshal.loads(bytes(b ^ _XK for b in raw))


_ORDINAL_MAP_ENC = b"p@2gOKRq)kE<Y$AA}%O99Vj&~Di=E{Dl;@aGqPD)T7XO$Ha|NkA0jR&I~^!BFDe&1Dk?KHJu|aeT3Ucc9X~D!Hajdo6hA*cDG4q+C@wE52tPSBG(0msGq71&T7X0uHa|Nk2{t<{KNLSdJ}C(<J18zMDhNM0H8eakJu|UcT3Ucg2|q3wC_5=K89O#MI6FBpGqzb;T7XvxKQ0M2J1jpPC^auCGq+h<T7Xv_KQ0M2J1jpPC^auCGqhP+T7XUoKQ0|8H7_a|BRMud9y2U6K0hckwOLwPfKDAhE*&T}FDe-$IW|8YGb}ScKPWS*Sz20vRS7>X9Vj&~DjzgEI5s~%GpkuzT7Xp@KQ0|8H7_b3G&?vpKRz?4Sz20vNgY2f9Vj&~Djy;$KRGTxJ`E8WGpSixT7XL(KQ0|8H7_a~IW8|dHVqLOGp<=$T7Xs^KQ0|8H7_b2Gdn#quUT4JfJq%cE*m*6Gb}$HC^auC88t67E;FoIT3Uce9X~D|C^auC2{t<{KN&SIG%ho(Sz20vP8~lk8!S6BHaj>rKN%`788s+BDKny3T3Uck2|q3uJ1H(dC>bg*8$3KSG&3$EGox8rT7XXpKQ0O=H90>iDH$p+8$3KSG&3$EGoV>oT7W?aKQ}cjKL|fNHZC(aKNTu2GdD9JJ1#RdG$}KoSz20vL>)ga2tPYEE;Bbj6)G+>H!~nRE;BVWDG4q+E-xuFrde8AfK3TME(#tM4l*b|J3bjIFB?2OGc+?UBQvL2T3Ucj9X~D#9u*EUC_g(s87eOuJUlZrGcF@Dq*+>8fKLfOE*=>hFD^9+GBZ3bA2d5SHa|WyrCC~9fKMGiE*=>hFD^9+GBZ3bA2d5SHa|WyT3%XOfJQYbJ2nL@J2o>uJ1##3E;BbjC<Qw?IWH(XIU_S$URqj!R0%&W7BxK?J2o~rJ2^2kSYBFMfKm=9J2^iVH9a#~URqj!R|!8Z3LX^}H9b8uG(9t3URqj!O9?+N7dtaHI5i>`H9b8uG(9t4URqj!RS7>X9zQrQJr*@RJu@^tGhAL;T7Xv>HZ>_f9zQrQJr*@RGhJR<T7Z8DKRq)kE<Y#=C^b1hDJdR1E;|_`IW{vn89O#MI6FBp2_rN)Gg4k!T7Y~AKRq)kE<Y#=C^b1hDJdR1E;|_`IW{vn89O#MI6FBp8!00+IWtpUT3Ud92tPeDDK0-K2{t<{KM5{7E<YJEJ2X8%89O#MI6FBp2_rN)Gf-YyT7Z8DKRq)kE<Y#<Hajdo2`)P>KN&JRG(A5VJ2o~rJ2^2MDI+vFGf`ezT7X0dKRq)kE<Y$AH$NynKQuWbA1psKE*U#EHaI&uF*8<PT3Ud32tPeDDK0-K2{t<{KOQqFIW;UlC?gp=Ha0jrIWY+%G&wU@URqj!c?dr}Gbt`VC<!(@EI%GIDLFMPKPV#^J2o~rJ2^2MDI+vFGgMw$T7X6fKRq)kE<Y#=9u*uYJ2yWTH7O|>J2o~rJ2^2kRbE<JfPV--Ju@jTKPU)4J})#rJ2W{X7d1XV88SOGJwHAfJ2o~rJ2^2kN?ux8fOrT$Ju@jTKPU+{J1jp6C_fb{2tPSBG(0ms89O#MI6FBpGfQ4tT7Z8DKRq)kE<Y#<Hajdo6FxsQE;BA87c(h0J1#jg89O#MI6FBpGe}-qT7Y^8KRq)kE<Y#}G%7DH9y=~O88SOGJwHAfJ2o~rJ2^2kNnTo7fPM%+Ju@jTKPU+{J1jp6H7G6?Gc++7GCMRqKRy{dHa0jrIWaR%URqj!P8~lk3LX_4C_6Vl7Bwj;2`)P>DKk%AT3Uci2tO%5E(#tM94I?CKNdA9DG4q+E-5oiURqj!P#h>fKNmkYH7Fx9O<r1BfK?qoE(t#<GdngEFE=<pC^JG{T3Uct9X~D}KP)pjKNLGRKQlvKT3Ucs9X~D)DL*J5H#;*nGeBNiT7XU+KQ0Y3G(I&gDGDexJ})^g5kDg{L0(!~fL9$qE*>Z|EI%j~Gbt`JMqXN4fKMGiE*Uj9H!n0ZIXf;hH8cq>J1!|RM_yW5fK3QLDL*b5H8(deG&4CnE;BVW2`)P>DKkV~T3UcW2`)P*E($*=JT)jcJ2W{z7d139E;T4KG(9s#URqj!LkTW5DhfX+JT)jcJ2W{z7d139E;T4KG(9tVURqj!N*zBg2tPYEE;Bbj2`)P>DKmRsT3Ucb2tPeDDK0-K2{j)SH7+weGdVjhGc`0BJ2o~rJ2^2kcwSmsfJO*EJu@jTKPU+`A0IbAC_O(kIU^Z6Ha0jrIWaSNURqj!RtYs96FxK_G&wasKQn$_T3Ucs2{j)RJ~SRbIW;~%Gk;!MT7Xp>6(1cxE*3i}E*~f;H7GNDURqj!OB)p*88$yVC>A>@E*~f;H7GNEURqj!OB)p*6Erg}2{t<{KNLSM6FxI?URqj!R2vl^2tPYM4Jb1%KOZ79b6#3nfJ++{9|=D+J{%}JJvTozE<Zjqa9&zkfJ++{9|%7=EC@e4DJefUI5s~sab8+lfK?k69|}J|F%vW_H8DREJ~MV+T3UcZ2|q3kJ~0YD6+ApPH9I~ZA}%O99Vj&~Dl>OpT3Ucd9y2LBI5s~GJ~0YD6+ApPH9I~ZA}%O99Vj&~Dl>FmT3Uck4=O%8E<X)EF%2;}A0jG0IW9jwGj(2CT7Xj<I5j9P2{}77GiqL1T7XmtKPf*h2{}778#py6E;DOhT3Uci9X~D>J1H&;92g2eC=?SJ2{t<{KPfY4URqj!K?^T4IWZhFG(HGFJ})#rJ2Wl|J2NO4J1#jgGihF0T7Xm?KQ0tME-f`EF%vXAH8XBrT3Uce9X~D<KQ1jbC^0DtH8V6WKPWSAURqj!R|z>gGzm64EI$)8JT)_HURqj!O$j+WGzm64EI%1FFElO)KRz!sK07onGi_d4T7XpxFEcqY2{t<{KN&SIG%hn@URqj!LJKc5IWY+~J1jpLH7_(S2tPhAG(I~tE;D0ZT3Uch9X~DzGc-L3Hajdo88t67E;C?WT3Ucg3okP{F$p<4G#fTH6cZUKGhtp@T7XvwKRZ4NHajdo6Er+EGiF{|T7XU+KQ0M5J2W&uJ_$BEEI%1FFElPQXI@%bfJq%cE(tk1G&Dax2{t<{KNB=OH8W&hT3Uck2|q3uJ1H(dC>|LZBRMud4l_4DGi6>{T7XOmKQ0$LDK0-K7Bw|086!D1KMpfDKQkI$T3Uct9X~D(GdD9dJr^}TKQkL%T3Ucf2|q3gBQ!Y}BMCM;EI$)8K0hKe7+zXhfK?tpI4?a3Hajdo5<4j#88aDPT3Ucf2|q3gE;}wi4Kpq>4l_4DH7_nR9$s2nfI<mBE(ta}EI$b@J1##BGcGa?GdDjqFD^45URqj!R~<ht2{t<{KM5{7E<ZCIURqj!P8~lk2{t<{KN}VaE;}wSDH%0BKQkR(T3UcjA2d5SHa`_FE-EiB2_rN)7dtdNJwGTj5?)$bfI=QKDLXheKNT-7DlaYxBQ!Y|J2X2zKPWR3URqj!NF6^e2{t<{KNTt!G&Um~Hak5t5MEkZfJzBJE(ta}EI%J8C^aY>IWaR4URqj!K^;FX2{t<{KOR3UGdVvWH!n6jE;BVW95y>WGZtQ2T7XF%KQ0M2J1jpRDK`!?H$OEmE-5n?URqj!NeMqL2{t<{KOZSK4l_4DH7_nHGZbE0T7XI&KQ0M2J1jpFK0h=rGcF@D6<%6efJqELC^I}G2{t<{KNCJbG%hnPBQpwKT3UcY3_mC{JR=)6HVHO6EI$)IKQt~gE;BzVGYei?T7XCmC^IfU2{t<{KL|fPGbt`VC^HCNT3Uch2tPYM2{t<{KL|fPGbt`VC^HFOT3Ucg4Jb1%KM6KFEI%F=3Ka+rGY(!_T7XpuKRZ4NHajdo9u^7}2o5t3URqj!N(etWH7q|U2{t<{KMpk&3Ns8|T3Uck88tLKGd(XTKM5l=ITt%LJ3T)rGYwu^T7Xv>H8eakJufIf92XZ4GXh>(T7XIkKQ0M2J1jpHDlRiMG&?pk172EMfJz-dE(ta}EI$=0E;BVWJ2o=_URqj!K?y%D2{t<{KM5}?Dm5rBDI6#}H$MnJDnC0eGXY*&T7W?vKQ0M2J1jp5FDfcEC@v`+C_6Vl2tO)6J1#Q@URqj!N(nzM2{t<{KMgxBIWj&qJu?ShT3Ucf2|q3gHajdo3O+LpJ1#jgJ~cfv1YTNNfJ_}fE(ta}EI$o9E;%wjH9Z+MG(0msGX-8+T7XO)KQ0M2J1jp9J1#jgJ~cfFE;}wSDKk1=T3Ucf2|q3yHZ}=1J1jp9J1#jgJ~cfvJ6>8^fJ_NLE*myB2{t<{KMFoG4LdG5GCnmuGdNyaT7XL(KQ0$LDK0-K6FxsQE;BA8GdW&bT7XL(KQ0$LDK0-K9y2>V9y=~OGd^BgT7XF#K0XO9J18zMDhfL&J2yWrKPWRlURqj!LK{9l2`)P*E-xwyJ19FhKQ2Eg7&|UGGBZ40T3Uci88$yVC<!h*C@wE53Ogt}H$N^vC@C{NURqj!LLEOY2`)P*E-xwyJ19FhKQ2Eg88t67E;BM-T3Uci8!9R`BMB}$C@wE53Ogt}H$N^vC@C{DURqj!LmMh8HX{ixJ18zMDhfL&J2yWrKPV|1Ha0UbURqj!NeMqL2`)P>KMgZ3G6^m_C@wE5GcjITT7XIkKQ0L_J1##7KPxXkG&w&rHeOm<fK(PWJ3bjTG(0ms5Gge@GdEsZT7Xp>FD^A1H8eakJufIf2^TXoURqj!Tpu|TG&3$UHC|d;fK(qj6Erg}94Iw695XgQGb&zMT7X?2IT<!JDL*qSURqj!OBpj8Zfa-+3Ogt%KM5{7E<ZCUURqj!O&K#AZfa-+9X~D~G&?vpKN&SQH#;;wGbvtLT7Xm;GaGJdXaxyBE*CXEKQk^~T3Ucq88aJhYG?%=KQ0$FK0h-rURqj!PZ={CZfa-+2tPYM2`)P>FDVT*C_XbRURqj!O&K#AZfa-+4Jb1%KN&SNE+{oN4K*k}Gc8_PT7Xv>GaGJdXayfMJ2*B!Ga_DET7XL#GaGJdXayWQFE%a+KPf*hGb3JFT7W?rGaGJdXayZVE)FO=G$}JKGc`0BH8(dqG(IyRURqj!LK!m~Zfa-+2tO+?KPfH_C_6MMGcGeVG&3PyT3Ucl88aJhYG?%<J1;ga2tO%5E(tC_Dl;ZtT3Ucd88aJhYG?%=KQ0L`Dk?Q7E<ZjVC^IZS7d1XVDKjTtT3Uci88aJhYG?%$DHk<9KM5}?Dm5rBKRz=gURqj!Lm4w0Zfa-+9X~D$FEcqY2`)7%6)G+>H8e9NURqj!Lm4w0Zfa-+2|q3iFEcqY2`)7%6)G+>H8eBYURqj!LK!m~Zfa-+9X~D!GA}MZH7zt1DlRiMG&9>?T3UcY88aJhYG?%sKQ0L}FD^bcEi@G>E;BVWGuU2QT7Y^PGaGJdXayZVE*>)}J2*B!6)Ha{J1#RdG!-f?Gc`0b*<M;&fO;7-8*XZ71qnYc9y2LBI5s~ODnBSYE;BVW6)G+>H8eBcURqj!P8l;BZfa-+9X~D-J2oyADlRiMG&A2`T3Uck88aJhYG?%sKQ0nGHZBz^E;BVWGu&QUT7X9xGaGJdXayZVE*v{AHZBN1J2@^hH8d3}E;BVWGu>WVT7X9xGaGJdXaxyBE*v{AHZBN1J2@^hH8d3}E;BVWGtypKT7XFzGaGJdXayZVE*~f;H7FT1K0h<lURqj!Oc^s9Zfa-+9X~D~C@3{35;G|-H7Fx9&|X?vfI=BF8*XZ71sOI!J18G0C^aY&Gbt`LC?hk`URqj!Oc^s9Zfa-+2|q3pH8(RfJr_SNGBrLk)?Qj#fJ_-P8*XZ71sy*w5;Zq7G(8tTE;2PfGuK{PT7Y^PGaGJdXayZVE(tFxDm5rBKRyyQH#0On7e6jCH9jdb)LvRzfJYfK8*XZ71rsR=E;}?nJ19O9H8(RfJr_SNGBrLk)m~a!fK(qhIU^lEE)p{-E;T44Gs<3CT7XI)H#s92Ha|Nk5;G|-H7Fx9%U)VqfL0$jIU^lEE*Uj1G%hp9URqj!R0<vy2tPYM6ErF>E)QZe$zEDofK>_}6$n2&J`*%5FD?^nY%|VYT3Ucr3LX^*KRZ4XG%7DH4{K~Q&t6(ufK>_}6$n2&J`*%5FD?^lXfw=ST3Ucr3LX^*KRZ4XG%7DH4{2yK&0bnsfK>_}6$n2&J`*%5FD@KuXfwiIT3Ucg3LX^=C^IfU6)!F-FD?&aGs9k5T7XLm9u*BJGcG?BFD@!CE)#2PGr(S2T7XLm9u*BJGcG?BFD@!CE)Q#LGr?Y3T7XLm9u*BJGcG?BFD@!CE)!{JGsa$8T7XLm9u*BJGcG?BFD@!CE)QvFGsj+9T7XLm9u*BJGcG?BFD@!CE*xoSGsIq6T7Xv$H7YeWH9aF3FEchiGsRw7T7XFoH7YeWH9aF8KQ0+EGd4abKQuG?URqj!N)9zDH8wRpBOO032sJe>DKq<CT3Uce9X~D!Hajdo88tLKGd&wVJ}5KzURqj!OC3Kh2{t<{KN~hPJ1HAJJ}5K!URqj!N*zBg2{t<{KMX%KJ~b#4J~RGaT3Ucf9X~D!Hajdo3Me%`FF7t5H9kKx|6W>JfJz-dE(ta}EI$Z8EHf!HH8eB)URqj!P8~lk2{t<{KM6l5GdngEFE=<pC^P+DT3Uce9X~D!Hajdo6)!F-FD@7}E-5qeURqj!NgY2f2{t<{KNT-7DlaY=BQ8HFGxJ_rT7XU+KQ0M2J1jpHFD@!CE)_gHDL*bV@LpP4fJ+@eE(ta}EI$)8DlaY=GcGAJ@m^Y5fJhxbE(ta}EI$)8DlaY=BQ8HFGxlCuT7XF%KQ0M2J1jpFG%7DH6+ApCKQ1%(URqj!OdUTi2{t<{KNT-7DlaYxE;}eL7&9(2^j=z8fKMGiE(ta}EI$)8DlaYxE;}eL7&9(2^<G+9fKDAhE(ta}EI$`JGd4IiA_^!qE;TdiURqj!Kpj6W2{t<{KNmYQHaImR4Jb1%KNdeUJuWgc>t0$~fIuBTE(ta}EI$`JGd4IiA`K`rE<Y7KJSjgeGw5DgT7W|xKQ0M2J1jpJJ2N&oH6jQ<J3baaG(9ddGwEJhT7W|xKQ0M2J1jpJJ2N&oH6jQ<J3bXWJSjgeGwxnmT7XI&KQ0M2J1jpJI3gJ}FElPQ?_OG3fL9$qE(ta}EI$%EDIOU!>|R=0fJz-dE(ta}EI%F@8#yjBEI%{tURqj!N*zBg2{t<{KOPwwBRMudYBS<qT3Ucg9X~D!Hajdo9vK-UIW|9QGvi)bT7Xp@KQ0M2J1jpQ83{5oJT5cfURqj!R2@Gq2{t<{KOPwrKO!zO;a*x=fJhxbE(ta}EI%F@3MfA;Gc_+MGv;1eT7XO)KQ0M2J1jpQ83;c)KQk;p4l_4D8#Cu#T3Uci9X~D!Hajdo9vKKfIX^QjKMpfDKNvIQURqj!OdUTi2{t<{KOPwfKRG`$EI$r2H$NFO<z8A^fJ_}fE(ta}EI%F@2tPSLGb}$2GdDjTGn!snT7XU+KQ0M2J1jpQ845cnKQt~1H7G7Kn_gO4fKDAhE(ta}EI$e|BPlaEJ2nm@DnB!rURqj!P8~lk2{t<{KMpl2H8wRpBMu`fKQozLT3Uch9X~D!HajdoA2co~BMLPrE;F89T3Ucl9X~D!Hajdo88tL1FE>9v3N<J$DKnp5T3Ucq9X~D!Hajdo3LZZ;J0mlkURqj!R~<ht2{t<{KOQb4DnB!wURqj!N*zBg2{t<{KNvPOIWZOp4KtEnT3Ucg9X~D!HajdoA3rK$7$Yt}Gm~CgT7Xm?KQ0M2J1jpRKPn0y6El!rT3Ucq9X~D!Hajdo6DbxoDK0aSURqj!NgY2f2{t<{KOZ<RDH$&)C_gkVGnQUjT7XI&KQ0M2J1jp56B83OK0hKemtI<0fJhxbE(ta}EI%1FA09t0J2N&ZGn8IhT7XC$KQ0M2J1jpOH6I>7E;}<eDKnK`T3Uce9X~D!HajdoA2lByKQ22nHYqcTURqj!NF6^e2{t<{KM6G-9zQNSGd3wRi(Xn<fKMGiE(ta}EI%9<7Y}M2FElwWGc`0bh+bM+fKMGiE(ta}EI%9<7Y}P3FElwWGc`0biC$V-fKMGiE(ta}EI%9<7Y}G0FElwWGc`0bj$T??fKMGiE(ta}EI%9<7Y}J1FElwWGc`0bk6v0@fL0wpE(ta}EI$-GH$O9sURqj!NF6^e2{t<{KOR3UGdVvLJ2yWwjb2(>fK(knE(ta}EI$%EDIX~_GlE`PT7Xm?KQ0M2J1jpEJ1G|)3NwRVT3Ucr2|q3gHajdoA1N~&Gd4dnfL>Z!fJhxbE(ta}EI%J9GYmf{DKj-RGl5=OT7XC$KQ0M2J1jp8KQulyC=@$4KQo42T3UcX9X~D!Hajdo2tPhAG(I~tIU^f6E;B4UE<ZjqhhAD*fI}TWE(ta}EI$e;GdDXZBNj6>F&HQ{F+VgjgkD-&fI%HUE(ta}EI$c9IW;ssJ18R-Gc++6C^a!ZG&6->T3UcXKRF@=H#i~%JwGl5DK0xMDFrwq1vfh>E<Y$Ux?WmZfJZ+$A_X@%A_XWvDL*a+DK0xMDFrwq1vfh>E<Y$UyIxvafJ8qzA_X@%A_XZgI5#sc1v@DtG&u!0BLz1*DK0-KGq_$_T7XPHIU)r&I3fitJ2Nf?I3oo&J1H(dC^NZUT3UcYKRF@=H#i~%IXg5tKQ;w8BLz1*DK0-KGrnG0T7X7BIU)r&I3fi-KQ09*KPfLZE(JIv1vfh>E<Y$Uzg}8efJz-dE(ta}EI$bs7C$sSE;2K`URqj!OA078I6oK&9t9f~DK0xMFDWy<URqj!ND3%5I6oW;2p$C+7AY<}E-xuFvR+zRfJh1`H8?*U3J4wr9u_GsJ1#FNGqYY=T7XpwC^a}g90~{?1ql}jKRq+BURqj!Ocx#s9X~D^H8eakJr^}TFE&3GGbt`Jv0hqQfI=4@3LQT#9zQNWIW9jw7d1XFHa`|KDK0a%URqj!Nf#ap88SaPF&8yHFE&3HJ1#jgGq+w^T7XIy9ts;TE;S!CFE>9ZJ1##nv|d_TfKdq(69_*$J`FV}J~OpmT3Ucs2@?|yC^IfU4K*k}Gpb%%T7XLl6B7tOJ3bjTG%hGLHV8jGGpk-&T7Xaq6B8RbD=#xBKQpLaT3Ucm2@?|tKQ=!*DL*r*URqj!RS6Rl95XaN89OdNJvAsJGp=4*T7Xpv6B7tOJ3bjZE<ZgrC?hkkURqj!ObHVcA2csFKPWpcKN&kNKRq=lGe0RatX^7LfL93<6CFP;2`(rzG(9OZtzKGMfJq4x6CFP;2`(rzG(8w26Er?QA~T|1T3Uch2@?|?KQ0|VG(RXiHWM^FH8Z1LT3Ucj4=O%8E<Xw=H7YwjJ1#RdG#)=TJ0mGGpk7*9fI=NVE(ta}EI$e;H7YwjJ1#RdG#)=TJ0mlpURqj!OdUTi7ds*fC^afOJv%NlH8dVSHajCTre0cFfKD4PE;SiDHaRagJ1##S83{5oJT5b*URqj!R2eliJTpBnC_f$<8#XpGq+VKDfI%NLJ2*B!88tL6Gc+$XFDVy4J1H+HKQ})#E;FTGT3UcjA2d5SHa{LHGdwOCH8(0hG$}hSGc`0bT3=dPfI=NVE(ta}EI$b&G&v13G(I&g2`)P>FDWxyUs_s#PYFLR9vKNEG&vSEDJ~g1Ha0jrIWaR>Us_s#ObI_O2_rN)4Kp-8H7yP@C_gDOH8wsoSzlUOfJ_}fE(s$vISn&3J~b^4GAKVOGBq|nGhSa>T7W|cKPf*h2{t<{KM5l=ISn&3J~b@~E;}wMGhbg?T7XU+KQ0$LA_*fjIUX}SJU=KuG&w&rTwhvRfK?qoE*Co~E<Y$984fcyKQmolT3UcX9X~DzKRiDuKQuW%88$UJF$p$1EI$)8K0hKeQeRqHfJ+l88#XoxHajdoDHAjaBQ!ZPQ(szIfKLfOE*>*GJv22bE;BhPA2d5SHa|WyP+wYFfKMGiE*>*GJv22bE;BhPA2d5SHa|WyQD0hGfI|-|K07Wy9y2>VG&LzMGdU><G&?FOGBqwUR$p3LfJq2HIW;Ig3LX_1BRMud2`)P*E;CnOT3Ucp2tPSBC_W7l88cL0T3Ucq9X~D~A}T*QE<ZjE5g9X8Us_s#R~<ht3Mex-J18R!5g9W|Us_s#RUJPr2|qbCG(I~hBMlK5GfQ7uT7XU+KQ0YEF$yR%H#;aJ94I?CKMo=@NMBl7fKDAhE)7003Mex-J18R@C_6Vl2qH5{Us_s#OdUTi4L&gmKRGotK07EQ94I?CKMo=@PG4GDfJ_}fE)7002|qbCG(I~hBOE9@H$Mm>Gf!VyT7XX-KQ0YEF$z946FwpyC^ae>H7_(SGfZDvT7XL(KQ0P8IWa#j7Bwj;2s<u6GfiJwT7XI&KQ0zKE<YS7J2yWFJ1##nLSI^1fJ+`TJ3TZtDL)i5ITAlRHZC$VLtk22fK?1XC^I}G6f-#zKRY%qGBZG5T3Ucq8!s+32tPSBEI%j|GdVLsUs_s#RTeclF&`o-KRGTxJ`E8WGe%!pT7XLrG&VIkF&`o-KRGTxJ`E8WGe=)qT7XO+G(0sZIX@pFDnB_cKRyjHITkfJF*8J8T3Ucq2|q3$A}T*QE<ZjE5g9W@Us_s#PaQul9y2>VG&LzMGdU>=H8V6WKPWSLUs_s#OdUTi9zQNSGd4dy9y2>VG&LzMGdU?UdtX{wfJz8IDL*bAGdn#rH7PDLIVm%EUs_s#NgY2f2{t<{KNd4IF$*s{HZv|GGkITHT7XL(KQ0L`H#a*dBMLP$G%i0VGk#xMT7W<ZKRZ4NHajdo3N<J$A1Ej_C>b>`G%i0VDKmdxT3Ucd2tPYM8#XoxHajdo3N<J$A1Ej_C>b>`G%i0VDKmUuT3Uci9X~D!Hajdo3N<J$A1Ej_C<!h*E-5p8Us_s#K?px7KQ0M2J1jp6H7G70C@3{388t67E<Y$KGjd;AT7X0kDn2_dKOQqXJv22bE;BhP4Kpq>9|;*BC@3{3DKm3lT3Ucq9X~D@C_g(f3N<q{E-5o`Us_s#OdUTi2{t<{KMFM{E*3L1F$pd^E-xuFabH?mfJ`1QH!2A>J1jp5E+{WKE)_gHDL*bLGj?BET7Xd<KQ0b6Dm6AWJtH%BUs_s#NgY2f2{t<{KN~qNGb}#}H7G7AGjv~CT7Xm?KQ0M2J1jp6J19RiE;DssT3Uce9X~D!Hajdo3Ogu2G%gA?C@wQ<Us_s#PaQul2{t<{KMFf2KQt~0E;}wWH8eA8Us_s#P8~lk2{t<{KOR3WJ2N&vJ`*%NH8W^mT3UcXIW<28J~KN#1u8W*HU%_4Ed@I)J2N&rI5s~sX<u4efJiwtKLtKBJ3R#`KRZ4JH$N^rGj3m6T7XYEH9rMDGdn#6C_g(s1vft_DLXwsGjCs7T7XVDH9rMDGdn#6J2^2lH7zzjK0QA(Y+qVhfJht(H6If+GcFl5G&DasE;BVWGi_g5T7XF$2{j)XHZ>_f88tLCKRGTlH8e9~Us_s#R~!j7A00m~2`)P>FDWx)Us_s#N*oC_9|%7yFFz?R2`)P>KQmxoT3Ucs90@fa9X~D!E;}wiGhts^T7Xj=2{j)GKPf*hGiF~}T7XF$2{j)LC^IfU2|GML6)!F-FD^4@Us_s#OB@L`9|%7?J_$QKKNB=6FD^4=Us_s#OdJU{A09O=G&VImJ_<W1J2yWrKPV|PWnWrafKMC=H6IB-E*v{EHYqziKNT-7DlaZG8edvkfJ+<+H6Ix=KRGcCJ1#jgJ~cfv8(&&lfJz(*H6I;6E*3i}E*~f;H7GL}Us_s#R2&I49~m}3J18G0C^aZE8DCmjfJht(H6Ifx2{t<{KN&kJJ2*B!Gag@BT7XO(2{j)bKQ0+HG&DasE;BVW88t67E;AorT3Ucg90@fa3Me%>KPf30BRMudGaO%9T7XX+2{j)VJ}MJ5GcFl5G&DasE;BVWGaX-AT7XO(2{j)VJ}MbDH7P$CH8eCoIW99bG&2%kT3Ucg90@fa7d|Q-KQ0L_J1#FNGZSB0T7XF$2{j)VJ}L-5D=$AOE(tC>E<ZC6Us_s#RU8R59~V9<9X~D!E;}wiGZ9}}T7Xs@2{j)VJ}L-5DL*bV7GGLgfJ__-H6Ir~Dh((zE<Xu7JU<mLE-EiBGZ$Z4T7XU*2{j)VJ}L-5J3a|JJU<gODlaZG6kl3efI}P!H6Ir~Djqd0G&VImJ_<W1J2yWrKPV|P6<=CffI=JzH6Ir~DhWR>96K{MDLXtr6)!F-FD^3*Us_s#P8<m}9~V9<88SaPF%3H|IWj&qJu?emT3Ucf90@fa7d|Q-KQ0zKDJ~x<C^aZE2wz%SfJ+<+H6Ir~Dj7CEJ18G0C^aZE313=TfJ7V#H6Ir~Djh#A2{t<{KN&SNG(R~mGc`0BH7_(SGY(%`T7W_v2{j)VJ}MqRE<ZUg88tLCKRGTlH8d$R4_{hZfK40;H6Ir~Djh#A9zQHIIX@ddJ}5saDKiXTT3UcZ90@fa7d|Q-KQ0$FJ})*u88tUI3Ogt}H!}@iT3UcZ90@fa7d|Q-KQ0$FJ})*u9y2>VG&LzRDKi3JT3Uce90@fa3_CV6K07Wy88tLC6FxHoUs_s#NIy9REIT$cK07Wy1vxb|JTpBr0AE^KfJi?%1u8!%JOw`@Dm5rB1vx1!GXY;(T7Xg)7##^NJ18zQ247lQfL#|D9SJTqDl-RPT3Ucs7Z@EADF`n#G&3|kGX!5+T7Xd(7#$ryE(tC>E-5nwUs_s#R~Hx^2tO%5E(tC>E-5oQUs_s#P!|{-9X~D#H7G7KJ6~E_fKeA19SJTwC@u~;Dl<4=T3Ucm7Z@E0E;T9+IVv+bUs_s#RTmf?4mm0lDF`n#G&3|kGd^EhT7Xv<7#$ryE)F>=3N<J$Ge2KiT7XU$7#$ryE(t$2KRGTxJ{LPFE<Y$UJYQN`fKC?}9SJ`!2|qSJIW9jw7dt5~KPWRjUs_s#ND?(J88tLCKRGTNK0X~NH7_bNGGAI+fKL)NE*Uj6G(R~m2tPM9EI%D6H7_bNGhbR-fI<>AE*Uj6G(R~m9X~D|C^auC2`)P>FDWxHUs_s#NfI?K88tLCKRGTRG%q(lC_64cGcjLUT7XCrH7*%7G&DasE*UmIJ184AHZwL~T3Ucj5;ZOvH8eCoIW8SPE*&T}FDe-|FElPQH(y#>fJ7NH8*XZ77d1XVDFqibK0gjM2`?%tH7G7WJ{U7DGc;dXT7Y{QGaGJdXcsj;KPd$hDHk<9KM5}?Dm5rBKRy#Q7dt62Gc{jYT7X3vGaGJdXcsj;KPd$tA}TvHJ_#=>Dm5rBKRy>bDKRrDUs_s#O&K#AZfa;3H9kKn1sy*w7d1XV6gxLRGb>+OT7W|tGaGJdXcsj;KPd$rKQ0$FK0g#YH$NXVGbmqLT7X0uGaGJdXcsj;KPd$rKQ0$FK0h8mDLE)JDlRiMG&3n*T3Ucc88aJhYG@ZVK0hf16Db)ZIW{vn2_rN)7d1XVGcI3RT7XO$GaGJdXcsj;KPd$WKPxXYC_gD488a_mT3Ud388aJhYG@ZVK0hf16DbKUJ2XB!C_WN3H#0On7e6jCH9j*eUs_s#MHw?2Zfa;3H9kKn1sy*w5;Zq7G(8tTE;2Pf6gxLRGc8|QT7X6wGaGJdXcsj;KPd$rKQ0nAH#0On4k$A{JwGTjB41isfJ7NH8*XZ77d1XVDFq!rE)q32Gc-LOGblefE;BVWGb3MGT7Z8UGaGJdXcsj;KPd$kGbt_!E;}?nJ19O9H8(RfJr_SNGBrLaGaz4DT7X6$IT<xCDmFhT6FvnVKQ2ExE*?KDGdVvFBPu^LAzxZrfKMMe88t5|Ha{p6J_Qpg88t5|Ha{pcCSO`wfJ`4b88t5|Ha{p6J_Qpg4nHV2Gc-FkGbdkKT7W|zIT<xCDmFhT6FvnUKQ0VEG(I&b6gxLRGbCSHT7W?xIT<xCDmFhT6FvnUKQ0VEG(I&b6gxLRA2c&1Us_s#M;|#EH7_bQKPVGE1sy*w9zQHIIX?~~DnArEH$OAlUs_s#K_598H7_bQKPVGE1sy*w88t5|Ha{pAH9kK!GuvNUT7W<wIT<xCDmFhT6FvnUKQ0VEG(I&b88t67E;HC)T3UcZA2}H{FDf=aC=)&f9X~D~G%hG388t67E;HF*T3Ud6A2}W~J3R?5C^IxYDFqHSDm6AWJtH1JDLE)JDlRiMG&9~`T3UcYA2}W~J3R?5C^IxYDFqHQH#0On7d1XVGv8lYT7X6$IUX}RJqa!-Gc-LZ1sEtlJ25IXGc+y^BPu^L++SK+fJ7fT9y2>V2`(rzG(9N=95pC6J1!U~KRYohH8V6WGu>ZWT7XR-H#s92H9kKD9X~D}KPfpVGb%1KH8eBQUs_s#OCL8mBN;V5KLs5>E*UmEDJe74Us_s#PaiiqBN;V5KLs5>E*UmEDJc{?H$OAbUs_s#MjtmhBN;V5KLs2$C^tJUA1Ej_C<s42Gbt`VC^OMtT3UcfA2&H888tpX1rsR<KRGolKPV$J)?Zp$fKMMe7dtaHI5i>#9X~D(BPu@>J2yWw*I!y%fK4Ac7dtaHI5i>#9X~D(BPu@>J2yWcG&9s+T3UcdA2}C0Gd4IiA_W~kE*~f;H7FiGDLE)JDlRiMG&9v-T3UclA2}C0Gd4IiA_WvbA}$#<FElPcC^O1mT3UcZA2|s%9|avhE*~f;H7FiGDLE)JDlRiMG&9RzT3UcWA2|v>H5oNNKRE>+J1#p8BPu@_GcE};AU`w6Us_s#O&>W5J~bINK0i4H9y=~O4kIc*6gxLRGs$0CT7XX<ISM{C88tpXIRzggE+{)WE)Q&OGtOUHT7XX<ISM{C88tpXIRzggE+{)WE)#5SGtXaIT7XU;ISM{C88tpXIRz6mDL*JK4{UBT%wJksfKDGd3O+R%H9kK%1rszWKPWB}Y;H5nUs_s#LLWH_J~bINK0i4HA0jR&J2@^0KRY&QXfwiJT3UcYA2|v>H5oNNKRE>-A}%O9IW7o4J2q@?Gs9n6T7XR-ISM{C88tpXIRz6mDL*JK2tPYEX=pRRUs_s#O&>W5J~bINK0i4H6ErD5C@u&;J2q@?Gr?b4T7W?xISM{C88tpXIRzOtFElP2IW99SKMFM{E-5p{Us_s#OdmN4J~bINK0i4H9X~D(H7YeWH9aFU$6s1nfIuHP3O+R%H9kK%1sy*w4mBz@HZ?sX6gxLRGsIt7T7X6$ISM{C88tpXIRza*E)F#+H8wRpBNRI~KOZzR#a~)lfK4Ac3O+R%H9kK%1rsR>H7G6{IW99SKQsDYT3Ucj2_6+2I5j9P1sy*w9zQ8LC^IT9Gc`0b`(IjGfKCY>6&pA;C@uvZKQ0+NE<ZgrC?hlYUs_s#P6-|r8#py6E(H@Q2tO_;BRe=YKQsAXT3Ucg2_6+2I5j9P1sy*w5;HU|GyY#%T7XX<ISDf}1sy*w89OdNJvAsJ6gxLRGyh*&T7XI)ISDf}1sOFzA2d5SHa|Wy{9jsHfJz@Z2{SVV88tr%J~b0GJT)`@Us_s#NFO-~GcyGlH9rbIH5(}@Gd(mj@?Tn7fJh%X2{SVV88tr&J~bING(0msGxJ|sT7W_yISDf}1sOFz4=Oe_J3bpO2`)P*E-xxG@LyV5fK4Ac2{SVV88tr{H8(0YKQ2ETIXOQmDKqh3T3UcgA2|s#GX)$qKOZzZI5s~%GxlFvT7XI)ISDf}1s^p(A2d5SHa|Wy_g`9CfJh%X2{SVV95XaN89OdNJvAsJGxT3tT7W|zISDf}1s^moH$NylE<YJNE<ZgrC^J7PGxc9uT7XC&ISDf}1qwSTDL)-QG(RXiHZ$s9T3UckA2|s#GX)(#E(tCuGc-LJH7_(SGwWYkT7XO+ISDf}1sy*w2`(rzG(8w26Er?QA~Wb;T3UcYA2|s#GX)(#E*Uj6JTpBnC_g?MHZwaZGwEMiT7XL*ISDf}1sy*w3_mnJH7FB4GwxqnT7XU;ISDf}1sy*w3Me%`FF7t5H9kKx?_XM4fJ+}a2{SVV9X~DzKP)pTGc`0b>|a`1fKMMe2{SVV9X~D!KPWRhHWV*6I6o*e?O$42fI}ZS2`)P>KLryh3_CV6J`N~5G$}JKGc`0b;$K=?fI}ZS2`)P>KLs5>E)FO=G$}JKGc`00BPu^L<6l}@fI}ZS2`)P>KLs5>E)FO=G$}JKGc_~{J1#Oa;9pu=fI%NQ2`)P>KLryh7&SF6DK02GDhNL-FEc1VJ~QE8T3UcrA2|swJ1##39X~D<J2yWw=3iP`fJ+}a2`)P>KLs5>E)+XAKOZzR=U-Y{fJq-Y2`)P>KLrvyDIX{(H7FZ7F*D>}T3UclA2|swJ1##32`(rzDjz5)H7FZ7F*D^~T3Ucc8x{o#E;}wSDH%0BKLs5>E*?KAIVdwKE;BVWGn!voT7W|v76l0|J1#FN88tpX1sy*w2|p}9C^If2Gn-#pT7X9z76l0|J1#FN88tpX1sy*w2tPSBEI%kC5;HU|GnijmT7X0w76l0|J1#FN88tpX1rsR@KQulyC<!V*IWs&nIWw7GT3Ucz92Fl3KRZ4%o?lv8fKnV49}OroE<ZD$Us_s#NE{U(2|q3hC^bDOKPf2^H8n9aoL^d6fKD709~m}3J17b$H9aUlDJc>)H8C@tUs_s#Qydi^2tPYMA0ji7Us_s#P#hH>4Jb1%KOZ79lV4g|fK(h69|=D$7%wR!5;Zk3Gmu|eT7XI%6(0ycD=$AOE*U#CIX^ZtkzZO`fK(h69~m}3J17}DG&w&uGnQXkT7Xg?6(0#dE)xnfmtR_1fKne7A00m~6ACkwUs_s#Qy&!{2|q3u8yPc|Us_s#Qy&!{9X~D?8yPc-Us_s#Qy&!{2|q3#6bUnnUs_s#RUZ`}9X~D{FE%y`J19FhGl*YWT7Xp_6(0#dE*vj5HVQi^J2x|lUs_s#Qy&!{9X~D}6bUnqUs_s#Ngov-2|q3yK0YWvDJdK?HZDIXGml?dT7XF(6(1cxE*m~RC_gDF95Xg9KPWSdUs_s#Rv#4~2|qMG94I?CKQoPAT3Ucr9~B=6KRG`$EI%A5J2yWwf?rx%fK(q99|=D+J{%}JH$NXDGlO4RT7XR-6(0#dE*m~RC_gDF95Xg9KPVh8Ha0VWUs_s#OCJ><2|q3fKRG`$EI$%8H8C@RUs_s#Ngov-88$yVC<s3}KQk;p5;Zk3GlpMUT7X>%H6I8+J3cdqUs_s#QVBI54Jb1%KQn}1T3Uch2{j)GKRZ4fE-olDI4>?gDKmv%T3Ucn2{j)GKRZ4YJ2yWwx?fsafKdrG9|%7?J`XfAE;GAdT3Ucq2{j)GKRZ4X9uyWcDK0a(Us_s#R|z#A2tPYM7c(>$J0df=Us_s#R2vl^2|qMG88tUIJ2XBszF%5efL0q79|%7?J`E@{E<ZEBUs_s#OB)p*2tPYM9zQHIIX@FLJT)`CUs_s#RvQ%`2tPYM2`)P>KQp~wT3Ucr8x<c7C^IfU88tL6C^a@SvR_(SfJhq^9~(YC6g4h0JTo~vE;BVWGqYb>T7XC!6(1fyHWW23GdwdnJ1#RdG&8VYT3Ucs8x<c3KQ0+HG(0msGqGP<T7Xs?6(1cxE*Uj6JTpBrwqIIWfK&_>9}_7FFDfcEC@w!fGq+z_T7X>)6(0#dG(I!5Us_s#Pz)6x2tPSLGb}$dwO?9VfKUt-9|=D+J_tK4Gpb)&T7Xv!6(0ycIX^QjKL|T5Gpk=(T7XFm6(1cxE*3i}E*~f;H7FT1K0h<4Us_s#Mhq1n2`)P*E)+E`GdwdnJ1#RdG!`={E<ZFsC^M;FT3UcX3>6;<E;T9?H7+weGdVjhGc`08Gbt`VG(RXau3uVOfItit9}_7QH7+weGdVjhGc`08Gbt`VG&3|kGp}D-T7XRq6(0ycJu@jTKPVJ6E;BqcIXf;hH8eA<Us_s#Lktxk4>Tx0Ju@jTKPVJ6E;BqcIXf;hH8eA=Us_s#MjI6$2`)P*E)+E`GdwdnJ1#RdG!`={E<ZFsC^Mp8T3UcX8x<c3E;T9?H7+weGdVjhGc`08Gbt`VG(RXaqhDHDfIu4+9}_7QH7+weGdVjhGc`08Gbt`VG&3|kGoW8uT7XR(6(0ycJu@jTKPVJ6E;BqcIXf;hH8eA!Us_s#LmL$z4>Tx0Ju@jTKPVJ6E;BqcIXf;hH8eA(Us_s#OdUTi2|qbCG(I~hBNj6>F$pd^E-xuFr(arHfJz@UJ2*B!2tPhAG(I~tIU_TqUs_s#NgY2f2tPhAG(I~tIU@-!J1#FNGo@czT7XR)H7Geh2tPhAG(I~tIU^i9Gd49WKPWR=Tv}RyPZ=^lIWY)7J})#rJ2W{X5<fdOE;2J)Tv}RyO9?+N2tPgwC^b1hDJecXE;}<=Tv}RyOC3Kh2tPgwC^b1hDJecXE;}<>Tv}RyNgp&jI5s~DGd(>cI6FBp9y2>VGhSR;T7XOwDGD<^JtH_fIWZnHJ3SvXJ2*B!J~LljT3Ucn9X~DzGc-LHH9kKxTwGdOfKUlPE)PB`7d1XVGhJL-T7Xa;KQ0eGDi<|AKQmHXT3Ucq6DbcqDjO_2Gd4RoHa{~{Tv}RyP9HQWFDO4AC^IZSC@BapG&D0bJu^^TT3Ucm6Erg}GdngjAU`uvTv}RyLK8GIE;BneGax?+DnB_hJTo~LJ1H(dC^J@ET3Ucz9y2K_H7P$cS6o_JfKUlPE)+j5Ej1`HGgMq!T7XgsKQ0L_J1##nRa{zHfL9$qE*3L1F$pd^E-xuFN?cl6fK(knE*Co~E<Y#<E;}wiGfP}rT7Xp<H7X+)J1H(dC<!h*E<ZC!Tv}RyNgY2f7dt5~KPU+<J1##NJ2^5xGf7-pT7Xg=KQ0M2J1jplPFz}AfL|RyE)x|qPh47BfKwJVIWZFzH#;gbOk7%8fKd-LHZ?gh6BRc*Dl<)7T3Uce9X~D?FD^eK3Me%$KRGTlH8e9qTv}RyN)0G8E<Xu2J1jpHFD@!CE;B=1T3Uck4Jb1%KM6KFEI$=5E-EiB7$Yt}GeBHgT7XU+KQ0M2J1jp59u*cdDJ~d0DKj}UL0no|fK?qoE(ta}EI$bz6&5ooE;B}4T3Uck9X~D?FE%bS2{t<{KM5Wc7BeX>Ge=xnT7XX+C_g_JFE%bS2{t<{KM5Wc7BeX>GelfkT7XF%KQ0M2J1jp6H8V6WKPUwW9u+f1Tv}RyL>)ga2{t<{KMFN7G%i0V1qmJ%1r0MUG8G;cGbt`JdR$ssfI}TWE(ta}EI$f0Gc+zgC<O@~6$K1CHZMOjdt6#tfJ7ZXE(ta}EI$f0Gc+zgC<O@~6$KMCK0hK1J2o#rGk9EDT7Xgs9u+MpGcG?fd0bjrfL#e56(~PDJ~Mt?T3Ucm2_6+FKRZ4JKO!@KTv}RyQ3)OuEhsZCKLtM`GkjcHT7XqKH9rMCKQ09|J_R;2DK0a8Tv}RyNjWt?1wB751vNM@KRGT1K0hfrGjd#7T7XD7H9rMCKQ0A7G%hG31wKD1IWu!yT3UcrIW<28JSaau1vNf4Gbt`Ja9mnifK@p)KLtD}KR*REKQ=QdE;DglT3UckA1OBzDHcCHJ2nm|J2WXXE;BVWGj?2BT7XO+DK{NIE*3vMJ2nm|J2WXXE;BVWDKmFmT3UciA1OB-KQ10WJUcHoE)Fv{KQ%8d7b!DzTv}RyOdlyX6DbiiH7zt7HVG~}E-xt=H9kKxbzE9nfK4AMHyJiNDJe5NBO5jeE;}wSDH%0BKQn4vT3UchA1OB-KQ0$LDK0-K88$m9DKl$aT3Uck88SaPF&HmAJU=KCG%i0qC^If2GiY2|T7XC$KQ0+NIWj*AH8nN~E;}wSDKlwYT3Ucg9X~D^J2^5x3N<x07d1XVGj3d3T7XIuDH%ICGCvA6H8u!8J3b>bZ(LehfK(hdFDWt^J2^5x3N<x0Gi+R1T7XL(KQ0+NIWj*AH8nOLC@3{3Gi_X2T7X{(E;}eLGh$p?T7X^&E;TAMV_aHVfKMGiE*Co@7dt5~KPVG4DK0xSIX@{gU|d>SfIu56DmEhsKRY%qGdDjKDlRiOGax%IGc`0RGhtj>T7XL(KQ10NHVi)~DKj-R6Er+EGiF>`T7XCiKQ0$9E<Yj)C^arWIW99bG&5&hT3Ucr7Be|NG$}tDIW99SJ1##nWn5ZXfJq-TFE>9ZJ1##SKRi1xHZBT2H8U7oT3Uct2|q3#ISC^)ITtlPKQkI!T3Uct9X~D}ISC^)ITtlPKQkL#T3UcZA2}Z>GX)(#E*?KDGdVvBJ~b0GJ~KH#DYF?|T3UcWA2}Z>GX)(#E*?KDGdVvBJ~at5AU_y0E-AAfTv}RyPaioSDKiBfKQ10WEHgPj2{#ioJT<c)Tv}RyLmxRGDKiBfKQ10WEHgPj9ytjkG&vVFK0mV@Tv}RyM;|#KDKiBfKQ10WEHgPj7dtaHI5i>;GdDjqFD|nkTv}RyO&>WQDKiBfKQ10WEHgPj6FxsQE;BA8vl3idT51"
_ORDINAL_MAP = _od()


def _resolve_export(real_dll, name):
    """根据语义名解析真实导出符号 (优先 D_<ordinal>, 兜底原名).

    返回 ctypes 函数对象, 或抛 AttributeError (调用方处理 missing).
    """
    ordinal = _ORDINAL_MAP.get(name)
    if ordinal is not None:
        try:
            return getattr(real_dll, "D_%d" % ordinal)
        except AttributeError:
            # ordinal 形式未导出, 兜底尝试原名 (用于过渡期/旧 DLL)
            pass
    return getattr(real_dll, name)


# ===================== DLL 加载与函数签名 =====================

class DarraCoreDLL:
    """
    Darra.Core.dll 原生函数封装
    负责加载 DLL 并定义所有 C 函数的 argtypes/restype
    """

    DLL_NAME = "Darra.Core.dll"

    def __init__(self, dll_path: Optional[str] = None):
        """
        加载 Darra.Core.dll

        参数:
            dll_path: DLL 文件路径。若为 None，按以下顺序搜索:
                      1. 当前工作目录
                      2. 本模块所在目录
                      3. 系统 PATH
        """
        self._dll = self._load_dll(dll_path)
        self._setup_functions()

    def _load_dll(self, dll_path: Optional[str]) -> ctypes.CDLL:
        """搜索并加载 DLL.

        Windows 上 Python 不再使用 PATH 解析 DLL 依赖, 必须用 os.add_dll_directory.
        额外搜索: DARRA_DLL_PATH 环境变量 / PATH 中的目录 / 包同目录.

        策略: 收集多个候选 DLL, 按"修改时间最新"排序优先尝试 (确保最新构建优先).
        每个候选若加载失败, 记录原因并尝试下一个.
        """
        # 1) 收集候选 DLL 文件路径 (绝对路径, 去重)
        candidates = []
        seen = set()

        def _add_candidate(path):
            if not path:
                return
            ap = os.path.abspath(path)
            if ap in seen:
                return
            if os.path.isfile(ap):
                seen.add(ap)
                candidates.append(ap)

        # 显式参数最优先
        if dll_path:
            _add_candidate(dll_path)

        # 环境变量
        env_dir = os.environ.get('DARRA_DLL_PATH')
        if env_dir and os.path.isdir(env_dir):
            _add_candidate(os.path.join(env_dir, self.DLL_NAME))

        # 当前目录 / 包同目录
        for d in (os.getcwd(), os.path.dirname(os.path.abspath(__file__))):
            _add_candidate(os.path.join(d, self.DLL_NAME))

        # PATH 中含 Darra.Core.dll 的目录
        for p in os.environ.get('PATH', '').split(os.pathsep):
            p = p.strip().strip('"')
            if p and os.path.isdir(p):
                _add_candidate(os.path.join(p, self.DLL_NAME))

        # 2) 收集所有 dll 搜索目录 (用于解析依赖)
        dep_dirs = set()
        for c in candidates:
            dep_dirs.add(os.path.dirname(c))
        # PATH 中含 VMProtectSDK64.dll 的目录也注册 (依赖)
        for p in os.environ.get('PATH', '').split(os.pathsep):
            p = p.strip().strip('"')
            if p and os.path.isdir(p) and os.path.isfile(os.path.join(p, 'VMProtectSDK64.dll')):
                dep_dirs.add(os.path.abspath(p))

        if hasattr(os, 'add_dll_directory'):
            for d in dep_dirs:
                try:
                    os.add_dll_directory(d)
                except (FileNotFoundError, OSError):
                    pass

        # 3) 按修改时间倒序排, 最新的 DLL 优先 (避免被旧版命中)
        try:
            candidates.sort(key=lambda c: os.path.getmtime(c), reverse=True)
        except OSError:
            pass

        # 4) 依次尝试加载, 失败则跳到下一个
        last_err = None
        for c in candidates:
            try:
                return ctypes.CDLL(c)
            except (OSError, FileNotFoundError) as e:
                last_err = (c, str(e))
                continue

        # 5) 最后兜底用系统路径名
        try:
            return ctypes.CDLL(self.DLL_NAME)
        except OSError as e:
            tried = '\n  '.join(f'{c}: {err}' for c, err in [(last_err[0], last_err[1])] if last_err)
            raise OSError(
                f"无法加载 {self.DLL_NAME}. 已尝试 {len(candidates)} 个候选.\n"
                f"最后错误: {tried or e}"
            )

    def _setup_functions(self):
        """声明所有 DLL 导出函数的参数类型和返回类型

        注: 由于 DLL 版本可能不同步, 若某些符号未导出, 不阻塞 import,
        改为生成一个调用时抛出 NotImplementedError 的占位 stub.
        """
        # 缺失符号集合 (供调用方诊断 / 跳过相应功能)
        self.missing_symbols = set()
        _real_dll = self._dll
        _missing_set = self.missing_symbols

        class _TolerantDllProxy:
            """对底层 DLL 进行容忍访问的代理: 缺失符号返回一个可被 _sig 设置签名的占位.

            语义名 -> ordinal D_NNNN 的转发由 _resolve_export 完成,
            缺失符号 (DLL 未导出) 返回 stub, 调用时报 NotImplementedError.
            """
            def __getattr__(self, name):
                try:
                    return _resolve_export(_real_dll, name)
                except AttributeError:
                    _missing_set.add(name)
                    # 返回一个具备 .restype/.argtypes 字段的 stub, 供 _sig 设置而不报错;
                    # 真正调用时抛 NotImplementedError.
                    class _Stub:
                        __name__ = name
                        restype = None
                        argtypes = None
                        def __call__(self, *_a, **_kw):
                            raise NotImplementedError(
                                f"DLL symbol '{name}' not exported by current Darra.Core.dll"
                            )
                    return _Stub()

        dll = _TolerantDllProxy()

        # ---- 内存管理 ----
        self._sig(dll.FreeMemory, None, [c_void_p])

        # ---- 版本信息 ----
        self._sig(dll.GetDllVersionInfo, c_void_p, [])

        # ---- 结构体对齐诊断 ----
        self._sig(dll.DumpSlaveStructOffsets, None, [])

        # ---- 初始化/销毁 ----
        self._sig(dll.Initialize, c_ushort, [])
        self._sig(dll.InitializeSpecificMaster, c_ushort, [c_ushort])
        self._sig(dll.Dispose, None, [c_ushort])

        # ---- CPU 亲和性 ----
        self._sig(dll.GetAvailableCpuCores, c_int, [])
        self._sig(dll.GetMaxMasterInstances, c_int, [])
        self._sig(dll.SetMasterCpuAffinity, c_bool, [c_ushort, c_int])
        self._sig(dll.SetProcessCpuAffinity, c_bool, [c_int])

        # ---- 周期与同步 ----
        self._sig(dll.SetMasterLoopCycleTime, None, [c_ushort, c_uint])
        self._sig(dll.SetSyncBySlaveIndex, None, [c_ushort, c_ushort, c_uint, c_uint, c_int])

        # ---- DC (ETG.1500 5.13) ----
        self._sig(dll.UpdatePropagationDelays, c_int, [c_ushort])
        self._sig(dll.AutoCalculateDCShift, c_int, [c_ushort])
        self._sig(dll.ConfigureDCAll, c_int, [c_ushort, c_uint, c_uint])
        self._sig(dll.GetSlavePropagationDelay, c_int, [c_ushort, c_ushort])
        self._sig(dll.GetMaxPropagationDelay, c_int, [c_ushort])
        self._sig(dll.EnableContinuousMeasurement, None, [c_ushort, c_bool, c_uint])
        self._sig(dll.EnableDriftCompensation, None, [c_ushort, c_bool, c_int, c_int])

        # ---- DC 同步窗口 (ETG.1500 5.13.3) ----
        self._sig(dll.GetSlaveSyncWindowStatus, c_bool,
                  [c_ushort, c_ushort, POINTER(c_int), POINTER(c_int),
                   POINTER(c_int), POINTER(c_int), POINTER(c_uint)])  # BOOL* 用 c_int(4字节), 不能用 c_bool(1字节)
        self._sig(dll.SetSyncWindowThreshold, None, [c_ushort, c_int])
        self._sig(dll.GetSyncWindowThreshold, c_int, [c_ushort])
        self._sig(dll.ResetSlaveSyncWindowStats, None, [c_ushort, c_ushort])
        self._sig(dll.GetMaxSyncDifference, c_int, [c_ushort])
        self._sig(dll.IsAllSlavesInSync, c_bool, [c_ushort])
        self._sig(dll.SetDCSyncLostCallback, None, [DCSyncLostCallbackType])

        # ---- 通信统计 ----
        self._sig(dll.GetCommunicationStats, c_void_p, [c_ushort])
        self._sig(dll.ResetCommunicationStats, None, [c_ushort])
        self._sig(dll.GetSlaveDetailedInfo, c_void_p, [c_ushort, c_ushort])

        # ---- 日志 ----
        self._sig(dll.SetPDOLogging, None, [c_bool])
        self._sig(dll.SetMailboxLogging, None, [c_bool])
        self._sig(dll.SetDebugLogging, None, [c_bool])
        self._sig(dll.SetLogCallback, None, [LogCallbackType])
        self._sig(dll.SetCrashCallback, None, [CrashNotifyCallbackType])
        self._sig(dll.CloseDebugLog, None, [])

        # ---- 设备信息与授权 ----
        self._sig(dll.GetSerialNumber, c_void_p, [])
        self._sig(dll.GetDeviceName, c_void_p, [])
        self._sig(dll.GetUserEmail, c_void_p, [])
        self._sig(dll.GetWindowsProductKey, c_void_p, [])
        self._sig(dll.GetDriverList, c_void_p, [])
        self._sig(dll.CheckBufferIntegrity, c_int, [])
        self._sig(dll.FlushCachePool, None, [])
        self._sig(dll.IsCachePoolReady, c_bool, [])
        # 激活授权 — 内核 WSK 走驱动多 NIC 群发 (3s 超时), SDK 不走 HTTP
        # int LicenseActivate(const char* code, char* err_buf, int err_buf_len)
        self._sig(dll.LicenseActivate, c_int, [c_char_p, c_char_p, c_int])

        # ---- 网络扫描 ----
        self._sig(dll.GetNetworkInfo, c_int, [c_bool, c_bool])
        self._sig(dll.GetNetworksPointer, c_void_p, [])
        self._sig(dll.QuickSlaveCount, c_int, [c_char_p])
        self._sig(dll.QuickSlaveCountRedundant, c_int, [c_char_p, c_char_p])
        self._sig(dll.ScanSlaveCount, c_int, [c_char_p])
        self._sig(dll.ScanSlaveCountRedundant, c_int, [c_char_p, c_char_p])
        self._sig(dll.GetRingSlaveCount, c_int, [])
        self._sig(dll.AbortScan, None, [])
        self._sig(dll.ResetScanAbort, None, [])
        self._sig(dll.AbortNetwork, None, [])
        self._sig(dll.ResetAbortNetwork, None, [])
        self._sig(dll.EmergencyCloseNics, None, [])

        # ---- 冗余模式 ----
        self._sig(dll.SetRedProcessdata, None, [c_int])
        self._sig(dll.GetRedProcessdata, c_int, [])

        # ---- 网络连接 ----
        self._sig(dll.SetNetwork, c_ushort, [c_ushort, c_char_p, c_char_p])

        # ---- 状态管理 ----
        self._sig(dll.GetMasterState, c_void_p, [c_ushort])
        self._sig(dll.GetMasterStateCache, c_void_p, [c_ushort])
        self._sig(dll.SetStateCacheUpdateInterval, None, [c_ushort, c_uint])
        self._sig(dll.GetStateCacheUpdateInterval, c_uint, [c_ushort])
        self._sig(dll.GetSlave, c_void_p, [c_ushort, c_ushort])
        self._sig(dll.GetLinkStatus, c_int, [c_ushort])
        self._sig(dll.SetState, c_bool, [c_ushort, c_ubyte])
        self._sig(dll.SetStateWithTimeout, c_bool, [c_ushort, c_ubyte, c_uint])
        self._sig(dll.SetSlaveStateWithTimeout, c_bool, [c_ushort, c_ushort, c_ubyte, c_uint])
        self._sig(dll.SetStateWithStartup, c_bool, [c_ushort, c_ubyte, c_uint])
        self._sig(dll.SetStateSequence, c_bool, [c_ushort, c_ubyte, c_uint])

        # ---- IO ----
        self._sig(dll.GetIO, c_ubyte, [c_ushort, c_ushort,
                  POINTER(c_int), POINTER(c_void_p), POINTER(c_int), POINTER(c_void_p)])
        self._sig(dll.LockIOmap, None, [c_ushort])
        self._sig(dll.UnlockIOmap, None, [c_ushort])

        # ---- 启停 ----
        self._sig(dll.Start, None, [c_ushort])
        self._sig(dll.Stop, None, [c_ushort])

        # ---- SDO ----
        self._sig(dll.GetSlaveSDOList, c_void_p, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveSDOListBasic, c_void_p, [c_ushort, c_ushort])
        self._sig(dll.GetSlavePointer_SDO_Value, c_void_p,
                  [c_ushort, c_ushort, c_ushort, c_ubyte, POINTER(c_int)])
        self._sig(dll.GetSlavePointer_SDO_IndexValue, c_void_p,
                  [c_ushort, c_ushort, c_ushort, c_ubyte, POINTER(c_int)])

        # ---- SDO 辅助 ----
        self._sig(dll.GetSlavePointer_SDO, c_void_p, [c_ushort, c_ushort, c_ushort])
        self._sig(dll.GetSlavePointer_SDO_WithODList, c_void_p,
                  [c_ushort, c_ushort, c_ushort, c_void_p])

        # ---- SDO 批量读取 ----
        self._sig(dll.GetMultiSlaveSDOList, c_int,
                  [c_ushort, POINTER(c_ushort), c_int, POINTER(c_void_p)])
        self._sig(dll.FreeMultiSlaveSDOList, None, [POINTER(c_void_p), c_int])

        # SDOwrite 使用 IntPtr 版本
        try:
            self._sig(dll.SDOwrite, c_bool,
                      [c_ushort, c_ushort, c_ushort, c_ubyte, c_bool, c_void_p, c_int])
        except AttributeError:
            pass

        self._sig(dll.SDOread, c_void_p,
                  [c_ushort, c_ushort, c_ushort, c_ubyte, c_bool, POINTER(c_int)])

        # ---- 回调注册 ----
        self._sig(dll.RegisterProcessDataCyclicCallbackSync, None, [ProcessDataCyclicCallbackType])
        self._sig(dll.RegisterProcessDataCyclicCallbackAsync, None, [ProcessDataCyclicCallbackType])
        self._sig(dll.RegisterSlaveStateChangeCallbackSync, None, [SlaveStateChangeCallbackType])
        self._sig(dll.RegisterSlaveStateChangeCallbackAsync, None, [SlaveStateChangeCallbackType])
        self._sig(dll.RegisterEmergencyEventCallback, None, [EmergencyEventCallbackType])
        self._sig(dll.RegisterSlaveDiscoveryCallbackSync, None, [SlaveDiscoveryCallbackType])
        self._sig(dll.RegisterSlaveDiscoveryCallbackAsync, None, [SlaveDiscoveryCallbackType])
        self._sig(dll.RegisterRedundancyModeChangedCallback, None, [RedundancyModeChangedCallbackType])
        self._sig(dll.RegisterInputDataChangedCallback, None, [InputDataChangedCallbackType])
        self._sig(dll.RegisterPDOFrameLossCallback, None, [PDOFrameLossCallbackType])
        self._sig(dll.RegisterSlavePreOpReconfigCallback, None, [SlavePreOpReconfigCallbackType])
        # v2 热插拔: 从站身份不符回调 + 用户确认替换
        try:
            self._sig(dll.RegisterSlaveIdentityMismatchCallback, None, [SlaveIdentityMismatchCallbackType])
            self._sig(dll.AcknowledgeSlaveReplacement, c_bool, [c_ushort, c_ushort])
        except AttributeError:
            pass
        # 端口链路变化回调 (断线/恢复事件)
        try:
            self._sig(dll.RegisterSlavePortLinkChangedCallback, None, [SlavePortLinkChangedCallbackType])
        except AttributeError:
            pass
        # DL Port 端口控制 (故障注入 / 冗余诊断)
        try:
            self._sig(dll.WriteSlaveDLPORT, c_bool, [c_ushort, c_ushort, c_ubyte])
            self._sig(dll.ReadSlaveDLPORT, c_bool, [c_ushort, c_ushort, POINTER(c_ubyte)])
        except AttributeError:
            pass

        # ---- FoE ----
        self._sig(dll.FOERead, c_bool,
                  [c_ushort, c_ushort, c_char_p, c_uint, POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.FOEWrite, c_bool,
                  [c_ushort, c_ushort, c_char_p, c_uint, c_void_p, c_int, c_int])
        self._sig(dll.FOESetProgressHook, c_bool, [c_ushort, FoEProgressCallbackType])
        self._sig(dll.FOEClearProgressHook, c_bool, [c_ushort])
        # FoE 扩展 (带选项)
        self._sig(dll.FOEReadEx, c_bool,
                  [c_ushort, c_ushort, c_char_p, c_uint,
                   POINTER(c_void_p), POINTER(c_int), c_int, POINTER(FoEOptions)])
        self._sig(dll.FOEWriteEx, c_bool,
                  [c_ushort, c_ushort, c_char_p, c_uint,
                   c_void_p, c_int, c_int, POINTER(FoEOptions)])

        # ---- SoE ----
        self._sig(dll.SoERead, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ubyte, c_ushort,
                   POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.SoEWrite, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ubyte, c_ushort, c_void_p, c_int, c_int])
        self._sig(dll.SoEReadAttributes, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ushort, POINTER(c_uint), c_int])
        self._sig(dll.SoEReadName, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ushort, POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.SoEReadUnit, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ushort, POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.SoEReadIDNList, c_bool,
                  [c_ushort, c_ushort, c_ubyte, POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.SoEReadMinMax, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ushort,
                   POINTER(c_void_p), POINTER(c_int), POINTER(c_void_p), POINTER(c_int), c_int])

        # ---- EoE ----
        self._sig(dll.EOESetIP, c_bool, [c_ushort, c_ushort, c_ubyte, c_uint, c_uint, c_uint, c_int])
        self._sig(dll.EOEGetIP, c_bool,
                  [c_ushort, c_ushort, c_ubyte, POINTER(c_uint), POINTER(c_uint), POINTER(c_uint), c_int])
        self._sig(dll.EOESendFrame, c_bool, [c_ushort, c_ushort, c_ubyte, c_void_p, c_int, c_int])
        self._sig(dll.EOEReceiveFrame, c_bool,
                  [c_ushort, c_ushort, c_ubyte, POINTER(c_void_p), POINTER(c_int), c_int])
        # EoE MAC 地址
        self._sig(dll.EOESetMAC, c_bool, [c_ushort, c_ushort, c_ubyte, c_void_p, c_int])
        self._sig(dll.EOEGetMAC, c_bool, [c_ushort, c_ushort, c_ubyte, c_void_p, c_int])
        # EoE DNS
        self._sig(dll.EOESetDNS, c_bool, [c_ushort, c_ushort, c_ubyte, c_uint, c_char_p, c_int])
        self._sig(dll.EOEGetDNS, c_bool, [c_ushort, c_ushort, c_ubyte, POINTER(c_uint), c_char_p, c_int])
        # EoE 完整参数
        self._sig(dll.EOEGetFullParam, c_bool,
                  [c_ushort, c_ushort, c_ubyte,
                   POINTER(c_uint), POINTER(c_uint), POINTER(c_uint),
                   c_void_p, POINTER(c_uint), c_char_p, c_int])
        self._sig(dll.EOESetFullParam, c_bool,
                  [c_ushort, c_ushort, c_ubyte,
                   c_uint, c_uint, c_uint,
                   c_void_p, c_uint, c_char_p, c_int])
        # EoE 地址过滤
        self._sig(dll.EOESetAddressFilter, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ubyte, c_void_p, c_int])
        self._sig(dll.EOEGetAddressFilter, c_bool,
                  [c_ushort, c_ushort, c_ubyte, POINTER(c_ubyte), c_void_p, c_int, c_int])

        # ---- AoE ----
        self._sig(dll.AOESendCommand, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_ushort, c_void_p, c_uint,
                   POINTER(c_void_p), POINTER(c_uint), c_int])
        self._sig(dll.AOEReadWrite, c_bool,
                  [c_ushort, c_ushort, c_uint, c_uint, c_uint, c_uint, c_void_p,
                   POINTER(c_void_p), POINTER(c_uint), c_int])
        self._sig(dll.AOEReadDeviceInfo, c_bool,
                  [c_ushort, c_ushort, POINTER(c_ubyte), POINTER(c_ubyte),
                   POINTER(c_ushort), c_void_p, c_int, c_int])
        self._sig(dll.AOEReadState, c_bool,
                  [c_ushort, c_ushort, POINTER(c_ushort), POINTER(c_ushort), c_int])
        self._sig(dll.AOEWriteControl, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_ushort, c_void_p, c_int, c_int])
        # AoE 高级功能
        self._sig(dll.AOEAddNotification, c_bool,
                  [c_ushort, c_ushort, c_uint, c_uint, c_uint,
                   c_uint, c_uint, c_uint, POINTER(c_uint), c_int])
        self._sig(dll.AOEDelNotification, c_bool, [c_ushort, c_ushort, c_uint, c_int])
        self._sig(dll.AOESetConfig, c_bool,
                  [c_ushort, c_ushort, c_void_p, c_ushort, c_void_p, c_ushort])
        self._sig(dll.AOEGetConfig, c_bool,
                  [c_ushort, c_ushort, c_void_p, POINTER(c_ushort), c_void_p, POINTER(c_ushort)])
        # AoE 通知监听
        self._sig(dll.AOEStartNotificationListener, c_bool, [c_ushort])
        self._sig(dll.AOEStopNotificationListener, c_bool, [])
        self._sig(dll.AOEIsNotificationListening, c_bool, [])
        self._sig(dll.AOERegisterNotification, c_int,
                  [c_ushort, c_uint, c_uint, c_uint, c_uint, c_void_p, c_void_p])
        self._sig(dll.AOEUnregisterNotification, c_bool, [c_int])

        # ---- VoE ----
        self._sig(dll.VOESend, c_bool,
                  [c_ushort, c_ushort, c_uint, c_ushort, c_void_p, c_int, c_int])
        self._sig(dll.VOEReceive, c_bool,
                  [c_ushort, c_ushort, POINTER(c_uint), POINTER(c_ushort),
                   POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.VOEIsSupported, c_bool, [c_ushort, c_ushort])
        # VoE 原始帧收发
        self._sig(dll.VOESendRaw, c_bool, [c_ushort, c_ushort, c_void_p, c_int, c_int])
        self._sig(dll.VOEReceiveRaw, c_bool,
                  [c_ushort, c_ushort, POINTER(c_void_p), POINTER(c_int), c_int])

        # ---- PDO 直接读写 ----
        self._sig(dll.PDOReadDirect, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint, POINTER(c_uint)])
        self._sig(dll.PDOWriteDirect, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint])

        # ---- PDO 批量读写 ----
        self._sig(dll.PDOBatchRead, c_uint,
                  [c_ushort, POINTER(c_ushort), c_uint,
                   POINTER(c_void_p), POINTER(c_uint), POINTER(c_uint)])
        self._sig(dll.PDOBatchWrite, c_uint,
                  [c_ushort, POINTER(c_ushort), c_uint,
                   POINTER(c_void_p), POINTER(c_uint)])

        # ---- PDO 监控 ----
        self._sig(dll.GetPDOStats, c_void_p, [c_ushort, c_ushort])
        self._sig(dll.ResetPDOStats, None, [c_ushort, c_ushort])
        self._sig(dll.EnablePDOMonitoring, None, [c_bool])
        self._sig(dll.IsPDOMonitoringEnabled, c_bool, [])
        self._sig(dll.GetPDOAvgCycleTimeNs, c_uint64, [c_ushort])
        self._sig(dll.GetPDOErrorCount, c_uint, [c_ushort])
        self._sig(dll.IsPDOValid, c_int, [c_ushort])
        self._sig(dll.IsPDOChanged, c_int, [c_ushort])
        self._sig(dll.GetPDOExpectedSize, c_uint, [c_ushort])

        # ---- PDO 映射 ----
        self._sig(dll.GetPDOMapping, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint, POINTER(c_uint)])

        # ---- 定时器精度验证 ----
        self._sig(dll.osal_validate_timer_accuracy, c_int, [c_uint32, c_uint32])

        # ---- 批量身份验证 ----
        self._sig(dll.VerifyAllSlaveIdentities, c_bool,
                  [c_ushort, POINTER(SlaveIdentity), c_uint, c_bool, c_bool, POINTER(c_uint64)])

        # ---- 组管理 ----
        self._sig(dll.SetSlaveGroup, c_bool, [c_ushort, c_ushort, c_ubyte])
        self._sig(dll.GetSlaveGroup, c_ubyte, [c_ushort, c_ushort])
        self._sig(dll.SetGroupCycleDivider, c_bool, [c_ushort, c_ubyte, c_ubyte])
        self._sig(dll.GetGroupCycleDivider, c_ubyte, [c_ushort, c_ubyte])
        self._sig(dll.SetGroupEnabled, c_bool, [c_ushort, c_ubyte, c_bool])
        self._sig(dll.GetGroupEnabled, c_bool, [c_ushort, c_ubyte])
        self._sig(dll.GetGroupExpectedWKC, c_ushort, [c_ushort, c_ubyte])
        self._sig(dll.GetActiveGroupCount, c_ubyte, [c_ushort])
        self._sig(dll.GetGroupSlaveCount, c_ushort, [c_ushort, c_ubyte])

        # ---- 启动参数管线 ----
        self._sig(dll.AddStartupParameter, c_int, [c_ushort, c_ushort, POINTER(StartupParam)])
        self._sig(dll.AddStartupParameterBatch, c_int, [c_ushort, c_ushort, POINTER(StartupParam), c_int])
        self._sig(dll.ClearStartupParameters, c_int, [c_ushort, c_ushort])
        self._sig(dll.GetStartupParameterCount, c_int, [c_ushort, c_ushort])
        self._sig(dll.ApplyStartupParameters, c_int, [c_ushort, c_ushort, c_ubyte, c_ubyte])
        self._sig(dll.ApplyStartupParametersAll, c_int, [c_ushort, c_ubyte, c_ubyte])
        # Default PDO 自动发现 (协议下沉, 见 native default_pdo.c, 2026-05-02)
        # int EnumerateDefaultPdo(uint16 master, uint16 slave, int direction,
        #                         uint16* out_indices, int max_count)
        # direction: 0=RxPDO, 1=TxPDO; 返回写入数, -1=失败
        self._sig(dll.EnumerateDefaultPdo, c_int,
                  [c_ushort, c_ushort, c_int, POINTER(c_ushort), c_int])

        # DC SyncManager 同步类型配置 (协议下沉, 见 native dc_sync_mode.c, 2026-05-02)
        # SDK 公开层不再 SDOWrite 0x1C32/0x1C33; 由 native 处理 ETG.1020 §23.1.2 协议细节.
        # sync_type 编码: 0=FreeRun, 1=SmSynchron, 2=DcSynchron, 3=DcSynchron01
        try:
            self._sig(dll.SetDcSyncMode, c_bool,
                      [c_ushort, c_ushort, c_ubyte])
        except AttributeError:
            pass
        try:
            self._sig(dll.GetDcSyncMode, c_ubyte,
                      [c_ushort, c_ushort])
        except AttributeError:
            pass

        # ---- 看门狗 ----
        self._sig(dll.SetSlaveWatchdog, c_bool, [c_ushort, c_ushort, c_uint])
        self._sig(dll.SetSlavePdiWatchdog, c_bool, [c_ushort, c_ushort, c_uint])
        self._sig(dll.GetSlaveWatchdogConfig, c_bool, [c_ushort, c_ushort, POINTER(WatchdogConfig)])
        self._sig(dll.GetSlaveWatchdogStatus, c_bool, [c_ushort, c_ushort, POINTER(WatchdogStatus)])
        self._sig(dll.SetAllSlaveWatchdog, c_int, [c_ushort, c_uint])
        self._sig(dll.SetAllSlavePdiWatchdog, c_int, [c_ushort, c_uint])

        # ---- 配置验证 ----
        self._sig(dll.GetSlaveIdentity, c_bool, [c_ushort, c_ushort, POINTER(SlaveIdentity)])
        self._sig(dll.VerifySlaveIdentity, c_bool,
                  [c_ushort, c_ushort, POINTER(SlaveIdentity), c_bool, c_bool])

        # ---- 寄存器读写 ----
        self._sig(dll.WriteSlaveRegister, c_bool, [c_ushort, c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.ReadSlaveRegister, c_bool, [c_ushort, c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.ConfigureSyncManager, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ushort, c_ushort, c_ubyte, c_bool])
        # FMMU 配置
        self._sig(dll.ConfigureFMMU, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_uint, c_ushort,
                   c_ubyte, c_ubyte, c_ushort, c_ubyte, c_ubyte, c_bool])

        # ---- SM/FMMU ----
        self._sig(dll.EnableOutputSyncManager, c_bool, [c_ushort, c_ushort])
        self._sig(dll.DisableOutputSyncManager, c_bool, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveOpOnlyFlag, c_bool, [c_ushort, c_ushort])
        self._sig(dll.SetSlaveErrorAck, c_bool, [c_ushort, c_ushort, c_bool])
        self._sig(dll.GetSlaveDeviceEmulationFlag, c_bool, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveEsmTimeouts, c_bool, [c_ushort, c_ushort, POINTER(SlaveEsmTimeouts)])
        self._sig(dll.SetSlaveEsmTimeouts, c_bool, [c_ushort, c_ushort, POINTER(SlaveEsmTimeouts)])

        # ---- 可选从站 ----
        self._sig(dll.SetSlaveOptional, c_bool, [c_ushort, c_ushort, c_bool])
        self._sig(dll.GetSlaveOptional, c_bool, [c_ushort, c_ushort])

        # ---- 帧重发支持 ----
        self._sig(dll.SetSlaveSupportsFrameRepeat, c_bool, [c_ushort, c_ushort, c_bool])
        self._sig(dll.GetSlaveSupportsFrameRepeat, c_bool, [c_ushort, c_ushort])

        # ---- 高级一步初始化 ----
        self._sig(dll.LoadConfigJson, c_int, [c_ushort, c_char_p])
        self._sig(dll.AutoConfigureSM, c_int, [c_ushort, c_ushort])
        self._sig(dll.EcInit, c_ushort, [c_char_p])
        self._sig(dll.EcInitFromFile, c_ushort, [c_char_p])
        self._sig(dll.EcClose, None, [c_ushort])
        self._sig(dll.DarraCoreInvoke, c_int, [c_ushort, c_uint, c_uint, c_uint, c_uint])
        self._sig(dll.DarraCoreInvokeText, c_int, [c_ushort, c_uint, c_char_p, c_uint, c_uint, c_uint])

        # ---- 主站诊断 ----
        self._sig(dll.GetMasterIdentity, c_bool, [c_ushort, POINTER(MasterIdentity)])
        self._sig(dll.GetMasterDiagData, c_bool, [c_ushort, POINTER(MasterDiagData)])

        # 获取详细诊断数据 (内部指针, 无需释放)
        self._sig(dll.GetDetailedDiagnostics, c_void_p, [c_ushort])
        # 诊断开关
        self._sig(dll.SetDiagnosticsEnabled, None, [c_ushort, c_bool])
        self._sig(dll.GetDiagnosticsEnabled, c_bool, [c_ushort])
        # 获取诊断数据指针
        self._sig(dll.GetDiagnosticsPointer, c_void_p, [c_ushort])
        # 重置诊断
        self._sig(dll.ResetDiagnostics, None, [c_ushort])
        # 获取摘要数据指针
        self._sig(dll.GetSummaryPointer, c_void_p, [c_ushort])

        # 诊断数据采集
        self._sig(dll.GetExpectedWKC, c_uint16, [c_uint16])
        self._sig(dll.SetExpectedWKC, None, [c_uint16, c_uint16])
        # [2026-04-27] 唯一丢包率/过慢率源 (内核 5s 滑窗)
        self._sig(dll.GetPacketLossRate, c_float, [c_uint16])
        self._sig(dll.GetLateFrameRate, c_float, [c_uint16])
        self._sig(dll.GetSlaveLinkQuality, c_int16, [c_uint16, c_uint16])
        self._sig(dll.RecordCycleTime, None, [c_uint16, c_uint32])
        self._sig(dll.RecordPDOCycleStart, None, [c_uint16])
        self._sig(dll.RecordWKC, None, [c_uint16, c_uint16])
        self._sig(dll.UpdateDiagnosticsSnapshot, None, [c_uint16])
        self._sig(dll.ResetSlavePortErrorCounters, c_bool, [c_uint16, c_uint16])

        # ---- 冗余与故障 ----
        self._sig(dll.GetRingMode, c_int, [c_ushort])
        self._sig(dll.GetSecondaryLinkStatus, c_bool, [c_ushort])
        self._sig(dll.GetBreakPoints, c_int,
                  [c_ushort, POINTER(c_ushort), POINTER(c_ubyte), POINTER(c_ubyte), c_ushort])
        self._sig(dll.GetPrimaryWKC, c_ushort, [])
        self._sig(dll.GetSecondaryWKC, c_ushort, [])

        # ---- UDP ----
        self._sig(dll.SetUdpMode, c_bool, [c_ushort, c_bool])
        self._sig(dll.GetUdpMode, c_bool, [c_ushort])
        self._sig(dll.IsUdpAvailable, c_bool, [c_ushort])

        # ---- 实时优化 ----
        self._sig(dll.ApplyRealtimeOptimizations, c_bool, [])
        self._sig(dll.RemoveRealtimeOptimizations, c_bool, [])
        self._sig(dll.GetRealtimeOptimizationsStatus, c_bool, [])
        self._sig(dll.GetTimingMode, c_uint, [c_ushort])

        # ---- WDK 实时驱动 ----
        self._sig(dll.IsWdkAvailable, c_bool, [c_ushort])
        self._sig(dll.SetWdkMode, c_bool, [c_ushort, c_bool])
        self._sig(dll.GetWdkMode, c_bool, [c_ushort])
        self._sig(dll.StartWdkRT, c_bool, [c_ushort, c_uint, c_uint])
        self._sig(dll.StopWdkRT, c_bool, [c_ushort])

        # ---- DC 高级 ----
        self._sig(dll.SetDCAutoShiftEnabled, None, [c_ushort, c_bool])
        self._sig(dll.GetDCAutoShiftEnabled, c_bool, [c_ushort])
        self._sig(dll.SetMasterDCCycleTime, None, [c_ushort, c_uint])

        # ---- 冗余高级 ----
        self._sig(dll.EnableRedundancy, c_bool, [c_ushort, c_bool])
        self._sig(dll.GetRedundancyStatus, c_void_p, [c_ushort])
        self._sig(dll.ForceRedundancyFailover, c_bool, [c_ushort])
        self._sig(dll.CheckRedundancyHealth, c_bool, [c_ushort])

        # ---- 从站状态查询 ----
        self._sig(dll.GetSlaveState, c_ubyte, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveALStatusCode, c_ushort, [c_ushort, c_ushort])

        # ---- 从站 IO 信息查询 (slave_index=0 获取主站汇总) ----
        self._sig(dll.GetSlaveOutputBits, c_ushort, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveOutputBytes, c_uint, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveInputBits, c_ushort, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveInputBytes, c_uint, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveHasDC, c_bool, [c_ushort, c_ushort])

        # ---- 邮箱协议能力 (ETG.1000.6 SII mbx_proto bitfield) ----
        # bit 0=AoE, bit 1=EoE, bit 2=CoE, bit 3=FoE, bit 4=SoE, bit 5=VoE
        # 用于各协议 is_supported 属性检测从站邮箱能力.
        try:
            self._sig(dll.GetSlaveMailboxProto, c_ushort, [c_ushort, c_ushort])
        except AttributeError:
            pass

        # ---- 邮箱协议统计 (对齐 C# IMailboxProtocol.Statistics / ResetStatistics) ----
        # 按 (master_index, slave_index, protocol_type) 查询 / 重置各协议统计.
        # protocol_type 取 ECT_MBXT_* 位: CoE=3, FoE=4, SoE=5, AoE=1, EoE=2, VoE=0x0F, FSoE=8.
        # DLL 未导出时静默降级 (各协议类 statistics 会返回 empty, reset 无操作).
        try:
            self._sig(dll.ecx_mbx_get_stats_by_master, c_int,
                      [c_uint16, c_uint16, ctypes.c_uint8, POINTER(EcMbxStatsT)])
        except AttributeError:
            pass
        try:
            self._sig(dll.ecx_mbx_reset_stats_by_master, None,
                      [c_uint16, c_uint16, ctypes.c_uint8])
        except AttributeError:
            pass

        # ---- ESI / MDP / 厂商信息 ----
        self._sig(dll.GetSlaveHasEsi, c_int, [c_ushort, c_ushort])
        self._sig(dll.SetSlaveEsiFile, c_int, [c_ushort, c_ushort, c_char_p])
        self._sig(dll.GetSlaveEsiVersion, c_int, [c_ushort, c_ushort, c_void_p, c_int])
        self._sig(dll.GetSlaveHasMDP, c_int, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveVendorName, c_int, [c_ushort, c_ushort, c_void_p, c_int])

        # ---- 从站冗余状态 ----
        self._sig(dll.GetSlaveRedundancyActivated, c_int, [c_ushort, c_ushort])
        self._sig(dll.GetSlavePrimaryLinkBroken, c_int, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveSecondaryLinkBroken, c_int, [c_ushort, c_ushort])

        # ---- 无锁输出写入 ----
        self._sig(dll.WriteSlaveOutput, None, [c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.WriteSlaveOutputByte, None, [c_ushort, c_ushort, c_uint, c_ubyte])

        # ---- Mutex 保护 ----
        self._sig(dll.SetMutexProtection, None, [c_ushort, c_bool])
        self._sig(dll.GetMutexProtection, c_bool, [c_ushort])

        # ---- 网络扫描详细 ----
        self._sig(dll.ReadSlaveInfo, c_int, [c_char_p])
        self._sig(dll.GetScannedSlaveCount, c_int, [])
        self._sig(dll.GetScannedSlaveInfo, c_bool,
                  [c_int, POINTER(c_uint), POINTER(c_uint), POINTER(c_uint), POINTER(c_uint),
                   c_void_p, c_int, POINTER(c_ushort), POINTER(c_ushort),
                   POINTER(c_ushort), POINTER(c_ubyte), POINTER(c_ubyte),
                   POINTER(c_ubyte), POINTER(c_ubyte), POINTER(c_ubyte)])

        # ---- PDO 丢帧 ----
        self._sig(dll.GetPDOFrameLossStats, None,
                  [c_ushort, c_ubyte, POINTER(c_uint), POINTER(c_uint), POINTER(c_uint)])
        self._sig(dll.ResetPDOFrameLossStats, None, [c_ushort, c_ubyte])

        # ---- 热插拔 ----
        self._sig(dll.GetSlaveNeedsStartupReconfig, c_bool, [c_ushort, c_ushort])
        self._sig(dll.ClearSlaveNeedsStartupReconfig, None, [c_ushort, c_ushort])

        # ---- CiA 402 驱动协议 ----
        self._sig(dll.CiA402_ParseState, c_int, [c_ushort])
        self._sig(dll.CiA402_GetEnableCommand, c_ushort, [c_ushort])
        self._sig(dll.CiA402_SetMode, c_bool, [c_ushort, c_ushort, c_byte])
        self._sig(dll.CiA402_GetMode, c_byte, [c_ushort, c_ushort])
        self._sig(dll.CiA402_ReadStatusWord, c_ushort, [c_ushort, c_ushort])
        self._sig(dll.CiA402_WriteControlWord, c_bool, [c_ushort, c_ushort, c_ushort])
        self._sig(dll.CiA402_Enable, c_bool, [c_ushort, c_ushort, c_int])
        self._sig(dll.CiA402_FaultReset, c_bool, [c_ushort, c_ushort])

        # ---- EMCY 紧急消息历史 ----
        self._sig(dll.EmcyGetHistory, c_int, [c_ushort, c_ushort, POINTER(EmcyRecord), c_int])
        self._sig(dll.EmcyClearHistory, None, [c_ushort, c_ushort])
        self._sig(dll.EmcyGetCount, c_int, [c_ushort, c_ushort])

        # ---- CoE Diagnosis History 0x10F3 (ETG.1020 §16.2) ----
        # 4 个 DLL 导出函数, 对应 C# DLL.CoeDiag* P/Invoke.
        # DLL 未导出时静默降级 (协议类方法返回 False / None / 空字节).
        try:
            self._sig(dll.coe_diag_poll_new_available, c_int,
                      [c_ushort, c_ushort, POINTER(c_uint)])
        except AttributeError:
            pass
        try:
            self._sig(dll.coe_diag_read_meta, c_int,
                      [c_ushort, c_ushort,
                       POINTER(c_ubyte), POINTER(c_ubyte),
                       POINTER(c_ubyte), POINTER(c_ushort),
                       POINTER(c_uint)])
        except AttributeError:
            pass
        try:
            self._sig(dll.coe_diag_read_message, c_int,
                      [c_ushort, c_ushort, c_ubyte,
                       ctypes.POINTER(c_ubyte), c_int,
                       POINTER(c_int), POINTER(c_uint)])
        except AttributeError:
            pass
        try:
            self._sig(dll.coe_diag_acknowledge, c_int,
                      [c_ushort, c_ushort, c_ubyte, POINTER(c_uint)])
        except AttributeError:
            pass

        # ---- FSoE ConnID 校验 (ETG.5120 §5.2.3) ----
        # 对应 C# DLL.FSoEValidateConnId. 薄封装, 无状态, 返回 bool.
        try:
            self._sig(dll.FSoEValidateConnId, c_bool, [c_ushort])
        except AttributeError:
            pass

        # ---- DC 时间查询 (2026-04-24) ----
        # 对应 C# DLL.GetMasterDCTime / DLL.GetReferenceClockSlaveIndex.
        try:
            self._sig(dll.GetMasterDCTime, c_uint64, [c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.GetReferenceClockSlaveIndex, c_ushort, [c_ushort])
        except AttributeError:
            pass

        # ---- SoE Notification / Emergency 回调 (ETG.1020 OpCode=5/6) ----
        # 对应 C# DLL.RegisterSoENotificationCallback / RegisterSoEEmergencyCallback.
        try:
            self._sig(dll.RegisterSoENotificationCallback, None,
                      [SoENotificationCallbackType])
        except AttributeError:
            pass
        try:
            self._sig(dll.RegisterSoEEmergencyCallback, None,
                      [SoEEmergencyCallbackType])
        except AttributeError:
            pass

        # ---- FoE Cancel / BusyHook ----
        # 对应 C# DLL.FOERequestCancel / FOEClearCancel / FOESetBusyHook.
        try:
            self._sig(dll.FOERequestCancel, c_bool, [c_ushort, c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.FOEClearCancel, c_bool, [c_ushort, c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.FOESetBusyHook, c_bool, [c_ushort, FoEBusyCallbackType])
        except AttributeError:
            pass

        # ---- Hot-Connect (ETG.1020 §8) ----
        # 对应 C# DLL.HotConnectAddGroup / RemoveGroup / GetGroupStatus /
        # Enumerate / ClearAll / GetGroupCount. C 端在 hotconnect.h 中导出.
        # DLL 未导出时静默降级 (HotConnect 类方法返回 False / 空 / UNKNOWN).
        try:
            self._sig(dll.HotConnectAddGroup, c_int,
                      [c_ushort, c_ushort, c_ushort, c_uint, c_uint])
        except AttributeError:
            pass
        try:
            self._sig(dll.HotConnectRemoveGroup, c_int, [c_ushort, c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.HotConnectGetGroupStatus, c_int, [c_ushort, c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.HotConnectEnumerate, c_int,
                      [c_ushort, POINTER(HotConnectGroupNative), c_int])
        except AttributeError:
            pass
        try:
            self._sig(dll.HotConnectClearAll, None, [c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.HotConnectGetGroupCount, c_int, [c_ushort])
        except AttributeError:
            pass

        # ---- EoE 扩展 (TIME_APPEND 时间戳 + 异步接收 Hook) ----
        # 对应 C# DLL.EOESendFrameEx / EOESetReceiveHook / EOEClearReceiveHook.
        try:
            self._sig(dll.EOESendFrameEx, c_bool,
                      [c_ushort, c_ushort, c_ubyte, c_void_p, c_int,
                       c_ubyte, c_uint, c_int])
        except AttributeError:
            pass
        try:
            self._sig(dll.EOESetReceiveHook, c_bool,
                      [c_ushort, EOEFrameCallbackType])
        except AttributeError:
            pass
        try:
            self._sig(dll.EOEClearReceiveHook, c_bool, [c_ushort])
        except AttributeError:
            pass

        # ---- VoE 异步通知 (Vendor-initiated, 对应 C# VoE NotificationReceived) ----
        # DLL.VoE.cs 暴露 VOEStartNotificationListener / VOEStopNotificationListener /
        # VOEIsNotificationListening / VOERegisterNotification / VOEUnregisterNotification.
        try:
            self._sig(dll.VOEStartNotificationListener, c_bool, [c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.VOEStopNotificationListener, c_bool, [])
        except AttributeError:
            pass
        try:
            self._sig(dll.VOEIsNotificationListening, c_bool, [])
        except AttributeError:
            pass
        try:
            self._sig(dll.VOERegisterNotification, c_int,
                      [c_ushort, c_uint, c_ushort,
                       VoENotificationCallbackType, c_void_p])
        except AttributeError:
            pass
        try:
            self._sig(dll.VOEUnregisterNotification, c_bool, [c_int])
        except AttributeError:
            pass

        # 注: SDO Block Transfer 绑定已按 ETG.1000.6 §5.6.2 audit 结论删除
        # (标准只定义 Expedited + Normal). Segmented Transfer 覆盖所有 >4 B 场景.

        # ---- PDO 类型化读写 ----
        self._sig(dll.PDOReadInputU8, c_ubyte, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOReadInputI16, c_short, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOReadInputU16, c_ushort, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOReadInputI32, c_int, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOReadInputU32, c_uint, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOReadInputF32, c_float, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOWriteOutputU8, c_bool, [c_ushort, c_ushort, c_uint32, c_ubyte])
        self._sig(dll.PDOWriteOutputI16, c_bool, [c_ushort, c_ushort, c_uint32, c_short])
        self._sig(dll.PDOWriteOutputU16, c_bool, [c_ushort, c_ushort, c_uint32, c_ushort])
        self._sig(dll.PDOWriteOutputI32, c_bool, [c_ushort, c_ushort, c_uint32, c_int])
        self._sig(dll.PDOWriteOutputU32, c_bool, [c_ushort, c_ushort, c_uint32, c_uint])
        self._sig(dll.PDOWriteOutputF32, c_bool, [c_ushort, c_ushort, c_uint32, c_float])

        # ---- PDO 类型化读写 (旧接口, 兼容) ----
        self._sig(dll.PdoWriteInt8, None, [c_ushort, c_ushort, c_uint, c_byte])
        self._sig(dll.PdoWriteInt16, None, [c_ushort, c_ushort, c_uint, c_short])
        self._sig(dll.PdoWriteInt32, None, [c_ushort, c_ushort, c_uint, c_int])
        self._sig(dll.PdoWriteUint8, None, [c_ushort, c_ushort, c_uint, c_ubyte])
        self._sig(dll.PdoWriteUint16, None, [c_ushort, c_ushort, c_uint, c_ushort])
        self._sig(dll.PdoWriteUint32, None, [c_ushort, c_ushort, c_uint, c_uint])
        self._sig(dll.PdoReadInt8, c_byte, [c_ushort, c_ushort, c_uint])
        self._sig(dll.PdoReadInt16, c_short, [c_ushort, c_ushort, c_uint])
        self._sig(dll.PdoReadInt32, c_int, [c_ushort, c_ushort, c_uint])
        self._sig(dll.PdoReadUint8, c_ubyte, [c_ushort, c_ushort, c_uint])
        self._sig(dll.PdoReadUint16, c_ushort, [c_ushort, c_ushort, c_uint])
        self._sig(dll.PdoReadUint32, c_uint, [c_ushort, c_ushort, c_uint])

        # ---- 网络拓扑 ----
        self._sig(dll.TopologyBuild, c_int, [c_ushort, POINTER(TopologyNode), c_int])
        self._sig(dll.TopologyGetChildren, c_int, [c_ushort, c_ushort, POINTER(c_ushort), c_int])
        self._sig(dll.TopologyGetRoots, c_int, [c_ushort, POINTER(c_ushort), c_int])
        # 获取拓扑信息
        self._sig(dll.GetTopology, c_int, [c_ushort, c_void_p, c_int])
        # 获取从站活动端口
        self._sig(dll.GetSlaveActivePorts, c_ubyte, [c_ushort, c_ushort])
        # 获取从站父节点索引
        self._sig(dll.GetSlaveParent, c_ushort, [c_ushort, c_ushort])

        # ---- ESC 端口错误诊断 (ETG.1000.4) ----
        self._sig(dll.ReadSlavePortErrorCounters, c_bool,
                  [c_ushort, c_ushort, POINTER(c_ubyte), POINTER(c_ubyte), POINTER(c_ubyte)])
        self._sig(dll.ReadAllSlavePortErrorCounters, c_int, [c_ushort])
        self._sig(dll.GetSlavePortErrorStats, c_void_p, [c_ushort, c_ushort])
        self._sig(dll.UpdateDiagnosticsWithESCErrors, None, [c_ushort])

        # ---- PDO 线程 CPU 亲和性 ----
        self._sig(dll.SetPDOThreadCpuAffinity, c_bool, [c_ushort, c_int])
        self._sig(dll.GetPDOThreadCpuAffinity, c_int, [c_ushort])

        # ---- 冗余批量查找 ----
        self._sig(dll.QuickFindRedundantPairBatch, c_int,
                  [POINTER(c_char_p), c_int, POINTER(c_int), POINTER(c_int),
                   POINTER(c_int), POINTER(c_int)])

        # ---- 调试辅助 ----
        self._sig(dll.DebugSlaveHasDC, None, [c_ushort, c_ushort])

        # ---- 配置验证 (ETG.1500 5.5.2) ----
        self._sig(dll.ec_validate_config, c_int, [c_uint16])

        # ---- 性能统计导出 CSV ----
        self._sig(dll.ec_perf_export_csv, c_int, [c_uint16, c_char_p])

        # ---- FSoE 功能安全 (ETG.5100/5120) ----
        # FSoE 单连接 (16个函数)
        self._sig(dll.FSoEInitConnection, c_bool,
                  [c_ushort, c_ushort, POINTER(FsoEConfig)])
        self._sig(dll.FSoECloseConnection, c_bool, [c_ushort, c_ushort])
        self._sig(dll.FSoEGetStatus, c_bool,
                  [c_ushort, c_ushort, POINTER(FsoEStatus)])
        self._sig(dll.FSoERequestState, c_bool, [c_ushort, c_ushort, c_int])
        self._sig(dll.FSoEGetState, c_int, [c_ushort, c_ushort])
        self._sig(dll.FSoEReset, c_bool, [c_ushort, c_ushort])
        self._sig(dll.FSoEWriteSafeOutput, c_bool,
                  [c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.FSoEReadSafeInput, c_bool,
                  [c_ushort, c_ushort, c_void_p, POINTER(c_uint)])
        self._sig(dll.FSoEDownloadParameters, c_bool,
                  [c_ushort, c_ushort, c_void_p, c_uint, POINTER(c_uint)])
        self._sig(dll.FSoESetFailsafeOutput, c_bool,
                  [c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.FSoECheckWatchdog, c_bool, [c_ushort, c_ushort])
        self._sig(dll.FSoEGetLastError, c_int, [c_ushort, c_ushort])
        self._sig(dll.FSoEClearError, None, [c_ushort, c_ushort])
        self._sig(dll.FSoEIsSlaveCapable, c_bool, [c_ushort, c_ushort])
        self._sig(dll.FSoEGetConnectionCount, c_ushort, [c_ushort])
        self._sig(dll.FSoEProcessCycle, None, [c_ushort])

        # FSoE MDP 多连接 (18个函数)
        self._sig(dll.FSoEMdpInitConnection, c_bool,
                  [c_ushort, c_ushort, c_ushort, POINTER(FsoEMdpConfig)])
        self._sig(dll.FSoEMdpCloseConnection, c_bool,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.FSoEMdpGetStatus, c_bool,
                  [c_ushort, c_ushort, c_ushort, POINTER(FsoEStatus)])
        self._sig(dll.FSoEMdpRequestState, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_int])
        self._sig(dll.FSoEMdpGetState, c_int,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.FSoEMdpReset, c_bool,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.FSoEMdpWriteSafeOutput, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.FSoEMdpReadSafeInput, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, POINTER(c_uint)])
        self._sig(dll.FSoEMdpDownloadParameters, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint, POINTER(c_uint)])
        self._sig(dll.FSoEMdpSetFailsafeOutput, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.FSoEMdpCheckWatchdog, c_bool,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.FSoEMdpGetLastError, c_int,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.FSoEMdpClearError, None,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.FSoEMdpGetSlaveConnectionCount, c_ushort,
                  [c_ushort, c_ushort])
        self._sig(dll.FSoEMdpDetectConnections, c_ushort,
                  [c_ushort, c_ushort])
        self._sig(dll.FSoEMdpGetDeviceAddress, c_bool,
                  [c_ushort, c_ushort, POINTER(c_ushort)])
        self._sig(dll.FSoEMdpGetModuleCommParam, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, POINTER(c_uint)])
        self._sig(dll.FSoEMdpGetModuleDiagnosis, c_bool,
                  [c_ushort, c_ushort, c_ushort, POINTER(c_ushort), POINTER(c_ushort)])

        # ===================================================================
        # 协议解码 / 错误码表 (DLL 端 protocol/ec_*.{c,h}, VMP 保护)
        # 字符串返回值统一为 c_char_p (C 端是 UTF-8), 调用方用 .decode("utf-8") 解码
        # 78 个新函数: AL_StatusCode 4 / SDOAbort 4 / EmcyCode 5 / EcState 8 /
        #   EcPdoCodec 15 / CiA402Modes 13 / EcMailbox+SoE 5 / EcSii 19 /
        #   EcCouplerId 6 / EcDiagStrings 4 = 83 个函数 (C# DLL.cs 同步)
        # ===================================================================

        # --- AL_STATUS_CODE (ec_status_codes.h) - 4 ---
        self._sig(dll.AL_StatusCode_GetDescription, c_char_p, [c_uint16])
        self._sig(dll.AL_StatusCode_GetSeverity, c_int, [c_uint16])
        self._sig(dll.AL_StatusCode_GetRecoveryHint, c_char_p, [c_uint16])
        self._sig(dll.AL_StatusCode_IsVendorSpecific, c_int, [c_uint16])

        # --- SDO Abort Code (ec_sdo_abort.h) - 4 ---
        self._sig(dll.SDOAbort_GetDescription, c_char_p, [c_uint32])
        self._sig(dll.SDOAbort_GetCategory, c_int, [c_uint32])
        self._sig(dll.SDOAbort_IsRetryable, c_int, [c_uint32])
        self._sig(dll.SDOAbort_GetHint, c_char_p, [c_uint32])

        # --- EMCY Emergency Code (ec_emcy_codes.h) - 5 ---
        self._sig(dll.EmcyCode_GetDescription, c_char_p, [c_uint16])
        self._sig(dll.EmcyCode_GetClass, c_int, [c_uint16])
        self._sig(dll.EmcyCode_GetClassName, c_char_p, [c_int])
        self._sig(dll.EmcyCode_FormatErrorRegister, None,
                  [c_ubyte, POINTER(c_ubyte), c_int])
        self._sig(dll.EmcyCode_IsRecovery, c_int, [c_uint16])

        # --- ESM 状态合法性 (ec_state_validator.h) - 8 ---
        self._sig(dll.EcState_IsValidTransition, c_int, [c_uint16, c_uint16])
        self._sig(dll.EcState_GetTransitionType, c_int, [c_uint16, c_uint16])
        self._sig(dll.EcState_GetTransitionPath, c_int,
                  [c_uint16, c_uint16, POINTER(c_uint16), c_int])
        self._sig(dll.EcState_IsBootstrapRequired, c_int, [c_uint16])
        self._sig(dll.EcState_GetName, c_char_p, [c_uint16])
        self._sig(dll.EcState_GetNameEn, c_char_p, [c_uint16])
        self._sig(dll.EcState_HasErrorAck, c_int, [c_uint16])
        self._sig(dll.EcState_StripErrorAck, c_uint16, [c_uint16])

        # --- PDO Codec / 端口拓扑 (ec_pdo_codec.h) - 15 ---
        self._sig(dll.EcPdoCodec_DataTypeBitSize, c_int, [c_int])
        self._sig(dll.EcPdoCodec_DataTypeName, c_char_p, [c_int])
        self._sig(dll.EcPdoCodec_ExtractU64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_int, POINTER(c_uint64)])
        self._sig(dll.EcPdoCodec_ExtractI64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_int, POINTER(ctypes.c_int64)])
        self._sig(dll.EcPdoCodec_InsertU64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_int, c_uint64])
        self._sig(dll.EcPdoCodec_InsertI64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_int, ctypes.c_int64])
        self._sig(dll.EcPdoCodec_ExtractReal32, c_int,
                  [POINTER(c_ubyte), c_int, c_int, POINTER(c_float)])
        self._sig(dll.EcPdoCodec_ExtractReal64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, POINTER(c_double)])
        self._sig(dll.EcPdoCodec_InsertReal32, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_float])
        self._sig(dll.EcPdoCodec_InsertReal64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_double])
        self._sig(dll.EcPdoCodec_CountActivePorts, c_int, [c_ubyte])
        self._sig(dll.EcPdoCodec_GetTopology, c_int, [c_ubyte])
        self._sig(dll.EcPdoCodec_GetTopologyName, c_char_p, [c_int])
        self._sig(dll.EcPdoCodec_GetTopologyNameEn, c_char_p, [c_int])
        self._sig(dll.EcPdoCodec_IsPortActive, c_int, [c_ubyte, c_int])

        # --- CiA402 模式 / 回零方法 (ec_cia402_modes.h) - 13 ---
        self._sig(dll.CiA402Modes_ModeToSupportedBit, c_int, [c_byte])
        self._sig(dll.CiA402Modes_IsModeSupportedInMask, c_int, [c_uint, c_byte])
        self._sig(dll.CiA402Modes_ExpandSupportedMask, c_int,
                  [c_uint, POINTER(c_byte), c_int])
        self._sig(dll.CiA402Modes_GetModeName, c_char_p, [c_byte])
        self._sig(dll.CiA402Modes_GetModeNameEn, c_char_p, [c_byte])
        self._sig(dll.CiA402Modes_GetModeDescription, c_char_p, [c_byte])
        self._sig(dll.CiA402Modes_IsCyclicSyncMode, c_int, [c_byte])
        self._sig(dll.CiA402Modes_RequiresDC, c_int, [c_byte])
        self._sig(dll.CiA402Modes_IsStandardHomingMethod, c_int, [c_byte])
        self._sig(dll.CiA402Modes_GetHomingMethodName, c_char_p, [c_byte])
        self._sig(dll.CiA402Modes_GetHomingTrigger, c_int, [c_byte])
        self._sig(dll.CiA402Modes_GetHomingDirection, c_int, [c_byte])
        self._sig(dll.CiA402Modes_ListStandardHomingMethods, c_int,
                  [POINTER(c_byte), c_int])

        # --- Mailbox 协议码 (ec_mailbox_codes.h) - 5 (含 SoE) ---
        self._sig(dll.EcMailbox_GetTypeName, c_char_p, [c_uint16])
        self._sig(dll.EcMailbox_GetTypeNameEn, c_char_p, [c_uint16])
        self._sig(dll.EcMailbox_GetErrorDescription, c_char_p, [c_uint16])
        self._sig(dll.EcMailbox_NextCounter, c_ubyte, [c_ubyte])
        self._sig(dll.EcSoE_GetErrorDescription, c_char_p, [c_uint16])

        # --- SII 解析 (ec_sii_parser.h) - 19 ---
        self._sig(dll.EcSii_FindCategory, c_int,
                  [POINTER(c_ubyte), c_int, c_uint16, POINTER(c_int)])
        self._sig(dll.EcSii_EnumerateCategories, c_int,
                  [POINTER(c_ubyte), c_int, POINTER(c_uint16), c_int])
        self._sig(dll.EcSii_GetStringByIndex, c_int,
                  [POINTER(c_ubyte), c_int, c_int, POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetStringCount, c_int,
                  [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetVendorId, c_uint, [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetProductCode, c_uint, [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetRevision, c_uint, [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetSerialNumber, c_uint, [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetConfiguredAlias, c_uint16,
                  [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_CoeEnabled, c_int, [c_ubyte])
        self._sig(dll.EcSii_CoeSdoInfo, c_int, [c_ubyte])
        self._sig(dll.EcSii_CoePdoAssign, c_int, [c_ubyte])
        self._sig(dll.EcSii_CoePdoConfig, c_int, [c_ubyte])
        self._sig(dll.EcSii_CoeUploadAtStartup, c_int, [c_ubyte])
        self._sig(dll.EcSii_CoeCompleteAccess, c_int, [c_ubyte])
        self._sig(dll.EcSii_FoeEnabled, c_int, [c_ubyte])
        self._sig(dll.EcSii_EoeEnabled, c_int, [c_ubyte])

        # --- 耦合器识别 (ec_coupler_id.h) - 6 ---
        self._sig(dll.EcCouplerId_DetectDeviceType, c_int, [c_uint, c_uint])
        self._sig(dll.EcCouplerId_IsCoupler, c_int, [c_uint, c_uint])
        self._sig(dll.EcCouplerId_IsTerminal, c_int, [c_uint, c_uint])
        self._sig(dll.EcCouplerId_GetVendorName, c_char_p, [c_uint])
        self._sig(dll.EcCouplerId_GetVendorNameEn, c_char_p, [c_uint])
        self._sig(dll.EcCouplerId_GetDeviceTypeName, c_char_p, [c_int])
        self._sig(dll.EcCouplerId_GetCouplerModel, c_char_p, [c_uint, c_uint])
        self._sig(dll.EcCouplerId_GetEntryCount, c_int, [])
        self._sig(dll.EcCouplerId_GetVendorCount, c_int, [])

        # --- ESI XML 解析 (ec_esi_parser.cpp) - 9 ---
        # DLL 内置 ESI XML 解析, 不再需要 C# 独占, 让其他语言能注册启动参数
        self._sig(dll.EcEsi_LoadFile, c_int, [c_char_p])
        self._sig(dll.EcEsi_LoadDirectory, c_int, [c_char_p])
        self._sig(dll.EcEsi_Clear, None, [])
        self._sig(dll.EcEsi_GetLoadedCount, c_int, [])
        self._sig(dll.EcEsi_BindToSlave, c_int, [c_uint16, c_uint16, c_char_p])
        self._sig(dll.EcEsi_AutoMatchAll, c_int, [c_uint16])
        self._sig(dll.EcEsi_RegisterStartupParameters, c_int, [c_uint16, c_uint16])
        self._sig(dll.EcEsi_ApplyAllSlaves, c_int, [c_uint16])
        self._sig(dll.SetSlaveEsiFile, c_int, [c_uint16, c_uint16, c_char_p])

        # --- 诊断翻译 (ec_diag_strings.h) - 4 ---
        self._sig(dll.EcDiagStrings_TopologyDescription, c_char_p, [c_ubyte])
        self._sig(dll.EcDiagStrings_TimingMode, c_char_p, [c_uint])
        self._sig(dll.EcDiagStrings_BreakpointType, c_char_p, [c_ubyte])
        self._sig(dll.EcDiagStrings_FormatBreakpoint, None,
                  [c_uint16, c_ubyte, c_ubyte, POINTER(c_ubyte), c_int])

        # --- ESI Device 字段直读 API (Step 1, D_1603-1608) - 6 ---
        # 协议下沉: SDK 不再独立解析 ESI XML, 改 native 直接拿 Device 字段.
        # 全部 by (master_index, slave_index); Slave 必须先 EcEsi_BindToSlave / AutoMatchAll.
        self._sig(dll.EcEsi_GetDevicePdoIndices, c_int,
                  [c_uint16, c_uint16, c_int, POINTER(c_uint16), c_int])
        self._sig(dll.EcEsi_GetDevicePdoSizeBits, c_int, [c_uint16, c_uint16, c_uint16])
        self._sig(dll.EcEsi_GetDeviceSmInfo, c_int,
                  [c_uint16, c_uint16, c_ubyte,
                   POINTER(c_uint16), POINTER(c_uint16), POINTER(c_ubyte)])
        self._sig(dll.EcEsi_GetDeviceDcSyncMode, c_int, [c_uint16, c_uint16])
        self._sig(dll.EcEsi_GetDeviceMailboxTimeout, c_int,
                  [c_uint16, c_uint16, POINTER(c_int), POINTER(c_int)])
        self._sig(dll.EcEsi_GetDeviceIdentity, c_int,
                  [c_uint16, c_uint16, POINTER(c_uint32), POINTER(c_uint32),
                   POINTER(c_uint32), POINTER(c_ubyte), c_int])

    def _sig(self, func_or_name, restype, argtypes):
        """设置函数签名的辅助方法 (容忍 DLL 缺失符号).

        参数 func_or_name 可以是:
          - ctypes 函数对象 (按旧用法直接设置签名)
          - 字符串 (在 DLL 中按名查找, 找不到则记录到 missing_symbols 并安装一个 stub)
        """
        if isinstance(func_or_name, str):
            try:
                func = getattr(self._dll, func_or_name)
            except AttributeError:
                # DLL 没导出该符号, 记录, 不阻塞其他绑定
                if not hasattr(self, 'missing_symbols'):
                    self.missing_symbols = set()
                self.missing_symbols.add(func_or_name)
                return None
            func.restype = restype
            func.argtypes = argtypes
            return func
        # 旧用法: 直接传入 ctypes 函数对象
        func_or_name.restype = restype
        func_or_name.argtypes = argtypes
        return func_or_name

    def __getattr__(self, name):
        """代理到底层 DLL 函数 (缺失则抛 NotImplementedError 而非 AttributeError).

        语义名 (如 'Initialize') 自动转发到真实导出 D_NNNN (如 D_1547);
        调度器名 'DarraCoreInvoke'/'DarraCoreInvokeText' 直接按名访问.
        """
        # 先访问 _dll. 注: __getattr__ 只在常规查找失败后调用, 不会进入死循环.
        try:
            dll = object.__getattribute__(self, '_dll')
        except AttributeError:
            raise AttributeError(name)
        try:
            return _resolve_export(dll, name)
        except AttributeError:
            missing = getattr(self, 'missing_symbols', set())
            if name in missing or True:
                def _stub(*_a, **_kw):
                    raise NotImplementedError(
                        f"DLL symbol '{name}' not exported by current Darra.Core.dll"
                    )
                return _stub
