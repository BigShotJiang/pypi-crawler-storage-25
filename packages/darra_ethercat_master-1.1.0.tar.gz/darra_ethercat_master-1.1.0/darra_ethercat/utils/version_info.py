# -*- coding: utf-8 -*-
"""
对应 C# 文件: Utils/VersionInfo.cs
DLL 版本信息辅助

注意: 与 statics/version_info.py 不同。
statics/version_info.py 提供面向用户的版本查询函数。
此文件提供底层 DLL 版本解析和校验功能。
"""

import ctypes
from ctypes import Structure, c_ushort
from typing import Optional


class DllVersionInfoStruct(Structure):
    """DLL 版本信息结构体"""
    _fields_ = [
        ('major', c_ushort),
        ('minor', c_ushort),
        ('patch', c_ushort),
        ('build', c_ushort),
    ]


def parse_version_string(version_str: str) -> Optional[tuple]:
    """
    解析版本字符串为元组

    参数:
        version_str: 版本字符串 (如 "1.2.3.4")

    返回:
        (major, minor, patch, build) 元组, 解析失败返回 None
    """
    try:
        parts = version_str.strip().split('.')
        if len(parts) >= 3:
            major = int(parts[0])
            minor = int(parts[1])
            patch = int(parts[2])
            build = int(parts[3]) if len(parts) > 3 else 0
            return (major, minor, patch, build)
    except (ValueError, IndexError):
        pass
    return None


def format_version(major: int, minor: int, patch: int, build: int = 0) -> str:
    """
    格式化版本号

    参数:
        major: 主版本号
        minor: 次版本号
        patch: 补丁版本号
        build: 构建号

    返回:
        格式化版本字符串
    """
    if build > 0:
        return f"{major}.{minor}.{patch}.{build}"
    return f"{major}.{minor}.{patch}"


def check_version_compatibility(required: tuple, actual: tuple) -> bool:
    """
    检查版本兼容性 (主版本号必须匹配, 次版本号不低于要求)

    参数:
        required: 要求版本 (major, minor, ...)
        actual:   实际版本 (major, minor, ...)

    返回:
        是否兼容
    """
    if len(required) < 2 or len(actual) < 2:
        return False
    if required[0] != actual[0]:
        return False
    return actual[1] >= required[1]
