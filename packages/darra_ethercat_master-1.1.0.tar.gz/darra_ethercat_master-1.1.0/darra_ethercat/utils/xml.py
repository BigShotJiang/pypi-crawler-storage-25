# -*- coding: utf-8 -*-
"""
对应 C# 文件: Utils/Xml.cs
XML 配置文件读写

包含:
- MasterXMLConfiguration: 主站 XML 配置数据类
- load_xml_configuration: 从 XML 加载配置

注: save_xml_configuration 已移除 —
    DENI 导出改为 Darra 主界面 / PLC 中间层内部功能, 不通过 SDK 对外开放。
    SDK 用户的标准工作流是先用 Darra 主界面生成 DENI, 再用 load_xml_configuration 加载。
"""

import xml.etree.ElementTree as ET
from typing import List, Optional, Tuple
from dataclasses import dataclass, field


@dataclass
class MasterXMLConfiguration:
    """主站 XML 配置"""
    version: str = "2.0"
    cycle_time_us: int = 1000
    dc_cycle_ns: int = 1000000
    adapter_name: str = ""
    adapter_description: str = ""
    adapter_mac: str = ""
    redundant_adapter_name: str = ""
    redundant_adapter_description: str = ""
    redundant_adapter_mac: str = ""
    redundancy_enabled: bool = False
    expected_slave_count: int = 0
    use_udp: bool = False
    vlan_id: int = 0
    vlan_priority: int = 0
    enable_overlapping_groups: bool = False
    packed_mode: bool = False
    frame_high_priority: bool = False
    cpu_affinity: int = -1
    pdo_logging: bool = False
    mailbox_logging: bool = False
    adaptive_timeout: bool = False
    frame_repeat_count: int = 1
    filter_threshold: int = 3
    mutex_protection: bool = True


def load_xml_configuration(path: str) -> Tuple[Optional[MasterXMLConfiguration], str]:
    """
    从 XML 文件加载主站配置

    参数:
        path: 文件路径

    返回:
        (config, message) 元组, 失败时 config 为 None
    """
    try:
        tree = ET.parse(path)
        root = tree.getroot()

        config = MasterXMLConfiguration()
        config.version = root.get('version', '2.0')

        # 主站配置
        master = root.find('Master')
        if master is not None:
            config.cycle_time_us = int(master.findtext('CycleTimeUs', '1000'))
            config.dc_cycle_ns = int(master.findtext('DcCycleNs', '1000000'))
            config.expected_slave_count = int(master.findtext('ExpectedSlaveCount', '0'))

        # 网络配置
        network = root.find('Network')
        if network is not None:
            config.adapter_name = network.findtext('AdapterName', '')
            config.adapter_description = network.findtext('AdapterDescription', '')
            config.adapter_mac = network.findtext('AdapterMAC', '')
            config.use_udp = network.findtext('UseUDP', 'false').lower() == 'true'
            config.redundancy_enabled = network.findtext('RedundancyEnabled', 'false').lower() == 'true'
            config.redundant_adapter_name = network.findtext('RedundantAdapterName', '')

        # 优化配置
        optimization = root.find('Optimization')
        if optimization is not None:
            config.frame_high_priority = optimization.findtext('FrameHighPriority', 'false').lower() == 'true'
            config.enable_overlapping_groups = optimization.findtext('OverlappingGroups', 'false').lower() == 'true'
            config.packed_mode = optimization.findtext('PackedMode', 'false').lower() == 'true'
            config.cpu_affinity = int(optimization.findtext('CpuAffinity', '-1'))
            config.adaptive_timeout = optimization.findtext('AdaptiveTimeout', 'false').lower() == 'true'
            config.frame_repeat_count = int(optimization.findtext('FrameRepeatCount', '1'))
            config.mutex_protection = optimization.findtext('MutexProtection', 'true').lower() == 'true'

        return (config, "加载成功")

    except Exception as ex:
        return (None, f"加载失败: {ex}")


# ===================== 从站 XML 配置数据模型 =====================

@dataclass
class QoSConfiguration:
    """
    QoS 配置 (对应 C# QoS 属性)

    EtherCAT 帧优先级和 VLAN 配置, 影响 IOmap 中帧的调度。
    """
    vlan_id: int = 0
    """VLAN ID (802.1Q, 0 表示不使用)"""
    vlan_priority: int = 0
    """VLAN 优先级 (0-7, PCP 字段)"""
    frame_high_priority: bool = False
    """是否启用高优先级帧发送"""
    enable_dscp: bool = False
    """是否启用 DSCP 标记 (仅 UDP 模式)"""
    dscp_value: int = 46
    """DSCP 值 (默认 EF=46, 仅 UDP 模式)"""


def apply_xml_configuration(config: MasterXMLConfiguration, master) -> bool:
    """
    将 XML 配置应用到主站 (对应 C# ApplyXMLConfiguration)

    解析配置对象中的参数并调用主站 API 设置:
    周期时间、DC 周期、CPU 亲和性、冗余模式等。

    参数:
        config: 已加载的 XML 配置
        master: EtherCATMaster 实例

    返回:
        是否成功应用
    """
    try:
        # 设置周期时间
        if config.cycle_time_us > 0:
            master.set_cycle_time(config.cycle_time_us * 1000)  # us -> ns

        # 设置 CPU 亲和性
        if config.cpu_affinity >= 0:
            master.set_cpu_affinity(config.cpu_affinity)

        # 设置冗余模式
        if config.redundancy_enabled:
            master.set_redundancy_mode(2)

        # 设置 UDP 模式
        if config.use_udp:
            master.udp_mode = True

        # 设置 Mutex 保护
        master.mutex_protection = config.mutex_protection

        return True
    except Exception:
        return False


@dataclass
class GroupConfigData:
    """组配置数据"""
    group_index: int = 0
    enabled: bool = False
    cycle_divider: int = 1


@dataclass
class SlaveDCConfig:
    """从站 DC 配置"""
    slave_index: int = 0
    vendor_id: int = 0
    product_code: int = 0
    sync0_cycle_ns: int = 0
    sync1_cycle_ns: int = 0
    shift_ns: int = 0


@dataclass
class XMLConfigurationResult:
    """XML 配置导入结果"""
    success: bool = False
    config_slave_count: int = 0
    actual_slave_count: int = 0
    matched_count: int = 0
    slave_details: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


@dataclass
class SyncManagerConfig:
    """SyncManager 配置"""
    index: int = 0
    start_addr: int = 0
    length: int = 0
    flags: int = 0
    sm_type: int = 0
    pdo_indices: List[int] = field(default_factory=list)
    watchdog: int = 0


@dataclass
class PDOEntryConfig:
    """PDO 条目配置"""
    index: int = 0
    sub_index: int = 0
    bit_length: int = 0
    name: str = ""
    data_type: str = ""
    offset: int = 0
    pdo_index: int = 0


@dataclass
class SlaveXMLConfiguration:
    """从站 XML 配置 (完整版)"""
    index: int = 0
    name: str = ""
    drive_name: str = ""
    vendor_id: int = 0
    product_code: int = 0
    revision: int = 0
    config_addr: int = 0
    input_size: int = 0
    output_size: int = 0
    input_pdos: List[PDOEntryConfig] = field(default_factory=list)
    output_pdos: List[PDOEntryConfig] = field(default_factory=list)
    sdo_init: list = field(default_factory=list)
    serial_no: int = 0
    alias_addr: int = 0
    mbx_write_offset: int = 0
    mbx_read_offset: int = 0
    mbx_write_length: int = 0
    mbx_read_length: int = 0
    mbx_poll_time: int = 0
    cia402_profile_no: int = 0
    bootstrap_send_offset: int = 0
    bootstrap_send_length: int = 0
    bootstrap_recv_offset: int = 0
    bootstrap_recv_length: int = 0
    has_dc: bool = False
    sync0_cycle_ns: int = 0
    sync1_cycle_ns: int = 0
    shift_ns: int = 0
    sync_managers: List[SyncManagerConfig] = field(default_factory=list)
    should_write_pdo_assignment: bool = True
    should_write_pdo_configuration: bool = False
    supports_complete_access: bool = False
    has_mdp: bool = False
    block_lrw: bool = False
    dtype: int = 0
    has_coe: bool = False
    has_foe: bool = False
    has_eoe: bool = False
    has_soe: bool = False
    has_aoe: bool = False
    has_voe: bool = False
    mailbox_data_link_layer: bool = False
    is_optional: bool = False
    wd_time_pd: int = 0
    wd_time_pdi: int = 0
    wd_divider: int = 0
    topology: int = 0
    active_ports: int = 0
    supports_frame_repeat: bool = False
