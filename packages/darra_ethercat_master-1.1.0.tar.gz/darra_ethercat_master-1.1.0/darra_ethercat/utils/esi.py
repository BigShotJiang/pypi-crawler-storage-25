# -*- coding: utf-8 -*-
"""
对应 C# 文件: Utils/ESI.cs
ESI (EtherCAT Slave Information) 工具函数及数据模型

包含:
- ESIPhysicsPortType: 物理端口类型枚举
- ESIRevisionCheckStrategy: 版本检查策略枚举
- ESIDeviceInfo: 设备详细信息
- ESICoEDetails: CoE 详细配置
- ESIDcConfiguration: DC 配置
- ESIDcOpMode: DC 操作模式
- ESIEepromConfiguration: EEPROM 配置
- ESIBootstrapInfo: Bootstrap 邮箱配置
- ESIElectricalInfo: 电气信息
- ESIIdentification: 设备识别信息
- ESIMailboxTimeout: 邮箱超时配置
- ESIPDOConfiguration: PDO 配置
- ESIPDOInfo / ESIPDOEntry: PDO 信息/条目
- ESIPhysicsInfo / ESIPhysicsPort: Physics 解析
- ESIPortInfo: 端口信息
- ESIStartupSDO: 启动 SDO
- ESIStatistics: ESI 统计信息
- ESISyncManagerInfo: SyncManager 信息
- EsiManager: ESI 加载管理器
"""

import os
from enum import IntEnum
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Callable, Tuple


# ===================== 枚举 =====================

class ESIPhysicsPortType(IntEnum):
    """ESI 物理端口类型"""
    NOT_USED = 0
    MII = 1
    EBUS = 2
    HOT_CONNECT = 3


class ESIRevisionCheckStrategy(IntEnum):
    """ESI 版本检查策略 (ETG.2000)"""
    NONE = 0
    EQ = 1
    EQ_OR_G = 2
    LW_EQ = 3
    HW_EQ = 4
    LW_EQ_OR_G = 5
    HW_EQ_OR_G = 6


# ===================== 数据模型 =====================

@dataclass
class EniMasterConfig:
    """ENI (ETG.2100) 主站配置摘要 — 用于 save_eni / load_eni 互通"""
    name: str = ""
    cycle_time_us: int = 1000
    dc_cycle_time_us: int = 1000
    expected_slave_count: int = 0


@dataclass
class EniSlaveConfig:
    """ENI (ETG.2100) 从站配置摘要"""
    physical_address: int = 0
    auto_inc_address: int = 0
    vendor_id: int = 0
    product_code: int = 0
    revision_number: int = 0
    name: str = ""
    dc_assign_activate: int = 0
    sm2_offset: int = 0
    sm2_length: int = 0
    sm3_offset: int = 0
    sm3_length: int = 0


@dataclass
class EniConfiguration:
    """ENI (ETG.2100 EtherCATConfig) 完整配置"""
    master: EniMasterConfig = field(default_factory=EniMasterConfig)
    slaves: List['EniSlaveConfig'] = field(default_factory=list)
    version: str = "3.0"


@dataclass
class ESIBootstrapInfo:
    """Bootstrap 邮箱配置"""
    recv_mailbox_offset: int = 0
    recv_mailbox_size: int = 0
    send_mailbox_offset: int = 0
    send_mailbox_size: int = 0


@dataclass
class ESICoEDetails:
    """ESI CoE 详细配置"""
    complete_access: bool = False
    diag_history: bool = False
    pdo_assign: bool = False
    pdo_config: bool = False
    sdo_info: bool = False
    segmented_sdo: bool = False


@dataclass
class ESIDcOpMode:
    """ESI DC 操作模式"""
    assign_activate: int = 0
    cycle_time_sync0: int = 0
    cycle_time_sync0_factor: int = 1
    cycle_time_sync1: int = 0
    cycle_time_sync1_factor: int = 1
    description: str = ""
    name: str = ""
    shift_time_sync0: int = 0
    shift_time_sync1: int = 0

    @property
    def is_dc_sync(self) -> bool:
        """是否为 DC 同步模式"""
        return self.assign_activate != 0

    @property
    def sync0_enabled(self) -> bool:
        """是否启用 SYNC0"""
        return (self.assign_activate & 0x0100) != 0

    @property
    def sync1_enabled(self) -> bool:
        """是否启用 SYNC1"""
        return (self.assign_activate & 0x0400) != 0


@dataclass
class ESIDcConfiguration:
    """ESI DC (分布式时钟) 配置"""
    op_modes: List[ESIDcOpMode] = field(default_factory=list)
    unknown_64bit: bool = False

    @property
    def dc_sync_op_mode(self) -> Optional[ESIDcOpMode]:
        """获取 DC 同步操作模式 (AssignActivate != 0)"""
        for m in self.op_modes:
            if m.assign_activate != 0:
                return m
        return None

    @property
    def default_op_mode(self) -> Optional[ESIDcOpMode]:
        """获取默认操作模式"""
        return self.op_modes[0] if self.op_modes else None


@dataclass
class ESIEepromConfiguration:
    """ESI EEPROM 配置"""
    bootstrap: Optional[ESIBootstrapInfo] = None
    byte_size: int = 0
    config_data: str = ""

    def config_data_bytes(self) -> bytes:
        """配置数据字节数组"""
        if not self.config_data:
            return b''
        result = []
        for i in range(0, len(self.config_data), 2):
            if i + 1 < len(self.config_data):
                try:
                    result.append(int(self.config_data[i:i+2], 16))
                except ValueError:
                    pass
        return bytes(result)


@dataclass
class ESIElectricalInfo:
    """ESI 电气信息"""
    ebus_current: int = 0

    @property
    def is_power_supply(self) -> bool:
        """是否为电源供应设备"""
        return self.ebus_current < 0

    @property
    def power_consumption(self) -> int:
        """功耗 (mA)"""
        return 0 if self.is_power_supply else self.ebus_current

    @property
    def power_supply_capacity(self) -> int:
        """供电能力 (mA)"""
        return -self.ebus_current if self.is_power_supply else 0


@dataclass
class ESIIdentification:
    """ESI 设备识别信息"""
    identification_ado: int = 0
    identification_value: int = 0


@dataclass
class ESIMailboxTimeout:
    """ESI 邮箱超时配置"""
    request_timeout: int = 100
    response_timeout: int = 2000


@dataclass
class ESIPDOEntry:
    """ESI PDO 条目信息"""
    bit_length: int = 0
    data_type: str = ""
    index: int = 0
    name: str = ""
    sub_index: int = 0


@dataclass
class ESIPDOInfo:
    """ESI PDO 信息"""
    entries: List[ESIPDOEntry] = field(default_factory=list)
    exclude_indices: List[int] = field(default_factory=list)
    index: int = 0
    is_fixed: bool = False
    is_mandatory: bool = False
    name: str = ""
    sync_manager: int = 0


@dataclass
class ESIPDOConfiguration:
    """ESI PDO 配置信息"""
    rx_pdos: List[ESIPDOInfo] = field(default_factory=list)
    tx_pdos: List[ESIPDOInfo] = field(default_factory=list)


@dataclass
class ESIPhysicsPort:
    """Physics 端口信息"""
    code: str = ""
    description: str = ""
    index: int = 0
    port_type: ESIPhysicsPortType = ESIPhysicsPortType.NOT_USED


@dataclass
class ESIPhysicsInfo:
    """ESI Physics 属性解析结果"""
    ports: List[ESIPhysicsPort] = field(default_factory=list)
    raw_value: str = ""

    @staticmethod
    def parse(physics: str) -> 'ESIPhysicsInfo':
        """解析 Physics 字符串"""
        info = ESIPhysicsInfo(raw_value=physics or "")
        if not physics:
            return info
        for i, ch in enumerate(physics):
            port = ESIPhysicsPort(index=i, code=ch)
            upper = ch.upper()
            if upper == 'Y':
                port.port_type = ESIPhysicsPortType.MII
                port.description = "MII (100Mbit)"
            elif upper == 'K':
                port.port_type = ESIPhysicsPortType.EBUS
                port.description = "E-Bus"
            elif upper == 'H':
                port.port_type = ESIPhysicsPortType.HOT_CONNECT
                port.description = "Hot Connect"
            else:
                port.port_type = ESIPhysicsPortType.NOT_USED
                port.description = "Not Used"
            info.ports.append(port)
        return info


@dataclass
class ESIPortInfo:
    """ESI 端口信息"""
    index: int = 0
    label: str = ""
    port_type: str = ""

    @property
    def is_ebus(self) -> bool:
        """是否为 EBUS 端口"""
        return self.port_type.upper() == "EBUS"

    @property
    def is_mii(self) -> bool:
        """是否为 MII 端口"""
        return self.port_type.upper() == "MII"


@dataclass
class ESIStartupSDO:
    """ESI 启动 SDO 配置"""
    data_type: str = ""
    index: int = 0
    name: str = ""
    sub_index: int = 0
    value: str = ""


@dataclass
class ESIStatistics:
    """ESI 统计信息"""
    total_devices: int = 0
    total_files: int = 0
    vendors: List[str] = field(default_factory=list)


@dataclass
class ESISyncManagerInfo:
    """ESI SyncManager 信息"""
    control_byte: int = 0
    default_size: int = 0
    enable: bool = False
    index: int = 0
    max_size: int = 0
    min_size: int = 0
    name: str = ""
    start_address: int = 0

    @property
    def sdo_index(self) -> int:
        """SDO 索引 (0x1C10 + SM索引)"""
        return 0x1C10 + self.index


@dataclass
class ESIDeviceInfo:
    """ESI 设备详细信息"""
    coe_details: Optional[ESICoEDetails] = None
    dc_configuration: Optional[ESIDcConfiguration] = None
    device_class: str = ""
    eeprom_configuration: Optional[ESIEepromConfiguration] = None
    electrical: Optional[ESIElectricalInfo] = None
    file_name: str = ""
    group_type: str = ""
    identification: Optional[ESIIdentification] = None
    mailbox_timeout: Optional[ESIMailboxTimeout] = None
    physics: str = ""
    physics_info: Optional[ESIPhysicsInfo] = None
    ports: List[ESIPortInfo] = field(default_factory=list)
    product_id: int = 0
    product_name: str = ""
    product_text: str = ""
    product_url: str = ""
    profile_number: str = ""
    revision_check_strategy: ESIRevisionCheckStrategy = ESIRevisionCheckStrategy.NONE
    revision_id: int = 0
    supports_coe: bool = False
    supports_eoe: bool = False
    supports_foe: bool = False
    supports_soe: bool = False
    supports_voe: bool = False
    supports_frame_repeat: bool = False
    vendor_comment: str = ""
    vendor_id: int = 0
    vendor_name: str = ""

    @property
    def dc_assign_activate(self) -> int:
        """DC 同步模式的 AssignActivate 值"""
        if self.dc_configuration and self.dc_configuration.dc_sync_op_mode:
            return self.dc_configuration.dc_sync_op_mode.assign_activate
        return 0

    @property
    def ebus_current(self) -> int:
        """E-Bus 电流 (mA)"""
        return self.electrical.ebus_current if self.electrical else 0

    @property
    def eeprom_size(self) -> int:
        """EEPROM 大小 (字节)"""
        return self.eeprom_configuration.byte_size if self.eeprom_configuration else 0

    @property
    def identification_ado(self) -> int:
        """识别 ADO 地址"""
        return self.identification.identification_ado if self.identification else 0

    @property
    def is_power_supply(self) -> bool:
        """是否为电源供应设备"""
        return self.electrical.is_power_supply if self.electrical else False

    @property
    def protocol_summary(self) -> str:
        """协议支持摘要"""
        protocols = []
        if self.supports_coe: protocols.append("CoE")
        if self.supports_foe: protocols.append("FoE")
        if self.supports_eoe: protocols.append("EoE")
        if self.supports_soe: protocols.append("SoE")
        if self.supports_voe: protocols.append("VoE")
        return ", ".join(protocols) if protocols else "None"

    @property
    def request_timeout(self) -> int:
        """请求超时 (ms)"""
        return self.mailbox_timeout.request_timeout if self.mailbox_timeout else 100

    @property
    def response_timeout(self) -> int:
        """响应超时 (ms)"""
        return self.mailbox_timeout.response_timeout if self.mailbox_timeout else 2000

    @property
    def supports_dc(self) -> bool:
        """是否支持 DC"""
        if self.dc_configuration:
            return any(m.is_dc_sync for m in self.dc_configuration.op_modes)
        return False

    @property
    def short_description(self) -> str:
        """简短描述"""
        return f"{self.product_name} ({self.vendor_name}) - 0x{self.product_id:08X}:0x{self.revision_id:08X}"


# ===================== ESI 工具函数 =====================

def calculate_eeprom_crc(data: bytes, length: int) -> int:
    """
    计算 EEPROM CRC-8 (多项式 0x07, 初始值 0xFF)

    参数:
        data:   EEPROM 数据
        length: 计算长度

    返回:
        8 位 CRC 值
    """
    crc = 0xFF
    for i in range(min(length, len(data))):
        crc ^= data[i]
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ 0x07) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc


def validate_eeprom_crc(eeprom_data: bytes) -> bool:
    """
    验证 EEPROM CRC
    EEPROM 头部前 14 字节的 CRC 存储在第 15 字节 (偏移 0x0E)

    参数:
        eeprom_data: EEPROM 数据 (至少 15 字节)

    返回:
        CRC 是否有效
    """
    if len(eeprom_data) < 15:
        return False
    calculated = calculate_eeprom_crc(eeprom_data, 14)
    return calculated == eeprom_data[14]


def match_revision(actual: int, expected: int,
                   strategy: ESIRevisionCheckStrategy) -> bool:
    """
    根据策略匹配版本号

    参数:
        actual:   实际设备版本号
        expected: ESI 定义的版本号
        strategy: 匹配策略

    返回:
        是否匹配
    """
    if expected == 0:
        return True
    if strategy == ESIRevisionCheckStrategy.NONE:
        return True
    elif strategy == ESIRevisionCheckStrategy.EQ:
        return actual == expected
    elif strategy == ESIRevisionCheckStrategy.EQ_OR_G:
        return actual >= expected
    elif strategy == ESIRevisionCheckStrategy.LW_EQ:
        return (actual & 0xFFFF) == (expected & 0xFFFF)
    elif strategy == ESIRevisionCheckStrategy.HW_EQ:
        return (actual >> 16) == (expected >> 16)
    elif strategy == ESIRevisionCheckStrategy.LW_EQ_OR_G:
        return (actual & 0xFFFF) >= (expected & 0xFFFF)
    elif strategy == ESIRevisionCheckStrategy.HW_EQ_OR_G:
        return (actual >> 16) >= (expected >> 16)
    return actual == expected


def get_default_esi_path() -> str:
    """获取默认 ESI 文件路径"""
    return os.path.join(os.path.dirname(os.path.dirname(__file__)), 'esi')


def find_esi_file(filename: str, search_paths: Optional[List[str]] = None) -> Optional[str]:
    """
    搜索 ESI 文件

    参数:
        filename:     ESI 文件名
        search_paths: 搜索路径列表 (None 使用默认路径)

    返回:
        找到的文件完整路径, 未找到返回 None
    """
    if search_paths is None:
        search_paths = [get_default_esi_path()]

    for path in search_paths:
        full_path = os.path.join(path, filename)
        if os.path.isfile(full_path):
            return full_path

    return None


# ===================== EsiManager =====================

class EsiManager:
    """
    ESI 加载管理器
    对应 C# EsiManager 静态类
    """

    _files: Dict[str, object] = {}
    _default_path: Optional[str] = None

    @classmethod
    def default_path(cls) -> str:
        """获取默认 ESI 文件路径"""
        return get_default_esi_path()

    @classmethod
    def preload(cls, progress_callback: Optional[Callable[[int, int, str], None]] = None):
        """预加载默认路径的 ESI 文件"""
        cls.load_path(cls.default_path(), progress_callback)

    @classmethod
    def is_preloaded(cls) -> bool:
        """检查是否已预加载"""
        return len(cls._files) > 0

    @classmethod
    def load_default(cls, progress_callback: Optional[Callable[[int, int, str], None]] = None):
        """加载默认路径的 ESI 文件"""
        cls.load_path(cls.default_path(), progress_callback)

    @classmethod
    def load_path(cls, path: str,
                  progress_callback: Optional[Callable[[int, int, str], None]] = None):
        """增量加载指定目录的 ESI 文件"""
        if not path or not os.path.isdir(path):
            return
        try:
            import xml.etree.ElementTree as ET
            xml_files = [f for f in os.listdir(path) if f.endswith('.xml')]
            total = len(xml_files)
            for i, fname in enumerate(xml_files):
                if fname in cls._files:
                    continue
                try:
                    fpath = os.path.join(path, fname)
                    tree = ET.parse(fpath)
                    cls._files[fname] = tree.getroot()
                except Exception:
                    pass
                if progress_callback:
                    progress_callback(i + 1, total, fname)
        except Exception:
            pass

    @classmethod
    def loaded_file_count(cls) -> int:
        """获取已加载文件数量"""
        return len(cls._files)

    @classmethod
    def clear(cls):
        """清空所有已加载的 ESI 文件"""
        cls._files.clear()

    @classmethod
    def remove_from_cache(cls, file_name: str):
        """从缓存中移除指定 ESI 文件"""
        cls._files.pop(file_name, None)

    @classmethod
    def is_file_loaded(cls, file_name: str) -> bool:
        """检查指定文件是否已加载"""
        return file_name in cls._files

    @classmethod
    def get_config_data_bytes(cls, vendor_id: int, product_code: int,
                               revision: int = 0) -> Optional[bytes]:
        """
        获取 ESI 配置数据的原始字节 (对应 C# GetConfigDataBytes)

        在已加载的 ESI 文件中查找匹配的设备, 返回其 EEPROM 配置数据。

        参数:
            vendor_id:    厂商 ID
            product_code: 产品代码
            revision:     修订号 (0 表示不限)

        返回:
            配置数据字节, 未找到返回 None
        """
        try:
            import xml.etree.ElementTree as ET
            for fname, root in cls._files.items():
                # 遍历所有 Vendor 节点
                for vendor in root.iter():
                    if vendor.tag.endswith('Vendor') or vendor.tag == 'Vendor':
                        vid_elem = vendor.find('Id')
                        if vid_elem is None:
                            continue
                        vid_text = (vid_elem.text or '').strip()
                        try:
                            vid = int(vid_text, 16) if vid_text.startswith(('#', '0x')) else int(vid_text)
                        except (ValueError, TypeError):
                            continue
                        if vid != vendor_id:
                            continue

                    # 遍历 Device 节点
                    for device in vendor.iter():
                        if not (device.tag.endswith('Device') or device.tag == 'Device'):
                            continue
                        # 检查 ProductCode
                        type_elem = device.find('Type')
                        if type_elem is None:
                            continue
                        pc_attr = type_elem.get('ProductCode', '')
                        try:
                            pc = int(pc_attr, 16) if pc_attr.startswith(('#', '0x')) else int(pc_attr)
                        except (ValueError, TypeError):
                            continue
                        if pc != product_code:
                            continue
                        # 检查 Revision (如果指定)
                        if revision != 0:
                            rev_attr = type_elem.get('RevisionNo', '0')
                            try:
                                rev = int(rev_attr, 16) if rev_attr.startswith(('#', '0x')) else int(rev_attr)
                            except (ValueError, TypeError):
                                rev = 0
                            if rev != revision:
                                continue
                        # 提取 Eeprom/ConfigData
                        eeprom = device.find('Eeprom')
                        if eeprom is None:
                            continue
                        config_data = eeprom.findtext('ConfigData', '')
                        if not config_data:
                            continue
                        # 将十六进制字符串转为字节
                        result = []
                        for i in range(0, len(config_data), 2):
                            if i + 1 < len(config_data):
                                try:
                                    result.append(int(config_data[i:i+2], 16))
                                except ValueError:
                                    pass
                        if result:
                            return bytes(result)
        except Exception:
            pass
        return None


# ===================== ENI (ETG.2100) Save (托管实装) =====================
# 对齐 Java Eni.saveENI / C# ESI.SaveENI: DLL 未导出 EcEni_Save, 在托管端用
# xml.etree.ElementTree 直接生成 ETG.2100 EtherCATConfig 骨架 (Master + Slave[]),
# 写盘成功返回 True. 不依赖 DLL FFI, 各语言走各自惯用 XML API.

def save_eni(file_path: str, config: 'EniConfiguration') -> bool:
    """
    保存 ENI 配置到 XML 文件 (ETG.2100 EtherCATConfig 格式).

    用 xml.etree.ElementTree 在托管端生成 ETG.2100 标准骨架:

        <EtherCATConfig version="3.0">
          <Config>
            <Master>
              <Info><Name>...</Name></Info>
              <CycleTime>...</CycleTime>
              <DcCycleTime>...</DcCycleTime>
            </Master>
            <Slave>
              <Info>
                <Name>...</Name>
                <PhysAddr>#x...</PhysAddr>
                <AutoIncAddr>#x...</AutoIncAddr>
                <VendorId>#x...</VendorId>
                <ProductCode>#x...</ProductCode>
                <RevisionNo>#x...</RevisionNo>
              </Info>
              <ProcessData>
                <Sm No="2"><StartAddress>#x...</StartAddress><DefaultSize>#x...</DefaultSize></Sm>
                <Sm No="3"><StartAddress>#x...</StartAddress><DefaultSize>#x...</DefaultSize></Sm>
              </ProcessData>
              <Dc><AssignActivate>#x...</AssignActivate></Dc>
            </Slave>
            ...
          </Config>
        </EtherCATConfig>

    DC offset / cycle 真实值需要 DLL 端 ENI builder 提供, 此处为最小骨架.
    与 Java/C# 保持一致, DLL 端 EcEni_Save 实装就绪后, 上层可改走 FFI.

    参数:
        file_path: 输出 XML 文件路径
        config:    ENI 配置对象 (EniConfiguration)
    返回:
        写盘成功返回 True; 参数非法 / IO 失败返回 False
    """
    if not file_path or config is None:
        return False
    try:
        import xml.etree.ElementTree as ET

        def _hex(v: int) -> str:
            """ETG.2100 标准十六进制格式 (#x前缀)"""
            return f"#x{v & 0xFFFFFFFF:x}"

        root = ET.Element("EtherCATConfig", attrib={"version": config.version or "3.0"})
        cfg = ET.SubElement(root, "Config")

        # ----- Master -----
        m = config.master if config.master else EniMasterConfig()
        master_el = ET.SubElement(cfg, "Master")
        info_el = ET.SubElement(master_el, "Info")
        ET.SubElement(info_el, "Name").text = m.name or "Darra EtherCAT Master"
        ET.SubElement(master_el, "CycleTime").text = str(int(m.cycle_time_us))
        ET.SubElement(master_el, "DcCycleTime").text = str(int(m.dc_cycle_time_us))

        # ----- Slave[] -----
        for s in (config.slaves or []):
            slave_el = ET.SubElement(cfg, "Slave")
            sinfo = ET.SubElement(slave_el, "Info")
            ET.SubElement(sinfo, "Name").text = s.name or ""
            ET.SubElement(sinfo, "PhysAddr").text = _hex(s.physical_address)
            ET.SubElement(sinfo, "AutoIncAddr").text = _hex(s.auto_inc_address)
            ET.SubElement(sinfo, "VendorId").text = _hex(s.vendor_id)
            ET.SubElement(sinfo, "ProductCode").text = _hex(s.product_code)
            ET.SubElement(sinfo, "RevisionNo").text = _hex(s.revision_number)

            pd = ET.SubElement(slave_el, "ProcessData")
            if s.sm2_length > 0:
                sm2 = ET.SubElement(pd, "Sm", attrib={"No": "2"})
                ET.SubElement(sm2, "StartAddress").text = _hex(s.sm2_offset)
                ET.SubElement(sm2, "DefaultSize").text = _hex(s.sm2_length)
            if s.sm3_length > 0:
                sm3 = ET.SubElement(pd, "Sm", attrib={"No": "3"})
                ET.SubElement(sm3, "StartAddress").text = _hex(s.sm3_offset)
                ET.SubElement(sm3, "DefaultSize").text = _hex(s.sm3_length)

            if s.dc_assign_activate != 0:
                dc_el = ET.SubElement(slave_el, "Dc")
                ET.SubElement(dc_el, "AssignActivate").text = _hex(s.dc_assign_activate)

        # 缩进 (Python 3.9+: ET.indent; 旧版本忽略)
        try:
            ET.indent(root, space="  ")
        except AttributeError:
            pass

        tree = ET.ElementTree(root)
        tree.write(file_path, encoding="utf-8", xml_declaration=True)
        return True
    except Exception:
        return False
