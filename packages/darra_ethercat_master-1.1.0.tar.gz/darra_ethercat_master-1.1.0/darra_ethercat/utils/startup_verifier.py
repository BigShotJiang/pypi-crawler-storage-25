# -*- coding: utf-8 -*-
"""
启动配置验证器
对应 C# Utils/StartupConfigurationVerifier.cs
用于验证实际从站配置是否符合预期
"""

import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Optional, List, Union


# ===================== 预期从站配置 =====================

@dataclass
class ExpectedSlaveConfig:
    """
    预期从站配置
    对应 C# ExpectedSlaveConfig 类
    """
    index: int = 0
    """从站索引"""
    vendor_id: int = 0
    """厂商 ID"""
    product_code: int = 0
    """产品代码"""
    revision_no: int = 0
    """修订号"""
    serial_no: int = 0
    """序列号"""
    alias_addr: int = 0
    """别名地址"""
    active_ports: int = 0
    """活跃端口位图"""
    topology: int = 0
    """拓扑类型"""
    name: str = ""
    """从站名称"""


# ===================== 从站详细验证结果 =====================

@dataclass
class SlaveVerifyDetail:
    """
    从站详细验证结果
    对应 C# SlaveDetail 类
    """
    slave_index: int = 0
    """从站索引"""
    slave_name: str = ""
    """从站名称"""
    is_match: bool = True
    """是否完全匹配"""
    expected_vendor_id: int = 0
    actual_vendor_id: int = 0
    vendor_id_match: bool = True
    expected_product_code: int = 0
    actual_product_code: int = 0
    product_code_match: bool = True
    expected_revision_no: int = 0
    actual_revision_no: int = 0
    revision_no_match: bool = True
    expected_serial_no: int = 0
    actual_serial_no: int = 0
    serial_no_match: bool = True
    expected_alias_addr: int = 0
    actual_alias_addr: int = 0
    alias_match: bool = True
    topology_match: bool = True


# ===================== 验证结果 =====================

@dataclass
class VerificationResult:
    """
    验证结果
    对应 C# VerificationResult 类
    """
    success: bool = True
    """验证是否通过"""
    errors: List[str] = field(default_factory=list)
    """错误列表"""
    warnings: List[str] = field(default_factory=list)
    """警告列表"""
    slave_details: List[SlaveVerifyDetail] = field(default_factory=list)
    """从站详细验证结果"""


# ===================== 配置验证器 =====================

def verify_configuration(master, expected_configs: List[ExpectedSlaveConfig],
                         strict_mode: bool = False) -> VerificationResult:
    """
    验证配置 - 简单模式

    参数:
        master: EtherCATMaster 实例
        expected_configs: 预期从站配置列表
        strict_mode: 严格模式 (验证修订号和序列号)

    返回:
        VerificationResult
    """
    result = VerificationResult()

    if master is None:
        result.success = False
        result.errors.append("主站实例为空")
        return result

    if not expected_configs:
        result.warnings.append("没有预期配置进行验证")
        return result

    slave_count = master.slave_count
    expected_count = len(expected_configs)

    # 检查从站数量
    if slave_count != expected_count:
        result.warnings.append(
            f"从站数量不匹配: 实际 {slave_count}, 预期 {expected_count}")

    # 逐个验证
    check_count = min(slave_count, expected_count)
    for i in range(check_count):
        slave = master[i + 1]  # 1-based
        expected = expected_configs[i]
        ident = slave.identity

        if ident is None:
            result.success = False
            result.errors.append(f"从站 {i + 1} 身份信息读取失败")
            continue

        actual_vid = ident.get('vendor_id', 0)
        actual_pid = ident.get('product_code', 0)
        actual_rev = ident.get('revision_no', 0)
        actual_sn = ident.get('serial_no', 0)

        # 基本匹配: 厂商ID + 产品码
        if actual_vid != expected.vendor_id or actual_pid != expected.product_code:
            result.success = False
            result.errors.append(
                f"从站 {i + 1} 不匹配: "
                f"实际 VID=0x{actual_vid:X} PID=0x{actual_pid:X}, "
                f"预期 VID=0x{expected.vendor_id:X} PID=0x{expected.product_code:X}")

        # 严格模式: 修订号
        if strict_mode and actual_rev != expected.revision_no:
            result.warnings.append(
                f"从站 {i + 1} RevisionNo 不匹配: "
                f"实际 0x{actual_rev:X}, 预期 0x{expected.revision_no:X}")

        # 严格模式: 序列号
        if strict_mode and expected.serial_no != 0 and actual_sn != expected.serial_no:
            result.warnings.append(
                f"从站 {i + 1} SerialNo 不匹配: "
                f"实际 0x{actual_sn:X}, 预期 0x{expected.serial_no:X}")

    return result


def verify_configuration_detailed(master, expected_configs: List[ExpectedSlaveConfig],
                                  strict_mode: bool = False) -> VerificationResult:
    """
    验证配置 - 详细模式 (返回每个从站的详细匹配结果)

    参数:
        master: EtherCATMaster 实例
        expected_configs: 预期从站配置列表
        strict_mode: 严格模式 (验证修订号和序列号)

    返回:
        VerificationResult (含详细 slave_details)
    """
    result = VerificationResult()

    if master is None:
        result.success = False
        result.errors.append("主站或从站列表为空")
        return result

    if not expected_configs:
        result.warnings.append("没有预期配置进行验证")
        return result

    slave_count = master.slave_count
    expected_count = len(expected_configs)

    # 检查从站数量
    if slave_count != expected_count:
        result.warnings.append(
            f"从站数量不匹配: 实际 {slave_count}, 预期 {expected_count}")

    # 逐个验证
    check_count = min(slave_count, expected_count)
    for i in range(check_count):
        slave = master[i + 1]  # 1-based
        expected = expected_configs[i]
        ident = slave.identity or {}

        actual_vid = ident.get('vendor_id', 0)
        actual_pid = ident.get('product_code', 0)
        actual_rev = ident.get('revision_no', 0)
        actual_sn = ident.get('serial_no', 0)

        detail = SlaveVerifyDetail(
            slave_index=i + 1,
            slave_name=expected.name,
            expected_vendor_id=expected.vendor_id,
            actual_vendor_id=actual_vid,
            expected_product_code=expected.product_code,
            actual_product_code=actual_pid,
            expected_revision_no=expected.revision_no,
            actual_revision_no=actual_rev,
            expected_serial_no=expected.serial_no,
            actual_serial_no=actual_sn,
            expected_alias_addr=expected.alias_addr,
            actual_alias_addr=0,  # 需要额外 DLL 调用获取
        )

        # 验证厂商ID
        detail.vendor_id_match = (actual_vid == expected.vendor_id)

        # 验证产品码
        detail.product_code_match = (actual_pid == expected.product_code)

        # 验证版本号（仅在严格模式下）
        detail.revision_no_match = (
            not strict_mode or actual_rev == expected.revision_no)

        # 验证序列号（仅在严格模式且期望值非零时验证）
        detail.serial_no_match = (
            not strict_mode or expected.serial_no == 0 or
            actual_sn == expected.serial_no)

        # 验证别名地址（仅在期望值非零时验证）
        detail.alias_match = (expected.alias_addr == 0 or
                              detail.actual_alias_addr == expected.alias_addr)

        # 拓扑匹配
        if expected.active_ports == 0 and expected.topology == 0:
            detail.topology_match = True
        else:
            # 需要通过 DLL 获取实际拓扑信息
            try:
                actual_ports = slave.active_ports
                detail.topology_match = (actual_ports == expected.active_ports)
            except Exception:
                detail.topology_match = True  # 无法获取时跳过

        # 综合判断
        detail.is_match = (
            detail.vendor_id_match and detail.product_code_match and
            detail.revision_no_match and detail.serial_no_match and
            detail.alias_match and detail.topology_match)

        if not detail.is_match:
            result.success = False
            errs = []
            if not detail.vendor_id_match:
                errs.append(
                    f"VID 0x{actual_vid:X}!=0x{expected.vendor_id:X}")
            if not detail.product_code_match:
                errs.append(
                    f"PID 0x{actual_pid:X}!=0x{expected.product_code:X}")
            if not detail.revision_no_match:
                errs.append(
                    f"Rev 0x{actual_rev:X}!=0x{expected.revision_no:X}")
            if not detail.serial_no_match:
                errs.append(
                    f"SN 0x{actual_sn:X}!=0x{expected.serial_no:X}")
            if not detail.alias_match:
                errs.append(
                    f"Alias {detail.actual_alias_addr}!={expected.alias_addr}")
            if not detail.topology_match:
                errs.append("拓扑不匹配")
            result.errors.append(
                f"从站 {i + 1} 不匹配: {', '.join(errs)}")

        result.slave_details.append(detail)

    return result


def create_expected_configs_from_dict(configs: List[dict]) -> List[ExpectedSlaveConfig]:
    """
    从字典列表创建预期配置

    参数:
        configs: 配置字典列表, 每项可含:
            index, vendor_id, product_code, revision_no, serial_no,
            alias_addr, active_ports, topology, name

    返回:
        ExpectedSlaveConfig 列表
    """
    result = []
    for cfg in configs:
        result.append(ExpectedSlaveConfig(
            index=cfg.get('index', 0),
            vendor_id=cfg.get('vendor_id', 0),
            product_code=cfg.get('product_code', 0),
            revision_no=cfg.get('revision_no', 0),
            serial_no=cfg.get('serial_no', 0),
            alias_addr=cfg.get('alias_addr', 0),
            active_ports=cfg.get('active_ports', 0),
            topology=cfg.get('topology', 0),
            name=cfg.get('name', ''),
        ))
    return result


def create_expected_configs_from_xml(xml_source: Union[str, ET.Element]) -> List[ExpectedSlaveConfig]:
    """
    从 XML 配置文件 (或 XML 字符串) 创建预期配置列表

    支持 DarraEtherCAT 导出的 XML 配置格式，从 <Slave> 节点解析
    VendorId, ProductCode, RevisionNo 等信息。

    参数:
        xml_source: XML 文件路径、XML 字符串或已解析的 Element

    返回:
        ExpectedSlaveConfig 列表
    """
    if isinstance(xml_source, ET.Element):
        root = xml_source
    elif isinstance(xml_source, str):
        # 判断是文件路径还是 XML 字符串
        if xml_source.strip().startswith('<'):
            root = ET.fromstring(xml_source)
        else:
            tree = ET.parse(xml_source)
            root = tree.getroot()
    else:
        raise TypeError(f"不支持的 xml_source 类型: {type(xml_source)}")

    results = []
    # 查找所有 Slave 节点 (支持多种命名空间)
    slave_nodes = root.findall('.//Slave')
    if not slave_nodes:
        # 尝试带命名空间
        for ns_prefix in ['', '{http://www.darra.com/ethercat}']:
            slave_nodes = root.findall(f'.//{ns_prefix}Slave')
            if slave_nodes:
                break

    for idx, node in enumerate(slave_nodes):
        cfg = ExpectedSlaveConfig(index=idx + 1)

        # 解析十六进制或十进制值
        def _parse_int(tag: str, default: int = 0) -> int:
            elem = node.find(tag)
            if elem is not None and elem.text:
                text = elem.text.strip()
                if text.startswith('0x') or text.startswith('0X'):
                    return int(text, 16)
                return int(text)
            return default

        cfg.vendor_id = _parse_int('VendorId')
        cfg.product_code = _parse_int('ProductCode')
        cfg.revision_no = _parse_int('RevisionNo')
        cfg.serial_no = _parse_int('SerialNo')
        cfg.alias_addr = _parse_int('AliasAddr')
        cfg.active_ports = _parse_int('ActivePorts')
        cfg.topology = _parse_int('Topology')

        # 名称
        name_elem = node.find('Name')
        if name_elem is not None and name_elem.text:
            cfg.name = name_elem.text.strip()

        results.append(cfg)

    return results


def verify_configuration_with_dll(dll, master_index: int,
                                   expected_configs: List[ExpectedSlaveConfig],
                                   strict_mode: bool = False) -> VerificationResult:
    """
    通过 DLL 直接验证配置 (不需要 EtherCATMaster 实例)

    使用底层 DLL 调用获取从站身份信息进行验证。
    适用于需要在初始化主站之前进行配置验证的场景。

    参数:
        dll: DarraCoreDLL 实例
        master_index: 主站索引
        expected_configs: 预期从站配置列表
        strict_mode: 严格模式 (验证修订号和序列号)

    返回:
        VerificationResult
    """
    import ctypes
    from ctypes import c_uint, c_ushort, byref

    result = VerificationResult()

    if not expected_configs:
        result.warnings.append("没有预期配置进行验证")
        return result

    # 获取实际从站数 (通过 GetMasterState 结构体)
    try:
        state_ptr = dll.GetMasterState(master_index)
        if state_ptr:
            import ctypes
            # ec_State 结构体的第一个 uint16 字段是 slave_count
            slave_count = ctypes.cast(state_ptr, ctypes.POINTER(ctypes.c_ushort))[0]
        else:
            slave_count = 0
    except Exception as e:
        result.success = False
        result.errors.append(f"获取从站数量失败: {e}")
        return result

    expected_count = len(expected_configs)
    if slave_count != expected_count:
        result.warnings.append(
            f"从站数量不匹配: 实际 {slave_count}, 预期 {expected_count}")

    check_count = min(slave_count, expected_count)
    for i in range(check_count):
        expected = expected_configs[i]
        slave_idx = i + 1

        # 通过 DLL 读取从站身份信息
        vid = c_uint(0)
        pid = c_uint(0)
        rev = c_uint(0)
        sn = c_uint(0)

        try:
            dll.GetSlaveIdentity(
                master_index, slave_idx,
                byref(vid), byref(pid), byref(rev), byref(sn))
        except Exception as e:
            result.success = False
            result.errors.append(f"从站 {slave_idx} 身份信息读取失败: {e}")
            continue

        actual_vid = vid.value
        actual_pid = pid.value
        actual_rev = rev.value
        actual_sn = sn.value

        # 基本匹配: 厂商ID + 产品码
        if actual_vid != expected.vendor_id or actual_pid != expected.product_code:
            result.success = False
            result.errors.append(
                f"从站 {slave_idx} 不匹配: "
                f"实际 VID=0x{actual_vid:X} PID=0x{actual_pid:X}, "
                f"预期 VID=0x{expected.vendor_id:X} PID=0x{expected.product_code:X}")

        # 严格模式: 修订号
        if strict_mode and actual_rev != expected.revision_no:
            result.warnings.append(
                f"从站 {slave_idx} RevisionNo 不匹配: "
                f"实际 0x{actual_rev:X}, 预期 0x{expected.revision_no:X}")

        # 严格模式: 序列号
        if strict_mode and expected.serial_no != 0 and actual_sn != expected.serial_no:
            result.warnings.append(
                f"从站 {slave_idx} SerialNo 不匹配: "
                f"实际 0x{actual_sn:X}, 预期 0x{expected.serial_no:X}")

    return result
