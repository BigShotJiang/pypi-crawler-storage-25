# -*- coding: utf-8 -*-
"""
对应 C# 文件: Utils/Help.cs
字符串编码辅助工具

包含:
- convert_byte_array_to_string: 字节数组转字符串 (自动检测编码)
"""


def convert_byte_array_to_string(data: bytes) -> str:
    """
    将字节数组转换为字符串 (自动检测编码)

    优先尝试 UTF-8, 失败后回退到 Latin-1。

    参数:
        data: 字节数据

    返回:
        解码后的字符串
    """
    if not data:
        return ""

    # 去除末尾 NUL
    null_idx = data.find(b'\x00')
    if null_idx >= 0:
        data = data[:null_idx]

    if not data:
        return ""

    # 优先 UTF-8
    try:
        return data.decode('utf-8')
    except UnicodeDecodeError:
        pass

    # 回退 Latin-1 (不会抛异常)
    return data.decode('latin-1')
