# -*- coding: utf-8 -*-
"""
EtherCAT 基础数据常量和辅助函数
对应 C# Utils/BaseData.cs
"""


# ===================== EtherCAT 基础常量 =====================

# 最大从站数
EC_MAX_SLAVE = 512

# 最大组数
EC_MAX_GROUP = 8

# 最大邮箱大小
EC_MAX_MAILBOX_SIZE = 1486

# SDO 最大数据大小
EC_MAX_SDO_SIZE = 65536

# EEPROM 最大大小
EC_MAX_EEPROM_SIZE = 0x8000

# 从站名称最大长度
EC_MAX_NAME = 40

# 支持的最大端口数
EC_MAX_PORTS = 4

# 最大 FMMU 数
EC_MAX_FMMU = 16

# 最大同步管理器数
EC_MAX_SM = 8

# EtherCAT 头部大小
EC_HEADER_SIZE = 2

# EtherCAT 数据链路层帧头大小
EC_DLPDU_HEADER_SIZE = 10

# EtherCAT 帧最小大小
EC_MIN_FRAME_SIZE = 64

# EtherCAT 帧最大大小 (含以太网头)
EC_MAX_FRAME_SIZE = 1518

# ===================== ESC 寄存器地址 =====================

# ESC 类型
ESC_REG_TYPE = 0x0000
# ESC 修订号
ESC_REG_REVISION = 0x0001
# ESC 构建号
ESC_REG_BUILD = 0x0002
# FMMU 支持数
ESC_REG_FMMU_COUNT = 0x0004
# SM 支持数
ESC_REG_SM_COUNT = 0x0005
# RAM 大小
ESC_REG_RAM_SIZE = 0x0006
# 端口描述符
ESC_REG_PORT_DESC = 0x0007
# ESC 特性寄存器
ESC_REG_FEATURES = 0x0008

# 配置地址 (Configured Station Address)
ESC_REG_CONFIG_ADDR = 0x0010
# 别名地址 (Configured Station Alias)
ESC_REG_ALIAS_ADDR = 0x0012

# DL 控制寄存器
ESC_REG_DL_CONTROL = 0x0100
# DL 状态寄存器
ESC_REG_DL_STATUS = 0x0110

# AL 控制寄存器
ESC_REG_AL_CONTROL = 0x0120
# AL 状态寄存器
ESC_REG_AL_STATUS = 0x0130
# AL 状态码
ESC_REG_AL_STATUS_CODE = 0x0134

# PDI 控制寄存器
ESC_REG_PDI_CONTROL = 0x0140

# 看门狗分频器
ESC_REG_WD_DIVISOR = 0x0400
# PDI 看门狗
ESC_REG_WD_PDI = 0x0410
# SM 看门狗
ESC_REG_WD_SM = 0x0420
# 看门狗状态
ESC_REG_WD_STATUS = 0x0440

# SM0 起始地址
ESC_REG_SM0 = 0x0800
# SM1 起始地址
ESC_REG_SM1 = 0x0808
# SM2 起始地址
ESC_REG_SM2 = 0x0810
# SM3 起始地址
ESC_REG_SM3 = 0x0818

# DC 接收时间端口 0
ESC_REG_DC_TIME_PORT0 = 0x0900
# DC 接收时间端口 1
ESC_REG_DC_TIME_PORT1 = 0x0904
# DC 系统时间
ESC_REG_DC_SYSTEM_TIME = 0x0910
# DC 系统时间差
ESC_REG_DC_SYS_TIME_DIFF = 0x092C
# DC SYNC0 周期时间
ESC_REG_DC_SYNC0_CYCLE = 0x09A0
# DC SYNC1 周期时间
ESC_REG_DC_SYNC1_CYCLE = 0x09A4

# EEPROM 配置
ESC_REG_EEPROM_CONFIG = 0x0500
# EEPROM 控制/状态
ESC_REG_EEPROM_CTRL = 0x0502
# EEPROM 地址
ESC_REG_EEPROM_ADDR = 0x0504
# EEPROM 数据
ESC_REG_EEPROM_DATA = 0x0508

# ===================== SII EEPROM 分类 =====================

# SII 分类标识
SII_CAT_NOP = 0
SII_CAT_STRING = 10
SII_CAT_DATATYPE = 20
SII_CAT_GENERAL = 30
SII_CAT_FMMU = 40
SII_CAT_SM = 41
SII_CAT_TXPDO = 50
SII_CAT_RXPDO = 51
SII_CAT_DC = 60
SII_CAT_END = 0xFFFF

# ===================== BaseData 类型化包装器 =====================

class BaseData:
    """
    基础数据类型化包装器
    对应 C# BaseData 类
    提供类型安全的数据读写、位级访问、自动类型转换

    用法:
        bd = BaseData(b'\\x01\\x02\\x03\\x04', dtype=0x0007)  # Unsigned32
        value = bd.content  # 自动转为 int
        bd.content = 12345
        raw = bd.get_raw_data()
    """

    # 数据类型到大小的映射 (字节)
    _TYPE_SIZES = {
        0x0001: 1,   # Boolean
        0x0002: 1,   # Integer8
        0x0003: 2,   # Integer16
        0x0004: 4,   # Integer32
        0x0005: 1,   # Unsigned8
        0x0006: 2,   # Unsigned16
        0x0007: 4,   # Unsigned32
        0x0008: 4,   # Real32
        0x0010: 3,   # Integer24
        0x0011: 8,   # Real64
        0x0015: 8,   # Integer64
        0x0016: 3,   # Unsigned24
        0x001B: 8,   # Unsigned64
    }

    # 数据类型到 struct 格式的映射
    _TYPE_FORMATS = {
        0x0001: '<B',   # Boolean -> uint8
        0x0002: '<b',   # Integer8
        0x0003: '<h',   # Integer16
        0x0004: '<i',   # Integer32
        0x0005: '<B',   # Unsigned8
        0x0006: '<H',   # Unsigned16
        0x0007: '<I',   # Unsigned32
        0x0008: '<f',   # Real32
        0x0011: '<d',   # Real64
        0x0015: '<q',   # Integer64
        0x001B: '<Q',   # Unsigned64
    }

    def __init__(self, data: bytes = b'', dtype: int = 0, bit_length: int = 0):
        """
        创建 BaseData 实例

        参数:
            data: 原始字节数据
            dtype: EtherCAT 数据类型 (如 0x0007 = Unsigned32)
            bit_length: 位长度 (0=根据类型自动计算)
        """
        self._data = bytearray(data)
        self._dtype = dtype
        self._bit_length = bit_length

    @property
    def data_type(self) -> int:
        """数据类型"""
        return self._dtype

    @property
    def bit_length(self) -> int:
        """位长度"""
        if self._bit_length > 0:
            return self._bit_length
        size = self._TYPE_SIZES.get(self._dtype, len(self._data))
        return size * 8

    @property
    def byte_length(self) -> int:
        """字节长度"""
        return (self.bit_length + 7) // 8

    @property
    def content(self):
        """
        获取类型化的内容值
        根据 dtype 自动转换为 int/float/bool/str/bytes
        """
        return self._convert_from_raw()

    @content.setter
    def content(self, value):
        """
        设置内容值
        根据 dtype 自动转换为原始字节
        """
        self._convert_to_raw(value)

    def get_raw_data(self) -> bytes:
        """获取原始字节数据"""
        return bytes(self._data)

    def write(self, value) -> bool:
        """
        写入值 (与 content setter 相同)

        参数:
            value: 要写入的值

        返回:
            是否成功
        """
        try:
            self._convert_to_raw(value)
            return True
        except Exception:
            return False

    def write_raw(self, data: bytes) -> bool:
        """
        直接写入原始字节

        参数:
            data: 原始字节

        返回:
            是否成功
        """
        self._data = bytearray(data)
        return True

    def get_bit(self, bit_index: int) -> bool:
        """
        获取指定位的值

        参数:
            bit_index: 位索引 (0-based)

        返回:
            位值
        """
        byte_idx = bit_index // 8
        bit_idx = bit_index % 8
        if byte_idx >= len(self._data):
            return False
        return bool(self._data[byte_idx] & (1 << bit_idx))

    def set_bit(self, bit_index: int, value: bool):
        """
        设置指定位的值

        参数:
            bit_index: 位索引 (0-based)
            value: 位值
        """
        byte_idx = bit_index // 8
        bit_idx = bit_index % 8
        # 扩展数据到需要的大小
        while byte_idx >= len(self._data):
            self._data.append(0)
        if value:
            self._data[byte_idx] |= (1 << bit_idx)
        else:
            self._data[byte_idx] &= ~(1 << bit_idx)

    def __getitem__(self, bit_index: int) -> bool:
        """位级索引器: bd[3] 获取第3位"""
        return self.get_bit(bit_index)

    def __setitem__(self, bit_index: int, value: bool):
        """位级索引器: bd[3] = True 设置第3位"""
        self.set_bit(bit_index, value)

    def _convert_from_raw(self):
        """根据类型将原始数据转换为 Python 值"""
        import struct

        if not self._data:
            return None

        fmt = self._TYPE_FORMATS.get(self._dtype)
        if fmt:
            expected = struct.calcsize(fmt)
            data = bytes(self._data)
            if len(data) < expected:
                data = data.ljust(expected, b'\x00')
            val = struct.unpack(fmt, data[:expected])[0]
            # Boolean 特殊处理
            if self._dtype == 0x0001:
                return bool(val)
            return val

        # 24位整数特殊处理
        if self._dtype in (0x0010, 0x0016):
            data = bytes(self._data)
            if len(data) < 3:
                data = data.ljust(3, b'\x00')
            val = data[0] | (data[1] << 8) | (data[2] << 16)
            if self._dtype == 0x0010 and val & 0x800000:  # Integer24 符号扩展
                val -= 0x1000000
            return val

        # 字符串类型
        if self._dtype in (0x0009, 0x000B):
            return bytes(self._data).decode('utf-8', errors='replace').rstrip('\x00')

        # 默认返回原始字节
        return bytes(self._data)

    def _convert_to_raw(self, value):
        """根据类型将 Python 值转换为原始数据"""
        import struct

        fmt = self._TYPE_FORMATS.get(self._dtype)
        if fmt:
            if self._dtype == 0x0001:
                value = 1 if value else 0
            self._data = bytearray(struct.pack(fmt, value))
            return

        # 24位整数
        if self._dtype in (0x0010, 0x0016):
            if self._dtype == 0x0010 and value < 0:
                value += 0x1000000
            self._data = bytearray([value & 0xFF, (value >> 8) & 0xFF, (value >> 16) & 0xFF])
            return

        # 字符串
        if self._dtype in (0x0009, 0x000B):
            self._data = bytearray(str(value).encode('utf-8'))
            return

        # 默认: 原始字节
        if isinstance(value, (bytes, bytearray)):
            self._data = bytearray(value)
        else:
            self._data = bytearray(str(value).encode('utf-8'))

    def __repr__(self) -> str:
        try:
            val = self.content
        except Exception:
            val = self._data.hex()
        return f"BaseData(dtype=0x{self._dtype:04X}, value={val})"


# ===================== 辅助函数 =====================


def ip_to_int(ip_str: str) -> int:
    """
    将 IP 地址字符串转换为整数 (网络字节序)

    参数:
        ip_str: IP 地址字符串 (如 "192.168.1.1")

    返回:
        32位整数
    """
    parts = ip_str.split('.')
    if len(parts) != 4:
        raise ValueError(f"无效的 IP 地址: {ip_str}")
    result = 0
    for i, p in enumerate(parts):
        result |= int(p) << (i * 8)
    return result


def int_to_ip(ip_int: int) -> str:
    """
    将整数 (网络字节序) 转换为 IP 地址字符串

    参数:
        ip_int: 32位整数

    返回:
        IP 地址字符串
    """
    return f"{ip_int & 0xFF}.{(ip_int >> 8) & 0xFF}.{(ip_int >> 16) & 0xFF}.{(ip_int >> 24) & 0xFF}"


def mac_to_bytes(mac_str: str) -> bytes:
    """
    将 MAC 地址字符串转换为字节

    参数:
        mac_str: MAC 地址字符串 (如 "00:11:22:33:44:55")

    返回:
        6字节 bytes
    """
    parts = mac_str.replace('-', ':').split(':')
    if len(parts) != 6:
        raise ValueError(f"无效的 MAC 地址: {mac_str}")
    return bytes(int(p, 16) for p in parts)


def bytes_to_mac(mac_bytes: bytes) -> str:
    """
    将字节转换为 MAC 地址字符串

    参数:
        mac_bytes: 6字节

    返回:
        MAC 地址字符串
    """
    if len(mac_bytes) != 6:
        raise ValueError("MAC 地址必须为 6 字节")
    return ':'.join(f'{b:02x}' for b in mac_bytes)
