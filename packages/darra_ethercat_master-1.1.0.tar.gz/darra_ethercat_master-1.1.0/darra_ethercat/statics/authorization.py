# -*- coding: utf-8 -*-
"""
SDK 公开接口层 — 最小授权接口 (跟 C# 对齐)

设计:
- 只 2 个对外 API: Authorization.activate(code) + Authorization.license_status
- 激活 / HTTP / 解密 / 验签 / 完整性 / 时钟 / 过期检查全部在 native (Darra.Core.dll) 内静默完成
- SDK 不做密码学, 不做 HTTP, 只是 1 行 ctypes wrapper
- 内核 WSK 走驱动多 NIC 群发, 3s 超时 (内核态网络)
"""

import ctypes
import os
import platform
from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum
from typing import Optional, Tuple

from ..utils.dll import DarraCoreDLL


class LicenseStatus(IntEnum):
    """授权状态 — 镜像 native license_status_t (license_verify.h)"""
    NOT_VERIFIED = 0
    VERIFYING = 1
    VERIFIED = 2
    FAILED = 3
    EXPIRED = 4
    MACHINE_ID_MISMATCH = 5


@dataclass
class LicenseCertificate:
    """授权证书数据模型 (跟 C# LicenseCertificate 对齐)"""
    version: int = 0
    certificate_id: str = ""
    license_type: str = ""
    activation_code: str = ""
    machine_id: str = ""
    device_name: str = ""
    enterprise_id: Optional[str] = None
    enterprise_name: Optional[str] = None
    max_devices: Optional[int] = None
    issue_date: Optional[datetime] = None
    expiration_date: Optional[datetime] = None
    platform_name: str = ""
    library_version: str = ""
    core_version: str = ""
    system_version: str = ""
    library_hash: str = ""
    core_hash: str = ""
    signature: str = ""


class Authorization:
    """
    授权管理 — 最小接口 (跟 6 SDK 完全对齐)
    只 2 个对外 API: activate() + license_status
    """
    _dll: Optional[DarraCoreDLL] = None

    @classmethod
    def _get_dll(cls) -> Optional[DarraCoreDLL]:
        """惰性加载 DarraCoreDLL 单例"""
        if cls._dll is None:
            try:
                cls._dll = DarraCoreDLL()
            except Exception:
                pass
        return cls._dll

    @classmethod
    @property
    def license_status(cls) -> LicenseStatus:
        """
        授权状态: 证书文件存在 = 已激活. 真实有效性由 native 静默验证.
        """
        try:
            if os.path.exists(_get_license_file_path()):
                return LicenseStatus.VERIFIED
        except Exception:
            pass
        return LicenseStatus.NOT_VERIFIED

    @classmethod
    def activate(cls, activation_code: str) -> Tuple[bool, str]:
        """
        激活授权 — 1 行 P/Invoke 调用 native LicenseActivate.

        native 内部完成:
          - 激活码格式校验
          - 拿机器码 / 设备信息 / 版本
          - 组 HTTP 请求
          - IOCTL → 内核 WSK 同步发送 (走驱动多 NIC, 3s 超时)
          - parse 响应 + 落盘 + 自验
          - DRL2 → DRL1 在线交换 (个人版二次加密)

        参数:
            activation_code: 激活码 (12 位字母, 允许 - 或空格分隔)

        返回:
            (success, message)
        """
        dll = cls._get_dll()
        if dll is None:
            return (False, "DLL 加载失败")
        try:
            err_buf = ctypes.create_string_buffer(512)
            code = dll.LicenseActivate(
                (activation_code or "").encode("utf-8"),
                err_buf,
                512,
            )
            msg = err_buf.value.decode("utf-8", errors="replace")
            return (code == 0, msg if msg else ("激活成功" if code == 0 else "激活失败"))
        except Exception as ex:
            return (False, f"激活异常: {ex}")


# ===================== 模块级辅助函数 (跟授权无关, 供 __init__.py re-export) =====================


def is_running_as_admin() -> bool:
    """检查当前是否以管理员权限运行"""
    if platform.system() == 'Windows':
        try:
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except Exception:
            return False
    try:
        return os.geteuid() == 0
    except AttributeError:
        return False


def get_device_name() -> str:
    """获取设备名称 (主机名)"""
    return platform.node()


def get_system_version() -> str:
    """获取系统版本"""
    return f"{platform.system()} {platform.release()} {platform.version()}"


# ===================== 内部辅助 =====================


def _get_license_file_path() -> str:
    """证书文件路径 (跟 native license_get_file_path 对齐: System32\\config\\DKEY)"""
    if platform.system() == 'Windows':
        win_dir = os.environ.get('SystemRoot', r'C:\Windows')
        return os.path.join(win_dir, 'System32', 'config', 'DKEY')
    return '/etc/darra/DKEY'
