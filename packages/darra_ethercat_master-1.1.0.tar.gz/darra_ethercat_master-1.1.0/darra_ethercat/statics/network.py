# -*- coding: utf-8 -*-
"""
网络信息与扫描结果
对应 C# Static/Network.cs
提供网络适配器信息和从站扫描结果数据类
"""

import ctypes
from ctypes import c_int, c_uint, c_ushort, c_ubyte, c_char_p, c_bool, byref, POINTER, c_void_p
from dataclasses import dataclass, field
from typing import Optional, List

from ..utils.dll import DarraCoreDLL


# ===================== 网络适配器信息 =====================

@dataclass
class NetworkInfo:
    """
    网络适配器信息
    对应 C# NetworkInfo 类
    """
    name: str = ""
    """pcap 适配器名称"""
    desc: str = ""
    """适配器描述"""
    mac: str = ""
    """MAC 地址 (格式: aa:bb:cc:dd:ee:ff)"""
    slave_num: Optional[int] = None
    """从站总数量 (需 need_slaves_num=True 时有值)"""
    redundant_slave_num: Optional[int] = None
    """受冗余保护的从站数量 (需 need_slaves_num=True 时有值)"""

    def __str__(self) -> str:
        parts = [f"{self.desc} [{self.name}]"]
        if self.mac:
            parts.append(f"MAC={self.mac}")
        if self.slave_num is not None:
            parts.append(f"从站={self.slave_num}")
        return " ".join(parts)


# ===================== 扫描从站信息 =====================

@dataclass
class ScannedSlaveInfo:
    """
    扫描到的从站基本信息
    对应 C# ScannedSlaveInfo 类
    """
    index: int = 0
    """从站索引 (1-based)"""
    name: str = ""
    """从站名称"""
    vendor_id: int = 0
    """厂商 ID"""
    product_code: int = 0
    """产品代码"""
    revision_number: int = 0
    """修订号"""
    serial_number: int = 0
    """序列号"""
    config_addr: int = 0
    """物理配置地址"""
    alias_addr: int = 0
    """别名地址"""
    parent_index: int = 0
    """父从站索引 (0=主站是父节点)"""
    topology: int = 0
    """拓扑类型: 0=无链接, 1=端点, 2=中间节点, 3=分支点, 4=交叉点"""
    active_ports: int = 0
    """活动端口位图"""
    entry_port: int = 0
    """入口端口"""
    parent_port: int = 0
    """父从站上的端口号"""
    physical_type: int = 0
    """物理端口类型寄存器 (0x0007)"""
    depth: int = 0
    """拓扑深度"""
    parent_port_type: int = 0
    """父端口物理类型"""

    def get_port_type(self, port: int) -> int:
        """获取指定端口的物理类型 (0=未实现, 1=未配置, 2=EBUS, 3=MII)"""
        return (self.physical_type >> (port * 2)) & 0x03

    @property
    def entry_port_type(self) -> int:
        """入口端口的物理类型"""
        return self.get_port_type(self.entry_port)

    @property
    def device_type(self) -> str:
        """设备类型描述"""
        PTYPE_EBUS = 2
        PTYPE_MII = 3
        ports = [self.get_port_type(i) for i in range(4)]
        ebus_count = sum(1 for p in ports if p == PTYPE_EBUS)
        mii_count = sum(1 for p in ports if p == PTYPE_MII)

        if ebus_count == 0 and mii_count >= 1:
            return "Box"
        elif ports[0] == PTYPE_MII and ebus_count >= 1:
            return "Coupler"
        elif ports[0] == PTYPE_EBUS and ports[1] == PTYPE_MII:
            return "Extension"
        elif ebus_count >= 2 and mii_count == 0:
            return "Terminal"
        else:
            return "Device"

    @property
    def is_coupler(self) -> bool:
        """是否为耦合器 (保守判断)"""
        if self.topology < 3:
            return False
        if self.name:
            name_lower = self.name.lower()
            if any(kw in name_lower for kw in
                   ["coupler", "junction", "hub", "splitter", "gateway"]):
                return True
            if self.name.upper().startswith("EK") and len(self.name) >= 6:
                return True
        return self.device_type == "Coupler"

    @property
    def alias_addr_hex(self) -> str:
        """别名地址的十六进制字符串 (对应 C# AliasAddrHex)"""
        return f"0x{self.alias_addr:04X}"

    @property
    def vendor_id_hex(self) -> str:
        """厂商ID十六进制 (对应 C# VendorIdHex)"""
        return f"0x{self.vendor_id:08X}"

    @property
    def product_code_hex(self) -> str:
        return f"0x{self.product_code:X}"

    @property
    def revision_number_hex(self) -> str:
        return f"0x{self.revision_number:X}"

    @property
    def config_addr_hex(self) -> str:
        return f"0x{self.config_addr:X}"

    @property
    def parent_key(self) -> Optional[int]:
        """父节点键 (None 表示根节点)"""
        return self.parent_index if self.parent_index > 0 else None

    @staticmethod
    def get_port_type_string(port_type: int) -> str:
        """获取端口类型字符串"""
        return {0: "N/A", 1: "NC", 2: "EBUS", 3: "MII"}.get(port_type, "?")

    def __str__(self) -> str:
        return (f"[{self.index}] {self.name} "
                f"VID=0x{self.vendor_id:08X} PID=0x{self.product_code:08X} "
                f"Type={self.device_type}")


# ===================== 网络扫描工具函数 =====================

def get_network_info(dll: DarraCoreDLL,
                     is_redundant: bool = False,
                     need_slaves_num: bool = False) -> List[NetworkInfo]:
    """
    获取网络适配器信息列表

    参数:
        dll: DarraCoreDLL 实例
        is_redundant: 是否启用冗余模式
        need_slaves_num: 是否扫描从站数量 (扫描较慢)

    返回:
        NetworkInfo 列表
    """
    count = dll.GetNetworkInfo(is_redundant, need_slaves_num)
    ptr = dll.GetNetworksPointer()
    if not ptr or count <= 0:
        return []

    # ec_networkInfo 结构体大小 (C/C# 一致, pack=1):
    # name[128] + desc[128] + slaveNum(int16) + redundantSlaveNum(int16) = 260 字节
    struct_size = 128 + 128 + 2 + 2
    results = []
    for i in range(count):
        offset = ptr + i * struct_size
        raw = ctypes.string_at(offset, struct_size)
        # 解析名称
        name_bytes = raw[:128]
        desc_bytes = raw[128:256]
        # 查找 null 终止符
        name_end = name_bytes.find(b'\x00')
        desc_end = desc_bytes.find(b'\x00')
        name = name_bytes[:name_end].decode('utf-8', errors='replace') if name_end >= 0 else ""
        desc = desc_bytes[:desc_end].decode('utf-8', errors='replace') if desc_end >= 0 else ""
        # 解析从站数 (int16, 与 C/C# 对齐)
        import struct
        slave_num_val = struct.unpack_from('<h', raw, 256)[0]
        red_slave_num_val = struct.unpack_from('<h', raw, 258)[0]

        info = NetworkInfo(
            name=name,
            desc=desc,
            slave_num=slave_num_val if need_slaves_num else None,
            redundant_slave_num=red_slave_num_val if need_slaves_num and red_slave_num_val > 0 else None,
        )
        results.append(info)

    return results


def scan_slaves(dll: DarraCoreDLL, adapter_name: str,
                secondary_adapter: Optional[str] = None) -> List[ScannedSlaveInfo]:
    """
    一键扫描从站并返回详细信息列表

    参数:
        dll: DarraCoreDLL 实例
        adapter_name: 主网络适配器名称
        secondary_adapter: 冗余网络适配器名称 (可选)

    返回:
        ScannedSlaveInfo 列表
    """
    adapter_bytes = adapter_name.encode('utf-8')

    if secondary_adapter:
        count = dll.ScanSlaveCountRedundant(
            adapter_bytes, secondary_adapter.encode('utf-8'))
    else:
        count = dll.ScanSlaveCount(adapter_bytes)

    if count <= 0:
        return []

    return _get_scanned_slaves(dll)


def _get_scanned_slaves(dll: DarraCoreDLL) -> List[ScannedSlaveInfo]:
    """内部: 读取扫描结果"""
    count = dll.GetScannedSlaveCount()
    results = []

    for i in range(count):
        vendor_id = c_uint(0)
        product_code = c_uint(0)
        revision = c_uint(0)
        serial = c_uint(0)
        name_buf = ctypes.create_string_buffer(256)
        config_addr = c_ushort(0)
        alias_addr = c_ushort(0)
        parent = c_ushort(0)
        topo = c_ubyte(0)
        active = c_ubyte(0)
        entry = c_ubyte(0)
        parent_port = c_ubyte(0)
        ptype = c_ubyte(0)

        ok = dll.GetScannedSlaveInfo(
            i, byref(vendor_id), byref(product_code),
            byref(revision), byref(serial),
            name_buf, 256,
            byref(config_addr), byref(alias_addr),
            byref(parent), byref(topo), byref(active),
            byref(entry), byref(parent_port), byref(ptype))

        if ok:
            name = name_buf.value.decode('utf-8', errors='replace')
            info = ScannedSlaveInfo(
                index=i + 1,
                name=name,
                vendor_id=vendor_id.value,
                product_code=product_code.value,
                revision_number=revision.value,
                serial_number=serial.value,
                config_addr=config_addr.value,
                alias_addr=alias_addr.value,
                parent_index=parent.value,
                topology=topo.value,
                active_ports=active.value,
                entry_port=entry.value,
                parent_port=parent_port.value,
                physical_type=ptype.value,
            )
            results.append(info)

    # 计算拓扑深度
    _calculate_depth(results)
    return results


def abort_scan(dll: DarraCoreDLL):
    """
    中止当前正在进行的从站扫描

    参数:
        dll: DarraCoreDLL 实例
    """
    if hasattr(dll, 'AbortScan'):
        dll.AbortScan()


def reset_scan_abort(dll: DarraCoreDLL):
    """
    重置扫描中止标志 (下次扫描前调用)

    参数:
        dll: DarraCoreDLL 实例
    """
    if hasattr(dll, 'ResetScanAbort'):
        dll.ResetScanAbort()


def quick_slave_count(dll: DarraCoreDLL, adapter_name: str) -> int:
    """
    快速探测网卡上的从站数量 (不读取详细信息)

    参数:
        dll: DarraCoreDLL 实例
        adapter_name: 网络适配器名称

    返回:
        从站数量
    """
    return dll.QuickSlaveCount(adapter_name.encode('utf-8'))


def quick_slave_count_redundant(dll: DarraCoreDLL, primary_adapter: str,
                                 secondary_adapter: str) -> int:
    """
    快速探测冗余网络上的从站数量

    参数:
        dll: DarraCoreDLL 实例
        primary_adapter: 主网络适配器名称
        secondary_adapter: 冗余网络适配器名称

    返回:
        从站数量
    """
    if hasattr(dll, 'QuickSlaveCountRedundant'):
        return dll.QuickSlaveCountRedundant(
            primary_adapter.encode('utf-8'),
            secondary_adapter.encode('utf-8')
        )
    return 0


def quick_find_redundant_pair_batch(dll: DarraCoreDLL,
                                     adapters: List[str]) -> tuple:
    """
    批量查找冗余网卡对 (O(N) 复杂度, 对齐 C# QuickFindRedundantPairBatch)

    参数:
        dll: DarraCoreDLL 实例
        adapters: 网络适配器名称列表

    返回:
        (slave_count, primary_idx, secondary_idx, ring_count, total_count)
        slave_count: 返回值 (成功>0)
        primary_idx: 主适配器索引 (-1=未找到)
        secondary_idx: 副适配器索引 (-1=未找到)
        ring_count: 环上从站数
        total_count: 总从站数 (含分支)
    """
    if not adapters or len(adapters) < 2:
        return (0, -1, -1, 0, 0)

    if not hasattr(dll, 'QuickFindRedundantPairBatch'):
        return (0, -1, -1, 0, 0)

    # 构建 C 字符串数组
    c_names = (ctypes.c_char_p * len(adapters))()
    for i, name in enumerate(adapters):
        c_names[i] = name.encode('utf-8')

    primary_idx = ctypes.c_int(-1)
    secondary_idx = ctypes.c_int(-1)
    ring_count = ctypes.c_int(0)
    total_count = ctypes.c_int(0)

    slave_count = dll.QuickFindRedundantPairBatch(
        c_names, len(adapters),
        ctypes.byref(primary_idx), ctypes.byref(secondary_idx),
        ctypes.byref(ring_count), ctypes.byref(total_count))

    return (slave_count, primary_idx.value, secondary_idx.value,
            ring_count.value, total_count.value)


def get_ring_slave_count(dll: DarraCoreDLL, adapter_name: str) -> int:
    """
    获取环形拓扑中从站数量

    参数:
        dll: DarraCoreDLL 实例
        adapter_name: 网络适配器名称

    返回:
        环形拓扑中从站数量, 不支持时返回 0
    """
    if hasattr(dll, 'GetRingSlaveCount'):
        return dll.GetRingSlaveCount(adapter_name.encode('utf-8'))
    return 0


# ===================== 拓扑信息 =====================

@dataclass
class TopologyInfo:
    """
    网络拓扑信息
    对应 C# TopologyInfo 类
    """
    slave_count: int = 0
    """从站总数"""
    coupler_count: int = 0
    """耦合器数量"""
    terminal_count: int = 0
    """终端数量"""
    has_ring: bool = False
    """是否包含环形拓扑"""
    max_depth: int = 0
    """最大拓扑深度"""
    topology_type: str = ""
    """拓扑类型描述 (线性/树形/环形)"""

    @staticmethod
    def from_slaves(slaves: List[ScannedSlaveInfo]) -> 'TopologyInfo':
        """
        从扫描结果构建拓扑信息

        参数:
            slaves: 扫描到的从站列表

        返回:
            TopologyInfo 实例
        """
        info = TopologyInfo()
        info.slave_count = len(slaves)

        for s in slaves:
            if s.is_coupler:
                info.coupler_count += 1
            else:
                info.terminal_count += 1
            if s.depth > info.max_depth:
                info.max_depth = s.depth
            # 拓扑类型 >= 3 (分支/交叉) 说明有分支
            if s.topology >= 4:
                info.has_ring = True

        # 判断拓扑类型
        if info.has_ring:
            info.topology_type = "环形"
        elif info.coupler_count > 1:
            info.topology_type = "树形"
        else:
            info.topology_type = "线性"

        return info

    def __str__(self) -> str:
        return (f"拓扑: {self.topology_type}, "
                f"从站={self.slave_count}, 耦合器={self.coupler_count}, "
                f"终端={self.terminal_count}, 深度={self.max_depth}")


def determine_coupler_status(slaves: List[ScannedSlaveInfo]) -> List[dict]:
    """
    检测 EtherCAT 耦合器状态 (对应 C# DetermineCouplerStatus)

    遍历从站列表, 识别耦合器并检查其下挂终端是否正常在线。
    通过从站拓扑类型和端口物理类型判断耦合器身份。

    参数:
        slaves: 扫描到的从站列表

    返回:
        耦合器状态列表 [{'index': int, 'name': str, 'is_coupler': bool,
                          'child_count': int, 'device_type': str}, ...]
    """
    slave_dict = {s.index: s for s in slaves}
    results = []
    for s in slaves:
        if not s.is_coupler:
            continue
        # 统计该耦合器下挂的子模块数量
        child_count = sum(1 for c in slaves if c.parent_index == s.index)
        results.append({
            'index': s.index,
            'name': s.name,
            'is_coupler': True,
            'child_count': child_count,
            'device_type': s.device_type,
        })
    return results


def _calculate_depth(slaves: List[ScannedSlaveInfo]):
    """计算拓扑深度"""
    PTYPE_EBUS = 2
    slave_dict = {s.index: s for s in slaves}

    for slave in slaves:
        # 计算父端口类型
        if slave.parent_index > 0 and slave.parent_index in slave_dict:
            parent = slave_dict[slave.parent_index]
            slave.parent_port_type = parent.get_port_type(slave.parent_port)

        # 深度计算
        if slave.parent_index == 0:
            slave.depth = 0
        else:
            entry_type = slave.get_port_type(slave.entry_port)
            slave.depth = 1 if entry_type == PTYPE_EBUS else 0
