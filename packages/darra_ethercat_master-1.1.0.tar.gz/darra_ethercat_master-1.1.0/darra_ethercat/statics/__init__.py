# -*- coding: utf-8 -*-
"""
静态工具模块
包含网络信息、打印辅助、版本信息、设备信息、授权等静态方法
"""

from .network import (
    NetworkInfo, ScannedSlaveInfo, TopologyInfo,
    get_network_info, scan_slaves,
    abort_scan, reset_scan_abort,
    quick_slave_count, quick_slave_count_redundant,
    quick_find_redundant_pair_batch, get_ring_slave_count,
)

from .print import (
    describe_state, describe_al_status, describe_link_state,
    describe_object_access, describe_access_chinese,
    describe_transition, describe_dc_mode, describe_redundancy_mode,
    describe_al_status_en, describe_al_status_full,
    describe_sdo_error, describe_soe_error,
    describe_mailbox_error, describe_mailbox_type,
    describe_data_type, describe_data_type_common,
    describe_write_condition, describe_access_with_state,
    describe_link_state_en,
)

from .version_info import (
    get_dll_version, get_api_version, get_build_number,
    get_serial_number, get_build_date,
)

from .device_info import get_device_serial_number

from .other import (
    initialize_logging, enable_pdo_logging,
    enable_mailbox_logging, enable_debug_logging,
)

from .authorization import (
    LicenseStatus, is_running_as_admin,
    get_device_name, get_system_version,
)

from .protocol_codes import ProtocolCodes
