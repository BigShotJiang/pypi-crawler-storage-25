# -*- coding: utf-8 -*-
"""
对应 C# 文件: Static/DeviceInfo.cs
设备信息获取

包含:
- get_serial_number: 获取设备序列号
"""

from ..utils.dll import DarraCoreDLL


def get_device_serial_number(dll: DarraCoreDLL) -> str:
    """
    获取设备序列号

    参数:
        dll: DLL 接口

    返回:
        设备序列号字符串
    """
    try:
        return dll.GetSerialNumber() or ""
    except Exception:
        return ""
