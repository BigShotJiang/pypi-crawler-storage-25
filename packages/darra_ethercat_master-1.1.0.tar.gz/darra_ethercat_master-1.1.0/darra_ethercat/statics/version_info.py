# -*- coding: utf-8 -*-
"""
版本信息
对应 C# Static/VersionInfo.cs
提供 DLL 和 SDK 版本查询
"""

from typing import Optional, Tuple

from ..utils.dll import DarraCoreDLL, DllVersionInfo


def get_serial_number(dll: DarraCoreDLL) -> str:
    """
    获取设备序列号
    对应 C# DeviceInfo.GetSerialNumber()

    参数:
        dll: DarraCoreDLL 实例

    返回:
        序列号字符串, 失败返回空字符串
    """
    try:
        if hasattr(dll, 'GetSerialNumber'):
            ptr = dll.GetSerialNumber()
            if ptr:
                import ctypes
                return ctypes.string_at(ptr).decode('utf-8', errors='replace')
        return ""
    except Exception:
        return ""


def get_dll_version(dll: DarraCoreDLL) -> Optional[dict]:
    """
    获取 DLL 版本信息

    参数:
        dll: DarraCoreDLL 实例

    返回:
        版本信息字典 {'major', 'minor', 'build', 'version', 'build_date'}
        失败返回 None
    """
    try:
        ptr = dll.GetDllVersionInfo()
        if not ptr:
            return None

        import ctypes
        info = ctypes.cast(ptr, ctypes.POINTER(DllVersionInfo)).contents
        return {
            'major': info.major,
            'minor': info.minor,
            'build': info.build,
            'version': f"{info.major}.{info.minor}.{info.build}",
        }
    except Exception:
        return None


def get_api_version() -> str:
    """
    获取 Python SDK API 版本

    返回:
        版本字符串 (从 VERSION 文件读取)
    """
    import os
    version_file = os.path.join(os.path.dirname(__file__), "VERSION")
    try:
        with open(version_file, "r", encoding="utf-8") as f:
            return f.read().strip()
    except FileNotFoundError:
        return "0.0.0"


def get_build_number(dll: DarraCoreDLL) -> int:
    """
    获取 DLL 构建号

    参数:
        dll: DarraCoreDLL 实例

    返回:
        构建号, 失败返回 -1
    """
    info = get_dll_version(dll)
    if info:
        return info.get('build', -1)
    return -1


def get_build_date(dll: DarraCoreDLL) -> str:
    """
    获取 DLL 构建日期

    参数:
        dll: DarraCoreDLL 实例

    返回:
        构建日期字符串, 失败返回空字符串
    """
    try:
        ptr = dll.GetDllVersionInfo()
        if not ptr:
            return ""

        import ctypes
        info = ctypes.cast(ptr, ctypes.POINTER(DllVersionInfo)).contents
        # DllVersionInfo 结构体可能包含 build_date 字段
        if hasattr(info, 'build_date'):
            raw = info.build_date
            if isinstance(raw, bytes):
                return raw.decode('utf-8', errors='replace').strip('\x00')
            return str(raw)
        return ""
    except Exception:
        return ""
