# -*- coding: utf-8 -*-
"""
对应 C# 文件: Static/Other.cs
静态辅助方法

包含:
- initialize_logging: 初始化日志系统
- enable_pdo_logging: 启用 PDO 日志
- enable_mailbox_logging: 启用邮箱日志
- enable_debug_logging: 启用调试日志
"""

from ..utils.dll import DarraCoreDLL


def initialize_logging(dll: DarraCoreDLL) -> None:
    """初始化 DLL 日志系统"""
    try:
        dll.InitLogging()
    except Exception:
        pass


def enable_pdo_logging(dll: DarraCoreDLL, enable: bool = True) -> None:
    """启用/禁用 PDO 日志"""
    try:
        dll.EnablePDOLogging(enable)
    except Exception:
        pass


def enable_mailbox_logging(dll: DarraCoreDLL, enable: bool = True) -> None:
    """启用/禁用邮箱日志"""
    try:
        dll.EnableMailboxLogging(enable)
    except Exception:
        pass


def enable_debug_logging(dll: DarraCoreDLL, enable: bool = True) -> None:
    """启用/禁用调试日志"""
    try:
        dll.EnableDebugLogging(enable)
    except Exception:
        pass
