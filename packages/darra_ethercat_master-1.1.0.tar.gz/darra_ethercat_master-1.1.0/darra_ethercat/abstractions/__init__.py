# -*- coding: utf-8 -*-
"""对齐 C# Abstractions 的 Python SDK 抽象层."""
from .mailbox_status import MailboxStatus
from .mailbox_statistics import MailboxStatistics
from .mailbox_protocol import IMailboxProtocol
from .mailbox_exception import (
    MailboxException, MailboxTimeoutException, MailboxCancelledException,
    CoEAbortException, FoEProtocolException, SoEProtocolException,
    AoEProtocolException, EoEProtocolException, VoEProtocolException,
    FSoEProtocolException,
)

__all__ = [
    "MailboxStatus", "MailboxStatistics", "IMailboxProtocol",
    "MailboxException", "MailboxTimeoutException", "MailboxCancelledException",
    "CoEAbortException", "FoEProtocolException", "SoEProtocolException",
    "AoEProtocolException", "EoEProtocolException", "VoEProtocolException",
    "FSoEProtocolException",
]
