# -*- coding: utf-8 -*-
"""邮箱协议异常体系 (对齐 C# MailboxException/*)."""
from .mailbox_status import MailboxStatus


class MailboxException(Exception):
    """邮箱事务异常基类"""

    def __init__(self, slave_index: int, protocol_type: int,
                 status: MailboxStatus, error_code: int, message: str):
        super().__init__(message)
        self.slave_index = slave_index
        self.protocol_type = protocol_type
        self.status = status
        self.error_code = error_code


class MailboxTimeoutException(MailboxException):
    """邮箱事务超时"""

    def __init__(self, slave, proto, msg):
        super().__init__(slave, proto, MailboxStatus.TIMEOUT, 0, msg)


class MailboxCancelledException(MailboxException):
    """邮箱事务被取消"""

    def __init__(self, slave, proto):
        super().__init__(slave, proto, MailboxStatus.CANCELLED, 0,
                         "Mailbox transaction cancelled")


class CoEAbortException(MailboxException):
    """CoE SDO Abort"""

    def __init__(self, slave, abort_code, msg):
        super().__init__(slave, 0x03, MailboxStatus.MAILBOX_ERROR, abort_code, msg)


class FoEProtocolException(MailboxException):
    """FoE 协议错误"""

    def __init__(self, slave, err, msg):
        super().__init__(slave, 0x04, MailboxStatus.MAILBOX_ERROR, err, msg)


class SoEProtocolException(MailboxException):
    """SoE 协议错误"""

    def __init__(self, slave, err, msg):
        super().__init__(slave, 0x05, MailboxStatus.MAILBOX_ERROR, err, msg)


class AoEProtocolException(MailboxException):
    """AoE 协议错误"""

    def __init__(self, slave, err, msg):
        super().__init__(slave, 0x01, MailboxStatus.MAILBOX_ERROR, err, msg)


class EoEProtocolException(MailboxException):
    """EoE 协议错误"""

    def __init__(self, slave, err, msg):
        super().__init__(slave, 0x02, MailboxStatus.MAILBOX_ERROR, err, msg)


class VoEProtocolException(MailboxException):
    """VoE 协议错误"""

    def __init__(self, slave, err, msg):
        super().__init__(slave, 0x0F, MailboxStatus.MAILBOX_ERROR, err, msg)


class FSoEProtocolException(MailboxException):
    """FSoE 协议错误"""

    def __init__(self, slave, err, msg):
        super().__init__(slave, 0x08, MailboxStatus.MAILBOX_ERROR, err, msg)
