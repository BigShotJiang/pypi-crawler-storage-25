# -*- coding: utf-8 -*-
"""邮箱事务状态枚举 (对齐 C 层 ec_mbx_status_t)."""
from enum import IntEnum


class MailboxStatus(IntEnum):
    """邮箱事务状态 (对齐 C 层 ec_mbx_status_t)"""
    PENDING = 0
    SUCCESS = 1
    TIMEOUT = -1
    CANCELLED = -2
    MAILBOX_ERROR = -3
    PROTO_MISMATCH = -4
    COUNTER_FAIL = -5
    WKC_FAIL = -6
    NO_MEMORY = -7
    INVALID_ARG = -8
    NOT_IMPLEMENTED = -9
