# -*- coding: utf-8 -*-
"""邮箱统计快照 (对齐 C# MailboxStatistics)."""
from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass(frozen=True)
class MailboxStatistics:
    """邮箱统计快照 (对齐 C# MailboxStatistics)"""
    total_sent: int = 0
    total_received: int = 0
    total_timeout: int = 0
    total_mailbox_error: int = 0
    total_protocol_error: int = 0
    total_cancelled: int = 0
    last_error_code: int = 0
    last_error_time: Optional[datetime] = None
    average_latency_us: float = 0.0

    @classmethod
    def empty(cls) -> "MailboxStatistics":
        """返回空统计快照"""
        return cls()
