# -*- coding: utf-8 -*-
"""邮箱协议统一接口 (对齐 C# IMailboxProtocol)."""
from abc import ABC, abstractmethod

from .mailbox_statistics import MailboxStatistics
from .mailbox_status import MailboxStatus


class IMailboxProtocol(ABC):
    """邮箱协议统一接口 (对齐 C# IMailboxProtocol)"""

    @property
    @abstractmethod
    def protocol_type(self) -> int:
        """ECT_MBXT_* 位 (CoE=3, FoE=4, SoE=5, AoE=1, EoE=2, VoE=0x0F, FSoE=8)"""
        pass

    @property
    @abstractmethod
    def protocol_name(self) -> str:
        """协议名称"""
        pass

    @property
    @abstractmethod
    def is_supported(self) -> bool:
        """从站是否支持该邮箱协议"""
        pass

    @property
    def last_status(self) -> MailboxStatus:
        """最近一次事务状态 (默认 PENDING)"""
        return getattr(self, "_last_status", MailboxStatus.PENDING)

    @property
    def last_error_code(self) -> int:
        """最近一次错误码"""
        return getattr(self, "_last_error_code", 0)

    @property
    @abstractmethod
    def statistics(self) -> MailboxStatistics:
        """邮箱统计快照"""
        pass

    @abstractmethod
    def reset_statistics(self) -> None:
        """重置统计计数"""
        pass
