# -*- coding: utf-8 -*-
"""
DarraEtherCAT Python SDK
========================

基于 ctypes 封装 Darra.Core.dll 的 Python SDK。
提供与 C# 类库结构一致的 Pythonic 接口。

基本用法::

    from darra_ethercat import EtherCATMaster, EcState

    with EtherCATMaster() as master:
        master.set_network("\\\\Device\\\\NPF_{GUID}")
        master.set_state_sequence(EcState.OP)
        master.start()

        # 访问从站
        slave = master[1]
        value = slave.coe.sdo_read_value(0x6041, 0, dtype='u16')

一步初始化::

    with EtherCATMaster.from_json(config) as master:
        ...
"""

# 从 VERSION 文件读取版本号
import os as _os
_version_file = _os.path.join(_os.path.dirname(__file__), "VERSION")
try:
    with open(_version_file, "r", encoding="utf-8") as _f:
        __version__ = _f.read().strip()
except FileNotFoundError:
    __version__ = "0.0.0"
del _os, _version_file

# ---- 底层 DLL 接口与基础类型 (utils/dll.py) ----
from .utils.dll import (
    # 枚举
    EcState,
    EcLinkState,
    RingMode,
    EcErr,
    CiA402State,
    FsoEState,
    FsoEError,
    # 结构体
    DllVersionInfo,
    SlaveIdentity,
    SlaveEsmTimeouts,
    WatchdogConfig,
    WatchdogStatus,
    MasterIdentity,
    MasterDiagData,
    StartupParam,
    FoEOptions,
    EmcyRecord,
    TopologyNode,
    RedundancyStatus,
    CommunicationStats,
    EscPortErrorStats,
    FsoEConfig,
    FsoEStatus,
    FsoEMdpConfig,
    # 启动参数常量
    TRANS_IP, TRANS_PS, TRANS_SO, TRANS_OS, TRANS_SP, TRANS_PI,
    TIMING_BEFORE, TIMING_AFTER,
    # 底层 DLL 接口
    DarraCoreDLL,
)

# ---- 从站类 (slave/core.py) ----
from .slave.core import Slave, CoE, SoE, FoE, EoE, AoE, VoE, VoEResponse, FSoE, CiA402, ModeCiA402

# ---- 主站类 (master/core.py) ----
from .master.core import EtherCATMaster, ValidationResult

# ---- CiA 401 I/O 模块 (slave/cia401.py) ----
from .slave.cia401 import CiA401, CiA401ErrorMode

# ---- 主站配置 (master/config.py) ----
from .master.config import MasterConfig, ScanRevisionMatchMode, MailboxConfig

# ---- ETG.1510 主站对象字典 (master/master_od.py) ----
from .master.master_od import MasterObjectDictionary

# ---- ETG.8200 Mailbox Gateway (master/mailbox_gateway.py) ----
from .master.mailbox_gateway import MailboxGatewayService

# ---- ESI 加载器 (slave/esi.py) ----
from .slave.esi import EsiLoader, EsiStartupParam, EsiDeviceInfo

# ---- 类型定义 (data/types.py) ----
from .data.types import (
    EcBufState, EcCmdType, EcEcmdType, LogLevel,
    EcALState, ALErrorCategory, classify_al_error,
    MailboxError, MailboxType, SDOError, SoEError,
    EcCommType, EcPortType, EcTopologyType, EcPdiType,
    EcDeviceType, EcSyncManagerType, EcFmmuType,
    EcCoEDetails, EcEoEDetails,
    DcSyncMode, StartupTransition, StartupWriteTiming,
    CoEObjectAccess, EsmTimeouts,
    SlaveErrorCounters, DiagnosticMessage,
    # 状态格式化
    EcStateFormat,
)

# ---- 诊断信息 (master/diagnostics.py) ----
from .master.diagnostics import MasterDiagnosticsInfo, MasterPDODiagnostics, PDOFrameLossStats, DiagnosticsSnapshot

# ---- 日志管理 (logging/logging.py) ----
from .logging.logging import LogManager, LogCategory, LogEntry, LogView

# ---- 高级功能 (各独立模块) ----
from .slave.coe import EcDataType, ObjAccess, ObjectEntry, ObjectDictionary, ODList
from .slave.cia402 import CiA402Advanced, StateCiA402, ModeCiA402, parse_cia402_state
from .slave.soe import SoEAdvanced
from .slave.fsoe import FSoEMdp, FSoEManager, fsoe_crc16, fsoe_crc16_fast
from .slave.mdp import MdpModule, MdpSlotInfo, MdpModulePdoInfo, MdpDiscovery
from .slave.eoe import EoEPinger
from .slave.aoe import AoESubscription, AoESubscriptionManager
from .slave.pdo import PDOWatcher, PDOMonitor

# ---- 事件系统 (master/events.py) ----
from .master.events import SlaveEvents, MasterEvents, SlaveIdentityMismatchEventArgs

# ---- 从站诊断 (slave/slave_stats.py) ----
from .slave.slave_stats import EscPortErrors, SyncWindowStatus, SlaveDCDiagnostics, SlaveDiagnostics

# ---- 启动参数管理 (slave/startup.py) ----
from .slave.startup import StartupParameter, StartupParameterList

# ---- 网络信息 (statics/network.py) ----
from .statics.network import (
    NetworkInfo, ScannedSlaveInfo, TopologyInfo,
    get_network_info, scan_slaves,
    abort_scan, reset_scan_abort,
    quick_slave_count, quick_slave_count_redundant,
    quick_find_redundant_pair_batch, get_ring_slave_count,
)

# ---- 版本信息 (statics/version_info.py) ----
from .statics.version_info import get_dll_version, get_api_version, get_build_number, get_serial_number, get_build_date

# ---- 基础数据 (utils/base_data.py) ----
from .utils.base_data import (
    EC_MAX_SLAVE, EC_MAX_GROUP, EC_MAX_MAILBOX_SIZE, EC_MAX_SDO_SIZE,
    EC_MAX_EEPROM_SIZE, EC_MAX_NAME, EC_MAX_PORTS, EC_MAX_FMMU, EC_MAX_SM,
    ip_to_int, int_to_ip, mac_to_bytes, bytes_to_mac,
    BaseData,
)

# ---- 枚举描述辅助 (statics/print.py) ----
from .statics.print import (
    describe_state, describe_al_status, describe_link_state,
    describe_object_access, describe_access_chinese,
    describe_transition, describe_dc_mode, describe_redundancy_mode,
    # 英文/双语/协议错误描述
    describe_al_status_en, describe_al_status_full,
    describe_sdo_error, describe_soe_error,
    describe_mailbox_error, describe_mailbox_type,
    describe_data_type, describe_data_type_common,
    describe_write_condition, describe_access_with_state,
    describe_link_state_en,
)

# ---- 启动配置验证 (utils/startup_verifier.py) ----
from .utils.startup_verifier import (
    ExpectedSlaveConfig, SlaveVerifyDetail, VerificationResult,
    verify_configuration, verify_configuration_detailed,
    create_expected_configs_from_dict,
    create_expected_configs_from_xml, verify_configuration_with_dll,
)

# ---- 拓扑管理 (slave/topology.py) ----
from .slave.topology import SlaveTopology

# ---- 新增: CoE EMCY 历史 (slave/coe_emcy.py) ----
from .slave.coe_emcy import EmergencyMessage, CoEEmcyRecorder

# ---- 新增: SoE 扩展类型 (slave/soe.py) ----
from .slave.soe import SoEParameter, SoEAttributes, SoEDataType, SoENotificationEventArgs

# ---- 新增: DC 配置 (slave/dc.py) ----
from .slave.dc import DcConfig

# ---- 新增: 从站 PDO 数据访问 (slave/slave_pdo.py) ----
from .slave.slave_pdo import SlavePdo

# ---- 新增: 冗余管理 (master/redundancy.py) ----
from .master.redundancy import RedundancyState, RedundancyStatusInfo, RedundancyManager

# ---- 新增: 主站附加功能 (master/other.py) ----
from .master.other import SlaveDiagnosticsData

# ---- 新增: 诊断扩展 (master/diagnostics_info.py) ----
from .master.diagnostics_info import BreakPointInfo

# ---- 新增: 授权辅助 (statics/authorization.py) ----
from .statics.authorization import LicenseStatus, is_running_as_admin

# ---- 新增: XML 配置 (utils/xml.py) ----
# 注: save_xml_configuration 已移除 - DENI 导出为 Darra 主界面/PLC 中间层内部功能
from .utils.xml import MasterXMLConfiguration, load_xml_configuration

__all__ = [
    # 主要类
    'EtherCATMaster',
    'Slave',
    # 协议类
    'CoE', 'SoE', 'FoE', 'EoE', 'AoE', 'VoE', 'VoEResponse', 'FSoE',
    'CiA402', 'ModeCiA402',
    # 枚举
    'EcState', 'EcLinkState', 'RingMode', 'EcErr', 'CiA402State',
    'FsoEState', 'FsoEError',
    # 结构体
    'DllVersionInfo', 'SlaveIdentity', 'SlaveEsmTimeouts',
    'WatchdogConfig', 'WatchdogStatus', 'MasterIdentity', 'MasterDiagData',
    'StartupParam', 'FoEOptions', 'EmcyRecord', 'TopologyNode',
    'RedundancyStatus', 'CommunicationStats',
    'EscPortErrorStats', 'FsoEConfig', 'FsoEStatus', 'FsoEMdpConfig',
    # 常量
    'TRANS_IP', 'TRANS_PS', 'TRANS_SO', 'TRANS_OS', 'TRANS_SP', 'TRANS_PI',
    'TIMING_BEFORE', 'TIMING_AFTER',
    # 底层
    'DarraCoreDLL',
    # ---- 高级功能 (各独立模块) ----
    'EcDataType', 'ObjAccess', 'ObjectEntry', 'ObjectDictionary', 'ODList',
    'CiA402Advanced', 'SoEAdvanced',
    'FSoEMdp', 'FSoEManager', 'fsoe_crc16', 'fsoe_crc16_fast',
    'MdpModule', 'MdpSlotInfo', 'MdpModulePdoInfo', 'MdpDiscovery',
    'EoEPinger', 'AoESubscription', 'AoESubscriptionManager',
    'PDOWatcher', 'PDOMonitor',
    # ---- CiA 401 I/O 模块 (slave/cia401.py) ----
    'CiA401', 'CiA401ErrorMode',
    # ---- 主站配置 (master/config.py) ----
    'MasterConfig', 'ScanRevisionMatchMode', 'MailboxConfig',
    # ---- ETG.1510 主站对象字典 (master/master_od.py) ----
    'MasterObjectDictionary',
    # ---- ETG.8200 Mailbox Gateway (master/mailbox_gateway.py) ----
    'MailboxGatewayService',
    # ---- ESI 加载器 (slave/esi.py) ----
    'EsiLoader', 'EsiStartupParam', 'EsiDeviceInfo',
    # ---- 类型定义 (data/types.py) ----
    'EcBufState', 'EcCmdType', 'EcEcmdType', 'LogLevel',
    'EcALState', 'ALErrorCategory', 'classify_al_error',
    'MailboxError', 'MailboxType', 'SDOError', 'SoEError',
    'EcCommType', 'EcPortType', 'EcTopologyType', 'EcPdiType',
    'EcDeviceType', 'EcSyncManagerType', 'EcFmmuType',
    'EcCoEDetails', 'EcEoEDetails',
    'DcSyncMode', 'StartupTransition', 'StartupWriteTiming',
    'CoEObjectAccess', 'EsmTimeouts',
    'SlaveErrorCounters', 'DiagnosticMessage',
    'EcStateFormat',
    # ---- 诊断信息 (master/diagnostics.py) ----
    'MasterDiagnosticsInfo', 'MasterPDODiagnostics', 'PDOFrameLossStats',
    # ---- 日志管理 (logging/logging.py) ----
    'LogManager', 'LogCategory', 'LogEntry', 'LogView',
    # ---- 事件系统 (master/events.py) ----
    'SlaveEvents', 'MasterEvents', 'SlaveIdentityMismatchEventArgs',
    # ---- 从站诊断 (slave/slave_stats.py) ----
    'EscPortErrors', 'SyncWindowStatus', 'SlaveDCDiagnostics', 'SlaveDiagnostics',
    # ---- 启动参数管理 (slave/startup.py) ----
    'StartupParameter', 'StartupParameterList',
    # ---- 网络信息 (statics/network.py) ----
    'NetworkInfo', 'ScannedSlaveInfo', 'TopologyInfo',
    'get_network_info', 'scan_slaves',
    'abort_scan', 'reset_scan_abort',
    'quick_slave_count', 'quick_slave_count_redundant',
    'quick_find_redundant_pair_batch', 'get_ring_slave_count',
    # ---- 版本信息 (statics/version_info.py) ----
    'get_dll_version', 'get_api_version', 'get_build_number',
    'get_serial_number', 'get_build_date',
    # ---- 基础数据 (utils/base_data.py) ----
    'EC_MAX_SLAVE', 'EC_MAX_GROUP', 'EC_MAX_MAILBOX_SIZE', 'EC_MAX_SDO_SIZE',
    'EC_MAX_EEPROM_SIZE', 'EC_MAX_NAME', 'EC_MAX_PORTS', 'EC_MAX_FMMU', 'EC_MAX_SM',
    'ip_to_int', 'int_to_ip', 'mac_to_bytes', 'bytes_to_mac',
    'BaseData',
    # ---- 枚举描述辅助 (statics/print.py) ----
    'describe_state', 'describe_al_status', 'describe_link_state',
    'describe_object_access', 'describe_access_chinese',
    'describe_transition', 'describe_dc_mode', 'describe_redundancy_mode',
    'describe_al_status_en', 'describe_al_status_full',
    'describe_sdo_error', 'describe_soe_error',
    'describe_mailbox_error', 'describe_mailbox_type',
    'describe_data_type', 'describe_data_type_common',
    'describe_write_condition', 'describe_access_with_state',
    'describe_link_state_en',
    # ---- 启动配置验证 (utils/startup_verifier.py) ----
    'ExpectedSlaveConfig', 'SlaveVerifyDetail', 'VerificationResult',
    'verify_configuration', 'verify_configuration_detailed',
    'create_expected_configs_from_dict',
    'create_expected_configs_from_xml', 'verify_configuration_with_dll',
    # ---- 拓扑管理 (slave/topology.py) ----
    'SlaveTopology',
    # ---- 新增模块 ----
    'EmergencyMessage', 'CoEEmcyRecorder',
    'SoEParameter', 'SoEAttributes', 'SoEDataType', 'SoENotificationEventArgs',
    'DcConfig', 'SlavePdo',
    'RedundancyState', 'RedundancyStatusInfo', 'RedundancyManager', 'SlaveDiagnosticsData',
    'BreakPointInfo',
    'LicenseStatus', 'is_running_as_admin',
    'MasterXMLConfiguration', 'load_xml_configuration',
]
