# -*- coding: utf-8 -*-
"""
ETG.8200 Mailbox Gateway 实现

允许外部诊断工具通过 UDP/IP 访问 EtherCAT 从站和主站对象字典。
默认 UDP 端口: 0x88A4 (34980) - ETG.8200 标准端口。
当 Address 字段为 0x0000 时，访问主站对象字典 (ETG.1510)。
"""

import socket
import struct
import threading
import logging
from typing import Optional


logger = logging.getLogger(__name__)


class MailboxGatewayService:
    """
    ETG.8200 Mailbox Gateway UDP 服务

    用法::

        gw = master.mailbox_gateway
        gw.start()
        print(f"网关运行在端口 {gw.port}")
        # ... 使用中 ...
        gw.stop()
    """

    # ETG.8200 标准基础端口
    _BASE_PORT = 0x88A4  # 34980

    def __init__(self, master, master_number: int = 0):
        """
        初始化 Mailbox Gateway 服务

        参数:
            master: EtherCATMaster 实例
            master_number: 主站编号 (用于端口偏移)
        """
        self._master = master
        self._port = self._BASE_PORT + max(0, master_number)
        self._socket: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._stop_event = threading.Event()
        # 邮箱计数器 (1-7 循环)
        self._mailbox_counter = 0
        self._counter_lock = threading.Lock()

    @property
    def port(self) -> int:
        """UDP 端口号"""
        return self._port

    @port.setter
    def port(self, value: int):
        """设置 UDP 端口号（仅在未运行时可修改）"""
        if self._running:
            raise RuntimeError("网关运行中不能修改端口")
        self._port = value

    @property
    def is_running(self) -> bool:
        """是否正在运行"""
        return self._running

    def start(self):
        """启动 Mailbox Gateway 服务"""
        if self._running:
            return

        self._stop_event.clear()
        self._socket = self._bind_port(self._port)
        self._port = self._socket.getsockname()[1]
        self._running = True

        self._thread = threading.Thread(
            target=self._listen_loop,
            name="MailboxGateway",
            daemon=True,
        )
        self._thread.start()
        logger.info("邮箱网关已启动, UDP端口=%d", self._port)

    def stop(self):
        """停止 Mailbox Gateway 服务"""
        if not self._running:
            return

        self._running = False
        self._stop_event.set()

        # 关闭 socket 使 recvfrom 退出
        if self._socket:
            try:
                self._socket.close()
            except Exception:
                pass
            self._socket = None

        if self._thread:
            self._thread.join(timeout=2.0)
            self._thread = None

        logger.info("邮箱网关已停止")

    def _bind_port(self, preferred_port: int) -> socket.socket:
        """
        绑定 UDP 端口：标准端口 -> 10个备用端口 -> 系统自动分配

        参数:
            preferred_port: 期望端口

        返回:
            已绑定的 UDP socket
        """
        # 尝试标准端口和备用端口
        for i in range(10):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(('0.0.0.0', preferred_port + i))
                return sock
            except OSError:
                try:
                    sock.close()
                except Exception:
                    pass
                logger.debug("邮箱网关: 端口 %d 不可用", preferred_port + i)

        # 所有端口都不可用，让系统分配
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('0.0.0.0', 0))
        logger.info("邮箱网关: 使用系统分配端口")
        return sock

    def _listen_loop(self):
        """UDP 监听循环"""
        while not self._stop_event.is_set() and self._socket:
            try:
                # 设置超时以便检查停止标志
                self._socket.settimeout(1.0)
                data, addr = self._socket.recvfrom(4096)
                # 在工作线程处理请求
                worker = threading.Thread(
                    target=self._process_request,
                    args=(data, addr),
                    daemon=True,
                )
                worker.start()
            except socket.timeout:
                continue
            except OSError:
                if self._running:
                    logger.debug("邮箱网关: socket 已关闭")
                break
            except Exception as e:
                if self._running:
                    logger.error("邮箱网关接收错误: %s", e)
                else:
                    break

    def _process_request(self, data: bytes, remote_addr):
        """
        处理 Mailbox Gateway 请求

        参数:
            data: 接收到的 UDP 数据
            remote_addr: 远端地址
        """
        # ETG.8200 最小帧长度: EtherCAT Header(2) + Mailbox Header(6) + 至少1字节数据
        if len(data) < 9:
            return

        try:
            # 解析 EtherCAT Header (2 bytes)
            ecat_header = struct.unpack_from('<H', data, 0)[0]
            ecat_length = ecat_header & 0x07FF        # 11 bits
            ecat_data_type = (ecat_header >> 12) & 0x0F  # 4 bits

            # 验证数据类型为邮箱通信 (0x05)
            if ecat_data_type != 0x05:
                return

            # 解析 Mailbox Header (6 bytes)
            mb_length = struct.unpack_from('<H', data, 2)[0]
            address = struct.unpack_from('<H', data, 4)[0]
            channel_prio = data[6]
            type_cnt_res = data[7]

            mailbox_type = (type_cnt_res >> 4) & 0x0F
            mailbox_cnt = (type_cnt_res >> 1) & 0x07

            # 提取邮箱数据
            mb_data_start = 8
            if len(data) < mb_data_start + mb_length:
                return
            mailbox_data = data[mb_data_start:mb_data_start + mb_length]

            # 路由处理
            if address == 0x0000:
                # 访问主站对象字典 (ETG.1510)
                response = self._process_master_request(mailbox_type, mailbox_data)
            else:
                # 访问从站邮箱
                response = self._process_slave_request(address, mailbox_type, mailbox_data)

            if response and len(response) > 0:
                frame = self._build_response_frame(address, mailbox_type, response)
                if self._socket:
                    self._socket.sendto(frame, remote_addr)

        except Exception as e:
            logger.error("邮箱网关处理错误: %s", e)

    def _process_master_request(self, mailbox_type: int, mailbox_data: bytes) -> Optional[bytes]:
        """
        处理主站对象字典请求 (ETG.1510)

        参数:
            mailbox_type: 邮箱类型
            mailbox_data: 邮箱数据

        返回:
            响应数据
        """
        if mailbox_type != 0x03:  # 仅支持 CoE
            return self._build_coe_abort(0x06010000)

        if len(mailbox_data) < 6:
            return None

        # 解析 CoE SDO 请求
        coe_type = (mailbox_data[1] >> 4) & 0x0F
        if coe_type != 0x02:  # 不是 SDO
            return None

        sdo_command = mailbox_data[2]
        index = struct.unpack_from('<H', mailbox_data, 3)[0]
        subindex = mailbox_data[5]

        is_upload = (sdo_command & 0x40) != 0
        is_download = (sdo_command & 0x20) != 0 and (sdo_command & 0x40) == 0

        # 获取主站对象字典
        master_od = getattr(self._master, '_master_od_instance', None)
        if master_od is None:
            master_od = self._master.master_od

        if is_upload:
            # SDO Upload (读取)
            data = master_od.read_object(index, subindex)
            if data is None:
                return self._build_coe_abort(0x06020000)
            return self._build_coe_upload_response(index, subindex, data)
        elif is_download:
            # SDO Download (写入)
            write_data = mailbox_data[6:]
            if len(write_data) > 0:
                success = master_od.write_object(index, subindex, write_data)
                if not success:
                    return self._build_coe_abort(0x06010002)
                return self._build_coe_download_response(index, subindex)

        return self._build_coe_abort(0x05040001)

    def _process_slave_request(self, address: int, mailbox_type: int,
                               mailbox_data: bytes) -> Optional[bytes]:
        """
        处理从站邮箱请求

        参数:
            address: 从站站地址
            mailbox_type: 邮箱类型
            mailbox_data: 邮箱数据

        返回:
            响应数据
        """
        # 查找从站 (按索引遍历)
        target_slave = None
        for i in range(1, self._master.slave_count + 1):
            try:
                slave = self._master[i]
                if slave and slave.index == address:
                    target_slave = slave
                    break
            except (KeyError, IndexError):
                continue

        if target_slave is None:
            return self._build_coe_abort(0x06020000)

        # 根据邮箱类型路由
        if mailbox_type == 0x03:
            # CoE
            return self._process_slave_coe(target_slave, mailbox_data)
        elif mailbox_type == 0x04:
            # SoE
            return self._process_slave_soe(target_slave, mailbox_data)
        elif mailbox_type == 0x05:
            # FoE
            return self._process_slave_foe(target_slave, mailbox_data)
        elif mailbox_type == 0x0F:
            # VoE
            return self._process_slave_voe(target_slave, mailbox_data)
        else:
            return self._build_coe_abort(0x06010000)

    def _process_slave_coe(self, slave, mailbox_data: bytes) -> Optional[bytes]:
        """处理从站 CoE 请求"""
        if len(mailbox_data) < 6:
            return None

        sdo_command = mailbox_data[2]
        index = struct.unpack_from('<H', mailbox_data, 3)[0]
        subindex = mailbox_data[5]

        is_upload = (sdo_command & 0x40) != 0
        is_download = (sdo_command & 0x20) != 0 and (sdo_command & 0x40) == 0

        try:
            if is_upload:
                data = slave.coe.sdo_read(index, subindex)
                if data is None:
                    return self._build_coe_abort(0x06020000)
                return self._build_coe_upload_response(index, subindex, data)
            elif is_download:
                write_data = mailbox_data[6:]
                if len(write_data) > 0:
                    success = slave.coe.sdo_write(index, subindex, write_data)
                    if not success:
                        return self._build_coe_abort(0x06010002)
                    return self._build_coe_download_response(index, subindex)
        except Exception as e:
            logger.error("从站 CoE 错误: %s", e)
            return self._build_coe_abort(0x08000000)

        return self._build_coe_abort(0x05040001)

    def _process_slave_soe(self, slave, mailbox_data: bytes) -> Optional[bytes]:
        """处理从站 SoE 请求 - 透传"""
        if len(mailbox_data) < 4:
            return self._build_soe_error(0x1001)

        try:
            op_code = mailbox_data[0]
            flags = mailbox_data[1]
            drive_no = (flags >> 3) & 0x07
            element_flags = flags & 0x07
            idn = struct.unpack_from('<H', mailbox_data, 2)[0]

            if op_code == 0x01:  # 读取
                data = slave.soe.read(idn, 0x40 | element_flags, 500)
                if data is None:
                    return self._build_soe_error(0x1009)
                return self._build_soe_read_response(idn, drive_no, element_flags, data)
            elif op_code == 0x02:  # 写入
                write_data = mailbox_data[4:]
                if len(write_data) <= 0:
                    return self._build_soe_error(0x3002)
                success = slave.soe.write(idn, write_data, element_flags, 500)
                if not success:
                    return self._build_soe_error(0x7002)
                return self._build_soe_write_response(idn, drive_no, element_flags)
            else:
                return self._build_soe_error(0x1001)
        except Exception as e:
            logger.error("从站 SoE 错误: %s", e)
            return self._build_soe_error(0x8000)

    def _process_slave_foe(self, slave, mailbox_data: bytes) -> Optional[bytes]:
        """处理从站 FoE 请求 - 透传"""
        if len(mailbox_data) < 1:
            return self._build_foe_error(0x00008001)

        try:
            op_code = mailbox_data[0]

            if op_code in (0x01, 0x02):
                # 读/写请求
                if len(mailbox_data) < 6:
                    return self._build_foe_error(0x00008003)
                filename = mailbox_data[5:].decode('ascii', errors='ignore').rstrip('\x00')
                if not filename:
                    return self._build_foe_error(0x00008003)

                if op_code == 0x01:  # 读取
                    file_data = slave.foe.download(filename, timeout_ms=5000)
                    if file_data is None:
                        return self._build_foe_error(0x00008002)
                    return self._build_foe_data_response(0, file_data)
                else:  # 写入
                    return self._build_foe_ack_response(0)
            else:
                return self._build_foe_error(0x00008001)
        except Exception as e:
            logger.error("从站 FoE 错误: %s", e)
            return self._build_foe_error(0x00008000)

    def _process_slave_voe(self, slave, mailbox_data: bytes) -> Optional[bytes]:
        """处理从站 VoE 请求 - 透传"""
        if len(mailbox_data) < 6:
            return self._build_voe_error(0x0002)

        try:
            vendor_id = struct.unpack_from('<I', mailbox_data, 0)[0]
            vendor_type = struct.unpack_from('<H', mailbox_data, 4)[0]
            data = mailbox_data[6:]

            response = slave.voe.send_and_receive(vendor_id, vendor_type, data, 500)
            if response is None:
                return self._build_voe_error(0x0003)
            return response
        except Exception as e:
            logger.error("从站 VoE 错误: %s", e)
            return self._build_voe_error(0x0000)

    # ========== 响应构建方法 ==========

    def _build_coe_upload_response(self, index: int, subindex: int, data: bytes) -> bytes:
        """构建 CoE Upload 响应"""
        response = bytearray(6 + len(data))
        response[0] = 0x00
        response[1] = 0x20  # Type = SDO
        if len(data) <= 4:
            size_indicator = (4 - len(data)) << 2
            response[2] = 0x43 | size_indicator
        else:
            response[2] = 0x41
        struct.pack_into('<H', response, 3, index)
        response[5] = subindex
        response[6:6 + len(data)] = data
        return bytes(response)

    def _build_coe_download_response(self, index: int, subindex: int) -> bytes:
        """构建 CoE Download 响应"""
        response = bytearray(6)
        response[0] = 0x00
        response[1] = 0x20
        response[2] = 0x60
        struct.pack_into('<H', response, 3, index)
        response[5] = subindex
        return bytes(response)

    def _build_coe_abort(self, abort_code: int) -> bytes:
        """构建 CoE Abort 响应"""
        response = bytearray(10)
        response[0] = 0x00
        response[1] = 0x20
        response[2] = 0x80
        struct.pack_into('<I', response, 6, abort_code)
        return bytes(response)

    def _build_soe_read_response(self, idn: int, drive_no: int,
                                 element_flags: int, data: bytes) -> bytes:
        """构建 SoE Read 响应"""
        response = bytearray(4 + len(data))
        response[0] = 0x80  # Read Response
        response[1] = (drive_no << 3) | (element_flags & 0x07)
        struct.pack_into('<H', response, 2, idn)
        response[4:4 + len(data)] = data
        return bytes(response)

    def _build_soe_write_response(self, idn: int, drive_no: int,
                                  element_flags: int) -> bytes:
        """构建 SoE Write 响应"""
        response = bytearray(4)
        response[0] = 0x81  # Write Response
        response[1] = (drive_no << 3) | (element_flags & 0x07)
        struct.pack_into('<H', response, 2, idn)
        return bytes(response)

    def _build_soe_error(self, error_code: int) -> bytes:
        """构建 SoE Error 响应"""
        response = bytearray(4)
        response[0] = 0x84  # Error
        response[1] = 0x40  # Error bit set
        struct.pack_into('<H', response, 2, error_code)
        return bytes(response)

    def _build_foe_data_response(self, packet_no: int, data: bytes) -> bytes:
        """构建 FoE Data 响应"""
        response = bytearray(5 + len(data))
        response[0] = 0x03  # Data
        struct.pack_into('<I', response, 1, packet_no)
        response[5:5 + len(data)] = data
        return bytes(response)

    def _build_foe_ack_response(self, packet_no: int) -> bytes:
        """构建 FoE Ack 响应"""
        response = bytearray(5)
        response[0] = 0x04  # Ack
        struct.pack_into('<I', response, 1, packet_no)
        return bytes(response)

    def _build_foe_error(self, error_code: int) -> bytes:
        """构建 FoE Error 响应"""
        response = bytearray(5)
        response[0] = 0x05  # Error
        struct.pack_into('<I', response, 1, error_code)
        return bytes(response)

    def _build_voe_error(self, error_code: int) -> bytes:
        """构建 VoE Error 响应"""
        response = bytearray(6)
        struct.pack_into('<I', response, 0, 0)  # VendorID = 0
        struct.pack_into('<H', response, 4, error_code)
        return bytes(response)

    def _build_response_frame(self, address: int, mailbox_type: int,
                              mailbox_data: bytes) -> bytes:
        """
        构建 ETG.8200 响应帧

        参数:
            address: 站地址
            mailbox_type: 邮箱类型
            mailbox_data: 邮箱数据

        返回:
            完整的响应帧
        """
        frame_len = 2 + 6 + len(mailbox_data)
        frame = bytearray(frame_len)

        # EtherCAT Header
        ecat_length = 6 + len(mailbox_data)
        ecat_header = (0x05 << 12) | (ecat_length & 0x07FF)
        struct.pack_into('<H', frame, 0, ecat_header)

        # Mailbox Header
        struct.pack_into('<H', frame, 2, len(mailbox_data))
        struct.pack_into('<H', frame, 4, address)
        frame[6] = 0x00  # Channel = 0, Priority = 0

        # 邮箱计数器 (1-7 循环)
        with self._counter_lock:
            self._mailbox_counter += 1
            cnt = ((self._mailbox_counter - 1) % 7) + 1
        frame[7] = (mailbox_type << 4) | (cnt << 1)

        # Mailbox Data
        frame[8:8 + len(mailbox_data)] = mailbox_data

        return bytes(frame)

    def __repr__(self) -> str:
        status = "运行中" if self._running else "已停止"
        return f"MailboxGatewayService(port={self._port}, {status})"
