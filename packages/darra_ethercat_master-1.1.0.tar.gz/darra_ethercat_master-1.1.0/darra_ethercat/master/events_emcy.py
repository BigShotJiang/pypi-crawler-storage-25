# -*- coding: utf-8 -*-
"""
对应 C# 文件: Master/Events_EmcyRecorder.cs
EMCY 事件记录扩展

将 EMCY 紧急消息记录到从站的 CoE 历史中。
"""

from typing import Optional, List
from ..slave.coe_emcy import CoEEmcyRecorder


def record_emcy_to_slave(emcy_recorders: dict, slave_index: int,
                         error_code: int, error_reg: int,
                         b1: int, w1: int, w2: int) -> None:
    """
    将 EMCY 紧急消息记录到从站的 CoE 历史中

    参数:
        emcy_recorders: {从站索引: CoEEmcyRecorder} 字典
        slave_index:    从站索引
        error_code:     紧急错误代码
        error_reg:      错误寄存器
        b1:             厂商特定字节
        w1:             厂商特定字 1
        w2:             厂商特定字 2
    """
    try:
        recorder = emcy_recorders.get(slave_index)
        if recorder is not None:
            recorder.record_emergency(error_code, error_reg, b1, w1, w2)
    except Exception:
        # 记录 EMCY 历史不应影响正常事件流
        pass
