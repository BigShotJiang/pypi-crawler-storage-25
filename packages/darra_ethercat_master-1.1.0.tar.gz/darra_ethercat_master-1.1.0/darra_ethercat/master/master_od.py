# -*- coding: utf-8 -*-
"""
ETG.1510 主站对象字典实现

提供符合 ETG.1510 规范的主站对象字典，用于诊断工具和 HMI 访问。

支持的对象索引范围：
- 0x1000: Device Type
- 0x1008: Manufacturer Device Name
- 0x1009: Manufacturer Hardware Version
- 0x100A: Manufacturer Software Version
- 0x1018: Identity Object
- 0x8nnn: Configuration Data (从站配置数据)
- 0x9nnn: Information Data (从站信息数据)
- 0xAnnn: Diagnosis Data (从站诊断数据)
- 0xF002: Detect Modules Command
- 0xF120: Master Diag Data
- 0xF200: Diag Interface Control
"""

import struct
import sys
import threading
from typing import Dict, List, Optional


# 实例计数器，用于生成唯一序列号
_instance_counter = 0
_instance_lock = threading.Lock()


class MasterObjectDictionary:
    """
    ETG.1510 主站对象字典

    用法::

        od = master.master_od
        # 读取设备类型
        data = od.read_object(0x1000, 0)
        # 获取支持的对象列表
        indices = od.get_supported_object_indices()
    """

    # 主站 Vendor ID (ETG 分配，固定值)
    VENDOR_ID = 0x00001164

    # 主站 Product Code（固定值）
    PRODUCT_CODE = 0x00000001

    def __init__(self, master):
        """
        初始化主站对象字典

        参数:
            master: EtherCATMaster 实例
        """
        self._master = master

        # 分配唯一序列号
        global _instance_counter
        with _instance_lock:
            self._serial_number = _instance_counter
            _instance_counter += 1

        # 扫描命令状态
        self._scan_command_status = 1  # 1 = 完成无错误
        self._detected_slave_count = 0

        # 诊断复位标志
        self._reset_diag_pending = False

        # 从站诊断数据缓存
        self._slave_diag_data: Dict[int, dict] = {}

    @property
    def vendor_id(self) -> int:
        """主站 Vendor ID"""
        return self.VENDOR_ID

    @property
    def product_code(self) -> int:
        """主站 Product Code"""
        return self.PRODUCT_CODE

    @property
    def revision_number(self) -> int:
        """
        主站 Revision Number
        从 DLL 版本派生：高字=主版本，低字=次版本
        """
        try:
            ver = self._master.dll_version
            if ver:
                major = ver.get('major', 0)
                minor = ver.get('minor', 0)
                return (major << 16) | (minor & 0xFFFF)
        except Exception:
            pass
        return 0x00010000

    @property
    def serial_number(self) -> int:
        """主站 Serial Number（按实例自增）"""
        return self._serial_number

    def get_object_name(self, index: int) -> str:
        """
        获取对象名称

        参数:
            index: 对象索引

        返回:
            对象名称字符串
        """
        if index == 0x1000:
            return "Device Type"
        if index == 0x1008:
            return "Manufacturer Device Name"
        if index == 0x1009:
            return "Manufacturer Hardware Version"
        if index == 0x100A:
            return "Manufacturer Software Version"
        if index == 0x1018:
            return "Identity Object"
        if 0x8000 <= index <= 0x8FFF:
            return f"Configuration Data Slave {index & 0x0FFF}"
        if 0x9000 <= index <= 0x9FFF:
            return f"Information Data Slave {index & 0x0FFF}"
        if 0xA000 <= index <= 0xAFFF:
            return f"Diagnosis Data Slave {index & 0x0FFF}"
        if index == 0xF002:
            return "Detect Modules Command"
        if index == 0xF120:
            return "Master Diag Data"
        if index == 0xF200:
            return "Diag Interface Control"
        return "Unknown"

    def get_subindex_count(self, index: int) -> int:
        """
        获取对象的子索引数量

        参数:
            index: 对象索引

        返回:
            子索引数量
        """
        if index in (0x1000, 0x1008, 0x1009, 0x100A):
            return 0
        if index == 0x1018:
            return 4
        if 0x8000 <= index <= 0x8FFF:
            return 40
        if 0x9000 <= index <= 0x9FFF:
            return 32
        if 0xA000 <= index <= 0xAFFF:
            return 19
        if index == 0xF002:
            return 3
        if index in (0xF120, 0xF200):
            return 16
        return 0

    def get_supported_object_indices(self) -> List[int]:
        """
        获取支持的对象索引列表

        返回:
            对象索引列表
        """
        indices = [0x1000, 0x1008, 0x1009, 0x100A, 0x1018,
                   0xF002, 0xF120, 0xF200]

        # 添加从站相关对象
        slave_count = self._master.slave_count
        for i in range(1, slave_count + 1):
            indices.append(0x8000 | i)  # Configuration Data
            indices.append(0x9000 | i)  # Information Data
            indices.append(0xA000 | i)  # Diagnosis Data

        return indices

    def read_object(self, index: int, subindex: int) -> Optional[bytes]:
        """
        读取主站对象字典 (SDO Read)
        根据 ETG.1510 规范实现主站诊断对象的读取

        参数:
            index: 对象索引
            subindex: 子索引

        返回:
            读取的数据，失败返回 None
        """
        if index == 0x1000:
            return self._read_0x1000(subindex)
        elif index == 0x1008:
            return self._read_0x1008(subindex)
        elif index == 0x1009:
            return self._read_0x1009(subindex)
        elif index == 0x100A:
            return self._read_0x100A(subindex)
        elif index == 0x1018:
            return self._read_0x1018(subindex)
        elif 0x8000 <= index <= 0x8FFF:
            return self._read_0x8nnn(index, subindex)
        elif 0x9000 <= index <= 0x9FFF:
            return self._read_0x9nnn(index, subindex)
        elif 0xA000 <= index <= 0xAFFF:
            return self._read_0xAnnn(index, subindex)
        elif index == 0xF002:
            return self._read_0xF002(subindex)
        elif index == 0xF120:
            return self._read_0xF120(subindex)
        elif index == 0xF200:
            return self._read_0xF200(subindex)
        return None

    def write_object(self, index: int, subindex: int, data: bytes) -> bool:
        """
        写入主站对象字典 (SDO Write)

        参数:
            index: 对象索引
            subindex: 子索引
            data: 要写入的数据

        返回:
            成功返回 True
        """
        if index == 0xF002:
            return self._write_0xF002(subindex, data)
        elif index == 0xF200:
            return self._write_0xF200(subindex, data)
        elif 0xA000 <= index <= 0xAFFF:
            return self._write_0xAnnn(index, subindex, data)
        return False  # 只读对象或未知对象

    # ========== 内部读取方法 ==========

    def _read_0x1000(self, subindex: int) -> Optional[bytes]:
        """0x1000 - Device Type: EtherCAT Master = 0x00001389"""
        if subindex != 0:
            return None
        return struct.pack('<I', 0x00001389)

    def _read_0x1008(self, subindex: int) -> Optional[bytes]:
        """0x1008 - Manufacturer Device Name"""
        if subindex != 0:
            return None
        return b"Darra EtherCAT Master"

    def _read_0x1009(self, subindex: int) -> Optional[bytes]:
        """0x1009 - Manufacturer Hardware Version"""
        if subindex != 0:
            return None
        hw = "x64" if sys.maxsize > 2**32 else "x86"
        return hw.encode('ascii')

    def _read_0x100A(self, subindex: int) -> Optional[bytes]:
        """0x100A - Manufacturer Software Version"""
        if subindex != 0:
            return None
        try:
            ver = self._master.dll_version
            if ver:
                sw = f"{ver.get('major', 0)}.{ver.get('minor', 0)}.{ver.get('build', 0)}"
            else:
                sw = "0.0.0"
        except Exception:
            sw = "0.0.0"
        return sw.encode('ascii')

    def _read_0x1018(self, subindex: int) -> Optional[bytes]:
        """0x1018 - Identity Object"""
        if subindex == 0:
            return bytes([4])
        elif subindex == 1:
            return struct.pack('<I', self.vendor_id)
        elif subindex == 2:
            return struct.pack('<I', self.product_code)
        elif subindex == 3:
            return struct.pack('<I', self.revision_number)
        elif subindex == 4:
            return struct.pack('<I', self.serial_number)
        return None

    def _get_slave(self, slave_index: int):
        """获取从站实例，安全访问"""
        try:
            return self._master[slave_index]
        except (KeyError, IndexError):
            return None

    def _read_0x8nnn(self, index: int, subindex: int) -> Optional[bytes]:
        """0x8nnn - Configuration Data (从站配置数据)"""
        slave_index = index & 0x0FFF
        if slave_index == 0 or slave_index > self._master.slave_count:
            return None

        slave = self._get_slave(slave_index)
        if slave is None:
            return None

        if subindex == 0:
            return bytes([40])

        identity = slave.identity
        if identity is None:
            identity = {}

        if subindex == 1:
            # Fixed Station Address
            try:
                return struct.pack('<H', slave.index)
            except Exception:
                return struct.pack('<H', 0)
        elif subindex == 5:
            # Vendor ID
            return struct.pack('<I', identity.get('vendor_id', 0))
        elif subindex == 6:
            # Product Code
            return struct.pack('<I', identity.get('product_code', 0))
        elif subindex == 7:
            # Revision Number
            return struct.pack('<I', identity.get('revision_no', 0))
        elif subindex == 8:
            # Serial Number
            return struct.pack('<I', identity.get('serial_no', 0))

        return None

    def _read_0x9nnn(self, index: int, subindex: int) -> Optional[bytes]:
        """0x9nnn - Information Data (检测到的从站信息)"""
        slave_index = index & 0x0FFF
        if slave_index == 0 or slave_index > self._master.slave_count:
            return None

        slave = self._get_slave(slave_index)
        if slave is None:
            return None

        if subindex == 0:
            return bytes([32])

        identity = slave.identity
        if identity is None:
            identity = {}

        if subindex == 1:
            return struct.pack('<H', slave.index)
        elif subindex == 5:
            return struct.pack('<I', identity.get('vendor_id', 0))
        elif subindex == 6:
            return struct.pack('<I', identity.get('product_code', 0))
        elif subindex == 7:
            return struct.pack('<I', identity.get('revision_no', 0))
        elif subindex == 8:
            return struct.pack('<I', identity.get('serial_no', 0))

        return None

    def _read_0xAnnn(self, index: int, subindex: int) -> Optional[bytes]:
        """0xAnnn - Diagnosis Data (从站诊断数据)"""
        slave_index = index & 0x0FFF
        if slave_index == 0 or slave_index > self._master.slave_count:
            return None

        slave = self._get_slave(slave_index)
        if slave is None:
            return None

        # 获取或创建诊断数据
        if slave_index not in self._slave_diag_data:
            self._slave_diag_data[slave_index] = {
                'al_status': 0,
                'al_control': 0,
                'last_al_status_code': 0,
                'link_conn_status': 0,
                'link_control': 0,
                'fixed_addr_conn_port': [0, 0, 0, 0],
                'frame_error_counter': [0, 0, 0, 0],
                'cyclic_wc_error_counter': 0,
                'slave_not_present_counter': 0,
                'abnormal_state_change_counter': 0,
                'disable_auto_link_control': False,
                'last_coe_soe_protocol_error': 0,
                'new_diag_messages': False,
            }

        diag = self._slave_diag_data[slave_index]

        if subindex == 0:
            return bytes([19])
        elif subindex == 1:
            return struct.pack('<H', diag['al_status'])
        elif subindex == 2:
            return struct.pack('<H', diag['al_control'])
        elif subindex == 3:
            return struct.pack('<H', diag['last_al_status_code'])
        elif subindex == 4:
            return bytes([diag['link_conn_status'] & 0xFF])
        elif subindex == 5:
            return bytes([diag['link_control'] & 0xFF])
        elif 6 <= subindex <= 9:
            port = subindex - 6
            return struct.pack('<H', diag['fixed_addr_conn_port'][port])
        elif 10 <= subindex <= 13:
            port = subindex - 10
            return struct.pack('<I', diag['frame_error_counter'][port])
        elif subindex == 14:
            return struct.pack('<I', diag['cyclic_wc_error_counter'])
        elif subindex == 15:
            return struct.pack('<I', diag['slave_not_present_counter'])
        elif subindex == 16:
            return struct.pack('<I', diag['abnormal_state_change_counter'])
        elif subindex == 17:
            return bytes([1 if diag['disable_auto_link_control'] else 0])
        elif subindex == 18:
            return struct.pack('<I', diag['last_coe_soe_protocol_error'])
        elif subindex == 19:
            return bytes([1 if diag['new_diag_messages'] else 0])

        return None

    def _read_0xF002(self, subindex: int) -> Optional[bytes]:
        """0xF002 - Detect Modules Command"""
        if subindex == 0:
            return bytes([3])
        elif subindex == 1:
            return bytes([0, 0])
        elif subindex == 2:
            return bytes([self._scan_command_status])
        elif subindex == 3:
            response = bytearray(6)
            response[0] = self._scan_command_status
            response[1] = 0
            struct.pack_into('<H', response, 2, 0)  # 错误码
            struct.pack_into('<H', response, 4, self._detected_slave_count)
            return bytes(response)
        return None

    def _read_0xF120(self, subindex: int) -> Optional[bytes]:
        """0xF120 - Master Diag Data (主站诊断数据)"""
        if subindex == 0:
            return bytes([16])
        elif subindex == 1:
            # Cyclic Lost Frames
            diag = self._master.diagnostics
            lost = diag.get('cyclic_lost_frames', 0) if diag else 0
            return struct.pack('<I', int(lost * 100))
        elif subindex == 2:
            # Acyclic Lost Frames (当前不支持区分)
            return struct.pack('<I', 0)
        elif subindex == 3:
            # Cyclic Frames Per Second
            return struct.pack('<I', 1000)  # 默认
        elif subindex == 4:
            return struct.pack('<I', 0)
        elif subindex == 16:
            # Master State
            try:
                state = self._master.state
                return struct.pack('<H', state if state else 0)
            except Exception:
                return struct.pack('<H', 0)
        return None

    def _read_0xF200(self, subindex: int) -> Optional[bytes]:
        """0xF200 - Diag Interface Control"""
        if subindex == 0:
            return bytes([16])
        elif subindex == 16:
            return bytes([1 if self._reset_diag_pending else 0])
        return None

    # ========== 内部写入方法 ==========

    def _write_0xF002(self, subindex: int, data: bytes) -> bool:
        """写入 0xF002 - 安全保护：禁止外部写入"""
        return False

    def _write_0xF200(self, subindex: int, data: bytes) -> bool:
        """写入 0xF200 (复位诊断信息)"""
        if subindex == 16 and data and len(data) >= 1:
            new_value = data[0] != 0
            # 检测上升沿
            if new_value and not self._reset_diag_pending:
                self._reset_all_diagnostics()
            self._reset_diag_pending = new_value
            return True
        return False

    def _write_0xAnnn(self, index: int, subindex: int, data: bytes) -> bool:
        """写入 0xAnnn 诊断数据（仅支持部分可写子索引）"""
        slave_index = index & 0x0FFF
        if slave_index == 0 or slave_index > self._master.slave_count:
            return False
        if slave_index not in self._slave_diag_data:
            return False
        # 当前不支持外部写入诊断数据
        return False

    def _reset_all_diagnostics(self):
        """复位所有诊断计数器"""
        for diag in self._slave_diag_data.values():
            diag['last_al_status_code'] = 0
            diag['frame_error_counter'] = [0, 0, 0, 0]
            diag['cyclic_wc_error_counter'] = 0
            diag['slave_not_present_counter'] = 0
            diag['abnormal_state_change_counter'] = 0

    def __repr__(self) -> str:
        return (
            f"MasterObjectDictionary("
            f"vendor_id=0x{self.vendor_id:08X}, "
            f"product_code=0x{self.product_code:08X}, "
            f"serial={self.serial_number})"
        )
