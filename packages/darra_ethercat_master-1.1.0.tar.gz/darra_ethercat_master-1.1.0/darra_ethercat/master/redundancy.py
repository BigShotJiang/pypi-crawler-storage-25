# -*- coding: utf-8 -*-
"""
对应 C# 文件: Master/RedundancyManager.cs
冗余网络管理器

包含:
- RedundancyState: 冗余状态枚举
- RedundancyStatusInfo: 冗余状态数据类
- RedundancyManager: 冗余网络管理辅助类
"""

from dataclasses import dataclass
from enum import IntEnum
from typing import Optional

from ..utils.dll import DarraCoreDLL, RedundancyStatus


class RedundancyState(IntEnum):
    """冗余网络状态枚举"""
    NONE      = 0  # 无冗余
    PRIMARY   = 1  # 仅使用主网络
    SECONDARY = 2  # 仅使用备用网络
    BOTH      = 3  # 使用双网络 (活动冗余)

    @property
    def description(self) -> str:
        """获取中文描述"""
        _desc = {
            RedundancyState.NONE: "无冗余",
            RedundancyState.PRIMARY: "主网络",
            RedundancyState.SECONDARY: "备用网络",
            RedundancyState.BOTH: "双网络活动",
        }
        return _desc.get(self, "未知")


@dataclass(frozen=True)
class RedundancyStatusInfo:
    """
    冗余状态信息数据类
    对应 C 端 ec_redundancy_status_t 结构体
    """
    # 冗余状态
    state: RedundancyState
    # 主链路是否连接
    primary_link_up: bool
    # 备用链路是否连接
    secondary_link_up: bool
    # 主网络发送帧数
    tx_frames_primary: int
    # 主网络接收帧数
    rx_frames_primary: int
    # 备用网络发送帧数
    tx_frames_secondary: int
    # 备用网络接收帧数
    rx_frames_secondary: int
    # 故障切换次数
    failover_count: int
    # 最后故障切换时间 (Unix 时间戳, 秒; 无切换时为 None)
    last_failover_time: Optional[float]

    def __str__(self) -> str:
        """格式化输出冗余状态"""
        primary = "UP" if self.primary_link_up else "DOWN"
        secondary = "UP" if self.secondary_link_up else "DOWN"
        lines = [
            f"状态: {self.state.description}",
            f"主链路: {primary}, 备链路: {secondary}",
            f"主网络  TX: {self.tx_frames_primary}, RX: {self.rx_frames_primary}",
            f"备网络  TX: {self.tx_frames_secondary}, RX: {self.rx_frames_secondary}",
            f"故障转移: {self.failover_count} 次",
        ]
        if self.last_failover_time is not None:
            lines.append(f"最后切换时间: {self.last_failover_time}")
        return "\n".join(lines)


class RedundancyManager:
    """
    冗余网络管理器
    对应 C# RedundancyManager 相关 partial class 方法
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int):
        """
        初始化冗余管理器

        参数:
            dll:          DLL 接口
            master_index: 主站编号
        """
        self._dll = dll
        self._mi = master_index

    def enable(self, enable: bool = True) -> bool:
        """
        启用或禁用冗余网络

        参数:
            enable: 是否启用冗余

        返回:
            是否设置成功
        """
        return bool(self._dll.EnableRedundancy(self._mi, enable))

    def get_status(self) -> Optional[RedundancyStatusInfo]:
        """
        获取冗余网络状态

        返回:
            RedundancyStatusInfo 数据类实例, 失败返回 None
        """
        ptr = None
        try:
            ptr = self._dll.GetRedundancyStatus(self._mi)
            if not ptr:
                return None
            # 从 RedundancyStatus 结构体解析
            import ctypes
            from ..utils.dll import RedundancyStatus as RS
            status = ctypes.cast(ptr, ctypes.POINTER(RS)).contents
            # 解析状态枚举
            try:
                state = RedundancyState(status.state)
            except ValueError:
                state = RedundancyState.NONE
            # 解析最后切换时间 (0 表示无切换记录)
            last_time = float(status.last_failover_time) if status.last_failover_time > 0 else None
            return RedundancyStatusInfo(
                state=state,
                primary_link_up=bool(status.primary_link_up),
                secondary_link_up=bool(status.secondary_link_up),
                tx_frames_primary=status.primary_tx_frames,
                rx_frames_primary=status.primary_rx_frames,
                tx_frames_secondary=status.secondary_tx_frames,
                rx_frames_secondary=status.secondary_rx_frames,
                failover_count=status.failover_count,
                last_failover_time=last_time,
            )
        except Exception:
            return None
        finally:
            if ptr:
                try:
                    self._dll.FreeMemory(ptr)
                except Exception:
                    pass

    def force_failover(self) -> bool:
        """
        强制冗余故障切换

        返回:
            是否切换成功
        """
        return bool(self._dll.ForceRedundancyFailover(self._mi))

    def check_health(self) -> bool:
        """检查冗余网络健康状态"""
        return bool(self._dll.CheckRedundancyHealth(self._mi))

    def set_red_processdata(self, mode: int) -> None:
        """
        设置冗余过程数据模式

        参数:
            mode: 冗余处理模式 (0=禁用, 1=启用)
        """
        self._dll.SetRedProcessdata(mode)

    def get_red_processdata(self) -> int:
        """
        获取冗余过程数据模式

        返回:
            冗余处理模式 (0=禁用, 非0=启用)
        """
        return self._dll.GetRedProcessdata()

    def __repr__(self) -> str:
        return f"RedundancyManager(master={self._mi})"

    def __str__(self) -> str:
        """格式化输出冗余管理器状态"""
        status = self.get_status()
        return str(status) if status is not None else "冗余状态不可用"
