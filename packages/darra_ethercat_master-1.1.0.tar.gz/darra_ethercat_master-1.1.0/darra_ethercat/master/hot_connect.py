# -*- coding: utf-8 -*-
"""
对应 C# 文件: Master/HotConnect.cs
Hot-Connect 组管理 (ETG.1000.4 / ETG.1020 §8)

包含:
- HotConnectStatus: 组状态枚举 (UNKNOWN=-1, ABSENT=0, PRESENT=1)
- HotConnectGroup:  Hot-Connect 组只读快照数据类
- HotConnect:       Hot-Connect 组管理器

语义 "默默支持":
- 用户不调用 add_group, 所有从站行为 = mandatory (默认; 缺失 → AL_ERROR).
- 一旦把从站加入 Hot-Connect 组, 该组缺失就不再算错, Master 可正常进 OP.

关键约束:
- Alias Address (ESC 0x0012) 必须预先烧录到从站 EEPROM, 非 0 且组内唯一.
- Alias=0 的从站不支持 Hot-Connect (ETG.1020 §8.3).
"""

import ctypes
from dataclasses import dataclass
from enum import IntEnum
from typing import List

from ..utils.dll import DarraCoreDLL, HotConnectGroupNative


# 每个 master 最多支持的 Hot-Connect 组数 (与 C 端 EC_HOTCONNECT_MAX_GROUPS 一致)
MAX_GROUPS: int = 32


class HotConnectStatus(IntEnum):
    """Hot-Connect 组当前状态 (对齐 C# HotConnectStatus)."""
    UNKNOWN = -1   # 组未注册或底层查询失败
    ABSENT = 0     # 组在当前扫描中未探测到
    PRESENT = 1    # 组在当前扫描中探测到

    @classmethod
    def from_value(cls, v: int) -> "HotConnectStatus":
        if v == 1:
            return cls.PRESENT
        if v == 0:
            return cls.ABSENT
        return cls.UNKNOWN


@dataclass(frozen=True)
class HotConnectGroup:
    """
    Hot-Connect 组的一次性只读快照, 由 HotConnect.enumerate() 返回.
    字段对齐 C 端 ec_hotconnect_group_t (Pack=1).
    """
    group_id: int             # 用户分配的组 ID, 1..65535
    alias_address: int        # 期望 Alias 地址 (ESC 0x0012, 必须非 0)
    vendor_id: int            # 期望 VendorID, 0=不校验
    product_code: int         # 期望 ProductCode, 0=不校验
    is_present: bool          # 是否在当前扫描中探测到
    detected_slave_index: int # 探测到时匹配的 slavelist[] 下标, 0=未匹配

    @property
    def status(self) -> HotConnectStatus:
        """获取状态枚举封装."""
        return HotConnectStatus.PRESENT if self.is_present else HotConnectStatus.ABSENT

    def __str__(self) -> str:
        return (
            f"HotConnectGroup(id={self.group_id}, alias={self.alias_address}, "
            f"vendor=0x{self.vendor_id:X}, product=0x{self.product_code:X}, "
            f"present={self.is_present}, slave_idx={self.detected_slave_index})"
        )


class HotConnect:
    """
    Hot-Connect 组管理器
    对应 C# Master/HotConnect.cs

    用法:
        hc = HotConnect(dll, master_index=0)
        hc.add_group(group_id=1, alias=1001, vendor_id=0, product_code=0)
        groups = hc.enumerate()
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int = 0):
        """
        初始化 Hot-Connect 管理器.

        参数:
            dll:          DLL 接口
            master_index: 主站编号
        """
        self._dll = dll
        self._mi = master_index

    # ===================== Hot-Connect API =====================

    def add_group(self, group_id: int, alias: int,
                  vendor_id: int = 0, product_code: int = 0) -> bool:
        """
        注册一个 Hot-Connect 组.

        参数:
            group_id:     组 ID (1..65535, 同 master 唯一)
            alias:        期望 Alias 地址 (必须非 0)
            vendor_id:    期望 VendorID, 0=不校验
            product_code: 期望 ProductCode, 0=不校验

        返回:
            成功返回 True
        """
        fn = getattr(self._dll, "HotConnectAddGroup", None)
        if fn is None:
            return False
        try:
            rc = fn(self._mi, int(group_id) & 0xFFFF, int(alias) & 0xFFFF,
                    int(vendor_id) & 0xFFFFFFFF, int(product_code) & 0xFFFFFFFF)
            return rc == 0
        except (OSError, AttributeError, NotImplementedError):
            return False

    def remove_group(self, group_id: int) -> bool:
        """删除一个 Hot-Connect 组."""
        fn = getattr(self._dll, "HotConnectRemoveGroup", None)
        if fn is None:
            return False
        try:
            return fn(self._mi, int(group_id) & 0xFFFF) == 0
        except (OSError, AttributeError, NotImplementedError):
            return False

    def get_group_status(self, group_id: int) -> HotConnectStatus:
        """查询某个组的当前 Present/Absent 状态."""
        fn = getattr(self._dll, "HotConnectGetGroupStatus", None)
        if fn is None:
            return HotConnectStatus.UNKNOWN
        try:
            return HotConnectStatus.from_value(int(fn(self._mi, int(group_id) & 0xFFFF)))
        except (OSError, AttributeError, NotImplementedError):
            return HotConnectStatus.UNKNOWN

    def clear_all(self) -> None:
        """清空当前 master 所有 Hot-Connect 组 (通常在重新 SetNetwork 前调用)."""
        fn = getattr(self._dll, "HotConnectClearAll", None)
        if fn is None:
            return None
        try:
            fn(self._mi)
        except (OSError, AttributeError, NotImplementedError):
            pass
        return None

    def group_count(self) -> int:
        """当前已注册组数 (0=无 HC 配置, 所有从站 mandatory)."""
        fn = getattr(self._dll, "HotConnectGetGroupCount", None)
        if fn is None:
            return 0
        try:
            v = int(fn(self._mi))
            return v if v >= 0 else 0
        except (OSError, AttributeError, NotImplementedError):
            return 0

    def enumerate(self) -> List[HotConnectGroup]:
        """
        枚举所有已注册的 Hot-Connect 组.

        实现路径:
          1. 分配 (HotConnectGroupNative * MAX_GROUPS) 数组
          2. 调 dll.HotConnectEnumerate(master_index, byref(arr), MAX_GROUPS)
          3. 按返回的 count 解码出 HotConnectGroup 列表

        返回:
            HotConnectGroup 列表 (FFI 缺失或失败返回空列表)
        """
        fn = getattr(self._dll, "HotConnectEnumerate", None)
        if fn is None:
            return []
        try:
            arr = (HotConnectGroupNative * MAX_GROUPS)()
            count = int(fn(self._mi, arr, MAX_GROUPS))
            if count <= 0:
                return []
            count = min(count, MAX_GROUPS)
            result: List[HotConnectGroup] = []
            for i in range(count):
                n = arr[i]
                result.append(HotConnectGroup(
                    group_id=int(n.group_id),
                    alias_address=int(n.alias_address),
                    vendor_id=int(n.vendor_id),
                    product_code=int(n.product_code),
                    is_present=bool(n.is_present),
                    detected_slave_index=int(n.detected_slave_index),
                ))
            return result
        except (OSError, AttributeError, NotImplementedError):
            return []

    # ===================== 热插拔自修复事件 =====================
    # 热插拔 self-recovery 复用 SlaveIdentityMismatch 事件:
    #   - 注册:    master.events.subscribe_slave_identity_mismatch(...)
    #   - 确认:    dll.AcknowledgeSlaveReplacement(master_index, slave_index)
    # 此处不重复声明回调接口, 上层订阅 MasterEvents 的 SlaveIdentityMismatch 即可.

    def __repr__(self) -> str:
        return f"HotConnect(master={self._mi})"
