# -*- coding: utf-8 -*-
"""
对应 C# 文件: Master/MasterDiagnosticsInfo.cs
主站诊断信息扩展

注意: 核心诊断功能已在 diagnostics.py (MasterDiagnosticsInfo) 中实现。
此文件提供额外的诊断数据结构和辅助类型。
"""

from typing import Optional


class BreakPointInfo:
    """
    故障点信息 (断线或 CRC 故障)
    对应 C# MasterDiagnosticsInfo.BreakPointInfo
    """

    def __init__(self, slave_index: int, port: int, fault_type: int = 0):
        """
        初始化故障点信息

        参数:
            slave_index: 故障从站索引 (1-based)
            port:        故障端口号 (0-3, 对应 P0-P3)
            fault_type:  故障类型: 0=断线, 1=CRC故障
        """
        self.slave_index = slave_index
        self.port = port
        self.fault_type = fault_type

    @property
    def is_link_down(self) -> bool:
        """是否为断线故障"""
        return self.fault_type == 0

    @property
    def is_crc_fault(self) -> bool:
        """是否为 CRC 故障"""
        return self.fault_type == 1

    def __repr__(self) -> str:
        fault_desc = {0: "断线", 1: "CRC故障"}.get(self.fault_type, f"未知故障({self.fault_type})")
        return f"从站{self.slave_index} P{self.port} {fault_desc}"


class SlaveErrorCounters:
    """
    从站错误计数器 (寄存器 0x0300-0x0307)
    对应 C# SlaveErrorCounters
    """

    def __init__(self, slave_index: int = 0):
        self.slave_index = slave_index
        self.port0_crc_errors: int = 0
        self.port1_crc_errors: int = 0
        self.port2_crc_errors: int = 0
        self.port3_crc_errors: int = 0
        self.frame_errors: int = 0
        self.lost_frames: int = 0

    @property
    def total_crc_errors(self) -> int:
        """总 CRC 错误数"""
        return (self.port0_crc_errors + self.port1_crc_errors +
                self.port2_crc_errors + self.port3_crc_errors)

    def __repr__(self) -> str:
        return (f"SlaveErrors(slave={self.slave_index}, "
                f"crc={self.total_crc_errors}, frame={self.frame_errors})")
