# -*- coding: utf-8 -*-
"""
对应 C# 文件: Master/Other.cs
主站附加功能

包含:
- SlaveDiagnosticsData: 全局从站诊断数据快照
- 批量 SDO 预加载、看门狗设置、CPU 亲和性等
"""

from typing import Optional, List

from ..utils.dll import DarraCoreDLL


class SlaveDiagnosticsData:
    """
    全局从站诊断数据快照
    对应 C# SlaveDiagnosticsData 类
    """

    def __init__(self):
        # 各从站链路质量百分比 (0-100), 索引=从站编号(1-based)
        self.link_quality_percent: List[int] = []
        # 各从站端口错误合计
        self.port_error_count: List[int] = []
        # 各从站链路丢失计数
        self.lost_link_count: List[int] = []

        # 全局帧错误统计 (5秒滑动窗口)
        self.frame_errors: int = 0
        self.lost_frames: int = 0
        self.checksum_errors: int = 0
        self.timeout_frames: int = 0

        # WKC 统计
        self.working_counter_errors: int = 0
        self.consecutive_wkc_errors: int = 0

        # 冗余端口错误 (5秒滑动窗口)
        self.primary_port_errors: int = 0
        self.secondary_port_errors: int = 0


def get_slave_diagnostics(dll: DarraCoreDLL, master_index: int,
                          slave_count: int) -> Optional[SlaveDiagnosticsData]:
    """
    获取全局从站诊断数据快照

    参数:
        dll:          DLL 接口
        master_index: 主站编号
        slave_count:  从站数量

    返回:
        诊断数据快照, 失败返回 None
    """
    if slave_count <= 0:
        return None

    try:
        result = SlaveDiagnosticsData()
        result.link_quality_percent = [0] * (slave_count + 1)
        result.port_error_count = [0] * (slave_count + 1)
        result.lost_link_count = [0] * (slave_count + 1)

        for i in range(1, slave_count + 1):
            try:
                quality = dll.GetSlaveLinkQuality(master_index, i)
                result.link_quality_percent[i] = max(0, quality)
            except Exception:
                pass

        return result
    except Exception:
        return None


def set_all_slave_watchdog(dll: DarraCoreDLL, master_index: int,
                           timeout_ms: int) -> int:
    """
    批量设置所有从站的过程数据看门狗超时

    参数:
        dll:          DLL 接口
        master_index: 主站编号
        timeout_ms:   超时时间 (毫秒), 0=禁用

    返回:
        成功设置的从站数量
    """
    return dll.SetAllSlaveWatchdog(master_index, timeout_ms)


def set_all_slave_pdi_watchdog(dll: DarraCoreDLL, master_index: int,
                               timeout_ms: int) -> int:
    """为所有从站设置统一的 PDI 看门狗超时

    参数:
        dll:          DarraCoreDLL 实例
        master_index: 主站编号
        timeout_ms:   超时时间 (毫秒), 0=禁用

    返回:
        成功设置的从站数量
    """
    return dll.SetAllSlavePdiWatchdog(master_index, timeout_ms)


def get_cpu_cores(dll: DarraCoreDLL) -> int:
    """获取系统可用的 CPU 核心数"""
    return dll.GetAvailableCpuCores()


def set_cpu_affinity(dll: DarraCoreDLL, master_index: int,
                     base_cpu_core: int) -> bool:
    """设置主站线程 CPU 亲和性"""
    return bool(dll.SetMasterCpuAffinity(master_index, base_cpu_core))


def apply_realtime_optimizations(dll: DarraCoreDLL) -> None:
    """应用默认实时优化 (高精度定时器、内存锁定等)"""
    if not dll.GetRealtimeOptimizationsStatus():
        dll.ApplyRealtimeOptimizations()


def init_console_info(log_level: int = 0) -> None:
    """初始化控制台信息 (设置日志级别等)"""
    pass  # 当前为存根实现


# ===================== WDK 实时驱动 (对应 C# Other.cs WDK 部分) =====================

def is_wdk_available(dll: DarraCoreDLL, master_index: int) -> bool:
    """
    WDK 实时驱动是否可用

    参数:
        dll:          DLL 接口
        master_index: 主站编号

    返回:
        WDK 驱动是否可用
    """
    return bool(dll.IsWdkAvailable(master_index))


def is_wdk_mode(dll: DarraCoreDLL, master_index: int) -> bool:
    """
    当前是否处于 WDK 驱动模式

    参数:
        dll:          DLL 接口
        master_index: 主站编号

    返回:
        是否处于 WDK 模式
    """
    return bool(dll.GetWdkMode(master_index))


def set_wdk_mode(dll: DarraCoreDLL, master_index: int, enable: bool) -> bool:
    """
    设置 WDK 驱动模式

    参数:
        dll:          DLL 接口
        master_index: 主站编号
        enable:       是否启用 WDK 模式

    返回:
        是否成功
    """
    return bool(dll.SetWdkMode(master_index, enable))


def get_wdk_mode(dll: DarraCoreDLL, master_index: int) -> bool:
    """
    获取 WDK 驱动模式状态

    参数:
        dll:          DLL 接口
        master_index: 主站编号

    返回:
        WDK 模式是否启用
    """
    return bool(dll.GetWdkMode(master_index))


def start_wdk_rt(dll: DarraCoreDLL, master_index: int,
                 cycle_us: int, cpu_index: int) -> bool:
    """
    启动 WDK 实时线程

    参数:
        dll:          DLL 接口
        master_index: 主站编号
        cycle_us:     周期时间 (微秒)
        cpu_index:    绑定的 CPU 核心索引

    返回:
        是否成功
    """
    return bool(dll.StartWdkRT(master_index, cycle_us, cpu_index))


def stop_wdk_rt(dll: DarraCoreDLL, master_index: int) -> bool:
    """
    停止 WDK 实时线程

    参数:
        dll:          DLL 接口
        master_index: 主站编号

    返回:
        是否成功
    """
    return bool(dll.StopWdkRT(master_index))


# ===================== UDP 模式 (对应 C# Other.cs UDP 部分) =====================

def is_udp_available(dll: DarraCoreDLL, master_index: int) -> bool:
    """
    检查 UDP 模式是否可用 (双 Socket 是否初始化成功)

    参数:
        dll:          DLL 接口
        master_index: 主站编号

    返回:
        UDP 模式是否可用
    """
    return bool(dll.IsUdpAvailable(master_index))


def set_udp_mode(dll: DarraCoreDLL, master_index: int, enable: bool) -> bool:
    """
    设置 UDP 帧模式

    参数:
        dll:          DLL 接口
        master_index: 主站编号
        enable:       是否启用

    返回:
        是否成功
    """
    return bool(dll.SetUdpMode(master_index, enable))


def get_udp_mode(dll: DarraCoreDLL, master_index: int) -> bool:
    """
    获取 UDP 帧模式状态

    参数:
        dll:          DLL 接口
        master_index: 主站编号

    返回:
        UDP 模式是否启用
    """
    return bool(dll.GetUdpMode(master_index))


# ===================== CPU 亲和性 (对应 C# Other.cs CPU 部分) =====================

def set_master_cpu_affinity(dll: DarraCoreDLL, master_index: int,
                            core: int) -> bool:
    """
    设置主站线程 CPU 亲和性

    以基准核心为起点, 向低核心号分配: PDO(基准) -> DC诊断(基准-1) -> StateGuard(基准-2)

    参数:
        dll:          DLL 接口
        master_index: 主站编号
        core:         基准 CPU 核心索引

    返回:
        是否成功
    """
    return bool(dll.SetMasterCpuAffinity(master_index, core))


def get_master_cpu_affinity(dll: DarraCoreDLL) -> int:
    """
    获取系统可用的 CPU 核心数

    参数:
        dll: DLL 接口

    返回:
        CPU 核心数
    """
    return dll.GetAvailableCpuCores()


def set_pdo_thread_cpu_affinity(dll: DarraCoreDLL, master_index: int,
                                core: int) -> bool:
    """
    设置 PDO 线程 CPU 亲和性

    参数:
        dll:          DLL 接口
        master_index: 主站编号
        core:         CPU 核心索引

    返回:
        是否成功
    """
    return bool(dll.SetPDOThreadCpuAffinity(master_index, core))


def get_pdo_thread_cpu_affinity(dll: DarraCoreDLL, master_index: int) -> int:
    """
    获取 PDO 线程绑定的 CPU 核心

    参数:
        dll:          DLL 接口
        master_index: 主站编号

    返回:
        CPU 核心索引, -1 表示未设置 (自动配置)
    """
    return dll.GetPDOThreadCpuAffinity(master_index)


# ===================== 实时优化 (对应 C# Other.cs 实时优化部分) =====================

def remove_realtime_optimizations(dll: DarraCoreDLL) -> bool:
    """
    移除实时优化 (高精度定时器、内存锁定等)

    参数:
        dll: DLL 接口

    返回:
        是否成功
    """
    return bool(dll.RemoveRealtimeOptimizations())


def get_timing_mode(dll: DarraCoreDLL, master_index: int) -> int:
    """
    获取定时模式

    参数:
        dll:          DLL 接口
        master_index: 主站编号

    返回:
        定时模式: 0=未知, 1=硬件(APIC), 2=软件(QPC), 3=降级
    """
    return dll.GetTimingMode(master_index)


def get_realtime_status(dll: DarraCoreDLL) -> bool:
    """
    查询实时优化是否已应用

    参数:
        dll: DLL 接口

    返回:
        是否已应用实时优化
    """
    return bool(dll.GetRealtimeOptimizationsStatus())


# ===================== 看门狗增强 (对应 C# Other.cs 看门狗部分) =====================

def get_slave_watchdog_config(dll: DarraCoreDLL, master_index: int,
                              slave_index: int) -> Optional[dict]:
    """
    获取从站看门狗配置

    参数:
        dll:          DLL 接口
        master_index: 主站编号
        slave_index:  从站索引

    返回:
        配置字典 {'divider': int, 'sm_timeout': int, 'pdi_timeout': int},
        失败返回 None
    """
    from ..utils.dll import WatchdogConfig
    cfg = WatchdogConfig()
    ok = dll.GetSlaveWatchdogConfig(master_index, slave_index, cfg)
    if not ok:
        return None
    return {
        'divider': cfg.wd_divider,
        'sm_timeout': cfg.wd_time_pd,
        'pdi_timeout': cfg.wd_time_pdi,
    }


# ===================== 热插拔自修复 (v2) =====================

def acknowledge_slave_replacement(dll: DarraCoreDLL, master_index: int,
                                  slave_num: int) -> bool:
    """
    用户确认从站替换完毕, 触发 ident FSM 重新探测

    调用时机: 订阅 master.events.add_slave_identity_mismatch() 接收到身份不符报警后,
    操作员检查 / 更换设备完毕, 调用本函数让 SDK 重新检测。

    行为:
    - 若身份已纠正 (换回正确设备 / 同型号升级 Revision) -> 自动恢复并触发 SlaveOnline
    - 若身份仍不匹配 -> 再次触发 SlaveIdentityMismatch, 回到 IDENT_REJECTED

    参数:
        dll:          DLL 接口
        master_index: 主站编号
        slave_num:    从站编号 (1-based, 与配置一致)

    返回:
        True=已接受并复位 FSM; False=参数无效, 或从站当前不在 IDENT_REJECTED / FAILED 状态
    """
    if slave_num <= 0 or slave_num > 0xFFFF:
        return False
    try:
        return bool(dll.AcknowledgeSlaveReplacement(master_index, slave_num))
    except AttributeError:
        return False


def get_slave_watchdog_status(dll: DarraCoreDLL, master_index: int,
                              slave_index: int) -> Optional[dict]:
    """
    获取从站看门狗详细状态

    参数:
        dll:          DLL 接口
        master_index: 主站编号
        slave_index:  从站索引

    返回:
        状态字典 {'status': int, 'counter': int, 'divider': int, 'timeout': int},
        失败返回 None
    """
    from ..utils.dll import WatchdogStatus
    st = WatchdogStatus()
    ok = dll.GetSlaveWatchdogStatus(master_index, slave_index, st)
    if not ok:
        return None
    return {
        'status': st.wd_status,
        'counter': st.wd_counter,
        'divider': st.wd_divider,
        'timeout': st.wd_time_pd,
    }
