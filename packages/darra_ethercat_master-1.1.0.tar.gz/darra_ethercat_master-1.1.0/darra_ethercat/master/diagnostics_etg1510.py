# -*- coding: utf-8 -*-
"""
对应 C# 文件: Master/MasterDiagnostics_ETG1510.cs
ETG.1510 主站诊断接口扩展

注意: ETG.1510 主站对象字典核心功能已在 master_od.py (MasterObjectDictionary)
中完整实现。此文件为 ETG.1510 规范提供额外的辅助定义和常量。
"""

from typing import Optional

# ETG.1510 对象索引范围定义
ETG1510_DEVICE_TYPE          = 0x1000  # Device Type
ETG1510_DEVICE_NAME          = 0x1008  # Manufacturer Device Name
ETG1510_HW_VERSION           = 0x1009  # Manufacturer Hardware Version
ETG1510_SW_VERSION           = 0x100A  # Manufacturer Software Version
ETG1510_IDENTITY             = 0x1018  # Identity Object
ETG1510_CONFIG_DATA_BASE     = 0x8000  # Configuration Data (从站配置)
ETG1510_INFO_DATA_BASE       = 0x9000  # Information Data (从站信息)
ETG1510_DIAG_DATA_BASE       = 0xA000  # Diagnosis Data (从站诊断)
ETG1510_DETECT_MODULES       = 0xF002  # Detect Modules Command
ETG1510_MASTER_DIAG          = 0xF120  # Master Diag Data
ETG1510_DIAG_INTERFACE       = 0xF200  # Diag Interface Control


class ALErrorClassifier:
    """AL 状态码错误分类器"""

    @staticmethod
    def classify(status_code: int) -> str:
        """
        根据 AL Status Code 分类错误类型

        参数:
            status_code: AL 状态码

        返回:
            错误分类描述
        """
        if status_code == 0:
            return "无错误"
        elif 0x0001 <= status_code <= 0x000F:
            return "通用错误"
        elif 0x0010 <= status_code <= 0x001F:
            return "启动错误"
        elif 0x0020 <= status_code <= 0x002F:
            return "邮箱错误"
        elif 0x0030 <= status_code <= 0x003F:
            return "看门狗错误"
        elif 0x0040 <= status_code <= 0x004F:
            return "同步错误"
        elif 0x0050 <= status_code <= 0x005F:
            return "分布式时钟错误"
        elif 0x0060 <= status_code <= 0x006F:
            return "MBX/Eoe 错误"
        return f"未知错误 (0x{status_code:04X})"


class SlaveDiagData:
    """
    ETG.1510 从站诊断数据
    对应 C# SlaveDiagData 结构体
    """

    def __init__(self):
        self.al_status_extended: int = 0
        """扩展 AL 状态码"""
        self.last_al_status_code: int = 0
        """最后的 AL 错误码"""
        self.last_coe_soe_protocol_error: int = 0
        """最后的 CoE/SoE 协议错误"""
        self.cyclic_wc_error_counter: int = 0
        """WKC 错误计数器"""
        self.new_diag_messages_available: bool = False
        """是否有新的诊断消息"""
        self.disable_automatic_link_control: bool = False
        """是否禁用自动链路控制"""

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            'al_status_extended': self.al_status_extended,
            'last_al_status_code': self.last_al_status_code,
            'last_coe_soe_protocol_error': self.last_coe_soe_protocol_error,
            'cyclic_wc_error_counter': self.cyclic_wc_error_counter,
            'new_diag_messages_available': self.new_diag_messages_available,
            'disable_automatic_link_control': self.disable_automatic_link_control,
        }


class ETG1510DiagInterface:
    """
    ETG.1510 诊断接口
    对应 C# MasterDiagnostics_ETG1510 的诊断相关方法
    """

    def __init__(self, master_od):
        """
        初始化诊断接口

        参数:
            master_od: MasterObjectDictionary 实例
        """
        self._od = master_od
        self._slave_diag: dict = {}

    def write_master_object(self, index: int, subindex: int, data: bytes) -> bool:
        """
        写入主站对象字典对象 (对应 C# WriteMasterObject)

        参数:
            index:    对象索引
            subindex: 子索引
            data:     要写入的数据字节
        返回:
            是否成功
        """
        return self._od.write_object(index, subindex, data)

    def read_master_object(self, index: int, subindex: int) -> Optional[bytes]:
        """
        读取主站对象字典对象

        参数:
            index:    对象索引
            subindex: 子索引
        返回:
            对象数据字节, 失败返回 None
        """
        return self._od.read_object(index, subindex)

    # ---- ETG.1510 OD 路由 (托管实装, 对齐 Java readEtg1510Object/writeEtg1510Object) ----
    # DLL 未导出 Diag_Etg1510Read / Diag_Etg1510Write 时, 走现有 master SDO API
    # 路由 (slave_index=0). 主站自身的 ETG.1510 OD 由 MasterObjectDictionary
    # 在 Python 端实装 (master_od.py); 真实 ETG.1510 主从协商需 DLL 补齐 FFI.
    # 各语言惯用法: Java 直接调 Diag_Etg1510Read (DLL); Python 走托管 OD 路由.

    def read_etg1510_object(self, index: int, subindex: int = 0,
                            slave_index: int = 0) -> Optional[bytes]:
        """
        通过 ETG.1510 OD 读取主站对象 (托管路由).

        对应 Java readEtg1510Object / C# DarraEtherCAT.ReadMasterObject.
        DLL 未导出 Diag_Etg1510Read 时, 路由到 master SDO API:
          - slave_index == 0: 走 MasterObjectDictionary.read_object (主站自身 OD)
          - slave_index >  0: 走从站 CoE.sdo_read (透传到具体从站)

        参数:
            index:       OD 索引 (0x1000-0xFFFF)
            subindex:    OD 子索引
            slave_index: 0=主站自身 OD; >0=透传到指定从站 CoE
        返回:
            读取的字节数据, 失败返回 None
        """
        try:
            if slave_index == 0:
                return self._od.read_object(index, subindex)
            master = getattr(self._od, '_master', None)
            if master is None:
                return None
            slave = master.slave(slave_index)
            if slave is None or not hasattr(slave, 'coe'):
                return None
            return slave.coe.sdo_read(index, subindex)
        except Exception:
            return None

    def write_etg1510_object(self, index: int, subindex: int, data: bytes,
                             slave_index: int = 0) -> bool:
        """
        通过 ETG.1510 OD 写入主站对象 (托管路由).

        对应 Java writeEtg1510Object / C# DarraEtherCAT.WriteMasterObject.
        DLL 未导出 Diag_Etg1510Write 时, 路由到 master SDO API:
          - slave_index == 0: 走 MasterObjectDictionary.write_object (主站自身 OD)
          - slave_index >  0: 走从站 CoE.sdo_write

        参数:
            index:       OD 索引 (0x1000-0xFFFF)
            subindex:    OD 子索引
            data:        写入字节 (不可为 None)
            slave_index: 0=主站自身 OD; >0=透传到指定从站 CoE
        返回:
            写盘成功返回 True; 参数非法 / 失败返回 False
        """
        if data is None:
            return False
        try:
            if slave_index == 0:
                return bool(self._od.write_object(index, subindex, data))
            master = getattr(self._od, '_master', None)
            if master is None:
                return False
            slave = master.slave(slave_index)
            if slave is None or not hasattr(slave, 'coe'):
                return False
            return bool(slave.coe.sdo_write(index, subindex, data))
        except Exception:
            return False

    def al_status_extended(self, slave_index: int) -> int:
        """
        获取从站扩展 AL 状态码

        参数:
            slave_index: 从站索引
        返回:
            AL 状态码
        """
        diag = self._get_slave_diag(slave_index)
        return diag.al_status_extended if diag else 0

    def last_al_status_code(self, slave_index: int) -> int:
        """
        获取从站最后的 AL 错误码

        参数:
            slave_index: 从站索引
        返回:
            AL 错误码
        """
        diag = self._get_slave_diag(slave_index)
        return diag.last_al_status_code if diag else 0

    def last_coe_soe_protocol_error(self, slave_index: int) -> int:
        """
        获取从站最后的 CoE/SoE 协议错误

        参数:
            slave_index: 从站索引
        返回:
            协议错误码
        """
        diag = self._get_slave_diag(slave_index)
        return diag.last_coe_soe_protocol_error if diag else 0

    def cyclic_wc_error_counter(self, slave_index: int) -> int:
        """
        获取从站 WKC 错误计数器

        参数:
            slave_index: 从站索引
        返回:
            WKC 错误计数
        """
        diag = self._get_slave_diag(slave_index)
        return diag.cyclic_wc_error_counter if diag else 0

    def new_diag_messages_available(self, slave_index: int) -> bool:
        """
        检查从站是否有新诊断消息

        参数:
            slave_index: 从站索引
        返回:
            是否有新消息
        """
        diag = self._get_slave_diag(slave_index)
        return diag.new_diag_messages_available if diag else False

    def disable_automatic_link_control(self, slave_index: int) -> bool:
        """
        获取从站自动链路控制是否已禁用

        参数:
            slave_index: 从站索引
        返回:
            是否已禁用
        """
        diag = self._get_slave_diag(slave_index)
        return diag.disable_automatic_link_control if diag else False

    def _get_slave_diag(self, slave_index: int) -> Optional[SlaveDiagData]:
        """获取从站诊断数据 (内部方法)"""
        if slave_index in self._slave_diag:
            return self._slave_diag[slave_index]
        # 尝试从 OD 读取
        data = self._od.read_object(0xA000 + slave_index, 0)
        if data and len(data) >= 12:
            import struct as st
            diag = SlaveDiagData()
            diag.al_status_extended = st.unpack_from('<H', data, 0)[0]
            diag.last_al_status_code = st.unpack_from('<H', data, 2)[0]
            diag.cyclic_wc_error_counter = st.unpack_from('<I', data, 4)[0]
            diag.last_coe_soe_protocol_error = st.unpack_from('<I', data, 8)[0]
            if len(data) >= 14:
                flags = data[12]
                diag.disable_automatic_link_control = bool(flags & 0x01)
                diag.new_diag_messages_available = bool(flags & 0x02)
            self._slave_diag[slave_index] = diag
            return diag
        return None


def get_object_name(index: int) -> str:
    """获取 ETG.1510 对象名称"""
    if index == 0x1000:
        return "Device Type"
    elif index == 0x1008:
        return "Manufacturer Device Name"
    elif index == 0x1009:
        return "Manufacturer Hardware Version"
    elif index == 0x100A:
        return "Manufacturer Software Version"
    elif index == 0x1018:
        return "Identity Object"
    elif 0x8000 <= index <= 0x8FFF:
        return f"Configuration Data Slave {index & 0x0FFF}"
    elif 0x9000 <= index <= 0x9FFF:
        return f"Information Data Slave {index & 0x0FFF}"
    elif 0xA000 <= index <= 0xAFFF:
        return f"Diagnosis Data Slave {index & 0x0FFF}"
    elif index == 0xF002:
        return "Detect Modules Command"
    elif index == 0xF120:
        return "Master Diag Data"
    elif index == 0xF200:
        return "Diag Interface Control"
    return "Unknown"
