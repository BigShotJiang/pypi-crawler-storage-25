# -*- coding: utf-8 -*-
"""
主站诊断信息类 - 帧/错误/抖动统计使用5秒滑动窗口，0.2秒刷新

通过 master.diagnostics_info 访问。
对应 C# MasterDiagnosticsInfo 类。
"""

import ctypes
import threading
import time
from ctypes import c_uint, c_ushort, c_int, c_double, c_ubyte, c_short, c_byte, Structure
from typing import Optional, TYPE_CHECKING
from dataclasses import dataclass

if TYPE_CHECKING:
    from .core import EtherCATMaster


# ===================== 原生结构体 (零拷贝指针访问) =====================

class _NativeSummary(Structure):
    """对应 C 端 ec_diagnostics_summary_t"""
    _fields_ = [
        ("total_errors", c_uint),
        ("error_rate_per_1000", c_double),
        ("worst_link_quality", c_short),
        ("worst_slave_index", c_ushort),
        # 网口状态
        ("redundancy_active", c_int),
        ("primary_port_ok", c_int),
        ("secondary_port_ok", c_int),
        ("primary_port_errors_window", c_uint),
        ("secondary_port_errors_window", c_uint),
        # 应用实时性能 (PDO 线程)
        ("rt_frequency", c_uint),
        ("cycle_time_us", c_uint),
        ("packet_loss_percent", c_double),
        ("avg_jitter_us", c_double),
        ("max_jitter_us", c_double),
        ("avg_cycle_time_us", c_double),
        # 总线实时性能 (RT 内核线程)
        ("bus_avg_jitter_us", c_double),
        ("bus_max_jitter_us", c_double),
        ("bus_clean_max_jitter_us", c_double),  # 干净最大抖动 (排除SMI)
        ("bus_cycle_hz", c_uint),
        ("bus_roundtrip_us", c_double),  # 报文往返延迟 (µs)
        ("smi_count", c_uint),           # SMI累计次数
        ("smi_peak_us", c_double),       # SMI峰值抖动 (µs)
        # 拓扑
        ("topology_mode", c_ubyte),
        ("_reserved", c_ubyte),
        ("break_point_count", c_short),
    ]


class _InternalDiagnostics(Structure):
    """对应 C 端内部诊断结构体 (用于直接指针访问)"""
    _fields_ = [
        ("cycle_count", c_uint),
        ("frame_errors", c_uint),
        ("lost_frames", c_uint),
        ("checksum_errors", c_uint),
        ("timeout_frames", c_uint),
        ("CycleTimeSpan", c_uint),
        ("WKC", c_ushort),
        ("ExpectedWKC", c_ushort),
        ("jitter_accumulator", c_double),
        ("jitter_sample_count", c_uint),
        ("max_jitter_in_second", c_double),
    ]


# ===================== PDO 丢帧诊断 =====================

@dataclass
class PDOFrameLossStats:
    """PDO 丢帧统计"""
    total_lost: int = 0       # 累计丢帧数
    consecutive_lost: int = 0 # 当前连续丢帧数
    max_consecutive: int = 0  # 历史最大连续丢帧数

    def __str__(self) -> str:
        return (f"累计丢帧={self.total_lost}, "
                f"连续丢帧={self.consecutive_lost}, "
                f"最大连续={self.max_consecutive}")


class MasterPDODiagnostics:
    """PDO 丢帧诊断。通过 master.diagnostics_info.pdo 访问。"""

    def __init__(self, diag: 'MasterDiagnosticsInfo'):
        self._diag = diag

    def _read_group(self, group: int) -> PDOFrameLossStats:
        """读取指定组的 PDO 丢帧统计"""
        total = c_uint(0)
        consecutive = c_uint(0)
        max_consecutive = c_uint(0)
        self._diag._master._dll.GetPDOFrameLossStats(
            self._diag._mi, group,
            ctypes.byref(total),
            ctypes.byref(consecutive),
            ctypes.byref(max_consecutive),
        )
        return PDOFrameLossStats(
            total_lost=total.value,
            consecutive_lost=consecutive.value,
            max_consecutive=max_consecutive.value,
        )

    def _read_all_groups(self) -> PDOFrameLossStats:
        """读取所有组的 PDO 丢帧统计汇总"""
        total_sum = 0
        consecutive_max = 0
        max_consecutive_max = 0
        for g in range(8):
            stats = self._read_group(g)
            total_sum += stats.total_lost
            consecutive_max = max(consecutive_max, stats.consecutive_lost)
            max_consecutive_max = max(max_consecutive_max, stats.max_consecutive)
        return PDOFrameLossStats(
            total_lost=total_sum,
            consecutive_lost=consecutive_max,
            max_consecutive=max_consecutive_max,
        )

    @property
    def total_lost(self) -> int:
        """累计丢帧数（所有组合计）"""
        return self._read_all_groups().total_lost

    @property
    def consecutive_lost(self) -> int:
        """当前连续丢帧数（所有组中最大值）"""
        return self._read_all_groups().consecutive_lost

    def get_frame_loss_stats(self, group: int = 255) -> PDOFrameLossStats:
        """
        获取 PDO 丢帧统计

        参数:
            group: 组号 (0-7)。不传参数或传 255 时返回所有组汇总

        返回:
            PDOFrameLossStats 统计数据
        """
        if group > 7:
            return self._read_all_groups()
        return self._read_group(group)


# ===================== 主站诊断信息类 =====================

class MasterDiagnosticsInfo:
    """
    主站诊断信息类 - 帧/错误/抖动统计使用5秒滑动窗口，0.2秒刷新

    通过 master.diagnostics_info 访问。
    """

    # 滑动窗口配置
    _SAMPLE_INTERVAL_S = 0.2   # 0.2秒采样间隔
    _WINDOW_SIZE = 25           # 25 x 0.2s = 5秒窗口

    def __init__(self, master: 'EtherCATMaster'):
        self._master = master
        self._mi = master._mi
        self._dll = master._dll

        # 滑动窗口数据
        self._lock = threading.Lock()
        self._cycle_delta = [0] * self._WINDOW_SIZE
        self._error_delta = [0] * self._WINDOW_SIZE
        self._elapsed_ms_delta = [0.0] * self._WINDOW_SIZE
        self._max_jitter_sample = [0.0] * self._WINDOW_SIZE
        self._jitter_acc_delta = [0.0] * self._WINDOW_SIZE
        self._jitter_count_delta = [0] * self._WINDOW_SIZE
        self._head = 0
        self._filled = 0

        # 上一次采样的值
        self._prev_cycles = 0
        self._prev_errors = 0
        self._prev_jitter_acc = 0.0
        self._prev_jitter_count = 0
        self._prev_time = 0.0
        self._initialized = False

        # 定时器
        self._timer: Optional[threading.Timer] = None
        self._timer_running = False

        # PDO 诊断
        self._pdo: Optional[MasterPDODiagnostics] = None

    # ===================== 诊断开关 =====================

    @property
    def enabled(self) -> bool:
        """
        诊断数据采集开关。启用后开始记录帧计数、抖动、错误率等统计数据。
        默认关闭。PDO 丢帧统计、冗余检测、DC 同步等功能不受此开关影响。
        """
        return bool(self._dll.GetDiagnosticsEnabled(self._mi))

    @enabled.setter
    def enabled(self, value: bool):
        self._dll.SetDiagnosticsEnabled(self._mi, value)
        if value:
            self._start_sampling()
        else:
            self._stop_sampling()

    # ===================== 采样定时器 =====================

    def _start_sampling(self):
        """启动采样定时器"""
        with self._lock:
            if self._timer_running:
                return
            self._timer_running = True
        self._schedule_next()

    def _stop_sampling(self):
        """停止采样定时器"""
        with self._lock:
            self._timer_running = False
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
            self._head = 0
            self._filled = 0
            self._initialized = False

    def _schedule_next(self):
        """安排下一次采样"""
        if not self._timer_running:
            return
        self._timer = threading.Timer(self._SAMPLE_INTERVAL_S, self._sample_callback)
        self._timer.daemon = True
        self._timer.start()

    def _sample_callback(self):
        """采样回调"""
        if not self._timer_running:
            return
        try:
            self._do_sample()
        except Exception:
            pass
        self._schedule_next()

    def _do_sample(self):
        """执行一次采样"""
        diag_ptr = self._dll.GetDiagnosticsPointer(self._mi)
        if not diag_ptr:
            return

        diag = ctypes.cast(diag_ptr, ctypes.POINTER(_InternalDiagnostics)).contents

        cycles = diag.cycle_count
        errors = (diag.frame_errors + diag.lost_frames
                  + diag.checksum_errors + diag.timeout_frames)
        jitter_acc = diag.jitter_accumulator
        jitter_count = diag.jitter_sample_count
        max_jitter = diag.max_jitter_in_second

        now = time.perf_counter()

        with self._lock:
            if not self._initialized:
                self._prev_cycles = cycles
                self._prev_errors = errors
                self._prev_jitter_acc = jitter_acc
                self._prev_jitter_count = jitter_count
                self._prev_time = now
                self._initialized = True
                return

            elapsed_ms = (now - self._prev_time) * 1000.0

            # 溢出保护: 经过时间为负数或超大值(>10秒)时跳过该采样点
            if elapsed_ms <= 0 or elapsed_ms > 10000:
                self._prev_time = now
                return

            # 无符号差值 (模拟 uint32 溢出)
            d_cycles = (cycles - self._prev_cycles) & 0xFFFFFFFF
            d_errors = (errors - self._prev_errors) & 0xFFFFFFFF

            # 溢出保护: 周期差值异常大时跳过
            if d_cycles > 1000000:
                self._prev_cycles = cycles
                self._prev_errors = errors
                self._prev_jitter_acc = jitter_acc
                self._prev_jitter_count = jitter_count
                self._prev_time = now
                return

            # 抖动增量
            if jitter_acc >= self._prev_jitter_acc and jitter_count >= self._prev_jitter_count:
                d_jitter_acc = jitter_acc - self._prev_jitter_acc
                d_jitter_count = jitter_count - self._prev_jitter_count
            else:
                d_jitter_acc = jitter_acc
                d_jitter_count = jitter_count

            self._cycle_delta[self._head] = d_cycles
            self._error_delta[self._head] = d_errors
            self._elapsed_ms_delta[self._head] = elapsed_ms
            self._jitter_acc_delta[self._head] = d_jitter_acc
            self._jitter_count_delta[self._head] = d_jitter_count
            self._max_jitter_sample[self._head] = max_jitter
            self._head = (self._head + 1) % self._WINDOW_SIZE
            if self._filled < self._WINDOW_SIZE:
                self._filled += 1

            self._prev_cycles = cycles
            self._prev_errors = errors
            self._prev_jitter_acc = jitter_acc
            self._prev_jitter_count = jitter_count
            self._prev_time = now

    # ===================== 5秒窗口聚合 =====================

    def _get_window_totals(self):
        """获取滑动窗口内的汇总值"""
        with self._lock:
            total_cycles = 0
            total_errors = 0
            total_ms = 0.0
            for i in range(self._filled):
                total_cycles += self._cycle_delta[i]
                total_errors += self._error_delta[i]
                total_ms += self._elapsed_ms_delta[i]
            return total_cycles, total_errors, total_ms

    def _get_summary(self) -> Optional[_NativeSummary]:
        """获取零拷贝摘要数据"""
        ptr = self._dll.GetSummaryPointer(self._mi)
        if not ptr:
            return None
        return ctypes.cast(ptr, ctypes.POINTER(_NativeSummary)).contents

    # ===================== PDO 通信状态 =====================

    @property
    def packet_loss_rate(self) -> float:
        """丢包率 (0.0 ~ 1.0) — 最近 5 秒滑窗.

        用户原话 (2026-04-27): "丢包率 = 发出 vs 接收, 过慢 (pipeline) 不算".
        算法: max(0, ΣTX - ΣRX - 2 帧 pipeline) / ΣTX, 内核统一计算 (单一数据源).
        对齐 C# PacketLossRate.
        """
        return float(self._dll.GetPacketLossRate(self._mi))

    @property
    def late_frame_rate(self) -> float:
        """过慢帧率 (0.0 ~ 1.0) — 最近 5 秒滑窗.
        idx 出 8 帧窗的 stale 帧 kernel drop, 不计入丢包.
        全双工正常 pipeline 下不该出现. 对齐 C# LateFrameRate.
        """
        return float(self._dll.GetLateFrameRate(self._mi))

    @property
    def rt_cnt(self) -> int:
        """每秒帧数 (Hz) - WDK 模式返回总线频率, Npcap 返回 PDO 频率"""
        # WDK Offload: 返回 RT 线程的真实总线频率
        s = self._get_summary()
        if s is not None and s.bus_cycle_hz > 0:
            return int(s.bus_cycle_hz)
        # Npcap: 返回 PDO 线程频率
        cycles, _, total_ms = self._get_window_totals()
        if total_ms < 1.0:
            return 0
        return int(cycles * 1000.0 / total_ms)

    @property
    def error_cnt(self) -> int:
        """每秒错误数，5秒平均"""
        _, errors, total_ms = self._get_window_totals()
        if total_ms < 1.0:
            return 0
        return int(errors * 1000.0 / total_ms)

    @property
    def cycle_time_span(self) -> int:
        """实际周期时间 (微秒) - 实时值"""
        diag_ptr = self._dll.GetDiagnosticsPointer(self._mi)
        if not diag_ptr:
            return 0
        diag = ctypes.cast(diag_ptr, ctypes.POINTER(_InternalDiagnostics)).contents
        return int(diag.CycleTimeSpan)

    # ===================== 抖动与频率 =====================

    @property
    def avg_jitter_us(self) -> float:
        """平均抖动 (us) - WDK 模式返回总线抖动, Npcap 返回 PDO 抖动"""
        # WDK Offload: 返回 RT 线程的真实总线抖动
        s = self._get_summary()
        if s is not None and s.bus_cycle_hz > 0:
            return s.bus_avg_jitter_us
        # Npcap: 返回 PDO 线程抖动
        with self._lock:
            total_acc = 0.0
            total_count = 0
            for i in range(self._filled):
                total_acc += self._jitter_acc_delta[i]
                total_count += self._jitter_count_delta[i]
            return total_acc / total_count if total_count > 0 else 0.0

    @property
    def max_jitter_us(self) -> float:
        """最大抖动 (us) - WDK 模式返回总线抖动, Npcap 返回 PDO 抖动"""
        # WDK Offload: 返回 RT 线程的真实总线最大抖动
        s = self._get_summary()
        if s is not None and s.bus_cycle_hz > 0:
            return s.bus_max_jitter_us
        # Npcap: 返回 PDO 线程最大抖动
        with self._lock:
            max_val = 0.0
            for i in range(self._filled):
                if self._max_jitter_sample[i] > max_val:
                    max_val = self._max_jitter_sample[i]
            return max_val

    @property
    def bus_cycle_hz(self) -> int:
        """总线频率 (Hz) - RT 内核线程的实际帧发送频率"""
        s = self._get_summary()
        return int(s.bus_cycle_hz) if s is not None else 0

    @property
    def bus_max_jitter_us(self) -> float:
        """总线最大抖动 (us) - RT 内核线程的帧发送时序偏差"""
        s = self._get_summary()
        return s.bus_max_jitter_us if s is not None else 0.0

    @property
    def bus_avg_jitter_us(self) -> float:
        """总线平均抖动 (us)"""
        s = self._get_summary()
        return s.bus_avg_jitter_us if s is not None else 0.0

    @property
    def bus_roundtrip_us(self) -> float:
        """报文往返延迟 (µs, 发送→接收) - 对齐 C# BusRoundtripUs"""
        s = self._get_summary()
        return s.bus_roundtrip_us if s is not None else 0.0

    @property
    def bus_load_percent(self) -> float:
        """通讯负载 (%) — 一个 PDO 周期内, 报文发送到接收占用的时间百分比.

        计算: bus_roundtrip_us / cycle_time_span × 100.

        含义:
            <30%  健康, 链路宽裕
            30-70% 中等, 升频率/加从站需谨慎
            >70%  接近极限, 必须降频或减少从站

        对齐 C# BusLoadPercent.
        """
        rtt = self.bus_roundtrip_us
        cycle_us = self.cycle_time_span
        if cycle_us <= 0 or rtt <= 0.0:
            return 0.0
        pct = rtt / float(cycle_us) * 100.0
        return 100.0 if pct > 100.0 else pct

    @property
    def bus_clean_max_jitter_us(self) -> float:
        """总线干净最大抖动 (us, 排除SMI) - 对齐 C# BusCleanMaxJitterUs"""
        s = self._get_summary()
        return s.bus_clean_max_jitter_us if s is not None else 0.0

    @property
    def smi_count(self) -> int:
        """SMI累计次数 - 对齐 C# SmiCount"""
        s = self._get_summary()
        return int(s.smi_count) if s is not None else 0

    @property
    def smi_peak_us(self) -> float:
        """SMI峰值抖动 (us) - 对齐 C# SmiPeakUs"""
        s = self._get_summary()
        return s.smi_peak_us if s is not None else 0.0

    # ===================== 网口状态 =====================

    @property
    def primary_port_ok(self) -> bool:
        """主端口是否正常（有流量且5秒内无错误）"""
        s = self._get_summary()
        return s is not None and s.primary_port_ok != 0

    @property
    def secondary_port_ok(self) -> bool:
        """副端口是否正常（有流量且5秒内无错误，无冗余时始终 False）"""
        s = self._get_summary()
        return s is not None and s.secondary_port_ok != 0

    @property
    def primary_port_errors(self) -> int:
        """主端口最近5秒错误数"""
        s = self._get_summary()
        return int(s.primary_port_errors_window) if s is not None else 0

    @property
    def secondary_port_errors(self) -> int:
        """副端口最近5秒错误数"""
        s = self._get_summary()
        return int(s.secondary_port_errors_window) if s is not None else 0

    @property
    def redundancy_active(self) -> bool:
        """冗余是否激活（双端口均有流量）"""
        s = self._get_summary()
        return s is not None and s.redundancy_active != 0

    # ===================== 从站链路与断线 =====================

    @property
    def worst_slave_index(self) -> int:
        """最差链路质量的从站索引"""
        s = self._get_summary()
        return int(s.worst_slave_index) if s is not None else 0

    @property
    def worst_link_quality(self) -> int:
        """最差链路质量百分比 (0-100%)"""
        s = self._get_summary()
        return int(s.worst_link_quality) if s is not None else 100

    # ===================== DC 同步窗口 =====================

    @property
    def sync_window_threshold(self) -> int:
        """DC 同步窗口阈值（纳秒），超过阈值触发 DCSyncLost 事件"""
        return self._dll.GetSyncWindowThreshold(self._mi)

    @sync_window_threshold.setter
    def sync_window_threshold(self, value: int):
        self._dll.SetSyncWindowThreshold(self._mi, value)

    # ===================== PDO 丢帧诊断 =====================

    @property
    def pdo(self) -> MasterPDODiagnostics:
        """PDO 丢帧诊断。通过 master.diagnostics_info.pdo 访问。"""
        if self._pdo is None:
            self._pdo = MasterPDODiagnostics(self)
        return self._pdo

    # ===================== 控制 =====================

    def reset(self):
        """重置所有诊断统计"""
        self._dll.ResetDiagnostics(self._mi)
        for g in range(8):
            self._dll.ResetPDOFrameLossStats(self._mi, g)

        with self._lock:
            self._head = 0
            self._filled = 0
            self._initialized = False

    def read_slave_error_counters(self, slave_index: int) -> dict:
        """
        读取指定从站的错误计数器 (寄存器 0x0300-0x0307)

        参数:
            slave_index: 从站索引 (1-based)

        返回:
            字典包含各端口错误计数
        """
        rx_error = (c_ubyte * 4)()
        invalid_frame = (c_ubyte * 4)()
        lost_link = (c_ubyte * 4)()
        ok = self._dll.ReadSlavePortErrorCounters(
            self._mi, slave_index, rx_error, invalid_frame, lost_link
        )
        if not ok:
            return {
                'slave_index': slave_index,
                'rx_error': [0, 0, 0, 0],
                'invalid_frame': [0, 0, 0, 0],
                'lost_link': [0, 0, 0, 0],
            }
        return {
            'slave_index': slave_index,
            'rx_error': list(rx_error),
            'invalid_frame': list(invalid_frame),
            'lost_link': list(lost_link),
        }

    # ===================== 拓扑与故障点 =====================

    @property
    def topology_description(self) -> str:
        """
        拓扑模式描述
        对应 C# TopologyDescription 属性
        """
        s = self._get_summary()
        if s is None:
            return "未知"
        mode = s.topology_mode
        _names = {0: "线性", 1: "树形", 2: "环形"}
        return _names.get(mode, f"未知({mode})")

    @property
    def break_point(self) -> Optional[dict]:
        """
        获取当前断点信息
        对应 C# BreakPoint 属性 (BreakPointInfo 结构体)

        返回:
            {'count': int, 'slave_index': int, 'port': int} 或 None
        """
        s = self._get_summary()
        if s is None or s.break_point_count <= 0:
            return None
        # 通过 DLL 获取详细故障点
        try:
            max_results = 64
            slaves = (ctypes.c_ushort * max_results)()
            ports = (ctypes.c_ubyte * max_results)()
            types = (ctypes.c_ubyte * max_results)()
            count = self._dll.GetBreakPoints(
                self._mi, slaves, ports, types, max_results
            )
            if count > 0:
                return {
                    'count': count,
                    'slave_index': slaves[0],
                    'port': ports[0],
                    'type': types[0],
                }
        except Exception:
            pass
        return {'count': s.break_point_count, 'slave_index': 0, 'port': 0, 'type': 0}

    @property
    def timing_mode(self) -> str:
        """
        获取时序模式描述
        对应 C# TimingMode 属性

        返回:
            时序模式描述字符串
        """
        s = self._get_summary()
        if s is None:
            return "未知"
        # 通过总线频率判断时序模式
        if s.bus_cycle_hz > 0:
            return "WDK 实时驱动"
        if s.rt_frequency > 0:
            return "Npcap PDO 线程"
        return "未启动"

    # ===================== PDO 丢帧统计属性 (对应 C# PdoLostFrames / PdoConsecutiveLost / PdoMaxConsecutiveLost) =====================

    @property
    def pdo_lost_frames(self) -> int:
        """PDO 总丢帧数 (所有组合计, 对应 C# PdoLostFrames)"""
        return self.pdo.total_lost

    @property
    def pdo_consecutive_lost(self) -> int:
        """当前连续丢帧数 (所有组中最大值, 对应 C# PdoConsecutiveLost)"""
        return self.pdo.consecutive_lost

    @property
    def pdo_max_consecutive_lost(self) -> int:
        """历史最大连续丢帧数 (对应 C# PdoMaxConsecutiveLost)"""
        return self.pdo.get_frame_loss_stats().max_consecutive

    def __str__(self) -> str:
        return (f"PacketLossRate: {self.packet_loss_rate:.2%}, RTcnt: {self.rt_cnt}, "
                f"ErrorCnt: {self.error_cnt}, Jitter: {self.avg_jitter_us:.2f}us")

    def get_snapshot(self) -> 'DiagnosticsSnapshot':
        """
        获取诊断数据的一致快照

        返回当前时刻所有诊断指标的冻结快照，适用于日志记录、UI 刷新等场景。
        快照为不可变对象，线程安全。
        """
        s = self._get_summary()
        # WKC 来自内部诊断结构体
        wkc_actual = 0
        wkc_expected = 0
        diag_ptr = self._dll.GetDiagnosticsPointer(self._mi)
        if diag_ptr:
            diag = ctypes.cast(diag_ptr, ctypes.POINTER(_InternalDiagnostics)).contents
            wkc_actual = int(diag.WKC)
            wkc_expected = int(diag.ExpectedWKC)
        return DiagnosticsSnapshot(
            frequency=self.rt_cnt,
            error_count=self.error_cnt,
            packet_loss_rate=self.packet_loss_rate,
            late_frame_rate=self.late_frame_rate,
            avg_jitter_us=self.avg_jitter_us,
            max_jitter_us=self.max_jitter_us,
            cycle_time_us=self.cycle_time_span,
            wkc_actual=wkc_actual,
            wkc_expected=wkc_expected,
            bus_cycle_hz=int(s.bus_cycle_hz) if s else 0,
            bus_max_jitter_us=s.bus_max_jitter_us if s else 0.0,
            bus_avg_jitter_us=s.bus_avg_jitter_us if s else 0.0,
            bus_roundtrip_us=s.bus_roundtrip_us if s else 0.0,
            bus_load_percent=self.bus_load_percent,
            smi_count=int(s.smi_count) if s else 0,
            smi_peak_us=s.smi_peak_us if s else 0.0,
            primary_port_ok=s is not None and s.primary_port_ok != 0,
            secondary_port_ok=s is not None and s.secondary_port_ok != 0,
            redundancy_active=s is not None and s.redundancy_active != 0,
        )


@dataclass(frozen=True)
class DiagnosticsSnapshot:
    """诊断数据快照 — 不可变，线程安全"""
    frequency: int            # 每秒帧数 (Hz)
    error_count: int          # 每秒错误数
    packet_loss_rate: float   # 丢包率 (0.0-1.0) — TX vs RX 5 秒滑窗
    late_frame_rate: float    # 过慢帧率 (0.0-1.0) — idx 出 8 帧窗 stale, 不计丢
    avg_jitter_us: float      # 平均抖动 (µs)
    max_jitter_us: float      # 最大抖动 (µs)
    cycle_time_us: int        # 实际周期时间 (µs)
    wkc_actual: int           # 当前 WKC
    wkc_expected: int         # 期望 WKC
    bus_cycle_hz: int         # 总线频率 (Hz)
    bus_max_jitter_us: float  # 总线最大抖动 (µs)
    bus_avg_jitter_us: float  # 总线平均抖动 (µs)
    bus_roundtrip_us: float   # 总线往返延迟 (µs)
    bus_load_percent: float   # 通讯负载 (%) — RTT/周期×100
    smi_count: int            # SMI 次数
    smi_peak_us: float        # SMI 峰值 (µs)
    primary_port_ok: bool     # 主端口正常
    secondary_port_ok: bool   # 副端口正常
    redundancy_active: bool   # 冗余激活
