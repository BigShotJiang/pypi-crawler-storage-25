# -*- coding: utf-8 -*-
"""
EtherCAT 主站类
封装 Darra.Core.dll 的主站级操作
"""

import ctypes
from ctypes import c_int, c_uint, c_ushort, c_ubyte, c_void_p, c_bool, byref, POINTER
from dataclasses import dataclass, field
from typing import Optional, List, Callable, Dict, Tuple

from ..utils.dll import (
    DarraCoreDLL, EcState, EcLinkState, RingMode,
    DllVersionInfo, MasterIdentity, MasterDiagData, TopologyNode,
    RedundancyStatus, CommunicationStats, PDOStats,
    LogCallbackType, ProcessDataCyclicCallbackType,
    SlaveStateChangeCallbackType, EmergencyEventCallbackType,
    SlaveDiscoveryCallbackType, RedundancyModeChangedCallbackType,
    InputDataChangedCallbackType, PDOFrameLossCallbackType,
    DCSyncLostCallbackType, CrashNotifyCallbackType,
    SlavePreOpReconfigCallbackType,
    TIMING_BEFORE, TIMING_AFTER,
    DARRA_CORE_OP_22, DARRA_CORE_OP_23, DARRA_CORE_OP_24,
    DARRA_CORE_OP_25, DARRA_CORE_OP_26, DARRA_CORE_FLAG_01,
)
from ..data.types import EcALState
from ..slave.core import Slave
from .diagnostics import MasterDiagnosticsInfo
from ..logging.logging import LogManager, LogView


@dataclass
class ValidationResult:
    """验证结果"""
    is_valid: bool
    errors: List[str] = field(default_factory=list)


class EtherCATMaster:
    """
    DarraEtherCAT 主站封装

    支持上下文管理器:
        with EtherCATMaster() as master:
            master.set_network("\\\\Device\\\\NPF_{...}")
            master.set_state_sequence(EcState.OP)
            master.start()

    也支持一步初始化:
        with EtherCATMaster.from_json(config_json) as master:
            ...
    """

    def __init__(self, dll_path: Optional[str] = None, master_index: Optional[int] = None):
        """
        创建 EtherCAT 主站实例

        参数:
            dll_path: Darra.Core.dll 路径 (None 自动搜索)
            master_index: 指定主站索引 (None 自动分配)
        """
        self._dll = DarraCoreDLL(dll_path)
        self._slaves: Dict[int, Slave] = {}
        self._slave_count = 0
        self._callbacks = {}  # 防止回调被 GC 回收
        self._config_instance = None
        self._master_od_instance = None
        self._mailbox_gateway_instance = None
        self._diagnostics_info_instance: Optional[MasterDiagnosticsInfo] = None
        self._pending_auto_startup = False

        if master_index is not None:
            self._mi = self._dll.InitializeSpecificMaster(master_index)
        else:
            self._mi = self._dll.Initialize()

        if self._mi == 0xFFFF:
            raise RuntimeError("主站初始化失败: 无可用实例")

    @classmethod
    def from_json(cls, json_config: str, dll_path: Optional[str] = None) -> 'EtherCATMaster':
        """
        通过 JSON 配置一步初始化

        参数:
            json_config: JSON 配置字符串
            dll_path: DLL 路径

        返回:
            已初始化的主站实例
        """
        instance = object.__new__(cls)
        instance._dll = DarraCoreDLL(dll_path)
        instance._slaves = {}
        instance._callbacks = {}
        instance._config_instance = None
        instance._master_od_instance = None
        instance._mailbox_gateway_instance = None
        instance._diagnostics_info_instance = None
        instance._pending_auto_startup = False
        instance._mi = instance._dll.EcInit(json_config.encode('utf-8'))
        if instance._mi == 0xFFFF:
            raise RuntimeError("一步初始化失败")
        instance._slave_count = 0
        return instance

    @classmethod
    def from_json_file(cls, json_file_path: str, dll_path: Optional[str] = None) -> 'EtherCATMaster':
        """
        通过 JSON 文件一步初始化

        参数:
            json_file_path: JSON 配置文件路径
        """
        instance = object.__new__(cls)
        instance._dll = DarraCoreDLL(dll_path)
        instance._slaves = {}
        instance._callbacks = {}
        instance._config_instance = None
        instance._master_od_instance = None
        instance._mailbox_gateway_instance = None
        instance._diagnostics_info_instance = None
        instance._pending_auto_startup = False
        instance._mi = instance._dll.EcInitFromFile(json_file_path.encode('utf-8'))
        if instance._mi == 0xFFFF:
            raise RuntimeError(f"从文件初始化失败: {json_file_path}")
        instance._slave_count = 0
        return instance

    # ===================== 上下文管理器 =====================

    def __enter__(self) -> 'EtherCATMaster':
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def close(self):
        """关闭主站 (Stop + Dispose)"""
        if hasattr(self, '_mi') and self._mi != 0xFFFF:
            mi = self._mi
            # 先标记已关闭, 防止回调在释放期间访问
            self._mi = 0xFFFF
            # 从全局回调注册表注销, 防止 GC 竞争条件
            try:
                from .events import _CallbackRegistry
                _CallbackRegistry.get().unregister_master(mi)
            except Exception:
                pass
            # 清除子对象引用
            self._events_instance = None
            self._diagnostics_info_instance = None
            self._config_instance = None
            self._master_od_instance = None
            if hasattr(self, '_mailbox_gateway_instance') and self._mailbox_gateway_instance:
                try:
                    self._mailbox_gateway_instance.stop()
                except Exception:
                    pass
                self._mailbox_gateway_instance = None
            # 释放主站资源 (停止所有原生线程)
            try:
                self._dll.EcClose(mi)
            except Exception:
                try:
                    self._dll.Stop(mi)
                    self._dll.Dispose(mi)
                except Exception:
                    pass
            # 最后清除回调引用, 防止 GC 在 Dispose 期间回收仍在使用的回调
            self._callbacks = {}
            self._slaves = {}

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    # ===================== 属性 =====================

    @property
    def master_index(self) -> int:
        """主站索引"""
        return self._mi

    @property
    def master_number(self) -> int:
        """主站编号 (master_index 的别名, 对应 C# MasterNumber)"""
        return self._mi

    @property
    def slave_count(self) -> int:
        """在线从站数量"""
        return self._slave_count

    @property
    def is_disposed(self) -> bool:
        """主站是否已释放 (对应 C# IsDisposed)"""
        return not hasattr(self, '_mi') or self._mi == 0xFFFF

    @property
    def slaves(self) -> List[Slave]:
        """
        从站列表 (1-based 索引映射到 list)

        返回:
            所有从站的列表
        """
        result = []
        for i in range(1, self._slave_count + 1):
            result.append(self.slave(i))
        return result

    def dump_slave_topology_bytes(self, slave_num: int) -> Optional[dict]:
        """
        获取从站拓扑信息 (对应 C# DumpSlaveTopologyBytes 的功能)

        注意: C# 版本通过直接读取结构体字节实现, Python SDK 使用
        DLL 导出的拓扑查询函数获取等效信息。

        参数:
            slave_num: 从站编号 (1-based)
        返回:
            拓扑信息字典, 失败返回 None
        """
        try:
            active_ports = self._dll.GetSlaveActivePorts(self._mi, slave_num)
            parent = self._dll.GetSlaveParent(self._mi, slave_num)
            has_dc = bool(self._dll.GetSlaveHasDC(self._mi, slave_num))
            return {
                'slave_num': slave_num,
                'active_ports': active_ports,
                'parent': parent,
                'has_dc': has_dc,
            }
        except Exception:
            pass
        return None

    @property
    def state(self) -> Optional[EcState]:
        """获取主站当前 EtherCAT 状态"""
        try:
            ptr = self._dll.GetMasterStateCache(self._mi)
            if not ptr:
                return None
            import ctypes as _ct
            raw = _ct.cast(ptr, _ct.POINTER(_ct.c_ushort))
            if not raw:
                return None
            try:
                return EcState(raw[0] & 0x0F)
            except ValueError:
                return EcState.NONE
        except Exception:
            return None

    @property
    def error_code(self) -> EcALState:
        """
        错误码 (AL Status Code, 对应 C# ErrorCode)
        状态切换失败时通过此属性获取失败原因
        """
        try:
            ptr = self._dll.GetMasterStateCache(self._mi)
            if not ptr:
                return EcALState.NO_ERROR
            import ctypes as _ct
            raw = _ct.cast(ptr, _ct.POINTER(_ct.c_ushort))
            if not raw:
                return EcALState.NO_ERROR
            val = raw[1]  # ALstatuscode 在 offset 2 (第2个 uint16)
            try:
                return EcALState(val)
            except ValueError:
                return EcALState.UNKNOWN
        except Exception:
            return EcALState.NO_ERROR

    @property
    def obits(self) -> int:
        """输出数据位数 (对应 C# Obits, 读取 slave[0] 汇总)"""
        try:
            return self._dll.GetSlaveOutputBits(self._mi, 0)
        except Exception:
            return 0

    @property
    def obytes(self) -> int:
        """输出数据字节数 (对应 C# Obytes, 读取 slave[0] 汇总)"""
        try:
            return self._dll.GetSlaveOutputBytes(self._mi, 0)
        except Exception:
            return 0

    @property
    def ibits(self) -> int:
        """输入数据位数 (对应 C# Ibits, 读取 slave[0] 汇总)"""
        try:
            return self._dll.GetSlaveInputBits(self._mi, 0)
        except Exception:
            return 0

    @property
    def ibytes(self) -> int:
        """输入数据字节数 (对应 C# Ibytes, 读取 slave[0] 汇总)"""
        try:
            return self._dll.GetSlaveInputBytes(self._mi, 0)
        except Exception:
            return 0

    @property
    def has_dc(self) -> bool:
        """是否启用 DC 同步 (对应 C# HasDC, 读取 slave[0])"""
        try:
            return bool(self._dll.GetSlaveHasDC(self._mi, 0))
        except Exception:
            return False

    @property
    def master_dc_time(self) -> int:
        """
        最近一次 FRMW 取回的 64-bit DC 系统时间 (对齐 C# DLL.GetMasterDCTime).

        单位: 纳秒, 纪元 2000-01-01 00:00:00 UTC.
        DC 未激活 / DLL 未导出时返回 0.
        """
        fn = getattr(self._dll, 'GetMasterDCTime', None)
        if fn is None:
            return 0
        try:
            return int(fn(self._mi))
        except Exception:
            return 0

    @property
    def reference_clock_slave_index(self) -> int:
        """
        参考时钟从站索引 (1-based, 对齐 C# DLL.GetReferenceClockSlaveIndex).

        返回 0 表示无 DC 从站 / DLL 未导出.
        """
        fn = getattr(self._dll, 'GetReferenceClockSlaveIndex', None)
        if fn is None:
            return 0
        try:
            return int(fn(self._mi))
        except Exception:
            return 0

    @property
    def link_state(self) -> EcLinkState:
        """链路状态 (对应 C# LinkState, link_status 的别名)"""
        return self.link_status

    @property
    def loop_cycle(self) -> int:
        """
        获取 PDO 交换周期时间 (纳秒, 对应 C# LoopCycle getter)
        """
        try:
            ptr = self._dll.GetMasterStateCache(self._mi)
            if not ptr:
                return 0
            import ctypes as _ct
            # LoopCycle 在 ec_State offset 8 (uint32)
            val = _ct.c_uint32.from_address(ptr + 8)
            return val.value
        except Exception:
            return 0

    @loop_cycle.setter
    def loop_cycle(self, value: int):
        """设置 PDO 交换周期时间 (纳秒, 对应 C# LoopCycle setter)"""
        self._dll.SetMasterLoopCycleTime(self._mi, max(0, value))

    @property
    def events(self):
        """
        事件系统 (对应 C# Events)
        通过回调函数注册事件，参考 on_pdo_cycle/on_state_change 等方法
        """
        # Python 使用 on_xxx 方法注册回调，此属性返回 self 以保持兼容
        return self

    @property
    def groups(self):
        """
        组访问器 (对应 C# Groups)
        使用 set_group_cycle_divider/set_group_enabled 管理组
        """
        return _GroupAccessor(self)

    @property
    def dll_version(self) -> Optional[dict]:
        """获取 DLL 版本信息"""
        ptr = self._dll.GetDllVersionInfo()
        if not ptr:
            return None
        # 注意: GetDllVersionInfo 返回静态常量指针, 不能调用 FreeMemory
        info = ctypes.cast(ptr, ctypes.POINTER(DllVersionInfo)).contents
        return {
            'major': info.major, 'minor': info.minor,
            'patch': info.patch, 'build': info.build,
            'build_date': info.build_date.decode('utf-8', errors='replace'),
        }

    @property
    def link_status(self) -> EcLinkState:
        """获取链路状态"""
        return EcLinkState(self._dll.GetLinkStatus(self._mi))

    @property
    def ring_mode(self) -> RingMode:
        """获取冗余运行模式"""
        return RingMode(self._dll.GetRingMode(self._mi))

    @property
    def secondary_link_ok(self) -> bool:
        """冗余链路是否正常"""
        return bool(self._dll.GetSecondaryLinkStatus(self._mi))

    @property
    def identity(self) -> Optional[dict]:
        """获取主站身份信息 (ETG.1510)"""
        ident = MasterIdentity()
        if self._dll.GetMasterIdentity(self._mi, byref(ident)):
            return {
                'vendor_id': ident.vendor_id,
                'product_code': ident.product_code,
                'revision_no': ident.revision_no,
                'serial_no': ident.serial_no,
                'device_name': ident.device_name.decode('utf-8', errors='replace'),
                'hw_version': ident.hw_version.decode('utf-8', errors='replace'),
                'sw_version': ident.sw_version.decode('utf-8', errors='replace'),
            }
        return None

    @property
    def diagnostics(self) -> Optional[dict]:
        """获取主站诊断数据 (ETG.1510)"""
        diag = MasterDiagData()
        if self._dll.GetMasterDiagData(self._mi, byref(diag)):
            return {
                'cyclic_lost_frames': diag.cyclic_lost_frames,
                'acyclic_lost_frames': diag.acyclic_lost_frames,
                'cyclic_fps': diag.cyclic_frames_per_sec,
                'acyclic_fps': diag.acyclic_frames_per_sec,
                'state': diag.master_state,
            }
        return None

    @property
    def diagnostics_info(self) -> MasterDiagnosticsInfo:
        """
        高级诊断信息 (帧/错误/抖动统计, 5秒滑动窗口)

        通过此属性访问丢包率、频率、抖动、网口状态、PDO丢帧等诊断数据。
        需要先设置 diagnostics_info.enabled = True 启用诊断采集。
        """
        if self._diagnostics_info_instance is None:
            self._diagnostics_info_instance = MasterDiagnosticsInfo(self)
        return self._diagnostics_info_instance

    @property
    def logs(self) -> LogView:
        """
        日志视图 (只读)

        使用示例::

            master.logs.set_filter(LogCategory.ERROR, LogCategory.WARNING)
            master.logs.on_updated = lambda: print(f"共 {master.logs.count} 条日志")
            for entry in master.logs:
                print(entry)
        """
        return LogManager.instance().default_view

    @property
    def udp_mode(self) -> bool:
        """是否使用 UDP 帧模式"""
        return bool(self._dll.GetUdpMode(self._mi))

    @udp_mode.setter
    def udp_mode(self, enable: bool):
        """设置 UDP 帧模式"""
        self._dll.SetUdpMode(self._mi, enable)

    @property
    def udp_available(self) -> bool:
        """UDP 模式是否可用"""
        return bool(self._dll.IsUdpAvailable(self._mi))

    # ===================== 流式 API 配置 (对应 C# SetENI/SetEsiFile 等) =====================

    def set_eni(self, eni_path: str) -> 'EtherCATMaster':
        """
        加载 JSON 配置文件 (对应 C# SetENI)

        注意: DLL 层仅支持 JSON 格式配置 (LoadConfigJson),
        XML/ENI 解析在 C# 层实现, Python SDK 仅支持 JSON 配置文件。

        参数:
            eni_path: JSON 配置文件路径

        返回:
            当前实例，支持链式调用
        """
        import os
        if not os.path.isfile(eni_path):
            raise FileNotFoundError(f"配置文件不存在: {eni_path}")
        with open(eni_path, 'r', encoding='utf-8') as f:
            json_str = f.read()
        self._dll.DarraCoreInvokeText(
            self._mi, DARRA_CORE_OP_23, json_str.encode('utf-8'), DARRA_CORE_FLAG_01, 0, 0)
        return self

    def set_esi_file(self, file_path: str) -> 'EtherCATMaster':
        """
        加载单个 ESI 文件 (对应 C# SetEsiFile)

        注意: ESI 解析在 C# 层由 EsiManager 实现, DLL 层无对应导出。
        Python SDK 中此方法仅记录路径, ESI 信息应通过 JSON 配置传递。

        参数:
            file_path: ESI 文件路径

        返回:
            当前实例，支持链式调用
        """
        # DLL 层无 LoadEsiFile 导出, ESI 解析在 C# 管理层实现
        # Python SDK 中通过 JSON 配置 (LoadConfigJson) 传递 ESI 信息
        if not hasattr(self, '_pending_esi_paths'):
            self._pending_esi_paths = []
        self._pending_esi_paths.append(file_path)
        return self

    def set_esi_files(self, path: str) -> 'EtherCATMaster':
        """
        加载 ESI 文件或目录 (对应 C# SetEsiFiles)

        注意: ESI 解析在 C# 层由 EsiManager 实现, DLL 层无对应导出。
        Python SDK 中此方法仅记录路径, ESI 信息应通过 JSON 配置传递。

        参数:
            path: ESI 文件路径或目录路径

        返回:
            当前实例，支持链式调用
        """
        # DLL 层无 LoadEsiFiles 导出, ESI 解析在 C# 管理层实现
        if not hasattr(self, '_pending_esi_paths'):
            self._pending_esi_paths = []
        self._pending_esi_paths.append(path)
        return self

    def enable_auto_startup(self) -> 'EtherCATMaster':
        """
        标记需要自动配置从站 (对应 C# EnableAutoStartup)

        返回:
            当前实例，支持链式调用
        """
        self._pending_auto_startup = True
        return self

    def build(self) -> 'EtherCATMaster':
        """
        构建并初始化主站 (对应 C# Build)

        在链式调用的最后调用此方法完成初始化。
        如果启用了 auto_startup，将自动配置未设置的从站。

        支持解构赋值 (对应 C# Deconstruct)::

            master, result = EtherCATMaster().set_network(adapter).build()
            # master = EtherCATMaster 实例
            # result = BuildResult 字典

        返回:
            当前实例 (成功) 或 None (失败)
        """
        # 执行 auto_startup (如果标记了)
        if getattr(self, '_pending_auto_startup', False):
            self.auto_startup()
        # 缓存构建结果用于解构
        self._build_result = {
            'success': self._mi != 0xFFFF,
            'slave_count': self._slave_count,
            'master_index': self._mi,
        }
        return self

    def deconstruct(self):
        """
        解构赋值 (对应 C# Deconstruct)

        返回:
            (EtherCATMaster, BuildResult字典) 元组

        用法::

            master, result = EtherCATMaster().set_network(adapter).build().deconstruct()
        """
        result = getattr(self, '_build_result', {
            'success': self._mi != 0xFFFF,
            'slave_count': self._slave_count,
            'master_index': self._mi,
        })
        return (self, result)

    def auto_startup(self):
        """
        自动配置从站 SM 参数 (对应 C# AutoStartup)

        注意: C# 的 AutoStartup 包含 ESI/CoE/MDP 等高级逻辑, DLL 层仅提供
        AutoConfigureSM (根据启动参数自动计算 SM2/SM3 物理参数)。
        slave_index=0 表示处理所有从站。
        """
        try:
            self._dll.DarraCoreInvoke(self._mi, DARRA_CORE_OP_24, 0, 0, 0)
        except Exception:
            pass

    def dispose(self):
        """释放主站资源 (对应 C# Dispose)"""
        self.close()

    @staticmethod
    def emergency_cleanup(dll_path: Optional[str] = None):
        """
        紧急释放所有主站资源 (对应 C# EmergencyCleanup)
        崩溃/进程退出时使用，直接关闭网卡句柄
        """
        try:
            dll = DarraCoreDLL(dll_path)
            dll.EmergencyCloseNics()
        except Exception:
            pass

    @staticmethod
    def _dump_slave_struct_offsets(dll_path: Optional[str] = None):
        """
        输出 C 结构体 ec_slavet 的字段偏移量到日志 (对应 C# DumpSlaveStructOffsets, 内部调试用)
        """
        try:
            dll = DarraCoreDLL(dll_path)
            dll.DumpSlaveStructOffsets()
        except Exception:
            pass

    # ===================== 网络连接 =====================

    def set_network(self, adapter: str, redundant_adapter: str = "") -> int:
        """
        设置网络适配器并扫描从站

        参数:
            adapter: 主网卡名称 (pcap 设备名)
            redundant_adapter: 冗余网卡名称 (空字符串表示不使用冗余)

        返回:
            发现的从站数量
        """
        count = self._dll.SetNetwork(
            self._mi,
            adapter.encode('utf-8'),
            redundant_adapter.encode('utf-8'),
        )
        # 归一化: DLL 返回 uint16, 0xFFFF (65535) 表示失败
        if count == 0xFFFF:
            self._slave_count = 0
            return 0
        self._slave_count = count
        self._slaves.clear()
        return count

    # ===================== 状态管理 =====================

    def set_state(self, state: EcState) -> bool:
        """
        切换 EtherCAT 主站状态. 唯一公开状态机 API.

        内部自动:
        - 链式转换 (Init→PreOp→SafeOp→OP, 跨多级一次到位)
        - 每步执行 Before/After Transition 启动参数
        - SafeOp/OP 进入后启动 PDO 线程
        - 默认每步 5s 超时
        - 3 次重试 + 1.5s wait (应对 OP 稳定期 Slave PHY 偶发抖动, 用户无需自己重试)

        参数:
            state: 目标状态 (EcState.INIT/PRE_OP/SAFE_OP/OP)

        返回:
            True 切换成功 (含重试), False 重试 3 次仍失败
        """
        import time
        for attempt in range(3):
            try:
                # SetStateSequence (D_1132) = ETG 标准状态机链 + 自动启动参数
                ok = bool(self._dll.SetStateSequence(self._mi, state.value, 5000))
                if ok:
                    # 进 SafeOp/OP 后启动 PDO 线程 (D_1592)
                    if state in (EcState.SAFE_OP, EcState.OP):
                        if not getattr(self, "_pdo_started", False):
                            self._dll.Start(self._mi)
                            self._pdo_started = True
                    return True
            except Exception:
                pass
            if attempt < 2:
                time.sleep(1.5)
        return False

    async def set_state_async(self, state: EcState) -> bool:
        """
        异步版 set_state, 不阻塞调用线程.
        内部 asyncio.run_in_executor 委托线程池执行 set_state.
        """
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.set_state(state))

    def execute_with_state_management(self, required_state: EcState,
                                       operation: Callable[[], bool],
                                       operation_name: str = "") -> bool:
        """
        执行带状态机管理的操作

        如果当前状态不符合操作要求，自动切换状态机（允许升级或降级），
        操作完成后不恢复原状态。
        内置重入保护：如果已经在状态转换中，直接执行操作避免无限递归。

        参数:
            required_state: 操作所需的最低状态
            operation: 要执行的操作 (返回 bool 表示是否成功)
            operation_name: 操作名称 (用于日志)

        返回:
            操作是否成功
        """
        if operation is None:
            raise ValueError("operation 不能为 None")

        # 重入保护
        if getattr(self, '_is_in_state_transition', False):
            try:
                return operation()
            except Exception:
                return False

        try:
            self._is_in_state_transition = True

            # 获取当前状态
            current = self.state
            if current is None:
                current = 0

            # 如果当前状态不满足要求，执行状态转换
            # [2026-05-04] 直调 SetStateSequence (D_1132), 不再走 OP_22=DarraProtocolRequireState
            if not bool(self._dll.SetStateSequence(self._mi, required_state.value, 5000)):
                return False

            # 执行操作
            return operation()
        except Exception:
            return False
        finally:
            self._is_in_state_transition = False

    def execute_with_state_management_value(self, required_state: EcState,
                                             operation: Callable,
                                             operation_name: str = "",
                                             default_value=None):
        """
        执行带状态机管理的操作（带返回值版本）

        参数:
            required_state: 操作所需的最低状态
            operation: 要执行的操作 (返回任意值)
            operation_name: 操作名称 (用于日志)
            default_value: 操作失败时的默认返回值

        返回:
            操作返回值，失败返回 default_value
        """
        if operation is None:
            raise ValueError("operation 不能为 None")

        # 重入保护
        if getattr(self, '_is_in_state_transition', False):
            try:
                return operation()
            except Exception:
                return default_value

        try:
            self._is_in_state_transition = True

            # 获取当前状态
            current = self.state
            if current is None:
                current = 0

            # 如果当前状态不满足要求，执行状态转换
            # [2026-05-04] 直调 SetStateSequence (D_1132), 不再走 OP_22=DarraProtocolRequireState
            if not bool(self._dll.SetStateSequence(self._mi, required_state.value, 5000)):
                return default_value

            # 执行操作
            return operation()
        except Exception:
            return default_value
        finally:
            self._is_in_state_transition = False

    # ===================== 启停 =====================

    def start(self):
        """启动 PDO 循环线程和状态监控线程"""
        self._dll.Start(self._mi)

    def stop(self):
        """停止 PDO 循环线程和状态监控线程"""
        self._dll.Stop(self._mi)

    # ===================== 从站访问 =====================

    def slave(self, index: int) -> Slave:
        """
        获取从站实例 (1-based 索引)

        参数:
            index: 从站索引 (1 开始)

        返回:
            Slave 实例
        """
        if index not in self._slaves:
            self._slaves[index] = Slave(self._dll, self._mi, index)
        return self._slaves[index]

    def __getitem__(self, index: int) -> Slave:
        """通过下标访问从站: master[1]"""
        return self.slave(index)

    # ===================== IO 操作 =====================

    def get_io(self, slave_index: int) -> Optional[Tuple[bytes, bytes]]:
        """
        获取从站的 IO 数据

        返回:
            (output_data, input_data) 元组，失败返回 None
        """
        out_size = c_int(0)
        out_ptr = c_void_p(0)
        in_size = c_int(0)
        in_ptr = c_void_p(0)
        result = self._dll.GetIO(
            self._mi, slave_index,
            byref(out_size), byref(out_ptr),
            byref(in_size), byref(in_ptr),
        )
        if result != 0:
            return None
        out_data = bytes(ctypes.string_at(out_ptr, out_size.value)) if out_ptr.value and out_size.value > 0 else b''
        in_data = bytes(ctypes.string_at(in_ptr, in_size.value)) if in_ptr.value and in_size.value > 0 else b''
        return (out_data, in_data)

    def lock_iomap(self):
        """锁定 IOmap (线程安全访问)"""
        self._dll.LockIOmap(self._mi)

    def unlock_iomap(self):
        """解锁 IOmap"""
        self._dll.UnlockIOmap(self._mi)

    # ===================== 配置 =====================

    def load_config_json(self, json_str: str) -> int:
        """从 JSON 字符串加载配置"""
        return self._dll.DarraCoreInvokeText(
            self._mi, DARRA_CORE_OP_23, json_str.encode('utf-8'), DARRA_CORE_FLAG_01, 0, 0)

    def auto_configure_sm(self, slave_index: int = 0) -> int:
        """
        自动配置 SM 物理参数

        参数:
            slave_index: 从站索引 (0 = 所有从站)
        """
        if slave_index == 0:
            return self._dll.DarraCoreInvoke(self._mi, DARRA_CORE_OP_24, 0, 0, 0)
        return self._dll.DarraCoreInvoke(self._mi, DARRA_CORE_OP_25, slave_index, 0, 0)

    def set_cycle_time(self, time_ns: int):
        """设置 PDO 循环周期 (纳秒)"""
        self._dll.SetMasterLoopCycleTime(self._mi, time_ns)

    def set_cpu_affinity(self, cpu_core: int) -> bool:
        """设置主站线程 CPU 亲和性"""
        return bool(self._dll.SetMasterCpuAffinity(self._mi, cpu_core))

    def set_redundancy_mode(self, mode: int):
        """设置冗余模式 (0=无冗余, 2=Mode 2 环形)"""
        self._dll.SetRedProcessdata(mode)

    @property
    def redundancy_mode(self) -> int:
        """获取当前冗余模式"""
        return self._dll.GetRedProcessdata()

    def acknowledge_slave_replacement(self, slave_num: int) -> bool:
        """
        用户确认从站替换完毕 (v2 热插拔自修复)

        调用时机: 订阅 master.events.add_slave_identity_mismatch() 接收到身份不符报警后,
        操作员检查 / 更换设备完毕, 调用本方法让 SDK 重新探测。

        行为:
        - 若身份已纠正 (换回正确设备 / 同型号升级 Revision) -> 自动恢复并触发 SlaveOnline
        - 若身份仍不匹配 -> 再次触发 SlaveIdentityMismatch, 回到 IDENT_REJECTED

        参数:
            slave_num: 从站编号 (1-based, 与配置一致)

        返回:
            True=已接受并复位 FSM; False=参数无效, 或从站当前不在 IDENT_REJECTED / FAILED 状态
        """
        if slave_num <= 0 or slave_num > 0xFFFF:
            return False
        try:
            return bool(self._dll.AcknowledgeSlaveReplacement(self._mi, slave_num))
        except AttributeError:
            return False

    # ===================== DC 同步 =====================

    def configure_dc(self, sync0_ns: int, sync1_ns: int = 0) -> int:
        """
        一次性配置所有 DC 从站

        参数:
            sync0_ns: SYNC0 周期 (纳秒), 0 禁用
            sync1_ns: SYNC1 周期 (纳秒), 0 禁用

        返回:
            成功配置的 DC 从站数量
        """
        return self._dll.ConfigureDCAll(self._mi, sync0_ns, sync1_ns)

    def update_propagation_delays(self) -> int:
        """更新所有 DC 从站的传播延迟"""
        return self._dll.UpdatePropagationDelays(self._mi)

    def auto_calculate_dc_shift(self) -> int:
        """自动计算 DC 偏移"""
        return self._dll.AutoCalculateDCShift(self._mi)

    def enable_continuous_measurement(self, enable: bool = True, interval_sec: int = 10):
        """启用/禁用持续传播延迟测量"""
        self._dll.EnableContinuousMeasurement(self._mi, enable, interval_sec)

    def set_sync_window_threshold(self, threshold_ns: int):
        """设置同步窗口阈值"""
        self._dll.SetSyncWindowThreshold(self._mi, threshold_ns)

    @property
    def all_slaves_in_sync(self) -> bool:
        """所有 DC 从站是否在同步窗口内"""
        return bool(self._dll.IsAllSlavesInSync(self._mi))

    @property
    def max_sync_difference(self) -> int:
        """所有 DC 从站的最大时间差 (纳秒)"""
        return self._dll.GetMaxSyncDifference(self._mi)

    def enable_drift_compensation(self, enable: bool = True,
                                  threshold_ns: int = 1000, gain: int = 1):
        """
        启用/禁用漂移补偿

        参数:
            enable: 是否启用
            threshold_ns: 触发阈值 (纳秒)
            gain: 补偿增益
        """
        self._dll.EnableDriftCompensation(self._mi, enable, threshold_ns, gain)

    @property
    def max_propagation_delay(self) -> int:
        """最大传播延迟 (纳秒)"""
        return self._dll.GetMaxPropagationDelay(self._mi)

    @property
    def sync_window_threshold(self) -> int:
        """同步窗口阈值 (纳秒)"""
        return self._dll.GetSyncWindowThreshold(self._mi)

    # ===================== 组管理 =====================

    def set_group_cycle_divider(self, group: int, divider: int) -> bool:
        """设置组周期分频器"""
        return bool(self._dll.SetGroupCycleDivider(self._mi, group, divider))

    def set_group_enabled(self, group: int, enabled: bool) -> bool:
        """启用/禁用组"""
        return bool(self._dll.SetGroupEnabled(self._mi, group, enabled))

    @property
    def active_group_count(self) -> int:
        """活跃组数量"""
        return self._dll.GetActiveGroupCount(self._mi)

    def get_group_expected_wkc(self, group: int) -> int:
        """获取组期望 WKC"""
        return self._dll.GetGroupExpectedWKC(self._mi, group)

    # ===================== 启动参数 =====================

    def clear_all_startup_params(self) -> int:
        """清除所有从站的启动参数"""
        return self._dll.ClearStartupParameters(self._mi, 0)

    def apply_startup_params_all(self, transition: int, timing: int = TIMING_AFTER) -> int:
        """对所有从站执行启动参数"""
        return self._dll.DarraCoreInvoke(
            self._mi, DARRA_CORE_OP_26, 0, 1 << transition, 1 << timing)

    # ===================== 看门狗 =====================

    def set_all_watchdog(self, timeout_ms: int) -> int:
        """为所有从站设置统一看门狗超时"""
        return self._dll.SetAllSlaveWatchdog(self._mi, timeout_ms)

    def set_all_pdi_watchdog(self, timeout_ms: int) -> int:
        """为所有从站设置统一PDI看门狗超时"""
        return self._dll.SetAllSlavePdiWatchdog(self._mi, timeout_ms)

    # ===================== 日志 =====================

    @staticmethod
    def set_pdo_logging(enable: bool):
        """启用/禁用 PDO 日志"""
        dll = DarraCoreDLL()
        dll.SetPDOLogging(enable)

    @staticmethod
    def set_mailbox_logging(enable: bool):
        """启用/禁用邮箱日志"""
        dll = DarraCoreDLL()
        dll.SetMailboxLogging(enable)

    @staticmethod
    def set_debug_logging(enable: bool):
        """启用/禁用调试日志"""
        dll = DarraCoreDLL()
        dll.SetDebugLogging(enable)

    def set_log_callback(self, callback: Callable[[int, str], None]):
        """
        设置日志回调

        参数:
            callback: 回调函数 (category, message)
        """
        @LogCallbackType
        def _cb(category, msg_ptr):
            try:
                if msg_ptr:
                    msg = ctypes.string_at(msg_ptr).decode('utf-8', errors='replace')
                    callback(category, msg)
            except Exception:
                pass  # 不能让异常穿越native边界

        self._callbacks['log'] = _cb
        self._dll.SetLogCallback(_cb)

    # ===================== 事件回调 =====================

    def on_pdo_cycle(self, callback: Callable[[int], None], sync: bool = True):
        """
        注册 PDO 周期回调

        参数:
            callback: 回调函数 (master_index)
            sync: True=同步回调 (在 PDO 线程中), False=异步回调
        """
        @ProcessDataCyclicCallbackType
        def _cb(mi):
            try:
                callback(mi)
            except Exception:
                pass  # 不能让异常穿越native边界

        self._callbacks['pdo_cycle'] = _cb
        if sync:
            self._dll.RegisterProcessDataCyclicCallbackSync(_cb)
        else:
            self._dll.RegisterProcessDataCyclicCallbackAsync(_cb)

    def on_state_change(self, callback: Callable[[int, int, int, int], None], sync: bool = True):
        """
        注册从站状态变化回调

        参数:
            callback: 回调函数 (master_index, slave_index, old_state, new_state)
        """
        @SlaveStateChangeCallbackType
        def _cb(mi, si, old, new):
            try:
                callback(mi, si, old, new)
            except Exception:
                pass  # 不能让异常穿越native边界

        self._callbacks['state_change'] = _cb
        if sync:
            self._dll.RegisterSlaveStateChangeCallbackSync(_cb)
        else:
            self._dll.RegisterSlaveStateChangeCallbackAsync(_cb)

    def on_emergency(self, callback: Callable):
        """
        注册紧急消息回调

        参数:
            callback: (master_index, slave_index, error_code, error_reg, b1, w1, w2)
        """
        @EmergencyEventCallbackType
        def _cb(mi, si, err_code, err_reg, b1, w1, w2):
            try:
                callback(mi, si, err_code, err_reg, b1, w1, w2)
            except Exception:
                pass  # 不能让异常穿越native边界

        self._callbacks['emergency'] = _cb
        self._dll.RegisterEmergencyEventCallback(_cb)

    def on_slave_discovery(self, callback: Callable[[int, int, bool], None], sync: bool = True):
        """
        注册从站发现/丢失回调

        参数:
            callback: (master_index, slave_index, is_found)
        """
        @SlaveDiscoveryCallbackType
        def _cb(mi, si, found):
            try:
                callback(mi, si, found)
            except Exception:
                pass  # 不能让异常穿越native边界

        self._callbacks['discovery'] = _cb
        if sync:
            self._dll.RegisterSlaveDiscoveryCallbackSync(_cb)
        else:
            self._dll.RegisterSlaveDiscoveryCallbackAsync(_cb)

    def on_redundancy_mode_changed(self, callback: Callable[[int, int, int], None]):
        """注册冗余模式变化回调 (master_index, old_mode, new_mode)"""
        @RedundancyModeChangedCallbackType
        def _cb(mi, old, new):
            try:
                callback(mi, old, new)
            except Exception:
                pass  # 不能让异常穿越native边界

        self._callbacks['red_mode'] = _cb
        self._dll.RegisterRedundancyModeChangedCallback(_cb)

    def on_input_changed(self, callback: Callable[[int, List[int]], None]):
        """
        注册输入 PDO 数据变化回调

        参数:
            callback: (master_index, changed_slave_indices)
        """
        @InputDataChangedCallbackType
        def _cb(mi, bits_ptr, count):
            try:
                # 解析位图
                changed = []
                if bits_ptr and count > 0:
                    bits_bytes = ctypes.string_at(bits_ptr, (count + 7) // 8 + 8)
                    for i in range(count):
                        byte_idx = i // 8
                        bit_idx = i % 8
                        if byte_idx < len(bits_bytes) and (bits_bytes[byte_idx] >> bit_idx) & 1:
                            changed.append(i)
                callback(mi, changed)
            except Exception:
                pass  # 不能让异常穿越native边界

        self._callbacks['input_changed'] = _cb
        self._dll.RegisterInputDataChangedCallback(_cb)

    def on_pdo_frame_loss(self, callback: Callable[[int, int, int, int], None]):
        """注册 PDO 丢帧回调 (master_index, group, consecutive, total)"""
        @PDOFrameLossCallbackType
        def _cb(mi, grp, consecutive, total):
            try:
                callback(mi, grp, consecutive, total)
            except Exception:
                pass  # 不能让异常穿越native边界

        self._callbacks['frame_loss'] = _cb
        self._dll.RegisterPDOFrameLossCallback(_cb)

    # ===================== PDO 丢帧统计 =====================

    def get_pdo_frame_loss_stats(self, group: int = 0) -> dict:
        """获取 PDO 丢帧统计"""
        total = c_uint(0)
        consecutive = c_uint(0)
        max_consecutive = c_uint(0)
        self._dll.GetPDOFrameLossStats(
            self._mi, group,
            byref(total), byref(consecutive), byref(max_consecutive)
        )
        return {
            'total_lost': total.value,
            'consecutive_lost': consecutive.value,
            'max_consecutive_lost': max_consecutive.value,
        }

    def reset_pdo_frame_loss_stats(self, group: int = 0):
        """重置 PDO 丢帧统计"""
        self._dll.ResetPDOFrameLossStats(self._mi, group)

    # ===================== 通信统计 =====================

    @property
    def communication_stats(self) -> Optional[dict]:
        """获取通信统计信息"""
        ptr = self._dll.GetCommunicationStats(self._mi)
        if not ptr:
            return None
        # 注意: GetCommunicationStats 返回内部静态结构体指针, 不能调用 FreeMemory
        stats = ctypes.cast(ptr, ctypes.POINTER(CommunicationStats)).contents
        return {
            'total_cycles': stats.total_cycles,
            'successful_cycles': stats.successful_cycles,
            'failed_cycles': stats.failed_cycles,
            'timeout_cycles': stats.timeout_cycles,
            'avg_cycle_time_us': stats.average_cycle_time_us,
            'max_cycle_time_us': stats.max_cycle_time_us,
            'min_cycle_time_us': stats.min_cycle_time_us,
        }

    def reset_communication_stats(self):
        """重置通信统计"""
        self._dll.ResetCommunicationStats(self._mi)

    def get_expected_wkc(self) -> int:
        """获取全局期望工作计数器"""
        return self._dll.GetExpectedWKC(self._mi)

    def set_expected_wkc(self, expected_wkc: int):
        """设置全局期望工作计数器"""
        self._dll.SetExpectedWKC(self._mi, expected_wkc)

    def get_slave_link_quality(self, slave_index: int) -> int:
        """获取从站链路质量 (0-100%)"""
        return self._dll.GetSlaveLinkQuality(self._mi, slave_index)

    def record_cycle_time(self, cycle_time_us: int):
        """记录周期时间 (微秒)"""
        self._dll.RecordCycleTime(self._mi, cycle_time_us)

    def record_pdo_cycle_start(self):
        """记录 PDO 周期开始"""
        self._dll.RecordPDOCycleStart(self._mi)

    def record_wkc(self, wkc: int):
        """记录工作计数器"""
        self._dll.RecordWKC(self._mi, wkc)

    def update_diagnostics_snapshot(self):
        """更新诊断快照"""
        self._dll.UpdateDiagnosticsSnapshot(self._mi)

    @property
    def detailed_diagnostics(self):
        """获取详细诊断信息指针"""
        return self._dll.GetDetailedDiagnostics(self._mi)

    def reset_diagnostics(self):
        """重置诊断计数器"""
        self._dll.ResetDiagnostics(self._mi)

    @property
    def diagnostics_pointer(self):
        """获取诊断数据指针 (零拷贝)"""
        return self._dll.GetDiagnosticsPointer(self._mi)

    @property
    def summary_pointer(self):
        """获取摘要数据指针 (零拷贝)"""
        return self._dll.GetSummaryPointer(self._mi)

    @property
    def diagnostics_enabled(self) -> bool:
        """诊断是否启用"""
        return bool(self._dll.GetDiagnosticsEnabled(self._mi))

    @diagnostics_enabled.setter
    def diagnostics_enabled(self, enable: bool):
        """启用/禁用诊断"""
        self._dll.SetDiagnosticsEnabled(self._mi, enable)

    def set_diagnostics_enabled(self, enable: bool):
        """启用/禁用诊断 (兼容旧接口, 建议使用 diagnostics_enabled 属性)"""
        self.diagnostics_enabled = enable

    def get_diagnostics_enabled(self) -> bool:
        """获取诊断启用状态 (兼容旧接口, 建议使用 diagnostics_enabled 属性)"""
        return self.diagnostics_enabled

    def reset_slave_port_error_counters(self, slave_index: int) -> bool:
        """重置从站端口错误计数器"""
        return bool(self._dll.ResetSlavePortErrorCounters(self._mi, slave_index))

    def read_slave_port_error_counters(self, slave_index: int) -> Optional[dict]:
        """
        读取从站端口错误计数器

        返回:
            {'rx_error': [4], 'invalid_frame': [4], 'lost_link': [4]} 或 None
        """
        rx_error = (c_ubyte * 4)()
        invalid_frame = (c_ubyte * 4)()
        lost_link = (c_ubyte * 4)()
        ok = self._dll.ReadSlavePortErrorCounters(
            self._mi, slave_index, rx_error, invalid_frame, lost_link
        )
        if not ok:
            return None
        return {
            'rx_error': list(rx_error),
            'invalid_frame': list(invalid_frame),
            'lost_link': list(lost_link),
        }

    def read_all_slave_port_error_counters(self) -> int:
        """读取所有从站端口错误计数器，返回成功读取的从站数"""
        return self._dll.ReadAllSlavePortErrorCounters(self._mi)

    def get_slave_port_error_stats(self, slave_index: int):
        """获取从站端口错误统计指针"""
        return self._dll.GetSlavePortErrorStats(self._mi, slave_index)

    def update_diagnostics_with_esc_errors(self):
        """使用 ESC 错误更新诊断数据"""
        self._dll.UpdateDiagnosticsWithESCErrors(self._mi)

    # ===================== 故障检测 =====================

    def get_break_points(self, max_results: int = 64) -> List[dict]:
        """
        获取故障点信息

        返回:
            故障点列表 [{'slave': int, 'port': int, 'type': int}, ...]
            type: 0=断线, 1=CRC劣化
        """
        slaves = (c_ushort * max_results)()
        ports = (c_ubyte * max_results)()
        types = (c_ubyte * max_results)()
        count = self._dll.GetBreakPoints(
            self._mi, slaves, ports, types, max_results
        )
        return [
            {'slave': slaves[i], 'port': ports[i], 'type': types[i]}
            for i in range(max(0, count))
        ]

    # ===================== 实时优化 =====================

    @staticmethod
    def _apply_realtime_optimizations() -> bool:
        """应用实时优化 (高精度定时器、内存锁定、高优先级, 内部用)"""
        # 静态方法需要独立 DLL 实例
        dll = DarraCoreDLL()
        return bool(dll.ApplyRealtimeOptimizations())

    @staticmethod
    def _remove_realtime_optimizations() -> bool:
        """移除实时优化 (内部用)"""
        dll = DarraCoreDLL()
        return bool(dll.RemoveRealtimeOptimizations())

    # ===================== 静态工具 =====================

    @staticmethod
    def quick_slave_count(adapter: str, dll_path: Optional[str] = None) -> int:
        """快速探测网卡上的从站数量"""
        dll = DarraCoreDLL(dll_path)
        return dll.QuickSlaveCount(adapter.encode('utf-8'))

    @staticmethod
    def scan_slave_count(adapter: str, dll_path: Optional[str] = None) -> int:
        """扫描网卡上的从站数量"""
        dll = DarraCoreDLL(dll_path)
        return dll.ScanSlaveCount(adapter.encode('utf-8'))

    @staticmethod
    def get_available_cpu_cores(dll_path: Optional[str] = None) -> int:
        """获取可用 CPU 核心数"""
        dll = DarraCoreDLL(dll_path)
        return dll.GetAvailableCpuCores()

    @staticmethod
    def get_max_master_instances(dll_path: Optional[str] = None) -> int:
        """获取最大主站实例数"""
        dll = DarraCoreDLL(dll_path)
        return dll.GetMaxMasterInstances()

    @staticmethod
    def get_max_instance_count(dll_path: Optional[str] = None) -> int:
        """
        获取最大可创建的主站实例数量

        基于可用隔离核心数和驱动上限决定。
        Linux: 隔离核心数由 install.sh 的 isolcpus 参数决定
        Windows: 总核心数 - 1 (驱动运行时隔离)

        参数:
            dll_path: DLL 路径 (None 自动搜索)

        返回:
            最大实例数
        """
        dll = DarraCoreDLL(dll_path)
        try:
            return dll.GetMaxMasterInstances()
        except Exception:
            return 0

    # ===================== 网络拓扑 =====================

    @property
    def topology(self) -> List[dict]:
        """
        构建网络拓扑并返回节点列表

        返回:
            拓扑节点列表 [{'slave_index', 'config_addr', 'parent_index',
                          'entry_port', 'active_ports', 'topology', 'port_type'}, ...]
        """
        max_nodes = max(self._slave_count, 64)
        buf = (TopologyNode * max_nodes)()
        count = self._dll.TopologyBuild(self._mi, buf, max_nodes)
        result = []
        for i in range(max(0, count)):
            n = buf[i]
            result.append({
                'slave_index': n.slave_index,
                'config_addr': n.config_addr,
                'parent_index': n.parent_index,
                'entry_port': n.entry_port,
                'active_ports': n.active_ports,
                'topology': n.topology,
                'port_type': n.port_type,
            })
        return result

    def topology_children(self, parent_index: int, max_results: int = 64) -> List[int]:
        """
        获取指定从站的子节点索引列表

        参数:
            parent_index: 父从站索引
            max_results: 最大结果数
        """
        buf = (c_ushort * max_results)()
        count = self._dll.TopologyGetChildren(self._mi, parent_index, buf, max_results)
        return [buf[i] for i in range(max(0, count))]

    def topology_roots(self, max_results: int = 64) -> List[int]:
        """
        获取根节点 (直连主站) 的从站索引列表

        参数:
            max_results: 最大结果数
        """
        buf = (c_ushort * max_results)()
        count = self._dll.TopologyGetRoots(self._mi, buf, max_results)
        return [buf[i] for i in range(max(0, count))]

    # ===================== WDK 实时驱动 =====================

    @property
    def _is_wdk_available(self) -> bool:
        """WDK 实时驱动是否可用 (内部用)"""
        return bool(self._dll.IsWdkAvailable(self._mi))

    @property
    def _wdk_mode(self) -> bool:
        """获取 WDK 模式状态 (内部用)"""
        return bool(self._dll.GetWdkMode(self._mi))

    def _set_wdk_mode(self, enable: bool) -> bool:
        """设置 WDK 模式 (内部用)"""
        return bool(self._dll.SetWdkMode(self._mi, enable))

    def _start_wdk_rt(self, cycle_us: int, cpu_index: int) -> bool:
        """
        启动 WDK 实时线程 (内部用)

        参数:
            cycle_us: 周期时间 (微秒)
            cpu_index: 绑定的 CPU 核心索引
        """
        return bool(self._dll.StartWdkRT(self._mi, cycle_us, cpu_index))

    def _stop_wdk_rt(self) -> bool:
        """停止 WDK 实时线程 (内部用)"""
        return bool(self._dll.StopWdkRT(self._mi))

    # ===================== 冗余高级 =====================

    def enable_redundancy(self, enable: bool) -> bool:
        """启用/禁用冗余"""
        return bool(self._dll.EnableRedundancy(self._mi, enable))

    @property
    def redundancy_status(self) -> Optional[dict]:
        """获取冗余状态详情"""
        ptr = self._dll.GetRedundancyStatus(self._mi)
        if not ptr:
            return None
        try:
            st = ctypes.cast(ptr, ctypes.POINTER(RedundancyStatus)).contents
            # GetRedundancyStatus 返回 malloc 分配的内存, 必须调用 FreeMemory
            result = {
                'state': st.state,
                'primary_link_up': bool(st.primary_link_up),
                'secondary_link_up': bool(st.secondary_link_up),
                'primary_tx_frames': st.primary_tx_frames,
                'primary_rx_frames': st.primary_rx_frames,
                'secondary_tx_frames': st.secondary_tx_frames,
                'secondary_rx_frames': st.secondary_rx_frames,
                'failover_count': st.failover_count,
                'last_failover_time': st.last_failover_time,
            }
            self._dll.FreeMemory(ptr)
            return result
        except Exception:
            self._dll.FreeMemory(ptr)
            return None

    def force_failover(self) -> bool:
        """强制冗余切换"""
        return bool(self._dll.ForceRedundancyFailover(self._mi))

    def check_redundancy_health(self) -> bool:
        """检查冗余链路健康状态"""
        return bool(self._dll.CheckRedundancyHealth(self._mi))

    # ===================== DC 高级 =====================

    @property
    def dc_auto_shift(self) -> bool:
        """获取 DC 自动偏移是否启用"""
        return bool(self._dll.GetDCAutoShiftEnabled(self._mi))

    @dc_auto_shift.setter
    def dc_auto_shift(self, enable: bool):
        """设置 DC 自动偏移"""
        self._dll.SetDCAutoShiftEnabled(self._mi, enable)

    def set_dc_cycle_time(self, time_ns: int):
        """设置主站 DC 周期时间 (纳秒), 独立于 PDO 循环周期"""
        self._dll.SetMasterDCCycleTime(self._mi, time_ns)

    # ===================== Mutex 保护 =====================

    @property
    def mutex_protection(self) -> bool:
        """获取 Mutex 保护是否启用"""
        return bool(self._dll.GetMutexProtection(self._mi))

    @mutex_protection.setter
    def mutex_protection(self, enable: bool):
        """设置 Mutex 保护"""
        self._dll.SetMutexProtection(self._mi, enable)

    # ===================== 聚合配置 (MasterConfig) =====================

    @property
    def config(self):
        """主站配置对象，统一管理所有通信配置"""
        if self._config_instance is None:
            from .config import MasterConfig
            self._config_instance = MasterConfig(self._dll, self._mi)
        return self._config_instance

    # ===================== ETG.1510 主站对象字典 =====================

    @property
    def master_od(self):
        """ETG.1510 主站对象字典，用于诊断工具和 HMI 访问"""
        if self._master_od_instance is None:
            from .master_od import MasterObjectDictionary
            self._master_od_instance = MasterObjectDictionary(self)
        return self._master_od_instance

    # ===================== ETG.8200 Mailbox Gateway =====================

    @property
    def mailbox_gateway(self):
        """ETG.8200 Mailbox Gateway 服务，用于外部诊断工具通过 UDP/IP 访问"""
        if self._mailbox_gateway_instance is None:
            from .mailbox_gateway import MailboxGatewayService
            self._mailbox_gateway_instance = MailboxGatewayService(self, self._mi)
        return self._mailbox_gateway_instance

    # ===================== 定时模式 =====================

    @property
    def _timing_mode(self) -> int:
        """获取当前定时模式 (内部用)"""
        return self._dll.GetTimingMode(self._mi)

    # ===================== 实时状态 =====================

    @staticmethod
    def _get_realtime_status(dll_path: Optional[str] = None) -> bool:
        """查询实时优化是否已应用 (内部用)"""
        dll = DarraCoreDLL(dll_path)
        return bool(dll.GetRealtimeOptimizationsStatus())

    # ===================== 网络扫描详细 =====================

    @staticmethod
    def read_slave_info(adapter: str, dll_path: Optional[str] = None) -> int:
        """
        扫描并读取从站详细信息

        参数:
            adapter: 网卡适配器名

        返回:
            发现的从站数量
        """
        dll = DarraCoreDLL(dll_path)
        return dll.ReadSlaveInfo(adapter.encode('utf-8'))

    @staticmethod
    def get_scanned_slave_count(dll_path: Optional[str] = None) -> int:
        """获取已扫描的从站数量"""
        dll = DarraCoreDLL(dll_path)
        return dll.GetScannedSlaveCount()

    @staticmethod
    def get_scanned_slave_info(index: int, dll_path: Optional[str] = None) -> Optional[dict]:
        """
        获取已扫描从站的详细信息

        参数:
            index: 从站在扫描列表中的索引

        返回:
            从站信息字典，失败返回 None
        """
        dll = DarraCoreDLL(dll_path)
        vendor_id = c_uint(0)
        product_code = c_uint(0)
        revision = c_uint(0)
        serial = c_uint(0)
        name_buf = ctypes.create_string_buffer(128)
        config_addr = c_ushort(0)
        alias_addr = c_ushort(0)
        parent = c_ushort(0)
        topology = c_ubyte(0)
        activeports = c_ubyte(0)
        entryport = c_ubyte(0)
        parentport = c_ubyte(0)
        ptype = c_ubyte(0)
        ok = dll.GetScannedSlaveInfo(
            index,
            byref(vendor_id), byref(product_code),
            byref(revision), byref(serial),
            name_buf, 128,
            byref(config_addr), byref(alias_addr),
            byref(parent), byref(topology), byref(activeports),
            byref(entryport), byref(parentport), byref(ptype),
        )
        if not ok:
            return None
        return {
            'vendor_id': vendor_id.value,
            'product_code': product_code.value,
            'revision': revision.value,
            'serial': serial.value,
            'name': name_buf.value.decode('utf-8', errors='replace'),
            'config_addr': config_addr.value,
            'alias_addr': alias_addr.value,
            'parent': parent.value,
            'topology': topology.value,
            'active_ports': activeports.value,
            'entry_port': entryport.value,
            'parent_port': parentport.value,
            'port_type': ptype.value,
        }

    # ===================== 授权与设备信息 =====================

    def verify_license(self) -> bool:
        """验证许可证有效性"""
        return self._dll.CheckBufferIntegrity() == 1

    def invalidate_license(self):
        """使许可证失效"""
        self._dll.FlushCachePool()

    @property
    def is_license_valid(self) -> bool:
        """许可证是否有效"""
        return bool(self._dll.IsCachePoolReady())

    @staticmethod
    def get_serial_number(dll_path: Optional[str] = None) -> str:
        """
        获取设备序列号

        返回:
            序列号字符串
        """
        dll = DarraCoreDLL(dll_path)
        ptr = dll.GetSerialNumber()
        if not ptr:
            return ""
        # DLL 返回内部静态缓冲区, 不能调用 FreeMemory
        result = ctypes.string_at(ptr).decode('utf-8', errors='replace')
        return result

    @staticmethod
    def get_device_name(dll_path: Optional[str] = None) -> str:
        """
        获取设备名称

        返回:
            设备名称字符串
        """
        dll = DarraCoreDLL(dll_path)
        ptr = dll.GetDeviceName()
        if not ptr:
            return ""
        # DLL 返回内部静态缓冲区, 不能调用 FreeMemory
        result = ctypes.string_at(ptr).decode('utf-8', errors='replace')
        return result

    @staticmethod
    def get_user_email(dll_path: Optional[str] = None) -> str:
        """
        获取用户邮箱

        返回:
            邮箱字符串
        """
        dll = DarraCoreDLL(dll_path)
        ptr = dll.GetUserEmail()
        if not ptr:
            return ""
        # DLL 返回内部静态缓冲区, 不能调用 FreeMemory
        result = ctypes.string_at(ptr).decode('utf-8', errors='replace')
        return result

    @staticmethod
    def get_windows_product_key(dll_path: Optional[str] = None) -> str:
        """
        获取 Windows 产品密钥

        返回:
            产品密钥字符串
        """
        dll = DarraCoreDLL(dll_path)
        ptr = dll.GetWindowsProductKey()
        if not ptr:
            return ""
        # DLL 返回内部静态缓冲区, 不能调用 FreeMemory
        result = ctypes.string_at(ptr).decode('utf-8', errors='replace')
        return result

    @staticmethod
    def get_driver_list(dll_path: Optional[str] = None) -> str:
        """
        获取驱动列表

        返回:
            驱动列表字符串
        """
        dll = DarraCoreDLL(dll_path)
        ptr = dll.GetDriverList()
        if not ptr:
            return ""
        # DLL 返回内部静态缓冲区, 不能调用 FreeMemory
        result = ctypes.string_at(ptr).decode('utf-8', errors='replace')
        return result

    # ===================== PDO 监控 =====================

    def pdo_stats(self, slave_index: int) -> Optional[dict]:
        """
        获取从站 PDO 性能统计 (返回内部指针, 无需释放)

        参数:
            slave_index: 从站索引

        返回:
            PDO 统计字典，失败返回 None
        """
        ptr = self._dll.GetPDOStats(self._mi, slave_index)
        if not ptr:
            return None
        stats = ctypes.cast(ptr, ctypes.POINTER(PDOStats)).contents
        return {
            'read_count': stats.read_count,
            'write_count': stats.write_count,
            'error_count': stats.error_count,
            'total_bytes_read': stats.total_bytes_read,
            'total_bytes_written': stats.total_bytes_written,
            'last_cycle_time_ns': stats.last_cycle_time_ns,
            'min_cycle_time_ns': stats.min_cycle_time_ns,
            'max_cycle_time_ns': stats.max_cycle_time_ns,
            'avg_cycle_time_ns': stats.avg_cycle_time_ns,
        }

    @property
    def pdo_monitoring(self) -> bool:
        """PDO 监控是否已启用"""
        return bool(self._dll.IsPDOMonitoringEnabled())

    @pdo_monitoring.setter
    def pdo_monitoring(self, enabled: bool):
        """启用/禁用 PDO 监控"""
        self._dll.EnablePDOMonitoring(enabled)

    def set_pdo_monitoring(self, enabled: bool):
        """启用/禁用 PDO 监控 (兼容旧接口, 建议使用 pdo_monitoring 属性)"""
        self.pdo_monitoring = enabled

    def is_pdo_monitoring_enabled(self) -> bool:
        """查询 PDO 监控是否已启用 (兼容旧接口, 建议使用 pdo_monitoring 属性)"""
        return self.pdo_monitoring

    def pdo_read_direct(self, slave_index: int, pdo_index: int, buffer_size: int) -> Optional[bytes]:
        """PDO 直接读取"""
        buf = (c_ubyte * buffer_size)()
        bytes_read = c_uint(0)  # DLL 签名为 POINTER(c_uint), 必须使用 c_uint
        ok = self._dll.PDOReadDirect(
            self._mi, slave_index, pdo_index,
            ctypes.cast(buf, c_void_p), buffer_size, ctypes.byref(bytes_read)
        )
        if not ok:
            return None
        return bytes(buf[:bytes_read.value])

    def pdo_write_direct(self, slave_index: int, pdo_index: int, data: bytes) -> bool:
        """PDO 直接写入"""
        buf = (c_ubyte * len(data))(*data)
        return bool(self._dll.PDOWriteDirect(
            self._mi, slave_index, pdo_index,
            ctypes.cast(buf, c_void_p), len(data)
        ))

    def reset_pdo_stats(self, slave_index: int):
        """重置 PDO 统计"""
        self._dll.ResetPDOStats(self._mi, slave_index)

    def get_pdo_mapping(self, slave_index: int, pdo_type: int, buffer_size: int = 256):
        """获取 PDO 映射"""
        buf = (c_ubyte * buffer_size)()
        count = c_uint(0)  # DLL 签名为 POINTER(c_uint), 必须使用 c_uint
        ok = self._dll.GetPDOMapping(
            self._mi, slave_index, pdo_type,
            ctypes.cast(buf, c_void_p), buffer_size, ctypes.byref(count)
        )
        if not ok:
            return None
        return bytes(buf[:count.value])

    def verify_all_slave_identities(self, expected_identities: list = None,
                                     check_revision: bool = False,
                                     check_serial: bool = False) -> dict:
        """
        批量验证所有从站身份

        参数:
            expected_identities: SlaveIdentity 列表 (None 表示使用当前在线从站身份)
            check_revision: 是否检查修订号
            check_serial: 是否检查序列号

        返回:
            {'success': bool, 'mismatch_mask': int} 字典
        """
        from ..utils.dll import SlaveIdentity as _SlaveIdentity
        if expected_identities is None:
            # 自动获取当前在线从站身份作为期望值
            count = self._slave_count
            if count <= 0:
                return {'success': True, 'mismatch_mask': 0}
            arr = (_SlaveIdentity * count)()
            for i in range(count):
                self._dll.GetSlaveIdentity(self._mi, i + 1, ctypes.byref(arr[i]))
            identities_ptr = ctypes.cast(arr, ctypes.POINTER(_SlaveIdentity))
        else:
            count = len(expected_identities)
            arr = (_SlaveIdentity * count)(*expected_identities)
            identities_ptr = ctypes.cast(arr, ctypes.POINTER(_SlaveIdentity))

        mismatch_mask = ctypes.c_uint64(0)
        ok = self._dll.VerifyAllSlaveIdentities(
            self._mi, identities_ptr, count,
            check_revision, check_serial, ctypes.byref(mismatch_mask)
        )
        return {'success': bool(ok), 'mismatch_mask': mismatch_mask.value}

    # ===================== 扫描控制 =====================

    def abort_scan(self):
        """中止正在进行的从站扫描"""
        self._dll.AbortScan()

    def reset_scan_abort(self):
        """重置扫描中止标志"""
        self._dll.ResetScanAbort()

    # ===================== 网络紧急控制 =====================

    def abort_network(self):
        """中止网络操作"""
        self._dll.AbortNetwork()

    def reset_abort_network(self):
        """重置网络中止标志"""
        self._dll.ResetAbortNetwork()

    def emergency_close_nics(self):
        """紧急关闭所有网卡"""
        self._dll.EmergencyCloseNics()

    # ===================== DC 同步丢失回调 =====================

    def set_dc_sync_lost_callback(self, callback: Optional[Callable[[int, int, int], None]]):
        """
        设置 DC 同步丢失回调

        参数:
            callback: 回调函数 (master_index, slave_index, diff_ns)，None 清除回调
        """
        if callback is None:
            self._callbacks.pop('dc_sync_lost', None)
            self._dll.SetDCSyncLostCallback(DCSyncLostCallbackType(0))
            return

        @DCSyncLostCallbackType
        def _cb(mi, si, diff_ns):
            try:
                callback(mi, si, diff_ns)
            except Exception:
                pass  # 不能让异常穿越native边界

        self._callbacks['dc_sync_lost'] = _cb
        self._dll.SetDCSyncLostCallback(_cb)

    # ===================== 配置验证 =====================

    def validate_config(self) -> int:
        """
        验证主站配置是否正确 (ETG.1500 5.5.2)

        返回:
            0 表示成功，非零表示错误码
        """
        return self._dll.ec_validate_config(self._mi)

    def validate(self) -> 'ValidationResult':
        """
        Build 前配置预检查

        检查主站配置是否满足最低要求（网口是否设置等），
        在调用 build() 之前使用，避免无效配置导致初始化失败。

        返回:
            ValidationResult 包含验证结果和错误列表
        """
        import os
        errors = []
        # 检查网口是否已设置
        if not getattr(self, '_network_configured', False):
            # 尝试通过 DLL 检查是否已配置网口
            try:
                sc = self._dll.GetSlaveCount(self._mi)
                # 如果能获取从站数说明已初始化，不报错
            except Exception:
                pass
            # 无法确定时不误报
        # 检查 ENI 文件路径是否存在
        eni_path = getattr(self, '_pending_eni_path', None)
        if eni_path and not os.path.exists(eni_path):
            errors.append(f"ENI 文件不存在: {eni_path}")
        # ETG.1500 配置验证
        try:
            ret = self._dll.ec_validate_config(self._mi)
            if ret != 0:
                errors.append(f"配置验证失败 (错误码: {ret})")
        except Exception:
            pass
        return ValidationResult(is_valid=len(errors) == 0, errors=errors)

    # ===================== 性能统计导出 =====================

    def perf_export_csv(self, filename: str) -> int:
        """
        导出性能统计数据到 CSV 文件

        参数:
            filename: 导出的 CSV 文件路径

        返回:
            0 表示成功，非零表示错误码
        """
        return self._dll.ec_perf_export_csv(self._mi, filename.encode('utf-8'))

    # ===================== 定时器精度验证 =====================

    @staticmethod
    def validate_timer_accuracy(expected_usec: int, tolerance_usec: int,
                                dll_path: Optional[str] = None) -> int:
        """
        验证操作系统定时器精度

        参数:
            expected_usec: 期望的定时器周期 (微秒)
            tolerance_usec: 允许的容差 (微秒)

        返回:
            0 表示定时器精度在容差范围内，非零表示超出容差
        """
        dll = DarraCoreDLL(dll_path)
        return dll.osal_validate_timer_accuracy(expected_usec, tolerance_usec)

    # ===================== 拓扑访问器 =====================

    @property
    def slave_topology(self):
        """
        从站拓扑访问器 (延迟创建)

        用法:
            topology = master.slave_topology
            root = topology[0]           # 第一个耦合器
            child = topology.get_children(root)[0]  # 第一个子模块
            slave = topology["0x1001"]   # 通过地址查找
        """
        if not hasattr(self, '_slave_topology') or self._slave_topology is None:
            from ..slave.topology import SlaveTopology
            self._slave_topology = SlaveTopology(self)
        return self._slave_topology

    def rebuild_topology(self):
        """重建拓扑结构（从站列表变化后调用）"""
        if hasattr(self, '_slave_topology') and self._slave_topology is not None:
            self._slave_topology.rebuild()

    # ===================== 实例管理 =====================

    @staticmethod
    def get_active_instance_count(dll_path: Optional[str] = None) -> int:
        """获取当前活跃的主站实例数"""
        dll = DarraCoreDLL(dll_path)
        try:
            return dll.GetActiveInstanceCount()
        except Exception:
            return 0

    @staticmethod
    def is_adapter_available(adapter: str, dll_path: Optional[str] = None) -> bool:
        """
        检查网卡适配器是否可用

        参数:
            adapter: 网卡适配器名称

        返回:
            是否可用
        """
        dll = DarraCoreDLL(dll_path)
        try:
            return bool(dll.IsAdapterAvailable(adapter.encode('utf-8')))
        except Exception:
            return False

    # ===================== DC 高级方法 =====================

    def reset_all_sync_window_stats(self):
        """重置所有从站的同步窗口统计"""
        for i in range(1, self._slave_count + 1):
            try:
                self._dll.ResetSlaveSyncWindowStats(self._mi, i)
            except Exception:
                pass

    # ===================== 字符串表示 =====================

    def __str__(self) -> str:
        """字符串表示: 主站索引和从站数量"""
        if self._mi == 0xFFFF:
            return "EtherCATMaster[已关闭]"
        return f"EtherCATMaster[{self._mi}] {self._slave_count} slaves"

    def __repr__(self) -> str:
        state = "已关闭" if self._mi == 0xFFFF else f"索引={self._mi}"
        return f"EtherCATMaster({state}, 从站数={self._slave_count})"

    # ===================== 可迭代接口 =====================

    def __iter__(self):
        """迭代所有从站 (支持 for slave in master)"""
        for i in range(1, self._slave_count + 1):
            yield self.slave(i)

    def __len__(self) -> int:
        """返回从站数量 (支持 len(master))"""
        return self._slave_count

    # ===================== 状态变化回调 =====================

    @property
    def on_state_changed(self):
        """
        主站状态变化回调

        设置一个回调函数, 当主站状态发生变化时被调用:
            master.on_state_changed = lambda old, new: print(f"状态: {old} -> {new}")
        """
        return self._callbacks.get('_state_changed_user')

    @on_state_changed.setter
    def on_state_changed(self, callback: Optional[Callable]):
        """设置主站状态变化回调 (old_state, new_state)"""
        if callback is None:
            self._callbacks.pop('_state_changed_user', None)
            return
        self._callbacks['_state_changed_user'] = callback
        # 通过从站状态变化回调监听主站级变化 (slave_index=0 表示主站)
        self._last_master_state = self.state

        @SlaveStateChangeCallbackType
        def _state_cb(mi, si, old, new):
            try:
                if si == 0:
                    callback(old, new)
            except Exception:
                pass  # 不能让异常穿越native边界

        self._callbacks['_state_changed_native'] = _state_cb
        self._dll.RegisterSlaveStateChangeCallbackSync(_state_cb)


class _GroupAccessor:
    """
    组访问器 (对应 C# SlaveGroupAccessor)
    支持 master.groups[g] 获取组内从站列表
    """

    def __init__(self, master: EtherCATMaster):
        self._master = master

    def __getitem__(self, group: int) -> '_GroupView':
        """按组号获取该组内的从站列表"""
        if group < 0 or group > 7:
            raise IndexError("组号必须在 0-7 范围内")
        return _GroupView(self._master, group)


class _GroupView:
    """
    组内从站视图 (对应 C# SlaveGroupList)
    支持按索引访问组内从站
    """

    def __init__(self, master: EtherCATMaster, group: int):
        self._master = master
        self._group = group
        self._cached = None

    def _get_slaves(self) -> List[Slave]:
        """获取组内从站列表"""
        if self._cached is None:
            result = []
            for s in self._master.slaves:
                try:
                    if s.group == self._group:
                        result.append(s)
                except Exception:
                    pass
            self._cached = result
        return self._cached

    @property
    def count(self) -> int:
        """组内从站数量"""
        return len(self._get_slaves())

    @property
    def divider(self) -> int:
        """PDO 周期分频器"""
        try:
            return self._master._dll.GetGroupCycleDivider(
                self._master._mi, self._group)
        except Exception:
            return 1

    @divider.setter
    def divider(self, value: int):
        """设置 PDO 周期分频器"""
        if value < 1:
            raise ValueError("分频器必须大于 0")
        self._master._dll.SetGroupCycleDivider(
            self._master._mi, self._group, value)

    def __getitem__(self, index: int) -> Slave:
        """按组内索引获取从站 (0-based)"""
        slaves = self._get_slaves()
        if index < 0 or index >= len(slaves):
            raise IndexError(
                f"组 {self._group} 共有 {len(slaves)} 个从站，索引 {index} 越界")
        return slaves[index]

    def to_list(self) -> List[Slave]:
        """
        返回从站列表副本
        对应 C# ToList 方法

        返回:
            从站列表的浅拷贝
        """
        return list(self._get_slaves())

    def __len__(self) -> int:
        return self.count

    def __iter__(self):
        return iter(self._get_slaves())
