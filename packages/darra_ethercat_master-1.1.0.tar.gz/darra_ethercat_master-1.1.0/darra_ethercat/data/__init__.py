# -*- coding: utf-8 -*-
"""
数据类型模块
包含所有 EtherCAT 协议相关的枚举、标志位和数据类
"""

from .types import (
    EcBufState, EcCmdType, EcEcmdType, LogLevel,
    EcALState, ALErrorCategory, classify_al_error,
    MailboxError, MailboxType, SDOError, SoEError,
    EcCommType, EcPortType, EcTopologyType, EcPdiType,
    EcDeviceType, EcSyncManagerType, EcFmmuType,
    EcCoEDetails, EcEoEDetails,
    DcSyncMode, StartupTransition, StartupWriteTiming,
    CoEObjectAccess, EsmTimeouts,
    SlaveErrorCounters, DiagnosticMessage,
    EcStateFormat,
)

from .structures import (
    ECT_MBXPROT_AOE, ECT_MBXPROT_EOE, ECT_MBXPROT_COE,
    ECT_MBXPROT_FOE, ECT_MBXPROT_SOE, ECT_MBXPROT_VOE,
    ECT_COEDET_SDO, ECT_COEDET_SDOINFO, ECT_COEDET_PDOASSIGN,
    ECT_COEDET_PDOCONFIG, ECT_COEDET_UPLOAD, ECT_COEDET_SDOCA,
    PDOStats, PDOMappingEntry, CommunicationStats, RealtimeStats,
    FoEOptionsStruct,
)
