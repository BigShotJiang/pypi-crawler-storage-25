# -*- coding: utf-8 -*-
"""
对应 C# 文件: Data/Structures.cs
EtherCAT 数据结构定义

包含:
- EtherCAT 常量
- PDO 统计/映射结构体
- 网络适配器信息结构体
- SyncManager / FMMU 结构体
- 从站结构体 (ec_slave)
- 主站状态结构体 (ec_State)
- 诊断数据结构体
- 启动/配置结构体
"""

import ctypes
from ctypes import Structure, c_uint, c_ushort, c_ubyte, c_int, c_uint64, c_double, c_byte
from ctypes import c_int64, c_int32, c_int16, c_void_p, c_uint32, c_uint16, c_uint8


# ===================== 增强型邮箱协议定义 =====================

ECT_MBXPROT_AOE = 0x0001
ECT_MBXPROT_EOE = 0x0002
ECT_MBXPROT_COE = 0x0004
ECT_MBXPROT_FOE = 0x0008
ECT_MBXPROT_SOE = 0x0010
ECT_MBXPROT_VOE = 0x0020

# CoE 详细定义
ECT_COEDET_SDO       = 0x01
ECT_COEDET_SDOINFO   = 0x02
ECT_COEDET_PDOASSIGN = 0x04
ECT_COEDET_PDOCONFIG = 0x08
ECT_COEDET_UPLOAD    = 0x10
ECT_COEDET_SDOCA     = 0x20


# ===================== PDO 性能统计结构体 =====================

class PDOStats(Structure):
    """PDO 性能统计结构体 (对应 C# Structures.PDOStats, Pack=1, uint*5 + ulong*4)"""
    _pack_ = 1
    _fields_ = [
        ('read_count', c_uint),
        ('write_count', c_uint),
        ('error_count', c_uint),
        ('total_bytes_read', c_uint),
        ('total_bytes_written', c_uint),
        ('last_cycle_time_ns', c_uint64),
        ('min_cycle_time_ns', c_uint64),
        ('max_cycle_time_ns', c_uint64),
        ('avg_cycle_time_ns', c_uint64),
    ]


# ===================== PDO 映射项结构体 =====================

class PDOMappingEntry(Structure):
    """PDO 映射项结构体"""
    _pack_ = 1
    _fields_ = [
        ('index', c_ushort),
        ('sub_index', c_ubyte),
        ('bit_length', c_ubyte),
        ('bit_offset', c_ushort),
        ('name', c_ubyte * 64),
        ('unit', c_ubyte * 16),
        ('readable', c_ubyte),
        ('writable', c_ubyte),
    ]


# ===================== 网络适配器信息结构体 =====================

class NetworkInfo(Structure):
    """
    网络适配器信息结构体 - 对应 C 端 ec_networkinfo_t
    必须与 Core.h 中的定义完全一致（Pack=1, 总大小260字节）
    """
    _pack_ = 1
    _fields_ = [
        ('name', c_ubyte * 128),    # EC_MAXLEN_ADAPTERNAME = 128
        ('desc', c_ubyte * 128),    # EC_MAXLEN_ADAPTERNAME = 128
        ('slave_num', c_int16),     # 从站数量
        ('redundant_slave_num', c_int16),  # 受冗余保护的从站数
    ]


# ===================== 通信统计信息结构体 =====================

class CommunicationStats(Structure):
    """通信统计信息结构体"""
    _pack_ = 1
    _fields_ = [
        ('total_cycles', c_uint),
        ('successful_cycles', c_uint),
        ('failed_cycles', c_uint),
        ('timeout_cycles', c_uint),
        ('average_cycle_time_us', c_double),
        ('max_cycle_time_us', c_double),
        ('min_cycle_time_us', c_double),
    ]


# ===================== 从站详细信息结构体 =====================

class SlaveInfo(Structure):
    """从站详细信息结构体"""
    _pack_ = 1
    _fields_ = [
        ('vendor_id', c_uint),
        ('product_code', c_uint),
        ('revision_number', c_uint),
        ('serial_number', c_uint),
        ('device_name', ctypes.c_char * 64),
        ('vendor_name', ctypes.c_char * 64),
        ('sync_manager_count', c_ushort),
        ('fmmu_count', c_ushort),
        ('supports_coe', ctypes.c_bool),
        ('supports_foe', ctypes.c_bool),
        ('supports_eoe', ctypes.c_bool),
        ('supports_soe', ctypes.c_bool),
    ]


# ===================== 实时统计信息结构体 =====================

class RealtimeStats(Structure):
    """实时统计信息结构体"""
    _pack_ = 1
    _fields_ = [
        ('current_cycle_time_us', c_double),
        ('jitter_us', c_double),
        ('lost_frames', c_uint),
        ('corrupted_frames', c_uint),
        ('bus_utilization', c_double),
    ]


# ===================== SyncManager 配置结构体 =====================

class EcSmt(Structure):
    """
    SyncManager 配置结构体 - 对应 C# ec_smt
    """
    _pack_ = 1
    _fields_ = [
        ('start_addr', c_ushort),   # SM 起始地址
        ('sm_length', c_ushort),    # SM 长度
        ('sm_flags', c_uint32),     # SM 标志
    ]


# ===================== FMMU 配置结构体 =====================

class EcFmmut(Structure):
    """
    FMMU 配置结构体 - 对应 C# ec_fmmut
    """
    _pack_ = 1
    _fields_ = [
        ('log_start', c_uint32),    # 逻辑起始地址
        ('log_length', c_ushort),   # 逻辑长度
        ('log_start_bit', c_ubyte), # 逻辑起始位
        ('log_end_bit', c_ubyte),   # 逻辑结束位
        ('phys_start', c_ushort),   # 物理起始地址
        ('phys_start_bit', c_ubyte), # 物理起始位
        ('fmmu_type', c_ubyte),     # FMMU 类型
        ('fmmu_active', c_ubyte),   # FMMU 激活
        ('unused1', c_ubyte),       # 保留
        ('unused2', c_ushort),      # 保留
    ]


# ===================== 从站结构体 =====================

class EcSlave(Structure):
    """
    从站结构体 - 对应 C# ec_slave / ec_slave_blittable
    必须与 ec_main.h 中的 C 结构完全一致（64位自然对齐）

    这是最核心的结构体，包含从站的全部运行时字段。
    """
    _fields_ = [
        # ==================== 基本状态字段 ====================
        ('state', c_ushort),            # 当前 EtherCAT 状态
        ('al_status_code', c_ushort),   # AL 状态码
        ('config_addr', c_ushort),      # 配置地址
        ('alias_addr', c_ushort),       # 别名地址
        ('eep_man', c_uint32),          # 制造商（来自 EEPROM）
        ('eep_id', c_uint32),           # 产品ID（来自 EEPROM）
        ('eep_rev', c_uint32),          # 修订版本（来自 EEPROM）
        ('eep_ser', c_uint32),          # 序列号（来自 EEPROM）
        ('itype', c_ushort),            # 接口类型
        ('dtype', c_ushort),            # 设备类型
        ('obits', c_ushort),            # 输出位数
        ('_padding1', c_ushort),        # 对齐填充
        ('obytes', c_uint32),           # 输出字节数
        ('_padding2', c_uint32),        # 对齐填充
        ('outputs', c_void_p),          # IOmap 中的输出指针
        ('ooffset', c_uint32),          # IOmap 中的输出偏移
        ('ostartbit', c_ubyte),         # 第一个输出字节的起始位
        ('_padding3', c_ubyte),         # 对齐填充
        ('ibits', c_ushort),            # 输入位数
        ('ibytes', c_uint32),           # 输入字节数
        ('_padding4', c_uint32),        # 对齐填充
        ('inputs', c_void_p),           # IOmap 中的输入指针
        ('ioffset', c_uint32),          # IOmap 中的输入偏移
        ('istartbit', c_ubyte),         # 第一个输入字节的起始位

        # ==================== SM 配置 ====================
        ('sm', EcSmt * 8),              # 8 个 SyncManager 条目
        ('sm_type', c_ubyte * 8),       # SM 类型

        # ==================== FMMU 配置 ====================
        ('fmmu', EcFmmut * 4),          # 4 个 FMMU 条目
        ('fmmu0_func', c_ubyte),        # FMMU0 功能
        ('fmmu1_func', c_ubyte),        # FMMU1 功能
        ('fmmu2_func', c_ubyte),        # FMMU2 功能
        ('fmmu3_func', c_ubyte),        # FMMU3 功能

        # ==================== 邮箱配置 ====================
        ('mbx_l', c_ushort),            # 写邮箱长度
        ('mbx_wo', c_ushort),           # 邮箱写偏移
        ('mbx_rl', c_ushort),           # 读邮箱长度
        ('mbx_ro', c_ushort),           # 邮箱读偏移
        ('mbx_proto', c_ushort),        # 邮箱支持的协议
        ('mbx_cnt', c_ubyte),           # 邮箱链路层协议计数器

        # ==================== DC 与拓扑 ====================
        ('hasdc', c_ubyte),             # 是否支持 DC
        ('ptype', c_ubyte),             # 物理类型
        ('topology', c_ubyte),          # 拓扑结构
        ('activeports', c_ubyte),       # 活跃端口位图
        ('consumedports', c_ubyte),     # 已用端口位图
        ('parent', c_ushort),           # 父从站编号
        ('parentport', c_ubyte),        # 父从站端口号
        ('entryport', c_ubyte),         # 本从站入口端口号
        ('dc_rt_a', c_int32),           # DC 端口 A 接收时间
        ('dc_rt_b', c_int32),           # DC 端口 B 接收时间
        ('dc_rt_c', c_int32),           # DC 端口 C 接收时间
        ('dc_rt_d', c_int32),           # DC 端口 D 接收时间
        ('pdelay', c_int32),            # 传播延迟
        ('dc_next', c_ushort),          # 下一个 DC 从站
        ('dc_previous', c_ushort),      # 上一个 DC 从站
        ('dc_cycle', c_int32),          # DC SYNC0 周期时间（纳秒）
        ('dc_cycle1', c_int32),         # DC SYNC1 周期时间（纳秒）
        ('dc_shift', c_int32),          # DC 偏移量
        ('dc_active', c_ushort),        # DC AssignActivate 值
        ('sii_index', c_ushort),        # SII 配置链接
        ('eep_8byte', c_ubyte),         # 1 = 8字节/次读取
        ('eep_pdi', c_ubyte),           # 0 = EEPROM 归主站, 1 = 归 PDI
        ('coe_details', c_ubyte),       # CoE 详细
        ('foe_details', c_ubyte),       # FoE 详细
        ('eoe_details', c_ubyte),       # EoE 详细
        ('soe_details', c_ubyte),       # SoE 详细
        ('ebus_current', c_int16),      # E-bus 电流
        ('block_lrw', c_ubyte),         # 若 >0 禁止使用 LRW
        ('group', c_ubyte),             # 分组
        ('fmmu_unused', c_ubyte),       # 第一个未使用的 FMMU
        ('islost', c_ubyte),            # 从站是否丢失

        # ==================== 函数指针与邮箱处理 ====================
        ('po2so_config', c_void_p),     # PO->SO 配置函数指针
        ('mbx_handler_state', c_int32), # 邮箱处理器状态
        ('mbx_rmp_state', c_int32),     # 邮箱 RMP 状态
        ('mbx_in_state_ex', c_ushort),  # 邮箱 RMP 扩展状态
        ('_padding8a', c_ushort),       # 对齐填充
        ('_padding8b', c_uint32),       # 对齐填充

        # ==================== CoE 邮箱 ====================
        ('coe_mbx_in', c_void_p),       # CoE 邮箱输入缓冲区指针
        ('coe_mbx_in_full', c_ubyte),   # CoE 邮箱输入标志
        ('_padding9a', c_ubyte),        # 对齐填充
        ('_padding9b', c_ushort),       # 对齐填充
        ('coe_mbx_overrun', c_int32),   # CoE 邮箱溢出计数

        # ==================== SoE 邮箱 ====================
        ('soe_mbx_in', c_void_p),
        ('soe_mbx_in_full', c_ubyte),
        ('_padding10a', c_ubyte),
        ('_padding10b', c_ushort),
        ('soe_mbx_overrun', c_int32),

        # ==================== FoE 邮箱 ====================
        ('foe_mbx_in', c_void_p),
        ('foe_mbx_in_full', c_ubyte),
        ('_padding11a', c_ubyte),
        ('_padding11b', c_ushort),
        ('foe_mbx_overrun', c_int32),

        # ==================== EoE 邮箱 ====================
        ('eoe_mbx_in', c_void_p),
        ('eoe_mbx_in_full', c_ubyte),
        ('_padding12a', c_ubyte),
        ('_padding12b', c_ushort),
        ('eoe_mbx_overrun', c_int32),

        # ==================== VoE 邮箱 ====================
        ('voe_mbx_in', c_void_p),
        ('voe_mbx_in_full', c_ubyte),
        ('_padding13a', c_ubyte),
        ('_padding13b', c_ushort),
        ('voe_mbx_overrun', c_int32),

        # ==================== AoE 邮箱 ====================
        ('aoe_mbx_in', c_void_p),
        ('aoe_mbx_in_full', c_ubyte),
        ('_padding14a', c_ubyte),
        ('_padding14b', c_ushort),
        ('aoe_mbx_overrun', c_int32),

        # ==================== 邮箱状态 ====================
        ('mbx_status', c_void_p),       # 输出邮箱状态寄存器缓冲区指针

        # ==================== 名称字段 ====================
        ('group_name', c_ubyte * 41),   # 组名称 (EC_MAXNAME + 1)
        ('device_name', c_ubyte * 41),  # 设备名称 (EC_MAXNAME + 1)
        ('sync_manager_count', c_ushort),  # 同步管理器数量

        # ==================== FSoE (功能安全) ====================
        ('fsoe_capable', c_ubyte),           # FSoE 能力标志
        ('_padding15a', c_ubyte),            # 对齐填充
        ('_padding15b', c_ushort),           # 对齐填充
        ('fsoe_connection', c_void_p),       # FSoE 连接指针
        ('fsoe_sm_context', c_void_p),       # FSoE 状态机上下文指针
        ('fsoe_connection_id', c_ushort),    # FSoE 连接 ID
        ('fsoe_safety_address', c_ushort),   # FSoE 安全地址
        ('fsoe_safe_input_size', c_ushort),  # FSoE 安全输入大小（字节）
        ('fsoe_safe_output_size', c_ushort), # FSoE 安全输出大小（字节）
        ('fsoe_pdo_input_offset', c_uint32), # FSoE PDO 输入偏移
        ('fsoe_pdo_output_offset', c_uint32), # FSoE PDO 输出偏移

        # ==================== 启动配置 ====================
        ('pdo_assignment_enabled', c_ubyte),     # PDO Assignment 写入开关
        ('pdo_configuration_enabled', c_ubyte),  # PDO Configuration 写入开关
        ('pdo_config_initialized', c_ubyte),     # PDO 配置是否已初始化
        ('supports_complete_access', c_ubyte),   # 是否支持 Complete Access
    ]


# ===================== 主站状态结构体 =====================

class EcState(Structure):
    """
    主站状态结构 - 对应 C# ec_State
    所有主站配置属性都存储在此结构中
    通过 GetMasterState() 获取指针后直接读写字段
    """
    _fields_ = [
        # ==================== EtherCAT 状态 ====================
        ('state', c_ushort),                # 当前 EtherCAT 状态
        ('al_status_code', c_ushort),       # AL 状态码
        ('slave_count', c_int32),           # 网络中的从站数量

        # ==================== 时间配置 ====================
        ('loop_cycle', c_uint32),           # 循环周期时间（纳秒）
        ('dc_cycle', c_uint32),             # DC 诊断监控基准周期（纳秒）
        ('dc_time', c_int64),               # DC 时间（实时值）

        # ==================== PDO 数据缓冲区 ====================
        ('iomap', c_ubyte * 65536),         # IO 映射缓冲区
        ('iomap_mutex', c_void_p),          # IOmap 访问同步互斥锁

        # 双缓冲区支持
        ('iomap_buffer', c_ubyte * 65536),  # 双缓冲区
        ('buffer_version', c_uint32),       # 版本计数器
        ('buffer_dirty', c_ubyte),          # 脏标志

        # ==================== 互斥锁保护配置 ====================
        ('mutex_protection', c_ubyte),      # 1 = 自动锁定, 0 = 无自动锁定

        # ==================== CPU 亲和性配置 ====================
        ('pdo_cpu_affinity', c_byte),       # PDO 线程 CPU 核心绑定 (-1 = 未配置)

        # ==================== DC 自动偏移配置 ====================
        ('dc_auto_shift_enabled', c_ubyte), # 0 = 禁用, 1 = 启用

        # ==================== 网络配置 ====================
        ('use_udp', c_ubyte),               # 0 = 标准帧, 1 = UDP 帧

        # ==================== 可选功能开关 ====================
        ('adaptive_timeout_enabled', c_ubyte),  # 自适应超时 (0=禁用, 1=启用)

        # ==================== PDO 通信优化 ====================
        ('overlapping_groups', c_ubyte),    # 重叠组 (0=禁用, 1=启用)
        ('packed_mode', c_ubyte),            # Packed PDO 映射 (0=字节对齐, 1=bit紧密)

        # ==================== 帧优先级配置 ====================
        ('frame_high_priority', c_ubyte),   # 帧高优先级 (0=禁用, 1=启用)

        # ==================== VLAN 配置 ====================
        ('vlan_id', c_ushort),              # VLAN ID (0=禁用)
        ('vlan_priority', c_ubyte),         # VLAN 优先级 (0-7)

        # ==================== 状态转换超时 (ETG.1020) ====================
        ('timeout_init_to_preop', c_uint32),    # INIT->PREOP 超时 (ms)
        ('timeout_preop_to_safeop', c_uint32),  # PREOP->SAFEOP 超时 (ms)
        ('timeout_safeop_to_op', c_uint32),     # SAFEOP->OP 超时 (ms)

        # ==================== 看门狗配置 (ETG.1000.4) ====================
        ('wd_pd_timeout_ms', c_ushort),     # 过程数据看门狗超时 (ms)
        ('wd_pdi_timeout_ms', c_ushort),    # PDI 看门狗超时 (ms)

        ('filter_threshold', c_uint32),  # 判断滤波阈值

        # ==================== 帧重复 (ETG.1500 5.4.3) ====================
        ('frame_repeat_count', c_ubyte),    # 帧重复次数

        # ==================== 组配置 ====================
        ('active_group_count', c_ubyte),    # 活跃组数量
        ('_group_pad', c_ubyte * 2),        # 对齐填充
        ('group_config_raw', c_ubyte * 64), # 8组 x 8字节 = 64字节
    ]


# ===================== 配置列表结构体 =====================

class EcConfigListEnhanced(Structure):
    """从站配置列表结构体 - 对应 C# ec_configlist_enhanced"""
    _pack_ = 1
    _fields_ = [
        ('man', c_uint32),              # 制造商代码
        ('id', c_uint32),               # 从站 ID
        ('index', c_ushort),            # 配置索引
        ('name', ctypes.c_char * 41),   # 可读名称 (EC_MAXNAME + 1)
        ('dtype', c_ubyte),             # 数据类型
        ('ibits', c_ushort),            # 输入位数
        ('obits', c_ushort),            # 输出位数
        ('sm2a', c_ushort),             # 同步管理器2地址
        ('sm2f', c_uint32),             # 同步管理器2标志
        ('sm3a', c_ushort),             # 同步管理器3地址
        ('sm3f', c_uint32),             # 同步管理器3标志
        ('fm0ac', c_ubyte),             # FMMU 0 激活
        ('fm1ac', c_ubyte),             # FMMU 1 激活
    ]


# ===================== 启动配置结构体 =====================

class EcStartupListEnhanced(Structure):
    """启动配置结构体 - 对应 C# ec_startuplist_enhanced"""
    _pack_ = 1
    _fields_ = [
        ('man', c_uint32),              # eep_man
        ('id', c_uint32),               # eep_id
        ('index', c_ushort),            # configadr
        ('sdo_index', c_ushort),        # OD 地址
        ('sdo_index2', c_ushort),       # OE 地址
        ('length', c_ubyte),            # 数据长度
        ('data', c_ubyte * 1486),       # 数据缓冲区 (EC_MAXMBX)
    ]


# ===================== DC 配置列表结构体 =====================

class EcDcListEnhanced(Structure):
    """DC 配置列表结构体 - 对应 C# ec_dclist_enhanced"""
    _pack_ = 1
    _fields_ = [
        ('man', c_uint32),              # eep_man
        ('id', c_uint32),               # eep_id
        ('config_addr', c_ushort),      # configadr
        ('sync_s', c_int32),            # SyncS
        ('sync0', c_uint32),            # Sync0
        ('sync1', c_uint32),            # Sync1
    ]


# ===================== 网络适配器结构体 =====================

class EcAdapterEnhanced(Structure):
    """网络适配器结构体 - 对应 C# ec_adapter_enhanced"""
    _pack_ = 1
    _fields_ = [
        ('name', ctypes.c_char * 128),  # 适配器名称
        ('desc', ctypes.c_char * 128),  # 适配器描述
        ('next', c_void_p),             # 下一个适配器指针
    ]


# ===================== 启动参数结构体 =====================

class EcStartupParam(Structure):
    """启动参数结构体 - 对应 C# ec_startup_param_t"""
    _pack_ = 1
    _fields_ = [
        ('index', c_ushort),            # SDO 索引
        ('subindex', c_ubyte),          # SDO 子索引
        ('data', c_void_p),             # 数据指针
        ('data_length', c_uint32),      # 数据长度
        ('phase', c_ubyte),             # 执行阶段 (0=预初始化, 1=初始化, 2=操作态准备)
        ('priority', c_ubyte),          # 优先级（数值越小优先级越高）
        ('is_read', c_ubyte),           # 是否为读取操作
    ]


# ===================== 内部诊断数据结构体 =====================

class InternalDiagnostics(Structure):
    """
    内部诊断数据结构 - 对应 C 层 internal_diagnostics_t
    这是所有统计信息的唯一所有者
    使用 GetDiagnosticsPointer() 进行零拷贝访问
    注意：不使用 pack=1，因为 C 端也使用自然对齐
    """
    _fields_ = [
        # ==================== 实时性能数据 ====================
        ('cache_cnt', c_uint32),             # 当前秒内的周期计数
        ('rt_cnt', c_uint32),                # 上一秒的周期计数（频率Hz）
        ('cycle_count', c_uint32),           # 累计总周期数

        ('error_cache_cnt', c_uint32),       # 当前秒内的错误计数
        ('error_cnt', c_uint32),             # 上一秒的错误计数

        ('wkc', c_ushort),                   # 当前工作计数器
        ('expected_wkc', c_ushort),          # 期望工作计数器

        ('cycle_time_span', c_uint32),       # 最近一次周期耗时（微秒）

        # ==================== 帧错误统计（累计） ====================
        ('frame_errors', c_uint32),          # 总帧错误数
        ('lost_frames', c_uint32),           # 丢失帧数
        ('out_of_order_frames', c_uint32),   # 乱序帧数
        ('checksum_errors', c_uint32),       # 校验和错误数
        ('timeout_frames', c_uint32),        # 超时帧数

        # ==================== 从站级错误计数器 (EC_MAXSLAVE=512) ====================
        ('rx_error_count', c_uint32 * 512),       # 每个从站的接收错误计数
        ('tx_error_count', c_uint32 * 512),       # 每个从站的发送错误计数
        ('lost_link_count', c_ushort * 512),      # 每个从站的链路丢失计数
        ('invalid_frame_count', c_ushort * 512),  # 每个从站的无效帧计数

        # ==================== WKC 统计 ====================
        ('working_counter_errors', c_ushort),     # WKC 错误次数
        ('consecutive_wkc_errors', c_ushort),     # 连续 WKC 错误次数
        ('total_wkc_mismatches', c_uint32),       # WKC 不匹配总次数

        # ==================== 时间统计 ====================
        ('cycle_start_time', c_uint64),            # 周期开始时间戳（纳秒）
        ('cycle_time_accumulator', c_double),      # 周期时间累加器
        ('last_snapshot_time', c_uint64),          # 上次快照时间戳（秒）
        ('snapshot_cycle_count', c_uint32),        # 上次快照时的 cycle_count

        # ==================== 抖动统计 (1秒窗口) ====================
        ('last_cycle_time_us', c_double),          # 上一次周期时间（微秒）
        ('jitter_accumulator', c_double),          # 1秒内抖动累加器
        ('max_jitter_in_second', c_double),        # 1秒内最大抖动（微秒）
        ('jitter_sample_count', c_uint32),         # 1秒内抖动采样数

        # 快照值（每秒更新一次）
        ('avg_jitter_us', c_double),               # 上一秒的平均抖动
        ('max_jitter_us', c_double),               # 上一秒的最大抖动
        ('cycle_time_sample_count', c_uint32),     # 周期时间采样数

        # ==================== 冗余端口统计 ====================
        ('primary_port_tx_count', c_uint32),       # 主端口发送计数
        ('primary_port_rx_count', c_uint32),       # 主端口接收计数
        ('secondary_port_tx_count', c_uint32),     # 副端口发送计数
        ('secondary_port_rx_count', c_uint32),     # 副端口接收计数
        ('primary_port_errors', c_uint32),         # 主端口错误计数
        ('secondary_port_errors', c_uint32),       # 副端口错误计数

        # ==================== 链路质量监控 (EC_MAXSLAVE=512) ====================
        ('link_quality_percent', c_int16 * 512),   # 每个从站的链路质量 (0-100%)
        ('last_good_frame_time', c_uint32 * 512),  # 每个从站最后成功通信时间

        # ==================== 标志位 ====================
        ('initialized', c_int32),                  # 诊断模块是否已初始化
        ('enabled', c_int32),                      # 诊断数据收集是否启用

        # ==================== 5秒滑动窗口 ====================
        ('win_frame_errors', c_uint32 * 5),
        ('win_lost_frames', c_uint32 * 5),
        ('win_out_of_order', c_uint32 * 5),
        ('win_checksum_errors', c_uint32 * 5),
        ('win_timeout_frames', c_uint32 * 5),
        ('win_wkc_errors', c_ushort * 5),
        ('win_wkc_mismatches', c_uint32 * 5),
        ('win_primary_errors', c_uint32 * 5),
        ('win_secondary_errors', c_uint32 * 5),
        ('win_head', c_int32),                     # 环形缓冲区写入位置
        ('win_filled', c_int32),                   # 已填充槽数 (0~5)
    ]


# ===================== FoE 扩展选项结构体 =====================

class FoEOptionsStruct(Structure):
    """FoE 扩展选项结构"""
    _pack_ = 1
    _fields_ = [
        ('enable_crc', c_ubyte),
        ('strict_mode', c_ubyte),
        ('auto_append_crc', c_ubyte),
        ('expected_crc', c_uint),
        ('crc_progress_callback', c_void_p),
        ('crc_callback_userdata', c_void_p),
        ('reserved', c_uint * 8),
    ]

    @staticmethod
    def default():
        """初始化为默认值"""
        opts = FoEOptionsStruct()
        opts.enable_crc = 0
        opts.strict_mode = 1
        opts.auto_append_crc = 1
        opts.expected_crc = 0
        return opts


# ===================== 组配置辅助方法 =====================

class EcGroupConfigHelper:
    """
    组配置辅助方法

    对应 C# EcGroupConfigHelper
    操作 ec_State.group_config_raw 中每组 8 字节的配置数据。
    布局: [enabled:1][cycle_divider:1][expected_wkc:2][slave_count:2][frame_repeat_eligible:1][reserved:1]
    """

    GROUP_CONFIG_SIZE = 8

    @staticmethod
    def get_group_enabled(group_config_raw: bytes, group: int) -> bool:
        """获取组是否启用"""
        if group >= 8:
            return False
        return group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE] != 0

    @staticmethod
    def set_group_enabled(group_config_raw: bytearray, group: int, enabled: bool):
        """设置组启用状态"""
        if group >= 8:
            return
        group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE] = 1 if enabled else 0

    @staticmethod
    def get_group_cycle_divider(group_config_raw: bytes, group: int) -> int:
        """获取组周期分频器"""
        if group >= 8:
            return 0
        return group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 1]

    @staticmethod
    def set_group_cycle_divider(group_config_raw: bytearray, group: int, divider: int):
        """设置组周期分频器"""
        if group >= 8:
            return
        group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 1] = divider & 0xFF

    @staticmethod
    def get_group_expected_wkc(group_config_raw: bytes, group: int) -> int:
        """获取组期望 WKC"""
        if group >= 8:
            return 0
        off = group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 2
        return int.from_bytes(group_config_raw[off:off + 2], byteorder='little', signed=False)

    @staticmethod
    def get_group_slave_count(group_config_raw: bytes, group: int) -> int:
        """获取组从站数量"""
        if group >= 8:
            return 0
        off = group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 4
        return int.from_bytes(group_config_raw[off:off + 2], byteorder='little', signed=False)

    @staticmethod
    def get_group_frame_repeat_eligible(group_config_raw: bytes, group: int) -> bool:
        """获取组帧重复资格 (ETG.1500 5.4.3)"""
        if group >= 8:
            return False
        return group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 6] != 0

    @staticmethod
    def set_group_frame_repeat_eligible(group_config_raw: bytearray, group: int, eligible: bool):
        """设置组帧重复资格 (ETG.1500 5.4.3)"""
        if group >= 8:
            return
        group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 6] = 1 if eligible else 0
