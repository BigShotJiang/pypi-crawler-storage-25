# -*- coding: utf-8 -*-
"""
EtherCAT 类型定义 - 与 C# Data/Type.cs 对应

包含所有 EtherCAT 协议相关的枚举、标志位和数据类。
"""

from enum import IntEnum, IntFlag
from dataclasses import dataclass, field
from typing import Optional, List


# ===================== 基础枚举 =====================

class EcErr(IntEnum):
    """错误码"""
    OK = 0
    ALREADY_INITIALIZED = 1
    NOT_INITIALIZED = 2
    TIMEOUT = 3
    NO_SLAVES = 4
    NOK = 5


class EcState(IntEnum):
    """EtherCAT 从站状态"""
    NONE = 0x00      # 无状态
    INIT = 0x01      # 初始化
    PRE_OP = 0x02    # 预运行
    BOOT = 0x03      # Bootstrap
    SAFE_OP = 0x04   # 安全运行
    OP = 0x08        # 运行
    ACK = 0x10       # 错误确认
    ERROR = 0x10     # 错误标志 (与 ACK 相同值)


class EcLinkState(IntEnum):
    """链路状态"""
    DISCONNECTED = 0     # 无连接
    CONNECTED = 1        # 主网口和冗余网口都连接
    PRIMARY_ONLY = 3     # 仅主网口连接
    SECONDARY_ONLY = 4   # 仅冗余网口连接


class RingMode(IntEnum):
    """环拓扑冗余运行模式"""
    INACTIVE = 0   # 未激活：冗余监控未初始化
    DUAL = 1       # 双向冗余：P1打开, secondary激活后两端发送LRW
    DEGRADED = 2   # 降级模式：secondary链路不可用，仅primary工作


class EcBufState(IntEnum):
    """缓冲区状态"""
    EMPTY = 0x00
    ALLOC = 0x01
    TX = 0x02
    RCVD = 0x03
    COMPLETE = 0x04


class EcDataType(IntEnum):
    """EtherCAT 数据类型"""
    BOOLEAN = 0x0001           # 布尔
    INTEGER8 = 0x0002          # 有符号8位整数
    INTEGER16 = 0x0003         # 有符号16位整数
    INTEGER32 = 0x0004         # 有符号32位整数
    UNSIGNED8 = 0x0005         # 无符号8位整数
    UNSIGNED16 = 0x0006        # 无符号16位整数
    UNSIGNED32 = 0x0007        # 无符号32位整数
    REAL32 = 0x0008            # 32位浮点
    VISIBLE_STRING = 0x0009    # 可见字符串
    OCTET_STRING = 0x000A      # 八进制字符串
    UNICODE_STRING = 0x000B    # Unicode字符串
    TIME_OF_DAY = 0x000C       # 时间
    TIME_DIFFERENCE = 0x000D   # 时间差
    DOMAIN = 0x000F            # 域数据
    INTEGER24 = 0x0010         # 有符号24位整数
    REAL64 = 0x0011            # 64位浮点
    # ETG.1000.6 Table 63: 扩展整数类型
    INTEGER40 = 0x0012         # 40位有符号整数
    INTEGER48 = 0x0013         # 48位有符号整数
    INTEGER56 = 0x0014         # 56位有符号整数
    INTEGER64 = 0x0015         # 有符号64位整数
    UNSIGNED24 = 0x0016        # 无符号24位整数
    UNSIGNED40 = 0x0018        # 40位无符号整数
    UNSIGNED48 = 0x0019        # 48位无符号整数
    UNSIGNED56 = 0x001A        # 56位无符号整数
    UNSIGNED64 = 0x001B        # 无符号64位整数
    BIT1 = 0x0030              # 1位
    BIT2 = 0x0031              # 2位
    BIT3 = 0x0032              # 3位
    BIT4 = 0x0033              # 4位
    BIT5 = 0x0034              # 5位
    BIT6 = 0x0035              # 6位
    BIT7 = 0x0036              # 7位
    BIT8 = 0x0037              # 8位


class EcCmdType(IntEnum):
    """EtherCAT 命令类型"""
    NOP = 0x00    # 无操作
    APRD = 0x01   # 自动递增物理读
    APWR = 0x02   # 自动递增物理写
    APRW = 0x03   # 自动递增物理读写
    FPRD = 0x04   # 配置地址物理读
    FPWR = 0x05   # 配置地址物理写
    FPRW = 0x06   # 配置地址物理读写
    BRD = 0x07    # 广播读
    BWR = 0x08    # 广播写
    BRW = 0x09    # 广播读写
    LRD = 0x0A    # 逻辑读
    LWR = 0x0B    # 逻辑写
    LRW = 0x0C    # 逻辑读写
    ARMW = 0x0D   # 自动递增物理读-多次写
    FRMW = 0x0E   # 配置地址物理读-多次写


class EcEcmdType(IntEnum):
    """EtherCAT EEPROM 命令类型"""
    NOP = 0x0000
    READ = 0x0100
    WRITE = 0x0201
    RELOAD = 0x0300


class LogLevel(IntEnum):
    """日志级别"""
    INFO = 0
    DEBUG = 1
    WARN = 2
    ERROR = 3
    FATAL = 4


# ===================== AL 状态码 (ETG.1020) =====================

class EcALState(IntEnum):
    """AL 状态码 (ETG.1020)"""
    NO_ERROR = 0x0000
    UNSPECIFIED_ERROR = 0x0001
    NO_MEMORY = 0x0002
    # 无效的设备设置 (如总线耦合器无物理模块连接)
    INVALID_DEVICE_SETUP = 0x0003
    # 输出/输入映射与硬件或软件修订版不匹配
    INVALID_REVISION = 0x0004
    # SII/EEPROM 内容与固件不匹配
    SII_EEPROM_MISMATCH = 0x0006
    # 固件更新失败，旧固件仍在运行
    FIRMWARE_UPDATE_FAILED = 0x0007
    # 硬件/软件许可证无效或评估期到期
    LICENSE_ERROR = 0x000E
    INVALID_STATE_CHANGE = 0x0011
    UNKNOWN_REQUESTED_STATE = 0x0012
    BOOTSTRAP_NOT_SUPPORTED = 0x0013
    NO_VALID_FIRMWARE = 0x0014
    INVALID_MAILBOX_CONFIG = 0x0015
    INVALID_MAILBOX_CONFIG2 = 0x0016
    INVALID_SYNC_MANAGER_CONFIG = 0x0017
    NO_VALID_INPUTS = 0x0018
    NO_VALID_OUTPUTS = 0x0019
    SYNC_ERROR = 0x001A
    SYNC_MANAGER_WATCHDOG = 0x001B
    INVALID_SYNC_MANAGER_TYPES = 0x001C
    INVALID_OUTPUT_CONFIG = 0x001D
    INVALID_INPUT_CONFIG = 0x001E
    INVALID_WATCHDOG_CONFIG = 0x001F
    NEEDS_COLD_START = 0x0020
    NEEDS_INIT = 0x0021
    NEEDS_PREOP = 0x0022
    NEEDS_SAFEOP = 0x0023
    INVALID_INPUT_MAPPING = 0x0024
    INVALID_OUTPUT_MAPPING = 0x0025
    INCONSISTENT_SETTINGS = 0x0026
    FREERUN_NOT_SUPPORTED = 0x0027
    SYNC_NOT_SUPPORTED = 0x0028
    FREERUN_NEEDS_3BUFFER = 0x0029
    BACKGROUND_WATCHDOG = 0x002A
    NO_VALID_IO = 0x002B
    FATAL_SYNC_ERROR = 0x002C
    NO_SYNC_ERROR = 0x002D
    # EtherCAT 周期时间小于从站支持的最小周期时间
    CYCLE_TIME_TOO_SMALL = 0x002E
    INVALID_DC_SYNC_CONFIG = 0x0030
    INVALID_DC_LATCH = 0x0031
    PLL_ERROR = 0x0032
    DC_SYNC_IO_ERROR = 0x0033
    DC_SYNC_TIMEOUT = 0x0034
    INVALID_DC_SYNC_CYCLE = 0x0035
    INVALID_SYNC0_CYCLE = 0x0036
    INVALID_SYNC1_CYCLE = 0x0037
    MAILBOX_AOE = 0x0041
    MAILBOX_EOE = 0x0042
    MAILBOX_COE = 0x0043
    MAILBOX_FOE = 0x0044
    MAILBOX_SOE = 0x0045
    MAILBOX_VOE = 0x004F
    EEPROM_NO_ACCESS = 0x0050
    EEPROM_ERROR = 0x0051
    # 外部硬件未就绪 (外部连接或信号缺失)
    EXTERNAL_HARDWARE_NOT_READY = 0x0052
    SLAVE_RESTARTED = 0x0060
    DEVICE_ID_UPDATED = 0x0061
    # 检测到的模块标识列表与配置不匹配
    MODULE_IDENT_LIST_MISMATCH = 0x0070
    # 供电电压过低
    SUPPLY_VOLTAGE_TOO_LOW = 0x0080
    # 供电电压过高
    SUPPLY_VOLTAGE_TOO_HIGH = 0x0081
    # 温度过低
    TEMPERATURE_TOO_LOW = 0x0082
    # 温度过高
    TEMPERATURE_TOO_HIGH = 0x0083
    APP_CONTROLLER_AVAILABLE = 0x00F0
    UNKNOWN = 0xFFFF

    def describe(self) -> str:
        """获取中文描述"""
        _desc = {
            0x0000: "无错误",
            0x0001: "未指定的错误",
            0x0002: "内存不足",
            0x0003: "无效的设备设置",
            0x0004: "无效的修订版本",
            0x0006: "SII/EEPROM不匹配",
            0x0007: "固件更新失败",
            0x000E: "许可证错误",
            0x0011: "无效的状态变更",
            0x0012: "未知的请求状态",
            0x0013: "不支持Bootstrap",
            0x0014: "无有效固件",
            0x0015: "无效的邮箱配置",
            0x0016: "无效的邮箱配置(2)",
            0x0017: "无效的同步管理器配置",
            0x0018: "无有效输入",
            0x0019: "无有效输出",
            0x001A: "同步错误",
            0x001B: "同步管理器看门狗",
            0x001C: "无效的同步管理器类型",
            0x001D: "无效的输出配置",
            0x001E: "无效的输入配置",
            0x001F: "无效的看门狗配置",
            0x0020: "需要冷启动",
            0x0021: "需要Init状态",
            0x0022: "需要PreOp状态",
            0x0023: "需要SafeOp状态",
            0x0024: "无效的输入映射",
            0x0025: "无效的输出映射",
            0x0026: "不一致的设置",
            0x0027: "不支持FreeRun",
            0x0028: "不支持同步",
            0x0029: "FreeRun需要3缓冲",
            0x002A: "后台看门狗",
            0x002B: "无有效IO",
            0x002C: "致命同步错误",
            0x002D: "无同步错误",
            0x002E: "周期时间过小",
            0x0030: "无效的DC同步配置",
            0x0031: "无效的DC锁存配置",
            0x0032: "PLL错误",
            0x0033: "DC同步IO错误",
            0x0034: "DC同步超时",
            0x0035: "无效的DC同步周期",
            0x0036: "无效的Sync0周期",
            0x0037: "无效的Sync1周期",
            0x0041: "邮箱AoE协议错误",
            0x0042: "邮箱EoE协议错误",
            0x0043: "邮箱CoE协议错误",
            0x0044: "邮箱FoE协议错误",
            0x0045: "邮箱SoE协议错误",
            0x004F: "邮箱VoE协议错误",
            0x0050: "EEPROM无访问权限",
            0x0051: "EEPROM错误",
            0x0052: "外部硬件未就绪",
            0x0060: "从站已重启",
            0x0061: "设备ID已更新",
            0x0070: "模块标识列表不匹配",
            0x0080: "供电电压过低",
            0x0081: "供电电压过高",
            0x0082: "温度过低",
            0x0083: "温度过高",
            0x00F0: "应用控制器可用",
            0xFFFF: "未知错误",
        }
        return _desc.get(self.value, f"未知(0x{self.value:04X})")


class ALErrorCategory(IntEnum):
    """AL 状态码错误分类"""
    NONE = 0          # 无错误
    TRANSIENT = 1     # 临时错误 - 可通过重试自动恢复
    CONFIGURATION = 2 # 配置错误 - 需要重新配置
    HARDWARE = 3      # 硬件错误 - 需要用户干预
    UNKNOWN = 4       # 未知错误


def classify_al_error(al_status_code: int) -> ALErrorCategory:
    """
    根据 AL Status Code 判断错误类别。
    参考 ETG.1020 标准: 临时错误自动重试, 配置错误需要重新配置, 硬件错误需要用户干预。

    参数:
        al_status_code: AL 状态码 (ushort)

    返回:
        错误分类
    """
    if al_status_code == 0x0000:
        return ALErrorCategory.NONE

    # 临时错误 (可自动恢复)
    transient = {0x0011, 0x001B, 0x001D, 0x0032, 0x0033, 0x0034}
    if al_status_code in transient:
        return ALErrorCategory.TRANSIENT

    # 配置错误 (需要重新配置)
    configuration = {
        0x0015, 0x0016, 0x0017, 0x0018, 0x0019, 0x001A,
        0x001C, 0x001E, 0x001F, 0x0030, 0x0031,
    }
    if al_status_code in configuration:
        return ALErrorCategory.CONFIGURATION

    # 硬件错误 (需要用户干预)
    hardware = {0x0042, 0x0043, 0x0050, 0x0051, 0x0060}
    if al_status_code in hardware:
        return ALErrorCategory.HARDWARE

    # 0x0040-0x005F 范围内都视为硬件错误
    if 0x0040 <= al_status_code <= 0x005F:
        return ALErrorCategory.HARDWARE

    return ALErrorCategory.UNKNOWN


# ===================== 邮箱协议 =====================

class MailboxError(IntEnum):
    """邮箱错误码"""
    NO_ERROR = 0x0000
    SYNTAX_ERROR = 0x0001
    PROTOCOL_NOT_SUPPORTED = 0x0002
    WRONG_CHANNEL_FIELD = 0x0003
    SERVICE_NOT_SUPPORTED = 0x0004
    INVALID_MAILBOX_HEADER = 0x0005
    DATA_TOO_SHORT = 0x0006
    NO_MEMORY_IN_SLAVE = 0x0007
    INCONSISTENT_DATA_LENGTH = 0x0008
    UNKNOWN_ERROR = 0xFFFF

    def describe(self) -> str:
        """获取中文描述"""
        _desc = {
            0x0000: "无错误",
            0x0001: "语法错误",
            0x0002: "不支持的协议",
            0x0003: "错误的通道字段",
            0x0004: "不支持的服务",
            0x0005: "无效的邮箱头",
            0x0006: "数据过短",
            0x0007: "从站内存不足",
            0x0008: "数据长度不一致",
            0xFFFF: "未知错误",
        }
        return _desc.get(self.value, f"未知(0x{self.value:04X})")


class MailboxType(IntEnum):
    """邮箱类型"""
    ERROR_MAILBOX = 0x00          # 错误邮箱
    ADS_OVER_ETHERCAT = 0x01      # AoE (ADS over EtherCAT)
    ETHERNET_OVER_ETHERCAT = 0x02 # EoE (Ethernet over EtherCAT)
    CANOPEN_OVER_ETHERCAT = 0x03  # CoE (CANopen over EtherCAT)
    FILE_OVER_ETHERCAT = 0x04     # FoE (File over EtherCAT)
    SERVO_OVER_ETHERCAT = 0x05    # SoE (Servo over EtherCAT)
    VENDOR_OVER_ETHERCAT = 0x0F   # VoE (Vendor over EtherCAT)


# ===================== SDO 错误码 =====================

class SDOError(IntEnum):
    """SDO 错误码 (CoE)"""
    NO_ERROR = 0x00000000
    TOGGLE_BIT_NOT_CHANGED = 0x05030000
    SDO_PROTOCOL_TIMEOUT = 0x05040000
    INVALID_COMMAND_SPECIFIER = 0x05040001
    OUT_OF_MEMORY = 0x05040005
    UNSUPPORTED_ACCESS = 0x06010000
    READ_WRITE_ONLY_ERROR = 0x06010001
    WRITE_READ_ONLY_ERROR = 0x06010002
    SUBINDEX_WRITE_ERROR = 0x06010003
    COMPLETE_ACCESS_NOT_SUPPORTED = 0x06010004
    OBJECT_LENGTH_EXCEEDED = 0x06010005
    OBJECT_MAPPED_TO_RXPDO = 0x06010006
    OBJECT_DOES_NOT_EXIST = 0x06020000
    CANNOT_BE_MAPPED_TO_PDO = 0x06040041
    EXCEEDS_PDO_LENGTH = 0x06040042
    PARAMETER_INCOMPATIBILITY = 0x06040043
    INTERNAL_INCOMPATIBILITY = 0x06040047
    HARDWARE_ACCESS_ERROR = 0x06060000
    DATA_TYPE_MISMATCH = 0x06070010
    DATA_TYPE_TOO_HIGH = 0x06070012
    DATA_TYPE_TOO_LOW = 0x06070013
    SUBINDEX_DOES_NOT_EXIST = 0x06090011
    VALUE_RANGE_EXCEEDED = 0x06090030
    VALUE_TOO_HIGH = 0x06090031
    VALUE_TOO_LOW = 0x06090032
    # 配置的模块列表与检测到的模块列表不匹配
    MODULE_IDENT_LIST_MISMATCH = 0x06090033
    MAX_LESS_THAN_MIN = 0x06090036
    GENERAL_ERROR = 0x08000000
    DATA_TRANSFER_ERROR = 0x08000020
    LOCAL_CONTROL_ERROR = 0x08000021
    DEVICE_STATE_ERROR = 0x08000022
    DICTIONARY_ERROR = 0x08000023
    UNKNOWN_ERROR = 0xFFFFFFFF

    def describe(self) -> str:
        """获取中文描述"""
        _desc = {
            0x00000000: "无错误",
            0x05030000: "Toggle位未改变",
            0x05040000: "SDO协议超时",
            0x05040001: "无效的命令指定符",
            0x05040005: "内存不足",
            0x06010000: "不支持的访问",
            0x06010001: "读写错误(只写对象)",
            0x06010002: "写只读对象错误",
            0x06010003: "子索引写错误",
            0x06010004: "不支持Complete Access",
            0x06010005: "对象长度超限",
            0x06010006: "对象已映射到RxPDO",
            0x06020000: "对象不存在",
            0x06040041: "无法映射到PDO",
            0x06040042: "超出PDO长度",
            0x06040043: "参数不兼容",
            0x06040047: "内部不兼容",
            0x06060000: "硬件访问错误",
            0x06070010: "数据类型不匹配",
            0x06070012: "数据类型过高",
            0x06070013: "数据类型过低",
            0x06090011: "子索引不存在",
            0x06090030: "值范围超限",
            0x06090031: "值过高",
            0x06090032: "值过低",
            0x06090033: "模块标识列表不匹配",
            0x06090036: "最大值小于最小值",
            0x08000000: "一般错误",
            0x08000020: "数据传输错误",
            0x08000021: "本地控制错误",
            0x08000022: "设备状态错误",
            0x08000023: "字典错误",
            0xFFFFFFFF: "未知错误",
        }
        return _desc.get(self.value, f"未知(0x{self.value:08X})")


# ===================== SoE 错误码 =====================

class SoEError(IntEnum):
    """SoE (Servo over EtherCAT) 错误码"""
    NO_ERROR = 0x0000
    NO_IDN = 0x1001
    INVALID_ACCESS_TO_ELEMENT1 = 0x1009
    NO_NAME = 0x2001
    NAME_TRANSMISSION_TOO_SHORT = 0x2002
    NAME_TRANSMISSION_TOO_LONG = 0x2003
    NAME_CANNOT_BE_CHANGED = 0x2004
    NAME_WRITE_PROTECTED = 0x2005
    ATTRIBUTE_TRANSMISSION_TOO_SHORT = 0x3002
    ATTRIBUTE_TRANSMISSION_TOO_LONG = 0x3003
    ATTRIBUTE_CANNOT_BE_CHANGED = 0x3004
    ATTRIBUTE_WRITE_PROTECTED = 0x3005
    NO_UNITS = 0x4001
    UNIT_TRANSMISSION_TOO_SHORT = 0x4002
    UNIT_TRANSMISSION_TOO_LONG = 0x4003
    UNIT_CANNOT_BE_CHANGED = 0x4004
    UNIT_WRITE_PROTECTED = 0x4005
    NO_MINIMUM_INPUT_VALUE = 0x5001
    MINIMUM_INPUT_VALUE_TRANSMISSION_TOO_SHORT = 0x5002
    MINIMUM_INPUT_VALUE_TRANSMISSION_TOO_LONG = 0x5003
    MINIMUM_INPUT_VALUE_CANNOT_BE_CHANGED = 0x5004
    MINIMUM_INPUT_VALUE_WRITE_PROTECTED = 0x5005
    NO_MAXIMUM_INPUT_VALUE = 0x6001
    MAXIMUM_INPUT_VALUE_TRANSMISSION_TOO_SHORT = 0x6002
    MAXIMUM_INPUT_VALUE_TRANSMISSION_TOO_LONG = 0x6003
    MAXIMUM_INPUT_VALUE_CANNOT_BE_CHANGED = 0x6004
    MAXIMUM_INPUT_VALUE_WRITE_PROTECTED = 0x6005
    NO_OPERATION_DATA = 0x7001
    OPERATION_DATA_TRANSMISSION_TOO_SHORT = 0x7002
    OPERATION_DATA_TRANSMISSION_TOO_LONG = 0x7003
    OPERATION_DATA_CANNOT_BE_CHANGED = 0x7004
    OPERATION_DATA_WRITE_PROTECTED_BY_STATE = 0x7005
    OPERATION_DATA_SMALLER_THAN_MINIMUM = 0x7006
    OPERATION_DATA_GREATER_THAN_MAXIMUM = 0x7007
    INVALID_OPERATION_DATA_CONFIG_IDN_NOT_SUPPORTED = 0x7008
    OPERATION_DATA_WRITE_PROTECTED_BY_PASSWORD = 0x7009
    OPERATION_DATA_CYCLICALLY_WRITE_PROTECTED = 0x700A
    INVALID_INDIRECT_ADDRESSING = 0x700B
    OPERATION_DATA_WRITE_PROTECTED_BY_SETTINGS = 0x700C
    RESERVED_700D = 0x700D
    PROCEDURE_COMMAND_ALREADY_ACTIVE = 0x7010
    PROCEDURE_COMMAND_NOT_INTERRUPTIBLE = 0x7011
    PROCEDURE_COMMAND_NOT_EXECUTABLE_STATE = 0x7012
    PROCEDURE_COMMAND_NOT_EXECUTABLE_INVALID_PARAMETERS = 0x7013
    NO_DATA_STATE = 0x7014
    NO_DEFAULT_VALUE = 0x8001
    DEFAULT_VALUE_TRANSMISSION_TOO_LONG = 0x8002
    DEFAULT_VALUE_TRANSMISSION_TOO_SHORT = 0x8003
    DEFAULT_VALUE_CANNOT_BE_CHANGED = 0x8004
    DEFAULT_VALUE_WRITE_PROTECTED = 0x8005
    # 无效的驱动器编号 / 一般错误 / 无元素被寻址 (同一代码值0x800A)
    INVALID_DRIVE_NUMBER = 0x800A
    GENERAL_ERROR = 0x800B
    NO_ELEMENT_ADDRESSED = 0x800C
    UNKNOWN = 0xFFFF

    def describe(self) -> str:
        """获取中文描述"""
        _desc = {
            0x0000: "无错误",
            0x1001: "无IDN",
            0x1009: "对元素1的无效访问",
            0x2001: "无名称",
            0x2002: "名称传输过短",
            0x2003: "名称传输过长",
            0x2004: "名称不可更改",
            0x2005: "名称写保护",
            0x3002: "属性传输过短",
            0x3003: "属性传输过长",
            0x3004: "属性不可更改",
            0x3005: "属性写保护",
            0x4001: "无单位",
            0x4002: "单位传输过短",
            0x4003: "单位传输过长",
            0x4004: "单位不可更改",
            0x4005: "单位写保护",
            0x5001: "无最小输入值",
            0x5002: "最小输入值传输过短",
            0x5003: "最小输入值传输过长",
            0x5004: "最小输入值不可更改",
            0x5005: "最小输入值写保护",
            0x6001: "无最大输入值",
            0x6002: "最大输入值传输过短",
            0x6003: "最大输入值传输过长",
            0x6004: "最大输入值不可更改",
            0x6005: "最大输入值写保护",
            0x7001: "无操作数据",
            0x7002: "操作数据传输过短",
            0x7003: "操作数据传输过长",
            0x7004: "操作数据不可更改",
            0x7005: "操作数据被状态写保护",
            0x7006: "操作数据小于最小值",
            0x7007: "操作数据大于最大值",
            0x7008: "无效操作数据(配置的IDN不支持)",
            0x7009: "操作数据被密码写保护",
            0x700A: "操作数据被周期性写保护",
            0x700B: "无效的间接寻址",
            0x700C: "操作数据被设置写保护",
            0x700D: "保留",
            0x7010: "过程命令已激活",
            0x7011: "过程命令不可中断",
            0x7012: "过程命令不可执行(状态错误)",
            0x7013: "过程命令不可执行(无效参数)",
            0x7014: "无数据状态",
            0x8001: "无默认值",
            0x8002: "默认值传输过长",
            0x8003: "默认值传输过短",
            0x8004: "默认值不可更改",
            0x8005: "默认值写保护",
            0x800A: "无效的驱动器编号",
            0x800B: "一般错误",
            0x800C: "无元素被寻址",
            0xFFFF: "未知错误",
        }
        return _desc.get(self.value, f"未知(0x{self.value:04X})")


# ===================== FoE 错误码 =====================

class FoEErrorCode(IntEnum):
    """FoE 错误码 (ETG.1000.6 Table 92)"""
    NotDefined       = 0x8000  # 未定义错误
    NotFound         = 0x8001  # 文件未找到
    AccessDenied     = 0x8002  # 访问被拒绝
    DiskFull         = 0x8003  # 磁盘满
    Illegal          = 0x8004  # 非法操作
    PacketNumberWrong = 0x8005  # 数据包编号错误
    AlreadyExists    = 0x8006  # 文件已存在
    NoUser           = 0x8007  # 用户不存在
    BootstrapOnly    = 0x8008  # 仅限Bootstrap模式
    NotBootstrap     = 0x8009  # 非Bootstrap模式
    NoRights         = 0x800A  # 无权限
    ProgramError     = 0x800B  # 程序错误


# ===================== 通信类型 =====================

class EcCommType(IntEnum):
    """通信类型枚举（用于自适应超时）"""
    MAILBOX_TX = 0    # 邮箱发送
    MAILBOX_RX = 1    # 邮箱接收
    SDO_READ = 2      # SDO 读取
    SDO_WRITE = 3     # SDO 写入
    PDO = 4           # PDO 传输
    REGISTER = 5      # 寄存器访问
    EEPROM = 6        # EEPROM 访问
    DC = 7            # DC 同步
    COUNT = 8         # 枚举值数量


# ===================== 端口与拓扑 =====================

class EcPortType(IntEnum):
    """物理端口类型 (ESC Port Physical Type)"""
    NOT_USED = 0   # 未使用/未连接
    MII = 1        # MII (Media Independent Interface)
    EBUS = 2       # EBUS (E-Bus)
    EBUS_ENHANCED = 3  # EBUS增强型 (EBUS+)

    def describe(self) -> str:
        """获取中文描述"""
        _desc = {
            0: "未使用",
            1: "MII",
            2: "EBUS",
            3: "EBUS+",
        }
        return _desc.get(self.value, "未知")


class EcTopologyType(IntEnum):
    """从站拓扑类型"""
    NO_LINK = 0    # 无链接
    END_POINT = 1  # 端点 - 只有1个端口活动
    LINE = 2       # 中间节点 - 2个端口活动，线性拓扑
    FORK = 3       # 分支点 - 3个端口活动
    CROSS = 4      # 交叉点 - 4个端口活动

    def describe(self) -> str:
        """获取中文描述"""
        _desc = {
            0: "无链接 (No Link)",
            1: "端点 (End Point)",
            2: "中间节点 (Line)",
            3: "分支点 (Fork)",
            4: "交叉点 (Cross)",
        }
        return _desc.get(self.value, "未知")


# ===================== PDI 类型 =====================

class EcPdiType(IntEnum):
    """PDI (Process Data Interface) 类型"""
    NONE = 0x00              # 接口未激活
    DIGITAL_INPUT_4 = 0x01   # 4个数字输入
    DIGITAL_OUTPUT_4 = 0x02  # 4个数字输出
    DIGITAL_IO_2X2 = 0x03   # 2个数字输入 + 2个数字输出
    DIGITAL_IO = 0x04        # 数字I/O
    SPI_SLAVE = 0x05         # SPI从站
    OVERLOAD_OUTPUT = 0x06   # 过载保护输出
    ESC_SYNC_MANAGER = 0x07  # ESC同步管理器
    UC_ASYNC_16 = 0x08       # 微控制器异步16位
    UC_ASYNC_8 = 0x09        # 微控制器异步8位
    UC_SYNC_16 = 0x0A        # 微控制器同步16位
    UC_SYNC_8 = 0x0B         # 微控制器同步8位
    DIGITAL_IO_32 = 0x10     # 32个数字输入/输出
    DIGITAL_IO_24X8 = 0x11   # 24个数字输入 + 8个数字输出
    DIGITAL_IO_16X16 = 0x12  # 16个数字输入 + 16个数字输出
    DIGITAL_IO_8X24 = 0x13   # 8个数字输入 + 24个数字输出
    ON_CHIP_BUS = 0x80       # On-chip bus (如 Xilinx LocalLink)
    UNKNOWN = 0xFF           # 未知类型

    def describe(self) -> str:
        """获取中文描述"""
        _desc = {
            0x00: "无PDI (接口未激活)",
            0x01: "4个数字输入",
            0x02: "4个数字输出",
            0x03: "2个数字输入 + 2个数字输出",
            0x04: "数字I/O",
            0x05: "SPI从站",
            0x06: "过载保护输出",
            0x07: "ESC同步管理器",
            0x08: "uC async. 16bit",
            0x09: "uC async. 8bit",
            0x0A: "uC sync. 16bit",
            0x0B: "uC sync. 8bit",
            0x10: "32个数字输入/输出",
            0x11: "24个数字输入 + 8个数字输出",
            0x12: "16个数字输入 + 16个数字输出",
            0x13: "8个数字输入 + 24个数字输出",
            0x80: "On-chip bus",
            0xFF: "未知类型",
        }
        return _desc.get(self.value, f"未知(0x{self.value:02X})")


# ===================== 设备与同步管理器 =====================

class EcDeviceType(IntEnum):
    """从站设备类型 (Dtype)"""
    UNDEFINED = 0                # 未定义
    STATIC = 1                   # 静态设备(无IO映射，如EK1100耦合器)
    INPUT_NO_MAILBOX = 2         # 输入设备(无邮箱)
    OUTPUT_NO_MAILBOX = 3        # 输出设备(无邮箱)
    INPUT_WITH_MAILBOX = 4       # 输入设备(有邮箱)
    OUTPUT_WITH_MAILBOX = 5      # 输出设备(有邮箱)
    IO_NO_MAILBOX = 6            # 输入输出设备(无邮箱)
    IO_WITH_MAILBOX = 7          # 输入输出设备(有邮箱)

    def describe(self) -> str:
        """获取中文描述"""
        _desc = {
            0: "未定义",
            1: "静态设备(无IO映射)",
            2: "输入设备(无邮箱)",
            3: "输出设备(无邮箱)",
            4: "输入设备(有邮箱)",
            5: "输出设备(有邮箱)",
            6: "输入输出设备(无邮箱)",
            7: "输入输出设备(有邮箱)",
        }
        return _desc.get(self.value, "未知")


class EcSyncManagerType(IntEnum):
    """SyncManager 类型"""
    NOT_USED = 0          # 未使用
    MAILBOX_OUT = 1       # 邮箱输出 (主站->从站)
    MAILBOX_IN = 2        # 邮箱输入 (从站->主站)
    PROCESS_DATA_OUT = 3  # 过程数据输出 (RxPDO, 主站->从站)
    PROCESS_DATA_IN = 4   # 过程数据输入 (TxPDO, 从站->主站)

    def describe(self) -> str:
        """获取中文描述"""
        _desc = {
            0: "未使用",
            1: "邮箱输出",
            2: "邮箱输入",
            3: "过程数据输出",
            4: "过程数据输入",
        }
        return _desc.get(self.value, "未知")


class EcFmmuType(IntEnum):
    """FMMU 类型"""
    NOT_USED = 0             # 未使用
    OUTPUT = 1               # 输出 (逻辑->物理)
    INPUT = 2                # 输入 (物理->逻辑)
    SYNC_MANAGER_STATUS = 3  # 同步管理器状态

    def describe(self) -> str:
        """获取中文描述"""
        _desc = {
            0: "未使用",
            1: "输出",
            2: "输入",
            3: "同步管理器状态",
        }
        return _desc.get(self.value, "未知")


# ===================== 协议详情标志位 =====================

class EcCoEDetails(IntFlag):
    """CoE 详情标志位"""
    NONE = 0x00              # 无
    SDO = 0x01               # 支持SDO
    SDO_INFO = 0x02          # 支持SDO Info
    PDO_ASSIGN = 0x04        # 支持PDO Assign
    PDO_CONFIG = 0x08        # 支持PDO Config
    STARTUP = 0x10           # 支持Startup
    COMPLETE_ACCESS = 0x20   # 支持Complete Access

    def describe(self) -> str:
        """获取中文描述 (多个标志逗号分隔)"""
        if self.value == 0:
            return "无"
        parts = []
        _flags = {
            0x01: "SDO",
            0x02: "SDO Info",
            0x04: "PDO Assign",
            0x08: "PDO Config",
            0x10: "Startup",
            0x20: "Complete Access",
        }
        for val, name in _flags.items():
            if self.value & val:
                parts.append(name)
        return ", ".join(parts)


class EcEoEDetails(IntFlag):
    """EoE 详情标志位"""
    NONE = 0x00         # 无
    SEND_FRAME = 0x01   # 支持发送帧
    RECEIVE_FRAME = 0x02  # 支持接收帧
    SET_IP_PARAM = 0x04 # 支持设置IP参数
    GET_IP_PARAM = 0x08 # 支持获取IP参数

    def describe(self) -> str:
        """获取中文描述 (多个标志逗号分隔)"""
        if self.value == 0:
            return "无"
        parts = []
        _flags = {
            0x01: "发送帧",
            0x02: "接收帧",
            0x04: "设置IP",
            0x08: "获取IP",
        }
        for val, name in _flags.items():
            if self.value & val:
                parts.append(name)
        return ", ".join(parts)


# ===================== DC 同步模式 =====================

class DcSyncMode(IntEnum):
    """DC 同步模式"""
    FREE_RUN = 0       # 自由运行
    SM_SYNCHRON = 1    # SM 同步
    DC_SYNCHRON = 2    # DC 同步


# ===================== 启动参数 =====================

class StartupTransition(IntEnum):
    """启动过渡阶段 (对应 C# StartupTransition, C EC_TRANS_*)"""
    IP = 0    # Init -> PreOp  (C: EC_TRANS_IP=0)
    PS = 1    # PreOp -> SafeOp  (C: EC_TRANS_PS=1)
    SO = 2    # SafeOp -> OP  (C: EC_TRANS_SO=2)
    OS = 3    # OP -> SafeOp  (C: EC_TRANS_OS=3)
    SP = 4    # SafeOp -> PreOp  (C: EC_TRANS_SP=4)
    PI = 5    # PreOp -> Init  (C: EC_TRANS_PI=5)


class StartupWriteTiming(IntEnum):
    """启动写入时机"""
    BEFORE_TRANSITION = 0  # 状态转换前
    AFTER_TRANSITION = 1   # 状态转换后


# ===================== CoE 对象访问权限 =====================

class CoEObjectAccess(IntFlag):
    """
    CoE 对象访问权限标志位 (ETG1000.6 Object Access)
    用于描述对象字典条目在各 EtherCAT 状态下的读写权限
    """
    NONE = 0x00           # 无权限
    READ_PREOP = 0x01     # Bit 0: Pre-Operational 状态下的读访问
    READ_SAFEOP = 0x02    # Bit 1: Safe-Operational 状态下的读访问
    READ_OP = 0x04        # Bit 2: Operational 状态下的读访问
    WRITE_PREOP = 0x08    # Bit 3: Pre-Operational 状态下的写访问
    WRITE_SAFEOP = 0x10   # Bit 4: Safe-Operational 状态下的写访问
    WRITE_OP = 0x20       # Bit 5: Operational 状态下的写访问
    # 组合值
    READ_ANY = READ_PREOP | READ_SAFEOP | READ_OP       # 所有读权限
    WRITE_ANY = WRITE_PREOP | WRITE_SAFEOP | WRITE_OP    # 所有写权限
    READ_WRITE_ALL = READ_ANY | WRITE_ANY                 # 所有状态下均可读写


# ===================== ESM 超时常量 =====================

class EsmTimeouts:
    """
    ETG.1020 ESM 状态转换超时配置 (毫秒)
    根据 ETG.1020 规范定义的默认超时值
    """
    # Init -> PreOp 默认超时 (ms) - ETG.1020 建议 3000ms
    INIT_TO_PREOP = 3000
    # PreOp -> SafeOp 默认超时 (ms) - ETG.1020 建议 10000ms
    PREOP_TO_SAFEOP = 10000
    # SafeOp -> OP 默认超时 (ms) - ETG.1020 建议 3000ms
    SAFEOP_TO_OP = 3000
    # OP -> SafeOp 默认超时 (ms) - ETG.1020 建议 200ms
    OP_TO_SAFEOP = 200
    # SafeOp -> PreOp 默认超时 (ms) - ETG.1020 建议 200ms
    SAFEOP_TO_PREOP = 200
    # PreOp -> Init 默认超时 (ms) - ETG.1020 建议 200ms
    PREOP_TO_INIT = 200
    # 任意状态 -> Boot 默认超时 (ms)
    TO_BOOT = 3000
    # Boot -> Init 默认超时 (ms)
    BOOT_TO_INIT = 3000
    # SDO 通信超时 (ms)
    SDO_TIMEOUT = 3000
    # 邮箱通信超时 (ms)
    MAILBOX_TIMEOUT = 5000
    # 状态切换后稳定等待时间 (ms)
    STATE_STABILIZE_DELAY = 100

    @staticmethod
    def get_transition_timeout(current_state: int, target_state: int) -> int:
        """
        根据当前状态和目标状态获取超时值

        参数:
            current_state: 当前 EcState 值
            target_state: 目标 EcState 值

        返回:
            超时值 (毫秒)
        """
        # 导入 EcState 避免循环依赖 (使用值比较)
        _map = {
            (0x01, 0x02): EsmTimeouts.INIT_TO_PREOP,
            (0x02, 0x04): EsmTimeouts.PREOP_TO_SAFEOP,
            (0x04, 0x08): EsmTimeouts.SAFEOP_TO_OP,
            (0x08, 0x04): EsmTimeouts.OP_TO_SAFEOP,
            (0x04, 0x02): EsmTimeouts.SAFEOP_TO_PREOP,
            (0x02, 0x01): EsmTimeouts.PREOP_TO_INIT,
            (0x03, 0x01): EsmTimeouts.BOOT_TO_INIT,
        }
        result = _map.get((current_state, target_state))
        if result is not None:
            return result
        # 目标是 Boot
        if target_state == 0x03:
            return EsmTimeouts.TO_BOOT
        # 默认超时
        return 3000


# ===================== 数据类 =====================

# ===================== EcState 格式化工具 =====================

class EcStateFormat:
    """
    EcState 格式化工具: 正确解析复合状态 (基础状态 + Error/Ack 标志位 0x10)
    对应 C# EcStateFormat 静态类
    """

    @staticmethod
    def format(state: int) -> str:
        """
        格式化 EcState 为可读字符串, 支持复合状态如 0x14 = SafeOp+Error

        参数:
            state: 状态值

        返回:
            格式化字符串
        """
        has_error = bool(state & 0x10)
        base_state = state & 0x0F
        _names = {
            0x00: "None",
            0x01: "Init",
            0x02: "PreOp",
            0x03: "Boot",
            0x04: "SafeOp",
            0x08: "OP",
        }
        base_name = _names.get(base_state, f"0x{base_state:02X}")
        return f"{base_name}+Error" if has_error else base_name

    @staticmethod
    def get_base_state(state: int) -> int:
        """
        获取基础状态 (低4位, 不含 Error/Ack 标志)

        参数:
            state: 状态值

        返回:
            基础状态值
        """
        return state & 0x0F

    @staticmethod
    def has_error(state: int) -> bool:
        """
        检查是否包含 Error 标志 (0x10)

        参数:
            state: 状态值

        返回:
            是否包含错误标志
        """
        return bool(state & 0x10)


@dataclass
class SlaveErrorCounters:
    """从站级错误统计 (ETG.1020, 寄存器 0x0300-0x0307)"""
    slave_index: int = 0         # 从站编号
    port0_crc_errors: int = 0    # 端口 0 CRC 错误 (寄存器 0x0300)
    port1_crc_errors: int = 0    # 端口 1 CRC 错误 (寄存器 0x0302)
    port2_crc_errors: int = 0    # 端口 2 CRC 错误 (寄存器 0x0304)
    port3_crc_errors: int = 0    # 端口 3 CRC 错误 (寄存器 0x0306)
    frame_errors: int = 0        # 帧错误计数
    lost_frames: int = 0         # 丢帧计数

    @property
    def total_crc_errors(self) -> int:
        """所有端口 CRC 错误总和"""
        return (self.port0_crc_errors + self.port1_crc_errors
                + self.port2_crc_errors + self.port3_crc_errors)

    def __str__(self) -> str:
        return (f"从站{self.slave_index}: CRC=[{self.port0_crc_errors},"
                f"{self.port1_crc_errors},{self.port2_crc_errors},"
                f"{self.port3_crc_errors}] 帧错误={self.frame_errors}"
                f" 丢帧={self.lost_frames}")


class StateCiA402(IntEnum):
    """CiA 402 驱动器状态机状态"""
    NOT_READY_TO_SWITCH_ON = 0   # 初始化中
    SWITCH_ON_DISABLED = 1       # 驱动禁用
    READY_TO_SWITCH_ON = 2       # 准备就绪
    SWITCHED_ON = 3              # 已开启
    OPERATION_ENABLED = 4        # 运行使能
    QUICK_STOP_ACTIVE = 5        # 快速停止
    FAULT_REACTION_ACTIVE = 6    # 故障反应中
    FAULT = 7                    # 故障
    UNKNOWN = 99                 # 未知状态


class ModeCiA402(IntEnum):
    """CiA 402 操作模式"""
    PP = 1       # 轮廓位置模式 (Profile Position)
    VL = 2       # 速度模式 (Velocity)
    PV = 3       # 轮廓速度模式 (Profile Velocity)
    PT = 4       # 轮廓转矩模式 (Profile Torque)
    HM = 6       # 回零模式 (Homing)
    IP = 7       # 插补位置模式 (Interpolated Position)
    CSP = 8      # 周期同步位置模式
    CSV = 9      # 周期同步速度模式
    CST = 10     # 周期同步转矩模式
    CSTCA = 11   # 周期同步转矩加速度模式


class LogCategory(IntEnum):
    """日志类别 - 与DLL中的LogCategory对应"""
    ERROR = 0      # 错误 - 系统错误和异常
    WARNING = 1    # 警告 - 潜在问题
    MESSAGE = 2    # 消息 - 一般信息
    MAILBOX = 3    # Mailbox - CoE/SoE/FoE/EoE通信
    PDO = 4        # PDO - 过程数据对象交换
    DEBUG = 5      # 调试 - 详细调试信息
    LOCAL = 6      # 本地 - 控制台输出捕获


class LicenseStatus(IntEnum):
    """授权状态"""
    NOT_VERIFIED = 0        # 未验证
    VERIFYING = 1           # 验证中
    VERIFIED = 2            # 已验证
    FAILED = 3              # 验证失败
    EXPIRED = 4             # 已过期
    MACHINE_ID_MISMATCH = 5 # 机器ID不匹配


@dataclass
class DiagnosticMessage:
    """ETG.1510 诊断消息"""
    sub_index: int = 0          # 子索引
    diag_code: int = 0          # 诊断代码
    flags: int = 0              # 标志位
    text_index: int = 0         # 文本索引
    raw_data: bytes = b''       # 原始数据

    def __str__(self) -> str:
        return f"Diag[{self.sub_index}]: Code=0x{self.diag_code:08X}, Flags=0x{self.flags:04X}"
