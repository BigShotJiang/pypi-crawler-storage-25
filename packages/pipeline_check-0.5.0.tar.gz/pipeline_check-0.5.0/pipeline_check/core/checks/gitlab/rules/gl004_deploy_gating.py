"""GL-004, deploy jobs must be gated by manual approval or environment."""
from __future__ import annotations

import re
from typing import Any

from ...base import Finding, Severity
from ...rule import Rule
from ..base import iter_jobs, job_scripts
from ._helpers import DEPLOY_RE, rules_manual

_DEPLOY_CMD_RE = re.compile(
    r"(?:kubectl\s+(?:apply|create|set\s+image|rollout\s+restart)"
    r"|terraform\s+(?:apply|destroy)"
    r"|aws\s+(?:s3\s+(?:cp|sync)|cloudformation\s+deploy|ecs\s+update-service)"
    r"|docker\s+push"
    r"|helm\s+(?:upgrade|install)"
    r"|gcloud\s+(?:app\s+deploy|run\s+deploy|functions\s+deploy)"
    r"|ansible-playbook"
    r"|serverless\s+deploy"
    r"|az\s+(?:webapp\s+deploy|functionapp\s+deploy|containerapp\s+update))",
    re.IGNORECASE,
)

RULE = Rule(
    id="GL-004",
    title="Deploy job lacks manual approval or environment gate",
    severity=Severity.MEDIUM,
    owasp=("CICD-SEC-1",),
    esf=("ESF-C-APPROVAL", "ESF-C-ENV-SEP"),
    cwe=("CWE-284",),
    recommendation=(
        "Add `when: manual` (optionally with `rules:` for protected "
        "branches) or bind the job to an `environment:` with a "
        "deployment tier so approvals and audit are enforced by "
        "GitLab's environment controls."
    ),
    docs_note=(
        "A job whose stage or name contains `deploy` / `release` / "
        "`publish` / `promote` should either require manual approval "
        "or declare an `environment:` binding. Otherwise any push to "
        "the trigger branch ships to the target."
    ),
)


def check(path: str, doc: dict[str, Any]) -> Finding:
    ungated: list[str] = []
    for name, job in iter_jobs(doc):
        stage = job.get("stage")
        # Cast each ``DEPLOY_RE.search(...)`` to bool so the variable's
        # inferred type stays ``bool`` across both assignments. mypy
        # otherwise widens to ``Match[str] | None | bool``, which then
        # fails the second assignment.
        is_deploy: bool = bool(
            (isinstance(stage, str) and DEPLOY_RE.search(stage))
            or DEPLOY_RE.search(name)
        )
        if not is_deploy:
            # Also check for deploy-like commands in scripts.
            is_deploy = any(
                _DEPLOY_CMD_RE.search(line) for line in job_scripts(job)
            )
        if not is_deploy:
            continue
        manual = job.get("when") == "manual" or rules_manual(job.get("rules"))
        has_env = bool(job.get("environment"))
        if not (manual or has_env):
            ungated.append(name)
    passed = not ungated
    desc = (
        "All deploy-like jobs are gated by manual approval or environment."
        if passed else
        f"{len(ungated)} deploy job(s) run automatically without a manual "
        f"gate or `environment:` binding: {', '.join(ungated)}. Any push "
        f"to the trigger branch will ship to the target."
    )
    return Finding(
        check_id=RULE.id, title=RULE.title, severity=RULE.severity,
        resource=path, description=desc,
        recommendation=RULE.recommendation, passed=passed,
    )
