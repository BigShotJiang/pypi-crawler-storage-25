"""CLI entry point.

Usage
-----
    pipeline_check [OPTIONS]
    pipeline_check init [--path PATH] [--force]

Examples
--------
    # Auto-detect the provider from cwd (default).
    pipeline_check

    # Scaffold a starter config file pre-filled from cwd.
    pipeline_check init

    # Short flags work for the most-typed options.
    pipeline_check -p github -o json -c GHA-001 -f HIGH

    # Scan a live AWS account.
    pipeline_check --pipeline aws --region eu-west-1 --output both --severity-threshold HIGH

    # Run specific checks only.
    pipeline_check --pipeline aws --checks CB-001 --checks CB-003

    # Scan a Terraform plan, no AWS credentials needed.
    pipeline_check --pipeline terraform --tf-plan plan.json

    # Annotate findings with a single standard, or list registered standards.
    pipeline_check --standard owasp_cicd_top_10
    pipeline_check --list-standards

    # Print version and exit.
    pipeline_check --version

Exit codes
----------
    0   Gate passed
    1   Gate failed (default gate: any CRITICAL finding in the effective set)
    2   Scanner failure (e.g. AWS API error)

Provider-path flags (``--tf-plan``, ``--gha-path``, ``--gitlab-path``,
``--bitbucket-path``) are validated eagerly; the latter three also
auto-detect their canonical file at cwd when omitted. Missing flag plus
missing canonical file raises a ``UsageError``.
"""
import os
import re
import sys
from typing import Any

import click

from . import __version__
from .core import autofix as _autofix
from .core import providers as _providers
from .core import standards as _standards
from .core.checks.base import Confidence, Severity, confidence_rank
from .core.config import load_config
from .core.gate import GateConfig, evaluate_gate, load_ignore_file
from .core.html_reporter import report_html
from .core.junit_reporter import report_junit
from .core.markdown_reporter import report_markdown
from .core.reporter import (
    report_chains_terminal,
    report_inventory_terminal,
    report_json,
    report_terminal,
)
from .core.sarif_reporter import report_sarif
from .core.scanner import MultiScanner, Scanner
from .core.scorer import score
from .core.threatmodel_reporter import report_threatmodel


def _tolerate_unencodable_stdio() -> None:
    """Make stdout/stderr tolerate non-ASCII characters on legacy consoles.

    Windows' default ``cmd.exe`` uses cp1252 for stdout. When click or
    our own code emits help text containing characters cp1252 can't
    encode (box-drawing, arrow, >=), Python raises
    ``UnicodeEncodeError`` and the program dies before printing
    anything useful. Reconfiguring the streams with
    ``errors='replace'`` degrades un-encodable characters to ``?``
    instead of crashing. We leave the *encoding* alone so output still
    matches the terminal's expectations - only the error handler changes.

    Runs at import time so it takes effect before click's argument-
    parsing emits help text on --help.
    """
    for stream in (sys.stdout, sys.stderr):
        # ``reconfigure`` is only present on ``io.TextIOWrapper``, which
        # is the type sys.stdout/stderr carry when not redirected.
        # When they're redirected (a pipe, a captured fixture in tests)
        # they may be a plain TextIO without ``reconfigure``, caught
        # by the AttributeError below.
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            reconfigure(errors="replace")
        except OSError:
            # Stream rejects the reconfigure (e.g. detached). Non-fatal:
            # the worst case is the original crash on cp1252, which only
            # affects Windows default console.
            pass


_tolerate_unencodable_stdio()


class _GroupedCommand(click.Command):
    """Click command that renders ``--help`` options under named sections.

    Keeps option declarations unchanged, the section→flag mapping lives
    here so adding an option only forces a mapping edit when the author
    wants it in a specific section. Unmapped options fall into
    ``Other`` so nothing silently vanishes from help.
    """

    _SECTIONS: tuple[tuple[str, frozenset[str]], ...] = (
        ("Target", frozenset({
            "--pipeline", "--target", "--region", "--profile",
            "--tf-plan", "--gha-path", "--gitlab-path",
            "--bitbucket-path", "--azure-path", "--jenkinsfile-path",
            "--circleci-path", "--cfn-template", "--cloudbuild-path",
            "--dockerfile-path", "--k8s-path", "--helm-path",
            "--buildkite-path", "--tekton-path", "--argo-path",
            "--helm-values", "--helm-set", "--oci-manifest",
            "--drone-path",
        })),
        ("Filtering", frozenset({
            "--checks", "--severity-threshold", "--min-confidence",
            "--secret-pattern", "--detect-entropy", "--custom-rules",
        })),
        ("Output", frozenset({
            "--output", "--output-file", "--standard",
            "--inventory", "--inventory-type", "--inventory-only",
        })),
        ("Gate", frozenset({
            "--fail-on", "--min-grade", "--max-failures",
            "--fail-on-check", "--baseline", "--baseline-from-git",
            "--diff-base", "--ignore-file",
            "--fail-on-chain", "--fail-on-any-chain",
        })),
        ("Attack chains", frozenset({
            "--no-chains", "--list-chains", "--explain-chain",
        })),
        ("Autofix", frozenset({"--fix", "--apply"})),
        ("Info & Help", frozenset({
            "--list-checks", "--list-standards", "--standard-report",
            "--explain", "--man", "--config-check",
            "--install-completion", "--config", "--version",
            "--help", "--verbose", "--quiet",
        })),
        ("AI augmentation (opt-in)", frozenset({
            "--ai-explain", "--ai-model", "--ai-context-file",
        })),
    )

    def format_options(
        self, ctx: click.Context, formatter: click.HelpFormatter,
    ) -> None:
        bucketed: dict[str, list[tuple[str, str]]] = {}
        section_order = [name for name, _ in self._SECTIONS] + ["Other"]
        for param in self.get_params(ctx):
            record = param.get_help_record(ctx)
            if record is None:
                continue
            opts = list(getattr(param, "opts", []))
            opts.extend(getattr(param, "secondary_opts", []))
            section = "Other"
            for name, flags in self._SECTIONS:
                if any(o in flags for o in opts):
                    section = name
                    break
            bucketed.setdefault(section, []).append(record)
        for name in section_order:
            rows = bucketed.get(name)
            if not rows:
                continue
            with formatter.section(name):
                formatter.write_dl(rows)


class _FuzzyChoice(click.Choice[str]):
    """Click Choice that appends 'Did you mean: X?' on a bad value.

    Mirrors the suggestion style used by ``--explain`` for unknown check
    IDs (see ``core/explain.py``). Case-insensitive match is up to the
    base class via ``case_sensitive=False``.
    """

    def convert(
        self,
        value: Any,
        param: click.Parameter | None,
        ctx: click.Context | None,
    ) -> Any:
        try:
            return super().convert(value, param, ctx)
        except click.exceptions.BadParameter:
            import difflib
            suggestions = difflib.get_close_matches(
                str(value).lower(),
                [c.lower() for c in self.choices],
                n=3,
            )
            hint = (
                f" Did you mean: {', '.join(suggestions)}?"
                if suggestions else ""
            )
            self.fail(
                f"{value!r} is not one of {', '.join(self.choices)}.{hint}",
                param,
                ctx,
            )


# ────────────────────────────────────────────────────────────────────────────
# Shell completion helpers
# ────────────────────────────────────────────────────────────────────────────


def _completion_debug(source: str, exc: BaseException) -> None:
    """Log a completion-helper exception to stderr when ``$PIPELINE_CHECK_DEBUG``
    is truthy.

    Tab-completion runs in the user's interactive shell, where stderr
    output during a Tab press is invisible (the shell renders the
    candidate list, not stderr). Silent ``except`` is therefore the
    only reasonable production behavior: a broken helper must not eat
    the keypress with a traceback. But debugging "why does my Tab
    show no candidates" requires *some* breadcrumb, so we honor an
    opt-in env var. Default off to keep the live path quiet.
    """
    if os.environ.get("PIPELINE_CHECK_DEBUG"):
        click.echo(
            f"[completion] {source}: {type(exc).__name__}: {exc}",
            err=True,
        )


def _complete_check_ids(
    ctx: click.Context, param: click.Parameter, incomplete: str,
) -> list[Any]:
    """Tab-complete check IDs (GHA-001, GL-002, CB-001, etc.)."""
    from click.shell_completion import CompletionItem
    try:
        ids = _all_check_ids()
    except Exception as exc:
        _completion_debug("check-ids", exc)
        return []
    return [
        CompletionItem(cid)
        for cid in ids
        if cid.lower().startswith(incomplete.lower())
    ]


def _complete_standards(
    ctx: click.Context, param: click.Parameter, incomplete: str,
) -> list[Any]:
    """Tab-complete standard names."""
    from click.shell_completion import CompletionItem
    try:
        names = _standards.available()
    except Exception as exc:
        _completion_debug("standards", exc)
        return []
    return [
        CompletionItem(n)
        for n in names
        if n.lower().startswith(incomplete.lower())
    ]


def _complete_man_topics(
    ctx: click.Context, param: click.Parameter, incomplete: str,
) -> list[Any]:
    """Tab-complete --man topic names."""
    from click.shell_completion import CompletionItem
    try:
        from .core.manual import topics
        names = topics()
    except Exception as exc:
        _completion_debug("man-topics", exc)
        return []
    return [
        CompletionItem(t)
        for t in names
        if t.lower().startswith(incomplete.lower())
    ]


def _list_checks_for_pipeline(pipeline: str) -> None:
    """Render every available check for *pipeline* as ``ID  SEV  TITLE``.

    Rule-based providers (all workflow providers + ``aws/rules/`` +
    ``cloudformation/*`` + ``terraform/*``) expose ``Rule`` metadata via
    ``discover_rules``. Class-based modules (AWS core services,
    Terraform core services) have the same info in their module
    docstring header. We parse it so the output is uniform.
    """
    rows: list[tuple[str, str, str]] = []
    # Rule-based packages are derived from the filesystem so a new
    # provider under ``pipeline_check/core/checks/<name>/rules/``
    # is auto-listed without a CLI edit. Same source-of-truth
    # pattern as ``_all_check_ids`` and the custom-rule loader's
    # built-in-ID collision check.
    from pathlib import Path as _Path
    _checks_root = _Path(__file__).parent / "core" / "checks"
    _provider_rule_dir = _checks_root / pipeline / "rules"
    rule_packages: dict[str, list[str]] = {}
    if _provider_rule_dir.is_dir():
        rule_packages[pipeline] = [
            f"pipeline_check.core.checks.{pipeline}.rules"
        ]
    from .core.checks.rule import discover_rules
    for pkg in rule_packages.get(pipeline, []):
        try:
            for rule, _ in discover_rules(pkg):
                rows.append((rule.id, rule.severity.value, rule.title))
        except Exception as exc:  # pragma: no cover - defensive
            click.echo(f"[warn] could not load {pkg}: {exc}", err=True)

    # Class-based modules, parse the docstring header. CloudFormation
    # modules don't carry the table header (their docstrings point at
    # Terraform's mirror); scan Terraform's source as a fallback so
    # ``--pipeline cloudformation --list-checks`` produces the same
    # IDs/severities a CFN scan would.
    import importlib
    import pkgutil
    _class_packages = {
        "aws": ["pipeline_check.core.checks.aws"],
        "terraform": ["pipeline_check.core.checks.terraform"],
        "cloudformation": [
            "pipeline_check.core.checks.terraform",
            "pipeline_check.core.checks.cloudformation",
        ],
    }
    class_pkg_names = _class_packages.get(pipeline) or []
    if class_pkg_names:
        _row_re = re.compile(
            r"^\s*(?P<id>[A-Z]+-\d+)\s{2,}(?P<title>.+?)\s{2,}"
            r"(?P<sev>CRITICAL|HIGH|MEDIUM|LOW|INFO)\b",
            re.MULTILINE,
        )
        for class_pkg_name in class_pkg_names:
            try:
                # ``class_pkg_module`` is distinct from the ``pkg`` loop
                # variables earlier and later in this function (which are
                # strings) so mypy doesn't carry a stale ``str`` inference.
                class_pkg_module = importlib.import_module(class_pkg_name)
                for info in pkgutil.iter_modules(class_pkg_module.__path__):
                    if info.name.startswith("_") or info.name == "rules":
                        continue
                    mod = importlib.import_module(f"{class_pkg_name}.{info.name}")
                    doc = mod.__doc__ or ""
                    for m in _row_re.finditer(doc):
                        rows.append((m["id"], m["sev"], m["title"].strip()))
            except Exception as exc:  # pragma: no cover - defensive
                click.echo(f"[warn] could not scan {class_pkg_name}: {exc}", err=True)

    if not rows:
        click.echo(
            f"[list-checks] no checks registered for --pipeline {pipeline}.",
            err=True,
        )
        sys.exit(3)

    # Deduplicate (rule-based + class-based overlap on IDs like CB-001)
    # and sort so ``GHA-001`` < ``GHA-010`` reads naturally.
    dedup: dict[str, tuple[str, str, str]] = {}
    for row in rows:
        dedup.setdefault(row[0], row)
    id_width = max(len(i) for i in dedup) if dedup else 0
    sev_width = max(len(r[1]) for r in dedup.values()) if dedup else 0
    for cid in sorted(dedup):
        _, sev, title = dedup[cid]
        click.echo(f"{cid:<{id_width}}  {sev:<{sev_width}}  {title}")


def _resolve_provider_path(
    provider_lc: str,
    *,
    flag: str,
    value: str | None,
    candidates: tuple[str, ...] = (),
    candidate_kind: str = "file",
    validate_kind: str = "exists",
    detect_label: str = "",
    not_found_label: str = "",
) -> str:
    """Auto-detect, validate, and return a per-provider input path.

    Replaces the per-provider elif ladder that ``main()`` used to
    carry. Cloudformation and helm have edge cases (template-folder
    detection, ``--helm-values`` validation) so they stay inline;
    every other provider's contract is exactly:

      1. If the user didn't pass ``--<flag>``, walk *candidates*
         and pick the first one that exists. ``candidate_kind`` is
         ``file`` for canonical files (``.gitlab-ci.yml``) or
         ``dir`` for canonical directories (``.github/workflows``).
      2. If still empty, raise ``UsageError`` with a hint that names
         the canonical files we looked for (*detect_label*).
      3. Validate that the resolved path exists. ``validate_kind``
         is ``exists`` (default; file or dir), ``file``, or ``dir``.
         ``not_found_label`` ("directory" / "path") inserts a noun
         into the error message when the validation kind is stricter
         than ``exists``.
    """
    if not value:
        check = os.path.isdir if candidate_kind == "dir" else os.path.isfile
        for cand in candidates:
            if check(cand):
                value = cand
                click.echo(f"[auto] using --{flag} {value}", err=True)
                break
    if not value:
        suffix = (
            f" (no {detect_label} found in the current directory)."
            if detect_label else "."
        )
        raise click.UsageError(
            f"--{flag} PATH is required when --pipeline {provider_lc}{suffix}"
        )
    validators = {
        "exists": os.path.exists,
        "file": os.path.isfile,
        "dir": os.path.isdir,
    }
    if not validators[validate_kind](value):
        kind_word = (not_found_label + " ") if not_found_label else ""
        raise click.UsageError(
            f"--{flag} {kind_word}not found: {value}"
        )
    return value


def _detect_pipeline_from_cwd() -> str | None:
    """Return the best-guess pipeline name based on files present at cwd.

    First match wins. Returns None when nothing recognizable is found;
    the caller then falls back to ``aws`` (preserves prior default).
    """
    if os.path.isdir(".github/workflows"):
        return "github"
    if os.path.isfile(".gitlab-ci.yml"):
        return "gitlab"
    if os.path.isfile(".circleci/config.yml"):
        return "circleci"
    if os.path.isfile("Jenkinsfile"):
        return "jenkins"
    if os.path.isfile("azure-pipelines.yml"):
        return "azure"
    if os.path.isfile("bitbucket-pipelines.yml"):
        return "bitbucket"
    if os.path.isfile("cloudbuild.yaml") or os.path.isfile("cloudbuild.yml"):
        return "cloudbuild"
    if (
        os.path.isfile(".buildkite/pipeline.yml")
        or os.path.isfile(".buildkite/pipeline.yaml")
    ):
        return "buildkite"
    if os.path.isfile(".drone.yml") or os.path.isfile(".drone.yaml"):
        return "drone"
    if os.path.isfile("Dockerfile") or os.path.isfile("Containerfile"):
        return "dockerfile"
    for _cfn in (
        "template.yml", "template.yaml", "template.json",
        "cloudformation.yml", "cloudformation.yaml",
        "cfn.yml", "cfn.yaml",
    ):
        if os.path.isfile(_cfn):
            return "cloudformation"
    # Helm is detected before kubernetes because a Chart.yaml at the
    # repo root is an unambiguous signal, whereas k8s falls back to
    # generic directory names that helm charts often use too.
    if os.path.isfile("Chart.yaml"):
        return "helm"
    # Kubernetes is detected last because its indicators are
    # generic directory names that other providers might use too.
    for _k8s in ("kubernetes", "k8s", "manifests"):
        if os.path.isdir(_k8s):
            return "kubernetes"
    return None


_CHECK_IDS_CACHE: list[str] | None = None


def _all_check_ids() -> list[str]:
    """Collect every check ID from every provider's rules registry.

    Cached after the first call so repeated completions are fast.
    CI providers use the ``Rule`` registry; AWS and Terraform check
    IDs are extracted from source via regex since they use class-based
    checks without a ``Rule`` dataclass.
    """
    global _CHECK_IDS_CACHE
    if _CHECK_IDS_CACHE is not None:
        return _CHECK_IDS_CACHE
    ids: list[str] = []
    # Rule-based providers, each has a rules/ package with RULE.id.
    # Derive the package list from the filesystem so adding a new
    # provider under ``pipeline_check/core/checks/<name>/rules/``
    # automatically surfaces in ``--list-checks`` / ``--explain`` /
    # autocomplete. Class-based AWS / Terraform IDs are scanned by
    # the regex pass below; ``set`` deduplication catches any overlap.
    from pathlib import Path
    checks_root = Path(__file__).parent / "core" / "checks"
    rule_pkgs = sorted(
        f"pipeline_check.core.checks.{p.parent.parent.name}.rules"
        for p in checks_root.glob("*/rules/__init__.py")
    )
    for pkg in rule_pkgs:
        try:
            from .core.checks.rule import discover_rules
            for rule, _ in discover_rules(pkg):
                ids.append(rule.id)
        except Exception as exc:
            _completion_debug(f"rule-discover {pkg}", exc)
    # AWS / Terraform, class-based checks with hardcoded check_id strings.
    _id_re = re.compile(r'check_id="([A-Z]+-\d+)"')
    for provider_pkg_name in (
        "pipeline_check.core.checks.aws",
        "pipeline_check.core.checks.terraform",
    ):
        try:
            import importlib
            import pkgutil
            # Distinct from the ``pkg`` loop variables earlier (lines
            # 264, 378) which iterate over strings, the inferred
            # ``str`` type would conflict with this Module assignment.
            provider_pkg_module = importlib.import_module(provider_pkg_name)
            for info in pkgutil.iter_modules(provider_pkg_module.__path__):
                mod = importlib.import_module(f"{provider_pkg_name}.{info.name}")
                if mod.__file__:
                    with open(mod.__file__, encoding="utf-8") as fh:
                        ids.extend(_id_re.findall(fh.read()))
        except Exception as exc:
            _completion_debug(f"id-scan {provider_pkg_name}", exc)
    ids = sorted(set(ids))
    _CHECK_IDS_CACHE = ids
    return ids


_SEVERITY_CHOICES = [
    s.value
    for s in (Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO)
]

# Derived from the provider registry, no manual list to maintain.
# Registering a new provider in core/providers/__init__.py automatically
# makes it available here. ``auto`` is a CLI-only sentinel that picks
# a provider by looking at cwd; it is resolved before Scanner runs.
_PIPELINE_CHOICES = ["auto", *_providers.available()]


def _load_config_callback(
    ctx: click.Context, _param: click.Parameter, value: str | None,
) -> str | None:
    """Eager callback, populates ``ctx.default_map`` so every other flag's
    default is pre-filled from the config file + environment.

    Precedence flows naturally from click here: ``default_map`` supplies
    defaults, CLI-provided values override them, and env/file values
    already live inside ``default_map`` with env winning over file (see
    :func:`pipeline_check.core.config.load_config`).
    """
    try:
        ctx.default_map = load_config(explicit_path=value)
    except FileNotFoundError as exc:
        raise click.UsageError(str(exc)) from exc
    return value


def _install_completion_callback(
    ctx: click.Context, _param: click.Parameter, value: str | None,
) -> None:
    """Print instructions or install completion for the given shell."""
    if not value:
        return
    shell = value
    if shell == "bash":
        line = 'eval "$(_PIPELINE_CHECK_COMPLETE=bash_source pipeline_check)"'
        rc = os.path.expanduser("~/.bashrc")
        marker = "# pipeline_check completion"
        try:
            existing = open(rc, encoding="utf-8").read() if os.path.exists(rc) else ""
        except OSError:
            existing = ""
        if marker in existing:
            click.echo(f"Completion already installed in {rc}")
        else:
            with open(rc, "a", encoding="utf-8") as f:
                f.write(f"\n{marker}\n{line}\n")
            click.echo(f"Completion installed in {rc}. Restart your shell or run:")
            click.echo(f"  source {rc}")
    elif shell == "zsh":
        line = 'eval "$(_PIPELINE_CHECK_COMPLETE=zsh_source pipeline_check)"'
        rc = os.path.expanduser("~/.zshrc")
        marker = "# pipeline_check completion"
        try:
            existing = open(rc, encoding="utf-8").read() if os.path.exists(rc) else ""
        except OSError:
            existing = ""
        if marker in existing:
            click.echo(f"Completion already installed in {rc}")
        else:
            with open(rc, "a", encoding="utf-8") as f:
                f.write(f"\n{marker}\n{line}\n")
            click.echo(f"Completion installed in {rc}. Restart your shell or run:")
            click.echo(f"  source {rc}")
    elif shell == "fish":
        comp_dir = os.path.expanduser("~/.config/fish/completions")
        os.makedirs(comp_dir, exist_ok=True)
        comp_file = os.path.join(comp_dir, "pipeline_check.fish")
        # Fish uses a generated script, not an eval.
        env = os.environ.copy()
        env["_PIPELINE_CHECK_COMPLETE"] = "fish_source"
        import subprocess
        result = subprocess.run(
            ["pipeline_check"], env=env,
            capture_output=True, text=True,
        )
        if result.stdout.strip():
            with open(comp_file, "w", encoding="utf-8") as f:
                f.write(result.stdout)
            click.echo(f"Completion installed to {comp_file}")
        else:
            click.echo(
                "Add this to ~/.config/fish/completions/pipeline_check.fish:\n"
                "  _PIPELINE_CHECK_COMPLETE=fish_source pipeline_check | source"
            )
    ctx.exit(0)


@click.command(cls=_GroupedCommand, epilog=(
    "Subcommands:\n"
    "  init    Scaffold a starter .pipeline-check.yml in the current directory."
))
@click.version_option(version=__version__, prog_name="pipeline_check")
@click.option(
    "--install-completion",
    type=click.Choice(["bash", "zsh", "fish"]),
    default=None,
    is_eager=True,
    expose_value=False,
    callback=_install_completion_callback,
    help="Install shell completion for the given shell and exit.",
)
@click.option(
    "--config",
    default=None,
    metavar="PATH",
    is_eager=True,
    expose_value=False,
    callback=_load_config_callback,
    help=(
        "Path to a config file (TOML or YAML). Auto-discovers "
        ".pipeline-check.yml or the [tool.pipeline_check] section of "
        "pyproject.toml at cwd when not specified."
    ),
)
@click.option(
    "--pipeline",
    "-p",
    type=_FuzzyChoice(_PIPELINE_CHOICES, case_sensitive=False),
    default="auto",
    show_default=True,
    help=(
        "Pipeline environment to scan. One of: "
        + ", ".join(_PIPELINE_CHOICES)
        + ". ``auto`` (default) picks a provider by scanning cwd for a "
        "recognized CI file (``.github/workflows``, ``.gitlab-ci.yml``, "
        "``Jenkinsfile``, etc.) and falls back to ``aws`` when nothing "
        "matches. Each provider has a companion path flag "
        "(--tf-plan, --cfn-template, --gha-path, --gitlab-path, "
        "--bitbucket-path, --azure-path, --jenkinsfile-path, "
        "--circleci-path, --cloudbuild-path, --dockerfile-path, "
        "--k8s-path, --helm-path, --buildkite-path, --tekton-path, "
        "--argo-path, --oci-manifest, --drone-path); "
        "AWS scans the live account via boto3. For multi-provider "
        "scans (so cross-provider attack chains like XPC-001 fire) "
        "use ``--pipelines github,oci`` instead."
    ),
)
@click.option(
    "--pipelines",
    "pipelines_csv",
    default="",
    metavar="LIST",
    help=(
        "Comma-separated list of providers to scan in one run "
        "(``--pipelines github,oci``). Mutually exclusive with "
        "``--pipeline``. Each name must be a registered provider "
        "(same vocabulary as ``--pipeline`` minus ``auto``). "
        "Findings from every provider are unified before the chain "
        "engine evaluates, which is what activates cross-provider "
        "attack chains (the ``XPC-NNN`` family). Each provider's "
        "input path is taken from the corresponding flag (``--gha-"
        "path``, ``--oci-manifest``, etc.) and auto-detection runs "
        "the same way it does for the single-provider flow."
    ),
)
@click.option(
    "--target",
    default=None,
    metavar="NAME",
    help=(
        "Scope the scan to a specific resource (e.g. a CodePipeline pipeline name).  "
        "Omit to scan the entire region."
    ),
)
@click.option(
    "--checks",
    "-c",
    multiple=True,
    metavar="CHECK_ID",
    shell_complete=_complete_check_ids,
    help=(
        "Run only the specified check ID(s).  Repeat to include multiple "
        "(e.g. --checks CB-001 --checks CB-003).  Omit to run all checks."
    ),
)
@click.option(
    "--region",
    "-r",
    default="us-east-1",
    show_default=True,
    help="Region to scan (AWS only).",
)
@click.option(
    "--profile",
    default=None,
    help="AWS CLI named profile (AWS only; defaults to the environment default).",
)
@click.option(
    "--tf-plan",
    default=None,
    metavar="PATH",
    help=(
        "Path to the JSON output of `terraform show -json` "
        "(Terraform provider only; required when --pipeline terraform)."
    ),
)
@click.option(
    "--gha-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to the GitHub Actions workflows directory, typically "
        "`.github/workflows` (required when --pipeline github)."
    ),
)
@click.option(
    "--resolve-remote/--no-resolve-remote",
    "resolve_remote",
    default=False,
    show_default=True,
    help=(
        "Follow ``jobs.<id>.uses: owner/repo/.github/workflows/x.yml@<sha>`` "
        "to the called workflow body and run the GHA rule pack against "
        "it with the caller's permissions context. Default off, the "
        "scanner stays read-from-disk-only by default. When off and a "
        "remote ref is encountered, a one-line stderr warning lists "
        "the count so users know what they're missing."
    ),
)
@click.option(
    "--gh-token",
    "gh_token",
    default=None,
    metavar="TOKEN",
    help=(
        "GitHub token used by --resolve-remote when fetching from "
        "raw.githubusercontent.com. Falls back to $GITHUB_TOKEN. "
        "Only required for private callee repos."
    ),
)
@click.option(
    "--no-cache",
    "no_cache",
    is_flag=True,
    default=False,
    help=(
        "Bypass the on-disk resolver cache "
        "(~/.cache/pipeline-check/gha-resolver) for this scan. "
        "Useful when a tag was force-pushed to a different SHA "
        "and you want the new bytes."
    ),
)
@click.option(
    "--gha-search-path",
    "gha_search_paths",
    multiple=True,
    metavar="PATH",
    help=(
        "On-disk root searched before the network when --resolve-"
        "remote is on. Repeat for multiple roots. Each is laid out "
        "as ``<root>/<owner>/<repo>/<workflow-path>``. Lets monorepos "
        "with sibling checkouts resolve fully offline."
    ),
)
@click.option(
    "--gha-resolve-depth",
    "gha_resolve_depth",
    type=int,
    default=3,
    show_default=True,
    help=(
        "Maximum depth the resolver follows transitive ``uses:`` "
        "calls. Hard ceiling 10. Cycles are detected and stop "
        "earlier."
    ),
)
@click.option(
    "--gitlab-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to a .gitlab-ci.yml file or a directory containing one "
        "(required when --pipeline gitlab)."
    ),
)
@click.option(
    "--bitbucket-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to a bitbucket-pipelines.yml file or a directory containing "
        "one (required when --pipeline bitbucket)."
    ),
)
@click.option(
    "--azure-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to an azure-pipelines.yml file or a directory containing one "
        "(required when --pipeline azure)."
    ),
)
@click.option(
    "--jenkinsfile-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to a Jenkinsfile or a directory containing one "
        "(required when --pipeline jenkins). Auto-detects ./Jenkinsfile."
    ),
)
@click.option(
    "--circleci-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to a CircleCI config.yml file or a directory containing one "
        "(required when --pipeline circleci). Auto-detects .circleci/config.yml."
    ),
)
@click.option(
    "--cfn-template",
    default=None,
    metavar="PATH",
    help=(
        "Path to a CloudFormation template (YAML or JSON) or a directory "
        "containing one (required when --pipeline cloudformation). "
        "Auto-detects common names like template.yml, template.json, "
        "cloudformation.yml, cfn.yaml."
    ),
)
@click.option(
    "--cloudbuild-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to a cloudbuild.yaml file or a directory containing one "
        "(required when --pipeline cloudbuild). Auto-detects "
        "./cloudbuild.yaml and ./cloudbuild.yml."
    ),
)
@click.option(
    "--dockerfile-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to a Dockerfile / Containerfile or a directory containing "
        "one (required when --pipeline dockerfile). Auto-detects "
        "./Dockerfile and ./Containerfile."
    ),
)
@click.option(
    "--k8s-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to a Kubernetes manifest (YAML) or a directory containing "
        "one (required when --pipeline kubernetes). Auto-detects "
        "./kubernetes/, ./k8s/, ./manifests/."
    ),
)
@click.option(
    "--buildkite-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to a Buildkite pipeline.yml file or a directory "
        "containing one (required when --pipeline buildkite). "
        "Auto-detects ./.buildkite/pipeline.yml."
    ),
)
@click.option(
    "--tekton-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to a Tekton YAML file or a directory containing one "
        "(required when --pipeline tekton). Documents are filtered "
        "to ``apiVersion: tekton.dev/*`` so a directory mixing "
        "Tekton and plain Kubernetes manifests is safe to point at."
    ),
)
@click.option(
    "--argo-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to an Argo Workflow YAML file or a directory "
        "containing one (required when --pipeline argo). Documents "
        "are filtered to ``apiVersion: argoproj.io/*``."
    ),
)
@click.option(
    "--helm-path",
    default=None,
    metavar="PATH",
    help=(
        "Path to a Helm chart directory (one containing Chart.yaml), a "
        "packaged .tgz chart, or a parent directory containing one or "
        "more charts (required when --pipeline helm). Auto-detects "
        "./Chart.yaml, ./charts/. Requires the 'helm' (Helm 3) binary "
        "on PATH."
    ),
)
@click.option(
    "--helm-values",
    "helm_values",
    multiple=True,
    metavar="FILE",
    help=(
        "Helm values file forwarded to ``helm template -f``. Repeat "
        "for multiple files; later files override earlier ones, "
        "matching helm's own precedence. Only meaningful with "
        "--pipeline helm."
    ),
)
@click.option(
    "--helm-set",
    "helm_set",
    multiple=True,
    metavar="KEY=VALUE",
    help=(
        "Helm value override forwarded to ``helm template --set``. "
        "Repeat for multiple overrides. Use the same syntax helm "
        "expects (``image.tag=v1`` or ``replicas=3``). Only "
        "meaningful with --pipeline helm."
    ),
)
@click.option(
    "--oci-manifest",
    "oci_manifest",
    default=None,
    metavar="PATH",
    help=(
        "Path to an OCI image manifest / image-index JSON file (the "
        "output of ``docker buildx imagetools inspect --raw <ref>`` "
        "or ``oras manifest fetch``), or a directory containing one "
        "(required when --pipeline oci). Pure parser, no registry "
        "pull, no daemon access. Auto-detects ./index.json."
    ),
)
@click.option(
    "--drone-path",
    "drone_path",
    default=None,
    metavar="PATH",
    help=(
        "Path to a Drone CI ``.drone.yml`` / ``.drone.yaml`` file "
        "or a directory containing one (required when --pipeline "
        "drone). Auto-detects ./.drone.yml or ./.drone.yaml."
    ),
)
@click.option(
    "--inventory",
    "inventory_flag",
    is_flag=True,
    default=False,
    help=(
        "Emit a component inventory alongside findings. Lists every "
        "resource/workflow/template the scanner discovered, "
        "complements the findings view and feeds asset-register "
        "dashboards. Added to JSON output as an ``inventory`` top-level "
        "array; rendered as a table after the findings for terminal "
        "output."
    ),
)
@click.option(
    "--inventory-type",
    "inventory_types",
    multiple=True,
    metavar="PATTERN",
    help=(
        "Glob pattern to scope --inventory output by component type "
        "(e.g. ``AWS::IAM::*``, ``aws_iam_role``, ``workflow``). "
        "Repeat for multiple patterns, a component is kept when its "
        "type matches any of them. Implies --inventory."
    ),
)
@click.option(
    "--inventory-only",
    is_flag=True,
    default=False,
    help=(
        "Skip running checks entirely; emit only the component "
        "inventory. Useful when the scanner is driving an asset "
        "register and you don't need security findings on every "
        "run. Implies --inventory. Mutually exclusive with --fix, "
        "--diff-base, and --baseline (each is rejected with a usage "
        "error when combined). See ``--man inventory``."
    ),
)
@click.option(
    "--output",
    "-o",
    type=click.Choice(
        [
            "terminal", "json", "html", "sarif", "junit",
            "markdown", "threatmodel", "both",
        ],
        case_sensitive=False,
    ),
    default="terminal",
    show_default=True,
    help="Output format.",
)
@click.option(
    "--output-file",
    "-O",
    default=None,
    metavar="PATH",
    help=(
        "Write the report to this file. Required for --output html. "
        "Optional for --output sarif/junit/markdown/threatmodel "
        "(stdout is used if unset)."
    ),
)
@click.option(
    "--standard",
    "standards",
    multiple=True,
    metavar="NAME",
    shell_complete=_complete_standards,
    help=(
        "Annotate findings with controls from the named standard. Repeat to "
        "enable multiple (e.g. --standard owasp_cicd_top_10 --standard "
        "cis_aws_foundations). Omit to include every registered standard."
    ),
)
@click.option(
    "--list-standards",
    is_flag=True,
    help="List every registered compliance standard and exit.",
)
@click.option(
    "--man",
    "man_topic",
    is_flag=False,
    flag_value="index",
    default=None,
    metavar="[TOPIC]",
    shell_complete=_complete_man_topics,
    help=(
        "Print extended documentation for TOPIC and exit. Without "
        "TOPIC, prints the index of available topics. Topics are "
        "generated from the manual registry; run ``--man`` with no "
        "argument for the current list. Unknown topic exits with code 3."
    ),
)
@click.option(
    "--standard-report",
    default=None,
    metavar="NAME",
    shell_complete=_complete_standards,
    help=(
        "Print the control -> check matrix for the named standard and "
        "exit. Includes a 'gaps' section listing controls with no "
        "mapped checks - useful for auditing standard coverage."
    ),
)
@click.option(
    "--list-checks",
    is_flag=True,
    default=False,
    help=(
        "List every check available for --pipeline (one per line: "
        "``ID  SEVERITY  TITLE``) and exit. Pipes well into ``grep`` "
        "for narrowing --checks patterns. No scan is performed."
    ),
)
@click.option(
    "--explain",
    "explain_id",
    default=None,
    metavar="CHECK_ID",
    shell_complete=_complete_check_ids,
    help=(
        "Print the full reference for one check (severity, confidence, "
        "compliance mappings, docs note, known FP modes, and how to "
        "fix it) and exit. Takes any ID from --list-checks. Exits 3 "
        "for an unknown ID and suggests near-matches."
    ),
)
@click.option(
    "--ai-explain",
    "ai_explain_id",
    default=None,
    metavar="CHECK_ID",
    shell_complete=_complete_check_ids,
    help=(
        "Augment ``--explain CHECK_ID`` with an AI-generated, project-"
        "specific remediation grounded in your README and (optionally) "
        "an offending file (``--ai-context-file PATH``). Opt-in. "
        "Bring your own key via ``ANTHROPIC_API_KEY`` / "
        "``OPENAI_API_KEY`` or run ``ollama serve`` locally. Output "
        "is clearly framed as ``[AI-generated, non-deterministic]`` "
        "and never affects the score / gate / SARIF output. Pick a "
        "provider with ``--ai-model anthropic`` / ``openai`` / "
        "``ollama`` (or a fully-qualified ``provider:model`` like "
        "``anthropic:claude-opus-4-7``)."
    ),
)
@click.option(
    "--ai-model",
    "ai_model_spec",
    default=None,
    metavar="SPEC",
    help=(
        "Provider for ``--ai-explain``. ``anthropic`` / ``openai`` / "
        "``ollama`` (default model) or ``provider:model`` (e.g. "
        "``anthropic:claude-opus-4-7``, ``ollama:llama3.2``). "
        "Falls back to ``$PIPELINE_CHECK_AI_MODEL`` and then to "
        "whichever provider has credentials in the environment."
    ),
)
@click.option(
    "--ai-context-file",
    "ai_context_file",
    default=None,
    type=click.Path(exists=True, dir_okay=False, readable=True),
    metavar="PATH",
    help=(
        "Optional file whose contents (first ~200 lines) get sent to "
        "the AI provider alongside the rule metadata so the response "
        "can be grounded in your actual code. Only used by "
        "``--ai-explain``."
    ),
)
@click.option(
    "--config-check",
    is_flag=True,
    help=(
        "Parse the config file, report any unknown keys, and exit. "
        "Exits non-zero when a dropped key is detected so CI can "
        "fail on typos. Use alongside --config PATH for explicit files."
    ),
)
@click.option(
    "--severity-threshold",
    type=click.Choice(_SEVERITY_CHOICES, case_sensitive=False),
    default="INFO",
    show_default=True,
    help="Minimum severity to display (e.g. HIGH shows only HIGH and CRITICAL).",
)
@click.option(
    "--min-confidence",
    type=click.Choice(["HIGH", "MEDIUM", "LOW"], case_sensitive=False),
    default="LOW",
    show_default=True,
    help=(
        "Minimum confidence to display and gate on. HIGH = only "
        "findings the scanner is certain about; MEDIUM = includes "
        "well-known heuristics; LOW (default) = includes blob-search "
        "patterns that have FP modes. For CI gates that only block "
        "on high-signal evidence, pass ``--min-confidence HIGH``."
    ),
)
@click.option(
    "--fail-on",
    "-f",
    type=click.Choice(_SEVERITY_CHOICES, case_sensitive=False),
    default=None,
    help=(
        "Fail the CI gate if any effective finding's severity is >= this "
        "threshold (e.g. --fail-on HIGH fails on HIGH or CRITICAL)."
    ),
)
@click.option(
    "--min-grade",
    type=click.Choice(["A", "B", "C", "D"], case_sensitive=False),
    default=None,
    help="Fail the gate if the overall grade is worse than this (A is best).",
)
@click.option(
    "--max-failures",
    type=int,
    default=None,
    metavar="N",
    help="Fail the gate if more than N effective failing findings are present.",
)
@click.option(
    "--fail-on-check",
    "fail_on_checks",
    multiple=True,
    metavar="CHECK_ID",
    shell_complete=_complete_check_ids,
    help=(
        "Fail the gate if the named check fails. Repeat for multiple "
        "(e.g. --fail-on-check IAM-001 --fail-on-check CB-002)."
    ),
)
@click.option(
    "--secret-pattern",
    "secret_patterns",
    multiple=True,
    metavar="REGEX",
    help=(
        "Extra regex (Python syntax) for the secret-scanning checks "
        "(GHA-008, GL-008, BB-008, ADO-008) to match against every "
        "string token. Repeat for multiple. Anchor with ^...$ for "
        "whole-token match. Also configurable via "
        "`secret_patterns: [...]` in the config file."
    ),
)
@click.option(
    "--detect-entropy",
    "detect_entropy",
    is_flag=True,
    default=False,
    help=(
        "Opt in to the Shannon-entropy secret detector. When enabled, "
        "the ``*-008`` literal-secret rules add an additional pass "
        "that flags high-entropy values (>= 3.5 bits/char, length "
        ">= 20) appearing in YAML key contexts that suggest a "
        "credential (``API_KEY``, ``apiToken``, ``password``, ...) "
        "and that the prefix-shape catalog hasn't already matched. "
        "Hits are labeled ``entropy:<redacted>``. Off by default "
        "because turning it on can introduce new findings on "
        "previously-clean scans, suppress per-resource via "
        "``--ignore-file`` once you've validated the heuristic."
    ),
)
@click.option(
    "--fix",
    is_flag=True,
    default=False,
    help=(
        "Emit a unified-diff patch to stdout for every failing finding "
        "that has a registered autofix. Does not modify files, pipe "
        "the output into `git apply` to apply. Currently supports: "
        + ", ".join(_autofix.available_fixers()) + "."
    ),
)
@click.option(
    "--apply",
    "apply_fixes",
    is_flag=True,
    default=False,
    help=(
        "Apply autofixes in place instead of emitting a patch. Only "
        "meaningful with --fix. Prints an 'N files modified' summary "
        "to stderr."
    ),
)
@click.option(
    "--baseline-from-git",
    default=None,
    metavar="REF:PATH",
    help=(
        "Load the baseline JSON from a prior commit via "
        "`git show REF:PATH`. Mirrors --diff-base for the baseline "
        "workflow. Example: --baseline-from-git origin/main:baseline.json"
    ),
)
@click.option(
    "--diff-base",
    default=None,
    metavar="REF",
    help=(
        "Scan only workflow/pipeline files changed since this git ref "
        "(e.g. `origin/main`). Uses `git diff --name-only <ref>...HEAD`; "
        "falls back to a full scan if git is unavailable. Ignored for "
        "AWS / Terraform providers."
    ),
)
@click.option(
    "--baseline",
    default=None,
    metavar="PATH",
    help=(
        "Path to a prior --output json report. Findings already failing in "
        "the baseline are excluded from gate evaluation (but still reported)."
    ),
)
@click.option(
    "--ignore-file",
    default=None,
    metavar="PATH",
    help=(
        "Path to an ignore file (one CHECK_ID or CHECK_ID:RESOURCE per line). "
        "Defaults to .pipelinecheckignore when present in the working dir."
    ),
)
@click.option(
    "--custom-rules",
    "custom_rules",
    multiple=True,
    metavar="PATH",
    help=(
        "YAML rule file (or directory of rule files) to load alongside "
        "the built-in catalog. Repeat for multiple paths. Loaded rules "
        "appear in findings, scoring, gating, --explain, and SARIF "
        "exactly like built-ins. See docs/writing_a_custom_rule.md for "
        "the rule-file shape and per-provider doc-tree reference."
    ),
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help=(
        "Emit additional [debug] messages to stderr showing provider "
        "resolution, check execution details, and gate configuration. "
        "Suppressed when --quiet is also set."
    ),
)
@click.option(
    "--quiet",
    "-q",
    is_flag=True,
    default=False,
    help=(
        "Suppress all terminal output. Only the exit code indicates "
        "pass (0) or fail (1). Useful for CI scripts that parse exit "
        "codes without needing human-readable output."
    ),
)
@click.option(
    "--no-chains",
    is_flag=True,
    default=False,
    help=(
        "Disable attack-chain correlation. By default the scanner "
        "correlates findings into multi-step attack narratives mapped "
        "to MITRE ATT&CK (e.g. AC-001 fork-PR credential theft). "
        "Disable when a downstream consumer doesn't understand the "
        "``chains`` JSON field, or to shave a few ms off a CI hot path."
    ),
)
@click.option(
    "--list-chains",
    is_flag=True,
    default=False,
    help=(
        "List every registered attack chain (one per line: "
        "``ID  SEVERITY  TITLE``) and exit. No scan is performed."
    ),
)
@click.option(
    "--serve",
    is_flag=True,
    default=False,
    help=(
        "Run pipeline-check as a Model Context Protocol (MCP) "
        "server on stdio. Lets MCP-aware AI clients (Claude "
        "Desktop, Claude Code, Cursor, Continue, Zed) introspect "
        "the rule catalog and run scans on demand. Requires the "
        "optional ``[mcp]`` extra: ``pip install "
        "'pipeline-check[mcp]'``. The process blocks until the "
        "client disconnects; no scan flags are honored in this "
        "mode (each scan is requested as an MCP tool call)."
    ),
)
@click.option(
    "--explain-chain",
    "explain_chain_id",
    default=None,
    metavar="CHAIN_ID",
    help=(
        "Print the full reference for one attack chain (summary, "
        "narrative template, MITRE ATT&CK techniques, kill-chain "
        "phase, references) and exit. Takes any ID from --list-chains."
    ),
)
@click.option(
    "--fail-on-chain",
    "fail_on_chain_ids",
    multiple=True,
    metavar="CHAIN_ID",
    help=(
        "Fail the gate if the named attack chain matched. Repeat for "
        "multiple (e.g. --fail-on-chain AC-001 --fail-on-chain AC-007). "
        "Chain matches bypass baseline/ignore filtering, a correlated "
        "attack path is intrinsically a new finding."
    ),
)
@click.option(
    "--fail-on-any-chain",
    is_flag=True,
    default=False,
    help=(
        "Fail the gate if any attack chain matched. Use as a blanket "
        "'no correlated attack paths in this branch' guard for "
        "high-trust repositories."
    ),
)
def scan(
    pipeline: str,
    pipelines_csv: str,
    target: str | None,
    checks: tuple[str, ...],
    region: str,
    profile: str | None,
    tf_plan: str | None,
    gha_path: str | None,
    gitlab_path: str | None,
    bitbucket_path: str | None,
    azure_path: str | None,
    jenkinsfile_path: str | None,
    circleci_path: str | None,
    cfn_template: str | None,
    cloudbuild_path: str | None,
    buildkite_path: str | None,
    tekton_path: str | None,
    argo_path: str | None,
    dockerfile_path: str | None,
    k8s_path: str | None,
    helm_path: str | None,
    helm_values: tuple[str, ...],
    helm_set: tuple[str, ...],
    oci_manifest: str | None,
    drone_path: str | None,
    inventory_flag: bool,
    inventory_types: tuple[str, ...],
    inventory_only: bool,
    output: str,
    output_file: str | None,
    standards: tuple[str, ...],
    list_standards: bool,
    man_topic: str | None,
    standard_report: str | None,
    list_checks: bool,
    explain_id: str | None,
    ai_explain_id: str | None,
    ai_model_spec: str | None,
    ai_context_file: str | None,
    config_check: bool,
    severity_threshold: str,
    min_confidence: str,
    fail_on: str | None,
    min_grade: str | None,
    max_failures: int | None,
    fail_on_checks: tuple[str, ...],
    secret_patterns: tuple[str, ...],
    detect_entropy: bool,
    fix: bool,
    apply_fixes: bool,
    baseline_from_git: str | None,
    diff_base: str | None,
    baseline: str | None,
    ignore_file: str | None,
    custom_rules: tuple[str, ...],
    verbose: bool,
    quiet: bool,
    no_chains: bool,
    list_chains: bool,
    explain_chain_id: str | None,
    fail_on_chain_ids: tuple[str, ...],
    fail_on_any_chain: bool,
    serve: bool = False,
    resolve_remote: bool = False,
    gh_token: str | None = None,
    no_cache: bool = False,
    gha_search_paths: tuple[str, ...] = (),
    gha_resolve_depth: int = 3,
) -> None:
    """PipelineCheck. CI/CD Security Posture Scanner.

    Analyzes CI/CD configurations and scores them against the
    OWASP Top 10 CI/CD Security Risks framework.
    """
    # --quiet wins over --verbose.
    verbose = verbose and not quiet

    def _debug(msg: str) -> None:
        if verbose:
            click.echo(f"[debug] {msg}", err=True)

    if man_topic is not None:
        from .core import manual as _manual
        known = set(_manual.topics())
        requested = (man_topic or "").lower()
        # ``--man`` alone (empty string) prints the index; only flag a
        # typo when the user supplied a non-empty topic that isn't in
        # the registry so scripts piping this through ``| grep`` get
        # a non-zero exit on misuse.
        click.echo(_manual.render(man_topic), nl=False)
        if requested and requested != "index" and requested not in known:
            sys.exit(3)
        return

    if list_standards:
        for std in _standards.resolve():
            click.echo(f"{std.name} ,  {std.title} (v{std.version or 'n/a'})")
            if std.url:
                click.echo(f"    {std.url}")
        return

    if serve:
        # Lazy import so the optional ``mcp`` SDK doesn't load at
        # CLI startup. The harness raises a clean RuntimeError when
        # the package isn't installed; surface it as exit 3.
        try:
            from .mcp_server import run_stdio
        except ImportError as exc:  # pragma: no cover - import-time safeguard
            click.echo(
                f"[error] MCP support unavailable: {exc}. "
                "Install with ``pip install 'pipeline-check[mcp]'``.",
                err=True,
            )
            sys.exit(3)
        try:
            run_stdio()
        except RuntimeError as exc:
            click.echo(f"[error] {exc}", err=True)
            sys.exit(3)
        except KeyboardInterrupt:
            pass
        return

    if list_checks:
        _list_checks_for_pipeline(pipeline.lower())
        return

    if list_chains:
        from .core import chains as _chains_pkg
        rules = _chains_pkg.list_rules()
        if not rules:
            click.echo("[list-chains] no attack chains registered.", err=True)
            sys.exit(3)
        id_w = max(len(r.id) for r in rules)
        sev_w = max(len(r.severity.value) for r in rules)
        for r in sorted(rules, key=lambda x: x.id):
            click.echo(f"{r.id:<{id_w}}  {r.severity.value:<{sev_w}}  {r.title}")
        return

    if explain_chain_id:
        from .core import chains as _chains_pkg
        # Distinct name from the ``rules`` list a few lines above so mypy
        # doesn't carry the list-typed inference across the reassignment.
        rules_by_id = {r.id.upper(): r for r in _chains_pkg.list_rules()}
        target_id = explain_chain_id.upper()
        rule = rules_by_id.get(target_id)
        if rule is None:
            import difflib
            rule_ids: list[str] = list(rules_by_id.keys())
            suggestions = difflib.get_close_matches(target_id, rule_ids, n=3)
            hint = f" Did you mean: {', '.join(suggestions)}?" if suggestions else ""
            click.echo(
                f"[explain-chain] unknown chain {explain_chain_id!r}.{hint}",
                err=True,
            )
            sys.exit(3)
        click.echo(f"{rule.id}, {rule.title}")
        click.echo(f"  Severity: {rule.severity.value}")
        if rule.providers:
            click.echo(f"  Providers: {', '.join(rule.providers)}")
        if rule.kill_chain_phase:
            click.echo(f"  Kill chain: {rule.kill_chain_phase}")
        if rule.mitre_attack:
            click.echo(f"  MITRE ATT&CK: {', '.join(rule.mitre_attack)}")
        click.echo("")
        click.echo("Summary:")
        click.echo(f"  {rule.summary}")
        click.echo("")
        click.echo("Recommendation:")
        click.echo(f"  {rule.recommendation}")
        if rule.references:
            click.echo("")
            click.echo("References:")
            for ref in rule.references:
                click.echo(f"  - {ref}")
        return

    if explain_id and ai_explain_id:
        # ``--ai-explain`` already runs the deterministic body before
        # the AI section, so passing both flags is always a mistake.
        # Reject it explicitly instead of silently letting ``--explain``
        # win (which used to drop the AI section without any signal).
        raise click.UsageError(
            "--explain and --ai-explain are mutually exclusive. "
            "Use --ai-explain CHECK_ID for the deterministic body "
            "plus the AI-generated section, or --explain CHECK_ID "
            "for the deterministic body alone."
        )

    if explain_id:
        from .core.explain import print_explain
        sys.exit(print_explain(explain_id))

    if ai_explain_id:
        sys.exit(_run_ai_explain(
            ai_explain_id,
            model_spec=ai_model_spec,
            context_file=ai_context_file,
        ))

    if standard_report:
        # Distinct name from the ``std`` loop variable above (line 1099)
        # so mypy can narrow ``Standard | None`` to ``Standard`` after
        # the None check without conflicting with the loop variable's
        # narrower inferred type.
        report_std = _standards.get(standard_report)
        if report_std is None:
            available = ", ".join(_standards.available())
            raise click.UsageError(
                f"Unknown standard {standard_report!r}. "
                f"Available: {available or 'none'}."
            )
        click.echo(f"{report_std.name} ,  {report_std.title} (v{report_std.version or 'n/a'})")
        if report_std.url:
            click.echo(f"  {report_std.url}")
        click.echo("")
        click.echo("Control -> check mapping:")
        gaps: list[tuple[str, str]] = []
        for ctrl_id in sorted(report_std.controls):
            title = report_std.controls[ctrl_id]
            check_ids = [
                cid for cid, controls in report_std.mappings.items()
                if ctrl_id in controls
            ]
            if check_ids:
                joined = ", ".join(sorted(check_ids))
                click.echo(f"  [{ctrl_id}] {title}")
                click.echo(f"      checks: {joined}")
            else:
                gaps.append((ctrl_id, title))
        if gaps:
            click.echo("")
            click.echo(f"Gaps ({len(gaps)} control(s) with no mapped check):")
            for ctrl_id, title in gaps:
                click.echo(f"  [{ctrl_id}] {title}")
        return

    if config_check:
        from .core.config import last_unknown_keys
        dropped = last_unknown_keys()
        if not dropped:
            click.echo("[config] OK, no unknown keys.")
            return
        for source, key, reason in dropped:
            click.echo(f"[config] {source}: {key!r}, {reason}", err=True)
        click.echo(f"[config] {len(dropped)} unknown key(s) detected.", err=True)
        sys.exit(3)

    if apply_fixes and not fix:
        raise click.UsageError("--apply requires --fix.")

    # Mutually-exclusive flag combinations, catch these before the
    # provider context is built so the error points at the conflict
    # rather than surfacing as a silent no-op later.
    if inventory_only and fix:
        raise click.UsageError(
            "--fix cannot be combined with --inventory-only "
            "(no findings are produced to fix)."
        )
    if inventory_only and diff_base:
        raise click.UsageError(
            "--diff-base cannot be combined with --inventory-only "
            "(inventory is a full-state snapshot, not a per-commit delta)."
        )
    if inventory_only and baseline:
        raise click.UsageError(
            "--baseline cannot be combined with --inventory-only "
            "(baselines gate findings; --inventory-only emits no findings)."
        )

    # Validate --baseline early so a typo'd path doesn't surface as
    # "no regressions found" after a full scan completes.
    if baseline and not os.path.isfile(baseline):
        raise click.UsageError(f"--baseline file not found: {baseline}")

    # Parse --pipelines (multi-provider mode). Mutually exclusive
    # with the single-valued --pipeline flag, the user picks one or
    # the other, never both. When --pipelines is set, every provider
    # in the list runs in one scan and the chain engine evaluates
    # over the union of every sub-scan's findings, which is what
    # activates cross-provider attack chains (the XPC-NNN family).
    pipelines_list: list[str] = []
    if pipelines_csv:
        if pipeline.lower() != "auto":
            raise click.UsageError(
                "--pipelines is mutually exclusive with --pipeline; "
                "drop --pipeline (it defaults to ``auto`` and is "
                "ignored when --pipelines is set)."
            )
        seen: set[str] = set()
        for raw in pipelines_csv.split(","):
            name = raw.strip().lower()
            if not name or name in seen:
                continue
            seen.add(name)
            pipelines_list.append(name)
        if not pipelines_list:
            raise click.UsageError(
                "--pipelines parsed empty after splitting on commas."
            )
        valid = set(_providers.available())
        invalid = [p for p in pipelines_list if p not in valid]
        if invalid:
            raise click.UsageError(
                f"unknown provider(s) in --pipelines: "
                f"{', '.join(invalid)}. Valid: "
                f"{', '.join(sorted(valid))}"
            )

    pipeline_lc = pipeline.lower()
    if not pipelines_list and pipeline_lc == "auto":
        detected = _detect_pipeline_from_cwd()
        if detected:
            click.echo(f"[auto] detected --pipeline {detected}", err=True)
            pipeline_lc = detected
        else:
            click.echo(
                "[auto] no CI files found at cwd; using --pipeline aws",
                err=True,
            )
            pipeline_lc = "aws"

    # Per-provider path resolution. In single-pipeline mode the
    # if/elif chain below runs once for ``pipeline_lc``; in
    # multi-pipeline mode it runs once per provider so each
    # provider's path flag (--gha-path, --oci-manifest, etc.) is
    # resolved + auto-detected the same way as a single-pipeline
    # invocation.
    pipelines_to_resolve = pipelines_list or [pipeline_lc]
    for pipeline_lc in pipelines_to_resolve:
        if pipeline_lc == "terraform":
            tf_plan = _resolve_provider_path(
                "terraform", flag="tf-plan", value=tf_plan,
                validate_kind="file", not_found_label="path",
            )
        elif pipeline_lc == "github":
            gha_path = _resolve_provider_path(
                "github", flag="gha-path", value=gha_path,
                candidates=(".github/workflows",), candidate_kind="dir",
                validate_kind="dir", detect_label=".github/workflows",
                not_found_label="directory",
            )
        elif pipeline_lc == "gitlab":
            gitlab_path = _resolve_provider_path(
                "gitlab", flag="gitlab-path", value=gitlab_path,
                candidates=(".gitlab-ci.yml",),
                detect_label=".gitlab-ci.yml",
            )
        elif pipeline_lc == "bitbucket":
            bitbucket_path = _resolve_provider_path(
                "bitbucket", flag="bitbucket-path", value=bitbucket_path,
                candidates=("bitbucket-pipelines.yml",),
                detect_label="bitbucket-pipelines.yml",
            )
        elif pipeline_lc == "azure":
            azure_path = _resolve_provider_path(
                "azure", flag="azure-path", value=azure_path,
                candidates=("azure-pipelines.yml",),
                detect_label="azure-pipelines.yml",
            )
        elif pipeline_lc == "jenkins":
            jenkinsfile_path = _resolve_provider_path(
                "jenkins", flag="jenkinsfile-path", value=jenkinsfile_path,
                candidates=("Jenkinsfile",),
                detect_label="Jenkinsfile",
            )
        elif pipeline_lc == "circleci":
            circleci_path = _resolve_provider_path(
                "circleci", flag="circleci-path", value=circleci_path,
                candidates=(".circleci/config.yml",),
                detect_label=".circleci/config.yml",
            )
        elif pipeline_lc == "cloudformation":
            if not cfn_template:
                for _candidate in (
                    "template.yml", "template.yaml", "template.json",
                    "cloudformation.yml", "cloudformation.yaml",
                    "cfn.yml", "cfn.yaml",
                ):
                    if os.path.isfile(_candidate):
                        cfn_template = _candidate
                        click.echo(
                            f"[auto] using --cfn-template {cfn_template}",
                            err=True,
                        )
                        break
            if not cfn_template:
                raise click.UsageError(
                    "--cfn-template PATH is required when --pipeline "
                    "cloudformation (no template.yml / template.json / "
                    "cloudformation.yml / cfn.yaml found in the current "
                    "directory)."
                )
            if not os.path.exists(cfn_template):
                raise click.UsageError(
                    f"--cfn-template not found: {cfn_template}"
                )
            # Distinguish "directory but no templates" from "file not found" —
            # the former is a common mistake when someone points the flag at
            # their project root instead of an infrastructure subdirectory.
            if os.path.isdir(cfn_template):
                _exts = (".yml", ".yaml", ".json", ".template")
                has_templates = any(
                    _ent.is_file() and _ent.name.lower().endswith(_exts)
                    for _ent in os.scandir(cfn_template)
                )
                if not has_templates:
                    raise click.UsageError(
                        f"--cfn-template directory {cfn_template!r} contains "
                        f"no .yml / .yaml / .json / .template files."
                    )
        elif pipeline_lc == "cloudbuild":
            cloudbuild_path = _resolve_provider_path(
                "cloudbuild", flag="cloudbuild-path", value=cloudbuild_path,
                candidates=("cloudbuild.yaml", "cloudbuild.yml"),
                detect_label="cloudbuild.yaml/cloudbuild.yml",
            )
        elif pipeline_lc == "buildkite":
            buildkite_path = _resolve_provider_path(
                "buildkite", flag="buildkite-path", value=buildkite_path,
                candidates=(".buildkite/pipeline.yml", ".buildkite/pipeline.yaml"),
                detect_label=".buildkite/pipeline.yml",
            )
        elif pipeline_lc == "tekton":
            tekton_path = _resolve_provider_path(
                "tekton", flag="tekton-path", value=tekton_path,
            )
        elif pipeline_lc == "argo":
            argo_path = _resolve_provider_path(
                "argo", flag="argo-path", value=argo_path,
            )
        elif pipeline_lc == "dockerfile":
            dockerfile_path = _resolve_provider_path(
                "dockerfile", flag="dockerfile-path", value=dockerfile_path,
                candidates=("Dockerfile", "Containerfile"),
                detect_label="Dockerfile/Containerfile",
            )
        elif pipeline_lc == "kubernetes":
            k8s_path = _resolve_provider_path(
                "kubernetes", flag="k8s-path", value=k8s_path,
                candidates=("kubernetes", "k8s", "manifests"),
                candidate_kind="dir",
                detect_label="kubernetes/, k8s/, or manifests/ directory",
            )
        elif pipeline_lc == "helm":
            if not helm_path:
                if os.path.isfile("Chart.yaml"):
                    helm_path = "."
                    click.echo("[auto] using --helm-path .", err=True)
                elif os.path.isdir("charts"):
                    helm_path = "charts"
                    click.echo("[auto] using --helm-path charts", err=True)
            if not helm_path:
                raise click.UsageError(
                    "--helm-path PATH is required when --pipeline helm "
                    "(no Chart.yaml or charts/ directory found in cwd)."
                )
            if not os.path.exists(helm_path):
                raise click.UsageError(
                    f"--helm-path not found: {helm_path}"
                )
            for vf in helm_values:
                if not os.path.isfile(vf):
                    raise click.UsageError(
                        f"--helm-values not found: {vf}"
                    )
        elif pipeline_lc == "oci":
            oci_manifest = _resolve_provider_path(
                "oci", flag="oci-manifest", value=oci_manifest,
                candidates=("index.json",),
                detect_label="index.json",
            )
        elif pipeline_lc == "drone":
            drone_path = _resolve_provider_path(
                "drone", flag="drone-path", value=drone_path,
                candidates=(".drone.yml", ".drone.yaml"),
                detect_label=".drone.yml/.drone.yaml",
            )

    if output == "html" and not output_file:
        raise click.UsageError(
            "--output-file PATH is required when --output html."
        )

    for pat in secret_patterns:
        try:
            re.compile(pat)
        except re.error as exc:
            raise click.UsageError(
                f"--secret-pattern {pat!r} is not a valid regex: {exc}"
            ) from exc

    for crp in custom_rules:
        if not os.path.exists(crp):
            raise click.UsageError(f"--custom-rules not found: {crp}")

    if diff_base is not None and diff_base.startswith("-"):
        # ``diff_base`` is composed into ``git diff --name-only
        # <base>...HEAD``. A leading ``-`` makes git parse the value
        # as an option (e.g. ``--output=path``, write-anywhere
        # primitive). Catch it here so the CLI shows a clean
        # UsageError; the helper also validates as defense in depth
        # (CWE-88, argument injection).
        raise click.UsageError(
            "--diff-base must not start with '-' "
            "(would be parsed as a git flag, not a positional ref)"
        )

    threshold = Severity(severity_threshold.upper())
    confidence_threshold = Confidence(min_confidence.upper())

    if not quiet:
        from .core.config import last_loaded_source as _config_source
        _cfg_src = _config_source()
        if _cfg_src:
            click.echo(f"[config] loaded {_cfg_src}", err=True)

    from .core.config import last_overrides as _config_overrides
    cli_overrides = _config_overrides()

    if pipelines_list:
        _debug(f"providers: {', '.join(pipelines_list)}")
    else:
        _debug(f"provider: {pipeline_lc}")

    # Shared kwargs forwarded to every (Multi)Scanner sub-scan.
    # Each provider's path flag is in here; the providers that
    # don't recognize a given flag silently ignore it.
    _scanner_kwargs: dict[str, Any] = dict(
        region=region,
        profile=profile,
        diff_base=diff_base,
        secret_patterns=secret_patterns or None,
        detect_entropy=detect_entropy,
        overrides=cli_overrides or None,
        custom_rules=list(custom_rules) or None,
        log=_debug if verbose else None,
        tf_plan=tf_plan,
        gha_path=gha_path,
        gitlab_path=gitlab_path,
        bitbucket_path=bitbucket_path,
        azure_path=azure_path,
        jenkinsfile_path=jenkinsfile_path,
        circleci_path=circleci_path,
        cfn_template=cfn_template,
        cloudbuild_path=cloudbuild_path,
        buildkite_path=buildkite_path,
        tekton_path=tekton_path,
        argo_path=argo_path,
        resolve_remote=resolve_remote,
        gh_token=gh_token,
        no_cache=no_cache,
        gha_search_paths=list(gha_search_paths),
        gha_resolve_depth=gha_resolve_depth,
        dockerfile_path=dockerfile_path,
        k8s_path=k8s_path,
        helm_path=helm_path,
        helm_values=list(helm_values) or None,
        helm_set=list(helm_set) or None,
        oci_manifest=oci_manifest,
        drone_path=drone_path,
    )

    scanner: Scanner | MultiScanner
    if pipelines_list:
        # Multi-provider mode. Each sub-scanner's chain pass is
        # suppressed regardless; ``MultiScanner.run`` evaluates
        # chains once over the union (when ``chains_enabled=True``)
        # so cross-provider chains (XPC-NNN) fire. Single-provider
        # chains still match in that union pass, so AC-NNN coverage
        # carries through. ``--no-chains`` disables the union pass
        # too.
        scanner = MultiScanner(
            pipelines=pipelines_list,
            chains_enabled=not no_chains,
            **_scanner_kwargs,
        )
    else:
        scanner = Scanner(
            pipeline=pipeline_lc,
            chains_enabled=not no_chains,
            **_scanner_kwargs,
        )

    if verbose:
        meta = scanner.metadata
        if meta.files_scanned or meta.files_skipped:
            _debug(f"loaded {meta.files_scanned} file(s), {meta.files_skipped} skipped")
        _debug(f"checks to run: {len(scanner._check_classes)} check class(es)")

    # ``--inventory-only``, ``--inventory-type``, and ``--output
    # threatmodel`` all imply ``--inventory``. Threat-model generation
    # populates its Assets and trust-boundary sections from the
    # inventory, so a run with ``--output threatmodel`` and no
    # explicit ``--inventory`` flag transparently turns it on.
    want_inventory = (
        inventory_flag
        or inventory_only
        or bool(inventory_types)
        or output == "threatmodel"
    )

    findings: list[Any] = []
    if not inventory_only:
        try:
            findings = scanner.run(
                checks=list(checks) if checks else None,
                target=target,
                standards=list(standards) if standards else None,
            )
        except Exception as exc:
            # Print the traceback to stderr so operators have something to
            # take to support. Keep the single-line summary above it for
            # teams that grep logs for "[error] Scan failed".
            import traceback
            click.echo(f"[error] Scan failed: {exc}", err=True)
            click.echo(traceback.format_exc(), err=True, nl=False)
            sys.exit(2)

    if not quiet:
        _emit_scan_summary(scanner.metadata)
        _maybe_emit_wrong_provider_hint(pipeline_lc, findings)

    # Confidence filter applies BEFORE scoring + gate so scores reflect
    # the trusted finding set. ``--min-confidence LOW`` (the default)
    # keeps everything; higher thresholds drop heuristic findings the
    # scanner is less certain about.
    pre_filter_count = len(findings)
    min_conf_rank = confidence_rank(confidence_threshold)
    findings = [
        f for f in findings if confidence_rank(f.confidence) >= min_conf_rank
    ]
    if verbose and pre_filter_count != len(findings):
        _debug(
            f"--min-confidence {confidence_threshold.value}: dropped "
            f"{pre_filter_count - len(findings)} finding(s)"
        )

    n_passed = sum(1 for f in findings if f.passed)
    n_failed = sum(1 for f in findings if not f.passed)
    _debug(f"findings: {len(findings)} total ({n_failed} failed, {n_passed} passed)")

    score_result = score(findings)

    # Collect the component inventory only when requested, some
    # providers (AWS runtime) perform extra API calls to build it.
    components = None
    if want_inventory:
        try:
            components = scanner.inventory(
                type_patterns=list(inventory_types) if inventory_types else None,
            )
        except Exception as exc:  # noqa: BLE001
            click.echo(f"[inventory] failed: {exc}", err=True)
            components = []

    chains = list(getattr(scanner, "chains", []) or [])

    if not quiet:
        if output in ("terminal", "both"):
            # When emitting both terminal and JSON, send the human-readable report to
            # stderr so the JSON on stdout remains clean and machine-parseable.
            from rich.console import Console as _Console  # local import, only needed here
            console = _Console(stderr=(output == "both"))
            report_terminal(findings, score_result, severity_threshold=threshold, console=console)
            if chains:
                report_chains_terminal(chains, console=console)
            if components is not None:
                report_inventory_terminal(components, console=console)

        if output in ("json", "both"):
            click.echo(report_json(
                findings, score_result, tool_version=__version__,
                inventory=components,
                chains=chains if not no_chains else None,
            ))

        if output == "html":
            report_html(
                findings, score_result, region=region, target=target or "",
                output_path=output_file, chains=chains,
            )
            click.echo(f"HTML report written to {output_file}", err=True)

        if output == "sarif":
            sarif_text = report_sarif(
                findings, score_result, tool_version=__version__, chains=chains,
            )
            if output_file:
                with open(output_file, "w", encoding="utf-8") as fh:
                    fh.write(sarif_text)
                click.echo(f"SARIF report written to {output_file}", err=True)
            else:
                click.echo(sarif_text)

        if output == "junit":
            junit_text = report_junit(findings, score_result)
            if output_file:
                with open(output_file, "w", encoding="utf-8") as fh:
                    fh.write(junit_text)
                click.echo(f"JUnit report written to {output_file}", err=True)
            else:
                click.echo(junit_text)

        if output == "markdown":
            md_text = report_markdown(findings, score_result, chains=chains)
            if output_file:
                with open(output_file, "w", encoding="utf-8") as fh:
                    fh.write(md_text)
                click.echo(f"Markdown report written to {output_file}", err=True)
            else:
                click.echo(md_text)

        if output == "threatmodel":
            tm_text = report_threatmodel(
                findings, score_result,
                inventory=components, chains=chains,
                tool_version=__version__,
                region=region or "", target=target or "",
            )
            if output_file:
                with open(output_file, "w", encoding="utf-8") as fh:
                    fh.write(tm_text)
                click.echo(
                    f"Threat-model report written to {output_file}",
                    err=True,
                )
            else:
                click.echo(tm_text)

        if fix:
            if apply_fixes:
                _apply_fix_patches(findings)
            else:
                # Route patches to stderr whenever stdout is carrying a machine-
                # readable report, so `--output json --fix` doesn't produce
                # "JSON...--- a/file" and break downstream parsers. The
                # documented `pipeline_check --fix | git apply` recipe uses the
                # default terminal output where stdout is free for the patch.
                _emit_fix_patches(findings, to_stderr=output != "terminal")

    # CI gate evaluation. See pipeline_check.core.gate for the full contract.
    ignore_path = ignore_file or ".pipelinecheckignore"
    baseline_git_pair: tuple[str, str] | None = None
    if baseline and baseline_from_git:
        raise click.UsageError(
            "--baseline and --baseline-from-git are mutually exclusive. "
            "Pick one: a file path, or a git REF:PATH lookup."
        )
    if baseline_from_git:
        if ":" not in baseline_from_git:
            raise click.UsageError(
                "--baseline-from-git expects REF:PATH (e.g. origin/main:baseline.json)"
            )
        ref_part, path_part = baseline_from_git.split(":", 1)
        # ``ref_part`` and ``path_part`` flow into ``git show`` as
        # positional arguments composed via f-string. Reject leading
        # ``-`` here so the CLI surfaces a clean UsageError instead of
        # the lower-layer ValueError; the helper validates again as a
        # second line of defense (CWE-88, argument injection).
        if ref_part.startswith("-") or path_part.startswith("-"):
            raise click.UsageError(
                "--baseline-from-git REF and PATH must not start with '-' "
                "(would be parsed as a git flag, not a positional argument)"
            )
        baseline_git_pair = (ref_part, path_part)
    gate_config = GateConfig(
        fail_on=Severity(fail_on.upper()) if fail_on else None,
        min_grade=min_grade.upper() if min_grade else None,
        max_failures=max_failures,
        fail_on_checks={c.upper() for c in fail_on_checks},
        baseline_path=baseline,
        baseline_from_git=baseline_git_pair,
        ignore_rules=load_ignore_file(ignore_path),
        fail_on_chains={c.upper() for c in fail_on_chain_ids},
        fail_on_any_chain=fail_on_any_chain,
    )

    if verbose:
        parts = []
        parts.append(f"fail-on={fail_on or 'CRITICAL (default)'}")
        if min_grade:
            parts.append(f"min-grade={min_grade}")
        if max_failures is not None:
            parts.append(f"max-failures={max_failures}")
        if baseline:
            parts.append(f"baseline={baseline}")
        elif baseline_from_git:
            parts.append(f"baseline-from-git={baseline_from_git}")
        _debug(f"gate config: {', '.join(parts)}")

    gate = evaluate_gate(findings, score_result, gate_config, chains=chains)

    if not quiet and output != "json":
        _emit_gate_summary(gate)

    if not gate.passed:
        sys.exit(1)


def _run_ai_explain(
    check_id: str,
    *,
    model_spec: str | None,
    context_file: str | None,
) -> int:
    """Print the deterministic explain body, then an AI-augmented section.

    Returns the exit code: 0 on success, 3 for an unknown check ID
    (matching the deterministic ``--explain`` contract), 4 for an
    AI-side configuration / dependency / network failure (so CI
    can distinguish "your scan is broken" from "the AI provider is").
    """
    # Always print the deterministic body first. If the ID is bad, the
    # deterministic path already exits 3 with a near-match suggestion;
    # the AI side never gets called for an unknown ID.
    from .core.explain import (
        _build_index,  # noqa: PLC2701 (intentional)
        print_explain,
    )
    body_code = print_explain(check_id)
    # Flush so the deterministic body lands on screen before any AI-
    # side error / output. Without this, an unbuffered stderr message
    # ("no AI provider configured") prints before the still-buffered
    # stdout body when the caller redirects 2>&1.
    sys.stdout.flush()
    if body_code != 0:
        return body_code

    # Resolve the rule (we already know it exists since print_explain
    # returned 0). The deterministic explain renders by ``_CheckMeta``
    # which carries the rule for rule-based packs; class-based packs
    # only have ``id`` / ``title`` / ``severity``, in which case we
    # synthesise a minimal Rule for the prompt.
    from .core.ai_explain import (
        AIAuthError,
        AIDependencyError,
        AIRequestError,
        default_spec_from_env,
        explain_check,
        render_section,
        select_client,
    )
    from .core.checks.rule import Rule as _Rule

    cid = check_id.strip().upper()
    meta = _build_index().get(cid)
    if meta is None:
        # Belt and suspenders: print_explain already returned 0, so
        # the index lookup should succeed; this guards against drift.
        click.echo(
            f"\n[ai-explain] internal: rule {cid!r} not in index", err=True,
        )
        return 4

    if meta.rule is not None:
        rule = meta.rule
    else:
        # Class-based pack — synthesise a minimal Rule so the prompt
        # builder still has a stable shape.
        rule = _Rule(
            id=meta.id,
            title=meta.title,
            severity=meta.severity,
            recommendation="(class-based check; no rule-level prose)",
            docs_note=meta.docstring or "",
        )

    spec = model_spec or default_spec_from_env()
    if not spec:
        click.echo(
            "\n[ai-explain] no AI provider configured. Set "
            "ANTHROPIC_API_KEY / OPENAI_API_KEY, or pass "
            "``--ai-model ollama`` to use a local Ollama daemon.",
            err=True,
        )
        return 4

    try:
        client = select_client(spec)
    except (ValueError, AIDependencyError, AIAuthError) as exc:
        click.echo(f"\n[ai-explain] {exc}", err=True)
        return 4

    try:
        response = explain_check(
            rule, client=client, context_file=context_file,
        )
    except AIRequestError as exc:
        click.echo(f"\n[ai-explain] {exc}", err=True)
        return 4

    # Extra blank line so the AI section visually separates from the
    # deterministic body above.
    click.echo("")
    click.echo(render_section(client.name, response))
    return 0


def _emit_fix_patches(findings: list[Any], *, to_stderr: bool = False) -> None:
    """Emit one unified-diff patch per failing finding that has a fixer.

    Patches go to stdout by default so a user can pipe straight into
    ``git apply``. When a machine-readable report is already occupying
    stdout (``--output json/sarif/html/both``), the caller sets
    ``to_stderr=True`` to avoid corrupting that stream.

    File read errors are silently skipped, a missing file is almost
    always due to a finding with a synthetic resource name (e.g. an
    AWS check), not a real on-disk workflow. Per-path content is
    cached so multiple findings against the same file only re-read
    the source once.
    """
    import os
    cache: dict[str, str] = {}
    patch_count = 0
    patched_files: set[str] = set()
    for f in findings:
        if f.passed:
            continue
        path = f.resource
        if not path or not os.path.isfile(path):
            continue
        before = cache.get(path)
        if before is None:
            try:
                with open(path, encoding="utf-8") as fh:
                    before = fh.read()
            except (OSError, UnicodeDecodeError):
                continue
            cache[path] = before
        try:
            after = _autofix.generate_fix(f, before)
        except Exception as exc:
            # One broken fixer must not abort the whole --fix run. Log
            # to stderr so the bug is still visible to whoever is
            # debugging it.
            click.echo(
                f"[autofix] fixer for {f.check_id} raised {type(exc).__name__}: {exc}",
                err=True,
            )
            continue
        if after is None:
            continue
        patch_count += 1
        patched_files.add(path)
        click.echo(
            _autofix.render_patch(path, before, after),
            nl=False,
            err=to_stderr,
        )
    if patch_count:
        click.echo(
            f"[autofix] {patch_count} patch(es) for {len(patched_files)} file(s)."
            f" Run with --apply to modify in place.",
            err=True,
        )


def _apply_fix_patches(findings: list[Any]) -> None:
    """Apply autofixes in place; print an N-files-modified summary to stderr.

    Each fixer is idempotent, so it's safe to re-run after an apply —
    already-fixed files produce no further patch. Unfixable findings
    are silently skipped.
    """
    import os
    cache: dict[str, str] = {}
    dirty: dict[str, str] = {}  # path → final content
    for f in findings:
        if f.passed:
            continue
        path = f.resource
        if not path or not os.path.isfile(path):
            continue
        before = dirty.get(path) or cache.get(path)
        if before is None:
            try:
                with open(path, encoding="utf-8") as fh:
                    before = fh.read()
            except (OSError, UnicodeDecodeError):
                continue
            cache[path] = before
        try:
            after = _autofix.generate_fix(f, before)
        except Exception as exc:
            click.echo(
                f"[autofix] fixer for {f.check_id} raised {type(exc).__name__}: {exc}",
                err=True,
            )
            continue
        if after is None:
            continue
        dirty[path] = after
    for path, content in dirty.items():
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(content)
        except OSError as exc:
            click.echo(f"[autofix] could not write {path}: {exc}", err=True)
    click.echo(f"[autofix] {len(dirty)} file(s) modified.", err=True)


def _maybe_emit_wrong_provider_hint(pipeline_lc: str, findings: list[Any]) -> None:
    """Nudge the user when AWS was scanned but a CI config file exists.

    Fires only when the caller explicitly picked ``--pipeline aws`` (or
    configured it) AND every finding is a degraded ``*-000`` API-access
    probe AND cwd looks like a CI repo. Designed to catch the common
    'wrong credentials / wrong provider' first-run mistake without
    spamming legitimate AWS runs.
    """
    if pipeline_lc != "aws" or not findings:
        return
    if not all(getattr(f, "check_id", "").endswith("-000") for f in findings):
        return
    detected = _detect_pipeline_from_cwd()
    if not detected:
        return
    click.echo(
        f"[hint] no real AWS results. This looks like a '{detected}' "
        f"repo; try: pipeline_check --pipeline {detected}",
        err=True,
    )


def _emit_scan_summary(meta: Any) -> None:
    """Render the scan summary line and any parse warnings to stderr."""
    from .core.scanner import ScanMetadata
    if not isinstance(meta, ScanMetadata):
        return
    for w in meta.warnings:
        click.echo(f"[warn] {w}", err=True)
    if meta.files_scanned == 0 and meta.files_skipped == 0:
        click.echo("[warn] no pipeline files found to scan", err=True)
        return
    skip_part = f" ({meta.files_skipped} skipped)" if meta.files_skipped else ""
    click.echo(
        f"[scan] {meta.provider}: scanned {meta.files_scanned} file(s){skip_part}"
        f" in {meta.elapsed_seconds:.1f}s",
        err=True,
    )


def _emit_gate_summary(gate: Any) -> None:
    """Render the gate outcome to stderr so JSON/SARIF on stdout stays clean."""
    n_effective = len(gate.effective)
    n_chains_tripped = len(getattr(gate, "tripped_chains", []) or [])
    if gate.passed:
        msg_lines = [f"[gate] PASS ({n_effective} effective finding(s) evaluated)"]
        for cond in getattr(gate, "conditions_evaluated", []):
            msg_lines.append(f"        - {cond}")
    else:
        msg_lines = ["[gate] FAIL"]
        for reason in gate.reasons:
            msg_lines.append(f"        - {reason}")
    if n_chains_tripped:
        ids = ", ".join(sorted({c.chain_id for c in gate.tripped_chains}))
        msg_lines.append(f"[gate] {n_chains_tripped} attack chain(s) tripped: {ids}")
    if gate.baseline_matched:
        msg_lines.append(
            f"[gate] {len(gate.baseline_matched)} finding(s) suppressed by baseline"
        )
    if gate.suppressed:
        msg_lines.append(
            f"[gate] {len(gate.suppressed)} finding(s) suppressed by ignore file"
        )
    if gate.expired_rules:
        for r in gate.expired_rules:
            scope = f":{r.resource}" if r.resource else ""
            msg_lines.append(
                f"[gate] ignore rule expired on {r.expires}: "
                f"{r.check_id}{scope} (no longer suppressing)"
            )
    for line in msg_lines:
        click.echo(line, err=True)


# ────────────────────────────────────────────────────────────────────────────
# `init` subcommand, scaffold a starter config file.
# ────────────────────────────────────────────────────────────────────────────


@click.command(name="init")
@click.option(
    "--path",
    "target_path",
    default=".pipeline-check.yml",
    show_default=True,
    metavar="PATH",
    help="Write the scaffold to this path.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Overwrite the target file if it already exists.",
)
def init_cmd(target_path: str, force: bool) -> None:
    """Write a starter .pipeline-check.yml in the current directory.

    Pre-fills the ``pipeline:`` key when a supported CI file is
    detected in cwd. Refuses to overwrite unless ``--force`` is set.
    """
    from .core.init_template import render as _render_template
    if os.path.exists(target_path) and not force:
        raise click.UsageError(
            f"{target_path} already exists. Re-run with --force to overwrite."
        )
    detected = _detect_pipeline_from_cwd()
    try:
        with open(target_path, "w", encoding="utf-8") as fh:
            fh.write(_render_template(detected))
    except OSError as exc:
        raise click.UsageError(f"could not write {target_path}: {exc}") from exc
    suffix = (
        f" (pipeline: {detected})"
        if detected
        else " (no CI files detected, edit the 'pipeline:' line before use)"
    )
    click.echo(f"[init] wrote {target_path}{suffix}")


def main() -> None:
    """Console entry point: dispatches between ``scan`` and subcommands.

    Keeping the top-level command as ``scan`` preserves backward
    compatibility, every documented ``pipeline_check --flag ...``
    invocation keeps working. Subcommands are opt-in via a bare
    argv[1] match, so adding more later is cheap.
    """
    if len(sys.argv) >= 2 and sys.argv[1] == "init":
        sys.argv.pop(1)
        init_cmd()
        return
    scan()
