#!/usr/bin/env bash
# tests/sandbox-linux-port-e2e.sh — full Linux-port end-to-end harness.
#
# Run inside claude-sandbox or any disposable Linux container.
# DO NOT run on a host where you have real watchers installed —
# Stage 0 will scrub real PID files, real systemd units, and the
# `# convo-recall:*` lines from the user's crontab.
#
# Stages (each fails fast via `set -euo pipefail`):
#   0. clean-room: manual scrub of any prior convo-recall state
#   1. static guards: pytest full suite + pexpect wizard tests
#   2. detection sanity: detect_scheduler + auto wizard run
#   3. polling lifecycle: real Popen + PID file + idempotency + stale-PID + uninstall
#   4. systemd lifecycle: real .service + .path + REAL FILE-EVENT FIRING + uninstall
#   5. cron lifecycle: real crontab round-trip + USER-LINE PRESERVATION + uninstall
#   6. cross-tier uninstall: install polling, install cron, uninstall cleans both
#   7. argparse + bogus tier: --scheduler bogus exits non-zero
#   8. wheel install: build wheel, install in fresh venv, run from there
#   9. linger opt-in (semi-manual): wizard fires the linger question for systemd
#
# Stage failures print the captured context to make debugging possible
# without re-running. `[N] passed` on success.

set -euo pipefail

# ── DESTRUCTIVE-SCRIPT GUARD ─────────────────────────────────────────────────
# This script wipes convo-recall state to test from a clean slate. Refuse to
# run unless we're inside a sandbox: either a Docker container (has /.dockerenv)
# or an explicit CONVO_RECALL_SANDBOX=1 override. Without this guard, a typo
# like `bash tests/sandbox-test.sh` on the live host destroys real state.
if [[ ! -f /.dockerenv && "${CONVO_RECALL_SANDBOX:-}" != "1" ]]; then
    cat <<'WARN' >&2

🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥
☠️  DESTRUCTIVE SCRIPT — NOT INSIDE A SANDBOX  ☠️
🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥

This script wipes convo-recall state to test from a clean slate. It WILL:
  📁 Delete the conversation DB at \$CONVO_RECALL_DB
  ⚙️  Remove launchd / systemd / cron watchers
  🪝 Strip convo-recall hook entries from claude / codex / gemini settings
  💥 Kill any running embed sidecar

If you are NOT inside the claude-sandbox Docker container, you WILL lose
state on THIS host. There is NO undo.

To run anyway (e.g. you have a one-off VM you don't care about):
    CONVO_RECALL_SANDBOX=1 bash $0
WARN
    if [[ -t 0 ]]; then
        printf '\n⚠️  Type "YES" (uppercase) to proceed anyway, anything else to abort: ' >&2
        read -r _sandbox_guard_response
        if [[ "$_sandbox_guard_response" != "YES" ]]; then
            echo "" >&2
            echo "✅ Aborted. Nothing changed." >&2
            exit 0
        fi
    else
        echo "" >&2
        echo "✗ Refusing in non-interactive shell. Set CONVO_RECALL_SANDBOX=1 to override." >&2
        exit 1
    fi
fi


OS_NAME="$(uname -s)"
RECALL="$(command -v recall || true)"

if [[ -z "${RECALL}" ]]; then
    echo "FAILED: recall not on PATH; install with \`pip install -e .[dev]\`" >&2
    exit 1
fi

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Shell-side mirror of `_paths.ensure_xdg_runtime_dir`: populate
# XDG_RUNTIME_DIR if unset but the user bus is reachable. Without this,
# any direct `systemctl --user` call in this script (Stage 0 cleanup,
# Stage 4 systemd-user availability check, Stage 4 list-units) fails
# silently and we falsely skip systemd lifecycle testing.
if [[ "${OS_NAME}" == "Linux" ]] && [[ -z "${XDG_RUNTIME_DIR:-}" ]]; then
    _candidate="/run/user/$(id -u)"
    if [[ -e "${_candidate}/bus" ]]; then
        export XDG_RUNTIME_DIR="${_candidate}"
    fi
    unset _candidate
fi

# Resolve the runtime dir from the SAME logic the wizard uses (including
# the XDG-bus auto-detect added in `_paths.ensure_xdg_runtime_dir`). Ask
# Python directly so the script and the wizard never disagree on the
# PID-file location.
RT_DIR="$(python3 -c '
from convo_recall.install._paths import ensure_xdg_runtime_dir, runtime_dir
ensure_xdg_runtime_dir()
print(runtime_dir())
')"

# ─── Result recording ────────────────────────────────────────────────────────
#
# Each run appends one NDJSON line to tests/sandbox-results.ndjson so future
# runs have a benchmark. Format:
#   {"ts":"...","commit":"<sha>","os":"Linux","kernel":"...","python":"3.11.8",
#    "recall":"0.3.0","stages":[{"n":0,"name":"clean-room","outcome":"pass",
#    "duration_s":0.5},...],"total_duration_s":42.1,"failed_stage":null}

RESULTS_FILE="${REPO_ROOT}/tests/sandbox-results.ndjson"
RUN_LOG="$(mktemp)"   # accumulates per-stage JSON fragments
RUN_START="$(date +%s)"
GIT_SHA="$(git -C "${REPO_ROOT}" rev-parse --short HEAD 2>/dev/null || echo unknown)"
KERNEL="$(uname -r)"
PY_VER="$(python -c 'import sys; print(".".join(str(v) for v in sys.version_info[:3]))')"
RECALL_VER="$(${RECALL} --version 2>/dev/null | awk '{print $2}' || echo unknown)"
STAGE_START=0
STAGE="?"
STAGE_NAME="?"

stage() {
    STAGE="$1"
    STAGE_NAME="$2"
    STAGE_START="$(date +%s)"
    echo
    echo "──── Stage $1: $2 ────"
}

# Record the just-completed stage (called explicitly per outcome).
__record() {
    local outcome="$1"
    local end_ts
    end_ts="$(date +%s)"
    local dur=$((end_ts - STAGE_START))
    # Tab-separated fragments: stage_n, stage_name, outcome, duration_s.
    printf '%s\t%s\t%s\t%s\n' \
        "${STAGE}" "${STAGE_NAME}" "${outcome}" "${dur}" >> "${RUN_LOG}"
}

pass_stage() {
    __record pass
    echo "[${STAGE}] passed (${STAGE_NAME})"
}

skip_stage() {
    local reason="$1"
    __record skip
    echo "[${STAGE}] skipped (${reason})"
}

# Trap: if anything exits non-zero, record the in-flight stage as `fail`
# and write the run record to RESULTS_FILE before propagating the failure.
__write_results() {
    local exit_code=$?
    local total_dur
    total_dur=$(($(date +%s) - RUN_START))

    # If we were mid-stage on a non-zero exit, record it as `fail`.
    if [[ "${exit_code}" -ne 0 && "${STAGE}" != "?" ]]; then
        # Avoid double-recording if the stage already wrote a result.
        if ! awk -F'\t' -v s="${STAGE}" '$1==s{found=1} END{exit !found}' "${RUN_LOG}" 2>/dev/null; then
            __record fail
        fi
    fi

    # Build stages JSON array from RUN_LOG.
    local stages_json
    stages_json="$(awk -F'\t' '
        BEGIN{first=1; printf "["}
        {
            if (!first) printf ",";
            first=0;
            printf "{\"n\":%s,\"name\":\"%s\",\"outcome\":\"%s\",\"duration_s\":%s}",
                $1, $2, $3, $4
        }
        END{printf "]"}
    ' "${RUN_LOG}")"

    local failed_stage="null"
    if [[ "${exit_code}" -ne 0 && "${STAGE}" != "?" ]]; then
        failed_stage="\"${STAGE}:${STAGE_NAME}\""
    fi

    local ts
    ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

    mkdir -p "$(dirname "${RESULTS_FILE}")"
    printf '{"ts":"%s","commit":"%s","os":"%s","kernel":"%s","python":"%s","recall":"%s","stages":%s,"total_duration_s":%s,"failed_stage":%s}\n' \
        "${ts}" "${GIT_SHA}" "${OS_NAME}" "${KERNEL}" "${PY_VER}" \
        "${RECALL_VER}" "${stages_json}" "${total_dur}" "${failed_stage}" \
        >> "${RESULTS_FILE}"

    rm -f "${RUN_LOG}"

    # Print a benchmark comparison vs the prior run (if one exists).
    if [[ -f "${RESULTS_FILE}" ]]; then
        local n_runs
        n_runs="$(wc -l < "${RESULTS_FILE}" | tr -d ' ')"
        if [[ "${n_runs}" -ge 2 ]]; then
            echo
            echo "── Benchmark vs prior run ──"
            tail -2 "${RESULTS_FILE}" | python3 -c "
import json, sys
prev, curr = [json.loads(l) for l in sys.stdin if l.strip()]
def stages_by_n(r): return {s['n']: s for s in r['stages']}
p, c = stages_by_n(prev), stages_by_n(curr)
print(f'  prior:   {prev[\"ts\"]}  commit={prev[\"commit\"]}  total={prev[\"total_duration_s\"]}s')
print(f'  current: {curr[\"ts\"]}  commit={curr[\"commit\"]}  total={curr[\"total_duration_s\"]}s')
for n in sorted(set(p) | set(c)):
    ps = p.get(n, {}); cs = c.get(n, {})
    p_oc = ps.get('outcome', '—'); c_oc = cs.get('outcome', '—')
    p_d = ps.get('duration_s', 0); c_d = cs.get('duration_s', 0)
    delta = c_d - p_d
    name = cs.get('name', ps.get('name', '?'))
    arrow = ''
    if p_oc != c_oc: arrow = f'  ({p_oc} → {c_oc})'
    print(f'  [{n}] {name:<28}  prev={p_oc:<5}{p_d:>3}s   curr={c_oc:<5}{c_d:>3}s   Δ{delta:+d}s{arrow}')
" 2>/dev/null || true
        fi
    fi
}
trap __write_results EXIT

fail()  { echo "FAILED ($STAGE): $*" >&2; exit 1; }

# ─── Stage 0: clean-room ──────────────────────────────────────────────────────

STAGE=0
stage 0 "clean-room scrub (manual; no recall uninstall)"

# Polling: nuke any leftover PID files (both XDG and /tmp fallback paths).
rm -f "${RT_DIR}"/*.pid 2>/dev/null || true
rm -f "/tmp/convo-recall-$(id -u)"/*.pid 2>/dev/null || true
# Kill any orphan watchers from prior runs (matches our own argv).
if pgrep -f "recall watch" >/dev/null 2>&1; then
    pkill -TERM -f "recall watch" 2>/dev/null || true
    sleep 1
    pkill -KILL -f "recall watch" 2>/dev/null || true
fi

# Systemd: disable + remove any com.convo-recall.* units.
if [[ "${OS_NAME}" == "Linux" ]] && command -v systemctl >/dev/null 2>&1 \
        && systemctl --user is-system-running >/dev/null 2>&1; then
    systemctl --user disable --now 'com.convo-recall.*' 2>/dev/null || true
    rm -f "${HOME}/.config/systemd/user/com.convo-recall."* 2>/dev/null || true
    systemctl --user daemon-reload 2>/dev/null || true
fi

# Cron: surgical removal of `# convo-recall:*` lines, preserve the rest.
if command -v crontab >/dev/null 2>&1; then
    if crontab -l 2>/dev/null | grep -v 'convo-recall:' > /tmp/crontab.scrub.$$; then
        crontab /tmp/crontab.scrub.$$ 2>/dev/null || true
    fi
    rm -f /tmp/crontab.scrub.$$
fi

# Data dirs: nuke DB, config, sock so each stage starts from a known DB-empty state.
rm -rf "${HOME}/.local/share/convo-recall" 2>/dev/null || true
rm -rf "${HOME}/.config/convo-recall"       2>/dev/null || true

pass_stage

# ─── Stage 1: static guards ───────────────────────────────────────────────────

STAGE=1
stage 1 "static guards (pytest + pexpect)"

cd "${REPO_ROOT}"
# Full unit suite — first time these run on a real Linux interpreter.
if ! python -m pytest tests/ -q --ignore=tests/test_wheel_packaging.py >/tmp/pytest.out.$$ 2>&1; then
    echo "FAILED: full pytest suite did not pass on this host"
    tail -40 /tmp/pytest.out.$$
    rm -f /tmp/pytest.out.$$
    exit 1
fi
rm -f /tmp/pytest.out.$$

# pexpect wizard: 4 cases under the real terminal of this OS.
if ! python -m pytest tests/test_install_wizard.py -v >/tmp/pexpect.out.$$ 2>&1; then
    echo "FAILED: pexpect wizard tests did not pass on this host"
    tail -40 /tmp/pexpect.out.$$
    rm -f /tmp/pexpect.out.$$
    exit 1
fi
rm -f /tmp/pexpect.out.$$

pass_stage

# ─── Stage 2: detection sanity ────────────────────────────────────────────────

STAGE=2
stage 2 "detection sanity (detect_scheduler + auto wizard)"

picked="$(python -c \
    "from convo_recall.install.schedulers import detect_scheduler; print(type(detect_scheduler()).__name__)")"
case "${OS_NAME}" in
    Darwin)
        [[ "${picked}" == "LaunchdScheduler" ]] || \
            fail "auto-detect on macOS should pick LaunchdScheduler; got ${picked}"
        ;;
    Linux)
        case "${picked}" in
            SystemdUserScheduler|CronScheduler|PollingScheduler) ;;
            *) fail "auto-detect on Linux should pick systemd/cron/polling; got ${picked}";;
        esac
        ;;
esac

# Auto wizard run — must NOT halt with `_require_macos`.
out="$(${RECALL} install --dry-run -y 2>&1)"
echo "${out}" | grep -q "Selected scheduler:" || \
    fail "wizard didn't print 'Selected scheduler:'; output:\n${out}"

pass_stage

# ─── Stage 3: polling lifecycle (real Popen) ──────────────────────────────────

STAGE=3
stage 3 "polling lifecycle (real Popen)"

PID_FILE="${RT_DIR}/watch.pid"

# 3a. Install + verify alive.
${RECALL} install --scheduler polling -y >/dev/null
[[ -f "${PID_FILE}" ]] || fail "PID file ${PID_FILE} not created after install"
PID="$(cat "${PID_FILE}")"
kill -0 "${PID}" 2>/dev/null || fail "PID ${PID} not alive after install"
pgrep -f "recall watch" >/dev/null || fail "pgrep can't find recall watch (PID ${PID})"

# 3b. Idempotency: re-install must NOT spawn a 2nd watcher.
PID_BEFORE="${PID}"
${RECALL} install --scheduler polling -y >/dev/null
PID_AFTER="$(cat "${PID_FILE}")"
[[ "${PID_AFTER}" == "${PID_BEFORE}" ]] || \
    fail "second install changed PID ${PID_BEFORE} → ${PID_AFTER} (should be no-op)"
[[ "$(pgrep -fc 'recall watch')" -eq 1 ]] || \
    fail "second install spawned a duplicate watcher; pgrep count=$(pgrep -fc 'recall watch')"

# 3c. Uninstall + verify dead.
${RECALL} uninstall >/dev/null
for _ in 1 2 3 4 5 6 7 8 9 10; do
    kill -0 "${PID}" 2>/dev/null || break
    sleep 0.5
done
kill -0 "${PID}" 2>/dev/null && fail "PID ${PID} still alive 5s after uninstall"
[[ ! -f "${PID_FILE}" ]] || fail "PID file ${PID_FILE} still exists after uninstall"

# 3d. Stale-PID handling: pre-write a dead PID, install must overwrite cleanly.
mkdir -p "${RT_DIR}"
echo "99999" > "${PID_FILE}"
${RECALL} install --scheduler polling -y >/dev/null
NEW_PID="$(cat "${PID_FILE}")"
[[ "${NEW_PID}" != "99999" ]] || fail "stale PID 99999 not overwritten on install"
kill -0 "${NEW_PID}" 2>/dev/null || fail "new PID ${NEW_PID} not alive after stale-recovery install"

# 3e. Adversarial: kill the watcher externally, then uninstall must clean up.
kill -KILL "${NEW_PID}" 2>/dev/null || true
sleep 0.5
${RECALL} uninstall >/dev/null
[[ ! -f "${PID_FILE}" ]] || fail "uninstall did not remove PID file after externally-killed watcher"

pass_stage

# ─── Stage 4: systemd lifecycle (REAL file-event firing) ──────────────────────

STAGE=4
stage 4 "systemd lifecycle (real units + file-event firing)"

if [[ "${OS_NAME}" != "Linux" ]]; then
    skip_stage "non-Linux host"
elif ! systemctl --user is-system-running >/dev/null 2>&1; then
    skip_stage "systemd-user not available"
else
    UNIT_DIR="${HOME}/.config/systemd/user"

    ${RECALL} install --scheduler systemd -y >/dev/null

    # 4a. Per-agent unit files exist + verify.
    matched=0
    for agent in claude codex gemini; do
        SVC="${UNIT_DIR}/com.convo-recall.ingest.${agent}.service"
        PTH="${UNIT_DIR}/com.convo-recall.ingest.${agent}.path"
        if [[ -f "${SVC}" && -f "${PTH}" ]]; then
            matched=$((matched + 1))
            systemd-analyze verify "${SVC}" "${PTH}" 2>&1 \
                | tee /tmp/sd-analyze.$$ \
                | { ! grep -E '(error|warning)' >/dev/null; } \
                || { cat /tmp/sd-analyze.$$; rm -f /tmp/sd-analyze.$$; \
                     fail "systemd-analyze flagged ${SVC} or ${PTH}"; }
            rm -f /tmp/sd-analyze.$$
        fi
    done
    [[ "${matched}" -ge 1 ]] || fail "no systemd unit pairs created"

    # 4b. Path units must be loaded + active.
    if ! systemctl --user list-units --no-legend 'com.convo-recall.ingest.*.path' \
            | grep -q loaded; then
        systemctl --user list-units --no-legend 'com.convo-recall.*' || true
        fail "no com.convo-recall.ingest.*.path units loaded after install"
    fi

    # 4c. THE REAL VALIDATION: trigger a file event, confirm .service fires.
    # Pick the first agent that has a watcher and a watch dir we can write.
    fired_for=""
    for agent in claude codex gemini; do
        SVC="com.convo-recall.ingest.${agent}.service"
        # Read the WatchPath from the .path unit file (literal %h not expanded —
        # use the in-process path source instead).
        watch_dir="$(python -c "
from convo_recall.install import _AGENT_WATCH_DIRS
print(_AGENT_WATCH_DIRS[\"${agent}\"]())")"
        if [[ -z "${watch_dir}" ]] || [[ ! -d "${watch_dir}" ]]; then
            mkdir -p "${watch_dir}" 2>/dev/null || continue
        fi
        # Capture journal cursor before the trigger.
        journal_cursor="$(journalctl --user --show-cursor -n 0 2>/dev/null \
            | tail -1 | sed -n 's/.*-- cursor: //p')"
        # Touch a file in the watched dir.
        touch "${watch_dir}/sandbox-trigger-$$.jsonl"
        sleep 3
        # Has the .service unit logged anything since the cursor?
        if [[ -n "${journal_cursor}" ]]; then
            if journalctl --user --after-cursor "${journal_cursor}" -u "${SVC}" \
                    --no-pager 2>/dev/null | grep -E "${SVC}|recall ingest" >/dev/null; then
                fired_for="${agent}"
                break
            fi
        fi
        # Fallback: check if the unit's last-run timestamp is recent.
        last_active="$(systemctl --user show "${SVC}" -p ActiveEnterTimestamp \
            --value 2>/dev/null || true)"
        if [[ -n "${last_active}" && "${last_active}" != "n/a" ]]; then
            fired_for="${agent}"
            break
        fi
    done
    if [[ -z "${fired_for}" ]]; then
        echo "WARNING: file-event firing not observed within 3s — this can"
        echo "         happen on slow sandboxes. Inspecting unit state:"
        systemctl --user list-units --no-legend 'com.convo-recall.*' || true
        # Soft warn — don't fail the whole stage on timing.
        echo "         (treating as soft warning; not a fatal failure)"
    else
        echo "  ✓ file-event firing observed for ${fired_for}.service"
    fi

    # 4d. Uninstall.
    ${RECALL} uninstall >/dev/null
    if systemctl --user list-units --no-legend 'com.convo-recall.*' \
            | grep -q loaded; then
        systemctl --user list-units --no-legend 'com.convo-recall.*' || true
        fail "com.convo-recall.* unit still loaded after uninstall"
    fi
    # And the unit files should be gone. Use shell globbing instead of
    # `ls` — `ls "/path/com.convo-recall."*` exits non-zero when the
    # glob has no matches (the success case), tripping `set -e`.
    shopt -s nullglob
    leftovers=("${UNIT_DIR}"/com.convo-recall.*)
    shopt -u nullglob
    [[ "${#leftovers[@]}" -eq 0 ]] || \
        fail "leftover unit file(s) after uninstall: ${leftovers[*]}"

    pass_stage
fi

# ─── Stage 5: cron lifecycle (USER-LINE PRESERVATION) ─────────────────────────

STAGE=5
stage 5 "cron lifecycle (real crontab round-trip + user-line preservation)"

if ! command -v crontab >/dev/null 2>&1; then
    skip_stage "crontab not installed"
else
    # 5a. Pre-populate crontab with two distinct user lines.
    USER_LINE_PLAIN='0 * * * * echo hi'
    USER_LINE_SUBSTRING='0 * * * * touch /tmp/x  # user note about convo-recall'
    printf '%s\n%s\n' "${USER_LINE_PLAIN}" "${USER_LINE_SUBSTRING}" | crontab -

    # 5b. Install — both user lines preserved + tagged @reboot line at end.
    ${RECALL} install --scheduler cron -y >/dev/null
    after="$(crontab -l 2>/dev/null)"
    echo "${after}" | grep -qF "${USER_LINE_PLAIN}" || \
        fail "plain user line was lost after cron install:\n${after}"
    echo "${after}" | grep -qF "${USER_LINE_SUBSTRING}" || \
        fail "user line containing substring 'convo-recall' was wrongly removed:\n${after}"
    tag_count="$(echo "${after}" | grep -c 'convo-recall:watch' || true)"
    [[ "${tag_count}" -eq 1 ]] || \
        fail "expected exactly 1 'convo-recall:watch' line; got ${tag_count}:\n${after}"

    # 5c. Backup file exists + matches pre-install content.
    bak="$(ls -t "${RT_DIR}"/crontab.bak.* 2>/dev/null | head -1)"
    [[ -n "${bak}" ]] || fail "no crontab backup written under ${RT_DIR}"
    grep -qF "${USER_LINE_PLAIN}" "${bak}" || fail "backup ${bak} doesn't contain pre-install state"

    # 5d. Idempotency.
    ${RECALL} install --scheduler cron -y >/dev/null
    after2="$(crontab -l 2>/dev/null)"
    tag_count2="$(echo "${after2}" | grep -c 'convo-recall:watch' || true)"
    [[ "${tag_count2}" -eq 1 ]] || \
        fail "second install duplicated cron line; got ${tag_count2}"

    # 5e. Uninstall — tagged line gone, user lines preserved verbatim.
    ${RECALL} uninstall >/dev/null
    final="$(crontab -l 2>/dev/null)"
    echo "${final}" | grep -q 'convo-recall:watch' && \
        fail "tagged @reboot line still present after uninstall:\n${final}"
    echo "${final}" | grep -qF "${USER_LINE_PLAIN}" || \
        fail "uninstall removed the plain user line:\n${final}"
    echo "${final}" | grep -qF "${USER_LINE_SUBSTRING}" || \
        fail "uninstall removed user line with 'convo-recall' substring:\n${final}"

    # 5f. Reset crontab.
    crontab -r 2>/dev/null || true

    pass_stage
fi

# ─── Stage 6: cross-tier uninstall ────────────────────────────────────────────

STAGE=6
stage 6 "cross-tier uninstall (polling + cron together)"

if ! command -v crontab >/dev/null 2>&1; then
    skip_stage "no crontab; cron tier unavailable"
else
    crontab -r 2>/dev/null || true

    ${RECALL} install --scheduler polling -y >/dev/null
    ${RECALL} install --scheduler cron -y >/dev/null

    # Both should have left state.
    [[ -f "${RT_DIR}/watch.pid" ]] || fail "polling PID file missing before cross-tier uninstall"
    crontab -l 2>/dev/null | grep -q 'convo-recall:watch' \
        || fail "cron tagged line missing before cross-tier uninstall"

    ${RECALL} uninstall >/dev/null

    # Both gone.
    [[ ! -f "${RT_DIR}/watch.pid" ]] || \
        fail "uninstall left polling PID file behind"
    if crontab -l 2>/dev/null | grep -q 'convo-recall:watch'; then
        fail "uninstall left cron tagged line behind"
    fi

    pass_stage
fi

# ─── Stage 7: argparse + bogus tier ───────────────────────────────────────────

STAGE=7
stage 7 "argparse rejects unknown scheduler"

set +e
out="$(${RECALL} install --scheduler bogus --dry-run -y 2>&1)"
rc=$?
set -e
[[ "${rc}" -ne 0 ]] || fail "bogus scheduler should exit non-zero; got rc=${rc}"
for name in auto launchd systemd cron polling; do
    echo "${out}" | grep -q "${name}" || \
        fail "argparse error should list '${name}' in choices; got:\n${out}"
done
pass_stage

# ─── Stage 8: wheel install (catches Hatch packaging gaps) ────────────────────

STAGE=8
stage 8 "wheel build + install in fresh venv"

if ! python -c "import build" 2>/dev/null; then
    skip_stage "\`pip install build\` to enable"
else
    cd "${REPO_ROOT}"
    # Stage 8 stays inside REPO_ROOT — sandboxes / containers often mount
    # /tmp as noexec, which breaks venv binary execution.
    WHEEL_DIR="${REPO_ROOT}/.cr-wheel.$$"
    VENV_DIR="${REPO_ROOT}/.cr-venv.$$"
    BUILD_LOG="${REPO_ROOT}/.cr-build.$$.log"
    RUN_LOG_W="${REPO_ROOT}/.cr-run.$$.log"

    find "${WHEEL_DIR}" -mindepth 1 -delete 2>/dev/null || true
    find "${VENV_DIR}"  -mindepth 1 -delete 2>/dev/null || true
    rmdir "${WHEEL_DIR}" "${VENV_DIR}" 2>/dev/null || true

    python -m build --wheel --outdir "${WHEEL_DIR}" >"${BUILD_LOG}" 2>&1 \
        || { tail -30 "${BUILD_LOG}"; rm -f "${BUILD_LOG}"; \
             fail "python -m build --wheel failed"; }
    rm -f "${BUILD_LOG}"

    python -m venv "${VENV_DIR}"
    "${VENV_DIR}/bin/pip" install --quiet "${WHEEL_DIR}"/convo_recall-*.whl

    "${VENV_DIR}/bin/recall" install --dry-run -y --scheduler polling \
        > "${RUN_LOG_W}" 2>&1 \
        || { tail -30 "${RUN_LOG_W}"; \
             fail "wheel-installed recall failed"; }
    grep -q "polling (Popen fallback)" "${RUN_LOG_W}" \
        || fail "wheel-installed recall didn't pick polling"

    find "${WHEEL_DIR}" -mindepth 1 -delete 2>/dev/null || true
    find "${VENV_DIR}"  -mindepth 1 -delete 2>/dev/null || true
    rmdir "${WHEEL_DIR}" "${VENV_DIR}" 2>/dev/null || true
    rm -f "${RUN_LOG_W}"

    pass_stage
fi

# ─── Stage 9: linger opt-in (semi-manual) ─────────────────────────────────────

STAGE=9
stage 9 "linger question fires for systemd path"

if [[ "${OS_NAME}" != "Linux" ]]; then
    skip_stage "non-Linux host"
elif ! command -v expect >/dev/null 2>&1 \
        && ! python -c "import pexpect" 2>/dev/null; then
    skip_stage "no expect/pexpect available"
else
    # Drive the wizard interactively under --scheduler systemd, look for the
    # linger prompt explicitly. We don't actually call enable-linger (skips
    # polkit/sudo), just verify the question fires.
    output="$(python - <<'PY'
import shutil, sys
import pexpect
recall = shutil.which("recall")
# --dry-run so we don't actually call enable-linger / mutate systemd.
w = pexpect.spawn(recall, ["install", "--scheduler", "systemd", "--dry-run"],
                  encoding="utf-8", timeout=10)
saw_linger = False
saw_watchers_question = False
try:
    while True:
        idx = w.expect([
            r"Keep watchers running when logged out",
            r"Install systemd --user \(Linux\) watchers",
            r"\[Y/n\]",
            pexpect.EOF,
        ], timeout=15)
        if idx == 0:
            # Linger fired — that's all we needed to prove. Decline + drain.
            saw_linger = True
            w.expect(r"\[Y/n\]")
            w.sendline("n")
            # Drain remaining prompts.
            while True:
                idx2 = w.expect([r"\[Y/n\]", pexpect.EOF], timeout=15)
                if idx2 == 0:
                    w.sendline("n")
                else:
                    break
            break
        elif idx == 1:
            # Watchers question — accept so linger gets a chance to fire.
            saw_watchers_question = True
            w.expect(r"\[Y/n\]")
            w.sendline("y")
        elif idx == 2:
            # Some other [Y/n] before watchers question — accept and continue.
            w.sendline("y")
        else:
            break
finally:
    w.close()
print("LINGER_QUESTION_FIRED" if saw_linger else "LINGER_QUESTION_MISSING",
      f"(watchers_q_seen={saw_watchers_question})")
PY
)"
    echo "${output}" | grep -q LINGER_QUESTION_FIRED \
        || fail "linger question did not fire under --scheduler systemd"
    pass_stage
fi

# ─── Stage 10: full-feature e2e (sandbox-e2e-full.sh) ─────────────────────────
#
# Existing 13-section script covering sidecar / agent detection / config /
# ingest / re-ingest / per-agent ingest / legacy migration / search flag
# matrix / cwd auto-scope / stats / backfills / watch loop / FTS-only.
#
# Was orphaned (never wired into a runner) — wires up now. Skips
# gracefully if the embed sidecar's UDS isn't reachable (Stage 1 of that
# script asserts it, so a missing sock just means we can't run this).

STAGE=10
stage 10 "full-feature e2e (search/ingest/stats/watch surface)"

if [[ ! -S "${CONVO_RECALL_SOCK:-/tmp/convo-recall/embed.sock}" ]]; then
    skip_stage "embed sidecar not running (set CONVO_RECALL_SOCK or run 'recall serve' first)"
else
    # Derive VENV from the resolved recall binary so this works regardless
    # of whether the venv lives inside the repo (default in sandbox-e2e-
    # full.sh) or alongside it (current claude-sandbox layout).
    _venv_dir="$(dirname "$(dirname "${RECALL}")")"
    if ! REPO_ROOT="${REPO_ROOT}" VENV="${_venv_dir}" \
            bash "${REPO_ROOT}/tests/sandbox-e2e-full.sh" \
            >/tmp/cr-full.$$.log 2>&1; then
        tail -60 /tmp/cr-full.$$.log >&2
        rm -f /tmp/cr-full.$$.log
        fail "sandbox-e2e-full.sh failed — see tail above"
    fi
    rm -f /tmp/cr-full.$$.log
    pass_stage
fi

# ─── Stage 11: hook integration e2e (sandbox-hooks-e2e.sh) ───────────────────
#
# Existing 4-section script: hook script smoke + Claude/Codex/Gemini
# wiring + model-receives-injected-context end-to-end probe. The model
# checks (4/4) need real API creds for at least one CLI; the script
# already skips per-CLI when creds are absent.

STAGE=11
stage 11 "hook integration (Claude/Codex/Gemini)"

if ! bash "${REPO_ROOT}/tests/sandbox-hooks-e2e.sh" >/tmp/cr-hooks.$$.log 2>&1; then
    tail -40 /tmp/cr-hooks.$$.log >&2
    rm -f /tmp/cr-hooks.$$.log
    fail "sandbox-hooks-e2e.sh failed — see tail above"
else
    rm -f /tmp/cr-hooks.$$.log
    pass_stage
fi

# ─── Stage 12: adversarial-input regression for F-1 / F-9 / F-10 ─────────────
#
# Three real bugs caught by real agent sessions. These specific failure
# modes are unit-tested too, but a stage-level test exercises the full
# CLI surface — the only way to prove the fixes survive future
# refactors that touch the actual `recall` invocation path.

STAGE=12
stage 12 "adversarial-input regression (F-1 / F-9 / F-10)"

# 12a — F-1: hyphenated cwd auto-scope. cd into a hyphenated dir and
# verify search returns hits (not zero) for content that's in the DB.
HYPHEN_DIR="/tmp/Projects/app-claude"
mkdir -p "${HYPHEN_DIR}"
hyphen_out=$(cd "${HYPHEN_DIR}" && "${RECALL}" search "the" -n 5 -c 0 2>&1 || true)
if echo "${hyphen_out}" | grep -q "No messages found for project"; then
    # Acceptable IF the DB legitimately has no rows under that slug. Check
    # for the did-you-mean hint, which would surface if the slug is wrong.
    if echo "${hyphen_out}" | grep -q "Did you mean"; then
        fail "F-1 regression: hyphenated cwd produced 0 results AND did-you-mean hint, slug mismatch is back"
    fi
    echo "  · F-1: no rows under app_claude in this sandbox (legitimate)"
fi
# Either way, no traceback should occur.
echo "${hyphen_out}" | grep -q "Traceback" && fail "F-1 regression: traceback on hyphenated cwd search"

# 12b — F-9: FTS5-special-char queries shouldn't crash.
for q in "app-gemini" ".*" "url:https" "(query)" "AND OR NOT" "foo*bar"; do
    out=$("${RECALL}" search "${q}" --all-projects -n 3 -c 0 2>&1 || true)
    if echo "${out}" | grep -qE "syntax error|no such column|apsw\."; then
        echo "${out}" >&2
        fail "F-9 regression: query ${q@Q} crashed FTS5"
    fi
done

# 12c — F-10: chmod the DB parent read-only, search should fall back
# gracefully to read-only mode with a warning, not a traceback.
DB_DIR="$(dirname "$("${PY:-python3}" -c '
from convo_recall.ingest import DB_PATH
print(DB_PATH)
' 2>/dev/null || echo /root/.local/share/convo-recall/conversations.db)")"
if [[ -d "${DB_DIR}" ]]; then
    saved_perms=$(stat -c %a "${DB_DIR}" 2>/dev/null || stat -f %p "${DB_DIR}" | tail -c 4)
    chmod 0500 "${DB_DIR}"
    sandbox_out=$("${RECALL}" search "anything" --all-projects -n 3 -c 0 2>&1 || true)
    chmod "${saved_perms}" "${DB_DIR}" 2>/dev/null || chmod 0700 "${DB_DIR}"
    if echo "${sandbox_out}" | grep -q "Traceback"; then
        echo "${sandbox_out}" >&2
        fail "F-10 regression: sandboxed env triggered traceback"
    fi
    if ! echo "${sandbox_out}" | grep -q "DB write access denied"; then
        # Only enforce the warning when it actually had to fall back. On
        # macOS host running as the owner, chmod 0500 doesn't always
        # block apsw; if WAL succeeded, no warning expected.
        echo "  · F-10: WAL succeeded under chmod 0500 (host kernel may not enforce)"
    fi
else
    echo "  · F-10: DB dir not found, skipping chmod check"
fi

pass_stage

echo
echo "════════════════════════════════════════════════════════════"
echo "All stages passed."
echo "════════════════════════════════════════════════════════════"
