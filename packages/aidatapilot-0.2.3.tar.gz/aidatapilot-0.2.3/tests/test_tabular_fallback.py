import pandas as pd

from aidatapilot.processors.steps import chunk_text


def test_tabular_fallback():
    # Dataset with NO text/description columns
    data = {
        "id": [501, 502],
        "name": ["Super Widget", "Mega Tool"],
        "price": [19.99, 45.0],
        "status": ["active", "discontinued"]
    }
    df = pd.DataFrame(data)
    
    # Run chunking on a non-existent column to trigger the "fallback"
    # The engine should detect that there's no 'content' and generate 
    # a summary-based chunk instead.
    print("\n--- Testing Tabular-to-Text Fallback ---")
    result = chunk_text(df, column="content")
    
    print(f"Number of rows processed: {len(df)}")
    print(f"Number of chunks generated: {len(result)}")
    
    for i, row in result.iterrows():
        print(f"\nChunk {i+1} (Source: {row['source']}):")
        print(f"Filename: {row['chunk_filename']}")
        print(f"Content: {row['chunk']}")
        assert "Context:" in row["chunk"]
        assert row["source"] in row["chunk"]

if __name__ == "__main__":
    test_tabular_fallback()
