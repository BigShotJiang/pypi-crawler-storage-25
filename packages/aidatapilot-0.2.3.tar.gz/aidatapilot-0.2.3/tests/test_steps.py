import pandas as pd

from aidatapilot.processors.steps import (
    deduplicate,
    fill_nulls,
    normalize_columns,
    remove_nulls,
    type_cast,
)


def test_normalize_columns():
    df = pd.DataFrame({"  First Name  ": [1], "last-name": [2], "Age!": [3]})
    ndf = normalize_columns(df)
    assert list(ndf.columns) == ["first_name", "last_name", "age"]

def test_remove_nulls():
    df = pd.DataFrame({
        "A": [1, None, None],
        "B": [1, 2, None]
    })
    # threshold 0.5: Row 0 (0% null), Row 1 (50% null), Row 2 (100% null)
    res = remove_nulls(df, threshold=0.5)
    assert len(res) == 2

def test_fill_nulls():
    df = pd.DataFrame({"A": [1, None, 3]})
    res = fill_nulls(df, strategy="mean")
    assert res["A"].iloc[1] == 2.0

def test_type_cast():
    df = pd.DataFrame({"A": ["1", "2", "3"]})
    res = type_cast(df, columns={"A": "int"})
    assert res["A"].dtype == "Int64"

def test_deduplicate():
    df = pd.DataFrame({"A": [1, 1, 2], "B": [1, 1, 3]})
    res = deduplicate(df)
    assert len(res) == 2

