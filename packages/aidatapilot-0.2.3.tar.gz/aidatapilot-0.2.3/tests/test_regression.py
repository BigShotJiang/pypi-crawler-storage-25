import os

import pandas as pd
import pytest

from aidatapilot import Pipeline


@pytest.fixture
def example_csv():
    """Ensure we have an example CSV to test with."""
    path = "examples/MESS.csv"
    # Always create/recreate the fixture data to ensure consistency
    df = pd.DataFrame({
        "First Name": ["John", " Jane ", "Doe"],
        "Price": ["$20", "40", "free"],
        "Join Date": ["2023.01.01", "2023/02/02", "None"]
    })
    os.makedirs("examples", exist_ok=True)
    df.to_csv(path, index=False)
    return path

def test_pipeline_output_integrity(example_csv):
    """Verify that a standard cleaning pipeline maintains expected behavior."""
    pipeline = Pipeline(template="basic_clean")
    pipeline.set_source(example_csv)
    pipeline.set_output(type="memory")
    
    result = pipeline.run()
    assert result.success is True
    
    df = result.df
    # Check normalized headers
    assert "first_name" in df.columns
    assert "price" in df.columns
    assert "join_date" in df.columns
    
    # Check cleaning results
    assert df["first_name"].iloc[1] == "Jane" 
    # v0.2.0 numeric parser: 'free' remains 'free' unless it's detected as numeric.
    # If the column is typed as numeric, 'free' becomes NaN/0.0.
    # In 'basic_clean', infer_types detects this column as numeric.
    assert float(df["price"].iloc[0]) == 20.0
    assert float(df["price"].iloc[2]) == 0.0

def test_chunking_output_structure():
    """Verify that chunk_text produces the exact expected format."""
    df = pd.DataFrame({
        "Name": ["Product A"],
        "Description": ["Short text for chunk test."]
    })
    
    pipeline = Pipeline(steps=[
        {"name": "chunk_text", "params": {"column": "Description", "chunk_size": 500}}
    ])
    
    result = pipeline.run(df=df)
    assert result.success is True
    
    # Structure match check
    expected_cols = ["row_id", "source", "context", "chunk", "chunk_index", "chunk_filename"]
    assert all(c in result.df.columns for c in expected_cols)
    assert len(result.df) == 1
    # Check the header contains the key info
    chunk = result.df["chunk"].iloc[0]
    assert "Product A" in chunk
    assert "Short text" in chunk

def test_tabular_to_text_fallback():
    """Verify that datasets without text columns are still chunked into summaries."""
    df = pd.DataFrame({
        "SKU": ["A1"],
        "Qty": [10]
    })
    
    pipeline = Pipeline(steps=[
        {"name": "chunk_text", "params": {"column": "non_existent"}}
    ])
    
    result = pipeline.run(df=df)
    assert result.success is True
    assert len(result.df) == 1
    # The header for fallback contains SKU and Qty info (may be wrapped in context)
    chunk = result.df["chunk"].iloc[0]
    assert "Sku is A1" in chunk
    assert "Qty is 10" in chunk
