from pathlib import Path

import pandas as pd

from aidatapilot.core.pipeline import Pipeline


def test_pipeline_basic_clean(tmp_path):
    # Create a dummy CSV
    csv_path = tmp_path / "test.csv"
    out_path = tmp_path / "out.csv"
    
    df = pd.DataFrame({
        "  Name  ": ["Alice", "Bob", None, "Alice"],
        "AGE": [25, 30, 35, 25],
        "city": ["NY", "SF", "NY", "SF"]
    })
    df.to_csv(csv_path, index=False)
    
    # Run pipeline with basic_clean template
    pipe = Pipeline(template="basic_clean")
    pipe.set_source(path=str(csv_path))
    pipe.set_output(path=str(out_path))
    result = pipe.run()
    
    assert result.success
    assert result.rows_in == 4
    # basic_clean: normalize (cols), remove_nulls (Alice, Bob, Alice), deduplicate (Alice, Bob)
    # Wait, remove_nulls threshold is 0.5. Alice has 0 nulls. Bob has 0. None has 1/3 (0.33) nulls. 
    # So all 4 rows pass remove_nulls.
    # Then deduplicate: Alice/25/NY is repeated? No, City is different.
    # Alice/25/NY and Alice/25/SF are unique.
    # Actually wait:
    # 0: Alice, 25, NY
    # 1: Bob, 30, SF
    # 2: None, 35, NY
    # 3: Alice, 25, SF
    # None of them are exact duplicates.
    assert result.rows_out == 4
    assert Path(out_path).exists()
    
    # Verify result content
    out_df = pd.read_csv(out_path)
    assert "name" in out_df.columns
    assert "age" in out_df.columns
    assert "city" in out_df.columns

def test_pipeline_explicit_steps(tmp_path):
    csv_path = tmp_path / "test.csv"
    out_path = tmp_path / "out.csv"
    pd.DataFrame({"A": [1, 1], "B": [2, 2]}).to_csv(csv_path, index=False)
    
    pipe = Pipeline(steps=["normalize_columns", "deduplicate"])
    pipe.set_source(path=str(csv_path))
    pipe.set_output(path=str(out_path))
    result = pipe.run()
    
    assert result.success
    assert result.rows_out == 1

