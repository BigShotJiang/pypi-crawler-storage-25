import pandas as pd
import pytest

from aidatapilot.processors.steps import chunk_text


def test_context_aware_chunking():
    data = {
        "id": [1],
        "name": ["Test Doc"],
        "content": ["Sentence one. Sentence two. Sentence three. Sentence four."],
        "category": ["Tests"]
    }
    df = pd.DataFrame(data)
    
    # Use a small chunk size to trigger multi-chunking
    # "Sentence one. " is 14 chars. 
    # "Sentence two. " is 14 chars.
    # Total ~60 chars.
    result = chunk_text(df, column="content", chunk_size=30, chunk_overlap=10)
    
    assert len(result) > 1
    assert "row_id" in result.columns
    assert "context" in result.columns
    assert "source" in result.columns
    assert "chunk" in result.columns
    
    # Check context contains category and name
    context = result.iloc[0]["context"]
    assert "id: 1" in context
    assert "name: Test Doc" in context
    assert "category: Tests" in context
    
    # Check source
    assert result.iloc[0]["source"] == "Test Doc"
    
    # Check filename
    assert "test_doc_chunk_1.txt" in result.iloc[0]["chunk_filename"]

def test_sentence_aware_splitting():
    text = "Machine Learning is fun. Data Science is hard. NLP is cool."
    data = {"content": [text], "name": ["AI"]}
    df = pd.DataFrame(data)
    
    # Chunk size 25 should hit "Machine Learning is fun. " (25 chars)
    # If it's character based, it might cut at ". " or "D"
    # With sentence awareness, it should ideally cut after the period.
    result = chunk_text(df, column="content", chunk_size=25, chunk_overlap=5)
    
    # The enriched chunk now contains context summary + raw text
    chunk1 = result.iloc[0]["chunk"]
    assert "Machine Learning is fun." in chunk1
    assert "Context:" in chunk1
    # Second chunk contains "Data Science"
    assert "Data Science" in result.iloc[1]["chunk"]

def test_empty_text_handling():
    data = {
        "content": ["", "   ", None, "Valid text"],
        "name": ["A", "B", "C", "D"]
    }
    df = pd.DataFrame(data)
    result = chunk_text(df, column="content")
    
    # In v0.2.0, even empty/null rows generate a "tabular summary" chunk
    # There are 4 rows in data, so we should have 4 chunks
    assert len(result) == 4
    # The first 3 should be "summary" chunks
    assert "summary" in result.iloc[0]["chunk_filename"]
    assert "summary" in result.iloc[1]["chunk_filename"]
    assert "summary" in result.iloc[2]["chunk_filename"]
    # The 4th should be the "Valid text" chunk
    assert "Valid text" in result.iloc[3]["chunk"]
    assert result.iloc[3]["source"] == "D"

if __name__ == "__main__":
    # Run tests if executed directly
    pytest.main([__file__])
