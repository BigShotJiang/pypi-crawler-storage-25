import pandas as pd

from aidatapilot.processors.steps import infer_types


def test_extract_numeric_from_text():
    df = pd.DataFrame({
        "mixed": ["12 apples", "price: 50.5", "weight 100kg", "abc"]
    })
    res = infer_types(df)
    # abc should become 0.0, others extracted
    assert res["mixed"].iloc[0] == 12.0
    assert res["mixed"].iloc[1] == 50.5
    assert res["mixed"].iloc[2] == 100.0
    assert res["mixed"].iloc[3] == 0.0

def test_currency_removal():
    df = pd.DataFrame({
        "price": ["$400", "₹500", "€10.50", "£20"]
    })
    res = infer_types(df)
    assert res["price"].iloc[0] == 400.0
    assert res["price"].iloc[1] == 500.0
    assert res["price"].iloc[2] == 10.5
    assert res["price"].iloc[3] == 20.0

def test_text_numbers_to_int():
    df = pd.DataFrame({
        "text_num": ["four hundred", "twelve", "one thousand", "zero"]
    })
    res = infer_types(df)
    assert res["text_num"].iloc[0] == 400
    assert res["text_num"].iloc[1] == 12
    assert res["text_num"].iloc[2] == 1000
    assert res["text_num"].iloc[3] == 0
    assert res["text_num"].dtype == "Int64"

def test_composite_text_numbers():
    df = pd.DataFrame({
        "text_num": ["twenty five", "two thousand five hundred"]
    })
    res = infer_types(df)
    assert res["text_num"].iloc[0] == 25
    assert res["text_num"].iloc[1] == 2500
