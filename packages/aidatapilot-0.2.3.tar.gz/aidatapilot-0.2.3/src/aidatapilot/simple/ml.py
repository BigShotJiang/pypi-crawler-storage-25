"""
aidatapilot ML Preprocessing Facade
--------------------------------
High-power preparation for machine learning models.
"""

from typing import Optional, Union

import pandas as pd

from aidatapilot.core.api import bootstrap
from aidatapilot.core.pipeline import Pipeline, PipelineResult


def auto_ml_prep(
    source: Union[str, pd.DataFrame], 
    output: Optional[str] = None, 
    **kwargs
) -> PipelineResult:
    """
    Standard Machine Learning Preprocessing Pipeline.
    
    Independently handles:
    - Normalization & Type Inference
    - Intelligent Imputation (Grouping-aware)
    - Outlier Segregation (Preservation at bottom)
    - Categorical Encoding & Scaling
    """
    # Trigger self-registration
    bootstrap()
    
    # Initialize a dedicated ML pipeline
    # Custom steps can still be passed via kwargs
    custom_steps = kwargs.pop("steps", None)
    pipe = Pipeline(
        template="ml_preprocess", 
        steps=custom_steps, 
        step_params=kwargs
    )
    
    # Configure source
    if isinstance(source, pd.DataFrame):
        pipe.set_source(df=source)
    else:
        pipe.set_source(type="file", path=str(source))
        
    # Configure output
    if output:
        pipe.set_output(type="file", path=str(output))
    else:
        pipe.set_output(None)
        
    return pipe.run()

