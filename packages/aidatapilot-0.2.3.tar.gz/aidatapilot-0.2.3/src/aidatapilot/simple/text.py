"""
aidatapilot Text & LLM Facade
---------------------------
Specialized one-liners for preparing documents for RAG and LLM workflows.
"""

from aidatapilot.core.api import auto_clean as _core_clean


def auto_text_prep(source, output=None, text_columns=None, primary_column=None, **kwargs):
    """
    Automated text cleaning and chunking pipeline in one line.
    If primary_column is not provided, it will be auto-detected (Description, Content, etc.).
    """
    params = {
        "text_columns": text_columns or [],
        "primary_column": primary_column, # This will be resolved by the step if None
        **kwargs
    }
    return _core_clean(source, output, template="llm_processing", **params)
