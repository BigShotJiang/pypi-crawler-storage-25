"""
AIDataPilot Simple API (Facade)
-------------------------------
One-line solutions for common data tasks.
"""

from __future__ import annotations
import pandas as pd
from typing import Union, Optional, List, Any, Dict

# Standardized absolute imports from the core engine
from aidatapilot.core.pipeline import Pipeline, PipelineResult

def auto_clean(
    source: Optional[Union[str, pd.DataFrame]] = None, 
    output: Optional[str] = None, 
    template: str = "basic_clean",
    **kwargs
) -> PipelineResult:
    """
    Clean a dataset in one line.
    
    Args:
        source: CSV path or DataFrame
        output: Optional path to save cleaned CSV
        template: Cleaning template to use (default: 'basic_clean')
    """
    from aidatapilot.core.api import auto_clean as _core_clean
    source = source or kwargs.pop("input", None)
    if source is None:
        raise TypeError("auto_clean() missing 1 required positional argument: 'source'")
    return _core_clean(source, output, template=template, **kwargs)

def auto_ml_prep(
    data: Union[str, pd.DataFrame], 
    target: Optional[str] = None,
    output: Optional[str] = None
) -> PipelineResult:
    """Prepare a dataset for Machine Learning in one step.
    
    Handles nulls, categorical encoding, and numeric scaling while 
    preserving the target labels.
    """
    # 1. Load data to detect target if not provided
    temp_pipeline = Pipeline()
    df_temp = temp_pipeline._load_data(data)
    
    # 2. Heuristic Target Detection
    if target is None:
        target_candidates = ["target", "label", "y", "status", "class"]
        for c in df_temp.columns:
            if c.lower() in target_candidates:
                target = c
                break
    
    # 3. Construct and Run Pipeline
    pipeline = Pipeline(template="ml_preprocess", target=target)
    
    # Correctly set output path
    if output:
        pipeline.set_output(path=output)
    else:
        pipeline.set_output(None)
        
    # Pass the loaded data to run
    return pipeline.run(df=df_temp)

def auto_pilot(source: Union[str, pd.DataFrame], output: Optional[str] = None, **kwargs) -> PipelineResult:
    """
    Fully autonomous cleaning with smart template detection.
    
    Args:
        source: CSV path or DataFrame
        output: Optional path to save result
    """
    from aidatapilot.core.api import auto_pilot as _core_pilot
    return _core_pilot(source, output, **kwargs)

def translate(
    data: Union[str, List[str], pd.DataFrame],
    target_lang: str = "en",
    source_lang: str = "auto",
    columns: Optional[List[str]] = None
) -> Union[str, List[str], pd.DataFrame]:
    """
    Translate text using the AIDataPilot Universal Engine.
    
    Args:
        data: String, List of Strings, or DataFrame to translate.
        target_lang: Destination language (ISO code).
        source_lang: Source language (ISO code, 'auto' for detection).
        columns: List of columns to translate (if data is a DataFrame).
    """
    from aidatapilot.core.api import translate_text
    return translate_text(data, target_lang=target_lang, source_lang=source_lang, columns=columns)

def auto_text_prep(
    source: Optional[Union[str, pd.DataFrame]] = None, 
    output: Optional[str] = None, 
    **kwargs
) -> PipelineResult:
    """
    Prepare documents for LLMs and RAG in one step.
    Usage: auto_text_prep("input.csv", "output.csv")
    """
    from aidatapilot.simple.text import auto_text_prep as _text_prep
    source = source or kwargs.pop("input", None)
    if source is None:
        raise TypeError("auto_text_prep() missing 1 required positional argument: 'source'")
    return _text_prep(source, output, **kwargs)
