"""
AIDataPilot Enriched Analytics Facade
------------------------------------
Tailored BI Insights and Professional reporting.
"""

from __future__ import annotations
import pandas as pd
from typing import Union, Optional, List, Any, Dict
from dataclasses import dataclass, field

# Standard package imports
from aidatapilot.core.api import auto_clean as _core_clean
from aidatapilot.discovery.analyzer import AdvancedAnalyzer
from aidatapilot.discovery.visualizer import HealthVisualizer

@dataclass
class DiscoveryResult:
    """Consolidated Analytical Result."""
    df: pd.DataFrame
    health_score: int
    insights: List[str]
    profiles: Dict[str, Any]
    report_path: Optional[str] = None

    def __repr__(self):
        status = "EXCELLENT" if self.health_score > 85 else ("GOOD" if self.health_score > 60 else "NEEDS WORK")
        return f"DiscoveryResult(Score: {self.health_score}/100 | Status: {status})"

def auto_analytics(
    source: Union[str, pd.DataFrame], 
    output: Optional[str] = None, 
    generate_report: bool = True,
    **kwargs
) -> DiscoveryResult:
    """Enriched BI Pipeline: Cleans, profiles, and visualizes insights."""
    # 1. Standard Cleaning & Formatting
    clean_result = _core_clean(source, output, template="analytics_cleaning", **kwargs)
    df = clean_result.df
    
    # 2. Advanced Analytical Discovery
    analyzer = AdvancedAnalyzer(df)
    profiles = analyzer.profile()
    
    # 3. Visual Health Report Generation
    report_path = None
    if generate_report:
        visualizer = HealthVisualizer(df)
        report_name = f"{output}_health_report.png" if output else "analytics_health_report.png"
        report_path = visualizer.generate_report(profiles["health_score"], save_path=report_name)
        
    return DiscoveryResult(
        df=df,
        health_score=profiles["health_score"],
        insights=profiles["insights"],
        profiles=profiles,
        report_path=report_path
    )
