"""
aidatapilot — Lightweight Intelligent Data Automation Engine
==========================================================

The simplest way to automate your data pipelines.

Quick start::

    from aidatapilot import auto_clean
    auto_clean("data.csv", "clean_data.csv")

Or use the Pipeline class::

    from aidatapilot import Pipeline

    pipe = Pipeline(template="analytics_cleaning")
    pipe.set_source(type="file", path="data.csv")
    pipe.set_output(type="file", path="clean.csv")
    pipe.run()
"""

# Version 
from aidatapilot.version import __version__

# Intelligence Advisor 
from aidatapilot.intelligence.advisor import Advisor
from aidatapilot.core.api import analyze_dataset

# Core Engine 
from aidatapilot.core.pipeline import Pipeline, PipelineResult
from aidatapilot.simple.analytics import auto_analytics

# Simplified API (The Public Facade)
from aidatapilot.simple.auto import (
    auto_clean, 
    auto_pilot, 
    auto_ml_prep, 
    auto_text_prep, 
    translate
)

__all__ = [
    "Advisor",
    "Pipeline",
    "PipelineResult",
    "__version__",
    "analyze_dataset",
    "auto_analytics",
    "auto_clean",
    "auto_ml_prep",
    "auto_pilot",
    "auto_text_prep",
    "translate",
]
