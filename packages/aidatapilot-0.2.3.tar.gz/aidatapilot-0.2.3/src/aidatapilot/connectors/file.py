"""
File Connector
--------------
Reads CSV and JSON files into a pandas DataFrame.
Auto-detects format from file extension.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import pandas as pd

from aidatapilot.connectors.base import BaseConnector
from aidatapilot.core.registry import ConnectorRegistry


class FileConnector(BaseConnector):
    """Read data from local CSV or JSON files.

    Args:
        path: Path to the source file.
        encoding: File encoding. Default ``"utf-8"``.
        **read_kwargs: Extra kwargs forwarded to ``pd.read_csv`` / ``pd.read_json``.

    Example::

        connector = FileConnector(path="data.csv")
        connector.connect()
        df = connector.read()
        connector.close()
    """

    SUPPORTED_EXTENSIONS = {".csv", ".json", ".jsonl", ".xlsx", ".xls", ".parquet", ".txt", ".pdf", ".docx", ".doc"}

    def __init__(
        self,
        path: str,
        encoding: str = "utf-8",
        **read_kwargs,
    ) -> None:
        self._path = Path(path)
        self._encoding = encoding
        self._read_kwargs = read_kwargs
        self._df: Optional[pd.DataFrame] = None

    def connect(self) -> FileConnector:
        """Validate the file exists and has a supported extension."""
        if not self._path.exists():
            raise FileNotFoundError(
                f"aidatapilot FileConnector: file not found — '{self._path}'"
            )
        ext = self._path.suffix.lower()
        if ext not in self.SUPPORTED_EXTENSIONS:
            raise ValueError(
                f"aidatapilot FileConnector: unsupported extension '{ext}'. "
                f"Supported: {', '.join(self.SUPPORTED_EXTENSIONS)}"
            )
        return self

    def _segment_text(self, text: str) -> list[str]:
        """Split giant text blocks into manageable sentences/chunks for translation."""
        if not text: return []
        import re
        # Split by Tamil/English sentence ends or common delimiters
        # Tamil period: '।' or '.'
        chunks = re.split(r'([.!?।।\n]+)', text)
        
        # Re-join delimiters with their preceding text
        sentences = []
        for i in range(0, len(chunks)-1, 2):
            sentences.append(chunks[i] + chunks[i+1])
        if len(chunks) % 2 != 0:
            sentences.append(chunks[-1])
            
        # Hard limit: if any sentence is > 5000 chars, chunk it by length
        final = []
        for s in sentences:
            s_clean = s.strip()
            if not s_clean: continue
            if len(s_clean) > 5000:
                for i in range(0, len(s_clean), 5000):
                    final.append(s_clean[i:i+5000])
            else:
                final.append(s_clean)
        return final

    def read(self) -> pd.DataFrame:
        """Read and return the file contents as a DataFrame."""
        ext = self._path.suffix.lower()
        
        if ext == ".csv":
            # 1. Detect delimiter and potential metadata rows
            delimiter = ","
            auto_skip = 0
            
            try:
                # Manual Delimiter Frequency Scorer
                # Use utf-8-sig to correctly handle BOMs during sniffing
                with open(self._path, encoding="utf-8-sig", errors="ignore") as f:
                    sample_lines = [f.readline() for _ in range(100)]
                
                # Test candidates
                candidates = [",", ";", "\t", "|", ":"]
                best_delim = ","
                max_score = 0
                
                for d in candidates:
                    # Score = total counts of delimiter across all lines
                    score = sum(l.count(d) for l in sample_lines if l.strip())
                    if score > max_score:
                        max_score = score
                        best_delim = d
                
                # Rule: Switch if the winner has ANY significant presence 
                # (Lowered threshold from 50% to 10% to account for metadata headers)
                if max_score > len(sample_lines) * 0.1: 
                    delimiter = best_delim
                    from aidatapilot.utils.logger import get_logger
                    get_logger().info(f"FileConnector: Auto-detected delimiter: [cyan]'{delimiter}'[/]")
            except Exception:
                pass # Fallback to comma

            if "skiprows" not in self._read_kwargs:
                auto_skip = self._detect_skiprows(self._path, delimiter=delimiter)
                if auto_skip > 0:
                   from aidatapilot.utils.logger import get_logger
                   get_logger().info(f"FileConnector: Auto-detected {auto_skip} metadata rows to skip.")

            # 2. Try multiple encodings for global reach
            encodings = [self._encoding, "utf-8-sig", "latin1", "cp1252", "shift_jis", "cp1251", "iso-8859-1"]
            last_error = None
            for enc in encodings:
                try:
                    self._df = pd.read_csv(
                        self._path, 
                        encoding=enc, 
                        sep=delimiter,
                        skiprows=auto_skip if auto_skip > 0 else self._read_kwargs.get("skiprows"),
                        **{k: v for k, v in self._read_kwargs.items() if k not in ("skiprows", "sep")}
                    )
                    self._encoding = enc  # Memoize successful encoding
                    return self._df
                except (UnicodeDecodeError, LookupError) as e:
                    last_error = e
                except Exception as e:
                    last_error = e
                    
            raise RuntimeError(
                f"aidatapilot: Could not parse CSV. Try passing a specific 'skiprows' or 'encoding'. Last error: {last_error}"
            )
            
        elif ext in (".xlsx", ".xls"):
            self._df = pd.read_excel(self._path, **self._read_kwargs)
        elif ext == ".parquet":
            self._df = pd.read_parquet(self._path, **self._read_kwargs)
        elif ext in (".json", ".jsonl"):
            orient = "records" if ext == ".jsonl" else None
            try:
                self._df = pd.read_json(
                    self._path,
                    encoding=self._encoding,
                    orient=orient,
                    **self._read_kwargs,
                )
            except ValueError:
                # Fallback: try lines mode for .json too
                self._df = pd.read_json(
                    self._path,
                    encoding=self._encoding,
                    lines=True,
                    **self._read_kwargs,
                )
        elif ext == ".txt":
            # Plain text: load segmented for translation readiness
            try:
                with open(self._path, encoding=self._encoding, errors="ignore") as f:
                    content = f.read()
                self._df = pd.DataFrame({"text": self._segment_text(content)})
            except Exception as e:
                raise RuntimeError(f"aidatapilot: Failed to read .txt file: {e}")
                
        elif ext == ".pdf":
            try:
                from pypdf import PdfReader
                reader = PdfReader(self._path)
                full_text = ""
                for page in reader.pages:
                    full_text += page.extract_text() + "\n"
                self._df = pd.DataFrame({"text": self._segment_text(full_text)})
            except ImportError:
                raise ImportError("aidatapilot: 'pypdf' required for PDF support. Run 'pip install pypdf'.")
            except Exception as e:
                raise RuntimeError(f"aidatapilot: Failed to read PDF: {e}")
                
        elif ext in (".docx", ".doc"):
            try:
                from docx import Document
                doc = Document(self._path)
                full_text = "\n".join([para.text for para in doc.paragraphs])
                self._df = pd.DataFrame({"text": self._segment_text(full_text)})
            except ImportError:
                raise ImportError("aidatapilot: 'python-docx' required for DOCX support. Run 'pip install python-docx'.")
            except Exception as e:
                raise RuntimeError(f"aidatapilot: Failed to read DOCX: {e}")

        return self._df  # type: ignore[return-value]

    def _detect_skiprows(self, path: Path, delimiter: str = ",") -> int:
        """Robust, quote-aware heuristic to find the row index of the actual data header."""
        import csv
        try:
            with open(path, "r", encoding="utf-8-sig", errors="ignore") as f:
                lines = [f.readline() for _ in range(50)]
            
            if not lines:
                return 0
                
            # Use csv.reader to correctly parse lines with quotes
            valid_counts = []
            for line in lines:
                if not line.strip(): continue
                try:
                    reader = csv.reader([line], delimiter=delimiter, quotechar='"')
                    row = next(reader)
                    valid_counts.append(len(row))
                except:
                    continue
            
            if not valid_counts:
                return 0
                
            # Mode detection (most common number of fields)
            from collections import Counter
            most_common_fields = Counter(valid_counts).most_common(1)[0][0]
            
            if most_common_fields < 2: # Single-column CSVs are rare or metadata
                return 0
                
            # If the first line matches the mode, assume it's the header
            if valid_counts[0] == most_common_fields:
                return 0
                
            # Otherwise, find the first line hitting that field count
            for i, line in enumerate(lines):
                if not line.strip(): continue
                try:
                    reader = csv.reader([line], delimiter=delimiter, quotechar='"')
                    if len(next(reader)) == most_common_fields:
                        return i
                except:
                    continue
            return 0
        except Exception:
            return 0

    def close(self) -> None:
        """No persistent connection to release."""
        self._df = None


from aidatapilot.core.registry import ConnectorRegistry

# Auto-register on import
ConnectorRegistry.register("file", FileConnector)

