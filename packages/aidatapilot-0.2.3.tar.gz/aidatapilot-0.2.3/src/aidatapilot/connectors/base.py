"""
Base Connector + Connector Registry
-------------------------------------
All data connectors inherit from :class:`BaseConnector`.
Register custom connectors via :func:`register_connector`.
"""

from __future__ import annotations

import abc

import pandas as pd


class BaseConnector(abc.ABC):
    """Abstract base class for all data connectors.

    Override :meth:`connect`, :meth:`read`, and :meth:`close`
    to implement a new data source.

    Plugin authors register connectors like this::

        from aidatapilot.connectors.base import register_connector
        from aidatapilot.connectors.base import BaseConnector

        class MyDBConnector(BaseConnector):
            def connect(self): ...
            def read(self) -> pd.DataFrame: ...
            def close(self): ...

        register_connector("mydb", MyDBConnector)
    """

    @abc.abstractmethod
    def connect(self) -> BaseConnector:
        """Open the connection / prepare the resource."""

    @abc.abstractmethod
    def read(self) -> pd.DataFrame:
        """Read and return data as a :class:`~pandas.DataFrame`."""

    @abc.abstractmethod
    def close(self) -> None:
        """Release the connection / clean up resources."""



