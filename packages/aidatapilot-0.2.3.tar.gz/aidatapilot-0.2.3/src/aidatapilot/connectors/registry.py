"""Connectors registry re-export."""
from aidatapilot.core.registry import ConnectorRegistry, register_connector

__all__ = ["ConnectorRegistry", "register_connector"]

