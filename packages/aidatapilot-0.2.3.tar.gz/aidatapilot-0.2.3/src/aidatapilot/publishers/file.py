"""
File Publisher
--------------
Write processed DataFrames to local CSV or JSON files.
Auto-detects format from the output file extension.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from aidatapilot.publishers.base import BasePublisher
from aidatapilot.core.registry import PublisherRegistry


class FilePublisher(BasePublisher):
    """Write a DataFrame to a local CSV or JSON file.

    The parent directory is created automatically if it doesn't exist.

    Supported extensions:
        ``.csv`` — comma-separated values
        ``.json`` — JSON array of records
        ``.jsonl`` — newline-delimited JSON

    Example::

        publisher = FilePublisher()
        publisher.publish(df, "output/clean_data.csv")
    """

    SUPPORTED_EXTENSIONS = {".csv", ".json", ".jsonl", ".xlsx", ".xls", ".parquet", ".txt"}

    def publish(self, df: pd.DataFrame, path: str, **kwargs) -> None:
        """Write *df* to *path* with auto-incrementing fallback for locked files."""
        out_path = Path(path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        ext = out_path.suffix.lower()
        
        if ext not in self.SUPPORTED_EXTENSIONS:
            raise ValueError(f"FilePublisher: unsupported extension '{ext}'.")

        from aidatapilot.utils.logger import get_logger
        logger = get_logger()
        
        # Safe Writing Strategy: Attempt auto-increment if file is locked (PermissionError)
        for i in range(10): # Max 10 attempts
            suffix = f"_{i}" if i > 0 else ""
            attempt_path = out_path.parent / f"{out_path.stem}{suffix}{out_path.suffix}"
            
            try:
                self._write_to_file(df, attempt_path, ext, **kwargs)
                if i > 0:
                    logger.warning(f"File locked: [yellow]{path}[/]. Saved to [cyan]{attempt_path.name}[/] instead.")
                return
            except PermissionError:
                if i == 9:
                    raise PipelineError(f"Permission denied for '{path}'. Close the file and try again.")
                continue
            except Exception as e:
                raise PipelineError(f"Failed to publish to '{path}': {e}")

    def _write_to_file(self, df: pd.DataFrame, path: Path, ext: str, **kwargs) -> None:
        index = kwargs.pop("index", False)
        try:
            if ext == ".csv":
                df.to_csv(path, index=index, **kwargs)
            elif ext in (".xlsx", ".xls"):
                df.to_excel(path, index=index, **kwargs)
            elif ext == ".parquet":
                df.to_parquet(path, index=index, **kwargs)
            elif ext == ".jsonl":
                df.to_json(path, orient="records", lines=True, **kwargs)
            elif ext == ".json":
                df.to_json(path, orient="records", indent=2, **kwargs)
            elif ext == ".txt":
                # Special handler for Unstructured Text output
                if "text" in df.columns:
                    # Just write the text column raw
                    with open(path, "w", encoding="utf-8") as f:
                        for line in df["text"]:
                            f.write(str(line) + "\n")
                else:
                    # Tab-separated raw text
                    df.to_csv(path, sep="\t", index=False, header=False, **kwargs)
        except ImportError as e:
            # Provide friendly fix
            from aidatapilot.exceptions.base import PipelineError
            msg = f"Missing dependency for {ext} output: {e}. Try 'pip install openpyxl' or 'pip install pyarrow'."
            raise PipelineError(msg)


from aidatapilot.core.registry import PublisherRegistry

# Auto-register on import
PublisherRegistry.register("file", FilePublisher)

