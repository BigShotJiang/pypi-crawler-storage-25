"""Publishers registry re-export."""
from aidatapilot.core.registry import PublisherRegistry, register_publisher

__all__ = ["PublisherRegistry", "register_publisher"]

