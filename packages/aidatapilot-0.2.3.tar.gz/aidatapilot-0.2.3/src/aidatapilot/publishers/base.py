"""
Base Publisher + Publisher Registry
--------------------------------------
All output publishers inherit from :class:`BasePublisher`.
Register custom publishers via :func:`register_publisher`.
"""

from __future__ import annotations

import abc

import pandas as pd


class BasePublisher(abc.ABC):
    """Abstract base class for output publishers.

    Plugin authors register publishers like this::

        from aidatapilot.publishers.base import register_publisher, BasePublisher

        class MyS3Publisher(BasePublisher):
            def publish(self, df, path, **kwargs): ...

        register_publisher("s3", MyS3Publisher)
    """

    @abc.abstractmethod
    def publish(self, df: pd.DataFrame, path: str, **kwargs) -> None:
        """Write *df* to the destination specified by *path*.

        Args:
            df: DataFrame to publish.
            path: Destination path or URI.
            **kwargs: Format-specific keyword arguments.
        """



