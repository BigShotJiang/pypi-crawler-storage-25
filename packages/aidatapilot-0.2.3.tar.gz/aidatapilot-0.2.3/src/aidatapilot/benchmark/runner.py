"""
aidatapilot Benchmark Runner
-------------------------
Measures pipeline performance (rows/sec, memory growth).
"""

import os
import time

from aidatapilot.utils.logger import get_logger

try:
    import psutil
except ImportError:
    psutil = None

logger = get_logger()

class BenchmarkRunner:
    """Executes pipelines and captures performance metrics."""

    def __init__(self, pipeline, label: str = "Benchmark"):
        self.pipeline = pipeline
        self.label = label
        self.results = {}

    def run(self) -> dict:
        """Run benchmark and return metrics."""
        logger.info(f"\n[bold blue]--- Benchmarking: {self.label} ---[/]")
        
        mem_before = 0
        if psutil:
            process = psutil.Process(os.getpid())
            mem_before = process.memory_info().rss / 1024**2

        start_time = time.perf_counter()
        result = self.pipeline.run()
        end_time = time.perf_counter()
        
        duration = end_time - start_time
        
        mem_after = 0
        if psutil:
            mem_after = process.memory_info().rss / 1024**2

        if result.success:
            throughput = result.rows_in / max(duration, 0.001)
            self.results = {
                "duration": duration,
                "throughput": throughput,
                "mem_growth": mem_after - mem_before,
                "rows_in": result.rows_in,
                "rows_out": result.rows_out,
                "success": True
            }
            self._print_results()
        else:
            logger.error(f"Benchmark Failed: {result.error}")
            self.results = {"success": False, "error": result.error}

        return self.results

    def _print_results(self):
        print(f"    Label:      {self.label}")
        print(f"    Time:       {self.results['duration']:.4f}s")
        print(f"    Throughput: {self.results['throughput']:,} rows/sec")
        if psutil:
            print(f"    Memory:     +{self.results['mem_growth']:.2f} MB")

