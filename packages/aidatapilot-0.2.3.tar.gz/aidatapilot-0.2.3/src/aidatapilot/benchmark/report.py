"""
aidatapilot Benchmark Reporting
----------------------------
Generates comparison reports for different performance strategies.
"""

from typing import Dict


class BenchmarkReporter:
    """Summarizes and compares multiple benchmark results."""

    def __init__(self):
        self.results = []

    def add_result(self, label: str, metrics: Dict):
        self.results.append({"label": label, **metrics})

    def print_comparison(self):
        """Print a formatted comparison table."""
        print("\n--- aidatapilot Performance Comparison ---")
        print(f"{'Strategy':<20} | {'Rows/Sec':<15} | {'Time (s)':<10} | {'Status':<10}")
        print("-" * 65)
        for res in self.results:
            if res.get("success"):
                print(f"{res['label']:<20} | {res['throughput']:<15,.0f} | {res['duration']:<10.4f} | SUCCESS")
            else:
                print(f"{res['label']:<20} | {'N/A':<15} | {'N/A':<10} | FAILED")
        print("-" * 65 + "\n")

