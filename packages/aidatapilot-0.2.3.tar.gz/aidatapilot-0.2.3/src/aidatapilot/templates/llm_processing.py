"""
LLM Preprocessing Template
---------------------------
Opinionated pipeline for preparing documents for Vector DBs and LLMs.
"""

from aidatapilot.core.registry import register_template


@register_template("llm_processing", description="Standard LLM Document Processing Pipeline.")
def llm_processing_template(**params):
    """
    Standard LLM Document Processing Pipeline:
    1. Normalize Columns
    2. Clean Text (lower, strip)
    3. Generate Metadata (word counts, etc.)
    4. Chunk Text (splitting for embeddings)
    """
    return [
        {"name": "normalize_columns"},
        {"name": "infer_types"},
        {"name": "interpolate_ids"},
        {"name": "handle_missing_data"},
        {"name": "deduplicate"},
        {"name": "segregate_outliers"},
        {
            "name": "clean_text", 
            "params": {"columns": params.get("text_columns", [])}
        },
        {
            "name": "generate_metadata",
            "params": {"column": params.get("primary_column", "content")}
        },
        {
            "name": "chunk_text",
            "params": {
                "column": params.get("primary_column", "content"),
                "chunk_size": params.get("chunk_size", 500),
                "chunk_overlap": params.get("chunk_overlap", 50)
            }
        },
    ]

