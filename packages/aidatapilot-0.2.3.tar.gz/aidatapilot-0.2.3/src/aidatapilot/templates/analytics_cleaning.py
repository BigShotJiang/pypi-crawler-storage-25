"""
Business Analytics Template
---------------------------
Opinionated pipeline for formatting data for BI tools and reports.
"""

from __future__ import annotations
from typing import Any, List, Optional
import pandas as pd
from aidatapilot.core.registry import register_template

@register_template("analytics_cleaning", description="Standard Business Analytics Pipeline.")
def analytics_cleaning_template(df: Optional[pd.DataFrame] = None, **params) -> List[Any]:
    """
    Standard Business Analytics Pipeline:
    1. Normalize Columns (Lower-underscore)
    2. Infer Types (Strict casting)
    3. Interpolate IDs (Sequential precision)
    4. Format Dates (Universal %d-%m-%Y)
    5. Handle Missing Data (0/null)
    6. Deduplicate (Unique rows)
    7. Basic Aggregation (Optional)
    """
    return [
        {"name": "normalize_columns"},
        {"name": "infer_types"},
        {"name": "handle_missing_data", "params": {"id_patterns": ["id", "pk", "uuid", "uid", "no", "code"]}},
        {"name": "format_date", "params": {"dayfirst": True, "display_format": "%d-%m-%Y"}},
        {"name": "deduplicate"},
        {"name": "segregate_outliers"},
        {"name": "basic_aggregation", "params": params.get("aggregation", {})},
    ]
