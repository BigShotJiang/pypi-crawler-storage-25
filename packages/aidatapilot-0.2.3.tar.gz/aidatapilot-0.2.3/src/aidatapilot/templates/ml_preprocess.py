"""
ML Preprocess Template
-----------------------
Professional pipeline for preparing training datasets for Machine Learning.
"""

from typing import Optional, List, Union, Dict, Any
import pandas as pd
from aidatapilot.core.registry import register_template


@register_template("ml_preprocess", description="Dynamic Machine Learning Preprocessing Pipeline.")
def ml_preprocess_template(df: pd.DataFrame, target: Optional[str] = None, **params):
    """
    Dynamic ML Preprocessing:
    1. Identify Numeric vs. Categorical features.
    2. Exclude Target/Labels from transformations.
    3. Scale Numeric (Standard), Encode Categorical (Label).
    4. Remove noise (IDs, high-null columns).
    """
    from aidatapilot.utils.internal import is_id_column

    # 1. Identification Logic
    # Use the passed target or check params for common names
    target = target or params.get("target") or params.get("label_column")
    
    cols = df.columns.tolist()
    
    # 2. Separate Features from Target and ID Noise
    numeric_cols = [
        c for c in df.select_dtypes(include=["number"]).columns 
        if c != target and not is_id_column(c)
    ]
    categorical_cols = [
        c for c in df.select_dtypes(include=["object", "category"]).columns 
        if c != target and not is_id_column(c)
    ]
    id_cols = [c for c in cols if is_id_column(c)]
    
    # 3. Pipeline Construction
    steps = [
        {"name": "normalize_columns"},
        {"name": "infer_types"},
        {"name": "handle_missing_data"},
    ]

    # 4. Feature Encoding (Turn text into numbers)
    if categorical_cols:
        steps.append({
            "name": "encode_categorical", 
            "params": {"columns": categorical_cols, "method": "label"}
        })

    # 5. Feature Scaling (Z-score standard scaling)
    if numeric_cols:
        steps.append({
            "name": "scale_numeric", 
            "params": {"columns": numeric_cols, "method": "standard"}
        })

    # 6. Final Sanitization
    if id_cols:
        steps.append({"name": "drop_columns", "params": {"columns": id_cols}})
    
    steps.append({"name": "segregate_outliers"})

    return steps
