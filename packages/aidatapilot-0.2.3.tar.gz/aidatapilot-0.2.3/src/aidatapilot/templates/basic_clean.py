"""
basic_clean Template
--------------------
The simplest and fastest cleaning pipeline.
Suitable for quick one-off data cleaning tasks.
"""

from aidatapilot.core.registry import register_template


@register_template("basic_clean", description="Quick data cleaning: normalize names, remove high-null rows, and deduplicate.")
def basic_clean_template(**params):
    """
    Standard Cleaning Pipeline (v0.2.x):
    1. normalize_columns
    2. infer_types
    3. interpolate_ids
    4. handle_missing_data
    5. deduplicate
    6. segregate_outliers
    """
    return [
        "normalize_columns",
        "infer_types",
        "interpolate_ids",
        "handle_missing_data",
        "deduplicate",
        "segregate_outliers",
    ]
