"""Templates package init."""

