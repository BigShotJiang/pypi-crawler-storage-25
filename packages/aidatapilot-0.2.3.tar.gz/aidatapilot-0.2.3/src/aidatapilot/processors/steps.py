"""
Built-in Processing Steps
--------------------------
All built-in steps auto-register themselves on import.
Each step follows the standard signature::

    def step_name(df: pd.DataFrame, **params) -> pd.DataFrame

Steps are intentionally short, focused, well-documented, and opinionated.
"""

from __future__ import annotations

import logging
import re
import warnings
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd

from aidatapilot.core.registry import register_step
from aidatapilot.utils.internal import smart_numeric_parse, is_id_column

logger = logging.getLogger("aidatapilot")
 


# ──────────────────────────────────────────────────────────────────────
# 1. normalize_columns
# ──────────────────────────────────────────────────────────────────────

@register_step("normalize_columns")
def normalize_columns(df: pd.DataFrame, **params) -> pd.DataFrame:
    """Normalize column names: strip whitespace, lowercase, replace spaces with underscores."""
    df = df.copy()
    try:
        # Use a more Unicode-friendly replacement: keep letters, numbers, and underscores
        df.columns = [re.sub(r"[^\w]+", "_", str(c).lower()).strip("_") for c in df.columns]
    except Exception as e:
        logger.warning(f"normalize_columns: failed to normalize names: {e}")
    return df


# ──────────────────────────────────────────────────────────────────────
# 2. infer_types
# ──────────────────────────────────────────────────────────────────────

@register_step("infer_types")
def infer_types(df: pd.DataFrame, confidence_threshold: float = 0.5, **params) -> pd.DataFrame:
    """Automatically detect and cast column types (Integer, Float, Date)."""
    df = df.copy()
    try:
        for col in df.columns:
            if df[col].dtype.kind not in 'OS': 
                continue
                
            non_null_count = df[col].notnull().sum()
            if non_null_count == 0:
                continue

            # -- 0. Skip ID Columns (keep as strings) ----------------------
            if is_id_column(col):
                continue

            # -- 1. Check for Date Candidacy ------------------------------
            is_date_candidate = any(p in col.lower() for p in ["date", "time", "stamp", "_at", "at_"])
            
            # -- 2. Try Date First if Candidate ---------------------------
            if is_date_candidate:
                temp_df = format_date(pd.DataFrame({"c": df[col]}), columns=["c"], silent=True)
                if temp_df["c"].dtype.kind in "M":
                     parsed_count = temp_df["c"].notnull().sum()
                     if parsed_count / non_null_count > 0.5:
                         df[col] = temp_df["c"]
                         continue

            # -- 3. Try Numeric (Intelligent) ---------------------------
            # First, check if column contains mixed alphanumeric content (letters + numbers)
            # If so, keep it as string (likely a categorical code or identifier)
            sample_values = df[col].dropna().head(100)
            has_mixed_alphanum = any(
                bool(re.search(r'[a-zA-Z]', str(v))) and bool(re.search(r'\d', str(v)))
                for v in sample_values
            )
            if has_mixed_alphanum:
                continue  # Skip columns with mixed text and numbers
            
            # First try standard cast
            numeric_series = pd.to_numeric(df[col].astype(str).str.strip(), errors="coerce")
            
            # If not perfectly numeric, try our smart parser
            if numeric_series.notnull().sum() / non_null_count < 0.99:
                smart_series = df[col].map(smart_numeric_parse)
                # Take the smart version if it found more numeric signals
                if smart_series.notnull().sum() >= numeric_series.notnull().sum():
                    numeric_series = smart_series
            
            parsed_numeric_ratio = numeric_series.notnull().sum() / non_null_count
            if parsed_numeric_ratio >= confidence_threshold and parsed_numeric_ratio > 0:
                # MANDATORY Standard: fill invalid/junk/NaN with 0 if column is numeric
                numeric_series = numeric_series.fillna(0)
                
                if (numeric_series % 1 == 0).all():
                    df[col] = numeric_series.round().astype("Int64")
                else:
                    df[col] = numeric_series
                continue

            # -- 4. Try Date (if not already tried) ------------------------------
            if not is_date_candidate:
                temp_df = format_date(pd.DataFrame({"c": df[col]}), columns=["c"], silent=True)
                if temp_df["c"].dtype.kind in "M":
                     parsed_count = temp_df["c"].notnull().sum()
                     if parsed_count / non_null_count > 0.5:
                         df[col] = temp_df["c"]
    except Exception as e:
        logger.warning(f"infer_types: silent recovery from error: {e}")
        
    return df


# ──────────────────────────────────────────────────────────────────────
# 3. remove_nulls
# ──────────────────────────────────────────────────────────────────────

@register_step("remove_nulls")
def remove_nulls(
    df: pd.DataFrame,
    threshold: float = 0.0,
    subset: Optional[List[str]] = None,
    **params,
) -> pd.DataFrame:
    """Remove rows where the fraction of null values exceeds *threshold*."""
    df = df.copy()
    try:
        cols = subset or list(df.columns)
        null_fraction = df[cols].isnull().mean(axis=1)
        before = len(df)
        df = df[null_fraction <= threshold]
        dropped = before - len(df)
        if dropped:
            logger.debug(f"remove_nulls: dropped {dropped:,} rows (threshold={threshold})")
    except Exception as e:
        logger.warning(f"remove_nulls: silent recovery: {e}")
    return df


# ──────────────────────────────────────────────────────────────────────
# 3. fill_nulls
# ──────────────────────────────────────────────────────────────────────

@register_step("fill_nulls")
def fill_nulls(
    df: pd.DataFrame,
    strategy: str = "mean",
    fill_value: Optional[Any] = None,
    columns: Optional[List[str]] = None,
    **params,
) -> pd.DataFrame:
    """Fill null values using a strategy or a fixed value."""
    df = df.copy()
    try:
        strategy = strategy or "auto"
        target_cols = columns or list(df.columns)

        for col in target_cols:
            if col not in df.columns or df[col].isnull().sum() == 0:
                continue

            if strategy == "auto":
                if pd.api.types.is_numeric_dtype(df[col]):
                    df[col] = df[col].fillna(0)
                elif not pd.api.types.is_datetime64_any_dtype(df[col]):
                    df[col] = df[col].fillna("null")
            elif strategy == "mean" and pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(df[col].mean())
            elif strategy == "median" and pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(df[col].median())
            elif strategy == "mode":
                mode = df[col].mode()
                if not mode.empty:
                    df[col] = df[col].fillna(mode[0])
            elif strategy == "interpolate":
                try:
                    df[col] = df[col].interpolate(method="linear")
                except Exception:
                    pass
            elif strategy == "value" and fill_value is not None:
                df[col] = df[col].fillna(fill_value)
    except Exception as e:
        logger.warning(f"fill_nulls: silent recovery: {e}")
    return df


@register_step("handle_missing_data")
def handle_missing_data(
    df: pd.DataFrame, 
    id_patterns: Optional[List[str]] = None, 
    **params
) -> pd.DataFrame:
    """Refined missing value handling (v0.2.0): ID -> Name -> Dependent -> Independent logic."""
    df = df.copy()
    try:
        # 0. Discovery
        id_cols = [c for c in df.columns if is_id_column(c, id_patterns)]
        name_cols = [c for c in df.columns if any(p in c.lower() for p in ["name", "product", "customer", "subject", "person"])]
        
        # 1. ID Column Handling (REFINED v0.2.0): Sequential Accuracy
        for col in id_cols:
            if pd.api.types.is_numeric_dtype(df[col]):
                # A. Detect existing IDs
                ids = df[col].values
                # B. Find gaps and fill sequentially
                if df[col].isnull().any():
                    # Heuristic: Start from 1 or current min
                    start_id = df[col].min()
                    if pd.isna(start_id): start_id = 1
                    
                    current_max = start_id
                    new_ids = []
                    for val in ids:
                        if pd.isna(val):
                            current_max += 1
                            new_ids.append(float(current_max))
                        else:
                            current_max = max(current_max, val)
                            new_ids.append(val)
                    df[col] = new_ids
                
                # C. Final Clean cast to Int64 (nullable integer)
                try:
                    df[col] = df[col].astype("Int64")
                except Exception:
                    pass
            else:
                # String IDs
                df[col] = df[col].ffill().bfill().fillna("UNKNOWN_ID")

        # 2. Name Column Handling ("Unknown")
        for col in name_cols:
            if col not in id_cols:
                # Identification of missing/unknown names
                series_str = df[col].astype(str).str.strip().str.lower()
                is_unknown = df[col].isna() | series_str.isin(["", "nan", "null", "none", "unknown"])
                
                if is_unknown.any():
                    # REFINED: Only flag for segregation if it's an actual 'Name' column 
                    # (Avoid moving rows just because 'product' or 'subject' is missing)
                    if "name" in col.lower() or "customer" in col.lower() or "person" in col.lower():
                        if "_aidatapilot_status" not in df.columns:
                            df["_aidatapilot_status"] = np.nan
                        df["_aidatapilot_status"] = df["_aidatapilot_status"].astype(object)
                        df.loc[is_unknown, "_aidatapilot_status"] = "Unknown Name"
                
                df[col] = df[col].astype(str).str.strip().replace(["", "nan", "NaN", "null", "None"], "null")
                df[col] = df[col].fillna("null")

        # 3. Dependent Column Filling
        potential_refs = [c for c in id_cols + name_cols if c in df.columns]
        other_cols = [c for c in df.columns if c not in potential_refs]
        for col in other_cols:
            if df[col].isnull().any():
                for ref in potential_refs:
                    mapping = df.dropna(subset=[col]).drop_duplicates(subset=[ref])[[ref, col]].set_index(ref)[col]
                    if not mapping.empty:
                        df[col] = df[col].fillna(df[ref].map(mapping))
                        if not df[col].isnull().any():
                            break

        # 4. Independent Column Filling
        for col in df.columns:
            if col == "_aidatapilot_status":
                continue # Don't fill the internal status column with "null"
            if df[col].isnull().any():
                if pd.api.types.is_numeric_dtype(df[col]):
                    df[col] = df[col].fillna(0)
                elif pd.api.types.is_datetime64_any_dtype(df[col]):
                    df[col] = df[col].ffill().bfill()
                else:
                    # STRICT Standard: fill string gaps with 'null'
                    df[col] = df[col].astype(str).str.strip().replace(["", "nan", "NaN", "None", "None", "nan"], "null")
                    df[col] = df[col].fillna("null")

    except Exception as e:
        logger.warning(f"handle_missing_data: safety recovery: {e}")
    
    return df


# ──────────────────────────────────────────────────────────────────────
# 5. adaptive_impute
# ──────────────────────────────────────────────────────────────────────

@register_step("adaptive_impute")
def adaptive_impute(
    df: pd.DataFrame, 
    cardinality_limit: int = 50,
    **params
) -> pd.DataFrame:
    """Automatically discover and perform group-based imputation for numeric nulls."""
    df = df.copy()
    try:
        # 1. Identify Numeric Targets with Nulls
        numeric_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c]) and not is_id_column(c)]
        targets = [c for c in numeric_cols if df[c].isnull().any() or (df[c] == 0).any()]
        
        # 2. Identify Potential Groups (Categorical, Low Cardinality)
        potential_groups = []
        for col in df.columns:
            if not pd.api.types.is_numeric_dtype(df[col]) and not is_id_column(col):
                nunique = df[col].nunique()
                if 1 < nunique <= cardinality_limit:
                    potential_groups.append(col)

        if not targets or not potential_groups:
            return df

        logger.info(f"adaptive_impute: Found {len(targets)} targets and {len(potential_groups)} group candidates.")

        for target in targets:
            # Simple heuristic: Use the first good grouping column for now
            # (In future versions, we could use correlation or mutual info)
            group = potential_groups[0] 
            logger.debug(f"adaptive_impute: Imputing '{target}' via '{group}'")
            df = group_impute(df, target_column=target, group_column=group)

    except Exception as e:
        logger.warning(f"adaptive_impute: silent recovery: {e}")
    return df


# ──────────────────────────────────────────────────────────────────────
# 6. type_cast
# ──────────────────────────────────────────────────────────────────────

@register_step("type_cast")
def type_cast(
    df: pd.DataFrame,
    columns: Optional[Dict[str, str]] = None,
    **params,
) -> pd.DataFrame:
    """Cast DataFrame columns to specified data types."""
    if not columns:
        return df
    df = df.copy()
    try:
        type_map = {
            "int":      "Int64",
            "float":    "float64",
            "str":      "string",
            "bool":     "boolean",
            "category": "category",
        }
        for col, dtype_str in columns.items():
            if col not in df.columns:
                continue
            if dtype_str == "datetime":
                df[col] = pd.to_datetime(df[col], errors="coerce")
            else:
                target = type_map.get(dtype_str, dtype_str)
                df[col] = df[col].astype(target)
    except Exception as e:
        logger.warning(f"type_cast: silent recovery: {e}")
    return df


# ──────────────────────────────────────────────────────────────────────
# 7. interpolate_ids
# ──────────────────────────────────────────────────────────────────────

@register_step("interpolate_ids")
def interpolate_ids(
    df: pd.DataFrame,
    method: str = "forward_fill",
    id_patterns: Optional[List[str]] = None,
    columns: Optional[List[str]] = None,
    handle_duplicates: bool = True,
    **params,
) -> pd.DataFrame:
    """Interpolate missing ID values and optionally handle duplicates.
    
    Args:
        df: Input DataFrame.
        method: Interpolation method - 'linear', 'forward_fill', or 'index_based'.
                - 'linear': Creates sequential values between known points (numeric only)
                - 'forward_fill': Use previous non-null value, then back-fill (DEFAULT)
                - 'index_based': Create new sequential IDs from row index (replaces all)
        id_patterns: Patterns to identify ID columns (e.g., ['id', 'pk']).
                    Defaults to common patterns: ['id', 'id_', '_id', 'pk'].
        columns: Specific columns to interpolate. If None, auto-detect ID columns.
        handle_duplicates: If True (DEFAULT), replace duplicate IDs with incremented unique values.
        **params: Additional parameters (unused).
    
    Returns:
        DataFrame with interpolated ID values and no duplicates.
    
    Examples:
        >>> # Auto-detect and forward-fill missing IDs (DEFAULT)
        >>> result = interpolate_ids(df)
        
        >>> # Linear interpolation (numeric IDs only)
        >>> result = interpolate_ids(df, method='linear')
        
        >>> # Replace all IDs with sequential from index
        >>> result = interpolate_ids(df, method='index_based')
    """
    df = df.copy()
    
    if id_patterns is None:
        id_patterns = ['id', 'id_', '_id', 'pk', 'primary_key']
    
    # Auto-detect ID columns if not specified
    if columns is None:
        columns = [c for c in df.columns if is_id_column(c, id_patterns)]
    
    if not columns:
        return df
    
    try:
        for col in columns:
            if col not in df.columns:
                continue
            
            original_col = df[col].copy()
            has_missing = original_col.isnull().any()
            
            # Handle index-based method (replaces all with sequential)
            if method == "index_based":
                df[col] = df.index + 1
                if pd.api.types.is_integer_dtype(original_col):
                    df[col] = df[col].astype(original_col.dtype)
                logger.debug(f"interpolate_ids: '{col}' using index-based sequential IDs")
                continue
            
            # If forward_fill method, first handle existing duplicates before filling missing
            if method == "forward_fill" and handle_duplicates:
                # Detect existing duplicates (not just missing values)
                value_counts = df[col].value_counts()
                duplicate_values = value_counts[value_counts > 1].index.tolist()
                
                # Mark duplicate rows for fixing
                for dup_val in duplicate_values:
                    dup_indices = df[df[col] == dup_val].index
                    first_idx = dup_indices[0]
                    # Keep first occurrence, mark others as NaN to be re-interpolated
                    for idx in dup_indices[1:]:
                        df.loc[idx, col] = np.nan
                
                if duplicate_values:
                    logger.debug(f"interpolate_ids: '{col}' marked {len(dup_indices) - 1} duplicate values for re-interpolation")
            
            # Only fill missing values if they exist
            if not df[col].isnull().any():
                continue
            
            # Choose interpolation method
            if method == "linear" and pd.api.types.is_numeric_dtype(df[col]):
                # Linear interpolation ONLY for numeric IDs
                df[col] = df[col].interpolate(method='linear')
                df[col] = df[col].ffill().bfill()  # Fill edges
                
                # Round to integer if original was integer
                non_null_originals = original_col.dropna()
                if len(non_null_originals) > 0 and (non_null_originals % 1 == 0).all():
                    df[col] = df[col].round().astype('Int64')
                logger.debug(f"interpolate_ids: '{col}' using linear interpolation")
            
            else:
                # Forward/backward fill first
                df[col] = df[col].ffill().bfill()
                logger.debug(f"interpolate_ids: '{col}' using forward/backward fill")
            
            # Handle remaining nulls AND ensure NO duplicate IDs exist
            if pd.api.types.is_numeric_dtype(df[col]):
                # For numeric columns: track seen values and increment duplicates
                seen_ids = set()
                for idx in df.index:
                    curr_val = df.loc[idx, col]
                    
                    # Skip nulls for now
                    if pd.isnull(curr_val):
                        df.loc[idx, col] = 0  # Temporary placeholder
                        continue
                    
                    curr_val = float(curr_val)
                    
                    # If we've seen this ID before, increment until unique
                    while curr_val in seen_ids:
                        curr_val += 1
                    
                    df.loc[idx, col] = curr_val
                    seen_ids.add(curr_val)
                
                # Now handle any remaining nulls (from NaN placeholders)
                for idx in df[df[col] == 0].index:
                    # Replace 0 placeholders with incremented values
                    prev_idx = idx - 1
                    while prev_idx >= 0 and df.loc[prev_idx, col] == 0:
                        prev_idx -= 1
                    
                    if prev_idx >= 0:
                        new_val = df.loc[prev_idx, col] + 1
                        while new_val in seen_ids:
                            new_val += 1
                        df.loc[idx, col] = new_val
                        seen_ids.add(new_val)
                    else:
                        # First row is null - start from 1
                        new_val = 1
                        while new_val in seen_ids:
                            new_val += 1
                        df.loc[idx, col] = new_val
                        seen_ids.add(new_val)
                
                # Final pass: convert placeholder 0s to proper values if any remain
                null_indices = df[df[col] == 0].index
                if len(null_indices) > 0:
                    for idx in null_indices:
                        prev_idx = idx - 1
                        while prev_idx >= 0 and df.loc[prev_idx, col] == 0:
                            prev_idx -= 1
                        if prev_idx >= 0:
                            new_val = df.loc[prev_idx, col] + 1
                        else:
                            new_val = 1.0
                        while new_val in seen_ids:
                            new_val += 1
                        df.loc[idx, col] = new_val
                        seen_ids.add(new_val)
                
                # Convert to Int64 if original was integer
                non_null_originals = original_col.dropna()
                if len(non_null_originals) > 0 and (non_null_originals % 1 == 0).all():
                    df[col] = df[col].round().astype('Int64')
                    
            else:
                # For string/alphanumeric columns: track seen values
                seen_ids = set()
                for idx in df.index:
                    curr_val = df.loc[idx, col]
                    
                    # Handle null/empty values
                    if pd.isnull(curr_val) or str(curr_val).strip() == '':
                        prev_idx = idx - 1
                        while prev_idx >= 0 and (pd.isnull(df.loc[prev_idx, col]) or str(df.loc[prev_idx, col]).strip() == ''):
                            prev_idx -= 1
                        
                        if prev_idx >= 0:
                            prev_str = str(df.loc[prev_idx, col])
                            match = re.search(r'(\d+)(?!.*\d)', prev_str)
                            if match:
                                num_part = int(match.group(1))
                                prefix = prev_str[:match.start()]
                                suffix = prev_str[match.end():]
                                new_val = f"{prefix}{num_part + 1}{suffix}"
                            else:
                                new_val = prev_str + "_1"
                        else:
                            new_val = "ID_1"
                        
                        df.loc[idx, col] = new_val
                        seen_ids.add(new_val)
                    else:
                        curr_str = str(curr_val)
                        # If duplicate, increment
                        if curr_str in seen_ids:
                            match = re.search(r'(\d+)(?!.*\d)', curr_str)
                            if match:
                                num_part = int(match.group(1))
                                prefix = curr_str[:match.start()]
                                suffix = curr_str[match.end():]
                                new_val = f"{prefix}{num_part + 1}{suffix}"
                            else:
                                new_val = curr_str + "_1"
                            
                            # Keep incrementing until unique
                            while new_val in seen_ids:
                                match = re.search(r'(\d+)(?!.*\d)', new_val)
                                if match:
                                    num_part = int(match.group(1)) + 1
                                    prefix = new_val[:match.start()]
                                    suffix = new_val[match.end():]
                                    new_val = f"{prefix}{num_part}{suffix}"
                                else:
                                    new_val = new_val + "_1"
                            
                            df.loc[idx, col] = new_val
                            seen_ids.add(new_val)
                        else:
                            seen_ids.add(curr_str)
            
            remaining_nulls = df[col].isnull().sum()
            if remaining_nulls > 0:
                logger.debug(f"interpolate_ids: '{col}' has {remaining_nulls} remaining nulls after interpolation")
        
        logger.info(f"interpolate_ids: Successfully processed {len(columns)} ID column(s)")
    
    except Exception as e:
        logger.warning(f"interpolate_ids: silent recovery: {e}")
    
    return df


# ──────────────────────────────────────────────────────────────────────
# 5. deduplicate
# ──────────────────────────────────────────────────────────────────────

@register_step("deduplicate")
def deduplicate(
    df: pd.DataFrame,
    subset: Optional[List[str]] = None,
    keep: str = "first",
    **params,
) -> pd.DataFrame:
    """Remove duplicate rows."""
    try:
        before = len(df)
        df = df.drop_duplicates(subset=subset, keep=keep)
        removed = before - len(df)
        if removed:
            logger.debug(f"deduplicate: removed {removed:,} rows")
    except Exception as e:
        logger.warning(f"deduplicate: silent recovery: {e}")
    return df


# ──────────────────────────────────────────────────────────────────────
# 6. basic_aggregation
# ──────────────────────────────────────────────────────────────────────

@register_step("basic_aggregation")
def basic_aggregation(
    df: pd.DataFrame,
    group_by: Optional[Union[str, List[str]]] = None,
    aggregations: Optional[Dict[str, str]] = None,
    **params,
) -> pd.DataFrame:
    """Aggregate the DataFrame using group-by + agg operations."""
    if not group_by:
        return df
    try:
        agg_funcs = aggregations or {}
        if agg_funcs:
            return df.groupby(group_by, as_index=False).agg(agg_funcs)
        return df.groupby(group_by, as_index=False).size()
    except Exception as e:
        logger.warning(f"basic_aggregation: silent recovery: {e}")
        return df


# ──────────────────────────────────────────────────────────────────────
# 7. rename_columns
# ──────────────────────────────────────────────────────────────────────

@register_step("rename_columns")
def rename_columns(df: pd.DataFrame, mapping: Optional[Dict[str, str]] = None, **params) -> pd.DataFrame:
    """Rename specific columns via an explicit mapping."""
    if not mapping:
        return df
    try:
        return df.rename(columns=mapping)
    except Exception as e:
        logger.warning(f"rename_columns: silent recovery: {e}")
        return df


# ──────────────────────────────────────────────────────────────────────
# 8. select_columns
# ──────────────────────────────────────────────────────────────────────

@register_step("select_columns")
def select_columns(df: pd.DataFrame, columns: Optional[List[str]] = None, **params) -> pd.DataFrame:
    """Keep only the specified columns."""
    if not columns:
        return df
    try:
        valid = [c for c in columns if c in df.columns]
        return df[valid]
    except Exception as e:
        logger.warning(f"select_columns: silent recovery: {e}")
        return df


# ──────────────────────────────────────────────────────────────────────
# 9. format_date
# ──────────────────────────────────────────────────────────────────────

@register_step("format_date")
def format_date(
    df: pd.DataFrame,
    columns: Optional[List[str]] = None,
    format: Optional[str] = None,
    dayfirst: bool = True,
    display_format: Optional[str] = None,
    silent: bool = False,
    **params,
) -> pd.DataFrame:
    """Parse string columns into standard datetime format.
    
    Universal Parser: handles mixed separators (. vs -) and attempts 
    multiple international formats if standard inference fails.

    Args:
        df: Input DataFrame.
        columns: List of columns to convert.
        format: Explicit strftime format. If ``None``, uses smart inference.
        dayfirst: Whether to interpret ambiguous dates as DD-MM. Default ``True``.
        display_format: Final output format string (e.g. "%d-%m-%Y").
            If provided, converts the datetime back to a string format.

    Returns:
        DataFrame with formatted datetime columns.
    """
    df = df.copy()
    try:
        if not columns:
            columns = _auto_detect_date_cols(df)
        
        if not columns:
            return df

        fallback_formats = [
            "%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y", 
            "%d/%m/%Y", "%Y/%m/%d", "%b %d, %Y",
            "%Y.%m.%d", "%d.%m.%Y", "%Y%m%d"
        ]

        for col in columns:
            if col not in df.columns:
                continue
                
            original_col = df[col].copy()
            clean_col = _standardize_date_separators(df[col])
            
            # Attempt Conversion
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", UserWarning)
                converted = pd.to_datetime(clean_col, format=format, dayfirst=dayfirst, errors="coerce")
            
            # Progressive fill
            for fmt in fallback_formats:
                if not converted.isnull().any():
                    break
                
                mask = converted.isnull()
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", UserWarning)
                    temp_parsed = pd.to_datetime(original_col[mask], format=fmt, errors="coerce")
                
                if temp_parsed.notnull().any():
                    converted.loc[mask] = temp_parsed

            # Fill remaining nulls with forward/backward fill
            if converted.isnull().any():
                converted = converted.ffill().bfill()

            if converted.isnull().all() and original_col.notnull().any():
                logger.debug(f"format_date: '{col}' failed date parsing. Reverting.")
                continue
            
            if display_format and converted.notnull().any():
                # Only format non-null dates, keep nulls as strings "null"
                formatted = converted.dt.strftime(display_format)
                formatted = formatted.fillna("null").astype(str)
                df[col] = formatted
            else:
                df[col] = converted
            
            num_nat = converted.isnull().sum()
            if num_nat > 0 and not silent:
                logger.warning(f"format_date: '{col}' has {num_nat} unparseable dates.")
    except Exception as e:
        logger.warning(f"format_date: silent recovery: {e}")
                
    return df

def _auto_detect_date_cols(df: pd.DataFrame) -> List[str]:
    cols = []
    for col in df.columns:
        col_low = col.lower()
        if any(p in col_low for p in ["date", "time", "stamp", "_at", "at_"]):
            cols.append(col)
        elif df[col].dtype == "object":
            sample = df[col].dropna().head(5).astype(str)
            if sample.str.contains(r"\d{2,4}[-./]\d{1,2}[-./]\d{1,2}", regex=True).any():
                cols.append(col)
    return cols

def _standardize_date_separators(series: pd.Series) -> pd.Series:
    if series.dtype == "object":
        s = series.astype(str)
        # Only replace if it matches a date-like pattern to avoid mangling numbers like "1.234"
        return s.str.replace(r"(\d{1,4})[./](\d{1,2})[./](\d{1,4})", r"\1-\2-\3", regex=True)
    return series


# ──────────────────────────────────────────────────────────────────────
# 10. outlier_detection
# ──────────────────────────────────────────────────────────────────────

@register_step("outlier_detection")
def outlier_detection(
    df: pd.DataFrame,
    columns: Optional[List[str]] = None,
    method: str = "iqr",
    action: str = "remove", # remove, clip, or move_to_bottom
    threshold: float = 1.5,
    min_val: Optional[float] = None,
    max_val: Optional[float] = None,
    **params,
) -> pd.DataFrame:
    """Detect and handle numerical outliers using IQR, Z-score, or Manual Range."""
    if not columns:
        return df
    df = df.copy()
    try:
        mask = pd.Series(True, index=df.index)
        for col in columns:
            if col not in df.columns or not pd.api.types.is_numeric_dtype(df[col]):
                continue
            if method == "iqr":
                q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
                iqr = q3 - q1
                lower, upper = q1 - threshold * iqr, q3 + threshold * iqr
                if action == "remove":
                    mask &= (df[col] >= lower) & (df[col] <= upper)
                else:
                    df[col] = df[col].clip(lower, upper)
            elif method == "zscore":
                mu, sigma = df[col].mean(), df[col].std()
                z = (df[col] - mu) / sigma
                if action == "remove":
                    mask &= z.abs() <= threshold
                else:
                    df[col] = df[col].clip(mu - threshold * sigma, mu + threshold * sigma)
            elif method == "manual":
                lower = min_val if min_val is not None else -np.inf
                upper = max_val if max_val is not None else np.inf
                if action == "remove":
                    mask &= (df[col] >= lower) & (df[col] <= upper)
                elif action == "clip":
                    df[col] = df[col].clip(lower, upper)
                elif action == "move_to_bottom":
                    outlier_mask = (df[col] < lower) | (df[col] > upper)
                    if outlier_mask.any():
                        if "_aidatapilot_status" not in df.columns:
                            df["_aidatapilot_status"] = np.nan
                        df["_aidatapilot_status"] = df["_aidatapilot_status"].astype(object)
                        df.loc[outlier_mask, "_aidatapilot_status"] = f"Outlier: {col}"
                        logger.debug(f"outlier_detection: flagged {outlier_mask.sum()} rows in '{col}' as outliers.")

        if action == "remove":
            df = df[mask]
    except Exception as e:
        logger.warning(f"outlier_detection: silent recovery: {e}")
    return df


# ──────────────────────────────────────────────────────────────────────
# 11. segregate_outliers
# ──────────────────────────────────────────────────────────────────────

@register_step("segregate_outliers")
def segregate_outliers(df: pd.DataFrame, drop_status: bool = True, **params) -> pd.DataFrame:
    """Move rows marked in _aidatapilot_status to the bottom."""
    if "_aidatapilot_status" not in df.columns:
        return df
    
    try:
        # Push rows with any status (Unknown Name, Outliers) to the bottom
        mask_any_status = df["_aidatapilot_status"].notnull()
        if mask_any_status.any():
            # Use concat for reliable reordering
            df = pd.concat([
                df[~mask_any_status], 
                df[mask_any_status]
            ], ignore_index=True)
        
        # Cleanup internal column from final output
        if drop_status:
            df = df.drop(columns=["_aidatapilot_status"], errors="ignore")

    except Exception as e:
        logger.warning(f"segregate_outliers: recovery: {e}")

    return df


# ──────────────────────────────────────────────────────────────────────
# 12. group_impute
# ──────────────────────────────────────────────────────────────────────

@register_step("group_impute")
def group_impute(
    df: pd.DataFrame,
    target_column: str,
    group_column: str,
    strategy: str = "median",
    treat_zero_as_null: bool = True,
    **params,
) -> pd.DataFrame:
    """Fill nulls (and optionally zeros) in a column using a group statistic.
    
    Example: Fill Salary (target) based on Department (group).
    """
    if target_column not in df.columns or group_column not in df.columns:
        return df
    df = df.copy()
    try:
        # Temporarily convert 0 to NaN if requested, to allow proper statistic calculation
        if treat_zero_as_null:
            df[target_column] = df[target_column].replace(0, np.nan)

        if strategy == "median":
            df[target_column] = df[target_column].fillna(
                df.groupby(group_column)[target_column].transform("median")
            )
        elif strategy == "mean":
            df[target_column] = df[target_column].fillna(
                df.groupby(group_column)[target_column].transform("mean")
            )
        elif strategy == "mode":
            def get_mode(x):
                m = x.dropna().mode()
                return m.iloc[0] if not m.empty else np.nan
            df[target_column] = df[target_column].fillna(
                df.groupby(group_column)[target_column].transform(get_mode)
            )
        
        # Final fallback to global median
        if df[target_column].isnull().any():
            df[target_column] = df[target_column].fillna(df[target_column].median())
        
        # If we still have NaNs (e.g. all values in a group were null/zero), return to 0 or leave as is
        df[target_column] = df[target_column].fillna(0)
            
    except Exception as e:
        logger.warning(f"group_impute: silent recovery: {e}")
    return df


# ──────────────────────────────────────────────────────────────────────
# 12. encode_categorical
# ──────────────────────────────────────────────────────────────────────

@register_step("encode_categorical")
def encode_categorical(
    df: pd.DataFrame,
    columns: Optional[List[str]] = None,
    method: str = "label",
    **params,
) -> pd.DataFrame:
    """Encode text columns into numerical values."""
    if not columns:
        return df
    df = df.copy()
    try:
        for col in columns:
            if col in df.columns:
                # MANDATORY: Convert to string first to handle mixed types/nulls smoothly
                df[col] = df[col].astype(str).astype("category").cat.codes
    except Exception as e:
        logger.warning(f"encode_categorical: silent recovery: {e}")
    return df


# ──────────────────────────────────────────────────────────────────────
# 12. scale_numeric
# ──────────────────────────────────────────────────────────────────────

@register_step("scale_numeric")
def scale_numeric(
    df: pd.DataFrame,
    columns: Optional[List[str]] = None,
    method: str = "minmax",
    **params,
) -> pd.DataFrame:
    """Scale numeric columns to a specific range."""
    if not columns:
        return df
    df = df.copy()
    try:
        for col in columns:
            if col not in df.columns or not pd.api.types.is_numeric_dtype(df[col]):
                continue
            if method == "minmax":
                mi, ma = df[col].min(), df[col].max()
                if ma > mi:
                    df[col] = (df[col] - mi) / (ma - mi)
            elif method == "standard":
                # Z-Score Scaling
                mu, sigma = df[col].mean(), df[col].std()
                if sigma > 0:
                    df[col] = (df[col] - mu) / sigma
                else:
                    df[col] = 0.0 # Constant column
    except Exception as e:
        logger.warning(f"scale_numeric: silent recovery: {e}")
    return df


# ──────────────────────────────────────────────────────────────────────
# 13. feature_engine
# ──────────────────────────────────────────────────────────────────────

@register_step("feature_engine")
def feature_engine(
    df: pd.DataFrame,
    output_column: str,
    operation: str,
    columns: List[str],
    **params,
) -> pd.DataFrame:
    """Create a new feature based on arithmetic operations."""
    if len(columns) != 2:
        return df
    df = df.copy()
    try:
        col1, col2 = columns
        if col1 in df.columns and col2 in df.columns:
            if operation == "add":
                df[output_column] = df[col1] + df[col2]
            elif operation == "sub":
                df[output_column] = df[col1] - df[col2]
            elif operation == "mul":
                df[output_column] = df[col1] * df[col2]
            elif operation == "div":
                df[output_column] = df[col1] / df[col2]
    except Exception as e:
        logger.warning(f"feature_engine: silent recovery: {e}")
    return df
# ──────────────────────────────────────────────────────────────────────
# 14. clean_text
# ──────────────────────────────────────────────────────────────────────

@register_step("clean_text")
def clean_text(
    df: pd.DataFrame,
    columns: Optional[List[str]] = None,
    lowercase: bool = True,
    remove_extra_whitespace: bool = True,
    **params,
) -> pd.DataFrame:
    """Basic text cleaning for NLP/LLM tasks."""
    if not columns:
        return df
    df = df.copy()
    try:
        for col in columns:
            if col not in df.columns or df[col].dtype != "object":
                continue
            series = df[col].astype(str)
            if lowercase:
                series = series.str.lower()
            if remove_extra_whitespace:
                series = series.str.replace(r"\s+", " ", regex=True).str.strip()
            df[col] = series
    except Exception as e:
        logger.warning(f"clean_text: silent recovery: {e}")
    return df


# ──────────────────────────────────────────────────────────────────────
# 15. chunk_text
# ──────────────────────────────────────────────────────────────────────

@register_step("chunk_text")
def chunk_text(
    df: pd.DataFrame,
    column: str,
    chunk_size: int = 500,
    chunk_overlap: int = 50,
    **params,
) -> pd.DataFrame:
    """Split long text into smart, context-aware overlapping chunks."""
    try:
        target_column = _resolve_text_column(df, column)
        chunked_rows = []
        
        for idx, row in df.iterrows():
            text = str(row.get(target_column, "")) if pd.notnull(row.get(target_column)) else ""
            source_val = _identify_source(row)
            summary_header, context_str = _generate_row_context(row, target_column, source_val)
            safe_source = _sanitize_filename(source_val)

            # Fallback for empty or null entries
            if not text.strip() or text.strip().lower() in ["null", "nan", "none"]:
                chunked_rows.append(_build_chunk_row(idx, source_val, context_str, summary_header, 1, f"{safe_source}_no_content.txt"))
                continue

            # Sentence-aware word-based chunking
            chunks = _split_into_chunks(text, chunk_size, chunk_overlap)
            for i, chunk_content in enumerate(chunks, 1):
                # Metadata-Enriched Prompt
                enriched = f"{summary_header}\n\n[Record ID: {idx} | Chunk: {i}/{len(chunks)}]\n{chunk_content}"
                filename = f"{safe_source}_chunk_{i}.txt"
                chunked_rows.append(_build_chunk_row(idx, source_val, context_str, enriched, i, filename))
                
        return pd.DataFrame(chunked_rows)
    except Exception as e:
        logger.warning(f"chunk_text: silent recovery: {e}")
        return pd.DataFrame()

def _resolve_text_column(df: pd.DataFrame, preferred: str) -> Optional[str]:
    # Case-insensitive column lookup
    cols_lower = {col.lower(): col for col in df.columns}
    
    if preferred and preferred.lower() in cols_lower:
        return cols_lower[preferred.lower()]
    
    fallbacks = ["description", "content", "comments", "text", "body"]
    for fallback in fallbacks:
        if fallback in cols_lower:
            return cols_lower[fallback]
    return None

def _identify_source(row: pd.Series) -> str:
    # Case-insensitive source column lookup
    potential = ["name", "product_name", "customer_name", "title", "sku"]
    cols_lower = {col.lower(): col for col in row.index}
    
    for p in potential:
        if p in cols_lower:
            col = cols_lower[p]
            if pd.notnull(row[col]):
                val = str(row[col]).strip()
                if val.lower() not in ["null", "unknown_id", "none", "nan", ""]:
                    return val
    return "unknown"

def _generate_row_context(row: pd.Series, target_col: Optional[str], source: str) -> tuple[str, str]:
    parts = []
    ctx_items = []
    for k, v in row.items():
        if k != target_col and pd.notnull(v) and str(v).lower() != "null":
            clean_k = str(k).replace("_", " ").title()
            parts.append(f"{clean_k} is {v}")
            ctx_items.append(f"{k}: {v}")
    
    # Generate context header with wrapper
    if parts:
        header = f"[Context: This record for {source} shows that {', '.join(parts)}.]"
    else:
        header = f"[Context: This record for {source}.]"
    return header, " | ".join(ctx_items)

def _sanitize_filename(name: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in name).lower()[:30]

def _build_chunk_row(idx, source, context, chunk, index, filename):
    return {
        "row_id": idx, "source": source, "context": context,
        "chunk": chunk, "chunk_index": index, "chunk_filename": filename
    }

def _split_into_chunks(text: str, size_in_words: int, overlap_in_words: int) -> List[str]:
    """Helper to split text into word-based chunks that respect sentence boundaries."""
    words = text.split()
    chunks = []
    
    # 1. Edge case: Text is smaller than chunk size
    if len(words) <= size_in_words:
        return [text]
        
    # 2. Iterate and split
    start = 0
    while start < len(words):
        end = start + size_in_words
        
        # If not the last chunk, try to find the nearest sentence boundary (., !, ?)
        if end < len(words):
            # Look back from the end to find a boundary
            search_window = words[max(start, end - 10):end]
            boundary_idx = -1
            for i, word in enumerate(reversed(search_window)):
                if any(p in word for p in [".", "!", "?"]):
                    boundary_idx = len(search_window) - 1 - i
                    break
            
            if boundary_idx != -1:
                end = max(start + 1, end - (len(search_window) - 1 - boundary_idx))
        
        chunk_words = words[start:end]
        chunks.append(" ".join(chunk_words))
        
        if end >= len(words):
            break
            
        start = max(start + 1, end - overlap_in_words)
        
    return chunks


# ──────────────────────────────────────────────────────────────────────
# 16. generate_metadata
# ──────────────────────────────────────────────────────────────────────

@register_step("generate_metadata")
def generate_metadata(df: pd.DataFrame, column: str, **params) -> pd.DataFrame:
    """Generate basic metadata (length, word count)."""
    if column not in df.columns:
        return df
    df = df.copy()
    try:
        series = df[column].astype(str)
        df[f"{column}_length"] = series.str.len()
        
        word_counts = series.str.split().str.len()
        df[f"{column}_word_count"] = word_counts
        
        # PROACTIVE FEATURE: Est. Reading Time (Assuming 200 words/min)
        df[f"{column}_reading_time_sec"] = (word_counts / 200 * 60).round(1)
        
    except Exception as e:
        logger.warning(f"generate_metadata: silent recovery: {e}")
    return df

@register_step("extract_date_features")
def extract_date_features(df: pd.DataFrame, columns: Optional[List[str]] = None, **params) -> pd.DataFrame:
    """Extract year, month, day, day_of_week."""
    if not columns:
        return df
    df = df.copy()
    try:
        for col in columns:
            if col not in df.columns:
                continue
            dt_series = pd.to_datetime(df[col], errors="coerce")
            df[f"{col}_year"] = dt_series.dt.year
            df[f"{col}_month"] = dt_series.dt.month
            df[f"{col}_day"] = dt_series.dt.day
            df[f"{col}_dayofweek"] = dt_series.dt.dayofweek
    except Exception as e:
        logger.warning(f"extract_date_features: silent recovery: {e}")
    return df

@register_step("drop_columns")
def drop_columns(df: pd.DataFrame, columns: List[str], **params) -> pd.DataFrame:
    """Remove specific columns from the DataFrame."""
    try:
        return df.drop(columns=columns, errors="ignore")
    except Exception as e:
        logger.warning(f"drop_columns: recovery: {e}")
        return df


# Builder Aliases (v0.2.4)
# ──────────────────────────────────────────────────────────────────────
from aidatapilot.core.registry import StepRegistry

StepRegistry.register_alias("missing_nulls", "handle_missing_data")
StepRegistry.register_alias("zero_values", "fill_nulls") # Defaults to strategy='auto' in step
StepRegistry.register_alias("outliers", "segregate_outliers")
StepRegistry.register_alias("empty_strings", "clean_text")
StepRegistry.register_alias("normalize", "normalize_columns")
StepRegistry.register_alias("duplicates", "deduplicate")
StepRegistry.register_alias("ids", "interpolate_ids")
StepRegistry.register_alias("types", "infer_types")
StepRegistry.register_alias("analytics", "basic_aggregation")
