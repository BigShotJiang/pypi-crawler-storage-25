"""
Validation Engine
------------------
Pre-pipeline validators that emit warnings or raise errors.
Schema validation checks required columns and dtypes.
NullThreshold validation warns when data quality is low.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import pandas as pd


@dataclass
class ValidationResult:
    """Result of a validation run.

    Attributes:
        passed: ``True`` if no hard errors were raised.
        warnings: Non-fatal observations.
        errors: Hard constraint violations.
    """

    passed: bool
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    def __bool__(self) -> bool:
        return self.passed


class SchemaValidator:
    """Validate a DataFrame against a column schema.

    Args:
        required_columns: Column names that must be present.
        dtypes: Mapping of column name → expected dtype string.
            Only checks presence of dtype family (numeric, object, datetime).

    Example::

        v = SchemaValidator(required_columns=["id", "name"])
        result = v.validate(df)
        if not result.passed:
            for err in result.errors:
                print("ERROR:", err)
    """

    def __init__(
        self,
        required_columns: Optional[List[str]] = None,
        dtypes: Optional[Dict[str, str]] = None,
    ) -> None:
        self.required_columns = required_columns or []
        self.dtypes = dtypes or {}

    def validate(self, df: pd.DataFrame) -> ValidationResult:
        """Run schema validation on *df*.

        Returns:
            :class:`ValidationResult` with warnings and errors.
        """
        errors: List[str] = []
        warnings: List[str] = []

        # Required column checks
        for col in self.required_columns:
            if col not in df.columns:
                errors.append(f"Required column '{col}' is missing.")

        # Dtype family checks
        for col, expected in self.dtypes.items():
            if col not in df.columns:
                continue  # Already caught above
            actual = df[col].dtype
            if expected in ("int", "float", "numeric"):
                if not pd.api.types.is_numeric_dtype(actual):
                    warnings.append(
                        f"Column '{col}' expected numeric dtype, "
                        f"got '{actual}'."
                    )
            elif expected in ("str", "string", "object"):
                if not pd.api.types.is_object_dtype(actual) and not pd.api.types.is_string_dtype(actual):
                    warnings.append(
                        f"Column '{col}' expected string dtype, "
                        f"got '{actual}'."
                    )
            elif expected in ("datetime", "date"):
                if not pd.api.types.is_datetime64_any_dtype(actual):
                    warnings.append(
                        f"Column '{col}' expected datetime dtype, "
                        f"got '{actual}'."
                    )

        return ValidationResult(
            passed=len(errors) == 0,
            warnings=warnings,
            errors=errors,
        )


class NullThresholdValidator:
    """Warn when columns have high percentages of null values.

    Args:
        threshold: Warn when a column's null fraction exceeds this value.
            Default ``0.8`` (warn if 80%+ of values are null).

    Example::

        v = NullThresholdValidator(threshold=0.5)
        result = v.validate(df)
        for w in result.warnings:
            print("WARN:", w)
    """

    def __init__(self, threshold: float = 0.8) -> None:
        self.threshold = threshold

    def validate(self, df: pd.DataFrame) -> ValidationResult:
        """Run null-threshold validation on *df*.

        Returns:
            :class:`ValidationResult` with warnings for high-null columns.
        """
        warnings: List[str] = []
        for col in df.columns:
            null_frac = df[col].isnull().mean()
            if null_frac > self.threshold:
                warnings.append(
                    f"Column '{col}' is {null_frac:.0%} null "
                    f"(threshold: {self.threshold:.0%}). Consider dropping it."
                )
        return ValidationResult(passed=True, warnings=warnings)


class DataQualityValidator:
    """Composite validator: runs both schema and null-threshold checks.

    Args:
        required_columns: Required column list forwarded to :class:`SchemaValidator`.
        dtypes: Dtype mapping forwarded to :class:`SchemaValidator`.
        null_threshold: Null fraction forwarded to :class:`NullThresholdValidator`.
    """

    def __init__(
        self,
        required_columns: Optional[List[str]] = None,
        dtypes: Optional[Dict[str, str]] = None,
        null_threshold: float = 0.8,
    ) -> None:
        self._schema = SchemaValidator(required_columns, dtypes)
        self._nulls = NullThresholdValidator(null_threshold)

    def validate(self, df: pd.DataFrame) -> ValidationResult:
        """Run all validators and combine results."""
        r1 = self._schema.validate(df)
        r2 = self._nulls.validate(df)
        return ValidationResult(
            passed=r1.passed and r2.passed,
            warnings=r1.warnings + r2.warnings,
            errors=r1.errors + r2.errors,
        )

