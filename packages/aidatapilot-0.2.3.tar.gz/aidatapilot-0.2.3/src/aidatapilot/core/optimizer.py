"""
Runtime Optimizer
-----------------
Intelligently decide execution strategies (batching, memory mode, etc.)
based on dataset size and available system resources.
"""

from __future__ import annotations

import os

try:
    import psutil
except ImportError:
    psutil = None
    
from dataclasses import dataclass
from typing import Optional

import pandas as pd


@dataclass
class OptimizationStrategy:
    """Settings decided by the optimizer."""
    chunked_reading: bool = False
    batch_size: Optional[int] = None
    memory_save_mode: bool = False
    parallel_fallback: bool = True
    use_sequential: bool = False


class RuntimeOptimizer:
    """Heuristic engine for performance tuning."""

    def __init__(self, df: Optional[pd.DataFrame] = None, file_path: Optional[str] = None):
        self.df = df
        self.file_path = file_path
        self._stats = {"rows": 0, "size_mb": 0}

    def profile(self) -> dict:
        """Measure dataset 'weight'."""
        if self.df is not None:
             self._stats["rows"] = len(self.df)
             self._stats["size_mb"] = self.df.memory_usage(deep=True).sum() / 1024**2
        elif self.file_path and os.path.exists(self.file_path):
             self._stats["size_mb"] = os.path.getsize(self.file_path) / 1024**2
             # Rough estimate for rows if file
             self._stats["rows"] = int(self._stats["size_mb"] * 5000) # heuristic
        
        return self._stats

    def decide_strategy(self) -> OptimizationStrategy:
        """Apply heuristics to pick the best execution mode."""
        stats = self.profile()
        rows = stats["rows"]
        size_mb = stats["size_mb"]
        
        # Get system memory safely
        if psutil:
            try:
                avail_mem_mb = psutil.virtual_memory().available / 1024**2
            except (AttributeError, TypeError):
                avail_mem_mb = 4096 # Fallback to 4GB
        else:
            avail_mem_mb = 4096 # Fallback to 4GB
        
        strategy = OptimizationStrategy()
        
        # Rule 1: Memory Safety
        # If dataset > 25% of available memory, trigger safety
        if size_mb > (avail_mem_mb * 0.25):
            strategy.memory_save_mode = True
            strategy.use_sequential = True # Parallel copies of large DFs cause crashes
            
        # Rule 2: Large Dataset (Chunking)
        # If > 500MB, suggest chunked processing (if connector supports it)
        if size_mb > 500:
            strategy.chunked_reading = True
            strategy.batch_size = 100000
            
        # Rule 3: Small Dataset Optimization
        # If < 1000 rows, sequential is usually faster (less overhead)
        if rows < 1000:
            strategy.use_sequential = True

        return strategy

