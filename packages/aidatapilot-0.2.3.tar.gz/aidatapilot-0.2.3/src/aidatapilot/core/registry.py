"""
Unified Registry Module
----------------------
A centralized, generic registry for all aidatapilot extension points.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Generic, List, Optional, Type, TypeVar
import pandas as pd

T = TypeVar("T")

class Registry(Generic[T]):
    """Generic registry for storing and retrieving components by name."""
    def __init__(self, name: str):
        self.name = name
        self._registry: Dict[str, T] = {}

    def register(self, name: str, item: T) -> None:
        self._registry[name.lower()] = item

    def get(self, name: str) -> Optional[T]:
        return self._registry.get(name.lower())

    def list(self) -> List[str]:
        return sorted(self._registry.keys())

    def register_alias(self, alias_name: str, target_name: str) -> None:
        """Register an alias for an existing item."""
        self._registry[alias_name.lower()] = target_name.lower()

@dataclass
class PipelineTemplate:
    """A pre-configured factory for processing steps."""
    name: str
    description: str
    factory: Callable[..., List[Any]]

# Global instances
ConnectorRegistry = Registry[Type[Any]]("Connectors")
PublisherRegistry = Registry[Type[Any]]("Publishers")
StepRegistry      = Registry[Callable]("Steps")
TemplateRegistry  = Registry[PipelineTemplate]("Templates")

def register_connector(name: str):
    def decorator(cls: Type[Any]) -> Type[Any]:
        ConnectorRegistry.register(name, cls)
        return cls
    return decorator

def register_publisher(name: str):
    def decorator(cls: Type[Any]) -> Type[Any]:
        PublisherRegistry.register(name, cls)
        return cls
    return decorator

def register_step(name: str):
    def decorator(fn: Callable) -> Callable:
        StepRegistry.register(name, fn)
        return fn
    return decorator

def register_template(name: str, description: Optional[str] = None):
    """Decorator to register a dynamic pipeline template factory."""
    def decorator(fn: Callable[..., List[Any]]) -> Callable:
        tpl = PipelineTemplate(
            name=name,
            description=description or fn.__doc__ or "No description",
            factory=fn
        )
        TemplateRegistry.register(name, tpl)
        return fn
    return decorator
