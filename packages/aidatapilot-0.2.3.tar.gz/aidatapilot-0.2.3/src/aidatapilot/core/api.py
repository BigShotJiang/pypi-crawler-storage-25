"""
aidatapilot Core API
-----------------
Consolidated API layer merging discovery, bootstrap, and one-liner helpers.
This is the internal implementation point for the 'Simple API' façade.
"""

from __future__ import annotations
import logging
from typing import TYPE_CHECKING, Optional, Union, List
import pandas as pd

if TYPE_CHECKING:
    from aidatapilot.core.pipeline import PipelineResult

logger = logging.getLogger("aidatapilot")

def bootstrap() -> None:
    """Import all built-in modules to trigger self-registration."""
    # Connectors & Publishers
    import aidatapilot.connectors.file
    import aidatapilot.publishers.file
    
    # Processors & Steps
    import aidatapilot.processors.steps
    
    # Templates
    import aidatapilot.templates.basic_clean
    import aidatapilot.templates.analytics_cleaning
    import aidatapilot.templates.ml_preprocess
    import aidatapilot.templates.llm_processing

def auto_clean(
    source: Union[str, pd.DataFrame],
    output: Optional[str] = None,
    template: str = "basic_clean",
    **kwargs,
) -> PipelineResult:
    """Internal implementation for one-line automation."""
    from aidatapilot.core.pipeline import Pipeline
    
    # Trigger registration
    try:
        custom_steps = kwargs.pop("steps", None)
        # Separate connector-specific kwargs from general step-params
        connector_keys = {"encoding", "sep", "delimiter", "skiprows", "on_bad_lines", "low_memory", "dtype"}
        connector_kwargs = {k: v for k, v in kwargs.items() if k in connector_keys}
        step_params = {k: v for k, v in kwargs.items() if k not in connector_keys}

        pipe = Pipeline(template=template, steps=custom_steps, step_params=step_params)
        
        if isinstance(source, pd.DataFrame):
            pipe.set_source(df=source)
        else:
            pipe.set_source(type="file", path=str(source), **connector_kwargs)
            
        if output:
            pipe.set_output(type="file", path=str(output))
        else:
            pipe.set_output(None)
            
        return pipe.run()
    except Exception as e:
        logger.error(f"auto_clean: global exception caught: {e}")
        from aidatapilot.core.pipeline import PipelineResult
        from aidatapilot.core.runtime import PipelineState
        return PipelineResult(
            success=False,
            state=PipelineState.FAILED.value,
            rows_in=0,
            rows_out=0,
            total_duration_seconds=0,
            warnings=[],
            step_reports=[],
            error=str(e),
            df=None
        )

def auto_pilot(source, output=None, **kwargs):
    """Placeholder for autonomous intelligence-driven cleaning."""
    return auto_clean(source, output, **kwargs)

def analyze_dataset(data: Union[str, pd.DataFrame]):
    """Public wrapper for the Intelligence Advisor."""
    from aidatapilot.intelligence.advisor import analyze_dataset as _analyze
    return _analyze(data)

def translate_text(
    data: Union[str, List[str], pd.DataFrame],
    target_lang: str = "en",
    source_lang: str = "auto",
    columns: Optional[List[str]] = None
):
    """Universal Translation Wrapper."""
    from aidatapilot.utils.translator import translate_text as _translate
    return _translate(data, target_lang=target_lang, source_lang=source_lang, columns=columns)

def plot_health(data: Union[str, pd.DataFrame], save_path: str = "data_health_report.png"):
    """Visual health check for datasets."""
    from aidatapilot.discovery import plot_health as _plot
    return _plot(data, save_path=save_path)
