"""
aidatapilot Adaptive Pipeline Builder 🚀
------------------------------------
Orchestrates profiling and rule-based decision logic to construct 
the optimal execution DAG for any dataset.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Union

import pandas as pd

from aidatapilot.core.pipeline import Pipeline
from aidatapilot.intelligence.analyzer import DatasetAnalyzer, ProfilingReport
from aidatapilot.intelligence.rules import RuleEngine
from aidatapilot.utils.logger import get_logger

logger = get_logger()

class AdaptiveBuilder:
    """The 'Architect' that builds custom pipelines from data profiles."""

    def __init__(self, data: Union[str, pd.DataFrame]):
        self.analyzer = DatasetAnalyzer(data)
        self.report: Optional[ProfilingReport] = None
        self._logger = logger

    def build(self) -> Pipeline:
        """Analyze data and construct a custom configured Pipeline."""
        self._logger.info("AdaptiveBuilder: Profiling dataset to determine strategy...")
        self.report = self.analyzer.profile()
        
        # Decide steps using Rule Engine
        self._logger.info(f"AdaptiveBuilder: Applying rules for {self.report.dataset_type} data...")
        engine = RuleEngine(self.report)
        steps = engine.decide()
        
        # Create the Pipeline
        pipeline = Pipeline(steps=steps)
        
        # Pass the report to the pipeline state if needed (optional)
        # We can store analysis metadata for the high-impact report
        self._logger.info(f"AdaptiveBuilder: Constructed execution DAG with {len(steps)} steps.")
        
        return pipeline

    def get_analysis_summary(self) -> Dict[str, Any]:
        """Return high-level summary for the Automation Decision Report."""
        if not self.report:
            return {}
            
        return {
            "dataset_type": self.report.dataset_type,
            "rows": self.report.rows,
            "cols": self.report.cols,
            "duplicates": self.report.duplicates,
            "has_target": self.report.has_target,
            "target_col": self.report.target_col,
            "critical_issues": [
                col for col, p in self.report.columns.items() if p.missing_ratio > 0.1 or p.has_outliers
            ]
        }
