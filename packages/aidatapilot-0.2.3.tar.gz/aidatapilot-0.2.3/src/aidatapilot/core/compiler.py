"""
Pipeline Compiler
-----------------
Converts a template + step config into an ordered list of DAGNodes.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import pandas as pd

@dataclass
class DAGNode:
    """A single node in the execution graph."""
    name: str
    params: Dict[str, Any] = field(default_factory=dict)
    parallel_group: Optional[int] = None

class PipelineCompiler:
    """Compiles a step list + dynamic template factory into an executable DAG."""

    def compile(
        self,
        steps: Optional[List[Dict[str, Any]]] = None,
        template: Optional[str] = None,
        step_params: Optional[Dict[str, Any]] = None,
        df: Optional[pd.DataFrame] = None,
    ) -> List[DAGNode]:
        """Return an ordered list of :class:`DAGNode` objects."""
        from aidatapilot.core.registry import TemplateRegistry

        step_params = step_params or {}
        raw_steps = []

        if template:
            tpl = TemplateRegistry.get(template)
            if tpl is None:
                available = ", ".join(TemplateRegistry.list())
                raise ValueError(f"Unknown template '{template}'. Available: {available}")
            
            # Dynamic Template Factory Call
            raw_steps.extend(tpl.factory(df=df, **step_params))
            
        if steps:
            raw_steps.extend(steps)
            
        if not raw_steps:
            raise ValueError("Compiler needs at least a 'template' or 'steps'.")

        nodes: List[DAGNode] = []
        for i, step in enumerate(raw_steps):
            if isinstance(step, str):
                name, params, group = step, {}, None
            elif isinstance(step, dict):
                name = step["name"]
                params = step.get("params", {})
                group = step.get("parallel_group", None)
            else:
                raise TypeError(f"Step at index {i} invalid type: {type(step).__name__}.")

            merged = {**step_params, **params}
            
            # Recursive Alias Resolution (v0.2.4)
            from aidatapilot.core.registry import StepRegistry
            resolved_name = name
            visited = set()
            while resolved_name and resolved_name.lower() in StepRegistry._registry:
                val = StepRegistry.get(resolved_name)
                if isinstance(val, str): # It's an alias
                    if val in visited: break # Prevent cycles
                    visited.add(val)
                    resolved_name = val
                else:
                    break
            
            nodes.append(DAGNode(name=resolved_name, params=merged, parallel_group=group))

        return nodes
