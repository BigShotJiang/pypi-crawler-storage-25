"""
Visual Health Reporting Engine
-----------------------------
Automated chart generation and visualization for BI insights.
"""

from __future__ import annotations
import os
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional

class HealthVisualizer:
    """Generates professional visual reports for data health."""

    def __init__(self, df: pd.DataFrame):
        self.df = df
        # Professional AIDataPilot Theme
        plt.style.use('bmh')
        sns.set_palette("viridis")

    def generate_report(self, health_score: int, save_path: str = "data_health_report.png") -> str:
        """Create a consolidated multi-chart report."""
        # 1. Setup multi-panel layout
        fig = plt.figure(figsize=(12, 10))
        gs = fig.add_gridspec(3, 2)
        
        # --- PANEL A: Health Gauge ---
        ax_gauge = fig.add_subplot(gs[0, :])
        self._plot_gauge(ax_gauge, health_score)

        # --- PANEL B: Top Numeric Distributions ---
        numeric_cols = self.df.select_dtypes(include=['number']).columns[:4]
        for i, col in enumerate(numeric_cols):
            ax = fig.add_subplot(gs[1 + (i // 2), i % 2])
            sns.histplot(self.df[col], kde=True, ax=ax, color='teal')
            ax.set_title(f"Distribution: {col}", fontsize=10)
            ax.set_ylabel("")

        plt.tight_layout(pad=3.0)
        plt.savefig(save_path, dpi=150)
        plt.close()
        return save_path

    def _plot_gauge(self, ax, score: int):
        """Draw a custom Gauge/Meter for the Health Score."""
        # Clean background
        ax.set_xlim(-1.5, 1.5)
        ax.set_ylim(-0.5, 1.5)
        ax.axis('off')

        # Draw semi-circle arc
        theta = np.linspace(0, np.pi, 100)
        r = 1.0
        x = r * np.cos(theta)
        y = r * np.sin(theta)
        ax.plot(x, y, color='silver', linewidth=15, alpha=0.3)

        # Color the arc based on score
        color = 'red' if score < 40 else ('orange' if score < 70 else 'limegreen')
        theta_score = (score / 100) * np.pi
        theta_filled = np.linspace(np.pi, np.pi - theta_score, 100)
        ax.plot(r * np.cos(theta_filled), r * np.sin(theta_filled), color=color, linewidth=18)

        # Draw the needle
        angle = np.pi - theta_score
        ax.arrow(0, 0, 0.8 * np.cos(angle), 0.8 * np.sin(angle), 
                 width=0.03, head_width=0.1, head_length=0.1, fc='black', ec='black')
        
        # Text center
        ax.text(0, 0.2, f"{score}", fontsize=40, fontweight='bold', ha='center', color=color)
        ax.text(0, -0.1, "DATASET HEALTH SCORE", fontsize=14, fontweight='bold', ha='center')
        
        # Legend
        ax.text(-1, 0, "0", ha='center', fontsize=12)
        ax.text(1, 0, "100", ha='center', fontsize=12)
