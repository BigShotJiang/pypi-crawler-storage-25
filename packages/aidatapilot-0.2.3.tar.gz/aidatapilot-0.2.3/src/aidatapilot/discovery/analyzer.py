"""
Advanced Analytics Analyzer
--------------------------
Core logic for automated EDA and Health Scoring.
"""

from __future__ import annotations
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional

class AdvancedAnalyzer:
    """Exploratory Data Analysis (EDA) Engine."""

    def __init__(self, df: pd.DataFrame):
        self.df = df

    def profile(self) -> Dict[str, Any]:
        """Generate a complete statistical profile of the dataset."""
        rows, cols = self.df.shape
        
        # 1. Summary Statistics (7-point summary)
        numeric_df = self.df.select_dtypes(include=['number'])
        summary = numeric_df.describe().to_dict() if not numeric_df.empty else {}
        
        # 2. Correlation Matrix
        correlation = numeric_df.corr().to_dict() if not numeric_df.empty else {}
        
        # 3. Cardinality (Categorical)
        cat_df = self.df.select_dtypes(exclude=['number'])
        cardinality = {c: self.df[c].nunique() for c in cat_df.columns}
        
        # 4. Missingness
        null_counts = self.df.isnull().sum().to_dict()
        null_rates = (self.df.isnull().mean() * 100).to_dict()
        
        # 5. Health Score
        score, insights = self.calculate_health_score()
        
        return {
            "shape": {"rows": rows, "cols": cols},
            "summary": summary,
            "correlation": correlation,
            "cardinality": cardinality,
            "null_rates": null_rates,
            "health_score": score,
            "insights": insights
        }

    def calculate_health_score(self) -> tuple[int, List[str]]:
        """Proprietary 0-100 Dataset Health Scoring logic."""
        score = 100
        insights = []
        
        # A. Missing Data Penalty
        null_rate = self.df.isnull().mean().mean()
        if null_rate > 0:
            penalty = min(30, int(null_rate * 100))
            score -= penalty
            insights.append(f"Missing Data: {null_rate:.1%} of cells are empty (-{penalty} pts).")
            
        # B. Outlier Penalty (Z > 3)
        numeric_df = self.df.select_dtypes(include=['number'])
        if not numeric_df.empty:
            outlier_rate = 0
            for col in numeric_df.columns:
                z_scores = np.abs((numeric_df[col] - numeric_df[col].mean()) / numeric_df[col].std())
                outlier_rate += (z_scores > 3).mean()
            outlier_rate /= len(numeric_df.columns)
            
            if outlier_rate > 0.01:
                penalty = min(20, int(outlier_rate * 500))
                score -= penalty
                insights.append(f"High Outliers: {outlier_rate:.1%} of numeric data is skewed (-{penalty} pts).")

        # C. Duplicate Penalty
        dup_rate = self.df.duplicated().mean()
        if dup_rate > 0:
            penalty = min(10, int(dup_rate * 100))
            score -= penalty
            insights.append(f"Duplicates Detected: {dup_rate:.1%} of rows are redundant (-{penalty} pts).")

        return max(0, score), insights
