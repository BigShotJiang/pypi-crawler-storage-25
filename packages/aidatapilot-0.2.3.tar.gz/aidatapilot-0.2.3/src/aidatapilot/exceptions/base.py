"""
aidatapilot Exception Hierarchy
---------------------------
Professional, domain-specific exceptions for better error handling and debugging.
"""

class aidatapilotError(Exception):
    """Base exception for all aidatapilot errors."""
    pass

class PipelineError(aidatapilotError):
    """Raised when a pipeline execution fails."""
    pass

class ConnectorError(aidatapilotError):
    """Raised when data source connection or reading fails."""
    pass

class ValidationError(aidatapilotError):
    """Raised when dataset validation fails."""
    pass

class TemplateError(aidatapilotError):
    """Raised when a template is invalid or missing."""
    pass

class OptimizerError(aidatapilotError):
    """Raised when the runtime optimizer encounters a failure."""
    pass

