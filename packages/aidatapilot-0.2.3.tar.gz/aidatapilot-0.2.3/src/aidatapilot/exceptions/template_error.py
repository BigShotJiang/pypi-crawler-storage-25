from aidatapilot.exceptions.base import aidatapilotError


class TemplateError(aidatapilotError):
    """Raised when a template is invalid, missing, or fails to compile."""
    pass

