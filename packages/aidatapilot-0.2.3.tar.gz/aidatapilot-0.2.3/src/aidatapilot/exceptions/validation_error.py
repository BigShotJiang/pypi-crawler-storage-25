from aidatapilot.exceptions.base import aidatapilotError


class ValidationError(aidatapilotError):
    """Raised when dataset validation fails."""
    pass

