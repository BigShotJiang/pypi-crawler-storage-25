from aidatapilot.exceptions.base import aidatapilotError


class ConnectorError(aidatapilotError):
    """Raised when data source connection or reading fails."""
    pass

