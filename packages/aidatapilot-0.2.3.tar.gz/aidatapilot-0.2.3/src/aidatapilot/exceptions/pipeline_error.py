from aidatapilot.exceptions.base import aidatapilotError


class PipelineError(aidatapilotError):
    """Raised when a pipeline execution fails or is misconfigured."""
    pass

