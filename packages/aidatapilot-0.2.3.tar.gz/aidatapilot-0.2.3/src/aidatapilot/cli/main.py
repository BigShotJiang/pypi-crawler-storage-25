"""
aidatapilot CLI
-------------
Entry point: `aidatapilot`
"""

from __future__ import annotations

import sys

import click

from aidatapilot.version import __version__


@click.group()
@click.version_option(__version__, "--version", "-V", message="aidatapilot %(version)s")
def cli() -> None:
    """aidatapilot — Lightweight Intelligent Data Automation Engine."""


@cli.command("run")
@click.argument("config_file", type=click.Path(exists=True, dir_okay=False))
@click.option("--dry-run", is_flag=True, help="Compile the pipeline without executing it.")
def run_command(config_file: str, dry_run: bool) -> None:
    """Run a pipeline defined in CONFIG_FILE (YAML)."""
    _bootstrap()

    from aidatapilot.core.pipeline import Pipeline
    from aidatapilot.utils.config import ConfigManager

    cfg = ConfigManager.load(config_file)

    template     = cfg.get("template", "basic_clean")
    source_cfg   = cfg.get("source", {})
    output_cfg   = cfg.get("output", {})
    steps        = cfg.get("steps", None)
    max_retries  = int(cfg.get("max_retries", 1))
    step_params  = cfg.get("step_params", {})

    if dry_run:
        from aidatapilot.core.compiler import PipelineCompiler
        nodes = PipelineCompiler().compile(steps=steps, template=template, step_params=step_params)
        print(f"\nDry run — {len(nodes)} step(s) would execute:\n")
        for i, n in enumerate(nodes, 1):
            print(f"  {i}. {n.name}  {n.params or ''}")
        print()
        return

    pipe = Pipeline(
        template=template if not steps else None,
        steps=steps,
        max_retries=max_retries,
        step_params=step_params,
    )
    pipe.set_source(**source_cfg)
    pipe.set_output(**output_cfg)
    result = pipe.run()

    sys.exit(0 if result.success else 1)


@cli.command("info")
def info_command() -> None:
    """Show version, registered templates, and available steps."""
    _bootstrap()

    from aidatapilot.core.registry import (
        ConnectorRegistry,
        PublisherRegistry,
        StepRegistry,
        TemplateRegistry,
    )

    print("-" * 40)
    print(f"aidatapilot v{__version__}")
    print("-" * 40)

    print("\nBuilt-in Templates:")
    for name, tpl in TemplateRegistry.all().items():
        print(f"  - {name:<15} {tpl.description}")

    steps = StepRegistry.list()
    print(f"\nRegistered Steps ({len(steps)}):")
    for s in steps:
        print(f"  - {s}")

    print(f"\nConnectors  : {', '.join(ConnectorRegistry.list())}")
    print(f"Publishers  : {', '.join(PublisherRegistry.list())}\n")


@cli.command("profile")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
def profile_command(file: str) -> None:
    """Print a data profile for FILE."""
    _bootstrap()
    from aidatapilot.connectors.file import FileConnector
    from aidatapilot.utils.profiler import DataProfiler

    connector = FileConnector(path=file)
    connector.connect()
    df = connector.read()
    connector.close()

    profiler = DataProfiler()
    report = profiler.profile(df)
    profiler.print_report(report)


@cli.command("version")
def version_command() -> None:
    """Print the version of aidatapilot."""
    print(f"aidatapilot v{__version__}")


@cli.command("analyze")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
def analyze_command(file: str) -> None:
    """Run the Intelligence Advisor on a dataset."""
    _bootstrap()
    from aidatapilot.intelligence.advisor import analyze_dataset
    analyze_dataset(file)


def _bootstrap() -> None:
    """Import all modules that self-register built-ins."""
    import aidatapilot.connectors.file
    import aidatapilot.processors.steps
    import aidatapilot.publishers.file
    import aidatapilot.templates.analytics_cleaning
    import aidatapilot.templates.basic_clean
    import aidatapilot.templates.llm_processing
    import aidatapilot.templates.ml_preprocess  # noqa: F401


if __name__ == "__main__":
    cli()
