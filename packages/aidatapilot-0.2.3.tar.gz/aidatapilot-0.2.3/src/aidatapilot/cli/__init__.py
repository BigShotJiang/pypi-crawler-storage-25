"""CLI package init."""

