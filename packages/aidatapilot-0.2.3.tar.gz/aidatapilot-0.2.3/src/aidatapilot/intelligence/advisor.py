"""
aidatapilot Advisor
-------------------
Proactive dataset analysis and high-precision suggestion engine.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Union, Dict, Any, List, Optional
import pandas as pd
import numpy as np

from aidatapilot.utils.logger import get_logger
from aidatapilot.utils.internal import is_id_column, smart_numeric_parse

logger = get_logger()

@dataclass
class AdvisorReport:
    """Structured diagnostic result from the Advisor."""
    row_count: int
    column_count: int
    null_count: int
    outlier_count: int
    readiness_score: int
    suggestions: List[str]
    diagnostics: Dict[str, Any]
    df: pd.DataFrame = field(repr=False)

class Advisor:
    """Analyzes datasets and provides actionable processing recommendations."""

    def __init__(self, data: Optional[Union[str, pd.DataFrame]] = None):
        self._df = self._ensure_df(data) if data is not None else None

    def _ensure_df(self, data) -> pd.DataFrame:
        if isinstance(data, pd.DataFrame):
            return data
        from aidatapilot.connectors.file import FileConnector
        return FileConnector(data).connect().read()

    def analyze(self, data: Optional[Union[str, pd.DataFrame]] = None) -> AdvisorReport:
        """Perform high-precision diagnostics and generate a cleaning recipe."""
        df = self._ensure_df(data) if data is not None else self._df
        
        if df is None:
            raise ValueError("No data provided to Advisor. Pass data to __init__ or analyze().")

        rows, cols = df.shape
        
        # 1. Semantic Mapping & Metadata
        semantic_map = {}
        for col in df.columns:
            if is_id_column(col):
                semantic_map[col] = "IDENTITY (ID)"
            elif "date" in col.lower() or "time" in col.lower():
                semantic_map[col] = "TEMPORAL (DATE)"
            elif pd.api.types.is_numeric_dtype(df[col]):
                semantic_map[col] = "NUMERIC (QUANTITY)"
            else:
                semantic_map[col] = "CATEGORICAL (LABEL/TEXT)"

        # 2. Basic Counts (Nulls)
        null_map = df.isnull().sum().to_dict()
        total_nulls = sum(null_map.values())
        
        # 3. Semantic Missingness (Empty Strings / Placeholders)
        empty_str_map = {}
        placeholder_patterns = ["", "null", "nan", "none", "n/a", "-", "invalid", "unknown"]
        for col in df.columns:
            series_str = df[col].astype(str).str.strip().str.lower()
            empty_mask = series_str.isin(placeholder_patterns)
            empty_count = int(empty_mask.sum())
            if empty_count > 0:
                empty_str_map[col] = empty_count

        # 4. Numeric Intelligence (Outliers & Variance)
        outlier_map = {}
        for col in df.columns:
            parsed = df[col].apply(smart_numeric_parse)
            valid_nums = parsed.dropna()
            if not valid_nums.empty and valid_nums.std() > 0:
                z_scores = np.abs((valid_nums - valid_nums.mean()) / valid_nums.std())
                outlier_count = int((z_scores > 2.0).sum()) 
                if outlier_count > 0:
                    outlier_map[col] = outlier_count

        # 5. Logical ID Gaps
        id_cols = [c for c in df.columns if is_id_column(c)]
        missing_id_count = 0
        if id_cols:
            for col in id_cols:
                series_str = df[col].astype(str).str.strip().str.lower()
                is_missing = df[col].isna() | series_str.isin(placeholder_patterns)
                missing_id_count += int(is_missing.sum())

        # 6. Suggestions Engine
        suggestions = []
        if total_nulls > 0:
            suggestions.append(f"Fill {total_nulls} null values using 'missing_nulls' Pipeline step.")
        if sum(outlier_map.values()) > 0:
            suggestions.append(f"Isolate {sum(outlier_map.values())} anomalies using 'outliers' step.")
        if missing_id_count > 0:
            suggestions.append(f"Repair {missing_id_count} missing Identifiers using 'ids' step.")
        if empty_str_map:
            suggestions.append("Sanitize semantic placeholders (e.g. 'null', 'unknown') in categorical columns.")

        # 7. Quality Scoring
        readiness_score = max(0, 100 - (total_nulls // 10) - (sum(outlier_map.values()) * 2) - (missing_id_count * 5))

        return AdvisorReport(
            row_count=rows,
            column_count=cols,
            null_count=total_nulls,
            outlier_count=sum(outlier_map.values()),
            readiness_score=readiness_score,
            suggestions=suggestions,
            diagnostics={
                "null_map": null_map,
                "outlier_map": outlier_map,
                "semantics": semantic_map
            },
            df=df
        )
