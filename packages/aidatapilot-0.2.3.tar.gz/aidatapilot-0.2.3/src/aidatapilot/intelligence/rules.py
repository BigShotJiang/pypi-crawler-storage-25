"""
aidatapilot Adaptive Rule Engine 🧠
--------------------------------
Maps profiling data to specific cleaning and transformation steps.
The core heuristic brain of the Adaptive Pipeline Builder.
"""

from __future__ import annotations

from typing import Any, Dict, List

from aidatapilot.intelligence.analyzer import ProfilingReport


class RuleEngine:
    """Decision engine for selecting pipeline steps."""

    def __init__(self, report: ProfilingReport):
        self.report = report
        self.suggested_steps = []

    def decide(self) -> List[Dict[str, Any]]:
        """Run all rules and return a list of step configurations."""
        self.suggested_steps = []
        
        # 1. Structural Cleaning (Always first)
        self.suggested_steps.append({"name": "normalize_columns"})
        
        # 2. Type Inference (Converts dirty strings to NaNs for the missing value handler)
        self.suggested_steps.append({"name": "infer_types"})
        
        # 3. Logic based on Report metadata
        if self.report.duplicates > 0:
            self.suggested_steps.append({"name": "deduplicate"})
            
        # 4. Handle specific dataset types
        if self.report.dataset_type == "document":
            self._apply_text_rules()
        elif self.report.dataset_type == "time_series":
            self._apply_analytics_rules()
        else:
            self._apply_tabular_rules()
            
        return self.suggested_steps

    def _apply_tabular_rules(self):
        """Rules for general tabular and transactional data."""
        # Missing values
        self.suggested_steps.append({"name": "handle_missing_data"})
        
        # Numeric checks
        for col, profile in self.report.columns.items():
            if profile.role == "numeric":
                # Handle Skew
                if abs(profile.skew) > 3.0:
                    self.suggested_steps.append({
                        "name": "log_transform", 
                        "params": {"columns": [col]}
                    })
                # Handle Outliers
                if profile.has_outliers:
                    self.suggested_steps.append({
                        "name": "handle_outliers",
                        "params": {"columns": [col], "method": "clip"}
                    })
            
            elif profile.role == "categorical":
                if not profile.is_high_cardinality:
                    self.suggested_steps.append({
                        "name": "one_hot_encode",
                        "params": {"columns": [col]}
                    })
                else:
                    self.suggested_steps.append({
                        "name": "label_encode",
                        "params": {"columns": [col]}
                    })

    def _apply_text_rules(self):
        """Rules for unstructured text data."""
        text_cols = [c for c, p in self.report.columns.items() if p.role == "text"]
        primary = self.report.target_col or (text_cols[0] if text_cols else "content")
        
        self.suggested_steps.append({
            "name": "clean_text",
            "params": {"columns": text_cols}
        })
        self.suggested_steps.append({
            "name": "generate_metadata",
            "params": {"column": primary}
        })
        self.suggested_steps.append({
            "name": "chunk_text",
            "params": {"column": primary, "chunk_size": 500, "chunk_overlap": 50}
        })

    def _apply_analytics_rules(self):
        """Rules for time-series and reporting data."""
        self.suggested_steps.append({"name": "handle_missing_data"})
        # Specific time feature engineering
        date_cols = [c for c, p in self.report.columns.items() if p.role == "datetime"]
        if date_cols:
            self.suggested_steps.append({
                "name": "extract_date_features",
                "params": {"columns": date_cols}
            })
