"""
Performance Benchmarking Module
-------------------------------
Measure execution time, throughput, and memory usage.
"""

import time

try:
    import psutil
except ImportError:
    psutil = None
import os

from aidatapilot.utils.logger import get_logger


def benchmark_pipeline(pipeline, label="Pipeline"):
    """
    Run a pipeline and print detailed performance metrics.
    """
    logger = get_logger()
    logger.info(f"\n[bold green]--- Benchmarking: {label} ---[/]")
    
    if psutil:
        process = psutil.Process(os.getpid())
        mem_before = process.memory_info().rss / 1024**2
    else:
        mem_before = 0
    
    start_time = time.perf_counter()
    result = pipeline.run()
    end_time = time.perf_counter()
    
    if psutil:
        mem_after = process.memory_info().rss / 1024**2
    else:
        mem_after = 0
        
    duration = end_time - start_time
    
    if result.success:
        throughput = result.rows_in / max(duration, 0.001)
        logger.info(f"Execution Time : {duration:.4f} seconds")
        logger.info(f"Throughput     : {throughput:,.0f} rows/sec")
        if psutil:
            logger.info(f"Memory Growth  : {mem_after - mem_before:.2f} MB")
            logger.info(f"Final Memory   : {mem_after:.2f} MB")
    else:
        logger.error(f"Benchmark Failed: {result.error}")
    
    logger.info("-" * 40 + "\n")
    return result

