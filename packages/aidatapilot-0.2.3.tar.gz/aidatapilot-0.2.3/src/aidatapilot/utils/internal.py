"""
Internal Utilities — Private logic shared across Processing Steps.
-----------------------------------------------------------------
WARNING: This module is for internal package use only. API may change.
"""

from __future__ import annotations
import re
from typing import Any, List, Optional
import numpy as np
import pandas as pd

# ──────────────────────────────────────────────────────────────────────
# 1. ID Detection Constants
# ──────────────────────────────────────────────────────────────────────

DEFAULT_ID_PATTERNS = ["id", "uid", "index", "pk", "uuid", "key", "num", "code"]

def is_id_column(col_name: str, custom_patterns: Optional[List[str]] = None) -> bool:
    """Determine if a column name likely represents an ID or unique identifier."""
    low_name = str(col_name).lower().strip()
    patterns = custom_patterns or DEFAULT_ID_PATTERNS
    
    # 1. Direct Pattern Match
    is_id = any(p == low_name for p in patterns) or any(f"_{p}" in low_name for p in patterns) or any(f"{p}_" in low_name for p in patterns)
    
    # 2. Number/No shorthand (e.g., "no", "order_no")
    if not is_id:
        is_id = any(p in low_name for p in ["_no", "no_", "number", "_num"]) or low_name == "no"
        
    # 3. Explicit Exclusions (Clinical Data / Money)
    exclusions = ["price", "total", "amount", "cost", "sum", "count", "quantity", "qty"]
    if any(e in low_name for e in exclusions):
        is_id = False
        
    return is_id

# ──────────────────────────────────────────────────────────────────────
# 2. Smart Numeric Parsing
# ──────────────────────────────────────────────────────────────────────

TEXT_NUMBERS = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
    "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20,
    "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90,
    "hundred": 100, "thousand": 1000, "million": 1000000
}

def smart_numeric_parse(val: Any) -> float:
    """Internal precision parser: handles messy text-to-numeric conversion."""
    if pd.isna(val) or val is None:
        return np.nan
    s = str(val).strip().lower()
    if not s or s in ("nan", "null", "n/a"):
        return np.nan
        
    # A. Handle Card-based Text Numbers
    if s in TEXT_NUMBERS:
        return float(TEXT_NUMBERS[s])
    if " " in s:
        parts = s.split()
        if all(p in TEXT_NUMBERS for p in parts):
            total, curr = 0, 0
            for p in parts:
                v = TEXT_NUMBERS[p]
                if v >= 100:
                    total += (curr or 1) * v
                    curr = 0
                else:
                    curr += v
            return float(total + curr)

    # B. Extract via Regex
    has_comma = "," in s
    has_period = "." in s
    clean_s = s
    if has_comma and not has_period:
        parts = s.split(",")
        if len(parts) == 2 and len(parts[1]) <= 2:
            clean_s = s.replace(",", ".")
        else:
            clean_s = s.replace(",", "")
    elif has_comma and has_period:
        if s.rfind(",") > s.rfind("."):
            clean_s = s.replace(".", "").replace(",", ".")
        else:
            clean_s = s.replace(",", "")

    clean_s = re.sub(r'[$\u20ac\u00a3\u00a5\u20b9]', '', clean_s)
    match = re.search(r'[-+]?\d*\.?\d+', clean_s)
    if match:
        try:
            return float(match.group())
        except ValueError:
            pass
    
    return np.nan
