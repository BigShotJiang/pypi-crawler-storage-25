"""
Data Profiler — Intelligence Hook
-----------------------------------
Provides a snapshot profile of a DataFrame: shape, dtypes,
null rates, basic statistics, and cardinality.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional

import pandas as pd


@dataclass
class ColumnProfile:
    """Profile of a single column."""
    name: str
    dtype: str
    null_count: int
    null_pct: float
    unique_count: int
    sample_values: List[Any] = field(default_factory=list)
    mean: Optional[float] = None
    std: Optional[float] = None
    min: Optional[float] = None
    max: Optional[float] = None


@dataclass
class DataProfile:
    """Full dataset profile."""
    row_count: int
    column_count: int
    columns: List[ColumnProfile]
    memory_mb: float


class DataProfiler:
    """Compute a descriptive profile of a DataFrame."""

    def profile(self, df: pd.DataFrame) -> DataProfile:
        columns: List[ColumnProfile] = []
        for col in df.columns:
            series = df[col]
            null_count = int(series.isnull().sum())
            null_pct = null_count / len(df) if len(df) > 0 else 0.0
            unique_count = int(series.nunique(dropna=True))
            sample = series.dropna().head(3).tolist()

            col_profile = ColumnProfile(
                name=col,
                dtype=str(series.dtype),
                null_count=null_count,
                null_pct=null_pct,
                unique_count=unique_count,
                sample_values=sample,
            )

            if pd.api.types.is_numeric_dtype(series):
                col_profile.mean = float(series.mean()) if not series.isnull().all() else None
                col_profile.std  = float(series.std())  if not series.isnull().all() else None
                col_profile.min  = float(series.min())  if not series.isnull().all() else None
                col_profile.max  = float(series.max())  if not series.isnull().all() else None

            columns.append(col_profile)

        return DataProfile(
            row_count=len(df),
            column_count=len(df.columns),
            columns=columns,
            memory_mb=df.memory_usage(deep=True).sum() / 1_048_576,
        )

    def print_report(self, profile: DataProfile) -> None:
        """Standard-print a DataProfile to the terminal."""
        print("-" * 60)
        print("aidatapilot Data Profile")
        print("-" * 60)
        print(f"Rows     : {profile.row_count}")
        print(f"Columns  : {profile.column_count}")
        print(f"Memory   : {profile.memory_mb:.2f} MB")
        
        print(f"\n{'Column':<20} {'Type':<10} {'Nulls':<10} {'Null %':<10} {'Unique':<10}")
        print("-" * 60)
        
        for col in profile.columns:
            print(f"{col.name:<20} {col.dtype:<10} {col.null_count:<10} {col.null_pct:<10.0%} {col.unique_count:<10}")
        print("-" * 60 + "\n")
