"""
Synthetic Dataset Generator
---------------------------
Generate large-scale test data for stress testing and examples.
"""

import random

import numpy as np
import pandas as pd


def generate_synthetic_data(rows: int = 1000, skew: bool = False) -> pd.DataFrame:
    """
    Create a large-scale messy dataset for testing.
    """
    data = {
        "user_id": range(1000, 1000 + rows),
        "full_name": [f"User_{i}" if i % 10 != 0 else None for i in range(rows)],
        "price": [random.uniform(10, 500) if i % 15 != 0 else None for i in range(rows)],
        "signup_date": [
            f"2023.{random.randint(1,12)}.{random.randint(1,28)}" 
            if i % 20 != 0 else None for i in range(rows)
        ],
        "score": np.random.normal(loc=100, scale=15, size=rows),
        "status": random.choices(["active", "inactive", "pending"], k=rows)
    }
    
    df = pd.DataFrame(data)
    
    if skew:
        # Create a highly skewed column
        df["score"] = np.random.exponential(scale=2.0, size=rows) * 100
        
    return df

