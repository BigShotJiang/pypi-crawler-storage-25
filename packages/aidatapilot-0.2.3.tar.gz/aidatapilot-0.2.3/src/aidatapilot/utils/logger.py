"""
aidatapilot Logger — Clean, Standard Observability
------------------------------------------------------
Simplified logger that uses standard print() and the stdlib logging module.
No 'rich' dependency for minimal terminal noise.
"""

from __future__ import annotations

import logging
import sys
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from aidatapilot.core.pipeline import PipelineResult


class aidatapilotLogger:
    """Unified logger for the aidatapilot engine.

    Uses standard print() for terminal output and Python's logging 
    module for machine-readable records.
    """

    def __init__(self, name: str = "aidatapilot") -> None:
        self._name = name
        self._py_logger = logging.getLogger(name)
        if not self._py_logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(
                logging.Formatter("[%(levelname)s] %(name)s: %(message)s")
            )
            self._py_logger.addHandler(handler)
            self._py_logger.setLevel(logging.DEBUG)

    def _format_msg(self, level: str, message: str) -> str:
        # Strip any accidental rich markup if it leaks in
        import re
        message = re.sub(r"\[/?[^\[\]]*\]", "", message)
        
        icons = {
            "info":     "  • ",
            "success":  "  ✔ ",
            "warning":  "  ⚠ ",
            "error":    "  ✘ ",
            "step":     "  ↪ ",
        }
        return f"{icons.get(level, '  - ')}{message}"

    def _print_safe(self, msg: str) -> None:
        """Safely print message, falling back to ASCII if Unicode symbols are not supported."""
        try:
            print(msg)
        except UnicodeEncodeError:
            # Fallback to plain ASCII symbols if terminal doesn't support Unicode
            ascii_msg = msg.replace("✔", "[v]").replace("⚠", "[!]").replace("✘", "[x]")
            ascii_msg = ascii_msg.replace("▶", ">").replace("↪", "->").replace("═", "=")
            ascii_msg = ascii_msg.replace("•", "-").replace("→", "->")
            print(ascii_msg)

    def info(self, message: str) -> None:
        self._print_safe(self._format_msg("info", message))

    def success(self, message: str) -> None:
        self._print_safe(self._format_msg("success", message))

    def warning(self, message: str) -> None:
        msg = self._format_msg("warning", message)
        self._print_safe(msg)
        self._py_logger.warning(message)

    def error(self, message: str) -> None:
        msg = self._format_msg("error", message)
        self._print_safe(msg)
        self._py_logger.error(message)

    def debug(self, message: str) -> None:
        self._py_logger.debug(message)

    def pipeline_start(self, template: Optional[str], source: str) -> None:
        self._print_safe("\n" + "═" * 80)
        self._print_safe(f" AIDataPilot Pipeline | template={template or 'custom'} | source={source}")
        self._print_safe("═" * 80)

    def step_start(self, name: str, attempt: int) -> None:
        # Map internal step names to user-friendly titles
        friendly_names = {
            "normalize_columns": "Normalizing column names",
            "infer_types": "Cleaning numeric columns",
            "handle_missing_data": "Handling missing values",
            "deduplicate": "Removing duplicates",
            "remove_nulls": "Removing null values",
            "fill_nulls": "Filling null values",
            "format_date": "Formatting dates",
            "type_cast": "Casting data types",
        }
        title = friendly_names.get(name, name.replace("_", " ").capitalize())
        suffix = f" (retry {attempt})" if attempt > 0 else ""
        self._print_safe(f"  ▶ {title}{suffix}...")

    def step_end(
        self,
        name: str,
        rows_in: int,
        rows_out: int,
        rows_edited: int,
        duration: float,
    ) -> None:
        # Map internal step names to user-friendly titles for the completion message
        friendly_names = {
            "normalize_columns": "Normalized columns",
            "infer_types": "Cleaned numeric columns",
            "handle_missing_data": "Handled missing values",
            "deduplicate": "Removed duplicates",
            "remove_nulls": "Removed null values",
            "fill_nulls": "Filled null values",
            "format_date": "Formatted dates",
            "type_cast": "Cast data types",
        }
        title = friendly_names.get(name, name.replace("_", " ").capitalize())
        delta = rows_out - rows_in
        delta_str = f"{delta:+d}"
        edit_str = f" (~{rows_edited} edited)" if rows_edited > 0 else ""
        self._print_safe(
            f"  ✔ {title}: {rows_in} → {rows_out} rows ({delta_str}{edit_str}) in {duration:.3f}s"
        )

    def print_report(self, result: PipelineResult) -> None:
        print("\n" + "-" * 30)
        print("PIPELINE REPORT")
        print("-" * 30)

        status = "SUCCESS" if result.success else "FAILED"
        print(f"Status   : {status}")
        print(f"Rows     : {result.rows_in} -> {result.rows_out} ({result.rows_out - result.rows_in:+d})")
        print(f"Duration : {result.total_duration_seconds:.3f}s")
        print("\nStep Details:")
        print(f"{'Step':<25} {'Rows In':<10} {'Rows Out':<10} {'Duration':<10}")
        print("-" * 60)
        
        for r in result.step_reports:
            print(f"{r.name:<25} {r.rows_in:<10} {r.rows_out:<10} {r.duration_seconds:.3f}s")

        if result.warnings:
            print("\nWarnings:")
            for w in result.warnings:
                print(f"  - {w}")

        print("-" * 80 + "\n")


_logger: Optional[aidatapilotLogger] = None


def get_logger() -> aidatapilotLogger:
    global _logger
    if _logger is None:
        _logger = aidatapilotLogger()
    return _logger


def set_log_level(level: str) -> None:
    logger = get_logger()
    logger._py_logger.setLevel(getattr(logging, level.upper(), logging.INFO))
