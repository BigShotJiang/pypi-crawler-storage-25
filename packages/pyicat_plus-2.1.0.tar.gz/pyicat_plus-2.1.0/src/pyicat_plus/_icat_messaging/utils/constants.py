from importlib.metadata import version as get_version

release = get_version("pyicat_plus")
definitions_release = get_version("icat-esrf-definitions")
