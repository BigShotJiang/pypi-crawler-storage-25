"""
Some ICAT requests do not go through the REST API but are send to an ActiveMQ message broker.
The consumers of these messages are referred to as "Ingesters".
"""
