from dataclasses import dataclass
from dataclasses import field
from typing import Optional

from xsdata.models.datatype import XmlDateTime

__NAMESPACE__ = "http://www.esrf.fr/icat"


@dataclass
class Investigation:
    class Meta:
        name = "investigation"
        namespace = "http://www.esrf.fr/icat"

    experiment: Optional[str] = field(
        default=None,
        metadata={
            "type": "Element",
            "required": True,
        },
    )
    instrument: Optional[str] = field(
        default=None,
        metadata={
            "type": "Element",
            "required": True,
        },
    )
    start_date: Optional[XmlDateTime] = field(
        default=None,
        metadata={
            "name": "startDate",
            "type": "Element",
            "required": True,
        },
    )
    investigation_id: Optional[int] = field(
        default=None,
        metadata={
            "name": "investigationId",
            "type": "Element",
            "required": True,
        },
    )
