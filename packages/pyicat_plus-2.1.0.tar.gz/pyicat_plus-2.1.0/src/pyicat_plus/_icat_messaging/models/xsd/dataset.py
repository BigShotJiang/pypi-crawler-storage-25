from dataclasses import dataclass
from dataclasses import field
from typing import List
from typing import Optional

from xsdata.models.datatype import XmlDateTime

__NAMESPACE__ = "http://www.esrf.fr/icat"


@dataclass
class Parameter:
    class Meta:
        name = "parameter"

    name: Optional[str] = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "http://www.esrf.fr/icat",
            "required": True,
        },
    )
    value: Optional[str] = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "http://www.esrf.fr/icat",
            "required": True,
        },
    )


@dataclass
class Datafile:
    class Meta:
        name = "datafile"

    location: Optional[str] = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "http://www.esrf.fr/icat",
            "required": True,
        },
    )
    size: Optional[int] = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "http://www.esrf.fr/icat",
        },
    )
    parameter: List[Parameter] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "http://www.esrf.fr/icat",
        },
    )


@dataclass
class Sample:
    class Meta:
        name = "sample"

    name: Optional[str] = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "http://www.esrf.fr/icat",
            "required": True,
        },
    )
    type_value: Optional[str] = field(
        default=None,
        metadata={
            "name": "type",
            "type": "Element",
            "namespace": "http://www.esrf.fr/icat",
            "required": True,
        },
    )
    parameter: List[Parameter] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "http://www.esrf.fr/icat",
        },
    )


@dataclass
class Dataset:
    class Meta:
        name = "dataset"
        namespace = "http://www.esrf.fr/icat"

    dataset_id: Optional[int] = field(
        default=None,
        metadata={
            "name": "datasetId",
            "type": "Element",
        },
    )
    investigation: Optional[str] = field(
        default=None,
        metadata={
            "type": "Element",
            "required": True,
        },
    )
    instrument: Optional[str] = field(
        default=None,
        metadata={
            "type": "Element",
            "required": True,
        },
    )
    name: Optional[str] = field(
        default=None,
        metadata={
            "type": "Element",
            "required": True,
        },
    )
    location: Optional[str] = field(
        default=None,
        metadata={
            "type": "Element",
            "required": True,
        },
    )
    start_date: Optional[XmlDateTime] = field(
        default=None,
        metadata={
            "name": "startDate",
            "type": "Element",
            "required": True,
        },
    )
    end_date: Optional[XmlDateTime] = field(
        default=None,
        metadata={
            "name": "endDate",
            "type": "Element",
            "required": True,
        },
    )
    comment: Optional[str] = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    sample: Optional[Sample] = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    datafile: List[Datafile] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    parameter: List[Parameter] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    complete: bool = field(
        default=True,
        metadata={
            "type": "Attribute",
        },
    )
