import datetime

from ..._icat_messaging.serializers.investigation import (
    raw_serialize_investigation_message,
)
from ..._icat_messaging.serializers.investigation import serialize_investigation_message
from ..._icat_messaging.utils import datetime_utils


def test_investigation_message():
    proposal = "MX-123"
    beamline = "ID30A-3"
    start_datetime = datetime.datetime.now().astimezone()

    expected = f"""<?xml version="1.0" encoding="UTF-8"?>
<tns:investigation xmlns:tns="http://www.esrf.fr/icat">
  <tns:experiment>mx-123</tns:experiment>
  <tns:instrument>id30a-3</tns:instrument>
  <tns:startDate>{datetime_utils.with_timezone_zulu_format(start_datetime)}</tns:startDate>
</tns:investigation>
"""

    data = serialize_investigation_message(
        beamline=beamline, proposal=proposal, start_datetime=start_datetime, indent="  "
    )
    assert data.decode("utf-8") == expected


def test_investigation_message_xsd_only():
    data = {
        "experiment": "MX-123",
        "instrument": "ID30A-3",
        "startDate": "2026-03-08T09:18:49.678825+01:00",
        "investigationId": 4521,
    }

    expected = """<?xml version="1.0" encoding="UTF-8"?>
<tns:investigation xmlns:tns="http://www.esrf.fr/icat">
  <tns:experiment>MX-123</tns:experiment>
  <tns:instrument>ID30A-3</tns:instrument>
  <tns:startDate>2026-03-08T09:18:49.678825+01:00</tns:startDate>
  <tns:investigationId>4521</tns:investigationId>
</tns:investigation>
"""

    data = raw_serialize_investigation_message(data, indent="  ")
    assert data.decode("utf-8") == expected
