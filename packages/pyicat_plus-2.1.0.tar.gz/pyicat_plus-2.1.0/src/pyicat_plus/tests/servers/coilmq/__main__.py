import logging
import pathlib
import sys

logger = logging.getLogger(__name__)

if __name__ == "__main__":
    try:
        import pkg_resources  # noqa F401
    except ImportError:
        sys.path.insert(0, str(pathlib.Path(__file__).parent))

    from coilmq.start import main

    try:
        main()
    except (KeyboardInterrupt, SystemExit):
        pass
    except Exception as e:
        logger.error("Server terminated due to error: %s" % e)
        logger.exception(e)
