import warnings

import pytest
from esrf_ontologies import technique

from ..errors import IcatMetadataFutureWarning
from ..metadata.definitions import load_icat_fields
from .fixtures.icat import *  # noqa F401

pytest.register_assert_rewrite("pyicat_plus.tests.utils.compare")


@pytest.fixture
def icat_namespace():
    metadict = dict()

    def getter(key):
        return metadict[key]

    def setter(key, value):
        metadict[key] = value

    icat_fields = load_icat_fields()
    metadata = icat_fields.namespace(getter=getter, setter=setter)

    return icat_fields, metadata, metadict


@pytest.fixture
def ignore_icat_message_warnings():
    """Ignore expected ICAT serialization warnings."""
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=IcatMetadataFutureWarning)
        yield


@pytest.fixture(scope="session")
def esrfet_version() -> str:
    return technique.get_ontology_version_number()
