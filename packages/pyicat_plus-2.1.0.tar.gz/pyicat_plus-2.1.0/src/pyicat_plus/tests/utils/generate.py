import random


def icat_id() -> int:
    return random.randint(1000000000, 9999999999)
