"""MobKit Python SDK.

Usage::

    from meerkat_mobkit import MobKit, MobKitRuntime, MobKitBuilder
    from meerkat_mobkit import DiscoverySpec, PreSpawnData, SessionQuery
    from meerkat_mobkit import SessionAgentBuilder, SessionBuildOptions
    from meerkat_mobkit.errors import MobKitError, RpcError, NotConnectedError
    from meerkat_mobkit.types import StatusResult, CapabilitiesResult
    from meerkat_mobkit.events import MobEvent, AgentEvent

Module authoring helpers are available via::

    from meerkat_mobkit.helpers import ModuleSpec, define_module, ...
"""
from __future__ import annotations

# Builder + Runtime
from .builder import MobKit, MobKitBuilder
from .runtime import MobKitRuntime, ToolCaller

# Data models
from .models import DiscoverySpec, PreSpawnData, SessionBuildOptions, SessionCreatedContext, SessionQuery

# Agent builder protocol (public contract — CallbackDispatcher is internal)
from .agent_builder import SessionAgentBuilder

# Errors
from .errors import (
    MOB_EVENTS_STALE_CURSOR_CODE,
    CAPABILITY_UNAVAILABLE_CODE,
    MEMORY_BACKEND_UNAVAILABLE_CODE,
    CapabilityUnavailableError,
    ContractMismatchError,
    MemoryBackendUnavailableError,
    MobEventsStaleError,
    MobKitError,
    NotConnectedError,
    RpcError,
    TransportError,
)

# Typed return models
from .types import (
    CallToolResult,
    CapabilitiesResult,
    CatalogEntry,
    CrossMobContactEntry,
    DeliveryHistoryResult,
    DeliveryResult,
    ErrorCategory,
    ErrorEvent,
    EventEnvelope,
    EventQuery,
    GatingAuditEntry,
    GatingDecisionResult,
    GatingEvaluateResult,
    GatingPendingEntry,
    HelperResult,
    KeepAliveConfig,
    MEMBER_STATE_ACTIVE,
    MEMBER_STATE_RETIRING,
    FailureRecord,
    FrameRecord,
    LoopIterationRecord,
    LoopRecord,
    MemberSnapshot,
    MemoryIndexResult,
    MemoryQueryResult,
    MemoryStoreInfo,
    MobMemberStatus,
    MobRun,
    MobRunSnapshot,
    MobRunStatus,
    MobStructuralEvent,
    StepRecord,
    MobUnreachablePeer,
    ModelsCatalogResult,
    PeerConnectivitySnapshot,
    PersistedEvent,
    ProfileCapabilities,
    ProviderDefaults,
    ReconcileEdgesReport,
    ReconcileResult,
    RediscoverReport,
    RichMemberSnapshot,
    RoutingResolution,
    RuntimeCapabilities,
    RuntimeRouteResult,
    SendMessageResult,
    SpawnMemberResult,
    SpawnResult,
    StatusResult,
    SubscribeResult,
    UnifiedAgentEvent,
    UnifiedModuleEvent,
)

# Typed events
from .events import (
    AgentEvent,
    Event,
    EventStream,
    MobEvent,
    RunCompleted,
    RunFailed,
    RunStarted,
    TextComplete,
    TextDelta,
    ToolCallRequested,
    ToolExecutionCompleted,
    ToolExecutionStarted,
    ToolResultReceived,
    TurnCompleted,
    TurnStarted,
    UnknownEvent,
)

# Config modules (importable as meerkat_mobkit.auth, etc.)
from .config import auth, memory, session_store

__all__ = [
    # Builder + Runtime
    "MobKit",
    "MobKitBuilder",
    "MobKitRuntime",
    # Data models
    "DiscoverySpec",
    "PreSpawnData",
    "SessionBuildOptions",
    "SessionCreatedContext",
    "SessionQuery",
    # Agent builder
    "SessionAgentBuilder",
    # Errors
    "MobKitError",
    "TransportError",
    "RpcError",
    "MobEventsStaleError",
    "MOB_EVENTS_STALE_CURSOR_CODE",
    "CAPABILITY_UNAVAILABLE_CODE",
    "MEMORY_BACKEND_UNAVAILABLE_CODE",
    "CapabilityUnavailableError",
    "MemoryBackendUnavailableError",
    "ContractMismatchError",
    "NotConnectedError",
    # Typed return models
    "StatusResult",
    "CapabilitiesResult",
    "ReconcileResult",
    "SpawnResult",
    "SpawnMemberResult",
    "SendMessageResult",
    "SubscribeResult",
    "KeepAliveConfig",
    "EventEnvelope",
    "RoutingResolution",
    "DeliveryResult",
    "DeliveryHistoryResult",
    "MemoryQueryResult",
    "MemoryStoreInfo",
    "MemoryIndexResult",
    "MEMBER_STATE_ACTIVE",
    "MEMBER_STATE_RETIRING",
    "MemberSnapshot",
    "MobRun",
    "MobRunStatus",
    "MobStructuralEvent",
    "StepRecord",
    "FailureRecord",
    "FrameRecord",
    "LoopRecord",
    "LoopIterationRecord",
    "RuntimeRouteResult",
    "GatingEvaluateResult",
    "GatingDecisionResult",
    "GatingAuditEntry",
    "GatingPendingEntry",
    "CallToolResult",
    "CatalogEntry",
    "CrossMobContactEntry",
    "HelperResult",
    "MobMemberStatus",
    "MobRunSnapshot",
    "MobUnreachablePeer",
    "ModelsCatalogResult",
    "PeerConnectivitySnapshot",
    "ProviderDefaults",
    "RichMemberSnapshot",
    "RuntimeCapabilities",
    "ProfileCapabilities",
    "ErrorCategory",
    "ErrorEvent",
    "EventQuery",
    "PersistedEvent",
    "UnifiedAgentEvent",
    "UnifiedModuleEvent",
    "ReconcileEdgesReport",
    "RediscoverReport",
    "ToolCaller",
    # Typed events
    "Event",
    "MobEvent",
    "AgentEvent",
    "EventStream",
    "RunStarted",
    "RunCompleted",
    "RunFailed",
    "TurnStarted",
    "TextDelta",
    "TextComplete",
    "ToolCallRequested",
    "ToolResultReceived",
    "TurnCompleted",
    "ToolExecutionStarted",
    "ToolExecutionCompleted",
    "UnknownEvent",
    # Config modules
    "auth",
    "memory",
    "session_store",
]
