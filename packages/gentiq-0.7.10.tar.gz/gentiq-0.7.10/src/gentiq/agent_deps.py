import asyncio
from dataclasses import dataclass, field

from .events import ThreadStreamEvent
from .schemas import User
from .stores.chat_store import ChatStore
from .stores.user_store import UserStore


@dataclass
class AgentDeps[T_Context]:
    """Standard agent dependencies for the Gentiq framework.

    This class is injected into your PydanticAI agents and provides access to
    the core Gentiq components like chat store and user store, the current authenticated
    `User`, and your custom application `context`.

    Example:
        ```python
        from gentiq import AgentDeps
        from pydantic_ai import Agent, RunContext

        # Define your context
        class MyContext:
            ...

        # Type your agent with AgentDeps
        agent = Agent[AgentDeps[MyContext]](...)

        @agent.tool
        async def my_tool(ctx: RunContext[AgentDeps[MyContext]]) -> str:
            # ctx.deps is an instance of AgentDeps
            user_name = ctx.deps.user.name
            chat_store = ctx.deps.chat_store
            return f"Hello {user_name}!"
        ```
    """

    user_store: UserStore
    chat_store: ChatStore
    user: User
    context: T_Context

    # Internal event queue for streaming custom events
    _event_queue: asyncio.Queue = field(default_factory=asyncio.Queue, init=False, repr=False)

    async def stream(self, event: ThreadStreamEvent):
        await self._event_queue.put(event)

    async def stream_events(self):
        while True:
            event = await self._event_queue.get()
            if event is None:
                break
            yield event
