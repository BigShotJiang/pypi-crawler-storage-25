from typing import Annotated, Literal

from pydantic import BaseModel, Field


__all__ = ["ProgressUpdateEvent", "ThreadStreamEvent"]


class ProgressUpdateEvent(BaseModel):
    event_kind: Literal["progress_update"] = "progress_update"
    tool_name: str
    status: Literal["running", "completed", "error"]
    message: str


ThreadStreamEvent = Annotated[ProgressUpdateEvent, Field(discriminator="event_kind")]
