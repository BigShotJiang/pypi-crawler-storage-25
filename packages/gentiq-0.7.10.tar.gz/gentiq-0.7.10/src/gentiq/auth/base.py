from abc import ABC, abstractmethod

from fastapi import Request

from ..schemas import User


class AuthAdapter(ABC):
    """
    Base class for authentication adapters in Gentiq.

    Developers can extend this class to implement custom authentication logic
    (e.g., Session-based, OAuth2, custom API Keys) and pass it to GentiqApp.
    """

    @abstractmethod
    def get_current_user(self, request: Request) -> User | None:
        """
        Verify the authentication credentials in the request and return the User.

        Should return None if authentication fails or is missing.
        """
        pass

    @abstractmethod
    def get_current_admin(self, request: Request) -> dict | None:
        """
        Verify the authentication credentials in the request and return the Admin data.

        Should return None if authentication fails or is missing.
        """
        pass

    @abstractmethod
    def create_user_token(self, user_id: str) -> str:
        """
        Create an authentication token for a user.
        """
        pass

    @abstractmethod
    def create_admin_token(self, admin_id: str) -> str:
        """
        Create an authentication token for an admin.
        """
        pass
