from datetime import UTC, datetime, timedelta

import jwt
from fastapi import Request

from ..env import ADMIN_JWT_EXPIRATION_HOURS, ADMIN_JWT_SECRET_KEY, JWT_ALGORITHM, JWT_EXPIRATION_HOURS, JWT_SECRET_KEY
from ..schemas import User
from ..stores import AdminStore, UserStore
from .base import AuthAdapter


class JWTAuth(AuthAdapter):
    """
    Default JWT-based authentication adapter for Gentiq.
    """

    def _create_token(self, data: dict, secret: str, expiration_hours: int) -> str:
        """Helper to create a JWT token with consistent payload structure."""
        expiration = datetime.now(UTC) + timedelta(hours=expiration_hours)
        payload = {
            **data,
            "exp": expiration,
            "iat": datetime.now(UTC),
        }
        return jwt.encode(payload, secret, algorithm=JWT_ALGORITHM)

    def create_user_token(self, user_id: str) -> str:
        """Create a JWT token for a user."""
        return self._create_token({"user_id": user_id}, JWT_SECRET_KEY, JWT_EXPIRATION_HOURS)

    def create_admin_token(self, admin_id: str) -> str:
        """Create a JWT token for an admin."""
        return self._create_token({"admin_id": admin_id}, ADMIN_JWT_SECRET_KEY, ADMIN_JWT_EXPIRATION_HOURS)

    def get_current_user(self, request: Request) -> User | None:
        """
        Verify JWT in Authorization header and return the User.
        """
        auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            return None

        token = auth_header.split(" ")[1]
        try:
            payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
            user_id = payload.get("user_id")
            if not user_id:
                return None

            user_store: UserStore = request.app.state.user_store
            return user_store.get_user(user_id)
        except (jwt.PyJWTError, Exception):
            return None

    def get_current_admin(self, request: Request) -> dict | None:
        """
        Verify JWT in Authorization header and return the Admin data.
        """
        auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            return None

        token = auth_header.split(" ")[1]
        try:
            payload = jwt.decode(token, ADMIN_JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
            admin_id = payload.get("admin_id")
            if not admin_id:
                return None

            admin_store: AdminStore = request.app.state.admin_store
            admin = admin_store.get_admin(admin_id)
            if not admin:
                return None

            return {
                "admin_id": admin.id,
                "username": admin.username,
                "name": admin.name,
                "permissions": admin.permissions,
            }
        except (jwt.PyJWTError, Exception):
            return None
