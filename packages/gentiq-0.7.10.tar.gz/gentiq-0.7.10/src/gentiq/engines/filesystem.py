import shutil
from pathlib import Path
from typing import Any

from .base import StorageEngine


class FileSystemEngine(StorageEngine):
    """
    Local file system storage engine implementation.
    """

    def __init__(self, base_path: str | Path, **kwargs: Any):
        self.base_path = Path(base_path).absolute()
        if not self.base_path.exists():
            self.base_path.mkdir(parents=True, exist_ok=True)

    def _get_full_path(self, container: str, object_name: str) -> Path:
        return self.base_path / container / object_name

    def upload(self, container: str, object_name: str, data: Any, length: int) -> None:
        full_path = self._get_full_path(container, object_name)
        full_path.parent.mkdir(parents=True, exist_ok=True)

        with open(full_path, "wb") as f:
            if hasattr(data, "read"):
                shutil.copyfileobj(data, f)
            else:
                f.write(data)

    def download(self, container: str, object_name: str) -> Any:
        full_path = self._get_full_path(container, object_name)
        if not full_path.exists():
            raise FileNotFoundError(f"Object {object_name} not found in container {container}")

        class LocalResponse:
            def __init__(self, file_path: Path):
                self.file = open(file_path, "rb")

            def read(self):
                return self.file.read()

            def close(self):
                self.file.close()

            def release_conn(self):
                pass

        return LocalResponse(full_path)

    def delete(self, container: str, object_name: str) -> None:
        full_path = self._get_full_path(container, object_name)
        if full_path.exists():
            full_path.unlink()

    def container_exists(self, container: str) -> bool:
        return (self.base_path / container).is_dir()

    def create_container(self, container: str) -> None:
        (self.base_path / container).mkdir(parents=True, exist_ok=True)

    def generate_url(self, container: str, object_name: str, expires: Any) -> str:
        full_path = self._get_full_path(container, object_name)
        return f"file://{full_path}"

    def exists(self, container: str, object_name: str) -> bool:
        full_path = self._get_full_path(container, object_name)
        return full_path.exists()
