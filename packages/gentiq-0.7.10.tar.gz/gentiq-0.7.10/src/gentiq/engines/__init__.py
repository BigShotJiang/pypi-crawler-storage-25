from .base import DBEngine, StorageEngine
from .filesystem import FileSystemEngine
from .minio import MinioEngine
from .mongo import MongoEngine
from .registry import EngineRegistry, register_db_engine, register_storage_engine
from .sqlite import SQLiteEngine


def _create_sqlite(app_name: str | None = None, **kwargs) -> DBEngine:
    name_str = (app_name or "gentiq").lower()
    return SQLiteEngine(f"sqlite:///{name_str}.db")


def _create_mongodb(**kwargs) -> DBEngine:
    from ..env import MONGODB_DB_NAME, MONGODB_PASSWORD, MONGODB_URI, MONGODB_USERNAME

    return MongoEngine(
        uri=str(MONGODB_URI),
        db_name=str(MONGODB_DB_NAME),
        username=MONGODB_USERNAME,
        password=MONGODB_PASSWORD,
    )


def _create_filesystem(**kwargs) -> StorageEngine:
    return FileSystemEngine(base_path="./.storage")


def _create_minio(**kwargs) -> StorageEngine:
    from ..env import MINIO_ACCESS_KEY, MINIO_ENDPOINT, MINIO_SECRET_KEY

    return MinioEngine(
        endpoint=str(MINIO_ENDPOINT),
        access_key=str(MINIO_ACCESS_KEY),
        secret_key=str(MINIO_SECRET_KEY),
        secure=False,
    )


EngineRegistry.register_db_engine("sqlite", _create_sqlite)
EngineRegistry.register_db_engine("mongodb", _create_mongodb)

EngineRegistry.register_storage_engine("filesystem", _create_filesystem)
EngineRegistry.register_storage_engine("minio", _create_minio)
