import json
import re
import sqlite3
from datetime import UTC
from threading import RLock
from typing import Any

from .base import DBEngine


class SQLiteEngine(DBEngine):
    """
    SQLite implementation of the Gentiq database engine.
    Stores documents as JSON in a single 'data' column.
    """

    def __init__(self, database_path: str, **kwargs):
        self.path = database_path.replace("sqlite:///", "")
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._lock = RLock()
        self._initialize_db()

    def _initialize_db(self):
        # We don't know the collections yet, they'll be created on demand
        pass

    def _ensure_table(self, collection: str):
        with self._lock:
            self.conn.execute(f"CREATE TABLE IF NOT EXISTS {collection} (id TEXT PRIMARY KEY, data TEXT)")
            self.conn.commit()

    def _get_id(self, doc: dict[str, Any]) -> str:
        return str(doc.get("id") or doc.get("_id") or "")

    def _match(self, doc: dict[str, Any], filter_doc: dict[str, Any]) -> bool:
        if not filter_doc:
            return True

        for key, value in filter_doc.items():
            if key == "$or":
                if not any(self._match(doc, f) for f in value):
                    return False
                continue
            if key == "$and":
                if not all(self._match(doc, f) for f in value):
                    return False
                continue

            # Handle dot notation
            actual_value = self._get_nested(doc, key)

            if isinstance(value, dict) and any(k.startswith("$") for k in value.keys()):
                # Handle operators
                for op, op_val in value.items():
                    if op == "$regex":
                        pattern = op_val
                        flags = 0
                        if "$options" in value and "i" in value["$options"]:
                            flags = re.IGNORECASE
                        if not re.search(pattern, str(actual_value), flags):
                            return False
                    elif op == "$ne":
                        if self._compare_values(actual_value, "==", op_val):
                            return False
                    elif op == "$in":
                        if not any(self._compare_values(actual_value, "==", v) for v in op_val):
                            return False
                    elif op == "$gt":
                        if not self._compare_values(actual_value, ">", op_val):
                            return False
                    elif op == "$gte":
                        if not self._compare_values(actual_value, ">=", op_val):
                            return False
                    elif op == "$lt":
                        if not self._compare_values(actual_value, "<", op_val):
                            return False
                    elif op == "$lte":
                        if not self._compare_values(actual_value, "<=", op_val):
                            return False
                    elif op == "$options":
                        continue  # Handled by $regex
            else:
                if not self._compare_values(actual_value, "==", value):
                    return False
        return True

    def _compare_values(self, a: Any, op: str, b: Any) -> bool:
        """Helper to compare values with smart type handling (e.g., ISO strings vs datetimes)."""
        from datetime import datetime

        def to_datetime(val: Any) -> Any:
            if isinstance(val, str):
                try:
                    # Handle Z and other ISO formats
                    clean_val = val.replace("Z", "+00:00")
                    dt = datetime.fromisoformat(clean_val)
                    # Force aware if it parsed as naive
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=UTC)
                    return dt
                except (ValueError, TypeError):
                    return val
            if isinstance(val, datetime):
                # Ensure it's aware
                if val.tzinfo is None:
                    return val.replace(tzinfo=UTC)
                return val
            return val

        # Normalize types if it's a comparison involving a datetime
        if isinstance(a, (str, datetime)) and isinstance(b, (str, datetime)):
            a_norm = to_datetime(a)
            b_norm = to_datetime(b)
            if isinstance(a_norm, datetime) and isinstance(b_norm, datetime):
                a, b = a_norm, b_norm

        # Handle None comparisons
        if a is None or b is None:
            if op == "==":
                return a == b
            if op == "!=":
                return a != b
            return False

        try:
            if op == "==":
                return a == b
            if op == "!=":
                return a != b
            if op == ">":
                return a > b
            if op == ">=":
                return a >= b
            if op == "<":
                return a < b
            if op == "<=":
                return a <= b
        except TypeError:
            # Final fallback to string comparison
            if op == "==":
                return str(a) == str(b)
            return False

        return False

    def _safe_sort_key(self, v: Any) -> tuple[int, Any]:
        """Helper for robust sorting and avoiding TypeErrors when comparing mixed types."""
        if v is None:
            return (0, "")
        if isinstance(v, bool):
            return (1, int(v))
        if isinstance(v, (int, float)):
            return (2, v)
        if isinstance(v, str):
            return (3, v)
        return (4, str(v))

    def _get_nested(self, data: dict[str, Any], path: str) -> Any:
        parts = path.split(".")
        current = data
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            else:
                return None
        return current

    def _set_nested(self, data: dict[str, Any], path: str, value: Any):
        parts = path.split(".")
        current = data
        for _, part in enumerate(parts[:-1]):
            if part not in current or not isinstance(current[part], dict):
                current[part] = {}
            current = current[part]
        current[parts[-1]] = value

    def _inc_nested(self, data: dict[str, Any], path: str, value: Any):
        parts = path.split(".")
        current = data
        for _, part in enumerate(parts[:-1]):
            if part not in current or not isinstance(current[part], dict):
                current[part] = {}
            current = current[part]

        last_part = parts[-1]
        current[last_part] = current.get(last_part, 0) + value

    def _delete_nested(self, data: dict[str, Any], path: str):
        parts = path.split(".")
        current = data
        for part in parts[:-1]:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return
        if isinstance(current, dict) and parts[-1] in current:
            del current[parts[-1]]

    def _apply_projection(self, doc: dict[str, Any], projection: dict[str, Any] | None) -> dict[str, Any]:
        if not projection:
            return doc

        # MongoDB projection rules:
        # 1. Inclusion: if any field (other than _id) is 1
        # 2. Exclusion: if all fields are 0
        # 3. Mixed is generally not allowed except for _id: 0
        inclusion = any(v for k, v in projection.items() if k not in ("_id", "id"))

        if inclusion:
            new_doc = {}
            # Always include _id/id unless explicitly excluded
            if projection.get("_id") != 0 and projection.get("id") != 0:
                if "_id" in doc:
                    new_doc["_id"] = doc["_id"]
                if "id" in doc:
                    new_doc["id"] = doc["id"]

            for key, value in projection.items():
                if value and key not in ("_id", "id"):
                    val = self._get_nested(doc, key)
                    if val is not None:
                        self._set_nested(new_doc, key, val)
            return new_doc
        else:
            new_doc = doc.copy()
            for key, value in projection.items():
                if not value:
                    self._delete_nested(new_doc, key)
            return new_doc

    def _apply_update(
        self,
        doc: dict[str, Any],
        set_fields: dict[str, Any] | None = None,
        inc_fields: dict[str, Any] | None = None,
        push_fields: dict[str, Any] | None = None,
    ):
        if set_fields:
            for path, v in set_fields.items():
                self._set_nested(doc, path, v)
        if inc_fields:
            for path, v in inc_fields.items():
                self._inc_nested(doc, path, v)
        if push_fields:
            for path, v in push_fields.items():
                current = self._get_nested(doc, path)
                if not isinstance(current, list):
                    current = []
                current.append(v)
                self._set_nested(doc, path, current)
        return doc

    def find_one(
        self, collection: str, filter: dict[str, Any], projection: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        self._ensure_table(collection)
        with self._lock:
            # Optimize for ID lookups
            lookup_id = None
            if len(filter) == 1:
                if "id" in filter and isinstance(filter["id"], str):
                    lookup_id = filter["id"]
                elif "_id" in filter and isinstance(filter["_id"], str):
                    lookup_id = filter["_id"]

            if lookup_id:
                cur = self.conn.execute(f"SELECT data FROM {collection} WHERE id = ?", (lookup_id,))
                row = cur.fetchone()
                if row:
                    doc = json.loads(row["data"])
                    return self._apply_projection(doc, projection)
                return None

            cur = self.conn.execute(f"SELECT data FROM {collection}")
            for row in cur:
                doc = json.loads(row["data"])
                if self._match(doc, filter):
                    return self._apply_projection(doc, projection)
        return None

    def find_many(
        self,
        collection: str,
        filter: dict[str, Any],
        projection: dict[str, Any] | None = None,
        sort: list[tuple[str, int]] | None = None,
        skip: int = 0,
        limit: int = 0,
    ) -> list[dict[str, Any]]:
        self._ensure_table(collection)
        results = []
        with self._lock:
            cur = self.conn.execute(f"SELECT data FROM {collection}")
            for row in cur:
                doc = json.loads(row["data"])
                if self._match(doc, filter):
                    results.append(self._apply_projection(doc, projection))

        if sort:
            for key, reverse in reversed(sort):
                results.sort(key=lambda x: self._safe_sort_key(self._get_nested(x, key)), reverse=(reverse < 0))

        if skip:
            results = results[skip:]
        if limit:
            results = results[:limit]

        return results

    def insert_one(self, collection: str, document: dict[str, Any]) -> Any:
        self._ensure_table(collection)
        doc_id = self._get_id(document)

        if not doc_id:
            import uuid

            doc_id = str(uuid.uuid4())

        # Ensure consistency in stored document
        if "id" not in document:
            document["id"] = doc_id
        if "_id" not in document:
            document["_id"] = doc_id

        # If they both exist but differ, use the one that matches doc_id
        # (Though this shouldn't happen with our _get_id logic)
        if document.get("id") != doc_id:
            document["id"] = doc_id
        if document.get("_id") != doc_id:
            document["_id"] = doc_id

        with self._lock:
            self.conn.execute(
                f"INSERT INTO {collection} (id, data) VALUES (?, ?)",
                (doc_id, json.dumps(document, default=str)),
            )
            self.conn.commit()
        return doc_id

    def update_one(
        self,
        collection: str,
        filter: dict[str, Any],
        set_fields: dict[str, Any] | None = None,
        inc_fields: dict[str, Any] | None = None,
        push_fields: dict[str, Any] | None = None,
        set_on_insert: dict[str, Any] | None = None,
        upsert: bool = False,
    ) -> Any:
        self._ensure_table(collection)
        with self._lock:
            doc = self.find_one(collection, filter)
            if doc:
                updated_doc = self._apply_update(doc, set_fields, inc_fields, push_fields)
                self.conn.execute(
                    f"UPDATE {collection} SET data = ? WHERE id = ?",
                    (json.dumps(updated_doc, default=str), self._get_id(updated_doc)),
                )
                self.conn.commit()
            elif upsert:
                new_doc = {}
                if set_on_insert:
                    for path, v in set_on_insert.items():
                        self._set_nested(new_doc, path, v)

                for k, v in filter.items():
                    if not k.startswith("$") and "." not in k:
                        new_doc[k] = v

                self._apply_update(new_doc, set_fields, inc_fields, push_fields)
                self.insert_one(collection, new_doc)
            self.conn.commit()

    def update_many(
        self,
        collection: str,
        filter: dict[str, Any],
        set_fields: dict[str, Any] | None = None,
        inc_fields: dict[str, Any] | None = None,
        push_fields: dict[str, Any] | None = None,
    ) -> int:
        self._ensure_table(collection)
        docs = self.find_many(collection, filter)
        count = 0
        with self._lock:
            for doc in docs:
                updated_doc = self._apply_update(doc, set_fields, inc_fields, push_fields)
                self.conn.execute(
                    f"UPDATE {collection} SET data = ? WHERE id = ?",
                    (json.dumps(updated_doc, default=str), self._get_id(updated_doc)),
                )
                count += 1
            if count:
                self.conn.commit()
        return count

    def delete_one(self, collection: str, filter: dict[str, Any]) -> bool:
        doc = self.find_one(collection, filter)
        if doc:
            with self._lock:
                self.conn.execute(f"DELETE FROM {collection} WHERE id = ?", (self._get_id(doc),))
                self.conn.commit()
            return True
        return False

    def delete_many(self, collection: str, filter: dict[str, Any]) -> int:
        count = 0
        docs = self.find_many(collection, filter)
        with self._lock:
            for doc in docs:
                self.conn.execute(f"DELETE FROM {collection} WHERE id = ?", (self._get_id(doc),))
                count += 1
            self.conn.commit()
        return count

    def count_documents(self, collection: str, filter: dict[str, Any]) -> int:
        return len(self.find_many(collection, filter))

    def update_and_return(
        self,
        collection: str,
        filter: dict[str, Any],
        set_fields: dict[str, Any] | None = None,
        inc_fields: dict[str, Any] | None = None,
        return_after: bool = True,
    ) -> dict[str, Any] | None:
        self._ensure_table(collection)
        with self._lock:
            doc = self.find_one(collection, filter)
            if not doc:
                return None

            before_doc = json.loads(json.dumps(doc))  # Deep copy
            updated_doc = self._apply_update(doc, set_fields, inc_fields)

            self.conn.execute(
                f"UPDATE {collection} SET data = ? WHERE id = ?",
                (json.dumps(updated_doc, default=str), self._get_id(updated_doc)),
            )
            self.conn.commit()

            return updated_doc if return_after else before_doc

    def create_index(self, collection: str, keys: list[tuple[str, int]], unique: bool = False) -> None:
        # For simplicity, we only optimize primary key (id) in find_one.
        # SQLite doesn't easily support indexing nested JSON without virtual columns.
        pass

    def distinct(self, collection: str, field: str, filter: dict[str, Any] | None = None) -> list[Any]:
        docs = self.find_many(collection, filter or {})
        distinct_values = set()
        for doc in docs:
            val = self._get_nested(doc, field)
            if val is not None:
                if isinstance(val, list):
                    distinct_values.update(val)
                else:
                    distinct_values.add(val)
        return list(distinct_values)

    def aggregate(self, collection: str, pipeline: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """
        Basic aggregation support for SQLite to provide analytics.
        Supports $match, $group, $sort, and $limit.
        """
        results = self.find_many(collection, {})

        for stage in pipeline:
            if not stage:
                continue

            op = next(iter(stage.keys()))
            val = stage[op]

            if op == "$match":
                results = [doc for doc in results if self._match(doc, val)]

            elif op == "$group":
                groups = {}
                id_spec = val.get("_id")

                for doc in results:
                    # Resolve group ID
                    group_id = None
                    if id_spec is None:
                        group_id = None
                    elif isinstance(id_spec, str) and id_spec.startswith("$"):
                        group_id = self._get_nested(doc, id_spec[1:])
                    elif isinstance(id_spec, dict):
                        # Handle operator like $dateToString
                        inner_op = next(iter(id_spec.keys()))
                        inner_val = id_spec[inner_op]
                        if inner_op == "$dateToString":
                            date_val = self._get_nested(doc, inner_val["date"][1:])
                            if date_val:
                                if isinstance(date_val, str):
                                    try:
                                        from datetime import datetime

                                        # Normalize string to aware datetime then format as string
                                        clean_v = date_val.replace("Z", "+00:00")
                                        dt = datetime.fromisoformat(clean_v)
                                        group_id = dt.strftime("%Y-%m-%d")
                                    except Exception:
                                        group_id = date_val[:10]
                                elif hasattr(date_val, "strftime"):
                                    group_id = date_val.strftime("%Y-%m-%d")
                                else:
                                    group_id = str(date_val)[:10]
                            else:
                                group_id = "Unknown"
                    else:
                        group_id = id_spec

                    if group_id not in groups:
                        groups[group_id] = {"_id": group_id}

                    for field, field_spec in val.items():
                        if field == "_id":
                            continue

                        acc_op = next(iter(field_spec.keys()))
                        acc_val = field_spec[acc_op]

                        if acc_op == "$sum":
                            increment = 0
                            if isinstance(acc_val, int):
                                increment = acc_val
                            elif isinstance(acc_val, str) and acc_val.startswith("$"):
                                increment = self._get_nested(doc, acc_val[1:]) or 0
                            elif isinstance(acc_val, dict):
                                # Handle $abs
                                sub_op = next(iter(acc_val.keys()))
                                sub_val = acc_val[sub_op]
                                if sub_op == "$abs":
                                    val_to_abs = self._get_nested(doc, sub_val[1:]) or 0
                                    increment = abs(val_to_abs)

                            groups[group_id][field] = groups[group_id].get(field, 0) + increment

                results = list(groups.values())

            elif op == "$sort":
                for key, reverse_val in reversed(list(val.items())):
                    results.sort(key=lambda x: self._safe_sort_key(x.get(key)), reverse=(reverse_val < 0))

            elif op == "$limit":
                results = results[:val]

        return results
