from abc import ABC, abstractmethod
from typing import Any


class DBEngine(ABC):
    """
    Abstract base class for all database engines in Gentiq.
    This interface defines the low-level operations required by the store classes.
    """

    @abstractmethod
    def find_one(
        self, collection: str, filter: dict[str, Any], projection: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        """Find a single document by filter."""
        pass

    @abstractmethod
    def find_many(
        self,
        collection: str,
        filter: dict[str, Any],
        projection: dict[str, Any] | None = None,
        sort: list[tuple[str, int]] | None = None,
        skip: int = 0,
        limit: int = 0,
    ) -> list[dict[str, Any]]:
        """Find multiple documents matching a filter."""
        pass

    @abstractmethod
    def insert_one(self, collection: str, document: dict[str, Any]) -> Any:
        """Insert a single document."""
        pass

    @abstractmethod
    def update_one(
        self,
        collection: str,
        filter: dict[str, Any],
        set_fields: dict[str, Any] | None = None,
        inc_fields: dict[str, Any] | None = None,
        push_fields: dict[str, Any] | None = None,
        set_on_insert: dict[str, Any] | None = None,
        upsert: bool = False,
    ) -> Any:
        """Update a single document matching a filter."""
        pass

    @abstractmethod
    def update_many(
        self,
        collection: str,
        filter: dict[str, Any],
        set_fields: dict[str, Any] | None = None,
        inc_fields: dict[str, Any] | None = None,
        push_fields: dict[str, Any] | None = None,
    ) -> int:
        """Update all documents matching a filter. Returns the number of modified documents."""
        pass

    @abstractmethod
    def delete_one(self, collection: str, filter: dict[str, Any]) -> bool:
        """Delete a single document matching a filter."""
        pass

    @abstractmethod
    def delete_many(self, collection: str, filter: dict[str, Any]) -> int:
        """Delete multiple documents matching a filter."""
        pass

    @abstractmethod
    def count_documents(self, collection: str, filter: dict[str, Any]) -> int:
        """Count documents matching a filter."""
        pass

    @abstractmethod
    def update_and_return(
        self,
        collection: str,
        filter: dict[str, Any],
        set_fields: dict[str, Any] | None = None,
        inc_fields: dict[str, Any] | None = None,
        return_after: bool = True,
    ) -> dict[str, Any] | None:
        """Atomically update and return a document."""
        pass

    @abstractmethod
    def create_index(self, collection: str, keys: list[tuple[str, int]], unique: bool = False) -> None:
        """Create an index on a collection."""
        pass

    @abstractmethod
    def distinct(self, collection: str, field: str, filter: dict[str, Any] | None = None) -> list[Any]:
        """Get unique values for a field across a collection."""
        pass

    @abstractmethod
    def aggregate(self, collection: str, pipeline: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Run an aggregation pipeline (generic interface, implementation varies)."""
        pass


class StorageEngine(ABC):
    """
    Abstract base class for all storage engines in Gentiq.
    This interface defines the low-level operations required by the store classes
    (e.g., ChatStore) to manage binary file persistence.
    """

    @abstractmethod
    def upload(self, container: str, object_name: str, data: Any, length: int) -> None:
        """Upload an object to a container."""
        pass

    @abstractmethod
    def download(self, container: str, object_name: str) -> Any:
        """Download an object from a container."""
        pass

    @abstractmethod
    def delete(self, container: str, object_name: str) -> None:
        """Delete an object from a container."""
        pass

    @abstractmethod
    def container_exists(self, container: str) -> bool:
        """Check if a container exists."""
        pass

    @abstractmethod
    def create_container(self, container: str) -> None:
        """Create a new container."""
        pass

    @abstractmethod
    def generate_url(self, container: str, object_name: str, expires: Any) -> str:
        """Generate a public or pre-signed URL for an object."""
        pass

    @abstractmethod
    def exists(self, container: str, object_name: str) -> bool:
        """Check if an object exists in a container."""
        pass
