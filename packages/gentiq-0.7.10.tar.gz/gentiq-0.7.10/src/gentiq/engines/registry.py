from collections.abc import Callable
from typing import Any, ClassVar

from .base import DBEngine, StorageEngine


class EngineRegistry:
    """Registry for managing and instantiating database and storage engines.

    The registry allows for pluggable persistence by mapping string identifiers
    (e.g., 'sqlite', 'mongodb') to engine factory functions or classes.
    """

    _db_engines: ClassVar[dict[str, Callable[..., DBEngine]]] = {}
    _storage_engines: ClassVar[dict[str, Callable[..., StorageEngine]]] = {}

    @classmethod
    def register_db_engine(cls, name: str, factory: Callable[..., DBEngine]) -> None:
        """Register a new database engine factory."""
        cls._db_engines[name] = factory

    @classmethod
    def get_db_engine(cls, name: str, **kwargs: Any) -> DBEngine:
        """Instantiate a registered database engine."""
        if name not in cls._db_engines:
            raise ValueError(f"Unsupported database type: {name}. Registered types: {list(cls._db_engines.keys())}")
        return cls._db_engines[name](**kwargs)

    @classmethod
    def register_storage_engine(cls, name: str, factory: Callable[..., StorageEngine]) -> None:
        """Register a new storage engine factory."""
        cls._storage_engines[name] = factory

    @classmethod
    def get_storage_engine(cls, name: str, **kwargs: Any) -> StorageEngine:
        """Instantiate a registered storage engine."""
        if name not in cls._storage_engines:
            raise ValueError(f"Unsupported storage type: {name}. Registered types: {list(cls._storage_engines.keys())}")
        return cls._storage_engines[name](**kwargs)


def register_db_engine(name: str):
    """Decorator to register a database engine class in the global registry.

    Example:
        @register_db_engine("my_custom_db")
        class MyCustomDB(DBEngine):
            ...
    """

    def decorator(cls: type[DBEngine]):
        EngineRegistry.register_db_engine(name, cls)
        return cls

    return decorator


def register_storage_engine(name: str):
    """Decorator to register a storage engine class."""

    def decorator(cls: type[StorageEngine]):
        EngineRegistry.register_storage_engine(name, cls)
        return cls

    return decorator
