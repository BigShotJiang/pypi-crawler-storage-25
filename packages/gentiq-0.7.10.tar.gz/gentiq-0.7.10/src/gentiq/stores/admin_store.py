from datetime import UTC, datetime

from ..engines.base import DBEngine
from ..env import ADMINS
from ..schemas import Admin


class AdminStore:
    """Store for managing administrative users and their access permissions.

    This class handles the persistence of admin accounts, authentication hashes, and
    fine-grained permission lists.

    Args:
        engine: The database engine instance for structured data.
        collection: The name of the collection/table for admin documents.
    """

    def __init__(self, engine: DBEngine, collection: str = ADMINS):
        self.engine = engine
        self.collection = collection

    def create_admin(
        self,
        admin_id: str,
        username: str,
        password_hash: str,
        name: str,
        permissions: list[str],
    ) -> Admin:
        admin = Admin(
            id=admin_id,
            username=username,
            password_hash=password_hash,
            name=name,
            permissions=permissions,
            created_at=datetime.now(UTC),
        )
        self.engine.insert_one(self.collection, admin.model_dump())
        return admin

    def list_admins(self) -> list[Admin]:
        docs = self.engine.find_many(self.collection, {})
        admins = []
        for doc in docs:
            doc.pop("_id", None)
            admins.append(Admin.model_validate(doc))
        return admins

    def update_admin(self, admin_id: str, update_data: dict) -> bool:
        self.engine.update_one(self.collection, {"id": admin_id}, set_fields=update_data)
        return True

    def delete_admin(self, admin_id: str) -> bool:
        return self.engine.delete_one(self.collection, {"id": admin_id})

    def get_admin_by_username(self, username: str) -> Admin | None:
        doc = self.engine.find_one(self.collection, {"username": username})
        if doc:
            doc.pop("_id", None)
            if "permissions" not in doc:
                doc["permissions"] = ["chat_history", "admin_management"]
            return Admin.model_validate(doc)
        return None

    def get_admin(self, admin_id: str) -> Admin | None:
        doc = self.engine.find_one(self.collection, {"id": admin_id})
        if not doc:
            return None
        doc.pop("_id", None)
        if "permissions" not in doc:
            doc["permissions"] = ["chat_history", "admin_management"]
        return Admin.model_validate(doc)
