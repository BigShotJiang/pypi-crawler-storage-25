from __future__ import annotations

import asyncio
import base64
import logging
import mimetypes
from collections.abc import AsyncIterator, Callable
from datetime import UTC, datetime
from json import dumps
from typing import Any, TypeVar

from pydantic_ai import Agent
from pydantic_ai.ui.vercel_ai import VercelAIAdapter
from pydantic_ai.ui.vercel_ai.request_types import FileUIPart
from pydantic_ai.ui.vercel_ai.response_types import DataChunk, TextDeltaChunk

from ..agent_deps import AgentDeps
from ..env import MAX_ATTACHMENT_SIZE
from ..schemas import User
from ..stores import ChatStore, UserStore


logger = logging.getLogger(__name__)

T_Context = TypeVar("T_Context")


class ChatService[T_Context]:
    """Service layer for handling chat-related business logic.

    Encapsulates message processing, attachment handling, AI title generation,
    and response streaming orchestration.
    """

    def __init__(
        self,
        chat_store: ChatStore,
        user_store: UserStore,
        agent: Agent,
        title_agent: Agent | None,
        create_agent_deps: Callable[[User], AgentDeps[T_Context]],
    ):
        self.chat_store = chat_store
        self.user_store = user_store
        self.agent = agent
        self.title_agent = title_agent
        self.create_agent_deps = create_agent_deps

    def preprocess_chat_request(self, body_dict: dict) -> bytes:
        """Preprocesses the chat request body for the Vercel AI SDK.

        Handles conversion of message contents to parts and resolves
        stored attachments (object_names) into data URIs for the LLM.

        Args:
            body_dict: The raw dictionary parsed from the request JSON.

        Returns:
            The preprocessed body as UTF-8 encoded bytes.
        """
        clean_messages = []

        for msg in body_dict.get("messages", []):
            raw_content = msg.get("content")
            raw_parts = msg.get("parts") or []

            # Convert simple content strings to structured parts if needed
            if not raw_parts and raw_content:
                raw_parts = [{"type": "text", "text": str(raw_content)}]

            clean_parts = []
            for part in raw_parts:
                if not isinstance(part, dict):
                    clean_parts.append(part)
                    continue

                p_type = part.get("type")
                if p_type == "file":
                    object_name = part.pop("object_name", None)
                    m_type = part.get("media_type") or part.get("mediaType") or "application/octet-stream"
                    url = part.get("url")

                    if object_name:
                        try:
                            content = self.chat_store.download_attachment(object_name)
                            encoded = base64.b64encode(content).decode("ascii")
                            url = f"data:{m_type};base64,{encoded}"
                        except Exception as dl_err:
                            logger.warning("Failed to fetch attachment %s: %s", object_name, dl_err)
                            clean_parts.append(
                                {
                                    "type": "text",
                                    "text": f"[Attachment {part.get('filename', 'file')} unavailable]",
                                }
                            )
                            continue

                    clean_parts.append(
                        {
                            "type": "file",
                            "media_type": m_type,
                            "filename": part.get("filename"),
                            "url": url,
                        }
                    )
                elif p_type == "text":
                    clean_parts.append(
                        {
                            "type": "text",
                            "text": part.get("text"),
                            "state": part.get("state"),
                        }
                    )
                elif p_type in ("reasoning", "thought"):
                    clean_parts.append(
                        {
                            "type": "reasoning",
                            "text": part.get("text") or part.get("reasoning"),
                            "state": part.get("state"),
                        }
                    )
                else:
                    clean_parts.append(part)

            clean_messages.append(
                {
                    "id": msg.get("id"),
                    "role": msg.get("role"),
                    "metadata": msg.get("metadata", {}),
                    "parts": clean_parts,
                }
            )

        clean_body = {
            "messages": clean_messages,
            "trigger": body_dict.get("trigger"),
            "id": body_dict.get("id"),
            "message_id": body_dict.get("message_id") or body_dict.get("messageId"),
        }

        compact_body = {k: v for k, v in clean_body.items() if v is not None}
        return dumps(compact_body).encode("utf-8")

    def handle_pre_stream_user_message(
        self,
        run_input: Any,
        thread_id: str,
        user_id: str,
    ) -> None:
        """Processes the user message before starting the LLM stream."""
        try:
            if not run_input.messages:
                self.chat_store.update_thread_info(thread_id, user_id=user_id)
                return

            last_user_msg = next(
                (msg for msg in reversed(run_input.messages) if self._get_message_role(msg) == "user"),
                None,
            )

            thread = self.chat_store.fetch_thread(thread_id)
            has_title = bool(thread.get("title")) if thread else False
            is_finalized = thread.get("title_finalized", False) if thread else False

            first_msg_text = ""
            for msg in run_input.messages:
                if self._get_message_role(msg) == "user":
                    first_msg_text = self._extract_text_from_message(msg).strip()
                    break

            if first_msg_text and not has_title and not is_finalized:
                fallback_title = (first_msg_text[:35] + "...") if len(first_msg_text) > 35 else first_msg_text
                self.chat_store.update_thread_info(thread_id, title=fallback_title, user_id=user_id)
            else:
                self.chat_store.update_thread_info(thread_id, user_id=user_id)

            if last_user_msg is None:
                return

            user_text = self._extract_text_from_message(last_user_msg).strip()
            user_msg_id = None
            if isinstance(last_user_msg, dict):
                user_msg_id = last_user_msg.get("id")
            elif hasattr(last_user_msg, "id"):
                user_msg_id = last_user_msg.id

            if not user_msg_id:
                timestamp = int(datetime.now(UTC).timestamp() * 1000)
                user_msg_id = f"msg_user_{thread_id}_{timestamp}"

            existing_msg = self.chat_store.fetch_thread_item(thread_id, user_msg_id)
            if existing_msg and "created_at" in existing_msg:
                deleted_count = self.chat_store.clear_thread_items_after(thread_id, existing_msg["created_at"])
                logger.info("Retry detected for message %s. Cleared %d forward items.", user_msg_id, deleted_count)

            file_parts = self._upload_file_parts(last_user_msg, user_id, thread_id, user_msg_id)
            text_part = {"type": "text", "text": user_text} if user_text else None
            parts = ([text_part] if text_part else []) + file_parts

            self.chat_store.save_thread_item(
                thread_id,
                {
                    "id": user_msg_id,
                    "role": "user",
                    "content": user_text,
                    "parts": parts,
                },
            )
        except Exception as e:
            logger.error("Error in pre-stream processing: %s", e)

    def _upload_file_parts(self, msg: Any, user_id: str, thread_id: str, msg_id: str) -> list[dict]:
        processed_parts: list[dict] = []
        file_index = 0

        raw_parts = []
        if hasattr(msg, "parts") and isinstance(msg.parts, list):
            raw_parts = msg.parts
        elif isinstance(msg, dict) and isinstance(msg.get("parts"), list):
            raw_parts = msg["parts"]

        for part in raw_parts:
            # Normalize part data
            is_file = False
            url = ""
            media_type = "application/octet-stream"
            filename = None

            if isinstance(part, FileUIPart):
                is_file = True
                url = part.url
                media_type = part.media_type
                filename = part.filename
            elif isinstance(part, dict) and part.get("type") == "file":
                is_file = True
                url = part.get("url", "")
                media_type = part.get("media_type") or part.get("mediaType") or "application/octet-stream"
                filename = part.get("filename")

            if not is_file:
                continue

            if url.startswith("data:"):
                decoded = self._decode_data_uri(url)
                if not decoded:
                    continue

                content, actual_media_type = decoded
                if len(content) > MAX_ATTACHMENT_SIZE:
                    logger.warning("Attachment too large (%d bytes), skipping", len(content))
                    continue

                object_name = self._get_attachment_key(
                    user_id,
                    thread_id,
                    msg_id,
                    file_index,
                    actual_media_type,
                    filename,
                )

                try:
                    self.chat_store.files_store.upload(
                        container=self.chat_store.attachments,
                        object_name=object_name,
                        data=content,
                        length=len(content),
                    )
                    self.chat_store.save_attachment(
                        attachment_id=object_name,
                        thread_id=thread_id,
                        user_id=user_id,
                        media_type=actual_media_type,
                        filename=filename,
                    )
                    processed_parts.append(
                        {
                            "type": "file",
                            "object_name": object_name,
                            "media_type": actual_media_type,
                            "mediaType": actual_media_type,
                            "filename": filename,
                        }
                    )
                    file_index += 1
                except Exception as e:
                    logger.error("Failed to upload attachment: %s", e)
            else:
                processed_parts.append(
                    {
                        "type": "file",
                        "url": url,
                        "media_type": media_type,
                        "mediaType": media_type,
                        "filename": filename,
                    }
                )
                file_index += 1

        return processed_parts

    async def _generate_thread_title(
        self,
        thread_id: str,
        first_msg_text: str,
        assistant_content: str,
    ) -> str | None:
        if not self.title_agent:
            return None

        try:
            truncated_query = first_msg_text[:500]
            truncated_response = assistant_content[:500]
            prompt = f"User question:\n{truncated_query}\n\nAssistant response:\n{truncated_response}"

            result = await self.title_agent.run(prompt)
            title = result.output.strip()

            if title:
                if len(title) > 80:
                    title = title[:77] + "..."
                self.chat_store.update_thread_info(thread_id, title=title, title_finalized=True)
                logger.info("Generated title for thread %s: %s", thread_id, title)
                return title
        except Exception:
            logger.exception("Title generation failed for thread %s — keeping fallback title", thread_id)

        return None

    async def handle_post_stream_assistant_message(
        self,
        run_result_holder: list[Any],
        run_input: Any,
        adapter: VercelAIAdapter[Any],
        thread_id: str,
        user_id: str,
        assistant_content: str,
        streamed_id: str | None = None,
        explicit_asst_id: str | None = None,
        assistant_parts: list[dict] | None = None,
    ) -> str | None:
        """Finalizes the assistant message and thread state after streaming."""
        try:
            if run_result_holder or assistant_content:
                run_result = run_result_holder[0] if run_result_holder else None
                asst_id = explicit_asst_id or streamed_id
                all_asst_parts = []

                if run_result:
                    ui_messages = adapter.dump_messages(run_result.new_messages())
                    for ui_msg in ui_messages:
                        if ui_msg.role == "assistant":
                            if not asst_id:
                                asst_id = ui_msg.id
                            all_asst_parts.extend([p.model_dump(mode="json") for p in ui_msg.parts])

                if not asst_id:
                    asst_id = explicit_asst_id or streamed_id

                if asst_id:
                    if not all_asst_parts and assistant_parts:
                        all_asst_parts = assistant_parts
                    if not all_asst_parts and assistant_content:
                        all_asst_parts = [{"type": "text", "text": assistant_content}]

                    self.chat_store.save_thread_item(
                        thread_id,
                        {
                            "id": asst_id,
                            "role": "assistant",
                            "content": assistant_content,
                            "parts": all_asst_parts,
                        },
                    )

                usage = None
                if run_result and callable(getattr(run_result, "usage", None)):
                    usage = run_result.usage()

                if usage:
                    self.chat_store.update_usage(user_id=user_id, thread_id=thread_id, usage=usage)

            # Title generation logic
            thread = self.chat_store.fetch_thread(thread_id)
            is_finalized = thread.get("title_finalized", False) if thread else False
            user_msg_count = sum(1 for m in run_input.messages if self._get_message_role(m) == "user")

            if not is_finalized and user_msg_count <= 3 and assistant_content:
                first_msg_text = ""
                for msg in run_input.messages:
                    if self._get_message_role(msg) == "user":
                        first_msg_text = self._extract_text_from_message(msg).strip()
                        break

                if first_msg_text:
                    return await self._generate_thread_title(thread_id, first_msg_text, assistant_content)

        except Exception as e:
            logger.error("Error in post-stream processing: %s", e)

        return None

    async def stream_chat(
        self,
        user: User,
        run_input: Any,
        adapter: VercelAIAdapter[Any],
        thread_id: str | None = None,
    ) -> AsyncIterator[Any]:
        """Managed stream generator that multiplexes LLM tokens and internal events."""
        run_result_holder: list[Any] = []

        async def _on_complete(result: Any):
            run_result_holder.append(result)

        agent_deps = self.create_agent_deps(user)
        asst_text: str = ""
        asst_parts: list[dict] = []
        streamed_msg_id: str | None = None
        is_processed = False

        explicit_msg_id = f"msg_asst_{thread_id}_{int(datetime.now(UTC).timestamp() * 1000)}" if thread_id else None

        if explicit_msg_id:
            yield DataChunk(data=[{"message_id": explicit_msg_id}], type="data-message-id")

        async def _safe_next(iterator):
            try:
                return await anext(iterator)
            except (StopAsyncIteration, GeneratorExit):
                return None

        try:
            llm_iter = aiter(adapter.run_stream(deps=agent_deps, on_complete=_on_complete))
            event_iter = aiter(agent_deps.stream_events())

            llm_task = asyncio.create_task(_safe_next(llm_iter))
            event_task = asyncio.create_task(_safe_next(event_iter))
            pending_tasks = {llm_task, event_task}

            while pending_tasks:
                done, pending_tasks = await asyncio.wait(pending_tasks, return_when=asyncio.FIRST_COMPLETED)

                for task in done:
                    if task == llm_task:
                        llm_event = task.result()
                        if llm_event is None:
                            if agent_deps._event_queue:
                                await agent_deps._event_queue.put(None)
                        else:
                            if hasattr(llm_event, "id") and streamed_msg_id is None:
                                streamed_msg_id = llm_event.id

                            if isinstance(llm_event, TextDeltaChunk):
                                asst_text += llm_event.delta
                                if not asst_parts or asst_parts[-1]["type"] != "text":
                                    asst_parts.append({"type": "text", "text": llm_event.delta})
                                else:
                                    asst_parts[-1]["text"] += llm_event.delta
                            elif hasattr(llm_event, "model_dump"):
                                data = llm_event.model_dump(mode="json")
                                if data.get("type") in ("reasoning", "tool-call", "tool-invocation", "tool-result"):
                                    asst_parts.append(data)

                            yield llm_event
                            llm_task = asyncio.create_task(_safe_next(llm_iter))
                            pending_tasks.add(llm_task)

                    elif task == event_task:
                        internal_msg = task.result()
                        if internal_msg is not None:
                            yield DataChunk(data=[internal_msg.model_dump(mode="json")], type="data-progress-update")
                            event_task = asyncio.create_task(_safe_next(event_iter))
                            pending_tasks.add(event_task)

        except (GeneratorExit, asyncio.CancelledError):
            raise
        finally:
            for task in pending_tasks:
                if not task.done():
                    task.cancel()

            if thread_id and not is_processed:
                is_processed = True
                try:
                    new_title = await asyncio.shield(
                        self.handle_post_stream_assistant_message(
                            run_result_holder=run_result_holder,
                            run_input=run_input,
                            adapter=adapter,
                            thread_id=thread_id,
                            user_id=user.id,
                            assistant_content=asst_text,
                            streamed_id=streamed_msg_id,
                            explicit_asst_id=explicit_msg_id,
                            assistant_parts=asst_parts if asst_parts else None,
                        )
                    )

                    if new_title:
                        yield DataChunk(data=[{"title": new_title}], type="data-title")

                    yield DataChunk(data=[{"finished": True}], type="data-chat-finished")
                except (asyncio.CancelledError, GeneratorExit):
                    pass
                except Exception as e:
                    logger.error("Failed post-stream persistence: %s", e)

    @staticmethod
    def _extract_text_from_message(msg: Any) -> str:
        """Extracts plain text from a Vercel AI SDK message object.

        Handles various formats including dictionaries, Pydantic models, and
        messages with complex nested parts.

        Args:
            msg: The message object (dict or Pydantic model) to extract text from.

        Returns:
            The extracted plain text string.
        """
        if isinstance(msg, dict):
            msg_content = msg.get("content", "")
            if isinstance(msg_content, list):
                return " ".join(
                    str(p.get("text", "")) for p in msg_content if isinstance(p, dict) and p.get("type") == "text"
                )
            return str(msg_content)

        if hasattr(msg, "parts") and isinstance(msg.parts, list):
            parts_content = []
            for part in msg.parts:
                if hasattr(part, "text"):
                    parts_content.append(str(part.text))
                elif hasattr(part, "content"):
                    parts_content.append(str(part.content))
                elif isinstance(part, dict):
                    parts_content.append(str(part.get("text", part.get("content", ""))))
            return " ".join(parts_content)

        if hasattr(msg, "content"):
            return str(msg.content)

        return str(msg)

    @staticmethod
    def _get_message_role(msg: Any) -> str:
        """Retrieves the role from a message object.

        Args:
            msg: The message object to inspect.

        Returns:
            The role string (e.g., 'user', 'assistant'). Defaults to 'user'.
        """
        if isinstance(msg, dict):
            return msg.get("role", "user")
        if hasattr(msg, "role"):
            return str(msg.role)
        return "user"

    @staticmethod
    def _decode_data_uri(data_uri: str) -> tuple[bytes, str] | None:
        """Decodes a data URI into raw bytes and its media type.

        Args:
            data_uri: The data URI string to decode.

        Returns:
            A tuple of (bytes, media_type) or None if decoding fails.
        """
        try:
            if not data_uri.startswith("data:"):
                return None

            header, encoded = data_uri.split(",", 1)
            meta = header[len("data:") :]
            media_type = meta.split(";")[0] if ";base64" in meta else meta
            content = base64.b64decode(encoded)
            return content, media_type
        except Exception as e:
            logger.warning("Failed to decode data URI: %s", e)
            return None

    @staticmethod
    def _get_attachment_key(
        user_id: str,
        thread_id: str,
        msg_id: str,
        index: int,
        media_type: str,
        filename: str | None,
    ) -> str:
        """Generates a unique storage key for an attachment.

        Args:
            user_id: The ID of the user owning the attachment.
            thread_id: The ID of the chat thread.
            msg_id: The ID of the message the attachment belongs to.
            index: The index of the attachment within the message.
            media_type: The media type of the attachment.
            filename: The original filename, if available.

        Returns:
            A unique string key for files_store.
        """
        extension = ""
        if filename and "." in filename:
            extension = "." + filename.rsplit(".", 1)[-1]
        else:
            extension = mimetypes.guess_extension(media_type) or ""

        return f"attachments/{user_id}/{thread_id}/{msg_id}/{index}{extension}"
