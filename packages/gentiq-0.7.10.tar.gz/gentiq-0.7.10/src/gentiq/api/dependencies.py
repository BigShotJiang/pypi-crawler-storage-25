from typing import Annotated, Any, Literal

from fastapi import Depends, HTTPException, Request
from fastapi.security import APIKeyHeader
from pydantic_ai import Agent

from ..auth import AuthAdapter
from ..env import BACKEND_API_KEY
from ..schemas import User
from ..stores import ChatStore, UserStore
from .enums import AdminPermission


__all__ = [
    "api_key_header",
    "get_agent",
    "get_chat_service",
    "get_chat_store",
    "get_context",
    "get_current_admin",
    "get_current_admin_optional",
    "get_current_user",
    "get_current_user_optional",
    "get_title_agent",
    "get_user_store",
    "require_permission",
    "verify_api_key",
]

api_key_header = APIKeyHeader(name="x-api-key", auto_error=False)


async def verify_api_key(api_key: str | None = Depends(api_key_header)) -> str | None:
    """Verify API key for server-to-server authentication."""
    if api_key != BACKEND_API_KEY:
        raise HTTPException(status_code=403, detail="Invalid API key")
    return api_key


async def get_current_user(request: Request) -> User:
    """Standard dependency to get the currently authenticated user."""
    auth_adapter: AuthAdapter = request.app.state.auth
    user = auth_adapter.get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required")
    return user


async def get_current_user_optional(request: Request) -> User | None:
    """Optional dependency to get the currently authenticated user."""
    auth_adapter: AuthAdapter = request.app.state.auth
    return auth_adapter.get_current_user(request)


async def get_current_admin(
    request: Request,
    api_key: str | None = Depends(api_key_header),
) -> dict | None:
    """
    Unified dependency to get current admin or verify API key.

    Returns:
        - dict: Admin information if authenticated via token.
        - None: If authenticated via valid API key.

    Raises:
        - HTTPException(401): If neither token nor API key is valid.
    """
    admin = await get_current_admin_optional(request, api_key)
    if admin is False:
        raise HTTPException(status_code=401, detail="Admin authentication required")
    return admin


async def get_current_admin_optional(
    request: Request,
    api_key: str | None = Depends(api_key_header),
) -> dict | None | Literal[False]:
    """
    Optional version of get_current_admin.
    Returns False if authentication failed but was attempted.
    """
    # 1. Try API Key first (server-to-server)
    if api_key and api_key == BACKEND_API_KEY:
        return None

    # 2. Try Admin Token
    auth_adapter: AuthAdapter = request.app.state.auth
    admin = auth_adapter.get_current_admin(request)
    if not admin:
        return False

    return admin


def require_permission(permission: AdminPermission):
    """Dependency factory to require a specific admin permission."""

    async def _permission_dependency(admin: Annotated[dict | None, Depends(get_current_admin)]):
        if admin is None:
            # Authenticated via API key, allow all
            return None

        if permission.value not in admin.get("permissions", []):
            raise HTTPException(
                status_code=403,
                detail=f"Permission denied: {permission.value} required",
            )
        return admin

    return _permission_dependency


# --- Core Component Dependencies ---


async def get_user_store(request: Request) -> UserStore:
    """FastAPI dependency to retrieve the UserStore instance from app state."""
    return request.app.state.user_store


async def get_chat_store(request: Request) -> ChatStore:
    """FastAPI dependency to retrieve the ChatStore instance from app state."""
    return request.app.state.chat_store


async def get_agent(request: Request) -> Agent:
    """FastAPI dependency to retrieve the main PydanticAI Agent from app state."""
    return request.app.state.agent


async def get_title_agent(request: Request) -> Agent | None:
    """FastAPI dependency to retrieve the title-generating Agent from app state."""
    return request.app.state.title_agent


async def get_chat_service(
    request: Request,
    user_store: Annotated[UserStore, Depends(get_user_store)],
    chat_store: Annotated[ChatStore, Depends(get_chat_store)],
    agent: Annotated[Agent, Depends(get_agent)],
    title_agent: Annotated[Agent | None, Depends(get_title_agent)],
):
    """FastAPI dependency to initialize and retrieve the ChatService."""
    from .chat_service import ChatService

    return ChatService(
        user_store=user_store,
        chat_store=chat_store,
        agent=agent,
        title_agent=title_agent,
        create_agent_deps=request.app.state.create_agent_deps,
    )


async def get_context(request: Request) -> Any:
    """FastAPI dependency to retrieve the custom application context from app state."""
    return request.app.state.context
