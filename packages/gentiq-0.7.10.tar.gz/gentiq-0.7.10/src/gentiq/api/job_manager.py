import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, ClassVar


@dataclass
class Job:
    """Represents a background job."""

    id: str
    type: str
    status: str  # "queued", "processing", "completed", "failed", "cancelled"
    user_id: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    metadata: dict[str, Any] | None = None
    progress: int = 0
    message: str | None = None
    result: dict[str, Any] | None = None
    error: str | None = None
    _cancel_event: asyncio.Event = field(default_factory=asyncio.Event)

    def cancel(self):
        """Mark the job as cancelled and set the cancellation event."""
        self.status = "cancelled"
        self.updated_at = datetime.now(UTC)
        self.message = "Job cancelled by user"
        self._cancel_event.set()

    @property
    def is_cancelled(self) -> bool:
        """Check if the job has been cancelled."""
        return self._cancel_event.is_set()

    def to_dict(self) -> dict:
        """Convert job to dictionary for API response."""
        return {
            "id": self.id,
            "type": self.type,
            "status": self.status,
            "user_id": self.user_id,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "metadata": self.metadata,
            "progress": self.progress,
            "message": self.message,
            "result": self.result,
            "error": self.error,
        }


class JobManager:
    """In-memory manager for background jobs."""

    _instance = None
    _jobs: ClassVar[dict[str, Job]] = {}

    @classmethod
    def get_instance(cls) -> "JobManager":
        """Get the singleton instance."""
        if cls._instance is None:
            cls._instance = JobManager()
        return cls._instance

    def create_job(
        self,
        type: str,
        user_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Job:
        """Create a new job."""
        job_id = f"job_{uuid.uuid4().hex}"
        job = Job(
            id=job_id,
            type=type,
            status="queued",
            user_id=user_id,
            metadata=metadata,
        )
        self._jobs[job_id] = job
        return job

    def get_job(self, job_id: str) -> Job | None:
        """Get a job by ID."""
        return self._jobs.get(job_id)

    def list_jobs(self, limit: int = 20, type: str | None = None) -> list[Job]:
        """List jobs, optionally filtered by type, sorted by most recent update."""
        jobs = list(self._jobs.values())
        if type:
            jobs = [j for j in jobs if j.type == type]

        # Sort by updated_at desc
        jobs.sort(key=lambda x: x.updated_at, reverse=True)
        return jobs[:limit]

    def update_job(
        self,
        job_id: str,
        status: str | None = None,
        progress: int | None = None,
        message: str | None = None,
        result: dict | None = None,
        error: str | None = None,
    ) -> None:
        """Update a job's status."""
        job = self.get_job(job_id)
        if not job:
            return

        # If job is already cancelled, don't allow status updates that might overwrite "cancelled"
        # unless it's strictly informational or progress, but usually we stop processing.
        if job.is_cancelled:
            return

        job.updated_at = datetime.now(UTC)
        if status is not None:
            job.status = status
        if progress is not None:
            job.progress = progress
        if message is not None:
            job.message = message
        if result is not None:
            job.result = result
        if error is not None:
            job.error = error

    def cancel_job(self, job_id: str) -> bool:
        """Cancel a job. Returns True if job found and cancelled."""
        job = self.get_job(job_id)
        if not job:
            return False

        if job.status in ["completed", "failed", "cancelled"]:
            return False

        job.cancel()
        return True


# Global instance
job_manager = JobManager.get_instance()
