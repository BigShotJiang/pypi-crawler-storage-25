from fastapi import APIRouter, HTTPException, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse, Response

from ...errors import ErrorCode, GentiqError
from ...stores import UserStore
from ..dependencies import get_current_user, get_current_user_optional
from ..inputs import UserUpdateInput
from ..security import hash_password


router = APIRouter()


@router.get("/users/me", tags=["User"])
async def get_me(request: Request) -> Response:
    """Endpoint to get current authenticated user profile."""
    try:
        user = await get_current_user(request)
    except HTTPException as e:
        raise e

    # Filter out sensitive data
    user_dict = user.model_dump(mode="json")
    user_dict.pop("password_hash", None)
    user_dict.pop("_id", None)
    user_dict.pop("token", None)

    return JSONResponse(jsonable_encoder(user_dict), status_code=200)


@router.patch("/users/me", tags=["User"])
async def update_current_user(request: Request, data: UserUpdateInput) -> Response:
    """Endpoint to update current authenticated user profile."""
    user_store: UserStore = request.app.state.user_store
    try:
        user = await get_current_user(request)
    except HTTPException as e:
        raise e

    if data.name is not None or data.surname is not None or data.metadata is not None:
        user_store.update_user_info(user.id, name=data.name, surname=data.surname, metadata=data.metadata)

    if data.phone is not None:
        # Check if phone is already taken
        existing = user_store.get_user_by_phone(data.phone)
        if existing and existing.id != user.id:
            raise GentiqError(ErrorCode.PHONE_ALREADY_EXISTS, status_code=400)
        user_store.update_user_phone(user.id, data.phone)

    if data.password is not None:
        user_store.update_user_password(user.id, hash_password(data.password))

    updated_user = user_store.get_user(user.id)
    if not updated_user:
        raise GentiqError(ErrorCode.USER_NOT_FOUND, status_code=500)

    user_dict = updated_user.model_dump(mode="json")
    user_dict.pop("password_hash", None)
    user_dict.pop("_id", None)
    user_dict.pop("token", None)

    return JSONResponse(jsonable_encoder(user_dict), status_code=200)


@router.get("/users/balance", tags=["User"])
async def get_user_balance(
    request: Request,
    phone: str | None = None,
) -> Response:
    """
    Endpoint to get a user's balance.
    Can be authenticated via JWT token or phone number.
    """
    user = None

    # Try JWT authentication
    user = await get_current_user_optional(request)

    if not user:
        raise GentiqError(ErrorCode.UNAUTHORIZED, status_code=401)

    balance = user.balance or {"tokens": 0, "requests": 0, "updated_at": None}
    return JSONResponse(jsonable_encoder(balance), status_code=200)
