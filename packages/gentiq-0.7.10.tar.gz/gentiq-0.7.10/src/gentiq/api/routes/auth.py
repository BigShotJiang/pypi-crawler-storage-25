import uuid

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, Response

from ...errors import ErrorCode, GentiqError
from ...stores import UserStore
from ..dependencies import verify_api_key
from ..inputs import LoginInput, RegisterUserInput
from ..security import hash_password


router = APIRouter()


@router.post("/auth/user", tags=["User"])
async def authorize_user(
    request: Request,
    data: RegisterUserInput,
    _: None = Depends(verify_api_key),
):
    """
    Endpoint to authorize or register a user with phone number. It returns a JWT token for authentication.
    Protected by API key.
    """
    user_store: UserStore = request.app.state.user_store
    auth_adapter = request.app.state.auth

    if not data.phone:
        raise GentiqError(ErrorCode.PHONE_REQUIRED, status_code=400)

    existing_user = user_store.get_user_by_phone(data.phone)

    if existing_user:
        token = auth_adapter.create_user_token(existing_user.id)
        user_store.update_user_token(existing_user.id, token)

        user_store.update_user_info(
            existing_user.id,
            name=data.name,
            surname=data.surname,
            metadata=data.metadata,
        )

        updated_user = user_store.get_user(existing_user.id)

        if not updated_user:
            raise GentiqError(ErrorCode.USER_NOT_FOUND, status_code=404)

        return updated_user.model_dump(mode="json")

    user_id = f"user_{uuid.uuid4().hex}"
    token = auth_adapter.create_user_token(user_id)

    try:
        user = user_store.create_user(
            user_id=user_id,
            phone=data.phone,
            name=data.name,
            surname=data.surname,
            token=token,
            metadata=data.metadata,
        )

        return JSONResponse(
            {
                "user_id": user.id,
                "phone": user.phone,
                "name": user.name,
                "surname": user.surname,
                "token": token,
                "created_at": user.created_at.isoformat(),
            },
            status_code=201,
        )
    except Exception as e:
        raise GentiqError(
            ErrorCode.INTERNAL_ERROR,
            message=f"Failed to create user: {e!s}",
            status_code=500,
        )


@router.post("/public/auth/register", tags=["User"])
async def public_register(
    request: Request,
    data: RegisterUserInput,
) -> Response:
    """Public endpoint for user registration. Creates a new user with password authentication."""
    user_store: UserStore = request.app.state.user_store
    auth_adapter = request.app.state.auth

    if not data.phone:
        raise GentiqError(ErrorCode.PHONE_REQUIRED, status_code=400)

    if not data.password:
        raise GentiqError(ErrorCode.PASSWORD_REQUIRED, status_code=400)

    if not data.name or not data.surname:
        raise GentiqError(ErrorCode.NAME_SURNAME_REQUIRED, status_code=400)

    existing_user = user_store.get_user_by_phone(data.phone)
    if existing_user:
        raise GentiqError(ErrorCode.PHONE_ALREADY_EXISTS, status_code=400)

    user_id = f"user_{uuid.uuid4().hex}"
    token = auth_adapter.create_user_token(user_id)

    password_hash = hash_password(data.password)

    try:
        user = user_store.create_user(
            user_id=user_id,
            phone=data.phone,
            password_hash=password_hash,
            name=data.name,
            surname=data.surname,
            token=token,
            metadata=data.metadata,
        )

        return JSONResponse(
            {
                "user_id": user.id,
                "phone": user.phone,
                "name": user.name,
                "surname": user.surname,
                "token": token,
            },
            status_code=201,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to create user: {e!s}"},
            status_code=500,
        )


@router.post("/public/auth/login", tags=["User"])
async def public_login(
    request: Request,
    data: LoginInput,
) -> Response:
    """Public endpoint for user login. Authenticates user with phone and password."""
    user_store: UserStore = request.app.state.user_store
    auth_adapter = request.app.state.auth

    if not data.phone or not data.password:
        raise GentiqError(ErrorCode.INVALID_CREDENTIALS, status_code=400)

    user = user_store.get_user_by_phone(data.phone)
    if not user or hash_password(data.password) != user.password_hash:
        raise GentiqError(ErrorCode.INVALID_CREDENTIALS, status_code=401)

    token = auth_adapter.create_user_token(user.id)
    user_store.update_user_token(user.id, token)

    return JSONResponse(
        {
            "user_id": user.id,
            "phone": user.phone,
            "name": user.name,
            "surname": user.surname,
            "token": token,
        },
        status_code=200,
    )
