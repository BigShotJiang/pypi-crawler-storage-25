from pydantic_ai import Agent

from .env import HTTP_PROXY


__all__ = ["get_anthropic_model", "get_google_model", "get_openai_model"]


def get_openai_model(model_name: str, proxy: str | None = None):
    """Create an OpenAI chat model instance with optional proxy support."""
    import httpx
    from pydantic_ai.models.openai import OpenAIChatModel
    from pydantic_ai.providers.openai import OpenAIProvider

    if proxy:
        http_client = httpx.AsyncClient(
            proxy=proxy,
            timeout=30,
            follow_redirects=True,
        )
        provider = OpenAIProvider(http_client=http_client)
    else:
        provider = OpenAIProvider()

    openai_model = OpenAIChatModel(model_name=model_name, provider=provider)

    return openai_model


def get_anthropic_model(model_name: str, proxy: str | None = None):
    """Create an Anthropic model instance with optional proxy support."""
    import httpx
    from pydantic_ai.models.anthropic import AnthropicModel
    from pydantic_ai.providers.anthropic import AnthropicProvider

    if proxy:
        http_client = httpx.AsyncClient(
            proxy=proxy,
            timeout=30,
            follow_redirects=True,
        )
        provider = AnthropicProvider(http_client=http_client)
    else:
        provider = AnthropicProvider()

    anthropic_model = AnthropicModel(model_name=model_name, provider=provider)

    return anthropic_model


def get_google_model(model_name: str, proxy: str | None = None):
    """Create a Google Generative AI model instance with optional proxy support."""
    import httpx
    from pydantic_ai.models.google import GoogleModel
    from pydantic_ai.providers.google import GoogleProvider

    if proxy:
        http_client = httpx.AsyncClient(
            proxy=proxy,
            timeout=30,
            follow_redirects=True,
        )
        provider = GoogleProvider(http_client=http_client)
    else:
        provider = GoogleProvider()

    google_model = GoogleModel(model_name=model_name, provider=provider)

    return google_model


def create_title_agent(model_name: str, instructions: str | None = None, proxy: str | None = HTTP_PROXY):
    """Create a specialized Agent for generating concise conversation titles.

    The title is typically generated from the first user message and the initial
    assistant response to provide context in the chat history sidebar.
    """
    default_instructions = (
        "You are a title generator. Given a user question and an assistant response, "
        "produce a short, descriptive title of 2 to 5 words that captures the topic. "
        "Output ONLY the title text — no quotes, no explanation, no punctuation at the end."
    )
    instructions = instructions or default_instructions
    if model_name.startswith("gpt"):
        model = get_openai_model(model_name, proxy)
    elif model_name.startswith("claude"):
        model = get_anthropic_model(model_name, proxy)
    elif model_name.startswith("gemini"):
        model = get_google_model(model_name, proxy)
    else:
        raise ValueError(f"Unsupported model: {model_name}")

    return Agent(
        name="title_agent",
        instructions=instructions,
        model=model,
    )
