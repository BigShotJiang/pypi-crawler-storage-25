"""Publication figure and table generators for Nature/Science submission."""
