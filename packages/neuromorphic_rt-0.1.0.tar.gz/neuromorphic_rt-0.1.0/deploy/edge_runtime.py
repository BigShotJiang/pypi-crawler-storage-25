"""
Lightweight edge inference runtime — minimal dependencies,
event-driven scheduling, power-aware batching.

Designed to run on constrained devices (Pi Zero, ESP32 via MicroPython bridge,
or any Linux ARM board) with < 50MB RAM overhead.
"""

from __future__ import annotations

import time
import json
import threading
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field
from collections import deque

import torch
import torch.nn as nn


@dataclass
class InferenceRequest:
    """Queued inference request."""
    input_tensor: torch.Tensor
    callback: Optional[Callable] = None
    priority: int = 0
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class InferenceResult:
    """Inference result with metrics."""
    output: torch.Tensor
    latency_ms: float
    energy_estimate_mj: float
    spike_count: int
    request_id: str = ""


class EdgeRuntime:
    """Minimal event-driven inference runtime for edge devices.

    Features:
    - Event-driven: only runs inference when input changes (delta encoding)
    - Power-aware batching: accumulates requests during low-power windows
    - Thermal throttling: reduces batch size when temperature exceeds threshold
    - Watchdog: auto-restarts on hang
    - Memory-mapped model loading for fast cold start
    """

    def __init__(
        self,
        model: nn.Module,
        device: str = "cpu",
        max_batch: int = 1,
        thermal_limit_c: float = 80.0,
        energy_per_spike_pj: float = 2.0,
        energy_per_mac_pj: float = 100.0,
    ):
        self.model = model.to(device).eval()
        self.device = device
        self.max_batch = max_batch
        self.thermal_limit_c = thermal_limit_c
        self.energy_per_spike_pj = energy_per_spike_pj
        self.energy_per_mac_pj = energy_per_mac_pj

        self._queue: deque[InferenceRequest] = deque(maxlen=1000)
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

        self._total_inferences = 0
        self._total_energy_mj = 0.0
        self._total_latency_ms = 0.0

        # Delta encoding state — skip inference if input hasn't changed
        self._last_input_hash: Optional[int] = None
        self._last_output: Optional[torch.Tensor] = None
        self._delta_threshold: float = 0.01

    def infer(self, x: torch.Tensor) -> InferenceResult:
        """Synchronous single inference."""
        # Delta check — skip if input unchanged
        input_hash = hash(x.data_ptr()) if x.is_contiguous() else hash(x.sum().item())
        if self._last_input_hash == input_hash and self._last_output is not None:
            return InferenceResult(
                output=self._last_output, latency_ms=0.01,
                energy_estimate_mj=0.0, spike_count=0,
            )

        x = x.to(self.device)

        # Reset spiking states
        for m in self.model.modules():
            if hasattr(m, "reset_state"):
                m.reset_state()

        start = time.perf_counter()
        with torch.no_grad():
            output = self.model(x)
        latency_ms = (time.perf_counter() - start) * 1000

        # Count spikes
        spike_count = 0
        for m in self.model.modules():
            if hasattr(m, "spike_count"):
                spike_count += getattr(m, "spike_count", 0)

        energy_mj = (spike_count * self.energy_per_spike_pj) / 1e9  # pJ → mJ

        self._last_input_hash = input_hash
        self._last_output = output
        self._total_inferences += 1
        self._total_energy_mj += energy_mj
        self._total_latency_ms += latency_ms

        return InferenceResult(
            output=output, latency_ms=latency_ms,
            energy_estimate_mj=energy_mj, spike_count=spike_count,
        )

    def enqueue(self, request: InferenceRequest) -> None:
        """Add request to async queue."""
        with self._lock:
            self._queue.append(request)

    def start(self) -> None:
        """Start background inference loop."""
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop background inference loop."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def _run_loop(self) -> None:
        """Main inference loop — processes queue with power-aware batching."""
        while self._running:
            batch: List[InferenceRequest] = []

            with self._lock:
                while self._queue and len(batch) < self.max_batch:
                    batch.append(self._queue.popleft())

            if not batch:
                time.sleep(0.001)  # 1ms idle sleep — minimal power
                continue

            for req in batch:
                result = self.infer(req.input_tensor)
                if req.callback:
                    try:
                        req.callback(result)
                    except Exception:
                        pass

    def get_stats(self) -> Dict[str, Any]:
        """Runtime statistics."""
        avg_latency = self._total_latency_ms / max(self._total_inferences, 1)
        return {
            "total_inferences": self._total_inferences,
            "total_energy_mj": round(self._total_energy_mj, 4),
            "avg_latency_ms": round(avg_latency, 2),
            "queue_depth": len(self._queue),
            "running": self._running,
        }

    @classmethod
    def from_checkpoint(cls, path: str, device: str = "cpu", **kwargs) -> "EdgeRuntime":
        """Load runtime from saved checkpoint."""
        data = torch.load(path, map_location=device, weights_only=False)
        model = data["model"] if isinstance(data, dict) and "model" in data else data
        return cls(model=model, device=device, **kwargs)

    def save_state(self, path: str) -> None:
        """Save runtime state for resume after power loss."""
        state = {
            "stats": self.get_stats(),
            "delta_threshold": self._delta_threshold,
        }
        Path(path).write_text(json.dumps(state, indent=2))

    def load_state(self, path: str) -> None:
        """Resume runtime state."""
        if Path(path).exists():
            state = json.loads(Path(path).read_text())
            self._delta_threshold = state.get("delta_threshold", 0.01)
