"""
Raspberry Pi 5 deployment: ARM optimization, picamera2 integration,
GPIO sensor management, and systemd service generation.
"""

from __future__ import annotations

import subprocess
import json
from pathlib import Path
from typing import Dict, Optional
from dataclasses import dataclass

import torch
import torch.nn as nn


@dataclass
class PiStatus:
    """Raspberry Pi device status."""
    cpu_temp_c: float
    cpu_freq_mhz: float
    cpu_util_pct: float
    memory_used_mb: float
    memory_total_mb: float
    throttled: bool
    voltage_ok: bool


class PiDeployer:
    """Deploy and optimize models for Raspberry Pi 5.

    Handles ARM-optimized export, power management,
    thermal monitoring, and systemd service creation.
    Pi 5 has no GPU — all inference is CPU (Cortex-A76).
    """

    def __init__(self):
        self.is_pi = Path("/proc/device-tree/model").exists()
        self._model_name = None

    def prepare_model(
        self,
        model: nn.Module,
        example_input: torch.Tensor,
        output_path: str = "model_pi.pth",
        quantize: bool = True,
    ) -> str:
        """Optimize model for Pi 5 deployment.

        Uses dynamic INT8 quantization by default for ~3x speedup on ARM.
        """
        model.eval()

        for m in model.modules():
            if hasattr(m, "reset_state"):
                m.reset_state()

        # INT8 dynamic quantization — best for Pi 5 Cortex-A76
        if quantize:
            try:
                quantized = torch.quantization.quantize_dynamic(
                    model, {nn.Linear, nn.Conv2d}, dtype=torch.qint8,
                )
                torch.save({"model": quantized, "quantized": True}, output_path)
                return output_path
            except Exception:
                pass

        # TorchScript trace fallback
        try:
            traced = torch.jit.trace(model, example_input)
            ts_path = output_path.replace(".pth", "_traced.pt")
            traced.save(ts_path)
            return ts_path
        except Exception:
            pass

        # Last resort: save full model
        torch.save({"model": model, "state_dict": model.state_dict()}, output_path)
        return output_path

    def get_status(self) -> PiStatus:
        """Get current Pi device status."""
        if not self.is_pi:
            return PiStatus(
                cpu_temp_c=45.0, cpu_freq_mhz=2400.0, cpu_util_pct=15.0,
                memory_used_mb=2048, memory_total_mb=16384,
                throttled=False, voltage_ok=True,
            )

        temp = 45.0
        try:
            temp = float(Path("/sys/class/thermal/thermal_zone0/temp").read_text()) / 1000
        except Exception:
            pass

        freq = 2400.0
        try:
            freq = float(Path("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq").read_text()) / 1000
        except Exception:
            pass

        throttled = False
        try:
            result = subprocess.run(
                ["vcgencmd", "get_throttled"], capture_output=True, text=True, timeout=5,
            )
            throttled = "0x0" not in result.stdout
        except Exception:
            pass

        return PiStatus(
            cpu_temp_c=temp, cpu_freq_mhz=freq, cpu_util_pct=0,
            memory_used_mb=0, memory_total_mb=16384,
            throttled=throttled, voltage_ok=not throttled,
        )

    def set_governor(self, governor: str = "performance") -> None:
        """Set CPU frequency governor.

        Args:
            governor: 'performance', 'powersave', 'ondemand', 'conservative'.
        """
        if not self.is_pi:
            print(f"[sim] Would set governor to {governor}")
            return

        for i in range(4):
            try:
                Path(f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_governor").write_text(governor)
            except PermissionError:
                subprocess.run(
                    ["sudo", "sh", "-c", f"echo {governor} > /sys/devices/system/cpu/cpu{i}/cpufreq/scaling_governor"],
                    check=False,
                )

    def create_service(
        self,
        model_path: str,
        service_name: str = "neuromorphic-rt",
        port: int = 8080,
    ) -> str:
        """Generate systemd service file for Pi 5."""
        service_content = f"""[Unit]
Description=NeuromorphicRT Edge AI Runtime (Pi 5)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=pi
WorkingDirectory=/opt/neuromorphic-rt
ExecStartPre=/usr/bin/python3 -c "import torch; print(f'PyTorch {{torch.__version__}} ready')"
ExecStart=/usr/bin/python3 -m neuromorphic_rt.cli serve \\
    --model {model_path} \\
    --port {port} \\
    --host 0.0.0.0
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
Environment=PYTHONUNBUFFERED=1
Environment=OMP_NUM_THREADS=4
Environment=TORCH_NUM_THREADS=4
Nice=-5

[Install]
WantedBy=multi-user.target
"""
        service_path = f"/tmp/{service_name}-pi.service"
        with open(service_path, "w") as f:
            f.write(service_content)

        return service_path

    def monitor_thermals(self) -> Dict[str, float]:
        """Read Pi thermal zones."""
        temps = {}
        try:
            temp = float(Path("/sys/class/thermal/thermal_zone0/temp").read_text()) / 1000
            temps["cpu"] = temp
        except Exception:
            temps["cpu"] = 45.0

        # Check if throttling
        try:
            result = subprocess.run(
                ["vcgencmd", "measure_temp"], capture_output=True, text=True, timeout=5,
            )
            if "temp=" in result.stdout:
                temps["vcgencmd"] = float(result.stdout.split("=")[1].split("'")[0])
        except Exception:
            pass

        return temps or {"cpu": 45.0}

    def estimate_inference_time(self, model: nn.Module, input_shape: tuple) -> float:
        """Estimate inference time on Pi 5 (ms).

        Pi 5 Cortex-A76 @ 2.4GHz ≈ 19.2 GFLOPS FP32, ~38 GFLOPS INT8.
        """
        total_flops = 0
        for m in model.modules():
            if isinstance(m, nn.Linear):
                total_flops += 2 * m.in_features * m.out_features
            elif isinstance(m, nn.Conv2d):
                # Rough estimate
                total_flops += 2 * m.in_channels * m.out_channels * m.kernel_size[0] * m.kernel_size[1]

        gflops = total_flops / 1e9
        est_ms = (gflops / 19.2) * 1000  # FP32 estimate
        return max(est_ms, 0.1)
