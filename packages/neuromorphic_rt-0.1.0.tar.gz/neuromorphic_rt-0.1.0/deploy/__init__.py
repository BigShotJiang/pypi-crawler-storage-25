"""NeuromorphicRT deployment: Jetson, Pi, edge runtime."""
