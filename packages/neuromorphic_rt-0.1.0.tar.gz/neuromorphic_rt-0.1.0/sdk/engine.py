"""
NeuromorphicRT Inference Engine — drop-in TensorRT replacement.

Loads spiking models, optimizes for target hardware, benchmarks
energy consumption, and runs inference with spike-aware profiling.
"""

from __future__ import annotations

import time
import torch
import torch.nn as nn
from torch import Tensor
from dataclasses import dataclass, field
from typing import Optional, Dict, Any
from pathlib import Path


@dataclass
class InferenceResult:
    """Result from a single inference call."""
    output: Tensor
    latency_ms: float
    spike_count: int
    active_neurons: int
    total_neurons: int
    spike_rate: float
    estimated_energy_mj: float  # Millijoules
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BenchmarkResult:
    """Result from benchmarking a model."""
    avg_latency_ms: float
    std_latency_ms: float
    avg_energy_mj: float
    avg_spike_rate: float
    throughput_fps: float
    total_macs: int
    total_spike_events: int
    energy_per_mac_pj: float
    model_params: int
    device: str


class NeuromorphicEngine:
    """Main inference engine for NeuromorphicRT.

    Drop-in replacement for TensorRT: load model, optimize, infer.

    Example:
        engine = NeuromorphicEngine()
        engine.load_model("spike_resnet.pth")
        engine.optimize(target="jetson_orin_nano")
        result = engine.infer(input_tensor)
        print(f"Energy: {result.estimated_energy_mj:.3f} mJ")
    """

    # Energy per operation by hardware target (picojoules)
    ENERGY_MODELS = {
        "jetson_orin_nano": {
            "mac_gpu": 45.0,       # pJ per MAC on GPU
            "mac_tensor": 3.7,     # pJ per MAC on Tensor Core
            "spike_event": 0.9,    # pJ per spike event (event-driven)
            "memory_read": 12.0,   # pJ per DRAM read (64 bytes)
            "memory_write": 15.0,  # pJ per DRAM write
            "static_power_w": 1.5, # Watts idle power
        },
        "raspberry_pi5": {
            "mac_gpu": 120.0,
            "mac_tensor": 120.0,  # No tensor cores
            "spike_event": 2.1,
            "memory_read": 20.0,
            "memory_write": 25.0,
            "static_power_w": 2.5,
        },
        "generic_cpu": {
            "mac_gpu": 200.0,
            "mac_tensor": 200.0,
            "spike_event": 5.0,
            "memory_read": 30.0,
            "memory_write": 35.0,
            "static_power_w": 15.0,
        },
    }

    def __init__(self):
        self.model: Optional[nn.Module] = None
        self.device = torch.device("cpu")
        self.target = "generic_cpu"
        self.optimized = False
        self._hooks = []
        self._spike_counts: Dict[str, int] = {}
        self._mac_counts: Dict[str, int] = {}

    def load_model(self, path: str) -> None:
        """Load a spiking model from checkpoint."""
        checkpoint = torch.load(path, map_location=self.device, weights_only=False)
        if isinstance(checkpoint, dict) and "model" in checkpoint:
            self.model = checkpoint["model"]
        elif isinstance(checkpoint, nn.Module):
            self.model = checkpoint
        else:
            raise ValueError("Checkpoint must contain 'model' key or be an nn.Module")
        self.model.eval()

    def from_pytorch(self, model: nn.Module, example_input: Optional[Tensor] = None) -> None:
        """Load a PyTorch model directly (already spiking or will be converted)."""
        self.model = model.to(self.device)
        self.model.eval()

    def optimize(self, target: str = "jetson_orin_nano") -> None:
        """Apply hardware-specific optimizations.

        Args:
            target: Hardware target. One of: jetson_orin_nano, raspberry_pi5, generic_cpu.
        """
        if self.model is None:
            raise RuntimeError("No model loaded. Call load_model() or from_pytorch() first.")

        self.target = target

        # Fuse BatchNorm into Conv/Linear where possible
        self.model = torch.quantization.fuse_modules(
            self.model, [], inplace=False
        ) if hasattr(self.model, 'fuse_modules') else self.model

        # Move to appropriate device
        if target == "jetson_orin_nano" and torch.cuda.is_available():
            self.device = torch.device("cuda")
        else:
            self.device = torch.device("cpu")

        self.model = self.model.to(self.device)

        # Enable torch.compile if available
        if hasattr(torch, "compile"):
            try:
                self.model = torch.compile(self.model, mode="reduce-overhead")
            except Exception:
                pass  # Fallback to eager mode

        self.optimized = True

    def benchmark(
        self,
        input_data: Tensor,
        num_runs: int = 100,
        warmup: int = 10,
    ) -> BenchmarkResult:
        """Benchmark model performance and energy.

        Args:
            input_data: Example input tensor.
            num_runs: Number of benchmark iterations. Default 100.
            warmup: Warmup iterations (excluded from timing). Default 10.

        Returns:
            BenchmarkResult with latency, energy, throughput stats.
        """
        if self.model is None:
            raise RuntimeError("No model loaded.")

        input_data = input_data.to(self.device)

        # Install profiling hooks
        self._install_hooks()

        # Warmup
        with torch.no_grad():
            for _ in range(warmup):
                self._reset_model_states()
                self.model(input_data)

        # Benchmark
        latencies = []
        spike_counts = []
        mac_counts = []

        with torch.no_grad():
            for _ in range(num_runs):
                self._reset_model_states()
                self._spike_counts.clear()
                self._mac_counts.clear()

                if torch.cuda.is_available():
                    torch.cuda.synchronize()

                t0 = time.perf_counter()
                self.model(input_data)

                if torch.cuda.is_available():
                    torch.cuda.synchronize()

                t1 = time.perf_counter()
                latencies.append((t1 - t0) * 1000)  # ms
                spike_counts.append(sum(self._spike_counts.values()))
                mac_counts.append(sum(self._mac_counts.values()))

        self._remove_hooks()

        latencies_t = torch.tensor(latencies)
        energy_model = self.ENERGY_MODELS[self.target]

        avg_spikes = sum(spike_counts) / len(spike_counts)
        avg_macs = sum(mac_counts) / len(mac_counts) if mac_counts else 0

        # Energy estimation: spikes are cheap, MACs are expensive
        avg_energy_pj = (
            avg_spikes * energy_model["spike_event"]
            + avg_macs * energy_model["mac_gpu"]
        )
        avg_energy_mj = avg_energy_pj / 1e9  # pJ → mJ

        # Add static power contribution
        avg_latency_s = latencies_t.mean().item() / 1000
        static_energy_mj = energy_model["static_power_w"] * avg_latency_s * 1000

        total_params = sum(p.numel() for p in self.model.parameters())

        return BenchmarkResult(
            avg_latency_ms=latencies_t.mean().item(),
            std_latency_ms=latencies_t.std().item(),
            avg_energy_mj=avg_energy_mj + static_energy_mj,
            avg_spike_rate=avg_spikes / max(total_params, 1),
            throughput_fps=1000.0 / latencies_t.mean().item(),
            total_macs=int(avg_macs),
            total_spike_events=int(avg_spikes),
            energy_per_mac_pj=energy_model["mac_gpu"],
            model_params=total_params,
            device=str(self.device),
        )

    def infer(self, input_tensor: Tensor) -> InferenceResult:
        """Run single inference with profiling.

        Args:
            input_tensor: Model input.

        Returns:
            InferenceResult with output, timing, and energy metrics.
        """
        if self.model is None:
            raise RuntimeError("No model loaded.")

        input_tensor = input_tensor.to(self.device)
        self._reset_model_states()
        self._install_hooks()
        self._spike_counts.clear()
        self._mac_counts.clear()

        with torch.no_grad():
            if torch.cuda.is_available():
                torch.cuda.synchronize()
            t0 = time.perf_counter()
            output = self.model(input_tensor)
            if torch.cuda.is_available():
                torch.cuda.synchronize()
            t1 = time.perf_counter()

        self._remove_hooks()

        total_spikes = sum(self._spike_counts.values())
        total_macs = sum(self._mac_counts.values())
        total_neurons = sum(p.numel() for p in self.model.parameters())

        # Also count TTFS neurons (they track spikes internally)
        from neuromorphic_rt.core.neurons import TTFSNeuron
        for m in self.model.modules():
            if isinstance(m, TTFSNeuron):
                total_spikes += m.total_spikes

        energy_model = self.ENERGY_MODELS[self.target]
        energy_pj = total_spikes * energy_model["spike_event"] + total_macs * energy_model["mac_gpu"]
        energy_mj = energy_pj / 1e9

        latency_ms = (t1 - t0) * 1000

        # Handle dict outputs (from fusion model)
        if isinstance(output, dict):
            out_tensor = output.get("classification", output.get("anomaly_score", torch.tensor(0)))
        else:
            out_tensor = output

        return InferenceResult(
            output=out_tensor,
            latency_ms=latency_ms,
            spike_count=total_spikes,
            active_neurons=total_spikes,
            total_neurons=total_neurons,
            spike_rate=total_spikes / max(total_neurons, 1),
            estimated_energy_mj=energy_mj,
        )

    def to(self, device: str) -> "NeuromorphicEngine":
        """Move engine to device."""
        self.device = torch.device(device)
        if self.model is not None:
            self.model = self.model.to(self.device)
        return self

    def _install_hooks(self):
        """Install forward hooks to count spikes and MACs."""
        from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire, TTFSNeuron

        for name, module in self.model.named_modules():
            if isinstance(module, TTFSNeuron):
                hook = module.register_forward_hook(
                    lambda m, inp, out, n=name: self._spike_counts.update(
                        {n: int(out.sum().item())}
                    )
                )
                self._hooks.append(hook)
            elif isinstance(module, LeakyIntegrateAndFire):
                hook = module.register_forward_hook(
                    lambda m, inp, out, n=name: self._spike_counts.update(
                        {n: int(out.sum().item())}
                    )
                )
                self._hooks.append(hook)
            elif isinstance(module, (nn.Linear, nn.Conv2d, nn.Conv1d)):
                hook = module.register_forward_hook(
                    lambda m, inp, out, n=name: self._mac_counts.update(
                        {n: self._count_macs(m, inp[0], out)}
                    )
                )
                self._hooks.append(hook)

    def _remove_hooks(self):
        for hook in self._hooks:
            hook.remove()
        self._hooks.clear()

    @staticmethod
    def _count_macs(module: nn.Module, input: Tensor, output: Tensor) -> int:
        if isinstance(module, nn.Linear):
            return int(input.shape[-1] * output.shape[-1] * input.shape[0])
        elif isinstance(module, nn.Conv2d):
            k = module.kernel_size[0] * module.kernel_size[1]
            return int(k * module.in_channels * output.numel())
        elif isinstance(module, nn.Conv1d):
            k = module.kernel_size[0]
            return int(k * module.in_channels * output.numel())
        return 0

    def _reset_model_states(self):
        for m in self.model.modules():
            if hasattr(m, "reset_state"):
                m.reset_state()
