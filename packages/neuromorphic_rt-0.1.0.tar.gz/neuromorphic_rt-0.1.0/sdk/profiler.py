"""
Energy profiler: measure and estimate energy consumption per inference.

Provides hardware-specific energy models for accurate comparison
between DNN and spiking inference. This data goes in the paper.
"""

from __future__ import annotations

import csv
import json
import torch
import torch.nn as nn
from torch import Tensor
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from pathlib import Path


@dataclass
class LayerProfile:
    """Energy profile for a single layer."""
    name: str
    layer_type: str
    spike_events: int
    mac_operations: int
    memory_reads: int
    memory_writes: int
    energy_pj: float  # Picojoules
    spike_rate: float
    params: int


@dataclass
class EnergyReport:
    """Complete energy profiling report."""
    model_name: str
    target_hardware: str
    total_energy_mj: float
    total_spike_events: int
    total_mac_operations: int
    spike_energy_mj: float
    mac_energy_mj: float
    memory_energy_mj: float
    static_energy_mj: float
    avg_spike_rate: float
    layer_profiles: List[LayerProfile]
    dnn_equivalent_energy_mj: Optional[float] = None
    energy_ratio: Optional[float] = None  # spike/dnn


class EnergyProfiler:
    """Profile energy consumption of spiking neural networks.

    Hooks into every layer, counts spike events and MAC operations,
    then estimates energy using hardware-specific energy models.

    Usage:
        profiler = EnergyProfiler(target="jetson_orin_nano")
        report = profiler.profile(model, input_data)
        comparison = profiler.compare(spike_model, dnn_model, input_data)
        profiler.to_csv(report, "energy_results.csv")
    """

    ENERGY_PER_OP = {
        "jetson_orin_nano": {
            "mac_pj": 45.0,
            "spike_pj": 0.9,
            "mem_read_pj": 12.0,
            "mem_write_pj": 15.0,
            "static_w": 1.5,
        },
        "raspberry_pi5": {
            "mac_pj": 120.0,
            "spike_pj": 2.1,
            "mem_read_pj": 20.0,
            "mem_write_pj": 25.0,
            "static_w": 2.5,
        },
    }

    def __init__(self, target: str = "jetson_orin_nano"):
        self.target = target
        self.energy_model = self.ENERGY_PER_OP.get(target, self.ENERGY_PER_OP["jetson_orin_nano"])

    def profile(
        self,
        model: nn.Module,
        input_data: Tensor,
        model_name: str = "model",
    ) -> EnergyReport:
        """Profile a model's energy consumption.

        Args:
            model: PyTorch model (spiking or DNN).
            input_data: Example input.
            model_name: Name for the report.

        Returns:
            EnergyReport with detailed breakdown.
        """
        from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire

        model.eval()
        layer_data: Dict[str, dict] = {}
        hooks = []

        # Install profiling hooks
        for name, module in model.named_modules():
            if isinstance(module, (nn.Linear, nn.Conv2d, nn.Conv1d, LeakyIntegrateAndFire)):
                layer_data[name] = {
                    "type": type(module).__name__,
                    "spikes": 0,
                    "macs": 0,
                    "params": sum(p.numel() for p in module.parameters(recurse=False)),
                }

                def make_hook(n):
                    def hook_fn(m, inp, out):
                        if isinstance(m, LeakyIntegrateAndFire):
                            layer_data[n]["spikes"] = int(out.sum().item())
                        elif isinstance(m, nn.Linear):
                            layer_data[n]["macs"] = int(inp[0].shape[-1] * out.shape[-1] * inp[0].shape[0])
                        elif isinstance(m, (nn.Conv2d, nn.Conv1d)):
                            k = m.kernel_size[0] if isinstance(m.kernel_size, tuple) else m.kernel_size
                            k = k * (m.kernel_size[1] if isinstance(m, nn.Conv2d) and isinstance(m.kernel_size, tuple) else k if isinstance(m, nn.Conv2d) else 1)
                            layer_data[n]["macs"] = int(k * m.in_channels * out.numel())
                    return hook_fn

                hooks.append(module.register_forward_hook(make_hook(name)))

        # Reset states and run
        for m in model.modules():
            if hasattr(m, "reset_state"):
                m.reset_state()

        with torch.no_grad():
            import time
            t0 = time.perf_counter()
            model(input_data)
            t1 = time.perf_counter()

        for h in hooks:
            h.remove()

        # Compute energy per layer
        layer_profiles = []
        total_spikes = 0
        total_macs = 0

        for name, data in layer_data.items():
            spikes = data["spikes"]
            macs = data["macs"]
            params = data["params"]

            mem_reads = macs  # Approximate: one read per MAC
            mem_writes = spikes + macs // 10  # Writes less frequent

            energy = (
                spikes * self.energy_model["spike_pj"]
                + macs * self.energy_model["mac_pj"]
                + mem_reads * self.energy_model["mem_read_pj"]
                + mem_writes * self.energy_model["mem_write_pj"]
            )

            total_neurons = max(params, 1)
            layer_profiles.append(LayerProfile(
                name=name,
                layer_type=data["type"],
                spike_events=spikes,
                mac_operations=macs,
                memory_reads=mem_reads,
                memory_writes=mem_writes,
                energy_pj=energy,
                spike_rate=spikes / total_neurons if total_neurons > 0 else 0,
                params=params,
            ))

            total_spikes += spikes
            total_macs += macs

        # Total energy
        spike_energy = total_spikes * self.energy_model["spike_pj"] / 1e9  # mJ
        mac_energy = total_macs * self.energy_model["mac_pj"] / 1e9
        mem_energy = total_macs * self.energy_model["mem_read_pj"] / 1e9
        static_energy = self.energy_model["static_w"] * (t1 - t0) * 1000  # mJ

        total_params = sum(p.numel() for p in model.parameters())

        return EnergyReport(
            model_name=model_name,
            target_hardware=self.target,
            total_energy_mj=spike_energy + mac_energy + mem_energy + static_energy,
            total_spike_events=total_spikes,
            total_mac_operations=total_macs,
            spike_energy_mj=spike_energy,
            mac_energy_mj=mac_energy,
            memory_energy_mj=mem_energy,
            static_energy_mj=static_energy,
            avg_spike_rate=total_spikes / max(total_params, 1),
            layer_profiles=layer_profiles,
        )

    def compare(
        self,
        spike_model: nn.Module,
        dnn_model: nn.Module,
        input_data: Tensor,
    ) -> Dict[str, EnergyReport]:
        """Side-by-side energy comparison: spike vs DNN.

        Args:
            spike_model: Spiking model.
            dnn_model: Standard DNN model.
            input_data: Shared input.

        Returns:
            Dict with 'spike' and 'dnn' EnergyReports, plus ratio.
        """
        spike_report = self.profile(spike_model, input_data, "spike_model")
        dnn_report = self.profile(dnn_model, input_data, "dnn_model")

        # Compute ratio
        if dnn_report.total_energy_mj > 0:
            ratio = spike_report.total_energy_mj / dnn_report.total_energy_mj
        else:
            ratio = 1.0

        spike_report.dnn_equivalent_energy_mj = dnn_report.total_energy_mj
        spike_report.energy_ratio = ratio

        return {
            "spike": spike_report,
            "dnn": dnn_report,
            "energy_ratio": ratio,
            "energy_savings_x": 1.0 / ratio if ratio > 0 else 0,
        }

    def report(self, energy_report: EnergyReport) -> str:
        """Generate human-readable report."""
        lines = [
            f"=== Energy Report: {energy_report.model_name} ===",
            f"Target: {energy_report.target_hardware}",
            f"Total Energy: {energy_report.total_energy_mj:.4f} mJ",
            f"  Spike Events: {energy_report.total_spike_events:,} ({energy_report.spike_energy_mj:.4f} mJ)",
            f"  MAC Ops: {energy_report.total_mac_operations:,} ({energy_report.mac_energy_mj:.4f} mJ)",
            f"  Memory: {energy_report.memory_energy_mj:.4f} mJ",
            f"  Static: {energy_report.static_energy_mj:.4f} mJ",
            f"  Avg Spike Rate: {energy_report.avg_spike_rate:.4f}",
            "",
            "Layer Breakdown:",
        ]

        for lp in energy_report.layer_profiles:
            lines.append(
                f"  {lp.name}: {lp.layer_type} | "
                f"spikes={lp.spike_events:,} macs={lp.mac_operations:,} | "
                f"{lp.energy_pj/1e9:.4f} mJ | rate={lp.spike_rate:.4f}"
            )

        if energy_report.energy_ratio is not None:
            lines.append(f"\nEnergy Ratio (spike/dnn): {energy_report.energy_ratio:.4f}")
            lines.append(f"Energy Savings: {1/energy_report.energy_ratio:.1f}x")

        return "\n".join(lines)

    def to_csv(self, energy_report: EnergyReport, path: str) -> None:
        """Export layer-by-layer profile to CSV for paper figures."""
        with open(path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "layer_name", "layer_type", "spike_events", "mac_operations",
                "memory_reads", "memory_writes", "energy_pj", "spike_rate", "params",
            ])
            for lp in energy_report.layer_profiles:
                writer.writerow([
                    lp.name, lp.layer_type, lp.spike_events, lp.mac_operations,
                    lp.memory_reads, lp.memory_writes, lp.energy_pj, lp.spike_rate,
                    lp.params,
                ])

    def to_json(self, energy_report: EnergyReport, path: str) -> None:
        """Export full report as JSON."""
        data = {
            "model_name": energy_report.model_name,
            "target_hardware": energy_report.target_hardware,
            "total_energy_mj": energy_report.total_energy_mj,
            "total_spike_events": energy_report.total_spike_events,
            "total_mac_operations": energy_report.total_mac_operations,
            "spike_energy_mj": energy_report.spike_energy_mj,
            "mac_energy_mj": energy_report.mac_energy_mj,
            "memory_energy_mj": energy_report.memory_energy_mj,
            "avg_spike_rate": energy_report.avg_spike_rate,
            "energy_ratio": energy_report.energy_ratio,
        }
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
