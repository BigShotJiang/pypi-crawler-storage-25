"""
Fleet management for distributed NeuromorphicRT edge devices.

mDNS discovery, OTA model deployment, health monitoring,
and centralized metrics aggregation.
"""

from __future__ import annotations

import json
import time
import threading
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class EdgeDevice:
    """Registered edge device."""
    device_id: str
    hostname: str
    ip_address: str
    port: int = 8080
    device_type: str = "unknown"  # jetson, pi5, generic
    model_version: str = ""
    last_heartbeat: float = 0
    status: str = "unknown"
    metrics: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_alive(self) -> bool:
        return time.time() - self.last_heartbeat < 60

    @property
    def url(self) -> str:
        return f"http://{self.ip_address}:{self.port}"


class FleetManager:
    """Manages a fleet of NeuromorphicRT edge devices.

    Features:
    - mDNS/Zeroconf discovery of devices on local network
    - Health monitoring with heartbeat tracking
    - OTA model deployment to all or selected devices
    - Centralized metrics aggregation
    - Rolling update strategy (canary → staged → full)
    """

    SERVICE_TYPE = "_neuromorphic-rt._tcp.local."

    def __init__(self):
        self.devices: Dict[str, EdgeDevice] = {}
        self._lock = threading.Lock()
        self._discovery_thread: Optional[threading.Thread] = None
        self._monitor_thread: Optional[threading.Thread] = None
        self._running = False

    def register_device(self, device: EdgeDevice) -> None:
        """Manually register an edge device."""
        with self._lock:
            self.devices[device.device_id] = device

    def discover(self, timeout: float = 5.0) -> List[EdgeDevice]:
        """Discover devices via mDNS/Zeroconf.

        Requires: pip install zeroconf
        """
        discovered = []
        try:
            from zeroconf import ServiceBrowser, Zeroconf, ServiceStateChange

            zc = Zeroconf()
            found = []

            class Listener:
                def add_service(self, zc, type_, name):
                    info = zc.get_service_info(type_, name)
                    if info:
                        found.append(info)

                def remove_service(self, zc, type_, name):
                    pass

                def update_service(self, zc, type_, name):
                    pass

            browser = ServiceBrowser(zc, self.SERVICE_TYPE, Listener())
            time.sleep(timeout)
            zc.close()

            for info in found:
                ip = info.parsed_addresses()[0] if info.parsed_addresses() else None
                if ip:
                    dev = EdgeDevice(
                        device_id=info.name,
                        hostname=info.server,
                        ip_address=ip,
                        port=info.port,
                        last_heartbeat=time.time(),
                    )
                    self.register_device(dev)
                    discovered.append(dev)

        except ImportError:
            pass  # zeroconf not installed — manual registration only

        return discovered

    def health_check(self, device_id: Optional[str] = None) -> Dict[str, Any]:
        """Check health of one or all devices."""
        import urllib.request

        targets = (
            [self.devices[device_id]] if device_id and device_id in self.devices
            else list(self.devices.values())
        )

        results = {}
        for dev in targets:
            try:
                url = f"{dev.url}/health"
                req = urllib.request.Request(url, method="GET")
                with urllib.request.urlopen(req, timeout=5) as resp:
                    data = json.loads(resp.read())
                    dev.status = "healthy"
                    dev.last_heartbeat = time.time()
                    dev.metrics = data
                    results[dev.device_id] = {"status": "healthy", "data": data}
            except Exception as e:
                dev.status = "unreachable"
                results[dev.device_id] = {"status": "unreachable", "error": str(e)}

        return results

    def deploy_model(
        self,
        model_path: str,
        device_ids: Optional[List[str]] = None,
        strategy: str = "rolling",
    ) -> Dict[str, str]:
        """Deploy model to fleet devices.

        Args:
            model_path: Path to model file.
            device_ids: Specific devices (None = all).
            strategy: 'rolling' (one at a time), 'canary' (1 first, then all), 'parallel'.

        Returns:
            Dict of device_id → deployment status.
        """
        import urllib.request

        targets = (
            [self.devices[d] for d in device_ids if d in self.devices]
            if device_ids else list(self.devices.values())
        )

        if not targets:
            return {"error": "no devices found"}

        model_data = Path(model_path).read_bytes()
        results = {}

        deploy_order = targets
        if strategy == "canary" and len(targets) > 1:
            # Deploy to first device, check health, then rest
            deploy_order = [targets[0]]

        for dev in deploy_order:
            try:
                url = f"{dev.url}/model/update"
                req = urllib.request.Request(
                    url, data=model_data, method="POST",
                    headers={"Content-Type": "application/octet-stream"},
                )
                with urllib.request.urlopen(req, timeout=30) as resp:
                    results[dev.device_id] = "deployed"
            except Exception as e:
                results[dev.device_id] = f"failed: {e}"

        # Canary: if first succeeded, deploy to rest
        if strategy == "canary" and len(targets) > 1:
            first_id = targets[0].device_id
            if results.get(first_id) == "deployed":
                for dev in targets[1:]:
                    try:
                        url = f"{dev.url}/model/update"
                        req = urllib.request.Request(
                            url, data=model_data, method="POST",
                            headers={"Content-Type": "application/octet-stream"},
                        )
                        with urllib.request.urlopen(req, timeout=30) as resp:
                            results[dev.device_id] = "deployed"
                    except Exception as e:
                        results[dev.device_id] = f"failed: {e}"

        return results

    def aggregate_metrics(self) -> Dict[str, Any]:
        """Aggregate metrics across all healthy devices."""
        alive = [d for d in self.devices.values() if d.is_alive]
        if not alive:
            return {"devices": 0}

        total_inferences = sum(d.metrics.get("total_inferences", 0) for d in alive)
        total_energy = sum(d.metrics.get("total_energy_mj", 0) for d in alive)
        avg_latency = (
            sum(d.metrics.get("avg_latency_ms", 0) for d in alive) / len(alive)
        )

        return {
            "devices": len(alive),
            "total_devices": len(self.devices),
            "total_inferences": total_inferences,
            "total_energy_mj": round(total_energy, 4),
            "avg_latency_ms": round(avg_latency, 2),
            "device_types": {d.device_type: 0 for d in alive},
        }

    def list_devices(self) -> List[Dict[str, Any]]:
        """List all registered devices."""
        return [
            {
                "id": d.device_id,
                "hostname": d.hostname,
                "ip": d.ip_address,
                "type": d.device_type,
                "status": d.status,
                "alive": d.is_alive,
                "model_version": d.model_version,
            }
            for d in self.devices.values()
        ]
