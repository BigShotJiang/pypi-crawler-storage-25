"""
Alert and notification system for NeuromorphicRT.

Supports Pushover, Telegram, email (SMTP), and generic webhooks.
Designed for edge deployments where immediate alerts on anomalies,
thermal events, or device failures are critical.
"""

from __future__ import annotations

import json
import time
import smtplib
from email.mime.text import MIMEText
from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class Severity(Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"


@dataclass
class Alert:
    """Alert event."""
    title: str
    message: str
    severity: Severity = Severity.INFO
    source: str = ""
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    acknowledged: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "message": self.message,
            "severity": self.severity.value,
            "source": self.source,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


@dataclass
class NotificationChannel:
    """Notification channel configuration."""
    name: str
    channel_type: str  # pushover, telegram, email, webhook
    config: Dict[str, str] = field(default_factory=dict)
    min_severity: Severity = Severity.WARNING
    enabled: bool = True


class NotificationManager:
    """Manages alert routing and notification delivery.

    Features:
    - Multiple channels (Pushover, Telegram, email, webhook)
    - Severity-based routing
    - Rate limiting (no spam)
    - Alert history with acknowledgment
    - Cooldown periods per alert type
    """

    def __init__(self, config_path: Optional[str] = None):
        self.channels: List[NotificationChannel] = []
        self.history: List[Alert] = []
        self._cooldowns: Dict[str, float] = {}
        self._cooldown_seconds: float = 300  # 5 min between same alerts
        self._handlers: Dict[str, Callable] = {
            "pushover": self._send_pushover,
            "telegram": self._send_telegram,
            "email": self._send_email,
            "webhook": self._send_webhook,
        }

        if config_path and Path(config_path).exists():
            self._load_config(config_path)

    def add_channel(self, channel: NotificationChannel) -> None:
        """Register a notification channel."""
        self.channels.append(channel)

    def send(self, alert: Alert) -> Dict[str, str]:
        """Send alert to all matching channels.

        Returns dict of channel_name → status.
        """
        # Rate limit check
        cooldown_key = f"{alert.source}:{alert.title}"
        now = time.time()
        if cooldown_key in self._cooldowns:
            if now - self._cooldowns[cooldown_key] < self._cooldown_seconds:
                return {"_rate_limited": "true"}
        self._cooldowns[cooldown_key] = now

        self.history.append(alert)

        results = {}
        for channel in self.channels:
            if not channel.enabled:
                continue
            if alert.severity.value < channel.min_severity.value:
                continue

            handler = self._handlers.get(channel.channel_type)
            if handler:
                try:
                    handler(alert, channel.config)
                    results[channel.name] = "sent"
                except Exception as e:
                    results[channel.name] = f"failed: {e}"

        return results

    def _send_pushover(self, alert: Alert, config: Dict[str, str]) -> None:
        """Send via Pushover API."""
        import urllib.request
        import urllib.parse

        priority = {
            Severity.INFO: -1,
            Severity.WARNING: 0,
            Severity.CRITICAL: 1,
            Severity.EMERGENCY: 2,
        }.get(alert.severity, 0)

        data = urllib.parse.urlencode({
            "token": config["api_token"],
            "user": config["user_key"],
            "title": f"[NeuromorphicRT] {alert.title}",
            "message": alert.message,
            "priority": priority,
        }).encode()

        req = urllib.request.Request(
            "https://api.pushover.net/1/messages.json",
            data=data, method="POST",
        )
        urllib.request.urlopen(req, timeout=10)

    def _send_telegram(self, alert: Alert, config: Dict[str, str]) -> None:
        """Send via Telegram Bot API."""
        import urllib.request
        import urllib.parse

        severity_emoji = {
            Severity.INFO: "ℹ️",
            Severity.WARNING: "⚠️",
            Severity.CRITICAL: "🔴",
            Severity.EMERGENCY: "🚨",
        }

        text = (
            f"{severity_emoji.get(alert.severity, '')} *{alert.title}*\n"
            f"{alert.message}\n"
            f"Source: {alert.source}"
        )

        url = f"https://api.telegram.org/bot{config['bot_token']}/sendMessage"
        data = urllib.parse.urlencode({
            "chat_id": config["chat_id"],
            "text": text,
            "parse_mode": "Markdown",
        }).encode()

        req = urllib.request.Request(url, data=data, method="POST")
        urllib.request.urlopen(req, timeout=10)

    def _send_email(self, alert: Alert, config: Dict[str, str]) -> None:
        """Send via SMTP."""
        msg = MIMEText(f"{alert.message}\n\nSource: {alert.source}\nSeverity: {alert.severity.value}")
        msg["Subject"] = f"[NeuromorphicRT] [{alert.severity.value.upper()}] {alert.title}"
        msg["From"] = config["from_address"]
        msg["To"] = config["to_address"]

        with smtplib.SMTP(config.get("smtp_host", "localhost"), int(config.get("smtp_port", "587"))) as server:
            if config.get("smtp_tls", "true") == "true":
                server.starttls()
            if "smtp_user" in config:
                server.login(config["smtp_user"], config["smtp_password"])
            server.send_message(msg)

    def _send_webhook(self, alert: Alert, config: Dict[str, str]) -> None:
        """Send via generic webhook (JSON POST)."""
        import urllib.request

        data = json.dumps(alert.to_dict()).encode()
        req = urllib.request.Request(
            config["url"], data=data, method="POST",
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=10)

    def _load_config(self, path: str) -> None:
        """Load channels from config file."""
        data = json.loads(Path(path).read_text())
        for ch in data.get("channels", []):
            self.add_channel(NotificationChannel(
                name=ch["name"],
                channel_type=ch["type"],
                config=ch.get("config", {}),
                min_severity=Severity(ch.get("min_severity", "warning")),
                enabled=ch.get("enabled", True),
            ))

    def get_recent_alerts(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent alert history."""
        return [a.to_dict() for a in self.history[-limit:]]
