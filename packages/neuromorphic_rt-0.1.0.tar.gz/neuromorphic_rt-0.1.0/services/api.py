"""
NeuromorphicRT REST API — FastAPI-based platform endpoint.

Serves real-time sensor data, inference results, energy metrics,
and fleet management for the edge AI platform.
"""

from __future__ import annotations

import time
import json
from typing import Dict, Optional, List
from pathlib import Path

try:
    from fastapi import FastAPI, WebSocket, HTTPException
    from fastapi.responses import HTMLResponse, JSONResponse
    from fastapi.middleware.cors import CORSMiddleware
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False


def create_app(
    fusion_agent=None,
    engine=None,
    api_key: Optional[str] = None,
) -> "FastAPI":
    """Create the NeuromorphicRT API application.

    Args:
        fusion_agent: SensorFusionAgent instance.
        engine: NeuromorphicEngine instance.
        api_key: Optional API key for authentication.

    Returns:
        FastAPI application.
    """
    if not HAS_FASTAPI:
        raise ImportError("FastAPI required: pip install fastapi uvicorn")

    app = FastAPI(
        title="NeuromorphicRT",
        description="Spiking Neural Network Runtime for Edge AI",
        version="0.1.0",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # State
    inference_history: List[Dict] = []
    alerts: List[Dict] = []
    start_time = time.time()

    @app.get("/health")
    async def health():
        return {
            "status": "healthy",
            "uptime_s": time.time() - start_time,
            "version": "0.1.0",
        }

    @app.get("/sensors")
    async def list_sensors():
        if fusion_agent is None:
            return {"sensors": []}
        return {
            "sensors": [
                {
                    "name": name,
                    "modality": sensor.modality,
                    "active": sensor.is_active,
                    "sample_rate": sensor.config.sample_rate,
                    "encoding": sensor.config.encoding,
                }
                for name, sensor in fusion_agent.sensors.items()
            ]
        }

    @app.get("/inference/latest")
    async def latest_inference():
        if not inference_history:
            return {"result": None}
        return {"result": inference_history[-1]}

    @app.get("/inference/history")
    async def inference_history_endpoint(limit: int = 100):
        return {"results": inference_history[-limit:]}

    @app.get("/metrics")
    async def metrics():
        stats = fusion_agent.get_stats() if fusion_agent else {}
        return {
            "uptime_s": time.time() - start_time,
            "inference_count": stats.get("inference_count", 0),
            "avg_latency_ms": stats.get("avg_latency_ms", 0),
            "active_sensors": stats.get("active_sensors", {}),
        }

    @app.get("/metrics/power")
    async def power_metrics():
        if engine:
            return {
                "target": engine.target,
                "energy_model": engine.ENERGY_MODELS.get(engine.target, {}),
            }
        return {"target": "unknown", "energy_model": {}}

    @app.get("/alerts")
    async def get_alerts():
        return {"alerts": [a for a in alerts if not a.get("acknowledged")]}

    @app.post("/alerts/acknowledge/{alert_id}")
    async def acknowledge_alert(alert_id: int):
        if 0 <= alert_id < len(alerts):
            alerts[alert_id]["acknowledged"] = True
            return {"status": "acknowledged"}
        raise HTTPException(404, "Alert not found")

    @app.get("/dashboard", response_class=HTMLResponse)
    async def dashboard():
        return _generate_dashboard_html()

    @app.websocket("/ws/stream")
    async def websocket_stream(websocket: WebSocket):
        await websocket.accept()
        try:
            while True:
                if inference_history:
                    await websocket.send_json(inference_history[-1])
                await asyncio.sleep(0.5)
        except Exception:
            pass

    # Callback to store results
    if fusion_agent:
        def _store_result(result):
            entry = {
                "timestamp": result.timestamp,
                "anomaly_score": result.anomaly_score,
                "active_sensors": result.active_sensors,
                "latency_ms": result.latency_ms,
                "spike_rates": result.spike_rates,
            }
            inference_history.append(entry)
            if len(inference_history) > 10000:
                inference_history.pop(0)

            # Generate alerts
            if result.anomaly_score > 0.8:
                alerts.append({
                    "id": len(alerts),
                    "timestamp": result.timestamp,
                    "severity": "CRITICAL",
                    "message": f"High anomaly score: {result.anomaly_score:.3f}",
                    "acknowledged": False,
                })

        fusion_agent.run_async(callback=_store_result)

    return app


def _generate_dashboard_html() -> str:
    """Generate single-file HTML dashboard."""
    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NeuromorphicRT Dashboard</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'JetBrains Mono', 'Fira Code', monospace; background: #0a0a0f; color: #e0e0e0; }
.header { background: linear-gradient(135deg, #1a1a2e, #16213e); padding: 20px 30px; border-bottom: 1px solid #2a2a4a; }
.header h1 { font-size: 1.5em; color: #00d4ff; }
.header p { font-size: 0.8em; color: #888; margin-top: 4px; }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px; padding: 20px; }
.card { background: #12121f; border: 1px solid #2a2a4a; border-radius: 8px; padding: 20px; }
.card h2 { font-size: 1em; color: #00d4ff; margin-bottom: 12px; }
.metric { display: flex; justify-content: space-between; margin: 8px 0; }
.metric .label { color: #888; }
.metric .value { color: #00ff88; font-weight: bold; }
.status { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 8px; }
.status.active { background: #00ff88; }
.status.inactive { background: #ff4444; }
.alert { background: #2a1515; border: 1px solid #ff4444; border-radius: 4px; padding: 10px; margin: 8px 0; }
.alert.critical { border-color: #ff0000; }
#energy-chart { width: 100%; height: 200px; }
</style>
</head>
<body>
<div class="header">
  <h1>NeuromorphicRT</h1>
  <p>Spiking Neural Network Runtime for Edge AI</p>
</div>
<div class="grid">
  <div class="card">
    <h2>System Status</h2>
    <div id="status-content">Loading...</div>
  </div>
  <div class="card">
    <h2>Active Sensors</h2>
    <div id="sensors-content">Loading...</div>
  </div>
  <div class="card">
    <h2>Inference Metrics</h2>
    <div id="metrics-content">Loading...</div>
  </div>
  <div class="card">
    <h2>Anomaly Alerts</h2>
    <div id="alerts-content">No alerts</div>
  </div>
  <div class="card" style="grid-column: span 2;">
    <h2>Energy Comparison (Spike vs DNN)</h2>
    <canvas id="energy-chart"></canvas>
  </div>
</div>
<script>
async function update() {
  try {
    const [health, sensors, metrics, alerts] = await Promise.all([
      fetch('/health').then(r => r.json()),
      fetch('/sensors').then(r => r.json()),
      fetch('/metrics').then(r => r.json()),
      fetch('/alerts').then(r => r.json()),
    ]);
    document.getElementById('status-content').innerHTML =
      '<div class="metric"><span class="label">Status</span><span class="value">' + health.status + '</span></div>' +
      '<div class="metric"><span class="label">Uptime</span><span class="value">' + Math.round(health.uptime_s) + 's</span></div>';
    let shtml = '';
    (sensors.sensors || []).forEach(s => {
      shtml += '<div class="metric"><span class="label"><span class="status ' + (s.active ? 'active' : 'inactive') + '"></span>' + s.name + ' (' + s.modality + ')</span><span class="value">' + s.sample_rate + ' Hz</span></div>';
    });
    document.getElementById('sensors-content').innerHTML = shtml || 'No sensors';
    document.getElementById('metrics-content').innerHTML =
      '<div class="metric"><span class="label">Inferences</span><span class="value">' + (metrics.inference_count || 0) + '</span></div>' +
      '<div class="metric"><span class="label">Avg Latency</span><span class="value">' + (metrics.avg_latency_ms || 0).toFixed(2) + ' ms</span></div>';
    let ahtml = '';
    (alerts.alerts || []).forEach(a => {
      ahtml += '<div class="alert ' + a.severity.toLowerCase() + '">[' + a.severity + '] ' + a.message + '</div>';
    });
    document.getElementById('alerts-content').innerHTML = ahtml || 'No alerts';
  } catch(e) { console.error(e); }
}
setInterval(update, 2000);
update();
</script>
</body>
</html>"""


import asyncio
