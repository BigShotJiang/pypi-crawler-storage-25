"""NeuromorphicRT platform: REST API, fleet management, dashboard."""
