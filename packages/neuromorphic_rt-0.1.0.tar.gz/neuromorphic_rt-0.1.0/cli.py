"""
NeuromorphicRT CLI — command-line interface for the entire platform.

Usage:
    neuromorphic-rt benchmark --tasks all --device cuda
    neuromorphic-rt convert --input resnet18.pth --output spike_resnet.pth
    neuromorphic-rt deploy --model spike_resnet.pth --target jetson --power-mode 7W
    neuromorphic-rt serve --port 8080 --model spike_resnet.pth
    neuromorphic-rt sensors --list
    neuromorphic-rt profile --model spike_resnet.pth --energy
    neuromorphic-rt demo --task vision --live
"""

from __future__ import annotations

import sys
import argparse
import torch


def main():
    parser = argparse.ArgumentParser(
        prog="neuromorphic-rt",
        description="NeuromorphicRT — Spiking Neural Network Runtime for Edge AI",
    )
    subparsers = parser.add_subparsers(dest="command")

    # benchmark
    bench = subparsers.add_parser("benchmark", help="Run energy benchmark suite")
    bench.add_argument("--tasks", nargs="+", default=["all"])
    bench.add_argument("--device", default="cuda")
    bench.add_argument("--num-trials", type=int, default=100)
    bench.add_argument("--output", default="benchmark_results.json")

    # convert
    conv = subparsers.add_parser("convert", help="Convert DNN to spiking model")
    conv.add_argument("--input", required=True, help="Input model path")
    conv.add_argument("--output", required=True, help="Output model path")
    conv.add_argument("--timesteps", type=int, default=4)
    conv.add_argument("--beta", type=float, default=0.9)

    # deploy
    dep = subparsers.add_parser("deploy", help="Deploy model to edge device")
    dep.add_argument("--model", required=True)
    dep.add_argument("--target", default="jetson", choices=["jetson", "pi", "generic"])
    dep.add_argument("--power-mode", default="7W")

    # serve
    srv = subparsers.add_parser("serve", help="Start API server")
    srv.add_argument("--port", type=int, default=8080)
    srv.add_argument("--model", default=None)
    srv.add_argument("--host", default="0.0.0.0")

    # sensors
    sens = subparsers.add_parser("sensors", help="List/manage sensors")
    sens.add_argument("--list", action="store_true")

    # profile
    prof = subparsers.add_parser("profile", help="Profile model energy")
    prof.add_argument("--model", required=True)
    prof.add_argument("--energy", action="store_true")
    prof.add_argument("--target", default="jetson_orin_nano")

    # demo
    demo = subparsers.add_parser("demo", help="Run live demo")
    demo.add_argument("--task", default="vision", choices=["vision", "audio", "fusion"])
    demo.add_argument("--live", action="store_true")

    # train
    tr = subparsers.add_parser("train", help="Train a spiking model")
    tr.add_argument("--model", default="spike-net7")
    tr.add_argument("--dataset", default="cifar10")
    tr.add_argument("--epochs", type=int, default=100)
    tr.add_argument("--lr", type=float, default=1e-3)
    tr.add_argument("--device", default="cuda")

    args = parser.parse_args()

    if args.command == "benchmark":
        _cmd_benchmark(args)
    elif args.command == "convert":
        _cmd_convert(args)
    elif args.command == "deploy":
        _cmd_deploy(args)
    elif args.command == "serve":
        _cmd_serve(args)
    elif args.command == "sensors":
        _cmd_sensors(args)
    elif args.command == "profile":
        _cmd_profile(args)
    elif args.command == "demo":
        _cmd_demo(args)
    elif args.command == "train":
        _cmd_train(args)
    else:
        parser.print_help()


def _cmd_benchmark(args):
    from neuromorphic_rt.benchmark.harness import BenchmarkHarness, ALL_TASKS

    tasks = ALL_TASKS if "all" in args.tasks else args.tasks
    harness = BenchmarkHarness(device=args.device, num_trials=args.num_trials)

    print("NeuromorphicRT Benchmark Suite")
    print(f"Device: {args.device} | Trials: {args.num_trials}")
    print()

    results = harness.run_all(tasks=tasks)
    print()
    print(results.summary())

    results.to_json(args.output)
    print(f"\nResults saved to {args.output}")


def _cmd_convert(args):
    from neuromorphic_rt.sdk.converter import relu_to_lif, get_conversion_stats

    print(f"Converting {args.input} → {args.output}")
    print(f"Timesteps: {args.timesteps}, Beta: {args.beta}")

    model = torch.load(args.input, weights_only=False)
    if isinstance(model, dict):
        model = model.get("model", model)

    converted = relu_to_lif(model, timesteps=args.timesteps, beta=args.beta)
    stats = get_conversion_stats(converted)

    torch.save({"model": converted}, args.output)
    print(f"Converted: {stats.replaced_activations} activations → LIF neurons")
    print(f"Estimated energy ratio: {stats.energy_ratio_estimate:.4f}")


def _cmd_deploy(args):
    from neuromorphic_rt.deploy.jetson import JetsonDeployer

    deployer = JetsonDeployer()
    model = torch.load(args.model, weights_only=False)
    if isinstance(model, dict):
        model = model.get("model", model)

    print(f"Deploying to {args.target} in {args.power_mode} mode")

    example = torch.randn(1, 3, 224, 224)
    out_path = deployer.prepare_model(model, example, f"optimized_{args.model}")
    print(f"Optimized model: {out_path}")

    service_path = deployer.create_service(out_path, power_mode=args.power_mode)
    print(f"Service file: {service_path}")
    print(f"Install: sudo cp {service_path} /etc/systemd/system/ && sudo systemctl enable neuromorphic-rt")


def _cmd_serve(args):
    from neuromorphic_rt.platform.api import create_app

    print(f"Starting NeuromorphicRT API on {args.host}:{args.port}")
    app = create_app()

    import uvicorn
    uvicorn.run(app, host=args.host, port=args.port)


def _cmd_sensors(args):
    print("Available sensor types:")
    print("  camera   - USB/CSI/RTSP camera (vision)")
    print("  audio    - Microphone (audio)")
    print("  imu      - MPU6050/BNO055/GY-85 (motion)")
    print("  env      - BME280/BH1750 (environment)")
    print("  network  - UDM Pro / pcap (network traffic)")


def _cmd_profile(args):
    from neuromorphic_rt.sdk.profiler import EnergyProfiler

    profiler = EnergyProfiler(target=args.target)
    model = torch.load(args.model, weights_only=False)
    if isinstance(model, dict):
        model = model.get("model", model)

    example = torch.randn(1, 3, 32, 32)
    report = profiler.profile(model, example, "profiled_model")
    print(profiler.report(report))


def _cmd_demo(args):
    from neuromorphic_rt.models.vision import SpikeNet7
    from neuromorphic_rt.sdk.engine import NeuromorphicEngine

    print(f"Running {args.task} demo...")

    if args.task == "vision":
        model = SpikeNet7(num_classes=10)
        engine = NeuromorphicEngine()
        engine.from_pytorch(model)

        # Synthetic demo
        for i in range(5):
            x = torch.randn(1, 3, 32, 32)
            result = engine.infer(x)
            pred = result.output.argmax(dim=-1).item()
            print(f"  Frame {i+1}: class={pred}, energy={result.estimated_energy_mj:.4f}mJ, "
                  f"spikes={result.spike_count}, latency={result.latency_ms:.2f}ms")


def _cmd_train(args):
    from neuromorphic_rt.models import get_model
    from neuromorphic_rt.training.trainer import SpikeTrainer

    print(f"Training {args.model} on {args.dataset}")
    model = get_model(args.model)

    # Create synthetic data for demo
    train_data = torch.utils.data.TensorDataset(
        torch.randn(1000, 3, 32, 32),
        torch.randint(0, 10, (1000,)),
    )
    val_data = torch.utils.data.TensorDataset(
        torch.randn(200, 3, 32, 32),
        torch.randint(0, 10, (200,)),
    )
    train_loader = torch.utils.data.DataLoader(train_data, batch_size=32, shuffle=True)
    val_loader = torch.utils.data.DataLoader(val_data, batch_size=32)

    trainer = SpikeTrainer()
    result = trainer.train(model, train_loader, val_loader, epochs=args.epochs, lr=args.lr, device=args.device)

    print(f"\nTraining complete!")
    print(f"  Best val accuracy: {result.best_val_accuracy:.4f}")
    print(f"  Avg spike rate: {result.avg_spike_rate:.4f}")
    print(f"  Time: {result.training_time_s:.1f}s")


if __name__ == "__main__":
    main()
