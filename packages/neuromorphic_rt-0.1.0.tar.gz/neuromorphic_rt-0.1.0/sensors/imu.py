"""IMU/accelerometer sensor: MPU6050, BNO055, GY-85."""

from __future__ import annotations

import torch
from torch import Tensor
from typing import Optional

from neuromorphic_rt.sensors.base import SensorStream, SensorConfig


class IMUStream(SensorStream):
    """IMU sensor: accelerometer + gyroscope.

    Reads 6-DOF data (accel_xyz + gyro_xyz) via I2C.
    Delta encoding: only spikes on significant motion changes.
    """

    def __init__(
        self,
        i2c_bus: int = 1,
        address: int = 0x68,  # MPU6050 default
        config: Optional[SensorConfig] = None,
    ):
        cfg = config or SensorConfig(sample_rate=100, encoding="delta", encoding_threshold=0.05)
        super().__init__(cfg)
        self.i2c_bus = i2c_bus
        self.address = address
        self._bus = None
        self._calibration_offset = torch.zeros(6)

    @property
    def modality(self) -> str:
        return "imu"

    def start(self) -> None:
        try:
            import smbus2
            self._bus = smbus2.SMBus(self.i2c_bus)
            # Wake up MPU6050
            self._bus.write_byte_data(self.address, 0x6B, 0)
            self._active = True
        except (ImportError, Exception):
            self._active = True  # Synthetic fallback

    def read(self) -> Tensor:
        """Read 6-DOF IMU data.

        Returns:
            (6,) tensor: [accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z]
        """
        if self._bus is not None:
            try:
                raw = self._bus.read_i2c_block_data(self.address, 0x3B, 14)
                accel_x = self._to_signed(raw[0], raw[1]) / 16384.0
                accel_y = self._to_signed(raw[2], raw[3]) / 16384.0
                accel_z = self._to_signed(raw[4], raw[5]) / 16384.0
                gyro_x = self._to_signed(raw[8], raw[9]) / 131.0
                gyro_y = self._to_signed(raw[10], raw[11]) / 131.0
                gyro_z = self._to_signed(raw[12], raw[13]) / 131.0
                data = torch.tensor([accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z])
                return data - self._calibration_offset
            except Exception:
                pass

        # Synthetic: slight gravity on z-axis + noise
        return torch.tensor([0.0, 0.0, 1.0, 0.0, 0.0, 0.0]) + torch.randn(6) * 0.01

    @staticmethod
    def _to_signed(high: int, low: int) -> float:
        val = (high << 8) | low
        return val - 65536 if val >= 32768 else val

    def calibrate(self, num_samples: int = 100) -> None:
        """Calibrate bias by averaging stationary readings."""
        samples = []
        for _ in range(num_samples):
            samples.append(self.read())
        self._calibration_offset = torch.stack(samples).mean(0)
        # Keep gravity on z
        self._calibration_offset[2] -= 1.0

    def stop(self) -> None:
        if self._bus is not None:
            self._bus.close()
        self._active = False
