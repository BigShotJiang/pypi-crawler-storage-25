"""Audio sensor: microphone input with mel-spectrogram preprocessing."""

from __future__ import annotations

import torch
from torch import Tensor
from typing import Optional

from neuromorphic_rt.sensors.base import SensorStream, SensorConfig


class AudioStream(SensorStream):
    """Audio sensor with VAD-gated spike encoding.

    Only processes audio when sound is detected (VAD gate),
    saving power during silence.
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        chunk_size: int = 512,
        mel_bins: int = 40,
        config: Optional[SensorConfig] = None,
    ):
        cfg = config or SensorConfig(sample_rate=sample_rate, encoding="delta")
        super().__init__(cfg)
        self.sr = sample_rate
        self.chunk_size = chunk_size
        self.mel_bins = mel_bins
        self.stream = None
        self._vad_threshold = 0.01

    @property
    def modality(self) -> str:
        return "audio"

    def start(self) -> None:
        try:
            import sounddevice as sd
            self.stream = sd.InputStream(
                samplerate=self.sr, channels=1, blocksize=self.chunk_size
            )
            self.stream.start()
            self._active = True
        except (ImportError, Exception):
            self._active = True  # Synthetic fallback

    def read(self) -> Tensor:
        """Read an audio chunk.

        Returns:
            (chunk_size,) float tensor of audio samples.
        """
        if self.stream is not None:
            data, overflowed = self.stream.read(self.chunk_size)
            return torch.from_numpy(data).squeeze().float()

        # Synthetic
        return torch.randn(self.chunk_size) * 0.01

    def to_mel_spectrogram(self, audio: Tensor) -> Tensor:
        """Convert audio to mel-spectrogram.

        Args:
            audio: (num_samples,) audio waveform.

        Returns:
            (num_frames, mel_bins) mel-spectrogram.
        """
        try:
            import torchaudio.transforms as T
            mel = T.MelSpectrogram(
                sample_rate=self.sr, n_mels=self.mel_bins,
                n_fft=512, hop_length=160,
            )
            spec = mel(audio.unsqueeze(0))
            return spec.squeeze(0).T  # (frames, mel_bins)
        except ImportError:
            # Manual approximate mel spectrogram
            n_fft = 512
            hop = 160
            frames = (audio.shape[0] - n_fft) // hop + 1
            if frames <= 0:
                return torch.zeros(1, self.mel_bins)

            specs = []
            for i in range(frames):
                chunk = audio[i * hop: i * hop + n_fft]
                fft = torch.fft.rfft(chunk * torch.hann_window(n_fft, device=audio.device))
                power = fft.abs().pow(2)
                # Crude mel binning
                bin_size = power.shape[0] // self.mel_bins
                mel_frame = torch.zeros(self.mel_bins)
                for j in range(self.mel_bins):
                    mel_frame[j] = power[j * bin_size: (j + 1) * bin_size].mean()
                specs.append(mel_frame)

            return torch.stack(specs)

    def stop(self) -> None:
        if self.stream is not None:
            self.stream.stop()
            self.stream.close()
        self._active = False
