"""
Base sensor interface and registry.

All sensor streams produce data that can be converted to spike trains
for processing by the UniversalSensorAgent.
"""

from __future__ import annotations

import torch
from torch import Tensor
from abc import ABC, abstractmethod
from typing import Dict, Optional, Type
from dataclasses import dataclass


@dataclass
class SensorConfig:
    """Configuration for a sensor stream."""
    sample_rate: int = 30  # Hz
    enabled: bool = True
    encoding: str = "delta"  # rate, temporal, delta
    encoding_threshold: float = 0.1
    encoding_timesteps: int = 4


class SensorStream(ABC):
    """Abstract base class for all sensor streams.

    Subclasses implement read() for their specific hardware,
    and optionally override to_spikes() for custom encoding.
    """

    def __init__(self, config: Optional[SensorConfig] = None):
        self.config = config or SensorConfig()
        self._active = False

    @property
    @abstractmethod
    def modality(self) -> str:
        """Sensor modality: 'vision', 'audio', 'imu', 'scalar', 'network'."""
        ...

    @property
    def is_active(self) -> bool:
        return self._active

    @abstractmethod
    def read(self) -> Tensor:
        """Read raw sensor data.

        Returns:
            Tensor of sensor readings.
        """
        ...

    def to_spikes(self, data: Tensor) -> Tensor:
        """Convert raw data to spike train.

        Args:
            data: Raw sensor tensor.

        Returns:
            Binary spike tensor.
        """
        from neuromorphic_rt.core.encoding import rate_encode, delta_encode, temporal_encode

        if self.config.encoding == "rate":
            # Normalize to [0, 1]
            d_min, d_max = data.min(), data.max()
            if d_max > d_min:
                data = (data - d_min) / (d_max - d_min)
            return rate_encode(data, self.config.encoding_timesteps)

        elif self.config.encoding == "delta":
            if data.dim() < 3:
                data = data.unsqueeze(0).unsqueeze(0)  # Add batch and time dims
            return delta_encode(data, self.config.encoding_threshold)

        elif self.config.encoding == "temporal":
            d_min, d_max = data.min(), data.max()
            if d_max > d_min:
                data = (data - d_min) / (d_max - d_min)
            return temporal_encode(data, self.config.encoding_timesteps)

        else:
            raise ValueError(f"Unknown encoding: {self.config.encoding}")

    def start(self) -> None:
        """Start the sensor stream."""
        self._active = True

    def stop(self) -> None:
        """Stop the sensor stream."""
        self._active = False

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(modality={self.modality}, active={self.is_active})"


class SensorRegistry:
    """Registry for discovering and managing sensor streams."""

    _sensors: Dict[str, SensorStream] = {}

    @classmethod
    def register(cls, name: str, sensor: SensorStream) -> None:
        cls._sensors[name] = sensor

    @classmethod
    def get(cls, name: str) -> Optional[SensorStream]:
        return cls._sensors.get(name)

    @classmethod
    def list_sensors(cls) -> Dict[str, str]:
        return {name: s.modality for name, s in cls._sensors.items()}

    @classmethod
    def get_active(cls) -> Dict[str, SensorStream]:
        return {n: s for n, s in cls._sensors.items() if s.is_active}

    @classmethod
    def clear(cls) -> None:
        cls._sensors.clear()
