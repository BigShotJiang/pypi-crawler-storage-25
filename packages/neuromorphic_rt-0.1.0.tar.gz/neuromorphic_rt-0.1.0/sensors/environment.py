"""Environmental sensors: temperature, humidity, pressure, light, IR."""

from __future__ import annotations

import torch
from torch import Tensor
from typing import Dict, Optional

from neuromorphic_rt.sensors.base import SensorStream, SensorConfig


class EnvironmentStream(SensorStream):
    """Environmental sensor array from SunFounder IoT kit.

    Reads temperature (DHT22/BME280), humidity, pressure, light (BH1750), IR.
    Rate-encoded: each scalar maps to a spike probability.
    """

    def __init__(
        self,
        poll_interval: float = 1.0,
        config: Optional[SensorConfig] = None,
    ):
        cfg = config or SensorConfig(sample_rate=1, encoding="rate", encoding_timesteps=4)
        super().__init__(cfg)
        self.poll_interval = poll_interval
        self._drivers: Dict[str, object] = {}

    @property
    def modality(self) -> str:
        return "scalar"

    def start(self) -> None:
        # Try to initialize hardware drivers
        self._try_init_bme280()
        self._try_init_bh1750()
        self._active = True

    def read(self) -> Tensor:
        """Read all environmental sensors.

        Returns:
            (8,) tensor: [temp_c, humidity_pct, pressure_hpa, light_lux,
                          ir_value, uv_index, dew_point, heat_index]
        """
        values = {
            "temperature": 22.0,
            "humidity": 45.0,
            "pressure": 1013.25,
            "light": 500.0,
            "ir": 0.0,
            "uv": 0.0,
            "dew_point": 10.0,
            "heat_index": 22.0,
        }

        # Read from real hardware if available
        if "bme280" in self._drivers:
            try:
                bme = self._drivers["bme280"]
                values["temperature"] = bme.temperature
                values["humidity"] = bme.humidity
                values["pressure"] = bme.pressure
            except Exception:
                pass

        if "bh1750" in self._drivers:
            try:
                values["light"] = self._drivers["bh1750"].luminance
            except Exception:
                pass

        # Compute derived values
        t = values["temperature"]
        h = values["humidity"]
        # Magnus formula for dew point
        import math
        gamma = math.log(h / 100) + (17.67 * t) / (243.5 + t) if h > 0 else 0
        values["dew_point"] = 243.5 * gamma / (17.67 - gamma) if 17.67 != gamma else t

        # Normalize to [0, 1] ranges for spike encoding
        normalized = torch.tensor([
            (values["temperature"] + 40) / 80,  # -40 to 40°C
            values["humidity"] / 100,
            (values["pressure"] - 900) / 200,  # 900-1100 hPa
            min(values["light"] / 10000, 1.0),
            min(values["ir"] / 1000, 1.0),
            min(values["uv"] / 11, 1.0),
            (values["dew_point"] + 20) / 60,
            (values["heat_index"] + 10) / 60,
        ]).clamp(0, 1)

        return normalized

    def read_raw(self) -> Dict[str, float]:
        """Read raw sensor values with units."""
        data = self.read()
        return {
            "temperature_c": data[0].item() * 80 - 40,
            "humidity_pct": data[1].item() * 100,
            "pressure_hpa": data[2].item() * 200 + 900,
            "light_lux": data[3].item() * 10000,
            "ir_raw": data[4].item() * 1000,
            "uv_index": data[5].item() * 11,
            "dew_point_c": data[6].item() * 60 - 20,
            "heat_index_c": data[7].item() * 60 - 10,
        }

    def _try_init_bme280(self) -> None:
        try:
            import board
            import adafruit_bme280.advanced as adafruit_bme280
            i2c = board.I2C()
            self._drivers["bme280"] = adafruit_bme280.Adafruit_BME280_I2C(i2c)
        except (ImportError, Exception):
            pass

    def _try_init_bh1750(self) -> None:
        try:
            import board
            import adafruit_bh1750
            i2c = board.I2C()
            self._drivers["bh1750"] = adafruit_bh1750.BH1750(i2c)
        except (ImportError, Exception):
            pass

    def stop(self) -> None:
        self._drivers.clear()
        self._active = False
