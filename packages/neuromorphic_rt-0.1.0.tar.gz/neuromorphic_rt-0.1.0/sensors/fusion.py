"""Multi-modal sensor fusion orchestrator: the runtime brain."""

from __future__ import annotations

import time
import threading
import torch
from torch import Tensor
from typing import Callable, Dict, List, Optional
from dataclasses import dataclass

from neuromorphic_rt.sensors.base import SensorStream


@dataclass
class FusionResult:
    """Result from one fusion inference cycle."""
    timestamp: float
    anomaly_score: float
    classification: Dict[str, float]
    predicted_state: Tensor
    active_sensors: List[str]
    spike_rates: Dict[str, float]
    latency_ms: float


class SensorFusionAgent:
    """Orchestrates multi-modal sensor fusion with event-driven inference.

    Manages N active SensorStreams, aligns spike trains temporally,
    and feeds unified input to UniversalSensorAgent model.

    Event-driven: only runs inference when ANY sensor spikes,
    achieving massive power savings vs. continuous polling.

    Usage:
        agent = SensorFusionAgent(model)
        agent.add_sensor("cam", CameraStream())
        agent.add_sensor("mic", AudioStream())
        agent.run(callback=handle_result)
    """

    def __init__(
        self,
        model=None,
        inference_interval: float = 0.1,
        device: str = "cpu",
    ):
        self.model = model
        self.inference_interval = inference_interval
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.sensors: Dict[str, SensorStream] = {}
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._inference_count = 0
        self._total_latency = 0.0

    def add_sensor(self, name: str, sensor: SensorStream) -> None:
        """Add a sensor stream."""
        self.sensors[name] = sensor

    def remove_sensor(self, name: str) -> None:
        """Remove a sensor stream."""
        if name in self.sensors:
            self.sensors[name].stop()
            del self.sensors[name]

    def run(
        self,
        callback: Optional[Callable[[FusionResult], None]] = None,
        max_iterations: Optional[int] = None,
    ) -> None:
        """Main fusion loop.

        Args:
            callback: Called with each FusionResult.
            max_iterations: Stop after N iterations (None = run forever).
        """
        self._running = True

        # Start all sensors
        for sensor in self.sensors.values():
            sensor.start()

        iteration = 0
        while self._running:
            if max_iterations and iteration >= max_iterations:
                break

            t0 = time.perf_counter()

            # Read from all active sensors
            sensor_data = {}
            for name, sensor in self.sensors.items():
                if sensor.is_active:
                    try:
                        raw = sensor.read()
                        spikes = sensor.to_spikes(raw)
                        sensor_data[name] = {
                            "raw": raw,
                            "spikes": spikes,
                            "modality": sensor.modality,
                        }
                    except Exception:
                        continue

            if not sensor_data:
                time.sleep(self.inference_interval)
                continue

            # Check if any sensor spiked (event-driven gate)
            any_spike = any(
                d["spikes"].abs().sum() > 0 for d in sensor_data.values()
            )

            if not any_spike and self.model is not None:
                time.sleep(self.inference_interval)
                continue

            # Run model inference
            result = self._infer(sensor_data)

            latency_ms = (time.perf_counter() - t0) * 1000
            self._inference_count += 1
            self._total_latency += latency_ms

            fusion_result = FusionResult(
                timestamp=time.time(),
                anomaly_score=result.get("anomaly_score", 0.0),
                classification=result.get("classification", {}),
                predicted_state=result.get("predicted_next", torch.zeros(128)),
                active_sensors=list(sensor_data.keys()),
                spike_rates=result.get("spike_rates", {}),
                latency_ms=latency_ms,
            )

            if callback:
                callback(fusion_result)

            iteration += 1
            time.sleep(max(0, self.inference_interval - latency_ms / 1000))

    def run_async(
        self,
        callback: Optional[Callable[[FusionResult], None]] = None,
    ) -> None:
        """Run fusion loop in background thread."""
        self._thread = threading.Thread(
            target=self.run, args=(callback,), daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        """Stop the fusion loop and all sensors."""
        self._running = False
        for sensor in self.sensors.values():
            sensor.stop()
        if self._thread:
            self._thread.join(timeout=5)

    def _infer(self, sensor_data: Dict) -> Dict:
        """Run model inference on fused sensor data."""
        if self.model is None:
            # No model: return spike statistics
            spike_rates = {}
            for name, data in sensor_data.items():
                spike_rates[name] = data["spikes"].abs().mean().item()
            return {
                "anomaly_score": max(spike_rates.values()) if spike_rates else 0,
                "spike_rates": spike_rates,
            }

        # Build model inputs grouped by modality
        model_inputs = {}
        for name, data in sensor_data.items():
            modality = data["modality"]
            raw = data["raw"]
            if raw.dim() == 0:
                continue
            # Add batch dimension if needed
            if raw.dim() < 2:
                raw = raw.unsqueeze(0)
            elif raw.dim() >= 2 and raw.shape[0] != 1:
                raw = raw.unsqueeze(0)
            model_inputs[modality] = raw.to(self.device)

        # Run model
        with torch.no_grad():
            for m in self.model.modules():
                if hasattr(m, "reset_state"):
                    m.reset_state()
            output = self.model(model_inputs)

        # Extract results
        result = {"spike_rates": {}}
        if isinstance(output, dict):
            if "anomaly_score" in output:
                result["anomaly_score"] = output["anomaly_score"].mean().item()
            if "classification" in output:
                logits = output["classification"][0]
                probs = torch.softmax(logits, dim=-1)
                result["classification"] = {
                    f"class_{i}": probs[i].item() for i in range(len(probs))
                }
            if "predicted_next" in output:
                result["predicted_next"] = output["predicted_next"][0].cpu()

        return result

    def get_stats(self) -> Dict:
        """Get fusion agent statistics."""
        return {
            "active_sensors": {n: s.is_active for n, s in self.sensors.items()},
            "inference_count": self._inference_count,
            "avg_latency_ms": self._total_latency / max(self._inference_count, 1),
            "running": self._running,
        }
