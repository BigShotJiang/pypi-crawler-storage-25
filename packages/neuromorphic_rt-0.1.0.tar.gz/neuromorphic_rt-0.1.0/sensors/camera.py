"""Camera sensor: USB, CSI, RTSP, or file-based video input."""

from __future__ import annotations

import torch
from torch import Tensor
from typing import Optional, Tuple

from neuromorphic_rt.sensors.base import SensorStream, SensorConfig


class CameraStream(SensorStream):
    """Camera sensor with event-camera-style delta encoding.

    Supports USB cameras, CSI (Jetson), RTSP streams, and image files.
    Delta encoding mimics an event camera: only generates spikes when
    pixels CHANGE, making it extremely power-efficient for static scenes.
    """

    def __init__(
        self,
        source: int | str = 0,
        resolution: Tuple[int, int] = (224, 224),
        fps: int = 30,
        config: Optional[SensorConfig] = None,
    ):
        cfg = config or SensorConfig(sample_rate=fps, encoding="delta")
        super().__init__(cfg)
        self.source = source
        self.resolution = resolution
        self.cap = None
        self._prev_frame: Optional[Tensor] = None

    @property
    def modality(self) -> str:
        return "vision"

    def start(self) -> None:
        try:
            import cv2
            if isinstance(self.source, int) or self.source.startswith("rtsp"):
                self.cap = cv2.VideoCapture(self.source)
                if self.cap.isOpened():
                    self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.resolution[0])
                    self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.resolution[1])
            self._active = True
        except ImportError:
            self._active = True  # Fallback to synthetic

    def read(self) -> Tensor:
        """Read a frame from the camera.

        Returns:
            (3, H, W) float tensor normalized to [0, 1].
        """
        if self.cap is not None and self.cap.isOpened():
            import cv2
            ret, frame = self.cap.read()
            if ret:
                frame = cv2.resize(frame, self.resolution)
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                tensor = torch.from_numpy(frame).float() / 255.0
                return tensor.permute(2, 0, 1)  # (3, H, W)

        # Synthetic fallback
        return torch.rand(3, *self.resolution)

    def to_spikes(self, data: Tensor) -> Tensor:
        """Delta encode: spike on pixel change (event-camera style).

        Args:
            data: (3, H, W) current frame.

        Returns:
            (3, H, W) spike tensor: +1/-1 for change, 0 for static.
        """
        if self._prev_frame is None:
            self._prev_frame = data.clone()
            return torch.zeros_like(data)

        diff = data - self._prev_frame
        threshold = self.config.encoding_threshold

        spikes = torch.zeros_like(data)
        spikes[diff > threshold] = 1.0
        spikes[diff < -threshold] = -1.0

        self._prev_frame = data.clone()
        return spikes

    def stop(self) -> None:
        if self.cap is not None:
            self.cap.release()
        self._active = False
        self._prev_frame = None
