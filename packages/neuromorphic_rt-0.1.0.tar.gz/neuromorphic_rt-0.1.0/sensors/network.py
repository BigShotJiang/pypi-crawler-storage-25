"""Network traffic sensor: UDM Pro API or pcap capture."""

from __future__ import annotations

import torch
from torch import Tensor
from typing import Dict, Optional

from neuromorphic_rt.sensors.base import SensorStream, SensorConfig


class NetworkStream(SensorStream):
    """Network traffic sensor via Ubiquiti UDM Pro API or packet capture.

    Extracts features: packet_rate, byte_rate, unique_ips, protocol_dist,
    dns_query_rate, syn_rate, etc. Delta-encoded for anomaly detection.
    """

    def __init__(
        self,
        udm_host: Optional[str] = None,
        udm_username: Optional[str] = None,
        udm_password: Optional[str] = None,
        capture_interface: Optional[str] = None,
        window_size: float = 1.0,
        config: Optional[SensorConfig] = None,
    ):
        cfg = config or SensorConfig(sample_rate=1, encoding="delta", encoding_threshold=0.1)
        super().__init__(cfg)
        self.udm_host = udm_host
        self.udm_username = udm_username
        self.udm_password = udm_password
        self.capture_interface = capture_interface
        self.window_size = window_size
        self._session = None
        self._prev_stats: Optional[Dict] = None

    @property
    def modality(self) -> str:
        return "network"

    def start(self) -> None:
        if self.udm_host:
            self._try_connect_udm()
        self._active = True

    def read(self) -> Tensor:
        """Read network traffic features.

        Returns:
            (16,) tensor of normalized network metrics.
        """
        stats = self._get_stats()

        features = torch.tensor([
            stats.get("packets_per_sec", 0) / 10000,
            stats.get("bytes_per_sec", 0) / 1e8,
            stats.get("unique_src_ips", 0) / 1000,
            stats.get("unique_dst_ips", 0) / 1000,
            stats.get("tcp_ratio", 0.5),
            stats.get("udp_ratio", 0.3),
            stats.get("icmp_ratio", 0.02),
            stats.get("other_ratio", 0.18),
            stats.get("dns_queries_per_sec", 0) / 100,
            stats.get("syn_rate", 0) / 1000,
            stats.get("rst_rate", 0) / 100,
            stats.get("avg_packet_size", 500) / 1500,
            stats.get("connection_rate", 0) / 1000,
            stats.get("bandwidth_utilization", 0),
            stats.get("retransmit_rate", 0),
            stats.get("latency_ms", 1) / 100,
        ]).clamp(0, 1)

        return features

    def _get_stats(self) -> Dict[str, float]:
        """Get network statistics from UDM Pro or synthetic."""
        if self._session and self.udm_host:
            try:
                return self._query_udm_stats()
            except Exception:
                pass

        # Synthetic baseline with small noise
        return {
            "packets_per_sec": 1500 + torch.randn(1).item() * 100,
            "bytes_per_sec": 2e6 + torch.randn(1).item() * 1e5,
            "unique_src_ips": 50 + torch.randn(1).item() * 5,
            "unique_dst_ips": 200 + torch.randn(1).item() * 20,
            "tcp_ratio": 0.65,
            "udp_ratio": 0.25,
            "icmp_ratio": 0.02,
            "other_ratio": 0.08,
            "dns_queries_per_sec": 10 + torch.randn(1).item() * 2,
            "syn_rate": 50 + torch.randn(1).item() * 10,
            "rst_rate": 2 + torch.randn(1).item() * 0.5,
            "avg_packet_size": 450 + torch.randn(1).item() * 50,
            "connection_rate": 100 + torch.randn(1).item() * 20,
            "bandwidth_utilization": 0.15 + torch.randn(1).item() * 0.02,
            "retransmit_rate": 0.01 + torch.randn(1).item() * 0.002,
            "latency_ms": 5 + torch.randn(1).item() * 1,
        }

    def _try_connect_udm(self) -> None:
        """Connect to UDM Pro REST API."""
        try:
            import requests
            self._session = requests.Session()
            self._session.verify = False
            self._session.post(
                f"https://{self.udm_host}/api/auth/login",
                json={"username": self.udm_username, "password": self.udm_password},
            )
        except Exception:
            self._session = None

    def _query_udm_stats(self) -> Dict[str, float]:
        """Query UDM Pro for network statistics."""
        resp = self._session.get(
            f"https://{self.udm_host}/proxy/network/api/s/default/stat/health"
        )
        data = resp.json().get("data", [{}])[0]
        return {
            "packets_per_sec": data.get("num_sta", 0) * 10,
            "bytes_per_sec": data.get("rx_bytes-r", 0) + data.get("tx_bytes-r", 0),
            "bandwidth_utilization": 0.1,
        }

    def stop(self) -> None:
        if self._session:
            self._session.close()
        self._active = False
