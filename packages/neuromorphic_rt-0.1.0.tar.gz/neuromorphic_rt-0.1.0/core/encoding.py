"""
Spike encoding schemes: convert continuous sensor data to binary spike trains.

Ported from MOLE src/sense/snn_encoder.py with additions for temporal and
learned encoding schemes from Neurovision.

Each encoder maps a float tensor (batch, features) → spike tensor (batch, T, features)
where T is the number of simulation timesteps.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor


def rate_encode(tensor: Tensor, num_steps: int, gain: float = 1.0) -> Tensor:
    """Rate coding: spike probability proportional to input magnitude.

    Higher input values → higher firing rate → more spikes across timesteps.
    P(spike at t) = clamp(gain * |x|, 0, 1)

    Args:
        tensor: (batch, *features) input in [0, 1] range.
        num_steps: Number of simulation timesteps T.
        gain: Scaling factor for spike probability. Default 1.0.

    Returns:
        Binary spike tensor (batch, T, *features).
    """
    probs = (tensor.abs() * gain).clamp(0.0, 1.0)
    # Expand time dimension and sample Bernoulli
    probs = probs.unsqueeze(1).expand(-1, num_steps, *[-1] * (tensor.dim() - 1))
    return torch.bernoulli(probs)


def temporal_encode(tensor: Tensor, num_steps: int, normalize: bool = True) -> Tensor:
    """Temporal coding: time-to-first-spike encoding.

    Higher input values fire EARLIER (lower latency). Each neuron fires
    exactly once. This is more energy-efficient than rate coding.

    spike_time = round((1 - x) * (T - 1))  →  high x → early spike

    Args:
        tensor: (batch, *features) input in [0, 1] range.
        num_steps: Number of timesteps T.
        normalize: If True, normalize input to [0, 1]. Default True.

    Returns:
        Binary spike tensor (batch, T, *features) with exactly one spike per neuron.
    """
    if normalize:
        t_min = tensor.min()
        t_max = tensor.max()
        if t_max > t_min:
            tensor = (tensor - t_min) / (t_max - t_min)

    # Compute spike times: higher value → earlier spike (lower index)
    spike_times = ((1.0 - tensor.clamp(0, 1)) * (num_steps - 1)).round().long()

    # Create one-hot spike train
    shape = tensor.shape
    spikes = torch.zeros(shape[0], num_steps, *shape[1:], device=tensor.device)

    # Scatter spikes at computed times
    time_idx = spike_times.unsqueeze(1)  # (batch, 1, *features)
    spikes.scatter_(1, time_idx, 1.0)

    return spikes


def delta_encode(tensor: Tensor, threshold: float = 0.1) -> Tensor:
    """Delta coding: spike on change exceeding threshold (event-driven).

    Mimics event cameras / dynamic vision sensors. Only generates spikes
    when the input CHANGES significantly — zero power for static inputs.

    S[t] = 1 if |x[t] - x[t-1]| > threshold, else 0

    Args:
        tensor: (batch, T, *features) time series input.
        threshold: Change threshold for spike generation. Default 0.1.

    Returns:
        Binary spike tensor, same shape as input.
    """
    if tensor.dim() < 3:
        raise ValueError(f"delta_encode expects (batch, T, *features), got shape {tensor.shape}")

    # Compute temporal differences
    diff = torch.zeros_like(tensor)
    diff[:, 1:] = tensor[:, 1:] - tensor[:, :-1]

    # Positive and negative spikes
    pos_spikes = (diff > threshold).float()
    neg_spikes = (diff < -threshold).float()

    return pos_spikes - neg_spikes  # {-1, 0, 1} encoding


def latency_encode(
    tensor: Tensor, num_steps: int, tau: float = 5.0, normalize: bool = True
) -> Tensor:
    """Latency coding: exponential decay timing.

    spike_time = τ · ln(x / (x - threshold))

    Neurons with higher input spike earlier, with exponential
    relationship between input magnitude and spike latency.

    Args:
        tensor: (batch, *features) input.
        num_steps: Number of timesteps T.
        tau: Time constant controlling spread. Default 5.0.
        normalize: Normalize to [0, 1]. Default True.

    Returns:
        Binary spike tensor (batch, T, *features).
    """
    if normalize:
        t_min = tensor.min()
        t_max = tensor.max()
        if t_max > t_min:
            tensor = (tensor - t_min) / (t_max - t_min)

    # Clamp to avoid log(0)
    x = tensor.clamp(1e-6, 1.0 - 1e-6)

    # Exponential latency: higher x → lower spike time
    spike_times = (tau * torch.log(x / (x - 0.5 * x))).clamp(0, num_steps - 1)
    spike_times = spike_times.round().long()

    shape = tensor.shape
    spikes = torch.zeros(shape[0], num_steps, *shape[1:], device=tensor.device)
    time_idx = spike_times.unsqueeze(1)
    spikes.scatter_(1, time_idx, 1.0)

    return spikes


class LearnedEncoder(nn.Module):
    """Learnable spike encoder: a small network that learns optimal encoding.

    Architecture: Linear → LIF neuron → produces spike train.
    The linear weights learn to map input features to optimal currents
    for the LIF neurons, and the LIF threshold/beta can also be learned.

    Args:
        in_features: Input feature dimension.
        num_steps: Number of timesteps to generate.
        hidden_features: Hidden dimension (default = in_features).
    """

    def __init__(
        self,
        in_features: int,
        num_steps: int,
        hidden_features: Optional[int] = None,
    ):
        super().__init__()
        from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire

        hidden = hidden_features or in_features
        self.num_steps = num_steps
        self.encoder = nn.Linear(in_features, hidden)
        self.lif = LeakyIntegrateAndFire(
            beta=0.9, threshold=1.0, learnable_beta=True, learnable_threshold=True
        )

    def forward(self, x: Tensor) -> Tensor:
        """Encode input tensor to spike train.

        Args:
            x: (batch, in_features) input tensor.

        Returns:
            (batch, T, hidden_features) binary spike tensor.
        """
        self.lif.reset_state()
        current = self.encoder(x)  # (batch, hidden)

        spikes = []
        for _ in range(self.num_steps):
            s = self.lif(current)
            spikes.append(s)

        return torch.stack(spikes, dim=1)  # (batch, T, hidden)


# Keep Optional import available for LearnedEncoder
from typing import Optional
