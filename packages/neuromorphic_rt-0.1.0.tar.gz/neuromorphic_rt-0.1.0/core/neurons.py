"""
Spiking neuron models with surrogate gradient support.

Ported from Neurovision R framework (nn_spiking_neuron, nn_surrogate_spike)
to production PyTorch/CUDA for Jetson Orin Nano deployment.

Mathematical foundations:
- LIF: dV/dt = -(V - V_rest)/τ_m + I_syn/C_m
- Surrogate gradient: σ'(x) ≈ 1/(1 + k|x|)² (fast sigmoid)
- Heaviside step with straight-through estimator for backprop
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor
from typing import Optional, Tuple


class SurrogateSpike(torch.autograd.Function):
    """Heaviside step with surrogate gradient for backpropagation.

    Forward: Θ(x) = 1 if x ≥ 0, else 0
    Backward: σ'(x) ≈ 1 / (1 + k|x|)²  (fast sigmoid surrogate)

    Three gradient variants available:
    - fast_sigmoid (default): 1/(1+k|x|)², smooth, well-behaved
    - arctan: (1/π) · 1/(1+(πkx)²), slightly wider gradient support
    - superspike: 1/(1+k|x|)², identical to fast_sigmoid but with k=25
    """

    @staticmethod
    def forward(ctx, membrane: Tensor, threshold: float, k: float = 25.0) -> Tensor:
        ctx.save_for_backward(membrane)
        ctx.threshold = threshold
        ctx.k = k
        return (membrane >= threshold).float()

    @staticmethod
    def backward(ctx, grad_output: Tensor) -> Tuple[Tensor, None, None]:
        (membrane,) = ctx.saved_tensors
        centered = membrane - ctx.threshold
        grad = 1.0 / (1.0 + ctx.k * centered.abs()).pow(2)
        return grad_output * grad, None, None


surrogate_spike = SurrogateSpike.apply


class LeakyIntegrateAndFire(nn.Module):
    """Leaky Integrate-and-Fire (LIF) spiking neuron.

    Membrane dynamics:
        V[t] = β · V[t-1] + (1-β) · I[t]
        S[t] = Θ(V[t] - V_th)
        V[t] = V[t] · (1 - S[t])  # reset after spike

    Where β = exp(-dt/τ_m) is the membrane decay factor.

    Args:
        beta: Membrane decay factor (0-1). Higher = slower leak. Default 0.9.
        threshold: Spike threshold voltage. Default 1.0.
        reset_mechanism: 'zero' (hard reset) or 'subtract' (soft reset). Default 'subtract'.
        surrogate_k: Surrogate gradient sharpness. Default 25.0.
        learnable_beta: If True, beta is a learnable parameter. Default False.
        learnable_threshold: If True, threshold is learnable. Default False.
    """

    def __init__(
        self,
        beta: float = 0.9,
        threshold: float = 1.0,
        reset_mechanism: str = "subtract",
        surrogate_k: float = 25.0,
        learnable_beta: bool = False,
        learnable_threshold: bool = False,
    ):
        super().__init__()
        if learnable_beta:
            self.beta = nn.Parameter(torch.tensor(beta))
        else:
            self.register_buffer("beta", torch.tensor(beta))

        if learnable_threshold:
            self.threshold = nn.Parameter(torch.tensor(threshold))
        else:
            self.register_buffer("threshold", torch.tensor(threshold))

        self.reset_mechanism = reset_mechanism
        self.surrogate_k = surrogate_k
        self.membrane: Optional[Tensor] = None

    def forward(self, input_current: Tensor) -> Tensor:
        """Process input current, return binary spike tensor.

        Args:
            input_current: (batch, *features) input current at this timestep.

        Returns:
            Binary spike tensor, same shape as input.
        """
        if self.membrane is None:
            self.membrane = torch.zeros_like(input_current)

        # Membrane dynamics: leaky integration
        self.membrane = self.beta * self.membrane + (1.0 - self.beta) * input_current

        # Spike generation with surrogate gradient
        spikes = surrogate_spike(self.membrane, self.threshold.item(), self.surrogate_k)

        # Reset mechanism
        if self.reset_mechanism == "zero":
            self.membrane = self.membrane * (1.0 - spikes)
        elif self.reset_mechanism == "subtract":
            self.membrane = self.membrane - spikes * self.threshold
        else:
            raise ValueError(f"Unknown reset mechanism: {self.reset_mechanism}")

        return spikes

    def reset_state(self) -> None:
        """Reset membrane potential to zero."""
        self.membrane = None

    def detach_state(self) -> None:
        """Detach membrane from computation graph (for TBPTT)."""
        if self.membrane is not None:
            self.membrane = self.membrane.detach()

    def extra_repr(self) -> str:
        return (
            f"beta={self.beta.item():.3f}, threshold={self.threshold.item():.3f}, "
            f"reset={self.reset_mechanism}, k={self.surrogate_k}"
        )


class AdaptiveExponentialIF(nn.Module):
    """Adaptive Exponential Integrate-and-Fire (AdEx) neuron.

    Adds an adaptation current w that increases after each spike,
    producing rich firing patterns (bursting, adaptation, irregular).

    Dynamics:
        V[t] = β_v · V[t-1] + I[t] - w[t-1]
        w[t] = β_w · w[t-1] + a · (V[t] - V_rest)
        S[t] = Θ(V[t] - V_th)
        w[t] += b · S[t]  (adaptation increment on spike)

    Args:
        beta_v: Membrane decay. Default 0.9.
        beta_w: Adaptation decay (slower than membrane). Default 0.95.
        a: Subthreshold adaptation coupling. Default 0.01.
        b: Spike-triggered adaptation increment. Default 0.1.
        threshold: Spike threshold. Default 1.0.
        v_rest: Resting potential. Default 0.0.
    """

    def __init__(
        self,
        beta_v: float = 0.9,
        beta_w: float = 0.95,
        a: float = 0.01,
        b: float = 0.1,
        threshold: float = 1.0,
        v_rest: float = 0.0,
        surrogate_k: float = 25.0,
    ):
        super().__init__()
        self.register_buffer("beta_v", torch.tensor(beta_v))
        self.register_buffer("beta_w", torch.tensor(beta_w))
        self.register_buffer("a", torch.tensor(a))
        self.register_buffer("b", torch.tensor(b))
        self.register_buffer("threshold", torch.tensor(threshold))
        self.register_buffer("v_rest", torch.tensor(v_rest))
        self.surrogate_k = surrogate_k
        self.membrane: Optional[Tensor] = None
        self.adaptation: Optional[Tensor] = None

    def forward(self, input_current: Tensor) -> Tensor:
        if self.membrane is None:
            self.membrane = torch.zeros_like(input_current)
            self.adaptation = torch.zeros_like(input_current)

        # Membrane dynamics with adaptation current
        self.membrane = (
            self.beta_v * self.membrane
            + input_current
            - self.adaptation
        )

        # Adaptation dynamics
        self.adaptation = (
            self.beta_w * self.adaptation
            + self.a * (self.membrane - self.v_rest)
        )

        # Spike
        spikes = surrogate_spike(self.membrane, self.threshold.item(), self.surrogate_k)

        # Reset and adaptation increment
        self.membrane = self.membrane * (1.0 - spikes)
        self.adaptation = self.adaptation + self.b * spikes

        return spikes

    def reset_state(self) -> None:
        self.membrane = None
        self.adaptation = None

    def detach_state(self) -> None:
        if self.membrane is not None:
            self.membrane = self.membrane.detach()
            self.adaptation = self.adaptation.detach()


class IzhikevichNeuron(nn.Module):
    """Izhikevich neuron model — rich dynamics with only 2 variables.

    Dynamics:
        v[t] = v[t-1] + 0.04v² + 5v + 140 - u + I  (rescaled to unit time)
        u[t] = u[t-1] + a(b·v - u)
        if v ≥ 30: v = c, u = u + d

    Presets (a, b, c, d):
        Regular spiking:  (0.02, 0.2, -65, 8)
        Fast spiking:     (0.1, 0.2, -65, 2)
        Bursting:         (0.02, 0.2, -50, 2)
        Chattering:       (0.02, 0.2, -50, 2)

    Args:
        a, b, c, d: Izhikevich parameters.
        scale: Input scaling factor (Izhikevich uses large voltages). Default 0.02.
    """

    PRESETS = {
        "regular_spiking": (0.02, 0.2, -65.0, 8.0),
        "fast_spiking": (0.1, 0.2, -65.0, 2.0),
        "bursting": (0.02, 0.2, -50.0, 2.0),
        "chattering": (0.02, 0.2, -50.0, 2.0),
    }

    def __init__(
        self,
        a: float = 0.02,
        b: float = 0.2,
        c: float = -65.0,
        d: float = 8.0,
        scale: float = 0.02,
        surrogate_k: float = 25.0,
    ):
        super().__init__()
        self.register_buffer("a", torch.tensor(a))
        self.register_buffer("b", torch.tensor(b))
        self.register_buffer("c", torch.tensor(c))
        self.register_buffer("d", torch.tensor(d))
        self.scale = scale
        self.surrogate_k = surrogate_k
        self.v: Optional[Tensor] = None
        self.u: Optional[Tensor] = None

    @classmethod
    def from_preset(cls, name: str, **kwargs) -> "IzhikevichNeuron":
        a, b, c, d = cls.PRESETS[name]
        return cls(a=a, b=b, c=c, d=d, **kwargs)

    def forward(self, input_current: Tensor) -> Tensor:
        if self.v is None:
            self.v = torch.full_like(input_current, -65.0)
            self.u = torch.full_like(input_current, -65.0 * 0.2)

        I = input_current / self.scale

        # Izhikevich dynamics (two half-steps for numerical stability)
        self.v = self.v + 0.5 * (0.04 * self.v.pow(2) + 5.0 * self.v + 140.0 - self.u + I)
        self.v = self.v + 0.5 * (0.04 * self.v.pow(2) + 5.0 * self.v + 140.0 - self.u + I)
        self.u = self.u + self.a * (self.b * self.v - self.u)

        # Spike detection
        spikes = surrogate_spike(self.v, 30.0, self.surrogate_k)

        # Reset
        self.v = torch.where(spikes.bool(), torch.full_like(self.v, self.c.item()), self.v)
        self.u = self.u + self.d * spikes

        return spikes

    def reset_state(self) -> None:
        self.v = None
        self.u = None

    def detach_state(self) -> None:
        if self.v is not None:
            self.v = self.v.detach()
            self.u = self.u.detach()


class TTFSNeuron(nn.Module):
    """Time-To-First-Spike (TTFS) neuron.

    Each neuron fires AT MOST ONCE. The spike timing encodes the output:
    strong input → early spike (low latency), weak input → late/no spike.

    Energy advantage over LIF rate coding:
    - LIF rate coding: neuron fires ~T×spike_rate times → O(T) spikes per neuron
    - TTFS: neuron fires 0 or 1 time → O(1) spikes per neuron
    - For T=8, this is ~8x fewer spike events = ~8x energy reduction

    The output is the spike TIME (continuous, differentiable via surrogate),
    not a binary spike train. This is decoded as:
        output = (T - spike_time) / T  ∈ [0, 1]
    where earlier spikes → higher output values.

    Membrane dynamics (same as LIF but with one-shot inhibition):
        V[t] = β · V[t-1] + (1-β) · I[t]
        if V[t] ≥ V_th AND not already fired:
            spike_time = t
            inhibit neuron (no more firing)

    Args:
        beta: Membrane decay. Default 0.9.
        threshold: Spike threshold. Default 1.0.
        surrogate_k: Surrogate gradient sharpness. Default 25.0.
        learnable_beta: Make beta learnable. Default False.
        learnable_threshold: Make threshold learnable. Default False.
        max_timesteps: Maximum timesteps (for normalization). Default 8.
    """

    def __init__(
        self,
        beta: float = 0.9,
        threshold: float = 1.0,
        surrogate_k: float = 25.0,
        learnable_beta: bool = False,
        learnable_threshold: bool = False,
        max_timesteps: int = 8,
    ):
        super().__init__()
        if learnable_beta:
            self.beta = nn.Parameter(torch.tensor(beta))
        else:
            self.register_buffer("beta", torch.tensor(beta))

        if learnable_threshold:
            self.threshold = nn.Parameter(torch.tensor(threshold))
        else:
            self.register_buffer("threshold", torch.tensor(threshold))

        self.surrogate_k = surrogate_k
        self.max_timesteps = max_timesteps

        # State
        self.membrane: Optional[Tensor] = None
        self.has_fired: Optional[Tensor] = None    # Boolean mask: which neurons already fired
        self.spike_times: Optional[Tensor] = None   # Recorded spike times (continuous)
        self._current_t: int = 0

    def forward(self, input_current: Tensor) -> Tensor:
        """Process one timestep. Returns binary spike (1 if firing NOW, 0 otherwise).

        After all timesteps, call decode() to get the timing-based output.

        Args:
            input_current: (batch, *features) input current.

        Returns:
            Binary spike tensor (1 = fired this timestep, 0 = didn't).
        """
        if self.membrane is None:
            self.membrane = torch.zeros_like(input_current)
            self.has_fired = torch.zeros_like(input_current, dtype=torch.bool)
            self.spike_times = torch.full_like(input_current, float(self.max_timesteps))

        # Membrane integration (only for neurons that haven't fired)
        active_mask = (~self.has_fired).float()
        self.membrane = (
            self.beta * self.membrane + (1.0 - self.beta) * input_current
        ) * active_mask

        # Spike detection with surrogate gradient
        spikes = surrogate_spike(self.membrane, self.threshold.item(), self.surrogate_k)

        # Only count spikes for neurons that haven't fired yet
        new_spikes = spikes * active_mask

        # Record spike times for newly firing neurons
        newly_fired = new_spikes.bool()
        self.spike_times = torch.where(
            newly_fired,
            torch.full_like(self.spike_times, float(self._current_t)),
            self.spike_times,
        )
        self.has_fired = self.has_fired | newly_fired

        # Inhibit: zero membrane for fired neurons
        self.membrane = self.membrane * active_mask

        self._current_t += 1
        return new_spikes

    def decode(self) -> Tensor:
        """Decode spike times to continuous output.

        Returns:
            (batch, *features) output in [0, 1].
            Earlier spike → higher value. No spike → 0.
        """
        if self.spike_times is None:
            raise RuntimeError("No timesteps processed yet. Call forward() first.")

        # Normalize: earlier spike = higher output
        # Neurons that never fired have spike_time = max_timesteps → output = 0
        output = (self.max_timesteps - self.spike_times) / self.max_timesteps
        return output.clamp(0.0, 1.0)

    def reset_state(self) -> None:
        self.membrane = None
        self.has_fired = None
        self.spike_times = None
        self._current_t = 0

    def detach_state(self) -> None:
        if self.membrane is not None:
            self.membrane = self.membrane.detach()
            self.spike_times = self.spike_times.detach()

    @property
    def total_spikes(self) -> int:
        """Count total spikes fired (for energy estimation)."""
        if self.has_fired is None:
            return 0
        return int(self.has_fired.sum().item())

    def extra_repr(self) -> str:
        return (
            f"beta={self.beta.item():.3f}, threshold={self.threshold.item():.3f}, "
            f"max_T={self.max_timesteps}, mode=TTFS"
        )
