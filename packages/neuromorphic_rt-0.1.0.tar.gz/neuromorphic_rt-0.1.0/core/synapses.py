"""
Synaptic plasticity rules for online/unsupervised learning.

Implements STDP, homeostatic scaling, and dopamine-modulated plasticity
from the Neuroforge brain simulator, adapted for torch.nn integration.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor
from typing import Optional


class STDP(nn.Module):
    """Spike-Timing Dependent Plasticity.

    Causal (pre before post):   ΔW = A⁺ · exp(-Δt/τ⁺)  [potentiation]
    Acausal (post before pre):  ΔW = -A⁻ · exp(-Δt/τ⁻) [depression]

    Maintains eligibility traces for pre/post spikes and updates weights
    based on temporal correlation.

    Args:
        a_plus: Potentiation amplitude. Default 0.01.
        a_minus: Depression amplitude. Default 0.012 (slightly asymmetric).
        tau_plus: Potentiation time constant (ms). Default 20.0.
        tau_minus: Depression time constant (ms). Default 20.0.
        w_min: Minimum weight. Default 0.0.
        w_max: Maximum weight. Default 1.0.
        dt: Simulation timestep (ms). Default 1.0.
    """

    def __init__(
        self,
        a_plus: float = 0.01,
        a_minus: float = 0.012,
        tau_plus: float = 20.0,
        tau_minus: float = 20.0,
        w_min: float = 0.0,
        w_max: float = 1.0,
        dt: float = 1.0,
    ):
        super().__init__()
        self.a_plus = a_plus
        self.a_minus = a_minus
        self.w_min = w_min
        self.w_max = w_max

        # Decay factors per timestep
        self.register_buffer("decay_pre", torch.tensor(torch.exp(torch.tensor(-dt / tau_plus))))
        self.register_buffer("decay_post", torch.tensor(torch.exp(torch.tensor(-dt / tau_minus))))

        # Eligibility traces
        self.trace_pre: Optional[Tensor] = None
        self.trace_post: Optional[Tensor] = None

    def forward(
        self, pre_spikes: Tensor, post_spikes: Tensor, weights: Tensor
    ) -> Tensor:
        """Compute weight update from pre/post spike correlation.

        Args:
            pre_spikes: (batch, pre_neurons) binary.
            post_spikes: (batch, post_neurons) binary.
            weights: (post_neurons, pre_neurons) weight matrix.

        Returns:
            Updated weights (post_neurons, pre_neurons).
        """
        if self.trace_pre is None:
            self.trace_pre = torch.zeros_like(pre_spikes[0])
            self.trace_post = torch.zeros_like(post_spikes[0])

        # Average over batch
        pre_avg = pre_spikes.mean(0)
        post_avg = post_spikes.mean(0)

        # Update eligibility traces
        self.trace_pre = self.decay_pre * self.trace_pre + pre_avg
        self.trace_post = self.decay_post * self.trace_post + post_avg

        # STDP weight updates
        # Post spike → potentiate synapses from recently active pre neurons
        dw_plus = self.a_plus * torch.outer(post_avg, self.trace_pre)
        # Pre spike → depress synapses to recently active post neurons
        dw_minus = self.a_minus * torch.outer(self.trace_post, pre_avg).T

        dw = dw_plus - dw_minus
        weights = (weights + dw).clamp(self.w_min, self.w_max)
        return weights

    def reset_state(self) -> None:
        self.trace_pre = None
        self.trace_post = None


class HomeostaticScaling(nn.Module):
    """Homeostatic synaptic scaling to maintain target firing rate.

    Scales all synaptic weights multiplicatively to push the neuron's
    average firing rate toward a target. Prevents runaway excitation
    or silence.

    scale_factor = target_rate / (current_rate + ε)
    W = W * scale_factor^α

    Args:
        target_rate: Target firing rate (fraction of timesteps). Default 0.05 (5%).
        alpha: Scaling strength. Default 0.001 (slow adjustment).
        window: Number of timesteps to average over. Default 100.
    """

    def __init__(
        self,
        target_rate: float = 0.05,
        alpha: float = 0.001,
        window: int = 100,
    ):
        super().__init__()
        self.target_rate = target_rate
        self.alpha = alpha
        self.window = window
        self.spike_history: list[Tensor] = []

    def forward(self, spikes: Tensor, weights: Tensor) -> Tensor:
        """Update weights based on firing rate deviation.

        Args:
            spikes: (batch, neurons) current spikes.
            weights: Weight matrix to scale.

        Returns:
            Scaled weights.
        """
        # Track firing rate
        self.spike_history.append(spikes.mean(0).detach())
        if len(self.spike_history) > self.window:
            self.spike_history.pop(0)

        if len(self.spike_history) < 10:
            return weights  # Not enough history

        current_rate = torch.stack(self.spike_history).mean(0)
        mean_rate = current_rate.mean()

        if mean_rate < 1e-8:
            scale = 1.0 + self.alpha
        else:
            scale = 1.0 + self.alpha * (self.target_rate - mean_rate.item())

        return weights * scale

    def reset_state(self) -> None:
        self.spike_history.clear()


class DopamineModulatedSTDP(nn.Module):
    """Reward-gated STDP: weight changes only consolidate with dopamine.

    Standard STDP computes eligibility traces, but weight updates are
    gated by a dopamine reward signal. This enables reinforcement learning
    with spiking networks.

    ΔW = dopamine · eligibility_trace

    Args:
        a_plus: Potentiation amplitude. Default 0.01.
        a_minus: Depression amplitude. Default 0.012.
        tau_eligibility: Eligibility trace decay (ms). Default 100.0.
        dt: Timestep (ms). Default 1.0.
    """

    def __init__(
        self,
        a_plus: float = 0.01,
        a_minus: float = 0.012,
        tau_eligibility: float = 100.0,
        dt: float = 1.0,
    ):
        super().__init__()
        self.a_plus = a_plus
        self.a_minus = a_minus
        self.register_buffer(
            "decay_elig", torch.tensor(torch.exp(torch.tensor(-dt / tau_eligibility)))
        )
        self.eligibility: Optional[Tensor] = None
        self.stdp = STDP(a_plus=a_plus, a_minus=a_minus)

    def forward(
        self,
        pre_spikes: Tensor,
        post_spikes: Tensor,
        weights: Tensor,
        dopamine: float = 0.0,
    ) -> Tensor:
        """Update weights gated by dopamine signal.

        Args:
            pre_spikes: (batch, pre) binary.
            post_spikes: (batch, post) binary.
            weights: (post, pre) weight matrix.
            dopamine: Scalar reward signal. Positive = reinforce, negative = weaken.

        Returns:
            Updated weights.
        """
        pre_avg = pre_spikes.mean(0)
        post_avg = post_spikes.mean(0)

        # Compute STDP-style eligibility
        dw = self.a_plus * torch.outer(post_avg, pre_avg) - self.a_minus * torch.outer(
            pre_avg, post_avg
        ).T

        if self.eligibility is None:
            self.eligibility = torch.zeros_like(weights)

        # Eligibility trace decays and accumulates
        self.eligibility = self.decay_elig * self.eligibility + dw

        # Only update weights when dopamine signal arrives
        if abs(dopamine) > 1e-8:
            weights = weights + dopamine * self.eligibility
            weights = weights.clamp(0.0, 1.0)

        return weights

    def reset_state(self) -> None:
        self.eligibility = None
        self.stdp.reset_state()
