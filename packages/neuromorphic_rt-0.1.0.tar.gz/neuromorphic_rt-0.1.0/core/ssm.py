"""
Selective State Space Model with spike-coded I/O.

Ported from Neurovision R/03-modules.R: nn_selective_ssm
and src/selective_scan.cpp (Blelloch parallel scan).

Mamba-style selective SSM: input-dependent state transitions with
O(n log n) parallel scan computation.

Theory:
    x'(t) = A·x(t) + B·u(t)
    y(t)  = C·x(t) + D·u(t)

Discretized (ZOH):
    A_bar = exp(Δ·A)
    B_bar = (A_bar - I)·A⁻¹·B ≈ Δ·B  (first-order)
    x[t]  = A_bar·x[t-1] + B_bar·u[t]
    y[t]  = C·x[t] + D·u[t]
"""

from __future__ import annotations

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from typing import Optional

from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire


def parallel_scan(a: Tensor, b: Tensor) -> Tensor:
    """Blelloch-style parallel associative scan for SSM recurrence.

    Computes x[t] = a[t]*x[t-1] + b[t] for all t in O(n log n).

    Monoid: (a1, b1) * (a2, b2) = (a1*a2, a1*b2 + b1)

    Args:
        a: (batch, length, dim) multiplicative coefficients (A_bar).
        b: (batch, length, dim) additive terms (B_bar * u).

    Returns:
        (batch, length, dim) state sequence x[0..T].
    """
    T = a.shape[1]

    if T <= 32:
        # Sequential fallback for short sequences
        return _sequential_scan(a, b)

    # Pad to power of 2
    log_T = math.ceil(math.log2(T))
    T_pad = 2 ** log_T
    if T_pad > T:
        a = F.pad(a, (0, 0, 0, T_pad - T), value=1.0)
        b = F.pad(b, (0, 0, 0, T_pad - T), value=0.0)

    # Up-sweep (reduce)
    a_levels = [a]
    b_levels = [b]
    for d in range(log_T):
        stride = 2 ** (d + 1)
        half = stride // 2
        a_prev = a_levels[-1]
        b_prev = b_levels[-1]

        a_new = a_prev.clone()
        b_new = b_prev.clone()

        # Compose pairs: (a[i], b[i]) * (a[i+half], b[i+half])
        idx = torch.arange(half - 1, T_pad, stride, device=a.device)
        idx_next = idx + half
        valid = idx_next < T_pad

        if valid.any():
            vi = idx[valid]
            vn = idx_next[valid]
            a_new[:, vn] = a_prev[:, vi] * a_prev[:, vn]
            b_new[:, vn] = a_prev[:, vn] * b_prev[:, vi] + b_prev[:, vn]

        a_levels.append(a_new)
        b_levels.append(b_new)

    # Down-sweep
    a_final = a_levels[-1]
    b_final = b_levels[-1]

    for d in range(log_T - 2, -1, -1):
        stride = 2 ** (d + 1)
        half = stride // 2

        idx = torch.arange(half - 1, T_pad, stride, device=a.device)
        idx_next = idx + half
        valid = idx_next < T_pad

        if valid.any():
            vi = idx[valid]
            vn = idx_next[valid]
            old_b_vi = b_final[:, vi].clone()
            b_final[:, vn] = a_final[:, vn] * old_b_vi + b_final[:, vn]
            a_final[:, vn] = a_final[:, vn] * a_final[:, vi]

    return b_final[:, :T]


def _sequential_scan(a: Tensor, b: Tensor) -> Tensor:
    """Sequential scan fallback for short sequences."""
    B, T, D = a.shape
    x = torch.zeros(B, D, device=a.device, dtype=a.dtype)
    outputs = []
    for t in range(T):
        x = a[:, t] * x + b[:, t]
        outputs.append(x)
    return torch.stack(outputs, dim=1)


class SelectiveSSM(nn.Module):
    """Mamba-style Selective State Space Model.

    Input-dependent discretization: Δ, B, C are functions of the input,
    allowing the model to selectively remember or forget information.

    From Neurovision: nn_selective_ssm (R/03-modules.R)

    Args:
        d_model: Input/output dimension.
        state_dim: SSM state dimension N. Default 16.
        expand_factor: Inner dimension expansion. Default 2.
        dt_min: Minimum Δ (discretization step). Default 0.001.
        dt_max: Maximum Δ. Default 0.1.
    """

    def __init__(
        self,
        d_model: int,
        state_dim: int = 16,
        expand_factor: int = 2,
        dt_min: float = 0.001,
        dt_max: float = 0.1,
    ):
        super().__init__()
        self.d_model = d_model
        self.state_dim = state_dim
        d_inner = d_model * expand_factor

        # Input projection
        self.in_proj = nn.Linear(d_model, d_inner * 2)

        # SSM parameters
        # A is initialized as negative log-spaced (stable dynamics)
        A = torch.arange(1, state_dim + 1, dtype=torch.float32).unsqueeze(0).expand(d_inner, -1)
        self.register_buffer("A_log", -torch.log(A))

        # Input-dependent projections for Δ, B, C
        self.dt_proj = nn.Linear(d_inner, d_inner)
        self.B_proj = nn.Linear(d_inner, state_dim)
        self.C_proj = nn.Linear(d_inner, state_dim)
        self.D = nn.Parameter(torch.ones(d_inner))

        # Output projection
        self.out_proj = nn.Linear(d_inner, d_model)

        # Δ initialization
        dt_init = torch.exp(
            torch.rand(d_inner) * (math.log(dt_max) - math.log(dt_min)) + math.log(dt_min)
        )
        inv_softplus = torch.log(torch.exp(dt_init) - 1.0)
        self.dt_proj.bias = nn.Parameter(inv_softplus)

        # Conv for local context
        self.conv = nn.Conv1d(d_inner, d_inner, kernel_size=4, padding=3, groups=d_inner)

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass.

        Args:
            x: (batch, seq_len, d_model).

        Returns:
            (batch, seq_len, d_model).
        """
        B, L, D = x.shape

        # Input projection and split into two paths
        xz = self.in_proj(x)  # (B, L, 2*d_inner)
        x_proj, z = xz.chunk(2, dim=-1)  # Each: (B, L, d_inner)

        # Local conv
        x_conv = self.conv(x_proj.transpose(1, 2))[:, :, :L].transpose(1, 2)
        x_conv = F.silu(x_conv)

        # Input-dependent SSM parameters
        A = -torch.exp(self.A_log)  # (d_inner, N) — negative for stability
        dt = F.softplus(self.dt_proj(x_conv))  # (B, L, d_inner) — positive Δ
        B_input = self.B_proj(x_conv)  # (B, L, N)
        C_input = self.C_proj(x_conv)  # (B, L, N)

        # Discretize: A_bar = exp(Δ * A), B_bar ≈ Δ * B
        # For parallel scan, we need per-position (a, b) pairs
        dt_A = dt.unsqueeze(-1) * A.unsqueeze(0).unsqueeze(0)  # (B, L, d_inner, N)
        a_bar = torch.exp(dt_A)  # (B, L, d_inner, N)
        b_bar = dt.unsqueeze(-1) * B_input.unsqueeze(2)  # (B, L, d_inner, N)

        # Scale by input
        bu = b_bar * x_conv.unsqueeze(-1)  # (B, L, d_inner, N)

        # Run parallel scan per state dimension
        # Reshape for scan: (B*d_inner, L, N)
        d_inner = x_conv.shape[-1]
        a_scan = a_bar.permute(0, 2, 1, 3).reshape(B * d_inner, L, self.state_dim)
        b_scan = bu.permute(0, 2, 1, 3).reshape(B * d_inner, L, self.state_dim)

        states = parallel_scan(a_scan, b_scan)  # (B*d_inner, L, N)
        states = states.reshape(B, d_inner, L, self.state_dim).permute(0, 2, 1, 3)
        # (B, L, d_inner, N)

        # Output: y = C · x + D · u
        y = torch.einsum("bldn,bln->bld", states, C_input)  # (B, L, d_inner)
        y = y + self.D * x_conv

        # Gate with z
        y = y * F.silu(z)

        return self.out_proj(y)


class SpikeSSM(nn.Module):
    """SSM with spike-coded input and output.

    Wraps SelectiveSSM with spike encoding on input and LIF neurons
    on output, creating a fully event-driven SSM.

    Args:
        d_model: Model dimension.
        state_dim: SSM state dimension. Default 16.
        beta: Output LIF decay. Default 0.9.
        threshold: Output LIF threshold. Default 1.0.
    """

    def __init__(
        self,
        d_model: int,
        state_dim: int = 16,
        beta: float = 0.9,
        threshold: float = 1.0,
    ):
        super().__init__()
        self.ssm = SelectiveSSM(d_model, state_dim=state_dim)
        self.output_lif = LeakyIntegrateAndFire(beta=beta, threshold=threshold)

    def forward(self, x: Tensor) -> Tensor:
        """Process spike input through SSM, output spikes.

        Args:
            x: (batch, seq_len, d_model) — can be binary spikes or continuous.

        Returns:
            (batch, seq_len, d_model) binary spike output.
        """
        y = self.ssm(x)  # Continuous SSM output

        # Apply LIF per timestep
        B, L, D = y.shape
        spikes = []
        for t in range(L):
            s = self.output_lif(y[:, t])
            spikes.append(s)
        return torch.stack(spikes, dim=1)

    def reset_state(self) -> None:
        self.output_lif.reset_state()

    def detach_state(self) -> None:
        self.output_lif.detach_state()
