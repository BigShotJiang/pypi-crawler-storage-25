"""
Temporal Event Neural Network (TENN) layers.

TENN processes spike events using learnable temporal kernels that operate
directly on spike TIMES rather than binning into fixed timesteps. This
preserves sub-timestep temporal precision critical for:
- Event camera data (microsecond resolution)
- Audio onset detection
- Network packet timing analysis

Key insight: standard SNNs bin events into T discrete timesteps, losing
timing information within each bin. TENN treats each spike as a continuous-
time event and applies temporal convolutions over spike timing patterns.

Architecture:
    TENNConv: Temporal convolution with learnable decay kernels
    TENNBlock: TENNConv → BatchNorm → TTFS neuron → residual connection
    TENNAttention: Cross-temporal attention between spike event streams

References:
    - Temporal Event Neural Networks (Haessig et al.)
    - SpikingJelly temporal coding
    - Neurovision R/04-spiking-attention.R (spike timing patterns)
"""

from __future__ import annotations

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from typing import Optional, Tuple, Union

from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire, TTFSNeuron, surrogate_spike


class TemporalKernel(nn.Module):
    """Learnable temporal convolution kernel.

    Parameterized as a sum of exponential decays:
        K(t) = Σ_k a_k · exp(-t / τ_k) · cos(ω_k · t + φ_k)

    This captures both monotone decay (pure exponential) and oscillatory
    patterns (damped cosine) in spike timing. The kernel is causal
    (K(t<0) = 0) and differentiable w.r.t. all parameters.

    Args:
        num_bases: Number of exponential basis functions. Default 4.
        max_duration: Maximum temporal extent in timesteps. Default 16.
    """

    def __init__(self, num_bases: int = 4, max_duration: int = 16):
        super().__init__()
        self.num_bases = num_bases
        self.max_duration = max_duration

        # Learnable kernel parameters
        self.log_tau = nn.Parameter(torch.linspace(math.log(1.0), math.log(max_duration), num_bases))
        self.amplitude = nn.Parameter(torch.randn(num_bases) * 0.1)
        self.omega = nn.Parameter(torch.zeros(num_bases))  # Oscillation freq
        self.phi = nn.Parameter(torch.zeros(num_bases))     # Phase offset

    def forward(self, duration: Optional[int] = None) -> Tensor:
        """Generate temporal kernel weights.

        Returns:
            (duration,) kernel tensor, normalized.
        """
        T = duration or self.max_duration
        t = torch.arange(T, device=self.log_tau.device, dtype=torch.float32)

        tau = self.log_tau.exp()  # (num_bases,)
        # (T, num_bases) exponential × cosine basis
        basis = (
            self.amplitude.unsqueeze(0)
            * torch.exp(-t.unsqueeze(1) / tau.unsqueeze(0))
            * torch.cos(self.omega.unsqueeze(0) * t.unsqueeze(1) + self.phi.unsqueeze(0))
        )

        kernel = basis.sum(dim=1)  # (T,)
        # L2 normalize for stable gradients
        return kernel / (kernel.norm() + 1e-8)


class TENNConv(nn.Module):
    """Temporal Event Convolution layer.

    Applies learnable temporal kernels over spike trains. Instead of
    standard spatial convolution, this convolves ALONG THE TIME AXIS
    using kernels parameterized as exponential decays.

    Input: (batch, T, channels) spike train
    Output: (batch, T, out_channels) temporally convolved features

    The temporal convolution is CAUSAL — output at time t depends only
    on inputs at times ≤ t.

    Args:
        in_channels: Input channels (neurons).
        out_channels: Output channels.
        kernel_duration: Temporal kernel length. Default 8.
        num_bases: Basis functions per kernel. Default 4.
        stride: Temporal stride. Default 1.
        spatial_features: If > 0, add spatial linear projection. Default 0.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_duration: int = 8,
        num_bases: int = 4,
        stride: int = 1,
        spatial_features: int = 0,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_duration = kernel_duration
        self.stride = stride

        # Spatial mixing: project input channels → output channels
        self.spatial = nn.Linear(in_channels, out_channels, bias=False)

        # One temporal kernel per output channel
        self.temporal_kernels = nn.ModuleList([
            TemporalKernel(num_bases=num_bases, max_duration=kernel_duration)
            for _ in range(out_channels)
        ])

        self.bias = nn.Parameter(torch.zeros(out_channels))

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass.

        Args:
            x: (batch, T, in_channels) spike train.

        Returns:
            (batch, T, out_channels) temporally convolved output.
        """
        B, T, C = x.shape

        # Spatial mixing: (B, T, C_in) → (B, T, C_out)
        h = self.spatial(x)

        # Apply temporal convolution per channel using causal conv1d
        # Reshape to (B, C_out, T) for conv1d
        h = h.transpose(1, 2)

        # Build composite temporal kernel: (C_out, 1, kernel_duration)
        kernels = torch.stack([
            k(self.kernel_duration) for k in self.temporal_kernels
        ], dim=0).unsqueeze(1)  # (C_out, 1, K)

        # Causal padding: pad left side only
        pad = self.kernel_duration - 1
        h_padded = F.pad(h, (pad, 0))

        # Depthwise temporal convolution
        out = F.conv1d(h_padded, kernels, groups=self.out_channels, stride=self.stride)

        # Add bias and transpose back
        out = out + self.bias.view(1, -1, 1)
        return out.transpose(1, 2)  # (B, T', C_out)


class TENNBlock(nn.Module):
    """TENN processing block with residual connection.

    Architecture:
        Input → TENNConv → LayerNorm → LIF/TTFS → Residual → Output

    This is the fundamental building block of TENN networks.
    The temporal convolution captures timing patterns, LIF/TTFS
    generates sparse spike output.

    Args:
        channels: Input/output channels.
        kernel_duration: Temporal kernel length. Default 8.
        num_bases: Temporal basis functions. Default 4.
        beta: Neuron decay. Default 0.9.
        use_ttfs: Use TTFS neurons (True) or LIF (False). Default True.
        dropout: Spike dropout rate. Default 0.1.
    """

    def __init__(
        self,
        channels: int,
        kernel_duration: int = 8,
        num_bases: int = 4,
        beta: float = 0.9,
        use_ttfs: bool = True,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.tenn_conv = TENNConv(channels, channels, kernel_duration, num_bases)
        self.norm = nn.LayerNorm(channels)
        self.use_ttfs = use_ttfs

        if use_ttfs:
            self.neuron = TTFSNeuron(beta=beta, learnable_beta=True)
        else:
            self.neuron = LeakyIntegrateAndFire(beta=beta)

        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

        # Feedforward expansion
        self.ff = nn.Sequential(
            nn.Linear(channels, channels * 2),
            nn.GELU(),
            nn.Linear(channels * 2, channels),
        )
        self.ff_norm = nn.LayerNorm(channels)

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass.

        Args:
            x: (batch, T, channels) input.

        Returns:
            (batch, T, channels) output.
        """
        # Temporal convolution path
        h = self.tenn_conv(x)
        h = self.norm(h)

        # Apply neuron per timestep
        B, T, C = h.shape
        self._reset_neuron()

        outputs = []
        for t in range(T):
            spike = self.neuron(h[:, t])
            outputs.append(spike)

        h = torch.stack(outputs, dim=1)  # (B, T, C)
        h = self.dropout(h)

        # Residual connection
        if x.shape == h.shape:
            h = h + x

        # Feedforward with residual
        ff_out = self.ff(self.ff_norm(h))
        h = h + self.dropout(ff_out)

        return h

    def _reset_neuron(self):
        self.neuron.reset_state()


class TENNAttention(nn.Module):
    """Temporal event attention — attends to spike timing patterns.

    Unlike standard attention over spatial features, this computes
    attention weights based on TEMPORAL PROXIMITY of spike events.
    Spikes close in time attend more strongly to each other.

    Uses the spike timing information directly:
        attention(i,j) ∝ exp(-|t_i - t_j| / τ) · (Q_i · K_j)

    This combines content-based attention (Q·K) with temporal
    locality bias (exponential decay).

    Args:
        embed_dim: Embedding dimension.
        num_heads: Attention heads. Default 4.
        tau: Temporal decay for proximity bias. Default 4.0.
    """

    def __init__(self, embed_dim: int, num_heads: int = 4, tau: float = 4.0):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.tau = nn.Parameter(torch.tensor(tau))

        self.qkv = nn.Linear(embed_dim, 3 * embed_dim, bias=False)
        self.out_proj = nn.Linear(embed_dim, embed_dim)
        self.scale = self.head_dim ** -0.5

    def forward(self, x: Tensor, spike_times: Optional[Tensor] = None) -> Tensor:
        """Forward pass.

        Args:
            x: (batch, T, embed_dim) input features.
            spike_times: (batch, T) optional spike timestamps for temporal bias.

        Returns:
            (batch, T, embed_dim) attended output.
        """
        B, T, D = x.shape
        H = self.num_heads

        qkv = self.qkv(x).reshape(B, T, 3, H, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # (B, H, T, head_dim)

        # Content attention
        attn = (q @ k.transpose(-2, -1)) * self.scale  # (B, H, T, T)

        # Temporal proximity bias
        if spike_times is not None:
            # |t_i - t_j| temporal distance matrix
            t_diff = spike_times.unsqueeze(-1) - spike_times.unsqueeze(-2)  # (B, T, T)
            temporal_bias = torch.exp(-t_diff.abs() / self.tau)  # (B, T, T)
            attn = attn + temporal_bias.unsqueeze(1).log().clamp(min=-10)  # Log-space add

        # Causal mask (optional — for autoregressive tasks)
        attn = F.softmax(attn, dim=-1)

        out = (attn @ v).transpose(1, 2).reshape(B, T, D)
        return self.out_proj(out)


class TENNEncoder(nn.Module):
    """Full TENN encoder stack.

    Stacks multiple TENNBlocks with optional TENNAttention layers.
    This is the temporal backbone for TENN-based models.

    Args:
        d_model: Model dimension.
        num_layers: Number of TENN blocks. Default 4.
        kernel_duration: Temporal kernel length. Default 8.
        num_heads: Attention heads (0 = no attention). Default 4.
        beta: Neuron decay. Default 0.9.
        use_ttfs: Use TTFS neurons. Default True.
        dropout: Dropout rate. Default 0.1.
    """

    def __init__(
        self,
        d_model: int,
        num_layers: int = 4,
        kernel_duration: int = 8,
        num_heads: int = 4,
        beta: float = 0.9,
        use_ttfs: bool = True,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.layers = nn.ModuleList()
        for _ in range(num_layers):
            self.layers.append(TENNBlock(
                channels=d_model,
                kernel_duration=kernel_duration,
                beta=beta,
                use_ttfs=use_ttfs,
                dropout=dropout,
            ))
            if num_heads > 0:
                self.layers.append(TENNAttention(d_model, num_heads))

    def forward(self, x: Tensor, spike_times: Optional[Tensor] = None) -> Tensor:
        """Forward pass.

        Args:
            x: (batch, T, d_model) input.
            spike_times: Optional (batch, T) spike timestamps.

        Returns:
            (batch, T, d_model) encoded output.
        """
        for layer in self.layers:
            if isinstance(layer, TENNAttention):
                x = x + layer(x, spike_times)
            else:
                x = layer(x)
        return x

    def reset_state(self):
        for layer in self.layers:
            if hasattr(layer, "_reset_neuron"):
                layer._reset_neuron()
