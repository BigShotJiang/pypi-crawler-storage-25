"""
Neural network layers with integrated spiking neurons.

Drop-in replacements for torch.nn layers that process spike trains
instead of continuous activations. Each layer applies a linear/conv
transform followed by a LIF neuron.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from typing import Optional, Tuple, Union

from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire, TTFSNeuron


class SpikeLinear(nn.Module):
    """Fully connected layer with LIF neuron.

    Linear(in, out) → LIF → binary spikes

    Args:
        in_features: Input dimension.
        out_features: Output dimension.
        bias: Include bias. Default True.
        beta: LIF decay factor. Default 0.9.
        threshold: LIF spike threshold. Default 1.0.
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        beta: float = 0.9,
        threshold: float = 1.0,
    ):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features, bias=bias)
        self.lif = LeakyIntegrateAndFire(beta=beta, threshold=threshold)

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass.

        Args:
            x: (batch, features) input spikes or currents at one timestep.

        Returns:
            (batch, out_features) binary spikes.
        """
        return self.lif(self.linear(x))

    def reset_state(self) -> None:
        self.lif.reset_state()

    def detach_state(self) -> None:
        self.lif.detach_state()


class SpikeConv2d(nn.Module):
    """2D convolutional layer with LIF neuron.

    Conv2d(in_ch, out_ch, kernel) → BatchNorm → LIF → binary spikes

    Args:
        in_channels: Input channels.
        out_channels: Output channels.
        kernel_size: Convolution kernel size.
        stride: Convolution stride. Default 1.
        padding: Padding. Default 0.
        beta: LIF decay. Default 0.9.
        threshold: LIF threshold. Default 1.0.
        batch_norm: Apply batch norm before LIF. Default True.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: Union[int, Tuple[int, int]],
        stride: int = 1,
        padding: int = 0,
        beta: float = 0.9,
        threshold: float = 1.0,
        batch_norm: bool = True,
    ):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, bias=not batch_norm)
        self.bn = nn.BatchNorm2d(out_channels) if batch_norm else nn.Identity()
        self.lif = LeakyIntegrateAndFire(beta=beta, threshold=threshold)

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass.

        Args:
            x: (batch, C_in, H, W) input at one timestep.

        Returns:
            (batch, C_out, H', W') binary spikes.
        """
        return self.lif(self.bn(self.conv(x)))

    def reset_state(self) -> None:
        self.lif.reset_state()

    def detach_state(self) -> None:
        self.lif.detach_state()


class SpikeConv1d(nn.Module):
    """1D convolutional layer with LIF neuron (for audio/time series).

    Args:
        in_channels: Input channels.
        out_channels: Output channels.
        kernel_size: Convolution kernel size.
        stride: Stride. Default 1.
        padding: Padding. Default 0.
        beta: LIF decay. Default 0.9.
        threshold: LIF threshold. Default 1.0.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int,
        stride: int = 1,
        padding: int = 0,
        beta: float = 0.9,
        threshold: float = 1.0,
    ):
        super().__init__()
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, stride, padding)
        self.bn = nn.BatchNorm1d(out_channels)
        self.lif = LeakyIntegrateAndFire(beta=beta, threshold=threshold)

    def forward(self, x: Tensor) -> Tensor:
        return self.lif(self.bn(self.conv(x)))

    def reset_state(self) -> None:
        self.lif.reset_state()

    def detach_state(self) -> None:
        self.lif.detach_state()


class SpikeRecurrent(nn.Module):
    """Recurrent spiking layer: input + recurrent feedback → LIF.

    I[t] = W_in · x[t] + W_rec · s[t-1]
    s[t] = LIF(I[t])

    Args:
        in_features: Input dimension.
        hidden_features: Hidden/recurrent dimension.
        beta: LIF decay. Default 0.9.
        threshold: LIF threshold. Default 1.0.
    """

    def __init__(
        self,
        in_features: int,
        hidden_features: int,
        beta: float = 0.9,
        threshold: float = 1.0,
    ):
        super().__init__()
        self.w_in = nn.Linear(in_features, hidden_features)
        self.w_rec = nn.Linear(hidden_features, hidden_features, bias=False)
        self.lif = LeakyIntegrateAndFire(beta=beta, threshold=threshold)
        self.prev_spikes: Optional[Tensor] = None

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass.

        Args:
            x: (batch, in_features) input at one timestep.

        Returns:
            (batch, hidden_features) binary spikes.
        """
        current = self.w_in(x)
        if self.prev_spikes is not None:
            current = current + self.w_rec(self.prev_spikes)
        spikes = self.lif(current)
        self.prev_spikes = spikes.detach()
        return spikes

    def reset_state(self) -> None:
        self.lif.reset_state()
        self.prev_spikes = None

    def detach_state(self) -> None:
        self.lif.detach_state()
        if self.prev_spikes is not None:
            self.prev_spikes = self.prev_spikes.detach()


class SpikeBatchNorm(nn.Module):
    """Batch normalization adapted for binary spike trains.

    Standard BN assumes continuous activations. For spikes, we normalize
    the membrane potential BEFORE the threshold comparison, not after.
    This preserves spike statistics while stabilizing training.

    Args:
        num_features: Number of channels/features.
        momentum: BN momentum. Default 0.1.
    """

    def __init__(self, num_features: int, momentum: float = 0.1):
        super().__init__()
        self.bn = nn.BatchNorm1d(num_features, momentum=momentum)

    def forward(self, x: Tensor) -> Tensor:
        if x.dim() == 4:  # (B, C, H, W)
            b, c, h, w = x.shape
            return nn.BatchNorm2d(c, device=x.device)(x)
        return self.bn(x)


class SpikeDropout(nn.Module):
    """Dropout for spike trains: randomly zero out spikes.

    Unlike standard dropout which scales by 1/(1-p), spike dropout
    simply removes spikes without rescaling (spikes are binary).

    Args:
        p: Dropout probability. Default 0.1.
    """

    def __init__(self, p: float = 0.1):
        super().__init__()
        self.p = p

    def forward(self, spikes: Tensor) -> Tensor:
        if not self.training or self.p == 0:
            return spikes
        mask = torch.bernoulli(torch.full_like(spikes, 1.0 - self.p))
        return spikes * mask


class SpikePooling(nn.Module):
    """Temporal spike pooling: aggregate spike train over time.

    Modes:
    - 'rate': Average spike count over time (rate decoding)
    - 'max': Max membrane potential over time
    - 'last': Last timestep membrane potential
    - 'weighted': Exponentially weighted sum (recent spikes matter more)

    Args:
        mode: Pooling mode. Default 'rate'.
        decay: Exponential decay for 'weighted' mode. Default 0.9.
    """

    def __init__(self, mode: str = "rate", decay: float = 0.9):
        super().__init__()
        self.mode = mode
        self.decay = decay

    def forward(self, spike_train: Tensor) -> Tensor:
        """Pool spike train over time dimension.

        Args:
            spike_train: (batch, T, *features) binary spike tensor.

        Returns:
            (batch, *features) pooled output.
        """
        if self.mode == "rate":
            return spike_train.mean(dim=1)
        elif self.mode == "max":
            return spike_train.max(dim=1).values
        elif self.mode == "last":
            return spike_train[:, -1]
        elif self.mode == "weighted":
            T = spike_train.shape[1]
            weights = torch.tensor(
                [self.decay ** (T - 1 - t) for t in range(T)],
                device=spike_train.device,
            )
            # Normalize weights
            weights = weights / weights.sum()
            # (T,) → broadcast shape
            shape = [1, T] + [1] * (spike_train.dim() - 2)
            return (spike_train * weights.view(*shape)).sum(dim=1)
        elif self.mode == "ttfs":
            # Time-To-First-Spike pooling: for each neuron, find the
            # first timestep it spiked. Earlier spike → higher output.
            # If no spike, output 0.
            T = spike_train.shape[1]
            # Find first spike time per neuron
            # cumsum trick: first 1 in cumsum marks first spike
            cumsum = spike_train.cumsum(dim=1)
            first_spike_mask = (cumsum == 1) & (spike_train > 0.5)
            # Time indices
            t_idx = torch.arange(T, device=spike_train.device).float()
            shape = [1, T] + [1] * (spike_train.dim() - 2)
            t_grid = t_idx.view(*shape).expand_as(spike_train)
            # Extract first spike times (T for no-spike neurons)
            spike_times = torch.where(first_spike_mask, t_grid, torch.tensor(float(T), device=spike_train.device))
            first_times = spike_times.min(dim=1).values  # (B, *features)
            # Normalize: early spike → high output
            output = (T - first_times) / T
            return output.clamp(0.0, 1.0)
        else:
            raise ValueError(f"Unknown pooling mode: {self.mode}")


class TTFSLinear(nn.Module):
    """Linear layer with TTFS neuron.

    Linear(in, out) → TTFS → fires at most once per neuron.
    Output is spike TIMING, not binary spikes.

    Energy: O(1) spikes per neuron vs O(T) for rate-coded SpikeLinear.

    Args:
        in_features: Input dimension.
        out_features: Output dimension.
        beta: TTFS neuron decay. Default 0.9.
        threshold: Spike threshold. Default 1.0.
        max_timesteps: Max T for normalization. Default 8.
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        beta: float = 0.9,
        threshold: float = 1.0,
        max_timesteps: int = 8,
    ):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features, bias=bias)
        self.ttfs = TTFSNeuron(
            beta=beta, threshold=threshold,
            learnable_beta=True, learnable_threshold=True,
            max_timesteps=max_timesteps,
        )

    def forward(self, x: Tensor) -> Tensor:
        """Single timestep forward. Returns binary spike (0 or 1).

        Call ttfs.decode() after all timesteps for timing-based output.
        """
        return self.ttfs(self.linear(x))

    def decode(self) -> Tensor:
        """Get TTFS decoded output after all timesteps."""
        return self.ttfs.decode()

    def reset_state(self) -> None:
        self.ttfs.reset_state()

    def detach_state(self) -> None:
        self.ttfs.detach_state()

    @property
    def total_spikes(self) -> int:
        return self.ttfs.total_spikes


class TTFSConv2d(nn.Module):
    """2D convolution with TTFS neuron.

    Conv2d → BatchNorm → TTFS → fires at most once per output neuron.

    Args:
        in_channels: Input channels.
        out_channels: Output channels.
        kernel_size: Conv kernel size.
        stride: Stride. Default 1.
        padding: Padding. Default 0.
        beta: TTFS decay. Default 0.9.
        threshold: Spike threshold. Default 1.0.
        max_timesteps: Max T. Default 8.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: Union[int, Tuple[int, int]],
        stride: int = 1,
        padding: int = 0,
        beta: float = 0.9,
        threshold: float = 1.0,
        max_timesteps: int = 8,
    ):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.ttfs = TTFSNeuron(
            beta=beta, threshold=threshold,
            learnable_beta=True, learnable_threshold=True,
            max_timesteps=max_timesteps,
        )

    def forward(self, x: Tensor) -> Tensor:
        """Single timestep. Returns binary spikes."""
        return self.ttfs(self.bn(self.conv(x)))

    def decode(self) -> Tensor:
        return self.ttfs.decode()

    def reset_state(self) -> None:
        self.ttfs.reset_state()

    def detach_state(self) -> None:
        self.ttfs.detach_state()

    @property
    def total_spikes(self) -> int:
        return self.ttfs.total_spikes
