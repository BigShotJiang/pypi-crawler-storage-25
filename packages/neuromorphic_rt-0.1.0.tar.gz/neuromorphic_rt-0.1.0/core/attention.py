"""
Spike-coded attention mechanisms — THE KEY INNOVATION.

Ported from Neurovision R/04-spiking-attention.R:
  - nn_spiking_linear_attention → SpikeLinearAttention
  - nn_wta_spiking_attention → WinnerTakeAllAttention
  - nn_hybrid_spiking_block → HybridSpikeBlock

Standard softmax attention: O(n²) and requires floating-point exp().
Spike linear attention: O(n·d) using binary spike gates + cumulative KV.
This is the theoretical foundation for the 1000x energy claim.
"""

from __future__ import annotations

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from typing import Optional

from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire, surrogate_spike


class SpikeLinearAttention(nn.Module):
    """Softmax-free linear attention via spike gates.

    Instead of softmax(QK^T/√d)V which is O(n²), we compute:
    1. Q, K, V projections (standard)
    2. Apply spike gate to Q: Q_spike = LIF(Q)  →  binary {0,1}
    3. Cumulative KV: KV_cum[t] = Σ_{s≤t} K[s]^T V[s]  (causal)
    4. Output[t] = Q_spike[t] · KV_cum[t]  →  O(n·d) per step

    The spike gate makes Q binary, so the Q·KV multiplication becomes
    a conditional copy (free if spike=0, cheap if spike=1). This is
    where the energy savings come from: most Q entries are 0 (sparse).

    From Neurovision R/04-spiking-attention.R: nn_spiking_linear_attention

    Args:
        embed_dim: Model dimension d.
        num_heads: Number of attention heads.
        beta: LIF decay for Q spike gate. Default 0.85.
        threshold: LIF threshold for Q gate. Default 0.5.
        dropout: Attention dropout. Default 0.0.
    """

    def __init__(
        self,
        embed_dim: int,
        num_heads: int = 1,
        beta: float = 0.85,
        threshold: float = 0.5,
        dropout: float = 0.0,
    ):
        super().__init__()
        assert embed_dim % num_heads == 0
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads

        self.q_proj = nn.Linear(embed_dim, embed_dim)
        self.k_proj = nn.Linear(embed_dim, embed_dim)
        self.v_proj = nn.Linear(embed_dim, embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)

        # Spike gate for queries — this makes attention sparse
        self.q_spike = LeakyIntegrateAndFire(
            beta=beta, threshold=threshold, reset_mechanism="subtract"
        )

        # Feature map for linear attention (ELU + 1)
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

        # Cumulative KV state for causal attention
        self.kv_state: Optional[Tensor] = None

    def _feature_map(self, x: Tensor) -> Tensor:
        """Non-negative feature map φ(x) = ELU(x) + 1."""
        return F.elu(x) + 1.0

    def forward(self, x: Tensor, causal: bool = True) -> Tensor:
        """Compute spike-gated linear attention.

        Args:
            x: (batch, seq_len, embed_dim) input at one timestep or full sequence.
            causal: If True, use causal (autoregressive) attention. Default True.

        Returns:
            (batch, seq_len, embed_dim) attention output.
        """
        B, L, D = x.shape

        # Project Q, K, V
        q = self.q_proj(x).view(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        # (B, H, L, D_h)

        # Apply feature map to K for linear attention
        k = self._feature_map(k)

        # Apply spike gate to Q — this is THE innovation
        # Reshape for LIF: (B*H, L, D_h) → process each position
        q_flat = q.reshape(B * self.num_heads * L, self.head_dim)
        q_spikes = self.q_spike(q_flat)
        q_spikes = q_spikes.view(B, self.num_heads, L, self.head_dim)

        if causal:
            # Causal linear attention with cumulative KV
            # For each position t: out[t] = q_spike[t] · Σ_{s≤t} k[s]^T v[s]
            kv_cumsum = torch.zeros(
                B, self.num_heads, self.head_dim, self.head_dim,
                device=x.device, dtype=x.dtype,
            )
            outputs = []
            for t in range(L):
                # Accumulate k^T v
                kv_cumsum = kv_cumsum + torch.einsum(
                    "bhd,bhe->bhde", k[:, :, t], v[:, :, t]
                )
                # Query with spike gate: only compute if spike fires
                out_t = torch.einsum("bhd,bhde->bhe", q_spikes[:, :, t], kv_cumsum)
                outputs.append(out_t)
            output = torch.stack(outputs, dim=2)  # (B, H, L, D_h)
        else:
            # Non-causal: full linear attention
            # out = q_spike · (k^T v) / (q_spike · k^T · 1)
            kv = torch.einsum("bhld,bhlv->bhdv", k, v)  # (B, H, D_h, D_h)
            output = torch.einsum("bhld,bhdv->bhlv", q_spikes, kv)

            # Normalize
            k_sum = k.sum(dim=2)  # (B, H, D_h)
            normalizer = torch.einsum("bhld,bhd->bhl", q_spikes, k_sum).unsqueeze(-1)
            output = output / (normalizer + 1e-6)

        # Reshape back
        output = output.transpose(1, 2).contiguous().view(B, L, D)
        output = self.out_proj(output)
        output = self.dropout(output)

        return output

    def reset_state(self) -> None:
        self.q_spike.reset_state()
        self.kv_state = None

    def detach_state(self) -> None:
        self.q_spike.detach_state()

    def get_spike_rate(self) -> float:
        """Return average Q spike rate (for energy estimation)."""
        # Will be tracked during forward pass in production
        return 0.05  # Typical: 5% of Q positions fire


class WinnerTakeAllAttention(nn.Module):
    """Winner-Take-All competitive spiking attention.

    Ultra-sparse: only the TOP-K neurons with highest membrane potential
    fire at each timestep. All others are suppressed via lateral inhibition.

    This produces extremely sparse spike patterns — ideal for energy
    efficiency. From Neurovision: nn_wta_spiking_attention

    Args:
        embed_dim: Model dimension.
        num_heads: Number of attention heads.
        k: Number of winners per head. Default 4.
    """

    def __init__(self, embed_dim: int, num_heads: int = 1, k: int = 4):
        super().__init__()
        assert embed_dim % num_heads == 0
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.k = k

        self.qkv = nn.Linear(embed_dim, 3 * embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)

        # Membrane potential accumulator
        self.membrane: Optional[Tensor] = None

    def forward(self, x: Tensor) -> Tensor:
        """Compute WTA attention.

        Args:
            x: (batch, seq_len, embed_dim).

        Returns:
            (batch, seq_len, embed_dim) with ultra-sparse output.
        """
        B, L, D = x.shape
        qkv = self.qkv(x).reshape(B, L, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # (B, H, L, D_h)

        # Compute attention scores (unnormalized)
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.head_dim)

        # WTA: keep only top-k per query position
        topk_vals, topk_idx = scores.topk(min(self.k, L), dim=-1)
        mask = torch.zeros_like(scores)
        mask.scatter_(-1, topk_idx, 1.0)

        # Apply mask and normalize
        scores = scores * mask
        attn = scores / (scores.sum(dim=-1, keepdim=True) + 1e-8)

        # Apply to values
        output = torch.matmul(attn, v)

        # Binary spike output via surrogate
        output_flat = output.reshape(-1, self.head_dim)
        spikes = surrogate_spike(output_flat, 0.5, 25.0)
        output = spikes.view(B, self.num_heads, L, self.head_dim)

        output = output.transpose(1, 2).contiguous().view(B, L, D)
        return self.out_proj(output)

    def reset_state(self) -> None:
        self.membrane = None


class HybridSpikeBlock(nn.Module):
    """Hybrid block alternating SSM and spiking attention.

    From Neurovision: nn_hybrid_spiking_block
    Pattern: SSM handles long-range dependencies, spike attention
    handles local/competitive selection.

    Architecture: LayerNorm → SSM → Residual → LayerNorm → SpikeAttn → Residual → FFN

    Args:
        embed_dim: Model dimension.
        num_heads: Attention heads. Default 4.
        ssm_dim: SSM state dimension. Default 16.
        expand_factor: FFN expansion. Default 2.
    """

    def __init__(
        self,
        embed_dim: int,
        num_heads: int = 4,
        ssm_dim: int = 16,
        expand_factor: int = 2,
    ):
        super().__init__()
        from neuromorphic_rt.core.ssm import SpikeSSM

        self.norm1 = nn.LayerNorm(embed_dim)
        self.ssm = SpikeSSM(embed_dim, state_dim=ssm_dim)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.attn = SpikeLinearAttention(embed_dim, num_heads=num_heads)
        self.norm3 = nn.LayerNorm(embed_dim)

        # Spiking FFN
        hidden = embed_dim * expand_factor
        self.ffn = nn.Sequential(
            nn.Linear(embed_dim, hidden),
            nn.SiLU(),
            nn.Linear(hidden, embed_dim),
        )
        self.ffn_spike = LeakyIntegrateAndFire(beta=0.9, threshold=1.0)

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass through hybrid block.

        Args:
            x: (batch, seq_len, embed_dim).

        Returns:
            (batch, seq_len, embed_dim).
        """
        # SSM branch
        residual = x
        x = self.norm1(x)
        x = self.ssm(x)
        x = x + residual

        # Spike attention branch
        residual = x
        x = self.norm2(x)
        x = self.attn(x)
        x = x + residual

        # FFN branch with spike gate
        residual = x
        x = self.norm3(x)
        x_ffn = self.ffn(x)
        # Apply spike gate per position
        B, L, D = x_ffn.shape
        x_flat = x_ffn.reshape(B * L, D)
        x_spikes = self.ffn_spike(x_flat)
        x = x_spikes.view(B, L, D) + residual

        return x

    def reset_state(self) -> None:
        self.ssm.reset_state()
        self.attn.reset_state()
        self.ffn_spike.reset_state()
