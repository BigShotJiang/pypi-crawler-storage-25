"""NeuromorphicRT core: spiking neuron primitives, encoding, synapses, layers, TENN, TTFS."""
