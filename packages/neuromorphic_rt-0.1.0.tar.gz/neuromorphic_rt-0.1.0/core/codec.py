"""
Encode/decode between standard float tensors and spike trains.

Provides the bridge between conventional deep learning and spiking
neural networks, enabling hybrid architectures and DNN-to-SNN conversion.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor
from typing import Optional

from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire
from neuromorphic_rt.core.encoding import rate_encode, temporal_encode, delta_encode


class TensorToSpike(nn.Module):
    """Convert float tensors to spike trains using configurable encoding.

    Args:
        method: Encoding method ('rate', 'temporal', 'delta', 'learned'). Default 'rate'.
        num_steps: Number of timesteps for rate/temporal encoding. Default 4.
        threshold: Delta encoding threshold. Default 0.1.
        in_features: Required for 'learned' method.
    """

    def __init__(
        self,
        method: str = "rate",
        num_steps: int = 4,
        threshold: float = 0.1,
        in_features: Optional[int] = None,
    ):
        super().__init__()
        self.method = method
        self.num_steps = num_steps
        self.threshold = threshold

        if method == "learned":
            assert in_features is not None, "in_features required for learned encoding"
            from neuromorphic_rt.core.encoding import LearnedEncoder
            self.encoder = LearnedEncoder(in_features, num_steps)

    def forward(self, x: Tensor) -> Tensor:
        """Convert float tensor to spike train.

        Args:
            x: (batch, *features) for rate/temporal/learned,
               (batch, T, *features) for delta.

        Returns:
            (batch, T, *features) binary spike tensor.
        """
        if self.method == "rate":
            return rate_encode(x, self.num_steps)
        elif self.method == "temporal":
            return temporal_encode(x, self.num_steps)
        elif self.method == "delta":
            return delta_encode(x, self.threshold)
        elif self.method == "learned":
            return self.encoder(x)
        else:
            raise ValueError(f"Unknown encoding method: {self.method}")


class SpikeToTensor(nn.Module):
    """Convert spike trains back to float tensors.

    Multiple decoding strategies:
    - rate: Average spike count over time (most common)
    - membrane: Final membrane potential readout
    - weighted: Exponentially weighted spike sum
    - first_spike: Time of first spike (latency decoding)

    Args:
        method: Decoding method. Default 'rate'.
        decay: Exponential decay for 'weighted'. Default 0.9.
    """

    def __init__(self, method: str = "rate", decay: float = 0.9):
        super().__init__()
        self.method = method
        self.decay = decay

    def forward(self, spikes: Tensor, membrane: Optional[Tensor] = None) -> Tensor:
        """Decode spike train to float tensor.

        Args:
            spikes: (batch, T, *features) binary spike tensor.
            membrane: Optional membrane potential for 'membrane' method.

        Returns:
            (batch, *features) float tensor.
        """
        if self.method == "rate":
            return spikes.mean(dim=1)

        elif self.method == "membrane":
            if membrane is not None:
                return membrane
            return spikes[:, -1]  # Last timestep as fallback

        elif self.method == "weighted":
            T = spikes.shape[1]
            weights = torch.tensor(
                [self.decay ** (T - 1 - t) for t in range(T)],
                device=spikes.device, dtype=spikes.dtype,
            )
            weights = weights / weights.sum()
            shape = [1, T] + [1] * (spikes.dim() - 2)
            return (spikes * weights.view(*shape)).sum(dim=1)

        elif self.method == "first_spike":
            # Time of first spike (lower = stronger signal)
            # Use argmax on cumsum to find first spike time
            cum = spikes.cumsum(dim=1)
            first_time = (cum >= 1).float().argmax(dim=1).float()
            # Normalize: earlier spike = higher value
            T = spikes.shape[1]
            return 1.0 - first_time / T

        else:
            raise ValueError(f"Unknown decoding method: {self.method}")


class SpikeAccumulator(nn.Module):
    """Accumulate spikes over time with leaky integration.

    Maintains a running membrane potential that integrates incoming
    spikes with configurable leak. Useful for output layers where
    you want a smooth readout from spike trains.

    Args:
        decay: Leak factor (0-1). 1.0 = perfect integrator. Default 0.95.
        scale: Scaling factor per spike. Default 1.0.
    """

    def __init__(self, decay: float = 0.95, scale: float = 1.0):
        super().__init__()
        self.decay = decay
        self.scale = scale
        self.accumulator: Optional[Tensor] = None

    def forward(self, spikes: Tensor) -> Tensor:
        """Accumulate spikes into continuous potential.

        Args:
            spikes: (batch, *features) binary spikes at one timestep.

        Returns:
            (batch, *features) accumulated potential.
        """
        if self.accumulator is None:
            self.accumulator = torch.zeros_like(spikes)

        self.accumulator = self.decay * self.accumulator + self.scale * spikes
        return self.accumulator

    def reset_state(self) -> None:
        self.accumulator = None

    def detach_state(self) -> None:
        if self.accumulator is not None:
            self.accumulator = self.accumulator.detach()
