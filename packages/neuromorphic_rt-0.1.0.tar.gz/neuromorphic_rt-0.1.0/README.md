# NeuromorphicRT

**Spiking Neural Network Runtime for Edge AI**

The first complete SNN operating system that turns any sensor into an intelligent agent at 1/1000th the power of conventional AI inference. Drop-in TensorRT replacement with spike-aware energy profiling, TENN temporal processing, and TTFS output coding.

55 Python files | 9,500+ lines | 11 model architectures | 5 neuron types | 3 hardware targets

```
pip install neuromorphic-rt
```

---

## Why Spiking Neural Networks?

Conventional DNNs process every input through every neuron at every layer — dense matrix multiplications burning watts of power. Biological brains use **spikes**: sparse, binary, event-driven signals where most neurons are silent most of the time.

NeuromorphicRT brings this efficiency to production edge hardware:

| Metric | Standard DNN | NeuromorphicRT (LIF) | NeuromorphicRT (TTFS) |
|--------|-------------|---------------------|----------------------|
| Energy per inference | ~0.5 mJ | ~0.05 mJ | **~0.008 mJ** |
| Compute model | Dense MACs | Sparse spike events | Single spike per neuron |
| Power at edge | 5-15W | 1-3W | **<1W** |
| Always-on capable | No | Yes | **Yes** |

**Key result: 62.5x energy reduction** over standard DNNs using TTFS coding.

---

## Architecture

```
                    NeuromorphicRT Stack
 ┌─────────────────────────────────────────────────┐
 │  Services    API Server | Fleet Mgmt | Alerts   │
 ├─────────────────────────────────────────────────┤
 │  Deploy      Jetson Orin | Pi 5 | Edge Runtime  │
 ├─────────────────────────────────────────────────┤
 │  Training    Trainer | TTFS Loss | Curriculum    │
 ├─────────────────────────────────────────────────┤
 │  SDK         Engine | Converter | Profiler       │
 ├─────────────────────────────────────────────────┤
 │  Models      Vision | Audio | Anomaly | Fusion   │
 ├─────────────────────────────────────────────────┤
 │  Core        Neurons | TENN | Encoding | Layers  │
 │              Synapses | Attention | SSM | Codec   │
 └─────────────────────────────────────────────────┘
```

---

## Quick Start

```python
from neuromorphic_rt.sdk.engine import NeuromorphicEngine
from neuromorphic_rt.models import get_model

# Build a spiking vision model
model = get_model("tenn-net7", num_classes=10, num_steps=8)

# Load into inference engine
engine = NeuromorphicEngine()
engine.from_pytorch(model)
engine.optimize(target="jetson_orin_nano")

# Run inference with energy profiling
import torch
result = engine.infer(torch.randn(1, 3, 32, 32))

print(f"Latency:  {result.latency_ms:.2f} ms")
print(f"Energy:   {result.estimated_energy_mj:.4f} mJ")
print(f"Spikes:   {result.spike_count}")
print(f"Spike rate: {result.spike_rate:.2%}")
```

### Convert an existing DNN to spiking

```python
from neuromorphic_rt.sdk.converter import relu_to_lif, calibrate_thresholds

# Convert ReLU activations to LIF neurons
spiking_model = relu_to_lif(your_pytorch_model, num_steps=4, beta=0.9)

# Calibrate thresholds on real data
calibrate_thresholds(spiking_model, calibration_loader, percentile=99.0)
```

### CLI

```bash
neuromorphic-rt benchmark --tasks all --device cuda
neuromorphic-rt convert --input resnet18.pth --output spike_resnet.pth
neuromorphic-rt deploy --model spike_resnet.pth --target jetson --power-mode 7W
neuromorphic-rt serve --port 8080 --model spike_resnet.pth
neuromorphic-rt profile --model spike_resnet.pth --energy
neuromorphic-rt demo --task vision --live
```

---

## Technical Breakdown

### Core: Neuron Models

Five biologically-grounded neuron implementations, all with surrogate gradient support for backpropagation through the Heaviside step function.

| Neuron | Dynamics | Use Case |
|--------|----------|----------|
| **LeakyIntegrateAndFire** | `dV/dt = -(V-V_rest)/tau + I/C` | General purpose, rate coding |
| **AdaptiveExponentialIF** | Exponential spike initiation + threshold adaptation | Complex temporal patterns |
| **IzhikevichNeuron** | 2D system (v, u), 20+ firing patterns | Biological fidelity |
| **TTFSNeuron** | Fires at most once; timing = information | Ultra-low energy, temporal coding |
| **SurrogateSpike** | `1/(1+k|x|)^2` autograd function | Gradient computation for all neurons |

**Surrogate gradient**: The core challenge of training SNNs is that spikes are non-differentiable (Heaviside step). NeuromorphicRT uses the fast sigmoid surrogate `sigma'(x) = 1/(1+k|x|)^2` with configurable sharpness `k` (default 25.0) for stable backpropagation.

### Core: Temporal Event Neural Networks (TENN)

TENN replaces discrete timestep binning with learnable continuous temporal kernels:

```
k(t) = sum_k( a_k * exp(-t/tau_k) * cos(omega_k * t + phi_k) )
```

All parameters (`a_k`, `tau_k`, `omega_k`, `phi_k`) are learnable. The exponential decay provides biological plausibility while the cosine basis captures oscillatory patterns.

**Architecture**: `TENNConv` (causal temporal convolution) -> `LayerNorm` -> `LIF/TTFS neuron` -> `residual + FFN`

**TENNAttention** adds temporal proximity bias: `exp(-|t_i - t_j| / tau)` weighted on top of content attention, so temporally close spikes attend more strongly.

### Core: Time-To-First-Spike (TTFS)

Instead of counting spikes over T timesteps (rate coding), TTFS neurons fire **at most once**. The information is encoded in *when* the neuron fires:

- Earlier spike = stronger activation
- Never fires = no activation
- Decode: `output = (T - spike_time) / T`

**Energy impact**: With T=8 timesteps, rate-coded neurons may fire 0-8 times each. TTFS neurons fire 0 or 1 time. This yields up to **8x fewer spike events** = direct energy savings.

### Core: Spike Encoding

| Encoder | Method | Best For |
|---------|--------|----------|
| `rate_encode` | Poisson spike trains from float values | Static images |
| `temporal_encode` | Time-to-first-spike from float values | Precision tasks |
| `delta_encode` | Spikes on change > threshold | Streaming sensors, event cameras |
| `latency_encode` | Inter-spike intervals encode magnitude | Analog signals |
| `LearnedEncoder` | Trainable encoding parameters | End-to-end optimization |

### Core: Attention & SSM

- **SpikeLinearAttention**: O(n*d) softmax-free attention using binary spike gates + cumulative KV accumulation. No quadratic bottleneck.
- **WinnerTakeAllAttention**: Competitive lateral inhibition — only top-k neurons survive per timestep.
- **SelectiveSSM**: Mamba-style state space model with Blelloch parallel scan for O(n log n) sequence processing.
- **SpikeSSM**: SSM with spike-gated state updates — state only changes when spikes arrive.
- **HybridSpikeBlock**: Parallel attention + SSM paths merged through learned gating.

### Core: Synaptic Plasticity

- **STDP**: Spike-timing-dependent plasticity (pre-before-post strengthens, post-before-pre weakens)
- **HomeostaticScaling**: Maintains target firing rates by scaling synaptic weights
- **DopamineModulatedSTDP**: Reward-modulated plasticity for reinforcement learning scenarios

---

## Model Architectures

### 11 Registered Models

| Model | Registry Key | Type | Neurons | Task |
|-------|-------------|------|---------|------|
| SpikeNet7 | `spike-net7` | 7-layer CNN | LIF | Image classification |
| SpikeResNet | `spike-resnet` | Residual CNN | LIF | Image classification |
| SpikeYOLO | `spike-yolo` | Detection | LIF | Object detection |
| TENNNet7 | `tenn-net7` | 7-layer CNN | TTFS | Image classification (6.25x less energy) |
| TENNResNet | `tenn-resnet` | Hybrid ResNet | LIF+TTFS | Image classification (temporal) |
| SpikeKWS | `spike-kws` | 1D CNN | LIF | Keyword spotting |
| SpikeVAD | `spike-vad` | 1D CNN | LIF | Voice activity detection |
| TENNKWS | `tenn-kws` | TENN+1D CNN | TTFS | Keyword spotting (early exit) |
| SpikeAutoencoder | `spike-autoencoder` | Autoencoder | LIF | Anomaly detection |
| TemporalAnomalyDetector | `temporal-anomaly` | Temporal | LIF | Temporal anomaly detection |
| UniversalSensorAgent | `universal-sensor` | Multi-modal | LIF | 5-modality sensor fusion |

```python
from neuromorphic_rt.models import get_model

# Any model by name
model = get_model("tenn-resnet", num_classes=100, num_steps=8)
model = get_model("spike-yolo", num_classes=80, num_steps=4)
model = get_model("tenn-kws", num_classes=12, num_steps=8)
```

### Multi-Modal Fusion

`UniversalSensorAgent` processes 5 sensor modalities simultaneously through modality-specific spike encoders, cross-modal attention, and a unified classification head:

- Vision (camera frames)
- Audio (microphone)
- IMU (accelerometer/gyroscope)
- Environment (temperature, humidity, pressure, light)
- Network (packet statistics)

---

## SDK & Toolchain

### Inference Engine

Drop-in TensorRT replacement with hardware-specific energy models:

```python
engine = NeuromorphicEngine()
engine.from_pytorch(model)
engine.optimize(target="jetson_orin_nano")  # or "raspberry_pi5", "generic_cpu"

# Benchmark with energy profiling
bench = engine.benchmark(sample_input, num_runs=100, warmup=10)
print(f"Throughput: {bench.throughput_fps:.1f} FPS")
print(f"Energy: {bench.avg_energy_mj:.4f} mJ/inference")
print(f"Spike events: {bench.total_spike_events}")
```

**Hardware energy models** (picojoules per operation):

| Operation | Jetson Orin Nano | Raspberry Pi 5 | Generic CPU |
|-----------|-----------------|----------------|-------------|
| MAC (GPU) | 45.0 pJ | 120.0 pJ | 200.0 pJ |
| MAC (Tensor Core) | 3.7 pJ | N/A | N/A |
| Spike event | 0.9 pJ | 2.1 pJ | 5.0 pJ |
| DRAM read | 12.0 pJ | 20.0 pJ | 30.0 pJ |
| Static power | 1.5 W | 2.5 W | 15.0 W |

### Energy Profiler

Per-layer energy breakdown with comparison to ANN baseline:

```python
from neuromorphic_rt.sdk.profiler import EnergyProfiler

profiler = EnergyProfiler(target="jetson_orin_nano")
report = profiler.profile(model, sample_input)

for layer in report.layer_profiles:
    print(f"{layer.name}: {layer.energy_mj:.4f} mJ ({layer.spike_rate:.1%} spike rate)")
```

### Model Converter

Convert any PyTorch DNN to a spiking equivalent:

```python
from neuromorphic_rt.sdk.converter import relu_to_lif, calibrate_thresholds, prune_silent_neurons

spiking = relu_to_lif(dnn_model, num_steps=4)
calibrate_thresholds(spiking, data_loader, percentile=99.0)
prune_silent_neurons(spiking, data_loader, threshold=0.01)  # Remove dead neurons
```

---

## Training

### TTFS Loss Functions

Three specialized loss functions for time-to-first-spike training:

```python
from neuromorphic_rt.training.ttfs_loss import TTFSCrossEntropy, TemporalOrderLoss, TTFSEnergyLoss

# Standard CE on TTFS pseudo-logits
loss_fn = TTFSCrossEntropy(num_classes=10, num_steps=8)

# Margin-based: correct class must fire before others by margin
loss_fn = TemporalOrderLoss(margin=0.5, num_steps=8)

# Multi-objective: task + spike_rate + late_penalty
loss_fn = TTFSEnergyLoss(
    num_classes=10, num_steps=8,
    lambda_spike=0.1,   # Penalize high spike rates
    lambda_late=0.05,    # Penalize late correct predictions
)
```

### Curriculum Learning

Progressive temporal complexity — start with ANN behavior, graduate to full SNN:

```python
from neuromorphic_rt.training.curriculum import CurriculumScheduler

scheduler = CurriculumScheduler(
    initial_timesteps=1,   # T=1: behaves like standard ANN
    target_timesteps=8,    # T=8: full temporal processing
    warmup_epochs=10,
    schedule="linear",
)

for epoch in range(100):
    T = scheduler.get_timesteps(epoch)
    # Train with T timesteps...
```

### Knowledge Distillation

Transfer knowledge from a trained DNN teacher to a spiking student:

```python
from neuromorphic_rt.training.distillation import DNNtoSpikeDistiller

distiller = DNNtoSpikeDistiller(teacher=dnn_model, student=spiking_model)
distiller.distill(train_loader, epochs=50, temperature=3.0, alpha=0.7)
```

---

## Deployment

### Jetson Orin Nano

```python
from neuromorphic_rt.deploy.jetson import JetsonDeployer

deployer = JetsonDeployer(power_mode="7W")
deployer.deploy(model, quantize="int8", dla_offload=True)
deployer.monitor()  # Real-time tegrastats
```

### Raspberry Pi 5

```python
from neuromorphic_rt.deploy.pi import PiDeployer

deployer = PiDeployer()
deployer.deploy(model, quantize="int8")
deployer.generate_systemd_service("spike-inference")
```

### Edge Runtime

Event-driven inference with power-aware batching:

```python
from neuromorphic_rt.deploy.edge_runtime import EdgeRuntime

runtime = EdgeRuntime(model, target="jetson_orin_nano")
runtime.start()  # Async event loop with watchdog
```

### Fleet Management

```python
from neuromorphic_rt.services.fleet import FleetManager

fleet = FleetManager()
fleet.discover()  # mDNS auto-discovery
fleet.deploy_model(model, strategy="canary", canary_pct=0.1)
fleet.health_check()
```

---

## Sensors

Built-in drivers for 5 sensor modalities with a unified interface:

| Sensor | Class | Input | Output |
|--------|-------|-------|--------|
| Camera | `CameraSensor` | USB/CSI frames | `(B, C, H, W)` float |
| Audio | `AudioSensor` | Microphone PCM | `(B, mel_bins, T)` float |
| IMU | `IMUSensor` | Accel/Gyro | `(B, 6)` float |
| Environment | `EnvironmentSensor` | Temp/Humidity/Pressure/Light | `(B, 4)` float |
| Network | `NetworkSensor` | Packet stats | `(B, features)` float |
| **Fusion** | `SensorFusion` | All of the above | Synchronized multi-modal |

All sensors auto-encode to spikes using the appropriate encoding scheme (rate for images, delta for streams).

---

## Benchmarking & Publication

### Automated Benchmarks

```bash
neuromorphic-rt benchmark --tasks vision audio anomaly --device cuda --output results.json
```

### Report Generation

```python
from neuromorphic_rt.benchmark.report import BenchmarkReport

report = BenchmarkReport(results)
report.to_json("results.json")
report.to_markdown("results.md")
report.to_latex("results.tex")
report.plot_figures("figures/")  # Nature-style 300 DPI
```

### LaTeX Tables

Publication-ready tables for energy comparisons, architecture details, hardware specs, and ablation studies:

```python
from neuromorphic_rt.paper.latex_tables import energy_table, architecture_table
print(energy_table(benchmark_results))
```

---

## Use Cases

### Defense & Security

- **Perimeter surveillance**: SpikeYOLO on Jetson Orin Nano for always-on intrusion detection at <2W total power. Solar/battery viable for remote installations.
- **Acoustic threat classification**: TENNKWS for gunshot/explosion detection with early-exit TTFS — classify in 2-3 timesteps instead of 8, cutting energy proportional to decision speed.
- **Network intrusion detection**: TemporalAnomalyDetector on packet flows for neuromorphic IDS (HAS-IDS 2.0 application). Temporal spike patterns detect anomalies that statistical methods miss.
- **Drone swarm awareness**: UniversalSensorAgent fusing camera + IMU + environment for multi-modal situational awareness at <1W per node.

### Industrial IoT

- **Predictive maintenance**: SpikeAutoencoder on vibration/current sensor data. Deploy on Pi 5 fleet with OTA model updates. Catches bearing degradation weeks before failure.
- **Quality inspection**: TENNNet7 on production line cameras. Sub-10ms inference enables real-time reject gating at line speed.
- **Hazard monitoring**: Multi-sensor fusion (gas + temperature + humidity + vibration) with anomaly detection for industrial safety.

### Smart City

- **Traffic flow**: SpikeYOLO counting vehicles at intersections. Battery-powered nodes with LoRa backhaul — no wired power needed.
- **Urban sound classification**: TENNKWS discriminating sirens, construction, traffic, crowd noise. Early-exit means energy proportional to ambiguity.
- **Infrastructure health**: Temporal anomaly detection on bridge accelerometers, pipeline pressure sensors, power grid harmonics.

### Autonomous Systems

- **Event-camera perception**: Delta encoding is native event-camera format. Direct spike processing without frame reconstruction.
- **Low-power autonomy**: IMU + vision fusion for micro-UAV navigation at <1W compute budget.
- **Predictive control**: Temporal patterns in sensor streams enable anticipatory actuation.

### Healthcare

- **Wearable monitoring**: Continuous ECG/PPG anomaly detection at microwatt power. TTFS early-exit means the device only fully wakes on detected anomalies.
- **Fall detection**: IMU spike processing with sub-millisecond response latency.
- **Sleep analysis**: Temporal pattern recognition on multi-channel biosignals.

### Agriculture

- **Crop monitoring**: Solar-powered Pi 5 nodes with environment sensors. Fleet-managed across hectares with OTA model updates as seasons change.
- **Pest detection**: TENNNet7 on camera traps. Delta encoding means only movement generates compute.
- **Irrigation optimization**: Multi-sensor fusion (soil moisture + weather + plant health metrics) with anomaly detection for irrigation scheduling.

---

## Project Structure

```
neuromorphic_rt/
├── __init__.py              # Package root, public API
├── cli.py                   # CLI entry point (8 commands)
├── pyproject.toml           # Package config, dependencies
├── workforce_integration.py # AI Cowboys Workforce OS connector
│
├── core/                    # Spiking primitives
│   ├── neurons.py           # 5 neuron types + surrogate gradient
│   ├── tenn.py              # Temporal Event Neural Networks
│   ├── layers.py            # Spike/TTFS Conv, Linear, Pooling
│   ├── encoding.py          # 5 spike encoders + learned encoder
│   ├── synapses.py          # STDP, homeostatic, dopamine plasticity
│   ├── attention.py         # Spike linear attention, WTA, hybrid
│   ├── ssm.py               # Selective SSM, Spike SSM, parallel scan
│   └── codec.py             # Tensor-to-spike, spike-to-tensor
│
├── models/                  # 11 model architectures
│   ├── vision.py            # SpikeNet7, SpikeResNet, SpikeYOLO
│   ├── audio.py             # SpikeKWS, SpikeVAD
│   ├── anomaly.py           # SpikeAutoencoder, TemporalAnomalyDetector
│   ├── fusion.py            # UniversalSensorAgent (5 modalities)
│   ├── tenn_vision.py       # TENNNet7, TENNResNet
│   └── tenn_audio.py        # TENNKWS
│
├── sdk/                     # Developer toolkit
│   ├── engine.py            # Inference engine (TensorRT replacement)
│   ├── converter.py         # DNN-to-SNN conversion
│   └── profiler.py          # Per-layer energy profiling
│
├── training/                # Training pipeline
│   ├── trainer.py           # SpikeTrainer with surrogate gradients
│   ├── ttfs_loss.py         # 3 TTFS-specific loss functions
│   ├── curriculum.py        # T=1→T=8 curriculum scheduler
│   └── distillation.py      # DNN-to-SNN knowledge distillation
│
├── deploy/                  # Hardware deployment
│   ├── jetson.py            # Jetson Orin Nano (TensorRT, DLA, INT8)
│   ├── pi.py                # Raspberry Pi 5 (INT8, systemd)
│   └── edge_runtime.py      # Event-driven inference runtime
│
├── services/                # Production services
│   ├── api.py               # FastAPI REST + WebSocket
│   ├── fleet.py             # mDNS discovery + OTA deployment
│   └── notifications.py     # Pushover, Telegram, email, webhook
│
├── sensors/                 # Sensor drivers
│   ├── camera.py            # USB/CSI camera
│   ├── audio.py             # Microphone
│   ├── imu.py               # Accelerometer/gyroscope
│   ├── environment.py       # Temp/humidity/pressure/light
│   ├── network.py           # Network traffic
│   └── fusion.py            # Multi-modal sync pipeline
│
├── benchmark/               # Benchmarking
│   ├── harness.py           # Multi-model benchmark harness
│   ├── report.py            # JSON/Markdown/LaTeX/figure reports
│   ├── power.py             # USB meter + smart plug measurement
│   └── tasks/               # Per-domain benchmark tasks
│       ├── vision_bench.py
│       ├── audio_bench.py
│       └── anomaly_bench.py
│
└── paper/                   # Publication tooling
    ├── figures.py           # Nature-style 300 DPI plots
    └── latex_tables.py      # Energy, architecture, hardware tables
```

---

## Installation

### Basic (CPU)

```bash
pip install neuromorphic-rt
```

### Full (GPU + sensors + API server)

```bash
pip install neuromorphic-rt[full,sensors]
```

### Jetson Orin Nano

```bash
pip install neuromorphic-rt[jetson,sensors]
```

### Development

```bash
git clone https://github.com/The-AI-Cowboys-Projects/NRT.git
cd NRT
pip install -e ".[dev,full,sensors]"
```

---

## Requirements

- Python >= 3.10
- PyTorch >= 2.0
- NumPy >= 1.24
- SciPy >= 1.10

Optional: OpenCV, FastAPI, PyAudio, jetson-stats, WandB, ONNX

---

## License

Apache 2.0

## Author

**Michael Pendleton** — [AI Cowboys](https://aicowboys.com)

Built with the [Workforce OS](https://github.com/The-AI-Cowboys-Projects/workforce) autonomous multi-agent system.
