"""NeuromorphicRT benchmark suite: harness, power measurement, task benchmarks."""
