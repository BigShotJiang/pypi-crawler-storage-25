"""
Anomaly detection benchmark task.

Compares SpikeAutoencoder vs standard autoencoder on detection
accuracy and energy efficiency.
"""

from __future__ import annotations

from typing import Any, Dict

import torch
import torch.nn as nn


class AnomalyBenchmark:
    """Anomaly detection benchmark using autoencoders."""

    def __init__(self, device: str = "cpu", num_trials: int = 100):
        self.device = device
        self.num_trials = num_trials
        self.input_dim = 64
        self.anomaly_threshold = 0.5

    def create_dnn_baseline(self) -> nn.Module:
        """Standard autoencoder baseline."""
        return nn.Sequential(
            nn.Linear(self.input_dim, 32), nn.ReLU(),
            nn.Linear(32, 16), nn.ReLU(),
            nn.Linear(16, 32), nn.ReLU(),
            nn.Linear(32, self.input_dim),
        ).to(self.device)

    def create_spike_model(self) -> nn.Module:
        """Spiking autoencoder."""
        from neuromorphic_rt.models.anomaly import SpikeAutoencoder
        return SpikeAutoencoder(input_dim=self.input_dim).to(self.device)

    def run(self) -> Dict[str, Any]:
        """Run anomaly detection benchmark."""
        from neuromorphic_rt.sdk.engine import NeuromorphicEngine

        dnn = self.create_dnn_baseline()
        spike = self.create_spike_model()
        engine = NeuromorphicEngine(device=self.device)

        normal_data = [torch.randn(1, self.input_dim, device=self.device) * 0.5 for _ in range(int(self.num_trials * 0.8))]
        anomaly_data = [torch.randn(1, self.input_dim, device=self.device) * 3.0 for _ in range(int(self.num_trials * 0.2))]

        test_inputs = normal_data + anomaly_data
        test_labels = [0] * len(normal_data) + [1] * len(anomaly_data)

        dnn.eval()
        dnn_correct = 0
        dnn_energy_total = 0
        with torch.no_grad():
            for x, y in zip(test_inputs, test_labels):
                recon = dnn(x)
                error = (x - recon).pow(2).mean().item()
                pred = 1 if error > self.anomaly_threshold else 0
                dnn_correct += int(pred == y)
                dnn_energy_total += 12.0

        engine.from_pytorch(spike)
        spike_correct = 0
        spike_energy_total = 0
        for x, y in zip(test_inputs, test_labels):
            result = engine.infer(x)
            error = (x - result.output).pow(2).mean().item()
            pred = 1 if error > self.anomaly_threshold else 0
            spike_correct += int(pred == y)
            spike_energy_total += result.estimated_energy_mj

        total = len(test_inputs)
        return {
            "task": "anomaly_detection",
            "dnn": {
                "accuracy": dnn_correct / total,
                "energy_mj": dnn_energy_total / total,
                "total_energy_mj": dnn_energy_total,
            },
            "spike": {
                "accuracy": spike_correct / total,
                "energy_mj": spike_energy_total / total,
                "total_energy_mj": spike_energy_total,
            },
        }
