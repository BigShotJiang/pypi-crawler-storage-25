"""Benchmark task implementations."""
