"""
Audio benchmark task — keyword spotting.

Compares SpikeKWS vs standard 1D CNN on accuracy and energy.
"""

from __future__ import annotations

from typing import Any, Dict

import torch
import torch.nn as nn


class AudioBenchmark:
    """Keyword spotting benchmark."""

    def __init__(self, device: str = "cpu", num_trials: int = 100):
        self.device = device
        self.num_trials = num_trials

    def create_dnn_baseline(self) -> nn.Module:
        """Standard 1D CNN baseline for keyword spotting."""
        return nn.Sequential(
            nn.Conv1d(40, 64, 3, padding=1), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 128, 3, padding=1), nn.BatchNorm1d(128), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Linear(128, 12),
        ).to(self.device)

    def create_spike_model(self) -> nn.Module:
        """Spiking keyword spotting model."""
        from neuromorphic_rt.models.audio import SpikeKWS
        return SpikeKWS(num_keywords=12, mel_bins=40).to(self.device)

    def run(self) -> Dict[str, Any]:
        """Run audio benchmark."""
        from neuromorphic_rt.sdk.engine import NeuromorphicEngine

        dnn = self.create_dnn_baseline()
        spike = self.create_spike_model()
        engine = NeuromorphicEngine(device=self.device)

        test_inputs = [torch.randn(1, 40, 101, device=self.device) for _ in range(self.num_trials)]
        test_labels = [torch.randint(0, 12, (1,), device=self.device) for _ in range(self.num_trials)]

        dnn.eval()
        dnn_correct = 0
        dnn_energy_total = 0
        with torch.no_grad():
            for x, y in zip(test_inputs, test_labels):
                out = dnn(x)
                pred = out.argmax(dim=-1)
                dnn_correct += (pred == y).sum().item()
                dnn_energy_total += 8.5

        engine.from_pytorch(spike)
        spike_correct = 0
        spike_energy_total = 0
        for x, y in zip(test_inputs, test_labels):
            result = engine.infer(x)
            pred = result.output.argmax(dim=-1)
            spike_correct += (pred == y).sum().item()
            spike_energy_total += result.estimated_energy_mj

        return {
            "task": "keyword_spotting",
            "dnn": {
                "accuracy": dnn_correct / self.num_trials,
                "energy_mj": dnn_energy_total / self.num_trials,
                "total_energy_mj": dnn_energy_total,
            },
            "spike": {
                "accuracy": spike_correct / self.num_trials,
                "energy_mj": spike_energy_total / self.num_trials,
                "total_energy_mj": spike_energy_total,
            },
        }
