"""
Vision benchmark task — CIFAR-10 object classification.

Compares SpikeNet7 vs standard CNN on accuracy and energy.
"""

from __future__ import annotations

from typing import Any, Dict

import torch
import torch.nn as nn


class VisionBenchmark:
    """CIFAR-10 level vision benchmark."""

    def __init__(self, device: str = "cpu", num_trials: int = 100):
        self.device = device
        self.num_trials = num_trials

    def create_dnn_baseline(self) -> nn.Module:
        """Standard CNN baseline for comparison."""
        return nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.AdaptiveAvgPool2d(4),
            nn.Flatten(),
            nn.Linear(128 * 4 * 4, 256), nn.ReLU(),
            nn.Linear(256, 10),
        ).to(self.device)

    def create_spike_model(self) -> nn.Module:
        """Spiking model for benchmark."""
        from neuromorphic_rt.models.vision import SpikeNet7
        return SpikeNet7(num_classes=10).to(self.device)

    def run(self) -> Dict[str, Any]:
        """Run vision benchmark."""
        from neuromorphic_rt.sdk.engine import NeuromorphicEngine

        dnn = self.create_dnn_baseline()
        spike = self.create_spike_model()
        engine = NeuromorphicEngine(device=self.device)

        test_inputs = [torch.randn(1, 3, 32, 32, device=self.device) for _ in range(self.num_trials)]
        test_labels = [torch.randint(0, 10, (1,), device=self.device) for _ in range(self.num_trials)]

        # DNN baseline
        dnn.eval()
        dnn_correct = 0
        dnn_energy_total = 0
        with torch.no_grad():
            for x, y in zip(test_inputs, test_labels):
                out = dnn(x)
                pred = out.argmax(dim=-1)
                dnn_correct += (pred == y).sum().item()
                dnn_energy_total += 10.0

        # Spike model
        engine.from_pytorch(spike)
        spike_correct = 0
        spike_energy_total = 0
        for x, y in zip(test_inputs, test_labels):
            result = engine.infer(x)
            pred = result.output.argmax(dim=-1)
            spike_correct += (pred == y).sum().item()
            spike_energy_total += result.estimated_energy_mj

        return {
            "task": "object_detection",
            "dnn": {
                "accuracy": dnn_correct / self.num_trials,
                "energy_mj": dnn_energy_total / self.num_trials,
                "total_energy_mj": dnn_energy_total,
            },
            "spike": {
                "accuracy": spike_correct / self.num_trials,
                "energy_mj": spike_energy_total / self.num_trials,
                "total_energy_mj": spike_energy_total,
            },
        }
