"""
Publication-ready benchmark report generator.

Combines benchmark results with figures and tables into
a complete reproducibility report.
"""

from __future__ import annotations

import json
import time
from typing import Any, Dict
from pathlib import Path


class BenchmarkReport:
    """Generates comprehensive benchmark reports."""

    def __init__(self, results: Dict[str, Any], output_dir: str = "benchmark_report"):
        self.results = results
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def generate_json(self) -> str:
        path = self.output_dir / "results.json"
        path.write_text(json.dumps(self.results, indent=2, default=str))
        return str(path)

    def generate_markdown(self) -> str:
        tasks = self.results.get("tasks", {})
        meta = self.results.get("metadata", {})

        lines = [
            "# NeuromorphicRT Benchmark Report",
            "",
            f"**Date**: {time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"**Device**: {meta.get('device', 'unknown')}",
            f"**Trials**: {meta.get('num_trials', 'N/A')}",
            "",
            "## Summary",
            "",
            "| Task | DNN Energy (mJ) | Spike Energy (mJ) | Ratio | DNN Acc | Spike Acc |",
            "|------|------------------|--------------------|-------|---------|-----------|",
        ]

        total_ratio = 0
        for task_name, data in tasks.items():
            dnn = data.get("dnn", {})
            spike = data.get("spike", {})
            dnn_e = dnn.get("energy_mj", 0)
            spike_e = spike.get("energy_mj", 0)
            ratio = dnn_e / spike_e if spike_e > 0 else 0
            total_ratio += ratio
            lines.append(
                f"| {task_name} | {dnn_e:.2f} | {spike_e:.4f} | "
                f"{ratio:.0f}x | {dnn.get('accuracy', 0):.3f} | {spike.get('accuracy', 0):.3f} |"
            )

        if tasks:
            lines += ["", f"**Average energy ratio**: {total_ratio / len(tasks):.0f}x", ""]

        lines += [
            "## Reproducibility",
            "",
            "```bash",
            "pip install neuromorphic-rt[dev]",
            "neuromorphic-rt benchmark --tasks all --device cuda --num-trials 100",
            "```",
        ]

        path = self.output_dir / "report.md"
        path.write_text("\n".join(lines))
        return str(path)

    def generate_figures(self) -> list:
        from neuromorphic_rt.paper.figures import (
            plot_energy_comparison, plot_accuracy_energy_pareto, plot_power_trace,
        )

        figures = []
        fig_dir = self.output_dir / "figures"
        fig_dir.mkdir(exist_ok=True)

        for fn, name in [
            (plot_energy_comparison, "fig_energy_comparison.pdf"),
            (plot_accuracy_energy_pareto, "fig_pareto.pdf"),
        ]:
            try:
                figures.append(fn(self.results, str(fig_dir / name)))
            except Exception:
                pass

        try:
            figures.append(plot_power_trace(output_path=str(fig_dir / "fig_power_trace.pdf")))
        except Exception:
            pass

        return figures

    def generate_latex(self) -> str:
        from neuromorphic_rt.paper.latex_tables import generate_all_tables
        tables = generate_all_tables(self.results)
        path = self.output_dir / "tables.tex"
        path.write_text(tables)
        return str(path)

    def generate_all(self) -> Dict[str, Any]:
        outputs = {
            "json": self.generate_json(),
            "markdown": self.generate_markdown(),
            "latex": self.generate_latex(),
        }
        try:
            outputs["figures"] = self.generate_figures()
        except Exception:
            outputs["figures"] = []
        return outputs
