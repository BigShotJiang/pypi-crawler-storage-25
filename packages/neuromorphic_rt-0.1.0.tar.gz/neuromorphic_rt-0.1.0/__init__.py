"""
NeuromorphicRT — Spiking Neural Network Runtime for Edge AI

The first spiking neural network operating system that turns any sensor
into an intelligent agent at 1/1000th the power of current AI inference.

Copyright (c) 2026 Michael Pendleton / AI Cowboys
License: Apache-2.0
"""

__version__ = "0.1.0"
__author__ = "Michael Pendleton"
__license__ = "Apache-2.0"

from neuromorphic_rt.core.neurons import (
    LeakyIntegrateAndFire,
    AdaptiveExponentialIF,
    IzhikevichNeuron,
)
from neuromorphic_rt.core.encoding import (
    rate_encode,
    temporal_encode,
    delta_encode,
    latency_encode,
)
from neuromorphic_rt.core.layers import (
    SpikeLinear,
    SpikeConv2d,
    SpikeRecurrent,
)
from neuromorphic_rt.core.attention import SpikeLinearAttention
from neuromorphic_rt.core.ssm import SelectiveSSM

__all__ = [
    "LeakyIntegrateAndFire",
    "AdaptiveExponentialIF",
    "IzhikevichNeuron",
    "rate_encode",
    "temporal_encode",
    "delta_encode",
    "latency_encode",
    "SpikeLinear",
    "SpikeConv2d",
    "SpikeRecurrent",
    "SpikeLinearAttention",
    "SelectiveSSM",
]
