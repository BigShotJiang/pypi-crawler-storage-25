"""
TTFS-specific loss functions for Time-To-First-Spike training.

Standard cross-entropy doesn't work well with TTFS because:
- TTFS outputs are spike TIMES, not logits
- We want the correct class to fire FIRST (earliest spike = most confident)
- Wrong classes should fire LATE or not at all

These losses are designed for the TTFS paradigm where information
is encoded in temporal ordering of spikes.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from typing import Optional


class TTFSCrossEntropy(nn.Module):
    """Cross-entropy loss adapted for TTFS outputs.

    Converts spike times to pseudo-logits:
        logit_i = (T - spike_time_i) / T

    Earlier spike → higher logit → higher class probability.
    Then applies standard cross-entropy.

    This naturally encourages the correct class neuron to fire first
    and wrong class neurons to fire late/never.

    Args:
        temperature: Sharpness of the softmax. Default 1.0.
        label_smoothing: Label smoothing factor. Default 0.0.
    """

    def __init__(self, temperature: float = 1.0, label_smoothing: float = 0.0):
        super().__init__()
        self.temperature = temperature
        self.label_smoothing = label_smoothing

    def forward(self, spike_times: Tensor, targets: Tensor, max_timesteps: int = 8) -> Tensor:
        """Compute TTFS cross-entropy loss.

        Args:
            spike_times: (batch, num_classes) raw spike times or TTFS decoded output.
            targets: (batch,) class labels.
            max_timesteps: Max timesteps T.

        Returns:
            Scalar loss.
        """
        # If inputs look like spike times (values > 1), normalize
        if spike_times.max() > 1.5:
            logits = (max_timesteps - spike_times) / max_timesteps
        else:
            logits = spike_times  # Already decoded to [0, 1]

        logits = logits / self.temperature
        return F.cross_entropy(logits, targets, label_smoothing=self.label_smoothing)


class TemporalOrderLoss(nn.Module):
    """Margin-based temporal ordering loss for TTFS.

    Enforces that the correct class neuron fires BEFORE all wrong
    class neurons by at least a temporal margin:
        L = Σ_{j≠y} max(0, t_y - t_j + margin)

    Where t_y is the spike time of the correct class and t_j is the
    spike time of wrong class j.

    This is more direct than cross-entropy for TTFS: it explicitly
    penalizes temporal ordering violations.

    Args:
        margin: Minimum temporal gap between correct and wrong classes. Default 1.0.
        reduction: 'mean' or 'sum'. Default 'mean'.
    """

    def __init__(self, margin: float = 1.0, reduction: str = "mean"):
        super().__init__()
        self.margin = margin
        self.reduction = reduction

    def forward(self, spike_times: Tensor, targets: Tensor) -> Tensor:
        """Compute temporal ordering loss.

        Args:
            spike_times: (batch, num_classes) spike times (lower = earlier).
            targets: (batch,) class labels.

        Returns:
            Scalar loss.
        """
        B, C = spike_times.shape

        # Get correct class spike times: (B, 1)
        correct_times = spike_times.gather(1, targets.unsqueeze(1))

        # Margin loss: penalize if correct class fires after wrong class
        # t_correct - t_wrong + margin > 0 means violation
        margin_violations = correct_times - spike_times + self.margin  # (B, C)

        # Zero out the correct class (no self-comparison)
        mask = torch.ones_like(margin_violations)
        mask.scatter_(1, targets.unsqueeze(1), 0)

        loss = F.relu(margin_violations) * mask

        if self.reduction == "mean":
            return loss.sum() / (B * (C - 1))
        return loss.sum()


class TTFSEnergyLoss(nn.Module):
    """Combined TTFS loss with energy regularization.

    L = L_task + λ_spike · L_spike + λ_late · L_late

    Where:
    - L_task: Cross-entropy or temporal ordering loss
    - L_spike: Penalizes TOTAL spike count (fewer spikes = less energy)
    - L_late: Penalizes late correct-class spikes (encourage fast decisions)

    This directly optimizes for the energy-accuracy tradeoff.

    Args:
        task_loss: 'cross_entropy' or 'temporal_order'. Default 'cross_entropy'.
        lambda_spike: Spike count penalty weight. Default 0.01.
        lambda_late: Late spike penalty weight. Default 0.1.
        margin: Temporal order margin. Default 1.0.
    """

    def __init__(
        self,
        task_loss: str = "cross_entropy",
        lambda_spike: float = 0.01,
        lambda_late: float = 0.1,
        margin: float = 1.0,
    ):
        super().__init__()
        self.lambda_spike = lambda_spike
        self.lambda_late = lambda_late

        if task_loss == "cross_entropy":
            self.task_fn = TTFSCrossEntropy()
        elif task_loss == "temporal_order":
            self.task_fn = TemporalOrderLoss(margin=margin)
        else:
            raise ValueError(f"Unknown task loss: {task_loss}")

    def forward(
        self,
        spike_times: Tensor,
        targets: Tensor,
        total_spikes: Optional[int] = None,
        total_neurons: Optional[int] = None,
        max_timesteps: int = 8,
    ) -> Tensor:
        """Compute combined TTFS energy loss.

        Args:
            spike_times: (batch, num_classes) TTFS output.
            targets: (batch,) labels.
            total_spikes: Total spikes fired in network (for energy penalty).
            total_neurons: Total neurons (for normalization).
            max_timesteps: Max T.

        Returns:
            Scalar loss.
        """
        # Task loss
        if isinstance(self.task_fn, TTFSCrossEntropy):
            loss = self.task_fn(spike_times, targets, max_timesteps)
        else:
            loss = self.task_fn(spike_times, targets)

        # Spike count penalty (fewer spikes = less energy)
        if total_spikes is not None and total_neurons is not None and total_neurons > 0:
            spike_rate = total_spikes / total_neurons
            loss = loss + self.lambda_spike * spike_rate

        # Late correct-class penalty
        if spike_times.max() > 1.5:
            # Raw spike times
            correct_times = spike_times.gather(1, targets.unsqueeze(1)).squeeze(1)
            loss = loss + self.lambda_late * (correct_times / max_timesteps).mean()
        else:
            # Decoded [0,1] — higher = earlier, so penalize LOW values
            correct_output = spike_times.gather(1, targets.unsqueeze(1)).squeeze(1)
            loss = loss + self.lambda_late * (1.0 - correct_output).mean()

        return loss
