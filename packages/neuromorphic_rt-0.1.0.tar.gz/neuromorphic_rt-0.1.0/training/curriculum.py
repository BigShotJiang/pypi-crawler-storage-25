"""
Curriculum learning for spiking neural networks.

Key insight: SNNs struggle with long temporal sequences early in training.
Start with T=1 timestep (essentially a standard ANN) and gradually increase
to full temporal depth. This dramatically improves convergence.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

import torch
import torch.nn as nn


@dataclass
class CurriculumConfig:
    """Curriculum learning configuration."""
    initial_timesteps: int = 1
    max_timesteps: int = 8
    warmup_epochs: int = 5           # Epochs at initial_timesteps before ramping
    ramp_epochs: int = 20            # Epochs to linearly ramp from initial to max
    spike_rate_target: float = 0.05  # Target 5% firing rate
    difficulty_metric: str = "loss"  # 'loss', 'spike_rate', 'accuracy'
    auto_adjust: bool = True         # Auto-adjust based on training metrics


@dataclass
class CurriculumState:
    """Tracks curriculum progression."""
    current_epoch: int = 0
    current_timesteps: int = 1
    current_difficulty: float = 0.0
    history: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def phase(self) -> str:
        if self.current_timesteps == 1:
            return "ann_warmup"
        elif self.current_difficulty < 0.5:
            return "early_temporal"
        elif self.current_difficulty < 0.9:
            return "temporal_ramp"
        else:
            return "full_temporal"


class CurriculumScheduler:
    """Manages timestep curriculum for SNN training.

    Schedule:
    1. ANN warmup (T=1): Learn spatial features without temporal complexity
    2. Early temporal (T=2-3): Introduce basic spike dynamics
    3. Temporal ramp (T=4-6): Full surrogate gradient training
    4. Full temporal (T=max): Final fine-tuning at target depth

    The scheduler can also adjust:
    - Spike rate regularization strength (increases with timesteps)
    - Learning rate (decreases as timesteps increase)
    - Beta (membrane decay) initialization range
    """

    def __init__(self, config: Optional[CurriculumConfig] = None):
        self.config = config or CurriculumConfig()
        self.state = CurriculumState(current_timesteps=self.config.initial_timesteps)

    def step(self, epoch: int, metrics: Optional[Dict[str, float]] = None) -> int:
        """Advance curriculum and return current timesteps.

        Args:
            epoch: Current training epoch.
            metrics: Training metrics (loss, accuracy, spike_rate).

        Returns:
            Number of timesteps for this epoch.
        """
        self.state.current_epoch = epoch

        if epoch < self.config.warmup_epochs:
            # Phase 1: ANN warmup
            t = self.config.initial_timesteps
        elif epoch < self.config.warmup_epochs + self.config.ramp_epochs:
            # Phase 2-3: Linear ramp
            progress = (epoch - self.config.warmup_epochs) / self.config.ramp_epochs
            t_range = self.config.max_timesteps - self.config.initial_timesteps
            t = self.config.initial_timesteps + int(progress * t_range)
        else:
            # Phase 4: Full temporal
            t = self.config.max_timesteps

        # Auto-adjust: if loss spiked, hold current timesteps
        if self.config.auto_adjust and metrics and len(self.state.history) > 1:
            prev_loss = self.state.history[-1].get("loss", float("inf"))
            curr_loss = metrics.get("loss", 0)
            if curr_loss > prev_loss * 1.5:
                t = self.state.current_timesteps  # Hold, don't advance

        self.state.current_timesteps = max(1, min(t, self.config.max_timesteps))
        self.state.current_difficulty = (
            (self.state.current_timesteps - self.config.initial_timesteps)
            / max(self.config.max_timesteps - self.config.initial_timesteps, 1)
        )

        # Record history
        record = {
            "epoch": epoch,
            "timesteps": self.state.current_timesteps,
            "difficulty": self.state.current_difficulty,
            "phase": self.state.phase,
        }
        if metrics:
            record.update(metrics)
        self.state.history.append(record)

        return self.state.current_timesteps

    def get_spike_rate_weight(self) -> float:
        """Spike rate regularization weight — increases with timesteps."""
        return 0.01 * self.state.current_difficulty

    def get_lr_multiplier(self) -> float:
        """LR multiplier — decrease as temporal complexity increases."""
        return 1.0 - 0.5 * self.state.current_difficulty

    def get_beta_range(self) -> Tuple[float, float]:
        """Beta initialization range — tighten as training progresses."""
        if self.state.current_timesteps <= 2:
            return (0.5, 0.99)  # Wide range early
        elif self.state.current_timesteps <= 4:
            return (0.7, 0.95)
        else:
            return (0.8, 0.95)  # Tight range for long sequences

    def update_model_timesteps(self, model: nn.Module) -> None:
        """Update all temporal modules in model to current timesteps."""
        for m in model.modules():
            if hasattr(m, "timesteps"):
                m.timesteps = self.state.current_timesteps
            if hasattr(m, "num_steps"):
                m.num_steps = self.state.current_timesteps

    def summary(self) -> str:
        """Human-readable curriculum status."""
        return (
            f"Curriculum: epoch={self.state.current_epoch}, "
            f"T={self.state.current_timesteps}/{self.config.max_timesteps}, "
            f"phase={self.state.phase}, "
            f"difficulty={self.state.current_difficulty:.2f}"
        )


class DifficultyAwareSampler:
    """Dataset sampler that increases difficulty with curriculum.

    Early: easy samples (high confidence, clean data)
    Late: full dataset including hard/noisy samples
    """

    def __init__(
        self,
        dataset_size: int,
        difficulty_scores: Optional[torch.Tensor] = None,
    ):
        self.dataset_size = dataset_size
        if difficulty_scores is not None:
            self.difficulty_scores = difficulty_scores
        else:
            # Assign random difficulty if not provided
            self.difficulty_scores = torch.rand(dataset_size)

        # Sort indices by difficulty
        self.sorted_indices = torch.argsort(self.difficulty_scores).tolist()

    def get_indices(self, difficulty: float) -> List[int]:
        """Get sample indices for current difficulty level.

        Args:
            difficulty: 0.0 (easiest) to 1.0 (full dataset).

        Returns:
            List of dataset indices to use.
        """
        n = max(1, int(self.dataset_size * (0.3 + 0.7 * difficulty)))
        return self.sorted_indices[:n]
