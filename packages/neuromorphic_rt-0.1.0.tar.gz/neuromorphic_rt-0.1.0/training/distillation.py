"""
Knowledge distillation: DNN teacher → spiking student.

Train a standard DNN first (easy, fast convergence), then distill
its knowledge into a spiking student model. This bridges the accuracy
gap between DNNs and SNNs.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from dataclasses import dataclass
from typing import Optional


@dataclass
class DistillResult:
    """Distillation result."""
    student_accuracy: float
    teacher_accuracy: float
    accuracy_gap: float
    final_kd_loss: float
    epochs_trained: int


class DNNtoSpikeDistiller:
    """Knowledge distillation from DNN teacher to spiking student.

    Uses soft targets (temperature-scaled logits) from the teacher
    to guide the student's learning. The student learns to match
    the teacher's output distribution, not just hard labels.

    Args:
        temperature: Softmax temperature for soft targets. Default 4.0.
        alpha: Weight of KD loss vs task loss. Default 0.7.
        feature_matching: Also match intermediate features. Default False.
    """

    def __init__(
        self,
        temperature: float = 4.0,
        alpha: float = 0.7,
        feature_matching: bool = False,
    ):
        self.temperature = temperature
        self.alpha = alpha
        self.feature_matching = feature_matching

    def distill(
        self,
        teacher: nn.Module,
        student: nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader,
        epochs: int = 50,
        lr: float = 1e-3,
        device: str = "cuda",
    ) -> DistillResult:
        """Run knowledge distillation.

        Args:
            teacher: Pre-trained DNN teacher model.
            student: Spiking student model to train.
            train_loader: Training data.
            val_loader: Validation data.
            epochs: Training epochs.
            lr: Learning rate.
            device: Device.

        Returns:
            DistillResult with accuracy comparison.
        """
        device_obj = torch.device(device if torch.cuda.is_available() else "cpu")
        teacher = teacher.to(device_obj).eval()
        student = student.to(device_obj)

        optimizer = torch.optim.AdamW(student.parameters(), lr=lr)
        task_criterion = nn.CrossEntropyLoss()

        for epoch in range(epochs):
            student.train()
            total_loss = 0
            num_batches = 0

            for batch in train_loader:
                if isinstance(batch, (list, tuple)):
                    x, y = batch[0].to(device_obj), batch[1].to(device_obj)
                else:
                    x = batch.to(device_obj)
                    y = torch.zeros(x.shape[0], dtype=torch.long, device=device_obj)

                # Reset student states
                for m in student.modules():
                    if hasattr(m, "reset_state"):
                        m.reset_state()

                optimizer.zero_grad()

                # Teacher forward (no grad)
                with torch.no_grad():
                    teacher_logits = teacher(x)
                    if isinstance(teacher_logits, dict):
                        teacher_logits = teacher_logits.get("classification", teacher_logits)

                # Student forward
                student_logits = student(x)
                if isinstance(student_logits, dict):
                    student_logits = student_logits.get("classification", student_logits)

                # KD loss: KL divergence on soft targets
                T = self.temperature
                kd_loss = F.kl_div(
                    F.log_softmax(student_logits / T, dim=-1),
                    F.softmax(teacher_logits / T, dim=-1),
                    reduction="batchmean",
                ) * (T * T)

                # Task loss: cross-entropy on hard labels
                task_loss = task_criterion(student_logits, y)

                # Combined loss
                loss = self.alpha * kd_loss + (1 - self.alpha) * task_loss

                loss.backward()
                nn.utils.clip_grad_norm_(student.parameters(), 1.0)
                optimizer.step()

                total_loss += loss.item()
                num_batches += 1

            if (epoch + 1) % 10 == 0:
                avg_loss = total_loss / max(num_batches, 1)
                print(f"Distill epoch {epoch+1}/{epochs} | Loss: {avg_loss:.4f}")

        # Evaluate both
        from neuromorphic_rt.training.trainer import SpikeTrainer
        trainer = SpikeTrainer()
        student_eval = trainer.evaluate(student, val_loader, device)
        teacher_eval = trainer.evaluate(teacher, val_loader, device)

        return DistillResult(
            student_accuracy=student_eval.accuracy,
            teacher_accuracy=teacher_eval.accuracy,
            accuracy_gap=teacher_eval.accuracy - student_eval.accuracy,
            final_kd_loss=total_loss / max(num_batches, 1),
            epochs_trained=epochs,
        )
