"""NeuromorphicRT training: spike-aware training, curriculum learning, distillation."""
