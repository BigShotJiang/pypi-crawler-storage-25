"""
Spike-coded anomaly detection models.

Novel insight: anomalies change spike TIMING patterns, not just rates.
Inter-spike interval (ISI) statistics reveal temporal anomalies that
rate-coded DNNs miss entirely.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor
from typing import Optional

from neuromorphic_rt.core.layers import SpikeLinear, SpikeRecurrent
from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire
from neuromorphic_rt.core.encoding import delta_encode


class SpikeAutoencoder(nn.Module):
    """Spiking autoencoder for unsupervised anomaly detection.

    Compresses sensor data into a spike code (bottleneck) and reconstructs.
    Anomaly score = reconstruction error. Works with ANY sensor modality.

    Architecture:
        Encoder: in → 128 → 64 → latent_dim (all SpikeLinear)
        Decoder: latent_dim → 64 → 128 → in (standard Linear for reconstruction)

    Args:
        in_features: Input dimension.
        latent_dim: Bottleneck dimension. Default 16.
        num_steps: Timesteps for processing. Default 4.
        beta: LIF decay. Default 0.9.
        anomaly_threshold: Reconstruction error threshold. Default 0.5.
    """

    def __init__(
        self,
        in_features: int,
        latent_dim: int = 16,
        num_steps: int = 4,
        beta: float = 0.9,
        anomaly_threshold: float = 0.5,
    ):
        super().__init__()
        self.in_features = in_features
        self.num_steps = num_steps
        self.anomaly_threshold = anomaly_threshold

        # Spiking encoder
        self.encoder = nn.Sequential(
            SpikeLinear(in_features, 128, beta=beta),
            SpikeLinear(128, 64, beta=beta),
            SpikeLinear(64, latent_dim, beta=beta),
        )

        # Standard decoder (reconstructs continuous values)
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, in_features),
        )

    def forward(self, x: Tensor) -> dict:
        """Encode input, decode, compute anomaly score.

        Args:
            x: (batch, in_features) sensor reading.

        Returns:
            Dict with 'reconstruction', 'latent_spikes', 'anomaly_score', 'is_anomaly'.
        """
        self._reset_states()

        # Run through spiking encoder for T timesteps
        latent_spikes = []
        for _ in range(self.num_steps):
            z = self.encoder(x)
            latent_spikes.append(z)

        # Average spike rate as latent representation
        z_rate = torch.stack(latent_spikes, dim=0).mean(dim=0)

        # Decode
        reconstruction = self.decoder(z_rate)

        # Anomaly score = MSE reconstruction error
        anomaly_score = (x - reconstruction).pow(2).mean(dim=-1)
        is_anomaly = anomaly_score > self.anomaly_threshold

        return {
            "reconstruction": reconstruction,
            "latent_spikes": torch.stack(latent_spikes, dim=1),
            "anomaly_score": anomaly_score,
            "is_anomaly": is_anomaly,
        }

    def _reset_states(self):
        for m in self.modules():
            if hasattr(m, "reset_state"):
                m.reset_state()


class TemporalAnomalyDetector(nn.Module):
    """Temporal anomaly detection using spike timing patterns.

    NOVEL: Uses inter-spike interval (ISI) statistics to detect anomalies.
    Normal data produces regular spike patterns. Anomalies disrupt timing.

    Architecture:
        Input → SpikeRecurrent (temporal dynamics)
        → ISI computation (inter-spike intervals)
        → Statistical test on ISI distribution
        → Anomaly score

    This catches temporal anomalies that rate-coded DNNs miss.

    Args:
        in_features: Input dimension.
        hidden_dim: Recurrent hidden dimension. Default 64.
        beta: LIF decay. Default 0.9.
        window_size: ISI statistics window. Default 50.
    """

    def __init__(
        self,
        in_features: int,
        hidden_dim: int = 64,
        beta: float = 0.9,
        window_size: int = 50,
    ):
        super().__init__()
        self.window_size = window_size

        self.encoder = nn.Linear(in_features, hidden_dim)
        self.recurrent = SpikeRecurrent(hidden_dim, hidden_dim, beta=beta)
        self.readout = nn.Linear(hidden_dim, 1)

        # Running ISI statistics
        self.isi_mean: Optional[Tensor] = None
        self.isi_var: Optional[Tensor] = None
        self.spike_history: list[Tensor] = []
        self.isi_count: int = 0

    def forward(self, x: Tensor) -> dict:
        """Process one timestep of time series data.

        Args:
            x: (batch, in_features) sensor reading at time t.

        Returns:
            Dict with 'spikes', 'isi_anomaly_score', 'rate_anomaly_score',
            'combined_score', 'is_anomaly'.
        """
        # Encode and generate spikes
        h = self.encoder(x)
        spikes = self.recurrent(h)

        # Track spike history for ISI computation
        self.spike_history.append(spikes.detach())
        if len(self.spike_history) > self.window_size:
            self.spike_history.pop(0)

        # Compute ISI statistics
        isi_score = self._compute_isi_anomaly(spikes)

        # Rate-based anomaly: deviation from expected firing rate
        if len(self.spike_history) >= 10:
            history = torch.stack(self.spike_history, dim=0)
            current_rate = history[-10:].mean(dim=0)
            expected_rate = history.mean(dim=0)
            rate_score = (current_rate - expected_rate).abs().mean(dim=-1)
        else:
            rate_score = torch.zeros(x.shape[0], device=x.device)

        # Combined score
        combined = 0.6 * isi_score + 0.4 * rate_score

        return {
            "spikes": spikes,
            "isi_anomaly_score": isi_score,
            "rate_anomaly_score": rate_score,
            "combined_score": combined,
            "is_anomaly": combined > 0.5,
        }

    def _compute_isi_anomaly(self, current_spikes: Tensor) -> Tensor:
        """Compute anomaly score from inter-spike interval statistics."""
        if len(self.spike_history) < 3:
            return torch.zeros(current_spikes.shape[0], device=current_spikes.device)

        history = torch.stack(self.spike_history[-20:], dim=0)  # (T_hist, B, H)

        # Compute ISI: time between consecutive spikes per neuron
        # Approximate by counting zero-gaps between spikes
        spike_times = history.sum(dim=0)  # Total spikes per neuron per batch
        recent_rate = history[-5:].sum(dim=0)

        # If spike rate changed significantly, it's anomalous
        expected = spike_times / max(len(self.spike_history), 1)
        actual = recent_rate / 5.0
        deviation = (actual - expected).abs().mean(dim=-1)

        return deviation.clamp(0, 2.0) / 2.0  # Normalize to [0, 1]

    def reset_state(self) -> None:
        self.recurrent.reset_state()
        self.spike_history.clear()
        self.isi_mean = None
        self.isi_var = None
        self.isi_count = 0


class SpikeIsolationForest(nn.Module):
    """Neuromorphic isolation forest using random spike projections.

    Projects input through random spiking neurons. Anomalies produce
    unusual spike patterns that are "isolated" quickly (few projections
    needed to separate them from normal data).

    Args:
        in_features: Input dimension.
        num_projections: Number of random projections. Default 100.
        num_steps: Timesteps per projection. Default 4.
    """

    def __init__(
        self,
        in_features: int,
        num_projections: int = 100,
        num_steps: int = 4,
    ):
        super().__init__()
        self.num_projections = num_projections
        self.num_steps = num_steps

        # Random (frozen) projection weights
        self.projections = nn.Linear(in_features, num_projections, bias=False)
        self.projections.weight.requires_grad_(False)
        nn.init.normal_(self.projections.weight, std=1.0 / in_features ** 0.5)

        self.lif = LeakyIntegrateAndFire(beta=0.85, threshold=1.0)

        # Running statistics of normal spike patterns
        self.register_buffer("mean_pattern", torch.zeros(num_projections))
        self.register_buffer("var_pattern", torch.ones(num_projections))
        self.calibrated = False
        self._calibration_data: list[Tensor] = []

    def forward(self, x: Tensor) -> dict:
        """Score anomalies via spike pattern deviation.

        Args:
            x: (batch, in_features).

        Returns:
            Dict with 'spike_pattern', 'anomaly_score', 'is_anomaly'.
        """
        self.lif.reset_state()

        # Project and spike
        projected = self.projections(x)
        spike_counts = torch.zeros_like(projected)
        for _ in range(self.num_steps):
            spikes = self.lif(projected)
            spike_counts = spike_counts + spikes

        pattern = spike_counts / self.num_steps  # Spike rate per projection

        if self.calibrated:
            z_scores = (pattern - self.mean_pattern) / (self.var_pattern.sqrt() + 1e-6)
            anomaly_score = z_scores.abs().mean(dim=-1)
        else:
            self._calibration_data.append(pattern.detach())
            anomaly_score = torch.zeros(x.shape[0], device=x.device)

        return {
            "spike_pattern": pattern,
            "anomaly_score": anomaly_score,
            "is_anomaly": anomaly_score > 2.0,  # 2σ threshold
        }

    def calibrate(self) -> None:
        """Calibrate normal statistics from collected data."""
        if not self._calibration_data:
            return
        data = torch.cat(self._calibration_data, dim=0)
        self.mean_pattern.copy_(data.mean(dim=0))
        self.var_pattern.copy_(data.var(dim=0))
        self.calibrated = True
        self._calibration_data.clear()
