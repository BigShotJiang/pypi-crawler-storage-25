"""NeuromorphicRT model architectures: vision, audio, anomaly, fusion, TENN+TTFS."""

from neuromorphic_rt.models.vision import SpikeNet7, SpikeResNet, SpikeYOLO
from neuromorphic_rt.models.audio import SpikeKWS, SpikeVAD
from neuromorphic_rt.models.anomaly import SpikeAutoencoder, TemporalAnomalyDetector
from neuromorphic_rt.models.fusion import UniversalSensorAgent
from neuromorphic_rt.models.tenn_vision import TENNNet7, TENNResNet
from neuromorphic_rt.models.tenn_audio import TENNKWS

MODEL_REGISTRY = {
    # Rate-coded models (LIF neurons)
    "spike-net7": SpikeNet7,
    "spike-resnet": SpikeResNet,
    "spike-yolo": SpikeYOLO,
    "spike-kws": SpikeKWS,
    "spike-vad": SpikeVAD,
    "spike-autoencoder": SpikeAutoencoder,
    "temporal-anomaly": TemporalAnomalyDetector,
    "universal-sensor": UniversalSensorAgent,
    # TENN+TTFS models (temporal event + time-to-first-spike)
    "tenn-net7": TENNNet7,
    "tenn-resnet": TENNResNet,
    "tenn-kws": TENNKWS,
}


def get_model(name: str, **kwargs):
    """Factory: get model by name."""
    if name not in MODEL_REGISTRY:
        raise ValueError(f"Unknown model: {name}. Available: {list(MODEL_REGISTRY.keys())}")
    return MODEL_REGISTRY[name](**kwargs)
