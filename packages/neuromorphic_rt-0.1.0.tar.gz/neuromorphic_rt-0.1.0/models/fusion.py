"""
Universal Sensor Agent — THE PRODUCT.

Multi-modal spike fusion: takes N heterogeneous sensor streams, encodes
each into spike trains, fuses via cross-modal spike attention, and
outputs unified perception.

This is what no one else has: a single spiking model that simultaneously
processes vision, audio, IMU, temperature, humidity, pressure, light, IR,
and network traffic in a unified temporal spike representation — the way
the human brain fuses vision, hearing, and touch into a single percept.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor
from typing import Dict, List, Optional

from neuromorphic_rt.core.layers import (
    SpikeConv2d,
    SpikeConv1d,
    SpikeLinear,
    SpikeRecurrent,
    SpikePooling,
)
from neuromorphic_rt.core.attention import SpikeLinearAttention
from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire


class ModalityEncoder(nn.Module):
    """Encode a single sensor modality into a fixed-size spike vector."""

    def __init__(self, modality: str, output_dim: int = 128, beta: float = 0.9):
        super().__init__()
        self.modality = modality
        self.output_dim = output_dim

        if modality == "vision":
            self.encoder = nn.Sequential(
                SpikeConv2d(3, 32, 3, stride=2, padding=1, beta=beta),
                SpikeConv2d(32, 64, 3, stride=2, padding=1, beta=beta),
                SpikeConv2d(64, 128, 3, stride=2, padding=1, beta=beta),
            )
            self.pool = nn.AdaptiveAvgPool2d(1)
            self.proj = SpikeLinear(128, output_dim, beta=beta)

        elif modality == "audio":
            self.encoder = nn.Sequential(
                SpikeConv1d(40, 64, 5, stride=1, padding=2, beta=beta),
                SpikeConv1d(64, 128, 3, stride=2, padding=1, beta=beta),
            )
            self.proj = SpikeLinear(128, output_dim, beta=beta)

        elif modality == "imu":
            self.encoder = SpikeRecurrent(6, 64, beta=beta)
            self.proj = SpikeLinear(64, output_dim, beta=beta)

        elif modality == "scalar":
            # Temperature, humidity, pressure, light, IR
            self.encoder = SpikeLinear(8, 64, beta=beta)
            self.proj = SpikeLinear(64, output_dim, beta=beta)

        elif modality == "network":
            # Packet rate, byte rate, unique IPs, protocol dist, etc.
            self.encoder = SpikeRecurrent(16, 64, beta=beta)
            self.proj = SpikeLinear(64, output_dim, beta=beta)

        else:
            raise ValueError(f"Unknown modality: {modality}")

    def forward(self, x: Tensor) -> Tensor:
        """Encode modality input to spike vector.

        Args:
            x: Modality-specific input tensor.

        Returns:
            (batch, output_dim) spike vector.
        """
        if self.modality == "vision":
            h = self.encoder(x)
            h = self.pool(h).squeeze(-1).squeeze(-1)
            return self.proj(h)
        elif self.modality == "audio":
            h = self.encoder(x.transpose(1, 2) if x.dim() == 2 else x)
            h = h.mean(dim=-1)
            return self.proj(h)
        else:
            h = self.encoder(x)
            return self.proj(h)

    def reset_state(self):
        for m in self.modules():
            if hasattr(m, "reset_state") and m is not self:
                m.reset_state()


class UniversalSensorAgent(nn.Module):
    """The core product: multi-modal spike fusion with cross-modal attention.

    Takes N heterogeneous sensor streams, encodes each into fixed-size
    spike vectors, fuses them via SpikeLinearAttention, and outputs
    anomaly scores, classifications, and predicted next states.

    Args:
        modalities: List of modality names. Default: all supported.
        embed_dim: Spike vector dimension per modality. Default 128.
        num_heads: Cross-modal attention heads. Default 4.
        num_classes: Classification output. Default 10.
        beta: LIF decay. Default 0.9.
    """

    SUPPORTED_MODALITIES = ["vision", "audio", "imu", "scalar", "network"]

    def __init__(
        self,
        modalities: Optional[List[str]] = None,
        embed_dim: int = 128,
        num_heads: int = 4,
        num_classes: int = 10,
        beta: float = 0.9,
    ):
        super().__init__()
        if modalities is None:
            modalities = self.SUPPORTED_MODALITIES

        self.modalities = modalities
        self.embed_dim = embed_dim

        # Per-modality encoders
        self.encoders = nn.ModuleDict({
            mod: ModalityEncoder(mod, output_dim=embed_dim, beta=beta)
            for mod in modalities
        })

        # Cross-modal spike attention: attend across modalities
        self.cross_attention = SpikeLinearAttention(
            embed_dim=embed_dim,
            num_heads=num_heads,
            beta=0.85,
            threshold=0.5,
        )

        # Modality position embeddings
        self.modality_embeddings = nn.Embedding(len(modalities), embed_dim)

        # Output heads
        self.anomaly_head = nn.Sequential(
            SpikeLinear(embed_dim, 64, beta=beta),
            nn.Linear(64, 1),
            nn.Sigmoid(),
        )

        self.classification_head = nn.Sequential(
            SpikeLinear(embed_dim, 64, beta=beta),
            nn.Linear(64, num_classes),
        )

        self.prediction_head = nn.Sequential(
            SpikeLinear(embed_dim, 64, beta=beta),
            nn.Linear(64, embed_dim),
        )

        self.pool = SpikePooling(mode="rate")

    def forward(
        self,
        inputs: Dict[str, Tensor],
        num_steps: int = 4,
    ) -> Dict[str, Tensor]:
        """Process multi-modal inputs through spike fusion.

        Args:
            inputs: Dict mapping modality name → input tensor.
                    Only active modalities need to be provided.
            num_steps: Timesteps for temporal integration. Default 4.

        Returns:
            Dict with:
            - 'anomaly_score': (batch, 1) per-sample anomaly probability
            - 'classification': (batch, num_classes) class logits
            - 'predicted_next': (batch, embed_dim) predicted next state
            - 'modality_spikes': Dict[str, Tensor] per-modality spike rates
            - 'fusion_spikes': (batch, embed_dim) fused representation
        """
        self._reset_states()

        batch_size = next(iter(inputs.values())).shape[0]
        device = next(iter(inputs.values())).device

        all_step_outputs = []

        for step in range(num_steps):
            # Encode each modality
            modality_vectors = []
            modality_names = []

            for i, mod in enumerate(self.modalities):
                if mod in inputs:
                    vec = self.encoders[mod](inputs[mod])
                    # Add modality position embedding
                    pos = self.modality_embeddings(
                        torch.tensor(i, device=device)
                    )
                    vec = vec + pos
                    modality_vectors.append(vec)
                    modality_names.append(mod)

            if not modality_vectors:
                continue

            # Stack modality vectors as sequence for cross-attention
            # (batch, num_modalities, embed_dim)
            modal_seq = torch.stack(modality_vectors, dim=1)

            # Cross-modal spike attention
            fused = self.cross_attention(modal_seq)  # (batch, num_mod, embed_dim)

            # Pool across modalities
            fused_pooled = fused.mean(dim=1)  # (batch, embed_dim)
            all_step_outputs.append(fused_pooled)

        # Temporal pooling across timesteps
        if not all_step_outputs:
            zeros = torch.zeros(batch_size, self.embed_dim, device=device)
            return {
                "anomaly_score": torch.zeros(batch_size, 1, device=device),
                "classification": torch.zeros(batch_size, 10, device=device),
                "predicted_next": zeros,
                "fusion_spikes": zeros,
            }

        temporal_stack = torch.stack(all_step_outputs, dim=1)  # (B, T, embed)
        fused_final = self.pool(temporal_stack)  # (B, embed)

        # Output heads
        anomaly = self.anomaly_head(fused_final)
        classification = self.classification_head(fused_final)
        predicted = self.prediction_head(fused_final)

        return {
            "anomaly_score": anomaly,
            "classification": classification,
            "predicted_next": predicted,
            "fusion_spikes": fused_final,
        }

    def get_spike_rates(self) -> Dict[str, float]:
        """Return per-modality spike rates for energy estimation."""
        rates = {}
        for mod, encoder in self.encoders.items():
            # Approximate: count LIF neurons and their recent spike rates
            total_spikes = 0
            total_neurons = 0
            for m in encoder.modules():
                if isinstance(m, LeakyIntegrateAndFire) and m.membrane is not None:
                    total_neurons += m.membrane.numel()
                    # Rough estimate from membrane potential vs threshold
                    above = (m.membrane > m.threshold * 0.5).sum().item()
                    total_spikes += above
            rates[mod] = total_spikes / max(total_neurons, 1)
        return rates

    def _reset_states(self):
        for m in self.modules():
            if hasattr(m, "reset_state") and m is not self:
                m.reset_state()
