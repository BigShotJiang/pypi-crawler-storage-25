"""
Spike-coded vision models for image classification and object detection.

All models accept spike-encoded inputs (binary tensors with time dimension)
and process them through spiking convolutional architectures.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor
from typing import List, Optional

from neuromorphic_rt.core.layers import SpikeConv2d, SpikeLinear, SpikePooling
from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire
from neuromorphic_rt.core.encoding import rate_encode


class SpikeNet7(nn.Module):
    """Lightweight 7-layer spiking CNN for image classification.

    Architecture:
        3x SpikeConv2d blocks (32→64→128, 3x3, stride-2)
        → Global average pool
        → 2x SpikeLinear (256→num_classes)

    Designed for CIFAR-10/100 level tasks with minimal energy.

    Args:
        in_channels: Input channels (3 for RGB). Default 3.
        num_classes: Output classes. Default 10.
        num_steps: Simulation timesteps. Default 4.
        beta: LIF decay. Default 0.9.
    """

    def __init__(
        self,
        in_channels: int = 3,
        num_classes: int = 10,
        num_steps: int = 4,
        beta: float = 0.9,
    ):
        super().__init__()
        self.num_steps = num_steps

        self.features = nn.Sequential(
            SpikeConv2d(in_channels, 32, 3, stride=2, padding=1, beta=beta),
            SpikeConv2d(32, 64, 3, stride=2, padding=1, beta=beta),
            SpikeConv2d(64, 128, 3, stride=2, padding=1, beta=beta),
        )

        self.classifier = nn.Sequential(
            SpikeLinear(128, 256, beta=beta),
            SpikeLinear(256, num_classes, beta=beta),
        )

        self.pool = SpikePooling(mode="rate")

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass over spike-encoded image sequence.

        Args:
            x: (batch, T, C, H, W) spike-encoded images,
               or (batch, C, H, W) float images (auto-encoded).

        Returns:
            (batch, num_classes) output logits.
        """
        if x.dim() == 4:
            x = rate_encode(x, self.num_steps)

        B, T = x.shape[0], x.shape[1]
        self._reset_states()

        spike_outputs = []
        for t in range(T):
            h = self.features(x[:, t])
            h = h.mean(dim=[-2, -1])  # Global average pool
            h = self.classifier(h)
            spike_outputs.append(h)

        spike_train = torch.stack(spike_outputs, dim=1)
        return self.pool(spike_train)

    def _reset_states(self):
        for m in self.modules():
            if hasattr(m, "reset_state"):
                m.reset_state()


class SpikeResNet(nn.Module):
    """ResNet-18 with all ReLU replaced by LIF neurons.

    Skip connections preserved, BatchNorm replaced with compatible version.
    The key insight: residual connections help gradient flow through
    surrogate gradients, making deep spiking networks trainable.

    Args:
        in_channels: Input channels. Default 3.
        num_classes: Output classes. Default 10.
        num_steps: Timesteps. Default 4.
        beta: LIF decay. Default 0.9.
    """

    def __init__(
        self,
        in_channels: int = 3,
        num_classes: int = 10,
        num_steps: int = 4,
        beta: float = 0.9,
    ):
        super().__init__()
        self.num_steps = num_steps

        self.stem = nn.Sequential(
            nn.Conv2d(in_channels, 64, 3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(64),
        )
        self.stem_lif = LeakyIntegrateAndFire(beta=beta)

        self.layer1 = self._make_layer(64, 64, 2, stride=1, beta=beta)
        self.layer2 = self._make_layer(64, 128, 2, stride=2, beta=beta)
        self.layer3 = self._make_layer(128, 256, 2, stride=2, beta=beta)
        self.layer4 = self._make_layer(256, 512, 2, stride=2, beta=beta)

        self.classifier = SpikeLinear(512, num_classes, beta=beta)
        self.pool = SpikePooling(mode="rate")

    def _make_layer(self, in_ch: int, out_ch: int, blocks: int, stride: int, beta: float):
        layers = [_SpikeResBlock(in_ch, out_ch, stride, beta)]
        for _ in range(1, blocks):
            layers.append(_SpikeResBlock(out_ch, out_ch, 1, beta))
        return nn.Sequential(*layers)

    def forward(self, x: Tensor) -> Tensor:
        if x.dim() == 4:
            x = rate_encode(x, self.num_steps)

        B, T = x.shape[0], x.shape[1]
        self._reset_states()

        outputs = []
        for t in range(T):
            h = self.stem_lif(self.stem(x[:, t]))
            h = self.layer1(h)
            h = self.layer2(h)
            h = self.layer3(h)
            h = self.layer4(h)
            h = h.mean(dim=[-2, -1])
            h = self.classifier(h)
            outputs.append(h)

        return self.pool(torch.stack(outputs, dim=1))

    def _reset_states(self):
        for m in self.modules():
            if hasattr(m, "reset_state"):
                m.reset_state()


class _SpikeResBlock(nn.Module):
    """Residual block with LIF neurons."""

    def __init__(self, in_ch: int, out_ch: int, stride: int = 1, beta: float = 0.9):
        super().__init__()
        self.conv1 = nn.Conv2d(in_ch, out_ch, 3, stride, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_ch)
        self.lif1 = LeakyIntegrateAndFire(beta=beta)

        self.conv2 = nn.Conv2d(out_ch, out_ch, 3, 1, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_ch)
        self.lif2 = LeakyIntegrateAndFire(beta=beta)

        self.shortcut = nn.Identity()
        if stride != 1 or in_ch != out_ch:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 1, stride, bias=False),
                nn.BatchNorm2d(out_ch),
            )

    def forward(self, x: Tensor) -> Tensor:
        identity = self.shortcut(x)
        out = self.lif1(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out = self.lif2(out + identity)
        return out

    def reset_state(self):
        self.lif1.reset_state()
        self.lif2.reset_state()


class SpikeYOLO(nn.Module):
    """Spiking object detection based on YOLOv8-nano architecture.

    LIF neurons replace all activations. Temporal integration over T
    timesteps provides detection stability.

    Args:
        num_classes: Number of object classes. Default 80.
        num_steps: Timesteps. Default 4.
        beta: LIF decay. Default 0.9.
    """

    def __init__(
        self,
        num_classes: int = 80,
        num_steps: int = 4,
        beta: float = 0.9,
    ):
        super().__init__()
        self.num_steps = num_steps
        self.num_classes = num_classes

        # Backbone (CSPDarknet-like with spike neurons)
        self.backbone = nn.ModuleList([
            SpikeConv2d(3, 16, 3, stride=2, padding=1, beta=beta),
            SpikeConv2d(16, 32, 3, stride=2, padding=1, beta=beta),
            SpikeConv2d(32, 64, 3, stride=2, padding=1, beta=beta),
            SpikeConv2d(64, 128, 3, stride=2, padding=1, beta=beta),
            SpikeConv2d(128, 256, 3, stride=2, padding=1, beta=beta),
        ])

        # Detection head
        self.detect = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(256, 128),
        )
        self.detect_lif = LeakyIntegrateAndFire(beta=beta)

        # Output: bbox (4) + objectness (1) + classes
        self.head = nn.Linear(128, 5 + num_classes)

        self.pool = SpikePooling(mode="rate")

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass.

        Args:
            x: (batch, T, 3, H, W) or (batch, 3, H, W).

        Returns:
            (batch, 5 + num_classes) detection output.
        """
        if x.dim() == 4:
            x = rate_encode(x, self.num_steps)

        B, T = x.shape[0], x.shape[1]
        self._reset_states()

        outputs = []
        for t in range(T):
            h = x[:, t]
            for layer in self.backbone:
                h = layer(h)
            h = self.detect(h)
            h = self.detect_lif(h)
            outputs.append(h)

        # Average spike output over time
        pooled = self.pool(torch.stack(outputs, dim=1))
        return self.head(pooled)

    def _reset_states(self):
        for m in self.modules():
            if hasattr(m, "reset_state"):
                m.reset_state()
