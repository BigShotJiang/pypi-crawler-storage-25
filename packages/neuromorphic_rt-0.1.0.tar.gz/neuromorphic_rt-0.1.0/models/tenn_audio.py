"""
TENN+TTFS audio models — temporal event processing for audio.

Audio is inherently temporal, making TENN's temporal kernels a natural fit.
TTFS provides early-exit capability: classify as soon as the output neuron fires.

For keyword spotting, this means:
- "Hey Siri" detected in ~2-3 timesteps instead of waiting for all T=8
- Energy proportional to decision time, not fixed T
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor

from neuromorphic_rt.core.layers import TTFSLinear, SpikeConv1d
from neuromorphic_rt.core.neurons import TTFSNeuron
from neuromorphic_rt.core.tenn import TENNEncoder
from neuromorphic_rt.core.encoding import delta_encode


class TENNKWS(nn.Module):
    """TENN+TTFS Keyword Spotting model.

    Uses TENN temporal kernels over mel-spectrogram deltas for
    superior temporal pattern recognition. TTFS output enables
    early-exit classification.

    Architecture:
        Mel-spec → delta_encode → SpikeConv1d spatial features
        → TENN temporal encoder → TTFS classifier

    Energy advantage over SpikeKWS:
        SpikeKWS: ~0.037 mJ (rate coding, all T steps)
        TENNKWS:  ~0.006 mJ (TTFS, can exit early)

    Args:
        num_classes: Number of keywords. Default 12.
        mel_bins: Mel frequency bins. Default 40.
        embed_dim: TENN embedding dimension. Default 128.
        num_steps: Max timesteps. Default 8.
        tenn_layers: TENN encoder layers. Default 2.
        beta: Neuron decay. Default 0.9.
        delta_threshold: Delta encoding threshold. Default 0.05.
    """

    def __init__(
        self,
        num_classes: int = 12,
        mel_bins: int = 40,
        embed_dim: int = 128,
        num_steps: int = 8,
        tenn_layers: int = 2,
        beta: float = 0.9,
        delta_threshold: float = 0.05,
    ):
        super().__init__()
        self.delta_threshold = delta_threshold
        self.num_steps = num_steps

        # Spatial feature extraction from mel bins
        self.spatial = nn.Sequential(
            SpikeConv1d(mel_bins, 64, kernel_size=5, stride=1, padding=2, beta=beta),
            SpikeConv1d(64, embed_dim, kernel_size=3, stride=1, padding=1, beta=beta),
        )

        # TENN temporal encoder
        self.tenn = TENNEncoder(
            d_model=embed_dim,
            num_layers=tenn_layers,
            kernel_duration=min(num_steps, 8),
            num_heads=4,
            beta=beta,
            use_ttfs=True,
        )

        # TTFS classifier
        self.classifier = TTFSLinear(
            embed_dim, num_classes,
            beta=beta, max_timesteps=num_steps,
        )

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass.

        Args:
            x: (batch, mel_bins, T_audio) mel-spectrogram.

        Returns:
            (batch, num_classes) TTFS-decoded output.
        """
        # Transpose for delta encoding: (B, T, mel)
        x_t = x.transpose(1, 2)
        spikes = delta_encode(x_t, self.delta_threshold)

        B, T_audio, M = spikes.shape
        self._reset_states()

        # Process in chunks to create num_steps temporal windows
        chunk_size = max(1, T_audio // self.num_steps)
        temporal_features = []

        for step in range(self.num_steps):
            start = step * chunk_size
            end = min(start + chunk_size, T_audio)
            if start >= T_audio:
                break

            # Average the chunk's spike frames
            chunk = spikes[:, start:end].mean(dim=1)  # (B, mel_bins)
            h = chunk.unsqueeze(-1)  # (B, mel_bins, 1) for Conv1d
            h = self.spatial(h)
            h = h.squeeze(-1)  # (B, embed_dim)
            temporal_features.append(h)

        if not temporal_features:
            return torch.zeros(B, self.classifier.linear.out_features, device=x.device)

        # Stack temporal features: (B, num_steps, embed_dim)
        temporal_seq = torch.stack(temporal_features, dim=1)

        # TENN temporal processing
        tenn_out = self.tenn(temporal_seq)

        # TTFS classification
        self.classifier.reset_state()
        for t in range(tenn_out.shape[1]):
            self.classifier(tenn_out[:, t])

        return self.classifier.decode()

    def _reset_states(self):
        for m in self.modules():
            if hasattr(m, "reset_state"):
                m.reset_state()

    @property
    def total_spikes(self) -> int:
        count = 0
        for m in self.modules():
            if isinstance(m, TTFSNeuron):
                count += m.total_spikes
        return count
