"""
Spike-coded audio models for keyword spotting and voice activity detection.

Designed for always-on, sub-milliwatt audio processing on edge devices.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor

from neuromorphic_rt.core.layers import SpikeConv1d, SpikeLinear, SpikePooling
from neuromorphic_rt.core.neurons import LeakyIntegrateAndFire
from neuromorphic_rt.core.encoding import delta_encode


class SpikeKWS(nn.Module):
    """Spiking Keyword Spotting model.

    Processes mel-spectrogram through delta encoding (spike on spectral change)
    then 3-layer spiking Conv1d for temporal pattern recognition.

    Designed for "Hey Siri" style always-on detection at <1mW.

    Architecture:
        Mel-spectrogram → delta_encode → 3x SpikeConv1d (64→128→256)
        → temporal pooling → SpikeLinear → 12 keyword classes

    Args:
        num_classes: Number of keywords. Default 12 (Google Speech Commands).
        mel_bins: Mel-spectrogram frequency bins. Default 40.
        num_steps: Not used (delta encoding is data-driven). Kept for API compat.
        beta: LIF decay. Default 0.9.
        delta_threshold: Delta encoding threshold. Default 0.05.
    """

    def __init__(
        self,
        num_classes: int = 12,
        mel_bins: int = 40,
        beta: float = 0.9,
        delta_threshold: float = 0.05,
    ):
        super().__init__()
        self.delta_threshold = delta_threshold

        self.features = nn.Sequential(
            SpikeConv1d(mel_bins, 64, kernel_size=5, stride=1, padding=2, beta=beta),
            SpikeConv1d(64, 128, kernel_size=5, stride=2, padding=2, beta=beta),
            SpikeConv1d(128, 256, kernel_size=3, stride=2, padding=1, beta=beta),
        )

        self.classifier = nn.Sequential(
            SpikeLinear(256, 128, beta=beta),
            SpikeLinear(128, num_classes, beta=beta),
        )

        self.pool = SpikePooling(mode="rate")

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass.

        Args:
            x: (batch, mel_bins, T) mel-spectrogram. Standard Conv1d format.

        Returns:
            (batch, num_classes) keyword probabilities.
        """
        # Transpose to (B, T, mel_bins) for delta encoding
        x_t = x.transpose(1, 2)
        spikes = delta_encode(x_t, self.delta_threshold)  # (B, T, mel_bins)

        B, T, M = spikes.shape
        self._reset_states()

        outputs = []
        for t in range(T):
            # Each timestep: (B, mel_bins) → features expect (B, C, L)
            h = spikes[:, t].unsqueeze(-1)  # (B, mel_bins, 1)
            h = self.features(h)            # (B, 256, 1)
            h = h.squeeze(-1)               # (B, 256)
            h = self.classifier(h)
            outputs.append(h)

        return self.pool(torch.stack(outputs, dim=1))

    def _reset_states(self):
        for m in self.modules():
            if hasattr(m, "reset_state"):
                m.reset_state()


class SpikeVAD(nn.Module):
    """Spiking Voice Activity Detection.

    Ultra-lightweight binary classifier: speech vs. silence.
    Runs at <0.1mW — designed to gate the more expensive KWS model.

    Args:
        mel_bins: Mel-spectrogram bins. Default 40.
        beta: LIF decay. Default 0.85 (faster response than KWS).
    """

    def __init__(self, mel_bins: int = 40, beta: float = 0.85):
        super().__init__()
        self.encoder = nn.Linear(mel_bins, 32)
        self.lif1 = LeakyIntegrateAndFire(beta=beta, threshold=0.8)
        self.classifier = nn.Linear(32, 1)
        self.lif_out = LeakyIntegrateAndFire(beta=0.95, threshold=0.5)
        self.delta_threshold = 0.02

    def forward(self, x: Tensor) -> Tensor:
        """Detect voice activity.

        Args:
            x: (batch, mel_bins, T) mel-spectrogram.

        Returns:
            (batch, 1) voice activity probability.
        """
        x_t = x.transpose(1, 2)
        spikes = delta_encode(x_t, self.delta_threshold)

        B, T, M = spikes.shape
        self.lif1.reset_state()
        self.lif_out.reset_state()

        outputs = []
        for t in range(T):
            h = self.lif1(self.encoder(spikes[:, t]))
            h = self.lif_out(self.classifier(h))
            outputs.append(h)

        return torch.stack(outputs, dim=1).mean(dim=1)

    def _reset_states(self):
        self.lif1.reset_state()
        self.lif_out.reset_state()
