"""日志系统的核心入口。

本模块负责：

- 维护一个 ``patch`` 过默认 ``extra`` 字段的 Loguru logger 实例。
- 提供幂等的 :func:`configure_logging` 初始化函数，统一控制台、文件
  sink 与 stdlib 桥接。
- 提供 :func:`get_logger` 用于按业务名称取得带绑定的 logger。
- 提供 :func:`reset_logging_for_tests` 在测试或运行时重置全部状态。
"""

from __future__ import annotations

import logging
import sys
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from loguru import logger as _base_logger

from iboxpay_xlog.config import LoggingSettings, LogSink
from iboxpay_xlog.intercept import INTERCEPT_HANDLER_TAG, InterceptHandler

_CONFIG_LOCK = threading.Lock()
_CURRENT_SETTINGS: LoggingSettings | None = None


def _make_record_patcher(settings: LoggingSettings) -> Callable[[dict[str, Any]], None]:
    """构造 Loguru 的 ``patch`` 回调，为每条记录补默认 extra。

    Args:
        settings: 当前生效的日志配置。

    Returns:
        Callable[[dict[str, Any]], None]: 直接传给 ``loguru.logger.patch``
        的回调函数，会就地修改 ``record['extra']``。
    """

    defaults = dict(settings.extra_default_fields)

    def _patch(record: dict[str, Any]) -> None:
        extra = record["extra"]
        extra.setdefault("name", record["name"])
        for key, value in defaults.items():
            extra.setdefault(key, value)

    return _patch


logger: Any = _base_logger.patch(_make_record_patcher(LoggingSettings()))


def _resolve_named_log_paths(settings: LoggingSettings) -> dict[str, Path]:
    """计算每个 sink 对应的日志文件路径。

    Args:
        settings: 当前生效的日志配置。

    Returns:
        dict[str, Path]: ``{sink.name: <base_dir>/<sink.name>/<sink.name>.log}``。
    """

    base_dir = settings.resolved_log_base_dir()
    return {sink.name: base_dir / sink.name / f"{sink.name}.log" for sink in settings.resolved_sinks()}


def _prepare_log_directories(settings: LoggingSettings) -> dict[str, Path] | None:
    """确保日志文件所在目录存在并可写。

    若任意一个目录无法创建或文件无法 touch，会向 stderr 打印告警并返回
    ``None``，由调用方退化为仅 stdout 输出。

    Args:
        settings: 当前生效的日志配置。

    Returns:
        dict[str, Path] | None: 成功时返回 sink 名称到文件路径的映射；
        失败时返回 ``None``。
    """

    paths = _resolve_named_log_paths(settings)
    try:
        for path in paths.values():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.touch(exist_ok=True)
    except OSError as exc:
        sys.stderr.write(
            f"iboxpay-xlog: cannot create log files under "
            f"{settings.resolved_log_base_dir()!s} ({exc!s}). "
            f"Logging to stdout only; fix directory permissions or set "
            f"{settings.resolved_log_base_dir_env()} to a writable path.\n"
        )
        return None
    return paths


def _make_rotation_callable(settings: LoggingSettings) -> Callable[[Any, Any], bool]:
    """构造 Loguru 的 ``rotation`` 回调。

    同时支持文件大小阈值与按小时切分两种策略；任意一种命中即触发滚动。

    Args:
        settings: 当前生效的日志配置。

    Returns:
        Callable[[Any, Any], bool]: 接受 Loguru 的 ``message`` 与 ``file``
        对象，返回是否需要滚动的布尔值。
    """

    max_bytes = settings.rotation_max_bytes
    rotate_hourly = settings.rotate_hourly

    def _should_rotate(message: Any, file: Any) -> bool:
        if max_bytes > 0 and file.tell() >= max_bytes:
            return True
        if not rotate_hourly:
            return False
        current_time = message.record["time"]
        file_path = Path(file.name)
        try:
            modified_time = datetime.fromtimestamp(file_path.stat().st_mtime, tz=current_time.tzinfo)
        except OSError:
            return False
        return (
            modified_time.year,
            modified_time.month,
            modified_time.day,
            modified_time.hour,
        ) != (
            current_time.year,
            current_time.month,
            current_time.day,
            current_time.hour,
        )

    return _should_rotate


def _make_sink_filter(sink: LogSink) -> Callable[[dict[str, Any]], bool] | None:
    """根据 sink 配置生成 Loguru ``filter`` 函数。

    Args:
        sink: 单个 sink 的配置。

    Returns:
        Callable | None: 若未配置 include / exclude 则返回 ``None``，让
        Loguru 不做额外过滤。
    """

    include = sink.include_logger_names
    exclude = sink.exclude_logger_names
    if include is None and exclude is None:
        return None

    def _filter(record: dict[str, Any]) -> bool:
        name = record["extra"].get("name", record["name"])
        if include is not None and name not in include:
            return False
        if exclude is not None and name in exclude:
            return False
        return True

    return _filter


def _bridge_stdlib_logging(settings: LoggingSettings, handler: InterceptHandler) -> None:
    """配置 stdlib ``logging`` 的处理器与级别，使其与 Loguru 一致。

    Args:
        settings: 当前生效的日志配置。
        handler: 已经构造好的 :class:`InterceptHandler` 实例。
    """

    root_logger = logging.getLogger()
    root_logger.handlers = [handler]
    root_logger.setLevel(logging.INFO)
    root_logger.propagate = False

    for logger_name, level_name in settings.silenced_loggers.items():
        logging.getLogger(logger_name).setLevel(level_name)

    for logger_name in settings.intercept_loggers:
        std_logger = logging.getLogger(logger_name)
        std_logger.handlers = [handler]
        std_logger.propagate = False

    for logger_name in settings.disabled_loggers:
        std_logger = logging.getLogger(logger_name)
        std_logger.handlers = []
        std_logger.propagate = False
        std_logger.disabled = True


def configure_logging(settings: LoggingSettings | None = None) -> LoggingSettings:
    """初始化整个日志系统，幂等可重复调用。

    第一次调用时按 ``settings`` 配置 Loguru sink 与 stdlib 桥接；后续
    调用若已经初始化过会直接返回已生效的配置，**不会** 重复添加 sink。
    需要重新配置时请先调用 :func:`reset_logging_for_tests`。

    Args:
        settings: 可选的日志配置；为 ``None`` 时使用默认 :class:`LoggingSettings`。

    Returns:
        LoggingSettings: 实际生效的配置实例，便于调用方留存或断言。
    """

    global _CURRENT_SETTINGS, logger
    with _CONFIG_LOCK:
        if _CURRENT_SETTINGS is not None:
            return _CURRENT_SETTINGS

        effective = settings or LoggingSettings()
        logger = _base_logger.patch(_make_record_patcher(effective))

        _base_logger.remove()
        _base_logger.add(
            sys.stdout,
            level=effective.console_level,
            backtrace=effective.backtrace,
            diagnose=effective.diagnose,
            format=effective.log_format,
        )

        paths = _prepare_log_directories(effective) if effective.enable_file_logging else None
        if paths is not None:
            rotation = _make_rotation_callable(effective)
            sinks_by_name = {sink.name: sink for sink in effective.resolved_sinks()}
            for sink_name, path in paths.items():
                sink = sinks_by_name[sink_name]
                _base_logger.add(
                    path,
                    level=sink.level,
                    backtrace=effective.backtrace,
                    diagnose=effective.diagnose,
                    encoding="utf-8",
                    format=effective.log_format,
                    rotation=rotation,
                    filter=_make_sink_filter(sink),
                )

        if effective.intercept_stdlib:
            handler = InterceptHandler(logger)
            _bridge_stdlib_logging(effective, handler)

        _CURRENT_SETTINGS = effective
        return effective


def get_logger(name: str) -> Any:
    """获取一个绑定了业务名称的 Loguru logger。

    若 :func:`configure_logging` 尚未调用，会以默认配置自动初始化，
    避免业务代码忘记初始化时静默丢失日志。

    Args:
        name: 业务 logger 名称，会写入 ``record.extra['name']``。
            建议使用模块路径（``__name__``）或语义化标签（如 ``"remote"``、
            ``"app.request"``、``"interface"``、``"access"``）。

    Returns:
        Any: 已绑定 ``name`` 的 Loguru logger，可继续 ``bind`` 其他字段。
    """

    if _CURRENT_SETTINGS is None:
        configure_logging()
    return logger.bind(name=name)


def reset_logging_for_tests() -> None:
    """清空所有 sink 与初始化标记，常用于单元测试或运行时重置。

    调用后下一次 :func:`configure_logging` / :func:`get_logger` 会重新
    走完整的初始化流程。同时会移除 stdlib root logger 上由本框架安装的
    :class:`InterceptHandler`，避免测试用例之间互相污染。
    """

    global _CURRENT_SETTINGS
    with _CONFIG_LOCK:
        _base_logger.remove()
        root_logger = logging.getLogger()
        root_logger.handlers = [
            handler
            for handler in root_logger.handlers
            if not getattr(handler, INTERCEPT_HANDLER_TAG, False)
        ]
        _CURRENT_SETTINGS = None


def current_settings() -> LoggingSettings | None:
    """返回当前生效的日志配置。

    Returns:
        LoggingSettings | None: 已初始化时返回配置实例；未初始化时返回 ``None``。
    """

    return _CURRENT_SETTINGS
