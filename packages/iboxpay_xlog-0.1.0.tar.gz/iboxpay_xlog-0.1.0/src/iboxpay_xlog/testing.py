"""测试辅助工具。

提供一个上下文管理器 :func:`capture_records`，可以在单元测试中收集
Loguru 输出的原始 ``record`` 字典，方便对日志内容、``extra`` 字段和
级别做断言。
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterator

from loguru import logger as _base_logger


@contextmanager
def capture_records(level: str = "INFO") -> Iterator[list[dict[str, Any]]]:
    """临时挂一个内存 sink，收集进入 Loguru 的所有 record。

    退出上下文时自动移除 sink，不影响其他测试或正常输出。

    Args:
        level: 收集的最小级别，默认 ``"INFO"``。

    Yields:
        list[dict[str, Any]]: 用例内部可直接读写的列表；每条 ``record``
            包含 ``message``、``level``、``extra`` 等字段。

    Examples:
        >>> from iboxpay_xlog import configure_logging, get_logger
        >>> from iboxpay_xlog.testing import capture_records
        >>> configure_logging()
        >>> with capture_records() as records:
        ...     get_logger("demo").info("hello")
        >>> records[-1]["message"]
        'hello'
    """

    records: list[dict[str, Any]] = []
    sink_id = _base_logger.add(lambda message: records.append(message.record), level=level)
    try:
        yield records
    finally:
        # 当上下文内部调用 configure_logging 等会清空 sink 的逻辑时，
        # 对应 sink_id 已被移除，这里吞掉 ValueError 以避免污染用例栈。
        try:
            _base_logger.remove(sink_id)
        except ValueError:
            pass
