"""敏感信息脱敏工具。

提供 :func:`redact_log_text` / :func:`redact_log_value` 两个公共入口，
分别处理纯文本与任意嵌套结构（dict / list / tuple / 字符串）。

脱敏规则与 iboxpay 后端统一约定：

- **身份证**：保留前 6 位与后 4 位，中间用 ``*`` 代替。
- **银行卡**：12~19 位连续数字，按身份证规则脱敏。
- **大陆手机号**：11 位以 ``1`` 开头且第二位为 ``3-9``，或带 ``86``
  前缀的 13 位号码，**不**脱敏，避免与银行卡误判。
"""

from __future__ import annotations

import re
from typing import Any

BANK_CARD_PATTERN = re.compile(r"(?<!\d)(\d{12,19})(?!\d)")
ID_CARD_PATTERN = re.compile(r"(?<![\dXx])(\d{17}[\dXx]|\d{15})(?![\dXx])")


def redact_log_value(value: Any) -> Any:
    """对任意类型的日志值进行脱敏。

    递归处理 ``dict`` / ``list`` / ``tuple`` 容器，对其中的字符串
    应用 :func:`redact_log_text`；其他标量类型原样返回。

    Args:
        value: 任意待写入日志的值。

    Returns:
        Any: 与输入同类型的脱敏后副本，原值不会被原地修改。
    """

    if isinstance(value, dict):
        return {key: redact_log_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [redact_log_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(redact_log_value(item) for item in value)
    if isinstance(value, str):
        return redact_log_text(value)
    return value


def redact_log_text(text: str) -> str:
    """对单段文本中的身份证、银行卡进行脱敏。

    Args:
        text: 原始文本。

    Returns:
        str: 脱敏后的文本，未命中规则的字符保持不变。
    """

    masked = ID_CARD_PATTERN.sub(lambda match: _mask_id_card(match.group(1)), text)
    masked = BANK_CARD_PATTERN.sub(
        lambda match: _mask_bank_card_or_keep_phone(match.group(1)), masked
    )
    return masked


def _mask_bank_card_or_keep_phone(value: str) -> str:
    """银行卡正则命中后的二次判定，避开手机号误伤。

    Args:
        value: 正则命中的连续数字串。

    Returns:
        str: 命中大陆手机号则原样返回，否则按银行卡规则脱敏。
    """

    if _looks_like_mainland_phone(value):
        return value
    return _mask_bank_card(value)


def _looks_like_mainland_phone(value: str) -> bool:
    """判断给定数字串是否符合大陆手机号规则。

    Args:
        value: 仅由数字组成的字符串。

    Returns:
        bool: 11 位且以 ``1[3-9]`` 开头，或 13 位以 ``861[3-9]`` 开头时为 ``True``。
    """

    if len(value) == 11 and value.startswith("1"):
        return value[1:].isdigit() and value[1] in "3456789"
    if len(value) == 13 and value.startswith("86"):
        mobile = value[2:]
        return mobile.startswith("1") and mobile[1:].isdigit() and mobile[1] in "3456789"
    return False


def _mask_bank_card(value: str) -> str:
    """对银行卡号进行掩码处理。

    Args:
        value: 银行卡号字符串。

    Returns:
        str: 长度小于等于 10 时全部用 ``*`` 替换；否则保留前 6 位与后 4 位。
    """

    if len(value) <= 10:
        return "*" * len(value)
    return f"{value[:6]}{'*' * (len(value) - 10)}{value[-4:]}"


def _mask_id_card(value: str) -> str:
    """对身份证号进行掩码处理。

    Args:
        value: 15 位或 18 位身份证字符串。

    Returns:
        str: 长度小于等于 10 时全部用 ``*`` 替换；否则保留前 6 位与后 4 位。
    """

    if len(value) <= 10:
        return "*" * len(value)
    return f"{value[:6]}{'*' * (len(value) - 10)}{value[-4:]}"
