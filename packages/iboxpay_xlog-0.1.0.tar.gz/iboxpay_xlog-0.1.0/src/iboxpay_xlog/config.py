"""日志框架的配置模型。

本模块提供 ``LogSink`` 与 ``LoggingSettings`` 两个数据类，描述：

- 单个日志文件的路由规则（按 ``record.extra['name']`` 进行 include / exclude 过滤）。
- 整个日志系统的全局配置（输出目录、格式、滚动阈值、stdlib 桥接策略等）。

业务方在调用 :func:`iboxpay_xlog.configure_logging` 时可传入自定义的
``LoggingSettings`` 覆盖默认行为；不传则使用一组与 iboxpay 后端服务一致的默认值。
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_LOG_FORMAT = (
    "[{time:YYYY-MM-DD HH:mm:ss:SSS}] "
    "[{thread.name}] "
    "[{level}] "
    "[{extra[name]}] "
    "[{extra[transactionId]}] "
    "[{extra[spanId]}] "
    "[{extra[timeDiff]}] "
    "[{extra[serviceId]}] "
    "[{extra[protocol]}] "
    "[{extra[logType]}] - {message}{extra[detail]}"
)

DEFAULT_ROTATION_MAX_BYTES = 100 * 1024 * 1024

DEFAULT_EXTRA_FIELDS: dict[str, str] = {
    "transactionId": "",
    "spanId": "",
    "timeDiff": "",
    "serviceId": "",
    "protocol": "",
    "logType": "",
    "detail": "",
}

DEFAULT_SILENCED_LOGGERS: dict[str, str] = {
    "httpx": "WARNING",
}

DEFAULT_DISABLED_LOGGERS: tuple[str, ...] = ("uvicorn.access",)

DEFAULT_INTERCEPT_LOGGERS: tuple[str, ...] = ("uvicorn", "uvicorn.error")


@dataclass(frozen=True)
class LogSink:
    """单个日志文件 sink 的配置。

    每个 sink 会在日志根目录下生成一个子目录，并写入同名的 ``.log`` 文件。
    通过 ``include_logger_names`` / ``exclude_logger_names`` 控制只把符合
    名称（即 ``record.extra['name']``，由 :func:`get_logger` 注入）的记录
    写入该文件。

    Attributes:
        name: sink 名称，同时作为子目录名与文件基名。
        level: 该 sink 的日志级别，默认 ``"INFO"``。
        include_logger_names: 仅当 ``record.extra['name']`` 命中此集合时写入。
            为 ``None`` 表示不做白名单过滤。
        exclude_logger_names: 当 ``record.extra['name']`` 命中此集合时跳过。
            为 ``None`` 表示不做黑名单过滤。
    """

    name: str
    level: str = "INFO"
    include_logger_names: frozenset[str] | None = None
    exclude_logger_names: frozenset[str] | None = None


def default_log_sinks() -> tuple[LogSink, ...]:
    """返回与 iboxpay 后端服务一致的默认 sink 集合。

    默认包含 ``app`` / ``interface`` / ``access`` / ``error`` / ``remote``
    五类文件，路由规则与原 ``iboxclaw-identity`` 项目保持一致。

    Returns:
        tuple[LogSink, ...]: 默认 sink 元组，按写入优先级排列。
    """

    return (
        LogSink(
            name="app",
            level="INFO",
            exclude_logger_names=frozenset({"interface", "access"}),
        ),
        LogSink(
            name="interface",
            level="INFO",
            include_logger_names=frozenset({"app.request", "interface"}),
        ),
        LogSink(
            name="access",
            level="INFO",
            include_logger_names=frozenset({"access", "uvicorn.access"}),
        ),
        LogSink(
            name="error",
            level="WARNING",
        ),
        LogSink(
            name="remote",
            level="INFO",
            include_logger_names=frozenset({"remote"}),
        ),
    )


@dataclass
class LoggingSettings:
    """全局日志配置。

    该配置作为 :func:`iboxpay_xlog.configure_logging` 的入参使用，
    所有字段均提供合理默认值，业务方仅覆盖关心的字段即可。

    Attributes:
        service_name: 服务标识，用于推导默认环境变量名与日志根目录。
        log_base_dir: 显式指定日志根目录；若提供则忽略环境变量。
        log_base_dir_env: 用于读取日志根目录的环境变量名。
            为 ``None`` 时根据 ``service_name`` 自动推导，例如
            ``"iboxpay-foo"`` 推导为 ``"IBOXPAY_FOO_LOG_BASE_DIR"``。
        fallback_log_base_dir: 当未配置环境变量且未显式指定时的回退根目录。
            为 ``None`` 时使用当前进程工作目录下的 ``logs``。
        log_format: Loguru 日志格式串，默认采用类 Logback 文本格式。
        console_level: 控制台 sink 的日志级别。
        rotation_max_bytes: 单文件滚动阈值（字节），超过即触发滚动。
        rotate_hourly: 是否在小时跨越时滚动文件，默认 ``True``。
        sinks: 文件 sink 列表；为 ``None`` 时使用 :func:`default_log_sinks`。
            提供空元组可关闭文件输出，仅保留 stdout。
        enable_file_logging: 总开关，``False`` 时强制禁用所有文件 sink。
        extra_default_fields: 注入到每条记录 ``extra`` 中的默认字段，
            避免格式串引用空字段时报错。
        intercept_stdlib: 是否安装 :class:`InterceptHandler` 把标准
            ``logging`` 记录桥接到 Loguru。
        silenced_loggers: 需要降噪的 stdlib logger 名称及目标级别。
        disabled_loggers: 需要彻底禁用的 stdlib logger 名称。
        intercept_loggers: 需要绑定 ``InterceptHandler`` 的额外 stdlib logger。
        backtrace: Loguru sink 的 ``backtrace`` 选项。
        diagnose: Loguru sink 的 ``diagnose`` 选项。
    """

    service_name: str = "iboxpay"
    log_base_dir: Path | None = None
    log_base_dir_env: str | None = None
    fallback_log_base_dir: Path | None = None
    log_format: str = DEFAULT_LOG_FORMAT
    console_level: str = "INFO"
    rotation_max_bytes: int = DEFAULT_ROTATION_MAX_BYTES
    rotate_hourly: bool = True
    sinks: tuple[LogSink, ...] | None = None
    enable_file_logging: bool = True
    extra_default_fields: dict[str, str] = field(
        default_factory=lambda: dict(DEFAULT_EXTRA_FIELDS)
    )
    intercept_stdlib: bool = True
    silenced_loggers: dict[str, str] = field(
        default_factory=lambda: dict(DEFAULT_SILENCED_LOGGERS)
    )
    disabled_loggers: tuple[str, ...] = DEFAULT_DISABLED_LOGGERS
    intercept_loggers: tuple[str, ...] = DEFAULT_INTERCEPT_LOGGERS
    backtrace: bool = False
    diagnose: bool = False

    def resolved_log_base_dir_env(self) -> str:
        """计算最终生效的日志根目录环境变量名。

        Returns:
            str: 显式提供的 ``log_base_dir_env`` 优先；否则由
            ``service_name`` 转大写并把非字母数字替换为下划线后，
            追加 ``_LOG_BASE_DIR`` 得到。
        """

        if self.log_base_dir_env:
            return self.log_base_dir_env
        normalized = "".join(
            ch.upper() if ch.isalnum() else "_" for ch in self.service_name.strip() or "iboxpay"
        )
        return f"{normalized}_LOG_BASE_DIR"

    def resolved_log_base_dir(self) -> Path:
        """解析最终生效的日志根目录。

        解析顺序：

        1. 若 ``log_base_dir`` 字段非空，直接使用。
        2. 否则读取由 :meth:`resolved_log_base_dir_env` 计算出的环境变量。
        3. 否则使用 ``fallback_log_base_dir``。
        4. 仍然未指定时回退到当前工作目录下的 ``logs``。

        Returns:
            Path: 解析后的绝对路径。
        """

        if self.log_base_dir is not None:
            return Path(self.log_base_dir).resolve()
        env_name = self.resolved_log_base_dir_env()
        raw = os.getenv(env_name, "").strip()
        if raw:
            return Path(raw).resolve()
        if self.fallback_log_base_dir is not None:
            return Path(self.fallback_log_base_dir).resolve()
        return (Path.cwd() / "logs").resolve()

    def resolved_sinks(self) -> tuple[LogSink, ...]:
        """获取最终生效的文件 sink 元组。

        当 :attr:`enable_file_logging` 为 ``False`` 时返回空元组；
        否则返回显式提供的 :attr:`sinks`，未指定则使用默认 sink 集合。

        Returns:
            tuple[LogSink, ...]: 实际会创建的文件 sink 列表。
        """

        if not self.enable_file_logging:
            return ()
        if self.sinks is None:
            return default_log_sinks()
        return tuple(self.sinks)
