"""iboxpay-xlog 公共日志框架。

对外暴露的核心 API：

- :func:`configure_logging`：幂等初始化整个日志系统。
- :func:`get_logger`：按业务名称取得绑定后的 Loguru logger。
- :func:`reset_logging_for_tests`：清空状态以便重新配置或在测试中复用。
- :data:`logger`：底层已经 ``patch`` 默认 extra 的 Loguru logger 实例。
- :class:`LoggingSettings` / :class:`LogSink`：配置数据类。
- :func:`redact_log_text` / :func:`redact_log_value`：脱敏工具。
- :class:`InterceptHandler`：将 stdlib ``logging`` 桥接到 Loguru 的处理器。
"""

from __future__ import annotations

from iboxpay_xlog.config import (
    DEFAULT_DISABLED_LOGGERS,
    DEFAULT_EXTRA_FIELDS,
    DEFAULT_INTERCEPT_LOGGERS,
    DEFAULT_LOG_FORMAT,
    DEFAULT_ROTATION_MAX_BYTES,
    DEFAULT_SILENCED_LOGGERS,
    LoggingSettings,
    LogSink,
    default_log_sinks,
)
from iboxpay_xlog.intercept import InterceptHandler
from iboxpay_xlog.logger import (
    configure_logging,
    current_settings,
    get_logger,
    logger,
    reset_logging_for_tests,
)
from iboxpay_xlog.redaction import (
    BANK_CARD_PATTERN,
    ID_CARD_PATTERN,
    redact_log_text,
    redact_log_value,
)

__all__ = [
    "BANK_CARD_PATTERN",
    "DEFAULT_DISABLED_LOGGERS",
    "DEFAULT_EXTRA_FIELDS",
    "DEFAULT_INTERCEPT_LOGGERS",
    "DEFAULT_LOG_FORMAT",
    "DEFAULT_ROTATION_MAX_BYTES",
    "DEFAULT_SILENCED_LOGGERS",
    "ID_CARD_PATTERN",
    "InterceptHandler",
    "LogSink",
    "LoggingSettings",
    "__version__",
    "configure_logging",
    "current_settings",
    "default_log_sinks",
    "get_logger",
    "logger",
    "redact_log_text",
    "redact_log_value",
    "reset_logging_for_tests",
]

__version__ = "0.1.0"
