"""标准库 ``logging`` 与 Loguru 之间的桥接。

通过 :class:`InterceptHandler` 把所有 stdlib 日志记录转发进 Loguru，
保证第三方库（如 uvicorn、httpx、SQLAlchemy 等）的输出与业务日志拥有
统一的格式与文件路由。
"""

from __future__ import annotations

import logging
from typing import Any

INTERCEPT_HANDLER_TAG = "_iboxpay_xlog_intercept_handler"


class InterceptHandler(logging.Handler):
    """将 stdlib ``logging`` 记录转发到 Loguru 的处理器。

    核心职责：保留原 logger 名称（写入 ``record.extra['name']``）、保留
    异常上下文，并按 Loguru 的级别名称重新派发，使所有日志在最终输出层
    保持一致的格式。
    """

    def __init__(self, loguru_logger: Any) -> None:
        """初始化处理器。

        Args:
            loguru_logger: 已经 ``patch`` 过默认 ``extra`` 字段的 Loguru
                logger 实例，由 :func:`iboxpay_xlog.configure_logging`
                注入。
        """

        super().__init__()
        self._loguru_logger = loguru_logger
        setattr(self, INTERCEPT_HANDLER_TAG, True)

    def emit(self, record: logging.LogRecord) -> None:
        """把单条 stdlib 记录转发给 Loguru。

        Args:
            record: stdlib 产生的日志记录对象。
        """

        if record.name.startswith("loguru"):
            return
        try:
            level: str | int = self._loguru_logger.level(record.levelname).name
        except ValueError:
            level = record.levelno
        self._loguru_logger.bind(name=record.name).opt(
            depth=6,
            exception=record.exc_info,
        ).log(level, record.getMessage())
