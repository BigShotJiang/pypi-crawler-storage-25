"""``LoggingSettings`` / ``LogSink`` 相关的单元测试。"""

from __future__ import annotations

from pathlib import Path

import pytest

from iboxpay_xlog import LoggingSettings, default_log_sinks


def test_default_log_sinks_have_expected_names() -> None:
    names = [sink.name for sink in default_log_sinks()]

    assert names == ["app", "interface", "access", "error", "remote"]


def test_resolved_log_base_dir_env_derives_from_service_name() -> None:
    settings = LoggingSettings(service_name="iboxpay-foo")

    assert settings.resolved_log_base_dir_env() == "IBOXPAY_FOO_LOG_BASE_DIR"


def test_resolved_log_base_dir_env_respects_override() -> None:
    settings = LoggingSettings(service_name="iboxpay-foo", log_base_dir_env="CUSTOM_LOG_DIR")

    assert settings.resolved_log_base_dir_env() == "CUSTOM_LOG_DIR"


def test_resolved_log_base_dir_prefers_explicit_path(tmp_path: Path) -> None:
    settings = LoggingSettings(log_base_dir=tmp_path)

    assert settings.resolved_log_base_dir() == tmp_path.resolve()


def test_resolved_log_base_dir_uses_env(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("IBOXPAY_TEST_LOG_BASE_DIR", str(tmp_path))
    settings = LoggingSettings(service_name="iboxpay-test")

    assert settings.resolved_log_base_dir() == tmp_path.resolve()


def test_resolved_log_base_dir_falls_back(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.delenv("IBOXPAY_TEST_LOG_BASE_DIR", raising=False)
    settings = LoggingSettings(service_name="iboxpay-test", fallback_log_base_dir=tmp_path)

    assert settings.resolved_log_base_dir() == tmp_path.resolve()


def test_resolved_sinks_returns_empty_when_file_logging_disabled() -> None:
    settings = LoggingSettings(enable_file_logging=False)

    assert settings.resolved_sinks() == ()


def test_resolved_sinks_uses_default_when_unspecified() -> None:
    settings = LoggingSettings()

    assert settings.resolved_sinks() == default_log_sinks()
