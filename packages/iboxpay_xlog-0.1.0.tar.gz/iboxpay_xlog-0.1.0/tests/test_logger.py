"""``configure_logging`` / ``get_logger`` 等核心 API 的单元测试。"""

from __future__ import annotations

import logging
import re
from pathlib import Path

import pytest

from iboxpay_xlog import (
    LoggingSettings,
    LogSink,
    configure_logging,
    current_settings,
    get_logger,
    reset_logging_for_tests,
)
from iboxpay_xlog.intercept import INTERCEPT_HANDLER_TAG
from iboxpay_xlog.testing import capture_records


def _build_settings(tmp_path: Path, **overrides) -> LoggingSettings:
    """构造仅写入 ``tmp_path`` 的测试用配置。"""

    return LoggingSettings(
        service_name="iboxpay-test",
        log_base_dir=tmp_path,
        rotate_hourly=False,
        **overrides,
    )


def test_configure_logging_is_idempotent(tmp_path: Path) -> None:
    first = configure_logging(_build_settings(tmp_path))
    second = configure_logging(_build_settings(tmp_path / "other"))

    assert first is second
    assert current_settings() is first


def test_get_logger_binds_name_into_extra(tmp_path: Path) -> None:
    configure_logging(_build_settings(tmp_path))

    with capture_records() as records:
        get_logger("demo.module").info("hello")

    assert records, "should have captured at least one record"
    assert records[-1]["extra"]["name"] == "demo.module"
    assert records[-1]["message"] == "hello"


def test_get_logger_auto_initialises_when_unconfigured(tmp_path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)

    bound = get_logger("auto")

    assert current_settings() is not None

    with capture_records() as records:
        bound.info("auto-init")

    assert records[-1]["extra"]["name"] == "auto"


def test_logging_routes_records_to_expected_files(tmp_path: Path) -> None:
    configure_logging(_build_settings(tmp_path))

    get_logger("app.service").info("app-message")
    get_logger("app.request").info("interface-message")
    get_logger("access").info("access-message")
    get_logger("remote").info("remote-message")
    get_logger("app.service").warning("error-message")

    app_log = (tmp_path / "app" / "app.log").read_text(encoding="utf-8")
    interface_log = (tmp_path / "interface" / "interface.log").read_text(encoding="utf-8")
    access_log = (tmp_path / "access" / "access.log").read_text(encoding="utf-8")
    error_log = (tmp_path / "error" / "error.log").read_text(encoding="utf-8")
    remote_log = (tmp_path / "remote" / "remote.log").read_text(encoding="utf-8")

    # app sink 默认仅排除 access/interface 名称，其他业务记录都会落入。
    assert "app-message" in app_log
    assert "access-message" not in app_log

    # interface 仅收 app.request 与 interface 命名的记录。
    assert "interface-message" in interface_log
    assert "app-message" not in interface_log

    # access 仅收 access / uvicorn.access。
    assert "access-message" in access_log
    assert "remote-message" not in access_log

    # remote 仅收 remote 命名的记录。
    assert "remote-message" in remote_log
    assert "app-message" not in remote_log

    # error sink 不限制名称，但仅收 WARNING 及以上级别。
    assert "error-message" in error_log
    assert "app-message" not in error_log


def test_logback_like_format_is_emitted(tmp_path: Path) -> None:
    configure_logging(_build_settings(tmp_path))
    get_logger("app.service").info("formatted")

    line = (tmp_path / "app" / "app.log").read_text(encoding="utf-8").strip().splitlines()[-1]
    pattern = (
        r"^\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}:\d{3}\] "
        r"\[[^\]]+\] \[INFO\] \[app\.service\] \[\] \[\] \[\] \[\] \[\] \[\] - formatted$"
    )
    assert re.match(pattern, line), line


def test_disable_file_logging_skips_files(tmp_path: Path) -> None:
    configure_logging(_build_settings(tmp_path, enable_file_logging=False))
    get_logger("app").info("only stdout")

    assert not (tmp_path / "app").exists()


def test_stdlib_logging_is_bridged(tmp_path: Path) -> None:
    configure_logging(_build_settings(tmp_path))

    with capture_records() as records:
        logging.getLogger("third.party").warning("from-stdlib")

    assert any(record["message"] == "from-stdlib" for record in records)
    root_handlers = logging.getLogger().handlers
    assert any(getattr(handler, INTERCEPT_HANDLER_TAG, False) for handler in root_handlers)
    assert logging.getLogger("httpx").level == logging.WARNING


def test_reset_logging_for_tests_clears_state(tmp_path: Path) -> None:
    configure_logging(_build_settings(tmp_path))
    assert current_settings() is not None

    reset_logging_for_tests()

    assert current_settings() is None
    assert not any(
        getattr(handler, INTERCEPT_HANDLER_TAG, False)
        for handler in logging.getLogger().handlers
    )


def test_configure_logging_falls_back_to_stdout_when_dir_unwritable(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, capsys
) -> None:
    target = tmp_path / "unwritable"

    def _raise(*_args, **_kwargs):
        raise OSError("denied")

    monkeypatch.setattr("pathlib.Path.mkdir", _raise)

    configure_logging(_build_settings(target))
    err = capsys.readouterr().err
    assert "iboxpay-xlog" in err

    with capture_records() as records:
        get_logger("app").info("stdout-only")

    assert records[-1]["message"] == "stdout-only"
    assert not target.exists()


def test_custom_sinks_are_honoured(tmp_path: Path) -> None:
    custom_sinks = (
        LogSink(name="audit", level="INFO", include_logger_names=frozenset({"audit"})),
        LogSink(name="general", level="INFO", exclude_logger_names=frozenset({"audit"})),
    )
    configure_logging(_build_settings(tmp_path, sinks=custom_sinks))

    get_logger("audit").info("audit-message")
    get_logger("biz").info("biz-message")

    audit_log = (tmp_path / "audit" / "audit.log").read_text(encoding="utf-8")
    general_log = (tmp_path / "general" / "general.log").read_text(encoding="utf-8")

    assert "audit-message" in audit_log
    assert "biz-message" not in audit_log
    assert "biz-message" in general_log
    assert "audit-message" not in general_log
    assert not (tmp_path / "app").exists()
