"""``iboxpay_xlog.testing`` 工具的单元测试。"""

from __future__ import annotations

from pathlib import Path

from iboxpay_xlog import LoggingSettings, configure_logging, get_logger
from iboxpay_xlog.testing import capture_records


def test_capture_records_collects_emitted_logs(tmp_path: Path) -> None:
    configure_logging(
        LoggingSettings(
            service_name="iboxpay-test",
            log_base_dir=tmp_path,
            rotate_hourly=False,
        )
    )

    with capture_records(level="INFO") as records:
        get_logger("test").info("captured")

    assert any(record["message"] == "captured" for record in records)


def test_capture_records_releases_sink_on_exit(tmp_path: Path) -> None:
    configure_logging(
        LoggingSettings(
            service_name="iboxpay-test",
            log_base_dir=tmp_path,
            rotate_hourly=False,
        )
    )

    with capture_records() as inner_records:
        pass

    with capture_records() as second_records:
        get_logger("test").info("after-exit")

    assert inner_records == []
    assert any(record["message"] == "after-exit" for record in second_records)
