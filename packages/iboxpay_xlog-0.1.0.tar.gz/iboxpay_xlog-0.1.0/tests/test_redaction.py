"""脱敏模块的单元测试。"""

from __future__ import annotations

from iboxpay_xlog import redact_log_text, redact_log_value


def test_redact_log_text_masks_id_card() -> None:
    text = "user 110101199003078888 logged in"
    masked = redact_log_text(text)

    assert "110101199003078888" not in masked
    assert "110101" in masked
    assert "8888" in masked


def test_redact_log_text_masks_bank_card() -> None:
    text = "card 6222021234567890123 charged"
    masked = redact_log_text(text)

    assert "6222021234567890123" not in masked
    assert masked.startswith("card 622202")
    assert masked.endswith("0123 charged")


def test_redact_log_text_keeps_mainland_phone() -> None:
    text = "phone 13800138000 verified"

    assert redact_log_text(text) == text


def test_redact_log_text_keeps_mainland_phone_with_country_code() -> None:
    text = "phone 8613800138000 verified"

    assert redact_log_text(text) == text


def test_redact_log_value_handles_nested_containers() -> None:
    payload = {
        "id_card": "110101199003078888",
        "bank_cards": ["6222021234567890123", "6222021111222233334"],
        "phone": "13800138000",
        "extras": ("110101199003078888",),
        "amount": 100,
    }

    masked = redact_log_value(payload)

    assert masked["id_card"] != payload["id_card"]
    assert all(card != raw for card, raw in zip(masked["bank_cards"], payload["bank_cards"]))
    assert masked["phone"] == payload["phone"]
    assert isinstance(masked["extras"], tuple)
    assert masked["extras"][0] != payload["extras"][0]
    assert masked["amount"] == 100


def test_redact_log_value_returns_non_string_scalars_unchanged() -> None:
    assert redact_log_value(None) is None
    assert redact_log_value(3.14) == 3.14
    assert redact_log_value(True) is True
