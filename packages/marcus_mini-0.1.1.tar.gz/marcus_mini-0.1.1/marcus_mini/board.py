"""SQLite-backed task board for Marcus Mini."""

from __future__ import annotations

import asyncio
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, cast

from marcus_mini.models import Status, Task

_DB_PATH = Path.home() / ".marcus-mini" / "board.db"

_DDL = """
PRAGMA journal_mode=WAL;
PRAGMA busy_timeout=10000;

CREATE TABLE IF NOT EXISTS tasks (
    id          TEXT PRIMARY KEY,
    project     TEXT NOT NULL,
    name        TEXT NOT NULL,
    description TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'TODO',
    assigned_to TEXT,
    deps        TEXT NOT NULL DEFAULT '[]',
    artifacts   TEXT NOT NULL DEFAULT '[]',
    decisions   TEXT NOT NULL DEFAULT '[]',
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL,
    started_at  TEXT
);

CREATE TABLE IF NOT EXISTS projects (
    slug         TEXT PRIMARY KEY,
    tmux_session TEXT NOT NULL,
    n_agents     INT  NOT NULL DEFAULT 0,
    started_at   TEXT NOT NULL,
    finished_at  TEXT,
    output_dir   TEXT,
    description  TEXT,
    status       TEXT NOT NULL DEFAULT 'running'
);

CREATE INDEX IF NOT EXISTS idx_tasks_project ON tasks(project);
CREATE INDEX IF NOT EXISTS idx_tasks_status  ON tasks(status);
"""

_SQLITE_MIN_VERSION = (3, 38)


class ProjectExistsError(Exception):
    """Raised when create_project is called with a slug that already exists.

    Parameters
    ----------
    project : str
        The duplicate project slug.
    """

    def __init__(self, project: str) -> None:
        super().__init__(f"Project '{project}' already exists on this board.")
        self.project = project


class TaskNotFoundError(KeyError):
    """Raised when a board operation references an unknown task ID.

    Subclasses KeyError to preserve backward-compat for callers using
    ``except KeyError``.

    Parameters
    ----------
    task_id : str
        The missing task identifier.
    """

    def __init__(self, task_id: str) -> None:
        super().__init__(f"Task '{task_id}' not found.")
        self.task_id = task_id


def _validate_dag(tasks: list[Task]) -> None:
    """Validate task list before insertion. Reject self-deps and unknown deps.

    Parameters
    ----------
    tasks : list[Task]
        Tasks scheduled for insertion.

    Raises
    ------
    ValueError
        If any task has a self-dependency or references an unknown task ID.
    """
    task_ids = {t.id for t in tasks}
    for t in tasks:
        if t.id in t.dependencies:
            raise ValueError(
                f"Task '{t.id}' has self-dependency — DAG is invalid."
            )
        unknown = [d for d in t.dependencies if d not in task_ids]
        if unknown:
            raise ValueError(
                f"Task '{t.id}' depends on unknown task(s): {unknown}"
            )


def _detect_cycles(deps_map: dict[str, list[str]]) -> None:
    """Detect cycles in a dependency graph via DFS coloring.

    Parameters
    ----------
    deps_map : dict[str, list[str]]
        Mapping of task ID to its dependency IDs.

    Raises
    ------
    ValueError
        If any cycle is detected.
    """
    # 0 = unvisited, 1 = in current DFS path, 2 = fully explored
    color: dict[str, int] = {tid: 0 for tid in deps_map}

    def _visit(tid: str) -> None:
        if color[tid] == 2:
            return
        if color[tid] == 1:
            raise ValueError(f"Cycle detected at task '{tid}'.")
        color[tid] = 1
        for d in deps_map[tid]:
            _visit(d)
        color[tid] = 2

    for tid in deps_map:
        _visit(tid)


def _check_sqlite_version(conn: sqlite3.Connection) -> None:
    """Assert that the connected SQLite runtime supports json_each().

    Parameters
    ----------
    conn : sqlite3.Connection
        An open database connection.

    Raises
    ------
    RuntimeError
        If the SQLite version is older than 3.38.
    """
    row = conn.execute("SELECT sqlite_version()").fetchone()
    version_str: str = row[0]
    parts = tuple(int(x) for x in version_str.split(".")[:2])
    if parts < _SQLITE_MIN_VERSION:
        raise RuntimeError(
            f"SQLite {version_str} detected; marcus-mini requires >= 3.38 "
            "(json_each support)."
        )


def _now() -> str:
    """Return current UTC time as ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


def _row_to_task(row: sqlite3.Row) -> Task:
    """Convert a sqlite3.Row into a Task dataclass.

    Parameters
    ----------
    row : sqlite3.Row
        Row from the tasks table.

    Returns
    -------
    Task
        Populated Task instance.
    """
    return Task(
        id=row["id"],
        name=row["name"],
        description=row["description"],
        status=row["status"],
        assigned_to=row["assigned_to"],
        dependencies=json.loads(row["deps"]),
        artifacts=json.loads(row["artifacts"]),
        decisions=json.loads(row["decisions"]),
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        project=row["project"],
    )


class Board:
    """Async wrapper around a SQLite task board.

    Heavy work runs in a thread-pool executor so callers can ``await``
    every method without blocking the event loop.

    Parameters
    ----------
    db_path : Path, optional
        Path to the SQLite database file. Defaults to
        ``~/.marcus-mini/board.db``.
    """

    def __init__(self, db_path: Path = _DB_PATH) -> None:
        self._db_path = db_path
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._cache: dict[str, Task] = {}
        self._init_db()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _connect(self) -> sqlite3.Connection:
        """Open and configure a database connection.

        Returns
        -------
        sqlite3.Connection
            Connection with WAL mode, busy timeout, and row_factory set.
        """
        conn = sqlite3.connect(str(self._db_path), timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=10000")
        return conn

    def _init_db(self) -> None:
        """Create schema, run column migrations, and validate SQLite version."""
        conn = self._connect()
        try:
            _check_sqlite_version(conn)
            conn.executescript(_DDL)
            # Safe migrations for boards created before these columns existed
            for col, definition in [
                ("output_dir", "TEXT"),
                ("description", "TEXT"),
                ("status", "TEXT NOT NULL DEFAULT 'running'"),
            ]:
                try:
                    conn.execute(
                        f"ALTER TABLE projects ADD COLUMN {col} {definition}"
                    )
                except sqlite3.OperationalError:
                    pass  # column already exists
            try:
                conn.execute("ALTER TABLE tasks ADD COLUMN started_at TEXT")
            except sqlite3.OperationalError:
                pass  # column already exists
            conn.commit()
        finally:
            conn.close()

    def _sync_create_project(self, project: str, tasks: list[Task]) -> None:
        """Bulk-insert tasks for a new project (synchronous).

        Parameters
        ----------
        project : str
            Project slug.
        tasks : list[Task]
            Tasks to insert.

        Raises
        ------
        ProjectExistsError
            If any task with the given project slug already exists.
        """
        # Reject malformed DAGs before they hit the DB.
        _validate_dag(tasks)
        _detect_cycles({t.id: list(t.dependencies) for t in tasks})

        conn = self._connect()
        try:
            existing = conn.execute(
                "SELECT 1 FROM tasks WHERE project = ? LIMIT 1", (project,)
            ).fetchone()
            if existing:
                raise ProjectExistsError(project)

            now = _now()
            rows = [
                (
                    t.id,
                    project,
                    t.name,
                    t.description,
                    "TODO",
                    None,
                    json.dumps(t.dependencies),
                    json.dumps([]),
                    json.dumps([]),
                    now,
                    now,
                )
                for t in tasks
            ]
            conn.executemany(
                """
                INSERT INTO tasks
                    (id, project, name, description, status, assigned_to,
                     deps, artifacts, decisions, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                rows,
            )
            conn.commit()
            # Populate cache
            for t in tasks:
                cached = Task(
                    id=t.id,
                    name=t.name,
                    description=t.description,
                    status="TODO",
                    assigned_to=None,
                    dependencies=t.dependencies,
                    artifacts=[],
                    decisions=[],
                    created_at=now,
                    updated_at=now,
                    project=project,
                )
                self._cache[t.id] = cached
        finally:
            conn.close()

    def _sync_request_next_task(
        self, agent_id: str, project: str
    ) -> Task | None:
        """Claim the next available task under an EXCLUSIVE transaction.

        A task is *available* when:
        - status = 'TODO'
        - every task id in its deps list has status = 'DONE'

        After claiming, dependency artifacts/decisions are appended to
        the task description as context.

        Parameters
        ----------
        agent_id : str
            Identifier of the requesting agent.
        project : str
            Project slug to pull from.

        Returns
        -------
        Task | None
            The claimed task (with injected context), or None if no
            task is available.
        """
        conn = self._connect()
        try:
            conn.execute("BEGIN EXCLUSIVE")

            # Find candidate tasks whose every dependency is DONE.
            # json_each() requires SQLite >= 3.38.
            row = conn.execute(
                """
                SELECT t.*
                FROM tasks t
                WHERE t.project = ?
                  AND t.status = 'TODO'
                  AND NOT EXISTS (
                      SELECT 1
                      FROM json_each(t.deps) AS dep
                      WHERE NOT EXISTS (
                          SELECT 1 FROM tasks d
                          WHERE d.id = dep.value
                            AND d.status = 'DONE'
                      )
                  )
                ORDER BY t.created_at
                LIMIT 1
                """,
                (project,),
            ).fetchone()

            if row is None:
                conn.rollback()
                return None

            task_id: str = row["id"]
            now = _now()
            # started_at preserves first claim (COALESCE) so re-claims
            # don't reset bench timing.
            conn.execute(
                """
                UPDATE tasks
                   SET status = 'IN_PROGRESS', assigned_to = ?,
                       updated_at = ?,
                       started_at = COALESCE(started_at, ?)
                 WHERE id = ?
                """,
                (agent_id, now, now, task_id),
            )
            conn.commit()

            task = _row_to_task(row)
            task.status = "IN_PROGRESS"
            task.assigned_to = agent_id
            task.updated_at = now

            # Inject dependency context into description
            context = self._sync_get_task_context(task_id, conn)
            dep_sections: list[str] = []
            for dep_id, dep_data in context.get("dependencies", {}).items():
                artifacts = dep_data.get("artifacts", [])
                decisions = dep_data.get("decisions", [])
                if artifacts or decisions:
                    section = f"### {dep_id}\n"
                    if artifacts:
                        section += "**Artifacts:**\n" + "\n".join(
                            f"- {a}" for a in artifacts
                        )
                    if decisions:
                        section += "\n**Decisions:**\n" + "\n".join(
                            f"- {d}" for d in decisions
                        )
                    dep_sections.append(section)

            if dep_sections:
                task.description = (
                    task.description
                    + "\n\n## Context from completed dependencies\n"
                    + "\n".join(dep_sections)
                )

            self._cache[task_id] = task
            return task
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _sync_get_task_context(
        self,
        task_id: str,
        conn: sqlite3.Connection | None = None,
    ) -> dict[str, Any]:
        """Return task data plus dependency artifacts/decisions.

        Parameters
        ----------
        task_id : str
            ID of the task to look up.
        conn : sqlite3.Connection | None
            Reuse an existing connection if provided; otherwise opens one.

        Returns
        -------
        dict[str, Any]
            ``{"task": task_dict, "dependencies": {dep_id: {...}}}``.
        """
        _close = conn is None
        if conn is None:
            conn = self._connect()
        try:
            row = conn.execute(
                "SELECT * FROM tasks WHERE id = ?", (task_id,)
            ).fetchone()
            if row is None:
                return {}

            task = _row_to_task(row)
            dep_context: dict[str, dict[str, Any]] = {}
            for dep_id in task.dependencies:
                dep_row = conn.execute(
                    "SELECT * FROM tasks WHERE id = ?", (dep_id,)
                ).fetchone()
                if dep_row:
                    dep = _row_to_task(dep_row)
                    dep_context[dep_id] = {
                        "name": dep.name,
                        "status": dep.status,
                        "artifacts": dep.artifacts,
                        "decisions": dep.decisions,
                    }

            return {
                "task": {
                    "id": task.id,
                    "name": task.name,
                    "description": task.description,
                    "status": task.status,
                    "assigned_to": task.assigned_to,
                    "dependencies": task.dependencies,
                    "artifacts": task.artifacts,
                    "decisions": task.decisions,
                },
                "dependencies": dep_context,
            }
        finally:
            if _close:
                conn.close()

    def _sync_log_artifact(self, task_id: str, content: str) -> None:
        """Append an artifact to a task record.

        Parameters
        ----------
        task_id : str
            Target task.
        content : str
            Artifact string to append.
        """
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT artifacts FROM tasks WHERE id = ?", (task_id,)
            ).fetchone()
            if row is None:
                raise TaskNotFoundError(task_id)
            artifacts: list[str] = json.loads(row["artifacts"])
            artifacts.append(content)
            conn.execute(
                "UPDATE tasks SET artifacts = ?, updated_at = ? WHERE id = ?",
                (json.dumps(artifacts), _now(), task_id),
            )
            conn.commit()
            if task_id in self._cache:
                self._cache[task_id].artifacts = artifacts
        finally:
            conn.close()

    def _sync_log_decision(self, task_id: str, content: str) -> None:
        """Append a decision to a task record.

        Parameters
        ----------
        task_id : str
            Target task.
        content : str
            Decision string to append.
        """
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT decisions FROM tasks WHERE id = ?", (task_id,)
            ).fetchone()
            if row is None:
                raise TaskNotFoundError(task_id)
            decisions: list[str] = json.loads(row["decisions"])
            decisions.append(content)
            conn.execute(
                "UPDATE tasks SET decisions = ?, updated_at = ? WHERE id = ?",
                (json.dumps(decisions), _now(), task_id),
            )
            conn.commit()
            if task_id in self._cache:
                self._cache[task_id].decisions = decisions
        finally:
            conn.close()

    def _sync_report_done(self, task_id: str) -> None:
        """Mark a task as DONE.

        Parameters
        ----------
        task_id : str
            Task to mark done.
        """
        now = _now()
        conn = self._connect()
        try:
            conn.execute(
                "UPDATE tasks SET status = 'DONE', updated_at = ? WHERE id = ?",
                (now, task_id),
            )
            conn.commit()
            if task_id in self._cache:
                self._cache[task_id].status = "DONE"
                self._cache[task_id].updated_at = now
        finally:
            conn.close()

    def _sync_report_failed(self, task_id: str, reason: str) -> None:
        """Mark a task as FAILED and log the reason as a decision.

        Parameters
        ----------
        task_id : str
            Task to mark failed.
        reason : str
            Explanation for the failure.
        """
        now = _now()
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT decisions FROM tasks WHERE id = ?", (task_id,)
            ).fetchone()
            if row is None:
                raise TaskNotFoundError(task_id)
            decisions: list[str] = json.loads(row["decisions"])
            decisions.append(f"FAILED: {reason}")
            conn.execute(
                """
                UPDATE tasks
                   SET status = 'FAILED', decisions = ?, updated_at = ?
                 WHERE id = ?
                """,
                (json.dumps(decisions), now, task_id),
            )
            conn.commit()
            if task_id in self._cache:
                self._cache[task_id].status = "FAILED"
                self._cache[task_id].decisions = decisions
                self._cache[task_id].updated_at = now
        finally:
            conn.close()

    def _sync_get_board_state(self, project: str) -> list[Task]:
        """Return all tasks for a project.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        list[Task]
            All tasks ordered by creation time.
        """
        conn = self._connect()
        try:
            rows = conn.execute(
                "SELECT * FROM tasks WHERE project = ? ORDER BY created_at",
                (project,),
            ).fetchall()
            tasks = [_row_to_task(r) for r in rows]
            for t in tasks:
                self._cache[t.id] = t
            return tasks
        finally:
            conn.close()

    def _sync_get_dag(self, project: str) -> dict[str, list[str]]:
        """Return the dependency DAG as an adjacency list.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        dict[str, list[str]]
            Mapping ``{task_id: [dep_id, ...]}``.
        """
        tasks = self._sync_get_board_state(project)
        return {t.id: t.dependencies for t in tasks}

    def _sync_all_done(self, project: str) -> bool:
        """Return True when every task in the project is DONE.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        bool
            True iff all tasks are DONE.
        """
        conn = self._connect()
        try:
            row = conn.execute(
                """
                SELECT COUNT(*) as total,
                       SUM(CASE WHEN status = 'DONE' THEN 1 ELSE 0 END) as done
                  FROM tasks WHERE project = ?
                """,
                (project,),
            ).fetchone()
            if row["total"] == 0:
                return False
            return bool(row["total"] == row["done"])
        finally:
            conn.close()

    def _sync_register_project(
        self,
        project: str,
        session: str,
        n_agents: int,
        output_dir: str = "",
        description: str = "",
    ) -> None:
        """Insert project timing record. Called at create_project time.

        Parameters
        ----------
        project : str
            Project slug.
        session : str
            tmux session name.
        n_agents : int
            Number of agents spawned.
        output_dir : str
            Absolute path where agents write files.
        description : str
            Original natural-language goal prompt.
        """
        conn = self._connect()
        try:
            conn.execute(
                "INSERT OR IGNORE INTO projects "
                "(slug, tmux_session, n_agents, started_at, output_dir, description) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (project, session, n_agents, _now(), output_dir, description),
            )
            conn.commit()
        finally:
            conn.close()

    def _sync_finish_project(self, project: str) -> None:
        """Set finished_at to now if not already set.

        Parameters
        ----------
        project : str
            Project slug.
        """
        conn = self._connect()
        try:
            conn.execute(
                "UPDATE projects SET finished_at = ?, status = 'done' "
                "WHERE slug = ? AND finished_at IS NULL",
                (_now(), project),
            )
            conn.commit()
        finally:
            conn.close()

    def _sync_stop_project(self, project: str) -> None:
        """Mark project as stopped (manually killed before completion).

        Parameters
        ----------
        project : str
            Project slug.
        """
        conn = self._connect()
        try:
            conn.execute(
                "UPDATE projects SET finished_at = ?, status = 'stopped' "
                "WHERE slug = ? AND finished_at IS NULL",
                (_now(), project),
            )
            conn.commit()
        finally:
            conn.close()

    def _sync_get_project_timing(
        self, project: str
    ) -> dict[str, str | None]:
        """Return started_at, finished_at, tmux_session, n_agents for a project.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        dict[str, str | None]
            Timing dict with keys slug, tmux_session, n_agents, started_at,
            finished_at. Empty dict if project not found.
        """
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT * FROM projects WHERE slug = ?", (project,)
            ).fetchone()
            if row is None:
                return {}
            return {
                "slug": row["slug"],
                "tmux_session": row["tmux_session"],
                "n_agents": row["n_agents"],
                "started_at": row["started_at"],
                "finished_at": row["finished_at"],
            }
        finally:
            conn.close()

    def _sync_get_all_projects(self) -> list[dict[str, str | int | None]]:
        """Return metadata for all known projects ordered by start time.

        Returns
        -------
        list[dict[str, str | int | None]]
            Each dict has keys: slug, status, started_at, finished_at,
            n_agents, output_dir, description, tmux_session.
        """
        conn = self._connect()
        try:
            rows = conn.execute(
                "SELECT * FROM projects ORDER BY started_at DESC"
            ).fetchall()
            results = []
            for row in rows:
                # Trust explicit status if it's already terminal. Only
                # auto-derive 'done' for legacy 'running' records that have
                # finished_at set (monitor wrote finished_at without flipping
                # status — pre-fix records).
                status = row["status"]
                if row["finished_at"] and status == "running":
                    status = "done"
                results.append({
                    "slug": row["slug"],
                    "status": status,
                    "started_at": row["started_at"],
                    "finished_at": row["finished_at"],
                    "n_agents": row["n_agents"],
                    "output_dir": row["output_dir"],
                    "description": row["description"],
                    "tmux_session": row["tmux_session"],
                })
            return results
        finally:
            conn.close()

    def _sync_get_agent_status(
        self, project: str
    ) -> list[dict[str, str | None]]:
        """Return per-agent status for all IN_PROGRESS tasks.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        list[dict[str, str | None]]
            Each element has keys agent_id, task_id, task_name, updated_at,
            last_activity.
        """
        conn = self._connect()
        try:
            rows = conn.execute(
                """SELECT id, name, assigned_to, status, updated_at,
                          artifacts, decisions
                   FROM tasks WHERE project = ? AND status = 'IN_PROGRESS'
                   ORDER BY updated_at DESC""",
                (project,),
            ).fetchall()
            result: list[dict[str, str | None]] = []
            for r in rows:
                artifacts: list[str] = json.loads(r["artifacts"])
                decisions: list[str] = json.loads(r["decisions"])
                last_activity: str | None = None
                if artifacts:
                    last_activity = f"artifact: {artifacts[-1][:80]}"
                elif decisions:
                    last_activity = f"decision: {decisions[-1][:80]}"
                result.append(
                    {
                        "agent_id": r["assigned_to"],
                        "task_id": r["id"],
                        "task_name": r["name"],
                        "updated_at": r["updated_at"],
                        "last_activity": last_activity,
                    }
                )
            return result
        finally:
            conn.close()

    def _sync_get_task_timing(
        self, project: str
    ) -> list[dict[str, str | None]]:
        """Return per-task timing data for bench analysis.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        list[dict[str, str | None]]
            Each element has keys: id, name, assigned_to, status,
            started_at, finished_at (None if task not DONE), deps.
        """
        conn = self._connect()
        try:
            rows = conn.execute(
                """SELECT id, name, assigned_to, status,
                          started_at, updated_at, deps
                   FROM tasks WHERE project = ?
                   ORDER BY COALESCE(started_at, created_at)""",
                (project,),
            ).fetchall()
            return [
                {
                    "id": row["id"],
                    "name": row["name"],
                    "assigned_to": row["assigned_to"],
                    "status": row["status"],
                    "started_at": row["started_at"],
                    "finished_at": (
                        row["updated_at"] if row["status"] == "DONE" else None
                    ),
                    "deps": row["deps"],
                }
                for row in rows
            ]
        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Public async API
    # ------------------------------------------------------------------

    async def _run(self, fn: Any, *args: Any) -> Any:
        """Run a synchronous function in the default thread-pool executor.

        Parameters
        ----------
        fn : callable
            Synchronous function to run.
        *args : Any
            Positional arguments forwarded to *fn*.

        Returns
        -------
        Any
            Return value of *fn*.
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, fn, *args)

    async def create_project(self, project: str, tasks: list[Task]) -> None:
        """Bulk-insert tasks for a new project.

        Parameters
        ----------
        project : str
            Unique project slug.
        tasks : list[Task]
            Tasks to create.

        Raises
        ------
        ProjectExistsError
            If the project slug already exists.
        """
        await self._run(self._sync_create_project, project, tasks)

    async def request_next_task(
        self, agent_id: str, project: str
    ) -> Task | None:
        """Claim the next available task for an agent.

        Parameters
        ----------
        agent_id : str
            Requesting agent's identifier.
        project : str
            Project to pull work from.

        Returns
        -------
        Task | None
            Claimed task with dependency context injected, or None.
        """
        result = await self._run(
            self._sync_request_next_task, agent_id, project
        )
        return cast("Task | None", result)

    async def log_artifact(self, task_id: str, content: str) -> None:
        """Append an artifact string to a task.

        Parameters
        ----------
        task_id : str
            Target task ID.
        content : str
            Artifact to store.
        """
        await self._run(self._sync_log_artifact, task_id, content)

    async def log_decision(self, task_id: str, content: str) -> None:
        """Append a decision string to a task.

        Parameters
        ----------
        task_id : str
            Target task ID.
        content : str
            Decision to store.
        """
        await self._run(self._sync_log_decision, task_id, content)

    async def report_done(self, task_id: str) -> None:
        """Mark a task as DONE.

        Parameters
        ----------
        task_id : str
            Task to complete.
        """
        await self._run(self._sync_report_done, task_id)

    async def report_failed(self, task_id: str, reason: str) -> None:
        """Mark a task as FAILED.

        Parameters
        ----------
        task_id : str
            Task that failed.
        reason : str
            Failure description.
        """
        await self._run(self._sync_report_failed, task_id, reason)

    async def get_board_state(self, project: str) -> list[Task]:
        """Return all tasks for a project.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        list[Task]
            Ordered task list.
        """
        result = await self._run(self._sync_get_board_state, project)
        return cast("list[Task]", result)

    async def get_dag(self, project: str) -> dict[str, list[str]]:
        """Return the dependency DAG for a project.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        dict[str, list[str]]
            Adjacency list ``{task_id: [dep_id, ...]}``.
        """
        result = await self._run(self._sync_get_dag, project)
        return cast("dict[str, list[str]]", result)

    async def all_done(self, project: str) -> bool:
        """Return True when every task in the project is DONE.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        bool
            Completion flag.
        """
        result = await self._run(self._sync_all_done, project)
        return cast(bool, result)

    async def get_task_context(self, task_id: str) -> dict[str, Any]:
        """Return a task and the artifacts/decisions of its dependencies.

        Parameters
        ----------
        task_id : str
            Task to look up.

        Returns
        -------
        dict[str, Any]
            ``{"task": ..., "dependencies": {dep_id: {...}}}``.
        """
        result = await self._run(self._sync_get_task_context, task_id, None)
        return cast("dict[str, Any]", result)

    async def register_project(
        self,
        project: str,
        session: str,
        n_agents: int,
        output_dir: str = "",
        description: str = "",
    ) -> None:
        """Insert project timing record.

        Parameters
        ----------
        project : str
            Project slug.
        session : str
            tmux session name.
        n_agents : int
            Number of agents spawned.
        output_dir : str
            Absolute path where agents write files.
        description : str
            Original natural-language goal prompt.
        """
        await self._run(
            self._sync_register_project,
            project,
            session,
            n_agents,
            output_dir,
            description,
        )

    async def get_all_projects(self) -> list[dict[str, str | int | None]]:
        """Return metadata for all known projects.

        Returns
        -------
        list[dict[str, str | int | None]]
            Project records ordered by start time (newest first).
        """
        result = await self._run(self._sync_get_all_projects)
        return cast("list[dict[str, str | int | None]]", result)

    async def finish_project(self, project: str) -> None:
        """Set finished_at on the project record.

        Parameters
        ----------
        project : str
            Project slug.
        """
        await self._run(self._sync_finish_project, project)

    async def stop_project(self, project: str) -> None:
        """Mark a project as stopped (killed before completion).

        Parameters
        ----------
        project : str
            Project slug.
        """
        await self._run(self._sync_stop_project, project)

    async def get_project_timing(
        self, project: str
    ) -> dict[str, str | None]:
        """Return timing info for a project.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        dict[str, str | None]
            Timing dict or empty dict if not found.
        """
        result = await self._run(self._sync_get_project_timing, project)
        return cast("dict[str, str | None]", result)

    async def get_agent_status(
        self, project: str
    ) -> list[dict[str, str | None]]:
        """Return per-agent status for all IN_PROGRESS tasks.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        list[dict[str, str | None]]
            Agent status records.
        """
        result = await self._run(self._sync_get_agent_status, project)
        return cast("list[dict[str, str | None]]", result)

    async def get_task_timing(
        self, project: str
    ) -> list[dict[str, str | None]]:
        """Return per-task timing data for bench analysis.

        Parameters
        ----------
        project : str
            Project slug.

        Returns
        -------
        list[dict[str, str | None]]
            Timing records with started_at / finished_at per task.
        """
        result = await self._run(self._sync_get_task_timing, project)
        return cast("list[dict[str, str | None]]", result)
