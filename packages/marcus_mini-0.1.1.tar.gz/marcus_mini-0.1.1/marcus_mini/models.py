"""Data models for Marcus Mini."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

Status = Literal["TODO", "IN_PROGRESS", "DONE", "FAILED"]


@dataclass
class Task:
    """Represents a single unit of work on the board.

    Parameters
    ----------
    id : str
        Unique identifier for the task (slug form, e.g. "setup-db").
    name : str
        Short human-readable name.
    description : str
        Full description of what the agent must do.
    status : Status
        Current lifecycle state.
    assigned_to : str | None
        Agent ID that has claimed this task, or None if unclaimed.
    dependencies : list[str]
        Task IDs that must be DONE before this task can be claimed.
    artifacts : list[str]
        Artifact strings logged by the agent that worked this task.
    decisions : list[str]
        Decision strings logged by the agent that worked this task.
    created_at : str
        ISO-8601 timestamp of creation.
    updated_at : str
        ISO-8601 timestamp of last modification.
    project : str
        Project slug this task belongs to.
    """

    id: str
    name: str
    description: str
    status: Status
    assigned_to: str | None
    dependencies: list[str]
    artifacts: list[str]
    decisions: list[str]
    created_at: str
    updated_at: str
    project: str
