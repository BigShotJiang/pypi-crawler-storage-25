"""Claude API-based project decomposer for Marcus Mini."""

from __future__ import annotations

import hashlib
import os
import re
from datetime import datetime, timezone
from typing import Any

import anthropic
from anthropic.types import TextBlockParam, ToolChoiceToolParam, ToolParam

from marcus_mini.models import Task

_DEFAULT_MODEL = "claude-sonnet-4-5"
# Intentionally NOT "ANTHROPIC_API_KEY" — that env var is consumed by Claude
# Code CLI and would charge your subscription key when agents run.
# Users set MINI_API_KEY to their provider API key for decomposition only.
_DEFAULT_API_KEY_ENV = "MINI_API_KEY"


def _get_api_key(env_var: str = _DEFAULT_API_KEY_ENV) -> str:
    """Return the API key from the named environment variable.

    Parameters
    ----------
    env_var : str
        Name of the environment variable that holds the API key.

    Returns
    -------
    str
        The API key value.

    Raises
    ------
    ValueError
        If the named environment variable is not set.
    """
    key = os.environ.get(env_var)
    if not key:
        raise ValueError(
            f"{env_var} environment variable is not set.\n"
            f"Set it to your Anthropic API key for project decomposition:\n"
            f"  export {env_var}=sk-ant-...\n"
            f"This key is used only for the one-time decomposition call, not by agents.\n"
            f"Do NOT use ANTHROPIC_API_KEY — Claude Code agents would pick it up "
            f"and charge it even when you have a subscription."
        )
    return key

_SYSTEM_PROMPT = (
    "You are a project decomposer. Produce a flat task list for coding projects. "
    "Each task must be self-contained enough for an agent to implement independently. "
    "Make descriptions 2-3 sentences. "
    "Aim for MAXIMUM parallelism — only add a dependency edge when it is strictly "
    "required (e.g. task B reads an artifact produced by task A). "
    "Never serialize tasks that can be done in parallel. "
    "Prefer explicit dependency edges over implicit ordering. "
    "Size tasks to 30-90 minutes of work."
)

_TOOL_SCHEMA: dict[str, Any] = {
    "name": "submit_tasks",
    "description": (
        "Submit the decomposed task list. "
        "Use integer indices (0-based) for dependencies."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "tasks": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "description": {"type": "string"},
                        "dependencies": {
                            "type": "array",
                            "items": {"type": "integer"},
                        },
                    },
                    "required": ["name", "description", "dependencies"],
                },
            }
        },
        "required": ["tasks"],
    },
}


def _slugify(text: str) -> str:
    """Convert a string to a URL-safe slug.

    Parameters
    ----------
    text : str
        Raw string to slugify.

    Returns
    -------
    str
        Lowercase, hyphen-separated slug.
    """
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    return text.strip("-")


def optimal_agent_count(tasks: list[Task], max_cap: int = 6) -> int:
    """Compute the optimal agent count via BFS over DAG levels.

    Uses a **parallel-level ratio** to avoid over-provisioning on mostly-
    linear DAGs.  If fewer than 25 % of levels have more than one runnable
    task, a single agent is recommended even if a brief wide level exists.
    Otherwise the maximum level width drives the count.

    This prevents a snake-game-style decomposition (one brief width-2 level
    among nine width-1 levels) from incorrectly recommending 2 agents when
    one agent will do all the work anyway.

    Parameters
    ----------
    tasks : list[Task]
        Full task list with dependency IDs populated.
    max_cap : int
        Upper bound on returned agent count. Default is 6.

    Returns
    -------
    int
        Recommended number of agents, clamped to ``[1, max_cap]``.
    """
    completed: set[str] = set()
    widths: list[int] = []
    remaining = list(tasks)

    while remaining:
        runnable = [
            t
            for t in remaining
            if all(d in completed for d in t.dependencies)
        ]
        if not runnable:
            break  # circular or done
        widths.append(len(runnable))
        for t in runnable:
            completed.add(t.id)
        remaining = [t for t in remaining if t.id not in completed]

    if not widths:
        return 1

    max_width = max(widths)
    total_tasks = len(tasks)

    # Fraction of all tasks sitting in the widest parallel level.
    # A snake game (width-2 burst among 10 tasks = 20%) should not trigger
    # multi-agent provisioning; a diamond or REST API (50 %+) should.
    parallel_share = max_width / total_tasks if total_tasks else 0

    recommended = max_width if parallel_share >= 0.33 else 1
    return min(max(1, recommended), max_cap)


def decompose(
    goal: str,
    model: str = _DEFAULT_MODEL,
    project: str = "project",
    api_key_env: str = _DEFAULT_API_KEY_ENV,
) -> tuple[list[Task], int]:
    """Decompose a project goal into tasks using Claude tool_use.

    Makes a single API call with ``tool_choice`` forced to
    ``submit_tasks``.  Integer dependency indices in the tool response
    are resolved to task ID slugs.

    Parameters
    ----------
    goal : str
        Natural-language description of what to build.
    model : str
        Claude model ID to use. Defaults to ``claude-sonnet-4-5``.
    project : str
        Project slug to embed in each Task.
    api_key_env : str
        Name of the environment variable that holds the Anthropic API key.

    Returns
    -------
    tuple[list[Task], int]
        ``(tasks, recommended_agents)`` where ``recommended_agents`` is
        derived from the DAG width algorithm.

    Raises
    ------
    ValueError
        If none of ANTHROPIC_API_KEY, CLAUDE_API_KEY, or ANTHROPIC_KEY are set.
    RuntimeError
        If Claude returns an unexpected response structure.
    """
    api_key = _get_api_key(api_key_env)
    client = anthropic.Anthropic(api_key=api_key)

    system_block: TextBlockParam = {
        "type": "text",
        "text": _SYSTEM_PROMPT,
        "cache_control": {"type": "ephemeral"},
    }
    tool_choice: ToolChoiceToolParam = {"type": "tool", "name": "submit_tasks"}
    tool_param: ToolParam = {
        "name": _TOOL_SCHEMA["name"],
        "description": _TOOL_SCHEMA["description"],
        "input_schema": _TOOL_SCHEMA["input_schema"],
    }

    response = client.messages.create(
        model=model,
        max_tokens=4096,
        # Low temperature so the same goal produces the same DAG across runs.
        # High variance corrupts benchmarks (different task counts/shapes).
        temperature=0.2,
        system=[system_block],
        tools=[tool_param],
        tool_choice=tool_choice,
        messages=[
            {
                "role": "user",
                "content": f"Decompose this project goal into tasks:\n\n{goal}",
            }
        ],
    )

    # Report mini's own token usage. Agents run under the user's Claude
    # subscription; this is the one place mini itself spends API budget.
    # Sonnet 4.5 list pricing: $3/1M input, $15/1M output (approximate).
    in_tok = response.usage.input_tokens
    out_tok = response.usage.output_tokens
    cost = (in_tok * 3 + out_tok * 15) / 1_000_000
    print(
        f"  Decomposer used {in_tok:,} input + {out_tok:,} output tokens "
        f"(~${cost:.4f})"
    )

    # Extract tool_use block — content is a union; check type then access attrs.
    tool_block: dict[str, Any] | None = None
    for block in response.content:
        if block.type == "tool_use":
            tb = block  # narrowed to ToolUseBlock
            if tb.name == "submit_tasks":
                tool_block = dict(tb.input)
                break

    if tool_block is None:
        raise RuntimeError(
            f"Claude did not call submit_tasks. Response: {response.content}"
        )

    raw_tasks: list[dict[str, Any]] = tool_block["tasks"]
    if not raw_tasks:
        raise RuntimeError("Claude returned an empty task list.")

    # 6-char project hash prefix makes task IDs globally unique across runs.
    # Two `mini build` calls with identical goals produce different project
    # slugs (timestamp suffix), so their task IDs never clash in the DB.
    proj_hash = hashlib.md5(project.encode()).hexdigest()[:6]

    # Build slug IDs from indices
    raw_slugs = [f"{proj_hash}-{_slugify(t['name'])}" for t in raw_tasks]
    # Ensure uniqueness within the batch when two task names slugify identically
    seen: dict[str, int] = {}
    unique_ids: list[str] = []
    for slug in raw_slugs:
        if slug in seen:
            seen[slug] += 1
            unique_ids.append(f"{slug}-{seen[slug]}")
        else:
            seen[slug] = 0
            unique_ids.append(slug)

    now = datetime.now(timezone.utc).isoformat()

    tasks: list[Task] = []
    for i, raw in enumerate(raw_tasks):
        dep_indices: list[int] = raw.get("dependencies", [])
        # Drop self-deps and out-of-range indices: LLMs occasionally return
        # both. Self-deps make a task permanently unrunnable.
        dep_ids = [
            unique_ids[j]
            for j in dep_indices
            if 0 <= j < len(unique_ids) and j != i
        ]
        tasks.append(
            Task(
                id=unique_ids[i],
                name=raw["name"],
                description=raw["description"],
                status="TODO",
                assigned_to=None,
                dependencies=dep_ids,
                artifacts=[],
                decisions=[],
                created_at=now,
                updated_at=now,
                project=project,
            )
        )

    # Skip appending the auto-README if Claude already generated one
    _readme_keywords = {"readme", "documentation", "docs"}
    _has_readme = any(
        any(kw in t.name.lower() or kw in t.id.lower() for kw in _readme_keywords)
        for t in tasks
    )
    if _has_readme:
        recommended = optimal_agent_count(tasks)
        return tasks, recommended

    # Find leaf tasks (no other task depends on them) and append README task
    all_dep_ids: set[str] = {dep for t in tasks for dep in t.dependencies}
    leaf_ids: list[str] = sorted(t.id for t in tasks if t.id not in all_dep_ids)

    now_str = datetime.now(timezone.utc).isoformat()
    readme_id = f"{proj_hash}-write-project-readme"
    readme_task = Task(
        id=readme_id,
        name="Write Project README",
        description=(
            "Write a comprehensive README.md for the project. "
            "Read all artifacts and decisions logged by other agents using "
            "get_task_context. "
            "Include: project overview, features list, installation instructions, "
            "usage examples with code, how to run and test the project, "
            "and any important architectural decisions made during development. "
            "The README should be clear enough for a new developer to get started "
            "immediately."
        ),
        status="TODO",
        assigned_to=None,
        dependencies=leaf_ids,
        artifacts=[],
        decisions=[],
        created_at=now_str,
        updated_at=now_str,
        project=project,
    )
    tasks.append(readme_task)

    recommended = optimal_agent_count(tasks)
    return tasks, recommended
