"""Marcus Mini — minimal multi-agent coordinator."""

__version__ = "0.1.0"
