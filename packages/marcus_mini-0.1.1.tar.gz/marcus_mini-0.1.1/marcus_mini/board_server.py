"""MCP stdio server exposing board operations to Claude Code agents.

Run as::

    python board_server.py --db ~/.marcus-mini/board.db --project <slug>

Reads JSON-RPC 2.0 requests line-by-line from stdin, writes responses
to stdout (flushed immediately).  Uses synchronous sqlite3 — no async
needed for a single-process stdio server.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from pathlib import Path
from typing import Any

from marcus_mini.board import TaskNotFoundError

# ---------------------------------------------------------------------------
# Inline sync board (avoids importing the async Board class)
# ---------------------------------------------------------------------------


def _connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=10000")
    return conn


def _row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    import json as _json

    return {
        "id": row["id"],
        "name": row["name"],
        "description": row["description"],
        "status": row["status"],
        "assigned_to": row["assigned_to"],
        "dependencies": _json.loads(row["deps"]),
        "artifacts": _json.loads(row["artifacts"]),
        "decisions": _json.loads(row["decisions"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "project": row["project"],
    }


def _now() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()


def op_request_next_task(
    db_path: str, project: str, agent_id: str
) -> dict[str, Any] | None:
    """Claim the next available task under an EXCLUSIVE transaction.

    Parameters
    ----------
    db_path : str
        Path to SQLite database.
    project : str
        Project slug.
    agent_id : str
        Requesting agent identifier.

    Returns
    -------
    dict[str, Any] | None
        Task dict with dependency context injected, or None.
    """
    conn = _connect(db_path)
    try:
        conn.execute("BEGIN EXCLUSIVE")
        row = conn.execute(
            """
            SELECT t.*
            FROM tasks t
            WHERE t.project = ?
              AND t.status = 'TODO'
              AND NOT EXISTS (
                  SELECT 1 FROM json_each(t.deps) AS dep
                  WHERE NOT EXISTS (
                      SELECT 1 FROM tasks d
                      WHERE d.id = dep.value AND d.status = 'DONE'
                  )
              )
            ORDER BY t.created_at
            LIMIT 1
            """,
            (project,),
        ).fetchone()

        if row is None:
            conn.rollback()
            return None

        task_id: str = row["id"]
        now = _now()
        # started_at is only ever set on first claim — needed for bench
        # timing. Use COALESCE so re-claims don't overwrite the original.
        conn.execute(
            "UPDATE tasks "
            "SET status='IN_PROGRESS', assigned_to=?, updated_at=?, "
            "    started_at=COALESCE(started_at, ?) "
            "WHERE id=?",
            (agent_id, now, now, task_id),
        )
        conn.commit()

        task = _row_to_dict(row)
        task["status"] = "IN_PROGRESS"
        task["assigned_to"] = agent_id
        task["updated_at"] = now

        # Inject dependency context
        dep_sections: list[str] = []
        for dep_id in task["dependencies"]:
            dep_row = conn.execute(
                "SELECT * FROM tasks WHERE id=?", (dep_id,)
            ).fetchone()
            if dep_row:
                dep = _row_to_dict(dep_row)
                if dep["artifacts"] or dep["decisions"]:
                    section = f"### {dep_id}\n"
                    if dep["artifacts"]:
                        section += "**Artifacts:**\n" + "\n".join(
                            f"- {a}" for a in dep["artifacts"]
                        )
                    if dep["decisions"]:
                        section += "\n**Decisions:**\n" + "\n".join(
                            f"- {d}" for d in dep["decisions"]
                        )
                    dep_sections.append(section)

        if dep_sections:
            task["description"] = (
                task["description"]
                + "\n\n## Context from completed dependencies\n"
                + "\n".join(dep_sections)
            )
        return task
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def op_log_artifact(db_path: str, task_id: str, content: str) -> None:
    """Append an artifact to a task.

    Parameters
    ----------
    db_path : str
        Path to SQLite database.
    task_id : str
        Target task ID.
    content : str
        Artifact content.
    """
    conn = _connect(db_path)
    try:
        row = conn.execute(
            "SELECT artifacts FROM tasks WHERE id=?", (task_id,)
        ).fetchone()
        if row is None:
            raise TaskNotFoundError(task_id)
        arts: list[str] = json.loads(row["artifacts"])
        arts.append(content)
        conn.execute(
            "UPDATE tasks SET artifacts=?, updated_at=? WHERE id=?",
            (json.dumps(arts), _now(), task_id),
        )
        conn.commit()
    finally:
        conn.close()


def op_log_decision(db_path: str, task_id: str, content: str) -> None:
    """Append a decision to a task.

    Parameters
    ----------
    db_path : str
        Path to SQLite database.
    task_id : str
        Target task ID.
    content : str
        Decision content.
    """
    conn = _connect(db_path)
    try:
        row = conn.execute(
            "SELECT decisions FROM tasks WHERE id=?", (task_id,)
        ).fetchone()
        if row is None:
            raise TaskNotFoundError(task_id)
        decs: list[str] = json.loads(row["decisions"])
        decs.append(content)
        conn.execute(
            "UPDATE tasks SET decisions=?, updated_at=? WHERE id=?",
            (json.dumps(decs), _now(), task_id),
        )
        conn.commit()
    finally:
        conn.close()


def op_report_done(db_path: str, task_id: str, summary: str = "") -> None:
    """Mark a task DONE and optionally append a summary artifact.

    Parameters
    ----------
    db_path : str
        Path to SQLite database.
    task_id : str
        Task to complete.
    summary : str
        Optional summary stored as an artifact.
    """
    conn = _connect(db_path)
    try:
        if summary:
            row = conn.execute(
                "SELECT artifacts FROM tasks WHERE id=?", (task_id,)
            ).fetchone()
            if row is None:
                raise TaskNotFoundError(task_id)
            arts: list[str] = json.loads(row["artifacts"])
            arts.append(summary)
            conn.execute(
                "UPDATE tasks SET status='DONE', artifacts=?, updated_at=? "
                "WHERE id=?",
                (json.dumps(arts), _now(), task_id),
            )
        else:
            conn.execute(
                "UPDATE tasks SET status='DONE', updated_at=? WHERE id=?",
                (_now(), task_id),
            )
        conn.commit()
    finally:
        conn.close()


def op_get_task_context(
    db_path: str, task_id: str
) -> dict[str, Any]:
    """Return a task plus artifacts/decisions from its dependencies.

    Parameters
    ----------
    db_path : str
        Path to SQLite database.
    task_id : str
        Task to look up.

    Returns
    -------
    dict[str, Any]
        ``{"task": ..., "dependencies": {dep_id: {...}}}``.
    """
    conn = _connect(db_path)
    try:
        row = conn.execute(
            "SELECT * FROM tasks WHERE id=?", (task_id,)
        ).fetchone()
        if row is None:
            return {}
        task = _row_to_dict(row)
        dep_context: dict[str, dict[str, Any]] = {}
        for dep_id in task["dependencies"]:
            dep_row = conn.execute(
                "SELECT * FROM tasks WHERE id=?", (dep_id,)
            ).fetchone()
            if dep_row:
                dep = _row_to_dict(dep_row)
                dep_context[dep_id] = {
                    "name": dep["name"],
                    "status": dep["status"],
                    "artifacts": dep["artifacts"],
                    "decisions": dep["decisions"],
                }
        return {"task": task, "dependencies": dep_context}
    finally:
        conn.close()


def op_project_status(db_path: str, project: str) -> dict[str, Any]:
    """Return task counts by status plus a terminal flag.

    Used by agents to decide when it is safe to exit. Without this an
    agent that polls and gets null cannot tell the difference between
    "all tasks finished" and "tasks remain but are blocked behind work
    held by another agent".

    Parameters
    ----------
    db_path : str
        SQLite database path.
    project : str
        Project slug.

    Returns
    -------
    dict[str, Any]
        {"todo": int, "in_progress": int, "done": int, "failed": int,
         "all_terminal": bool}. all_terminal is true when there are no
        TODO or IN_PROGRESS tasks left — i.e., it is correct to exit.
    """
    conn = _connect(db_path)
    try:
        rows = conn.execute(
            "SELECT status, COUNT(*) AS c FROM tasks "
            "WHERE project = ? GROUP BY status",
            (project,),
        ).fetchall()
        counts = {"todo": 0, "in_progress": 0, "done": 0, "failed": 0}
        for r in rows:
            key = str(r["status"]).lower()
            if key in counts:
                counts[key] = int(r["c"])
        counts["all_terminal"] = (counts["todo"] + counts["in_progress"]) == 0
        return counts
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------

_TOOLS = [
    {
        "name": "request_next_task",
        "description": (
            "Claim the next available task on the board. "
            "Returns the task object or null if no tasks are ready."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {
                    "type": "string",
                    "description": "Unique identifier for this agent.",
                }
            },
            "required": ["agent_id"],
        },
    },
    {
        "name": "log_artifact",
        "description": "Store an artifact string on a task for downstream agents.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["task_id", "content"],
        },
    },
    {
        "name": "log_decision",
        "description": "Record an architectural decision on a task.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["task_id", "content"],
        },
    },
    {
        "name": "report_done",
        "description": "Mark a task as DONE, unblocking dependent tasks.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string"},
                "summary": {
                    "type": "string",
                    "description": "Optional completion summary stored as artifact.",
                },
            },
            "required": ["task_id"],
        },
    },
    {
        "name": "get_task_context",
        "description": (
            "Return the task plus artifacts/decisions from completed dependencies."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"task_id": {"type": "string"}},
            "required": ["task_id"],
        },
    },
    {
        "name": "project_status",
        "description": (
            "Return task counts by status (todo/in_progress/done/failed) "
            "plus an all_terminal flag. Use this BEFORE exiting on null "
            "to confirm work is truly complete vs just blocked behind "
            "tasks held by other agents."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
]


# ---------------------------------------------------------------------------
# JSON-RPC dispatch
# ---------------------------------------------------------------------------


def _make_result(req_id: Any, result: Any) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def _make_error(req_id: Any, code: int, message: str) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": code, "message": message},
    }


def _send(obj: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(obj) + "\n")
    sys.stdout.flush()


def _handle(
    request: dict[str, Any], db_path: str, project: str
) -> dict[str, Any] | None:
    """Dispatch a single JSON-RPC request.

    Parameters
    ----------
    request : dict[str, Any]
        Parsed JSON-RPC 2.0 request object.
    db_path : str
        SQLite database path.
    project : str
        Active project slug.

    Returns
    -------
    dict[str, Any] | None
        JSON-RPC response, or None for notifications (no id).
    """
    method: str = request.get("method", "")
    req_id: Any = request.get("id")
    params: dict[str, Any] = request.get("params", {})

    # Notifications have no id — no response required
    is_notification = "id" not in request

    try:
        if method == "initialize":
            result = {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "mini-board", "version": "0.1.0"},
            }
            return None if is_notification else _make_result(req_id, result)

        if method == "notifications/initialized":
            return None

        if method == "tools/list":
            return _make_result(req_id, {"tools": _TOOLS})

        if method == "tools/call":
            tool_name: str = params.get("name", "")
            args: dict[str, Any] = params.get("arguments", {})

            if tool_name == "request_next_task":
                task = op_request_next_task(
                    db_path, project, args["agent_id"]
                )
                content = json.dumps(task)
                return _make_result(
                    req_id,
                    {"content": [{"type": "text", "text": content}]},
                )

            if tool_name == "log_artifact":
                op_log_artifact(db_path, args["task_id"], args["content"])
                return _make_result(
                    req_id,
                    {"content": [{"type": "text", "text": "ok"}]},
                )

            if tool_name == "log_decision":
                op_log_decision(db_path, args["task_id"], args["content"])
                return _make_result(
                    req_id,
                    {"content": [{"type": "text", "text": "ok"}]},
                )

            if tool_name == "report_done":
                op_report_done(
                    db_path,
                    args["task_id"],
                    args.get("summary", ""),
                )
                return _make_result(
                    req_id,
                    {"content": [{"type": "text", "text": "ok"}]},
                )

            if tool_name == "get_task_context":
                ctx = op_get_task_context(db_path, args["task_id"])
                return _make_result(
                    req_id,
                    {"content": [{"type": "text", "text": json.dumps(ctx)}]},
                )

            if tool_name == "project_status":
                status = op_project_status(db_path, project)
                return _make_result(
                    req_id,
                    {"content": [{"type": "text", "text": json.dumps(status)}]},
                )

            return _make_error(req_id, -32601, f"Unknown tool: {tool_name}")

        return _make_error(req_id, -32601, f"Method not found: {method}")

    except Exception as exc:
        return _make_error(req_id, -32603, str(exc))


def main() -> None:
    """Entry point: parse args and serve JSON-RPC over stdio."""
    parser = argparse.ArgumentParser(
        description="MCP stdio board server for marcus-mini"
    )
    parser.add_argument(
        "--db",
        default=str(Path.home() / ".marcus-mini" / "board.db"),
        help="Path to SQLite database",
    )
    parser.add_argument(
        "--project",
        required=True,
        help="Project slug to serve",
    )
    args = parser.parse_args()

    db_path: str = str(Path(args.db).expanduser())
    project: str = args.project

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
        except json.JSONDecodeError as exc:
            _send(_make_error(None, -32700, f"Parse error: {exc}"))
            continue

        response = _handle(request, db_path, project)
        if response is not None:
            _send(response)


if __name__ == "__main__":
    main()
