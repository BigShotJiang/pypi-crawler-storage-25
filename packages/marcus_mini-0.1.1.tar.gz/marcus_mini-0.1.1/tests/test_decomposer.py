"""Unit tests for marcus_mini.decomposer.

All Claude API calls are mocked. Tests verify schema correctness,
dependency resolution, and the optimal_agent_count algorithm.
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from marcus_mini.decomposer import decompose, optimal_agent_count
from marcus_mini.models import Task


def _proj_hash(project: str) -> str:
    """Return the 6-char MD5 prefix used by decompose() for task IDs."""
    return hashlib.md5(project.encode()).hexdigest()[:6]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_response(raw_tasks: list[dict[str, Any]]) -> MagicMock:
    """Build a mock anthropic response that returns the given raw task list.

    Parameters
    ----------
    raw_tasks : list[dict[str, Any]]
        The task dicts that will appear in the tool_use block.

    Returns
    -------
    MagicMock
        Mock mimicking anthropic.types.Message.
    """
    tool_block = MagicMock()
    tool_block.type = "tool_use"
    tool_block.name = "submit_tasks"
    tool_block.input = {"tasks": raw_tasks}

    response = MagicMock()
    response.content = [tool_block]
    return response


def _make_task(
    task_id: str,
    deps: list[str] | None = None,
) -> Task:
    """Build a minimal Task for algorithm tests.

    Parameters
    ----------
    task_id : str
        Task identifier.
    deps : list[str] | None
        Dependency IDs.

    Returns
    -------
    Task
        Minimal populated Task.
    """
    now = datetime.now(timezone.utc).isoformat()
    return Task(
        id=task_id,
        name=task_id,
        description="",
        status="TODO",
        assigned_to=None,
        dependencies=deps or [],
        artifacts=[],
        decisions=[],
        created_at=now,
        updated_at=now,
        project="test",
    )


# ---------------------------------------------------------------------------
# Tests for decompose()
# ---------------------------------------------------------------------------


class TestDecompose:
    """Tests for the decompose() function."""

    @patch.dict("os.environ", {"MINI_API_KEY": "test-key"})
    @patch("marcus_mini.decomposer.anthropic.Anthropic")
    def test_decompose_returns_tasks_with_correct_schema(
        self, mock_anthropic_cls: MagicMock
    ) -> None:
        """Test that decompose returns Task objects with expected fields."""
        # Arrange
        raw = [
            {"name": "Setup DB", "description": "Create the schema.", "dependencies": []},
            {"name": "Build API", "description": "REST endpoints.", "dependencies": [0]},
        ]
        mock_client = MagicMock()
        mock_client.messages.create.return_value = _make_mock_response(raw)
        mock_anthropic_cls.return_value = mock_client

        # Act
        tasks, recommended = decompose("Build a TODO app", project="todo-app")

        # Assert schema — 2 original tasks + 1 auto-appended README task
        assert len(tasks) == 3
        task = tasks[0]
        assert task.id == f"{_proj_hash('todo-app')}-setup-db"
        assert task.name == "Setup DB"
        assert task.description == "Create the schema."
        assert task.status == "TODO"
        assert task.assigned_to is None
        assert task.project == "todo-app"
        assert isinstance(task.dependencies, list)
        assert isinstance(task.artifacts, list)
        assert isinstance(task.decisions, list)
        assert isinstance(recommended, int)

    @patch.dict("os.environ", {"MINI_API_KEY": "test-key"})
    @patch("marcus_mini.decomposer.anthropic.Anthropic")
    def test_dependency_indices_resolved_to_ids(
        self, mock_anthropic_cls: MagicMock
    ) -> None:
        """Test that integer dependency indices are converted to task ID slugs."""
        # Arrange
        raw = [
            {"name": "Task Alpha", "description": "First.", "dependencies": []},
            {"name": "Task Beta", "description": "Second.", "dependencies": [0]},
            {"name": "Task Gamma", "description": "Third.", "dependencies": [0, 1]},
        ]
        mock_client = MagicMock()
        mock_client.messages.create.return_value = _make_mock_response(raw)
        mock_anthropic_cls.return_value = mock_client

        # Act
        tasks, _ = decompose("something", project="proj")

        # Assert
        h = _proj_hash("proj")
        assert tasks[0].dependencies == []
        assert tasks[1].dependencies == [f"{h}-task-alpha"]
        assert tasks[2].dependencies == [f"{h}-task-alpha", f"{h}-task-beta"]

    @patch.dict("os.environ", {"MINI_API_KEY": "test-key"})
    @patch("marcus_mini.decomposer.anthropic.Anthropic")
    def test_optimal_agent_count_returned(
        self, mock_anthropic_cls: MagicMock
    ) -> None:
        """Test that recommended agent count is returned as second tuple element."""
        raw = [
            {"name": "A", "description": ".", "dependencies": []},
            {"name": "B", "description": ".", "dependencies": []},
            {"name": "C", "description": ".", "dependencies": [0, 1]},
        ]
        mock_client = MagicMock()
        mock_client.messages.create.return_value = _make_mock_response(raw)
        mock_anthropic_cls.return_value = mock_client

        tasks, recommended = decompose("goal", project="p")

        # A and B are both runnable at level 0 → width = 2
        assert recommended == 2
        # 3 original tasks + 1 auto-appended README task
        assert len(tasks) == 4

    @patch.dict("os.environ", {}, clear=True)
    def test_raises_value_error_without_api_key(self) -> None:
        """Test that decompose raises ValueError when API key is missing."""
        # Remove key if present
        import os
        os.environ.pop("MINI_API_KEY", None)

        with pytest.raises(ValueError, match="MINI_API_KEY"):
            decompose("goal")

    @patch.dict("os.environ", {"MINI_API_KEY": "test-key"})
    @patch("marcus_mini.decomposer.anthropic.Anthropic")
    def test_raises_runtime_error_when_tool_not_called(
        self, mock_anthropic_cls: MagicMock
    ) -> None:
        """Test that RuntimeError is raised when Claude skips submit_tasks."""
        # Arrange — response has no tool_use block
        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = "I cannot help with that."

        response = MagicMock()
        response.content = [text_block]

        mock_client = MagicMock()
        mock_client.messages.create.return_value = response
        mock_anthropic_cls.return_value = mock_client

        # Act / Assert
        with pytest.raises(RuntimeError, match="submit_tasks"):
            decompose("goal")


# ---------------------------------------------------------------------------
# Tests for optimal_agent_count()
# ---------------------------------------------------------------------------


class TestReadmeTask:
    """Tests for the auto-appended README task in decompose()."""

    @patch.dict("os.environ", {"MINI_API_KEY": "test-key"})
    @patch("marcus_mini.decomposer.anthropic.Anthropic")
    def test_readme_task_appended_as_last_task(
        self, mock_anthropic_cls: MagicMock
    ) -> None:
        """Test that a 'Write Project README' task is the last task returned."""
        raw = [
            {
                "name": "Setup DB",
                "description": "Create schema.",
                "dependencies": [],
            },
            {
                "name": "Build API",
                "description": "REST endpoints.",
                "dependencies": [0],
            },
        ]
        mock_client = MagicMock()
        mock_client.messages.create.return_value = _make_mock_response(raw)
        mock_anthropic_cls.return_value = mock_client

        tasks, _ = decompose("Build a TODO app", project="todo-app")

        # Should have 3 tasks: 2 original + README
        assert len(tasks) == 3
        last = tasks[-1]
        assert last.name == "Write Project README"
        assert last.id == f"{_proj_hash('todo-app')}-write-project-readme"

    @patch.dict("os.environ", {"MINI_API_KEY": "test-key"})
    @patch("marcus_mini.decomposer.anthropic.Anthropic")
    def test_readme_depends_on_leaf_tasks(
        self, mock_anthropic_cls: MagicMock
    ) -> None:
        """Test that README task depends on all leaf tasks in the DAG.

        In a linear chain A → B → C, only C is a leaf (nothing depends on C
        except the README task itself). README should depend on ['build-api'].
        In a fork A → (B, C), both B and C are leaves.
        """
        # Fork shape: setup-db → (build-api, add-auth)
        raw = [
            {
                "name": "Setup DB",
                "description": "Schema.",
                "dependencies": [],
            },
            {
                "name": "Build API",
                "description": "Endpoints.",
                "dependencies": [0],
            },
            {
                "name": "Add Auth",
                "description": "Auth layer.",
                "dependencies": [0],
            },
        ]
        mock_client = MagicMock()
        mock_client.messages.create.return_value = _make_mock_response(raw)
        mock_anthropic_cls.return_value = mock_client

        tasks, _ = decompose("Build a TODO app", project="todo-app")

        readme = tasks[-1]
        assert readme.name == "Write Project README"
        # Both build-api and add-auth are leaves (nothing original depends on them)
        h = _proj_hash("todo-app")
        assert sorted(readme.dependencies) == sorted(
            [f"{h}-add-auth", f"{h}-build-api"]
        )

    @patch.dict("os.environ", {"MINI_API_KEY": "test-key"})
    @patch("marcus_mini.decomposer.anthropic.Anthropic")
    def test_readme_has_correct_project_slug(
        self, mock_anthropic_cls: MagicMock
    ) -> None:
        """Test that the README task carries the correct project slug."""
        raw = [
            {
                "name": "Task A",
                "description": "First.",
                "dependencies": [],
            },
        ]
        mock_client = MagicMock()
        mock_client.messages.create.return_value = _make_mock_response(raw)
        mock_anthropic_cls.return_value = mock_client

        tasks, _ = decompose("My project", project="my-proj")

        readme = tasks[-1]
        assert readme.project == "my-proj"
        assert readme.status == "TODO"
        assert readme.assigned_to is None


class TestOptimalAgentCount:
    """Tests for the optimal_agent_count() algorithm."""

    def test_single_task_returns_one(self) -> None:
        """Test that a single task yields agent count of 1."""
        tasks = [_make_task("a")]
        assert optimal_agent_count(tasks) == 1

    def test_optimal_agent_count_equals_dag_width(self) -> None:
        """Test that the agent count equals the maximum DAG level width.

        DAG shape:
          a ──┐
              ├── c (level 1, width 2: a and b)
          b ──┘
        """
        tasks = [
            _make_task("a"),
            _make_task("b"),
            _make_task("c", deps=["a", "b"]),
        ]
        # Level 0: a, b (width=2); Level 1: c (width=1)
        assert optimal_agent_count(tasks) == 2

    def test_linear_chain_returns_one(self) -> None:
        """Test that a strict linear dependency chain yields agent count 1."""
        tasks = [
            _make_task("a"),
            _make_task("b", deps=["a"]),
            _make_task("c", deps=["b"]),
        ]
        assert optimal_agent_count(tasks) == 1

    def test_wide_dag_capped_at_max_cap(self) -> None:
        """Test that agent count is capped at max_cap."""
        # 10 independent tasks → width 10, capped at 6 (default)
        tasks = [_make_task(f"t{i}") for i in range(10)]
        assert optimal_agent_count(tasks) == 6

    def test_max_cap_override(self) -> None:
        """Test that a custom max_cap is respected."""
        tasks = [_make_task(f"t{i}") for i in range(10)]
        assert optimal_agent_count(tasks, max_cap=3) == 3

    def test_diamond_dag_width(self) -> None:
        """Test agent count for diamond-shaped DAG (width = 2 at middle level).

        Shape: root → (left, right) → tip
        """
        tasks = [
            _make_task("root"),
            _make_task("left", deps=["root"]),
            _make_task("right", deps=["root"]),
            _make_task("tip", deps=["left", "right"]),
        ]
        # Level 0: root (1); Level 1: left, right (2); Level 2: tip (1)
        assert optimal_agent_count(tasks) == 2

    def test_empty_task_list_returns_one(self) -> None:
        """Test that an empty task list returns 1 (minimum)."""
        assert optimal_agent_count([]) == 1
