const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const SIGNAL_DIR = path.join(os.homedir(), '.arrayview');
const SIGNAL_FILE = path.join(SIGNAL_DIR, 'open-request-v0900.json');  // fallback
const LOG_FILE = path.join(SIGNAL_DIR, 'extension.log');

// Per-window targeted signal file: Python writes to a file named by the SHA256
// of VSCODE_IPC_HOOK_CLI, which is unique per VS Code window on the remote.
// The extension checks its own targeted file first, then the fallback.
//
// On LOCAL VS Code desktop the extension host may not inherit VSCODE_IPC_HOOK_CLI
// directly, so we also walk parent processes to find it — the same approach
// Python uses in _platform._find_vscode_ipc_hook().
function _findVscodeIpcHook() {
    const direct = process.env.VSCODE_IPC_HOOK_CLI || '';
    if (direct && fs.existsSync(direct)) return direct;
    // Walk up to 8 ancestor processes looking for VSCODE_IPC_HOOK_CLI.
    let pid = process.pid;
    for (let i = 0; i < 8; i++) {
        const ppidRes = spawnSync('ps', ['-p', String(pid), '-o', 'ppid='],
            { encoding: 'utf8', timeout: 2000 });
        const ppid = parseInt((ppidRes.stdout || '').trim(), 10);
        if (!ppid || ppid <= 1) break;
        const envRes = spawnSync('ps', ['ewwww', '-p', String(ppid)],
            { encoding: 'utf8', timeout: 3000 });
        for (const token of (envRes.stdout || '').split(/\s+/)) {
            if (token.startsWith('VSCODE_IPC_HOOK_CLI=')) {
                const val = token.slice('VSCODE_IPC_HOOK_CLI='.length);
                if (val && fs.existsSync(val)) return val;
            }
        }
        pid = ppid;
    }
    return '';
}

const OWN_IPC_HOOK = _findVscodeIpcHook();
const OWN_HOOK_TAG = OWN_IPC_HOOK
    ? crypto.createHash('sha256').update(OWN_IPC_HOOK).digest('hex').slice(0, 16)
    : '';
// Targeted signal file: prefer IPC hook-based, fallback to PID-based for local desktop.
// This enables multi-window targeting even when VSCODE_IPC_HOOK_CLI isn't available.
const TARGETED_SIGNAL_FILE = OWN_HOOK_TAG
    ? path.join(SIGNAL_DIR, `open-request-ipc-${OWN_HOOK_TAG}.json`)
    : path.join(SIGNAL_DIR, `open-request-pid-${process.pid}.json`);

// Collect ancestor PIDs for cross-process window matching.
// Python can identify which VS Code window spawned a given terminal by finding
// the window whose extension host shares a common ancestor with the terminal process.
// Records up to 8 levels: [ppid, pppid, ...] stopping before PID 1.
function _getAncestorPids(pid, depth) {
    const result = [];
    let p = pid;
    for (let i = 0; i < depth; i++) {
        const res = spawnSync('ps', ['-p', String(p), '-o', 'ppid='],
            { encoding: 'utf8', timeout: 1000 });
        const ppid = parseInt((res.stdout || '').trim(), 10);
        if (!ppid || ppid <= 1) break;
        result.push(ppid);
        p = ppid;
    }
    return result;
}
const EXT_PPIDS = _getAncestorPids(process.pid, 8);

let version = 'unknown';
let isProcessingSignal = false;
let lastHandledRequestId = null;
let lastHandledUrl = null;
let lastHandledAt = 0;

// Track open webview panels by URL so we can reveal instead of re-creating.
const _openPanels = new Map(); // url -> vscode.WebviewPanel

function log(message) {
    const line = `[${new Date().toISOString()}] ${message}\n`;
    try { fs.appendFileSync(LOG_FILE, line); } catch (_) {}
    console.log(`[arrayview-opener] ${message}`);
}

function isExpiredSignal(data) {
    const sentAtMs = Number(data.sentAtMs || 0);
    const maxAgeMs = Number(data.maxAgeMs || 15000);
    if (!sentAtMs || maxAgeMs <= 0) return false;
    const ageMs = Date.now() - sentAtMs;
    if (ageMs <= maxAgeMs) return false;
    log(`SIGNAL: expired ageMs=${ageMs} maxAgeMs=${maxAgeMs}`);
    return true;
}

function isProcessAlive(pid) {
    try { process.kill(pid, 0); return true; } catch { return false; }
}

function cleanupStaleFiles() {
    // Remove stale .claimed-* and .tmp files left behind by crashes.
    // Also remove window-*.json registration files for dead processes.
    try {
        const files = fs.readdirSync(SIGNAL_DIR);
        for (const f of files) {
            if (f.startsWith('open-request-') && (f.includes('.claimed-') || f.endsWith('.tmp'))) {
                try {
                    fs.unlinkSync(path.join(SIGNAL_DIR, f));
                    log(`CLEANUP: removed stale file ${f}`);
                } catch (_) {}
            }
            if (f.startsWith('window-') && f.endsWith('.json')) {
                try {
                    const data = JSON.parse(fs.readFileSync(path.join(SIGNAL_DIR, f), 'utf8'));
                    if (data.pid && !isProcessAlive(data.pid)) {
                        fs.unlinkSync(path.join(SIGNAL_DIR, f));
                        log(`CLEANUP: removed stale registration ${f} (pid ${data.pid} dead)`);
                    }
                } catch (_) {}
            }
        }
    } catch (_) {}
}

// Shared-fallback files: any window may claim these, so we must verify hookTag.
const SHARED_FALLBACK_BASENAMES = new Set([
    path.basename(SIGNAL_FILE),
    'open-request-v0800.json',
    'open-request-v0400.json',
]);

async function tryOpenSignalFile() {
    // If we are currently showing a URL, leave any pending signal files on disk.
    // The 1-second polling loop will pick them up once we are done.  This avoids
    // in-memory queues that can be lost when the extension host reloads.
    if (isProcessingSignal) return;

    // Check targeted file first (matches our window's IPC hook or PID), then primary,
    // then compat signal files for older/published arrayview Python versions.
    const candidates = [];
    if (TARGETED_SIGNAL_FILE) candidates.push(TARGETED_SIGNAL_FILE);
    candidates.push(
        SIGNAL_FILE,
        path.join(SIGNAL_DIR, 'open-request-v0800.json'),
        path.join(SIGNAL_DIR, 'open-request-v0400.json'),
    );

    // Multi-window race mitigation: if this window is not focused, add a small delay
    // before claiming shared files. This gives the focused window a chance to claim first.
    const isFocused = vscode.window.state.focused;
    const isOwnTargetedFile = (f) => TARGETED_SIGNAL_FILE && f === TARGETED_SIGNAL_FILE;

    for (const signalFile of candidates) {
        // If not our targeted file and window not focused, delay briefly
        if (!isOwnTargetedFile(signalFile) && !isFocused) {
            await new Promise(resolve => setTimeout(resolve, 100));
        }

        const claimedFile = signalFile + '.claimed-' + process.pid;
        let raw;
        try {
            fs.renameSync(signalFile, claimedFile);
        } catch {
            continue;  // file doesn't exist or claimed by another window
        }
        try {
            raw = fs.readFileSync(claimedFile, 'utf8');
        } catch (e) {
            log(`ERROR: read claimed file failed: ${e.message}`);
            try { fs.unlinkSync(claimedFile); } catch (_) {}
            continue;
        }

        let data;
        try { data = JSON.parse(raw); } catch (err) {
            log(`SIGNAL: invalid JSON: ${err.message}`);
            try { fs.unlinkSync(claimedFile); } catch (_) {}
            continue;
        }

        // --- Multi-window guard ---
        // If a shared fallback file carries a hookTag that doesn't match ours,
        // it was written by Python for a different VS Code window.  Forward it
        // to that window's targeted file so the correct extension instance picks
        // it up, then skip processing here.
        const isSharedFallback = SHARED_FALLBACK_BASENAMES.has(path.basename(signalFile));
        if (isSharedFallback && data.hookTag && OWN_HOOK_TAG && data.hookTag !== OWN_HOOK_TAG) {
            log(`SIGNAL: hookTag mismatch (ours=${OWN_HOOK_TAG} signal=${data.hookTag}), forwarding to correct window`);
            const targetedFile = path.join(SIGNAL_DIR, `open-request-ipc-${data.hookTag}.json`);
            const tmp = targetedFile + '.tmp';
            try {
                fs.writeFileSync(tmp, JSON.stringify(data));
                fs.renameSync(tmp, targetedFile);
                log(`SIGNAL: forwarded to ${path.basename(targetedFile)}`);
            } catch (_) {}
            try { fs.unlinkSync(claimedFile); } catch (_) {}
            continue;
        }

        // --- Broadcast guard ---
        // If this signal is marked as broadcast (Python couldn't determine which window
        // to target), only process it if this window is currently focused. This ensures
        // only the active window opens the viewer when multiple windows are open.
        if (data.broadcast === true && !isFocused) {
            log(`SIGNAL: broadcast signal skipped (window not focused)`);
            try { fs.unlinkSync(claimedFile); } catch (_) {}
            continue;
        }

        try { fs.unlinkSync(claimedFile); } catch (_) {}

        if (isExpiredSignal(data)) continue;

        try {
            await processSignalData(data);
        } catch (error) {
            log(`ERROR: ${error.message}`);
        }
        return;  // processed one signal, done for this tick
    }
}

// Open or reveal a VS Code WebviewPanel for the given URL.
// Using createWebviewPanel instead of simpleBrowser.show lets us set a custom
// tab title (e.g. "ArrayView: sample.npy").  The webview just wraps the
// arrayview server URL in a full-page iframe.
function openInWebviewPanel(url, title) {
    const label = title || 'ArrayView';

    // Reveal existing panel for this URL if still open.
    const existing = _openPanels.get(url);
    if (existing) {
        try {
            existing.reveal(undefined, false);
            log(`PANEL: revealed existing panel for ${url}`);
            return;
        } catch (_) {
            _openPanels.delete(url);
        }
    }

    const viewColumn = vscode.window.activeTextEditor
        ? vscode.ViewColumn.Beside
        : vscode.ViewColumn.Active;

    const panel = vscode.window.createWebviewPanel(
        'arrayview.preview',
        label,
        { viewColumn, preserveFocus: false },
        {
            enableScripts: true,
            enableForms: true,
            retainContextWhenHidden: true,
        }
    );

    // Use a nonce so the CSP allows exactly our inline script and nothing else.
    // The iframe src is set via JS (not as an HTML attribute) to avoid any
    // attribute-encoding issues and to match VS Code's own Simple Browser pattern.
    const nonce = crypto.randomBytes(16).toString('hex');
    const jsonUrl = JSON.stringify(url); // safe JS string literal embedding

    panel.webview.html = `<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Security-Policy"
      content="default-src 'none'; frame-src *; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';">
<style>
  html, body { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; }
  iframe { position: fixed; top: 0; left: 0; width: 100%; height: 100%; border: none; }
</style>
</head>
<body>
<iframe id="f" sandbox="allow-scripts allow-forms allow-same-origin allow-downloads"></iframe>
<script nonce="${nonce}">document.getElementById('f').src = ${jsonUrl};</script>
</body>
</html>`;

    _openPanels.set(url, panel);
    panel.onDidDispose(() => _openPanels.delete(url));
    log(`PANEL: created "${label}" for ${url}`);
}

async function processSignalData(data) {
    isProcessingSignal = true;
    try {
        const url = data.url;
        if (!url) { log('SIGNAL: missing url'); return; }

        const requestId = data.requestId || null;
        const now = Date.now();
        if (requestId && requestId === lastHandledRequestId) {
            log(`SIGNAL: duplicate requestId ignored: ${requestId}`);
            return;
        }
        if (!requestId && url === lastHandledUrl && now - lastHandledAt < 5000) {
            log(`SIGNAL: duplicate url ignored within debounce window`);
            return;
        }

        log(`SIGNAL: requestId=${requestId || 'none'} url=${url} title=${data.title || '(none)'}`);
        lastHandledRequestId = requestId;
        lastHandledUrl = url;
        lastHandledAt = now;

        let openUrl = url;
        if (vscode.env.remoteName) {
            // Remote / tunnel: asExternalUri converts the localhost URL to the
            // public devtunnel URL (e.g. https://HOST-8000.euw.devtunnels.ms/).
            // VS Code strips query strings during this conversion, so we extract
            // ?sid=... from the original URL and re-append it manually.
            let port = 8000;
            try { port = parseInt(new URL(url).port, 10) || 8000; } catch (_) {}
            let origQuery = '';
            try { origQuery = new URL(url).search; } catch (_) {}

            try {
                const baseUri = vscode.Uri.parse(`http://localhost:${port}/`);
                log(`REMOTE: asExternalUri(http://localhost:${port}/)...`);
                const externalUri = await Promise.race([
                    vscode.env.asExternalUri(baseUri),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('asExternalUri timeout after 8s')), 8000)),
                ]);
                const externalBase = externalUri.toString().replace(/\/$/, '');
                log(`REMOTE: → ${externalBase}`);
                openUrl = externalBase + '/' + origQuery;
                log(`REMOTE: final URL = ${openUrl}`);
            } catch (err) {
                log(`REMOTE: asExternalUri failed (${err.message}), using localhost`);
                openUrl = url;
            }
        }

        log(`openInWebviewPanel(${openUrl})`);
        openInWebviewPanel(openUrl, data.title);
        log('openInWebviewPanel done');
    } catch (error) {
        log(`ERROR: ${error.message}`);
    } finally {
        isProcessingSignal = false;
        // Signal files for subsequent arrays remain on disk; the 1-second poll
        // will pick them up now that isProcessingSignal is false again.
    }
}

function activate(context) {
    version = context.extension.packageJSON.version;
    log(`=== ACTIVATE v${version} ===`);
    log(`remoteName=${vscode.env.remoteName} appHost=${vscode.env.appHost}`);
    log(`ipcHook=${OWN_IPC_HOOK || 'NOT_SET'} hookTag=${OWN_HOOK_TAG || 'none'}`);
    if (TARGETED_SIGNAL_FILE) {
        log(`targetedFile=${path.basename(TARGETED_SIGNAL_FILE)}`);
    } else {
        log(`targetedFile=none (will use shared fallback only)`);
    }

    try { fs.mkdirSync(SIGNAL_DIR, { recursive: true }); } catch (_) {}

    // Write registration so Python can find this window's hookTag or PID.
    // Python reads ~/.arrayview/window-<hookTag>.json to know which targeted
    // signal file to write for this specific VS Code window.
    // Fallback: use PID when IPC hook isn't available (local macOS/Windows).
    const windowId = OWN_HOOK_TAG || String(process.pid);
    const regFile = path.join(SIGNAL_DIR, `window-${windowId}.json`);
    try {
        fs.writeFileSync(regFile, JSON.stringify({
            hookTag: OWN_HOOK_TAG || '',
            pid: process.pid,
            ppids: EXT_PPIDS,   // ancestor PIDs for multi-window matching by Python
            ts: Date.now(),
            fallbackId: !OWN_HOOK_TAG  // true if using PID fallback
        }));
        log(`REGISTER: wrote ${path.basename(regFile)} (${OWN_HOOK_TAG ? 'hookTag' : 'PID fallback'})`);
        context.subscriptions.push({ dispose: () => {
            try { fs.unlinkSync(regFile); } catch (_) {}
            log(`REGISTER: deleted ${path.basename(regFile)}`);
        }});
    } catch (e) {
        log(`REGISTER: failed to write: ${e.message}`);
    }

    cleanupStaleFiles();

    void tryOpenSignalFile();

    const interval = setInterval(() => void tryOpenSignalFile(), 1000);
    context.subscriptions.push({ dispose: () => clearInterval(interval) });

    try {
        const ownBasename = TARGETED_SIGNAL_FILE ? path.basename(TARGETED_SIGNAL_FILE) : null;
        const watcher = fs.watch(SIGNAL_DIR, (eventType, filename) => {
            if (!filename || filename.includes('.claimed-') || filename.endsWith('.tmp')) return;
            const isOwn = ownBasename && filename === ownBasename;
            const isFallback = filename === path.basename(SIGNAL_FILE) ||
                               filename === 'open-request-v0800.json' ||
                               filename === 'open-request-v0400.json';
            if (isOwn || isFallback) {
                log(`WATCH: event=${eventType} file=${filename}`);
                setTimeout(() => void tryOpenSignalFile(), 100);
            }
        });
        context.subscriptions.push({ dispose: () => watcher.close() });
        log(`WATCH: fs.watch active on ${SIGNAL_DIR}`);
    } catch (err) {
        log(`WATCH: fs.watch failed (polling still active): ${err.message}`);
    }

    log('=== ACTIVATE DONE ===');
}

function deactivate() {
    log(`deactivate v${version}`);
}

module.exports = { activate, deactivate };
