"use strict";

/**
 * PlatformProvider base class.
 *
 * Abstracts OS-specific QEMU VM operations so that macOS works now and
 * Windows (or other platforms) can be added later by subclassing this
 * interface and implementing every method.
 */
class PlatformProvider {
  /**
   * Check whether all prerequisites required to run a VM are present.
   *
   * @returns {{ qemu: boolean, firmware: boolean, errors: string[] }}
   */
  checkPrerequisites() {
    throw new Error("Not implemented");
  }

  /**
   * Return the absolute path to the QEMU binary for this platform.
   *
   * @returns {string}
   */
  getQemuBinary() {
    throw new Error("Not implemented");
  }

  /**
   * Return the base QEMU command-line arguments for this platform.
   *
   * @param {{ memoryGB: number, cpuCount: number }} config
   * @returns {string[]}
   */
  getQemuBaseArgs(config) {
    throw new Error("Not implemented");
  }

  /**
   * Return paths to the UEFI firmware files required to boot the VM.
   *
   * @returns {{ code: string, varsTemplate: string }}
   */
  getFirmwarePaths() {
    throw new Error("Not implemented");
  }

  /**
   * Create a cloud-init seed ISO image.
   *
   * @param {{ userDataContent: string, metaDataContent: string, destPath: string }} opts
   * @returns {Promise<string>} Resolves to the final ISO path.
   */
  createSeedISO({ userDataContent, metaDataContent, destPath }) {
    throw new Error("Not implemented");
  }

  /**
   * Return QEMU arguments that expose host directories to the guest via
   * the virtio-9p file-share mechanism.
   *
   * @param {Array<{ hostPath: string, guestTag: string }>} folders
   * @returns {string[]}
   */
  getFileShareArgs(folders) {
    throw new Error("Not implemented");
  }

  /**
   * Return fstab-style lines that the guest can use to mount the shared
   * directories exposed by getFileShareArgs().
   *
   * @param {Array<{ hostPath: string, guestTag: string }>} folders
   * @returns {string[]}
   */
  getGuestMountCommands(folders) {
    throw new Error("Not implemented");
  }

  /**
   * Terminate a process by PID, escalating from SIGTERM to SIGKILL if
   * the process does not exit within the allotted grace period.
   *
   * @param {number} pid
   * @returns {Promise<void>}
   */
  killProcess(pid) {
    throw new Error("Not implemented");
  }

  /**
   * Return the guest CPU architecture string.
   *
   * @returns {"aarch64" | "x86_64"}
   */
  getGuestArch() {
    throw new Error("Not implemented");
  }
}

module.exports = { PlatformProvider };
