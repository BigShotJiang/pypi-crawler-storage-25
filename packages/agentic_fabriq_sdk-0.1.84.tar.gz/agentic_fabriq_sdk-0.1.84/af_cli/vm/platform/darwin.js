"use strict";

const { execFileSync } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { PlatformProvider } = require("./interface");
const {
  QEMU_IMG_BINARY_NAME,
  QEMU_SYSTEM_BINARY_NAME,
  getQemuSystemBinary,
  resolveQemuBinaries,
} = require("../qemu");

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const HOMEBREW_PREFIXES = ["/opt/homebrew", "/usr/local"];
const FIRMWARE_CODE = "share/qemu/edk2-aarch64-code.fd";
const FIRMWARE_VARS = "share/qemu/edk2-arm-vars.fd";

// Grace period (ms) before escalating SIGTERM → SIGKILL
const SIGTERM_TIMEOUT_MS = 8000;
// Poll interval (ms) when waiting for a process to exit
const POLL_INTERVAL_MS = 200;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Check whether a process with the given PID is still alive.
 * @param {number} pid
 * @returns {boolean}
 */
function isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

/**
 * Sleep for `ms` milliseconds.
 * @param {number} ms
 * @returns {Promise<void>}
 */
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ---------------------------------------------------------------------------
// DarwinProvider
// ---------------------------------------------------------------------------

class DarwinProvider extends PlatformProvider {
  // -------------------------------------------------------------------------
  // checkPrerequisites
  // -------------------------------------------------------------------------

  /**
   * Verify that QEMU and the UEFI firmware files are available.
   *
   * @returns {{ qemu: boolean, firmware: boolean, errors: string[] }}
   */
  checkPrerequisites() {
    const errors = [];

    // --- QEMU binaries ---
    const qemuBinaries = resolveQemuBinaries();
    const qemu = qemuBinaries.missing.length === 0;
    if (!qemuBinaries.img) {
      errors.push(
        `${QEMU_IMG_BINARY_NAME} not found. Install QEMU or set AF_QEMU_IMG.`
      );
    }
    if (!qemuBinaries.system) {
      errors.push(
        `${QEMU_SYSTEM_BINARY_NAME} not found. Install QEMU or set AF_QEMU_SYSTEM.`
      );
    }
    if (qemuBinaries.errors.length > 0) {
      errors.push(...qemuBinaries.errors);
    }

    // --- Firmware ---
    let firmware = false;
    try {
      const fw = this.getFirmwarePaths();
      if (fs.existsSync(fw.code) && fs.existsSync(fw.varsTemplate)) {
        firmware = true;
      } else {
        if (!fs.existsSync(fw.code)) {
          errors.push(`UEFI firmware code file not found: ${fw.code}`);
        }
        if (!fs.existsSync(fw.varsTemplate)) {
          errors.push(`UEFI firmware vars template not found: ${fw.varsTemplate}`);
        }
      }
    } catch (err) {
      errors.push(`Could not locate firmware: ${err.message}`);
    }

    return { qemu, firmware, errors };
  }

  // -------------------------------------------------------------------------
  // getQemuBinary
  // -------------------------------------------------------------------------

  /**
   * Return the path to the QEMU binary.
   *
   * @returns {string}
   */
  getQemuBinary() {
    return getQemuSystemBinary();
  }

  // -------------------------------------------------------------------------
  // getQemuBaseArgs
  // -------------------------------------------------------------------------

  /**
   * Return the base QEMU arguments for Apple Silicon Macs (aarch64 + HVF).
   *
   * @param {{ memoryGB: number, cpuCount: number }} config
   * @returns {string[]}
   */
  getQemuBaseArgs({ memoryGB, cpuCount }) {
    return [
      "-M", "virt,highmem=on",
      "-cpu", "host",
      "-accel", "hvf",
      "-m", String(memoryGB * 1024),
      "-smp", String(cpuCount),
    ];
  }

  // -------------------------------------------------------------------------
  // getFirmwarePaths
  // -------------------------------------------------------------------------

  /**
   * Locate the UEFI firmware files under the active Homebrew prefix.
   * Checks /opt/homebrew first (Apple Silicon), then /usr/local (Intel).
   *
   * @returns {{ code: string, varsTemplate: string }}
   * @throws {Error} When no firmware is found in any known prefix.
   */
  getFirmwarePaths() {
    for (const prefix of HOMEBREW_PREFIXES) {
      const code = path.join(prefix, FIRMWARE_CODE);
      const varsTemplate = path.join(prefix, FIRMWARE_VARS);
      if (fs.existsSync(code)) {
        // Return even if varsTemplate doesn't exist yet; caller validates.
        return { code, varsTemplate };
      }
    }

    // Return the Apple Silicon default so callers can surface a useful error.
    const defaultPrefix = HOMEBREW_PREFIXES[0];
    return {
      code: path.join(defaultPrefix, FIRMWARE_CODE),
      varsTemplate: path.join(defaultPrefix, FIRMWARE_VARS),
    };
  }

  // -------------------------------------------------------------------------
  // createSeedISO
  // -------------------------------------------------------------------------

  /**
   * Build a cloud-init seed ISO on macOS using hdiutil + dd.
   *
   * Steps:
   *  1. Create a temp directory.
   *  2. Write user-data and meta-data files into it.
   *  3. Use `hdiutil create` to create an HFS+ image labelled "cidata".
   *  4. Attach the image.
   *  5. Copy the cloud-init files onto the mounted volume.
   *  6. Detach the image.
   *  7. Use `dd` to convert the image to a raw ISO and place it at destPath.
   *  8. Remove the temp directory.
   *
   * @param {{ userDataContent: string, metaDataContent: string, destPath: string }} opts
   * @returns {Promise<string>} Resolves to destPath.
   */
  async createSeedISO({ userDataContent, metaDataContent, destPath }) {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "af-seed-"));

    try {
      // --- Write cloud-init payload files ---
      const userDataFile = path.join(tmpDir, "user-data");
      const metaDataFile = path.join(tmpDir, "meta-data");
      fs.writeFileSync(userDataFile, userDataContent, "utf8");
      fs.writeFileSync(metaDataFile, metaDataContent, "utf8");

      // --- Create a raw FAT (MS-DOS) disk image labeled "CIDATA" ---
      // cloud-init's NoCloud datasource uses blkid to detect the seed drive.
      // It requires TYPE="vfat" LABEL="CIDATA". HFS+ and ISO 9660 hybrids
      // are ignored because blkid sees the wrong filesystem type first.
      // Use plain FAT with -layout NONE so blkid reports vfat.
      const dmgBase = path.join(tmpDir, "seed");
      const dmgPath = dmgBase + ".dmg";
      execFileSync("hdiutil", [
        "create", "-size", "2m",
        "-fs", "MS-DOS", "-volname", "CIDATA",
        "-layout", "NONE", "-o", dmgBase,
      ]);

      // Mount, copy cloud-init files, then detach
      const attachOut = execFileSync(
        "hdiutil",
        ["attach", dmgPath, "-mountrandom", "/tmp", "-nobrowse", "-plist"],
        { encoding: "utf8" }
      );
      const mpMatch = attachOut.match(/<key>mount-point<\/key>\s*<string>([^<]+)<\/string>/);
      if (!mpMatch) throw new Error("hdiutil attach: no mount-point");
      const mountPoint = mpMatch[1].trim();

      try {
        fs.copyFileSync(userDataFile, path.join(mountPoint, "user-data"));
        fs.copyFileSync(metaDataFile, path.join(mountPoint, "meta-data"));
      } finally {
        execFileSync("hdiutil", ["detach", mountPoint, "-force"]);
      }

      // Extract raw bytes from the DMG — the .dmg wrapper has Apple metadata
      // that QEMU can't read as raw FAT. Re-attach without mounting and dd.
      const devOut = execFileSync(
        "hdiutil", ["attach", dmgPath, "-nomount"],
        { encoding: "utf8" }
      );
      const devMatch = devOut.match(/^(\/dev\/disk\S+)/m);
      if (!devMatch) throw new Error("hdiutil attach -nomount: no device");
      const device = devMatch[1];
      try {
        execFileSync("dd", [`if=${device}`, `of=${destPath}`, "bs=512k"]);
      } finally {
        try { execFileSync("hdiutil", ["detach", device, "-force"]); } catch {}
      }

      return destPath;
    } finally {
      // --- Clean up temp directory ---
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  }

  // -------------------------------------------------------------------------
  // getFileShareArgs
  // -------------------------------------------------------------------------

  /**
   * Return QEMU -virtfs arguments to expose host directories to the guest.
   *
   * @param {Array<{ hostPath: string, guestTag: string }>} folders
   * @returns {string[]}
   */
  getFileShareArgs(folders) {
    const args = [];
    for (const { hostPath, guestTag } of folders) {
      args.push(
        "-virtfs",
        `local,path=${hostPath},mount_tag=${guestTag},security_model=mapped-xattr`
      );
    }
    return args;
  }

  // -------------------------------------------------------------------------
  // getGuestMountCommands
  // -------------------------------------------------------------------------

  /**
   * Return fstab lines that mount the virtio-9p shares inside the guest.
   *
   * @param {Array<{ hostPath: string, guestTag: string }>} folders
   * @returns {string[]}
   */
  getGuestMountCommands(folders) {
    return folders.map(({ guestTag }) => {
      // Derive a stable guest mount point from the tag.
      const mountPoint = `/mnt/${guestTag}`;
      return (
        `${guestTag} ${mountPoint} 9p ` +
        `trans=virtio,version=9p2000.L,msize=104857600 0 0`
      );
    });
  }

  // -------------------------------------------------------------------------
  // killProcess
  // -------------------------------------------------------------------------

  /**
   * Send SIGTERM to a process, then escalate to SIGKILL after 8 seconds if
   * it has not exited.
   *
   * @param {number} pid
   * @returns {Promise<void>}
   */
  async killProcess(pid) {
    if (!isAlive(pid)) {
      return;
    }

    // First attempt: graceful shutdown.
    try {
      process.kill(pid, "SIGTERM");
    } catch {
      // Process may have already exited — that is fine.
      return;
    }

    // Wait up to SIGTERM_TIMEOUT_MS for the process to exit.
    const deadline = Date.now() + SIGTERM_TIMEOUT_MS;
    while (Date.now() < deadline) {
      if (!isAlive(pid)) {
        return;
      }
      await sleep(POLL_INTERVAL_MS);
    }

    // Escalate to SIGKILL if the process is still alive.
    if (isAlive(pid)) {
      try {
        process.kill(pid, "SIGKILL");
      } catch {
        // Already dead — ignore.
      }
    }
  }

  // -------------------------------------------------------------------------
  // getGuestArch
  // -------------------------------------------------------------------------

  /**
   * This macOS provider targets Apple Silicon (aarch64).
   *
   * @returns {"aarch64"}
   */
  getGuestArch() {
    return "aarch64";
  }
}

module.exports = { DarwinProvider };
