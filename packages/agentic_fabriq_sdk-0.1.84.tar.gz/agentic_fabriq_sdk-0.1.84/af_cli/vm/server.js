"use strict";

const express = require("express");
const cors = require("cors");

const { startRelay } = require("./relay");
const { DarwinProvider } = require("./platform/darwin");
const { ensureSSHKey, getSSHInfo, runSSHCommand, canReachSSH } = require("./ssh");
const { IMAGE_CATALOG, imageStatus, listImages, runDownloadPipeline, deleteImage } = require("./images");
const {
  loadVMs,
  getVM,
  updateVM,
  createVM,
  startVM,
  stopVM,
  deleteVM,
  reconcileStaleVMs,
} = require("./engine");

// ---------------------------------------------------------------------------
// Platform setup
// ---------------------------------------------------------------------------

let platform;
if (process.platform === "darwin") {
  platform = new DarwinProvider();
} else {
  throw new Error(`Unsupported platform: ${process.platform}`);
}

// ---------------------------------------------------------------------------
// Express app
// ---------------------------------------------------------------------------

const app = express();

const ALLOWED_ORIGINS = [
  "https://dashboard.agenticfabriq.com",
  "https://staging.agenticfabriq.com",
  "http://localhost:5173",
  "http://localhost:3000",
];

// Handle CORS + Chrome Private Network Access (public → loopback)
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && ALLOWED_ORIGINS.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Private-Network", "true");
  }

  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", req.headers["access-control-request-headers"] || "*");
    res.setHeader("Access-Control-Max-Age", "86400");
    return res.status(204).end();
  }

  next();
});

app.use(express.json());

// ---------------------------------------------------------------------------
// Health routes
// ---------------------------------------------------------------------------

app.get("/status", (_req, res) => {
  res.json({ status: "ok", platform: process.platform, version: "1.0.0" });
});

app.get("/prerequisites", async (_req, res) => {
  try {
    const result = await platform.checkPrerequisites();
    res.json({ ok: result.qemu && result.firmware, checks: result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Image routes
// ---------------------------------------------------------------------------

app.get("/images", async (_req, res) => {
  try {
    const images = await listImages();
    res.json(images);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/images/:id", (req, res) => {
  const { id } = req.params;
  const entry = IMAGE_CATALOG.find((img) => img.id === id);
  if (!entry) {
    return res.status(404).json({ error: `Unknown image: ${id}` });
  }
  res.json({ ...entry, ...imageStatus(id) });
});

app.post("/images/:id/download", (req, res) => {
  const { id } = req.params;
  res.json({ id, status: "downloading" });
  // Background download — do not await
  runDownloadPipeline(id).catch((err) => {
    console.error(`[images] download pipeline error for ${id}:`, err.message);
  });
});

app.delete("/images/:id", async (req, res) => {
  try {
    await deleteImage(req.params.id);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Agent types
// ---------------------------------------------------------------------------

const AGENT_TYPES = [
  {
    id: "claude-code",
    name: "Claude Code",
    description: "Anthropic's Claude-powered coding agent",
    imageId: "ubuntu-24.04-arm64",
  },
  {
    id: "cursor",
    name: "Cursor",
    description: "AI-first code editor with built-in agent capabilities",
    imageId: "ubuntu-24.04-arm64",
  },
  {
    id: "codex",
    name: "Codex",
    description: "OpenAI Codex-based coding agent",
    imageId: "ubuntu-24.04-arm64",
  },
  {
    id: "openclaw",
    name: "OpenClaw",
    description: "Open-source coding agent with multi-model support",
    imageId: "ubuntu-24.04-arm64",
  },
];

app.get("/agents", (_req, res) => {
  res.json(AGENT_TYPES);
});

// ---------------------------------------------------------------------------
// VM helpers
// ---------------------------------------------------------------------------

/**
 * Check whether a VM process is still alive via PID liveness probe.
 * Marks the VM stopped in storage if the PID is dead.
 * Returns the (possibly updated) VM object.
 */
async function withPidCheck(vm) {
  if (
    vm.pid &&
    (vm.status === "running" || vm.status === "starting" || vm.status === "provisioning")
  ) {
    try {
      process.kill(vm.pid, 0);
    } catch (_) {
      // PID is dead — update status in storage
      vm = await updateVM(vm.id, { status: "stopped", pid: null });
    }
  }
  return vm;
}

// ---------------------------------------------------------------------------
// VM routes
// ---------------------------------------------------------------------------

app.get("/vms", async (_req, res) => {
  try {
    const { vms } = loadVMs();
    const checked = await Promise.all(vms.map(withPidCheck));
    res.json(checked);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/vms", async (req, res) => {
  try {
    const {
      name,
      agent,
      image,
      memoryGB = 8,
      cpuCount = 4,
      sharedFolders = [],
      ports = [],
    } = req.body || {};

    if (!name || !agent || !image) {
      return res
        .status(400)
        .json({ error: "name, agent, and image are required" });
    }

    const config = { name, agent, image, memoryGB, cpuCount, sharedFolders, ports };
    const vm = await createVM(config, platform);
    res.status(201).json(vm);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/vms/:id", async (req, res) => {
  try {
    let vm = getVM(req.params.id);
    if (!vm) {
      return res.status(404).json({ error: "VM not found" });
    }
    vm = await withPidCheck(vm);
    res.json(vm);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/vms/:id/start", async (req, res) => {
  try {
    const vm = await startVM(req.params.id, platform);
    res.json(vm);

    // Background probe loop:
    //  1. Wait for SSH to become reachable → mark "provisioning"
    //  2. Wait for cloud-init to finish   → mark "running"
    const MAX_SSH_ITERATIONS = 120; // up to 6 min for QEMU + SSH to come up
    const PROBE_INTERVAL_MS = 3000;
    const CLOUD_INIT_POLL_MS = 5000;
    const CLOUD_INIT_TIMEOUT_MS = 15 * 60 * 1000; // 15 min for package installs
    let iterations = 0;

    const probe = setInterval(async () => {
      iterations++;
      try {
        const reachable = await canReachSSH("127.0.0.1", vm.sshPort);
        if (reachable) {
          clearInterval(probe);
          await updateVM(vm.id, { status: "provisioning" });
          console.log(`[vms] VM ${vm.id} SSH reachable, waiting for cloud-init...`);

          // Poll cloud-init status until done
          const deadline = Date.now() + CLOUD_INIT_TIMEOUT_MS;
          const ciPoll = setInterval(async () => {
            try {
              const result = runSSHCommand("cloud-init status", vm.sshPort, "ubuntu");
              const output = result.stdout + result.stderr;
              if (output.includes("done")) {
                clearInterval(ciPoll);
                await updateVM(vm.id, { status: "running" });
                console.log(`[vms] VM ${vm.id} cloud-init done — status: running`);
              } else if (Date.now() > deadline) {
                clearInterval(ciPoll);
                await updateVM(vm.id, { status: "running" });
                console.warn(`[vms] VM ${vm.id} cloud-init timed out, marking running anyway`);
              }
            } catch (err) {
              clearInterval(ciPoll);
              console.error(`[vms] cloud-init poll error for VM ${vm.id}:`, err.message);
              await updateVM(vm.id, { status: "running" });
            }
          }, CLOUD_INIT_POLL_MS);
        } else if (iterations >= MAX_SSH_ITERATIONS) {
          clearInterval(probe);
          console.warn(`[vms] SSH probe timed out for VM ${vm.id}`);
        }
      } catch (err) {
        clearInterval(probe);
        console.error(`[vms] SSH probe error for VM ${vm.id}:`, err.message);
      }
    }, PROBE_INTERVAL_MS);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/vms/:id/stop", async (req, res) => {
  try {
    const vm = await stopVM(req.params.id, platform);
    res.json(vm);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete("/vms/:id", async (req, res) => {
  try {
    await deleteVM(req.params.id, platform);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/vms/:id/run-command", async (req, res) => {
  try {
    let vm = getVM(req.params.id);
    if (!vm) {
      return res.status(404).json({ error: "VM not found" });
    }
    vm = await withPidCheck(vm);

    if (vm.status !== "running") {
      return res.status(409).json({ error: "VM is not running" });
    }

    const { command } = req.body || {};
    if (!command) {
      return res.status(400).json({ error: "command is required" });
    }

    const output = await runSSHCommand(command, vm.sshPort);
    res.json({ output });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/vms/:id/ssh-info", async (req, res) => {
  try {
    const vm = getVM(req.params.id);
    if (!vm) {
      return res.status(404).json({ error: "VM not found" });
    }
    const info = await getSSHInfo(vm.sshPort);
    res.json(info);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Startup
// ---------------------------------------------------------------------------

const PORT = parseInt(process.env.AF_VM_PORT || "7865", 10);

async function start() {
  await ensureSSHKey();
  await reconcileStaleVMs();

  app.listen(PORT, () => {
    console.log(`AF VM server listening on http://localhost:${PORT}`);
    console.log(`Platform: ${process.platform} (${platform.constructor.name})`);

    // Connect relay to gateway if auth token is available
    const token = process.env.AF_AUTH_TOKEN;
    if (token) {
      startRelay(token, PORT);
    } else {
      console.log("No auth token — dashboard relay disabled. Run 'afctl auth login' to enable.");
    }
  });
}

if (require.main === module) {
  start().catch((err) => {
    console.error("Failed to start AF VM server:", err);
    process.exit(1);
  });
}

module.exports = { app, start };
