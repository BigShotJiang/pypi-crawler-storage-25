"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");

const QEMU_IMG_BINARY_NAME = "qemu-img";
const QEMU_SYSTEM_BINARY_NAME = "qemu-system-aarch64";

function defaultCommonDirs(env = process.env) {
  const dirs = [
    "/opt/homebrew/bin",
    "/usr/local/bin",
    "/opt/local/bin",
    path.join(os.homedir(), ".nix-profile", "bin"),
    "/run/current-system/sw/bin",
  ];

  if (env.CONDA_PREFIX) {
    dirs.push(path.join(env.CONDA_PREFIX, "bin"));
  }

  return dirs;
}

function isExecutable(candidate) {
  try {
    fs.accessSync(candidate, fs.constants.X_OK);
    return true;
  } catch {
    return false;
  }
}

function findOnPath(binaryName, pathEnv, executableCheck) {
  for (const dir of (pathEnv || "").split(path.delimiter)) {
    if (!dir) continue;
    const candidate = path.join(dir, binaryName);
    if (executableCheck(candidate)) {
      return candidate;
    }
  }
  return null;
}

function findInDirs(binaryName, dirs, executableCheck) {
  for (const dir of dirs || []) {
    const candidate = path.join(dir, binaryName);
    if (executableCheck(candidate)) {
      return candidate;
    }
  }
  return null;
}

function resolveBinary({ binaryName, envVar, env, executableCheck, commonDirs }) {
  const override = env[envVar];
  if (override) {
    if (executableCheck(override)) {
      return { path: override, errors: [] };
    }
    return {
      path: null,
      errors: [`${envVar} points to a non-executable path: ${override}`],
    };
  }

  const fromPath = findOnPath(binaryName, env.PATH, executableCheck);
  if (fromPath) {
    return { path: fromPath, errors: [] };
  }

  const fromCommonDir = findInDirs(binaryName, commonDirs, executableCheck);
  if (fromCommonDir) {
    return { path: fromCommonDir, errors: [] };
  }

  return { path: null, errors: [] };
}

function resolveQemuBinaries(options = {}) {
  const env = options.env || process.env;
  const executableCheck = options.isExecutable || isExecutable;
  const commonDirs =
    options.commonDirs !== undefined ? options.commonDirs : defaultCommonDirs(env);

  const img = resolveBinary({
    binaryName: QEMU_IMG_BINARY_NAME,
    envVar: "AF_QEMU_IMG",
    env,
    executableCheck,
    commonDirs,
  });
  const system = resolveBinary({
    binaryName: QEMU_SYSTEM_BINARY_NAME,
    envVar: "AF_QEMU_SYSTEM",
    env,
    executableCheck,
    commonDirs,
  });

  const missing = [];
  if (!img.path) missing.push(QEMU_IMG_BINARY_NAME);
  if (!system.path) missing.push(QEMU_SYSTEM_BINARY_NAME);

  return {
    img: img.path,
    system: system.path,
    missing,
    errors: [...img.errors, ...system.errors],
  };
}

function formatMissingQemuError(action, result) {
  const lines = [
    `QEMU is required before ${action}.`,
    `Missing: ${result.missing.join(", ")}`,
    "Install QEMU with your package manager, make sure the binaries are on PATH, or set AF_QEMU_IMG and AF_QEMU_SYSTEM to the full executable paths.",
    "Example: AF_QEMU_IMG=/path/to/qemu-img AF_QEMU_SYSTEM=/path/to/qemu-system-aarch64 afctl vm serve",
  ];

  if (result.errors.length > 0) {
    lines.push(...result.errors);
  }

  return lines.join("\n");
}

function getQemuImgBinary(options = {}) {
  const result = resolveQemuBinaries(options);
  if (!result.img) {
    throw new Error(formatMissingQemuError("managing VM images", result));
  }
  return result.img;
}

function getQemuSystemBinary(options = {}) {
  const result = resolveQemuBinaries(options);
  if (!result.system) {
    throw new Error(formatMissingQemuError("managing VMs", result));
  }
  return result.system;
}

module.exports = {
  QEMU_IMG_BINARY_NAME,
  QEMU_SYSTEM_BINARY_NAME,
  defaultCommonDirs,
  resolveQemuBinaries,
  getQemuImgBinary,
  getQemuSystemBinary,
  formatMissingQemuError,
};
