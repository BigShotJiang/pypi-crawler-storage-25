"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");

const {
  resolveQemuBinaries,
  getQemuImgBinary,
  getQemuSystemBinary,
} = require("./qemu");

test("uses explicit QEMU environment overrides before PATH", () => {
  const result = resolveQemuBinaries({
    env: {
      AF_QEMU_IMG: "/custom/bin/qemu-img",
      AF_QEMU_SYSTEM: "/custom/bin/qemu-system-aarch64",
      PATH: "/ignored/bin",
    },
    isExecutable: (candidate) => candidate.startsWith("/custom/bin/"),
  });

  assert.equal(result.img, "/custom/bin/qemu-img");
  assert.equal(result.system, "/custom/bin/qemu-system-aarch64");
  assert.deepEqual(result.missing, []);
  assert.deepEqual(result.errors, []);
});

test("finds QEMU binaries on PATH when overrides are not set", () => {
  const result = resolveQemuBinaries({
    env: { PATH: "/tools/bin:/other/bin" },
    isExecutable: (candidate) => candidate.startsWith("/tools/bin/"),
    commonDirs: [],
  });

  assert.equal(result.img, "/tools/bin/qemu-img");
  assert.equal(result.system, "/tools/bin/qemu-system-aarch64");
  assert.deepEqual(result.missing, []);
});

test("falls back to common install directories when PATH does not include QEMU", () => {
  const result = resolveQemuBinaries({
    env: { PATH: "/usr/bin:/bin" },
    isExecutable: (candidate) => candidate.startsWith("/pkg/bin/"),
    commonDirs: ["/pkg/bin"],
  });

  assert.equal(result.img, "/pkg/bin/qemu-img");
  assert.equal(result.system, "/pkg/bin/qemu-system-aarch64");
  assert.deepEqual(result.missing, []);
});

test("reports invalid overrides and missing binaries", () => {
  const result = resolveQemuBinaries({
    env: {
      AF_QEMU_IMG: "/missing/qemu-img",
      PATH: "/usr/bin:/bin",
    },
    isExecutable: () => false,
    commonDirs: [],
  });

  assert.equal(result.img, null);
  assert.equal(result.system, null);
  assert.deepEqual(result.missing, ["qemu-img", "qemu-system-aarch64"]);
  assert.match(result.errors[0], /AF_QEMU_IMG points to a non-executable path/);
});

test("throws a clear error when qemu-img is unavailable", () => {
  assert.throws(
    () =>
      getQemuImgBinary({
        env: { PATH: "/usr/bin:/bin" },
        isExecutable: () => false,
        commonDirs: [],
      }),
    /QEMU is required before managing VM images/
  );
});

test("throws a clear error when qemu-system-aarch64 is unavailable", () => {
  assert.throws(
    () =>
      getQemuSystemBinary({
        env: { PATH: "/usr/bin:/bin" },
        isExecutable: () => false,
        commonDirs: [],
      }),
    /QEMU is required before managing VMs/
  );
});
