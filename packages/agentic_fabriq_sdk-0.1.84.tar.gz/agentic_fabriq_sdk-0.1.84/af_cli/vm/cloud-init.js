"use strict";

// Packages to install per agent type. All agents share a common base;
// agent-specific extras are appended.
const BASE_PACKAGES = [
  "python3-pip",
  "python3-venv",
  "git",
  "curl",
  "build-essential",
];

const AGENT_PACKAGES = {
  "claude-code": [...BASE_PACKAGES, "nodejs", "npm"],
  "codex":       [...BASE_PACKAGES, "nodejs", "npm"],
  "cursor":      [...BASE_PACKAGES, "wget"],
  "openclaw":    [...BASE_PACKAGES],
};

// npm global packages to install per agent type
const AGENT_NPM_PACKAGES = {
  "claude-code": "@anthropic-ai/claude-code",
  "codex":       "@openai/codex",
};

/**
 * generateUserData — build a cloud-init #cloud-config YAML string.
 *
 * @param {object} opts
 * @param {string}   opts.sshPubKey      – ed25519 public key line
 * @param {string}   [opts.agent]        – agent type id (e.g. "claude-code")
 * @param {Array<{hostPath:string,guestTag:string}>} opts.sharedFolders
 * @returns {string} YAML content
 */
function generateUserData({ sshPubKey, agent, sharedFolders }) {
  const username = "ubuntu";
  const home = `/home/${username}`;

  // Build the fstab + mount runcmd lines for each shared folder
  const sharedFolderCmds = [];
  for (const { guestTag } of sharedFolders) {
    sharedFolderCmds.push(`  - mkdir -p /mnt/${guestTag}`);
    sharedFolderCmds.push(
      `  - echo '${guestTag} /mnt/${guestTag} 9p trans=virtio,version=9p2000.L,access=any,nofail 0 0' >> /etc/fstab`
    );
    sharedFolderCmds.push(`  - mount -a 2>/dev/null || true`);
  }

  // Resolve package list for the agent type
  const packages = AGENT_PACKAGES[agent] || BASE_PACKAGES;
  const packagesYaml = packages.map((p) => `  - ${p}`).join("\n");

  // Build agent-specific npm install commands
  const npmInstallCmds = [];
  const needsNpm = AGENT_PACKAGES[agent] && AGENT_PACKAGES[agent].includes("nodejs");
  if (needsNpm) {
    npmInstallCmds.push(`  - su - ${username} -c 'mkdir -p ${home}/.npm-global'`);
    npmInstallCmds.push(`  - su - ${username} -c 'npm config set prefix ${home}/.npm-global'`);

    const npmPkg = AGENT_NPM_PACKAGES[agent];
    if (npmPkg) {
      npmInstallCmds.push(`  - su - ${username} -c 'npm install -g ${npmPkg}'`);
    }
  }

  const claudeMcpJson = JSON.stringify({
    mcpServers: {
      "agentic-fabriq": {
        command: "afctl",
        args: ["broker"],
      },
    },
  });

  const cursorMcpJson = JSON.stringify({
    mcpServers: {
      "agentic-fabriq": {
        command: `${home}/.af-venv/bin/afctl`,
        args: ["broker"],
      },
    },
  });

  const yaml = `#cloud-config
users:
  - name: ${username}
    sudo: ALL=(ALL) NOPASSWD:ALL
    shell: /bin/bash
    lock_passwd: false
    ssh_authorized_keys:
      - ${sshPubKey}

package_update: true

packages:
${packagesYaml}

runcmd:
  - python3 -m venv ${home}/.af-venv
  - ${home}/.af-venv/bin/pip install agentic-fabriq-sdk
  - chown -R ${username}:${username} ${home}/.af-venv
  - echo 'export PATH="${home}/.npm-global/bin:${home}/.local/bin:${home}/.af-venv/bin:$PATH"' >> ${home}/.bashrc
  - mkdir -p ${home}/.claude
  - echo '${claudeMcpJson}' > ${home}/.claude/mcp.json
  - chown -R ${username}:${username} ${home}/.claude
  - mkdir -p ${home}/.cursor
  - echo '${cursorMcpJson}' > ${home}/.cursor/mcp.json
  - chown -R ${username}:${username} ${home}/.cursor
  - ${home}/.af-venv/bin/pip install keyrings.alt
  - mkdir -p ${home}/.config/python_keyring
  - echo '[backend]' > ${home}/.config/python_keyring/keyringrc.cfg
  - echo 'default-keyring=keyrings.alt.file.PlaintextKeyring' >> ${home}/.config/python_keyring/keyringrc.cfg
  - chown -R ${username}:${username} ${home}/.config
  - mkdir -p ${home}/.ssh
  - chmod 700 ${home}/.ssh
  - chown ${username}:${username} ${home}/.ssh
  - printf '%s\\n' '${sshPubKey}' > ${home}/.ssh/authorized_keys
  - chmod 600 ${home}/.ssh/authorized_keys
  - chown ${username}:${username} ${home}/.ssh/authorized_keys
${npmInstallCmds.join("\n")}
${sharedFolderCmds.join("\n")}
`;

  return yaml;
}

/**
 * generateMetaData — build a cloud-init meta-data string.
 *
 * @param {string} vmId
 * @returns {string}
 */
function generateMetaData(vmId) {
  return `instance-id: ${vmId}\nlocal-hostname: af-vm-${vmId}\n`;
}

module.exports = { generateUserData, generateMetaData };
