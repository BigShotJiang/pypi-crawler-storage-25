"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");

const { resolveRelayUrl } = require("./relay");

test("derives the relay WebSocket URL from the configured gateway URL", () => {
  assert.equal(
    resolveRelayUrl("https://staging.agenticfabriq.com"),
    "wss://staging.agenticfabriq.com/api/v1/vm/relay"
  );
});

test("uses production as the fallback relay URL", () => {
  assert.equal(
    resolveRelayUrl(),
    "wss://dashboard.agenticfabriq.com/api/v1/vm/relay"
  );
});
