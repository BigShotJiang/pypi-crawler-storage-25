"use strict";

const { spawn } = require("child_process");
const { execFileSync } = require("child_process");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { VMS_DIR, ensureSSHKey, runSSHCommand } = require("./ssh");
const { generateUserData, generateMetaData } = require("./cloud-init");
const { imagePaths } = require("./images");
const { getQemuImgBinary } = require("./qemu");

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const INSTANCES_DIR = path.join(VMS_DIR, "instances");
const VMS_JSON = path.join(VMS_DIR, "vms.json");

// ---------------------------------------------------------------------------
// State persistence
// ---------------------------------------------------------------------------

/**
 * Read and parse VMS_JSON. Returns { vms: [] } on error.
 * @returns {{ vms: Array<object> }}
 */
function loadVMs() {
  try {
    const raw = fs.readFileSync(VMS_JSON, "utf8");
    return JSON.parse(raw);
  } catch {
    return { vms: [] };
  }
}

/**
 * Write data to VMS_JSON, creating VMS_DIR if necessary.
 * @param {{ vms: Array<object> }} data
 */
function saveVMs(data) {
  fs.mkdirSync(VMS_DIR, { recursive: true });
  fs.writeFileSync(VMS_JSON, JSON.stringify(data, null, 2), "utf8");
}

/**
 * Find a VM by id.
 * @param {string} id
 * @returns {object|undefined}
 */
function getVM(id) {
  const { vms } = loadVMs();
  return vms.find((vm) => vm.id === id);
}

/**
 * Merge updates into a VM record and persist.
 * @param {string} id
 * @param {object} updates
 * @returns {object} Updated VM record
 */
function updateVM(id, updates) {
  const data = loadVMs();
  const idx = data.vms.findIndex((vm) => vm.id === id);
  if (idx === -1) {
    throw new Error(`VM not found: ${id}`);
  }
  data.vms[idx] = { ...data.vms[idx], ...updates };
  saveVMs(data);
  return data.vms[idx];
}

// ---------------------------------------------------------------------------
// Port allocation
// ---------------------------------------------------------------------------

/**
 * Find an unused TCP port starting at 2222.
 * @returns {number}
 */
function allocateSSHPort() {
  const net = require("net");
  let port = 2222;

  while (true) {
    try {
      // Check if port is already allocated to a running VM
      const { vms } = loadVMs();
      const inUse = vms.some((vm) => vm.sshPort === port && vm.status !== "stopped" && vm.status !== "error");
      if (!inUse) {
        // Also verify TCP not in use by anything
        const server = net.createServer();
        let available = false;
        try {
          server.listen(port, "127.0.0.1");
          available = true;
        } catch {
          available = false;
        } finally {
          server.close();
        }
        if (available) {
          return port;
        }
      }
    } catch {
      // If loadVMs fails, still try the port
    }
    port++;
  }
}

// ---------------------------------------------------------------------------
// VM Lifecycle
// ---------------------------------------------------------------------------

/**
 * Create a new VM: allocate port, create disk and seed ISO, persist record.
 *
 * @param {{ name: string, agent: string, image: string, memoryGB: number, cpuCount: number, sharedFolders: Array, ports: Array }} config
 * @param {object} platform — PlatformProvider instance
 * @returns {Promise<object>} VM record
 */
async function createVM(config, platform) {
  const { name, agent, image, memoryGB, cpuCount, sharedFolders = [], ports = [] } = config;

  // Generate a unique 4-byte hex ID
  const id = crypto.randomBytes(4).toString("hex");

  // Allocate SSH port
  const sshPort = allocateSSHPort();

  // Create instance directory
  const instanceDir = path.join(INSTANCES_DIR, id);
  fs.mkdirSync(instanceDir, { recursive: true });

  // Resolve base image path
  const paths = imagePaths(image);
  if (!paths) {
    throw new Error(`Unknown image: ${image}`);
  }
  const baseImage = paths.qcow2;

  // Create qcow2 disk with backing file
  const diskPath = path.join(instanceDir, "disk.qcow2");
  const qemuImg = getQemuImgBinary();
  execFileSync(
    qemuImg,
    ["create", "-f", "qcow2", "-b", baseImage, "-F", "qcow2", diskPath],
    { stdio: "pipe" }
  );

  // Copy EFI vars template
  const fw = platform.getFirmwarePaths();
  const efiVarsPath = path.join(instanceDir, "efi-vars.fd");
  fs.copyFileSync(fw.varsTemplate, efiVarsPath);

  // Generate cloud-init content
  const sshPubKey = ensureSSHKey();
  const userDataContent = generateUserData({ sshPubKey, agent, sharedFolders });
  const metaDataContent = generateMetaData(id);

  // Build seed ISO via platform
  const seedPath = path.join(instanceDir, "seed.iso");
  await platform.createSeedISO({ userDataContent, metaDataContent, destPath: seedPath });

  // Build VM record
  const vm = {
    id,
    name,
    agent: agent || null,
    image,
    memoryGB,
    cpuCount,
    sharedFolders,
    ports,
    sshPort,
    instanceDir,
    diskPath,
    efiVarsPath,
    seedPath,
    status: "stopped",
    pid: null,
    lastStartedAt: null,
    createdAt: new Date().toISOString(),
  };

  // Persist
  const data = loadVMs();
  data.vms.push(vm);
  saveVMs(data);

  return vm;
}

/**
 * Start a VM by launching QEMU.
 *
 * @param {string} id
 * @param {object} platform — PlatformProvider instance
 * @returns {Promise<object>} Updated VM record
 */
async function startVM(id, platform) {
  const vm = getVM(id);
  if (!vm) {
    throw new Error(`VM not found: ${id}`);
  }
  if (vm.status !== "stopped" && vm.status !== "error") {
    throw new Error(`VM ${id} is not stopped (status: ${vm.status})`);
  }

  const fw = platform.getFirmwarePaths();

  // Build QEMU args
  const baseArgs = platform.getQemuBaseArgs({ memoryGB: vm.memoryGB, cpuCount: vm.cpuCount });

  // EFI pflash drives
  const efiArgs = [
    "-drive", `if=pflash,format=raw,file=${fw.code},readonly=on`,
    "-drive", `if=pflash,format=raw,file=${vm.efiVarsPath}`,
  ];

  // Main disk
  const diskArgs = [
    "-drive", `if=virtio,format=qcow2,file=${vm.diskPath}`,
  ];

  // Seed ISO
  const seedArgs = [
    "-drive", `if=virtio,format=raw,file=${vm.seedPath},readonly=on`,
  ];

  // Networking — build hostfwd string for SSH + any extra ports
  const hostfwds = [`hostfwd=tcp::${vm.sshPort}-:22`];
  for (const p of (vm.ports || [])) {
    const hostPort = p.host || p.hostPort;
    const guestPort = p.guest || p.guestPort;
    if (hostPort && guestPort) {
      hostfwds.push(`hostfwd=tcp::${hostPort}-:${guestPort}`);
    }
  }
  const netArgs = [
    "-netdev", `user,id=net0,${hostfwds.join(",")}`,
    "-device", "virtio-net-pci,netdev=net0",
  ];

  // File share args
  const fileShareArgs = platform.getFileShareArgs(vm.sharedFolders || []);

  // Serial console → log file (not stdio, so QEMU survives server restarts)
  const logPath = path.join(vm.instanceDir, "console.log");
  const displayArgs = ["-display", "none", "-serial", `file:${logPath}`];

  const qemuArgs = [
    ...baseArgs,
    ...efiArgs,
    ...diskArgs,
    ...seedArgs,
    ...netArgs,
    ...fileShareArgs,
    ...displayArgs,
  ];

  const qemuBin = platform.getQemuBinary();

  // Spawn QEMU detached so it survives server restarts.
  // stdio is fully disconnected — serial output goes to the log file above.
  const oldUmask = process.umask(0);
  let child;
  try {
    child = spawn(qemuBin, qemuArgs, {
      stdio: "ignore",
      detached: true,
    });
  } finally {
    process.umask(oldUmask);
  }

  // Let the server exit without waiting for QEMU
  child.unref();

  // Update VM record
  const updated = updateVM(id, {
    status: "starting",
    pid: child.pid,
    lastStartedAt: new Date().toISOString(),
  });

  return updated;
}

/**
 * Stop a running VM: try SSH poweroff first, fall back to kill.
 *
 * @param {string} id
 * @param {object} platform — PlatformProvider instance
 * @returns {Promise<object>} Updated VM record
 */
async function stopVM(id, platform) {
  const vm = getVM(id);
  if (!vm) {
    throw new Error(`VM not found: ${id}`);
  }

  // Try SSH graceful shutdown
  if (vm.sshPort && vm.pid) {
    try {
      runSSHCommand("sudo poweroff", vm.sshPort);
      // Wait up to 10s for the process to die
      const deadline = Date.now() + 10000;
      while (Date.now() < deadline) {
        try {
          process.kill(vm.pid, 0);
          // Still alive, wait a bit
          await new Promise((resolve) => setTimeout(resolve, 500));
        } catch {
          // Process gone
          break;
        }
      }
    } catch {
      // SSH failed, fall through to kill
    }
  }

  // Fall back to platform kill if process still alive
  if (vm.pid) {
    try {
      process.kill(vm.pid, 0);
      // Still alive — kill it
      await platform.killProcess(vm.pid);
    } catch {
      // Already dead
    }
  }

  return updateVM(id, { status: "stopped", pid: null });
}

/**
 * Delete a VM: stop if running, remove files, remove from registry.
 *
 * @param {string} id
 * @param {object} platform — PlatformProvider instance
 * @returns {Promise<void>}
 */
async function deleteVM(id, platform) {
  const vm = getVM(id);
  if (!vm) {
    throw new Error(`VM not found: ${id}`);
  }

  // Stop if running
  if (vm.status === "running" || vm.status === "starting" || vm.status === "provisioning") {
    await stopVM(id, platform);
  }

  // Delete instance directory
  if (vm.instanceDir && fs.existsSync(vm.instanceDir)) {
    fs.rmSync(vm.instanceDir, { recursive: true, force: true });
  }

  // Remove from vms.json
  const data = loadVMs();
  data.vms = data.vms.filter((v) => v.id !== id);
  saveVMs(data);
}

/**
 * Reconcile VMs whose process may have died while the CLI was not running.
 * For each VM with a pid and status running/starting, check if the process
 * is still alive and mark stopped if not.
 *
 * @returns {void}
 */
function reconcileStaleVMs() {
  const data = loadVMs();
  let changed = false;

  for (const vm of data.vms) {
    if (vm.pid && (vm.status === "running" || vm.status === "starting" || vm.status === "provisioning")) {
      let alive = false;
      try {
        process.kill(vm.pid, 0);
        alive = true;
      } catch {
        alive = false;
      }

      if (!alive) {
        vm.status = "stopped";
        vm.pid = null;
        changed = true;
      }
    }
  }

  if (changed) {
    saveVMs(data);
  }
}

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------

module.exports = {
  loadVMs,
  getVM,
  updateVM,
  createVM,
  startVM,
  stopVM,
  deleteVM,
  reconcileStaleVMs,
};
