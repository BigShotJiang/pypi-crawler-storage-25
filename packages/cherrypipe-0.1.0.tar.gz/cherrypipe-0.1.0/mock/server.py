"""
mock/server.py
~~~~~~~~~~~~~~
A minimal fake WeChat iLink server for local testing.

Simulates the iLink Bot API so you can develop and test cherrypipe
without real WeChat ClawBot access.

Run it:
    python mock/server.py

Then start cherrypipe pointed at the mock instead of the real API:
    ILINK_BASE_URL=http://localhost:8765 python -m cherrypipe

Inject a fake incoming WeChat message via:
    curl -X POST http://localhost:8765/inject \
         -H "Content-Type: application/json" \
         -d '{"from_user_id": "cherry@wechat", "text": "hello claude"}'

Bot replies will be printed to this terminal as they arrive.
"""

from __future__ import annotations

import json
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Event, Lock
from typing import Any

# ── Message queue ─────────────────────────────────────────────────────────────
# Incoming messages injected via /inject are held here until getupdates picks them up.

_queue: list[dict[str, Any]] = []
_queue_lock = Lock()
_new_msg = Event()
_MSG_COUNTER = 1000


def _next_id() -> int:
    """Return a monotonically increasing message ID."""
    global _MSG_COUNTER  # noqa: PLW0603 — intentional module-level counter # pylint: disable=global-statement
    _MSG_COUNTER += 1
    return _MSG_COUNTER


def _make_message(from_user_id: str, text: str) -> dict[str, Any]:
    """Build a fake iLink USER message dict from a user ID and text string."""
    return {
        "message_id": _next_id(),
        "from_user_id": from_user_id,
        "to_user_id": "bot@ilink",
        "context_token": f"ctx-{from_user_id}",
        "message_type": 1,  # USER
        "message_state": 0,  # NEW
        "session_id": f"sess-{from_user_id}",
        "create_time_ms": int(time.time() * 1000),
        "item_list": [{"type": 1, "text_item": {"text": text}}],
    }


# ── Request handler ───────────────────────────────────────────────────────────


class MockHandler(BaseHTTPRequestHandler):
    """
    HTTP request handler that mimics the WeChat iLink Bot API.

    Supported endpoints:
      POST ilink/bot/getupdates   — long-poll for new messages (holds 5s)
      POST ilink/bot/sendmessage  — capture and print bot replies
      POST ilink/bot/getconfig    — return a dummy typing ticket
      POST ilink/bot/sendtyping   — acknowledge silently
      POST ilink/bot/getqrcode    — return a fake QR code URL
      POST ilink/bot/checkqrcode  — immediately confirm login
      POST /inject                — test helper: inject a fake user message
    """

    # pylint: disable=arguments-differ
    def log_message(self, fmt: str, *args: Any) -> None:
        """Override default handler to prefix log lines with [mock]."""
        print(f"[mock] {fmt % args}")

    def _read_json(self) -> dict[str, Any]:
        """Read and parse the JSON request body."""
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        return json.loads(body) if body else {}

    def _send_json(self, data: dict[str, Any], status: int = 200) -> None:
        """Serialise data as JSON and send it as the HTTP response."""
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(
        self,
    ) -> None:  # noqa: N802 — method name mandated by BaseHTTPRequestHandler
        """Route incoming POST requests to the appropriate iLink endpoint handler."""
        path = self.path.rstrip("/")

        if path.endswith("getupdates"):
            self._handle_getupdates()
        elif path.endswith("sendmessage"):
            self._handle_sendmessage()
        elif path.endswith("getconfig"):
            self._send_json({"ret": 0, "typing_ticket": "mock-ticket"})
        elif path.endswith("sendtyping"):
            self._read_json()  # consume body
            self._send_json({"ret": 0})
        elif path.endswith("getqrcode"):
            self._handle_getqrcode()
        elif path.endswith("checkqrcode"):
            self._handle_checkqrcode()
        elif path == "/inject":
            self._handle_inject()
        else:
            self._send_json({"ret": -1, "errmsg": f"unknown endpoint: {path}"}, 404)

    def do_GET(self) -> None:  # noqa: N802
        """Handle GET requests for QR code endpoints."""
        if "get_bot_qrcode" in self.path:
            self._send_json({
                "qrcode":             "mock-qrcode-token",
                "qrcode_img_content": "https://mock.cherrypipe.local/qr/abc123",
            })
        elif "get_qrcode_status" in self.path:
            self._send_json({
                "status":       "confirmed",
                "bot_token":    "mock-token-abc123",
                "ilink_bot_id": "mock-account",
                "baseurl":      "http://127.0.0.1:8765/",
            })
        else:
            self._send_json({"ret": -1, "errmsg": f"unknown endpoint: {self.path}"}, 404)
            
    # ── Endpoint handlers ─────────────────────────────────────────────────────

    def _handle_getupdates(self) -> None:
        """Hold the request up to 5s, then return any queued messages."""
        _new_msg.wait(timeout=5)
        _new_msg.clear()
        with _queue_lock:
            msgs = list(_queue)
            _queue.clear()
        self._send_json(
            {
                "ret": 0,
                "msgs": msgs,
                "get_updates_buf": "mock-cursor",
                "longpolling_timeout_ms": 5_000,
            }
        )

    def _handle_sendmessage(self) -> None:
        """Capture a bot reply and print it to the terminal."""
        body = self._read_json()
        msg = body.get("msg", {})
        items = msg.get("item_list", [])
        for item in items:
            if item.get("type") == 1:
                text = item.get("text_item", {}).get("text", "")
                to = msg.get("to_user_id", "?")
                print(f"\n  bot -> {to}:\n  {text}\n")
        self._send_json({"ret": 0})

    def _handle_getqrcode(self) -> None:
        """Return a fake QR code URL for the login flow."""
        self._send_json(
            {
                "ret": 0,
                "qrcode_url": "https://mock.cherrypipe.local/qr/abc123",
                "scene_str": "mock-scene",
                "expire_time": 120,
            }
        )

    def _handle_checkqrcode(self) -> None:
        """Immediately confirm the QR code scan with a mock token."""
        self._read_json()  # consume body
        self._send_json(
            {
                "ret": 0,
                "status": 2,  # 2 = confirmed
                "token": "mock-token-abc123",
                "account_id": "mock-account",
            }
        )

    def _handle_inject(self) -> None:
        """Test helper: inject a fake user message into the queue."""
        body = self._read_json()
        uid = body.get("from_user_id", "testuser@wechat")
        text = body.get("text", "hello")
        msg = _make_message(uid, text)
        with _queue_lock:
            _queue.append(msg)
        _new_msg.set()
        print(f"[mock] injected from={uid} text={text!r}")
        self._send_json({"ok": True, "message_id": msg["message_id"]})


# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    PORT = 8765
    server = HTTPServer(("127.0.0.1", PORT), MockHandler)

    print(f"🍒 Mock iLink server  http://127.0.0.1:{PORT}")
    print()
    print("Inject a test message:")
    print(f"  curl -X POST http://127.0.0.1:{PORT}/inject \\")
    print("       -H 'Content-Type: application/json' \\")
    print('       -d \'{"from_user_id": "cherry@wechat", "text": "hello"}\'')
    print()
    print("Press Ctrl+C to stop.")
    print()

    server.serve_forever()
