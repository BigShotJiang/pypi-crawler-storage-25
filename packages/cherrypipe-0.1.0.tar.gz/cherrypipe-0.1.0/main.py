"""
main.py
~~~~~~~
cherrypipe entry point.

Starts the bridge: loads credentials, initialises the iLink client,
detects available agents, and runs the long-poll loop.

Usage:
    python main.py                        # use saved credentials
    python main.py --mock                 # use local mock server
    python main.py --cwd /my/project      # set default working directory

Stop with Ctrl+C.
"""

from __future__ import annotations

import argparse
import asyncio
import signal
import sys

from src.agents import ALL_AGENTS
from src.credentials import require
from src.handler import MessageHandler
from src.ilink import ILinkClient, SessionExpiredError

BANNER = """
🍒 cherrypipe
─────────────────────────────────────────
"""


# ── Agent detection ───────────────────────────────────────────────────────────


async def detect_agents(cwd: str | None) -> list:
    """
    Instantiate and check availability of all registered agents.

    Prints a status line for each agent so the user knows what's
    ready to use. Returns only agents that are actually available.
    """
    available = []
    for agent_class in ALL_AGENTS:
        agent = agent_class()
        if cwd:
            agent._default_cwd = cwd  # type: ignore[attr-defined]
        ready = await agent.is_available()
        status = "✅" if ready else "❌ not found"
        print(f"  {agent.name:<12} {status}")
        if ready:
            available.append(agent)
    return available


# ── Poll loop ─────────────────────────────────────────────────────────────────


async def poll_loop(client: ILinkClient, handler: MessageHandler) -> None:
    """
    Run the long-poll loop indefinitely.

    Each iteration calls get_updates(), which blocks until messages
    arrive or the server times out (~35s). On timeout it returns an
    empty result and we loop immediately — no sleep needed.

    Transient network errors are logged and retried with exponential
    backoff (1s → 2s → 4s … capped at 30s). A SessionExpiredError
    exits immediately with a clear message.
    """
    cursor = ""
    backoff_s = 1

    print("\nListening for WeChat messages. Press Ctrl+C to stop.\n")

    while True:
        try:
            result = await client.get_updates(cursor=cursor)
            backoff_s = 1  # reset backoff on success

            if result.next_cursor:
                cursor = result.next_cursor

            for msg in result.messages:
                # Dispatch each message concurrently — one user never
                # blocks another, and slow Claude responses don't pile up
                asyncio.create_task(handler.handle(msg))

        except SessionExpiredError:
            print("\n❌ Session expired. Run:  python login.py")
            sys.exit(1)

        except (OSError, Exception) as e:  # noqa: BLE001
            print(f"[poll] error (retrying in {backoff_s}s): {type(e).__name__}: {e}")
            await asyncio.sleep(backoff_s)
            backoff_s = min(backoff_s * 2, 30)


# ── Entry point ───────────────────────────────────────────────────────────────


async def run(mock: bool, cwd: str | None) -> None:
    """Load config, detect agents, and start the poll loop."""
    print(BANNER)

    creds = require()
    base_url = "http://127.0.0.1:8765/" if mock else creds.base_url

    print(f"Account:  {creds.account_id}")
    print(f"API:      {base_url}")
    print(f"Logged in:{creds.logged_in_at}")
    print("\nDetecting agents...")

    agents = await detect_agents(cwd)

    if not agents:
        print("\n❌ No agents available. Install Claude Code:")
        print("     npm install -g @anthropic-ai/claude-code")
        print("     claude auth login")
        sys.exit(1)

    print(f"\nDefault agent: {agents[0].name}")

    async with ILinkClient(token=creds.token, base_url=base_url) as client:
        handler = MessageHandler(client=client, agents=agents)
        await poll_loop(client, handler)


def main() -> None:
    """Parse CLI arguments and start the async event loop."""
    parser = argparse.ArgumentParser(
        description="cherrypipe — WeChat → AI agent bridge"
    )
    parser.add_argument("--mock", action="store_true", help="use local mock server")
    parser.add_argument(
        "--cwd", metavar="PATH", help="default working directory for agents"
    )
    args = parser.parse_args()

    # Clean Ctrl+C handling — no ugly traceback
    def _handle_sigint(*_) -> None:
        print("\n\n👋 cherrypipe stopped.")
        sys.exit(0)

    signal.signal(signal.SIGINT, _handle_sigint)

    asyncio.run(run(mock=args.mock, cwd=args.cwd))


if __name__ == "__main__":
    main()
