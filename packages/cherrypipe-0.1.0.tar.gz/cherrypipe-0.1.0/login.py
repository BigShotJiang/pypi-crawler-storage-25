"""
login.py
~~~~~~~~
One-time WeChat iLink Bot login via QR code.

Usage:
    python login.py            # login with real WeChat
    python login.py --mock     # login against local mock server
    python login.py --logout   # clear saved credentials

Real API endpoints (from @tencent-weixin/openclaw-weixin source):
    GET  ilink/bot/get_bot_qrcode?bot_type=3   — fetch QR code
    GET  ilink/bot/get_qrcode_status?qrcode=X  — long-poll for scan status
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from datetime import datetime, timezone

import httpx

from src.credentials import Credentials, clear, load, save
from src.ilink import ILINK_BASE_URL

MOCK_BASE_URL = "http://127.0.0.1:8765/"
BOT_TYPE = "3"
POLL_TIMEOUT_S = 35  # server holds the long-poll up to ~35s
MAX_QR_REFRESH = 3  # auto-refresh expired QR codes up to this many times


# ── API calls ─────────────────────────────────────────────────────────────────


async def _get_qr(client: httpx.AsyncClient, base_url: str) -> dict:
    """
    Fetch a fresh QR code from the iLink API.

    Returns dict with keys:
        qrcode          — opaque token used to poll for status
        qrcode_img_content — URL to open in browser for scanning
    """
    url = base_url.rstrip("/") + f"/ilink/bot/get_bot_qrcode?bot_type={BOT_TYPE}"
    resp = await client.get(url, timeout=15)
    resp.raise_for_status()
    return resp.json()


async def _poll_status(
    client: httpx.AsyncClient, base_url: str, qrcode_token: str
) -> dict:
    """
    Long-poll for QR code scan status.

    Blocks up to POLL_TIMEOUT_S seconds. Returns dict with key:
        status — "wait" | "scaned" | "confirmed" | "expired"
        bot_token, ilink_bot_id, baseurl — present when status == "confirmed"
    """
    url = base_url.rstrip("/") + f"/ilink/bot/get_qrcode_status?qrcode={qrcode_token}"
    try:
        resp = await client.get(
            url,
            timeout=POLL_TIMEOUT_S + 5,
            headers={"iLink-App-ClientVersion": "1"},
        )
        resp.raise_for_status()
        return resp.json()
    except httpx.TimeoutException:
        return {"status": "wait"}


# ── Main login flow ───────────────────────────────────────────────────────────


async def login(base_url: str) -> None:
    """Run the full QR code login flow against the given base URL."""
    async with httpx.AsyncClient() as client:

        # ── Fetch first QR code ───────────────────────────────────────────────
        print("Requesting QR code...")
        try:
            qr_data = await _get_qr(client, base_url)
        except httpx.HTTPError as e:
            print(f"\nFailed to reach iLink API: {e}")
            print("\nIf you don't have WeChat ClawBot access yet, use the mock:")
            print("  ./cherrypipe start --mock")
            sys.exit(1)

        qrcode_token = qr_data.get("qrcode", "")
        qr_url = qr_data.get("qrcode_img_content", "")

        if not qrcode_token or not qr_url:
            print(f"Unexpected response: {qr_data}")
            sys.exit(1)

        # ── Display login instructions ────────────────────────────────────────
        print("\n" + "─" * 40)
        print("📱 To login:")
        print("   1. Open this URL in your phone browser:")
        print(f"\n      {qr_url}\n")
        print("   2. Scan the QR code on that page with WeChat")
        print("─" * 40 + "\n")
        print("Waiting for scan", end="", flush=True)

        # ── Poll for confirmation ─────────────────────────────────────────────
        scanned = False
        refresh_count = 0

        while True:
            status_data = await _poll_status(client, base_url, qrcode_token)
            status = status_data.get("status", "wait")

            if status == "wait":
                print(".", end="", flush=True)

            elif status == "scaned" and not scanned:
                print("\nQR code scanned — confirm in WeChat...")
                scanned = True

            elif status == "confirmed":
                print("\n")
                token = status_data.get("bot_token", "")
                account_id = status_data.get("ilink_bot_id", "unknown")
                user_base_url = status_data.get("baseurl") or base_url

                creds = Credentials(
                    token=token,
                    account_id=account_id,
                    base_url=user_base_url,
                    logged_in_at=datetime.now(timezone.utc).isoformat(),
                )
                save(creds)

                print(f"Logged in as: {account_id}")
                return

            elif status == "expired":
                refresh_count += 1
                if refresh_count > MAX_QR_REFRESH:
                    print(f"\nQR code expired {MAX_QR_REFRESH} times. Run login again.")
                    sys.exit(1)

                print(
                    f"\nQR code expired — refreshing ({refresh_count}/{MAX_QR_REFRESH})..."
                )
                try:
                    qr_data = await _get_qr(client, base_url)
                    qrcode_token = qr_data.get("qrcode", "")
                    qr_url = qr_data.get("qrcode_img_content", "")
                    scanned = False

                    print("\n" + "─" * 40)
                    print("📱 New QR code — open this URL in your phone browser:")
                    print(f"\n      {qr_url}\n")
                    print("   Scan the QR code on that page with WeChat")
                    print("─" * 40 + "\n")
                    print("Waiting for scan", end="", flush=True)

                except httpx.HTTPError as e:
                    print(f"\nFailed to refresh QR code: {e}")
                    sys.exit(1)


# ── Entry point ───────────────────────────────────────────────────────────────


def main() -> None:
    """Parse arguments and run the appropriate login action."""
    parser = argparse.ArgumentParser(description="cherrypipe login")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--mock", action="store_true", help="use local mock server")
    group.add_argument("--logout", action="store_true", help="clear saved credentials")
    args = parser.parse_args()

    if args.logout:
        clear()
        return

    existing = load()
    if existing:
        print(f"Already logged in as: {existing.account_id}")
        print(f"Logged in at:         {existing.logged_in_at}")
        print(f"Base URL:             {existing.base_url}")
        print("\nRun ./cherrypipe stop to logout, then start again.")
        return

    base_url = MOCK_BASE_URL if args.mock else ILINK_BASE_URL
    print(f"\n🍒 cherrypipe login  ({'mock' if args.mock else 'real'})")
    print("─" * 40)

    asyncio.run(login(base_url))


if __name__ == "__main__":
    main()
