"""
src.sessions
~~~~~~~~~~~~~~~~~~~
Persists agent session IDs per WeChat user.

Each user gets their own session ID, stored in data/sessions.json.
Passing the session ID back to the agent on each call lets Claude
remember the conversation context across multiple messages.

Storage: data/sessions.json (created automatically, gitignored)
"""

from __future__ import annotations

import json
from pathlib import Path

_DATA_DIR     = Path(__file__).parent.parent / "data"
_SESSION_FILE = _DATA_DIR / "sessions.json"


def _load() -> dict[str, str]:
    """Load the session map from disk, returning empty dict if not found."""
    if not _SESSION_FILE.exists():
        return {}
    try:
        return json.loads(_SESSION_FILE.read_text())
    except (json.JSONDecodeError, TypeError) as e:
        print(f"[warn] sessions.json is corrupt, starting fresh: {e}")
        return {}


def _save(sessions: dict[str, str]) -> None:
    """Write the session map to disk."""
    _DATA_DIR.mkdir(parents=True, exist_ok=True)
    _SESSION_FILE.write_text(json.dumps(sessions, indent=2))


def get(user_id: str) -> str | None:
    """Return the current session ID for a user, or None if no session exists."""
    return _load().get(user_id)


def set_session(user_id: str, session_id: str) -> None:
    """Persist a session ID for a user."""
    sessions = _load()
    sessions[user_id] = session_id
    _save(sessions)


def clear(user_id: str) -> None:
    """Delete the session for a user, starting fresh on their next message."""
    sessions = _load()
    if user_id in sessions:
        del sessions[user_id]
        _save(sessions)


def clear_all() -> None:
    """Delete all sessions."""
    _save({})
