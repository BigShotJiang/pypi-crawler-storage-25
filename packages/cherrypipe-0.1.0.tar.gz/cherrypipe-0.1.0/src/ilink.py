"""
src.ilink
~~~~~~~~~~~~~~~~
Async HTTP client for the WeChat iLink Bot API.

All network I/O lives here. Nothing above this layer knows about HTTP,
headers, or WeChat's wire format — they just call methods and get back
clean Python objects.

API base: https://ilinkai.weixin.qq.com/
Docs:     @tencent-weixin/openclaw-weixin (npm)
"""

from __future__ import annotations

import base64
import json
import secrets
import struct
import traceback
import uuid
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any

import httpx

# ── Constants ────────────────────────────────────────────────────────────────

ILINK_BASE_URL = "https://ilinkai.weixin.qq.com/"
LONG_POLL_TIMEOUT_S = 40  # slightly longer than server's 35s hold
API_TIMEOUT_S = 15
CONFIG_TIMEOUT_S = 10


# ── Enums (mirrors the official types.ts) ────────────────────────────────────


class MessageType(IntEnum):
    """Whether a message originated from a human user or from the bot."""

    NONE = 0
    USER = 1  # message FROM a WeChat user
    BOT = 2  # message FROM us (the bot)


class ItemType(IntEnum):
    """Content type of a single item inside a WeChat message."""

    NONE = 0
    TEXT = 1
    IMAGE = 2
    VOICE = 3
    FILE = 4
    VIDEO = 5


class MessageState(IntEnum):
    """Delivery / generation state of a message."""

    NEW = 0
    GENERATING = 1
    FINISH = 2


class TypingStatus(IntEnum):
    """Typing indicator state sent via sendTyping."""

    TYPING = 1
    CANCEL = 2


# ── Data classes ─────────────────────────────────────────────────────────────


@dataclass
class TextItem:
    """Plain-text content of a message item."""

    text: str


@dataclass
class VoiceItem:
    """Voice message content, including an optional speech-to-text transcript."""

    text: str | None = None  # voice-to-text transcript (if available)
    playtime_ms: int = 0


@dataclass
class MessageItem:
    """A single content block inside a WeixinMessage (text, voice, image, ...)."""

    type: ItemType
    text_item: TextItem | None = None
    voice_item: VoiceItem | None = None
    # image/file/video items omitted for now — added in a later step


@dataclass
class WeixinMessage:
    """A complete message received from or sent to a WeChat user via iLink."""

    from_user_id: str
    to_user_id: str
    context_token: str  # MUST be echoed back in replies
    message_type: MessageType
    message_state: MessageState
    items: list[MessageItem] = field(default_factory=list)
    message_id: int | None = None
    session_id: str | None = None

    def text(self) -> str | None:
        """Return the first text or voice-transcript content, or None."""
        for item in self.items:
            if item.type == ItemType.TEXT and item.text_item:
                return item.text_item.text.strip()
            if item.type == ItemType.VOICE and item.voice_item and item.voice_item.text:
                return item.voice_item.text.strip()
        return None


@dataclass
class GetUpdatesResult:
    """Result returned by a single get_updates long-poll call."""

    messages: list[WeixinMessage]
    next_cursor: str  # pass this back on next call
    poll_timeout_ms: int = 35_000


# ── Header helpers ────────────────────────────────────────────────────────────


def _wechat_uin() -> str:
    """X-WECHAT-UIN: random uint32 -> decimal string -> base64."""
    rand_bytes = secrets.token_bytes(4)
    uint32 = struct.unpack(">I", rand_bytes)[0]
    return base64.b64encode(str(uint32).encode()).decode()


def _build_headers(token: str, body: bytes) -> dict[str, str]:
    """Build the required HTTP headers for every iLink API request."""
    return {
        "Content-Type": "application/json",
        "AuthorizationType": "ilink_bot_token",
        "Authorization": f"Bearer {token}",
        "Content-Length": str(len(body)),
        "X-WECHAT-UIN": _wechat_uin(),
    }


# ── Parsing helpers ───────────────────────────────────────────────────────────


def _parse_item(raw: dict[str, Any]) -> MessageItem:
    """Parse a single item_list entry from the iLink wire format."""
    itype = ItemType(raw.get("type", 0))

    text_item = None
    voice_item = None

    if itype == ItemType.TEXT:
        ti = raw.get("text_item") or {}
        text_item = TextItem(text=ti.get("text", ""))

    elif itype == ItemType.VOICE:
        vi = raw.get("voice_item") or {}
        voice_item = VoiceItem(
            text=vi.get("text"),
            playtime_ms=vi.get("playtime", 0),
        )

    return MessageItem(type=itype, text_item=text_item, voice_item=voice_item)


def _parse_message(raw: dict[str, Any]) -> WeixinMessage | None:
    """Parse a raw iLink message dict into a WeixinMessage, or None if it should be skipped."""

    # Skip bot echoes — only handle real user messages
    mtype = MessageType(raw.get("message_type", 0))
    if mtype != MessageType.USER:
        return None

    from_uid = raw.get("from_user_id", "")
    to_uid = raw.get("to_user_id", "")
    if not from_uid:
        return None

    items = [_parse_item(i) for i in raw.get("item_list", [])]

    return WeixinMessage(
        from_user_id=from_uid,
        to_user_id=to_uid,
        context_token=raw.get("context_token", ""),
        message_type=mtype,
        message_state=MessageState(raw.get("message_state", 0)),
        items=items,
        message_id=raw.get("message_id"),
        session_id=raw.get("session_id"),
    )


# ── Client ────────────────────────────────────────────────────────────────────


class ILinkClient:
    """
    Async WeChat iLink Bot API client.

    Usage:
        async with ILinkClient(token="...") as client:
            result = await client.get_updates(cursor="")
            for msg in result.messages:
                await client.send_text(msg.from_user_id, msg.context_token, "Hi!")
    """

    def __init__(self, token: str, base_url: str = ILINK_BASE_URL) -> None:
        self.token = token
        self.base_url = base_url.rstrip("/") + "/"
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> ILinkClient:
        self._client = httpx.AsyncClient(base_url=self.base_url, timeout=None)
        return self

    async def __aexit__(self, *_: Any) -> None:
        if self._client:
            await self._client.aclose()

    # ── Internal ──────────────────────────────────────────────────────────────

    async def _post(
        self,
        endpoint: str,
        payload: dict[str, Any],
        timeout: float,
    ) -> dict[str, Any]:
        """POST JSON to an iLink endpoint and return the parsed response."""
        body = json.dumps(
            {**payload, "base_info": {"channel_version": "1.0.0"}}
        ).encode()
        headers = _build_headers(self.token, body)

        assert self._client is not None, "Use 'async with ILinkClient(...) as client'"

        resp = await self._client.post(
            endpoint,
            content=body,
            headers=headers,
            timeout=timeout,
        )
        resp.raise_for_status()
        return resp.json()  # type: ignore[no-any-return]

    # ── Public API ────────────────────────────────────────────────────────────

    async def get_updates(self, cursor: str = "") -> GetUpdatesResult:
        """
        Long-poll for new messages.
        Blocks until messages arrive or the server times out (~35s).
        On timeout returns an empty result — just call again.
        """
        try:
            data = await self._post(
                "ilink/bot/getupdates",
                {"get_updates_buf": cursor},
                timeout=LONG_POLL_TIMEOUT_S,
            )
        except httpx.TimeoutException:
            # Timeout is normal for long-polling — return empty, caller retries
            return GetUpdatesResult(messages=[], next_cursor=cursor)

        if data.get("errcode") == -14:
            raise SessionExpiredError("iLink session expired — please re-login")

        messages = []
        for raw in data.get("msgs") or []:
            msg = _parse_message(raw)
            if msg:
                messages.append(msg)

        return GetUpdatesResult(
            messages=messages,
            next_cursor=data.get("get_updates_buf", cursor),
            poll_timeout_ms=data.get("longpolling_timeout_ms", 35_000),
        )

    async def send_text(
        self,
        to_user_id: str,
        context_token: str,
        text: str,
    ) -> None:
        """Send a plain-text message to a WeChat user."""

        # WeChat has a ~4000 char limit per message — split if needed
        for chunk in _split(text, 4000):
            client_id = f"cherrypipe-{uuid.uuid4().hex}"
            await self._post(
                "ilink/bot/sendmessage",
                {
                    "msg": {
                        "from_user_id": "",  # required by iLink API
                        "to_user_id": to_user_id,
                        "client_id": client_id,  # unique per message
                        "context_token": context_token,
                        "message_type": int(MessageType.BOT),
                        "message_state": int(MessageState.FINISH),
                        "item_list": [
                            {"type": int(ItemType.TEXT), "text_item": {"text": chunk}}
                        ],
                    }
                },
                timeout=API_TIMEOUT_S,
            )

    async def send_typing(
        self, user_id: str, context_token: str, typing: bool = True
    ) -> None:
        """
        Show or hide the typing indicator for a user.

        This is best-effort — a failure here must never crash the bridge.
        However, we always log failures with full tracebacks so engineers
        can diagnose issues (e.g. unexpected API responses, network errors).
        """
        try:
            cfg = await self._post(
                "ilink/bot/getconfig",
                {"ilink_user_id": user_id, "context_token": context_token},
                timeout=CONFIG_TIMEOUT_S,
            )
            ticket = cfg.get("typing_ticket")
            if ticket:
                await self._post(
                    "ilink/bot/sendtyping",
                    {
                        "ilink_user_id": user_id,
                        "typing_ticket": ticket,
                        "status": int(
                            TypingStatus.TYPING if typing else TypingStatus.CANCEL
                        ),
                    },
                    timeout=CONFIG_TIMEOUT_S,
                )
        except Exception as e:
            # Non-fatal: log the full traceback so engineers can see what went wrong,
            # but do not propagate — a typing indicator failure must not disrupt the bridge.
            print(f"[warn] send_typing failed (non-fatal): {type(e).__name__}: {e}")
            print(traceback.format_exc())


# ── Errors ────────────────────────────────────────────────────────────────────


class SessionExpiredError(Exception):
    """Raised when iLink returns errcode -14 (token expired)."""


# ── Utilities ─────────────────────────────────────────────────────────────────


def _split(text: str, max_len: int) -> list[str]:
    """Split text into chunks of at most max_len characters."""
    return [text[i : i + max_len] for i in range(0, max(len(text), 1), max_len)]
