"""
src.pairing
~~~~~~~~~~~~~~~~~~
Access control for cherrypipe.

When an unknown WeChat user sends a message, we generate a 6-digit
pairing code and send it back to them. They confirm by sending the
code back. Once paired, they stay in the allowlist until explicitly
removed.

Storage: data/pairs.json (created automatically, gitignored)

Pairing flow:
    Unknown user sends any message
        → bridge generates a 6-digit code
        → bridge sends code back to user
        → user sends the code back
        → bridge confirms, user is now in allowlist
        → all future messages go straight to the agent
"""

from __future__ import annotations

import json
import secrets
import time
from dataclasses import asdict, dataclass
from pathlib import Path

_DATA_DIR   = Path(__file__).parent.parent / "data"
_PAIRS_FILE = _DATA_DIR / "pairs.json"

_CODE_TTL_S = 600   # pairing codes expire after 10 minutes


# ── Data models ───────────────────────────────────────────────────────────────

@dataclass
class PairedUser:
    """A WeChat user who has successfully completed the pairing flow."""

    user_id:   str
    paired_at: float   # unix timestamp
    label:     str     # human-readable nickname, defaults to user_id


@dataclass
class PendingCode:
    """A pairing code that has been issued but not yet confirmed."""

    user_id:    str
    code:       str
    created_at: float   # unix timestamp


@dataclass
class PairingStore:
    """Full contents of data/pairs.json."""

    paired:  list[PairedUser]
    pending: list[PendingCode]
    locked:  bool   # when True, no new pairing codes are issued


# ── Persistence ───────────────────────────────────────────────────────────────

def _load() -> PairingStore:
    """Load pairs.json from disk, returning an empty store if it doesn't exist."""
    if not _PAIRS_FILE.exists():
        return PairingStore(paired=[], pending=[], locked=False)
    try:
        raw = json.loads(_PAIRS_FILE.read_text())
        return PairingStore(
            paired  = [PairedUser(**u) for u in raw.get("paired", [])],
            pending = [PendingCode(**p) for p in raw.get("pending", [])],
            locked  = raw.get("locked", False),
        )
    except (json.JSONDecodeError, TypeError) as e:
        print(f"[warn] pairs.json is corrupt, starting fresh: {e}")
        return PairingStore(paired=[], pending=[], locked=False)


def _save(store: PairingStore) -> None:
    """Write the pairing store to disk."""
    _DATA_DIR.mkdir(parents=True, exist_ok=True)
    _PAIRS_FILE.write_text(json.dumps({
        "paired":  [asdict(u) for u in store.paired],
        "pending": [asdict(p) for p in store.pending],
        "locked":  store.locked,
    }, indent=2))


# ── Public API ────────────────────────────────────────────────────────────────

def is_paired(user_id: str) -> bool:
    """Return True if this user has already completed pairing."""
    return any(u.user_id == user_id for u in _load().paired)


def is_locked() -> bool:
    """Return True if new pairing codes are currently disabled."""
    return _load().locked


def set_locked(locked: bool) -> None:
    """Enable or disable issuance of new pairing codes."""
    store = _load()
    store.locked = locked
    _save(store)


def issue_code(user_id: str) -> str | None:
    """
    Issue a new 6-digit pairing code for an unknown user.

    Returns the code string, or None if pairing is locked.
    If a valid unexpired code already exists for this user, returns it
    unchanged — so re-sending a message shows the same code, not a new one.
    """
    store = _load()

    if store.locked:
        return None

    now = time.time()

    # Reuse an existing valid code if one exists
    for pending in store.pending:
        if pending.user_id == user_id:
            if now - pending.created_at < _CODE_TTL_S:
                return pending.code
            # Expired — remove it and issue a fresh one
            store.pending = [p for p in store.pending if p.user_id != user_id]
            break

    code = str(secrets.randbelow(900_000) + 100_000)   # 100000–999999
    store.pending.append(PendingCode(user_id=user_id, code=code, created_at=now))
    _save(store)
    return code


def confirm_code(code: str) -> str | None:
    """
    Confirm a pairing code entered by the user.

    Returns the user_id that was paired on success, or None if the code
    is invalid, expired, or does not match any pending entry.
    """
    store = _load()
    now   = time.time()

    for pending in store.pending:
        if pending.code == code:
            if now - pending.created_at > _CODE_TTL_S:
                # Expired — clean it up and tell the caller
                store.pending = [p for p in store.pending if p.code != code]
                _save(store)
                return None

            # Valid — promote to paired
            store.pending = [p for p in store.pending if p.code != code]
            store.paired.append(PairedUser(
                user_id   = pending.user_id,
                paired_at = now,
                label     = pending.user_id,
            ))
            _save(store)
            return pending.user_id

    return None


def list_paired() -> list[PairedUser]:
    """Return all currently paired users."""
    return _load().paired


def remove_paired(user_id: str) -> bool:
    """
    Remove a user from the allowlist.

    Returns True if the user was found and removed, False if not found.
    """
    store  = _load()
    before = len(store.paired)
    store.paired = [u for u in store.paired if u.user_id != user_id]
    _save(store)
    return len(store.paired) < before


def owner_id() -> str | None:
    """
    Return the user_id of the first paired user (the owner).

    The owner gets extra admin commands like /lock and /unlock.
    Returns None if no users have paired yet.
    """
    paired = _load().paired
    return paired[0].user_id if paired else None
