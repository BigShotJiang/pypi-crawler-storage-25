"""
src.agents.claude
~~~~~~~~~~~~~~~~~~~~~~~~
Claude Code agent implementation.

Spawns the `claude` CLI as a subprocess using --output-format stream-json,
which emits structured JSON events line by line as Claude thinks.
Each session is resumable via --resume <session_id>, giving each WeChat
user their own persistent conversation context.

Requirements:
    - `claude` CLI installed and authenticated
    - Install: npm install -g @anthropic-ai/claude-code
    - Auth:    claude auth login
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
from pathlib import Path

from src.agents.base import Agent, AgentResult

_DEFAULT_CWD = Path.home() / ".cherrypipe" / "workspace"


class ClaudeAgent(Agent):
    """
    AI coding agent backed by the Claude Code CLI.

    Communicates via `claude -p <prompt> --output-format stream-json`.
    Sessions persist across messages using `--resume <session_id>`.
    """

    name = "claude"
    description = "Claude Code by Anthropic"
    aliases = ["cc", "c"]

    def _claude_path(self) -> str:
        """
        Resolve the claude binary path, checking PATH and common locations.

        Returns the first found path, or bare 'claude' as a fallback
        which will raise FileNotFoundError with a clear message if missing.
        """
        # Check PATH first (works in interactive shells)
        path = shutil.which("claude")
        if path:
            return path
        # Check common install locations (for launchd / non-interactive shells)
        for candidate in [
            "/opt/homebrew/bin/claude",  # macOS Apple Silicon (Homebrew)
            "/usr/local/bin/claude",  # macOS Intel (Homebrew) / Linux
            str(Path.home() / ".local" / "bin" / "claude"),  # pip user install
        ]:
            if Path(candidate).exists():
                return candidate
        return "claude"  # fallback — will raise FileNotFoundError with clear message

    async def is_available(self) -> bool:
        """Return True if the claude CLI is installed and reachable."""
        return self._claude_path() != "claude" or shutil.which("claude") is not None

    async def run(
        self,
        prompt: str,
        session_id: str | None = None,
        cwd: str | None = None,
    ) -> AgentResult:
        """
        Run a prompt through Claude Code and return the full response.

        Streams JSON events from the claude CLI, collecting assistant text
        blocks and extracting the session_id for conversation continuity.
        """
        work_dir = Path(cwd) if cwd else _DEFAULT_CWD
        work_dir.mkdir(parents=True, exist_ok=True)

        args = self._build_args(prompt, session_id)

        try:
            output, new_session_id = await self._stream(args, work_dir)
        except FileNotFoundError:
            return AgentResult(
                text=(
                    "claude CLI not found. Install it with:\n"
                    "  npm install -g @anthropic-ai/claude-code\n"
                    "Then authenticate with:\n"
                    "  claude auth login"
                ),
                success=False,
            )
        except asyncio.TimeoutError:
            return AgentResult(
                text="Claude took too long to respond (5 minute timeout). Try a simpler prompt.",
                success=False,
            )

        if not output.strip():
            return AgentResult(
                text="Claude returned an empty response.",
                session_id=new_session_id,
                success=False,
            )

        return AgentResult(
            text=output.strip(),
            session_id=new_session_id,
            success=True,
        )

    # ── Private helpers ───────────────────────────────────────────────────────

    def _build_args(self, prompt: str, session_id: str | None) -> list[str]:
        """Build the claude CLI argument list for this prompt."""
        args = [
            self._claude_path(),  # resolved full path
            "--print",
            "--verbose",  # required with stream-json
            "--output-format",
            "stream-json",
            "--dangerously-skip-permissions",
        ]
        if session_id:
            args += ["--resume", session_id]
        args += ["--", prompt]
        return args

    async def _stream(
        self,
        args: list[str],
        work_dir: Path,
    ) -> tuple[str, str | None]:
        """
        Spawn the claude subprocess and stream its JSON output.

        Returns a tuple of (full_response_text, session_id).
        Raises asyncio.TimeoutError if claude takes more than 5 minutes.
        Raises FileNotFoundError if the claude binary is not on PATH.
        """
        env = {**os.environ}

        proc = await asyncio.create_subprocess_exec(
            *args,
            cwd=str(work_dir),
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        text_parts: list[str] = []
        self._last_session_id = None

        async def read_stdout() -> None:
            """Read and parse stream-json events from stdout."""
            assert proc.stdout is not None
            async for raw_line in proc.stdout:
                line = raw_line.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                self._handle_event(line, text_parts)

        async def read_stderr() -> None:
            """Drain stderr so the subprocess never blocks on a full pipe."""
            assert proc.stderr is not None
            async for raw_line in proc.stderr:
                line = raw_line.decode("utf-8", errors="replace").strip()
                if line:
                    print(f"[claude stderr] {line}")

        # Run with a 5-minute hard timeout
        try:
            await asyncio.wait_for(
                asyncio.gather(read_stdout(), read_stderr()),
                timeout=300,
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            raise

        await proc.wait()

        return "\n".join(text_parts), self._last_session_id

    def _handle_event(self, line: str, text_parts: list[str]) -> None:
        """
        Parse one stream-json event line and extract text or session_id.

        Claude emits events like:
            {"type": "assistant", "message": {"content": [{"type": "text", "text": "..."}]}}
            {"type": "result", "session_id": "abc123", ...}
        """
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            # Non-JSON line — treat as plain text output
            text_parts.append(line)
            return

        event_type = event.get("type")

        if event_type == "assistant":
            message = event.get("message") or {}
            for block in message.get("content") or []:
                if block.get("type") == "text":
                    text = block.get("text", "")
                    if text:
                        text_parts.append(text)

        elif event_type == "result":
            sid = event.get("session_id")
            if sid:
                self._last_session_id = sid

    def __init__(self) -> None:
        """Initialise the Claude agent with an empty session ID cache."""
        self._last_session_id: str | None = None
