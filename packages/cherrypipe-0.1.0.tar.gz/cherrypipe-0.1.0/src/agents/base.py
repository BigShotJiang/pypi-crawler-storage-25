"""
src.agents.base
~~~~~~~~~~~~~~~~~~~~~~
Abstract base class for all AI coding agents.

Every agent (Claude, Codex, Gemini, ...) must subclass Agent and
implement its two abstract methods. The rest of the bridge only
ever talks to this interface — it never imports a concrete agent
directly. This means adding a new agent is purely additive: create
a new file, subclass Agent, register it. Nothing else changes.

Adding a new agent:
    1. Create src/agents/your_agent.py
    2. Subclass Agent and implement run() and is_available()
    3. Register it in src/agents/__init__.py
    4. Done — the bridge picks it up automatically
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


# ── Result type ───────────────────────────────────────────────────────────────

@dataclass
class AgentResult:
    """
    The outcome of a single agent run.

    Attributes:
        text:       The agent's full response text.
        session_id: Opaque session identifier returned by the agent.
                    Pass this back on the next call to continue the
                    same conversation. None means no session to resume.
        success:    False if the agent exited with an error. In that
                    case, text contains the error message to show the user.
    """

    text:       str
    session_id: str | None = None
    success:    bool = True


# ── Agent interface ───────────────────────────────────────────────────────────

class Agent(ABC):
    """
    Abstract base class for a cherrypipe AI coding agent.

    Subclass this and implement run() and is_available().
    All other behaviour (routing, pairing, iLink I/O) is handled
    by the bridge and never needs to change when you add an agent.

    Class attributes to set in each subclass:
        name:        Short identifier used in commands, e.g. "claude"
        description: One-line description shown in /agents output
        aliases:     Alternative names the user can use, e.g. ["cc", "c"]
    """

    name:        str = ""
    description: str = ""
    aliases:     list[str] = [] # override in each subclass with a new list

    @abstractmethod
    async def run(
        self,
        prompt:     str,
        session_id: str | None = None,
        cwd:        str | None = None,
    ) -> AgentResult:
        """
        Send a prompt to the agent and return its response.

        Args:
            prompt:     The user's message text.
            session_id: If provided, resume this existing session.
                        If None, start a fresh conversation.
            cwd:        Working directory for the agent process.
                        If None, the agent uses its own default.

        Returns:
            AgentResult with the response text and next session_id.
        """

    @abstractmethod
    async def is_available(self) -> bool:
        """
        Check whether this agent is installed and ready to use.

        Should return True only if the agent CLI / API is reachable.
        Used at startup to auto-detect which agents are available,
        and in the /agents command to show the user what they can use.
        """
