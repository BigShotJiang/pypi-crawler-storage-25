"""
src.agents
~~~~~~~~~~~~~~~~~
Agent registry.

To add a new agent:
    1. Implement it in its own module (e.g. src/agents/codex.py)
    2. Import it here and add it to ALL_AGENTS

The bridge imports ALL_AGENTS at startup, calls is_available() on each,
and builds the active agent list from whatever responds True.
"""

from src.agents.base import Agent, AgentResult
from src.agents.claude import ClaudeAgent

ALL_AGENTS: list[type[Agent]] = [
    ClaudeAgent,
    # Add future agents here:
    # CodexAgent,
    # GeminiAgent,
]

__all__ = ["Agent", "AgentResult", "ALL_AGENTS"]
