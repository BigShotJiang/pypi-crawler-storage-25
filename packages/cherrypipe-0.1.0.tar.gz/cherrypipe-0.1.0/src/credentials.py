"""
src.credentials
~~~~~~~~~~~~~~~~~~~~~~
Handles reading and writing the iLink bot token to disk.

The token is stored in data/credentials.json with permissions 0600
(readable only by the current user). Nothing else in the project
touches this file directly — all access goes through this module.
"""

from __future__ import annotations

import json
import stat
from dataclasses import asdict, dataclass
from pathlib import Path

# Always relative to the project root, regardless of where you run from
_DATA_DIR   = Path(__file__).parent.parent / "data"
_CREDS_FILE = _DATA_DIR / "credentials.json"


@dataclass
class Credentials:
    """Stored iLink bot token and associated account metadata."""

    token:      str
    account_id: str
    base_url:   str
    logged_in_at: str  # ISO 8601 timestamp


def save(creds: Credentials) -> None:
    """
    Write credentials to disk.

    Creates the data/ directory if it does not exist, then writes
    credentials.json with mode 0600 so only the current user can read it.
    """
    _DATA_DIR.mkdir(parents=True, exist_ok=True)
    path = _CREDS_FILE
    path.write_text(json.dumps(asdict(creds), indent=2))
    # Restrict to owner read/write only — token must never be world-readable
    path.chmod(stat.S_IRUSR | stat.S_IWUSR)


def load() -> Credentials | None:
    """
    Load credentials from disk.

    Returns None (rather than raising) if the file does not exist,
    so callers can handle the not-logged-in case gracefully.
    """
    if not _CREDS_FILE.exists():
        return None
    try:
        data = json.loads(_CREDS_FILE.read_text())
        return Credentials(**data)
    except (json.JSONDecodeError, TypeError) as e:
        print(f"[warn] credentials file is corrupt and will be ignored: {e}")
        return None


def clear() -> None:
    """Delete the stored credentials (logout)."""
    if _CREDS_FILE.exists():
        _CREDS_FILE.unlink()
        print("Credentials cleared.")
    else:
        print("No credentials found — already logged out.")


def require() -> Credentials:
    """
    Load credentials or exit with a clear error message.

    Use this at the start of any command that needs authentication,
    so the user gets a helpful message instead of a confusing traceback.
    """
    creds = load()
    if creds is None:
        print("Not logged in. Run:  python login.py")
        raise SystemExit(1)
    return creds
