"""
src.handler
~~~~~~~~~~~~~~~~~~
Routes incoming WeChat messages to the right action and sends replies.

This is the single place where all layers meet:
    iLink message → pairing check → command or agent → iLink reply

It intentionally contains no business logic of its own — it delegates
everything to the appropriate module (pairing, sessions, agent).

Commands available to paired users:
    /new             — clear session, start fresh conversation
    /session         — show current session ID
    /agent <name>    — switch to a different agent
    /agents          — list available agents
    /help            — show all commands
    /cwd <path>      — set working directory for the agent

Admin commands (run from CLI, not WeChat):
    python cli.py lock            — stop new pairings
    python cli.py unlock          — allow new pairings
    python cli.py unpair <id>     — remove a user
    python cli.py paired          — list paired users
"""

from __future__ import annotations

import asyncio
import os
import subprocess

from src import sessions
from src.agents.base import Agent
from src.ilink import ILinkClient, WeixinMessage
from src.pairing import (
    confirm_code,
    is_locked,
    is_paired,
    issue_code,
    list_paired,
)

# ── Help text ─────────────────────────────────────────────────────────────────

_HELP = """
🍒 cherrypipe commands:

  /new              start a fresh conversation
  /session          show your session ID
  /agents           list available agents
  /agent <name>     switch agent (e.g. /agent claude)
  /cwd <path>       set agent working directory
  /status           show bridge status
  /stop             stop the bridge
  /help             show this message
""".strip()


# ── Handler ───────────────────────────────────────────────────────────────────


class MessageHandler:
    """
    Stateless message router for the cherrypipe bridge.

    Receives a WeixinMessage from the poll loop and dispatches it to
    the correct action. Holds a reference to the active agent, which
    can be switched at runtime via the /agent command.
    """

    def __init__(self, client: ILinkClient, agents: list[Agent]) -> None:
        self._client = client
        self._agents = {a.name: a for a in agents}
        # Also register aliases so /cc works the same as /claude
        for agent in agents:
            for alias in agent.aliases:
                self._agents[alias] = agent
        self._active_agent = agents[0] if agents else None
        # Per-user working directories
        self._cwd: dict[str, str] = {}

    async def handle(self, msg: WeixinMessage) -> None:
        """
        Handle one incoming WeChat message end-to-end.

        Flow:
            1. Extract text
            2. If user is not paired → run pairing flow
            3. If text is a /command → run command handler
            4. Otherwise → forward to active agent, send reply
        """
        user_id = msg.from_user_id
        token = msg.context_token
        text = msg.text()

        # Non-text messages from unpaired users — ignore silently
        if text is None:
            if is_paired(user_id):
                await self._reply(token, user_id, "⚠️ Only text messages are supported.")
            return

        # ── Pairing flow ──────────────────────────────────────────────────────
        if not is_paired(user_id):
            await self._handle_pairing(user_id, token, text)
            return

        # ── Commands ──────────────────────────────────────────────────────────
        if text.startswith("/"):
            await self._handle_command(user_id, token, text)
            return

        # ── Forward to agent ──────────────────────────────────────────────────
        await self._handle_agent(user_id, token, text)

    # ── Pairing ───────────────────────────────────────────────────────────────

    async def _handle_pairing(self, user_id: str, token: str, text: str) -> None:
        """
        Handle messages from users who have not yet paired.

        Flow:
            - If user sends a 6-digit code → confirm it
            - Otherwise → generate a code, print it to terminal,
              tell user to check the terminal and type it in WeChat
        """
        # Check if they're submitting a code they saw on the terminal
        if text.strip().isdigit() and len(text.strip()) == 6:
            paired_id = confirm_code(text.strip())
            if paired_id:
                await self._reply(token, user_id, await self._welcome_message())
                return
            await self._reply(token, user_id, "❌ Invalid or expired code. Try again.")
            return

        if is_locked():
            await self._reply(token, user_id, "🔒 This bridge is locked.")
            return

        # Issue (or reuse) a pairing code — print to terminal only
        code = issue_code(user_id)
        if code is None:
            await self._reply(token, user_id, "🔒 This bridge is locked.")
            return

        # Show code on the terminal — user walks to their machine to see it
        print(f"\n{'─' * 40}")
        print(f"🍒 Pairing request from: {user_id}")
        print(f"   Code: {code}")
        print(f"{'─' * 40}\n")

        await self._reply(
            token,
            user_id,
            "👋 Welcome to cherrypipe!\n\n"
            "Check the terminal for your pairing code,\n"
            "then type it here to connect.",
        )

    async def _welcome_message(self) -> str:
        """Build the post-pairing welcome message showing available agents."""
        lines = ["✅ Paired!\n"]

        # List available agents
        seen = set()
        available = []
        for agent in self._agents.values():
            if agent.name in seen:
                continue
            seen.add(agent.name)
            if await agent.is_available():
                available.append(agent)

        if available:
            lines.append("Available agents:")
            for agent in available:
                active = " ← active" if agent is self._active_agent else ""
                lines.append(f"  • {agent.name} — {agent.description}{active}")
            lines.append("\nSend any message to start talking.")
            lines.append("Type /help for all commands.")
        else:
            lines.append("⚠️ No agents found on this machine.\n")
            lines.append("To install Claude Code:")
            lines.append("  npm install -g @anthropic-ai/claude-code")
            lines.append("  claude auth login\n")
            lines.append("Then restart cherrypipe.")

        return "\n".join(lines)

    # ── Commands ──────────────────────────────────────────────────────────────

    async def _handle_command(self, user_id: str, token: str, text: str) -> None:
        """Dispatch a /command message to the right handler."""
        parts = text.strip().split(maxsplit=1)
        command = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if command == "/new":
            sessions.clear(user_id)
            await self._reply(token, user_id, "🔄 Session cleared — starting fresh.")

        elif command == "/session":
            sid = sessions.get(user_id)
            await self._reply(
                token, user_id, f"Session: {sid}" if sid else "No active session."
            )

        elif command == "/agents":
            await self._handle_list_agents(token, user_id)

        elif command == "/agent":
            await self._handle_switch_agent(token, user_id, arg)

        elif command == "/cwd":
            await self._handle_cwd(token, user_id, arg)

        elif command == "/help":
            await self._reply(token, user_id, _HELP)

        elif command == "/status":
            await self._handle_status(token, user_id)

        elif command == "/stop":
            await self._handle_stop(token, user_id)

        else:
            await self._reply(
                token,
                user_id,
                f"Unknown command: {command}\n\nType /help for commands.",
            )

    async def _handle_list_agents(self, token: str, user_id: str) -> None:
        """Reply with a list of available agents and which is active."""
        lines = []
        seen = set()
        for agent in self._agents.values():
            if agent.name in seen:
                continue
            seen.add(agent.name)
            active = " ← active" if agent is self._active_agent else ""
            lines.append(f"• {agent.name} — {agent.description}{active}")
        await self._reply(token, user_id, "Available agents:\n" + "\n".join(lines))

    async def _handle_switch_agent(self, token: str, user_id: str, name: str) -> None:
        """Switch the active agent by name or alias."""
        if not name:
            await self._reply(
                token, user_id, "Usage: /agent <name>\n\nType /agents to see options."
            )
            return
        agent = self._agents.get(name.lower())
        if agent is None:
            await self._reply(
                token, user_id, f"Unknown agent: {name}\n\nType /agents to see options."
            )
            return
        if not await agent.is_available():
            await self._reply(
                token, user_id, f"❌ {agent.name} is not installed on this machine."
            )
            return
        self._active_agent = agent
        await self._reply(token, user_id, f"✅ Switched to {agent.name}.")

    async def _handle_cwd(self, token: str, user_id: str, path: str) -> None:
        """Set the working directory used by the agent for this user."""
        if not path:
            current = self._cwd.get(user_id, "default")
            await self._reply(token, user_id, f"Current working directory: {current}")
            return
        self._cwd[user_id] = path
        await self._reply(token, user_id, f"📁 Working directory set to: {path}")

    async def _handle_status(self, token: str, user_id: str) -> None:
        """Reply with current bridge status."""
        paired = list_paired()
        sid = sessions.get(user_id)
        agent = self._active_agent.name if self._active_agent else "none"
        cwd = self._cwd.get(user_id, "default")
        lines = [
            "🍒 cherrypipe status",
            f"Agent:    {agent}",
            f"Session:  {sid or 'none'}",
            f"Cwd:      {cwd}",
            f"Paired:   {len(paired)} user(s)",
        ]
        await self._reply(token, user_id, "\n".join(lines))

    async def _handle_stop(self, token: str, user_id: str) -> None:
        """Stop the bridge service from WeChat."""
        await self._reply(
            token,
            user_id,
            "🛑 Stopping cherrypipe...\n\nAll data will be cleared.\nRun ./cherrypipe start to set up again.",
        )
        await asyncio.sleep(2)
        subprocess.Popen(
            [
                "launchctl",
                "unload",
                f"{os.path.expanduser('~')}/Library/LaunchAgents/com.cherrypipe.bridge.plist",
            ]
        )

    # ── Agent forwarding ──────────────────────────────────────────────────────

    async def _handle_agent(self, user_id: str, token: str, text: str) -> None:
        """Forward a message to the active agent and send the reply."""
        if self._active_agent is None:
            await self._reply(
                token, user_id, "❌ No agent available. Check your installation."
            )
            return

        # Show typing indicator while agent thinks
        await self._client.send_typing(user_id, token, typing=True)

        try:
            result = await self._active_agent.run(
                prompt=text,
                session_id=sessions.get(user_id),
                cwd=self._cwd.get(user_id),
            )
        finally:
            # Always cancel typing indicator — even if agent raises
            await self._client.send_typing(user_id, token, typing=False)

        # Persist new session ID if we got one
        if result.session_id:
            sessions.set_session(user_id, result.session_id)

        await self._reply(token, user_id, result.text)

    # ── Reply helper ──────────────────────────────────────────────────────────

    async def _reply(self, context_token: str, to_user_id: str, text: str) -> None:
        """Send a text reply to a WeChat user."""
        await self._client.send_text(
            to_user_id=to_user_id,
            context_token=context_token,
            text=text,
        )
