"""
cherrypipe 🍒
WeChat → AI coding agent bridge
"""

__version__ = "0.1.0"
