# cherrypipe 🍒

Control Claude Code from WeChat.

## Setup
```bash
pip install cherrypipe
cherrypipe start
```

Scan the QR code with WeChat, pair, and start chatting with Claude Code from your phone.

## Requirements

- macOS
- Python 3.11+
- Claude Code CLI
- WeChat with ClawBot access
