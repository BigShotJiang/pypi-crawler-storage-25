"""
cli.py
~~~~~~
cherrypipe admin CLI.

Usage:
    python cli.py status                    — show bridge status
    python cli.py pair <code>               — confirm a pairing code
    python cli.py paired                    — list paired users
    python cli.py unpair <user_id>          — remove a paired user
    python cli.py lock                      — stop new pairings
    python cli.py unlock                    — allow new pairings
    python cli.py send <user_id> <message>  — send a message proactively
    python cli.py clear-sessions            — clear all Claude sessions
    python cli.py logout                    — clear saved credentials
"""

from __future__ import annotations

import argparse
import asyncio
import sys

from src import sessions
from src.credentials import clear as logout, load
from src.ilink import ILinkClient
from src.pairing import (
    confirm_code,
    list_paired,
    remove_paired,
    set_locked,
    is_locked,
)


# ── Commands ──────────────────────────────────────────────────────────────────

def cmd_status() -> None:
    """Show current bridge status: credentials, paired users, lock state."""
    creds = load()
    print("\n🍒 cherrypipe status")
    print("─" * 40)

    if creds:
        print(f"Account:    {creds.account_id}")
        print(f"API:        {creds.base_url}")
        print(f"Logged in:  {creds.logged_in_at}")
    else:
        print("Not logged in. Run:  python login.py")

    paired = list_paired()
    locked = is_locked()
    print(f"\nPaired users: {len(paired)}")
    for u in paired:
        print(f"  • {u.user_id}")

    print(f"Pairing:      {'locked 🔒' if locked else 'open 🔓'}")
    print()


def cmd_pair(code: str) -> None:
    """Confirm a 6-digit pairing code."""
    user_id = confirm_code(code)
    if user_id:
        print(f"✅ Paired: {user_id}")
    else:
        print("❌ Invalid or expired code.")
        sys.exit(1)


def cmd_paired() -> None:
    """List all paired users."""
    users = list_paired()
    if not users:
        print("No paired users.")
        return
    print(f"\n{'User ID':<40} {'Paired at'}")
    print("─" * 60)
    for u in users:
        import datetime
        dt = datetime.datetime.fromtimestamp(u.paired_at).strftime("%Y-%m-%d %H:%M")
        print(f"{u.user_id:<40} {dt}")
    print()


def cmd_unpair(user_id: str) -> None:
    """Remove a user from the allowlist."""
    if remove_paired(user_id):
        sessions.clear(user_id)
        print(f"✅ Removed: {user_id}")
    else:
        print(f"❌ User not found: {user_id}")
        sys.exit(1)


def cmd_lock() -> None:
    """Stop new pairing codes from being issued."""
    set_locked(True)
    print("🔒 Pairing locked — no new users can pair.")


def cmd_unlock() -> None:
    """Allow new pairing codes to be issued."""
    set_locked(False)
    print("🔓 Pairing unlocked — new users can pair.")


def cmd_clear_sessions() -> None:
    """Clear all stored Claude session IDs."""
    sessions.clear_all()
    print("✅ All sessions cleared.")


def cmd_logout() -> None:
    """Remove saved credentials."""
    logout()


async def cmd_send(user_id: str, text: str) -> None:
    """Send a proactive message to a paired WeChat user."""
    creds = load()
    if not creds:
        print("❌ Not logged in. Run:  python login.py")
        sys.exit(1)

    async with ILinkClient(token=creds.token, base_url=creds.base_url) as client:
        await client.send_text(
            to_user_id    = user_id,
            context_token = "",
            text          = text,
        )
    print(f"✅ Sent to {user_id}")


# ── Argument parser ───────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser for the cherrypipe CLI."""
    parser = argparse.ArgumentParser(
        prog        = "python cli.py",
        description = "cherrypipe admin CLI",
    )
    sub = parser.add_subparsers(dest="command", metavar="command")
    sub.required = True

    sub.add_parser("status",         help="show bridge status")
    sub.add_parser("paired",         help="list paired users")
    sub.add_parser("lock",           help="stop new pairings")
    sub.add_parser("unlock",         help="allow new pairings")
    sub.add_parser("clear-sessions", help="clear all Claude sessions")
    sub.add_parser("logout",         help="clear saved credentials")

    p_pair = sub.add_parser("pair", help="confirm a pairing code")
    p_pair.add_argument("code", help="6-digit pairing code")

    p_unpair = sub.add_parser("unpair", help="remove a paired user")
    p_unpair.add_argument("user_id", help="user ID to remove")

    p_send = sub.add_parser("send", help="send a message to a user")
    p_send.add_argument("user_id", help="target user ID")
    p_send.add_argument("text",    help="message text", nargs=argparse.REMAINDER)

    return parser


# ── Entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    """Parse arguments and dispatch to the correct command."""
    parser = build_parser()
    args   = parser.parse_args()

    if args.command == "status":
        cmd_status()
    elif args.command == "pair":
        cmd_pair(args.code)
    elif args.command == "paired":
        cmd_paired()
    elif args.command == "unpair":
        cmd_unpair(args.user_id)
    elif args.command == "lock":
        cmd_lock()
    elif args.command == "unlock":
        cmd_unlock()
    elif args.command == "clear-sessions":
        cmd_clear_sessions()
    elif args.command == "logout":
        cmd_logout()
    elif args.command == "send":
        text = " ".join(args.text)
        if not text:
            print("❌ Please provide a message.")
            sys.exit(1)
        asyncio.run(cmd_send(args.user_id, text))


if __name__ == "__main__":
    main()
