import os
import threading
from enkrypto_sdk.core.sdk import EnkryptoSDK


# store running SDKs
running = {}


def detect_type(path):
    if path.endswith(".json"):
        return "json"
    elif path.endswith(".csv"):
        return "csv"
    elif path.endswith(".xlsx") or path.endswith(".xls"):
        return "excel"
    else:
        raise ValueError("unsupported file type")


def handle_connect(path):
    path = os.path.abspath(path)

    if path in running:
        print("[!] already running")
        return

    if not os.path.exists(path):
        print("file not found")
        return

    try:
        db_type = detect_type(path)
    except Exception as e:
        print(str(e))
        return

    config = {
        "type": db_type,
        "path": path,
        "endpoint": "http://localhost:8000/proof",
        "api_key": "test"
    }

    print(f"[+] connecting to {path} as {db_type}...")

    sdk = EnkryptoSDK(config)
    sdk.init()

    t = threading.Thread(target=sdk.start, daemon=True)
    t.start()

    running[path] = (sdk, t)

    print(f"[✓] tracking started for {path}")


def handle_status(path):
    path = os.path.abspath(path)

    if path in running:
        print(f"[✓] running: {path}")
    else:
        print(f"[✗] not running: {path}")


def handle_stop(path):
    path = os.path.abspath(path)

    if path not in running:
        print("[✗] not running")
        return

    # NOTE: real stop not implemented yet
    del running[path]

    print(f"[!] stopped (logical only): {path}")


def shell():
    import sys
    sys.stdout.reconfigure(line_buffering=True)
    print("EnKrypto CLI", flush=True)
    print("type 'help' for commands\n", flush=True)

    while True:
        try:
            print("enk> ", end="", flush=True)
            command = input().strip()

            if not command:
                continue

            parts = command.split()
            cmd = parts[0]

            if cmd == "connect":
                if len(parts) < 2:
                    print("usage: connect <file_path>")
                    continue
                handle_connect(parts[1])

            elif cmd == "status":
                if len(parts) < 2:
                    print("usage: status <file_path>")
                    continue
                handle_status(parts[1])

            elif cmd == "stop":
                if len(parts) < 2:
                    print("usage: stop <file_path>")
                    continue
                handle_stop(parts[1])

            elif cmd == "help":
                print("""
commands:
  connect <file>   start tracking
  status <file>    check status
  stop <file>      stop tracking (basic)
  help             show commands
  exit             quit CLI
""")

            elif cmd == "exit":
                print("bye")
                break

            else:
                print("unknown command")

        except KeyboardInterrupt:
            print("\n[!] interrupted")
        except Exception as e:
            print(f"error: {e}")


if __name__ == "__main__":
    shell()