from enkrypto_sdk.adapters.json_adapter import JSONAdapter
from enkrypto_sdk.adapters.csv_adapter import CSVAdapter
from enkrypto_sdk.adapters.excel_adapter import ExcelAdapter
from enkrypto_sdk.adapters.mongo_adapter import MongoAdapter
from enkrypto_sdk.adapters.sqlalchemy_adapter import SQLAlchemyAdapter

from enkrypto_sdk.watcher.dispatcher import Dispatcher
from enkrypto_sdk.transport.client import EnkryptoClient
from enkrypto_sdk.config.settings import ConfigValidator
import threading
import time

class EnkryptoSDK:
    def __init__(self, config):
        self.config = config
        self.adapter = None
        self.dispatcher = None

    def init(self):
        ConfigValidator.validate(self.config)
        db_type = self.config["type"]

        if db_type == "json":
            self.adapter = JSONAdapter(self.config)

        elif db_type == "csv":
            self.adapter = CSVAdapter(self.config)

        elif db_type == "excel":
            self.adapter = ExcelAdapter(self.config)

        elif db_type == "mongo":
            self.adapter = MongoAdapter(self.config)

        elif db_type == "sql":
            self.adapter = SQLAlchemyAdapter(self.config)

        else:
            raise ValueError("unsupported type")

        client = EnkryptoClient(
            endpoint=self.config["endpoint"],
            api_key=self.config["api_key"]
        )

        self.dispatcher = Dispatcher(client)

    def start(self):
        self.adapter.connect()

        thread = threading.Thread(
            target=self.adapter.watch,
            args=(self.dispatcher.handle_event,),
            daemon=True
        )

        thread.start()

        while True:
            time.sleep(1)