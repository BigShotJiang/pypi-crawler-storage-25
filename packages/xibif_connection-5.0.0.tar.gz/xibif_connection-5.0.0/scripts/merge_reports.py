import sys
import glob
from junitparser import JUnitXml

merged_xml = JUnitXml()
xml_files = glob.glob("reports/*.xml")

if not xml_files:
    print("No XML files found to merge.")
    sys.exit(1)

for file in xml_files:
    print(f"Merging: {file}")
    try:
        report = JUnitXml.fromfile(file)
        merged_xml += report
    except Exception as e:
        print(f"Error reading {file}: {e}")

merged_xml.write("test_report.xml")
print("Merged report saved as test_report.xml")
