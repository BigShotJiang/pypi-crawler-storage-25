#!/bin/sh

set -e

# Find latest common ancestor or the last SemVer Tag
if [ -n "$CI_MERGE_REQUEST_SOURCE_BRANCH_NAME" ]; then
  SOURCE_BRANCH="$CI_MERGE_REQUEST_SOURCE_BRANCH_NAME"
  TARGET_BRANCH="$CI_MERGE_REQUEST_TARGET_BRANCH_NAME"

  git fetch origin "$SOURCE_BRANCH" "$TARGET_BRANCH"
  BASE_REF=$(git merge-base "origin/$SOURCE_BRANCH" "origin/$TARGET_BRANCH")
  RANGE_END="HEAD"
  if [ -z "$BASE_REF" ]; then
    echo "Error: Could not determine the common ancestor between source and target branches."
    exit 1
  fi
else
  # CI clones can contain stale local tags; force-refresh remote tags to avoid fetch rejection.
  git fetch origin --tags --force
  SEMVER_TAGS=$(git tag -l "v[0-9]*.[0-9]*.[0-9]*" --sort=-v:refname)

  if [ -n "$CI_COMMIT_TAG" ]; then
    LATEST_TAG=$(echo "$SEMVER_TAGS" | sed -n '1p')
    PREVIOUS_TAG=$(echo "$SEMVER_TAGS" | sed -n '2p')

    if [ -z "$LATEST_TAG" ] || [ -z "$PREVIOUS_TAG" ]; then
      echo "Error: At least two SemVer tags are required for tag pipelines."
      exit 1
    fi

    echo "Using SemVer tag range: $PREVIOUS_TAG..$LATEST_TAG"
    BASE_REF="$PREVIOUS_TAG"
    RANGE_END="$LATEST_TAG"
  else
    LAST_TAG=$(echo "$SEMVER_TAGS" | sed -n '1p')

    if [ -z "$LAST_TAG" ]; then
      echo "Error: No previous SemVer tag found."
      exit 1
    fi

    echo "Using last SemVer tag: $LAST_TAG"
    BASE_REF="$LAST_TAG"
    RANGE_END="HEAD"
  fi
fi

# Check all commits from base to now for a valid commit message
echo "Checking commit messages from $BASE_REF to $RANGE_END..."
COMMITS=$(git log --format=%H "$BASE_REF..$RANGE_END")
PASSED=0
for COMMIT in $COMMITS; do
  COMMIT_MESSAGE=$(git log --format=%B -n 1 $COMMIT)

  echo "-- Checking $COMMIT"
  # Check title (first line, max 72 chars)
  TITLE=$(echo "$COMMIT_MESSAGE" | head -n1)
  if [ ${#TITLE} -gt 72 ]; then
    echo "---- ❌ has a title longer than 72 characters"
    continue;
  else
    echo "---- ✅ title is ok"
  fi

  # Ensure there's a description (empty line before)
  if ! echo "$COMMIT_MESSAGE" | grep -q "^$"; then
    echo "---- ❌ does not have a description after the title"
    continue;
  else
    echo "---- ✅ description is ok"
  fi

  # Check for non-changelog trailer
  if echo "$COMMIT_MESSAGE" | grep -Eq "^Changelog: (documentation|ci|other)$"; then
    echo "---- ⚠️ Trailer complies with format but is not added to changelog!"
  elif echo "$COMMIT_MESSAGE" | grep -Eq "^Changelog: (added|changed|fixed|deprecated|removed|security|performance)$"; then
    echo "---- ✅ trailer is ok"
  else
    echo "---- ❌ missing a valid trailer"
    continue;
  fi

  echo "-- ✅ $COMMIT follows the required format"
  # all checks passed
  PASSED=1
done

if [ "$PASSED" -eq 0 ]; then
  echo "❌ No commit in this range meets the required format."
  exit 1
fi

echo "✅ At least one commit in this range follows the required format."
