
################
XiBIF Connection
################

The XiBIF Connection package provides the API to connect to an FPGA using XiBIF. It includes a command line interface (CLI) for interactive use and a Python API for programmatic access.

.. toctree::
   :maxdepth: 1
   :caption: Connection and Session

   connection-session/connection-and-session
   connection-session/examples

.. toctree::
   :maxdepth: 1
   :caption: Shell

   shell/usage
   shell/reference

.. toctree::
   :maxdepth: 1
   :caption: Sourcecode

   code/api
   code/protocol
   code/transport
