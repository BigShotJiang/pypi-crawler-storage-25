Examples
========
 
This section provides runnable examples for using the XiBIF Connection package. These examples demonstrate how to use the core API and are intended to be executed in a Python environment with access to the XiBIF hardware.

All examples can be found in the `examples directory of the repository <https://gitlab.com/xibif/xibif-connection/-/tree/main/examples>`_.

.. include:: ../_generated/repo_examples.rst
