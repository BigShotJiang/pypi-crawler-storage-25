# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# Setup for autodoc
import ast
import os
import sys
import importlib.metadata as metadata
import inspect
from importlib import import_module
from datetime import date

sys.path.insert(0, os.path.abspath("../.."))


def _extract_command_description(command: str, doc: str) -> str:
    """Extract a short command description from a shell command docstring."""
    lines = [line.strip() for line in doc.splitlines() if line.strip()]
    for line in lines:
        lowered = line.lower()
        prefix = f"{command.lower()} - "
        if lowered.startswith(prefix):
            return line[len(prefix) :].strip().rstrip(".")

    # Fallback to first non-heading line
    skip_tokens = {"name", "synopsis", "options", "description", "examples", "see also"}
    for line in lines:
        if line.lower() in skip_tokens:
            continue
        return line.rstrip(".")
    return ""


def _parse_command_doc(doc: str) -> dict[str, list[str]]:
    """Parse command docstrings with NAME/SYNOPSIS/OPTIONS/... sections."""
    section_names = {
        "NAME",
        "SYNOPSIS",
        "OPTIONS",
        "DESCRIPTION",
        "EXAMPLES",
        "SEE ALSO",
    }
    sections: dict[str, list[str]] = {}
    current: str | None = None

    for raw_line in doc.splitlines():
        stripped = raw_line.strip()

        if stripped in section_names:
            current = stripped
            sections.setdefault(current, [])
            continue

        if current is None:
            continue

        sections[current].append(stripped)

    # Trim leading/trailing empty lines per section
    for key, values in sections.items():
        start = 0
        end = len(values)
        while start < end and values[start] == "":
            start += 1
        while end > start and values[end - 1] == "":
            end -= 1
        sections[key] = values[start:end]

    return sections


def _append_text_block(lines: list[str], values: list[str]) -> None:
    """Append a plain text block preserving paragraph breaks."""
    for value in values:
        if value == "":
            lines.append("")
        else:
            lines.append(value)


def _append_code_block(lines: list[str], values: list[str]) -> None:
    """Append a text code block for command snippets."""
    lines.append(".. code-block:: text")
    lines.append("")
    for value in values:
        lines.append(f"   {value}")
    lines.append("")


def _append_options_block(lines: list[str], values: list[str]) -> None:
    """Append OPTIONS entries using reStructuredText option-list syntax."""
    i = 0
    while i < len(values):
        option_line = values[i].strip()
        if option_line == "":
            i += 1
            continue

        # Treat lines starting with '-' as option headers, otherwise keep raw text.
        if option_line.startswith("-"):
            normalized_option = " ".join(option_line.replace(" ,", ",").split())
            lines.append(normalized_option)
            i += 1

            description_lines: list[str] = []
            while i < len(values):
                current = values[i].strip()
                if current.startswith("-"):
                    break
                if current != "":
                    description_lines.append(current)
                i += 1

            if description_lines:
                for desc in description_lines:
                    lines.append(f"   {desc}")
            else:
                lines.append("   ")
            lines.append("")
            continue

        lines.append(option_line)
        lines.append("")
        i += 1


def _render_command_reference(
    command_items: list[tuple[str, str, dict[str, list[str]]]],
) -> str:
    """Render detailed command reference in RST."""
    lines: list[str] = []

    for command, description, sections in command_items:
        lines.append(command)
        lines.append("~" * len(command))
        lines.append("")

        if description:
            lines.append(description)
            lines.append("")

        synopsis = sections.get("SYNOPSIS", [])
        if synopsis:
            lines.append("**Synopsis**")
            lines.append("")
            _append_code_block(lines, synopsis)

        options = sections.get("OPTIONS", [])
        if options:
            lines.append("**Options**")
            lines.append("")
            _append_options_block(lines, options)

        description_block = sections.get("DESCRIPTION", [])
        if description_block:
            lines.append("**Description**")
            lines.append("")
            _append_text_block(lines, description_block)
            lines.append("")

        examples = sections.get("EXAMPLES", [])
        if examples:
            lines.append("**Examples**")
            lines.append("")
            _append_code_block(lines, examples)

    if not lines:
        lines = ["No shell commands detected.", ""]

    return "\n".join(lines)


def _generate_shell_docs() -> None:
    """Generate RST snippets for shell docs directly from the CLI implementation."""
    source_dir = os.path.dirname(__file__)
    generated_dir = os.path.join(source_dir, "_generated")
    os.makedirs(generated_dir, exist_ok=True)

    commands_path = os.path.join(generated_dir, "shell_core_commands.rst")
    command_reference_path = os.path.join(generated_dir, "shell_command_reference.rst")

    try:
        cli = import_module("xibif_connection.cli")

        shell_cls = cli.XibifShell
        command_items: list[tuple[str, str, dict[str, list[str]]]] = []
        for name, func in shell_cls.__dict__.items():
            if not name.startswith("do_"):
                continue
            if not inspect.isfunction(func):
                continue

            command = name[3:]
            if command == "help":
                continue
            doc = inspect.getdoc(func) or ""
            sections = _parse_command_doc(doc)
            description = _extract_command_description(command, doc)
            if description:
                command_items.append((command, description, sections))
            else:
                command_items.append((command, "Shell command", sections))

        command_items.sort(key=lambda item: item[0])
        command_lines = [
            f"- ``{cmd}``: {' '.join(desc.split()).rstrip('.')}."
            for cmd, desc, _ in command_items
        ]
        if not command_lines:
            command_lines = ["- No shell commands detected."]

        command_reference_text = _render_command_reference(command_items)

    except Exception as exc:  # pragma: no cover - docs fallback
        command_lines = [f"- Failed to generate commands automatically: {exc}"]
        command_reference_text = (
            f"Failed to generate command reference automatically: {exc}\n"
        )

    with open(commands_path, "w", encoding="utf-8") as f:
        f.write("\n".join(command_lines) + "\n")

    with open(command_reference_path, "w", encoding="utf-8") as f:
        f.write(command_reference_text)


_generate_shell_docs()


def _generate_examples_docs() -> None:
    """Generate examples page fragments from files in the repository examples folder."""
    source_dir = os.path.dirname(__file__)
    repo_root = os.path.abspath(os.path.join(source_dir, "..", ".."))
    examples_dir = os.path.join(repo_root, "examples")
    generated_dir = os.path.join(source_dir, "_generated")
    os.makedirs(generated_dir, exist_ok=True)

    output_path = os.path.join(generated_dir, "repo_examples.rst")
    repo_base = "https://gitlab.com/xibif/xibif-connection/-/blob/main/examples"

    lines: list[str] = []

    try:
        for filename in sorted(os.listdir(examples_dir)):
            if not filename.endswith(".py"):
                continue

            absolute_path = os.path.join(examples_dir, filename)
            relative_include = f"../../../examples/{filename}"

            with open(absolute_path, "r", encoding="utf-8") as f:
                source = f.read()

            module = ast.parse(source)
            docstring = ast.get_docstring(module) or "No description available."

            lines.append(filename)
            lines.append("~" * len(filename))
            lines.append("")
            for paragraph in docstring.strip().split("\n\n"):
                for line in paragraph.splitlines():
                    lines.append(line.rstrip())
                lines.append("")

            lines.append(f"`View file in repository <{repo_base}/{filename}>`__")
            lines.append("")
            lines.append(f".. literalinclude:: {relative_include}")
            lines.append("   :language: python")
            lines.append("")

        if not lines:
            lines = ["No example files found.", ""]

    except Exception as exc:  # pragma: no cover - docs fallback
        lines = [f"Failed to generate examples documentation automatically: {exc}", ""]

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


_generate_examples_docs()

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

project = "XiBIF Connection"
copyright = str(date.today().year) + ", XiBIF. Licensed under the CERN-OHL-P v2.0"
author = metadata.metadata("xibif_connection")["Author-email"]
release = metadata.version("xibif_connection")
version = metadata.version("xibif_connection")

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = []

templates_path = ["_templates"]
exclude_patterns = []


# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output
# html_theme = 'sphinx_material'
html_theme = "sphinx_rtd_theme"
html_favicon = "img/xibif_logo.png"
# html_static_path = ['_static/css/']
# html_css_files = ["css/custom.css"]
# html_style = 'css/custom.css'
smart_quotes = True

extensions = [
    "sphinx_toolbox.collapse",
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.autosummary",
    "sphinxcontrib.mermaid",
    "sphinx_simplepdf",
    "sphinxcontrib.wavedrom",
    "sphinxarg.ext",
    "enum_tools.autoenum",
]

autodoc_mock_imports = ["numpy", "numpy.typing"]
add_module_names = False
render_using_wavedrompy = True
napoleon_use_rtype = False

html_theme_options = {
    # Visible levels of the global TOC; -1 means unlimited
    "globaltoc_collapse": True,
    "globaltoc_includehidden": False,
}

html_sidebars = {"**": ["globaltoc.html", "searchbox.html"]}
version_dropdown = True
simplepdf_vars = {
    "primary": "#8C1A5F",
    "primary-opaque": "rgba(140, 26, 95, 1)",
    "secondary": "#FFFF00",
    "cover": "#ffffff",
    "white": "#ffffff",
    #  'links': 'FA2323',
    #  'cover-bg': 'url(cover-bg.jpg) no-repeat center',
    "cover-overlay": "rgba(140, 26, 95, 0.6)",
    "top-left-content": "counter(page)",
    "bottom-center-content": '"XiBIF Connection Documentation"',
}
simplepdf_file_name = "XiBIF_Connection_Documentation.pdf"
