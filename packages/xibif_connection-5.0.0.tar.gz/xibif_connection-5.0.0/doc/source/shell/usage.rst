Usage
=====

The XiBIF Connection package provides an interactive shell through the
``xibif-connection`` command line entry point.

.. argparse::
   :module: xibif_connection.cli
   :func: build_arg_parser
   :prog: xibif-connection
   :nodescription:

Examples
~~~~~~~~

Start the shell without connecting:

.. code-block:: bash

   xibif-connection

Start the shell and connect immediately:

.. code-block:: bash

   xibif-connection --ip 192.168.1.10 --uuid 0xDEAD_CAFE --timeout 5

Available commands
------------------

The available commands of the shell are as follows:

.. include:: ../_generated/shell_core_commands.rst

Typical workflow
----------------

.. code-block:: text

   $ xibif-connection
   xibif> connect 192.168.1.10 0xDEAD_CAFE
   Connected to 192.168.1.10
   xibif> read my_register
   0x00000001
   xibif> write my_register.my_field 3
   xibif> quit
   Bye.

