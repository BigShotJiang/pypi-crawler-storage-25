Command Reference
-----------------

The following commands are available in the shell. For detailed usage of each command, use the ``help`` command within the shell or refer to the generated command reference below.

.. include:: ../_generated/shell_command_reference.rst