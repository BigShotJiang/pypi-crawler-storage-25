
Transport
=========

.. autoclass:: xibif_connection.transport.tcp.TcpTransport
    :members:
