API
===

.. autoclass:: xibif_connection.api.connection.XibifConnection
    :members:

.. autoclass:: xibif_connection.api.session.XibifSession
    :members:
