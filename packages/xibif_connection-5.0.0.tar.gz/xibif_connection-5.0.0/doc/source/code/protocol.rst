
Protocol
========

.. autoclass:: xibif_connection.protocol.coding.XibifProtocol
    :members:

.. autoenum:: xibif_connection.protocol.data.Command
    :members:

.. autoclass:: xibif_connection.protocol.data.Message
    :members:

.. autoclass:: xibif_connection.protocol.data.Response
    :members:

.. autoclass:: xibif_connection.protocol.data.XibifStatus
    :members:


Helper Types
============

.. autoenum:: xibif_connection.protocol.data.ResponseStatus
    :members:

.. autoenum:: xibif_connection.protocol.data.AxiAccessStatus
    :members:

.. autoclass:: xibif_connection.protocol.data.XibifVersion
    :members:

.. autoclass:: xibif_connection.protocol.data.XibifFifo
    :members:

.. autoclass:: xibif_connection.protocol.data.XibifUuid
    :members:
