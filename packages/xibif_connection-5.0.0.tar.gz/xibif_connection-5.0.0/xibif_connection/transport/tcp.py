"""TCP Transport Class for a XiBIF Board"""
from __future__ import annotations

import math
import os
import socket
import struct
import time

from ..exceptions import SocketClosedError, SocketConnectionError, SocketTimeoutError

SendableData = bytes | bytearray | memoryview


class TcpTransport:
    """
    Defines TCP Transport for a XiBIF Board.
    """
    ip: str | None = None
    port: int | None = None
    timeout: float = 5.0

    socket: socket.socket | None = None

    MAX_PACKET_SIZE_BYTES = 2**14

    def __init__(
        self,
        ip: str,
        port: int,
        timeout: float | None = 5.0,
    ) -> None:
        self.ip = ip
        self.port = port

        if timeout:
            self.timeout = timeout

    def open(self) -> None:
        """
        Open a connection to a XiBIF board

        A socket connection to will be opened to the configured IP and port.
        If a connection is already established, it will be closed.

        Raises
        ------
        SocketConnectionError:
            Connection could not be opened
        """
        if self.socket:
            self.close()
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # rx/tx blocking timeouts
            self.socket.setblocking(True)
            self.socket.settimeout(self.timeout)  # Set timeout for the connect call
            self.socket.setsockopt(
                socket.SOL_SOCKET,
                socket.SO_SNDTIMEO,
                self._socket_sec2opt(self.timeout),
            )
            self.socket.setsockopt(
                socket.SOL_SOCKET,
                socket.SO_RCVTIMEO,
                self._socket_sec2opt(self.timeout),
            )
            self.socket.setsockopt(
                socket.IPPROTO_TCP, socket.TCP_NODELAY, 1
            )  # Disable Nagle's algorithm for low latency
            self.socket.connect((self.ip, self.port))

        except OSError as exc:
            raise SocketConnectionError from exc

    def close(self) -> None:
        """
        Close the connection to a XiBIF board

        Raises
        ------
            SocketClosedError
                The connection does not exist. It cannot be closed.
        """
        if not self.socket:
            raise SocketClosedError()

        self.socket.close()
        self.socket = None

    def send(self, data: SendableData) -> None:
        """
        Send data over a TCP connection.

        Send the given data over the configured TCP connection if
        it exists.

        Parameters
        ----------
            data: SendableData
                Data to send

        Raises
        ------
            SocketClosedError:
                No connection exists, cannot send data.
        """
        if not self.socket:
            raise SocketClosedError

        self.socket.send(data)

    def receive(self, length: int) -> SendableData:
        """
        Receive a number of bytes over a TCP connection.

        Receives the specified number of bytes over the configured TCP
        connection if it exists. Upon successfully receiving the number of
        bytes specified, the data is returned.

        Parameters
        ----------
            length: int
                Number of bytes to read from a socket

        Returns
        -------
            data: SendableData
                Received data

        Raises
        ------
            SocketClosedError:
                No connection exists or the connection was unexpectedly closed during transmission.
            SocketTimeoutError:
                Timeout while reading the socket. Either the connection is unresponsive or tried to read more bytes than available.
        """
        if not self.socket:
            raise SocketClosedError()

        chunks = []
        read = 0
        start_time = time.time()

        while read < length:
            if time.time() - start_time > self.timeout:
                raise SocketTimeoutError

            chunkLength = length - read
            try:
                chunk = self.socket.recv(chunkLength)
            except OSError as e:
                raise SocketTimeoutError from e
            if chunk == b"":
                raise SocketClosedError
            chunks.append(chunk)
            read += len(chunk)

        return b"".join(chunks)

    def _socket_sec2opt(self, seconds: float = 0) -> int | bytes:
        """
        Convert seconds to the correct socket option format.

        On Windows:
            Returns integer milliseconds (int).

        On POSIX systems:
            Returns a packed struct timeval (bytes).
        """
        if seconds <= 0:
            raise ValueError("seconds must be positive")

        if os.name == "nt":
            return int(seconds * 1000)

        whole_seconds = int(math.floor(seconds))
        microseconds = int(math.floor((seconds % 1) * 1_000_000))
        return struct.pack("ll", whole_seconds, microseconds)

    @property
    def isConnected(self):
        """
        Defines whether the TcpTransport object is connected.

        Returns
        -------
            connected: boolean
                True if a connection exists, False otherwise
        """
        return self.socket is not None
