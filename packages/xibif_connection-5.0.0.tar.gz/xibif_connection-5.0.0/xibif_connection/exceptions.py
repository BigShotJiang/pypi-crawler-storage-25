"""
Custom exceptions for xibif-connection.
"""


class XibifError(Exception):
    """Base exception for all xibif-related errors."""


class XibifResponseError(XibifError):
    """Board response is invalid"""


# -------------------------
# Transport Errors
# -------------------------


class TransportError(XibifError):
    """Base class for transport-related errors."""


class SocketConnectionError(TransportError):
    """Raised when a socket connection cannot be established."""


class SocketTimeoutError(TransportError):
    """Raised when a socket send/receive operation times out."""


class SocketClosedError(TransportError):
    """Raised when the socket connection is unexpectedly closed."""


# -------------------------
# Protocol Errors
# -------------------------


class ProtocolError(XibifError):
    """Raised when encoding or decoding fails."""


# -------------------------
# AXI Errors
# -------------------------


class AxiError(XibifError):
    """Raised when an AXI access fails."""


# -------------------------
# Stream Errors
# -------------------------


class StreamError(XibifError):
    """Raised when stream operations fail."""


# -------------------------
# Device State Errors
# -------------------------


class DeviceNotOpenError(XibifError):
    """Raised when an operation is attempted on a closed device."""
