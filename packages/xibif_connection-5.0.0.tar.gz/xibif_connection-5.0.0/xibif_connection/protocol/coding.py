"""Definition of XiBIF protocol"""
from __future__ import annotations
from collections.abc import Iterable

import numpy as np
from numpy.typing import NDArray

from ..transport.tcp import SendableData
from .data import (
    Command,
    Message,
    Response,
    ResponseStatus,
    XibifRegisterAddress,
    XibifRegisterData,
)


class XibifProtocol:
    """
    Implements the protocol to communicate with a Xibif board.

    A message can be sent/received to/from a Xibif board only if the data
    between the board and the client is in accordance to a data format that
    the board recognizes.
    """

    _dtype = np.dtype("<u4")  # little endian uint32
    _header_size_bytes = 20
    _register_access_width = 32  # chunk size in which registers are accessed
    _register_width: int  # width of the registers to read/write

    def __init__(self, register_width: int) -> None:
        self._register_width = register_width

    @property
    def dtype(self) -> np.dtype:
        """
        Underlying datatype of the protocol
        """
        return self._dtype

    @property
    def header_size_bytes(self) -> int:
        """
        Size of a header received after sending a command in bytes.
        """
        return self._header_size_bytes

    @property
    def register_width(self) -> int:
        """
        Get the register width in bits.
        """
        return self._register_width

    @register_width.setter
    def register_width(self, value: int) -> None:
        """
        Set the register width in bits.
        """
        self._register_width = value

    def _num_unit_registers(self) -> int:
        """
        Number of unit registers for a given register width.

        Defines the number of unit register accesses that are associated
        with a configured register width of a project.
        If the configured register width is not native, multiple bus accesses
        might need to occur in the PS to fully read/write a single hardware
        register.
        """
        units = self._register_width // self._register_access_width
        if self._register_width % self._register_access_width != 0:
            units += 1

        return units

    def encode(self, msg: Message) -> SendableData:
        """
        Convert a Message to SendableData

        This implementation avoids Python-level payload expansion (the `*payload` pattern)
        by constructing header and payload numpy arrays and concatenating them. That
        prevents creating a large intermediate Python list/tuple for big payloads.
        """
        if msg.payload is None:
            payload_arr = np.array([], dtype=self._dtype)
        else:
            payload_arr = msg.payload

        header = np.array(
            [msg.id.value, msg.uuid, payload_arr.size * 4], dtype=self._dtype
        )

        if payload_arr.size == 0:
            arr = header
        else:
            arr = np.concatenate((header, payload_arr))

        # Return a memoryview over the numpy array buffer for sending
        return memoryview(arr)

    def get_command_from_header(self, data: np.ndarray) -> Command:
        """
        Extract the `Command` associated with a header.
        """
        if len(data) != self._header_size_bytes / 4:
            raise ValueError("Invalid header, cannot decode")
        return Command(data[0])

    def get_command_status_from_header(self, data: np.ndarray) -> ResponseStatus:
        """
        Read status from a header.

        The received header contains information on the status of the
        command associated with the header.
        """
        if len(data) != self._header_size_bytes / 4:
            raise ValueError("Invalid header, cannot decode")
        return ResponseStatus(data[1])

    def get_payload_length_from_header(self, data: np.ndarray) -> int:
        """
        Read payload length from header.
        """
        if len(data) != self._header_size_bytes / 4:
            raise ValueError("Invalid header, cannot decode")
        return data[2]

    def get_execution_time_from_header(self, data: np.ndarray) -> int:
        """
        ATTENTION: not pure execution time. Measures time from complete reception to instant of
        sending the response.
        """
        if len(data) != self._header_size_bytes / 4:
            raise ValueError("Invalid header, cannot decode")
        return (int(data[3]) << 32) + int(data[4])

    def decode(self, data: SendableData) -> NDArray[np.uint32]:
        """
        Decode data received from a XiBIF board.

        Decodes `SendableData` by ensuring that the data is four-byte aligned
        and then decoding it using the protocol-defined data-type.
        """
        pad = (-len(data)) % 4
        data_padded = b"\x00" * pad + data
        decoded = np.frombuffer(data_padded, dtype=self._dtype)
        return decoded

    def build_response(self, header: np.ndarray, payload: np.ndarray) -> Response:
        """
        Assemble a `Response` object from a received header and the payload.
        """
        cmd = self.get_command_from_header(header)
        status = self.get_command_status_from_header(header)
        cycles = self.get_execution_time_from_header(header)
        return Response(cmd, status, payload, cycles)

    def encode_register_address(self, addr: XibifRegisterAddress) -> NDArray[np.uint32]:
        """
        Encode a register address into a list of register addresses.

        Hardware access of addresses always occurs for 32 bits at time. If the register width
        is larger than 32, multiple accesses need to occur to read/write a single register.
        """
        if isinstance(addr, Iterable):
            result = []
            for a in addr:
                result.extend(self.encode_register_address(a))
            return np.array(result)

        n_units = self._num_unit_registers()
        return np.array([addr + i * 0x04 for i in range(n_units)], dtype=self._dtype)

    def encode_register_data(self, data: XibifRegisterData) -> NDArray[np.uint32]:
        """Split data into 32-bit chunks according to register width."""
        if isinstance(data, Iterable):
            result: list[int] = []
            for d in data:
                result.extend(self.encode_register_data(d))
            return np.array(result, dtype=self._dtype)

        num_units = self._num_unit_registers()
        chunks: list[int] = []
        for i in range(num_units):
            chunks.append((data >> (i * self._register_access_width)) & 0xFFFF_FFFF)
        return np.array(chunks, dtype=self._dtype)

    def decode_register_data(self, data: NDArray[np.uint32]) -> XibifRegisterData:
        """
        Decode received register data into values of individual registers
        """
        step = self._num_unit_registers()
        result: list[int] = []
        for i in range(0, len(data), step):
            val = 0
            for j in range(step):
                if i + j < len(data):
                    val |= int(data[i + j]) << (j * self._register_access_width)
            result.append(val)
        return result
