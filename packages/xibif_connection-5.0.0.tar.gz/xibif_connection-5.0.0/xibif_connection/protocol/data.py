"""Dataclasses for a XibifConnection"""
from __future__ import annotations
import datetime
from dataclasses import dataclass
from enum import Enum

import numpy as np
from numpy.typing import NDArray

XibifPayload = "NDArray[np.uint32] | None"
XibifRegisterAddress = "int | list[int] | NDArray[np.uint32]"
XibifRegisterData = "int | list[int] | NDArray[np.integer]"


class Command(Enum):
    """
    Commands that can be sent to a Xibif board.

    A Xibif board offers a set of commands that it can execute. This list must
    be in agreement with the commands implemented in the C-code running on the
    hardware.
    """

    STATUS = 0
    FLUSH_STREAM = 1
    READ_REGISTER = 2
    WRITE_REGISTER = 3
    READ_STREAM = 4
    READ_STREAM_ALL = 5
    WRITE_STREAM = 6
    WRITE_BITSTREAM = 7
    UART_PRINT_STATUS = 8
    UART_ENABLE_DBG_OUTPUT = 9
    RESET = 10
    AXI_READ = 11
    AXI_WRITE = 12
    READ_REGISTER_MAP = 13
    PERFORMANCE_TEST = 14

    def __str__(self) -> str:
        names = {
            Command.STATUS: "Status",
            Command.FLUSH_STREAM: "Flush Stream",
            Command.READ_REGISTER: "Read Register",
            Command.WRITE_REGISTER: "Write Register",
            Command.READ_STREAM: "Read Stream",
            Command.READ_STREAM_ALL: "Read Stream All",
            Command.WRITE_STREAM: "Write Stream",
            Command.WRITE_BITSTREAM: "Write Bitstream",
            Command.UART_PRINT_STATUS: "UART Print Status",
            Command.UART_ENABLE_DBG_OUTPUT: "UART Enable Debug Output",
            Command.RESET: "Software Reset",
            Command.AXI_READ: "AXI Read",
            Command.AXI_WRITE: "AXI Write",
            Command.READ_REGISTER_MAP: "Read Register Map",
            Command.PERFORMANCE_TEST: "Performance Test",
        }
        return names.get(self, super().__str__())


class ResponseStatus(Enum):
    """
    Response information for a sent command.

    Values
    ------
    - OK: Command executed successfully.
    - UNAUTHORIZED: Command execution not authorized.
    - COMMAND_NOT_IMPLEMENTED: Command is not implemented.
    - FAILED: Command execution failed due to an error.
    - INVALID_LENGTH: Command execution failed due to invalid payload length.
    """

    OK = 0
    UNAUTHORIZED = 1
    COMMAND_NOT_IMPLEMENTED = 2
    FAILED = 3
    INVALID_LENGTH = 4

    def __str__(self) -> str:
        if self == ResponseStatus.OK:
            return "Ok"
        elif self == ResponseStatus.UNAUTHORIZED:
            return "Unauthorized Access"
        elif self == ResponseStatus.COMMAND_NOT_IMPLEMENTED:
            return "Command not implemented"
        elif self == ResponseStatus.INVALID_LENGTH:
            return "Invalid payload length"
        elif self == ResponseStatus.FAILED:
            return "Command failed"

        return super().__str__()


class AxiAccessStatus(Enum):
    """
    AXI status codes after executing a direct AXI-access

    Values
    ------
    - AXI_ACCESS_OK: Access was successful.
    - AXI_ACCESS_NOT_ALLOWED_RANGE: The address is not within the allowed range. It must be in the range of 0x40000000 to 0x4FFFFFFF for Zynq-7000 platforms or 0xA0000000 to 0xAFFFFFFF for ZynqMP platforms.
    - AXI_ACCESS_NOT_ALLOWED_XIBIF_RANGE: The address is within the XiBIF reserved range and cannot be accessed.
    - AXI_FIREWALL_ERROR: The AXI Firewall detected an error.
    - AXI_FIREWALL_DATA_DEC0DEE3_DEADFA11: The AXI Firewall returned a specific error code indicating a data issue. If you expect to read the value 0xDEADC0DE or 0xDEADFA11 you can disable this error by setting the property disable_axi_check_DEC0DEE3_DEADFA11 to True.
    - AXI_ACCESS_ADDRESS_NOT_ALIGNED: The address is not aligned to 32-bit values. The address must be a multiple of 4.
    """

    AXI_ACCESS_OK = 0
    AXI_ACCESS_NOT_ALLOWED_RANGE = 1
    AXI_ACCESS_NOT_ALLOWED_XIBIF_RANGE = 2
    AXI_FIREWALL_ERROR = 3
    AXI_FIREWALL_DATA_DEC0DEE3_DEADFA11 = 4
    AXI_ACCESS_ADDRESS_NOT_ALIGNED = 5


@dataclass
class Message:
    """
    A message that can be sent to a XiBIF board.

    The message consists of a UUID for authentication, a `COMMAND` to specify which
    function to execute and a `XibifPayload` which contains the data required to execute
    the specified command.
    """

    uuid: int
    id: Command = Command.STATUS
    payload: XibifPayload = None

    def __str__(self) -> str:
        return f"Message: Command={self.id}, UUID={self.uuid}, Payload={self.payload}"


@dataclass
class Response:
    """
    A response from a XiBIF board.

    The response consists of a UUID, a `COMMAND` indicating which command execution
    the response belongs to, a `ResponseStatus` signaling the status of the execution
    and an optional payload for commands that require data being returned.
    """

    id: Command = Command.STATUS
    status: ResponseStatus = ResponseStatus.OK
    payload: NDArray[np.uint32] | None = None
    cycles: int = -1

    def __str__(self) -> str:
        return f"Response: Status={self.status}, Command={self.id}, Payload={self.payload}, Cycles={self.cycles}"


@dataclass
class XibifVersion:
    """
    Encapsulates the version data from a XiBIF board and implements representation methods.
    """

    major: int
    minor: int
    patch: int
    rev: int

    def __init__(self, value: int):
        self.major = int((value & 0xFF000000) >> 24)
        self.minor = int((value & 0x00FF0000) >> 16)
        self.patch = int((value & 0x0000FF00) >> 8)
        self.rev = int((value & 0x000000FF) >> 0)

    def __str__(self) -> str:
        return f"v{self.major}.{self.minor}.{self.patch}-{self.rev}"

    def __format__(self, format_spec):
        return format(str(self), format_spec)


@dataclass
class XibifFifo:
    """
    Represents the status of a XiBIF stream FIFO and implements representation methods.
    """

    fill: int
    depth: int
    enabled: bool
    axiError: bool
    ddrFull: bool

    def __str__(self) -> str:
        if not self.enabled:
            return "Disabled"

        return f"Fill={self.fill}, Depth={self.depth}{', AXI Error Occurred!' if self.axiError else ''}{', DDR is full!' if self.ddrFull else ''}"


@dataclass
class XibifUuid:
    """
    Unique Identification number of a XiBIF Board.

    This dataclass exists to provide proper representations of UUIDs for status printing.
    """
    uuid: int

    def __init__(self, value):
        self.uuid = int(value)

    def __str__(self) -> str:
        s = "-".join(f"{b:02X}" for b in self.uuid.to_bytes(4, "big"))
        return s

    def __format__(self, format_spec):
        return format(str(self), format_spec)


@dataclass
class XibifStatus:
    """
    Encapsulates the data returned by a XiBIF board when queried for the status of the board.
    Implements constructor methods from a payload and representation methods for printing.
    """

    registerVersion: XibifVersion  # Version stored in user register block
    streamVersion: XibifVersion
    softwareVersion: XibifVersion

    hardwareTimestamp: int
    softwareTimestamp: int

    registerUuid: XibifUuid
    streamUuid: XibifUuid

    registerWidth: int
    streamWidth: int

    pc2plFifo: XibifFifo
    pl2pcFifo: XibifFifo
    bistreamAvailable: bool

    nb_frequency: int

    def __init__(self, status: list[int] | NDArray[np.uint32]):
        if len(status) != 19:
            raise ValueError(
                f"cannot decode status from array with length {len(status)}"
            )

        self.registerVersion = XibifVersion(status[0])
        self.streamVersion = XibifVersion(status[1])
        self.softwareVersion = XibifVersion(status[2])

        self.hardwareTimestamp = self._timestamp_to_epoch(status[3])
        self.softwareTimestamp = self._timestamp_to_epoch(status[4])

        self.registerUuid = XibifUuid(status[5])
        self.streamUuid = XibifUuid(status[6])

        self.registerWidth = status[7]
        self.streamWidth = status[8]

        self.bistreamAvailable = status[9] > 0

        self.pl2pcFifo = XibifFifo(
            fill=(status[12]),
            depth=(status[11]),
            enabled=(status[10] == 1),
            axiError=False,
            ddrFull=False,
        )
        self.pc2plFifo = XibifFifo(
            fill=(status[16]),
            depth=(status[15]),
            enabled=(status[14] == 1),
            axiError=False,
            ddrFull=False,
        )

        self.nb_frequency = status[18]

    def _timestamp_to_epoch(self, value: int, base_year: int = 2000) -> int:
        """
        Convert a timestamp sent from a board to an epoch
        """
        day = (value >> 27) & 0x1F
        month = (value >> 23) & 0x0F
        year = (value >> 17) & 0x3F
        hour = (value >> 12) & 0x1F
        minute = (value >> 6) & 0x3F
        sec = value & 0x3F

        year += base_year
        dt = datetime.datetime(
            year, month, day, hour, minute, sec
        )
        dt = dt.astimezone(datetime.timezone.utc)
        return int(dt.timestamp())

    def _time_diff_pretty(self, epoch: int) -> str:
        """
        Return a human-readable difference between the given epoch and now.
        """
        now = datetime.datetime.now(datetime.timezone.utc).timestamp()
        delta = int(now - epoch)

        if delta < 0:
            return "in the future"

        if delta < 60:
            return f"{delta} second{'s' if delta > 1 else ''} ago"
        elif delta < 3600:
            minutes = round(delta / 60)
            return f"{minutes} minute{'s' if minutes > 1 else ''} ago"
        elif delta < 86400:
            hours = round(delta / 3600)
            return f"{hours} hour{'s' if hours > 1 else ''} ago"
        else:
            days = round(delta / 86400)
            return f"{days} day{'s' if days > 1 else ''} ago"

    def __str__(self) -> str:
        hw_build_time = datetime.datetime.fromtimestamp(self.hardwareTimestamp)
        sw_build_time = datetime.datetime.fromtimestamp(self.softwareTimestamp)
        time_format = "%Y-%m-%d %H:%M:%S"
        return f"""
--------------------------------------------------------------
XiBIF Status
--------------------------------------------------------------
UUIDs{" NO MATCH!" if self.registerUuid != self.streamUuid else ""}:
    Register: {str(self.registerUuid):>5}
    Stream:   {str(self.streamUuid):>5}

Build Time:
    Hardware: {hw_build_time.strftime(time_format)} ({self._time_diff_pretty(self.hardwareTimestamp)})
    Software: {sw_build_time.strftime(time_format)} ({self._time_diff_pretty(self.softwareTimestamp)})

Version Information:
    Register: {str(self.registerVersion):>10}
    Stream:   {str(self.streamVersion):>10}
    Software: {str(self.softwareVersion):>10}

Registers:
    Width: {self.registerWidth}bits

Streaming FIFOS:
    PC -> PL: {self.pc2plFifo}
    PL -> PC: {self.pl2pcFifo}

Bitstream:
    {"Available" if self.bistreamAvailable else "Not Available"}
--------------------------------------------------------------
"""
