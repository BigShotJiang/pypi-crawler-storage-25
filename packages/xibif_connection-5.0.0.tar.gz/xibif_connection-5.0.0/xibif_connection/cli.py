"""CLI for an interactive connection with a XiBIF board"""

from __future__ import annotations

import argparse
import cmd
import inspect
import os
import shlex
import subprocess
import sys
import threading
import time
from typing import Any

from numpy import mean

from xibif_connection.register_map import Field

# Prefer absolute imports; when running from the source tree the local imports
# inside the except block will be used.
try:
    from xibif_connection.api import XibifSession
    from xibif_connection.exceptions import XibifError
    from xibif_connection.register_map import RegisterMap
except ImportError:  # pragma: no cover - fallback for development environment
    from ..exceptions import XibifError  # type: ignore
    from .api import XibifSession  # type: ignore
    from .register_map import RegisterMap  # type: ignore

try:
    import readline
except ImportError:
    readline = None

if readline is not None:
    readline.parse_and_bind("tab: complete")


class WatchTask:
    """
    Background thread that polls a value and executes a callback upon a value change.
    """

    def __init__(self, name, func, interval=1.0, callback=None):
        """
        Initialize a WatchTask
        """
        self.name = name
        self.func = func
        self.interval = interval
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.callback = callback

    def run(self):
        """
        Task to run in the background.

        The function with which the WatchTask was initialized is periodically evaluated.
        Upon change of the return value of that function, a given callback is executed.
        """
        last_value = None
        while not self.stop_event.is_set():
            value = self.func()
            if last_value is not None and value != last_value:
                if self.callback:
                    self.callback(self.name, last_value, value)
            last_value = value
            time.sleep(self.interval)

    def start(self):
        """
        Start the WatchTask

        Starts the thread that periodically executes the WatchTask function.
        """
        self.thread.start()

    def stop(self):
        """
        Stop the WatchTask
        """
        self.stop_event.set()
        self.thread.join()


def parse_int(val: str) -> int:
    """Parse integer string supporting decimal and hex (0x...)."""
    s = val.strip().lower()
    if s.startswith("0x"):
        return int(s, 16)
    return int(s, 0)


class XibifShell(cmd.Cmd):
    """Interactive shell that uses XibifSession and RegisterMap."""

    intro = "XiBIF interactive shell. Type 'help' or '?' for commands."
    prompt = "xibif> "

    def __init__(self) -> None:
        super().__init__()
        self.session: XibifSession | None = None
        self.connected: bool = False
        self.regmap: RegisterMap | None = None
        self.watch_tasks: list[WatchTask] = []

    # --------------------
    # Helpers
    # --------------------
    @staticmethod
    def _looks_numeric(token: str) -> bool:
        try:
            parse_int(token)
            return True
        except ValueError:
            return False

    def _attempt_auto_load_map(self) -> None:
        """Attempt to read the registermap from the board and populate cached values."""
        if not (self.session and self.connected):
            return
        try:
            reg_map = RegisterMap.from_json_map(self.session.read_registermap())
        except (XibifError, ValueError, TypeError):
            return
        self.regmap = reg_map

    def _render_help(self, func):
        doc = inspect.getdoc(func)
        print(doc)

    def _read_register(self, reg: str | int) -> int:
        if self.session is None:
            raise RuntimeError("cannot read without a session")

        address: int | None = None
        _regname: str | None = None
        field: Field | None = None
        if isinstance(reg, int):
            address = reg
        elif isinstance(reg, str):
            if not self.regmap:
                raise RuntimeError(
                    "Register map not loaded. Use 'load_map' or connect to a board that provides it."
                )

            try:
                _regname, address, field = self.regmap.resolve(reg)
            except ValueError as e:
                raise RuntimeError(f"Resolve failed: {e}") from e

        if address is None:
            raise RuntimeError("cannot read without address")
        try:
            value = self.session.read(address)
        except XibifError as e:
            raise RuntimeError(f"Failed to read register at address {address}") from e

        if not isinstance(value, int):
            raise RuntimeError("must read one single value from register")

        if field is not None:
            return field.extract(value)
        return value

    def _load_regmap(self) -> None:
        if not (self.session and self.connected):
            print("Not connected.")
            return
        try:
            jm = self.session.read_registermap()
        except XibifError as e:
            print(f"Failed to read register map: {e}")
            return
        try:
            rm = RegisterMap.from_json_map(jm)
        except ValueError as e:
            print(f"Failed to parse register map: {e}")
            return
        self.regmap = rm
        print(f"Loaded register map with {len(self.regmap.registers())} registers")

    def _print_regmap(self) -> None:
        if not self.regmap:
            print("No register map loaded.")
            return
        regs = sorted(self.regmap.registers(), key=lambda r: r.address)
        for r in regs:
            print(f"{r.name}@0x{r.address:02X}")
            for fld in sorted(r.fields.values(), key=lambda f: f.lsb, reverse=True):
                print(f"  [{fld.msb:2}:{fld.lsb:2}] {fld.name:12}")

    def _print_reg_val(self, value: int, output_format: str = "hex") -> None:
        if output_format == "hex":
            print(f"0x{value:08X}")
        elif output_format == "bin":
            print(f"0b{value:>032b}")
        elif output_format == "dec":
            print(value)

    # --------------------
    # Connection commands
    # --------------------
    def do_connect(self, arg: str) -> None:
        """
        NAME
            connect - Connect to a XiBIF board.

        SYNOPSIS
            connect IP UUID [OPTIONS]

        OPTIONS
            -t, --timeout <seconds>
                Set the socket timeout in seconds
            -v, --verbose
                Connect in verbose mode

        DESCRIPTION
            connect establishes a connection to a XiBIF board at a given IP
            address that uses the given UUID. The UUID is bound to a XiBIF
            project and prevents accidental interference with another board
            on the same network. The UUID is not a security feature!

        EXAMPLES
            connect 192.168.1.10 0xDEADCAFE
            connect 192.168.1.10 0xDEADCAFE --timeout 10 --verbose

        SEE ALSO
            XibifConnection.connect(1)
        """
        parts = shlex.split(arg)
        if len(parts) < 2:
            print("Usage: connect <ip> <uuid> [--timeout N] [--verbose]")
            return
        ip = parts[0]
        try:
            uuid = parse_int(parts[1])
        except ValueError:
            print("Invalid uuid. Must be integer or 0x... hex.")
            return

        timeout: float | None = None
        verbose = False
        i = 2
        while i < len(parts):
            p = parts[i]
            if p in ("--timeout", "-t") and i + 1 < len(parts):
                try:
                    timeout = float(parts[i + 1])
                except ValueError:
                    print("Invalid timeout value.")
                    return
                i += 2
            elif p in ("-v", "--verbose"):
                verbose = True
                i += 1
            else:
                print(f"Ignoring unknown option: {p}")
                i += 1

        kwargs: dict[str, Any] = {}
        if timeout is not None:
            kwargs["timeout"] = timeout
        if verbose:
            kwargs["verbose"] = verbose

        self.session = XibifSession(ip, uuid, **kwargs)
        try:
            self.session.connect()
            self.connected = True
            print(f"Connected to {ip}")
            self._attempt_auto_load_map()
        except XibifError as e:
            self.connected = False
            print(f"Failed to connect: {e}")

    def do_disconnect(self, _arg: str) -> None:
        """
        NAME
            disconnect - Disconnect from a XiBIF board.

        SYNOPSIS
            disconnect

        DESCRIPTION
            disconnect disconnects from an active connection to a
            XiBIF board if it exists.

        EXAMPLES
            disconnect

        SEE ALSO
            XibifConnection.close(1)
        """
        if self.session and self.connected:
            try:
                self.session.disconnect()
            except XibifError as e:
                print(f"Error while disconnecting: {e}")
            finally:
                self.session = None
                self.connected = False
                self.regmap = None
                print("Disconnected.")
        else:
            print("No active session.")

    def do_status(self, _arg: str) -> None:
        """
        NAME
            status - Read and print board status.

        SYNOPSIS
            status

        DESCRIPTION
            status reads status information from a XiBIF board
            and prints the status to stdout of the active console.

        EXAMPLES
            status
        """
        if not (self.session and self.connected):
            print("Not connected.")
            return
        try:
            status = self.session.read_board_status()
            print(status)
        except XibifError as e:
            print(f"Failed to read status: {e}")

    def do_ping(self, arg: str) -> None:
        """
        NAME
            ping - Ping a XiBIF board.

        SYNOPSIS
            ping OPTIONS

        OPTIONS
            -c, --count <count>
                The number of times to repeat the ping test. Defaults to 3
            -i, --interval <interval>
                Time to wait between sending pings to the XiBIF board. Defaults to 1s.

        DESCRIPTION
            ping tests the connection between the host and a XiBIF board and prints
            the round-trip-time of the ping to the console.
            The number of times to repeat the ping test and the interval in between
            pings can be specified using the appropriate options. When pinging more than
            once, the minimum, maximum and average RTT per ping are reported.

        EXAMPLES
            ping
            ping --count 10 --interval 0.5

        SEE ALSO
            XibifConnection.ping(1)
        """
        parts = shlex.split(arg)
        i = 0
        count = 3
        interval = 1
        while i < len(parts):
            p = parts[i]
            if p in ("-c", "--count") and i + 1 < len(parts):
                try:
                    count = int(parts[i + 1])
                except ValueError:
                    print("Invalid count value.")
                    return
                i += 2
            elif p in ("-i", "--interval") and i + 1 < len(parts):
                try:
                    interval = float(parts[i + 1])
                except ValueError:
                    print("Invalid interval value.")
                    return
                i += 2
            else:
                print(f"Ignoring unknown option: {p}")
                i += 1
        if not (self.session and self.connected):
            print("Not connected.")
            return
        print(f"Executing ping for {self.session.ip}")
        try:
            times = []
            for i in range(count):
                rtt = self.session.ping()
                times.append(rtt * 1e3)
                print(f"Response from {self.session.ip}, Time={(rtt * 1e3):2f}ms")
                if count > 1 and (i + 1 < count):
                    time.sleep(interval)

            if count > 1:
                print(
                    f"Min {min(times):3f}ms, Max {max(times):3f}ms, Avg {mean(times):3f}ms"
                )
        except XibifError as e:
            print(f"Ping failed: {e}")

    def do_read(self, arg: str) -> None:
        """
        NAME
            read - Read one or multiple values from a hardware register.
        SYNOPSIS
            read ADDRESS [COUNT]
            read REGNAME [COUNT]
            read REGNAME.FIELDNAME
            read FIELDNAME

        DESCRIPTION
            read reads one or multiple values from a hardware register
            on a XiBIF board or a field of such a register.
            The first argument identifies the register/field to read. If
            operating on a whole register, the second argument identifies
            how many following registers should be read.
            A register may be identified by its address or its name. A field
            can only be identified by its name. When only a field name is provided
            the name must be unique for the whole register map.

        EXAMPLES
            read 0
            read register
            read 0 4
            read register 4
            read register.field

        SEE ALSO
            XibifConnection.read(1)
        """
        if not (self.session and self.connected):
            print("Not connected.")
            return

        parts = shlex.split(arg)
        if not parts:
            print("Usage: read <address|name> [count] [--format <dec|hex|bin>]")
            return

        target = parts[0]
        count = 1
        i = 1
        if len(parts) >= 2:
            if not parts[1].startswith("-"):
                try:
                    count = int(parts[1])
                    i += 1
                except ValueError:
                    print("Invalid count.")
                    return
                if count < 1:
                    print("Count must be >= 1")
                    return

        output_format: str = "hex"
        while i < len(parts):
            p = parts[i]
            if p in ("-f", "--format") and i + 1 < len(parts):
                output_format = parts[i + 1]
                i += 1
            else:
                print(f"Ignoring unknown option: {p}")
            i += 1

        # numeric address
        if self._looks_numeric(target):
            try:
                addr = parse_int(target)
            except ValueError:
                print("Invalid address.")
                return

            addresses = [addr + 4 * i for i in range(count)] if count > 1 else [addr]
            try:
                vals = []
                for a in addresses:
                    vals.append(self._read_register(a))
            except XibifError as e:
                print(f"Read failed: {e}")
                return

            # Normalize and print
            if isinstance(vals, int):
                vals = [vals]

            for v in list(vals):
                try:
                    iv = int(v)
                    self._print_reg_val(iv, output_format)
                except (TypeError, ValueError):
                    self._print_reg_val(v, output_format)
            return

        try:
            reg_val = self._read_register(target)
            self._print_reg_val(reg_val, output_format)
        except (RuntimeError, XibifError, ValueError, TypeError) as e:
            print(f"Failed to read register {target} - {e}")
            return

        try:
            if isinstance(reg_val, (list, tuple)):
                # session returned multiple values unexpectedly; take the first
                reg_val = int(reg_val[0])
            else:
                reg_val = int(reg_val)
        except (IndexError, TypeError, ValueError):
            print(f"Unexpected register read value: {reg_val}")
            return

    def do_write(self, arg: str) -> None:
        """
        NAME
            write - Write values to a hardware register.

        SYNOPSIS
            write ADDRESS VALUE
            write REGNAME VALUE
            write REGNAME.FIELDNAME VALUE
            write FIELDNAME VALUE

        DESCRIPTION
            write writes a value to a hardware register on a XiBIF board
            The first argument of the command identifies the register to write,
            the second argument specifies the value to write.
            The first argument can either be a register address or the
            name of a register/register field. If only a field name is
            provided, it must be unique in the register map.

        EXAMPLES
            write 0 12
            write register 12
            write register.field 12
            write field 12

        SEE ALSO
            XibifConnection.write(1)
        """
        if not (self.session and self.connected):
            print("Not connected.")
            return

        parts = shlex.split(arg)
        if len(parts) < 2:
            print("Usage: write <address|name> <value>")
            return

        target = parts[0]
        try:
            value = parse_int(parts[1])
        except ValueError:
            print("Invalid value.")
            return

        # write directly if an address is provided
        addr: int | None = None
        if self._looks_numeric(target):
            try:
                addr = parse_int(target)
                self.session.write(addr, value)
                return
            except (ValueError, XibifError):
                print("Invalid address.")
                return

        # if no address is provided, the register map is required
        # to resolve a name to an address
        if self.regmap is None:
            print(
                "Register map not loaded. Use 'load_map' first or provide numeric address."
            )
            return

        try:
            reg_name, addr, field = self.regmap.resolve(target)
        except ValueError as e:
            print(f"Resolve failed: {e}")
            return

        # read-modify-write
        try:
            current_val = self.session.read(addr)
            if not isinstance(current_val, int):
                return
            current_val = int(current_val)
        except XibifError:
            return

        # compose new full register value
        try:
            if field is None:
                # full-register write
                new_val = self.regmap.compose_register_write(
                    reg_name, None, value, None
                )
            else:
                new_val = self.regmap.compose_register_write(
                    reg_name, field.name, value, current_val
                )
        except (TypeError, ValueError) as e:
            print(f"Compose failed: {e}")
            return

        try:
            self.session.write(addr, new_val)
        except XibifError as e:
            print(f"Write failed: {e}")

    def do_regmap(self, arg: str) -> None:
        """
        NAME
            regmap - Operate on the register map of a XiBIF board.

        SYNOPSIS
            regmap [OPTIONS]

        OPTIONS
            -p, --print
                Print the register map to stdout
            -f , --force
                Force load the register map when one is already loaded

        DESCRIPTION
            regmap loads a register map from a XiBIF board if none is loaded
            already. The register map can be reloaded forcefully by specifying
            the appropriate flag.

        EXAMPLES
            regmap
            regmap --force
            regmap --print

        SEE ALSO
            XibifConnection.read_registermap(1)
        """
        if self.regmap is None:
            self._load_regmap()

        parts = shlex.split(arg)
        i = 0
        while i < len(parts):
            p = parts[i]
            if p in ("-f", "--force"):
                self._load_regmap()
            elif p in ("-p", "--print"):
                self._print_regmap()
            else:
                print(f"Ignoring unknown option: {p}")
            i += 1

    def do_watch(self, arg):
        """
        NAME
            watch - Observe a register.

        SYNOPSIS
            watch REGNAME [INTERVAL]
            watch REGNAME.FIELDNAME [INTERVAL]
            watch FIELDNAME [INTERVAL]

        DESCRIPTION
            watch periodically reads a register to print a notification
            as soon as the specified register/field value changes.
            The register read task is added as a background thread and triggers
            at the specified interval.

            All background threads are terminated when the connection is closed.

        EXAMPLES
            watch register
            watch register 0.1
            watch register.field
            watch field 0.1

        SEE ALSO
            unwatch(1)
        """
        parts = arg.split()
        if len(parts) < 1:
            print("Usage: watch <name> [interval]")
            return

        name = parts[0]
        interval = float(parts[1]) if len(parts) > 1 else 1.0

        def on_change(name, old, new):
            shell = self
            shell.stdout.write(f"\n[WATCH:{name}] {old}->{new}\n")
            shell.stdout.write(shell.prompt)
            shell.stdout.flush()

        task = WatchTask(
            name=name,
            interval=interval,
            func=lambda: self._read_register(name),
            callback=on_change,
        )

        task.start()
        self.watch_tasks.append(task)

        print(f"Started watch '{name}'")

    def do_unwatch(self, arg):
        """
        NAME
            unwatch - Stop watching a register.

        SYNOPSIS
            unwatch REGNAME
            unwatch REGNAME.FIELDNAME
            unwatch FIELDNAME

        DESCRIPTION
            unwatch stops observing a register that is currently being
            observed by terminating the background thread periodically
            reading the observed registers.

        EXAMPLES
            unwatch register
            unwatch register.field
            unwatch field

        SEE ALSO
            watch(1)
        """

        parts = shlex.split(arg)
        i = 0
        names: list[str] = []
        while i < len(parts):
            p = parts[i]
            names.append(p)
            i += 1

        for task in list(self.watch_tasks):
            if task.name in names:
                task.stop()
                self.watch_tasks.remove(task)
                print(f"Stopped watch '{task.name}'")

    # --------------------
    # Misc
    # --------------------
    def do_clear(self, _arg: str) -> None:
        """
        NAME
            clear - Clear the terminal screen.

        SYNOPSIS
            clear

        DESCRIPTION
            The current terminal screen is cleared using the host's operating
            system's respective clear command. For Linux, 'clear' is used while
            for NT-based operating systems 'cls' is used.
            On Linux-based systems, the terminal is cleared using direct control
            commands.
            If the clearing process fails on either OS, the clear function inserts
            newline statements to give the appearance of a cleared screen.

        EXAMPLES
            clear
        """
        try:
            if os.name == "nt":
                subprocess.Popen("cls")
            else:
                if subprocess.Popen("clear") != 0:
                    sys.stdout.write("\x1b[2J\x1b[H")
                    sys.stdout.flush()
        except OSError:
            print("\n" * 120)

    def do_reset(self, _arg: str) -> None:
        """
        NAME
            reset - Reset the PL system of the XiBIF board.

        SYNOPSIS
            reset

        DESCRIPTION
            reset performs a reset operation on the programmable
            logic part of a connected XiBIF board.

        EXAMPLES
            reset
        """
        if not (self.session and self.connected):
            print("Not connected.")
            return

        try:
            self.session.reset()
        except XibifError:
            print("error during reset")

    def do_quit(self, _arg: str) -> bool:
        """
        NAME
            quit - Quit the shell.

        SYNOPSIS
            quit

        DESCRIPTION
            quit closes any existing connection to a XiBIF board and
            terminates the active shell.
        """
        for task in self.watch_tasks:
            task.stop()
        if self.session and self.connected:
            try:
                self.session.disconnect()
            except XibifError:
                pass
        print("Bye.")
        return True

    def do_exit(self, arg: str) -> bool:
        """
        NAME
            exit - Quit the shell.

        SYNOPSIS
            exit

        DESCRIPTION
            exit is an alias for quit

        SEE ALSO
            quit(1)
        """
        return self.do_quit(arg)

    def emptyline(self) -> bool:
        """Do nothing on empty input (instead of repeating last command)."""
        return False

    def complete_read(
        self, text: str, line: str, _begidx: int, _endidx: int
    ) -> list[str]:
        """
        Autocomplete for read command.
        """
        try:
            after_cmd = line.split(None, 1)[1]
        except IndexError:
            after_cmd = ""

        token = text or ""
        if not self.regmap:
            return []

        completions: list[str] = []

        # if there is a dot, suggest fields
        if "." in after_cmd:
            reg_part, _, field_part = after_cmd.rpartition(".")
            reg_part = reg_part.strip()
            field_fragment = field_part if (line.endswith(".") or token) else token

            # resolve register and list fields
            try:
                reg_name, _, _ = self.regmap.resolve(reg_part)
                reg_obj = next(r for r in self.regmap.registers() if r.name == reg_name)
                for f in reg_obj.fields.values():
                    if f.name.lower().startswith(field_fragment.lower()):
                        completions.append(f"{reg_name}.{f.name}")
            except (ValueError, StopIteration):
                # unknown register
                return []
            return completions

        # suggest registers
        for r in self.regmap.registers():
            if r.name.lower().startswith(token.lower()):
                completions.append(r.name)

        # globally unique fields
        field_hits = {}
        for r in self.regmap.registers():
            for f in r.fields.values():
                key = f.name.lower()
                field_hits.setdefault(key, []).append(r.name)
        for fname, regs in field_hits.items():
            if fname.startswith(token.lower()) and len(regs) == 1:
                reg_name = regs[0]
                reg_obj = next(r for r in self.regmap.registers() if r.name == reg_name)
                field_name = next(
                    f.name for f in reg_obj.fields.values() if f.name.lower() == fname
                )
                completions.append(
                    fname if fname == token.lower() else reg_name + "." + field_name
                )

        return sorted(set(completions))


# Entrypoint helpers
def build_arg_parser() -> argparse.ArgumentParser:
    """
    Build the argument parser for the xibif-connection CLI.
    """
    p = argparse.ArgumentParser(prog="xibif-connection", description="XiBIF CLI")
    p.add_argument("--ip", "-i", help="IP address of board to connect to")
    p.add_argument("--uuid", "-u", help="UUID of board (decimal or 0x... hex)")
    p.add_argument("--timeout", "-t", type=float, help="Connection timeout in seconds")
    p.add_argument("--verbose", action="store_true", help="Enable verbose output")
    return p


def main(argv: list[str] | None = None) -> int:
    """
    Start the CLI.
    """
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    shell = XibifShell()

    if args.ip and args.uuid:
        # delegate to the connect command to reuse parsing
        conn_cmd = f"{args.ip} {args.uuid}"
        if args.timeout:
            conn_cmd += f" --timeout {args.timeout}"
        if args.verbose:
            conn_cmd += " --verbose"
        shell.onecmd(f"connect {conn_cmd}")

    try:
        shell.cmdloop()
    except KeyboardInterrupt:
        print("\nKeyboardInterrupt")
        if shell.session and shell.connected:
            try:
                shell.session.disconnect()
            except XibifError:
                pass
        return 1
    except (XibifError, RuntimeError, OSError, ValueError) as e:
        print(f"Fatal error: {e}")
        if shell.session and shell.connected:
            try:
                shell.session.disconnect()
            except XibifError:
                pass
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
