"""Tests for protocol data types."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

import numpy as np

from xibif_connection.protocol.data import (
    AxiAccessStatus,
    Command,
    Message,
    Response,
    ResponseStatus,
    XibifFifo,
    XibifStatus,
    XibifUuid,
    XibifVersion,
)


class CommandTests(unittest.TestCase):

    def test_all_members_exist(self):
        expected = [
            "STATUS", "FLUSH_STREAM", "READ_REGISTER", "WRITE_REGISTER",
            "READ_STREAM", "READ_STREAM_ALL", "WRITE_STREAM", "WRITE_BITSTREAM",
            "UART_PRINT_STATUS", "UART_ENABLE_DBG_OUTPUT", "RESET",
            "AXI_READ", "AXI_WRITE", "READ_REGISTER_MAP", "PERFORMANCE_TEST",
        ]
        for name in expected:
            self.assertIn(name, Command.__members__)

    def test_values(self):
        self.assertEqual(Command.STATUS.value, 0)
        self.assertEqual(Command.FLUSH_STREAM.value, 1)
        self.assertEqual(Command.READ_REGISTER.value, 2)
        self.assertEqual(Command.WRITE_REGISTER.value, 3)
        self.assertEqual(Command.READ_STREAM.value, 4)
        self.assertEqual(Command.READ_STREAM_ALL.value, 5)
        self.assertEqual(Command.WRITE_STREAM.value, 6)
        self.assertEqual(Command.WRITE_BITSTREAM.value, 7)
        self.assertEqual(Command.UART_PRINT_STATUS.value, 8)
        self.assertEqual(Command.UART_ENABLE_DBG_OUTPUT.value, 9)
        self.assertEqual(Command.RESET.value, 10)
        self.assertEqual(Command.AXI_READ.value, 11)
        self.assertEqual(Command.AXI_WRITE.value, 12)
        self.assertEqual(Command.READ_REGISTER_MAP.value, 13)
        self.assertEqual(Command.PERFORMANCE_TEST.value, 14)

    def test_str_status(self):
        self.assertEqual(str(Command.STATUS), "Status")

    def test_str_flush_stream(self):
        self.assertEqual(str(Command.FLUSH_STREAM), "Flush Stream")

    def test_str_read_register(self):
        self.assertEqual(str(Command.READ_REGISTER), "Read Register")

    def test_str_write_register(self):
        self.assertEqual(str(Command.WRITE_REGISTER), "Write Register")

    def test_str_read_stream(self):
        self.assertEqual(str(Command.READ_STREAM), "Read Stream")

    def test_str_reset(self):
        self.assertEqual(str(Command.RESET), "Software Reset")

    def test_str_axi_read(self):
        self.assertEqual(str(Command.AXI_READ), "AXI Read")

    def test_str_performance_test(self):
        self.assertEqual(str(Command.PERFORMANCE_TEST), "Performance Test")

    def test_str_read_stream_all(self):
        self.assertEqual(str(Command.READ_STREAM_ALL), "Read Stream All")

    def test_str_write_stream(self):
        self.assertEqual(str(Command.WRITE_STREAM), "Write Stream")

    def test_str_write_bitstream(self):
        self.assertEqual(str(Command.WRITE_BITSTREAM), "Write Bitstream")

    def test_str_uart_print_status(self):
        self.assertEqual(str(Command.UART_PRINT_STATUS), "UART Print Status")

    def test_str_uart_enable_dbg_output(self):
        self.assertEqual(str(Command.UART_ENABLE_DBG_OUTPUT), "UART Enable Debug Output")

    def test_str_read_register_map(self):
        self.assertEqual(str(Command.READ_REGISTER_MAP), "Read Register Map")

    def test_str_axi_write(self):
        self.assertEqual(str(Command.AXI_WRITE), "AXI Write")


class ResponseStatusTests(unittest.TestCase):

    def test_values(self):
        self.assertEqual(ResponseStatus.OK.value, 0)
        self.assertEqual(ResponseStatus.UNAUTHORIZED.value, 1)
        self.assertEqual(ResponseStatus.COMMAND_NOT_IMPLEMENTED.value, 2)
        self.assertEqual(ResponseStatus.FAILED.value, 3)
        self.assertEqual(ResponseStatus.INVALID_LENGTH.value, 4)

    def test_str_ok(self):
        self.assertEqual(str(ResponseStatus.OK), "Ok")

    def test_str_unauthorized(self):
        self.assertIn("Unauthorized", str(ResponseStatus.UNAUTHORIZED))

    def test_str_command_not_implemented(self):
        self.assertIn("not implemented", str(ResponseStatus.COMMAND_NOT_IMPLEMENTED))

    def test_str_failed(self):
        self.assertIn("failed", str(ResponseStatus.FAILED))

    def test_str_invalid_length(self):
        self.assertIn("Invalid", str(ResponseStatus.INVALID_LENGTH))


class AxiAccessStatusTests(unittest.TestCase):

    def test_values(self):
        self.assertEqual(AxiAccessStatus.AXI_ACCESS_OK.value, 0)
        self.assertEqual(AxiAccessStatus.AXI_ACCESS_NOT_ALLOWED_RANGE.value, 1)
        self.assertEqual(AxiAccessStatus.AXI_ACCESS_NOT_ALLOWED_XIBIF_RANGE.value, 2)
        self.assertEqual(AxiAccessStatus.AXI_FIREWALL_ERROR.value, 3)
        self.assertEqual(AxiAccessStatus.AXI_FIREWALL_DATA_DEC0DEE3_DEADFA11.value, 4)
        self.assertEqual(AxiAccessStatus.AXI_ACCESS_ADDRESS_NOT_ALIGNED.value, 5)


class MessageTests(unittest.TestCase):

    def test_default_command(self):
        msg = Message(uuid=0x1234)
        self.assertEqual(msg.id, Command.STATUS)
        self.assertIsNone(msg.payload)

    def test_uuid_stored(self):
        msg = Message(uuid=0xABCD)
        self.assertEqual(msg.uuid, 0xABCD)

    def test_custom_command(self):
        payload = np.array([1, 2, 3], dtype=np.uint32)
        msg = Message(uuid=0xABCD, id=Command.READ_REGISTER, payload=payload)
        self.assertEqual(msg.uuid, 0xABCD)
        self.assertEqual(msg.id, Command.READ_REGISTER)
        np.testing.assert_array_equal(msg.payload, payload)

    def test_str_contains_command_name(self):
        msg = Message(uuid=0x42, id=Command.STATUS)
        self.assertIn("Status", str(msg))

    def test_str_contains_uuid(self):
        msg = Message(uuid=0x42, id=Command.STATUS)
        self.assertIn("66", str(msg))  # 0x42 = 66


class ResponseTests(unittest.TestCase):

    def test_default_values(self):
        resp = Response()
        self.assertEqual(resp.id, Command.STATUS)
        self.assertEqual(resp.status, ResponseStatus.OK)
        self.assertIsNone(resp.payload)
        self.assertEqual(resp.cycles, -1)

    def test_custom_values(self):
        payload = np.array([1, 2], dtype=np.uint32)
        resp = Response(id=Command.READ_REGISTER, status=ResponseStatus.OK, payload=payload, cycles=1000)
        self.assertEqual(resp.id, Command.READ_REGISTER)
        self.assertEqual(resp.cycles, 1000)
        np.testing.assert_array_equal(resp.payload, payload)

    def test_str_contains_status(self):
        resp = Response(status=ResponseStatus.FAILED)
        self.assertIn("failed", str(resp).lower())


class XibifVersionTests(unittest.TestCase):

    def test_parse_v1_2_3_4(self):
        value = (1 << 24) | (2 << 16) | (3 << 8) | 4
        v = XibifVersion(value)
        self.assertEqual(v.major, 1)
        self.assertEqual(v.minor, 2)
        self.assertEqual(v.patch, 3)
        self.assertEqual(v.rev, 4)

    def test_str(self):
        value = (1 << 24) | (2 << 16) | (3 << 8) | 4
        self.assertEqual(str(XibifVersion(value)), "v1.2.3-4")

    def test_format(self):
        v = XibifVersion((1 << 24) | (2 << 16) | (3 << 8) | 4)
        self.assertEqual(f"{v}", "v1.2.3-4")

    def test_zero_version(self):
        self.assertEqual(str(XibifVersion(0)), "v0.0.0-0")

    def test_max_byte_values(self):
        value = (255 << 24) | (255 << 16) | (255 << 8) | 255
        v = XibifVersion(value)
        self.assertEqual(v.major, 255)
        self.assertEqual(v.minor, 255)
        self.assertEqual(v.patch, 255)
        self.assertEqual(v.rev, 255)


class XibifFifoTests(unittest.TestCase):

    def test_str_disabled(self):
        fifo = XibifFifo(fill=0, depth=0, enabled=False, axiError=False, ddrFull=False)
        self.assertEqual(str(fifo), "Disabled")

    def test_str_enabled(self):
        fifo = XibifFifo(fill=10, depth=100, enabled=True, axiError=False, ddrFull=False)
        s = str(fifo)
        self.assertIn("Fill=10", s)
        self.assertIn("Depth=100", s)

    def test_str_axi_error(self):
        fifo = XibifFifo(fill=5, depth=50, enabled=True, axiError=True, ddrFull=False)
        self.assertIn("AXI Error", str(fifo))

    def test_str_ddr_full(self):
        fifo = XibifFifo(fill=50, depth=50, enabled=True, axiError=False, ddrFull=True)
        self.assertIn("DDR", str(fifo))


class XibifUuidTests(unittest.TestCase):

    def test_parse(self):
        uuid = XibifUuid(0xDEADBEEF)
        self.assertEqual(uuid.uuid, 0xDEADBEEF)

    def test_str_hex_formatted(self):
        uuid = XibifUuid(0xDEADBEEF)
        s = str(uuid)
        self.assertIn("DE", s)
        self.assertIn("AD", s)
        self.assertIn("-", s)

    def test_format(self):
        uuid = XibifUuid(0xDEADBEEF)
        self.assertEqual(f"{uuid}", str(uuid))

    def test_zero_uuid(self):
        uuid = XibifUuid(0)
        self.assertEqual(uuid.uuid, 0)


class XibifStatusTests(unittest.TestCase):

    @staticmethod
    def _make_status_array():
        """Build a valid 19-element status array."""
        # Encode a timestamp: 2024-01-15 10:30:45
        ts = (15 << 27) | (1 << 23) | (24 << 17) | (10 << 12) | (30 << 6) | 45
        return np.array([
            (1 << 24) | (0 << 16) | (0 << 8) | 0,  # [0] registerVersion v1.0.0-0
            (2 << 24) | (0 << 16) | (0 << 8) | 0,  # [1] streamVersion v2.0.0-0
            (0 << 24) | (1 << 16) | (0 << 8) | 0,  # [2] softwareVersion v0.1.0-0
            ts,                                      # [3] hardwareTimestamp
            ts,                                      # [4] softwareTimestamp
            0xDEADBEEF,                              # [5] registerUuid
            0xDEADBEEF,                              # [6] streamUuid
            32,                                      # [7] registerWidth
            32,                                      # [8] streamWidth
            1,                                       # [9] bistreamAvailable
            1,                                       # [10] pl2pcFifo.enabled
            1024,                                    # [11] pl2pcFifo.depth
            512,                                     # [12] pl2pcFifo.fill
            0,                                       # [13] (unused)
            1,                                       # [14] pc2plFifo.enabled
            2048,                                    # [15] pc2plFifo.depth
            1024,                                    # [16] pc2plFifo.fill
            0,                                       # [17] (unused)
            100_000_000,                             # [18] nb_frequency
        ], dtype=np.uint32)

    def test_construction_versions(self):
        status = XibifStatus(self._make_status_array())
        self.assertEqual(status.registerVersion.major, 1)
        self.assertEqual(status.streamVersion.major, 2)
        self.assertEqual(status.softwareVersion.minor, 1)

    def test_construction_widths(self):
        status = XibifStatus(self._make_status_array())
        self.assertEqual(status.registerWidth, 32)
        self.assertEqual(status.streamWidth, 32)

    def test_bistream_available(self):
        status = XibifStatus(self._make_status_array())
        self.assertTrue(status.bistreamAvailable)

    def test_fifo_values(self):
        status = XibifStatus(self._make_status_array())
        self.assertTrue(status.pl2pcFifo.enabled)
        self.assertEqual(status.pl2pcFifo.depth, 1024)
        self.assertEqual(status.pl2pcFifo.fill, 512)
        self.assertTrue(status.pc2plFifo.enabled)
        self.assertEqual(status.pc2plFifo.depth, 2048)
        self.assertEqual(status.pc2plFifo.fill, 1024)

    def test_frequency(self):
        status = XibifStatus(self._make_status_array())
        self.assertEqual(status.nb_frequency, 100_000_000)

    def test_wrong_length_raises(self):
        with self.assertRaises(ValueError):
            XibifStatus(np.zeros(10, dtype=np.uint32))

    def test_str_contains_header(self):
        status = XibifStatus(self._make_status_array())
        self.assertIn("XiBIF Status", str(status))

    def test_bistream_not_available(self):
        arr = self._make_status_array()
        arr[9] = 0
        status = XibifStatus(arr)
        self.assertFalse(status.bistreamAvailable)


if __name__ == "__main__":
    unittest.main()
