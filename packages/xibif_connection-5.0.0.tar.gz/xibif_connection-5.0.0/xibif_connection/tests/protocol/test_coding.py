"""Tests for protocol coding."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

import numpy as np

from xibif_connection.protocol.coding import XibifProtocol
from xibif_connection.protocol.data import Command, Message, Response, ResponseStatus


def _make_header_bytes(cmd_val, status_val, payload_len, cycles_high=0, cycles_low=0):
    """Build a 20-byte (5 x uint32 little-endian) response header."""
    arr = np.array([cmd_val, status_val, payload_len, cycles_high, cycles_low], dtype="<u4")
    return arr.tobytes()


class XibifProtocolEncodeTests(unittest.TestCase):

    def setUp(self):
        self.proto = XibifProtocol(register_width=32)

    def test_encode_no_payload_header_fields(self):
        msg = Message(uuid=0x1234, id=Command.STATUS)
        data = self.proto.encode(msg)
        arr = np.frombuffer(bytes(data), dtype="<u4")
        self.assertEqual(arr[0], Command.STATUS.value)
        self.assertEqual(arr[1], 0x1234)
        self.assertEqual(arr[2], 0)

    def test_encode_no_payload_length(self):
        msg = Message(uuid=0x1234, id=Command.STATUS)
        data = self.proto.encode(msg)
        arr = np.frombuffer(bytes(data), dtype="<u4")
        self.assertEqual(len(arr), 3)

    def test_encode_with_payload_header_fields(self):
        payload = np.array([0xDEAD, 0xBEEF], dtype="<u4")
        msg = Message(uuid=0x42, id=Command.READ_REGISTER, payload=payload)
        data = self.proto.encode(msg)
        arr = np.frombuffer(bytes(data), dtype="<u4")
        self.assertEqual(arr[0], Command.READ_REGISTER.value)
        self.assertEqual(arr[1], 0x42)
        self.assertEqual(arr[2], 8)  # 2 elements * 4 bytes

    def test_encode_with_payload_data(self):
        payload = np.array([0xDEAD, 0xBEEF], dtype="<u4")
        msg = Message(uuid=0x42, id=Command.READ_REGISTER, payload=payload)
        data = self.proto.encode(msg)
        arr = np.frombuffer(bytes(data), dtype="<u4")
        self.assertEqual(arr[3], 0xDEAD)
        self.assertEqual(arr[4], 0xBEEF)

    def test_encode_returns_memoryview(self):
        msg = Message(uuid=1, id=Command.STATUS)
        result = self.proto.encode(msg)
        self.assertIsInstance(result, memoryview)

    def test_encode_empty_payload_array(self):
        msg = Message(uuid=0x99, id=Command.STATUS, payload=np.array([], dtype="<u4"))
        data = self.proto.encode(msg)
        arr = np.frombuffer(bytes(data), dtype="<u4")
        self.assertEqual(len(arr), 3)
        self.assertEqual(arr[2], 0)


class XibifProtocolDecodeTests(unittest.TestCase):

    def setUp(self):
        self.proto = XibifProtocol(register_width=32)

    def test_decode_produces_correct_values(self):
        raw = _make_header_bytes(Command.STATUS.value, ResponseStatus.OK.value, 0)
        decoded = self.proto.decode(raw)
        self.assertEqual(decoded[0], Command.STATUS.value)
        self.assertEqual(decoded[1], ResponseStatus.OK.value)
        self.assertEqual(decoded[2], 0)

    def test_decode_pads_unaligned_bytes(self):
        # 3 bytes → padded to 4 bytes
        raw = b"\x01\x02\x03"
        decoded = self.proto.decode(raw)
        self.assertEqual(len(decoded), 1)

    def test_get_command_from_header(self):
        raw = _make_header_bytes(Command.READ_REGISTER.value, ResponseStatus.OK.value, 0)
        header = self.proto.decode(raw)
        self.assertEqual(self.proto.get_command_from_header(header), Command.READ_REGISTER)

    def test_get_status_from_header_ok(self):
        raw = _make_header_bytes(Command.STATUS.value, ResponseStatus.OK.value, 0)
        header = self.proto.decode(raw)
        self.assertEqual(self.proto.get_command_status_from_header(header), ResponseStatus.OK)

    def test_get_status_from_header_failed(self):
        raw = _make_header_bytes(Command.STATUS.value, ResponseStatus.FAILED.value, 0)
        header = self.proto.decode(raw)
        self.assertEqual(self.proto.get_command_status_from_header(header), ResponseStatus.FAILED)

    def test_get_payload_length(self):
        raw = _make_header_bytes(Command.STATUS.value, ResponseStatus.OK.value, 76)
        header = self.proto.decode(raw)
        self.assertEqual(self.proto.get_payload_length_from_header(header), 76)

    def test_get_execution_time(self):
        raw = _make_header_bytes(Command.STATUS.value, ResponseStatus.OK.value, 0, cycles_high=0, cycles_low=1000)
        header = self.proto.decode(raw)
        self.assertEqual(self.proto.get_execution_time_from_header(header), 1000)

    def test_get_execution_time_high_bits(self):
        raw = _make_header_bytes(Command.STATUS.value, ResponseStatus.OK.value, 0, cycles_high=1, cycles_low=0)
        header = self.proto.decode(raw)
        self.assertEqual(self.proto.get_execution_time_from_header(header), 1 << 32)

    def test_invalid_header_get_command_raises(self):
        bad = np.array([0, 1, 2], dtype="<u4")
        with self.assertRaises(ValueError):
            self.proto.get_command_from_header(bad)

    def test_invalid_header_get_status_raises(self):
        bad = np.array([0, 1, 2], dtype="<u4")
        with self.assertRaises(ValueError):
            self.proto.get_command_status_from_header(bad)

    def test_invalid_header_get_payload_len_raises(self):
        bad = np.array([0, 1, 2], dtype="<u4")
        with self.assertRaises(ValueError):
            self.proto.get_payload_length_from_header(bad)

    def test_invalid_header_get_exec_time_raises(self):
        bad = np.array([0, 1, 2], dtype="<u4")
        with self.assertRaises(ValueError):
            self.proto.get_execution_time_from_header(bad)

    def test_build_response(self):
        raw = _make_header_bytes(Command.STATUS.value, ResponseStatus.OK.value, 0, 0, 500)
        header = self.proto.decode(raw)
        payload = np.array([1, 2, 3], dtype="<u4")
        resp = self.proto.build_response(header, payload)
        self.assertIsInstance(resp, Response)
        self.assertEqual(resp.id, Command.STATUS)
        self.assertEqual(resp.status, ResponseStatus.OK)
        self.assertEqual(resp.cycles, 500)
        np.testing.assert_array_equal(resp.payload, payload)


class XibifProtocol32BitRegisterTests(unittest.TestCase):

    def setUp(self):
        self.proto = XibifProtocol(register_width=32)

    def test_num_unit_registers(self):
        self.assertEqual(self.proto._num_unit_registers(), 1)

    def test_encode_register_address_single(self):
        encoded = self.proto.encode_register_address(0x10)
        np.testing.assert_array_equal(encoded, [0x10])

    def test_encode_register_address_list(self):
        encoded = self.proto.encode_register_address([0x10, 0x20])
        np.testing.assert_array_equal(encoded, [0x10, 0x20])

    def test_encode_register_data_single(self):
        encoded = self.proto.encode_register_data(0xABCD)
        np.testing.assert_array_equal(encoded, [0xABCD])

    def test_encode_register_data_list(self):
        encoded = self.proto.encode_register_data([0x10, 0x20])
        np.testing.assert_array_equal(encoded, [0x10, 0x20])

    def test_decode_register_data_single(self):
        encoded = np.array([0x42], dtype="<u4")
        decoded = self.proto.decode_register_data(encoded)
        self.assertEqual(decoded[0], 0x42)

    def test_decode_register_data_multiple(self):
        encoded = np.array([0x42, 0x99], dtype="<u4")
        decoded = self.proto.decode_register_data(encoded)
        self.assertEqual(decoded[0], 0x42)
        self.assertEqual(decoded[1], 0x99)

    def test_encode_decode_roundtrip(self):
        values = [0x00, 0xFF, 0xDEADBEEF & 0xFFFFFFFF]
        encoded = self.proto.encode_register_data(values)
        decoded = self.proto.decode_register_data(encoded)
        self.assertEqual(list(decoded), values)


class XibifProtocol64BitRegisterTests(unittest.TestCase):

    def setUp(self):
        self.proto = XibifProtocol(register_width=64)

    def test_num_unit_registers(self):
        self.assertEqual(self.proto._num_unit_registers(), 2)

    def test_encode_register_address_produces_two_offsets(self):
        encoded = self.proto.encode_register_address(0x10)
        np.testing.assert_array_equal(encoded, [0x10, 0x14])

    def test_encode_register_data_splits_value(self):
        # 0x100000002 → low=0x00000002, high=0x00000001
        encoded = self.proto.encode_register_data(0x100000002)
        np.testing.assert_array_equal(encoded, [0x00000002, 0x00000001])

    def test_decode_register_data_combines_chunks(self):
        raw = np.array([0x00000002, 0x00000001], dtype="<u4")
        decoded = self.proto.decode_register_data(raw)
        self.assertEqual(decoded[0], 0x100000002)

    def test_encode_decode_roundtrip_64bit(self):
        value = 0xDEADBEEFCAFEBABE
        encoded = self.proto.encode_register_data(value)
        decoded = self.proto.decode_register_data(encoded)
        self.assertEqual(decoded[0], value)


class XibifProtocolOddWidthRegisterTests(unittest.TestCase):

    def setUp(self):
        self.proto = XibifProtocol(register_width=48)

    def test_num_unit_registers_rounds_up(self):
        # 48 / 32 = 1.5 → rounds up to 2
        self.assertEqual(self.proto._num_unit_registers(), 2)

    def test_encode_register_address_48bit(self):
        encoded = self.proto.encode_register_address(0x00)
        # 2 accesses: 0x00 and 0x04
        np.testing.assert_array_equal(encoded, [0x00, 0x04])


if __name__ == "__main__":
    unittest.main()
