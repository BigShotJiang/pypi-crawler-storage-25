"""Tests for xibif_connection.protocol."""
