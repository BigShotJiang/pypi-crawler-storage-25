"""Tests for register_map."""

import unittest

from xibif_connection.register_map import Field, RegisterMap


def _sample_json_map():
    return {
        "registers": [
            {
                "name": "CTRL",
                "address": "0x00",
                "fields": [
                    {"name": "enable", "lsb": 0, "width": 1},
                    {"name": "mode", "lsb": 4, "msb": 7},
                ],
            },
            {
                "name": "STATUS",
                "address": 4,
                "fields": [
                    {"name": "done", "lsb": 0, "width": 1},
                    {"name": "error", "lsb": 1, "width": 1},
                ],
            },
        ]
    }


class FieldTests(unittest.TestCase):

    def test_post_init_normalizes_missing_msb(self):
        field = Field(name="flag", lsb=2, msb=None)
        self.assertEqual(field.msb, 2)
        self.assertEqual(field.width, 1)

    def test_width_mask_and_shifted_mask(self):
        field = Field(name="mode", lsb=4, msb=7)
        self.assertEqual(field.width, 4)
        self.assertEqual(field.mask, 0xF)
        self.assertEqual(field.shifted_mask, 0xF0)

    def test_extract(self):
        field = Field(name="mode", lsb=4, msb=7)
        self.assertEqual(field.extract(0xB0), 0xB)

    def test_insert_into(self):
        field = Field(name="mode", lsb=4, msb=7)
        self.assertEqual(field.insert_into(0x03, 0xA), 0xA3)

    def test_insert_into_rejects_overflow(self):
        field = Field(name="mode", lsb=4, msb=7)
        with self.assertRaises(ValueError):
            field.insert_into(0, 0x10)

    def test_invalid_field_definition_raises(self):
        with self.assertRaises(ValueError):
            Field(name="bad", lsb=4, msb=3)

    def test_non_integer_register_value_raises(self):
        field = Field(name="mode", lsb=4, msb=7)
        with self.assertRaises(TypeError):
            field.extract("0x10")

    def test_insert_into_rejects_bad_types_and_negative_values(self):
        field = Field(name="mode", lsb=4, msb=7)
        with self.assertRaises(TypeError):
            field.insert_into("bad", 1)
        with self.assertRaises(TypeError):
            field.insert_into(0, "bad")
        with self.assertRaises(ValueError):
            field.insert_into(0, -1)


class RegisterTests(unittest.TestCase):

    def test_get_field_handles_none_and_case_insensitive_names(self):
        regmap = RegisterMap.from_json_map(_sample_json_map())
        reg = next(reg for reg in regmap.registers() if reg.name == "CTRL")
        self.assertIsNone(reg.get_field(None))
        self.assertEqual(reg.get_field("MODE").name, "mode")


class RegisterMapFactoryTests(unittest.TestCase):

    def test_from_json_map_builds_registers(self):
        regmap = RegisterMap.from_json_map(_sample_json_map())
        regs = sorted(regmap.registers(), key=lambda reg: reg.address)
        self.assertEqual([reg.name for reg in regs], ["CTRL", "STATUS"])

    def test_from_json_map_accepts_top_level_mapping(self):
        regmap = RegisterMap.from_json_map(
            {
                "CTRL": {
                    "address": "0x10",
                    "fields": [{"name": "enable", "lsb": 0, "width": 1}],
                }
            }
        )
        reg_name, address, field = regmap.resolve("ctrl.enable")
        self.assertEqual(reg_name, "CTRL")
        self.assertEqual(address, 0x10)
        self.assertEqual(field.name, "enable")

    def test_registers_must_be_list(self):
        with self.assertRaises(ValueError):
            RegisterMap.from_json_map({"registers": {}})

    def test_duplicate_register_raises(self):
        with self.assertRaises(ValueError):
            RegisterMap.from_json_map(
                {
                    "registers": [
                        {"name": "CTRL", "address": 0},
                        {"name": "ctrl", "address": 4},
                    ]
                }
            )

    def test_duplicate_field_raises(self):
        with self.assertRaises(ValueError):
            RegisterMap.from_json_map(
                {
                    "registers": [
                        {
                            "name": "CTRL",
                            "address": 0,
                            "fields": [
                                {"name": "enable", "lsb": 0, "width": 1},
                                {"name": "ENABLE", "lsb": 1, "width": 1},
                            ],
                        }
                    ]
                }
            )

    def test_missing_address_raises(self):
        with self.assertRaises(ValueError):
            RegisterMap.from_json_map({"registers": [{"name": "CTRL"}]})

    def test_invalid_field_width_raises(self):
        with self.assertRaises(ValueError):
            RegisterMap.from_json_map(
                {
                    "registers": [
                        {
                            "name": "CTRL",
                            "address": 0,
                            "fields": [{"name": "enable", "lsb": 0, "width": 0}],
                        }
                    ]
                }
            )

    def test_parse_address_accepts_int_and_strings(self):
        self.assertEqual(RegisterMap._parse_address(4), 4)
        self.assertEqual(RegisterMap._parse_address("0x10"), 0x10)
        self.assertEqual(RegisterMap._parse_address("12"), 12)

    def test_parse_address_rejects_invalid_values(self):
        with self.assertRaises(ValueError):
            RegisterMap._parse_address("0xnope")
        with self.assertRaises(TypeError):
            RegisterMap._parse_address(None)

    def test_from_json_map_rejects_invalid_top_level_register_definition(self):
        with self.assertRaises(ValueError):
            RegisterMap.from_json_map({"CTRL": 1})

    def test_from_json_map_accepts_bitfields_alias_and_none_fields(self):
        regmap = RegisterMap.from_json_map(
            {
                "registers": [
                    {
                        "name": "CTRL",
                        "address": 0,
                        "bitfields": [{"name": "enable", "lsb": 0, "width": 1}],
                    },
                    {"name": "EMPTY", "address": 4, "fields": None},
                ]
            }
        )
        reg_name, address, field = regmap.resolve("CTRL.enable")
        self.assertEqual((reg_name, address, field.name), ("CTRL", 0, "enable"))
        self.assertEqual(regmap.resolve("EMPTY"), ("EMPTY", 4, None))

    def test_from_json_map_rejects_invalid_field_entries(self):
        with self.assertRaises(ValueError):
            RegisterMap.from_json_map(
                {"registers": [{"name": "CTRL", "address": 0, "fields": [123]}]}
            )
        with self.assertRaises(ValueError):
            RegisterMap.from_json_map(
                {"registers": [{"name": "CTRL", "address": 0, "fields": [{"lsb": 0}]}]}
            )
        with self.assertRaises(ValueError):
            RegisterMap.from_json_map(
                {
                    "registers": [
                        {"name": "CTRL", "address": 0, "fields": [{"name": "enable"}]}
                    ]
                }
            )
        with self.assertRaises(ValueError):
            RegisterMap.from_json_map(
                {
                    "registers": [
                        {
                            "name": "CTRL",
                            "address": 0,
                            "fields": [{"name": "enable", "lsb": -1}],
                        }
                    ]
                }
            )
        with self.assertRaises(ValueError):
            RegisterMap.from_json_map(
                {
                    "registers": [
                        {
                            "name": "CTRL",
                            "address": 0,
                            "fields": [{"name": "enable", "lsb": 0, "msb": "bad"}],
                        }
                    ]
                }
            )


class RegisterMapUsageTests(unittest.TestCase):

    def setUp(self):
        self.regmap = RegisterMap.from_json_map(_sample_json_map())

    def test_resolve_register(self):
        reg_name, address, field = self.regmap.resolve("ctrl")
        self.assertEqual((reg_name, address, field), ("CTRL", 0, None))

    def test_resolve_qualified_field(self):
        reg_name, address, field = self.regmap.resolve("CTRL.mode")
        self.assertEqual(reg_name, "CTRL")
        self.assertEqual(address, 0)
        self.assertEqual(field.name, "mode")

    def test_resolve_unique_field(self):
        reg_name, address, field = self.regmap.resolve("done")
        self.assertEqual(reg_name, "STATUS")
        self.assertEqual(address, 4)
        self.assertEqual(field.name, "done")

    def test_resolve_ambiguous_field_raises(self):
        regmap = RegisterMap.from_json_map(
            {
                "registers": [
                    {"name": "A", "address": 0, "fields": [{"name": "flag", "lsb": 0}]},
                    {"name": "B", "address": 4, "fields": [{"name": "flag", "lsb": 1}]},
                ]
            }
        )
        with self.assertRaises(ValueError):
            regmap.resolve("flag")

    def test_resolve_missing_name_raises(self):
        with self.assertRaises(ValueError):
            self.regmap.resolve("missing")

    def test_resolve_empty_name_raises(self):
        with self.assertRaises(ValueError):
            self.regmap.resolve("  ")

    def test_read_field_from_register_returns_full_value(self):
        self.assertEqual(self.regmap.read_field_from_register("CTRL", 0xA5, None), 0xA5)

    def test_read_field_from_register_extracts_field(self):
        self.assertEqual(self.regmap.read_field_from_register("CTRL", 0xB0, "mode"), 0xB)

    def test_read_field_from_register_rejects_bad_input(self):
        with self.assertRaises(TypeError):
            self.regmap.read_field_from_register(123, 0, None)
        with self.assertRaises(ValueError):
            self.regmap.read_field_from_register("CTRL", None, None)
        with self.assertRaises(TypeError):
            self.regmap.read_field_from_register("CTRL", "bad", None)
        with self.assertRaises(ValueError):
            self.regmap.read_field_from_register("UNKNOWN", 0, None)
        with self.assertRaises(ValueError):
            self.regmap.read_field_from_register("CTRL", 0, "missing")

    def test_compose_register_write_full_register(self):
        self.assertEqual(self.regmap.compose_register_write("CTRL", None, 0x55, None), 0x55)

    def test_compose_register_write_updates_field(self):
        self.assertEqual(
            self.regmap.compose_register_write("CTRL", "mode", 0xA, 0x03),
            0xA3,
        )

    def test_compose_register_write_uses_zero_for_missing_base(self):
        self.assertEqual(self.regmap.compose_register_write("CTRL", "enable", 1, None), 1)

    def test_compose_register_write_rejects_bad_input(self):
        with self.assertRaises(TypeError):
            self.regmap.compose_register_write(123, None, 1, None)
        with self.assertRaises(ValueError):
            self.regmap.compose_register_write("CTRL", None, None, None)
        with self.assertRaises(TypeError):
            self.regmap.compose_register_write("CTRL", None, "bad", None)
        with self.assertRaises(ValueError):
            self.regmap.compose_register_write("UNKNOWN", None, 1, None)
        with self.assertRaises(ValueError):
            self.regmap.compose_register_write("CTRL", "missing", 1, 0)
        with self.assertRaises(TypeError):
            self.regmap.compose_register_write("CTRL", "enable", 1, "bad")

    def test_repr_contains_register_count(self):
        self.assertEqual(repr(self.regmap), "<RegisterMap registers=2>")


if __name__ == "__main__":
    unittest.main()