"""Tests for cli."""

import io
import unittest
from unittest.mock import MagicMock, patch

from xibif_connection import cli
from xibif_connection.exceptions import XibifError
from xibif_connection.register_map import RegisterMap


def _sample_regmap():
    return RegisterMap.from_json_map(
        {
            "registers": [
                {
                    "name": "CTRL",
                    "address": 0,
                    "fields": [
                        {"name": "enable", "lsb": 0, "width": 1},
                        {"name": "mode", "lsb": 4, "width": 4},
                    ],
                },
                {
                    "name": "STATUS",
                    "address": 4,
                    "fields": [{"name": "done", "lsb": 0, "width": 1}],
                },
            ]
        }
    )


class ParseIntTests(unittest.TestCase):

    def test_parse_int_decimal(self):
        self.assertEqual(cli.parse_int("12"), 12)

    def test_parse_int_hex(self):
        self.assertEqual(cli.parse_int("0x10"), 16)


class WatchTaskTests(unittest.TestCase):

    def test_run_invokes_callback_on_change(self):
        callback = MagicMock()
        values = iter([1, 2])
        task = cli.WatchTask("sig", lambda: next(values), interval=0.0, callback=callback)
        task.stop_event = MagicMock()
        task.stop_event.is_set.side_effect = [False, False, True]
        with patch("time.sleep"):
            task.run()
        callback.assert_called_once_with("sig", 1, 2)

    def test_start_and_stop_delegate_to_thread(self):
        task = cli.WatchTask("sig", lambda: 1)
        task.thread = MagicMock()
        task.stop_event = MagicMock()
        task.start()
        task.stop()
        task.thread.start.assert_called_once()
        task.stop_event.set.assert_called_once()
        task.thread.join.assert_called_once()


class XibifShellHelperTests(unittest.TestCase):

    def setUp(self):
        self.shell = cli.XibifShell()
        self.shell.regmap = _sample_regmap()
        self.shell.session = MagicMock()
        self.shell.connected = True

    def test_looks_numeric(self):
        self.assertTrue(self.shell._looks_numeric("0x10"))
        self.assertTrue(self.shell._looks_numeric("42"))
        self.assertFalse(self.shell._looks_numeric("ctrl"))

    def test_read_register_by_address(self):
        self.shell.session.read.return_value = 0x1234
        self.assertEqual(self.shell._read_register(0x10), 0x1234)
        self.shell.session.read.assert_called_once_with(0x10)

    def test_read_register_by_field_name(self):
        self.shell.session.read.return_value = 0xA1
        self.assertEqual(self.shell._read_register("ctrl.mode"), 0xA)

    def test_read_register_without_session_raises(self):
        self.shell.session = None
        with self.assertRaises(RuntimeError):
            self.shell._read_register(0)

    def test_read_register_resolve_failure_raises(self):
        with self.assertRaises(RuntimeError):
            self.shell._read_register("missing")

    def test_attempt_auto_load_map_success(self):
        self.shell.session.read_registermap.return_value = {"registers": [{"name": "A", "address": 0}]}
        self.shell._attempt_auto_load_map()
        self.assertIsNotNone(self.shell.regmap)

    def test_attempt_auto_load_map_ignores_failures(self):
        self.shell.session.read_registermap.side_effect = XibifError("fail")
        existing = self.shell.regmap
        self.shell._attempt_auto_load_map()
        self.assertIs(self.shell.regmap, existing)

    def test_attempt_auto_load_map_ignores_when_disconnected(self):
        self.shell.connected = False
        existing = self.shell.regmap
        self.shell._attempt_auto_load_map()
        self.assertIs(self.shell.regmap, existing)

    def test_render_help_prints_docstring(self):
        def helper():
            """hello"""

        with patch("builtins.print") as mock_print:
            self.shell._render_help(helper)
        mock_print.assert_called_once_with("hello")

    def test_load_regmap_success(self):
        self.shell.session.read_registermap.return_value = {"registers": [{"name": "A", "address": 0}]}
        with patch("builtins.print") as mock_print:
            self.shell._load_regmap()
        mock_print.assert_called_with("Loaded register map with 1 registers")

    def test_load_regmap_not_connected(self):
        self.shell.connected = False
        with patch("builtins.print") as mock_print:
            self.shell._load_regmap()
        mock_print.assert_called_with("Not connected.")

    def test_load_regmap_read_failure(self):
        self.shell.session.read_registermap.side_effect = XibifError("boom")
        with patch("builtins.print") as mock_print:
            self.shell._load_regmap()
        mock_print.assert_called_with("Failed to read register map: boom")

    def test_load_regmap_parse_failure(self):
        self.shell.session.read_registermap.return_value = {"registers": {}}
        with patch("builtins.print") as mock_print:
            self.shell._load_regmap()
        mock_print.assert_called_with("Failed to parse register map: 'registers' must be a list")

    def test_print_regmap_without_map(self):
        self.shell.regmap = None
        with patch("builtins.print") as mock_print:
            self.shell._print_regmap()
        mock_print.assert_called_with("No register map loaded.")

    def test_print_regmap_with_map(self):
        with patch("builtins.print") as mock_print:
            self.shell._print_regmap()
        self.assertGreaterEqual(mock_print.call_count, 3)

    def test_print_reg_val_variants(self):
        with patch("builtins.print") as mock_print:
            self.shell._print_reg_val(10, "hex")
            self.shell._print_reg_val(10, "bin")
            self.shell._print_reg_val(10, "dec")
        self.assertEqual(mock_print.call_count, 3)

    def test_read_register_requires_regmap_for_string_names(self):
        self.shell.regmap = None
        with self.assertRaises(RuntimeError):
            self.shell._read_register("CTRL")

    def test_read_register_non_scalar_raises(self):
        self.shell.session.read.return_value = [1, 2]
        with self.assertRaises(RuntimeError):
            self.shell._read_register(0)


class XibifShellCommandTests(unittest.TestCase):

    def setUp(self):
        self.shell = cli.XibifShell()
        self.shell.regmap = _sample_regmap()
        self.shell.session = MagicMock()
        self.shell.session.ip = "192.168.1.10"
        self.shell.connected = True

    def test_do_connect_usage(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_connect("")
        mock_print.assert_called_with("Usage: connect <ip> <uuid> [--timeout N] [--verbose]")

    def test_do_connect_invalid_uuid(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_connect("192.168.1.10 nope")
        mock_print.assert_called_with("Invalid uuid. Must be integer or 0x... hex.")

    def test_do_connect_success(self):
        with patch("xibif_connection.cli.XibifSession") as mock_session_cls:
            session = MagicMock()
            mock_session_cls.return_value = session
            with patch.object(self.shell, "_attempt_auto_load_map") as mock_auto_load:
                with patch("builtins.print") as mock_print:
                    self.shell.do_connect("192.168.1.10 0x12 --timeout 5 --verbose")
        self.assertTrue(self.shell.connected)
        mock_session_cls.assert_called_once_with("192.168.1.10", 0x12, timeout=5.0, verbose=True)
        session.connect.assert_called_once()
        mock_auto_load.assert_called_once()
        mock_print.assert_called_with("Connected to 192.168.1.10")

    def test_do_connect_invalid_timeout(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_connect("192.168.1.10 0x12 --timeout nope")
        mock_print.assert_called_with("Invalid timeout value.")

    def test_do_connect_ignores_unknown_option(self):
        with patch("xibif_connection.cli.XibifSession") as mock_session_cls:
            session = MagicMock()
            mock_session_cls.return_value = session
            with patch.object(self.shell, "_attempt_auto_load_map"):
                with patch("builtins.print") as mock_print:
                    self.shell.do_connect("192.168.1.10 0x12 --weird")
        mock_print.assert_any_call("Ignoring unknown option: --weird")

    def test_do_connect_failure(self):
        with patch("xibif_connection.cli.XibifSession") as mock_session_cls:
            session = MagicMock()
            session.connect.side_effect = XibifError("boom")
            mock_session_cls.return_value = session
            with patch("builtins.print") as mock_print:
                self.shell.do_connect("192.168.1.10 0x12")
        self.assertFalse(self.shell.connected)
        mock_print.assert_called_with("Failed to connect: boom")

    def test_do_disconnect_active(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_disconnect("")
        self.assertFalse(self.shell.connected)
        self.assertIsNone(self.shell.session)
        mock_print.assert_called_with("Disconnected.")

    def test_do_disconnect_without_session(self):
        self.shell.connected = False
        with patch("builtins.print") as mock_print:
            self.shell.do_disconnect("")
        mock_print.assert_called_with("No active session.")

    def test_do_status_success(self):
        self.shell.session.read_board_status.return_value = "STATUS"
        with patch("builtins.print") as mock_print:
            self.shell.do_status("")
        mock_print.assert_called_with("STATUS")

    def test_do_status_failure(self):
        self.shell.session.read_board_status.side_effect = XibifError("boom")
        with patch("builtins.print") as mock_print:
            self.shell.do_status("")
        mock_print.assert_called_with("Failed to read status: boom")

    def test_do_ping_not_connected(self):
        self.shell.connected = False
        with patch("builtins.print") as mock_print:
            self.shell.do_ping("")
        mock_print.assert_called_with("Not connected.")

    def test_do_ping_success_summary(self):
        self.shell.session.ping.side_effect = [0.001, 0.002]
        with patch("time.sleep"):
            with patch("builtins.print") as mock_print:
                self.shell.do_ping("--count 2 --interval 0")
        self.assertGreaterEqual(mock_print.call_count, 4)

    def test_do_ping_invalid_count(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_ping("--count nope")
        mock_print.assert_called_with("Invalid count value.")

    def test_do_ping_invalid_interval(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_ping("--interval nope")
        mock_print.assert_called_with("Invalid interval value.")

    def test_do_ping_failure(self):
        self.shell.session.ping.side_effect = XibifError("boom")
        with patch("builtins.print") as mock_print:
            self.shell.do_ping("")
        mock_print.assert_any_call("Ping failed: boom")

    def test_do_read_usage(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_read("")
        mock_print.assert_called_with("Usage: read <address|name> [count] [--format <dec|hex|bin>]")

    def test_do_read_numeric_address(self):
        with patch.object(self.shell, "_read_register", side_effect=[1, 2]) as mock_read:
            with patch.object(self.shell, "_print_reg_val") as mock_print_val:
                self.shell.do_read("0x0 2")
        self.assertEqual(mock_read.call_count, 2)
        self.assertEqual(mock_print_val.call_count, 2)

    def test_do_read_invalid_count(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_read("0x0 nope")
        mock_print.assert_called_with("Invalid count.")

    def test_do_read_rejects_non_positive_count(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_read("0x0 0")
        mock_print.assert_called_with("Count must be >= 1")

    def test_do_read_named_target_failure(self):
        with patch.object(self.shell, "_read_register", side_effect=RuntimeError("boom")):
            with patch("builtins.print") as mock_print:
                self.shell.do_read("CTRL")
        mock_print.assert_called_with("Failed to read register CTRL - boom")

    def test_do_read_named_target(self):
        with patch.object(self.shell, "_read_register", return_value=7) as mock_read:
            with patch.object(self.shell, "_print_reg_val") as mock_print_val:
                self.shell.do_read("CTRL.enable")
        mock_read.assert_called_once_with("CTRL.enable")
        mock_print_val.assert_called_once_with(7, "hex")

    def test_do_write_numeric_address(self):
        self.shell.do_write("0x10 0x20")
        self.shell.session.write.assert_called_once_with(0x10, 0x20)

    def test_do_write_invalid_value(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_write("CTRL nope")
        mock_print.assert_called_with("Invalid value.")

    def test_do_write_missing_regmap(self):
        self.shell.regmap = None
        with patch("builtins.print") as mock_print:
            self.shell.do_write("CTRL 1")
        mock_print.assert_called_with("Register map not loaded. Use 'load_map' first or provide numeric address.")

    def test_do_write_named_field_success(self):
        self.shell.session.read.return_value = 0x03
        self.shell.do_write("CTRL.mode 0xA")
        self.shell.session.write.assert_called_once_with(0, 0xA3)

    def test_do_write_resolve_failure(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_write("missing 1")
        self.assertIn("Resolve failed:", mock_print.call_args[0][0])


    def test_do_write_non_int_current_value_returns_early(self):
        self.shell.session.read.return_value = [1]
        self.shell.do_write("CTRL.mode 1")
        self.shell.session.write.assert_not_called()

    def test_do_write_compose_failure(self):
        self.shell.session.read.return_value = 0
        with patch.object(self.shell.regmap, "compose_register_write", side_effect=ValueError("boom")):
            with patch("builtins.print") as mock_print:
                self.shell.do_write("CTRL.mode 1")
        mock_print.assert_called_with("Compose failed: boom")

    def test_do_write_write_failure(self):
        self.shell.session.read.return_value = 0
        self.shell.session.write.side_effect = XibifError("boom")
        with patch("builtins.print") as mock_print:
            self.shell.do_write("CTRL.mode 1")
        mock_print.assert_called_with("Write failed: boom")

    def test_do_regmap_force_and_print(self):
        with patch.object(self.shell, "_load_regmap") as mock_load:
            with patch.object(self.shell, "_print_regmap") as mock_print_regmap:
                self.shell.do_regmap("--force --print")
        mock_load.assert_called_once()
        mock_print_regmap.assert_called_once()

    def test_do_regmap_initial_load_when_missing(self):
        self.shell.regmap = None
        with patch.object(self.shell, "_load_regmap") as mock_load:
            self.shell.do_regmap("")
        mock_load.assert_called_once()

    def test_do_regmap_ignores_unknown_option(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_regmap("--weird")
        mock_print.assert_called_with("Ignoring unknown option: --weird")

    def test_do_watch_adds_task(self):
        fake_task = MagicMock()
        with patch("xibif_connection.cli.WatchTask", return_value=fake_task) as mock_task_cls:
            with patch("builtins.print") as mock_print:
                self.shell.do_watch("CTRL 0.5")
        mock_task_cls.assert_called_once()
        fake_task.start.assert_called_once()
        self.assertIn(fake_task, self.shell.watch_tasks)
        mock_print.assert_called_with("Started watch 'CTRL'")

    def test_do_watch_usage(self):
        with patch("builtins.print") as mock_print:
            self.shell.do_watch("")
        mock_print.assert_called_with("Usage: watch <name> [interval]")

    def test_do_unwatch_stops_matching_tasks(self):
        task_a = MagicMock(name="task_a")
        task_a.name = "CTRL"
        task_b = MagicMock(name="task_b")
        task_b.name = "STATUS"
        self.shell.watch_tasks = [task_a, task_b]
        with patch("builtins.print") as mock_print:
            self.shell.do_unwatch("CTRL")
        task_a.stop.assert_called_once()
        self.assertEqual(self.shell.watch_tasks, [task_b])
        mock_print.assert_called_with("Stopped watch 'CTRL'")

    def test_do_reset_not_connected(self):
        self.shell.connected = False
        with patch("builtins.print") as mock_print:
            self.shell.do_reset("")
        mock_print.assert_called_with("Not connected.")

    def test_do_quit_disconnects_and_stops_tasks(self):
        task = MagicMock()
        self.shell.watch_tasks = [task]
        with patch("builtins.print") as mock_print:
            result = self.shell.do_quit("")
        task.stop.assert_called_once()
        self.shell.session.disconnect.assert_called_once()
        self.assertTrue(result)
        mock_print.assert_called_with("Bye.")

    def test_do_exit_aliases_quit(self):
        with patch.object(self.shell, "do_quit", return_value=True) as mock_quit:
            self.assertTrue(self.shell.do_exit(""))
        mock_quit.assert_called_once_with("")

    def test_emptyline_returns_false(self):
        self.assertFalse(self.shell.emptyline())

    def test_complete_read_register_completion(self):
        self.assertEqual(self.shell.complete_read("CT", "read CT", 5, 7), ["CTRL"])

    def test_complete_read_field_completion(self):
        self.assertEqual(self.shell.complete_read("m", "read CTRL.m", 10, 11), ["CTRL.mode"])

    def test_complete_read_global_unique_field_completion(self):
        self.assertEqual(self.shell.complete_read("do", "read do", 5, 7), ["STATUS.done"])


class MainTests(unittest.TestCase):

    def test_build_arg_parser(self):
        parser = cli.build_arg_parser()
        args = parser.parse_args(["--ip", "192.168.1.1", "--uuid", "0x12", "--timeout", "2", "--verbose"])
        self.assertEqual(args.ip, "192.168.1.1")
        self.assertEqual(args.uuid, "0x12")
        self.assertEqual(args.timeout, 2.0)
        self.assertTrue(args.verbose)

    def test_main_returns_zero(self):
        with patch("xibif_connection.cli.XibifShell") as mock_shell_cls:
            shell = MagicMock()
            mock_shell_cls.return_value = shell
            self.assertEqual(cli.main([]), 0)
        shell.cmdloop.assert_called_once()

    def test_main_autoconnects(self):
        with patch("xibif_connection.cli.XibifShell") as mock_shell_cls:
            shell = MagicMock()
            mock_shell_cls.return_value = shell
            cli.main(["--ip", "192.168.1.1", "--uuid", "0x12", "--timeout", "2", "--verbose"])
        shell.onecmd.assert_called_once_with("connect 192.168.1.1 0x12 --timeout 2.0 --verbose")

    def test_main_keyboard_interrupt(self):
        with patch("xibif_connection.cli.XibifShell") as mock_shell_cls:
            shell = MagicMock()
            shell.cmdloop.side_effect = KeyboardInterrupt()
            shell.session = MagicMock()
            shell.connected = True
            mock_shell_cls.return_value = shell
            with patch("builtins.print") as mock_print:
                self.assertEqual(cli.main([]), 1)
        shell.session.disconnect.assert_called_once()
        mock_print.assert_called_with("\nKeyboardInterrupt")

    def test_main_fatal_error_returns_two(self):
        with patch("xibif_connection.cli.XibifShell") as mock_shell_cls:
            shell = MagicMock()
            shell.cmdloop.side_effect = RuntimeError("boom")
            shell.session = MagicMock()
            shell.connected = True
            mock_shell_cls.return_value = shell
            with patch("builtins.print") as mock_print:
                self.assertEqual(cli.main([]), 2)
        shell.session.disconnect.assert_called_once()
        mock_print.assert_called_with("Fatal error: boom")


if __name__ == "__main__":
    unittest.main()
