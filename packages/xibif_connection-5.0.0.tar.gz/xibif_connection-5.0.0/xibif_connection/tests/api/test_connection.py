"""Tests for XibifConnection."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest
from unittest.mock import MagicMock, patch
import json
import os
import tempfile

import numpy as np

from xibif_connection.api.connection import XibifConnection
from xibif_connection.exceptions import XibifError, XibifResponseError
from xibif_connection.protocol.coding import XibifProtocol
from xibif_connection.protocol.data import Command, Message, Response, ResponseStatus, XibifStatus
from xibif_connection.protocol.data import AxiAccessStatus


def _make_status_payload():
    """Build a minimal valid 19-element status payload."""
    ts = (15 << 27) | (1 << 23) | (24 << 17) | (10 << 12) | (30 << 6) | 45
    return np.array([
        (1 << 24), (2 << 24), (1 << 16),  # versions [0–2]
        ts, ts,                             # timestamps [3–4]
        0xDEADBEEF, 0xDEADBEEF,            # UUIDs [5–6]
        32, 32,                             # register/stream width [7–8]
        1,                                  # bistreamAvailable [9]
        1, 1024, 512,                       # pl2pcFifo: enabled, depth, fill [10–12]
        0,                                  # (unused) [13]
        1, 2048, 1024,                      # pc2plFifo: enabled, depth, fill [14–16]
        0,                                  # (unused) [17]
        100_000_000,                        # nb_frequency [18]
    ], dtype=np.uint32)


def _make_response_header_bytes(cmd, status, payload_len=0, cycles=0):
    """Build a 20-byte response header."""
    arr = np.array([cmd.value, status.value, payload_len, 0, cycles], dtype="<u4")
    return arr.tobytes()


def _make_connection():
    """Create a XibifConnection instance with mocked transport, bypassing network."""
    conn = XibifConnection.__new__(XibifConnection)
    conn.ip = "192.168.1.1"
    conn.uuid = 0x42
    conn.timeout = 5.0
    conn.verbose = False
    conn._disable_axi_DEC0DEE3_DEADFA11 = False
    conn._last_response = None
    conn.protocol = XibifProtocol(32)
    conn.transport = MagicMock()
    conn.status = XibifStatus(_make_status_payload())
    return conn


class XibifConnectionInitTests(unittest.TestCase):

    def test_valid_ipv4(self):
        conn = XibifConnection("192.168.1.1", uuid=0xABCD)
        self.assertEqual(conn.ip, "192.168.1.1")
        self.assertEqual(conn.uuid, 0xABCD)

    def test_uuid_stored(self):
        conn = XibifConnection("10.0.0.1", uuid=0xFFFF)
        self.assertEqual(conn.uuid, 0xFFFF)

    def test_invalid_ip_raises_value_error(self):
        with self.assertRaises(ValueError):
            XibifConnection("not-an-ip", uuid=0)

    def test_invalid_ip_non_string_raises(self):
        with self.assertRaises(ValueError):
            XibifConnection("999.999.999.999", uuid=0)

    def test_custom_timeout(self):
        conn = XibifConnection("10.0.0.1", uuid=0, timeout=10.0)
        self.assertEqual(conn.timeout, 10.0)

    def test_default_timeout(self):
        conn = XibifConnection("10.0.0.1", uuid=0)
        self.assertEqual(conn.timeout, 5)

    def test_verbose_flag(self):
        conn = XibifConnection("10.0.0.1", uuid=0, verbose=True)
        self.assertTrue(conn.verbose)


class XibifConnectionConnectTests(unittest.TestCase):

    def test_connect_opens_transport(self):
        conn = _make_connection()
        conn.read_board_status = MagicMock()
        conn._is_compatible = MagicMock(return_value=True)
        conn.connect()
        conn.transport.open.assert_called_once()

    def test_connect_reads_board_status(self):
        conn = _make_connection()
        conn.read_board_status = MagicMock()
        conn._is_compatible = MagicMock(return_value=True)
        conn.connect()
        conn.read_board_status.assert_called_once()

    def test_disconnect_closes_transport(self):
        conn = _make_connection()
        conn.disconnect()
        conn.transport.close.assert_called_once()

    def test_connect_verbose_prints(self):
        conn = _make_connection()
        conn.verbose = True
        conn.read_board_status = MagicMock()
        conn._is_compatible = MagicMock(return_value=True)
        with patch("builtins.print") as mock_print:
            conn.connect()
            mock_print.assert_called()

    def test_disconnect_verbose_prints(self):
        conn = _make_connection()
        conn.verbose = True
        with patch("builtins.print") as mock_print:
            conn.disconnect()
            mock_print.assert_called()


class XibifConnectionSendReceiveTests(unittest.TestCase):

    def _make_conn_real_protocol(self):
        conn = _make_connection()
        conn.protocol = XibifProtocol(32)
        return conn

    def test_receive_response_socket_timeout_raises(self):
        from xibif_connection.exceptions import SocketTimeoutError as XibifSocketTimeoutError

        conn = self._make_conn_real_protocol()
        conn.transport.receive.side_effect = XibifSocketTimeoutError("timeout")
        msg = Message(uuid=conn.uuid, id=Command.STATUS)

        with self.assertRaises(XibifError):
            conn._send_and_receive(msg)

    def test_send_and_receive_ok(self):
        conn = self._make_conn_real_protocol()
        header_bytes = _make_response_header_bytes(Command.STATUS, ResponseStatus.OK, 0, 100)
        conn.transport.receive.return_value = header_bytes
        msg = Message(uuid=conn.uuid, id=Command.STATUS)
        resp = conn._send_and_receive(msg)
        self.assertEqual(resp.status, ResponseStatus.OK)
        conn.transport.send.assert_called_once()

    def test_send_and_receive_unauthorized_raises(self):
        conn = self._make_conn_real_protocol()
        header_bytes = _make_response_header_bytes(Command.STATUS, ResponseStatus.UNAUTHORIZED)
        conn.transport.receive.return_value = header_bytes
        msg = Message(uuid=conn.uuid, id=Command.STATUS)
        with self.assertRaises(XibifResponseError):
            conn._send_and_receive(msg)

    def test_send_and_receive_not_implemented_raises(self):
        conn = self._make_conn_real_protocol()
        header_bytes = _make_response_header_bytes(Command.STATUS, ResponseStatus.COMMAND_NOT_IMPLEMENTED)
        conn.transport.receive.return_value = header_bytes
        msg = Message(uuid=conn.uuid, id=Command.STATUS)
        with self.assertRaises(XibifResponseError):
            conn._send_and_receive(msg)

    def test_send_and_receive_failed_raises(self):
        conn = self._make_conn_real_protocol()
        header_bytes = _make_response_header_bytes(Command.STATUS, ResponseStatus.FAILED)
        conn.transport.receive.return_value = header_bytes
        msg = Message(uuid=conn.uuid, id=Command.STATUS)
        with self.assertRaises(XibifResponseError):
            conn._send_and_receive(msg)

    def test_send_and_receive_invalid_length_raises(self):
        conn = self._make_conn_real_protocol()
        header_bytes = _make_response_header_bytes(Command.STATUS, ResponseStatus.INVALID_LENGTH)
        conn.transport.receive.return_value = header_bytes
        msg = Message(uuid=conn.uuid, id=Command.STATUS)
        with self.assertRaises(XibifResponseError):
            conn._send_and_receive(msg)

    def test_send_and_receive_stores_last_response(self):
        conn = self._make_conn_real_protocol()
        header_bytes = _make_response_header_bytes(Command.STATUS, ResponseStatus.OK)
        conn.transport.receive.return_value = header_bytes
        msg = Message(uuid=conn.uuid, id=Command.STATUS)
        resp = conn._send_and_receive(msg)
        self.assertIs(conn._last_response, resp)

    def test_send_and_receive_with_payload(self):
        conn = self._make_conn_real_protocol()
        payload = np.array([1, 2, 3], dtype="<u4")
        header_bytes = _make_response_header_bytes(Command.STATUS, ResponseStatus.OK, len(payload) * 4)

        def recv_side_effect(length):
            if length == conn.protocol._header_size_bytes:
                return header_bytes
            return payload.tobytes()

        conn.transport.receive.side_effect = recv_side_effect
        msg = Message(uuid=conn.uuid, id=Command.STATUS)
        resp = conn._send_and_receive(msg)
        self.assertEqual(resp.status, ResponseStatus.OK)
        np.testing.assert_array_equal(resp.payload, payload)

    def test_send_and_receive_verbose_prints(self):
        conn = self._make_conn_real_protocol()
        conn.verbose = True
        header_bytes = _make_response_header_bytes(Command.STATUS, ResponseStatus.OK)
        conn.transport.receive.return_value = header_bytes
        msg = Message(uuid=conn.uuid, id=Command.STATUS)
        with patch("builtins.print"):
            resp = conn._send_and_receive(msg)
        self.assertEqual(resp.status, ResponseStatus.OK)


class XibifConnectionReadTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def _mock_ok_response(self, payload):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.READ_REGISTER, status=ResponseStatus.OK, payload=payload, cycles=0,
        ))

    def test_read_single_returns_int(self):
        self._mock_ok_response(np.array([0xFF], dtype=np.uint32))
        result = self.conn.read(0x10)
        self.assertEqual(result, 0xFF)

    def test_read_multiple_returns_list(self):
        self._mock_ok_response(np.array([0x01, 0x02], dtype=np.uint32))
        result = self.conn.read([0x10, 0x14])
        self.assertEqual(result, [0x01, 0x02])

    def test_read_unaligned_address_raises(self):
        with self.assertRaises(XibifError):
            self.conn.read(0x01)

    def test_read_sends_correct_command(self):
        self._mock_ok_response(np.array([0x00], dtype=np.uint32))
        self.conn.read(0x10)
        call_args = self.conn._send_and_receive.call_args[0][0]
        self.assertEqual(call_args.id, Command.READ_REGISTER)

    def test_read_none_payload_raises(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.READ_REGISTER, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        with self.assertRaises(XibifError):
            self.conn.read(0x10)


class XibifConnectionWriteTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.WRITE_REGISTER, status=ResponseStatus.OK, payload=None, cycles=0,
        ))

    def test_write_single_calls_send_and_receive(self):
        self.conn.write(0x10, 0xFF)
        self.conn._send_and_receive.assert_called_once()

    def test_write_sends_correct_command(self):
        self.conn.write(0x10, 0xFF)
        call_args = self.conn._send_and_receive.call_args[0][0]
        self.assertEqual(call_args.id, Command.WRITE_REGISTER)

    def test_write_mismatched_lengths_raises(self):
        with self.assertRaises(ValueError):
            self.conn.write([0x10, 0x14], [0x01])

    def test_write_unaligned_address_raises(self):
        with self.assertRaises(ValueError):
            self.conn.write(0x01, 0xFF)

    def test_write_multiple_registers(self):
        self.conn.write([0x10, 0x14], [0x01, 0x02])
        self.conn._send_and_receive.assert_called_once()


class XibifConnectionStreamTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def test_read_stream_disabled_raises(self):
        self.conn.status.pl2pcFifo.enabled = False
        with self.assertRaises(XibifError):
            self.conn.read_stream(10)

    def test_write_stream_disabled_raises(self):
        self.conn.status.pc2plFifo.enabled = False
        with self.assertRaises(XibifError):
            self.conn.write_stream(np.array([1, 2, 3], dtype=np.uint32))

    def test_read_stream_returns_none_on_no_payload(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.READ_STREAM, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        result = self.conn.read_stream(10)
        self.assertIsNone(result)

    def test_read_stream_returns_data_as_list(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.READ_STREAM, status=ResponseStatus.OK,
            payload=np.array([1, 2, 3], dtype=np.uint32), cycles=0,
        ))
        result = self.conn.read_stream(3)
        self.assertEqual(result, [1, 2, 3])

    def test_read_stream_all(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.READ_STREAM_ALL, status=ResponseStatus.OK,
            payload=np.array([10, 20], dtype=np.uint32), cycles=0,
        ))
        result = self.conn.read_stream(None)
        self.assertEqual(result, [10, 20])
        call_args = self.conn._send_and_receive.call_args[0][0]
        self.assertEqual(call_args.id, Command.READ_STREAM_ALL)

    def test_write_stream_calls_send_and_receive(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.WRITE_STREAM, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        self.conn.write_stream(np.array([1, 2, 3], dtype=np.uint32))
        self.conn._send_and_receive.assert_called_once()


class XibifConnectionStatusTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def test_read_board_status_returns_status(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.STATUS, status=ResponseStatus.OK,
            payload=_make_status_payload(), cycles=0,
        ))
        status = self.conn.read_board_status()
        self.assertIsNotNone(status)

    def test_read_board_status_updates_register_width(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.STATUS, status=ResponseStatus.OK,
            payload=_make_status_payload(), cycles=0,
        ))
        self.conn.read_board_status()
        self.assertEqual(self.conn.protocol._register_width, 32)

    def test_read_board_status_none_payload_raises(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.STATUS, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        with self.assertRaises(XibifError):
            self.conn.read_board_status()

    def test_flush_stream_sends_correct_command(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.FLUSH_STREAM, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        self.conn.flush_stream()
        call_args = self.conn._send_and_receive.call_args[0][0]
        self.assertEqual(call_args.id, Command.FLUSH_STREAM)

    def test_reset_sends_correct_command(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.RESET, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        self.conn.reset()
        call_args = self.conn._send_and_receive.call_args[0][0]
        self.assertEqual(call_args.id, Command.RESET)

    def test_print_status_uart_sends_correct_command(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.UART_PRINT_STATUS, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        self.conn.print_status_uart()
        call_args = self.conn._send_and_receive.call_args[0][0]
        self.assertEqual(call_args.id, Command.UART_PRINT_STATUS)


class XibifConnectionHelperTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def test_listify_int(self):
        result = self.conn._listify(42)
        np.testing.assert_array_equal(result, [42])

    def test_listify_list(self):
        result = self.conn._listify([1, 2, 3])
        np.testing.assert_array_equal(result, [1, 2, 3])

    def test_check_address_alignment_aligned(self):
        self.assertTrue(self.conn._check_address_alignment(0x10))
        self.assertTrue(self.conn._check_address_alignment([0x10, 0x14]))

    def test_check_address_alignment_unaligned(self):
        self.assertFalse(self.conn._check_address_alignment(0x01))
        self.assertFalse(self.conn._check_address_alignment([0x10, 0x11]))

    def test_display_progress_update_none_pbar_prints(self):
        with patch("builtins.print") as mock_print:
            self.conn._display_progress_update(None, "step 1")
            mock_print.assert_called_once_with("step 1")

    def test_display_progress_update_with_pbar(self):
        mock_pbar = MagicMock()
        self.conn._display_progress_update(mock_pbar, "step 1", inc=2)
        mock_pbar.update.assert_called_once_with(2)


class XibifConnectionAxiCheckTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def test_check_axi_response_all_ok(self):
        response = np.array([
            AxiAccessStatus.AXI_ACCESS_OK.value,
            AxiAccessStatus.AXI_ACCESS_OK.value,
        ], dtype=np.uint32)
        # Should not raise
        self.conn._check_axi_response(response)

    def test_check_axi_response_error_raises(self):
        response = np.array([AxiAccessStatus.AXI_FIREWALL_ERROR.value], dtype=np.uint32)
        with self.assertRaises(XibifError):
            self.conn._check_axi_response(response)

    def test_check_axi_response_deadface_error_raises_by_default(self):
        response = np.array([AxiAccessStatus.AXI_FIREWALL_DATA_DEC0DEE3_DEADFA11.value], dtype=np.uint32)
        with self.assertRaises(XibifError):
            self.conn._check_axi_response(response)

    def test_check_axi_response_deadface_ok_when_disabled(self):
        self.conn._disable_axi_DEC0DEE3_DEADFA11 = True
        response = np.array([AxiAccessStatus.AXI_FIREWALL_DATA_DEC0DEE3_DEADFA11.value], dtype=np.uint32)
        # Should not raise when the check is disabled
        self.conn._check_axi_response(response)


class XibifConnectionReadWriteErrorPaths(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def test_read_non_ok_status_raises(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.READ_REGISTER, status=ResponseStatus.FAILED,
            payload=np.array([0], dtype=np.uint32), cycles=0,
        ))
        with self.assertRaises(XibifError):
            self.conn.read(0x10)

    def test_write_non_ok_status_raises(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.WRITE_REGISTER, status=ResponseStatus.FAILED, payload=None, cycles=0,
        ))
        with self.assertRaises(XibifError):
            self.conn.write(0x10, 0xFF)

    def test_read_stream_non_ok_status_raises(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.READ_STREAM, status=ResponseStatus.FAILED, payload=None, cycles=0,
        ))
        with self.assertRaises(XibifError):
            self.conn.read_stream(10)


class XibifConnectionUartDebugTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.UART_ENABLE_DBG_OUTPUT, status=ResponseStatus.OK, payload=None, cycles=0,
        ))

    def test_set_uart_debug_enable(self):
        self.conn.set_uart_debug(True)
        call_args = self.conn._send_and_receive.call_args[0][0]
        self.assertEqual(call_args.id, Command.UART_ENABLE_DBG_OUTPUT)
        np.testing.assert_array_equal(call_args.payload, [1])

    def test_set_uart_debug_disable(self):
        self.conn.set_uart_debug(False)
        call_args = self.conn._send_and_receive.call_args[0][0]
        np.testing.assert_array_equal(call_args.payload, [0])


class XibifConnectionWriteBitstreamTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def test_bitstream_not_available_raises(self):
        self.conn.status.bistreamAvailable = False
        with self.assertRaises(XibifError):
            self.conn.write_bitstream("/nonexistent/path.bit")

    def test_path_not_exist_raises(self):
        self.conn.status.bistreamAvailable = True
        with self.assertRaises(XibifError):
            self.conn.write_bitstream("/nonexistent/path.bit")

    def test_write_bitstream_success(self):
        self.conn.status.bistreamAvailable = True
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.WRITE_BITSTREAM, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        with tempfile.NamedTemporaryFile(suffix=".bit", delete=False) as f:
            data = np.array([0x01, 0x02, 0x03], dtype=np.uint32)
            data.tofile(f)
            tmp_path = f.name
        try:
            self.conn.write_bitstream(tmp_path)
            self.conn._send_and_receive.assert_called_once()
            call_args = self.conn._send_and_receive.call_args[0][0]
            self.assertEqual(call_args.id, Command.WRITE_BITSTREAM)
        finally:
            os.unlink(tmp_path)

    def test_write_bitstream_verbose(self):
        self.conn.status.bistreamAvailable = True
        self.conn.verbose = True
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.WRITE_BITSTREAM, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        with tempfile.NamedTemporaryFile(suffix=".bit", delete=False) as f:
            np.array([0x01], dtype=np.uint32).tofile(f)
            tmp_path = f.name
        try:
            with patch("builtins.print") as mock_print:
                self.conn.write_bitstream(tmp_path)
                mock_print.assert_called()
        finally:
            os.unlink(tmp_path)


class XibifConnectionReadRegisterMapTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def test_read_registermap_success(self):
        reg_map = {"registers": [{"name": "TEST", "address": "0x00"}]}
        json_bytes = json.dumps(reg_map).encode("utf-8")
        # Pad to uint32 alignment
        while len(json_bytes) % 4 != 0:
            json_bytes += b"\x00"
        payload = np.frombuffer(json_bytes, dtype=np.uint32)
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.READ_REGISTER_MAP, status=ResponseStatus.OK, payload=payload, cycles=0,
        ))
        result = self.conn.read_registermap()
        self.assertEqual(result["registers"][0]["name"], "TEST")

    def test_read_registermap_none_payload_raises(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.READ_REGISTER_MAP, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        with self.assertRaises(XibifError):
            self.conn.read_registermap()


class XibifConnectionAxiReadWriteTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def _ok_axi_write_response(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.AXI_WRITE, status=ResponseStatus.OK,
            payload=np.array([AxiAccessStatus.AXI_ACCESS_OK.value], dtype=np.uint32),
            cycles=0,
        ))

    def test_write_axi_single_address(self):
        self._ok_axi_write_response()
        self.conn.write_axi(0x40000000, 0xDEAD)
        self.conn._send_and_receive.assert_called_once()
        call_args = self.conn._send_and_receive.call_args[0][0]
        self.assertEqual(call_args.id, Command.AXI_WRITE)

    def test_write_axi_none_payload_raises(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.AXI_WRITE, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        with self.assertRaises(XibifError):
            self.conn.write_axi(0x40000000, 0xDEAD)

    def test_write_axi_multiple_addresses_wrong_count_raises(self):
        self._ok_axi_write_response()
        with self.assertRaises(XibifError):
            self.conn.write_axi([0x40000000, 0x40000004], [0x01, 0x02, 0x03])

    def test_write_axi_multiple_masks_wrong_count_raises(self):
        self._ok_axi_write_response()
        with self.assertRaises(XibifError):
            self.conn.write_axi(0x40000000, [0x01, 0x02], mask=[0xFF, 0xFF, 0xFF])

    def test_write_axi_axi_error_raises(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.AXI_WRITE, status=ResponseStatus.OK,
            payload=np.array([AxiAccessStatus.AXI_FIREWALL_ERROR.value], dtype=np.uint32),
            cycles=0,
        ))
        with self.assertRaises(XibifError):
            self.conn.write_axi(0x40000000, 0xDEAD)

    def test_read_axi_single_address_returns_int(self):
        # Response: [data0, status0]
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.AXI_READ, status=ResponseStatus.OK,
            payload=np.array([0xBEEF, AxiAccessStatus.AXI_ACCESS_OK.value], dtype=np.uint32),
            cycles=0,
        ))
        result = self.conn.read_axi(0x40000000)
        self.assertEqual(result, 0xBEEF)

    def test_read_axi_none_payload_raises(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.AXI_READ, status=ResponseStatus.OK, payload=None, cycles=0,
        ))
        with self.assertRaises(XibifError):
            self.conn.read_axi(0x40000000)

    def test_read_axi_multiple_addresses_with_length_raises(self):
        with self.assertRaises(XibifError):
            self.conn.read_axi([0x40000000, 0x40000004], length=2)

    def test_read_axi_multiple_addresses_returns_array(self):
        self.conn._send_and_receive = MagicMock(return_value=Response(
            id=Command.AXI_READ, status=ResponseStatus.OK,
            payload=np.array([
                0xDEAD, AxiAccessStatus.AXI_ACCESS_OK.value,
                0xBEEF, AxiAccessStatus.AXI_ACCESS_OK.value,
            ], dtype=np.uint32),
            cycles=0,
        ))
        # Pass multiple addresses explicitly with length=1 (the valid combination)
        result = self.conn.read_axi([0x40000000, 0x40000004], length=1)
        self.assertEqual(len(result), 2)


class XibifConnectionPingTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def test_ping_success_with_mocked_transport(self):
        mock_transport = MagicMock()
        mock_transport.receive.return_value = b"PING"
        rtt = self.conn.ping(payload=b"PING", transport=mock_transport)
        self.assertGreaterEqual(rtt, 0.0)
        mock_transport.open.assert_called_once()
        mock_transport.send.assert_called_once_with(b"PING")
        mock_transport.close.assert_called_once()

    def test_ping_payload_mismatch_raises(self):
        mock_transport = MagicMock()
        mock_transport.receive.return_value = b"PONG"
        with self.assertRaises(XibifError):
            self.conn.ping(payload=b"PING", transport=mock_transport)

    def test_ping_numpy_payload(self):
        mock_transport = MagicMock()
        payload = np.array([0x50, 0x49, 0x4E, 0x47], dtype=np.uint8)  # "PING"
        mock_transport.receive.return_value = payload.tobytes()
        rtt = self.conn.ping(payload=payload, transport=mock_transport)
        self.assertGreaterEqual(rtt, 0.0)


if __name__ == "__main__":
    unittest.main()
class XibifConnectionVerboseTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()
        self.conn.verbose = True

    def _setup_transport_response(self, cmd, status, payload=None):
        """Configure transport mock to return a valid response."""
        import io
        if payload is None:
            payload = np.array([], dtype=np.uint32)
        header = np.array(
            [cmd.value, status.value, len(payload) * 4, 0, 0], dtype="<u4"
        )
        self.conn.transport.receive.side_effect = [
            header.tobytes(),
            payload.tobytes(),
        ]

    def test_send_and_receive_verbose_prints_response(self):
        # verbose=True triggers print(resp) after a successful response
        self._setup_transport_response(
            Command.READ_REGISTER, ResponseStatus.OK,
            payload=np.array([0xAB], dtype=np.uint32),
        )
        msg = Message(id=Command.READ_REGISTER, uuid=self.conn.uuid, payload=np.array([0], dtype=np.uint32))
        with patch("builtins.print") as mock_print:
            self.conn._send_and_receive(msg)
            mock_print.assert_called()

    def test_receive_response_verbose_prints_debug(self):
        # verbose=True triggers 2 debug print statements in _receive_response
        self._setup_transport_response(
            Command.READ_REGISTER, ResponseStatus.OK,
            payload=np.array([0xBC], dtype=np.uint32),
        )
        with patch("builtins.print") as mock_print:
            self.conn._receive_response()
            # At least 2 prints: "Receiving … bytes" and "Command took …"
            self.assertGreaterEqual(mock_print.call_count, 2)


class XibifConnectionPingRetryTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def test_ping_list_payload(self):
        mock_transport = MagicMock()
        # [0x50, 0x49, 0x4E, 0x47] → "PING"
        mock_transport.receive.return_value = bytes([0x50, 0x49, 0x4E, 0x47])
        rtt = self.conn.ping(payload=[0x50, 0x49, 0x4E, 0x47], transport=mock_transport)
        self.assertGreaterEqual(rtt, 0.0)


class XibifConnectionBenchmarkCommandTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()
        # Mock underlying commands so no real network call happens
        self.conn.read = MagicMock()
        self.conn.write = MagicMock()
        self.conn.read_board_status = MagicMock()
        self.conn._last_response = MagicMock(cycles=1000)
        # status.nb_frequency must be readable
        self.conn.status = MagicMock()
        self.conn.status.nb_frequency = 100_000_000
        self.conn._get_pbar = MagicMock(return_value=None)
        self.conn._display_progress_update = MagicMock()

    def test_benchmark_command_read_register(self):
        times = self.conn.benchmark_command(Command.READ_REGISTER, repeats=2)
        self.assertEqual(len(times), 2)
        self.conn.read.assert_called()

    def test_benchmark_command_write_register(self):
        times = self.conn.benchmark_command(Command.WRITE_REGISTER, repeats=2)
        self.assertEqual(len(times), 2)
        self.conn.write.assert_called()

    def test_benchmark_command_status(self):
        times = self.conn.benchmark_command(Command.STATUS, repeats=1)
        self.assertEqual(len(times), 1)
        self.conn.read_board_status.assert_called()

    def test_benchmark_command_unknown_raises(self):
        with self.assertRaises(XibifError):
            self.conn.benchmark_command(Command.AXI_READ, repeats=1)


class XibifConnectionBenchmarkPingTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()
        self.conn.ping = MagicMock(return_value=0.001)
        self.conn._get_pbar = MagicMock(return_value=None)
        self.conn._display_progress_update = MagicMock()

    def test_benchmark_ping_returns_array(self):
        with patch("xibif_connection.api.connection.TcpTransport"):
            with patch("time.sleep"):
                result = self.conn.benchmark_ping(repeats=3, wait_time=0.0)
        self.assertEqual(len(result), 3)
        np.testing.assert_array_almost_equal(result, [0.001, 0.001, 0.001])


class XibifConnectionPingEdgeTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()

    def test_ping_uses_default_transport_when_none_given(self):
        mock_transport = MagicMock()
        mock_transport.receive.return_value = b"PING"
        with patch("xibif_connection.api.connection.TcpTransport", return_value=mock_transport) as mock_transport_cls:
            rtt = self.conn.ping(payload=b"PING", timeout=1.0)
        self.assertGreaterEqual(rtt, 0.0)
        mock_transport_cls.assert_called_once_with(self.conn.ip, self.conn.PORT_ECHO, 1.0)

    def test_ping_rejects_unsupported_payload_type(self):
        mock_transport = MagicMock()
        with self.assertRaises(XibifError):
            self.conn.ping(payload=object(), transport=mock_transport)


class XibifConnectionBenchmarkStreamTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()
        self.conn.write_stream = MagicMock()
        self.conn.read_stream = MagicMock(return_value=np.array([1], dtype=np.uint32))
        self.conn.flush_stream = MagicMock()
        self.conn.read_board_status = MagicMock()
        self.conn.status = MagicMock()
        self.conn.status.pl2pcFifo.fill = 2
        self.conn.status.nb_frequency = 100_000_000
        self.conn._get_pbar = MagicMock(return_value=MagicMock())
        self.conn._display_progress_update = MagicMock()

    def test_benchmark_stream_write_flushes_and_returns_mean(self):
        with patch("xibif_connection.api.connection.np.random.randint", return_value=np.array([1, 2], dtype=np.uint32)):
            with patch("xibif_connection.api.connection.time.monotonic_ns", side_effect=[0, 1_000_000_000]):
                result = self.conn.benchmark_stream_write(8, repeats=1, quiet=True)
        self.assertEqual(result, 1.0)
        self.conn.write_stream.assert_called_once()
        self.conn.flush_stream.assert_called_once()

    def test_benchmark_stream_write_skip_flush(self):
        with patch("xibif_connection.api.connection.np.random.randint", return_value=np.array([1, 2], dtype=np.uint32)):
            with patch("xibif_connection.api.connection.time.monotonic_ns", side_effect=[0, 500_000_000]):
                result = self.conn.benchmark_stream_write(8, repeats=1, quiet=True, skip_flush=True)
        self.assertEqual(result, 0.5)
        self.conn.flush_stream.assert_not_called()

    def test_benchmark_stream_read_rejects_illegal_skip_write_combination(self):
        with self.assertRaises(ValueError):
            self.conn.benchmark_stream_read(8, repeats=2, skip_write=True, quiet=True)

    def test_benchmark_stream_read_requires_n_bytes_when_writing(self):
        with self.assertRaises(ValueError):
            self.conn.benchmark_stream_read(None, repeats=1, skip_write=False, quiet=True)

    def test_benchmark_stream_read_raises_on_missing_rx(self):
        self.conn.read_stream.return_value = None
        with self.assertRaises(RuntimeError):
            self.conn.benchmark_stream_read(8, repeats=1, skip_write=True, quiet=True)

    def test_benchmark_stream_read_success(self):
        with patch("xibif_connection.api.connection.time.monotonic_ns", side_effect=[0, 250_000_000]):
            result = self.conn.benchmark_stream_read(8, repeats=1, skip_write=True, quiet=True)
        self.assertEqual(result, 0.25)
        self.conn.read_stream.assert_called_once_with(2)

    def test_benchmark_stream_success(self):
        pbar = MagicMock()
        self.conn._get_pbar.return_value = pbar
        self.conn.benchmark_stream_write = MagicMock(side_effect=[1.0, 2.0])
        self.conn.benchmark_stream_read = MagicMock(side_effect=[0.5, 1.0])
        amounts, speeds_tx, speeds_rx = self.conn.benchmark_stream([8, 16], repeats=1)
        np.testing.assert_array_equal(amounts, np.array([8, 16]))
        np.testing.assert_array_almost_equal(speeds_tx, np.array([64.0 / 1.0, 128.0 / 2.0]))
        np.testing.assert_array_almost_equal(speeds_rx, np.array([64.0 / 0.5, 128.0 / 1.0]))
        self.assertEqual(self.conn.flush_stream.call_count, 2)
        pbar.close.assert_called_once()


class XibifConnectionBenchmarkMemoryTests(unittest.TestCase):

    def setUp(self):
        self.conn = _make_connection()
        self.conn.status = MagicMock()
        self.conn.status.nb_frequency = 100_000_000
        self.conn._get_pbar = MagicMock(return_value=None)
        self.conn._display_progress_update = MagicMock()
        self.conn.read_board_status = MagicMock()

    def test_benchmark_memory_access_rejects_missing_payload(self):
        self.conn._send_and_receive = MagicMock(
            return_value=Response(Command.PERFORMANCE_TEST, ResponseStatus.OK, None, 0)
        )
        with self.assertRaises(XibifResponseError):
            self.conn.benchmark_memory_access([10], repeat=1)

    def test_benchmark_memory_access_rejects_wrong_payload_length(self):
        payload = np.array([1, 2], dtype=np.uint32)
        self.conn._send_and_receive = MagicMock(
            return_value=Response(Command.PERFORMANCE_TEST, ResponseStatus.OK, payload, 0)
        )
        with self.assertRaises(XibifResponseError):
            self.conn.benchmark_memory_access([10], repeat=1)

    def test_benchmark_memory_access_success(self):
        payload = np.array([8, 0, 16, 0, 24, 0, 32, 0], dtype=np.uint32)
        self.conn._send_and_receive = MagicMock(
            return_value=Response(Command.PERFORMANCE_TEST, ResponseStatus.OK, payload, 0)
        )
        cycles, user_times, stream_times, ddr_write_times, ddr_read_times = self.conn.benchmark_memory_access([10], repeat=1)
        np.testing.assert_array_equal(cycles, np.array([10]))
        self.assertEqual(len(user_times), 1)
        self.assertEqual(len(stream_times), 1)
        self.assertEqual(len(ddr_write_times), 1)
        self.assertEqual(len(ddr_read_times), 1)


if __name__ == "__main__":
    unittest.main()
