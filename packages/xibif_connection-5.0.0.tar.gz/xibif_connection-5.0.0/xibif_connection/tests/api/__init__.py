"""Tests for xibif_connection.api."""
