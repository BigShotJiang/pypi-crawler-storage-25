"""Tests for XibifSession."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest
from unittest.mock import MagicMock

from xibif_connection.api.session import XibifSession


def _make_session():
    """Create a XibifSession with mocked connect/disconnect."""
    session = XibifSession.__new__(XibifSession)
    session.connect = MagicMock()
    session.disconnect = MagicMock()
    return session


class XibifSessionEnterTests(unittest.TestCase):

    def test_enter_calls_connect(self):
        session = _make_session()
        session.__enter__()
        session.connect.assert_called_once()

    def test_enter_returns_self(self):
        session = _make_session()
        result = session.__enter__()
        self.assertIs(result, session)

    def test_enter_returns_xibif_connection_type(self):
        session = _make_session()
        result = session.__enter__()
        self.assertIsInstance(result, XibifSession)


class XibifSessionExitTests(unittest.TestCase):

    def test_exit_calls_disconnect(self):
        session = _make_session()
        session.__exit__(None, None, None)
        session.disconnect.assert_called_once()

    def test_exit_calls_disconnect_with_exception(self):
        session = _make_session()
        session.__exit__(RuntimeError, RuntimeError("boom"), None)
        session.disconnect.assert_called_once()


class XibifSessionContextManagerTests(unittest.TestCase):

    def test_context_manager_calls_connect_and_disconnect(self):
        session = _make_session()
        with session:
            session.connect.assert_called_once()
        session.disconnect.assert_called_once()

    def test_context_manager_returns_self(self):
        session = _make_session()
        with session as s:
            self.assertIs(s, session)

    def test_context_manager_disconnect_on_exception(self):
        session = _make_session()
        try:
            with session:
                raise RuntimeError("something went wrong")
        except RuntimeError:
            pass
        session.disconnect.assert_called_once()

    def test_context_manager_propagates_exception(self):
        session = _make_session()
        with self.assertRaises(ValueError):
            with session:
                raise ValueError("propagated")


if __name__ == "__main__":
    unittest.main()
