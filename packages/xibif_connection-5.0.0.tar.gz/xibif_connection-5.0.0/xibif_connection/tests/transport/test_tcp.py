"""Tests for TcpTransport."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import socket
import unittest
from unittest.mock import MagicMock, patch
import os

from xibif_connection.exceptions import SocketClosedError, SocketConnectionError, SocketTimeoutError
from xibif_connection.transport.tcp import TcpTransport


class TcpTransportInitTests(unittest.TestCase):

    def test_stores_ip_and_port(self):
        t = TcpTransport("192.168.1.1", 6, timeout=3.0)
        self.assertEqual(t.ip, "192.168.1.1")
        self.assertEqual(t.port, 6)

    def test_stores_custom_timeout(self):
        t = TcpTransport("10.0.0.1", 80, timeout=3.0)
        self.assertEqual(t.timeout, 3.0)

    def test_default_timeout(self):
        t = TcpTransport("10.0.0.1", 80)
        self.assertEqual(t.timeout, 5.0)

    def test_socket_initially_none(self):
        t = TcpTransport("10.0.0.1", 80)
        self.assertIsNone(t.socket)

    def test_none_timeout_uses_class_default(self):
        t = TcpTransport("10.0.0.1", 80, timeout=None)
        self.assertEqual(t.timeout, 5.0)  # class default, since None is falsy


class TcpTransportOpenTests(unittest.TestCase):

    @patch("xibif_connection.transport.tcp.socket.socket")
    def test_open_creates_tcp_socket(self, mock_socket_class):
        mock_sock = MagicMock()
        mock_socket_class.return_value = mock_sock
        t = TcpTransport("192.168.1.1", 6)
        t.open()
        mock_socket_class.assert_called_once_with(socket.AF_INET, socket.SOCK_STREAM)

    @patch("xibif_connection.transport.tcp.socket.socket")
    def test_open_connects_to_host_and_port(self, mock_socket_class):
        mock_sock = MagicMock()
        mock_socket_class.return_value = mock_sock
        t = TcpTransport("192.168.1.1", 6)
        t.open()
        mock_sock.connect.assert_called_once_with(("192.168.1.1", 6))

    @patch("xibif_connection.transport.tcp.socket.socket")
    def test_open_stores_socket(self, mock_socket_class):
        mock_sock = MagicMock()
        mock_socket_class.return_value = mock_sock
        t = TcpTransport("192.168.1.1", 6)
        t.open()
        self.assertEqual(t.socket, mock_sock)

    @patch("xibif_connection.transport.tcp.socket.socket")
    def test_open_sets_tcp_nodelay(self, mock_socket_class):
        mock_sock = MagicMock()
        mock_socket_class.return_value = mock_sock
        t = TcpTransport("192.168.1.1", 6)
        t.open()
        mock_sock.setsockopt.assert_any_call(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

    @patch("xibif_connection.transport.tcp.socket.socket")
    def test_open_sets_timeout(self, mock_socket_class):
        mock_sock = MagicMock()
        mock_socket_class.return_value = mock_sock
        t = TcpTransport("192.168.1.1", 6, timeout=7.0)
        t.open()
        mock_sock.settimeout.assert_called_once_with(7.0)

    @patch("xibif_connection.transport.tcp.socket.socket")
    def test_open_closes_existing_socket_first(self, mock_socket_class):
        mock_sock = MagicMock()
        mock_socket_class.return_value = mock_sock
        t = TcpTransport("192.168.1.1", 6)
        old_sock = MagicMock()
        t.socket = old_sock
        t.open()
        old_sock.close.assert_called_once()

    @patch("xibif_connection.transport.tcp.socket.socket")
    def test_open_raises_socket_connection_error_on_failure(self, mock_socket_class):
        mock_sock = MagicMock()
        mock_sock.connect.side_effect = OSError("Connection refused")
        mock_socket_class.return_value = mock_sock
        t = TcpTransport("192.168.1.1", 6)
        with self.assertRaises(SocketConnectionError):
            t.open()


class TcpTransportCloseTests(unittest.TestCase):

    def test_close_calls_socket_close(self):
        t = TcpTransport("192.168.1.1", 6)
        mock_sock = MagicMock()
        t.socket = mock_sock
        t.close()
        mock_sock.close.assert_called_once()

    def test_close_sets_socket_to_none(self):
        t = TcpTransport("192.168.1.1", 6)
        t.socket = MagicMock()
        t.close()
        self.assertIsNone(t.socket)

    def test_close_without_socket_raises(self):
        t = TcpTransport("192.168.1.1", 6)
        with self.assertRaises(SocketClosedError):
            t.close()


class TcpTransportSendTests(unittest.TestCase):

    def test_send_calls_socket_send(self):
        t = TcpTransport("192.168.1.1", 6)
        mock_sock = MagicMock()
        t.socket = mock_sock
        t.send(b"\x01\x02\x03")
        mock_sock.send.assert_called_once_with(b"\x01\x02\x03")

    def test_send_without_socket_raises(self):
        t = TcpTransport("192.168.1.1", 6)
        with self.assertRaises(SocketClosedError):
            t.send(b"\x00")

    def test_send_memoryview(self):
        t = TcpTransport("192.168.1.1", 6)
        mock_sock = MagicMock()
        t.socket = mock_sock
        data = memoryview(b"\xDE\xAD\xBE\xEF")
        t.send(data)
        mock_sock.send.assert_called_once_with(data)


class TcpTransportReceiveTests(unittest.TestCase):

    def test_receive_single_chunk(self):
        t = TcpTransport("192.168.1.1", 6)
        mock_sock = MagicMock()
        mock_sock.recv.return_value = b"\x01\x02\x03\x04"
        t.socket = mock_sock
        result = t.receive(4)
        self.assertEqual(result, b"\x01\x02\x03\x04")

    def test_receive_assembles_multiple_chunks(self):
        t = TcpTransport("192.168.1.1", 6)
        mock_sock = MagicMock()
        mock_sock.recv.side_effect = [b"\x01\x02", b"\x03\x04"]
        t.socket = mock_sock
        result = t.receive(4)
        self.assertEqual(result, b"\x01\x02\x03\x04")

    def test_receive_without_socket_raises(self):
        t = TcpTransport("192.168.1.1", 6)
        with self.assertRaises(SocketClosedError):
            t.receive(4)

    def test_receive_empty_chunk_raises_closed(self):
        t = TcpTransport("192.168.1.1", 6)
        mock_sock = MagicMock()
        mock_sock.recv.return_value = b""
        t.socket = mock_sock
        with self.assertRaises(SocketClosedError):
            t.receive(4)

    def test_receive_socket_exception_raises_timeout(self):
        t = TcpTransport("192.168.1.1", 6)
        mock_sock = MagicMock()
        mock_sock.recv.side_effect = OSError("timed out")
        t.socket = mock_sock
        with self.assertRaises(SocketTimeoutError):
            t.receive(4)


if __name__ == "__main__":
    unittest.main()


class TcpTransportSocketOptTests(unittest.TestCase):

    def test_socket_sec2opt_windows(self):
        with patch.object(__import__("os"), "name", "nt"):
            t = TcpTransport("192.168.1.1", 6)
            result = t._socket_sec2opt(2.5)
        self.assertEqual(result, 2500)  # 2.5 seconds * 1000

    def test_socket_sec2opt_posix(self):
        with patch("xibif_connection.transport.tcp.os.name", "posix"):
            t = TcpTransport("192.168.1.1", 6)
            result = t._socket_sec2opt(1.5)
        import struct
        expected = struct.pack("ll", 1, 500000)
        self.assertEqual(result, expected)

    def test_socket_sec2opt_zero_raises(self):
        t = TcpTransport("192.168.1.1", 6)
        with self.assertRaises(ValueError):
            t._socket_sec2opt(0)

    def test_socket_sec2opt_negative_raises(self):
        t = TcpTransport("192.168.1.1", 6)
        with self.assertRaises(ValueError):
            t._socket_sec2opt(-1.0)


class TcpTransportIsConnectedTests(unittest.TestCase):

    def test_is_connected_false_when_no_socket(self):
        t = TcpTransport("192.168.1.1", 6)
        self.assertFalse(t.isConnected)

    def test_is_connected_true_when_socket_set(self):
        t = TcpTransport("192.168.1.1", 6)
        t.socket = MagicMock()
        self.assertTrue(t.isConnected)
