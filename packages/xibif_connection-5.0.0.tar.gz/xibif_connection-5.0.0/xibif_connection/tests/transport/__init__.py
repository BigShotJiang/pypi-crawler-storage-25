"""Tests for xibif_connection.transport."""
