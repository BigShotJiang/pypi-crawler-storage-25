"""Tests for xibif_connection."""
