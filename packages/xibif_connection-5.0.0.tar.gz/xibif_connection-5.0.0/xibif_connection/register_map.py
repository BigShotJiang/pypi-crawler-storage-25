"""
xibif_connection.register_map

Utilities to load a JSON register map and provide:
- case-insensitive name resolution for registers and fields
- bitfield masking / shifting helpers
- reading a field from a register value
- composing register write values for single-field updates
- storage of current register values (initialized to None)

Expected JSON format (flexible). Example input accepted by `from_json_map`:
{
  "registers": [
    {
      "name": "VERSION",
      "address": "0x00",
      "fields": [
        {"name": "rev", "lsb": 0, "width": 8},
        {"name": "patch", "lsb": 8, "width": 8},
        {"name": "min", "lsb": 16, "width": 8},
        {"name": "maj", "lsb": 24, "width": 8}
      ]
    },
    {
      "name": "UUID",
      "address": 4,
      "fields": [{"name": "uuid", "lsb": 0, "width": 32}]
    }
  ]
}

This module is defensive: it validates inputs, supports integer or hex-string addresses,
supports fields defined with (lsb, msb) or (lsb, width), and performs case-insensitive lookups.

Example usage:
```/dev/null/usage_example.py#L1-24
from xibif_connection.register_map import RegisterMap

json_map = {
    "registers": [
        {"name": "VERSION", "address": "0x00", "fields": [
            {"name": "rev", "lsb": 0, "width": 8},
            {"name": "patch", "lsb": 8, "width": 8},
            {"name": "min", "lsb": 16, "width": 8},
            {"name": "maj", "lsb": 24, "width": 8},
        ]},
        {"name": "UUID", "address": 4, "fields": [{"name": "uuid", "lsb": 0, "width": 32}]}
    ]
}
rm = RegisterMap.from_json_map(json_map)
# set full register (optional)
rm.set_register_value("VERSION", 0x04050336)  # maj=4, min=5, patch=3, rev=54
# read a field
maj = rm.get_register_value("version.maj")
print("MAJ:", maj)
# update only a field
rm.set_register_value("version.rev", 0x12)
print("VERSION full:", hex(rm.get_register_value("version")))
```
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

# Public API:
# - RegisterMap.from_json_map(json_map: dict) -> RegisterMap
# - RegisterMap.resolve(name: str) -> (register_name, address, Optional[Field])
# - RegisterMap.read_field_from_register(register_name, register_value, field_name) -> int
# - RegisterMap.compose_register_write(register_name, field_name, field_value, current_value) -> int
# - RegisterMap.get_register_value(name), RegisterMap.set_register_value(name, value)


@dataclass(frozen=True)
class Field:
    """
    Represents a bitfield inside a register.

    Attributes:
    - name: canonical field name (case preserved)
    - lsb: least-significant bit index (0-based)
    - msb: most-significant bit index (0-based)
    """

    name: str
    lsb: int
    msb: int

    def __post_init__(self) -> None:
        # normalize msb to lsb if not provided
        if self.msb is None:
            object.__setattr__(self, "msb", self.lsb)
        if not (isinstance(self.lsb, int) and isinstance(self.msb, int)):
            raise TypeError("Field lsb/msb must be integers")
        if self.lsb < 0 or self.msb < self.lsb:
            raise ValueError(
                f"Invalid lsb/msb for field {self.name}: lsb={self.lsb}, msb={self.msb}"
            )

    @property
    def width(self) -> int:
        """
        Width of a Field

        Returns the width of a register field by evaluating
        its msb and lsb properties.
        """
        return self.msb - self.lsb + 1

    @property
    def mask(self) -> int:
        """Unshifted mask for the field (e.g. width=3 -> 0b111)."""
        return (1 << self.width) - 1

    @property
    def shifted_mask(self) -> int:
        """Mask shifted to the field position within the register."""
        return self.mask << self.lsb

    def extract(self, register_value: int) -> int:
        """Extract the field value from a full register value."""
        if not isinstance(register_value, int):
            raise TypeError("register_value must be int")
        return (register_value >> self.lsb) & self.mask

    def insert_into(self, current_register_value: int, field_value: int) -> int:
        """
        Return a new register value with this field set to field_value,
        preserving other bits from current_register_value.
        """
        if not isinstance(current_register_value, int):
            raise TypeError("current_register_value must be int")
        if not isinstance(field_value, int):
            raise TypeError("field_value must be int")
        if field_value < 0:
            raise ValueError("field_value must be non-negative")
        if field_value > self.mask:
            raise ValueError(
                f"field_value 0x{field_value:X} overflows field '{self.name}' width {self.width}"
            )
        cleared = current_register_value & (~self.shifted_mask)
        inserted = cleared | ((field_value & self.mask) << self.lsb)
        return inserted


@dataclass
class Register:
    """
    Represents a register.

    Attributes:
    - name: canonical register name (case preserved)
    - address: integer address
    - fields: mapping lowercased field name -> Field
    """

    name: str
    address: int
    fields: dict[str, Field]

    def get_field(self, field_name: str | None) -> Field | None:
        """
        Get register field by name (case-insensitive)

        Searches for a register field a name. If a field
        with the given name is found, it is returned.
        If no field with a matching name is found, None is returned.
        """
        if field_name is None:
            return None
        return self.fields.get(field_name.lower())


class RegisterMap:
    """
    RegisterMap holds registers and provides resolution and utilities.

    Key behaviors:
    - Case-insensitive lookups for both registers and fields.
    - Stores current register values (by register canonical name) which default to None.
    """

    def __init__(self, registers: dict[str, Register]) -> None:
        # registers keyed by lowercased name
        self._registers: dict[str, Register] = registers
        # storage for current register values keyed by lowercased register name
        self._values: dict[str, int | None] = {k: None for k in registers.keys()}

    @classmethod
    def from_json_map(cls, json_map: dict[str, Any]) -> "RegisterMap":
        """
        Create a RegisterMap from a JSON-like dict.

        Field definitions must contain at least "name" and "lsb". They may specify "msb" or "width".
        Register addresses may be integers or hex strings like "0x10".
        """

        regs_list: list[dict[str, Any]] = []
        if "registers" in json_map:
            regs = json_map["registers"]
            if not isinstance(regs, list):
                raise ValueError("'registers' must be a list")
            regs_list = regs
        else:
            # treat top-level keys as registers
            for k, v in json_map.items():
                rd: dict[str, Any] = {"name": k}
                if isinstance(v, dict):
                    rd.update(v)
                else:
                    raise ValueError(f"Invalid register definition for {k}")
                regs_list.append(rd)

        registers: dict[str, Register] = {}
        for rd in regs_list:
            name = rd.get("name")
            if not name or not isinstance(name, str):
                raise ValueError("Each register must have a string 'name'")

            address_raw = rd.get("address")
            if address_raw is None:
                raise ValueError(f"Register '{name}' missing 'address'")
            address = cls._parse_address(address_raw)

            # accommodate both "fields" and "bitfields" if present
            fields_raw = rd.get("fields", rd.get("bitfields", []))
            if fields_raw is None:
                fields_raw = []
            if not isinstance(fields_raw, list):
                raise ValueError(
                    f"'fields' for register '{name}' must be a list if present"
                )

            fields: dict[str, Field] = {}
            for fd in fields_raw:
                if not isinstance(fd, dict):
                    raise ValueError(
                        f"Field entries for register '{name}' must be dicts"
                    )
                fname = fd.get("name")
                if not fname or not isinstance(fname, str):
                    raise ValueError(
                        f"A field in register '{name}' is missing a string 'name'"
                    )
                if "lsb" not in fd:
                    raise ValueError(
                        f"Field '{fname}' in register '{name}' missing 'lsb'"
                    )
                lsb = fd["lsb"]
                if not isinstance(lsb, int) or lsb < 0:
                    raise ValueError(
                        f"Field '{fname}' in register '{name}': 'lsb' must be a non-negative int"
                    )
                msb: int | None = None
                if "msb" in fd:
                    msb = fd["msb"]
                    if not isinstance(msb, int):
                        raise ValueError(
                            f"Field '{fname}' in register '{name}': 'msb' must be int"
                        )
                elif "width" in fd:
                    width = fd["width"]
                    if not isinstance(width, int) or width <= 0:
                        raise ValueError(
                            f"Field '{fname}' in register '{name}': 'width' must be positive int"
                        )
                    msb = lsb + width - 1
                else:
                    msb = lsb

                field_obj = Field(name=fname, lsb=lsb, msb=msb)
                key = fname.lower()
                if key in fields:
                    raise ValueError(
                        f"Duplicate field name '{fname}' in register '{name}'"
                    )
                fields[key] = field_obj

            reg = Register(name=name, address=address, fields=fields)
            rkey = name.lower()
            if rkey in registers:
                raise ValueError(f"Duplicate register name '{name}'")
            registers[rkey] = reg

        return cls(registers)

    @staticmethod
    def _parse_address(addr: Any) -> int:
        if isinstance(addr, int):
            return addr
        if isinstance(addr, str):
            s = addr.strip().lower()
            if s.startswith("0x"):
                try:
                    return int(s, 16)
                except ValueError as exc:
                    raise ValueError(f"Invalid hex address: {addr}") from exc
            else:
                try:
                    return int(s, 0)
                except ValueError as exc:
                    raise ValueError(f"Invalid address string: {addr}") from exc
        raise TypeError("address must be int or hex string")

    def resolve(self, name: str) -> tuple[str, int, Field | None]:
        """
        Resolve a name to (register_name, address, field or None).

        Name formats supported:
        - "REG" (case-insensitive) -> (reg_name, address, None)
        - "REG.FIELD" (case-insensitive) -> (reg_name, address, Field)
        - "FIELD" (if the field name is unique across all registers) -> (reg_name, address, Field)

        Raises ValueError when not found or ambiguous.
        """
        name = name.strip()
        if not name:
            raise ValueError("name must not be empty")

        if "." in name:
            reg_part, field_part = name.split(".", 1)
            reg = self._registers.get(reg_part.lower())
            if reg is None:
                raise ValueError(f"Register '{reg_part}' not found")
            field = reg.get_field(field_part)
            if field is None:
                raise ValueError(
                    f"Field '{field_part}' not found in register '{reg.name}'"
                )
            return (reg.name, reg.address, field)

        # try register name first
        reg = self._registers.get(name.lower())
        if reg is not None:
            return (reg.name, reg.address, None)

        # try to resolve as a field name globally (must be unique)
        matches: list[tuple[Register, Field]] = []
        lname = name.lower()
        for regobj in self._registers.values():
            fld = regobj.get_field(lname)
            if fld is not None:
                matches.append((regobj, fld))
        if not matches:
            raise ValueError(f"Name '{name}' did not match any register or field")
        if len(matches) > 1:
            reg_names = ", ".join(r.name for r, _ in matches)
            raise ValueError(
                f"Field name '{name}' is ambiguous (found in registers: {reg_names}); please qualify with 'REG.FIELD'"
            )
        regobj, fld = matches[0]
        return (regobj.name, regobj.address, fld)

    def read_field_from_register(
        self, register_name: str, register_value: int, field_name: str | None
    ) -> int:
        """
        Extract an integer field value from a register_value.

        If field_name is None, returns the full register_value (no masking).
        """
        if not isinstance(register_name, str):
            raise TypeError("register_name must be a string")
        if register_value is None:
            raise ValueError("register_value must not be None")
        if not isinstance(register_value, int):
            raise TypeError("register_value must be an int")
        reg = self._registers.get(register_name.lower())
        if reg is None:
            raise ValueError(f"Register '{register_name}' not found")
        if field_name is None:
            return register_value
        fld = reg.get_field(field_name)
        if fld is None:
            raise ValueError(f"Field '{field_name}' not found in register '{reg.name}'")
        return fld.extract(register_value)

    def compose_register_write(
        self,
        register_name: str,
        field_name: str | None,
        field_value: int,
        current_value: int | None,
    ) -> int:
        """
        Compose a register write value.

        - If field_name is None: field_value is treated as the full register value and returned.
        - If field_name provided: validates field_value fits into the field, uses current_value (or 0 if None)
          to preserve other bits and returns the composed full register value.
        """
        if not isinstance(register_name, str):
            raise TypeError("register_name must be a string")
        if field_value is None:
            raise ValueError("field_value must not be None")
        if not isinstance(field_value, int):
            raise TypeError("field_value must be int")
        reg = self._registers.get(register_name.lower())
        if reg is None:
            raise ValueError(f"Register '{register_name}' not found")
        if field_name is None:
            # full register write
            return field_value
        fld = reg.get_field(field_name)
        if fld is None:
            raise ValueError(f"Field '{field_name}' not found in register '{reg.name}'")
        base = 0 if current_value is None else current_value
        if not isinstance(base, int):
            raise TypeError("current_value must be int or None")
        return fld.insert_into(base, field_value)

    def registers(self) -> list[Register]:
        """Return list of Register objects."""
        return list(self._registers.values())

    def __repr__(self) -> str:
        return f"<RegisterMap registers={len(self._registers)}>"
