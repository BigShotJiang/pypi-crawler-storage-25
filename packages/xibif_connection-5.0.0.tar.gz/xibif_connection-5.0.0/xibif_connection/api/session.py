"""Context management for a XibifConnection"""
from __future__ import annotations
from .connection import XibifConnection


class XibifSession(XibifConnection):
    """
    A `XibifSession` allows using a `XibifConnection` object
    with context management.

    The `XibifSession` is a wrapper class for `XibifConnection`, inheriting
    all functions and extending it by providing `__enter__` and `__exit__`
    functions to use it in a context.
    """

    def __enter__(self) -> "XibifConnection":
        """
        Enter the runtime context related to this object.

        This method opens the connection to the XiBIF device by calling `connect()`.
        To ensure a proper state of the connection, `read_board_status()` is called
        when connected.

        Returns
        -------
        XibifSession
            The active session object that can be used inside the `with` block.
        """
        self.connect()
        return self

    def __exit__(
        self,
        exc_type: type | None,
        exc_value: BaseException | None,
        traceback: object | None,
    ) -> None:
        """
        Exit the runtime context and clean up the session.

        This method closes the connection to the XiBIF device by calling `disconnect()`.

        Parameters
        ----------
        exc_type : type, optional
            The exception type if an exception occurred, else None.
        exc_value : BaseException, optional
            The exception instance if an exception occurred, else None.
        traceback : object, optional
            The traceback object if an exception occurred, else None.
        """
        self.disconnect()
