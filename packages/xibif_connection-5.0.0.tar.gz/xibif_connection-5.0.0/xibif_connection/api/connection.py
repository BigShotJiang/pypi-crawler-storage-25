"""Connection API for a XiBIF Board"""

from __future__ import annotations
from importlib.metadata import version
import json
import os
import time
from ipaddress import AddressValueError, IPv4Address

import numpy as np
from numpy.typing import NDArray

from ..exceptions import (
    SocketClosedError,
    SocketConnectionError,
    SocketTimeoutError,
    XibifError,
    XibifResponseError,
)
from ..protocol.coding import XibifProtocol
from ..protocol.data import (
    AxiAccessStatus,
    Command,
    Message,
    Response,
    ResponseStatus,
    XibifRegisterAddress,
    XibifRegisterData,
    XibifStatus,
)
from ..transport.tcp import TcpTransport

try:
    from tqdm import tqdm as tqdm_progress
except ModuleNotFoundError:
    tqdm_progress = None


class XibifConnection:
    """
    The base class to establish connection to a XiBIF board.
    """

    PORT_REGISTERS = 6
    PORT_ECHO = 7
    PORT_HTTP = 80

    ip: str
    uuid: int
    timeout: float = 5
    verbose: bool = False

    status: XibifStatus

    transport: TcpTransport
    protocol: XibifProtocol = XibifProtocol(32)

    _disable_axi_DEC0DEE3_DEADFA11: bool = False

    _last_response: Response | None = None

    def __init__(
        self,
        ip: str,
        uuid: int,
        timeout: float | None = None,
        verbose: bool | None = None,
    ) -> None:
        """
        Initialize a `XibifConnection` object.

        To connect to a XiBIF board, an IP address for the board as
        well as a UUID must be provided, both of which can be obtained
        from the UART output of the board.


        Parameters
        ----------
            ip: str
                The IP-address of the board to connect to. Must be a valid IPv4 address.
            uuid: int
                UUID of the board to connect to. Acts as a passphrase to verify that the
                correct board is connected.
            timeout: float | None
                Timeout in seconds until a port connection is assumed to have been unexpectedly
                closed. Defaults to 5.0 seconds.
            verbose: bool | None
                If set to `True` output detailed transaction information.

        Raises
        ------
            ValueError:
                The IP-address is not a valid IPv4 address.
        """
        try:
            IPv4Address(ip)
        except AddressValueError as e:
            raise ValueError("given IP address is not a valid IPv4 address") from e

        self.ip = ip
        self.uuid = uuid

        if timeout:
            self.timeout = timeout
        if verbose:
            self.verbose = verbose
        self.transport = TcpTransport(ip, self.PORT_REGISTERS, self.timeout)

    def connect(self) -> None:
        """
        Connect to the board

        Raises
        ------
        XibifError:
            Could not connect to board
        """
        try:
            self.transport.open()
        except SocketConnectionError as e:
            raise XibifError(
                f"Failed to connect to {self.ip}:{self.PORT_REGISTERS}"
            ) from e
        if self.verbose:
            print(f"Established connection to {self.ip}:{self.PORT_REGISTERS}")

        self.read_board_status()

        if not self._is_compatible():
            raise XibifError(
                "The used xibif version of the board is not compatible with this version of the xibif-connection package. Try updating the xibif-connection package and/or the xibif on your board to the same version."
            )

    def disconnect(self) -> None:
        """
        Closes the connection to the board
        """
        try:
            self.transport.close()
        except SocketClosedError as e:
            raise XibifError(
                f"Failed to close connection to {self.ip}:{self.PORT_REGISTERS}"
            ) from e
        if self.verbose:
            print(f"Closed connection to {self.ip}:{self.PORT_REGISTERS}")

    # ---- Internal ----
    def _send_and_receive(self, msg: Message) -> Response:
        """
        Send a message to the connected board and receive the response.

        Parameters
        ----------
        msg : Message
            The message to send to the connected board

        """

        self._send_message(msg)
        resp = self._receive_response()
        if resp.status == ResponseStatus.UNAUTHORIZED:
            raise XibifResponseError(f"Invalid UUID to access board at {self.ip}")
        elif resp.status == ResponseStatus.COMMAND_NOT_IMPLEMENTED:
            raise XibifResponseError("The requested command is not implemented")
        elif resp.status == ResponseStatus.FAILED:
            raise XibifResponseError("Command execution failed on the FPGA")
        elif resp.status == ResponseStatus.INVALID_LENGTH:
            raise XibifResponseError("Invalid payload length for command")
        elif resp.status != ResponseStatus.OK:
            raise XibifResponseError("An unknown error occurred")
        if self.verbose:
            print(resp)

        return resp

    def _send_message(self, msg: Message) -> None:
        """
        Sends a message to the connected board using a transport object

        The message is encoded with a protocol (see the protocol property of the XibifSession class)
        and then sent using the transport.

        If the session is started in verbose mode (XibifSession.verbose == True), the contents of the
        message are printed to the console prior to sending.

        Parameters
        ----------
        msg: Message
            The message to send to the board
        """
        tx = self.protocol.encode(msg)
        if self.verbose:
            print(msg)
        self.transport.send(tx)

    def _receive_response(self) -> Response:
        """
        Receives a response from the connected board.

        A certain number of bytes is received defined by the header size in the
        protocol, which subsequently determines the number of data bytes to receive.

        The received data is converted to a `Response` object .

        Returns
        -------
        resp: Response
            The received response
        """
        try:
            rx = self.transport.receive(self.protocol.header_size_bytes)
        except SocketTimeoutError as e:
            raise XibifError(
                "A timeout occurred while receiving the header. It is likely that the expected and actual header length do not match"
            ) from e
        header = self.protocol.decode(rx)
        length = self.protocol.get_payload_length_from_header(header)
        exec_time = self.protocol.get_execution_time_from_header(header)

        if self.verbose:
            print(f"Receiving {length} bytes of data")
            print(f"Command took {2 * exec_time} FPGA PS cycles to execute")
        payload = np.array([])
        if length > 0:
            rx = self.transport.receive(length)
            payload = self.protocol.decode(rx)

        resp = self.protocol.build_response(header, payload)
        self._last_response = resp
        return resp

    def _listify(
        self, value: int | list[int] | NDArray[np.uint32]
    ) -> NDArray[np.uint32]:
        """
        Ensures that values are an array

        If a single value is passed as parameter, an array of length 1 is returned
        containing only that value.
        If an array-like is passed as parameter, it is returned as an array.

        Returns
        -------
        values: npt.NDArray[np.integer]
            An array containing the passed valued
        """
        if isinstance(value, int):
            value = [value]

        return np.array(value, dtype=self.protocol.dtype)

    def _check_address_alignment(
        self, addresses: XibifRegisterAddress, alignment: int = 4
    ) -> bool:
        """
        Checks that all addresses in an address list are aligned to a number of bytes.

        Alignment is checked per address using `(address % alignment) == 0`.

        Parameters
        ----------
        addresses: npt.NDArray[np.integer]
            The addresses to check for alignment
        alignment: int, optional
            The alignment to check for. Default: 4

        Returns
        -------
        aligned : bool
            True if all addresses are aligned, false otherwise
        """
        if isinstance(addresses, int):
            return addresses % alignment == 0

        for a in addresses:
            if a % alignment != 0:
                return False
        return True

    def _get_pbar(self, total: int, description: str):
        if tqdm_progress is None:
            return None
        return tqdm_progress(
            total=total,
            desc=description,
            bar_format="{desc} |{bar}| {percentage:3.0f}% {n_fmt}/{total_fmt} "
            "[{elapsed}<{remaining}, {rate_fmt}]",
            unit_scale=True,
        )

    def _display_progress_update(self, pbar, text: str, inc: int = 1):
        if pbar is None:
            print(text)
            return
        pbar.update(inc)

    def _check_axi_response(self, response: NDArray[np.uint32]):
        status = [AxiAccessStatus(value) for value in response]
        nonzero_status = [s for s in status if s != AxiAccessStatus.AXI_ACCESS_OK]

        if self._disable_axi_DEC0DEE3_DEADFA11:
            nonzero_status = [
                s
                for s in status
                if s != AxiAccessStatus.AXI_FIREWALL_DATA_DEC0DEE3_DEADFA11
            ]
        if any(nonzero_status):
            raise XibifError(
                f"An error occurred while writing to an AXI device: {nonzero_status}"
            )

    def _is_compatible(self) -> bool:
        version_full = version("xibif-connection").split(".")

        # Check if the version is a pre-release
        if len(version_full) > 3:
            version_full[3] = version_full[3].split("+")[0].removeprefix("post")
            while len(version_full) > 4:
                version_full.pop(4)
        else:
            version_full.append("0")

        major = int(version_full[0])
        minor = int(version_full[1])
        patch = int(version_full[2])
        revision = int(version_full[3])

        # Compare major version
        if major != self.status.softwareVersion.major:
            return False
        if major != self.status.registerVersion.major:
            return False
        if major != self.status.streamVersion.major:
            return False

        # Compare minor version
        if minor != self.status.softwareVersion.minor:
            if minor > self.status.softwareVersion.minor:
                print(
                    f"Warning: Software version minor number is higher than version of this package: {str(self.status.softwareVersion)} > v{major}.{minor}.{patch}-{revision}. Try updating the package xibif-connection to the same version."
                )
            else:
                print(
                    f"Warning: Software version minor number is lower than version of this package: {str(self.status.softwareVersion)} < v{major}.{minor}.{patch}-{revision}. Try updating the xibif package and the software on your board."
                )
            return True
        if minor != self.status.registerVersion.minor:
            if minor > self.status.registerVersion.minor:
                print(
                    f"Warning: Register version minor number is higher than version of this package: {str(self.status.registerVersion)} > v{major}.{minor}.{patch}-{revision}. Try updating the package xibif-connection to the same version."
                )
            else:
                print(
                    f"Warning: Register version minor number is lower than version of this package: {str(self.status.registerVersion)} < v{major}.{minor}.{patch}-{revision}. Try updating the xibif package and the software on your board."
                )
            return True
        if minor != self.status.streamVersion.minor:
            if minor > self.status.streamVersion.minor:
                print(
                    f"Warning: Stream version minor number is higher than version of this package: {str(self.status.streamVersion)} > v{major}.{minor}.{patch}-{revision}. Try updating the package xibif-connection to the same version."
                )
            else:
                print(
                    f"Warning: Stream version minor number is lower than version of this package: {str(self.status.streamVersion)} < v{major}.{minor}.{patch}-{revision}. Try updating the xibif package and the software on your board."
                )
            return True

        # Compare patch version
        if patch != self.status.softwareVersion.patch:
            if patch > self.status.softwareVersion.patch:
                print(
                    f"Warning: Software version patch number is higher than version of this package: {str(self.status.softwareVersion)} > v{major}.{minor}.{patch}-{revision}. Try updating the package xibif-connection to the same version."
                )
            else:
                print(
                    f"Warning: Software version patch number is lower than version of this package: {str(self.status.softwareVersion)} < v{major}.{minor}.{patch}-{revision}. Try updating the xibif package and the software on your board."
                )
            return True
        if patch != self.status.registerVersion.patch:
            if patch > self.status.registerVersion.patch:
                print(
                    f"Warning: Register version patch number is higher than version of this package: {str(self.status.registerVersion)} > v{major}.{minor}.{patch}-{revision}. Try updating the package xibif-connection to the same version."
                )
            else:
                print(
                    f"Warning: Register version patch number is lower than version of this package: {str(self.status.registerVersion)} < v{major}.{minor}.{patch}-{revision}. Try updating the xibif package and the software on your board."
                )
            return True
        if patch != self.status.streamVersion.patch:
            if patch > self.status.streamVersion.patch:
                print(
                    f"Warning: Stream version patch number is higher than version of this package: {str(self.status.streamVersion)} > v{major}.{minor}.{patch}-{revision}. Try updating the package xibif-connection to the same version."
                )
            else:
                print(
                    f"Warning: Stream version patch number is lower than version of this package: {str(self.status.streamVersion)} < v{major}.{minor}.{patch}-{revision}. Try updating the xibif package and the software on your board."
                )
            return True

        return True

    # ---- API ----

    def read_board_status(self) -> XibifStatus:
        """
        Read the current board status

        The board status contains static and runtime information of the board.
        Once received, the status is stored in the `XibifSession.status` property
        for later referral.

        The status contains information about the register width which is updated for the protocol
        to read/write registers with widths > 32bit

        This property does not update automatically.

        Returns
        -------
        status: XibifStatus
            The status of the board

        Raises
        ------
        XibifError:
            The status cannot be decoded from the payload
        """
        msg = Message(self.uuid, Command.STATUS)
        resp = self._send_and_receive(msg)

        if resp.payload is None:
            raise XibifError("Cannot decode status from None")

        self.status = XibifStatus(resp.payload)
        self.protocol.register_width = self.status.registerWidth

        return self.status

    def read(self, address: XibifRegisterAddress) -> XibifRegisterData:
        """Read register values

        This function reads a single or multiple register values from a board.

        Parameters
        ----------
        address: int | List[int]
            A single address or an array of register addresses to read.

        Returns
        -------
        values : int | List[int]
            A single integer or a numpy array of integers corresponding to the addressed given as parameters.

        Raises
        ------
        ValueError:
            The some addresses are not word (4-byte) aligned.
        XibifError:
            Failed to read register(self)
        XibifError:
            The value read from the register(self) is not valid.

        """
        address = self._listify(address)
        if not self._check_address_alignment(address):
            raise XibifError("address must be word-aligned (4-bytes)!")

        addresses = self.protocol.encode_register_address(address)

        msg = Message(self.uuid, Command.READ_REGISTER, addresses)
        resp = self._send_and_receive(msg)

        if resp.status != ResponseStatus.OK:
            raise XibifError(
                f"could not read register{'self' if len(addresses) > 1 else ''}"
            )
        if resp.payload is None:
            raise XibifError("None is not a valid value for a register")

        if len(resp.payload) == 1:
            return int(resp.payload[0])

        return resp.payload.tolist()

    def write(
        self,
        address: int | list[int],
        value: int | list[int],
    ):
        """Write register values

        Writes a single or multiple register values to a Xibif board by sending multiple pairs
        of (address, value) to the board.

        When writing multiple register, the length and dimensions of the value and parameter registers must be equal.

        Parameters
        ----------
        address: int | List[int]
            A single address or an array of register addresses to read.
        value: int | List[int]
            A single value or an array of values to write to the registers.

        Raises
        ------
        ValueError:
            The length of the address and value arrays does not match
        ValueError:
            The some addresses are not word (4-byte) aligned.
        XibifError:
            Failed to write register(self)
        """
        addresses = self._listify(address)
        values = self._listify(value)

        if len(addresses) != len(values):
            raise ValueError(
                "the number of addresses and values to write must be equal"
            )
        if not self._check_address_alignment(addresses):
            raise ValueError("address must be word-aligned (4-bytes)!")

        payload = np.hstack(list(zip(addresses, values))).transpose()
        msg = Message(self.uuid, Command.WRITE_REGISTER, payload)
        resp = self._send_and_receive(msg)

        if resp.status != ResponseStatus.OK:
            raise XibifError(
                f"could not write register{'self' if len(addresses) > 1 else ''}"
            )

    def read_stream(self, length: int | None = None) -> list[int] | None:
        """
        Read stream data from the XiBIF board.

        Attempts to read a number of stream data packets from the FPGA. If successful,
        the data read is returned as a numpy array with the length requested in `length`.

        Attention: there is no guarantee that the number of entries read is the number that
        was requested.

        If no data is obtained from the board, `None` is returned.

        Parameters
        ----------
            length: int
                The number of stream entries to be read. For normal configurations, a stream entry is a word (4 bytes)
                If `None` is specified, all available data is read from the board.

        Returns
        -------
            rx: NDArray[int] | None
                An array of the stream data received from the board.
        """
        if not self.status.pl2pcFifo.enabled:
            raise XibifError("Cannot read stream from device, PL2PC FIFO is disabled")

        if length is None:
            payload = None
            msg = Message(self.uuid, Command.READ_STREAM_ALL, payload)
        else:
            payload = np.array([length * 4], dtype=self.protocol.dtype)
            msg = Message(self.uuid, Command.READ_STREAM, payload)

        resp = self._send_and_receive(msg)

        if resp.status != ResponseStatus.OK:
            raise XibifError("could not read from board stream")

        if resp.payload is None:
            return None

        return resp.payload.tolist()

    def write_stream(self, data: NDArray[np.uint32]) -> None:
        """
        Write stream data to the XiBIF board.

        Writes the given data to the FPGA stream.

        Parameters
        ----------
            data: list[int] | int
                A list of the data to write to the FPGA
        """
        if not self.status.pc2plFifo.enabled:
            raise XibifError("Cannot write stream to device, PC2PL FIFO is disabled")

        msg = Message(self.uuid, Command.WRITE_STREAM, data)
        self._send_and_receive(msg)

    def flush_stream(self) -> None:
        """
        Flush the XiBIF Stream

        Flush all data in the FPGA stream by resetting the head and tail pointers of the associated FIFOs.
        Any data that is flushed cannot be recovered!
        """
        msg = Message(self.uuid, Command.FLUSH_STREAM, None)
        self._send_and_receive(msg)

    def set_uart_debug(self, enable: bool) -> None:
        """
        Set UART debug property

        Sets the UART debug property in the PS software. When set to `True`,
        UART debugging is enabled, resulting in all socket transactions
        being printed over UART.

        Be aware that enabling the UART debug feature drastically impacts
        software performance.
        """
        payload = np.array([1 if enable else 0], dtype=self.protocol.dtype)
        msg = Message(self.uuid, Command.UART_ENABLE_DBG_OUTPUT, payload)
        self._send_and_receive(msg)

    def print_status_uart(self) -> None:
        """
        Print the status of the XiBIF board over UART.

        Contains information such as versions, UUIDs, stream FIFO stats and build times.
        """
        msg = Message(self.uuid, Command.UART_PRINT_STATUS, None)
        self._send_and_receive(msg)

    def reset(self) -> None:
        """
        Perform a reset of the board.
        """
        msg = Message(self.uuid, Command.RESET, None)
        self._send_and_receive(msg)

    def write_bitstream(self, path: str) -> None:
        """
        Write a bitstream to the XiBIF board.

        Parameters
        ----------
            path: str
                path to the bitstream file to be flashed

        Raises
        ------
            XibifError:
                Flashing the bitstream is not available for the connected board
            XibifError from ValueError
        """

        if not self.status.bistreamAvailable:
            raise XibifError("bitstream flashing is not available for your device")

        if not os.path.exists(path):
            raise XibifError(f"the path {path} does not exist")

        streamAddress = 0x43C0_0000
        registerAddress = 0x43D0_0000
        data = np.fromfile(path, dtype=np.uint32)

        if self.verbose:
            print(f"writing bitstream from path {path}")

        payload = np.insert(data, 0, [streamAddress, registerAddress])
        msg = Message(self.uuid, Command.WRITE_BITSTREAM, payload)
        self._send_and_receive(msg)

    def read_registermap(self):
        """
        Read the registermap from the XiBIF board.

        Reads the embedded registermap from the XiBIF board as a JSON formatted
        string and returns the JSON object.

        The JSON object contains information on the user registers and their
        fields that are accessible using the `read` and `write` methods.

        Returns
        -------
            map: json
                A JSON object containing the register map of the board

        Raises
        ------
            XibifError:
                No registermap received
        """
        msg = Message(self.uuid, Command.READ_REGISTER_MAP, None)
        resp = self._send_and_receive(msg)
        if resp.payload is None:
            raise XibifError("no registermap received")

        register_map_json = resp.payload.tobytes().rstrip(b"\x00").decode("utf-8")

        return json.loads(register_map_json)

    def write_axi(
        self,
        address: int | list[int],
        data: int | list[int],
        mask: int | list[int] = 0xFFFF_FFFF,
    ):
        """
        Write data to an AXI address

        This function is used to write data to one or multiple AXI addresses.
        When this function is invoked with only one address and multiple data
        words, an address array of increasing addresses with the length of the
        data is created.
        When multiple addresses are given, the number of entries in the address
        and data lists must match for a one-to-one mapping.
        The data mask allows to disable individual bits from being written. 0xFFFF_FFFF
        corresponds to all 32 bits of data being written.

        Parameters
        ----------
            address: int | List[int]
                One or multiple addresses to write to
            data: int | List[int]
                One or multiple data words to write
            mask: int | List[int]
                One or multiple data masks to mask data to write

        Raises
        ------
            XibifError:
                The returned AXI status is not AxiAccessStatus.AXI_ACCESS_OK
                The number of addresses is greater than one and does not match the number of data words
                The number of masks is greater than one and does not match the number of data words
                No payload was received after the AXI write

        """
        # make lists
        addresses = self._listify(address)
        datas = self._listify(data)
        masks = self._listify(mask)

        # either specify one address/mask or specify the number of data words
        if len(addresses) > 1 and len(addresses) != len(datas):
            raise XibifError(
                "When specifying more than one address, the number of addresses must be equal to the number of data words"
            )
        if len(masks) > 1 and len(masks) != len(datas):
            raise XibifError(
                "When specifying more than one mask, the number of masks must be equal to the number of data words"
            )

        # normalize address and mask
        if len(addresses) == 1:
            addresses = np.array(
                [addresses[0] + i * 4 for i in range(len(addresses))],
                dtype=self.protocol.dtype,
            )
        if len(masks) == 1:
            masks = np.ones(len(masks), dtype=self.protocol.dtype) * masks[0]

        # assemble payload [a0, d0, m0, a1, b1, m1, ...]
        payload = np.hstack(list(zip(addresses, datas, masks))).transpose()
        msg = Message(self.uuid, Command.AXI_WRITE, payload)
        resp = self._send_and_receive(msg)

        # no payload -> something went wrong
        if resp.payload is None:
            raise XibifError("No payload received after AXI write command")

        self._check_axi_response(resp.payload)

    def read_axi(self, address: int | list[int], length: int = 1):
        """
        Read data from an AXI address

        This function is used to read data from one or more AXI addresses.
        When only one address is given, the length parameter allows to read
        multiple consecutive words from an AXI endpoint.

        Parameters
        ----------
            address: int | List[int]
                One or multiple addresses to read from
            length: int = 1
                Number of words to read from the given address up to address + 4 * (i-1)

        Returns
        -------
            data: int | List[int]
                One or multiple words read from the given AXI address

        Raises
        ------
            XibifError:
                No payload received from read command
                Multiple addresses and length > 1 specified
        """
        addresses = self._listify(address)
        if len(addresses) == 1:
            addresses = np.array([addresses[0] + i * 4 for i in range(length)])

        if len(addresses) > 1 and length > 1:
            raise XibifError(
                "When multiple addresses to read are specified, the length parameter must be 1"
            )
        msg = Message(self.uuid, Command.AXI_READ, addresses)
        resp = self._send_and_receive(msg)

        if resp.payload is None:
            raise XibifError("No payload received after AXI read command")

        # response structure [data0, error0, data1, error1, ...]
        data = resp.payload[::2]
        error = resp.payload[1::2]
        self._check_axi_response(error)

        if len(data) == 1:
            return data[0]
        return data

    def ping(
        self,
        payload: bytes | bytearray | list[int] | NDArray[np.uint32] = b"PING",
        timeout: float | None = None,
        retries: int = 1,
        transport: TcpTransport | None = None,
    ) -> float:
        """
        Ping a XiBIF board

        The XiBIF board is pinged using the echo port (80) and the round-trip-time
        (RTT) is measured.

        Parameters
        ----------
            payload: bytes | bytearray | List[int] | NDArray[np.uint32] = b"PING",
                The payload to send to the XiBIF board
            timeout: float | None = None,
                Time in seconds until the connection is considered timed out
            retries: int = 1,
                Number of times the ping is retried until a connection is considered dead.
            transport: TcpTransport | None = None,
                Protocol to use
        Raises
        ------
            XibifError
                Connection could not be opened
                Unsupported payload
                Received payload does not match sent payload
                Ping timed out after retries
        """
        timeout = timeout if timeout is not None else self.timeout
        echo_transport = (
            TcpTransport(self.ip, self.PORT_ECHO, timeout)
            if transport is None
            else transport
        )
        try:
            try:
                echo_transport.open()
            except SocketConnectionError as e:
                raise XibifError(
                    f"Failed to open echo connection to {self.ip}:{self.PORT_ECHO}"
                ) from e

            if isinstance(payload, (bytes, bytearray)):
                data = bytes(payload)
            else:
                try:
                    arr = np.asarray(payload, dtype=np.uint8).ravel()
                    data = arr.tobytes()
                except (TypeError, ValueError) as e:
                    raise XibifError("Unsupported payload type for ping") from e

            last_exc: Exception | None = None
            for _attempt in range(max(1, retries)):
                start = time.monotonic()
                try:
                    echo_transport.send(data)
                    resp = echo_transport.receive(len(data))
                except (SocketTimeoutError, SocketClosedError) as e:
                    last_exc = e
                    # try again unless this was the last attempt
                    continue

                rtt = time.monotonic() - start

                if resp == data:
                    return rtt
                else:
                    raise XibifError("Echo payload mismatch")

            # If we reach here, all retries exhausted
            raise XibifError(f"ping timed out after {retries} attempts") from last_exc
        finally:
            try:
                echo_transport.close()
            except (SocketClosedError, OSError):
                # best-effort close, ignore errors
                pass

    # -----------------------------
    # Benchmarking
    # -----------------------------

    def benchmark_stream_write(
        self,
        n_bytes: int,
        repeats: int = 1,
        skip_flush: bool = False,
        quiet: bool = False,
    ) -> float:
        """
        Write a random array of n_bytes to the board and measure the time required.

        To measure performance, n_bytes are written to the board. The actual data being sent
        is divided into words (4 bytes), i.e. there are a total number of n_bytes / 4 words
        being sent using `write_stream`.

        If desired, the write operation can be repeated for `repeats` number of times. For each
        iteration, the time is measured for the write portion only. The returned value is the
        average of the durations.

        The `skip_flush` option is provided when performing complete benchmarks (i.e. read and write).
        It allows for the written data to persist on the board, meaning that the read test does not
        need to write data to the board before testing read speeds.

        Parameters
        ----------
            n_bytes: int
                number of bytes to send
            repeats: int
                the number of times to repeat the test
            skip_flush: bool
                whether to skip flushing after the write test, useful for consecutive read tests
            quiet: bool
                whether to print information during the test

        Returns
        -------
            duration: float
                the average duration of the write transactions
        """
        n_words = n_bytes // 4  # 32-bit words
        tx = np.random.randint(0, 2**32, n_words, dtype=np.uint32)

        if not quiet:
            print("-------------------------------------------------------")
            print(f"Starting Stream Write Benchmark with {n_bytes} bytes ")
            print(f"\t{repeats} tests will be run")

        # Benchmark
        durations = []
        for i in range(repeats):
            if not quiet:
                print(f"\tIteration {i + 1}/{repeats}", end="")
            start = time.monotonic_ns()
            self.write_stream(tx)
            while True:
                self.read_board_status()
                if self.status.pl2pcFifo.fill == n_words:
                    break
            end = time.monotonic_ns()
            duration = end - start
            duration /= 1e9

            if not quiet:
                print(f": {duration:.4f} seconds")

            durations.append(duration)

        if not skip_flush:
            self.flush_stream()

        if not quiet:
            print("-------------------------------------------------------")

        return float(np.mean(durations))

    def benchmark_stream_read(
        self,
        n_bytes: int | None,
        repeats: int = 1,
        skip_write: bool = False,
        quiet: bool = False,
    ) -> float:
        """
        Read a random array of n_bytes from the board and measure the time required.

        Before reading, `n_bytes` of random data are written to the board unless `skip_write = True`.
        The actual data being sent is divided into words (4 bytes), i.e. there are a total number of n_bytes / 4 words
        being sent using `write_stream`.

        The amount of data written to the board is then read and the time required for this action is measured.

        The `skip_write` option is provided when performing complete benchmarks (i.e. read and write).
        It allows for previously written data from another benchmark to be read instead of explicitly writing
        data for the purpose of measuring the read performance.

        Parameters
        ----------
            n_bytes: int
                number of bytes to send
            repeats: int
                the number of times to repeat the test
            skip_write: bool
                whether to write data to the board before reading
            quiet: bool
                whether to print information during the test

        Returns
        -------
            duration: float
                the average duration of the read transactions
        """
        if not quiet:
            print("-------------------------------------------------------")
            if n_bytes is None:
                print(f"Starting Stream Read Benchmark with {n_bytes} bytes ")
            else:
                print("Starting Stream Read All Benchmark")

            print(f"\t{repeats} tests will be run")
        if skip_write is True and repeats > 1:
            raise ValueError(
                "the combination of skipping writes before benchmarking and doing more than one test is illegal"
            )

        durations = []
        for i in range(repeats):
            if not quiet:
                print(f"\tIteration {i + 1}/{repeats}", end="")
            # write data if necessary
            if not skip_write:
                if n_bytes is None:
                    raise ValueError(
                        "Cannot write without information on the number of bytes"
                    )
                n_words = n_bytes // 4  # 32-bit words
                tx = np.random.randint(0, 2**32, n_words, dtype=np.uint32)
                self.write_stream(tx)

            # Benchmark
            start = time.monotonic_ns()
            if n_bytes is not None:
                rx = self.read_stream(n_bytes // 4)
            else:
                rx = self.read_stream()
            if rx is None:
                raise RuntimeError("no data to read!")
            end = time.monotonic_ns()

            duration = end - start
            duration /= 1e9
            if not quiet:
                print(f": {duration:.4f} seconds")
            durations.append(duration)

            if not quiet:
                print("-------------------------------------------------------")

        return float(np.mean(durations))

    def benchmark_memory_access(self, cycles: list[int] | np.ndarray, repeat: int = 5):
        """
        Benchmark the XiBIF Software

        The software is benchmarked by executing a set of commands in the FPGA PS for `cycles`
        number of times. The FPGA responds to this command with the amount of so-called "Global Time"
        that has passed during execution of said commands.

        The elapsed wallclock time is calculated from the "Global Time" returned by the FPGA.

        The commands executed are:
            - access to the user register area
            - access to the stream register area
            - read access to RAM
            - write access to RAM

        Parameters
        ----------
            cycles: list[int] | NDArray[np.uint32]
                A list of the amount of cycles for which to evaluate the benchmark commands.
            repeat: int = 5
                Number of times to repeat the memory access test

        Returns
        -------
            cycles, userTime, streamTimes, ddrWriteTimes, ddrReadTimes: list[int], list[float], list[float], list[float], list[float]
                A tuple of lists where each list has the same length as the `cycles` input parameter containing
                the wallclock execution times for the benchmark commands.
        """
        userTimes = []
        streamTimes = []
        ddrWriteTimes = []
        ddrReadTimes = []

        n_cycles_total = int(np.sum(cycles)) * repeat
        pbar = self._get_pbar(n_cycles_total, "Benchmarking PS...")

        for c in cycles:
            payload = np.array([c], dtype=self.protocol.dtype)
            msg = Message(self.uuid, Command.PERFORMANCE_TEST, payload)

            userCylces: float = 0
            streamCycles: float = 0
            ddrWriteTime: float = 0
            ddrReadTime: float = 0
            for _ in range(repeat):
                resp = self._send_and_receive(msg)

                if resp.payload is None:
                    raise XibifResponseError("no payload received!")

                plen = len(resp.payload)
                if plen != 8:
                    raise XibifResponseError(f"payload with length {plen} is invalid")

                userCylces += (resp.payload[1] << 32) + resp.payload[0]
                streamCycles += (resp.payload[3] << 32) + resp.payload[2]
                ddrWriteTime += (resp.payload[5] << 32) + resp.payload[4]
                ddrReadTime += (resp.payload[7] << 32) + resp.payload[6]
                self._display_progress_update(pbar, f"{c} cycles complete", c)

            # Calculate execution time
            # Global time is clocked at half the PS clock frequency
            # /8 because the operations are repeated 8 times on the HW
            # to reduce the impact of loop overhead
            self.read_board_status()
            userTimes.append(userCylces / self.status.nb_frequency / 2 / 8 / c / repeat)
            streamTimes.append(
                streamCycles / self.status.nb_frequency / 2 / 8 / c / repeat
            )
            ddrWriteTimes.append(
                ddrWriteTime / self.status.nb_frequency / 2 / 8 / c / repeat
            )
            ddrReadTimes.append(
                ddrReadTime / self.status.nb_frequency / 2 / 8 / c / repeat
            )

        return np.array(cycles), userTimes, streamTimes, ddrWriteTimes, ddrReadTimes

    def benchmark_stream(
        self,
        n_bytes: list[int] | np.ndarray,
        repeats: int = 5,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Benchmark the XiBIF Stream

        The stream is benchmarked by writing and then reading data to a XiBIF board and measuring
        the time it takes to do so.

        For each element in `n_bytes`, a number of bytes is written to and subsequently read from the FPGA. For each
        number of bytes, the test is repeated `repeats` times and the results are averaged. This helps to compensate
        for possible network fluctuations in non-directly connected boards.

        Attention: for the benchmark to be successful, the write stream needs to be connected to the read stream,
        which is the case for the demo project just after `xibif setup`

        Parameters
        ---------
            n_bytes: list[int]
                A list of the amount of bytes to use for the benchmark. For each element in the list, a separate
                read and write test pair is executed.
            repeats: int
                The number of times to repeat each of the read-write pair tests.

        Returns
        -------
            n_bytes, speeds_rx, speeds_tx : list[int], list[float], list[float]
                A tuple of lists. The first element contains the list of number of bytes used for each test.
                The second and third element contain the read and write data rates for the stream actions as viewed
                from the computer running the benchmark. The data rates are in bits/s.
        """

        amounts = []
        speeds_tx = []
        speeds_rx_all = []

        n_bits_total = int(np.sum(n_bytes)) * 8 * repeats * 2
        pbar = self._get_pbar(
            total=int(n_bits_total / 8), description="Benchmarking stream..."
        )

        # sweep over data amounts
        for amount in n_bytes:
            amount = int(amount)
            amounts.append(amount)
            amount_speeds_tx = []
            amount_speeds_rx_all = []

            # repeats for averaging
            for i in range(repeats):
                self.flush_stream()
                if pbar is not None:
                    pbar.set_description(
                        f"Benchmarking stream with {amount / 1e3:.0f}kbit ({i + 1:>3}/{repeats:>3})"
                    )
                duration_tx = self.benchmark_stream_write(
                    amount, repeats=1, quiet=True, skip_flush=True
                )
                self._display_progress_update(pbar, "", amount)
                duration_rx = self.benchmark_stream_read(
                    amount, repeats=1, quiet=True, skip_write=True
                )
                self._display_progress_update(pbar, "", amount)

                amount_speeds_tx.append(amount * 8 / duration_tx)
                amount_speeds_rx_all.append(amount * 8 / duration_rx)

            speeds_tx.append(np.mean(amount_speeds_tx))
            speeds_rx_all.append(np.mean(amount_speeds_rx_all))

        if pbar is not None:
            pbar.close()
        return np.array(amounts), np.array(speeds_tx), np.array(speeds_rx_all)

    def benchmark_ping(
        self, repeats: int = 100, wait_time: float = 0.001
    ) -> np.ndarray:
        """
        Benchmark the network connection

        The XiBIF board is pinged for a repeat number of times, followed by a wait time.
        After the test, the individual RTTs are returned as an array.

        Parameters
        ----------
            repeats: int = 100
                Number of times to repeat the test
            wait_time: float = 0.001
                Wait time in seconds to wait after each ping test
        """
        transport = TcpTransport(self.ip, self.PORT_ECHO, self.timeout)
        pings = []

        pbar = self._get_pbar(total=repeats, description="Benchmarking ping...")

        for _ in range(repeats):
            pings.append(self.ping(transport=transport))
            time.sleep(wait_time)
            self._display_progress_update(pbar, "Ping", 1)

        return np.array(pings)

    def benchmark_command(
        self, command: Command, repeats: int = 100
    ) -> np.ndarray | None:
        """
        Evaluate the performance of a Command.

        The performance of a command on a XiBIF board is evaluated. When a command
        is dispatched in the PS of the FPGA, the number of clock cycles until its
        completion is measured and returned in the header. This benchmark function
        evaluates a repeated number of command executions to estimate the total
        performance of a given command implementation on the board.

        The amount of cycles is measured between the time that a command has been fully
        received and decoded until the time that the command is seen as completed before
        the data is being sent back from the board.

        The durations that this command returns do not include network latency.

        Parameters
        ----------
            command: Command
                The command to evaluate
            repeats: int = 100
                Number of times to execute the comamand

        Returns
        -------
            times: NDarray[float]
                Expired wall-clock time for each execution of the command.

        Raises
        ------
            XibifError:
                The requested command is not implemented for evaluation yet.
        """
        times = []
        self.read_board_status()
        pbar = self._get_pbar(repeats, description=f"Benchmarking {command} command")
        for i in range(repeats):
            if command == Command.READ_REGISTER:
                self.read(0)
            elif command == Command.WRITE_REGISTER:
                self.write(0, 0)
            elif command == Command.STATUS:
                self.read_board_status()
            else:
                raise XibifError("Command Benchmark not implemented")

            cycles = (
                self._last_response.cycles if self._last_response is not None else -1
            )
            exec_time = cycles / self.status.nb_frequency
            self._display_progress_update(pbar, f"{i + 1}/{repeats}")

            times.append(exec_time)

        return np.array(times)
