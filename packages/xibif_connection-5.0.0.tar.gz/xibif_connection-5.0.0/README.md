# XiBIF Connection

The XiBIF Connection package is an API that allows to interface with a XiBIF board.

## Installation
The XiBIF Connection package is installed via pip:
```bash
pip install xibif-connection 
```
## Features

The XiBIF Connection package offers a set of API functions to ease interfacing with the FPGA, such as:
- read and write registers
- read and write from/to the AXI-Stream
- benchmarking functions
- interactive shell

## Usage
The main API object is `XibifConnection`.
```python
from xibif_connection.api import XibifConnection

board = XibifConnection("192.168.1.10", 0xDEAD_CAFE)
board.connect()
print(board.read(0))
board.write(0, 10)
```

Alternatively, use a `XibifSession`
```python
from xibif_connection.api import XibifSession

with XibifSession("192.168.1.10", 0xDEAD_CAFE) as board:
    print(board.read(0))
    board.write(0, 10)
```

For an interactive connection with your board, use the CLI tool `xibif-connection`:

```bash
> xibif-connection --ip 192.168.1.10 --uuid 0xDEAD_CAFE
xibif> read 0
0x1234_5678
xibif> write 4 10
xibif> read 4
10
xibif> quit
>
```
