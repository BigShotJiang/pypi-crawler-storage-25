"""
This file provides an easy example of basic usage of the
XibifSession API

It shows how to:
    - establish a connection to a board
    - read/write registers
"""

from xibif_connection.api import XibifSession

# you can obtain the IP and UUID of your board by
# observing the serial output during startup
IP = "192.168.1.10" # multiple boards can connect to one host
UUID = 0x83DB3005 # the UUID verifies that you connect to the right board


with XibifSession(ip=IP, uuid=UUID) as board:
    # the connection to the board is automatically
    # established when entering a context

    for address in range(4):
        print(f"Reading register at address 0x{address*4:02X}: {board.read(address=address*4)}")

    board.write(address=0x0C, value=100)
    print(f"Register 0x0C={board.read(address=0x0C)}")
    print(f"Register 0x08={board.read(address=0x08)}")


    # the session is always disconnected automatically when
    # existing the context
