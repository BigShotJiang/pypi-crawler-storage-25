
"""
This file provides an easy example of data streaming
using the XibifConnection API.
"""

from xibif_connection.api import XibifConnection
import numpy as np

# you can obtain the IP and UUID of your board by
# observing the serial output during startup
IP = "192.168.1.10" # multiple boards can connect to one host
UUID = 0x83DB3005 # the UUID verifies that you connect to the right board

board = XibifConnection(ip=IP, uuid=UUID)

# connect to the board using a socket
board.connect()

# ensure that there is no data in the stream FIFOs
board.flush_stream()

# generate a NumPy vector of N_WORDS random 32-bit integers
# the stream API operates on the uint32 datatype
N_WORDS = 100_000
tx = np.random.randint(0, 2**32, N_WORDS, dtype=np.uint32)
print(f"Writing {N_WORDS*4} bytes to the FPGA")
board.write_stream(tx)

# the default XiBIF project connects the read and write streams
# to form a loopback interface
print(f"Reading {N_WORDS*4} bytes from the FPGA")
rx = np.array(board.read_stream(length=N_WORDS))

# compare TX and RX data
if np.any(rx != tx):
    print("Mismatch in transmitted and received data")
    print(rx[rx!=tx])
else:
    print("Transmitted and received data match!")

# end the connection gracefully
board.disconnect()
