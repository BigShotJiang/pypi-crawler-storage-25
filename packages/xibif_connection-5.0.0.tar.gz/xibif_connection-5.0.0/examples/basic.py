"""
This file provides an easy example of basic usage of the
XibifConnection API.

It shows how to:
    - establish a connection to a board
    - read/write registers
"""

from xibif_connection.api import XibifConnection

# you can obtain the IP and UUID of your board by
# observing the serial output during startup
IP = "192.168.1.10" # multiple boards can connect to one host
UUID = 0x83DB3005 # the UUID verifies that you connect to the right board

board = XibifConnection(ip=IP, uuid=UUID)

# connect to the board using a socket
board.connect()

print(board.read_board_status())

# The following registers are available by default
# when you set up a XiBIF project.
for address in range(4):
    print(f"Reading register at address 0x{address*4:02X}: {board.read(address=address*4)}")

board.write(address=0x0C, value=100)
print(f"Register 0x0C={board.read(address=0x0C)}")

# the register at address 0x08 has its input connected
# to the output of register 0x0C
print(f"Register 0x08={board.read(address=0x08)}")

# reset the programmable logic on the FPGA
board.reset()

# end the connection gracefully
board.disconnect()
