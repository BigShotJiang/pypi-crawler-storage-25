#
# Copyright 2026 HojoAI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""HOJO ASR model: audio encoder, Conformer adapter, and causal LM decoding."""

from __future__ import annotations

import json
import os
import argparse
import contextlib
import logging
from omegaconf import OmegaConf
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import torch
import torch.nn as nn
from safetensors.torch import load_file
from torch.utils.data import DataLoader
from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer
from transformers import StoppingCriteria, StoppingCriteriaList
from transformers import WhisperFeatureExtractor
from hojo_asr.wenet.transformer.encoder import ConformerEncoder

from hojo_asr.qwen3_omni_audioencoder import ModifyQwen3OmniMoeAudioEncoder
from hojo_asr.dataset import infer_datapipe
from hojo_asr.utils import prepare_sample


class StopOnTokenSequences(StoppingCriteria):
    """Stop generation when the suffix matches any of the given token sequences."""

    def __init__(self, stop_token_seqs: Optional[List[torch.Tensor]] = None) -> None:
        super().__init__()
        self.stop_token_seqs = stop_token_seqs or []

    def __call__(
        self, input_ids: torch.LongTensor, scores: torch.FloatTensor, **kwargs: Any
    ) -> bool:
        for seq in self.stop_token_seqs:
            tail = input_ids[0, -seq.numel() :]
            if seq.numel() > 0 and torch.all(tail == seq).item():
                return True
        return False

class Config:
    def __init__(self, cfg_path):
        self.config = {}
        config = OmegaConf.load(cfg_path)
        self.config = config

    def _convert_to_dot_list(self, opts):
        if opts is None:
            opts = []

        if len(opts) == 0:
            return opts

        has_equal = opts[0].find("=") != -1
        if has_equal:
            return opts

        return [(opt + "=" + value) for opt, value in zip(opts[0::2], opts[1::2])]

    def _convert_node_to_json(self, node):
        container = OmegaConf.to_container(node, resolve=True)
        return json.dumps(container, indent=4, sort_keys=True)

    def to_dict(self):
        return OmegaConf.to_container(self.config)


class HOJO_ASR(nn.Module):
    """End-to-end ASR: encode speech, concat with LLM token embeddings, then `generate` text."""

    @property
    def device(self) -> torch.device:
        """Device of the first parameter; used to decide whether to enable CUDA autocast."""
        return next(self.parameters()).device

    def autocast_context(self, dtype: torch.dtype = torch.float16):
        """Use autocast on GPU; no-op context on CPU."""
        if self.device.type != "cpu":
            return torch.amp.autocast("cuda", dtype=dtype)
        return contextlib.nullcontext()

    def __init__(
        self,
        base_folder: str,
        config: Dict[str, Any]
    ) -> None:
        super().__init__()
        self.base_folder = base_folder
        self.config = config

        llama_path = os.path.join(self.base_folder, self.config.model.get("llama_path", "")) 
        encoder_path = os.path.join(self.base_folder, self.config.model.get("encoder_path", ""))
        whisper_model_path = os.path.join(self.base_folder, self.config.model.get("whisper_path", ""))

        self.feat_extractor = WhisperFeatureExtractor.from_pretrained(whisper_model_path)

        linear_units = self.config.model.get("linear_units", 1280)
        num_blocks = self.config.model.get("num_blocks", 2)
        input_layer = self.config.model.get("input_layer", "embed")

        num_param = 0
        logging.info('Loading LLaMA Tokenizer llama_path: {}'.format(llama_path))
        self.tokenizer = AutoTokenizer.from_pretrained(llama_path)
        self.tokenizer.add_special_tokens({'pad_token': '[PAD]'})
        self.tokenizer.padding_side = "right"
        self.bos_token_id = self.tokenizer.bos_token_id

        logging.info('Loading LLaMA Model')
        self.decoder_model = AutoModelForCausalLM.from_pretrained(llama_path, torch_dtype=torch.bfloat16)

        if any('qwen' in arch.lower() for arch in self.decoder_model.config.architectures):
            qwen_special_token = self.tokenizer.additional_special_tokens[0] # "<|im_start|>"
            self.bos_token_id = self.tokenizer.get_vocab()[qwen_special_token]
        
        llm_num_param = sum([p.numel() for p in self.decoder_model.parameters()])
        num_param += llm_num_param
        # logging.info("llm_num_param: {:.3f} M".format(llm_num_param / 1024 /1024))
        self.decoder_model.resize_token_embeddings(len(self.tokenizer)) 
        
        # load qwen3-omni encoder
        logging.info('Loading Encoder')
        omni_config = AutoConfig.from_pretrained(encoder_path)
        audio_config = omni_config.thinker_config.audio_config
        audio_config.n_window = 1500
        audio_config.n_window_infer = 3000
        audio_config._attn_implementation = "flash_attention_2"
        self.speech_encoder = ModifyQwen3OmniMoeAudioEncoder(audio_config)
        encoder_output_size = omni_config.thinker_config.audio_config.output_dim
        
        speech_num_param = sum([p.numel() for p in self.speech_encoder.parameters()])
        num_param += speech_num_param
        # logging.info("speech_num_param: {:.3f} M".format(speech_num_param / 1024 /1024))

        self.bottleneck = ConformerEncoder(
            encoder_output_size,
            self.decoder_model.config.hidden_size, 
            linear_units=linear_units, 
            num_blocks=num_blocks, 
            input_layer=input_layer
        )

        self.ln_speech = nn.LayerNorm(self.decoder_model.config.hidden_size)
        bottleneck_num_param = sum([p.numel() for p in self.bottleneck.parameters()])
        num_param += bottleneck_num_param
        # logging.info("bottleneck_num_param: {:.3f} M".format(bottleneck_num_param / 1024 /1024))

    def build_padding_mask(self, lengths: torch.Tensor, max_len: int = 0) -> torch.Tensor:
        """Build a 2D boolean mask where True marks padded positions.

        Args:
            lengths: Per-sequence valid lengths, shape (B,).
            max_len: Time-axis cap; 0 means use the max length in the batch.

        Returns:
            Boolean tensor of shape (B, T); True means that timestep is padding.
        """
        batch_size = lengths.size(0)
        max_len = max_len if max_len > 0 else int(lengths.max().item())
        time_idx = torch.arange(max_len, dtype=torch.int64, device=lengths.device)
        time_grid = time_idx.unsqueeze(0).expand(batch_size, max_len)
        len_grid = lengths.unsqueeze(-1)
        return time_grid >= len_grid

    def encode_speech(
        self,
        spectrogram: torch.Tensor,
        spectrogram_lengths: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Mel features -> audio encoder -> Conformer bottleneck."""
        n_window_infer = 3000
        with self.autocast_context():
            B = spectrogram.shape[0]

            max_len = spectrogram.size(1)
            valid_mask = ~self.build_padding_mask(spectrogram_lengths, max_len).to(spectrogram.device)

            packed_input = spectrogram[valid_mask].transpose(0, 1)
            enc_states = self.speech_encoder(packed_input, spectrogram_lengths)
            hidden = enc_states.last_hidden_state

            remainder = spectrogram_lengths % n_window_infer
            sub_len = (remainder - 1) // 2 + 1
            per_chunk = ((sub_len - 1) // 2 + 1 - 1) // 2 + 1 + \
                    (spectrogram_lengths // n_window_infer) * int(np.ceil(n_window_infer / 8))

            split_sizes = per_chunk.tolist()
            segments = hidden.split(split_sizes, dim=0)

            speech_embeddings = torch.nn.utils.rnn.pad_sequence(segments, batch_first=True, padding_value=0.0)
            max_T = speech_embeddings.size(1)

            enc_pad_mask = ~self.build_padding_mask(per_chunk, max_T).to(speech_embeddings.device)

            length_for_adapter = enc_pad_mask.sum(dim=1).to(speech_embeddings.device)

            speech_embeddings, attn = self.bottleneck(speech_embeddings, length_for_adapter)
            speech_embeddings = self.ln_speech(speech_embeddings)
            attn = attn.squeeze(1)

        return speech_embeddings, attn

    def infer(
        self,
        batch: Dict[str, Any],
        generation_config: Dict[str, Any],
        cuda_device_index: int = 0,
    ) -> List[str]:
        """Decode one batch (already moved to device by `prepare_sample`); returns a list of strings."""
        spectrogram = batch["spectrogram"]
        spectrogram_lengths = batch["spectrogram_lens"]
        batch_size = spectrogram.shape[0]

        speech_embeddings, speech_attn = self.encode_speech(
            spectrogram,
            spectrogram_lengths,
        )

        bos_column = speech_attn[:, :1]
        bos_ids = (
            torch.ones(batch_size, 1, dtype=torch.int32, device=speech_embeddings.device)
            * self.bos_token_id
        )
        bos_embeds = self.decoder_model.model.embed_tokens(bos_ids)
        inputs_embeds = torch.cat([bos_embeds, speech_embeddings], dim=1)
        attention_mask = torch.cat([bos_column, speech_attn], dim=1)

        stop_tensor = torch.tensor([-100]).cuda(cuda_device_index)
        criteria = StoppingCriteriaList(
            [StopOnTokenSequences(stop_token_seqs=[stop_tensor])]
        )

        max_tokens = generation_config.get("max_new_tokens", 200)
        feat_len = speech_embeddings.size(1)
        max_new_tokens = min(max_tokens, int(feat_len * 2) + 10) 
        max_new_tokens = max(max_new_tokens, 10)

        eos_token_id = self.tokenizer.eos_token_id

        output_ids = self.decoder_model.generate(
            inputs_embeds=inputs_embeds,
            max_new_tokens=max_new_tokens,
            eos_token_id=eos_token_id,
            #max_new_tokens=generation_config.get("max_new_tokens", 200),
            stopping_criteria=criteria,
            num_beams=generation_config.get("num_beams", 4),
            do_sample=generation_config.get("do_sample", False),
            min_length=generation_config.get("min_length", 1),
            temperature=generation_config.get("temperature", 1.0),
            top_p=generation_config.get("top_p", 0.9),
            repetition_penalty=generation_config.get("repetition_penalty", 1.0),
            length_penalty=generation_config.get("length_penalty", 1.0),
            attention_mask=attention_mask,
        )
        return self.tokenizer.batch_decode(output_ids, add_special_tokens=False)

    def run_infer(
        self,
        audio_input: Union[str, Sequence[str]],
        *,
        seed: int = 777,
        batch_size: int = 1,
        cuda_enabled: bool = True,
    ) -> List[Dict[str, str]]:
        """Run DataPipe + DataLoader; decode every micro-batch (up to ``batch_size`` utterances).

        Pass a list of wav paths and set ``batch_size`` to batch them. Single-utterance
        inference uses ``batch_size=1`` or a one-element list. The DataPipe uses
        ``drop_last=False``, so the last chunk may be smaller than ``batch_size``.

        Returns ``[{"key": ..., "text": ...}, ...]`` in the same order as ``audio_input``.
        """
        generation_config = self.config.generate
        datapipe, source_kind = infer_datapipe(
            audio_input, self.feat_extractor, batch_size=batch_size
        )
        logging.info("Dataset pipeline type is %s", source_kind)
        #logging.info("Dataset pipeline ready (pipe batch_size=%s)", batch_size)

        rng = torch.Generator()
        rng.manual_seed(seed)
        loader = DataLoader(datapipe, batch_size=None, generator=rng)

        total_res: List[Dict[str, str]] = []
        self.eval()
        with torch.no_grad():
            for batch in loader:
                batch_data = prepare_sample(batch, cuda_enabled=cuda_enabled)
                n = batch_data["spectrogram"].shape[0]
                # logging.info("Decoding batch size: %s", n)

                keys = batch_data["id"]
                original_index = batch_data.get("original_index", list(range(n)))
                with self.autocast_context():
                    texts = self.infer(batch_data, generation_config)

                batch_results: List[Optional[Dict[str, str]]] = [None] * n
                for j in range(n):
                    key = keys[j] if isinstance(keys[j], str) else str(keys[j])
                    text = texts[j]
                    text = (
                        text.replace("<|im_end|>", "")
                        .replace("<|endoftext|>", "")
                        .strip()
                    )
                    orig = original_index[j]
                    batch_results[orig] = {"key": key, "text": text}
                total_res.extend(batch_results)
        return total_res

    @classmethod
    def load_model(
        cls,
        folder_path: str,
        device: str = "cuda:0"
    ) -> HOJO_ASR:
        """Load weights from safetensors, and set eval mode."""

        safetensors_path = os.path.join(folder_path, "merged_full_model.safetensors")
        config_path = os.path.join(folder_path, "config.yaml")
        cfg = Config(config_path)

        model = cls(base_folder=folder_path, config=cfg.config)
        
        state = load_file(safetensors_path)
        model.load_state_dict(state, strict=True)
        model.to(device)
        model.eval()
        logging.info("Loaded weights from %s", safetensors_path)
        return model
