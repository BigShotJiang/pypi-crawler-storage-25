import click


@click.group()
def cli():
    """Welcome to the pyRSS CLI"""

    pass


if __name__ == "__main__":
    cli()
