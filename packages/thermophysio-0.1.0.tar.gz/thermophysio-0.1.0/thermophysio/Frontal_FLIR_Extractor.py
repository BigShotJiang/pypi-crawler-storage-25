#!/usr/bin/env python3
"""
Frontal_FLIR_Extractor.py

Single-camera FLIR analyser for frontal head experiments.
Uses MediaPipe Face Mesh (468 landmarks) to anchor anatomical regions.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ROI mesh is loaded from mesh_defs.json via mesh_loader.py — edit it      ║
║  with frontal_mesh_editor.py (press J to export) then push to GitHub.     ║
╚══════════════════════════════════════════════════════════════════════════════╝

Each region in REGION_DEFS is an ordered polygon vertex list.
Vertex specs:
    ('mp',  idx)   – position of MediaPipe Face Mesh landmark #idx
                     (auto-tracks the face — not draggable)
    ('free', name) – draggable anchor defined in FREE_ANCHORS

FREE_ANCHORS default positions use two anatomical scale lengths:
    D_eye  = pixel distance, outer L-eye corner (lm 33)  →  outer R-eye corner (lm 263)
    H_nose = pixel distance, eye midpoint                →  nose tip (lm 4)

Default pos  =  lm[ref_mp]  +  dx0 * D_eye  * [1, 0]
                              +  dy0 * H_nose * [0, 1]
    dx0 > 0 → rightward in image     dy0 > 0 → downward (toward chin)
    dx0 < 0 → leftward               dy0 < 0 → upward   (toward forehead)

Offsets stored as (frac_x, frac_y) fractions of (D_eye, H_nose).
Adjusted pos = default pos + (frac_x * D_eye,  frac_y * H_nose)
Offsets persist across every image in the session; Reset clears all.

Image-left side = subject's anatomical RIGHT.
Image-right side = subject's anatomical LEFT.

Key MediaPipe 468-landmark reference (pixel coords, y-down):
  Outer L-eye: 33  |  Inner L-eye: 133  |  Outer R-eye: 263  |  Inner R-eye: 362
  Nose tip: 4      |  Glabella/bridge: 6, 168                 |  Subnasale: 2
  L-mouth corner: 61  |  R-mouth corner: 291  |  Lip top: 0  |  Lip bottom: 17
  Chin tip: 152    |  L-jaw/ear area: 234, 127, 93            |  R-jaw/ear area: 454, 356, 323
  Forehead centre: 10, 151  |  Forehead L: 109, 67, 103       |  Forehead R: 338, 297, 332
  L nose/alar: 49, 64, 98   |  R nose/alar: 279, 294, 327
"""

import os
import sys
import argparse
import tkinter as tk
import urllib.request
import tempfile
from datetime import datetime, timedelta

import cv2
import numpy as np
from PIL import Image
import flyr

from .shared_utils import (get_capture_time, get_polygon_values,
                          _save_overlay, _save_pixels, _write_meta)

try:
    import mediapipe as _mediapipe
    from mediapipe.tasks import python       as _mp_python
    from mediapipe.tasks.python import vision as _mp_vision
    _MP_OK = True
except ImportError:
    _mediapipe = _mp_python = _mp_vision = None
    _MP_OK = False
    print("[WARN] mediapipe not installed — run:  pip install mediapipe")

# Face Landmarker model — downloaded once to temp dir and reused
_MODEL_URL  = ("https://storage.googleapis.com/mediapipe-models/"
               "face_landmarker/face_landmarker/float16/1/face_landmarker.task")
_MODEL_PATH = os.path.join(tempfile.gettempdir(), "face_landmarker.task")

# ── ROI mesh — populated at runtime by run() via load_mesh("frontal") ─────────
FREE_ANCHORS = None   # OrderedDict set by run() on first call
REGION_DEFS  = None   # OrderedDict set by run() on first call

# ── Geometry ──────────────────────────────────────────────────────────────────

def compute_basis(lm):
    """
    Compute anatomical scale lengths from detected landmarks.
    lm: dict {idx: np.array([x, y])}
    Returns (D_eye, H_nose, eye_mid) or (None, None, None).
    """
    if 33 not in lm or 263 not in lm or 4 not in lm:
        return None, None, None
    l_outer  = lm[33].astype(float)
    r_outer  = lm[263].astype(float)
    nose_tip = lm[4].astype(float)
    D_eye    = float(np.hypot(*(r_outer - l_outer)))
    if D_eye < 1:
        return None, None, None
    eye_mid = (l_outer + r_outer) / 2.0
    H_nose  = float(np.hypot(*(nose_tip - eye_mid)))
    if H_nose < 1:
        H_nose = D_eye * 0.80   # fallback: nose ≈ 0.8× inter-ocular distance below midpoint
    return D_eye, H_nose, eye_mid


def compute_anchor_defaults(lm, D_eye, H_nose):
    """Return {anchor_name: np.array([x, y])} for every FREE_ANCHOR using current landmarks."""
    defaults = {}
    for name, defn in FREE_ANCHORS.items():
        ref_idx = defn['ref_mp']
        if ref_idx not in lm:
            continue
        ref = lm[ref_idx].astype(float)
        defaults[name] = np.array([
            ref[0] + defn['dx0'] * D_eye,
            ref[1] + defn['dy0'] * H_nose,
        ])
    return defaults


def apply_offsets(defaults, offsets, D_eye, H_nose):
    """Apply (frac_x, frac_y) offsets to default anchor positions."""
    result = {}
    for name, pos in defaults.items():
        if name in offsets:
            fx, fy = offsets[name]
            result[name] = pos + np.array([fx * D_eye, fy * H_nose])
        else:
            result[name] = pos.copy()
    return result


def pixel_delta_to_fractions(delta_px, D_eye, H_nose):
    """Convert pixel drag delta → (frac_x, frac_y) in (D_eye, H_nose) units."""
    return (float(delta_px[0]) / D_eye, float(delta_px[1]) / H_nose)


def build_region_polys(lm, anchor_pos):
    """
    Build {region_name: np.int32 polygon array} from landmarks + anchor positions.
    Regions with any missing vertex are silently skipped.
    """
    polys = {}
    for rname, defn in REGION_DEFS.items():
        pts = []
        ok  = True
        for spec in defn['poly']:
            if spec[0] == 'mp':
                idx = spec[1]
                if idx not in lm:
                    ok = False; break
                pts.append(lm[idx].astype(float))
            else:                        # 'free'
                aname = spec[1]
                if aname not in anchor_pos:
                    ok = False; break
                pts.append(anchor_pos[aname].astype(float))
        if ok and len(pts) >= 3:
            polys[rname] = np.array(pts, dtype=np.int32)
    return polys


def draw_regions(base_bgr, region_polys):
    """Filled + outlined region polygons with centred labels on a copy of base_bgr."""
    canvas = base_bgr.copy()
    for rname, poly in region_polys.items():
        defn   = REGION_DEFS.get(rname, {})
        color  = defn.get('color', (128, 128, 128))
        alpha  = defn.get('alpha', 0.40)
        overlay = canvas.copy()
        cv2.fillPoly(overlay, [poly.reshape(-1, 1, 2)], color)
        cv2.addWeighted(overlay, alpha, canvas, 1 - alpha, 0, canvas)
        cv2.polylines(canvas, [poly.reshape(-1, 1, 2)], True, color, 2, cv2.LINE_AA)
        ctr = poly.mean(axis=0).astype(int)
        cv2.putText(canvas, rname, tuple(ctr),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, (0, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(canvas, rname, tuple(ctr),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, color, 1, cv2.LINE_AA)
    return canvas


# ── FLIR / image loading ──────────────────────────────────────────────────────

def load_flir_thermal_and_display(path):
    thermal = None
    try:
        bundle  = flyr.unpack(path)
        thermal = bundle.celsius.astype(np.float32)
        optical = bundle.optical
        if optical is not None and optical.size > 0:
            return thermal, optical.astype(np.uint8)
    except Exception as exc:
        print(f"  [flyr] failed: {exc}")
        thermal = None
    try:
        rgb = np.array(Image.open(path).convert("RGB"))
        return thermal, rgb
    except Exception:
        pass
    if thermal is not None:
        return thermal, thermal
    raise RuntimeError("Could not load any image data.")
def to_bgr(arr):
    if arr.ndim == 2:
        return cv2.cvtColor(arr.astype(np.uint8), cv2.COLOR_GRAY2BGR)
    if arr.shape[2] == 4:
        arr = arr[:, :, :3]
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


# ── MediaPipe detection (Tasks API — mediapipe ≥ 0.10) ───────────────────────

_face_landmarker_instance = None   # lazy singleton — reused across all images


def _get_face_landmarker():
    global _face_landmarker_instance
    if _face_landmarker_instance is not None:
        return _face_landmarker_instance
    if not _MP_OK:
        return None
    if not os.path.exists(_MODEL_PATH):
        print(f"[MP] Downloading face landmarker model (~6 MB) to:\n     {_MODEL_PATH}")
        try:
            urllib.request.urlretrieve(_MODEL_URL, _MODEL_PATH)
            print("[MP] Download complete.")
        except Exception as exc:
            print(f"[MP] Download failed: {exc}")
            return None
    try:
        opts = _mp_vision.FaceLandmarkerOptions(
            base_options=_mp_python.BaseOptions(model_asset_path=_MODEL_PATH),
            num_faces=1,
            min_face_detection_confidence=0.5,
            min_face_presence_confidence=0.5,
            min_tracking_confidence=0.5,
        )
        _face_landmarker_instance = _mp_vision.FaceLandmarker.create_from_options(opts)
    except Exception as exc:
        print(f"[MP] Failed to create FaceLandmarker: {exc}")
        return None
    return _face_landmarker_instance


def detect_and_annotate(bgr):
    """
    Run MediaPipe FaceLandmarker (Tasks API) on the BGR image.
    Returns (annotated_bgr, lm) where lm = {idx: np.array([x, y])} or None.
    Draws all landmarks as tiny dots plus highlights on the three basis points.
    """
    base = bgr.copy()
    fl   = _get_face_landmarker()
    if fl is None:
        return base, None
    rgb      = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    mp_image = _mediapipe.Image(image_format=_mediapipe.ImageFormat.SRGB, data=rgb)
    try:
        result = fl.detect(mp_image)
    except Exception as exc:
        print(f"[MP] Detection error: {exc}")
        return base, None
    if not result.face_landmarks:
        return base, None
    h, w = bgr.shape[:2]
    lm = {}
    for idx, landmark in enumerate(result.face_landmarks[0]):
        lm[idx] = np.array([landmark.x * w, landmark.y * h])
    return base, lm


# ── Thermal extraction ────────────────────────────────────────────────────────

# ── Block-time GUI ────────────────────────────────────────────────────────────

def _parse_time(s, date_ref):
    s = s.strip()
    try:
        t = datetime.strptime(s, "%H:%M:%S").time()
    except ValueError:
        raise ValueError(f"'{s}' is not a valid time — use HH:MM:SS format.")
    return datetime.combine(date_ref.date(), t)


def get_block_times_gui(img_times):
    date_ref = img_times[0]; result = {}; confirmed = [False]
    root = tk.Tk(); root.title("Define Block Times")
    root.configure(bg="#1e1e1e"); root.resizable(False, False)
    BG = "#1e1e1e"; FG = "#e8e8e8"; ACCENT = "#00c864"; ERR_COL = "#ff5555"
    ENTRY_BG = "#2d2d2d"; ENTRY_FG = "#ffffff"
    FONT_H = ("Consolas", 11, "bold"); FONT_N = ("Consolas", 10); FONT_S = ("Consolas", 9)

    left = tk.Frame(root, bg=BG, padx=12, pady=12); left.grid(row=0, column=0, sticky="ns")
    tk.Label(left, text="Image timestamps", bg=BG, fg=ACCENT, font=FONT_H).pack(anchor="w", pady=(0, 6))
    frame_list = tk.Frame(left, bg=BG); frame_list.pack(fill="both", expand=True)
    sb = tk.Scrollbar(frame_list, orient="vertical", bg="#333", troughcolor="#222")
    lb = tk.Listbox(frame_list, yscrollcommand=sb.set, bg=ENTRY_BG, fg=FG,
                    selectbackground="#3a3a5c", font=FONT_N, width=32,
                    height=min(30, len(img_times) + 2), borderwidth=0,
                    highlightthickness=1, highlightcolor=ACCENT, highlightbackground="#444")
    sb.config(command=lb.yview); sb.pack(side="right", fill="y")
    lb.pack(side="left", fill="both", expand=True)
    for i, t in enumerate(img_times):
        lb.insert(tk.END, f"  {i+1:3d}.  {t.strftime('%H:%M:%S')}")

    right = tk.Frame(root, bg=BG, padx=24, pady=12); right.grid(row=0, column=1, sticky="n")
    tk.Label(right, text="Block Times  (HH:MM:SS)", bg=BG, fg=ACCENT, font=FONT_H).grid(
        row=0, column=0, columnspan=2, sticky="w", pady=(0, 14))
    field_defs = [
        ("Block 1  start", "b1_start"), ("Block 1  end",   "b1_end"),
        ("Block 2  start", "b2_start"), ("Block 2  end",   "b2_end"),
        ("Block 3  start", "b3_start"), ("Block 3  end",   "b3_end"),
        ("Session end",    "end_time"),
    ]
    entries = {}; err_labels = {}
    for row_idx, (label, key) in enumerate(field_defs, start=1):
        if key == "end_time":
            sep = tk.Frame(right, bg="#444", height=1)
            sep.grid(row=row_idx * 3 - 1, column=0, columnspan=2, sticky="ew", pady=6)
        tk.Label(right, text=label, bg=BG, fg=FG, font=FONT_N, anchor="w", width=18).grid(
            row=row_idx * 3, column=0, sticky="w", pady=(4, 0))
        var = tk.StringVar()
        e = tk.Entry(right, textvariable=var, bg=ENTRY_BG, fg=ENTRY_FG, font=FONT_N,
                     insertbackground=ACCENT, width=12, relief="flat",
                     highlightthickness=1, highlightcolor=ACCENT, highlightbackground="#555")
        e.grid(row=row_idx * 3, column=1, sticky="w", padx=(8, 0), pady=(4, 0))
        e.bind('<Control-v>', lambda ev, w=e: w.event_generate('<<Paste>>'))
        e.bind('<Control-V>', lambda ev, w=e: w.event_generate('<<Paste>>'))
        err = tk.Label(right, text="", bg=BG, fg=ERR_COL, font=FONT_S)
        err.grid(row=row_idx * 3 + 1, column=0, columnspan=2, sticky="w", pady=(0, 2))
        entries[key] = var; err_labels[key] = err

    tk.Label(right,
             text="Images >5 s before Block 1 start are discarded.\n+1 inside blocks, -1 outside.",
             bg=BG, fg="#888888", font=FONT_S, justify="left").grid(
        row=100, column=0, columnspan=2, sticky="w", pady=(16, 8))
    status_var = tk.StringVar(value="")
    status_lbl = tk.Label(right, textvariable=status_var, bg=BG, fg=ERR_COL, font=FONT_S, justify="left")
    status_lbl.grid(row=101, column=0, columnspan=2, sticky="w")

    def on_confirm():
        for lbl in err_labels.values(): lbl.config(text="")
        status_var.set(""); status_lbl.config(fg=ERR_COL)
        parsed = {}; has_error = False
        for label, key in field_defs:
            raw = entries[key].get().strip()
            if not raw:
                err_labels[key].config(text="  required"); has_error = True; continue
            try:
                parsed[key] = _parse_time(raw, date_ref)
            except ValueError as exc:
                err_labels[key].config(text=f"  {exc}"); has_error = True
        if has_error: return
        order_checks = [
            ("b1_start", "b1_end",   "Block 1 start must be before Block 1 end"),
            ("b1_end",   "b2_start", "Block 2 start must be after Block 1 end"),
            ("b2_start", "b2_end",   "Block 2 start must be before Block 2 end"),
            ("b2_end",   "b3_start", "Block 3 start must be after Block 2 end"),
            ("b3_start", "b3_end",   "Block 3 start must be before Block 3 end"),
            ("b3_end",   "end_time", "Session end must be after Block 3 end"),
        ]
        for a, b, msg in order_checks:
            if parsed[a] >= parsed[b]:
                status_var.set(msg); return
        cutoff = parsed["b1_start"] - timedelta(seconds=5)
        kept   = [t for t in img_times if t >= cutoff]; n_disc = len(img_times) - len(kept)
        n_on   = sum(1 for t in kept
                     if any(parsed[f"b{n}_start"] <= t <= parsed[f"b{n}_end"] for n in (1, 2, 3)))
        status_var.set(
            f"OK — {len(kept)} kept ({n_disc} discarded),  {n_on} active (+1),  {len(kept)-n_on} baseline (-1)")
        status_lbl.config(fg=ACCENT)
        result.update(parsed); confirmed[0] = True; root.after(800, root.destroy)

    tk.Button(right, text="Confirm", command=on_confirm,
              bg="#005533", fg="#00ff88", activebackground="#007744", activeforeground="#ffffff",
              font=("Consolas", 11, "bold"), relief="flat", padx=20, pady=6, cursor="hand2").grid(
        row=102, column=0, columnspan=2, pady=(12, 0), sticky="w")
    root.bind("<Return>", lambda e: on_confirm())
    root.update_idletasks()
    w, h = root.winfo_width(), root.winfo_height()
    root.geometry(f"+{(root.winfo_screenwidth()-w)//2}+{(root.winfo_screenheight()-h)//2}")
    root.mainloop()
    if not confirmed[0]: return None
    return result


# ── Reference series ──────────────────────────────────────────────────────────

def build_reference_series(images, block_times):
    """Filter images to session window and return (filtered, times, z_series)."""
    cutoff = block_times["b1_start"] - timedelta(seconds=5)
    filtered = []; times_kept = []; ref_raw = []
    for img in images:
        t = img["time"]
        if t < cutoff: continue
        active = any(
            block_times[f"b{n}_start"] <= t <= block_times[f"b{n}_end"] for n in (1, 2, 3))
        filtered.append(img); times_kept.append(t)
        ref_raw.append(1.0 if active else -1.0)
    ref_arr = np.array(ref_raw)
    mu  = float(np.mean(ref_arr))
    std = float(np.std(ref_arr, ddof=1)) if len(ref_arr) > 1 else 1.0
    ref_z = (ref_arr - mu) / std if std != 0 else ref_arr - mu
    return filtered, times_kept, ref_z


# ── Interactive display ───────────────────────────────────────────────────────

class FrontalDisplay:
    TARGET_H = 640; BAR_H = 50; INFO_H = 36; CTRL_H = 46
    HANDLE_R = 8;  HIT_R  = 16
    COL_DEFAULT  = (0, 220,  80)
    COL_MODIFIED = (0, 140, 255)
    COL_ACTIVE   = (0, 240, 240)
    COL_BG       = (20,  20,  20)
    RST_COL      = (140,  50,  50)
    FONT = cv2.FONT_HERSHEY_SIMPLEX

    def __init__(self, win, base_bgr, lm, img_info, offsets):
        self.win      = win
        self.base     = base_bgr         # original (unscaled) display image with MP dots
        self.lm       = lm               # dict {idx: np.array([x,y])} or None
        self.img_info = img_info
        self.offsets  = offsets          # shared dict — mutated in-place by drag actions
        self.scale    = self.TARGET_H / base_bgr.shape[0]
        self.cw       = int(base_bgr.shape[1] * self.scale)
        self.img_y0   = self.BAR_H
        self.info_y0  = self.BAR_H + self.TARGET_H
        self.ctrl_y0  = self.info_y0 + self.INFO_H
        self.canvas_h = self.ctrl_y0 + self.CTRL_H
        # populated each render()
        self._basis           = (None, None)   # (D_eye, H_nose)
        self._anchor_defaults = {}             # {name: np.array}  — fresh each frame
        self._anchor_pos      = {}             # {name: np.array}  — with offsets applied
        self._regions         = {}             # {name: np.int32 poly}
        self._drag_name       = None
        cv2.namedWindow(win, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(win, self.cw, self.canvas_h)
        cv2.setMouseCallback(win, self._on_mouse)
        self.render()

    # ── coordinate helpers ─────────────────────────────────────────────────────
    def _btn_reset_rect(self):
        return (10, self.ctrl_y0 + 7, 95, self.ctrl_y0 + self.CTRL_H - 7)

    def _img_to_canvas(self, ix, iy):
        return int(round(ix * self.scale)), int(round(iy * self.scale + self.img_y0))

    def _canvas_to_img(self, cx, cy):
        return cx / self.scale, (cy - self.img_y0) / self.scale

    def _find_nearest_handle(self, cx, cy):
        if not (self.img_y0 <= cy <= self.img_y0 + self.TARGET_H): return None
        best_name, best_d = None, self.HIT_R ** 2
        for name, pos in self._anchor_pos.items():
            hcx, hcy = self._img_to_canvas(pos[0], pos[1])
            d = (cx - hcx) ** 2 + (cy - hcy) ** 2
            if d < best_d: best_d = d; best_name = name
        return best_name

    # ── render ─────────────────────────────────────────────────────────────────
    def render(self):
        if self.lm is not None:
            D, H, _ = compute_basis(self.lm)
            if D is not None:
                self._basis           = (D, H)
                self._anchor_defaults = compute_anchor_defaults(self.lm, D, H)
                self._anchor_pos      = apply_offsets(self._anchor_defaults, self.offsets, D, H)
                self._regions         = build_region_polys(self.lm, self._anchor_pos)
                ann = draw_regions(self.base, self._regions)
            else:
                ann = self.base.copy(); self._regions = {}
        else:
            ann = self.base.copy(); self._regions = {}

        canvas = np.full((self.canvas_h, self.cw, 3), self.COL_BG, dtype=np.uint8)
        img_s  = cv2.resize(ann, (self.cw, self.TARGET_H), interpolation=cv2.INTER_AREA)

        # header bar
        nmod    = sum(1 for v in self.offsets.values() if np.any(np.array(v) != 0))
        mod_str = f"  [{nmod} adjusted]" if nmod else ""
        hdr = np.full((self.BAR_H, self.cw, 3), (28, 28, 28), dtype=np.uint8)
        for txt, yy, sc in [
            (f"FRONTAL  |  {len(self._regions)} regions{mod_str}", 18, 0.50),
            (self.img_info[:110], 36, 0.38),
        ]:
            cv2.putText(hdr, txt, (8, yy), self.FONT, sc, (0, 0, 0),     2, cv2.LINE_AA)
            cv2.putText(hdr, txt, (8, yy), self.FONT, sc, (255, 255, 255), 1, cv2.LINE_AA)
        canvas[0:self.BAR_H, 0:self.cw]                             = hdr
        canvas[self.img_y0:self.img_y0 + self.TARGET_H, 0:self.cw] = img_s

        # info bar
        cv2.rectangle(canvas, (0, self.info_y0), (self.cw, self.info_y0 + self.INFO_H), (18, 18, 18), -1)
        cv2.putText(canvas, self.img_info, (8, self.info_y0 + 24), self.FONT, 0.40, (0, 0, 0),     2, cv2.LINE_AA)
        cv2.putText(canvas, self.img_info, (8, self.info_y0 + 24), self.FONT, 0.40, (190, 190, 190), 1, cv2.LINE_AA)

        # control bar
        cv2.rectangle(canvas, (0, self.ctrl_y0), (self.cw, self.canvas_h), (22, 22, 22), -1)
        cv2.line(canvas, (0, self.ctrl_y0), (self.cw, self.ctrl_y0), (55, 55, 55), 1)
        rx1, ry1, rx2, ry2 = self._btn_reset_rect()
        cv2.rectangle(canvas, (rx1, ry1), (rx2, ry2), self.RST_COL, -1, cv2.LINE_AA)
        cv2.rectangle(canvas, (rx1, ry1), (rx2, ry2), (200, 80, 80),  1, cv2.LINE_AA)
        (tw, th), _ = cv2.getTextSize("Reset", self.FONT, 0.50, 1)
        cx_ = rx1 + ((rx2 - rx1) - tw) // 2; cy_ = ry1 + ((ry2 - ry1) + th) // 2
        cv2.putText(canvas, "Reset", (cx_, cy_), self.FONT, 0.50, (0, 0, 0),     2, cv2.LINE_AA)
        cv2.putText(canvas, "Reset", (cx_, cy_), self.FONT, 0.50, (240, 200, 200), 1, cv2.LINE_AA)
        cv2.putText(canvas,
                    "Drag handles (offsets in D_eye / H_nose fractions, persist to next image)"
                    "  |  Enter=Accept   S=Skip   Q=Quit",
                    (rx2 + 14, self.ctrl_y0 + self.CTRL_H // 2 + 5),
                    self.FONT, 0.34, (110, 110, 110), 1, cv2.LINE_AA)

        self._draw_handles(canvas)
        cv2.imshow(self.win, canvas)

    def _draw_handles(self, canvas):
        for name, pos in self._anchor_pos.items():
            hcx, hcy = self._img_to_canvas(pos[0], pos[1])
            if not (self.img_y0 <= hcy <= self.img_y0 + self.TARGET_H): continue
            if not (0 <= hcx <= self.cw): continue
            is_drag = (self._drag_name == name)
            has_off = name in self.offsets and np.any(np.array(self.offsets[name]) != 0)
            col = (self.COL_ACTIVE   if is_drag else
                   self.COL_MODIFIED if has_off else
                   self.COL_DEFAULT)
            cv2.circle(canvas, (hcx, hcy), self.HANDLE_R, col, -1, cv2.LINE_AA)
            cv2.circle(canvas, (hcx, hcy), self.HANDLE_R, (255, 255, 255), 1, cv2.LINE_AA)
            # label: show only the suffix after first underscore for compactness
            short = name.split('_', 1)[-1] if '_' in name else name
            cv2.putText(canvas, short, (hcx + self.HANDLE_R + 3, hcy - 3),
                        self.FONT, 0.28, (0, 0, 0), 2, cv2.LINE_AA)
            cv2.putText(canvas, short, (hcx + self.HANDLE_R + 3, hcy - 3),
                        self.FONT, 0.28, col, 1, cv2.LINE_AA)

    # ── mouse ──────────────────────────────────────────────────────────────────
    def _on_mouse(self, event, cx, cy, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN:
            rx1, ry1, rx2, ry2 = self._btn_reset_rect()
            if rx1 <= cx <= rx2 and ry1 <= cy <= ry2:
                self.offsets.clear(); self.render(); return
            name = self._find_nearest_handle(cx, cy)
            if name: self._drag_name = name; self.render()

        elif event == cv2.EVENT_MOUSEMOVE:
            if self._drag_name and self._drag_name in self._anchor_defaults:
                D, H = self._basis
                if D is not None:
                    ix, iy   = self._canvas_to_img(cx, cy)
                    def_pos  = self._anchor_defaults[self._drag_name]
                    delta_px = np.array([ix - def_pos[0], iy - def_pos[1]])
                    self.offsets[self._drag_name] = pixel_delta_to_fractions(delta_px, D, H)
                    self.render()

        elif event == cv2.EVENT_LBUTTONUP:
            self._drag_name = None

    @property
    def regions(self): return self._regions

    def destroy(self):
        try: cv2.destroyWindow(self.win)
        except cv2.error: pass


_WIN = "Frontal FLIR  |  Drag handles  |  Enter=Accept  S=Skip  Q=Quit"


def show_image_cv2(base_bgr, lm, img_info, offsets):
    disp = FrontalDisplay(_WIN, base_bgr, lm, img_info, offsets)
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key in (13, 10):
            disp.destroy(); return "accept", disp.regions
        elif key in (ord('s'), ord('S')):
            disp.destroy(); return "skip", {}
        elif key in (ord('q'), ord('Q'), 27):
            disp.destroy(); return "abort", {}
        try:
            if cv2.getWindowProperty(_WIN, cv2.WND_PROP_VISIBLE) < 1:
                disp.destroy(); return "abort", {}
        except cv2.error:
            disp.destroy(); return "abort", {}


# ══════════════════════════════════════════════════════════════════════════════
#  Session persistence helpers
#
#  Analysis (z-scoring, deltas, cross-correlation, CSV) lives in
#  FLIR_Analyser.py and can be re-run at any time without re-scanning images.
#
#  Per accepted image this extractor saves:
#    overlays/<label>.png  — annotated display image (open to verify masks)
#    pixels/<label>.npz   — { region_name : float32 temperature array }
#  Plus session_meta.json indexing everything.
# ══════════════════════════════════════════════════════════════════════════════

# ── callable API ─────────────────────────────────────────────────────────────

def run(img_dir: str, out_dir: str):
    """
    Extract frontal thermal ROIs from a directory of FLIR images.

    Opens the block-time GUI and a per-image interactive display for the
    researcher to adjust anatomical region overlays.

    Parameters
    ----------
    img_dir : path to folder of FLIR JPEG images
    out_dir : output session directory (created if missing)

    Returns
    -------
    dict   session metadata on success
    None   if the researcher cancels the GUI or accepts no images

    Raises
    ------
    RuntimeError  if mediapipe is not installed or no JPEG images are found
    """
    if not _MP_OK:
        raise RuntimeError("mediapipe not installed — run:  pip install mediapipe")

    global FREE_ANCHORS, REGION_DEFS
    from .mesh_loader import load_mesh
    FREE_ANCHORS, REGION_DEFS = load_mesh("frontal")

    os.makedirs(os.path.join(out_dir, "overlays"), exist_ok=True)
    os.makedirs(os.path.join(out_dir, "pixels"),   exist_ok=True)

    # ── scan images ───────────────────────────────────────────────────────────
    paths = [os.path.join(img_dir, f) for f in os.listdir(img_dir)
             if os.path.splitext(f)[1].lower() in {".jpg", ".jpeg"}]
    images = sorted(
        [{"path": p, "time": get_capture_time(p)} for p in paths],
        key=lambda x: x["time"])
    if not images:
        raise RuntimeError(f"No JPEG images found in '{img_dir}'")
    print(f"Found {len(images)} images.")

    # ── block-time GUI ────────────────────────────────────────────────────────
    print("\nOpening block-time GUI ...")
    block_times = get_block_times_gui([img["time"] for img in images])
    if block_times is None:
        print("Cancelled — no output written.")
        return None

    # ── filter images to session window ───────────────────────────────────────
    filtered, times_kept, ref_series_z = build_reference_series(images, block_times)
    n_disc = len(images) - len(filtered)
    print(f"\nBlock times confirmed.")
    print(f"  Images discarded (>5 s before Block 1): {n_disc}")
    print(f"  Images kept:     {len(filtered)}")
    print(f"  Active (+1):     {int(np.sum(ref_series_z > 0))}")
    print(f"  Baseline (-1):   {int(np.sum(ref_series_z <= 0))}")
    if not filtered:
        raise RuntimeError("No images remain after filtering.")

    print(f"\nRegions defined: {', '.join(REGION_DEFS.keys())}")
    print(f"Free anchors:    {', '.join(FREE_ANCHORS.keys())}")
    print(f"\nDrag handles to adjust regions.  Enter=Accept  S=Skip  Q=Quit\n")

    offsets    = {}
    timepoints = []

    for idx, img_item in enumerate(filtered):
        t          = times_kept[idx]
        ref_val    = float(ref_series_z[idx])
        active_str = "ACTIVE (+1)" if ref_val > 0 else "baseline (-1)"
        print(f"\n[{idx+1}/{len(filtered)}]  {t.strftime('%H:%M:%S')}  [{active_str}]  "
              f"{os.path.basename(img_item['path'])}")

        try:
            thermal, disp = load_flir_thermal_and_display(img_item["path"])
        except Exception as exc:
            print(f"  ERROR loading: {exc} — skipping"); continue

        bgr  = to_bgr(disp)
        base, lm = detect_and_annotate(bgr)

        if lm is None:
            print("  [MP] No face detected — image will be displayed for manual review.")
        else:
            D, H, _ = compute_basis(lm)
            if D is not None:
                print(f"  [MP] Face detected.  D_eye={D:.1f} px   H_nose={H:.1f} px")
            else:
                print("  [MP] Face detected but basis is degenerate.")

        nmod = sum(1 for v in offsets.values() if np.any(np.array(v) != 0))
        if nmod:
            print(f"  Carrying over {nmod} non-zero offset(s).")

        img_info = (f"Img {idx+1}/{len(filtered)}"
                    f"  |  {t.strftime('%H:%M:%S')}  [{active_str}]"
                    f"  |  {os.path.basename(img_item['path'])}")

        action, regions = show_image_cv2(base, lm, img_info, offsets)

        if action == "abort":
            print("  Aborted."); break
        if action == "skip":
            print("  Skipped."); continue

        # ── save overlay ──────────────────────────────────────────────────────
        label       = f"T{idx+1:03d}_{t.strftime('%Y-%m-%d_%H-%M-%S')}"
        overlay_bgr = draw_regions(base, regions)
        rel_overlay = _save_overlay(out_dir, label, overlay_bgr)

        # ── extract and save raw thermal pixel arrays + pixel coordinates ─────
        pixel_dict = {}
        for rname, poly in regions.items():
            vals, coords = get_polygon_values(thermal, poly, disp.shape)
            pixel_dict[rname]              = vals
            pixel_dict[f"{rname}__coords"] = coords
            m = float(np.mean(vals))
            v = float(np.var(vals, ddof=1)) if vals.size > 1 else 0.0
            print(f"    {rname:20s}  mean={m:7.3f}  var={v:.4f}  npx={int(vals.size)}")
        rel_pixels = _save_pixels(out_dir, label, pixel_dict)

        active = any(
            block_times[f"b{n}_start"] <= t <= block_times[f"b{n}_end"]
            for n in (1, 2, 3))

        timepoints.append({
            "index":        idx,
            "label":        label,
            "timestamp":    t.isoformat(),
            "elapsed_s":    round((t - times_kept[0]).total_seconds(), 3),
            "active":       active,
            "source_filename": os.path.basename(img_item["path"]),
            "overlay_file": rel_overlay,
            "pixel_file":   rel_pixels,
            "regions":      list(pixel_dict.keys()),
        })

    if not timepoints:
        print("\nNo images processed — session not saved.")
        return None

    # ── write session metadata ────────────────────────────────────────────────
    meta = {
        "session_type": "frontal",
        "created":      datetime.now().isoformat(),
        "source_dir":   img_dir,
        "block_times":  {k: v.isoformat() for k, v in block_times.items()},
        "n_timepoints": len(timepoints),
        "timepoints":   timepoints,
    }
    _write_meta(out_dir, meta)

    n = len(timepoints)
    print(f"\nExtraction complete.  {n} images saved.")
    print(f"  Overlays : {out_dir}/overlays/  ({n} PNG files)")
    print(f"  Pixels   : {out_dir}/pixels/   ({n} NPZ files)")

    return meta


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="Frontal FLIR extractor — Stage 1: segmentation and raw data extraction")
    ap.add_argument("img_dir", help="Folder of FLIR JPEG images")
    ap.add_argument("out_dir", help="Output session directory (will be created)")
    args = ap.parse_args()
    result = run(args.img_dir, args.out_dir)
    if result is None:
        sys.exit(0)


if __name__ == "__main__":
    main()
