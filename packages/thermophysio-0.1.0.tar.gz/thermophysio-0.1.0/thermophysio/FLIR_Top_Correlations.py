"""
FLIR_Top_Correlations.py
========================
Produce a global top-N summary across all (feature × region-pair) combinations
after FLIR_CrossROI_Analysis has run.

Usage
-----
    python FLIR_Top_Correlations.py <ccf_table.csv> <resampled.csv> [out_dir]
           [--top-n 10] [--max-lag N] [--alpha 0.05]

Arguments
---------
    ccf_table.csv   path to the table written by FLIR_CrossROI_Analysis.analyse()
    resampled.csv   path to the uniform-grid CSV from FLIR_TimeSeries.resample()
    out_dir         output directory (default: same directory as ccf_table.csv)
    --top-n         how many top pairs to display (default: 10)
    --max-lag       maximum CCF lag for re-computation (default: n_timepoints // 3)
    --alpha         Bartlett CI level (default: 0.05)

Outputs (written to out_dir, same level as ccf_table.csv)
----------------------------------------------------------
    top10_leaderboard.png   ranked horizontal bar chart — feature | pair vs |CCF|
    top10_ccf_grid.png      5×2 grid of full CCF curves for the top-N pairs
"""

import os
import sys
import csv
import math
import argparse

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches

from .shared_utils import cross_covariance_bartlett, _safe_float  # noqa: E402
from .FLIR_CrossROI_Analysis import read_resampled_csv            # noqa: E402


# ── helpers ───────────────────────────────────────────────────────────────────

def _load_top_n(ccf_table_csv, top_n):
    """Read ccf_table.csv and return the top-N rows sorted by |best_ccf| desc."""
    rows = []
    with open(ccf_table_csv, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            bcf = _safe_float(row.get("best_ccf", ""))
            if not math.isfinite(bcf):
                continue
            _ci = _safe_float(row.get("ci_bound", ""))
            _se = _safe_float(row.get("se_bartlett", ""))
            rows.append({
                "feature":     row["feature"].strip(),
                "pair":        row["pair"].strip(),
                "best_lag":    int(float(row.get("best_lag", 0))),
                "best_ccf":    bcf,
                "ci_bound":    _ci if math.isfinite(_ci) else 0.0,
                "se_bartlett": _se if math.isfinite(_se) else 0.0,
                "significant": row.get("significant", "False").strip() == "True",
            })

    rows.sort(key=lambda r: abs(r["best_ccf"]), reverse=True)
    return rows[:top_n]


def _clean_pair_label(pair_str):
    """'FrontalL_vs_Ear_R' → 'FrontalL  vs  Ear R'"""
    s = pair_str.replace("_vs_", "  vs  ")
    return s.replace("_", " ")


def _recompute_ccf_for_top(top_rows, resampled_csv, max_lag, alpha):
    """Re-read resampled CSV and compute full CCF for each top entry."""
    elapsed_s, feat_data, reference = read_resampled_csv(resampled_csv)
    n_tp = len(elapsed_s)
    eff_max_lag = max_lag if max_lag is not None else max(1, n_tp // 3)

    ref_unique = np.unique(reference[np.isfinite(reference)])
    if len(ref_unique) <= 1:
        ref_z = reference.copy()
    else:
        mu  = float(np.nanmean(reference))
        std = float(np.nanstd(reference, ddof=1))
        ref_z = (reference - mu) / std if std > 0 else reference.copy()

    results = {}
    for row in top_rows:
        feat = row["feature"]
        pair = row["pair"]
        try:
            r_a, r_b = pair.split("_vs_", 1)
            delta = feat_data[feat][r_a] - feat_data[feat][r_b]
            res = cross_covariance_bartlett(ref_z, delta, eff_max_lag, alpha=alpha)
        except (KeyError, ValueError):
            res = None
        results[(feat, pair)] = res

    return results


# ── Plot A: leaderboard ───────────────────────────────────────────────────────

def plot_leaderboard(top_rows, out_path):
    """Horizontal ranked bar chart of top-N pairs."""
    n = len(top_rows)
    y_pos = np.arange(n)

    abs_ccf  = [abs(r["best_ccf"]) for r in top_rows]
    ci_bound = [r["ci_bound"]      for r in top_rows]
    colors   = ["mediumseagreen" if r["significant"] else "lightsalmon"
                for r in top_rows]
    labels   = [f"{r['feature']}  |  {_clean_pair_label(r['pair'])}"
                for r in top_rows]

    fig, ax = plt.subplots(figsize=(10, max(5, n * 0.55)))

    bars = ax.barh(y_pos, abs_ccf, xerr=ci_bound,
                   color=colors, alpha=0.88,
                   error_kw={"elinewidth": 1.2, "capsize": 3, "ecolor": "grey"})

    for i, (bar, row) in enumerate(zip(bars, top_rows)):
        ann = f"lag {row['best_lag']}"
        if row["significant"]:
            ann += " ★"
        x_end = bar.get_width() + ci_bound[i] + 0.02
        ax.text(x_end, bar.get_y() + bar.get_height() / 2,
                ann, va="center", fontsize=7.5)

    ax.set_yticks(y_pos)
    ax.set_yticklabels(labels, fontsize=8.5)
    ax.invert_yaxis()

    ax.set_xlim(0, 1.18)
    ax.set_xlabel("|best CCF|", fontsize=10)
    ax.set_title("Top Correlated Feature–Region Pairs", fontsize=12, fontweight="bold")

    legend_patches = [
        mpatches.Patch(color="mediumseagreen", label="Significant (Bartlett CI)"),
        mpatches.Patch(color="lightsalmon",    label="Not significant"),
    ]
    ax.legend(handles=legend_patches, fontsize=8, loc="lower right")
    ax.axvline(0, color="black", linewidth=0.7)

    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


# ── Plot B: CCF grid ──────────────────────────────────────────────────────────

def plot_ccf_grid(top_rows, ccf_results, out_path):
    """5×2 grid of full CCF bar charts for the top-10 pairs globally."""
    n = len(top_rows)
    nrows, ncols = math.ceil(n / 2), 2

    fig = plt.figure(figsize=(12, 3.6 * nrows))
    gs  = gridspec.GridSpec(nrows, ncols, figure=fig, hspace=0.55, wspace=0.3)

    for i, row in enumerate(top_rows):
        ax  = fig.add_subplot(gs[i // ncols, i % ncols])
        res = ccf_results.get((row["feature"], row["pair"]))

        if res is None:
            ax.text(0.5, 0.5, "Data unavailable",
                    ha="center", va="center", transform=ax.transAxes, fontsize=8)
            ax.set_axis_off()
            continue

        lags = res["lags"]
        ccf  = res["ccf"]
        ci_u = res["ci_upper"]
        ci_l = res["ci_lower"]

        colours = np.where(np.abs(ccf) > ci_u, "tomato", "steelblue")
        ax.bar(lags, ccf, color=colours, alpha=0.85, width=0.8)
        ax.axhline(ci_u, color="red",   linestyle="--", linewidth=0.9)
        ax.axhline(ci_l, color="red",   linestyle="--", linewidth=0.9)
        ax.axhline(0,    color="black", linewidth=0.6)

        star  = " ★" if row["significant"] else ""
        title = (f"#{i+1}  {row['feature']}  |  "
                 f"{_clean_pair_label(row['pair'])}{star}")
        ax.set_title(title, fontsize=7.8)
        ax.tick_params(labelsize=6.5)
        ax.set_xlabel("Lag (timepoints, reference leads)", fontsize=7)

    fig.suptitle("Top CCF Curves — Full Lag Profiles  (★ = significant)",
                 fontsize=12, fontweight="bold", y=1.01)
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


# ── public API ────────────────────────────────────────────────────────────────

def summarise(ccf_table_csv, resampled_csv, out_dir,
              top_n=10, max_lag=None, alpha=0.05):
    """
    Produce global top-N summary plots from a completed CCF analysis.

    Parameters
    ----------
    ccf_table_csv : path to ccf_table.csv written by FLIR_CrossROI_Analysis.analyse()
    resampled_csv : path to stats_resampled.csv written by FLIR_TimeSeries.resample()
    out_dir       : directory where plots are written
    top_n         : number of top pairs to include (default 10)
    max_lag       : CCF max lag for re-computation (default n_timepoints // 3)
    alpha         : Bartlett CI significance level (default 0.05)

    Returns
    -------
    dict with keys 'leaderboard' and 'ccf_grid', or None if no data.
    """
    if not os.path.isfile(ccf_table_csv):
        print(f"[Top-N] WARNING: '{ccf_table_csv}' not found — skipping summary.")
        return None

    top_rows = _load_top_n(ccf_table_csv, top_n)
    if not top_rows:
        print("[Top-N] WARNING: ccf_table.csv contains no finite results — skipping.")
        return None

    os.makedirs(out_dir, exist_ok=True)

    leaderboard_path = os.path.join(out_dir, f"top{top_n}_leaderboard.png")
    grid_path        = os.path.join(out_dir, f"top{top_n}_ccf_grid.png")

    plot_leaderboard(top_rows, leaderboard_path)

    ccf_results = _recompute_ccf_for_top(top_rows, resampled_csv, max_lag, alpha)
    plot_ccf_grid(top_rows, ccf_results, grid_path)

    print(f"\nTop-{top_n} leaderboard : {leaderboard_path}")
    print(f"Top-{top_n} CCF grid    : {grid_path}")

    return {"leaderboard": leaderboard_path, "ccf_grid": grid_path}


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="Global top-N CCF summary plots across all feature–pair combinations.")
    ap.add_argument("ccf_table_csv",
                    help="ccf_table.csv from FLIR_CrossROI_Analysis")
    ap.add_argument("resampled_csv",
                    help="stats_resampled.csv from FLIR_TimeSeries")
    ap.add_argument("out_dir", nargs="?", default=None,
                    help="Output directory (default: same dir as ccf_table.csv)")
    ap.add_argument("--top-n",   type=int,   default=10,   metavar="N",
                    help="Number of top pairs (default: 10)")
    ap.add_argument("--max-lag", type=int,   default=None, metavar="N",
                    help="Maximum CCF lag (default: n_timepoints // 3)")
    ap.add_argument("--alpha",   type=float, default=0.05,
                    help="Bartlett CI significance level (default: 0.05)")
    args = ap.parse_args()

    if args.out_dir is None:
        args.out_dir = os.path.dirname(os.path.abspath(args.ccf_table_csv))

    summarise(args.ccf_table_csv, args.resampled_csv, args.out_dir,
              top_n=args.top_n, max_lag=args.max_lag, alpha=args.alpha)


if __name__ == "__main__":
    main()
