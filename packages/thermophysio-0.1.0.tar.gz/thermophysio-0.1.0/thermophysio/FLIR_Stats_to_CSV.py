#!/usr/bin/env python3
"""
FLIR_Stats_to_CSV.py

Converts the output of Back_FLIR_Extractor.py, Frontal_FLIR_Extractor.py,
or Dual_FLIR_Extractor.py into a CSV summary.

Output format — rows are signals (region × feature), columns are timepoints:

    feature                  | T001_...  | T002_...  | ...
    timestamp                | ISO-str   | ...       |
    elapsed_s                | 0.0       | 15.3      |
    <Region>_mean            | 35.1      | ...       |
    <Region>_variance        | 0.02      | ...       |
    <Region>_max             | 36.1      | ...       |
    <Region>_min             | 34.5      | ...       |
    <Region>_npixels         | 125       | ...       |
    ...  (one block per region)
    reference_activation     | -1        | +1        |

    reference_activation = +1 during active blocks, -1 during baseline.

Usage:
    python FLIR_Stats_to_CSV.py <session_dir> [output.csv]

    <session_dir>  directory produced by any of the three extractors
                   (must contain session_meta.json and a pixels/ sub-folder)
    output.csv     optional output path  (default: <session_dir>/stats.csv)
"""

import os
import sys
import json
import csv
import numpy as np

# shared feature computation (same directory)
from .shared_utils import compute_region_features, FEATURE_NAMES


# ── helpers ───────────────────────────────────────────────────────────────────

def load_meta(session_dir: str) -> dict:
    path = os.path.join(session_dir, "session_meta.json")
    if not os.path.isfile(path):
        sys.exit(f"ERROR: session_meta.json not found in '{session_dir}'")
    with open(path) as f:
        return json.load(f)


def stats_from_npz(npz_path: str, session_dir: str) -> dict:
    """
    Load an NPZ pixel file and return {region_name: feature_dict}.
    Skips keys ending in '__coords'.
    """
    full = os.path.join(session_dir, npz_path)
    if not os.path.isfile(full):
        return {}
    data = np.load(full, allow_pickle=False)
    result = {}
    for key in data.files:
        if key.endswith("__coords"):
            continue
        result[key] = compute_region_features(data[key].astype(np.float64))
    return result


# ── main ──────────────────────────────────────────────────────────────────────

def build_csv(session_dir: str, out_csv: str):
    meta = load_meta(session_dir)
    session_type = meta.get("session_type", "unknown")
    timepoints   = meta.get("timepoints", [])

    if not timepoints:
        sys.exit("ERROR: no timepoints found in session_meta.json")

    print(f"Session type : {session_type}")
    print(f"Timepoints   : {len(timepoints)}")

    # ── collect per-timepoint stats ──────────────────────────────────────────
    # col_labels : list of column header strings (one per timepoint)
    # tp_meta    : list of (timestamp, elapsed_s, active) per timepoint
    # region_data: {region_name: [stat_tuple_per_timepoint]}
    col_labels  = []
    tp_meta     = []
    region_data = {}   # ordered as encountered

    for tp in timepoints:
        col_labels.append(tp["label"])
        tp_meta.append((tp["timestamp"], tp["elapsed_s"], tp["active"]))

        if session_type == "dual":
            # cam_a → regions with suffix already baked in (e.g. Eye-L)
            # cam_b → regions with suffix already baked in (e.g. Eye-R)
            stats_a = stats_from_npz(tp["cam_a"]["pixel_file"], session_dir)
            stats_b = stats_from_npz(tp["cam_b"]["pixel_file"], session_dir)
            combined = {**stats_a, **stats_b}
        else:
            combined = stats_from_npz(tp["pixel_file"], session_dir)

        _nan_stat = {k: (0 if k == "npixels" else float("nan"))
                     for k in FEATURE_NAMES}
        t_idx = len(col_labels) - 1

        # Register new regions, padding all previous timepoints with NaN
        for rname in combined:
            if rname not in region_data:
                region_data[rname] = [_nan_stat] * t_idx  # pad prior timepoints

        # Append this timepoint's stat (or NaN) to every known region
        for rname in region_data:
            region_data[rname].append(combined.get(rname, _nan_stat))

    n_tp = len(col_labels)
    print(f"Regions      : {', '.join(region_data.keys())}")

    # ── build rows ───────────────────────────────────────────────────────────
    # First column header
    header = ["feature"] + col_labels

    rows = []

    # metadata rows
    rows.append(["timestamp"]  + [m[0] for m in tp_meta])
    rows.append(["elapsed_s"]  + [m[1] for m in tp_meta])

    # one block per region, one row per feature
    for rname, stat_list in region_data.items():
        for s_name in FEATURE_NAMES:
            row = [f"{rname}_{s_name}"]
            for t_idx in range(n_tp):
                val = stat_list[t_idx]
                row.append(val[s_name] if val is not None else float("nan"))
            rows.append(row)

    # reference activation row (+1 active, -1 baseline)
    ref_row = ["reference_activation"] + [
        1.0 if m[2] else -1.0 for m in tp_meta
    ]
    rows.append(ref_row)

    # ── write CSV ────────────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(os.path.abspath(out_csv)), exist_ok=True)
    with open(out_csv, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)

    print(f"\nCSV written  : {out_csv}")
    print(f"  Rows       : {len(rows)}  (2 metadata + {len(region_data)} regions × {len(FEATURE_NAMES)} features + 1 reference)")
    print(f"  Columns    : {n_tp} timepoints")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    session_dir = sys.argv[1]
    if not os.path.isdir(session_dir):
        sys.exit(f"ERROR: '{session_dir}' is not a directory")

    out_csv = sys.argv[2] if len(sys.argv) >= 3 else os.path.join(session_dir, "stats.csv")

    build_csv(session_dir, out_csv)


if __name__ == "__main__":
    main()
