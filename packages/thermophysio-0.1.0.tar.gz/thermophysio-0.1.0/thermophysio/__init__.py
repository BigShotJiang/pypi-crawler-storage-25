"""
thermophysio
============

FLIR thermal imaging analysis pipeline for psychophysiology research.

Three extraction entry-points, one per camera / experiment type:

    extract_frontal(img_dir, out_dir, **pipeline_kwargs)
        Face-mesh ROI extraction via MediaPipe (frontal camera).

    extract_back(img_dir, out_dir, model=..., **pipeline_kwargs)
        Ear-region ROI extraction via YOLOv8 pose (back-of-head camera).

    extract_profile(dir_a, dir_b, out_dir, model=..., max_dt=..., **pipeline_kwargs)
        Dual-profile ROI extraction via YOLOv8 keypoints (two side cameras).

All three run the full downstream pipeline automatically:
    ROI extraction  →  FLIR_Stats_to_CSV  →  FLIR_TimeSeries
                    →  FLIR_CrossROI_Analysis  →  FLIR_Top_Correlations

Output layout under out_dir/
    raw/                 session_meta.json, overlays/, pixels/
    stats.csv            10 features × all ROIs × all timepoints
    stats_resampled.csv  uniform Δt grid (spline-interpolated)
    analysis/
        ccf_table.csv    all pairs ranked by |CCF|, with Bartlett CI
        plots/           individual CCF bar charts + top-k grids

Pipeline kwargs accepted by all three functions
-----------------------------------------------
dt        float  resampling step in seconds          (default 5.0)
features  list   feature types for CCF analysis      (default: all 9 signal features)
max_lag   int    maximum CCF lag                      (default n_timepoints // 3)
alpha     float  Bartlett CI significance level       (default 0.05)
top_k     int    pairs per feature in the grid plot   (default 9)

Mesh editors (GUI tools for defining ROI regions)
-------------------------------------------------
Run from the command line after installation:

    thermophysio-mesh-back    [img_dir] [--out mesh_defs.json]
    thermophysio-mesh-frontal [img_dir] [--out mesh_defs.json]
    thermophysio-mesh-profile [img_dir] [--out mesh_defs.json]
"""

import os

from ._pipeline import run_pipeline


# ── public functions ──────────────────────────────────────────────────────────

def extract_frontal(
    img_dir: str,
    out_dir: str,
    **pipeline_kwargs,
) -> dict:
    """
    Run the frontal-camera pipeline (MediaPipe face mesh).

    Parameters
    ----------
    img_dir          : directory of FLIR JPEG images (frontal camera)
    out_dir          : root output directory
    **pipeline_kwargs: dt, features, max_lag, alpha, top_k  (see module docstring)

    Returns
    -------
    dict  with keys: raw_dir, stats_csv, resampled_csv,
                     analysis_dir, ccf_table, plots_dir
    """
    from .Frontal_FLIR_Extractor import run as _run_frontal

    raw_dir = os.path.join(out_dir, "raw")
    os.makedirs(raw_dir, exist_ok=True)

    meta = _run_frontal(img_dir, raw_dir)
    if meta is None:
        raise RuntimeError("Frontal extraction cancelled or produced no output.")

    return run_pipeline(raw_dir, out_dir, **pipeline_kwargs)


def extract_back(
    img_dir: str,
    out_dir: str,
    model: str = "yolov8n-pose.pt",
    **pipeline_kwargs,
) -> dict:
    """
    Run the back-of-head camera pipeline (YOLOv8 pose, ear regions).

    Parameters
    ----------
    img_dir          : directory of FLIR JPEG images (back camera)
    out_dir          : root output directory
    model            : YOLOv8 pose model path or name (default "yolov8n-pose.pt")
    **pipeline_kwargs: dt, features, max_lag, alpha, top_k  (see module docstring)

    Returns
    -------
    dict  with keys: raw_dir, stats_csv, resampled_csv,
                     analysis_dir, ccf_table, plots_dir
    """
    from .Back_FLIR_Extractor import run as _run_back

    raw_dir = os.path.join(out_dir, "raw")
    os.makedirs(raw_dir, exist_ok=True)

    meta = _run_back(img_dir, raw_dir, model=model)
    if meta is None:
        raise RuntimeError("Back extraction cancelled or produced no output.")

    return run_pipeline(raw_dir, out_dir, **pipeline_kwargs)


def extract_profile(
    dir_a: str,
    dir_b: str,
    out_dir: str,
    model: str = "yolov8n-pose.pt",
    max_dt: float = 5.0,
    **pipeline_kwargs,
) -> dict:
    """
    Run the dual-profile camera pipeline (YOLOv8 profile keypoints).

    Parameters
    ----------
    dir_a            : image directory for camera A (left or right profile)
    dir_b            : image directory for camera B (opposite profile)
    out_dir          : root output directory
    model            : YOLOv8 pose model path or name (default "yolov8n-pose.pt")
    max_dt           : maximum allowed timestamp gap for frame pairing, seconds
    **pipeline_kwargs: dt, features, max_lag, alpha, top_k  (see module docstring)

    Returns
    -------
    dict  with keys: raw_dir, stats_csv, resampled_csv,
                     analysis_dir, ccf_table, plots_dir
    """
    from .Dual_FLIR_Extractor import run as _run_dual

    raw_dir = os.path.join(out_dir, "raw")
    os.makedirs(raw_dir, exist_ok=True)

    meta = _run_dual(dir_a, dir_b, raw_dir, model=model, max_dt=max_dt)
    if meta is None:
        raise RuntimeError("Profile extraction cancelled or produced no output.")

    return run_pipeline(raw_dir, out_dir, **pipeline_kwargs)


__all__ = ["extract_frontal", "extract_back", "extract_profile", "run_pipeline"]