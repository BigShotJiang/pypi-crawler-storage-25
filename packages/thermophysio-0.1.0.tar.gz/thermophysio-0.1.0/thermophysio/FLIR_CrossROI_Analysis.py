#!/usr/bin/env python3
"""
FLIR_CrossROI_Analysis.py

Full cross-ROI lagged-linear dependence analysis using normalised
cross-covariance with Bartlett's Formula confidence intervals.

For each selected feature type and every C(n,2) region pair:
  - non-constant reference → CCF vs lag with Bartlett CI bands
  - constant reference     → time-series plot of all regions

Bartlett's Formula widens the CI to account for autocorrelation in both
series, preventing the spurious-correlation trap that naive ±2/√n causes
with thermal time-series data.

Usage:
    python FLIR_CrossROI_Analysis.py <resampled.csv> [out_dir]
           [--features mean entropy kurtosis ...]
           [--max-lag N]
           [--alpha 0.05]
           [--top-k 9]

    resampled.csv   output of FLIR_TimeSeries.py
    out_dir         directory for table + plots
                    (default: same directory as input CSV)
    --features      feature types to analyse
                    (default: mean entropy kurtosis)
    --max-lag N     maximum lag (default: n_timepoints // 3)
    --alpha         CI significance level (default: 0.05)
    --top-k         pairs shown in grid plot per feature (default: 9)
"""

import os
import sys
import csv
import math
import argparse
import itertools
import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

# shared utilities live in the same directory
from .shared_utils import cross_covariance_bartlett, FEATURE_NAMES, _safe_float, _fmt


# ── I/O ───────────────────────────────────────────────────────────────────────


def read_resampled_csv(path: str):
    """
    Parse a resampled stats CSV.

    Returns
    -------
    elapsed_s  : np.ndarray  shape (T,)
    features   : dict[feature_name -> dict[region_name -> np.ndarray]]
    reference  : np.ndarray  shape (T,)
    """
    with open(path, newline="") as f:
        rows = list(csv.reader(f))

    if not rows:
        sys.exit(f"ERROR: '{path}' is empty")

    raw = {}
    for row in rows[1:]:
        if not row:
            continue
        raw[row[0].strip()] = np.array([_safe_float(v) for v in row[1:]])

    elapsed_s = raw.pop("elapsed_s", np.array([]))
    reference  = raw.pop("reference_activation", np.array([]))
    raw.pop("timestamp", None)

    # Group remaining rows by feature suffix
    features = {fn: {} for fn in FEATURE_NAMES}
    for key, arr in raw.items():
        for fn in FEATURE_NAMES:
            if key.endswith(f"_{fn}"):
                rname = key[: -len(fn) - 1]
                features[fn][rname] = arr
                break

    return elapsed_s, features, reference


# ── plotting ──────────────────────────────────────────────────────────────────

_COLOURS = plt.rcParams["axes.prop_cycle"].by_key()["color"]


def plot_timeseries(elapsed_s, region_series, feature_name, out_path):
    """Time-series of all regions for one feature (constant-reference case)."""
    fig, ax = plt.subplots(figsize=(12, 4))
    for i, (rname, series) in enumerate(region_series.items()):
        ax.plot(elapsed_s, series,
                color=_COLOURS[i % len(_COLOURS)],
                linewidth=1.0, label=rname)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel(feature_name)
    ax.set_title(f"Region time series — {feature_name}  [constant reference]")
    ax.legend(fontsize=7, ncol=4, loc="upper right")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_ccf_single(pair_name, feature_name,
                    lags, ccf, ci_upper, ci_lower,
                    out_path):
    """CCF vs lag with Bartlett CI bands for one pair."""
    fig, ax = plt.subplots(figsize=(8, 3.5))

    colours = np.where(np.abs(ccf) > ci_upper, "tomato", "steelblue")
    ax.bar(lags, ccf, color=colours, alpha=0.85, width=0.8)
    ax.axhline(ci_upper, color="red",   linestyle="--", linewidth=1.2,
               label=f"Bartlett ±CI ({ci_upper:.3f})")
    ax.axhline(ci_lower, color="red",   linestyle="--", linewidth=1.2)
    ax.axhline(0,        color="black", linewidth=0.7)

    ax.set_xlabel("Lag (timepoints, reference leads)")
    ax.set_ylabel("Normalised CCF")
    ax.set_title(f"{pair_name}  [{feature_name}]")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_top_grid(top_results, feature_name, top_k, out_path):
    """
    Grid of up to top_k CCF plots for a feature, sorted by |best_ccf|.
    top_results : list of (pair_name, ccf_dict) already sorted descending.
    """
    k    = min(top_k, len(top_results))
    if k == 0:
        return
    cols = min(3, k)
    rows = math.ceil(k / cols)

    fig = plt.figure(figsize=(5 * cols, 3.5 * rows))
    gs  = gridspec.GridSpec(rows, cols, figure=fig, hspace=0.45, wspace=0.3)

    for i, (pname, res) in enumerate(top_results[:k]):
        ax   = fig.add_subplot(gs[i // cols, i % cols])
        lags = res["lags"]
        ccf  = res["ccf"]
        ci_u = res["ci_upper"]
        ci_l = res["ci_lower"]

        colours = np.where(np.abs(ccf) > ci_u, "tomato", "steelblue")
        ax.bar(lags, ccf, color=colours, alpha=0.85, width=0.8)
        ax.axhline(ci_u, color="red",   linestyle="--", linewidth=0.9)
        ax.axhline(ci_l, color="red",   linestyle="--", linewidth=0.9)
        ax.axhline(0,    color="black", linewidth=0.6)

        star = " ★" if res["significant"] else ""
        ax.set_title(f"{pname}{star}", fontsize=7.5)
        ax.tick_params(labelsize=6.5)
        ax.set_xlabel("Lag", fontsize=7)

    fig.suptitle(f"Top {k} pairs — {feature_name}  (★ = significant)",
                 fontsize=10)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


# ── formatting ────────────────────────────────────────────────────────────────

# ── callable API ─────────────────────────────────────────────────────────────

def analyse(
    resampled_csv: str,
    out_dir: str = None,
    features: list = None,
    max_lag: int = None,
    alpha: float = 0.05,
    top_k: int = 9,
) -> str:
    """
    Run cross-ROI CCF analysis with Bartlett CI on a resampled stats CSV.

    Parameters
    ----------
    resampled_csv : path to CSV produced by FLIR_TimeSeries.resample()
    out_dir       : directory for table + plots (default: same dir as CSV)
    features      : feature types to analyse (default: all 9 signal features)
    max_lag       : maximum lag (default: n_timepoints // 3)
    alpha         : CI significance level (default: 0.05)
    top_k         : pairs shown in grid plot per feature (default: 9)

    Returns
    -------
    str  path to ccf_table.csv (may not exist if reference is constant).

    Raises
    ------
    FileNotFoundError  if resampled_csv does not exist.
    """
    if not os.path.isfile(resampled_csv):
        raise FileNotFoundError(f"'{resampled_csv}' not found")

    if features is None:
        features = ["mean", "median", "max", "min", "variance",
                    "energy", "entropy", "kurtosis", "skewness"]
    if out_dir is None:
        out_dir = os.path.dirname(os.path.abspath(resampled_csv))

    plots_dir = os.path.join(out_dir, "plots")
    os.makedirs(plots_dir, exist_ok=True)

    elapsed_s, feat_data, reference = read_resampled_csv(resampled_csv)
    n_tp = len(elapsed_s)

    max_lag = max_lag if max_lag is not None else max(1, n_tp // 3)

    ref_unique   = np.unique(reference[np.isfinite(reference)])
    ref_constant = len(ref_unique) <= 1

    if ref_constant:
        ref_z = reference.copy()
    else:
        mu  = float(np.nanmean(reference))
        std = float(np.nanstd(reference, ddof=1))
        ref_z = (reference - mu) / std if std > 0 else reference.copy()

    print(f"Timepoints  : {n_tp}")
    print(f"Max lag     : {max_lag}")
    print(f"Features    : {features}")
    print(f"Reference   : {'CONSTANT — only time-series plots will be produced'
                            if ref_constant else 'variable'}")

    all_table_rows = []

    for feat in features:
        region_series = feat_data.get(feat, {})
        if not region_series:
            print(f"\n[SKIP] no rows found for feature '{feat}'")
            continue

        regions  = list(region_series.keys())
        n_reg    = len(regions)
        n_pairs  = n_reg * (n_reg - 1) // 2
        print(f"\nFeature '{feat}': {n_reg} regions, {n_pairs} pairs")

        # ── constant reference: time-series plots only ──────────────────────
        if ref_constant:
            ts_path = os.path.join(plots_dir, f"timeseries_{feat}.png")
            plot_timeseries(elapsed_s, region_series, feat, ts_path)
            print(f"  Time-series plot → {ts_path}")
            continue

        # ── variable reference: CCF analysis ───────────────────────────────
        pair_results = {}

        for r_a, r_b in itertools.combinations(regions, 2):
            pname = f"{r_a}_vs_{r_b}"
            delta = region_series[r_a] - region_series[r_b]
            res   = cross_covariance_bartlett(ref_z, delta, max_lag, alpha=alpha)
            pair_results[pname] = res

            plot_ccf_single(
                pname, feat,
                res["lags"], res["ccf"], res["ci_upper"], res["ci_lower"],
                os.path.join(plots_dir, f"ccf_{feat}_{pname}.png"),
            )

            all_table_rows.append({
                "feature":     feat,
                "pair":        pname,
                "best_lag":    res["best_lag"],
                "best_ccf":    res["best_ccf"],
                "ci_bound":    res["ci_upper"],
                "se_bartlett": res["se"],
                "significant": res["significant"],
            })

        n_sig = sum(1 for r in all_table_rows
                    if r["feature"] == feat and r["significant"])
        print(f"  {n_pairs} pairs computed  ({n_sig} significant at α={alpha})")

        sorted_pairs = sorted(
            pair_results.items(),
            key=lambda kv: abs(kv[1]["best_ccf"])
                           if math.isfinite(kv[1]["best_ccf"]) else 0.0,
            reverse=True,
        )
        grid_path = os.path.join(plots_dir, f"top_pairs_{feat}.png")
        plot_top_grid(sorted_pairs, feat, top_k, grid_path)
        print(f"  Top-{top_k} grid → {grid_path}")

    # ── summary table ─────────────────────────────────────────────────────────
    table_path = os.path.join(out_dir, "ccf_table.csv")
    if all_table_rows:
        all_table_rows.sort(
            key=lambda r: abs(r["best_ccf"])
                          if math.isfinite(r["best_ccf"]) else 0.0,
            reverse=True,
        )
        cols = ["feature", "pair", "best_lag", "best_ccf",
                "ci_bound", "se_bartlett", "significant"]
        with open(table_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols)
            w.writeheader()
            for row in all_table_rows:
                w.writerow({k: _fmt(row[k]) for k in cols})

        n_sig_total = sum(1 for r in all_table_rows if r["significant"])
        print(f"\nCCF table   : {table_path}")
        print(f"  {len(all_table_rows)} rows, "
              f"{n_sig_total} significant pairs across all features")
    else:
        print("\nNo CCF results produced (reference may be constant for all features).")

    return table_path


# ── main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="Cross-ROI CCF analysis with Bartlett CI")
    ap.add_argument("stats_csv")
    ap.add_argument("out_dir", nargs="?", default=None)
    ap.add_argument("--features", nargs="+",
                    default=None,
                    help="Feature types to analyse (default: all signal features)")
    ap.add_argument("--max-lag",  type=int,   default=None,
                    help="Maximum lag (default: n_timepoints // 3)")
    ap.add_argument("--alpha",    type=float, default=0.05,
                    help="CI significance level (default: 0.05)")
    ap.add_argument("--top-k",    type=int,   default=9,
                    help="Pairs in grid plot per feature (default: 9)")
    args = ap.parse_args()
    analyse(args.stats_csv, args.out_dir,
            features=args.features, max_lag=args.max_lag,
            alpha=args.alpha, top_k=args.top_k)


if __name__ == "__main__":
    main()
