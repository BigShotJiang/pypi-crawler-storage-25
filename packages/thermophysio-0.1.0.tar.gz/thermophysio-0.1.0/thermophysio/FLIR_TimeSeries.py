#!/usr/bin/env python3
"""
FLIR_TimeSeries.py

Resamples the irregular-timestep stats CSV produced by FLIR_Stats_to_CSV.py
to a uniform time grid using cubic-spline interpolation.

For each numeric feature row the irregular (elapsed_s, value) pairs are
fitted with a CubicSpline and evaluated on a uniform grid with spacing dt.
The reference_activation signal is resampled with nearest-neighbour to
preserve its step-function character.

Usage:
    python FLIR_TimeSeries.py <stats.csv> [out.csv] [--dt SECONDS]

    stats.csv    output of FLIR_Stats_to_CSV.py
    out.csv      optional output path (default: <stem>_resampled.csv)
    --dt         uniform time step in seconds (default: 5.0)
"""

import os
import sys
import csv
import argparse
import numpy as np
from scipy.interpolate import CubicSpline

from .shared_utils import _safe_float, _fmt  # noqa: E402


# ── I/O ───────────────────────────────────────────────────────────────────────


def read_stats_csv(path: str):
    """
    Returns:
        col_labels : list[str]        timepoint labels
        row_order  : list[str]        row keys in original order
        data       : dict[str, list]  {key: [values per timepoint]}
    """
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    if not rows:
        sys.exit(f"ERROR: '{path}' is empty")

    col_labels = rows[0][1:]   # drop 'feature' column
    row_order  = []
    data       = {}

    for row in rows[1:]:
        if not row:
            continue
        key = row[0].strip()
        row_order.append(key)
        data[key] = row[1:]    # keep as strings; convert later

    return col_labels, row_order, data


# ── resampling ────────────────────────────────────────────────────────────────

def _nearest(t_orig: np.ndarray, values: np.ndarray,
             t_new: np.ndarray) -> np.ndarray:
    """Nearest-neighbour resampling for step-function signals."""
    idx = np.searchsorted(t_orig, t_new, side="left")
    idx = np.clip(idx, 0, len(t_orig) - 1)
    idx_before = np.maximum(idx - 1, 0)
    d_after  = np.abs(t_new - t_orig[idx])
    d_before = np.abs(t_new - t_orig[idx_before])
    best = np.where(d_before < d_after, idx_before, idx)
    return values[best].astype(float)


def _spline_resample(t_orig: np.ndarray, values: np.ndarray,
                     t_new: np.ndarray) -> np.ndarray:
    """
    Cubic-spline interpolation from t_orig to t_new using finite points only.
    Clamps to boundary values outside the fitted range.
    Returns NaN row if fewer than 3 finite points.
    """
    mask = np.isfinite(values)
    if mask.sum() < 3:
        return np.full(len(t_new), float("nan"))

    t_fit = t_orig[mask]
    v_fit = values[mask]

    # Collapse any duplicate timestamps by averaging their values
    t_fit, inv = np.unique(t_fit, return_inverse=True)
    v_fit = np.array([v_fit[inv == i].mean() for i in range(len(t_fit))])

    if len(t_fit) < 3:
        return np.full(len(t_new), float("nan"))

    cs     = CubicSpline(t_fit, v_fit, extrapolate=False)
    result = cs(t_new).astype(float)

    # clamp extrapolated NaNs to boundary values
    result = np.where(t_new < t_fit[0],  v_fit[0],  result)
    result = np.where(t_new > t_fit[-1], v_fit[-1], result)

    return result


# ── formatting ────────────────────────────────────────────────────────────────

# ── callable API ─────────────────────────────────────────────────────────────

def resample(stats_csv: str, out_csv: str = None, dt: float = 5.0) -> str:
    """
    Resample an irregular-timestep stats CSV to a uniform Δt grid.

    Parameters
    ----------
    stats_csv : path to CSV produced by FLIR_Stats_to_CSV.py
    out_csv   : output path (default: <stem>_resampled.csv)
    dt        : uniform time step in seconds (default 5.0)

    Returns
    -------
    str  absolute path to the written output file.

    Raises
    ------
    FileNotFoundError  if stats_csv does not exist.
    ValueError         if elapsed_s row is missing or all-NaN.
    """
    if not os.path.isfile(stats_csv):
        raise FileNotFoundError(f"'{stats_csv}' not found")

    if out_csv is None:
        base = os.path.splitext(stats_csv)[0]
        out_csv = base + "_resampled.csv"

    col_labels, row_order, raw = read_stats_csv(stats_csv)

    # ── elapsed_s axis ───────────────────────────────────────────────────────
    if "elapsed_s" not in raw:
        raise ValueError("'elapsed_s' row not found in CSV")

    elapsed_s = np.array([_safe_float(v) for v in raw["elapsed_s"]])
    finite_t  = elapsed_s[np.isfinite(elapsed_s)]
    if finite_t.size == 0:
        raise ValueError("All elapsed_s values are NaN")

    t0    = float(finite_t.min())
    t_end = float(finite_t.max())
    t_new = np.arange(t0, t_end + dt / 2.0, dt)
    n_new = len(t_new)

    print(f"Input timepoints    : {len(col_labels)}")
    print(f"Time range          : {t0:.1f} – {t_end:.1f} s")
    print(f"dt                  : {dt} s")
    print(f"Resampled timepoints: {n_new}")

    new_labels = [f"T{i+1:03d}_{t:.1f}s" for i, t in enumerate(t_new)]

    # ── resample each row ────────────────────────────────────────────────────
    out_rows = {}

    for key in row_order:
        raw_vals = raw[key]

        if key == "timestamp":
            out_rows[key] = [""] * n_new
            continue

        values = np.array([_safe_float(v) for v in raw_vals])

        if key == "elapsed_s":
            out_rows[key] = list(t_new)
        elif key == "reference_activation":
            out_rows[key] = list(_nearest(elapsed_s, values, t_new))
        else:
            out_rows[key] = list(_spline_resample(elapsed_s, values, t_new))

    # ── write output CSV ─────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(os.path.abspath(out_csv)), exist_ok=True)

    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["feature"] + new_labels)
        for key in row_order:
            w.writerow([key] + [_fmt(v) for v in out_rows[key]])

    print(f"\nOutput              : {out_csv}")
    return out_csv


# ── main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="Resample FLIR stats CSV to uniform time grid")
    ap.add_argument("stats_csv")
    ap.add_argument("out_csv", nargs="?", default=None,
                    help="Output path (default: <stem>_resampled.csv)")
    ap.add_argument("--dt", type=float, default=5.0,
                    help="Uniform time step in seconds (default: 5.0)")
    args = ap.parse_args()
    resample(args.stats_csv, args.out_csv, args.dt)


if __name__ == "__main__":
    main()
