#!/usr/bin/env python3
"""
Back_FLIR_Extractor.py

Single-camera FLIR analyser for back-of-head experiments.
Uses YOLOv8 pose to detect ear positions; the ear–ear line is the anatomical
basis unit for all region definitions.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ROI mesh is loaded from mesh_defs.json via mesh_loader.py — edit it      ║
║  with back_mesh_editor.py (press J to export) then push to GitHub.        ║
╚══════════════════════════════════════════════════════════════════════════════╝

COORDINATE SYSTEM  (u, v) — both normalised by D_ear (inter-ear pixel distance)

    u  along the ear–ear axis:
         u = -0.5  →  left ear tip
         u =  0.0  →  midpoint between ears
         u = +0.5  →  right ear tip

    v  perpendicular to ear axis:
         v > 0  →  toward crown  (upward in image, y decreases)
         v < 0  →  toward neck   (downward in image)

Anchor pixel pos  =  M  +  u * D_ear * e_u  +  v * D_ear * e_v
    where  M     = (l_ear + r_ear) / 2
           e_u   = (r_ear - l_ear) / D_ear          (unit along ear axis)
           e_v   = [e_u[1], -e_u[0]]                (90° CW → toward crown)

Offsets (du, dv) in UV units persist across every image in the session.
Reset button clears all offsets.

Run:
    python Back_FLIR_Extractor.py <img_dir>  [out_csv]
    python Back_FLIR_Extractor.py <img_dir>  [out_csv]  --model yolov8m-pose.pt

INTERACTIVE CONTROLS (per image)
    Drag green/blue handles  →  fine-tune anchor positions
    L key then left-click    →  reposition left  ear (rebuilds entire basis)
    K key then left-click    →  reposition right ear (rebuilds entire basis)
    Reset button             →  clear all offsets for this image onward
    Enter                    →  accept image, extract thermal stats
    S                        →  skip this image
    Q / Esc                  →  abort session

Handle colours:
    green   →  default position (no offset applied)
    blue    →  manually adjusted
    cyan    →  currently being dragged
    orange  →  ear marker
"""

import os
import sys
import argparse
import tkinter as tk
from datetime import datetime
from typing import Optional

import cv2
import numpy as np
from PIL import Image
import flyr

from .shared_utils import (get_capture_time, get_polygon_values,
                          _save_overlay, _save_pixels, _write_meta)


# ── ROI mesh — populated at runtime by run() via load_mesh("back") ────────────
BACK_ANCHORS     = None   # OrderedDict set by run() on first call
BACK_REGION_DEFS = None   # OrderedDict set by run() on first call


# ── YOLOv8 ear detection ──────────────────────────────────────────────────────

_COCO_LEFT_EAR  = 3
_COCO_RIGHT_EAR = 4
_yolo_model_cache = {}   # {model_path: YOLO instance}


def _get_yolo(model_path: str):
    if model_path not in _yolo_model_cache:
        from ultralytics import YOLO
        _yolo_model_cache[model_path] = YOLO(model_path)
    return _yolo_model_cache[model_path]


def detect_ears_yolo(bgr: np.ndarray, model_path: str = "yolov8n-pose.pt"):
    """
    Run YOLOv8 pose on bgr image and extract ear keypoints.

    Strategy:
    - Run with low conf/iou thresholds to maximise detection rate on back-of-head images.
    - Pick the detection with the highest box confidence.
    - If both ears are found (conf > 0.05) → return both as-is.
    - If only one ear is found → mirror it across the image centre to estimate the other.
      This is a reasonable fallback for symmetric back-of-head views.
    - If neither ear is found → return None.

    Returns (l_ear, r_ear, conf_l, conf_r) or None.
    """
    try:
        model   = _get_yolo(model_path)
        # Lower thresholds than default (0.25 conf, 0.7 iou) to catch partial detections
        results = model(bgr, verbose=False, conf=0.10, iou=0.45)
        if not results or results[0].keypoints is None:
            return None
        kps_t = results[0].keypoints.data
        if kps_t is None or len(kps_t) == 0:
            return None
        boxes = results[0].boxes
        best  = int(np.argmax(boxes.conf.cpu().numpy())) if boxes is not None else 0
        kps   = kps_t[best].cpu().numpy()       # (17, 3)  x, y, conf

        l_kp, r_kp = kps[_COCO_LEFT_EAR], kps[_COCO_RIGHT_EAR]
        conf_l, conf_r = float(l_kp[2]), float(r_kp[2])

        MIN_CONF = 0.05   # anything below this is treated as "not detected"
        h, w = bgr.shape[:2]
        cx   = w / 2.0

        l_found = conf_l >= MIN_CONF
        r_found = conf_r >= MIN_CONF

        if not l_found and not r_found:
            return None

        l_pos = np.array([float(l_kp[0]), float(l_kp[1])])
        r_pos = np.array([float(r_kp[0]), float(r_kp[1])])

        # Mirror missing ear across the vertical image centre
        if l_found and not r_found:
            # Mirror L ear to estimate R
            r_pos  = np.array([2 * cx - l_pos[0], l_pos[1]])
            conf_r = conf_l * 0.5   # mark as estimated
            print(f"  [YOLO] only L-ear detected (conf={conf_l:.2f}) — "
                  f"R-ear estimated by mirroring.")
        elif r_found and not l_found:
            # Mirror R ear to estimate L
            l_pos  = np.array([2 * cx - r_pos[0], r_pos[1]])
            conf_l = conf_r * 0.5
            print(f"  [YOLO] only R-ear detected (conf={conf_r:.2f}) — "
                  f"L-ear estimated by mirroring.")

        return l_pos, r_pos, conf_l, conf_r

    except Exception as exc:
        print(f"  [YOLO] error: {exc}")
        return None


# ── Ear–ear coordinate geometry ───────────────────────────────────────────────

def build_basis(l_ear: np.ndarray, r_ear: np.ndarray):
    """
    Compute the ear–ear coordinate frame.
    Returns (M, D, e_u, e_v):
        M    – midpoint between ears (px)
        D    – inter-ear distance (px)
        e_u  – unit vector along ear axis (L→R)
        e_v  – unit vector toward crown (90° CW of e_u)
    """
    l  = np.array(l_ear, float)
    r  = np.array(r_ear, float)
    D_true = max(float(np.hypot(*(r - l))), 1.0)
    e_u = (r - l) / D_true                      # proper unit vector (unscaled)
    e_v = np.array([e_u[1], -e_u[0]])            # 90° CW → toward crown (y-down image)
    M   = (l + r) / 2.0
    D   = D_true * 0.90                          # 10% scale-down applied only to D
    return M, D, e_u, e_v


def compute_anchor_pixels(l_ear, r_ear, offsets: dict) -> dict:
    """
    Return {name: np.array([x, y])} for every anchor in BACK_ANCHORS,
    applying any (du, dv) offsets from the shared offsets dict.
    """
    M, D, e_u, e_v = build_basis(l_ear, r_ear)
    result = {}
    for name, a in BACK_ANCHORS.items():
        du, dv = offsets.get(name, (0.0, 0.0))
        u = a['u'] + du
        v = a['v'] + dv
        result[name] = M + u * D * e_u + v * D * e_v
    return result


def build_region_polys(anchor_px: dict) -> dict:
    """Return {region_name: np.int32 polygon array} from computed anchor pixels."""
    polys = {}
    for rname, defn in BACK_REGION_DEFS.items():
        pts = []
        ok  = True
        for name in defn['poly']:
            if name not in anchor_px:
                ok = False; break
            pts.append(anchor_px[name].astype(float))
        if ok and len(pts) >= 3:
            polys[rname] = np.array(pts, dtype=np.int32)
    return polys


def draw_regions(base_bgr: np.ndarray, region_polys: dict) -> np.ndarray:
    canvas = base_bgr.copy()
    for rname, poly in region_polys.items():
        defn    = BACK_REGION_DEFS.get(rname, {})
        color   = defn.get('color', (128, 128, 128))
        alpha   = defn.get('alpha', 0.40)
        overlay = canvas.copy()
        cv2.fillPoly(overlay, [poly.reshape(-1, 1, 2)], color)
        cv2.addWeighted(overlay, alpha, canvas, 1 - alpha, 0, canvas)
        cv2.polylines(canvas, [poly.reshape(-1, 1, 2)], True, color, 2, cv2.LINE_AA)
        ctr = poly.mean(axis=0).astype(int)
        cv2.putText(canvas, rname, tuple(ctr),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.36, (0, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(canvas, rname, tuple(ctr),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.36, color,    1, cv2.LINE_AA)
    return canvas


# ── FLIR image loading ────────────────────────────────────────────────────────

def _thermal_to_display_bgr(thermal: np.ndarray) -> np.ndarray:
    t_min, t_max = np.nanmin(thermal), np.nanmax(thermal)
    norm = ((thermal - t_min) / (t_max - t_min) * 255).astype(np.uint8) if t_max > t_min \
           else np.zeros_like(thermal, dtype=np.uint8)
    return cv2.applyColorMap(norm, cv2.COLORMAP_INFERNO)


def load_flir(path: str):
    """
    Returns (thermal, rgb_bgr):
        thermal  – float32 ndarray (H×W) in °C, or None
        rgb_bgr  – uint8 BGR ndarray for display
    """
    thermal = None
    rgb = None
    try:
        bundle  = flyr.unpack(path)
        thermal = bundle.celsius.astype(np.float32)
        optical = bundle.optical
        if optical is not None and optical.size > 0:
            rgb = optical
            print(f"  [flyr] RGB via embedded optical → {rgb.shape}")
    except Exception as exc:
        print(f"  [flyr] failed: {exc}")

    if rgb is None:
        try:
            rgb = np.array(Image.open(path).convert("RGB"))
            print(f"  [flyr] RGB via outer JPEG → {rgb.shape}")
        except Exception:
            pass

    if rgb is None and thermal is not None:
        bgr = _thermal_to_display_bgr(thermal)
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        print("  [flyr] WARNING: using thermal false-colour as RGB (no camera image found).")

    if rgb is None:
        raise RuntimeError("Could not load any image data from FLIR file.")

    rgb_bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    return thermal, rgb_bgr


# ── Session-time GUI ─────────────────────────────────────────────────────────

def _parse_time(s: str, date_ref: datetime) -> datetime:
    s = s.strip()
    try:
        t = datetime.strptime(s, "%H:%M:%S").time()
    except ValueError:
        raise ValueError(f"'{s}' is not a valid time — use HH:MM:SS format.")
    return datetime.combine(date_ref.date(), t)


def get_session_times_gui(img_times: list):
    """
    Show a GUI with the image timestamp list and two fields:
        Activation start  (HH:MM:SS)
        Activation end    (HH:MM:SS)

    Returns {'act_start': datetime, 'act_end': datetime} or None if cancelled.
    """
    date_ref = img_times[0]; result = {}; confirmed = [False]
    root = tk.Tk(); root.title("Define Activation Period")
    root.configure(bg="#1e1e1e"); root.resizable(False, False)
    BG = "#1e1e1e"; FG = "#e8e8e8"; ACCENT = "#00c864"; ERR_COL = "#ff5555"
    ENTRY_BG = "#2d2d2d"; ENTRY_FG = "#ffffff"
    FONT_H = ("Consolas", 11, "bold"); FONT_N = ("Consolas", 10); FONT_S = ("Consolas", 9)

    # ── left: scrollable timestamp list ──────────────────────────────────────
    left = tk.Frame(root, bg=BG, padx=12, pady=12)
    left.grid(row=0, column=0, sticky="ns")
    tk.Label(left, text="Image timestamps", bg=BG, fg=ACCENT, font=FONT_H).pack(
        anchor="w", pady=(0, 6))
    frame_list = tk.Frame(left, bg=BG); frame_list.pack(fill="both", expand=True)
    sb = tk.Scrollbar(frame_list, orient="vertical", bg="#333", troughcolor="#222")
    lb = tk.Listbox(frame_list, yscrollcommand=sb.set, bg=ENTRY_BG, fg=FG,
                    selectbackground="#3a3a5c", font=FONT_N, width=32,
                    height=min(30, len(img_times) + 2), borderwidth=0,
                    highlightthickness=1, highlightcolor=ACCENT, highlightbackground="#444")
    sb.config(command=lb.yview); sb.pack(side="right", fill="y")
    lb.pack(side="left", fill="both", expand=True)
    for i, t in enumerate(img_times):
        lb.insert(tk.END, f"  {i+1:3d}.  {t.strftime('%H:%M:%S')}")

    # ── right: two time fields ────────────────────────────────────────────────
    right = tk.Frame(root, bg=BG, padx=24, pady=12)
    right.grid(row=0, column=1, sticky="n")
    tk.Label(right, text="Activation Period  (HH:MM:SS)",
             bg=BG, fg=ACCENT, font=FONT_H).grid(
        row=0, column=0, columnspan=2, sticky="w", pady=(0, 20))

    field_defs = [
        ("Activation start", "act_start"),
        ("Activation end",   "act_end"),
    ]
    entries = {}; err_labels = {}
    for row_idx, (label, key) in enumerate(field_defs, start=1):
        tk.Label(right, text=label, bg=BG, fg=FG, font=FONT_N,
                 anchor="w", width=18).grid(
            row=row_idx * 3, column=0, sticky="w", pady=(4, 0))
        var = tk.StringVar()
        e = tk.Entry(right, textvariable=var, bg=ENTRY_BG, fg=ENTRY_FG, font=FONT_N,
                     insertbackground=ACCENT, width=12, relief="flat",
                     highlightthickness=1, highlightcolor=ACCENT, highlightbackground="#555")
        e.grid(row=row_idx * 3, column=1, sticky="w", padx=(8, 0), pady=(4, 0))
        e.bind('<Control-v>', lambda ev, w=e: w.event_generate('<<Paste>>'))
        e.bind('<Control-V>', lambda ev, w=e: w.event_generate('<<Paste>>'))
        err = tk.Label(right, text="", bg=BG, fg=ERR_COL, font=FONT_S)
        err.grid(row=row_idx * 3 + 1, column=0, columnspan=2, sticky="w", pady=(0, 2))
        entries[key] = var; err_labels[key] = err

    tk.Label(right,
             text=(
                 "All images kept and subsampled to ≥15 s apart.\n"
                 "Images inside the window  →  +1 (active).\n"
                 "Images outside the window →  -1 (baseline)."
             ),
             bg=BG, fg="#888888", font=FONT_S, justify="left").grid(
        row=20, column=0, columnspan=2, sticky="w", pady=(20, 8))

    status_var = tk.StringVar(value="")
    status_lbl = tk.Label(right, textvariable=status_var, bg=BG, fg=ERR_COL,
                          font=FONT_S, justify="left")
    status_lbl.grid(row=21, column=0, columnspan=2, sticky="w")

    def on_confirm():
        for lbl in err_labels.values(): lbl.config(text="")
        status_var.set(""); status_lbl.config(fg=ERR_COL)
        parsed = {}; has_error = False
        for label, key in field_defs:
            raw = entries[key].get().strip()
            if not raw:
                err_labels[key].config(text="  required"); has_error = True; continue
            try:
                parsed[key] = _parse_time(raw, date_ref)
            except ValueError as exc:
                err_labels[key].config(text=f"  {exc}"); has_error = True
        if has_error: return
        if parsed["act_start"] >= parsed["act_end"]:
            status_var.set("Activation start must be before activation end."); return

        # Preview counts after 15-s subsampling
        kept = _subsample_15s(img_times)
        n_on = sum(1 for t in kept
                   if parsed["act_start"] <= t <= parsed["act_end"])
        status_var.set(
            f"OK — {len(kept)} images kept (≥15 s apart),  "
            f"{n_on} active (+1),  {len(kept) - n_on} baseline (-1)")
        status_lbl.config(fg=ACCENT)
        result.update(parsed); confirmed[0] = True; root.after(800, root.destroy)

    tk.Button(right, text="Confirm", command=on_confirm,
              bg="#005533", fg="#00ff88", activebackground="#007744",
              activeforeground="#ffffff", font=("Consolas", 11, "bold"),
              relief="flat", padx=20, pady=6, cursor="hand2").grid(
        row=22, column=0, columnspan=2, pady=(12, 0), sticky="w")
    root.bind("<Return>", lambda e: on_confirm())
    root.update_idletasks()
    w, h = root.winfo_width(), root.winfo_height()
    root.geometry(f"+{(root.winfo_screenwidth()-w)//2}+{(root.winfo_screenheight()-h)//2}")
    root.mainloop()
    if not confirmed[0]: return None
    return result


# ── Image subsampling + reference series ──────────────────────────────────────

def _subsample_15s(times: list) -> list:
    """
    Keep only timestamps that are ≥15 seconds after the last kept timestamp.
    Returns the filtered list of datetime objects.
    """
    kept = []
    for t in times:
        if not kept or (t - kept[-1]).total_seconds() >= 15:
            kept.append(t)
    return kept


def build_reference_series(images: list, session_times: dict):
    """
    Subsample images to ≥15 s apart, then label each:
        +1  if its timestamp falls within [act_start, act_end]
        -1  otherwise (baseline)

    Returns (filtered_images, times_kept, ref_labels, ref_z_array).
    ref_labels holds the raw ±1 values; ref_z_array is the z-scored version
    for use as a GLM regressor.
    """
    act_start = session_times["act_start"]
    act_end   = session_times["act_end"]

    # Subsample: keep images ≥15 s apart (consistent with _subsample_15s)
    filtered   = []
    times_kept = []
    for img in images:
        t = img["time"]
        if not times_kept or (t - times_kept[-1]).total_seconds() >= 15:
            filtered.append(img)
            times_kept.append(t)

    ref_raw = [1.0 if act_start <= t <= act_end else -1.0 for t in times_kept]
    ref_arr = np.array(ref_raw)
    mu  = float(np.mean(ref_arr))
    std = float(np.std(ref_arr, ddof=1)) if len(ref_arr) > 1 else 1.0
    ref_z = (ref_arr - mu) / std if std != 0 else ref_arr - mu
    return filtered, times_kept, ref_arr, ref_z


# ── Interactive per-image display ─────────────────────────────────────────────

class BackDisplay:
    TARGET_H = 640
    BAR_H    = 50
    INFO_H   = 36
    CTRL_H   = 46
    HANDLE_R = 8
    HIT_R    = 16
    COL_DEFAULT  = (0, 220,  80)   # green
    COL_MODIFIED = (0, 140, 255)   # blue
    COL_ACTIVE   = (0, 240, 240)   # cyan
    COL_EAR      = (0, 140, 255)   # orange-ish for ears  (BGR)
    COL_BG       = (20,  20,  20)
    RST_COL      = (140,  50,  50)
    FONT = cv2.FONT_HERSHEY_SIMPLEX

    def __init__(self, win: str, base_bgr: np.ndarray,
                 l_ear: np.ndarray, r_ear: np.ndarray,
                 img_info: str, offsets: dict,
                 conf_l: Optional[float] = None, conf_r: Optional[float] = None):
        self.win      = win
        self.base     = base_bgr
        self.img_info = img_info
        self.offsets  = offsets      # {name: (du, dv)} — mutated in-place
        self.conf_l   = conf_l
        self.conf_r   = conf_r

        self.l_ear = np.array(l_ear, float)
        self.r_ear = np.array(r_ear, float)

        self.scale  = self.TARGET_H / base_bgr.shape[0]
        self.cw     = int(base_bgr.shape[1] * self.scale)
        self.img_y0 = self.BAR_H
        self.info_y0 = self.BAR_H + self.TARGET_H
        self.ctrl_y0 = self.info_y0 + self.INFO_H
        self.canvas_h = self.ctrl_y0 + self.CTRL_H

        self._anchor_px = {}
        self._regions   = {}
        self._drag_name = None
        self._set_ear   = None    # None | 'L' | 'R'

        # Flags read by main() after accept to update per-ear deltas
        self.ear_l_modified = False
        self.ear_r_modified = False
        self.ears_reset     = False

        cv2.namedWindow(win, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(win, self.cw, self.canvas_h)
        cv2.setMouseCallback(win, self._on_mouse)
        self.render()

    # ── coordinate helpers ────────────────────────────────────────────────────

    def _btn_reset_rect(self):
        return (10, self.ctrl_y0 + 7, 95, self.ctrl_y0 + self.CTRL_H - 7)

    def _img_to_canvas(self, ix: float, iy: float) -> tuple[int, int]:
        return (int(round(ix * self.scale)),
                int(round(iy * self.scale + self.img_y0)))

    def _canvas_to_img(self, cx: float, cy: float) -> tuple[float, float]:
        return cx / self.scale, (cy - self.img_y0) / self.scale

    def _find_nearest_handle(self, cx: int, cy: int) -> Optional[str]:
        if not (self.img_y0 <= cy <= self.img_y0 + self.TARGET_H):
            return None
        best_name, best_d = None, self.HIT_R ** 2
        for name, pos in self._anchor_px.items():
            hcx, hcy = self._img_to_canvas(pos[0], pos[1])
            d = (cx - hcx) ** 2 + (cy - hcy) ** 2
            if d < best_d:
                best_d = d; best_name = name
        return best_name

    # ── render ────────────────────────────────────────────────────────────────

    def render(self):
        self._anchor_px = compute_anchor_pixels(self.l_ear, self.r_ear, self.offsets)
        self._regions   = build_region_polys(self._anchor_px)
        ann = draw_regions(self.base, self._regions)

        canvas = np.full((self.canvas_h, self.cw, 3), self.COL_BG, dtype=np.uint8)
        img_s  = cv2.resize(ann, (self.cw, self.TARGET_H), interpolation=cv2.INTER_AREA)

        # ── header bar ────────────────────────────────────────────────────────
        nmod    = sum(1 for v in self.offsets.values() if v != (0.0, 0.0))
        mod_str = f"  [{nmod} adjusted]" if nmod else ""
        M, D, _, _ = build_basis(self.l_ear, self.r_ear)
        conf_str = ""
        if self.conf_l is not None:
            conf_str = f"  L={self.conf_l:.2f} R={self.conf_r:.2f}"
        hdr = np.full((self.BAR_H, self.cw, 3), (28, 28, 28), dtype=np.uint8)
        for txt, yy, sc in [
            (f"BACK-OF-HEAD  |  {len(self._regions)} regions{mod_str}"
             f"  D_ear={D:.0f}px{conf_str}", 18, 0.46),
            (self.img_info[:120], 36, 0.36),
        ]:
            cv2.putText(hdr, txt, (8, yy), self.FONT, sc, (0, 0, 0),      2, cv2.LINE_AA)
            cv2.putText(hdr, txt, (8, yy), self.FONT, sc, (255, 255, 255), 1, cv2.LINE_AA)
        canvas[0:self.BAR_H]                             = hdr
        canvas[self.img_y0:self.img_y0 + self.TARGET_H] = img_s

        # ── ear markers ───────────────────────────────────────────────────────
        for ear, lbl, col in [
            (self.l_ear, "L-EAR", (60,  110, 255)),
            (self.r_ear, "R-EAR", (0,   200,  60)),
        ]:
            ecx, ecy = self._img_to_canvas(ear[0], ear[1])
            if self.img_y0 <= ecy <= self.img_y0 + self.TARGET_H:
                cv2.circle(canvas, (ecx, ecy), 12, col, 2, cv2.LINE_AA)
                cv2.circle(canvas, (ecx, ecy),  4, col, -1, cv2.LINE_AA)
                cv2.putText(canvas, lbl, (ecx + 14, ecy + 5),
                            self.FONT, 0.32, (0, 0, 0), 2, cv2.LINE_AA)
                cv2.putText(canvas, lbl, (ecx + 14, ecy + 5),
                            self.FONT, 0.32, col,       1, cv2.LINE_AA)

        # ── info bar ──────────────────────────────────────────────────────────
        cv2.rectangle(canvas, (0, self.info_y0),
                      (self.cw, self.info_y0 + self.INFO_H), (18, 18, 18), -1)
        ear_hint = ""
        if self._set_ear:
            ear_hint = f"  ←  click to set {'LEFT' if self._set_ear=='L' else 'RIGHT'} ear"
        cv2.putText(canvas, self.img_info + ear_hint,
                    (8, self.info_y0 + 24), self.FONT, 0.38, (0, 0, 0),      2, cv2.LINE_AA)
        cv2.putText(canvas, self.img_info + ear_hint,
                    (8, self.info_y0 + 24), self.FONT, 0.38, (190, 190, 190), 1, cv2.LINE_AA)

        # ── control bar ───────────────────────────────────────────────────────
        cv2.rectangle(canvas, (0, self.ctrl_y0), (self.cw, self.canvas_h), (22, 22, 22), -1)
        cv2.line(canvas, (0, self.ctrl_y0), (self.cw, self.ctrl_y0), (55, 55, 55), 1)
        rx1, ry1, rx2, ry2 = self._btn_reset_rect()
        cv2.rectangle(canvas, (rx1, ry1), (rx2, ry2), self.RST_COL, -1)
        cv2.rectangle(canvas, (rx1, ry1), (rx2, ry2), (200, 80, 80),  1)
        (tw, th), _ = cv2.getTextSize("Reset", self.FONT, 0.50, 1)
        cx_ = rx1 + ((rx2 - rx1) - tw) // 2
        cy_ = ry1 + ((ry2 - ry1) + th) // 2
        cv2.putText(canvas, "Reset", (cx_, cy_), self.FONT, 0.50, (0, 0, 0),      2, cv2.LINE_AA)
        cv2.putText(canvas, "Reset", (cx_, cy_), self.FONT, 0.50, (240, 200, 200), 1, cv2.LINE_AA)
        cv2.putText(canvas,
                    "Drag handles  |  L/K = reposition L/R ear"
                    "  |  Enter=Accept   S=Skip   Q=Quit",
                    (rx2 + 14, self.ctrl_y0 + self.CTRL_H // 2 + 5),
                    self.FONT, 0.33, (110, 110, 110), 1, cv2.LINE_AA)

        self._draw_handles(canvas)
        cv2.imshow(self.win, canvas)

    def _draw_handles(self, canvas: np.ndarray):
        for name, pos in self._anchor_px.items():
            hcx, hcy = self._img_to_canvas(pos[0], pos[1])
            if not (self.img_y0 <= hcy <= self.img_y0 + self.TARGET_H):
                continue
            if not (0 <= hcx <= self.cw):
                continue
            is_drag = (self._drag_name == name)
            has_off = self.offsets.get(name, (0.0, 0.0)) != (0.0, 0.0)
            col = (self.COL_ACTIVE   if is_drag else
                   self.COL_MODIFIED if has_off else
                   self.COL_DEFAULT)
            cv2.circle(canvas, (hcx, hcy), self.HANDLE_R, col, -1, cv2.LINE_AA)
            cv2.circle(canvas, (hcx, hcy), self.HANDLE_R, (255, 255, 255), 1, cv2.LINE_AA)
            cv2.putText(canvas, name, (hcx + self.HANDLE_R + 3, hcy - 3),
                        self.FONT, 0.26, (0, 0, 0), 2, cv2.LINE_AA)
            cv2.putText(canvas, name, (hcx + self.HANDLE_R + 3, hcy - 3),
                        self.FONT, 0.26, col,       1, cv2.LINE_AA)

    # ── mouse ─────────────────────────────────────────────────────────────────

    def _on_mouse(self, event, cx: int, cy: int, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN:
            # Ear repositioning mode
            if self._set_ear and self.img_y0 <= cy <= self.img_y0 + self.TARGET_H:
                ix, iy = self._canvas_to_img(cx, cy)
                if self._set_ear == 'L':
                    self.l_ear = np.array([ix, iy])
                    self.ear_l_modified = True
                else:
                    self.r_ear = np.array([ix, iy])
                    self.ear_r_modified = True
                self._set_ear = None
                self.render(); return

            # Reset button
            rx1, ry1, rx2, ry2 = self._btn_reset_rect()
            if rx1 <= cx <= rx2 and ry1 <= cy <= ry2:
                self.offsets.clear()
                self.ears_reset = True
                self.render(); return

            # Start dragging an anchor
            name = self._find_nearest_handle(cx, cy)
            if name:
                self._drag_name = name; self.render()

        elif event == cv2.EVENT_MOUSEMOVE:
            if self._drag_name:
                ix, iy = self._canvas_to_img(cx, cy)
                # Compute how far the dragged pixel is from the anchor's default pixel
                M, D, e_u, e_v = build_basis(self.l_ear, self.r_ear)
                a = BACK_ANCHORS[self._drag_name]
                default_px = M + a['u'] * D * e_u + a['v'] * D * e_v
                delta = np.array([ix - default_px[0], iy - default_px[1]])
                du = float(np.dot(delta, e_u)) / D
                dv = float(np.dot(delta, e_v)) / D
                self.offsets[self._drag_name] = (round(du, 4), round(dv, 4))
                self.render()

        elif event == cv2.EVENT_LBUTTONUP:
            self._drag_name = None

    @property
    def regions(self):
        return self._regions

    def destroy(self):
        try:
            cv2.destroyWindow(self.win)
        except cv2.error:
            pass


_WIN = "Back-of-Head FLIR  |  Drag handles  |  L/K=set ear  |  Enter=Accept  S=Skip  Q=Quit"


def show_image_cv2(base_bgr, l_ear, r_ear, img_info, offsets,
                   conf_l=None, conf_r=None):
    """
    Returns (action, regions, l_ear, r_ear, ear_l_modified, ear_r_modified, ears_reset).
    ear_l/r_modified: user repositioned that ear with L/K — main() should update the delta.
    ears_reset:       Reset was clicked — main() should zero both ear deltas.
    """
    disp = BackDisplay(_WIN, base_bgr, l_ear, r_ear, img_info, offsets, conf_l, conf_r)
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key in (13, 10):                           # Enter → accept
            disp.destroy()
            return "accept", disp.regions, disp.l_ear, disp.r_ear, \
                   disp.ear_l_modified, disp.ear_r_modified, disp.ears_reset
        elif key in (ord('s'), ord('S')):             # Skip
            disp.destroy()
            return "skip", {}, disp.l_ear, disp.r_ear, \
                   disp.ear_l_modified, disp.ear_r_modified, disp.ears_reset
        elif key in (ord('q'), ord('Q'), 27):         # Quit
            disp.destroy()
            return "abort", {}, disp.l_ear, disp.r_ear, False, False, False
        elif key in (ord('l'), ord('L')):
            disp._set_ear = 'L'; disp.render()
        elif key in (ord('k'), ord('K')):
            disp._set_ear = 'R'; disp.render()
        try:
            if cv2.getWindowProperty(_WIN, cv2.WND_PROP_VISIBLE) < 1:
                disp.destroy()
                return "abort", {}, disp.l_ear, disp.r_ear, False, False, False
        except cv2.error:
            disp.destroy()
            return "abort", {}, disp.l_ear, disp.r_ear, False, False, False


# ══════════════════════════════════════════════════════════════════════════════
#  Session persistence helpers
#
#  Analysis lives in FLIR_Analyser.py and can be re-run without re-scanning.
#  Per accepted image the extractor saves:
#    overlays/<label>.png  — annotated display image (verify masks visually)
#    pixels/<label>.npz   — { region_name : float32 temperature array }
#  Plus session_meta.json indexing everything.
# ══════════════════════════════════════════════════════════════════════════════

# ── callable API ─────────────────────────────────────────────────────────────

def run(img_dir: str, out_dir: str, model: str = "yolov8n-pose.pt"):
    """
    Extract back-of-head thermal ROIs from a directory of FLIR images.

    Opens the session-time GUI and a per-image interactive display for the
    researcher to verify and adjust anatomical region overlays.

    Parameters
    ----------
    img_dir : path to folder of FLIR JPEG images
    out_dir : output session directory (created if missing)
    model   : YOLOv8 pose model path (default: yolov8n-pose.pt;
              use yolov8m-pose.pt for better accuracy)

    Returns
    -------
    dict   session metadata on success
    None   if the researcher cancels the GUI or accepts no images

    Raises
    ------
    RuntimeError  if no JPEG images are found
    """
    global BACK_ANCHORS, BACK_REGION_DEFS
    from .mesh_loader import load_mesh
    BACK_ANCHORS, BACK_REGION_DEFS = load_mesh("back")

    os.makedirs(os.path.join(out_dir, "overlays"), exist_ok=True)
    os.makedirs(os.path.join(out_dir, "pixels"),   exist_ok=True)

    # ── scan images ───────────────────────────────────────────────────────────
    paths = sorted(
        p for p in
        (os.path.join(img_dir, f) for f in os.listdir(img_dir))
        if os.path.splitext(p)[1].lower() in {".jpg", ".jpeg"})
    images = sorted(
        [{"path": p, "time": get_capture_time(p)} for p in paths],
        key=lambda x: x["time"])
    if not images:
        raise RuntimeError(f"No JPEG images found in '{img_dir}'")
    print(f"Found {len(images)} images.")

    # ── session-time GUI ──────────────────────────────────────────────────────
    print("\nOpening session-time GUI ...")
    session_times = get_session_times_gui([img["time"] for img in images])
    if session_times is None:
        print("Cancelled — no output written.")
        return None

    # ── filter + reference series ─────────────────────────────────────────────
    filtered, times_kept, ref_series, ref_series_z = build_reference_series(images, session_times)
    n_disc = len(images) - len(filtered)
    print(f"\nSession times confirmed.")
    print(f"  Images discarded (< 15 s from previous): {n_disc}")
    print(f"  Images kept:     {len(filtered)}")
    print(f"  Active (+1):     {int(np.sum(ref_series > 0))}")
    print(f"  Baseline (-1):   {int(np.sum(ref_series < 0))}")
    if not filtered:
        raise RuntimeError("No images remain after filtering.")

    print(f"\nRegions: {', '.join(BACK_REGION_DEFS.keys())}")
    print(f"Anchors: {', '.join(BACK_ANCHORS.keys())}")
    print(f"\nControls:  Drag handles  |  L/K = set ear  |  Enter=accept  S=skip  Q=quit")
    print("Offsets (du, dv in UV units) persist across images.  Reset clears all.\n")

    offsets      = {}
    last_l_ear   = None
    last_r_ear   = None
    ear_delta_l  = np.zeros(2)
    ear_delta_r  = np.zeros(2)
    timepoints   = []

    for idx, img_item in enumerate(filtered):
        t          = times_kept[idx]
        ref_val    = float(ref_series[idx])
        active_str = "ACTIVE (+1)" if ref_val > 0 else "baseline (-1)"
        print(f"\n[{idx+1}/{len(filtered)}]  {t.strftime('%H:%M:%S')}  [{active_str}]  "
              f"{os.path.basename(img_item['path'])}")

        try:
            thermal, rgb_bgr = load_flir(img_item["path"])
        except Exception as exc:
            print(f"  ERROR loading: {exc} — skipping"); continue

        yolo_result = detect_ears_yolo(rgb_bgr, model)
        if yolo_result is not None:
            l_ear, r_ear, conf_l, conf_r = yolo_result
            yolo_l_ear, yolo_r_ear = l_ear.copy(), r_ear.copy()
            l_ear = l_ear + ear_delta_l
            r_ear = r_ear + ear_delta_r
            D = float(np.hypot(*(r_ear - l_ear)))
            print(f"  [YOLO] ears detected  D_ear={D:.1f}px  L={conf_l:.2f}  R={conf_r:.2f}")
            if conf_l < 0.35 or conf_r < 0.35:
                print("  [YOLO] low confidence — verify ears in the display window.")
            last_l_ear, last_r_ear = l_ear.copy(), r_ear.copy()
        else:
            print("  [YOLO] ear detection failed.", end="")
            if last_l_ear is not None:
                l_ear, r_ear = last_l_ear.copy(), last_r_ear.copy()
                print("  Using ear positions from previous image.")
            else:
                h, w = rgb_bgr.shape[:2]
                l_ear = np.array([w * 0.30, h * 0.50])
                r_ear = np.array([w * 0.70, h * 0.50])
                print("  Using default centre positions — please adjust with L/K keys.")
            conf_l = conf_r = None
            yolo_l_ear = yolo_r_ear = None

        nmod = sum(1 for v in offsets.values() if v != (0.0, 0.0))
        has_delta = np.any(ear_delta_l != 0) or np.any(ear_delta_r != 0)
        if nmod:
            print(f"  Carrying over {nmod} non-zero offset(s).")
        if has_delta:
            print(f"  Ear delta active: L=({ear_delta_l[0]:+.1f},{ear_delta_l[1]:+.1f})px"
                  f"  R=({ear_delta_r[0]:+.1f},{ear_delta_r[1]:+.1f})px")

        img_info = (f"Img {idx+1}/{len(filtered)}"
                    f"  |  {t.strftime('%H:%M:%S')}  [{active_str}]"
                    f"  |  {os.path.basename(img_item['path'])}")

        action, regions, l_ear, r_ear, ear_l_mod, ear_r_mod, ears_rst = show_image_cv2(
            rgb_bgr, l_ear, r_ear, img_info, offsets, conf_l, conf_r)

        last_l_ear, last_r_ear = l_ear.copy(), r_ear.copy()

        if action == "abort":
            print("  Aborted."); break
        if action == "skip":
            print("  Skipped."); continue

        if ears_rst:
            ear_delta_l = np.zeros(2)
            ear_delta_r = np.zeros(2)
            print("  Ear deltas reset to zero.")
        elif yolo_l_ear is not None:
            if ear_l_mod:
                ear_delta_l = l_ear - yolo_l_ear
            if ear_r_mod:
                ear_delta_r = r_ear - yolo_r_ear

        if thermal is None:
            print("  WARNING: no thermal data — skipping this image."); continue

        # ── save overlay ──────────────────────────────────────────────────────
        label       = f"T{idx+1:03d}_{t.strftime('%Y-%m-%d_%H-%M-%S')}"
        overlay_bgr = draw_regions(rgb_bgr, regions)
        rel_overlay = _save_overlay(out_dir, label, overlay_bgr)

        # ── extract and save raw thermal pixel arrays + pixel coordinates ─────
        pixel_dict = {}
        for rname, poly in regions.items():
            vals, coords = get_polygon_values(thermal, poly, rgb_bgr.shape)
            pixel_dict[rname]              = vals
            pixel_dict[f"{rname}__coords"] = coords
            m = float(np.mean(vals))
            v = float(np.var(vals, ddof=1)) if vals.size > 1 else 0.0
            print(f"    {rname:20s}  mean={m:7.3f}  var={v:.4f}  npx={int(vals.size)}")
        rel_pixels = _save_pixels(out_dir, label, pixel_dict)

        act_start = session_times["act_start"]
        act_end   = session_times["act_end"]
        active    = act_start <= t <= act_end

        timepoints.append({
            "index":        idx,
            "label":        label,
            "timestamp":    t.isoformat(),
            "elapsed_s":    round((t - times_kept[0]).total_seconds(), 3),
            "active":       active,
            "source_filename": os.path.basename(img_item["path"]),
            "overlay_file": rel_overlay,
            "pixel_file":   rel_pixels,
            "regions":      list(pixel_dict.keys()),
        })

    if not timepoints:
        print("\nNo images processed — session not saved.")
        return None

    meta = {
        "session_type":  "back",
        "created":       datetime.now().isoformat(),
        "source_dir":    img_dir,
        "session_times": {k: v.isoformat() for k, v in session_times.items()},
        "n_timepoints":  len(timepoints),
        "timepoints":    timepoints,
    }
    _write_meta(out_dir, meta)

    n = len(timepoints)
    print(f"\nExtraction complete.  {n} images saved.")
    print(f"  Overlays : {out_dir}/overlays/  ({n} PNG files)")
    print(f"  Pixels   : {out_dir}/pixels/   ({n} NPZ files)")

    return meta


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="Back FLIR extractor — Stage 1: segmentation and raw data extraction")
    ap.add_argument("img_dir",  help="Folder of FLIR JPEG images")
    ap.add_argument("out_dir",  help="Output session directory (will be created)")
    ap.add_argument("--model", default="yolov8n-pose.pt",
                    help="YOLOv8 pose model  (default: yolov8n-pose.pt). "
                         "Use yolov8m-pose.pt for better accuracy.")
    args = ap.parse_args()
    result = run(args.img_dir, args.out_dir, model=args.model)
    if result is None:
        sys.exit(0)


if __name__ == "__main__":
    main()
