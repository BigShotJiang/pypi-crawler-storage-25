#!/usr/bin/env python3
"""
profile_mesh_editor.py  —  Interactive Profile-View ROI Editor
Uses YOLOv8 pose to detect the visible eye, ear, and nose.
ALL coordinates are expressed in a dual oblique basis anchored at the eye:

    pixel = eye  +  u × L × ê_ear  +  v × D × ê_nose

where
    ê_ear   unit vector  eye → ear         L = |ear  − eye|  (eye-ear  length)
    ê_nose  unit vector  eye → nose        D = |nose − eye|  (eye-nose length)
    u, v    dimensionless fractions — each scaled by its own anatomical unit

This means EVERY point in the image is described by two coordinates that are
independently normalised: u counts in units of "how far toward the ear" and
v in units of "how far toward the nose".  The two axes are generally oblique
(not orthogonal), forming a natural anatomical parallelogram grid.

Run:
    python profile_mesh_editor.py <profile_photo.jpg> --side left
    python profile_mesh_editor.py <profile_photo.jpg> --side right
    python profile_mesh_editor.py <photo.jpg> --side left --model yolov8m-pose.pt
    python profile_mesh_editor.py <photo.jpg> --side left --manual

    Run the tool twice (once per side) to define both left and right meshes,
    then paste both exported blocks into Dual_FLIR_Extractor.py.

FLIR SUPPORT
    FLIR JPEG files are auto-detected.  Embedded RGB is extracted via
    flyr (bundle.optical) with PIL outer-JPEG fallback.  Press T to toggle RGB ↔ thermal.

OUTPUT  (press E):
    Prints Python code ready to paste into Dual_FLIR_Extractor.py.
    Also saves  left_profile_region_defs.py  (or right_…)  in the current folder.

COORDINATE SYSTEM  (u, v)  — oblique dual-basis anchored at eye
    Origin  : eye landmark

    u  along  eye → ear  (posterior),  normalised by  L  (eye-ear distance):
         u = 0.0  →  eye
         u = 1.0  →  ear tip

    v  along  eye → nose  (anterior-inferior),  normalised by  D  (eye-nose dist):
         v = 0.0  →  eye
         v = 1.0  →  nose tip

    Crown / parietal  →  large u,  negative v  (v < 0 = away from nose)
    Jaw / neck        →  small u,  large positive v

RECONSTRUCTION (given eye, ear, nose as pixel arrays):
    e_ear  = (ear  - eye) / L          # unit vector eye→ear
    e_nose = (nose - eye) / D          # unit vector eye→nose
    pixel  = eye  +  u * L * e_ear  +  v * D * e_nose

INVERSION (pixel → u, v) — 2×2 oblique solve:
    A   = L * e_ear
    B   = D * e_nose
    det = A.x*B.y − A.y*B.x
    u   = ( delta.x*B.y − delta.y*B.x ) / det
    v   = ( A.x*delta.y − A.y*delta.x ) / det
    where  delta = pixel − eye

CONTROLS
────────────────────────────────────────────────────────────────────────────────
 POLYGON MODE  (default)
   Left-click near existing anchor  →  add it to the current polygon
   Left-click on empty area         →  auto-place new anchor → name dialog
                                        → immediately added to current polygon
   Enter                            →  finish polygon → name dialog (≥3 pts)
   Backspace                        →  remove last polygon point
   Escape                           →  cancel current polygon (or quit if empty)
   Delete                           →  delete last completed polygon

 ANCHOR MODE  (press A)
   Left-click anywhere              →  place new anchor → name dialog
   Left-click + drag                →  reposition anchor (UV updated live)
   Double-click anchor              →  rename anchor
   Right-click anchor               →  delete anchor

 LANDMARK REPOSITIONING
   Y   →  next left-click sets the EYE  position (rebuilds entire basis)
   R   →  next left-click sets the EAR  position (rebuilds entire basis)
   O   →  next left-click sets the NOSE position (rebuilds entire basis)
   (Esc while in set mode cancels)

 VIEW
   F          toggle polygon fill
   G          toggle parallelogram grid overlay
   N          toggle anchor name / UV labels
   T          toggle RGB ↔ thermal  (FLIR images only)
   Scroll     zoom in / out (anchored to cursor)
   Middle-drag  →  pan
   V          reset view to fit image
   +  /  -    zoom ±20 %
   E          export code
   Q          quit
────────────────────────────────────────────────────────────────────────────────
"""

import sys
import os
import io
import colorsys
import argparse
import subprocess
import shutil
import glob
import site

import numpy as np
import cv2

try:
    import tkinter as tk
    from tkinter import simpledialog, messagebox
    _TK = True
except Exception:
    _TK = False


# ── tiny TK helpers ────────────────────────────────────────────────────────────

def _ask(title: str, prompt: str, default: str = "") -> str | None:
    if _TK:
        root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True)
        v = simpledialog.askstring(title, prompt, initialvalue=default, parent=root)
        root.destroy()
        return v
    raw = input(f"{prompt} [{default}]: ").strip()
    return raw if raw else default


def _info(title: str, msg: str) -> None:
    if _TK:
        root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True)
        messagebox.showinfo(title, msg, parent=root)
        root.destroy()
    else:
        print(f"[{title}] {msg}")


def _palette(idx: int) -> tuple:
    h = (idx * 0.137) % 1.0
    r, g, b = colorsys.hsv_to_rgb(h, 0.85, 0.95)
    return (int(b * 255), int(g * 255), int(r * 255))   # BGR


# ── COCO-17 keypoint indices ───────────────────────────────────────────────────
_COCO_NOSE        = 0
_COCO_LEFT_EYE    = 1
_COCO_RIGHT_EYE   = 2
_COCO_LEFT_EAR    = 3
_COCO_RIGHT_EAR   = 4

_SKELETON = [
    (0, 1), (0, 2), (1, 3), (2, 4), (5, 6),
    (5, 7), (7, 9), (6, 8), (8, 10),
    (5, 11), (6, 12), (11, 12),
    (11, 13), (13, 15), (12, 14), (14, 16),
]

_SIDE_EYE = {'left': _COCO_LEFT_EYE,  'right': _COCO_RIGHT_EYE}
_SIDE_EAR = {'left': _COCO_LEFT_EAR,  'right': _COCO_RIGHT_EAR}
# Nose (idx 0) is the same for both sides

# Landmark display colours (BGR)
_COL_EYE  = (0,   200, 255)   # cyan
_COL_EAR  = (0,   220,  80)   # green
_COL_NOSE = (50,  120, 255)   # orange


# ── YOLOv8 profile detection ──────────────────────────────────────────────────

def run_yolo_profile(bgr: np.ndarray, side: str,
                     model_path: str = "yolov8n-pose.pt"):
    """
    Run YOLOv8 pose on *bgr* and extract eye, ear, nose keypoints for *side*.

    Returns
    -------
    (eye_px, ear_px, nose_px, kps_17x3, conf_eye, conf_ear, conf_nose)
    or  None  on failure.
    """
    try:
        from ultralytics import YOLO
    except ImportError:
        print("ERROR: ultralytics not installed — run:  pip install ultralytics")
        return None

    eye_idx  = _SIDE_EYE[side]
    ear_idx  = _SIDE_EAR[side]

    model   = YOLO(model_path)
    results = model(bgr, verbose=False)
    if not results or results[0].keypoints is None:
        return None

    kps_t = results[0].keypoints.data
    if kps_t is None or len(kps_t) == 0:
        return None

    boxes = results[0].boxes
    best  = (int(np.argmax(boxes.conf.cpu().numpy()))
             if boxes is not None and len(boxes.conf) > 0 else 0)

    kps       = kps_t[best].cpu().numpy()   # (17, 3)
    eye_kp    = kps[eye_idx]
    ear_kp    = kps[ear_idx]
    nose_kp   = kps[_COCO_NOSE]
    conf_eye  = float(eye_kp[2])
    conf_ear  = float(ear_kp[2])
    conf_nose = float(nose_kp[2])

    if conf_eye < 0.10 and conf_ear < 0.10:
        print(f"[YOLO] {side.upper()} eye + ear too uncertain "
              f"(eye={conf_eye:.2f}  ear={conf_ear:.2f}).")
        return None

    for lm_name, conf in [("eye", conf_eye), ("ear", conf_ear), ("nose", conf_nose)]:
        if conf < 0.20:
            print(f"[YOLO] {side.upper()} {lm_name} low confidence ({conf:.2f}) — "
                  f"reposition with Y/R/O keys if needed.")

    return (
        np.array([float(eye_kp[0]),  float(eye_kp[1])]),
        np.array([float(ear_kp[0]),  float(ear_kp[1])]),
        np.array([float(nose_kp[0]), float(nose_kp[1])]),
        kps,
        conf_eye, conf_ear, conf_nose,
    )


def click_landmarks_manually(bgr: np.ndarray, side: str):
    """Click EYE → EAR → NOSE.  Returns (eye, ear, nose) as float ndarrays."""
    WIN    = "_profile_placement_"
    clicks = []
    S      = side.upper()
    colors  = [_COL_EYE, _COL_EAR, _COL_NOSE]
    names   = [f"{S}-EYE", f"{S}-EAR", "NOSE"]
    prompts = [f"1. Click {S} EYE",
               f"2. Click {S} EAR",
               "3. Click NOSE TIP",
               "Press any key to confirm"]

    def _cb(event, cx, cy, _f, _p):
        if event == cv2.EVENT_LBUTTONDOWN and len(clicks) < 3:
            clicks.append(np.array([float(cx), float(cy)]))

    cv2.namedWindow(WIN, cv2.WINDOW_NORMAL)
    ih, iw = bgr.shape[:2]
    cv2.resizeWindow(WIN, min(iw, 1200), min(ih, 900))
    cv2.setMouseCallback(WIN, _cb)

    while True:
        step = len(clicks)
        disp = bgr.copy()
        for i, c in enumerate(clicks):
            cv2.circle(disp, (int(c[0]), int(c[1])), 12, colors[i], 2, cv2.LINE_AA)
            cv2.circle(disp, (int(c[0]), int(c[1])),  4, colors[i], -1, cv2.LINE_AA)
            cv2.putText(disp, names[i], (int(c[0]) + 14, int(c[1]) + 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 3)
            cv2.putText(disp, names[i], (int(c[0]) + 14, int(c[1]) + 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, colors[i], 1)
        label = prompts[min(step, 3)]
        cv2.putText(disp, label, (20, 44),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.1, (0, 0, 0), 6, cv2.LINE_AA)
        cv2.putText(disp, label, (20, 44),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.1, (0, 220, 255), 2, cv2.LINE_AA)
        cv2.imshow(WIN, disp)
        k = cv2.waitKey(20)
        if step >= 3 and k != -1:
            break
        if k == 27:
            cv2.destroyWindow(WIN)
            print("Landmark placement cancelled.")
            sys.exit(1)

    cv2.destroyWindow(WIN)
    if len(clicks) < 3:
        print("Need 3 clicks (eye, ear, nose).")
        sys.exit(1)
    return clicks[0], clicks[1], clicks[2]


# ── Dual-basis geometry ────────────────────────────────────────────────────────

def _build_basis(eye, ear, nose):
    """
    Build the oblique dual basis from the three landmarks.

    Returns (L, D, A, B, det) where
        L   = |ear  − eye|         eye-ear  pixel distance
        D   = |nose − eye|         eye-nose pixel distance
        A   = L * e_ear            ear  basis vector (pixels)
        B   = D * e_nose           nose basis vector (pixels)
        det = A.x*B.y − A.y*B.x   determinant for inversion
    """
    diff_ear  = ear  - eye
    diff_nose = nose - eye
    L = max(float(np.hypot(*diff_ear)),  1.0)
    D = max(float(np.hypot(*diff_nose)), 1.0)
    A = diff_ear          # = L * e_ear  (no need to divide and re-multiply)
    B = diff_nose         # = D * e_nose
    det = float(A[0] * B[1] - A[1] * B[0])
    return L, D, A, B, det


def _px_to_uv(ix, iy, eye, A, B, det):
    """Image pixel → oblique (u, v).  u in units of L, v in units of D."""
    if abs(det) < 1e-6:
        return 0.0, 0.0
    dx, dy = ix - eye[0], iy - eye[1]
    u = (dx * B[1] - dy * B[0]) / det
    v = (A[0] * dy - A[1] * dx) / det
    return round(u, 4), round(v, 4)


def _uv_to_px(u, v, eye, A, B):
    """Oblique (u, v) → image pixel coords."""
    return eye + u * A + v * B


# ── Editor ─────────────────────────────────────────────────────────────────────

class Editor:
    FONT   = cv2.FONT_HERSHEY_SIMPLEX
    CW, CH = 1440, 980
    CTRL_H = 72

    def __init__(self, bgr, eye, ear, nose, side,
                 kps=None, conf_eye=None, conf_ear=None, conf_nose=None,
                 thermal_bgr=None):
        self.bgr         = bgr
        self.thermal_bgr = thermal_bgr
        self.show_thermal = False
        self.kps       = kps
        self.conf_eye  = conf_eye
        self.conf_ear  = conf_ear
        self.conf_nose = conf_nose
        self.side      = side

        # Mutable landmarks
        self.eye  = np.array(eye,  dtype=float)
        self.ear  = np.array(ear,  dtype=float)
        self.nose = np.array(nose, dtype=float)
        self._rebuild_basis()

        # View
        self.zoom      = 1.0
        self.pan       = np.array([0.0, 0.0])
        self._panning  = False
        self._pan_last = None

        # Toggles
        self.show_fill   = True
        self.show_grid   = True
        self.show_names  = True
        self.anchor_mode = False

        # Landmark-set mode: None | 'eye' | 'ear' | 'nose'
        self._set_mode    = None
        self._drag_anchor = None

        # Data
        self.anchors = {}   # {name: {'u': float, 'v': float}}
        self.regions = []   # [{'name': str, 'pts': [...], 'color': BGR}]
        self.cur_pts = []   # names in polygon being built

        ih, iw = self.bgr.shape[:2]
        self.zoom = min((self.CH - self.CTRL_H) / ih, self.CW / iw)
        self.pan  = np.array([(self.CW - iw * self.zoom) / 2.0, 0.0])

        S = side.upper()
        self.WIN = (
            f"Profile Mesh Editor [{S}]  |  "
            "A=anchor  F=fill  G=grid  N=names  "
            "Y=set-eye  R=set-ear  O=set-nose  E=export  J=json  Q=quit"
        )
        cv2.namedWindow(self.WIN, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(self.WIN, self.CW, self.CH)
        cv2.setMouseCallback(self.WIN, self._mouse)
        self.render()

    # ── basis ─────────────────────────────────────────────────────────────────

    def _rebuild_basis(self):
        self.L, self.D, self.A, self.B, self.det = \
            _build_basis(self.eye, self.ear, self.nose)

    # ── coordinate transforms ─────────────────────────────────────────────────

    def i2c(self, ix, iy):
        return (int(ix * self.zoom + self.pan[0]),
                int(iy * self.zoom + self.pan[1]) + self.CTRL_H)

    def c2i(self, cx, cy):
        return ((cx - self.pan[0]) / self.zoom,
                (cy - self.CTRL_H - self.pan[1]) / self.zoom)

    def _to_uv(self, ix, iy):
        return _px_to_uv(ix, iy, self.eye, self.A, self.B, self.det)

    def _from_uv(self, u, v):
        return _uv_to_px(u, v, self.eye, self.A, self.B)

    def anc_pixel(self, name):
        a = self.anchors[name]
        return self._from_uv(a['u'], a['v'])

    def anc_canvas(self, name):
        p = self.anc_pixel(name)
        return self.i2c(p[0], p[1])

    # ── nearest anchor ────────────────────────────────────────────────────────

    def _nearest_anchor(self, cx, cy, thr=18):
        best, bd = None, thr ** 2
        for name in self.anchors:
            acx, acy = self.anc_canvas(name)
            d = (cx - acx) ** 2 + (cy - acy) ** 2
            if d < bd:
                bd = d; best = name
        return best

    # ── render ────────────────────────────────────────────────────────────────

    def render(self):
        cw, ch = self.CW, self.CH
        canvas = np.full((ch, cw, 3), (28, 28, 28), np.uint8)

        # image (darkened)
        src = (self.thermal_bgr
               if (self.show_thermal and self.thermal_bgr is not None)
               else self.bgr)
        ih, iw = src.shape[:2]
        sw, sh = int(iw * self.zoom), int(ih * self.zoom)
        img_s  = cv2.resize(src, (sw, sh), interpolation=cv2.INTER_LINEAR)
        img_s  = (img_s * 0.58).astype(np.uint8)
        ox = int(self.pan[0]); oy = int(self.pan[1]) + self.CTRL_H
        x0, y0 = max(0, ox), max(0, oy)
        x1, y1 = min(cw, ox + sw), min(ch, oy + sh)
        if x1 > x0 and y1 > y0:
            canvas[y0:y1, x0:x1] = img_s[y0 - oy:y1 - oy, x0 - ox:x1 - ox]

        # YOLO skeleton
        if self.kps is not None:
            for (i, j) in _SKELETON:
                if self.kps[i, 2] > 0.25 and self.kps[j, 2] > 0.25:
                    cv2.line(canvas,
                             self.i2c(self.kps[i, 0], self.kps[i, 1]),
                             self.i2c(self.kps[j, 0], self.kps[j, 1]),
                             (45, 45, 75), 1, cv2.LINE_AA)
            skip = {_COCO_LEFT_EYE, _COCO_RIGHT_EYE,
                    _COCO_LEFT_EAR,  _COCO_RIGHT_EAR, _COCO_NOSE}
            for k in range(17):
                if self.kps[k, 2] > 0.25 and k not in skip:
                    cv2.circle(canvas, self.i2c(self.kps[k, 0], self.kps[k, 1]),
                               3, (50, 65, 105), -1)

        # oblique parallelogram grid
        if self.show_grid:
            self._draw_grid(canvas)

        # basis frame
        self._draw_basis_frame(canvas)

        # completed regions
        for reg in self.regions:
            poly = self._build_poly(reg['pts'])
            if poly is None or len(poly) < 3:
                continue
            col = reg['color']
            if self.show_fill:
                ov = canvas.copy()
                cv2.fillPoly(ov, [poly], col)
                cv2.addWeighted(ov, 0.33, canvas, 0.67, 0, canvas)
            cv2.polylines(canvas, [poly], True, col, 2, cv2.LINE_AA)
            ctr = poly.mean(0).astype(int)
            cv2.putText(canvas, reg['name'], tuple(ctr),
                        self.FONT, 0.50, (0, 0, 0), 2, cv2.LINE_AA)
            cv2.putText(canvas, reg['name'], tuple(ctr),
                        self.FONT, 0.50, col, 1, cv2.LINE_AA)

        # polygon in progress
        if self.cur_pts:
            pts = self._build_poly(self.cur_pts)
            if pts is not None and len(pts) >= 1:
                for i, pt in enumerate(pts):
                    cv2.circle(canvas, tuple(pt), 8, (0, 240, 240), -1, cv2.LINE_AA)
                    cv2.circle(canvas, tuple(pt), 8, (255, 255, 255), 1, cv2.LINE_AA)
                    if i > 0:
                        cv2.line(canvas, tuple(pts[i - 1]), tuple(pt),
                                 (0, 240, 240), 2, cv2.LINE_AA)
                if len(pts) > 1:
                    cv2.line(canvas, tuple(pts[-1]), tuple(pts[0]),
                             (0, 240, 240), 1, cv2.LINE_AA)

        # anchors
        box_r = max(5, int(8 * min(self.zoom, 2.0)))
        for name, a in self.anchors.items():
            p = self.anc_pixel(name)
            acx, acy = self.i2c(p[0], p[1])
            if not (0 <= acx < cw and self.CTRL_H <= acy < ch):
                continue
            in_poly = name in self.cur_pts
            col = (0, 240, 240) if in_poly else (0, 220, 60)
            cv2.rectangle(canvas,
                          (acx - box_r, acy - box_r),
                          (acx + box_r, acy + box_r), col, -1)
            cv2.rectangle(canvas,
                          (acx - box_r, acy - box_r),
                          (acx + box_r, acy + box_r), (255, 255, 255), 1)
            if self.show_names:
                fs  = max(0.22, 0.30 * min(self.zoom, 2.0))
                lbl = f"{name}  u={a['u']:+.2f}  v={a['v']:+.2f}"
                cv2.putText(canvas, lbl, (acx + box_r + 3, acy + 4),
                            self.FONT, fs, (0, 0, 0), 2, cv2.LINE_AA)
                cv2.putText(canvas, lbl, (acx + box_r + 3, acy + 4),
                            self.FONT, fs, col, 1, cv2.LINE_AA)

        # landmark markers
        self._draw_landmarks(canvas)

        # control bar
        cv2.rectangle(canvas, (0, 0), (cw, self.CTRL_H), (18, 18, 18), -1)
        cv2.line(canvas, (0, self.CTRL_H), (cw, self.CTRL_H), (60, 60, 60), 1)

        if self._set_mode == 'eye':
            mode_txt, mode_col = "[ CLICK TO SET EYE  — Esc to cancel ]", _COL_EYE
        elif self._set_mode == 'ear':
            mode_txt, mode_col = "[ CLICK TO SET EAR  — Esc to cancel ]", _COL_EAR
        elif self._set_mode == 'nose':
            mode_txt, mode_col = "[ CLICK TO SET NOSE — Esc to cancel ]", _COL_NOSE
        elif self.anchor_mode:
            mode_txt, mode_col = "[ ANCHOR MODE ]", (60, 220, 255)
        else:
            mode_txt, mode_col = "[ POLYGON MODE ]", (80, 255, 100)

        cur_str = f"  •  {len(self.cur_pts)} pt(s) in progress" if self.cur_pts else ""

        # oblique angle between axes
        with np.errstate(invalid='ignore'):
            cos_a = np.clip(np.dot(self.A / self.L, self.B / self.D), -1.0, 1.0)
        angle_deg = float(np.degrees(np.arccos(cos_a)))

        S = self.side.upper()
        side_col = (100, 140, 255) if self.side == 'left' else (80, 230, 80)
        stats = (f"  |  SIDE={S}  "
                 f"L={self.L:.0f}px  D={self.D:.0f}px  "
                 f"axis-angle={angle_deg:.1f}°  "
                 f"{len(self.anchors)} anchors  {len(self.regions)} regions  "
                 f"zoom={self.zoom:.2f}×")

        cv2.putText(canvas, mode_txt + cur_str, (10, 24),
                    self.FONT, 0.52, mode_col, 1, cv2.LINE_AA)
        cv2.putText(canvas, stats, (340, 24),
                    self.FONT, 0.38, (130, 130, 130), 1, cv2.LINE_AA)
        cv2.putText(canvas, f"SIDE: {S}", (10, 54),
                    self.FONT, 0.44, side_col, 1, cv2.LINE_AA)
        cv2.putText(canvas,
                    ("A=anchor  F=fill  G=grid  N=names  "
                     "Y=set-eye  R=set-ear  O=set-nose  T=thermal  "
                     "V=reset  +/-=zoom  Enter=finish-poly  Del=undo-region  "
                     "E=export  J=json  Q=quit"),
                    (100, 54), self.FONT, 0.29, (90, 90, 90), 1, cv2.LINE_AA)

        cv2.imshow(self.WIN, canvas)

    # ── oblique grid ──────────────────────────────────────────────────────────

    def _draw_grid(self, canvas):
        """Draw iso-u and iso-v lines of the oblique parallelogram grid."""
        cw, ch = self.CW, self.CH
        col_u = (50, 50, 90)   # iso-u  (lines parallel to nose axis)
        col_v = (65, 42, 42)   # iso-v  (lines parallel to ear  axis)
        step   = 0.25
        t_vals = np.linspace(-2.5, 4.5, 160)

        def _draw_line(u_fix, v_fix, sweep_u):
            pts = []
            for t in t_vals:
                p = (self._from_uv(t, v_fix) if sweep_u
                     else self._from_uv(u_fix, t))
                cx, cy = self.i2c(p[0], p[1])
                if 0 <= cx < cw and self.CTRL_H <= cy < ch:
                    pts.append((cx, cy))
                elif pts:
                    if len(pts) >= 2:
                        cv2.polylines(canvas,
                                      [np.array(pts, np.int32)],
                                      False,
                                      col_u if sweep_u else col_v,
                                      1, cv2.LINE_AA)
                    pts = []
            if len(pts) >= 2:
                cv2.polylines(canvas,
                              [np.array(pts, np.int32)],
                              False,
                              col_u if sweep_u else col_v,
                              1, cv2.LINE_AA)

        for u in np.arange(-1.0, 3.01, step):
            _draw_line(u, 0, sweep_u=False)   # iso-u: fix u, sweep v
        for v in np.arange(-1.5, 3.01, step):
            _draw_line(0, v, sweep_u=True)    # iso-v: fix v, sweep u

        # dots at grid intersections
        for u in np.arange(-1.0, 3.01, step * 2):
            for v in np.arange(-1.5, 3.01, step * 2):
                p = self._from_uv(u, v)
                cx, cy = self.i2c(p[0], p[1])
                if 0 <= cx < cw and self.CTRL_H <= cy < ch:
                    cv2.circle(canvas, (cx, cy), 2, (80, 80, 120), -1)

    # ── basis frame ───────────────────────────────────────────────────────────

    def _draw_basis_frame(self, canvas):
        """Annotated arrows showing both basis vectors from the eye origin."""
        eye_c  = self.i2c(self.eye[0],  self.eye[1])
        ear_c  = self.i2c(self.ear[0],  self.ear[1])
        nose_c = self.i2c(self.nose[0], self.nose[1])

        # u-axis: eye → ear
        cv2.arrowedLine(canvas, eye_c, ear_c,
                        (0, 160, 60), 2, cv2.LINE_AA, tipLength=0.08)
        mid_u = ((eye_c[0] + ear_c[0]) // 2, (eye_c[1] + ear_c[1]) // 2)
        cv2.putText(canvas, "u (×L)", (mid_u[0] + 4, mid_u[1] - 6),
                    self.FONT, 0.38, (0, 160, 60), 1, cv2.LINE_AA)
        cv2.putText(canvas, f"L={self.L:.0f}px",
                    (ear_c[0] + 6, ear_c[1] + 4),
                    self.FONT, 0.30, (0, 160, 60), 1, cv2.LINE_AA)

        # v-axis: eye → nose
        cv2.arrowedLine(canvas, eye_c, nose_c,
                        (30, 80, 220), 2, cv2.LINE_AA, tipLength=0.08)
        mid_v = ((eye_c[0] + nose_c[0]) // 2, (eye_c[1] + nose_c[1]) // 2)
        cv2.putText(canvas, "v (×D)", (mid_v[0] + 4, mid_v[1] - 6),
                    self.FONT, 0.38, (30, 80, 220), 1, cv2.LINE_AA)
        cv2.putText(canvas, f"D={self.D:.0f}px",
                    (nose_c[0] + 6, nose_c[1] + 4),
                    self.FONT, 0.30, (30, 80, 220), 1, cv2.LINE_AA)

        # origin dot at eye
        cv2.circle(canvas, eye_c, 5, (200, 200, 200), -1, cv2.LINE_AA)
        cv2.putText(canvas, "origin", (eye_c[0] + 8, eye_c[1] + 14),
                    self.FONT, 0.28, (160, 160, 160), 1, cv2.LINE_AA)

    # ── landmark markers ──────────────────────────────────────────────────────

    def _draw_landmarks(self, canvas):
        S = self.side.upper()
        for pt, col, lbl, conf, mk in [
            (self.eye,  _COL_EYE,  f"{S}-EYE", self.conf_eye,  'eye'),
            (self.ear,  _COL_EAR,  f"{S}-EAR", self.conf_ear,  'ear'),
            (self.nose, _COL_NOSE, "NOSE",      self.conf_nose, 'nose'),
        ]:
            cx, cy = self.i2c(pt[0], pt[1])
            ring = (0, 200, 255) if self._set_mode == mk else col
            cv2.circle(canvas, (cx, cy), 14, ring, 2, cv2.LINE_AA)
            cv2.circle(canvas, (cx, cy),  4, ring, -1, cv2.LINE_AA)
            tag = f"{lbl} ({conf:.2f})" if conf is not None else lbl
            cv2.putText(canvas, tag, (cx + 16, cy + 5),
                        self.FONT, 0.40, (0, 0, 0), 3, cv2.LINE_AA)
            cv2.putText(canvas, tag, (cx + 16, cy + 5),
                        self.FONT, 0.40, ring, 1, cv2.LINE_AA)

    # ── polygon builder ───────────────────────────────────────────────────────

    def _build_poly(self, names):
        pts = []
        for name in names:
            if name not in self.anchors:
                return None
            pts.append(self.anc_canvas(name))
        return np.array(pts, dtype=np.int32) if pts else None

    def _place_anchor(self, ix, iy, add_to_poly):
        u, v = self._to_uv(ix, iy)
        default = f"A{len(self.anchors) + 1:02d}"
        name = _ask("New Anchor", "Anchor name:", default)
        if not name:
            return
        name = name.strip().upper().replace(" ", "_")
        if name in self.anchors:
            _info("Duplicate", f"'{name}' already exists.")
            return
        self.anchors[name] = {'u': u, 'v': v}
        if add_to_poly:
            self.cur_pts.append(name)
        self.render()

    # ── mouse ─────────────────────────────────────────────────────────────────

    def _mouse(self, event, cx, cy, flags, _param):
        # scroll zoom (cursor-anchored)
        if event == cv2.EVENT_MOUSEWHEEL:
            f = 1.12 if flags > 0 else 1.0 / 1.12
            ix, iy = self.c2i(cx, cy)
            self.zoom = max(0.05, min(10.0, self.zoom * f))
            ncx, ncy = self.i2c(ix, iy)
            self.pan[0] += cx - ncx
            self.pan[1] += (cy - self.CTRL_H) - (ncy - self.CTRL_H)
            self.render(); return

        # middle-button pan
        if event == cv2.EVENT_MBUTTONDOWN:
            self._panning = True; self._pan_last = (cx, cy); return
        if event == cv2.EVENT_MBUTTONUP:
            self._panning = False; return

        if event == cv2.EVENT_MOUSEMOVE:
            if self._panning and self._pan_last:
                self.pan[0] += cx - self._pan_last[0]
                self.pan[1] += cy - self._pan_last[1]
                self._pan_last = (cx, cy); self.render()
            if self._drag_anchor:
                ix, iy = self.c2i(cx, cy)
                u, v = self._to_uv(ix, iy)
                self.anchors[self._drag_anchor]['u'] = u
                self.anchors[self._drag_anchor]['v'] = v
                self.render()
            return

        if event == cv2.EVENT_LBUTTONUP and self._drag_anchor:
            self._drag_anchor = None; return

        if cy < self.CTRL_H and not self._set_mode:
            return

        # landmark-set mode
        if self._set_mode and event == cv2.EVENT_LBUTTONDOWN:
            ix, iy = self.c2i(cx, cy)
            setattr(self, self._set_mode, np.array([ix, iy]))
            if self._set_mode == 'eye':   self.conf_eye  = None
            elif self._set_mode == 'ear': self.conf_ear  = None
            else:                         self.conf_nose = None
            self._rebuild_basis()
            self._set_mode = None
            self.render(); return

        if event == cv2.EVENT_LBUTTONDOWN:
            if self.anchor_mode:
                an = self._nearest_anchor(cx, cy)
                if an:
                    self._drag_anchor = an; return
                ix, iy = self.c2i(cx, cy)
                self._place_anchor(ix, iy, add_to_poly=False)
            else:
                an = self._nearest_anchor(cx, cy)
                if an:
                    if an not in self.cur_pts:
                        self.cur_pts.append(an)
                    self.render(); return
                ix, iy = self.c2i(cx, cy)
                self._place_anchor(ix, iy, add_to_poly=True)

        if event == cv2.EVENT_RBUTTONDOWN:
            an = self._nearest_anchor(cx, cy)
            if an:
                for reg in self.regions:
                    reg['pts'] = [p for p in reg['pts'] if p != an]
                self.cur_pts = [p for p in self.cur_pts if p != an]
                del self.anchors[an]
                self.render()

        if event == cv2.EVENT_LBUTTONDBLCLK:
            an = self._nearest_anchor(cx, cy)
            if an:
                nn = _ask("Rename", "New name:", an)
                if nn and nn != an:
                    nn = nn.strip().upper().replace(" ", "_")
                    self.anchors[nn] = self.anchors.pop(an)
                    for reg in self.regions:
                        reg['pts'] = [nn if p == an else p for p in reg['pts']]
                    self.cur_pts = [nn if p == an else p for p in self.cur_pts]
                self.render()

    # ── keyboard ─────────────────────────────────────────────────────────────

    def key(self, k):
        if self._set_mode and k == 27:
            self._set_mode = None

        elif k in (13, 10):   # Enter
            if len(self.cur_pts) >= 3:
                name = _ask("Region name", "e.g.  Parietal / Jaw / Cheek",
                            f"Region_{len(self.regions) + 1}")
                if name:
                    self.regions.append({'name': name.strip(),
                                         'pts':  list(self.cur_pts),
                                         'color': _palette(len(self.regions))})
                    self.cur_pts = []
            else:
                _info("Too few points", "A polygon needs ≥ 3 anchors.")

        elif k == 8:           # Backspace
            if self.cur_pts: self.cur_pts.pop()

        elif k == 27:          # Esc
            if self.cur_pts: self.cur_pts = []
            else: return "quit"

        elif k in (ord('q'), ord('Q')):
            return "quit"

        elif k in (127, 255, 3014656):   # Delete
            if self.regions: self.regions.pop()

        elif k in (ord('a'), ord('A')): self.anchor_mode = not self.anchor_mode
        elif k in (ord('f'), ord('F')): self.show_fill   = not self.show_fill
        elif k in (ord('g'), ord('G')): self.show_grid   = not self.show_grid
        elif k in (ord('n'), ord('N')): self.show_names  = not self.show_names
        elif k in (ord('y'), ord('Y')): self._set_mode   = 'eye'
        elif k in (ord('r'), ord('R')): self._set_mode   = 'ear'
        elif k in (ord('o'), ord('O')): self._set_mode   = 'nose'

        elif k in (ord('t'), ord('T')):
            if self.thermal_bgr is not None:
                self.show_thermal = not self.show_thermal
            else:
                print("  [T] No thermal image available.")

        elif k in (ord('v'), ord('V')):
            active = (self.thermal_bgr
                      if (self.show_thermal and self.thermal_bgr is not None)
                      else self.bgr)
            ih, iw = active.shape[:2]
            self.zoom = min((self.CH - self.CTRL_H) / ih, self.CW / iw)
            self.pan  = np.array([(self.CW - iw * self.zoom) / 2.0, 0.0])

        elif k in (ord('+'), ord('=')): self.zoom = min(10.0, self.zoom * 1.20)
        elif k == ord('-'):             self.zoom = max(0.10, self.zoom / 1.20)
        elif k in (ord('e'), ord('E')): self.export()
        elif k in (ord('j'), ord('J')): self.export_json()

        self.render()
        return None

    # ── export ────────────────────────────────────────────────────────────────

    def export(self):
        s     = self.side
        S     = s.upper()
        VNAME = f"{S}_PROFILE"
        fn_c  = f"compute_anchor_pixels_{s}_profile"
        fn_b  = f"build_region_polys_{s}_profile"
        fn_d  = f"draw_regions_{s}_profile"
        fn_bas = f"_build_{s}_profile_basis"

        lines = [
            "# ══════════════════════════════════════════════════════════════════════════════",
            f"# Paste into Dual_FLIR_Extractor.py  ({S} profile — dual oblique-basis mesh)",
            "# ══════════════════════════════════════════════════════════════════════════════",
            "#",
            "# DUAL OBLIQUE COORDINATE SYSTEM  (u, v)",
            "#",
            "#   Three YOLO landmarks:  eye (origin),  ear,  nose",
            "#",
            "#   pixel = eye  +  u × A  +  v × B",
            "#       A = ear  - eye   (= L × ê_ear,   L = eye-ear  distance)",
            "#       B = nose - eye   (= D × ê_nose,  D = eye-nose distance)",
            "#",
            "#   u = 0 → eye,   u = 1 → ear tip      (posterior axis, scaled by L)",
            "#   v = 0 → eye,   v = 1 → nose tip      (anterior  axis, scaled by D)",
            "#",
            "#   crown / parietal  → large +u,  negative v",
            "#   jaw / neck        → small  u,  large   +v",
            "#",
            "# INVERSION  (pixel → u, v) — 2×2 oblique solve:",
            "#   det = A.x*B.y − A.y*B.x",
            "#   u   = (delta.x*B.y − delta.y*B.x) / det",
            "#   v   = (A.x*delta.y − A.y*delta.x) / det",
            "#   where delta = pixel − eye",
            "#",
            "# INTEGRATION into Dual_FLIR_Extractor.py",
            f"#   For the {S} side, replace compute_all_vertices() + draw_regions_from_verts()",
            "#   with:",
            "#",
            f"#     anchor_px = {fn_c}(",
            "#         kps['eye'], kps['ear'], kps['nose'], offsets)",
            f"#     annotated, regions = {fn_d}(",
            "#         base_bgr, anchor_px, side_label)",
            "#",
            "#   kps is the dict already returned by annotate_with_yolo(),",
            "#   which provides 'eye', 'ear', and 'nose' keys.",
            "#   offsets format unchanged: {name: (du, dv)} in fractions of L and D.",
            "#",
            "# ══════════════════════════════════════════════════════════════════════════════",
            "",
            "from collections import OrderedDict",
            "import numpy as np",
            "import cv2",
            "",
        ]

        # ANCHORS
        lines += [
            f"# ── {S} profile anchors  (u in units of L=eye-ear, v in units of D=eye-nose) ──",
            f"{VNAME}_ANCHORS = OrderedDict([",
        ]
        if not self.anchors:
            lines.append("    # (no anchors defined)")
        for name, a in self.anchors.items():
            lines.append(f"    ('{name}', {{'u': {a['u']:+.4f}, 'v': {a['v']:+.4f}}}),")
        lines.append("])")
        lines.append("")

        # REGION DEFS
        lines += [
            f"# ── {S} profile region definitions ────────────────────────────────────────────",
            f"{VNAME}_REGION_DEFS = OrderedDict([",
        ]
        for reg in self.regions:
            rgb = (reg['color'][2], reg['color'][1], reg['color'][0])
            lines += [
                f"    ('{reg['name']}', {{",
                "        'poly': [",
            ]
            for nm in reg['pts']:
                lines.append(f"            '{nm}',")
            lines += [
                "        ],",
                f"        'color': {rgb},  'alpha': 0.40,",
                "    }),",
            ]
        lines.append("])")
        lines.append("")

        # HELPER FUNCTIONS
        lines += [
            "# ── Helper functions ─────────────────────────────────────────────────────────",
            "",
            f"def {fn_bas}(eye, ear, nose):",
            f'    """Compute dual oblique basis for the {S} profile.',
            f'    Returns (A, B, det) where pixel = eye + u*A + v*B."""',
            f'    eye  = np.array([float(eye[0]),  float(eye[1])])',
            f'    ear  = np.array([float(ear[0]),  float(ear[1])])',
            f'    nose = np.array([float(nose[0]), float(nose[1])])',
            f'    A   = ear  - eye          # L * e_ear  (eye-ear  vector)',
            f'    B   = nose - eye          # D * e_nose (eye-nose vector)',
            f'    det = float(A[0]*B[1] - A[1]*B[0])',
            f'    return eye, A, B, det',
            f'',
            f'',
            f"def {fn_c}(eye, ear, nose, offsets=None):",
            f'    """',
            f'    Compute pixel positions for all {VNAME}_ANCHORS.',
            f'',
            f'    Parameters',
            f'    ----------',
            f'    eye, ear, nose : array-like [x, y]',
            f"        YOLO keypoint pixel positions from annotate_with_yolo()'s",
            f"        kps dict keys 'eye', 'ear', 'nose'.",
            f'    offsets : dict {{name: (du, dv)}}',
            f'        Fine-tune offsets. du is a fraction of L (eye-ear distance),',
            f'        dv is a fraction of D (eye-nose distance). Compatible with',
            f'        the existing ref_offsets / tgt_offsets dicts.',
            f'',
            f'    Returns',
            f'    -------',
            f'    dict {{anchor_name: np.ndarray([x, y], float)}}',
            f'    """',
            f'    origin, A, B, det = {fn_bas}(eye, ear, nose)',
            f'    offsets = offsets or {{}}',
            f'    result  = {{}}',
            f'    for name, a in {VNAME}_ANCHORS.items():',
            f'        du, dv = offsets.get(name, (0.0, 0.0))',
            f'        result[name] = origin + (a["u"] + du) * A \\',
            f'                              + (a["v"] + dv) * B',
            f'    return result',
            f'',
            f'',
            f"def {fn_b}(anchor_px):",
            f'    """Build int32 polygon arrays for all {VNAME}_REGION_DEFS.',
            f'    Returns dict {{region_name: np.int32 polygon array}}."""',
            f'    polys = {{}}',
            f'    for rname, defn in {VNAME}_REGION_DEFS.items():',
            f'        pts = []',
            f'        ok  = True',
            f'        for name in defn["poly"]:',
            f'            if name not in anchor_px:',
            f'                ok = False; break',
            f'            pts.append(anchor_px[name].astype(float))',
            f'        if ok and len(pts) >= 3:',
            f'            polys[rname] = np.array(pts, dtype=np.int32)',
            f'    return polys',
            f'',
            f'',
            f"def {fn_d}(base_bgr, anchor_px, side_label):",
            f'    """',
            f'    Draw {S} profile ROIs on *base_bgr*.',
            f'',
            f'    Parameters',
            f'    ----------',
            f'    base_bgr   : uint8 BGR image (YOLO-annotated display frame)',
            f'    anchor_px  : output of {fn_c}()',
            f'    side_label : str e.g. "L" or "R"  — prefixed on region labels',
            f'',
            f'    Returns',
            f'    -------',
            f'    (annotated_bgr, regions_dict)',
            f'    regions_dict maps region_name → np.int32 polygon,',
            f'    drop-in replacement for the dict returned by draw_regions_from_verts().',
            f'    Pass directly to get_polygon_values() for thermal extraction.',
            f'    """',
            f'    canvas  = base_bgr.copy()',
            f'    regions = {{}}',
            f'    for rname, poly in {fn_b}(anchor_px).items():',
            f'        defn    = {VNAME}_REGION_DEFS.get(rname, {{}})',
            f'        color   = defn.get("color", (128, 128, 128))',
            f'        alpha   = defn.get("alpha", 0.40)',
            f'        overlay = canvas.copy()',
            f'        cv2.fillPoly(overlay, [poly.reshape(-1, 1, 2)], color)',
            f'        cv2.addWeighted(overlay, alpha, canvas, 1 - alpha, 0, canvas)',
            f'        cv2.polylines(canvas, [poly.reshape(-1, 1, 2)],',
            f'                      True, color, 2, cv2.LINE_AA)',
            f'        ctr = poly.mean(axis=0).astype(int)',
            f'        lbl = f"{{side_label}}-{{rname}}"',
            f'        cv2.putText(canvas, lbl, tuple(ctr),',
            f'                    cv2.FONT_HERSHEY_SIMPLEX, 0.36, (0, 0, 0), 2, cv2.LINE_AA)',
            f'        cv2.putText(canvas, lbl, tuple(ctr),',
            f'                    cv2.FONT_HERSHEY_SIMPLEX, 0.36, color, 1, cv2.LINE_AA)',
            f'        regions[rname] = poly',
            f'    return canvas, regions',
        ]

        code = "\n".join(lines)
        sep  = "═" * 82
        print(f"\n{sep}\n{code}\n{sep}\n")

        out_file = f"{s}_profile_region_defs.py"
        with open(out_file, "w", encoding="utf-8") as fh:
            fh.write(code + "\n")
        _info("Exported",
              f"Code printed to terminal.\nSaved to:\n{os.path.abspath(out_file)}")

    def export_json(self):
        """Save / update the 'dual' section of mesh_defs.json  (press J)."""
        import json
        from pathlib import Path

        anchors_out = {
            name: {"u": a["u"], "v": a["v"]}
            for name, a in self.anchors.items()
        }
        regions_out = {}
        for reg in self.regions:
            bgr = reg["color"]
            regions_out[reg["name"]] = {
                "poly":  list(reg["pts"]),
                "color": [bgr[0], bgr[1], bgr[2]],
                "alpha": 0.40,
            }

        path = Path("mesh_defs.json")
        data = json.loads(path.read_text()) if path.exists() else {}
        data.setdefault("version", "1.0.0")
        data["dual"] = {"anchors": anchors_out, "regions": regions_out}
        path.write_text(json.dumps(data, indent=2))
        print(f"[mesh_editor] Saved dual mesh to {path.resolve()}")
        _info("JSON Exported",
              f"'dual' section written to:\n{path.resolve()}\n\n"
              f"Commit the file and push to update the hosted definitions.")


# ── FLIR image loading ─────────────────────────────────────────────────────────

def _thermal_to_display_bgr(thermal):
    t_min, t_max = np.nanmin(thermal), np.nanmax(thermal)
    norm = (((thermal - t_min) / (t_max - t_min) * 255).astype(np.uint8)
            if t_max > t_min else np.zeros_like(thermal, dtype=np.uint8))
    return cv2.applyColorMap(norm, cv2.COLORMAP_INFERNO)


def _find_exiftool():
    et = shutil.which("exiftool")
    if et: return et
    sp_roots = []
    try: sp_roots += site.getsitepackages()
    except Exception: pass
    try:
        u = site.getusersitepackages()
        if u and u not in sp_roots: sp_roots.append(u)
    except Exception: pass
    for pkg in ("dji_executables", "flirimageextractor"):
        try:
            import importlib
            d = os.path.dirname(importlib.import_module(pkg).__file__)
            for c in glob.glob(os.path.join(d, "**", "exiftool*"), recursive=True):
                if os.path.isfile(c) and not c.endswith((".txt", ".md")): return c
        except Exception: pass
    for sp in sp_roots:
        for c in glob.glob(os.path.join(sp, "**", "exiftool*"), recursive=True):
            if os.path.isfile(c) and not c.endswith((".txt", ".md")): return c
    return ""


_EXIFTOOL_EXE = None


def _extract_rgb_via_exiftool(path):
    global _EXIFTOOL_EXE
    if _EXIFTOOL_EXE is None:
        _EXIFTOOL_EXE = _find_exiftool()
        print(f"  [exiftool] {'found: ' + _EXIFTOOL_EXE if _EXIFTOOL_EXE else 'not found'}")
    if not _EXIFTOOL_EXE: return None
    from PIL import Image as _PIL
    for tag in ("EmbeddedImage", "ThumbnailImage", "PreviewImage", "JpgFromRaw"):
        try:
            r = subprocess.run([_EXIFTOOL_EXE, "-b", f"-{tag}", path],
                               capture_output=True, timeout=20)
            if r.returncode == 0 and len(r.stdout) > 500 and r.stdout[:2] == b"\xff\xd8":
                return np.array(_PIL.open(io.BytesIO(r.stdout)).convert("RGB"))
        except Exception: pass
    return None


def load_image(path):
    from PIL import Image as _PIL
    result = {"bgr": None, "rgb": None, "thermal": None,
              "thermal_bgr": None, "is_flir": False, "source": ""}
    flir_obj = thermal = None
    try:
        from flirimageextractor import FlirImageExtractor
        flir_obj = FlirImageExtractor(); flir_obj.process_image(path)
        thermal  = np.array(flir_obj.get_thermal_np(), dtype=np.float32)
        result.update(is_flir=True, thermal=thermal,
                      thermal_bgr=_thermal_to_display_bgr(thermal))
    except ImportError: print("  [FLIR] flirimageextractor not installed.")
    except Exception as exc: print(f"  [FLIR] {exc}")

    rgb = None
    if result["is_flir"] and flir_obj is not None:
        try:
            r = flir_obj.get_rgb_np()
            if r is not None and r.size > 0:
                if r.ndim == 2: r = np.stack([r]*3, axis=-1)
                if r.shape[2] == 4: r = r[:,:,:3]
                rgb = r.astype(np.uint8); result["source"] = "FLIR (get_rgb_np)"
        except Exception: pass
        if rgb is None:
            rgb = _extract_rgb_via_exiftool(path)
            if rgb is not None: result["source"] = "FLIR (exiftool tag)"
        if rgb is None:
            try: rgb = np.array(_PIL.open(path).convert("RGB")); result["source"] = "FLIR (JPEG)"
            except Exception: pass
        if rgb is None and thermal is not None:
            rgb = cv2.cvtColor(_thermal_to_display_bgr(thermal), cv2.COLOR_BGR2RGB)
            result["source"] = "FLIR (thermal false-colour)"
    if rgb is None:
        try: rgb = np.array(_PIL.open(path).convert("RGB")); result["source"] = "plain image"
        except Exception as exc: print(f"ERROR: {exc}"); sys.exit(1)
    result["rgb"] = rgb
    result["bgr"] = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    return result


# ── main ───────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("image", help="Profile photo (JPG / PNG / BMP / FLIR JPEG)")
    ap.add_argument("--side", choices=["left", "right"], default="left",
                    help="Profile side  (default: left).  Run twice for both sides.")
    ap.add_argument("--model", default="yolov8n-pose.pt",
                    help="YOLOv8 pose weights  (default: yolov8n-pose.pt).")
    ap.add_argument("--manual", action="store_true",
                    help="Skip YOLO — click eye, ear, nose manually.")
    args = ap.parse_args()

    side = args.side; S = side.upper()
    print(f"\nLoading: {args.image}")
    img_data = load_image(args.image)
    bgr = img_data["bgr"]
    print(f"  Source : {img_data['source']}")
    print(f"  Size   : {bgr.shape[1]} × {bgr.shape[0]} px\n")

    eye = ear = nose = kps = None
    conf_eye = conf_ear = conf_nose = None

    if not args.manual:
        print(f"Running YOLOv8  [{args.model}]  →  {S} eye + ear + nose …")
        result = run_yolo_profile(bgr, side, args.model)
        if result is not None:
            eye, ear, nose, kps, conf_eye, conf_ear, conf_nose = result
            L = float(np.hypot(*(ear  - eye)))
            D = float(np.hypot(*(nose - eye)))
            angle = float(np.degrees(np.arccos(np.clip(
                np.dot((ear - eye)/L, (nose - eye)/D), -1, 1))))
            print(f"  ✓  {S} Eye  ({eye[0]:.1f}, {eye[1]:.1f})  conf={conf_eye:.2f}")
            print(f"  ✓  {S} Ear  ({ear[0]:.1f}, {ear[1]:.1f})  conf={conf_ear:.2f}")
            print(f"  ✓  Nose ({nose[0]:.1f}, {nose[1]:.1f})  conf={conf_nose:.2f}")
            print(f"  ✓  L={L:.1f}px   D={D:.1f}px   axis-angle={angle:.1f}°")
        else:
            print("[YOLO] No reliable detection — switching to manual placement.")

    if eye is None or ear is None or nose is None:
        print(f"\nManual placement ({S} profile):  click  1.EYE  2.EAR  3.NOSE")
        eye, ear, nose = click_landmarks_manually(bgr, side)
        L = float(np.hypot(*(ear - eye))); D = float(np.hypot(*(nose - eye)))
        print(f"  ✓  {S} Eye ({eye[0]:.1f},{eye[1]:.1f})  "
              f"{S} Ear ({ear[0]:.1f},{ear[1]:.1f})  "
              f"Nose ({nose[0]:.1f},{nose[1]:.1f})")
        print(f"  ✓  L={L:.1f}px   D={D:.1f}px")

    print(f"\nOpening editor …  Y=set-eye  R=set-ear  O=set-nose  G=grid  E=export")

    ed = Editor(bgr, eye, ear, nose, side,
                kps, conf_eye, conf_ear, conf_nose,
                thermal_bgr=img_data.get("thermal_bgr"))

    while True:
        k = cv2.waitKey(30) & 0xFF
        if k != 255:
            if ed.key(k) == "quit": break
        try:
            if cv2.getWindowProperty(ed.WIN, cv2.WND_PROP_VISIBLE) < 1: break
        except Exception: break

    cv2.destroyAllWindows()
    print("Editor closed.")


if __name__ == "__main__":
    main()
