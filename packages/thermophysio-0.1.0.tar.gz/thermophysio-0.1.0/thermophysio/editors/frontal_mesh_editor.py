#!/usr/bin/env python3
"""
mesh_editor.py  —  Interactive Face Mesh Region Editor
Standalone tool — works with any regular portrait JPEG, completely independent
of FLIR cameras. Use any frontal face photo (phone photo, Google image, etc.)

Run:
    python mesh_editor.py <any_face_photo.jpg>

OUTPUT  (press E):
    Prints Python code blocks ready to paste into Frontal_FLIR_Extractor.py
    Also saves region_defs.py in the current folder.

CONTROLS
─────────────────────────────────────────────────────
 POLYGON MODE  (default)
   Left-click near numbered dot   →  add MP landmark to polygon
   Left-click near square anchor  →  add free anchor to polygon
   Enter                          →  finish polygon → name dialog
   Backspace                      →  remove last point
   Escape                         →  cancel current polygon
   Delete                         →  delete last completed polygon

 ANCHOR MODE  (press A)
   Left-click anywhere            →  place free anchor → name + adjustable?
   Left-click + drag anchor       →  reposition anchor
   Right-click anchor             →  toggle adjustable flag
   Double-click anchor            →  rename

 VIEW
   N          toggle landmark number labels
   F          toggle polygon fill
   Scroll     zoom
   Middle-drag or hold Space + drag  → pan
   R          reset view
   E          export code
   Q / Esc    quit
─────────────────────────────────────────────────────
"""

import sys, os, io, tempfile, math, colorsys
import numpy as np
import cv2
from PIL import Image

try:
    import tkinter as tk
    from tkinter import simpledialog, messagebox
    _TK = True
except Exception:
    _TK = False

# ── tiny TK dialogs ────────────────────────────────────────────────────────────
def ask(title, prompt, default=""):
    if _TK:
        root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True)
        v = simpledialog.askstring(title, prompt, initialvalue=default, parent=root)
        root.destroy(); return v
    return input(f"{prompt} [{default}]: ").strip() or default

def info(title, msg):
    if _TK:
        root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True)
        messagebox.showinfo(title, msg, parent=root); root.destroy()
    else:
        print(f"[{title}] {msg}")

def palette(idx):
    h = (idx * 0.137) % 1.0
    r,g,b = colorsys.hsv_to_rgb(h, 0.85, 0.95)
    return (int(b*255), int(g*255), int(r*255))

# ── MediaPipe ──────────────────────────────────────────────────────────────────
def run_mp(rgb):
    import mediapipe as mp
    from mediapipe.tasks import python as mpp
    from mediapipe.tasks.python import vision as mpv
    model = os.path.join(tempfile.gettempdir(), "face_landmarker.task")
    if not os.path.exists(model):
        print("Downloading face_landmarker.task (~6 MB)…")
        import urllib.request
        urllib.request.urlretrieve(
            "https://storage.googleapis.com/mediapipe-models/"
            "face_landmarker/face_landmarker/float16/1/face_landmarker.task", model)
    opts = mpv.FaceLandmarkerOptions(
        base_options=mpp.BaseOptions(model_asset_path=model),
        num_faces=1, min_face_detection_confidence=0.3, min_face_presence_confidence=0.3)
    fl  = mpv.FaceLandmarker.create_from_options(opts)
    res = fl.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb))
    if not res.face_landmarks: return None
    h,w = rgb.shape[:2]
    return {i: np.array([p.x*w, p.y*h]) for i,p in enumerate(res.face_landmarks[0])}

# ── Editor ─────────────────────────────────────────────────────────────────────
class Editor:
    WIN    = "Mesh Editor  |  A=anchor  N=numbers  F=fill  E=export  Q=quit"
    CTRL_H = 58
    FONT   = cv2.FONT_HERSHEY_SIMPLEX

    def __init__(self, bgr, lm):
        self.bgr   = bgr
        self.lm    = lm          # {idx: np.array([x,y])}
        self.zoom  = 1.0
        self.pan   = np.array([0.0, 0.0])
        self._panning = False; self._pan_last = None
        self._space_held = False

        self.show_nums   = True
        self.show_fill   = True
        self.anchor_mode = False

        self.regions  = []   # [{'name', 'pts', 'color'}]
        self.anchors  = {}   # {name: {'pos','ref_mp','dx0','dy0','adj'}}
        self.cur_pts  = []   # [('mp',i) | ('free',name)]

        self._drag_anchor = None

        ih,iw = bgr.shape[:2]
        # basis for offset calc
        self.D_eye = self.H_nose = None
        if 33 in lm and 263 in lm and 4 in lm:
            self.D_eye  = float(np.hypot(*(lm[263]-lm[33])))
            self.H_nose = float(np.hypot(*(lm[4]-(lm[33]+lm[263])/2)))

        # initial zoom: fit image to ~900px height
        self.zoom = min(900/ih, 1400/iw)
        self.pan  = np.array([(1400 - iw*self.zoom)/2, 0.0])

        cv2.namedWindow(self.WIN, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(self.WIN, 1400, 900 + self.CTRL_H)
        cv2.setMouseCallback(self.WIN, self._mouse)
        self.render()

    # ── transforms ────────────────────────────────────────────────────────────
    def i2c(self, ix, iy):
        return (int(ix*self.zoom + self.pan[0]),
                int(iy*self.zoom + self.pan[1]) + self.CTRL_H)

    def c2i(self, cx, cy):
        return ((cx - self.pan[0]) / self.zoom,
                (cy - self.CTRL_H - self.pan[1]) / self.zoom)

    def _nearest_lm(self, cx, cy, thr=18):
        best, bd = None, thr**2
        for idx, p in self.lm.items():
            pcx, pcy = self.i2c(p[0], p[1])
            d = (cx-pcx)**2 + (cy-pcy)**2
            if d < bd: bd=d; best=idx
        return best

    def _nearest_anc(self, cx, cy, thr=18):
        best, bd = None, thr**2
        for n,a in self.anchors.items():
            pcx, pcy = self.i2c(a['pos'][0], a['pos'][1])
            d = (cx-pcx)**2 + (cy-pcy)**2
            if d < bd: bd=d; best=n
        return best

    # ── render ────────────────────────────────────────────────────────────────
    def render(self):
        ih,iw = self.bgr.shape[:2]
        cw = 1400; ch = 900 + self.CTRL_H
        canvas = np.full((ch, cw, 3), (28,28,28), np.uint8)

        # paste image (darkened)
        sw,sh = int(iw*self.zoom), int(ih*self.zoom)
        img_s = cv2.resize(self.bgr, (sw,sh), interpolation=cv2.INTER_LINEAR)
        img_s = (img_s*0.60).astype(np.uint8)
        ox,oy = int(self.pan[0]), int(self.pan[1]) + self.CTRL_H
        x0=max(0,ox); y0=max(0,oy); x1=min(cw,ox+sw); y1=min(ch,oy+sh)
        if x1>x0 and y1>y0:
            canvas[y0:y1,x0:x1] = img_s[y0-oy:y1-oy, x0-ox:x1-ox]

        # completed region fills
        if self.show_fill:
            for reg in self.regions:
                poly = self._reg_poly(reg['pts'])
                if poly is not None and len(poly)>=3:
                    ov = canvas.copy()
                    cv2.fillPoly(ov, [poly], reg['color'])
                    cv2.addWeighted(ov, 0.35, canvas, 0.65, 0, canvas)

        # completed region outlines
        for reg in self.regions:
            poly = self._reg_poly(reg['pts'])
            if poly is None or len(poly)<2: continue
            cv2.polylines(canvas,[poly],True,reg['color'],2,cv2.LINE_AA)
            ctr = poly.mean(0).astype(int)
            self._label(canvas, reg['name'], ctr[0], ctr[1], reg['color'])

        # current polygon in progress
        if self.cur_pts:
            pts = self._reg_poly(self.cur_pts)
            if pts is not None:
                for i,pt in enumerate(pts):
                    cv2.circle(canvas, tuple(pt), 8, (0,240,240), -1, cv2.LINE_AA)
                    cv2.circle(canvas, tuple(pt), 8, (255,255,255), 1, cv2.LINE_AA)
                    if i>0: cv2.line(canvas, tuple(pts[i-1]), tuple(pt), (0,240,240), 2, cv2.LINE_AA)
                if len(pts)>1: cv2.line(canvas, tuple(pts[-1]), tuple(pts[0]), (0,240,240), 1, cv2.LINE_AA)

        # landmarks
        r = max(2, int(4*min(self.zoom,2)))
        for idx, p in self.lm.items():
            cx,cy = self.i2c(p[0],p[1])
            if not (0<=cx<cw and self.CTRL_H<=cy<ch): continue
            used = ('mp',idx) in self.cur_pts
            col  = (0,240,200) if used else (0,180,70)
            cv2.circle(canvas,(cx,cy),r,col,-1,cv2.LINE_AA)
            if self.show_nums:
                fs = max(0.20, 0.36*min(self.zoom,2))
                lbl = str(idx)
                cv2.putText(canvas,lbl,(cx+r+2,cy+3),self.FONT,fs,(0,0,0),2,cv2.LINE_AA)
                cv2.putText(canvas,lbl,(cx+r+2,cy+3),self.FONT,fs,(240,210,50),1,cv2.LINE_AA)

        # anchors
        for name, a in self.anchors.items():
            cx,cy = self.i2c(a['pos'][0],a['pos'][1])
            if not (0<=cx<cw and self.CTRL_H<=cy<ch): continue
            col = (0,220,60) if a['adj'] else (60,140,255)
            if ('free',name) in self.cur_pts: col=(0,240,240)
            r2 = max(5,int(8*min(self.zoom,2)))
            cv2.rectangle(canvas,(cx-r2,cy-r2),(cx+r2,cy+r2),col,-1)
            cv2.rectangle(canvas,(cx-r2,cy-r2),(cx+r2,cy+r2),(255,255,255),1)
            lbl = f"{name}{'✦' if a['adj'] else ''}"
            cv2.putText(canvas,lbl,(cx+r2+3,cy+4),self.FONT,max(0.22,0.34*min(self.zoom,2)),(0,0,0),2,cv2.LINE_AA)
            cv2.putText(canvas,lbl,(cx+r2+3,cy+4),self.FONT,max(0.22,0.34*min(self.zoom,2)),col,1,cv2.LINE_AA)

        # control bar
        cv2.rectangle(canvas,(0,0),(cw,self.CTRL_H),(18,18,18),-1)
        cv2.line(canvas,(0,self.CTRL_H),(cw,self.CTRL_H),(60,60,60),1)
        mode = "[ ANCHOR MODE ]" if self.anchor_mode else "[ POLYGON MODE ]"
        mcol = (60,220,255) if self.anchor_mode else (80,255,100)
        cur  = f"  •  building polygon: {len(self.cur_pts)} pts" if self.cur_pts else ""
        stat = f"  regions: {len(self.regions)}   anchors: {len(self.anchors)}"
        cv2.putText(canvas, mode+cur+stat, (10,22), self.FONT, 0.52, mcol, 1, cv2.LINE_AA)
        cv2.putText(canvas,
            "A=anchor  N=nums  F=fill  Enter=finish polygon  Backspace=undo pt  "
            "Del=undo region  E=export  R=reset view  Q=quit",
            (10,44), self.FONT, 0.36, (110,110,110), 1, cv2.LINE_AA)

        cv2.imshow(self.WIN, canvas)

    def _reg_poly(self, pts):
        out=[]
        for spec in pts:
            if spec[0]=='mp':
                if spec[1] not in self.lm: return None
                p=self.lm[spec[1]]; out.append(self.i2c(p[0],p[1]))
            else:
                if spec[1] not in self.anchors: return None
                p=self.anchors[spec[1]]['pos']; out.append(self.i2c(p[0],p[1]))
        return np.array(out,dtype=np.int32) if out else None

    def _label(self, canvas, txt, cx, cy, col):
        cv2.putText(canvas,txt,(cx+1,cy+1),self.FONT,0.52,(0,0,0),2,cv2.LINE_AA)
        cv2.putText(canvas,txt,(cx,cy),self.FONT,0.52,col,1,cv2.LINE_AA)

    # ── mouse ──────────────────────────────────────────────────────────────────
    def _mouse(self, event, cx, cy, flags, param):
        # scroll zoom
        if event == cv2.EVENT_MOUSEWHEEL:
            f = 1.12 if flags>0 else 1/1.12
            ix,iy = self.c2i(cx,cy)
            self.zoom = max(0.1, min(10.0, self.zoom*f))
            ncx,ncy = self.i2c(ix,iy)
            self.pan[0] += cx-ncx; self.pan[1] += (cy-self.CTRL_H)-(ncy-self.CTRL_H)
            self.render(); return

        # middle-button pan
        if event == cv2.EVENT_MBUTTONDOWN:
            self._panning=True; self._pan_last=(cx,cy); return
        if event == cv2.EVENT_MBUTTONUP:
            self._panning=False; return
        if event == cv2.EVENT_MOUSEMOVE:
            if self._panning and self._pan_last:
                self.pan[0]+=cx-self._pan_last[0]; self.pan[1]+=cy-self._pan_last[1]
                self._pan_last=(cx,cy); self.render()
            if self._drag_anchor:
                ix,iy=self.c2i(cx,cy)
                self.anchors[self._drag_anchor]['pos']=np.array([ix,iy])
                self._calc_offset(self._drag_anchor)
                self.render()
            return
        if event==cv2.EVENT_LBUTTONUP and self._drag_anchor:
            self._drag_anchor=None; return

        if cy < self.CTRL_H: return

        if event == cv2.EVENT_LBUTTONDOWN:
            if self.anchor_mode:
                an = self._nearest_anc(cx,cy)
                if an: self._drag_anchor=an; return
                ix,iy=self.c2i(cx,cy)
                name=ask("New Anchor","Anchor name (e.g. LEAR_TOP):",f"ANC_{len(self.anchors)}")
                if not name: return
                name=name.strip().upper().replace(" ","_")
                if name in self.anchors: info("Duplicate",f"'{name}' already exists"); return
                ref=min(self.lm, key=lambda i: np.hypot(*(self.lm[i]-np.array([ix,iy]))))
                adj_s=ask("Adjustable?","Adjustable in main script? (y/n):","y")
                adj=(adj_s or "y").strip().lower().startswith("y")
                self.anchors[name]={'pos':np.array([ix,iy]),'ref_mp':ref,'dx0':0.0,'dy0':0.0,'adj':adj}
                self._calc_offset(name); self.render()
            else:
                an=self._nearest_anc(cx,cy)
                if an:
                    if ('free',an) not in self.cur_pts:
                        self.cur_pts.append(('free',an)); self.render()
                    return
                lm_i=self._nearest_lm(cx,cy)
                if lm_i is not None and ('mp',lm_i) not in self.cur_pts:
                    self.cur_pts.append(('mp',lm_i)); self.render()

        if event==cv2.EVENT_RBUTTONDOWN:
            an=self._nearest_anc(cx,cy)
            if an: self.anchors[an]['adj']=not self.anchors[an]['adj']; self.render()

        if event==cv2.EVENT_LBUTTONDBLCLK:
            an=self._nearest_anc(cx,cy)
            if an:
                nn=ask("Rename","New name:",an)
                if nn and nn!=an:
                    nn=nn.strip().upper().replace(" ","_")
                    self.anchors[nn]=self.anchors.pop(an)
                    for reg in self.regions:
                        reg['pts']=[('free',nn) if p==('free',an) else p for p in reg['pts']]
                    self.cur_pts=[('free',nn) if p==('free',an) else p for p in self.cur_pts]
                self.render()

    def _calc_offset(self, name):
        a=self.anchors[name]; ref=self.lm.get(a['ref_mp'])
        if ref is None or self.D_eye is None: return
        d=a['pos']-ref
        a['dx0']=round(float(d[0])/self.D_eye, 3)
        a['dy0']=round(float(d[1])/self.H_nose,3)

    # ── keyboard ──────────────────────────────────────────────────────────────
    def key(self, k):
        if k in (13,10):   # Enter — finish polygon
            if len(self.cur_pts)>=3:
                name=ask("Region name","e.g.  L-Cheek",f"Region_{len(self.regions)+1}")
                if name:
                    self.regions.append({'name':name.strip(),'pts':list(self.cur_pts),'color':palette(len(self.regions))})
                    self.cur_pts=[]
            else:
                info("Too few","Need at least 3 points.")
        elif k==8:          # Backspace
            if self.cur_pts: self.cur_pts.pop()
        elif k==27:         # Esc
            if self.cur_pts: self.cur_pts=[]
            else: return "quit"
        elif k in (ord('q'),ord('Q')): return "quit"
        elif k==255 or k==3014656:   # Delete (cv2 reports 3014656 on some OS)
            if self.regions: self.regions.pop()
        elif k in (ord('a'),ord('A')): self.anchor_mode=not self.anchor_mode
        elif k in (ord('n'),ord('N')): self.show_nums=not self.show_nums
        elif k in (ord('f'),ord('F')): self.show_fill=not self.show_fill
        elif k in (ord('e'),ord('E')): self.export()
        elif k in (ord('j'),ord('J')): self.export_json()
        elif k in (ord('r'),ord('R')):
            ih,iw=self.bgr.shape[:2]
            self.zoom=min(900/ih,1400/iw)
            self.pan=np.array([(1400-iw*self.zoom)/2,0.0])
        elif k in (ord('+'),ord('=')): self.zoom=min(10,self.zoom*1.2)
        elif k==ord('-'): self.zoom=max(0.1,self.zoom/1.2)
        self.render()

    # ── export ────────────────────────────────────────────────────────────────
    def export(self):
        lines=["# ════════════════════════════════════════════════════════════════",
               "# Paste these two blocks into Frontal_FLIR_Extractor.py",
               "# replacing the existing FREE_ANCHORS and REGION_DEFS blocks",
               "# ════════════════════════════════════════════════════════════════",
               ""]

        # FREE_ANCHORS — only adjustable ones go in the active block
        lines.append("FREE_ANCHORS = OrderedDict([")
        adj_anchors = {n:a for n,a in self.anchors.items() if a['adj']}
        if not adj_anchors:
            lines.append("    # (no adjustable anchors defined yet)")
        for name,a in adj_anchors.items():
            lines.append(f"    ('{name}', {{'ref_mp': {a['ref_mp']:3d},  "
                         f"'dx0': {a['dx0']:+.3f}, 'dy0': {a['dy0']:+.3f}}}),  "
                         f"# ref landmark shown in image")
        lines.append("])")
        lines.append("")

        # REGION_DEFS
        lines.append("REGION_DEFS = OrderedDict([")
        for reg in self.regions:
            rgb=(reg['color'][2],reg['color'][1],reg['color'][0])
            lines.append(f"    ('{reg['name']}', {{")
            lines.append( "        'poly': [")
            for spec in reg['pts']:
                if spec[0]=='mp':
                    lines.append(f"            ('mp',    {spec[1]:3d}),")
                else:
                    lines.append(f"            ('free', '{spec[1]}'),")
            lines.append( "        ],")
            lines.append(f"        'color': {rgb},  'alpha': 0.40,")
            lines.append( "    }),")
        lines.append("])")
        lines.append("")

        # All anchors as comment (including non-adjustable vertex-only ones)
        if any(not a['adj'] for a in self.anchors.values()):
            lines.append("# ── Non-adjustable anchors (vertex-only, fixed position) ─────────")
            lines.append("# Add these to FREE_ANCHORS too if you want them draggable:")
            for name,a in self.anchors.items():
                if not a['adj']:
                    lines.append(f"#   ('{name}', {{'ref_mp': {a['ref_mp']},  "
                                 f"'dx0': {a['dx0']:+.3f}, 'dy0': {a['dy0']:+.3f},  "
                                 f"'adj': False}}),")
            lines.append("")

        code="\n".join(lines)
        sep="═"*68
        print(f"\n{sep}\n{code}\n{sep}\n")
        out="region_defs.py"
        with open(out,"w") as f: f.write(code+"\n")
        info("Exported", f"Code printed to terminal.\nAlso saved to:\n{os.path.abspath(out)}")

    def export_json(self):
        """Save / update the 'frontal' section of mesh_defs.json  (press J)."""
        import json
        from pathlib import Path

        anchors_out = {
            name: {"ref_mp": a["ref_mp"], "dx0": a["dx0"], "dy0": a["dy0"]}
            for name, a in self.anchors.items()
        }
        regions_out = {}
        for reg in self.regions:
            bgr = reg["color"]                          # stored as BGR
            regions_out[reg["name"]] = {
                "poly":  [list(pt) for pt in reg["pts"]],   # tuples → lists for JSON
                "color": [bgr[0], bgr[1], bgr[2]],
                "alpha": 0.40,
            }

        path = Path("mesh_defs.json")
        data = json.loads(path.read_text()) if path.exists() else {}
        data.setdefault("version", "1.0.0")
        data["frontal"] = {"anchors": anchors_out, "regions": regions_out}
        path.write_text(json.dumps(data, indent=2))
        print(f"[mesh_editor] Saved frontal mesh to {path.resolve()}")
        info("JSON Exported",
             f"'frontal' section written to:\n{path.resolve()}\n\n"
             f"Commit the file and push to update the hosted definitions.")

# ── main ───────────────────────────────────────────────────────────────────────
def main():
    if len(sys.argv)<2:
        print(__doc__)
        print("Usage: python mesh_editor.py <face_photo.jpg>")
        print("  Use any regular portrait JPEG — phone photo, downloaded image, etc.")
        sys.exit(1)

    path=sys.argv[1]
    rgb=np.array(Image.open(path).convert("RGB"))
    print(f"Image: {rgb.shape}")

    print("Running MediaPipe…")
    lm=run_mp(rgb)
    if lm is None:
        print("No face detected. Try a clearer frontal face photo."); sys.exit(1)
    print(f"{len(lm)} landmarks detected.")

    bgr=cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR)
    ed=Editor(bgr,lm)

    while True:
        k=cv2.waitKey(30)&0xFF
        if k!=255:
            if ed.key(k)=="quit": break
        try:
            if cv2.getWindowProperty(ed.WIN,cv2.WND_PROP_VISIBLE)<1: break
        except: break

    cv2.destroyAllWindows()

if __name__=="__main__":
    main()
