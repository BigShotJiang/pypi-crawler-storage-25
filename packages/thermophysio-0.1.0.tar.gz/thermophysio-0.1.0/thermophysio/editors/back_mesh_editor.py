#!/usr/bin/env python3
"""
back_mesh_editor.py  —  Interactive Back-of-Head ROI Editor
Uses YOLOv8 pose to detect ears; the ear–ear line is the reference / basis unit.

Run:
    python back_mesh_editor.py <back_of_head_photo.jpg>
    python back_mesh_editor.py <flir_image.jpg>           # FLIR auto-detected → embedded RGB shown
    python back_mesh_editor.py <photo.jpg> --model yolov8m-pose.pt   # higher accuracy
    python back_mesh_editor.py <photo.jpg> --manual                   # skip YOLO, click ears

FLIR SUPPORT
    FLIR JPEG files are auto-detected.  The tool tries to extract the embedded
    high-resolution RGB image using flyr (bundle.optical), falling back to
    the outer JPEG.  Press T at any time to toggle between the
    RGB and a false-colour thermal preview.

OUTPUT  (press E):
    Prints Python code ready to paste into Back_FLIR_Extractor.py
    Also saves  back_region_defs.py  in the current folder.

COORDINATE SYSTEM (u, v)  — both normalised by D_ear (inter-ear pixel distance)
    u  along the ear–ear axis:
         u = -0.5  →  left ear tip
         u =  0.0  →  midpoint between ears
         u = +0.5  →  right ear tip
    v  perpendicular to ear axis:
         v > 0  →  toward crown  (upward in image)
         v < 0  →  toward neck   (downward in image)

All anchor positions are stored as (u, v) pairs.  They reconstruct to pixel
coordinates given only the two ear positions, so the same ROI definition works
on any image regardless of head size or slight tilt.

CONTROLS
────────────────────────────────────────────────────────────────────────────────
 POLYGON MODE  (default)
   Left-click near existing anchor  →  add it to the current polygon
   Left-click on empty area         →  auto-place new anchor → name dialog
                                        → immediately added to current polygon
   Enter                            →  finish polygon → name dialog (≥3 pts)
   Backspace                        →  remove last polygon point
   Escape                           →  cancel current polygon (or quit if empty)
   Delete                           →  delete last completed polygon

 ANCHOR MODE  (press A)
   Left-click anywhere              →  place new anchor → name dialog
   Left-click + drag anchor         →  reposition anchor (UV updated live)
   Double-click anchor              →  rename anchor
   Right-click anchor               →  delete anchor

 EAR REPOSITIONING
   L   →  next left-click sets the LEFT  ear position (updates entire basis)
   K   →  next left-click sets the RIGHT ear position (updates entire basis)
   (Esc while in ear-set mode cancels)

 VIEW
   F          toggle polygon fill
   G          toggle UV dot-grid overlay
   N          toggle anchor name / coordinate labels
   T          toggle RGB ↔ thermal view  (FLIR images only)
   Scroll     zoom in / out
   Middle-drag  or  Space + drag  →  pan
   V          reset view to fit image
   +  /  -    zoom ±20 %
   E          export code
   Q          quit
────────────────────────────────────────────────────────────────────────────────
"""

import sys
import os
import io
import math
import colorsys
import argparse
import subprocess
import shutil
import glob
import site

import numpy as np
import cv2

try:
    import tkinter as tk
    from tkinter import simpledialog, messagebox
    _TK = True
except Exception:
    _TK = False

# ── tiny TK helpers ────────────────────────────────────────────────────────────

def _ask(title: str, prompt: str, default: str = "") -> str | None:
    if _TK:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        v = simpledialog.askstring(title, prompt, initialvalue=default, parent=root)
        root.destroy()
        return v
    raw = input(f"{prompt} [{default}]: ").strip()
    return raw if raw else default


def _info(title: str, msg: str) -> None:
    if _TK:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        messagebox.showinfo(title, msg, parent=root)
        root.destroy()
    else:
        print(f"[{title}] {msg}")


def _palette(idx: int) -> tuple:
    h = (idx * 0.137) % 1.0
    r, g, b = colorsys.hsv_to_rgb(h, 0.85, 0.95)
    return (int(b * 255), int(g * 255), int(r * 255))   # BGR


# ── YOLOv8 pose detection ─────────────────────────────────────────────────────
#  COCO 17-keypoint indices
_COCO_NOSE        = 0
_COCO_LEFT_EAR    = 3
_COCO_RIGHT_EAR   = 4
_COCO_LEFT_SHLDR  = 5
_COCO_RIGHT_SHLDR = 6

# Skeleton edges — used to draw a faint body-pose reference
_SKELETON = [
    (0, 1), (0, 2), (1, 3), (2, 4),              # head/ears
    (5, 6),                                        # shoulders
    (5, 7), (7, 9), (6, 8), (8, 10),              # arms
    (5, 11), (6, 12), (11, 12),                   # torso
    (11, 13), (13, 15), (12, 14), (14, 16),       # legs
]


def run_yolo(bgr: np.ndarray, model_path: str = "yolov8n-pose.pt"):
    """
    Run YOLOv8 pose on *bgr* image.

    Returns
    -------
    (l_ear_px, r_ear_px, keypoints_17x3, conf_l, conf_r)  or  None on failure.
    keypoints_17x3 : ndarray (17, 3)  →  [x, y, confidence] per COCO keypoint
    """
    try:
        from ultralytics import YOLO
    except ImportError:
        print("ERROR: ultralytics not installed — run:  pip install ultralytics")
        return None

    model   = YOLO(model_path)
    results = model(bgr, verbose=False)

    if not results or results[0].keypoints is None:
        return None

    kps_tensor = results[0].keypoints.data         # shape: (n_persons, 17, 3)
    boxes      = results[0].boxes

    if kps_tensor is None or len(kps_tensor) == 0:
        return None

    # Pick detection with highest box confidence
    if boxes is not None and len(boxes.conf) > 0:
        best = int(np.argmax(boxes.conf.cpu().numpy()))
    else:
        best = 0

    kps    = kps_tensor[best].cpu().numpy()        # (17, 3)
    l_kp   = kps[_COCO_LEFT_EAR]
    r_kp   = kps[_COCO_RIGHT_EAR]
    conf_l = float(l_kp[2])
    conf_r = float(r_kp[2])

    if conf_l < 0.10 and conf_r < 0.10:
        print(f"[YOLO] Ear keypoints too uncertain  "
              f"(L={conf_l:.2f}  R={conf_r:.2f}).")
        return None

    return (
        np.array([float(l_kp[0]), float(l_kp[1])]),
        np.array([float(r_kp[0]), float(r_kp[1])]),
        kps,
        conf_l,
        conf_r,
    )


def click_ears_manually(bgr: np.ndarray):
    """
    Show the image and ask the user to click LEFT ear then RIGHT ear.
    Returns (l_ear_px, r_ear_px) as np.array([x, y], float).
    """
    WIN    = "_ear_placement_"
    clicks = []

    def _cb(event, cx, cy, _flags, _param):
        if event == cv2.EVENT_LBUTTONDOWN:
            clicks.append(np.array([float(cx), float(cy)]))

    cv2.namedWindow(WIN, cv2.WINDOW_NORMAL)
    ih, iw = bgr.shape[:2]
    cv2.resizeWindow(WIN, min(iw, 1200), min(ih, 900))
    cv2.setMouseCallback(WIN, _cb)

    ear_colors = [(60, 100, 255), (0, 220, 80)]    # BGR: blue=L, green=R
    labels_all = ["Click LEFT EAR", "Click RIGHT EAR", "Press any key to continue"]

    while True:
        step  = len(clicks)
        disp  = bgr.copy()
        label = labels_all[min(step, 2)]

        # Draw placed clicks
        for i, c in enumerate(clicks):
            cv2.circle(disp, (int(c[0]), int(c[1])), 12, ear_colors[i], 2, cv2.LINE_AA)
            cv2.circle(disp, (int(c[0]), int(c[1])),  4, ear_colors[i], -1, cv2.LINE_AA)
            tag = "L-EAR" if i == 0 else "R-EAR"
            cv2.putText(disp, tag, (int(c[0]) + 14, int(c[1]) + 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 3)
            cv2.putText(disp, tag, (int(c[0]) + 14, int(c[1]) + 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, ear_colors[i], 1)

        # Instruction banner
        cv2.putText(disp, label, (20, 44), cv2.FONT_HERSHEY_SIMPLEX, 1.2,
                    (0, 0, 0), 6, cv2.LINE_AA)
        cv2.putText(disp, label, (20, 44), cv2.FONT_HERSHEY_SIMPLEX, 1.2,
                    (0, 220, 255), 2, cv2.LINE_AA)

        cv2.imshow(WIN, disp)
        k = cv2.waitKey(20)

        if step >= 2 and k != -1:
            break
        if k == 27:     # Esc → abort
            cv2.destroyWindow(WIN)
            print("Ear placement cancelled.")
            sys.exit(1)

    cv2.destroyWindow(WIN)

    if len(clicks) < 2:
        print("Ear placement incomplete — need exactly 2 clicks.")
        sys.exit(1)

    return clicks[0], clicks[1]


# ── Editor ─────────────────────────────────────────────────────────────────────

class Editor:
    WIN    = ("Back-Head Mesh Editor  |  "
              "A=anchor  F=fill  G=grid  N=names  L/K=set ear  E=export  Q=quit")
    CTRL_H = 68          # pixels reserved for the top control bar
    FONT   = cv2.FONT_HERSHEY_SIMPLEX
    CW, CH = 1400, 968   # canvas width / height  (CH = 900 + CTRL_H)

    def __init__(
        self,
        bgr:         np.ndarray,
        l_ear:       np.ndarray,
        r_ear:       np.ndarray,
        kps:         np.ndarray | None = None,
        conf_l:      float | None      = None,
        conf_r:      float | None      = None,
        thermal_bgr: np.ndarray | None = None,   # colourised thermal for toggle
    ):
        self.bgr         = bgr
        self.thermal_bgr = thermal_bgr   # None if not a FLIR image
        self.show_thermal = False        # T key toggles this
        self.kps    = kps
        self.conf_l = conf_l
        self.conf_r = conf_r

        # Ear positions — mutable via L / K keys
        self.l_ear = np.array(l_ear, dtype=float)
        self.r_ear = np.array(r_ear, dtype=float)
        self._rebuild_basis()

        # View state
        self.zoom         = 1.0
        self.pan          = np.array([0.0, 0.0])
        self._panning     = False
        self._pan_last    = None

        # Toggle flags
        self.show_fill  = True
        self.show_grid  = True
        self.show_names = True
        self.anchor_mode = False

        # Ear-reposition state  — None | 'L' | 'R'
        self._set_ear_mode = None

        # Data
        self.anchors  = {}   # {name: {'u': float, 'v': float}}
        self.regions  = []   # [{'name': str, 'pts': [name, ...], 'color': BGR}]
        self.cur_pts  = []   # names in the polygon being built

        self._drag_anchor = None

        # Initial zoom: fit image into CH×CW
        ih, iw = self.bgr.shape[:2]
        self.zoom = min((self.CH - self.CTRL_H) / ih, self.CW / iw)
        self.pan  = np.array([(self.CW - iw * self.zoom) / 2.0, 0.0])

        cv2.namedWindow(self.WIN, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(self.WIN, self.CW, self.CH)
        cv2.setMouseCallback(self.WIN, self._mouse)
        self.render()

    # ── basis ────────────────────────────────────────────────────────────────

    def _rebuild_basis(self):
        """Recompute ear-ear coordinate system from current ear positions."""
        diff        = self.r_ear - self.l_ear
        self.D_ear  = max(float(np.hypot(*diff)), 1.0)
        self.ear_mid  = (self.l_ear + self.r_ear) / 2.0
        self.ear_unit = diff / self.D_ear                           # L→R unit vector
        # 90° CW rotation of ear_unit → toward crown (y decreases in image)
        self.ear_perp = np.array([self.ear_unit[1], -self.ear_unit[0]])

    # ── coordinate transforms ─────────────────────────────────────────────────

    def i2c(self, ix: float, iy: float) -> tuple[int, int]:
        """Image pixel → canvas pixel."""
        return (
            int(ix * self.zoom + self.pan[0]),
            int(iy * self.zoom + self.pan[1]) + self.CTRL_H,
        )

    def c2i(self, cx: float, cy: float) -> tuple[float, float]:
        """Canvas pixel → image pixel."""
        return (
            (cx - self.pan[0]) / self.zoom,
            (cy - self.CTRL_H - self.pan[1]) / self.zoom,
        )

    def px_to_uv(self, ix: float, iy: float) -> tuple[float, float]:
        """Image pixel → (u, v) in ear-ear normalised coords."""
        p = np.array([ix, iy]) - self.ear_mid
        u = float(np.dot(p, self.ear_unit)) / self.D_ear
        v = float(np.dot(p, self.ear_perp)) / self.D_ear
        return round(u, 4), round(v, 4)

    def uv_to_px(self, u: float, v: float) -> np.ndarray:
        """(u, v) → image pixel coords (float ndarray [x, y])."""
        return self.ear_mid + u * self.D_ear * self.ear_unit + v * self.D_ear * self.ear_perp

    def anc_pixel(self, name: str) -> np.ndarray:
        """Current image-pixel position of named anchor."""
        a = self.anchors[name]
        return self.uv_to_px(a["u"], a["v"])

    def anc_canvas(self, name: str) -> tuple[int, int]:
        """Current canvas-pixel position of named anchor."""
        p = self.anc_pixel(name)
        return self.i2c(p[0], p[1])

    # ── nearest helpers ───────────────────────────────────────────────────────

    def _nearest_anchor(self, cx: int, cy: int, thr: int = 18) -> str | None:
        best, bd = None, thr ** 2
        for name in self.anchors:
            acx, acy = self.anc_canvas(name)
            d = (cx - acx) ** 2 + (cy - acy) ** 2
            if d < bd:
                bd = d; best = name
        return best

    # ── render ────────────────────────────────────────────────────────────────

    def render(self):
        cw, ch = self.CW, self.CH
        canvas = np.full((ch, cw, 3), (28, 28, 28), np.uint8)

        # ── paste darkened image ─────────────────────────────────────────────
        active_bgr = (self.thermal_bgr
                      if (self.show_thermal and self.thermal_bgr is not None)
                      else self.bgr)
        ih, iw = active_bgr.shape[:2]
        sw, sh = int(iw * self.zoom), int(ih * self.zoom)
        img_s  = cv2.resize(active_bgr, (sw, sh), interpolation=cv2.INTER_LINEAR)
        img_s  = (img_s * 0.60).astype(np.uint8)
        ox = int(self.pan[0]); oy = int(self.pan[1]) + self.CTRL_H
        x0 = max(0, ox); y0 = max(0, oy)
        x1 = min(cw, ox + sw); y1 = min(ch, oy + sh)
        if x1 > x0 and y1 > y0:
            canvas[y0:y1, x0:x1] = img_s[y0 - oy:y1 - oy, x0 - ox:x1 - ox]

        # ── YOLO skeleton (faint reference) ──────────────────────────────────
        if self.kps is not None:
            for (i, j) in _SKELETON:
                if self.kps[i, 2] > 0.25 and self.kps[j, 2] > 0.25:
                    p1 = self.i2c(self.kps[i, 0], self.kps[i, 1])
                    p2 = self.i2c(self.kps[j, 0], self.kps[j, 1])
                    cv2.line(canvas, p1, p2, (50, 50, 80), 1, cv2.LINE_AA)
            for k in range(17):
                if self.kps[k, 2] > 0.25 and k not in (_COCO_LEFT_EAR, _COCO_RIGHT_EAR):
                    pcx, pcy = self.i2c(self.kps[k, 0], self.kps[k, 1])
                    cv2.circle(canvas, (pcx, pcy), 3, (55, 70, 110), -1)

        # ── UV dot-grid ──────────────────────────────────────────────────────
        if self.show_grid:
            for u in np.arange(-0.75, 0.76, 0.125):
                for v in np.arange(-0.75, 0.76, 0.125):
                    px, py = self.uv_to_px(u, v)
                    gcx, gcy = self.i2c(px, py)
                    if 0 <= gcx < cw and self.CTRL_H <= gcy < ch:
                        cv2.circle(canvas, (gcx, gcy), 1, (48, 48, 68), -1)

        # ── ear-ear reference frame ───────────────────────────────────────────
        self._draw_ear_frame(canvas)

        # ── completed region fills ────────────────────────────────────────────
        if self.show_fill:
            for reg in self.regions:
                poly = self._build_poly(reg["pts"])
                if poly is not None and len(poly) >= 3:
                    ov = canvas.copy()
                    cv2.fillPoly(ov, [poly], reg["color"])
                    cv2.addWeighted(ov, 0.35, canvas, 0.65, 0, canvas)

        # ── completed region outlines + labels ────────────────────────────────
        for reg in self.regions:
            poly = self._build_poly(reg["pts"])
            if poly is None or len(poly) < 2:
                continue
            cv2.polylines(canvas, [poly], True, reg["color"], 2, cv2.LINE_AA)
            ctr = poly.mean(0).astype(int)
            self._draw_label(canvas, reg["name"], ctr[0], ctr[1], reg["color"])

        # ── polygon in progress ───────────────────────────────────────────────
        if self.cur_pts:
            pts = self._build_poly(self.cur_pts)
            if pts is not None:
                for i, pt in enumerate(pts):
                    cv2.circle(canvas, tuple(pt), 8, (0, 240, 240), -1, cv2.LINE_AA)
                    cv2.circle(canvas, tuple(pt), 8, (255, 255, 255), 1, cv2.LINE_AA)
                    if i > 0:
                        cv2.line(canvas, tuple(pts[i - 1]), tuple(pt),
                                 (0, 240, 240), 2, cv2.LINE_AA)
                if len(pts) > 1:
                    cv2.line(canvas, tuple(pts[-1]), tuple(pts[0]),
                             (0, 240, 240), 1, cv2.LINE_AA)

        # ── anchors ───────────────────────────────────────────────────────────
        box_r = max(5, int(8 * min(self.zoom, 2.0)))
        for name in self.anchors:
            acx, acy = self.anc_canvas(name)
            if not (0 <= acx < cw and self.CTRL_H <= acy < ch):
                continue
            in_poly = name in self.cur_pts
            col     = (0, 240, 240) if in_poly else (0, 220, 60)
            cv2.rectangle(canvas,
                          (acx - box_r, acy - box_r),
                          (acx + box_r, acy + box_r), col, -1)
            cv2.rectangle(canvas,
                          (acx - box_r, acy - box_r),
                          (acx + box_r, acy + box_r), (255, 255, 255), 1)
            if self.show_names:
                a   = self.anchors[name]
                lbl = f"{name}  u={a['u']:+.2f}  v={a['v']:+.2f}"
                fs  = max(0.22, 0.30 * min(self.zoom, 2.0))
                cv2.putText(canvas, lbl,
                            (acx + box_r + 3, acy + 4),
                            self.FONT, fs, (0, 0, 0), 2, cv2.LINE_AA)
                cv2.putText(canvas, lbl,
                            (acx + box_r + 3, acy + 4),
                            self.FONT, fs, col, 1, cv2.LINE_AA)

        # ── control bar ───────────────────────────────────────────────────────
        cv2.rectangle(canvas, (0, 0), (cw, self.CTRL_H), (18, 18, 18), -1)
        cv2.line(canvas, (0, self.CTRL_H), (cw, self.CTRL_H), (60, 60, 60), 1)

        if self._set_ear_mode:
            ear_name = "LEFT" if self._set_ear_mode == "L" else "RIGHT"
            mode_txt = f"[ CLICK TO SET {ear_name} EAR — Esc to cancel ]"
            mode_col = (60, 120, 255) if self._set_ear_mode == "L" else (0, 220, 80)
        elif self.anchor_mode:
            mode_txt = "[ ANCHOR MODE ]"
            mode_col = (60, 220, 255)
        else:
            mode_txt = "[ POLYGON MODE ]"
            mode_col = (80, 255, 100)

        view_tag = ""
        if self.thermal_bgr is not None:
            view_tag = "  📷 RGB" if not self.show_thermal else "  🌡 THERMAL"

        cur_str = f"  •  polygon: {len(self.cur_pts)} pt(s)" if self.cur_pts else ""
        conf_str = ""
        if self.conf_l is not None and self.conf_r is not None:
            conf_str = f"  L-ear={self.conf_l:.2f}  R-ear={self.conf_r:.2f}"
        stat_str = (f"  |  regions: {len(self.regions)}"
                    f"  anchors: {len(self.anchors)}"
                    f"  D_ear={self.D_ear:.0f}px"
                    f"{conf_str}{view_tag}")

        cv2.putText(canvas, mode_txt + cur_str + stat_str,
                    (10, 22), self.FONT, 0.50, mode_col, 1, cv2.LINE_AA)
        cv2.putText(canvas,
                    ("A=anchor  F=fill  G=grid  N=names  T=RGB/thermal  "
                     "L/K=set L/R ear  "
                     "Enter=finish  Backspace=undo pt  Del=undo region  "
                     "E=export  V=reset view  Q=quit"),
                    (10, 44), self.FONT, 0.34, (100, 100, 100), 1, cv2.LINE_AA)

        if self._set_ear_mode:
            ear_name = "LEFT  (blue)" if self._set_ear_mode == "L" else "RIGHT (green)"
            cv2.putText(canvas, f"Click the {ear_name} ear in the image",
                        (10, 63), self.FONT, 0.40, (0, 200, 255), 1, cv2.LINE_AA)

        cv2.imshow(self.WIN, canvas)

    # ── ear-ear reference frame drawing ───────────────────────────────────────

    def _draw_ear_frame(self, canvas):
        cw, ch = self.CW, self.CH

        # Extended ear-ear axis line
        ext_l = self.uv_to_px(-0.65, 0.0)
        ext_r = self.uv_to_px( 0.65, 0.0)
        cv2.line(canvas,
                 self.i2c(ext_l[0], ext_l[1]),
                 self.i2c(ext_r[0], ext_r[1]),
                 (50, 50, 90), 1, cv2.LINE_AA)

        # Perpendicular axis through midpoint
        perp_t = self.uv_to_px(0.0,  0.85)
        perp_b = self.uv_to_px(0.0, -0.65)
        cv2.line(canvas,
                 self.i2c(perp_t[0], perp_t[1]),
                 self.i2c(perp_b[0], perp_b[1]),
                 (50, 50, 90), 1, cv2.LINE_AA)

        # Axis tick marks  (every 0.125 D_ear)
        for u_tick in np.arange(-0.5, 0.51, 0.125):
            p1 = self.uv_to_px(u_tick, -0.03)
            p2 = self.uv_to_px(u_tick,  0.03)
            cv2.line(canvas,
                     self.i2c(p1[0], p1[1]),
                     self.i2c(p2[0], p2[1]),
                     (70, 70, 110), 1)

        # Perpendicular ticks
        for v_tick in np.arange(-0.5, 0.76, 0.125):
            p1 = self.uv_to_px(-0.02, v_tick)
            p2 = self.uv_to_px( 0.02, v_tick)
            cv2.line(canvas,
                     self.i2c(p1[0], p1[1]),
                     self.i2c(p2[0], p2[1]),
                     (70, 70, 110), 1)

        # Midpoint marker
        mcx, mcy = self.i2c(self.ear_mid[0], self.ear_mid[1])
        cv2.circle(canvas, (mcx, mcy), 5, (90, 90, 160), -1, cv2.LINE_AA)
        cv2.putText(canvas, "M (0,0)", (mcx + 7, mcy + 4),
                    self.FONT, 0.32, (100, 100, 180), 1, cv2.LINE_AA)

        # Scale bar under the ear line:  "1× D_ear"
        bar_l_px = self.uv_to_px(-0.5, 0.0)
        bar_r_px = self.uv_to_px( 0.5, 0.0)
        bcl = self.i2c(bar_l_px[0], bar_l_px[1])
        bcr = self.i2c(bar_r_px[0], bar_r_px[1])
        # Place the scale bar below the ear line (add in the perpendicular direction)
        p_bar_l = self.uv_to_px(-0.5, -0.12)
        p_bar_r = self.uv_to_px( 0.5, -0.12)
        bl = self.i2c(p_bar_l[0], p_bar_l[1])
        br = self.i2c(p_bar_r[0], p_bar_r[1])
        cv2.line(canvas, bl, br, (70, 70, 130), 1)
        cv2.line(canvas, (bl[0], bl[1] - 4), (bl[0], bl[1] + 4), (70, 70, 130), 1)
        cv2.line(canvas, (br[0], br[1] - 4), (br[0], br[1] + 4), (70, 70, 130), 1)
        mid_bar_x = (bl[0] + br[0]) // 2
        mid_bar_y = (bl[1] + br[1]) // 2
        cv2.putText(canvas, "1× D_ear",
                    (mid_bar_x - 28, mid_bar_y + 14),
                    self.FONT, 0.30, (80, 80, 150), 1, cv2.LINE_AA)

        # Ear markers — draw over everything else
        for side, ear, conf, lbl, col in [
            ("L", self.l_ear, self.conf_l, "L-EAR", (60, 110, 255)),
            ("R", self.r_ear, self.conf_r, "R-EAR", (0, 220, 80)),
        ]:
            ecx, ecy = self.i2c(ear[0], ear[1])
            # Highlight if currently being repositioned
            ring_col = (0, 200, 255) if self._set_ear_mode == side else col
            cv2.circle(canvas, (ecx, ecy), 14, ring_col, 2, cv2.LINE_AA)
            cv2.circle(canvas, (ecx, ecy),  4, ring_col, -1, cv2.LINE_AA)
            if conf is not None:
                tag = f"{lbl} ({conf:.2f})"
            else:
                tag = f"{lbl} (manual)"
            cv2.putText(canvas, tag, (ecx + 16, ecy + 5),
                        self.FONT, max(0.28, 0.38 * min(self.zoom, 2.0)),
                        (0, 0, 0), 3, cv2.LINE_AA)
            cv2.putText(canvas, tag, (ecx + 16, ecy + 5),
                        self.FONT, max(0.28, 0.38 * min(self.zoom, 2.0)),
                        ring_col, 1, cv2.LINE_AA)

    # ── polygon builder ───────────────────────────────────────────────────────

    def _build_poly(self, names: list) -> np.ndarray | None:
        pts = []
        for name in names:
            if name not in self.anchors:
                return None
            pts.append(self.anc_canvas(name))
        return np.array(pts, dtype=np.int32) if pts else None

    def _draw_label(self, canvas, txt, cx, cy, col):
        cv2.putText(canvas, txt, (cx + 1, cy + 1),
                    self.FONT, 0.52, (0, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(canvas, txt, (cx, cy),
                    self.FONT, 0.52, col, 1, cv2.LINE_AA)

    # ── mouse ─────────────────────────────────────────────────────────────────

    def _mouse(self, event, cx, cy, flags, _param):
        # ── scroll zoom ───────────────────────────────────────────────────────
        if event == cv2.EVENT_MOUSEWHEEL:
            f = 1.12 if flags > 0 else 1.0 / 1.12
            ix, iy = self.c2i(cx, cy)
            self.zoom = max(0.1, min(10.0, self.zoom * f))
            ncx, ncy = self.i2c(ix, iy)
            self.pan[0] += cx - ncx
            self.pan[1] += (cy - self.CTRL_H) - (ncy - self.CTRL_H)
            self.render()
            return

        # ── middle-button pan ─────────────────────────────────────────────────
        if event == cv2.EVENT_MBUTTONDOWN:
            self._panning = True; self._pan_last = (cx, cy); return
        if event == cv2.EVENT_MBUTTONUP:
            self._panning = False; return

        # ── mouse move: pan or drag anchor ────────────────────────────────────
        if event == cv2.EVENT_MOUSEMOVE:
            if self._panning and self._pan_last:
                self.pan[0] += cx - self._pan_last[0]
                self.pan[1] += cy - self._pan_last[1]
                self._pan_last = (cx, cy)
                self.render()
            if self._drag_anchor:
                ix, iy = self.c2i(cx, cy)
                u, v = self.px_to_uv(ix, iy)
                self.anchors[self._drag_anchor]["u"] = u
                self.anchors[self._drag_anchor]["v"] = v
                self.render()
            return

        if event == cv2.EVENT_LBUTTONUP and self._drag_anchor:
            self._drag_anchor = None; return

        # Ignore clicks inside control bar (unless setting ears)
        if cy < self.CTRL_H and not self._set_ear_mode:
            return

        # ── ear-set mode: next click repositions an ear ───────────────────────
        if self._set_ear_mode and event == cv2.EVENT_LBUTTONDOWN:
            ix, iy = self.c2i(cx, cy)
            if self._set_ear_mode == "L":
                self.l_ear  = np.array([ix, iy])
                self.conf_l = None
            else:
                self.r_ear  = np.array([ix, iy])
                self.conf_r = None
            self._rebuild_basis()
            self._set_ear_mode = None
            self.render()
            return

        # ── left-click: main interaction ──────────────────────────────────────
        if event == cv2.EVENT_LBUTTONDOWN:
            if self.anchor_mode:
                # Start dragging an existing anchor
                an = self._nearest_anchor(cx, cy)
                if an:
                    self._drag_anchor = an; return
                # Place a new anchor
                ix, iy = self.c2i(cx, cy)
                self._place_anchor(ix, iy, add_to_poly=False)
            else:
                # Polygon mode: click near anchor → add to polygon
                an = self._nearest_anchor(cx, cy)
                if an:
                    if an not in self.cur_pts:
                        self.cur_pts.append(an)
                    self.render()
                    return
                # Click on empty space → place new anchor + add to polygon
                ix, iy = self.c2i(cx, cy)
                self._place_anchor(ix, iy, add_to_poly=True)

        # ── right-click anchor: delete ────────────────────────────────────────
        if event == cv2.EVENT_RBUTTONDOWN:
            an = self._nearest_anchor(cx, cy)
            if an:
                # Remove from any completed regions and current polygon
                for reg in self.regions:
                    reg["pts"] = [p for p in reg["pts"] if p != an]
                self.cur_pts = [p for p in self.cur_pts if p != an]
                del self.anchors[an]
                self.render()

        # ── double-click anchor: rename ───────────────────────────────────────
        if event == cv2.EVENT_LBUTTONDBLCLK:
            an = self._nearest_anchor(cx, cy)
            if an:
                nn = _ask("Rename anchor", "New name:", an)
                if nn and nn != an:
                    nn = nn.strip().upper().replace(" ", "_")
                    self.anchors[nn] = self.anchors.pop(an)
                    for reg in self.regions:
                        reg["pts"] = [nn if p == an else p for p in reg["pts"]]
                    self.cur_pts = [nn if p == an else p for p in self.cur_pts]
                self.render()

    def _place_anchor(self, ix: float, iy: float, add_to_poly: bool):
        u, v = self.px_to_uv(ix, iy)
        default_name = f"A{len(self.anchors) + 1:02d}"
        name = _ask("New Anchor", "Anchor name (e.g. CROWN_L):", default_name)
        if not name:
            return
        name = name.strip().upper().replace(" ", "_")
        if name in self.anchors:
            _info("Duplicate", f"'{name}' already exists."); return
        self.anchors[name] = {"u": u, "v": v}
        if add_to_poly:
            self.cur_pts.append(name)
        self.render()

    # ── keyboard ──────────────────────────────────────────────────────────────

    def key(self, k: int) -> str | None:
        # Ear-set mode: Esc cancels
        if self._set_ear_mode and k == 27:
            self._set_ear_mode = None

        elif k in (13, 10):                  # Enter — finish polygon
            if len(self.cur_pts) >= 3:
                name = _ask("Region name", "e.g.  Crown  /  L-Parietal",
                            f"Region_{len(self.regions) + 1}")
                if name:
                    self.regions.append({
                        "name":  name.strip(),
                        "pts":   list(self.cur_pts),
                        "color": _palette(len(self.regions)),
                    })
                    self.cur_pts = []
            else:
                _info("Too few points", "A polygon needs at least 3 anchor points.")

        elif k == 8:                          # Backspace — undo last point
            if self.cur_pts:
                self.cur_pts.pop()

        elif k == 27:                         # Esc — cancel polygon or quit
            if self.cur_pts:
                self.cur_pts = []
            else:
                return "quit"

        elif k in (ord("q"), ord("Q")):
            return "quit"

        elif k in (255, 3014656):             # Delete — remove last region
            if self.regions:
                self.regions.pop()

        elif k in (ord("a"), ord("A")):
            self.anchor_mode = not self.anchor_mode

        elif k in (ord("f"), ord("F")):
            self.show_fill = not self.show_fill

        elif k in (ord("g"), ord("G")):
            self.show_grid = not self.show_grid

        elif k in (ord("n"), ord("N")):
            self.show_names = not self.show_names

        elif k in (ord("l"), ord("L")):       # Set left ear on next click
            self._set_ear_mode = "L"

        elif k in (ord("k"), ord("K")):       # Set right ear on next click
            self._set_ear_mode = "R"

        elif k in (ord("e"), ord("E")):
            self.export()

        elif k in (ord("j"), ord("J")):
            self.export_json()

        elif k in (ord("t"), ord("T")):       # Toggle thermal / RGB view
            if self.thermal_bgr is not None:
                self.show_thermal = not self.show_thermal
            else:
                print("  [T] No thermal image available for this file.")

        elif k in (ord("v"), ord("V")):       # reset View (use active image size)
            active = (self.thermal_bgr
                      if (self.show_thermal and self.thermal_bgr is not None)
                      else self.bgr)
            ih, iw = active.shape[:2]
            self.zoom = min((self.CH - self.CTRL_H) / ih, self.CW / iw)
            self.pan  = np.array([(self.CW - iw * self.zoom) / 2.0, 0.0])

        elif k in (ord("+"), ord("=")):
            self.zoom = min(10.0, self.zoom * 1.20)

        elif k == ord("-"):
            self.zoom = max(0.10, self.zoom / 1.20)

        self.render()
        return None

    # ── export ────────────────────────────────────────────────────────────────

    def export(self):
        lines = [
            "# ════════════════════════════════════════════════════════════════════════",
            "# Paste these blocks into Back_FLIR_Extractor.py",
            "# ════════════════════════════════════════════════════════════════════════",
            "#",
            "# COORDINATE SYSTEM  (u, v) — both normalised by D_ear",
            "#",
            "#   u  along the ear–ear axis:",
            "#        u = -0.5  →  left ear",
            "#        u =  0.0  →  midpoint between ears",
            "#        u = +0.5  →  right ear",
            "#",
            "#   v  perpendicular to ear axis:",
            "#        v > 0  →  toward crown  (upward in image, y decreases)",
            "#        v < 0  →  toward neck   (downward in image)",
            "#",
            "# RECONSTRUCTION (given l_ear and r_ear as pixel arrays):",
            "#",
            "#   import numpy as np",
            "#   def build_anchor_pixels(l_ear, r_ear, anchors):",
            "#       l, r   = np.array(l_ear, float), np.array(r_ear, float)",
            "#       D      = float(np.hypot(*(r - l)))",
            "#       e_u    = (r - l) / D                      # unit along ear axis",
            "#       e_v    = np.array([e_u[1], -e_u[0]])      # 90° CW  →  toward crown",
            "#       M      = (l + r) / 2                      # midpoint",
            "#       return {",
            "#           name: M + a['u']*D*e_u + a['v']*D*e_v",
            "#           for name, a in anchors.items()",
            "#       }",
            "#",
            "# ════════════════════════════════════════════════════════════════════════",
            "",
            "from collections import OrderedDict",
            "",
        ]

        # ── BACK_ANCHORS ──────────────────────────────────────────────────────
        lines.append("# ── Anchor definitions ──────────────────────────────────────────────────")
        lines.append("BACK_ANCHORS = OrderedDict([")
        if not self.anchors:
            lines.append("    # (no anchors defined)")
        for name, a in self.anchors.items():
            lines.append(f"    ('{name}', {{'u': {a['u']:+.4f}, 'v': {a['v']:+.4f}}}),")
        lines.append("])")
        lines.append("")

        # ── BACK_REGION_DEFS ──────────────────────────────────────────────────
        lines.append("# ── Region definitions ─────────────────────────────────────────────────")
        lines.append("BACK_REGION_DEFS = OrderedDict([")
        for reg in self.regions:
            rgb = (reg["color"][2], reg["color"][1], reg["color"][0])   # BGR→RGB
            lines.append(f"    ('{reg['name']}', {{")
            lines.append( "        'poly': [")
            for name in reg["pts"]:
                lines.append(f"            '{name}',")
            lines.append( "        ],")
            lines.append(f"        'color': {rgb},  'alpha': 0.40,")
            lines.append( "    }),")
        lines.append("])")
        lines.append("")

        code = "\n".join(lines)
        sep  = "═" * 74
        print(f"\n{sep}\n{code}\n{sep}\n")

        out_path = "back_region_defs.py"
        with open(out_path, "w", encoding="utf-8") as fh:
            fh.write(code + "\n")

        _info("Exported",
              f"Code printed to terminal.\nAlso saved to:\n{os.path.abspath(out_path)}")

    def export_json(self):
        """Save / update the 'back' section of mesh_defs.json  (press J)."""
        import json
        from pathlib import Path

        anchors_out = {
            name: {"u": a["u"], "v": a["v"]}
            for name, a in self.anchors.items()
        }
        regions_out = {}
        for reg in self.regions:
            bgr = reg["color"]                          # stored as BGR
            regions_out[reg["name"]] = {
                "poly":  list(reg["pts"]),
                "color": [bgr[0], bgr[1], bgr[2]],
                "alpha": 0.40,
            }

        path = Path("mesh_defs.json")
        data = json.loads(path.read_text()) if path.exists() else {}
        data.setdefault("version", "1.0.0")
        data["back"] = {"anchors": anchors_out, "regions": regions_out}
        path.write_text(json.dumps(data, indent=2))
        print(f"[mesh_editor] Saved back mesh to {path.resolve()}")
        _info("JSON Exported",
              f"'back' section written to:\n{path.resolve()}\n\n"
              f"Commit the file and push to update the hosted definitions.")


# ── FLIR image loading ─────────────────────────────────────────────────────────

def _thermal_to_display_bgr(thermal: np.ndarray) -> np.ndarray:
    """Convert a float32 thermal array → colourised uint8 BGR (COLORMAP_INFERNO)."""
    t_min, t_max = np.nanmin(thermal), np.nanmax(thermal)
    if t_max > t_min:
        norm = ((thermal - t_min) / (t_max - t_min) * 255).astype(np.uint8)
    else:
        norm = np.zeros_like(thermal, dtype=np.uint8)
    return cv2.applyColorMap(norm, cv2.COLORMAP_INFERNO)


def _find_exiftool() -> str:
    """
    Locate the exiftool binary. Search order:
      1. System PATH
      2. dji_executables package dir  (bundled by flirimageextractor on Windows)
      3. flirimageextractor package dir
      4. All site-packages dirs, including user site-packages
    Returns the full path string, or "" if not found.
    """
    # 1. System PATH
    et = shutil.which("exiftool")
    if et:
        return et

    # Collect all site-package roots to search (including user packages)
    sp_roots = []
    try:
        sp_roots += site.getsitepackages() if hasattr(site, "getsitepackages") else []
    except Exception:
        pass
    try:
        user_sp = site.getusersitepackages()
        if user_sp and user_sp not in sp_roots:
            sp_roots.append(user_sp)
    except Exception:
        pass

    # 2. dji_executables package (where flirimageextractor bundles exiftool on Windows)
    try:
        import dji_executables as _dji
        dji_dir = os.path.dirname(_dji.__file__)
        for candidate in glob.glob(os.path.join(dji_dir, "**", "exiftool*"), recursive=True):
            if os.path.isfile(candidate) and not candidate.endswith((".txt", ".md")):
                return candidate
    except Exception:
        pass

    # 3. flirimageextractor package dir
    try:
        import flirimageextractor as _flie
        pkg_dir = os.path.dirname(_flie.__file__)
        for candidate in glob.glob(os.path.join(pkg_dir, "**", "exiftool*"), recursive=True):
            if os.path.isfile(candidate) and not candidate.endswith((".txt", ".md")):
                return candidate
    except Exception:
        pass

    # 4. All site-packages roots (broad fallback)
    for sp in sp_roots:
        for candidate in glob.glob(os.path.join(sp, "**", "exiftool*"), recursive=True):
            if os.path.isfile(candidate) and not candidate.endswith((".txt", ".md")):
                return candidate

    return ""

    return ""


_EXIFTOOL_EXE: str | None = None   # resolved once, then cached


def _extract_rgb_via_exiftool(path: str) -> np.ndarray | None:
    """
    Try known FLIR embedded-image EXIF tags via the exiftool binary.
    Returns an RGB uint8 ndarray, or None if extraction fails.
    """
    global _EXIFTOOL_EXE
    if _EXIFTOOL_EXE is None:
        _EXIFTOOL_EXE = _find_exiftool()
        if _EXIFTOOL_EXE:
            print(f"  [exiftool] found: {_EXIFTOOL_EXE}")
        else:
            print("  [exiftool] not found — skipping tag extraction.\n"
                  "             Install from https://exiftool.org for better RGB quality.")
    if not _EXIFTOOL_EXE:
        return None

    from PIL import Image as _PILImage

    for tag in ("EmbeddedImage", "ThumbnailImage", "PreviewImage", "JpgFromRaw"):
        try:
            r = subprocess.run(
                [_EXIFTOOL_EXE, "-b", f"-{tag}", path],
                capture_output=True, timeout=20,
            )
            if (r.returncode == 0
                    and len(r.stdout) > 500
                    and r.stdout[:2] == b"\xff\xd8"):   # JPEG magic bytes
                img = np.array(_PILImage.open(io.BytesIO(r.stdout)).convert("RGB"))
                print(f"  [exiftool] tag '{tag}' → RGB {img.shape}")
                return img
        except Exception as exc:
            print(f"  [exiftool] tag '{tag}' error: {exc}")
    return None


def load_image(path: str) -> dict:
    """
    Load *path* and return a dict:

        'bgr'         – BGR ndarray shown in the editor        (always present)
        'rgb'         – same as RGB                            (always present)
        'thermal'     – float32 temperature array or None      (FLIR only)
        'thermal_bgr' – false-colour thermal BGR or None       (FLIR only)
        'is_flir'     – bool
        'source'      – human-readable description

    RGB extraction priority for FLIR files:
        1. flir.get_rgb_np()         — built into flirimageextractor, no extras needed
        2. exiftool tag extraction   — higher-res on some camera models
        3. PIL open of the file      — the outer JPEG preview
        4. Thermal false-colour      — last resort if no RGB at all
    """
    from PIL import Image as _PILImage

    result = {
        "bgr":         None,
        "rgb":         None,
        "thermal":     None,
        "thermal_bgr": None,
        "is_flir":     False,
        "source":      "",
    }

    flir_obj = None
    thermal  = None

    # ── Step 1: try flirimageextractor ────────────────────────────────────────
    try:
        from flirimageextractor import FlirImageExtractor
        flir_obj = FlirImageExtractor()
        flir_obj.process_image(path)
        thermal = np.array(flir_obj.get_thermal_np(), dtype=np.float32)
        result["is_flir"]     = True
        result["thermal"]     = thermal
        result["thermal_bgr"] = _thermal_to_display_bgr(thermal)
        print(f"  [FLIR] thermal  → {thermal.shape}  "
              f"range {thermal.min():.1f} – {thermal.max():.1f} °C")
    except ImportError:
        print("  [FLIR] flirimageextractor not installed — treating as plain image.")
    except Exception as exc:
        print(f"  [FLIR] not a FLIR file or read error ({exc}) — plain image mode.")

    # ── Step 2: extract RGB ───────────────────────────────────────────────────
    rgb = None

    if result["is_flir"] and flir_obj is not None:

        # 2a. get_rgb_np() — the correct built-in method, no exiftool needed
        try:
            rgb_raw = flir_obj.get_rgb_np()
            if rgb_raw is not None and rgb_raw.size > 0:
                # Ensure it's uint8 RGB (H×W×3)
                if rgb_raw.ndim == 2:
                    rgb_raw = np.stack([rgb_raw] * 3, axis=-1)
                if rgb_raw.shape[2] == 4:
                    rgb_raw = rgb_raw[:, :, :3]
                rgb = rgb_raw.astype(np.uint8)
                result["source"] = "FLIR (get_rgb_np)"
                print(f"  [FLIR] RGB via get_rgb_np()  → {rgb.shape}")
        except Exception as exc:
            print(f"  [FLIR] get_rgb_np() failed: {exc}")

        # 2b. exiftool tag extraction (higher-res on some FLIR models)
        if rgb is None:
            print("  [FLIR] trying exiftool tag extraction …")
            rgb = _extract_rgb_via_exiftool(path)
            if rgb is not None:
                result["source"] = "FLIR (exiftool embedded tag)"

        # 2c. PIL open of the file — the outer JPEG (low-res preview, always present)
        if rgb is None:
            try:
                rgb = np.array(_PILImage.open(path).convert("RGB"))
                result["source"] = "FLIR (outer JPEG preview)"
                print(f"  [FLIR] RGB via outer JPEG preview  → {rgb.shape}")
            except Exception as exc:
                print(f"  [FLIR] outer JPEG read failed: {exc}")

        # 2d. Last resort: false-colour thermal rendered as RGB
        if rgb is None and thermal is not None:
            bgr = _thermal_to_display_bgr(thermal)
            rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
            result["source"] = "FLIR (thermal false-colour — no RGB found)"
            print("  [FLIR] WARNING: no RGB image found; displaying thermal false-colour.")

    # ── Step 3: plain image fallback ──────────────────────────────────────────
    if rgb is None:
        try:
            rgb = np.array(_PILImage.open(path).convert("RGB"))
            result["source"] = "plain image"
            print(f"  [plain] loaded  → {rgb.shape}")
        except Exception as exc:
            print(f"ERROR: cannot open image: {exc}")
            sys.exit(1)

    if rgb is None:
        print("ERROR: all image loading methods failed.")
        sys.exit(1)

    result["rgb"] = rgb
    result["bgr"] = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    return result


# ── main ───────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("image",
                    help="Back-of-head photo (JPG / PNG / BMP …)")
    ap.add_argument("--model", default="yolov8n-pose.pt",
                    help="YOLOv8 pose model weights  "
                         "(default: yolov8n-pose.pt — auto-downloaded on first run). "
                         "Use yolov8m-pose.pt or yolov8l-pose.pt for higher accuracy.")
    ap.add_argument("--manual", action="store_true",
                    help="Skip YOLO detection — place ears by clicking manually.")
    args = ap.parse_args()

    # ── Load image (auto-detects FLIR) ───────────────────────────────────────
    print(f"\nLoading: {args.image}")
    img_data = load_image(args.image)
    bgr = img_data["bgr"]

    print(f"  Source  : {img_data['source']}")
    print(f"  Size    : {bgr.shape[1]} × {bgr.shape[0]} px")
    if img_data["is_flir"]:
        print(f"  Thermal : {img_data['thermal'].shape}  "
              f"(press T in the editor to toggle thermal/RGB view)")
    print()

    l_ear = r_ear = kps = None
    conf_l = conf_r = None

    # ── YOLO detection ────────────────────────────────────────────────────────
    if not args.manual:
        print(f"\nRunning YOLOv8 pose  [{args.model}] …")
        result = run_yolo(bgr, args.model)
        if result is not None:
            l_ear, r_ear, kps, conf_l, conf_r = result
            d = np.hypot(*(r_ear - l_ear))
            print(f"  ✓  Left  ear: ({l_ear[0]:.1f}, {l_ear[1]:.1f})   conf={conf_l:.2f}")
            print(f"  ✓  Right ear: ({r_ear[0]:.1f}, {r_ear[1]:.1f})   conf={conf_r:.2f}")
            print(f"  ✓  D_ear = {d:.1f} px")

            # Warn if one ear has low confidence (back-of-head scenario)
            if conf_l < 0.35 or conf_r < 0.35:
                print("\n  [WARN] One or both ear confidences are low (<0.35).")
                print("         You can reposition ears at any time with the L / K keys.")
        else:
            print("[YOLO] No reliable ear detection — switching to manual placement.")

    # ── Manual ear placement fallback ─────────────────────────────────────────
    if l_ear is None or r_ear is None:
        print("\nManual ear placement:")
        print("  1. A window will open with the image.")
        print("  2. Click the LEFT  ear tip.")
        print("  3. Click the RIGHT ear tip.")
        print("  4. Press any key to confirm.")
        l_ear, r_ear = click_ears_manually(bgr)
        print(f"  ✓  Left  ear set at ({l_ear[0]:.1f}, {l_ear[1]:.1f})")
        print(f"  ✓  Right ear set at ({r_ear[0]:.1f}, {r_ear[1]:.1f})")

    print("\nOpening editor …")
    print("  L  →  next click repositions LEFT  ear")
    print("  K  →  next click repositions RIGHT ear")
    print("  E  →  export BACK_ANCHORS + BACK_REGION_DEFS")
    print()

    ed = Editor(bgr, l_ear, r_ear, kps, conf_l, conf_r,
                thermal_bgr=img_data.get("thermal_bgr"))

    while True:
        k = cv2.waitKey(30) & 0xFF
        if k != 255:
            if ed.key(k) == "quit":
                break
        try:
            if cv2.getWindowProperty(ed.WIN, cv2.WND_PROP_VISIBLE) < 1:
                break
        except Exception:
            break

    cv2.destroyAllWindows()
    print("Editor closed.")


if __name__ == "__main__":
    main()