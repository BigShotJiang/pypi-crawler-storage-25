#!/usr/bin/env python3
"""
shared_utils.py

Shared utilities for the FLIR thermal analysis pipeline.

I/O helpers
-----------
_safe_float(s) -> float
    Parse a string to float; return NaN on failure.
_fmt(v) -> str
    Format a value for CSV output.
get_capture_time(path) -> datetime
    Read EXIF DateTimeOriginal, fall back to file mtime.
get_polygon_values(thermal, poly_display, display_shape) -> (values, coords)
    Extract pixel temperatures and coordinates for a polygon ROI.
region_stats(values) -> (mean, variance, npixels)
    Quick console summary statistics (never written to disk).
_save_overlay(out_dir, label, overlay_bgr) -> str
    Write annotated display image; return relative path.
_save_pixels(out_dir, label, pixel_dict) -> str
    Write {region_name: float32_array, region_name__coords: int16_array} as NPZ.
_write_meta(out_dir, meta) -> None
    Write session_meta.json.

Feature computation
-------------------
compute_region_features(pixel_values) -> dict
    All features for one ROI at one timepoint.
    Basic:   mean, median, max, min, variance
    Texture: energy, entropy (histogram), kurtosis (excess), skewness
    Count:   npixels

CCF
---
cross_covariance_bartlett(x, y, max_lag, alpha=0.05) -> dict
    Normalized cross-covariance (CCF) with Bartlett confidence interval.
    Accounts for autocorrelation in both x and y to prevent the
    spurious-correlation trap common in thermal time-series analysis.
"""

import cv2
import json
import math
import os

import numpy as np
import scipy.stats

from datetime import datetime
from PIL import Image
from PIL.ExifTags import TAGS


# Ordered feature names used in CSV rows
FEATURE_NAMES = [
    "mean", "median", "max", "min", "variance",
    "energy", "entropy", "kurtosis", "skewness", "npixels",
]


# ── CSV helpers ───────────────────────────────────────────────────────────────

def _safe_float(s) -> float:
    """Parse s to float; return NaN on any failure."""
    try:
        return float(s)
    except (ValueError, TypeError):
        return float("nan")


def _fmt(v) -> str:
    """Format a scalar value for CSV output."""
    if isinstance(v, (float, np.floating)) and not math.isfinite(float(v)):
        return ""
    if isinstance(v, (float, np.floating)):
        return f"{float(v):.6g}"
    if isinstance(v, (bool, np.bool_)):
        return str(bool(v))
    return str(v)


# ── image I/O ─────────────────────────────────────────────────────────────────

def get_capture_time(path) -> datetime:
    """Read EXIF DateTimeOriginal; fall back to file modification time."""
    try:
        img  = Image.open(path)
        exif = img.getexif()
        if exif:
            for tid, val in exif.items():
                if TAGS.get(tid, tid) == "DateTimeOriginal":
                    return datetime.strptime(val, "%Y:%m:%d %H:%M:%S")
    except Exception:
        pass
    return datetime.fromtimestamp(os.path.getmtime(path))


# ── ROI extraction ────────────────────────────────────────────────────────────

def get_polygon_values(thermal, poly_display, display_shape):
    """
    Extract pixel temperatures and (row, col) coordinates for a polygon ROI.

    Parameters
    ----------
    thermal       : float32 array (H_t, W_t) — thermal temperature grid
    poly_display  : int32 array (N, 2)        — polygon vertices in display coords (x, y)
    display_shape : tuple                     — (H_d, W_d[, ...]) of the display image

    Returns
    -------
    values : float32 array (M,)     — temperature of each pixel inside the polygon
    coords : int16  array (M, 2)    — (row, col) of each pixel in thermal-grid space

    Both arrays are parallel: coords[i] is the location of values[i].
    Saved in NPZ as  region_name  and  region_name__coords.
    """
    Ht, Wt = thermal.shape
    Hd, Wd = display_shape[:2]
    poly_t = poly_display.astype(np.float64).copy()
    poly_t[:, 0] *= Wt / Wd
    poly_t[:, 1] *= Ht / Hd
    poly_t = poly_t.astype(np.int32)
    poly_t[:, 0] = np.clip(poly_t[:, 0], 0, Wt - 1)
    poly_t[:, 1] = np.clip(poly_t[:, 1], 0, Ht - 1)
    mask = np.zeros((Ht, Wt), dtype=np.uint8)
    cv2.fillPoly(mask, [poly_t.reshape(-1, 1, 2)], 1)
    rows, cols = np.where(mask == 1)
    values     = thermal[rows, cols].astype(np.float32)
    coords     = np.stack([rows, cols], axis=1).astype(np.int16)
    return values, coords


def region_stats(values):
    """
    Quick console summary: (mean, variance, npixels).
    Never written to disk — used only for human-readable progress output.
    """
    if values.size == 0:
        return float("nan"), float("nan"), 0
    return (float(np.mean(values)),
            float(np.var(values, ddof=1)) if values.size > 1 else 0.0,
            int(values.size))


# ── session output ────────────────────────────────────────────────────────────

def _save_overlay(out_dir: str, label: str, overlay_bgr) -> str:
    """Write annotated display image to overlays/{label}.png; return relative path."""
    rel = os.path.join("overlays", f"{label}.png")
    cv2.imwrite(os.path.join(out_dir, rel), overlay_bgr)
    return rel


def _save_pixels(out_dir: str, label: str, pixel_dict: dict) -> str:
    """
    Write {region_name: float32_array, region_name__coords: int16_array} as NPZ.
    Returns relative path pixels/{label}.npz.
    """
    rel = os.path.join("pixels", f"{label}.npz")
    np.savez(os.path.join(out_dir, rel), **pixel_dict)
    return rel


def _write_meta(out_dir: str, meta: dict) -> None:
    """Write session_meta.json."""
    path = os.path.join(out_dir, "session_meta.json")
    with open(path, "w") as f:
        json.dump(meta, f, indent=2, default=str)


# ── feature computation ───────────────────────────────────────────────────────

def compute_region_features(pixel_values) -> dict:
    """
    Compute all features for one ROI from its temperature pixel array.

    Parameters
    ----------
    pixel_values : array-like of float  (temperature values in °C)

    Returns
    -------
    dict keyed by FEATURE_NAMES.
    All float features are NaN for an empty array; npixels is 0.
    """
    nan_result = {k: (0 if k == "npixels" else float("nan"))
                  for k in FEATURE_NAMES}

    if pixel_values is None:
        return nan_result

    pv = np.asarray(pixel_values, dtype=np.float64).ravel()
    if pv.size == 0:
        return nan_result

    n = pv.size

    # histogram-based entropy (32 bins, normalised to probability)
    counts, _ = np.histogram(pv, bins=32)
    probs = counts / counts.sum()
    probs = probs[probs > 0]
    entropy = float(-np.sum(probs * np.log2(probs)))

    return {
        "mean":     float(np.mean(pv)),
        "median":   float(np.median(pv)),
        "max":      float(np.max(pv)),
        "min":      float(np.min(pv)),
        "variance": float(np.var(pv, ddof=1)) if n > 1 else 0.0,
        "energy":   float(np.mean(pv ** 2)),         # raw signal energy (mean of squares)
        "entropy":  entropy,                          # bits
        "kurtosis": float(scipy.stats.kurtosis(pv)), # excess kurtosis (Fisher)
        "skewness": float(scipy.stats.skew(pv)),
        "npixels":  int(n),
    }


# ── cross-covariance with Bartlett CI ─────────────────────────────────────────

def _sample_acf(x: np.ndarray, max_lag: int) -> np.ndarray:
    """
    Sample autocorrelation r(1), r(2), ..., r(max_lag) for a zero-mean
    1-D array x.  Returns an array of length max_lag.
    """
    n  = len(x)
    c0 = float(np.dot(x, x)) / n
    if c0 == 0:
        return np.zeros(max_lag)
    acf = np.array([
        float(np.dot(x[:n - h], x[h:])) / (n * c0)
        for h in range(1, max_lag + 1)
    ])
    return acf


def cross_covariance_bartlett(
        x: np.ndarray,
        y: np.ndarray,
        max_lag: int,
        alpha: float = 0.05,
) -> dict:
    """
    Compute the sample normalised cross-covariance (CCF) of x and y at lags
    0, 1, ..., max_lag, where x leads y:

        CCF(h) = C_XY(h) / (σ_X · σ_Y)
        C_XY(h) = (1/(n-h)) Σ_{t=0}^{n-h-1} (x_t - x̄)(y_{t+h} - ȳ)

    Bartlett confidence interval (same width at all lags):

        SE  = (1/√n) · √(1 + 2·Σ_{j=1}^{M} r_X(j)² + 2·Σ_{j=1}^{M} r_Y(j)²)
        CI  = ±z_{α/2} · SE

    where M = min(n//2, 20) and r_X, r_Y are sample autocorrelations.
    Using this wider CI (vs naive ±2/√n) avoids declaring spurious
    significance when either series is autocorrelated.

    Parameters
    ----------
    x, y    : 1-D array-like  (NaN pairs are dropped jointly)
    max_lag : highest lag to compute
    alpha   : significance level (default 0.05 → 95 % CI)

    Returns
    -------
    dict with keys:
        lags        np.ndarray shape (max_lag+1,)
        ccf         np.ndarray CCF values
        ci_upper    float  +CI bound (symmetric)
        ci_lower    float  -CI bound
        se          float  Bartlett standard error
        best_lag    int    lag with highest |CCF|
        best_ccf    float  CCF at best_lag
        significant bool   |best_ccf| > ci_upper
    """
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)

    # drop NaN pairs
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    n = len(x)

    _nan = dict(
        lags=np.arange(max_lag + 1),
        ccf=np.full(max_lag + 1, np.nan),
        ci_upper=np.nan, ci_lower=np.nan, se=np.nan,
        best_lag=0, best_ccf=np.nan, significant=False,
    )
    if n < max_lag + 3:
        return _nan

    # demean
    xm = x - x.mean()
    ym = y - y.mean()

    sx = float(np.std(xm, ddof=1))
    sy = float(np.std(ym, ddof=1))
    if sx == 0 or sy == 0:
        return _nan

    # CCF at each lag h (x leads)
    ccf = np.array([
        float(np.dot(xm[:n - h], ym[h:])) / ((n - h) * sx * sy)
        for h in range(max_lag + 1)
    ])

    # Bartlett SE
    M     = min(n // 2, 20)
    acf_x = _sample_acf(xm, M)
    acf_y = _sample_acf(ym, M)
    se    = (1.0 / np.sqrt(n)) * np.sqrt(
        1.0 + 2.0 * float(np.sum(acf_x ** 2)) + 2.0 * float(np.sum(acf_y ** 2))
    )

    z        = float(scipy.stats.norm.ppf(1.0 - alpha / 2.0))
    ci_upper = z * se
    ci_lower = -ci_upper

    best_lag    = int(np.argmax(np.abs(ccf)))
    best_ccf    = float(ccf[best_lag])
    significant = bool(abs(best_ccf) > ci_upper)

    return dict(
        lags=np.arange(max_lag + 1),
        ccf=ccf,
        ci_upper=ci_upper,
        ci_lower=ci_lower,
        se=se,
        best_lag=best_lag,
        best_ccf=best_ccf,
        significant=significant,
    )
