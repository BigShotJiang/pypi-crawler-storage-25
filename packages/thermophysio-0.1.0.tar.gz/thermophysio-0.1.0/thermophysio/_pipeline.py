"""
thermophysio/_pipeline.py

Orchestrates the post-extraction pipeline:
    FLIR_Stats_to_CSV  →  FLIR_TimeSeries  →  FLIR_CrossROI_Analysis
                       →  FLIR_Top_Correlations
"""

import os

from .FLIR_Stats_to_CSV import build_csv
from .FLIR_TimeSeries import resample
from .FLIR_CrossROI_Analysis import analyse
from .FLIR_Top_Correlations import summarise


def run_pipeline(
    raw_dir: str,
    out_dir: str,
    dt: float = 5.0,
    features: list = None,
    max_lag: int = None,
    alpha: float = 0.05,
    top_k: int = 9,
) -> dict:
    """
    Run the full post-extraction pipeline on a completed session directory.

    Parameters
    ----------
    raw_dir      : path to the raw session dir written by an extractor run()
                   (contains session_meta.json, overlays/, pixels/)
    out_dir      : root output directory; stats.csv, stats_resampled.csv and
                   analysis/ are written here
    dt           : resampling step in seconds (default 5.0)
    features     : feature types for CCF analysis
                   (default: all 9 signal features, excluding npixels)
    max_lag      : maximum CCF lag (default n_timepoints // 3)
    alpha        : Bartlett CI significance level (default 0.05)
    top_k        : pairs in grid plot per feature (default 9)

    Returns
    -------
    dict with keys:
        raw_dir, stats_csv, resampled_csv, analysis_dir, ccf_table,
        plots_dir, leaderboard, ccf_grid
    """
    stats_csv    = os.path.join(out_dir, "stats.csv")
    resampled    = os.path.join(out_dir, "stats_resampled.csv")
    analysis_dir = os.path.join(out_dir, "analysis")
    os.makedirs(analysis_dir, exist_ok=True)

    build_csv(raw_dir, stats_csv)
    resample(stats_csv, resampled, dt=dt)
    ccf_table = analyse(
        resampled, analysis_dir,
        features=features,
        max_lag=max_lag,
        alpha=alpha,
        top_k=top_k,
    )

    summary_paths = summarise(
        ccf_table, resampled, analysis_dir,
        max_lag=max_lag,
        alpha=alpha,
    )

    return {
        "raw_dir":       raw_dir,
        "stats_csv":     stats_csv,
        "resampled_csv": resampled,
        "analysis_dir":  analysis_dir,
        "ccf_table":     ccf_table,
        "plots_dir":     os.path.join(analysis_dir, "plots"),
        "leaderboard":   summary_paths.get("leaderboard") if summary_paths else None,
        "ccf_grid":      summary_paths.get("ccf_grid")    if summary_paths else None,
    }