#!/usr/bin/env python3
"""
FLIR_Delta_Analysis.py

Standalone alternative analysis tool (Pearson delta). Not part of the main
pipeline. Use FLIR_CrossROI_Analysis.py for the standard Bartlett-corrected
CCF pipeline.

Takes the CSV output of FLIR_Stats_to_CSV.py and produces a three-section
analysis CSV:

  SECTION 1 — Delta time series
      C(n,2) rows: one per region pair, value = region_A_mean − region_B_mean
      at each timepoint.

  SECTION 2 — Z-score normalised delta series
      Same pairs, each series standardised to zero mean and unit variance.

  SECTION 3 — Pearson cross-correlation vs positive lag
      (only computed when the reference activation signal is not constant)
      For each delta series: Pearson r and p-value at lags 0, 1, 2, … max_lag,
      where lag k means the delta series is shifted k timepoints later than the
      reference (the reference leads — the only direction that makes physical
      sense).
      Extra columns: best_lag, best_r, best_p.

Usage:
    python FLIR_Delta_Analysis.py <stats.csv> [out.csv] [--max-lag N]

    <stats.csv>   output of FLIR_Stats_to_CSV.py
    out.csv       optional output path
                  (default: same directory, name derived from input)
    --max-lag N   maximum lag to test  (default: n_timepoints // 3)
"""

import os
import sys
import csv
import argparse
import itertools
import math
import numpy as np
from scipy import stats as sp_stats

from .shared_utils import _safe_float, _fmt  # noqa: E402


# ── I/O helpers ───────────────────────────────────────────────────────────────

def read_stats_csv(path: str):
    """
    Parse the features×time CSV produced by FLIR_Stats_to_CSV.py.

    Returns:
        col_labels  : list[str]   — timepoint labels (columns after 'feature')
        elapsed_s   : np.ndarray  — elapsed time in seconds per timepoint
        region_mean : dict[str, np.ndarray]  — {region_name: mean temp series}
        reference   : np.ndarray  — reference_activation series (+1 / -1)
    """
    with open(path, newline="") as f:
        reader = csv.reader(f)
        rows = list(reader)

    if not rows:
        sys.exit(f"ERROR: '{path}' is empty")

    header     = rows[0]
    col_labels = header[1:]          # drop 'feature' column

    region_mean = {}
    elapsed_s   = None
    reference   = None

    for row in rows[1:]:
        if len(row) < 2:
            continue
        key    = row[0].strip()
        values = np.array([_safe_float(v) for v in row[1:]])

        if key == "elapsed_s":
            elapsed_s = values
        elif key == "reference_activation":
            reference = values
        elif key.endswith("_mean"):
            rname = key[: -len("_mean")]
            region_mean[rname] = values

    if elapsed_s is None:
        sys.exit("ERROR: 'elapsed_s' row not found in CSV")
    if reference is None:
        sys.exit("ERROR: 'reference_activation' row not found in CSV")
    if not region_mean:
        sys.exit("ERROR: no '*_mean' rows found in CSV")

    return col_labels, elapsed_s, region_mean, reference



# ── analysis ──────────────────────────────────────────────────────────────────

def zscore(arr: np.ndarray) -> np.ndarray:
    """Z-score a 1-D array; returns array of NaNs if std == 0."""
    mu  = np.nanmean(arr)
    std = np.nanstd(arr, ddof=1)
    if std == 0 or not np.isfinite(std):
        return np.full_like(arr, float("nan"))
    return (arr - mu) / std


def pearson_at_lag(x: np.ndarray, y: np.ndarray, lag: int):
    """
    Pearson r between x[0:n-lag] and y[lag:n].
    x leads (reference), y follows (delta).
    Returns (r, p) or (nan, nan) if insufficient data.
    """
    n = len(x)
    if lag >= n - 2:
        return float("nan"), float("nan")
    x_cut = x[: n - lag]
    y_cut = y[lag:]
    # drop any timepoints where either series is NaN
    mask = np.isfinite(x_cut) & np.isfinite(y_cut)
    if mask.sum() < 3:
        return float("nan"), float("nan")
    r, p = sp_stats.pearsonr(x_cut[mask], y_cut[mask])
    return float(r), float(p)


# ── CSV writer ────────────────────────────────────────────────────────────────

def _section_header(title: str, col_labels: list) -> list:
    return [title] + [""] * len(col_labels)


def write_analysis_csv(out_path: str,
                       col_labels: list,
                       delta_series: dict,
                       delta_z:      dict,
                       ref_constant: bool,
                       corr_results: dict,
                       max_lag:      int):
    """
    Write the three-section output CSV.

    delta_series / delta_z : {pair_name: np.ndarray}
    corr_results           : {pair_name: [(r, p) for lag 0..max_lag]}
    """
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)

    with open(out_path, "w", newline="") as f:
        w = csv.writer(f)

        # ── Section 1: raw delta series ─────────────────────────────────────
        w.writerow(_section_header("# SECTION 1 — DELTA SERIES (region_A_mean - region_B_mean)", col_labels))
        w.writerow(["feature"] + col_labels)
        for pname, series in delta_series.items():
            w.writerow([pname] + [_fmt(v) for v in series])
        w.writerow([])   # blank separator

        # ── Section 2: z-scored delta series ────────────────────────────────
        w.writerow(_section_header("# SECTION 2 — Z-SCORE NORMALISED DELTA SERIES", col_labels))
        w.writerow(["feature"] + col_labels)
        for pname, series in delta_z.items():
            w.writerow([pname] + [_fmt(v) for v in series])
        w.writerow([])

        # ── Section 3: Pearson correlation vs positive lag ───────────────────
        if ref_constant:
            w.writerow(["# SECTION 3 — PEARSON CORRELATION SKIPPED"
                        " (reference activation signal is constant)"])
        else:
            lag_cols = [f"lag_{k}" for k in range(max_lag + 1)]
            w.writerow(_section_header(
                "# SECTION 3 — PEARSON r vs POSITIVE LAG (reference leads, delta follows)",
                lag_cols + ["best_lag", "best_r", "best_p"]))
            w.writerow(["feature"] + lag_cols + ["best_lag", "best_r", "best_p"])

            for pname, lag_rp in corr_results.items():
                r_values = [rp[0] for rp in lag_rp]
                p_values = [rp[1] for rp in lag_rp]

                # best lag = index of highest absolute r among finite values
                finite_mask = [math.isfinite(r) for r in r_values]
                if any(finite_mask):
                    best_lag = max(
                        (k for k in range(len(r_values)) if finite_mask[k]),
                        key=lambda k: abs(r_values[k]))
                    best_r = r_values[best_lag]
                    best_p = p_values[best_lag]
                else:
                    best_lag, best_r, best_p = "", "", ""

                row = ([pname]
                       + [_fmt(r) for r in r_values]
                       + [best_lag, _fmt(best_r), _fmt(best_p)])
                w.writerow(row)


# ── main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="FLIR pairwise delta analysis")
    ap.add_argument("stats_csv",  help="CSV from FLIR_Stats_to_CSV.py")
    ap.add_argument("out_csv",    nargs="?", default=None,
                    help="Output CSV path (default: <stats_csv dir>/<stem>_deltas.csv)")
    ap.add_argument("--max-lag",  type=int, default=None,
                    help="Maximum lag to test in Pearson analysis (default: n//3)")
    args = ap.parse_args()

    if not os.path.isfile(args.stats_csv):
        sys.exit(f"ERROR: '{args.stats_csv}' not found")

    # default output path
    if args.out_csv is None:
        base  = os.path.splitext(args.stats_csv)[0]
        args.out_csv = base + "_deltas.csv"

    # ── load ────────────────────────────────────────────────────────────────
    col_labels, elapsed_s, region_mean, reference = read_stats_csv(args.stats_csv)
    n_tp      = len(col_labels)
    regions   = list(region_mean.keys())
    n_regions = len(regions)
    n_pairs   = n_regions * (n_regions - 1) // 2

    print(f"Timepoints   : {n_tp}")
    print(f"Regions      : {n_regions}  ({', '.join(regions)})")
    print(f"Pairs C(n,2) : {n_pairs}")

    max_lag = args.max_lag if args.max_lag is not None else max(1, n_tp // 3)
    print(f"Max lag      : {max_lag}")

    # ── reference signal check ───────────────────────────────────────────────
    ref_unique    = np.unique(reference[np.isfinite(reference)])
    ref_constant  = len(ref_unique) <= 1
    if ref_constant:
        print("Reference    : CONSTANT — Pearson correlation section will be skipped")
    else:
        print(f"Reference    : {int(np.sum(reference > 0))} active (+1), "
              f"{int(np.sum(reference < 0))} baseline (-1)")

    ref_z = zscore(reference)

    # ── compute delta series ─────────────────────────────────────────────────
    delta_series = {}
    delta_z      = {}

    for r_a, r_b in itertools.combinations(regions, 2):
        pname              = f"{r_a}_vs_{r_b}"
        delta              = region_mean[r_a] - region_mean[r_b]
        delta_series[pname] = delta
        delta_z[pname]      = zscore(delta)

    print(f"Delta series : {len(delta_series)} computed")

    # ── Pearson correlation vs positive lag ──────────────────────────────────
    corr_results = {}
    if not ref_constant:
        for pname, dz in delta_z.items():
            corr_results[pname] = [pearson_at_lag(ref_z, dz, k)
                                   for k in range(max_lag + 1)]
        print(f"Pearson lags : 0 … {max_lag} computed for {len(corr_results)} pairs")

    # ── write output ─────────────────────────────────────────────────────────
    write_analysis_csv(args.out_csv, col_labels, delta_series, delta_z,
                       ref_constant, corr_results, max_lag)

    print(f"\nOutput       : {args.out_csv}")


if __name__ == "__main__":
    main()
