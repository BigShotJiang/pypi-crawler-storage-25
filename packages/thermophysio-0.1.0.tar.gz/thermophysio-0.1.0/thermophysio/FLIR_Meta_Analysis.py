"""
FLIR_Meta_Analysis.py
=====================
Meta-analyse CCF results across multiple runs of the same experiment type.

For each (feature × region-pair) combination, applies Fisher's r-to-z transform
across runs and computes the mean correlation with a between-run confidence
interval.  A pair that reaches a high |CCF| in only one run will have a wide CI;
a pair that is consistently correlated across all runs will have a narrow CI that
excludes zero.

Usage
-----
    python FLIR_Meta_Analysis.py table1.csv table2.csv [table3.csv ...]
           --out out_dir
           [--label "Faces"]
           [--top-n 10]
           [--alpha 0.05]
           [--min-runs 1]

Arguments
---------
    ccf_tables  one or more ccf_table.csv files (one per run),
                produced by FLIR_CrossROI_Analysis.analyse()
    --out       output directory for the two output images
    --label     experiment type label used in plot titles (e.g. "Faces")
    --top-n     how many top pairs to display (default: 10)
    --alpha     CI significance level (default: 0.05)
    --min-runs  minimum number of runs in which a pair must appear
                to be eligible (default: 1)

Outputs
-------
    top{N}_{label}_leaderboard.png   ranked bar chart with between-run CI
    top{N}_{label}_table.png         styled table image of the ranking
    {label}_ccf_report.md            full AI-readable report of all pairs
"""

import os
import sys
import csv
import math
import argparse
import datetime

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from scipy.stats import norm as _norm

from .shared_utils import _safe_float  # noqa: E402


# ── data loading ──────────────────────────────────────────────────────────────

def _load_ccf_table(path):
    """Read one ccf_table.csv → list of dicts with parsed numeric fields."""
    rows = []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            bcf = _safe_float(row.get("best_ccf", ""))
            if not math.isfinite(bcf):
                continue
            rows.append({
                "feature":  row["feature"].strip(),
                "pair":     row["pair"].strip(),
                "best_ccf": bcf,
            })
    return rows


# ── Fisher r→z meta-analysis ─────────────────────────────────────────────────

def _fisher_meta(r_values, alpha=0.05):
    """
    Fisher r-to-z meta-analysis across k runs.

    Uses between-run variance (std of z_i / sqrt(k)) as the SE so that a pair
    that correlates highly in only one run will have a wide CI, while a pair
    that is consistently correlated across all runs will have a narrow CI.

    Returns dict:
        r_bar      : back-transformed mean correlation
        k          : number of runs
        ci_lower   : lower CI on r  (None when k < 2)
        ci_upper   : upper CI on r  (None when k < 2)
        consistent : True if CI excludes 0, False if not, None when k < 2
    """
    # Clamp to avoid atanh(±1) = ±inf
    z_vals = [math.atanh(max(-0.9999, min(0.9999, r))) for r in r_values]
    k = len(z_vals)
    mean_z = float(np.mean(z_vals))
    r_bar  = math.tanh(mean_z)

    if k < 2:
        return dict(r_bar=r_bar, k=k,
                    ci_lower=None, ci_upper=None, consistent=None)

    se_z   = float(np.std(z_vals, ddof=1)) / math.sqrt(k)
    z_crit = float(_norm.ppf(1.0 - alpha / 2.0))
    ci_lo  = math.tanh(mean_z - z_crit * se_z)
    ci_hi  = math.tanh(mean_z + z_crit * se_z)
    consistent = ci_lo > 0 or ci_hi < 0   # CI does not straddle zero

    return dict(r_bar=r_bar, k=k,
                ci_lower=ci_lo, ci_upper=ci_hi, consistent=consistent)


# ── aggregation ───────────────────────────────────────────────────────────────

def _aggregate(tables, min_runs, alpha):
    """
    Combine all ccf_table rows across runs, compute Fisher meta per pair,
    return list sorted by abs(r_bar) descending.
    Each result dict includes 'r_values' — the raw per-run best_ccf list.
    """
    collected = {}
    for rows in tables:
        for row in rows:
            key = (row["feature"], row["pair"])
            collected.setdefault(key, []).append(row["best_ccf"])

    results = []
    for (feat, pair), r_vals in collected.items():
        if len(r_vals) < min_runs:
            continue
        meta = _fisher_meta(r_vals, alpha=alpha)
        results.append({"feature": feat, "pair": pair, "r_values": r_vals, **meta})

    results.sort(key=lambda r: abs(r["r_bar"]), reverse=True)
    return results


# ── label helpers ─────────────────────────────────────────────────────────────

def _clean_pair_label(pair_str):
    """'FP_L_vs_Ear_R' → 'FP L  vs  Ear R'"""
    return pair_str.replace("_vs_", "  vs  ").replace("_", " ")


def _split_pair(pair_str):
    """'A_vs_B' → ('A', 'B') with underscores converted to spaces."""
    parts = pair_str.split("_vs_", 1)
    if len(parts) == 2:
        return parts[0].replace("_", " "), parts[1].replace("_", " ")
    return pair_str.replace("_", " "), ""


# ── Plot A: leaderboard ───────────────────────────────────────────────────────

def plot_meta_leaderboard(top_rows, out_path, label="", alpha=0.05):
    """
    Horizontal bar chart of mean CCF (signed) with between-run CI.

    Colour coding:
      green  = CI excludes 0 (consistent across runs)
      salmon = CI includes 0 (not consistently significant)
      silver = only one run available (no between-run CI)
    """
    n     = len(top_rows)
    y_pos = np.arange(n)

    r_bars = [r["r_bar"] for r in top_rows]

    xerr_lo, xerr_hi = [], []
    for r in top_rows:
        if r["ci_lower"] is not None:
            xerr_lo.append(abs(r["r_bar"] - r["ci_lower"]))
            xerr_hi.append(abs(r["ci_upper"] - r["r_bar"]))
        else:
            xerr_lo.append(0.0)
            xerr_hi.append(0.0)

    has_ci   = any(v > 0 for v in xerr_lo)
    colors   = []
    for r in top_rows:
        if r["k"] < 2:
            colors.append("silver")
        elif r["consistent"]:
            colors.append("mediumseagreen")
        else:
            colors.append("lightsalmon")

    ylabels = [f"{r['feature']}  |  {_clean_pair_label(r['pair'])}"
               for r in top_rows]

    fig, ax = plt.subplots(figsize=(11, max(5, n * 0.60)))

    bars = ax.barh(
        y_pos, r_bars,
        xerr=[xerr_lo, xerr_hi] if has_ci else None,
        color=colors, alpha=0.88,
        error_kw={"elinewidth": 1.3, "capsize": 3, "ecolor": "dimgrey"},
    )

    for bar, row, eh in zip(bars, top_rows, xerr_hi):
        ann_parts = [f"k={row['k']}"]
        if row["consistent"] is True:
            ann_parts.append("★")
        elif row["consistent"] is None:
            ann_parts.append("(1 run)")
        ann   = "  ".join(ann_parts)
        x_end = bar.get_width()
        sign  = 1 if x_end >= 0 else -1
        ax.text(x_end + sign * (eh + 0.03),
                bar.get_y() + bar.get_height() / 2,
                ann, va="center", fontsize=7.5,
                ha="left" if sign > 0 else "right")

    ax.set_yticks(y_pos)
    ax.set_yticklabels(ylabels, fontsize=8.5)
    ax.invert_yaxis()
    ax.axvline(0, color="black", linewidth=0.9, linestyle="--", alpha=0.55)
    ax.set_xlim(-1.25, 1.25)
    ax.set_xlabel("Mean CCF  r̄  (Fisher z-transformed, ★ = consistent across runs)",
                  fontsize=9.5)

    ci_pct = int(round((1 - alpha) * 100))
    title  = f"Top Correlated Feature–Region Pairs"
    if label:
        title += f"  —  {label}"
    ax.set_title(title, fontsize=12, fontweight="bold")

    legend_patches = [
        mpatches.Patch(color="mediumseagreen",
                       label=f"Consistent  ({ci_pct}% CI excludes 0)"),
        mpatches.Patch(color="lightsalmon",
                       label="Not consistent  (CI includes 0)"),
        mpatches.Patch(color="silver",
                       label="Single run  (no between-run CI)"),
    ]
    ax.legend(handles=legend_patches, fontsize=8, loc="lower right")

    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


# ── Plot B: table image ───────────────────────────────────────────────────────

def plot_meta_table(top_rows, out_path, label="", alpha=0.05):
    """Render the ranking as a styled PNG table."""
    ci_pct = int(round((1 - alpha) * 100))

    col_headers = [
        "Rank", "Feature", "Region A", "Region B",
        "r̄", f"CI {ci_pct}% lower", f"CI {ci_pct}% upper",
        "Runs (k)", "Consistent?",
    ]

    cell_data   = []
    cell_colors = []
    for i, r in enumerate(top_rows):
        ra, rb  = _split_pair(r["pair"])
        ci_lo   = f"{r['ci_lower']:.3f}"  if r["ci_lower"]  is not None else "—"
        ci_hi   = f"{r['ci_upper']:.3f}"  if r["ci_upper"]  is not None else "—"
        if r["consistent"] is True:
            cons_txt = "Yes  ★"
        elif r["consistent"] is False:
            cons_txt = "No"
        else:
            cons_txt = "N/A"

        cell_data.append([
            f"#{i+1}", r["feature"], ra, rb,
            f"{r['r_bar']:+.3f}", ci_lo, ci_hi,
            str(r["k"]), cons_txt,
        ])

        base  = "#f0f0f0" if i % 2 == 0 else "#ffffff"
        ccons = "#c8e6c9" if r["consistent"] is True else (
                "#ffccbc" if r["consistent"] is False else "#eeeeee")
        cell_colors.append([base] * 8 + [ccons])

    n_cols = len(col_headers)
    fig_h  = 1.2 + len(cell_data) * 0.48
    fig, ax = plt.subplots(figsize=(15, fig_h))
    ax.set_axis_off()

    title = "Feature–Region Pair Rankings"
    if label:
        title += f"  —  {label}"
    fig.suptitle(title, fontsize=12, fontweight="bold", y=0.98)

    tbl = ax.table(
        cellText=cell_data,
        colLabels=col_headers,
        cellColours=cell_colors,
        loc="center",
        cellLoc="center",
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(9)
    tbl.scale(1, 1.7)
    tbl.auto_set_column_width(list(range(n_cols)))

    header_bg = "#2c3e50"
    for j in range(n_cols):
        cell = tbl[0, j]
        cell.set_facecolor(header_bg)
        cell.set_text_props(color="white", fontweight="bold")

    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


# ── markdown report ───────────────────────────────────────────────────────────

def _write_markdown(results, out_path, label, alpha, run_paths, min_runs):
    """
    Write a full AI-readable markdown report of all (feature × pair) results.

    Structure
    ---------
    - Metadata block (YAML-style) for machine parsing
    - Human summary
    - Source runs list
    - Interpretation key
    - Full ranked table of ALL pairs with per-run values
    - Consistent-pairs section (CI excludes 0)
    - Not-consistent section
    """
    ci_pct       = int(round((1 - alpha) * 100))
    n_total      = len(results)
    n_consistent = sum(1 for r in results if r["consistent"] is True)
    n_not        = sum(1 for r in results if r["consistent"] is False)
    n_single     = sum(1 for r in results if r["consistent"] is None)
    top1         = results[0] if results else None
    generated    = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    # Short run labels: basename of parent dir of each ccf_table.csv
    run_labels = []
    for p in run_paths:
        parts = os.path.normpath(p).split(os.sep)
        # walk up to find the experiment-level dir (e.g. Exp01-Faces)
        label_candidate = next(
            (part for part in reversed(parts)
             if part.startswith("Exp") or part not in ("analysis", "ccf_table.csv")),
            os.path.basename(os.path.dirname(p))
        )
        run_labels.append(label_candidate)

    def fmt_r(v):
        return f"{v:+.4f}" if v is not None else "—"

    def fmt_ci(lo, hi):
        if lo is None or hi is None:
            return "— (single run)"
        return f"[{lo:+.4f}, {hi:+.4f}]"

    def cons_str(r):
        if r["consistent"] is True:
            return "YES"
        if r["consistent"] is False:
            return "NO"
        return "N/A (k=1)"

    lines = []

    # ── metadata block ────────────────────────────────────────────────────────
    lines += [
        f"# CCF Meta-Analysis Report — {label or 'Experiment'}",
        "",
        "```yaml",
        f"generated:        {generated}",
        f"experiment_label: {label or 'unspecified'}",
        f"runs_included:    {len(run_paths)}",
        f"alpha:            {alpha}",
        f"ci_level:         {ci_pct}%",
        f"min_runs_filter:  {min_runs}",
        f"total_pairs:      {n_total}",
        f"consistent_pairs: {n_consistent}",
        f"not_consistent:   {n_not}",
        f"single_run_only:  {n_single}",
        "```",
        "",
    ]

    # ── human summary ─────────────────────────────────────────────────────────
    lines += ["## Summary", ""]
    if top1:
        ra, rb = _split_pair(top1["pair"])
        lines.append(
            f"The strongest mean correlation across all {len(run_paths)} runs is "
            f"**{top1['feature']}** between **{ra}** and **{rb}** "
            f"(r̄ = {top1['r_bar']:+.3f}, {ci_pct}% CI {fmt_ci(top1['ci_lower'], top1['ci_upper'])})."
        )
    lines += [
        "",
        f"- **{n_consistent}** of {n_total} feature–pair combinations are "
        f"*consistent* across runs ({ci_pct}% CI excludes 0).",
        f"- **{n_not}** are present in ≥2 runs but the CI includes 0 "
        f"(correlation may be noise or session-dependent).",
        f"- **{n_single}** appear in only one run (no between-run CI available).",
        "",
    ]

    # ── source runs ───────────────────────────────────────────────────────────
    lines += ["## Source Runs", ""]
    lines += [f"| # | Label | Path |", "|---|---|---|"]
    for i, (lbl, path) in enumerate(zip(run_labels, run_paths), 1):
        lines.append(f"| {i} | {lbl} | `{path}` |")
    lines += [""]

    # ── interpretation key ────────────────────────────────────────────────────
    lines += [
        "## Interpretation Key",
        "",
        "| Column | Meaning |",
        "|---|---|",
        "| `r_bar` | Fisher z-transformed mean correlation across runs (signed) |",
        f"| `ci_lower` / `ci_upper` | {ci_pct}% between-run confidence interval on r̄ |",
        "| `k` | Number of runs contributing this pair |",
        "| `consistent` | YES = CI excludes 0 (effect replicated); NO = CI straddles 0 |",
        "| `run_values` | Raw best_ccf from each individual run (in source-run order) |",
        "",
        "> **Note on `best_ccf`:** Each run's value is the *peak* absolute CCF across all",
        "> tested lags, not a fixed-lag measurement. The Fisher meta-analysis accounts for",
        "> between-run variability; a wide CI means the peak correlation is inconsistent",
        "> across sessions even if it looks large in a single run.",
        "",
    ]

    # ── run-value header for the tables ───────────────────────────────────────
    run_cols  = " | ".join(run_labels)
    sep_runs  = "|".join(["---"] * len(run_labels))
    tbl_header = (
        f"| Rank | Feature | Region A | Region B | r̄ | CI {ci_pct}% | "
        f"k | Consistent | {run_cols} |"
    )
    tbl_sep = f"|---|---|---|---|---|---|---|---|{sep_runs}|"

    def pair_row(i, r):
        ra, rb = _split_pair(r["pair"])
        rv = " | ".join(f"{v:+.3f}" for v in r["r_values"])
        return (
            f"| {i} | {r['feature']} | {ra} | {rb} | "
            f"{fmt_r(r['r_bar'])} | {fmt_ci(r['ci_lower'], r['ci_upper'])} | "
            f"{r['k']} | {cons_str(r)} | {rv} |"
        )

    # ── consistent pairs ──────────────────────────────────────────────────────
    consistent_rows = [r for r in results if r["consistent"] is True]
    lines += [
        f"## Consistent Pairs  ({n_consistent} pairs, {ci_pct}% CI excludes 0)",
        "",
        "_These combinations replicate across sessions. Prioritise for further analysis._",
        "",
        tbl_header, tbl_sep,
    ]
    rank = 1
    for r in consistent_rows:
        lines.append(pair_row(rank, r))
        rank += 1
    lines += [""]

    # ── not consistent ────────────────────────────────────────────────────────
    not_consistent_rows = [r for r in results if r["consistent"] is False]
    lines += [
        f"## Not Consistent  ({n_not} pairs, CI includes 0)",
        "",
        "_Present in ≥2 runs but correlation is not reliably above noise across sessions._",
        "",
        tbl_header, tbl_sep,
    ]
    for r in not_consistent_rows:
        lines.append(pair_row(rank, r))
        rank += 1
    lines += [""]

    # ── single run ────────────────────────────────────────────────────────────
    if n_single:
        single_rows = [r for r in results if r["consistent"] is None]
        lines += [
            f"## Single-Run Pairs  ({n_single} pairs, no between-run CI)",
            "",
            "_Only one run contributed this pair. Treat as exploratory only._",
            "",
            tbl_header, tbl_sep,
        ]
        for r in single_rows:
            lines.append(pair_row(rank, r))
            rank += 1
        lines += [""]

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


# ── public API ────────────────────────────────────────────────────────────────

def meta_analyse(ccf_table_paths, out_dir, top_n=10, label="",
                 alpha=0.05, min_runs=1):
    """
    Meta-analyse CCF results across multiple runs of the same experiment type.

    Parameters
    ----------
    ccf_table_paths : list of paths to ccf_table.csv files (one per run)
    out_dir         : directory for output images
    top_n           : number of top pairs to display (default 10)
    label           : experiment-type name used in titles (e.g. "Faces")
    alpha           : CI significance level (default 0.05)
    min_runs        : minimum runs a pair must appear in to be included (default 1)

    Returns
    -------
    dict with 'leaderboard', 'table_image', and 'md_report' paths, or None on failure.
    """
    tables = []
    for path in ccf_table_paths:
        if not os.path.isfile(path):
            print(f"[Meta] WARNING: '{path}' not found — skipping.")
            continue
        rows = _load_ccf_table(path)
        if not rows:
            print(f"[Meta] WARNING: '{path}' is empty — skipping.")
            continue
        tables.append(rows)
        print(f"[Meta] Loaded  {len(rows):4d} pairs  ← {path}")

    if not tables:
        print("[Meta] ERROR: No valid ccf_table.csv files loaded.")
        return None

    results = _aggregate(tables, min_runs=min_runs, alpha=alpha)
    if not results:
        print(f"[Meta] No pairs met the min-runs threshold (--min-runs {min_runs}).")
        return None

    top_rows = results[:top_n]
    os.makedirs(out_dir, exist_ok=True)

    lbl_slug         = label.replace(" ", "_") if label else "meta"
    leaderboard_path = os.path.join(out_dir, f"top{top_n}_{lbl_slug}_leaderboard.png")
    table_path       = os.path.join(out_dir, f"top{top_n}_{lbl_slug}_table.png")
    md_path          = os.path.join(out_dir, f"{lbl_slug}_ccf_report.md")

    plot_meta_leaderboard(top_rows, leaderboard_path, label=label, alpha=alpha)
    plot_meta_table(top_rows, table_path, label=label, alpha=alpha)
    _write_markdown(results, md_path, label=label, alpha=alpha,
                    run_paths=ccf_table_paths, min_runs=min_runs)

    ci_pct       = int(round((1 - alpha) * 100))
    n_consistent = sum(1 for r in results if r["consistent"] is True)
    n_single     = sum(1 for r in results if r["k"] < 2)

    print(f"\n[Meta] Experiment      : {label or '(unspecified)'}")
    print(f"[Meta] Runs loaded     : {len(tables)}")
    print(f"[Meta] Total pairs     : {len(results)}")
    print(f"[Meta] Consistent      : {n_consistent} / {len(results)}  ({ci_pct}% CI excludes 0)")
    if n_single:
        print(f"[Meta] Single-run      : {n_single}  (no between-run CI)")
    print(f"[Meta] Leaderboard     : {leaderboard_path}")
    print(f"[Meta] Table image     : {table_path}")
    print(f"[Meta] MD report       : {md_path}")

    return {"leaderboard": leaderboard_path, "table_image": table_path,
            "md_report": md_path}


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description=(
            "Meta-analyse CCF results across multiple runs of the same "
            "experiment type using Fisher r-to-z meta-analysis."
        )
    )
    ap.add_argument("ccf_tables", nargs="+", metavar="ccf_table.csv",
                    help="One or more ccf_table.csv files (one per run)")
    ap.add_argument("--out", required=True, metavar="DIR",
                    help="Output directory for images")
    ap.add_argument("--label", default="",
                    help="Experiment type label for titles  (e.g. 'Faces')")
    ap.add_argument("--top-n", type=int, default=10, metavar="N",
                    help="Number of top pairs to display  (default: 10)")
    ap.add_argument("--alpha", type=float, default=0.05,
                    help="CI significance level  (default: 0.05)")
    ap.add_argument("--min-runs", type=int, default=1, metavar="K",
                    help="Minimum runs a pair must appear in  (default: 1)")
    args = ap.parse_args()

    meta_analyse(
        args.ccf_tables, args.out,
        top_n=args.top_n, label=args.label,
        alpha=args.alpha, min_runs=args.min_runs,
    )


if __name__ == "__main__":
    main()
