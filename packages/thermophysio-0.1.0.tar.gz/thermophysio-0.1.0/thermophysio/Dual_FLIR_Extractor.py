#!/usr/bin/env python3
"""
Dual_FLIR_Extractor.py

Dual-camera FLIR analyser using the dual oblique-basis profile mesh system.
Coordinate system:  pixel = eye + u*A + v*B
    A = ear  − eye   (L × ê_ear,  eye-ear  axis, posterior scale unit)
    B = nose − eye   (D × ê_nose, eye-nose axis, anterior  scale unit)

Region names in the CSV carry a side suffix: -L for the left-profile camera,
-R for the right-profile camera.
"""

import os
import sys
import argparse
import tkinter as tk
from datetime import datetime, timedelta

import cv2
import numpy as np

from PIL import Image
import flyr

from .shared_utils import (get_capture_time, get_polygon_values,
                          _save_overlay, _save_pixels, _write_meta)

try:
    from ultralytics import YOLO as _YOLO
    _YOLO_OK = True
except ImportError:
    _YOLO_OK = False
    print("[WARN] ultralytics not installed -- run: pip install ultralytics")

try:
    import torch as _torch
    _CUDA = _torch.cuda.is_available()
except ImportError:
    _CUDA = False


_YOLO_KP_NAMES = [
    "Nose", "L-Eye", "R-Eye", "L-Ear", "R-Ear",
    "L-Sh", "R-Sh", "L-Elbow", "R-Elbow",
    "L-Wrist", "R-Wrist", "L-Hip", "R-Hip",
    "L-Knee", "R-Knee", "L-Ankle", "R-Ankle",
]


# ── ROI mesh — populated at runtime by run() via load_mesh("dual") ────────────
PROFILE_ANCHORS     = None   # OrderedDict set by run() on first call
PROFILE_REGION_DEFS = None   # OrderedDict set by run() on first call


# ══════════════════════════════════════════════════════════════════════════════
#  DUAL OBLIQUE BASIS GEOMETRY
# ══════════════════════════════════════════════════════════════════════════════

def _build_profile_basis(eye, ear, nose):
    """
    Build the dual oblique basis from three YOLO landmarks.

    Returns (origin, A, B, det) where
        origin  = eye pixel position (np.array [x, y])
        A       = ear  − eye  (L × ê_ear,  posterior basis vector)
        B       = nose − eye  (D × ê_nose, anterior  basis vector)
        det     = A.x*B.y − A.y*B.x  (for 2×2 oblique inversion)

    If nose is None (YOLO didn't detect it), B is estimated as the vector
    90° clockwise from A scaled to 0.6×L — this places a synthetic nose
    roughly below-forward of the eye in a typical profile orientation.
    The mesh still renders; the user can correct the nose with N+click.
    """
    origin = np.array([float(eye[0]),  float(eye[1])])
    ear_   = np.array([float(ear[0]),  float(ear[1])])
    A      = ear_ - origin   # eye→ear vector

    if nose is not None:
        nose_ = np.array([float(nose[0]), float(nose[1])])
        B = nose_ - origin
    else:
        # 90° clockwise rotation of A, scaled to 0.6×L
        # In image coords (y down): CW rotation = (dy, -dx)
        L = max(float(np.hypot(*A)), 1.0)
        e = A / L
        B = np.array([e[1], -e[0]]) * L * 0.6

    det = float(A[0] * B[1] - A[1] * B[0])
    return origin, A, B, det


def _pixel_delta_to_oblique(delta_px, A, B, det):
    """
    Convert a pixel offset into oblique (du, dv) fractions.

    delta_px : np.array [dx, dy]  — pixel displacement from default position
    Returns (du, dv) where the corrected pixel = default + du*A + dv*B
    """
    if abs(det) < 1e-6:
        return 0.0, 0.0
    du = (delta_px[0] * B[1] - delta_px[1] * B[0]) / det
    dv = (A[0] * delta_px[1] - A[1] * delta_px[0]) / det
    return float(du), float(dv)


def compute_anchor_pixels(eye, ear, nose, offsets=None):
    """
    Compute pixel positions for all PROFILE_ANCHORS.

    Parameters
    ----------
    eye, ear, nose : array-like [x, y]  — YOLO keypoint pixel coords.
    offsets        : dict {name: (du, dv)}
        Fine-tune offsets in fractions of L (du) and D (dv).
        Compatible with ref_offsets / tgt_offsets dicts.

    Returns
    -------
    dict {anchor_name: np.ndarray([x, y], float)}
    """
    origin, A, B, det = _build_profile_basis(eye, ear, nose)
    offsets = offsets or {}
    result  = {}
    for name, a in PROFILE_ANCHORS.items():
        du, dv = offsets.get(name, (0.0, 0.0))
        result[name] = origin + (a['u'] + du) * A + (a['v'] + dv) * B
    return result


def build_region_polys(anchor_px):
    """
    Build closed int32 polygon arrays for all PROFILE_REGION_DEFS.
    Returns dict {region_name: np.int32 polygon}.
    """
    polys = {}
    for rname, defn in PROFILE_REGION_DEFS.items():
        pts = []
        ok  = True
        for name in defn['poly']:
            if name not in anchor_px:
                ok = False; break
            pts.append(anchor_px[name].astype(float))
        if ok and len(pts) >= 3:
            polys[rname] = np.array(pts, dtype=np.int32)
    return polys


def draw_regions(base_bgr, anchor_px, side_suffix):
    """
    Draw profile ROIs on *base_bgr*.

    Parameters
    ----------
    base_bgr    : uint8 BGR image
    anchor_px   : output of compute_anchor_pixels()
    side_suffix : '-L' or '-R' — appended to every region name in the
                  returned dict (used in CSV output) and in the overlay label.

    Returns
    -------
    (annotated_bgr, regions_dict)
    regions_dict : {region_name + side_suffix: np.int32 polygon}
                   — drop-in for get_polygon_values()
    """
    canvas  = base_bgr.copy()
    regions = {}
    for rname, poly in build_region_polys(anchor_px).items():
        defn    = PROFILE_REGION_DEFS.get(rname, {})
        color   = defn.get('color', (128, 128, 128))
        alpha   = defn.get('alpha', 0.40)
        overlay = canvas.copy()
        cv2.fillPoly(overlay, [poly.reshape(-1, 1, 2)], color)
        cv2.addWeighted(overlay, alpha, canvas, 1 - alpha, 0, canvas)
        cv2.polylines(canvas, [poly.reshape(-1, 1, 2)], True, color, 2, cv2.LINE_AA)
        ctr = poly.mean(axis=0).astype(int)
        lbl = rname + side_suffix
        cv2.putText(canvas, lbl, tuple(ctr),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.36, (0, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(canvas, lbl, tuple(ctr),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.36, color, 1, cv2.LINE_AA)
        regions[lbl] = poly
    return canvas, regions


# ══════════════════════════════════════════════════════════════════════════════
#  POLYGON / THERMAL UTILITIES
# ══════════════════════════════════════════════════════════════════════════════

def _draw_poly(canvas, poly, color, alpha, label=None):
    overlay = canvas.copy()
    cv2.fillPoly(overlay, [poly.reshape(-1, 1, 2)], color)
    cv2.addWeighted(overlay, alpha, canvas, 1 - alpha, 0, canvas)
    cv2.polylines(canvas, [poly.reshape(-1, 1, 2)], True, color, 2, cv2.LINE_AA)
    if label:
        c = poly.mean(axis=0).astype(int)
        cv2.putText(canvas, label, tuple(c),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.50, (0, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(canvas, label, tuple(c),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.50, color, 1, cv2.LINE_AA)
    return canvas


# ══════════════════════════════════════════════════════════════════════════════
#  IMAGE LOADING
# ══════════════════════════════════════════════════════════════════════════════

def load_flir_thermal_and_display(path):
    """
    Load a FLIR (or plain) image and return (thermal_array, rgb_uint8).

    RGB extraction priority — tried in order until one succeeds:

        1. flyr bundle.optical — REJECTED if the returned image has the same
                                 spatial dimensions as the thermal array
                                 (colourised thermal, not a real photo).

        2. PIL Image.open() — the outer JPEG.  On DJI thermal cameras
                              (Zenmuse, H20T, XT2, etc.) this IS the
                              high-resolution visible-light photo.  Also
                              handles plain (non-thermal) reference cameras.
                              REJECTED if same resolution as thermal.

        3. bundle.optical unconditional — accepted regardless of resolution
                                          (FLIR ONE: outer JPEG is thermal-
                                          sized, so optical is the only RGB).

        4. Thermal false-colour — absolute last resort; YOLO will fail.

    For non-FLIR plain JPEGs (e.g. a regular visible-light camera on the
    reference side), flyr throws and we fall back to plain PIL.
    """
    fname = os.path.basename(path)

    thermal = None
    optical = None
    is_flir = False
    try:
        bundle  = flyr.unpack(path)
        thermal = bundle.celsius.astype(np.float32)
        optical = bundle.optical
        is_flir = True
        print(f"  [{fname}] FLIR thermal OK → {thermal.shape}  "
              f"{thermal.min():.1f}–{thermal.max():.1f} °C")
    except Exception as exc:
        print(f"  [{fname}] not FLIR or thermal read error ({exc})")

    rgb = None

    # ── Method 1: bundle.optical (DJI same-resolution rejection) ─────────
    if is_flir and optical is not None and optical.size > 0:
        th_h, th_w   = thermal.shape[:2]
        cand_h, cand_w = optical.shape[:2]
        same_res = (abs(cand_h - th_h) <= 4 and abs(cand_w - th_w) <= 4)
        if same_res:
            print(f"  [{fname}] bundle.optical same resolution as thermal "
                  f"({cand_h}×{cand_w}) — colourised thermal, skipping.")
        else:
            rgb = optical.astype(np.uint8)
            print(f"  [{fname}] RGB via bundle.optical → {rgb.shape}")

    # ── Method 2: PIL Image.open() ────────────────────────────────────────
    if rgb is None:
        try:
            candidate = np.array(Image.open(path).convert("RGB"))
            if thermal is not None:
                th_h, th_w   = thermal.shape[:2]
                cand_h, cand_w = candidate.shape[:2]
                same_res = (abs(cand_h - th_h) <= 4 and abs(cand_w - th_w) <= 4)
                if same_res:
                    print(f"  [{fname}] PIL outer JPEG same resolution as "
                          f"thermal ({cand_h}×{cand_w}) — skipping (FLIR ONE preview).")
                    candidate = None
            if candidate is not None:
                rgb = candidate
                ch_std = [round(float(rgb[:, :, c].std()), 1) for c in range(3)]
                print(f"  [{fname}] RGB via PIL Image.open() → {rgb.shape}  "
                      f"ch_std={ch_std}")
        except Exception as exc:
            print(f"  [{fname}] PIL Image.open() failed: {exc}")

    # ── Method 3: bundle.optical unconditional (FLIR ONE last attempt) ────
    if rgb is None and is_flir and optical is not None and optical.size > 0:
        rgb = optical.astype(np.uint8)
        print(f"  [{fname}] RGB via bundle.optical (unconditional) → {rgb.shape}")

    # ── Method 4: thermal false-colour ────────────────────────────────────
    if rgb is None:
        if thermal is not None:
            print(f"  [{fname}] WARNING: all RGB methods failed — "
                  f"using thermal false-colour.  YOLO will likely fail.")
            t_min = float(np.nanmin(thermal))
            t_max = float(np.nanmax(thermal))
            norm  = ((thermal - t_min) / max(t_max - t_min, 1e-6) * 255
                     ).astype(np.uint8)
            rgb = cv2.cvtColor(
                cv2.applyColorMap(norm, cv2.COLORMAP_INFERNO),
                cv2.COLOR_BGR2RGB)
        else:
            print(f"  [{fname}] ERROR: no thermal and no RGB — cannot load.")
            return None, None

    if thermal is None:
        thermal = np.zeros(rgb.shape[:2], dtype=np.float32)

    return thermal, rgb

# ══════════════════════════════════════════════════════════════════════════════
#  YOLO DETECTION
# ══════════════════════════════════════════════════════════════════════════════

def annotate_with_yolo(bgr, yolo_model):
    """
    Run YOLOv8 pose on *bgr*.  No confidence thresholds are applied —
    YOLO's best-guess positions are always used.  The user can correct
    any landmark placement interactively using the E/R/N keys.

    Auto-detects which profile is visible by comparing L vs R eye confidence.
    Returns (annotated_bgr, kps_dict) with keys 'eye', 'ear', 'nose', 'side'.
    Returns (annotated_bgr, None) only if YOLO finds no keypoints at all.
    """
    device  = "cuda" if _CUDA else "cpu"
    results = yolo_model(bgr, device=device, verbose=False)
    if not results:
        return bgr.copy(), None
    r = results[0]

    # Pick the largest bounding box when multiple people detected
    if r.boxes is not None and len(r.boxes) > 1:
        xyxy  = r.boxes.xyxy
        areas = (xyxy[:, 2] - xyxy[:, 0]) * (xyxy[:, 3] - xyxy[:, 1])
        best_idx = int(areas.argmax())
        print(f"  [YOLO] {len(r.boxes)} detections — "
              f"using largest (area={float(areas[best_idx]):.0f}px²)")
    else:
        best_idx = 0

    # Draw all detected keypoints for reference (regardless of confidence)
    base = bgr.copy()
    if r.keypoints is not None and len(r.keypoints.data) > best_idx:
        for idx, (x, y, conf) in enumerate(r.keypoints.data[best_idx].tolist()):
            if conf < 0.05:   # only skip completely zero/absent keypoints
                continue
            kn  = _YOLO_KP_NAMES[idx] if idx < len(_YOLO_KP_NAMES) else str(idx)
            col = (0, 255, 0) if conf >= 0.5 else (0, 165, 255)  # green/orange
            cv2.circle(base, (int(x), int(y)), 5, col, -1)
            cv2.putText(base, f"{kn}({conf:.2f})", (int(x) + 6, int(y) - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.34, (255, 255, 0), 1, cv2.LINE_AA)

    if r.keypoints is None or len(r.keypoints.data) <= best_idx:
        return base, None

    kp = r.keypoints.data[best_idx].tolist()
    nx, ny, nc   = kp[0]   # nose
    l_ex, l_ey, l_ec = kp[1]
    r_ex, r_ey, r_ec = kp[2]
    l_ax, l_ay, l_ac = kp[3]
    r_ax, r_ay, r_ac = kp[4]

    # Auto-detect visible profile side — pick whichever eye has higher confidence
    l_score = l_ec + l_ac
    r_score = r_ec + r_ac

    if l_ec >= r_ec:
        detected_side = "L"
        ex, ey, ec = l_ex, l_ey, l_ec
        ax, ay, ac = l_ax, l_ay, l_ac
    else:
        detected_side = "R"
        ex, ey, ec = r_ex, r_ey, r_ec
        ax, ay, ac = r_ax, r_ay, r_ac

    print(f"  [YOLO] {detected_side}-profile: "
          f"eye=({ex:.0f},{ey:.0f}) conf={ec:.2f}  "
          f"ear=({ax:.0f},{ay:.0f}) conf={ac:.2f}  "
          f"nose=({nx:.0f},{ny:.0f}) conf={nc:.2f}")

    # Always return all three landmarks — user can correct via E/R/N keys
    nose_px = (nx, ny) if nc >= 0.05 else None
    return base, {"eye": (ex, ey), "ear": (ax, ay), "nose": nose_px, "side": detected_side}

# ══════════════════════════════════════════════════════════════════════════════
#  INTERACTIVE PAIR DISPLAY
# ══════════════════════════════════════════════════════════════════════════════

class InteractivePairDisplay:
    TARGET_H = 640
    BAR_H    = 50
    INFO_H   = 36
    CTRL_H   = 46
    DIV_W    = 4
    HANDLE_R = 6
    HIT_R    = 13

    COL_DEFAULT  = (0, 220, 80)
    COL_MODIFIED = (0, 140, 255)
    COL_ACTIVE   = (0, 240, 240)
    COL_BG       = (20, 20, 20)
    BTN_COL      = (55, 55, 55)
    BTN_ACT      = (0, 140, 80)
    RST_COL      = (140, 50, 50)
    FONT         = cv2.FONT_HERSHEY_SIMPLEX

    _SIDES = ["L", "Both", "R"]

    def __init__(self, win, ref_base, tgt_base, ref_kps, tgt_kps,
                 pair_info, ref_offsets, tgt_offsets):
        self.win      = win
        self.ref_base = ref_base
        self.tgt_base = tgt_base
        self.ref_kps  = ref_kps
        self.tgt_kps  = tgt_kps
        self.pair_info   = pair_info
        self.ref_offsets = ref_offsets
        self.tgt_offsets = tgt_offsets

        # Side suffix derived from YOLO detection in each image, not from CLI
        # Falls back to 'A'/'B' (camera A / camera B) if YOLO found nothing
        ref_det = (ref_kps.get("side") if ref_kps else None) or "A"
        tgt_det = (tgt_kps.get("side") if tgt_kps else None) or "B"
        self._ref_suffix = f"-{ref_det}"
        self._tgt_suffix = f"-{tgt_det}"
        self.ref_side = ref_det
        self.tgt_side = tgt_det

        self.ref_scale = self.TARGET_H / ref_base.shape[0]
        self.tgt_scale = self.TARGET_H / tgt_base.shape[0]
        self.ref_cw    = int(ref_base.shape[1] * self.ref_scale)
        self.tgt_cw    = int(tgt_base.shape[1] * self.tgt_scale)

        self.ref_x0  = 0
        self.tgt_x0  = self.ref_cw + self.DIV_W
        self.img_y0  = self.BAR_H
        self.info_y0 = self.BAR_H + self.TARGET_H
        self.ctrl_y0 = self.info_y0 + self.INFO_H
        self.canvas_w = self.ref_cw + self.DIV_W + self.tgt_cw
        self.canvas_h = self.ctrl_y0 + self.CTRL_H

        # Anchor pixel positions — defaults (no offsets) for drag inversion,
        # current (offset-adjusted) for display and hit-testing.
        self._ref_anchor_defaults = {}
        self._tgt_anchor_defaults = {}
        self._ref_anchor_current  = {}
        self._tgt_anchor_current  = {}
        # Oblique basis (origin, A, B, det) for offset inversion
        self._ref_basis = (None, None, None, None)
        self._tgt_basis = (None, None, None, None)
        # Drawn regions (with side suffix baked into keys)
        self._ref_regions = {}
        self._tgt_regions = {}

        self._drag_side = None
        self._drag_name = None
        self._side_idx  = 1   # default: "Both"

        # Landmark manual placement mode
        # _place_mode: None | ('ref','eye') | ('ref','ear') | ('ref','nose')
        #                   | ('tgt','eye') | ('tgt','ear') | ('tgt','nose')
        self._place_mode = None

        self._layout_buttons()
        cv2.namedWindow(win, cv2.WINDOW_NORMAL)
        cv2.setWindowProperty(win, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        cv2.setMouseCallback(win, self._on_mouse)
        self.render()

    # ── layout ────────────────────────────────────────────────────────────────

    def _layout_buttons(self):
        y1 = self.ctrl_y0 + 7
        y2 = self.ctrl_y0 + self.CTRL_H - 7
        x  = 10
        self._btn_reset = (x, y1, x + 85, y2)
        x += 95
        self._btn_sides = []
        for _ in self._SIDES:
            self._btn_sides.append((x, y1, x + 65, y2))
            x += 72

    # ── coordinate helpers ────────────────────────────────────────────────────

    def _img_to_canvas(self, ix, iy, which):
        s  = self.ref_scale if which == 'ref' else self.tgt_scale
        x0 = self.ref_x0   if which == 'ref' else self.tgt_x0
        return int(round(ix * s + x0)), int(round(iy * s + self.img_y0))

    def _canvas_to_img(self, cx, cy, which):
        s  = self.ref_scale if which == 'ref' else self.tgt_scale
        x0 = self.ref_x0   if which == 'ref' else self.tgt_x0
        return (cx - x0) / s, (cy - self.img_y0) / s

    def _which_pane(self, cx):
        if self.ref_x0 <= cx < self.ref_x0 + self.ref_cw:
            return 'ref'
        if self.tgt_x0 <= cx < self.tgt_x0 + self.tgt_cw:
            return 'tgt'
        return None

    # ── nearest draggable anchor ──────────────────────────────────────────────

    def _find_nearest_handle(self, cx, cy):
        as_  = self._SIDES[self._side_idx]
        pane = self._which_pane(cx)
        if pane is None:
            return None, None
        if pane == 'ref' and as_ == 'L':
            return None, None
        if pane == 'tgt' and as_ == 'R':
            return None, None
        if not (self.img_y0 <= cy <= self.img_y0 + self.TARGET_H):
            return None, None

        # Use current offset-adjusted positions for hit detection so you can
        # click on where the dot actually is, not its original default position.
        current = (self._ref_anchor_current if pane == 'ref'
                   else self._tgt_anchor_current)
        best_name, best_d = None, self.HIT_R ** 2
        for name, px in current.items():
            hcx, hcy = self._img_to_canvas(px[0], px[1], pane)
            d = (cx - hcx) ** 2 + (cy - hcy) ** 2
            if d < best_d:
                best_d = d; best_name = name
        return pane, best_name

    # ── render ────────────────────────────────────────────────────────────────

    def render(self):
        as_ = self._SIDES[self._side_idx]

        # Compute anchors and draw regions — always, regardless of landmark quality
        def _compute_for_pane(kps, offsets):
            if kps is None:
                return (None, None, None, None), {}, {}, None
            origin, A, B, det = _build_profile_basis(
                kps['eye'], kps['ear'], kps.get('nose'))
            basis    = (origin, A, B, det)
            defaults = compute_anchor_pixels(kps['eye'], kps['ear'], kps.get('nose'))
            current  = compute_anchor_pixels(kps['eye'], kps['ear'], kps.get('nose'),
                                             offsets)
            return basis, defaults, current, current

        self._ref_basis, self._ref_anchor_defaults, self._ref_anchor_current, anchor_px_ref =             _compute_for_pane(self.ref_kps, self.ref_offsets)
        self._tgt_basis, self._tgt_anchor_defaults, self._tgt_anchor_current, anchor_px_tgt =             _compute_for_pane(self.tgt_kps, self.tgt_offsets)

        # Draw regions — always draw if we have anchor positions
        if as_ in ("Both", "R") and anchor_px_ref:
            ref_ann, self._ref_regions = draw_regions(
                self.ref_base, anchor_px_ref, self._ref_suffix)
        else:
            ref_ann, self._ref_regions = self.ref_base.copy(), {}

        if as_ in ("Both", "L") and anchor_px_tgt:
            tgt_ann, self._tgt_regions = draw_regions(
                self.tgt_base, anchor_px_tgt, self._tgt_suffix)
        else:
            tgt_ann, self._tgt_regions = self.tgt_base.copy(), {}

        # Build canvas
        canvas = np.full((self.canvas_h, self.canvas_w, 3),
                         self.COL_BG, dtype=np.uint8)
        ref_s = cv2.resize(ref_ann, (self.ref_cw, self.TARGET_H),
                           interpolation=cv2.INTER_AREA)
        tgt_s = cv2.resize(tgt_ann, (self.tgt_cw, self.TARGET_H),
                           interpolation=cv2.INTER_AREA)
        if as_ == 'L':
            ref_s = (ref_s * 0.28).astype(np.uint8)
        if as_ == 'R':
            tgt_s = (tgt_s * 0.28).astype(np.uint8)

        ref_nmod = sum(1 for v in self.ref_offsets.values() if np.any(np.array(v) != 0))
        tgt_nmod = sum(1 for v in self.tgt_offsets.values() if np.any(np.array(v) != 0))

        for x0, cw, role, sl, n, dimmed, nmod in [
            (self.ref_x0, self.ref_cw, "Cam-A", self.ref_side,
             len(self._ref_regions), as_ == 'L', ref_nmod),
            (self.tgt_x0, self.tgt_cw, "Cam-B", self.tgt_side,
             len(self._tgt_regions), as_ == 'R', tgt_nmod),
        ]:
            hdr = np.full((self.BAR_H, cw, 3), (28, 28, 28), dtype=np.uint8)
            tc  = (70, 70, 70) if dimmed else (255, 255, 255)
            mod_str = f"  [{nmod} adjusted]" if nmod else ""
            for txt, yy, sc in [
                (f"{role} ({sl}-side){mod_str}", 18, 0.50),
                (f"{n} regions{'  [filtered]' if dimmed else ''}", 36, 0.42),
            ]:
                cv2.putText(hdr, txt, (8, yy), self.FONT, sc, (0, 0, 0), 2, cv2.LINE_AA)
                cv2.putText(hdr, txt, (8, yy), self.FONT, sc, tc, 1, cv2.LINE_AA)
            canvas[0:self.BAR_H, x0:x0 + cw] = hdr

        canvas[self.img_y0:self.img_y0 + self.TARGET_H,
               self.ref_x0:self.ref_x0 + self.ref_cw] = ref_s
        canvas[self.img_y0:self.img_y0 + self.TARGET_H,
               self.tgt_x0:self.tgt_x0 + self.tgt_cw] = tgt_s
        canvas[0:self.img_y0 + self.TARGET_H,
               self.ref_cw:self.ref_cw + self.DIV_W] = (70, 70, 70)

        # Info bar
        cv2.rectangle(canvas, (0, self.info_y0),
                      (self.canvas_w, self.info_y0 + self.INFO_H), (18, 18, 18), -1)
        cv2.putText(canvas, self.pair_info, (8, self.info_y0 + 24),
                    self.FONT, 0.42, (0, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(canvas, self.pair_info, (8, self.info_y0 + 24),
                    self.FONT, 0.42, (190, 190, 190), 1, cv2.LINE_AA)

        # Control bar
        cv2.rectangle(canvas, (0, self.ctrl_y0),
                      (self.canvas_w, self.canvas_h), (22, 22, 22), -1)
        cv2.line(canvas, (0, self.ctrl_y0),
                 (self.canvas_w, self.ctrl_y0), (55, 55, 55), 1)

        # Reset button
        rx1, ry1, rx2, ry2 = self._btn_reset
        cv2.rectangle(canvas, (rx1, ry1), (rx2, ry2), self.RST_COL, -1, cv2.LINE_AA)
        cv2.rectangle(canvas, (rx1, ry1), (rx2, ry2), (200, 80, 80), 1, cv2.LINE_AA)
        (tw, th), _ = cv2.getTextSize("Reset", self.FONT, 0.50, 1)
        cv2.putText(canvas, "Reset",
                    (rx1 + ((rx2 - rx1) - tw) // 2, ry1 + ((ry2 - ry1) + th) // 2),
                    self.FONT, 0.50, (0, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(canvas, "Reset",
                    (rx1 + ((rx2 - rx1) - tw) // 2, ry1 + ((ry2 - ry1) + th) // 2),
                    self.FONT, 0.50, (240, 200, 200), 1, cv2.LINE_AA)

        # Side filter buttons
        for i, (lbl, (bx1, by1, bx2, by2)) in enumerate(
                zip(self._SIDES, self._btn_sides)):
            active = (i == self._side_idx)
            bg  = self.BTN_ACT if active else self.BTN_COL
            brd = (0, 220, 140) if active else (80, 80, 80)
            cv2.rectangle(canvas, (bx1, by1), (bx2, by2), bg, -1, cv2.LINE_AA)
            cv2.rectangle(canvas, (bx1, by1), (bx2, by2), brd, 1, cv2.LINE_AA)
            (tw, th), _ = cv2.getTextSize(lbl, self.FONT, 0.50, 1)
            cv2.putText(canvas, lbl,
                        (bx1 + ((bx2 - bx1) - tw) // 2,
                         by1 + ((by2 - by1) + th) // 2),
                        self.FONT, 0.50, (0, 0, 0), 2, cv2.LINE_AA)
            cv2.putText(canvas, lbl,
                        (bx1 + ((bx2 - bx1) - tw) // 2,
                         by1 + ((by2 - by1) + th) // 2),
                        self.FONT, 0.50,
                        (255, 255, 255) if active else (190, 190, 190),
                        1, cv2.LINE_AA)

        inst = ("Drag anchor handles  |  "
                "offsets stored as oblique fractions (du, dv) of L and D  |  "
                "Enter=Accept  S=Skip  Q=Quit")
        cv2.putText(canvas, inst,
                    (self._btn_sides[-1][2] + 18,
                     self.ctrl_y0 + self.CTRL_H // 2 + 5),
                    self.FONT, 0.34, (110, 110, 110), 1, cv2.LINE_AA)

        # Draw anchor handles at their CURRENT (offset-adjusted) positions
        if as_ in ("Both", "R"):
            self._draw_handles(canvas, anchor_px_ref,
                               self.ref_offsets, 'ref')
        if as_ in ("Both", "L"):
            self._draw_handles(canvas, anchor_px_tgt,
                               self.tgt_offsets, 'tgt')

        # Landmark placement mode banner
        if self._place_mode is not None:
            pane_str, lm_str = self._place_mode
            col_map  = {'eye': (0, 200, 255), 'ear': (0, 220, 80), 'nose': (50, 120, 255)}
            lm_col   = col_map.get(lm_str, (255, 255, 255))
            banner   = (f">>> CLICK to place {pane_str.upper()} {lm_str.upper()} "
                        f"— Esc to cancel <<<")
            bw, bh   = self.canvas_w, 40
            overlay  = canvas.copy()
            cv2.rectangle(overlay, (0, 0), (bw, bh), (30, 30, 30), -1)
            cv2.addWeighted(overlay, 0.75, canvas, 0.25, 0, canvas)
            cv2.putText(canvas, banner,
                        (bw // 2 - cv2.getTextSize(banner, self.FONT, 0.60, 2)[0][0] // 2, 27),
                        self.FONT, 0.60, (0, 0, 0), 3, cv2.LINE_AA)
            cv2.putText(canvas, banner,
                        (bw // 2 - cv2.getTextSize(banner, self.FONT, 0.60, 2)[0][0] // 2, 27),
                        self.FONT, 0.60, lm_col, 1, cv2.LINE_AA)

        cv2.imshow(self.win, canvas)

    # ── handle drawing ────────────────────────────────────────────────────────

    def _draw_handles(self, canvas, anchor_defaults, offsets, which):
        for name, px in anchor_defaults.items():
            cx, cy = self._img_to_canvas(px[0], px[1], which)
            if not (self.img_y0 <= cy <= self.img_y0 + self.TARGET_H):
                continue
            x0 = self.ref_x0 if which == 'ref' else self.tgt_x0
            cw = self.ref_cw if which == 'ref' else self.tgt_cw
            if not (x0 <= cx <= x0 + cw):
                continue
            is_drag  = (self._drag_side == which and self._drag_name == name)
            has_off  = (name in offsets
                        and np.any(np.array(offsets[name]) != 0))
            col = (self.COL_ACTIVE   if is_drag
                   else self.COL_MODIFIED if has_off
                   else self.COL_DEFAULT)
            cv2.circle(canvas, (cx, cy), self.HANDLE_R, col, -1, cv2.LINE_AA)
            cv2.circle(canvas, (cx, cy), self.HANDLE_R, (255, 255, 255), 1)
            cv2.putText(canvas, name, (cx + self.HANDLE_R + 3, cy - 3),
                        self.FONT, 0.30, (0, 0, 0), 2, cv2.LINE_AA)
            cv2.putText(canvas, name, (cx + self.HANDLE_R + 3, cy - 3),
                        self.FONT, 0.30, col, 1, cv2.LINE_AA)

    # ── mouse ─────────────────────────────────────────────────────────────────

    def _on_mouse(self, event, cx, cy, flags, param):
        # ── Landmark placement mode — intercept all clicks ────────────────────
        if self._place_mode is not None and event == cv2.EVENT_LBUTTONDOWN:
            pane_str, lm_str = self._place_mode
            ix, iy = self._canvas_to_img(cx, cy, pane_str)
            kps = self.ref_kps if pane_str == 'ref' else self.tgt_kps
            if kps is not None:
                kps[lm_str] = (ix, iy)
            self._place_mode = None
            self.render()
            return

        if event == cv2.EVENT_LBUTTONDOWN:
            # Reset button
            rx1, ry1, rx2, ry2 = self._btn_reset
            if rx1 <= cx <= rx2 and ry1 <= cy <= ry2:
                self.ref_offsets.clear()
                self.tgt_offsets.clear()
                self.render(); return
            # Side filter buttons
            for i, (bx1, by1, bx2, by2) in enumerate(self._btn_sides):
                if bx1 <= cx <= bx2 and by1 <= cy <= by2:
                    if i != self._side_idx:
                        self._side_idx = i
                        self.render()
                    return
            # Drag handle
            pane, name = self._find_nearest_handle(cx, cy)
            if name:
                self._drag_side = pane
                self._drag_name = name
                self.render()

        elif event == cv2.EVENT_MOUSEMOVE:
            if self._drag_side and self._drag_name:
                ix, iy   = self._canvas_to_img(cx, cy, self._drag_side)
                new_pos  = np.array([ix, iy])
                defaults = (self._ref_anchor_defaults if self._drag_side == 'ref'
                            else self._tgt_anchor_defaults)
                offsets  = (self.ref_offsets if self._drag_side == 'ref'
                            else self.tgt_offsets)
                _, A, B, det = (self._ref_basis if self._drag_side == 'ref'
                                else self._tgt_basis)

                if self._drag_name in defaults and A is not None:
                    delta = new_pos - defaults[self._drag_name]
                    du, dv = _pixel_delta_to_oblique(delta, A, B, det)
                    offsets[self._drag_name] = (du, dv)
                self.render()

        elif event == cv2.EVENT_LBUTTONUP:
            self._drag_side = None
            self._drag_name = None

    # ── key handler ──────────────────────────────────────────────────────────

    def handle_key(self, key):
        """
        Handle landmark placement keys.  Call from the show_pair_cv2 loop.

        Keys (both cameras):
            E / e  →  place EYE   on ref pane, then tgt pane on next press
            R / r  →  place EAR
            N / n  →  place NOSE
            Each key cycles:  ref → tgt → cancel (Esc cancels at any point).

        Because both panes show a profile, we map:
            First  press → place on REF pane
            Second press → place on TGT pane
        """
        if key == 27:   # Esc — cancel placement mode
            if self._place_mode is not None:
                self._place_mode = None
                self.render()
            return

        lm_map = {
            ord('e'): 'eye',  ord('E'): 'eye',
            ord('r'): 'ear',  ord('R'): 'ear',
            ord('n'): 'nose', ord('N'): 'nose',
        }
        if key not in lm_map:
            return

        lm = lm_map[key]

        # Cycle through: not-in-mode → ref → tgt → cancel
        if self._place_mode is None:
            self._place_mode = ('ref', lm)
        elif self._place_mode == ('ref', lm):
            self._place_mode = ('tgt', lm)
        else:
            self._place_mode = None   # already on tgt or different lm → cancel

        self.render()

    # ── properties ────────────────────────────────────────────────────────────

    @property
    def ref_regions(self): return self._ref_regions

    @property
    def tgt_regions(self): return self._tgt_regions

    def destroy(self):
        try:
            cv2.destroyWindow(self.win)
        except cv2.error:
            pass


# ══════════════════════════════════════════════════════════════════════════════
#  PAIR DISPLAY ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

_WIN = ("Dual FLIR Profile Mesh  |  "
        "Drag handles  |  E=place-eye  R=place-ear  N=place-nose  "
        "Enter=Accept  S=Skip  Q=Quit")


def show_pair_cv2(ref_base, tgt_base, ref_kps, tgt_kps,
                  pair_info, ref_offsets, tgt_offsets):
    disp = InteractivePairDisplay(
        _WIN, ref_base, tgt_base, ref_kps, tgt_kps,
        pair_info, ref_offsets, tgt_offsets)
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key in (13, 10):
            disp.destroy()
            return "accept", disp.ref_regions, disp.tgt_regions
        elif key in (ord('s'), ord('S')):
            disp.destroy()
            return "skip", {}, {}
        elif key in (ord('q'), ord('Q')):
            disp.destroy()
            return "abort", {}, {}
        elif key == 27:   # Esc — cancel placement mode or quit if idle
            if disp._place_mode is not None:
                disp.handle_key(27)
            else:
                disp.destroy()
                return "abort", {}, {}
        elif key != 255:
            disp.handle_key(key)
        try:
            if cv2.getWindowProperty(_WIN, cv2.WND_PROP_VISIBLE) < 1:
                disp.destroy()
                return "abort", {}, {}
        except cv2.error:
            disp.destroy()
            return "abort", {}, {}


# ══════════════════════════════════════════════════════════════════════════════
#  SYNCHRONISATION
# ══════════════════════════════════════════════════════════════════════════════

def sync_images(ref_list, tgt_list, max_time_diff=5.0):
    candidates = []
    for i, tgt in enumerate(tgt_list):
        for j, ref in enumerate(ref_list):
            diff = abs((ref["time"] - tgt["time"]).total_seconds())
            if diff <= max_time_diff:
                candidates.append((diff, j, i, ref, tgt))
    candidates.sort(key=lambda x: x[0])
    pairs, used_r, used_t = [], set(), set()
    for diff, ri, ti, ref, tgt in candidates:
        if ri not in used_r and ti not in used_t:
            pairs.append((ref, tgt))
            used_r.add(ri); used_t.add(ti)
    pairs.sort(key=lambda p: p[0]["time"])
    return pairs


# ══════════════════════════════════════════════════════════════════════════════
#  BLOCK TIME GUI
# ══════════════════════════════════════════════════════════════════════════════

def _parse_time(s, date_ref):
    s = s.strip()
    try:
        t = datetime.strptime(s, "%H:%M:%S").time()
    except ValueError:
        raise ValueError(f"'{s}' is not a valid time — use HH:MM:SS format.")
    return datetime.combine(date_ref.date(), t)


def get_block_times_gui(pair_avg_times):
    date_ref  = pair_avg_times[0]
    result    = {}
    confirmed = [False]
    root = tk.Tk()
    root.title("Define Block Times")
    root.configure(bg="#1e1e1e")
    root.resizable(False, False)

    BG       = "#1e1e1e"; FG     = "#e8e8e8"
    ACCENT   = "#00c864"; ERR_COL = "#ff5555"
    ENTRY_BG = "#2d2d2d"; ENTRY_FG = "#ffffff"
    FONT_H = ("Consolas", 11, "bold")
    FONT_N = ("Consolas", 10)
    FONT_S = ("Consolas", 9)

    left = tk.Frame(root, bg=BG, padx=12, pady=12)
    left.grid(row=0, column=0, sticky="ns")
    tk.Label(left, text="Pair timestamps (avg ref+tgt)",
             bg=BG, fg=ACCENT, font=FONT_H).pack(anchor="w", pady=(0, 6))
    frame_list = tk.Frame(left, bg=BG)
    frame_list.pack(fill="both", expand=True)
    scrollbar = tk.Scrollbar(frame_list, orient="vertical",
                             bg="#333", troughcolor="#222")
    listbox = tk.Listbox(frame_list, yscrollcommand=scrollbar.set,
                         bg=ENTRY_BG, fg=FG, selectbackground="#3a3a5c",
                         font=FONT_N, width=36,
                         height=min(30, len(pair_avg_times)))
    for t in pair_avg_times:
        listbox.insert(tk.END, t.strftime("  %H:%M:%S"))
    scrollbar.config(command=listbox.yview)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    right = tk.Frame(root, bg=BG, padx=18, pady=12)
    right.grid(row=0, column=1, sticky="nw")
    tk.Label(right, text="Block times", bg=BG, fg=ACCENT,
             font=FONT_H).grid(row=0, column=0, columnspan=2,
                                sticky="w", pady=(0, 8))

    field_defs = [
        ("Block 1  start", "b1_start"), ("Block 1  end", "b1_end"),
        ("Block 2  start", "b2_start"), ("Block 2  end", "b2_end"),
        ("Block 3  start", "b3_start"), ("Block 3  end", "b3_end"),
        ("Session end",    "end_time"),
    ]
    entries    = {}
    err_labels = {}
    for row_idx, (label, key) in enumerate(field_defs, start=1):
        if key == "end_time":
            sep = tk.Frame(right, bg="#444", height=1)
            sep.grid(row=row_idx * 3 - 1, column=0, columnspan=2,
                     sticky="ew", pady=6)
        tk.Label(right, text=label, bg=BG, fg=FG, font=FONT_N,
                 anchor="w", width=18).grid(row=row_idx * 3, column=0,
                                             sticky="w", pady=(4, 0))
        var = tk.StringVar()
        e   = tk.Entry(right, textvariable=var, bg=ENTRY_BG, fg=ENTRY_FG,
                       font=FONT_N, insertbackground=ACCENT, width=12,
                       relief="flat", highlightthickness=1,
                       highlightcolor=ACCENT, highlightbackground="#555")
        e.grid(row=row_idx * 3, column=1, sticky="w", padx=(8, 0), pady=(4, 0))
        err = tk.Label(right, text="", bg=BG, fg=ERR_COL, font=FONT_S)
        err.grid(row=row_idx * 3 + 1, column=0, columnspan=2,
                 sticky="w", pady=(0, 2))
        entries[key]    = var
        err_labels[key] = err

    tk.Label(right,
             text=("Pairs > 5s before Block 1 start will be discarded.\n"
                   "Reference = +1 inside blocks, -1 outside."),
             bg=BG, fg="#888888", font=FONT_S, justify="left"
             ).grid(row=100, column=0, columnspan=2, sticky="w", pady=(16, 8))

    status_var = tk.StringVar(value="")
    status_lbl = tk.Label(right, textvariable=status_var, bg=BG,
                          fg=ERR_COL, font=FONT_S, justify="left")
    status_lbl.grid(row=101, column=0, columnspan=2, sticky="w")

    def on_confirm():
        for lbl in err_labels.values():
            lbl.config(text="")
        status_var.set(""); status_lbl.config(fg=ERR_COL)
        parsed    = {}; has_error = False
        for label, key in field_defs:
            raw = entries[key].get().strip()
            if not raw:
                err_labels[key].config(text="  required"); has_error = True; continue
            try:
                parsed[key] = _parse_time(raw, date_ref)
            except ValueError as e:
                err_labels[key].config(text=f"  {e}"); has_error = True
        if has_error:
            return
        order_checks = [
            ("b1_start", "b1_end",  "Block 1 start must be before Block 1 end"),
            ("b1_end",   "b2_start","Block 2 start must be after Block 1 end"),
            ("b2_start", "b2_end",  "Block 2 start must be before Block 2 end"),
            ("b2_end",   "b3_start","Block 3 start must be after Block 2 end"),
            ("b3_start", "b3_end",  "Block 3 start must be before Block 3 end"),
            ("b3_end",   "end_time","Session end must be after Block 3 end"),
        ]
        for a, b, msg in order_checks:
            if parsed[a] >= parsed[b]:
                status_var.set(msg); return
        cutoff = parsed["b1_start"] - timedelta(seconds=5)
        kept   = [t for t in pair_avg_times if t >= cutoff]
        n_disc = len(pair_avg_times) - len(kept)
        n_on   = sum(1 for t in kept
                     if any(parsed[f"b{n}_start"] <= t <= parsed[f"b{n}_end"]
                            for n in (1, 2, 3)))
        n_off  = len(kept) - n_on
        status_var.set(
            f"OK — {len(kept)} pairs kept ({n_disc} discarded), "
            f"{n_on} active (+1), {n_off} baseline (-1)")
        status_lbl.config(fg=ACCENT)
        result.update(parsed)
        confirmed[0] = True
        root.after(800, root.destroy)

    tk.Button(right, text="Confirm", command=on_confirm,
              bg="#005533", fg="#00ff88",
              activebackground="#007744", activeforeground="#ffffff",
              font=("Consolas", 11, "bold"), relief="flat",
              padx=20, pady=6, cursor="hand2"
              ).grid(row=102, column=0, columnspan=2, pady=(12, 0), sticky="w")
    root.bind("<Return>", lambda e: on_confirm())
    root.update_idletasks()
    w, h = root.winfo_width(), root.winfo_height()
    root.geometry(
        f"+{(root.winfo_screenwidth() - w) // 2}"
        f"+{(root.winfo_screenheight() - h) // 2}")
    root.mainloop()
    if not confirmed[0]:
        return None
    return result


# ══════════════════════════════════════════════════════════════════════════════
#  REFERENCE SERIES
# ══════════════════════════════════════════════════════════════════════════════

def build_reference_series(paired, block_times):
    cutoff = block_times["b1_start"] - timedelta(seconds=5)
    filtered_paired     = []
    pair_avg_times_kept = []
    ref_series_raw      = []
    for ref_item, tgt_item in paired:
        avg_t  = ref_item["time"] + (tgt_item["time"] - ref_item["time"]) / 2
        if avg_t < cutoff:
            continue
        active = any(
            block_times[f"b{n}_start"] <= avg_t <= block_times[f"b{n}_end"]
            for n in (1, 2, 3))
        filtered_paired.append((ref_item, tgt_item))
        pair_avg_times_kept.append(avg_t)
        ref_series_raw.append(1.0 if active else -1.0)
    ref_arr = np.array(ref_series_raw)
    mu      = float(np.mean(ref_arr))
    std     = (float(np.std(ref_arr, ddof=1))
               if len(ref_arr) > 1 else 1.0)
    ref_series_z = (ref_arr - mu) / std if std != 0 else ref_arr - mu
    return filtered_paired, pair_avg_times_kept, ref_series_z

# ══════════════════════════════════════════════════════════════════════════════
#  Session persistence helpers
#
#  Analysis lives in FLIR_Analyser.py and can be re-run without re-scanning.
#  Per accepted pair the extractor saves:
#    overlays/T###_A_<label>.png  — annotated Cam-A display image
#    overlays/T###_B_<label>.png  — annotated Cam-B display image
#    pixels/T###_A_<label>.npz   — { region_name-L : float32 array }
#    pixels/T###_B_<label>.npz   — { region_name-R : float32 array }
#  Plus session_meta.json indexing everything.
#  FLIR_Analyser.py merges the two NPZs per timepoint (collision-free because
#  region names already carry -L / -R suffixes) and treats the result as a
#  standard flat {region_name: pixel_array} dict, identical in structure to
#  single-camera sessions.
# ══════════════════════════════════════════════════════════════════════════════

def _make_overlay_from_regions(base_bgr, region_polys):
    """
    Draw pre-computed polygon regions onto base_bgr and return annotated copy.
    Used to produce the saved overlay image after the GUI closes.
    Region names carry a side suffix (-L/-R); colours are looked up by stripping it.
    """
    canvas = base_bgr.copy()
    for rname, poly in region_polys.items():
        base_rname = rname[:-2] if rname.endswith(("-L", "-R")) else rname
        defn    = PROFILE_REGION_DEFS.get(base_rname, {})
        color   = defn.get("color", (128, 128, 128))
        alpha   = defn.get("alpha", 0.40)
        overlay = canvas.copy()
        cv2.fillPoly(overlay, [poly.reshape(-1, 1, 2)], color)
        cv2.addWeighted(overlay, alpha, canvas, 1 - alpha, 0, canvas)
        cv2.polylines(canvas, [poly.reshape(-1, 1, 2)], True, color, 2, cv2.LINE_AA)
        ctr = poly.mean(axis=0).astype(int)
        cv2.putText(canvas, rname, tuple(ctr),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.36, (0, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(canvas, rname, tuple(ctr),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.36, color, 1, cv2.LINE_AA)
    return canvas


# ══════════════════════════════════════════════════════════════════════════════
#  CALLABLE API
# ══════════════════════════════════════════════════════════════════════════════

def run(dir_a: str, dir_b: str, out_dir: str,
        model: str = "yolov8n-pose.pt", max_dt: float = 5.0):
    """
    Extract dual-profile thermal ROIs from two synchronised FLIR image directories.

    Pairs images from both cameras within max_dt seconds, opens the block-time
    GUI, then shows a side-by-side per-pair interactive display for the
    researcher to verify and adjust anatomical region overlays.

    Parameters
    ----------
    dir_a   : path to first camera image directory
    dir_b   : path to second camera image directory
    out_dir : output session directory (created if missing)
    model   : YOLOv8 pose model path (default: yolov8n-pose.pt)
    max_dt  : maximum time difference (s) allowed when pairing images (default 5.0)

    Returns
    -------
    dict   session metadata on success
    None   if the researcher cancels the GUI or accepts no pairs

    Raises
    ------
    RuntimeError  if ultralytics is not installed, directories are empty,
                  or no image pairs can be formed within max_dt
    """
    if not _YOLO_OK:
        raise RuntimeError("ultralytics not installed — run:  pip install ultralytics")

    os.makedirs(os.path.join(out_dir, "overlays"), exist_ok=True)
    os.makedirs(os.path.join(out_dir, "pixels"),   exist_ok=True)

    def get_imgs(d):
        exts  = {".jpg", ".jpeg", ".JPG", ".JPEG"}
        paths = [os.path.join(d, f) for f in os.listdir(d)
                 if os.path.splitext(f)[1] in exts]
        return sorted(
            [{"path": p, "time": get_capture_time(p)} for p in paths],
            key=lambda x: x["time"])

    global PROFILE_ANCHORS, PROFILE_REGION_DEFS
    from .mesh_loader import load_mesh
    PROFILE_ANCHORS, PROFILE_REGION_DEFS = load_mesh("dual")

    print("Scanning directories...")
    ref_imgs = get_imgs(dir_a)
    tgt_imgs = get_imgs(dir_b)
    if not ref_imgs or not tgt_imgs:
        raise RuntimeError("One or both directories contain no JPEG images.")
    print(f"Found {len(ref_imgs)} cam-A  +  {len(tgt_imgs)} cam-B images.")

    paired = sync_images(ref_imgs, tgt_imgs, max_dt)
    if not paired:
        raise RuntimeError(f"No image pairs found within {max_dt}s tolerance.")
    print(f"Synchronized {len(paired)} pairs.")

    p_r = {id(p[0]) for p in paired}; p_t = {id(p[1]) for p in paired}
    nr  = sum(1 for i in ref_imgs if id(i) not in p_r)
    nt  = sum(1 for i in tgt_imgs if id(i) not in p_t)
    if nr: print(f"  {nr} unmatched Cam-A image(s) skipped.")
    if nt: print(f"  {nt} unmatched Cam-B image(s) skipped.")

    pair_avg_times_all = [
        ref["time"] + (tgt["time"] - ref["time"]) / 2
        for ref, tgt in paired]

    print("\n" + "=" * 90)
    for i, ((ref, tgt), avg_t) in enumerate(zip(paired, pair_avg_times_all)):
        diff = (tgt["time"] - ref["time"]).total_seconds()
        intv = ""
        if i > 0:
            ri = (ref["time"] - paired[i-1][0]["time"]).total_seconds()
            ti = (tgt["time"] - paired[i-1][1]["time"]).total_seconds()
            intv = f"  (+{ri:.1f}s / +{ti:.1f}s)"
        print(f"  [{i+1:3d}]  avg={avg_t.strftime('%H:%M:%S')}  "
              f"ref={ref['time'].strftime('%H:%M:%S')}  "
              f"{os.path.basename(ref['path']):24s}  "
              f"tgt={tgt['time'].strftime('%H:%M:%S')}  "
              f"{os.path.basename(tgt['path']):24s}  "
              f"dt={diff:+.2f}s{intv}")
    print("=" * 90)

    print("\nOpening block-time GUI...")
    block_times = get_block_times_gui(pair_avg_times_all)
    if block_times is None:
        print("Block-time GUI closed without confirming.")
        return None

    filtered_paired, pair_avg_times_kept, ref_series_z = \
        build_reference_series(paired, block_times)
    n_discarded = len(paired) - len(filtered_paired)
    print(f"\nBlock times confirmed.")
    print(f"  Pairs discarded (>5s before Block 1): {n_discarded}")
    print(f"  Pairs kept:                           {len(filtered_paired)}")
    print(f"  Active (+1):   {int(np.sum(ref_series_z > 0))}")
    print(f"  Baseline (-1): {int(np.sum(ref_series_z <= 0))}")
    if len(filtered_paired) == 0:
        raise RuntimeError("No pairs remain after filtering.")

    print(f"\nControls: drag anchor handles  |  "
          f"E=place-eye  R=place-ear  N=place-nose  |  "
          f"[Enter] accept  [S] skip  [Q/Esc] quit")
    print(f"Loading YOLO model '{model}' ...")
    yolo_model = _YOLO(model)

    def to_bgr(arr):
        arr = np.asarray(arr)
        if arr.ndim == 2:
            return cv2.cvtColor(arr.astype(np.uint8), cv2.COLOR_GRAY2BGR)
        arr = arr.astype(np.uint8)
        if arr.shape[2] == 4:
            arr = arr[:, :, :3]
        return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)

    ref_offsets = {}
    tgt_offsets = {}
    timepoints  = []

    for idx, (ref_item, tgt_item) in enumerate(filtered_paired):
        avg_t   = pair_avg_times_kept[idx]
        ref_val = float(ref_series_z[idx])
        print(f"\n[{idx+1}/{len(filtered_paired)}]  "
              f"avg={avg_t.strftime('%H:%M:%S')}  "
              f"ref_signal={ref_val:+.3f}  "
              f"Cam-A: {os.path.basename(ref_item['path'])} "
              f"({ref_item['time'].strftime('%H:%M:%S')})  |  "
              f"Cam-B: {os.path.basename(tgt_item['path'])} "
              f"({tgt_item['time'].strftime('%H:%M:%S')})")

        ref_therm, ref_disp = load_flir_thermal_and_display(ref_item["path"])
        tgt_therm, tgt_disp = load_flir_thermal_and_display(tgt_item["path"])

        if ref_disp is None or tgt_disp is None:
            print("  ERROR: failed to load one or both images — skipping pair.")
            continue

        print("  Running YOLO on Cam-A...")
        ref_base, ref_kps = annotate_with_yolo(to_bgr(ref_disp), yolo_model)
        print(f"  -> {'detected ' + ref_kps.get('side') + '-profile' if ref_kps else 'no keypoints'}")

        print("  Running YOLO on Cam-B...")
        tgt_base, tgt_kps = annotate_with_yolo(to_bgr(tgt_disp), yolo_model)
        print(f"  -> {'detected ' + tgt_kps.get('side') + '-profile' if tgt_kps else 'no keypoints'}")

        n_ref_off = sum(1 for v in ref_offsets.values() if np.any(np.array(v) != 0))
        n_tgt_off = sum(1 for v in tgt_offsets.values() if np.any(np.array(v) != 0))
        if n_ref_off or n_tgt_off:
            print(f"  Carrying over offsets: ref={n_ref_off}, tgt={n_tgt_off} anchors")

        sync_diff  = (tgt_item["time"] - ref_item["time"]).total_seconds()
        active_str = "ACTIVE (+1)" if ref_val > 0 else "baseline (-1)"
        pair_info  = (
            f"Pair {idx+1}/{len(filtered_paired)}  |  "
            f"avg={avg_t.strftime('%H:%M:%S')}  [{active_str}]  |  "
            f"Cam-A: {os.path.basename(ref_item['path'])} "
            f"@ {ref_item['time'].strftime('%H:%M:%S')}  |  "
            f"Cam-B: {os.path.basename(tgt_item['path'])} "
            f"@ {tgt_item['time'].strftime('%H:%M:%S')}  |  "
            f"Sync dt={sync_diff:+.2f}s")

        action, ref_regions, tgt_regions = show_pair_cv2(
            ref_base, tgt_base, ref_kps, tgt_kps,
            pair_info, ref_offsets, tgt_offsets)

        if action == "abort":
            print("  Aborted."); break
        if action == "skip":
            print("  Skipped."); continue

        # ── save overlay images ───────────────────────────────────────────────
        label   = f"T{idx+1:03d}_{avg_t.strftime('%Y-%m-%d_%H-%M-%S')}"
        label_a = f"{label}_A"
        label_b = f"{label}_B"

        ov_a = _save_overlay(out_dir, label_a,
                             _make_overlay_from_regions(ref_base, ref_regions))
        ov_b = _save_overlay(out_dir, label_b,
                             _make_overlay_from_regions(tgt_base, tgt_regions))

        # ── extract and save raw thermal pixel arrays per region ──────────────
        def extract_pixels(therm, display, regions, cam_label):
            pdict = {}
            for rname, poly in regions.items():
                vals, coords = get_polygon_values(therm, poly, display.shape)
                pdict[rname]              = vals
                pdict[f"{rname}__coords"] = coords
                m = float(np.mean(vals))
                v = float(np.var(vals, ddof=1)) if vals.size > 1 else 0.0
                print(f"    {cam_label} {rname:18s}  mean={m:6.2f}  "
                      f"var={v:.4f}  npx={int(vals.size)}")
            return pdict

        px_a = extract_pixels(ref_therm, ref_disp, ref_regions, "Cam-A")
        px_b = extract_pixels(tgt_therm, tgt_disp, tgt_regions, "Cam-B")

        rel_px_a = _save_pixels(out_dir, label_a, px_a)
        rel_px_b = _save_pixels(out_dir, label_b, px_b)

        active = any(
            block_times[f"b{n}_start"] <= avg_t <= block_times[f"b{n}_end"]
            for n in (1, 2, 3))

        timepoints.append({
            "index":     idx,
            "label":     label,
            "timestamp": avg_t.isoformat(),
            "elapsed_s": round((avg_t - pair_avg_times_kept[0]).total_seconds(), 3),
            "active":    active,
            "cam_a": {
                "source_filename": os.path.basename(ref_item["path"]),
                "overlay_file": ov_a,
                "pixel_file":   rel_px_a,
                "regions":      list(px_a.keys()),
            },
            "cam_b": {
                "source_filename": os.path.basename(tgt_item["path"]),
                "overlay_file": ov_b,
                "pixel_file":   rel_px_b,
                "regions":      list(px_b.keys()),
            },
        })

    if not timepoints:
        print("\nNo pairs processed — session not saved.")
        return None

    meta = {
        "session_type": "dual",
        "created":      datetime.now().isoformat(),
        "source_dir":   f"{dir_a}  +  {dir_b}",
        "block_times":  {k: v.isoformat() for k, v in block_times.items()},
        "n_timepoints": len(timepoints),
        "timepoints":   timepoints,
    }
    _write_meta(out_dir, meta)

    n = len(timepoints)
    print(f"\nExtraction complete.  {n} pairs saved.")
    print(f"  Overlays : {out_dir}/overlays/  ({n*2} PNG files, 2 per pair)")
    print(f"  Pixels   : {out_dir}/pixels/   ({n*2} NPZ files, 2 per pair)")

    return meta


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser(
        description="Dual FLIR extractor — Stage 1: segmentation and raw data extraction.")
    ap.add_argument("dir_a",    help="First camera directory")
    ap.add_argument("dir_b",    help="Second camera directory")
    ap.add_argument("out_dir",  help="Output session directory (will be created)")
    ap.add_argument("--model",  default="yolov8n-pose.pt")
    ap.add_argument("--max-dt", type=float, default=5.0,
                    help="Max time difference (s) for pairing images (default 5.0)")
    args = ap.parse_args()
    result = run(args.dir_a, args.dir_b, args.out_dir,
                 model=args.model, max_dt=args.max_dt)
    if result is None:
        sys.exit(0)


if __name__ == "__main__":
    main()
