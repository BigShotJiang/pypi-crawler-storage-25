"""
mesh_loader.py  —  download-on-first-run ROI mesh definitions
=============================================================

Usage in extractors
-------------------
    from mesh_loader import load_mesh
    anchors, region_defs = load_mesh("frontal")   # "back" or "dual"

The first call either:
  1. Loads from the local cache at ~/.thermophysio/mesh_definitions.json
  2. Downloads from REMOTE_URL and saves to that cache (like YOLO weights)
  3. Falls back to the bundled mesh_defs.json next to this file if offline

To force a re-download (e.g. after ROI definitions are updated):
    from mesh_loader import invalidate_cache
    invalidate_cache()
"""

import json
import urllib.request
from collections import OrderedDict
from pathlib import Path

# ── configuration ─────────────────────────────────────────────────────────────

# GitHub raw URL — fill in your username and repo after committing mesh_defs.json
REMOTE_URL = (
    "https://raw.githubusercontent.com/RauwP/thermophysio"
    "/main/thermophysio/mesh_defs.json"
)

CACHE_DIR      = Path.home() / ".thermophysio"
CACHE_FILE     = CACHE_DIR / "mesh_definitions.json"
LOCAL_FALLBACK = Path(__file__).parent / "mesh_defs.json"  # bundled in repo

# ── internal helpers ──────────────────────────────────────────────────────────

_cache: dict | None = None   # in-process cache so repeated calls don't re-read


def _fetch_remote() -> dict:
    """Download mesh_definitions.json from REMOTE_URL and cache it."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    print(f"[thermophysio] Downloading mesh definitions from:\n"
          f"               {REMOTE_URL}")
    with urllib.request.urlopen(REMOTE_URL, timeout=15) as resp:
        data = json.loads(resp.read())
    CACHE_FILE.write_text(json.dumps(data, indent=2))
    print(f"[thermophysio] Cached to {CACHE_FILE}")
    return data


def _load_raw() -> dict:
    """
    Load the raw JSON dict.
    Priority: in-process cache → disk cache → remote download → local bundled file.
    """
    global _cache
    if _cache is not None:
        return _cache

    if CACHE_FILE.exists():
        _cache = json.loads(CACHE_FILE.read_text())
        return _cache

    try:
        _cache = _fetch_remote()
        return _cache
    except Exception as exc:
        if LOCAL_FALLBACK.exists():
            print(f"[thermophysio] Download failed ({exc}).\n"
                  f"               Using bundled definitions at {LOCAL_FALLBACK}")
            _cache = json.loads(LOCAL_FALLBACK.read_text())
            return _cache
        raise RuntimeError(
            f"Mesh definitions not found.\n"
            f"  Cache:    {CACHE_FILE}  (missing)\n"
            f"  Fallback: {LOCAL_FALLBACK}  (missing)\n"
            f"  Download failed: {exc}\n\n"
            f"Set REMOTE_URL in mesh_loader.py to a valid URL, or place "
            f"mesh_defs.json next to mesh_loader.py."
        ) from exc


# ── public API ────────────────────────────────────────────────────────────────

def load_mesh(camera: str) -> tuple:
    """
    Return (anchors, region_defs) as OrderedDicts for the given camera type.

    Parameters
    ----------
    camera : "frontal" | "back" | "dual"

    Returns
    -------
    anchors      OrderedDict  — same structure the extractors use at runtime
    region_defs  OrderedDict  — poly lists, color tuples, alpha floats

    For *frontal*, poly vertex specs are converted from JSON lists back to
    tuples:  ["free", "FP3"]  →  ("free", "FP3")
    For *back* and *dual*, poly entries are plain strings (anchor names).
    """
    data  = _load_raw()
    block = data.get(camera)
    if block is None:
        raise KeyError(
            f"Camera type '{camera}' not found in mesh definitions "
            f"(available: {list(data.keys())})"
        )

    # Anchors — preserve insertion order
    anchors = OrderedDict(block["anchors"])

    # Region defs — convert JSON types back to what the extractors expect
    is_frontal = (camera == "frontal")
    region_defs = OrderedDict()
    for name, defn in block["regions"].items():
        poly = (
            [tuple(pt) for pt in defn["poly"]]   # frontal: [list,…] → [tuple,…]
            if is_frontal else
            list(defn["poly"])                    # back/dual: already strings
        )
        region_defs[name] = {
            "poly":  poly,
            "color": tuple(defn["color"]),
            "alpha": defn["alpha"],
        }

    return anchors, region_defs


def invalidate_cache() -> None:
    """Delete the disk cache and in-process cache so the next load re-downloads."""
    global _cache
    _cache = None
    if CACHE_FILE.exists():
        CACHE_FILE.unlink()
        print(f"[thermophysio] Cache cleared: {CACHE_FILE}")
    else:
        print(f"[thermophysio] No cache to clear ({CACHE_FILE})")
