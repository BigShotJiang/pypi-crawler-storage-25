"""Backward-compatible touchpoint for packaged business runtime delegation helpers."""

from obra_business.runtime.canonical_executor import (
    CanonicalWorkflowExecutionSource,
    DelegatedRunResult,
    PreparedDelegatedRun,
    RuntimeDelegationError,
    RuntimeLogPaths,
    build_delegated_command,
    build_delegated_environment,
    build_runtime_objective,
    copy_runtime_input,
    execute_delegated_run,
    get_runtime_log_paths,
    load_workflow_definition,
    prepare_delegated_run,
    resolve_delegated_plan_path,
    resolve_canonical_execution_source,
)

__all__ = [
    "CanonicalWorkflowExecutionSource",
    "DelegatedRunResult",
    "PreparedDelegatedRun",
    "RuntimeDelegationError",
    "RuntimeLogPaths",
    "build_delegated_command",
    "build_delegated_environment",
    "build_runtime_objective",
    "copy_runtime_input",
    "execute_delegated_run",
    "get_runtime_log_paths",
    "load_workflow_definition",
    "prepare_delegated_run",
    "resolve_delegated_plan_path",
    "resolve_canonical_execution_source",
]
