"""Quality gate evaluation for business workflows.

This module provides the QualityGateEvaluator class that evaluates
stage outputs against quality rules defined in the workflow.

Example:
    >>> evaluator = QualityGateEvaluator(quality_rules)
    >>> result = evaluator.evaluate(stage_output, "S6")
    >>> if not result.passed:
    ...     print(f"Failed rules: {result.failed_rules}")

Related:
    - PRD Appendix B: QualityRule schema
    - obra_business/schemas/workflow.py
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from obra_business.schemas.workflow import QualityRule

logger = logging.getLogger(__name__)


@dataclass
class RuleResult:
    """Result from evaluating a single quality rule.

    Attributes:
        rule_id: ID of the rule (e.g., QR1)
        rule_name: Human-readable rule name
        passed: Whether the rule passed
        message: Explanation of pass/fail
        severity: Rule severity (error, warning)
    """

    rule_id: str
    rule_name: str
    passed: bool
    message: str
    severity: str = "error"


@dataclass
class QualityGateResult:
    """Result from evaluating all quality rules for a stage.

    Attributes:
        passed: Whether all error-severity rules passed
        results: Individual rule results
        failed_rules: List of rule IDs that failed with error severity
        warnings: List of rule IDs that failed with warning severity
    """

    passed: bool
    results: list[RuleResult] = field(default_factory=list)
    failed_rules: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def summary(self) -> str:
        """Generate human-readable summary of evaluation."""
        total = len(self.results)
        passed_count = sum(1 for r in self.results if r.passed)
        failed_count = len(self.failed_rules)
        warning_count = len(self.warnings)

        if self.passed and warning_count == 0:
            return f"All {total} rules passed"
        if self.passed:
            return f"{passed_count}/{total} rules passed ({warning_count} warnings)"
        return f"Failed: {failed_count} error(s), {warning_count} warning(s)"


class QualityGateEvaluator:
    """Evaluate stage outputs against workflow quality rules.

    The evaluator applies quality rules defined in the workflow definition
    to stage outputs, determining pass/fail status for quality gates.

    Example:
        >>> rules = workflow.quality_rules
        >>> evaluator = QualityGateEvaluator(rules)
        >>> result = evaluator.evaluate({"completeness": 0.8}, "S6")
        >>> if not result.passed:
        ...     # Retry previous stage
        ...     pass
    """

    def __init__(self, rules: list[QualityRule]) -> None:
        """Initialize QualityGateEvaluator.

        Args:
            rules: Quality rules from workflow definition
        """
        self.rules = rules
        logger.debug(f"QualityGateEvaluator initialized with {len(rules)} rules")

    def evaluate(self, stage_output: dict[str, Any], stage_id: str) -> QualityGateResult:
        """Evaluate stage output against applicable quality rules.

        Args:
            stage_output: Output data from the stage
            stage_id: ID of the stage being evaluated (e.g., S6)

        Returns:
            QualityGateResult with pass/fail status and details
        """
        # Filter rules that apply to this stage
        applicable_rules = [r for r in self.rules if stage_id in r.applies_to]

        logger.debug(f"Evaluating {len(applicable_rules)} rules for stage {stage_id}")

        results: list[RuleResult] = []
        failed_rules: list[str] = []
        warnings: list[str] = []

        for rule in applicable_rules:
            rule_result = self._evaluate_rule(rule, stage_output)
            results.append(rule_result)

            if not rule_result.passed:
                if rule_result.severity == "error":
                    failed_rules.append(rule.id)
                else:
                    warnings.append(rule.id)

        # Overall pass = no error-severity failures
        passed = len(failed_rules) == 0

        logger.info(
            f"Quality gate evaluation for {stage_id}: "
            f"passed={passed}, errors={len(failed_rules)}, warnings={len(warnings)}"
        )

        return QualityGateResult(
            passed=passed,
            results=results,
            failed_rules=failed_rules,
            warnings=warnings,
        )

    def _evaluate_rule(self, rule: QualityRule, stage_output: dict[str, Any]) -> RuleResult:
        """Evaluate a single quality rule against stage output.

        The evaluation checks for rule-specific keys in the stage output:
        - For completeness rules: checks 'completeness' >= 0.9
        - For consistency rules: checks 'consistency_check' == True
        - For required fields: checks fields exist in output
        - Default: assumes pass if no specific check applies

        Args:
            rule: Quality rule to evaluate
            stage_output: Stage output data

        Returns:
            RuleResult with pass/fail and explanation
        """
        rule_name_lower = rule.name.lower()
        rule_desc_lower = rule.description.lower()

        # Check for completeness-related rules
        if "complete" in rule_name_lower or "complete" in rule_desc_lower:
            return self._check_completeness(rule, stage_output)

        # Check for consistency-related rules
        if "consist" in rule_name_lower or "consist" in rule_desc_lower:
            return self._check_consistency(rule, stage_output)

        # Check for required fields rules
        if "required" in rule_name_lower or "required" in rule_desc_lower:
            return self._check_required_fields(rule, stage_output)

        # Check for quality score rules
        if "quality" in rule_name_lower or "score" in rule_name_lower:
            return self._check_quality_score(rule, stage_output)

        # Default: check if stage has output and no explicit failure
        return self._check_default(rule, stage_output)

    def _check_completeness(self, rule: QualityRule, stage_output: dict[str, Any]) -> RuleResult:
        """Check completeness rule."""
        completeness = stage_output.get("completeness", 1.0)
        threshold = 0.9  # 90% completeness required

        if isinstance(completeness, (int, float)) and completeness >= threshold:
            return RuleResult(
                rule_id=rule.id,
                rule_name=rule.name,
                passed=True,
                message=f"Completeness {completeness:.0%} meets threshold",
                severity=rule.severity,
            )
        return RuleResult(
            rule_id=rule.id,
            rule_name=rule.name,
            passed=False,
            message=f"Completeness {completeness:.0%} below {threshold:.0%} threshold",
            severity=rule.severity,
        )

    def _check_consistency(self, rule: QualityRule, stage_output: dict[str, Any]) -> RuleResult:
        """Check consistency rule."""
        consistency = stage_output.get("consistency_check", True)

        if consistency:
            return RuleResult(
                rule_id=rule.id,
                rule_name=rule.name,
                passed=True,
                message="Consistency check passed",
                severity=rule.severity,
            )
        return RuleResult(
            rule_id=rule.id,
            rule_name=rule.name,
            passed=False,
            message="Consistency check failed: data inconsistencies detected",
            severity=rule.severity,
        )

    def _check_required_fields(self, rule: QualityRule, stage_output: dict[str, Any]) -> RuleResult:
        """Check required fields rule."""
        # Look for missing_fields in output
        missing = stage_output.get("missing_fields", [])

        if not missing:
            return RuleResult(
                rule_id=rule.id,
                rule_name=rule.name,
                passed=True,
                message="All required fields present",
                severity=rule.severity,
            )
        return RuleResult(
            rule_id=rule.id,
            rule_name=rule.name,
            passed=False,
            message=f"Missing required fields: {', '.join(missing)}",
            severity=rule.severity,
        )

    def _check_quality_score(self, rule: QualityRule, stage_output: dict[str, Any]) -> RuleResult:
        """Check quality score rule."""
        score = stage_output.get("quality_score", 1.0)
        threshold = 0.7  # 70% quality required

        if isinstance(score, (int, float)) and score >= threshold:
            return RuleResult(
                rule_id=rule.id,
                rule_name=rule.name,
                passed=True,
                message=f"Quality score {score:.0%} meets threshold",
                severity=rule.severity,
            )
        return RuleResult(
            rule_id=rule.id,
            rule_name=rule.name,
            passed=False,
            message=f"Quality score {score:.0%} below {threshold:.0%} threshold",
            severity=rule.severity,
        )

    def _check_default(self, rule: QualityRule, stage_output: dict[str, Any]) -> RuleResult:
        """Default check: pass if output exists and no failure marker."""
        has_failure = stage_output.get("_failed", False)
        has_error = "error" in stage_output

        if has_failure or has_error:
            return RuleResult(
                rule_id=rule.id,
                rule_name=rule.name,
                passed=False,
                message="Stage output contains failure marker",
                severity=rule.severity,
            )
        return RuleResult(
            rule_id=rule.id,
            rule_name=rule.name,
            passed=True,
            message="Rule evaluation passed (default check)",
            severity=rule.severity,
        )


__all__ = [
    "QualityGateEvaluator",
    "QualityGateResult",
    "RuleResult",
]
