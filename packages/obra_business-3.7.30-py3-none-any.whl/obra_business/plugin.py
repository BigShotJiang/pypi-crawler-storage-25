"""Business domain plugin for Obra.

This module provides the BusinessDomainPlugin class that implements
the DomainPlugin interface for business process automation workflows.

The business domain provides:
- FileWorkspaceManager for filesystem-only artifact management
- BusinessReviewStrategy with opt-in reviews (disabled by default)
- Business-focused validators (completeness, format)
- Business terminology prompt templates

Example:
    >>> from obra_business import BusinessDomainPlugin
    >>> domain = BusinessDomainPlugin()
    >>> print(domain.name)
    'business'
    >>> validators = domain.get_validators()
    >>> templates = domain.get_prompt_templates()
"""

import logging
from typing import Any

try:
    from src.plugins.domain import DomainPlugin
    from src.plugins.review_strategy import ReviewStrategy
    from src.plugins.workspace import WorkspaceManager
except ImportError:
    # When obra-business is used standalone, provide base classes
    class DomainPlugin:  # type: ignore[no-redef]
        """Base class for domain plugins."""

        def get_response_validator_config(self) -> dict[str, Any]:
            """Get default response validator config."""
            return {}

    class ReviewStrategy:  # type: ignore[no-redef]
        """Base class for review strategies."""

    class WorkspaceManager:  # type: ignore[no-redef]
        """Base class for workspace managers."""

logger = logging.getLogger(__name__)


class BusinessDomainPlugin(DomainPlugin):
    """Domain plugin for business process automation.

    Implements the DomainPlugin interface to provide business-specific:
    - Validators (completeness, format - no code checks)
    - Prompt templates (business terminology, no code references)
    - Review strategy (opt-in, reviews disabled by default)
    - Workspace manager (filesystem-based, no git required)

    This domain is designed for non-technical workflows like:
    - Document and report generation
    - Business process automation
    - Content creation and review
    - Non-technical artifact management

    Thread-safety:
        This class is thread-safe. Validator and workspace instances
        are created lazily but cached per instance.

    Example:
        >>> domain = BusinessDomainPlugin()
        >>> print(domain.name)
        'business'
        >>>
        >>> # Get validators for business content
        >>> validators = domain.get_validators()
        >>> for v in validators:
        ...     print(type(v).__name__)
        'CompletenessValidator'
        'FormatValidator'
        >>>
        >>> # Get prompt templates
        >>> templates = domain.get_prompt_templates()
        >>> print(templates.keys())
        dict_keys(['plan', 'draft', 'review', ...])
    """

    # Domain identifier
    DOMAIN_NAME = "business"

    # Version information
    VERSION = "0.1.0"

    def __init__(self) -> None:
        """Initialize business domain plugin."""
        self._validators: list[Any] = []
        self._workspace_manager: WorkspaceManager | None = None
        self._review_strategy: ReviewStrategy | None = None
        self._validators_initialized = False

    @property
    def name(self) -> str:
        """Get the unique identifier for this domain.

        Returns:
            'business' - the domain identifier

        Example:
            >>> domain = BusinessDomainPlugin()
            >>> domain.name
            'business'
        """
        return self.DOMAIN_NAME

    def get_validators(self) -> list[Any]:
        """Get business-specific validators.

        Returns validators for:
        - Completeness (all required sections present)
        - Format (document structure validation)

        No code-specific validators are included.

        Returns:
            List of validator instances

        Example:
            >>> validators = domain.get_validators()
            >>> len(validators)
            2
        """
        if not self._validators_initialized:
            # Import here to avoid circular imports
            from obra_business.validators import (
                CompletenessValidator,
                FormatValidator,
            )

            self._validators = [
                CompletenessValidator(),
                FormatValidator(),
            ]
            self._validators_initialized = True
            logger.debug(f"Initialized {len(self._validators)} validators")

        return self._validators

    def get_prompt_templates(self) -> dict[str, str]:
        """Get business-specific prompt templates.

        Returns templates for:
        - plan: Planning business deliverables
        - draft: Creating initial content
        - review: Reviewing deliverables
        - revise: Revising based on feedback
        - finalize: Finalizing deliverables

        Templates use business terminology with no code references.

        Returns:
            Dictionary mapping template names to template strings

        Example:
            >>> templates = domain.get_prompt_templates()
            >>> 'plan' in templates
            True
        """
        return {
            "plan": self._get_planning_template(),
            "draft": self._get_draft_template(),
            "review": self._get_review_template(),
            "revise": self._get_revision_template(),
            "finalize": self._get_finalize_template(),
        }

    def get_review_strategy(self) -> ReviewStrategy:
        """Get business-specific review strategy.

        Returns the BusinessReviewStrategy with opt-in reviews:
        - Reviews disabled by default
        - Enable via context flag when needed

        Returns:
            BusinessReviewStrategy instance

        Example:
            >>> strategy = domain.get_review_strategy()
            >>> strategy.should_review(artifact, {})
            False  # Disabled by default
            >>> strategy.should_review(artifact, {"enable_review": True})
            True
        """
        if self._review_strategy is None:
            from obra_business.review import BusinessReviewStrategy

            self._review_strategy = BusinessReviewStrategy()
            logger.debug("Initialized BusinessReviewStrategy")

        return self._review_strategy

    def get_workspace_manager(self) -> WorkspaceManager:
        """Get filesystem-based workspace manager.

        Returns the FileWorkspaceManager for:
        - Filesystem-only artifact management (no git required)
        - Directory-based checkpointing
        - File change tracking

        Returns:
            FileWorkspaceManager instance

        Example:
            >>> workspace = domain.get_workspace_manager()
            >>> workspace.initialize(Path("/project"))
            >>> workspace.checkpoint()
        """
        if self._workspace_manager is None:
            from obra_business.workspace import FileWorkspaceManager

            self._workspace_manager = FileWorkspaceManager()
            logger.debug("Initialized FileWorkspaceManager")

        return self._workspace_manager

    def get_response_validator_config(self) -> dict[str, Any]:
        """Get business-specific response validation configuration.

        Business workflows emphasize completeness over code validity,
        so the confidence weights prioritize completeness (0.35) and
        specificity (0.25) over code-related metrics.

        Business-specific patterns:
        - Detects incomplete deliverables
        - Detects placeholder content

        Returns:
            Dictionary with validation configuration
        """
        return {
            "min_length": 100,
            "max_length": 100000,
            "forbidden_patterns": [
                "I cannot",
                "I'm unable",
                "I don't have access",
                "I apologize but I cannot",
                "As an AI",
            ],
            "truncation_indicators": [
                "...",
                "[truncated]",
                "Continued in next",
                "Due to length",
                "[to be continued]",
                "[more to follow]",
            ],
            "confidence_weights": {
                "completeness": 0.35,  # Higher weight for business completeness
                "length": 0.15,
                "code": 0.05,  # Minimal weight for code in business domain
                "tone": 0.20,  # Professional tone matters
                "specificity": 0.25,  # Specific details important
            },
        }

    def get_capabilities(self) -> dict[str, Any]:
        """Get business domain capabilities.

        Returns information about what this domain supports.

        Returns:
            Dictionary with capability information
        """
        return {
            "supports_testing": False,  # No code testing
            "supports_linting": False,  # No code linting
            "supports_typing": False,  # No type checking
            "artifact_types": [
                ".md",
                ".txt",
                ".docx",
                ".pdf",
                ".xlsx",
                ".csv",
                ".json",
                ".yaml",
            ],
            "review_types": ["content", "format", "completeness"],
            "version": self.VERSION,
            "features": {
                "git_integration": False,
                "plan_refinement": True,
                "iterative_review": True,
                "opt_in_review": True,
            },
        }

    # Private methods for template generation

    def _get_planning_template(self) -> str:
        """Get template for business planning prompts."""
        return """## Business Deliverable Planning

You are planning the creation of a business deliverable.

### Objective
{objective}

### Context
{context}

### Guidelines
1. Break down into clear, manageable sections
2. Include acceptance criteria for each section
3. Specify dependencies between sections
4. Consider stakeholder requirements
5. Note any assumptions or constraints

### Output Format
Return a structured plan with:
- Deliverable sections
- Clear acceptance criteria
- Explicit dependencies
- Estimated effort (Low/Medium/High)
"""

    def _get_draft_template(self) -> str:
        """Get template for initial content drafting."""
        return """## Content Drafting

### Deliverable
{deliverable_title}

### Section
{section_title}

### Requirements
{requirements}

### Guidelines
1. Follow the specified format and structure
2. Use clear, professional language
3. Include all required information
4. Maintain consistent tone throughout
5. Address stakeholder needs

### Context
{context}
"""

    def _get_review_template(self) -> str:
        """Get template for content review."""
        return """## Deliverable Review

### Content to Review
{content}

### Review Criteria
1. **Completeness**: Are all required sections present?
2. **Clarity**: Is the content clear and understandable?
3. **Accuracy**: Is the information correct?
4. **Format**: Does it follow the required structure?
5. **Tone**: Is the tone appropriate for the audience?

### Output
Provide structured feedback with:
- Issues found (with severity)
- Suggestions for improvement
- Overall assessment (approve/needs-revision/reject)
"""

    def _get_revision_template(self) -> str:
        """Get template for content revision."""
        return """## Content Revision

Revise the deliverable based on review feedback.

### Current Content
{content}

### Feedback
{feedback}

### Guidelines
1. Address all feedback items
2. Maintain overall structure
3. Preserve approved sections
4. Improve clarity where noted
5. Verify completeness after changes
"""

    def _get_finalize_template(self) -> str:
        """Get template for finalizing deliverables."""
        return """## Deliverable Finalization

### Final Review Checklist
- All sections complete
- Formatting consistent
- No placeholder content
- Stakeholder requirements met
- Ready for distribution

### Content
{content}

### Final Instructions
{instructions}
"""


# Convenience function for registration
def create_business_domain() -> BusinessDomainPlugin:
    """Factory function to create BusinessDomainPlugin.

    Useful for entry point registration.

    Returns:
        New BusinessDomainPlugin instance
    """
    return BusinessDomainPlugin()


__all__ = ["BusinessDomainPlugin", "create_business_domain"]
