"""Business domain prompt templates.

This package contains prompt templates for business process automation
using business terminology with no code references.

Templates are loaded dynamically and can be customized per project.
"""

__all__: list[str] = []
