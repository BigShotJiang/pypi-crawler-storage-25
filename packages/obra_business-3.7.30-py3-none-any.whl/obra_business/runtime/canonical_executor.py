"""Canonical delegated execution for packaged business workflows."""

from __future__ import annotations

import asyncio
from collections.abc import Mapping
from datetime import UTC, datetime
import json
import logging
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from obra.api import APIClient
from obra.config.tier_resolution import resolve_tier_config
from obra.config.loaders import get_gateway_onboarding_config
from obra.gateway.providers.registry import ProviderRegistry
from obra.hybrid.event_logger import HybridEventLogger
from obra.hybrid.preexecution_pipeline import build_preexecution_pipeline
from obra.schemas.stage_model_binding import StageModelBinding
from obra.utils.obra_home import resolve_runtime_dir
from obra.workflow.template_assets import (
    choose_primary_instruction_binding,
    normalize_template_bindings,
)

from obra_business.config.loader import (
    get_config_value,
    get_parallel_execution_enabled,
    get_parallel_max_concurrent_stages,
    load_config,
    normalize_stage_type_tier_entry,
)
from obra_business.complexity.stage_complexity_gate import (
    StageComplexityAssessmentError,
    StageComplexityGate,
)
from obra_business.compilation.compiler import (
    _compute_workflow_content_hash,
    load_cached_grades,
)
from obra_business.crosswalk.model_crosswalk import (
    CrossWalk,
    CrossWalkConfirmationRequired,
    auto_confirm_crosswalk,
    build_crosswalk,
    carry_forward_confirmation,
    confirmed_crosswalk,
    crosswalk_path,
    enumerate_available_models,
    load_crosswalk,
    save_crosswalk,
)
from obra_business.crosswalk.resolver import resolve_stage_binding
from obra_business.schemas.workflow import WorkflowDefinition
from obra_business.schemas.workflow import MODEL_TIER_VALUES
from obra_business.plan_compat import PlanCompatibilityError, select_runtime_plan
from obra_business.runtime.workflow_publication import (
    WorkflowPublicationError,
    persist_published_workflow_revision,
    publish_workflow_revision,
)
from obra_business.workflow_source import (
    build_business_baseline_workflow_ref,
    build_business_workflow_source_payload,
    canonical_workflow_source_path,
    load_business_workflow_source_payload,
)
from obra.quality_tiers import resolve_quality_tier

_TIER_PRIORITY = {tier: index for index, tier in enumerate(MODEL_TIER_VALUES)}
logger = logging.getLogger(__name__)


class RuntimeDelegationError(ValueError):
    """Raised when delegated execution cannot be prepared safely."""


@dataclass(frozen=True)
class CanonicalWorkflowExecutionSource:
    """Resolved canonical workflow source used to synthesize delegated execution."""

    source_path: Path | None
    source_kind: str
    source_provenance: str
    workflow_definition: dict[str, Any]
    summary: dict[str, Any]
    source_artifact: dict[str, Any]
    workflow_derivation_request: dict[str, Any]


@dataclass(frozen=True)
class PreparedDelegatedRun:
    """Materialized inputs for delegated `obra run` execution."""

    command: list[str]
    plan_path: Path
    copied_input_path: Path
    environment: dict[str, str]
    execution_source: CanonicalWorkflowExecutionSource
    objective: str


@dataclass(frozen=True)
class DelegatedRunResult:
    """Subprocess result from delegated execution."""

    exit_code: int
    items_completed: int = 0


@dataclass(frozen=True)
class RuntimeLogPaths:
    """Canonical runtime log locations exposed to operators."""

    runtime_root: Path
    hybrid_log: Path
    production_log: Path
    sessions_dir: Path


# Safety governor: cap the nesting depth of delegated ``obra run``
# subprocesses under a single top-level invocation. The on_start shim
# already has a base case (``_is_delegated_run_context`` in
# ``obra/domains/business/__init__.py``) that suppresses re-entry when
# ``OBRA_STAGE_MODEL_BINDINGS_PATH`` is present, so a correctly configured
# run never nests. This governor is the durable safety net that catches
# any future regression (new code path, changed dispatch mode, etc.)
# before it can fan out into unbounded recursion. The parent's depth is
# carried forward via the ``OBRA_DELEGATION_DEPTH`` env var, which is
# incremented for every subprocess launch in ``build_delegated_environment``.
_DELEGATION_DEPTH_ENV = "OBRA_DELEGATION_DEPTH"
_DEFAULT_MAX_DELEGATION_DEPTH = 2

_DELEGATED_STATUS_PATH_ENV = "OBRA_DELEGATED_STATUS_PATH"
"""Sidecar contract: the parent ``obra business run`` writes a tempfile
path here for the delegated subprocess; the nested run's
``_finalize_completion_notice`` writes ``{"items_completed": N}`` to that
file at session-complete time. The parent reads it after the subprocess
exits so the nested run's actual work-bearing-stage count can flow back
into the parent's invocation counter via the dispatched stage's result
metadata. Without this, the parent always reports
``items_completed=1`` (the on_start wrapper dispatch) regardless of the
nested run's true work count.
"""


def _current_delegation_depth() -> int:
    """Return the number of delegated-run layers already above this process."""
    raw = os.environ.get(_DELEGATION_DEPTH_ENV, "0").strip() or "0"
    try:
        return max(0, int(raw))
    except ValueError:
        return 0


def _resolve_max_delegation_depth(config: dict[str, Any]) -> int:
    """Return the configured maximum nesting depth for delegated runs."""
    raw = (
        config.get("business", {})
        .get("crosswalk", {})
        .get("delegation", {})
        .get("max_depth")
    )
    if raw is None:
        return _DEFAULT_MAX_DELEGATION_DEPTH
    try:
        parsed = int(raw)
    except (TypeError, ValueError):
        return _DEFAULT_MAX_DELEGATION_DEPTH
    return max(1, parsed)


def _check_delegation_depth_budget(config: dict[str, Any]) -> None:
    """Raise when the delegation-depth governor would be exceeded."""
    current = _current_delegation_depth()
    limit = _resolve_max_delegation_depth(config)
    if current >= limit:
        raise RuntimeDelegationError(
            "Delegated-run depth governor refused to spawn another nested "
            f"`obra run`: already {current} layer(s) deep, limit is {limit}. "
            "This usually indicates a regression that re-enters the "
            "business_pipeline_execute on_start shim from inside a delegation "
            "(see obra/domains/business/__init__.py::_is_delegated_run_context). "
            "Raise the limit via business.crosswalk.delegation.max_depth only "
            "after confirming the nesting is intentional."
        )


def prepare_delegated_run(
    *,
    workflow_dir: Path,
    workflow_id: str,
    input_path: Path,
    dry_run: bool,
    raw_plan_path: Path | None = None,
) -> PreparedDelegatedRun:
    """Prepare deterministic inputs for canonical delegated execution."""
    config = load_config()
    _check_delegation_depth_budget(config)
    selected_plan_path = resolve_delegated_plan_path(
        workflow_dir=workflow_dir,
        workflow_id=workflow_id,
        raw_plan_path=raw_plan_path,
    )
    copied_input_path = copy_runtime_input(workflow_dir=workflow_dir, input_path=input_path)
    persist_delegated_execution_input_ref(
        plan_path=selected_plan_path,
        copied_input_path=copied_input_path,
    )
    publish_delegated_workflow_revision(plan_path=selected_plan_path)
    execution_source = resolve_canonical_execution_source(
        workflow_dir=workflow_dir,
        workflow_id=workflow_id,
        raw_plan_path=selected_plan_path,
    )
    compiled_plan = _load_plan_payload(selected_plan_path)
    workflow_content_hash, grades = run_stage_complexity_estimation(
        compiled_plan=compiled_plan,
        config=config,
        execution_source=execution_source,
        workflow_dir=workflow_dir,
        plan_path=selected_plan_path,
    )
    crosswalk = enforce_crosswalk_confirmation(
        compiled_plan=compiled_plan,
        config=config,
        execution_source=execution_source,
        workflow_dir=workflow_dir,
        workflow_id=workflow_id,
        workflow_content_hash=workflow_content_hash,
        grades=grades,
    )
    runtime_bindings = None
    if grades is not None or crosswalk is not None:
        runtime_bindings = resolve_runtime_stage_model_bindings(
            compiled_plan=compiled_plan,
            config=config,
            execution_source=execution_source,
            crosswalk=crosswalk,
            grades=grades,
            workflow_content_hash=workflow_content_hash,
        )
    if runtime_bindings is not None:
        compiled_plan["stage_model_bindings"] = [binding.to_dict() for binding in runtime_bindings]
        _write_plan_payload(selected_plan_path, compiled_plan)
    objective = build_runtime_objective(
        copied_input_path=copied_input_path,
        execution_source=execution_source,
    )
    _, resolved_model, _, bindings = _resolve_delegated_model(
        execution_source=execution_source,
        plan_path=selected_plan_path,
        compiled_plan=compiled_plan,
    )
    parallel_enabled = _plan_requests_parallel_execution(
        plan_path=selected_plan_path,
        config=config,
    )
    bindings_path = write_stage_model_bindings_payload(
        workflow_dir=workflow_dir,
        workflow_content_hash=workflow_content_hash,
        bindings=bindings,
    )
    environment = build_delegated_environment(
        config=config,
        parallel_enabled=parallel_enabled,
        stage_model_bindings_path=bindings_path,
    )
    command = build_delegated_command(
        objective=objective,
        dry_run=dry_run,
        working_dir=workflow_dir.resolve(),
        plan_file=selected_plan_path,
        model=resolved_model,
        parallel=parallel_enabled,
    )
    return PreparedDelegatedRun(
        command=command,
        plan_path=selected_plan_path,
        copied_input_path=copied_input_path,
        environment=environment,
        execution_source=execution_source,
        objective=objective,
    )


def publish_delegated_workflow_revision(*, plan_path: Path) -> None:
    """Publish the selected runtime plan and persist its server revision ref."""
    plan_data = _load_plan_payload(plan_path)
    try:
        client = APIClient.from_config()
    except Exception as exc:
        raise RuntimeDelegationError(
            f"Could not initialize API client to publish delegated workflow revision: {exc}"
        ) from exc

    try:
        result = publish_workflow_revision(client=client, plan=plan_data)
    except WorkflowPublicationError as exc:
        raise RuntimeDelegationError(
            f"Failed to publish delegated workflow revision: {exc}"
        ) from exc

    persist_published_workflow_revision(plan_path, result.revision_id)


def persist_delegated_execution_input_ref(
    *,
    plan_path: Path,
    copied_input_path: Path,
) -> None:
    """Persist the copied input path into the plan uploaded by nested `obra run`."""
    plan_data = _load_plan_payload(plan_path)
    artifacts = plan_data.get("artifacts")
    if not isinstance(artifacts, dict):
        artifacts = {}
        plan_data["artifacts"] = artifacts
    copied_input = str(copied_input_path.resolve())
    if artifacts.get("execution_input") == copied_input:
        return
    artifacts["execution_input"] = copied_input
    _write_plan_payload(plan_path, plan_data)


def resolve_delegated_plan_path(
    *,
    workflow_dir: Path,
    workflow_id: str,
    raw_plan_path: Path | None = None,
) -> Path:
    """Resolve the runtime-safe compiled plan to pass via `obra run --plan-file`."""
    plan_path = (raw_plan_path or workflow_dir / "WORKFLOW_PLAN.json").resolve()
    if not plan_path.exists():
        msg = (
            f"Compiled workflow plan not found for {workflow_id}: {plan_path}. "
            "Restore or regenerate WORKFLOW_PLAN.json before delegated execution."
        )
        raise RuntimeDelegationError(msg)

    try:
        selection = select_runtime_plan(
            workflow_dir=workflow_dir,
            raw_plan_path=plan_path,
            workflow_id=workflow_id,
        )
    except PlanCompatibilityError as exc:
        msg = f"Compiled workflow plan is not safe for delegation: {exc}"
        raise RuntimeDelegationError(msg) from exc
    return selection.plan_path


def resolve_canonical_execution_source(
    *,
    workflow_dir: Path,
    workflow_id: str,
    raw_plan_path: Path | None = None,
) -> CanonicalWorkflowExecutionSource:
    """Resolve the canonical workflow source used for runtime delegation."""
    persisted_payload = load_business_workflow_source_payload(workflow_dir)
    if persisted_payload is not None:
        return _payload_to_execution_source(
            persisted_payload,
            workflow_dir=workflow_dir,
            source_path=canonical_workflow_source_path(workflow_dir).resolve(),
        )

    definition_path = workflow_dir / "definition.yaml"
    if definition_path.exists():
        workflow = load_workflow_definition(workflow_dir)
        workflow_payload = build_business_workflow_source_payload(
            workflow_definition=workflow.model_dump(mode="json"),
            source_kind="definition_yaml",
            source_provenance="supplied",
            source_definition="definition.yaml",
            workflow_version=workflow.version,
            workflow_derivation_request={
                "mission": workflow.title,
                "domain_id": "business",
                "baseline_workflow_ref": build_business_baseline_workflow_ref(
                    workflow,
                    workflow_dir=workflow_dir,
                    provenance="supplied",
                    mission=workflow.title,
                    source_kind="definition_yaml",
                ),
            },
        )
        return _payload_to_execution_source(
            workflow_payload,
            workflow_dir=workflow_dir,
            source_path=definition_path.resolve(),
        )

    plan_path = raw_plan_path or workflow_dir / "WORKFLOW_PLAN.json"
    if plan_path.exists():
        return _load_execution_source_from_plan(plan_path)

    msg = (
        f"Canonical workflow source not found for {workflow_id}: expected "
        "definition.yaml, a persisted canonical workflow source artifact, or a legacy "
        "WORKFLOW_PLAN.json fallback."
    )
    raise RuntimeDelegationError(msg)


def build_delegated_command(
    *,
    objective: str,
    dry_run: bool,
    working_dir: Path | None = None,
    plan_file: Path | None = None,
    model: str | None = None,
    parallel: bool = False,
) -> list[str]:
    """Build the delegated `obra run` argv in deterministic order.

    Per ADR-101, business-domain stages route through pipeline-stage
    infrastructure rather than the software-domain derive/execute path.
    Each compiled story carries explicit ``runner_specs`` (emitted by
    ``obra_business/compilation/compiler.py``) pointing at the
    ``business.stage.llm_invoke`` runner, which performs a single LLM
    call per story against the authored instruction template. The
    nested ``obra run`` auto-detects ``pipeline_only`` from the
    business-workflow-artifact project_context
    (``obra/hybrid/flows/derive.py::_resolve_pipeline_only``) and
    dispatches each story through the PIPELINE_STAGE path.

    No CLI rigor overrides are needed: the pipeline-stage dispatch path
    never invokes spike-first or the review cycle. The previous
    ``--no-spike-first --plan-mode light`` flags were a coupling to
    software-domain rigor knobs that suppressed software orchestration
    but exposed the business delegation to CLI-flag churn; ADR-101
    replaces that contract with runner_specs-driven routing.
    """
    argv = [
        "obra",
        "run",
        "--domain",
        "business",
    ]
    if working_dir is not None:
        argv.extend(["--dir", str(working_dir)])
    if plan_file is not None:
        argv.extend(["--plan-file", str(plan_file)])
    if model is not None:
        argv.extend(["--model", model])
    if parallel:
        argv.append("--parallel")
    if dry_run:
        argv.append("--plan-only")
    argv.append(objective)
    return argv


def build_delegated_environment(
    *,
    config: dict[str, Any],
    parallel_enabled: bool,
    stage_model_bindings_path: Path | None = None,
) -> dict[str, str]:
    """Build subprocess environment overrides for delegated execution."""
    environment: dict[str, str] = {}
    if parallel_enabled:
        environment["OBRA_PARALLEL_EXECUTION"] = "1"
        environment["OBRA_PARALLEL_MAX_WORKERS"] = str(get_parallel_max_concurrent_stages(config))
    if stage_model_bindings_path is not None:
        environment["OBRA_STAGE_MODEL_BINDINGS_PATH"] = str(stage_model_bindings_path)
    # Propagate the delegation-depth counter so the governor in
    # ``_check_delegation_depth_budget`` can catch runaway recursion. The
    # nested subprocess sees ``current + 1`` as its own depth and refuses
    # to spawn a further child once the configured max is reached.
    environment[_DELEGATION_DEPTH_ENV] = str(_current_delegation_depth() + 1)
    return environment


def execute_delegated_run(
    *,
    command: list[str],
    workflow_dir: Path,
    copied_input_path: Path | None = None,
    environment: Mapping[str, str] | None = None,
) -> DelegatedRunResult:
    """Execute delegated `obra run` with stdout/stderr passthrough."""
    if copied_input_path is not None:
        _resolve_and_validate_input_path(copied_input_path, label="copied")
    sidecar_path = workflow_dir / ".obra-biz" / ".delegated-status.json"
    sidecar_path.parent.mkdir(parents=True, exist_ok=True)
    if sidecar_path.exists():
        try:
            sidecar_path.unlink()
        except OSError:
            pass
    subprocess_env = {
        **os.environ,
        **dict(environment or {}),
        _DELEGATED_STATUS_PATH_ENV: str(sidecar_path),
    }
    completed = subprocess.run(  # noqa: S603
        command,
        cwd=str(workflow_dir),
        check=False,
        env=subprocess_env,
    )
    items_completed = _read_delegated_items_completed(sidecar_path)
    return DelegatedRunResult(
        exit_code=int(completed.returncode),
        items_completed=items_completed,
    )


def _read_delegated_items_completed(sidecar_path: Path) -> int:
    """Read the nested run's reported ``items_completed`` from the sidecar.

    Returns ``0`` when the sidecar is absent or unreadable; the parent's
    command-runner branch treats that as "nested didn't report" and falls
    back to the per-dispatch +1 increment. Any non-negative integer
    reported by the nested run is honored.
    """
    if not sidecar_path.is_file():
        return 0
    try:
        payload = json.loads(sidecar_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return 0
    if not isinstance(payload, dict):
        return 0
    raw = payload.get("items_completed")
    try:
        return max(0, int(raw))
    except (TypeError, ValueError):
        return 0


def copy_runtime_input(*, workflow_dir: Path, input_path: Path) -> Path:
    """Copy the user input into the canonical runtime-input staging directory."""
    source_path = _resolve_and_validate_input_path(input_path, label="source")
    runtime_input_dir = workflow_dir / ".obra-biz" / "runtime-input"
    runtime_input_dir.mkdir(parents=True, exist_ok=True)
    copied_input_path = runtime_input_dir / source_path.name
    shutil.copy2(source_path, copied_input_path)
    return _resolve_and_validate_input_path(copied_input_path, label="copied")


def build_runtime_objective(
    *,
    copied_input_path: Path,
    execution_source: CanonicalWorkflowExecutionSource,
) -> str:
    """Build a delegated runtime objective from canonical workflow metadata."""
    metadata = execution_source.summary
    deliverables = ", ".join(metadata["output_deliverables"]) or metadata["output_name"]
    required_fields = ", ".join(metadata["input_required_fields"]) or "the documented input schema"
    return (
        f"Execute the imported business workflow plan for '{metadata['title']}'.\n"
        f"Canonical source provenance: {execution_source.source_kind}/{execution_source.source_provenance}.\n"
        "The supplied --plan-file is authoritative; do not derive a new plan.\n"
        f"Treat the copied file at {copied_input_path} as the authoritative source artifact.\n"
        f"Input specification: {metadata['input_name']} ({metadata['input_format']}) "
        f"with required fields {required_fields}.\n"
        f"Input details: {metadata['input_description']}.\n"
        f"Produce {metadata['output_name']} ({metadata['output_format']}) "
        f"with deliverables {deliverables}.\n"
        f"Output details: {metadata['output_description']}.\n"
        f"Workflow description: {metadata['description']}."
    )


def load_workflow_definition(workflow_dir: Path) -> WorkflowDefinition:
    """Load and validate the workflow definition used for objective synthesis."""
    definition_path = workflow_dir / "definition.yaml"
    if not definition_path.exists():
        msg = f"Workflow definition not found: {definition_path}"
        raise RuntimeDelegationError(msg)

    try:
        definition_data = yaml.safe_load(definition_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        msg = f"Workflow definition is not valid YAML: {definition_path} ({exc})"
        raise RuntimeDelegationError(msg) from exc

    try:
        return WorkflowDefinition.model_validate(definition_data)
    except Exception as exc:
        msg = f"Workflow definition validation failed for {definition_path}: {exc}"
        raise RuntimeDelegationError(msg) from exc


def get_runtime_log_paths() -> RuntimeLogPaths:
    """Resolve the canonical runtime log locations used by delegated runs."""
    runtime_root = resolve_runtime_dir().path
    return RuntimeLogPaths(
        runtime_root=runtime_root,
        hybrid_log=runtime_root / "logs" / "hybrid.jsonl",
        production_log=runtime_root / "logs" / "production.jsonl",
        sessions_dir=runtime_root / "logs" / "sessions",
    )


def _payload_to_execution_source(
    payload: dict[str, Any],
    *,
    workflow_dir: Path,
    source_path: Path | None = None,
) -> CanonicalWorkflowExecutionSource:
    workflow_definition = payload.get("workflow_definition")
    if not isinstance(workflow_definition, dict):
        msg = f"Canonical workflow source missing workflow_definition in {workflow_dir}"
        raise RuntimeDelegationError(msg)

    summary = payload.get("workflow_source_summary")
    if not isinstance(summary, dict):
        msg = f"Canonical workflow source missing workflow_source_summary in {workflow_dir}"
        raise RuntimeDelegationError(msg)

    required_keys = {
        "title",
        "description",
        "input_name",
        "input_format",
        "input_description",
        "input_required_fields",
        "output_name",
        "output_format",
        "output_description",
        "output_deliverables",
    }
    missing_keys = sorted(key for key in required_keys if key not in summary)
    if missing_keys:
        msg = (
            "Canonical workflow source is missing runtime summary fields: "
            f"{', '.join(missing_keys)}"
        )
        raise RuntimeDelegationError(msg)
    required_text_keys = (
        "title",
        "description",
        "input_name",
        "input_format",
        "input_description",
        "output_name",
        "output_format",
        "output_description",
    )
    empty_keys = [
        key for key in required_text_keys if not isinstance(summary.get(key), str) or not summary[key].strip()
    ]
    if empty_keys:
        msg = (
            "Canonical workflow source has empty runtime summary fields: "
            f"{', '.join(empty_keys)}"
        )
        raise RuntimeDelegationError(msg)

    return CanonicalWorkflowExecutionSource(
        source_path=source_path,
        source_kind=str(payload.get("workflow_source_kind") or "workflow_definition"),
        source_provenance=str(payload.get("workflow_source_provenance") or "supplied"),
        workflow_definition=workflow_definition,
        summary=summary,
        source_artifact=dict(payload.get("workflow_source_artifact") or {}),
        workflow_derivation_request=dict(payload.get("workflow_derivation_request") or {}),
    )


def _load_execution_source_from_plan(plan_path: Path) -> CanonicalWorkflowExecutionSource:
    try:
        payload = json.loads(plan_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        msg = f"Legacy workflow plan is not readable: {plan_path}"
        raise RuntimeDelegationError(msg) from exc

    if not isinstance(payload, dict):
        msg = f"Legacy workflow plan must be a JSON object: {plan_path}"
        raise RuntimeDelegationError(msg)

    summary = payload.get("workflow_source_summary")
    if not isinstance(summary, dict):
        msg = (
            "Legacy WORKFLOW_PLAN.json fallback is missing workflow_source_summary; "
            f"recompile the workflow to persist a canonical source artifact: {plan_path}"
        )
        raise RuntimeDelegationError(msg)

    return CanonicalWorkflowExecutionSource(
        source_path=plan_path.resolve(),
        source_kind=str(payload.get("workflow_source_kind") or "legacy_workflow_plan"),
        source_provenance=str(payload.get("workflow_source_provenance") or "compatibility_fallback"),
        workflow_definition=_workflow_definition_from_plan(payload),
        summary=summary,
        source_artifact=dict(payload.get("workflow_source_artifact") or {}),
        workflow_derivation_request=dict(payload.get("workflow_derivation_request") or {}),
    )


def _workflow_definition_from_plan(plan_payload: dict[str, Any]) -> dict[str, Any]:
    if isinstance(plan_payload.get("workflow_definition"), dict):
        return dict(plan_payload["workflow_definition"])

    stages: list[dict[str, Any]] = []
    epics = plan_payload.get("epics")
    if not isinstance(epics, list):
        epics = []
    for epic in epics:
        if not isinstance(epic, dict):
            continue
        stories = epic.get("stories")
        if not isinstance(stories, list):
            continue
        for story in stories:
            if not isinstance(story, dict):
                continue
            stages.append(
                {
                    "id": str(story.get("stage_id") or story.get("id") or ""),
                    "title": str(story.get("title") or story.get("description") or ""),
                    "purpose": str(story.get("description") or story.get("title") or ""),
                    "depends_on": _as_string_list(story.get("depends_on")),
                    "inputs": _as_string_list(story.get("inputs")),
                    "outputs": _as_string_list(story.get("outputs")),
                    "rules": _as_string_list(story.get("rules")),
                    "quality_gates": _as_string_list(story.get("quality_gates")),
                    "type": str(story.get("stage_type") or "").strip(),
                    "model_tier": story.get("model_tier"),
                    "provider": story.get("provider"),
                    "model": story.get("model"),
                    "reasoning_level": story.get("reasoning_level"),
                    "auth_method": story.get("auth_method"),
                    "template_asset_bindings": [
                        dict(binding)
                        for binding in story.get("template_asset_bindings", [])
                        if isinstance(binding, dict)
                    ]
                    if isinstance(story.get("template_asset_bindings"), list)
                    else [],
                    "instruction_file": str(story.get("instruction_file") or ""),
                    "quality_loop": (
                        dict(story.get("quality_loop"))
                        if isinstance(story.get("quality_loop"), dict)
                        else None
                    ),
                    "runner_specs": [
                        dict(spec)
                        for spec in story.get("runner_specs", [])
                        if isinstance(spec, dict)
                    ]
                    if isinstance(story.get("runner_specs"), list)
                    else [],
                }
            )
    return {
        "title": str(summary_title(plan_payload)),
        "description": str(summary_description(plan_payload)),
        "quality_dimensions": _as_string_list(plan_payload.get("quality_dimensions")),
        "lifecycle_capabilities": _as_string_list(
            plan_payload.get("lifecycle_capabilities")
        ),
        "lifecycle": (
            dict(plan_payload.get("lifecycle"))
            if isinstance(plan_payload.get("lifecycle"), dict)
            else {}
        ),
        "stages": stages,
    }


def _resolve_delegated_model(
    *,
    execution_source: CanonicalWorkflowExecutionSource,
    plan_path: Path,
    compiled_plan: dict[str, Any] | None = None,
) -> tuple[str | None, str, str | None, list[StageModelBinding] | None]:
    plan_payload = compiled_plan or _load_plan_payload(plan_path)
    bindings = _load_stage_model_bindings(plan_payload)
    if bindings:
        representative = max(bindings, key=_binding_tier_priority)
        if not representative.model:
            raise RuntimeDelegationError(
                f"Stage binding for {representative.stage_id} resolved with no model."
            )
        return (
            representative.provider,
            representative.model,
            representative.reasoning_level,
            bindings,
        )

    aggregated_tier = _resolve_workflow_execution_tier(
        execution_source=execution_source,
        plan_path=plan_path,
    )
    resolved = resolve_tier_config(aggregated_tier, role="implementation")
    resolved_model = str(resolved.get("model") or "").strip()
    if not resolved_model:
        raise RuntimeDelegationError(
            f"resolve_tier_config returned no model for implementation tier '{aggregated_tier}'."
        )
    return (
        str(resolved.get("provider") or "").strip() or None,
        resolved_model,
        str(resolved.get("reasoning_level") or "").strip() or None,
        None,
    )


def _resolve_workflow_execution_tier(
    *,
    execution_source: CanonicalWorkflowExecutionSource,
    plan_path: Path,
) -> str:
    config = load_config()
    execution_tier = _coerce_model_tier(get_config_value(config, "business.llm.execution_tier"))
    if execution_tier is None:
        raise RuntimeDelegationError("business.llm.execution_tier must resolve to a model tier.")
    stage_type_tiers = get_config_value(config, "business.llm.stage_type_tiers")
    if not isinstance(stage_type_tiers, dict):
        raise RuntimeDelegationError("business.llm.stage_type_tiers must be a mapping.")

    stages = execution_source.workflow_definition.get("stages")
    if not isinstance(stages, list) or not stages:
        return execution_tier

    story_metadata = _load_story_metadata(plan_path)
    effective_tiers: list[str] = []
    total_stages = len(stages)
    for index, raw_stage in enumerate(stages, start=1):
        if not isinstance(raw_stage, Mapping):
            continue
        stage = dict(raw_stage)
        stage_id = str(stage.get("id") or stage.get("stage_id") or "").strip()
        metadata = story_metadata.get(stage_id, {})
        explicit_tier = _coerce_model_tier(stage.get("model_tier")) or _coerce_model_tier(
            metadata.get("model_tier")
        )
        if explicit_tier is not None:
            effective_tiers.append(explicit_tier)
            continue

        resolved_stage_type = _resolve_stage_type(
            stage=stage,
            story_metadata=metadata,
            index=index,
            total=total_stages,
        )
        raw_stage_type_tier = stage_type_tiers.get(resolved_stage_type)
        configured_tier = (
            _coerce_model_tier(
                normalize_stage_type_tier_entry(raw_stage_type_tier).get("model_tier")
            )
            if raw_stage_type_tier is not None
            else None
        )
        effective_tiers.append(configured_tier or execution_tier)

    if not effective_tiers:
        return execution_tier
    return max(effective_tiers, key=lambda tier: _TIER_PRIORITY[tier])


def _load_story_metadata(plan_path: Path) -> dict[str, dict[str, Any]]:
    payload = _load_plan_payload(plan_path)
    story_metadata = _story_metadata_from_payload(payload)
    normalized: dict[str, dict[str, Any]] = {}
    for stage_id, story in story_metadata.items():
        normalized[stage_id] = {
            "stage_type": str(story.get("stage_type") or "").strip() or None,
            "model_tier": story.get("model_tier"),
            "provider": story.get("provider"),
            "model": story.get("model"),
            "reasoning_level": story.get("reasoning_level"),
            "auth_method": story.get("auth_method"),
            "runner_specs": [
                dict(spec)
                for spec in story.get("runner_specs", [])
                if isinstance(spec, dict)
            ]
            if isinstance(story.get("runner_specs"), list)
            else [],
        }
    return normalized


def run_stage_complexity_estimation(
    *,
    compiled_plan: dict[str, Any],
    config: dict[str, Any],
    execution_source: CanonicalWorkflowExecutionSource,
    workflow_dir: Path,
    plan_path: Path,
) -> tuple[str, list[Any] | None]:
    """Run or reuse per-stage complexity estimation for the workflow."""
    workflow_content_hash = _compute_workflow_content_hash(execution_source.workflow_definition)
    estimator_enabled = bool(
        get_config_value(config, "business.complexity.estimator.enabled")
    )
    if not estimator_enabled:
        return workflow_content_hash, None

    cached_grades = load_cached_grades(compiled_plan, execution_source.workflow_definition)
    if cached_grades is not None:
        return workflow_content_hash, cached_grades

    try:
        pipeline = build_preexecution_pipeline(
            workflow_dir,
            "stage_complexity_gate",
            max_retries=int(get_config_value(config, "business.complexity.estimator.max_retries")),
        )
        gate = StageComplexityGate(config)
        grades = asyncio.run(gate.assess(compiled_plan, pipeline))
    except StageComplexityAssessmentError as exc:
        logger.warning("Stage complexity assessment failed: %s", exc)
        return workflow_content_hash, None
    except Exception as exc:
        logger.warning("Stage complexity estimator failed: %s", exc)
        return workflow_content_hash, None

    compiled_plan["complexity_grades"] = {
        "workflow_content_hash": workflow_content_hash,
        "graded_at": datetime.now(UTC).isoformat(),
        "grades": [
            {
                "stage_id": grade.stage_id,
                "grade": grade.grade,
                "rationale": grade.rationale,
            }
            for grade in grades
        ],
    }
    _write_plan_payload(plan_path, compiled_plan)
    return workflow_content_hash, grades


def enforce_crosswalk_confirmation(
    *,
    compiled_plan: dict[str, Any],
    config: dict[str, Any],
    execution_source: CanonicalWorkflowExecutionSource,
    workflow_dir: Path,
    workflow_id: str,
    workflow_content_hash: str,
    grades: list[Any] | None,
) -> CrossWalk | None:
    """Load, build, or gate the workflow crosswalk before delegated execution."""
    if not grades:
        return None

    registry = ProviderRegistry(get_gateway_onboarding_config().get("providers"))
    available, available_hash = enumerate_available_models(registry)
    existing = load_crosswalk(workflow_dir, workflow_id)
    crosswalk = existing
    if (
        crosswalk is None
        or crosswalk.workflow_content_hash != workflow_content_hash
        or crosswalk.available_models_hash != available_hash
    ):
        crosswalk = build_crosswalk(
            grades=grades,
            available=available,
            available_hash=available_hash,
            workflow_content_hash=workflow_content_hash,
            config=config,
        )
        crosswalk = carry_forward_confirmation(existing, crosswalk)
        if not bool(get_config_value(config, "business.crosswalk.enforce_confirmation")):
            crosswalk = auto_confirm_crosswalk(crosswalk)
            save_crosswalk(workflow_dir, workflow_id, crosswalk)
            return crosswalk
        if confirmed_crosswalk(crosswalk):
            save_crosswalk(workflow_dir, workflow_id, crosswalk)
            return crosswalk
        save_crosswalk(workflow_dir, workflow_id, crosswalk)
        path = crosswalk_path(workflow_dir, workflow_id)
        _emit_hybrid_event(
            "crosswalk_awaiting_confirmation",
            workflow_id=workflow_id,
            path=str(path),
            grades_count=len(grades),
            available_models_count=len(available),
        )
        raise CrossWalkConfirmationRequired(path, workflow_id, crosswalk)

    if not bool(get_config_value(config, "business.crosswalk.enforce_confirmation")):
        if not confirmed_crosswalk(crosswalk):
            crosswalk = auto_confirm_crosswalk(crosswalk)
            save_crosswalk(workflow_dir, workflow_id, crosswalk)
        return crosswalk

    if confirmed_crosswalk(crosswalk):
        return crosswalk

    path = crosswalk_path(workflow_dir, workflow_id)
    _emit_hybrid_event(
        "crosswalk_awaiting_confirmation",
        workflow_id=workflow_id,
        path=str(path),
        grades_count=len(grades),
        available_models_count=len(available),
    )
    raise CrossWalkConfirmationRequired(path, workflow_id, crosswalk)


def resolve_runtime_stage_model_bindings(
    *,
    compiled_plan: dict[str, Any],
    config: dict[str, Any],
    execution_source: CanonicalWorkflowExecutionSource,
    crosswalk: CrossWalk | None,
    grades: list[Any] | None,
    workflow_content_hash: str,
) -> list[StageModelBinding] | None:
    """Resolve the final per-stage binding list for delegated execution."""
    stages = execution_source.workflow_definition.get("stages")
    if not isinstance(stages, list) or not stages:
        return None

    stage_type_tiers = get_config_value(config, "business.llm.stage_type_tiers")
    story_metadata = _story_metadata_from_payload(compiled_plan)
    grades_by_stage = {
        str(getattr(grade, "stage_id", None) or grade.get("stage_id") or "").strip(): grade
        for grade in grades or []
        if str(getattr(grade, "stage_id", None) or grade.get("stage_id") or "").strip()
    }

    bindings: list[StageModelBinding] = []
    for index, raw_stage in enumerate(stages, start=1):
        if not isinstance(raw_stage, Mapping):
            continue
        stage = dict(raw_stage)
        stage_id = str(stage.get("id") or stage.get("stage_id") or "").strip()
        if not stage_id:
            continue
        metadata = story_metadata.get(stage_id, {})
        merged_stage = {
            **metadata,
            **stage,
            "id": stage_id,
            "stage_id": stage_id,
            "type": _resolve_stage_type(
                stage=stage,
                story_metadata=metadata,
                index=index,
                total=len(stages),
            ),
        }
        binding = resolve_stage_binding(
            merged_stage,
            crosswalk,
            grades_by_stage.get(stage_id),
            stage_type_tiers,
            config,
        )
        bindings.append(binding)

    if not bindings:
        return None
    compiled_plan["workflow_content_hash"] = workflow_content_hash
    return bindings


def write_stage_model_bindings_payload(
    *,
    workflow_dir: Path,
    workflow_content_hash: str,
    bindings: list[StageModelBinding] | None,
) -> Path | None:
    """Persist the binding payload consumed by the delegated execute handler."""
    if not bindings:
        return None
    workspace = workflow_dir / ".obra-biz" / "session-workspace"
    workspace.mkdir(parents=True, exist_ok=True)
    payload_path = workspace / "stage_model_bindings.json"
    payload = {
        "workflow_content_hash": workflow_content_hash,
        "bindings": [binding.to_dict() for binding in bindings],
    }
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return payload_path


def _load_stage_model_bindings(compiled_plan: dict[str, Any]) -> list[StageModelBinding] | None:
    raw_bindings = compiled_plan.get("stage_model_bindings")
    if not isinstance(raw_bindings, list) or not raw_bindings:
        return None
    bindings = [
        StageModelBinding.from_dict(binding)
        for binding in raw_bindings
        if isinstance(binding, dict)
    ]
    return [binding for binding in bindings if binding.stage_id and binding.model] or None


def _binding_tier_priority(binding: StageModelBinding) -> int:
    tier = binding.model_tier
    if tier not in _TIER_PRIORITY and binding.provider and binding.model:
        tier = resolve_quality_tier(binding.provider, binding.model)
    return _TIER_PRIORITY.get(str(tier), _TIER_PRIORITY["medium"])


def _load_plan_payload(plan_path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(plan_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeDelegationError(f"Compiled workflow plan is not readable: {plan_path}") from exc
    if not isinstance(payload, dict):
        raise RuntimeDelegationError(f"Compiled workflow plan must be a JSON object: {plan_path}")
    return payload


def _write_plan_payload(plan_path: Path, payload: dict[str, Any]) -> None:
    plan_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _story_metadata_from_payload(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    story_metadata: dict[str, dict[str, Any]] = {}
    epics = payload.get("epics")
    if not isinstance(epics, list):
        return story_metadata
    for epic in epics:
        if not isinstance(epic, dict):
            continue
        stories = epic.get("stories")
        if not isinstance(stories, list):
            continue
        for story in stories:
            if not isinstance(story, dict):
                continue
            stage_id = str(story.get("stage_id") or story.get("id") or "").strip()
            if not stage_id:
                continue
            story_metadata[stage_id] = dict(story)
    return story_metadata


def _emit_hybrid_event(event_type: str, **payload: Any) -> None:
    logger_instance = HybridEventLogger(log_path=get_runtime_log_paths().hybrid_log)
    logger_instance.log_event(event_type, **payload)


def _plan_requests_parallel_execution(*, plan_path: Path, config: dict[str, Any]) -> bool:
    """Return whether the delegated runtime should request core parallel execution."""
    if not get_parallel_execution_enabled(config):
        return False
    try:
        payload = json.loads(plan_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    if not isinstance(payload, dict):
        return False
    epics = payload.get("epics")
    if not isinstance(epics, list):
        return False
    for epic in epics:
        if not isinstance(epic, dict):
            continue
        stories = epic.get("stories")
        if not isinstance(stories, list):
            continue
        for story in stories:
            if isinstance(story, dict) and story.get("parallel_group") is not None:
                return True
    return False


def _coerce_model_tier(value: Any) -> str | None:
    if value is None:
        return None
    tier = str(value).strip()
    if not tier:
        return None
    if tier not in MODEL_TIER_VALUES:
        raise RuntimeDelegationError(f"Unsupported model tier: {tier}")
    return tier


def _resolve_stage_type(
    *,
    stage: Mapping[str, Any],
    story_metadata: Mapping[str, Any],
    index: int,
    total: int,
) -> str:
    for candidate in (
        stage.get("type"),
        stage.get("stage_type"),
        story_metadata.get("stage_type"),
    ):
        stage_type = str(candidate or "").strip()
        if stage_type:
            return stage_type
    return _synthesize_stage_type(stage, index=index, total=total)


def _synthesize_stage_type(stage: Mapping[str, Any], *, index: int, total: int) -> str:
    title = (
        f"{stage.get('title', '')} {stage.get('name', '')} "
        f"{stage.get('purpose', '')} {stage.get('description', '')}"
    ).lower()
    if index == 1:
        return "input_validation"
    if index == total:
        return "output"
    if "quality" in title or "review" in title:
        return "quality_gate"
    if "decision" in title or "approve" in title:
        return "decision"
    if "enrich" in title:
        return "enrichment"
    if "transform" in title or "normalize" in title:
        return "transformation"
    return "generation"


def _render_stage_contract(stage: dict[str, Any]) -> str:
    stage_id = str(stage.get("id") or stage.get("stage_id") or "<unknown>").strip()
    stage_title = str(stage.get("title") or stage.get("name") or stage_id).strip()
    stage_purpose = str(stage.get("purpose") or stage.get("description") or stage_title).strip()
    dependencies = ", ".join(_as_string_list(stage.get("depends_on"))) or "none"
    inputs = ", ".join(_as_string_list(stage.get("inputs"))) or "upstream workflow input"
    outputs = ", ".join(_as_string_list(stage.get("outputs"))) or "stage output"
    instruction_path = _resolve_stage_instruction_path(stage)
    instruction_detail = instruction_path or "no stage markdown binding provided"
    quality_loop = _render_quality_loop(stage.get("quality_loop"))
    return (
        f"- {stage_id} {stage_title}: {stage_purpose}. "
        f"Depends on: {dependencies}. Inputs: {inputs}. Outputs: {outputs}. "
        f"Instruction asset: {instruction_detail}. Quality loop: {quality_loop}."
    )


def _resolve_stage_instruction_path(stage: dict[str, Any]) -> str:
    explicit_instruction = str(stage.get("instruction_file") or "").strip()
    if explicit_instruction:
        return explicit_instruction

    workflow_version = (
        str(stage.get("workflow_version") or stage.get("version") or "").strip() or None
    )
    bindings_by_stage = normalize_template_bindings(
        {"stages": [stage]},
        workflow_version=workflow_version,
    )
    stage_id = str(stage.get("id") or "").strip()
    primary_binding = choose_primary_instruction_binding(bindings_by_stage.get(stage_id, []))
    if primary_binding is not None:
        return str(
            primary_binding.materialization_metadata.get("path")
            or primary_binding.path_hint
            or primary_binding.target_artifact_id
            or ""
        ).strip()

    stage_assets = stage.get("stage_assets")
    if isinstance(stage_assets, list):
        for asset in stage_assets:
            asset_path = str(asset or "").strip()
            if asset_path:
                return asset_path
    return ""


def _render_quality_loop(value: Any) -> str:
    if not isinstance(value, dict):
        return "default business-domain review loop"
    routing = value.get("routing")
    if not isinstance(routing, dict) or not routing:
        return "canonical quality_loop present"
    preferred_keys = (
        "on_pass",
        "on_advisory_pass",
        "on_revise_required",
        "on_block",
        "on_escalate",
        "on_pending_manual",
        "on_manual_resume",
    )
    parts = [
        f"{key[3:]}={routing[key]}"
        for key in preferred_keys
        if isinstance(routing.get(key), str) and str(routing[key]).strip()
    ]
    return ", ".join(parts) if parts else "canonical quality_loop present"


def _as_string_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return []


def summary_title(plan_payload: dict[str, Any]) -> str:
    summary = plan_payload.get("workflow_source_summary")
    if isinstance(summary, dict):
        title = str(summary.get("title") or "").strip()
        if title:
            return title
    return str(plan_payload.get("work_id") or "business workflow").strip()


def summary_description(plan_payload: dict[str, Any]) -> str:
    summary = plan_payload.get("workflow_source_summary")
    if isinstance(summary, dict):
        description = str(summary.get("description") or "").strip()
        if description:
            return description
    return ""


def _resolve_and_validate_input_path(path: Path, *, label: str) -> Path:
    try:
        resolved = path.resolve(strict=True)
    except FileNotFoundError as exc:
        msg = f"{label.capitalize()} input file not found: {path}"
        raise RuntimeDelegationError(msg) from exc

    if not resolved.is_file():
        msg = f"{label.capitalize()} input path is not a file: {resolved}"
        raise RuntimeDelegationError(msg)
    if not os.access(resolved, os.R_OK):
        msg = f"{label.capitalize()} input file is not readable: {resolved}"
        raise RuntimeDelegationError(msg)
    return resolved


__all__ = [
    "CanonicalWorkflowExecutionSource",
    "DelegatedRunResult",
    "PreparedDelegatedRun",
    "RuntimeDelegationError",
    "RuntimeLogPaths",
    "build_delegated_command",
    "build_delegated_environment",
    "build_runtime_objective",
    "copy_runtime_input",
    "execute_delegated_run",
    "get_runtime_log_paths",
    "prepare_delegated_run",
    "resolve_canonical_execution_source",
]
