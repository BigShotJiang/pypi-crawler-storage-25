"""Publish a compiled business workflow to the server's workflow registry.

ADR-101's pipeline_only per-story dispatch resolves the compiled workflow
through the ``workflow_baseline`` ref, which points to a record persisted
at ``users/{uid}/workflows/{workflow_id}/revisions/{revision_id}`` per
ADR-097. Without that record the server's
``functions/src/pipeline/story_dispatch_queue.py::load_compiled_workflow_stages``
raises ``workflow record <id>@<rev> not found`` and the on_start shim
fails.

This module is the canonical client-side entry point for that publication
step. It turns a compiled WORKFLOW_PLAN.json into a
``WorkflowCandidateEnvelope`` whose ``workflow_definition`` carries:

* the canonical W2-shaped stages (``id``, ``title``, ``purpose``,
  ``inputs``, ``outputs``, ``depends_on``, ``template_asset_bindings``)
  taken from the compiled plan's ``workflow_derivation_request.baseline_workflow_ref.metadata``
  bundle, so the W2 mutation engine accepts the candidate without
  hitting workflow-level fail issues, and
* a ``runner_specs`` list per stage merged in from the compiled stories
  (``epics[].stories[]``) so the per-story dispatch on the server can
  resolve a runner for each stage per ADR-101 Invariant 1.

The helper is idempotent: when the workflow head already exists and its
``workflow_content_hash`` matches the compiled plan, no new revision is
written.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass
from typing import Any

from obra.api import APIClient
from obra.api.protocol_workflow import WorkflowCandidateEnvelope
from obra.exceptions import APIError
from obra_business.runner_specs import normalize_business_stage_runner_specs

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PublishedWorkflowRevision:
    """Outcome of a workflow-revision publish operation."""

    workflow_id: str
    revision_id: str
    created: bool


class WorkflowPublicationError(RuntimeError):
    """Raised when the workflow revision cannot be published."""


def persist_published_workflow_revision(plan_file: Any, revision_id: str) -> None:
    """Update imported-plan workflow refs to the revision actually published."""
    from pathlib import Path

    revision_id = str(revision_id or "").strip()
    if not revision_id:
        return
    plan_path = Path(plan_file)
    try:
        plan_data = json.loads(plan_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return
    if not isinstance(plan_data, dict):
        return

    changed = False
    if str(plan_data.get("revision_id") or "").strip() != revision_id:
        plan_data["revision_id"] = revision_id
        changed = True

    source_artifact = plan_data.get("workflow_source_artifact")
    if isinstance(source_artifact, dict):
        if str(source_artifact.get("version") or "").strip() != revision_id:
            source_artifact["version"] = revision_id
            changed = True

    derivation = plan_data.get("workflow_derivation_request")
    if isinstance(derivation, dict):
        baseline_ref = derivation.get("baseline_workflow_ref")
        if isinstance(baseline_ref, dict):
            if str(baseline_ref.get("target_version_selector") or "").strip() != revision_id:
                baseline_ref["target_version_selector"] = revision_id
                changed = True

    if changed:
        plan_path.write_text(json.dumps(plan_data, indent=2), encoding="utf-8")


def build_candidate_from_compiled_plan(
    plan: Mapping[str, Any],
) -> dict[str, Any]:
    """Build a WorkflowCandidateEnvelope payload from a compiled plan.

    The candidate's ``workflow_definition.stages`` list contains one
    entry per compiled story, with the canonical baseline stage fields
    spliced in from the plan's
    ``workflow_derivation_request.baseline_workflow_ref.metadata`` bundle
    so each stage carries both its W2 metadata (``purpose``, ``inputs``,
    ``outputs``, ``template_asset_bindings``) and its runtime
    ``runner_specs``.
    """
    source_artifact = plan.get("workflow_source_artifact")
    source_artifact_map: Mapping[str, Any] = (
        source_artifact if isinstance(source_artifact, Mapping) else {}
    )
    workflow_id = str(
        source_artifact_map.get("artifact_id")
        or plan.get("workflow_id")
        or plan.get("work_id")
        or ""
    ).strip()
    if not workflow_id:
        raise WorkflowPublicationError("Compiled plan is missing 'work_id'")

    summary = plan.get("workflow_source_summary")
    summary_map: Mapping[str, Any] = summary if isinstance(summary, Mapping) else {}

    derivation = plan.get("workflow_derivation_request")
    derivation_map: Mapping[str, Any] = (
        derivation if isinstance(derivation, Mapping) else {}
    )
    baseline_ref = derivation_map.get("baseline_workflow_ref")
    baseline_ref_map: Mapping[str, Any] = (
        baseline_ref if isinstance(baseline_ref, Mapping) else {}
    )
    baseline_metadata = baseline_ref_map.get("metadata")
    baseline_meta_map: Mapping[str, Any] = (
        baseline_metadata if isinstance(baseline_metadata, Mapping) else {}
    )

    title = str(
        summary_map.get("title")
        or baseline_meta_map.get("title")
        or workflow_id
    ).strip()
    description = str(
        summary_map.get("description")
        or baseline_meta_map.get("description")
        or ""
    ).strip()
    domain_id = str(
        summary_map.get("domain_id")
        or baseline_meta_map.get("domain_id")
        or "business"
    ).strip()
    version = str(baseline_meta_map.get("version") or "1.0.0")

    baseline_stages = baseline_meta_map.get("stages")
    baseline_stage_index: dict[str, Mapping[str, Any]] = {}
    if isinstance(baseline_stages, list):
        for entry in baseline_stages:
            if not isinstance(entry, Mapping):
                continue
            stage_id = str(entry.get("id") or "").strip()
            if stage_id:
                baseline_stage_index[stage_id] = entry

    stages: list[dict[str, Any]] = []
    for epic in plan.get("epics") or []:
        if not isinstance(epic, Mapping):
            continue
        for story in epic.get("stories") or []:
            if not isinstance(story, Mapping):
                continue
            stages.append(
                _merge_stage_definition(
                    compiled_story=story,
                    baseline_stage=baseline_stage_index.get(
                        str(story.get("stage_id") or "").strip()
                    ),
                )
            )

    if not stages:
        raise WorkflowPublicationError(
            f"Compiled plan {workflow_id} has no stages to publish"
        )

    workflow_definition: dict[str, Any] = {
        "workflow_id": workflow_id,
        "title": title,
        "description": description,
        "domain_id": domain_id,
        "version": version,
        "stages": stages,
    }

    for key in (
        "quality_dimensions",
        "lifecycle_capabilities",
        "lifecycle",
        "template_asset_bindings",
    ):
        value = baseline_meta_map.get(key)
        if value is None:
            value = summary_map.get(key)
        if value is not None:
            workflow_definition[key] = deepcopy(value)

    input_document = baseline_meta_map.get("input_document")
    output_document = baseline_meta_map.get("output_document")
    if isinstance(input_document, Mapping):
        workflow_definition["input_document"] = deepcopy(dict(input_document))
    if isinstance(output_document, Mapping):
        workflow_definition["output_document"] = deepcopy(dict(output_document))

    metadata: dict[str, Any] = {}
    content_hash = plan.get("workflow_content_hash")
    if isinstance(content_hash, str) and content_hash.strip():
        metadata["workflow_content_hash"] = content_hash.strip()
    metadata["workflow_version"] = version
    metadata["source"] = "obra_business_run"

    envelope = WorkflowCandidateEnvelope(
        workflow_id=workflow_id,
        title=title,
        description=description,
        domain_id=domain_id,
        workflow_definition=workflow_definition,
        metadata=metadata,
    )
    return envelope.to_dict()


def publish_workflow_revision(
    *,
    client: APIClient,
    plan: Mapping[str, Any],
) -> PublishedWorkflowRevision:
    """Publish (create or update) a workflow revision for the compiled plan.

    Returns the resolved ``(workflow_id, revision_id)`` and a ``created``
    flag indicating whether a new revision was written. Raises
    :class:`WorkflowPublicationError` when the candidate is malformed,
    when the W2 mutation engine rejects the apply with blocking issues,
    or when the server returns no revision identifier.
    """
    candidate = build_candidate_from_compiled_plan(plan)
    workflow_id = str(candidate.get("workflow_id") or "").strip()
    if not workflow_id:
        raise WorkflowPublicationError(
            "Built candidate has no workflow_id"
        )

    head = _try_get_workflow_head(client, workflow_id)
    if head is not None:
        _preserve_head_runtime_metadata(candidate, head)
        head_revision_id = str(head.get("revision_id") or "").strip()
        if _content_matches(head, candidate):
            return PublishedWorkflowRevision(
                workflow_id=workflow_id,
                revision_id=head_revision_id,
                created=False,
            )
        result = client.apply_workflow_candidate(
            candidate,
            expected_revision_id=head_revision_id,
        )
    else:
        result = client.create_workflow(candidate)

    outcome = str(result.get("outcome") or "").strip().lower()
    workflow = result.get("workflow") if isinstance(result, dict) else None
    if outcome != "accepted":
        validation = result.get("validation_summary") if isinstance(result, dict) else None
        raise WorkflowPublicationError(
            f"Workflow publish for {workflow_id} returned outcome={outcome!r}: "
            f"{validation}"
        )

    new_revision_id = ""
    if isinstance(workflow, Mapping):
        new_revision_id = str(workflow.get("revision_id") or "").strip()
    if not new_revision_id:
        raise WorkflowPublicationError(
            f"Workflow publish for {workflow_id} returned no revision_id"
        )
    return PublishedWorkflowRevision(
        workflow_id=workflow_id,
        revision_id=new_revision_id,
        created=True,
    )


def _merge_stage_definition(
    *,
    compiled_story: Mapping[str, Any],
    baseline_stage: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Merge a baseline stage's W2 metadata with a compiled story's runtime fields."""
    stage: dict[str, Any] = {}
    if baseline_stage is not None:
        stage.update(deepcopy(dict(baseline_stage)))

    stage_id = str(
        compiled_story.get("stage_id")
        or (baseline_stage.get("id") if baseline_stage is not None else "")
        or compiled_story.get("id")
        or ""
    ).strip()
    if stage_id:
        stage["id"] = stage_id

    title = str(
        (baseline_stage.get("title") if baseline_stage is not None else "")
        or compiled_story.get("title")
        or stage_id
    ).strip()
    if title:
        stage["title"] = title

    if baseline_stage is None or not str(baseline_stage.get("purpose") or "").strip():
        purpose = _derive_stage_purpose(compiled_story)
        if purpose:
            stage["purpose"] = purpose

    stage["runner_specs"] = normalize_business_stage_runner_specs(
        compiled_story.get("runner_specs"),
        repair_legacy_docs_placeholder=True,
    )

    # ``instruction_file`` and ``stage_assets`` are removed fields per the
    # canonical template-asset model — server-side
    # ``StageArtifactResolver.removed_stage_asset_fields`` raises on
    # either, so the published candidate must rely on the baseline
    # stage's ``template_asset_bindings`` (already copied above) for the
    # primary instruction binding rather than carrying the runtime path.
    for key in (
        "stage_type",
        "model_tier",
        "provider",
        "model",
        "reasoning_level",
        "auth_method",
        "quality_loop",
        "depends_on",
        "parallel_group",
        "topological_level",
        "failure_policy",
    ):
        value = compiled_story.get(key)
        if value is None:
            continue
        if isinstance(value, list) and not value and key in stage:
            continue
        stage[key] = deepcopy(value) if isinstance(value, (list, dict)) else value

    return stage


def _derive_stage_purpose(compiled_story: Mapping[str, Any]) -> str:
    """Pick a non-empty purpose string from a compiled story's task descriptions."""
    tasks = compiled_story.get("tasks")
    if isinstance(tasks, list):
        for task in tasks:
            if not isinstance(task, Mapping):
                continue
            desc = str(task.get("desc") or "").strip()
            if desc:
                return desc
    return str(compiled_story.get("title") or "").strip()


def _try_get_workflow_head(client: APIClient, workflow_id: str) -> dict[str, Any] | None:
    try:
        response = client.get_workflow(workflow_id)
    except APIError as exc:
        if exc.status_code == 404:
            return None
        raise
    if not isinstance(response, dict):
        return None
    workflow = response.get("workflow")
    if isinstance(workflow, dict) and workflow.get("workflow_id"):
        return workflow
    return None


def _preserve_head_runtime_metadata(
    candidate: dict[str, Any],
    head: Mapping[str, Any],
) -> None:
    """Carry runtime-only head fields that compiled plans may not contain.

    Runtime publication repairs runner specs from compiled plans, but imported
    plans can lack W2 template asset bindings. Dropping those bindings makes the
    next Studio launch fail even though the template files are still present.
    """
    head_metadata = head.get("metadata")
    candidate_metadata = candidate.setdefault("metadata", {})
    if isinstance(head_metadata, Mapping) and isinstance(candidate_metadata, dict):
        working_dir = str(head_metadata.get("working_dir") or "").strip()
        if working_dir and not str(candidate_metadata.get("working_dir") or "").strip():
            candidate_metadata["working_dir"] = working_dir

    head_def = head.get("workflow_definition")
    candidate_def = candidate.get("workflow_definition")
    if not isinstance(head_def, Mapping) or not isinstance(candidate_def, dict):
        return

    head_top_bindings = head_def.get("template_asset_bindings")
    if (
        isinstance(head_top_bindings, list)
        and head_top_bindings
        and not candidate_def.get("template_asset_bindings")
    ):
        candidate_def["template_asset_bindings"] = deepcopy(head_top_bindings)

    head_stages = head_def.get("stages")
    candidate_stages = candidate_def.get("stages")
    if not isinstance(head_stages, list) or not isinstance(candidate_stages, list):
        return
    head_stage_index = {
        str(stage.get("id") or stage.get("stage_id") or "").strip(): stage
        for stage in head_stages
        if isinstance(stage, Mapping)
        and str(stage.get("id") or stage.get("stage_id") or "").strip()
    }
    for candidate_stage in candidate_stages:
        if not isinstance(candidate_stage, dict):
            continue
        stage_id = str(
            candidate_stage.get("id") or candidate_stage.get("stage_id") or ""
        ).strip()
        head_stage = head_stage_index.get(stage_id)
        if head_stage is None:
            continue
        head_bindings = head_stage.get("template_asset_bindings")
        if (
            isinstance(head_bindings, list)
            and head_bindings
            and not candidate_stage.get("template_asset_bindings")
        ):
            candidate_stage["template_asset_bindings"] = deepcopy(head_bindings)


def _content_matches(
    head: Mapping[str, Any],
    candidate: Mapping[str, Any],
) -> bool:
    head_meta = head.get("metadata")
    head_meta_map: Mapping[str, Any] = (
        head_meta if isinstance(head_meta, Mapping) else {}
    )
    candidate_meta = candidate.get("metadata")
    candidate_meta_map: Mapping[str, Any] = (
        candidate_meta if isinstance(candidate_meta, Mapping) else {}
    )
    head_hash = str(head_meta_map.get("workflow_content_hash") or "").strip()
    candidate_hash = str(candidate_meta_map.get("workflow_content_hash") or "").strip()
    head_def = head.get("workflow_definition")
    candidate_def = candidate.get("workflow_definition")
    if head_hash and candidate_hash:
        return (
            head_hash == candidate_hash
            and _runtime_stage_signature(head_def) == _runtime_stage_signature(candidate_def)
        )

    return _stages_signature(head_def) == _stages_signature(candidate_def)


def _runtime_stage_signature(workflow_definition: Any) -> str:
    if not isinstance(workflow_definition, Mapping):
        return ""
    stages = workflow_definition.get("stages")
    if not isinstance(stages, list):
        return ""
    signature: list[dict[str, Any]] = []
    for stage in stages:
        if not isinstance(stage, Mapping):
            continue
        stage_id = str(stage.get("id") or stage.get("stage_id") or "").strip()
        runner_specs = stage.get("runner_specs")
        normalized_specs = (
            [dict(spec) for spec in runner_specs if isinstance(spec, Mapping)]
            if isinstance(runner_specs, list)
            else []
        )
        template_asset_bindings = stage.get("template_asset_bindings")
        normalized_bindings = (
            [dict(binding) for binding in template_asset_bindings if isinstance(binding, Mapping)]
            if isinstance(template_asset_bindings, list)
            else []
        )
        signature.append(
            {
                "id": stage_id,
                "runner_specs": normalized_specs,
                "template_asset_bindings": normalized_bindings,
            }
        )
    return json.dumps(signature, sort_keys=True, default=str)


def _stages_signature(workflow_definition: Any) -> str:
    if not isinstance(workflow_definition, Mapping):
        return ""
    stages = workflow_definition.get("stages")
    if not isinstance(stages, list):
        return ""
    return json.dumps(stages, sort_keys=True, default=str)
