"""LLM-backed stage complexity estimation for business workflows."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from inspect import isawaitable
from typing import Any

from obra.config.tier_resolution import resolve_tier_config
from obra.hybrid.derivation import TEMPLATE_FALLBACK_STATUSES
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline

from obra_business.config.loader import get_config_value

logger = logging.getLogger(__name__)

STAGE_COMPLEXITY_TEMPLATE_SCHEMA = {
    "grades": [
        {
            "stage_id": "",
            "grade": "",
            "rationale": "",
        }
    ],
    "_instructions": (
        "Return one entry per stage.\n"
        "Set grade to exactly one of: low, medium, high.\n"
        "Each rationale must be non-empty and concise.\n"
        "Do not omit stages."
    ),
}

STAGE_COMPLEXITY_PROMPT_TEMPLATE = """Assess the implementation complexity of each workflow stage.

Workflow:
- Title: {workflow_title}
- Description: {workflow_description}

Dependencies:
{dependency_lines}

Stages:
{stage_lines}
"""


@dataclass(frozen=True)
class StageComplexityGrade:
    """Structured per-stage complexity grade."""

    stage_id: str
    grade: str
    rationale: str


class StageComplexityAssessmentError(RuntimeError):
    """Raised when the stage complexity gate cannot produce valid structured output."""


def get_complexity_estimator_llm_config(config: dict[str, Any]) -> dict[str, Any]:
    """Resolve estimator LLM config from the business config surface."""
    resolved = resolve_tier_config("medium", role="orchestrator")
    estimator_config = get_config_value(config, "business.complexity.estimator")
    if not isinstance(estimator_config, dict):
        raise ValueError("business.complexity.estimator must be a mapping")

    provider = _normalized_or_none(estimator_config.get("provider")) or resolved.get("provider")
    model = _normalized_or_none(estimator_config.get("model")) or resolved.get("model")
    auth_method = resolved.get("auth_method")
    reasoning_level = (
        _normalized_or_none(estimator_config.get("reasoning_level"))
        or resolved.get("reasoning_level")
    )
    return {
        "provider": provider,
        "model": model,
        "auth_method": auth_method,
        "reasoning_level": reasoning_level,
    }


class StageComplexityGate:
    """Estimate low/medium/high complexity for each workflow stage."""

    def __init__(self, config: dict[str, Any]) -> None:
        self._config = config

    async def assess(
        self,
        compiled_plan: dict[str, Any],
        pipeline: TemplateEditPipeline,
    ) -> list[StageComplexityGrade]:
        """Assess stage complexity from a compiled workflow plan."""
        workflow = _workflow_summary_from_compiled_plan(compiled_plan)
        stages = workflow["stages"]
        if not stages:
            return []

        max_input_tokens = _as_positive_int(
            get_config_value(self._config, "business.complexity.estimator.max_input_tokens"),
            "business.complexity.estimator.max_input_tokens",
        )
        detail_batch_size = _as_positive_int(
            get_config_value(self._config, "business.complexity.estimator.detail_batch_size"),
            "business.complexity.estimator.detail_batch_size",
        )
        timeout_s = _as_positive_int(
            get_config_value(self._config, "business.complexity.estimator.timeout_s"),
            "business.complexity.estimator.timeout_s",
        )
        max_retries = _as_non_negative_int(
            get_config_value(self._config, "business.complexity.estimator.max_retries"),
            "business.complexity.estimator.max_retries",
        )
        llm_config = get_complexity_estimator_llm_config(self._config)

        full_prompt = _build_complexity_prompt(
            workflow_title=workflow["title"],
            workflow_description=workflow["description"],
            stages=stages,
            detailed=True,
        )
        if _estimate_prompt_tokens(full_prompt) <= max_input_tokens:
            return await self._run_prompt(
                pipeline=pipeline,
                prompt=full_prompt,
                stage_ids=[stage["stage_id"] for stage in stages],
                llm_config=llm_config,
                timeout_s=timeout_s,
                max_retries=max_retries,
            )

        triage_prompt = _build_complexity_prompt(
            workflow_title=workflow["title"],
            workflow_description=workflow["description"],
            stages=stages,
            detailed=False,
        )
        triage = await self._run_prompt(
            pipeline=pipeline,
            prompt=triage_prompt,
            stage_ids=[stage["stage_id"] for stage in stages],
            llm_config=llm_config,
            timeout_s=timeout_s,
            max_retries=max_retries,
        )
        merged = {grade.stage_id: grade for grade in triage}
        detail_candidates = [stage for stage in stages if merged[stage["stage_id"]].grade != "low"]
        for batch_start in range(0, len(detail_candidates), detail_batch_size):
            batch = detail_candidates[batch_start : batch_start + detail_batch_size]
            detail_prompt = _build_complexity_prompt(
                workflow_title=workflow["title"],
                workflow_description=workflow["description"],
                stages=batch,
                detailed=True,
            )
            details = await self._run_prompt(
                pipeline=pipeline,
                prompt=detail_prompt,
                stage_ids=[stage["stage_id"] for stage in batch],
                llm_config=llm_config,
                timeout_s=timeout_s,
                max_retries=max_retries,
            )
            for grade in details:
                merged[grade.stage_id] = grade
        return [merged[stage["stage_id"]] for stage in stages]

    async def _run_prompt(
        self,
        *,
        pipeline: TemplateEditPipeline,
        prompt: str,
        stage_ids: list[str],
        llm_config: dict[str, Any],
        timeout_s: int,
        max_retries: int,
    ) -> list[StageComplexityGrade]:
        def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
            try:
                parsed = _parse_grades(data)
            except StageComplexityAssessmentError as exc:
                return False, str(exc)
            parsed_ids = [grade.stage_id for grade in parsed]
            if parsed_ids != stage_ids:
                return False, f"grades must cover stages in order: {', '.join(stage_ids)}"
            return True, None

        try:
            result = pipeline.execute(
                base_prompt=prompt,
                template_content=STAGE_COMPLEXITY_TEMPLATE_SCHEMA,
                validator=validator,
                fallback_fn=None,
                llm_config=llm_config,
                timeout_s=timeout_s,
                max_retries=max_retries,
            )
            if isawaitable(result):
                result = await result
            data, metadata = result
        except Exception as exc:
            raise StageComplexityAssessmentError(str(exc)) from exc

        status = (metadata or {}).get("status")
        if status in TEMPLATE_FALLBACK_STATUSES:
            raise StageComplexityAssessmentError(f"template pipeline returned fallback status {status}")
        if not isinstance(data, dict):
            raise StageComplexityAssessmentError("template pipeline did not return an object payload")
        grades = _parse_grades(data)
        parsed_ids = [grade.stage_id for grade in grades]
        if parsed_ids != stage_ids:
            raise StageComplexityAssessmentError(
                f"grades must cover stages in order: {', '.join(stage_ids)}"
            )
        return grades


def _parse_grades(data: dict[str, Any]) -> list[StageComplexityGrade]:
    raw_grades = data.get("grades")
    if not isinstance(raw_grades, list) or not raw_grades:
        raise StageComplexityAssessmentError("grades must be a non-empty list")
    parsed: list[StageComplexityGrade] = []
    seen_stage_ids: set[str] = set()
    for entry in raw_grades:
        if not isinstance(entry, dict):
            raise StageComplexityAssessmentError("each grade entry must be an object")
        stage_id = str(entry.get("stage_id") or "").strip()
        grade = str(entry.get("grade") or "").strip().lower()
        rationale = str(entry.get("rationale") or "").strip()
        if not stage_id:
            raise StageComplexityAssessmentError("stage_id must be non-empty")
        if stage_id in seen_stage_ids:
            raise StageComplexityAssessmentError(f"duplicate stage_id: {stage_id}")
        if grade not in {"low", "medium", "high"}:
            raise StageComplexityAssessmentError(f"invalid grade for {stage_id}: {grade}")
        if not rationale:
            raise StageComplexityAssessmentError(f"rationale missing for {stage_id}")
        seen_stage_ids.add(stage_id)
        parsed.append(StageComplexityGrade(stage_id=stage_id, grade=grade, rationale=rationale))
    return parsed


def _workflow_summary_from_compiled_plan(compiled_plan: dict[str, Any]) -> dict[str, Any]:
    title = str(compiled_plan.get("work_id") or "business workflow").strip()
    description = ""
    stages: list[dict[str, Any]] = []
    epics = compiled_plan.get("epics")
    if isinstance(epics, list) and epics:
        first_epic = epics[0] if isinstance(epics[0], dict) else {}
        title = str(first_epic.get("title") or title).strip()
        description = str(first_epic.get("description") or "").strip()
        for epic in epics:
            if not isinstance(epic, dict):
                continue
            stories = epic.get("stories")
            if not isinstance(stories, list):
                continue
            for story in stories:
                if not isinstance(story, dict):
                    continue
                stages.append(
                    {
                        "stage_id": str(story.get("stage_id") or story.get("id") or "").strip(),
                        "title": str(story.get("title") or "").strip(),
                        "description": str(story.get("description") or "").strip(),
                        "stage_type": str(story.get("stage_type") or "").strip(),
                        "depends_on": [
                            str(item).strip()
                            for item in story.get("depends_on", [])
                            if str(item).strip()
                        ]
                        if isinstance(story.get("depends_on"), list)
                        else [],
                        "inputs": [
                            str(item).strip()
                            for item in story.get("inputs", [])
                            if str(item).strip()
                        ]
                        if isinstance(story.get("inputs"), list)
                        else [],
                        "outputs": [
                            str(item).strip()
                            for item in story.get("outputs", [])
                            if str(item).strip()
                        ]
                        if isinstance(story.get("outputs"), list)
                        else [],
                        "prompt_template": story.get("prompt_template"),
                        "input_schema": story.get("input_schema"),
                        "output_schema": story.get("output_schema"),
                    }
                )
    return {
        "title": title,
        "description": description,
        "stages": [stage for stage in stages if stage["stage_id"]],
    }


def _build_complexity_prompt(
    *,
    workflow_title: str,
    workflow_description: str,
    stages: list[dict[str, Any]],
    detailed: bool,
) -> str:
    dependency_lines = "\n".join(
        f"- {stage['stage_id']}: depends_on={', '.join(stage['depends_on']) or 'none'}"
        for stage in stages
    ) or "- none"
    stage_lines = "\n".join(
        _format_stage_line(stage, detailed=detailed)
        for stage in stages
    )
    return STAGE_COMPLEXITY_PROMPT_TEMPLATE.format(
        workflow_title=workflow_title or "Untitled Workflow",
        workflow_description=workflow_description or "(none provided)",
        dependency_lines=dependency_lines,
        stage_lines=stage_lines,
    )


def _format_stage_line(stage: dict[str, Any], *, detailed: bool) -> str:
    header = (
        f"- {stage['stage_id']} [{stage['stage_type'] or 'unknown'}] "
        f"{stage['title'] or stage['stage_id']}: {stage['description'] or '(no description)'}"
    )
    if not detailed:
        return header
    details = [
        f"inputs={', '.join(stage['inputs']) or 'none'}",
        f"outputs={', '.join(stage['outputs']) or 'none'}",
        f"input_schema={_truncate(stage.get('input_schema'))}",
        f"output_schema={_truncate(stage.get('output_schema'))}",
        f"prompt_template={_truncate(stage.get('prompt_template'))}",
    ]
    return f"{header}\n  " + "\n  ".join(details)


def _truncate(value: Any, *, max_chars: int = 800) -> str:
    if value is None:
        return "none"
    text = str(value)
    if len(text) <= max_chars:
        return text
    return f"{text[:max_chars]}..."


def _estimate_prompt_tokens(prompt: str) -> int:
    return max(1, len(prompt) // 4)


def _normalized_or_none(value: Any) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None


def _as_positive_int(value: Any, key_path: str) -> int:
    if not isinstance(value, int) or value < 1:
        raise ValueError(f"{key_path} must be an integer >= 1")
    return value


def _as_non_negative_int(value: Any, key_path: str) -> int:
    if not isinstance(value, int) or value < 0:
        raise ValueError(f"{key_path} must be an integer >= 0")
    return value
