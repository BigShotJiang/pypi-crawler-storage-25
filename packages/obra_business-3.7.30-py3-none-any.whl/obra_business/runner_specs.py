"""Shared runner-spec defaults for business workflow stage execution."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

DEFAULT_BUSINESS_STAGE_LLM_INVOKE_RUNNER_SPEC: dict[str, Any] = {
    "runner_id": "business.stage.llm_invoke",
    "runner_version": "",
    "runner_selector": "",
    "runner_kind": "command_runner",
    "runner_config": {},
}


def default_business_stage_llm_invoke_runner_specs() -> list[dict[str, Any]]:
    """Return the canonical runner spec for a story without an authored runner."""
    return [dict(DEFAULT_BUSINESS_STAGE_LLM_INVOKE_RUNNER_SPEC)]


def normalize_business_stage_runner_specs(
    raw_specs: Any,
    *,
    repair_legacy_docs_placeholder: bool = False,
) -> list[dict[str, Any]]:
    """Normalize runner_specs and fall back to the canonical LLM stage runner."""
    if not isinstance(raw_specs, list):
        return default_business_stage_llm_invoke_runner_specs()
    if repair_legacy_docs_placeholder and is_legacy_docs_placeholder_runner_specs(raw_specs):
        return default_business_stage_llm_invoke_runner_specs()

    normalized_specs = [
        {
            "runner_id": str(spec.get("runner_id") or "").strip(),
            "runner_version": str(spec.get("runner_version") or "").strip(),
            "runner_selector": str(spec.get("runner_selector") or "").strip(),
            "runner_kind": str(spec.get("runner_kind") or "extension_runner").strip()
            or "extension_runner",
            "runner_config": (
                dict(spec.get("runner_config"))
                if isinstance(spec.get("runner_config"), Mapping)
                else {}
            ),
        }
        for spec in raw_specs
        if isinstance(spec, Mapping) and str(spec.get("runner_id") or "").strip()
    ]
    return normalized_specs or default_business_stage_llm_invoke_runner_specs()


def is_legacy_docs_placeholder_runner_specs(raw_specs: Any) -> bool:
    """Return whether runner_specs are the old Studio scaffold docs placeholder."""
    if not isinstance(raw_specs, list) or len(raw_specs) != 1:
        return False
    spec = raw_specs[0]
    if not isinstance(spec, Mapping):
        return False
    runner_id = str(spec.get("runner_id") or "").strip()
    if runner_id != "docs":
        return False
    runner_version = str(spec.get("runner_version") or "").strip()
    runner_selector = str(spec.get("runner_selector") or "").strip()
    runner_config = spec.get("runner_config")
    has_config = isinstance(runner_config, Mapping) and bool(runner_config)
    return not runner_version and not runner_selector and not has_config
