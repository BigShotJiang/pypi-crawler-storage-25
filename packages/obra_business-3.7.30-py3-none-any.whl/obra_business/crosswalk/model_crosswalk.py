"""Crosswalk persistence and model enumeration for business workflows."""

from __future__ import annotations

import hashlib
import logging
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

import yaml
from obra.config.providers import LLM_AUTH_METHODS
from obra.gateway.providers.registry import ProviderRegistry
from obra.model_lookup import MODEL_REGISTRY, get_provider_models
from obra.quality_tiers import resolve_quality_tier

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class CrossWalkEntry:
    """One grade-to-model selection inside the workflow crosswalk."""

    grade: Literal["low", "medium", "high"]
    rationale: str
    selected: dict[str, Any]
    available: list[dict[str, Any]]
    confirmed: bool = False
    fallback_reason: str | None = None


@dataclass(frozen=True)
class CrossWalk:
    """Persisted workflow crosswalk surface."""

    workflow_content_hash: str
    available_models_hash: str
    entries: list[CrossWalkEntry]
    confirmed_at: str | None = None


class CrossWalkConfirmationRequired(RuntimeError):
    """Raised when the operator must confirm a generated workflow crosswalk."""

    def __init__(self, path: Path, workflow_id: str, crosswalk: CrossWalk) -> None:
        self.path = path
        self.workflow_id = workflow_id
        self.crosswalk = crosswalk
        super().__init__(str(self))

    def __str__(self) -> str:
        return f"Review and set confirmed: true in {self.path}"


def crosswalk_path(workflow_dir: Path, workflow_id: str) -> Path:
    """Return the canonical crosswalk path for one workflow."""
    return workflow_dir / ".obra" / workflow_id / "model_crosswalk.yaml"


def load_crosswalk(workflow_dir: Path, workflow_id: str) -> CrossWalk | None:
    """Load a persisted workflow crosswalk if present and parseable."""
    path = crosswalk_path(workflow_dir, workflow_id)
    if not path.exists():
        return None
    try:
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        logger.warning("Failed to parse crosswalk %s: %s", path, exc)
        return None
    if not isinstance(payload, dict):
        logger.warning("Crosswalk file %s must be a mapping", path)
        return None
    try:
        entries = [_entry_from_payload(entry) for entry in payload.get("entries", []) or []]
        return CrossWalk(
            workflow_content_hash=str(payload.get("workflow_content_hash") or "").strip(),
            available_models_hash=str(payload.get("available_models_hash") or "").strip(),
            entries=entries,
            confirmed_at=_normalized_or_none(payload.get("confirmed_at")),
        )
    except Exception as exc:
        logger.warning("Failed to normalize crosswalk %s: %s", path, exc)
        return None


def save_crosswalk(workflow_dir: Path, workflow_id: str, cw: CrossWalk) -> None:
    """Persist a workflow crosswalk as YAML."""
    path = crosswalk_path(workflow_dir, workflow_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "workflow_content_hash": cw.workflow_content_hash,
        "available_models_hash": cw.available_models_hash,
        "confirmed_at": cw.confirmed_at,
        "entries": [asdict(entry) for entry in cw.entries],
    }
    path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")


def carry_forward_confirmation(
    previous: CrossWalk | None,
    candidate: CrossWalk,
) -> CrossWalk:
    """Preserve confirmation when regenerated selections are equivalent."""
    if previous is None or not confirmed_crosswalk(previous):
        return candidate
    if previous.available_models_hash != candidate.available_models_hash:
        return candidate
    if _confirmation_signature(previous) != _confirmation_signature(candidate):
        return candidate
    return CrossWalk(
        workflow_content_hash=candidate.workflow_content_hash,
        available_models_hash=candidate.available_models_hash,
        confirmed_at=previous.confirmed_at or datetime.now(UTC).isoformat(),
        entries=[
            CrossWalkEntry(
                grade=entry.grade,
                rationale=entry.rationale,
                selected=dict(entry.selected),
                available=[dict(item) for item in entry.available],
                confirmed=True,
                fallback_reason=entry.fallback_reason,
            )
            for entry in candidate.entries
        ],
    )


def _confirmation_signature(crosswalk: CrossWalk) -> list[tuple[str, tuple[tuple[str, str], ...]]]:
    execution_selection_keys = {"provider", "model", "reasoning_level", "auth_method"}
    signature = []
    for entry in crosswalk.entries:
        selected = tuple(
            sorted(
                (str(key), str(value))
                for key, value in entry.selected.items()
                if key in execution_selection_keys
            )
        )
        signature.append((entry.grade, selected))
    return sorted(signature)


def enumerate_available_models(registry: ProviderRegistry) -> tuple[list[dict[str, Any]], str]:
    """Enumerate concrete model options for healthy providers.

    The ``ProviderRegistry`` keys providers by their CLI/onboarding
    identifier (``claude_code``, ``openai``, ``google``, ``ollama``) while
    ``obra/model_registry.py`` and the business crosswalk's
    ``default_mapping`` key by the canonical LLM-provider family
    (``anthropic``, ``openai``, ``google``, ``ollama``). The layered
    config loader preserves ``llm_provider_id`` declared on onboarding
    provider entries (see ``obra/gateway/providers/registry.py`` where
    ``ProviderEntry.llm_provider_id`` is populated from the dict), so the
    translation is read directly from the provider entry — no compat
    table needed. See ADR-100 (incident record) and ADR-101 (current
    execute-path contract).
    """
    available: list[dict[str, Any]] = []
    for provider in registry.list_providers():
        try:
            detection_handler = registry.resolve_detection_handler(provider.provider_id)
            detection = detection_handler()
        except Exception as exc:
            logger.warning("Provider detection failed for %s: %s", provider.provider_id, exc)
            continue
        if not isinstance(detection, dict) or not detection.get("installed", False):
            continue

        llm_provider_id = (
            str(getattr(provider, "llm_provider_id", "") or "").strip()
            or provider.provider_id
        )
        auth_method = _normalize_registry_auth_method(provider.auth_method)
        provider_config = MODEL_REGISTRY.get(llm_provider_id)
        provider_reasoning_levels = (
            sorted(provider_config.reasoning_supported_levels)
            if provider_config and provider_config.reasoning_supported_levels
            else []
        )
        for model_info in get_provider_models(llm_provider_id):
            reasoning_levels = (
                sorted(model_info.reasoning_supported_levels)
                if model_info.reasoning_supported_levels
                else provider_reasoning_levels
            )
            available.append(
                {
                    "provider": llm_provider_id,
                    "model": model_info.id,
                    "display_name": model_info.display_name,
                    "auth_method": auth_method,
                    "reasoning_level_options": reasoning_levels,
                }
            )
    available.sort(key=lambda item: (item["provider"], item["model"]))
    digest = hashlib.sha256(
        yaml.safe_dump(available, sort_keys=True).encode("utf-8")
    ).hexdigest()
    return available, digest


def build_crosswalk(
    grades: list[Any],
    available: list[dict[str, Any]],
    available_hash: str,
    workflow_content_hash: str,
    config: dict[str, Any],
) -> CrossWalk:
    """Build a crosswalk from estimator grades and available model options."""
    crosswalk_config = config["business"]["crosswalk"]
    default_mapping = crosswalk_config["default_mapping"]
    tier_fallback_order = crosswalk_config["tier_fallback_order"]
    available_by_provider_model = {
        (str(item.get("provider") or ""), str(item.get("model") or "")): item for item in available
    }
    distinct_grades = []
    seen_grades: set[str] = set()
    for grade in grades:
        grade_name = str(getattr(grade, "grade", None) or grade.get("grade") or "").strip().lower()
        if grade_name in {"low", "medium", "high"} and grade_name not in seen_grades:
            distinct_grades.append(grade_name)
            seen_grades.add(grade_name)

    entries: list[CrossWalkEntry] = []
    for grade_name in distinct_grades:
        matching_grade = next(
            (
                grade
                for grade in grades
                if str(getattr(grade, "grade", None) or grade.get("grade") or "").strip().lower()
                == grade_name
            ),
            None,
        )
        rationale = str(
            getattr(matching_grade, "rationale", None)
            or (matching_grade or {}).get("rationale")
            or ""
        ).strip()
        selected = dict(default_mapping[grade_name])
        fallback_reason: str | None = None
        provider = str(selected.get("provider") or "").strip()
        model = str(selected.get("model") or "").strip()
        if (provider, model) not in available_by_provider_model:
            fallback_reason = f"default_unavailable: {provider}/{model}".rstrip("/")
            fallback_selected = _select_fallback_model(
                available=available,
                fallback_tiers=tier_fallback_order[grade_name],
            )
            if fallback_selected is not None:
                selected.update(
                    {
                        "provider": fallback_selected["provider"],
                        "model": fallback_selected["model"],
                        "auth_method": fallback_selected.get("auth_method"),
                        "reasoning_level": _choose_reasoning_level(
                            selected.get("reasoning_level"),
                            fallback_selected.get("reasoning_level_options"),
                        ),
                    }
                )
        else:
            selected["auth_method"] = (
                selected.get("auth_method")
                or available_by_provider_model[(provider, model)].get("auth_method")
            )
            selected["reasoning_level"] = _choose_reasoning_level(
                selected.get("reasoning_level"),
                available_by_provider_model[(provider, model)].get("reasoning_level_options"),
            )

        entries.append(
            CrossWalkEntry(
                grade=grade_name,
                rationale=rationale,
                selected=selected,
                available=[dict(item) for item in available],
                confirmed=False,
                fallback_reason=fallback_reason,
            )
        )

    return CrossWalk(
        workflow_content_hash=workflow_content_hash,
        available_models_hash=available_hash,
        entries=entries,
        confirmed_at=None,
    )


def _entry_from_payload(payload: Any) -> CrossWalkEntry:
    if not isinstance(payload, dict):
        raise ValueError("crosswalk entry must be a mapping")
    return CrossWalkEntry(
        grade=str(payload.get("grade") or "").strip().lower(),
        rationale=str(payload.get("rationale") or "").strip(),
        selected=dict(payload.get("selected") or {}),
        available=[
            dict(item)
            for item in payload.get("available", [])
            if isinstance(item, dict)
        ],
        confirmed=bool(payload.get("confirmed", False)),
        fallback_reason=_normalized_or_none(payload.get("fallback_reason")),
    )


def _normalize_registry_auth_method(value: Any) -> str | None:
    normalized = str(value or "").strip().lower()
    if normalized == "oauth_cli":
        return "oauth"
    if normalized in LLM_AUTH_METHODS:
        return normalized
    return None


def _select_fallback_model(
    *,
    available: list[dict[str, Any]],
    fallback_tiers: list[str],
) -> dict[str, Any] | None:
    for tier in fallback_tiers:
        for item in available:
            provider = str(item.get("provider") or "").strip()
            model = str(item.get("model") or "").strip()
            if not provider or not model:
                continue
            if resolve_quality_tier(provider, model) == tier:
                return item
    return available[0] if available else None


def _choose_reasoning_level(
    requested: Any,
    options: Any,
) -> str | None:
    requested_value = _normalized_or_none(requested)
    if not isinstance(options, list) or not options:
        return requested_value
    normalized_options = [str(option).strip() for option in options if str(option).strip()]
    if requested_value and requested_value in normalized_options:
        return requested_value
    return normalized_options[-1] if normalized_options else requested_value


def confirmed_crosswalk(crosswalk: CrossWalk) -> bool:
    """Return whether every entry is confirmed."""
    return bool(crosswalk.entries) and all(entry.confirmed for entry in crosswalk.entries)


def auto_confirm_crosswalk(crosswalk: CrossWalk) -> CrossWalk:
    """Return a copy with all entries confirmed."""
    return CrossWalk(
        workflow_content_hash=crosswalk.workflow_content_hash,
        available_models_hash=crosswalk.available_models_hash,
        entries=[
            CrossWalkEntry(
                grade=entry.grade,
                rationale=entry.rationale,
                selected=dict(entry.selected),
                available=[dict(item) for item in entry.available],
                confirmed=True,
                fallback_reason=entry.fallback_reason,
            )
            for entry in crosswalk.entries
        ],
        confirmed_at=datetime.now(UTC).isoformat(),
    )


def _normalized_or_none(value: Any) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None
