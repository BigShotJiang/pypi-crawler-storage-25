"""Precedence resolver for business-domain stage model bindings."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from obra.config.tier_resolution import resolve_stage_llm_config
from obra.schemas.stage_llm_override import StageLLMOverride
from obra.schemas.stage_model_binding import StageModelBinding

from obra_business.config.loader import normalize_stage_type_tier_entry
from obra_business.crosswalk.model_crosswalk import CrossWalk


def resolve_stage_binding(
    stage: Mapping[str, Any],
    crosswalk: CrossWalk | None,
    grade: Any | None,
    stage_type_tiers: dict[str, Any],
    config: dict[str, Any],
) -> StageModelBinding:
    """Resolve the fully materialized binding for one workflow stage."""
    stage_id = str(stage.get("id") or stage.get("stage_id") or "").strip()
    stage_type = str(stage.get("type") or stage.get("stage_type") or "").strip()
    default_fallback_tier = str(config["business"]["llm"]["execution_tier"]).strip()
    fallback_entry = _fallback_entry_for_stage_type(
        stage_type=stage_type,
        stage_type_tiers=stage_type_tiers,
        default_fallback_tier=default_fallback_tier,
    )
    fallback_tier = str(fallback_entry.get("model_tier") or default_fallback_tier).strip()

    explicit_override = StageLLMOverride(
        provider=_normalized_or_none(stage.get("provider")),
        model=_normalized_or_none(stage.get("model")),
        model_tier=_normalized_or_none(stage.get("model_tier")),
        reasoning_level=_normalized_or_none(stage.get("reasoning_level")),
        auth_method=_normalized_or_none(stage.get("auth_method")),
    )
    if any(
        (
            explicit_override.provider,
            explicit_override.model,
            explicit_override.reasoning_level,
            explicit_override.auth_method,
        )
    ):
        return _binding_from_resolution(
            stage_id=stage_id,
            source="mosaic",
            stage_override=explicit_override,
            fallback_tier=fallback_tier,
        )
    if explicit_override.model_tier is not None:
        return _binding_from_resolution(
            stage_id=stage_id,
            source="stage_tier",
            stage_override=StageLLMOverride(
                model_tier=explicit_override.model_tier,
                provider=explicit_override.provider,
                model=explicit_override.model,
                reasoning_level=explicit_override.reasoning_level,
                auth_method=explicit_override.auth_method,
            ),
            fallback_tier=fallback_tier,
        )

    grade_name = _grade_name(grade)
    if crosswalk is not None and grade_name is not None:
        for entry in crosswalk.entries:
            if entry.grade == grade_name and entry.confirmed:
                return _binding_from_resolution(
                    stage_id=stage_id,
                    source="crosswalk",
                    stage_override=StageLLMOverride(
                        provider=_normalized_or_none(entry.selected.get("provider")),
                        model=_normalized_or_none(entry.selected.get("model")),
                        model_tier=_normalized_or_none(entry.selected.get("model_tier")),
                        reasoning_level=_normalized_or_none(entry.selected.get("reasoning_level")),
                        auth_method=_normalized_or_none(entry.selected.get("auth_method")),
                    ),
                    fallback_tier=fallback_tier,
                )

    if grade_name is not None:
        default_mapping = config["business"]["crosswalk"]["default_mapping"][grade_name]
        return _binding_from_resolution(
            stage_id=stage_id,
            source="estimator",
            stage_override=StageLLMOverride(
                provider=_normalized_or_none(default_mapping.get("provider")),
                model=_normalized_or_none(default_mapping.get("model")),
                model_tier=_normalized_or_none(default_mapping.get("model_tier")),
                reasoning_level=_normalized_or_none(default_mapping.get("reasoning_level")),
                auth_method=_normalized_or_none(default_mapping.get("auth_method")),
            ),
            fallback_tier=fallback_tier,
        )

    return _binding_from_resolution(
        stage_id=stage_id,
        source="fallback",
        stage_override=StageLLMOverride(
            provider=_normalized_or_none(fallback_entry.get("provider")),
            model=_normalized_or_none(fallback_entry.get("model")),
            model_tier=_normalized_or_none(fallback_entry.get("model_tier")),
            reasoning_level=_normalized_or_none(fallback_entry.get("reasoning_level")),
            auth_method=_normalized_or_none(fallback_entry.get("auth_method")),
        ),
        fallback_tier=fallback_tier,
    )


def _fallback_entry_for_stage_type(
    *,
    stage_type: str,
    stage_type_tiers: dict[str, Any],
    default_fallback_tier: str,
) -> dict[str, Any]:
    raw_entry = stage_type_tiers.get(stage_type)
    if raw_entry is not None:
        return normalize_stage_type_tier_entry(raw_entry)
    return {
        "model_tier": default_fallback_tier,
        "provider": None,
        "model": None,
        "reasoning_level": None,
        "auth_method": None,
    }


def _binding_from_resolution(
    *,
    stage_id: str,
    source: str,
    stage_override: StageLLMOverride,
    fallback_tier: str,
) -> StageModelBinding:
    resolved = resolve_stage_llm_config(
        stage_override=stage_override,
        fallback_tier=fallback_tier,
        role="implementation",
    )
    return StageModelBinding(
        stage_id=stage_id,
        provider=str(resolved.get("provider") or "").strip() or None,
        model=str(resolved.get("model") or "").strip() or None,
        model_tier=stage_override.model_tier or fallback_tier,
        reasoning_level=str(resolved.get("reasoning_level") or "").strip() or None,
        auth_method=str(resolved.get("auth_method") or "").strip() or None,
        source=source,
    )


def _grade_name(grade: Any) -> str | None:
    if grade is None:
        return None
    if isinstance(grade, Mapping):
        value = grade.get("grade")
    else:
        value = getattr(grade, "grade", None)
    normalized = _normalized_or_none(value)
    if normalized in {"low", "medium", "high"}:
        return normalized
    return None


def _normalized_or_none(value: Any) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None
