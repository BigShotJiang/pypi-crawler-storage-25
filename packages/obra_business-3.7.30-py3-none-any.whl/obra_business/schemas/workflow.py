"""Complete Pydantic schemas for workflow definition.

These schemas define the structure of definition.yaml, which captures
the extracted workflow structure from natural language descriptions.
"""

import re
from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from obra.workflow import collect_stage_quality_loop_issues
from obra.schemas.stage_llm_override import normalize_inherit

MODEL_TIER_VALUES = ("fast", "medium", "high")
FAILURE_POLICY_VALUES = ("fail_fast", "all_settle")
STAGE_TYPE_VALUES = (
    "input_validation",
    "transformation",
    "enrichment",
    "decision",
    "generation",
    "quality_gate",
    "output",
)
ModelTier = Literal["fast", "medium", "high"]
FailurePolicy = Literal["fail_fast", "all_settle"]
StageType = Literal[
    "input_validation",
    "transformation",
    "enrichment",
    "decision",
    "generation",
    "quality_gate",
    "output",
]
ContextPolicyMode = Literal["none", "latest_only", "selected_refs", "blind_review"]
ContextPolicyHydrate = Literal["full", "none"]


class InputDocumentSpec(BaseModel):
    """Specification for workflow input document."""

    name: str = Field(..., min_length=1, description="Human-readable name")
    format: Literal["text", "markdown", "json", "yaml", "structured"] = Field(
        default="text", description="Expected input format"
    )
    required_fields: list[str] = Field(
        default_factory=list,
        description="Fields that must be present in input",
    )
    description: str = Field(default="", description="Description of expected input")
    input_schema: dict[str, Any] | None = Field(
        default=None,
        description=(
            "Optional JSON Schema defining the expected input payload structure. "
            "When provided, integrators can validate input client-side before submission."
        ),
    )


class DeliverableSpec(BaseModel):
    """Rich metadata for one declared workflow deliverable."""

    name: str = Field(..., min_length=1, description="Deliverable name")
    format: Literal["text", "markdown", "json", "yaml", "structured"] = Field(
        default="text", description="Deliverable content format"
    )
    stage_id: str | None = Field(
        default=None, description="ID of the stage that produces this deliverable"
    )
    description: str = Field(default="", description="What this deliverable contains")


class OutputDocumentSpec(BaseModel):
    """Specification for workflow output document."""

    name: str = Field(..., min_length=1, description="Human-readable name")
    format: Literal["text", "markdown", "json", "yaml", "structured"] = Field(
        default="structured", description="Output format"
    )
    deliverables: list[str] = Field(
        default_factory=list,
        description="Expected output components",
    )
    deliverable_specs: list[DeliverableSpec] | None = Field(
        default=None,
        description="Rich deliverable metadata when available",
    )
    description: str = Field(default="", description="Description of expected output")

    @model_validator(mode="before")
    @classmethod
    def populate_deliverable_specs(cls, data: Any) -> Any:
        """Capture rich deliverable metadata before deliverables normalize to strings."""
        if not isinstance(data, dict):
            return data
        if data.get("deliverable_specs") is not None:
            return data
        deliverables = data.get("deliverables")
        if not isinstance(deliverables, list):
            return data

        deliverable_specs = []
        for item in deliverables:
            spec = _coerce_deliverable_spec(item)
            if spec is not None:
                deliverable_specs.append(spec)
        if deliverable_specs:
            data = dict(data)
            data["deliverable_specs"] = deliverable_specs
        return data

    @field_validator("deliverables", mode="before")
    @classmethod
    def normalize_deliverables(cls, value: Any) -> list[str]:
        """Normalize deliverables to the canonical list[str] shape.

        Some checked-in or user-edited definitions may accidentally express
        deliverables as a list of single-key mapping entries such as:

            - report_name: "description"

        The canonical contract remains ``list[str]``. Accept the keyed variant
        only as a compatibility input and normalize it back to the deliverable
        keys so downstream generation and compilation stay consistent.
        """
        if value is None:
            return []
        if not isinstance(value, list):
            msg = "deliverables must be a list of strings"
            raise ValueError(msg)

        normalized: list[str] = []
        for item in value:
            deliverable_spec = _coerce_deliverable_spec(item)
            if deliverable_spec is not None:
                normalized.append(deliverable_spec.name)
                continue
            if isinstance(item, str):
                deliverable = item.strip()
                if not deliverable:
                    msg = "deliverables may not contain blank strings"
                    raise ValueError(msg)
                normalized.append(deliverable)
                continue
            if isinstance(item, dict):
                if len(item) != 1:
                    msg = "deliverables must contain only strings, rich deliverable specs, or single-key mappings"
                    raise ValueError(msg)
                deliverable = str(next(iter(item.keys()))).strip()
                if not deliverable:
                    msg = "deliverable mapping entries must use a non-empty key"
                    raise ValueError(msg)
                normalized.append(deliverable)
                continue
            msg = "deliverables must contain only strings or single-key mappings"
            raise ValueError(msg)

        return normalized


def _coerce_deliverable_spec(value: Any) -> DeliverableSpec | None:
    """Return a rich deliverable spec when the input uses that shape."""
    if isinstance(value, DeliverableSpec):
        return value
    if not isinstance(value, dict):
        return None
    try:
        return DeliverableSpec.model_validate(value)
    except ValueError:
        return None


class StageRunnerBinding(BaseModel):
    """Author-time runner binding for one workflow stage."""

    model_config = ConfigDict(extra="forbid")

    runner_id: str = Field(..., min_length=1, description="Stable runner identifier")
    runner_version: str | None = Field(default=None, description="Optional exact runner version")
    runner_selector: str | None = Field(
        default=None,
        description="Optional version selector when pinning to a range",
    )
    runner_config: dict[str, Any] = Field(
        default_factory=dict,
        description="Optional runner-specific configuration mapping",
    )
    connector: str | None = Field(
        default=None,
        description="Reserved future connector shorthand field",
    )
    operation: str | None = Field(
        default=None,
        description="Reserved future connector shorthand field",
    )

    @model_validator(mode="after")
    def validate_reserved_connector_shorthand(self) -> "StageRunnerBinding":
        """Reject the reserved connector shorthand until ADR-097 implements it."""
        if self.connector or self.operation:
            raise ValueError(
                "Connector runner shorthand is reserved in ADR-097 and not yet supported."
            )
        return self


class StageContextBudget(BaseModel):
    """Optional per-stage prompt-hydration budget override."""

    model_config = ConfigDict(extra="forbid")

    excerpt_chars: int | None = Field(default=None)
    total_chars: int | None = Field(default=None)
    full_recent_count: int | None = Field(default=None)


class StageContextPolicy(BaseModel):
    """Author-declared policy for prior-stage output hydration."""

    model_config = ConfigDict(extra="forbid")

    mode: ContextPolicyMode
    hydrate: ContextPolicyHydrate = "full"
    include: list[str] = Field(default_factory=list)
    budget: StageContextBudget | None = None

    @field_validator("include", mode="before")
    @classmethod
    def normalize_include(cls, value: Any) -> list[str]:
        """Normalize included stage IDs and reject blank entries."""
        if value is None:
            return []
        if not isinstance(value, list):
            msg = "context_policy.include must be a list of stage IDs"
            raise ValueError(msg)
        normalized: list[str] = []
        seen: set[str] = set()
        for item in value:
            stage_id = str(item or "").strip()
            if not stage_id:
                raise ValueError("context_policy.include may not contain blank stage IDs")
            if stage_id in seen:
                continue
            seen.add(stage_id)
            normalized.append(stage_id)
        return normalized


class StageDefinition(BaseModel):
    """Definition of a single workflow stage."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(
        ...,
        pattern=r"^S\d+[a-z]?$",
        description="Stage ID (S0, S1, S1a...)",
    )
    name: str = Field(..., min_length=1, max_length=50, description="Stage name")
    type: StageType = Field(..., description="Stage type")
    description: str = Field(..., min_length=10, max_length=500, description="What this stage does")
    depends_on: list[str] = Field(
        default_factory=list,
        description="Stage IDs this stage depends on (default: previous stage)",
    )
    parallel_group: str | None = Field(
        default=None,
        description="Optional human-friendly parallel group label for sibling stages",
    )
    failure_policy: FailurePolicy | None = Field(
        default=None,
        description="Optional same-group failure policy for parallel stages",
    )
    model_tier: ModelTier | None = Field(
        default=None,
        description="Optional provider-agnostic model tier override",
    )
    provider: str | None = Field(
        default=None,
        description="Optional LLM provider override",
    )
    model: str | None = Field(
        default=None,
        description="Optional specific model override",
    )
    reasoning_level: str | None = Field(
        default=None,
        description="Optional reasoning/effort level override",
    )
    auth_method: str | None = Field(
        default=None,
        description="Optional auth method override",
    )
    quality_loop: dict[str, Any] | None = Field(
        default=None,
        description="Optional canonical stage quality-loop policy",
    )
    runner: StageRunnerBinding | None = Field(
        default=None,
        description="Optional per-stage runner binding",
    )
    context_policy: StageContextPolicy | None = Field(
        default=None,
        description="Optional prior-stage output hydration policy",
    )

    @model_validator(mode="before")
    @classmethod
    def reject_legacy_quality_loop_fields(cls, data: Any) -> Any:
        """Reject removed stage quality-loop shorthand fields."""
        if not isinstance(data, dict):
            return data
        legacy_fields = sorted(
            field_name
            for field_name in ("on_issues", "on_sound", "quality_loop_normalization")
            if field_name in data and data.get(field_name) is not None
        )
        if legacy_fields:
            msg = (
                "Stage quality_loop must be declared via canonical quality_loop; "
                f"unsupported fields: {', '.join(legacy_fields)}"
            )
            raise ValueError(msg)
        return data

    @model_validator(mode="before")
    @classmethod
    def normalize_llm_override_fields(cls, data: Any) -> Any:
        """Normalize inherit-like stage LLM override strings to None."""
        if not isinstance(data, dict):
            return data
        normalized = dict(data)
        for field_name in (
            "model_tier",
            "provider",
            "model",
            "reasoning_level",
            "auth_method",
        ):
            if field_name in normalized:
                normalized[field_name] = normalize_inherit(normalized.get(field_name))
        return normalized

    @field_validator("id")
    @classmethod
    def validate_stage_id(cls, v: str) -> str:
        """Ensure stage ID is well-formed."""
        if not v.startswith("S"):
            msg = f"Stage ID must start with 'S', got: {v}"
            raise ValueError(msg)
        if re.fullmatch(r"^S\d+[a-z]?$", v) is None:
            msg = f"Stage ID must be S<number> with optional lowercase suffix, got: {v}"
            raise ValueError(msg)
        return v

    @field_validator("quality_loop")
    @classmethod
    def validate_quality_loop(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        """Reject malformed canonical stage quality-loop payloads."""
        if v is None:
            return None
        issues = collect_stage_quality_loop_issues({"quality_loop": v})
        if issues:
            issue_messages = "; ".join(
                str(issue.get("message") or issue.get("code") or "invalid quality_loop")
                for issue in issues
            )
            msg = f"Invalid stage quality_loop: {issue_messages}"
            raise ValueError(msg)
        return v

    @field_validator("depends_on", mode="before")
    @classmethod
    def normalize_depends_on(cls, value: Any) -> list[str]:
        """Normalize dependency IDs to a unique ordered list of stage IDs."""
        if value is None:
            return []
        if not isinstance(value, list):
            msg = "depends_on must be a list of stage IDs"
            raise ValueError(msg)
        normalized: list[str] = []
        seen: set[str] = set()
        for dependency in value:
            dependency_id = str(dependency or "").strip()
            if not dependency_id:
                continue
            if dependency_id in seen:
                continue
            seen.add(dependency_id)
            normalized.append(dependency_id)
        return normalized

    @field_validator("parallel_group")
    @classmethod
    def normalize_parallel_group(cls, value: str | None) -> str | None:
        """Normalize blank parallel-group labels to ``None``."""
        if value is None:
            return None
        normalized = str(value).strip()
        return normalized or None


class QualityRule(BaseModel):
    """Quality rule that applies to one or more stages."""

    id: str = Field(
        ...,
        pattern=r"^QR\d+$",
        description="Quality rule ID (QR1, QR2...)",
    )
    name: str = Field(..., min_length=1, max_length=50, description="Rule name")
    description: str = Field(
        ..., min_length=10, max_length=500, description="What this rule checks"
    )
    applies_to: list[str] = Field(
        ..., min_length=1, description="Stage IDs where this rule applies"
    )
    severity: Literal["error", "warning"] = Field(default="error", description="Failure severity")


class WorkflowDefinition(BaseModel):
    """Complete workflow definition extracted from user input.

    This is the primary schema written to definition.yaml after extraction.
    """

    workflow_id: str = Field(
        ...,
        pattern=r"^WORKFLOW-[A-Z]+-\d{3}$",
        description="Workflow ID (e.g., WORKFLOW-FEEDBACK-001)",
    )
    title: str = Field(..., min_length=5, max_length=100, description="Human-readable title")
    version: str = Field(
        default="1.0.0",
        pattern=r"^\d+\.\d+\.\d+$",
        description="Semantic version",
    )
    created: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="Creation timestamp",
    )
    description: str = Field(default="", max_length=1000, description="Workflow description")
    input_document: InputDocumentSpec = Field(..., description="Input document specification")
    output_document: OutputDocumentSpec = Field(..., description="Output document specification")
    stages: list[StageDefinition] = Field(
        ..., min_length=2, max_length=50, description="Workflow stages (2-50)"
    )
    quality_rules: list[QualityRule] = Field(default_factory=list, description="Quality rules")

    @model_validator(mode="after")
    def validate_stage_topology(self) -> "WorkflowDefinition":
        """Ensure stage ordering and dependency references stay canonical."""
        parsed_ids: list[tuple[int, str, StageDefinition]] = []
        seen_stage_ids: set[str] = set()
        for index, stage in enumerate(self.stages):
            numeric_prefix, suffix = _parse_grouped_stage_id(stage.id)
            if stage.id in seen_stage_ids:
                msg = f"Duplicate stage ID '{stage.id}' is not allowed."
                raise ValueError(msg)
            seen_stage_ids.add(stage.id)
            parsed_ids.append((numeric_prefix, suffix, stage))
            if not stage.depends_on and index > 0 and stage.parallel_group is None:
                stage.depends_on = [self.stages[index - 1].id]

        expected_stage_order = sorted(
            parsed_ids,
            key=lambda item: (item[0], "" if item[1] == "" else item[1]),
        )
        if [stage.id for _, _, stage in parsed_ids] != [stage.id for _, _, stage in expected_stage_order]:
            msg = (
                "Stages must be ordered by dense numeric group and suffix "
                "(for example S0, S1, S1a, S1b, S2)."
            )
            raise ValueError(msg)

        numeric_groups = sorted({numeric for numeric, _, _ in parsed_ids})
        expected_numeric_groups = list(range(len(numeric_groups)))
        if numeric_groups != expected_numeric_groups:
            msg = (
                "Stage numeric groups must be dense from S0. "
                f"Expected {expected_numeric_groups}, got {numeric_groups}."
            )
            raise ValueError(msg)

        grouped_suffixes: dict[int, list[str]] = {}
        for numeric_prefix, suffix, _stage in parsed_ids:
            grouped_suffixes.setdefault(numeric_prefix, []).append(suffix)

        for numeric_prefix, suffixes in grouped_suffixes.items():
            bare_count = suffixes.count("")
            if bare_count > 1:
                msg = f"Stage group S{numeric_prefix} may declare at most one bare stage id."
                raise ValueError(msg)
            letter_suffixes = [suffix for suffix in suffixes if suffix]
            expected_suffixes = [chr(ord("a") + index) for index in range(len(letter_suffixes))]
            if sorted(letter_suffixes) != expected_suffixes:
                msg = (
                    f"Stage group S{numeric_prefix} must use dense lowercase suffixes from 'a'. "
                    f"Expected {expected_suffixes}, got {sorted(letter_suffixes)}."
                )
                raise ValueError(msg)

        known_stage_ids = {stage.id for stage in self.stages}
        for stage in self.stages:
            if stage.failure_policy is not None and stage.parallel_group is None:
                msg = (
                    f"Stage {stage.id} declares failure_policy without parallel_group. "
                    "failure_policy is only valid for parallel stages."
                )
                raise ValueError(msg)
            for dependency_id in stage.depends_on:
                if dependency_id == stage.id:
                    msg = f"Stage {stage.id} cannot depend on itself."
                    raise ValueError(msg)
                if dependency_id not in known_stage_ids:
                    msg = (
                        f"Stage {stage.id} depends on unknown stage '{dependency_id}'. "
                        "All dependencies must reference declared stages."
                    )
                    raise ValueError(msg)
            if stage.context_policy is not None:
                for include_id in stage.context_policy.include:
                    if include_id == stage.id:
                        msg = f"Stage {stage.id} context_policy.include cannot reference itself."
                        raise ValueError(msg)
                    if include_id not in known_stage_ids:
                        msg = (
                            f"Stage {stage.id} context_policy.include references unknown "
                            f"stage '{include_id}'. All included stages must be declared."
                        )
                        raise ValueError(msg)
        return self


def _parse_grouped_stage_id(stage_id: str) -> tuple[int, str]:
    """Return the grouped numeric prefix and optional suffix for one stage id."""
    match = re.fullmatch(r"^S(?P<numeric>\d+)(?P<suffix>[a-z]?)$", stage_id)
    if match is None:
        raise ValueError(f"Invalid stage id: {stage_id}")
    return int(match.group("numeric")), match.group("suffix")

    @field_validator("quality_rules")
    @classmethod
    def validate_quality_gate_coverage(
        cls, v: list[QualityRule], info: Any
    ) -> list[QualityRule]:
        """Ensure quality_gate stages have quality rules applied to them.

        If the LLM assigned rules only to processing stages and not to the
        quality_gate stage, auto-assign all rules to quality_gate stages so
        the gate actually has something to evaluate.
        """
        stages = info.data.get("stages", [])
        if not stages or not v:
            return v

        gate_ids = {s.id for s in stages if s.type == "quality_gate"}
        if not gate_ids:
            return v

        # Check if any rule already applies to a quality gate
        has_gate_coverage = any(
            gate_id in rule.applies_to for rule in v for gate_id in gate_ids
        )
        if has_gate_coverage:
            return v

        # Auto-assign all rules to quality gate stages
        for rule in v:
            for gate_id in sorted(gate_ids):
                if gate_id not in rule.applies_to:
                    rule.applies_to.append(gate_id)

        return v

    def require_runtime_objective_metadata(self) -> dict[str, Any]:
        """Return metadata required to build a delegated runtime objective.

        Raises:
            ValueError: If required fields are missing or blank.
        """
        missing_fields: list[str] = []
        if not self.title.strip():
            missing_fields.append("title")
        if not self.description.strip():
            missing_fields.append("description")
        if not self.input_document.name.strip():
            missing_fields.append("input_document.name")
        if not self.input_document.description.strip():
            missing_fields.append("input_document.description")
        if not self.output_document.name.strip():
            missing_fields.append("output_document.name")
        if not self.output_document.description.strip():
            missing_fields.append("output_document.description")

        if missing_fields:
            missing = ", ".join(missing_fields)
            msg = (
                "Workflow definition is missing required runtime objective metadata: "
                f"{missing}"
            )
            raise ValueError(msg)

        return {
            "title": self.title.strip(),
            "description": self.description.strip(),
            "input_name": self.input_document.name.strip(),
            "input_format": self.input_document.format,
            "input_description": self.input_document.description.strip(),
            "input_required_fields": list(self.input_document.required_fields),
            "output_name": self.output_document.name.strip(),
            "output_format": self.output_document.format,
            "output_description": self.output_document.description.strip(),
            "output_deliverables": list(self.output_document.deliverables),
        }

    model_config = {"extra": "forbid"}
