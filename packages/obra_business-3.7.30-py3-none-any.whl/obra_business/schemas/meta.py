"""Execution metadata schema.

Defines the structure of _meta.yaml which contains
workflow execution configuration and retry policies.
"""

from typing import Literal

from pydantic import BaseModel, Field


class RetryPolicy(BaseModel):
    """Retry configuration for quality gate failures."""

    max_attempts: int = Field(default=3, ge=1, le=10)
    on_quality_failure: Literal["loop_to_previous", "fail", "skip"] = Field(
        default="loop_to_previous"
    )
    backoff_seconds: float = Field(default=1.0, ge=0)


class MetaConfig(BaseModel):
    """Workflow execution metadata (_meta.yaml)."""

    workflow_id: str = Field(...)
    version: str = Field(default="1.0.0")
    execution_mode: Literal["sequential"] = Field(
        default="sequential", description="Only sequential supported in MVP"
    )
    total_stages: int = Field(..., ge=2, le=15)
    quality_gate_stages: list[str] = Field(
        default_factory=list, description="Stage IDs that are quality gates"
    )
    retry_policy: RetryPolicy = Field(default_factory=RetryPolicy)

    model_config = {"extra": "forbid"}
