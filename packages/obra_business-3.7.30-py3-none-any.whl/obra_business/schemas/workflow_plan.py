"""WORKFLOW_PLAN.json schema compatible with Obra's PlanReader.

This schema produces plans loadable by obra.auto.plan_reader.PlanReader.
Business-specific fields are allowed via MachinePlanSchema's extra="allow".

Stage-to-Story ID Mapping:
- Workflow stages (S0, S1, S2...) map to WORKFLOW_PLAN stories with 1-based indexing
- Stage S0 becomes Story S1, Stage S1 becomes Story S2, etc.
- Story titles include stage reference: "Stage S0: Document Receipt"
"""

from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

from obra_business.schemas.workflow import FailurePolicy


class WorkflowTaskSchema(BaseModel):
    """Task within a workflow stage (maps to TaskSchema)."""

    id: str = Field(
        ...,
        pattern=r"^S\d+\.T\d+(?:\.sub\d+(?:\.\d+)*)?$",
        description="Task ID (e.g., S1.T1 or S1.T1.sub1)",
    )
    desc: str = Field(..., min_length=1, description="Task description")
    status: Literal["pending", "in_progress", "completed", "blocked"] = Field(default="pending")
    verify: str = Field(..., min_length=1, description="Verification criteria")


class WorkflowStorySchema(BaseModel):
    """Story representing a workflow stage (maps to StorySchema).

    Note: Story IDs are 1-indexed (S1, S2...) for MachinePlan compatibility,
    while stage IDs (stored in stage_id) are 0-indexed (S0, S1...).
    """

    id: str = Field(
        ...,
        pattern=r"^S\d+$",
        description="Story ID (S1, S2... - 1-indexed for MachinePlan compat)",
    )
    title: str = Field(..., min_length=1, description="Stage title")
    status: Literal["pending", "in_progress", "completed", "blocked"] = Field(default="pending")
    tasks: list[WorkflowTaskSchema] = Field(..., min_length=1)

    # Business-specific fields (allowed via extra="allow" in MachinePlanSchema)
    stage_id: str = Field(..., description="Original stage ID (S0, S1...)")
    stage_type: str = Field(..., description="Stage type from definition")
    instruction_file: str | None = Field(
        default=None,
        description="Optional path to stage instruction file",
    )
    model_tier: Literal["fast", "medium", "high"] | None = Field(
        default=None,
        description="Optional provider-agnostic model tier preserved for runtime",
    )
    provider: str | None = Field(
        default=None,
        description="Optional provider override preserved for runtime",
    )
    model: str | None = Field(
        default=None,
        description="Optional model override preserved for runtime",
    )
    reasoning_level: str | None = Field(
        default=None,
        description="Optional reasoning level override preserved for runtime",
    )
    auth_method: str | None = Field(
        default=None,
        description="Optional auth method override preserved for runtime",
    )
    quality_loop: dict[str, Any] | None = Field(
        default=None,
        description="Optional canonical stage quality-loop policy preserved for runtime",
    )
    context_policy: dict[str, Any] | None = Field(
        default=None,
        description="Optional prior-stage output hydration policy preserved for runtime",
    )
    runner_specs: list[dict[str, Any]] | None = Field(
        default=None,
        description="Optional normalized runner specs preserved for runtime",
    )
    depends_on: list[str] = Field(
        default_factory=list,
        description="Original stage IDs this story depends on",
    )
    parallel_group: int | None = Field(
        default=None,
        description="Normalized numeric parallel-group identifier for delegated execution",
    )
    topological_level: int | None = Field(
        default=None,
        description="Dependency-wave level for delegated execution ordering",
    )
    failure_policy: FailurePolicy | None = Field(
        default=None,
        description="Effective failure policy for the normalized parallel group",
    )


class WorkflowEpicSchema(BaseModel):
    """Epic containing all workflow stages (maps to EpicSchema)."""

    id: str = Field(default="E1", pattern=r"^E\d+$")
    title: str = Field(..., min_length=1)
    description: str = Field(default="")
    status: Literal["pending", "in_progress", "completed", "blocked"] = Field(default="pending")
    stories: list[WorkflowStorySchema] = Field(..., min_length=1)


class WorkflowPlanSchema(BaseModel):
    """Complete WORKFLOW_PLAN.json schema.

    Designed to be loadable by obra.auto.plan_reader.PlanReader.
    Business-specific fields are allowed via MachinePlanSchema's extra="allow".
    """

    work_id: str = Field(
        ...,
        pattern=r"^WORKFLOW-[A-Z]+-\d{3}$",
        description="Workflow ID matching definition",
    )
    workflow_type: Literal["business"] = Field(
        default="business", description="Plan type discriminator"
    )
    epics: list[WorkflowEpicSchema] = Field(..., min_length=1)
    completion_checklist: list[str] = Field(
        ..., min_length=1, description="Completion criteria (strings only)"
    )

    # Metadata
    source_definition: str = Field(default="definition.yaml", description="Source definition file")
    compiled_at: str = Field(..., description="ISO-8601 compilation timestamp")

    @field_validator("completion_checklist")
    @classmethod
    def validate_checklist_strings(cls, v: list[str]) -> list[str]:
        """Ensure all checklist items are strings (not nested lists)."""
        for i, item in enumerate(v):
            if not isinstance(item, str):
                msg = f"completion_checklist[{i}] must be a string, got {type(item).__name__}"
                raise TypeError(msg)
        return v

    model_config = {"extra": "allow"}  # Allow future fields
