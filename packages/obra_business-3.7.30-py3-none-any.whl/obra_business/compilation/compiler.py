"""Workflow compiler for converting definitions to executable plans.

Stage-to-Story ID Mapping:
    - Workflow stages (S0, S1, S2...) map to WORKFLOW_PLAN stories with 1-based indexing
    - Stage S0 becomes Story S1, Stage S1 becomes Story S2, etc.
    - This ensures compatibility with obra.auto.plan_reader.PlanReader

Compatibility:
    WorkflowPlanSchema uses extra='allow' so business-specific fields
    (stage_type, instruction_file, model_tier) are preserved but ignored by PlanReader.
"""

from __future__ import annotations

import json
import hashlib
import logging
import re
from collections import defaultdict, deque
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml
from pydantic import ValidationError
from obra.workflow.artifact_model import WorkflowArtifactRecord
from obra.workflow.runner_catalog_sources import effective_catalog_for_domain
from obra.workflow.template_assets import (
    choose_primary_instruction_binding,
    normalize_template_bindings,
)
from obra.schemas.stage_model_binding import StageModelBinding

from obra_business.config.loader import get_parallel_default_failure_policy, load_config
from obra_business.crosswalk.resolver import resolve_stage_binding
from obra_business.schemas.workflow import WorkflowDefinition
from obra_business.schemas.workflow_plan import (
    WorkflowEpicSchema,
    WorkflowPlanSchema,
    WorkflowStorySchema,
    WorkflowTaskSchema,
)
from obra_business.runner_specs import (
    default_business_stage_llm_invoke_runner_specs,
    normalize_business_stage_runner_specs,
)
from obra_business.workflow_source import (
    _stage_inputs,
    build_business_baseline_workflow_ref,
    build_business_workflow_source_from_artifact,
    build_business_workflow_source_payload,
    build_business_workflow_source_summary,
    write_business_workflow_source_payload,
)

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class CompilationError(Exception):
    """Error during workflow compilation."""


def _default_context_policy_for_stage(
    stage_type: str,
    depends_on: list[str],
) -> dict[str, Any]:
    """Return the default prior-output hydration policy for a stage type."""
    normalized_type = str(stage_type or "").strip()
    normalized_dependencies = [str(item).strip() for item in depends_on if str(item).strip()]
    if normalized_type == "input_validation":
        return {"mode": "none"}
    if normalized_type == "quality_gate":
        return {"mode": "blind_review"}
    if normalized_type in {"decision", "output"}:
        return {"mode": "selected_refs", "include": list(normalized_dependencies)}
    if normalized_type in {"transformation", "enrichment", "generation"}:
        if normalized_dependencies:
            return {"mode": "selected_refs", "include": list(normalized_dependencies)}
        return {"mode": "latest_only"}
    if normalized_dependencies:
        return {"mode": "selected_refs", "include": list(normalized_dependencies)}
    return {"mode": "latest_only"}


def _context_policy_payload(value: Any) -> dict[str, Any] | None:
    """Return a JSON-compatible context policy mapping when supplied."""
    if value is None:
        return None
    if hasattr(value, "model_dump"):
        payload = value.model_dump(mode="json", exclude_none=True)
    elif isinstance(value, Mapping):
        payload = dict(value)
    else:
        return None
    return payload if isinstance(payload, dict) else None


def _compute_workflow_content_hash(workflow_definition: WorkflowDefinition | Mapping[str, Any]) -> str:
    """Hash the canonical workflow-definition subset used by stage complexity routing."""
    if isinstance(workflow_definition, WorkflowDefinition):
        payload = workflow_definition.model_dump(mode="json")
    else:
        payload = dict(workflow_definition)
    stages = payload.get("stages")
    normalized_stages = []
    if isinstance(stages, list):
        for stage in stages:
            if not isinstance(stage, Mapping):
                continue
            normalized_stages.append(
                {
                    "id": str(stage.get("id") or stage.get("stage_id") or "").strip(),
                    "name": str(stage.get("name") or stage.get("title") or "").strip(),
                    "type": str(stage.get("type") or stage.get("stage_type") or "").strip(),
                    "description": str(
                        stage.get("description") or stage.get("purpose") or ""
                    ).strip(),
                    "prompt_template": stage.get("prompt_template"),
                    "input_schema": stage.get("input_schema"),
                    "output_schema": stage.get("output_schema"),
                    "depends_on": sorted(
                        str(item).strip()
                        for item in stage.get("depends_on", [])
                        if str(item).strip()
                    )
                    if isinstance(stage.get("depends_on"), list)
                    else [],
                }
            )
    canonical_payload = {
        "title": str(payload.get("title") or "").strip(),
        "description": str(payload.get("description") or "").strip(),
        "stages": normalized_stages,
    }
    return hashlib.sha256(
        json.dumps(canonical_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def load_cached_grades(
    compiled_plan: dict[str, Any],
    workflow_definition: WorkflowDefinition | Mapping[str, Any],
) -> list[Any] | None:
    """Return cached stage grades when the canonical workflow hash matches."""
    raw_cache = compiled_plan.get("complexity_grades")
    if not isinstance(raw_cache, Mapping):
        return None
    expected_hash = _compute_workflow_content_hash(workflow_definition)
    actual_hash = str(raw_cache.get("workflow_content_hash") or "").strip()
    if not actual_hash or actual_hash != expected_hash:
        return None
    raw_grades = raw_cache.get("grades")
    if not isinstance(raw_grades, list):
        return None
    from obra_business.complexity.stage_complexity_gate import StageComplexityGrade

    grades: list[StageComplexityGrade] = []
    for entry in raw_grades:
        if not isinstance(entry, Mapping):
            return None
        stage_id = str(entry.get("stage_id") or "").strip()
        grade = str(entry.get("grade") or "").strip().lower()
        rationale = str(entry.get("rationale") or "").strip()
        if not stage_id or grade not in {"low", "medium", "high"} or not rationale:
            return None
        grades.append(StageComplexityGrade(stage_id=stage_id, grade=grade, rationale=rationale))
    return grades


def _slugify(name: str) -> str:
    """Convert stage name to filename-safe slug.

    Args:
        name: Stage name (e.g., "Document Receipt")

    Returns:
        Slug (e.g., "document_receipt")
    """
    # Convert to lowercase
    slug = name.lower()
    # Replace spaces and hyphens with underscores
    slug = re.sub(r"[\s-]+", "_", slug)
    # Remove any non-alphanumeric characters except underscores
    slug = re.sub(r"[^\w]", "", slug)
    # Collapse multiple underscores
    slug = re.sub(r"_+", "_", slug)
    # Strip leading/trailing underscores
    return slug.strip("_")


class WorkflowCompiler:
    """Compiles workflow definitions into executable WORKFLOW_PLAN.json."""

    def __init__(self) -> None:
        """Initialize the compiler with configuration."""
        self.config = load_config()

    def compile(
        self,
        workflow_dir: Path,
        validate_only: bool = False,
    ) -> WorkflowPlanSchema | None:
        """Compile a workflow definition to WORKFLOW_PLAN.json.

        Loads definition.yaml, validates it, maps stages to stories,
        and generates a WORKFLOW_PLAN.json compatible with PlanReader.

        Args:
            workflow_dir: Directory containing definition.yaml
            validate_only: If True, validate without writing plan file

        Returns:
            WorkflowPlanSchema if successful, None if validate_only and valid

        Raises:
            CompilationError: If compilation fails (file not found, validation error, etc.)
        """
        definition_path = workflow_dir / "definition.yaml"

        # Load definition.yaml
        if not definition_path.exists():
            msg = f"definition.yaml not found in {workflow_dir}"
            raise CompilationError(msg)

        try:
            with definition_path.open(encoding="utf-8") as f:
                definition_data = yaml.safe_load(f)
        except yaml.YAMLError as e:
            msg = f"Invalid YAML in definition.yaml: {e}"
            raise CompilationError(msg) from e

        # Validate with WorkflowDefinition schema
        try:
            workflow = WorkflowDefinition.model_validate(definition_data)
        except ValidationError as e:
            msg = f"Workflow definition validation failed:\n{e}"
            raise CompilationError(msg) from e
        if not workflow.input_document.required_fields and workflow.input_document.input_schema is None:
            logger.warning(
                "Workflow %s has no required_fields and no input_schema - integrators cannot validate input",
                workflow.workflow_id,
            )
        if not workflow.output_document.deliverables:
            logger.warning(
                "Workflow %s has no declared deliverables - integrators cannot predict output",
                workflow.workflow_id,
            )
        _validate_declared_stage_runners(workflow.stages, domain_id="business")

        baseline_ref = build_business_baseline_workflow_ref(
            workflow,
            workflow_dir=workflow_dir,
            provenance="supplied",
            mission=workflow.title,
            source_kind="definition_yaml",
        )
        metadata = build_business_workflow_source_summary(
            workflow_definition=workflow.model_dump(mode="json"),
            source_kind="definition_yaml",
            source_provenance="supplied",
            source_definition="definition.yaml",
            workflow_version=workflow.version,
            workflow_derivation_request={
                "mission": workflow.title,
                "domain_id": "business",
                "baseline_workflow_ref": baseline_ref,
            },
        )
        source_payload = build_business_workflow_source_payload(
            workflow_definition=workflow.model_dump(mode="json"),
            source_kind="definition_yaml",
            source_provenance="supplied",
            source_definition="definition.yaml",
            workflow_version=workflow.version,
            workflow_derivation_request={
                "mission": workflow.title,
                "domain_id": "business",
                "baseline_workflow_ref": baseline_ref,
            },
        )
        return self._compile_workflow_source(
            workflow_dir=workflow_dir,
            workflow_id=workflow.workflow_id,
            title=workflow.title,
            description=workflow.description,
            stages=[
                {
                    "stage_id": stage.id,
                    "title": stage.name,
                    "description": stage.description,
                    "depends_on": list(stage.depends_on),
                    "parallel_group": stage.parallel_group,
                    "failure_policy": stage.failure_policy,
                    "inputs": _stage_inputs(workflow, stage.id, stage.depends_on),
                    "outputs": (
                        [workflow.output_document.name]
                        if stage.id == workflow.stages[-1].id
                        else [f"{stage.id}_output"]
                    ),
                    "rules": [
                        rule.id for rule in workflow.quality_rules if stage.id in rule.applies_to
                    ],
                    "quality_gates": [
                        rule.name for rule in workflow.quality_rules if stage.id in rule.applies_to
                    ],
                    "verify": "Stage completes successfully",
                    "stage_type": stage.type,
                    "model_tier": stage.model_tier,
                    "provider": stage.provider,
                    "model": stage.model,
                    "reasoning_level": stage.reasoning_level,
                    "auth_method": stage.auth_method,
                    "instruction_file": f"stages/{stage.id}_{_slugify(stage.name)}.md",
                    "require_instruction_file": True,
                    "quality_loop": dict(stage.quality_loop) if stage.quality_loop else None,
                    "context_policy": _context_policy_payload(stage.context_policy),
                    "runner_specs": _runner_specs_from_authored_runner(stage.runner),
                }
                for stage in workflow.stages
            ],
            completion_checklist=[
                "All stages completed",
                "Output document generated",
                "Quality gates passed",
            ],
            validate_only=validate_only,
            metadata=metadata,
            source_payload=source_payload,
        )

    def compile_workflow_artifact(
        self,
        *,
        workflow_dir: Path,
        workflow_artifact: WorkflowArtifactRecord | Mapping[str, object],
        validate_only: bool = False,
    ) -> WorkflowPlanSchema | None:
        """Compile an accepted W2 artifact into a runtime-safe WORKFLOW_PLAN.json."""
        source = build_business_workflow_source_from_artifact(workflow_artifact)
        workflow_definition = source["workflow_definition"]
        if not isinstance(workflow_definition, Mapping):
            msg = "Workflow artifact must provide metadata.workflow_definition"
            raise CompilationError(msg)

        stages = workflow_definition.get("stages")
        if not isinstance(stages, list) or not stages:
            msg = "Workflow artifact workflow_definition must include non-empty stages"
            raise CompilationError(msg)

        normalized_stages = []
        workflow_version = _resolve_workflow_version(
            workflow_definition,
            source.get("workflow_source_artifact")
            if isinstance(source.get("workflow_source_artifact"), Mapping)
            else None,
        )
        bindings_by_stage = normalize_template_bindings(
            workflow_definition,
            workflow_version=workflow_version,
        )
        for index, stage in enumerate(stages, start=1):
            if not isinstance(stage, Mapping):
                continue
            stage_id = str(stage.get("id") or f"S{index - 1}")
            stage_title = str(stage.get("title") or stage.get("name") or stage_id)
            verification = stage.get("verification") or stage.get("verify")
            instruction_file, require_instruction_file = _resolve_stage_instruction_binding(
                stage,
                stage_bindings=bindings_by_stage.get(stage_id, []),
            )
            normalized_stages.append(
                {
                    "stage_id": stage_id,
                    "title": stage_title,
                    "description": str(
                        stage.get("purpose")
                        or stage.get("description")
                        or stage.get("name")
                        or stage_title
                    ),
                    "verify": (
                        "; ".join(str(item) for item in verification)
                        if isinstance(verification, list) and verification
                        else str(verification or "Stage completes successfully")
                    ),
                    "depends_on": [
                        str(item).strip()
                        for item in stage.get("depends_on", [])
                        if str(item).strip()
                    ]
                    if isinstance(stage.get("depends_on"), list)
                    else [],
                    "parallel_group": (
                        str(stage.get("parallel_group")).strip()
                        if stage.get("parallel_group") is not None
                        and str(stage.get("parallel_group")).strip()
                        else None
                    ),
                    "failure_policy": (
                        str(stage.get("failure_policy")).strip()
                        if stage.get("failure_policy") is not None
                        and str(stage.get("failure_policy")).strip()
                        else None
                    ),
                    "inputs": [
                        str(item).strip()
                        for item in stage.get("inputs", [])
                        if str(item).strip()
                    ]
                    if isinstance(stage.get("inputs"), list)
                    else [],
                    "outputs": [
                        str(item).strip()
                        for item in stage.get("outputs", [])
                        if str(item).strip()
                    ]
                    if isinstance(stage.get("outputs"), list)
                    else [],
                    "rules": [
                        str(item).strip()
                        for item in stage.get("rules", [])
                        if str(item).strip()
                    ]
                    if isinstance(stage.get("rules"), list)
                    else [],
                    "quality_gates": [
                        str(item).strip()
                        for item in stage.get("quality_gates", [])
                        if str(item).strip()
                    ]
                    if isinstance(stage.get("quality_gates"), list)
                    else [],
                    "template_asset_bindings": [
                        dict(binding)
                        for binding in stage.get("template_asset_bindings", [])
                        if isinstance(binding, Mapping)
                    ]
                    if isinstance(stage.get("template_asset_bindings"), list)
                    else [],
                    "stage_type": _derive_stage_type(stage, index=index, total=len(stages)),
                    "model_tier": stage.get("model_tier"),
                    "provider": stage.get("provider"),
                    "model": stage.get("model"),
                    "reasoning_level": stage.get("reasoning_level"),
                    "auth_method": stage.get("auth_method"),
                    "instruction_file": instruction_file,
                    "require_instruction_file": require_instruction_file,
                    "quality_loop": (
                        dict(stage.get("quality_loop"))
                        if isinstance(stage.get("quality_loop"), Mapping)
                        else None
                    ),
                    "context_policy": _context_policy_payload(stage.get("context_policy")),
                    "runner_specs": _normalize_stage_runner_specs(stage),
                }
            )

        metadata = build_business_workflow_source_summary(
            workflow_definition=workflow_definition,
            source_kind=str(source.get("workflow_source_kind") or "workflow_derived"),
            source_provenance=str(
                source.get("workflow_source_provenance") or "synthesized"
            ),
            source_definition=str(
                source.get("source_definition") or "workflow_derived:unknown"
            ),
            workflow_version=workflow_version,
            source_artifact=(
                source.get("workflow_source_artifact")
                if isinstance(source.get("workflow_source_artifact"), Mapping)
                else None
            ),
            workflow_derivation_request=(
                source.get("workflow_derivation_request")
                if isinstance(source.get("workflow_derivation_request"), Mapping)
                else None
            ),
        )
        raw_workflow_id = (
                source.get("workflow_source_artifact", {}).get("artifact_id")
            if isinstance(source.get("workflow_source_artifact"), Mapping)
            else workflow_definition.get("workflow_id", "WORKFLOW-BUSINESS-001")
        )
        workflow_id = _coerce_workflow_id(str(raw_workflow_id or "WORKFLOW-BUSINESS-001"))
        source_payload = build_business_workflow_source_payload(
            workflow_definition=workflow_definition,
            source_kind=str(source.get("workflow_source_kind") or "workflow_derived"),
            source_provenance=str(
                source.get("workflow_source_provenance") or "synthesized"
            ),
            source_definition=str(
                source.get("source_definition") or "workflow_derived:unknown"
            ),
            workflow_version=workflow_version,
            source_artifact=(
                source.get("workflow_source_artifact")
                if isinstance(source.get("workflow_source_artifact"), Mapping)
                else None
            ),
            workflow_derivation_request=(
                source.get("workflow_derivation_request")
                if isinstance(source.get("workflow_derivation_request"), Mapping)
                else None
            ),
        )
        return self._compile_workflow_source(
            workflow_dir=workflow_dir,
            workflow_id=workflow_id,
            title=str(workflow_definition.get("title") or workflow_id),
            description=str(workflow_definition.get("description") or ""),
            stages=normalized_stages,
            completion_checklist=[
                "Accepted business workflow W2 compiled into runtime-safe plan",
                "Delegated business runtime completed successfully",
            ],
            validate_only=validate_only,
            metadata=metadata,
            source_payload=source_payload,
        )

    def _compile_workflow_source(
        self,
        *,
        workflow_dir: Path,
        workflow_id: str,
        title: str,
        description: str,
        stages: list[dict[str, object]],
        completion_checklist: list[str],
        validate_only: bool,
        metadata: dict[str, object],
        source_payload: dict[str, Any],
    ) -> WorkflowPlanSchema | None:
        stories = []
        compiled_stages = _enrich_compiled_stages(
            stages,
            default_failure_policy=get_parallel_default_failure_policy(self.config),
        )
        stage_type_tiers = self.config["business"]["llm"]["stage_type_tiers"]
        for index, stage in enumerate(compiled_stages, start=1):
            story_id = f"S{index}"
            instruction_file = str(stage.get("instruction_file", "") or "")
            if bool(stage.get("require_instruction_file")) and instruction_file:
                instruction_path = workflow_dir / instruction_file
                if not instruction_path.exists():
                    msg = f"Instruction file not found: {instruction_path}"
                    raise CompilationError(msg)

            task = WorkflowTaskSchema(
                id=f"{story_id}.T1",
                desc=str(stage.get("description", "") or f"Complete {stage.get('title', story_id)}"),
                status="pending",
                verify=str(stage.get("verify", "") or "Stage completes successfully"),
            )
            story_payload = {
                "id": story_id,
                "title": f"Stage {stage.get('stage_id')}: {stage.get('title')}",
                "status": "pending",
                "tasks": [task],
                "stage_id": str(stage.get("stage_id", f"S{index - 1}")),
                "stage_type": str(stage.get("stage_type", "business_stage")),
                "instruction_file": instruction_file or None,
                "model_tier": stage.get("model_tier"),
                "provider": stage.get("provider"),
                "model": stage.get("model"),
                "reasoning_level": stage.get("reasoning_level"),
                "auth_method": stage.get("auth_method"),
                "quality_loop": (
                    dict(stage.get("quality_loop"))
                    if isinstance(stage.get("quality_loop"), Mapping)
                    else None
                ),
                "context_policy": (
                    dict(stage.get("context_policy"))
                    if isinstance(stage.get("context_policy"), Mapping)
                    else _default_context_policy_for_stage(
                        str(stage.get("stage_type", "business_stage")),
                        [
                            str(item).strip()
                            for item in stage.get("depends_on", [])
                            if str(item).strip()
                        ]
                        if isinstance(stage.get("depends_on"), list)
                        else [],
                    )
                ),
                "runner_specs": (
                    [dict(spec) for spec in stage.get("runner_specs", []) if isinstance(spec, Mapping)]
                    if isinstance(stage.get("runner_specs"), list)
                    else None
                ),
            }
            for field_name in (
                "depends_on",
                "parallel_group",
                "topological_level",
                "failure_policy",
                "runner_specs",
                "inputs",
                "outputs",
                "rules",
                "quality_gates",
                "template_asset_bindings",
            ):
                if field_name in stage:
                    story_payload[field_name] = stage[field_name]

            stories.append(WorkflowStorySchema(**story_payload))

        epic = WorkflowEpicSchema(
            id="E1",
            title=title,
            description=description,
            status="pending",
            stories=stories,
        )
        plan = WorkflowPlanSchema(
            work_id=workflow_id,
            workflow_type="business",
            epics=[epic],
            completion_checklist=completion_checklist,
            compiled_at=datetime.now(UTC).isoformat(),
            **metadata,
        )
        stage_model_bindings = _compile_time_stage_model_bindings(
            compiled_stages=compiled_stages,
            stage_type_tiers=stage_type_tiers,
            config=self.config,
        )
        if stage_model_bindings:
            if getattr(plan, "__pydantic_extra__", None) is None:
                plan.__pydantic_extra__ = {}
            plan.__pydantic_extra__["stage_model_bindings"] = [
                binding.to_dict() for binding in stage_model_bindings
            ]

        if not validate_only:
            write_business_workflow_source_payload(workflow_dir, source_payload)
            plan_path = workflow_dir / "WORKFLOW_PLAN.json"
            with plan_path.open("w", encoding="utf-8") as f:
                json.dump(plan.model_dump(mode="json"), f, indent=2, ensure_ascii=False)
            logger.info("Wrote WORKFLOW_PLAN.json to %s", plan_path)
            self._verify_plan_reader_compatibility(plan_path)
        return plan

    def _verify_plan_reader_compatibility(self, plan_path: Path) -> None:
        """Verify the generated plan is loadable by PlanReader.

        This is a validation check only - logs warning on failure but
        doesn't fail compilation.

        Args:
            plan_path: Path to WORKFLOW_PLAN.json
        """
        try:
            # Lazy import to avoid circular dependency
            from obra.auto.plan_reader import PlanReader

            reader = PlanReader(str(plan_path))
            plan = reader.load()

            # Verify we can get the first pending story
            story = reader.get_next_pending_story()
            if story:
                logger.debug(
                    "PlanReader compatibility verified: found story %s",
                    story.get("id"),
                )
            else:
                logger.warning("PlanReader loaded plan but found no pending stories")

            # Additional validation: check plan has expected structure
            if "epics" not in plan:
                logger.warning("PlanReader loaded but plan missing 'epics' key")
            elif not plan["epics"]:
                logger.warning("PlanReader loaded but epics array is empty")

        except ImportError:
            logger.warning("Could not import obra.auto.plan_reader - skipping compatibility check")
        except Exception as e:
            logger.warning("PlanReader compatibility check failed: %s", e)


def _derive_stage_type(
    stage: Mapping[str, object],
    *,
    index: int,
    total: int,
) -> str:
    title = (
        f"{stage.get('title', '')} {stage.get('name', '')} "
        f"{stage.get('purpose', '')} {stage.get('description', '')}"
    ).lower()
    if index == 1:
        return "input_validation"
    if index == total:
        return "output"
    if "quality" in title or "review" in title:
        return "quality_gate"
    if "decision" in title or "approve" in title:
        return "decision"
    if "enrich" in title:
        return "enrichment"
    if "transform" in title or "normalize" in title:
        return "transformation"
    return "generation"


def _resolve_stage_instruction_binding(
    stage: Mapping[str, object],
    *,
    stage_bindings: list[object],
) -> tuple[str, bool]:
    """Resolve the compile-time instruction asset for an accepted W2 stage."""
    explicit_instruction = str(stage.get("instruction_file") or "").strip()
    if explicit_instruction:
        require_instruction = stage.get("require_instruction_file")
        return explicit_instruction, bool(True if require_instruction is None else require_instruction)

    primary_binding = choose_primary_instruction_binding(stage_bindings)
    if primary_binding is not None:
        binding_role = str(primary_binding.binding_role or "").strip()
        if binding_role != "primary_stage_instruction":
            msg = f"Unsupported stage instruction binding role: {binding_role}"
            raise CompilationError(msg)
        content_format = str(primary_binding.content_format or "").strip()
        if content_format and content_format != "markdown":
            msg = (
                "Stage instruction binding must materialize markdown content, "
                f"got {content_format!r}"
            )
            raise CompilationError(msg)
        materialized_path = str(
            primary_binding.materialization_metadata.get("path")
            or primary_binding.path_hint
            or ""
        ).strip()
        if materialized_path:
            return materialized_path, True

    stage_assets = stage.get("stage_assets")
    if not isinstance(stage_assets, list):
        return "", False

    for asset in stage_assets:
        asset_path = str(asset or "").strip()
        if asset_path.startswith("stages/") and asset_path.endswith(".md"):
            return asset_path, True
    return "", False


def _resolve_workflow_version(
    workflow_definition: Mapping[str, object],
    source_artifact: Mapping[str, object] | None,
) -> str | None:
    version = str(
        workflow_definition.get("version")
        or workflow_definition.get("workflow_version")
        or (source_artifact or {}).get("version")
        or ""
    ).strip()
    return version or None


def _default_llm_invoke_runner_specs() -> list[dict[str, Any]]:
    """Return the canonical runner_specs for a story with no authored runner.

    Per ADR-101, business stories without an explicit runner binding route
    through ``business.stage.llm_invoke`` so each story executes as a
    single LLM call against its authored instruction template. The
    framework on_start wrapper keeps using ``business.stage.command`` and
    is emitted elsewhere (see ``obra/domains/business/__init__.py``
    default pipeline config) — this helper only covers authored story
    stages.
    """
    return default_business_stage_llm_invoke_runner_specs()


def _runner_specs_from_authored_runner(
    runner: Any,
) -> list[dict[str, Any]] | None:
    """Project an authored runner binding into canonical runner_specs.

    When no authored runner is supplied, emit the default
    ``business.stage.llm_invoke`` runner_specs (ADR-101). Authored
    runners always win.
    """
    if runner is None:
        return _default_llm_invoke_runner_specs()
    return [
        {
            "runner_id": str(runner.runner_id),
            "runner_version": str(runner.runner_version or ""),
            "runner_selector": str(runner.runner_selector or ""),
            "runner_kind": "extension_runner",
            "runner_config": dict(runner.runner_config),
        }
    ]


def _normalize_stage_runner_specs(stage: Mapping[str, object]) -> list[dict[str, Any]] | None:
    """Normalize artifact-stage runner data to canonical runner_specs.

    When the artifact declares neither ``runner_specs`` nor an explicit
    ``runner``, fall back to the default ``business.stage.llm_invoke``
    runner_specs per ADR-101 so every compiled story encodes its
    dispatch target explicitly.
    """
    existing_specs = stage.get("runner_specs")
    if isinstance(existing_specs, list):
        return normalize_business_stage_runner_specs(existing_specs)

    runner = stage.get("runner")
    if not isinstance(runner, Mapping):
        return _default_llm_invoke_runner_specs()
    runner_id = str(runner.get("runner_id") or "").strip()
    if not runner_id:
        return _default_llm_invoke_runner_specs()
    return [
        {
            "runner_id": runner_id,
            "runner_version": str(runner.get("runner_version") or "").strip(),
            "runner_selector": str(runner.get("runner_selector") or "").strip(),
            "runner_kind": "extension_runner",
            "runner_config": (
                dict(runner.get("runner_config"))
                if isinstance(runner.get("runner_config"), Mapping)
                else {}
            ),
        }
    ]


def _validate_declared_stage_runners(
    stages: list[Any],
    *,
    domain_id: str,
) -> None:
    """Hard-fail compilation when authored runner ids are not registered."""
    available_runner_ids = {entry.id for entry in effective_catalog_for_domain(domain_id)}
    for stage in stages:
        stage_id = str(getattr(stage, "id", "") or "")
        runner = getattr(stage, "runner", None)
        if runner is None:
            continue
        runner_id = str(getattr(runner, "runner_id", "") or "").strip()
        if not runner_id or runner_id in available_runner_ids:
            continue
        raise CompilationError(
            f"Stage {stage_id} declares runner_id={runner_id!r} which is not registered for "
            f"domain {domain_id!r}. Run `obra catalog list --domain {domain_id}` to see "
            "available runners."
        )


def _coerce_workflow_id(value: str) -> str:
    if re.match(r"^WORKFLOW-[A-Z]+-\d{3}$", value):
        return value
    slug = re.sub(r"[^A-Za-z]+", "", value).upper() or "BUSINESS"
    return f"WORKFLOW-{slug[:20]}-001"


def _compile_time_stage_model_bindings(
    *,
    compiled_stages: list[dict[str, object]],
    stage_type_tiers: dict[str, Any],
    config: dict[str, Any],
) -> list[StageModelBinding]:
    """Emit bindings only for compile-time explicit stage overrides."""
    bindings: list[StageModelBinding] = []
    for stage in compiled_stages:
        binding = resolve_stage_binding(
            stage=stage,
            crosswalk=None,
            grade=None,
            stage_type_tiers=stage_type_tiers,
            config=config,
        )
        if binding.source in {"mosaic", "stage_tier"}:
            bindings.append(binding)
    return bindings


def _enrich_compiled_stages(
    stages: list[dict[str, object]],
    *,
    default_failure_policy: str,
) -> list[dict[str, object]]:
    """Normalize stage topology and attach deterministic wave metadata."""
    normalized: list[dict[str, object]] = []
    stage_id_order: list[str] = []
    stage_id_index: dict[str, int] = {}

    for index, raw_stage in enumerate(stages):
        stage = dict(raw_stage)
        stage_id = str(stage.get("stage_id") or stage.get("id") or f"S{index}").strip()
        if not stage_id:
            raise CompilationError(f"Stage at index {index} is missing stage_id.")
        if stage_id in stage_id_index:
            raise CompilationError(f"Duplicate stage_id in workflow compilation: {stage_id}")
        depends_on = [
            str(dependency).strip()
            for dependency in stage.get("depends_on", [])
            if str(dependency).strip()
        ]
        parallel_group = stage.get("parallel_group")
        normalized_group = (
            str(parallel_group).strip()
            if parallel_group is not None and str(parallel_group).strip()
            else None
        )
        failure_policy = stage.get("failure_policy")
        normalized_failure_policy = (
            str(failure_policy).strip()
            if failure_policy is not None and str(failure_policy).strip()
            else None
        )
        stage["stage_id"] = stage_id
        stage["depends_on"] = depends_on
        stage["parallel_group"] = normalized_group
        stage["failure_policy"] = normalized_failure_policy
        normalized.append(stage)
        stage_id_order.append(stage_id)
        stage_id_index[stage_id] = index

    for index, stage in enumerate(normalized):
        if not stage["depends_on"] and index > 0 and stage.get("parallel_group") is None:
            stage["depends_on"] = [stage_id_order[index - 1]]

    known_stage_ids = set(stage_id_order)
    group_members: dict[str, list[dict[str, object]]] = defaultdict(list)
    ordered_group_labels: list[str] = []
    for stage in normalized:
        stage_id = str(stage["stage_id"])
        dependencies = stage["depends_on"]
        if not isinstance(dependencies, list):
            raise CompilationError(f"Stage {stage_id} depends_on must be a list.")
        for dependency_id in dependencies:
            if dependency_id == stage_id:
                raise CompilationError(f"Stage {stage_id} cannot depend on itself.")
            if dependency_id not in known_stage_ids:
                raise CompilationError(
                    f"Stage {stage_id} depends on unknown stage '{dependency_id}'."
                )
        parallel_group = stage.get("parallel_group")
        if parallel_group is None:
            if stage.get("failure_policy") is not None:
                raise CompilationError(
                    f"Stage {stage_id} declares failure_policy without parallel_group."
                )
            continue
        group_label = str(parallel_group)
        if group_label not in group_members:
            ordered_group_labels.append(group_label)
        group_members[group_label].append(stage)

    group_id_map = {
        group_label: group_index
        for group_index, group_label in enumerate(ordered_group_labels, start=1)
    }

    for group_label, members in group_members.items():
        member_ids = {str(member["stage_id"]) for member in members}
        upstream_sets = {
            tuple(sorted(str(dependency) for dependency in member["depends_on"]))
            for member in members
        }
        if len(upstream_sets) > 1:
            member_list = ", ".join(sorted(member_ids))
            raise CompilationError(
                "Parallel group "
                f"{group_label!r} must use identical upstream dependencies across sibling stages. "
                f"Offending stages: {member_list}."
            )
        for member in members:
            member_id = str(member["stage_id"])
            if any(str(dependency) in member_ids for dependency in member["depends_on"]):
                raise CompilationError(
                    f"Parallel group {group_label!r} contains an intra-group dependency on stage "
                    f"{member_id}. Sibling stages in the same parallel_group may not depend on each other."
                )
        effective_policies = {
            str(member.get("failure_policy") or default_failure_policy) for member in members
        }
        if len(effective_policies) > 1:
            member_list = ", ".join(sorted(member_ids))
            raise CompilationError(
                "Parallel group "
                f"{group_label!r} declares conflicting failure_policy values across: {member_list}."
            )
        effective_policy = next(iter(effective_policies))
        for member in members:
            member["parallel_group"] = group_id_map[group_label]
            member["failure_policy"] = effective_policy

    downstream: dict[str, list[str]] = {stage_id: [] for stage_id in stage_id_order}
    indegree: dict[str, int] = {stage_id: 0 for stage_id in stage_id_order}
    topological_level: dict[str, int] = {stage_id: 0 for stage_id in stage_id_order}
    for stage in normalized:
        stage_id = str(stage["stage_id"])
        for dependency_id in stage["depends_on"]:
            downstream[str(dependency_id)].append(stage_id)
            indegree[stage_id] += 1

    ready = deque(
        sorted(
            (stage_id for stage_id, count in indegree.items() if count == 0),
            key=lambda stage_id: stage_id_index[stage_id],
        )
    )
    processed = 0
    while ready:
        stage_id = ready.popleft()
        processed += 1
        for child_id in sorted(downstream[stage_id], key=lambda item: stage_id_index[item]):
            topological_level[child_id] = max(
                topological_level[child_id],
                topological_level[stage_id] + 1,
            )
            indegree[child_id] -= 1
            if indegree[child_id] == 0:
                ready.append(child_id)

    if processed != len(normalized):
        raise CompilationError("Workflow stages contain a dependency cycle.")

    enriched: list[dict[str, object]] = []
    for stage in normalized:
        stage_id = str(stage["stage_id"])
        stage["topological_level"] = topological_level[stage_id]
        enriched.append(stage)
    return enriched
