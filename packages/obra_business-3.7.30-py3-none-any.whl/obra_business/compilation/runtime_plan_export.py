"""Refresh business WORKFLOW_PLAN.json from the authoritative runtime plan."""

from __future__ import annotations

import json
import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from obra_business.schemas.workflow_plan import WorkflowPlanSchema

logger = logging.getLogger(__name__)


def refresh_workflow_plan_export(
    *,
    workflow_dir: Path,
    authoritative_plan_items: list[dict[str, Any]],
) -> Path | None:
    """Refresh WORKFLOW_PLAN.json from authoritative refined plan items."""
    if not authoritative_plan_items:
        return None

    plan_path = workflow_dir / "WORKFLOW_PLAN.json"
    if not plan_path.exists():
        logger.debug("Skipping workflow plan export refresh; %s does not exist", plan_path)
        return None

    plan_data = json.loads(plan_path.read_text(encoding="utf-8"))
    if not isinstance(plan_data, dict):
        return None

    item_by_id = {
        str(item.get("id") or "").strip(): item
        for item in authoritative_plan_items
        if isinstance(item, dict) and str(item.get("id") or "").strip()
    }
    child_ids_by_parent: dict[str, list[str]] = {}
    for item in authoritative_plan_items:
        if not isinstance(item, dict):
            continue
        parent_id = str(item.get("parent_id") or "").strip()
        item_id = str(item.get("id") or "").strip()
        if not parent_id or not item_id:
            continue
        child_ids_by_parent.setdefault(parent_id, []).append(item_id)

    refreshed_epics: list[dict[str, Any]] = []
    for epic in plan_data.get("epics", []):
        if not isinstance(epic, dict):
            continue
        refreshed_stories: list[dict[str, Any]] = []
        for story in epic.get("stories", []):
            if not isinstance(story, dict):
                continue
            story_id = str(story.get("id") or "").strip()
            if not story_id:
                refreshed_stories.append(story)
                continue
            rendered_tasks = _render_story_tasks(
                story_id=story_id,
                authoritative_plan_items=authoritative_plan_items,
                item_by_id=item_by_id,
                child_ids_by_parent=child_ids_by_parent,
            )
            refreshed_story = dict(story)
            if rendered_tasks:
                refreshed_story["tasks"] = rendered_tasks
            refreshed_stories.append(refreshed_story)

        refreshed_epic = dict(epic)
        refreshed_epic["stories"] = refreshed_stories
        refreshed_epics.append(refreshed_epic)

    refreshed_plan = dict(plan_data)
    refreshed_plan["epics"] = refreshed_epics
    refreshed_plan["refreshed_at"] = datetime.now(UTC).isoformat()
    validated = WorkflowPlanSchema(**refreshed_plan)
    plan_path.write_text(
        json.dumps(validated.model_dump(mode="json"), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    logger.info("Refreshed WORKFLOW_PLAN.json from authoritative refined plan at %s", plan_path)
    return plan_path


def _render_story_tasks(
    *,
    story_id: str,
    authoritative_plan_items: list[dict[str, Any]],
    item_by_id: dict[str, dict[str, Any]],
    child_ids_by_parent: dict[str, list[str]],
) -> list[dict[str, Any]]:
    rendered: list[dict[str, Any]] = []
    for item in authoritative_plan_items:
        if not isinstance(item, dict):
            continue
        item_id = str(item.get("id") or "").strip()
        if not item_id:
            continue
        if _resolve_story_id(item, item_by_id) != story_id:
            continue
        if str(item.get("item_type") or "").strip() not in {"task", "subtask"}:
            continue
        if child_ids_by_parent.get(item_id):
            continue
        rendered.append(
            {
                "id": item_id,
                "desc": str(item.get("description") or item.get("title") or item_id),
                "status": str(item.get("status") or "pending"),
                "verify": _render_verify_text(item),
            }
        )
    return rendered


def _resolve_story_id(
    item: dict[str, Any],
    item_by_id: dict[str, dict[str, Any]],
) -> str | None:
    current = item
    while isinstance(current, dict):
        item_type = str(current.get("item_type") or "").strip()
        item_id = str(current.get("id") or "").strip()
        if item_type == "story" and item_id:
            return item_id
        parent_id = str(current.get("parent_id") or "").strip()
        if not parent_id:
            return None
        current = item_by_id.get(parent_id)
    return None


def _render_verify_text(item: dict[str, Any]) -> str:
    verification = item.get("verification")
    if isinstance(verification, list):
        parts = [str(entry).strip() for entry in verification if str(entry).strip()]
        if parts:
            return "; ".join(parts)
    acceptance_criteria = item.get("acceptance_criteria")
    if isinstance(acceptance_criteria, list):
        parts = [str(entry).strip() for entry in acceptance_criteria if str(entry).strip()]
        if parts:
            return "; ".join(parts)
    return str(item.get("title") or item.get("description") or "Task completes successfully.")
