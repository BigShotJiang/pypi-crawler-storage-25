"""Workflow compilation module.

Converts workflow definitions (definition.yaml) into executable
WORKFLOW_PLAN.json files compatible with Obra's PlanReader.
"""

from obra_business.compilation.compiler import CompilationError, WorkflowCompiler

__all__ = ["CompilationError", "WorkflowCompiler"]
