"""Packaged runner catalog providers for `obra-business`."""

from __future__ import annotations

from typing import Any

from obra.domains.business import BusinessDomain
from obra.domains.business import _business_runner_catalog_entries

INTERFACE_VERSION = "v3"


def get_runner_catalog_entries() -> list[dict[str, Any]]:
    """Return packaged runner catalog entries published by `obra-business`."""
    return _business_runner_catalog_entries(source_type="domain_package", package="obra-business")


class BusinessDomainModule(BusinessDomain):
    """Packaged domain adapter exposed through the `obra.domains` entry point."""

    INTERFACE_VERSION = INTERFACE_VERSION

    def get_runner_catalog_entries(self) -> list[dict[str, Any]]:
        """Expose packaged runner catalog entries for the business domain."""
        return get_runner_catalog_entries()
