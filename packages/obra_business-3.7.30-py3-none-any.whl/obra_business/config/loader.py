"""Configuration loader for the packaged business domain."""
import os
from pathlib import Path
from typing import Any

import yaml
from obra.schemas.stage_llm_override import normalize_inherit

from obra_business.schemas.workflow import (
    FAILURE_POLICY_VALUES,
    MODEL_TIER_VALUES,
    STAGE_TYPE_VALUES,
)

# Package default config path
DEFAULT_CONFIG_PATH = Path(__file__).parent / "default_config.yaml"

# Required config keys (fail fast if missing)
REQUIRED_KEYS = [
    "business.llm.extraction_model",
    "business.llm.execution_tier",
    "business.llm.stage_type_tiers",
    "business.llm.extraction_timeout_s",
    "business.llm.execution_timeout_s",
    "business.llm.context_budget.excerpt_chars",
    "business.llm.context_budget.total_chars",
    "business.llm.context_budget.full_recent_count",
    "business.complexity.estimator.enabled",
    "business.complexity.estimator.timeout_s",
    "business.complexity.estimator.max_retries",
    "business.complexity.estimator.max_input_tokens",
    "business.complexity.estimator.detail_batch_size",
    "business.crosswalk.preflight.cache_ttl_s",
    "business.crosswalk.default_mapping",
    "business.crosswalk.tier_fallback_order",
    "business.crosswalk.enforce_confirmation",
    "business.execution.parallel.enabled",
    "business.execution.parallel.max_concurrent_stages",
    "business.execution.parallel.default_failure_policy",
]

ENV_OVERRIDE_MAP = {
    "business.llm.execution_timeout_s": "OBRA_BIZ_LLM_EXECUTION_TIMEOUT_S",
    "business.llm.context_budget.excerpt_chars": (
        "OBRA_BIZ_LLM_CONTEXT_BUDGET_EXCERPT_CHARS"
    ),
    "business.llm.context_budget.total_chars": "OBRA_BIZ_LLM_CONTEXT_BUDGET_TOTAL_CHARS",
    "business.llm.context_budget.full_recent_count": (
        "OBRA_BIZ_LLM_CONTEXT_BUDGET_FULL_RECENT_COUNT"
    ),
    "business.execution.parallel.enabled": "OBRA_BIZ_PARALLEL_ENABLED",
    "business.execution.parallel.max_concurrent_stages": (
        "OBRA_BIZ_PARALLEL_MAX_CONCURRENT_STAGES"
    ),
    "business.execution.parallel.default_failure_policy": (
        "OBRA_BIZ_PARALLEL_DEFAULT_FAILURE_POLICY"
    ),
}

_LEGACY_PRIOR_OUTPUT_KEYS = (
    "prior_output_excerpt_chars",
    "prior_output_total_chars",
    "prior_output_full_recent_count",
)

_LEGACY_CONTEXT_BUDGET_ERROR = (
    "business.llm.prior_output_* keys removed by ADR-110; use "
    "business.llm.context_budget.{excerpt_chars,total_chars,full_recent_count} instead."
)


class ConfigError(Exception):
    """Configuration error."""


def normalize_stage_type_tier_entry(entry: Any) -> dict[str, str | None]:
    """Normalize one stage_type_tiers entry to the shared override shape."""
    normalized = {
        "model_tier": None,
        "provider": None,
        "model": None,
        "reasoning_level": None,
        "auth_method": None,
    }
    if isinstance(entry, str):
        normalized["model_tier"] = normalize_inherit(entry)
        return normalized
    if isinstance(entry, dict):
        for field_name in normalized:
            normalized[field_name] = normalize_inherit(entry.get(field_name))
        return normalized
    msg = (
        "business.llm.stage_type_tiers entries must be either a model tier string "
        "or a mapping with model_tier/provider/model/reasoning_level/auth_method."
    )
    raise ConfigError(msg)


def normalize_stage_type_tiers(entries: Any) -> dict[str, dict[str, str | None]]:
    """Normalize the full stage_type_tiers mapping."""
    if not isinstance(entries, dict):
        raise ConfigError("business.llm.stage_type_tiers must be a mapping.")
    return {
        str(stage_type): normalize_stage_type_tier_entry(entry)
        for stage_type, entry in entries.items()
    }


def load_config() -> dict[str, Any]:
    """Load merged configuration.

    Returns:
        Merged configuration dictionary

    Raises:
        ConfigError: If required keys are missing
    """
    # Start with defaults
    config = _load_yaml(DEFAULT_CONFIG_PATH)

    # Merge project-level configs
    for config_path in [
        Path(".obra/config.yaml"),
        Path(".obra-biz/config.yaml"),
    ]:
        if config_path.exists():
            project_config = _load_yaml(config_path)
            config = _deep_merge(config, project_config)

    _apply_env_overrides(config)

    # Validate required keys
    _validate_required_keys(config)
    _reject_legacy_prior_output_keys(config)
    _validate_tier_policy(config)
    _validate_complexity_policy(config)
    _validate_crosswalk_policy(config)
    _validate_parallel_policy(config)

    return config


def _load_yaml(path: Path) -> dict[str, Any]:
    """Load YAML file."""
    with path.open(encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Deep merge two dictionaries."""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _validate_required_keys(config: dict[str, Any]) -> None:
    """Validate all required keys are present.

    Raises:
        ConfigError: If any required key is missing
    """
    missing = []
    for key_path in REQUIRED_KEYS:
        parts = key_path.split(".")
        current: Any = config
        try:
            for part in parts:
                current = current[part]
        except (KeyError, TypeError):
            missing.append(key_path)

    if missing:
        msg = (
            f"Required configuration keys missing: {', '.join(missing)}. "
            "Set these in .obra-biz/config.yaml or the shared .obra/config.yaml."
        )
        raise ConfigError(msg)


def _reject_legacy_prior_output_keys(config: dict[str, Any]) -> None:
    """Reject removed prior-output budget keys after project config merge."""
    llm_config = config.get("business", {}).get("llm", {})
    if not isinstance(llm_config, dict):
        return
    if any(key in llm_config for key in _LEGACY_PRIOR_OUTPUT_KEYS):
        raise ConfigError(_LEGACY_CONTEXT_BUDGET_ERROR)


def _validate_tier_policy(config: dict[str, Any]) -> None:
    """Validate business tier policy config values."""
    llm_config = config.get("business", {}).get("llm", {})
    if not isinstance(llm_config, dict):
        raise ConfigError("business.llm must be a mapping.")

    execution_tier = llm_config.get("execution_tier")
    if execution_tier not in MODEL_TIER_VALUES:
        raise ConfigError(
            "business.llm.execution_tier must be one of: "
            + ", ".join(MODEL_TIER_VALUES)
        )

    for timeout_key in ("extraction_timeout_s", "execution_timeout_s"):
        timeout_s = llm_config.get(timeout_key)
        if not isinstance(timeout_s, int) or timeout_s < 600:
            raise ConfigError(f"business.llm.{timeout_key} must be an integer >= 600.")

    context_budget = llm_config.get("context_budget")
    if not isinstance(context_budget, dict):
        raise ConfigError("business.llm.context_budget must be a mapping.")

    excerpt_chars = context_budget.get("excerpt_chars")
    if not isinstance(excerpt_chars, int) or excerpt_chars < 1000:
        raise ConfigError(
            "business.llm.context_budget.excerpt_chars must be an integer >= 1000."
        )

    total_chars = context_budget.get("total_chars")
    if not isinstance(total_chars, int) or total_chars < excerpt_chars:
        raise ConfigError(
            "business.llm.context_budget.total_chars must be an integer >= "
            "business.llm.context_budget.excerpt_chars."
        )

    full_recent_count = context_budget.get("full_recent_count")
    if not isinstance(full_recent_count, int) or full_recent_count < 0:
        raise ConfigError(
            "business.llm.context_budget.full_recent_count must be an integer >= 0."
        )

    stage_type_tiers = normalize_stage_type_tiers(llm_config.get("stage_type_tiers"))
    llm_config["stage_type_tiers"] = stage_type_tiers

    missing_stage_types = [
        stage_type for stage_type in STAGE_TYPE_VALUES if stage_type not in stage_type_tiers
    ]
    if missing_stage_types:
        raise ConfigError(
            "business.llm.stage_type_tiers is missing canonical stage types: "
            + ", ".join(missing_stage_types)
        )

    unexpected_stage_types = sorted(
        str(stage_type)
        for stage_type in stage_type_tiers
        if stage_type not in STAGE_TYPE_VALUES
    )
    if unexpected_stage_types:
        raise ConfigError(
            "business.llm.stage_type_tiers contains unsupported stage types: "
            + ", ".join(unexpected_stage_types)
        )

    invalid_tiers = sorted(
        str(stage_type)
        for stage_type, tier_entry in stage_type_tiers.items()
        if tier_entry.get("model_tier") not in MODEL_TIER_VALUES
    )
    if invalid_tiers:
        raise ConfigError(
            "business.llm.stage_type_tiers values must be one of "
            + ", ".join(MODEL_TIER_VALUES)
            + "; invalid entries for: "
            + ", ".join(invalid_tiers)
        )


def _validate_complexity_policy(config: dict[str, Any]) -> None:
    """Validate business stage-complexity estimator configuration."""
    estimator_config = get_config_value(config, "business.complexity.estimator")
    if not isinstance(estimator_config, dict):
        raise ConfigError("business.complexity.estimator must be a mapping.")

    enabled = estimator_config.get("enabled")
    if not isinstance(enabled, bool):
        raise ConfigError("business.complexity.estimator.enabled must be a boolean.")

    timeout_s = estimator_config.get("timeout_s")
    if not isinstance(timeout_s, int) or timeout_s < 600:
        raise ConfigError("business.complexity.estimator.timeout_s must be an integer >= 600.")

    max_retries = estimator_config.get("max_retries")
    if not isinstance(max_retries, int) or max_retries < 0:
        raise ConfigError(
            "business.complexity.estimator.max_retries must be an integer >= 0."
        )

    max_input_tokens = estimator_config.get("max_input_tokens")
    if not isinstance(max_input_tokens, int) or max_input_tokens < 1:
        raise ConfigError(
            "business.complexity.estimator.max_input_tokens must be an integer >= 1."
        )

    detail_batch_size = estimator_config.get("detail_batch_size")
    if not isinstance(detail_batch_size, int) or detail_batch_size < 1:
        raise ConfigError(
            "business.complexity.estimator.detail_batch_size must be an integer >= 1."
        )

    for field_name in ("model", "provider", "reasoning_level"):
        value = estimator_config.get(field_name)
        if value is not None and not isinstance(value, str):
            raise ConfigError(
                f"business.complexity.estimator.{field_name} must be a string or null."
            )


def _validate_crosswalk_policy(config: dict[str, Any]) -> None:
    """Validate business crosswalk configuration."""
    crosswalk_config = get_config_value(config, "business.crosswalk")
    if not isinstance(crosswalk_config, dict):
        raise ConfigError("business.crosswalk must be a mapping.")

    preflight = crosswalk_config.get("preflight")
    if not isinstance(preflight, dict):
        raise ConfigError("business.crosswalk.preflight must be a mapping.")
    cache_ttl_s = preflight.get("cache_ttl_s")
    if not isinstance(cache_ttl_s, int) or cache_ttl_s < 0:
        raise ConfigError("business.crosswalk.preflight.cache_ttl_s must be an integer >= 0.")

    enforce_confirmation = crosswalk_config.get("enforce_confirmation")
    if not isinstance(enforce_confirmation, bool):
        raise ConfigError("business.crosswalk.enforce_confirmation must be a boolean.")

    default_mapping = crosswalk_config.get("default_mapping")
    if not isinstance(default_mapping, dict):
        raise ConfigError("business.crosswalk.default_mapping must be a mapping.")
    crosswalk_config["default_mapping"] = _normalize_grade_override_mapping(default_mapping)

    fallback_order = crosswalk_config.get("tier_fallback_order")
    if not isinstance(fallback_order, dict):
        raise ConfigError("business.crosswalk.tier_fallback_order must be a mapping.")
    normalized_fallback_order: dict[str, list[str]] = {}
    for grade in ("low", "medium", "high"):
        tiers = fallback_order.get(grade)
        if not isinstance(tiers, list) or not tiers:
            raise ConfigError(
                f"business.crosswalk.tier_fallback_order.{grade} must be a non-empty list."
            )
        normalized_tiers = []
        for tier in tiers:
            normalized_tier = normalize_inherit(tier)
            if normalized_tier not in MODEL_TIER_VALUES:
                raise ConfigError(
                    f"business.crosswalk.tier_fallback_order.{grade} values must be one of: "
                    + ", ".join(MODEL_TIER_VALUES)
                )
            normalized_tiers.append(str(normalized_tier))
        normalized_fallback_order[grade] = normalized_tiers
    crosswalk_config["tier_fallback_order"] = normalized_fallback_order

    delegation = crosswalk_config.get("delegation")
    if delegation is not None:
        if not isinstance(delegation, dict):
            raise ConfigError("business.crosswalk.delegation must be a mapping when provided.")
        max_depth = delegation.get("max_depth")
        if max_depth is not None and (not isinstance(max_depth, int) or max_depth < 1):
            raise ConfigError(
                "business.crosswalk.delegation.max_depth must be an integer >= 1 when "
                "provided. The delegation governor caps how many layers of nested "
                "`obra run` subprocesses a single top-level business run may fan out "
                "before fail-fast. Omit the key to inherit the built-in default "
                "(canonical_executor._DEFAULT_MAX_DELEGATION_DEPTH)."
            )


def _apply_env_overrides(config: dict[str, Any]) -> None:
    """Apply supported environment overrides before validation."""
    for key_path, env_var in ENV_OVERRIDE_MAP.items():
        raw_value = os.environ.get(env_var)
        if raw_value is None:
            continue
        _set_config_path(config, key_path, _coerce_env_value(key_path, raw_value))


def _coerce_env_value(key_path: str, raw_value: str) -> Any:
    """Coerce env values to the expected config type."""
    if key_path.endswith(".enabled"):
        lowered = raw_value.strip().lower()
        if lowered in {"1", "true", "yes", "on"}:
            return True
        if lowered in {"0", "false", "no", "off"}:
            return False
        raise ConfigError(f"{key_path} env override must be boolean, got {raw_value!r}")
    if key_path.endswith(
        (
            ".max_concurrent_stages",
            "_timeout_s",
            "_chars",
            "_count",
        )
    ):
        try:
            return int(raw_value)
        except ValueError as exc:
            raise ConfigError(
                f"{key_path} env override must be an integer, got {raw_value!r}"
            ) from exc
    return raw_value.strip()


def _set_config_path(config: dict[str, Any], key_path: str, value: Any) -> None:
    """Set a dot-path inside the config mapping."""
    parts = key_path.split(".")
    current = config
    for part in parts[:-1]:
        existing = current.get(part)
        if not isinstance(existing, dict):
            existing = {}
            current[part] = existing
        current = existing
    current[parts[-1]] = value


def _validate_parallel_policy(config: dict[str, Any]) -> None:
    """Validate business parallel execution configuration."""
    parallel_config = get_config_value(config, "business.execution.parallel")
    if not isinstance(parallel_config, dict):
        raise ConfigError("business.execution.parallel must be a mapping.")

    enabled = parallel_config.get("enabled")
    if not isinstance(enabled, bool):
        raise ConfigError("business.execution.parallel.enabled must be a boolean.")

    max_concurrent_stages = parallel_config.get("max_concurrent_stages")
    if not isinstance(max_concurrent_stages, int) or max_concurrent_stages < 1:
        raise ConfigError(
            "business.execution.parallel.max_concurrent_stages must be an integer >= 1."
        )

    default_failure_policy = parallel_config.get("default_failure_policy")
    if default_failure_policy not in FAILURE_POLICY_VALUES:
        raise ConfigError(
            "business.execution.parallel.default_failure_policy must be one of: "
            + ", ".join(FAILURE_POLICY_VALUES)
        )


def _normalize_grade_override_mapping(entries: Any) -> dict[str, dict[str, str | None]]:
    """Normalize the crosswalk default mapping by grade."""
    if not isinstance(entries, dict):
        raise ConfigError("business.crosswalk.default_mapping must be a mapping.")
    normalized: dict[str, dict[str, str | None]] = {}
    for grade in ("low", "medium", "high"):
        if grade not in entries:
            raise ConfigError(
                "business.crosswalk.default_mapping is missing grades: "
                + ", ".join(sorted(set(("low", "medium", "high")) - set(entries)))
            )
        normalized[grade] = _normalize_override_entry(
            entries[grade],
            label=f"business.crosswalk.default_mapping.{grade}",
        )
    return normalized


def _normalize_override_entry(entry: Any, *, label: str) -> dict[str, str | None]:
    """Normalize one shared override-shape mapping."""
    normalized = normalize_stage_type_tier_entry(entry)
    model_tier = normalized.get("model_tier")
    if model_tier not in MODEL_TIER_VALUES:
        raise ConfigError(f"{label}.model_tier must be one of: " + ", ".join(MODEL_TIER_VALUES))
    for field_name in ("provider", "model", "reasoning_level", "auth_method"):
        value = normalized.get(field_name)
        if value is not None and not isinstance(value, str):
            raise ConfigError(f"{label}.{field_name} must be a string or null.")
    return normalized


def get_config_value(config: dict[str, Any], key_path: str) -> Any:
    """Get a config value by dot-separated path.

    Args:
        config: Configuration dictionary
        key_path: Dot-separated path (e.g., "business.llm.extraction_model")

    Returns:
        Config value

    Raises:
        KeyError: If key not found (no silent fallbacks per Rule 22)
    """
    parts = key_path.split(".")
    current: Any = config
    for part in parts:
        current = current[part]  # Raises KeyError if missing
    return current


def get_parallel_execution_enabled(config: dict[str, Any]) -> bool:
    """Return whether business parallel execution is enabled."""
    value = get_config_value(config, "business.execution.parallel.enabled")
    if not isinstance(value, bool):
        raise ConfigError("business.execution.parallel.enabled must be a boolean.")
    return value


def get_parallel_max_concurrent_stages(config: dict[str, Any]) -> int:
    """Return the configured max number of concurrent business stages."""
    value = get_config_value(config, "business.execution.parallel.max_concurrent_stages")
    if not isinstance(value, int) or value < 1:
        raise ConfigError(
            "business.execution.parallel.max_concurrent_stages must be an integer >= 1."
        )
    return value


def get_parallel_default_failure_policy(config: dict[str, Any]) -> str:
    """Return the default same-group failure policy for parallel stages."""
    value = get_config_value(config, "business.execution.parallel.default_failure_policy")
    if value not in FAILURE_POLICY_VALUES:
        raise ConfigError(
            "business.execution.parallel.default_failure_policy must be one of: "
            + ", ".join(FAILURE_POLICY_VALUES)
        )
    return str(value)
