"""Configuration module for obra-biz."""
