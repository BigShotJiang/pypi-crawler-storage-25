"""Structured-output helpers for obra-biz workflow extraction.

This module defines the provider-compatible JSON schema, template scaffold, and
validation rules used by ``WorkflowExtractor`` when requesting structured
workflow output through ``TemplateEditPipeline``.
"""

from __future__ import annotations

import re
from typing import Any

from pydantic import ValidationError

from obra_business.schemas.workflow import WorkflowDefinition

_STAGE_DESCRIPTION_BULLET_RE = re.compile(r"(?:^|\n)\s*(?:[-*]|\d+\.)\s+", re.MULTILINE)
_STAGE_DESCRIPTION_PROCEDURAL_RE = re.compile(
    r"\b(?:step\s+\d+|step-by-step|checklist|follow these steps)\b",
    re.IGNORECASE,
)


def _strict_object_schema(properties: dict[str, Any]) -> dict[str, Any]:
    """Build a provider-compatible strict object schema."""
    return {
        "type": "object",
        "required": list(properties.keys()),
        "additionalProperties": False,
        "properties": properties,
    }


def _nullable(schema: dict[str, Any]) -> dict[str, Any]:
    """Allow a schema value or ``null``."""
    return {
        "anyOf": [
            schema,
            {"type": "null"},
        ]
    }


def build_workflow_extraction_template() -> dict[str, Any]:
    """Return the canonical structured template for workflow extraction."""
    return {
        "workflow_id": "WORKFLOW-AREA-001",
        "title": "Workflow Title",
        "version": "1.0.0",
        "description": "Brief workflow description.",
        "input_document": {
            "name": "Input Document",
            "format": "text",
            "required_fields": ["field_one"],
            "description": "What input is expected.",
            "input_schema": None,
        },
        "output_document": {
            "name": "Output Document",
            "format": "structured",
            "deliverables": ["deliverable_one"],
            "description": "What output is produced.",
        },
        "stages": [
            {
                "id": "S0",
                "name": "Input Validation",
                "type": "input_validation",
                "description": "Validate the input and flag any missing required fields.",
                "depends_on": [],
                "parallel_group": None,
                "failure_policy": None,
                "quality_loop": None,
            },
            {
                "id": "S1",
                "name": "Output Generation",
                "type": "output",
                "description": "Generate the final workflow deliverable from the validated input.",
                "depends_on": ["S0"],
                "parallel_group": None,
                "failure_policy": None,
                "quality_loop": None,
            },
        ],
        "quality_rules": [
            {
                "id": "QR1",
                "name": "Completeness Check",
                "description": "Ensure the final output includes each required deliverable.",
                "applies_to": ["S1"],
                "severity": "error",
            }
        ],
        "_instructions": (
            "Replace every placeholder value with a complete workflow definition. "
            "Output deliverables must be plain string identifiers, never keyed "
            "objects or embedded descriptions. "
            "Keep workflow and stage descriptions concise summaries, not detailed "
            "procedural instructions. Stage descriptions must be a single concise "
            "paragraph between 10 and 500 characters with no bullets, numbered "
            "steps, or checklists. Use depends_on as the canonical dependency "
            "surface. Use parallel_group only when sibling stages can run in "
            "parallel after the same upstream dependencies resolve, and keep "
            "failure_policy consistent within each parallel group. Use quality_loop "
            "only when a canonical stage quality-loop policy is genuinely required; "
            "otherwise return null."
        ),
    }


def build_workflow_extraction_output_schema() -> dict[str, Any]:
    """Return the strict structured-output schema for workflow extraction."""
    stage_quality_loop_schema = {
        "type": "object",
        "additionalProperties": True,
    }
    input_document_schema = _strict_object_schema(
        {
            "name": {"type": "string", "minLength": 1},
            "format": {
                "type": "string",
                "enum": ["text", "markdown", "json", "yaml", "structured"],
            },
            "required_fields": {
                "type": "array",
                "items": {"type": "string", "minLength": 1},
            },
            "description": {"type": "string", "minLength": 1, "maxLength": 500},
            "input_schema": _nullable({"type": "object"}),
        }
    )
    output_document_schema = _strict_object_schema(
        {
            "name": {"type": "string", "minLength": 1},
            "format": {
                "type": "string",
                "enum": ["text", "markdown", "json", "yaml", "structured"],
            },
            "deliverables": {
                "type": "array",
                "items": {"type": "string", "minLength": 1},
            },
            "description": {"type": "string", "minLength": 1, "maxLength": 500},
        }
    )
    stage_schema = _strict_object_schema(
        {
            "id": {"type": "string", "pattern": r"^S\d+$"},
            "name": {"type": "string", "minLength": 1, "maxLength": 50},
            "type": {
                "type": "string",
                "enum": [
                    "input_validation",
                    "transformation",
                    "enrichment",
                    "decision",
                    "generation",
                    "quality_gate",
                    "output",
                ],
            },
            "description": {"type": "string", "minLength": 10, "maxLength": 500},
            "depends_on": {
                "type": "array",
                "items": {"type": "string", "pattern": r"^S\d+$"},
            },
            "parallel_group": _nullable({"type": "string", "minLength": 1, "maxLength": 50}),
            "failure_policy": _nullable(
                {
                    "type": "string",
                    "enum": ["fail_fast", "all_settle"],
                }
            ),
            "quality_loop": _nullable(stage_quality_loop_schema),
        }
    )
    quality_rule_schema = _strict_object_schema(
        {
            "id": {"type": "string", "pattern": r"^QR\d+$"},
            "name": {"type": "string", "minLength": 1, "maxLength": 50},
            "description": {"type": "string", "minLength": 10, "maxLength": 500},
            "applies_to": {
                "type": "array",
                "minItems": 1,
                "items": {"type": "string", "pattern": r"^S\d+$"},
            },
            "severity": {"type": "string", "enum": ["error", "warning"]},
        }
    )
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        **_strict_object_schema(
            {
                "workflow_id": {"type": "string", "pattern": r"^WORKFLOW-[A-Z]+-\d{3}$"},
                "title": {"type": "string", "minLength": 5, "maxLength": 100},
                "version": {"type": "string", "pattern": r"^\d+\.\d+\.\d+$"},
                "description": {"type": "string", "minLength": 1, "maxLength": 1000},
                "input_document": input_document_schema,
                "output_document": output_document_schema,
                "stages": {
                    "type": "array",
                    "minItems": 2,
                    "maxItems": 50,
                    "items": stage_schema,
                },
                "quality_rules": {
                    "type": "array",
                    "items": quality_rule_schema,
                },
            }
        ),
    }


def validate_extracted_workflow_payload(data: dict[str, Any]) -> tuple[bool, str | None]:
    """Validate a structured extraction payload before accepting it."""
    if not isinstance(data, dict):
        return (False, "workflow extraction output must be a JSON object")

    try:
        workflow = WorkflowDefinition.model_validate(data)
    except ValidationError as exc:
        return (False, str(exc))

    stage_issue = _find_stage_description_issue(workflow)
    if stage_issue:
        return (False, stage_issue)

    return (True, None)


def materialize_extracted_workflow(data: dict[str, Any]) -> WorkflowDefinition:
    """Convert a structured payload into a validated workflow object."""
    workflow = WorkflowDefinition.model_validate(data)
    stage_issue = _find_stage_description_issue(workflow)
    if stage_issue:
        raise ValueError(stage_issue)
    return workflow


def _find_stage_description_issue(workflow: WorkflowDefinition) -> str | None:
    """Return a validation message when a stage summary is too procedural."""
    for stage in workflow.stages:
        description = stage.description.strip()
        if len(description) > 500:
            return (
                f"Stage {stage.id} description is {len(description)} characters. "
                "Keep stage descriptions between 10 and 500 characters."
            )
        if "\n" in description:
            return (
                f"Stage {stage.id} description must be a single concise paragraph. "
                "Move bullets, numbered steps, and checklists into the editable stage markdown file."
            )
        if _STAGE_DESCRIPTION_BULLET_RE.search(description):
            return (
                f"Stage {stage.id} description contains bullet or numbered-list formatting. "
                "Use a concise summary sentence instead of procedural instructions."
            )
        if _STAGE_DESCRIPTION_PROCEDURAL_RE.search(description):
            return (
                f"Stage {stage.id} description reads like procedural instructions. "
                "Summarize what the stage does and keep execution steps in the stage markdown file."
            )
    return None


__all__ = [
    "build_workflow_extraction_output_schema",
    "build_workflow_extraction_template",
    "materialize_extracted_workflow",
    "validate_extracted_workflow_payload",
]
