"""Structured workflow-extraction helpers kept for schema validation support."""

from obra_business.extraction.structured_output import build_workflow_extraction_output_schema

__all__ = ["build_workflow_extraction_output_schema"]
