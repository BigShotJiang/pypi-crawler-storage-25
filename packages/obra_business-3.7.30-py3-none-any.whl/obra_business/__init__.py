"""Obra Business Domain Plugin.

This package provides the business domain plugin for Obra, enabling
business process automation workflows without software development
assumptions.

The business domain is designed for:
- Document and report generation
- Business process workflows
- Content creation and review
- Non-technical artifact management

Main components:
- BusinessDomainPlugin: Domain plugin implementing DomainPlugin ABC
- FileWorkspaceManager: Filesystem-based workspace manager (no git required)
- BusinessReviewStrategy: Opt-in review strategy for business workflows
- Business validators for completeness and format checking

Example:
    >>> from obra_business import BusinessDomainPlugin
    >>> domain = BusinessDomainPlugin()
    >>> print(domain.name)
    'business'
    >>> workspace = domain.get_workspace_manager()
    >>> review = domain.get_review_strategy()

    # Using with Obra configuration
    # config.yaml:
    #   domain: business
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version
from typing import TYPE_CHECKING

try:
    __version__ = version("obra-business")
except PackageNotFoundError:
    __version__ = "0.0.0.dev"  # Running from source without install

if TYPE_CHECKING:
    from obra_business.plugin import BusinessDomainPlugin, create_business_domain
    from obra_business.review import BusinessReviewStrategy
    from obra_business.workspace import FileWorkspaceManager


def __getattr__(name: str) -> object:
    """Lazy-load plugin classes that depend on src.plugins (Obra internals)."""
    if name in ("BusinessDomainPlugin", "create_business_domain"):
        from obra_business.plugin import BusinessDomainPlugin, create_business_domain

        return BusinessDomainPlugin if name == "BusinessDomainPlugin" else create_business_domain
    if name == "BusinessReviewStrategy":
        from obra_business.review import BusinessReviewStrategy

        return BusinessReviewStrategy
    if name == "FileWorkspaceManager":
        from obra_business.workspace import FileWorkspaceManager

        return FileWorkspaceManager
    msg = f"module 'obra_business' has no attribute {name!r}"
    raise AttributeError(msg)


__all__ = [
    "BusinessDomainPlugin",
    "BusinessReviewStrategy",
    "FileWorkspaceManager",
    "__version__",
    "create_business_domain",
]
