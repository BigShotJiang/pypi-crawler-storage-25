"""Compatibility gating for delegating business workflow plans into Obra runtime."""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from obra.execution.intake import create_userplan_from_plan_file
from obra_business.runner_specs import (
    is_legacy_docs_placeholder_runner_specs,
    normalize_business_stage_runner_specs,
)


class PlanCompatibilityError(ValueError):
    """Raised when a workflow plan cannot be evaluated or normalized safely."""


@dataclass(frozen=True)
class PlanCompatibilityVerdict:
    """Structured compatibility result for a raw WORKFLOW_PLAN.json file."""

    mode: Literal["direct", "adapter_required"]
    reason_code: str
    detail: str


@dataclass(frozen=True)
class NormalizedPlanSelection:
    """Selected runtime plan path and the verdict that produced it."""

    plan_path: Path
    verdict: PlanCompatibilityVerdict


RepresentativeRunValidator = Callable[[Path], str | None]


def evaluate_plan_compatibility(plan_path: Path, workflow_id: str) -> PlanCompatibilityVerdict:
    """Determine whether a raw workflow plan can be passed to `obra run` directly."""
    plan_data = _load_plan(plan_path)
    epics = _extract_epics(plan_data, plan_path)
    normalization_reasons = _collect_normalization_reasons(plan_data, epics)

    plan_context = dict(plan_data)
    plan_context["epics"] = epics
    try:
        create_userplan_from_plan_file(
            plan_context=plan_context,
            project_id=workflow_id,
            plan_file_path=str(plan_path),
        )
    except Exception as exc:  # pragma: no cover - defensive; exercised in tests via monkeypatch
        if normalization_reasons:
            return PlanCompatibilityVerdict(
                mode="adapter_required",
                reason_code="probe_requires_normalization",
                detail=(
                    "Runtime intake probe rejected the raw workflow plan and the adapter "
                    f"can normalize these issues: {', '.join(normalization_reasons)}. "
                    f"Probe error: {exc}"
                ),
            )
        return PlanCompatibilityVerdict(
            mode="adapter_required",
            reason_code="probe_failed",
            detail=(
                "Runtime intake probe rejected the raw workflow plan. "
                f"Adapter normalization is required. Probe error: {exc}"
            ),
        )

    if normalization_reasons:
        return PlanCompatibilityVerdict(
            mode="adapter_required",
            reason_code="normalization_required",
            detail=(
                "Raw workflow plan needs deterministic normalization before delegation: "
                f"{', '.join(normalization_reasons)}"
            ),
        )

    return PlanCompatibilityVerdict(
        mode="direct",
        reason_code="direct_probe_passed",
        detail="Raw WORKFLOW_PLAN.json passed structural validation and runtime intake probe.",
    )


def select_runtime_plan(
    workflow_dir: Path,
    raw_plan_path: Path,
    workflow_id: str,
    representative_run_validator: RepresentativeRunValidator | None = None,
) -> NormalizedPlanSelection:
    """Select the delegated runtime plan path for `obra run --plan-file`."""
    verdict = evaluate_plan_compatibility(raw_plan_path, workflow_id)
    if verdict.mode == "direct":
        direct_path = raw_plan_path.resolve(strict=True)
        if representative_run_validator is None:
            return NormalizedPlanSelection(plan_path=direct_path, verdict=verdict)

        representative_error = representative_run_validator(direct_path)
        if representative_error is None:
            return NormalizedPlanSelection(plan_path=direct_path, verdict=verdict)

        adapted_path = write_adapted_runtime_plan(
            workflow_dir=workflow_dir,
            raw_plan_path=raw_plan_path,
            workflow_id=workflow_id,
        )
        adapted_error = representative_run_validator(adapted_path)
        if adapted_error is not None:
            msg = (
                "Representative delegated validation failed for both raw and adapted plans. "
                f"Raw error: {representative_error}. Adapted error: {adapted_error}"
            )
            raise PlanCompatibilityError(msg)

        return NormalizedPlanSelection(
            plan_path=adapted_path,
            verdict=PlanCompatibilityVerdict(
                mode="adapter_required",
                reason_code="representative_run_required_adapter",
                detail=(
                    "Raw WORKFLOW_PLAN.json failed representative delegated validation "
                    f"and required adapter normalization. Raw error: {representative_error}"
                ),
            ),
        )

    adapted_path = write_adapted_runtime_plan(
        workflow_dir=workflow_dir,
        raw_plan_path=raw_plan_path,
        workflow_id=workflow_id,
    )
    if representative_run_validator is not None:
        adapted_error = representative_run_validator(adapted_path)
        if adapted_error is not None:
            msg = (
                "Representative delegated validation failed for adapted workflow plan: "
                f"{adapted_error}"
            )
            raise PlanCompatibilityError(msg)
    return NormalizedPlanSelection(plan_path=adapted_path, verdict=verdict)


def write_adapted_runtime_plan(
    workflow_dir: Path,
    raw_plan_path: Path,
    workflow_id: str,
) -> Path:
    """Normalize a raw workflow plan into a runtime-safe machine-plan shape."""
    plan_data = _load_plan(raw_plan_path)
    epics = _extract_epics(plan_data, raw_plan_path)
    normalized_plan = _normalize_plan(plan_data, epics, workflow_id)

    runtime_plan_dir = workflow_dir / ".obra-biz" / "runtime-plan"
    runtime_plan_dir.mkdir(parents=True, exist_ok=True)
    adapted_path = runtime_plan_dir / f"{workflow_id}.json"
    adapted_path.write_text(json.dumps(normalized_plan, indent=2), encoding="utf-8")
    return adapted_path.resolve(strict=True)


def _load_plan(plan_path: Path) -> dict[str, Any]:
    try:
        raw_data = json.loads(plan_path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        msg = f"Workflow plan not found: {plan_path}"
        raise PlanCompatibilityError(msg) from exc
    except json.JSONDecodeError as exc:
        msg = f"Workflow plan is not valid JSON: {plan_path} ({exc})"
        raise PlanCompatibilityError(msg) from exc

    if not isinstance(raw_data, dict):
        msg = f"Workflow plan must be a JSON object: {plan_path}"
        raise PlanCompatibilityError(msg)
    return raw_data


def _extract_epics(plan_data: dict[str, Any], plan_path: Path) -> list[dict[str, Any]]:
    epics = plan_data.get("epics")
    if not isinstance(epics, list) or not epics:
        msg = f"Workflow plan missing non-empty 'epics' array: {plan_path}"
        raise PlanCompatibilityError(msg)

    normalized_epics: list[dict[str, Any]] = []
    for epic_index, epic in enumerate(epics, start=1):
        if not isinstance(epic, dict):
            msg = f"Workflow plan contains invalid epic entry at epics[{epic_index - 1}]: {plan_path}"
            raise PlanCompatibilityError(msg)

        stories = epic.get("stories")
        if not isinstance(stories, list) or not stories:
            epic_id = epic.get("id", f"E{epic_index}")
            msg = f"Epic {epic_id} missing non-empty 'stories' array: {plan_path}"
            raise PlanCompatibilityError(msg)

        normalized_stories: list[dict[str, Any]] = []
        for story_index, story in enumerate(stories, start=1):
            if not isinstance(story, dict):
                msg = (
                    "Workflow plan contains invalid story entry at "
                    f"epics[{epic_index - 1}].stories[{story_index - 1}]: {plan_path}"
                )
                raise PlanCompatibilityError(msg)

            tasks = story.get("tasks")
            if tasks is None:
                story_id = story.get("id", f"S{story_index}")
                msg = f"Story {story_id} missing 'tasks' array: {plan_path}"
                raise PlanCompatibilityError(msg)
            if not isinstance(tasks, list) or not tasks:
                story_id = story.get("id", f"S{story_index}")
                msg = f"Story {story_id} must contain a non-empty tasks array: {plan_path}"
                raise PlanCompatibilityError(msg)

            normalized_stories.append(story)

        normalized_epic = dict(epic)
        normalized_epic["stories"] = normalized_stories
        normalized_epics.append(normalized_epic)

    return normalized_epics


def _collect_normalization_reasons(
    plan_data: dict[str, Any],
    epics: list[dict[str, Any]],
) -> list[str]:
    reasons: list[str] = []
    if not _is_non_empty_string(plan_data.get("work_id")):
        reasons.append("missing_or_invalid_work_id")
    if not (
        _is_non_empty_string(plan_data.get("domain"))
        or _is_non_empty_string(plan_data.get("domain_id"))
        or _is_non_empty_string(plan_data.get("workflow_type"))
    ):
        reasons.append("missing_explicit_domain")

    for epic_index, epic in enumerate(epics, start=1):
        if not _is_non_empty_string(epic.get("id")):
            reasons.append(f"epic_{epic_index}_missing_id")
        if not _is_non_empty_string(epic.get("title")):
            reasons.append(f"epic_{epic_index}_missing_title")

        stories = epic["stories"]
        for story_index, story in enumerate(stories, start=1):
            story_prefix = f"story_{epic_index}_{story_index}"
            if not _is_non_empty_string(story.get("id")):
                reasons.append(f"{story_prefix}_missing_id")
            if not (_is_non_empty_string(story.get("title")) or _is_non_empty_string(story.get("desc"))):
                reasons.append(f"{story_prefix}_missing_title")
            if not _has_valid_runner_specs(story.get("runner_specs")):
                reasons.append(f"{story_prefix}_missing_runner_specs")
            elif is_legacy_docs_placeholder_runner_specs(story.get("runner_specs")):
                reasons.append(f"{story_prefix}_legacy_docs_runner_placeholder")

            task_entries = story["tasks"]
            for task_index, task in enumerate(task_entries, start=1):
                task_prefix = f"{story_prefix}_task_{task_index}"
                if isinstance(task, str):
                    continue
                if not isinstance(task, dict):
                    reasons.append(f"{task_prefix}_non_object_entry")
                    continue
                if not _is_non_empty_string(task.get("id")):
                    reasons.append(f"{task_prefix}_missing_id")
                if not (_is_non_empty_string(task.get("desc")) or _is_non_empty_string(task.get("title"))):
                    reasons.append(f"{task_prefix}_missing_desc")

    # Preserve deterministic order while removing duplicates.
    return list(dict.fromkeys(reasons))


def _normalize_plan(
    plan_data: dict[str, Any],
    epics: list[dict[str, Any]],
    workflow_id: str,
) -> dict[str, Any]:
    normalized_epics: list[dict[str, Any]] = []
    for epic_index, epic in enumerate(epics, start=1):
        epic_id = _text_or_default(epic.get("id"), f"E{epic_index}")
        epic_title = _text_or_default(epic.get("title"), f"Workflow Epic {epic_index}")
        normalized_stories: list[dict[str, Any]] = []

        for story_index, story in enumerate(epic["stories"], start=1):
            story_id = _text_or_default(story.get("id"), f"S{story_index}")
            stage_id = _text_or_default(story.get("stage_id"), story_id)
            story_title = _first_text(
                story.get("title"),
                story.get("desc"),
                story.get("description"),
                story.get("name"),
                f"Stage {stage_id}",
            )
            tasks: list[dict[str, Any]] = []
            for task_index, task in enumerate(story["tasks"], start=1):
                task_id = f"{story_id}.T{task_index}"
                if isinstance(task, str):
                    tasks.append(
                        {
                            "id": task_id,
                            "desc": task,
                            "status": "pending",
                            "verify": "Complete the normalized workflow task successfully.",
                        }
                    )
                    continue

                if not isinstance(task, dict):
                    tasks.append(
                        {
                            "id": task_id,
                            "desc": f"Normalized task {task_index} for {story_title}",
                            "status": "pending",
                            "verify": "Complete the normalized workflow task successfully.",
                        }
                    )
                    continue

                tasks.append(
                    {
                        "id": _text_or_default(task.get("id"), task_id),
                        "desc": _first_text(
                            task.get("desc"),
                            task.get("title"),
                            f"Complete {story_title}",
                        ),
                        "status": _text_or_default(task.get("status"), "pending"),
                        "verify": _first_text(
                            task.get("verify"),
                            story.get("verify"),
                            "Complete the normalized workflow task successfully.",
                        ),
                    }
                )

            normalized_stories.append(
                _preserve_story_runtime_fields(
                    {
                    "id": story_id,
                    "title": story_title,
                    "description": _text_or_default(story.get("description"), story_title),
                    "status": _text_or_default(story.get("status"), "pending"),
                    "tasks": tasks,
                    "stage_id": stage_id,
                    "stage_type": _text_or_default(story.get("stage_type"), "business_stage"),
                    "instruction_file": _text_or_default(story.get("instruction_file"), ""),
                    "quality_loop": (
                        dict(story.get("quality_loop"))
                        if isinstance(story.get("quality_loop"), dict)
                        else None
                    ),
                    "runner_specs": normalize_business_stage_runner_specs(
                        story.get("runner_specs"),
                        repair_legacy_docs_placeholder=True,
                    ),
                    },
                    story,
                )
            )

        normalized_epics.append(
            {
                "id": epic_id,
                "title": epic_title,
                "description": _text_or_default(epic.get("description"), epic_title),
                "status": _text_or_default(epic.get("status"), "pending"),
                "stories": normalized_stories,
            }
        )

    completion_checklist = plan_data.get("completion_checklist")
    if not isinstance(completion_checklist, list) or not all(
        isinstance(item, str) and item.strip() for item in completion_checklist
    ):
        completion_checklist = [
            "All normalized business workflow stories completed",
            "Delegated business runtime completed successfully",
        ]

    normalized_plan = {
        "work_id": _text_or_default(plan_data.get("work_id"), workflow_id),
        "workflow_type": _text_or_default(plan_data.get("workflow_type"), "business"),
        "epics": normalized_epics,
        "completion_checklist": completion_checklist,
        "source_definition": _text_or_default(plan_data.get("source_definition"), "definition.yaml"),
        "compiled_at": _text_or_default(plan_data.get("compiled_at"), "normalized-for-runtime"),
    }
    for key in (
        "workflow_source_kind",
        "workflow_source_provenance",
        "workflow_source_summary",
        "workflow_source_artifact",
        "workflow_derivation_request",
        "workflow_definition",
        "quality_dimensions",
        "lifecycle_capabilities",
        "lifecycle",
    ):
        if key in plan_data:
            normalized_plan[key] = plan_data[key]
    return normalized_plan


def _first_text(*values: Any) -> str:
    for value in values:
        if _is_non_empty_string(value):
            return str(value).strip()
    msg = "Expected at least one non-empty string value"
    raise PlanCompatibilityError(msg)


def _text_or_default(value: Any, default: str) -> str:
    if _is_non_empty_string(value):
        return str(value).strip()
    return default


def _is_non_empty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _has_valid_runner_specs(value: Any) -> bool:
    return (
        isinstance(value, list)
        and any(
            isinstance(spec, dict) and _is_non_empty_string(spec.get("runner_id"))
            for spec in value
        )
    )


def _preserve_story_runtime_fields(
    normalized_story: dict[str, Any],
    raw_story: dict[str, Any],
) -> dict[str, Any]:
    for field_name in (
        "depends_on",
        "parallel_group",
        "topological_level",
        "failure_policy",
        "inputs",
        "outputs",
        "rules",
        "quality_gates",
        "template_asset_bindings",
    ):
        if field_name in raw_story:
            normalized_story[field_name] = raw_story[field_name]
    return normalized_story
