# Icechunk

::: virtualizarr.parsers.IcechunkParser
