try:
    from mcp.server.fastmcp import FastMCP
except ImportError:  # pragma: no cover - fallback for older installs
    from fastmcp import FastMCP

from pathlib import Path

from .memory import is_obsidian_enabled, list_recent_session_files, recall_memory, write_session_summary

mcp = FastMCP("agent-mem")

_session: dict = {"memory_loaded": False}


@mcp.tool()
def query_memory(project_name: str, query: str) -> str:
    """MUST be called at the start of every new session.

    Use the project root folder name for project_name and a short goal-focused query.
    Works in both modes:
    - Obsidian mode: reads recent notes from <vault>/Memory/Agent-Mem
    - Fallback mode: reads local .agent-memory/memory.md
    """
    # Reset state so each query_memory call marks a clean session start,
    # preventing stale memory_loaded=True from a previous connection bleeding in.
    _session["memory_loaded"] = False
    project_root = Path.cwd().resolve()
    result = recall_memory(project_name, query, count=5, project_root=project_root)
    _session["memory_loaded"] = True
    return result

@mcp.tool()
def summarize_to_obsidian(project_name: str, summary: str) -> str:
    """Call when context is getting long (about 15-20 turns).

    Provide a structured markdown summary with decisions, file changes, open tasks,
    blockers, and next steps. After saving, suggest starting a fresh chat.

    This tool writes to Obsidian when configured, otherwise to local .agent-memory/memory.md.
    """
    project_root = Path.cwd().resolve()
    filepath = write_session_summary(project_name, summary, project_root=project_root)
    target = "Obsidian" if is_obsidian_enabled() else "local memory file"

    loaded = _session["memory_loaded"]
    _session["memory_loaded"] = False  # reset so next session starts clean

    result = (
        f"✅ Session summarized and saved to {target}: {filepath}\n"
        "You can now start a fresh chat. Future chats will use query_memory first."
    )
    if not loaded:
        result = (
            "⚠️ MEMORY NOT LOADED: query_memory was not called this session. "
            "Memory context is missing — summary may be incomplete. "
            "Call query_memory first, then re-summarize.\n\n"
        ) + result
    return result


@mcp.tool()
def list_recent_sessions(project_name: str, count: int = 3) -> str:
    """List recent memory notes for quick historical overviews.

    Useful when users ask about prior work before requesting deep details.
    In fallback mode, returns the local memory.md file when available.
    """
    project_root = Path.cwd().resolve()
    files = list_recent_session_files(project_name, count=count, project_root=project_root)
    if not files:
        result = "No sessions yet"
    elif is_obsidian_enabled():
        result = "\n".join(file_path.name for file_path in files)
    else:
        result = "\n".join(str(f.relative_to(project_root)) for f in files)

    if not _session["memory_loaded"]:
        result = (
            "⚠️ MEMORY NOT LOADED: Call query_memory before listing sessions to ensure context is active.\n\n"
        ) + result
    return result


@mcp.tool()
def session_status() -> str:
    """Check whether memory has been loaded in this session. Call to verify agent-mem compliance."""
    if _session["memory_loaded"]:
        return "✅ Memory loaded — session context active."
    return "❌ Memory NOT loaded — call query_memory before proceeding."
