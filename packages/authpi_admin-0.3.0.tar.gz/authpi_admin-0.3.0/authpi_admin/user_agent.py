"""Build a User-Agent header string for the Admin SDK.

Format: ``authpi-admin-py/<sdk-version> Python/<python-version> (<platform>; <arch>)``

Example: ``authpi-admin-py/0.2.0 Python/3.11.5 (linux; x86_64)``
"""

from __future__ import annotations

import platform
import sys

_SDK_NAME = "authpi-admin-py"


def build_user_agent(sdk_version: str) -> str:
    """Build the User-Agent string for this SDK."""
    py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    system = platform.system().lower()  # linux, darwin, windows
    machine = platform.machine().lower()  # x86_64, arm64, etc.
    return f"{_SDK_NAME}/{sdk_version} Python/{py_version} ({system}; {machine})"
