"""SDK version — kept in sync with pyproject.toml via release-please."""

# x-release-please-start-version
SDK_VERSION = "0.3.0"
# x-release-please-end
