"""AuthPI Admin SDK — Official Python client for the AuthPI Core API."""

from __future__ import annotations

__version__ = "0.3.0"

from authpi_admin.client import AuthPIAdmin
from authpi_admin.errors import (
    ApiError,
    AuthenticationError,
    BadGatewayError,
    ClosedClientError,
    ConfigurationError,
    ConflictError,
    ForbiddenError,
    GatewayTimeoutError,
    InternalServerError,
    NotFoundError,
    PreconditionFailedError,
    RateLimitError,
    ServerError,
    ServiceUnavailableError,
    UnexpectedError,
    ValidationError,
)
from authpi_admin.generated.scopes.issuer_scope import IssuerScope
from authpi_admin.generated.scopes.user_scope import UserScope
from authpi_admin.generated.scopes.agent_scope import AgentScope
from authpi_admin.generated.scopes.webhook_scope import WebhookScope
from authpi_admin.pagination import Page

__all__ = [
    "AgentScope",
    "ApiError",
    "AuthPIAdmin",
    "AuthenticationError",
    "BadGatewayError",
    "ClosedClientError",
    "ConfigurationError",
    "ConflictError",
    "ForbiddenError",
    "GatewayTimeoutError",
    "InternalServerError",
    "IssuerScope",
    "NotFoundError",
    "Page",
    "PreconditionFailedError",
    "RateLimitError",
    "ServerError",
    "ServiceUnavailableError",
    "UnexpectedError",
    "UserScope",
    "ValidationError",
    "WebhookScope",
]
