"""Generated resource class for api_keys — DO NOT EDIT."""

from __future__ import annotations

from typing import Any, AsyncIterator

from authpi_admin.http_client import HttpClient, validate_path_segment as _validate_path_segment
from authpi_admin.pagination import Page, auto_paginate
from authpi_admin.generated.models import (
    UpdateApiKey,
)


class ApiKeysResource:
    """Operations on api_keys."""

    def __init__(self, client: HttpClient, base_path: str) -> None:
        self._client = client
        self._base_path = base_path

    async def get(
        self,
        key_id: str,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Get API Key"""
        path = f"{self._base_path}/{key_id}"
        resp = await self._client.request("GET", path, timeout=timeout, headers=headers)
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def update(
        self,
        key_id: str,
        body: dict[str, Any],
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Update API Key"""
        path = f"{self._base_path}/{key_id}"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "PATCH",
            path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def delete(
        self,
        key_id: str,
        *,
        if_match: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Delete API Key"""
        path = f"{self._base_path}/{key_id}"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        await self._client.request(
            "DELETE",
            path,
            timeout=timeout,
            headers=req_headers or None,
        )

    async def block(
        self,
        key_id: str,
        body: dict[str, Any] | None = None,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Block API Key"""
        _validate_path_segment(key_id, "key_id")
        path = f"{self._base_path}/{key_id}/block"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def revoke(
        self,
        key_id: str,
        body: dict[str, Any] | None = None,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Revoke API Key"""
        _validate_path_segment(key_id, "key_id")
        path = f"{self._base_path}/{key_id}/revoke"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def rotate(
        self,
        key_id: str,
        body: dict[str, Any] | None = None,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Rotate API Key Secret"""
        _validate_path_segment(key_id, "key_id")
        path = f"{self._base_path}/{key_id}/rotate"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def unblock(
        self,
        key_id: str,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Unblock API Key"""
        _validate_path_segment(key_id, "key_id")
        path = f"{self._base_path}/{key_id}/unblock"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data
