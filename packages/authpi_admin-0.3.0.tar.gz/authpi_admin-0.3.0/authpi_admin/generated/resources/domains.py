"""Generated resource class for domains — DO NOT EDIT."""

from __future__ import annotations

from typing import Any, AsyncIterator

from authpi_admin.http_client import HttpClient, validate_path_segment as _validate_path_segment
from authpi_admin.pagination import Page, auto_paginate


class DomainsResource:
    """Operations on domains."""

    def __init__(self, client: HttpClient, base_path: str) -> None:
        self._client = client
        self._base_path = base_path

    async def list(
        self,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Page[dict[str, Any]]:
        """List Account Domains"""
        query: dict[str, Any] = {}
        resp = await self._client.request(
            "GET",
            self._base_path,
            query=query or None,
            timeout=timeout,
            headers=headers,
        )
        data = resp.data
        items = data.get("data", []) if data else []
        return Page(
            data=items,
            has_more=data.get("has_more", False) if data else False,
            next_cursor=data.get("next_cursor") if data else None,
        )

    async def list_all(
        self,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """Auto-paginating iterator over all domains."""
        async def _fetch(cursor: str | None = None) -> Page[dict[str, Any]]:
            return await self.list(
                timeout=timeout,
                headers=headers,
            )
        async for item in auto_paginate(_fetch):
            yield item

    async def create(
        self,
        body: dict[str, Any],
        *,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Add Account Domain"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            self._base_path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def delete(
        self,
        domain: str,
        *,
        if_match: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Remove Account Domain"""
        path = f"{self._base_path}/{domain}"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        await self._client.request(
            "DELETE",
            path,
            timeout=timeout,
            headers=req_headers or None,
        )

    async def assign(
        self,
        domain: str,
        body: dict[str, Any] | None = None,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Assign Domain to Issuer"""
        _validate_path_segment(domain, "domain")
        path = f"{self._base_path}/{domain}/assign"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def unassign(
        self,
        domain: str,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Unassign Domain from Issuer"""
        _validate_path_segment(domain, "domain")
        path = f"{self._base_path}/{domain}/unassign"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def verify(
        self,
        domain: str,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Verify Account Domain"""
        _validate_path_segment(domain, "domain")
        path = f"{self._base_path}/{domain}/verify"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data
