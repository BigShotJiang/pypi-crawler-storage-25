"""Generated resource class for organizations — DO NOT EDIT."""

from __future__ import annotations

from typing import Any, AsyncIterator

from authpi_admin.http_client import HttpClient, validate_path_segment as _validate_path_segment
from authpi_admin.pagination import Page, auto_paginate


class OrganizationsResource:
    """Operations on organizations."""

    def __init__(self, client: HttpClient, base_path: str) -> None:
        self._client = client
        self._base_path = base_path

    async def list(
        self,
        limit: int | None = None,
        cursor: str | None = None,
        status: str | None = None,
        sso_enabled: str | None = None,
        sso_only: str | None = None,
        mfa_required: str | None = None,
        invitation_enabled: str | None = None,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Page[dict[str, Any]]:
        """List Organizations"""
        query: dict[str, Any] = {}
        if limit is not None:
            query["limit"] = limit
        if cursor is not None:
            query["cursor"] = cursor
        if status is not None:
            query["status"] = status
        if sso_enabled is not None:
            query["sso_enabled"] = sso_enabled
        if sso_only is not None:
            query["sso_only"] = sso_only
        if mfa_required is not None:
            query["mfa_required"] = mfa_required
        if invitation_enabled is not None:
            query["invitation_enabled"] = invitation_enabled
        resp = await self._client.request(
            "GET",
            self._base_path,
            query=query or None,
            timeout=timeout,
            headers=headers,
        )
        data = resp.data
        items = data.get("data", []) if data else []
        return Page(
            data=items,
            has_more=data.get("has_more", False) if data else False,
            next_cursor=data.get("next_cursor") if data else None,
        )

    async def list_all(
        self,
        limit: int | None = None,
        status: str | None = None,
        sso_enabled: str | None = None,
        sso_only: str | None = None,
        mfa_required: str | None = None,
        invitation_enabled: str | None = None,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """Auto-paginating iterator over all organizations."""
        async def _fetch(cursor: str | None = None) -> Page[dict[str, Any]]:
            return await self.list(
                limit=limit,
                status=status,
                sso_enabled=sso_enabled,
                sso_only=sso_only,
                mfa_required=mfa_required,
                invitation_enabled=invitation_enabled,
                cursor=cursor,
                timeout=timeout,
                headers=headers,
            )
        async for item in auto_paginate(_fetch):
            yield item

    async def create(
        self,
        body: dict[str, Any],
        *,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Create Organization"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            self._base_path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def get(
        self,
        org_id: str,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Get Organization"""
        path = f"{self._base_path}/{org_id}"
        resp = await self._client.request("GET", path, timeout=timeout, headers=headers)
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def update(
        self,
        org_id: str,
        body: dict[str, Any],
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Update Organization"""
        path = f"{self._base_path}/{org_id}"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "PATCH",
            path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def delete(
        self,
        org_id: str,
        *,
        if_match: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Delete Organization"""
        path = f"{self._base_path}/{org_id}"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        await self._client.request(
            "DELETE",
            path,
            timeout=timeout,
            headers=req_headers or None,
        )

    async def domains_sso(
        self,
        org_id: str,
        body: dict[str, Any] | None = None,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Add SSO Domain"""
        _validate_path_segment(org_id, "org_id")
        path = f"{self._base_path}/{org_id}/sso/domains"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def rotate_secret_sso(
        self,
        org_id: str,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Rotate SSO Client Secret"""
        _validate_path_segment(org_id, "org_id")
        path = f"{self._base_path}/{org_id}/sso/rotate-secret"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data
