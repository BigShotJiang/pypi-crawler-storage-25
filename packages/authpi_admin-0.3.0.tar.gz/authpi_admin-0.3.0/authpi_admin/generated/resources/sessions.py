"""Generated resource class for sessions — DO NOT EDIT."""

from __future__ import annotations

from typing import Any, AsyncIterator

from authpi_admin.http_client import HttpClient, validate_path_segment as _validate_path_segment
from authpi_admin.pagination import Page, auto_paginate


class SessionsResource:
    """Operations on sessions."""

    def __init__(self, client: HttpClient, base_path: str) -> None:
        self._client = client
        self._base_path = base_path

    async def get(
        self,
        session_id: str,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Get Session"""
        path = f"{self._base_path}/{session_id}"
        resp = await self._client.request("GET", path, timeout=timeout, headers=headers)
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def reactivate(
        self,
        session_id: str,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Reactivate Session"""
        _validate_path_segment(session_id, "session_id")
        path = f"{self._base_path}/{session_id}/reactivate"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def revoke(
        self,
        session_id: str,
        body: dict[str, Any] | None = None,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Revoke Session"""
        _validate_path_segment(session_id, "session_id")
        path = f"{self._base_path}/{session_id}/revoke"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def suspend(
        self,
        session_id: str,
        body: dict[str, Any] | None = None,
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Suspend Session"""
        _validate_path_segment(session_id, "session_id")
        path = f"{self._base_path}/{session_id}/suspend"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data
