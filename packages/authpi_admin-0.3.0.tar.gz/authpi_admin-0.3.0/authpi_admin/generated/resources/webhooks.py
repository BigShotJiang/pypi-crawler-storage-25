"""Generated resource class for webhooks — DO NOT EDIT."""

from __future__ import annotations

from typing import Any, AsyncIterator

from authpi_admin.http_client import HttpClient, validate_path_segment as _validate_path_segment
from authpi_admin.pagination import Page, auto_paginate
from authpi_admin.generated.models import (
    WebhookListItem,
    CreateWebhookInput,
    UpdateWebhook,
)


class WebhooksResource:
    """Operations on webhooks."""

    def __init__(self, client: HttpClient, base_path: str) -> None:
        self._client = client
        self._base_path = base_path

    async def list(
        self,
        limit: int | None = None,
        cursor: str | None = None,
        status: str | None = None,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Page[WebhookListItem]:
        """List Webhooks"""
        query: dict[str, Any] = {}
        if limit is not None:
            query["limit"] = limit
        if cursor is not None:
            query["cursor"] = cursor
        if status is not None:
            query["status"] = status
        resp = await self._client.request(
            "GET",
            self._base_path,
            query=query or None,
            timeout=timeout,
            headers=headers,
        )
        data = resp.data
        items = [WebhookListItem(**item) for item in data.get("data", [])] if data else []
        return Page(
            data=items,
            has_more=data.get("has_more", False) if data else False,
            next_cursor=data.get("next_cursor") if data else None,
        )

    async def list_all(
        self,
        limit: int | None = None,
        status: str | None = None,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> AsyncIterator[WebhookListItem]:
        """Auto-paginating iterator over all webhooks."""
        async def _fetch(cursor: str | None = None) -> Page[WebhookListItem]:
            return await self.list(
                limit=limit,
                status=status,
                cursor=cursor,
                timeout=timeout,
                headers=headers,
            )
        async for item in auto_paginate(_fetch):
            yield item

    async def create(
        self,
        body: dict[str, Any],
        *,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Create Webhook"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            self._base_path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def get(
        self,
        resource_id: str,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Get Webhook"""
        path = f"{self._base_path}/{resource_id}"
        resp = await self._client.request("GET", path, timeout=timeout, headers=headers)
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def update(
        self,
        resource_id: str,
        body: dict[str, Any],
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Update Webhook"""
        path = f"{self._base_path}/{resource_id}"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "PATCH",
            path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def delete(
        self,
        resource_id: str,
        *,
        if_match: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Delete Webhook"""
        path = f"{self._base_path}/{resource_id}"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        await self._client.request(
            "DELETE",
            path,
            timeout=timeout,
            headers=req_headers or None,
        )
