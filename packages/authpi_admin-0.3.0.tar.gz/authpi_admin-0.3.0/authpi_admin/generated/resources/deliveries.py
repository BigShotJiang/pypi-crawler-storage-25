"""Generated resource class for deliveries — DO NOT EDIT."""

from __future__ import annotations

from typing import Any, AsyncIterator

from authpi_admin.http_client import HttpClient, validate_path_segment as _validate_path_segment
from authpi_admin.pagination import Page, auto_paginate


class DeliveriesResource:
    """Operations on deliveries."""

    def __init__(self, client: HttpClient, base_path: str) -> None:
        self._client = client
        self._base_path = base_path

    async def list(
        self,
        limit: int | None = None,
        cursor: str | None = None,
        event_type: str | None = None,
        status: str | None = None,
        after: float | None = None,
        before: float | None = None,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Page[dict[str, Any]]:
        """List Webhook Deliveries"""
        query: dict[str, Any] = {}
        if limit is not None:
            query["limit"] = limit
        if cursor is not None:
            query["cursor"] = cursor
        if event_type is not None:
            query["event_type"] = event_type
        if status is not None:
            query["status"] = status
        if after is not None:
            query["after"] = after
        if before is not None:
            query["before"] = before
        resp = await self._client.request(
            "GET",
            self._base_path,
            query=query or None,
            timeout=timeout,
            headers=headers,
        )
        data = resp.data
        items = data.get("data", []) if data else []
        return Page(
            data=items,
            has_more=data.get("has_more", False) if data else False,
            next_cursor=data.get("next_cursor") if data else None,
        )

    async def list_all(
        self,
        limit: int | None = None,
        event_type: str | None = None,
        status: str | None = None,
        after: float | None = None,
        before: float | None = None,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """Auto-paginating iterator over all deliveries."""
        async def _fetch(cursor: str | None = None) -> Page[dict[str, Any]]:
            return await self.list(
                limit=limit,
                event_type=event_type,
                status=status,
                after=after,
                before=before,
                cursor=cursor,
                timeout=timeout,
                headers=headers,
            )
        async for item in auto_paginate(_fetch):
            yield item
