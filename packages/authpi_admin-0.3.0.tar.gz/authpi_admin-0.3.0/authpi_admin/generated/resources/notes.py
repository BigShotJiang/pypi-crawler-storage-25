"""Generated resource class for notes — DO NOT EDIT."""

from __future__ import annotations

from typing import Any, AsyncIterator

from authpi_admin.http_client import HttpClient, validate_path_segment as _validate_path_segment
from authpi_admin.pagination import Page, auto_paginate
from authpi_admin.generated.models import (
    Note,
    CreateNoteInput,
    UpdateNoteInput,
)


class NotesResource:
    """Operations on notes."""

    def __init__(self, client: HttpClient, base_path: str) -> None:
        self._client = client
        self._base_path = base_path

    async def list(
        self,
        limit: int | None = None,
        cursor: str | None = None,
        subject_type: str | None = None,
        subject_id: str | None = None,
        issuer_id: str | None = None,
        created_by: str | None = None,
        pinned: bool | None = None,
        mentions_user_id: str | None = None,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Page[Note]:
        """List Notes"""
        query: dict[str, Any] = {}
        if limit is not None:
            query["limit"] = limit
        if cursor is not None:
            query["cursor"] = cursor
        if subject_type is not None:
            query["subject_type"] = subject_type
        if subject_id is not None:
            query["subject_id"] = subject_id
        if issuer_id is not None:
            query["issuer_id"] = issuer_id
        if created_by is not None:
            query["created_by"] = created_by
        if pinned is not None:
            query["pinned"] = pinned
        if mentions_user_id is not None:
            query["mentions_user_id"] = mentions_user_id
        resp = await self._client.request(
            "GET",
            self._base_path,
            query=query or None,
            timeout=timeout,
            headers=headers,
        )
        data = resp.data
        items = [Note(**item) for item in data.get("data", [])] if data else []
        return Page(
            data=items,
            has_more=data.get("has_more", False) if data else False,
            next_cursor=data.get("next_cursor") if data else None,
        )

    async def list_all(
        self,
        limit: int | None = None,
        subject_type: str | None = None,
        subject_id: str | None = None,
        issuer_id: str | None = None,
        created_by: str | None = None,
        pinned: bool | None = None,
        mentions_user_id: str | None = None,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> AsyncIterator[Note]:
        """Auto-paginating iterator over all notes."""
        async def _fetch(cursor: str | None = None) -> Page[Note]:
            return await self.list(
                limit=limit,
                subject_type=subject_type,
                subject_id=subject_id,
                issuer_id=issuer_id,
                created_by=created_by,
                pinned=pinned,
                mentions_user_id=mentions_user_id,
                cursor=cursor,
                timeout=timeout,
                headers=headers,
            )
        async for item in auto_paginate(_fetch):
            yield item

    async def create(
        self,
        body: dict[str, Any],
        *,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Create Note"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "POST",
            self._base_path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def get(
        self,
        note_id: str,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Get Note"""
        path = f"{self._base_path}/{note_id}"
        resp = await self._client.request("GET", path, timeout=timeout, headers=headers)
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def update(
        self,
        note_id: str,
        body: dict[str, Any],
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Update Note"""
        path = f"{self._base_path}/{note_id}"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "PATCH",
            path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data

    async def delete(
        self,
        note_id: str,
        *,
        if_match: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Delete Note"""
        path = f"{self._base_path}/{note_id}"
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        await self._client.request(
            "DELETE",
            path,
            timeout=timeout,
            headers=req_headers or None,
        )
