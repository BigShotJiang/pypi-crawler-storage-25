"""Generated resource class for events — DO NOT EDIT."""

from __future__ import annotations

from typing import Any, AsyncIterator

from authpi_admin.http_client import HttpClient, validate_path_segment as _validate_path_segment
from authpi_admin.pagination import Page, auto_paginate
from authpi_admin.generated.models import (
    Event,
)


class EventsResource:
    """Operations on events."""

    def __init__(self, client: HttpClient, base_path: str) -> None:
        self._client = client
        self._base_path = base_path

    async def list(
        self,
        limit: int | None = None,
        cursor: str | None = None,
        issuer_id: str | None = None,
        user_id: str | None = None,
        client_id: str | None = None,
        event_types: str | None = None,
        after: float | None = None,
        before: float | None = None,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Page[Event]:
        """List Events"""
        query: dict[str, Any] = {}
        if limit is not None:
            query["limit"] = limit
        if cursor is not None:
            query["cursor"] = cursor
        if issuer_id is not None:
            query["issuer_id"] = issuer_id
        if user_id is not None:
            query["user_id"] = user_id
        if client_id is not None:
            query["client_id"] = client_id
        if event_types is not None:
            query["event_types"] = event_types
        if after is not None:
            query["after"] = after
        if before is not None:
            query["before"] = before
        resp = await self._client.request(
            "GET",
            self._base_path,
            query=query or None,
            timeout=timeout,
            headers=headers,
        )
        data = resp.data
        items = [Event(**item) for item in data.get("data", [])] if data else []
        return Page(
            data=items,
            has_more=data.get("has_more", False) if data else False,
            next_cursor=data.get("next_cursor") if data else None,
        )

    async def list_all(
        self,
        limit: int | None = None,
        issuer_id: str | None = None,
        user_id: str | None = None,
        client_id: str | None = None,
        event_types: str | None = None,
        after: float | None = None,
        before: float | None = None,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> AsyncIterator[Event]:
        """Auto-paginating iterator over all events."""
        async def _fetch(cursor: str | None = None) -> Page[Event]:
            return await self.list(
                limit=limit,
                issuer_id=issuer_id,
                user_id=user_id,
                client_id=client_id,
                event_types=event_types,
                after=after,
                before=before,
                cursor=cursor,
                timeout=timeout,
                headers=headers,
            )
        async for item in auto_paginate(_fetch):
            yield item

    async def get(
        self,
        event_id: str,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Get Event"""
        path = f"{self._base_path}/{event_id}"
        resp = await self._client.request("GET", path, timeout=timeout, headers=headers)
        data = resp.data
        if resp.etag and isinstance(data, dict):
            data["_etag"] = resp.etag
        return data
