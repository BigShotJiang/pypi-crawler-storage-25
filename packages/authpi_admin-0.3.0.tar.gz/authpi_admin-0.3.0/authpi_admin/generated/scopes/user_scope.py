"""Generated scope class for UserScope — DO NOT EDIT."""

from __future__ import annotations

from functools import cached_property
from typing import Any, TYPE_CHECKING

from authpi_admin.http_client import validate_path_segment as _validate_path_segment

if TYPE_CHECKING:
    from authpi_admin.http_client import HttpClient
from authpi_admin.generated.resources.sessions import SessionsResource
from authpi_admin.generated.resources.tokens import TokensResource
from authpi_admin.generated.resources.trusted_devices import TrustedDevicesResource
from authpi_admin.generated.resources.verifiers import VerifiersResource


class UserScope:
    """Scope for operations under a specific user."""

    def __init__(self, client: HttpClient, base_path: str, user_id: str) -> None:
        _validate_path_segment(user_id, "user_id")
        self._client = client
        self._base_path = base_path
        self._user_id = user_id
        self._path = f"{base_path}/{user_id}"

    @cached_property
    def sessions(self) -> SessionsResource:
        """Access sessions under this user."""
        return SessionsResource(self._client, f"{self._path}/sessions")

    @cached_property
    def tokens(self) -> TokensResource:
        """Access tokens under this user."""
        return TokensResource(self._client, f"{self._path}/tokens")

    @cached_property
    def trusted_devices(self) -> TrustedDevicesResource:
        """Access trusted_devices under this user."""
        return TrustedDevicesResource(self._client, f"{self._path}/trusted-devices")

    @cached_property
    def verifiers(self) -> VerifiersResource:
        """Access verifiers under this user."""
        return VerifiersResource(self._client, f"{self._path}/verifiers")

    async def get(
        self,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Get User"""
        resp = await self._client.request("GET", self._path, timeout=timeout, headers=headers)
        return resp.data

    async def update(
        self,
        body: dict[str, Any],
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Update User"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "PATCH",
            self._path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        return resp.data

    async def delete(
        self,
        *,
        if_match: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Delete User"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        await self._client.request(
            "DELETE",
            self._path,
            timeout=timeout,
            headers=req_headers or None,
        )
