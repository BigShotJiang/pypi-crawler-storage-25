"""Generated scope class for AgentScope — DO NOT EDIT."""

from __future__ import annotations

from functools import cached_property
from typing import Any, TYPE_CHECKING

from authpi_admin.http_client import validate_path_segment as _validate_path_segment

if TYPE_CHECKING:
    from authpi_admin.http_client import HttpClient
from authpi_admin.generated.resources.verifiers import VerifiersResource


class AgentScope:
    """Scope for operations under a specific agent."""

    def __init__(self, client: HttpClient, base_path: str, agent_id: str) -> None:
        _validate_path_segment(agent_id, "agent_id")
        self._client = client
        self._base_path = base_path
        self._agent_id = agent_id
        self._path = f"{base_path}/{agent_id}"

    @cached_property
    def verifiers(self) -> VerifiersResource:
        """Access verifiers under this agent."""
        return VerifiersResource(self._client, f"{self._path}/verifiers")

    async def get(
        self,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Get Agent"""
        resp = await self._client.request("GET", self._path, timeout=timeout, headers=headers)
        return resp.data

    async def update(
        self,
        body: dict[str, Any],
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Update Agent"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "PATCH",
            self._path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        return resp.data

    async def delete(
        self,
        *,
        if_match: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Delete Agent"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        await self._client.request(
            "DELETE",
            self._path,
            timeout=timeout,
            headers=req_headers or None,
        )
