"""Generated scope class for IssuerScope — DO NOT EDIT."""

from __future__ import annotations

from functools import cached_property
from typing import Any, TYPE_CHECKING

from authpi_admin.http_client import validate_path_segment as _validate_path_segment

if TYPE_CHECKING:
    from authpi_admin.http_client import HttpClient
from authpi_admin.generated.resources.agents import AgentsResource
from authpi_admin.generated.resources.approvals import ApprovalsResource
from authpi_admin.generated.resources.auth_methods import AuthMethodsResource
from authpi_admin.generated.resources.clients import ClientsResource
from authpi_admin.generated.resources.organizations import OrganizationsResource
from authpi_admin.generated.resources.api_keys import ApiKeysResource
from authpi_admin.generated.resources.groups import GroupsResource
from authpi_admin.generated.resources.invitations import InvitationsResource
from authpi_admin.generated.resources.members import MembersResource
from authpi_admin.generated.resources.domains import DomainsResource
from authpi_admin.generated.resources.sessions import SessionsResource
from authpi_admin.generated.resources.users import UsersResource
from authpi_admin.generated.scopes.agent_scope import AgentScope
from authpi_admin.generated.scopes.user_scope import UserScope


class IssuerScope:
    """Scope for operations under a specific issuer."""

    def __init__(self, client: HttpClient, base_path: str, issuer_id: str) -> None:
        _validate_path_segment(issuer_id, "issuer_id")
        self._client = client
        self._base_path = base_path
        self._issuer_id = issuer_id
        self._path = f"{base_path}/{issuer_id}"

    @cached_property
    def agents(self) -> AgentsResource:
        """Access agents under this issuer."""
        return AgentsResource(self._client, f"{self._path}/agents")

    @cached_property
    def approvals(self) -> ApprovalsResource:
        """Access approvals under this issuer."""
        return ApprovalsResource(self._client, f"{self._path}/approvals")

    @cached_property
    def auth_methods(self) -> AuthMethodsResource:
        """Access auth_methods under this issuer."""
        return AuthMethodsResource(self._client, f"{self._path}/auth-methods")

    @cached_property
    def clients(self) -> ClientsResource:
        """Access clients under this issuer."""
        return ClientsResource(self._client, f"{self._path}/clients")

    @cached_property
    def organizations(self) -> OrganizationsResource:
        """Access organizations under this issuer."""
        return OrganizationsResource(self._client, f"{self._path}/organizations")

    @cached_property
    def api_keys(self) -> ApiKeysResource:
        """Access api_keys under this issuer."""
        return ApiKeysResource(self._client, f"{self._path}/api-keys")

    @cached_property
    def groups(self) -> GroupsResource:
        """Access groups under this issuer."""
        return GroupsResource(self._client, f"{self._path}/groups")

    @cached_property
    def invitations(self) -> InvitationsResource:
        """Access invitations under this issuer."""
        return InvitationsResource(self._client, f"{self._path}/invitations")

    @cached_property
    def members(self) -> MembersResource:
        """Access members under this issuer."""
        return MembersResource(self._client, f"{self._path}/members")

    @cached_property
    def domains(self) -> DomainsResource:
        """Access domains under this issuer."""
        return DomainsResource(self._client, f"{self._path}/domains")

    @cached_property
    def sessions(self) -> SessionsResource:
        """Access sessions under this issuer."""
        return SessionsResource(self._client, f"{self._path}/sessions")

    @cached_property
    def users(self) -> UsersResource:
        """Access users under this issuer."""
        return UsersResource(self._client, f"{self._path}/users")

    def agent(self, agent_id: str) -> AgentScope:
        """Scope into a specific agent."""
        return AgentScope(self._client, f"{self._path}/agents", agent_id)

    def user(self, user_id: str) -> UserScope:
        """Scope into a specific user."""
        return UserScope(self._client, f"{self._path}/users", user_id)

    async def get(
        self,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Get Issuer"""
        resp = await self._client.request("GET", self._path, timeout=timeout, headers=headers)
        return resp.data

    async def update(
        self,
        body: dict[str, Any],
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Update Issuer"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "PATCH",
            self._path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        return resp.data

    async def delete(
        self,
        *,
        if_match: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Delete Issuer"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        await self._client.request(
            "DELETE",
            self._path,
            timeout=timeout,
            headers=req_headers or None,
        )
