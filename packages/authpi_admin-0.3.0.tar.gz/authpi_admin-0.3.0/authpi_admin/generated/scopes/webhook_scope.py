"""Generated scope class for WebhookScope — DO NOT EDIT."""

from __future__ import annotations

from functools import cached_property
from typing import Any, TYPE_CHECKING

from authpi_admin.http_client import validate_path_segment as _validate_path_segment

if TYPE_CHECKING:
    from authpi_admin.http_client import HttpClient
from authpi_admin.generated.resources.deliveries import DeliveriesResource


class WebhookScope:
    """Scope for operations under a specific webhook."""

    def __init__(self, client: HttpClient, base_path: str, webhook_id: str) -> None:
        _validate_path_segment(webhook_id, "webhook_id")
        self._client = client
        self._base_path = base_path
        self._webhook_id = webhook_id
        self._path = f"{base_path}/{webhook_id}"

    @cached_property
    def deliveries(self) -> DeliveriesResource:
        """Access deliveries under this webhook."""
        return DeliveriesResource(self._client, f"{self._path}/deliveries")

    async def get(
        self,
        *,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Get Webhook"""
        resp = await self._client.request("GET", self._path, timeout=timeout, headers=headers)
        return resp.data

    async def update(
        self,
        body: dict[str, Any],
        *,
        if_match: str | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Update Webhook"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        if idempotency_key:
            req_headers["idempotency-key"] = idempotency_key
        resp = await self._client.request(
            "PATCH",
            self._path,
            body=body,
            timeout=timeout,
            headers=req_headers or None,
        )
        return resp.data

    async def delete(
        self,
        *,
        if_match: str | None = None,
        timeout: float | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Delete Webhook"""
        req_headers: dict[str, str] = {}
        if headers:
            req_headers.update(headers)
        if if_match:
            req_headers["if-match"] = if_match
        await self._client.request(
            "DELETE",
            self._path,
            timeout=timeout,
            headers=req_headers or None,
        )
