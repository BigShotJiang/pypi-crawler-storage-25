"""Generated Pydantic models — DO NOT EDIT."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, PrivateAttr

class NoteSubjectType(str, Enum):
    """Type of resource the note is attached to"""
    USER = "user"
    ORG = "org"
    ISSUER = "issuer"
    CLIENT = "client"
    AGENT = "agent"

class NoteRefType(str, Enum):
    """Type of the referenced resource"""
    USER = "user"
    ORG = "org"
    ISSUER = "issuer"
    CLIENT = "client"
    WEBHOOK = "webhook"
    API_KEY = "api_key"

class Address(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    line1: str | None = None
    line2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str

class Metadata(BaseModel):
    model_config = ConfigDict(frozen=True, extra="allow")

    _etag: str | None = PrivateAttr(default=None)


class FieldError(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    field: str
    code: str
    message: str

class ApiError(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    error: str
    error_description: str
    reference: str | None = None
    retryable: bool
    retry_after: int | None = None
    fields: list[FieldError] | None = None

class PreconditionFailedError(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    error: str
    error_description: str
    reference: str | None = None
    retryable: bool
    retry_after: int | None = None
    fields: list[FieldError] | None = None
    current_etag: str | None = None

class Client(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    id: str
    issuer_id: str
    status: str
    type: str
    confidential: bool
    secret_rotated_at: int | None = None
    name: str
    description: str
    logo_url: str
    settings: dict[str, Any]
    status_at: int | None = None
    metadata: Metadata | None = None
    created_at: int
    updated_at: int | None = None

class Event(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    spec: str
    id: str
    trace: str | None = None
    type: str
    source: str
    trigger: str | None = None
    auth: dict[str, Any] | None = None
    subject: dict[str, Any] | None = None
    timestamp: float
    data: dict[str, Any] | None = None

class WebhookListItem(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    id: str
    account_id: str
    status: str
    name: str
    description: str
    url: str
    auth_type: str
    events: list[str]
    status_at: int
    created_at: int
    updated_at: int

class CreateWebhookResponseAuth(BaseModel):
    """Union type (oneOf)"""
    model_config = ConfigDict(frozen=True, extra="allow")

    _etag: str | None = PrivateAttr(default=None)


class CreateAuthInput(BaseModel):
    """Union type (oneOf)"""
    model_config = ConfigDict(frozen=True, extra="allow")

    _etag: str | None = PrivateAttr(default=None)


class CreateWebhookInput(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    name: str
    description: str | None = None
    url: str
    status: str | None = None
    auth: CreateAuthInput
    events: list[str]
    subjects: list[dict[str, Any]] | None = None
    retry: dict[str, Any] | None = None
    circuit_breaker: dict[str, Any] | None = None
    metadata: Metadata | None = None

class WebhookAuth(BaseModel):
    """Union type (oneOf)"""
    model_config = ConfigDict(frozen=True, extra="allow")

    _etag: str | None = PrivateAttr(default=None)


class Webhook(BaseModel):
    """The webhook configuration"""
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    id: str
    account_id: str
    name: str
    description: str | None = None
    url: str
    status: str | None = None
    status_at: int | None = None
    status_reason: str | None = None
    status_by: str | None = None
    auth: WebhookAuth
    events: list[str]
    subjects: list[dict[str, Any]] | None = None
    retry: dict[str, Any] | None = None
    circuit_breaker: dict[str, Any] | None = None
    metadata: Metadata | None = None
    created_at: int
    updated_at: int | None = None

class UpdateWebhookResponseAuth(BaseModel):
    """Union type (oneOf)"""
    model_config = ConfigDict(frozen=True, extra="allow")

    _etag: str | None = PrivateAttr(default=None)


class UpdateAuthInput(BaseModel):
    """Union type (oneOf)"""
    model_config = ConfigDict(frozen=True, extra="allow")

    _etag: str | None = PrivateAttr(default=None)


class UpdateWebhook(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    name: str | None = None
    description: str | None = None
    url: str | None = None
    status: str | None = None
    status_reason: str | None = None
    status_by: str | None = None
    auth: UpdateAuthInput | None = None
    events: list[str] | None = None
    subjects: list[dict[str, Any]] | None = None
    retry: dict[str, Any] | None = None
    circuit_breaker: dict[str, Any] | None = None
    metadata: Metadata | None = None

class ApiKey(BaseModel):
    """The API key details"""
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    issuer_id: str
    type: str
    name: str
    description: str | None = None
    tags: list[str] | None = None
    restrictions: dict[str, Any]
    status: str | None = None
    status_at: int | None = None
    status_reason: str | None = None
    status_by: str | None = None
    expires_at: int | None = None
    metadata: Metadata | None = None
    created_at: int
    updated_at: int | None = None
    id: str
    org_id: str
    secret: dict[str, Any]

class UpdateApiKey(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    status: str | None = None
    status_reason: str | None = None
    status_by: str | None = None
    name: str | None = None
    description: str | None = None
    tags: list[str] | None = None
    restrictions: dict[str, Any] | None = None
    expires_at: int | None = None
    metadata: Metadata | None = None

class PersonalToken(BaseModel):
    """The personal token details"""
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    issuer_id: str
    type: str
    name: str
    description: str | None = None
    tags: list[str] | None = None
    restrictions: dict[str, Any]
    status: str | None = None
    status_at: int | None = None
    status_reason: str | None = None
    status_by: str | None = None
    expires_at: int | None = None
    metadata: Metadata | None = None
    created_at: int
    updated_at: int | None = None
    id: str
    user_id: str
    audience: str | None = None
    jti: str | None = None

class Session(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    id: str
    user_id: str
    issuer_id: str
    type: str
    status: str
    status_at: int | None = None
    status_reason: str | None = None
    status_by: str | None = None
    authentication: dict[str, Any] | None = None
    client: dict[str, Any] | None = None
    op_session_id: str | None = None
    device: dict[str, Any] | None = None
    location: dict[str, Any] | None = None
    origin: str | None = None
    ttl: int | None = None
    idle_timeout: int | None = None
    last_activity_at: int | None = None
    access_token_issued_at: int | None = None
    refresh_token_issued_at: int | None = None
    refresh_count: int | None = None
    secret: str | None = None
    compromised: bool | None = None
    compromised_at: int | None = None
    compromised_reason: str | None = None
    revoked_reason: str | None = None
    metadata: Metadata | None = None
    created_at: int
    updated_at: int | None = None
    expires_at: int | None = None
    revoked_at: int | None = None

class NoteMention(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    mentioned_user_id: str
    created_at: float

class NoteReference(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    ref_type: NoteRefType
    ref_id: str
    ref_issuer_id: str
    created_at: float

class Note(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    id: str
    account_id: str
    issuer_id: str
    subject_type: NoteSubjectType
    subject_id: str
    content: str
    pinned: bool
    created_by: str
    updated_by: str
    created_at: float
    updated_at: float
    mentions: list[NoteMention] | None = None
    references: list[NoteReference] | None = None

class CreateNoteInput(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    subject_type: NoteSubjectType
    subject_id: str
    issuer_id: str | None = None
    content: str
    pinned: bool | None = None

class UpdateNoteInput(BaseModel):
    model_config = ConfigDict(frozen=True)

    _etag: str | None = PrivateAttr(default=None)

    content: str | None = None
    pinned: bool | None = None

