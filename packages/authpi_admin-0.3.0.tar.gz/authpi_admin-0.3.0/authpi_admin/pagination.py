"""Cursor-based pagination helpers."""

from __future__ import annotations

from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from typing import Generic, TypeVar

T = TypeVar("T")


@dataclass(frozen=True)
class Page(Generic[T]):
    """A single page of results from a paginated endpoint."""

    data: list[T]
    has_more: bool
    next_cursor: str | None = None


async def auto_paginate(
    fetcher: Callable[[str | None], Awaitable[Page[T]]],
) -> AsyncIterator[T]:
    """Automatically paginate through all results.

    Args:
        fetcher: An async function that takes an optional cursor and returns a Page.

    Yields:
        Individual items from each page.
    """
    cursor: str | None = None
    while True:
        page = await fetcher(cursor)
        for item in page.data:
            yield item
        if not page.has_more:
            break
        cursor = page.next_cursor
        if cursor is None:
            break
