"""AuthPIAdmin — entry-point client for the AuthPI Admin SDK."""

from __future__ import annotations

from functools import cached_property
from typing import TYPE_CHECKING, Any, Awaitable, Callable

import httpx

from authpi_admin.errors import ConfigurationError
from authpi_admin.http_client import HttpClient
from authpi_admin.generated.resources.accounts import AccountsResource
from authpi_admin.generated.resources.api_keys import ApiKeysResource
from authpi_admin.generated.resources.domains import DomainsResource
from authpi_admin.generated.resources.events import EventsResource
from authpi_admin.generated.resources.issuers import IssuersResource
from authpi_admin.generated.resources.notes import NotesResource
from authpi_admin.generated.resources.tokens import TokensResource
from authpi_admin.generated.resources.webhooks import WebhooksResource
from authpi_admin.generated.scopes.issuer_scope import IssuerScope
from authpi_admin.generated.scopes.webhook_scope import WebhookScope

if TYPE_CHECKING:
    from types import TracebackType


class AuthPIAdmin:
    """Entry-point client for the AuthPI Core API.

    Usage with API key:
        async with AuthPIAdmin(api_key="key_xxx") as admin:
            users = await admin.issuer("iss_xxx").users.list()

    Usage with bearer token:
        async with AuthPIAdmin(
            access_token="tok_xxx",
            account_id="acc_xxx",
        ) as admin:
            users = await admin.issuer("iss_xxx").users.list()
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        access_token: str | None = None,
        on_token_expired: Callable[[], Awaitable[dict[str, str]]] | None = None,
        account_id: str | None = None,
        base_url: str = "https://api.authpi.dev",
        http_client: httpx.AsyncClient | None = None,
        timeout: float = 30.0,
        default_headers: dict[str, str] | None = None,
        retries: bool | dict[str, Any] | None = None,
    ) -> None:
        if not api_key and not access_token:
            raise ConfigurationError("Either api_key or access_token is required")
        if api_key and access_token:
            raise ConfigurationError("Provide either api_key or access_token, not both")
        if access_token and not account_id:
            raise ConfigurationError("account_id is required when using access_token")

        resolved_account_id = account_id or "me"
        self._http = HttpClient(
            base_url=base_url,
            api_key=api_key,
            access_token=access_token,
            on_token_expired=on_token_expired,
            http_client=http_client,
            timeout=timeout,
            default_headers=default_headers,
            retries=retries,
        )
        self._base_path = f"/v1/accounts/{resolved_account_id}"

    @property
    def http(self) -> HttpClient:
        """The underlying HTTP client (for advanced use)."""
        return self._http

    # --- Account-level resource accessors ---

    @cached_property
    def accounts(self) -> AccountsResource:
        """Operations on the account itself."""
        return AccountsResource(self._http, "/v1/accounts")

    @cached_property
    def api_keys(self) -> ApiKeysResource:
        """Manage account-level API keys."""
        return ApiKeysResource(self._http, f"{self._base_path}/api-keys")

    @cached_property
    def domains(self) -> DomainsResource:
        """Manage account-level domains."""
        return DomainsResource(self._http, f"{self._base_path}/domains")

    @cached_property
    def events(self) -> EventsResource:
        """Query events."""
        return EventsResource(self._http, f"{self._base_path}/events")

    @cached_property
    def issuers(self) -> IssuersResource:
        """Manage issuers."""
        return IssuersResource(self._http, f"{self._base_path}/issuers")

    @cached_property
    def notes(self) -> NotesResource:
        """Manage notes."""
        return NotesResource(self._http, f"{self._base_path}/notes")

    @cached_property
    def tokens(self) -> TokensResource:
        """Manage account-level tokens."""
        return TokensResource(self._http, f"{self._base_path}/tokens")

    @cached_property
    def webhooks(self) -> WebhooksResource:
        """Manage webhooks."""
        return WebhooksResource(self._http, f"{self._base_path}/webhooks")

    # --- Scope accessors ---

    def issuer(self, issuer_id: str) -> IssuerScope:
        """Scope operations to a specific issuer."""
        return IssuerScope(
            client=self._http,
            base_path=f"{self._base_path}/issuers",
            issuer_id=issuer_id,
        )

    def webhook(self, webhook_id: str) -> WebhookScope:
        """Scope operations to a specific webhook."""
        return WebhookScope(
            client=self._http,
            base_path=f"{self._base_path}/webhooks",
            webhook_id=webhook_id,
        )

    # --- Lifecycle ---

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.close()

    async def __aenter__(self) -> AuthPIAdmin:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()
