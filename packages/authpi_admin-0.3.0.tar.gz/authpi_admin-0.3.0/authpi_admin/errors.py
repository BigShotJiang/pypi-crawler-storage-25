"""Error hierarchy for the AuthPI Admin SDK."""

from __future__ import annotations

import contextlib
from typing import Any

# Retryable status codes (when not overridden by response body)
_RETRYABLE_STATUSES = {408, 429, 502, 503, 504}


class ConfigurationError(Exception):
    """Raised when the client is configured incorrectly."""


class ApiError(Exception):
    """Base error for all API errors."""

    def __init__(
        self,
        *,
        error: str,
        error_description: str,
        status_code: int,
        retryable: bool = False,
        reference: str | None = None,
        raw_body: str | None = None,
    ) -> None:
        super().__init__(error_description)
        self.error = error
        self.error_description = error_description
        self.status_code = status_code
        self.retryable = retryable
        self.reference = reference
        self.raw_body = raw_body


class ValidationError(ApiError):
    """Raised for 400 and 422 responses with field-level validation errors."""

    def __init__(self, *, fields: list[dict[str, Any]] | None = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.fields = fields or []


class AuthenticationError(ApiError):
    """Raised for 401 responses."""


class ForbiddenError(ApiError):
    """Raised for 403 responses."""


class NotFoundError(ApiError):
    """Raised for 404 responses."""


class ConflictError(ApiError):
    """Raised for 409 responses."""


class PreconditionFailedError(ApiError):
    """Raised for 412 responses (ETag mismatch)."""

    def __init__(self, *, current_etag: str | None = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.current_etag = current_etag


class RateLimitError(ApiError):
    """Raised for 429 responses."""

    def __init__(self, *, retry_after: int | None = None, **kwargs: Any) -> None:
        kwargs.setdefault("retryable", True)
        super().__init__(**kwargs)
        self.retry_after = retry_after


class ServerError(ApiError):
    """Base class for 5xx server errors."""


class InternalServerError(ServerError):
    """Raised for 500 responses."""


class BadGatewayError(ServerError):
    """Raised for 502 responses."""

    def __init__(self, **kwargs: Any) -> None:
        kwargs.setdefault("retryable", True)
        super().__init__(**kwargs)


class ServiceUnavailableError(ServerError):
    """Raised for 503 responses."""

    def __init__(self, **kwargs: Any) -> None:
        kwargs.setdefault("retryable", True)
        super().__init__(**kwargs)


class GatewayTimeoutError(ServerError):
    """Raised for 504 responses."""

    def __init__(self, **kwargs: Any) -> None:
        kwargs.setdefault("retryable", True)
        super().__init__(**kwargs)


class UnexpectedError(ApiError):
    """Raised for any status code not explicitly mapped."""


class ClosedClientError(ApiError):
    """Raised when attempting to use a closed client."""

    def __init__(self) -> None:
        super().__init__(
            error="closed_client",
            error_description="Cannot make requests after the client has been closed",
            status_code=0,
            retryable=False,
        )


# HTTP status text fallbacks
_STATUS_TEXT: dict[int, str] = {
    400: "Bad Request",
    401: "Unauthorized",
    403: "Forbidden",
    404: "Not Found",
    408: "Request Timeout",
    409: "Conflict",
    412: "Precondition Failed",
    422: "Unprocessable Entity",
    429: "Too Many Requests",
    500: "Internal Server Error",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
}

# Status code -> error class mapping
_STATUS_MAP: dict[int, type[ApiError]] = {
    400: ValidationError,
    401: AuthenticationError,
    403: ForbiddenError,
    404: NotFoundError,
    409: ConflictError,
    412: PreconditionFailedError,
    422: ValidationError,
    429: RateLimitError,
    500: InternalServerError,
    502: BadGatewayError,
    503: ServiceUnavailableError,
    504: GatewayTimeoutError,
}


def error_from_response(
    *,
    status_code: int,
    body: dict[str, Any] | None,
    headers: dict[str, str],
    raw_body: str | None = None,
) -> ApiError:
    """Create the appropriate error from an HTTP response.

    Args:
        status_code: HTTP status code.
        body: Parsed JSON body, or None if parsing failed.
        headers: Response headers (lowercase keys).
        raw_body: Raw body string for non-JSON responses.
    """
    body = body or {}
    error = body.get("error", "unknown")
    error_description = body.get("error_description", _STATUS_TEXT.get(status_code, "Unknown Error"))
    reference = body.get("reference")
    retryable = body.get("retryable", status_code in _RETRYABLE_STATUSES)

    base_kwargs: dict[str, Any] = {
        "error": error,
        "error_description": error_description,
        "status_code": status_code,
        "retryable": retryable,
        "reference": reference,
        "raw_body": raw_body,
    }

    error_class = _STATUS_MAP.get(status_code)

    if error_class is None:
        # 408 gets base ApiError with retryable=True
        if status_code == 408:
            return ApiError(**base_kwargs)
        # Unmapped 5xx codes get the base ServerError
        if 500 <= status_code < 600:
            return ServerError(**base_kwargs)
        return UnexpectedError(**base_kwargs)

    # Build extra kwargs for specific error classes
    if error_class is ValidationError:
        return ValidationError(fields=body.get("fields"), **base_kwargs)

    if error_class is PreconditionFailedError:
        return PreconditionFailedError(current_etag=body.get("current_etag"), **base_kwargs)

    if error_class is RateLimitError:
        retry_after = body.get("retry_after")
        if retry_after is None:
            header_val = headers.get("retry-after")
            if header_val is not None:
                with contextlib.suppress(ValueError):
                    retry_after = int(header_val)
        return RateLimitError(retry_after=retry_after, **base_kwargs)

    return error_class(**base_kwargs)
