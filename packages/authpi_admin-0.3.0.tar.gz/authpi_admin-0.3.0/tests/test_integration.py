"""Integration smoke tests — verify client -> scope -> resource wiring works end to end."""

from __future__ import annotations

from authpi_admin.client import AuthPIAdmin
from authpi_admin.generated.resources.accounts import AccountsResource
from authpi_admin.generated.resources.api_keys import ApiKeysResource
from authpi_admin.generated.resources.agents import AgentsResource
from authpi_admin.generated.resources.auth_methods import AuthMethodsResource
from authpi_admin.generated.resources.clients import ClientsResource
from authpi_admin.generated.resources.deliveries import DeliveriesResource
from authpi_admin.generated.resources.domains import DomainsResource
from authpi_admin.generated.resources.events import EventsResource
from authpi_admin.generated.resources.groups import GroupsResource
from authpi_admin.generated.resources.invitations import InvitationsResource
from authpi_admin.generated.resources.issuers import IssuersResource
from authpi_admin.generated.resources.members import MembersResource
from authpi_admin.generated.resources.notes import NotesResource
from authpi_admin.generated.resources.organizations import OrganizationsResource
from authpi_admin.generated.resources.sessions import SessionsResource
from authpi_admin.generated.resources.tokens import TokensResource
from authpi_admin.generated.resources.trusted_devices import TrustedDevicesResource
from authpi_admin.generated.resources.users import UsersResource
from authpi_admin.generated.resources.verifiers import VerifiersResource
from authpi_admin.generated.resources.webhooks import WebhooksResource
from authpi_admin.generated.scopes.agent_scope import AgentScope
from authpi_admin.generated.scopes.issuer_scope import IssuerScope
from authpi_admin.generated.scopes.user_scope import UserScope
from authpi_admin.generated.scopes.webhook_scope import WebhookScope


class TestAccountLevelResources:
    """Verify all account-level resource accessors exist and return the right type."""

    def setup_method(self):
        self.admin = AuthPIAdmin(api_key="test_key")

    def test_accounts(self):
        assert isinstance(self.admin.accounts, AccountsResource)

    def test_api_keys(self):
        assert isinstance(self.admin.api_keys, ApiKeysResource)

    def test_domains(self):
        assert isinstance(self.admin.domains, DomainsResource)

    def test_events(self):
        assert isinstance(self.admin.events, EventsResource)

    def test_issuers(self):
        assert isinstance(self.admin.issuers, IssuersResource)

    def test_notes(self):
        assert isinstance(self.admin.notes, NotesResource)

    def test_tokens(self):
        assert isinstance(self.admin.tokens, TokensResource)

    def test_webhooks(self):
        assert isinstance(self.admin.webhooks, WebhooksResource)


class TestIssuerScope:
    """Verify IssuerScope wiring: resources + child scopes."""

    def setup_method(self):
        self.admin = AuthPIAdmin(api_key="test_key")
        self.scope = self.admin.issuer("iss_test")

    def test_scope_type(self):
        assert isinstance(self.scope, IssuerScope)

    def test_users(self):
        assert isinstance(self.scope.users, UsersResource)

    def test_clients(self):
        assert isinstance(self.scope.clients, ClientsResource)

    def test_agents(self):
        assert isinstance(self.scope.agents, AgentsResource)

    def test_organizations(self):
        assert isinstance(self.scope.organizations, OrganizationsResource)

    def test_auth_methods(self):
        assert isinstance(self.scope.auth_methods, AuthMethodsResource)

    def test_groups(self):
        assert isinstance(self.scope.groups, GroupsResource)

    def test_invitations(self):
        assert isinstance(self.scope.invitations, InvitationsResource)

    def test_members(self):
        assert isinstance(self.scope.members, MembersResource)

    def test_domains(self):
        assert isinstance(self.scope.domains, DomainsResource)

    def test_sessions(self):
        assert isinstance(self.scope.sessions, SessionsResource)

    def test_user_child_scope(self):
        """IssuerScope.user() returns a UserScope."""
        user = self.scope.user("usr_123")
        assert isinstance(user, UserScope)

    def test_agent_child_scope(self):
        """IssuerScope.agent() returns an AgentScope."""
        agent = self.scope.agent("ag_123")
        assert isinstance(agent, AgentScope)


class TestUserScope:
    """Verify UserScope wiring."""

    def setup_method(self):
        admin = AuthPIAdmin(api_key="test_key")
        self.scope = admin.issuer("iss_test").user("usr_test")

    def test_scope_type(self):
        assert isinstance(self.scope, UserScope)

    def test_sessions(self):
        assert isinstance(self.scope.sessions, SessionsResource)

    def test_tokens(self):
        assert isinstance(self.scope.tokens, TokensResource)

    def test_trusted_devices(self):
        assert isinstance(self.scope.trusted_devices, TrustedDevicesResource)

    def test_verifiers(self):
        assert isinstance(self.scope.verifiers, VerifiersResource)


class TestAgentScope:
    """Verify AgentScope wiring."""

    def setup_method(self):
        admin = AuthPIAdmin(api_key="test_key")
        self.scope = admin.issuer("iss_test").agent("ag_test")

    def test_scope_type(self):
        assert isinstance(self.scope, AgentScope)

    def test_verifiers(self):
        assert isinstance(self.scope.verifiers, VerifiersResource)


class TestWebhookScope:
    """Verify WebhookScope wiring."""

    def setup_method(self):
        admin = AuthPIAdmin(api_key="test_key")
        self.scope = admin.webhook("wh_test")

    def test_scope_type(self):
        assert isinstance(self.scope, WebhookScope)

    def test_deliveries(self):
        assert isinstance(self.scope.deliveries, DeliveriesResource)


class TestBasePaths:
    """Verify that resource base paths are constructed correctly."""

    def setup_method(self):
        self.admin = AuthPIAdmin(api_key="test_key", account_id="acc_123")

    def test_account_base_path(self):
        assert self.admin._base_path == "/v1/accounts/acc_123"

    def test_issuers_base_path(self):
        assert self.admin.issuers._base_path == "/v1/accounts/acc_123/issuers"

    def test_events_base_path(self):
        assert self.admin.events._base_path == "/v1/accounts/acc_123/events"

    def test_issuer_scope_path(self):
        scope = self.admin.issuer("iss_1")
        assert scope._path == "/v1/accounts/acc_123/issuers/iss_1"

    def test_issuer_users_path(self):
        scope = self.admin.issuer("iss_1")
        assert scope.users._base_path == "/v1/accounts/acc_123/issuers/iss_1/users"

    def test_user_scope_path(self):
        scope = self.admin.issuer("iss_1").user("usr_2")
        assert scope._path == "/v1/accounts/acc_123/issuers/iss_1/users/usr_2"

    def test_user_sessions_path(self):
        scope = self.admin.issuer("iss_1").user("usr_2")
        assert scope.sessions._base_path == "/v1/accounts/acc_123/issuers/iss_1/users/usr_2/sessions"

    def test_webhook_scope_path(self):
        scope = self.admin.webhook("wh_3")
        assert scope._path == "/v1/accounts/acc_123/webhooks/wh_3"

    def test_webhook_deliveries_path(self):
        scope = self.admin.webhook("wh_3")
        assert scope.deliveries._base_path == "/v1/accounts/acc_123/webhooks/wh_3/deliveries"


class TestCachedPropertyBehavior:
    """Verify that resource accessors use cached_property correctly."""

    def test_account_resource_is_cached(self):
        admin = AuthPIAdmin(api_key="test_key")
        assert admin.issuers is admin.issuers
        assert admin.events is admin.events
        assert admin.webhooks is admin.webhooks

    def test_scope_resource_is_cached(self):
        admin = AuthPIAdmin(api_key="test_key")
        scope = admin.issuer("iss_1")
        assert scope.users is scope.users
        assert scope.clients is scope.clients

    def test_scope_accessor_not_cached(self):
        """Scopes are not cached — each call returns a fresh instance."""
        admin = AuthPIAdmin(api_key="test_key")
        s1 = admin.issuer("iss_1")
        s2 = admin.issuer("iss_1")
        assert s1 is not s2


class TestResourceMethodsExist:
    """Verify that generated resource classes have the expected CRUD methods."""

    def test_users_has_list(self):
        assert callable(getattr(UsersResource, "list", None))

    def test_users_has_create(self):
        assert callable(getattr(UsersResource, "create", None))

    def test_users_has_get(self):
        assert callable(getattr(UsersResource, "get", None))

    def test_users_has_update(self):
        assert callable(getattr(UsersResource, "update", None))

    def test_users_has_delete(self):
        assert callable(getattr(UsersResource, "delete", None))

    def test_users_has_list_all(self):
        assert callable(getattr(UsersResource, "list_all", None))

    def test_webhooks_has_list(self):
        assert callable(getattr(WebhooksResource, "list", None))

    def test_webhooks_has_create(self):
        assert callable(getattr(WebhooksResource, "create", None))

    def test_events_has_list(self):
        assert callable(getattr(EventsResource, "list", None))

    def test_events_has_get(self):
        assert callable(getattr(EventsResource, "get", None))


class TestScopeSelfOperations:
    """Verify that scope classes have self-operations (get/update/delete)."""

    def test_issuer_scope_has_get(self):
        assert callable(getattr(IssuerScope, "get", None))

    def test_issuer_scope_has_update(self):
        assert callable(getattr(IssuerScope, "update", None))

    def test_issuer_scope_has_delete(self):
        assert callable(getattr(IssuerScope, "delete", None))

    def test_user_scope_has_get(self):
        assert callable(getattr(UserScope, "get", None))

    def test_user_scope_has_update(self):
        assert callable(getattr(UserScope, "update", None))

    def test_user_scope_has_delete(self):
        assert callable(getattr(UserScope, "delete", None))
