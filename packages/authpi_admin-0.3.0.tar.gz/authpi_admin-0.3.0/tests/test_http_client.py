"""Tests for the internal HTTP client."""

from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

from authpi_admin.errors import (
    AuthenticationError,
    ClosedClientError,
    NotFoundError,
    ValidationError,
)
from authpi_admin.http_client import ApiResponse, HttpClient


@pytest.fixture
def client() -> HttpClient:
    return HttpClient(base_url="https://api.test.com", api_key="test_key_123")


async def test_request_sends_auth_header(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1"})

    await client.request("GET", "/v1/test")

    request = httpx_mock.get_request()
    assert request is not None
    assert request.headers["authorization"] == "Bearer test_key_123"


async def test_request_returns_api_response(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1", "name": "Test"})

    result = await client.request("GET", "/v1/test")
    assert isinstance(result, ApiResponse)
    assert result.data == {"id": "1", "name": "Test"}


async def test_request_extracts_etag(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1"}, headers={"etag": '"abc123"'})

    result = await client.request("GET", "/v1/test")
    assert result.etag == '"abc123"'


async def test_request_no_etag(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1"})

    result = await client.request("GET", "/v1/test")
    assert result.etag is None


async def test_request_sends_json_body(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1"})

    await client.request("POST", "/v1/test", body={"name": "Alice"})

    request = httpx_mock.get_request()
    assert request is not None
    assert request.content == b'{"name": "Alice"}'


async def test_request_sends_query_params(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"data": []})

    await client.request("GET", "/v1/test", query={"limit": 50, "cursor": "abc"})

    request = httpx_mock.get_request()
    assert request is not None
    assert "limit=50" in str(request.url)
    assert "cursor=abc" in str(request.url)


async def test_request_skips_none_query_params(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"data": []})

    await client.request("GET", "/v1/test", query={"limit": 50, "cursor": None})

    request = httpx_mock.get_request()
    assert request is not None
    assert "limit=50" in str(request.url)
    assert "cursor" not in str(request.url)


async def test_request_sends_extra_headers(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1"})

    await client.request("GET", "/v1/test", headers={"x-request-id": "req_123"})

    request = httpx_mock.get_request()
    assert request is not None
    assert request.headers["x-request-id"] == "req_123"


async def test_request_sends_if_match(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1"})

    await client.request("PATCH", "/v1/test", headers={"if-match": '"etag123"'})

    request = httpx_mock.get_request()
    assert request is not None
    assert request.headers["if-match"] == '"etag123"'


async def test_request_sends_idempotency_key(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1"})

    await client.request("POST", "/v1/test", headers={"idempotency-key": "key_123"})

    request = httpx_mock.get_request()
    assert request is not None
    assert request.headers["idempotency-key"] == "key_123"


async def test_request_raises_not_found(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(status_code=404, json={"error": "not_found", "error_description": "Not found"})

    with pytest.raises(NotFoundError) as exc_info:
        await client.request("GET", "/v1/test")
    assert exc_info.value.status_code == 404


async def test_request_raises_authentication_error(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(status_code=401, json={"error": "unauthorized"})

    with pytest.raises(AuthenticationError):
        await client.request("GET", "/v1/test")


async def test_request_raises_validation_error(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(
        status_code=400,
        json={"error": "validation_error", "error_description": "Bad", "fields": [{"field": "name"}]},
    )

    with pytest.raises(ValidationError) as exc_info:
        await client.request("POST", "/v1/test")
    assert exc_info.value.fields == [{"field": "name"}]


async def test_request_handles_non_json_error(httpx_mock: HTTPXMock):
    # Use retries=False since 502 is retryable by default
    no_retry_client = HttpClient(base_url="https://api.test.com", api_key="test_key_123", retries=False)
    httpx_mock.add_response(status_code=502, text="<html>Bad Gateway</html>")

    from authpi_admin.errors import BadGatewayError

    with pytest.raises(BadGatewayError) as exc_info:
        await no_retry_client.request("GET", "/v1/test")
    assert exc_info.value.raw_body == "<html>Bad Gateway</html>"


# ── Bearer token auth ──────────────────────────────────────


async def test_bearer_token_auth(httpx_mock: HTTPXMock):
    httpx_mock.add_response(json={"id": "1"})
    bearer_client = HttpClient(base_url="https://api.test.com", access_token="tok_abc123")
    await bearer_client.request("GET", "/v1/test")
    req = httpx_mock.get_request()
    assert req is not None
    assert req.headers["authorization"] == "Bearer tok_abc123"


def test_rejects_no_credential():
    from authpi_admin.errors import ConfigurationError

    with pytest.raises(ConfigurationError, match="Either api_key or access_token"):
        HttpClient(base_url="https://api.test.com")


def test_rejects_both_credentials():
    from authpi_admin.errors import ConfigurationError

    with pytest.raises(ConfigurationError, match="either api_key or access_token, not both"):
        HttpClient(base_url="https://api.test.com", api_key="k", access_token="t")


# ── Retries ────────────────────────────────────────────────


async def test_retries_get_on_503(httpx_mock: HTTPXMock):
    httpx_mock.add_response(status_code=503)
    httpx_mock.add_response(json={"data": "ok"})
    retry_client = HttpClient(base_url="https://api.test.com", api_key="k", retries={"limit": 2, "delay": 0.01})
    result = await retry_client.request("GET", "/v1/test")
    assert result.data == {"data": "ok"}
    assert len(httpx_mock.get_requests()) == 2


async def test_no_retry_on_post(httpx_mock: HTTPXMock):
    from authpi_admin.errors import ServiceUnavailableError

    httpx_mock.add_response(status_code=503)
    retry_client = HttpClient(base_url="https://api.test.com", api_key="k", retries={"limit": 2, "delay": 0.01})
    with pytest.raises(ServiceUnavailableError):
        await retry_client.request("POST", "/v1/test", body={"a": 1})
    assert len(httpx_mock.get_requests()) == 1


async def test_no_retry_on_400(httpx_mock: HTTPXMock):
    from authpi_admin.errors import ValidationError

    httpx_mock.add_response(status_code=400, json={"error": "bad", "error_description": "bad input"})
    retry_client = HttpClient(base_url="https://api.test.com", api_key="k", retries={"limit": 2, "delay": 0.01})
    with pytest.raises(ValidationError):
        await retry_client.request("GET", "/v1/test")
    assert len(httpx_mock.get_requests()) == 1


async def test_retries_disabled(httpx_mock: HTTPXMock):
    from authpi_admin.errors import ServiceUnavailableError

    httpx_mock.add_response(status_code=503)
    no_retry = HttpClient(base_url="https://api.test.com", api_key="k", retries=False)
    with pytest.raises(ServiceUnavailableError):
        await no_retry.request("GET", "/v1/test")
    assert len(httpx_mock.get_requests()) == 1


async def test_retries_exhausted(httpx_mock: HTTPXMock):
    from authpi_admin.errors import ServiceUnavailableError

    for _ in range(3):
        httpx_mock.add_response(status_code=503)
    retry_client = HttpClient(base_url="https://api.test.com", api_key="k", retries={"limit": 2, "delay": 0.01})
    with pytest.raises(ServiceUnavailableError):
        await retry_client.request("GET", "/v1/test")
    assert len(httpx_mock.get_requests()) == 3  # 1 initial + 2 retries


# ── Token refresh ──────────────────────────────────────────


async def test_on_token_expired_refreshes_on_401(httpx_mock: HTTPXMock):
    """On 401, calls on_token_expired and retries with new token."""
    call_count = 0

    def match_old_token(request: httpx.Request) -> bool:
        return request.headers["authorization"] == "Bearer tok_old"

    def match_new_token(request: httpx.Request) -> bool:
        return request.headers["authorization"] == "Bearer tok_new"

    httpx_mock.add_response(
        status_code=401,
        json={"error": "unauthorized", "error_description": "expired"},
        match_headers={"authorization": "Bearer tok_old"},
    )
    httpx_mock.add_response(
        status_code=200,
        json={"data": "ok"},
        match_headers={"authorization": "Bearer tok_new"},
    )

    async def refresh():
        nonlocal call_count
        call_count += 1
        return {"access_token": "tok_new"}

    client = HttpClient(base_url="https://api.test.com", access_token="tok_old", on_token_expired=refresh)
    result = await client.request("GET", "/v1/test")
    assert result.data == {"data": "ok"}
    assert call_count == 1


async def test_401_without_callback_raises(httpx_mock: HTTPXMock):
    from authpi_admin.errors import AuthenticationError

    httpx_mock.add_response(status_code=401, json={"error": "unauthorized", "error_description": "bad"})
    client = HttpClient(base_url="https://api.test.com", access_token="tok_old")
    with pytest.raises(AuthenticationError):
        await client.request("GET", "/v1/test")


# ── Default headers ────────────────────────────────────────


async def test_default_headers_sent(httpx_mock: HTTPXMock):
    httpx_mock.add_response(json={"id": "1"})
    client = HttpClient(
        base_url="https://api.test.com",
        api_key="k",
        default_headers={"X-Custom": "val", "Authpi-Dashboard": "dtok"},
    )
    await client.request("GET", "/v1/test")
    req = httpx_mock.get_request()
    assert req is not None
    assert req.headers["x-custom"] == "val"
    assert req.headers["authpi-dashboard"] == "dtok"


async def test_default_headers_cannot_override_auth(httpx_mock: HTTPXMock):
    httpx_mock.add_response(json={"id": "1"})
    client = HttpClient(
        base_url="https://api.test.com",
        api_key="real_key",
        default_headers={"authorization": "Bearer evil"},
    )
    await client.request("GET", "/v1/test")
    req = httpx_mock.get_request()
    assert req is not None
    assert req.headers["authorization"] == "Bearer real_key"


async def test_close_owned_client(client: HttpClient):
    assert client._owns_client is True
    await client.close()
    assert client._closed is True


async def test_close_raises_on_subsequent_request(httpx_mock: HTTPXMock, client: HttpClient):
    await client.close()
    with pytest.raises(ClosedClientError):
        await client.request("GET", "/v1/test")


async def test_injected_client_close_is_noop():
    import httpx

    external = httpx.AsyncClient()
    client = HttpClient(base_url="https://api.test.com", api_key="key", http_client=external)
    assert client._owns_client is False
    await client.close()
    # Client is not closed — still usable
    assert not external.is_closed
    await external.aclose()


async def test_request_with_timeout_override(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1"})

    await client.request("GET", "/v1/test", timeout=5.0)

    request = httpx_mock.get_request()
    assert request is not None  # Request was made successfully


async def test_request_returns_empty_for_204(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(status_code=204)

    result = await client.request("DELETE", "/v1/test")
    assert result.data is None


async def test_externally_closed_injected_client_raises_closed_error():
    import httpx

    external = httpx.AsyncClient()
    client = HttpClient(base_url="https://api.test.com", api_key="key", http_client=external)
    await external.aclose()  # Close externally
    with pytest.raises(ClosedClientError):
        await client.request("GET", "/v1/test")


# --- validate_path_segment ---

from authpi_admin.http_client import validate_path_segment


def test_validate_path_segment_allows_valid_ids():
    assert validate_path_segment("usr_123") == "usr_123"
    assert validate_path_segment("abc-def") == "abc-def"


def test_validate_path_segment_rejects_path_separators():
    with pytest.raises(ValueError, match="Invalid id"):
        validate_path_segment("../api-keys")
    with pytest.raises(ValueError, match="Invalid id"):
        validate_path_segment("foo/bar")
    with pytest.raises(ValueError, match="Invalid id"):
        validate_path_segment("foo\\bar")


def test_validate_path_segment_rejects_query_and_fragment():
    with pytest.raises(ValueError, match="Invalid id"):
        validate_path_segment("foo?bar=1")
    with pytest.raises(ValueError, match="Invalid id"):
        validate_path_segment("foo#section")


def test_validate_path_segment_rejects_empty_and_dots():
    with pytest.raises(ValueError, match="Invalid id"):
        validate_path_segment("")
    with pytest.raises(ValueError, match="Invalid id"):
        validate_path_segment(".")
    with pytest.raises(ValueError, match="Invalid id"):
        validate_path_segment("..")


def test_validate_path_segment_custom_name():
    with pytest.raises(ValueError, match="Invalid user_id"):
        validate_path_segment("a/b", "user_id")


# --- Header injection protection ---


async def test_protected_headers_cannot_be_overridden(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1"})

    await client.request("GET", "/v1/test", headers={
        "authorization": "Bearer attacker_key",
        "host": "evil.com",
        "x-custom": "allowed",
    })

    request = httpx_mock.get_request()
    assert request is not None
    assert request.headers["authorization"] == "Bearer test_key_123"
    assert request.headers.get("host") != "evil.com"
    assert request.headers["x-custom"] == "allowed"


# --- Strip _-prefixed keys from outbound body ---


async def test_strip_underscore_keys_from_body(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1"})

    await client.request("PATCH", "/v1/test", body={
        "name": "Alice",
        "_etag": '"old"',
        "_internal": True,
    })

    request = httpx_mock.get_request()
    import json
    sent = json.loads(request.content)
    assert sent == {"name": "Alice"}
    assert "_etag" not in sent


async def test_strip_underscore_keys_deep(httpx_mock: HTTPXMock, client: HttpClient):
    httpx_mock.add_response(json={"id": "1"})

    await client.request("PATCH", "/v1/test", body={
        "name": "Alice",
        "_etag": '"top"',
        "address": {"city": "NYC", "_etag": '"nested"'},
        "items": [{"tag": "a", "_etag": '"arr"'}],
    })

    request = httpx_mock.get_request()
    import json
    sent = json.loads(request.content)
    assert sent == {
        "name": "Alice",
        "address": {"city": "NYC"},
        "items": [{"tag": "a"}],
    }


# --- API key not exposed ---


def test_api_key_not_in_repr():
    client = HttpClient(base_url="https://api.test.com", api_key="secret_key")
    assert "secret_key" not in repr(client)
    assert "api.test.com" in repr(client)
