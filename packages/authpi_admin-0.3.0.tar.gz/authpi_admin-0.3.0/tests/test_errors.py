"""Tests for the Admin SDK error hierarchy."""

from __future__ import annotations

from authpi_admin.errors import (
    ApiError,
    AuthenticationError,
    BadGatewayError,
    ClosedClientError,
    InternalServerError,
    NotFoundError,
    PreconditionFailedError,
    RateLimitError,
    ServerError,
    ServiceUnavailableError,
    UnexpectedError,
    ValidationError,
    error_from_response,
)


def test_api_error_base():
    err = ApiError(
        error="test_error",
        error_description="Something went wrong",
        status_code=418,
        retryable=False,
    )
    assert err.error == "test_error"
    assert err.error_description == "Something went wrong"
    assert err.status_code == 418
    assert err.retryable is False
    assert err.reference is None
    assert err.raw_body is None
    assert str(err) == "Something went wrong"


def test_validation_error_fields():
    err = ValidationError(
        error="validation_error",
        error_description="Invalid input",
        status_code=400,
        fields=[{"field": "username", "message": "required"}],
    )
    assert err.fields == [{"field": "username", "message": "required"}]
    assert isinstance(err, ApiError)


def test_authentication_error():
    err = AuthenticationError(
        error="unauthorized",
        error_description="Invalid API key",
        status_code=401,
    )
    assert isinstance(err, ApiError)
    assert err.retryable is False


def test_precondition_failed_error():
    err = PreconditionFailedError(
        error="precondition_failed",
        error_description="ETag mismatch",
        status_code=412,
        current_etag='"abc123"',
    )
    assert err.current_etag == '"abc123"'
    assert isinstance(err, ApiError)


def test_rate_limit_error():
    err = RateLimitError(
        error="rate_limited",
        error_description="Too many requests",
        status_code=429,
        retry_after=30,
    )
    assert err.retry_after == 30
    assert err.retryable is True


def test_server_error_hierarchy():
    err = InternalServerError(
        error="internal",
        error_description="Server error",
        status_code=500,
    )
    assert isinstance(err, ServerError)
    assert isinstance(err, ApiError)


def test_bad_gateway_retryable():
    err = BadGatewayError(
        error="bad_gateway",
        error_description="Bad Gateway",
        status_code=502,
    )
    assert err.retryable is True


def test_closed_client_error():
    err = ClosedClientError()
    assert isinstance(err, ApiError)
    assert err.retryable is False
    assert err.status_code == 0


def test_unexpected_error():
    err = UnexpectedError(
        error="unknown",
        error_description="Something unexpected",
        status_code=499,
        raw_body="raw response",
    )
    assert isinstance(err, ApiError)
    assert err.raw_body == "raw response"


# --- error_from_response tests ---


def test_error_from_response_400():
    err = error_from_response(
        status_code=400,
        body={"error": "validation_error", "error_description": "Bad input", "fields": [{"field": "name"}]},
        headers={},
    )
    assert isinstance(err, ValidationError)
    assert err.fields == [{"field": "name"}]


def test_error_from_response_401():
    err = error_from_response(status_code=401, body={"error": "unauthorized"}, headers={})
    assert isinstance(err, AuthenticationError)


def test_error_from_response_404():
    err = error_from_response(status_code=404, body={"error": "not_found"}, headers={})
    assert isinstance(err, NotFoundError)


def test_error_from_response_429_with_retry_after_header():
    err = error_from_response(
        status_code=429,
        body={"error": "rate_limited"},
        headers={"retry-after": "60"},
    )
    assert isinstance(err, RateLimitError)
    assert err.retry_after == 60


def test_error_from_response_429_with_body_retry_after():
    err = error_from_response(
        status_code=429,
        body={"error": "rate_limited", "retry_after": 30},
        headers={},
    )
    assert isinstance(err, RateLimitError)
    assert err.retry_after == 30


def test_error_from_response_500():
    err = error_from_response(status_code=500, body={"error": "internal"}, headers={})
    assert isinstance(err, InternalServerError)


def test_error_from_response_502():
    err = error_from_response(status_code=502, body={}, headers={})
    assert isinstance(err, BadGatewayError)
    assert err.retryable is True


def test_error_from_response_non_json_body():
    err = error_from_response(status_code=503, body=None, headers={}, raw_body="<html>error</html>")
    assert isinstance(err, ServiceUnavailableError)
    assert err.error == "unknown"
    assert err.raw_body == "<html>error</html>"


def test_error_from_response_unknown_status():
    err = error_from_response(status_code=418, body={"error": "teapot"}, headers={})
    assert isinstance(err, UnexpectedError)
    assert err.status_code == 418


def test_unmapped_5xx_returns_server_error():
    """Unmapped 5xx codes should return ServerError, not UnexpectedError."""
    for status in [501, 505, 507, 511]:
        err = error_from_response(
            status_code=status,
            body={"error": "server_error", "error_description": "Something went wrong"},
            headers={},
        )
        assert isinstance(err, ServerError), f"Status {status} should be ServerError, got {type(err).__name__}"
