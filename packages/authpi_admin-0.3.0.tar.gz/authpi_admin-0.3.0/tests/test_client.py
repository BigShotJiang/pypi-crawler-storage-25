"""Tests for the AuthPIAdmin entry-point client."""

from __future__ import annotations

import pytest

from authpi_admin.client import AuthPIAdmin
from authpi_admin.errors import ClosedClientError, ConfigurationError
from authpi_admin.generated.scopes.issuer_scope import IssuerScope
from authpi_admin.generated.scopes.webhook_scope import WebhookScope


def test_client_constructor_requires_credential():
    with pytest.raises(ConfigurationError, match="Either api_key or access_token"):
        AuthPIAdmin()

def test_client_rejects_both_credentials():
    with pytest.raises(ConfigurationError, match="either api_key or access_token, not both"):
        AuthPIAdmin(api_key="key_123", access_token="tok_123")

def test_client_access_token_requires_account_id():
    with pytest.raises(ConfigurationError, match="account_id is required"):
        AuthPIAdmin(access_token="tok_123")

def test_client_access_token_with_account_id():
    client = AuthPIAdmin(access_token="tok_123", account_id="acc_abc")
    assert client._base_path == "/v1/accounts/acc_abc"

def test_client_exposes_http():
    client = AuthPIAdmin(api_key="test_key")
    assert client.http is client._http


def test_client_default_base_url():
    client = AuthPIAdmin(api_key="test_key")
    assert client._http._base_url == "https://api.authpi.dev"


def test_client_custom_base_url():
    client = AuthPIAdmin(api_key="test_key", base_url="https://custom.api.com")
    assert client._http._base_url == "https://custom.api.com"


def test_issuer_scope_returns_scope_object():
    client = AuthPIAdmin(api_key="test_key")
    scope = client.issuer("iss_123")
    assert isinstance(scope, IssuerScope)
    assert scope._issuer_id == "iss_123"


def test_issuer_scope_not_memoized():
    """Different calls return different scope instances (scopes are cheap)."""
    client = AuthPIAdmin(api_key="test_key")
    s1 = client.issuer("iss_123")
    s2 = client.issuer("iss_123")
    assert s1 is not s2  # Not memoized


def test_webhook_scope_returns_scope_object():
    client = AuthPIAdmin(api_key="test_key")
    scope = client.webhook("wh_456")
    assert isinstance(scope, WebhookScope)
    assert scope._webhook_id == "wh_456"


async def test_context_manager():
    async with AuthPIAdmin(api_key="test_key") as client:
        assert client._http._closed is False
    assert client._http._closed is True


async def test_close():
    client = AuthPIAdmin(api_key="test_key")
    await client.close()
    assert client._http._closed is True


async def test_closed_client_raises():
    client = AuthPIAdmin(api_key="test_key")
    await client.close()
    with pytest.raises(ClosedClientError):
        await client._http.request("GET", "/v1/test")


def test_injected_httpx_client():
    import httpx

    external = httpx.AsyncClient()
    client = AuthPIAdmin(api_key="test_key", http_client=external)
    assert client._http._owns_client is False
