"""Tests for pagination helpers."""

from __future__ import annotations

from authpi_admin.pagination import Page, auto_paginate


def test_page_creation():
    page = Page(data=[1, 2, 3], has_more=True, next_cursor="abc")
    assert page.data == [1, 2, 3]
    assert page.has_more is True
    assert page.next_cursor == "abc"


def test_page_no_more():
    page = Page(data=[1], has_more=False)
    assert page.next_cursor is None


def test_page_empty():
    page: Page[str] = Page(data=[], has_more=False)
    assert len(page.data) == 0


async def test_auto_paginate_single_page():
    """auto_paginate yields all items from a single page."""

    async def fetcher(cursor: str | None = None) -> Page[int]:
        return Page(data=[1, 2, 3], has_more=False)

    items = [item async for item in auto_paginate(fetcher)]
    assert items == [1, 2, 3]


async def test_auto_paginate_multiple_pages():
    """auto_paginate follows cursors across multiple pages."""
    pages = {
        None: Page(data=[1, 2], has_more=True, next_cursor="page2"),
        "page2": Page(data=[3, 4], has_more=True, next_cursor="page3"),
        "page3": Page(data=[5], has_more=False),
    }

    async def fetcher(cursor: str | None = None) -> Page[int]:
        return pages[cursor]

    items = [item async for item in auto_paginate(fetcher)]
    assert items == [1, 2, 3, 4, 5]


async def test_auto_paginate_empty_first_page():
    """auto_paginate handles empty first page."""

    async def fetcher(cursor: str | None = None) -> Page[int]:
        return Page(data=[], has_more=False)

    items = [item async for item in auto_paginate(fetcher)]
    assert items == []


async def test_auto_paginate_breaks_on_missing_cursor():
    """Prevent infinite loop when has_more=True but next_cursor is None."""
    call_count = 0

    async def fetcher(cursor):
        nonlocal call_count
        call_count += 1
        return Page(data=[f"item_{call_count}"], has_more=True, next_cursor=None)

    items = []
    async for item in auto_paginate(fetcher):
        items.append(item)

    assert items == ["item_1"]
    assert call_count == 1
