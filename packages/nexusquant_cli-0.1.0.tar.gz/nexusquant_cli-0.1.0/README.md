# nexusquant-cli

Command line tool for NexusQuant strategy providers.

It supports browser login through Cognito, stores tokens locally, refreshes tokens, and calls the Nexus strategy provider APIs. Provider commands require a Cognito user with `custom:userType=strategyProvider` or `custom:userType=admin`.

## Install

```bash
python3 -m pip install -e .
```

## Login

```bash
nexusquant auth
nexusquant auth --status
nexusquant auth --refresh
nexusquant auth --logout
```

Tokens are stored in the current OS user's config directory, for example `~/Library/Application Support/nexusquant-cli/credentials.json` on macOS. The file is written with `0600` permissions when supported.

## Strategy Commands

Create or update a strategy:

```bash
nexusquant strategy create \
  --strategy-id my_alpha_001 \
  --name "My Alpha" \
  --schema-file schema.json \
  --output-unit SHARE_COUNT
```

List strategies registered by the current provider. Admin users see all strategies:

```bash
nexusquant strategy list
```

List signal history for one strategy:

```bash
nexusquant strategy signal my_alpha_001 --history --limit 20
```

Send a single signal:

```bash
nexusquant strategy signal my_alpha_001 \
  --strategy-name "My Alpha" \
  --ticker AAPL \
  --direction bull \
  --price 150.25 \
  --level 0.8 \
  --quantity 100
```

Send a multi-route `signals` map:

```bash
nexusquant strategy signal my_alpha_001 \
  --strategy-name "My Alpha" \
  --signals-file signals.json
```

Get non-PII subscriber config for a strategy:

```bash
nexusquant strategy sub config my_alpha_001
```

## JSON Inputs

`--schema-file` must contain the `strategy_schema` object accepted by `nexus-service`, for example:

```json
{
  "type": "object",
  "properties": {
    "window": {
      "type": "integer",
      "default": 14,
      "title": "Window",
      "source": "user"
    }
  },
  "required": []
}
```

`--signals-file` must contain a JSON object whose keys are `default` or user ids:

```json
{
  "default": {
    "ticker": "AAPL",
    "time": "2026-04-26T19:30:00Z",
    "price": 150.25,
    "level": 0.8,
    "direction": "bull",
    "quantity": 100,
    "metadata": {}
  }
}
```

## Environment Overrides

Normal use does not require configuration. For staging or local development:

| Variable | Meaning |
| --- | --- |
| `NEXUSQUANT_API_ENDPOINT` | API endpoint host, default `https://api.nexusquant.co`; CLI calls `/api/...` under it |
| `NEXUSQUANT_API_BASE_URL` | Optional full API base override, e.g. `https://api.nexusquant.co/api` |
| `NEXUSQUANT_COGNITO_DOMAIN` | Cognito Hosted UI host, default `auth.lookatwallstreet.com` |
| `NEXUSQUANT_COGNITO_CLIENT_ID` | Cognito app client id |
| `NEXUSQUANT_REDIRECT_URI` | OAuth callback, default `http://127.0.0.1:8251/callback` |

There is also a hidden typo-compatible alias: `nexusquant startegy ...` maps to `nexusquant strategy ...`.
