from __future__ import annotations

import typer
from rich.console import Console

from nexusquant_cli import __version__
from nexusquant_cli.commands import register_all

console = Console()
app = typer.Typer(
    name="nexusquant",
    help=(
        "NexusQuant strategy provider CLI. Login once with Cognito, then create "
        "strategies, send strategy signals, list signal history, and fetch non-PII "
        "subscriber configs. Requires custom:userType=strategyProvider or admin for "
        "provider commands."
    ),
    no_args_is_help=True,
)

register_all(app)


@app.command("version", help="Print this CLI package version string.")
def version_cmd() -> None:
    """Print CLI version."""
    console.print(__version__)


if __name__ == "__main__":
    app()
