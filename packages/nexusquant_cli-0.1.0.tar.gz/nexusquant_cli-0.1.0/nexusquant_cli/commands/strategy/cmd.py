from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Any

import typer
from rich.console import Console

from nexusquant_cli import api_client
from nexusquant_cli.commands._util import (
    load_json_file,
    load_json_option,
    print_json_or_exit,
)

console = Console()

strategy_app = typer.Typer(
    help=(
        "Strategy provider commands. Security model: strategyProvider users can only "
        "create, list, signal, and inspect subscriber configs for strategies they own; "
        "admin users can operate across strategies."
    ),
    no_args_is_help=True,
)
sub_app = typer.Typer(
    help="Subscriber-related provider commands for one strategy. Returns non-PII config only.",
    no_args_is_help=True,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _strategy_name_arg(strategy_name: str | None, strategy_id: str) -> str:
    return strategy_name or strategy_id


@strategy_app.command(
    "create",
    help=(
        "Create or update an external strategy via POST /strategy-signal/register/. "
        "Requires custom:userType=strategyProvider or admin."
    ),
)
def create_strategy(
    strategy_id: Annotated[
        str,
        typer.Option(
            "--strategy-id",
            "-i",
            help="Stable strategy id used in future signal calls, e.g. my_alpha_001.",
        ),
    ],
    strategy_name: Annotated[
        str,
        typer.Option("--name", "-n", help="Human-readable strategy name shown in UI."),
    ],
    schema_file: Annotated[
        Path | None,
        typer.Option(
            "--schema-file",
            exists=True,
            dir_okay=False,
            readable=True,
            help=(
                "UTF-8 JSON file containing strategy_schema. Shape: JSON Schema object "
                "with type/properties/required as accepted by nexus-service."
            ),
        ),
    ] = None,
    schema_json: Annotated[
        str | None,
        typer.Option(
            "--schema-json",
            help="Inline JSON object for strategy_schema. Use this or --schema-file.",
        ),
    ] = None,
    output_unit: Annotated[
        str,
        typer.Option(
            "--output-unit",
            help=(
                "Signal output unit. One of CASH_AMOUNT, SHARE_COUNT, "
                "PERCENTAGE_BALANCE, PERCENTAGE_EQUITY."
            ),
        ),
    ] = "SHARE_COUNT",
    description: Annotated[
        str | None,
        typer.Option("--description", "-d", help="Optional strategy description."),
    ] = None,
    config_file: Annotated[
        Path | None,
        typer.Option(
            "--config-file",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Optional UTF-8 JSON file for provider metadata stored as Strategy.config.",
        ),
    ] = None,
    config_json: Annotated[
        str | None,
        typer.Option("--config-json", help="Inline JSON object for Strategy.config."),
    ] = None,
    enabled_execution_key: Annotated[
        list[str] | None,
        typer.Option(
            "--enabled-execution-key",
            help=(
                "Execution key exposed to users. Repeatable. Supported examples: "
                "max_order_cash_usd, symbols_allowlist. Omit for platform default."
            ),
        ),
    ] = None,
) -> None:
    """
    Register an external strategy owned by the logged-in provider/admin.

    AI usage example:
    ``nexusquant strategy create -i demo -n Demo --schema-file schema.json --output-unit SHARE_COUNT``
    """
    if schema_file and schema_json:
        raise typer.BadParameter("Use only one of --schema-file or --schema-json.")
    if config_file and config_json:
        raise typer.BadParameter("Use only one of --config-file or --config-json.")

    strategy_schema = (
        load_json_file(schema_file, label="strategy schema")
        if schema_file
        else load_json_option(schema_json, label="strategy schema")
    )
    if strategy_schema is None:
        strategy_schema = {"type": "object", "properties": {}, "required": []}

    config = (
        load_json_file(config_file, label="strategy config")
        if config_file
        else load_json_option(config_json, label="strategy config")
    )
    body: dict[str, Any] = {
        "strategy_id": strategy_id,
        "strategy_name": strategy_name,
        "strategy_schema": strategy_schema,
        "output_unit": output_unit,
    }
    if description is not None:
        body["description"] = description
    if config is not None:
        body["config"] = config
    if enabled_execution_key is not None:
        body["enabled_execution_keys"] = enabled_execution_key

    print_json_or_exit(console, lambda: api_client.create_strategy(body))


@strategy_app.command(
    "list",
    help=(
        "List strategies registered by the current provider. Admin users see all strategies. "
        "Calls GET /strategy-signal/provider-strategies/."
    ),
)
def list_strategies() -> None:
    """
    Output: JSON with strategies, total_count, ownership metadata, signal counts, and schema.
    """
    print_json_or_exit(console, api_client.list_provider_strategies)


@strategy_app.command(
    "signal",
    help=(
        "Send a strategy signal, send a signals map, or list signal history for one strategy. "
        "Without send fields, this lists history."
    ),
)
def strategy_signal(
    strategy_id: Annotated[
        str,
        typer.Argument(help="Strategy id in the URL/path and request body."),
    ],
    strategy_name: Annotated[
        str | None,
        typer.Option(
            "--strategy-name",
            "--name",
            help="Strategy display name sent with a signal. Defaults to strategy_id.",
        ),
    ] = None,
    history: Annotated[
        bool,
        typer.Option(
            "--history",
            help="List signal history instead of sending. This is the default when no send fields are provided.",
        ),
    ] = False,
    limit: Annotated[
        int,
        typer.Option("--limit", help="History page size.", min=1, max=500),
    ] = 50,
    offset: Annotated[
        int,
        typer.Option("--offset", help="History offset for pagination.", min=0),
    ] = 0,
    status_filter: Annotated[
        str | None,
        typer.Option(
            "--status",
            help="History filter: received, sent_to_broker, completed, failed.",
        ),
    ] = None,
    ticker: Annotated[
        str | None,
        typer.Option("--ticker", help="Ticker symbol for a single signal, e.g. AAPL."),
    ] = None,
    direction: Annotated[
        str | None,
        typer.Option("--direction", help="Signal direction: bull or bear."),
    ] = None,
    price: Annotated[
        float | None,
        typer.Option(
            "--price",
            help="Reference price. Required for send and notional_usd sizing.",
        ),
    ] = None,
    level: Annotated[
        float | None,
        typer.Option("--level", help="Signal strength/level, e.g. 0.8."),
    ] = None,
    time_value: Annotated[
        str | None,
        typer.Option(
            "--time",
            help="Signal timestamp in ISO-8601. Defaults to current UTC time when sending.",
        ),
    ] = None,
    sizing_kind: Annotated[
        str | None,
        typer.Option(
            "--sizing-kind", help="Optional explicit sizing: shares or notional_usd."
        ),
    ] = None,
    quantity: Annotated[
        int | None,
        typer.Option(
            "--quantity", help="Share quantity for shares sizing. Positive integer."
        ),
    ] = None,
    notional_usd: Annotated[
        float | None,
        typer.Option(
            "--notional-usd",
            help="USD notional for notional_usd sizing. Positive number.",
        ),
    ] = None,
    metadata_json: Annotated[
        str | None,
        typer.Option(
            "--metadata-json", help="Inline JSON object attached to signal.metadata."
        ),
    ] = None,
    signals_file: Annotated[
        Path | None,
        typer.Option(
            "--signals-file",
            exists=True,
            dir_okay=False,
            readable=True,
            help=(
                "UTF-8 JSON object for multi-route signals map. Keys are default or user_id; "
                "values are signal objects. When provided, single-signal options are ignored."
            ),
        ),
    ] = None,
) -> None:
    """
    Send or inspect signal history.

    History:
    ``nexusquant strategy signal my_alpha --history --limit 20``

    Single signal:
    ``nexusquant strategy signal my_alpha --ticker AAPL --direction bull --price 150 --level 0.8 --quantity 100``

    Signals map:
    ``nexusquant strategy signal my_alpha --signals-file signals.json --strategy-name "My Alpha"``
    """
    should_send_single = any(
        value is not None
        for value in (
            ticker,
            direction,
            price,
            level,
            quantity,
            notional_usd,
            signals_file,
        )
    )
    if history or not should_send_single:
        print_json_or_exit(
            console,
            lambda: api_client.get_provider_signal_history(
                strategy_id,
                limit=limit,
                offset=offset,
                direction=direction if history else None,
                status=status_filter,
            ),
        )
        return

    body: dict[str, Any] = {
        "strategy_id": strategy_id,
        "strategy_name": _strategy_name_arg(strategy_name, strategy_id),
    }
    if signals_file is not None:
        signals = load_json_file(signals_file, label="signals map")
        if not isinstance(signals, dict):
            raise typer.BadParameter("--signals-file must contain a JSON object.")
        body["signals"] = signals
        print_json_or_exit(console, lambda: api_client.send_strategy_signal(body))
        return

    missing = [
        name
        for name, value in {
            "--ticker": ticker,
            "--direction": direction,
            "--price": price,
            "--level": level,
        }.items()
        if value is None
    ]
    if missing:
        raise typer.BadParameter(
            f"Sending a single signal requires: {', '.join(missing)}"
        )

    signal: dict[str, Any] = {
        "ticker": ticker,
        "time": time_value or _now_iso(),
        "price": price,
        "level": level,
        "direction": direction,
    }
    if sizing_kind is not None:
        signal["sizing_kind"] = sizing_kind
    if quantity is not None:
        signal["quantity"] = quantity
    if notional_usd is not None:
        signal["notional_usd"] = notional_usd
    metadata = load_json_option(metadata_json, label="metadata")
    if metadata is not None:
        signal["metadata"] = metadata
    body["signal"] = signal
    print_json_or_exit(console, lambda: api_client.send_strategy_signal(body))


@sub_app.command(
    "config",
    help=(
        "Get all active subscribers' non-PII config snapshot for one strategy. "
        "Provider must own the strategy unless logged in as admin."
    ),
)
def subscriber_config(
    strategy_id: Annotated[str, typer.Argument(help="Strategy id to inspect.")],
) -> None:
    """
    Output: user_id and uses_default_config for each active subscriber. For non-default
    subscribers, includes normalized personal_config and effective_config. No email,
    username, Cognito ID, container ID, or subscription time is returned.
    """
    print_json_or_exit(console, lambda: api_client.get_subscriber_configs(strategy_id))


strategy_app.add_typer(sub_app, name="sub")


def register(app: typer.Typer) -> None:
    app.add_typer(strategy_app, name="strategy")
    app.add_typer(strategy_app, name="startegy", hidden=True)
