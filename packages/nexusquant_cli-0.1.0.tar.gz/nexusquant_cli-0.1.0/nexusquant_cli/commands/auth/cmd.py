from __future__ import annotations

import typer
from rich.console import Console

from nexusquant_cli.auth_pkce import ensure_fresh_id_token, login_and_save
from nexusquant_cli.config import CREDENTIALS_PATH, clear_credentials, load_credentials

console = Console()


def register(app: typer.Typer) -> None:
    @app.command(
        "auth",
        help=(
            "Login with Cognito Hosted UI and save local tokens. Use --refresh to force "
            "refresh, --status to inspect local login state, or --logout to clear tokens."
        ),
    )
    def auth(
        logout: bool = typer.Option(
            False,
            "--logout",
            help="Remove locally saved Cognito tokens and exit.",
        ),
        refresh: bool = typer.Option(
            False,
            "--refresh",
            help="Refresh the saved ID token using the saved refresh token.",
        ),
        status: bool = typer.Option(
            False,
            "--status",
            help="Print whether credentials are saved locally without showing token values.",
        ),
    ) -> None:
        """
        Authenticate this machine for NexusQuant strategy provider API calls.

        Output: tokens are stored in the current OS user's config directory with 0600
        permissions when supported. Commands send the ID token as Authorization: Bearer
        because the backend checks ``custom:userType`` for strategyProvider/admin access.
        """
        if logout:
            clear_credentials()
            console.print(
                "[green]已退出登录（本机保存的 NexusQuant token 已清除）。[/green]"
            )
            raise typer.Exit(0)

        if status:
            creds = load_credentials()
            if creds and creds.get("id_token"):
                console.print(f"[green]已登录。本地凭据: {CREDENTIALS_PATH}[/green]")
            else:
                console.print("[yellow]尚未登录。请执行：nexusquant auth[/yellow]")
            raise typer.Exit(0)

        try:
            if refresh:
                ensure_fresh_id_token(force_refresh=True)
                console.print("[green]token 已刷新。[/green]")
            else:
                login_and_save()
                console.print("[green]登录成功，token 已保存在本机。[/green]")
        except Exception as e:
            console.print(f"[red]{e}[/red]")
            raise typer.Exit(1) from e
