from __future__ import annotations

import typer

from nexusquant_cli.commands.auth.cmd import register as register_auth
from nexusquant_cli.commands.strategy.cmd import register as register_strategy


def register_all(app: typer.Typer) -> None:
    register_auth(app)
    register_strategy(app)
