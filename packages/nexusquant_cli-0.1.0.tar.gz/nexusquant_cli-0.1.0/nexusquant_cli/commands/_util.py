from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

import typer
from rich.console import Console


def print_json_or_exit(console: Console, fetch: Callable[[], Any]) -> None:
    try:
        data = fetch()
    except Exception as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from e
    console.print_json(data=data)


def load_json_option(value: str | None, *, label: str) -> Any:
    if value is None:
        return None
    try:
        return json.loads(value)
    except json.JSONDecodeError as e:
        raise typer.BadParameter(f"{label} must be valid JSON: {e}") from e


def load_json_file(path: Path, *, label: str) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except OSError as e:
        raise typer.BadParameter(f"Cannot read {label}: {e}") from e
    except json.JSONDecodeError as e:
        raise typer.BadParameter(f"{label} must contain valid JSON: {e}") from e
