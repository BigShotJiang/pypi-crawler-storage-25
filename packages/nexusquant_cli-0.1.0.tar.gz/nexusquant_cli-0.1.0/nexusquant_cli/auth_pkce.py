"""
Cognito Hosted UI login via OAuth 2.0 Authorization Code + PKCE.

Nexus service reads ``custom:userType`` from JWT claims for provider/admin
authorization, so the CLI stores and sends the ID token as ``Authorization:
Bearer``. Refresh uses the Cognito refresh token when the ID token is near expiry.
"""

from __future__ import annotations

import base64
import hashlib
import json
import secrets
import threading
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any

import httpx

from nexusquant_cli.config import (
    cognito_client_id,
    cognito_domain_host,
    load_credentials,
    redirect_uri,
    save_credentials,
)


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _pkce_pair() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(48)
    challenge = _b64url(hashlib.sha256(verifier.encode("ascii")).digest())
    return verifier, challenge


def _parse_query(path: str) -> dict[str, str]:
    query = urllib.parse.urlparse(path).query
    return dict(urllib.parse.parse_qsl(query))


def _token_url(domain_host: str) -> str:
    return f"https://{domain_host}/oauth2/token"


def _post_token(domain_host: str, body: dict[str, Any]) -> dict[str, Any]:
    with httpx.Client(timeout=30.0) as client:
        response = client.post(
            _token_url(domain_host),
            data=body,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
    if response.status_code >= 400:
        try:
            detail: Any = response.json()
        except json.JSONDecodeError:
            detail = response.text
        raise RuntimeError(
            f"Cognito token endpoint error ({response.status_code}): {detail}"
        )
    return response.json()


def refresh_tokens(
    *,
    domain_host: str,
    client_id: str,
    refresh_token: str,
) -> dict[str, Any]:
    return _post_token(
        domain_host,
        {
            "grant_type": "refresh_token",
            "client_id": client_id,
            "refresh_token": refresh_token,
        },
    )


def exchange_code_for_tokens(
    *,
    domain_host: str,
    client_id: str,
    code: str,
    redirect_uri_value: str,
    code_verifier: str,
) -> dict[str, Any]:
    return _post_token(
        domain_host,
        {
            "grant_type": "authorization_code",
            "client_id": client_id,
            "code": code,
            "redirect_uri": redirect_uri_value,
            "code_verifier": code_verifier,
        },
    )


def run_browser_login() -> dict[str, Any]:
    domain_host = cognito_domain_host()
    client_id = cognito_client_id()
    redirect_uri_value = redirect_uri()
    verifier, challenge = _pkce_pair()

    auth_params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri_value,
        "scope": "openid email phone",
        "code_challenge_method": "S256",
        "code_challenge": challenge,
    }
    auth_url = (
        f"https://{domain_host}/oauth2/authorize?{urllib.parse.urlencode(auth_params)}"
    )

    code_holder: dict[str, str | None] = {"code": None, "error": None}
    done = threading.Event()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, _format: str, *_args: object) -> None:
            return

        def do_GET(self) -> None:  # noqa: N802
            params = _parse_query(self.path)
            if "code" in params:
                code_holder["code"] = params["code"]
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(
                    b"<html><body><p>NexusQuant login successful. You can close this tab.</p></body></html>"
                )
            else:
                error = (
                    params.get("error_description")
                    or params.get("error")
                    or "unknown_error"
                )
                code_holder["error"] = error
                self.send_response(400)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(
                    f"<html><body><p>NexusQuant login failed: {error}</p></body></html>".encode(
                        "utf-8"
                    )
                )
            done.set()

    parsed = urllib.parse.urlparse(redirect_uri_value)
    if parsed.hostname not in ("127.0.0.1", "localhost") or not parsed.port:
        raise RuntimeError("NEXUSQUANT_REDIRECT_URI must be localhost with a port.")

    bind_host = "127.0.0.1" if parsed.hostname == "localhost" else parsed.hostname
    server = HTTPServer((bind_host or "127.0.0.1", parsed.port), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    webbrowser.open(auth_url)

    if not done.wait(timeout=300):
        server.shutdown()
        raise TimeoutError("No OAuth callback received within 5 minutes.")
    server.shutdown()

    if code_holder["error"]:
        raise RuntimeError(f"Cognito error: {code_holder['error']}")
    code = code_holder["code"]
    if not code:
        raise RuntimeError("No authorization code in callback.")

    tokens = exchange_code_for_tokens(
        domain_host=domain_host,
        client_id=client_id,
        code=code,
        redirect_uri_value=redirect_uri_value,
        code_verifier=verifier,
    )
    if "id_token" not in tokens:
        raise RuntimeError("Cognito token response missing id_token.")
    return tokens


def persist_tokens(tokens: dict[str, Any]) -> None:
    save_credentials(
        {
            "id_token": tokens["id_token"],
            "access_token": tokens.get("access_token"),
            "refresh_token": tokens.get("refresh_token"),
            "expires_in": int(tokens.get("expires_in") or 0),
            "saved_at": time.time(),
        }
    )


def ensure_fresh_id_token(*, force_refresh: bool = False) -> str:
    creds = load_credentials()
    if not creds or not creds.get("id_token"):
        raise RuntimeError("尚未登录。请先执行：nexusquant auth")

    expires_in = int(creds.get("expires_in") or 0)
    saved_at = float(creds.get("saved_at") or 0)
    remaining = saved_at + expires_in - time.time() if expires_in > 0 else 999999
    refresh_token = creds.get("refresh_token")
    if not force_refresh and (remaining > 120 or not refresh_token):
        return str(creds["id_token"])
    if not refresh_token:
        return str(creds["id_token"])

    new_tokens = refresh_tokens(
        domain_host=cognito_domain_host(),
        client_id=cognito_client_id(),
        refresh_token=refresh_token,
    )
    merged = {
        "id_token": new_tokens.get("id_token") or creds["id_token"],
        "access_token": new_tokens.get("access_token") or creds.get("access_token"),
        "refresh_token": new_tokens.get("refresh_token") or refresh_token,
        "expires_in": int(new_tokens.get("expires_in") or expires_in),
        "saved_at": time.time(),
    }
    save_credentials(merged)
    return str(merged["id_token"])


def login_and_save() -> None:
    persist_tokens(run_browser_login())
