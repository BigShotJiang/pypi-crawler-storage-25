from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from platformdirs import user_config_dir

CONFIG_DIR = Path(user_config_dir("nexusquant-cli", appauthor=False))
CREDENTIALS_PATH = CONFIG_DIR / "credentials.json"

DEFAULT_API_ENDPOINT = "https://api.nexusquant.co"
DEFAULT_COGNITO_DOMAIN = "auth.lookatwallstreet.com"
DEFAULT_COGNITO_CLIENT_ID = "5o7hhd4hn4birr8c29vndehiat"
DEFAULT_REDIRECT_URI = "http://127.0.0.1:8251/callback"


def _env(name: str, default: str | None = None) -> str | None:
    value = os.environ.get(name)
    if value is not None and value.strip():
        return value.strip()
    return default


def api_base_url() -> str:
    endpoint = (
        _env("NEXUSQUANT_API_ENDPOINT", DEFAULT_API_ENDPOINT) or DEFAULT_API_ENDPOINT
    ).rstrip("/")
    # Backwards-compatible override: allow either host-only endpoint or full /api base.
    base_override = _env("NEXUSQUANT_API_BASE_URL")
    if base_override:
        return base_override.rstrip("/")
    return f"{endpoint}/api"


def cognito_domain_host() -> str:
    domain = (
        _env("NEXUSQUANT_COGNITO_DOMAIN", DEFAULT_COGNITO_DOMAIN)
        or DEFAULT_COGNITO_DOMAIN
    )
    return domain.removeprefix("https://").removeprefix("http://").split("/")[0]


def cognito_client_id() -> str:
    return (
        _env("NEXUSQUANT_COGNITO_CLIENT_ID", DEFAULT_COGNITO_CLIENT_ID)
        or DEFAULT_COGNITO_CLIENT_ID
    )


def redirect_uri() -> str:
    return _env("NEXUSQUANT_REDIRECT_URI", DEFAULT_REDIRECT_URI) or DEFAULT_REDIRECT_URI


def load_credentials() -> dict[str, Any] | None:
    if not CREDENTIALS_PATH.is_file():
        return None
    try:
        return json.loads(CREDENTIALS_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def save_credentials(data: dict[str, Any]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        CREDENTIALS_PATH.chmod(0o600)
    except OSError:
        pass


def clear_credentials() -> None:
    try:
        CREDENTIALS_PATH.unlink(missing_ok=True)
    except OSError:
        pass
