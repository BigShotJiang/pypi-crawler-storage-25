from __future__ import annotations

import json
from typing import Any

import httpx

from nexusquant_cli.auth_pkce import ensure_fresh_id_token
from nexusquant_cli.config import api_base_url


def _headers() -> dict[str, str]:
    token = ensure_fresh_id_token()
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }


def _raise_for_error(response: httpx.Response) -> None:
    if response.status_code < 400:
        return
    try:
        detail: Any = response.json()
    except json.JSONDecodeError:
        detail = response.text
    raise RuntimeError(f"HTTP {response.status_code}: {detail}")


def get_json(
    path: str, *, params: dict[str, Any] | None = None, timeout: float = 60.0
) -> Any:
    with httpx.Client(timeout=timeout) as client:
        response = client.get(
            f"{api_base_url()}{path}", headers=_headers(), params=params
        )
    _raise_for_error(response)
    return response.json()


def post_json(path: str, body: Any, *, timeout: float = 60.0) -> Any:
    headers = {**_headers(), "Content-Type": "application/json"}
    with httpx.Client(timeout=timeout) as client:
        response = client.post(f"{api_base_url()}{path}", headers=headers, json=body)
    _raise_for_error(response)
    return response.json()


def create_strategy(body: dict[str, Any]) -> Any:
    """POST /strategy-signal/register/ — create/update an external strategy."""
    return post_json("/strategy-signal/register/", body)


def list_provider_strategies() -> Any:
    """GET /strategy-signal/provider-strategies/ — owned strategies, or all for admin."""
    return get_json("/strategy-signal/provider-strategies/")


def get_provider_signal_history(
    strategy_id: str,
    *,
    limit: int,
    offset: int,
    direction: str | None = None,
    status: str | None = None,
) -> Any:
    """GET /strategy-signal/provider-signals/{strategy_id}/ — scoped signal history."""
    params: dict[str, Any] = {"limit": limit, "offset": offset}
    if direction:
        params["direction"] = direction
    if status:
        params["status"] = status
    return get_json(f"/strategy-signal/provider-signals/{strategy_id}/", params=params)


def send_strategy_signal(body: dict[str, Any]) -> Any:
    """POST /strategy-signal/ — send one signal or a signals map."""
    return post_json("/strategy-signal/", body)


def get_subscriber_configs(strategy_id: str) -> Any:
    """GET /strategy-signal/subscriber-configs/{strategy_id}/ — non-PII subscriber config."""
    return get_json(f"/strategy-signal/subscriber-configs/{strategy_id}/")
