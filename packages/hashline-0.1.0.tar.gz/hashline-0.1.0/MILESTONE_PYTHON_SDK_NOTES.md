# Milestone: Python SDK v0.1

**Status:** complete (pending operator verification against live API).

## What was built

A standalone Python SDK package (`hashline`) that wraps the Hashline audit
ledger v1 HTTP API. Mirrors the TypeScript SDK's feature set and adds the
endpoints deferred in the TS milestone.

### Files

```
src/hashline/
├── __init__.py      # public re-exports
├── py.typed         # PEP 561 marker
├── types.py         # TypedDict wire types (EventType, Actor, EventAck, BatchAck, …)
├── errors.py        # HashlineError / APIError / ValidationError / NetworkError
├── _retry.py        # compute_backoff_ms, parse_retry_after_ms, is_retryable_status
└── client.py        # _ClientCore, Client (sync), AsyncClient (async)
tests/
├── test_client.py   # happy path, auth, no-op, env vars
├── test_validation.py
├── test_retry.py    # unit tests for _retry + integration retry tests
└── test_async.py
examples/
├── basic.py
├── anthropic_tools.py
└── openai_tools.py
```

## Design decisions

### Sync + async via shared core

`_ClientCore` holds all non-IO logic: constructor, header building, URL
construction, response error parsing, delay calculation, and body builders.
`Client` and `AsyncClient` each hold their own `_request` method (sync vs
async) and call `asyncio.sleep` vs `time.sleep` respectively. This avoids
duplicating validation and serialisation while keeping the two execution models
clearly separated.

### Per-attempt timeout

The spec said `timeout=30.0`. After clarification, each attempt gets a fresh
30 s budget. This is implemented by passing `timeout=self._timeout` directly
to `httpx.Client(timeout=...)`, so every `request()` call starts a new timeout.
This differs from the TS SDK's composite timeout but is the right choice for
long-running operations like export polling.

### TypedDict over dataclass

TypedDicts are the idiomatic Python choice for JSON-shaped types: they're
serialisable, require no conversion, play well with `mypy --strict`, and feel
natural to users passing dicts (e.g. `actor={"type": "agent", "id": "x"}`).

### `batch()` returns full `BatchAck`

The Python spec example comment implied a flat list, but the wire response is
`{"run_id": "...", "events": [...]}`. We return the full `BatchAck` TypedDict,
matching the wire format. Users access `result["events"]` to iterate acks.

### Validation before no-op check? No.

No-op mode (`enabled=False`) skips all validation. A disabled client is
completely silent — including for bad inputs. This mirrors the TS SDK and keeps
no-op semantics clean: "I'm disabled, I do nothing."

### `type` and `format` as parameter names

Both shadow Python builtins. This is deliberate — it matches the public API
shown in the spec and is the pattern used by Anthropic's and OpenAI's own
Python SDKs. Neither builtin is called inside the affected methods.

### Actor type constraint

`actor.type` is validated against `{"agent", "human", "system"}` at runtime,
not just by the TypedDict annotation. This catches typos in dynamic callers
that aren't type-checked.

## Deferred / non-goals

The following were explicitly excluded per spec:

1. **CLI tool.** Not built.
2. **Framework-specific packages** (langchain, crewai, etc.). Not built.
3. **Client-side hash chain verification.** Server does this; `verify()` calls
   the server endpoint.
4. **Auto PII scrubbing.** Not built; documented in README.
5. **Auto instrumentation.** All instrumentation is explicit `client.event()` calls.
6. **Queue / buffering.** All calls are synchronous; fire-and-forget queue is
   a natural v0.2.
7. **AbortSignal equivalent.** Python's per-attempt timeout via httpx covers
   this use case adequately.
8. **Auto-generated `client_event_id`.** Passed through when supplied; not
   auto-generated. Can be added without API change.
9. **Browser build.** Server-only; no browser target.

## Ambiguities resolved

All five ambiguities flagged before implementation were resolved by the operator:

| Ambiguity | Resolution |
|---|---|
| `batch()` return type | Full `BatchAck` matching wire format |
| URL patterns for new endpoints | Confirmed as inferred (see client.py) |
| EventType validation | Validate against exact Literal set |
| actor.type validation | Validate — constrain to agent/human/system |
| Timeout semantics | Per-attempt (30 s each), not combined |

## Verification results

```
mypy src/hashline
→ Success: no issues found in 5 source files

ruff check .
→ All checks passed!

ruff format --check .
→ 13 files already formatted

pytest -v
→ 72 passed in 0.48s

python -m build
→ Successfully built hashline-0.1.0.tar.gz and hashline-0.1.0-py3-none-any.whl

uv pip install dist/hashline-0.1.0-py3-none-any.whl --force-reinstall
python -c "from hashline import Client, AsyncClient, APIError, ValidationError; print('ok')"
→ ok
```

All exit criteria met. Not tested against live API (requires operator credentials).
