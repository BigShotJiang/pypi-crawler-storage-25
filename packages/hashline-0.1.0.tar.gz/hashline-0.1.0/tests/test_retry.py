"""Tests for retry logic: backoff, Retry-After, retryable/non-retryable statuses."""

from __future__ import annotations

import httpx
import pytest
import respx

from hashline import Client
from hashline._retry import compute_backoff_ms, is_retryable_status, parse_retry_after_ms
from hashline.errors import APIError, NetworkError

BASE = "https://api.hashline.dev/v1"
ACTOR = {"type": "agent", "id": "test-agent"}
ACK = {"id": "evt_1", "run_id": "run_1", "seq": 0, "hash": "sha256:abc"}


def _client(**kwargs: object) -> Client:
    return Client(api_key="al_test_key", _random_fn=lambda: 0.0, **kwargs)  # type: ignore[arg-type]


def _event(client: Client) -> object:
    return client.event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})


# ---------------------------------------------------------------------------
# unit tests for _retry helpers
# ---------------------------------------------------------------------------


def test_compute_backoff_zero_when_random_zero() -> None:
    delay = compute_backoff_ms(0, base_ms=250, max_ms=10_000, random_fn=lambda: 0.0)
    assert delay == 0.0


def test_compute_backoff_max_when_random_one() -> None:
    delay = compute_backoff_ms(0, base_ms=250, max_ms=10_000, random_fn=lambda: 1.0)
    assert delay == pytest.approx(250.0)


def test_compute_backoff_capped_at_max_ms() -> None:
    delay = compute_backoff_ms(10, base_ms=250, max_ms=500, random_fn=lambda: 1.0)
    assert delay == pytest.approx(500.0)


def test_compute_backoff_increases_exponentially() -> None:
    delays = [
        compute_backoff_ms(i, base_ms=250, max_ms=10_000, random_fn=lambda: 1.0) for i in range(4)
    ]
    assert delays == pytest.approx([250.0, 500.0, 1000.0, 2000.0])


def test_is_retryable_status_retryable() -> None:
    for status in [408, 429, 500, 502, 503, 504, 599]:
        assert is_retryable_status(status), f"{status} should be retryable"


def test_is_retryable_status_not_retryable() -> None:
    for status in [200, 201, 301, 400, 401, 403, 404, 422]:
        assert not is_retryable_status(status), f"{status} should not be retryable"


def test_parse_retry_after_delta_seconds() -> None:
    ms = parse_retry_after_ms("2")
    assert ms == pytest.approx(2000.0)


def test_parse_retry_after_zero() -> None:
    ms = parse_retry_after_ms("0")
    assert ms == pytest.approx(0.0)


def test_parse_retry_after_missing_returns_none() -> None:
    assert parse_retry_after_ms(None) is None
    assert parse_retry_after_ms("") is None


def test_parse_retry_after_http_date() -> None:
    # Use a date far in the future to avoid flakiness
    now_ms = 1_000_000_000_000.0  # epoch ms
    future_ms = now_ms + 5_000.0
    import datetime

    dt = datetime.datetime.fromtimestamp(future_ms / 1000.0, tz=datetime.timezone.utc)
    header = dt.strftime("%a, %d %b %Y %H:%M:%S GMT")
    ms = parse_retry_after_ms(header, now_ms=now_ms)
    assert ms == pytest.approx(5_000.0, abs=1000.0)


def test_parse_retry_after_past_date_clamped_to_zero() -> None:
    # A past HTTP date should give 0, not negative
    ms = parse_retry_after_ms("Thu, 01 Jan 1970 00:00:00 GMT", now_ms=1_000_000.0)
    assert ms == 0.0


def test_parse_retry_after_garbage_returns_none() -> None:
    assert parse_retry_after_ms("not-a-date-or-number") is None


# ---------------------------------------------------------------------------
# retry integration tests
# ---------------------------------------------------------------------------


def test_429_retried_succeeds_on_second_attempt(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("time.sleep", lambda _: None)
    with respx.mock:
        responses = iter([httpx.Response(429), httpx.Response(200, json=ACK)])
        route = respx.post(f"{BASE}/events").mock(side_effect=lambda req: next(responses))
        result = _event(_client())
        assert result is not None
        assert route.call_count == 2


def test_500_retried_succeeds_on_second_attempt(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("time.sleep", lambda _: None)
    with respx.mock:
        responses = iter([httpx.Response(503), httpx.Response(200, json=ACK)])
        route = respx.post(f"{BASE}/events").mock(side_effect=lambda req: next(responses))
        result = _event(_client())
        assert result is not None
        assert route.call_count == 2


def test_401_not_retried() -> None:
    with respx.mock:
        route = respx.post(f"{BASE}/events").mock(
            return_value=httpx.Response(401, json={"title": "Unauthorized", "status": 401})
        )
        with pytest.raises(APIError) as exc_info:
            _event(_client())
        assert exc_info.value.status == 401
        assert route.call_count == 1


def test_400_not_retried() -> None:
    with respx.mock:
        route = respx.post(f"{BASE}/events").mock(
            return_value=httpx.Response(400, json={"title": "Bad Request", "status": 400})
        )
        with pytest.raises(APIError) as exc_info:
            _event(_client())
        assert exc_info.value.status == 400
        assert route.call_count == 1


def test_network_error_retried_succeeds(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("time.sleep", lambda _: None)
    with respx.mock:
        responses: list[httpx.Response | Exception] = [
            httpx.ConnectError("connection refused"),
            httpx.Response(200, json=ACK),
        ]
        idx = [0]

        def side_effect(req: httpx.Request) -> httpx.Response:
            val = responses[idx[0]]
            idx[0] += 1
            if isinstance(val, Exception):
                raise val
            return val

        route = respx.post(f"{BASE}/events").mock(side_effect=side_effect)
        result = _event(_client())
        assert result is not None
        assert route.call_count == 2


def test_retry_after_header_respected(monkeypatch: pytest.MonkeyPatch) -> None:
    sleep_calls: list[float] = []
    monkeypatch.setattr("time.sleep", lambda s: sleep_calls.append(s))

    with respx.mock:
        responses = iter(
            [
                httpx.Response(429, headers={"Retry-After": "3"}),
                httpx.Response(200, json=ACK),
            ]
        )
        respx.post(f"{BASE}/events").mock(side_effect=lambda req: next(responses))
        # _now_fn=lambda: 0 is not needed for delta-seconds form
        _event(Client(api_key="al_test_key", _random_fn=lambda: 0.0))

    assert len(sleep_calls) == 1
    assert sleep_calls[0] == pytest.approx(3.0)


def test_max_retries_exhausted_raises_api_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("time.sleep", lambda _: None)
    with respx.mock:
        respx.post(f"{BASE}/events").mock(return_value=httpx.Response(503))
        with pytest.raises(APIError) as exc_info:
            _event(_client(max_retries=2))
        assert exc_info.value.status == 503


def test_max_retries_exhausted_on_network_error_raises_network_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("time.sleep", lambda _: None)
    with respx.mock:
        respx.post(f"{BASE}/events").mock(side_effect=httpx.ConnectError("connection refused"))
        with pytest.raises(NetworkError):
            _event(_client(max_retries=2))


def test_exponential_backoff_increases(monkeypatch: pytest.MonkeyPatch) -> None:
    """With random=1.0, delays should be 0.25s, 0.5s, 1.0s."""
    sleep_calls: list[float] = []
    monkeypatch.setattr("time.sleep", lambda s: sleep_calls.append(s))

    with respx.mock:
        # 4 attempts total (max_retries=3): fail 3 times, succeed on 4th
        responses = iter(
            [
                httpx.Response(503),
                httpx.Response(503),
                httpx.Response(503),
                httpx.Response(200, json=ACK),
            ]
        )
        respx.post(f"{BASE}/events").mock(side_effect=lambda req: next(responses))
        result = _event(Client(api_key="al_test_key", max_retries=3, _random_fn=lambda: 1.0))
        assert result is not None

    assert len(sleep_calls) == 3
    assert sleep_calls[0] == pytest.approx(0.25)
    assert sleep_calls[1] == pytest.approx(0.50)
    assert sleep_calls[2] == pytest.approx(1.00)
    # strictly increasing
    assert sleep_calls[0] < sleep_calls[1] < sleep_calls[2]
