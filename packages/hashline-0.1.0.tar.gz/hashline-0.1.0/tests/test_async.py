"""Tests for AsyncClient — async/await, no-op mode, and retry."""

from __future__ import annotations

import httpx
import pytest
import respx

from hashline import AsyncClient
from hashline.errors import APIError, NetworkError

BASE = "https://api.hashline.dev/v1"
ACTOR = {"type": "agent", "id": "test-agent"}
ACK = {"id": "evt_1", "run_id": "run_1", "seq": 0, "hash": "sha256:abc"}
BATCH_ACK = {"run_id": "run_1", "events": [ACK]}


async def test_async_event_success() -> None:
    async with respx.mock:  # type: ignore[attr-defined]
        respx.post(f"{BASE}/events").mock(return_value=httpx.Response(200, json=ACK))
        async with AsyncClient(api_key="al_test_key") as client:
            result = await client.event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})
        assert result is not None
        assert result["id"] == "evt_1"
        assert result["seq"] == 0


async def test_async_batch_success() -> None:
    async with respx.mock:  # type: ignore[attr-defined]
        respx.post(f"{BASE}/events/batch").mock(return_value=httpx.Response(200, json=BATCH_ACK))
        events = [
            {"type": "prompt", "actor": ACTOR, "payload": {"model": "m", "content": "hi"}},
            {"type": "completion", "actor": ACTOR, "payload": {"model": "m", "content": "bye"}},
        ]
        async with AsyncClient(api_key="al_test_key") as client:
            result = await client.batch("run_1", events)  # type: ignore[arg-type]
        assert result is not None
        assert result["run_id"] == "run_1"


async def test_async_noop_event_returns_none() -> None:
    async with respx.mock:  # type: ignore[attr-defined]
        async with AsyncClient(api_key="key", enabled=False) as client:
            result = await client.event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})
        assert result is None
        assert len(respx.calls) == 0


async def test_async_noop_batch_returns_none() -> None:
    async with respx.mock:  # type: ignore[attr-defined]
        async with AsyncClient(api_key="key", enabled=False) as client:
            result = await client.batch("run_1", [])  # type: ignore[arg-type]
        assert result is None
        assert len(respx.calls) == 0


async def test_async_retries_on_503() -> None:
    # Use _random_fn=lambda: 0.0 so backoff delay is 0ms — asyncio.sleep(0) is instant.
    async with respx.mock:  # type: ignore[attr-defined]
        responses = iter([httpx.Response(503), httpx.Response(200, json=ACK)])
        route = respx.post(f"{BASE}/events").mock(side_effect=lambda req: next(responses))
        async with AsyncClient(api_key="key", _random_fn=lambda: 0.0) as client:
            result = await client.event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})
        assert result is not None
        assert route.call_count == 2


async def test_async_non_retryable_raises_immediately() -> None:
    async with respx.mock:  # type: ignore[attr-defined]
        route = respx.post(f"{BASE}/events").mock(
            return_value=httpx.Response(401, json={"title": "Unauthorized", "status": 401})
        )
        async with AsyncClient(api_key="key") as client:
            with pytest.raises(APIError) as exc_info:
                await client.event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})
        assert exc_info.value.status == 401
        assert route.call_count == 1


async def test_async_network_error_raises_network_error() -> None:
    # _random_fn=lambda: 0.0 keeps retry delays at 0 so the test runs fast.
    async with respx.mock:  # type: ignore[attr-defined]
        respx.post(f"{BASE}/events").mock(side_effect=httpx.ConnectError("connection refused"))
        async with AsyncClient(api_key="key", max_retries=1, _random_fn=lambda: 0.0) as client:
            with pytest.raises(NetworkError):
                await client.event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})


async def test_async_context_manager() -> None:
    async with respx.mock:  # type: ignore[attr-defined]
        respx.post(f"{BASE}/events").mock(return_value=httpx.Response(200, json=ACK))
        async with AsyncClient(api_key="al_test_key") as client:
            result = await client.event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})
            assert result is not None


async def test_async_auth_header() -> None:
    async with respx.mock:  # type: ignore[attr-defined]
        route = respx.post(f"{BASE}/events").mock(return_value=httpx.Response(200, json=ACK))
        async with AsyncClient(api_key="al_mykey") as client:
            await client.event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})
        assert route.calls[0].request.headers["authorization"] == "Bearer al_mykey"


async def test_async_verify() -> None:
    async with respx.mock:  # type: ignore[attr-defined]
        respx.post(f"{BASE}/runs/run_1/verify").mock(
            return_value=httpx.Response(200, json={"valid": True, "events_verified": 5})
        )
        async with AsyncClient(api_key="al_test_key") as client:
            result = await client.verify("run_1")
        assert result is not None
        assert result["valid"] is True
