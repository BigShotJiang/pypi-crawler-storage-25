"""Tests for input validation — all raised before any network I/O."""

from __future__ import annotations

import pytest

from hashline import Client
from hashline.errors import ValidationError

ACTOR = {"type": "agent", "id": "test-agent"}


def client() -> Client:
    return Client(api_key="al_test_key")


# ---------------------------------------------------------------------------
# event() validation
# ---------------------------------------------------------------------------


def test_missing_run_id_raises() -> None:
    with pytest.raises(ValidationError, match="run_id"):
        client().event(run_id="", type="tool_call", actor=ACTOR, payload={})


def test_missing_type_raises() -> None:
    with pytest.raises(ValidationError, match="type"):
        client().event(run_id="run_1", type="", actor=ACTOR, payload={})


def test_invalid_type_value_raises() -> None:
    with pytest.raises(ValidationError, match="type"):
        client().event(run_id="run_1", type="not_a_real_type", actor=ACTOR, payload={})


def test_missing_actor_raises() -> None:
    with pytest.raises(ValidationError, match="actor"):
        client().event(run_id="run_1", type="tool_call", actor="not_a_dict", payload={})  # type: ignore[arg-type]


def test_missing_actor_type_raises() -> None:
    with pytest.raises(ValidationError, match="actor.type"):
        client().event(run_id="run_1", type="tool_call", actor={"id": "a"}, payload={})


def test_invalid_actor_type_raises() -> None:
    with pytest.raises(ValidationError, match="actor.type"):
        client().event(
            run_id="run_1",
            type="tool_call",
            actor={"type": "robot", "id": "a"},  # type: ignore[typeddict-item]
            payload={},
        )


def test_missing_actor_id_raises() -> None:
    with pytest.raises(ValidationError, match="actor.id"):
        client().event(
            run_id="run_1", type="tool_call", actor={"type": "agent", "id": ""}, payload={}
        )


def test_all_valid_event_types_accepted() -> None:
    """Smoke-test that every defined EventType passes validation without error.

    We only test the validation layer here — no HTTP is made.
    """
    import httpx
    import respx

    from hashline.types import VALID_EVENT_TYPES

    ack = {"id": "evt_1", "run_id": "run_1", "seq": 0, "hash": "sha256:abc"}
    for event_type in VALID_EVENT_TYPES:
        with respx.mock:
            respx.post("https://api.hashline.dev/v1/events").mock(
                return_value=httpx.Response(200, json=ack)
            )
            client().event(run_id="run_1", type=event_type, actor=ACTOR, payload={})


def test_all_valid_actor_types_accepted() -> None:
    """All three actor types pass validation."""
    import httpx
    import respx

    ack = {"id": "evt_1", "run_id": "run_1", "seq": 0, "hash": "sha256:abc"}
    for actor_type in ("agent", "human", "system"):
        with respx.mock:
            respx.post("https://api.hashline.dev/v1/events").mock(
                return_value=httpx.Response(200, json=ack)
            )
            client().event(
                run_id="run_1",
                type="tool_call",
                actor={"type": actor_type, "id": "x"},  # type: ignore[typeddict-item]
                payload={},
            )


# ---------------------------------------------------------------------------
# batch() validation
# ---------------------------------------------------------------------------


def test_batch_empty_raises() -> None:
    with pytest.raises(ValidationError, match="at least one"):
        client().batch("run_1", [])  # type: ignore[arg-type]


def test_batch_over_500_raises() -> None:
    events = [{"type": "annotation", "actor": ACTOR, "payload": {}}] * 501
    with pytest.raises(ValidationError, match="500"):
        client().batch("run_1", events)  # type: ignore[arg-type]


def test_batch_exactly_500_is_valid() -> None:
    """500 events must not raise ValidationError (max is inclusive)."""
    import httpx
    import respx

    events = [{"type": "annotation", "actor": ACTOR, "payload": {}}] * 500
    ack = {"run_id": "run_1", "events": []}
    with respx.mock:
        respx.post("https://api.hashline.dev/v1/events/batch").mock(
            return_value=httpx.Response(200, json=ack)
        )
        result = client().batch("run_1", events)  # type: ignore[arg-type]
        assert result is not None


def test_batch_conflicting_run_id_raises() -> None:
    events = [
        {"type": "tool_call", "actor": ACTOR, "payload": {}, "run_id": "run_OTHER"},
    ]
    with pytest.raises(ValidationError, match="run_id"):
        client().batch("run_1", events)  # type: ignore[arg-type]


def test_batch_event_missing_type_raises() -> None:
    events = [{"actor": ACTOR, "payload": {}}]
    with pytest.raises(ValidationError, match="type"):
        client().batch("run_1", events)  # type: ignore[arg-type]


def test_batch_event_missing_payload_raises() -> None:
    events = [{"type": "tool_call", "actor": ACTOR}]
    with pytest.raises(ValidationError, match="payload"):
        client().batch("run_1", events)  # type: ignore[arg-type]


def test_batch_event_invalid_actor_type_raises() -> None:
    events = [{"type": "tool_call", "actor": {"type": "robot", "id": "a"}, "payload": {}}]
    with pytest.raises(ValidationError, match="actor.type"):
        client().batch("run_1", events)  # type: ignore[arg-type]


def test_batch_missing_run_id_raises() -> None:
    with pytest.raises(ValidationError, match="run_id"):
        client().batch("", [{"type": "tool_call", "actor": ACTOR, "payload": {}}])  # type: ignore[arg-type]
