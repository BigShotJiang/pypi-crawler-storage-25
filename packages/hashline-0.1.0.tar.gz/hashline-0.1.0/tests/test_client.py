"""Tests for Client happy paths, no-op mode, and env var fallbacks."""

from __future__ import annotations

import httpx
import pytest
import respx

from hashline import Client
from hashline.errors import APIError, ValidationError

BASE = "https://api.hashline.dev/v1"

EVENT_ACK = {"id": "evt_1", "run_id": "run_1", "seq": 0, "hash": "sha256:abc"}
BATCH_ACK = {"run_id": "run_1", "events": [EVENT_ACK]}
ACTOR = {"type": "agent", "id": "test-agent"}


def _client(**kwargs: object) -> Client:
    return Client(api_key="al_test_key", **kwargs)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# event()
# ---------------------------------------------------------------------------


def test_event_sends_correct_body_and_returns_ack() -> None:
    with respx.mock:
        route = respx.post(f"{BASE}/events").mock(return_value=httpx.Response(200, json=EVENT_ACK))
        client = _client()
        result = client.event(
            run_id="run_1",
            type="tool_call",
            actor=ACTOR,
            payload={"name": "search", "arguments": {"q": "hello"}},
        )

        assert result is not None
        assert result["id"] == "evt_1"
        assert result["run_id"] == "run_1"
        assert result["seq"] == 0
        assert result["hash"] == "sha256:abc"

        body = route.calls[0].request.read()
        import json

        sent = json.loads(body)
        assert sent["run_id"] == "run_1"
        assert sent["type"] == "tool_call"
        assert sent["actor"] == ACTOR


def test_event_sends_optional_fields() -> None:
    with respx.mock:
        route = respx.post(f"{BASE}/events").mock(return_value=httpx.Response(200, json=EVENT_ACK))
        _client().event(
            run_id="run_1",
            type="prompt",
            actor=ACTOR,
            payload={},
            client_event_id="idem_key",
            client_ts=1713456789000,
        )
        import json

        sent = json.loads(route.calls[0].request.read())
        assert sent["client_event_id"] == "idem_key"
        assert sent["client_ts"] == 1713456789000


# ---------------------------------------------------------------------------
# batch()
# ---------------------------------------------------------------------------


def test_batch_sends_correct_body_and_returns_ack() -> None:
    with respx.mock:
        route = respx.post(f"{BASE}/events/batch").mock(
            return_value=httpx.Response(200, json=BATCH_ACK)
        )
        events = [
            {"type": "prompt", "actor": ACTOR, "payload": {"model": "m", "content": "hi"}},
            {"type": "completion", "actor": ACTOR, "payload": {"model": "m", "content": "bye"}},
        ]
        result = _client().batch("run_1", events)  # type: ignore[arg-type]

        assert result is not None
        assert result["run_id"] == "run_1"
        assert len(result["events"]) == 1  # BATCH_ACK has one event for simplicity

        import json

        sent = json.loads(route.calls[0].request.read())
        assert sent["run_id"] == "run_1"
        assert len(sent["events"]) == 2
        # run_id pinned on each event
        for e in sent["events"]:
            assert e["run_id"] == "run_1"


# ---------------------------------------------------------------------------
# verify()
# ---------------------------------------------------------------------------


def test_verify_sends_post_returns_result() -> None:
    with respx.mock:
        respx.post(f"{BASE}/runs/run_1/verify").mock(
            return_value=httpx.Response(200, json={"valid": True, "events_verified": 3})
        )
        result = _client().verify("run_1")
        assert result is not None
        assert result["valid"] is True
        assert result["events_verified"] == 3


# ---------------------------------------------------------------------------
# get_run()
# ---------------------------------------------------------------------------


def test_get_run_sends_get_returns_run() -> None:
    with respx.mock:
        run_data = {"id": "run_1", "status": "open", "agent_id": "agent_a"}
        respx.get(f"{BASE}/runs/run_1").mock(return_value=httpx.Response(200, json=run_data))
        result = _client().get_run("run_1")
        assert result is not None
        assert result["id"] == "run_1"
        assert result["status"] == "open"


# ---------------------------------------------------------------------------
# list_runs()
# ---------------------------------------------------------------------------


def test_list_runs_sends_get_with_query_params() -> None:
    with respx.mock:
        runs = [{"id": "run_1"}, {"id": "run_2"}]
        route = respx.get(f"{BASE}/runs").mock(return_value=httpx.Response(200, json=runs))
        result = _client().list_runs(agent_id="agent_search", status="open", limit=10)

        assert result is not None
        assert len(result) == 2

        params = dict(route.calls[0].request.url.params)
        assert params["agent_id"] == "agent_search"
        assert params["status"] == "open"
        assert params["limit"] == "10"


def test_list_runs_no_params() -> None:
    with respx.mock:
        respx.get(f"{BASE}/runs").mock(return_value=httpx.Response(200, json=[]))
        result = _client().list_runs()
        assert result is not None
        assert result == []


# ---------------------------------------------------------------------------
# get_events()
# ---------------------------------------------------------------------------


def test_get_events_sends_get_with_pagination() -> None:
    with respx.mock:
        events = [{"id": "evt_1", "seq": 1}, {"id": "evt_2", "seq": 2}]
        route = respx.get(f"{BASE}/runs/run_1/events").mock(
            return_value=httpx.Response(200, json=events)
        )
        result = _client().get_events("run_1", after_seq=0, limit=100)

        assert result is not None
        assert len(result) == 2

        params = dict(route.calls[0].request.url.params)
        assert params["after_seq"] == "0"
        assert params["limit"] == "100"


# ---------------------------------------------------------------------------
# export() and get_export()
# ---------------------------------------------------------------------------


def test_export_sends_post_with_format() -> None:
    with respx.mock:
        route = respx.post(f"{BASE}/runs/run_1/export").mock(
            return_value=httpx.Response(200, json={"export_id": "exp_1", "status": "queued"})
        )
        result = _client().export("run_1", format="jsonl")

        assert result is not None
        assert result["export_id"] == "exp_1"
        assert result["status"] == "queued"

        import json

        sent = json.loads(route.calls[0].request.read())
        assert sent["format"] == "jsonl"


def test_get_export_sends_get_returns_status() -> None:
    with respx.mock:
        respx.get(f"{BASE}/exports/exp_1").mock(
            return_value=httpx.Response(
                200,
                json={"export_id": "exp_1", "status": "done", "url": "https://example.com/export"},
            )
        )
        result = _client().get_export("exp_1")
        assert result is not None
        assert result["status"] == "done"
        assert "url" in result


# ---------------------------------------------------------------------------
# Auth header
# ---------------------------------------------------------------------------


def test_auth_header_is_bearer_token() -> None:
    with respx.mock:
        route = respx.post(f"{BASE}/events").mock(return_value=httpx.Response(200, json=EVENT_ACK))
        Client(api_key="al_test_mykey").event(
            run_id="run_1", type="tool_call", actor=ACTOR, payload={}
        )
        assert route.calls[0].request.headers["authorization"] == "Bearer al_test_mykey"


def test_auth_header_present_on_get_request() -> None:
    with respx.mock:
        route = respx.get(f"{BASE}/runs/run_1").mock(
            return_value=httpx.Response(200, json={"id": "run_1"})
        )
        Client(api_key="al_test_mykey").get_run("run_1")
        assert route.calls[0].request.headers["authorization"] == "Bearer al_test_mykey"


# ---------------------------------------------------------------------------
# X-Request-Id captured in APIError
# ---------------------------------------------------------------------------


def test_request_id_captured_in_api_error() -> None:
    with respx.mock:
        respx.post(f"{BASE}/events").mock(
            return_value=httpx.Response(
                400,
                headers={"X-Request-Id": "req_xyz"},
                json={"title": "Bad Request", "status": 400, "detail": "missing field"},
            )
        )
        with pytest.raises(APIError) as exc_info:
            _client().event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})
        assert exc_info.value.request_id == "req_xyz"
        assert exc_info.value.status == 400
        assert exc_info.value.problem is not None


# ---------------------------------------------------------------------------
# No-op mode
# ---------------------------------------------------------------------------


def test_noop_event_returns_none_no_http() -> None:
    with respx.mock:
        client = Client(api_key="key", enabled=False)
        result = client.event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})
        assert result is None
        assert len(respx.calls) == 0


def test_noop_batch_returns_none_no_http() -> None:
    with respx.mock:
        client = Client(api_key="key", enabled=False)
        result = client.batch("run_1", [])  # type: ignore[arg-type]
        assert result is None
        assert len(respx.calls) == 0


def test_noop_verify_returns_none_no_http() -> None:
    with respx.mock:
        client = Client(api_key="key", enabled=False)
        result = client.verify("run_1")
        assert result is None
        assert len(respx.calls) == 0


def test_noop_get_run_returns_none() -> None:
    with respx.mock:
        client = Client(api_key="key", enabled=False)
        result = client.get_run("run_1")
        assert result is None


def test_noop_list_runs_returns_none() -> None:
    with respx.mock:
        client = Client(api_key="key", enabled=False)
        result = client.list_runs()
        assert result is None


def test_noop_export_returns_none() -> None:
    with respx.mock:
        client = Client(api_key="key", enabled=False)
        result = client.export("run_1")
        assert result is None


# ---------------------------------------------------------------------------
# Env var fallbacks
# ---------------------------------------------------------------------------


def test_env_var_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    with respx.mock:
        monkeypatch.setenv("HASHLINE_API_KEY", "al_from_env")
        route = respx.post(f"{BASE}/events").mock(return_value=httpx.Response(200, json=EVENT_ACK))
        Client().event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})
        assert route.calls[0].request.headers["authorization"] == "Bearer al_from_env"


def test_env_var_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    with respx.mock:
        monkeypatch.setenv("HASHLINE_BASE_URL", "https://custom.example.com/v1")
        respx.post("https://custom.example.com/v1/events").mock(
            return_value=httpx.Response(200, json=EVENT_ACK)
        )
        Client(api_key="key").event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})
        # If we reach here without a respx.CallNotFound, the URL was correct.


def test_env_var_disabled(monkeypatch: pytest.MonkeyPatch) -> None:
    with respx.mock:
        monkeypatch.setenv("HASHLINE_DISABLED", "1")
        # No api_key needed when disabled
        client = Client()
        result = client.event(run_id="run_1", type="tool_call", actor=ACTOR, payload={})
        assert result is None
        assert not client.enabled


def test_env_var_disabled_true(monkeypatch: pytest.MonkeyPatch) -> None:
    with respx.mock:
        monkeypatch.setenv("HASHLINE_DISABLED", "true")
        client = Client()
        assert not client.enabled


def test_requires_api_key_when_enabled() -> None:
    with pytest.raises(ValidationError, match="api_key"):
        Client(enabled=True)
