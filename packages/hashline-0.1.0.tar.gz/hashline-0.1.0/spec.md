# Hashline Python SDK — Build Spec

**Purpose:** Build a Python SDK for the Hashline agent audit ledger API, mirroring the functionality of the existing TypeScript SDK at github.com/hashline-dev/sdk-js.

**Context:** Hashline is a hosted, append-only, tamper-evident audit log for AI agent workloads. The API is live at `https://api.hashline.dev`. The TypeScript SDK is published at `@hashline/sdk` on npm. This Python SDK must be wire-compatible with the same API.

---

## Reference material

Before writing any code, read the TypeScript SDK to understand the API surface, error handling, and design decisions:

- `src/` — Client class, types, error classes, retry logic
- `test/` — test patterns and assertions
- `examples/` — integration examples (Anthropic, OpenAI, Vercel AI SDK)
- `README.md` — public API documentation
- `MILESTONE_9_NOTES.md` — design decisions and deferred items

The Python SDK should feel native to Python developers — not a transliteration of TypeScript. Use Python idioms, type hints, naming conventions (snake_case), and packaging standards.

---

## Deliverables

```
hashline-python/
├── src/
│   └── hashline/
│       ├── __init__.py          # re-exports Client, errors, types
│       ├── client.py            # Client class
│       ├── types.py             # TypedDict / dataclass definitions
│       ├── errors.py            # HashlineError, APIError, ValidationError, NetworkError
│       └── _retry.py            # retry logic (internal)
├── tests/
│   ├── test_client.py
│   ├── test_validation.py
│   └── test_retry.py
├── examples/
│   ├── basic.py                 # standalone end-to-end example
│   ├── anthropic_tools.py       # Anthropic SDK with tool use
│   └── openai_tools.py          # OpenAI SDK with tool use
├── pyproject.toml               # PEP 621, build system, metadata
├── README.md
├── LICENSE                      # Apache-2.0
├── .gitignore
└── MILESTONE_PYTHON_SDK_NOTES.md
```

---

## Client API surface

Mirror the TypeScript SDK's public API, adapted to Python conventions:

```python
from hashline import Client

# Construction
client = Client(
    api_key="al_live_...",                          # required
    base_url="https://api.hashline.dev/v1",         # default
    enabled=True,                                    # False = no-op mode
    max_retries=3,                                   # default
    timeout=30.0,                                    # seconds, default
)

# Also reads from env vars if not passed:
#   HASHLINE_API_KEY  — api_key
#   HASHLINE_BASE_URL — base_url
#   HASHLINE_DISABLED=1 — sets enabled=False

# Single event
result = client.event(
    run_id="run_01HXYZ...",
    type="tool_call",
    actor={"type": "agent", "id": "search_agent"},
    payload={"name": "web_search", "arguments": {"q": "..."}, "call_id": "c1"},
    client_event_id="optional-idempotency-key",      # optional
    client_ts=1713456789000,                          # optional, unix ms
)
# Returns: {"id": "evt_...", "run_id": "run_...", "seq": 0, "hash": "sha256:..."}

# Batch (up to 500 events, same run, atomic)
results = client.batch("run_01HXYZ...", [
    {"type": "prompt", "actor": {"type": "agent", "id": "a"}, "payload": {"model": "m", "content": "..."}},
    {"type": "completion", "actor": {"type": "agent", "id": "a"}, "payload": {"model": "m", "content": "..."}},
])
# Returns: list of {"id", "run_id", "seq", "hash"} dicts

# Get run
run = client.get_run("run_01HXYZ...")

# List runs
runs = client.list_runs(agent_id="agent_search", status="open", limit=10)

# Get events for a run
events = client.get_events("run_01HXYZ...", after_seq=0, limit=100)

# Verify chain
verification = client.verify("run_01HXYZ...")
# Returns: {"valid": True, "events_verified": 50}
# or:      {"valid": False, "break_at_seq": 5, "reason": "prev_hash mismatch"}

# Request export
export = client.export("run_01HXYZ...", format="jsonl")
# Returns: {"export_id": "export_...", "status": "queued"}

# Poll export status
status = client.get_export("export_...")
# Returns: {"export_id": "...", "status": "done", "url": "https://..."}
```

### No-op mode

When `enabled=False` (or `HASHLINE_DISABLED=1` env var), every method returns `None` without making any network calls. No exceptions thrown. This lets developers leave Hashline wired in during local dev and CI without a running server.

### Async support

Provide an `AsyncClient` with the same API surface using `async/await`. Use `httpx` for both sync and async HTTP:

```python
from hashline import AsyncClient

client = AsyncClient(api_key="al_live_...")
result = await client.event(...)
```

Both `Client` and `AsyncClient` should share internal logic as much as possible. Don't duplicate the validation, retry, or serialization code.

---

## Error handling

Three error classes, all inheriting from a base `HashlineError`:

```python
class HashlineError(Exception):
    """Base class for all Hashline errors."""
    pass

class ValidationError(HashlineError):
    """Raised before any network call when input is obviously invalid."""
    pass

class APIError(HashlineError):
    """Raised on non-2xx responses from the API."""
    status: int
    request_id: str | None
    problem: dict | None    # parsed RFC 7807 body if available

    def __str__(self) -> str:
        return f"APIError(status={self.status}, request_id={self.request_id})"

class NetworkError(HashlineError):
    """Raised on transport failures (DNS, TCP, TLS, timeout)."""
    pass
```

### Validation rules (raise ValidationError before sending)

- `run_id` is required and must be a non-empty string.
- `type` is required and must be one of the defined EventType values.
- `actor` is required and must have `type` and `id` fields.
- `payload` is required (can be empty dict `{}`).
- Batch: all events must have the same `run_id`, max 500 events.
- Batch: `run_id` param must match every event's `run_id` if provided in events.

### Retry logic

Retry on: `408`, `429`, `5xx` status codes, and network errors (connection refused, DNS failure, timeout).

Do NOT retry on: `400`, `401`, `403`, `404`, `422` — these are permanent failures.

Retry strategy:
- Exponential backoff with full jitter.
- If `Retry-After` header is present, respect it (both delta-seconds and HTTP-date formats).
- Max retries configurable (default 3).
- Each retry logs a warning (using Python's `logging` module, logger name `hashline`).

---

## Dependencies

**Runtime:**
- `httpx` >= 0.27 — HTTP client (sync + async in one library, modern, well-maintained).

**No other runtime dependencies.** Keep the dependency tree minimal. This is a security product — every dependency is an attack surface.

**Dev dependencies:**
- `pytest` + `pytest-asyncio` — testing
- `respx` — httpx mock/stub library for tests
- `mypy` — type checking
- `ruff` — linting and formatting
- `build` — PEP 517 build

---

## Packaging (pyproject.toml)

```toml
[project]
name = "hashline"
version = "0.1.0"
description = "Python SDK for the Hashline agent audit ledger."
readme = "README.md"
license = {text = "Apache-2.0"}
requires-python = ">=3.10"
authors = [{name = "Nikola Medjugorac", email = "nikola@hashline.dev"}]
keywords = ["audit", "logging", "ai", "agents", "hashline", "observability"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: Apache Software License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Typing :: Typed",
]
dependencies = ["httpx>=0.27"]

[project.urls]
Homepage = "https://hashline.dev"
Documentation = "https://hashline.dev"
Repository = "https://github.com/hashline-dev/sdk-python"
Issues = "https://github.com/hashline-dev/sdk-python/issues"
Changelog = "https://github.com/hashline-dev/sdk-python/releases"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/hashline"]

[tool.mypy]
strict = true

[tool.ruff]
target-version = "py310"
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "I", "UP", "B", "SIM", "TCH"]

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
```

---

## Tests

Use `pytest` + `respx` (httpx mocking). Test against mocked HTTP responses, NOT the live API.

### Required test coverage:

**test_client.py:**
- `event()` sends correct POST body, returns parsed response.
- `batch()` sends correct POST body with all events, returns list.
- `verify()` sends POST, returns parsed verification result.
- `get_run()` sends GET, returns run dict.
- `list_runs()` sends GET with query params, returns list.
- `get_events()` sends GET with pagination params, returns list.
- `export()` sends POST, returns export dict.
- `get_export()` sends GET, returns status dict.
- Auth header is `Bearer <api_key>` on every request.
- `X-Request-Id` is logged/accessible from responses if present.
- No-op mode: every method returns None, no HTTP calls made.
- Env var fallback: `HASHLINE_API_KEY`, `HASHLINE_BASE_URL`, `HASHLINE_DISABLED`.

**test_validation.py:**
- Missing `run_id` raises `ValidationError`.
- Missing `type` raises `ValidationError`.
- Missing `actor` raises `ValidationError`.
- Invalid `type` value raises `ValidationError`.
- Batch > 500 events raises `ValidationError`.
- Batch with mixed `run_id` values raises `ValidationError`.
- Empty batch raises `ValidationError`.

**test_retry.py:**
- 429 response is retried, succeeds on retry.
- 500 response is retried, succeeds on retry.
- 401 response is NOT retried (immediate APIError).
- Network error (connection refused) is retried.
- `Retry-After` header is respected (mock time or assert delay).
- Max retries exhausted raises the final error.
- Retries use exponential backoff (assert increasing delays).

**test_async.py:**
- `AsyncClient.event()` works with `await`.
- `AsyncClient.batch()` works with `await`.
- Async no-op mode returns None.

Target: 40+ tests. All must pass with `pytest`.

---

## Examples

### examples/basic.py

End-to-end: create a run, emit 5 events, verify chain, request export. Self-contained, runnable with:

```bash
HASHLINE_API_KEY=al_live_... python examples/basic.py
```

By default connects to `https://api.hashline.dev/v1`. Override with `HASHLINE_BASE_URL` for local dev.

### examples/anthropic_tools.py

Shows how to wire Hashline into an Anthropic SDK tool-use loop. Every prompt, completion, tool_call, and tool_result logged. Requires `ANTHROPIC_API_KEY` and `HASHLINE_API_KEY`.

### examples/openai_tools.py

Same pattern with the OpenAI SDK. Requires `OPENAI_API_KEY` and `HASHLINE_API_KEY`.

Example header format (no internal references, no milestone numbers):

```python
"""
examples/basic.py — End-to-end example for the Hashline Python SDK.

Emits a run_started, tool_call/tool_result pair, and run_ended,
then verifies the chain.

Usage:
    HASHLINE_API_KEY=al_live_... python examples/basic.py

By default connects to https://api.hashline.dev/v1.
For local dev: HASHLINE_BASE_URL=http://localhost:8787/v1 python examples/basic.py
"""
```

---

## README.md

Mirror the TypeScript SDK README structure:

1. Package name + one-line description.
2. Install: `pip install hashline`
3. Quick start (5-line example).
4. Async usage.
5. Behaviour (auto-retry, no-op mode, validation, typed errors).
6. Security notes (no PII scrubbing, backend-only, rotate keys).
7. Examples section linking to each file.
8. Development (install, test, type-check, lint).
9. License: Apache-2.0.

---

## What NOT to build

- No CLI tool.
- No framework-specific integration packages (no `hashline-langchain`, no `hashline-crewai`).
- No async-only design — sync Client is the primary, AsyncClient is secondary.
- No dashboard or UI.
- No hash chain verification logic client-side — the server does this.
- No automatic PII scrubbing.
- No automatic instrumentation / monkey-patching. Always explicit `client.event()` calls.
- No `setup.cfg` or `setup.py` — pyproject.toml only.

---

## Verification

Exit criteria:

```bash
# Type check
mypy src/hashline

# Lint
ruff check .

# Format check
ruff format --check .

# Tests
pytest -v

# Build
python -m build

# Verify the built package installs cleanly
pip install dist/hashline-0.1.0-py3-none-any.whl --force-reinstall
python -c "from hashline import Client; print('ok')"
```

All must pass. Report results in MILESTONE_PYTHON_SDK_NOTES.md.

---

## After verification

Do NOT publish to PyPI from Claude Code. The operator will:

1. Review the code.
2. Create the `hashline` project on PyPI.
3. Publish manually with `python -m twine upload dist/*`.

---

## Working agreement

- Read the TypeScript SDK first. Understand its design, then write idiomatic Python — not a port.
- If any requirement is ambiguous, flag it in MILESTONE_PYTHON_SDK_NOTES.md.
- No runtime dependencies beyond httpx. If you think you need another dependency, stop and ask.
- Every public function and class has a docstring.
- Every module has a module-level docstring.
- Type hints on every function signature. `mypy --strict` must pass.
- Use `logging.getLogger("hashline")` for all log output. Never print().
- Snake_case for everything. No camelCase leaking from the TypeScript SDK.
- Keep the API field names as-is from the HTTP API (run_id, client_event_id, etc.) — they're already snake_case in the wire format.
