"""
examples/openai_tools.py — OpenAI SDK tool-use loop with Hashline audit logging.

Demonstrates logging run_started, prompt, completion, tool_call, tool_result,
and run_ended for every step in an OpenAI tool-use conversation.

Usage:
    HASHLINE_API_KEY=al_live_... OPENAI_API_KEY=sk-... python examples/openai_tools.py

By default connects to https://api.hashline.dev/v1.
For local dev: HASHLINE_BASE_URL=http://localhost:8787/v1 python examples/openai_tools.py
"""

from __future__ import annotations

import json
import os
import sys
import time
from typing import Any

try:
    import openai
except ImportError:
    print("openai package is required: pip install openai", file=sys.stderr)
    sys.exit(1)

from hashline import Client

hashline_key = os.environ.get("HASHLINE_API_KEY")
openai_key = os.environ.get("OPENAI_API_KEY")
base_url = os.environ.get("HASHLINE_BASE_URL", "https://api.hashline.dev/v1")

if not hashline_key:
    print("HASHLINE_API_KEY is required", file=sys.stderr)
    sys.exit(1)
if not openai_key:
    print("OPENAI_API_KEY is required", file=sys.stderr)
    sys.exit(1)

hashline = Client(api_key=hashline_key, base_url=base_url)
oai = openai.OpenAI(api_key=openai_key)

run_id = f"run_{int(time.time() * 1000):X}"
agent = {"type": "agent", "id": "openai-demo"}
system_actor = {"type": "system", "id": "runner"}

MODEL = "gpt-4o-mini"

TOOLS: list[Any] = [
    {
        "type": "function",
        "function": {
            "name": "add",
            "description": "Add two numbers and return the sum.",
            "parameters": {
                "type": "object",
                "properties": {
                    "a": {"type": "number"},
                    "b": {"type": "number"},
                },
                "required": ["a", "b"],
            },
        },
    },
]


def main() -> None:
    print(f"[example] run_id = {run_id}")

    hashline.event(
        run_id=run_id,
        type="run_started",
        actor=system_actor,
        payload={"agent": "openai-demo"},
    )
    print("sent: run_started")

    messages: list[Any] = [
        {"role": "user", "content": "What is 1234 + 5678? Use the add function."},
    ]

    hashline.event(
        run_id=run_id,
        type="prompt",
        actor=agent,
        payload={"model": MODEL, "messages": messages},
    )
    print("sent: prompt")

    while True:
        response = oai.chat.completions.create(
            model=MODEL,
            tools=TOOLS,
            messages=messages,
        )
        msg = response.choices[0].message

        hashline.event(
            run_id=run_id,
            type="completion",
            actor=agent,
            payload={
                "model": response.model,
                "message": msg.model_dump(),
                "finish_reason": response.choices[0].finish_reason,
            },
        )
        print("sent: completion")

        if not msg.tool_calls:
            break

        messages.append(msg)  # type: ignore[arg-type]

        for tc in msg.tool_calls:
            args = json.loads(tc.function.arguments)

            hashline.event(
                run_id=run_id,
                type="tool_call",
                actor=agent,
                payload={
                    "name": tc.function.name,
                    "arguments": args,
                    "call_id": tc.id,
                },
            )
            print(f"sent: tool_call ({tc.function.name})")

            result = float(args["a"]) + float(args["b"])

            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": str(result),
                }
            )

            hashline.event(
                run_id=run_id,
                type="tool_result",
                actor=agent,
                payload={"call_id": tc.id, "result": result, "status": "ok"},
            )
            print("sent: tool_result")

    hashline.event(
        run_id=run_id,
        type="run_ended",
        actor=system_actor,
        payload={"outcome": "success"},
    )
    print("sent: run_ended")

    verify = hashline.verify(run_id)
    print(f"verify: {verify}")
    if verify and verify.get("valid"):
        print("[example] OK — chain is valid.")
    else:
        print("[example] chain verification failed", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
