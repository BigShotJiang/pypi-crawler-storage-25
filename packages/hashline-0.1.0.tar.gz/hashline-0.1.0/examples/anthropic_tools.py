"""
examples/anthropic_tools.py — Anthropic SDK tool-use loop with Hashline audit logging.

Demonstrates logging run_started, prompt, completion, tool_call, tool_result,
and run_ended for every step in an Anthropic tool-use conversation.

Usage:
    HASHLINE_API_KEY=al_live_... ANTHROPIC_API_KEY=sk-ant-... python examples/anthropic_tools.py

By default connects to https://api.hashline.dev/v1.
For local dev: HASHLINE_BASE_URL=http://localhost:8787/v1 python examples/anthropic_tools.py
"""

from __future__ import annotations

import os
import sys
import time

try:
    import anthropic
except ImportError:
    print("anthropic package is required: pip install anthropic", file=sys.stderr)
    sys.exit(1)

from hashline import Client

hashline_key = os.environ.get("HASHLINE_API_KEY")
anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
base_url = os.environ.get("HASHLINE_BASE_URL", "https://api.hashline.dev/v1")

if not hashline_key:
    print("HASHLINE_API_KEY is required", file=sys.stderr)
    sys.exit(1)
if not anthropic_key:
    print("ANTHROPIC_API_KEY is required", file=sys.stderr)
    sys.exit(1)

hashline = Client(api_key=hashline_key, base_url=base_url)
anth = anthropic.Anthropic(api_key=anthropic_key)

run_id = f"run_{int(time.time() * 1000):X}"
agent = {"type": "agent", "id": "anthropic-demo"}
system_actor = {"type": "system", "id": "runner"}

MODEL = "claude-haiku-4-5-20251001"

TOOLS: list[anthropic.types.ToolParam] = [
    {
        "name": "add",
        "description": "Add two numbers and return the sum.",
        "input_schema": {
            "type": "object",
            "properties": {
                "a": {"type": "number"},
                "b": {"type": "number"},
            },
            "required": ["a", "b"],
        },
    },
]


def main() -> None:
    print(f"[example] run_id = {run_id}")

    hashline.event(
        run_id=run_id,
        type="run_started",
        actor=system_actor,
        payload={"agent": "anthropic-demo"},
    )
    print("sent: run_started")

    messages: list[anthropic.types.MessageParam] = [
        {"role": "user", "content": "What is 1234 + 5678? Use the add tool."},
    ]

    hashline.event(
        run_id=run_id,
        type="prompt",
        actor=agent,
        payload={"model": MODEL, "messages": messages},
    )
    print("sent: prompt")

    while True:
        response = anth.messages.create(
            model=MODEL,
            max_tokens=1024,
            tools=TOOLS,
            messages=messages,
        )

        hashline.event(
            run_id=run_id,
            type="completion",
            actor=agent,
            payload={
                "model": response.model,
                "content": [b.model_dump() for b in response.content],
                "stop_reason": response.stop_reason,
            },
        )
        print("sent: completion")

        if response.stop_reason != "tool_use":
            break

        messages.append({"role": "assistant", "content": response.content})  # type: ignore[arg-type]
        tool_results: list[anthropic.types.ToolResultBlockParam] = []

        for block in response.content:
            if block.type != "tool_use":
                continue

            hashline.event(
                run_id=run_id,
                type="tool_call",
                actor=agent,
                payload={
                    "name": block.name,
                    "arguments": block.input,
                    "call_id": block.id,
                },
            )
            print(f"sent: tool_call ({block.name})")

            args = block.input  # type: ignore[union-attr]
            result = float(args["a"]) + float(args["b"])  # type: ignore[index]

            tool_results.append(
                {
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": str(result),
                }
            )

            hashline.event(
                run_id=run_id,
                type="tool_result",
                actor=agent,
                payload={"call_id": block.id, "result": result, "status": "ok"},
            )
            print("sent: tool_result")

        messages.append({"role": "user", "content": tool_results})

    hashline.event(
        run_id=run_id,
        type="run_ended",
        actor=system_actor,
        payload={"outcome": "success"},
    )
    print("sent: run_ended")

    verify = hashline.verify(run_id)
    print(f"verify: {verify}")
    if verify and verify.get("valid"):
        print("[example] OK — chain is valid.")
    else:
        print("[example] chain verification failed", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
