"""
examples/basic.py — End-to-end example for the Hashline Python SDK.

Emits a run_started, a tool_call/tool_result batch, and a run_ended,
then verifies the chain and requests an export.

Usage:
    HASHLINE_API_KEY=al_live_... python examples/basic.py

By default connects to https://api.hashline.dev/v1.
For local dev: HASHLINE_BASE_URL=http://localhost:8787/v1 python examples/basic.py
"""

from __future__ import annotations

import os
import sys
import time

from hashline import Client

api_key = os.environ.get("HASHLINE_API_KEY")
base_url = os.environ.get("HASHLINE_BASE_URL", "https://api.hashline.dev/v1")

if not api_key:
    print("HASHLINE_API_KEY env var is required", file=sys.stderr)
    sys.exit(1)

run_id = f"run_{int(time.time() * 1000):X}"
client = Client(api_key=api_key, base_url=base_url)

system = {"type": "system", "id": "example-runner"}
agent = {"type": "agent", "id": "example-agent"}


def main() -> None:
    print(f"[example] run_id = {run_id}")
    print(f"[example] base_url = {base_url}")

    started = client.event(
        run_id=run_id,
        type="run_started",
        actor=system,
        payload={"agent": "example-agent", "version": "0.1.0"},
    )
    print(f"[example] seq={started['seq']} run_started hash={started['hash']}")

    call_id = f"call_{int(time.time() * 1000)}"
    batch_ack = client.batch(
        run_id,
        [
            {
                "type": "tool_call",
                "actor": agent,
                "payload": {
                    "name": "web_search",
                    "arguments": {"q": "hashline audit ledger"},
                    "call_id": call_id,
                },
            },
            {
                "type": "tool_result",
                "actor": agent,
                "payload": {
                    "call_id": call_id,
                    "status": "ok",
                    "result": {"hits": 3},
                    "duration_ms": 42,
                },
            },
        ],
    )
    last_hash = batch_ack["events"][-1]["hash"] if batch_ack else "?"
    event_count = len(batch_ack["events"]) if batch_ack else 0
    print(f"[example] batch ack: {event_count} events, last hash={last_hash}")

    ended = client.event(
        run_id=run_id,
        type="run_ended",
        actor=system,
        payload={"outcome": "success"},
    )
    print(f"[example] seq={ended['seq']} run_ended hash={ended['hash']}")

    verify = client.verify(run_id)
    print(f"[example] verify: {verify}")
    if verify and not verify.get("valid"):
        print(
            f"[example] chain invalid: break_at_seq={verify.get('break_at_seq')} "
            f"reason={verify.get('reason')}",
            file=sys.stderr,
        )
        sys.exit(1)

    print("[example] OK — chain is valid.")

    export = client.export(run_id, format="jsonl")
    print(f"[example] export queued: {export}")


if __name__ == "__main__":
    main()
