"""Error hierarchy surfaced by the Hashline SDK."""

from __future__ import annotations

from typing import Any


class HashlineError(Exception):
    """Base class for all errors thrown by the Hashline SDK."""


class ValidationError(HashlineError):
    """Raised when input is invalid before any network call is made.

    These are callsite bugs; they are never retried.
    """


class APIError(HashlineError):
    """Raised on non-2xx HTTP responses from the Hashline API.

    ``problem`` carries the RFC 7807 body when the server returned one.
    ``retryable`` is True for 408/429/5xx — the SDK may have already retried
    before raising; the flag lets callers decide whether to try again later.
    """

    status: int
    request_id: str | None
    problem: dict[str, Any] | None
    retryable: bool

    def __init__(
        self,
        message: str,
        *,
        status: int,
        request_id: str | None = None,
        problem: dict[str, Any] | None = None,
        retryable: bool = False,
    ) -> None:
        """Initialise an APIError with HTTP metadata."""
        super().__init__(message)
        self.status = status
        self.request_id = request_id
        self.problem = problem
        self.retryable = retryable

    def __str__(self) -> str:
        """Return a concise string representation."""
        return f"APIError(status={self.status}, request_id={self.request_id})"


class NetworkError(HashlineError):
    """Raised on transport failures: DNS, TCP, TLS, or timeout.

    The SDK retries these internally up to ``max_retries`` before raising.
    """

    def __init__(self, message: str, cause: BaseException | None = None) -> None:
        """Initialise a NetworkError, optionally chaining the original cause."""
        super().__init__(message)
        if cause is not None:
            self.__cause__ = cause
