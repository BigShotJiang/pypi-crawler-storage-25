"""Wire types for the Hashline audit ledger API."""

from __future__ import annotations

from typing import Any, Literal, NotRequired, TypedDict, get_args

EventType = Literal[
    "run_started",
    "run_ended",
    "prompt",
    "completion",
    "tool_call",
    "tool_result",
    "decision",
    "human_approval_requested",
    "human_approval_granted",
    "human_approval_denied",
    "error",
    "annotation",
]

ActorType = Literal["agent", "human", "system"]

VALID_EVENT_TYPES: frozenset[str] = frozenset(get_args(EventType))
VALID_ACTOR_TYPES: frozenset[str] = frozenset(get_args(ActorType))


class Actor(TypedDict):
    """Actor performing or initiating an event."""

    type: ActorType
    id: str
    principal: NotRequired[str]


class BatchEventInput(TypedDict):
    """Input for a single event within a batch call.

    run_id is supplied once at the batch level, not per event.
    """

    type: EventType
    actor: Actor
    payload: Any
    client_ts: NotRequired[int]
    client_event_id: NotRequired[str]


class EventInput(TypedDict):
    """Input for a single event call."""

    run_id: str
    type: EventType
    actor: Actor
    payload: Any
    client_ts: NotRequired[int]
    client_event_id: NotRequired[str]


class EventAck(TypedDict):
    """Server acknowledgement for a single appended event."""

    id: str
    run_id: str
    seq: int
    hash: str


class BatchAck(TypedDict):
    """Server acknowledgement for a batch of appended events."""

    run_id: str
    events: list[EventAck]


class ProblemJson(TypedDict, total=False):
    """RFC 7807 problem+json body as returned by the Hashline API."""

    type: str
    title: str
    status: int
    detail: str
    instance: str
