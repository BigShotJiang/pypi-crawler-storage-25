"""Hashline SDK client — sync and async implementations."""

from __future__ import annotations

import asyncio
import logging
import os
import random as _random_mod
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

import httpx

from ._retry import compute_backoff_ms, is_retryable_status, parse_retry_after_ms
from .errors import APIError, NetworkError, ValidationError
from .types import (
    VALID_ACTOR_TYPES,
    VALID_EVENT_TYPES,
    BatchAck,
    BatchEventInput,
    EventAck,
)

_log = logging.getLogger("hashline")

DEFAULT_BASE_URL = "https://api.hashline.dev/v1"
MAX_BATCH_SIZE = 500
_SDK_VERSION = "0.1.0"


# ---------------------------------------------------------------------------
# Input validation helpers
# ---------------------------------------------------------------------------


def _read_env_flag(name: str) -> bool:
    """Return True when an env var is set to a truthy value (1, true, yes)."""
    val = os.environ.get(name, "").lower()
    return val in {"1", "true", "yes"}


def _validate_actor(actor: object, prefix: str = "") -> None:
    """Raise ValidationError when actor is missing required fields."""
    loc = f"{prefix}actor" if not prefix else f"{prefix}"
    if not isinstance(actor, dict):
        raise ValidationError(f"{loc} must be a dict with 'type' and 'id' fields")
    actor_type = actor.get("type")
    if not actor_type:
        raise ValidationError(f"{loc}.type is required")
    if actor_type not in VALID_ACTOR_TYPES:
        raise ValidationError(
            f"{loc}.type must be one of {sorted(VALID_ACTOR_TYPES)}, got {actor_type!r}"
        )
    actor_id = actor.get("id")
    if not actor_id or not isinstance(actor_id, str):
        raise ValidationError(f"{loc}.id is required and must be a non-empty string")


def _validate_event_args(
    run_id: str,
    type: str,  # noqa: A002
    actor: object,
    payload: object,
) -> None:
    """Raise ValidationError for invalid event arguments."""
    if not run_id or not isinstance(run_id, str):
        raise ValidationError("run_id is required and must be a non-empty string")
    if not type or type not in VALID_EVENT_TYPES:
        raise ValidationError(f"type must be one of {sorted(VALID_EVENT_TYPES)}, got {type!r}")
    _validate_actor(actor)
    # payload presence is guaranteed by the function signature; we only check
    # batch event dicts (via _validate_batch_event) where it may be absent.


def _validate_batch_event(event: Any, run_id: str, index: int) -> None:
    """Raise ValidationError for an invalid batch event dict."""
    if not isinstance(event, dict):
        raise ValidationError(f"event at index {index} must be a dict")
    if "run_id" in event and event["run_id"] != run_id:
        raise ValidationError(f"event at index {index}: run_id conflicts with batch run_id")
    if "payload" not in event:
        raise ValidationError(f"event at index {index}: payload is required")
    _validate_event_args(
        run_id=run_id,
        type=event.get("type", ""),
        actor=event.get("actor"),
        payload=event.get("payload"),
    )


def _validate_batch(run_id: str, events: list[Any]) -> None:
    """Raise ValidationError for an invalid batch."""
    if not run_id or not isinstance(run_id, str):
        raise ValidationError("run_id is required and must be a non-empty string")
    if not isinstance(events, list) or len(events) == 0:
        raise ValidationError("batch must contain at least one event")
    if len(events) > MAX_BATCH_SIZE:
        raise ValidationError(f"batch size {len(events)} exceeds limit of {MAX_BATCH_SIZE}")
    for i, event in enumerate(events):
        _validate_batch_event(event, run_id, i)


# ---------------------------------------------------------------------------
# Shared core
# ---------------------------------------------------------------------------


class _ClientCore:
    """Shared initialisation and HTTP helpers for Client and AsyncClient."""

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        enabled: bool | None = None,
        max_retries: int = 3,
        timeout: float = 30.0,
        _random_fn: Callable[[], float] | None = None,
        _now_fn: Callable[[], float] | None = None,
    ) -> None:
        """Initialise shared client state from explicit args and env vars."""
        env_disabled = _read_env_flag("HASHLINE_DISABLED")
        if enabled is None:
            enabled = not env_disabled

        if api_key is None:
            api_key = os.environ.get("HASHLINE_API_KEY") or ""

        if base_url is None:
            base_url = os.environ.get("HASHLINE_BASE_URL") or DEFAULT_BASE_URL

        if enabled and not api_key:
            raise ValidationError(
                "api_key is required when enabled=True. Pass api_key= or set HASHLINE_API_KEY."
            )

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._enabled = enabled
        self._max_retries = max_retries
        self._timeout = timeout
        self._random_fn: Callable[[], float] = _random_fn or _random_mod.random
        self._now_fn: Callable[[], float] = _now_fn or (lambda: time.time() * 1000.0)

    @property
    def enabled(self) -> bool:
        """Whether telemetry is enabled for this client instance."""
        return self._enabled

    def _make_url(self, path: str) -> str:
        """Build an absolute URL for the given API path."""
        return f"{self._base_url}{path}"

    def _make_headers(self, *, with_body: bool = True) -> dict[str, str]:
        """Build the standard request headers."""
        headers: dict[str, str] = {
            "Authorization": f"Bearer {self._api_key}",
            "Accept": "application/json",
            "User-Agent": f"hashline-sdk-python/{_SDK_VERSION}",
        }
        if with_body:
            headers["Content-Type"] = "application/json; charset=utf-8"
        return headers

    def _parse_api_error(self, response: httpx.Response) -> APIError:
        """Build an APIError from a non-2xx httpx response."""
        request_id = response.headers.get("x-request-id")
        problem: dict[str, Any] | None = None
        message = f"HTTP {response.status_code}"
        try:
            text = response.text
            if text:
                try:
                    parsed: Any = response.json()
                    if isinstance(parsed, dict):
                        problem = parsed
                        title: Any = parsed.get("title")
                        detail: Any = parsed.get("detail")
                        if title:
                            message = str(title)
                        if detail:
                            message = f"{message}: {detail}"
                    else:
                        message = f"{message}: {text}"
                except Exception:
                    message = f"{message}: {text}"
        except Exception:
            pass
        return APIError(
            message,
            status=response.status_code,
            request_id=request_id,
            problem=problem,
            retryable=is_retryable_status(response.status_code),
        )

    def _next_delay_s(self, attempt: int, retry_after_ms: float | None) -> float:
        """Return the delay in seconds before the next retry attempt."""
        if retry_after_ms is not None:
            return retry_after_ms / 1000.0
        return compute_backoff_ms(attempt, random_fn=self._random_fn) / 1000.0

    def _event_body(
        self,
        run_id: str,
        event_type: str,
        actor: dict[str, Any],
        payload: Any,
        client_event_id: str | None,
        client_ts: int | None,
    ) -> dict[str, Any]:
        """Build the JSON body for a single event POST."""
        body: dict[str, Any] = {
            "run_id": run_id,
            "type": event_type,
            "actor": actor,
            "payload": payload,
        }
        if client_event_id is not None:
            body["client_event_id"] = client_event_id
        if client_ts is not None:
            body["client_ts"] = client_ts
        return body

    def _batch_body(self, run_id: str, events: list[BatchEventInput]) -> dict[str, Any]:
        """Build the JSON body for a batch POST, pinning run_id on each event."""
        return {
            "run_id": run_id,
            "events": [{**e, "run_id": run_id} for e in events],
        }

    def _list_runs_params(
        self,
        agent_id: str | None,
        status: str | None,
        limit: int | None,
    ) -> dict[str, str | int] | None:
        """Build query params for list_runs."""
        params: dict[str, str | int] = {}
        if agent_id is not None:
            params["agent_id"] = agent_id
        if status is not None:
            params["status"] = status
        if limit is not None:
            params["limit"] = limit
        return params or None

    def _get_events_params(
        self,
        after_seq: int | None,
        limit: int | None,
    ) -> dict[str, str | int] | None:
        """Build query params for get_events."""
        params: dict[str, str | int] = {}
        if after_seq is not None:
            params["after_seq"] = after_seq
        if limit is not None:
            params["limit"] = limit
        return params or None


# ---------------------------------------------------------------------------
# Synchronous client
# ---------------------------------------------------------------------------


class Client(_ClientCore):
    """Synchronous client for the Hashline agent audit ledger.

    Construction does not make any network calls. All methods are safe to call
    concurrently from multiple threads; httpx.Client is thread-safe.

    When ``enabled`` is False every method is a silent no-op returning ``None``.
    Use this in tests and local dev without needing a running server.

    Usage::

        client = Client(api_key="al_live_...")
        ack = client.event(
            run_id="run_...",
            type="tool_call",
            actor={"type": "agent", "id": "my-agent"},
            payload={"name": "web_search", "arguments": {"q": "..."}},
        )
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        enabled: bool | None = None,
        max_retries: int = 3,
        timeout: float = 30.0,
        _random_fn: Callable[[], float] | None = None,
        _now_fn: Callable[[], float] | None = None,
    ) -> None:
        """Create a synchronous Hashline client.

        Args:
            api_key: API key with events:write scope. Falls back to
                ``HASHLINE_API_KEY`` env var.
            base_url: Override the default API base URL. Falls back to
                ``HASHLINE_BASE_URL`` env var.
            enabled: Master switch. ``False`` makes every method a no-op.
                Defaults to ``False`` when ``HASHLINE_DISABLED=1`` is set.
            max_retries: Maximum retry attempts after the first try. Default 3.
            timeout: Per-attempt timeout in seconds. Default 30.
            _random_fn: Injected RNG for deterministic tests.
            _now_fn: Injected clock (returns Unix ms) for Retry-After tests.
        """
        super().__init__(
            api_key,
            base_url=base_url,
            enabled=enabled,
            max_retries=max_retries,
            timeout=timeout,
            _random_fn=_random_fn,
            _now_fn=_now_fn,
        )
        self._http = httpx.Client(timeout=self._timeout)

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> Client:
        """Support use as a context manager."""
        return self

    def __exit__(self, *args: object) -> None:
        """Close the client on context manager exit."""
        self.close()

    def _request(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        params: dict[str, str | int] | None = None,
    ) -> Any:
        """Execute an HTTP request with retries.

        Retries on 408, 429, 5xx, and transport errors using exponential
        backoff with full jitter. Respects ``Retry-After`` headers.
        Each attempt has an independent timeout of ``self._timeout`` seconds.
        """
        url = self._make_url(path)
        headers = self._make_headers(with_body=body is not None)

        for attempt in range(self._max_retries + 1):
            try:
                response = self._http.request(
                    method,
                    url,
                    headers=headers,
                    json=body,
                    params=params,
                )
                if response.is_success:
                    return response.json()

                err = self._parse_api_error(response)
                if not err.retryable or attempt == self._max_retries:
                    raise err

                retry_after_ms = parse_retry_after_ms(
                    response.headers.get("retry-after"), self._now_fn()
                )
                delay = self._next_delay_s(attempt, retry_after_ms)
                _log.warning(
                    "hashline: HTTP %d, retrying (attempt %d/%d) in %.2fs",
                    err.status,
                    attempt + 1,
                    self._max_retries,
                    delay,
                )
                time.sleep(delay)

            except APIError:
                raise
            except httpx.TransportError as exc:
                if attempt == self._max_retries:
                    raise NetworkError(f"network request failed: {exc}", exc) from exc
                delay = self._next_delay_s(attempt, None)
                _log.warning(
                    "hashline: transport error (attempt %d/%d): %s, retrying in %.2fs",
                    attempt + 1,
                    self._max_retries,
                    exc,
                    delay,
                )
                time.sleep(delay)

        # Unreachable: loop always returns or raises before exhausting.
        raise NetworkError("retry loop exhausted")

    def event(
        self,
        *,
        run_id: str,
        type: str,  # noqa: A002
        actor: dict[str, Any],
        payload: Any,
        client_event_id: str | None = None,
        client_ts: int | None = None,
    ) -> EventAck | None:
        """Append a single event to a run.

        Returns the server acknowledgement, or ``None`` when the client is
        disabled. Raises ``ValidationError`` for bad input before any I/O.
        """
        if not self._enabled:
            return None
        _validate_event_args(run_id=run_id, type=type, actor=actor, payload=payload)
        body = self._event_body(run_id, type, actor, payload, client_event_id, client_ts)
        result: EventAck = self._request("POST", "/events", body=body)
        return result

    def batch(
        self,
        run_id: str,
        events: list[BatchEventInput],
    ) -> BatchAck | None:
        """Append up to MAX_BATCH_SIZE events to a single run atomically.

        All events are appended in array order; the server assigns ``seq``
        in that order. Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        _validate_batch(run_id, events)
        body = self._batch_body(run_id, events)
        result: BatchAck = self._request("POST", "/events/batch", body=body)
        return result

    def get_run(self, run_id: str) -> dict[str, Any] | None:
        """Retrieve a run by ID.

        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        if not run_id:
            raise ValidationError("run_id is required")
        result: dict[str, Any] = self._request("GET", f"/runs/{run_id}")
        return result

    def list_runs(
        self,
        *,
        agent_id: str | None = None,
        status: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]] | None:
        """List runs, optionally filtered by agent_id, status, and limit.

        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        params = self._list_runs_params(agent_id, status, limit)
        result: list[dict[str, Any]] = self._request("GET", "/runs", params=params)
        return result

    def get_events(
        self,
        run_id: str,
        *,
        after_seq: int | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]] | None:
        """Retrieve events for a run, with optional pagination.

        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        if not run_id:
            raise ValidationError("run_id is required")
        params = self._get_events_params(after_seq, limit)
        result: list[dict[str, Any]] = self._request("GET", f"/runs/{run_id}/events", params=params)
        return result

    def verify(self, run_id: str) -> dict[str, Any] | None:
        """Request server-side hash-chain verification for a run.

        Returns ``{"valid": True, "events_verified": N}`` on success,
        or ``{"valid": False, "break_at_seq": N, "reason": "..."}`` on failure.
        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        if not run_id:
            raise ValidationError("run_id is required")
        result: dict[str, Any] = self._request("POST", f"/runs/{run_id}/verify")
        return result

    def export(
        self,
        run_id: str,
        *,
        format: str = "jsonl",  # noqa: A002
    ) -> dict[str, Any] | None:
        """Request an export of a run.

        Returns ``{"export_id": "...", "status": "queued"}`` immediately.
        Poll with ``get_export()`` until ``status == "done"``.
        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        if not run_id:
            raise ValidationError("run_id is required")
        result: dict[str, Any] = self._request(
            "POST", f"/runs/{run_id}/export", body={"format": format}
        )
        return result

    def get_export(self, export_id: str) -> dict[str, Any] | None:
        """Poll the status of an export.

        Returns ``{"export_id": "...", "status": "done", "url": "..."}`` when
        complete. Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        if not export_id:
            raise ValidationError("export_id is required")
        result: dict[str, Any] = self._request("GET", f"/exports/{export_id}")
        return result


# ---------------------------------------------------------------------------
# Asynchronous client
# ---------------------------------------------------------------------------


class AsyncClient(_ClientCore):
    """Asynchronous client for the Hashline agent audit ledger.

    Mirrors the ``Client`` API surface with ``async/await``. Uses
    ``httpx.AsyncClient`` for non-blocking I/O; safe to use in any asyncio
    event loop.

    When ``enabled`` is False every method is a silent no-op returning ``None``.

    Usage::

        client = AsyncClient(api_key="al_live_...")
        ack = await client.event(
            run_id="run_...",
            type="tool_call",
            actor={"type": "agent", "id": "my-agent"},
            payload={"name": "web_search", "arguments": {"q": "..."}},
        )
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        enabled: bool | None = None,
        max_retries: int = 3,
        timeout: float = 30.0,
        _random_fn: Callable[[], float] | None = None,
        _now_fn: Callable[[], float] | None = None,
    ) -> None:
        """Create an asynchronous Hashline client.

        Args:
            api_key: API key with events:write scope. Falls back to
                ``HASHLINE_API_KEY`` env var.
            base_url: Override the default API base URL. Falls back to
                ``HASHLINE_BASE_URL`` env var.
            enabled: Master switch. ``False`` makes every method a no-op.
                Defaults to ``False`` when ``HASHLINE_DISABLED=1`` is set.
            max_retries: Maximum retry attempts after the first try. Default 3.
            timeout: Per-attempt timeout in seconds. Default 30.
            _random_fn: Injected RNG for deterministic tests.
            _now_fn: Injected clock (returns Unix ms) for Retry-After tests.
        """
        super().__init__(
            api_key,
            base_url=base_url,
            enabled=enabled,
            max_retries=max_retries,
            timeout=timeout,
            _random_fn=_random_fn,
            _now_fn=_now_fn,
        )
        self._http = httpx.AsyncClient(timeout=self._timeout)

    async def aclose(self) -> None:
        """Close the underlying async HTTP connection pool."""
        await self._http.aclose()

    async def __aenter__(self) -> AsyncClient:
        """Support use as an async context manager."""
        return self

    async def __aexit__(self, *args: object) -> None:
        """Close the client on async context manager exit."""
        await self.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        params: dict[str, str | int] | None = None,
    ) -> Any:
        """Execute an async HTTP request with retries.

        Same retry policy as the sync ``Client._request``, using
        ``asyncio.sleep`` between attempts.
        """
        url = self._make_url(path)
        headers = self._make_headers(with_body=body is not None)

        for attempt in range(self._max_retries + 1):
            try:
                response = await self._http.request(
                    method,
                    url,
                    headers=headers,
                    json=body,
                    params=params,
                )
                if response.is_success:
                    return response.json()

                err = self._parse_api_error(response)
                if not err.retryable or attempt == self._max_retries:
                    raise err

                retry_after_ms = parse_retry_after_ms(
                    response.headers.get("retry-after"), self._now_fn()
                )
                delay = self._next_delay_s(attempt, retry_after_ms)
                _log.warning(
                    "hashline: HTTP %d, retrying (attempt %d/%d) in %.2fs",
                    err.status,
                    attempt + 1,
                    self._max_retries,
                    delay,
                )
                await asyncio.sleep(delay)

            except APIError:
                raise
            except httpx.TransportError as exc:
                if attempt == self._max_retries:
                    raise NetworkError(f"network request failed: {exc}", exc) from exc
                delay = self._next_delay_s(attempt, None)
                _log.warning(
                    "hashline: transport error (attempt %d/%d): %s, retrying in %.2fs",
                    attempt + 1,
                    self._max_retries,
                    exc,
                    delay,
                )
                await asyncio.sleep(delay)

        raise NetworkError("retry loop exhausted")

    async def event(
        self,
        *,
        run_id: str,
        type: str,  # noqa: A002
        actor: dict[str, Any],
        payload: Any,
        client_event_id: str | None = None,
        client_ts: int | None = None,
    ) -> EventAck | None:
        """Append a single event to a run (async).

        Returns the server acknowledgement, or ``None`` when disabled.
        """
        if not self._enabled:
            return None
        _validate_event_args(run_id=run_id, type=type, actor=actor, payload=payload)
        body = self._event_body(run_id, type, actor, payload, client_event_id, client_ts)
        result: EventAck = await self._request("POST", "/events", body=body)
        return result

    async def batch(
        self,
        run_id: str,
        events: list[BatchEventInput],
    ) -> BatchAck | None:
        """Append up to MAX_BATCH_SIZE events to a single run atomically (async).

        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        _validate_batch(run_id, events)
        body = self._batch_body(run_id, events)
        result: BatchAck = await self._request("POST", "/events/batch", body=body)
        return result

    async def get_run(self, run_id: str) -> dict[str, Any] | None:
        """Retrieve a run by ID (async).

        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        if not run_id:
            raise ValidationError("run_id is required")
        result: dict[str, Any] = await self._request("GET", f"/runs/{run_id}")
        return result

    async def list_runs(
        self,
        *,
        agent_id: str | None = None,
        status: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]] | None:
        """List runs, optionally filtered (async).

        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        params = self._list_runs_params(agent_id, status, limit)
        result: list[dict[str, Any]] = await self._request("GET", "/runs", params=params)
        return result

    async def get_events(
        self,
        run_id: str,
        *,
        after_seq: int | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]] | None:
        """Retrieve events for a run with optional pagination (async).

        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        if not run_id:
            raise ValidationError("run_id is required")
        params = self._get_events_params(after_seq, limit)
        result: list[dict[str, Any]] = await self._request(
            "GET", f"/runs/{run_id}/events", params=params
        )
        return result

    async def verify(self, run_id: str) -> dict[str, Any] | None:
        """Request server-side hash-chain verification for a run (async).

        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        if not run_id:
            raise ValidationError("run_id is required")
        result: dict[str, Any] = await self._request("POST", f"/runs/{run_id}/verify")
        return result

    async def export(
        self,
        run_id: str,
        *,
        format: str = "jsonl",  # noqa: A002
    ) -> dict[str, Any] | None:
        """Request an export of a run (async).

        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        if not run_id:
            raise ValidationError("run_id is required")
        result: dict[str, Any] = await self._request(
            "POST", f"/runs/{run_id}/export", body={"format": format}
        )
        return result

    async def get_export(self, export_id: str) -> dict[str, Any] | None:
        """Poll the status of an export (async).

        Returns ``None`` when the client is disabled.
        """
        if not self._enabled:
            return None
        if not export_id:
            raise ValidationError("export_id is required")
        result: dict[str, Any] = await self._request("GET", f"/exports/{export_id}")
        return result
