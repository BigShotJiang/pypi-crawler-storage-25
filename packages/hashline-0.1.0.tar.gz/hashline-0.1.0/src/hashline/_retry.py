"""Retry helpers: backoff computation, Retry-After parsing, status classification."""

from __future__ import annotations

import math
import random as _random_mod
import time
from email.utils import parsedate_to_datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable


def compute_backoff_ms(
    attempt: int,
    *,
    base_ms: int = 250,
    max_ms: int = 10_000,
    random_fn: Callable[[], float] | None = None,
) -> float:
    """Full-jitter exponential backoff (AWS Architecture Blog pattern).

    Returns a delay in ``[0, min(max_ms, base_ms * 2^attempt))`` milliseconds.
    Full jitter spreads retries across the window and avoids thundering herds.
    """
    rng = random_fn if random_fn is not None else _random_mod.random
    cap = min(max_ms, base_ms * (2**attempt))
    result: float = rng() * cap
    return result


def parse_retry_after_ms(
    header: str | None,
    now_ms: float | None = None,
) -> float | None:
    """Parse a ``Retry-After`` header value to milliseconds.

    Supports both the delta-seconds form and HTTP-date form (RFC 7231 §7.1.3).
    Returns ``None`` when the header is absent or malformed.
    """
    if not header:
        return None
    trimmed = header.strip()
    if not trimmed:
        return None

    # Delta-seconds form: "120" or "0"
    try:
        seconds = float(trimmed)
        if math.isfinite(seconds) and seconds >= 0:
            return seconds * 1000.0
    except ValueError:
        pass

    # HTTP-date form: "Wed, 21 Oct 2015 07:28:00 GMT"
    try:
        dt = parsedate_to_datetime(trimmed)
        if now_ms is None:
            now_ms = time.time() * 1000.0
        delta = dt.timestamp() * 1000.0 - now_ms
        return max(0.0, delta)
    except Exception:
        pass

    return None


def is_retryable_status(status: int) -> bool:
    """Return True for HTTP status codes that warrant an automatic retry."""
    return status == 408 or status == 429 or (500 <= status <= 599)
