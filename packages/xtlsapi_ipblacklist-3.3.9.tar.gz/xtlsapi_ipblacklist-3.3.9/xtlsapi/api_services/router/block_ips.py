import grpc
from xtlsapi.api_services._base import BaseService
from xtlsapi.xray_api.app.router import config_pb2
from xtlsapi.xray_api.app.router.command import command_pb2
from xtlsapi.xray_api.common.serial import typed_message_pb2
import ipaddress


class RouterBlockIps(BaseService):
    """Блокировка IP через Xray API"""

    def block_ips(
        self,
        ips: list[str],
        inbound_tag: str,
        rule_tag: str = "sourceIpBlock",
        outbound_tag: str = "blocked",
    ):
        """
        Блокирует указанные IP на конкретном inbound.
        """

        try:
            # 1️⃣ Удаляем старое правило
            self.routing_stub.RemoveRule(
                command_pb2.RemoveRuleRequest(ruleTag=rule_tag)
            )

            if not ips:
                return None

            # 2️⃣ Конвертация IP в protobuf CIDR
            def ip_to_bytes(ip_str: str) -> bytes:
                return ipaddress.ip_address(ip_str).packed

            geoip_list = [
                config_pb2.GeoIP(
                    country_code="",  # кастомные IP
                    cidr=[config_pb2.CIDR(ip=ip_to_bytes(ip), prefix=32)]
                )
                for ip in ips
            ]

            # 3️⃣ Создаем RoutingRule
            rule = config_pb2.RoutingRule(
                rule_tag=rule_tag,
                inbound_tag=[inbound_tag] if inbound_tag else [],
                tag=outbound_tag,          # outbound
                source_geoip=geoip_list
            )

            # 4️⃣ Создаем Config с одним правилом
            config = config_pb2.Config(
                rule=[rule]
            )

            # 5️⃣ Сериализуем Config в байты protobuf для gRPC
            typed_msg = typed_message_pb2.TypedMessage(
                type=config.DESCRIPTOR.full_name,
                value=config.SerializeToString()
            )

            # 6️⃣ Отправляем AddRule через gRPC
            return self.routing_stub.AddRule(
                command_pb2.AddRuleRequest(
                    config=typed_msg,
                    shouldAppend=True,
                )
            )

        except grpc.RpcError as e:
            # Можно логировать детали: e.details()
            raise e