"""mgf-example-app — reference second-consumer of mgf-common.

v0.4 Phase G3. Demonstrates the canonical v0.4 ergonomic shape
in a real, tested, packaged consumer:

  - ``bootstrap()`` for one-call observability + identity wiring.
  - ``AppSettings(BaseAppSettings)`` composing
    :class:`mgf.common.settings.MgfSettings` as a sub-field.
  - A custom CLI subcommand registered via
    :func:`mgf.common.cli.register_cli_subcommand`.
  - ``bootstrap_for_test()`` in the test suite for opinionated
    test bootstrap.

This package is the "second consumer" signal — every v0.4 public
API decision is grounded in a real consumer integration, not
just self-tests in mgf-common's source repo.
"""

from __future__ import annotations

__version__ = "0.0.1"

__all__ = ["__version__"]
