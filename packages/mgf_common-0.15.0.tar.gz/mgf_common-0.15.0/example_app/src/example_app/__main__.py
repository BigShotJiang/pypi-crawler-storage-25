"""Module entry — ``python -m example_app``."""

from __future__ import annotations

from example_app.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
