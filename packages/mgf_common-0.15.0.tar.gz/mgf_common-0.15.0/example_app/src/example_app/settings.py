"""Typed settings for ``example_app``.

Demonstrates the canonical v0.4 composition pattern from
``docs/public/04_settings.md`` — the consumer's settings carries
:class:`mgf.common.settings.MgfSettings` as a sub-field rather
than subclassing it.
"""

from __future__ import annotations

from typing import Annotated

from mgf.common.config import BaseAppSettings, Field, settings_config
from mgf.common.settings import MgfSettings


class AppSettings(BaseAppSettings):
    """Top-level settings for ``example_app``.

    Loads from env vars (``EXAMPLE_APP_*``) and the standard
    config-file paths. ``mgf-common``'s own settings ride along
    under ``EXAMPLE_APP_MGF__*`` env vars and the ``mgf:`` section
    of YAML / pyproject.

    Domain fields are minimal — just enough to demonstrate the
    composition pattern. A real consumer would have more.
    """

    model_config = settings_config(
        env_prefix="EXAMPLE_APP_",
        env_nested_delimiter="__",
    )

    # Domain fields:
    greeting: str = "Hello"
    request_timeout_seconds: Annotated[int, Field(ge=1, le=300)] = 30

    # mgf-common's settings as a sub-field. The library reads ONLY
    # this sub-field; bootstrap(settings=app_settings.mgf) wires
    # the mgf-common pieces.
    mgf: MgfSettings = Field(default_factory=MgfSettings)


__all__ = ["AppSettings"]
