"""OpenTelemetry types re-exported through ``mgf.common.observability``.

Closes the closed-box leak CB-12 / CB-13 — consumers no longer
``import opentelemetry`` for normal span manipulation.

Two paths:

  - **OTel installed** (the ``[observability]`` extra) — names
    are the real OTel types; type-checkers + IDEs see them as
    ``opentelemetry.trace.*``.
  - **OTel NOT installed** (default install) — names fall back
    to ``Any`` sentinels so the import succeeds; the convenience
    helpers (:func:`get_current_span`, :func:`set_attribute`,
    etc.) all no-op when OTel is absent.

The re-export shape uses explicit ``X as X`` aliasing per PEP 484
so ``mypy --strict`` accepts them as public re-exports.

Renames at the boundary:

  - OTel ``opentelemetry.trace.Status`` → :class:`SpanStatus`
    (the OTel name collides with too many other things in
    consumer code).

See ``docs/CLOSED_BOX_REDESIGN.md`` §4.4 for the full design.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    # Static analysis path — always uses the real types so IDEs
    # + mypy give correct hover info.
    from opentelemetry.trace import (  # noqa: I001
        Span as Span,
        SpanContext as SpanContext,
        SpanKind as SpanKind,
        Status as SpanStatus,
        StatusCode as StatusCode,
    )
else:
    try:
        from opentelemetry.trace import Span as Span
        from opentelemetry.trace import SpanContext as SpanContext
        from opentelemetry.trace import SpanKind as SpanKind
        from opentelemetry.trace import Status as SpanStatus
        from opentelemetry.trace import StatusCode as StatusCode
    except ImportError:
        # OTel not installed — expose Any sentinels so the import
        # succeeds + downstream type annotations don't crash.
        # The helper functions in _otel_helpers.py all no-op
        # without OTel; consumer code that uses these types as
        # type annotations only is unaffected.
        Span = Any  # type: ignore[misc, assignment]
        SpanContext = Any  # type: ignore[misc, assignment]
        SpanKind = Any  # type: ignore[misc, assignment]
        SpanStatus = Any  # type: ignore[misc, assignment]
        StatusCode = Any  # type: ignore[misc, assignment]


__all__ = [
    "Span",
    "SpanContext",
    "SpanKind",
    "SpanStatus",
    "StatusCode",
]
