"""Process-wide unhandled-exception hook.

Installs a wrapper around ``sys.excepthook`` that:

  1. Lets ``KeyboardInterrupt`` and ``SystemExit`` pass through to the
     prior hook (Python's default behavior is correct for these).
  2. Logs the exception via the application logger at ERROR with full
     traceback (rule LG-05).
  3. Persists a local crash report and best-effort ships it to the
     configured remote sink (rule EH-05).
  4. Calls the prior hook so anything else chained on top still sees it.

Idempotent: re-running :func:`install_excepthook` chains the new wrapper
over the existing one. The wrapper detects this and does not double-log.

See ``docs/standards/ERROR_HANDLING.md`` §4.2.
"""

from __future__ import annotations

import logging
import sys
from typing import TYPE_CHECKING

from mgf.common._identity import app_name
from mgf.common.observability.crash_reporter import report_now

if TYPE_CHECKING:
    from types import TracebackType

# Sentinel attached to wrapped hooks so re-installation is idempotent
# (calling install_excepthook twice should not produce two crash reports
# per crash).
_INSTALLED_MARKER = "_mgf_common_excepthook_installed"


def _wire_excepthook() -> None:
    """Install the process-wide unhandled-exception hook (rule EH-04).

    Internal — called by :func:`mgf.common.bootstrap` and by the
    deprecated :func:`install_excepthook` shim.
    """
    prior = sys.excepthook
    if getattr(prior, _INSTALLED_MARKER, False):
        # Already installed; chaining again would just produce two
        # crash reports per crash. No-op.
        return

    log = logging.getLogger(f"{app_name()}.unhandled")

    def hook(
        exc_type: type[BaseException],
        exc: BaseException,
        tb: TracebackType | None,
    ) -> None:
        # KeyboardInterrupt / SystemExit are NOT bugs — let the
        # default hook handle them (Python prints "KeyboardInterrupt"
        # and exits cleanly).
        if issubclass(exc_type, (KeyboardInterrupt, SystemExit)):
            prior(exc_type, exc, tb)
            return

        # Log first so the trace is in the structured log even if the
        # crash reporter itself trips.
        log.error(
            "unhandled exception",
            exc_info=(exc_type, exc, tb),
        )
        report_now(exc, source="excepthook")
        # Chain to the prior hook (Python default = print to stderr).
        prior(exc_type, exc, tb)

    setattr(hook, _INSTALLED_MARKER, True)
    sys.excepthook = hook


def install_excepthook() -> None:
    """Deprecated — use :func:`mgf.common.bootstrap` instead.

    Emits :class:`mgf.common._warnings.MgfDeprecationWarning` and
    delegates to ``_wire_excepthook``. Removed in v1.0.
    """
    import warnings

    from mgf.common._warnings import MgfDeprecationWarning

    warnings.warn(
        "mgf.common.observability.install_excepthook is deprecated since "
        "v0.3.0; use mgf.common.bootstrap(...) which installs the hooks "
        "transactionally. Removed in v1.0.",
        MgfDeprecationWarning,
        stacklevel=2,
    )
    _wire_excepthook()


__all__ = ["install_excepthook"]
