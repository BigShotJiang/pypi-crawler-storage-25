"""OpenTelemetry initialisation — Tier C observability.

Lazy imports throughout — the OpenTelemetry SDK is an optional extra
(``mgf-common[observability]``). Code paths in this module degrade
gracefully when the SDK is not installed: :func:`setup_otel` becomes a
no-op, :func:`operation_span` yields without opening a span, and
:func:`build_otlp_log_handler` returns ``None``.

Endpoints + service identity come from standard OpenTelemetry env vars:

  - ``OTEL_EXPORTER_OTLP_ENDPOINT``
  - ``OTEL_EXPORTER_OTLP_HEADERS``
  - ``OTEL_SERVICE_NAME``  (default: :func:`mgf.common.app_name`)
  - ``OTEL_RESOURCE_ATTRIBUTES``

This round ships only the foundation: the entry-point hook + the
span context manager + the OTLP log handler factory.

See ``docs/standards/LOGGING.md`` §7.
"""

from __future__ import annotations

import contextlib
import logging
import os
from typing import TYPE_CHECKING, Any

from mgf.common._identity import app_name

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator
else:
    from collections.abc import Callable

_LOG = logging.getLogger(__name__)

# Module-level flag so re-calling setup_otel is a no-op rather than
# stacking a second TracerProvider.
_INSTALLED = False


def _wire_otel(*, enabled: bool | None = None) -> None:
    """Initialise the OpenTelemetry SDK + OTLP span exporter.

    Internal — called by :func:`mgf.common.bootstrap` and by the
    deprecated :func:`setup_otel` shim. Idempotent — re-calling
    is a no-op rather than stacking a second TracerProvider.
    """
    global _INSTALLED
    if _INSTALLED:
        return
    if enabled is None:
        enabled = bool(os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT"))
    if not enabled:
        return

    try:
        from opentelemetry import trace
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
    except ImportError:
        _LOG.warning(
            "OTEL_EXPORTER_OTLP_ENDPOINT is set but the opentelemetry SDK is not installed; "
            "install with `pip install %s[observability]`",
            app_name(),
        )
        return

    resource = Resource.create({"service.name": os.environ.get("OTEL_SERVICE_NAME", app_name())})
    provider = TracerProvider(resource=resource)
    provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
    trace.set_tracer_provider(provider)
    _INSTALLED = True

    # Auto-instrument well-known clients so HTTP requests / SQL queries
    # appear as child spans of the currently-active operation_span
    # automatically — callers don't have to manually wrap every IO
    # call. Each helper is best-effort: missing optional dep → no-op.
    _maybe_instrument_httpx()


def setup_otel(*, enabled: bool | None = None) -> None:
    """Deprecated — use :func:`mgf.common.bootstrap` instead.

    The v0.1 multi-call bootstrap shape is replaced in v0.3 by a
    single :func:`mgf.common.bootstrap` call. See
    ``docs/CLOSED_BOX_REDESIGN.md`` §4.1.

    Emits :class:`mgf.common._warnings.MgfDeprecationWarning` and
    delegates to ``_wire_otel``. Removed in v1.0.
    """
    import warnings

    from mgf.common._warnings import MgfDeprecationWarning

    warnings.warn(
        "mgf.common.observability.setup_otel is deprecated since "
        "v0.3.0; use mgf.common.bootstrap(...) which wires logging + "
        "OTel + excepthooks transactionally. Removed in v1.0.",
        MgfDeprecationWarning,
        stacklevel=2,
    )
    _wire_otel(enabled=enabled)


def _maybe_instrument_httpx() -> None:
    """Auto-instrument the ``httpx`` HTTP client.

    No-op when the optional ``opentelemetry-instrumentation-httpx``
    package is not installed (it is only pulled by the
    ``[observability]`` extra). Idempotent — calling twice does not
    stack instrumentations.
    """
    try:
        from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
    except ImportError:
        return
    try:
        HTTPXClientInstrumentor().instrument()
    except Exception as e:
        # Already-instrumented or some other transient — log and
        # continue rather than blocking startup.
        _LOG.warning("httpx auto-instrumentation skipped: %s", e)


@contextlib.contextmanager
def operation_span(name: str, **attributes: Any) -> Iterator[None]:
    """Open an OpenTelemetry span around an operation.

    Usage::

        with operation_span("vm.create", vm_name=spec.name):
            handle = build_and_run(spec, provider)

    When the OpenTelemetry SDK is not installed OR :func:`setup_otel`
    has not been called, this is a no-op — the ``with`` block runs
    normally and no span is opened. This means callers can safely use
    the context manager unconditionally.

    Span names follow ``<subject>.<verb>`` (e.g., ``vm.create``,
    ``snapshot.revert``) — see ``docs/standards/LOGGING.md`` §7.3.

    Attributes are attached as span attributes when a real span is
    opened. Keys SHOULD be snake_case. ``None`` values are skipped
    (OTel attribute API rejects them).

    On exception:
      - The exception is recorded on the span (``record_exception``)
        so the trace shows the failure type + message + stacktrace.
      - The span status is set to ERROR so the trace UI highlights
        the failure path.
      - The exception then re-raises so the caller's error handling
        runs unchanged.
    """
    try:
        from opentelemetry import trace
        from opentelemetry.trace import Status, StatusCode
    except ImportError:
        yield
        return

    tracer = trace.get_tracer(app_name())
    with tracer.start_as_current_span(name) as span:
        for k, v in attributes.items():
            if v is None:
                # OTel attributes API rejects None values. Skip
                # rather than coerce to "None" string — callers can
                # always pass an explicit empty string when they
                # want a placeholder.
                continue
            span.set_attribute(k, v)
        try:
            yield
        except Exception as exc:
            span.record_exception(exc)
            span.set_status(Status(StatusCode.ERROR, description=str(exc)))
            raise


def build_otlp_log_handler() -> logging.Handler | None:
    """Build an OTLP log exporter handler, or return ``None`` if SDK absent.

    Used by :func:`mgf.common.observability.logging_setup.setup_logging`
    when ``OTEL_EXPORTER_OTLP_ENDPOINT`` is set.

    The OTel logs API was experimental in opentelemetry-python until
    SDK ~1.27 — pin appropriately in ``pyproject.toml``.
    """
    try:
        from opentelemetry.exporter.otlp.proto.http._log_exporter import OTLPLogExporter
        from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
        from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
    except ImportError:
        return None

    provider = LoggerProvider()
    provider.add_log_record_processor(BatchLogRecordProcessor(OTLPLogExporter()))
    handler: logging.Handler = LoggingHandler(level=logging.NOTSET, logger_provider=provider)
    return handler


def emit_log_event(name: str, *, attributes: dict[str, Any]) -> None:
    """Emit a one-off OTel log event (used by the crash reporter's OTLP sink).

    No-op when the SDK is not installed. Distinct from a regular
    log record so the receiving collector can route crash events
    differently from operational logs.
    """
    try:
        from opentelemetry._logs import SeverityNumber, get_logger
    except ImportError:
        return
    logger = get_logger(app_name())
    logger.emit(
        body=name,
        severity_number=SeverityNumber.ERROR,
        attributes=attributes,
    )


# ---------------------------------------------------------------------------
# OTel span-processor registry (Phase 3 — registry shipped; full wiring Phase 5+)
# ---------------------------------------------------------------------------
#
# Consumers register a NAMED span-processor factory; the active
# wiring instantiates each one when its name appears in
# ``MgfSettings.otel.enabled_processors`` (a future field — Phase
# 5 threads it through ``_wire_otel``).
#
# Phase 3 ships the registry + decorator + tests so consumer
# plug-in code can register at import time. The wiring step that
# instantiates them lands when consumers actually need it.

if TYPE_CHECKING:
    from opentelemetry.sdk.trace import SpanProcessor

    from mgf.common.settings import MgfSettings

SpanProcessorFactory = Callable[["MgfSettings"], "SpanProcessor"]
"""Factory that returns a configured OTel ``SpanProcessor`` given
the active :class:`mgf.common.settings.MgfSettings`."""

_SPAN_PROCESSORS: dict[str, SpanProcessorFactory] = {}


def register_span_processor(
    name: str,
) -> Callable[[SpanProcessorFactory], SpanProcessorFactory]:
    """Decorator: register a custom OTel span-processor factory.

    Closes the closed-box leak around custom span export
    (consumers no longer ``import opentelemetry.sdk.trace`` to
    add a custom processor; they register a named factory and
    enable it through settings).

    Example::

        from mgf.common.observability import register_span_processor

        @register_span_processor("custom-batcher")
        def _make_batcher(settings):
            return MyCustomSpanProcessor(...)

    Activated by listing the name in
    ``MgfSettings.otel.enabled_processors`` (wiring lands in a
    later phase). Phase 3 ships the registry so consumers can
    register at import time without source-compat impact.

    Threading: register at module-import / bootstrap time.
    """

    def decorator(fn: SpanProcessorFactory) -> SpanProcessorFactory:
        if name in _SPAN_PROCESSORS:
            raise ValueError(
                f"span processor {name!r} already registered "
                f"(unregister first if you intend to replace it)"
            )
        _SPAN_PROCESSORS[name] = fn
        return fn

    return decorator


def unregister_span_processor(name: str) -> None:
    """Remove a registered span processor. No-op if unknown."""
    _SPAN_PROCESSORS.pop(name, None)


def _registered_span_processors() -> dict[str, SpanProcessorFactory]:
    """Internal: snapshot of the registry."""
    return dict(_SPAN_PROCESSORS)


__all__ = [
    "SpanProcessorFactory",
    "build_otlp_log_handler",
    "emit_log_event",
    "operation_span",
    "register_span_processor",
    "setup_otel",
    "unregister_span_processor",
]
