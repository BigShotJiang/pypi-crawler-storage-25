"""Local + optional remote crash reporting.

See: ``docs/public/06_crash_reporting.md``.

Local reports are JSON files under ``<state>/crashes/``, one per
crash, named ``<timestamp>-<short-uuid>.json``. The directory persists
across runs so a user can attach a single file to a bug report.

Remote shipping is opt-in via the ``<APP>_CRASH_SINK`` environment
variable (where ``<APP>`` is the upper-cased
:func:`mgf.common.app_name`):

  - ``"sentry"``  — uses ``sentry-sdk`` if installed.
  - ``"otlp"``    — uses the OpenTelemetry log exporter if installed.
  - ``"https://..."`` (or ``http://``) — POST JSON to this URL.
  - unset / empty — local only.

The remote dependencies are imported **lazily** so the package works
without the ``observability`` extra installed.

The entry point :func:`report_now` MUST NEVER raise — it is the last
line of defense in every top-level handler. Any failure during report
generation, file write, or remote ship is logged at WARNING via the
module logger and swallowed.

See ``docs/standards/ERROR_HANDLING.md`` §6 for the design.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import sys
import traceback
import uuid
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from mgf.common._identity import app_name, app_version
from mgf.common.observability.paths import default_crash_dir

_LOG = logging.getLogger(__name__)

# Sentinel returned when the local write itself fails. Callers
# (e.g., the CLI catch-all) check ``path != _NULL_REPORT_PATH``
# before showing it to the user.
_NULL_REPORT_PATH = Path("/dev/null")


def report_now(exc: BaseException, *, source: str) -> Path:
    """Build, persist locally, and best-effort ship a crash report.

    Returns the local file path so callers can show it to the user.
    Returns :data:`_NULL_REPORT_PATH` if the local write failed (the
    failure is logged; the caller's user-facing message can degrade
    gracefully — see VManager's ``cli/__main__.py`` for the canonical
    pattern).

    NEVER raises. Any exception during report assembly, file write, or
    remote shipping is caught here and logged at WARNING.
    """
    try:
        report = _build_report(exc, source=source)
    except Exception as build_err:
        _LOG.warning("crash reporter could not build report: %s", build_err)
        return _NULL_REPORT_PATH

    try:
        path = _write_local(report)
    except Exception as write_err:
        _LOG.warning("crash reporter could not write local report: %s", write_err)
        path = _NULL_REPORT_PATH

    # Remote shipping is fire-and-forget. Errors logged, never raised.
    _ship_remote(report)

    return path


def _build_report(exc: BaseException, *, source: str) -> dict[str, Any]:
    """Build the JSON-serialisable report dict.

    Captures: timestamp, app name + version, source label (e.g.,
    ``"cli"``, ``"gui-worker"``, ``"thread:metrics"``), exception
    type / message / args / traceback, the cause chain (one level
    deep — most useful in practice), and platform info.

    The cause chain stops at one level because deeper chains are
    rarely actionable in a crash report and bloat the file.
    """
    cause: dict[str, Any] | None = None
    if exc.__cause__ is not None:
        cause = {
            "type": _qualified_type(exc.__cause__),
            "message": str(exc.__cause__),
        }

    return {
        "timestamp": datetime.now(UTC).isoformat(),
        "report_id": uuid.uuid4().hex,
        "app": app_name(),
        "version": app_version(),
        "source": source,
        "exception": {
            "type": _qualified_type(exc),
            "message": str(exc),
            "args": [repr(a) for a in getattr(exc, "args", ())],
        },
        "traceback": traceback.format_exception(type(exc), exc, exc.__traceback__),
        "cause": cause,
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "python": sys.version,
            "implementation": platform.python_implementation(),
        },
    }


def _write_local(report: dict[str, Any]) -> Path:
    """Atomic write under ``<state>/crashes/`` (rule CF-04 generalised)."""
    target_dir = default_crash_dir()
    target_dir.mkdir(parents=True, exist_ok=True)

    # Replace ``:`` in the timestamp so the filename is portable
    # (Windows forbids ``:`` in filenames).
    safe_ts = report["timestamp"].replace(":", "-")
    short_id = report["report_id"][:8]
    path = target_dir / f"{safe_ts}-{short_id}.json"

    tmp = path.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
        tmp.chmod(0o600)
        tmp.replace(path)
    except Exception:
        # Clean up the partial temp file before propagating; the caller
        # (``report_now``) catches the propagation.
        tmp.unlink(missing_ok=True)
        raise
    return path


# ---------------------------------------------------------------------------
# Crash-sink registry (closes FEEDBACK API-07)
# ---------------------------------------------------------------------------
#
# Consumers register custom sinks via the ``register_crash_sink``
# decorator. The dispatch in ``_ship_remote`` consults the registry
# instead of the v0.1 hardcoded sentry / otlp / http branches —
# which now exist as PRE-REGISTERED entries (`@register_crash_sink`
# decorations on the existing helpers) so backward compat is
# preserved.
#
# Sink signature:
#
#     CrashSink = Callable[[Path, dict[str, Any]], None]
#
# The sink receives both the local report path AND the in-memory
# payload. Either may be useful; sinks that only need one ignore
# the other.

CrashSink = Callable[[Path, dict[str, Any]], None]
"""Type alias for crash-sink handler callables (closes FEEDBACK API-07)."""

_CRASH_SINKS: dict[str, CrashSink] = {}


def register_crash_sink(name: str) -> Callable[[CrashSink], CrashSink]:
    """Decorator: register a crash-sink handler under ``name``.

    Closes FEEDBACK API-07 — consumers extend the crash-reporter
    sink set without forking ``mgf-common``::

        from pathlib import Path
        from typing import Any

        from mgf.common.observability import register_crash_sink

        @register_crash_sink("my-slack")
        def ship_to_slack(report_path: Path, payload: dict[str, Any]) -> None:
            requests.post(
                SLACK_WEBHOOK,
                json={
                    "text": f"Crash in {payload['app']}: "
                            f"{payload['exception']['message']}",
                },
                timeout=5,
            )

    The sink fires when ``MgfSettings.crash.sinks`` (or the legacy
    ``<APP>_CRASH_SINK`` env var) names it. Sinks MUST NOT raise —
    the crash reporter wraps every sink call in ``try / except`` and
    logs failures at WARNING.

    Threading: ``register_crash_sink`` is single-threaded — call at
    module-import time / bootstrap time, not from a worker. The
    registry itself is read-only on the hot path.
    """

    def decorator(fn: CrashSink) -> CrashSink:
        if name in _CRASH_SINKS:
            raise ValueError(
                f"crash sink {name!r} is already registered "
                f"(unregister first if you intend to replace it)"
            )
        _CRASH_SINKS[name] = fn
        return fn

    return decorator


def unregister_crash_sink(name: str) -> None:
    """Remove a registered crash sink. No-op if ``name`` is unknown.

    Useful for tests + for consumers swapping a sink at runtime.
    """
    _CRASH_SINKS.pop(name, None)


def _registered_crash_sinks() -> dict[str, CrashSink]:
    """Internal: snapshot of the active registry. Used by tests +
    the (future) ``mgf-common doctor`` diagnostic."""
    return dict(_CRASH_SINKS)


def _ship_remote(report: dict[str, Any]) -> None:
    """Best-effort remote shipping. Never raises (caught by ``report_now``).

    Resolution order:

    1. Active :class:`MgfSettings.crash.sinks` — fan-out to every
       named sink (closes FEEDBACK API-07; multi-sink shape).
    2. Legacy ``<APP>_CRASH_SINK`` env var — single sink (v0.1
       behaviour, preserved for ``preset="auto"`` consumers).

    Each sink path catches its own exceptions and logs at WARNING.
    """
    # Path 1: registry-driven (v0.3+).
    sink_names = _resolve_active_sinks()
    if sink_names:
        for name in sink_names:
            if name == "local":
                continue  # local is the always-on baseline
            sink_fn = _CRASH_SINKS.get(name)
            if sink_fn is None:
                _LOG.warning(
                    "crash sink %r is not registered; ignoring", name,
                )
                continue
            try:
                # The local report path is built by `_write_local`
                # before this is called; we don't have it here, so
                # the sink receives the in-memory payload only and
                # an empty Path() sentinel. (Refactor: thread the
                # path through if + when a registered sink needs it.)
                sink_fn(Path(), report)
            except Exception as e:  # never raises (rule EH-10)
                _LOG.warning("crash sink %r failed: %s", name, e)
        return

    # Path 2: v0.1 env-var fallback.
    sink_env = f"{app_name().upper()}_CRASH_SINK"
    sink = os.environ.get(sink_env, "").strip()
    if not sink:
        return
    if sink.startswith(("http://", "https://")):
        # http URLs aren't a registered name — they ARE the URL.
        try:
            _ship_http(report, sink)
        except Exception as e:
            _LOG.warning("crash report shipping failed: %s", e)
        return
    sink_fn = _CRASH_SINKS.get(sink)
    if sink_fn is None:
        _LOG.warning("unknown crash sink: %r (set %s)", sink, sink_env)
        return
    try:
        sink_fn(Path(), report)
    except Exception as e:
        _LOG.warning("crash report shipping failed: %s", e)


def _resolve_active_sinks() -> list[str]:
    """Look at the active AppContext (if any) for the configured
    crash-sink list. Returns ``[]`` when no context active OR the
    settings list is the default ``["local"]`` (signal: 'use the
    legacy env-var path').
    """
    try:
        from mgf.common._lifecycle import current_context
    except ImportError:
        return []
    ctx = current_context()
    if ctx is None:
        return []
    sinks = list(ctx.settings.crash.sinks)
    # When the consumer hasn't customised the list, fall through
    # to the env-var path so legacy behaviour is preserved.
    if sinks == ["local"]:
        return []
    return sinks


@register_crash_sink("sentry")
def _ship_sentry(report_path: Path, report: dict[str, Any]) -> None:
    """Built-in Sentry sink. Pre-registered at module import."""
    try:
        import sentry_sdk
    except ImportError:
        _LOG.warning(
            "%s_CRASH_SINK=sentry but sentry-sdk is not installed",
            app_name().upper(),
        )
        return
    # ``capture_event`` accepts a synthetic event dict; we send the
    # full report as the message + extras so Sentry doesn't deduplicate
    # us into oblivion based on the typed exception alone.
    sentry_sdk.capture_event(
        {
            "message": report["exception"]["message"],
            "level": "error",
            "extra": report,
        }
    )


@register_crash_sink("otlp")
def _ship_otlp(report_path: Path, report: dict[str, Any]) -> None:
    """Built-in OTLP log-emitter sink. Pre-registered at module import."""
    try:
        from mgf.common.observability.otel_setup import emit_log_event
    except ImportError:
        _LOG.warning(
            "%s_CRASH_SINK=otlp but observability extra is not installed",
            app_name().upper(),
        )
        return
    emit_log_event(name="crash", attributes=report)


def _ship_http(report: dict[str, Any], url: str) -> None:
    """POST the report to a webhook URL.

    Synchronous with a 5-second timeout — fine for CLI exit-code
    translators. For long-running services, callers SHOULD wrap
    ``report_now`` in a queue.
    """
    import urllib.request

    body = json.dumps(report).encode("utf-8")
    # ruff S310 — the URL is operator-controlled (set via the
    # <APP>_CRASH_SINK env var), not derived from user input. The
    # scheme check is the operator's responsibility; restricting to
    # http/https here would silently drop file:/ for local-test
    # mocks. Documented per-line allowlist instead of blanket noqa.
    req = urllib.request.Request(  # noqa: S310
        url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=5):  # noqa: S310 — see above
        pass


def _crash_dir() -> Path:
    """Deprecated alias for :func:`mgf.common.observability.default_crash_dir`.

    Removed in a future release. Closed-box leak: consumers that
    imported this private helper (it had no public alternative
    before v0.13) should migrate to the public name.
    """
    import warnings

    from mgf.common._warnings import MgfDeprecationWarning

    warnings.warn(
        "mgf.common.observability.crash_reporter._crash_dir is "
        "deprecated since v0.13.0; import "
        "mgf.common.observability.default_crash_dir instead.",
        MgfDeprecationWarning,
        stacklevel=2,
    )
    return default_crash_dir()


def _qualified_type(exc: BaseException) -> str:
    """Return ``module.QualName`` of an exception's type."""
    cls = type(exc)
    return f"{cls.__module__}.{cls.__qualname__}"


__all__ = [
    "CrashSink",
    "register_crash_sink",
    "report_now",
    "unregister_crash_sink",
]
