"""Shared request-id contextvar + helpers.

Hoisted to a framework-agnostic location so both
``mgf.common.fastapi`` and ``mgf.common.django`` (and any future
framework adapter) can read/write the same contextvar. Logging
filters that pull ``current_request_id()`` work end-to-end across
mixed-framework processes (e.g., a Django app calling a FastAPI
service via an internal RPC).

This module is private — consumers import the public re-exports
from ``mgf.common.fastapi`` or ``mgf.common.django`` (whichever
framework they use).
"""

from __future__ import annotations

import contextvars
import uuid

REQUEST_ID_HEADER = "X-Request-Id"
"""Canonical header name. Many providers ship as ``X-Request-Id``;
some use ``Request-Id`` or ``X-Correlation-Id``. We accept any
case variant on input but always echo as ``X-Request-Id``."""


# Per-request contextvar. Default empty string so reads from outside
# a request return a falsy value rather than raising.
_REQUEST_ID_VAR: contextvars.ContextVar[str] = contextvars.ContextVar(
    "mgf_request_id",
    default="",
)


def current_request_id() -> str:
    """Return the current request's ID, or ``""`` outside a request.

    Reads a per-task contextvar set by the framework adapter's
    request-id middleware. Safe to call from any code path inside an
    HTTP request handler, including async children. Outside a
    request, returns the empty string — code SHOULD treat that as
    "no request id available."
    """
    return _REQUEST_ID_VAR.get()


def _generate_request_id() -> str:
    """Generate a fresh UUID4 string for a request id.

    Separate function so tests can monkeypatch deterministic ids.
    """
    return str(uuid.uuid4())
