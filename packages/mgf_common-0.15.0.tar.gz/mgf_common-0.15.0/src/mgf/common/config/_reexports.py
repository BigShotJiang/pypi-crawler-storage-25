"""Pydantic primitives re-exported through ``mgf.common.config``.

Closes the closed-box leak CB-04 (consumers no longer need
``import pydantic`` for normal subclass authoring). The re-exports
are intentionally explicit (`from pydantic import X as X`) so:

  - ``mypy --strict`` accepts them as public re-exports per PEP 484
    semantics.
  - The set of names is grep-able + auditable in one place.
  - We can shim a future pydantic API change without touching
    consumer code.

The re-exports cover the names a consumer needs to author a
non-trivial ``BaseAppSettings`` subclass:

  - :class:`BaseModel` — for nested sub-models inside Settings.
  - :class:`ConfigDict` — for inner ``model_config`` declarations
    on sub-models (``ConfigDict(extra="forbid")``).
  - :func:`Field` — typed field with constraints + aliases.
  - :class:`AliasChoices` — for renames-without-breaks (rule CF-11).
  - :func:`field_validator` — single-field validators.
  - :func:`model_validator` — cross-field / whole-model validators.
  - :class:`ValidationError` — the exception consumers catch when
    validating user-supplied dicts via ``Model.model_validate``.

Names NOT re-exported (deliberately): ``BaseSettings``,
``SettingsConfigDict``, ``PydanticBaseSettingsSource``,
``YamlConfigSettingsSource``. Consumers don't subclass
``BaseSettings`` directly — they subclass our
:class:`BaseAppSettings`. The settings-source primitives are
internal to the layered-loading machinery (rule CF-02).

See ``docs/CLOSED_BOX_REDESIGN.md`` §4.2 for the full closed-box
rationale.
"""

from __future__ import annotations

from pydantic import AliasChoices as AliasChoices
from pydantic import BaseModel as BaseModel
from pydantic import ConfigDict as ConfigDict
from pydantic import Field as Field
from pydantic import ValidationError as ValidationError
from pydantic import field_validator as field_validator
from pydantic import model_validator as model_validator

__all__ = [
    "AliasChoices",
    "BaseModel",
    "ConfigDict",
    "Field",
    "ValidationError",
    "field_validator",
    "model_validator",
]
