"""``configure_env`` — the load-bearing alembic env.py helper.

Reads the URL + metadata + options from the consumer; runs the
migration via either the sync or async path based on the URL's
driver prefix.

Async drivers detected by URL prefix:

  - ``postgresql+asyncpg://``
  - ``postgresql+psycopg://`` (psycopg 3 with asyncio mode)
  - ``mysql+aiomysql://``
  - ``mysql+asyncmy://``
  - ``sqlite+aiosqlite://``

Other URLs (``postgresql://``, ``postgresql+psycopg2://``,
``mysql+pymysql://``, ``sqlite:///``) take the sync path.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from sqlalchemy import pool

if TYPE_CHECKING:
    from sqlalchemy import Connection, MetaData


# URL prefixes that indicate an async driver. Conservative list —
# adding a driver not here means it falls through to the sync path
# (which will raise at runtime if the driver doesn't have a sync
# variant — which is the right behavior; users will discover it
# immediately).
_ASYNC_URL_PREFIXES: tuple[str, ...] = (
    "postgresql+asyncpg://",
    "postgresql+psycopg://",
    "mysql+aiomysql://",
    "mysql+asyncmy://",
    "sqlite+aiosqlite://",
)


def configure_env(
    *,
    database_url: str,
    target_metadata: MetaData,
    compare_type: bool = True,
    compare_server_default: bool = True,
    naming_convention: dict[str, str] | None = None,
) -> None:
    """Run alembic migrations using ``database_url`` + ``target_metadata``.

    Call from your ``alembic/env.py`` at module-level scope.
    Replaces the ~40-line boilerplate the standard async env.py
    template ships.

    Parameters
    ----------
    database_url
        SQLAlchemy URL. Async drivers (``+asyncpg``, ``+aiomysql``,
        ``+aiosqlite``, ``+psycopg`` async, ``+asyncmy``) are
        auto-detected and run via :func:`asyncio.run`. Other URLs
        take the synchronous path.
    target_metadata
        ``MetaData`` from your declarative base
        (e.g. ``Base.metadata``). Required for autogenerate to know
        the model schema.
    compare_type
        Pass to ``alembic.context.configure``. ``True`` (default)
        means autogenerate notices column-type changes; ``False``
        means it ignores them. Most consumers want ``True``.
    compare_server_default
        Pass to ``alembic.context.configure``. ``True`` (default)
        means autogenerate notices server-default changes; ``False``
        means it ignores them. Most consumers want ``True``.
    naming_convention
        Optional naming convention for auto-generated constraints
        (indexes, FK, PK). Recommended pattern::

            naming_convention = {
                "ix": "ix_%(column_0_label)s",
                "uq": "uq_%(table_name)s_%(column_0_name)s",
                "ck": "ck_%(table_name)s_%(constraint_name)s",
                "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
                "pk": "pk_%(table_name)s",
            }

        Without this, alembic generates anonymous constraint names
        that vary across DBs and produce noisy migration diffs.
    """
    from alembic import context

    if naming_convention is not None:
        target_metadata.naming_convention = naming_convention

    if context.is_offline_mode():
        _run_offline(
            url=database_url,
            target_metadata=target_metadata,
            compare_type=compare_type,
            compare_server_default=compare_server_default,
        )
        return

    is_async = database_url.startswith(_ASYNC_URL_PREFIXES)
    if is_async:
        asyncio.run(
            _run_online_async(
                url=database_url,
                target_metadata=target_metadata,
                compare_type=compare_type,
                compare_server_default=compare_server_default,
            )
        )
    else:
        _run_online_sync(
            url=database_url,
            target_metadata=target_metadata,
            compare_type=compare_type,
            compare_server_default=compare_server_default,
        )


def _run_offline(
    *,
    url: str,
    target_metadata: MetaData,
    compare_type: bool,
    compare_server_default: bool,
) -> None:
    """Offline mode — emit SQL without connecting to the database.

    Used for ``alembic upgrade --sql ...`` that pipes migration SQL
    to a file or to a DBA. No connection is opened.
    """
    from alembic import context

    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=compare_type,
        compare_server_default=compare_server_default,
    )
    with context.begin_transaction():
        context.run_migrations()


def _do_run_migrations(
    connection: Connection,
    *,
    target_metadata: MetaData,
    compare_type: bool,
    compare_server_default: bool,
) -> None:
    """Run migrations against an open SYNC connection.

    Called by both the sync and async online paths. The async path
    arrives here via ``await connection.run_sync(...)``.
    """
    from alembic import context

    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        compare_type=compare_type,
        compare_server_default=compare_server_default,
    )
    with context.begin_transaction():
        context.run_migrations()


def _run_online_sync(
    *,
    url: str,
    target_metadata: MetaData,
    compare_type: bool,
    compare_server_default: bool,
) -> None:
    """Online sync mode — open one connection, run migrations, dispose."""
    from sqlalchemy import create_engine

    connectable = create_engine(url, poolclass=pool.NullPool)
    try:
        with connectable.connect() as connection:
            _do_run_migrations(
                connection,
                target_metadata=target_metadata,
                compare_type=compare_type,
                compare_server_default=compare_server_default,
            )
    finally:
        connectable.dispose()


async def _run_online_async(
    *,
    url: str,
    target_metadata: MetaData,
    compare_type: bool,
    compare_server_default: bool,
) -> None:
    """Online async mode — async engine + ``run_sync`` for the alembic call."""
    from sqlalchemy.ext.asyncio import create_async_engine

    connectable = create_async_engine(url, poolclass=pool.NullPool)
    try:
        async with connectable.connect() as connection:
            await connection.run_sync(
                _do_run_migrations,
                target_metadata=target_metadata,
                compare_type=compare_type,
                compare_server_default=compare_server_default,
            )
    finally:
        await connectable.dispose()


__all__ = ["configure_env"]
