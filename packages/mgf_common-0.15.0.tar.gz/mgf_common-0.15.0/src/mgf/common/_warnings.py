"""Library-internal warning categories.

The closed-box redesign deprecates the v0.1 multi-call bootstrap
shape (``configure`` + ``setup_logging`` + ``setup_otel`` +
``install_excepthook`` + ``install_threading_excepthook``) and the
``EnvironmentError`` / ``make_settings_config`` names. Each
deprecated path emits :class:`MgfDeprecationWarning` so:

  - Consumer CI with ``filterwarnings = ["error"]`` (rule TS-04)
    sees the warning when running a v0.3+ install — the migration
    signal lands loudly.
  - Our OWN test suite (also ``filterwarnings = ["error"]``)
    selectively exempts the category via a per-class
    ``pyproject.toml`` filter so the v0.1 tests can keep passing
    without per-test marks.

The category is a subclass of :class:`DeprecationWarning` so
``python -W error::DeprecationWarning`` still escalates it,
matching the standard Python deprecation contract. Consumers that
want to ESCALATE our warnings to errors specifically can::

    import warnings
    from mgf.common._warnings import MgfDeprecationWarning
    warnings.filterwarnings("error", category=MgfDeprecationWarning)

This module has no other library code — keeping warning categories
in their own file means the public surface ``mgf.common._warnings``
is small and stable, and the import doesn't pull in anything
heavier (the warning classes are just empty subclasses).
"""

from __future__ import annotations


class MgfDeprecationWarning(DeprecationWarning):
    """``DeprecationWarning`` subclass for ``mgf-common``'s own deprecations.

    Used by the v0.1 → v0.3 migration shims (``configure``,
    ``setup_logging``, ``setup_otel``, ``install_excepthook``,
    ``install_threading_excepthook``, ``make_settings_config``,
    ``EnvironmentError``). Allows consumer test suites + our own
    test suite to filter our deprecations selectively while
    keeping ``filterwarnings = ["error"]`` strict for everything
    else.

    Inherits from :class:`DeprecationWarning` so the standard
    ``-W error::DeprecationWarning`` flag still escalates it —
    we're not opting out of Python's deprecation contract, only
    adding a finer-grained handle.
    """


__all__ = ["MgfDeprecationWarning"]
