"""Public ``apps.py`` — Django discovers ``AppConfig`` subclasses here.

Django's app-registry build looks for ``apps.py`` in each entry of
``INSTALLED_APPS`` and binds the ``AppConfig`` subclass found inside.
The actual implementation lives in :mod:`mgf.common.django._apps`
(private, per the closed-box convention); this module re-exports
the class at the path Django expects.
"""

from __future__ import annotations

from mgf.common.django._apps import MgfCommonConfig

__all__ = ["MgfCommonConfig"]
