""":class:`JsonFormatter` — Django ``LOGGING``-compatible JSON formatter.

Wraps :class:`mgf.common.observability.JsonFormatter` so the
``'()': '...'`` factory syntax in Django's ``LOGGING['formatters']``
dict works without the consumer having to construct a
:class:`Redactor` first.

The wrapper subclasses the underlying formatter; instances behave
identically (same OTel correlation, same redaction, same JSON
schema). The only difference is the no-arg constructor — it pulls
the default :class:`Redactor` automatically.
"""

from __future__ import annotations

from mgf.common.observability.json_formatter import JsonFormatter as _BaseJsonFormatter
from mgf.common.observability.redaction import Redactor


class JsonFormatter(_BaseJsonFormatter):
    """No-arg JSON formatter for ``LOGGING['formatters']``.

    Use in Django's logging config::

        LOGGING = {
            "version": 1,
            "formatters": {
                "json": {"()": "mgf.common.django.JsonFormatter"},
            },
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "formatter": "json",
                },
            },
            "root": {"handlers": ["console"], "level": "INFO"},
        }

    The ``()`` syntax is Django's "callable factory" indicator —
    Django constructs the formatter as ``mgf.common.django.JsonFormatter()``,
    no kwargs. The default :class:`Redactor` (built-in pattern groups)
    is wired automatically.

    To customise redaction, subclass and pass your own redactor::

        from mgf.common.observability import Redactor
        from mgf.common.django import JsonFormatter as BaseJsonFormatter

        class MyJsonFormatter(BaseJsonFormatter):
            def __init__(self) -> None:
                super().__init__()
                # OR construct fresh:
                self._redactor = Redactor(
                    extra_keys=frozenset({"my_secret"}),
                )
    """

    def __init__(self) -> None:
        super().__init__(redactor=Redactor.default())
