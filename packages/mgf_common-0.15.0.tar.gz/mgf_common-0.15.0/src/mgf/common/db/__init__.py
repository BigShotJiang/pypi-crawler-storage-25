"""``mgf.common.db`` — async SQLAlchemy session manager + tenant helper.

See: ``docs/public/recipes/db.md`` (v0.6 Phase C) and the
strategic-review §4.2.C.

Every async-SQLAlchemy + FastAPI consumer needs the same five
things:

  - An :class:`AsyncEngine` factory with sane defaults (pool sizing,
    ``pool_pre_ping``, ``pool_recycle``, ``echo`` from settings).
  - An :func:`async_sessionmaker` factory wired to that engine.
  - A FastAPI-Depends-compatible session dependency.
  - A per-request tenant-scoping context manager
    (``SET LOCAL app.current_tenant = '<uuid>'`` for Postgres RLS).
  - A lifespan helper that creates the engine at app startup +
    disposes it at shutdown.

Optional extra: ``pip install 'mgf-common[db]'`` (pulls
``sqlalchemy[asyncio]>=2.0``).

The integration is **adapter-shaped, not framework-shaped**. Nothing
here re-exports SQLAlchemy primitives or hides them. The consumer's
ORM is still vanilla SQLAlchemy 2; these helpers plug into the
seams (engine factory, sessionmaker, FastAPI lifespan / Depends).

Closed-box invariant: ``mgf.common.db`` depends on
``mgf-common[db]`` only. Consumers without a database don't pay
the import cost.
"""

from __future__ import annotations

from mgf.common.db._engine import create_engine
from mgf.common.db._lifespan import setup_db
from mgf.common.db._session import (
    create_sessionmaker,
    get_session,
    tenant_session,
)

__all__ = [
    "create_engine",
    "create_sessionmaker",
    "get_session",
    "setup_db",
    "tenant_session",
]
