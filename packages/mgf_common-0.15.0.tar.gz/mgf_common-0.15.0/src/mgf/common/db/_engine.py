"""Async SQLAlchemy engine factory.

Wraps :func:`sqlalchemy.ext.asyncio.create_async_engine` with
production-leaning defaults:

  - ``pool_pre_ping=True`` — every checkout pings the connection.
    Costs one round-trip per checkout but catches stale connections
    after DB restart / firewall reset / etc.
  - ``pool_recycle=3600`` — recycle connections older than an hour.
    Avoids the MySQL "wait_timeout" surprise + Postgres connection
    leaks.
  - ``pool_size`` / ``max_overflow`` set to conservative defaults
    that work for SQLite + scale to Postgres / MySQL.

Consumers override any default via kwargs.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine

# Production-leaning defaults. Override per-consumer as needed.
_DEFAULT_POOL_PRE_PING: bool = True
_DEFAULT_POOL_RECYCLE_SECONDS: int = 3600  # 1 hour
_DEFAULT_POOL_SIZE: int = 5
_DEFAULT_MAX_OVERFLOW: int = 10


def create_engine(
    database_url: str,
    *,
    echo: bool = False,
    pool_pre_ping: bool = _DEFAULT_POOL_PRE_PING,
    pool_recycle: int = _DEFAULT_POOL_RECYCLE_SECONDS,
    pool_size: int = _DEFAULT_POOL_SIZE,
    max_overflow: int = _DEFAULT_MAX_OVERFLOW,
    **extra: Any,
) -> AsyncEngine:
    """Build an async SQLAlchemy engine with mgf-common defaults.

    ``database_url`` follows the SQLAlchemy URL grammar — must use
    an async driver:

      - ``postgresql+asyncpg://user:pass@host/db``
      - ``mysql+aiomysql://...``
      - ``sqlite+aiosqlite://`` (in-memory) or
        ``sqlite+aiosqlite:///path/to/db.sqlite``

    ``echo=True`` logs every statement (debug only — never in prod).

    Pool settings are passed through to SQLAlchemy. SQLite ignores
    ``pool_size`` / ``max_overflow`` (it uses ``StaticPool`` /
    ``NullPool``) — the values are still accepted for shape
    consistency but have no effect.

    ``**extra`` is forwarded to :func:`create_async_engine` for
    consumers needing rare options (``connect_args``, ``isolation_level``,
    ``poolclass``, etc.).

    Returns the engine. The engine is **not yet connected** — the
    first connection attempt happens lazily on the first
    ``await engine.connect()`` or ``async_sessionmaker()`` call.
    """
    kwargs: dict[str, Any] = {
        "echo": echo,
        "pool_pre_ping": pool_pre_ping,
        "pool_recycle": pool_recycle,
    }

    # Pool sizing only applies to drivers that use a real pool.
    # SQLite uses StaticPool / NullPool; passing pool_size to those
    # raises. Detect the driver and skip pool kwargs accordingly.
    is_sqlite = database_url.startswith(("sqlite://", "sqlite+"))
    if not is_sqlite:
        kwargs["pool_size"] = pool_size
        kwargs["max_overflow"] = max_overflow

    kwargs.update(extra)
    return create_async_engine(database_url, **kwargs)


__all__ = ["create_engine"]
