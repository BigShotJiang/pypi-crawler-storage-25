"""``mgf-common doctor --standards`` — code-level conformance audit.

Read-only audit that walks the consumer project's ``src/`` and
``pyproject.toml`` looking for violations of high-signal rules
from ``docs/standards/``. Complementary to ``mgf-common
catch-up``:

  - ``catch-up`` audits **project setup** (pin staleness,
    four-gate config, CLAUDE.md presence, legacy bootstrap
    call sites).
  - ``doctor --standards`` audits **code-level conformance**
    (py.typed marker, ``__version__`` sync, naive datetime
    usage, etc.).

Both are read-only by design. ``catch-up`` ships a separate
``--apply`` mode for the mechanical fixes it owns; this audit
has no auto-fix path — every finding is a human decision
about how to refactor.

The shipped check set is deliberately small (four checks for
the first cut) so the output stays scannable. Future check
additions land here as new ``_check_*`` functions added to the
``CHECKS`` tuple.

Exit code:
  - ``0``   — every check passed (✓) or only warned (⚠).
  - ``2``   — at least one check FAILED (✗) or the project
              shape couldn't be detected.
"""

from __future__ import annotations

import ast
import sys
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from mgf.common.cli._exit_codes import EXIT_OPERATION_ERROR, EXIT_SUCCESS

if TYPE_CHECKING:
    from collections.abc import Iterator


@dataclass(frozen=True)
class Finding:
    """One audit result. Bound to a rule, has a tier + message."""

    rule_id: str
    tier: str  # "ok" / "warn" / "fail"
    message: str


# ---------------------------------------------------------------------------
# Project shape discovery
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _ProjectShape:
    """Snapshot of the audited project — enough for every check
    to consult without re-parsing pyproject for itself."""

    root: Path
    pyproject: dict[str, object]
    src_dir: Path
    package_root: Path
    package_name: str
    declared_version: str


def _discover_project(start: Path) -> _ProjectShape | None:
    """Walk up from ``start`` looking for a ``pyproject.toml`` +
    a ``src/`` layout. Return None if either is missing or the
    package shape can't be inferred."""
    cur = start.resolve()
    while True:
        py = cur / "pyproject.toml"
        if py.is_file():
            break
        if cur.parent == cur:
            return None
        cur = cur.parent

    try:
        pyproject = tomllib.loads(py.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return None

    project = pyproject.get("project") or {}
    if not isinstance(project, dict):
        return None
    package_name = str(project.get("name", "")).strip()
    declared_version = str(project.get("version", "")).strip()
    if not package_name:
        return None

    src_dir = cur / "src"
    if not src_dir.is_dir():
        return None

    package_root = _find_package_root(src_dir, package_name)
    if package_root is None:
        return None

    return _ProjectShape(
        root=cur,
        pyproject=pyproject,
        src_dir=src_dir,
        package_root=package_root,
        package_name=package_name,
        declared_version=declared_version,
    )


def _find_package_root(src_dir: Path, package_name: str) -> Path | None:
    """Resolve ``src/<package_name>/`` for both flat and namespace
    layouts. Hyphens in the distribution name → underscores in
    the import path; namespace packages live under
    ``src/<ns>/<sub>/`` (e.g. ``src/mgf/common/``).
    """
    underscore_name = package_name.replace("-", "_")
    candidates = [
        src_dir / underscore_name,
        # Namespace shape: src/<ns>/<sub>/ where the dist is <ns>-<sub>.
        # E.g. mgf-common → src/mgf/common; mgf-apiprobe → src/mgf/apiprobe.
        *(
            src_dir / parts[0] / "/".join(parts[1:])
            for parts in [underscore_name.split("_", 1)]
            if len(parts) == 2
        ),
    ]
    for c in candidates:
        if (c / "__init__.py").is_file():
            return c
    return None


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------


def _check_py_typed_marker(shape: _ProjectShape) -> Finding:
    """AP-09 — every typed package MUST ship a ``py.typed`` marker."""
    marker = shape.package_root / "py.typed"
    if marker.is_file():
        return Finding(
            "AP-09",
            "ok",
            f"py.typed marker present at "
            f"{marker.relative_to(shape.root)}",
        )
    return Finding(
        "AP-09",
        "fail",
        f"py.typed marker missing at "
        f"{marker.relative_to(shape.root)} — downstream "
        f"`mypy --strict` will not consume your annotations. "
        f"`touch {marker.relative_to(shape.root)}` and add it to "
        f"the wheel's package data.",
    )


def _check_version_sync(shape: _ProjectShape) -> Finding:
    """AP-13 — ``__version__`` MUST match ``pyproject.toml::project.version``."""
    if not shape.declared_version:
        return Finding(
            "AP-13",
            "warn",
            "pyproject.toml has no [project] version field — "
            "either using dynamic versioning (no audit possible) "
            "or the field is missing.",
        )
    runtime = _read_dunder_version(shape.package_root)
    if runtime is None:
        return Finding(
            "AP-13",
            "warn",
            f"package {shape.package_name} has no `__version__` "
            f"attribute discoverable in `__init__.py` or "
            f"`_version.py`. Pin it to "
            f"`pyproject.toml::project.version` "
            f"({shape.declared_version!r}) so consumers can read "
            f"`<pkg>.__version__`.",
        )
    if runtime != shape.declared_version:
        return Finding(
            "AP-13",
            "fail",
            f"version drift: pyproject says "
            f"{shape.declared_version!r}, runtime "
            f"`{shape.package_name}.__version__` says "
            f"{runtime!r}. They MUST match — bump both together.",
        )
    return Finding(
        "AP-13",
        "ok",
        f"__version__ matches pyproject ({runtime!r})",
    )


def _check_filterwarnings(shape: _ProjectShape) -> Finding:
    """TS-04 — ``filterwarnings = ["error", ...]`` MUST be set in
    pytest config so warnings escalate to errors during tests."""
    tool = shape.pyproject.get("tool")
    pytest_cfg: object = {}
    if isinstance(tool, dict):
        pytest_section = tool.get("pytest")
        if isinstance(pytest_section, dict):
            pytest_cfg = pytest_section.get("ini_options", {})
    fw = pytest_cfg.get("filterwarnings") if isinstance(pytest_cfg, dict) else None
    if not isinstance(fw, list) or not fw:
        return Finding(
            "TS-04",
            "fail",
            "[tool.pytest.ini_options] filterwarnings is not "
            "configured — DeprecationWarnings (including "
            "MgfDeprecationWarning) won't escalate to test "
            "failures. Add `filterwarnings = [\"error\", ...]` to "
            "pyproject.toml.",
        )
    if "error" not in fw:
        return Finding(
            "TS-04",
            "fail",
            f"[tool.pytest.ini_options] filterwarnings = {fw!r} — "
            f"the first element MUST be 'error' so unexpected "
            f"warnings break the build.",
        )
    return Finding(
        "TS-04",
        "ok",
        f"pytest filterwarnings escalates ({len(fw)} entries; first is 'error')",
    )


def _check_naive_datetime(shape: _ProjectShape) -> Finding:
    """DP-12 — naive ``datetime`` usage is forbidden. Walk
    ``src/`` for ``datetime.now()`` without ``tzinfo`` and
    ``datetime.utcnow()``."""
    violations: list[str] = []
    for py in _iter_py_files(shape.package_root):
        try:
            tree = ast.parse(py.read_text(encoding="utf-8"))
        except (OSError, SyntaxError):
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            # Match `datetime.now(...)` / `datetime.utcnow()`.
            if isinstance(func, ast.Attribute):
                attr = func.attr
                base = func.value
                base_name = (
                    base.id if isinstance(base, ast.Name) else None
                )
                if base_name == "datetime" and attr == "utcnow":
                    violations.append(
                        f"  {py.relative_to(shape.root)}:{node.lineno}: "
                        f"datetime.utcnow() — use datetime.now(UTC)"
                    )
                if (
                    base_name == "datetime"
                    and attr == "now"
                    and not _has_kwarg(node, "tz")
                    and not node.args
                ):
                    violations.append(
                        f"  {py.relative_to(shape.root)}:{node.lineno}: "
                        f"datetime.now() with no tzinfo — pass UTC explicitly"
                    )
    if not violations:
        return Finding(
            "DP-12",
            "ok",
            "no naive datetime calls in package source",
        )
    return Finding(
        "DP-12",
        "fail",
        "naive datetime calls (DP-12 forbids these — they "
        "produce ambiguous timestamps across DST + timezone "
        "boundaries):\n" + "\n".join(violations[:20])
        + (
            f"\n  ... and {len(violations) - 20} more"
            if len(violations) > 20
            else ""
        ),
    )


def _has_kwarg(call: ast.Call, name: str) -> bool:
    """True iff ``call`` has a keyword argument named ``name``."""
    return any(kw.arg == name for kw in call.keywords)


def _iter_py_files(package_root: Path) -> Iterator[Path]:
    """Walk every ``*.py`` under ``package_root`` (skipping
    ``__pycache__`` and underscore-prefixed test fixtures)."""
    for p in package_root.rglob("*.py"):
        if any(part == "__pycache__" for part in p.parts):
            continue
        yield p


def _read_dunder_version(package_root: Path) -> str | None:
    """Find ``__version__ = "..."`` in the package's ``__init__.py``
    or a ``_version.py`` sibling."""
    for candidate in (
        package_root / "__init__.py",
        package_root / "_version.py",
    ):
        if not candidate.is_file():
            continue
        try:
            tree = ast.parse(candidate.read_text(encoding="utf-8"))
        except (OSError, SyntaxError):
            continue
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Assign)
                and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id == "__version__"
                and isinstance(node.value, ast.Constant)
                and isinstance(node.value.value, str)
            ):
                return node.value.value
    return None


# Order matters — output reads top-down.
CHECKS = (
    _check_py_typed_marker,
    _check_version_sync,
    _check_filterwarnings,
    _check_naive_datetime,
)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def doctor_standards(*, root: Path | None = None) -> int:
    """Run the standards-conformance audit; print + exit code.

    Returns ``0`` on full pass / warnings, ``EXIT_OPERATION_ERROR``
    on any FAIL.
    """
    shape = _discover_project(root or Path.cwd())
    if shape is None:
        print(
            "mgf-common doctor --standards: cannot detect project "
            "shape (need a pyproject.toml with [project] name + a "
            "src/ layout). Run from a project root.",
            file=sys.stderr,
        )
        return EXIT_OPERATION_ERROR

    print(
        f"mgf-common doctor --standards — auditing "
        f"{shape.package_name} at {shape.root}\n"
    )

    findings = [check(shape) for check in CHECKS]
    fails = sum(1 for f in findings if f.tier == "fail")
    warns = sum(1 for f in findings if f.tier == "warn")
    oks = sum(1 for f in findings if f.tier == "ok")

    glyph = {"ok": "✓", "warn": "⚠", "fail": "✗"}
    for f in findings:
        print(f"  {glyph[f.tier]} {f.rule_id}  {f.message}\n")

    print(
        f"\n{oks} pass · {warns} warn · {fails} fail "
        f"({len(findings)} checks total)"
    )
    if fails:
        print(
            "\nAt least one rule failed. Read "
            "`docs/standards/<topic>.md` for the rule rationale "
            "(`mgf-common standards <topic>`)."
        )
        return EXIT_OPERATION_ERROR
    return EXIT_SUCCESS


__all__ = ["doctor_standards"]
