"""``mgf-common`` console-script entry point.

Four subcommands shipped through Phase 7 (now registered via the
v0.4 Phase E registry):

  - ``explain``  — print the active settings with provenance.
  - ``validate`` — schema-validate a YAML file.
  - ``doctor``   — install-state and wiring health checks.
  - ``migrate``  — apply mechanical version-rename codemods.

The entry point is wired in ``pyproject.toml``::

    [project.scripts]
    mgf-common = "mgf.common.cli._mgfcli:main"

Argument parsing uses :mod:`argparse` from the stdlib — no
additional dependency on ``click`` or ``typer``. The library does
not want to inflict a CLI framework choice on consumers; argparse
is the lowest common denominator + ships with Python.

v0.4 Phase E refactor: the four built-in subcommands are
pre-registered against the
:mod:`mgf.common.cli._subcommand_registry` registry at import
time, and dispatch flows through
:func:`mgf.common.cli._subcommand_registry.dispatch`. This means
consumers can register their own subcommands and they show up
on every ``mgf-common <subcommand>`` invocation alongside the
built-ins. Consumers can also build their own top-level CLI on
top of the same registry via
:func:`mgf.common.cli._subcommand_registry.build_cli`.
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from mgf.common.cli._bench import add_bench_args, run_bench
from mgf.common.cli._catch_up import add_catch_up_args, run_catch_up
from mgf.common.cli._doctor import add_doctor_args, run_doctor
from mgf.common.cli._explain import add_explain_args, run_explain
from mgf.common.cli._feedback import add_feedback_args, run_feedback
from mgf.common.cli._init_project import (
    add_init_project_args,
    run_init_project,
)
from mgf.common.cli._migrate import add_migrate_args, run_migrate
from mgf.common.cli._standards import add_standards_args, run_standards
from mgf.common.cli._subcommand_registry import (
    build_cli,
    dispatch,
    register_cli_subcommand,
)
from mgf.common.cli._validate import add_validate_args, run_validate

if TYPE_CHECKING:
    import argparse
    from collections.abc import Sequence


# ---------------------------------------------------------------------------
# Built-in subcommand pre-registration
# ---------------------------------------------------------------------------
#
# Registered at module import time so any caller of ``build_cli`` /
# ``mgf.common.cli._mgfcli.main`` finds the four built-ins available.
# Consumer-registered subcommands stack on top.

register_cli_subcommand(
    "explain",
    handler=run_explain,
    help="Print the active MgfSettings with each field's source.",
    parser_setup=add_explain_args,
)

register_cli_subcommand(
    "validate",
    handler=run_validate,
    help="Validate a YAML config file against the MgfSettings schema.",
    parser_setup=add_validate_args,
)

register_cli_subcommand(
    "doctor",
    handler=run_doctor,
    help="Run install-state and wiring health checks.",
    parser_setup=add_doctor_args,
)

register_cli_subcommand(
    "migrate",
    handler=run_migrate,
    help=(
        "Apply mechanical renames to migrate consumer source from "
        "one mgf-common version to another."
    ),
    parser_setup=add_migrate_args,
)

register_cli_subcommand(
    "bench",
    handler=run_bench,
    help=(
        "Run microbench numbers for hot paths "
        "(current_context, bootstrap, log call, redaction)."
    ),
    parser_setup=add_bench_args,
)

register_cli_subcommand(
    "standards",
    handler=run_standards,
    help=(
        "Print engineering-standards docs (DESIGN_PRINCIPLES, LOGGING, "
        "SECURITY, etc.) — single source of truth for cross-project rules."
    ),
    parser_setup=add_standards_args,
)

register_cli_subcommand(
    "init-project",
    handler=run_init_project,
    help=(
        "Scaffold a new mgf-common-aligned project: docs/CLAUDE.md + "
        ".claude/settings.json + pyproject snippet for the four gates."
    ),
    parser_setup=add_init_project_args,
)

register_cli_subcommand(
    "feedback",
    handler=run_feedback,
    help=(
        "Print the FEEDBACK.md submission flow + entry template — "
        "the canonical channel for sharp edges, roadmap requests, "
        "and design questions."
    ),
    parser_setup=add_feedback_args,
)

register_cli_subcommand(
    "catch-up",
    handler=run_catch_up,
    help=(
        "Audit an existing project against the current mgf-common "
        "engineering standards; --apply for mechanical fixes."
    ),
    parser_setup=add_catch_up_args,
)


def build_parser() -> argparse.ArgumentParser:
    """Construct the top-level argparse parser + every subparser.

    Backward-compat alias for :func:`build_cli` with no arguments.
    Existing tests + consumers that pinned this name keep working.
    Prefer :func:`mgf.common.cli.build_cli` going forward — it
    exposes the ``prog`` and ``include_builtins`` kwargs.
    """
    return build_cli()


def main(argv: Sequence[str] | None = None) -> int:
    """Console-script entry point.

    Returns the exit code (NEVER raises). When called with no
    subcommand, prints the help text to stderr and returns
    :data:`mgf.common.cli.EXIT_UNKNOWN`. Dispatch flows through
    the v0.4 Phase E registry; consumer-registered subcommands
    are first-class.
    """
    if argv is None:
        argv = sys.argv[1:]

    parser = build_cli()
    args = parser.parse_args(list(argv))
    return dispatch(args, parser=parser)


__all__ = [
    "build_parser",
    "main",
]
