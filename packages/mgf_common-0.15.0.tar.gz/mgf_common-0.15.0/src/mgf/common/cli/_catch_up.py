"""``mgf-common catch-up`` — audit + update an existing project against current standards.

Closes the v0.11.0 deliverable: existing projects (VManager,
inthewords, future adopters) need an audit-and-update flow, not
the create-from-scratch shape ``init-project`` ships. ``catch-up``:

  - Reads the project's pyproject.toml + docs/CLAUDE.md +
    .claude/settings.json + (optionally) src/.
  - Compares against the current init-project templates +
    standards.
  - Prints a drift report (✅ / ⚠️ / 🔴 per row).
  - With ``--apply``, performs ONLY safe mechanical updates:
    creates missing files, refreshes the auto-managed CLAUDE.md
    block (between BEGIN/END markers), backs up originals.
    Pyproject snippets and v0.1-pattern migrations are surfaced
    as suggestions, not auto-modified — too easy to clobber
    project-specific config.

Read-only by default. ``--apply`` is the explicit opt-in.
"""

from __future__ import annotations

import re
import sys
import time
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from mgf.common.cli._init_project import (
    CLAUDE_MD_BEGIN_MARKER,
    CLAUDE_MD_END_MARKER,
    _render_claude_md,
    _render_claude_settings,
)

if TYPE_CHECKING:
    import argparse
    from collections.abc import Callable


_Severity = Literal["ok", "warn", "fail", "info"]
_SEVERITY_ICON: dict[_Severity, str] = {
    "ok": "✅",
    "warn": "⚠️ ",
    "fail": "🔴",
    "info": "ℹ️ ",  # noqa: RUF001 — INFORMATION SOURCE is intentional
}


class _Finding:
    """One row in the audit report."""

    __slots__ = ("detail", "fix", "severity", "title")

    def __init__(
        self,
        severity: _Severity,
        title: str,
        detail: str,
        fix: Callable[[Path], str] | None = None,
    ) -> None:
        self.severity = severity
        self.title = title
        self.detail = detail
        self.fix = fix


def add_catch_up_args(parser: argparse.ArgumentParser) -> None:
    """Register the ``catch-up`` subcommand's arguments."""
    parser.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help=(
            "Target project root (default: current working directory). "
            "Must contain a pyproject.toml or be the root of a project "
            "that depends on mgf-common."
        ),
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help=(
            "Apply mechanical fixes (create missing CLAUDE.md / "
            ".claude/settings.json; refresh CLAUDE.md auto-block "
            "between BEGIN/END markers). Originals are backed up to "
            "<file>.bak.<timestamp>. Read-only without this flag."
        ),
    )
    parser.add_argument(
        "--name",
        help=(
            "Project name (used when CLAUDE.md is missing entirely "
            "and we need to render a fresh one). Defaults to the "
            "project's name from pyproject.toml."
        ),
    )
    parser.add_argument(
        "--kind",
        choices=("cli", "fastapi", "django", "library", "service"),
        help=(
            "Project kind (used when CLAUDE.md is missing entirely). "
            "Defaults to 'library' if it can't be guessed."
        ),
    )


def run_catch_up(args: argparse.Namespace) -> int:
    """Run the audit, optionally apply fixes."""
    target_dir = args.path.resolve()
    if not target_dir.is_dir():
        print(
            f"error: target path {target_dir} is not a directory.",
            file=sys.stderr,
        )
        return 1

    project_name, project_kind = _resolve_project_identity(target_dir, args)

    findings: list[_Finding] = []
    findings.append(_check_pyproject_pin(target_dir))
    findings.append(_check_four_gates(target_dir))
    findings.append(_check_claude_md(target_dir, project_name, project_kind))
    findings.append(_check_claude_settings(target_dir, project_kind))
    findings.append(_check_v01_patterns(target_dir))

    _print_report(findings, target_dir, project_name, project_kind)

    if not args.apply:
        # Read-only mode. Done.
        return _exit_code_for(findings)

    # --apply mode: run any fixes that are safe + automatic.
    print()
    print("Applying mechanical fixes …")
    applied = 0
    for finding in findings:
        if finding.fix is None:
            continue
        result = finding.fix(target_dir)
        print(f"  {_SEVERITY_ICON['info']} {finding.title}: {result}")
        applied += 1
    if applied == 0:
        print("  (nothing to apply — everything mechanical is already current.)")
    else:
        print()
        print(
            f"Applied {applied} mechanical fix(es). Re-run "
            "`mgf-common catch-up` to verify, or check the .bak.* "
            "backups if anything looks wrong.",
        )

    return _exit_code_for(findings)


# ---------------------------------------------------------------------------
# Identity resolution.
# ---------------------------------------------------------------------------


def _resolve_project_identity(
    target_dir: Path,
    args: argparse.Namespace,
) -> tuple[str, str]:
    """Resolve project name + kind from CLI args + pyproject.toml."""
    name = args.name
    kind = args.kind

    if name is None:
        name = _read_pyproject_name(target_dir) or target_dir.name
    if kind is None:
        kind = "library"

    return name, kind


def _read_pyproject_name(target_dir: Path) -> str | None:
    """Pull `[project] name = "..."` from pyproject.toml."""
    pyproject = target_dir / "pyproject.toml"
    if not pyproject.is_file():
        return None
    try:
        text = pyproject.read_text(encoding="utf-8")
    except OSError:
        return None
    match = re.search(
        r'^\s*name\s*=\s*"([^"]+)"',
        text,
        re.MULTILINE,
    )
    return match.group(1) if match else None


# ---------------------------------------------------------------------------
# Individual audit checks. Each returns one _Finding.
# ---------------------------------------------------------------------------


def _check_pyproject_pin(target_dir: Path) -> _Finding:
    """Is the mgf-common pin in pyproject.toml current?

    v0.12.0+: when the pin's upper bound excludes the running
    mgf-common version (i.e., pin is stale), the finding gets a
    ``fix=`` callable that ``--apply`` can invoke to rewrite the
    line to a current 2-minor window (``>=<current>,<<major>.<minor+2>``).
    Conservative: only rewrites lines whose shape we fully understand.
    """
    pyproject = target_dir / "pyproject.toml"
    if not pyproject.is_file():
        return _Finding(
            "warn",
            "pyproject.toml — mgf-common pin",
            "no pyproject.toml found; standards adoption usually needs one.",
        )

    try:
        text = pyproject.read_text(encoding="utf-8")
    except OSError as exc:
        return _Finding(
            "fail",
            "pyproject.toml — mgf-common pin",
            f"could not read pyproject.toml: {exc}",
        )

    pin_match = re.search(
        r'"(mgf-common(?:\[[^\]]+\])?)\s*([^"]*)"',
        text,
    )
    if pin_match is None:
        return _Finding(
            "warn",
            "pyproject.toml — mgf-common pin",
            "no `mgf-common` dep found. Add it to "
            "`[project] dependencies`. See `mgf-common standards "
            "components` for the canonical pin shape.",
        )

    from mgf.common import __version__ as current

    pin_extras_part = pin_match.group(1)  # e.g., "mgf-common" or "mgf-common[fastapi]"
    pin_constraint = pin_match.group(2).strip(", ")
    if not pin_constraint:
        return _Finding(
            "info",
            "pyproject.toml — mgf-common pin",
            f"unpinned dep on `mgf-common`. Suggest pinning to "
            f"`>={current},<{_next_major(current)}`.",
        )

    # Determine if the pin is stale: does the upper bound exclude
    # the running mgf-common version?
    is_stale = _pin_is_stale(pin_constraint, current)
    if not is_stale:
        return _Finding(
            "ok",
            "pyproject.toml — mgf-common pin",
            f"declared (constraint: `{pin_constraint}`; current "
            f"mgf-common: `{current}`). Pin window includes "
            f"current; nothing to do.",
        )

    new_constraint = f">={current},<{_next_major(current)}"
    return _Finding(
        "warn",
        "pyproject.toml — mgf-common pin",
        f"STALE: declared `{pin_constraint}` but current "
        f"mgf-common is `{current}` — the upper bound excludes it. "
        f"Suggest bumping to `{new_constraint}` (2-minor window). "
        f"Run with --apply to rewrite the line; backup written.",
        fix=lambda root: _apply_bump_pin(
            root,
            extras_part=pin_extras_part,
            old_constraint=pin_constraint,
            new_constraint=new_constraint,
        ),
    )


def _pin_is_stale(constraint: str, current_version: str) -> bool:
    """Return True if ``current_version`` is excluded by the pin's upper bound.

    Parses the constraint string (PEP 440-ish, comma-separated). Recognises
    ``<X.Y[.Z]`` upper bounds (the canonical shape mgf-common projects
    use). Anything else (no upper bound, unparseable, or non-`<` bound)
    returns False — better to under-flag than to rewrite blindly.
    """
    upper_match = re.search(r"<\s*([0-9]+)\.([0-9]+)(?:\.([0-9]+))?", constraint)
    if upper_match is None:
        return False  # No `<X.Y` upper bound — can't reason; trust the user.

    upper_major = int(upper_match.group(1))
    upper_minor = int(upper_match.group(2))
    upper_patch = int(upper_match.group(3)) if upper_match.group(3) else 0

    cur_parts = current_version.split(".")
    if len(cur_parts) < 2:
        return False
    try:
        cur_major = int(cur_parts[0])
        cur_minor = int(cur_parts[1])
        cur_patch = int(cur_parts[2]) if len(cur_parts) >= 3 else 0
    except ValueError:
        return False

    # Strict-less than comparison: stale iff (cur_major, cur_minor, cur_patch)
    # >= upper bound.
    return (cur_major, cur_minor, cur_patch) >= (upper_major, upper_minor, upper_patch)


def _apply_bump_pin(
    target_dir: Path,
    *,
    extras_part: str,
    old_constraint: str,
    new_constraint: str,
) -> str:
    """Rewrite the mgf-common pin line in pyproject.toml.

    Conservative: targets ONLY the specific
    ``"mgf-common[…]<old_constraint>"`` substring, leaves the rest of
    the file untouched. Writes a backup before modifying.
    """
    pyproject = target_dir / "pyproject.toml"
    original = pyproject.read_text(encoding="utf-8")

    # Build the exact substring to find (so we don't accidentally
    # rewrite mentions of mgf-common in comments / urls).
    old_pin_str = f'"{extras_part}{old_constraint}"'
    # Some projects write "mgf-common>=0.1.0,<0.2" with no space; some
    # might have spaces. Try the exact form first.
    if old_pin_str not in original:
        # The match-group may have captured a slightly different form
        # (with spaces stripped vs preserved). Re-derive from the file.
        regex = re.compile(
            r'"(' + re.escape(extras_part) + r')\s*([^"]*)"',
        )
        match = regex.search(original)
        if match is None:
            return "could not locate the mgf-common pin line; manual edit required."
        old_pin_str = match.group(0)

    new_pin_str = f'"{extras_part}{new_constraint}"'
    rewritten = original.replace(old_pin_str, new_pin_str, 1)

    if rewritten == original:
        return "could not locate the mgf-common pin line; manual edit required."

    backup = pyproject.with_suffix(f".toml.bak.{int(time.time())}")
    backup.write_text(original, encoding="utf-8")
    pyproject.write_text(rewritten, encoding="utf-8")

    return f"bumped pin to `{new_constraint}` in {pyproject} (backup: {backup.name})"


def _check_four_gates(target_dir: Path) -> _Finding:
    """Are the four gates configured in pyproject.toml?

    Uses :mod:`tomllib` (stdlib in Python 3.11+) to parse the file
    properly rather than substring-matching, which gave false
    positives on the multi-line array form
    (``filterwarnings = [\\n    "error",\\n]``).
    """
    import tomllib

    pyproject = target_dir / "pyproject.toml"
    if not pyproject.is_file():
        return _Finding(
            "warn",
            "pyproject.toml — four gates",
            "no pyproject.toml; cannot check gate config.",
        )
    try:
        with pyproject.open("rb") as fh:
            data = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError) as exc:
        return _Finding(
            "fail",
            "pyproject.toml — four gates",
            f"could not parse pyproject.toml: {exc}",
        )

    tool = data.get("tool", {})
    missing: list[str] = []

    # Ruff: presence of the table is enough; specific rule selection
    # is consumer-customisable.
    if "ruff" not in tool:
        missing.append("[tool.ruff]")

    # mypy: requires the table AND `strict = true` (per DP-04).
    mypy_cfg = tool.get("mypy", {})
    if not mypy_cfg or mypy_cfg.get("strict") is not True:
        missing.append("[tool.mypy] with strict = true")

    # pytest: requires the table AND filterwarnings contains "error"
    # (per TS-04). Accepts both the single-line and multi-line array
    # forms — they produce the same parsed list.
    pytest_cfg = tool.get("pytest", {}).get("ini_options", {})
    fw = pytest_cfg.get("filterwarnings", [])
    if not pytest_cfg or "error" not in fw:
        missing.append("[tool.pytest.ini_options] with filterwarnings = ['error']")

    # coverage: any of the coverage tables (run / report / paths) is
    # acceptable as a signal that coverage is configured. fail_under
    # specifically is in [tool.coverage.report].
    coverage_cfg = tool.get("coverage", {})
    if not coverage_cfg:
        missing.append("[tool.coverage.report] with fail_under")

    if not missing:
        return _Finding(
            "ok",
            "pyproject.toml — four gates",
            "ruff / mypy strict / pytest filterwarnings=error / "
            "coverage threshold all configured.",
        )

    return _Finding(
        "warn",
        "pyproject.toml — four gates",
        "missing or partial: "
        + "; ".join(missing)
        + ". Run `mgf-common init-project --kind <kind> --dry-run "
        "--path <tmp>` to print a fresh four-gate snippet, or paste "
        "from the recipe at `mgf-common standards components`.",
    )


def _check_claude_md(
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> _Finding:
    """Does docs/CLAUDE.md exist + does it have the auto-managed block?"""
    claude_md = target_dir / "docs" / "CLAUDE.md"
    if not claude_md.is_file():
        return _Finding(
            "fail",
            "docs/CLAUDE.md",
            "missing. Claude won't auto-load any standards on session "
            "start — manual prompting required for every task. "
            "Run with --apply to create a fresh CLAUDE.md from the "
            "current template.",
            fix=lambda root: _apply_create_claude_md(
                root,
                project_name,
                project_kind,
            ),
        )

    try:
        content = claude_md.read_text(encoding="utf-8")
    except OSError as exc:
        return _Finding(
            "fail",
            "docs/CLAUDE.md",
            f"could not read: {exc}",
        )

    has_begin = CLAUDE_MD_BEGIN_MARKER in content
    has_end = CLAUDE_MD_END_MARKER in content

    if not has_begin or not has_end:
        return _Finding(
            "warn",
            "docs/CLAUDE.md",
            "exists but lacks BEGIN/END auto-managed markers — "
            "either pre-v0.11 init-project output or hand-written. "
            "catch-up cannot refresh the auto-block in place. Either "
            "re-run `mgf-common init-project --force` (clobbers your "
            "project-specific lookup section — back it up first), or "
            "manually add the BEGIN/END markers around the standards "
            "section.",
        )

    # Compute the current expected auto-block; compare to existing.
    expected = _render_claude_md(project_name, project_kind)
    expected_block = _extract_auto_block(expected)
    actual_block = _extract_auto_block(content)

    if expected_block == actual_block:
        return _Finding(
            "ok",
            "docs/CLAUDE.md",
            "exists with current auto-managed block. "
            "Project-specific lookup preserved.",
        )

    return _Finding(
        "warn",
        "docs/CLAUDE.md",
        "exists with auto-block markers, but the auto-block content "
        "is stale relative to the current template (rules may have "
        "been added / wording changed in newer mgf-common). Run with "
        "--apply to refresh just the auto-block.",
        fix=lambda root: _apply_refresh_claude_md(
            root,
            project_name,
            project_kind,
        ),
    )


def _check_claude_settings(
    target_dir: Path,
    project_kind: str,
) -> _Finding:
    """Does .claude/settings.json exist?"""
    settings = target_dir / ".claude" / "settings.json"
    if not settings.is_file():
        return _Finding(
            "warn",
            ".claude/settings.json",
            "missing. Without it, Claude prompts for every Bash "
            "command — friction in normal dev. Run with --apply to "
            "create one with safe defaults for this project kind.",
            fix=lambda root: _apply_create_claude_settings(root, project_kind),
        )
    return _Finding(
        "ok",
        ".claude/settings.json",
        "exists. (catch-up doesn't audit allow-list contents — "
        "your team customizes them.)",
    )


def _check_v01_patterns(target_dir: Path) -> _Finding:
    """Grep src/ for v0.1-pattern usages that should migrate to bootstrap()."""
    src = target_dir / "src"
    if not src.is_dir():
        # Try the project root as a fallback.
        src = target_dir

    patterns: list[tuple[str, str]] = [
        ("mgf.common.configure(", "→ `with mgf.common.bootstrap(...)` (v0.3+)"),
        ("make_settings_config(", "→ `settings_config(...)` (v0.3+)"),
        ("setup_logging(", "→ folded into `bootstrap()` (v0.3+)"),
        ("setup_otel(", "→ folded into `bootstrap()` (v0.3+)"),
        ("install_excepthook(", "→ folded into `bootstrap()` (v0.3+)"),
        ("install_threading_excepthook(", "→ folded into `bootstrap()` (v0.3+)"),
    ]

    findings: list[str] = []
    for needle, suggestion in patterns:
        count = _count_matches(src, needle)
        if count > 0:
            findings.append(f"`{needle}` x {count}: {suggestion}")

    if not findings:
        return _Finding(
            "ok",
            "v0.1-pattern usage",
            "no legacy `configure() / setup_logging() / "
            "install_excepthook()` calls found.",
        )

    return _Finding(
        "warn",
        "v0.1-pattern usage",
        "legacy v0.1 call sites found: "
        + "; ".join(findings)
        + ". These still work via deprecation cycle, but the "
        "v0.3+ `bootstrap()` shape is the canonical replacement. "
        "Migration is NOT mechanical (the call shape changes from "
        "5 separate calls to 1 context manager); catch-up will not "
        "auto-modify. See `mgf-common standards design` for the "
        "bootstrap() pattern.",
    )


def _count_matches(root: Path, needle: str) -> int:
    """Count how many times ``needle`` appears across .py files under ``root``."""
    if not root.is_dir():
        return 0
    total = 0
    for path in root.rglob("*.py"):
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        total += text.count(needle)
    return total


# ---------------------------------------------------------------------------
# Apply functions. Called only when --apply is passed.
# ---------------------------------------------------------------------------


def _apply_create_claude_md(
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> str:
    """Create a fresh CLAUDE.md."""
    path = target_dir / "docs" / "CLAUDE.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_render_claude_md(project_name, project_kind), encoding="utf-8")
    return f"created {path}"


def _apply_refresh_claude_md(
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> str:
    """Refresh just the auto-managed block of an existing CLAUDE.md."""
    path = target_dir / "docs" / "CLAUDE.md"
    original = path.read_text(encoding="utf-8")

    # Backup before modifying.
    backup = path.with_suffix(f".md.bak.{int(time.time())}")
    backup.write_text(original, encoding="utf-8")

    new_full = _render_claude_md(project_name, project_kind)
    new_auto_block = _extract_auto_block(new_full)

    # Splice: keep everything BEFORE the BEGIN marker + the new
    # auto-block + everything AFTER the END marker.
    refreshed = _splice_auto_block(original, new_auto_block)
    path.write_text(refreshed, encoding="utf-8")
    return f"refreshed auto-block in {path} (backup: {backup.name})"


def _apply_create_claude_settings(target_dir: Path, project_kind: str) -> str:
    """Create a fresh .claude/settings.json."""
    path = target_dir / ".claude" / "settings.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_render_claude_settings(project_kind), encoding="utf-8")
    return f"created {path}"


# ---------------------------------------------------------------------------
# Auto-block extraction + splicing.
# ---------------------------------------------------------------------------


def _extract_auto_block(content: str) -> str:
    """Return the substring between BEGIN and END markers (markers excluded)."""
    begin_idx = content.find(CLAUDE_MD_BEGIN_MARKER)
    end_idx = content.find(CLAUDE_MD_END_MARKER)
    if begin_idx == -1 or end_idx == -1 or end_idx < begin_idx:
        return ""
    # Slice from end-of-BEGIN-marker-line to start-of-END-marker-line.
    begin_line_end = content.find("\n", begin_idx)
    if begin_line_end == -1:
        return ""
    return content[begin_line_end + 1 : end_idx]


def _splice_auto_block(original: str, new_block: str) -> str:
    """Replace original's auto-block with new_block (keep markers + outside)."""
    begin_idx = original.find(CLAUDE_MD_BEGIN_MARKER)
    end_idx = original.find(CLAUDE_MD_END_MARKER)
    if begin_idx == -1 or end_idx == -1 or end_idx < begin_idx:
        # Shouldn't be called when markers are missing, but be safe.
        return original

    # Find the end of the BEGIN marker's line (so we keep the marker
    # itself but replace everything below it up to the END marker).
    begin_line_end = original.find("\n", begin_idx)
    return original[: begin_line_end + 1] + new_block + original[end_idx:]


# ---------------------------------------------------------------------------
# Reporting.
# ---------------------------------------------------------------------------


def _print_report(
    findings: list[_Finding],
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> None:
    """Print the audit report."""
    from mgf.common import __version__

    print(
        f"mgf-common catch-up — auditing {target_dir}",
    )
    print(
        f"  Project:        {project_name} (kind: {project_kind})",
    )
    print(
        f"  mgf-common:     {__version__}",
    )
    print()
    print("Drift report:")
    print()
    for finding in findings:
        icon = _SEVERITY_ICON[finding.severity]
        print(f"  {icon} {finding.title}")
        # Indent the detail.
        for line in finding.detail.splitlines() or [""]:
            print(f"      {line}")
        print()

    fixable = sum(1 for f in findings if f.fix is not None)
    if fixable > 0:
        print(
            f"{fixable} finding(s) have mechanical fixes. "
            f"Re-run with `--apply` to apply (originals backed up).",
        )


def _exit_code_for(findings: list[_Finding]) -> int:
    """Exit non-zero if anything failed; warnings are zero (advisory)."""
    if any(f.severity == "fail" for f in findings):
        return 1
    return 0


def _next_major(version: str) -> str:
    """Return ``X.<Y+1>`` for an ``X.Y[.Z]`` version (rough upper bound)."""
    parts = version.split(".")
    if len(parts) < 2:
        return version
    try:
        major = int(parts[0])
        minor = int(parts[1])
    except ValueError:
        return version
    return f"{major}.{minor + 1}"


__all__ = ["add_catch_up_args", "run_catch_up"]
