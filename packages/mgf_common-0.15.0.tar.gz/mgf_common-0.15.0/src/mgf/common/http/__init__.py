"""``mgf.common.http`` — typed async HTTP client wrapper.

See: ``docs/public/recipes/http.md`` (v0.6 Phase A) and
``my_stuff/STRATEGIC_REVIEW_2026-04-29.md`` §4.2.A.

A consumer that needs HTTP shouldn't reinvent these things every
time:

  - User-Agent identity headers (``<app>/<ver> mgf-common/<libver>``)
  - Redaction of secret-shaped headers (Authorization, Cookie, etc.)
    in logs and OTel spans
  - Retry on transient failures with exponential backoff + jitter
  - Per-request and global timeouts
  - TLS-verify default-on with a runtime warning if disabled
  - Typed error translation (``httpx.TimeoutException`` → ``TransportError``,
    etc.)

This subpackage ships :class:`AsyncHttpClient` — a thin layer over
:class:`httpx.AsyncClient` that bakes the above in. It is **fully
optional**: nothing else in ``mgf-common`` imports from here, so
consumers without HTTP needs pay zero cost.

Install via the ``[http]`` extra::

    pip install 'mgf-common[http]'

Two consumers exist already:

  - **mgf-apiprobe**: migrates ``HttpxTransport`` to use this in v0.6.
  - **PlasmaMapper** (Phase 2+): every provider integration
    (Teltonika, Stripe, map providers).

The closed-box invariant holds — the wrapper exposes a small
``request()`` surface; consumers don't reach past it into ``httpx``
internals (though they can if they need to via the
:attr:`AsyncHttpClient.client` escape hatch).
"""

from __future__ import annotations

from mgf.common.http._client import AsyncHttpClient
from mgf.common.http._errors import HttpClientError
from mgf.common.http._retry import RetryPolicy

__all__ = [
    "AsyncHttpClient",
    "HttpClientError",
    "RetryPolicy",
]
