"""``AsyncHttpClient`` — wraps :class:`httpx.AsyncClient` with mgf-common defaults.

The class is intentionally small. The value-add isn't in the request
shape (``httpx`` already nailed that); it's in the four cross-cutting
concerns every consumer reinvents:

  - **Identity** — User-Agent auto-derived from
    :func:`mgf.common.app_name` + :func:`mgf.common.app_version` +
    the library's own version, so traffic can be attributed.
  - **Retry** — :class:`RetryPolicy`-driven exponential-with-jitter
    on transient failures. Defaults to zero retries (deterministic).
  - **Redaction** — secret-shaped request headers (``Authorization``,
    ``Cookie``, ``X-Api-Key`` family, etc.) are redacted in the
    structured log line we emit per request. The response body
    isn't logged.
  - **Errors** — ``httpx`` exceptions are wrapped in
    :class:`mgf.common.http.HttpClientError` so the standard CLI
    exit-code translator + ``except AppError:`` patterns work.

OTel span emission is **best-effort**: when the ``[observability]``
extra is installed (and a TracerProvider is wired), each
:meth:`request` call opens a span named ``http.client.<METHOD>``.
Without OTel, the span block no-ops.

TLS verification is **default-on**. Constructing with
``verify_tls=False`` emits :class:`UserWarning` once per process —
disabling TLS in production is almost always a bug.
"""

from __future__ import annotations

import asyncio
import logging
import warnings
from typing import TYPE_CHECKING, Any

import httpx

from mgf.common.http._errors import HttpClientError
from mgf.common.http._retry import RetryPolicy

if TYPE_CHECKING:
    from collections.abc import Mapping
    from types import TracebackType

_LOG = logging.getLogger("mgf.common.http")

# Header names treated as secret-shaped for redaction in logs/spans.
# Case-insensitive comparison via .lower() at lookup time.
_SECRET_HEADER_KEYS: frozenset[str] = frozenset(
    {
        "authorization",
        "cookie",
        "set-cookie",
        "x-api-key",
        "x-auth-token",
        "x-secret",
        "proxy-authorization",
    }
)

# Tracks whether the verify_tls=False warning has already fired
# this process. One-shot per process to avoid spam in test runs
# that exercise the disabled-tls path repeatedly.
_TLS_DISABLE_WARNED = False


class AsyncHttpClient:
    """Thin wrapper over :class:`httpx.AsyncClient` with mgf-common defaults.

    Use as an async context manager OR call :meth:`aclose` explicitly::

        async with AsyncHttpClient(timeout=10.0) as http:
            response = await http.get("https://api.example.com/users")

        # equivalent:
        http = AsyncHttpClient(timeout=10.0)
        try:
            response = await http.get("https://api.example.com/users")
        finally:
            await http.aclose()

    Reuse one instance across many calls to share the connection pool.

    For tests, mock the underlying httpx layer with respx — the
    wrapper is transparent to it.
    """

    def __init__(
        self,
        *,
        base_url: str = "",
        timeout: float = 30.0,
        verify_tls: bool = True,
        user_agent: str | None = None,
        default_headers: Mapping[str, str] | None = None,
        retry: RetryPolicy | None = None,
    ) -> None:
        if timeout <= 0:
            raise ValueError(f"timeout must be > 0 (got {timeout})")

        if not verify_tls:
            global _TLS_DISABLE_WARNED
            if not _TLS_DISABLE_WARNED:
                _TLS_DISABLE_WARNED = True
                warnings.warn(
                    "AsyncHttpClient: verify_tls=False — TLS certificate "
                    "verification is DISABLED. This is almost never the "
                    "right thing in production. If this is a test fixture, "
                    "narrow the scope (per-test client, not global). If a "
                    "provider's TLS chain is broken, file with them.",
                    UserWarning,
                    stacklevel=2,
                )

        self._timeout = timeout
        self._retry = retry or RetryPolicy()
        self._user_agent = user_agent or _default_user_agent()

        # Assemble default headers: User-Agent first (consumer
        # overrides win), then user-supplied defaults.
        headers = {"User-Agent": self._user_agent}
        if default_headers:
            headers.update(dict(default_headers))

        self._client = httpx.AsyncClient(
            base_url=base_url,
            timeout=timeout,
            verify=verify_tls,
            headers=headers,
            follow_redirects=True,
        )

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def aclose(self) -> None:
        """Close the underlying connection pool. Safe to call multiple times."""
        await self._client.aclose()

    async def __aenter__(self) -> AsyncHttpClient:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        await self.aclose()

    # ── Underlying client (escape hatch) ──────────────────────────────────

    @property
    def client(self) -> httpx.AsyncClient:
        """The wrapped :class:`httpx.AsyncClient`.

        Exposed so consumers needing httpx-specific features (streaming
        downloads, multipart uploads, custom transports) can reach
        through. The wrapper's defaults still apply at construction
        time; per-call kwargs fall back to httpx semantics.

        Avoid using this for the request shapes :meth:`request` already
        covers — you'll lose retry, redaction, and error translation.
        """
        return self._client

    # ── Convenience method shortcuts ──────────────────────────────────────

    async def get(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("GET", url, **kwargs)

    async def post(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("POST", url, **kwargs)

    async def put(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("PUT", url, **kwargs)

    async def patch(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("PATCH", url, **kwargs)

    async def delete(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("DELETE", url, **kwargs)

    async def head(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("HEAD", url, **kwargs)

    # ── The load-bearing call ─────────────────────────────────────────────

    async def request(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, Any] | None = None,
        cookies: Mapping[str, str] | None = None,
        json: Any = None,
        content: bytes | str | None = None,
        timeout: float | None = None,  # noqa: ASYNC109 — passthrough to httpx
        retry: RetryPolicy | None = None,
    ) -> httpx.Response:
        """Send a request; return the response.

        ``method`` is uppercase per HTTP convention. ``url`` is
        absolute or relative to the client's ``base_url``.

        Per-call overrides:

          - ``timeout`` overrides the constructor's default for this
            request only (None = use constructor default).
          - ``retry`` overrides the policy for this request only.

        Raises:

          - :class:`HttpClientError` for transport-level failures
            (timeout, connect error, network error) AFTER retries
            exhaust. Original ``httpx`` exception preserved via
            ``__cause__``.

        4xx and 5xx responses are NOT raised — they return as
        :class:`httpx.Response`. Use ``response.raise_for_status()``
        if you want a typed exception, or check ``response.status_code``.
        """
        method_upper = method.upper()
        retry_policy = retry or self._retry
        per_call_timeout = timeout if timeout is not None else self._timeout

        with _client_span(method_upper, url):
            return await self._send_with_retries(
                method=method_upper,
                url=url,
                headers=headers,
                params=params,
                cookies=cookies,
                json=json,
                content=content,
                timeout=per_call_timeout,
                retry_policy=retry_policy,
            )

    async def _send_with_retries(
        self,
        *,
        method: str,
        url: str,
        headers: Mapping[str, str] | None,
        params: Mapping[str, Any] | None,
        cookies: Mapping[str, str] | None,
        json: Any,
        content: bytes | str | None,
        timeout: float,  # noqa: ASYNC109 — passthrough to httpx
        retry_policy: RetryPolicy,
    ) -> httpx.Response:
        """The inner retry + send loop.

        Returns the final response if successful (or a non-retryable
        4xx/5xx). Raises :class:`HttpClientError` on persistent
        transport-level failure.
        """
        method_retryable = retry_policy.is_method_retryable(method)
        max_attempts = retry_policy.max_attempts if method_retryable else 0

        last_exc: BaseException | None = None
        for attempt in range(max_attempts + 1):
            if attempt > 0:
                backoff = retry_policy.backoff_for_attempt(attempt - 1)
                _LOG.debug(
                    "http retry: method=%s url=%s attempt=%s backoff=%.3fs",
                    method,
                    url,
                    attempt,
                    backoff,
                )
                await asyncio.sleep(backoff)

            # httpx 0.28+ deprecated per-request cookies= in favour of
            # client-level cookies. We need per-request cookies for our
            # per-probe / per-call shape (CookieAuth in apiprobe, etc.),
            # so we pack the dict into a single Cookie header instead.
            # That sidesteps the deprecation entirely and is exactly
            # what httpx would have done internally.
            request_headers = dict(headers) if headers else {}
            if cookies:
                cookie_header = "; ".join(f"{k}={v}" for k, v in cookies.items())
                # If the caller already set a Cookie header explicitly,
                # ours appends — same as how httpx would merge.
                existing = request_headers.get("Cookie") or request_headers.get("cookie")
                if existing:
                    cookie_header = f"{existing}; {cookie_header}"
                    request_headers.pop("Cookie", None)
                    request_headers.pop("cookie", None)
                request_headers["Cookie"] = cookie_header

            try:
                response = await self._client.request(
                    method=method,
                    url=url,
                    headers=request_headers or None,
                    params=params,
                    json=json,
                    content=content,
                    timeout=timeout,
                )
            except httpx.TimeoutException as exc:
                last_exc = exc
                _LOG.warning(
                    "http timeout: method=%s url=%s attempt=%s",
                    method,
                    url,
                    attempt + 1,
                )
                continue
            except httpx.ConnectError as exc:
                last_exc = exc
                _LOG.warning(
                    "http connect error: method=%s url=%s attempt=%s err=%s",
                    method,
                    url,
                    attempt + 1,
                    exc,
                )
                continue
            except httpx.NetworkError as exc:
                last_exc = exc
                _LOG.warning(
                    "http network error: method=%s url=%s attempt=%s err=%s",
                    method,
                    url,
                    attempt + 1,
                    exc,
                )
                continue
            except httpx.HTTPError as exc:
                # Catch-all for any other httpx error; do NOT retry.
                _LOG.warning(
                    "http error (non-retryable): method=%s url=%s err=%s",
                    method,
                    url,
                    exc,
                )
                raise HttpClientError(
                    url=url,
                    cause_summary=f"httpx error: {exc}",
                    attempts=attempt + 1,
                ) from exc

            # Response received. Decide whether to retry on status.
            if (
                attempt < max_attempts
                and retry_policy.is_status_retryable(response.status_code)
            ):
                _LOG.warning(
                    "http retryable status: method=%s url=%s status=%s "
                    "attempt=%s",
                    method,
                    url,
                    response.status_code,
                    attempt + 1,
                )
                await response.aclose()
                continue

            # Successful or non-retryable response. Log + return.
            _log_response(method, url, response, headers)
            return response

        # All attempts exhausted on transport-level failures.
        cause = _categorise_exc(last_exc) if last_exc else "unknown"
        raise HttpClientError(
            url=url,
            cause_summary=cause,
            attempts=max_attempts + 1,
        ) from last_exc


# ---------------------------------------------------------------------------
# Helpers — User-Agent, span, redaction, error categorisation.
# ---------------------------------------------------------------------------


def _default_user_agent() -> str:
    """Return ``<app_name>/<app_version> mgf-common/<libver>``.

    Uses :func:`mgf.common.app_name` + :func:`mgf.common.app_version`
    if bootstrap has been called; otherwise falls back to
    ``"app/unknown mgf-common/<libver>"``.
    """
    from mgf.common import __version__ as lib_version
    from mgf.common._identity import _APP_NAME, _APP_VERSION

    return f"{_APP_NAME}/{_APP_VERSION} mgf-common/{lib_version}"


def _redact_headers(headers: Mapping[str, str] | None) -> dict[str, str]:
    """Return a copy of ``headers`` with secret-shaped values redacted."""
    if not headers:
        return {}
    out: dict[str, str] = {}
    for key, value in headers.items():
        if key.lower() in _SECRET_HEADER_KEYS:
            out[key] = "<redacted>"
        else:
            out[key] = value
    return out


def _log_response(
    method: str,
    url: str,
    response: httpx.Response,
    request_headers: Mapping[str, str] | None,
) -> None:
    """Emit one structured log line per completed request."""
    _LOG.info(
        "http request: method=%s url=%s status=%s elapsed_ms=%.1f request_headers=%s",
        method,
        url,
        response.status_code,
        response.elapsed.total_seconds() * 1000.0,
        _redact_headers(request_headers),
    )


def _categorise_exc(exc: BaseException) -> str:
    """Short, human-readable category for log + error messages."""
    if isinstance(exc, httpx.TimeoutException):
        return f"timeout: {exc}"
    if isinstance(exc, httpx.ConnectError):
        return f"connect error: {exc}"
    if isinstance(exc, httpx.NetworkError):
        return f"network error: {exc}"
    return f"{type(exc).__name__}: {exc}"


# ---------------------------------------------------------------------------
# OTel span — best-effort; no-ops when the SDK isn't installed.
# ---------------------------------------------------------------------------


def _client_span(method: str, url: str) -> Any:
    """Return a context manager that opens an OTel client span.

    No-op when ``[observability]`` extra is not installed.
    """
    try:
        from opentelemetry import trace
    except ImportError:
        return _NullSpan()

    tracer = trace.get_tracer("mgf.common.http")
    return tracer.start_as_current_span(
        f"http.client.{method}",
        attributes={
            "http.request.method": method,
            "url.full": url,
        },
    )


class _NullSpan:
    """No-op span context manager. Used when OTel SDK is absent."""

    def __enter__(self) -> _NullSpan:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        return


__all__ = ["AsyncHttpClient"]
