"""``RequestIdMiddleware`` — per-request X-Request-Id generation + propagation.

Every HTTP request gets a request id:

  - If the inbound request carries ``X-Request-Id`` (canonical name —
    case-insensitive lookup), reuse it.
  - Otherwise, generate a UUID4.

The request id is:

  - Set on ``request.state.request_id`` (FastAPI standard surface).
  - Set on a contextvar so :func:`current_request_id` works from any
    code path inside the request — including async task children
    via :pep:`567` propagation.
  - Echoed in the response's ``X-Request-Id`` header.

Logging integration: add a logging filter that injects the contextvar
into log records. The filter is shipped in v0.7 Phase D's async-logging
work; for v0.6, consumers can attach it manually via ``%(request_id)s``
format directive in their log config.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from starlette.middleware.base import BaseHTTPMiddleware

# Shared contextvar + helpers — same identity across framework
# adapters so request-id correlation works in mixed processes.
from mgf.common._request_id import (
    _REQUEST_ID_VAR,
    REQUEST_ID_HEADER,
    _generate_request_id,
    current_request_id,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from starlette.requests import Request
    from starlette.responses import Response


class RequestIdMiddleware(BaseHTTPMiddleware):
    """ASGI middleware that injects/forwards ``X-Request-Id``.

    Install at app construction time::

        from fastapi import FastAPI
        from mgf.common.fastapi import RequestIdMiddleware

        app = FastAPI()
        app.add_middleware(RequestIdMiddleware)

    Order matters when combined with other middlewares: install
    :class:`RequestIdMiddleware` **early** so downstream middlewares +
    handlers see ``request.state.request_id`` populated.
    """

    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        # Case-insensitive header lookup. Starlette normalises header
        # keys to lowercase internally.
        existing = request.headers.get(REQUEST_ID_HEADER.lower())
        request_id = existing or _generate_request_id()

        request.state.request_id = request_id
        token = _REQUEST_ID_VAR.set(request_id)
        try:
            response = await call_next(request)
        finally:
            _REQUEST_ID_VAR.reset(token)

        # Echo in the response so clients can correlate too.
        response.headers[REQUEST_ID_HEADER] = request_id
        return response


__all__ = [
    "REQUEST_ID_HEADER",
    "RequestIdMiddleware",
    "current_request_id",
]
