"""``mgf.common.fastapi`` — FastAPI integration adapters.

See: ``docs/public/recipes/fastapi.md`` (v0.6 Phase B) and the
strategic-review §4.2.B.

A consumer building a FastAPI service shouldn't reinvent the wiring
for these every time:

  - :func:`bootstrap` ↔ FastAPI lifespan (start/stop wiring).
  - Per-request ``X-Request-Id`` generation + propagation to logs.
  - Typed-exception → JSON response mapping
    (``ConfigError`` → 400, ``ResourceNotFoundError`` → 404, etc.).
  - ``Depends()`` helpers for request-scoped data (settings,
    request_id, ``AppContext``).

Optional extra: ``pip install 'mgf-common[fastapi]'`` (pulls
``fastapi>=0.110``).

The integration is **adapter-shaped, not framework-shaped**. Nothing
here re-exports FastAPI primitives or hides them. The consumer's app
is still a regular FastAPI app — these helpers just plug into the
seams FastAPI provides (lifespan, middleware, dependencies).

Closed-box invariant: ``mgf.common.fastapi`` depends on
``mgf-common[fastapi]`` only. Consumers without FastAPI never see
the import.
"""

from __future__ import annotations

from mgf.common.fastapi._dependencies import (
    get_app_context,
    get_request_id,
    get_settings,
)
from mgf.common.fastapi._exceptions import (
    DEFAULT_STATUS_MAP,
    ExceptionTranslationMiddleware,
)
from mgf.common.fastapi._lifespan import setup_lifespan
from mgf.common.fastapi._request_id import (
    REQUEST_ID_HEADER,
    RequestIdMiddleware,
    current_request_id,
)

__all__ = [
    "DEFAULT_STATUS_MAP",
    "REQUEST_ID_HEADER",
    "ExceptionTranslationMiddleware",
    "RequestIdMiddleware",
    "current_request_id",
    "get_app_context",
    "get_request_id",
    "get_settings",
    "setup_lifespan",
]
