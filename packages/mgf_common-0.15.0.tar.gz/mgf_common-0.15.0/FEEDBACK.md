# FEEDBACK.md — Consumer feedback & open roadmap

> **Living document.** Design conversations between
> `mgf-common` maintainers and library consumers.
>
> **Format.** Each entry is a uniform block: identifier, status
> badge, severity, structured frontmatter, then prose. The format
> is optimised for both human readers and AI agents — every entry
> has the same shape, every status field is grep-able.
>
> **Bar.** Industry-standard. The shape any serious Python
> service / desktop / mobile project reaches for by default.

---

## §1. Process

### 1.1 Submission

A consumer adds an entry by opening a PR that edits this file.
Every entry MUST follow the **§1.4 entry template** below — the
uniform shape is what makes the document machine-actionable.

The `mgf-common feedback` CLI prints the submission flow + the
entry template ready to paste. Run it from any project that
depends on mgf-common.

### 1.2 Severity

| Level | Meaning | SLA |
|---|---|---|
| 🔴 **Blocker** | Getting it wrong requires a breaking change to fix later. MUST be decided before locking the public surface. | Triaged within the release cycle it lands in; decision recorded inline. |
| 🟡 **High** | Significant quality-of-life issue. Painful to live with, additive to add later. | Addressed as a minor / patch; no release gate. |
| 🟢 **Nice-to-have** | Real value, not urgent. | Picked up when a maintainer has capacity or a second consumer asks. |
| 💭 **Aspirational** | "Long-term where should this go" input. Not actionable today. | Kept for roadmap reviews; drives major-version planning. |

### 1.3 Status lifecycle

```
OPEN → ACCEPTED → SCHEDULED → SHIPPED
       ↓
       REJECTED   (with rationale)
       DEFERRED   (agreed in principle, not scheduled)
```

- **OPEN** — submitted, not yet triaged.
- **ACCEPTED** — maintainers agree; not yet scheduled.
- **SCHEDULED** — assigned a release.
- **SHIPPED** — landed; entry's status changes inline with a
  one-line retrospective. (We don't keep a parallel "shipped
  audit" section — the CHANGELOG carries the audit trail.)
- **REJECTED** — kept (not deleted) so future consumers don't
  re-raise.
- **DEFERRED** — agreed in principle, picked up at next roadmap
  review.

### 1.4 Entry template — every new entry MUST follow this shape

```markdown
### `<AREA>-<NN>` — One-line title

| Field | Value |
|---|---|
| Status | OPEN / ACCEPTED / SCHEDULED / SHIPPED / REJECTED / DEFERRED |
| Severity | 🔴 / 🟡 / 🟢 / 💭 |
| Submitter | <Project> (commit `<sha>` if applicable) |
| Submitted | YYYY-MM-DD |
| Decision | pending / accepted / rejected (one line) |
| Decided on | YYYY-MM-DD or `—` |
| Scheduled for | release tag or `—` |
| Shipped in | commit SHA + release tag, or `—` |

**Concern.** What's wrong or missing. One paragraph.

**Why it matters.** Why this affects real consumers. One paragraph.

**Suggested shape.** Concrete proposal — code snippet, prose, or
both. Not required to be the final answer; required to be a
starting point.

**Decision rationale.** Filled when triaged. Why accepted /
rejected / deferred / scheduled.

**Retrospective.** Filled when shipped. Did the suggested shape
survive contact with implementation? What changed and why?
```

The frontmatter table is the single source of truth for status.
Prose comes after.

### 1.5 Ground rules

- **API stability is best-effort during the 0.x window.** Pinning
  to a minor (e.g., `>=0.X,<0.Y`) opts the consumer in to a
  predictable change cadence; pinning broadly opts in to faster
  iteration. Aggressive 🔴 Blocker resolution is the point of
  the early window.
- **A "co-developed" consumer carries less signal than a remote
  one.** A concern raised independently by a consumer with no
  prior coordination is a stronger lift signal than the same
  concern surfaced by the maintainer's primary consumer. Filter
  accordingly.
- **Don't optimise for `mgf-common` developers.** Every design
  trade-off favours the consumer. A feature that saves the
  library author an hour but costs every consumer a day of
  integration pain is a net loss.

---

## §2. Open feedback (active)

Sorted by area, then ID. To add a new entry, copy §1.4's template
verbatim and fill it in.

### 🟡 Papercuts

#### `PAPER-03` — Observability shim pattern is load-bearing but undocumented

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High (doc, not code) |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept (recipe form rather than standards-doc section) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `docs/public/recipes/observability_shim.md` (in-tree) + cross-link from `05_observability.md` |

**Concern.** A consumer can layer a project-local
`<project>/observability/__init__.py` re-export shim over
`mgf.common.observability` to layer in its own redactor /
formatter / handler extensions without forking `mgf.common`.
This pattern is valuable but nowhere documented as recommended
practice.

**Why it matters.** A future consumer evaluating the
architecture will either (a) miss the pattern entirely and
either fork or live with limited extensibility, or (b) discover
it by reading another consumer's source — neither is the right
onboarding shape for an industry-standard library.

**Suggested shape.** Add a section to
`docs/standards/COMMON_COMPONENTS.md` or a new
`docs/patterns/shim-layering.md` explaining: (a) why a consumer
might want a shim even without legacy call sites, (b) the
`import-linter` contract that keeps the shim from re-entangling,
(c) how to layer consumer-specific redactor extensions on top.

**Resolution.** Shipped as a recipe at
`docs/public/recipes/observability_shim.md` rather than a
standards-doc section: the standards docs declare MUSTs and
SHOULDs, while this is a recommended pattern (a recipe). The
recipe covers: why a shim is valuable for extensibility (not
just back-compat), the closed-box rule that applies inside the
shim, a layered example (custom redactor + custom log handler +
wrapper around `operation_span`), an `import-linter` contract
for the consumer side, and when NOT to use the shim.
Cross-linked from `docs/public/05_observability.md` "Related
docs".

---

#### `PAPER-04` — Schema-versioning patterns are not reusable

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `mgf.common.versioned.VersionedFileStore[T]` + `MigrateFn` (in-tree) |

**Concern.** Every sub-config file in a real consumer (hooks,
schedules, alerts, lab specs, profiles) implements the same
shape: `version: int` + unknown-key rejection + migration
callback + atomic write. The code is duplicated across many
modules because `mgf.common.config.BaseAppSettings` covers only
the top-level config file, not satellite files.

**Why it matters.** Real code duplication cost (~600 LOC in
the reference consumer alone); will replicate in every consumer.
Each instance also drifts subtly (slightly different error
wording, slightly different migration shape) — exactly the
bit-rot the standards exist to prevent.

**Resolution.** Ships as `mgf.common.versioned`, a new public
subpackage. Two public names:

- `VersionedFileStore[T]` — the generic. Constructor takes the
  pydantic schema (must set `extra="forbid"`), the
  `current_version`, an optional `migrate=` callback, and an
  optional `version_field=` (default `"version"`; the consumer
  uses both `version` and `schema_version`). Format auto-detects
  from the path suffix (`.yaml` / `.yml` / `.json`); override via
  `file_format=`. `load()` validates, routes through migrate,
  returns `T`. `save()` stamps `version_field=current_version`
  and writes atomically (temp + fsync + rename, mode 0o600).
  Errors land as `AppConfigError` with PEP 678 notes naming the
  path + offending key.
- `MigrateFn` — the type alias for the migration callback:
  `Callable[[Mapping[str, Any], int], Mapping[str, Any]]`.

Recipe at `docs/public/recipes/versioned.md`. Pinned by 28 unit
tests + 5 user-perspective tests + the `PUBLIC_API.md` /
`PUBLIC_API.json` contract.

---

#### `PAPER-06` — `docs/standards/` cites the reference consumer with file:line

| Field | Value |
|---|---|
| Status | 🟡 PARTIAL — line-range citations stripped + caveat banner added |
| Severity | 🟡 High (doc refactor) |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept partial; full restructure deferred |
| Decided on | 2026-04-30 |
| Scheduled for | full restructure: future |
| Shipped in | partial: line ranges stripped from 12 citations across 6 docs; caveat banner in `docs/standards/README.md` |

**Concern.** Some topic docs have "AS-IS in <consumer>"
paragraphs citing specific file:line locations. These rot as the
consumer evolves. When a second consumer arrives, these
paragraphs become confusing ("wait, is that the reference
example or an accident?").

**Why it matters.** The standards docs are the public face of
the project. Consumer-specific examples cluttering the
cross-project standard creates a perception that the standards
are consumer-shaped rather than industry-shaped — which
undermines the cornerstone-library positioning.

**Suggested shape (partial done).** Highest-rot-risk component
closed: 12 `*.py:NN-MM` line-range citations across
`COMMON_COMPONENTS.md`, `LOGGING.md`, `CONFIGURATION.md`,
`DESIGN_PRINCIPLES.md`, and `ERROR_HANDLING.md` replaced with
file/function references that don't drift on every refactor. A
caveat banner in `docs/standards/README.md` warns readers that
consumer-specific examples are illustrative.

**Full restructure (still open).** Move consumer-specific
paragraphs into a dedicated `docs/reference-consumer/`
subfolder. When a second consumer arrives, generalise to
`docs/reference-consumers/Project1.md` /
`docs/reference-consumers/Project2.md`. Standards stay
consumer-neutral.

---

#### `PAPER-07` — Default-path helpers (`_default_log_path`, `_crash_dir`) are private but consumers need them

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | Maintainer audit (VManager integration walk, 2026-05-01) |
| Submitted | 2026-05-01 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-02 |
| Scheduled for | 0.13.0 |
| Shipped in | `mgf.common.observability.{default_log_path, default_crash_dir, default_state_dir}` (v0.13.0); underscore-prefixed names retained as deprecated aliases that emit `MgfDeprecationWarning` for one cycle |

**Concern.** Consumers writing observability-adjacent UI (a log
viewer dialog, a crash-report browser, a "show me where my
state lives" diagnostic) need to know the on-disk paths the
library writes to. Today these paths are computed by private
helpers in `mgf.common.observability`:

- `mgf.common.observability.logging_setup._default_log_path()`
  — resolves `<state>/<app>/logs/<app>.log`.
- `mgf.common.observability.crash_reporter._crash_dir()` —
  resolves `<state>/<app>/crashes/`.

The reference consumer has already had to reach into the
private surface — `vmanager/gui/windows/main_window.py:254`
imports `_default_log_path` directly — which is a real
closed-box leak the consumer had no public alternative for.

**Why it matters.** Closed-box discipline is load-bearing for
`mgf-common`'s positioning. Every consumer that needs to
surface "where do my logs live?" in their UI is going to hit
this gap. The library can either (a) keep both paths private
and force every consumer to reach into the private surface
(the worst outcome — silent erosion of the closed-box
property) or (b) promote them now while the surface is still
small.

**Suggested shape.** Promote both helpers to public, ideally
in a small dedicated module so future path helpers have a
home::

    # mgf/common/observability/paths.py — new public module
    from pathlib import Path

    def default_log_path() -> Path: ...
    def default_crash_dir() -> Path: ...
    def default_state_dir() -> Path: ...   # the parent of both

Re-export from `mgf.common.observability.__all__`. Keep the
underscore-prefixed names as deprecated aliases for one cycle
so consumers reaching into the private surface get a
deprecation warning rather than a silent break.

Pin via the existing AP-10 sync test + a public-surface test
in `tests/public_surface/test_observability_as_user.py`.

---

#### `PAPER-08` — `mgf-common catch-up` should detect closed-box leaks (private imports from `mgf.common._*`)

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🟢 Nice-to-have |
| Submitter | Maintainer audit (VManager integration walk, 2026-05-01) |
| Submitted | 2026-05-01 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** `mgf-common catch-up` audits four-gate config,
pin staleness, CLAUDE.md presence, and v0.1-pattern call
sites. It does NOT audit consumer source for closed-box leaks
(`from mgf.common._x import _y` or `from mgf.common.X import
_private`). The reference consumer had one such leak that the
audit didn't surface (`_default_log_path` import in
VManager's main window) — `tests/public_surface/`'s
`test_no_private_imports.py` AST pin is exactly the right
shape, but lives in `mgf-common`'s test suite, so the
discipline isn't enforced consumer-side unless the consumer
copies it.

**Why it matters.** The closed-box rule is harder to enforce
when consumers can write `from mgf.common._foo import _bar`
and silently get away with it until the next refactor breaks
their import. Surfacing this in `catch-up` makes the rule
discoverable as part of the standard "is my project up to
spec?" workflow, rather than something the consumer has to
remember to write a test for.

**Suggested shape.** Extend `_check_legacy_patterns` (or add a
new `_check_closed_box_leaks` audit row) that AST-walks every
`*.py` under `src/` and emits a warning for each
`mgf.common._*` import or `mgf.common.X._private`
import-from. Output format same as the existing
"v0.1-pattern usage" row — list the offending paths and a
one-line suggestion. Caveat: the audit MUST NOT walk into the
consumer's own `tests/` directory, since
`tests/unit/_internal_test_helpers/` style imports are
legitimate consumer-side.

This is also the right shape to surface FEEDBACK PAPER-07 —
the audit would name the private import and PAPER-07 (when
shipped) would direct the consumer to the public alternative.

---

#### `PAPER-09` — `VersionedFileStore[T]` rejects missing-version files unconditionally; consumers with pre-versioning legacy YAMLs cannot adopt it

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | VManager (Phase MGF-3 catch-up walk, 2026-05-02) |
| Submitted | 2026-05-02 |
| Decision | accept (suggested shape verbatim — single boolean) |
| Decided on | 2026-05-02 |
| Scheduled for | 0.14.0 |
| Shipped in | `VersionedFileStore[T](..., tolerate_missing_version=False)` (v0.14.0); default keeps strict-by-default; opt-in logs one WARNING via `mgf.common.versioned` and treats missing as `current_version` (skipping migrate, since there is no version to migrate from); files where the field is *present but not an int* still raise — that's a corruption signal, not a legacy file |

**Concern.** `VersionedFileStore[T].load()` raises
`AppConfigError` when the on-disk file is missing the typed
version field. That's the right default for fresh consumers, but
it locks out consumers with **pre-versioning legacy files** —
files written before the consumer adopted CF-07's `version:`
discipline, which exist in user state directories on machines
that have been running the consumer across multiple releases.

VManager's `vmanager.profiles.profile.VMProfile.from_dict` ships
a deliberate grace path: a missing `version:` is logged at
WARNING and treated as `version: 1`. The next save rewrites the
file with `version:` at the top. This is what every test in
`tests/unit/test_profiles.py::TestVMProfileVersioning` pins —
specifically `test_load_accepts_missing_version_with_warning`.
Five satellite stores in VManager migrated to
`VersionedFileStore[T]` cleanly during Phase MGF-3 of
`docs/MGF_COMMON_CATCHUP.md`; the sixth (profiles) had to be
skipped because the grace path can't go through VFS. The bespoke
manual-JSON-parse + version-handling code in `profile.py` stays.

**Why it matters.** Every long-lived consumer that adds CF-07
versioning AFTER a public release of the file format hits this.
The "I added `version: <N>` to a file format that didn't have it
before; I want users' existing files to keep loading" pattern is
exactly what VFS should make easy, and it's where every consumer
will hit the same wall the moment they adopt
`VersionedFileStore[T]` for a pre-existing file. PAPER-04's
"replicates in every consumer" reasoning applies again here.

**Suggested shape.** Add an explicit opt-in flag — name it
something like `tolerate_missing_version=False` — that, when
set, treats a missing version field as the constructor's
`current_version` (with a single WARNING log via `mgf.common`'s
own logger, not raised as an error). The consumer's migrate
callback still runs against any other version, so consumers
that mix "missing means current" with real migrations
work cleanly.

```python
store = VersionedFileStore(
    path,
    schema=ProfileFile,
    current_version=2,
    migrate=migrate,           # v1 → v2
    tolerate_missing_version=True,  # missing → v2 with WARNING
)
```

The default stays `False` — fresh consumers benefit from the
strict-by-default behaviour. The flag is the explicit
opt-in for consumers that need the grace mode.

Alternative shape: a richer `MissingVersionPolicy` enum
(`reject` / `treat_as_current` / `treat_as_v1`) if the maintainer
wants more flexibility. The simple boolean is probably enough —
"treat as current with WARNING" is the only sane non-reject
behaviour, since the only thing pre-versioning files were
(implicitly) was "the version that was current when I was
written," which becomes "the current version" once they're
loaded by a binary that knows about versioning.

---

#### `PAPER-10` — No entry-point-driven auto-discovery for observability / vault plug-ins

| Field | Value |
|---|---|
| Status | DEFERRED |
| Severity | 🟢 Nice-to-have |
| Submitter | VManager (Round 2 audit walk, 2026-05-02) |
| Submitted | 2026-05-02 |
| Decision | defer until first plugin-framework consumer files concrete pain |
| Decided on | 2026-05-02 |
| Scheduled for | — |
| Shipped in | — |

**Decision rationale.** VManager themselves admit they don't
need this today (single-tenant, no extensions registered yet).
The `[project.entry-points.*]` shape is well-understood from
pytest / pluggy / flake8, but the *grouping* and the
*lifecycle* (when in `bootstrap()` to walk; what counts as a
plugin failure) are calls that benefit hugely from a real
consumer constraining them.

Strategic-review P1 (commit `f3e5845`) is exactly this point:
"Get a second, independent consumer." The second consumer's
plugin needs are the gate for designing the entry-point seam.
Pre-designing risks calcifying wrong: a seam that goes
un-stress-tested for two years lands in v1.0 with whatever
shape we guessed today, and consumers route around it instead
of using it.

The shipping-early argument ("zero downstream registrations to
migrate") is real but weaker. The existing explicit-call API
is already additive-compatible with any future entry-point
walk; consumers that adopt entry points don't have to rewrite
their existing wiring. So the cost of waiting is small.

**When to revisit.** Either of:
  - A plugin-framework consumer (multi-tenancy §S1 scenario)
    files concrete pain from the explicit-call shape.
  - The "second independent consumer" lands and reports their
    extension-wiring story.

Reopen this entry at that point with the consumer's evidence
attached.

**Concern.** `mgf.common.observability` exposes five explicit
registries — `register_log_handler`,
`register_redaction_pattern_group`, `register_span_processor`,
`register_crash_sink` — and `mgf.common.vault` adds a sixth via
`register_vault_backend`. All six require the consumer to
**import the plugin module + call the registration function**
somewhere that executes BEFORE `bootstrap()` claims its wiring
slot. Miss the import (e.g., the plugin lives in a sibling
package the host doesn't know about) and the registration never
happens; miss the timing (call after bootstrap) and the wiring
silently ignores the late entry.

The contrast: `mgf.common.pytest_plugin` declares itself in
`pyproject.toml::[project.entry-points.pytest11]` and pytest
auto-discovers it. Zero consumer-side import; the plugin "just
appears." Every other observability extension point is the
opposite shape — explicit-import, explicit-call, explicit-order.

**Why it matters.** The strategic review's Priority 1 ("second,
independent consumer") leans heavily on the multi-tenancy story
documented in `docs/public/multi_tenancy.md` §S1 — plug-in
frameworks hosting child packages with their own identity and
extensions. That scenario implies third-party plug-ins ship
their own redactor / handler / span-processor. Today every such
plug-in has to convince the host to import it and call its
register hook in the right place. With Python entry points, the
plug-in declares itself; `bootstrap()` walks the entry-point
groups during wiring and the plug-in's hook runs at the right
moment with no host-side change.

VManager itself doesn't have this need today (single-tenant, no
extensions registered yet — Round 2's `R2-MGF-PROGRESS` migration
is purely a re-export shim). The audit raised the gap because
VManager's recipe-driven shim layering pattern, when applied at
scale by a plug-in framework consumer, would surface this
friction immediately. Better to design the discovery seam now —
when there are zero downstream registrations to migrate — than
after a plug-in ecosystem has accreted around the explicit-call
shape.

**Suggested shape.** Define entry-point groups, one per
registry:

```toml
# Consumer's pyproject.toml — say, "vmanager-spice-redactor"
[project.entry-points."mgf.common.observability.redaction_pattern_groups"]
spice = "vmanager_spice_redactor:register"

[project.entry-points."mgf.common.observability.log_handlers"]
audit_kafka = "vmanager_audit:register_kafka_handler"

[project.entry-points."mgf.common.vault.backends"]
hashicorp = "vmanager_vault_hashicorp:register"
```

Each entry's value is a `module:callable` reference; the
callable takes no arguments and returns nothing — it just calls
the existing `register_*` API the way a manual import would. The
group's namespace mirrors the registry name so the contract is
discoverable by reading the `[project.entry-points]` block of any
plug-in package without consulting upstream docs.

`bootstrap()` walks every group via
`importlib.metadata.entry_points()` after wiring identity but
before wiring the registries that consume registered plugins.
Plug-ins that fail to load (`ImportError`, `register()` raises)
emit a single `MgfPluginLoadError` warning and proceed — the
same "best-effort observer" shape (rule **EH-10**) every other
observer in the library follows, so a broken third-party plugin
doesn't break the host's bootstrap.

The existing explicit-call API stays — entry-point discovery is
strictly additive. Consumers that prefer explicit wiring (the
"closed-box" mode) can pass `bootstrap(plugins="off")` (or set
`MgfSettings(plugins="off")`) to skip the entry-point walk
entirely.

The pattern matches what `setuptools` / `pytest` / `flake8` /
`pluggy`-based frameworks have used for a decade; consumers
already understand it and shipping tooling (uv, build, pip)
already supports declaring entry points. Cost on the upstream
side: ~50 lines of entry-point walking + tests.

---

#### `PAPER-11` — Consumers translating `VersionedFileStore[T]` errors string-match on private message markers; typed `error_kind` (or subclasses) would close the contract gap

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | VManager (Phase MGF-3 catch-up walk, 2026-05-02) |
| Submitted | 2026-05-02 |
| Decision | accept (Approach A — `AppConfigErrorKind` enum field) |
| Decided on | 2026-05-02 |
| Scheduled for | 0.15.0 |
| Shipped in | `mgf.common.exceptions.AppConfigErrorKind` (StrEnum) + `AppConfigError.kind: AppConfigErrorKind \| None = None` (v0.15.0). Every load-path raise in `mgf.common.versioned._store` sets `kind` (FILE_NOT_FOUND, IO_READ_FAILED, JSON_PARSE_FAILURE, YAML_PARSE_FAILURE, NON_DICT_ROOT, MISSING_VERSION, UNSUPPORTED_VERSION, MIGRATE_FAILED, SCHEMA_VALIDATION). Save-path raises don't yet opt in — flag a follow-up if a consumer hits pain there. |

**Retrospective.** Implemented Approach A verbatim. Added two
kinds VManager's enum didn't list — `FILE_NOT_FOUND` and
`IO_READ_FAILED` — to cover ALL the load-path raise sites; if
consumers translate VFS errors and a raise site has `kind=None`,
they're forced back to message inspection for that site, which
defeats the whole purpose. Dropped vmanager's `NO_MIGRATE` (it
overlapped 1:1 with `UNSUPPORTED_VERSION` in the actual code).
Backward-compatible: every existing `except AppConfigError:`
clause keeps catching unchanged; consumers that don't
read `e.kind` see no change.

**Concern.** `VersionedFileStore[T].load()` raises a single
exception class (`AppConfigError`) for at least five distinct
failure modes:

1. JSON / YAML parse failure (the on-disk bytes are not valid).
2. Top-level non-dict (`raw` is a string / list / number).
3. Missing typed `version` field
   (when `tolerate_missing_version=False`).
4. On-disk version differs from `current_version` and no
   `migrate` callback is registered.
5. Pydantic schema-validation failure (missing required field,
   wrong type, value outside constraint).

Each case carries a distinguishable error **message** (literal
strings like `"is malformed (json)"`,
`"must be a mapping at the root"`,
`"is missing a typed 'version' field"`,
`"has version=N"`, `"failed schema validation"`). The exception
**class** is the same in every case.

Consumers that want to translate these to project-flavoured
wording — because their CLI or their tests pin specific error
text the consumer's API has historically promised — currently
have to **string-match on the private message format**. The
markers live in `mgf/common/versioned/_store.py` and have no
documented stability contract.

**Why it matters.** During Phase MGF-3 of VManager's catch-up
walk, three migrations needed this translation pattern:

- `src/vmanager/forensics/capture/filesystem.py::load_baseline`
- `src/vmanager/forensics/manifest.py::load_manifest`
- `src/vmanager/security/isolation/baseline.py::load_baseline`

Each ended up writing a discriminator like:

```python
except AppConfigError as e:
    raw = str(e).lower()
    if "is malformed (json)" in raw:
        msg = f"... is unreadable: {e}"
    elif "must be a mapping at the root" in raw:
        msg = f"... is not a JSON object"
    elif "has version=" in raw or "is missing a typed" in raw:
        msg = f"... has unsupported schema_version"
    else:
        # catch-all for schema-validation failures
        msg = f"... is malformed: {e}"
    raise OperationError(msg) from e
```

Three modules × ~four branches each = twelve string-match call
sites that silently break the moment upstream rewords any of
the markers (e.g., "is malformed" → "could not parse"; "has
version=" → "version mismatch on disk:"). The break is
**invisible** in CI — the consumer's tests pass with the legacy
wording in the catch-all branch, the legacy `match=` regexes in
the consumer's tests still match the catch-all message, and
nothing fires until a user hits the specific error path in
production.

Across N consumers each doing K translations, the multiplier is
N × K silently-fragile call sites. The same scaling argument
that drove PAPER-04 (VFS itself was the "every consumer ships
the same shape" pattern) applies here: **every consumer doing
error translation duplicates this discrimination, and every one
of them is fragile on the same upstream reword**.

**Suggested shape.** Either of two approaches; both surface a
typed contract consumers can switch on without string matching.

**Approach A — `error_kind` field on `AppConfigError`.**

```python
from enum import StrEnum

class AppConfigErrorKind(StrEnum):
    JSON_PARSE_FAILURE = "json_parse_failure"
    YAML_PARSE_FAILURE = "yaml_parse_failure"
    NON_DICT_ROOT       = "non_dict_root"
    MISSING_VERSION     = "missing_version"
    UNSUPPORTED_VERSION = "unsupported_version"
    SCHEMA_VALIDATION   = "schema_validation"
    MIGRATE_FAILED      = "migrate_failed"
    NO_MIGRATE          = "no_migrate"

class AppConfigError(AppError):
    kind: AppConfigErrorKind | None = None  # None = legacy/general
    # ... existing fields ...
```

Each `raise` site in `_store.py` sets `exc.kind = AppConfigErrorKind.X`.
Consumers translate with:

```python
except AppConfigError as e:
    match e.kind:
        case AppConfigErrorKind.JSON_PARSE_FAILURE | AppConfigErrorKind.YAML_PARSE_FAILURE:
            raise OperationError("... is unreadable") from e
        case AppConfigErrorKind.UNSUPPORTED_VERSION | AppConfigErrorKind.MISSING_VERSION:
            raise OperationError("... has unsupported schema_version") from e
        case _:
            raise OperationError(f"... is malformed: {e}") from e
```

**Approach B — typed subclasses.**

```python
class MalformedDocumentError(AppConfigError):
    """JSON / YAML parse failure."""
class NonDictRootError(AppConfigError):
    """Top-level value is not a mapping."""
class MissingVersionFieldError(AppConfigError):
    """version field absent or wrong type."""
class UnsupportedVersionError(AppConfigError):
    """on-disk version != current_version and no migrate."""
class StoreSchemaValidationError(AppConfigError):
    """Pydantic field validation failed."""
```

Consumers translate with:

```python
except MalformedDocumentError:
    raise OperationError("... is unreadable") from e
except UnsupportedVersionError:
    raise OperationError("... has unsupported schema_version") from e
except AppConfigError as e:
    raise OperationError(f"... is malformed: {e}") from e
```

Both approaches preserve the existing `AppConfigError` parent
type — every existing `except AppConfigError:` clause keeps
catching the new typed children. Backward-compatible.

**Recommend Approach A** (the enum field). Smaller diff
upstream, no new public class names, easier for consumers to
exhaustively check via Python 3.10+ structural pattern matching,
and the enum doubles as a stable string contract for any
non-Python consumer that ends up reading the JSON crash report
output.

The same argument generalises to other rich-error sites in
`mgf-common` (e.g., `EH-02` translation seams, `BootstrapError`
which today carries `failed_step: str`): typed kinds beat
prose, especially when consumers translate. PAPER-11 is just
the first instance the reference consumer hit hard enough to
file.

---

#### `PAPER-12` — `PUBLIC_API.md` and recipes drift ahead of the published wheel; consumers reading from a local checkout cannot tell what's actually shipped

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | VManager (Phase MGF-3 catch-up walk, 2026-05-02) |
| Submitted | 2026-05-02 |
| Decision | accept (banner-form fix; CI-from-tag deferred) |
| Decided on | 2026-05-02 |
| Scheduled for | docs-only (no version bump) |
| Shipped in | banner at the top of `PUBLIC_API.md` directing readers to `pip show mgf-common` + `PUBLIC_API.json`'s `__version__` field for the actually-installed surface; the heavier "publish docs from release tags" alternative is deferred until CI lands (per the strategic-review P2 priority) |

**Concern.** During Phase MGF-3 of VManager's catch-up the
consumer read `mgf_common/PUBLIC_API.md` and
`docs/public/recipes/versioned.md` from the maintainer's master
checkout, which described `VersionedFileStore[T]` as available
in 0.12.0. The published wheel did not yet ship the module —
master was at 0.13.0-dev. Two rounds of confusion followed
(working assumption: VFS is shipped; reality: not yet). The
same desync recurred for PAPER-07's `default_log_path`.

**Why it matters.** Any consumer who reads the docs from a
local mgf-common checkout (the recommended workflow per
`CLAUDE.md`'s "Round 5 critical facts") will hit the same trap
whenever the maintainer is between a feature merge and a
release. The signal "this is in the docs" reads as "this is
shipped" — which it isn't, until the next `twine upload`. The
same confusion bit the maintainer's own session on 2026-05-02
when responding to the catch-up status — see the local-dist
vs PyPI mismatch resolved in commit `5bef66f`'s lead-up.

**Suggested shape.** A small banner or version stamp at the
top of `PUBLIC_API.md` (and the recipe docs) that says
"documents v...-dev — features marked NEW since the last
release tag are unreleased; consult `pip install
mgf-common==<published>` for the actual surface." Or: tag
releases on master and have CI publish `PUBLIC_API.md` from the
tag, not the tip. Either way, the desync gap closes.

---

#### `VAULT-01` — Vault registry should accept `config_model=` for typed custom backends

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | Maintainer dogfood |
| Submitted | 2026-04-28 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `register_vault_backend(name, *, config_model=None)` + a `model_validator` on `VaultSettings` that coerces dicts → typed model when registered (in-tree) |

**Concern.** The three built-in vault backends
(`EnvVaultConfig` / `KeyringVaultConfig` /
`EncryptedFileVaultConfig`) ship typed configs via the
discriminated union `BuiltinVaultBackendConfig`. Custom
backends (HashiCorp Vault, AWS Secrets Manager, …) still use
`dict[str, Any]` — the closed-box leak is half-closed.
Consumer code shipping a custom backend writes stringly-typed
config dicts that the IDE / mypy / pydantic won't validate.

**Why it matters.** The whole point of typed configs was to
close the "consumers spelunk source to know what keys each
backend wants" gap. Custom backends still spelunk. Real
third-party stores (HashiCorp / AWS) are exactly where the
typed-config win matters most.

**Suggested shape.** Extend `register_vault_backend` to
optionally accept a `config_model` parameter; the registry
stores the mapping. `VaultSettings.config` then validates
against the registered model when the active `backend` matches:

```python
from mgf.common.vault import register_vault_backend
from mgf.common.config import BaseModel, ConfigDict

class HashicorpVaultConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    backend_type: Literal["hashicorp"] = "hashicorp"
    url: str
    token: str
    mount: str = "secret"

@register_vault_backend("hashicorp", config_model=HashicorpVaultConfig)
def make_hashicorp_vault(config: HashicorpVaultConfig) -> VaultProtocol:
    ...
```

`MgfSettings(backend="hashicorp", config=...)` then accepts the
typed config; `BuiltinVaultBackendConfig` becomes a
dynamically-resolved discriminated union from the registry.

**Resolution.** Ships as additive surface:

- `register_vault_backend(name, *, config_model=None)` — the new
  `config_model=` kwarg accepts a `BaseModel` subclass. The
  registry stores `(factory, config_model)` pairs internally.
- `VaultSettings` gets a `model_validator(mode="after")` that
  consults the registry: when the active `backend` has a
  registered `config_model`, an incoming dict is validated and
  replaced with the typed instance; an already-typed instance
  passes through; a wrong typed instance raises with a clear
  error; an unregistered backend leaves the dict untouched
  (factories registered without a model own their own validation).
- Built-in backends (`env` / `keyring` / `file`) keep their
  existing isinstance dispatch + deprecation warning for
  backward compat — the change is purely additive for custom
  backends.

Recipe section in `docs/public/07_vault.md` ("Custom backend with
a typed config — recommended"). Pinned by 8 unit tests + 1
public-surface test.

---

### 💭 Aspirational

#### `ASPIRE-01` — "Multi-consumer process" as an explicit design choice

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 💭 Aspirational |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept (position paper at suggested path) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `docs/public/multi_tenancy.md` (in-tree) + cross-link from `01_lifecycle.md` |

**Concern.** The hybrid module-global + opt-in `AppContext`
shape covers most "library-in-library" / multi-consumer
scenarios via PEP 567 contextvar isolation. But the design
question of whether mgf-common explicitly supports or
explicitly forbids multi-tenancy is worth a position paper —
silence is the worst option, since consumers who hit
ambiguity discover it via pain.

**Why it matters.** Decide whether `mgf-common` explicitly
supports or explicitly forbids multi-tenancy as part of the
public-API contract. The current shape supports it implicitly
(scoped `AppContext` context manager), but the contract isn't
documented as a stable promise.

**Suggested shape.** A `docs/public/multi_tenancy.md` walkthrough
that documents the supported scenarios:

  - Library plug-in with its own identity
  - Monorepo tests importing multiple consumer projects
  - Long-running services embedding consumer sub-components

…plus the unsupported ones (e.g., per-request identity in a
single-process server — that's what request-id contextvars are
for, not full identity isolation).

**Resolution.** Shipped as
[`docs/public/multi_tenancy.md`](../docs/public/multi_tenancy.md):
a position paper that commits the project to a specific shape.
The supported scenarios match the suggested list (S1 plug-in
framework, S2 monorepo tests, S3 long-running services with
finite tenants). The unsupported anti-pattern is named
explicitly: per-request identity in a single-process server —
with reasons (cardinality, crash-dir scatter, OTel
service.name semantics) and the right alternative
(`request_id` contextvar via the
fastapi/django middleware that already ships). The contract
table at the end is part of the public-API promise.

---

## §3. Multi-tenancy decision (design rationale)

The hardest unresolved design question, captured here in full so
the trade-offs survive even if the related entries above don't.

**Option A — "One app per process, explicit."**
- Pro: simple, fast (no contextvar lookup), matches 95% of real use.
- Con: forecloses on library-in-library architectures forever.

**Option B — Per-consumer `AppContext` (full contextvar).**
- Pro: supports every use case.
- Con: every observability function pays a contextvar lookup;
  surface-area doubles (every API needs a sibling that takes a
  context arg).

**Option C — Hybrid (the shipped shape).**
- Module-level globals for the default; `AppContext` as opt-in
  override. Observability resolves via the active context if any,
  else the global.
- Pro: zero overhead for the 95% case; extension available for
  the 5%.
- Con: two paths to reason about (acceptable: the second path is
  documented as a power-user escape hatch).

The Option C shape is what `mgf.common.bootstrap()` +
`AppContext` currently implement. PEP 567 contextvar semantics
give correct async-task isolation + thread isolation without
per-call plumbing. The `current_context()` fast path is a
single ContextVar.get() call (~30 ns).

---

## §4. Reviewer's meta-feedback

Unvarnished personal view from the maintainer + co-design partner.
Take or leave. No frontmatter — these aren't actionable items,
they're trajectory observations.

1. **`mgf-common` is more ambitious than its size suggests.**
   Small today; ambition (industry-standard Python infrastructure
   library) is enormous. Every decision should be made with
   "what would I do if this had 100 consumers" in mind.

2. **The reference-consumer model is a double-edged sword.**
   A co-designed reference consumer gives `mgf-common` a starting
   advantage but biases every decision toward "this works for
   <that consumer>". A second consumer's audit will surface
   assumptions the first can't see. **Recommendation:** even a
   single-file utility that uses `mgf.common.config` only would
   surface assumptions; recruit one early.

3. **The standards docs are heroic and 100% aimed at humans.**
   The "Rules box" pattern is great. But industry-standard also
   means machine-readable: the MUST/SHOULD/MAY set should be
   extractable as a JSON schema so a consumer's CI can run
   `mgf-common-lint` for a structured pass/fail report.

4. **The release flow is a latent risk.** Manual `uv publish`
   from a token file works fine for now. For an industry-standard
   library, plan the path to GPG-signed releases + SLSA provenance
   + a release branch requiring second-maintainer sign-off. Not
   urgent, but plan.

5. **The "cornerstone rhythm" — one shared library + many
   consumers — is the highest-leverage pattern in the project.**
   It captures something most libraries never articulate. Real
   audience is library AUTHORS, not consumers. Consider a separate
   `docs/for-library-authors/` track or a blog post to bootstrap
   the community.

---

## §5. How consumers submit feedback

Any project that depends on `mgf-common` — co-developed sibling,
external adopter, internal team project, hobby user — uses this
file to surface concerns. The submission flow is the same
regardless of relationship to the maintainers.

### Quick-start

```bash
# In a project that has mgf-common installed:
mgf-common feedback              # how to submit + severity guide
mgf-common feedback --template   # the entry template, ready to paste
mgf-common feedback --url        # this file's URL on codeberg
```

### Submission steps

1. **Read §1.4 (entry template) + §1.2 (severity).** The
   uniform shape is what makes the document machine-actionable.
   Don't deviate — the audit trail depends on it.
2. **Pick a fresh ID.** Format `<AREA>-<NN>` where `AREA` is a
   capitalised domain prefix (e.g., `API`, `HTTP`, `DB`,
   `CONFIG`, `SEC`, `TEST`, `VAULT`, `SSH`) and `NN` is a
   2-digit sequence within that area.
3. **Add the entry under §2** (open feedback). §2 is for "this
   is wrong / missing / painful." Roadmap-shaped requests —
   "this whole module would be useful" — also live in §2;
   severity tells you how urgent.
4. **Open a PR.** Two paths depending on access:
   - **Co-developer / sibling-project author**: PR directly
     against `mgf-common`'s `master`.
   - **External consumer (no PR access yet)**: open the
     codeberg PR from a fork. If you can't fork or PR
     (corporate firewall, etc.), open an issue at
     `https://codeberg.org/magogi-admin/mgf_common/issues` with
     "FEEDBACK:" prefix and paste the entry — a maintainer will
     mirror it into FEEDBACK.md and reference your issue.
5. **Triage** happens in the PR thread. The decision (accepted
   / rejected / deferred / scheduled) lands in the entry's
   `Decision` field. The maintainer drives this; submitters
   don't need to push.
6. **When shipped**, the entry's status changes to SHIPPED with
   a one-line retrospective on what was implemented + any
   shape changes. The CHANGELOG carries the full release-level
   detail.
7. **Rejected entries stay in the file** with rationale —
   recording "we considered this and said no, because…" is
   higher-leverage than recording only what shipped.

### What makes a great submission

- **Specific call site or example.** "I tried `MgfSettings(...)`
  with `extra_keys=['foo']` and got a confusing error" beats
  "settings are awkward."
- **Severity self-assessment.** Be honest. A 🔴 means "if we
  lock the API with this, fixing it is breaking later." Most
  things are 🟡 or 🟢; reserve 🔴 for genuine API-shape
  concerns.
- **Suggested shape, even if rough.** A wrong starting point is
  more useful than no starting point. The maintainer can refine.
- **One concern per entry.** Don't bundle. If you have three
  separate sharp edges, file three entries — they'll be triaged
  on different cadences.

### Don't worry about

- **Whether your concern is "important enough."** File it. The
  triage will sort severity. False-negative (concern missed) is
  more expensive than false-positive (entry triaged + closed
  quickly).
- **Whether the maintainer will be annoyed.** This file IS the
  design conversation.
- **Picking the perfect ID.** Maintainers will renumber if
  there's a clash. Get the entry in.

---

## §6. Cross-references

- Engineering standards: [`docs/standards/`](docs/standards/) (8 topic docs).
- Public-API contract: [`PUBLIC_API.md`](PUBLIC_API.md) (the AP-10 contract).
- Vulnerability-reporting policy: [`SECURITY.md`](SECURITY.md) (the SC-12 contract).
- Maintainer's dense-lookup doc: [`docs/claude/CLAUDE.md`](docs/claude/CLAUDE.md).
- Onboarding entry point: [`STARTHERE.md`](STARTHERE.md).
