"""Layer 1 — configure + setup_logging + emit one record.

The minimum viable use of mgf.common.observability for logging:
identity-then-setup-then-log. Output goes to stderr in text form
(TTY default).
"""

from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path

import mgf.common
from mgf.common.observability import setup_logging


def main() -> None:
    # Isolate state dir so the default rotating file lands in a tmp dir.
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["XDG_STATE_HOME"] = tmp

        # Identity flows through configure() — log paths, env-var
        # prefixes, and OTel service name all derive from app_name.
        # MUST come before any observability function.
        mgf.common.configure(app_name="example-simple-log", app_version="0.1.0")

        # Console + rotating file by default; we override log_file
        # so this example doesn't touch ~/.local/state.
        setup_logging(level="INFO", log_file=Path(tmp) / "demo.log")

        # Per-module logger via __name__ (rule LG-01).
        LOG = logging.getLogger(__name__)
        LOG.info("hello from mgf-common logging")


if __name__ == "__main__":
    main()
