"""Layer 1 — A tiny full app using v0.4 ``bootstrap()``.

The minimum viable app shape: one ``bootstrap()`` call wires
identity + logging + OTel + crash reporter + excepthooks. The
rest of the example is just "do work + log a line".

For the v0.1-style ``configure() + setup_logging() + ...`` shape,
see ``docs/MIGRATION_0.1_TO_0.3.md``. v0.4 trims the boilerplate
further — ``bootstrap()`` accepts no positional args; identity
auto-derives from the launching package's distribution metadata
when feasible (Phase B), else falls back to ``("app", "unknown")``
with an ``UnconfiguredWarning``.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import mgf.common
from mgf.common.observability import get_logger
from mgf.common.settings import LoggingSettings, MgfSettings


def do_thing() -> str:
    """The application's actual work."""
    log = get_logger(__name__)
    log.info("doing the thing")
    return "done"


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["XDG_STATE_HOME"] = tmp

        # bootstrap() is the single entry point. We pass identity
        # explicitly here because this is an ad-hoc script (not run
        # via `python -m mypackage`), so auto-derivation can't
        # find the dist metadata.
        with mgf.common.bootstrap(
            app_name="myapp",
            app_version="0.1.0",
            settings=MgfSettings(
                logging=LoggingSettings(
                    level="INFO",
                    file=Path(tmp) / "myapp.log",
                ),
            ),
        ):
            result = do_thing()
            print(f"result: {result!r}")


if __name__ == "__main__":
    main()
