"""Layer 1 — Subclass AppError, raise, catch by base class.

The minimum viable use of mgf.common.exceptions: define one
project-specific error type and let it propagate cleanly.
"""

from __future__ import annotations

from mgf.common.exceptions import AppError


class MyAppError(AppError):
    """Base for all errors this example raises."""


def main() -> None:
    try:
        raise MyAppError("something went wrong")
    except AppError as e:
        # Catching the base class catches every subclass.
        print(f"caught: {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
