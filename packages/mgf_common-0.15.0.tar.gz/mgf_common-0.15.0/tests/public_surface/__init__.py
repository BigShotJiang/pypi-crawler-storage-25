"""Public-surface tests — exercise the library AS A USER would.

Every test file in this package MUST import only from
``mgf.common.*`` (no underscore-prefixed module names). The pin
test ``test_no_private_imports.py`` enforces this with an AST
walk of every test file's import nodes.

The discipline matters because internals-aware tests can't catch
the kind of bugs the v0.4 reshape kept finding via consumer
integration: `_BootstrapContext` private return type leaking into
`PUBLIC_API.md` (Phase A); `_mgfcli` registration side-effect not
firing for consumer-built CLIs (Phase G3); `register_cli_subcommand`
return-type Union confusing mypy at consumer call sites (Phase G3).
Each was invisible from inside `tests/unit/`; visible immediately
from a user-perspective integration.

The PACKAGED-consumer signal (full pyproject.toml + venv +
installed wheel) lives in ``example_app/`` at the repo root. THIS
directory is the per-component depth equivalent — same posture
("test as the user sees it"), narrower scope (one public surface
per file), runs in the standard pytest suite.
"""
