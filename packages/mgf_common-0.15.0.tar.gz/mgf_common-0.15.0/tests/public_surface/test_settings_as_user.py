"""User-perspective tests for ``mgf.common.settings``.

Surfaces exercised:
  - :class:`mgf.common.settings.MgfSettings` + sub-models
  - Factory classmethods: ``dev()`` / ``production()`` / ``testing()``
  - Preset application (single + composable list)
  - Env-var overrides via ``MGF_*`` (both single and double underscore)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from mgf.common.settings import (
    LoggingSettings,
    MgfSettings,
    OtelSettings,
)

if TYPE_CHECKING:
    import pytest


class TestConstruction:
    def test_default_construction(self) -> None:
        s = MgfSettings()
        assert s.logging.level == "INFO"
        assert s.otel.enabled is False
        assert s.preset == "explicit"

    def test_explicit_overrides(self) -> None:
        s = MgfSettings(
            logging=LoggingSettings(level="DEBUG", format="json"),
        )
        assert s.logging.level == "DEBUG"
        assert s.logging.format == "json"


class TestFactories:
    def test_dev(self) -> None:
        s = MgfSettings.dev()
        assert s.preset == "dev"
        assert s.logging.level == "DEBUG"

    def test_production(self) -> None:
        s = MgfSettings.production()
        assert s.preset == "explicit"
        assert s.logging.format == "json"
        assert s.otel.sample_rate == 0.05

    def test_testing(self) -> None:
        s = MgfSettings.testing()
        assert s.logging.level == "WARNING"
        assert s.otel.enabled is False

    def test_factory_kwargs_win_over_defaults(self) -> None:
        s = MgfSettings.production(
            otel=OtelSettings(sample_rate=0.5),
        )
        assert s.otel.sample_rate == 0.5
        # Production's logging default still applies (factory only
        # overrides what the user supplied):
        assert s.logging.format == "json"


class TestComposablePresets:
    def test_list_preset(self) -> None:
        s = MgfSettings(preset=["docker", "dev"])
        # dev's level=DEBUG (no conflict with docker)
        assert s.logging.level == "DEBUG"
        # dev's format=text wins (later in list)
        assert s.logging.format == "text"


class TestEnvOverrides:
    """Single + double underscore both work (V04-04 SmartEnvSource)."""

    def test_single_underscore_form(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("MGF_LOGGING_LEVEL", "ERROR")
        s = MgfSettings()
        assert s.logging.level == "ERROR"

    def test_double_underscore_form_legacy(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("MGF_LOGGING__LEVEL", "WARNING")
        s = MgfSettings()
        assert s.logging.level == "WARNING"

    def test_underscored_field_name_resolved(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Field names with embedded underscores
        (``service_namespace``) are correctly disambiguated."""
        monkeypatch.setenv("MGF_OTEL_SERVICE_NAMESPACE", "my-team")
        s = MgfSettings()
        assert s.otel.service_namespace == "my-team"
