"""Unit tests for :mod:`mgf.common.observability.redaction`.

Verifies the default policy covers the well-known secret-bearing
keys, the Bearer / JWT / PEM value patterns are scrubbed regardless
of key, nested dicts and lists are walked, and per-project extras
augment (not replace) the default set.
"""

from __future__ import annotations

import re

import pytest

from mgf.common.observability.redaction import REDACTED_PLACEHOLDER, Redactor


@pytest.fixture
def default_redactor() -> Redactor:
    return Redactor.default()


# ---------------------------------------------------------------------------
# Key-based redaction (default policy)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "key",
    [
        "password",
        "Password",
        "PASSWORD",
        "passwd",
        "secret",
        "token",
        "api_key",
        "apikey",
        "private_key",
        "privatekey",
        "cookie",
        "set-cookie",
        "authorization",
        "auth",
        "session",
        "client_secret",
        "access_token",
        "refresh_token",
        "x-api-key",
    ],
)
def test_default_redactor_scrubs_well_known_keys(default_redactor: Redactor, key: str) -> None:
    payload = {key: "supersecret"}
    default_redactor.redact(payload)
    assert payload[key] == REDACTED_PLACEHOLDER


def test_unknown_key_is_left_alone(default_redactor: Redactor) -> None:
    payload = {"user_id": "u-123", "vm_name": "prod-1"}
    default_redactor.redact(payload)
    assert payload == {"user_id": "u-123", "vm_name": "prod-1"}


# ---------------------------------------------------------------------------
# Value-pattern redaction
# ---------------------------------------------------------------------------


def test_bearer_token_is_scrubbed_regardless_of_key(
    default_redactor: Redactor,
) -> None:
    payload = {"raw_log": "Authorization: Bearer abc123def456ghi"}
    default_redactor.redact(payload)
    assert REDACTED_PLACEHOLDER in payload["raw_log"]
    assert "abc123def456ghi" not in payload["raw_log"]


def test_jwt_is_scrubbed_regardless_of_key(default_redactor: Redactor) -> None:
    jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTYifQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV"
    payload = {"note": f"received {jwt} from peer"}
    default_redactor.redact(payload)
    assert REDACTED_PLACEHOLDER in payload["note"]
    assert "eyJ" not in payload["note"]


def test_pem_private_key_is_scrubbed(default_redactor: Redactor) -> None:
    pem = "-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEA...\n-----END RSA PRIVATE KEY-----"
    payload = {"key_blob": pem}
    default_redactor.redact(payload)
    assert payload["key_blob"] == REDACTED_PLACEHOLDER


# ---------------------------------------------------------------------------
# Recursive walk (nested dicts and lists)
# ---------------------------------------------------------------------------


def test_nested_dict_is_walked(default_redactor: Redactor) -> None:
    payload = {
        "outer": {
            "inner": {
                "password": "pw",
                "ok": "value",
            }
        }
    }
    default_redactor.redact(payload)
    assert payload["outer"]["inner"]["password"] == REDACTED_PLACEHOLDER
    assert payload["outer"]["inner"]["ok"] == "value"


def test_list_of_dicts_is_walked(default_redactor: Redactor) -> None:
    payload = {
        "users": [
            {"name": "a", "password": "p1"},
            {"name": "b", "password": "p2"},
        ]
    }
    default_redactor.redact(payload)
    for user in payload["users"]:
        assert user["password"] == REDACTED_PLACEHOLDER


# ---------------------------------------------------------------------------
# Extra keys (per-project additions)
# ---------------------------------------------------------------------------


def test_extra_keys_augment_default_set() -> None:
    redactor = Redactor(extra_keys=frozenset({"db_password", "vault_key"}))
    payload = {
        "db_password": "p",
        "vault_key": "k",
        "password": "still scrubbed",
        "username": "left alone",
    }
    redactor.redact(payload)
    assert payload["db_password"] == REDACTED_PLACEHOLDER
    assert payload["vault_key"] == REDACTED_PLACEHOLDER
    assert payload["password"] == REDACTED_PLACEHOLDER
    assert payload["username"] == "left alone"


def test_extra_value_patterns() -> None:
    redactor = Redactor(extra_value_patterns=(re.compile(r"sk_live_[A-Za-z0-9]+"),))
    payload = {"note": "stripe key sk_live_abc123 deployed"}
    redactor.redact(payload)
    assert REDACTED_PLACEHOLDER in payload["note"]
    assert "sk_live_abc123" not in payload["note"]


# ---------------------------------------------------------------------------
# redact_string (free-form string scrubbing)
# ---------------------------------------------------------------------------


def test_redact_string_scrubs_bearer(default_redactor: Redactor) -> None:
    out = default_redactor.redact_string("Bearer abc123def456ghi tail")
    assert "abc123def456ghi" not in out
    assert REDACTED_PLACEHOLDER in out


def test_redact_string_passes_clean_input_unchanged(
    default_redactor: Redactor,
) -> None:
    assert default_redactor.redact_string("hello world") == "hello world"


# ---------------------------------------------------------------------------
# FEEDBACK PAPER-01 — extended API-key value patterns
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("name", "secret"),
    [
        ("openai", "sk-" + "A" * 40),
        ("github_classic", "ghp_" + "A" * 36),
        ("github_oauth", "gho_" + "A" * 36),
        ("github_user", "ghu_" + "A" * 36),
        ("github_server", "ghs_" + "A" * 36),
        ("aws_access", "AKIAIOSFODNN7EXAMPLE"),
        ("slack_bot", "xoxb-1234-5678-AbCdEfGhIjKlMnOp"),
        ("google_api", "AIzaSy" + "A" * 33),
    ],
)
def test_paper_01_extended_api_key_patterns_are_redacted(
    default_redactor: Redactor, name: str, secret: str,
) -> None:
    """FEEDBACK PAPER-01: common API-key shapes MUST be scrubbed
    even when they appear in free-text values."""
    payload = {"message": f"connecting with {secret} in the body"}
    default_redactor.redact(payload)
    assert secret not in payload["message"], (
        f"PAPER-01: {name} secret pattern not redacted from free text"
    )
    assert REDACTED_PLACEHOLDER in payload["message"]


# ---------------------------------------------------------------------------
# FEEDBACK PAPER-02 — Redactor composition + DEFAULT_REDACTION_KEYS
# ---------------------------------------------------------------------------


def test_paper_02_default_redaction_keys_is_public_frozenset() -> None:
    """PAPER-02: ``DEFAULT_REDACTION_KEYS`` MUST be public + frozen
    so consumers can audit and extend without copy-paste."""
    from mgf.common.observability import DEFAULT_REDACTION_KEYS

    assert isinstance(DEFAULT_REDACTION_KEYS, frozenset)
    assert "password" in DEFAULT_REDACTION_KEYS
    assert "authorization" in DEFAULT_REDACTION_KEYS
    # frozen — attempted mutation raises.
    with pytest.raises(AttributeError):
        DEFAULT_REDACTION_KEYS.add("hypervisor_api_key")  # type: ignore[attr-defined]


def test_paper_02_redactor_composes_via_or() -> None:
    """PAPER-02: ``Redactor.default() | Redactor(extra_keys=...)``
    returns a redactor with the union of keys."""
    a = Redactor.default()
    b = Redactor(extra_keys=frozenset({"hypervisor_api_key"}))
    composed = a | b

    payload = {"hypervisor_api_key": "leak-me", "password": "also-leak"}
    composed.redact(payload)
    assert payload["hypervisor_api_key"] == REDACTED_PLACEHOLDER
    assert payload["password"] == REDACTED_PLACEHOLDER


def test_paper_02_compose_concatenates_value_patterns() -> None:
    """Composing concatenates the extra value-pattern tuples."""
    import re

    pat_one = re.compile(r"PROJECT-A-\d+")
    pat_two = re.compile(r"PROJECT-B-\d+")
    a = Redactor(extra_value_patterns=(pat_one,))
    b = Redactor(extra_value_patterns=(pat_two,))
    composed = a | b

    out = composed.redact_string("PROJECT-A-42 and PROJECT-B-7 in one line")
    assert "PROJECT-A-42" not in out
    assert "PROJECT-B-7" not in out
