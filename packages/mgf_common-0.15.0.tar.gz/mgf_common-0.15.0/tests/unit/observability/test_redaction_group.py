"""Tests for ``RedactionGroup`` enum (v0.8 ergonomics).

The enum is a typo-proof alternative to bare strings in
``RedactionSettings.enabled_pattern_groups``. It MUST stay
str-compatible — pre-existing str-keyed code keeps working
unchanged.
"""

from __future__ import annotations

from mgf.common.observability import RedactionGroup, Redactor
from mgf.common.settings import MgfSettings, RedactionSettings


class TestEnumIsStr:
    def test_enum_member_is_str(self) -> None:
        # str-Enum: the enum value IS a string. Crucial for settings
        # that type the field as ``list[str]`` — passing an enum value
        # must Just Work without coercion ceremony.
        assert isinstance(RedactionGroup.BUILTIN, str)
        assert RedactionGroup.BUILTIN == "builtin"
        assert RedactionGroup.BUILTIN.value == "builtin"

    def test_enum_in_str_set(self) -> None:
        # Mixed str/enum membership tests work.
        active = {RedactionGroup.BUILTIN, "consumer-group"}
        assert "builtin" in active
        assert RedactionGroup.BUILTIN in active


class TestSettingsCompat:
    def test_enum_value_passes_through_settings(self) -> None:
        # The settings field is `list[str]`; pydantic should accept
        # the enum (str-Enum is a str subclass) and coerce to str.
        settings = RedactionSettings(
            enabled_pattern_groups=[RedactionGroup.BUILTIN],
        )
        assert settings.enabled_pattern_groups == ["builtin"]
        # After model_dump, the value is a plain str.
        assert isinstance(settings.enabled_pattern_groups[0], str)

    def test_mixed_str_and_enum_accepted(self) -> None:
        # Real consumers register custom groups via
        # register_redaction_pattern_group + reference them by string
        # name. Mixing the enum (canonical) with strings (consumer-
        # registered) MUST work.
        settings = RedactionSettings(
            enabled_pattern_groups=[
                RedactionGroup.BUILTIN,
                "my-product-tokens",
            ],
        )
        assert settings.enabled_pattern_groups == [
            "builtin",
            "my-product-tokens",
        ]

    def test_default_is_builtin(self) -> None:
        # Default behavior unchanged — the field default is still
        # ["builtin"]; the enum is additive, not a replacement.
        settings = RedactionSettings()
        assert settings.enabled_pattern_groups == ["builtin"]

    def test_mgf_settings_composition(self) -> None:
        # Round-trip through MgfSettings to ensure no validator
        # re-rejects the str-Enum upstream of RedactionSettings.
        mgf = MgfSettings(
            redaction=RedactionSettings(
                enabled_pattern_groups=[RedactionGroup.BUILTIN],
            ),
        )
        assert mgf.redaction.enabled_pattern_groups == ["builtin"]


class TestRedactorActive:
    def test_redactor_default_works_with_enum_groups(self) -> None:
        # End-to-end smoke: default Redactor has the builtin patterns
        # active; redacting a record with a Bearer token still scrubs.
        redactor = Redactor.default()
        record: dict[str, object] = {"auth": "Bearer abc.def.ghi"}
        redactor.redact(record)
        assert record["auth"] != "Bearer abc.def.ghi"
