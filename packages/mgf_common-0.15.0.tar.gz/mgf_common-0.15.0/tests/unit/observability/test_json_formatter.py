"""Unit tests for :mod:`mgf.common.observability.json_formatter`.

Verifies the JSON shape (every documented top-level key present),
extras are promoted, exceptions are formatted, redaction runs, and
OpenTelemetry trace context is attached when a span is active (and
absent when no span / no SDK).
"""

from __future__ import annotations

import json
import logging
from typing import Any

from mgf.common.observability.json_formatter import JsonFormatter
from mgf.common.observability.redaction import REDACTED_PLACEHOLDER, Redactor


def _make_record(
    *,
    name: str = "mgf.test",
    level: int = logging.INFO,
    msg: str = "hello",
    extra: dict[str, Any] | None = None,
    exc_info: object = None,
) -> logging.LogRecord:
    record = logging.LogRecord(
        name=name,
        level=level,
        pathname="test.py",
        lineno=42,
        msg=msg,
        args=None,
        exc_info=exc_info,  # type: ignore[arg-type]
        func="test_func",
    )
    if extra:
        for k, v in extra.items():
            setattr(record, k, v)
    return record


# ---------------------------------------------------------------------------
# Shape
# ---------------------------------------------------------------------------


def test_record_shape_has_documented_top_level_keys() -> None:
    fmt = JsonFormatter(redactor=Redactor.default())
    record = _make_record(msg="started")
    out = json.loads(fmt.format(record))
    assert set(out.keys()) >= {
        "ts",
        "level",
        "logger",
        "msg",
        "module",
        "func",
        "line",
        "thread",
        "process",
    }
    assert out["msg"] == "started"
    assert out["level"] == "INFO"
    assert out["logger"] == "mgf.test"


def test_extras_are_promoted_to_top_level_keys() -> None:
    fmt = JsonFormatter(redactor=Redactor.default())
    record = _make_record(extra={"vm_name": "prod-1", "duration_ms": 142})
    out = json.loads(fmt.format(record))
    assert out["vm_name"] == "prod-1"
    assert out["duration_ms"] == 142


def test_redaction_runs_on_extras() -> None:
    fmt = JsonFormatter(redactor=Redactor.default())
    record = _make_record(extra={"password": "supersecret", "user": "alice"})
    out = json.loads(fmt.format(record))
    assert out["password"] == REDACTED_PLACEHOLDER
    assert out["user"] == "alice"


def test_one_record_is_one_line() -> None:
    fmt = JsonFormatter(redactor=Redactor.default())
    record = _make_record(extra={"vm_name": "x", "msg_count": 5})
    line = fmt.format(record)
    assert "\n" not in line


# ---------------------------------------------------------------------------
# Exception formatting
# ---------------------------------------------------------------------------


def test_exc_info_is_attached_as_exception_field() -> None:
    fmt = JsonFormatter(redactor=Redactor.default())
    try:
        raise RuntimeError("boom")
    except RuntimeError:
        import sys

        record = _make_record(level=logging.ERROR, msg="fail", exc_info=sys.exc_info())
    out = json.loads(fmt.format(record))
    assert "exception" in out
    assert "RuntimeError" in out["exception"]
    assert "boom" in out["exception"]


# ---------------------------------------------------------------------------
# OpenTelemetry trace context
# ---------------------------------------------------------------------------


def test_no_otel_no_trace_keys_in_record() -> None:
    """Without an active span (or SDK), trace keys are absent."""
    fmt = JsonFormatter(redactor=Redactor.default())
    record = _make_record(msg="no span")
    out = json.loads(fmt.format(record))
    # Either OTel is not installed at all (keys absent) OR OTel is
    # installed but no active span (keys absent because span is the
    # invalid no-op span). Either way, no trace_id / span_id present.
    assert "trace_id" not in out
    assert "span_id" not in out
