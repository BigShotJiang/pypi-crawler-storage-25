"""Unit tests for :mod:`mgf.common.observability.excepthook` and
:mod:`mgf.common.observability.threading_excepthook`.

The hooks have side effects on global state (sys.excepthook,
threading.excepthook) — the tests carefully save and restore the
prior state via fixtures so they never leak across the suite.
"""

from __future__ import annotations

import sys
import threading
from typing import TYPE_CHECKING

import pytest

from mgf.common.observability.excepthook import install_excepthook
from mgf.common.observability.threading_excepthook import install_threading_excepthook

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path

_APP = "mgftest"


@pytest.fixture
def _restore_sys_excepthook() -> Iterator[None]:
    prior = sys.excepthook
    yield
    sys.excepthook = prior


@pytest.fixture
def _restore_threading_excepthook() -> Iterator[None]:
    prior = threading.excepthook
    yield
    threading.excepthook = prior


@pytest.fixture(autouse=True)
def _isolate_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))


# ---------------------------------------------------------------------------
# install_excepthook
# ---------------------------------------------------------------------------


def test_install_excepthook_replaces_sys_excepthook(
    _restore_sys_excepthook: None,
) -> None:
    prior = sys.excepthook
    install_excepthook()
    assert sys.excepthook is not prior


def test_install_excepthook_is_idempotent(
    _restore_sys_excepthook: None,
) -> None:
    install_excepthook()
    once = sys.excepthook
    install_excepthook()
    twice = sys.excepthook
    # Same wrapper — second call is a no-op (no double-stacking).
    assert once is twice


def test_excepthook_writes_crash_report_for_runtime_error(
    tmp_path: Path,
    _restore_sys_excepthook: None,
) -> None:
    # Replace the prior hook with a no-op BEFORE installing ours, so
    # the chain at the end of our hook doesn't surface the synthetic
    # exception back to pytest and confuse the runner.
    sys.excepthook = lambda *_args: None
    install_excepthook()

    try:
        raise RuntimeError("excepthook test")
    except RuntimeError as e:
        sys.excepthook(type(e), e, e.__traceback__)

    crash_dir = tmp_path / "state" / _APP / "crashes"
    assert crash_dir.exists()
    files = list(crash_dir.glob("*.json"))
    assert files, "no crash report written by sys.excepthook"


def test_excepthook_lets_keyboard_interrupt_through(
    tmp_path: Path,
    _restore_sys_excepthook: None,
) -> None:
    # No-op prior hook so we don't perturb pytest's runner.
    sys.excepthook = lambda *_args: None
    install_excepthook()
    try:
        raise KeyboardInterrupt
    except KeyboardInterrupt as e:
        sys.excepthook(type(e), e, e.__traceback__)
    # KeyboardInterrupt is NOT a bug — no crash report should be written.
    crash_dir = tmp_path / "state" / _APP / "crashes"
    if crash_dir.exists():
        assert list(crash_dir.glob("*.json")) == []


# ---------------------------------------------------------------------------
# install_threading_excepthook
# ---------------------------------------------------------------------------


def test_install_threading_excepthook_replaces_hook(
    _restore_threading_excepthook: None,
) -> None:
    prior = threading.excepthook
    install_threading_excepthook()
    assert threading.excepthook is not prior


def test_install_threading_excepthook_is_idempotent(
    _restore_threading_excepthook: None,
) -> None:
    install_threading_excepthook()
    once = threading.excepthook
    install_threading_excepthook()
    twice = threading.excepthook
    assert once is twice


def test_threading_excepthook_skips_systemexit_silently(
    tmp_path: Path,
    _restore_threading_excepthook: None,
) -> None:
    threading.excepthook = lambda _args: None
    install_threading_excepthook()
    args = threading.ExceptHookArgs(
        (SystemExit, SystemExit("clean stop"), None, threading.current_thread())
    )
    threading.excepthook(args)
    crash_dir = tmp_path / "state" / _APP / "crashes"
    if crash_dir.exists():
        assert list(crash_dir.glob("*.json")) == []


def test_threading_excepthook_writes_crash_report_for_runtime_error(
    tmp_path: Path,
    _restore_threading_excepthook: None,
) -> None:
    threading.excepthook = lambda _args: None
    install_threading_excepthook()
    try:
        raise RuntimeError("thread crash")
    except RuntimeError as e:
        args = threading.ExceptHookArgs(
            (type(e), e, e.__traceback__, threading.current_thread()),
        )
        threading.excepthook(args)
    crash_dir = tmp_path / "state" / _APP / "crashes"
    assert crash_dir.exists()
    files = list(crash_dir.glob("*.json"))
    assert files, "thread crash report not written"
