"""Tests for ``mgf.common.http.AsyncHttpClient``.

Uses respx to mock httpx — no real network calls.
"""

from __future__ import annotations

import warnings

import httpx
import pytest
import respx

from mgf.common.http import AsyncHttpClient, HttpClientError, RetryPolicy

# ---------------------------------------------------------------------------
# Construction.
# ---------------------------------------------------------------------------


class TestConstruction:
    def test_defaults(self) -> None:
        client = AsyncHttpClient()
        assert client._timeout == 30.0
        assert client._retry.max_attempts == 0
        # User-Agent set on the underlying httpx client.
        assert "User-Agent" in client.client.headers

    def test_user_agent_includes_mgf_common(self) -> None:
        client = AsyncHttpClient()
        ua = client.client.headers["User-Agent"]
        assert "mgf-common/" in ua

    def test_explicit_user_agent_overrides_default(self) -> None:
        client = AsyncHttpClient(user_agent="my-app/1.0")
        assert client.client.headers["User-Agent"] == "my-app/1.0"

    def test_default_headers_merged(self) -> None:
        client = AsyncHttpClient(default_headers={"X-Tenant": "acme"})
        assert client.client.headers["x-tenant"] == "acme"
        # Default User-Agent still present.
        assert "User-Agent" in client.client.headers

    def test_zero_timeout_rejected(self) -> None:
        with pytest.raises(ValueError, match="> 0"):
            AsyncHttpClient(timeout=0)

    def test_negative_timeout_rejected(self) -> None:
        with pytest.raises(ValueError, match="> 0"):
            AsyncHttpClient(timeout=-5.0)

    def test_verify_tls_disabled_emits_warning(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Reset the one-shot guard so the warning fires.
        from mgf.common.http import _client as _client_mod

        monkeypatch.setattr(_client_mod, "_TLS_DISABLE_WARNED", False)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            AsyncHttpClient(verify_tls=False)
        msgs = [str(w.message) for w in caught if issubclass(w.category, UserWarning)]
        assert any("verify_tls=False" in m for m in msgs)

    def test_verify_tls_disabled_warning_one_shot(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from mgf.common.http import _client as _client_mod

        monkeypatch.setattr(_client_mod, "_TLS_DISABLE_WARNED", False)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            AsyncHttpClient(verify_tls=False)
            AsyncHttpClient(verify_tls=False)
            AsyncHttpClient(verify_tls=False)
        tls_warnings = [
            w
            for w in caught
            if "verify_tls=False" in str(w.message)
        ]
        assert len(tls_warnings) == 1


# ---------------------------------------------------------------------------
# Basic requests via respx.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestBasicRequests:
    @respx.mock
    async def test_get(self) -> None:
        respx.get("https://api.example.com/users").mock(
            return_value=httpx.Response(200, json=[{"id": 1}])
        )
        async with AsyncHttpClient() as client:
            response = await client.get("https://api.example.com/users")
        assert response.status_code == 200
        assert response.json() == [{"id": 1}]

    @respx.mock
    async def test_post_with_json(self) -> None:
        import json as _json

        route = respx.post("https://api.example.com/users").mock(
            return_value=httpx.Response(201, json={"id": "new"})
        )
        async with AsyncHttpClient() as client:
            response = await client.post(
                "https://api.example.com/users",
                json={"name": "alice"},
            )
        assert response.status_code == 201
        # JSON-decode-compare to dodge spaces vs. no-spaces in encoding.
        sent = _json.loads(route.calls.last.request.read())
        assert sent == {"name": "alice"}

    @respx.mock
    async def test_put_patch_delete_head(self) -> None:
        respx.put("https://x.test/y").mock(return_value=httpx.Response(200))
        respx.patch("https://x.test/y").mock(return_value=httpx.Response(200))
        respx.delete("https://x.test/y").mock(return_value=httpx.Response(204))
        respx.head("https://x.test/y").mock(return_value=httpx.Response(200))

        async with AsyncHttpClient() as client:
            assert (await client.put("https://x.test/y")).status_code == 200
            assert (await client.patch("https://x.test/y")).status_code == 200
            assert (await client.delete("https://x.test/y")).status_code == 204
            assert (await client.head("https://x.test/y")).status_code == 200

    @respx.mock
    async def test_4xx_returns_response_not_raises(self) -> None:
        respx.get("https://x.test/y").mock(return_value=httpx.Response(404))
        async with AsyncHttpClient() as client:
            response = await client.get("https://x.test/y")
        # 4xx is the consumer's decision; we don't raise here.
        assert response.status_code == 404

    @respx.mock
    async def test_500_returns_response_not_raises(self) -> None:
        respx.get("https://x.test/y").mock(return_value=httpx.Response(500))
        async with AsyncHttpClient() as client:
            response = await client.get("https://x.test/y")
        assert response.status_code == 500


# ---------------------------------------------------------------------------
# Headers + base_url.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestHeadersAndBaseUrl:
    @respx.mock
    async def test_request_headers_merged_with_default(self) -> None:
        route = respx.get("https://x.test/y").mock(
            return_value=httpx.Response(200)
        )
        async with AsyncHttpClient(
            default_headers={"X-Tenant": "acme"}
        ) as client:
            await client.get(
                "https://x.test/y",
                headers={"X-Request-Id": "req-001"},
            )
        sent = route.calls.last.request
        assert sent.headers["x-tenant"] == "acme"
        assert sent.headers["x-request-id"] == "req-001"

    @respx.mock
    async def test_base_url_prefix(self) -> None:
        respx.get("https://api.example.com/v1/users").mock(
            return_value=httpx.Response(200)
        )
        async with AsyncHttpClient(
            base_url="https://api.example.com/v1"
        ) as client:
            response = await client.get("/users")
        assert response.status_code == 200

    @respx.mock
    async def test_cookies_attached(self) -> None:
        route = respx.get("https://x.test/y").mock(
            return_value=httpx.Response(200)
        )
        async with AsyncHttpClient() as client:
            await client.get(
                "https://x.test/y",
                cookies={"session": "session-id-xyz"},
            )
        sent = route.calls.last.request
        cookie_header = sent.headers.get("cookie", "")
        assert "session=session-id-xyz" in cookie_header


# ---------------------------------------------------------------------------
# Error translation.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestErrorTranslation:
    @respx.mock
    async def test_timeout_raises_httpclienterror(self) -> None:
        respx.get("https://x.test/y").mock(
            side_effect=httpx.ReadTimeout("read timed out")
        )
        async with AsyncHttpClient() as client:
            with pytest.raises(HttpClientError) as exc_info:
                await client.get("https://x.test/y")
        assert "timeout" in exc_info.value.cause_summary.lower()
        assert exc_info.value.url == "https://x.test/y"
        assert exc_info.value.attempts == 1
        assert isinstance(exc_info.value.__cause__, httpx.ReadTimeout)

    @respx.mock
    async def test_connect_error_raises_httpclienterror(self) -> None:
        respx.get("https://x.test/y").mock(
            side_effect=httpx.ConnectError("dns down")
        )
        async with AsyncHttpClient() as client:
            with pytest.raises(HttpClientError) as exc_info:
                await client.get("https://x.test/y")
        assert "connect error" in exc_info.value.cause_summary.lower()

    @respx.mock
    async def test_network_error_raises_httpclienterror(self) -> None:
        respx.get("https://x.test/y").mock(
            side_effect=httpx.ReadError("read failed")
        )
        async with AsyncHttpClient() as client:
            with pytest.raises(HttpClientError) as exc_info:
                await client.get("https://x.test/y")
        assert "network error" in exc_info.value.cause_summary.lower()

    @respx.mock
    async def test_unsupported_protocol_not_retried(self) -> None:
        # UnsupportedProtocol is an httpx.HTTPError that's NOT a
        # network/timeout — covers the catch-all "other HTTPError"
        # path. Non-retryable; single attempt; wrapped in
        # HttpClientError.
        respx.get("https://x.test/y").mock(
            side_effect=httpx.UnsupportedProtocol("scheme not supported")
        )
        async with AsyncHttpClient(
            retry=RetryPolicy(max_attempts=3)
        ) as client:
            with pytest.raises(HttpClientError) as exc_info:
                await client.get("https://x.test/y")
        assert exc_info.value.attempts == 1


# ---------------------------------------------------------------------------
# Retry behavior.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestRetry:
    @respx.mock
    async def test_no_retry_by_default(self) -> None:
        route = respx.get("https://x.test/y").mock(
            side_effect=httpx.ReadTimeout("timeout")
        )
        async with AsyncHttpClient() as client:
            with pytest.raises(HttpClientError) as exc_info:
                await client.get("https://x.test/y")
        # Single attempt because max_attempts=0.
        assert route.call_count == 1
        assert exc_info.value.attempts == 1

    @respx.mock
    async def test_retry_on_transport_failure(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Make backoff instant for fast tests.
        from mgf.common.http import _retry

        monkeypatch.setattr(_retry.RetryPolicy, "backoff_for_attempt", lambda self, attempt: 0.0)

        # First two calls fail, third succeeds.
        responses = [
            httpx.ReadTimeout("timeout 1"),
            httpx.ReadTimeout("timeout 2"),
            httpx.Response(200, json={"ok": True}),
        ]
        route = respx.get("https://x.test/y").mock(side_effect=responses)

        async with AsyncHttpClient(
            retry=RetryPolicy(max_attempts=3)
        ) as client:
            response = await client.get("https://x.test/y")

        assert response.status_code == 200
        assert route.call_count == 3

    @respx.mock
    async def test_retry_exhaustion_raises(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from mgf.common.http import _retry as _r

        monkeypatch.setattr(_r.RetryPolicy, "backoff_for_attempt", lambda self, attempt: 0.0)

        respx.get("https://x.test/y").mock(
            side_effect=httpx.ReadTimeout("perma-timeout")
        )
        async with AsyncHttpClient(
            retry=RetryPolicy(max_attempts=2)
        ) as client:
            with pytest.raises(HttpClientError) as exc_info:
                await client.get("https://x.test/y")
        # 1 initial + 2 retries = 3 attempts.
        assert exc_info.value.attempts == 3

    @respx.mock
    async def test_post_not_retried_by_default(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from mgf.common.http import _retry as _r

        monkeypatch.setattr(_r.RetryPolicy, "backoff_for_attempt", lambda self, attempt: 0.0)

        # POST is not retryable by default.
        route = respx.post("https://x.test/y").mock(
            side_effect=httpx.ReadTimeout("timeout")
        )
        async with AsyncHttpClient(
            retry=RetryPolicy(max_attempts=5)
        ) as client:
            with pytest.raises(HttpClientError) as exc_info:
                await client.post("https://x.test/y")
        # Single attempt — POST not in retryable set.
        assert route.call_count == 1
        assert exc_info.value.attempts == 1

    @respx.mock
    async def test_post_retried_when_explicitly_allowed(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from mgf.common.http import _retry as _r

        monkeypatch.setattr(_r.RetryPolicy, "backoff_for_attempt", lambda self, attempt: 0.0)

        responses = [
            httpx.ReadTimeout("timeout"),
            httpx.Response(201, json={"id": "new"}),
        ]
        route = respx.post("https://x.test/y").mock(side_effect=responses)
        policy = RetryPolicy(
            max_attempts=2,
            retryable_methods=frozenset({"POST"}),
        )
        async with AsyncHttpClient(retry=policy) as client:
            response = await client.post("https://x.test/y")
        assert response.status_code == 201
        assert route.call_count == 2

    @respx.mock
    async def test_retry_on_503(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from mgf.common.http import _retry as _r

        monkeypatch.setattr(_r.RetryPolicy, "backoff_for_attempt", lambda self, attempt: 0.0)

        responses = [
            httpx.Response(503),
            httpx.Response(200, json={"ok": True}),
        ]
        route = respx.get("https://x.test/y").mock(side_effect=responses)
        async with AsyncHttpClient(
            retry=RetryPolicy(max_attempts=2)
        ) as client:
            response = await client.get("https://x.test/y")
        assert response.status_code == 200
        assert route.call_count == 2

    @respx.mock
    async def test_no_retry_on_404(self) -> None:
        # 404 is not in the retryable_statuses set.
        respx.get("https://x.test/y").mock(return_value=httpx.Response(404))
        async with AsyncHttpClient(
            retry=RetryPolicy(max_attempts=3)
        ) as client:
            response = await client.get("https://x.test/y")
        assert response.status_code == 404


# ---------------------------------------------------------------------------
# Per-call overrides.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestPerCallOverrides:
    @respx.mock
    async def test_per_call_retry_overrides_constructor(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from mgf.common.http import _retry as _r

        monkeypatch.setattr(_r.RetryPolicy, "backoff_for_attempt", lambda self, attempt: 0.0)

        responses = [httpx.ReadTimeout("timeout"), httpx.Response(200)]
        route = respx.get("https://x.test/y").mock(side_effect=responses)

        # Constructor: max_attempts=0. Per-call: max_attempts=2.
        async with AsyncHttpClient() as client:
            response = await client.request(
                "GET",
                "https://x.test/y",
                retry=RetryPolicy(max_attempts=2),
            )
        assert response.status_code == 200
        assert route.call_count == 2


# ---------------------------------------------------------------------------
# Lifecycle.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestLifecycle:
    async def test_aclose_idempotent(self) -> None:
        client = AsyncHttpClient()
        await client.aclose()
        await client.aclose()  # second call must not raise

    @respx.mock
    async def test_async_context_manager(self) -> None:
        respx.get("https://x.test/y").mock(return_value=httpx.Response(200))
        async with AsyncHttpClient() as client:
            response = await client.get("https://x.test/y")
        assert response.status_code == 200


# ---------------------------------------------------------------------------
# Redaction in logs.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestRedaction:
    @respx.mock
    async def test_authorization_redacted_in_log(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        import logging

        respx.get("https://x.test/y").mock(return_value=httpx.Response(200))
        with caplog.at_level(logging.INFO, logger="mgf.common.http"):
            async with AsyncHttpClient() as client:
                await client.get(
                    "https://x.test/y",
                    headers={"Authorization": "Bearer secret-xyz"},
                )

        log_text = " ".join(r.getMessage() for r in caplog.records)
        # The header NAME is in the log; the VALUE is not.
        assert "Authorization" in log_text
        assert "Bearer secret-xyz" not in log_text
        assert "<redacted>" in log_text

    @respx.mock
    async def test_cookie_redacted_in_log(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        import logging

        respx.get("https://x.test/y").mock(return_value=httpx.Response(200))
        with caplog.at_level(logging.INFO, logger="mgf.common.http"):
            async with AsyncHttpClient() as client:
                await client.get(
                    "https://x.test/y",
                    headers={"Cookie": "session=secret-session-id"},
                )
        log_text = " ".join(r.getMessage() for r in caplog.records)
        assert "secret-session-id" not in log_text

    @respx.mock
    async def test_non_secret_headers_not_redacted(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        import logging

        respx.get("https://x.test/y").mock(return_value=httpx.Response(200))
        with caplog.at_level(logging.INFO, logger="mgf.common.http"):
            async with AsyncHttpClient() as client:
                await client.get(
                    "https://x.test/y",
                    headers={"X-Tenant": "acme"},
                )
        log_text = " ".join(r.getMessage() for r in caplog.records)
        assert "acme" in log_text
