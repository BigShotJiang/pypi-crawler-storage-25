"""Pin: per-record logging cost MUST stay below 100 µs.

Rule **LG-12** (LOGGING.md §13). The budget is the file-sink path —
``RotatingFileHandler`` is the synchronous IO surface. Console
output is dominated by the terminal / pytest-capture overhead in
production-equivalent ways, but the file write per record is
something we own.

This is the consumer-side guard pattern from LOGGING.md §11.2:
even though the implementation lives in ``mgf.common.observability``,
the project keeps its own perf pin so a refactor that silently
violates the budget lights up here, before any consumer sees it.

The pytest-capture trap: the default console ``StreamHandler``
runs through pytest's stderr capture which inflates the per-record
number by 30-40 %. The test removes the console handler before
the timed loop so we measure the production path.
"""

from __future__ import annotations

import contextlib
import logging
import time
from logging.handlers import RotatingFileHandler
from typing import TYPE_CHECKING

import pytest

import mgf.common
from mgf.common.observability import setup_logging

if TYPE_CHECKING:
    from pathlib import Path

# Soft margin over the 100 µs MUST so a noisy CI run doesn't false-
# positive on cold caches. Investigate any drift toward this number;
# treat anything over the MUST as a regression.
_BUDGET_US = 100.0


@pytest.fixture
def _isolate_logging() -> None:
    """Save + restore the root logger handlers around the test."""
    yield
    for h in logging.root.handlers[:]:
        with contextlib.suppress(Exception):
            h.close()
        logging.root.removeHandler(h)


@pytest.mark.usefixtures("_isolate_logging")
def test_per_record_under_100us(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """LG-12: each emitted record MUST cost under 100 µs at INFO."""
    # Identity isolation — the autouse fixture in tests/unit/observability/
    # does this already, but this test lives outside that scope.
    monkeypatch.setattr(mgf.common, "configure", mgf.common.configure)
    mgf.common.configure(app_name="perf-test", app_version="0.0.0")

    monkeypatch.delenv("JOURNAL_STREAM", raising=False)
    monkeypatch.delenv("INVOCATION_ID", raising=False)

    log_file = tmp_path / "perf.log"
    setup_logging(level="DEBUG", fmt="json", log_file=log_file)

    # Drop the console StreamHandler so the timed loop measures the
    # rotating-file path (the surface LG-12 actually constrains)
    # without paying for pytest's stderr-capture machinery per
    # record. See LOGGING.md §11.1 for the full rationale.
    for h in logging.root.handlers[:]:
        if not isinstance(h, RotatingFileHandler):
            logging.root.removeHandler(h)

    log = logging.getLogger("perf.test")

    # Warm-up: prime the path-resolver cache, the formatter, and the
    # file handle.
    for i in range(100):
        log.info("warmup", extra={"i": i})

    n = 5_000
    start = time.perf_counter()
    for i in range(n):
        log.info(
            "benchmark message",
            extra={"iteration": i, "subject": "alice", "kind": "info"},
        )
    elapsed = time.perf_counter() - start

    per_record_us = (elapsed / n) * 1_000_000
    assert per_record_us < _BUDGET_US, (
        f"LG-12 budget breach: {per_record_us:.1f} µs/record "
        f"(budget {_BUDGET_US:.0f} µs). "
        f"Investigate the rotating-file sink path; perhaps a new "
        f"per-record allocation in JsonFormatter."
    )
