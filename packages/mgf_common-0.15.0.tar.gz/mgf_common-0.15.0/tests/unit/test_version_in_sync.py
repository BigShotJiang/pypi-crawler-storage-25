"""Pin: ``mgf.common.__version__`` MUST match ``pyproject.toml``.

Rule **AP-13** — the version string lives in exactly one place
conceptually (the package itself) and is mirrored everywhere
mechanically. Drift is silent without this pin: a release tag may
ship a wheel whose ``__version__`` says one thing while PyPI's
metadata says another.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

import mgf.common


def test_pyproject_version_matches_dunder() -> None:
    """``mgf.common.__version__`` MUST equal ``pyproject.toml::project.version``."""
    pyproject = Path(__file__).resolve().parent.parent.parent / "pyproject.toml"
    declared = tomllib.loads(pyproject.read_text())["project"]["version"]
    assert mgf.common.__version__ == declared, (
        f"AP-13 version drift: __version__={mgf.common.__version__!r} "
        f"pyproject={declared!r}. "
        f"Update both in the same commit when bumping a release."
    )
