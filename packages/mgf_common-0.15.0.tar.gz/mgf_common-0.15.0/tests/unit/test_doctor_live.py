"""Tests for v0.5 Phase E — `doctor --live` and `doctor --redaction`."""

from __future__ import annotations

import io
import json
from typing import TYPE_CHECKING

from mgf.common.cli._doctor_live import (
    RUNTIME_SNAPSHOT_ENV_VAR,
    doctor_live,
    doctor_redaction,
    emit_runtime_snapshot,
)
from mgf.common.cli._exit_codes import EXIT_OPERATION_ERROR, EXIT_SUCCESS

if TYPE_CHECKING:
    from pathlib import Path

    import pytest

# ---------------------------------------------------------------------------
# emit_runtime_snapshot — bootstrap-side helper.
# ---------------------------------------------------------------------------


class TestEmitRuntimeSnapshot:
    def test_writes_when_env_var_set(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        target = tmp_path / "runtime.json"
        monkeypatch.setenv(RUNTIME_SNAPSHOT_ENV_VAR, str(target))
        emit_runtime_snapshot({"app_name": "test", "app_version": "1.0"})
        assert target.exists()
        loaded = json.loads(target.read_text())
        assert loaded == {"app_name": "test", "app_version": "1.0"}

    def test_noop_when_env_var_unset(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv(RUNTIME_SNAPSHOT_ENV_VAR, raising=False)
        emit_runtime_snapshot({"app_name": "test"})
        # No file written anywhere predictable.

    def test_creates_parent_directory(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        target = tmp_path / "nested" / "deep" / "runtime.json"
        monkeypatch.setenv(RUNTIME_SNAPSHOT_ENV_VAR, str(target))
        emit_runtime_snapshot({"app_name": "test"})
        assert target.exists()

    def test_overwrites_existing_snapshot(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        target = tmp_path / "runtime.json"
        target.write_text('{"old": "data"}')
        monkeypatch.setenv(RUNTIME_SNAPSHOT_ENV_VAR, str(target))
        emit_runtime_snapshot({"new": "data"})
        loaded = json.loads(target.read_text())
        assert loaded == {"new": "data"}

    def test_does_not_raise_on_oserror(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Path that can't be written (root dir on a read-only-mounted file).
        # Use an obviously-invalid path that triggers OSError.
        monkeypatch.setenv(RUNTIME_SNAPSHOT_ENV_VAR, "/proc/this/cannot/be/created")
        # Must not raise — bootstrap depends on it being safe.
        emit_runtime_snapshot({"x": "y"})


# ---------------------------------------------------------------------------
# doctor_live — read snapshot.
# ---------------------------------------------------------------------------


class TestDoctorLive:
    def test_returns_error_when_env_unset(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv(RUNTIME_SNAPSHOT_ENV_VAR, raising=False)
        out = io.StringIO()
        rc = doctor_live(out=out)
        assert rc == EXIT_OPERATION_ERROR
        assert RUNTIME_SNAPSHOT_ENV_VAR in out.getvalue()

    def test_returns_error_when_file_missing(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv(
            RUNTIME_SNAPSHOT_ENV_VAR, str(tmp_path / "nonexistent.json")
        )
        out = io.StringIO()
        rc = doctor_live(out=out)
        assert rc == EXIT_OPERATION_ERROR
        assert "does not exist" in out.getvalue()

    def test_returns_error_on_invalid_json(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        path = tmp_path / "bad.json"
        path.write_text("not valid json {")
        monkeypatch.setenv(RUNTIME_SNAPSHOT_ENV_VAR, str(path))
        out = io.StringIO()
        rc = doctor_live(out=out)
        assert rc == EXIT_OPERATION_ERROR
        assert "Cannot read" in out.getvalue()

    def test_prints_snapshot_when_valid(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        path = tmp_path / "runtime.json"
        snapshot = {
            "app_name": "myapp",
            "app_version": "1.0.0",
            "log_handler_count": 2,
            "otel_enabled": False,
        }
        path.write_text(json.dumps(snapshot))
        monkeypatch.setenv(RUNTIME_SNAPSHOT_ENV_VAR, str(path))
        out = io.StringIO()
        rc = doctor_live(out=out)
        assert rc == EXIT_SUCCESS
        printed = out.getvalue()
        assert "myapp" in printed
        assert "1.0.0" in printed
        assert "log_handler_count" in printed


# ---------------------------------------------------------------------------
# doctor_redaction — pipe payload through Redactor.
# ---------------------------------------------------------------------------


class TestDoctorRedaction:
    def test_redacts_authorization_header(self) -> None:
        out = io.StringIO()
        payload = json.dumps(
            {"Authorization": "Bearer secret-xyz", "user": "alice"}
        )
        rc = doctor_redaction(out=out, payload_text=payload)
        assert rc == EXIT_SUCCESS
        printed = out.getvalue()
        assert "Before redaction" in printed
        assert "After redaction" in printed
        # Either removed or masked — the standard Redactor handles
        # secret-shaped keys; we don't pin the exact mechanism.
        # Confirm the after-payload differs from the before-payload.
        before_idx = printed.find("Before")
        after_idx = printed.find("After")
        before_section = printed[before_idx:after_idx]
        after_section = printed[after_idx:]
        assert "Bearer secret-xyz" in before_section
        # Secret should NOT appear in the after section.
        assert "Bearer secret-xyz" not in after_section

    def test_no_redaction_warning(self) -> None:
        out = io.StringIO()
        payload = json.dumps({"user": "alice", "color": "blue"})
        rc = doctor_redaction(out=out, payload_text=payload)
        assert rc == EXIT_SUCCESS
        # Warns when nothing was redacted.
        assert "No fields were redacted" in out.getvalue()

    def test_returns_error_on_invalid_json(self) -> None:
        out = io.StringIO()
        rc = doctor_redaction(out=out, payload_text="not json")
        assert rc == EXIT_OPERATION_ERROR
        assert "JSON object" in out.getvalue() or "parse" in out.getvalue()

    def test_returns_error_on_non_object_json(self) -> None:
        out = io.StringIO()
        rc = doctor_redaction(out=out, payload_text='[1, 2, 3]')
        assert rc == EXIT_OPERATION_ERROR
        assert "OBJECT" in out.getvalue()


# ---------------------------------------------------------------------------
# Integration with bootstrap.
# ---------------------------------------------------------------------------


class TestBootstrapWritesSnapshot:
    def test_bootstrap_writes_snapshot_when_env_set(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        target = tmp_path / "runtime.json"
        monkeypatch.setenv(RUNTIME_SNAPSHOT_ENV_VAR, str(target))

        from mgf.common._test_helpers import bootstrap_for_test

        with bootstrap_for_test():
            assert target.exists()
            loaded = json.loads(target.read_text())
            assert loaded["app_name"] == "test-app"
            assert "log_handler_count" in loaded
            assert "redaction_pattern_groups" in loaded

    def test_bootstrap_no_snapshot_when_env_unset(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        monkeypatch.delenv(RUNTIME_SNAPSHOT_ENV_VAR, raising=False)
        target = tmp_path / "runtime.json"

        from mgf.common._test_helpers import bootstrap_for_test

        with bootstrap_for_test():
            # No snapshot at the suggested target.
            assert not target.exists()
