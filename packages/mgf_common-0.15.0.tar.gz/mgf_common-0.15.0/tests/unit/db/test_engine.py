"""Tests for ``mgf.common.db.create_engine``."""

from __future__ import annotations

import pytest
from sqlalchemy.ext.asyncio import AsyncEngine

from mgf.common.db import create_engine


class TestCreateEngine:
    def test_returns_async_engine(self) -> None:
        engine = create_engine("sqlite+aiosqlite:///:memory:")
        assert isinstance(engine, AsyncEngine)

    def test_sqlite_skips_pool_kwargs(self) -> None:
        # SQLite uses StaticPool / NullPool which reject pool_size /
        # max_overflow. The factory should detect SQLite and omit them.
        engine = create_engine(
            "sqlite+aiosqlite:///:memory:",
            pool_size=99,
            max_overflow=99,
        )
        assert isinstance(engine, AsyncEngine)

    def test_echo_passthrough(self) -> None:
        engine = create_engine("sqlite+aiosqlite:///:memory:", echo=True)
        assert engine.echo is True

    def test_extra_kwargs_forwarded(self) -> None:
        engine = create_engine(
            "sqlite+aiosqlite:///:memory:",
            connect_args={"check_same_thread": False},
        )
        assert isinstance(engine, AsyncEngine)


@pytest.mark.asyncio
class TestEngineActuallyConnects:
    async def test_in_memory_sqlite_round_trip(self) -> None:
        from sqlalchemy import text

        engine = create_engine("sqlite+aiosqlite:///:memory:")
        try:
            async with engine.connect() as conn:
                result = await conn.execute(text("SELECT 1 + 1"))
                row = result.scalar_one()
            assert row == 2
        finally:
            await engine.dispose()
