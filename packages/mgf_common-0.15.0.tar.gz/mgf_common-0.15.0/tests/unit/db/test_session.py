"""Tests for ``mgf.common.db._session`` — sessionmaker, get_session, tenant_session."""

from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

import pytest
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from mgf.common.db import (
    create_engine,
    create_sessionmaker,
    get_session,
    setup_db,
    tenant_session,
)
from mgf.common.exceptions import AppConfigError

# ---------------------------------------------------------------------------
# create_sessionmaker
# ---------------------------------------------------------------------------


class TestCreateSessionmaker:
    def test_returns_async_sessionmaker(self) -> None:
        engine = create_engine("sqlite+aiosqlite:///:memory:")
        sm = create_sessionmaker(engine)
        assert isinstance(sm, async_sessionmaker)

    def test_default_expire_on_commit_false(self) -> None:
        engine = create_engine("sqlite+aiosqlite:///:memory:")
        sm = create_sessionmaker(engine)
        # SQLAlchemy 2.x async-recommended default: expire_on_commit=False.
        # Inspect via the kw saved on the sessionmaker.
        assert sm.kw.get("expire_on_commit") is False

    def test_expire_on_commit_can_be_overridden(self) -> None:
        engine = create_engine("sqlite+aiosqlite:///:memory:")
        sm = create_sessionmaker(engine, expire_on_commit=True)
        assert sm.kw.get("expire_on_commit") is True


# ---------------------------------------------------------------------------
# get_session — FastAPI Depends generator
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestGetSessionDepDirect:
    """Direct calls to get_session as an async generator."""

    async def test_yields_session_when_sessionmaker_present(self) -> None:
        engine = create_engine("sqlite+aiosqlite:///:memory:")
        sm = create_sessionmaker(engine)

        # Mock a Request with the right state.
        class _FakeApp:
            class state:  # noqa: N801 — must match FastAPI's request.app.state name
                mgf_db_sessionmaker = sm

        class _FakeRequest:
            app = _FakeApp()

        try:
            gen = get_session(_FakeRequest())  # type: ignore[arg-type]
            session = await gen.__anext__()
            try:
                assert isinstance(session, AsyncSession)
                # Session is usable.
                row = (await session.execute(text("SELECT 1"))).scalar_one()
                assert row == 1
            finally:
                # Close the generator (drains the finally in get_session).
                with pytest.raises(StopAsyncIteration):
                    await gen.__anext__()
        finally:
            await engine.dispose()

    async def test_raises_appconfigerror_when_sessionmaker_missing(self) -> None:
        class _FakeApp:
            class state:  # noqa: N801 — must match FastAPI's request.app.state name
                pass  # no mgf_db_sessionmaker attribute

        class _FakeRequest:
            app = _FakeApp()

        gen = get_session(_FakeRequest())  # type: ignore[arg-type]
        with pytest.raises(AppConfigError, match="setup_db"):
            await gen.__anext__()


class TestGetSessionDepViaFastAPI:
    """get_session integrated end-to-end with FastAPI + setup_db."""

    def test_fastapi_app_with_setup_db(self) -> None:
        from contextlib import asynccontextmanager

        @asynccontextmanager
        async def _lifespan(app: FastAPI):
            async with setup_db(app, database_url="sqlite+aiosqlite:///:memory:"):
                yield

        app = FastAPI(lifespan=_lifespan)

        @app.get("/check")
        async def _check(session: Any = Depends(get_session)) -> dict[str, int]:
            row = (await session.execute(text("SELECT 42"))).scalar_one()
            return {"answer": row}

        with TestClient(app) as client:
            response = client.get("/check")
        assert response.status_code == 200
        assert response.json() == {"answer": 42}


# ---------------------------------------------------------------------------
# tenant_session
# ---------------------------------------------------------------------------


class TestTenantSessionValidation:
    """Pure validation logic — runs without a real DB."""

    @pytest.mark.asyncio
    async def test_rejects_non_uuid_string(self) -> None:
        engine = create_engine("sqlite+aiosqlite:///:memory:")
        sm = create_sessionmaker(engine)
        try:
            async with sm() as session:
                with pytest.raises(ValueError):
                    async with tenant_session(session, "not-a-uuid"):
                        pass
        finally:
            await engine.dispose()

    @pytest.mark.asyncio
    async def test_accepts_uuid_object(self) -> None:
        # SQLite doesn't support GUC settings, so the SET LOCAL will
        # error at the DB layer. We're testing that VALIDATION passes
        # (no ValueError) — the SQL execution can fail, that's fine.
        engine = create_engine("sqlite+aiosqlite:///:memory:")
        sm = create_sessionmaker(engine)
        tid = uuid4()
        try:
            async with sm() as session:
                # Expect the SET to fail on SQLite (unknown function /
                # syntax). We just verify the call doesn't fail at
                # the validation step.
                with pytest.raises(Exception) as excinfo:
                    async with tenant_session(session, tid):
                        pass
                # The error is from SQLAlchemy / SQLite, NOT a ValueError.
                assert not isinstance(excinfo.value, ValueError)
        finally:
            await engine.dispose()

    @pytest.mark.asyncio
    async def test_accepts_uuid_string(self) -> None:
        engine = create_engine("sqlite+aiosqlite:///:memory:")
        sm = create_sessionmaker(engine)
        try:
            async with sm() as session:
                with pytest.raises(Exception) as excinfo:
                    async with tenant_session(
                        session,
                        "550e8400-e29b-41d4-a716-446655440000",
                    ):
                        pass
                # Validation passed; only DB-layer error remains.
                assert not isinstance(excinfo.value, ValueError)
        finally:
            await engine.dispose()


class TestTenantSessionSqlShape:
    """Pin the exact SQL emitted by tenant_session.

    Captures the fact that we use SET LOCAL with literal interpolation
    (Postgres' SET doesn't accept bind params). Critical that the
    UUID validation runs first.
    """

    @pytest.mark.asyncio
    async def test_emits_set_local_app_current_tenant(self) -> None:
        from unittest.mock import AsyncMock, MagicMock

        # Mock the session to capture executed SQL.
        mock_session = MagicMock(spec=AsyncSession)
        mock_session.execute = AsyncMock()
        tid = UUID("550e8400-e29b-41d4-a716-446655440000")

        async with tenant_session(mock_session, tid):
            pass

        # Captured exactly one execute() call.
        assert mock_session.execute.call_count == 1
        call_args = mock_session.execute.call_args
        sql_clause = call_args.args[0]
        # The SQL clause is a TextClause; render to string for inspection.
        rendered = str(sql_clause)
        assert "SET LOCAL" in rendered
        assert "app.current_tenant" in rendered
        assert "550e8400-e29b-41d4-a716-446655440000" in rendered

    @pytest.mark.asyncio
    async def test_uuid_object_rendered_as_canonical_form(self) -> None:
        from unittest.mock import AsyncMock, MagicMock

        mock_session = MagicMock(spec=AsyncSession)
        mock_session.execute = AsyncMock()
        # UUID with mixed case input — should render lowercase canonical.
        tid_str = "550E8400-E29B-41D4-A716-446655440000"

        async with tenant_session(mock_session, tid_str):
            pass

        rendered = str(mock_session.execute.call_args.args[0])
        # UUID() canonicalises to lowercase.
        assert "550e8400-e29b-41d4-a716-446655440000" in rendered
        assert "550E8400" not in rendered
