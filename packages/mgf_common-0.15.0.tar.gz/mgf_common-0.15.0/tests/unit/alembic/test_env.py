"""Tests for ``mgf.common.alembic.configure_env``.

Strategy: build a minimal alembic project in a tmp dir + run
``alembic.command.upgrade(config, "head")`` via the public alembic
API (no subprocess). The env.py imports configure_env, which is the
load-bearing path under test.

Two driver shapes covered:

  - Sync (``sqlite:///``): smoke + round-trip.
  - Async (``sqlite+aiosqlite://``): smoke + round-trip.
"""

from __future__ import annotations

import textwrap
from typing import TYPE_CHECKING

import pytest
from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, text

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Test alembic project scaffolding.
# ---------------------------------------------------------------------------


_ENV_PY_TEMPLATE = textwrap.dedent(
    """
    from mgf.common.alembic import configure_env
    from sqlalchemy import Column, Integer, MetaData, String, Table

    metadata = MetaData()
    Table(
        "users",
        metadata,
        Column("id", Integer, primary_key=True),
        Column("name", String(64), nullable=False),
    )

    configure_env(
        database_url={url!r},
        target_metadata=metadata,
    )
    """
).strip()


_INITIAL_MIGRATION_TEMPLATE = textwrap.dedent(
    '''
    """initial — create users table

    Revision ID: 0001
    Revises:
    Create Date: 2026-04-29 00:00:00

    """
    from alembic import op
    import sqlalchemy as sa

    revision = "0001"
    down_revision = None
    branch_labels = None
    depends_on = None


    def upgrade() -> None:
        op.create_table(
            "users",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("name", sa.String(64), nullable=False),
        )


    def downgrade() -> None:
        op.drop_table("users")
    '''
).strip()


_ALEMBIC_INI_TEMPLATE = textwrap.dedent(
    """
    [alembic]
    script_location = {script_location}
    sqlalchemy.url = {url}

    [loggers]
    keys = root

    [handlers]
    keys = console

    [formatters]
    keys = generic

    [logger_root]
    level = WARN
    handlers = console
    qualname =

    [handler_console]
    class = StreamHandler
    args = (sys.stderr,)
    level = NOTSET
    formatter = generic

    [formatter_generic]
    format = %(levelname)-5.5s [%(name)s] %(message)s
    """
).strip()


def _build_project(tmp_path: Path, *, url: str) -> Config:
    """Lay out a minimal alembic project in ``tmp_path``; return Config."""
    project_root = tmp_path / "alembic_test"
    project_root.mkdir()

    versions = project_root / "versions"
    versions.mkdir()

    (project_root / "env.py").write_text(_ENV_PY_TEMPLATE.format(url=url))
    (project_root / "script.py.mako").write_text(
        '"""${message}"""\n'
        'from alembic import op\n'
        'import sqlalchemy as sa\n'
        'revision = ${repr(up_revision)}\n'
        'down_revision = ${repr(down_revision)}\n'
        'branch_labels = ${repr(branch_labels)}\n'
        'depends_on = ${repr(depends_on)}\n'
        '\n'
        'def upgrade() -> None:\n'
        '    ${upgrades if upgrades else "pass"}\n'
        '\n'
        'def downgrade() -> None:\n'
        '    ${downgrades if downgrades else "pass"}\n'
    )
    (versions / "0001_initial.py").write_text(_INITIAL_MIGRATION_TEMPLATE)

    ini_path = tmp_path / "alembic.ini"
    ini_path.write_text(
        _ALEMBIC_INI_TEMPLATE.format(
            script_location=str(project_root),
            url=url,
        )
    )

    return Config(str(ini_path))


# ---------------------------------------------------------------------------
# Sync driver round-trip.
# ---------------------------------------------------------------------------


class TestSyncDriver:
    def test_upgrade_creates_users_table(self, tmp_path: Path) -> None:
        db_path = tmp_path / "test.db"
        url = f"sqlite:///{db_path}"
        config = _build_project(tmp_path, url=url)

        # Run the migration.
        command.upgrade(config, "head")

        # Verify the table exists.
        engine = create_engine(url)
        try:
            with engine.connect() as conn:
                result = conn.execute(
                    text("SELECT name FROM sqlite_master WHERE type='table'")
                )
                tables = {row[0] for row in result}
        finally:
            engine.dispose()

        assert "users" in tables
        assert "alembic_version" in tables  # Tracked migrations.

    def test_downgrade_drops_users_table(self, tmp_path: Path) -> None:
        db_path = tmp_path / "test.db"
        url = f"sqlite:///{db_path}"
        config = _build_project(tmp_path, url=url)

        command.upgrade(config, "head")
        command.downgrade(config, "base")

        engine = create_engine(url)
        try:
            with engine.connect() as conn:
                result = conn.execute(
                    text("SELECT name FROM sqlite_master WHERE type='table'")
                )
                tables = {row[0] for row in result}
        finally:
            engine.dispose()

        # users table is gone; alembic_version stays.
        assert "users" not in tables


# ---------------------------------------------------------------------------
# Async driver round-trip.
# ---------------------------------------------------------------------------


# aiosqlite's worker thread + the asyncio event loop our helper
# spins up live past the asyncio.run() return; finalizers fire during
# the next test's GC pass and surface as PytestUnraisableExceptionWarning.
# Force a GC sweep at end-of-test (within this filter scope) so the
# finalizer warnings are absorbed here rather than leaking to siblings.
@pytest.mark.filterwarnings("ignore::pytest.PytestUnraisableExceptionWarning")
class TestAsyncDriver:
    def test_async_upgrade_creates_users_table(self, tmp_path: Path) -> None:
        import gc

        db_path = tmp_path / "test.db"
        url = f"sqlite+aiosqlite:///{db_path}"
        config = _build_project(tmp_path, url=url)

        # Run the migration (configure_env detects the async URL +
        # uses asyncio.run internally).
        command.upgrade(config, "head")

        # Verify via a sync sqlite reader (the file is the same).
        engine = create_engine(f"sqlite:///{db_path}")
        try:
            with engine.connect() as conn:
                result = conn.execute(
                    text("SELECT name FROM sqlite_master WHERE type='table'")
                )
                tables = {row[0] for row in result}
        finally:
            engine.dispose()

        assert "users" in tables

        # Sweep aiosqlite/loop finalizers within this test's filter
        # scope so they don't surface in unrelated downstream tests.
        gc.collect()


# ---------------------------------------------------------------------------
# Offline mode (SQL-emit-only).
# ---------------------------------------------------------------------------


class TestOfflineMode:
    def test_offline_emits_sql(self, tmp_path: Path, capsys) -> None:
        url = "sqlite:///./not-used.db"  # offline doesn't connect
        config = _build_project(tmp_path, url=url)

        # alembic.command.upgrade with sql=True is offline mode.
        command.upgrade(config, "head", sql=True)

        captured = capsys.readouterr()
        # The output should contain the CREATE TABLE statement.
        assert "CREATE TABLE users" in captured.out
        assert "alembic_version" in captured.out


# ---------------------------------------------------------------------------
# Naming convention application.
# ---------------------------------------------------------------------------


_ENV_PY_WITH_NAMING = textwrap.dedent(
    """
    from mgf.common.alembic import configure_env
    from sqlalchemy import Column, Integer, MetaData, String, Table, UniqueConstraint

    metadata = MetaData()
    Table(
        "users",
        metadata,
        Column("id", Integer, primary_key=True),
        Column("email", String(64), nullable=False),
        UniqueConstraint("email"),
    )

    configure_env(
        database_url={url!r},
        target_metadata=metadata,
        naming_convention={{
            "ix": "ix_%(column_0_label)s",
            "uq": "uq_%(table_name)s_%(column_0_name)s",
            "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
            "pk": "pk_%(table_name)s",
        }},
    )
    """
).strip()


class TestNamingConvention:
    def test_naming_convention_applied(self, tmp_path: Path) -> None:
        # Build a project that uses naming_convention.
        url = f"sqlite:///{tmp_path / 'test.db'}"
        project_root = tmp_path / "alembic_test"
        project_root.mkdir()
        (project_root / "versions").mkdir()
        (project_root / "env.py").write_text(_ENV_PY_WITH_NAMING.format(url=url))
        (project_root / "script.py.mako").write_text(
            '"""${message}"""\n'
            'from alembic import op\n'
            'import sqlalchemy as sa\n'
            'revision = ${repr(up_revision)}\n'
            'down_revision = ${repr(down_revision)}\n'
            'branch_labels = ${repr(branch_labels)}\n'
            'depends_on = ${repr(depends_on)}\n'
            '\n'
            'def upgrade() -> None:\n'
            '    ${upgrades if upgrades else "pass"}\n'
            '\n'
            'def downgrade() -> None:\n'
            '    ${downgrades if downgrades else "pass"}\n'
        )
        ini_path = tmp_path / "alembic.ini"
        ini_path.write_text(
            _ALEMBIC_INI_TEMPLATE.format(
                script_location=str(project_root),
                url=url,
            )
        )

        # Smoke: just verify configure_env runs without error when
        # naming_convention is supplied. Full propagation testing
        # requires an autogenerate run, which is more elaborate.
        config = Config(str(ini_path))
        # No migration files yet — but configure_env still runs.
        command.upgrade(config, "head")  # no-op since versions/ is empty


# ---------------------------------------------------------------------------
# URL prefix detection.
# ---------------------------------------------------------------------------


class TestAsyncUrlDetection:
    @pytest.mark.parametrize(
        "url",
        [
            "postgresql+asyncpg://user:pass@host/db",
            "mysql+aiomysql://user:pass@host/db",
            "sqlite+aiosqlite:///path",
            "postgresql+psycopg://user:pass@host/db",
            "mysql+asyncmy://user:pass@host/db",
        ],
    )
    def test_known_async_prefixes(self, url: str) -> None:
        from mgf.common.alembic._env import _ASYNC_URL_PREFIXES

        assert any(url.startswith(prefix) for prefix in _ASYNC_URL_PREFIXES)

    @pytest.mark.parametrize(
        "url",
        [
            "postgresql://user:pass@host/db",
            "postgresql+psycopg2://user:pass@host/db",
            "mysql+pymysql://user:pass@host/db",
            "sqlite:///path",
        ],
    )
    def test_known_sync_prefixes_not_in_async_list(self, url: str) -> None:
        from mgf.common.alembic._env import _ASYNC_URL_PREFIXES

        assert not any(url.startswith(prefix) for prefix in _ASYNC_URL_PREFIXES)
