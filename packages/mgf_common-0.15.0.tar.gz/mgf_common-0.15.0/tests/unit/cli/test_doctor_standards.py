"""Tests for ``mgf-common doctor --standards``.

Builds a tiny project tree per test (pyproject.toml + src/<pkg>/)
under ``tmp_path``, then runs each check against it. Avoids
shelling out via the CLI — exercises the audit functions directly
so failures point at the right line.

Covers:
  - Project shape discovery (flat + namespace layouts).
  - AP-09 py.typed marker presence / absence.
  - AP-13 __version__ ↔ pyproject sync (match / mismatch /
    missing).
  - TS-04 filterwarnings escalation (configured / missing /
    not-error-first).
  - DP-12 naive datetime detection.
  - End-to-end ``doctor_standards()`` exit code.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from mgf.common.cli._doctor_standards import (
    _check_filterwarnings,
    _check_naive_datetime,
    _check_py_typed_marker,
    _check_version_sync,
    _discover_project,
    doctor_standards,
)

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path

    import pytest


def _write_project(
    root: Path,
    *,
    package_name: str = "myapp",
    declared_version: str = "1.0.0",
    runtime_version: str | None = "1.0.0",
    py_typed: bool = True,
    filterwarnings: list[str] | None = ("error",),
    extra_pyproject: Mapping[str, object] | None = None,
    package_files: Mapping[str, str] | None = None,
) -> Path:
    """Build a minimal project tree at ``root``; return ``root``."""
    underscore = package_name.replace("-", "_")
    (root / "src" / underscore).mkdir(parents=True, exist_ok=True)
    if py_typed:
        (root / "src" / underscore / "py.typed").touch()
    init = root / "src" / underscore / "__init__.py"
    if runtime_version is not None:
        init.write_text(f'__version__ = "{runtime_version}"\n')
    else:
        init.write_text("")
    for rel, content in (package_files or {}).items():
        (root / "src" / underscore / rel).write_text(content)

    pyproject_text = f'[project]\nname = "{package_name}"\n'
    if declared_version:
        pyproject_text += f'version = "{declared_version}"\n'
    if filterwarnings is not None:
        # Render as a TOML array literal.
        items = ", ".join(f'"{f}"' for f in filterwarnings)
        pyproject_text += (
            f"\n[tool.pytest.ini_options]\n"
            f"filterwarnings = [{items}]\n"
        )
    (root / "pyproject.toml").write_text(pyproject_text)
    return root


# ---------------------------------------------------------------------------
# Project shape discovery
# ---------------------------------------------------------------------------


class TestProjectDiscovery:
    def test_flat_layout(self, tmp_path: Path) -> None:
        _write_project(tmp_path, package_name="myapp")
        shape = _discover_project(tmp_path)
        assert shape is not None
        assert shape.package_name == "myapp"
        assert shape.package_root.name == "myapp"

    def test_namespace_layout(self, tmp_path: Path) -> None:
        # Distribution name "mgf-common" → import path "mgf/common".
        (tmp_path / "src" / "mgf" / "common").mkdir(parents=True)
        (tmp_path / "src" / "mgf" / "common" / "__init__.py").write_text(
            '__version__ = "0.1.0"\n',
        )
        (tmp_path / "src" / "mgf" / "common" / "py.typed").touch()
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "mgf-common"\nversion = "0.1.0"\n',
        )
        shape = _discover_project(tmp_path)
        assert shape is not None
        assert shape.package_name == "mgf-common"
        assert shape.package_root == tmp_path / "src" / "mgf" / "common"

    def test_no_pyproject_returns_none(self, tmp_path: Path) -> None:
        # Empty dir.
        assert _discover_project(tmp_path) is None

    def test_no_src_dir_returns_none(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\n',
        )
        assert _discover_project(tmp_path) is None


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------


class TestPyTypedCheck:
    def test_present(self, tmp_path: Path) -> None:
        _write_project(tmp_path, py_typed=True)
        shape = _discover_project(tmp_path)
        assert shape is not None
        assert _check_py_typed_marker(shape).tier == "ok"

    def test_missing(self, tmp_path: Path) -> None:
        _write_project(tmp_path, py_typed=False)
        shape = _discover_project(tmp_path)
        assert shape is not None
        finding = _check_py_typed_marker(shape)
        assert finding.tier == "fail"
        assert "py.typed" in finding.message


class TestVersionSyncCheck:
    def test_match(self, tmp_path: Path) -> None:
        _write_project(
            tmp_path, declared_version="1.2.3", runtime_version="1.2.3",
        )
        shape = _discover_project(tmp_path)
        assert shape is not None
        assert _check_version_sync(shape).tier == "ok"

    def test_mismatch(self, tmp_path: Path) -> None:
        _write_project(
            tmp_path, declared_version="1.2.3", runtime_version="9.9.9",
        )
        shape = _discover_project(tmp_path)
        assert shape is not None
        finding = _check_version_sync(shape)
        assert finding.tier == "fail"
        assert "1.2.3" in finding.message
        assert "9.9.9" in finding.message

    def test_missing_runtime_version(self, tmp_path: Path) -> None:
        _write_project(
            tmp_path, declared_version="1.2.3", runtime_version=None,
        )
        shape = _discover_project(tmp_path)
        assert shape is not None
        finding = _check_version_sync(shape)
        assert finding.tier == "warn"

    def test_missing_declared_version(self, tmp_path: Path) -> None:
        _write_project(
            tmp_path, declared_version="", runtime_version="1.0.0",
        )
        shape = _discover_project(tmp_path)
        assert shape is not None
        finding = _check_version_sync(shape)
        assert finding.tier == "warn"


class TestFilterwarningsCheck:
    def test_configured_with_error(self, tmp_path: Path) -> None:
        _write_project(tmp_path, filterwarnings=["error"])
        shape = _discover_project(tmp_path)
        assert shape is not None
        assert _check_filterwarnings(shape).tier == "ok"

    def test_missing(self, tmp_path: Path) -> None:
        _write_project(tmp_path, filterwarnings=None)
        shape = _discover_project(tmp_path)
        assert shape is not None
        finding = _check_filterwarnings(shape)
        assert finding.tier == "fail"

    def test_no_error_entry(self, tmp_path: Path) -> None:
        _write_project(
            tmp_path, filterwarnings=["ignore::DeprecationWarning"],
        )
        shape = _discover_project(tmp_path)
        assert shape is not None
        finding = _check_filterwarnings(shape)
        assert finding.tier == "fail"
        assert "error" in finding.message


class TestNaiveDatetimeCheck:
    def test_no_violations(self, tmp_path: Path) -> None:
        _write_project(
            tmp_path,
            package_files={
                "module.py": (
                    "from datetime import UTC, datetime\n"
                    "x = datetime.now(UTC)\n"
                ),
            },
        )
        shape = _discover_project(tmp_path)
        assert shape is not None
        assert _check_naive_datetime(shape).tier == "ok"

    def test_utcnow_flagged(self, tmp_path: Path) -> None:
        _write_project(
            tmp_path,
            package_files={
                "module.py": (
                    "from datetime import datetime\n"
                    "x = datetime.utcnow()\n"
                ),
            },
        )
        shape = _discover_project(tmp_path)
        assert shape is not None
        finding = _check_naive_datetime(shape)
        assert finding.tier == "fail"
        assert "utcnow" in finding.message

    def test_naive_now_flagged(self, tmp_path: Path) -> None:
        _write_project(
            tmp_path,
            package_files={
                "module.py": (
                    "from datetime import datetime\n"
                    "x = datetime.now()\n"
                ),
            },
        )
        shape = _discover_project(tmp_path)
        assert shape is not None
        finding = _check_naive_datetime(shape)
        assert finding.tier == "fail"

    def test_now_with_tz_kwarg_passes(self, tmp_path: Path) -> None:
        _write_project(
            tmp_path,
            package_files={
                "module.py": (
                    "from datetime import UTC, datetime\n"
                    "x = datetime.now(tz=UTC)\n"
                ),
            },
        )
        shape = _discover_project(tmp_path)
        assert shape is not None
        # Currently, we accept positional too; the AST check looks
        # for either kwarg `tz=...` OR positional args.
        assert _check_naive_datetime(shape).tier == "ok"


# ---------------------------------------------------------------------------
# End-to-end exit code
# ---------------------------------------------------------------------------


class TestDoctorStandardsExitCode:
    def test_clean_project_exits_zero(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str],
    ) -> None:
        _write_project(tmp_path)
        rc = doctor_standards(root=tmp_path)
        assert rc == 0

    def test_failing_project_exits_nonzero(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str],
    ) -> None:
        _write_project(tmp_path, py_typed=False)  # AP-09 will FAIL
        rc = doctor_standards(root=tmp_path)
        assert rc != 0

    def test_no_project_exits_nonzero(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str],
    ) -> None:
        rc = doctor_standards(root=tmp_path)
        assert rc != 0
