"""Tests for ``mgf-common bench`` subcommand."""

from __future__ import annotations

import argparse
import io
import json
from contextlib import redirect_stdout

import pytest

from mgf.common.cli._bench import add_bench_args, run_bench


@pytest.fixture(autouse=True)
def _reset_bootstrap_state() -> None:
    """Tear down any AppContext bench leaves on the process-global.

    The bench runs real bootstrap() calls which set
    ``mgf.common._lifecycle._GLOBAL_CONTEXT``; without explicit
    cleanup, sibling tests (config, django, lifecycle) inherit the
    leftover bench-app context and break.
    """
    import mgf.common._lifecycle as lc

    yield
    if lc._GLOBAL_CONTEXT is not None:
        lc._GLOBAL_CONTEXT.shutdown()
        lc._GLOBAL_CONTEXT = None


def _make_args(*, quick: bool = True, json_out: bool = False) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    add_bench_args(parser)
    return parser.parse_args(
        ["--quick"] * quick + ["--json"] * json_out,
    )


class TestBenchHumanOutput:
    def test_runs_and_returns_zero(self) -> None:
        # Capture stdout so the test runner output isn't polluted.
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            exit_code = run_bench(_make_args(quick=True))
        assert exit_code == 0

    def test_human_output_contains_expected_rows(self) -> None:
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            run_bench(_make_args(quick=True))
        output = buffer.getvalue()

        # All seven measurements must appear.
        assert "current_context()" in output
        assert "bootstrap (cold)" in output
        assert "bootstrap (warm)" in output
        assert "operation_span open+close" in output
        assert "log call (sync, JSON)" in output
        assert "log call (async, JSON)" in output
        assert "redaction pass" in output

    def test_human_output_includes_walltime(self) -> None:
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            run_bench(_make_args(quick=True))
        assert "total walltime:" in buffer.getvalue()


class TestBenchJsonOutput:
    def test_json_output_is_valid(self) -> None:
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            run_bench(_make_args(quick=True, json_out=True))
        payload = json.loads(buffer.getvalue())

        assert "version" in payload
        assert "walltime_s" in payload
        assert "rows" in payload
        assert len(payload["rows"]) == 7

    def test_json_rows_have_expected_shape(self) -> None:
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            run_bench(_make_args(quick=True, json_out=True))
        payload = json.loads(buffer.getvalue())

        for row in payload["rows"]:
            assert "name" in row
            assert "ns_per_call" in row
            assert "iterations" in row
            assert isinstance(row["ns_per_call"], (int, float))
            assert row["ns_per_call"] > 0
            assert row["iterations"] >= 1


class TestBenchPerformanceContract:
    def test_quick_mode_runs_under_two_seconds(self) -> None:
        # Per the strategic plan: full bench < 5s. Quick is a fraction
        # of that — ~1-2s on common hardware. We test 2s as the upper
        # bound (CI shared runners can be slow).
        import time

        buffer = io.StringIO()
        start = time.perf_counter()
        with redirect_stdout(buffer):
            run_bench(_make_args(quick=True))
        elapsed = time.perf_counter() - start
        assert elapsed < 2.0, f"quick bench took {elapsed:.2f}s — too slow"
