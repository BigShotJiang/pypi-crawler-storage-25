"""Tests for ``mgf-common catch-up`` subcommand."""

from __future__ import annotations

import argparse
import io
import json
from contextlib import redirect_stdout
from typing import TYPE_CHECKING

import pytest

from mgf.common.cli._catch_up import (
    _apply_bump_pin,
    _check_claude_md,
    _check_claude_settings,
    _check_four_gates,
    _check_pyproject_pin,
    _check_v01_patterns,
    _extract_auto_block,
    _pin_is_stale,
    _splice_auto_block,
    add_catch_up_args,
    run_catch_up,
)
from mgf.common.cli._init_project import (
    CLAUDE_MD_BEGIN_MARKER,
    CLAUDE_MD_END_MARKER,
    _render_claude_md,
)

if TYPE_CHECKING:
    from pathlib import Path


def _make_args(
    path: Path,
    *,
    apply: bool = False,
    name: str | None = None,
    kind: str | None = None,
) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    add_catch_up_args(parser)
    argv = ["--path", str(path)]
    if apply:
        argv.append("--apply")
    if name is not None:
        argv.extend(["--name", name])
    if kind is not None:
        argv.extend(["--kind", kind])
    return parser.parse_args(argv)


def _seed_minimal_project(target: Path, *, with_pyproject: bool = True) -> None:
    """Create a minimal project layout."""
    if with_pyproject:
        (target / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\n'
            'dependencies = ["mgf-common>=0.5.0,<0.6"]\n',
            encoding="utf-8",
        )


# ---------------------------------------------------------------------------
# Auto-block extraction + splicing.
# ---------------------------------------------------------------------------


class TestAutoBlockExtraction:
    def test_extract_returns_content_between_markers(self) -> None:
        rendered = _render_claude_md("demo", "cli")
        block = _extract_auto_block(rendered)
        # Block must be non-empty and contain the standing-instructions
        # heading + the rule index.
        assert "Standing instructions" in block
        assert "DP-01" in block
        # Markers themselves should NOT be inside the extracted block.
        assert CLAUDE_MD_BEGIN_MARKER not in block
        assert CLAUDE_MD_END_MARKER not in block

    def test_extract_empty_when_markers_missing(self) -> None:
        assert _extract_auto_block("# No markers here\nJust content") == ""

    def test_splice_replaces_block_in_place(self) -> None:
        rendered = _render_claude_md("demo", "cli")
        new_block = "\nNEW BLOCK CONTENT\n"
        spliced = _splice_auto_block(rendered, new_block)
        # Markers preserved.
        assert CLAUDE_MD_BEGIN_MARKER in spliced
        assert CLAUDE_MD_END_MARKER in spliced
        # New content appears between them.
        assert "NEW BLOCK CONTENT" in spliced
        # Old content (rules, etc.) gone.
        assert "DP-01" not in spliced

    def test_splice_preserves_text_around_markers(self) -> None:
        before = "# Project Title\n\nProject-specific stuff above.\n\n"
        original = (
            before
            + CLAUDE_MD_BEGIN_MARKER + "\n"
            + "OLD CONTENT\n"
            + CLAUDE_MD_END_MARKER + " -->\n"
            + "## Project-specific lookup\n\nTeam content.\n"
        )
        spliced = _splice_auto_block(original, "\nNEW\n")
        assert "Project-specific stuff above." in spliced
        assert "Team content." in spliced
        assert "OLD CONTENT" not in spliced
        assert "\nNEW\n" in spliced


# ---------------------------------------------------------------------------
# Individual audit checks.
# ---------------------------------------------------------------------------


class TestPinCheck:
    def test_no_pyproject_warns(self, tmp_path: Path) -> None:
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "warn"
        assert "no pyproject.toml" in finding.detail.lower()

    def test_current_pin_returns_ok(self, tmp_path: Path) -> None:
        # v0.12.0+: the seed uses ``>=0.5.0,<0.6`` which IS stale
        # against today's running mgf-common (>=0.11) — so we
        # need a pin that's actually current. Use the running
        # version's window.
        from mgf.common import __version__ as current

        major, minor = current.split(".")[:2]
        upper_minor = int(minor) + 1
        (tmp_path / "pyproject.toml").write_text(
            f'[project]\nname = "demo"\ndependencies = '
            f'["mgf-common>={current},<{major}.{upper_minor}"]\n',
            encoding="utf-8",
        )
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "ok"
        assert finding.fix is None

    def test_stale_pin_warns_with_fix(self, tmp_path: Path) -> None:
        # The pin <0.2 cannot accommodate the running 0.11.x. Stale.
        _seed_minimal_project(tmp_path)
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "warn"
        assert "STALE" in finding.detail
        assert finding.fix is not None  # has a mechanical fix

    def test_no_mgf_dep_warns(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "x"\ndependencies = []\n',
            encoding="utf-8",
        )
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "warn"


class TestPinStaleness:
    """``_pin_is_stale`` core staleness detection."""

    def test_pin_with_no_upper_bound_not_flagged(self) -> None:
        # A pin like `>=0.5.0` (no upper bound) should NOT be flagged
        # as stale — we don't know the user's intent.
        assert _pin_is_stale(">=0.5.0", "0.11.3") is False

    def test_pin_excluding_current_is_stale(self) -> None:
        assert _pin_is_stale(">=0.1.0,<0.2", "0.11.3") is True
        assert _pin_is_stale(">=0.6.0,<0.8", "0.11.3") is True
        assert _pin_is_stale(">=0.10.0,<0.11", "0.11.0") is True

    def test_pin_including_current_not_stale(self) -> None:
        assert _pin_is_stale(">=0.11.0,<0.13", "0.11.3") is False
        assert _pin_is_stale(">=0.5.0,<1.0", "0.11.3") is False

    def test_pin_at_exact_upper_bound_is_stale(self) -> None:
        # `<0.11` excludes 0.11.0 (strict-less-than).
        assert _pin_is_stale(">=0.10.0,<0.11", "0.11.0") is True

    def test_unparseable_constraint_not_flagged(self) -> None:
        # Non-numeric, weird shape, etc. — better to under-flag.
        assert _pin_is_stale("== latest", "0.11.3") is False
        assert _pin_is_stale("garbage", "0.11.3") is False


class TestApplyBumpPin:
    """``_apply_bump_pin`` rewrites the pin line conservatively."""

    def test_simple_pin_rewrite(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "x"\n'
            'dependencies = [\n    "mgf-common>=0.1.0,<0.2",\n]\n',
            encoding="utf-8",
        )
        result = _apply_bump_pin(
            tmp_path,
            extras_part="mgf-common",
            old_constraint=">=0.1.0,<0.2",
            new_constraint=">=0.11.0,<0.13",
        )
        content = (tmp_path / "pyproject.toml").read_text()
        assert "mgf-common>=0.11.0,<0.13" in content
        assert "mgf-common>=0.1.0,<0.2" not in content
        assert "bumped pin" in result

    def test_extras_in_pin_preserved(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "x"\n'
            'dependencies = ["mgf-common[fastapi]>=0.6.0,<0.8"]\n',
            encoding="utf-8",
        )
        _apply_bump_pin(
            tmp_path,
            extras_part="mgf-common[fastapi]",
            old_constraint=">=0.6.0,<0.8",
            new_constraint=">=0.11.0,<0.13",
        )
        content = (tmp_path / "pyproject.toml").read_text()
        assert "mgf-common[fastapi]>=0.11.0,<0.13" in content
        assert "[fastapi]" in content  # extras preserved

    def test_backup_file_written(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "x"\ndependencies = ["mgf-common>=0.1,<0.2"]\n',
            encoding="utf-8",
        )
        _apply_bump_pin(
            tmp_path,
            extras_part="mgf-common",
            old_constraint=">=0.1,<0.2",
            new_constraint=">=0.11.0,<0.13",
        )
        backups = list(tmp_path.glob("pyproject.toml.bak.*"))
        assert len(backups) == 1
        # Backup contains the original.
        assert ">=0.1,<0.2" in backups[0].read_text()
        # Live file has the new pin.
        assert ">=0.11.0,<0.13" in (tmp_path / "pyproject.toml").read_text()

    def test_other_lines_untouched(self, tmp_path: Path) -> None:
        # Conservative: only the mgf-common line changes; everything
        # else stays byte-for-byte.
        (tmp_path / "pyproject.toml").write_text(
            "[project]\n"
            'name = "x"\n'
            'dependencies = [\n'
            '    "click>=8.1",\n'
            '    "pyyaml>=6.0",\n'
            '    "mgf-common>=0.1.0,<0.2",\n'
            '    "rich>=13.7",\n'
            "]\n"
            "[tool.ruff]\n"
            "line-length = 100\n",
            encoding="utf-8",
        )
        _apply_bump_pin(
            tmp_path,
            extras_part="mgf-common",
            old_constraint=">=0.1.0,<0.2",
            new_constraint=">=0.11.0,<0.13",
        )
        content = (tmp_path / "pyproject.toml").read_text()
        # Other deps untouched.
        assert '"click>=8.1"' in content
        assert '"pyyaml>=6.0"' in content
        assert '"rich>=13.7"' in content
        # Ruff section untouched.
        assert "[tool.ruff]" in content
        assert "line-length = 100" in content
        # mgf-common line bumped.
        assert "mgf-common>=0.11.0,<0.13" in content

    def test_pin_line_with_comments_around_preserved(self, tmp_path: Path) -> None:
        # VManager-shape: the dep line is surrounded by a long comment.
        # Both the comment and adjacent context must survive.
        (tmp_path / "pyproject.toml").write_text(
            "[project]\n"
            'name = "vmanager"\n'
            "dependencies = [\n"
            "    # Comment above explaining the dep.\n"
            "    # Multiple lines of context.\n"
            '    "mgf-common>=0.1.0,<0.2",\n'
            "    # Comment below.\n"
            "]\n",
            encoding="utf-8",
        )
        _apply_bump_pin(
            tmp_path,
            extras_part="mgf-common",
            old_constraint=">=0.1.0,<0.2",
            new_constraint=">=0.11.0,<0.13",
        )
        content = (tmp_path / "pyproject.toml").read_text()
        assert "Comment above" in content
        assert "Multiple lines of context." in content
        assert "Comment below" in content
        assert "mgf-common>=0.11.0,<0.13" in content


class TestEndToEndPinBump:
    """Verify catch-up's apply path bumps the pin with a real audit run."""

    def test_apply_bumps_stale_pin(self, tmp_path: Path) -> None:
        _seed_minimal_project(tmp_path)  # pin = >=0.5.0,<0.6 (stale vs 0.11.x)
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))
        # Pin in pyproject.toml is now bumped to a current 2-minor window.
        content = (tmp_path / "pyproject.toml").read_text()
        assert ">=0.5.0,<0.6" not in content
        # New constraint contains current major + minor.
        from mgf.common import __version__ as current

        assert f">={current}" in content


class TestFourGatesCheck:
    def test_no_pyproject_warns(self, tmp_path: Path) -> None:
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "warn"

    def test_partial_config_lists_missing(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            "[project]\nname = 'x'\n[tool.ruff]\nline-length = 100\n",
            encoding="utf-8",
        )
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "warn"
        # ruff present, others not.
        assert "[tool.mypy]" in finding.detail
        assert "filterwarnings" in finding.detail

    def test_full_config_returns_ok(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            "[project]\nname = 'x'\n"
            "[tool.ruff]\n\n"
            "[tool.mypy]\nstrict = true\n\n"
            '[tool.pytest.ini_options]\nfilterwarnings = ["error"]\n\n'
            "[tool.coverage.report]\nfail_under = 80\n",
            encoding="utf-8",
        )
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "ok"

    def test_multiline_filterwarnings_array_returns_ok(self, tmp_path: Path) -> None:
        # v0.11.2 fix: parse with tomllib so the multi-line array form
        # (which apiprobe + many real projects use) is recognized.
        # The pre-fix substring-match required the exact single-line
        # `filterwarnings = ["error"]` form and gave a false positive
        # warning on multi-line.
        (tmp_path / "pyproject.toml").write_text(
            "[project]\nname = 'x'\n"
            "[tool.ruff]\n\n"
            "[tool.mypy]\nstrict = true\n\n"
            "[tool.pytest.ini_options]\n"
            "filterwarnings = [\n"
            '    "error",\n'
            '    "ignore::DeprecationWarning:third_party.*",\n'
            "]\n\n"
            "[tool.coverage.report]\nfail_under = 80\n",
            encoding="utf-8",
        )
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "ok", (
            f"multi-line filterwarnings array should pass, got "
            f"{finding.severity}: {finding.detail}"
        )

    def test_filterwarnings_without_error_string_warns(self, tmp_path: Path) -> None:
        # If filterwarnings is configured but doesn't contain "error",
        # the gate should fail (TS-04 requires error-level).
        (tmp_path / "pyproject.toml").write_text(
            "[project]\nname = 'x'\n"
            "[tool.ruff]\n\n"
            "[tool.mypy]\nstrict = true\n\n"
            '[tool.pytest.ini_options]\nfilterwarnings = ["default"]\n\n'
            "[tool.coverage.report]\nfail_under = 80\n",
            encoding="utf-8",
        )
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "warn"
        assert "filterwarnings" in finding.detail

    def test_corrupt_pyproject_returns_fail(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            "[project\nthis is not valid toml\n",
            encoding="utf-8",
        )
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "fail"
        assert "could not parse" in finding.detail.lower()


class TestClaudeMdCheck:
    def test_missing_returns_fail_with_fix(self, tmp_path: Path) -> None:
        finding = _check_claude_md(tmp_path, "demo", "cli")
        assert finding.severity == "fail"
        assert finding.fix is not None  # has mechanical fix

    def test_existing_with_markers_current_returns_ok(self, tmp_path: Path) -> None:
        (tmp_path / "docs").mkdir()
        (tmp_path / "docs" / "CLAUDE.md").write_text(
            _render_claude_md("demo", "cli"),
            encoding="utf-8",
        )
        finding = _check_claude_md(tmp_path, "demo", "cli")
        assert finding.severity == "ok"

    def test_existing_without_markers_warns(self, tmp_path: Path) -> None:
        (tmp_path / "docs").mkdir()
        (tmp_path / "docs" / "CLAUDE.md").write_text(
            "# Demo Project\n\nNo markers anywhere here.\n",
            encoding="utf-8",
        )
        finding = _check_claude_md(tmp_path, "demo", "cli")
        assert finding.severity == "warn"
        assert "BEGIN/END" in finding.detail
        # No mechanical fix for hand-written files.
        assert finding.fix is None

    def test_stale_auto_block_warns_with_fix(self, tmp_path: Path) -> None:
        (tmp_path / "docs").mkdir()
        # Use library kind in the file but check for cli kind — kind
        # affects the quick-start block, so the auto-block content
        # differs.
        (tmp_path / "docs" / "CLAUDE.md").write_text(
            _render_claude_md("demo", "library"),
            encoding="utf-8",
        )
        finding = _check_claude_md(tmp_path, "demo", "cli")
        assert finding.severity == "warn"
        assert "stale" in finding.detail
        assert finding.fix is not None  # refreshable


class TestClaudeSettingsCheck:
    def test_missing_warns_with_fix(self, tmp_path: Path) -> None:
        finding = _check_claude_settings(tmp_path, "cli")
        assert finding.severity == "warn"
        assert finding.fix is not None

    def test_existing_returns_ok(self, tmp_path: Path) -> None:
        (tmp_path / ".claude").mkdir()
        (tmp_path / ".claude" / "settings.json").write_text("{}", encoding="utf-8")
        finding = _check_claude_settings(tmp_path, "cli")
        assert finding.severity == "ok"


class TestV01PatternsCheck:
    def test_clean_project_returns_ok(self, tmp_path: Path) -> None:
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "demo.py").write_text(
            "from mgf.common import bootstrap\n"
            "with bootstrap(app_name='x', app_version='0.1') as ctx:\n"
            "    pass\n",
            encoding="utf-8",
        )
        finding = _check_v01_patterns(tmp_path)
        assert finding.severity == "ok"

    def test_legacy_calls_warn(self, tmp_path: Path) -> None:
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "legacy.py").write_text(
            "import mgf.common\n"
            "mgf.common.configure(app_name='x', app_version='0.1')\n"
            "from mgf.common.observability import setup_logging\n"
            "setup_logging(level='INFO')\n",
            encoding="utf-8",
        )
        finding = _check_v01_patterns(tmp_path)
        assert finding.severity == "warn"
        assert "configure(" in finding.detail
        assert "setup_logging(" in finding.detail
        # Catch-up does NOT auto-fix structural migrations.
        assert finding.fix is None


# ---------------------------------------------------------------------------
# End-to-end: run + apply.
# ---------------------------------------------------------------------------


class TestRunCatchUp:
    def test_audit_only_creates_no_files(self, tmp_path: Path) -> None:
        _seed_minimal_project(tmp_path)
        buf = io.StringIO()
        with redirect_stdout(buf):
            exit_code = run_catch_up(_make_args(tmp_path, kind="cli"))
        # Critical fail (missing CLAUDE.md) → exit 1.
        assert exit_code == 1
        # No files created.
        assert not (tmp_path / "docs").exists()
        assert not (tmp_path / ".claude").exists()
        # Report mentions the fail.
        assert "CLAUDE.md" in buf.getvalue()
        assert "missing" in buf.getvalue().lower()

    def test_apply_creates_missing_files(self, tmp_path: Path) -> None:
        _seed_minimal_project(tmp_path)
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))

        claude_md = tmp_path / "docs" / "CLAUDE.md"
        settings = tmp_path / ".claude" / "settings.json"
        assert claude_md.is_file()
        assert settings.is_file()
        # CLAUDE.md has the markers + project name.
        content = claude_md.read_text()
        assert CLAUDE_MD_BEGIN_MARKER in content
        assert CLAUDE_MD_END_MARKER in content
        assert "demo — Claude Reference" in content
        # settings.json is valid JSON.
        json.loads(settings.read_text())

    def test_apply_refresh_preserves_project_specific_content(
        self,
        tmp_path: Path,
    ) -> None:
        _seed_minimal_project(tmp_path)
        # First apply creates CLAUDE.md.
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))

        claude_md = tmp_path / "docs" / "CLAUDE.md"
        # Append project-specific content below the END marker.
        claude_md.write_text(
            claude_md.read_text() + "\n\n## Custom team note\n\nKeep me!\n",
            encoding="utf-8",
        )

        # Tamper with the auto-block to make catch-up detect drift.
        content = claude_md.read_text()
        content = content.replace("Standing instructions", "TAMPERED HEADING")
        claude_md.write_text(content, encoding="utf-8")

        # Re-apply.
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))

        refreshed = claude_md.read_text()
        # Auto-block restored.
        assert "Standing instructions" in refreshed
        assert "TAMPERED HEADING" not in refreshed
        # Project-specific content survives.
        assert "## Custom team note" in refreshed
        assert "Keep me!" in refreshed

    def test_apply_creates_backup_for_refreshed_claude_md(
        self,
        tmp_path: Path,
    ) -> None:
        _seed_minimal_project(tmp_path)
        # Apply once (creates fresh CLAUDE.md).
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))
        # Tamper to induce drift.
        claude_md = tmp_path / "docs" / "CLAUDE.md"
        claude_md.write_text(
            claude_md.read_text().replace(
                "Standing instructions", "TAMPERED",
            ),
            encoding="utf-8",
        )
        # Apply again — backup should be created.
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))
        backups = list((tmp_path / "docs").glob("CLAUDE.md.bak.*"))
        assert len(backups) == 1, "expected exactly one backup file"
        # Backup contains the tampered version.
        assert "TAMPERED" in backups[0].read_text()

    def test_invalid_target_dir(self, tmp_path: Path) -> None:
        from pathlib import Path

        bad = Path("/nonexistent/path/v11")
        out_buf = io.StringIO()
        # Don't redirect stderr — argparse error path uses different shape.
        with redirect_stdout(out_buf):
            from contextlib import redirect_stderr

            err_buf = io.StringIO()
            with redirect_stderr(err_buf):
                exit_code = run_catch_up(_make_args(bad, kind="cli"))
        assert exit_code == 1


@pytest.mark.parametrize(
    "kind", ["cli", "fastapi", "django", "library", "service"]
)
def test_apply_works_for_all_kinds(tmp_path: Path, kind: str) -> None:
    _seed_minimal_project(tmp_path)
    buf = io.StringIO()
    with redirect_stdout(buf):
        run_catch_up(_make_args(tmp_path, apply=True, kind=kind))
    assert (tmp_path / "docs" / "CLAUDE.md").is_file()
    assert (tmp_path / ".claude" / "settings.json").is_file()
