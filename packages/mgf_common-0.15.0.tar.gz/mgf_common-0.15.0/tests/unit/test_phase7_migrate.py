"""Phase 7 of the v0.3 closed-box redesign — migrate codemod tests.

Drives ``mgf-common migrate`` through the in-process ``main(argv)``
entry against ``tmp_path`` Python files. Verifies the safe
identifier-anchored renames, the per-rule import-gate semantics
(no over-application), --dry-run / --backup behaviour,
idempotency, and the unsupported-version path.

The codemod ships only mechanical safe renames; the bootstrap
reshape (§1 of MIGRATION_0.1_TO_0.3.md) is deliberately NOT
codemodded — it benefits from human review per case. Tests
assert this restriction (no transformation of bootstrap-shape
files).
"""

from __future__ import annotations

import textwrap
from typing import TYPE_CHECKING

from mgf.common.cli._exit_codes import (
    EXIT_CONFIG_ERROR,
    EXIT_OPERATION_ERROR,
    EXIT_SUCCESS,
)
from mgf.common.cli._mgfcli import main

if TYPE_CHECKING:
    from pathlib import Path

    import pytest


# ---------------------------------------------------------------------------
# EnvironmentError → HostEnvironmentError
# ---------------------------------------------------------------------------


class TestEnvironmentErrorRename:
    """Rule 1 — closes FEEDBACK API-01."""

    def test_rename_in_import_and_use_site(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str],
    ) -> None:
        target = tmp_path / "module.py"
        target.write_text(textwrap.dedent("""
            from mgf.common.exceptions import EnvironmentError

            class CpuLacksVmxError(EnvironmentError):
                pass

            def check() -> None:
                raise EnvironmentError("not supported")
        """))
        rc = main(["migrate", "0.1", "0.3", str(tmp_path)])
        assert rc == EXIT_SUCCESS
        new = target.read_text()
        assert "HostEnvironmentError" in new
        assert "EnvironmentError" not in new.replace("HostEnvironmentError", "")

    def test_does_not_touch_files_without_mgf_exceptions_import(
        self, tmp_path: Path,
    ) -> None:
        target = tmp_path / "unrelated.py"
        # Uses Python's builtin EnvironmentError (alias for OSError).
        # No mgf.common.exceptions import → MUST NOT be renamed.
        original = textwrap.dedent("""
            import os

            EnvironmentError = OSError  # MUST stay as-is

            def is_io_problem(exc: BaseException) -> bool:
                return isinstance(exc, EnvironmentError)
        """)
        target.write_text(original)
        main(["migrate", "0.1", "0.3", str(tmp_path)])
        assert target.read_text() == original

    def test_does_not_touch_substring_of_longer_identifier(
        self, tmp_path: Path,
    ) -> None:
        # MyEnvironmentErrorSubclass should NOT become MyHostEnvironmentErrorSubclass
        # (the rename is identifier-anchored via word boundary).
        target = tmp_path / "module.py"
        target.write_text(textwrap.dedent("""
            from mgf.common.exceptions import EnvironmentError

            # Substring inside a longer identifier — MUST NOT rename.
            class MyEnvironmentErrorSubclass(EnvironmentError):
                pass

            class MyEnvironmentErrorWrapper:
                pass
        """))
        main(["migrate", "0.1", "0.3", str(tmp_path)])
        new = target.read_text()
        # The exact identifier is replaced.
        assert "(HostEnvironmentError)" in new
        # Substrings inside MyEnvironmentErrorSubclass / MyEnvironmentErrorWrapper
        # MUST stay intact.
        assert "MyEnvironmentErrorSubclass" in new
        assert "MyEnvironmentErrorWrapper" in new


# ---------------------------------------------------------------------------
# make_settings_config → settings_config
# ---------------------------------------------------------------------------


class TestMakeSettingsConfigRename:
    """Rule 2 — drops the make_ verb-prefix noise."""

    def test_rename_in_import_and_call_site(
        self, tmp_path: Path,
    ) -> None:
        target = tmp_path / "settings.py"
        target.write_text(textwrap.dedent("""
            from mgf.common.config import BaseAppSettings, make_settings_config


            class MySettings(BaseAppSettings):
                model_config = make_settings_config(env_prefix="MYAPP_")
        """))
        main(["migrate", "0.1", "0.3", str(tmp_path)])
        new = target.read_text()
        assert "import BaseAppSettings, settings_config" in new
        assert "model_config = settings_config(env_prefix=" in new
        # No leftover make_settings_config.
        assert "make_settings_config" not in new

    def test_does_not_touch_files_without_mgf_config_import(
        self, tmp_path: Path,
    ) -> None:
        target = tmp_path / "unrelated.py"
        original = textwrap.dedent("""
            # Custom helper that happens to share the name.
            def make_settings_config(**kw):
                return kw
        """)
        target.write_text(original)
        main(["migrate", "0.1", "0.3", str(tmp_path)])
        assert target.read_text() == original


# ---------------------------------------------------------------------------
# Per-rule gating — multiple rules with different gates
# ---------------------------------------------------------------------------


class TestPerRuleGating:
    """Each rule has its own import_gate; rules apply independently."""

    def test_only_config_rule_applies_when_only_config_imported(
        self, tmp_path: Path,
    ) -> None:
        target = tmp_path / "module.py"
        target.write_text(textwrap.dedent("""
            from mgf.common.config import make_settings_config

            EnvironmentError = OSError  # builtin alias — MUST stay

            class S:
                model_config = make_settings_config(env_prefix="X_")
        """))
        main(["migrate", "0.1", "0.3", str(tmp_path)])
        new = target.read_text()
        # Config rule applied.
        assert "settings_config(env_prefix=" in new
        assert "make_settings_config" not in new
        # Exceptions rule did NOT apply (builtin EnvironmentError untouched).
        assert "EnvironmentError = OSError" in new
        assert "HostEnvironmentError" not in new

    def test_only_exceptions_rule_applies_when_only_exceptions_imported(
        self, tmp_path: Path,
    ) -> None:
        target = tmp_path / "module.py"
        target.write_text(textwrap.dedent("""
            from mgf.common.exceptions import EnvironmentError

            def make_settings_config(**kw):  # local helper — MUST stay
                return kw

            class CpuLacksVmxError(EnvironmentError):
                pass
        """))
        main(["migrate", "0.1", "0.3", str(tmp_path)])
        new = target.read_text()
        assert "import HostEnvironmentError" in new
        assert "(HostEnvironmentError)" in new
        # Local helper preserved.
        assert "def make_settings_config(" in new


# ---------------------------------------------------------------------------
# Bootstrap-reshape NOT codemodded
# ---------------------------------------------------------------------------


class TestBootstrapReshapeIsNotCodemodded:
    """The 5-call v0.1 bootstrap sequence MUST NOT be auto-rewritten;
    that is a behavioural reshape walked by the migration GUIDE."""

    def test_setup_logging_call_left_untouched(
        self, tmp_path: Path,
    ) -> None:
        target = tmp_path / "entry.py"
        original = textwrap.dedent("""
            from mgf.common import configure
            from mgf.common.observability import (
                setup_logging,
                setup_otel,
                install_excepthook,
                install_threading_excepthook,
            )

            def main():
                configure(app_name="myapp", app_version="1.0")
                setup_logging(level="DEBUG", fmt="json")
                setup_otel(enabled=True)
                install_excepthook()
                install_threading_excepthook()
        """)
        target.write_text(original)
        main_args = ["migrate", "0.1", "0.3", str(tmp_path)]
        rc = main(main_args)
        assert rc == EXIT_SUCCESS
        # No transformation — file unchanged.
        assert target.read_text() == original


# ---------------------------------------------------------------------------
# --dry-run / --backup
# ---------------------------------------------------------------------------


class TestDryRunAndBackup:
    """The two CLI safety flags."""

    def test_dry_run_does_not_modify_files(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str],
    ) -> None:
        target = tmp_path / "module.py"
        original = "from mgf.common.exceptions import EnvironmentError\n"
        target.write_text(original)
        rc = main(["migrate", "0.1", "0.3", str(tmp_path), "--dry-run"])
        captured = capsys.readouterr()
        assert rc == EXIT_SUCCESS
        # File unchanged.
        assert target.read_text() == original
        # Report still shows what WOULD have changed.
        assert "would change" in captured.out
        assert str(target) in captured.out
        assert "(dry-run)" in captured.out

    def test_backup_creates_bak_file(self, tmp_path: Path) -> None:
        target = tmp_path / "module.py"
        original = "from mgf.common.exceptions import EnvironmentError\n"
        target.write_text(original)
        rc = main(["migrate", "0.1", "0.3", str(tmp_path), "--backup"])
        assert rc == EXIT_SUCCESS
        # Backup carries the original.
        assert (tmp_path / "module.py.bak").read_text() == original
        # Target was rewritten.
        new = target.read_text()
        assert "HostEnvironmentError" in new

    def test_no_backup_by_default(self, tmp_path: Path) -> None:
        target = tmp_path / "module.py"
        target.write_text("from mgf.common.exceptions import EnvironmentError\n")
        main(["migrate", "0.1", "0.3", str(tmp_path)])
        # No .bak created.
        assert not (tmp_path / "module.py.bak").exists()


# ---------------------------------------------------------------------------
# Idempotency
# ---------------------------------------------------------------------------


class TestIdempotency:
    """Re-running the codemod is a no-op."""

    def test_second_run_is_noop(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str],
    ) -> None:
        target = tmp_path / "module.py"
        target.write_text(textwrap.dedent("""
            from mgf.common.exceptions import EnvironmentError
            from mgf.common.config import make_settings_config
        """))
        main(["migrate", "0.1", "0.3", str(tmp_path)])
        capsys.readouterr()  # discard first run output
        first = target.read_text()

        rc = main(["migrate", "0.1", "0.3", str(tmp_path)])
        captured = capsys.readouterr()
        assert rc == EXIT_SUCCESS
        # File unchanged on second run.
        assert target.read_text() == first
        assert "Nothing to do" in captured.out


# ---------------------------------------------------------------------------
# File walk + unsupported-version + missing-target
# ---------------------------------------------------------------------------


class TestFileWalk:
    """Recursion + skip directory + single-file targets."""

    def test_walks_recursively(self, tmp_path: Path) -> None:
        nested = tmp_path / "pkg" / "sub"
        nested.mkdir(parents=True)
        target = nested / "deep.py"
        target.write_text("from mgf.common.exceptions import EnvironmentError\n")
        rc = main(["migrate", "0.1", "0.3", str(tmp_path)])
        assert rc == EXIT_SUCCESS
        assert "HostEnvironmentError" in target.read_text()

    def test_skips_dot_venv_directory(self, tmp_path: Path) -> None:
        vendored = tmp_path / ".venv" / "lib" / "package"
        vendored.mkdir(parents=True)
        target = vendored / "vendored.py"
        # Vendored file MUST stay untouched even if it has the old name.
        original = "from mgf.common.exceptions import EnvironmentError\n"
        target.write_text(original)
        main(["migrate", "0.1", "0.3", str(tmp_path)])
        assert target.read_text() == original

    def test_skips_pycache_directory(self, tmp_path: Path) -> None:
        cache = tmp_path / "src" / "__pycache__"
        cache.mkdir(parents=True)
        target = cache / "stale.py"
        original = "from mgf.common.exceptions import EnvironmentError\n"
        target.write_text(original)
        main(["migrate", "0.1", "0.3", str(tmp_path)])
        assert target.read_text() == original

    def test_single_file_target(self, tmp_path: Path) -> None:
        target = tmp_path / "single.py"
        target.write_text("from mgf.common.exceptions import EnvironmentError\n")
        rc = main(["migrate", "0.1", "0.3", str(target)])
        assert rc == EXIT_SUCCESS
        assert "HostEnvironmentError" in target.read_text()

    def test_non_python_files_ignored(self, tmp_path: Path) -> None:
        target = tmp_path / "config.yaml"
        original = "EnvironmentError: should not be touched\n"
        target.write_text(original)
        main(["migrate", "0.1", "0.3", str(tmp_path)])
        assert target.read_text() == original


class TestErrorPaths:
    """Unsupported version + missing target."""

    def test_unsupported_migration_returns_config_error(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str],
    ) -> None:
        rc = main(["migrate", "9.9", "10.0", str(tmp_path)])
        captured = capsys.readouterr()
        assert rc == EXIT_CONFIG_ERROR
        assert "unsupported migration" in captured.err
        assert "Supported migrations:" in captured.err
        assert "0.1 → 0.3" in captured.err

    def test_missing_target_returns_operation_error(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str],
    ) -> None:
        rc = main(["migrate", "0.1", "0.3", str(tmp_path / "nonexistent")])
        captured = capsys.readouterr()
        assert rc == EXIT_OPERATION_ERROR
        assert "does not exist" in captured.err


# ---------------------------------------------------------------------------
# CLI dispatch — `migrate` is the fourth subcommand
# ---------------------------------------------------------------------------


class TestDispatch:
    """The CLI exposes migrate alongside explain/validate/doctor."""

    def test_migrate_in_subcommand_list(
        self, capsys: pytest.CaptureFixture[str],
    ) -> None:
        from mgf.common.cli._mgfcli import build_parser

        parser = build_parser()
        import argparse
        sub_action = next(
            a for a in parser._actions
            if isinstance(a, argparse._SubParsersAction)
        )
        assert "migrate" in sub_action.choices
