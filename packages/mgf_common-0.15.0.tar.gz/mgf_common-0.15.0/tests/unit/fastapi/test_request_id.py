"""Tests for ``mgf.common.fastapi.RequestIdMiddleware``."""

from __future__ import annotations

import re

from fastapi import FastAPI
from fastapi.testclient import TestClient

from mgf.common.fastapi import (
    REQUEST_ID_HEADER,
    RequestIdMiddleware,
    current_request_id,
)


def _build_app() -> FastAPI:
    app = FastAPI()
    app.add_middleware(RequestIdMiddleware)

    @app.get("/echo-id")
    def _echo() -> dict[str, str]:
        return {"id_via_contextvar": current_request_id()}

    return app


class TestRequestIdMiddleware:
    def test_generates_uuid_when_header_absent(self) -> None:
        with TestClient(_build_app()) as client:
            response = client.get("/echo-id")
        assert response.status_code == 200
        request_id = response.headers[REQUEST_ID_HEADER]
        # UUID4 shape.
        assert re.match(
            r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
            request_id,
        )
        # Echoed via contextvar inside the handler.
        assert response.json()["id_via_contextvar"] == request_id

    def test_forwards_inbound_header(self) -> None:
        with TestClient(_build_app()) as client:
            response = client.get(
                "/echo-id",
                headers={REQUEST_ID_HEADER: "client-supplied-123"},
            )
        assert response.headers[REQUEST_ID_HEADER] == "client-supplied-123"
        assert response.json()["id_via_contextvar"] == "client-supplied-123"

    def test_lowercase_inbound_header_accepted(self) -> None:
        with TestClient(_build_app()) as client:
            response = client.get(
                "/echo-id",
                headers={"x-request-id": "lower-case-456"},
            )
        # We echo using the canonical name.
        assert response.headers[REQUEST_ID_HEADER] == "lower-case-456"

    def test_each_request_gets_fresh_id(self) -> None:
        with TestClient(_build_app()) as client:
            r1 = client.get("/echo-id")
            r2 = client.get("/echo-id")
        assert r1.headers[REQUEST_ID_HEADER] != r2.headers[REQUEST_ID_HEADER]


class TestCurrentRequestIdOutsideRequest:
    def test_returns_empty_string_outside_request(self) -> None:
        # No request active; default is "".
        assert current_request_id() == ""
