"""Minimal URLconf for the test Django app."""

from __future__ import annotations

from django.http import JsonResponse
from django.urls import path


def _ping(request):
    return JsonResponse(
        {
            "request_id": getattr(request, "mgf_request_id", None),
            "context_app": getattr(request.mgf_context, "app_name", None)
            if getattr(request, "mgf_context", None)
            else None,
        }
    )


def _raise(request):
    raise RuntimeError("intentional test failure")


urlpatterns = [
    path("ping/", _ping, name="ping"),
    path("boom/", _raise, name="boom"),
]
