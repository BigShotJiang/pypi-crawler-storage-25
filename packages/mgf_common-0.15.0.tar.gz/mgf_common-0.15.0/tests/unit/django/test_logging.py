"""Tests for ``JsonFormatter`` — Django LOGGING-compatible wrapper."""

from __future__ import annotations

import json
import logging

from mgf.common.django import JsonFormatter
from mgf.common.observability.json_formatter import JsonFormatter as BaseJsonFormatter


class TestJsonFormatter:
    def test_no_arg_construction(self) -> None:
        # Django's '()' factory syntax constructs with no kwargs.
        # The wrapper MUST accept that.
        formatter = JsonFormatter()
        assert isinstance(formatter, BaseJsonFormatter)

    def test_emits_one_line_json(self) -> None:
        formatter = JsonFormatter()
        record = logging.LogRecord(
            name="test.logger",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="hello world",
            args=(),
            exc_info=None,
        )

        output = formatter.format(record)
        # One JSON object per line.
        assert "\n" not in output
        payload = json.loads(output)
        assert payload["level"] == "INFO"
        assert payload["msg"] == "hello world"
        assert payload["logger"] == "test.logger"

    def test_redaction_applied(self) -> None:
        formatter = JsonFormatter()
        record = logging.LogRecord(
            name="test.logger",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="login",
            args=(),
            exc_info=None,
        )
        record.password = "supersecret"  # type: ignore[attr-defined]
        record.username = "alice"  # type: ignore[attr-defined]

        output = formatter.format(record)
        payload = json.loads(output)

        # The default redactor scrubs ``password``-keyed fields.
        assert "supersecret" not in output
        assert payload.get("username") == "alice"  # not scrubbed
        assert payload.get("password") != "supersecret"

    def test_django_logging_integration(self) -> None:
        # Verify Django's logging.config.dictConfig accepts the
        # formatter via the '()' factory syntax.
        import logging.config

        logging.config.dictConfig(
            {
                "version": 1,
                "disable_existing_loggers": False,
                "formatters": {
                    "json": {"()": "mgf.common.django.JsonFormatter"},
                },
                "handlers": {
                    "memory": {
                        "class": "logging.NullHandler",
                        "formatter": "json",
                    },
                },
                "loggers": {
                    "test.django.formatter": {
                        "handlers": ["memory"],
                        "level": "DEBUG",
                    },
                },
            }
        )
        # If we got here without raising, dictConfig accepted the
        # factory. The handler is a NullHandler (no actual emit
        # checked — we already verified format() above).
        log = logging.getLogger("test.django.formatter")
        log.info("smoke test")  # should not raise
