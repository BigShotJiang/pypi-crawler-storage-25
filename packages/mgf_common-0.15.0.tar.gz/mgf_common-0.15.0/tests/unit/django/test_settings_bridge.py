"""Tests for ``DjangoSettingsBridge`` — typed read of django.conf.settings."""

from __future__ import annotations

from mgf.common.django import DjangoSettingsBridge


class TestDjangoSettingsBridge:
    def test_from_django_reads_live_settings(self) -> None:
        bridge = DjangoSettingsBridge.from_django()

        # Conftest configures these:
        assert bridge.debug is False
        assert "*" in bridge.allowed_hosts
        assert "django.contrib.contenttypes" in bridge.installed_apps
        assert "mgf.common.django" in bridge.installed_apps
        assert bridge.time_zone == "UTC"
        assert bridge.use_tz is True
        assert bridge.language_code == "en-us"

    def test_secret_key_never_in_bridge(self) -> None:
        # The bridge MUST NOT carry SECRET_KEY (too sensitive).
        # It exposes a presence boolean instead.
        bridge = DjangoSettingsBridge.from_django()

        assert bridge.secret_key_present is True
        assert not hasattr(bridge, "secret_key")

        # Defensive: dumping the bridge MUST NOT expose the secret.
        dumped = bridge.model_dump_json()
        assert "test-secret-key-not-for-production" not in dumped

    def test_mgf_common_settings_exposed(self) -> None:
        bridge = DjangoSettingsBridge.from_django()
        assert bridge.mgf_app_name == "test-app"
        assert bridge.mgf_app_version == "0.0.1"

    def test_bridge_is_a_baseappsettings(self) -> None:
        # AP-04 contract: bridge MUST be a BaseAppSettings so
        # ``mgf-common explain`` can introspect it.
        from mgf.common.config import BaseAppSettings

        bridge = DjangoSettingsBridge.from_django()
        assert isinstance(bridge, BaseAppSettings)

    def test_bridge_is_constructable_directly(self) -> None:
        # The bridge can be constructed from kwargs (not just from_django).
        # Useful in tests where the consumer doesn't want to mock Django.
        bridge = DjangoSettingsBridge(
            debug=True,
            allowed_hosts=("example.com",),
            installed_apps=("myapp",),
            secret_key_present=True,
        )
        assert bridge.debug is True
        assert bridge.allowed_hosts == ("example.com",)
