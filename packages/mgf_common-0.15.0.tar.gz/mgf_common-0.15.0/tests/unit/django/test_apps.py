"""Tests for ``MgfCommonConfig`` — bootstrap idempotency."""

from __future__ import annotations

from mgf.common.django import MgfCommonConfig
from mgf.common.django._apps import _cleanup_bootstrap


class TestMgfCommonConfig:
    def test_app_label(self) -> None:
        # Django app labels can't have dots; we pin a safe alternative.
        assert MgfCommonConfig.label == "mgf_common"
        assert MgfCommonConfig.name == "mgf.common.django"

    def test_ready_is_idempotent(self) -> None:
        # Django's setup() in conftest.py already called ready() once
        # (when the app registry built). Calling it again is a no-op
        # via the module-level guard.
        from mgf.common.django._apps import _BOOTSTRAP_STACK

        # First ready() ran during django.setup() — stack is set.
        assert _BOOTSTRAP_STACK is not None

        # Second ready() call (instantiate the AppConfig manually +
        # call ready) should be a no-op, not double-bootstrap.
        from django.apps import apps

        config = apps.get_app_config("mgf_common")
        config.ready()  # no-op
        config.ready()  # no-op
        # Guard intact.
        assert _BOOTSTRAP_STACK is not None

    def test_cleanup_idempotent(self) -> None:
        # Calling cleanup before any bootstrap is a no-op.
        # Calling it twice is a no-op.
        # We don't call cleanup mid-suite (that would tear down the
        # process-wide bootstrap and break later tests).
        from mgf.common.django import _apps

        # Save current state.
        original = _apps._BOOTSTRAP_STACK

        # Force-reset to None and verify cleanup is a no-op.
        _apps._BOOTSTRAP_STACK = None
        _cleanup_bootstrap()  # no-op — nothing to clean
        assert _apps._BOOTSTRAP_STACK is None

        # Restore.
        _apps._BOOTSTRAP_STACK = original
