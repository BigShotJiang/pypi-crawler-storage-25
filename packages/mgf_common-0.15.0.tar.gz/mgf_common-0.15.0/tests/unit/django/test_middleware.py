"""Tests for Django middleware: request-id + context propagation."""

from __future__ import annotations

import re

import pytest
from django.test import Client

_UUID4_PATTERN = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"
)


@pytest.fixture
def client() -> Client:
    return Client()


class TestRequestIdMiddleware:
    def test_generates_uuid4_when_no_header(self, client: Client) -> None:
        response = client.get("/ping/")

        assert response.status_code == 200
        rid = response["X-Request-Id"]
        assert _UUID4_PATTERN.match(rid), (
            f"Expected UUID4, got: {rid!r}"
        )

        # Echoed in the JSON body (the view reads request.mgf_request_id).
        assert response.json()["request_id"] == rid

    def test_forwards_inbound_header(self, client: Client) -> None:
        response = client.get(
            "/ping/",
            headers={"X-Request-Id": "test-correlation-abc"},
        )

        assert response.status_code == 200
        assert response["X-Request-Id"] == "test-correlation-abc"
        assert response.json()["request_id"] == "test-correlation-abc"

    def test_case_insensitive_inbound_header(self, client: Client) -> None:
        # Django normalises header case at the WSGI layer; but verify
        # via the canonical lookup we use.
        response = client.get(
            "/ping/",
            headers={"x-request-id": "lower-case-id"},
        )

        assert response["X-Request-Id"] == "lower-case-id"

    def test_contextvar_set_during_request(self, client: Client) -> None:
        # The contextvar is set during the view; assert via the JSON
        # response body that the view saw it.
        from mgf.common._request_id import current_request_id

        # OUTSIDE the request, the contextvar is empty.
        assert current_request_id() == ""

        response = client.get(
            "/ping/",
            headers={"X-Request-Id": "ctxvar-check"},
        )
        assert response.json()["request_id"] == "ctxvar-check"

        # AFTER the request, the contextvar resets.
        assert current_request_id() == ""


class TestContextMiddleware:
    def test_request_carries_app_context(self, client: Client) -> None:
        response = client.get("/ping/")

        # The conftest configures MGF_COMMON_APP_NAME = "test-app";
        # the AppContext should reflect that.
        assert response.json()["context_app"] == "test-app"

    def test_context_unavailable_pre_bootstrap(self) -> None:
        # If we somehow hit the middleware before bootstrap, the
        # response should still succeed with context=None. We can't
        # easily un-bootstrap mid-suite, so we test the middleware
        # logic directly with a fake current_context that raises.
        from unittest.mock import patch

        from mgf.common.django._middleware import MgfContextMiddleware

        called = {}

        def fake_get_response(request):
            called["mgf_context"] = request.mgf_context
            return

        middleware = MgfContextMiddleware(fake_get_response)

        class _FakeRequest:
            pass

        with patch(
            "mgf.common._lifecycle.current_context",
            side_effect=RuntimeError("not bootstrapped"),
        ):
            middleware(_FakeRequest())  # type: ignore[arg-type]

        assert called["mgf_context"] is None
