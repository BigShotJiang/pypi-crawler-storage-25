"""Console-script entry point — `python -m {{ cookiecutter.package_name }}`.

Demonstrates the canonical mgf-common bootstrap shape: identity
+ logging + OTel + crash hooks wired transactionally in one
call. Replace ``do_work()`` with your app's actual logic.
"""

from __future__ import annotations

import sys

import mgf.common
from mgf.common.observability import get_logger

LOG = get_logger(__name__)


def do_work() -> int:
    """Replace me with your app's actual entry-point logic."""
    LOG.info("hello from {{ cookiecutter.package_name }}")
    return 0


def main() -> int:
    """The console-script entry. Identity auto-derives from
    package metadata when run via ``python -m
    {{ cookiecutter.package_name }}``."""
    with mgf.common.bootstrap():
        return do_work()


if __name__ == "__main__":
    sys.exit(main())
