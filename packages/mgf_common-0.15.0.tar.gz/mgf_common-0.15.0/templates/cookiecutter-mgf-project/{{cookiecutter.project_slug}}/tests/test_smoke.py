"""Smoke tests — confirms the package imports + bootstraps cleanly."""

from __future__ import annotations

import {{ cookiecutter.package_name }}


def test_version_present() -> None:
    """The package exposes a non-empty ``__version__``."""
    assert isinstance({{ cookiecutter.package_name }}.__version__, str)
    assert {{ cookiecutter.package_name }}.__version__


def test_bootstrap_round_trip() -> None:
    """Bootstrap-for-test exits cleanly with the shipped settings."""
    from mgf.common import bootstrap_for_test

    with bootstrap_for_test() as ctx:
        assert ctx.app_name
        assert ctx.app_version
