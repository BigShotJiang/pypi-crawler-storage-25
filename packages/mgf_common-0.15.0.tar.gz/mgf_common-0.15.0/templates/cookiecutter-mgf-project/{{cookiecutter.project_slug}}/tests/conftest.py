"""Shared test fixtures.

The ``app_ctx`` fixture wraps ``mgf.common.bootstrap_for_test()``
— gives every test a clean ``AppContext`` with WARNING-level
logging, OTel disabled, deterministic preset. Auto-shutdown on
test exit.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest
from mgf.common import bootstrap_for_test

if TYPE_CHECKING:
    from collections.abc import Iterator

    from mgf.common import AppContext


@pytest.fixture
def app_ctx() -> Iterator[AppContext]:
    """Per-test bootstrap. Use when a test needs identity +
    settings wired (e.g. testing logging output or
    operation_span behavior)."""
    with bootstrap_for_test() as ctx:
        yield ctx
