# {{ cookiecutter.project_name }}

{{ cookiecutter.description }}

Built on [`mgf-common`]({{ cookiecutter.mgf_common_pin }}) — typed
exceptions, structured logging, OpenTelemetry tracing, and the
team's engineering-standards bar.

## Install

```bash
# With uv (recommended)
uv sync

# Or with pip
pip install -e ".[dev]"
```

## Run

```bash
python -m {{ cookiecutter.package_name }}
```

## Test

```bash
# Four green gates — all should pass before committing.
uv run ruff check
uv run mypy --strict src/
uv run pytest
uv run lint-imports
```

## Standards

This project follows
[`mgf-common`'s engineering standards](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/standards/).
Read any topic on demand:

```bash
mgf-common standards <topic>
```

Audit conformance:

```bash
mgf-common catch-up                  # project-setup audit
mgf-common doctor --standards        # code-level audit
```

## License

{{ cookiecutter.license }}.
