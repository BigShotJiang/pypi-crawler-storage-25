"""CLI commands for editorial review pipeline."""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Optional

import click

from cli_error_handling import handle_cli_exception
from core.review.models import ReviewReport

logger = logging.getLogger("scribe")


@click.group()
def review() -> None:
    """Editorial review pipeline — continuity, editorial, and humanization checks."""
    pass


@review.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Review a specific chapter only")
@click.option(
    "--quick", is_flag=True, help="Continuity check only (skip editor and humanizer passes)"
)
@click.option("--fix", is_flag=True, help="Apply auto-fixable issues after review")
@click.option(
    "--appendices/--no-appendices",
    default=False,
    help="Include character/world appendix data in review",
)
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.pass_context
def start(
    ctx: click.Context,
    project_name: str,
    chapter: Optional[int],
    quick: bool,
    fix: bool,
    appendices: bool,
    project_dir: str,
    provider: str,
) -> None:
    """Run the editorial review pipeline for a project."""
    debug = ctx.obj.get("debug", False) if ctx.obj else False
    logger.info(f"Starting review for '{project_name}'")

    project_path = Path(project_dir) / project_name
    if not project_path.exists():
        logger.error(f"Project '{project_name}' not found")
        sys.exit(1)

    chapters_dir = project_path / "chapters"
    if not chapters_dir.exists():
        logger.error(f"No chapters directory found for '{project_name}'")
        sys.exit(1)

    if chapter is not None:
        chapter_file = chapters_dir / f"chapter_{chapter:03d}.md"
        if not chapter_file.exists():
            logger.error(f"Chapter {chapter} not found")
            sys.exit(1)

    try:
        report = _run_review_pipeline(
            project_path=project_path,
            project_name=project_name,
            chapter=chapter,
            quick=quick,
            appendices=appendices,
            provider=provider,
        )

        _display_report(report)

        if fix and report.findings:
            _apply_fixes(report)

        if not quick:
            logger.info("Review pipeline complete.")

    except Exception as e:
        handle_cli_exception(logger, f"Review failed: {e}", e, debug=debug)


def _run_review_pipeline(
    project_path: Path,
    project_name: str,
    chapter: Optional[int],
    quick: bool,
    appendices: bool,
    provider: str,
) -> "ReviewReport":
    """Run the review pipeline and return a ReviewReport."""
    from core.llm_client import LLMConfig
    from core.orchestrator import create_orchestrator
    from core.review.models import ReviewCategory
    from core.review.report_generator import ReviewReportGenerator
    from core.storage import StorageConfig

    storage_config = StorageConfig(base_path=str(project_path.parent))
    llm_config = LLMConfig(provider=provider)
    orchestrator = create_orchestrator(storage_config, llm_config)

    workflow_path = str(Path(__file__).parent / "workflows" / "en" / "review_phase.yaml")
    if not Path(workflow_path).exists():
        workflow_path = str(Path(__file__).parent / "workflows" / "review_phase.yaml")

    initial_context: dict = {
        "project_name": project_name,
        "quick_mode": str(quick).lower(),
        "include_appendices": str(appendices).lower(),
        "provider": provider,
    }
    if chapter is not None:
        initial_context["chapter"] = str(chapter)

    result = orchestrator.execute_workflow(
        workflow_path=workflow_path,
        project_name=project_name,
        initial_context=initial_context,
    )

    generator = ReviewReportGenerator(project_name=project_name)

    continuity = result.context.get("continuity_findings", {})
    if continuity:
        generator.add_findings_from_dict(
            continuity,
            category=ReviewCategory.CONTINUITY,
        )

    editorial = result.context.get("editorial_findings", {})
    if editorial:
        generator.add_findings_from_dict(
            editorial,
            category=ReviewCategory.EDITORIAL,
        )

    humanization = result.context.get("humanization_findings", {})
    if humanization:
        generator.add_findings_from_dict(
            humanization,
            category=ReviewCategory.HUMANIZATION,
        )

    return generator.generate()


def _display_report(report: "ReviewReport") -> None:
    """Print the review report to stdout."""
    grade = report.quality_grade
    score = report.overall_quality_score

    logger.info("")
    logger.info(f"========== Review Report: {report.project} ==========")
    logger.info(f"  Quality Score: {score:.1f}/100 ({grade})")
    logger.info(f"  Total Findings: {report.total_findings}")
    logger.info(f"    Critical: {report.critical_count}")
    logger.info(f"    Warning:  {report.warning_count}")
    logger.info(f"    Info:     {report.info_count}")
    logger.info("")

    if not report.findings:
        logger.info("No issues found.")
        return

    by_category: dict = {}
    for f in report.findings:
        by_category.setdefault(f.category.value, []).append(f)

    for cat, findings in by_category.items():
        logger.info(f"  [{cat.upper()}]")
        for finding in findings[:5]:
            ch = f" Ch{finding.chapter}" if finding.chapter else ""
            loc = f" ({finding.location})" if finding.location else ""
            logger.info(f"    [{finding.severity.value}] {finding.description[:80]}{loc}{ch}")
        if len(findings) > 5:
            logger.info(f"    ... and {len(findings) - 5} more")
        logger.info("")


def _apply_fixes(report: "ReviewReport") -> None:
    """Apply auto-fixable issues from the report."""
    auto_fixable = [f for f in report.findings if f.auto_fixable]
    if not auto_fixable:
        logger.info("No auto-fixable issues found.")
        return

    logger.info(f"Applying {len(auto_fixable)} auto-fixable issues...")
    fixed_count = 0

    for finding in auto_fixable:
        if not finding.location:
            continue
        chapter_file = Path(finding.location)
        if not chapter_file.exists():
            continue
        original = chapter_file.read_text()
        if finding.suggested_fix and finding.suggested_fix not in original:
            updated = original.replace(finding.description, finding.suggested_fix, 1)
            if updated != original:
                chapter_file.write_text(updated)
                fixed_count += 1
                logger.info(f"  Fixed: {finding.description[:60]}")

    logger.info(f"Applied {fixed_count} fixes.")


@review.command("report")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Show findings for a specific chapter")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--save", "-s", is_flag=True, help="Save report to file")
@click.option("--output", "-o", type=click.Path(), help="Output file path")
@click.pass_context
def show_report(
    ctx: click.Context,
    project_name: str,
    chapter: Optional[int],
    project_dir: str,
    save: bool,
    output: Optional[str],
) -> None:
    """Display the latest review report."""
    import json

    project_path = Path(project_dir) / project_name
    report_path: Path | None = None

    candidates = [
        project_path / "reports" / "review_report.json",
        project_path / "reports" / "review_report.md",
    ]
    for candidate in candidates:
        if candidate.exists():
            report_path = candidate
            break

    if report_path is None:
        logger.error(f"No review report found for '{project_name}'")
        logger.info("Run 'scribe review start' first to generate a report.")
        sys.exit(1)

    if report_path.suffix == ".json":
        data = json.loads(report_path.read_text())
    else:
        click.echo(report_path.read_text())
        return

    if chapter is not None:
        findings = [f for f in data.get("findings", []) if f.get("chapter") == chapter]
        data["findings"] = findings

    logger.info(f"Review Report: {project_name}")
    logger.info("=" * 60)
    score = data.get("overall_quality_score", 0)
    total = data.get("total_findings", 0)
    critical = data.get("critical_count", 0)
    warning = data.get("warning_count", 0)
    info = data.get("info_count", 0)
    logger.info(f"  Quality Score: {score:.1f}/100 ({data.get('quality_grade', 'N/A')})")
    logger.info(
        f"  Total Findings: {total}  | Critical: {critical}  | Warning: {warning}  | Info: {info}"
    )

    if save:
        out_path = Path(output) if output else Path(project_name) / "review_report.json"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(data, indent=2))
        logger.info(f"✅ Report saved to {out_path}")


@review.command("formats")
def list_formats() -> None:
    """List available review modes."""
    click.echo("Available review modes:")
    click.echo("  full    — Continuity + editorial + humanization (default)")
    click.echo("  quick   — Continuity check only")
    click.echo("  chapter — Single chapter review (use --chapter)")
