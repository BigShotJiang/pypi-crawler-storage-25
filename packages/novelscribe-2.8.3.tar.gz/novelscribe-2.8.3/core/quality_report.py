"""
Quality Report Generation for Novel Generation.

This module provides quality report generation, fix suggestions,
and gate statistics, extracted from the QualityGate class.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .quality_metrics import QualityMetrics
from .quality_models import (
    FixApproach,
    FixSuggestionResponse,
    GateResult,
    QualityGateConfig,
    QualityLevel,
)
from .validation_system import ValidationReport

if TYPE_CHECKING:
    from .quality_gate import QualityGate


class QualityReportGenerator:
    """Generates quality reports, fix suggestions, and gate statistics.

    Uses composition: receives references to the parent QualityGate for
    methods that need gate-level operations (e.g. get_highest_passing_level,
    promote_to_level).
    """

    def __init__(self, project_root: Path, gate: "QualityGate") -> None:
        self.project_root = project_root
        self._gate = gate
        data_dir = project_root / "core" / "data" / "suggestions"
        self._fix_suggestions_cache = self._load_fix_suggestions(data_dir)

    # ------------------------------------------------------------------
    # Fix suggestion loading
    # ------------------------------------------------------------------

    def _load_fix_suggestions(self, data_dir: Path) -> Dict[str, List[FixApproach]]:
        """Load fix suggestions from YAML files."""
        import yaml

        fix_suggestions: Dict[str, List[FixApproach]] = {}

        try:
            quality_file = data_dir / "quality_suggestions.yaml"
            if quality_file.exists():
                with open(quality_file, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f)

                if data and "quality_suggestions" in data:
                    for lang in ["en", "zh-CN", "zh-TW"]:
                        if lang in data["quality_suggestions"]:
                            fix_suggestions[lang] = [
                                FixApproach(**suggestion)
                                for suggestion in data["quality_suggestions"][lang]
                            ]
        except Exception as e:
            print(f"Warning: Could not load fix suggestions: {e}")

        return fix_suggestions

    # ------------------------------------------------------------------
    # Fix suggestion queries
    # ------------------------------------------------------------------

    def get_fix_suggestions(
        self,
        failed_criteria: List[str],
        target_level: QualityLevel = QualityLevel.SILVER,
        language: str = "en",
    ) -> FixSuggestionResponse:
        """
        Get fix approach suggestions for failed quality criteria.

        Args:
            failed_criteria: List of failed quality criteria
            target_level: Target quality level
            language: Language code (en, zh-CN, zh-TW)

        Returns:
            FixSuggestionResponse with suggested fix approaches
        """
        if language not in self._fix_suggestions_cache:
            language = "en"

        available_fixes = self._fix_suggestions_cache.get(language, [])

        relevant_fixes = self._select_relevant_fixes(failed_criteria, available_fixes)

        urgency = self._determine_urgency(failed_criteria, target_level)

        recommended = self._recommend_fix_approach(relevant_fixes, failed_criteria)

        return FixSuggestionResponse(
            issue_summary=self._generate_issue_summary(failed_criteria),
            failed_criteria=failed_criteria,
            fix_approaches=relevant_fixes,
            recommended_approach=recommended.id if recommended else None,
            urgency_level=urgency,
            estimated_fix_time=self._estimate_fix_time(failed_criteria, target_level),
        )

    def _select_relevant_fixes(
        self, failed_criteria: List[str], available_fixes: List[FixApproach]
    ) -> List[FixApproach]:
        """Select relevant fix approaches based on failed criteria."""
        relevant: List[FixApproach] = []

        has_critical = any(c in ["validation", "quality_score"] for c in failed_criteria)
        has_style = any(
            c in ["passive_voice", "readability_ease", "adverb_frequency"] for c in failed_criteria
        )
        has_content = any(
            c in ["word_count", "dialogue_clarity", "character_consistency", "vocabulary_diversity"]
            for c in failed_criteria
        )

        for fix in available_fixes:
            if has_critical and "strict" in fix.id:
                relevant.append(fix)
            elif has_critical and "balanced" in fix.id:
                relevant.append(fix)
            elif has_style and ("auto_fix" in fix.id or "review" in fix.id):
                relevant.append(fix)
            elif has_content and ("defer" in fix.id or "manual" in fix.id):
                relevant.append(fix)
            elif "continuity" in fix.id and "character_consistency" in failed_criteria:
                relevant.append(fix)
            elif "style" in fix.id and has_style:
                relevant.append(fix)
            elif "pacing" in fix.id:
                relevant.append(fix)

        if not relevant:
            relevant = available_fixes[:3]

        return relevant[:4]

    def _determine_urgency(self, failed_criteria: List[str], target_level: QualityLevel) -> str:
        """Determine urgency level based on failed criteria and target level."""
        if "validation" in failed_criteria:
            return "critical"

        if target_level in [QualityLevel.GOLD, QualityLevel.PLATINUM]:
            return "high"

        if len(failed_criteria) >= 4:
            return "high"
        elif len(failed_criteria) >= 2:
            return "medium"
        else:
            return "low"

    def _recommend_fix_approach(
        self, relevant_fixes: List[FixApproach], failed_criteria: List[str]
    ) -> Optional[FixApproach]:
        """Recommend the best fix approach based on context."""
        if not relevant_fixes:
            return None

        if "validation" in failed_criteria or "quality_score" in failed_criteria:
            for fix in relevant_fixes:
                if "balanced" in fix.id:
                    return fix

        for fix in relevant_fixes:
            if "review" in fix.id:
                return fix

        return relevant_fixes[0]

    def _generate_issue_summary(self, failed_criteria: List[str]) -> str:
        """Generate a human-readable summary of issues."""
        criterion_names = {
            "word_count": "Word count",
            "passive_voice": "Passive voice usage",
            "readability_ease": "Readability score",
            "dialogue_clarity": "Dialogue clarity",
            "character_consistency": "Character consistency",
            "vocabulary_diversity": "Vocabulary diversity",
            "adverb_frequency": "Adverb frequency",
            "quality_score": "Overall quality score",
            "validation": "Validation errors",
        }

        names = [criterion_names.get(c, c) for c in failed_criteria]

        if len(names) == 1:
            return f"Issue with {names[0]}"
        elif len(names) == 2:
            return f"Issues with {names[0]} and {names[1]}"
        else:
            return f"Issues with {', '.join(names[:-1])}, and {names[-1]}"

    def _estimate_fix_time(self, failed_criteria: List[str], target_level: QualityLevel) -> str:
        """Estimate time required to fix issues."""
        if "validation" in failed_criteria:
            return "15-30 minutes"

        if target_level == QualityLevel.PLATINUM:
            return "1-2 hours"
        elif target_level == QualityLevel.GOLD:
            return "45-90 minutes"
        elif target_level == QualityLevel.SILVER:
            return "30-60 minutes"
        else:
            return "15-30 minutes"

    # ------------------------------------------------------------------
    # Promotion gap / auto-fix / action plan helpers
    # ------------------------------------------------------------------

    def analyze_promotion_gap(
        self, metrics: QualityMetrics, result: GateResult, target_level: QualityLevel
    ) -> Dict[str, Any]:
        """Analyze the gap between current and target quality level."""
        config = QualityGateConfig().get_level_config(target_level)

        gaps: Dict[str, Any] = {}
        for criterion in result.failed_criteria:
            if criterion in result.scores:
                current_value = result.scores[criterion]

                if criterion == "word_count":
                    threshold = config.min_word_count
                    gap = threshold - current_value
                    gaps[criterion] = {
                        "current": current_value,
                        "target": threshold,
                        "gap": gap,
                        "percent_improvement": (gap / threshold) * 100,
                    }
                elif criterion.endswith("_ratio") or criterion.endswith("_frequency"):
                    threshold = getattr(config, f"max_{criterion}", current_value)
                    gap = current_value - threshold
                    gaps[criterion] = {
                        "current": current_value,
                        "target": threshold,
                        "gap": gap,
                        "percent_improvement": (gap / current_value) * 100,
                    }
                else:
                    threshold = getattr(config, f"min_{criterion}", 0.0)
                    gap = threshold - current_value
                    gaps[criterion] = {
                        "current": current_value,
                        "target": threshold,
                        "gap": gap,
                        "percent_improvement": (gap / threshold) * 100 if threshold > 0 else 0,
                    }

        return gaps

    def generate_auto_fix_plan(
        self, failed_criteria: List[str], gap_analysis: Dict[str, Any]
    ) -> List[str]:
        """Generate automatic fix suggestions."""
        auto_fixes: List[str] = []

        for criterion in failed_criteria:
            if criterion in gap_analysis:
                gap = gap_analysis[criterion]

                if criterion == "word_count":
                    auto_fixes.append(
                        f"Add approximately {int(gap['gap'])} words to meet minimum count"
                    )
                elif criterion == "passive_voice":
                    auto_fixes.append(
                        f"Rewrite {int(gap['gap'] * 100)}% of passive constructions to active voice"
                    )
                elif criterion == "readability_ease":
                    auto_fixes.append(
                        "Simplify sentence structure and vocabulary to improve readability"
                    )
                elif criterion == "dialogue_clarity":
                    auto_fixes.append("Add speaker attributions to unidentified dialogue lines")
                elif criterion == "character_consistency":
                    auto_fixes.append("Incorporate missing character appearances and interactions")
                elif criterion == "vocabulary_diversity":
                    auto_fixes.append("Replace repeated words with varied vocabulary")
                elif criterion == "adverb_frequency":
                    auto_fixes.append(
                        f"Replace {int(gap['gap'] * 100)} adverbs with stronger verbs"
                    )

        return auto_fixes

    def generate_action_plan(
        self, failed_criteria: List[str], recommendations: List[str]
    ) -> List[str]:
        """Generate prioritized action plan for failed criteria."""
        priority_order = [
            "validation",
            "quality_score",
            "word_count",
            "character_consistency",
            "readability_ease",
            "dialogue_clarity",
            "vocabulary_diversity",
            "passive_voice",
            "adverb_frequency",
        ]

        actions: List[str] = []
        for criterion in priority_order:
            if criterion in failed_criteria:
                criterion_recommendations = [
                    rec
                    for rec in recommendations
                    if criterion.lower() in rec.lower()
                    or criterion.replace("_", " ") in rec.lower()
                ]
                actions.extend(criterion_recommendations[:2])

        return actions

    # ------------------------------------------------------------------
    # Full quality report
    # ------------------------------------------------------------------

    def generate_quality_report(
        self,
        project_name: str,
        metrics: QualityMetrics,
        validation_report: Optional[ValidationReport] = None,
    ) -> str:
        """
        Generate comprehensive quality report.

        Args:
            project_name: Name of the project
            metrics: Quality metrics
            validation_report: Optional validation report

        Returns:
            Formatted quality report as string
        """
        current_level = self._gate.get_highest_passing_level(
            project_name, metrics, validation_report
        )

        report_lines = [
            "# Quality Gate Report",
            f"Project: {project_name}",
            f"Chapter: {metrics.chapter_number} (Version {metrics.version})",
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            f"## Current Quality Level: {current_level.value.upper()}",
            "",
            "## Quality Scores",
            f"- Overall Quality: {metrics.overall_quality_score:.1%}",
            f"- Word Count: {metrics.word_count:,}",
            f"- Readability (Flesch-Kincaid): {metrics.flesch_kincaid:.1f}",
            f"- Dialogue Clarity: {metrics.speaker_clarity:.1%}",
            f"- Character Consistency: {metrics.character_consistency:.1%}",
            f"- Vocabulary Diversity: {metrics.vocabulary_diversity:.1%}",
            f"- Passive Voice Ratio: {metrics.passive_voice_ratio:.1%}",
            f"- Adverb Frequency: {metrics.adverb_frequency:.2%}",
            "",
        ]

        if validation_report:
            report_lines.extend(
                [
                    "## Validation Results",
                    f"- Total Rules Checked: {validation_report.total_rules_checked}",
                    f"- Passed: {validation_report.passed_rules}",
                    f"- Failed: {validation_report.failed_rules}",
                    f"- Warnings: {validation_report.warnings}",
                    f"- Errors: {validation_report.errors}",
                    "",
                ]
            )

        promotion_status = self._gate.promote_to_level(
            project_name, metrics, validation_report, QualityLevel.GOLD
        )

        report_lines.extend(
            [
                "## Promotion Path",
                f"- Current Level: {current_level.value}",
                f"- Next Target: {promotion_status['current_level'].value}",
                f"- Can Promote: {promotion_status['can_auto_promote']}",
                "",
            ]
        )

        if promotion_status["recommendations"]:
            report_lines.extend(["## Recommendations for Improvement", ""])
            for i, rec in enumerate(promotion_status["recommendations"], 1):
                report_lines.append(f"{i}. {rec}")

        return "\n".join(report_lines)

    # ------------------------------------------------------------------
    # Gate statistics
    # ------------------------------------------------------------------

    def get_gate_statistics(
        self, project_name: str, gate_history: Dict[str, List[GateResult]]
    ) -> Dict[str, Any]:
        """Get statistics for quality gate history."""
        if project_name not in gate_history:
            return {"error": "No gate history found for project"}

        history = gate_history[project_name]

        level_counts = {level.value: 0 for level in QualityLevel}
        pass_count = sum(1 for result in history if result.passed)
        total_count = len(history)

        for result in history:
            level_counts[result.gate_level.value] += 1

        recent_scores = [r.overall_score for r in history[-10:]]

        return {
            "project_name": project_name,
            "total_checks": total_count,
            "pass_count": pass_count,
            "pass_rate": pass_count / total_count if total_count > 0 else 0,
            "level_distribution": level_counts,
            "recent_average_score": (
                sum(recent_scores) / len(recent_scores) if recent_scores else None
            ),
            "most_common_level": max(level_counts, key=level_counts.get)
            if level_counts
            else "none",
        }
