"""Project discovery and management commands."""

from __future__ import annotations

import json
from pathlib import Path

import click

from cli_output import print_kv, print_list, print_section


@click.group()
def project() -> None:
    """Project discovery and management commands."""
    pass


@project.command("list")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--format", "output_format", type=click.Choice(["text", "json"]), default="text")
def list_projects(project_dir: str, output_format: str) -> None:
    """List available projects."""
    base = Path(project_dir)

    if not base.exists():
        if output_format == "json":
            click.echo(json.dumps({"project_dir": str(base), "count": 0, "projects": []}, indent=2))
            return
        print_section("Projects")
        print_kv("Project Dir", base)
        print_kv("Count", 0)
        click.echo("No projects found.")
        return

    projects = sorted([p.name for p in base.iterdir() if p.is_dir()])

    if output_format == "json":
        click.echo(
            json.dumps(
                {
                    "project_dir": str(base),
                    "count": len(projects),
                    "projects": projects,
                },
                indent=2,
            )
        )
        return

    print_section("Projects")
    print_kv("Project Dir", base)
    print_kv("Count", len(projects))
    if projects:
        click.echo("")
        print_list(projects)
    else:
        click.echo("No projects found.")
