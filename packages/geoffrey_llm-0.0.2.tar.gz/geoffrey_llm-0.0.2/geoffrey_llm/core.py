"""Core module - Unified LLM API client"""

import os
from typing import Iterator, Optional


class LLMClient:
    """
    统一大模型调用接口
    支持：OpenAI、阿里云 DashScope、本地 Ollama
    """
    
    def __init__(
        self,
        provider: str = "openai",  # openai | dashscope | ollama
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: Optional[str] = None
    ):
        self.provider = provider
        
        # 自动从环境变量读取 api_key
        self.api_key = api_key or self._get_api_key_from_env()
        self.base_url = base_url
        self.model = model or self._default_model()
        
        # 延迟导入，避免强制依赖
        self._client = None
    
    def _get_api_key_from_env(self) -> Optional[str]:
        env_map = {
            "openai": "OPENAI_API_KEY",
            "dashscope": "DASHSCOPE_API_KEY",
            "ollama": None  # ollama 不需要 key
        }
        env_var = env_map.get(self.provider)
        return os.getenv(env_var) if env_var else None
    
    def _default_model(self) -> str:
        defaults = {
            "openai": "gpt-3.5-turbo",
            "dashscope": "qwen-turbo",
            "ollama": "llama2"
        }
        return defaults.get(self.provider, "gpt-3.5-turbo")
    
    def _get_client(self):
        """延迟初始化客户端"""
        if self._client is not None:
            return self._client
            
        if self.provider == "openai":
            try:
                from openai import OpenAI
            except ImportError:
                raise ImportError("请安装 openai: pip install openai")
            
            self._client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
            
        elif self.provider == "dashscope":
            try:
                import dashscope
            except ImportError:
                raise ImportError("请安装 dashscope: pip install dashscope")
            
            dashscope.api_key = self.api_key
            self._client = dashscope
            
        elif self.provider == "ollama":
            try:
                import ollama
            except ImportError:
                raise ImportError("请安装 ollama: pip install ollama")
            
            self._client = ollama
            
        else:
            raise ValueError(f"不支持的 provider: {self.provider}")
        
        return self._client
    
    def chat(self, message: str, stream: bool = False, **kwargs) -> str:
        """
        单轮对话
        
        Args:
            message: 用户输入
            stream: 是否流式输出
            **kwargs: 额外参数（temperature, max_tokens 等）
        
        Returns:
            模型回复文本
        """
        client = self._get_client()
        
        if self.provider == "openai":
            return self._chat_openai(message, stream, **kwargs)
        elif self.provider == "dashscope":
            return self._chat_dashscope(message, stream, **kwargs)
        elif self.provider == "ollama":
            return self._chat_ollama(message, stream, **kwargs)
    
    def _chat_openai(self, message: str, stream: bool, **kwargs) -> str:
        from openai import OpenAI
        
        messages = [{"role": "user", "content": message}]
        
        response = self._client.chat.completions.create(
            model=self.model,
            messages=messages,
            stream=stream,
            **kwargs
        )
        
        if stream:
            # 返回生成器
            return self._stream_response(response)
        
        return response.choices[0].message.content
    
    def _chat_dashscope(self, message: str, stream: bool, **kwargs) -> str:
        from dashscope import Generation
        
        response = Generation.call(
            model=self.model,
            messages=[{"role": "user", "content": message}],
            stream=stream,
            **kwargs
        )
        
        if stream:
            return self._stream_dashscope(response)
        
        return response.output.text
    
    def _chat_ollama(self, message: str, stream: bool, **kwargs) -> str:
        response = self._client.chat(
            model=self.model,
            messages=[{"role": "user", "content": message}],
            stream=stream,
            options=kwargs
        )
        
        if stream:
            return self._stream_ollama(response)
        
        return response['message']['content']
    
    def _stream_response(self, response) -> Iterator[str]:
        """OpenAI 流式处理"""
        for chunk in response:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
    
    def _stream_dashscope(self, response) -> Iterator[str]:
        """DashScope 流式处理"""
        for chunk in response:
            if chunk.output and chunk.output.text:
                yield chunk.output.text
    
    def _stream_ollama(self, response) -> Iterator[str]:
        """Ollama 流式处理"""
        for chunk in response:
            if 'message' in chunk and 'content' in chunk['message']:
                yield chunk['message']['content']


# 保留旧函数保持兼容
def placeholder():
    """占位函数"""
    return "geoffrey-llm v0.0.2 - Unified LLM Client is ready!"
