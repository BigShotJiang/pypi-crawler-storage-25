"""geoffrey-llm: A lightweight toolkit for LLM development"""

__version__ = "0.0.2"
__author__ = "Geoffrey"

from .core import LLMClient, placeholder


__all__ = ["LLMClient", "placeholder"]
