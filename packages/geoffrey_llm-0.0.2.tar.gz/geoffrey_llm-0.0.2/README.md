# geoffrey-llm

[![PyPI version](https://badge.fury.io/py/geoffrey-llm.svg)](https://pypi.org/project/geoffrey-llm/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

A lightweight toolkit for LLM fine-tuning, inference optimization, and agent development.

> ⚠️ **Note**: This package is currently in early development (v0.0.1). APIs will change frequently.

## Planned Features

- [ ] Simplified LoRA/QLoRA fine-tuning interface
- [ ] Unified inference backend (vLLM, llama.cpp, TensorRT)
- [ ] GraphRAG-lite for knowledge graph RAG
- [ ] Log analysis Agent toolkit
- [ ] Model quantization utilities (AWQ, GPTQ)

## Installation

```bash
pip install geoffrey-llm
```

### Optional dependencies

```bash
# For fine-tuning capabilities
pip install geoffrey-llm[finetune]

# For optimized inference
pip install geoffrey-llm[inference]

# Development install
pip install geoffrey-llm[dev]
```

## Quick Start

```python
from geoffrey_llm import placeholder

print(placeholder())
# Output: geoffrey-llm is under development. Stay tuned!
```

## License

MIT License