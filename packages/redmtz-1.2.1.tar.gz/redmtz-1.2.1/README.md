# REDMTZ — AI Agent Governance

> **"No agent crosses the gate without passing through the law."**

[![License](https://img.shields.io/badge/license-Proprietary-red.svg)]()
[![Python](https://img.shields.io/badge/python-3.12%2B-blue.svg)]()
[![Tests](https://img.shields.io/badge/tests-242%2F242%20passing-brightgreen.svg)]()
[![Supply Chain](https://img.shields.io/badge/supply%20chain-hash%20pinned-brightgreen.svg)]()
[![Patents](https://img.shields.io/badge/patents-USPTO%20filed-blue.svg)]()

---

## What Is REDMTZ?

REDMTZ builds the governance layer that sits between AI agents and the real world.

When your AI agent runs a SQL query, executes a shell command, or reads a file — how do you know it didn't do something it shouldn't have? How do you prove it to a regulator, auditor, or legal team?

REDMTZ answers both questions with cryptographic proof.

**Two products, one architecture:**

| | Seatbelt | Cockpit |
|---|---|---|
| **What it is** | Python library, 3 lines of code | Full 7-gate governance pipeline |
| **Governance** | Deterministic (pure logic) | Neuro-symbolic (logic + LLM) |
| **Infrastructure** | Zero — runs in your process | Ollama local LLM + pipeline |
| **Setup time** | 5 minutes | Full deployment |
| **governance_mode** | `"deterministic"` | `"neuro-symbolic"` |
| **Status** | ✅ Shipping | 🔄 Active development |

Same envelope schema. Same audit trail. Same patent. Seatbelt is the on-ramp. Cockpit is the destination.

---

# SEATBELT — Start Here

## What Is Seatbelt?

Seatbelt is a Python library that wraps your AI agent's execution functions and does three things automatically:

1. **Blocks** destructive actions before they execute — DROP TABLE, rm -rf /, credential theft, SQL injection, and more
2. **Signs** every decision with Ed25519 cryptography — tamper-evident proof that the decision happened
3. **Chains** every decision to the one before it — so nothing can be deleted or modified without detection

The result: when a regulator asks "what did your AI agent do?" — you produce cryptographic proof, not a story.

## Quickstart — 5 Minutes

```bash
pip install redmtz
```

**Using a Python function? Three lines:**

```python
from redmtz import govern, GovernanceBlocked

@govern(rules="destructive_actions", policy="safe_defaults")
def execute_sql(query: str):
    db.execute(query)
```

**Using Claude Code, Claude Desktop, Cline, or Cursor? One command:**

```bash
redmtz serve
```

Then point your MCP client at it. → [Full connection guide](CONNECT.md)

That's it. Your function is now governed.

```python
# Safe — passes through, signed envelope logged
execute_sql("SELECT * FROM users WHERE id = 42")

# Dangerous — blocked before execution, signed proof created
try:
    execute_sql("DROP TABLE users")
except GovernanceBlocked as e:
    print(f"Blocked:  {e.pattern.description}")
    print(f"Proof ID: {e.envelope['event_id']}")
    print(f"Fix:      {e.remediation_hint}")
```

## Run the Demo

```bash
python demo.py
```

60 seconds. Genesis block auto-generated. Safe action allowed. Dangerous action blocked. Signed envelope printed. That's the complete story.

---

## How Seatbelt Works — Plain English

Think of Seatbelt like a bouncer at a club. Every action your AI agent tries to take has to pass the bouncer first. The bouncer checks a list of known dangerous patterns. If the action matches — it's blocked at the door. The agent never gets in.

The bouncer writes down exactly what happened, signs the note with a cryptographic key, and locks it in a tamper-evident chain. That signed note is called an **envelope**. It's your proof.

## How Seatbelt Works — Under the Hood

```
Function called
      │
      ▼
1. Extract action string from arguments
      │
      ▼
2. PatternMatcher.match_all()
   8 hardcoded patterns — zero LLM, pure regex
      │
      ├── No match ──────────────────────────┐
      │                                      │
      ▼                                      │
3. Policy check (safe_defaults / read_only   │
   / audit_mode / strict_prod)               │
      │                                      │
      ▼                                      │
4. Build signed RDM-019 envelope             │
   UUID v7 · SHA-256 digest · hash chain     │
   Ed25519 signature · governance_mode       │
      │                                      │
      ▼                                      │
5. Log to SQLite ledger + SEDR JSONL         │
      │                                      ▼
      ├── BLOCK → GovernanceBlocked      6. Execute function
      │           (envelope attached)        │
      └───────────────────────────────── Return result
```

**Key principle:** Logging happens before execution. Every decision — allow or block — is in the audit trail. No gaps.

---

## What Gets Blocked — 8 Core Patterns

All patterns are hardcoded regex. Zero LLM. Zero AI. Deterministic and auditable.

### Database Patterns

| Pattern ID | Risk | What It Catches |
|------------|------|-----------------|
| `BLOCK_DROP_TABLE` | CRITICAL | `DROP TABLE users`, `drop table logs` |
| `BLOCK_TRUNCATE` | CRITICAL | `TRUNCATE TABLE users`, `truncate logs` |
| `BLOCK_DELETE_NO_WHERE` | CRITICAL | `DELETE FROM users`, `DELETE FROM t WHERE 1=1` |
| `BLOCK_SQL_INJECTION_OBVIOUS` | HIGH | `f"SELECT * WHERE id={uid}"`, string concat SQL |

### System / File Patterns

| Pattern ID | Risk | What It Catches |
|------------|------|-----------------|
| `BLOCK_RM_RF_ROOT` | CRITICAL | `rm -rf /`, `rm -rf /etc`, `rm -rf /bin` |
| `BLOCK_CRED_THEFT` | CRITICAL | `cat ~/.ssh/id_rsa`, `cat ~/.aws/credentials`, hardcoded `api_key='...'` |
| `BLOCK_SHELL_EXEC_DANGEROUS` | HIGH | `subprocess.run(cmd, shell=True)`, `os.system('curl ' + url)` |
| `BLOCK_WILDCARD_DELETE` | HIGH | `rm /var/log/*`, `shutil.rmtree('/home/user/docs')` |

**False positive rate: zero** — all 8 patterns are tested against their allowed examples. A `DELETE FROM users WHERE id=123` (with WHERE clause) passes through. A `SELECT * FROM drop_temp` (drop in identifier) passes through.

---

## Policy Templates

| Policy | CRITICAL | HIGH | MEDIUM | LOW | Use When |
|--------|----------|------|--------|-----|----------|
| `safe_defaults` | Block | Block | Allow | Allow | Starting point for most agents |
| `read_only` | Block | Block | Block | Allow | Reporting / analytics agents |
| `audit_mode` | Allow | Allow | Allow | Allow | Integration testing, observability |
| `strict_prod` | Block | Block | Block | Block | Zero-tolerance production systems |

```python
@govern(rules="destructive_actions", policy="audit_mode")   # See everything, block nothing
@govern(rules="destructive_actions", policy="strict_prod")  # Block anything that matches
```

---

## The GovernanceBlocked Exception

```python
try:
    execute_sql("DROP TABLE users")
except GovernanceBlocked as e:
    e.envelope           # Full signed RDM-019 envelope (dict) — your cryptographic proof
    e.pattern            # First matched DestructivePattern
    e.patterns           # All matched patterns (list — one action can match multiple)
    e.remediation_hint   # Plain-English fix for the developer
```

---

## The Signed Envelope — Your Cryptographic Proof

Every decision produces an envelope. This is what you show auditors, regulators, and legal teams.

```json
{
  "event_id":        "019d31c3-b92a-7150-9d27-a9f897c0deef",
  "timestamp_utc":   "2026-03-28T02:14:33.421+00:00",
  "governance_mode": "deterministic",

  "actor": {
    "type":              "application",
    "identity":          "myapp.database.execute_sql",
    "credential_method": "decorator"
  },

  "input": {
    "digest": "a3f5c8d2e1b7f9c4...",
    "token_count": 3,
    "classification": "unknown"
  },

  "gate_decisions": [{
    "gate":     "resolver",
    "decision": "block",
    "reason":   "BLOCK_DROP_TABLE",
    "patterns": ["BLOCK_DROP_TABLE"]
  }],

  "hash_chain": {
    "previous_hash": "2edf56acc1fd16ca...",
    "current_hash":  "2405c42ff0d032c5..."
  },

  "signatures": [{
    "signer":    "myapp.database.execute_sql",
    "signature": "fxgmFMU/I8n6l/x+Mcj2...",
    "type":      "self"
  }]
}
```

**`input.digest`** — SHA-256 of the raw query. The actual SQL is never stored. GDPR-safe by design.

**`hash_chain`** — Delete or modify any envelope and the chain breaks. This is mathematical tamper detection, not a policy.

**`signatures`** — Ed25519. Any auditor with your public key (`keys/sudo_signing.pub`) can independently verify every decision, forever, without accessing your system.

**`governance_mode: "deterministic"`** — Proves this decision was made by pure logic, not an AI model. When you upgrade to Cockpit, envelopes emit `"neuro-symbolic"`. Your audit history shows the transition.

---

## Key Management — Zero Config

On first import, Seatbelt auto-generates an Ed25519 keypair:

```
keys/
  sudo_signing.key   ← private key (mode 0600, only you can read it)
  sudo_signing.pub   ← public key  (share this with auditors)
```

Never asked again. Never requires configuration.

**To override key location (recommended for production):**
```bash
export REDMTZ_SUDO_KEY_PATH=/path/to/sudo_signing.key
export REDMTZ_SUDO_PUBKEY_PATH=/path/to/sudo_signing.pub
```

For a full breakdown of what Seatbelt governs and what it doesn't, see [GOVERNANCE_SCOPE.md](GOVERNANCE_SCOPE.md).

---

## Querying Your Audit Trail

### CISO Dashboard
```bash
python dashboard_server.py   # http://localhost:5001
```

### REST API
```bash
curl http://localhost:8000/api/audit/query?limit=50   # Recent decisions
curl http://localhost:8000/api/audit/export           # CSV export
```

### Direct SQLite
```python
import sqlite3
conn = sqlite3.connect('redmtz_audit.db')
blocks = conn.execute(
    "SELECT timestamp_utc, reason FROM audit_log WHERE verdict='BLOCK'"
).fetchall()
```

### Pipe to your SIEM
```bash
curl http://localhost:8000/api/audit/export | splunk add oneshot - -sourcetype redmtz
```

---

## Action Extraction Heuristics

Seatbelt finds the action string in your function arguments automatically:

1. First parameter named `query`, `command`, `action`, `sql`, `cmd`, `shell_cmd`, `statement`, or `text` → use it
2. First parameter is a string → use it regardless of name
3. Can't find a string → log warning, execute without checking (fail-open for unknowns)

Domain is inferred from parameter and function names (`sql`/`query` → `database`, `cmd`/`shell` → `system`). Unknown domain → check all patterns (`*`).

---

## Upgrading to Cockpit

Seatbelt is Gates 2, 5, and 6 of the full Cockpit pipeline. The upgrade is non-breaking:

| Feature | Seatbelt | Cockpit |
|---------|----------|---------|
| Destructive pattern blocking | ✅ | ✅ |
| Signed envelopes | ✅ | ✅ |
| Hash chain audit trail | ✅ | ✅ |
| LLM intent analysis (Yang's Law) | ❌ | ✅ |
| Multi-agent mesh auth | ❌ | ✅ |
| Human-in-the-loop approval | ❌ | ✅ |
| Centralized cloud audit | ❌ | ✅ |
| governance_mode | `deterministic` | `neuro-symbolic` |

Same envelope schema. Same keypair. Same audit history. You add gates — you replace nothing.

---

# COCKPIT — The Full Platform

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    MCP SERVER (mcp_server.py)            │
│              The 7-Gate Governance Pipeline              │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────────┐  │
│  │  GATE 1  │→ │  GATE 2  │→ │       GATE 3         │  │
│  │ SOVEREIGN│  │ RESOLVER │  │  CONTEXT GUARDIAN    │  │
│  │ blacklist│  │Yang's Law│  │  mesh governance     │  │
│  └──────────┘  └──────────┘  └──────────────────────┘  │
│       ↓              ↓                  ↓               │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────────┐  │
│  │  GATE 4  │→ │  GATE 5  │→ │       GATE 6         │  │
│  │ AI SUDO  │  │WATCHTOWER│  │   FINAL VERDICT      │  │
│  │  human   │  │  AEGIS   │  │  aggregate + audit   │  │
│  └──────────┘  └──────────┘  └──────────────────────┘  │
│                                                          │
│  PROCEED requires ALL gates to pass.                     │
│  BLOCK if ANY gate fails. Fail-closed always.            │
└─────────────────────────────────────────────────────────┘
```

## Gate Reference

### Gate 1: Sovereign (`mcp_server.py` + `sovereign.py`)
Blacklist enforcement with dual-time sequencing. Checks agent lineage (agent ID, company, nation, swarm) against the sovereign blacklist. Hard stop on any match.

RDM-020: Every action gets a `SequenceAnchor` — wall-clock UTC + `CLOCK_MONOTONIC_RAW` nanoseconds + UUID v4 replay nonce. Duplicate nonce = replay attack = BLOCK.

### Gate 2: Resolver (`resolver.py`)
Intent-vs-command consistency. Uses a local LLM (Mistral 7B via Ollama) to independently extract intent and command, then runs:
- **Yang's Law** — constructive intent + destructive action = BLOCK
- **Skill Registry Gate** — unregistered skills = BLOCK
- **Parameter Guard** — dangerous flags, zone violations, count escalation
- **Neuro-Symbolic Trickery Detection** — LLM flags mismatches, deterministic layer vetoes false positives

### Gate 3: Context Guardian (`context_guardian.py`)
Mesh governance across agent boundaries:
- **Lateral**: agent-to-agent topology enforcement
- **Protocol**: agent-to-service governance (MCP, A2A, tools)
- **Hierarchical**: escalation chains to human supervisors

### Gate 4: AI Sudo (`ai_sudo.py`)
Human-in-the-loop approval. `sudo` for AI agents. Fail-closed: no response = DENY, timeout = DENY, error = DENY. Every approval is Ed25519 signed (Patent Claim 28).

### Gate 5: Watchtower (`watchtower.py`)
AEGIS behavioral scoring (0-100):
- Base risk from skill registry
- Session threat persistence
- **Exponential velocity penalty**: `2^n - 1` — rapid-fire attacks escalate cost exponentially
  - 1 violation = 1pt, 3 = 7pts, 5 = 31pts, 8 = 255pts (instant CRITICAL_DRIFT)

### Gate 6: Final Verdict (`mcp_server.py`)
Aggregates all gate results, produces PROCEED/BLOCK, creates compliance hash, logs signed envelope to audit ledger.

---

## Key Innovations

### Yang's Law
Symbolic truth table for intent-action contradictions:
- Constructive intent + Destructive action → **BLOCK** (contradiction)
- Neutral intent + Destructive action → **HOLD** (needs human review)
- Unknown intent + Destructive action → **BLOCK** (unsafe)
- Destructive intent + Constructive action → **BLOCK** (suspicious reversal)

### Neuro-Symbolic Bridge
LLMs flag suspicion (neural layer). Deterministic logic has veto power (symbolic layer). If action verbs and targets match, the system overrides LLM false positives. Neural for detection, symbolic for decision.

### RDM-019 Canonical Envelope
Every decision — across all 7 gates, across Seatbelt and Cockpit — produces the same envelope schema. UUID v7 event ID. SHA-256 digest-only (no raw PII stored). Ed25519 signed. Hash-chained. `governance_mode` field distinguishes deterministic vs neuro-symbolic governance.

### Exponential Velocity Penalty
Linear penalties let attackers budget violations. Exponential penalties (`2^n - 1`) make sustained rapid-fire attacks economically impossible.

### SEDR (Sentinel Event Data Recorder)
Parallel append-only JSONL file as SQLite failsafe. If the database fails mid-decision, SEDR has it. Two independent records per decision.

---

## Module Reference

### Seatbelt (MVP — Shipping)

| Module | Purpose |
|--------|---------|
| `decorator.py` | `@govern` decorator — the 3-line integration |
| `patterns.py` | 8 hardcoded destructive patterns + `PatternMatcher` |
| `policies.py` | 4 policy templates (safe_defaults, read_only, audit_mode, strict_prod) |
| `actions.py` | ActionGrammar — 12-verb finite set, 8 domains, risk matrix |
| `envelope.py` | RDM-019 CanonicalEnvelope — build + verify signed envelopes |
| `sovereign.py` | SequenceAnchor — dual-time stamp + UUID v4 replay nonce |
| `replay_detector.py` | SQLite-backed nonce registry — replay attack detection |
| `sudo_signing.py` | Ed25519 keypair generation, signing, verification |
| `database.py` | SHA-256 hash-chained SQLite audit ledger |
| `__init__.py` | `from redmtz import govern, GovernanceBlocked` |
| `demo.py` | 60-second CLI demo for prospects and demos |

### Cockpit (Active Development)

| Module | Purpose |
|--------|---------|
| `mcp_server.py` | 7-Gate Pipeline — MCP server entry point |
| `resolver.py` | Intent-vs-command consistency (Yang's Law + NSB) |
| `context_guardian.py` | Mesh governance — lateral, protocol, hierarchical |
| `ai_sudo.py` | Human-in-the-loop approval engine |
| `watchtower.py` | AEGIS behavioral scoring + velocity penalties |
| `skills.py` | Unified Skill Registry + Intent/Action Maps |
| `reasoner.py` | Reasoning engine for complex decision chains |
| `config.py` | Centralized config (Ollama URL, models, timeouts) |
| `api.py` | REST API (audit query, CSV export) |
| `dashboard_server.py` | CISO dashboard server |
| `ciso_dashboard.html` | Visual audit dashboard |

---

## Test Suite — 242/242 Passing

| Test File | Module | Tests |
|-----------|--------|-------|
| `test_envelope.py` | RDM-019 Canonical Envelope | 30 |
| `test_action_grammar.py` | RDM-015 Action Grammar | 54 |
| `test_sovereign_monotonic.py` | RDM-020 Monotonic Clock + Replay | 36 |
| `test_patterns.py` | RDM-021 Pattern Library | 72 |
| `test_decorator.py` | RDM-022 @govern Decorator | 50 |
| `test_mcp_gates.py` | Cockpit 7-Gate Pipeline | 14 |
| `test_schema_migration.py` | Database schema migration | 10 |

```bash
source venv/bin/activate
python -m pytest -v   # Run all 242 tests
```

---

## Compliance Mapping

### OWASP LLM Top 10

| Category | REDMTZ Response |
|----------|----------------|
| LLM01: Prompt Injection | All inputs validated against destructive patterns before execution |
| LLM02: Insecure Output Handling | LLM outputs treated as untrusted until they pass `@govern` |
| LLM05: Supply Chain | Hash-pinned lockfile, GitHub Actions SHA-pinned, pip-audit on every push |
| LLM06: Sensitive Info Disclosure | Digest-only policy — raw inputs never stored in audit ledger |
| LLM07: Insecure Plugin Design | Every skill registered in Skill Registry; unregistered = BLOCK |
| LLM08: Excessive Agency | 8 hardcoded patterns + ActionGrammar limit agent blast radius |
| LLM09: Overreliance | GovernanceBlocked exception forces visible failure; Gate 4 requires human approval |

### NIST AI Risk Management Framework

| Function | REDMTZ Component |
|----------|-----------------|
| GOVERN | Policy templates, HITL gates, escalation chains |
| MAP | ActionGrammar — 12 verbs × 8 domains × risk matrix |
| MEASURE | risk_level in envelope, AEGIS score, pattern match counts |
| MANAGE | GovernanceBlocked + remediation hints = active risk management |

### EU AI Act

Seatbelt's signed envelope directly addresses **Article 12** (record-keeping and logging) for high-risk AI systems — automatic recording of events, tamper-evident chain, Ed25519 signatures, independently verifiable by any auditor.

For a full article-by-article mapping of Seatbelt and Cockpit capabilities to EU AI Act obligations (Art. 9–15), see [EU_AI_ACT_MAPPING.md](EU_AI_ACT_MAPPING.md).

---

## Supply Chain Security

We practice what we preach.

| Control | Status | Detail |
|---------|--------|--------|
| pip-audit on every push | ✅ | `.github/workflows/security-audit.yml` |
| Hash-pinned dependency lockfile | ✅ | `requirements.lock` via `uv pip compile --generate-hashes` |
| Binary-only installs | ✅ | `--only-binary :all:` — bypasses malicious `setup.py` execution |
| GitHub Actions SHA-pinned | ✅ | Immutable commit SHAs, not mutable version tags |
| Secret masking in CI/CD | ✅ | All API keys masked before any log step |
| 24-hour rule | Policy | Never install zero-day releases without community stress-testing |

**Why this matters**: The LiteLLM supply chain attack (March 2026) used a `.pth` file that executed code at Python startup — before your application ran a single line. Hash-pinned lockfiles catch version substitution at install time. Binary-only installs bypass `setup.py` entirely. SHA-pinned GitHub Actions can't be redirected to malicious commits.

---

## Setup

```bash
# Clone
git clone git@github.com:redmtz-t/governance-core.git
cd governance-core

# Virtual environment
python3 -m venv venv
source venv/bin/activate

# Install from hash-pinned lockfile
pip install --only-binary :all: -r requirements.lock

# Run the demo
python demo.py

# Run the full test suite
python -m pytest -v

# Start the CISO dashboard
python dashboard_server.py   # http://localhost:5001

# Start the MCP governance server (Cockpit)
python mcp_server.py
```

**For Cockpit** (requires local LLM):
```bash
# Install Ollama — https://ollama.ai
ollama pull mistral
python create_blacklist_table.py
python mcp_server.py
```

---

## FAQ

**Q: Does Seatbelt require an internet connection?**
No. Zero cloud. Zero LLM. Everything runs in your process. Your audit trail is yours.

**Q: Does Seatbelt use AI to make blocking decisions?**
No. Every decision is made by hardcoded regex patterns. Deterministic, auditable, explainable. No model can be hallucinated past or prompt-injected.

**Q: What if I need to run DROP TABLE legitimately?**
Use `policy="audit_mode"` for that session — everything is logged but nothing is blocked. Or call the underlying function directly, bypassing the decorator. Seatbelt is a safety layer, not a prison.

**Q: How do I verify an envelope's signature?**
```python
from envelope import CanonicalEnvelope
result = CanonicalEnvelope().verify(envelope)
print(result["valid"])       # True if hash + sig both verify
print(result["hash_valid"])  # True if not tampered with
```

**Q: What if the database goes down during a decision?**
SEDR (Sentinel Event Data Recorder) — a parallel JSONL append-only file — captures every decision as a failsafe. Two independent records per decision.

**Q: How does this scale to 1,000,000 agents?**
Seatbelt runs inside each agent's process — zero central bottleneck, scales horizontally to infinity. Cockpit adds a pool of LLM inference nodes for intent analysis. The envelope chain ties swarms together across machines. Distributed by design.

---

## Patent Status

**Provisional Patent Filed** — U.S. Provisional Application 63/994,312
**CIP (Continuation-in-Part)** — In preparation

**Claims include:**
- Canonical signed event envelope with hash-chain integrity (RDM-019)
- Neuro-symbolic deterministic gate engine (Cockpit 7-gate pipeline)
- Ed25519 signing on AI governance decisions — Patent Claim 28
- Progressive trust escalation via signature accumulation without schema modification
- `governance_mode` field enabling deterministic → neuro-symbolic upgrade path

**The moat**: Competitors can copy pattern matching (regex is not novel). They cannot copy the envelope format, the hash chain, the signing method, or the progressive trust model without infringing.

---

## Hardware

- **Dell Precision T5810** workstation
- **NVIDIA RTX 3090 FE** (24GB VRAM) — runs Mistral 7B locally via Ollama
- **Proxmox VE** hypervisor — **Ubuntu Server** VM (`sentinel-core-01`)

---

## Author

**Robert Benitez** — Founder & Sole Inventor
**REDMTZ** — Comanche, TX

*"AI agents should be provably safe, not just probably safe."*

---

## License

Proprietary. All rights reserved. Patent pending.

*REDMTZ — Genesis block. Signed envelopes. Deterministic governance from line one.*
