"""Norwegian public-holiday calendar and Jira-style duration parsing.

The 12 Norwegian "røde dager" are computed per year — the three fixed dates
(1 Jan, 1 May, 17 May, 25 Dec, 26 Dec) plus Easter-relative dates derived
via the Meeus/Jones/Butcher Gregorian Easter algorithm.

Christmas Eve (24 Dec) and New Year's Eve (31 Dec) aren't formal holidays
but many Norwegian workplaces close them — pass them in via
`extra_holidays=` if your team does too.
"""

from __future__ import annotations

import math
import re
from datetime import date, timedelta


# ---------------------------------------------------------------------------
# Easter + red days
# ---------------------------------------------------------------------------


def easter_sunday(year: int) -> date:
    """Meeus/Jones/Butcher algorithm for the Gregorian Easter date."""
    a = year % 19
    b, c = divmod(year, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = ((h + l - 7 * m + 114) % 31) + 1
    return date(year, month, day)


def norway_holidays(year: int) -> dict[date, str]:
    """Return {date: name} for all Norwegian public holidays in the year."""
    e = easter_sunday(year)
    return {
        date(year, 1, 1): "Nyttårsdag",
        e - timedelta(days=3): "Skjærtorsdag",
        e - timedelta(days=2): "Langfredag",
        e: "1. påskedag",
        e + timedelta(days=1): "2. påskedag",
        date(year, 5, 1): "Arbeidernes dag",
        date(year, 5, 17): "Grunnlovsdag",
        e + timedelta(days=39): "Kristi himmelfartsdag",
        e + timedelta(days=49): "1. pinsedag",
        e + timedelta(days=50): "2. pinsedag",
        date(year, 12, 25): "1. juledag",
        date(year, 12, 26): "2. juledag",
    }


# ---------------------------------------------------------------------------
# Working-day calendar
# ---------------------------------------------------------------------------


class Calendar:
    """Working-day calendar. Weekends + Norwegian red days + any extras."""

    def __init__(self, extra_holidays: list[date] | None = None):
        self._extra = set(extra_holidays or [])
        self._cache: dict[int, dict[date, str]] = {}

    def holidays(self, year: int) -> dict[date, str]:
        if year not in self._cache:
            self._cache[year] = norway_holidays(year)
        base = self._cache[year]
        if not any(d.year == year for d in self._extra):
            return base
        merged = dict(base)
        for d in self._extra:
            if d.year == year:
                merged.setdefault(d, "Extra holiday")
        return merged

    def is_workday(self, d: date) -> bool:
        if d.weekday() >= 5:  # Sat/Sun
            return False
        if d in self._extra:
            return False
        if d in self.holidays(d.year):
            return False
        return True

    def next_workday(self, d: date) -> date:
        while not self.is_workday(d):
            d += timedelta(days=1)
        return d

    def add_workdays(self, start: date, n: int) -> date:
        """Return the end date of a task starting on `start` taking n workdays.

        Convention: duration of 1 workday means start == end. Duration of 2
        means the task runs over 2 consecutive workdays, so end is the next
        workday after `start`. `start` itself must be a workday.
        """
        if n < 1:
            n = 1
        cur = self.next_workday(start)
        remaining = n - 1
        while remaining > 0:
            cur += timedelta(days=1)
            if self.is_workday(cur):
                remaining -= 1
        return cur


# ---------------------------------------------------------------------------
# Duration parsing
# ---------------------------------------------------------------------------
#
# Jira time-tracking format: "1w 2d 3h 30m". Default workweek: 5 days/week,
# 8 hours/day. Total hours are rounded UP to whole working days.

_DUR_PART = re.compile(r"(\d+(?:\.\d+)?)\s*([wdhm])", re.IGNORECASE)


def parse_estimate(s: str | None, default_days: float = 3.0) -> tuple[int, bool]:
    """Return (days, used_default). Days is always a positive int."""
    if not s:
        return (int(math.ceil(default_days)), True)
    total_hours = 0.0
    for match in _DUR_PART.finditer(s):
        val = float(match.group(1))
        unit = match.group(2).lower()
        if unit == "w":
            total_hours += val * 5 * 8
        elif unit == "d":
            total_hours += val * 8
        elif unit == "h":
            total_hours += val
        elif unit == "m":
            total_hours += val / 60.0
    if total_hours <= 0:
        return (int(math.ceil(default_days)), True)
    days = int(math.ceil(total_hours / 8.0))
    return (max(days, 1), False)


def parse_delay(s: str) -> int:
    """Parse '3d' / '1w' / '4h' style shifts into working days (>=1)."""
    days, _ = parse_estimate(s, default_days=1.0)
    return days
