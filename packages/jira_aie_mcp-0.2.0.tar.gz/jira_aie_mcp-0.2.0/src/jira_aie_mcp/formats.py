"""Three ways to render a computed plan: JSON, Markdown table, Mermaid gantt."""

from __future__ import annotations

from collections import defaultdict
from datetime import date

from .scheduler import Node


def to_plan_json(
    nodes: dict[str, Node],
    crit: list[str],
    project_start: date,
    warnings: list[str],
    project_key: str | None = None,
) -> dict:
    if not nodes:
        return {
            "project_start": project_start.isoformat(),
            "project_key": project_key,
            "issues": [],
            "warnings": warnings,
        }
    project_end = max(n.end for n in nodes.values() if n.end)
    crit_set = set(crit)  # for O(1) membership on each issue row
    return {
        "project_start": project_start.isoformat(),
        "project_end": project_end.isoformat(),
        "project_key": project_key,
        # Chain-ordered root → leaf. See scheduler.critical_path docstring.
        "critical_path": list(crit),
        "issues": [
            {
                "key": n.key,
                "summary": n.summary,
                "issue_type": n.issue_type,
                "status": n.status,
                "workstream": n.workstream,
                "duration_days": n.duration_days,
                "start": n.start.isoformat() if n.start else None,
                "end": n.end.isoformat() if n.end else None,
                "blocked_by": n.preds,
                "blocks": n.succs,
                "on_critical_path": n.key in crit_set,
                "pinned": n.pinned,
                "delayed_by_days": n.delayed_by,
                "used_default_estimate": n.used_default_estimate,
            }
            for n in sorted(nodes.values(), key=lambda x: (x.start or date.max, x.key))
        ],
        "warnings": warnings,
    }


def to_markdown(plan: dict) -> str:
    pk = plan.get("project_key")
    title = f"# {pk} schedule" if pk else "# Schedule"
    lines = [
        title,
        "",
        f"- **Start:** {plan['project_start']}",
        f"- **End:** {plan.get('project_end', '—')}",
        f"- **Critical path:** {', '.join(plan['critical_path']) or '—'}",
        "",
        "| Key | Summary | Type | Start | End | Days | Deps | ★ |",
        "| --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for i in plan["issues"]:
        crit = "★" if i["on_critical_path"] else ""
        pin = " 📌" if i["pinned"] else ""
        dly = f" (+{i['delayed_by_days']}d)" if i["delayed_by_days"] else ""
        deps = ", ".join(i["blocked_by"]) if i["blocked_by"] else "—"
        lines.append(
            f"| {i['key']} | {i['summary']} | {i['issue_type']} | "
            f"{i['start']}{pin}{dly} | {i['end']} | {i['duration_days']} | {deps} | {crit} |"
        )
    if plan["warnings"]:
        lines.append("")
        lines.append("## Warnings")
        lines.append("")
        for w in plan["warnings"]:
            lines.append(f"- {w}")
    return "\n".join(lines)


def to_mermaid(plan: dict) -> str:
    pk = plan.get("project_key")
    title = f"{pk} schedule" if pk else "Schedule"
    lines = [
        "```mermaid",
        "gantt",
        f"    title {title} (from {plan['project_start']})",
        "    dateFormat YYYY-MM-DD",
        "    axisFormat %d %b",
        "    excludes weekends",
    ]
    by_ws: dict[str, list[dict]] = defaultdict(list)
    for i in plan["issues"]:
        ws = i.get("workstream") or "Unassigned"
        by_ws[ws].append(i)
    for ws, items in by_ws.items():
        lines.append(f"    section {ws}")
        for i in items:
            tag = "crit, " if i["on_critical_path"] else ""
            if i["blocked_by"]:
                after = f"after {' '.join(i['blocked_by'])}"
                lines.append(
                    f"    {_mmd_label(i)} :{tag}{i['key']}, {after}, {i['duration_days']}d"
                )
            else:
                lines.append(
                    f"    {_mmd_label(i)} :{tag}{i['key']}, {i['start']}, {i['duration_days']}d"
                )
    lines.append("```")
    return "\n".join(lines)


def _mmd_label(issue: dict) -> str:
    summary = issue["summary"].replace(":", "·").replace('"', "'")
    if len(summary) > 40:
        summary = summary[:37] + "…"
    return f"{issue['key']}: {summary}"
