"""Environment-variable-based configuration.

All settings live in the MCP client's server definition (Cowork/Claude
Desktop config) as env vars — no config file on disk. Example:

    "env": {
      "JIRA_BASE_URL":  "https://your-tenant.atlassian.net",
      "JIRA_EMAIL":     "you@example.com",
      "JIRA_API_TOKEN": "..."
    }

This keeps the token scoped to the MCP process — the sandbox the server
runs in never needs filesystem access to credentials.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


class ConfigError(RuntimeError):
    """Raised when required env vars are missing or malformed."""


@dataclass(frozen=True)
class Config:
    base_url: str
    email: str
    api_token: str
    default_project_key: str | None = None
    workstream_field_id: str | None = None

    @classmethod
    def from_env(cls) -> "Config":
        base_url = os.environ.get("JIRA_BASE_URL", "").rstrip("/")
        email = os.environ.get("JIRA_EMAIL", "")
        token = os.environ.get("JIRA_API_TOKEN", "")
        project = os.environ.get("JIRA_DEFAULT_PROJECT_KEY") or None
        workstream_field = os.environ.get("JIRA_WORKSTREAM_FIELD_ID") or None
        missing = []
        if not base_url:
            missing.append("JIRA_BASE_URL")
        if not email:
            missing.append("JIRA_EMAIL")
        if not token:
            missing.append("JIRA_API_TOKEN")
        if missing:
            raise ConfigError(
                "Missing required environment variable(s): "
                + ", ".join(missing)
                + ". Set them in the MCP client's server config."
            )
        return cls(
            base_url=base_url,
            email=email,
            api_token=token,
            default_project_key=project,
            workstream_field_id=workstream_field,
        )
