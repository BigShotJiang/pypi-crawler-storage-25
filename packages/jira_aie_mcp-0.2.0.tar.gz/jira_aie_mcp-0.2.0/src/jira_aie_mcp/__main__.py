"""Entry point: `python -m jira_aie_mcp` or the `jira-aie-mcp` console script.

Starts the FastMCP server over stdio, which is what MCP clients (Cowork,
Claude Desktop, Claude Code) expect. Configuration is read from environment
variables — see README.md for the full list.
"""

from __future__ import annotations

import sys

from .server import mcp


def main() -> int:
    # FastMCP.run() defaults to stdio transport. Host process (Cowork, Claude
    # Desktop, etc.) owns stdin/stdout; we must never write prose to stdout
    # outside the JSON-RPC frames. All our tool bodies return values; logging
    # goes to stderr.
    try:
        mcp.run()
    except KeyboardInterrupt:
        return 130
    return 0


if __name__ == "__main__":
    sys.exit(main())
