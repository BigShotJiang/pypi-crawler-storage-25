"""Atlassian Document Format (ADF) helpers.

Three accepted description formats:

1. **String** → treated as Markdown and converted to ADF. Small subset:
   headings, paragraphs, bullet/ordered lists, code fences, blockquotes,
   rules, simple tables, and inline marks (strong / em / code / link).

2. **Block list (DSL)** → each entry is a dict describing one block. This
   is the path agents use when they want panels, status lozenges, date
   chips, expand blocks, or task lists — things the Markdown converter
   cannot express.

3. **Full ADF** → already a `{"type": "doc", "version": 1, "content": [...]}` dict.
   Used when the caller composed ADF themselves (e.g., round-tripped from
   another issue via `jira_get_issue_raw`).

Block DSL cheat sheet (one key per block)::

    {"h": 2, "text": "Heading"}                            # heading 1-6
    {"p": "paragraph"} or {"p": [{"text": "bold", "marks": ["strong"]}]}
    {"ul": ["item 1", "item 2", {"p": "rich"}]}            # bullet list
    {"ol": ["first", "second"]}                            # numbered list
    {"code": "print('x')", "lang": "python"}               # code block
    {"quote": "text"}                                      # blockquote
    {"rule": true}                                         # horizontal rule
    {"panel": "info", "content": [...]}                    # info|note|success|warning|error panel
    {"status": "In progress", "color": "yellow"}           # status lozenge (wrapped in paragraph)
    {"date": "2026-04-20"}                                 # date chip (wrapped in paragraph)
    {"expand": {"title": "Details", "content": [...]}}     # collapsible
    {"tasks": [{"text": "…", "done": true}, …]}            # task list
    {"table": {"headers": ["A","B"], "rows": [["x","y"]]}} # table
"""

from __future__ import annotations

import datetime as _dt
import json
import re
from typing import Any


class ADFError(ValueError):
    """Raised when a DSL block is malformed."""


PANEL_VARIANTS = {"info", "note", "success", "warning", "error"}
STATUS_COLORS = {"neutral", "purple", "blue", "red", "yellow", "green"}


# ---------------------------------------------------------------------------
# Inline nodes
# ---------------------------------------------------------------------------


def _inline_from(value: Any) -> list[dict]:
    """Accept a string or a list of inline specs; return ADF inline nodes."""
    if isinstance(value, str):
        return [{"type": "text", "text": value}] if value else []
    out: list[dict] = []
    for item in value:
        if isinstance(item, str):
            if item:
                out.append({"type": "text", "text": item})
        elif isinstance(item, dict):
            out.append(_inline_dict(item))
        else:
            raise ADFError(f"Cannot convert to inline ADF: {item!r}")
    return out


def _inline_dict(spec: dict) -> dict:
    """Convert one inline-spec dict (text/marks, mention, status, date, hard_break) to ADF."""
    if "hard_break" in spec:
        return {"type": "hardBreak"}
    if "mention" in spec:
        return {
            "type": "mention",
            "attrs": {"id": spec["mention"], "text": spec.get("text", "")},
        }
    if "status" in spec:
        color = spec.get("color", "neutral")
        if color not in STATUS_COLORS:
            raise ADFError(f"Unknown status color {color!r}; allowed: {sorted(STATUS_COLORS)}")
        return {
            "type": "status",
            "attrs": {"text": spec["status"], "color": color, "style": ""},
        }
    if "date" in spec:
        val = spec["date"]
        if isinstance(val, str):
            ts = int(_dt.datetime.fromisoformat(val).timestamp() * 1000)
        else:
            ts = int(val)
        return {"type": "date", "attrs": {"timestamp": str(ts)}}
    if "emoji" in spec:
        return {
            "type": "emoji",
            "attrs": {"shortName": spec["emoji"], "text": spec.get("text", spec["emoji"])},
        }
    if "text" in spec:
        node: dict[str, Any] = {"type": "text", "text": spec["text"]}
        marks = spec.get("marks")
        if marks:
            node["marks"] = [_inline_mark(m) for m in marks]
        if "link" in spec:
            node.setdefault("marks", []).append({"type": "link", "attrs": {"href": spec["link"]}})
        return node
    raise ADFError(f"Unknown inline spec: {spec!r}")


def _inline_mark(m: Any) -> dict:
    if isinstance(m, str):
        # shorthand: "strong", "em", "code", "strike", "underline"
        return {"type": m}
    if isinstance(m, dict):
        return m
    raise ADFError(f"Unknown mark: {m!r}")


# ---------------------------------------------------------------------------
# Block nodes
# ---------------------------------------------------------------------------


def _blocks_from(value: Any) -> list[dict]:
    """Accept block-list DSL, Markdown string, or already-built ADF; return list of ADF blocks.

    A string whose first non-whitespace character is `[` or `{` is probed
    as JSON first — some MCP clients stringify structured arguments, and
    without this check a JSON-serialized block-list DSL would be treated
    as literal Markdown and rendered as one long paragraph of raw JSON.
    If JSON decoding fails the string is treated as Markdown, so ordinary
    Markdown that happens to start with `[link](...)` still works.
    """
    if value is None:
        return []
    if isinstance(value, str):
        stripped = value.lstrip()
        if stripped.startswith("[") or stripped.startswith("{"):
            try:
                parsed = json.loads(value)
            except json.JSONDecodeError:
                parsed = None
            if parsed is not None:
                return _blocks_from(parsed)
        return markdown_to_adf_blocks(value)
    if isinstance(value, dict) and value.get("type") == "doc":
        return list(value.get("content", []))
    if isinstance(value, dict):
        # A bare dict is treated as a single DSL block (e.g. `{"p": "hi"}`).
        return _block_to_adf(value)
    if not isinstance(value, list):
        raise ADFError(f"Description must be string, list, or ADF doc, got {type(value).__name__}")
    out: list[dict] = []
    for block in value:
        out.extend(_block_to_adf(block))
    return out


def _block_to_adf(block: dict) -> list[dict]:  # noqa: C901 — flat keyword dispatch
    """One DSL block -> one or more ADF blocks."""
    if "h" in block:
        level = int(block["h"])
        if not 1 <= level <= 6:
            raise ADFError(f"Heading level must be 1-6, got {level}")
        return [
            {
                "type": "heading",
                "attrs": {"level": level},
                "content": _inline_from(block.get("text", "")),
            }
        ]
    if "p" in block:
        return [{"type": "paragraph", "content": _inline_from(block["p"])}]
    if "ul" in block:
        return [_list_node("bulletList", block["ul"])]
    if "ol" in block:
        return [_list_node("orderedList", block["ol"])]
    if "code" in block:
        attrs: dict[str, Any] = {}
        if "lang" in block:
            attrs["language"] = block["lang"]
        return [
            {
                "type": "codeBlock",
                "attrs": attrs,
                "content": [{"type": "text", "text": block["code"]}],
            }
        ]
    if "quote" in block:
        content = block["quote"]
        if isinstance(content, str):
            inner = [{"type": "paragraph", "content": _inline_from(content)}]
        else:
            inner = _blocks_from(content)
        return [{"type": "blockquote", "content": inner}]
    if block.get("rule"):
        return [{"type": "rule"}]
    if "panel" in block:
        variant = block["panel"]
        if variant not in PANEL_VARIANTS:
            raise ADFError(f"Panel variant {variant!r} not in {sorted(PANEL_VARIANTS)}")
        content = block.get("content", [])
        if isinstance(content, str):
            inner = [{"type": "paragraph", "content": _inline_from(content)}]
        else:
            inner = _blocks_from(content)
        return [
            {
                "type": "panel",
                "attrs": {"panelType": variant},
                "content": inner or [{"type": "paragraph", "content": []}],
            }
        ]
    if "status" in block:
        return [
            {
                "type": "paragraph",
                "content": [
                    _inline_dict({"status": block["status"], "color": block.get("color", "neutral")})
                ],
            }
        ]
    if "date" in block:
        return [{"type": "paragraph", "content": [_inline_dict({"date": block["date"]})]}]
    if "expand" in block:
        spec = block["expand"]
        title = spec.get("title", "")
        inner = _blocks_from(spec.get("content", []))
        return [
            {
                "type": "expand",
                "attrs": {"title": title},
                "content": inner or [{"type": "paragraph", "content": []}],
            }
        ]
    if "tasks" in block:
        items = []
        for i, t in enumerate(block["tasks"]):
            text = t["text"] if isinstance(t, dict) else str(t)
            done = bool(t.get("done")) if isinstance(t, dict) else False
            items.append(
                {
                    "type": "taskItem",
                    "attrs": {"localId": f"task-{i}", "state": "DONE" if done else "TODO"},
                    "content": _inline_from(text),
                }
            )
        return [
            {
                "type": "taskList",
                "attrs": {"localId": block.get("localId", "tasklist-0")},
                "content": items,
            }
        ]
    if "table" in block:
        return [_table_node(block["table"])]
    if "raw" in block or "mediaSingle" in block:
        return [block.get("raw") or block["mediaSingle"]]
    raise ADFError(f"Unknown block type: {list(block.keys())}")


def _list_node(kind: str, items: list[Any]) -> dict:
    children = []
    for item in items:
        if isinstance(item, str):
            inner = [{"type": "paragraph", "content": _inline_from(item)}]
        elif isinstance(item, dict) and ("p" in item or "h" in item or "ul" in item or "ol" in item):
            inner = _block_to_adf(item)
        elif isinstance(item, list):
            inner = _blocks_from(item)
        else:
            inner = [{"type": "paragraph", "content": _inline_from(item)}]
        children.append({"type": "listItem", "content": inner})
    return {"type": kind, "content": children}


def _table_node(spec: dict) -> dict:
    headers = spec.get("headers", [])
    rows = spec.get("rows", [])
    table_rows: list[dict] = []
    if headers:
        table_rows.append(
            {
                "type": "tableRow",
                "content": [
                    {
                        "type": "tableHeader",
                        "attrs": {},
                        "content": [{"type": "paragraph", "content": _inline_from(h)}],
                    }
                    for h in headers
                ],
            }
        )
    for row in rows:
        table_rows.append(
            {
                "type": "tableRow",
                "content": [
                    {
                        "type": "tableCell",
                        "attrs": {},
                        "content": (
                            _blocks_from(cell)
                            if isinstance(cell, list)
                            else [{"type": "paragraph", "content": _inline_from(cell)}]
                        ),
                    }
                    for cell in row
                ],
            }
        )
    return {
        "type": "table",
        "attrs": {"isNumberColumnEnabled": False, "layout": "default"},
        "content": table_rows,
    }


def wrap_doc(blocks: list[dict]) -> dict:
    """Wrap a list of ADF blocks in a `doc` root node."""
    return {
        "type": "doc",
        "version": 1,
        "content": blocks or [{"type": "paragraph", "content": []}],
    }


def to_adf_doc(description: Any) -> dict:
    """Public entry: convert any accepted description form into a root ADF doc."""
    return wrap_doc(_blocks_from(description))


# ---------------------------------------------------------------------------
# Tiny Markdown → ADF fallback
# ---------------------------------------------------------------------------

_MD_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")
_MD_UL = re.compile(r"^[-*]\s+(.*)$")
_MD_OL = re.compile(r"^\d+\.\s+(.*)$")
_MD_FENCE = re.compile(r"^```(\w*)\s*$")
_MD_QUOTE = re.compile(r"^>\s?(.*)$")
_MD_RULE = re.compile(r"^(---+|\*\*\*+)\s*$")
_MD_TABLE_ROW = re.compile(r"^\|(.+)\|\s*$")

_INLINE_CODE = re.compile(r"`([^`]+)`")
_INLINE_STRONG = re.compile(r"\*\*([^*]+)\*\*")
_INLINE_EM = re.compile(r"(?<![*_])[*_]([^*_]+)[*_](?![*_])")
_INLINE_LINK = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")


def markdown_to_adf_blocks(md: str) -> list[dict]:  # noqa: C901 — single-pass line walker
    lines = md.splitlines()
    out: list[dict] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        m = _MD_FENCE.match(line)
        if m:
            lang = m.group(1)
            j = i + 1
            buf: list[str] = []
            while j < len(lines) and not _MD_FENCE.match(lines[j]):
                buf.append(lines[j])
                j += 1
            out.extend(
                _block_to_adf(
                    {"code": "\n".join(buf), "lang": lang} if lang else {"code": "\n".join(buf)}
                )
            )
            i = j + 1
            continue
        m = _MD_HEADING.match(line)
        if m:
            out.extend(_block_to_adf({"h": len(m.group(1)), "text": _md_inline(m.group(2).strip())}))
            i += 1
            continue
        if _MD_RULE.match(line):
            out.append({"type": "rule"})
            i += 1
            continue
        if _MD_QUOTE.match(line):
            qbuf: list[str] = []
            while i < len(lines) and _MD_QUOTE.match(lines[i]):
                qbuf.append(_MD_QUOTE.match(lines[i]).group(1))
                i += 1
            out.extend(_block_to_adf({"quote": "\n".join(qbuf)}))
            continue
        if _MD_UL.match(line):
            items: list[str] = []
            while i < len(lines) and _MD_UL.match(lines[i]):
                items.append(_MD_UL.match(lines[i]).group(1))
                i += 1
            out.append(_list_node("bulletList", [_md_inline_list(x) for x in items]))
            continue
        if _MD_OL.match(line):
            oitems: list[str] = []
            while i < len(lines) and _MD_OL.match(lines[i]):
                oitems.append(_MD_OL.match(lines[i]).group(1))
                i += 1
            out.append(_list_node("orderedList", [_md_inline_list(x) for x in oitems]))
            continue
        if _MD_TABLE_ROW.match(line):
            rows: list[list[str]] = []
            while i < len(lines) and _MD_TABLE_ROW.match(lines[i]):
                parts = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                rows.append(parts)
                i += 1
            if len(rows) >= 2 and all(re.match(r"^:?-+:?$", c) for c in rows[1]):
                headers = rows[0]
                body = rows[2:]
            else:
                headers = []
                body = rows
            out.append(_table_node({"headers": headers, "rows": body}))
            continue
        # Paragraph: gather until blank line
        pbuf = [line]
        i += 1
        while i < len(lines) and lines[i].strip() and not (
            _MD_HEADING.match(lines[i])
            or _MD_UL.match(lines[i])
            or _MD_OL.match(lines[i])
            or _MD_FENCE.match(lines[i])
            or _MD_QUOTE.match(lines[i])
            or _MD_RULE.match(lines[i])
            or _MD_TABLE_ROW.match(lines[i])
        ):
            pbuf.append(lines[i])
            i += 1
        out.extend(_block_to_adf({"p": _md_inline(" ".join(pbuf))}))
    return out


def _md_inline(text: str) -> list[dict]:
    """Convert Markdown inline syntax to a list of text nodes with marks."""
    tokens: list[Any] = [text]

    def _apply(pattern: re.Pattern, handler):
        nonlocal tokens
        new: list[Any] = []
        for tok in tokens:
            if isinstance(tok, dict):
                new.append(tok)
                continue
            s = tok
            last = 0
            for m in pattern.finditer(s):
                if m.start() > last:
                    new.append(s[last : m.start()])
                new.append(handler(m))
                last = m.end()
            if last < len(s):
                new.append(s[last:])
        tokens = [t for t in new if t != ""]

    _apply(_INLINE_LINK, lambda m: {"text": m.group(1), "link": m.group(2)})
    _apply(_INLINE_CODE, lambda m: {"text": m.group(1), "marks": ["code"]})
    _apply(_INLINE_STRONG, lambda m: {"text": m.group(1), "marks": ["strong"]})
    _apply(_INLINE_EM, lambda m: {"text": m.group(1), "marks": ["em"]})

    out: list[dict] = []
    for t in tokens:
        if isinstance(t, str):
            if t:
                out.append({"type": "text", "text": t})
        else:
            out.append(_inline_dict(t))
    return out


def _md_inline_list(text: str) -> dict:
    """For use as a DSL list item — return a {p: [...]} block."""
    return {"p": _md_inline(text)}
