"""FastMCP server definition.

Exposes rich-ADF issue creation and working-day scheduling as MCP tools.
Designed to complement `mcp-atlassian` — use that for search, transitions,
comments, watchers, and anything else it covers; use this server for:

- `jira_create_issue` / `jira_update_issue` — full ADF surface (panels,
  status lozenges, date chips, expand blocks, task lists, tables).
- `jira_link_issues` — semantic shortcuts that pick the right
  inward/outward direction for Blocks, Relates, Duplicates, Clones, Causes.
- `jira_batch_ops` — mixed create/update/link in one round-trip.
- `jira_get_issue_raw` — full REST response, including raw ADF description
  (useful for round-tripping through the DSL).
- `schedule_compute` / `schedule_holidays` — working-day gantt on the
  Norwegian red-day calendar; optional duedate writeback.
"""

from __future__ import annotations

import json
from datetime import date, datetime
from typing import Any, Literal

from fastmcp import FastMCP

from .adf import ADFError
from .client import GADGET_SHORTCUTS, JiraAPIError, JiraClient
from .config import ConfigError
from .formats import to_markdown, to_mermaid, to_plan_json
from .holidays import Calendar, parse_delay
from .scheduler import (
    SchedulingError,
    build_graph,
    compute_schedule,
    critical_path,
    scheduler_fields,
)


mcp = FastMCP("jira-aie")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _errordict(exc: Exception) -> dict:
    """Convert any raised error into a flat result dict.

    We return structured errors rather than raising because FastMCP surfaces
    raised exceptions as tool errors — not always a useful shape for the
    model to reason about. A dict with `error` key keeps the response
    inspectable.
    """
    if isinstance(exc, JiraAPIError):
        return exc.to_dict()
    if isinstance(exc, (ADFError, SchedulingError, ConfigError, ValueError)):
        return {"error": type(exc).__name__, "detail": str(exc)}
    return {"error": "UnexpectedError", "detail": str(exc)}


def _parse_iso_date(s: str) -> date:
    """Accept YYYY-MM-DD or a full ISO datetime; return date."""
    if "T" in s:
        return datetime.fromisoformat(s).date()
    return date.fromisoformat(s)


# ---------------------------------------------------------------------------
# String→JSON coercion at the tool boundary
# ---------------------------------------------------------------------------
#
# Some MCP clients serialize structured arguments as JSON strings when a
# tool's schema lacks a concrete JSON type (e.g. `Any`, `dict[str, Any] | None`
# — pydantic/FastMCP emit a schema without `type: object` for those, and
# some clients fall back to stringifying). The fix is to accept the string
# form at the seam and decode it here, so the rest of the pipeline never
# has to know the difference.


def _maybe_json(val: Any) -> Any:
    """If `val` is a string that parses as JSON, return the decoded value;
    otherwise return `val` unchanged. Never raises.

    This is the workhorse coercion: try JSON first, fall through on any
    decoding failure. The caller then type-checks the result for the
    shape it actually wants.
    """
    if not isinstance(val, str):
        return val
    try:
        return json.loads(val)
    except (json.JSONDecodeError, ValueError):
        return val


def _coerce_obj(val: Any, name: str) -> dict[str, Any] | None:
    """Accept a dict, None, or a JSON-encoded object string."""
    decoded = _maybe_json(val)
    if decoded is None or isinstance(decoded, dict):
        return decoded
    raise ValueError(
        f"{name} must be an object or a JSON-object string; got {type(decoded).__name__}"
    )


def _coerce_arr(val: Any, name: str, *, allow_csv: bool = False) -> list[Any] | None:
    """Accept a list, None, or a JSON-encoded array string.

    When `allow_csv=True`, a plain comma-separated string is also accepted
    (e.g. `"summary,description"` → `["summary", "description"]`) —
    useful for list-of-fieldname params.
    """
    decoded = _maybe_json(val)
    if decoded is None or isinstance(decoded, list):
        return decoded
    if allow_csv and isinstance(decoded, str):
        return [s.strip() for s in decoded.split(",") if s.strip()]
    raise ValueError(
        f"{name} must be a list or a JSON-array string; got {type(decoded).__name__}"
    )


# ---------------------------------------------------------------------------
# Issue CRUD
# ---------------------------------------------------------------------------


@mcp.tool
def jira_create_issue(
    summary: str,
    issue_type: str,
    project_key: str | None = None,
    labels: list[str] | str | None = None,
    priority: str | None = None,
    assignee_id: str | None = None,
    fields: dict[str, Any] | str | None = None,
    epic_key: str | None = None,
    description: Any = None,
) -> dict:
    """Create a Jira issue with an optional rich-ADF description.

    `description` may be:
      - a Markdown string (converted via the built-in converter),
      - a block-list DSL (e.g. `[{"h": 2, "text": "..."}, {"panel": "info", ...}]`),
      - or a full ADF doc dict.

    `fields` carries custom fields as-is (e.g. `{"customfield_10751": {"value": "S2"}}`).
    Omit `project_key` to use the MCP's default (`AIE` unless overridden via
    `JIRA_DEFAULT_PROJECT_KEY`).

    `fields` / `labels` / `description` may arrive as JSON strings from clients
    that stringify structured arguments — they're decoded transparently.
    """
    try:
        fields = _coerce_obj(fields, "fields")
        labels = _coerce_arr(labels, "labels", allow_csv=True)
    except ValueError as e:
        return _errordict(e)
    payload = {
        "summary": summary,
        "issue_type": issue_type,
        "project_key": project_key,
        "labels": labels,
        "priority": priority,
        "assignee_id": assignee_id,
        "fields": fields,
        "epic_key": epic_key,
        "description": description,
    }
    # Drop None entries so _build_fields doesn't overwrite with None
    payload = {k: v for k, v in payload.items() if v is not None}
    try:
        with JiraClient.from_env() as jc:
            return jc.create_issue(payload)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


@mcp.tool
def jira_update_issue(
    issue_key: str,
    summary: str | None = None,
    labels: list[str] | str | None = None,
    fields: dict[str, Any] | str | None = None,
    description: Any = None,
) -> dict:
    """Update fields on an existing Jira issue.

    Pass any combination of `summary`, `labels`, `fields`, or `description`.
    `description` accepts the same three forms as `jira_create_issue`.

    `fields` / `labels` / `description` may arrive as JSON strings from
    clients that stringify structured arguments — they're decoded
    transparently.
    """
    try:
        fields = _coerce_obj(fields, "fields")
        labels = _coerce_arr(labels, "labels", allow_csv=True)
    except ValueError as e:
        return _errordict(e)
    payload: dict[str, Any] = {"issue_key": issue_key}
    if summary is not None:
        payload["summary"] = summary
    if labels is not None:
        payload["labels"] = labels
    if fields is not None:
        payload["fields"] = fields
    if description is not None:
        payload["description"] = description
    try:
        with JiraClient.from_env() as jc:
            return jc.update_issue(payload)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


@mcp.tool
def jira_get_issue_raw(
    issue_key: str,
    fields: list[str] | str | None = None,
) -> dict:
    """Fetch the raw Jira issue (including ADF description). Use sparingly —
    `mcp-atlassian`'s get_issue is fine for most reads; this is for when
    you need the untouched ADF body or a custom field the other tool strips.

    `fields` accepts either a list of names, a JSON-array string, or a
    comma-separated string.
    """
    try:
        fields_list = _coerce_arr(fields, "fields", allow_csv=True)
    except ValueError as e:
        return _errordict(e)
    try:
        with JiraClient.from_env() as jc:
            return jc.get_issue(issue_key, fields=fields_list)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


# ---------------------------------------------------------------------------
# Links
# ---------------------------------------------------------------------------


@mcp.tool
def jira_link_issues(
    type: str,
    outwardIssue: str | None = None,
    inwardIssue: str | None = None,
    blocker: str | None = None,
    blockee: str | None = None,
    a: str | None = None,
    b: str | None = None,
    duplicate: str | None = None,
    canonical: str | None = None,
    clone: str | None = None,
    original: str | None = None,
    cause: str | None = None,
    incident: str | None = None,
) -> dict:
    """Create an issue link. Accepts either explicit direction or a semantic shortcut.

    Semantic shortcuts by link type. For all active-verb types, the
    subject maps to `inwardIssue` (its page shows the active verb) and
    the object to `outwardIssue` (its page shows the passive):

      - `Blocks` → `blocker` (shows "blocks [blockee]"),
                    `blockee` (shows "is blocked by [blocker]")
      - `Duplicate` / `Duplicates` → `duplicate` (shows "duplicates
                    [canonical]"), `canonical` (shows "is duplicated
                    by [duplicate]")
      - `Clones` / `Cloners` → `clone` (shows "clones [original]"),
                    `original` (shows "is cloned by [clone]")
      - `Causes` / `Problem/Incident` → `cause` (shows "causes
                    [incident]"), `incident` (shows "is caused by
                    [cause]")
      - `Relates` → `a`, `b` (symmetric)

    Explicit form: pass `outwardIssue` and `inwardIssue` directly.
    """
    payload: dict[str, Any] = {"type": type}
    for name, val in (
        ("outwardIssue", outwardIssue),
        ("inwardIssue", inwardIssue),
        ("blocker", blocker),
        ("blockee", blockee),
        ("a", a),
        ("b", b),
        ("duplicate", duplicate),
        ("canonical", canonical),
        ("clone", clone),
        ("original", original),
        ("cause", cause),
        ("incident", incident),
    ):
        if val is not None:
            payload[name] = val
    try:
        with JiraClient.from_env() as jc:
            return jc.create_link(payload)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


# ---------------------------------------------------------------------------
# Batch
# ---------------------------------------------------------------------------


@mcp.tool
def jira_batch_ops(ops: list[dict[str, Any]] | str) -> list[dict]:
    """Run a mixed array of create/update/link operations in one call.

    Each entry is `{op: "create"|"update"|"link", ...}` with the same fields
    the individual tools accept (minus the wrapper). A failing entry returns
    a result record with `error`/`status`/`detail` — the batch does not halt.

    `ops` may also be passed as a JSON-array string (e.g. from clients that
    stringify structured arguments); it's decoded transparently.

    Example:
      [
        {"op": "create", "summary": "Setup", "issue_type": "Task",
         "epic_key": "AIE-5",
         "fields": {"timetracking": {"originalEstimate": "2d"},
                    "customfield_10742": {"value": "Platform"}}},
        {"op": "link", "type": "Blocks", "blocker": "AIE-6", "blockee": "AIE-7"}
      ]
    """
    try:
        ops_list = _coerce_arr(ops, "ops")
    except ValueError as e:
        return [_errordict(e)]
    if ops_list is None:
        return []
    try:
        with JiraClient.from_env() as jc:
            return jc.batch(ops_list)
    except Exception as e:  # noqa: BLE001
        return [_errordict(e)]


# ---------------------------------------------------------------------------
# Scheduler
# ---------------------------------------------------------------------------


@mcp.tool
def schedule_compute(
    jql: str,
    start: str | None = None,
    default_estimate_days: float = 3.0,
    format: Literal["json", "markdown", "mermaid"] = "json",
    pins: dict[str, str] | str | None = None,
    delays: dict[str, str] | str | None = None,
    extra_holidays: list[str] | str | None = None,
    write_duedate: bool = False,
) -> dict:
    """Forward-pass working-day scheduler for in-scope Jira issues.

    - `jql` scopes the graph (typically one Epic's children or a fixVersion).
    - `start` is ISO date; defaults to next workday from today.
    - `default_estimate_days` is used when an issue has no Original Estimate.
    - `pins = {"AIE-12": "2026-05-10"}` forces a start date.
    - `delays = {"AIE-7": "3d"}` shifts a start by N workdays (Jira duration syntax).
    - `extra_holidays` is a list of ISO dates to treat as non-working.
    - `write_duedate=True` persists computed end dates to each issue's `duedate` field.

    `pins` / `delays` / `extra_holidays` may arrive as JSON strings from
    clients that stringify structured arguments; they're decoded
    transparently.

    Returns the JSON plan dict. If `format` is markdown or mermaid, the
    response also carries a `rendered` string with that representation.
    """
    try:
        pins = _coerce_obj(pins, "pins")
        delays = _coerce_obj(delays, "delays")
        extra_holidays = _coerce_arr(extra_holidays, "extra_holidays", allow_csv=True)
    except ValueError as e:
        return _errordict(e)
    try:
        extras = [date.fromisoformat(x) for x in (extra_holidays or [])]
    except ValueError as e:
        return {"error": "BadHolidayDate", "detail": str(e)}

    calendar = Calendar(extra_holidays=extras)

    try:
        start_date = (
            _parse_iso_date(start) if start else calendar.next_workday(date.today())
        )
    except ValueError as e:
        return {"error": "BadStartDate", "detail": str(e)}
    project_start = calendar.next_workday(start_date)

    pins_parsed: dict[str, date] = {}
    try:
        for k, v in (pins or {}).items():
            pins_parsed[k] = _parse_iso_date(v)
    except ValueError as e:
        return {"error": "BadPinDate", "detail": str(e)}

    delays_parsed: dict[str, int] = {
        k: parse_delay(v) for k, v in (delays or {}).items()
    }

    try:
        with JiraClient.from_env() as jc:
            ws_field = jc.config.workstream_field_id
            issues = jc.search_jql(jql, scheduler_fields(ws_field))
            in_scope = {i["key"] for i in issues}
            nodes = build_graph(issues, default_estimate_days, in_scope, ws_field)
            compute_schedule(nodes, project_start, calendar, pins_parsed, delays_parsed)
            crit = critical_path(nodes)

            warnings: list[str] = []
            for n in nodes.values():
                if n.used_default_estimate:
                    warnings.append(
                        f"{n.key} has no originalEstimate; used default {n.duration_days}d"
                    )
            for k, pin_date in pins_parsed.items():
                if k not in nodes:
                    warnings.append(f"pin {k} not in scope of JQL")
                    continue
                for p in nodes[k].preds:
                    pend = nodes[p].end
                    if pend and pend >= pin_date:
                        warnings.append(
                            f"{k} pinned to {pin_date.isoformat()} but predecessor {p} ends {pend.isoformat()}"
                        )

            project_key = (
                issues[0]["key"].split("-", 1)[0]
                if issues and "-" in issues[0]["key"]
                else None
            )
            plan = to_plan_json(nodes, crit, project_start, warnings, project_key)

            if write_duedate:
                updates = ((n.key, n.end.isoformat()) for n in nodes.values() if n.end)
                plan["writeback"] = jc.iter_duedate_results(updates)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)

    if format == "markdown":
        plan["rendered"] = to_markdown(plan)
    elif format == "mermaid":
        plan["rendered"] = to_mermaid(plan)
    # JSON format leaves `rendered` unset — the plan dict itself is the payload.
    return plan


@mcp.tool
def schedule_holidays(
    year: int,
    extra_holidays: list[str] | None = None,
) -> list[dict]:
    """Return the Norwegian public-holiday calendar for a given year.

    Useful for verifying the Easter-derived dates before trusting the
    scheduler output. `extra_holidays` (ISO dates) are appended.
    """
    try:
        extras = [date.fromisoformat(x) for x in (extra_holidays or [])]
    except ValueError as e:
        return [{"error": "BadHolidayDate", "detail": str(e)}]
    cal = Calendar(extra_holidays=extras)
    hols = cal.holidays(year)
    return [
        {"date": d.isoformat(), "weekday": d.strftime("%a"), "name": name}
        for d, name in sorted(hols.items())
    ]


# ---------------------------------------------------------------------------
# Filters
# ---------------------------------------------------------------------------


@mcp.tool
def jira_create_filter(
    name: str,
    jql: str,
    description: str | None = None,
    favourite: bool = False,
    share: Any = None,
) -> dict:
    """Create a saved JQL filter.

    `share` accepts a preset or a raw sharePermissions list:
      - ``None`` or ``"private"``        → owner-only (default)
      - ``"public"``                      → visible to anyone (including anonymous)
      - ``"authenticated"``               → visible to any logged-in user
      - ``"project"``                     → share with the default project (AIE)
      - ``"project:KEY"``                 → share with a specific project
      - ``[{"type": ...}, ...]``          → raw sharePermissions (escape hatch)

    Returns a summary with `id`, `name`, `jql`, `viewUrl`, `sharePermissions`.
    Use the returned `id` when placing gadgets that need a filter.
    """
    try:
        share = _maybe_json(share)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)
    try:
        with JiraClient.from_env() as jc:
            return jc.create_filter(
                name=name,
                jql=jql,
                description=description,
                favourite=favourite,
                share=share,
            )
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


@mcp.tool
def jira_update_filter(
    filter_id: str,
    name: str | None = None,
    jql: str | None = None,
    description: str | None = None,
    favourite: bool | None = None,
    share: Any = "__unset__",
) -> dict:
    """Update a saved filter. Pass only the fields you want to change.

    `share` uses the same presets as `jira_create_filter`; leave it at the
    default sentinel to preserve the current sharePermissions.
    """
    try:
        if share != "__unset__":
            share = _maybe_json(share)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)
    try:
        with JiraClient.from_env() as jc:
            return jc.update_filter(
                filter_id,
                name=name,
                jql=jql,
                description=description,
                favourite=favourite,
                share=share,
            )
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


@mcp.tool
def jira_delete_filter(filter_id: str) -> dict:
    """Delete a saved filter. Gadgets pointing at it will fail to load —
    check `jira_list_filters` / dashboard usage before removing."""
    try:
        with JiraClient.from_env() as jc:
            return jc.delete_filter(filter_id)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


@mcp.tool
def jira_list_filters(search: str | None = None) -> list[dict]:
    """List saved filters. `search` does a partial-name match (Jira handles
    the filtering server-side)."""
    try:
        with JiraClient.from_env() as jc:
            return jc.list_filters(search=search)
    except Exception as e:  # noqa: BLE001
        return [_errordict(e)]


# ---------------------------------------------------------------------------
# Dashboards
# ---------------------------------------------------------------------------


@mcp.tool
def jira_create_dashboard(
    name: str,
    description: str | None = None,
    share: Any = None,
) -> dict:
    """Create a Jira dashboard. `share` uses the same presets as filters.

    Returns `{id, name, view, sharePermissions, ...}`. Use the `id` with
    `jira_add_gadget` to place gadgets on it.
    """
    try:
        share = _maybe_json(share)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)
    try:
        with JiraClient.from_env() as jc:
            return jc.create_dashboard(name=name, description=description, share=share)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


@mcp.tool
def jira_update_dashboard(
    dashboard_id: str,
    name: str | None = None,
    description: str | None = None,
    share: Any = "__unset__",
) -> dict:
    """Update a dashboard's name/description/share. Omit fields to leave them unchanged."""
    try:
        if share != "__unset__":
            share = _maybe_json(share)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)
    try:
        with JiraClient.from_env() as jc:
            return jc.update_dashboard(
                dashboard_id, name=name, description=description, share=share
            )
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


@mcp.tool
def jira_delete_dashboard(dashboard_id: str) -> dict:
    """Delete a dashboard. This is destructive — gadgets and their
    properties go with it."""
    try:
        with JiraClient.from_env() as jc:
            return jc.delete_dashboard(dashboard_id)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


@mcp.tool
def jira_list_dashboards(search: str | None = None) -> list[dict]:
    """List dashboards. `search` does a partial-name match."""
    try:
        with JiraClient.from_env() as jc:
            return jc.list_dashboards(search=search)
    except Exception as e:  # noqa: BLE001
        return [_errordict(e)]


# ---------------------------------------------------------------------------
# Gadgets
# ---------------------------------------------------------------------------


@mcp.tool
def jira_list_gadgets_available(dashboard_id: str) -> list[dict]:
    """List the gadget types Jira will accept on this dashboard (module keys
    + titles). Use when the semantic shortcuts in `jira_add_gadget` don't
    cover a gadget add-on you need."""
    try:
        with JiraClient.from_env() as jc:
            return jc.list_gadgets_available(dashboard_id)
    except Exception as e:  # noqa: BLE001
        return [_errordict(e)]


@mcp.tool
def jira_list_gadgets(dashboard_id: str) -> list[dict]:
    """List the gadgets currently placed on the dashboard, with their
    positions and item ids. Use the returned `id` for `jira_update_gadget`
    / `jira_remove_gadget`."""
    try:
        with JiraClient.from_env() as jc:
            return jc.list_gadgets(dashboard_id)
    except Exception as e:  # noqa: BLE001
        return [_errordict(e)]


@mcp.tool
def jira_add_gadget(
    dashboard_id: str,
    gadget: str,
    title: str | None = None,
    color: str | None = None,
    position: dict[str, int] | str | None = None,
    config: dict[str, Any] | str | None = None,
) -> dict:
    """Add a gadget to a dashboard in one call (create + set properties).

    `gadget` is either a semantic shortcut or a raw module key / URI:

      - ``"filter-results"`` — list view of a filter's issues (needs `config.filterId`)
      - ``"pie-chart"``       — pie by stat type (needs `filterId`; `statType` optional)
      - ``"two-d-stats"``     — 2D stat breakdown (needs `filterId`)
      - ``"created-vs-resolved"`` — line chart over time (needs `filterId`)
      - ``"issue-statistics"``    — bar chart by stat (needs `filterId`)
      - ``"heat-map"``        — heatmap by stat type (needs `filterId`)
      - ``"text"``            — a rich-text note / section divider
      - ``"roadmap"``         — project versions roadmap (needs `projectId`)
      - raw module key (``"addon.key:module-key"``) or XML-descriptor URI

    `config` keys depend on the gadget; at minimum pass the `filterId`
    from `jira_create_filter` / `jira_list_filters`. `position` is
    ``{"row": 0, "column": 1}``. Shortcut defaults fill the rest.

    Returns `{item_id, module_key, title, config}` — save `item_id` if
    you want to update or remove the gadget later.
    """
    try:
        position = _coerce_obj(position, "position")
        config = _coerce_obj(config, "config")
    except ValueError as e:
        return _errordict(e)
    try:
        with JiraClient.from_env() as jc:
            return jc.add_gadget(
                dashboard_id,
                gadget,
                title=title,
                color=color,
                position=position,
                config=config,
            )
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


@mcp.tool
def jira_update_gadget(
    dashboard_id: str,
    item_id: str,
    title: str | None = None,
    color: str | None = None,
    position: dict[str, int] | str | None = None,
    config: dict[str, Any] | str | None = None,
) -> dict:
    """Update a placed gadget. `title`/`color`/`position` hit the gadget
    shell; `config` keys are written to item properties. Pass only what
    changes — omitted args are untouched."""
    try:
        position = _coerce_obj(position, "position")
        config = _coerce_obj(config, "config")
    except ValueError as e:
        return _errordict(e)
    try:
        with JiraClient.from_env() as jc:
            return jc.update_gadget(
                dashboard_id,
                item_id,
                title=title,
                color=color,
                position=position,
                config=config,
            )
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


@mcp.tool
def jira_remove_gadget(dashboard_id: str, item_id: str) -> dict:
    """Remove a gadget from a dashboard by `item_id`
    (from `jira_list_gadgets`)."""
    try:
        with JiraClient.from_env() as jc:
            return jc.remove_gadget(dashboard_id, item_id)
    except Exception as e:  # noqa: BLE001
        return _errordict(e)


__all__ = ["mcp"]
