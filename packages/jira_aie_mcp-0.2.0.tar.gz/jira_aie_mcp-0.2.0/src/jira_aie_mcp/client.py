"""Thin synchronous Jira Cloud REST v3 client.

Single entry point: `with JiraClient.from_env() as jc: jc.create_issue(...)`.
Each method maps to one HTTP call; error handling raises `JiraAPIError`
so the MCP layer can serialize the failure back to the model cleanly
instead of crashing the server.
"""

from __future__ import annotations

import json
from base64 import b64encode
from dataclasses import dataclass
from typing import Any, Iterator

import httpx

from . import __version__
from .adf import to_adf_doc
from .config import Config, ConfigError


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class JiraAPIError(RuntimeError):
    """Raised when a Jira REST call returns a non-2xx status."""

    def __init__(self, operation: str, status: int, detail: Any):
        self.operation = operation
        self.status = status
        self.detail = detail
        super().__init__(f"Jira API {operation} failed ({status}): {detail}")

    def to_dict(self) -> dict:
        return {
            "error": f"Jira API {self.operation} failed",
            "status": self.status,
            "detail": self.detail,
        }


# ---------------------------------------------------------------------------
# Link-type shortcuts
# ---------------------------------------------------------------------------
#
# Semantic keys → (outward_role, inward_role). Jira stores directional
# link types with an active-verb ordering: for "A blocks B" (or "A causes
# B", "A duplicates B", "A clones B"), A is the inwardIssue (subject) and
# B is the outwardIssue (object). Callers pass the semantic key
# (blocker/blockee, cause/incident, etc.) and we pick the right
# `outwardIssue` / `inwardIssue` JSON fields to produce the intended
# direction in the Jira UI.

LINK_SHORTCUTS: dict[str, tuple[str, str]] = {
    "Blocks":     ("blockee",   "blocker"),
    "Relates":    ("a",         "b"),
    "Duplicate":  ("canonical", "duplicate"),
    "Duplicates": ("canonical", "duplicate"),
    "Clones":     ("original",  "clone"),
    "Cloners":    ("original",  "clone"),
    "Problem/Incident": ("incident", "cause"),
    "Causes":     ("incident",  "cause"),
}


# ---------------------------------------------------------------------------
# Dashboard-gadget shortcuts
# ---------------------------------------------------------------------------
#
# Jira Cloud identifies gadgets by an Atlassian-Connect module key (or, for
# legacy gadgets, by a URI to an XML descriptor). Nobody remembers these
# strings; callers want to say "pie-chart" and pass a filter id.
#
# Each entry has:
#   - `module_key` (preferred) or `uri` (for older instance gadgets) — the
#     identifier Jira's POST /dashboard/{id}/gadget endpoint expects.
#   - `config_defaults` — merged into the caller's `config` dict before
#     setting gadget properties. Keys are whatever Jira's gadget storage
#     treats as property keys (e.g. `filterId`, `num`, `statType`).
#   - `required_config_keys` — missing keys → early ValueError so the
#     caller doesn't end up with a broken, blank gadget on the dashboard.
#
# These module keys are the modern system-gadget set on Jira Cloud as of
# 2026-04. If an instance has gadget add-ons installed, their keys go
# through the fallthrough path in `add_gadget` (pass the raw module key
# as `gadget=`).

GADGET_SHORTCUTS: dict[str, dict[str, Any]] = {
    "filter-results": {
        "module_key": "com.atlassian.jira.gadgets:filter-results-gadget",
        "config_defaults": {
            "num": 10,
            "isConfigured": True,
            "columnNames": "issuetype|issuekey|summary|assignee|status|duedate|updated",
        },
        "required_config_keys": ["filterId"],
    },
    "pie-chart": {
        "module_key": "com.atlassian.jira.gadgets:pie-chart-dashboard-item",
        "config_defaults": {"statType": "status", "isConfigured": True},
        "required_config_keys": ["filterId"],
    },
    "two-d-stats": {
        "module_key": "com.atlassian.jira.gadgets:two-dimensional-stats-gadget",
        "config_defaults": {
            "xstattype": "status",
            "ystattype": "assignees",
            "numberToShow": 50,
            "sortBy": "natural",
            "sortDirection": "asc",
            "showTotals": True,
            "isConfigured": True,
        },
        "required_config_keys": ["filterId"],
    },
    "created-vs-resolved": {
        "module_key": "com.atlassian.jira.gadgets:createdvsresolved-gadget",
        "config_defaults": {
            "daysprevious": 30,
            "periodName": "daily",
            "isCumulative": False,
            "showUnresolvedTrend": True,
            "versionLabel": "none",
            "isConfigured": True,
        },
        "required_config_keys": ["filterId"],
    },
    "issue-statistics": {
        "module_key": "com.atlassian.jira.gadgets:stats-gadget",
        "config_defaults": {
            "statType": "assignees",
            "isConfigured": True,
        },
        "required_config_keys": ["filterId"],
    },
    "heat-map": {
        "module_key": "com.atlassian.jira.gadgets:heatmap-gadget",
        "config_defaults": {"statType": "assignees", "isConfigured": True},
        "required_config_keys": ["filterId"],
    },
    "text": {
        # A simple rich-text / HTML note block — useful for section dividers
        # and links out to Cowork artifacts.
        "module_key": "com.atlassian.jira.gadgets:text-gadget",
        "config_defaults": {"isConfigured": True},
        "required_config_keys": [],
    },
    "roadmap": {
        "module_key": "com.atlassian.jira.gadgets:roadmap-gadget",
        "config_defaults": {
            "numOfVersions": 5,
            "isConfigured": True,
        },
        "required_config_keys": ["projectId"],
    },
}


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


@dataclass
class JiraClient:
    config: Config
    _client: httpx.Client

    # -- lifecycle --------------------------------------------------------

    @classmethod
    def from_config(cls, cfg: Config) -> "JiraClient":
        auth = b64encode(f"{cfg.email}:{cfg.api_token}".encode()).decode()
        http = httpx.Client(
            base_url=cfg.base_url,
            headers={
                "Authorization": f"Basic {auth}",
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": f"jira-aie-mcp/{__version__}",
            },
            timeout=30.0,
        )
        return cls(config=cfg, _client=http)

    @classmethod
    def from_env(cls) -> "JiraClient":
        return cls.from_config(Config.from_env())

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "JiraClient":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # -- building blocks --------------------------------------------------

    def _check(self, operation: str, r: httpx.Response) -> None:
        if r.status_code < 300:
            return
        try:
            detail: Any = r.json()
        except Exception:
            detail = r.text
        raise JiraAPIError(operation, r.status_code, detail)

    def _build_fields(self, payload: dict) -> dict:
        """Translate a create/update payload into the `fields` dict Jira expects."""
        fields: dict[str, Any] = {}
        if "project_key" in payload or payload.get("op") == "create":
            pk = payload.get("project_key") or self.config.default_project_key
            if not pk:
                raise ConfigError(
                    "No project key supplied. Pass `project_key` in the "
                    "payload, or set JIRA_DEFAULT_PROJECT_KEY in the MCP "
                    "server's env."
                )
            fields["project"] = {"key": pk}
        if "summary" in payload:
            fields["summary"] = payload["summary"]
        if "issue_type" in payload:
            fields["issuetype"] = {"name": payload["issue_type"]}
        if "labels" in payload:
            fields["labels"] = list(payload["labels"])
        if "priority" in payload:
            fields["priority"] = {"name": payload["priority"]}
        if "assignee_id" in payload:
            fields["assignee"] = {"accountId": payload["assignee_id"]}
        for k, v in (payload.get("fields") or {}).items():
            fields[k] = v
        if "description" in payload and payload["description"] is not None:
            fields["description"] = to_adf_doc(payload["description"])
        return fields

    def browse_url(self, key: str) -> str:
        return f"{self.config.base_url}/browse/{key}"

    # -- issue CRUD -------------------------------------------------------

    def create_issue(self, payload: dict) -> dict:
        fields = self._build_fields({**payload, "op": "create"})
        r = self._client.post("/rest/api/3/issue", json={"fields": fields})
        self._check("create", r)
        data = r.json()
        out: dict[str, Any] = {
            "op": "create",
            "key": data["key"],
            "id": data["id"],
            "url": self.browse_url(data["key"]),
        }
        epic = payload.get("epic_key")
        if epic:
            self.link_to_epic(data["key"], epic)
            out["epic"] = epic
        return out

    def update_issue(self, payload: dict) -> dict:
        key = payload["issue_key"]
        fields = self._build_fields(payload)
        # `fields["project"]` is only for creates; strip if it snuck in.
        fields.pop("project", None)
        r = self._client.put(f"/rest/api/3/issue/{key}", json={"fields": fields})
        self._check("update", r)
        return {"op": "update", "key": key, "url": self.browse_url(key)}

    def get_issue(self, key: str, fields: list[str] | None = None) -> dict:
        params = {"fields": ",".join(fields)} if fields else None
        r = self._client.get(f"/rest/api/3/issue/{key}", params=params)
        self._check("get", r)
        return r.json()

    def get_transitions(self, key: str) -> dict:
        r = self._client.get(f"/rest/api/3/issue/{key}/transitions")
        self._check("transitions", r)
        return r.json()

    def link_to_epic(self, child_key: str, epic_key: str) -> None:
        # Team-managed projects use the `parent` field on the child.
        r = self._client.put(
            f"/rest/api/3/issue/{child_key}",
            json={"fields": {"parent": {"key": epic_key}}},
        )
        self._check(f"link {child_key} → {epic_key}", r)

    # -- issue links ------------------------------------------------------

    def create_link(self, payload: dict) -> dict:
        link_type = payload.get("type")
        if not link_type:
            raise ValueError("link payload needs 'type'")
        outward = payload.get("outwardIssue")
        inward = payload.get("inwardIssue")

        if not (outward and inward):
            match = LINK_SHORTCUTS.get(link_type)
            if not match:
                raise ValueError(
                    f"Link type {link_type!r} has no semantic shortcut. "
                    f"Pass 'inwardIssue' and 'outwardIssue' explicitly."
                )
            outward_role, inward_role = match
            outward = payload.get(outward_role)
            inward = payload.get(inward_role)
            if not (outward and inward):
                raise ValueError(
                    f"Link type {link_type!r} expects '{outward_role}' and '{inward_role}' keys "
                    f"(or explicit 'outwardIssue' / 'inwardIssue')."
                )

        body = {
            "type": {"name": link_type},
            "outwardIssue": {"key": outward},
            "inwardIssue": {"key": inward},
        }
        r = self._client.post("/rest/api/3/issueLink", json=body)
        self._check("link", r)
        return {"op": "link", "type": link_type, "outward": outward, "inward": inward}

    # -- batch ------------------------------------------------------------

    def batch(self, ops: list[dict]) -> list[dict]:
        """Run a mixed list of create/update/link operations.

        Errors on one operation do not halt the batch — failing entries
        return `{error, status?, detail?, index}` and the rest proceed.
        """
        results: list[dict] = []
        for i, entry in enumerate(ops):
            kind = entry.get("op", "create")
            try:
                if kind == "create":
                    results.append(self.create_issue(entry))
                elif kind == "update":
                    results.append(self.update_issue(entry))
                elif kind == "link":
                    results.append(self.create_link(entry))
                else:
                    results.append({"op": kind, "index": i, "error": f"unknown op {kind}"})
            except JiraAPIError as e:
                results.append({"op": kind, "index": i, **e.to_dict()})
            except Exception as e:  # noqa: BLE001 — translate any error into a record
                results.append({"op": kind, "index": i, "error": str(e)})
        return results

    # -- search & writeback ----------------------------------------------

    def search_jql(self, jql: str, fields: list[str]) -> list[dict]:
        """Paginated search via /search/jql. Returns a flat list of issues."""
        body: dict[str, Any] = {"jql": jql, "fields": fields, "maxResults": 100}
        out: list[dict] = []
        next_token: str | None = None
        while True:
            if next_token:
                body["nextPageToken"] = next_token
            r = self._client.post("/rest/api/3/search/jql", json=body)
            self._check("search", r)
            page = r.json()
            out.extend(page.get("issues", []))
            next_token = page.get("nextPageToken")
            if not next_token or page.get("isLast", True):
                break
        return out

    def set_duedate(self, key: str, iso_date: str) -> None:
        r = self._client.put(
            f"/rest/api/3/issue/{key}",
            json={"fields": {"duedate": iso_date}},
        )
        self._check(f"set duedate {key}", r)

    def iter_duedate_results(self, updates: Iterator[tuple[str, str]]) -> list[dict]:
        """Apply (key, iso_date) pairs; return per-key result records."""
        results: list[dict] = []
        for key, iso in updates:
            try:
                self.set_duedate(key, iso)
                results.append({"key": key, "ok": True, "duedate": iso})
            except JiraAPIError as e:
                results.append({"key": key, "ok": False, **e.to_dict()})
        return results

    # -- share permissions -----------------------------------------------

    @staticmethod
    def _share_permissions(share: Any) -> list[dict]:
        """Translate a friendly `share` argument into Jira's sharePermissions list.

        Accepted forms:
          - ``None`` or ``"private"``          → ``[]`` (owner-only)
          - ``"public"``                        → ``[{"type": "global"}]``
          - ``"authenticated"``                 → ``[{"type": "authenticated"}]``
          - ``"project"``                       → share with default project from env
          - ``"project:AIE"``                   → share with project AIE
          - ``list[dict]``                      → passed through verbatim (escape hatch)
        """
        if share is None or share == "private":
            return []
        if isinstance(share, list):
            return share
        if not isinstance(share, str):
            raise ValueError(
                f"share must be None, a string preset, or a list of "
                f"sharePermission dicts; got {type(share).__name__}"
            )
        if share == "public":
            return [{"type": "global"}]
        if share == "authenticated":
            return [{"type": "authenticated"}]
        if share == "project" or share.startswith("project:"):
            _, _, key = share.partition(":")
            return [{"type": "project", "project": {"key": key or "AIE"}}]
        raise ValueError(f"unknown share preset {share!r}")

    # -- filters ---------------------------------------------------------

    @staticmethod
    def _summarize_filter(data: dict) -> dict:
        """Pick the fields most callers care about out of a full filter JSON."""
        return {
            "id": data.get("id"),
            "name": data.get("name"),
            "jql": data.get("jql"),
            "description": data.get("description"),
            "favourite": data.get("favourite"),
            "owner": (data.get("owner") or {}).get("displayName"),
            "viewUrl": data.get("viewUrl"),
            "searchUrl": data.get("searchUrl"),
            "sharePermissions": data.get("sharePermissions", []),
        }

    def create_filter(
        self,
        name: str,
        jql: str,
        description: str | None = None,
        favourite: bool = False,
        share: Any = None,
    ) -> dict:
        body: dict[str, Any] = {
            "name": name,
            "jql": jql,
            "favourite": favourite,
            "sharePermissions": self._share_permissions(share),
        }
        if description is not None:
            body["description"] = description
        r = self._client.post("/rest/api/3/filter", json=body)
        self._check("create filter", r)
        return self._summarize_filter(r.json())

    def update_filter(
        self,
        filter_id: str,
        *,
        name: str | None = None,
        jql: str | None = None,
        description: str | None = None,
        favourite: bool | None = None,
        share: Any = "__unset__",
    ) -> dict:
        # Jira's PUT /filter/{id} replaces the filter body; fetch first and
        # merge so callers can update a single field without wiping others.
        r = self._client.get(f"/rest/api/3/filter/{filter_id}")
        self._check("fetch filter", r)
        current = r.json()
        body: dict[str, Any] = {
            "name": name if name is not None else current.get("name"),
            "jql": jql if jql is not None else current.get("jql"),
            "description": (
                description
                if description is not None
                else current.get("description", "")
            ),
            "favourite": (
                favourite if favourite is not None else bool(current.get("favourite"))
            ),
            "sharePermissions": (
                self._share_permissions(share)
                if share != "__unset__"
                else current.get("sharePermissions", [])
            ),
        }
        r2 = self._client.put(f"/rest/api/3/filter/{filter_id}", json=body)
        self._check("update filter", r2)
        return self._summarize_filter(r2.json())

    def delete_filter(self, filter_id: str) -> dict:
        r = self._client.delete(f"/rest/api/3/filter/{filter_id}")
        self._check("delete filter", r)
        return {"op": "delete", "id": filter_id, "ok": True}

    def list_filters(self, search: str | None = None) -> list[dict]:
        params: dict[str, Any] = {"expand": "owner,sharePermissions,jql,description"}
        if search:
            params["filterName"] = search
        r = self._client.get("/rest/api/3/filter/search", params=params)
        self._check("search filters", r)
        data = r.json()
        values = data.get("values") if isinstance(data, dict) else data
        return [self._summarize_filter(f) for f in (values or [])]

    # -- dashboards ------------------------------------------------------

    @staticmethod
    def _summarize_dashboard(data: dict) -> dict:
        return {
            "id": data.get("id"),
            "name": data.get("name"),
            "description": data.get("description"),
            "view": data.get("view"),
            "owner": (data.get("owner") or {}).get("displayName"),
            "isFavourite": data.get("isFavourite"),
            "sharePermissions": data.get("sharePermissions", []),
        }

    def create_dashboard(
        self,
        name: str,
        description: str | None = None,
        share: Any = None,
    ) -> dict:
        body: dict[str, Any] = {
            "name": name,
            "sharePermissions": self._share_permissions(share),
        }
        if description is not None:
            body["description"] = description
        r = self._client.post("/rest/api/3/dashboard", json=body)
        self._check("create dashboard", r)
        return self._summarize_dashboard(r.json())

    def update_dashboard(
        self,
        dashboard_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        share: Any = "__unset__",
    ) -> dict:
        r = self._client.get(f"/rest/api/3/dashboard/{dashboard_id}")
        self._check("fetch dashboard", r)
        current = r.json()
        body: dict[str, Any] = {
            "name": name if name is not None else current.get("name"),
            "description": (
                description
                if description is not None
                else current.get("description", "")
            ),
            "sharePermissions": (
                self._share_permissions(share)
                if share != "__unset__"
                else current.get("sharePermissions", [])
            ),
        }
        r2 = self._client.put(f"/rest/api/3/dashboard/{dashboard_id}", json=body)
        self._check("update dashboard", r2)
        return self._summarize_dashboard(r2.json())

    def delete_dashboard(self, dashboard_id: str) -> dict:
        r = self._client.delete(f"/rest/api/3/dashboard/{dashboard_id}")
        self._check("delete dashboard", r)
        return {"op": "delete", "id": dashboard_id, "ok": True}

    def list_dashboards(self, search: str | None = None) -> list[dict]:
        params: dict[str, Any] = {"maxResults": 100}
        if search:
            params["dashboardName"] = search
        r = self._client.get("/rest/api/3/dashboard/search", params=params)
        self._check("search dashboards", r)
        data = r.json()
        values = data.get("values") if isinstance(data, dict) else data
        return [self._summarize_dashboard(d) for d in (values or [])]

    # -- gadgets ---------------------------------------------------------

    def list_gadgets_available(self, dashboard_id: str) -> list[dict]:
        """Return the gadgets Jira will let you add to this dashboard."""
        r = self._client.get(f"/rest/api/3/dashboard/{dashboard_id}/gadgets")
        self._check("list available gadgets", r)
        data = r.json()
        return data.get("gadgets", []) if isinstance(data, dict) else data

    def list_gadgets(self, dashboard_id: str) -> list[dict]:
        """Return the gadgets currently placed on this dashboard."""
        r = self._client.get(f"/rest/api/3/dashboard/{dashboard_id}/gadget")
        self._check("list dashboard gadgets", r)
        data = r.json()
        return data.get("gadgets", []) if isinstance(data, dict) else data

    def _gadget_properties_put(
        self, dashboard_id: str, item_id: str, config: dict[str, Any]
    ) -> None:
        """PUT each config key as an item property. Values are JSON-encoded
        because Jira's dashboard-item-properties storage is typed `string`
        and gadgets deserialize their own config."""
        for key, value in config.items():
            # JSON-encode everything so readers get the original type back.
            payload = value if isinstance(value, str) else json.dumps(value)
            r = self._client.put(
                f"/rest/api/3/dashboard/{dashboard_id}/items/{item_id}/properties/{key}",
                content=payload if isinstance(payload, str) else str(payload),
                headers={"Content-Type": "application/json"},
            )
            self._check(f"set gadget property {key}", r)

    def add_gadget(
        self,
        dashboard_id: str,
        gadget: str,
        *,
        title: str | None = None,
        color: str | None = None,
        position: dict[str, int] | None = None,
        config: dict[str, Any] | None = None,
    ) -> dict:
        """Add a gadget to `dashboard_id`.

        `gadget` is either a shortcut key from `GADGET_SHORTCUTS`
        (e.g. "pie-chart", "filter-results") or a raw module key /
        URI string. The method does two HTTP calls: POST to create
        the gadget, then PUT each config property.
        """
        shortcut = GADGET_SHORTCUTS.get(gadget)
        effective_config: dict[str, Any] = {}
        module_key: str | None = None
        uri: str | None = None
        if shortcut is not None:
            module_key = shortcut.get("module_key")
            uri = shortcut.get("uri")
            effective_config.update(shortcut.get("config_defaults") or {})
            missing = [
                k
                for k in shortcut.get("required_config_keys", [])
                if k not in (config or {})
                and k not in effective_config
            ]
            if missing:
                raise ValueError(
                    f"gadget {gadget!r} requires config keys: {missing}"
                )
        else:
            # Treat `gadget` as a raw identifier — URIs start with http(s),
            # module keys look like `addon.key:module-key`.
            if gadget.startswith("http://") or gadget.startswith("https://"):
                uri = gadget
            else:
                module_key = gadget

        effective_config.update(config or {})

        body: dict[str, Any] = {}
        if module_key:
            body["moduleKey"] = module_key
        if uri:
            body["uri"] = uri
        if title:
            body["title"] = title
        if color:
            body["color"] = color
        if position:
            body["position"] = position

        r = self._client.post(
            f"/rest/api/3/dashboard/{dashboard_id}/gadget", json=body
        )
        self._check("add gadget", r)
        created = r.json()
        item_id = str(created.get("id"))

        if effective_config:
            self._gadget_properties_put(dashboard_id, item_id, effective_config)

        return {
            "op": "add_gadget",
            "dashboard_id": dashboard_id,
            "item_id": item_id,
            "gadget": gadget,
            "module_key": module_key,
            "uri": uri,
            "title": created.get("title") or title,
            "config": effective_config,
        }

    def update_gadget(
        self,
        dashboard_id: str,
        item_id: str,
        *,
        title: str | None = None,
        color: str | None = None,
        position: dict[str, int] | None = None,
        config: dict[str, Any] | None = None,
    ) -> dict:
        """Update the shell (title/color/position) and/or config of a placed gadget."""
        shell: dict[str, Any] = {}
        if title is not None:
            shell["title"] = title
        if color is not None:
            shell["color"] = color
        if position is not None:
            shell["position"] = position
        if shell:
            r = self._client.put(
                f"/rest/api/3/dashboard/{dashboard_id}/gadget/{item_id}", json=shell
            )
            self._check("update gadget", r)

        if config:
            self._gadget_properties_put(dashboard_id, item_id, config)

        return {
            "op": "update_gadget",
            "dashboard_id": dashboard_id,
            "item_id": item_id,
            "updated_shell": list(shell.keys()),
            "updated_config": list((config or {}).keys()),
        }

    def remove_gadget(self, dashboard_id: str, item_id: str) -> dict:
        r = self._client.delete(
            f"/rest/api/3/dashboard/{dashboard_id}/gadget/{item_id}"
        )
        self._check("remove gadget", r)
        return {
            "op": "remove_gadget",
            "dashboard_id": dashboard_id,
            "item_id": item_id,
            "ok": True,
        }
