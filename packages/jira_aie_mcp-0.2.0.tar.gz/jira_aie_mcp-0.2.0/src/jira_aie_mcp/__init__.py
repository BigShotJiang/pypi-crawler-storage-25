"""jira-aie-mcp — MCP server exposing rich-ADF Jira operations and a gantt scheduler for the AIE team."""

__version__ = "0.2.0"
