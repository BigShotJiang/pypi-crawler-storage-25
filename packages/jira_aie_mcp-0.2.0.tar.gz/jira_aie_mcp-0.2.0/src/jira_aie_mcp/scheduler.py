"""Working-day-aware forward-pass scheduler.

Reads a flat list of Jira issues (already fetched via JQL), builds a graph
of Blocks dependencies, assigns durations from `timetracking.originalEstimate`
(falling back to a default), and computes start/end dates by forward pass.

Only **Blocks** edges participate. Relates/Duplicates/Clones/Caused-by are
ignored for scheduling. Subtask and Epic parent relationships also don't
influence the schedule — if an Epic's children have dependencies on each
other, link them explicitly with Blocks.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from datetime import date, timedelta

from .holidays import Calendar, parse_estimate


class SchedulingError(ValueError):
    """Raised when the graph can't be scheduled (typically a cycle)."""


# ---------------------------------------------------------------------------
# Node model
# ---------------------------------------------------------------------------


@dataclass
class Node:
    key: str
    summary: str
    issue_type: str
    status: str
    workstream: str | None
    duration_days: int
    used_default_estimate: bool
    preds: list[str] = field(default_factory=list)
    succs: list[str] = field(default_factory=list)
    start: date | None = None
    end: date | None = None
    pinned: bool = False
    delayed_by: int = 0


_BASE_SCHEDULER_FIELDS = [
    "summary",
    "status",
    "issuetype",
    "issuelinks",
    "timetracking",
    "duedate",
    "parent",
]


def scheduler_fields(workstream_field_id: str | None = None) -> list[str]:
    """Fields to request for scheduling. Appends the Workstream custom field
    if its ID is configured (it's tenant-specific, so it's opt-in)."""
    if workstream_field_id:
        return [*_BASE_SCHEDULER_FIELDS, workstream_field_id]
    return list(_BASE_SCHEDULER_FIELDS)


# ---------------------------------------------------------------------------
# Graph construction
# ---------------------------------------------------------------------------


def build_graph(
    issues: list[dict],
    default_days: float,
    in_scope: set[str],
    workstream_field_id: str | None = None,
) -> dict[str, Node]:
    """Build a dict of Node objects keyed by issue key, wired by Blocks edges."""
    nodes: dict[str, Node] = {}
    for issue in issues:
        key = issue["key"]
        f = issue.get("fields", {})
        est = (f.get("timetracking") or {}).get("originalEstimate")
        duration, used_default = parse_estimate(est, default_days=default_days)
        ws_field = f.get(workstream_field_id) if workstream_field_id else None
        workstream = (ws_field or {}).get("value") if isinstance(ws_field, dict) else None
        nodes[key] = Node(
            key=key,
            summary=f.get("summary", ""),
            issue_type=((f.get("issuetype") or {}).get("name") or "Unknown"),
            status=((f.get("status") or {}).get("name") or "Unknown"),
            workstream=workstream,
            duration_days=duration,
            used_default_estimate=used_default,
        )
    # Second pass: wire up Blocks edges (only among in-scope issues).
    #
    # Jira stores "Blocks" with an active-verb ordering: for "A blocks B",
    # A is the inwardIssue (subject) and B is the outwardIssue (object).
    # When you GET an issue X's `issuelinks`, each entry shows the *other*
    # end of the link relative to X:
    #   - entry with `inwardIssue: Y`  → Y is on the subject side,
    #     Y blocks X → Y is a PREDECESSOR of X.
    #   - entry with `outwardIssue: Y` → Y is on the object side,
    #     X blocks Y → Y is a SUCCESSOR of X.
    for issue in issues:
        key = issue["key"]
        for link in (issue.get("fields", {}).get("issuelinks") or []):
            type_name = (link.get("type") or {}).get("name", "")
            if type_name != "Blocks":
                continue
            if "inwardIssue" in link:
                # The other side is inward (subject) → it blocks this issue.
                other = link["inwardIssue"]["key"]
                if other in in_scope:
                    nodes[key].preds.append(other)
                    nodes[other].succs.append(key)
            elif "outwardIssue" in link:
                # The other side is outward (object) → this issue blocks it.
                other = link["outwardIssue"]["key"]
                if other in in_scope:
                    # May already be recorded from the other side; dedup below.
                    if other not in nodes[key].succs:
                        nodes[key].succs.append(other)
                        nodes[other].preds.append(key)
    # Dedup edges (both sides of a Blocks link often appear on both issues)
    for n in nodes.values():
        n.preds = sorted(set(n.preds))
        n.succs = sorted(set(n.succs))
    return nodes


# ---------------------------------------------------------------------------
# Topological sort + forward pass
# ---------------------------------------------------------------------------


def topo_order(nodes: dict[str, Node]) -> list[str]:
    """Kahn's algorithm. Raises SchedulingError on cycle."""
    indeg = {k: len(n.preds) for k, n in nodes.items()}
    ready: deque[str] = deque(k for k, d in indeg.items() if d == 0)
    order: list[str] = []
    while ready:
        k = ready.popleft()
        order.append(k)
        for s in nodes[k].succs:
            indeg[s] -= 1
            if indeg[s] == 0:
                ready.append(s)
    if len(order) != len(nodes):
        unresolved = sorted(k for k, d in indeg.items() if d > 0)
        raise SchedulingError(f"Dependency cycle involving: {unresolved}")
    return order


def compute_schedule(
    nodes: dict[str, Node],
    project_start: date,
    calendar: Calendar,
    pins: dict[str, date],
    delays: dict[str, int],
) -> None:
    """Forward-pass schedule. Mutates each node's start/end/pinned/delayed_by."""
    for k, n in nodes.items():
        if k in delays:
            n.delayed_by = delays[k]
    order = topo_order(nodes)
    for k in order:
        n = nodes[k]
        if k in pins:
            n.start = calendar.next_workday(pins[k])
            n.pinned = True
        else:
            earliest = project_start
            for p in n.preds:
                pend = nodes[p].end
                if pend is None:
                    continue
                nxt = calendar.next_workday(pend + timedelta(days=1))
                if nxt > earliest:
                    earliest = nxt
            earliest = calendar.next_workday(earliest)
            if n.delayed_by:
                earliest = calendar.add_workdays(earliest, n.delayed_by + 1)
            n.start = earliest
        n.end = calendar.add_workdays(n.start, n.duration_days)


def critical_path(nodes: dict[str, Node]) -> list[str]:
    """Return the keys on a longest-duration chain, ordered root → leaf.

    If multiple chains tie for longest, this returns one of them (the one
    reached by greedy max-predecessor walkback from the latest-finishing
    node — deterministic per input, but don't rely on which tie-breaker it
    picks). Use set membership (`key in critical_path(nodes)`) when you
    only care about whether a node is on the chain.
    """
    order = topo_order(nodes)
    best: dict[str, int] = {}
    prev: dict[str, str | None] = {}
    for k in order:
        n = nodes[k]
        pred_best = 0
        pred_k: str | None = None
        for p in n.preds:
            if best[p] > pred_best:
                pred_best = best[p]
                pred_k = p
        best[k] = pred_best + n.duration_days
        prev[k] = pred_k
    if not best:
        return []
    end_key = max(best, key=best.get)  # type: ignore[arg-type]
    # Walk back from leaf to root, then reverse so the output reads as the
    # chain of work — useful for narrative rendering ("Setup → A → Integrate
    # → Validate") and for picking out the first slippable node.
    chain: list[str] = []
    cur: str | None = end_key
    while cur is not None:
        chain.append(cur)
        cur = prev[cur]
    chain.reverse()
    return chain
