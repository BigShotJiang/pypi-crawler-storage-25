# Changelog

All notable changes to this project are documented here. Dates are ISO; the
project follows [Semantic Versioning](https://semver.org/).

## 0.2.0 - 2026-04-22

### Added

- **Filter CRUD.** `jira_create_filter`, `jira_update_filter`,
  `jira_delete_filter`, `jira_list_filters`. The `share` arg accepts
  a friendly preset (`"private"` / `"public"` / `"authenticated"` /
  `"project"` / `"project:KEY"`) or a raw `sharePermissions` list.
  Update is merge-on-top-of-fetch so callers can change one field
  without clobbering the rest.

- **Dashboard CRUD.** `jira_create_dashboard`, `jira_update_dashboard`,
  `jira_delete_dashboard`, `jira_list_dashboards`. Same `share`
  presets as filters; same merge-on-update semantics.

- **Gadget CRUD with semantic shortcuts.** `jira_list_gadgets_available`,
  `jira_list_gadgets`, `jira_add_gadget`, `jira_update_gadget`,
  `jira_remove_gadget`. `GADGET_SHORTCUTS` maps friendly names
  (`"filter-results"`, `"pie-chart"`, `"two-d-stats"`,
  `"created-vs-resolved"`, `"issue-statistics"`, `"heat-map"`,
  `"text"`, `"roadmap"`) to Atlassian-Connect module keys with
  sensible `config_defaults` and declared `required_config_keys`.
  Missing required keys raise `ValueError` before the first HTTP
  call, so callers never end up with a blank gadget on the board.

  `add_gadget` implements the two-step Jira contract: POST to
  `/rest/api/3/dashboard/{id}/gadget` to create the shell, then
  PUT each config entry to
  `/rest/api/3/dashboard/{id}/items/{itemId}/properties/{key}`
  (values are JSON-encoded because the storage is typed `string`
  and gadgets deserialize their own config).

- **`tests/test_dashboards.py`.** 15 cases covering
  `_share_permissions` translation (None / presets / raw list /
  type errors), `GADGET_SHORTCUTS` well-formedness (identifier
  present, config_defaults shape, filter-backed gadgets require
  filterId, roadmap requires projectId, text requires nothing),
  and `add_gadget` input validation (missing required keys raise
  before HTTP; text gadget passes the validation guard). Uses a
  stub HTTP client so no network is touched.

### Changed

- `server.py` now imports `GADGET_SHORTCUTS` from `client` and exposes
  13 new `@mcp.tool` wrappers (4 filter, 4 dashboard, 5 gadget).
  `_coerce_obj` is reused for the `config` / `position` params on
  gadget tools so clients that stringify structured arguments
  continue to work transparently.

### Migration note

Purely additive. Existing 7 tools (`jira_create_issue`,
`jira_update_issue`, `jira_get_issue_raw`, `jira_link_issues`,
`jira_batch_ops`, `schedule_compute`, `schedule_holidays`) are
unchanged; all existing tests still pass.

## 0.1.5 - 2026-04-22

### Fixed

- **`Blocks` direction was still wrong after 0.1.4 — in a different
  place.** 0.1.4 flipped `LINK_SHORTCUTS["Blocks"]` on the assumption
  that Jira's convention was the naive reading of the type description
  fields (outward="blocks" → outwardIssue is the blocker). Empirically
  that's wrong: Jira stores "Blocks" with an active-verb ordering —
  for "A blocks B", A is the `inwardIssue` (subject) and B is the
  `outwardIssue` (object). The 0.1.4 tuple flip happened to produce
  the correct UI direction for `jira_link_issues`, but the accompanying
  docstring described the wrong reason, and the scheduler's read path
  was still inverted.

  This release corrects both:

  1. **Scheduler read path (`scheduler.py`).** `build_graph`
     interpreted an `inwardIssue: Y` entry on X's `issuelinks` as
     "X blocks Y" → Y is X's successor. Under Jira's actual convention,
     Y sits on the subject side of that entry, so Y blocks X — Y is
     X's *predecessor*. The two slot-branches are swapped.
     `test_scheduler.py` helpers (renamed to `_this_blocks` /
     `_this_blocked_by` from the old `_blocks_outward` /
     `_blocks_inward`) now produce the correct slot for each
     perspective. 35/35 tests still pass.
  2. **Docstrings and comments (`server.py`, `client.py`).** The
     `jira_link_issues` docstring and the `LINK_SHORTCUTS` comment
     both described Jira's convention backwards. Rewritten to match
     the active-verb rule and to say what each param name means in
     the resulting UI.

  The other directional shortcuts are flipped to match the same rule:

  - `Duplicate` / `Duplicates`: `("duplicate", "canonical")` →
    `("canonical", "duplicate")` (so `duplicate` → `inwardIssue`,
    "duplicate duplicates canonical").
  - `Clones` / `Cloners`: `("clone", "original")` →
    `("original", "clone")` ("clone clones original").
  - `Causes`: `("cause", "incident")` → `("incident", "cause")`
    ("cause causes incident").
  - `Problem/Incident`: unchanged. `("incident", "cause")` was already
    correct — it happens to match the active-verb rule, since the
    old docs-convention reading of the passive "is caused by"
    outward phrasing produces the same tuple.

  `Relates` is symmetric and unaffected.

## 0.1.4 - 2026-04-22

### Fixed

- **`jira_link_issues` with `type="Blocks"` was creating links in the
  reverse direction in the Jira UI.** The `LINK_SHORTCUTS` mapping put
  `blocker` on the `outwardIssue` slot (which Jira renders as "blocks")
  and `blockee` on the `inwardIssue` slot ("is blocked by"), so a call
  like `blocker="A", blockee="B"` produced a link where A showed "blocks
  B" in the UI — the opposite of the intended "A is blocked by B"
  relationship. The tuple is now `("blockee", "blocker")`, so `blocker`
  maps to the inward side ("is blocked by") and `blockee` to the outward
  side ("blocks"). The `jira_link_issues` docstring is updated to spell
  out what each param name means in the resulting UI.

  Scope: only `Blocks` is flipped. The scheduler's interpretation of
  Jira GET responses in `scheduler.py` is unchanged — it reads directly
  against Jira's documented outward/inward convention and its regression
  tests still pass.

## 0.1.3 - 2026-04-21

### Fixed

- **Structured arguments arriving as JSON strings are now decoded
  transparently.** Some MCP clients (observed against Cowork) serialize
  object- and array-valued arguments as JSON strings when a tool's schema
  lacks a concrete JSON type. `dict[str, Any] | None` and `Any` - the
  annotations on `fields`, `description`, `ops`, `pins`, `delays`, and
  `extra_holidays` - produced pydantic/FastMCP schemas without
  `type: object`, which was enough to trigger the client-side stringify
  fallback. Result: `jira_create_issue(fields={"customfield_10742": ...})`
  failed with "Input should be a valid dictionary", and a block-list
  `description` was passed through to `_blocks_from` as a raw string, hit
  the Markdown fallback, and got rendered as one enormous paragraph of
  literal JSON.

  Two-layer fix:

  1. **At the tool seam (`server.py`)** - the relevant params are retyped
     as `dict | str | None` / `list | str | None` so pydantic accepts the
     string form, and new `_coerce_obj` / `_coerce_arr` helpers decode the
     string via a single `_maybe_json` primitive. The rule is: try
     `json.loads`, and if it throws, treat the value as a plain string.
     Callers then type-check the result (dict vs. list) and raise a
     clear `ValueError` with the offending param name if the decoded
     shape is wrong. `jira_get_issue_raw(fields=...)` additionally accepts
     a comma-separated string, matching mcp-atlassian ergonomics.
  2. **In the ADF layer (`adf.py`)** - `_blocks_from` now probes strings
     whose first non-whitespace char is `[` or `{` as JSON before falling
     back to Markdown. Real Markdown that starts with `[link](...)` or
     with a `{non-json}` brace still renders correctly; a stringified
     block DSL correctly produces block nodes.

- **`description` for the `to_adf_doc` entry point now accepts a bare DSL
  dict** (e.g. `{"p": "hi"}` for a one-block doc). Previously only lists,
  strings, and full ADF docs were accepted.

### Added

- `tests/test_coercion.py` - 23 cases covering dict/list pass-through,
  JSON-string decoding, invalid-JSON graceful handling, CSV fallback for
  string lists, JSON-over-CSV precedence, JSON-in-string description
  detection, Markdown-fallback safety when the opener is `[link]` or
  `{garbage}`, and a named regression guard for the AIE-11 live-test
  failure mode.

### Migration note

Existing callers are unaffected: dicts and lists still work as before.
The change is purely additive - strings are newly accepted at these seams.

## 0.1.2 - 2026-04-21

### Changed

- **`critical_path` now returns a chain-ordered `list[str]`** instead of a
  `set[str]`. The output reads root -> leaf (e.g. `["AIE-6", "AIE-7",
  "AIE-9", "AIE-10"]` for the classic diamond), which matches how people
  skim gantt output. Previously the JSON plan showed the chain sorted
  alphanumerically as `["AIE-10", "AIE-6", "AIE-7", "AIE-9"]`, which looked
  backwards.
- `to_plan_json` no longer re-sorts the chain; it preserves scheduler order
  and builds a set internally for the per-issue `on_critical_path` flag.

### Added

- `tests/test_scheduler.py` gains two cases: one asserting the chain order,
  one asserting `to_plan_json` preserves it.

### Migration note

If anything downstream relies on `critical_path(nodes)` returning a set,
wrap the call in `set(...)`. Membership checks (`"AIE-7" in crit`) keep
working either way.

## 0.1.1 - 2026-04-21

### Fixed

- **Scheduler: Blocks direction was inverted.** `build_graph` was reading
  `outwardIssue` as the successor and `inwardIssue` as the predecessor, which
  is the opposite of what Jira REST v3 returns. In the real payload, when
  you GET issue X's `issuelinks`:
  - an entry with `inwardIssue: Y` means **X blocks Y** (Y is a successor of X),
  - an entry with `outwardIssue: Y` means **X is blocked by Y** (Y is a
    predecessor of X).
  The previous code mirrored every schedule - `critical_path`, `project_end`,
  and `duedate` writeback all came out reversed. All of them look internally
  consistent with each other, so the bug only surfaces when you compare
  against the actual dependency graph. Detected via the live diamond smoke
  test on AIE-5..AIE-10.
- Deduplication when both sides of a Blocks edge are in-scope no longer
  drops the second side.

### Added

- Test suite (`tests/test_scheduler.py`) with 10 cases covering the
  Blocks-direction contract, diamond end-to-end scheduling, weekend skipping,
  pins, delays, and a named regression guard against the 0.1.0 inversion.
- `pytest` added as an optional `dev` dependency and a `[tool.pytest.ini_options]`
  section so `pytest` runs out of the box.

### Note for existing users

If you ran `schedule_compute(..., write_duedate=True)` on 0.1.0 against any
non-trivial Blocks graph, the persisted `duedate` fields on those issues are
mirror-image wrong. Re-run the scheduler with `write_duedate=True` after
upgrading; the overwrite will restore correct dates.

## 0.1.0 - 2026-04-21

Initial public release on PyPI. 7 FastMCP tools:

- `jira_create_issue` / `jira_update_issue` - rich ADF descriptions (panels,
  status lozenges, date chips, expand blocks, task lists, tables), plus
  Markdown-string and raw-ADF fallbacks.
- `jira_get_issue_raw` - untouched REST v3 response.
- `jira_link_issues` - semantic shortcuts for Blocks/Relates/Duplicates/
  Clones/Causes.
- `jira_batch_ops` - mixed create/update/link in one round-trip.
- `schedule_compute` - working-day forward-pass gantt on the Norwegian
  public-holiday calendar, with critical-path detection, JSON / Markdown /
  Mermaid output, and optional `duedate` writeback.
- `schedule_holidays` - verify the Norwegian red-day calendar for a year.
