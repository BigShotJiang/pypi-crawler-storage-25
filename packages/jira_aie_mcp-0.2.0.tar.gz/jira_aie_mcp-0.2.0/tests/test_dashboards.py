"""Tests for filter / dashboard / gadget helpers.

These don't touch Jira — they exercise the pure pieces:

- `JiraClient._share_permissions` translates the friendly `share` arg.
- `GADGET_SHORTCUTS` is well-formed (module_key or uri present,
  required_config_keys subset of expected keys).
- `JiraClient.add_gadget` rejects missing required config up front.

The network-facing CRUD methods are covered by the live smoke test in
`scripts/` (not committed) against a dashboard staging instance; they
are intentionally not mocked here because mocking Jira's paginated
search responses is more fragile than the live check.
"""

from __future__ import annotations

import pytest

from jira_aie_mcp.client import GADGET_SHORTCUTS, JiraClient


# ---------------------------------------------------------------------------
# _share_permissions
# ---------------------------------------------------------------------------


def test_share_none_is_private():
    assert JiraClient._share_permissions(None) == []


def test_share_private_preset():
    assert JiraClient._share_permissions("private") == []


def test_share_public_becomes_global():
    assert JiraClient._share_permissions("public") == [{"type": "global"}]


def test_share_authenticated_preset():
    assert JiraClient._share_permissions("authenticated") == [
        {"type": "authenticated"}
    ]


def test_share_project_default_key():
    out = JiraClient._share_permissions("project")
    assert out == [{"type": "project", "project": {"key": "AIE"}}]


def test_share_project_explicit_key():
    out = JiraClient._share_permissions("project:FOO")
    assert out == [{"type": "project", "project": {"key": "FOO"}}]


def test_share_passes_raw_list_through():
    raw = [{"type": "group", "group": {"name": "jira-users"}}]
    assert JiraClient._share_permissions(raw) is raw


def test_share_rejects_unknown_preset():
    with pytest.raises(ValueError, match="unknown share preset"):
        JiraClient._share_permissions("world")


def test_share_rejects_wrong_type():
    with pytest.raises(ValueError, match="share must be"):
        JiraClient._share_permissions(42)


# ---------------------------------------------------------------------------
# GADGET_SHORTCUTS well-formedness
# ---------------------------------------------------------------------------


def test_gadget_shortcuts_have_identifier():
    for name, spec in GADGET_SHORTCUTS.items():
        assert "module_key" in spec or "uri" in spec, (
            f"gadget {name!r} needs module_key or uri"
        )


def test_gadget_shortcuts_config_defaults_is_dict():
    for name, spec in GADGET_SHORTCUTS.items():
        assert isinstance(spec.get("config_defaults", {}), dict), name


def test_gadget_shortcuts_required_keys_are_strings():
    for name, spec in GADGET_SHORTCUTS.items():
        reqs = spec.get("required_config_keys", [])
        assert all(isinstance(k, str) for k in reqs), name


def test_filter_gadgets_require_filter_id():
    # Filter-backed gadgets must declare filterId as required.
    for name in (
        "filter-results",
        "pie-chart",
        "two-d-stats",
        "created-vs-resolved",
        "issue-statistics",
        "heat-map",
    ):
        assert (
            "filterId" in GADGET_SHORTCUTS[name]["required_config_keys"]
        ), f"{name} should require filterId"


def test_text_gadget_has_no_required_config():
    # The text/note gadget should work with no config.
    assert GADGET_SHORTCUTS["text"]["required_config_keys"] == []


def test_roadmap_gadget_requires_project_id():
    assert "projectId" in GADGET_SHORTCUTS["roadmap"]["required_config_keys"]


# ---------------------------------------------------------------------------
# add_gadget input validation (no network)
# ---------------------------------------------------------------------------


class _StubClient:
    """Minimal stand-in so add_gadget reaches its validation without HTTP."""

    def __init__(self):
        self.calls = []

    def post(self, *args, **kwargs):  # pragma: no cover - shouldn't be reached
        self.calls.append(("post", args, kwargs))
        raise AssertionError("should not reach HTTP on validation failure")

    def put(self, *args, **kwargs):  # pragma: no cover
        raise AssertionError("should not reach HTTP on validation failure")


def _make_client_stub() -> JiraClient:
    """Build a JiraClient that won't actually hit HTTP for the validation path."""
    from jira_aie_mcp.config import Config

    cfg = Config(
        base_url="https://example.atlassian.net",
        email="test@example.com",
        api_token="x",
        default_project_key="AIE",
        workstream_field_id=None,
    )
    jc = JiraClient(config=cfg, _client=_StubClient())  # type: ignore[arg-type]
    return jc


def test_add_gadget_rejects_missing_filter_id():
    jc = _make_client_stub()
    with pytest.raises(ValueError, match="requires config keys"):
        jc.add_gadget("1000", "pie-chart", config={})


def test_add_gadget_rejects_missing_project_id_for_roadmap():
    jc = _make_client_stub()
    with pytest.raises(ValueError, match="projectId"):
        jc.add_gadget("1000", "roadmap", config={})


def test_add_gadget_text_needs_no_config():
    # text gadget has no required keys — validation should pass the guard.
    # It will still fail at the HTTP seam (_StubClient.post asserts),
    # proving validation passed.
    jc = _make_client_stub()
    with pytest.raises(AssertionError, match="should not reach HTTP"):
        jc.add_gadget("1000", "text")
