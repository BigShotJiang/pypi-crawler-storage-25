"""Tests for the string-to-JSON coercion at the tool boundary.

Some MCP clients (observed against Cowork) serialize structured arguments
as JSON strings when a tool's schema lacks a concrete JSON type.
"""

from __future__ import annotations

import pytest

from jira_aie_mcp.adf import to_adf_doc
from jira_aie_mcp.server import _coerce_arr, _coerce_obj


# _coerce_obj


def test_coerce_obj_passes_dict_through():
    val = {"customfield_10742": {"value": "Platform"}}
    assert _coerce_obj(val, "fields") is val


def test_coerce_obj_passes_none_through():
    assert _coerce_obj(None, "fields") is None


def test_coerce_obj_decodes_json_string():
    raw = '{"customfield_10742": {"value": "Platform"}}'
    out = _coerce_obj(raw, "fields")
    assert out == {"customfield_10742": {"value": "Platform"}}


def test_coerce_obj_decodes_nested_json_string():
    raw = (
        '{"customfield_10742": {"value": "Platform"}, '
        '"customfield_10750": [{"value": "Infrastructure"}]}'
    )
    out = _coerce_obj(raw, "fields")
    assert out["customfield_10750"] == [{"value": "Infrastructure"}]


def test_coerce_obj_rejects_invalid_json_with_clear_message():
    with pytest.raises(ValueError, match="fields must be an object"):
        _coerce_obj("{not-json", "fields")


def test_coerce_obj_rejects_json_that_decodes_to_list():
    with pytest.raises(ValueError, match="fields must be an object.*got list"):
        _coerce_obj("[1, 2, 3]", "fields")


def test_coerce_obj_rejects_wrong_python_type():
    with pytest.raises(ValueError, match="fields must be an object.*got int"):
        _coerce_obj(42, "fields")


# _coerce_arr


def test_coerce_arr_passes_list_through():
    val = [{"op": "create"}]
    assert _coerce_arr(val, "ops") is val


def test_coerce_arr_passes_none_through():
    assert _coerce_arr(None, "ops") is None


def test_coerce_arr_decodes_json_array_string():
    raw = '[{"op": "create", "summary": "x", "issue_type": "Task"}]'
    out = _coerce_arr(raw, "ops")
    assert out == [{"op": "create", "summary": "x", "issue_type": "Task"}]


def test_coerce_arr_rejects_json_that_decodes_to_object():
    with pytest.raises(ValueError, match="ops must be a list.*got dict"):
        _coerce_arr('{"op": "create"}', "ops")


def test_coerce_arr_rejects_plain_string_when_csv_disabled():
    with pytest.raises(ValueError, match="ops must be a list.*got str"):
        _coerce_arr("summary,description", "ops")


def test_coerce_arr_accepts_csv_when_allowed():
    out = _coerce_arr("summary, description ,status", "fields", allow_csv=True)
    assert out == ["summary", "description", "status"]


def test_coerce_arr_csv_skips_empty_tokens():
    out = _coerce_arr("a,,b,", "fields", allow_csv=True)
    assert out == ["a", "b"]


def test_coerce_arr_json_beats_csv_when_both_possible():
    out = _coerce_arr('["a","b"]', "fields", allow_csv=True)
    assert out == ["a", "b"]


def test_coerce_arr_rejects_wrong_python_type():
    with pytest.raises(ValueError, match="ops must be a list.*got int"):
        _coerce_arr(42, "ops")


# adf.to_adf_doc


def test_adf_parses_json_array_string_as_blocks():
    raw = '[{"h": 2, "text": "Hello"}, {"panel": "info", "content": [{"p": "hi"}]}]'
    doc = to_adf_doc(raw)
    types = [b["type"] for b in doc["content"]]
    assert "heading" in types
    assert "panel" in types
    heading = next(b for b in doc["content"] if b["type"] == "heading")
    assert heading["content"][0]["text"] == "Hello"


def test_adf_parses_json_object_string_as_single_block():
    raw = '{"p": "single paragraph"}'
    doc = to_adf_doc(raw)
    assert len(doc["content"]) == 1
    assert doc["content"][0]["type"] == "paragraph"
    assert doc["content"][0]["content"][0]["text"] == "single paragraph"


def test_adf_parses_json_doc_string_as_full_doc():
    raw = (
        '{"type": "doc", "version": 1, '
        '"content": [{"type": "paragraph", "content": [{"type": "text", "text": "ok"}]}]}'
    )
    doc = to_adf_doc(raw)
    assert doc["content"][0]["type"] == "paragraph"
    assert doc["content"][0]["content"][0]["text"] == "ok"


def test_adf_falls_back_to_markdown_when_json_parse_fails():
    md = "[Jira](https://apply-team.atlassian.net) is the source of truth."
    doc = to_adf_doc(md)
    assert len(doc["content"]) == 1
    assert doc["content"][0]["type"] == "paragraph"
    texts = [n.get("text", "") for n in doc["content"][0]["content"]]
    assert "Jira" in texts


def test_adf_falls_back_to_markdown_for_ambiguous_brace_opener():
    md = "{not valid json} should render as a paragraph."
    doc = to_adf_doc(md)
    assert doc["content"][0]["type"] == "paragraph"
    assert doc["content"][0]["content"][0]["text"].startswith("{not valid json}")


def test_adf_bare_dict_is_treated_as_single_block():
    doc = to_adf_doc({"h": 1, "text": "Title"})
    assert len(doc["content"]) == 1
    assert doc["content"][0]["type"] == "heading"


def test_adf_regression_stringified_dsl_does_not_become_text_paragraph():
    """AIE-11 live test regression guard."""
    raw = '[{"panel": "warning", "content": [{"p": "no oversubscription"}]}]'
    doc = to_adf_doc(raw)
    assert len(doc["content"]) == 1
    assert doc["content"][0]["type"] == "panel"
    assert doc["content"][0]["attrs"]["panelType"] == "warning"
