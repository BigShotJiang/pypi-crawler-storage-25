"""Tests for scheduler.build_graph, compute_schedule, and critical_path.

The Blocks direction is the single most error-prone piece of the scheduler —
reverse it and every downstream computation (topo, forward pass, critical
path, duedate writeback) silently produces mirror-image output that still
looks internally consistent. These tests pin the contract using the exact
shape Jira's REST v3 returns for the `issuelinks` field.

Jira stores "Blocks" with an active-verb ordering: for "A blocks B", A is
the inwardIssue (subject) and B is the outwardIssue (object). So on the
blocker's issuelinks, the blockee appears in the `outwardIssue` slot; on
the blockee's issuelinks, the blocker appears in the `inwardIssue` slot.
"""

from __future__ import annotations

from datetime import date

import pytest

from jira_aie_mcp.formats import to_plan_json
from jira_aie_mcp.holidays import Calendar
from jira_aie_mcp.scheduler import (
    build_graph,
    compute_schedule,
    critical_path,
)


# ---------------------------------------------------------------------------
# Jira payload fixtures — shape matches real REST v3 output
# ---------------------------------------------------------------------------


def _issue(key: str, estimate: str, links: list[dict]) -> dict:
    """Minimal Jira issue dict with just what build_graph reads."""
    return {
        "key": key,
        "fields": {
            "summary": f"Summary of {key}",
            "issuetype": {"name": "Task"},
            "status": {"name": "To Do"},
            "timetracking": {"originalEstimate": estimate},
            "issuelinks": links,
        },
    }


def _this_blocks(other_key: str) -> dict:
    """A link entry as it appears on the BLOCKER'S issue.

    When you GET issue X's links and X is the blocker ("X blocks other"),
    X sits on the inward/subject side of the link, so Jira returns the
    other end as `outwardIssue`.
    """
    return {
        "id": "99",
        "type": {
            "id": "10000",
            "name": "Blocks",
            "inward": "is blocked by",
            "outward": "blocks",
        },
        "outwardIssue": {"key": other_key},
    }


def _this_blocked_by(other_key: str) -> dict:
    """A link entry as it appears on the BLOCKEE'S issue.

    When you GET issue X's links and X is being blocked ("other blocks X"),
    X sits on the outward/object side of the link, so Jira returns the
    other end as `inwardIssue`.
    """
    return {
        "id": "99",
        "type": {
            "id": "10000",
            "name": "Blocks",
            "inward": "is blocked by",
            "outward": "blocks",
        },
        "inwardIssue": {"key": other_key},
    }


# ---------------------------------------------------------------------------
# Direction contract
# ---------------------------------------------------------------------------


def test_outward_issue_on_blocker_means_successor():
    """`outwardIssue` on an issue's link list = the issue THIS one blocks
    (Jira's Blocks uses active-verb ordering: inward = subject, outward =
    object, so on the blocker's view the blockee appears as outwardIssue).
    """
    issues = [
        _issue("AIE-1", "1d", [_this_blocks("AIE-2")]),
        _issue("AIE-2", "1d", [_this_blocked_by("AIE-1")]),
    ]
    nodes = build_graph(issues, default_days=1.0, in_scope={"AIE-1", "AIE-2"})
    assert nodes["AIE-1"].succs == ["AIE-2"]
    assert nodes["AIE-1"].preds == []
    assert nodes["AIE-2"].preds == ["AIE-1"]
    assert nodes["AIE-2"].succs == []


def test_only_blocker_side_in_scope():
    """Edges are wired even if only one end of the link is inside the JQL.

    build_graph iterates every issue's links, but both sides of a link should
    produce the same edge (with dedup). Regression guard against the
    inverted-dedup bug where the two sides would cancel each other.
    """
    issues = [_issue("AIE-1", "1d", [_this_blocks("AIE-2")])]
    nodes = build_graph(issues, default_days=1.0, in_scope={"AIE-1"})
    # AIE-2 isn't in scope so no edge should be wired.
    assert nodes["AIE-1"].succs == []
    assert nodes["AIE-1"].preds == []


def test_both_sides_record_edge_idempotently():
    """When both issues are in scope, each side's view of the link produces
    the same edge. The dedup logic must not double-count."""
    issues = [
        _issue("AIE-1", "1d", [_this_blocks("AIE-2")]),
        _issue("AIE-2", "1d", [_this_blocked_by("AIE-1")]),
    ]
    nodes = build_graph(issues, default_days=1.0, in_scope={"AIE-1", "AIE-2"})
    assert nodes["AIE-1"].succs == ["AIE-2"]
    assert nodes["AIE-2"].preds == ["AIE-1"]


def test_non_blocks_links_ignored():
    """Relates / Duplicates / Clones / Caused-by don't participate in scheduling."""
    issues = [
        _issue(
            "AIE-1",
            "1d",
            [
                {
                    "type": {"name": "Relates"},
                    "inwardIssue": {"key": "AIE-2"},
                },
                {
                    "type": {"name": "Duplicate"},
                    "outwardIssue": {"key": "AIE-3"},
                },
            ],
        ),
        _issue("AIE-2", "1d", []),
        _issue("AIE-3", "1d", []),
    ]
    nodes = build_graph(issues, default_days=1.0, in_scope={"AIE-1", "AIE-2", "AIE-3"})
    assert nodes["AIE-1"].succs == []
    assert nodes["AIE-1"].preds == []


# ---------------------------------------------------------------------------
# Diamond end-to-end (same shape as the live AIE-5 smoke test)
# ---------------------------------------------------------------------------


def _diamond_issues() -> list[dict]:
    """AIE-6 Setup (2d) → {AIE-7 A (3d), AIE-8 B (2d)} → AIE-9 Integrate (2d) → AIE-10 Validate (1d)."""
    return [
        _issue(
            "AIE-6",
            "2d",
            [_this_blocks("AIE-7"), _this_blocks("AIE-8")],
        ),
        _issue(
            "AIE-7",
            "3d",
            [_this_blocked_by("AIE-6"), _this_blocks("AIE-9")],
        ),
        _issue(
            "AIE-8",
            "2d",
            [_this_blocked_by("AIE-6"), _this_blocks("AIE-9")],
        ),
        _issue(
            "AIE-9",
            "2d",
            [
                _this_blocked_by("AIE-7"),
                _this_blocked_by("AIE-8"),
                _this_blocks("AIE-10"),
            ],
        ),
        _issue("AIE-10", "1d", [_this_blocked_by("AIE-9")]),
    ]


def test_diamond_graph_shape():
    nodes = build_graph(
        _diamond_issues(),
        default_days=3.0,
        in_scope={"AIE-6", "AIE-7", "AIE-8", "AIE-9", "AIE-10"},
    )
    assert nodes["AIE-6"].preds == []
    assert nodes["AIE-6"].succs == ["AIE-7", "AIE-8"]
    assert nodes["AIE-7"].preds == ["AIE-6"]
    assert nodes["AIE-7"].succs == ["AIE-9"]
    assert nodes["AIE-8"].preds == ["AIE-6"]
    assert nodes["AIE-8"].succs == ["AIE-9"]
    assert nodes["AIE-9"].preds == ["AIE-7", "AIE-8"]
    assert nodes["AIE-9"].succs == ["AIE-10"]
    assert nodes["AIE-10"].preds == ["AIE-9"]
    assert nodes["AIE-10"].succs == []


def test_diamond_forward_pass_skips_weekend():
    """Starting Mon 2026-05-04: Setup+A+Integrate+Validate = 2+3+2+1 = 8 workdays,
    ending Wed 2026-05-13 (spans the 2026-05-09/10 weekend)."""
    cal = Calendar()
    nodes = build_graph(
        _diamond_issues(),
        default_days=3.0,
        in_scope={"AIE-6", "AIE-7", "AIE-8", "AIE-9", "AIE-10"},
    )
    compute_schedule(nodes, date(2026, 5, 4), cal, pins={}, delays={})
    assert nodes["AIE-6"].start == date(2026, 5, 4)
    assert nodes["AIE-6"].end == date(2026, 5, 5)
    assert nodes["AIE-7"].start == date(2026, 5, 6)
    assert nodes["AIE-7"].end == date(2026, 5, 8)
    assert nodes["AIE-8"].start == date(2026, 5, 6)
    assert nodes["AIE-8"].end == date(2026, 5, 7)
    # Mon 5/11 (weekend skip)
    assert nodes["AIE-9"].start == date(2026, 5, 11)
    assert nodes["AIE-9"].end == date(2026, 5, 12)
    assert nodes["AIE-10"].start == date(2026, 5, 13)
    assert nodes["AIE-10"].end == date(2026, 5, 13)


def test_diamond_critical_path_membership():
    """Longest chain includes Setup + Branch-A + Integrate + Validate.
    Branch-B only takes 2 workdays so it's off the critical path."""
    cal = Calendar()
    nodes = build_graph(
        _diamond_issues(),
        default_days=3.0,
        in_scope={"AIE-6", "AIE-7", "AIE-8", "AIE-9", "AIE-10"},
    )
    compute_schedule(nodes, date(2026, 5, 4), cal, pins={}, delays={})
    crit = critical_path(nodes)
    assert set(crit) == {"AIE-6", "AIE-7", "AIE-9", "AIE-10"}
    assert "AIE-8" not in crit


def test_diamond_critical_path_is_chain_ordered():
    """critical_path returns the chain in root → leaf order, not sorted.

    The diamond's longest chain is Setup → Branch-A → Integrate → Validate,
    which is AIE-6 → AIE-7 → AIE-9 → AIE-10. Alphanumeric sort would put
    AIE-10 first, which is misleading when skimming the output.
    """
    cal = Calendar()
    nodes = build_graph(
        _diamond_issues(),
        default_days=3.0,
        in_scope={"AIE-6", "AIE-7", "AIE-8", "AIE-9", "AIE-10"},
    )
    compute_schedule(nodes, date(2026, 5, 4), cal, pins={}, delays={})
    crit = critical_path(nodes)
    assert crit == ["AIE-6", "AIE-7", "AIE-9", "AIE-10"], (
        "Critical path must be chain-ordered from root to leaf"
    )


# ---------------------------------------------------------------------------
# Pin / delay interaction
# ---------------------------------------------------------------------------


def test_pin_overrides_predecessor_end():
    """Pinning an issue fixes its start; the scheduler warns about this
    separately but the forward pass still honours the pin."""
    cal = Calendar()
    issues = [
        _issue("AIE-1", "2d", [_this_blocks("AIE-2")]),
        _issue("AIE-2", "1d", [_this_blocked_by("AIE-1")]),
    ]
    nodes = build_graph(issues, default_days=1.0, in_scope={"AIE-1", "AIE-2"})
    # AIE-1 normally runs Mon 5/4 → Tue 5/5, AIE-2 would be Wed 5/6.
    # Pin AIE-2 to Thu 5/7.
    compute_schedule(
        nodes,
        date(2026, 5, 4),
        cal,
        pins={"AIE-2": date(2026, 5, 7)},
        delays={},
    )
    assert nodes["AIE-2"].start == date(2026, 5, 7)
    assert nodes["AIE-2"].pinned is True


def test_delay_shifts_start():
    """A delay pushes the start N workdays later than the computed earliest."""
    cal = Calendar()
    issues = [
        _issue("AIE-1", "2d", [_this_blocks("AIE-2")]),
        _issue("AIE-2", "1d", [_this_blocked_by("AIE-1")]),
    ]
    nodes = build_graph(issues, default_days=1.0, in_scope={"AIE-1", "AIE-2"})
    # AIE-2 normally starts Wed 5/6; delay 2 workdays → Fri 5/8.
    compute_schedule(
        nodes,
        date(2026, 5, 4),
        cal,
        pins={},
        delays={"AIE-2": 2},
    )
    assert nodes["AIE-2"].start == date(2026, 5, 8)
    assert nodes["AIE-2"].delayed_by == 2


# ---------------------------------------------------------------------------
# Regression guard against the 0.1.0 inversion bug
# ---------------------------------------------------------------------------


def test_plan_json_preserves_critical_path_order():
    """to_plan_json must not re-sort critical_path — it has to come out in
    the same chain order the scheduler produced."""
    cal = Calendar()
    nodes = build_graph(
        _diamond_issues(),
        default_days=3.0,
        in_scope={"AIE-6", "AIE-7", "AIE-8", "AIE-9", "AIE-10"},
    )
    compute_schedule(nodes, date(2026, 5, 4), cal, pins={}, delays={})
    crit = critical_path(nodes)
    plan = to_plan_json(nodes, crit, date(2026, 5, 4), [], "AIE")
    assert plan["critical_path"] == ["AIE-6", "AIE-7", "AIE-9", "AIE-10"]
    # Membership still correct on each issue row.
    on_crit = {i["key"]: i["on_critical_path"] for i in plan["issues"]}
    assert on_crit == {
        "AIE-6": True,
        "AIE-7": True,
        "AIE-8": False,
        "AIE-9": True,
        "AIE-10": True,
    }


@pytest.mark.parametrize(
    "issues",
    [
        # Shape exactly as it came back from AIE-6 in the 2026-04-21 smoke test.
        [
            _issue(
                "AIE-6",
                "2d",
                [_this_blocks("AIE-7")],  # outwardIssue=AIE-7
            ),
            _issue(
                "AIE-7",
                "3d",
                [_this_blocked_by("AIE-6")],  # inwardIssue=AIE-6
            ),
        ],
    ],
)
def test_regression_blocker_is_predecessor_not_successor(issues):
    """The 0.1.0 bug made the blocker a successor of the blockee, inverting
    every schedule. This test fails loudly if that inversion returns."""
    nodes = build_graph(issues, default_days=1.0, in_scope={"AIE-6", "AIE-7"})
    assert nodes["AIE-6"].succs == ["AIE-7"], (
        "AIE-6 should block AIE-7, i.e. AIE-7 is a successor of AIE-6"
    )
    assert nodes["AIE-7"].preds == ["AIE-6"], (
        "AIE-7 is blocked by AIE-6, i.e. AIE-6 is a predecessor of AIE-7"
    )
