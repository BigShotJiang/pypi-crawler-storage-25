# Configuration

MaskStudio does not rely on credentials, environment variables, or external
services. All configuration is expressed by the value you pass to
`annotate_masks()` or to the CLI launcher.

## Input resolution flow

`maskstudio.annotate_masks(path=None)` resolves its input as follows:

1. If `path` is `None`, a native folder picker is shown. Cancelling the
   picker returns an empty `AnnotationResult` without raising.
2. If `path` points to an existing **folder**, every supported raster file
   inside is discovered in natural-sort order. Files that already end with
   `_mask.png` are ignored.
3. If `path` points to an existing **file**, the file is opened directly
   when it is a supported format and is not itself a generated mask.
4. If `path` is a non-existent filesystem entry, `FileNotFoundError` is
   raised.
5. If `path` is a file with an unsupported extension or a generated mask,
   `UnsupportedImageError` is raised.
6. If a valid folder contains no supported images, `NoImagesFoundError` is
   raised.

## Supported raster formats

The file extensions below are accepted case-insensitively:

- `.png`
- `.jpg`
- `.jpeg`
- `.bmp`
- `.tif`
- `.tiff`
- `.webp`

Any other extension is rejected with `UnsupportedImageError`.

## Python examples

```python
from pathlib import Path

import maskstudio

# 1. Ask for a folder with the graphical picker
result = maskstudio.annotate_masks()

# 2. Open a folder non-interactively
result = maskstudio.annotate_masks("/data/batch-01")

# 3. Open a single image
result = maskstudio.annotate_masks(Path("/data/batch-01/frame_007.png"))

for saved_mask in result.saved_paths:
    print(saved_mask)
```

## Shell examples

```bash
maskstudio                         # folder picker
maskstudio /data/batch-01          # folder without picker
maskstudio /data/batch-01/frame_007.png
```

The CLI returns exit code `0` in every successful run, including sessions
where the user closes the picker without saving any mask.

## Loading paths from dotenv files

MaskStudio never reads `.env` files automatically. If you want to drive a
workflow from environment-style configuration, load the variables explicitly
before calling the API:

```python
import os

from dotenv import load_dotenv

import maskstudio

load_dotenv()

result = maskstudio.annotate_masks(os.environ["MASKSTUDIO_INPUT_PATH"])
```

## Output paths

For every saved mask, MaskStudio writes `<stem>_mask.png` next to the
source image. Output is always PNG, mode `L`, with a white background
(`255`) and black annotated pixels (`0`). Re-opening an image that already
has a saved mask reloads the existing geometry so annotations are
editable.
