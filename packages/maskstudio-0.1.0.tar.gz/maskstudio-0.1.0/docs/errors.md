# Errors

MaskStudio exposes a small hierarchy of typed exceptions. Every public
exception inherits from `MaskStudioError`, so a single `except
MaskStudioError` branch catches every failure originated by the library.

## Hierarchy

```
Exception
└── MaskStudioError
    ├── NoImagesFoundError
    └── UnsupportedImageError
```

### `MaskStudioError`

Base class for every exception raised by the public API. Catch this when
you only want to react to library-level failures and let other errors
propagate.

### `NoImagesFoundError`

Raised when `annotate_masks(path=...)` receives a folder that contains no
supported images after filtering generated masks. The exception exposes a
`path` attribute with the resolved folder path.

### `UnsupportedImageError`

Raised when the input is a file whose extension is not in the supported
list or whose name already matches `*_mask.png`. The exception exposes a
`path` attribute with the resolved file path.

## Non-library exceptions

Two failure modes fall outside `MaskStudioError` because they indicate a
programmer error or filesystem issue rather than a MaskStudio rule:

- `FileNotFoundError` — the path passed to `annotate_masks` does not
  exist on disk.
- `TypeError`, `ValueError` from Pydantic — the value passed to a public
  model violates the schema (e.g. wrong type for `AnnotationRequest.path`).

## Capture patterns

### Catch every library failure

```python
import maskstudio
from maskstudio.exceptions import MaskStudioError

try:
    result = maskstudio.annotate_masks("/data/batch-01")
except MaskStudioError as error:
    print(f"MaskStudio failed: {error}")
```

### React to specific failures

```python
import maskstudio
from maskstudio.exceptions import (
    MaskStudioError,
    NoImagesFoundError,
    UnsupportedImageError,
)

try:
    result = maskstudio.annotate_masks("/data/batch-01")
except NoImagesFoundError as error:
    print(f"Folder has no supported images: {error.path}")
except UnsupportedImageError as error:
    print(f"Unsupported file: {error.path}")
except MaskStudioError as error:
    print(f"Unexpected MaskStudio failure: {error}")
```

### Separate I/O errors from library rules

```python
import maskstudio
from maskstudio.exceptions import MaskStudioError

try:
    result = maskstudio.annotate_masks("/data/does-not-exist")
except FileNotFoundError as error:
    print(f"Path not found: {error}")
except MaskStudioError as error:
    print(f"MaskStudio failed: {error}")
```

## Good practices

- Prefer the narrowest exception that still describes the failure mode
  you intend to handle — catching `MaskStudioError` is only appropriate as
  a fallback or at application boundaries.
- Always read the `.path` attribute of `NoImagesFoundError` and
  `UnsupportedImageError` when surfacing the message to the user; it is
  already resolved to an absolute path.
- Do not catch `FileNotFoundError` together with `MaskStudioError` unless
  you explicitly intend to treat missing paths as library failures.
