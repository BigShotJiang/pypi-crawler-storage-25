# Changelog

Todas as mudanças relevantes do MaskStudio são registradas neste arquivo.

## [0.1.0] - 2026-04-17

### Adicionado

- Função pública `annotate_masks(path=None)` que abre a GUI e retorna um
  `AnnotationResult`.
- CLI instalado (`maskstudio`) com argumento opcional de pasta ou imagem.
- Modelos Pydantic v2 públicos: `AnnotationRequest` e `AnnotationResult`
  (`frozen=True`, `extra="forbid"`).
- Hierarquia tipada de exceções: `MaskStudioError`, `NoImagesFoundError` e
  `UnsupportedImageError`.
- Descoberta determinística de imagens com ordenação natural e suporte a
  `.png`, `.jpg`, `.jpeg`, `.bmp`, `.tif`, `.tiff`, `.webp`.
- Ferramentas de anotação: seleção, pincel, polígono, retângulo, buraco,
  edição de contorno, pan e ROI.
- Refinamento com suavização Laplaciana e snap de bordas via Canny.
- Histórico por documento com undo/redo limitado e snapshots imutáveis.
- Persistência de máscara em `<stem>_mask.png` no mesmo diretório da imagem
  (modo `L`, fundo branco, anotações em preto).
- Layout split view com overview e detalhe sincronizados por ROI editável.
- Catálogo de traduções em inglês para rótulos da UI.
- Marcador PEP 561 (`py.typed`) incluído no wheel.
- Suíte de testes com smoke de imports, API, descoberta, histórico, refino,
  geometria, máscara I/O e validação automática da documentação.
