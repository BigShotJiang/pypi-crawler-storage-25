from __future__ import annotations

from maskstudio._core.domain.geometry import GeometryEngine


def test_undo_redo_round_trip_is_stable(sample_controller) -> None:
    controller = sample_controller
    original = controller.current_document.snapshot()
    controller.apply_add_geometry(GeometryEngine.rectangle((10, 10), (60, 60)))
    changed = controller.current_document.snapshot()
    assert changed != original
    controller.undo()
    assert controller.current_document.snapshot() == original
    controller.redo()
    assert controller.current_document.snapshot() == changed
