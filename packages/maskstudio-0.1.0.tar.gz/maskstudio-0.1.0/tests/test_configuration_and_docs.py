"""Validações automáticas para manter README e docs alinhados ao código.

Este módulo garante que:
- Cada operação e exceção pública mencionada no código apareça no README.
- Todos os blocos `python` em arquivos Markdown são sintaxe Python válida.

Última atualização: 2026-04-17.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _read(path):
    return path.read_text(encoding="utf-8")


def test_readme_menciona_operacoes_publicas():
    """README cita todas as operações e exceções expostas no pacote."""

    readme = _read(PROJECT_ROOT / "README.md")
    expected_symbols = [
        "annotate_masks",
        "AnnotationRequest",
        "AnnotationResult",
        "MaskStudioError",
        "NoImagesFoundError",
        "UnsupportedImageError",
        "__version__",
    ]
    for symbol in expected_symbols:
        assert symbol in readme, f"símbolo público ausente do README: {symbol}"


def test_readme_lista_formatos_suportados():
    """README menciona todas as extensões de imagem suportadas pelo discovery."""

    from maskstudio._core.io.discovery import SUPPORTED_IMAGE_EXTENSIONS

    readme = _read(PROJECT_ROOT / "README.md")
    for extension in SUPPORTED_IMAGE_EXTENSIONS:
        assert extension in readme, f"extensão ausente do README: {extension}"


@pytest.mark.parametrize(
    "markdown_path",
    sorted(
        [
            PROJECT_ROOT / "README.md",
            PROJECT_ROOT / "CHANGELOG.md",
            PROJECT_ROOT / "CONTRIBUTING.md",
            PROJECT_ROOT / "docs" / "configuration.md",
            PROJECT_ROOT / "docs" / "errors.md",
        ]
    ),
    ids=lambda p: p.relative_to(PROJECT_ROOT).as_posix(),
)
def test_python_code_blocks_compilam(markdown_path):
    """Todo bloco ```python``` em arquivos Markdown deve compilar sem SyntaxError."""

    content = _read(markdown_path)
    blocks = re.findall(r"```python\n(.*?)```", content, re.DOTALL)
    for index, block in enumerate(blocks, start=1):
        try:
            compile(block, f"{markdown_path.name}:python:{index}", "exec")
        except SyntaxError as error:
            raise AssertionError(
                f"Bloco python inválido em {markdown_path}:{error.lineno} — {error.msg}"
            ) from error


def test_changelog_registra_versao_atual():
    """CHANGELOG.md registra a versão atual do pacote."""

    import maskstudio

    changelog = _read(PROJECT_ROOT / "CHANGELOG.md")
    assert f"[{maskstudio.__version__}]" in changelog


def test_pyproject_versao_bate_com_pacote():
    """pyproject.toml declara a mesma versão exposta em `maskstudio.__version__`."""

    import maskstudio

    pyproject = _read(PROJECT_ROOT / "pyproject.toml")
    match = re.search(r'^version\s*=\s*"([^"]+)"', pyproject, re.MULTILINE)
    assert match is not None, "campo version ausente em pyproject.toml"
    assert match.group(1) == maskstudio.__version__
