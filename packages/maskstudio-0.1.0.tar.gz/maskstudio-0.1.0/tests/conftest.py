"""Fixtures compartilhadas para a suíte de testes do MaskStudio.

Última atualização: 2026-04-17.
"""

from __future__ import annotations

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from pathlib import Path

import pytest
from PIL import Image

from maskstudio._core.app.controller import WorkspaceController


@pytest.fixture()
def image_factory(tmp_path):
    """Retorna função auxiliar que cria imagens de teste no diretório temporário."""

    def _create(name, size=(160, 120), color=(220, 220, 220)):
        path = tmp_path / name
        image = Image.new("RGB", size, color)
        image.save(path)
        return path

    return _create


@pytest.fixture()
def sample_image(image_factory) -> Path:
    """Cria uma imagem RGB padrão para testes que precisam de um único arquivo."""

    return image_factory("sample.png", size=(200, 140))


@pytest.fixture()
def sample_controller(sample_image) -> WorkspaceController:
    """Instancia um `WorkspaceController` a partir de uma imagem de teste."""

    return WorkspaceController([sample_image])
