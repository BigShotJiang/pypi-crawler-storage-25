from __future__ import annotations

import numpy as np
from PIL import Image, ImageDraw

from maskstudio._core.domain.geometry import GeometryEngine
from maskstudio._core.domain.models import RefinementOptions
from maskstudio._core.domain.refinement import ContourRefiner


def test_refinement_returns_valid_geometry(tmp_path) -> None:
    path = tmp_path / "edges.png"
    image = Image.new("RGB", (160, 160), "white")
    draw = ImageDraw.Draw(image)
    draw.rectangle((50, 40, 110, 120), outline="black", width=3)
    image.save(path)
    geometry = GeometryEngine.rectangle((46, 36), (114, 124))
    refiner = ContourRefiner()
    refined = refiner.refine(
        geometry,
        np.array(image),
        RefinementOptions(enable_smooth=True, enable_edge_snap=True, edge_radius=8),
    )
    assert refined.is_valid
    assert not refined.is_empty
