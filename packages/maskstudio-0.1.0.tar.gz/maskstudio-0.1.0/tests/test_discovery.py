from __future__ import annotations

from pathlib import Path

from maskstudio._core.io.discovery import discover_images, resolve_input_images


def test_discovery_uses_natural_sort_and_ignores_masks(tmp_path, image_factory) -> None:
    image_factory("frame10.png")
    image_factory("frame2.png")
    image_factory("frame1.JPG")
    image_factory("frame2_mask.png")
    image_factory("frame11_mask.PNG")
    paths = discover_images(tmp_path)
    assert [path.name for path in paths] == ["frame1.JPG", "frame2.png", "frame10.png"]


def test_resolve_input_images_supports_single_file(sample_image: Path) -> None:
    assert resolve_input_images(sample_image) == [sample_image.resolve()]
