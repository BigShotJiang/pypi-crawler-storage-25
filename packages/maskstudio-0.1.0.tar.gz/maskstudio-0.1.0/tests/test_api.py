"""Testes da API pública `annotate_masks` usando fake adapters.

Última atualização: 2026-04-17.
"""

from __future__ import annotations

import inspect

import pytest
from PIL import Image

import maskstudio
from maskstudio import annotate_masks
from maskstudio.exceptions import NoImagesFoundError, UnsupportedImageError
from maskstudio.models import AnnotationResult


def test_public_api_signature_uses_default_none():
    """A assinatura pública mantém `path` opcional com default `None`."""

    signature = inspect.signature(annotate_masks)
    parameter = signature.parameters["path"]
    assert parameter.default is None


def test_annotate_masks_without_path_uses_picker(monkeypatch, tmp_path):
    """Quando `path` é None, o seletor gráfico é utilizado."""

    folder = tmp_path / "images"
    folder.mkdir()
    image_path = folder / "frame.png"
    Image.new("RGB", (20, 20), "white").save(image_path)
    saved_path = folder / "frame_mask.png"

    _install_fake_qt(monkeypatch)
    monkeypatch.setattr("maskstudio._core.ui.dialogs.pick_workspace_path", lambda: folder)
    monkeypatch.setattr(
        "maskstudio._core.io.discovery.resolve_input_images",
        lambda path: [image_path],
    )
    monkeypatch.setattr(
        "maskstudio._core.app.controller.WorkspaceController.__init__",
        lambda self, paths: None,
    )
    monkeypatch.setattr(
        "maskstudio._core.app.controller.WorkspaceController.run",
        lambda self, owns_app=False: [saved_path],
    )

    result = annotate_masks()
    assert isinstance(result, AnnotationResult)
    assert result.saved_paths == (saved_path,)


def test_annotate_masks_with_single_file(monkeypatch, sample_image):
    """Caminho único é aceito diretamente sem disparar o seletor."""

    saved_path = sample_image.with_name("sample_mask.png")

    _install_fake_qt(monkeypatch)
    monkeypatch.setattr(
        "maskstudio._core.io.discovery.resolve_input_images",
        lambda path: [sample_image],
    )
    monkeypatch.setattr(
        "maskstudio._core.app.controller.WorkspaceController.__init__",
        lambda self, paths: None,
    )
    monkeypatch.setattr(
        "maskstudio._core.app.controller.WorkspaceController.run",
        lambda self, owns_app=False: [saved_path],
    )

    result = annotate_masks(sample_image)
    assert tuple(result) == (saved_path,)
    assert len(result) == 1


def test_annotate_masks_missing_path_raises_file_not_found(monkeypatch, tmp_path):
    """Caminho inexistente levanta FileNotFoundError."""

    _install_fake_qt(monkeypatch)
    with pytest.raises(FileNotFoundError):
        annotate_masks(tmp_path / "does-not-exist.png")


def test_annotate_masks_unsupported_file_raises(monkeypatch, tmp_path):
    """Arquivo com extensão fora da lista gera UnsupportedImageError."""

    bogus = tmp_path / "note.txt"
    bogus.write_text("not an image", encoding="utf-8")
    _install_fake_qt(monkeypatch)
    with pytest.raises(UnsupportedImageError):
        annotate_masks(bogus)


def test_annotate_masks_empty_folder_raises(monkeypatch, tmp_path):
    """Pasta sem imagens suportadas levanta NoImagesFoundError."""

    empty = tmp_path / "empty"
    empty.mkdir()
    _install_fake_qt(monkeypatch)
    with pytest.raises(NoImagesFoundError):
        annotate_masks(empty)


def test_annotate_masks_cancelled_picker_returns_empty(monkeypatch):
    """Fechar o seletor sem escolha retorna um `AnnotationResult` vazio."""

    _install_fake_qt(monkeypatch)
    monkeypatch.setattr("maskstudio._core.ui.dialogs.pick_workspace_path", lambda: None)
    result = annotate_masks()
    assert result.saved_paths == ()
    assert len(result) == 0


def test_public_version_matches_module_constant():
    """A constante `__version__` é acessível e em formato semver simples."""

    assert isinstance(maskstudio.__version__, str)
    assert maskstudio.__version__.count(".") >= 1


def _install_fake_qt(monkeypatch):
    """Substitui o ícone e desliga `app.setWindowIcon` antes de instanciar a GUI."""

    class _FakeApp:
        def setWindowIcon(self, icon):
            pass

        def exec(self):
            return 0

    fake_app = _FakeApp()
    monkeypatch.setattr(
        "PySide6.QtWidgets.QApplication.instance", staticmethod(lambda: fake_app)
    )
    monkeypatch.setattr(
        "maskstudio._core.ui.main_window._make_app_icon", lambda: object()
    )
