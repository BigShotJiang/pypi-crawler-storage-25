from __future__ import annotations

import numpy as np
from PIL import Image
from shapely.geometry import Point

from maskstudio._core.app.controller import WorkspaceController
from maskstudio._core.domain.geometry import GeometryEngine
from maskstudio._core.domain.rasterize import MaskRasterizer
from maskstudio._core.domain.vectorize import MaskVectorizer
from maskstudio._core.io.masks import load_existing_mask_geometry, mask_output_path


def test_mask_output_rules_and_resume(sample_image) -> None:
    rasterizer = MaskRasterizer()
    vectorizer = MaskVectorizer()
    outer = Point(90, 70).buffer(40)
    hole = Point(90, 70).buffer(15)
    geometry = GeometryEngine.subtract(outer, hole)
    target = mask_output_path(sample_image)
    image = rasterizer.rasterize(geometry, (200, 140))
    image.save(target)

    with Image.open(target) as saved:
        array = np.array(saved)
        assert saved.mode == "L"
        assert saved.size == (200, 140)
        assert set(np.unique(array)) <= {0, 255}
        assert array[70, 90] == 255
        assert array[70, 55] == 0

    resumed = load_existing_mask_geometry(sample_image, vectorizer)
    polygons = GeometryEngine.polygons(resumed)
    assert len(polygons) == 1
    assert len(polygons[0].interiors) == 1


def test_display_settings_do_not_leak_into_saved_png(sample_image) -> None:
    controller = WorkspaceController([sample_image])
    controller.set_overlay_color("#ff00ff")
    controller.set_overlay_opacity(0.12)
    controller.set_outline_width(7.0)
    controller.set_brightness(60)
    controller.set_contrast(80)
    controller.apply_add_geometry(GeometryEngine.rectangle((30, 20), (120, 100)))
    saved = controller.save_current()

    with Image.open(saved) as image:
        array = np.array(image)
        assert image.mode == "L"
        assert set(np.unique(array)) <= {0, 255}
