from __future__ import annotations

import numpy as np

from maskstudio._core.domain.geometry import GeometryEngine
from maskstudio._core.domain.rasterize import MaskRasterizer


def test_touching_regions_merge_into_one_polygon() -> None:
    first = GeometryEngine.rectangle((10, 10), (40, 40))
    second = GeometryEngine.rectangle((40, 10), (70, 40))
    merged = GeometryEngine.union(first, second)
    assert len(GeometryEngine.polygons(merged)) == 1


def test_hole_tool_produces_white_interior() -> None:
    outer = GeometryEngine.rectangle((20, 20), (120, 120))
    hole = GeometryEngine.rectangle((50, 50), (90, 90))
    geometry = GeometryEngine.subtract(outer, hole)
    image = MaskRasterizer().rasterize(geometry, (140, 140))
    array = np.array(image)
    assert array[30, 30] == 0
    assert array[60, 60] == 255
