"""Smoke test: garante que todos os símbolos públicos podem ser importados.

Última atualização: 2026-04-17.
"""

from __future__ import annotations


def test_import_package_exports_public_symbols():
    """Importação do pacote expõe a API prometida no README."""

    import maskstudio

    assert callable(maskstudio.annotate_masks)
    assert isinstance(maskstudio.__version__, str)
    assert maskstudio.VERSION == maskstudio.__version__

    expected_attrs = {
        "annotate_masks",
        "AnnotationRequest",
        "AnnotationResult",
        "MaskStudioError",
        "NoImagesFoundError",
        "UnsupportedImageError",
        "__version__",
        "VERSION",
    }
    for attr in expected_attrs:
        assert hasattr(maskstudio, attr), f"público ausente: {attr}"


def test_import_models_and_exceptions():
    """Submódulos `models` e `exceptions` expõem classes documentadas."""

    from maskstudio.exceptions import (
        MaskStudioError,
        NoImagesFoundError,
        UnsupportedImageError,
    )
    from maskstudio.models import AnnotationRequest, AnnotationResult

    assert issubclass(NoImagesFoundError, MaskStudioError)
    assert issubclass(UnsupportedImageError, MaskStudioError)

    request = AnnotationRequest()
    assert request.path is None
    assert request.model_config["frozen"] is True

    result = AnnotationResult()
    assert result.saved_paths == ()
    assert len(result) == 0
    assert result.model_config["frozen"] is True


def test_pytyped_marker_is_distributed():
    """O marcador PEP 561 existe dentro do pacote instalado."""

    import maskstudio

    package_dir = maskstudio.__file__
    assert package_dir.endswith("__init__.py")

    from pathlib import Path

    marker = Path(package_dir).parent / "py.typed"
    assert marker.exists()
