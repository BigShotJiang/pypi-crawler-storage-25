# Contributing

Obrigado pelo interesse em contribuir com o MaskStudio. Este guia cobre a
configuração do ambiente de desenvolvimento, execução de testes, lint,
estrutura do projeto e o processo completo de build e publicação no PyPI.

## Development setup

```bash
git clone https://github.com/reiarthur/maskstudio.git
cd maskstudio
python -m venv .venv
. .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

Em sistemas Linux, garanta que exista uma sessão X11 ou Wayland disponível
para validar manualmente a GUI. Em headless, apenas os testes automatizados
rodam (eles não dependem de display).

## Running tests

```bash
pytest
```

A suíte usa `pytest-asyncio` e valida imports, API, descoberta de imagens,
histórico, refinamento, geometria, máscara I/O e a consistência entre a
documentação e o código.

## Linting

```bash
ruff check src tests
```

O projeto usa as regras `E`, `F`, `I`, `B` e `UP`, com `target-version =
py312` e `line-length = 100`.

## Project structure

```
src/maskstudio/
├── __init__.py          # API pública + __version__
├── exceptions.py        # Hierarquia tipada de exceções
├── models.py            # Modelos Pydantic v2 (frozen)
├── py.typed             # Marcador PEP 561
└── _core/               # Implementação interna (não é API pública)
    ├── api.py           # Orquestração do fluxo annotate_masks
    ├── launcher.py      # Entry point da CLI instalada
    ├── qt_bootstrap.py  # Pré-carregamento de bibliotecas Qt
    ├── app/             # Controller e estado de sessão
    ├── domain/          # Geometria, rasterização, vetorização, refino
    ├── i18n/            # Catálogo de traduções da UI
    ├── io/              # Descoberta, I/O de imagens e máscaras
    └── ui/              # Widgets, cenas, views e diálogos Qt
tests/                   # pytest suite
docs/                    # Documentação de suporte
```

A API pública vive estritamente em `src/maskstudio/__init__.py`,
`models.py` e `exceptions.py`. Tudo em `_core/` é implementação interna e
pode mudar sem aviso entre versões minor enquanto estivermos em `0.x`.

## Adding features

1. Implemente a lógica dentro de `src/maskstudio/_core/` seguindo a
   organização por camada (`app`, `domain`, `io`, `ui`, `i18n`).
2. Se a feature expõe símbolos estáveis ao consumidor, exporte via
   `src/maskstudio/__init__.py`, `models.py` ou `exceptions.py` — nomes
   públicos devem ser em inglês.
3. Atualize o README com exemplos executáveis da nova operação.
4. Registre a mudança em `CHANGELOG.md`.
5. Adicione testes cobrindo os fluxos relevantes em `tests/`.
6. Rode `pytest`, `ruff check src tests`, `python -m build` e
   `twine check dist/*` antes de abrir o PR.

## Build and publish

### 1. Atualize a versão

Edite o campo `version` em `pyproject.toml` e a constante `__version__` em
`src/maskstudio/__init__.py` para o novo número da release (eles devem
sempre bater). Atualize `CHANGELOG.md` com a nova seção.

### 2. Validações obrigatórias

```bash
pytest
ruff check src tests
python -m build
twine check dist/*
```

Todos os comandos devem concluir sem erro antes da publicação.

### 3. Push para o GitHub

```bash
git add -A
git commit -m "Release vX.Y.Z"
git tag vX.Y.Z
git push origin main --tags
```

### 4. Upload ao PyPI

```bash
python -m build
TWINE_USERNAME="__token__" TWINE_PASSWORD="<seu_token_pypi>" twine upload dist/*
```

O token deve ser armazenado fora do repositório (ex: gerenciador de
segredos ou variável de ambiente). Nunca commit um token do PyPI.

### 5. Verificação pós-publicação

```bash
pip install --upgrade maskstudio
python -c "import maskstudio; print(maskstudio.__version__)"
```

Confirme que `https://pypi.org/project/maskstudio/X.Y.Z/` está acessível.
