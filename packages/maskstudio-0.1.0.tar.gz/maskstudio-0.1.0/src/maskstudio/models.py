"""Public Pydantic v2 models exposed by the MaskStudio API.

Modelos imutáveis (`frozen=True`) usados como request/result estáveis na
fronteira pública da biblioteca.

Última atualização: 2026-04-17.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field


class AnnotationRequest(BaseModel):
    """Parâmetros de entrada para iniciar uma sessão de anotação."""

    model_config = ConfigDict(
        frozen=True,
        extra="forbid",
        arbitrary_types_allowed=True,
        str_strip_whitespace=True,
    )

    path: Path | None = Field(
        default=None,
        description="Pasta ou imagem a abrir; None exibe o seletor gráfico.",
    )


class AnnotationResult(BaseModel):
    """Resultado de uma sessão de anotação finalizada."""

    model_config = ConfigDict(
        frozen=True,
        extra="forbid",
        arbitrary_types_allowed=True,
        str_strip_whitespace=True,
    )

    saved_paths: tuple[Path, ...] = Field(
        default_factory=tuple,
        description="Caminhos dos arquivos `_mask.png` salvos na sessão.",
    )

    def __iter__(self):
        """Permite iterar diretamente sobre os caminhos salvos."""

        return iter(self.saved_paths)

    def __len__(self):
        """Retorna a quantidade de máscaras salvas na sessão."""

        return len(self.saved_paths)


__all__ = ["AnnotationRequest", "AnnotationResult"]
