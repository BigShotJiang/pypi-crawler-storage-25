"""Public package entry point for MaskStudio.

Mantém `import maskstudio` barato: dependências pesadas (PySide6, OpenCV,
Pillow, Shapely) são carregadas apenas quando `annotate_masks()` é chamado.

Última atualização: 2026-04-17.
"""

from __future__ import annotations

from maskstudio.exceptions import (
    MaskStudioError,
    NoImagesFoundError,
    UnsupportedImageError,
)
from maskstudio.models import AnnotationRequest, AnnotationResult

__version__ = "0.1.0"

VERSION = __version__


def annotate_masks(path=None):
    """Opens the annotation GUI and returns the session result.

    ### Parâmetros:
        path (str | Path | None): Pasta ou imagem a abrir. Quando `None`,
            um seletor de diretório gráfico é exibido.

    ### Retorna:
        AnnotationResult: Contém `saved_paths` em ordem de salvamento.

    ### Exceções:
        NoImagesFoundError: Pasta não contém imagens suportadas.
        UnsupportedImageError: Arquivo informado não é imagem suportada.
        FileNotFoundError: Caminho informado não existe.

    ### Exemplo de Uso:
        ```python
        import maskstudio

        result = maskstudio.annotate_masks("/path/to/folder")
        for saved_mask in result:
            print(saved_mask)
        ```
    """

    from maskstudio._core.api import annotate_masks_impl

    return annotate_masks_impl(path)


__all__ = [
    "__version__",
    "VERSION",
    "annotate_masks",
    "AnnotationRequest",
    "AnnotationResult",
    "MaskStudioError",
    "NoImagesFoundError",
    "UnsupportedImageError",
]
