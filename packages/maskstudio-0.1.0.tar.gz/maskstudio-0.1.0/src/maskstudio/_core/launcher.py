"""Launcher helpers for the installed GUI entry point."""

from __future__ import annotations

import argparse
from pathlib import Path

from maskstudio._core.api import annotate_masks


def build_parser() -> argparse.ArgumentParser:
    """Create the command-line parser for the GUI launcher."""

    parser = argparse.ArgumentParser(description="Launch the MaskStudio GUI.")
    parser.add_argument("path", nargs="?", help="Optional folder or image path to open.")
    return parser


def main() -> int:
    """Run the installed GUI launcher."""

    args = build_parser().parse_args()
    path = Path(args.path).expanduser() if args.path else None
    annotate_masks(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

