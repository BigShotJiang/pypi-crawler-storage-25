"""Runtime helpers for loading Qt dependencies from the active conda environment."""

from __future__ import annotations

import ctypes
import os
import sys
from pathlib import Path

_BOOTSTRAPPED = False


def ensure_qt_runtime() -> None:
    """Preload common Qt shared libraries from the active conda environment."""

    global _BOOTSTRAPPED
    if _BOOTSTRAPPED or sys.platform != "linux":
        return

    prefix = Path(os.environ.get("CONDA_PREFIX", sys.prefix))
    lib_dir = prefix / "lib"
    if not lib_dir.exists():
        _BOOTSTRAPPED = True
        return

    load_mode = getattr(ctypes, "RTLD_GLOBAL", 0)
    for library_name in [
        "libX11.so.6",
        "libfontconfig.so.1",
        "libfreetype.so.6",
        "libgthread-2.0.so.0",
        "libxkbcommon.so.0",
        "libxkbcommon-x11.so.0",
        "libGL.so.1",
        "libEGL.so.1",
        "libglib-2.0.so.0",
    ]:
        candidate = lib_dir / library_name
        if candidate.exists():
            try:
                ctypes.CDLL(str(candidate), mode=load_mode)
            except OSError:
                continue
    _BOOTSTRAPPED = True
