"""Helpers de construção da toolbar para a janela principal.
Última atualização: 2026-04-17.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QAction, QActionGroup, QColor, QKeySequence, QPainter, QPixmap
from PySide6.QtWidgets import (
    QComboBox,
    QMainWindow,
    QPushButton,
    QStyle,
    QToolBar,
    QWidgetAction,
)

from maskstudio._core.domain.models import ToolKind


@dataclass(slots=True)
class ToolbarBundle:
    """Referências à toolbar e suas ações."""

    toolbar: QToolBar
    tool_actions: dict[ToolKind, QAction] = field(default_factory=dict)
    save_action: QAction | None = None
    previous_action: QAction | None = None
    next_action: QAction | None = None
    undo_action: QWidgetAction | None = None
    redo_action: QWidgetAction | None = None
    clear_action: QAction | None = None
    shortcuts_action: QAction | None = None
    theme_combo: QComboBox | None = None


def build_toolbar(window: QMainWindow, controller) -> ToolbarBundle:
    """Constrói a toolbar principal e retorna referências às ações."""

    toolbar = QToolBar(window)
    toolbar.setMovable(False)
    bundle = ToolbarBundle(toolbar=toolbar)

    bundle.previous_action = _make_action(
        window,
        text="Previous Image",
        icon=window.style().standardIcon(QStyle.StandardPixmap.SP_ArrowBack),
        shortcut="A",
        callback=controller.go_previous,
        tooltip="Previous image  (A)",
    )
    bundle.next_action = _make_action(
        window,
        text="Save & Next Image",
        icon=window.style().standardIcon(QStyle.StandardPixmap.SP_ArrowForward),
        shortcut="D",
        callback=controller.save_and_next,
        tooltip="Save if modified, then go to next image  (D)",
    )
    bundle.save_action = _make_action(
        window,
        text="Save",
        icon=window.style().standardIcon(QStyle.StandardPixmap.SP_DialogSaveButton),
        shortcut=QKeySequence.StandardKey.Save,
        callback=controller.save_current,
        tooltip="Save mask  (Ctrl+S)",
    )
    toolbar.addAction(bundle.previous_action)
    toolbar.addAction(bundle.next_action)
    toolbar.addAction(bundle.save_action)
    toolbar.addSeparator()

    # Undo/Redo com botões de fonte maior para boa visibilidade
    bundle.undo_action, _ = _make_symbol_action(
        window, toolbar, "↩",
        shortcut=QKeySequence.StandardKey.Undo,
        callback=controller.undo,
        tooltip="Undo  (Ctrl+Z)",
    )
    bundle.redo_action, _ = _make_symbol_action(
        window, toolbar, "↪",
        shortcut=QKeySequence.StandardKey.Redo,
        callback=controller.redo,
        tooltip="Redo  (Ctrl+Y)",
    )
    toolbar.addSeparator()

    # Grupo de ferramentas
    tool_group = QActionGroup(window)
    tool_group.setExclusive(True)
    tool_specs = [
        (ToolKind.SELECTION, "Select", "V"),
        (ToolKind.BRUSH, "Brush", "B"),
        (ToolKind.POLYGON, "Polygon", "P"),
        (ToolKind.RECTANGLE, "Rectangle", "R"),
        (ToolKind.HOLE, "Hole", "H"),
        (ToolKind.CONTOUR_EDIT, "Contour Edit", "E"),
    ]
    for tool, label, shortcut in tool_specs:
        action = _make_action(
            window,
            text=label,
            icon=None,
            shortcut=shortcut,
            callback=lambda checked=False, t=tool: controller.set_active_tool(t),
            checkable=True,
            tooltip=f"{label}  ({shortcut})",
        )
        tool_group.addAction(action)
        toolbar.addAction(action)
        bundle.tool_actions[tool] = action
    bundle.tool_actions[ToolKind.SELECTION].setChecked(True)
    toolbar.addSeparator()

    bundle.clear_action = _make_action(
        window,
        text="Delete",
        icon=_make_trash_icon(),
        shortcut="Delete",
        callback=controller.clear_current_geometry,  # reconectado em main_window
        tooltip="Delete selected annotations  (Delete)",
    )
    toolbar.addAction(bundle.clear_action)

    bundle.shortcuts_action = _make_action(
        window,
        text="?",
        icon=None,
        shortcut=None,
        callback=window.open_shortcuts_dialog,
        tooltip="Keyboard shortcuts",
    )
    toolbar.addAction(bundle.shortcuts_action)
    toolbar.addSeparator()

    # Seletor de tema — apenas o combo, sem label
    theme_combo = QComboBox()
    theme_combo.setMinimumWidth(80)
    theme_combo.addItem("Dark", True)
    theme_combo.addItem("Light", False)
    theme_combo.setCurrentIndex(0 if controller.session.display.dark_theme else 1)
    theme_combo.currentIndexChanged.connect(
        lambda idx: controller.set_dark_theme(bool(theme_combo.itemData(idx)))
    )
    bundle.theme_combo = theme_combo
    toolbar.addWidget(theme_combo)

    return bundle


def _make_trash_icon(size: int = 22) -> object:
    """Cria um ícone de lixeira desenhado via QPainter."""

    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)

    from PySide6.QtGui import QPen
    pen = QPen(QColor("#aaaaaa"))
    pen.setWidthF(1.6)
    painter.setPen(pen)

    # Tampa
    painter.drawLine(4, 7, size - 4, 7)
    # Alça da tampa
    painter.drawRoundedRect(8, 3, 6, 5, 2, 2)
    # Corpo da lixeira
    painter.drawRoundedRect(4, 8, size - 8, size - 10, 2, 2)
    # Linhas verticais internas
    pen2 = QPen(QColor("#aaaaaa"))
    pen2.setWidthF(1.2)
    painter.setPen(pen2)
    for x_off in [7, 11, 15]:
        painter.drawLine(x_off, 10, x_off, size - 4)

    painter.end()
    from PySide6.QtGui import QIcon
    return QIcon(pixmap)


def _make_symbol_action(
    window: QMainWindow,
    toolbar: QToolBar,
    symbol: str,
    *,
    shortcut,
    callback,
    tooltip: str = "",
) -> tuple[QWidgetAction, QPushButton]:
    """Cria um QWidgetAction com QPushButton de fonte grande para símbolos."""

    btn = QPushButton(symbol, window)
    font = btn.font()
    font.setPixelSize(20)
    btn.setFont(font)
    btn.setFixedSize(QSize(36, 36))
    btn.setToolTip(tooltip)
    btn.clicked.connect(callback)
    if shortcut is not None:
        from PySide6.QtGui import QShortcut
        sc = QShortcut(shortcut if isinstance(shortcut, QKeySequence) else QKeySequence(shortcut), window)
        sc.activated.connect(callback)

    action = QWidgetAction(window)
    action.setDefaultWidget(btn)
    toolbar.addAction(action)
    return action, btn


def _make_action(
    window: QMainWindow,
    text: str,
    icon,
    *,
    shortcut,
    callback,
    checkable: bool = False,
    tooltip: str = "",
) -> QAction:
    """Cria uma QAction com ícone opcional, atalho e callback."""

    action = (
        QAction(icon, text, window)
        if icon is not None
        else QAction(text, window)
    )
    if shortcut is not None:
        action.setShortcut(shortcut)
    action.setCheckable(checkable)
    action.setToolTip(tooltip or text)
    action.triggered.connect(callback)
    return action
