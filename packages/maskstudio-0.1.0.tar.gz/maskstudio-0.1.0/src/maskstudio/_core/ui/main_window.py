"""Janela principal da aplicação de anotação de máscaras.
Última atualização: 2026-04-17.
"""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QIcon, QKeySequence, QPainter, QPixmap, QShortcut
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QSlider,
    QSplitter,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)

from maskstudio._core.ui.scene import AnnotationScene
from maskstudio._core.ui.toolbars import build_toolbar
from maskstudio._core.ui.views import DetailView, OverviewView


def _make_app_icon() -> QIcon:
    """Gera um ícone programático para a janela e barra de tarefas."""

    size = 64
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)

    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(QColor("#2a9d8f"))
    painter.drawRoundedRect(1, 1, size - 2, size - 2, 14, 14)

    painter.setBrush(QColor("#f4f7fb"))
    painter.drawRoundedRect(10, 14, 44, 36, 5, 5)

    painter.setBrush(QColor("#0f1318"))
    painter.drawRoundedRect(10, 14, 44, 18, 5, 5)
    painter.drawRect(10, 24, 44, 8)

    pen = painter.pen()
    pen.setColor(QColor("#fca311"))
    pen.setWidth(0)
    painter.setPen(pen)
    font = painter.font()
    font.setPixelSize(20)
    font.setBold(True)
    painter.setFont(font)
    painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "M")

    painter.end()
    return QIcon(pixmap)


def build_app_stylesheet(dark: bool) -> str:
    """Retorna o stylesheet da aplicação para o tema escolhido."""

    if dark:
        return """
        QMainWindow, QWidget { background: #12161d; color: #f4f7fb; }
        QToolBar { background: #18202b; border: none; spacing: 6px; padding: 6px; }
        QToolButton, QPushButton, QComboBox {
            background: #243140; border: 1px solid #31465f; border-radius: 8px; padding: 6px 10px;
        }
        QToolButton:checked { background: #2a9d8f; color: #081017; }
        QToolButton:hover, QPushButton:hover { background: #2d3e52; }
        QSlider::groove:horizontal { background: #23303c; height: 6px; border-radius: 3px; }
        QSlider::handle:horizontal {
            background: #fca311; width: 14px; margin: -4px 0; border-radius: 7px;
        }
        QGraphicsView { border: 1px solid #273443; background: #0f1318; border-radius: 12px; }
        QStatusBar { background: #18202b; color: #e6edf7; }
        QLabel { background: transparent; }
        QComboBox { min-height: 26px; }
        QTableWidget { background: #18202b; gridline-color: #273443; border: none; }
        QHeaderView::section { background: #243140; border: none; padding: 4px 8px; }
        """
    return """
    QMainWindow, QWidget { background: #f5f7fb; color: #1a2530; }
    QToolBar { background: #e9eef5; border: none; spacing: 6px; padding: 6px; }
    QToolButton, QPushButton, QComboBox {
        background: #ffffff; border: 1px solid #c7d3e0; border-radius: 8px; padding: 6px 10px;
    }
    QToolButton:checked { background: #2a9d8f; color: #ffffff; }
    QToolButton:hover, QPushButton:hover { background: #eef2f8; }
    QSlider::groove:horizontal { background: #d8e0ea; height: 6px; border-radius: 3px; }
    QSlider::handle:horizontal {
        background: #fca311; width: 14px; margin: -4px 0; border-radius: 7px;
    }
    QGraphicsView { border: 1px solid #d6e0ea; background: #ffffff; border-radius: 12px; }
    QStatusBar { background: #e9eef5; color: #1a2530; }
    QLabel { background: transparent; }
    QComboBox { min-height: 26px; }
    QTableWidget { background: #ffffff; gridline-color: #d6e0ea; border: none; }
    QHeaderView::section { background: #eef2f8; border: none; padding: 4px 8px; }
    """


class MainWindow(QMainWindow):
    """Janela principal com layout split overview/detail."""

    closed = Signal()

    def __init__(self, controller) -> None:
        super().__init__()
        self.controller = controller
        self.scene = AnnotationScene(controller)
        self.detail_view = DetailView(self.scene, controller, self)
        self.overview_view = OverviewView(self.scene, controller, self)
        self.toolbar_bundle = build_toolbar(self, controller)
        self.addToolBar(self.toolbar_bundle.toolbar)
        self.setWindowTitle("MaskStudio")
        self.setWindowIcon(_make_app_icon())
        self.setMinimumSize(1200, 760)
        self._build_central_layout()
        self._build_status_bar()
        self._connect_signals()
        self._update_status()
        self.apply_theme()

    def showEvent(self, event) -> None:
        """Garante fit correto após o widget ter tamanho real."""

        super().showEvent(event)
        self.detail_view.fit_to_roi()
        self.overview_view.fit_current()

    def open_shortcuts_dialog(self) -> None:
        """Abre o diálogo de atalhos de teclado."""

        from maskstudio._core.ui.dialogs import show_shortcuts_dialog
        show_shortcuts_dialog(self)

    def closeEvent(self, event) -> None:
        if not self.controller.confirm_close():
            event.ignore()
            return
        self.closed.emit()
        super().closeEvent(event)

    def apply_theme(self) -> None:
        """Aplica o stylesheet e atualiza elementos dinâmicos de cor."""

        self.setStyleSheet(build_app_stylesheet(self.controller.session.display.dark_theme))
        self._update_color_button()

    def _build_central_layout(self) -> None:
        central = QWidget(self)
        root = QHBoxLayout(central)
        root.setContentsMargins(12, 12, 12, 12)
        splitter = QSplitter(Qt.Orientation.Horizontal, central)
        root.addWidget(splitter)

        # Painel esquerdo: detail view
        detail_panel = QWidget(splitter)
        detail_layout = QVBoxLayout(detail_panel)
        detail_layout.setContentsMargins(0, 0, 0, 0)
        detail_layout.addWidget(self.detail_view)
        splitter.addWidget(detail_panel)

        # Painel direito: overview + controles (sem QGroupBox — sem bordas nem títulos)
        sidebar = QWidget(splitter)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(0, 0, 0, 0)
        sidebar_layout.setSpacing(8)

        # Overview — expande com a janela mantendo tamanho estável nos ajustes
        overview_container = QWidget(sidebar)
        overview_layout = QVBoxLayout(overview_container)
        overview_layout.setContentsMargins(0, 0, 0, 0)
        self.overview_view.setMinimumHeight(280)
        overview_layout.addWidget(self.overview_view)
        sidebar_layout.addWidget(overview_container, 1)

        # Display
        display_container = QWidget(sidebar)
        display_layout = QVBoxLayout(display_container)
        display_layout.setSpacing(8)
        display_layout.setContentsMargins(4, 4, 4, 4)

        # Linha: cor do overlay + slider de opacidade
        color_row = QHBoxLayout()
        color_row.setSpacing(6)
        self.overlay_color_button = QPushButton("Overlay Color", display_container)
        self.overlay_color_button.setFixedWidth(110)
        self.overlay_color_button.setToolTip("Click to choose overlay color")
        self.overlay_color_button.clicked.connect(self._open_color_dialog)
        self.opacity_slider = _build_slider(
            display_container, 5, 100,
            int(self.controller.session.display.overlay_opacity * 100),
        )
        self.opacity_slider.setToolTip("Overlay opacity")
        self.opacity_slider.valueChanged.connect(
            lambda v: self.controller.set_overlay_opacity(v / 100.0)
        )
        color_row.addWidget(self.overlay_color_button)
        color_row.addWidget(self.opacity_slider)
        display_layout.addLayout(color_row)

        # Linha: brightness
        brightness_row = QHBoxLayout()
        brightness_row.setSpacing(6)
        self.brightness_reset = QPushButton("Brightness", display_container)
        self.brightness_reset.setFixedWidth(90)
        self.brightness_reset.setToolTip("Reset brightness to 0")
        self.brightness_slider = _build_slider(
            display_container, -100, 100,
            self.controller.session.display.brightness,
        )
        self.brightness_slider.setToolTip("Brightness")
        self.brightness_slider.valueChanged.connect(self.controller.set_brightness)
        self.brightness_reset.clicked.connect(lambda: self.brightness_slider.setValue(0))
        brightness_row.addWidget(self.brightness_reset)
        brightness_row.addWidget(self.brightness_slider)
        display_layout.addLayout(brightness_row)

        # Linha: contrast
        contrast_row = QHBoxLayout()
        contrast_row.setSpacing(6)
        self.contrast_reset = QPushButton("Contrast", display_container)
        self.contrast_reset.setFixedWidth(90)
        self.contrast_reset.setToolTip("Reset contrast to 0")
        self.contrast_slider = _build_slider(
            display_container, -80, 120,
            self.controller.session.display.contrast,
        )
        self.contrast_slider.setToolTip("Contrast")
        self.contrast_slider.valueChanged.connect(self.controller.set_contrast)
        self.contrast_reset.clicked.connect(lambda: self.contrast_slider.setValue(0))
        contrast_row.addWidget(self.contrast_reset)
        contrast_row.addWidget(self.contrast_slider)
        display_layout.addLayout(contrast_row)

        sidebar_layout.addWidget(display_container, 0)

        # Contorno — três linhas (smooth, snap, scale) com botão checkable + slider
        contour_container = QWidget(sidebar)
        contour_layout = QVBoxLayout(contour_container)
        contour_layout.setSpacing(6)
        contour_layout.setContentsMargins(4, 4, 4, 4)

        button_width = 170

        # Smooth Contour: suavização Laplaciana com nível
        smooth_row = QHBoxLayout()
        smooth_row.setSpacing(6)
        self.smooth_button = QPushButton("Smooth Contour", contour_container)
        self.smooth_button.setCheckable(True)
        self.smooth_button.setFixedWidth(button_width)
        self.smooth_button.setToolTip(
            "Select a region, toggle this button and drag the slider to smooth in real time"
        )
        self.smooth_button.toggled.connect(self._on_smooth_toggled)
        self.smooth_slider = _build_slider(contour_container, 1, 25, 8)
        self.smooth_slider.setToolTip("Smoothing level")
        self.smooth_slider.setEnabled(False)
        self.smooth_slider.valueChanged.connect(self._on_smooth_value_changed)
        smooth_row.addWidget(self.smooth_button)
        smooth_row.addWidget(self.smooth_slider)
        contour_layout.addLayout(smooth_row)

        # Auto Contour Adjustment: snap de bordas com força regulável
        snap_row = QHBoxLayout()
        snap_row.setSpacing(6)
        self.snap_button = QPushButton("Auto Contour Adjustment", contour_container)
        self.snap_button.setCheckable(True)
        self.snap_button.setFixedWidth(button_width)
        self.snap_button.setToolTip(
            "Select a region, toggle this button and drag the slider to snap to edges in real time"
        )
        self.snap_button.toggled.connect(self._on_snap_toggled)
        self.snap_slider = _build_slider(contour_container, 5, 120, 55)
        self.snap_slider.setToolTip("Adjustment strength")
        self.snap_slider.setEnabled(False)
        self.snap_slider.valueChanged.connect(self._on_snap_value_changed)
        snap_row.addWidget(self.snap_button)
        snap_row.addWidget(self.snap_slider)
        contour_layout.addLayout(snap_row)

        # Scale: aumenta/diminui proporcionalmente a seleção (slider centrado em 0)
        scale_row = QHBoxLayout()
        scale_row.setSpacing(6)
        self.scale_button = QPushButton("Scale", contour_container)
        self.scale_button.setCheckable(True)
        self.scale_button.setFixedWidth(button_width)
        self.scale_button.setToolTip(
            "Select a region, toggle this button and drag the slider to scale in real time"
        )
        self.scale_button.toggled.connect(self._on_scale_toggled)
        self.scale_slider = _build_slider(contour_container, -50, 50, 0)
        self.scale_slider.setToolTip("Scale factor (right enlarges, left shrinks)")
        self.scale_slider.setEnabled(False)
        self.scale_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.scale_slider.setTickInterval(50)
        self.scale_slider.valueChanged.connect(self._on_scale_value_changed)
        scale_row.addWidget(self.scale_button)
        scale_row.addWidget(self.scale_slider)
        contour_layout.addLayout(scale_row)

        sidebar_layout.addWidget(contour_container, 0)

        splitter.addWidget(sidebar)
        splitter.setStretchFactor(0, 4)
        splitter.setStretchFactor(1, 2)
        self.setCentralWidget(central)

    def _build_status_bar(self) -> None:
        status = QStatusBar(self)
        self.index_status = QLabel(status)
        self.tool_status = QLabel(status)
        self.zoom_status = QLabel(status)
        self.state_status = QLabel(status)
        self.cursor_status = QLabel(status)
        for widget in [
            self.index_status, self.tool_status, self.zoom_status,
            self.state_status, self.cursor_status,
        ]:
            status.addPermanentWidget(widget)
        self.setStatusBar(status)

    def _connect_signals(self) -> None:
        self.controller.document_changed.connect(self._handle_document_change)
        self.controller.geometry_changed.connect(self._update_status)
        self.controller.theme_changed.connect(self.apply_theme)
        self.controller.status_changed.connect(self._update_status)
        self.controller.fit_full_requested.connect(self.detail_view.fit_full)
        self.detail_view.zoom_changed.connect(self.controller.update_zoom_percent)
        self.overview_view.zoom_changed.connect(self.controller.update_zoom_percent)

        # Trash / Delete → apaga somente selecionados (ou vértice em edição de contorno)
        self.toolbar_bundle.clear_action.triggered.disconnect()
        self.toolbar_bundle.clear_action.triggered.connect(self.scene.handle_delete)

        # ESC cancela interação ativa (preview de polígono, handles, etc.)
        esc_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Escape), self)
        esc_shortcut.activated.connect(self.scene.clear_interaction)

    def _handle_document_change(self) -> None:
        self.scene.refresh_scene()
        self._update_status()

    def _update_status(self) -> None:
        document = self.controller.current_document
        if document is None:
            return
        catalog = self.controller.catalog
        total = len(self.controller.session.images)
        current = self.controller.session.current_index + 1
        self.index_status.setText(f"Image: {current}/{total}")
        self.tool_status.setText(
            f"Tool: {catalog.get(self.controller.tool_key())}"
        )
        self.zoom_status.setText(
            f"Zoom: {self.controller.session.zoom_percent:.0f}%"
        )
        state = "Unsaved" if document.dirty else "Saved"
        self.state_status.setText(f"State: {state}")
        x, y = self.controller.session.cursor_position
        self.cursor_status.setText(f"Cursor: {x:.0f}, {y:.0f}")
        if self.controller.active_tool in self.toolbar_bundle.tool_actions:
            self.toolbar_bundle.tool_actions[self.controller.active_tool].setChecked(True)

    def _update_color_button(self) -> None:
        """Atualiza o background do botão de cor conforme a cor atual do overlay."""

        color = self.controller.session.display.overlay_color
        dark = self.controller.session.display.dark_theme
        border = "#31465f" if dark else "#c7d3e0"
        self.overlay_color_button.setStyleSheet(
            f"QPushButton {{ background-color: {color}; border: 1px solid {border}; "
            f"border-radius: 8px; padding: 6px 10px; }}"
        )

    def _on_smooth_toggled(self, checked: bool) -> None:
        """Ativa/desativa a sessão de smoothing com preview em tempo real."""

        if checked:
            self._deactivate_other_adjust_buttons(self.smooth_button)
            if not self.controller.begin_adjust_session(only_refinable=True):
                self.smooth_button.setChecked(False)
                return
            self.smooth_slider.setEnabled(True)
            self._sync_slider_value(self.smooth_slider, self.smooth_slider.value())
            self.controller.preview_smooth(self.smooth_slider.value())
        else:
            self.smooth_slider.setEnabled(False)
            self.controller.finalize_adjust_session()

    def _on_snap_toggled(self, checked: bool) -> None:
        """Ativa/desativa a sessão de snap de bordas com preview em tempo real."""

        if checked:
            self._deactivate_other_adjust_buttons(self.snap_button)
            if not self.controller.begin_adjust_session(only_refinable=True):
                self.snap_button.setChecked(False)
                return
            self.snap_slider.setEnabled(True)
            self.controller.preview_snap(self.snap_slider.value())
        else:
            self.snap_slider.setEnabled(False)
            self.controller.finalize_adjust_session()

    def _on_scale_toggled(self, checked: bool) -> None:
        """Ativa/desativa a sessão de escala proporcional com preview em tempo real."""

        if checked:
            self._deactivate_other_adjust_buttons(self.scale_button)
            if not self.controller.begin_adjust_session(only_refinable=False):
                self.scale_button.setChecked(False)
                return
            self.scale_slider.setEnabled(True)
            self.scale_slider.blockSignals(True)
            self.scale_slider.setValue(0)
            self.scale_slider.blockSignals(False)
        else:
            self.scale_slider.setEnabled(False)
            self.controller.finalize_adjust_session()

    def _on_smooth_value_changed(self, value: int) -> None:
        if self.smooth_button.isChecked():
            self.controller.preview_smooth(value)

    def _on_snap_value_changed(self, value: int) -> None:
        if self.snap_button.isChecked():
            self.controller.preview_snap(value)

    def _on_scale_value_changed(self, value: int) -> None:
        if self.scale_button.isChecked():
            self.controller.preview_scale(value)

    def _deactivate_other_adjust_buttons(self, keep: QPushButton) -> None:
        """Desmarca os botões de ajuste que não são o recém-ativado."""

        for button in (self.smooth_button, self.snap_button, self.scale_button):
            if button is not keep and button.isChecked():
                button.setChecked(False)

    def _sync_slider_value(self, slider: QSlider, value: int) -> None:
        """Garante que a posição do slider reflita o valor sem emitir sinal."""

        slider.blockSignals(True)
        slider.setValue(value)
        slider.blockSignals(False)

    def _open_color_dialog(self) -> None:
        """Abre o QColorDialog para selecionar a cor do overlay."""

        from PySide6.QtGui import QColor
        from PySide6.QtWidgets import QColorDialog

        current = QColor(self.controller.session.display.overlay_color)
        color = QColorDialog.getColor(current, self, "Overlay Color")
        if color.isValid():
            self.controller.set_overlay_color(color.name())


def _build_slider(parent: QWidget, minimum: int, maximum: int, value: int) -> QSlider:
    """Cria um QSlider horizontal com intervalo e valor inicial."""

    slider = QSlider(Qt.Orientation.Horizontal, parent)
    slider.setRange(minimum, maximum)
    slider.setValue(value)
    return slider
