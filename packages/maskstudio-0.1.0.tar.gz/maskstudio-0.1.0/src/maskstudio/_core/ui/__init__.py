"""Qt user interface package."""

from __future__ import annotations

