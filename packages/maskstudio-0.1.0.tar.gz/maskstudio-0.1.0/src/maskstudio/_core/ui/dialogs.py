"""Dialogs used by the MaskStudio user interface.
Última atualização: 2026-04-17.
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QHeaderView,
    QMessageBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


def pick_workspace_path(parent: QWidget | None = None) -> Path | None:
    """Abre o seletor de diretório e retorna o caminho escolhido."""

    selected = QFileDialog.getExistingDirectory(parent, "Choose a folder to annotate")
    if not selected:
        return None
    return Path(selected)


def show_empty_selection_warning(path: Path | None) -> None:
    """Exibe aviso quando nenhuma imagem válida é encontrada."""

    QMessageBox.warning(None, "MaskStudio", f"No supported images were found for: {path}")


def ask_unsaved_changes(parent: QWidget | None, image_name: str) -> tuple[str, bool]:
    """Pergunta como tratar alterações não salvas ao navegar ou fechar.

    ### Parâmetros:
        parent: Widget pai para centralizar o diálogo.
        image_name: Nome do arquivo com alterações pendentes.

    ### Retorna:
        Tupla (decisão, lembrar) onde decisão é "save", "discard" ou "cancel".
    """

    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Warning)
    box.setWindowTitle("MaskStudio")
    box.setText("There are unsaved changes.")
    box.setInformativeText(f"What do you want to do with the changes to:\n{image_name}")
    save_button = box.addButton("Save", QMessageBox.ButtonRole.AcceptRole)
    discard_button = box.addButton("Discard", QMessageBox.ButtonRole.DestructiveRole)
    box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
    remember_box = QCheckBox("Remember for this session")
    box.setCheckBox(remember_box)
    box.exec()
    clicked = box.clickedButton()
    if clicked == save_button:
        return ("save", remember_box.isChecked())
    if clicked == discard_button:
        return ("discard", remember_box.isChecked())
    return ("cancel", False)


_SHORTCUTS = [
    ("A", "Previous image"),
    ("D", "Next image"),
    ("Ctrl+S", "Save mask"),
    ("Ctrl+Shift+S", "Save mask and go to next image"),
    ("Ctrl+Z", "Undo"),
    ("Ctrl+Y  /  Ctrl+Shift+Z", "Redo"),
    ("Delete", "Clear all annotations"),
    ("V", "Selection tool"),
    ("B", "Brush tool"),
    ("P", "Polygon tool"),
    ("R", "Rectangle tool"),
    ("H", "Hole tool"),
    ("E", "Contour Edit tool"),
    ("Double-click", "Finalize polygon"),
    ("Click near first point", "Auto-close polygon"),
    ("Right-click on ROI", "Reset ROI to default"),
    ("Middle mouse button", "Pan view"),
    ("Scroll wheel", "Zoom in / out"),
]


def show_shortcuts_dialog(parent: QWidget | None = None) -> None:
    """Exibe um diálogo listando todos os atalhos de teclado disponíveis."""

    dialog = QDialog(parent)
    dialog.setWindowTitle("Keyboard Shortcuts")
    dialog.setMinimumWidth(460)

    table = QTableWidget(len(_SHORTCUTS), 2, dialog)
    table.setHorizontalHeaderLabels(["Shortcut", "Action"])
    table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
    table.verticalHeader().setVisible(False)
    table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
    table.setShowGrid(False)
    for row, (shortcut, action) in enumerate(_SHORTCUTS):
        table.setItem(row, 0, QTableWidgetItem(f"  {shortcut}"))
        table.setItem(row, 1, QTableWidgetItem(action))
    table.resizeColumnToContents(0)

    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close, dialog)
    buttons.rejected.connect(dialog.reject)

    layout = QVBoxLayout(dialog)
    layout.addWidget(table)
    layout.addWidget(buttons)
    dialog.exec()
