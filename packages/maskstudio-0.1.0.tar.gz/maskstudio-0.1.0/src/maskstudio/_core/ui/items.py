"""Itens QGraphics reutilizáveis para a cena de anotação.
Última atualização: 2026-04-17.
"""

from __future__ import annotations

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QColor, QPainterPath, QPen
from PySide6.QtWidgets import QGraphicsItem, QGraphicsPathItem

from maskstudio._core.domain.models import HandleDescriptor, HandleKind


class GeometryPathItem(QGraphicsPathItem):
    """Item de caminho estilizado para overlays de geometria."""

    def apply_style(
        self,
        *,
        fill_color: str,
        fill_opacity: float,
        outline_color: str,
        outline_width: float,
        outline_style: Qt.PenStyle = Qt.PenStyle.SolidLine,
    ) -> None:
        """Aplica configurações de pintura de overlay ao item."""

        fill = QColor(fill_color)
        fill.setAlphaF(fill_opacity)
        self.setBrush(fill)
        pen = QPen(QColor(outline_color))
        pen.setCosmetic(True)
        pen.setWidthF(outline_width)
        pen.setStyle(outline_style)
        self.setPen(pen)


class HandleItem(QGraphicsPathItem):
    """Item não escalável para handles de edição de contorno."""

    def __init__(self, descriptor: HandleDescriptor) -> None:
        super().__init__()
        self.descriptor = descriptor
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations, True)
        self.setZValue(30)
        self._build_shape(selected=False)

    def set_selected(self, selected: bool) -> None:
        """Altera a aparência do handle para indicar seleção."""

        self._build_shape(selected=selected)

    def _build_shape(self, selected: bool = False) -> None:
        radius = 5.0
        path = QPainterPath()
        if self.descriptor.kind is HandleKind.VERTEX:
            path.addEllipse(QPointF(0.0, 0.0), radius, radius)
            fill = QColor("#fca311") if selected else QColor("#f5f5f5")
        else:
            path.addRect(-radius * 0.8, -radius * 0.8, radius * 1.6, radius * 1.6)
            fill = QColor("#ff6b6b") if selected else QColor("#ffd166")
        self.setPath(path)
        self.setBrush(fill)
        pen = QPen(QColor("#cc4400") if selected else QColor("#111111"))
        pen.setCosmetic(True)
        pen.setWidthF(2.0 if selected else 1.5)
        self.setPen(pen)
        self.setPos(QPointF(*self.descriptor.point))
