"""Views gráficas para os editores de overview e detail.
Última atualização: 2026-04-17.
"""

from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtCore import QPoint, QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QMouseEvent, QPainter, QPen
from PySide6.QtWidgets import QGraphicsView

from maskstudio._core.domain.models import ToolKind


class BaseImageView(QGraphicsView):
    """Comportamento compartilhado para views com zoom e pan."""

    zoom_changed = Signal(float)

    def __init__(self, scene, controller, parent=None) -> None:
        super().__init__(scene, parent)
        self.controller = controller
        self.setRenderHints(
            QPainter.RenderHint.Antialiasing
            | QPainter.RenderHint.SmoothPixmapTransform
            | QPainter.RenderHint.TextAntialiasing
        )
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)
        self.setDragMode(QGraphicsView.DragMode.NoDrag)
        self.setMouseTracking(True)
        self.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.FullViewportUpdate)
        self._panning = False
        self._pan_origin = QPoint()

    def fit_current(self) -> None:
        """Ajusta a view para o conteúdo relevante."""

        self.fitInView(self.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)
        self._emit_zoom()

    def zoom_100(self) -> None:
        """Reseta o zoom para 1:1."""

        self.resetTransform()
        self._emit_zoom()

    def wheelEvent(self, event) -> None:
        """Aplica zoom com o scroll do mouse."""

        factor = 1.15 if event.angleDelta().y() > 0 else (1.0 / 1.15)
        self.scale(factor, factor)
        self._emit_zoom()

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if (
            event.button() == Qt.MouseButton.MiddleButton
            or self.controller.active_tool is ToolKind.PAN
        ):
            self._panning = True
            self._pan_origin = event.pos()
            self.viewport().setCursor(Qt.CursorShape.ClosedHandCursor)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if self._panning:
            delta = event.pos() - self._pan_origin
            self._pan_origin = event.pos()
            self.horizontalScrollBar().setValue(self.horizontalScrollBar().value() - delta.x())
            self.verticalScrollBar().setValue(self.verticalScrollBar().value() - delta.y())
            event.accept()
            return
        point = self.mapToScene(event.pos())
        self.controller.update_cursor_position(point.x(), point.y())
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if self._panning and (
            event.button() == Qt.MouseButton.MiddleButton
            or self.controller.active_tool is ToolKind.PAN
        ):
            self._panning = False
            self.viewport().unsetCursor()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._emit_zoom()

    def _emit_zoom(self) -> None:
        percent = self.transform().m11() * 100.0
        self.zoom_changed.emit(percent)


@dataclass(slots=True)
class RoiHitResult:
    """Resultado do hit-test sobre a ROI."""

    mode: str | None


class OverviewView(BaseImageView):
    """Overview da imagem completa com ROI sempre interativa.

    A ROI pode ser redimensionada e movida independentemente da ferramenta ativa.
    Nenhuma operação de desenho/anotação ocorre nesta view.
    O zoom é bloqueado — a imagem é sempre exibida por completo.
    """

    def __init__(self, scene, controller, parent=None) -> None:
        super().__init__(scene, controller, parent)
        self._roi_mode: str | None = None
        self._roi_origin = QPointF()
        self._initial_roi = QRectF()
        self.controller.document_changed.connect(self.fit_current)
        self.controller.roi_changed.connect(lambda _rect: self.viewport().update())

    def fit_current(self) -> None:
        """Ajusta a view para mostrar a imagem completa."""

        super().fit_current()

    def wheelEvent(self, event) -> None:
        """Bloqueia o zoom na overview — sempre exibe a imagem por completo."""

        event.accept()

    def resizeEvent(self, event) -> None:
        """Re-encaixa a imagem completa ao redimensionar."""

        super().resizeEvent(event)
        self.fit_current()

    def drawForeground(self, painter: QPainter, rect) -> None:
        super().drawForeground(painter, rect)
        if self.controller.session.roi is None:
            return
        roi = self.controller.session.roi.to_rect()
        scale = max(self.transform().m11(), 0.001)

        pen = QPen(QColor("#fca311"))
        pen.setWidthF(2.0)
        pen.setCosmetic(True)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(roi)

        # Alças de canto em tamanho fixo de tela (8×8 px)
        handle_size = 5.0 / scale
        for handle in self._roi_handles(roi, handle_size):
            painter.fillRect(handle, QColor("#fca311"))

    def mousePressEvent(self, event: QMouseEvent) -> None:
        # Clique direito dentro da ROI → reseta a ROI
        if event.button() == Qt.MouseButton.RightButton:
            if self.controller.session.roi is not None:
                point = self.mapToScene(event.pos())
                if self.controller.session.roi.to_rect().contains(point):
                    self.controller.reset_roi()
            event.accept()
            return

        # Pan por botão do meio ou ferramenta PAN
        if (
            event.button() == Qt.MouseButton.MiddleButton
            or self.controller.active_tool is ToolKind.PAN
        ):
            self._panning = True
            self._pan_origin = event.pos()
            self.viewport().setCursor(Qt.CursorShape.ClosedHandCursor)
            event.accept()
            return

        # Interação com ROI — sempre ativa, independente da ferramenta
        if event.button() == Qt.MouseButton.LeftButton and self.controller.session.roi is not None:
            point = self.mapToScene(event.pos())
            hit = self._hit_test_roi(point)
            if hit.mode is not None:
                self._roi_origin = point
                self._initial_roi = self.controller.session.roi.to_rect()
                self._roi_mode = hit.mode
                event.accept()
                return

        # Consome o evento — nenhum desenho no overview
        event.accept()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        # Panning
        if self._panning:
            delta = event.pos() - self._pan_origin
            self._pan_origin = event.pos()
            self.horizontalScrollBar().setValue(self.horizontalScrollBar().value() - delta.x())
            self.verticalScrollBar().setValue(self.verticalScrollBar().value() - delta.y())
            event.accept()
            return

        point = self.mapToScene(event.pos())
        self.controller.update_cursor_position(point.x(), point.y())

        # Redimensionar/mover ROI
        if self._roi_mode is not None and self.controller.session.roi is not None:
            self.controller.set_roi_rect(
                self._resize_roi(self._initial_roi, self._roi_mode, point)
            )
            event.accept()
            return

        # Atualiza cursor de hover sobre a ROI
        if self.controller.session.roi is not None:
            hit = self._hit_test_roi(point)
            self.viewport().setCursor(self._cursor_for_mode(hit.mode))
        else:
            self.viewport().unsetCursor()

        event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        # Fim do panning
        if self._panning and (
            event.button() == Qt.MouseButton.MiddleButton
            or self.controller.active_tool is ToolKind.PAN
        ):
            self._panning = False
            self.viewport().unsetCursor()
            event.accept()
            return

        # Fim do arraste de ROI — sempre re-encaixa o detail na ROI
        if self._roi_mode is not None and event.button() == Qt.MouseButton.LeftButton:
            self._roi_mode = None
            if self.controller.session.roi is not None:
                self.controller.roi_changed.emit(self.controller.session.roi.to_rect())
            event.accept()
            return

        event.accept()

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:
        """Duplo clique fora da ROI → exibe a imagem completa no detail."""

        if event.button() == Qt.MouseButton.LeftButton:
            if self.controller.session.roi is not None:
                point = self.mapToScene(event.pos())
                if not self.controller.session.roi.to_rect().contains(point):
                    self.controller.fit_full_requested.emit()
            else:
                self.controller.fit_full_requested.emit()
        event.accept()

    def _hit_test_roi(self, point: QPointF) -> RoiHitResult:
        """Testa qual parte da ROI foi clicada, com tolerância em pixels de tela."""

        roi = self.controller.session.roi.to_rect()
        # Converte 8 pixels de tela para coordenadas de cena
        scale = max(self.transform().m11(), 0.001)
        tolerance = 8.0 / scale

        corners = {
            "top_left": roi.topLeft(),
            "top_right": roi.topRight(),
            "bottom_left": roi.bottomLeft(),
            "bottom_right": roi.bottomRight(),
        }
        for mode, corner in corners.items():
            if (point - corner).manhattanLength() <= tolerance * 2.5:
                return RoiHitResult(mode)
        if abs(point.x() - roi.left()) <= tolerance and roi.top() <= point.y() <= roi.bottom():
            return RoiHitResult("left")
        if abs(point.x() - roi.right()) <= tolerance and roi.top() <= point.y() <= roi.bottom():
            return RoiHitResult("right")
        if abs(point.y() - roi.top()) <= tolerance and roi.left() <= point.x() <= roi.right():
            return RoiHitResult("top")
        if abs(point.y() - roi.bottom()) <= tolerance and roi.left() <= point.x() <= roi.right():
            return RoiHitResult("bottom")
        if roi.contains(point):
            return RoiHitResult("move")
        return RoiHitResult(None)

    def _resize_roi(self, roi: QRectF, mode: str, point: QPointF) -> QRectF:
        """Aplica a transformação de redimensionamento/movimento à ROI."""

        delta = point - self._roi_origin
        updated = QRectF(roi)
        if mode == "move":
            updated.translate(delta)
            return updated
        if "left" in mode:
            updated.setLeft(roi.left() + delta.x())
        if "right" in mode:
            updated.setRight(roi.right() + delta.x())
        if mode in {"left", "right"}:
            return updated.normalized()
        if "top" in mode:
            updated.setTop(roi.top() + delta.y())
        if "bottom" in mode:
            updated.setBottom(roi.bottom() + delta.y())
        return updated.normalized()

    def _cursor_for_mode(self, mode: str | None) -> Qt.CursorShape:
        """Retorna o cursor adequado para o modo de interação com a ROI."""

        mapping = {
            "move": Qt.CursorShape.SizeAllCursor,
            "left": Qt.CursorShape.SizeHorCursor,
            "right": Qt.CursorShape.SizeHorCursor,
            "top": Qt.CursorShape.SizeVerCursor,
            "bottom": Qt.CursorShape.SizeVerCursor,
            "top_left": Qt.CursorShape.SizeFDiagCursor,
            "bottom_right": Qt.CursorShape.SizeFDiagCursor,
            "top_right": Qt.CursorShape.SizeBDiagCursor,
            "bottom_left": Qt.CursorShape.SizeBDiagCursor,
        }
        return mapping.get(mode, Qt.CursorShape.ArrowCursor)

    def _roi_handles(self, roi: QRectF, size: float) -> list[QRectF]:
        """Retorna os retângulos das alças de canto da ROI."""

        centers = [roi.topLeft(), roi.topRight(), roi.bottomLeft(), roi.bottomRight()]
        return [
            QRectF(p.x() - size, p.y() - size, size * 2.0, size * 2.0)
            for p in centers
        ]


class DetailView(BaseImageView):
    """View de edição ampliada focada na região da ROI.

    O zoom mínimo é limitado ao nível de fit-to-view para não
    permitir zoom out além da imagem completa.
    """

    def __init__(self, scene, controller, parent=None) -> None:
        super().__init__(scene, controller, parent)
        self.controller.document_changed.connect(self.fit_to_roi)
        self.controller.roi_changed.connect(lambda _rect: self.fit_to_roi())

    def fit_current(self) -> None:
        """Ajusta a view para a ROI atual."""

        self.fit_to_roi()

    def fit_to_roi(self) -> None:
        """Centraliza e amplia a view na região da ROI."""

        if self.controller.session.roi is None:
            super().fit_current()
            return
        self.fitInView(self.controller.session.roi.to_rect(), Qt.AspectRatioMode.KeepAspectRatio)
        self._emit_zoom()

    def fit_full(self) -> None:
        """Ajusta a view para exibir a imagem completa."""

        self.fitInView(self.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)
        self._emit_zoom()

    def wheelEvent(self, event) -> None:
        """Aplica zoom respeitando o nível mínimo (fit completo).

        Quando o zoom out atinge o nível de fit, re-encaixa a imagem inteira
        para evitar recortes nas bordas superior/inferior provocados pelo
        scroll remanescente da posição anterior.
        """

        factor = 1.15 if event.angleDelta().y() > 0 else (1.0 / 1.15)
        current_scale = self.transform().m11()
        new_scale = current_scale * factor
        min_scale = self._fit_scale()
        if new_scale <= min_scale * 1.01:
            self.fit_full()
            event.accept()
            return
        self.scale(factor, factor)
        self._emit_zoom()

    def showEvent(self, event) -> None:
        """Garante o fit correto após o widget ter tamanho real."""

        super().showEvent(event)
        self.fit_to_roi()

    def _fit_scale(self) -> float:
        """Calcula a escala mínima para encaixar a cena na viewport."""

        scene_rect = self.sceneRect()
        if scene_rect.isEmpty():
            return 0.0
        vp = self.viewport().rect()
        return min(vp.width() / scene_rect.width(), vp.height() / scene_rect.height())
