"""Cena de anotação compartilhada pelos views de overview e detail.
Última atualização: 2026-04-17.
"""

from __future__ import annotations

from math import hypot

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QPainterPath, QPixmap
from PySide6.QtWidgets import QGraphicsPixmapItem, QGraphicsScene

from maskstudio._core.domain.geometry import GeometryEngine
from maskstudio._core.domain.models import DocumentState, HandleDescriptor, HandleKind, ToolKind
from maskstudio._core.ui.items import GeometryPathItem, HandleItem

# Tolerância em pixels de cena para hit-test de handles
_HANDLE_TOLERANCE = 10.0
# Limiar de movimento para distinguir clique de arrasto
_DRAG_THRESHOLD = 3.0


class AnnotationScene(QGraphicsScene):
    """Exibe e permite editar anotações sobre a imagem atual."""

    def __init__(self, controller, parent=None) -> None:
        super().__init__(parent)
        self.controller = controller
        self.image_item = QGraphicsPixmapItem()
        self.image_item.setZValue(0)
        self.overlay_item = GeometryPathItem()
        self.overlay_item.setZValue(10)
        self.selection_item = GeometryPathItem()
        self.selection_item.setZValue(15)
        self.preview_item = GeometryPathItem()
        self.preview_item.setZValue(20)
        self.temp_item = GeometryPathItem()
        self.temp_item.setZValue(25)
        self.addItem(self.image_item)
        self.addItem(self.overlay_item)
        self.addItem(self.selection_item)
        self.addItem(self.preview_item)
        self.addItem(self.temp_item)

        # Estado de interação geral
        self._handles: list[HandleItem] = []
        self._stroke_points: list[tuple[float, float]] = []
        self._polygon_points: list[tuple[float, float]] = []
        self._rectangle_origin: tuple[float, float] | None = None

        # Estado da edição de contorno
        self._editing_original: DocumentState | None = None
        self._active_handle: HandleDescriptor | None = None
        self._selected_vertex: HandleDescriptor | None = None
        self._is_dragging: bool = False
        self._press_pos: tuple[float, float] | None = None
        self._translate_mode: bool = False
        self._translate_region_index: int | None = None

        # Detecção de troca de ferramenta para limpar interação
        self._last_active_tool = controller.active_tool

        self.controller.document_changed.connect(self.refresh_scene)
        self.controller.geometry_changed.connect(self.refresh_geometry)
        self.controller.display_changed.connect(self.refresh_display)
        self.controller.status_changed.connect(self._check_tool_change)
        self.refresh_scene()

    # ------------------------------------------------------------------ #
    # Refresh público                                                      #
    # ------------------------------------------------------------------ #

    def refresh_scene(self) -> None:
        """Recarrega o pixmap, o rect da cena e os overlays."""

        document = self.controller.current_document
        if document is None:
            return
        self.clear_interaction()
        qimage = self.controller.current_qimage()
        self.image_item.setPixmap(QPixmap.fromImage(qimage))
        width, height = document.size
        self.setSceneRect(0.0, 0.0, float(width), float(height))
        self.refresh_display()
        self.refresh_geometry()

    def refresh_display(self) -> None:
        """Aplica o estilo de exibição atual aos itens de overlay."""

        display = self.controller.session.display
        self.overlay_item.apply_style(
            fill_color=display.overlay_color,
            fill_opacity=display.overlay_opacity,
            outline_color=display.outline_color,
            outline_width=display.outline_width,
        )
        self.selection_item.apply_style(
            fill_color=display.overlay_color,
            fill_opacity=0.18,
            outline_color="#fca311",
            outline_width=max(2.0, display.outline_width + 1.0),
        )
        self.preview_item.apply_style(
            fill_color="#5dade2",
            fill_opacity=0.20,
            outline_color="#8ecae6",
            outline_width=max(2.0, display.outline_width),
            outline_style=Qt.PenStyle.DashLine,
        )
        self.temp_item.apply_style(
            fill_color="#ffffff",
            fill_opacity=0.08,
            outline_color="#ffffff",
            outline_width=2.0,
            outline_style=Qt.PenStyle.DashLine,
        )
        if self.controller.current_document is not None:
            self.image_item.setPixmap(QPixmap.fromImage(self.controller.current_qimage()))

    def refresh_geometry(self) -> None:
        """Atualiza overlay, seleção, preview e alças de contorno."""

        document = self.controller.current_document
        if document is None:
            return
        self.overlay_item.setPath(GeometryEngine.qpath_for_geometry(document.geometry))
        self.selection_item.setPath(
            GeometryEngine.qpath_for_geometry(
                GeometryEngine.selected_geometry(document.geometry, document.selection)
            )
        )
        preview = (
            document.preview_geometry
            if document.preview_geometry is not None
            else GeometryEngine.empty()
        )
        self.preview_item.setPath(GeometryEngine.qpath_for_geometry(preview))
        self._refresh_handles()

    # ------------------------------------------------------------------ #
    # Ações públicas                                                       #
    # ------------------------------------------------------------------ #

    def finalize_polygon(self) -> None:
        """Confirma a ferramenta polígono se houver pontos suficientes."""

        if len(self._polygon_points) >= 3:
            self.controller.apply_add_geometry(GeometryEngine.polygon(self._polygon_points))
        self._polygon_points.clear()
        self.temp_item.setPath(QPainterPath())

    def clear_interaction(self) -> None:
        """Cancela qualquer operação de desenho ou edição em andamento."""

        self._stroke_points.clear()
        self._polygon_points.clear()
        self._rectangle_origin = None
        self._editing_original = None
        self._active_handle = None
        self._selected_vertex = None
        self._is_dragging = False
        self._press_pos = None
        self._translate_mode = False
        self._translate_region_index = None
        self.temp_item.setPath(QPainterPath())
        self._refresh_handles()

    def handle_delete(self) -> None:
        """Deleta o vértice selecionado (edição de contorno) ou os polígonos selecionados."""

        if (
            self.controller.active_tool is ToolKind.CONTOUR_EDIT
            and self._selected_vertex is not None
        ):
            doc = self.controller.current_document
            if doc is None:
                return
            new_geometry = GeometryEngine.delete_vertex(
                doc.geometry,
                self._selected_vertex.region_index,
                self._selected_vertex.interior_index,
                self._selected_vertex.vertex_index,
            )
            self._selected_vertex = None
            self.controller._commit_geometry(new_geometry)
        else:
            self.controller.delete_selected()

    # ------------------------------------------------------------------ #
    # Eventos de mouse                                                     #
    # ------------------------------------------------------------------ #

    def mousePressEvent(self, event) -> None:
        document = self.controller.current_document
        if document is None:
            return
        point = self._clamped_point(event.scenePos())
        point_tuple = (point.x(), point.y())
        if event.button() != Qt.MouseButton.LeftButton:
            super().mousePressEvent(event)
            return

        tool = self.controller.active_tool

        if tool is ToolKind.SELECTION:
            self.controller.select_at(
                point_tuple,
                multi=bool(event.modifiers() & Qt.KeyboardModifier.ShiftModifier),
            )
            event.accept()
            return

        if tool is ToolKind.BRUSH:
            self._stroke_points = [point_tuple]
            self._update_stroke_preview()
            event.accept()
            return

        if tool is ToolKind.HOLE:
            self._stroke_points = [point_tuple]
            self._update_stroke_preview()
            event.accept()
            return

        if tool is ToolKind.RECTANGLE:
            self._rectangle_origin = point_tuple
            event.accept()
            return

        if tool is ToolKind.POLYGON:
            # Auto-fecha ao clicar próximo do primeiro ponto
            if len(self._polygon_points) >= 3:
                first = self._polygon_points[0]
                if hypot(point_tuple[0] - first[0], point_tuple[1] - first[1]) <= 15.0:
                    self.finalize_polygon()
                    event.accept()
                    return
            self._polygon_points.append(point_tuple)
            self._update_polygon_preview(point)
            event.accept()
            return

        if tool is ToolKind.CONTOUR_EDIT:
            self._handle_contour_press(document, point_tuple, event)
            return

        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        point = self._clamped_point(event.scenePos())
        point_tuple = (point.x(), point.y())
        self.controller.update_cursor_position(point.x(), point.y())

        tool = self.controller.active_tool

        if tool is ToolKind.BRUSH and self._stroke_points:
            self._stroke_points.append(point_tuple)
            self._update_stroke_preview()
            event.accept()
            return

        if tool is ToolKind.HOLE and self._stroke_points:
            self._stroke_points.append(point_tuple)
            self._update_stroke_preview()
            event.accept()
            return

        if tool is ToolKind.RECTANGLE and self._rectangle_origin is not None:
            geometry = GeometryEngine.rectangle(self._rectangle_origin, point_tuple)
            self.temp_item.setPath(GeometryEngine.qpath_for_geometry(geometry))
            event.accept()
            return

        if tool is ToolKind.POLYGON and self._polygon_points:
            self._update_polygon_preview(point)
            event.accept()
            return

        if tool is ToolKind.CONTOUR_EDIT:
            self._handle_contour_move(point_tuple, event)
            return

        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        point = self._clamped_point(event.scenePos())
        point_tuple = (point.x(), point.y())

        if event.button() == Qt.MouseButton.LeftButton and self.controller.active_tool in {
            ToolKind.BRUSH,
            ToolKind.HOLE,
        }:
            if self._stroke_points:
                self._stroke_points.append(point_tuple)
                radius = self.controller.session.display.brush_radius
                geometry = self._stroke_to_geometry(self._stroke_points, radius)
                if self.controller.active_tool is ToolKind.BRUSH:
                    self.controller.apply_add_geometry(geometry)
                else:
                    self.controller.apply_subtract_geometry(geometry)
            self._stroke_points.clear()
            self.temp_item.setPath(QPainterPath())
            event.accept()
            return

        if (
            event.button() == Qt.MouseButton.LeftButton
            and self.controller.active_tool is ToolKind.RECTANGLE
        ):
            if self._rectangle_origin is not None:
                geometry = GeometryEngine.rectangle(self._rectangle_origin, point_tuple)
                self.controller.apply_add_geometry(geometry)
            self._rectangle_origin = None
            self.temp_item.setPath(QPainterPath())
            event.accept()
            return

        if (
            event.button() == Qt.MouseButton.LeftButton
            and self.controller.active_tool is ToolKind.CONTOUR_EDIT
        ):
            self._handle_contour_release(event)
            return

        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:
        if (
            self.controller.active_tool is ToolKind.POLYGON
            and event.button() == Qt.MouseButton.LeftButton
        ):
            self.finalize_polygon()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    # ------------------------------------------------------------------ #
    # Lógica interna de edição de contorno                                 #
    # ------------------------------------------------------------------ #

    def _handle_contour_press(self, document, point_tuple, event) -> None:
        """Processa o press do mouse no modo CONTOUR_EDIT."""

        # Prioridade 1: vertex handle
        vertex_handle = self._find_handle_by_kind(point_tuple, HandleKind.VERTEX)
        if vertex_handle is not None:
            self._editing_original = document.snapshot()
            self._active_handle = vertex_handle
            self._press_pos = point_tuple
            self._is_dragging = False
            event.accept()
            return

        # Prioridade 2: edge handle
        # Em retângulo, arestas apenas redimensionam — não inserem vértice.
        # Em polígono, clique em aresta insere um vértice naquele ponto.
        edge_handle = self._find_handle_by_kind(point_tuple, HandleKind.EDGE)
        if edge_handle is not None:
            self._editing_original = document.snapshot()
            polygon_kind = self._polygon_kind_at(document, edge_handle.region_index)
            if polygon_kind == "rectangle":
                self._active_handle = edge_handle
                self._press_pos = point_tuple
                self._is_dragging = False
            else:
                geometry, updated_handle = GeometryEngine.move_handle(
                    document.geometry, edge_handle, point_tuple
                )
                self.controller.apply_temporary_geometry(
                    geometry, selection=document.selection, normalize=False
                )
                self._active_handle = updated_handle
                self._is_dragging = True
            event.accept()
            return

        # Prioridade 3: clique dentro de qualquer polígono → translação
        index = GeometryEngine.find_polygon_index(document.geometry, point_tuple)
        if index is not None:
            if index not in document.selection:
                self.controller.set_selection({index})
            self._translate_mode = True
            self._translate_region_index = index
            self._press_pos = point_tuple
            self._editing_original = document.snapshot()
            self._is_dragging = False
            event.accept()
            return

        # Clique em área vazia: deseleciona e limpa vértice selecionado
        self.controller.select_at(
            point_tuple,
            multi=bool(event.modifiers() & Qt.KeyboardModifier.ShiftModifier),
        )
        self._selected_vertex = None
        self._refresh_handles()
        event.accept()

    def _handle_contour_move(self, point_tuple, event) -> None:
        """Processa o move do mouse no modo CONTOUR_EDIT."""

        if self._active_handle is not None:
            if not self._is_dragging and self._press_pos is not None:
                if hypot(
                    point_tuple[0] - self._press_pos[0],
                    point_tuple[1] - self._press_pos[1],
                ) > _DRAG_THRESHOLD:
                    self._is_dragging = True
            if self._is_dragging:
                doc = self.controller.current_document
                if doc is not None:
                    geometry, updated = GeometryEngine.move_handle(
                        doc.geometry, self._active_handle, point_tuple
                    )
                    self._active_handle = updated
                    self.controller.apply_temporary_geometry(
                        geometry, selection=doc.selection, normalize=False
                    )
            event.accept()
            return

        if self._translate_mode and self._press_pos is not None:
            if not self._is_dragging:
                if hypot(
                    point_tuple[0] - self._press_pos[0],
                    point_tuple[1] - self._press_pos[1],
                ) > _DRAG_THRESHOLD:
                    self._is_dragging = True
            if self._is_dragging and self._editing_original is not None:
                original = GeometryEngine.from_wkb(self._editing_original.geometry_wkb)
                dx = point_tuple[0] - self._press_pos[0]
                dy = point_tuple[1] - self._press_pos[1]
                geometry = GeometryEngine.translate_polygon(
                    original, self._translate_region_index, dx, dy
                )
                doc = self.controller.current_document
                sel = doc.selection if doc is not None else set()
                self.controller.apply_temporary_geometry(
                    geometry, selection=sel, normalize=False
                )
            event.accept()
            return

        event.accept()

    def _handle_contour_release(self, event) -> None:
        """Processa o release do mouse no modo CONTOUR_EDIT."""

        if self._active_handle is not None:
            if self._is_dragging:
                self.controller.finalize_temporary_geometry(self._editing_original)
            else:
                # Clique simples → seleciona ou desseleciona vértice
                if self._selected_vertex == self._active_handle:
                    self._selected_vertex = None
                else:
                    self._selected_vertex = self._active_handle
                self._refresh_handles()
            self._active_handle = None
            self._is_dragging = False
            self._press_pos = None
            self._editing_original = None
            event.accept()
            return

        if self._translate_mode:
            if self._is_dragging:
                self.controller.finalize_temporary_geometry(self._editing_original)
            self._translate_mode = False
            self._translate_region_index = None
            self._is_dragging = False
            self._press_pos = None
            self._editing_original = None
            event.accept()
            return

        event.accept()

    # ------------------------------------------------------------------ #
    # Helpers internos                                                     #
    # ------------------------------------------------------------------ #

    def _stroke_to_geometry(self, pts: list[tuple[float, float]], radius: float):
        """Converte stroke em geometria; fecha como polígono se o laço fechar."""

        if len(pts) >= 3:
            first = pts[0]
            last = pts[-1]
            close_thresh = max(radius * 2.0, 20.0)
            if hypot(last[0] - first[0], last[1] - first[1]) <= close_thresh:
                return GeometryEngine.polygon(pts)
        return GeometryEngine.buffered_stroke(pts, radius)

    def _refresh_handles(self) -> None:
        for item in self._handles:
            self.removeItem(item)
        self._handles.clear()
        if self.controller.active_tool is not ToolKind.CONTOUR_EDIT:
            return
        document = self.controller.current_document
        if document is None or not document.selection:
            return
        for descriptor in GeometryEngine.handles_for_selection(
            document.geometry,
            document.selection,
        ):
            item = HandleItem(descriptor)
            if self._selected_vertex is not None and descriptor == self._selected_vertex:
                item.set_selected(True)
            self.addItem(item)
            self._handles.append(item)

    def _update_stroke_preview(self) -> None:
        geometry = GeometryEngine.buffered_stroke(
            self._stroke_points,
            self.controller.session.display.brush_radius,
        )
        self.temp_item.setPath(GeometryEngine.qpath_for_geometry(geometry))

    def _update_polygon_preview(self, current_point: QPointF) -> None:
        path = QPainterPath()
        if not self._polygon_points:
            self.temp_item.setPath(path)
            return
        first = QPointF(*self._polygon_points[0])
        path.moveTo(first)
        for x, y in self._polygon_points[1:]:
            path.lineTo(x, y)
        path.lineTo(current_point)
        self.temp_item.setPath(path)

    def _find_handle_by_kind(
        self,
        point: tuple[float, float],
        kind: HandleKind,
    ) -> HandleDescriptor | None:
        """Retorna o handle mais próximo do tipo dado dentro da tolerância."""

        doc = self.controller.current_document
        if doc is None:
            return None
        best: HandleDescriptor | None = None
        best_dist = float("inf")
        for handle in GeometryEngine.handles_for_selection(doc.geometry, doc.selection):
            if handle.kind is not kind:
                continue
            dist = hypot(handle.point[0] - point[0], handle.point[1] - point[1])
            if dist <= _HANDLE_TOLERANCE and dist < best_dist:
                best = handle
                best_dist = dist
        return best

    def _polygon_kind_at(self, document, region_index) -> str | None:
        """Retorna 'rectangle', 'polygon' ou 'brush' para o polígono no índice."""

        polygons = GeometryEngine.polygons(document.geometry)
        if region_index is None or region_index < 0 or region_index >= len(polygons):
            return None
        return GeometryEngine.polygon_kind(polygons[region_index])

    def _check_tool_change(self) -> None:
        """Limpa interação em andamento quando a ferramenta muda."""

        tool = self.controller.active_tool
        if tool != self._last_active_tool:
            self._last_active_tool = tool
            self.clear_interaction()

    def _clamped_point(self, point: QPointF) -> QPointF:
        document = self.controller.current_document
        if document is None:
            return point
        x, y = GeometryEngine.clamp_point((point.x(), point.y()), *document.size)
        return QPointF(x, y)
