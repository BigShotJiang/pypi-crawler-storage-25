"""Implementação interna da API pública de anotação de máscaras.

Este módulo executa o fluxo completo: resolve o caminho de entrada, valida as
imagens encontradas, inicializa a aplicação Qt quando necessário, cria o
`WorkspaceController` e retorna um `AnnotationResult` com os caminhos salvos.

Última atualização: 2026-04-17.
"""

from __future__ import annotations

from pathlib import Path

from maskstudio.exceptions import NoImagesFoundError, UnsupportedImageError


def annotate_masks_impl(path=None):
    """Executa o fluxo de anotação e retorna um `AnnotationResult`.

    Importa dependências pesadas (PySide6, OpenCV, Pillow, Shapely) apenas
    quando invocado, mantendo `import maskstudio` barato.

    ### Parâmetros:
        path (str | Path | None): Pasta ou arquivo a abrir. Quando `None`, um
            seletor de diretório é exibido.

    ### Retorna:
        AnnotationResult: Resultado com `saved_paths` em ordem de salvamento.

    ### Exceções:
        NoImagesFoundError: Pasta informada não contém imagens suportadas.
        UnsupportedImageError: Arquivo informado não é imagem suportada.
        FileNotFoundError: Caminho informado não existe.
    """

    from PySide6.QtWidgets import QApplication

    from maskstudio._core.app.controller import WorkspaceController
    from maskstudio._core.io.discovery import (
        is_generated_mask,
        is_supported_image,
        resolve_input_images,
    )
    from maskstudio._core.ui.dialogs import pick_workspace_path
    from maskstudio._core.ui.main_window import _make_app_icon
    from maskstudio.models import AnnotationResult

    app = QApplication.instance()
    owns_app = app is None
    if owns_app:
        app = QApplication([])

    app.setWindowIcon(_make_app_icon())

    selected_path = None
    if path is None:
        selected_path = pick_workspace_path()
        if selected_path is None:
            return AnnotationResult(saved_paths=())
    else:
        selected_path = Path(path).expanduser()

    resolved_path = selected_path.resolve()
    if not resolved_path.exists():
        raise FileNotFoundError(resolved_path)
    if resolved_path.is_file() and (
        not is_supported_image(resolved_path) or is_generated_mask(resolved_path)
    ):
        raise UnsupportedImageError(resolved_path)

    image_paths = resolve_input_images(selected_path)
    if not image_paths:
        raise NoImagesFoundError(resolved_path)

    controller = WorkspaceController(image_paths)
    saved = controller.run(owns_app=owns_app)
    return AnnotationResult(saved_paths=tuple(Path(p) for p in saved))
