"""Translation catalog exports."""

from __future__ import annotations

from maskstudio._core.i18n.catalog import TranslationCatalog

__all__ = ["TranslationCatalog"]
