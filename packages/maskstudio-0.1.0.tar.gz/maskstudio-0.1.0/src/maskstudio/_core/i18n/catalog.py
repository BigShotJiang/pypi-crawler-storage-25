"""English string catalog for MaskStudio UI."""

from __future__ import annotations

_STRINGS: dict[str, str] = {
    "app.title": "MaskStudio",
    "tool.selection": "Select",
    "tool.brush": "Brush",
    "tool.polygon": "Polygon",
    "tool.rectangle": "Rectangle",
    "tool.hole": "Hole",
    "tool.contour_edit": "Contour Edit",
    "tool.pan": "Pan",
    "tool.roi": "ROI",
    "action.previous": "Previous",
    "action.next": "Next",
    "action.save": "Save",
    "action.save_next": "Save + Next",
    "action.undo": "Undo",
    "action.redo": "Redo",
    "action.clear": "Clear",
    "action.refine": "Refine",
    "action.fit": "Fit View",
    "action.zoom_100": "100%",
    "action.reset_roi": "Reset ROI",
    "label.image_index": "Image",
    "label.active_tool": "Tool",
    "label.zoom": "Zoom",
    "label.state": "State",
    "label.cursor": "Cursor",
    "label.theme": "Theme",
    "label.dark_theme": "Dark",
    "label.light_theme": "Light",
    "status.clean": "Saved",
    "status.dirty": "Unsaved",
    "panel.overview": "Overview",
    "panel.display": "Display",
}


class TranslationCatalog:
    """Returns English strings by key."""

    def get(self, key: str, **kwargs: object) -> str:
        """Return the English string for key, falling back to the key itself."""

        text = _STRINGS.get(key, key)
        if kwargs:
            return text.format(**kwargs)
        return text
