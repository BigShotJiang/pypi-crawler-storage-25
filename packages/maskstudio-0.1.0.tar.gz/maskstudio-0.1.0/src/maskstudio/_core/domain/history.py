"""Undo/redo history management."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field


@dataclass(slots=True)
class HistoryManager[T]:
    """A snapshot-based history stack."""

    limit: int = 100
    _states: list[T] = field(default_factory=list)
    _index: int = -1

    def clear(self, initial_state: T) -> None:
        """Reset history to a single initial state."""

        self._states = [initial_state]
        self._index = 0

    @property
    def current(self) -> T:
        """Return the current snapshot."""

        return self._states[self._index]

    @property
    def can_undo(self) -> bool:
        """Return whether an undo step is available."""

        return self._index > 0

    @property
    def can_redo(self) -> bool:
        """Return whether a redo step is available."""

        return self._index + 1 < len(self._states)

    def push(self, state: T) -> bool:
        """Append a new snapshot if it differs from the current state."""

        if self._states and state == self._states[self._index]:
            return False
        del self._states[self._index + 1 :]
        self._states.append(state)
        if len(self._states) > self.limit:
            overflow = len(self._states) - self.limit
            del self._states[:overflow]
            self._index = len(self._states) - 1
        else:
            self._index += 1
        return True

    def undo(self) -> T | None:
        """Move one step backward if possible."""

        if not self.can_undo:
            return None
        self._index -= 1
        return self._states[self._index]

    def redo(self) -> T | None:
        """Move one step forward if possible."""

        if not self.can_redo:
            return None
        self._index += 1
        return self._states[self._index]

    def states(self) -> Sequence[T]:
        """Return a read-only snapshot of the history contents."""

        return tuple(self._states)
