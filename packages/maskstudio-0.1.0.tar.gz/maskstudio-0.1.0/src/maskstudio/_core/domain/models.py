"""Shared domain models for geometry editing and refinement."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class ToolKind(StrEnum):
    """Available interaction tools in the editor."""

    SELECTION = "selection"
    BRUSH = "brush"
    POLYGON = "polygon"
    RECTANGLE = "rectangle"
    HOLE = "hole"
    CONTOUR_EDIT = "contour_edit"
    PAN = "pan"
    ROI = "roi"


class HandleKind(StrEnum):
    """Kinds of contour edit handles."""

    VERTEX = "vertex"
    EDGE = "edge"


class RefinementScope(StrEnum):
    """Scope of refinement operations."""

    SELECTED = "selected"
    ALL = "all"


@dataclass(frozen=True, slots=True)
class HandleDescriptor:
    """A lightweight reference to a contour edit handle."""

    region_index: int
    interior_index: int | None
    vertex_index: int
    kind: HandleKind
    point: tuple[float, float]


@dataclass(frozen=True, slots=True)
class DocumentState:
    """Immutable snapshot used by the history manager."""

    geometry_wkb: bytes
    selection: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class RefinementOptions:
    """Configuration for smoothing and edge-aware snapping."""

    smooth_iterations: int = 1
    edge_radius: int = 6
    canny_low: int = 60
    canny_high: int = 140
    enable_smooth: bool = True
    enable_edge_snap: bool = False
