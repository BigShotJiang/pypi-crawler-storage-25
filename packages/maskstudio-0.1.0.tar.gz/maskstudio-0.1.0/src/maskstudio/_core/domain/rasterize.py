"""Rasterize vector geometry into grayscale mask images."""

from __future__ import annotations

import numpy as np
from PIL import Image
from shapely.geometry import Polygon
from shapely.geometry.base import BaseGeometry

from maskstudio._core.domain.geometry import GeometryEngine


class MaskRasterizer:
    """Rasterize editable geometry into a saved binary mask."""

    def rasterize(self, geometry: BaseGeometry, size: tuple[int, int]) -> Image.Image:
        """Return a mode-L image with white background and black masked pixels."""

        width, height = size
        canvas = np.full((height, width), 255, dtype=np.uint8)
        for polygon in GeometryEngine.polygons(geometry):
            self._fill_polygon(canvas, polygon, 0)
            for hole in polygon.interiors:
                self._fill_points(canvas, list(hole.coords), 255)
        canvas = np.where(canvas < 128, 0, 255).astype(np.uint8)
        return Image.fromarray(canvas)

    def _fill_polygon(self, canvas: np.ndarray, polygon: Polygon, color: int) -> None:
        self._fill_points(canvas, list(polygon.exterior.coords), color)

    def _fill_points(
        self,
        canvas: np.ndarray,
        points: list[tuple[float, float]],
        color: int,
    ) -> None:
        import cv2

        height, width = canvas.shape
        coords = np.array(
            [
                [
                    int(np.clip(round(x), 0, width - 1)),
                    int(np.clip(round(y), 0, height - 1)),
                ]
                for x, y in points
            ],
            dtype=np.int32,
        )
        if len(coords) >= 3:
            cv2.fillPoly(canvas, [coords], color)
