"""Vectorize existing raster masks back into editable geometry."""

from __future__ import annotations

import numpy as np
from PIL import Image
from shapely.geometry import Polygon
from shapely.geometry.base import BaseGeometry

from maskstudio._core.domain.geometry import GeometryEngine


class MaskVectorizer:
    """Reconstruct polygons and holes from an existing mask image."""

    def vectorize(self, mask_image: Image.Image | np.ndarray) -> BaseGeometry:
        """Convert a saved mask image into normalized vector geometry."""

        import cv2

        if isinstance(mask_image, Image.Image):
            array = np.array(mask_image.convert("L"))
        else:
            array = mask_image.astype(np.uint8)
        binary = np.where(array < 128, 255, 0).astype(np.uint8)
        contours, hierarchy = cv2.findContours(binary, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
        if hierarchy is None or not contours:
            return GeometryEngine.empty()

        hierarchy_data = hierarchy[0]
        polygons: list[Polygon] = []
        for index, contour in enumerate(contours):
            parent = hierarchy_data[index][3]
            if parent != -1:
                continue
            shell = self._contour_points(contour)
            if len(shell) < 3:
                continue
            holes: list[list[tuple[float, float]]] = []
            child = hierarchy_data[index][2]
            while child != -1:
                hole_points = self._contour_points(contours[child])
                if len(hole_points) >= 3:
                    holes.append(hole_points)
                child = hierarchy_data[child][0]
            polygons.append(Polygon(shell, holes=holes))
        if not polygons:
            return GeometryEngine.empty()
        from shapely.ops import unary_union

        return GeometryEngine.normalize(unary_union(polygons))

    @staticmethod
    def _contour_points(contour: np.ndarray) -> list[tuple[float, float]]:
        points = contour.squeeze(axis=1)
        return [(float(x), float(y)) for x, y in points.tolist()]

