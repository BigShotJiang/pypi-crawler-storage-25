"""Geometry utilities built on top of Shapely."""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from math import hypot

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QPainterPath, QPolygonF
from shapely import normalize as shapely_normalize
from shapely import set_precision
from shapely.affinity import scale as shapely_scale
from shapely.affinity import translate as shapely_translate
from shapely.geometry import GeometryCollection, LineString, MultiPolygon, Point, Polygon, box
from shapely.geometry.base import BaseGeometry
from shapely.ops import unary_union
from shapely.validation import make_valid

from maskstudio._core.domain.models import HandleDescriptor, HandleKind


class GeometryEngine:
    """Create, normalize, query, and edit polygonal geometry."""

    grid_size = 0.25
    minimum_area = 1.0

    @classmethod
    def empty(cls) -> BaseGeometry:
        """Return an empty polygonal geometry."""

        return GeometryCollection()

    @classmethod
    def to_wkb(cls, geometry: BaseGeometry) -> bytes:
        """Serialize geometry to WKB."""

        return shapely_normalize(geometry).wkb

    @classmethod
    def from_wkb(cls, value: bytes) -> BaseGeometry:
        """Deserialize WKB into normalized polygonal geometry."""

        from shapely import from_wkb

        return cls.normalize(from_wkb(value))

    @classmethod
    def normalize(cls, geometry: BaseGeometry) -> BaseGeometry:
        """Return a valid polygonal geometry with stable precision."""

        if geometry.is_empty:
            return cls.empty()
        validated = make_valid(geometry)
        polygons = cls._polygonal_parts(validated)
        if not polygons:
            return cls.empty()
        merged = unary_union(polygons)
        merged = make_valid(merged)
        polygons = [
            set_precision(part, cls.grid_size)
            for part in cls._polygonal_parts(merged)
            if part.area >= cls.minimum_area
        ]
        if not polygons:
            return cls.empty()
        merged = unary_union(polygons)
        merged = set_precision(merged, cls.grid_size)
        ordered = cls.polygons(merged)
        if not ordered:
            return cls.empty()
        if len(ordered) == 1:
            return ordered[0]
        return MultiPolygon(ordered)

    @classmethod
    def polygons(cls, geometry: BaseGeometry) -> list[Polygon]:
        """Explode geometry into a stable, sorted list of polygons."""

        parts = [part for part in cls._polygonal_parts(geometry) if part.area >= cls.minimum_area]
        return sorted(
            parts,
            key=lambda poly: (
                round(poly.bounds[1], 3),
                round(poly.bounds[0], 3),
                round(-poly.area, 3),
            ),
        )

    @classmethod
    def union(cls, current: BaseGeometry, addition: BaseGeometry) -> BaseGeometry:
        """Union polygonal geometry and normalize the result."""

        if current.is_empty:
            return cls.normalize(addition)
        if addition.is_empty:
            return cls.normalize(current)
        return cls.normalize(unary_union([current, addition]))

    @classmethod
    def subtract(cls, current: BaseGeometry, cutter: BaseGeometry) -> BaseGeometry:
        """Subtract geometry from the current annotation."""

        if current.is_empty or cutter.is_empty:
            return cls.normalize(current)
        return cls.normalize(current.difference(cutter))

    @classmethod
    def polygon(cls, points: Sequence[tuple[float, float]]) -> BaseGeometry:
        """Create a polygon from a point sequence."""

        if len(points) < 3:
            return cls.empty()
        return cls.normalize(Polygon(points))

    @classmethod
    def rectangle(cls, start: tuple[float, float], end: tuple[float, float]) -> BaseGeometry:
        """Create a rectangle from two corners."""

        x1, y1 = start
        x2, y2 = end
        if x1 == x2 or y1 == y2:
            return cls.empty()
        return cls.normalize(box(min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)))

    @classmethod
    def buffered_stroke(cls, points: Sequence[tuple[float, float]], radius: float) -> BaseGeometry:
        """Convert a sampled pointer path into a filled brush stroke."""

        if not points:
            return cls.empty()
        if len(points) == 1:
            return cls.normalize(Point(points[0]).buffer(radius))
        return cls.normalize(LineString(points).buffer(radius, cap_style=1, join_style=1))

    @classmethod
    def selected_geometry(cls, geometry: BaseGeometry, selection: Iterable[int]) -> BaseGeometry:
        """Return a union of the selected polygon components."""

        polygons = cls.polygons(geometry)
        indices = set(selection)
        selected = [polygon for index, polygon in enumerate(polygons) if index in indices]
        if not selected:
            return cls.empty()
        return cls.normalize(unary_union(selected))

    @classmethod
    def replace_polygons(
        cls,
        geometry: BaseGeometry,
        selection: Iterable[int],
        replacements: Sequence[BaseGeometry],
    ) -> BaseGeometry:
        """Replace selected polygons with new geometry."""

        polygons = cls.polygons(geometry)
        selected = set(selection)
        kept = [polygon for index, polygon in enumerate(polygons) if index not in selected]
        pieces: list[BaseGeometry] = kept + [piece for piece in replacements if not piece.is_empty]
        if not pieces:
            return cls.empty()
        return cls.normalize(unary_union(pieces))

    @classmethod
    def find_polygon_index(
        cls,
        geometry: BaseGeometry,
        point: tuple[float, float],
        tolerance: float = 3.0,
    ) -> int | None:
        """Find the polygon index under or near the given point."""

        target = Point(point)
        for index, polygon in enumerate(cls.polygons(geometry)):
            if polygon.contains(target) or polygon.touches(target):
                return index
        for index, polygon in enumerate(cls.polygons(geometry)):
            if polygon.boundary.distance(target) <= tolerance:
                return index
        return None

    @classmethod
    def qpath_for_geometry(cls, geometry: BaseGeometry) -> QPainterPath:
        """Convert geometry into an odd-even Qt painter path."""

        path = QPainterPath()
        path.setFillRule(Qt.FillRule.OddEvenFill)
        for polygon in cls.polygons(geometry):
            path.addPolygon(cls._ring_to_qpolygon(polygon.exterior.coords))
            for interior in polygon.interiors:
                path.addPolygon(cls._ring_to_qpolygon(interior.coords))
        return path

    @classmethod
    def polygon_kind(cls, polygon: Polygon) -> str:
        """Retorna 'rectangle', 'polygon' ou 'brush' com base na contagem de vértices externos."""

        n = len(polygon.exterior.coords) - 1
        if n <= 5:
            return "rectangle"
        if n <= 15:
            return "polygon"
        return "brush"

    @classmethod
    def delete_vertex(
        cls,
        geometry: BaseGeometry,
        region_index: int,
        interior_index: int | None,
        vertex_index: int,
    ) -> BaseGeometry:
        """Remove um vértice de um polígono e retorna a geometria normalizada."""

        polygons = cls.polygons(geometry)
        if region_index >= len(polygons):
            return geometry
        polygon = polygons[region_index]
        shell = list(polygon.exterior.coords[:-1])
        holes = [list(h.coords[:-1]) for h in polygon.interiors]
        if interior_index is None:
            if len(shell) <= 3:
                return geometry
            del shell[vertex_index % len(shell)]
        else:
            if interior_index >= len(holes) or len(holes[interior_index]) <= 3:
                return geometry
            del holes[interior_index][vertex_index % len(holes[interior_index])]
        candidate = Polygon(shell, holes=holes)
        if not candidate.is_valid or candidate.area <= 0:
            return geometry
        return cls.replace_polygons(geometry, {region_index}, [candidate])

    @classmethod
    def scale_polygons(
        cls,
        geometry: BaseGeometry,
        selection: Iterable[int],
        factor: float,
    ) -> BaseGeometry:
        """Escala proporcionalmente os polígonos selecionados em torno do centroide.

        ### Parâmetros:
            geometry: Geometria com todos os polígonos.
            selection: Índices dos polígonos a escalar.
            factor: Fator de escala (1.0 = inalterado, >1 aumenta, <1 diminui).

        ### Retorna:
            Nova geometria com os polígonos selecionados escalados.
        """

        polygons = cls.polygons(geometry)
        indices = sorted({i for i in selection if 0 <= i < len(polygons)})
        if not indices or factor <= 0:
            return geometry
        replacements = []
        for idx in indices:
            poly = polygons[idx]
            centroid = poly.centroid
            scaled = shapely_scale(
                poly,
                xfact=factor,
                yfact=factor,
                origin=(centroid.x, centroid.y),
            )
            replacements.append(scaled)
        return cls.replace_polygons(geometry, indices, replacements)

    @classmethod
    def translate_polygon(
        cls,
        geometry: BaseGeometry,
        region_index: int,
        dx: float,
        dy: float,
    ) -> BaseGeometry:
        """Translada um polígono específico por (dx, dy) e retorna a geometria normalizada."""

        polygons = cls.polygons(geometry)
        if region_index >= len(polygons):
            return geometry
        moved = shapely_translate(polygons[region_index], xoff=dx, yoff=dy)
        return cls.replace_polygons(geometry, {region_index}, [moved])

    @classmethod
    def handles_for_selection(
        cls,
        geometry: BaseGeometry,
        selection: Iterable[int],
    ) -> list[HandleDescriptor]:
        """Constrói handles de edição para os polígonos selecionados.

        Retângulos: 4 handles de canto (VERTEX 0=TL,1=TR,2=BR,3=BL) e
        4 handles de aresta (EDGE 0=top,1=right,2=bottom,3=left) que
        preservam a forma de caixa ao serem arrastados.
        Polígonos (>5 e ≤15 vértices): handles em todos os vértices e
        em todas as arestas. Arrastar vértice move ponto; clicar aresta
        insere vértice; apertar Delete em vértice seleciona o remove.
        Pincel (>15 vértices): sem handles — edição de contorno é
        desabilitada para evitar bugs de topologia.
        """

        handles: list[HandleDescriptor] = []
        polygons = cls.polygons(geometry)
        for region_index in selection:
            if region_index >= len(polygons):
                continue
            polygon = polygons[region_index]
            kind = cls.polygon_kind(polygon)
            if kind == "brush":
                continue
            if kind == "rectangle":
                handles.extend(cls._rectangle_bbox_handles(region_index, polygon))
                continue
            exterior = list(polygon.exterior.coords[:-1])
            handles.extend(cls._ring_handles(region_index, None, exterior))
            for hole_index, interior in enumerate(polygon.interiors):
                handles.extend(cls._ring_handles(region_index, hole_index, interior.coords[:-1]))
        return handles

    @classmethod
    def _rectangle_bbox_handles(
        cls,
        region_index: int,
        polygon: Polygon,
    ) -> list[HandleDescriptor]:
        """Gera os 8 handles de bounding box para um retângulo.

        ### Parâmetros:
            region_index: Índice do polígono na geometria.
            polygon: Polígono a ser tratado como retângulo pela bounding box.

        ### Retorna:
            Lista com 4 handles de canto (VERTEX 0-3) e 4 handles de aresta
            (EDGE 0-3) na convenção top-right-bottom-left.
        """

        minx, miny, maxx, maxy = polygon.bounds
        cx = (minx + maxx) / 2.0
        cy = (miny + maxy) / 2.0
        corners = [(minx, miny), (maxx, miny), (maxx, maxy), (minx, maxy)]
        edges = [(cx, miny), (maxx, cy), (cx, maxy), (minx, cy)]
        handles: list[HandleDescriptor] = []
        for i, pt in enumerate(corners):
            handles.append(HandleDescriptor(
                region_index=region_index,
                interior_index=None,
                vertex_index=i,
                kind=HandleKind.VERTEX,
                point=(float(pt[0]), float(pt[1])),
            ))
        for i, pt in enumerate(edges):
            handles.append(HandleDescriptor(
                region_index=region_index,
                interior_index=None,
                vertex_index=i,
                kind=HandleKind.EDGE,
                point=(float(pt[0]), float(pt[1])),
            ))
        return handles

    @classmethod
    def move_handle(
        cls,
        geometry: BaseGeometry,
        handle: HandleDescriptor,
        new_point: tuple[float, float],
    ) -> tuple[BaseGeometry, HandleDescriptor]:
        """Move um handle de contorno e retorna a geometria e o handle atualizado.

        Para retângulo: preserva a forma de bounding box ao mover cantos/arestas.
        Para polígono comum: move vértice (VERTEX) ou insere vértice na aresta (EDGE).
        A geometria é retornada sem re-normalização agressiva para preservar os
        índices dos vértices durante o arrasto; o handle tem seu region_index
        reajustado caso a ordenação final de polygons() altere a posição.
        """

        polygons = cls.polygons(geometry)
        if handle.region_index >= len(polygons):
            return geometry, handle
        polygon = polygons[handle.region_index]
        kind = cls.polygon_kind(polygon)

        if kind == "brush":
            return geometry, handle

        if kind == "rectangle":
            updated_polygon, updated_handle = cls._resize_rectangle_bbox(
                polygon, handle, new_point
            )
        else:
            updated_polygon, updated_handle = cls._edit_polygon_ring(
                polygon, handle, new_point
            )

        if updated_polygon is None:
            return geometry, handle

        polygons[handle.region_index] = updated_polygon
        new_geometry = cls._as_multipolygon(polygons)
        adjusted_index = cls._locate_polygon_index(new_geometry, updated_polygon)
        if adjusted_index is not None and adjusted_index != updated_handle.region_index:
            updated_handle = HandleDescriptor(
                region_index=adjusted_index,
                interior_index=updated_handle.interior_index,
                vertex_index=updated_handle.vertex_index,
                kind=updated_handle.kind,
                point=updated_handle.point,
            )
        return new_geometry, updated_handle

    @classmethod
    def _resize_rectangle_bbox(
        cls,
        polygon: Polygon,
        handle: HandleDescriptor,
        new_point: tuple[float, float],
    ) -> tuple[Polygon | None, HandleDescriptor]:
        """Redimensiona um retângulo pela bounding box preservando a forma."""

        minx, miny, maxx, maxy = polygon.bounds
        nx, ny = new_point
        vi = handle.vertex_index
        if handle.kind is HandleKind.VERTEX:
            if vi == 0:
                minx, miny = nx, ny
            elif vi == 1:
                maxx, miny = nx, ny
            elif vi == 2:
                maxx, maxy = nx, ny
            elif vi == 3:
                minx, maxy = nx, ny
        else:
            if vi == 0:
                miny = ny
            elif vi == 1:
                maxx = nx
            elif vi == 2:
                maxy = ny
            elif vi == 3:
                minx = nx
        if minx > maxx:
            minx, maxx = maxx, minx
        if miny > maxy:
            miny, maxy = maxy, miny
        if maxx - minx < 2.0 or maxy - miny < 2.0:
            return None, handle
        new_polygon = box(minx, miny, maxx, maxy)
        new_point_final = cls._rectangle_handle_point(minx, miny, maxx, maxy, handle)
        new_handle = HandleDescriptor(
            region_index=handle.region_index,
            interior_index=None,
            vertex_index=handle.vertex_index,
            kind=handle.kind,
            point=new_point_final,
        )
        return new_polygon, new_handle

    @classmethod
    def _rectangle_handle_point(
        cls,
        minx: float,
        miny: float,
        maxx: float,
        maxy: float,
        handle: HandleDescriptor,
    ) -> tuple[float, float]:
        """Retorna o ponto atualizado de um handle de bbox após resize."""

        cx = (minx + maxx) / 2.0
        cy = (miny + maxy) / 2.0
        if handle.kind is HandleKind.VERTEX:
            corners = [(minx, miny), (maxx, miny), (maxx, maxy), (minx, maxy)]
            return corners[handle.vertex_index % 4]
        edges = [(cx, miny), (maxx, cy), (cx, maxy), (minx, cy)]
        return edges[handle.vertex_index % 4]

    @classmethod
    def _edit_polygon_ring(
        cls,
        polygon: Polygon,
        handle: HandleDescriptor,
        new_point: tuple[float, float],
    ) -> tuple[Polygon | None, HandleDescriptor]:
        """Aplica movimento ou inserção de vértice em um anel de polígono."""

        shell = [tuple(point) for point in polygon.exterior.coords[:-1]]
        holes = [
            [tuple(point) for point in interior.coords[:-1]]
            for interior in polygon.interiors
        ]
        ring = shell if handle.interior_index is None else (
            holes[handle.interior_index]
            if handle.interior_index is not None and handle.interior_index < len(holes)
            else None
        )
        if ring is None:
            return None, handle

        if handle.kind is HandleKind.EDGE:
            insert_at = handle.vertex_index + 1
            if insert_at > len(ring):
                insert_at = len(ring)
            ring.insert(insert_at, new_point)
            new_handle = HandleDescriptor(
                region_index=handle.region_index,
                interior_index=handle.interior_index,
                vertex_index=insert_at,
                kind=HandleKind.VERTEX,
                point=new_point,
            )
        else:
            if not (0 <= handle.vertex_index < len(ring)):
                return None, handle
            ring[handle.vertex_index] = new_point
            new_handle = HandleDescriptor(
                region_index=handle.region_index,
                interior_index=handle.interior_index,
                vertex_index=handle.vertex_index,
                kind=HandleKind.VERTEX,
                point=new_point,
            )

        if len(ring) < 3:
            return None, handle
        try:
            candidate = Polygon(shell, holes=holes)
            if not candidate.is_valid:
                repaired = make_valid(candidate)
                parts = cls._polygonal_parts(repaired)
                if not parts:
                    return None, handle
                candidate = max(parts, key=lambda p: p.area)
        except Exception:
            return None, handle
        if candidate.is_empty or candidate.area <= 0:
            return None, handle
        return candidate, new_handle

    @classmethod
    def _as_multipolygon(cls, polygons_list: list[Polygon]) -> BaseGeometry:
        """Constrói Polygon/MultiPolygon preservando a ordem, sem normalizar."""

        valid = [
            p for p in polygons_list
            if p is not None and not p.is_empty and p.is_valid and p.area >= cls.minimum_area
        ]
        if not valid:
            return cls.empty()
        if len(valid) == 1:
            return valid[0]
        return MultiPolygon(valid)

    @classmethod
    def _locate_polygon_index(
        cls,
        geometry: BaseGeometry,
        target: Polygon,
    ) -> int | None:
        """Encontra o índice do polígono target na ordenação final de polygons()."""

        ordered = cls.polygons(geometry)
        if not ordered:
            return None
        centroid = target.centroid
        best_index = 0
        best_distance = float("inf")
        for i, poly in enumerate(ordered):
            distance = poly.centroid.distance(centroid)
            if distance < best_distance:
                best_distance = distance
                best_index = i
        return best_index

    @classmethod
    def simplify_for_editing(
        cls,
        geometry: BaseGeometry,
        selection: Iterable[int],
        tolerance: float = 3.0,
    ) -> BaseGeometry:
        """Simplifica polígonos selecionados para facilitar edição de contorno.

        ### Parâmetros:
            geometry: Geometria com todos os polígonos.
            selection: Índices dos polígonos a simplificar.
            tolerance: Distância de simplificação em pixels (padrão: 3.0).

        ### Retorna:
            Nova geometria com os polígonos selecionados simplificados.
        """

        polygons = cls.polygons(geometry)
        selected = set(selection)
        result = [
            polygon.simplify(tolerance, preserve_topology=True)
            if i in selected
            else polygon
            for i, polygon in enumerate(polygons)
        ]
        if not result:
            return cls.empty()
        return cls.normalize(unary_union(result))

    @classmethod
    def clamp_point(
        cls,
        point: tuple[float, float],
        width: int,
        height: int,
    ) -> tuple[float, float]:
        """Clamp a point to the current image bounds."""

        x, y = point
        return (max(0.0, min(x, width - 1.0)), max(0.0, min(y, height - 1.0)))

    @classmethod
    def _polygonal_parts(cls, geometry: BaseGeometry) -> list[Polygon]:
        if geometry.is_empty:
            return []
        if isinstance(geometry, Polygon):
            return [geometry]
        if isinstance(geometry, MultiPolygon):
            return list(geometry.geoms)
        if isinstance(geometry, GeometryCollection):
            parts: list[Polygon] = []
            for component in geometry.geoms:
                parts.extend(cls._polygonal_parts(component))
            return parts
        if hasattr(geometry, "geoms"):
            parts = []
            for component in geometry.geoms:
                parts.extend(cls._polygonal_parts(component))
            return parts
        return []

    @staticmethod
    def _ring_to_qpolygon(points: Iterable[tuple[float, float]]) -> QPolygonF:
        return QPolygonF([QPointF(float(x), float(y)) for x, y in points])

    @classmethod
    def _ring_handles(
        cls,
        region_index: int,
        interior_index: int | None,
        points: Sequence[tuple[float, float]],
    ) -> list[HandleDescriptor]:
        handles: list[HandleDescriptor] = []
        ring_points = list(points)
        count = len(ring_points)
        if count < 3:
            return handles
        for vertex_index, point in enumerate(ring_points):
            handles.append(
                HandleDescriptor(
                    region_index=region_index,
                    interior_index=interior_index,
                    vertex_index=vertex_index,
                    kind=HandleKind.VERTEX,
                    point=(float(point[0]), float(point[1])),
                )
            )
            next_point = ring_points[(vertex_index + 1) % count]
            midpoint = ((point[0] + next_point[0]) / 2.0, (point[1] + next_point[1]) / 2.0)
            handles.append(
                HandleDescriptor(
                    region_index=region_index,
                    interior_index=interior_index,
                    vertex_index=vertex_index,
                    kind=HandleKind.EDGE,
                    point=(float(midpoint[0]), float(midpoint[1])),
                )
            )
        return handles

    @classmethod
    def _rebuild_polygon(
        cls,
        shell: Sequence[tuple[float, float]],
        holes: Sequence[Sequence[tuple[float, float]]],
        fallback: Polygon,
    ) -> Polygon | None:
        valid_shell = cls._clean_ring(shell)
        valid_holes = [
            hole
            for hole in (cls._clean_ring(points) for points in holes)
            if hole is not None
        ]
        if valid_shell is None:
            return fallback
        candidate = Polygon(valid_shell, holes=valid_holes)
        normalized = cls.normalize(candidate)
        polygons = cls.polygons(normalized)
        if not polygons:
            return fallback
        target = fallback.centroid
        return min(polygons, key=lambda polygon: polygon.centroid.distance(target))

    @staticmethod
    def _clean_ring(points: Sequence[tuple[float, float]]) -> list[tuple[float, float]] | None:
        ring = []
        for point in points:
            if not ring or hypot(point[0] - ring[-1][0], point[1] - ring[-1][1]) > 0.25:
                ring.append((float(point[0]), float(point[1])))
        if len(ring) < 3:
            return None
        return ring
