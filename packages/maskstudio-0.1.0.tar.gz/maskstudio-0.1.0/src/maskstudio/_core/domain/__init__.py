"""Domain services and immutable models for MaskStudio."""

from __future__ import annotations

