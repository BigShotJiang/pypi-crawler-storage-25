"""Serviços de refinamento de geometria: suavização e snap de bordas.
Última atualização: 2026-04-17.
"""

from __future__ import annotations

from collections.abc import Iterable

import cv2
import numpy as np
from shapely.geometry import Polygon
from shapely.geometry.base import BaseGeometry
from shapely.ops import unary_union

from maskstudio._core.domain.geometry import GeometryEngine
from maskstudio._core.domain.models import RefinementOptions


class ContourRefiner:
    """Aplica suavização Laplaciana e snap de borda a geometrias vetoriais."""

    def refine(
        self,
        geometry: BaseGeometry,
        image_array: np.ndarray,
        options: RefinementOptions,
        selection: Iterable[int] | None = None,
    ) -> BaseGeometry:
        """Refina polígonos selecionados preservando a topologia.

        ### Parâmetros:
            geometry: Geometria original com todos os polígonos.
            image_array: Array numpy da imagem para snap de bordas.
            options: Configuração de suavização e snap.
            selection: Índices dos polígonos a refinar; None refina todos.

        ### Retorna:
            Nova geometria com os polígonos refinados.
        """

        polygons = GeometryEngine.polygons(geometry)
        if not polygons:
            return GeometryEngine.empty()

        selected = set(range(len(polygons))) if selection is None else set(selection)
        edge_map = self._edge_map(image_array, options) if options.enable_edge_snap else None

        result: list[BaseGeometry] = []
        for index, polygon in enumerate(polygons):
            if index not in selected:
                result.append(polygon)
                continue
            updated = polygon
            if options.enable_smooth:
                updated = self._smooth_polygon(updated, options.smooth_iterations)
            if options.enable_edge_snap and edge_map is not None:
                updated = self._snap_polygon(updated, edge_map, options.edge_radius)
            result.append(updated)

        if not result:
            return GeometryEngine.empty()
        return GeometryEngine.normalize(unary_union(result))

    def _smooth_polygon(self, polygon: Polygon, iterations: int) -> BaseGeometry:
        """Aplica suavização Laplaciana ao polígono pelo número de iterações."""

        shell = list(polygon.exterior.coords[:-1])
        holes = [list(interior.coords[:-1]) for interior in polygon.interiors]

        for _ in range(max(1, iterations)):
            shell = self._smooth_ring(shell)
            holes = [self._smooth_ring(h) for h in holes]

        candidate = Polygon(shell, holes=holes)
        normalized = GeometryEngine.normalize(candidate)
        polygons = GeometryEngine.polygons(normalized)
        return polygons[0] if polygons else polygon

    def _smooth_ring(self, points: list[tuple[float, float]]) -> list[tuple[float, float]]:
        """Aplica uma iteração de suavização Laplaciana preservando a contagem de vértices."""

        n = len(points)
        if n < 3:
            return points
        weight = 0.5
        smoothed: list[tuple[float, float]] = []
        for i, pt in enumerate(points):
            prev = points[(i - 1) % n]
            nxt = points[(i + 1) % n]
            avg_x = (prev[0] + nxt[0]) / 2.0
            avg_y = (prev[1] + nxt[1]) / 2.0
            smoothed.append((
                pt[0] + weight * (avg_x - pt[0]),
                pt[1] + weight * (avg_y - pt[1]),
            ))
        return smoothed

    def _snap_polygon(self, polygon: Polygon, edge_map: np.ndarray, radius: int) -> BaseGeometry:
        """Encaixa o polígono nas bordas mais próximas com passes decrescentes.

        Executa múltiplas passadas com raios progressivamente menores para
        atrair o contorno de distâncias maiores sem ultrapassar bordas finas,
        densificando a cada passada, suavizando ao final para eliminar pontas
        e simplificando para reduzir vértices redundantes.
        """

        passes = [max(3, int(round(radius * factor))) for factor in (1.0, 0.55, 0.25)]
        shell = list(polygon.exterior.coords[:-1])
        holes = [list(interior.coords[:-1]) for interior in polygon.interiors]
        for pass_radius in passes:
            shell = self._densify_ring(shell, pass_radius)
            shell = self._snap_ring(shell, edge_map, pass_radius)
            holes = [
                self._snap_ring(self._densify_ring(hole, pass_radius), edge_map, pass_radius)
                for hole in holes
            ]
        for _ in range(2):
            shell = self._smooth_ring(shell)
            holes = [self._smooth_ring(hole) for hole in holes]
        candidate = Polygon(shell, holes=holes)
        simplified = candidate.simplify(0.75, preserve_topology=True)
        return GeometryEngine.normalize(simplified)

    def _densify_ring(
        self,
        points: list[tuple[float, float]],
        radius: int,
    ) -> list[tuple[float, float]]:
        """Insere vértices intermediários para melhorar o snap de bordas."""

        if len(points) < 3:
            return points
        spacing = max(2.0, radius / 2.0)
        dense: list[tuple[float, float]] = []
        for index, point in enumerate(points):
            next_point = points[(index + 1) % len(points)]
            dense.append(point)
            segment = np.array(next_point) - np.array(point)
            distance = float(np.linalg.norm(segment))
            steps = int(distance // spacing)
            if steps <= 1:
                continue
            for step in range(1, steps):
                factor = step / steps
                interpolated = np.array(point) + segment * factor
                dense.append((float(interpolated[0]), float(interpolated[1])))
        return dense

    def _snap_ring(
        self,
        points: list[tuple[float, float]],
        edge_map: np.ndarray,
        radius: int,
    ) -> list[tuple[float, float]]:
        """Encaixa cada ponto do anel na borda mais próxima dentro do raio."""

        return [self._nearest_edge_point(edge_map, x, y, radius) for x, y in points]

    def _nearest_edge_point(
        self,
        edge_map: np.ndarray,
        x: float,
        y: float,
        radius: int,
    ) -> tuple[float, float]:
        """Retorna o ponto de borda mais próximo dentro do raio, ou o ponto original."""

        px = int(round(x))
        py = int(round(y))
        top = max(0, py - radius)
        bottom = min(edge_map.shape[0], py + radius + 1)
        left = max(0, px - radius)
        right = min(edge_map.shape[1], px + radius + 1)
        window = edge_map[top:bottom, left:right]
        candidates = np.argwhere(window > 0)
        if len(candidates) == 0:
            return (x, y)
        offsets = np.column_stack((candidates[:, 1] + left, candidates[:, 0] + top)).astype(float)
        distances = np.sum((offsets - np.array([x, y])) ** 2, axis=1)
        nearest = offsets[int(np.argmin(distances))]
        return (float(nearest[0]), float(nearest[1]))

    def _edge_map(self, image_array: np.ndarray, options: RefinementOptions) -> np.ndarray:
        """Gera o mapa de bordas Canny para snap."""

        if image_array.ndim == 3:
            gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
        else:
            gray = image_array
        return cv2.Canny(gray, options.canny_low, options.canny_high)
