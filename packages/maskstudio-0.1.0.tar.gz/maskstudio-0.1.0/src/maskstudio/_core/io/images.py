"""Image loading and display conversion helpers."""

from __future__ import annotations

import numpy as np
from PIL import Image
from PySide6.QtGui import QImage


def load_image_array(path: str) -> np.ndarray:
    """Load an image as an RGB numpy array."""

    with Image.open(path) as image:
        return np.array(image.convert("RGB"))


def apply_display_adjustments(
    image_array: np.ndarray,
    brightness: int,
    contrast: int,
) -> np.ndarray:
    """Apply non-destructive brightness and contrast adjustments for display."""

    array = image_array.astype(np.float32)
    contrast_factor = max(0.1, 1.0 + (contrast / 100.0))
    adjusted = ((array - 127.5) * contrast_factor) + 127.5 + brightness
    return np.clip(adjusted, 0, 255).astype(np.uint8)


def array_to_qimage(image_array: np.ndarray) -> QImage:
    """Convert an RGB array into a detached QImage."""

    height, width, channels = image_array.shape
    bytes_per_line = channels * width
    image = QImage(image_array.data, width, height, bytes_per_line, QImage.Format.Format_RGB888)
    return image.copy()

