"""Mask loading, output naming, and persistence helpers."""

from __future__ import annotations

from pathlib import Path

from PIL import Image
from shapely.geometry.base import BaseGeometry

from maskstudio._core.domain.geometry import GeometryEngine
from maskstudio._core.domain.rasterize import MaskRasterizer
from maskstudio._core.domain.vectorize import MaskVectorizer


def mask_output_path(image_path: Path) -> Path:
    """Return the generated mask path for an image."""

    return image_path.with_name(f"{image_path.stem}_mask.png")


def load_existing_mask_geometry(image_path: Path, vectorizer: MaskVectorizer) -> BaseGeometry:
    """Load an existing `_mask.png` file if present."""

    output_path = mask_output_path(image_path)
    if not output_path.exists():
        return GeometryEngine.empty()
    with Image.open(output_path) as image:
        return vectorizer.vectorize(image.convert("L"))


def save_mask(
    image_path: Path,
    geometry: BaseGeometry,
    image_size: tuple[int, int],
    rasterizer: MaskRasterizer,
) -> Path:
    """Rasterize and save the current geometry as a PNG mask."""

    target = mask_output_path(image_path)
    image = rasterizer.rasterize(geometry, image_size)
    image.save(target, format="PNG")
    return target

