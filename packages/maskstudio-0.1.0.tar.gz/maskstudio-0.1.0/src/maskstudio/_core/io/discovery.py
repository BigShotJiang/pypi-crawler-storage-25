"""Deterministic discovery of images and their mask paths."""

from __future__ import annotations

import re
from pathlib import Path

SUPPORTED_IMAGE_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".bmp",
    ".tif",
    ".tiff",
    ".webp",
}

_NATURAL_PATTERN = re.compile(r"(\d+)")


def natural_sort_key(path: Path) -> list[int | str]:
    """Return a natural-sort key for deterministic file ordering."""

    return [
        int(token) if token.isdigit() else token.lower()
        for token in _NATURAL_PATTERN.split(path.name)
        if token
    ]


def is_supported_image(path: Path) -> bool:
    """Return whether a path is a supported input image."""

    if not path.is_file():
        return False
    return path.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS


def is_generated_mask(path: Path) -> bool:
    """Return whether a path matches the generated mask naming pattern."""

    return path.suffix.lower() == ".png" and path.stem.lower().endswith("_mask")


def discover_images(directory: Path) -> list[Path]:
    """Discover supported source images in a directory."""

    return sorted(
        [
            child
            for child in directory.iterdir()
            if is_supported_image(child) and not is_generated_mask(child)
        ],
        key=natural_sort_key,
    )


def resolve_input_images(path: Path) -> list[Path]:
    """Resolve a folder or file path into the images to open."""

    path = path.expanduser().resolve()
    if path.is_dir():
        return discover_images(path)
    if not path.exists():
        raise FileNotFoundError(path)
    if not is_supported_image(path) or is_generated_mask(path):
        raise ValueError(f"Unsupported input image: {path}")
    return [path]

