"""IO services for discovery and image/mask persistence."""

from __future__ import annotations

