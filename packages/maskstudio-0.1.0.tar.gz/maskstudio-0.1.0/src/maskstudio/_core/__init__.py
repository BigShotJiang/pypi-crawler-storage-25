"""Internal implementation modules for MaskStudio.

Este pacote concentra toda a lógica interna, não faz parte da API pública.
Última atualização: 2026-04-17.
"""
