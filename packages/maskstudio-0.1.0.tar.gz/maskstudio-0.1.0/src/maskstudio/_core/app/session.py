"""Session and document state models for the workspace."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from PySide6.QtCore import QRectF
from shapely.geometry.base import BaseGeometry

from maskstudio._core.domain.geometry import GeometryEngine
from maskstudio._core.domain.history import HistoryManager
from maskstudio._core.domain.models import DocumentState


@dataclass(slots=True)
class DisplaySettings:
    """Display-only settings — do not affect saved masks."""

    overlay_color: str = "#2fbf71"
    overlay_opacity: float = 0.40
    outline_width: float = 2.0
    brightness: int = 0
    contrast: int = 0
    brush_radius: float = 6.0
    dark_theme: bool = True

    @property
    def outline_color(self) -> str:
        """Opaque outline color derived from the overlay fill."""

        from PySide6.QtGui import QColor
        return QColor(self.overlay_color).lighter(155).name()


@dataclass(slots=True)
class RoiState:
    """Current region of interest shown in the detail view."""

    x: float
    y: float
    width: float
    height: float
    minimum_size: float = 32.0

    @classmethod
    def default_for_size(cls, width: int, height: int) -> RoiState:
        """Create a centered ROI sized for detail editing."""

        roi_width = width if width <= 256 else max(64.0, width * 0.45)
        roi_height = height if height <= 256 else max(64.0, height * 0.45)
        x = max(0.0, (width - roi_width) / 2.0)
        y = max(0.0, (height - roi_height) / 2.0)
        return cls(
            x=x,
            y=y,
            width=min(roi_width, float(width)),
            height=min(roi_height, float(height)),
        )

    def to_rect(self) -> QRectF:
        """Convert the ROI to a QRectF."""

        return QRectF(self.x, self.y, self.width, self.height)


@dataclass(slots=True)
class AnnotationDocument:
    """Editable image document and its mask geometry."""

    image_path: Path
    image_array: np.ndarray
    geometry: BaseGeometry
    mask_path: Path
    history: HistoryManager[DocumentState] = field(default_factory=HistoryManager)
    selection: set[int] = field(default_factory=set)
    preview_geometry: BaseGeometry | None = None
    saved_geometry_wkb: bytes = field(init=False)

    def __post_init__(self) -> None:
        self.saved_geometry_wkb = GeometryEngine.to_wkb(self.geometry)
        self.history.clear(self.snapshot())

    @property
    def size(self) -> tuple[int, int]:
        """Return image size as (width, height)."""

        height, width = self.image_array.shape[:2]
        return (width, height)

    @property
    def dirty(self) -> bool:
        """Return whether the current geometry differs from the saved version."""

        return GeometryEngine.to_wkb(self.geometry) != self.saved_geometry_wkb

    def snapshot(self) -> DocumentState:
        """Create a history snapshot of the current state."""

        return DocumentState(
            geometry_wkb=GeometryEngine.to_wkb(self.geometry),
            selection=tuple(sorted(self.selection)),
        )

    def restore(self, state: DocumentState) -> None:
        """Restore geometry and selection from a snapshot."""

        self.geometry = GeometryEngine.from_wkb(state.geometry_wkb)
        self.selection = set(state.selection)
        self.preview_geometry = None

    def mark_saved(self) -> None:
        """Mark the current geometry as persisted."""

        self.saved_geometry_wkb = GeometryEngine.to_wkb(self.geometry)


@dataclass(slots=True)
class SessionState:
    """Global workspace state shared by the controller and UI."""

    images: list[Path]
    documents: dict[Path, AnnotationDocument] = field(default_factory=dict)
    current_index: int = 0
    saved_paths: list[Path] = field(default_factory=list)
    display: DisplaySettings = field(default_factory=DisplaySettings)
    roi: RoiState | None = None
    remembered_navigation_decision: str | None = None
    cursor_position: tuple[float, float] = (0.0, 0.0)
    zoom_percent: float = 100.0

    @property
    def current_path(self) -> Path | None:
        """Return the currently active image path."""

        if not self.images:
            return None
        return self.images[self.current_index]

    def register_save(self, path: Path) -> None:
        """Track saved mask paths in first-save order without duplicates."""

        if path not in self.saved_paths:
            self.saved_paths.append(path)
