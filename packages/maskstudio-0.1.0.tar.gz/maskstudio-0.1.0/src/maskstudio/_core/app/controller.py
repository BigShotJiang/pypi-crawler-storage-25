"""Controller que coordena o estado da sessão, I/O e eventos da GUI.
Última atualização: 2026-04-17.
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QEventLoop, QObject, QRectF, Signal
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QApplication, QWidget

from maskstudio._core.app.session import AnnotationDocument, RoiState, SessionState
from maskstudio._core.domain.geometry import GeometryEngine
from maskstudio._core.domain.models import DocumentState, RefinementOptions, ToolKind
from maskstudio._core.domain.rasterize import MaskRasterizer
from maskstudio._core.domain.refinement import ContourRefiner
from maskstudio._core.domain.vectorize import MaskVectorizer
from maskstudio._core.i18n import TranslationCatalog
from maskstudio._core.io.images import apply_display_adjustments, array_to_qimage, load_image_array
from maskstudio._core.io.masks import load_existing_mask_geometry, mask_output_path, save_mask
from maskstudio._core.ui import dialogs


class WorkspaceController(QObject):
    """Coordena a sessão da aplicação e dirige a interface."""

    document_changed = Signal()
    geometry_changed = Signal()
    display_changed = Signal()
    theme_changed = Signal()
    roi_changed = Signal(QRectF)
    status_changed = Signal()
    fit_full_requested = Signal()

    def __init__(self, image_paths: list[Path]) -> None:
        super().__init__()
        self.session = SessionState(images=image_paths)
        self.catalog = TranslationCatalog()
        self.vectorizer = MaskVectorizer()
        self.rasterizer = MaskRasterizer()
        self.refiner = ContourRefiner()
        self.active_tool = ToolKind.SELECTION
        self._window: QWidget | None = None
        # Snapshot da sessão de ajuste via sliders (smooth/snap/scale)
        self._adjust_snapshot: DocumentState | None = None
        self._adjust_indices: set[int] = set()
        if image_paths:
            self._load_document(image_paths[0])
            current = self.current_document
            if current is not None:
                width, height = current.size
                self.session.roi = RoiState.default_for_size(width, height)

    @property
    def current_document(self) -> AnnotationDocument | None:
        """Retorna o documento ativo no momento."""

        path = self.session.current_path
        if path is None:
            return None
        return self.session.documents.get(path)

    def run(self, owns_app: bool = False) -> list[Path]:
        """Cria a janela principal e retorna caminhos salvos ao fechar."""

        from maskstudio._core.ui.main_window import MainWindow

        window = MainWindow(self)
        self._window = window
        window.show()
        app = QApplication.instance()
        if app is None:
            return []
        if owns_app:
            app.exec()
        else:
            loop = QEventLoop()
            window.closed.connect(loop.quit)
            loop.exec()
        return list(self.session.saved_paths)

    def translate(self, key: str, **kwargs: object) -> str:
        """Traduz uma chave de string de UI."""

        return self.catalog.get(key, **kwargs)

    def current_qimage(self) -> QImage:
        """Retorna a imagem ajustada para exibição do documento atual."""

        document = self._require_document()
        adjusted = apply_display_adjustments(
            document.image_array,
            self.session.display.brightness,
            self.session.display.contrast,
        )
        return array_to_qimage(adjusted)

    def set_active_tool(self, tool: ToolKind) -> None:
        """Ativa uma ferramenta, limpa seleção ao trocar para ferramentas de desenho."""

        if self.active_tool == tool:
            return
        self.active_tool = tool
        # Limpa seleção apenas ao entrar em ferramentas de desenho
        drawing_tools = {ToolKind.BRUSH, ToolKind.POLYGON, ToolKind.RECTANGLE, ToolKind.HOLE}
        document = self.current_document
        if tool in drawing_tools and document is not None:
            document.selection.clear()
        self.geometry_changed.emit()
        self.status_changed.emit()

    def set_overlay_color(self, color_name: str) -> None:
        """Atualiza a cor global do overlay."""

        self.session.display.overlay_color = color_name
        self.display_changed.emit()
        self.theme_changed.emit()

    def set_overlay_opacity(self, opacity: float) -> None:
        """Atualiza a opacidade global do overlay."""

        self.session.display.overlay_opacity = max(0.05, min(opacity, 1.0))
        self.display_changed.emit()

    def set_outline_width(self, width: float) -> None:
        """Atualiza a largura global do contorno."""

        self.session.display.outline_width = max(1.0, width)
        self.display_changed.emit()

    def set_brightness(self, brightness: int) -> None:
        """Atualiza o brilho de exibição."""

        self.session.display.brightness = brightness
        self.display_changed.emit()

    def set_contrast(self, contrast: int) -> None:
        """Atualiza o contraste de exibição."""

        self.session.display.contrast = contrast
        self.display_changed.emit()

    def set_brush_radius(self, radius: float) -> None:
        """Atualiza o raio do pincel."""

        self.session.display.brush_radius = max(1.0, radius)
        self.status_changed.emit()

    def set_dark_theme(self, enabled: bool) -> None:
        """Alterna o tema da aplicação."""

        self.session.display.dark_theme = enabled
        self.theme_changed.emit()

    def update_cursor_position(self, x: float, y: float) -> None:
        """Armazena a última posição do cursor em coordenadas de imagem."""

        self.session.cursor_position = (x, y)
        self.status_changed.emit()

    def update_zoom_percent(self, zoom_percent: float) -> None:
        """Armazena o percentual de zoom da view ativa."""

        self.session.zoom_percent = zoom_percent
        self.status_changed.emit()

    def set_selection(self, selection: set[int]) -> None:
        """Substitui a seleção de polígonos atual."""

        document = self._require_document()
        max_index = len(GeometryEngine.polygons(document.geometry)) - 1
        document.selection = {index for index in selection if 0 <= index <= max_index}
        self.geometry_changed.emit()
        self.status_changed.emit()

    def select_at(self, point: tuple[float, float], multi: bool = False) -> None:
        """Seleciona ou desseleciona o polígono sob o cursor.

        Clicar novamente num polígono já selecionado sozinho o desseleciona.
        """

        document = self._require_document()
        index = GeometryEngine.find_polygon_index(document.geometry, point)
        if index is None:
            if not multi:
                document.selection.clear()
                self.geometry_changed.emit()
                self.status_changed.emit()
            return
        if multi:
            if index in document.selection:
                document.selection.remove(index)
            else:
                document.selection.add(index)
        else:
            # Toggle: clicar no polígono já selecionado como único o desseleciona
            if document.selection == {index}:
                document.selection.clear()
            else:
                document.selection = {index}
        self.geometry_changed.emit()
        self.status_changed.emit()

    def apply_add_geometry(self, geometry) -> None:
        """Adiciona nova geometria e registra no histórico."""

        document = self._require_document()
        updated = GeometryEngine.union(document.geometry, geometry)
        self._commit_geometry(updated)

    def apply_subtract_geometry(self, geometry) -> None:
        """Subtrai geometria e registra no histórico."""

        document = self._require_document()
        updated = GeometryEngine.subtract(document.geometry, geometry)
        self._commit_geometry(updated)

    def delete_selected(self) -> None:
        """Remove apenas os polígonos selecionados da imagem atual.

        Se não houver seleção, não faz nada.
        """

        document = self._require_document()
        if not document.selection:
            return
        updated = GeometryEngine.replace_polygons(document.geometry, document.selection, [])
        self._commit_geometry(updated, selection=set())

    def clear_current_geometry(self) -> None:
        """Remove todas as anotações da imagem atual."""

        self._commit_geometry(GeometryEngine.empty(), selection=set())

    def apply_temporary_geometry(
        self,
        geometry,
        selection: set[int] | None = None,
        *,
        normalize: bool = True,
    ) -> None:
        """Atualiza a geometria ao vivo sem empurrar snapshot no histórico.

        ### Parâmetros:
            geometry: Geometria a aplicar.
            selection: Seleção opcional a substituir.
            normalize: Quando False, preserva a ordem e os índices dos vértices
                (indicado para fluxos de arrasto de handle).
        """

        document = self._require_document()
        document.geometry = GeometryEngine.normalize(geometry) if normalize else geometry
        document.preview_geometry = None
        if selection is not None:
            document.selection = selection
        self._normalize_selection(document)
        self.geometry_changed.emit()
        self.status_changed.emit()

    def finalize_temporary_geometry(self, original: DocumentState) -> None:
        """Empurra snapshot se a edição temporária alterou o documento.

        Ao finalizar, re-normaliza a geometria para garantir validade e
        precisão do grid, já que o arrasto usa apply_temporary_geometry
        sem normalizar para preservar índices dos vértices.
        """

        document = self._require_document()
        document.geometry = GeometryEngine.normalize(document.geometry)
        self._normalize_selection(document)
        if document.snapshot() != original:
            document.history.push(document.snapshot())
        else:
            document.restore(original)
        self.geometry_changed.emit()
        self.status_changed.emit()

    def restore_snapshot(self, snapshot: DocumentState) -> None:
        """Restaura um snapshot imediatamente."""

        document = self._require_document()
        document.restore(snapshot)
        self.geometry_changed.emit()
        self.status_changed.emit()

    def undo(self) -> None:
        """Desfaz a última operação do documento atual."""

        document = self._require_document()
        snapshot = document.history.undo()
        if snapshot is None:
            return
        document.restore(snapshot)
        self.geometry_changed.emit()
        self.status_changed.emit()

    def redo(self) -> None:
        """Refaz a última operação desfeita do documento atual."""

        document = self._require_document()
        snapshot = document.history.redo()
        if snapshot is None:
            return
        document.restore(snapshot)
        self.geometry_changed.emit()
        self.status_changed.emit()

    def save_current(self) -> Path:
        """Salva a máscara atual no caminho gerado."""

        document = self._require_document()
        target = save_mask(document.image_path, document.geometry, document.size, self.rasterizer)
        document.mask_path = target
        document.mark_saved()
        self.session.register_save(target)
        self.status_changed.emit()
        return target

    def save_and_next(self) -> None:
        """Salva o documento atual (se houver alterações) e avança para o próximo."""

        document = self.current_document
        if document is not None and document.dirty:
            self.save_current()
        self.go_to_index(min(self.session.current_index + 1, len(self.session.images) - 1))

    def go_to_index(self, index: int) -> bool:
        """Navega para um novo índice de imagem, aplicando a política de alterações não salvas."""

        if not (0 <= index < len(self.session.images)):
            return False
        if index == self.session.current_index:
            return True
        if not self._resolve_unsaved_changes():
            return False

        self.session.current_index = index
        self._load_document(self.session.images[index])
        document = self._require_document()
        width, height = document.size
        self.session.roi = RoiState.default_for_size(width, height)
        self.document_changed.emit()
        self.roi_changed.emit(self.session.roi.to_rect())
        self.status_changed.emit()
        return True

    def go_previous(self) -> bool:
        """Move para a imagem anterior se disponível."""

        return self.go_to_index(self.session.current_index - 1)

    def go_next(self) -> bool:
        """Move para a próxima imagem se disponível."""

        return self.go_to_index(self.session.current_index + 1)

    def set_roi_rect(self, rect: QRectF) -> None:
        """Aplica um novo retângulo de ROI, limitando às bordas da imagem."""

        document = self._require_document()
        image_width, image_height = document.size
        minimum = self.session.roi.minimum_size if self.session.roi is not None else 32.0

        left = max(0.0, rect.left())
        top = max(0.0, rect.top())
        width = max(minimum, rect.width())
        height = max(minimum, rect.height())
        if left + width > image_width:
            left = max(0.0, image_width - width)
        if top + height > image_height:
            top = max(0.0, image_height - height)
        width = min(width, float(image_width))
        height = min(height, float(image_height))
        self.session.roi = RoiState(left, top, width, height, minimum)
        self.roi_changed.emit(self.session.roi.to_rect())
        self.status_changed.emit()

    def reset_roi(self) -> None:
        """Redefine a ROI para o retângulo centralizado padrão."""

        document = self._require_document()
        width, height = document.size
        self.session.roi = RoiState.default_for_size(width, height)
        self.roi_changed.emit(self.session.roi.to_rect())
        self.status_changed.emit()

    def begin_adjust_session(self, *, only_refinable: bool) -> bool:
        """Inicia uma sessão de ajuste por slider sobre a seleção atual.

        ### Parâmetros:
            only_refinable: Quando True, limita a sessão a polígonos não
                retangulares (smooth/snap só fazem sentido nesses). Para
                escala, aceita todos os polígonos selecionados.

        ### Retorna:
            True se houver ao menos um polígono elegível, False caso contrário.
        """

        document = self._require_document()
        if not document.selection:
            return False
        if only_refinable:
            indices = self._refinable_indices(document.geometry, document.selection)
        else:
            indices = set(document.selection)
        if not indices:
            return False
        self._adjust_snapshot = document.snapshot()
        self._adjust_indices = indices
        return True

    def preview_smooth(self, level: int) -> None:
        """Aplica suavização Laplaciana temporária com a intensidade do slider."""

        if self._adjust_snapshot is None:
            return
        document = self._require_document()
        original = GeometryEngine.from_wkb(self._adjust_snapshot.geometry_wkb)
        iterations = max(1, int(level))
        options = RefinementOptions(
            smooth_iterations=iterations,
            enable_smooth=True,
            enable_edge_snap=False,
        )
        updated = self.refiner.refine(
            original,
            document.image_array,
            options,
            selection=self._adjust_indices,
        )
        self.apply_temporary_geometry(updated, selection=document.selection)

    def preview_snap(self, strength: int) -> None:
        """Aplica snap de bordas temporário com intensidade do slider.

        A intensidade controla o raio de busca (proporcional à força escolhida)
        e o limiar Canny (mais agressivo para forças maiores).
        """

        if self._adjust_snapshot is None:
            return
        document = self._require_document()
        original = GeometryEngine.from_wkb(self._adjust_snapshot.geometry_wkb)
        level = max(1, int(strength))
        edge_radius = max(8, int(round(level * 0.9)))
        canny_low = max(20, 60 - level // 2)
        canny_high = max(60, 140 - level // 2)
        options = RefinementOptions(
            enable_smooth=False,
            enable_edge_snap=True,
            edge_radius=edge_radius,
            canny_low=canny_low,
            canny_high=canny_high,
        )
        updated = self.refiner.refine(
            original,
            document.image_array,
            options,
            selection=self._adjust_indices,
        )
        self.apply_temporary_geometry(updated, selection=document.selection)

    def preview_scale(self, percent: int) -> None:
        """Escala proporcionalmente a seleção em torno do centroide de cada polígono.

        O valor percent varia tipicamente de -50 a +50: 0 preserva o tamanho,
        valores positivos aumentam e negativos diminuem.
        """

        if self._adjust_snapshot is None:
            return
        document = self._require_document()
        original = GeometryEngine.from_wkb(self._adjust_snapshot.geometry_wkb)
        factor = max(0.05, 1.0 + float(percent) / 100.0)
        updated = GeometryEngine.scale_polygons(
            original,
            self._adjust_indices,
            factor,
        )
        self.apply_temporary_geometry(updated, selection=document.selection)

    def finalize_adjust_session(self) -> None:
        """Finaliza a sessão de ajuste, empurrando snapshot se houve mudança."""

        snapshot = self._adjust_snapshot
        self._adjust_snapshot = None
        self._adjust_indices = set()
        if snapshot is None:
            return
        self.finalize_temporary_geometry(snapshot)

    def cancel_adjust_session(self) -> None:
        """Cancela a sessão de ajuste restaurando o snapshot original."""

        snapshot = self._adjust_snapshot
        self._adjust_snapshot = None
        self._adjust_indices = set()
        if snapshot is None:
            return
        self.restore_snapshot(snapshot)

    def _refinable_indices(self, geometry, selection) -> set[int]:
        """Retorna índices de polígonos selecionados elegíveis a refinement.

        Exclui retângulos, que não se beneficiam de suavização ou snap por
        terem poucos vértices e forma fechada definida.
        """

        polygons = GeometryEngine.polygons(geometry)
        return {
            i for i in selection
            if 0 <= i < len(polygons)
            and GeometryEngine.polygon_kind(polygons[i]) != "rectangle"
        }

    def simplify_and_edit_selected(self) -> None:
        """Simplifica os polígonos selecionados e ativa a ferramenta de edição de contorno."""

        document = self._require_document()
        if not document.selection:
            return
        updated = GeometryEngine.simplify_for_editing(document.geometry, document.selection)
        self._commit_geometry(updated, selection=document.selection)
        self.set_active_tool(ToolKind.CONTOUR_EDIT)

    def confirm_close(self) -> bool:
        """Resolve alterações não salvas antes de fechar a janela."""

        return self._resolve_unsaved_changes()

    def tool_key(self, tool: ToolKind | None = None) -> str:
        """Retorna a chave de tradução para uma ferramenta."""

        target = self.active_tool if tool is None else tool
        return {
            ToolKind.SELECTION: "tool.selection",
            ToolKind.BRUSH: "tool.brush",
            ToolKind.POLYGON: "tool.polygon",
            ToolKind.RECTANGLE: "tool.rectangle",
            ToolKind.HOLE: "tool.hole",
            ToolKind.CONTOUR_EDIT: "tool.contour_edit",
            ToolKind.PAN: "tool.pan",
            ToolKind.ROI: "tool.roi",
        }[target]

    def _commit_geometry(self, geometry, selection: set[int] | None = None) -> None:
        document = self._require_document()
        document.geometry = GeometryEngine.normalize(geometry)
        if selection is not None:
            document.selection = selection
        self._normalize_selection(document)
        document.preview_geometry = None
        document.history.push(document.snapshot())
        self.geometry_changed.emit()
        self.status_changed.emit()

    def _normalize_selection(self, document: AnnotationDocument) -> None:
        polygons = GeometryEngine.polygons(document.geometry)
        document.selection = {index for index in document.selection if 0 <= index < len(polygons)}

    def _load_document(self, path: Path) -> AnnotationDocument:
        if path in self.session.documents:
            return self.session.documents[path]
        image_array = load_image_array(str(path))
        geometry = load_existing_mask_geometry(path, self.vectorizer)
        document = AnnotationDocument(
            image_path=path,
            image_array=image_array,
            geometry=geometry,
            mask_path=mask_output_path(path),
        )
        document.mark_saved()
        self.session.documents[path] = document
        return document

    def _resolve_unsaved_changes(self) -> bool:
        document = self.current_document
        if document is None or not document.dirty:
            return True

        decision = self.session.remembered_navigation_decision
        remember = False
        if decision is None:
            decision, remember = dialogs.ask_unsaved_changes(
                self._window,
                document.image_path.name,
            )
        if remember and decision in {"save", "discard"}:
            self.session.remembered_navigation_decision = decision
        if decision == "save":
            self.save_current()
            return True
        return decision == "discard"

    def _require_document(self) -> AnnotationDocument:
        document = self.current_document
        if document is None:
            raise RuntimeError("No active document is loaded.")
        return document
