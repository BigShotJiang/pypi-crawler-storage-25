"""Typed exceptions exposed by the MaskStudio public API.

Todas as exceções do pacote herdam de `MaskStudioError`, permitindo que o
consumidor capture a hierarquia inteira com uma única cláusula `except`.

Última atualização: 2026-04-17.
"""

from __future__ import annotations


class MaskStudioError(Exception):
    """Classe base para todas as exceções públicas do MaskStudio."""


class NoImagesFoundError(MaskStudioError):
    """Levantada quando a pasta fornecida não contém imagens suportadas."""

    def __init__(self, path):
        super().__init__(f"No supported images were found in: {path}")
        self.path = path


class UnsupportedImageError(MaskStudioError):
    """Levantada quando um arquivo informado não é uma imagem suportada."""

    def __init__(self, path):
        super().__init__(f"Unsupported input image: {path}")
        self.path = path


__all__ = [
    "MaskStudioError",
    "NoImagesFoundError",
    "UnsupportedImageError",
]
