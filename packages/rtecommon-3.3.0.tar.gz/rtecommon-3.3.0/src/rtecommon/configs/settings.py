from dotenv import load_dotenv
from pydantic_settings import BaseSettings

load_dotenv()


class EnvironmentSettings(BaseSettings):
    PROJECT_DIR: str = ""
    PROJECT_NAME: str = ""
    VENV_ENVIRONMENT: str = ""


class LoggingSettings(BaseSettings):
    LOG_BACKUP_COUNT: int = -1
    LOG_DIR: str = ""
    LOG_LEVEL_CONSOLE: str = ""
    LOG_LEVEL_FILE: str = ""
    LOG_WHEN: str = "midnight"


class Settings(BaseSettings):
    env: EnvironmentSettings = EnvironmentSettings()
    logging: LoggingSettings = LoggingSettings()


env_settings = EnvironmentSettings()
logging_settings = LoggingSettings()
settings = Settings()
