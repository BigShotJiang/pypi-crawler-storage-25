from __future__ import annotations

import logging
import logging.config
from pathlib import Path

# from rtecommon.logging.formatters import COLORLOG_AVAILABLE
from rtecommon.logging.formatters import TRACE_LEVEL


def _build_config(
    *,
    log_backup_count: int,
    log_dir: Path,
    log_level_console: str,
    log_level_file: str,
    log_when: str,
    service_name: str,
) -> dict[str, object]:
    """Return the logging dictConfig structure."""
    base_format = "[%(asctime)s %(name)s.%(levelname)s %(filename)s:%(lineno)d] %(message)s"
    color_format = "[%(log_color)s%(asctime)s %(name)s.%(levelname)s %(filename)s:%(lineno)d]%(reset)s %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"
    log_path = log_dir / f"{service_name}.log"

    color_formatter: dict[str, object] = {
        "()": "rtecommon.logging.formatters.ShortLevelColoredFormatter",
        "datefmt": date_format,
        "format": color_format,
        "log_colors": {
            "CRITICAL": "bold_red",
            "DEBUG": "cyan",
            "ERROR": "red",
            "INFO": "green",
            "TRACE": "blue",
            "WARNING": "yellow",
        },
    }

    return {
        "disable_existing_loggers": False,
        "formatters": {
            "colorFormatter": color_formatter,
            "simpleFormatter": {
                "()": "rtecommon.logging.formatters.ShortLevelFormatter",
                "datefmt": date_format,
                "format": base_format,
            },
        },
        "handlers": {
            "consoleHandler": {
                "class": "logging.StreamHandler",
                "formatter": "colorFormatter",
                "level": log_level_console,
                "stream": "ext://sys.stdout",
            },
            "fileHandler": {
                "backupCount": log_backup_count,
                "class": "logging.handlers.TimedRotatingFileHandler",
                "encoding": "utf-8",
                "filename": str(log_path),
                "formatter": "simpleFormatter",
                "interval": 1,
                "level": log_level_file,
                "utc": True,
                "when": log_when,
            },
        },
        "loggers": {
            "all": {
                "handlers": ["fileHandler", "consoleHandler"],
                "level": "DEBUG",
                "propagate": False,
            },
            "console": {
                "handlers": ["consoleHandler"],
                "level": "DEBUG",
                "propagate": False,
            },
            "file": {
                "handlers": ["fileHandler"],
                "level": "DEBUG",
                "propagate": False,
            },
        },
        "version": 1,
    }


def _register_trace_level() -> None:
    """Register the TRACE log level and logger method."""
    if logging.getLevelName(TRACE_LEVEL) != "TRACE":
        logging.addLevelName(TRACE_LEVEL, "TRACE")

    if not hasattr(logging, "TRACE"):
        logging.TRACE = TRACE_LEVEL  # type: ignore[attr-defined]
    if not hasattr(logging.Logger, "trace"):

        def trace(self: logging.Logger, msg: str, *args: object, **kwargs: object) -> None:  # type: ignore[override]
            if self.isEnabledFor(TRACE_LEVEL):
                self._log(TRACE_LEVEL, msg, args, **kwargs)

        logging.Logger.trace = trace  # type: ignore[assignment]


def _validate_logging_settings(
    *,
    log_backup_count: int,
    log_dir: str | Path,
    log_level_console: str,
    log_level_file: str,
    log_when: str,
) -> Path:
    """Validate logging settings and return the resolved log directory path."""
    missing_log_variables: list[str] = []
    resolved_log_dir = str(log_dir).strip()

    if not resolved_log_dir:
        missing_log_variables.append("LOG_DIR")
    if not log_level_console:
        missing_log_variables.append("LOG_LEVEL_CONSOLE")
    if not log_level_file:
        missing_log_variables.append("LOG_LEVEL_FILE")
    if not log_when:
        missing_log_variables.append("LOG_WHEN")
    if log_backup_count < 0:
        missing_log_variables.append("LOG_BACKUP_COUNT")
    if missing_log_variables:
        missing_values = ", ".join(missing_log_variables)
        raise ValueError(f"Missing required logging environment variables: {missing_values}")

    return Path(resolved_log_dir)


def setup_logging(
    *,
    log_backup_count: int,
    log_dir: str | Path,
    log_level_console: str,
    log_level_file: str,
    log_when: str = "midnight",
    service_name: str,
) -> Path:
    """Apply the shared logging configuration and return the target log file path."""
    resolved_log_dir = _validate_logging_settings(
        log_backup_count=log_backup_count,
        log_dir=log_dir,
        log_level_console=log_level_console,
        log_level_file=log_level_file,
        log_when=log_when,
    )
    log_path = resolved_log_dir / f"{service_name}.log"

    _register_trace_level()
    resolved_log_dir.mkdir(parents=True, exist_ok=True)
    if not log_path.exists():
        log_path.touch()

    logging.config.dictConfig(
        _build_config(
            log_backup_count=log_backup_count,
            log_dir=resolved_log_dir,
            log_level_console=log_level_console,
            log_level_file=log_level_file,
            log_when=log_when,
            service_name=service_name,
        )
    )
    return log_path
