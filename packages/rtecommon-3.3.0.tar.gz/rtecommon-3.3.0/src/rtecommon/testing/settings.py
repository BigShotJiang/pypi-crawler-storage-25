"""Shared testing configuration models for RTE services."""

from dotenv import load_dotenv
from pydantic_settings import BaseSettings

load_dotenv()


class DevAutoSettings(BaseSettings):
    """Environment-backed settings for Docker-backed development test databases."""

    DEV_AUTO_OVERRIDE: bool = False
    DEV_DB_ROLLBACK_OVERRIDE: bool = False
    DEV_AUTO_MYSQL_HOST: str = ""
    DEV_AUTO_MYSQL_TCP_PORT: int = 0


dev_auto_settings = DevAutoSettings()
