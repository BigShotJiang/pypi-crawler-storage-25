"""Shared pytest-oriented testing helpers for RTE services."""

from rtecommon.testing.settings import dev_auto_settings
from rtecommon.testing.settings import DevAutoSettings

__all__ = ["DevAutoSettings", "dev_auto_settings"]
