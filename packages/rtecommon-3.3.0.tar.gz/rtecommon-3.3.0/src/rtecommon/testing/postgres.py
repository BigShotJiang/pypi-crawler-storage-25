"""Reusable PostgreSQL and Docker test helpers shared across RTE services."""

import time
from dataclasses import dataclass

import docker
import docker.errors
from sqlalchemy import create_engine
from sqlalchemy import text
from sqlalchemy.engine import URL

DB_DUMMY = "postgres"


@dataclass(frozen=True)
class TestDbEnvironmentState:
    """Original environment values plus the resolved host/port used for the test database."""

    connect_host: str
    original_container_name: str
    original_host: str
    original_port: int
    port: int


def build_postgres_url(*, database: str, host: str, password: str, port: int, user: str) -> str:
    """Build a SQLAlchemy PostgreSQL URL string for the provided connection values."""

    return render_url(
        URL.create(
            "postgresql+psycopg2",
            username=user,
            password=password,
            host=host,
            port=port,
            database=database,
        )
    )


def connect_host(host: str) -> str:
    """Normalize localhost-style hosts to the loopback IP used by Docker-backed tests."""

    return "127.0.0.1" if host in ("", "0.0.0.0", "localhost") else host


def database_port(configured_port: int) -> int:
    """Map legacy MySQL default ports to the PostgreSQL test default while preserving explicit ports."""

    return 5432 if configured_port in (0, 3306) else configured_port


def ensure_test_postgres_container(
    *,
    client,
    container_name: str,
    dev_auto_override: bool,
    logger,
    run_container,
):
    """Return the container that should back the test database, creating or reusing it as configured."""

    try:
        container = client.containers.get(container_name)
        if not dev_auto_override:
            container.remove(force=True)
            return run_container()
        if container.status != "running":
            container.start()
        return container
    except docker.errors.NotFound:
        if dev_auto_override:
            containers = client.containers.list(
                all=True,
                filters={
                    "label": [
                        f"com.docker.compose.project={container_name}",
                        "com.docker.compose.service=db",
                    ]
                },
            )
            if len(containers) == 1:
                container = containers[0]
                if container.status != "running":
                    container.start()
                return container
            raise RuntimeError(
                f"Expected existing PostgreSQL container for compose project {container_name!r} and service 'db' "
                f"when DEV_AUTO_OVERRIDE=true"
            )
        logger.info("No existing PostgreSQL container found. Starting %r.", container_name)
        return run_container()


def finalize_db_session(
    *,
    connection,
    dev_db_rollback_override: bool,
    engine,
    event_remove,
    outer_transaction,
    restart_savepoint,
    session,
) -> None:
    """Tear down the db_session fixture, optionally persisting the outer transaction for override mode."""

    event_remove(session, "after_transaction_end", restart_savepoint)
    try:
        if dev_db_rollback_override:
            session.commit()
            outer_transaction.commit()
        else:
            outer_transaction.rollback()
    finally:
        session.close()
        connection.close()
        engine.dispose()


def get_docker_client(
    *,
    docker_module=docker,
    interval: int = 2,
    time_module=time,
    timeout: int = 60,
):
    """Return a Docker client after retrying until the daemon responds or the timeout expires."""

    deadline = time_module.time() + timeout
    last_error = None
    while time_module.time() < deadline:
        try:
            client = docker_module.from_env()
            client.ping()
            return client
        except docker.errors.DockerException as exc:
            last_error = exc
            time_module.sleep(interval)

    raise RuntimeError(f"Docker client unavailable after {timeout}s: {last_error}") from last_error


def prepare_test_db_environment_state(
    *,
    compose_project_name: str,
    dev_auto_mysql_host: str,
    dev_auto_mysql_tcp_port: int,
    dev_auto_override: bool,
    mysql_host: str,
    mysql_tcp_port: int,
) -> tuple[TestDbEnvironmentState, str]:
    """Return the original environment state plus the effective container name for the test database."""

    effective_container_name = compose_project_name
    effective_mysql_host = mysql_host
    effective_mysql_tcp_port = int(mysql_tcp_port)
    original_port = int(mysql_tcp_port)

    if not dev_auto_override:
        effective_container_name = "DevTestContainer"
        effective_mysql_host = dev_auto_mysql_host
        effective_mysql_tcp_port = int(dev_auto_mysql_tcp_port)

    return (
        TestDbEnvironmentState(
            connect_host=connect_host(effective_mysql_host),
            original_container_name=compose_project_name,
            original_host=mysql_host,
            original_port=original_port,
            port=database_port(effective_mysql_tcp_port),
        ),
        effective_container_name,
    )


def quote_identifier(identifier: str) -> str:
    """Quote a SQL identifier and escape embedded double quotes."""

    return '"' + identifier.replace('"', '""') + '"'


def quote_literal(value: str) -> str:
    """Quote a SQL literal and escape embedded single quotes."""

    return "'" + value.replace("'", "''") + "'"


def recreate_test_database(
    *,
    build_postgres_url_fn=build_postgres_url,
    create_engine_fn=create_engine,
    database: str,
    host: str,
    installer_password: str,
    installer_user: str,
    port: int,
    root_password: str,
    root_user: str,
    text_fn=text,
) -> str:
    """Recreate the target test database and installer role through the PostgreSQL maintenance database."""

    admin_url = build_postgres_url_fn(
        database=DB_DUMMY,
        host=host,
        password=root_password,
        port=port,
        user=root_user,
    )
    admin_engine = create_engine_fn(admin_url, future=True, pool_pre_ping=True)
    quoted_database = quote_identifier(database)
    quoted_installer = quote_identifier(installer_user)
    quoted_password = quote_literal(installer_password)

    try:
        with admin_engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
            conn.execute(
                text_fn("""
                SELECT pg_terminate_backend(pid)
                FROM pg_stat_activity
                WHERE datname = :db_name
                  AND pid <> pg_backend_pid()
                     """),
                {"db_name": database},
            )
            conn.execute(text_fn(f"DROP DATABASE IF EXISTS {quoted_database}"))
            conn.execute(text_fn(f"DROP ROLE IF EXISTS {quoted_installer}"))
            conn.execute(text_fn(f"CREATE ROLE {quoted_installer} WITH LOGIN PASSWORD {quoted_password}"))
            conn.execute(text_fn(f"CREATE DATABASE {quoted_database} WITH OWNER {quoted_installer}"))
            conn.execute(text_fn(f"GRANT ALL PRIVILEGES ON DATABASE {quoted_database} TO {quoted_installer}"))
    finally:
        admin_engine.dispose()

    return host


def render_url(url: URL) -> str:
    """Render a SQLAlchemy URL to a connection string with the password included."""

    return url.render_as_string(hide_password=False)


def wait_for_postgres(
    container,
    *,
    build_postgres_url_fn=build_postgres_url,
    create_engine_fn=create_engine,
    database: str,
    host: str,
    password: str,
    port: int,
    text_fn=text,
    time_module=time,
    timeout: int = 60,
    interval: int = 2,
    user: str,
) -> None:
    """Poll the container until PostgreSQL is reachable from the host side or a timeout occurs."""

    deadline = time_module.time() + timeout
    last_connection_error = None
    while time_module.time() < deadline:
        try:
            container.reload()
        except docker.errors.NotFound as exc:
            raise RuntimeError(f"Container {container.name!r} no longer exists.") from exc

        if container.status != "running":
            time_module.sleep(interval)
            continue

        exit_code, _ = container.exec_run(["pg_isready", "-U", user, "-d", database])
        if exit_code == 0:
            probe_engine = create_engine_fn(
                build_postgres_url_fn(
                    database=database,
                    host=host,
                    password=password,
                    port=port,
                    user=user,
                ),
                future=True,
                pool_pre_ping=True,
            )
            try:
                with probe_engine.connect() as conn:
                    conn.execute(text_fn("SELECT 1"))
                return
            except Exception as exc:
                last_connection_error = exc
            finally:
                probe_engine.dispose()

        time_module.sleep(interval)

    logs = container.logs(tail=120).decode("utf-8", errors="ignore")
    raise TimeoutError(
        f"PostgreSQL container {container.name!r} did not become ready within {timeout}s.\n"
        f"Last host-side connection error: {last_connection_error}\n"
        f"{logs}"
    )
