"""Factory helpers for repo-local pytest fixtures built on shared test infrastructure."""

from collections.abc import Callable


def make_db_session_fixture(
    *,
    create_engine_getter: Callable[[], object],
    event_getter: Callable[[], object],
    finalize_db_session_getter: Callable[[], Callable[..., None]],
    session_setup_getter: Callable[[], Callable[..., None]] | None = None,
    session_teardown_getter: Callable[[], Callable[..., None]] | None = None,
    sessionmaker_getter: Callable[[], object],
):
    """Return a pytest fixture that creates a nested-transaction SQLAlchemy session."""

    import pytest

    @pytest.fixture
    def db_session(test_db_url, init_db):
        create_engine = create_engine_getter()
        event = event_getter()
        finalize_db_session = finalize_db_session_getter()
        session_setup = session_setup_getter() if session_setup_getter is not None else None
        session_teardown = session_teardown_getter() if session_teardown_getter is not None else None
        sessionmaker = sessionmaker_getter()
        engine = create_engine(test_db_url, future=True, pool_pre_ping=True)
        connection = engine.connect()
        outer_transaction = connection.begin()
        session_local = sessionmaker(bind=connection, autocommit=False, autoflush=False)
        session = session_local()

        if session_setup is not None:
            session_setup(
                connection=connection,
                engine=engine,
                outer_transaction=outer_transaction,
                session=session,
                session_local=session_local,
            )

        session.begin_nested()

        @event.listens_for(session, "after_transaction_end")
        def restart_savepoint(active_session, ended_transaction):
            parent = getattr(ended_transaction, "parent", None)
            if ended_transaction.nested and (parent is None or not getattr(parent, "nested", False)):
                active_session.expire_all()
                active_session.begin_nested()

        try:
            yield session
        finally:
            try:
                finalize_db_session(
                    connection=connection,
                    engine=engine,
                    outer_transaction=outer_transaction,
                    restart_savepoint=restart_savepoint,
                    session=session,
                )
            finally:
                if session_teardown is not None:
                    session_teardown(
                        connection=connection,
                        engine=engine,
                        outer_transaction=outer_transaction,
                        session=session,
                        session_local=session_local,
                    )

    return db_session


def make_init_db_fixture(*, create_engine_getter: Callable[[], object], dbdef_getter: Callable[[], object]):
    """Return a pytest fixture that initializes and later disposes the shared dbdef engine."""

    import pytest

    @pytest.fixture(scope="session")
    def init_db(test_db_url):
        create_engine = create_engine_getter()
        dbdef = dbdef_getter()
        dbdef.import_models(print_imports=False)
        dbdef.configure_engine(create_engine(test_db_url, future=True, pool_pre_ping=True))
        dbdef.initialize_database()
        yield
        if dbdef.engine is not None:
            dbdef.engine.dispose()

    return init_db


def make_test_db_url_fixture(
    *,
    build_postgres_url_getter: Callable[[], Callable[..., str]],
    dev_auto_settings_getter: Callable[[], object],
    docker_db_image: str,
    ensure_test_postgres_container_getter: Callable[[], Callable[..., object]],
    env_settings_getter: Callable[[], object],
    get_docker_client_getter: Callable[[], Callable[..., object]],
    logger_getter: Callable[[], object],
    prepare_test_db_environment_getter: Callable[[], Callable[..., object]],
    recreate_test_database_getter: Callable[[], Callable[..., str]],
    restore_test_db_environment_getter: Callable[[], Callable[[object], None]],
    wait_for_postgres_getter: Callable[[], Callable[..., None]],
):
    """Return a pytest fixture that provisions or reuses the Docker-backed PostgreSQL URL."""

    import pytest

    @pytest.fixture(scope="session")
    def test_db_url():
        build_postgres_url = build_postgres_url_getter()
        dev_auto_settings = dev_auto_settings_getter()
        ensure_test_postgres_container = ensure_test_postgres_container_getter()
        env_settings = env_settings_getter()
        get_docker_client = get_docker_client_getter()
        logger = logger_getter()
        prepare_test_db_environment = prepare_test_db_environment_getter()
        recreate_test_database = recreate_test_database_getter()
        restore_test_db_environment = restore_test_db_environment_getter()
        wait_for_postgres = wait_for_postgres_getter()

        def run_test_postgres_container():
            return client.containers.run(
                docker_db_image,
                name=env_settings.COMPOSE_PROJECT_NAME,
                environment={
                    "POSTGRES_DB": env_settings.MYSQL_DATABASE,
                    "POSTGRES_USER": env_settings.MYSQL_ROOT_USER,
                    "POSTGRES_PASSWORD": env_settings.MYSQL_ROOT_PASSWORD,
                },
                ports={"5432/tcp": ("127.0.0.1", port)},
                detach=True,
                mem_limit="256m",
                cpu_quota=25000,
                cpu_period=100000,
            )

        state = prepare_test_db_environment(dev_auto_override=dev_auto_settings.DEV_AUTO_OVERRIDE)
        connect_host = state.connect_host
        port = state.port

        if not env_settings.COMPOSE_PROJECT_NAME:
            raise ValueError("COMPOSE_PROJECT_NAME must be set for Docker-backed tests")

        client = get_docker_client()
        container = ensure_test_postgres_container(
            client=client,
            container_name=env_settings.COMPOSE_PROJECT_NAME,
            dev_auto_override=dev_auto_settings.DEV_AUTO_OVERRIDE,
            run_container=run_test_postgres_container,
        )

        try:
            wait_for_postgres(
                container,
                database=env_settings.MYSQL_DATABASE,
                host=connect_host,
                password=env_settings.MYSQL_ROOT_PASSWORD,
                port=port,
                user=env_settings.MYSQL_ROOT_USER,
            )
            if not dev_auto_settings.DEV_AUTO_OVERRIDE:
                recreate_test_database(
                    database=env_settings.MYSQL_DATABASE,
                    host=connect_host,
                    installer_password=env_settings.INSTALLER_PWD,
                    installer_user=env_settings.INSTALLER_USERID,
                    port=port,
                    root_password=env_settings.MYSQL_ROOT_PASSWORD,
                    root_user=env_settings.MYSQL_ROOT_USER,
                )

            yield build_postgres_url(
                database=env_settings.MYSQL_DATABASE,
                host=connect_host,
                password=env_settings.INSTALLER_PWD,
                port=port,
                user=env_settings.INSTALLER_USERID,
            )
        except Exception as exc:
            logs = container.logs(tail=120).decode("utf-8", errors="ignore")
            logger.error("Db container %r failed to start: %s\n%s", container.name, exc, logs)
            raise RuntimeError(f"Db container {container.name!r} failed to start: {exc}\nContainer logs:\n{logs}")
        finally:
            restore_test_db_environment(state)

    return test_db_url
