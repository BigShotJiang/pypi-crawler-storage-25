import importlib
import pkgutil
from contextlib import contextmanager
from dataclasses import dataclass

from sqlalchemy import create_engine
from sqlalchemy import inspect
from sqlalchemy import text
from sqlalchemy.engine import Engine
from sqlalchemy.engine import URL
from sqlalchemy.exc import DatabaseError
from sqlalchemy.exc import IntegrityError
from sqlalchemy.exc import OperationalError
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import sessionmaker

POSTGRES_MAINTENANCE_DB = "postgres"

engine: Engine | None = None
SessionLocal = sessionmaker(autocommit=False, autoflush=False)
_runtime = None


@dataclass
class DbDefRuntime:
    app_label: str
    base: object
    env_settings: object
    log_console: object
    tables_package_name: str


def _database_port() -> int:
    """Resolve the active database port, translating stale MySQL defaults to PostgreSQL."""
    runtime = _require_runtime()
    configured_port = int(runtime.env_settings.MYSQL_TCP_PORT or 0)
    if configured_port in (0, 3306):
        return 5432
    return configured_port


def _quote_identifier(identifier: str) -> str:
    """Quote a PostgreSQL identifier safely."""
    return '"' + identifier.replace('"', '""') + '"'


def _quote_literal(value: str) -> str:
    """Quote a SQL literal safely for small bootstrap statements."""
    return "'" + value.replace("'", "''") + "'"


def _render_url(url: URL) -> str:
    """Render a SQLAlchemy URL with the password left visible for callers."""
    return url.render_as_string(hide_password=False)


def _require_runtime() -> DbDefRuntime:
    """Return the configured runtime or fail fast when dbdef has not been configured."""
    if _runtime is None:
        raise RuntimeError("rtecommon.dbdef runtime is not configured")
    return _runtime


def configure_engine(configured_engine: Engine) -> Engine:
    """Bind the shared session factory to a specific SQLAlchemy engine."""
    global engine
    engine = configured_engine
    SessionLocal.configure(bind=engine)
    return engine


def configure_runtime(
    *, app_label: str, base: object, env_settings: object, log_console: object, tables_package_name: str
) -> None:
    """Configure rtecommon.dbdef for a specific consuming service package."""
    global _runtime
    _runtime = DbDefRuntime(
        app_label=app_label,
        base=base,
        env_settings=env_settings,
        log_console=log_console,
        tables_package_name=tables_package_name,
    )


def configure_session_factory(session_factory):
    """Bind the shared db runtime to a caller-provided session factory."""
    global SessionLocal
    SessionLocal = session_factory
    return SessionLocal


def create_tables(local_engine: Engine | None = None):
    """Create all locally defined database tables."""
    runtime = _require_runtime()
    target_engine = local_engine or get_engine()
    try:
        runtime.log_console.info("Creating database tables from local %s models.", runtime.app_label)
        runtime.base.metadata.create_all(bind=target_engine)
        runtime.log_console.info("Done creating database tables.")
    except SQLAlchemyError as exc:
        runtime.log_console.error("Error during table creation: %s", exc)
        raise


def database_exists() -> bool:
    """Check whether the target application database already exists."""
    runtime = _require_runtime()
    root_engine = create_engine(get_root_uri(), future=True, pool_pre_ping=True)
    try:
        with root_engine.connect() as conn:
            result = conn.execute(
                text("SELECT 1 FROM pg_database WHERE datname = :db_name"),
                {"db_name": runtime.env_settings.MYSQL_DATABASE},
            )
            return result.scalar() is not None
    finally:
        root_engine.dispose()


def ensure_database():
    """Create the application database if needed and enforce installer ownership."""
    runtime = _require_runtime()
    root_engine = create_engine(get_root_uri(), future=True, pool_pre_ping=True)
    quoted_database = _quote_identifier(runtime.env_settings.MYSQL_DATABASE)
    quoted_installer = _quote_identifier(runtime.env_settings.INSTALLER_USERID)
    alter_owner_sql = f"ALTER DATABASE {quoted_database} OWNER TO {quoted_installer}"
    create_db_sql = f"CREATE DATABASE {quoted_database} OWNER {quoted_installer}"
    grant_db_sql = f"GRANT ALL PRIVILEGES ON DATABASE {quoted_database} TO {quoted_installer}"
    try:
        with root_engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
            if not database_exists():
                conn.execute(text(create_db_sql))
                runtime.log_console.info("Created database '%s'.", runtime.env_settings.MYSQL_DATABASE)
            else:
                runtime.log_console.info("Database '%s' already exists.", runtime.env_settings.MYSQL_DATABASE)
            conn.execute(text(alter_owner_sql))
            conn.execute(text(grant_db_sql))
    finally:
        root_engine.dispose()


def ensure_database_permissions():
    """Grant the installer role ownership and default privileges on the public schema."""
    runtime = _require_runtime()
    root_engine = create_engine(
        get_root_uri(runtime.env_settings.MYSQL_DATABASE),
        future=True,
        pool_pre_ping=True,
    )
    quoted_installer = _quote_identifier(runtime.env_settings.INSTALLER_USERID)
    try:
        with root_engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
            conn.execute(text(f"ALTER SCHEMA public OWNER TO {quoted_installer}"))
            conn.execute(text(f"GRANT ALL ON SCHEMA public TO {quoted_installer}"))
            conn.execute(text(f"ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO {quoted_installer}"))
            conn.execute(
                text(f"ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO {quoted_installer}")
            )
    finally:
        root_engine.dispose()


def ensure_installer_role():
    """Create or update the installer role used by the consuming service."""
    runtime = _require_runtime()
    root_engine = create_engine(get_root_uri(), future=True, pool_pre_ping=True)
    quoted_password = _quote_literal(runtime.env_settings.INSTALLER_PWD)
    quoted_role = _quote_identifier(runtime.env_settings.INSTALLER_USERID)
    try:
        with root_engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
            if installer_role_exists():
                conn.execute(text(f"ALTER ROLE {quoted_role} WITH LOGIN PASSWORD {quoted_password}"))
                runtime.log_console.info("Updated installer role '%s'.", runtime.env_settings.INSTALLER_USERID)
            else:
                conn.execute(text(f"CREATE ROLE {quoted_role} WITH LOGIN PASSWORD {quoted_password}"))
                runtime.log_console.info("Created installer role '%s'.", runtime.env_settings.INSTALLER_USERID)
    finally:
        root_engine.dispose()


def get_db():
    """
    Dependency that provides an SQLAlchemy Session,
    rolls back on error, and closes the session.
    """
    runtime = _require_runtime()
    session = get_session_factory()()
    try:
        yield session
    except IntegrityError as exc:
        session.rollback()
        runtime.log_console.error("Data integrity violation: %s", exc)
        raise
    except OperationalError as exc:
        session.rollback()
        runtime.log_console.error("Operational error (e.g. connection/pool issue): %s", exc)
        raise
    except DatabaseError as exc:
        session.rollback()
        runtime.log_console.error("Generic database error: %s", exc)
        raise
    except Exception as exc:
        session.rollback()
        runtime.log_console.error("Unexpected error: %s", exc)
        raise
    finally:
        session.close()


@contextmanager
def get_db_session():
    """Expose the dependency-style session provider as a context manager."""
    db_generator = get_db()
    session = next(db_generator)
    try:
        yield session
    finally:
        db_generator.close()


def get_db_uri() -> str:
    """Build the application PostgreSQL connection URI."""
    runtime = _require_runtime()
    return _render_url(
        URL.create(
            "postgresql+psycopg2",
            username=runtime.env_settings.INSTALLER_USERID,
            password=runtime.env_settings.INSTALLER_PWD,
            host=runtime.env_settings.MYSQL_HOST,
            port=_database_port(),
            database=runtime.env_settings.MYSQL_DATABASE,
        )
    )


def get_engine() -> Engine:
    """Return the shared SQLAlchemy engine, creating it lazily when required."""
    if engine is None:
        configure_engine(create_engine(get_db_uri(), future=True, pool_pre_ping=True))
    return engine


def get_root_uri(database: str = POSTGRES_MAINTENANCE_DB) -> str:
    """Build the maintenance PostgreSQL connection URI."""
    runtime = _require_runtime()
    return _render_url(
        URL.create(
            "postgresql+psycopg2",
            username=runtime.env_settings.MYSQL_ROOT_USER,
            password=runtime.env_settings.MYSQL_ROOT_PASSWORD,
            host=runtime.env_settings.MYSQL_HOST,
            port=runtime.env_settings.MYSQL_TCP_PORT,
            database=runtime.env_settings.MYSQL_DATABASE,
        )
    )


def get_session_factory():
    """Return the shared session factory after ensuring it is bound to an engine."""
    get_engine()
    return SessionLocal


def import_models(print_imports: bool = False):
    """Import all table modules so SQLAlchemy metadata is fully registered."""
    runtime = _require_runtime()
    tables_package = importlib.import_module(runtime.tables_package_name)

    if print_imports:
        print(f"Importing models from {runtime.tables_package_name}...")

    for _, module_name, _ in pkgutil.iter_modules(tables_package.__path__):
        if print_imports:
            print(f" - importing: {module_name}")
        importlib.import_module(f"{runtime.tables_package_name}.{module_name}")

    if print_imports:
        print("\nAll tables registered with base: ")
        for key in runtime.base.metadata.tables.keys():
            print(f"\t- {key}")


def initialize_database():
    """Ensure the PostgreSQL database exists and create the local database tables."""
    runtime = _require_runtime()
    try:
        ensure_installer_role()
        ensure_database()
        ensure_database_permissions()
        import_models(print_imports=True)

        if getattr(runtime.env_settings, "VENV_ENVIRONMENT", "") == "prod":
            runtime.log_console.info(
                "Models imported. Automatic table creation skipped in production environment (%s).",
                runtime.env_settings.VENV_ENVIRONMENT,
            )
            return

        local_engine = get_engine()
        if tables_exist(local_engine):
            runtime.log_console.info("Database tables already exist.")
            return

        create_tables(local_engine)
    except OperationalError as exc:
        runtime.log_console.error(
            "Cannot connect to PostgreSQL at %s:%s. Please ensure PostgreSQL is running and accessible. Error: %s",
            runtime.env_settings.MYSQL_HOST,
            _database_port(),
            exc,
        )
        raise


def installer_role_exists() -> bool:
    """Check whether the application installer role already exists."""
    runtime = _require_runtime()
    root_engine = create_engine(get_root_uri(), future=True, pool_pre_ping=True)
    try:
        with root_engine.connect() as conn:
            result = conn.execute(
                text("SELECT 1 FROM pg_roles WHERE rolname = :role_name"),
                {"role_name": runtime.env_settings.INSTALLER_USERID},
            )
            return result.scalar() is not None
    finally:
        root_engine.dispose()


def reset_engine_and_session_factory() -> None:
    """Reset the shared engine and session factory for isolated test runs."""
    global SessionLocal
    global engine

    if engine is not None:
        engine.dispose()
    engine = None
    if hasattr(SessionLocal, "configure"):
        SessionLocal.configure(autocommit=False, autoflush=False, bind=None)
        return

    SessionLocal = sessionmaker(autocommit=False, autoflush=False)


def tables_exist(local_engine: Engine | None = None) -> bool:
    """Return True when all locally defined tables already exist."""
    runtime = _require_runtime()
    check_engine = local_engine or get_engine()
    try:
        with check_engine.connect():
            inspector = inspect(check_engine)
            existing_tables = set(inspector.get_table_names())
            expected_tables = set(runtime.base.metadata.tables.keys())
            return expected_tables.issubset(existing_tables) and len(expected_tables) > 0
    except OperationalError as exc:
        runtime.log_console.warning(
            "Could not connect to database to check tables. Make sure PostgreSQL is running on %s:%s. Error: %s",
            runtime.env_settings.MYSQL_HOST,
            _database_port(),
            exc,
        )
        return False
    except Exception as exc:
        runtime.log_console.warning("Could not check if tables exist: %s", exc)
        return False


@contextmanager
def transaction():
    session = get_session_factory()()
    try:
        yield session
        session.commit()
    except IntegrityError:
        session.rollback()
        raise
    except OperationalError:
        session.rollback()
        raise
    except DatabaseError:
        session.rollback()
        raise
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
