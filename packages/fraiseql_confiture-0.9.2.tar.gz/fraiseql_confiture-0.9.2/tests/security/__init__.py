"""Security tests for Confiture."""
