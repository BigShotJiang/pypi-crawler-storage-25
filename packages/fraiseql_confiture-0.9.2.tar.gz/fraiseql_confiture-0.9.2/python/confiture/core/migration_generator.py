"""Migration file generator from schema diffs.

This module generates Python migration files from SchemaDiff objects.
Each migration file contains up() and down() methods with the necessary SQL.
"""

import fcntl
import shlex
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any

from confiture.core.introspection.differ_sql import DifferSQLGenerator
from confiture.core.sql_utils import strip_transaction_wrappers
from confiture.exceptions import ExternalGeneratorError, UnsafeOperationError
from confiture.models.schema import SchemaChange, SchemaDiff


class MigrationGenerator:
    """Generates Python migration files from schema diffs.

    Example:
        >>> generator = MigrationGenerator(migrations_dir=Path("db/migrations"))
        >>> diff = SchemaDiff(changes=[...])
        >>> migration_file = generator.generate(diff, name="add_users_table")
    """

    def __init__(self, migrations_dir: Path):
        """Initialize migration generator.

        Args:
            migrations_dir: Directory where migration files will be created
        """
        self.migrations_dir = migrations_dir
        # Non-destructive generator — destructive ops emit warning comments instead of raising
        self._sql_gen = DifferSQLGenerator(force_destructive=False)

    def generate(self, diff: SchemaDiff, name: str) -> Path:
        """Generate migration file from schema diff.

        Args:
            diff: Schema diff containing changes
            name: Name for the migration (snake_case)

        Returns:
            Path to generated migration file

        Raises:
            ValueError: If diff has no changes
        """
        if not diff.has_changes():
            raise ValueError("No changes to generate migration from")

        # Get next version number
        version = self._get_next_version()

        # Generate file path
        filename = f"{version}_{name}.py"
        filepath = self.migrations_dir / filename

        # Generate migration code
        code = self._generate_migration_code(diff, version, name)

        # Write file
        filepath.write_text(code)

        return filepath

    def _get_next_version(self) -> str:
        """Generate a timestamp-based migration version (seconds precision).

        Returns:
            Version string in YYYYMMDDHHmmSS format (e.g., "20260228120530").
            Guaranteed unique for practical migration rates (< 1/second per developer).

        Note:
            Timestamps are seconds-precision to ensure lexicographic sort order
            matches chronological order. Collision probability at 10 migrations/day
            per developer is negligible.
        """
        return datetime.now().strftime("%Y%m%d%H%M%S")

    def _validate_versions(self) -> dict[str, list[Path]]:
        """Validate migration versions for duplicates.

        Returns:
            Dict mapping version numbers to list of files with that version.
            Empty dict if no duplicates exist.
        """
        version_map: dict[str, list[Path]] = {}

        if not self.migrations_dir.exists():
            return {}

        for migration_file in self.migrations_dir.glob("*.py"):
            try:
                version = migration_file.name.split("_")[0]
                if version not in version_map:
                    version_map[version] = []
                version_map[version].append(migration_file)
            except IndexError:
                # Ignore malformed filenames
                continue

        # Filter to only duplicates
        duplicates = {v: files for v, files in version_map.items() if len(files) > 1}
        return duplicates

    def _check_name_conflict(self, name: str) -> list[Path]:
        """Check if migration name already exists with different version.

        Args:
            name: Migration name to check

        Returns:
            List of files with same name but different version
        """
        if not self.migrations_dir.exists():
            return []

        conflicts = []
        for migration_file in self.migrations_dir.glob(f"*_{name}.py"):
            conflicts.append(migration_file)

        return conflicts

    def _check_file_exists(self, filepath: Path) -> bool:
        """Check if a file already exists.

        Args:
            filepath: Path to check

        Returns:
            True if file exists, False otherwise
        """
        return filepath.exists()

    def _acquire_migration_lock(self) -> Any:
        """Acquire lock for migration generation.

        Returns:
            Lock file handle (must be released with _release_migration_lock)

        Raises:
            IOError: If lock cannot be acquired (another process has it)
        """
        lock_file = self.migrations_dir / ".migration_lock"
        lock_file.parent.mkdir(parents=True, exist_ok=True)
        lock_file.touch(exist_ok=True)

        lock_fd = open(lock_file)  # noqa: SIM115 - File lock requires open handle

        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return lock_fd
        except OSError as e:
            lock_fd.close()
            raise OSError(
                "Another migration generation is in progress. "
                "Wait for other process to complete or remove .migration_lock"
            ) from e

    def _release_migration_lock(self, lock_fd: Any) -> None:
        """Release migration lock.

        Args:
            lock_fd: Lock file handle from _acquire_migration_lock
        """
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
        finally:
            lock_fd.close()

    def _generate_migration_code(self, diff: SchemaDiff, version: str, name: str) -> str:
        """Generate Python migration code.

        Args:
            diff: Schema diff containing changes
            version: Version number
            name: Migration name

        Returns:
            Python code as string
        """
        class_name = self._to_class_name(name)
        timestamp = datetime.now().isoformat()

        # Generate up and down statements
        up_statements = self._generate_up_statements(diff.changes)
        down_statements = self._generate_down_statements(diff.changes)

        template = '''"""Migration: {name}

Version: {version}
Generated: {timestamp}
"""

from confiture.models.migration import Migration


class {class_name}(Migration):
    """Migration: {name}."""

    version = "{version}"
    name = "{name}"

    def up(self) -> None:
        """Apply migration."""
{up_statements}

    def down(self) -> None:
        """Rollback migration."""
{down_statements}
'''

        return template.format(
            name=name,
            version=version,
            class_name=class_name,
            up_statements=up_statements,
            down_statements=down_statements,
            timestamp=timestamp,
        )

    def _to_class_name(self, snake_case: str) -> str:
        """Convert snake_case to PascalCase.

        Args:
            snake_case: String in snake_case format

        Returns:
            String in PascalCase format

        Example:
            >>> gen._to_class_name("add_users_table")
            'AddUsersTable'
        """
        words = snake_case.split("_")
        return "".join(word.capitalize() for word in words)

    def _generate_up_statements(self, changes: list[SchemaChange]) -> str:
        """Generate SQL statements for up migration.

        Args:
            changes: List of schema changes

        Returns:
            Python code with execute() calls
        """
        statements = []

        for change in changes:
            sql = self._change_to_up_sql(change)
            if sql:
                statements.append(f'        self.execute("{sql}")')

        return "\n".join(statements) if statements else "        pass  # No operations"

    def _generate_down_statements(self, changes: list[SchemaChange]) -> str:
        """Generate SQL statements for down migration.

        Args:
            changes: List of schema changes

        Returns:
            Python code with execute() calls
        """
        statements = []

        # Process changes in reverse order for rollback
        for change in reversed(changes):
            sql = self._change_to_down_sql(change)
            if sql:
                statements.append(f'        self.execute("{sql}")')

        return "\n".join(statements) if statements else "        pass  # No operations"

    # Change types delegated to DifferSQLGenerator (destructive ops emit warning comments)
    _DELEGATED_UP_TYPES = frozenset(
        {
            "ADD_INDEX",
            "DROP_INDEX",
            "ADD_FOREIGN_KEY",
            "DROP_FOREIGN_KEY",
            "ADD_CHECK_CONSTRAINT",
            "DROP_CHECK_CONSTRAINT",
            "ADD_UNIQUE_CONSTRAINT",
            "DROP_UNIQUE_CONSTRAINT",
            "ADD_ENUM_TYPE",
            "DROP_ENUM_TYPE",
            "CHANGE_ENUM_VALUES",
            "ADD_SEQUENCE",
            "DROP_SEQUENCE",
        }
    )

    def _change_to_up_sql(self, change: SchemaChange) -> str | None:
        """Convert schema change to SQL for up migration.

        Args:
            change: Schema change

        Returns:
            SQL string or None if not applicable
        """
        if change.type == "ADD_TABLE":
            # Full schema info not available; user must write this migration manually
            raise NotImplementedError(
                f"Cannot auto-generate migration for ADD_TABLE on {change.table}. "
                "Write the migration manually or use --generator."
            )

        elif change.type == "DROP_TABLE":
            return f"DROP TABLE {change.table}"

        elif change.type == "RENAME_TABLE":
            return f"ALTER TABLE {change.old_value} RENAME TO {change.new_value}"

        elif change.type == "ADD_COLUMN":
            col_def = change.new_value if change.new_value else "TEXT"
            return f"ALTER TABLE {change.table} ADD COLUMN {change.column} {col_def}"

        elif change.type == "DROP_COLUMN":
            return f"ALTER TABLE {change.table} DROP COLUMN {change.column}"

        elif change.type == "RENAME_COLUMN":
            return (
                f"ALTER TABLE {change.table} RENAME COLUMN {change.old_value} TO {change.new_value}"
            )

        elif change.type == "CHANGE_COLUMN_TYPE":
            return (
                f"ALTER TABLE {change.table} ALTER COLUMN {change.column} TYPE {change.new_value}"
            )

        elif change.type == "CHANGE_COLUMN_NULLABLE":
            if change.new_value == "false":
                return f"ALTER TABLE {change.table} ALTER COLUMN {change.column} SET NOT NULL"
            else:
                return f"ALTER TABLE {change.table} ALTER COLUMN {change.column} DROP NOT NULL"

        elif change.type == "CHANGE_COLUMN_DEFAULT":
            if change.new_value:
                return f"ALTER TABLE {change.table} ALTER COLUMN {change.column} SET DEFAULT {change.new_value}"
            else:
                return f"ALTER TABLE {change.table} ALTER COLUMN {change.column} DROP DEFAULT"

        elif change.type in self._DELEGATED_UP_TYPES:
            try:
                return self._sql_gen.generate_up(change).rstrip("\n")
            except UnsafeOperationError as exc:
                return f"-- WARNING: {exc}"

        return None

    def run_external_generator(
        self,
        *,
        generator_config: Any,
        from_path: Path,
        to_path: Path,
        migration_name: str,
        dry_run: bool = False,
    ) -> tuple[str, Path]:
        """Run an external generator command and return (resolved_command, output_path).

        On dry_run=True: resolves the command and target filename but does NOT
        execute the subprocess or write any file.

        Args:
            generator_config: MigrationGeneratorConfig with command template
            from_path: Path to the old schema file
            to_path: Path to the new schema file
            migration_name: Name for the migration (snake_case)
            dry_run: If True, skip execution and return resolved paths only

        Returns:
            Tuple of (resolved_command, target_up_sql_path)

        Raises:
            FileNotFoundError: If from_path or to_path does not exist
            ExternalGeneratorError: If subprocess exits with non-zero code or writes empty file
        """
        version = self._get_next_version()
        output_path = self.migrations_dir / f"{version}_{migration_name}.up.sql"

        resolved = generator_config.command.format_map(
            {
                "from": shlex.quote(str(from_path.resolve())),
                "to": shlex.quote(str(to_path.resolve())),
                "output": shlex.quote(str(output_path.resolve())),
            }
        )

        if dry_run:
            return (resolved, output_path)

        if not from_path.exists():
            raise FileNotFoundError(f"from_path does not exist: {from_path}")
        if not to_path.exists():
            raise FileNotFoundError(f"to_path does not exist: {to_path}")

        result = subprocess.run(
            resolved,
            shell=True,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise ExternalGeneratorError(
                f"Generator exited with code {result.returncode}.\nstderr: {result.stderr}",
                returncode=result.returncode,
                stderr=result.stderr,
                resolution_hint="Check the generator command configuration and ensure the external tool is installed and accessible",
            )

        sql = output_path.read_text()
        if not sql.strip():
            raise ExternalGeneratorError(
                "Generator wrote an empty SQL file; aborting to avoid a silent no-op migration.",
                returncode=0,
                stderr="",
                resolution_hint="Ensure the generator command writes valid SQL to the output file path",
            )
        sql = _strip_transaction_wrappers(sql)
        output_path.write_text(sql)

        down_path = output_path.parent / output_path.name.replace(".up.sql", ".down.sql")
        if not down_path.exists():
            down_path.write_text(
                "-- WARNING: Rollback SQL not generated. Edit this file before deploying.\n"
                "-- If no rollback is needed, replace this with a comment explaining why.\n"
            )

        return (resolved, output_path)

    def _change_to_down_sql(self, change: SchemaChange) -> str | None:
        """Convert schema change to SQL for down migration (reverse).

        Args:
            change: Schema change

        Returns:
            SQL string or None if not applicable
        """
        if change.type == "ADD_TABLE":
            return f"DROP TABLE {change.table}"

        elif change.type == "DROP_TABLE":
            return f"# WARNING: Cannot auto-generate down migration for DROP_TABLE {change.table}"

        elif change.type == "RENAME_TABLE":
            return f"ALTER TABLE {change.new_value} RENAME TO {change.old_value}"

        elif change.type == "ADD_COLUMN":
            return f"ALTER TABLE {change.table} DROP COLUMN {change.column}"

        elif change.type == "DROP_COLUMN":
            return f"# WARNING: Cannot auto-generate down migration for DROP_COLUMN {change.table}.{change.column}"

        elif change.type == "RENAME_COLUMN":
            return (
                f"ALTER TABLE {change.table} RENAME COLUMN {change.new_value} TO {change.old_value}"
            )

        elif change.type == "CHANGE_COLUMN_TYPE":
            return (
                f"ALTER TABLE {change.table} ALTER COLUMN {change.column} TYPE {change.old_value}"
            )

        elif change.type == "CHANGE_COLUMN_NULLABLE":
            if change.old_value == "false":
                return f"ALTER TABLE {change.table} ALTER COLUMN {change.column} SET NOT NULL"
            else:
                return f"ALTER TABLE {change.table} ALTER COLUMN {change.column} DROP NOT NULL"

        elif change.type == "CHANGE_COLUMN_DEFAULT":
            if change.old_value:
                return f"ALTER TABLE {change.table} ALTER COLUMN {change.column} SET DEFAULT {change.old_value}"
            else:
                return f"ALTER TABLE {change.table} ALTER COLUMN {change.column} DROP DEFAULT"

        elif change.type in self._DELEGATED_UP_TYPES:
            sql = self._sql_gen.generate_down(change).rstrip("\n")
            return sql if sql else None

        return None


# Backward-compatible alias — logic lives in confiture.core.sql_utils
def _strip_transaction_wrappers(sql: str) -> str:
    result = strip_transaction_wrappers(sql)
    assert isinstance(result, str)
    return result
