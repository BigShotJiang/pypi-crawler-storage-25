"""Shared dataclass types for tonal_py.

Mirrors the TypeScript interfaces in @tonaljs/* packages. Frozen dataclasses
match the JS pattern of plain objects that get reused via caching.

This module grows phase-by-phase as new packages are ported.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal, TypeAlias

# JS interval/note direction. 1 = ascending, -1 = descending. None when not
# applicable (pitches and notes don't have direction).
Direction: TypeAlias = Literal[1, -1]

# Coordinate tuples on the circle of fifths.
# - PitchClass: just [fifths]
# - Note:       [fifths, octaves]
# - Interval:   [fifths, octaves, direction]
PitchClassCoordinates: TypeAlias = tuple[int]
NoteCoordinates: TypeAlias = tuple[int, int]
IntervalCoordinates: TypeAlias = tuple[int, int, Direction]
PitchCoordinates: TypeAlias = (
    PitchClassCoordinates | NoteCoordinates | IntervalCoordinates
)


@dataclass(frozen=True, slots=True)
class Pitch:
    """Foundation pitch object.

    Fields mirror @tonaljs/pitch's Pitch interface:
    - step: 0 = C, 1 = D, ... 6 = B
    - alt: alterations. -2 = bb, -1 = b, 0 = natural, 1 = #, 2 = ##, ...
    - oct: octave (None when this is a pitch class)
    - dir: direction for intervals (None for notes/pitch classes)
    """

    step: int
    alt: int
    oct: int | None = None
    dir: Direction | None = None


@dataclass(frozen=True, slots=True)
class Note:
    """Parsed note. Mirrors @tonaljs/pitch-note's Note interface.

    For the empty/invalid sentinel use NO_NOTE. Numeric fields that JS marks
    NaN (step/alt/chroma/height) are typed `float` so we can store math.nan;
    in valid Notes they hold integer values.
    """

    empty: bool
    name: str
    letter: str
    acc: str
    pc: str
    step: float
    alt: float
    chroma: float
    height: float
    coord: tuple[int, ...]
    oct: int | None
    midi: int | None
    freq: float | None


NO_NOTE: Note = Note(
    empty=True,
    name="",
    letter="",
    acc="",
    pc="",
    step=math.nan,
    alt=math.nan,
    chroma=math.nan,
    height=math.nan,
    coord=(),
    oct=None,
    midi=None,
    freq=None,
)


@dataclass(frozen=True, slots=True)
class Interval:
    """Parsed interval. Mirrors @tonaljs/pitch-interval's Interval interface.

    Use NO_INTERVAL for invalid input. Numeric fields use `float` for
    NaN-sentinel parity with JS; in valid Intervals they hold integers.
    """

    empty: bool
    name: str
    num: float
    q: str
    type: str
    step: float
    alt: float
    dir: float  # JS uses NaN sentinel; for valid intervals 1 or -1
    simple: float
    semitones: float
    chroma: float
    coord: tuple[int, ...]
    oct: float


NO_INTERVAL: Interval = Interval(
    empty=True,
    name="",
    num=math.nan,
    q="",
    type="",
    step=math.nan,
    alt=math.nan,
    dir=math.nan,
    simple=math.nan,
    semitones=math.nan,
    chroma=math.nan,
    coord=(),
    oct=math.nan,
)


@dataclass(frozen=True, slots=True)
class Pcset:
    """Pitch class set. Mirrors @tonaljs/pcset's Pcset interface."""

    empty: bool
    name: str
    set_num: int
    chroma: str
    normalized: str
    intervals: tuple[str, ...]


EMPTY_PCSET: Pcset = Pcset(
    empty=True,
    name="",
    set_num=0,
    chroma="000000000000",
    normalized="000000000000",
    intervals=(),
)


@dataclass(frozen=True, slots=True)
class ChordType:
    """Chord type. Pcset fields + quality + aliases."""

    empty: bool
    name: str
    set_num: int
    chroma: str
    normalized: str
    intervals: tuple[str, ...]
    quality: str  # "Major" | "Minor" | "Augmented" | "Diminished" | "Unknown"
    aliases: tuple[str, ...]


NO_CHORD_TYPE: ChordType = ChordType(
    empty=True,
    name="",
    set_num=0,
    chroma="000000000000",
    normalized="000000000000",
    intervals=(),
    quality="Unknown",
    aliases=(),
)


@dataclass(frozen=True, slots=True)
class ScaleType:
    """Scale type. Pcset fields + aliases."""

    empty: bool
    name: str
    set_num: int
    chroma: str
    normalized: str
    intervals: tuple[str, ...]
    aliases: tuple[str, ...]


NO_SCALE_TYPE: ScaleType = ScaleType(
    empty=True,
    name="",
    set_num=0,
    chroma="000000000000",
    normalized="000000000000",
    intervals=(),
    aliases=(),
)


@dataclass(frozen=True, slots=True)
class RomanNumeral:
    """Parsed roman numeral. Mirrors @tonaljs/roman-numeral."""

    empty: bool
    name: str
    roman: str
    interval: str
    acc: str
    chord_type: str
    alt: float
    step: float
    major: bool
    oct: float
    dir: float


NO_ROMAN_NUMERAL: RomanNumeral = RomanNumeral(
    empty=True,
    name="",
    roman="",
    interval="",
    acc="",
    chord_type="",
    alt=math.nan,
    step=math.nan,
    major=False,
    oct=math.nan,
    dir=math.nan,
)


@dataclass(frozen=True, slots=True)
class Mode:
    """Mode definition. Pcset fields + mode-specific metadata.

    Note: chroma is NOT zero-padded in JS — `Number(setNum).toString(2)`. All
    7 actual modes produce 12-char strings naturally (set_num >= 2741), so
    in practice chroma is always 12 chars wide.
    """

    empty: bool
    name: str
    set_num: int
    chroma: str
    normalized: str
    intervals: tuple[str, ...]
    mode_num: float
    alt: float
    triad: str
    seventh: str
    aliases: tuple[str, ...]


NO_MODE: Mode = Mode(
    empty=True,
    name="",
    set_num=0,
    chroma="000000000000",
    normalized="000000000000",
    intervals=(),
    mode_num=math.nan,
    alt=0,
    triad="",
    seventh="",
    aliases=(),
)


@dataclass(frozen=True, slots=True)
class Chord:
    """Chord. ChordType fields + tonic/root/bass placement and computed notes."""

    empty: bool
    name: str
    set_num: float  # NaN when empty (matches JS NoChord)
    chroma: str
    normalized: str
    intervals: tuple[str, ...]
    quality: str
    aliases: tuple[str, ...]
    symbol: str
    root: str
    bass: str
    root_degree: float  # NaN when no root, else int 1..N
    type: str
    tonic: str | None  # None when empty (JS uses null)
    notes: tuple[str, ...]


NO_CHORD: Chord = Chord(
    empty=True,
    name="",
    set_num=math.nan,
    chroma="",
    normalized="",
    intervals=(),
    quality="Unknown",
    aliases=(),
    symbol="",
    root="",
    bass="",
    root_degree=0,  # JS uses 0 here, not NaN
    type="",
    tonic=None,
    notes=(),
)


@dataclass(frozen=True, slots=True)
class Scale:
    """Scale. ScaleType fields + tonic/type/notes."""

    empty: bool
    name: str
    set_num: float  # NaN when empty
    chroma: str
    normalized: str
    intervals: tuple[str, ...]
    aliases: tuple[str, ...]
    type: str
    tonic: str | None
    notes: tuple[str, ...]


NO_SCALE: Scale = Scale(
    empty=True,
    name="",
    set_num=math.nan,
    chroma="",
    normalized="",
    intervals=(),
    aliases=(),
    type="",
    tonic=None,
    notes=(),
)


@dataclass(frozen=True, slots=True)
class KeyScale:
    """Sub-scale of a key (used for natural/harmonic/melodic in MinorKey, and
    flat-embedded in MajorKey). Mirrors JS KeyScale interface.
    """

    tonic: str
    grades: tuple[str, ...]
    intervals: tuple[str, ...]
    scale: tuple[str, ...]
    triads: tuple[str, ...]
    chords: tuple[str, ...]
    chords_harmonic_function: tuple[str, ...]
    chord_scales: tuple[str, ...]
    secondary_dominants: tuple[str, ...]
    secondary_dominant_supertonics: tuple[str, ...]
    substitute_dominants: tuple[str, ...]
    substitute_dominant_supertonics: tuple[str, ...]
    # Deprecated aliases kept for parity
    secondary_dominants_minor_relative: tuple[str, ...]
    substitute_dominants_minor_relative: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class MajorKey:
    """Major key. Inlines KeyScale fields + key-level metadata."""

    type: str  # "major"
    tonic: str
    alteration: int
    key_signature: str
    minor_relative: str
    grades: tuple[str, ...]
    intervals: tuple[str, ...]
    scale: tuple[str, ...]
    triads: tuple[str, ...]
    chords: tuple[str, ...]
    chords_harmonic_function: tuple[str, ...]
    chord_scales: tuple[str, ...]
    secondary_dominants: tuple[str, ...]
    secondary_dominant_supertonics: tuple[str, ...]
    substitute_dominants: tuple[str, ...]
    substitute_dominant_supertonics: tuple[str, ...]
    secondary_dominants_minor_relative: tuple[str, ...]
    substitute_dominants_minor_relative: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class MinorKey:
    """Minor key. Three nested KeyScales for natural/harmonic/melodic."""

    type: str  # "minor"
    tonic: str
    alteration: int
    key_signature: str
    relative_major: str
    natural: KeyScale
    harmonic: KeyScale
    melodic: KeyScale


@dataclass(frozen=True, slots=True)
class KeyChord:
    """A chord in a key with its harmonic role(s)."""

    name: str
    roles: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class TimeSignature:
    """Parsed time signature. Mirrors @tonaljs/time-signature."""

    empty: bool
    name: str
    upper: int | tuple[int, ...] | None
    lower: int | None
    type: str | None  # "simple" | "compound" | "irregular" | "irrational"
    additive: tuple[int, ...]


NO_TIME_SIGNATURE: TimeSignature = TimeSignature(
    empty=True,
    name="",
    upper=None,
    lower=None,
    type=None,
    additive=(),
)


@dataclass(frozen=True, slots=True)
class DurationValue:
    """Note duration (e.g. quarter, eighth, dotted half)."""

    empty: bool
    name: str
    value: float
    fraction: tuple[int, int]
    shorthand: str
    dots: str
    names: tuple[str, ...]


NO_DURATION: DurationValue = DurationValue(
    empty=True,
    name="",
    value=0,
    fraction=(0, 0),
    shorthand="",
    dots="",
    names=(),
)


# Suppress unused-import lint
_ = field
