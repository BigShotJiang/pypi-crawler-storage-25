"""tonal_py — Python port of the tonal npm music theory library v6.4.3.

Public namespaces mirror the JS package's PascalCase exports
(`tonal/dist/index.d.ts`). Use:

    from tonal_py import Note, Chord, Scale, Key, Voicing
    Note.midi("C4")             # 60
    Chord.get("Cmaj7").notes    # ('C', 'E', 'G', 'B')
    Scale.get("C major").notes  # ('C', 'D', 'E', 'F', 'G', 'A', 'B')

Function names are snake_case (Python convention) — JS docs use camelCase,
so `Note.fromMidi` becomes `Note.from_midi`. See CLAUDE.md.
"""

from __future__ import annotations

from . import abc_notation as AbcNotation
from . import array as Array
from . import chord as Chord
from . import chord_type as ChordType
from . import collection as Collection
from . import core as Core
from . import duration_value as DurationValue
from . import interval as Interval
from . import key as Key
from . import midi as Midi
from . import mode as Mode
from . import note as Note
from . import pcset as Pcset
from . import progression as Progression
from . import range as Range
from . import rhythm_pattern as RhythmPattern
from . import roman_numeral as RomanNumeral
from . import scale as Scale
from . import scale_type as ScaleType
from . import time_signature as TimeSignature
from . import voice_leading as VoiceLeading
from . import voicing as Voicing
from . import voicing_dictionary as VoicingDictionary

# Re-export shared dataclass types only (no functions — function names
# would collide with module names like `note`, `chord`, `interval`,
# `transpose`). For the JS-style top-level helpers, use the Core namespace
# explicitly: `from tonal_py.core import note, transpose, ...`.
from ._types import (  # noqa: F401
    EMPTY_PCSET,
    NO_CHORD,
    NO_CHORD_TYPE,
    NO_INTERVAL,
    NO_MODE,
    NO_NOTE,
    NO_ROMAN_NUMERAL,
    NO_SCALE,
    NO_SCALE_TYPE,
    NO_TIME_SIGNATURE,
    Direction,
    KeyChord,
    KeyScale,
    MajorKey,
    MinorKey,
    Pitch,
    PitchCoordinates,
)

# Deprecated aliases for the top-level `tonal` package's legacy exports.
Tonal = Core
PcSet = Pcset
ChordDictionary = ChordType
ScaleDictionary = ScaleType

__all__ = [
    # Namespaces (PascalCase, matching JS)
    "AbcNotation",
    "Array",
    "Chord",
    "ChordType",
    "Collection",
    "Core",
    "DurationValue",
    "Interval",
    "Key",
    "Midi",
    "Mode",
    "Note",
    "Pcset",
    "Progression",
    "Range",
    "RhythmPattern",
    "RomanNumeral",
    "Scale",
    "ScaleType",
    "TimeSignature",
    "VoiceLeading",
    "Voicing",
    "VoicingDictionary",
    # Deprecated aliases
    "ChordDictionary",
    "PcSet",
    "ScaleDictionary",
    "Tonal",
]
