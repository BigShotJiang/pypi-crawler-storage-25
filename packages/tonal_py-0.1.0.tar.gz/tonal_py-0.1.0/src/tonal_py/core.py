"""Foundation re-exports + small utility helpers.

The `Core` namespace re-exports the lowest-level building blocks: pitch
arithmetic, the note and interval parsers, and the transposition/distance
functions. Most users won't touch `Core` directly — the high-level
namespaces (`Note`, `Interval`, `Chord`, ...) wrap these.

Two convenience helpers live here:

- [`fill_str`][tonal_py.core.fill_str] — repeat a string `abs(n)` times.
- [`deprecate`][tonal_py.core.deprecate] — wrap a function so calls emit
  a `DeprecationWarning`.

Example:
    >>> from tonal_py.core import note, transpose, distance
    >>> note("C4").midi
    60
    >>> transpose("C4", "M3")
    'E4'
    >>> distance("C4", "G4")
    '5P'

Source parity: `@tonaljs/core`
"""

from __future__ import annotations

import warnings
from collections.abc import Callable
from typing import Any, TypeVar

# Re-exports from _pitch
from ._pitch import (  # noqa: F401
    chroma,
    coordinates,
    height,
    is_named_pitch,
    is_pitch,
    midi,
    pitch,
)

# Re-exports from _pitch_distance
from ._pitch_distance import (  # noqa: F401
    distance,
    tonic_intervals_transposer,
    transpose,
)

# Re-exports from _pitch_interval
from ._pitch_interval import (  # noqa: F401
    coord_to_interval,
    interval,
    tokenize_interval,
)

# Re-exports from _pitch_note
from ._pitch_note import (  # noqa: F401
    acc_to_alt,
    alt_to_acc,
    coord_to_note,
    note,
    step_to_letter,
    tokenize_note,
)

# Re-export shared types
from ._types import (  # noqa: F401
    NO_INTERVAL,
    NO_NOTE,
    Direction,
    Interval,
    IntervalCoordinates,
    Note,
    NoteCoordinates,
    Pitch,
    PitchClassCoordinates,
    PitchCoordinates,
)


def fill_str(s: str, n: int) -> str:
    """Repeat string `s` `abs(n)` times.

    Args:
        s: String to repeat.
        n: Repeat count (sign ignored).

    Returns:
        `s * abs(n)`.

    Example:
        >>> from tonal_py.core import fill_str
        >>> fill_str("a", 3)
        'aaa'
        >>> fill_str("ab", 2)
        'abab'
        >>> fill_str("a", -3)        # sign ignored
        'aaa'
    """
    return s * abs(n)


F = TypeVar("F", bound=Callable[..., Any])


def deprecate(original: str, alternative: str, fn: F) -> F:
    """Wrap `fn` so calls emit a `DeprecationWarning`.

    Args:
        original: The deprecated name (used in the warning message).
        alternative: The recommended replacement name.
        fn: The function to wrap.

    Returns:
        A wrapped function with the same signature.

    Example:
        >>> import warnings
        >>> from tonal_py.core import deprecate
        >>> def add(a, b): return a + b
        >>> deprecated_add = deprecate("add", "newAdd", add)
        >>> with warnings.catch_warnings(record=True) as w:
        ...     warnings.simplefilter("always")
        ...     deprecated_add(2, 3)
        ...     issubclass(w[0].category, DeprecationWarning)
        5
        True
    """
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        warnings.warn(
            f"{original} is deprecated. Use {alternative}.",
            DeprecationWarning,
            stacklevel=2,
        )
        return fn(*args, **kwargs)

    wrapper.__name__ = getattr(fn, "__name__", original)
    wrapper.__doc__ = fn.__doc__
    return wrapper  # type: ignore[return-value]


# Deprecated alias kept for parity with @tonaljs/core's `isNamed` export.
is_named = deprecate("is_named", "is_named_pitch", is_named_pitch)
