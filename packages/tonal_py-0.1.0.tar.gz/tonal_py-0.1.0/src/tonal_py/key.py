"""Musical keys with diatonic chords and harmonic analysis.

The `Key` namespace generates everything you need for harmonic analysis in
a major or minor key: the scale, the seven diatonic chords (triads and
seventh chords), their harmonic functions (T/SD/D), the chord-scale
mappings for each degree, and the secondary dominants + tritone-substitute
dominants used in jazz harmony.

Minor keys expose three variants — natural, harmonic, melodic — each
with its own diatonic chord set.

Example:
    >>> from tonal_py import Key
    >>> ck = Key.major_key("C")
    >>> ck.chords
    ('Cmaj7', 'Dm7', 'Em7', 'Fmaj7', 'G7', 'Am7', 'Bm7b5')
    >>> ck.minor_relative
    'A'
    >>> ck.alteration
    0

Source parity: `@tonaljs/key`
"""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any

from . import _pitch_note, note as _note_mod, roman_numeral
from ._types import KeyChord, KeyScale, MajorKey, MinorKey

_EMPTY: tuple[str, ...] = ()

NO_KEY_SCALE = KeyScale(
    tonic="",
    grades=_EMPTY,
    intervals=_EMPTY,
    scale=_EMPTY,
    triads=_EMPTY,
    chords=_EMPTY,
    chords_harmonic_function=_EMPTY,
    chord_scales=_EMPTY,
    secondary_dominants=_EMPTY,
    secondary_dominant_supertonics=_EMPTY,
    substitute_dominants=_EMPTY,
    substitute_dominant_supertonics=_EMPTY,
    secondary_dominants_minor_relative=_EMPTY,
    substitute_dominants_minor_relative=_EMPTY,
)

NO_MAJOR_KEY = MajorKey(
    type="major",
    tonic="",
    alteration=0,
    key_signature="",
    minor_relative="",
    grades=_EMPTY,
    intervals=_EMPTY,
    scale=_EMPTY,
    triads=_EMPTY,
    chords=_EMPTY,
    chords_harmonic_function=_EMPTY,
    chord_scales=_EMPTY,
    secondary_dominants=_EMPTY,
    secondary_dominant_supertonics=_EMPTY,
    substitute_dominants=_EMPTY,
    substitute_dominant_supertonics=_EMPTY,
    secondary_dominants_minor_relative=_EMPTY,
    substitute_dominants_minor_relative=_EMPTY,
)

NO_MINOR_KEY = MinorKey(
    type="minor",
    tonic="",
    alteration=0,
    key_signature="",
    relative_major="",
    natural=NO_KEY_SCALE,
    harmonic=NO_KEY_SCALE,
    melodic=NO_KEY_SCALE,
)


def _map_scale_to_type(scale: list[str], type_list: list[str], sep: str = "") -> tuple[str, ...]:
    return tuple(f"{scale[i]}{sep}{t}" for i, t in enumerate(type_list))


def _supertonics(dominants: list[str], target_triads: list[str]) -> tuple[str, ...]:
    """Build the supertonic chord (ii of each secondary dominant target)."""
    out = []
    for index, chord in enumerate(dominants):
        if not chord:
            out.append("")
            continue
        dom_root = chord[:-1]
        minor_root = _note_mod.transpose(dom_root, "5P")
        target = target_triads[index]
        is_minor = target.endswith("m")
        out.append(minor_root + ("m7" if is_minor else "m7b5"))
    return tuple(out)


def _key_scale(
    grades: list[str],
    triads: list[str],
    chord_types: list[str],
    harmonic_functions: list[str],
    chord_scales: list[str],
) -> Callable[[str], KeyScale]:
    """Higher-order builder. Returns fn that, given a tonic, builds the full KeyScale."""

    def build(tonic: str) -> KeyScale:
        intervals = [roman_numeral.get(gr).interval or "" for gr in grades]
        scale = [_note_mod.transpose(tonic, ivl) for ivl in intervals]
        chords_ = list(_map_scale_to_type(scale, chord_types))
        # Secondary dominants: V7 at each scale degree, only if target is in scale
        # AND chord isn't already diatonic.
        secondary_dominants = []
        for n in scale:
            v_target = _note_mod.transpose(n, "5P")
            if v_target in scale and (v_target + "7") not in chords_:
                secondary_dominants.append(v_target + "7")
            else:
                secondary_dominants.append("")
        secondary_dominant_supertonics = _supertonics(secondary_dominants, triads)
        # Substitute dominants: tritone substitution of each secondary dominant.
        substitute_dominants = []
        for chord in secondary_dominants:
            if not chord:
                substitute_dominants.append("")
                continue
            dom_root = chord[:-1]
            sub_root = _note_mod.transpose(dom_root, "5d")
            substitute_dominants.append(sub_root + "7")
        substitute_dominant_supertonics = _supertonics(substitute_dominants, triads)
        return KeyScale(
            tonic=tonic,
            grades=tuple(grades),
            intervals=tuple(intervals),
            scale=tuple(scale),
            triads=_map_scale_to_type(scale, triads),
            chords=tuple(chords_),
            chords_harmonic_function=tuple(harmonic_functions),
            chord_scales=_map_scale_to_type(scale, chord_scales, " "),
            secondary_dominants=tuple(secondary_dominants),
            secondary_dominant_supertonics=secondary_dominant_supertonics,
            substitute_dominants=tuple(substitute_dominants),
            substitute_dominant_supertonics=substitute_dominant_supertonics,
            # Deprecated parity aliases
            secondary_dominants_minor_relative=secondary_dominant_supertonics,
            substitute_dominants_minor_relative=substitute_dominant_supertonics,
        )

    return build


def _dist_in_fifths(from_note: str, to_note: str) -> int:
    f = _pitch_note.note(from_note)
    t = _pitch_note.note(to_note)
    if f.empty or t.empty:
        return 0
    return int(t.coord[0]) - int(f.coord[0])


# Diatonic chord/scale templates per scale type.
_MajorScale = _key_scale(
    "I II III IV V VI VII".split(" "),
    " m m   m dim".split(" "),
    "maj7 m7 m7 maj7 7 m7 m7b5".split(" "),
    "T SD T SD D T D".split(" "),
    "major,dorian,phrygian,lydian,mixolydian,minor,locrian".split(","),
)

_NaturalScale = _key_scale(
    "I II bIII IV V bVI bVII".split(" "),
    "m dim  m m  ".split(" "),
    "m7 m7b5 maj7 m7 m7 maj7 7".split(" "),
    "T SD T SD D SD SD".split(" "),
    "minor,locrian,major,dorian,phrygian,lydian,mixolydian".split(","),
)

_HarmonicScale = _key_scale(
    "I II bIII IV V bVI VII".split(" "),
    "m dim aug m   dim".split(" "),
    "mMaj7 m7b5 +maj7 m7 7 maj7 o7".split(" "),
    "T SD T SD D SD D".split(" "),
    "harmonic minor,locrian 6,major augmented,lydian diminished,phrygian dominant,lydian #9,ultralocrian".split(","),
)

_MelodicScale = _key_scale(
    "I II bIII IV V VI VII".split(" "),
    "m m aug   dim dim".split(" "),
    "m6 m7 +maj7 7 7 m7b5 m7b5".split(" "),
    "T SD T SD D  ".split(" "),
    "melodic minor,dorian b2,lydian augmented,lydian dominant,mixolydian b6,locrian #2,altered".split(","),
)


def major_key(tonic: str) -> MajorKey:
    """Build a `MajorKey` for the given tonic.

    The returned object has everything for harmonic analysis: the scale
    notes, the 7 diatonic 7th chords, their harmonic functions, secondary
    dominants, substitute dominants, and chord-scale mappings.

    Args:
        tonic: The tonic note (e.g. `"C"`, `"Bb"`, `"F#"`).

    Returns:
        A `MajorKey` dataclass. Returns `NO_MAJOR_KEY` if the tonic is
        invalid.

    Example:
        >>> from tonal_py import Key
        >>> ck = Key.major_key("C")
        >>> ck.chords
        ('Cmaj7', 'Dm7', 'Em7', 'Fmaj7', 'G7', 'Am7', 'Bm7b5')
        >>> ck.chords_harmonic_function
        ('T', 'SD', 'T', 'SD', 'D', 'T', 'D')
        >>> ck.minor_relative
        'A'
        >>> ck.alteration
        0
        >>> Key.major_key("D").key_signature
        '##'
    """
    pc = _pitch_note.note(tonic).pc
    if not pc:
        return NO_MAJOR_KEY
    ks = _MajorScale(pc)
    alteration = _dist_in_fifths("C", pc)
    return MajorKey(
        type="major",
        tonic=ks.tonic,
        alteration=alteration,
        key_signature=_pitch_note.alt_to_acc(alteration),
        minor_relative=_note_mod.transpose(pc, "-3m"),
        grades=ks.grades,
        intervals=ks.intervals,
        scale=ks.scale,
        triads=ks.triads,
        chords=ks.chords,
        chords_harmonic_function=ks.chords_harmonic_function,
        chord_scales=ks.chord_scales,
        secondary_dominants=ks.secondary_dominants,
        secondary_dominant_supertonics=ks.secondary_dominant_supertonics,
        substitute_dominants=ks.substitute_dominants,
        substitute_dominant_supertonics=ks.substitute_dominant_supertonics,
        secondary_dominants_minor_relative=ks.secondary_dominants_minor_relative,
        substitute_dominants_minor_relative=ks.substitute_dominants_minor_relative,
    )


def minor_key(tonic: str) -> MinorKey:
    """Build a `MinorKey` with natural, harmonic, and melodic sub-scales.

    Each sub-scale (`.natural`, `.harmonic`, `.melodic`) is a `KeyScale`
    with its own diatonic chords and harmonic functions.

    Args:
        tonic: The tonic note.

    Returns:
        A `MinorKey` dataclass. Returns `NO_MINOR_KEY` if invalid.

    Example:
        >>> from tonal_py import Key
        >>> ak = Key.minor_key("A")
        >>> ak.relative_major
        'C'
        >>> ak.alteration
        0
        >>> ak.natural.chords
        ('Am7', 'Bm7b5', 'Cmaj7', 'Dm7', 'Em7', 'Fmaj7', 'G7')
    """
    pc = _pitch_note.note(tonic).pc
    if not pc:
        return NO_MINOR_KEY
    alteration = _dist_in_fifths("C", pc) - 3
    return MinorKey(
        type="minor",
        tonic=pc,
        alteration=alteration,
        key_signature=_pitch_note.alt_to_acc(alteration),
        relative_major=_note_mod.transpose(pc, "3m"),
        natural=_NaturalScale(pc),
        harmonic=_HarmonicScale(pc),
        melodic=_MelodicScale(pc),
    )


def _key_chords_of(key: KeyScale, chords_out: list[dict]) -> None:
    """Internal builder: appends KeyChord-like dicts to `chords_out` with
    deduplication by chord name and accumulation of role tags."""

    def update_chord(name: str, new_role: str) -> None:
        if not name:
            return
        existing = next((c for c in chords_out if c["name"] == name), None)
        if existing is None:
            existing = {"name": name, "roles": []}
            chords_out.append(existing)
        if new_role and new_role not in existing["roles"]:
            existing["roles"].append(new_role)

    for chord_name, role in zip(key.chords, key.chords_harmonic_function):
        update_chord(chord_name, role)
    for index, chord_name in enumerate(key.secondary_dominants):
        update_chord(chord_name, f"V/{key.grades[index]}")
    for index, chord_name in enumerate(key.secondary_dominant_supertonics):
        update_chord(chord_name, f"ii/{key.grades[index]}")
    for index, chord_name in enumerate(key.substitute_dominants):
        update_chord(chord_name, f"subV/{key.grades[index]}")
    for index, chord_name in enumerate(key.substitute_dominant_supertonics):
        update_chord(chord_name, f"subii/{key.grades[index]}")


def major_key_chords(tonic: str) -> list[KeyChord]:
    """Get all chords in a major key with their harmonic role tags.

    Each chord may have multiple roles (e.g. a chord that's both a
    diatonic V and a secondary dominant for another key center).

    Args:
        tonic: The tonic note.

    Returns:
        List of `KeyChord` objects, each with `.name` and `.roles`.

    Example:
        >>> from tonal_py import Key
        >>> chords = Key.major_key_chords("C")
        >>> # First chord is the tonic
        >>> chords[0].name
        'Cmaj7'
        >>> 'T' in chords[0].roles    # tonic function
        True
    """
    key = major_key(tonic)
    chords_dict: list[dict] = []
    # major_key inlines KeyScale fields, so we wrap it as a KeyScale-shaped object.
    key_scale = KeyScale(
        tonic=key.tonic,
        grades=key.grades,
        intervals=key.intervals,
        scale=key.scale,
        triads=key.triads,
        chords=key.chords,
        chords_harmonic_function=key.chords_harmonic_function,
        chord_scales=key.chord_scales,
        secondary_dominants=key.secondary_dominants,
        secondary_dominant_supertonics=key.secondary_dominant_supertonics,
        substitute_dominants=key.substitute_dominants,
        substitute_dominant_supertonics=key.substitute_dominant_supertonics,
        secondary_dominants_minor_relative=key.secondary_dominants_minor_relative,
        substitute_dominants_minor_relative=key.substitute_dominants_minor_relative,
    )
    _key_chords_of(key_scale, chords_dict)
    return [KeyChord(name=c["name"], roles=tuple(c["roles"])) for c in chords_dict]


def minor_key_chords(tonic: str) -> list[KeyChord]:
    """Get all chords in a minor key (combining natural/harmonic/melodic).

    Args:
        tonic: The tonic note.

    Returns:
        List of `KeyChord` objects with their harmonic roles. Larger
        than the major-key list because each minor sub-scale contributes
        chords.

    Example:
        >>> from tonal_py import Key
        >>> chords = Key.minor_key_chords("A")
        >>> # Has at least the 7 natural diatonic chords
        >>> len(chords) >= 7
        True
    """
    key = minor_key(tonic)
    chords_dict: list[dict] = []
    _key_chords_of(key.natural, chords_dict)
    _key_chords_of(key.harmonic, chords_dict)
    _key_chords_of(key.melodic, chords_dict)
    return [KeyChord(name=c["name"], roles=tuple(c["roles"])) for c in chords_dict]


_SIG_REGEX = re.compile(r"^b+|#+$")


def major_tonic_from_key_signature(sig: Any) -> str | None:
    """Convert a key signature to its major-key tonic.

    The signature may be either a string (`"###"` for 3 sharps, `"bb"` for
    2 flats) or an integer (number of fifths from C; positive = sharps,
    negative = flats).

    Args:
        sig: Either a sharps/flats string or an integer fifth count.

    Returns:
        The tonic note name, or `None` for invalid input.

    Example:
        >>> from tonal_py import Key
        >>> Key.major_tonic_from_key_signature("###")
        'A'
        >>> Key.major_tonic_from_key_signature("bb")
        'Bb'
        >>> Key.major_tonic_from_key_signature(2)     # 2 fifths up from C
        'D'
        >>> Key.major_tonic_from_key_signature("garbage") is None
        True
    """
    if isinstance(sig, bool):
        return None
    if isinstance(sig, int):
        return _note_mod.transpose_fifths("C", sig)
    if isinstance(sig, str) and _SIG_REGEX.match(sig):
        return _note_mod.transpose_fifths("C", _pitch_note.acc_to_alt(sig))
    return None
