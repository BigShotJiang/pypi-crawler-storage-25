"""The scale type dictionary — 92 scale definitions.

The `ScaleType` namespace exposes an in-memory dictionary of 92 scale
types, each indexed by name, aliases, set number, and chroma. Includes
the seven diatonic modes, jazz scales (melodic minor, harmonic minor,
bebop, diminished, altered), pentatonics, hexatonics, exotic scales
(messiaen modes, ragas, hungarian, persian), and the chromatic scale.

So `ScaleType.get("major")`, `ScaleType.get("ionian")`,
`ScaleType.get(2773)`, and `ScaleType.get("101011010101")` all return
the same `ScaleType`.

Like [`ChordType`][tonal_py.chord_type], the dictionary is mutable —
[`add`][tonal_py.scale_type.add] extends it.

Example:
    >>> from tonal_py import ScaleType
    >>> len(ScaleType.all())
    92
    >>> ScaleType.get("major").chroma
    '101011010101'
    >>> ScaleType.get("aeolian").name        # alias resolves to "minor"
    'minor'

Source parity: `@tonaljs/scale-type`
"""

from __future__ import annotations

from typing import Any

from . import pcset as _pcset
from ._types import NO_SCALE_TYPE, ScaleType

# 85 scale definitions, transcribed verbatim from JS.
# Format: (intervals_string, name, *aliases) — aliases is variadic.
SCALES: list[tuple[str, str, tuple[str, ...]]] = [
    # Basic scales
    ("1P 2M 3M 5P 6M", "major pentatonic", ("pentatonic",)),
    ("1P 2M 3M 4P 5P 6M 7M", "major", ("ionian",)),
    ("1P 2M 3m 4P 5P 6m 7m", "minor", ("aeolian",)),
    # Jazz common scales
    ("1P 2M 3m 3M 5P 6M", "major blues", ()),
    ("1P 3m 4P 5d 5P 7m", "minor blues", ("blues",)),
    ("1P 2M 3m 4P 5P 6M 7M", "melodic minor", ()),
    ("1P 2M 3m 4P 5P 6m 7M", "harmonic minor", ()),
    ("1P 2M 3M 4P 5P 6M 7m 7M", "bebop", ()),
    ("1P 2M 3m 4P 5d 6m 6M 7M", "diminished", ("whole-half diminished",)),
    # Modes
    ("1P 2M 3m 4P 5P 6M 7m", "dorian", ()),
    ("1P 2M 3M 4A 5P 6M 7M", "lydian", ()),
    ("1P 2M 3M 4P 5P 6M 7m", "mixolydian", ("dominant",)),
    ("1P 2m 3m 4P 5P 6m 7m", "phrygian", ()),
    ("1P 2m 3m 4P 5d 6m 7m", "locrian", ()),
    # 5-note scales
    ("1P 3M 4P 5P 7M", "ionian pentatonic", ()),
    ("1P 3M 4P 5P 7m", "mixolydian pentatonic", ("indian",)),
    ("1P 2M 4P 5P 6M", "ritusen", ()),
    ("1P 2M 4P 5P 7m", "egyptian", ()),
    ("1P 3M 4P 5d 7m", "neapolitan major pentatonic", ()),
    ("1P 3m 4P 5P 6m", "vietnamese 1", ()),
    ("1P 2m 3m 5P 6m", "pelog", ()),
    ("1P 2m 4P 5P 6m", "kumoijoshi", ()),
    ("1P 2M 3m 5P 6m", "hirajoshi", ()),
    ("1P 2m 4P 5d 7m", "iwato", ()),
    ("1P 2m 4P 5P 7m", "in-sen", ()),
    ("1P 3M 4A 5P 7M", "lydian pentatonic", ("chinese",)),
    ("1P 3m 4P 6m 7m", "malkos raga", ()),
    ("1P 3m 4P 5d 7m", "locrian pentatonic", ("minor seven flat five pentatonic",)),
    ("1P 3m 4P 5P 7m", "minor pentatonic", ("vietnamese 2",)),
    ("1P 3m 4P 5P 6M", "minor six pentatonic", ()),
    ("1P 2M 3m 5P 6M", "flat three pentatonic", ("kumoi",)),
    ("1P 2M 3M 5P 6m", "flat six pentatonic", ()),
    ("1P 2m 3M 5P 6M", "scriabin", ()),
    ("1P 3M 5d 6m 7m", "whole tone pentatonic", ()),
    ("1P 3M 4A 5A 7M", "lydian #5p pentatonic", ()),
    ("1P 3M 4A 5P 7m", "lydian dominant pentatonic", ()),
    ("1P 3m 4P 5P 7M", "minor #7m pentatonic", ()),
    ("1P 3m 4d 5d 7m", "super locrian pentatonic", ()),
    # 6-note scales
    ("1P 2M 3m 4P 5P 7M", "minor hexatonic", ()),
    ("1P 2A 3M 5P 5A 7M", "augmented", ()),
    ("1P 2M 4P 5P 6M 7m", "piongio", ()),
    ("1P 2m 3M 4A 6M 7m", "prometheus neapolitan", ()),
    ("1P 2M 3M 4A 6M 7m", "prometheus", ()),
    ("1P 2m 3M 5d 6m 7m", "mystery #1", ()),
    ("1P 2m 3M 4P 5A 6M", "six tone symmetric", ()),
    ("1P 2M 3M 4A 5A 6A", "whole tone", ("messiaen's mode #1",)),
    ("1P 2m 4P 4A 5P 7M", "messiaen's mode #5", ()),
    # 7-note scales
    ("1P 2M 3M 4P 5d 6m 7m", "locrian major", ("arabian",)),
    ("1P 2m 3M 4A 5P 6m 7M", "double harmonic lydian", ()),
    ("1P 2m 2A 3M 4A 6m 7m", "altered", ("super locrian", "diminished whole tone", "pomeroy")),
    ("1P 2M 3m 4P 5d 6m 7m", "locrian #2", ("half-diminished", "aeolian b5")),
    ("1P 2M 3M 4P 5P 6m 7m", "mixolydian b6", ("melodic minor fifth mode", "hindu")),
    ("1P 2M 3M 4A 5P 6M 7m", "lydian dominant", ("lydian b7", "overtone")),
    ("1P 2M 3M 4A 5A 6M 7M", "lydian augmented", ()),
    ("1P 2m 3m 4P 5P 6M 7m", "dorian b2", ("phrygian #6", "melodic minor second mode")),
    ("1P 2m 3m 4d 5d 6m 7d", "ultralocrian", ("superlocrian bb7", "superlocrian diminished")),
    ("1P 2m 3m 4P 5d 6M 7m", "locrian 6", ("locrian natural 6", "locrian sharp 6")),
    ("1P 2A 3M 4P 5P 5A 7M", "augmented heptatonic", ()),
    ("1P 2M 3m 4A 5P 6M 7m", "dorian #4", ("ukrainian dorian", "romanian minor", "altered dorian")),
    ("1P 2M 3m 4A 5P 6M 7M", "lydian diminished", ()),
    ("1P 2M 3M 4A 5A 7m 7M", "leading whole tone", ()),
    ("1P 2M 3M 4A 5P 6m 7m", "lydian minor", ()),
    ("1P 2m 3M 4P 5P 6m 7m", "phrygian dominant", ("spanish", "phrygian major")),
    ("1P 2m 3m 4P 5P 6m 7M", "balinese", ()),
    ("1P 2m 3m 4P 5P 6M 7M", "neapolitan major", ()),
    ("1P 2M 3M 4P 5P 6m 7M", "harmonic major", ()),
    ("1P 2m 3M 4P 5P 6m 7M", "double harmonic major", ("gypsy",)),
    ("1P 2M 3m 4A 5P 6m 7M", "hungarian minor", ()),
    ("1P 2A 3M 4A 5P 6M 7m", "hungarian major", ()),
    ("1P 2m 3M 4P 5d 6M 7m", "oriental", ()),
    ("1P 2m 3m 3M 4A 5P 7m", "flamenco", ()),
    ("1P 2m 3m 4A 5P 6m 7M", "todi raga", ()),
    ("1P 2m 3M 4P 5d 6m 7M", "persian", ()),
    ("1P 2m 3M 5d 6m 7m 7M", "enigmatic", ()),
    ("1P 2M 3M 4P 5A 6M 7M", "major augmented", ("major #5", "ionian augmented", "ionian #5")),
    ("1P 2A 3M 4A 5P 6M 7M", "lydian #9", ()),
    # 8-note scales
    ("1P 2m 2M 4P 4A 5P 6m 7M", "messiaen's mode #4", ()),
    ("1P 2m 3M 4P 4A 5P 6m 7M", "purvi raga", ()),
    ("1P 2m 3m 3M 4P 5P 6m 7m", "spanish heptatonic", ()),
    ("1P 2M 3m 3M 4P 5P 6M 7m", "bebop minor", ()),
    ("1P 2M 3M 4P 5P 5A 6M 7M", "bebop major", ()),
    ("1P 2m 3m 4P 5d 5P 6m 7m", "bebop locrian", ()),
    ("1P 2M 3m 4P 5P 6m 7m 7M", "minor bebop", ()),
    ("1P 2M 3M 4P 5d 5P 6M 7M", "ichikosucho", ()),
    ("1P 2M 3m 4P 5P 6m 6M 7M", "minor six diminished", ()),
    ("1P 2m 3m 3M 4A 5P 6M 7m", "half-whole diminished", ("dominant diminished", "messiaen's mode #2")),
    ("1P 3m 3M 4P 5P 6M 7m 7M", "kafi raga", ()),
    ("1P 2M 3M 4P 4A 5A 6A 7M", "messiaen's mode #6", ()),
    # 9-note scales
    ("1P 2M 3m 3M 4P 5d 5P 6M 7m", "composite blues", ()),
    ("1P 2M 3m 3M 4A 5P 6m 7m 7M", "messiaen's mode #3", ()),
    # 10-note scales
    ("1P 2m 2M 3m 4P 4A 5P 6m 6M 7M", "messiaen's mode #7", ()),
    # 12-note scales
    ("1P 2m 2M 3m 3M 4P 5d 5P 6m 6M 7m 7M", "chromatic", ()),
]


# Module-level mutable state.
_DICTIONARY: list[ScaleType] = []
_INDEX: dict[Any, ScaleType] = {}


def get(type_: Any) -> ScaleType:
    """Look up a scale type by name, alias, set number, or chroma string.

    Args:
        type_: A lookup key. Name, alias, integer set number, or 12-bit
            chroma string.

    Returns:
        A `ScaleType` dataclass. Returns `NO_SCALE_TYPE` for unknown input.

    Example:
        >>> from tonal_py import ScaleType
        >>> ScaleType.get("major").intervals
        ('1P', '2M', '3M', '4P', '5P', '6M', '7M')
        >>> ScaleType.get("ionian").name        # alias resolves to "major"
        'major'
        >>> ScaleType.get("garbage").empty
        True
    """
    return _INDEX.get(type_, NO_SCALE_TYPE)


# Alias matching JS export
scale_type = get


def names() -> list[str]:
    """Return all 92 scale names in dictionary order.

    Example:
        >>> from tonal_py import ScaleType
        >>> "major" in ScaleType.names()
        True
        >>> "lydian" in ScaleType.names()
        True
    """
    return [s.name for s in _DICTIONARY]


def all() -> list[ScaleType]:  # noqa: A001
    """Return all 92 scale types as a fresh list.

    Example:
        >>> from tonal_py import ScaleType
        >>> len(ScaleType.all())
        92
    """
    return _DICTIONARY.copy()


# Deprecated alias matching JS `entries` export.
entries = all


def keys() -> list[Any]:
    return list(_INDEX.keys())


def remove_all() -> None:
    _DICTIONARY.clear()
    _INDEX.clear()


def add(intervals: list[str], name: str, aliases: tuple[str, ...] | list[str] = ()) -> ScaleType:
    """Add a scale type to the dictionary.

    Args:
        intervals: List of interval names (e.g. `["1P", "2M", "3M", "5P"]`).
        name: The full name (always required for scales).
        aliases: Optional alias names.

    Returns:
        The newly-created `ScaleType`.

    Example:
        >>> from tonal_py import ScaleType
        >>> ScaleType.add(["1P", "3M", "5P"], "test triad scale", ["tts"])
        ScaleType(empty=False, name='test triad scale', set_num=2192, ...)
        >>> ScaleType.get("tts").name
        'test triad scale'
        >>> # Cleanup
        >>> ScaleType.remove_all()
        >>> from tonal_py.scale_type import _seed
        >>> _seed()
    """
    pcset_data = _pcset.get(intervals)
    scale = ScaleType(
        empty=False,
        name=name,
        set_num=pcset_data.set_num,
        chroma=pcset_data.chroma,
        normalized=pcset_data.normalized,
        intervals=tuple(intervals),
        aliases=tuple(aliases),
    )
    _DICTIONARY.append(scale)
    _INDEX[scale.name] = scale
    _INDEX[scale.set_num] = scale
    _INDEX[scale.chroma] = scale
    for alias in scale.aliases:
        add_alias(scale, alias)
    return scale


def add_alias(scale: ScaleType, alias: str) -> None:
    _INDEX[alias] = scale


def _seed() -> None:
    """Populate the dictionary from SCALES. Called once at import time."""
    for ivls, name, aliases in SCALES:
        add(ivls.split(" "), name, aliases)


_seed()
