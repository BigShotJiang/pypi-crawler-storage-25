"""Time signature parsing.

The `TimeSignature` namespace parses time signature strings into
`TimeSignature` dataclasses with the upper number, lower number, type
classification (simple/compound/irregular/irrational), and additive
components.

Supported notation:

- **Simple**: `"4/4"`, `"3/4"`, `"2/2"` (denominators 2 or 4).
- **Compound**: `"6/8"`, `"9/8"`, `"12/8"` (denominator 8 with upper
  divisible by 3).
- **Additive**: `"3+2+3/8"` (groupings sum to upper).
- **Irregular**: any other power-of-2 denominator (e.g. `"5/16"`).
- **Irrational**: non-power-of-2 denominator (e.g. `"4/3"`).

Example:
    >>> from tonal_py import TimeSignature
    >>> ts = TimeSignature.get("4/4")
    >>> ts.upper, ts.lower, ts.type
    (4, 4, 'simple')
    >>> TimeSignature.get("3+2+3/8").additive
    (3, 2, 3)

Source parity: `@tonaljs/time-signature`

!!! note "Robust to garbage"
    Tonal.js crashes on `T.TimeSignature.get("garbage")`. Our port
    returns `NO_TIME_SIGNATURE` instead.
"""

from __future__ import annotations

import math
import re
from typing import Any

from ._cache import make_cache
from ._types import NO_TIME_SIGNATURE, TimeSignature

_NAMES: list[str] = ["4/4", "3/4", "2/4", "2/2", "12/8", "9/8", "6/8", "3/8"]


def names() -> list[str]:
    """Return common time signature names.

    Example:
        >>> from tonal_py import TimeSignature
        >>> TimeSignature.names()
        ['4/4', '3/4', '2/4', '2/2', '12/8', '9/8', '6/8', '3/8']
    """
    return _NAMES.copy()


_REGEX = re.compile(r"^(\d*\d(?:\+\d)*)\/(\d+)$")
_CACHE, clear_cache = make_cache()


def parse(literal: Any) -> tuple[Any, int]:
    """Tokenize a time signature literal into `(upper, lower)`.

    `upper` is an int when no additive (`+`); a `list` of ints when
    additive (`'3+2+3' -> [3, 2, 3]`). `lower` is always an int.

    Args:
        literal: A time signature string or a `(upper_str, lower_str)`
            tuple.

    Returns:
        `(upper, lower)`.

    Example:
        >>> from tonal_py import TimeSignature
        >>> TimeSignature.parse("4/4")
        (4, 4)
        >>> TimeSignature.parse("3+2+3/8")
        ([3, 2, 3], 8)
    """
    if isinstance(literal, str):
        m = _REGEX.match(literal)
        if not m:
            return parse(("", ""))
        return parse((m.group(1), m.group(2)))
    up, down = literal[0], literal[1]
    try:
        denominator = int(down)
    except (ValueError, TypeError):
        denominator = 0
    if isinstance(up, (int, float)) and not isinstance(up, bool):
        return (int(up), denominator)
    if not isinstance(up, str):
        return (0, denominator)
    parts = up.split("+")
    try:
        nums = [int(n) for n in parts]
    except ValueError:
        return (0, denominator)
    if len(nums) == 1:
        return (nums[0], denominator)
    return (nums, denominator)


def _is_power_of_two(x: int) -> bool:
    """True if x is a positive power of 2."""
    return x > 0 and math.log(x) / math.log(2) % 1 == 0


def _build(parsed: tuple[Any, int]) -> TimeSignature:
    up, down = parsed
    upper = sum(up) if isinstance(up, list) else up
    lower = down
    if upper == 0 or lower == 0:
        return NO_TIME_SIGNATURE
    if isinstance(up, list):
        name = "+".join(str(n) for n in up) + f"/{down}"
        additive: tuple[int, ...] = tuple(up)
    else:
        name = f"{up}/{down}"
        additive = ()
    if lower == 4 or lower == 2:
        type_ = "simple"
    elif lower == 8 and upper % 3 == 0:
        type_ = "compound"
    elif _is_power_of_two(lower):
        type_ = "irregular"
    else:
        type_ = "irrational"
    return TimeSignature(
        empty=False,
        name=name,
        type=type_,
        upper=upper,
        lower=lower,
        additive=additive,
    )


def get(literal: Any) -> TimeSignature:
    """Parse and classify a time signature.

    Args:
        literal: A time signature string (`"4/4"`, `"3+2+3/8"`).

    Returns:
        A `TimeSignature` dataclass. Returns `NO_TIME_SIGNATURE` for
        invalid input (unlike tonal.js, which crashes).

    Example:
        >>> from tonal_py import TimeSignature
        >>> ts = TimeSignature.get("6/8")
        >>> ts.type
        'compound'
        >>> ts.upper
        6
        >>> TimeSignature.get("garbage").empty
        True
    """
    key = repr(literal)
    cached = _CACHE.get(key)
    if cached is not None:
        return cached  # type: ignore[return-value]
    ts = _build(parse(literal))
    _CACHE[key] = ts
    return ts
