"""Foundation pitch arithmetic — port of @tonaljs/pitch.

This is the lowest layer: a Pitch is a (step, alt, oct?, dir?) tuple, and
this module provides the conversions to/from circle-of-fifths coordinates
plus chroma/height/midi calculations. Internal — exposed indirectly through
Note and Interval.

Source: node_modules/@tonaljs/pitch/dist/index.mjs
"""

from __future__ import annotations

from math import floor
from typing import Any

from ._types import Pitch, PitchCoordinates

# Semitone offsets for the 7 natural steps C, D, E, F, G, A, B.
SIZES: list[int] = [0, 2, 4, 5, 7, 9, 11]

# Position on the circle of fifths for each step (C=0, D=2, E=4, F=-1, ...).
FIFTHS: list[int] = [0, 2, 4, -1, 1, 3, 5]

# Octave offsets so that fifths arithmetic stays octave-consistent for each
# natural step. Computed once: floor(FIFTHS[step] * 7 / 12).
STEPS_TO_OCTS: list[int] = [floor(f * 7 / 12) for f in FIFTHS]

# Reverse lookup: which step does a given (unaltered) fifth correspond to?
FIFTHS_TO_STEPS: list[int] = [3, 0, 4, 1, 5, 2, 6]


def is_named_pitch(src: Any) -> bool:
    """True if `src` looks like a NamedPitch (has a string `name` attribute)."""
    if src is None:
        return False
    name = getattr(src, "name", None)
    return isinstance(name, str)


def is_pitch(src: Any) -> bool:
    """True if `src` looks like a Pitch (has int step + alt, neither NaN)."""
    if src is None:
        return False
    step = getattr(src, "step", None)
    alt = getattr(src, "alt", None)
    if not isinstance(step, int) or isinstance(step, bool):
        return False
    if not isinstance(alt, int) or isinstance(alt, bool):
        return False
    return True


def chroma(pitch: Pitch) -> int:
    """Pitch class number 0-11. Independent of octave and direction.

    JS: `(SIZES[step] + alt + 120) % 12`. The +120 ensures positivity when
    alt is heavily negative.
    """
    return (SIZES[pitch.step] + pitch.alt + 120) % 12


def height(pitch: Pitch) -> int:
    """Absolute height for ordering. Direction-aware.

    When `oct` is None, treats as -100 (matches JS `oct === void 0 ? -100 : oct`).
    The 100-octave offset just keeps pitch-classes far below noted pitches.
    """
    direction = pitch.dir if pitch.dir is not None else 1
    oct_ = pitch.oct if pitch.oct is not None else -100
    return direction * (SIZES[pitch.step] + pitch.alt + 12 * oct_)


def midi(pitch: Pitch) -> int | None:
    """MIDI number, or None if out of valid MIDI range.

    JS uses height + 12 because MIDI's C-1 = 0 means an octave offset.
    Valid range is 0-127, but the JS guard is `h >= -12 && h <= 115`
    (i.e. midi 0-127). We mirror it exactly.
    """
    if pitch.oct is None:
        return None
    h = height(pitch)
    if -12 <= h <= 115:
        return h + 12
    return None


def coordinates(pitch: Pitch) -> PitchCoordinates:
    """Convert Pitch -> coordinate tuple on the circle of fifths.

    Returns:
    - (fifths,) if pitch is a pitch class (no oct)
    - (fifths, octaves) for notes
    - direction is encoded by negating both components (matches JS)
    """
    direction = pitch.dir if pitch.dir is not None else 1
    f = FIFTHS[pitch.step] + 7 * pitch.alt
    if pitch.oct is None:
        return (direction * f,)
    o = pitch.oct - STEPS_TO_OCTS[pitch.step] - 4 * pitch.alt
    return (direction * f, direction * o)


def pitch(coord: PitchCoordinates) -> Pitch:
    """Inverse of coordinates(): coordinate tuple -> Pitch.

    `coord` may have 1, 2, or 3 elements (pitch class / note / interval).
    The 3rd element when present is the direction.
    """
    f = coord[0]
    o = coord[1] if len(coord) >= 2 else None
    direction = coord[2] if len(coord) >= 3 else None  # type: ignore[misc]
    step = FIFTHS_TO_STEPS[_unaltered(f)]
    alt = floor((f + 1) / 7)
    if o is None:
        return Pitch(step=step, alt=alt, dir=direction)
    oct_ = o + 4 * alt + STEPS_TO_OCTS[step]
    return Pitch(step=step, alt=alt, oct=oct_, dir=direction)


def _unaltered(f: int) -> int:
    """Map fifths value into the unaltered 0..6 range. Mirrors JS `unaltered`."""
    i = (f + 1) % 7
    return 7 + i if i < 0 else i
