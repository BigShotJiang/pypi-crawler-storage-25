"""Interval parsing — port of @tonaljs/pitch-interval.

Parses interval strings ("3M", "P5", "-2m", "9M") into Interval dataclasses.
Internal — exposed publicly through `tonal_py.interval`.

Source: node_modules/@tonaljs/pitch-interval/dist/index.mjs
"""

from __future__ import annotations

import re
from math import floor
from typing import Any

from . import _pitch
from ._cache import make_cache
from ._types import NO_INTERVAL, Interval, Pitch

# Two interval syntaxes joined by alternation: "tonal" (number first, e.g.
# "5P", "-3m") and "shorthand" (quality first, e.g. "P5", "M3"). The
# anchoring is intentionally ^...|...$ — the first alternative anchors at
# start, the second at end. This is exactly how the JS source builds it.
_INTERVAL_TONAL = r"([-+]?\d+)(d{1,4}|m|M|P|A{1,4})"
_INTERVAL_SHORTHAND = r"(AA|A|P|M|m|d|dd)([-+]?\d+)"
_REGEX = re.compile("^" + _INTERVAL_TONAL + "|" + _INTERVAL_SHORTHAND + "$")

_SIZES: list[int] = [0, 2, 4, 5, 7, 9, 11]
# Quality marker for each step: 'P' for steps that take perfect intervals
# (1st, 4th, 5th, 8th); 'M' for those that take major/minor (2nd, 3rd, 6th, 7th).
_TYPES: str = "PMMPPMM"

# Compiled tests for qToAlt
_RE_AAA = re.compile(r"^A+$")
_RE_DDD = re.compile(r"^d+$")


def _fill_str(s: str, n: int) -> str:
    return s * abs(n)


def tokenize_interval(s: str | None) -> tuple[str, str]:
    """Parse an interval string into (number_str, quality). Returns ('','') on miss.

    Uses `re.search` (not `re.match`) because the regex's second alternative
    isn't anchored at start — JS `RegExp.exec` scans for the first match,
    which matters for inputs like "ddd5" where the match starts at offset 1.
    """
    if s is None:
        s = ""
    m = _REGEX.search(s)
    if m is None:
        return ("", "")
    # Tonal form populates groups 1+2; shorthand populates 3+4.
    if m.group(1):
        return (m.group(1), m.group(2))
    if m.group(3):
        return (m.group(4), m.group(3))
    return ("", "")


def _q_to_alt(type_: str, q: str) -> int:
    """Quality string -> alteration count.

    Mirrors the JS branch ladder exactly:
    - "M" on majorable / "P" on perfectable -> 0
    - "m" on majorable -> -1
    - run of A's -> +length (augmented)
    - run of d's -> -length (perfectable) or -(length+1) (majorable, diminished)
    """
    if (q == "M" and type_ == "majorable") or (q == "P" and type_ == "perfectable"):
        return 0
    if q == "m" and type_ == "majorable":
        return -1
    if _RE_AAA.match(q):
        return len(q)
    if _RE_DDD.match(q):
        return -1 * (len(q) if type_ == "perfectable" else len(q) + 1)
    return 0


def _alt_to_q(type_: str, alt: int) -> str:
    """Alteration int -> quality string."""
    if alt == 0:
        return "M" if type_ == "majorable" else "P"
    if alt == -1 and type_ == "majorable":
        return "m"
    if alt > 0:
        return _fill_str("A", alt)
    # Diminished: perfectable counts straight; majorable shifts by 1
    return _fill_str("d", alt if type_ == "perfectable" else alt + 1)


def _pitch_to_name(p: Pitch) -> str:
    """Render a (step, alt, oct, dir) Pitch as an interval name. Mirrors JS pitchName."""
    if not p.dir:
        return ""
    oct_ = p.oct if p.oct is not None else 0
    calc_num = p.step + 1 + 7 * oct_
    num = p.step + 1 if calc_num == 0 else calc_num
    d = "-" if p.dir < 0 else ""
    type_ = "majorable" if _TYPES[p.step] == "M" else "perfectable"
    return d + str(num) + _alt_to_q(type_, p.alt)


def _parse(s: str) -> Interval:
    num_str, q = tokenize_interval(s)
    if num_str == "":
        return NO_INTERVAL
    num = int(num_str)
    step = (abs(num) - 1) % 7
    t = _TYPES[step]
    if t == "M" and q == "P":
        return NO_INTERVAL
    type_ = "majorable" if t == "M" else "perfectable"
    name = str(num) + q
    direction = -1 if num < 0 else 1
    # 8 (octave) keeps its number; otherwise reduce to a 1..7 range with dir.
    if num == 8 or num == -8:
        simple = num
    else:
        simple = direction * (step + 1)
    alt = _q_to_alt(type_, q)
    oct_ = floor((abs(num) - 1) / 7)
    semitones = direction * (_SIZES[step] + alt + 12 * oct_)
    chroma = (direction * (_SIZES[step] + alt) % 12 + 12) % 12
    coord = _pitch.coordinates(Pitch(step=step, alt=alt, oct=oct_, dir=direction))
    return Interval(
        empty=False,
        name=name,
        num=num,
        q=q,
        step=step,
        alt=alt,
        dir=direction,
        type=type_,
        simple=simple,
        semitones=semitones,
        chroma=chroma,
        coord=coord,
        oct=oct_,
    )


_CACHE, clear_cache = make_cache()


def _cache_key(src: Any) -> str:
    if isinstance(src, str):
        return "s:" + src
    if isinstance(src, Interval):
        return "s:" + src.name
    if _pitch.is_pitch(src):
        return "s:" + _pitch_to_name(src)
    return "s:" + repr(src)


def interval(src: Any) -> Interval:
    """Parse anything interval-like into an Interval dataclass.

    Uses duck-typed `is_pitch` (not `isinstance(Pitch)`) so other dataclasses
    with step/alt fields (notably RomanNumeral) flow through the Pitch path,
    matching JS's `isPitch` runtime check.
    """
    key = _cache_key(src)
    cached = _CACHE.get(key)
    if cached is not None:
        return cached  # type: ignore[return-value]
    if isinstance(src, str):
        value = _parse(src)
    elif _pitch.is_pitch(src):
        value = interval(_pitch_to_name(src))
    elif _pitch.is_named_pitch(src):
        value = interval(src.name)
    else:
        value = NO_INTERVAL
    _CACHE[key] = value
    return value


def coord_to_interval(coord: tuple[int, ...], force_descending: bool = False) -> Interval:
    """Convert a coordinate tuple to an Interval.

    `force_descending=True` is used by the unison edge-case in pitch-distance
    (#243 in tonal): when from/to have same height but different steps, the
    interval should be descending unison rather than perfect unison.
    """
    f = coord[0]
    o = coord[1] if len(coord) >= 2 else 0
    is_descending = f * 7 + o * 12 < 0
    if force_descending or is_descending:
        ivl: tuple[int, int, int] = (-f, -o, -1)
    else:
        ivl = (f, o, 1)
    return interval(_pitch.pitch(ivl))
