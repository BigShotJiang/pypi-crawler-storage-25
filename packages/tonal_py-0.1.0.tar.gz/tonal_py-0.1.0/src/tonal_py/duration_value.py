"""Note duration values (whole, half, quarter, ... + dotted variations).

The `DurationValue` namespace converts between named durations
(`"quarter"`, `"q"`, `"q."`) and their fractional values relative to a
whole note. Useful for music notation tooling.

Each duration entry has a denominator (whole = 1, quarter = 4, ...), a
shorthand string (`q`, `e`, `s`, ...), and a list of full names. Dotted
variations (`q.`, `q..`) are computed on the fly.

Example:
    >>> from tonal_py import DurationValue
    >>> DurationValue.value("q")        # quarter note
    0.25
    >>> DurationValue.value("q.")       # dotted quarter
    0.375
    >>> DurationValue.fraction("q.")
    (3, 8)

Source parity: `@tonaljs/duration-value`
"""

from __future__ import annotations

import re

from ._types import NO_DURATION, DurationValue

# (denominator, shorthand, [names...])
# NB: "h" appears twice (half=2 and hundred-twenty-eighth=128). Lookups by
# "h" only ever resolve to the first match (half) — same JS behavior.
DATA: list[tuple[float, str, list[str]]] = [
    (0.125, "dl", ["large", "duplex longa", "maxima", "octuple", "octuple whole"]),
    (0.25, "l", ["long", "longa"]),
    (0.5, "d", ["double whole", "double", "breve"]),
    (1, "w", ["whole", "semibreve"]),
    (2, "h", ["half", "minim"]),
    (4, "q", ["quarter", "crotchet"]),
    (8, "e", ["eighth", "quaver"]),
    (16, "s", ["sixteenth", "semiquaver"]),
    (32, "t", ["thirty-second", "demisemiquaver"]),
    (64, "sf", ["sixty-fourth", "hemidemisemiquaver"]),
    (128, "h", ["hundred twenty-eighth"]),
    (256, "th", ["two hundred fifty-sixth"]),
]


_VALUES: list[DurationValue] = []


def _add(denominator: float, shorthand: str, names_list: list[str]) -> None:
    fraction = (int(1 / denominator), 1) if denominator < 1 else (1, int(denominator))
    _VALUES.append(
        DurationValue(
            empty=False,
            dots="",
            name="",
            value=1 / denominator,
            fraction=fraction,
            shorthand=shorthand,
            names=tuple(names_list),
        )
    )


for _denom, _short, _ns in DATA:
    _add(_denom, _short, _ns)


def names() -> list[str]:
    """Return every full duration name across all entries.

    Each entry contributes multiple names (e.g. quarter has `["quarter",
    "crotchet"]`).

    Example:
        >>> from tonal_py import DurationValue
        >>> "quarter" in DurationValue.names()
        True
        >>> "whole" in DurationValue.names()
        True
    """
    return [n for d in _VALUES for n in d.names]


def shorthands() -> list[str]:
    """Return the shorthand strings (`w`, `h`, `q`, `e`, ...).

    Example:
        >>> from tonal_py import DurationValue
        >>> DurationValue.shorthands()[:5]
        ['dl', 'l', 'd', 'w', 'h']
    """
    return [d.shorthand for d in _VALUES]


_REGEX = re.compile(r"^([^.]+)(\.*)$")


def _calc_dots(fraction: tuple[int, int], dots: int) -> tuple[int, int]:
    """Apply dotted-note math: each dot adds half the previous value."""
    pow_ = 2 ** dots
    numerator = fraction[0] * pow_
    denominator = fraction[1] * pow_
    base = numerator
    for i in range(dots):
        numerator += base // (2 ** (i + 1))
    while numerator % 2 == 0 and denominator % 2 == 0:
        numerator //= 2
        denominator //= 2
    return (numerator, denominator)


def get(name: str) -> DurationValue:
    """Get a duration by name or shorthand, including dotted variations.

    Args:
        name: A duration name or shorthand. Trailing dots add half the
            previous value each (e.g. `"q."` = 1.5x quarter).

    Returns:
        A `DurationValue` dataclass. Returns `NO_DURATION` for unknown input.

    Example:
        >>> from tonal_py import DurationValue
        >>> DurationValue.get("quarter").value
        0.25
        >>> DurationValue.get("q").value
        0.25
        >>> DurationValue.get("q.").fraction
        (3, 8)
    """
    m = _REGEX.match(name)
    if not m:
        return NO_DURATION
    simple = m.group(1)
    dots = m.group(2)
    base = next(
        (d for d in _VALUES if d.shorthand == simple or simple in d.names),
        None,
    )
    if base is None:
        return NO_DURATION
    fraction = _calc_dots(base.fraction, len(dots))
    value_ = fraction[0] / fraction[1]
    return DurationValue(
        empty=False,
        name=name,
        value=value_,
        fraction=fraction,
        shorthand=base.shorthand,
        dots=dots,
        names=base.names,
    )


def value(name: str) -> float:
    """Get a duration as a float (1.0 = whole note).

    Example:
        >>> from tonal_py import DurationValue
        >>> DurationValue.value("q")
        0.25
        >>> DurationValue.value("h.")        # dotted half
        0.75
    """
    return get(name).value


def fraction(name: str) -> tuple[int, int]:
    """Get a duration as a `(numerator, denominator)` reduced fraction.

    Example:
        >>> from tonal_py import DurationValue
        >>> DurationValue.fraction("q")
        (1, 4)
        >>> DurationValue.fraction("q.")
        (3, 8)
    """
    return get(name).fraction
