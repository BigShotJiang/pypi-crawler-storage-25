"""**Deprecated** — use [`Collection`][tonal_py.collection] and [`Note`][tonal_py.note] instead.

The `Array` namespace exists for tonal.js parity. It exposes the same
utilities as `Collection` plus two note-aware helpers
([`sorted_note_names`][tonal_py.array.sorted_note_names] and
[`sorted_uniq_note_names`][tonal_py.array.sorted_uniq_note_names]) which
duplicate functionality available in `Note`.

For new code, prefer the canonical namespaces.

Source parity: `@tonaljs/array` (deprecated upstream)
"""

from __future__ import annotations

from . import _pitch_note

# Re-export collection helpers — same signatures.
from .collection import compact, permutations, range, rotate, shuffle  # noqa: F401, A004


def sorted_note_names(notes: list[str]) -> list[str]:
    """Sort note names ascending by pitch height; drop invalid entries.

    Equivalent to [`Note.sorted_names`][tonal_py.note.sorted_names] —
    prefer that for new code.

    Example:
        >>> from tonal_py import Array
        >>> Array.sorted_note_names(["E4", "C4", "garbage", "G4"])
        ['C4', 'E4', 'G4']
    """
    valid = [n for n in (_pitch_note.note(x) for x in notes) if not n.empty]
    valid.sort(key=lambda n: n.height)
    return [n.name for n in valid]


def sorted_uniq_note_names(arr: list[str]) -> list[str]:
    """Sort + dedupe note names.

    Equivalent to [`Note.sorted_uniq_names`][tonal_py.note.sorted_uniq_names]
    — prefer that for new code.

    Example:
        >>> from tonal_py import Array
        >>> Array.sorted_uniq_note_names(["E4", "C4", "C4", "G4"])
        ['C4', 'E4', 'G4']
    """
    sorted_ = sorted_note_names(arr)
    return [n for i, n in enumerate(sorted_) if i == 0 or n != sorted_[i - 1]]
