"""Note parsing — port of @tonaljs/pitch-note.

Parses note name strings ("C4", "Bb3", "F##-1") into Note dataclasses with
all derived properties (chroma, height, midi, freq, coord). Internal —
exposed publicly through `tonal_py.note`.

Source: node_modules/@tonaljs/pitch-note/dist/index.mjs
"""

from __future__ import annotations

import re
from typing import Any

from . import _pitch
from ._cache import make_cache
from ._types import NO_NOTE, Note, Pitch

# Note string regex: optional letter, optional accidental run (#, b, or x),
# optional integer octave (with sign), then any trailing chars (which, if
# non-empty, invalidate the parse).
_REGEX = re.compile(r"^([a-gA-G]?)(#+|b+|x+|)(-?\d*)\s*(.*)$")

# Semitone offsets for each natural step C..B. Same constants as _pitch.SIZES
# but mirroring the JS source which redeclares them locally.
_SEMI: list[int] = [0, 2, 4, 5, 7, 9, 11]


def _fill_str(s: str, n: int) -> str:
    """Repeat `s` abs(n) times. Mirrors JS `Array(Math.abs(n) + 1).join(s)`."""
    return s * abs(n)


def step_to_letter(step: int) -> str:
    """0..6 -> 'C'..'B'. Out-of-range returns empty string."""
    if 0 <= step < 7:
        return "CDEFGAB"[step]
    return ""


def alt_to_acc(alt: int) -> str:
    """Alteration int -> accidental string. Negative = flats, positive = sharps."""
    if alt < 0:
        return _fill_str("b", -alt)
    return _fill_str("#", alt)


def acc_to_alt(acc: str) -> int:
    """Accidental string -> alteration count. 'b' = -1, '##' = 2, '' = 0."""
    if not acc:
        return 0
    if acc[0] == "b":
        return -len(acc)
    return len(acc)


def tokenize_note(s: str) -> tuple[str, str, str, str]:
    """Split a note-name string into (letter, acc, oct, suffix).

    The regex catch-all (.*) means tokenize never raises; an unparseable
    input returns ('', '', '', original_or_remainder).
    """
    m = _REGEX.match(s)
    if not m:
        return ("", "", "", "")
    letter = m.group(1).upper()
    acc = m.group(2).replace("x", "##")
    return (letter, acc, m.group(3), m.group(4))


def _mod(n: int, m: int) -> int:
    """JS-style modulo that always returns non-negative."""
    return (n % m + m) % m


def _parse(note_name: str) -> Note:
    """Build a Note from a name string. Returns NO_NOTE on parse failure."""
    letter, acc, oct_str, suffix = tokenize_note(note_name)
    if letter == "" or suffix != "":
        return NO_NOTE
    # 'C'(67)+3 mod 7 = 0; 'D'(68)+3 mod 7 = 1; ... 'B'(66+3) = ... lines up.
    step = (ord(letter) + 3) % 7
    alt = acc_to_alt(acc)
    oct_: int | None = int(oct_str) if oct_str else None
    coord = _pitch.coordinates(Pitch(step=step, alt=alt, oct=oct_))
    name = letter + acc + oct_str
    pc = letter + acc
    chroma = (_SEMI[step] + alt + 120) % 12
    if oct_ is None:
        # Pitch class: JS height uses a -99-octave sentinel below the chroma.
        height = _mod(_SEMI[step] + alt, 12) - 12 * 99
        midi = None
        freq = None
    else:
        # Note: pitch-note's height puts C-1 at 0 (so midi == height directly).
        height = _SEMI[step] + alt + 12 * (oct_ + 1)
        midi = height if 0 <= height <= 127 else None
        freq = (2 ** ((height - 69) / 12)) * 440
    return Note(
        empty=False,
        acc=acc,
        alt=alt,
        chroma=chroma,
        coord=coord,
        freq=freq,
        height=height,
        letter=letter,
        midi=midi,
        name=name,
        oct=oct_,
        pc=pc,
        step=step,
    )


def _pitch_to_name(p: Pitch) -> str:
    """Render a Pitch (or Pitch-like) as a note name string. Mirrors JS pitchName."""
    letter = step_to_letter(p.step)
    if not letter:
        return ""
    pc = letter + alt_to_acc(p.alt)
    if p.oct is not None:
        return pc + str(p.oct)
    return pc


_CACHE, clear_cache = make_cache()


def _cache_key(src: Any) -> str:
    """Stable string key for the cache. Strings cache as themselves; Pitch
    and Note objects cache by their canonical name (so all three input forms
    share the same cached Note when they describe the same pitch).
    """
    if isinstance(src, str):
        return "s:" + src
    if isinstance(src, Note):
        return "s:" + src.name
    if _pitch.is_pitch(src):
        return "s:" + _pitch_to_name(src)
    return "s:" + repr(src)


def note(src: Any) -> Note:
    """Parse anything note-like into a Note dataclass.

    Accepts a name string, a Pitch-like object (duck-typed: anything with
    step+alt int fields), or a NamedPitch (anything with a `name` attr —
    including a Note). Invalid input returns NO_NOTE.
    """
    key = _cache_key(src)
    cached = _CACHE.get(key)
    if cached is not None:
        return cached  # type: ignore[return-value]
    if isinstance(src, str):
        value = _parse(src)
    elif _pitch.is_pitch(src):
        value = note(_pitch_to_name(src))
    elif _pitch.is_named_pitch(src):
        value = note(src.name)
    else:
        value = NO_NOTE
    _CACHE[key] = value
    return value


def coord_to_note(note_coord: tuple[int, ...]) -> Note:
    """Coordinate tuple -> Note. Used by transpose/distance helpers."""
    return note(_pitch.pitch(note_coord))
