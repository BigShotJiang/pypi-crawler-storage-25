"""Pitch class sets — the bit-vector representation that powers chord/scale lookups.

A **pitch class set** (Pcset) is the set of distinct pitch classes (chromas
0-11) in a collection of notes or intervals. Tonal represents it as a
12-character binary string where position `i` is `1` iff chroma `i` is
present:

| Notes        | Chroma         | Set num |
| ---          | ---            | ---     |
| C            | `100000000000` | 2048    |
| C, E, G      | `100010010000` | 2192    |
| C major      | `101011010101` | 2773    |
| C minor      | `101101011010` | 2906    |

This compact encoding makes set operations (subset, superset, equality)
into fast bitwise operations, and it's the foundation that
[ChordType][tonal_py.chord_type] and [ScaleType][tonal_py.scale_type] index
their dictionaries by.

Example:
    >>> from tonal_py import Pcset
    >>> Pcset.chroma(["C", "E", "G"])
    '100010010000'
    >>> Pcset.num(["C", "E", "G"])
    2192
    >>> in_cmaj_triad = Pcset.is_subset_of(["C", "E", "G"])
    >>> in_cmaj_triad(["C", "E"])
    True

Source parity: `@tonaljs/pcset`
"""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any

from . import _pitch_distance, _pitch_interval, _pitch_note, collection
from ._types import EMPTY_PCSET, Pcset

# Interval names by chroma index (transcribed verbatim from JS IVLS).
IVLS: tuple[str, ...] = (
    "1P", "2m", "2M", "3m", "3M", "4P",
    "5d", "5P", "6m", "6M", "7m", "7M",
)

_CHROMA_REGEX = re.compile(r"^[01]{12}$")


def is_chroma(s: Any) -> bool:
    """True if `s` is a 12-character binary chroma string.

    Args:
        s: Any value.

    Returns:
        True iff `s` is a string of exactly 12 characters, each `'0'` or `'1'`.

    Example:
        >>> from tonal_py import Pcset
        >>> Pcset.is_chroma("100010010000")
        True
        >>> Pcset.is_chroma("not a chroma")
        False
        >>> Pcset.is_chroma("10010")             # too short
        False
    """
    return isinstance(s, str) and bool(_CHROMA_REGEX.match(s))


def _is_pcset_num(s: Any) -> bool:
    """True if `s` is a number 0..4095 (a valid set number)."""
    if isinstance(s, bool):
        return False
    return isinstance(s, int) and 0 <= s <= 4095


def _is_pcset(s: Any) -> bool:
    """True if `s` looks like a Pcset (has a valid chroma attribute)."""
    if s is None:
        return False
    chroma = getattr(s, "chroma", None)
    return is_chroma(chroma)


def _set_num_to_chroma(n: int) -> str:
    """Decimal -> 12-bit zero-padded binary string."""
    return f"{n:012b}"


def _chroma_to_number(s: str) -> int:
    return int(s, 2)


def _chroma_rotations(chroma: str) -> list[str]:
    """All 12 rotations of the chroma."""
    return ["".join(collection.rotate(i, list(chroma))) for i in range(len(chroma))]


def _chroma_to_intervals(chroma: str) -> tuple[str, ...]:
    """Pull interval names from IVLS for each '1' position."""
    return tuple(IVLS[i] for i, c in enumerate(chroma) if c == "1")


def _list_to_chroma(items: list) -> str:
    """Convert a list of note/interval names into a chroma string. Each item
    is parsed as a note first, falling back to an interval (matches JS).
    """
    if len(items) == 0:
        return EMPTY_PCSET.chroma
    binary = [0] * 12
    for item in items:
        pitch = _pitch_note.note(item)
        if pitch.empty:
            pitch = _pitch_interval.interval(item)
        if not pitch.empty:
            binary[int(pitch.chroma)] = 1
    return "".join(str(b) for b in binary)


def _chroma_to_pcset(chroma: str) -> Pcset:
    """Build a full Pcset (including normalized form) from a chroma string."""
    set_num = _chroma_to_number(chroma)
    # Normalized: lowest set_num among rotations whose number ≥ 2048 (i.e.
    # rotations starting with '1'). Keeps a canonical form per equivalence class.
    rotation_nums = [_chroma_to_number(r) for r in _chroma_rotations(chroma)]
    valid = sorted(n for n in rotation_nums if n >= 2048)
    normalized_num = valid[0] if valid else 0
    normalized = _set_num_to_chroma(normalized_num)
    return Pcset(
        empty=False,
        name="",
        set_num=set_num,
        chroma=chroma,
        normalized=normalized,
        intervals=_chroma_to_intervals(chroma),
    )


# Module-level cache. Mutable on purpose — matches JS `cache = {...}`.
_CACHE: dict[str, Pcset] = {EMPTY_PCSET.chroma: EMPTY_PCSET}


def get(src: Any) -> Pcset:
    """Get a `Pcset` from a chroma string, set number, list, or existing Pcset.

    Args:
        src: One of:
            - A 12-bit chroma string (e.g. `"100010010000"`).
            - An int 0-4095 (the chroma as a number).
            - A list of note names or interval names.
            - An existing `Pcset` (returns it unchanged via the cache).

    Returns:
        The corresponding `Pcset`. Invalid input returns `EMPTY_PCSET`.

    Example:
        >>> from tonal_py import Pcset
        >>> Pcset.get(["C", "E", "G"]).set_num
        2192
        >>> Pcset.get(2192).chroma
        '100010010000'
        >>> Pcset.get("100010010000").set_num
        2192
        >>> Pcset.get("garbage").empty
        True
    """
    if is_chroma(src):
        chroma = src
    elif _is_pcset_num(src):
        chroma = _set_num_to_chroma(src)
    elif isinstance(src, list):
        chroma = _list_to_chroma(src)
    elif _is_pcset(src):
        chroma = src.chroma
    else:
        chroma = EMPTY_PCSET.chroma
    cached = _CACHE.get(chroma)
    if cached is not None:
        return cached
    value = _chroma_to_pcset(chroma)
    _CACHE[chroma] = value
    return value


# Accessors


def chroma(s: Any) -> str:
    """Get the 12-bit chroma string of a pitch class set.

    Example:
        >>> from tonal_py import Pcset
        >>> Pcset.chroma(["C", "D", "E"])
        '101010000000'
    """
    return get(s).chroma


def intervals(s: Any) -> tuple[str, ...]:
    """Get the intervals (from C) of a pitch class set.

    Example:
        >>> from tonal_py import Pcset
        >>> Pcset.intervals(["C", "E", "G"])
        ('1P', '3M', '5P')
    """
    return get(s).intervals


def num(s: Any) -> int:
    """Get the set number (decimal value of the chroma).

    Example:
        >>> from tonal_py import Pcset
        >>> Pcset.num(["C", "D", "E"])
        2688
    """
    return get(s).set_num


def notes(s: Any) -> list[str]:
    """Get the pitch class names (transposed from C).

    Example:
        >>> from tonal_py import Pcset
        >>> Pcset.notes(["C", "E", "G"])
        ['C', 'E', 'G']
    """
    return [_pitch_distance.transpose("C", ivl) for ivl in get(s).intervals]


def chromas() -> list[str]:
    """All 2048 chromas with C as root (set numbers 2048-4095).

    Example:
        >>> from tonal_py import Pcset
        >>> len(Pcset.chromas())
        2048
        >>> Pcset.chromas()[0]      # smallest 12-bit chroma starting with 1
        '100000000000'
    """
    return [_set_num_to_chroma(n) for n in collection.range(2048, 4095)]


def modes(s: Any, normalize: bool = True) -> list[str]:
    """Rotate the chroma to enumerate "modes" (rotations starting with 1).

    With `normalize=True` (default), drops rotations that begin with `0`
    — keeping only those that could be rooted at a real pitch class.
    Useful for finding all the modes of a scale.

    Args:
        s: A Pcset (any input accepted by [`get`][tonal_py.pcset.get]).
        normalize: If True, drop rotations starting with `0`.

    Returns:
        List of chroma strings.

    Example:
        >>> from tonal_py import Pcset
        >>> # C major has 7 rotations starting with 1
        >>> len(Pcset.modes(["C", "D", "E", "F", "G", "A", "B"]))
        7
    """
    pcs = get(s)
    binary = list(pcs.chroma)
    out: list[str] = []
    for i in range(len(binary)):
        r = collection.rotate(i, binary)
        if normalize and r[0] == "0":
            continue
        out.append("".join(r))
    return collection.compact(out)


def is_equal(s1: Any, s2: Any) -> bool:
    """Test if two pitch class sets contain the same chromas.

    Octaves and note duplicates don't matter — only the set of chromas.

    Example:
        >>> from tonal_py import Pcset
        >>> Pcset.is_equal(["C", "E", "G"], ["G2", "E5", "C4", "C6"])
        True
    """
    return get(s1).set_num == get(s2).set_num


def is_subset_of(s: Any) -> Callable[[Any], bool]:
    """Curry a "is subset of" test against a fixed superset.

    `is_subset_of(SUPER)(TEST)` returns True if every pitch class in
    `TEST` is also in `SUPER` AND `TEST` has strictly fewer notes
    (proper subset).

    Args:
        s: The superset to test against.

    Returns:
        A predicate function `(test_set) -> bool`.

    Example:
        >>> from tonal_py import Pcset
        >>> in_cmaj = Pcset.is_subset_of(["C", "E", "G"])
        >>> in_cmaj(["C", "E"])               # CE is a subset of CEG
        True
        >>> in_cmaj(["C", "E", "G", "B"])     # CEGB has notes outside CEG
        False
        >>> in_cmaj(["C", "E", "G"])          # not strict — equal sets fail
        False
    """
    s_num = get(s).set_num

    def predicate(notes: Any) -> bool:
        o_num = get(notes).set_num
        return bool(s_num != 0 and s_num != o_num and (o_num & s_num) == o_num)

    return predicate


def is_superset_of(s: Any) -> Callable[[Any], bool]:
    """Curry a "is superset of" test against a fixed subset.

    `is_superset_of(SUB)(TEST)` returns True if `TEST` contains every
    pitch class in `SUB` plus at least one more.

    Args:
        s: The subset to test against.

    Returns:
        A predicate function `(test_set) -> bool`.

    Example:
        >>> from tonal_py import Pcset
        >>> extends_cmaj = Pcset.is_superset_of(["C", "E", "G"])
        >>> extends_cmaj(["C", "E", "G", "B"])      # Cmaj7 extends Cmaj
        True
        >>> extends_cmaj(["C", "E"])                 # missing the G
        False
    """
    s_num = get(s).set_num

    def predicate(notes: Any) -> bool:
        o_num = get(notes).set_num
        return bool(s_num != 0 and s_num != o_num and (o_num | s_num) == o_num)

    return predicate


def is_note_included_in(s: Any) -> Callable[[Any], bool]:
    """Curry a membership test for "is this note in the pitch class set?".

    Args:
        s: The pitch class set.

    Returns:
        A predicate function `(note_name) -> bool`.

    Example:
        >>> from tonal_py import Pcset
        >>> in_cmaj = Pcset.is_note_included_in(["C", "E", "G"])
        >>> in_cmaj("C4")
        True
        >>> in_cmaj("C#4")
        False
    """
    pcs = get(s)

    def predicate(note_name: Any) -> bool:
        n = _pitch_note.note(note_name)
        return bool(not n.empty and pcs.chroma[int(n.chroma)] == "1")

    return predicate


# Deprecated alias (matches JS export)
includes = is_note_included_in


def filter(s: Any) -> Callable[[list[str]], list[str]]:  # noqa: A001
    """Curry a list-filter that keeps only notes belonging to the pitch class set.

    Args:
        s: The pitch class set.

    Returns:
        A function `(notes) -> notes` that filters in-set notes.

    Example:
        >>> from tonal_py import Pcset
        >>> keep = Pcset.filter(["C", "E", "G"])
        >>> keep(["C2", "C#2", "E2", "F2", "G2"])
        ['C2', 'E2', 'G2']
    """
    is_included = is_note_included_in(s)

    def fn(note_list: list[str]) -> list[str]:
        return [n for n in note_list if is_included(n)]

    return fn


# Deprecated alias matching JS `pcset` export.
pcset = get
