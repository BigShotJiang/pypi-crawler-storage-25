"""The seven diatonic modes.

The `Mode` namespace provides the 7 modes of the major scale (ionian,
dorian, phrygian, lydian, mixolydian, aeolian, locrian) with their
characteristic triad and seventh chord qualities, plus operations for
finding relative-mode tonics.

Each mode has an `alt` field representing its position on the circle of
fifths relative to ionian (0). This drives [`distance`][tonal_py.mode.distance]
and [`relative_tonic`][tonal_py.mode.relative_tonic].

Example:
    >>> from tonal_py import Mode
    >>> Mode.get("dorian").triad
    'm'
    >>> Mode.notes("dorian", "D")
    ['D', 'E', 'F', 'G', 'A', 'B', 'C']
    >>> Mode.relative_tonic("dorian", "ionian", "C")
    'D'

Source parity: `@tonaljs/mode`
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from . import _pitch_distance, collection, interval as _interval_mod, scale_type
from ._types import NO_MODE, Mode

#: The 7 modes as raw rows: `(mode_num, set_num, alt, name, triad, seventh,
#: optional_alias)`. Use [`all`][tonal_py.mode.all] to get them as `Mode`
#: dataclasses.
MODES: list[tuple] = [
    (0, 2773, 0, "ionian", "", "Maj7", "major"),
    (1, 2902, 2, "dorian", "m", "m7"),
    (2, 3418, 4, "phrygian", "m", "m7"),
    (3, 2741, -1, "lydian", "", "Maj7"),
    (4, 2774, 1, "mixolydian", "", "7"),
    (5, 2906, 3, "aeolian", "m", "m7", "minor"),
    (6, 3434, 5, "locrian", "dim", "m7b5"),
]


def _to_mode(row: tuple) -> Mode:
    mode_num, set_num, alt, name, triad, seventh = row[:6]
    alias = row[6] if len(row) >= 7 else None
    aliases = (alias,) if alias else ()
    chroma = bin(set_num)[2:]
    intervals = scale_type.get(name).intervals
    return Mode(
        empty=False,
        intervals=intervals,
        mode_num=mode_num,
        chroma=chroma,
        normalized=chroma,
        name=name,
        set_num=set_num,
        alt=alt,
        triad=triad,
        seventh=seventh,
        aliases=aliases,
    )


_MODES: list[Mode] = [_to_mode(row) for row in MODES]
_INDEX: dict[str, Mode] = {}
for _mode in _MODES:
    _INDEX[_mode.name] = _mode
    for _alias in _mode.aliases:
        _INDEX[_alias] = _mode


def get(name: Any) -> Mode:
    """Get a mode by name or alias.

    Recognized names: ionian, dorian, phrygian, lydian, mixolydian,
    aeolian, locrian. The aliases `major` (for ionian) and `minor`
    (for aeolian) also work.

    Args:
        name: A mode name string (case-insensitive), or an object
            with a `.name` attribute.

    Returns:
        A `Mode` dataclass. Returns `NO_MODE` for unknown input.

    Example:
        >>> from tonal_py import Mode
        >>> Mode.get("dorian").alt
        2
        >>> Mode.get("MAJOR").name      # case-insensitive, alias for ionian
        'ionian'
        >>> Mode.get("notamode").empty
        True
    """
    if isinstance(name, str):
        return _INDEX.get(name.lower(), NO_MODE)
    if name and getattr(name, "name", None):
        return get(name.name)
    return NO_MODE


#: Alias for [`get`][tonal_py.mode.get] (matches tonal.js export).
mode = get


def all() -> list[Mode]:  # noqa: A001
    """Return all 7 modes as a fresh list of `Mode` dataclasses.

    Example:
        >>> from tonal_py import Mode
        >>> len(Mode.all())
        7
    """
    return _MODES.copy()


#: Deprecated alias for [`all`][tonal_py.mode.all] (matches tonal.js).
entries = all


def names() -> list[str]:
    """Return the 7 mode names in canonical order.

    Example:
        >>> from tonal_py import Mode
        >>> Mode.names()
        ['ionian', 'dorian', 'phrygian', 'lydian', 'mixolydian', 'aeolian', 'locrian']
    """
    return [m.name for m in _MODES]


def notes(mode_name: str, tonic: str) -> list[str]:
    """Get the notes of a mode at a given tonic.

    Args:
        mode_name: A mode name or alias.
        tonic: The starting note.

    Returns:
        The 7 notes of the mode, in order.

    Example:
        >>> from tonal_py import Mode
        >>> Mode.notes("dorian", "D")
        ['D', 'E', 'F', 'G', 'A', 'B', 'C']
        >>> Mode.notes("phrygian", "E")
        ['E', 'F', 'G', 'A', 'B', 'C', 'D']
    """
    return [_pitch_distance.transpose(tonic, ivl) for ivl in get(mode_name).intervals]


def _chords(chord_templates: list[str]) -> Callable[[str, str], list[str]]:
    def fn(mode_name: str, tonic: str) -> list[str]:
        m = get(mode_name)
        if m.empty:
            return []
        rotated_chords = collection.rotate(int(m.mode_num), chord_templates)
        tonics = [_pitch_distance.transpose(tonic, i) for i in m.intervals]
        return [tonics[i] + rotated_chords[i] for i in range(len(tonics))]

    return fn


#: Build the diatonic triads of a mode at a tonic. Returns 7 chord names.
#:
#: Example:
#:     >>> from tonal_py import Mode
#:     >>> Mode.triads("ionian", "C")
#:     ['C', 'Dm', 'Em', 'F', 'G', 'Am', 'Bdim']
#:     >>> Mode.triads("dorian", "D")
#:     ['Dm', 'Em', 'F', 'G', 'Am', 'Bdim', 'C']
triads = _chords([row[4] for row in MODES])

#: Build the diatonic seventh chords of a mode at a tonic. Returns 7
#: chord names.
#:
#: Example:
#:     >>> from tonal_py import Mode
#:     >>> Mode.seventh_chords("ionian", "C")
#:     ['CMaj7', 'Dm7', 'Em7', 'FMaj7', 'G7', 'Am7', 'Bm7b5']
seventh_chords = _chords([row[5] for row in MODES])


def distance(destination: str, source: str) -> str:
    """Get the interval between two modes (used by relative-tonic math).

    Computed as the difference in `alt` (circle-of-fifths position) between
    the two modes, simplified to a basic interval.

    Args:
        destination: Target mode name.
        source: Source mode name.

    Returns:
        The interval name. Empty string if either mode is invalid.

    Example:
        >>> from tonal_py import Mode
        >>> Mode.distance("dorian", "ionian")     # 2 fifths up
        '2M'
        >>> Mode.distance("ionian", "dorian")     # 2 fifths down
        '-2M'
    """
    src = get(source)
    dst = get(destination)
    if src.empty or dst.empty:
        return ""
    return _interval_mod.simplify(
        _interval_mod.transpose_fifths("1P", int(dst.alt - src.alt))
    )


def relative_tonic(destination: str, source: str, tonic: str) -> str:
    """Get the tonic of the relative `destination` mode for a given source.

    "C ionian and D dorian have the same notes" — this function expresses
    that relationship: `relative_tonic("dorian", "ionian", "C")` returns
    `"D"`.

    Args:
        destination: Target mode name.
        source: Source mode name.
        tonic: Tonic of the source mode.

    Returns:
        The tonic of the destination mode.

    Example:
        >>> from tonal_py import Mode
        >>> Mode.relative_tonic("dorian", "ionian", "C")
        'D'
        >>> Mode.relative_tonic("aeolian", "ionian", "C")
        'A'
    """
    return _pitch_distance.transpose(tonic, distance(destination, source))
