"""Convert chord progressions ↔ roman numeral sequences.

The `Progression` namespace converts between concrete chord names (in a
specific key) and roman-numeral analysis (key-independent).

Example:
    >>> from tonal_py import Progression
    >>> # Roman numerals to chords in C major
    >>> Progression.from_roman_numerals("C", ["I", "IIm7", "V7"])
    ['C', 'Dm7', 'G7']
    >>> # Chord progression back to roman numerals
    >>> Progression.to_roman_numerals("C", ["C", "Dm7", "G7"])
    ['I', 'IIm7', 'V7']

Source parity: `@tonaljs/progression`
"""

from __future__ import annotations

from typing import Any

from . import _pitch_distance, _pitch_interval, chord as _chord_mod, roman_numeral


def from_roman_numerals(tonic: Any, chords: list[str]) -> list[str]:
    """Convert roman numerals to concrete chord names in a key.

    Args:
        tonic: The key's tonic note.
        chords: List of roman-numeral chord strings.

    Returns:
        List of concrete chord names.

    Example:
        >>> from tonal_py import Progression
        >>> Progression.from_roman_numerals("C", ["I", "IIm7", "V7"])
        ['C', 'Dm7', 'G7']
        >>> Progression.from_roman_numerals("G", ["I", "vi", "IV", "V"])
        ['G', 'E', 'C', 'D']
    """
    rns = [roman_numeral.get(c) for c in chords]
    return [
        _pitch_distance.transpose(tonic, _pitch_interval.interval(rn).name) + rn.chord_type
        for rn in rns
    ]


def to_roman_numerals(tonic: Any, chords: list[str]) -> list[str]:
    """Convert concrete chord names to roman numerals relative to a key.

    Args:
        tonic: The key's tonic note.
        chords: List of chord names.

    Returns:
        List of roman-numeral analysis strings.

    Example:
        >>> from tonal_py import Progression
        >>> Progression.to_roman_numerals("C", ["C", "Dm7", "G7"])
        ['I', 'IIm7', 'V7']
    """
    out: list[str] = []
    for chord in chords:
        note, chord_type, _bass = _chord_mod.tokenize(chord)
        interval_name = _pitch_distance.distance(tonic, note)
        roman = roman_numeral.get(_pitch_interval.interval(interval_name))
        out.append(roman.name + chord_type)
    return out
