"""Roman numeral analysis.

The `RomanNumeral` namespace parses roman-numeral strings into structured
analysis objects. Used by [`Progression`][tonal_py.progression] for chord
progression conversions and by [`Key`][tonal_py.key] internally for
diatonic chord generation.

The parser handles:

- Case to encode mode: uppercase = major (`I`, `V`, `bVII`),
  lowercase = minor (`i`, `iv`, `vi`)
- Accidentals: `#`, `b`, `x` (double-sharp), `bb` (double-flat)
- Optional chord-type suffix: `Vmaj7`, `iim7`, `bIII7b5`

Example:
    >>> from tonal_py import RomanNumeral
    >>> RomanNumeral.get("V").interval
    '5P'
    >>> RomanNumeral.get("bVII").interval
    '7m'
    >>> RomanNumeral.get("iv").major
    False
    >>> RomanNumeral.get("Vmaj7").chord_type
    'maj7'

Source parity: `@tonaljs/roman-numeral`
"""

from __future__ import annotations

import re
from typing import Any

from . import _pitch, _pitch_interval, _pitch_note
from ._cache import make_cache
from ._types import NO_ROMAN_NUMERAL, Pitch, RomanNumeral

_ROMANS = "I II III IV V VI VII"
NAMES: list[str] = _ROMANS.split(" ")
NAMES_MINOR: list[str] = _ROMANS.lower().split(" ")

# Captures (accidentals)(roman numeral)(chord type suffix). The negation set
# `[^IViv]*` ensures the suffix doesn't include further roman characters.
_REGEX = re.compile(r"^(#+|b+|x+|)(IV|I{1,3}|VI{0,2}|iv|i{1,3}|vi{0,2})([^IViv]*)$")


def tokenize(s: str) -> tuple[str, str, str, str]:
    """Tokenize a roman-numeral string into its components.

    Args:
        s: A roman-numeral string.

    Returns:
        `(full_match, accidentals, roman, chord_type)`. All four are
        empty when input doesn't match.

    Example:
        >>> from tonal_py import RomanNumeral
        >>> RomanNumeral.tokenize("VIIb5")
        ('VIIb5', '', 'VII', 'b5')
        >>> RomanNumeral.tokenize("bVII")
        ('bVII', 'b', 'VII', '')
        >>> RomanNumeral.tokenize("garbage")
        ('', '', '', '')
    """
    m = _REGEX.match(s)
    if not m:
        return ("", "", "", "")
    return (m.group(0), m.group(1), m.group(2), m.group(3))


_CACHE, clear_cache = make_cache()


def _from_pitch(p: Any) -> RomanNumeral:
    """Convert a Pitch-like object to a RomanNumeral via its (alt, step) pair."""
    return get(_pitch_note.alt_to_acc(p.alt) + NAMES[p.step])


def _parse(src: str) -> RomanNumeral:
    name, acc, roman, chord_type = tokenize(src)
    if not roman:
        return NO_ROMAN_NUMERAL
    upper_roman = roman.upper()
    step = NAMES.index(upper_roman)
    alt = _pitch_note.acc_to_alt(acc)
    direction = 1
    return RomanNumeral(
        empty=False,
        name=name,
        roman=roman,
        interval=_pitch_interval.interval(Pitch(step=step, alt=alt, dir=direction)).name,
        acc=acc,
        chord_type=chord_type,
        alt=alt,
        step=step,
        major=(roman == upper_roman),
        oct=0,
        dir=direction,
    )


def get(src: Any) -> RomanNumeral:
    """Parse a roman numeral from a string, int, `Pitch`, or `Interval`.

    Args:
        src: One of:
            - A string like `"V7"`, `"bVII"`, `"iv"`, `"VIIb5"`.
            - An int 0-6 selecting from the major roman names
              `["I", "II", "III", "IV", "V", "VI", "VII"]` (note: 0-based,
              a tonal.js quirk).
            - A `Pitch` or `Interval` object — uses its step+alt fields.

    Returns:
        A `RomanNumeral` dataclass. Returns `NO_ROMAN_NUMERAL` for
        unrecognized input.

    Example:
        >>> from tonal_py import RomanNumeral
        >>> RomanNumeral.get("V").interval
        '5P'
        >>> RomanNumeral.get("V").major
        True
        >>> RomanNumeral.get("v").major
        False
        >>> RomanNumeral.get("Vmaj7").chord_type
        'maj7'
        >>> RomanNumeral.get(2).roman      # 0-based: 2 -> "III"
        'III'
    """
    if isinstance(src, str):
        cached = _CACHE.get(src)
        if cached is not None:
            return cached  # type: ignore[return-value]
        value = _parse(src)
        _CACHE[src] = value
        return value
    if isinstance(src, bool):
        # bool is a subclass of int in Python; rule it out before isinstance(int)
        return NO_ROMAN_NUMERAL
    if isinstance(src, int):
        # 1-based: NAMES[src] gives the (src-1)th. JS uses NAMES[src] directly,
        # which means src=0 returns NAMES[0]="I" — preserve that quirk.
        return get(NAMES[src] if 0 <= src < len(NAMES) else "")
    if _pitch.is_pitch(src):
        return _from_pitch(src)
    if _pitch.is_named_pitch(src):
        return get(src.name)
    return NO_ROMAN_NUMERAL


# Deprecated alias matching JS export
roman_numeral = get


def names(major: bool = True) -> list[str]:
    """Return the seven roman numerals.

    Args:
        major: If True (default), returns uppercase (major); if False,
            returns lowercase (minor).

    Returns:
        `["I", ..., "VII"]` or `["i", ..., "vii"]`.

    Example:
        >>> from tonal_py import RomanNumeral
        >>> RomanNumeral.names()
        ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']
        >>> RomanNumeral.names(major=False)
        ['i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii']
    """
    return (NAMES if major else NAMES_MINOR).copy()
