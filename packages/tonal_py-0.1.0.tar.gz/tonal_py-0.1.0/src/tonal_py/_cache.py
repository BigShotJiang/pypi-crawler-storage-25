"""Memoization helper.

Mirrors the JS pattern of module-level `cache = new Map()` used by
@tonaljs/pitch-note, @tonaljs/pitch-interval, @tonaljs/time-signature, and
@tonaljs/roman-numeral.

Why not functools.lru_cache:
- chord_type and scale_type expose `add()` to mutate the dictionary at
  runtime; lru_cache would lock in stale lookups.
- Tests need to clear and inspect caches; lru_cache makes that awkward.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TypeVar

T = TypeVar("T")


def make_cache() -> tuple[dict[str, object], Callable[[], None]]:
    """Create a string-keyed cache dict and a clear callback.

    Usage:
        _CACHE, clear_cache = make_cache()

        def lookup(name: str) -> Foo:
            if name in _CACHE:
                return _CACHE[name]  # type: ignore[return-value]
            value = _expensive(name)
            _CACHE[name] = value
            return value
    """
    cache: dict[str, object] = {}

    def clear() -> None:
        cache.clear()

    return cache, clear
