"""Note transposition and interval distance — port of @tonaljs/pitch-distance.

All operations work as vector arithmetic on circle-of-fifths coordinates.
Source: node_modules/@tonaljs/pitch-distance/dist/index.mjs
"""

from __future__ import annotations

from collections.abc import Callable
from math import floor
from typing import Any

from . import _pitch_interval, _pitch_note


def transpose(note_name: Any, interval_name: Any) -> str:
    """Transpose a note by an interval.

    `interval_name` may be a string ('M3'), an Interval, a Pitch, or a
    [fifths, octaves] list/tuple (used by Note.transpose_fifths /
    Note.transpose_octaves to bypass the parser).
    Returns the transposed note name, or "" if either input is invalid.
    """
    n = _pitch_note.note(note_name)
    if isinstance(interval_name, (list, tuple)) and len(interval_name) >= 2 and not isinstance(interval_name, str):
        # caller-supplied coordinates — skip interval parsing
        # (str check is redundant — kept for clarity)
        # Slicing safely down to the first two scalars; longer tuples (with
        # direction) also work because we only read [0] and [1].
        try:
            f, o = int(interval_name[0]), int(interval_name[1])
        except (TypeError, ValueError):
            return ""
        interval_coord: tuple[int, ...] = (f, o)
    else:
        ivl = _pitch_interval.interval(interval_name)
        if ivl.empty:
            return ""
        interval_coord = ivl.coord
    if n.empty or len(interval_coord) < 2:
        return ""
    nc = n.coord
    if len(nc) == 1:
        tr: tuple[int, ...] = (nc[0] + interval_coord[0],)
    else:
        tr = (nc[0] + interval_coord[0], nc[1] + interval_coord[1])
    return _pitch_note.coord_to_note(tr).name


def tonic_intervals_transposer(
    intervals: list[str], tonic: str | None
) -> Callable[[int], str]:
    """Return a function that, given a normalized scale-degree index (any
    int including negative and beyond the scale length), returns the note
    name. Used by Scale/Mode/Chord for `degrees`/`steps` accessors.
    """
    length = len(intervals)

    def fn(normalized: int) -> str:
        if not tonic:
            return ""
        if normalized < 0:
            index = (length - (-normalized) % length) % length
        else:
            index = normalized % length
        octaves = floor(normalized / length)
        root = transpose(tonic, [0, octaves])
        return transpose(root, intervals[index])

    return fn


def distance(from_note: Any, to_note: Any) -> str:
    """Find the interval from `from_note` to `to_note`.

    Both must be valid note literals (string, Pitch, NamedPitch). For
    pitch-class inputs (no octave), the distance is always ascending.
    Returns "" if either input is invalid.
    """
    f = _pitch_note.note(from_note)
    t = _pitch_note.note(to_note)
    if f.empty or t.empty:
        return ""
    fc = f.coord
    tc = t.coord
    fifths = tc[0] - fc[0]
    if len(fc) == 2 and len(tc) == 2:
        octs = tc[1] - fc[1]
    else:
        octs = -floor(fifths * 7 / 12)
    # Edge case (#243): when both notes have the same height/midi but the
    # source step is higher (e.g. distance("Db", "C#")), force the interval
    # to descending unison.
    force_descending = (
        t.height == f.height
        and t.midi is not None
        and f.oct == t.oct
        and f.step > t.step
    )
    return _pitch_interval.coord_to_interval(
        (fifths, octs), force_descending=force_descending
    ).name
