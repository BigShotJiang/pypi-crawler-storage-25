"""Chord detection — find chord names from a list of notes.

The single public function [`detect`][tonal_py.chord_detect.detect]
returns chord names that match the input notes, weighted so root-position
matches outrank inversions. Re-exported as
[`Chord.detect`][tonal_py.chord.detect].

Example:
    >>> from tonal_py.chord_detect import detect
    >>> detect(["C", "E", "G"])
    ['CM', 'Em#5/C']
    >>> detect(["E", "G", "C"])
    ['Em#5', 'CM/E']

Source parity: `@tonaljs/chord-detect`
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TypedDict

from . import _pitch_note, chord_type, pcset


class DetectOptions(TypedDict, total=False):
    assumePerfectFifth: bool


# Bitmask constants (transcribed verbatim).
BITMASK = {
    # 3m 000100000000
    # 3M 000010000000
    "anyThirds": 384,
    # 5P 000000010000
    "perfectFifth": 16,
    # 5d 000000100000
    # 5A 000000001000
    "nonPerfectFifths": 40,
    "anySeventh": 3,
}


def _test_chroma_number(bitmask: int) -> Callable[[int], bool]:
    return lambda chroma_num: bool(chroma_num & bitmask)


_has_any_third = _test_chroma_number(BITMASK["anyThirds"])
_has_perfect_fifth = _test_chroma_number(BITMASK["perfectFifth"])
_has_any_seventh = _test_chroma_number(BITMASK["anySeventh"])
_has_non_perfect_fifth = _test_chroma_number(BITMASK["nonPerfectFifths"])


def _has_any_third_and_perfect_fifth_and_any_seventh(ct) -> bool:
    n = int(ct.chroma, 2)
    return _has_any_third(n) and _has_perfect_fifth(n) and _has_any_seventh(n)


def _with_perfect_fifth(chroma: str) -> str:
    """If the chroma already has a non-perfect 5th, return as-is; otherwise
    OR-in the perfect-fifth bit. Returns binary string (without zero-padding,
    matching JS `(n).toString(2)`)."""
    n = int(chroma, 2)
    if _has_non_perfect_fifth(n):
        return chroma
    return bin(n | 16)[2:]


def _named_set(notes: list[str]) -> Callable[[int], str]:
    """Build a pitch-class -> name map from notes; later, look up by chroma."""
    pc_to_name: dict[int, str] = {}
    for n in notes:
        nt = _pitch_note.note(n)
        if nt.empty:
            continue
        ch = int(nt.chroma)
        pc_to_name.setdefault(ch, nt.name)

    def lookup(chroma: int) -> str:
        return pc_to_name.get(chroma, "")

    return lookup


def _find_matches(notes: list[str], weight: float, options: DetectOptions) -> list[dict]:
    tonic = notes[0]
    tonic_chroma = int(_pitch_note.note(tonic).chroma)
    note_name = _named_set(notes)
    all_modes = pcset.modes(notes, normalize=False)
    found: list[dict] = []
    for index, mode in enumerate(all_modes):
        mode_with_perfect_fifth = (
            _with_perfect_fifth(mode) if options.get("assumePerfectFifth") else None
        )
        for ct in chord_type.all():
            # Match this mode either directly or — if assumePerfectFifth and
            # the chord type would require a 3-5-7 — with the implied 5P bit.
            if options.get("assumePerfectFifth") and _has_any_third_and_perfect_fifth_and_any_seventh(ct):
                if ct.chroma != mode_with_perfect_fifth:
                    continue
            elif ct.chroma != mode:
                continue
            chord_name = ct.aliases[0] if ct.aliases else ""
            base_note = note_name(index)
            is_inversion = index != tonic_chroma
            if is_inversion:
                found.append({
                    "weight": 0.5 * weight,
                    "name": f"{base_note}{chord_name}/{tonic}",
                })
            else:
                found.append({
                    "weight": 1 * weight,
                    "name": f"{base_note}{chord_name}",
                })
    return found


def detect(source: list[str], options: DetectOptions | None = None) -> list[str]:
    """Detect chord names that match a list of notes.

    The first note is treated as a likely root (root-position weight = 1.0);
    inversions get half-weight (0.5). Results are sorted descending by
    weight.

    Args:
        source: Note names.
        options: Optional dict. `{"assumePerfectFifth": True}` allows
            matches when the input is missing a perfect fifth (useful for
            shell voicings).

    Returns:
        Matching chord names. Empty list for empty input.

    Example:
        >>> from tonal_py import Chord
        >>> Chord.detect(["C", "E", "G"])
        ['CM', 'Em#5/C']
        >>> Chord.detect(["D", "F#", "A", "C"])
        ['D7']
        >>> Chord.detect([])
        []
    """
    options = options or {}  # type: ignore[assignment]
    notes = [n.pc for n in (_pitch_note.note(x) for x in source) if n.pc]
    # JS source uses `note.length === 0` here — a bug (`note` is the imported
    # function so .length is its arity, never 0). The intended check is
    # `notes.length === 0`. JS still effectively returns [] for empty input
    # because all downstream loops produce no matches; in Python, an empty
    # `notes` causes `notes[0]` to raise IndexError, so we guard explicitly.
    if not notes:
        return []
    found = _find_matches(notes, 1, options)
    found = [c for c in found if c["weight"]]
    found.sort(key=lambda c: c["weight"], reverse=True)
    return [c["name"] for c in found]
