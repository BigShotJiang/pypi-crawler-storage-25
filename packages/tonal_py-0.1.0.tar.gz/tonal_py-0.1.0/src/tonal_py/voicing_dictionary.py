"""Pre-built voicing dictionaries for [`Voicing`][tonal_py.voicing].

A voicing dictionary maps chord symbols to lists of interval-set strings
(`"3M 5P 7M 9M"` etc.). Three dictionaries are provided:

| Dictionary | Contents |
| --- | --- |
| `triads` | Major, minor, diminished, augmented triads in three inversions |
| `lefthand` | Jazz left-hand piano voicings (m7, ^7, 7, m7b5, ...) |
| `all` | Union of triads and lefthand |

[`lookup`][tonal_py.voicing_dictionary.lookup] resolves chord-symbol
aliases (so looking up `"Maj7"` finds the `"^7"` entry).

Example:
    >>> from tonal_py import VoicingDictionary
    >>> "M" in VoicingDictionary.triads
    True
    >>> VoicingDictionary.lookup("m7") == VoicingDictionary.lefthand["m7"]
    True

Source parity: `@tonaljs/voicing-dictionary`
"""

from __future__ import annotations

from . import chord as _chord_mod

triads: dict[str, list[str]] = {
    "M": ["1P 3M 5P", "3M 5P 8P", "5P 8P 10M"],
    "m": ["1P 3m 5P", "3m 5P 8P", "5P 8P 10m"],
    "o": ["1P 3m 5d", "3m 5d 8P", "5d 8P 10m"],
    "aug": ["1P 3M 5A", "3M 5A 8P", "5A 8P 10M"],
}

lefthand: dict[str, list[str]] = {
    "m7": ["3m 5P 7m 9M", "7m 9M 10m 12P"],
    "7": ["3M 6M 7m 9M", "7m 9M 10M 13M"],
    "^7": ["3M 5P 7M 9M", "7M 9M 10M 12P"],
    "69": ["3M 5P 6A 9M"],
    "m7b5": ["3m 5d 7m 8P", "7m 8P 10m 12d"],
    "7b9": ["3M 6m 7m 9m", "7m 9m 10M 13m"],  # b9 / b13
    "7b13": ["3M 6m 7m 9m", "7m 9m 10M 13m"],  # b9 / b13
    "o7": ["1P 3m 5d 6M", "5d 6M 8P 10m"],
    "7#11": ["7m 9M 11A 13A"],
    "7#9": ["3M 7m 9A"],
    "mM7": ["3m 5P 7M 9M", "7M 9M 10m 12P"],
    "m6": ["3m 5P 6M 9M", "6M 9M 10m 12P"],
}

all: dict[str, list[str]] = {**triads, **lefthand}  # noqa: A001 (matches JS export)

# JS `defaultDictionary` is `lefthand` (NOT `all`). Voicing.search overrides
# this default to use `triads`.
default_dictionary: dict[str, list[str]] = lefthand


def lookup(symbol: str, dictionary: dict[str, list[str]] | None = None) -> list[str] | None:
    """Look up voicings for a chord symbol with alias resolution.

    First tries `dictionary[symbol]` directly. If that misses, tokenizes
    the symbol via `Chord.get(`"C" + symbol`)` and tries each of its
    aliases against the dictionary.

    Args:
        symbol: A chord symbol (`"m7"`, `"maj7"`, `"^7"`, ...).
        dictionary: The dictionary to search. Defaults to `lefthand`.

    Returns:
        A list of interval-set strings, or `None` if no match.

    Example:
        >>> from tonal_py import VoicingDictionary
        >>> VoicingDictionary.lookup("m7")
        ['3m 5P 7m 9M', '7m 9M 10m 12P']
        >>> VoicingDictionary.lookup("nonsense") is None
        True
    """
    d = dictionary if dictionary is not None else default_dictionary
    if symbol in d:
        return d[symbol]
    aliases = _chord_mod.get("C" + symbol).aliases
    match = next((s for s in d.keys() if s in aliases), None)
    if match is not None:
        return d[match]
    return None
