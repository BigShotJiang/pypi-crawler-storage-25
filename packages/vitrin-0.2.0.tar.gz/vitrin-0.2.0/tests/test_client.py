"""Testes do client HTTP (mocked com responses)."""

import pytest
import responses

from vitrin import (
    Vitrin,
    VitrinAuthError,
    VitrinNotFoundError,
    VitrinRateLimitError,
    VitrinServerError,
    VitrinValidationError,
)

BASE = 'https://api.vitrin.digital/api/v1'


def test_rejects_construction_without_api_key():
    with pytest.raises(ValueError):
        Vitrin(api_key='')


@responses.activate
def test_request_sends_authorization_header():
    responses.add(responses.GET, f'{BASE}/whatever/', json={'ok': True}, status=200)
    Vitrin(api_key='vd_test_xyz').request('/whatever/')
    call = responses.calls[0].request
    assert call.headers['Authorization'] == 'Bearer vd_test_xyz'
    assert 'vitrin-python/' in call.headers['User-Agent']


@responses.activate
def test_query_params_drop_none():
    responses.add(responses.GET, f'{BASE}/list', json=[], status=200)
    Vitrin(api_key='k').request('/list', query={'page': 2, 'unset': None, 'empty': ''})
    url = responses.calls[0].request.url
    assert 'page=2' in url
    assert 'unset' not in url
    assert 'empty' not in url


@responses.activate
def test_204_returns_none():
    responses.add(responses.DELETE, f'{BASE}/x/', status=204)
    assert Vitrin(api_key='k').request('/x/', method='DELETE') is None


@responses.activate
def test_401_maps_to_auth_error():
    responses.add(responses.GET, f'{BASE}/x/', json={'error': 'invalid'}, status=401)
    with pytest.raises(VitrinAuthError):
        Vitrin(api_key='k', max_retries=0).request('/x/')


@responses.activate
def test_404_maps_to_not_found():
    responses.add(responses.GET, f'{BASE}/x/', json={'detail': 'not found'}, status=404)
    with pytest.raises(VitrinNotFoundError):
        Vitrin(api_key='k', max_retries=0).request('/x/')


@responses.activate
def test_422_maps_to_validation_with_field_errors():
    responses.add(
        responses.POST, f'{BASE}/x/',
        json={'amount': ['positivo'], 'cpf_cnpj': ['inválido']},
        status=422,
    )
    try:
        Vitrin(api_key='k', max_retries=0).request('/x/', method='POST', body={})
    except VitrinValidationError as e:
        assert e.field_errors['amount'] == ['positivo']
        assert e.field_errors['cpf_cnpj'] == ['inválido']
    else:
        pytest.fail('should have raised')


@responses.activate
def test_429_retries_then_succeeds():
    responses.add(responses.GET, f'{BASE}/x/',
                  json={'error': 'rate'}, status=429,
                  headers={'retry-after': '0'})
    responses.add(responses.GET, f'{BASE}/x/', json={'ok': True}, status=200)
    result = Vitrin(api_key='k', max_retries=3).request('/x/')
    assert result == {'ok': True}
    assert len(responses.calls) == 2


@responses.activate
def test_503_retries_and_gives_up():
    for _ in range(3):
        responses.add(responses.GET, f'{BASE}/x/', json={'error': 'down'}, status=503)
    with pytest.raises(VitrinServerError):
        Vitrin(api_key='k', max_retries=2).request('/x/')
    assert len(responses.calls) == 3  # 1 inicial + 2 retries


@responses.activate
def test_400_does_not_retry():
    responses.add(responses.POST, f'{BASE}/x/', json={'error': 'bad'}, status=400)
    with pytest.raises(VitrinValidationError):
        Vitrin(api_key='k', max_retries=5).request('/x/', method='POST', body={})
    assert len(responses.calls) == 1


@responses.activate
def test_idempotency_key_forwarded():
    responses.add(responses.POST, f'{BASE}/charges/',
                  json={'id': 'tx_1'}, status=201)
    Vitrin(api_key='k').charges.create(
        customer_id='cus_1', amount=100, billing_type='PIX',
        idempotency_key='order-42',
    )
    assert responses.calls[0].request.headers['Idempotency-Key'] == 'order-42'


@responses.activate
def test_charges_create_posts_body():
    responses.add(responses.POST, f'{BASE}/charges/',
                  json={'id': 'tx_1'}, status=201)
    Vitrin(api_key='k').charges.create(
        customer_id='cus_1', amount=99.90, billing_type='PIX', description='x',
    )
    body = responses.calls[0].request.body
    if isinstance(body, bytes):
        body = body.decode('utf-8')
    assert '"customer_id": "cus_1"' in body
    assert '"billing_type": "PIX"' in body


@responses.activate
def test_customers_namespaces_exposed():
    responses.add(responses.GET, f'{BASE}/customers/cus_x/',
                  json={'id': 'cus_x', 'name': 'Maria'}, status=200)
    v = Vitrin(api_key='k')
    assert v.customers.retrieve('cus_x')['name'] == 'Maria'
