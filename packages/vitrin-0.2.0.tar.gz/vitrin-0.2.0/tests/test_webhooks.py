"""Testes do helper de webhooks."""

import hashlib
import hmac
import time

import pytest

from vitrin import VitrinError, webhooks

SECRET = 'whsec_test'


def _sign(payload: bytes) -> str:
    return hmac.new(SECRET.encode(), payload, hashlib.sha256).hexdigest()


def test_constructs_event_with_valid_signature():
    payload = b'{"IdTransaction":"tx_1","amount":100}'
    evt = webhooks.construct_event(
        payload=payload,
        signature=_sign(payload),
        secret=SECRET,
        timestamp=str(int(time.time())),
        event_type='Autorizado',
        event_id='evt_1',
    )
    assert evt.type == 'Autorizado'
    assert evt.id == 'evt_1'
    assert evt.data['IdTransaction'] == 'tx_1'


def test_rejects_invalid_signature():
    with pytest.raises(VitrinError, match='Assinatura'):
        webhooks.construct_event(
            payload=b'{"x":1}',
            signature='a' * 64,
            secret=SECRET,
        )


def test_rejects_missing_signature():
    with pytest.raises(VitrinError, match='Signature'):
        webhooks.construct_event(payload=b'{}', signature=None, secret=SECRET)


def test_rejects_old_timestamp():
    payload = b'{}'
    old = str(int(time.time()) - 600)
    with pytest.raises(VitrinError, match='tolerância'):
        webhooks.construct_event(
            payload=payload, signature=_sign(payload),
            secret=SECRET, timestamp=old,
        )


def test_accepts_old_timestamp_when_tolerance_zero():
    payload = b'{}'
    old = str(int(time.time()) - 600)
    evt = webhooks.construct_event(
        payload=payload, signature=_sign(payload),
        secret=SECRET, timestamp=old, tolerance_ms=0,
    )
    assert evt is not None


def test_accepts_string_payload():
    payload = '{"x":1}'
    evt = webhooks.construct_event(
        payload=payload,
        signature=_sign(payload.encode()),
        secret=SECRET,
    )
    assert evt.data == {'x': 1}


def test_rejects_non_json_payload():
    payload = b'not json'
    with pytest.raises(VitrinError, match='JSON'):
        webhooks.construct_event(
            payload=payload, signature=_sign(payload), secret=SECRET,
        )
