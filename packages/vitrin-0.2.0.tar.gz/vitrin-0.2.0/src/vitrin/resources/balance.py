from __future__ import annotations
from typing import Any
from .._client import Client


class BalanceAPI:
    def __init__(self, client: Client) -> None:
        self._client = client

    def retrieve(self) -> dict[str, Any]:
        return self._client.request('/balance/')

    def scheduled(self, days_ahead: int = 90) -> dict[str, Any]:
        return self._client.request('/balance/scheduled/', query={'days_ahead': days_ahead})
