from __future__ import annotations
from typing import Any
from .._client import Client


class Plans:
    def __init__(self, client: Client) -> None:
        self._client = client

    def create(self, **fields: Any) -> dict[str, Any]:
        return self._client.request('/plans/', method='POST', body=fields)

    def retrieve(self, plan_id: str) -> dict[str, Any]:
        return self._client.request(f'/plans/{plan_id}/')

    def list(self, **params: Any) -> dict[str, Any]:
        return self._client.request('/plans/', query=params)

    def update(self, plan_id: str, **fields: Any) -> dict[str, Any]:
        return self._client.request(f'/plans/{plan_id}/', method='PATCH', body=fields)

    def delete(self, plan_id: str) -> None:
        self._client.request(f'/plans/{plan_id}/', method='DELETE')
