from __future__ import annotations
from typing import Any
from .._client import Client


class Products:
    def __init__(self, client: Client) -> None:
        self._client = client

    def create(self, **fields: Any) -> dict[str, Any]:
        return self._client.request('/products/', method='POST', body=fields)

    def retrieve(self, product_id: str) -> dict[str, Any]:
        return self._client.request(f'/products/{product_id}/')

    def list(self, **params: Any) -> dict[str, Any]:
        return self._client.request('/products/', query=params)

    def update(self, product_id: str, **fields: Any) -> dict[str, Any]:
        return self._client.request(
            f'/products/{product_id}/', method='PATCH', body=fields,
        )

    def delete(self, product_id: str) -> None:
        self._client.request(f'/products/{product_id}/', method='DELETE')
