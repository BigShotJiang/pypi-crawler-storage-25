from __future__ import annotations
from typing import Any
from .._client import Client


class Customers:
    def __init__(self, client: Client) -> None:
        self._client = client

    def create(self, **fields: Any) -> dict[str, Any]:
        return self._client.request('/customers/', method='POST', body=fields)

    def retrieve(self, customer_id: str) -> dict[str, Any]:
        return self._client.request(f'/customers/{customer_id}/')

    def list(self, **params: Any) -> dict[str, Any]:
        return self._client.request('/customers/', query=params)

    def update(self, customer_id: str, **fields: Any) -> dict[str, Any]:
        return self._client.request(
            f'/customers/{customer_id}/', method='PATCH', body=fields,
        )

    def delete(self, customer_id: str) -> None:
        self._client.request(f'/customers/{customer_id}/', method='DELETE')

    # ── Cartão salvo (one-click buy) ──────────────────────────────────

    def save_card(
        self,
        customer_id: str,
        *,
        credit_card: dict[str, str],
        consent: dict[str, str],
    ) -> dict[str, Any]:
        """Tokeniza + persiste o cartão preferido do cliente.

        Salvar novo substitui o anterior. `consent` é obrigatório (LGPD):
        ``{"accepted_at": iso8601, "ip": "..."}``.
        """
        return self._client.request(
            f'/customers/{customer_id}/saved-card/',
            method='POST',
            body={'credit_card': credit_card, 'consent': consent},
        )

    def saved_card(self, customer_id: str) -> dict[str, Any]:
        """Retorna brand/last4/exp/holder do cartão salvo (nunca o token)."""
        return self._client.request(f'/customers/{customer_id}/saved-card/')

    def delete_saved_card(self, customer_id: str) -> None:
        self._client.request(
            f'/customers/{customer_id}/saved-card/', method='DELETE',
        )

    def saved_card_management_link(self, customer_id: str) -> dict[str, Any]:
        """Gera URL assinada (JWT 24h) pro cliente final gerenciar o próprio cartão."""
        return self._client.request(
            f'/customers/{customer_id}/saved-card/management-link/',
            method='POST',
        )

    def one_click_link(
        self,
        customer_id: str,
        *,
        product_id: str | None = None,
        plan_id: str | None = None,
        amount: str | None = None,
        installments: int = 1,
        coupon_code: str | None = None,
        bump_ids: list[str] | None = None,
        expires_in: int = 900,
    ) -> dict[str, Any]:
        """Gera link assinado de recompra one-click (JWT 15min, uso único).

        Informe exatamente um de ``product_id`` ou ``plan_id``. ``amount``
        é opcional: usado pra produto ``customer_defined`` ou pra plano com
        ``allow_customer_defined_amount=True``. ``coupon_code`` e
        ``bump_ids`` só funcionam pra produto.
        """
        body: dict[str, Any] = {
            'installments': installments,
            'expires_in': expires_in,
        }
        if product_id:
            body['product_id'] = product_id
        if plan_id:
            body['plan_id'] = plan_id
        if amount is not None:
            body['amount'] = amount
        if coupon_code:
            body['coupon_code'] = coupon_code
        if bump_ids:
            body['bump_ids'] = bump_ids
        return self._client.request(
            f'/customers/{customer_id}/one-click-link/',
            method='POST', body=body,
        )
