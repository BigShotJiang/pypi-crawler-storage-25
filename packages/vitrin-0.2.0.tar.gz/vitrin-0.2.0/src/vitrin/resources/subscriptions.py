from __future__ import annotations
from typing import Any
from .._client import Client


class Subscriptions:
    def __init__(self, client: Client) -> None:
        self._client = client

    def create(self, **fields: Any) -> dict[str, Any]:
        return self._client.request('/subscriptions/', method='POST', body=fields)

    def retrieve(self, sub_id: str) -> dict[str, Any]:
        return self._client.request(f'/subscriptions/{sub_id}/')

    def list(self, **params: Any) -> dict[str, Any]:
        return self._client.request('/subscriptions/', query=params)

    def cancel(self, sub_id: str, *, pin: str) -> dict[str, Any]:
        return self._client.request(
            f'/subscriptions/{sub_id}/cancel/', method='POST', body={'pin': pin},
        )
