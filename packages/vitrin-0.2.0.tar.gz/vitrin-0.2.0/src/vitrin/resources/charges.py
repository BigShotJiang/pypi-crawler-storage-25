from __future__ import annotations
from typing import Any
from .._client import Client


class Charges:
    """Cobranças avulsas — PIX, Boleto, Cartão."""

    def __init__(self, client: Client) -> None:
        self._client = client

    def create(
        self,
        *,
        customer_id: str,
        amount: float | str,
        billing_type: str,
        description: str = '',
        due_date: str | None = None,
        installments: int = 1,
        credit_card_token: str | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        body = {
            'customer_id': customer_id,
            'amount': amount,
            'billing_type': billing_type,
            'description': description,
            'installments': installments,
        }
        if due_date:
            body['due_date'] = due_date
        if credit_card_token:
            body['credit_card_token'] = credit_card_token
        return self._client.request(
            '/charges/', method='POST', body=body, idempotency_key=idempotency_key,
        )

    def create_with_saved_card(
        self,
        *,
        customer_id: str,
        amount: float | str,
        description: str = '',
        installments: int = 1,
        external_reference: str | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """One-click buy: cobra usando o cartão preferido salvo do cliente.

        Cliente precisa ter um saved card (`customers.save_card`). Erros:
        422 ``no_saved_card``, 422 ``card_expired``.
        """
        body: dict[str, Any] = {
            'customer_id': customer_id,
            'amount': amount,
            'description': description,
            'installments': installments,
        }
        if external_reference:
            body['external_reference'] = external_reference
        return self._client.request(
            '/charges/charge-saved/',
            method='POST', body=body, idempotency_key=idempotency_key,
        )

    def retrieve(self, charge_id: str) -> dict[str, Any]:
        return self._client.request(f'/transactions/{charge_id}/')

    def list(self, **params: Any) -> dict[str, Any]:
        return self._client.request('/reports/transactions/', query=params)

    def refund(
        self,
        charge_id: str,
        *,
        pin: str,
        amount: float | str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {'pin': pin}
        if amount is not None:
            body['amount'] = amount
        return self._client.request(
            f'/payments/{charge_id}/refund/', method='POST', body=body,
        )

    def cancel(self, charge_id: str, *, pin: str) -> dict[str, Any]:
        return self._client.request(
            f'/payments/{charge_id}/cancel/', method='POST', body={'pin': pin},
        )

    def status(self, charge_id: str) -> dict[str, Any]:
        return self._client.request(f'/payments/{charge_id}/status/')
