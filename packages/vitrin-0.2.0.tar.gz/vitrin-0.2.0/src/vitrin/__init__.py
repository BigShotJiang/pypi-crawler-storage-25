"""SDK oficial Python para a API da Vitrin Digital.

Uso típico::

    from vitrin import Vitrin

    vitrin = Vitrin(api_key=os.environ["VITRIN_API_KEY"])

    customer = vitrin.customers.create(
        name="Maria Silva",
        email="maria@example.com",
        cpf_cnpj="12345678901",
    )
    charge = vitrin.charges.create(
        customer_id=customer["id"],
        amount=99.90,
        billing_type="PIX",
        idempotency_key=f"pedido-{order_id}",
    )
    print(charge["pix_qr_code"])

Validação de webhook::

    from vitrin import webhooks
    event = webhooks.construct_event(
        payload=request.body,
        signature=request.headers["X-Vitrin-Signature"],
        secret=os.environ["VITRIN_WEBHOOK_SECRET"],
    )
"""

from ._client import Client, DEFAULT_BASE_URL
from .errors import (
    VitrinError,
    VitrinAuthError,
    VitrinValidationError,
    VitrinRateLimitError,
    VitrinNotFoundError,
    VitrinServerError,
    VitrinNetworkError,
)
from .resources import Charges, Customers, Plans, Subscriptions, Products, BalanceAPI
from . import webhooks

__version__ = '0.1.0'

__all__ = [
    'Vitrin',
    'webhooks',
    'VitrinError',
    'VitrinAuthError',
    'VitrinValidationError',
    'VitrinRateLimitError',
    'VitrinNotFoundError',
    'VitrinServerError',
    'VitrinNetworkError',
]


class Vitrin:
    """Entry-point do SDK. Instanciar com a `api_key` da org."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        self.client = Client(
            api_key=api_key, base_url=base_url, timeout=timeout, max_retries=max_retries,
        )
        self.charges = Charges(self.client)
        self.customers = Customers(self.client)
        self.plans = Plans(self.client)
        self.subscriptions = Subscriptions(self.client)
        self.products = Products(self.client)
        self.balance = BalanceAPI(self.client)

    def request(self, path: str, **kwargs):  # type: ignore[no-untyped-def]
        """Acesso bruto pra endpoints não cobertos pelos resources."""
        return self.client.request(path, **kwargs)
