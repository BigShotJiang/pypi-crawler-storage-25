"""HTTP client interno do SDK.

Wrapper sobre `requests.Session` com:
- Headers padrão (Authorization, User-Agent, Content-Type)
- Mapeamento de status HTTP → :class:`vitrin.errors.VitrinError`
- Retry automático em 429/5xx com backoff exponencial e jitter
- Idempotency-Key opcional pra POSTs
"""

from __future__ import annotations

import json as _json
import platform
import random
import time
from typing import Any
from urllib.parse import urljoin

import requests

from .errors import (
    VitrinAuthError,
    VitrinError,
    VitrinNetworkError,
    VitrinNotFoundError,
    VitrinRateLimitError,
    VitrinServerError,
    VitrinValidationError,
)

DEFAULT_BASE_URL = 'https://api.vitrin.digital/api/v1'
SDK_VERSION = '0.1.0'


class Client:
    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries: int = 3,
        session: requests.Session | None = None,
    ) -> None:
        if not api_key:
            raise ValueError('api_key é obrigatório')
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = session or requests.Session()

    def request(
        self,
        path: str,
        *,
        method: str = 'GET',
        body: Any = None,
        query: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> Any:
        url = urljoin(self.base_url + '/', path.lstrip('/'))
        headers = self._build_headers(has_body=body is not None, idempotency_key=idempotency_key)
        params = _filter_query(query)

        last_exc: VitrinError | None = None

        for attempt in range(self.max_retries + 1):
            try:
                resp = self.session.request(
                    method=method,
                    url=url,
                    headers=headers,
                    params=params,
                    data=_json.dumps(body) if body is not None else None,
                    timeout=self.timeout,
                )
            except requests.exceptions.Timeout as e:
                last_exc = VitrinNetworkError(f'Timeout após {self.timeout}s')
                if attempt < self.max_retries:
                    time.sleep(_backoff(attempt))
                    continue
                raise last_exc from e
            except requests.exceptions.RequestException as e:
                last_exc = VitrinNetworkError(str(e))
                if attempt < self.max_retries:
                    time.sleep(_backoff(attempt))
                    continue
                raise last_exc from e

            request_id = resp.headers.get('x-request-id')

            if 200 <= resp.status_code < 300:
                if resp.status_code == 204 or not resp.content:
                    return None
                try:
                    return resp.json()
                except ValueError:
                    return resp.text

            try:
                parsed = resp.json()
            except ValueError:
                parsed = resp.text

            err = _map_error(resp.status_code, parsed, request_id)
            retriable = resp.status_code == 429 or resp.status_code >= 500
            if retriable and attempt < self.max_retries:
                retry_after = _parse_retry_after(resp.headers.get('retry-after'))
                time.sleep(retry_after if retry_after is not None else _backoff(attempt))
                last_exc = err
                continue
            raise err

        raise last_exc or VitrinError('Esgotou tentativas sem erro identificado')

    def _build_headers(self, *, has_body: bool, idempotency_key: str | None) -> dict[str, str]:
        py_version = platform.python_version()
        ua = f'vitrin-python/{SDK_VERSION} python/{py_version}'
        headers: dict[str, str] = {
            'Authorization': f'Bearer {self.api_key}',
            'Accept': 'application/json',
            'User-Agent': ua,
        }
        if has_body:
            headers['Content-Type'] = 'application/json'
        if idempotency_key:
            headers['Idempotency-Key'] = idempotency_key
        return headers


def _filter_query(query: dict[str, Any] | None) -> dict[str, Any] | None:
    if not query:
        return None
    return {k: v for k, v in query.items() if v is not None and v != ''}


def _map_error(status: int, body: Any, request_id: str | None) -> VitrinError:
    message = _extract_message(body) or f'HTTP {status}'
    common = {'status_code': status, 'body': body, 'request_id': request_id}

    if status in (401, 403):
        return VitrinAuthError(message, **common)
    if status == 404:
        return VitrinNotFoundError(message, **common)
    if status == 429:
        return VitrinRateLimitError(message, **common)
    if status >= 500:
        return VitrinServerError(message, **common)
    if status in (400, 422):
        return VitrinValidationError(
            message, **common, field_errors=_extract_field_errors(body),
        )
    return VitrinError(message, **common)


def _extract_message(body: Any) -> str | None:
    if not isinstance(body, dict):
        return None
    if isinstance(body.get('error'), str):
        return body['error']
    if isinstance(body.get('detail'), str):
        return body['detail']
    for v in body.values():
        if isinstance(v, list) and v and isinstance(v[0], str):
            return v[0]
    return None


def _extract_field_errors(body: Any) -> dict[str, list[str]]:
    if not isinstance(body, dict):
        return {}
    out: dict[str, list[str]] = {}
    for k, v in body.items():
        if isinstance(v, list) and all(isinstance(x, str) for x in v):
            out[k] = v
    return out


def _parse_retry_after(value: str | None) -> float | None:
    if not value:
        return None
    try:
        return float(value)
    except ValueError:
        return None


def _backoff(attempt: int) -> float:
    base = 0.25 * (2 ** attempt)
    return base + random.uniform(0, base * 0.5)
