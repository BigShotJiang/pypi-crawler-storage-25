"""Validação de webhooks Vitrin → seu backend Python.

A Vitrin envia POST com:
    X-Vitrin-Signature: HMAC-SHA256 hex do body cru com o webhook_secret
    X-Vitrin-Timestamp: epoch UTC em segundos
    X-Vitrin-Event:     tipo do evento
    X-Vitrin-Event-Id:  ID único pra idempotência

Use :func:`construct_event` no handler do seu backend antes de processar.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass, field
from typing import Any

from .errors import VitrinError


@dataclass
class WebhookEvent:
    type: str
    id: str
    timestamp_ms: int
    data: dict[str, Any] = field(default_factory=dict)


def construct_event(
    *,
    payload: bytes | str,
    signature: str | None,
    secret: str,
    timestamp: str | None = None,
    event_type: str | None = None,
    event_id: str | None = None,
    tolerance_ms: int = 300_000,
) -> WebhookEvent:
    """Valida a assinatura HMAC + timestamp e retorna o evento parseado."""
    if not signature:
        raise VitrinError('Header X-Vitrin-Signature ausente.')
    if not secret:
        raise VitrinError('webhook secret é obrigatório.')

    raw = payload.encode('utf-8') if isinstance(payload, str) else payload
    expected = hmac.new(secret.encode('utf-8'), raw, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature.strip()):
        raise VitrinError('Assinatura inválida — payload pode ter sido adulterado.')

    if tolerance_ms > 0 and timestamp:
        try:
            ts_ms = int(timestamp) * 1000
        except ValueError as e:
            raise VitrinError('X-Vitrin-Timestamp inválido.') from e
        drift = abs(int(time.time() * 1000) - ts_ms)
        if drift > tolerance_ms:
            raise VitrinError(
                f'Webhook fora da janela de tolerância (drift {drift}ms > {tolerance_ms}ms).'
            )

    try:
        data = json.loads(raw.decode('utf-8'))
    except (ValueError, UnicodeDecodeError) as e:
        raise VitrinError('Payload não é JSON válido.') from e

    return WebhookEvent(
        type=event_type or '',
        id=event_id or '',
        timestamp_ms=int(timestamp) * 1000 if timestamp else int(time.time() * 1000),
        data=data,
    )
