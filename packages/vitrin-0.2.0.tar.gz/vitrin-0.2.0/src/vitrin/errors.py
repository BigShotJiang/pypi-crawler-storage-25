"""Hierarquia de erros do SDK Vitrin.

Todos descendem de :class:`VitrinError`.
"""

from __future__ import annotations
from typing import Any


class VitrinError(Exception):
    """Erro base do SDK Vitrin. Toda chamada à API que falha levanta isso ou subclasse."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        body: Any = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.body = body
        self.request_id = request_id

    def __repr__(self) -> str:  # pragma: no cover
        return f'<{type(self).__name__}: {self.message} (status={self.status_code})>'


class VitrinAuthError(VitrinError):
    """401/403 — chave inválida, expirada, ou sem permissão."""


class VitrinValidationError(VitrinError):
    """400/422 — DRF retornou erros de campo ou body inválido."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        body: Any = None,
        request_id: str | None = None,
        field_errors: dict[str, list[str]] | None = None,
    ) -> None:
        super().__init__(message, status_code=status_code, body=body, request_id=request_id)
        self.field_errors = field_errors or {}


class VitrinRateLimitError(VitrinError):
    """429 — você ultrapassou o rate limit."""


class VitrinNotFoundError(VitrinError):
    """404 — recurso não encontrado."""


class VitrinServerError(VitrinError):
    """5xx — falha do lado do servidor."""


class VitrinNetworkError(VitrinError):
    """Falha antes da resposta HTTP — DNS, timeout, conexão recusada."""
