# Changelog — vitrin

## 0.2.0 — 2026-05-16

### Adicionado
- `customers.save_card()` / `saved_card()` / `delete_saved_card()` —
  tokenização + persistência de cartão preferido (one-click buy).
  Requer `consent` com `accepted_at` + `ip` (LGPD).
- `customers.saved_card_management_link()` — gera URL com JWT 24h pro
  cliente final ver/remover o próprio cartão.
- `charges.create_with_saved_card()` — cobrança one-click server-side
  (sem CVV) usando o token salvo.
- `customers.one_click_link()` — gera link assinado de recompra (JWT
  15min, uso único) pra o cliente final confirmar a compra com 1 clique
  numa página hospedada pela Vitrin. Aceita `coupon_code` e `bump_ids`
  (só produto).

## 0.1.0 — Release inicial
