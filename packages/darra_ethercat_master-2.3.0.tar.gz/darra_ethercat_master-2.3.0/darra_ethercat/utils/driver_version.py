# -*- coding: utf-8 -*-
"""
内核驱动版本查询 + DLL/驱动 兼容性比对.

对应 native:
- GetDriverVersion() -> driver_version_info_t*
- InvalidateDriverVersionCache()
- EnsureDriversRunning() -> int (1=ok)

所有失败路径都不抛异常, 仅写日志, 兼容旧 DLL.
"""

import ctypes
import logging
from typing import Optional

from .dll import DarraCoreDLL, DriverVersionInfo, DllVersionInfo

_log = logging.getLogger("darra_ethercat.driver_version")


def _get_dll() -> Optional[DarraCoreDLL]:
    try:
        return DarraCoreDLL()
    except Exception:
        return None


def get_driver_version(dll: Optional[DarraCoreDLL] = None) -> dict:
    """查内核驱动版本.

    返回字典:
        {'available': bool, 'major', 'minor', 'build',
         'build_date', 'driver_name', 'error_code', 'version'}
    失败时 available=False + 'error_message' 描述失败原因.
    """
    if dll is None:
        dll = _get_dll()
    if dll is None:
        return {'available': False, 'error_message': 'Darra.Core.dll 未加载'}
    try:
        ptr = dll.GetDriverVersion()
    except NotImplementedError:
        return {'available': False, 'error_message': 'GetDriverVersion 未在当前 DLL 中导出'}
    except Exception as e:
        return {'available': False, 'error_message': f'调用失败: {e}'}

    if not ptr:
        return {'available': False, 'error_message': 'NULL ptr'}
    info = ptr.contents
    available = bool(info.available)
    return {
        'major': int(info.major),
        'minor': int(info.minor),
        'build': int(info.build),
        'build_date': info.build_date.decode('utf-8', errors='replace').rstrip('\x00'),
        'driver_name': info.driver_name.decode('utf-8', errors='replace').rstrip('\x00'),
        'available': available,
        'error_code': int(info.error_code),
        'version': (f"{info.major}.{info.minor}.{info.build}" if available else "N/A"),
    }


def invalidate_driver_version_cache(dll: Optional[DarraCoreDLL] = None) -> None:
    """让 native 端下一次 GetDriverVersion 重新查询 (服务重启后调用)."""
    if dll is None:
        dll = _get_dll()
    if dll is None:
        return
    try:
        dll.InvalidateDriverVersionCache()
    except Exception:
        pass


def ensure_drivers_running(dll: Optional[DarraCoreDLL] = None) -> bool:
    """确保 Darra 内核驱动服务处于 RUNNING. 失败返回 False, 不抛异常."""
    if dll is None:
        dll = _get_dll()
    if dll is None:
        return False
    try:
        return bool(dll.EnsureDriversRunning())
    except Exception:
        return False


def _read_dll_version(dll: DarraCoreDLL) -> Optional[dict]:
    try:
        ptr = dll.GetDllVersionInfo()
        if not ptr:
            return None
        info = ctypes.cast(ptr, ctypes.POINTER(DllVersionInfo)).contents
        return {
            'major': int(info.major),
            'minor': int(info.minor),
            'patch': int(info.patch),
            'build': int(info.build),
        }
    except Exception:
        return None


def log_compatibility(dll: Optional[DarraCoreDLL] = None) -> None:
    """比较 DLL 和内核驱动 (major, minor); 不匹配写 warning. 永不抛异常."""
    if dll is None:
        dll = _get_dll()
    if dll is None:
        _log.debug("DLL 未加载, 跳过兼容性检查")
        return

    drv = get_driver_version(dll)
    sdk = _read_dll_version(dll)
    if not drv.get('available'):
        _log.warning("内核驱动版本不可用: %s (error_code=0x%X)",
                     drv.get('error_message', 'N/A'),
                     drv.get('error_code', 0))
        return
    if sdk is None:
        _log.debug("DLL 版本不可用, 跳过比对")
        return

    drv_mm = (drv['major'], drv['minor'])
    sdk_mm = (sdk['major'], sdk['minor'])
    if drv_mm != sdk_mm:
        _log.warning(
            "DLL/驱动 版本主次号不匹配: DLL=%d.%d.%d.%d 驱动=%d.%d.%d (%s); 建议升级到一致版本",
            sdk['major'], sdk['minor'], sdk['patch'], sdk['build'],
            drv['major'], drv['minor'], drv['build'], drv.get('driver_name', ''))
    else:
        _log.info(
            "DLL/驱动 版本兼容: DLL=%d.%d.%d.%d 驱动=%d.%d.%d (%s)",
            sdk['major'], sdk['minor'], sdk['patch'], sdk['build'],
            drv['major'], drv['minor'], drv['build'], drv.get('driver_name', ''))


__all__ = [
    "get_driver_version",
    "invalidate_driver_version_cache",
    "ensure_drivers_running",
    "log_compatibility",
]
