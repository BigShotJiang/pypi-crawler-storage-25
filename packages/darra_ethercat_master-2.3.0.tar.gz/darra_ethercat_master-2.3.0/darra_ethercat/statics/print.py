# -*- coding: utf-8 -*-
"""
枚举中文描述辅助函数
对应 C# Static/Print.cs
提供各种枚举类型的中文描述方法
"""

from ..data.types import (
    EcALState, MailboxError, MailboxType, SDOError, SoEError,
    EcPortType, EcTopologyType, EcPdiType, EcDeviceType,
    EcSyncManagerType, EcFmmuType, EcCoEDetails, EcEoEDetails,
    CoEObjectAccess, DcSyncMode, StartupTransition, StartupWriteTiming,
    EcStateFormat,
)
from ..utils.dll import EcState, EcLinkState


# ===================== EcState 描述 =====================

def describe_state(state: int) -> str:
    """获取 EtherCAT 状态中文描述"""
    base = state & 0x0F
    has_error = bool(state & 0x10)
    _names = {
        0x00: "None",
        0x01: "Init",
        0x02: "PreOp",
        0x03: "Boot",
        0x04: "SafeOp",
        0x08: "OP",
    }
    name = _names.get(base, f"0x{base:02X}")
    return f"{name}+Error" if has_error else name


# ===================== AL Status Code 描述 =====================
# 注: 本地 AL Status 中文表已移除 (原 64 条), 统一查询 Core.dll
# (ec_status_codes.h, ETG.1020 标准, VMP 保护). 旧 DLL 缺失时退化兜底.

import ctypes as _ctypes
from ..utils.dll import DarraCoreDLL as _DarraCoreDLL

_dll_singleton: 'object' = None


def _al_dll():
    """惰性加载单例 DLL; 失败返回 None."""
    global _dll_singleton
    if _dll_singleton is None:
        try:
            _dll_singleton = _DarraCoreDLL()
        except Exception:
            _dll_singleton = False  # 标记失败避免反复重试
    return _dll_singleton if _dll_singleton else None


def describe_al_status(code: int) -> str:
    """获取 AL Status Code 的中文描述 (来自 Core.dll, ETG.1020 标准)"""
    dll = _al_dll()
    if dll is not None:
        try:
            ptr = dll.AL_StatusCode_GetDescription(_ctypes.c_uint16(code & 0xFFFF))
            if ptr:
                raw = ptr if isinstance(ptr, bytes) else _ctypes.string_at(ptr)
                txt = raw.decode("utf-8", errors="replace")
                if txt:
                    return txt
        except Exception:
            pass
    if code >= 0x8000:
        return f"厂商特定错误 (0x{code:04X})"
    return f"未知错误 (0x{code:04X})"


# ===================== 链路状态描述 =====================

def describe_link_state(state: int) -> str:
    """获取链路状态中文描述"""
    _names = {
        0: "未连接",
        1: "已连接",
        3: "仅主网口",
        4: "仅副网口",
    }
    return _names.get(state, "未知")


# ===================== 对象访问权限描述 =====================

# ETG1000.6 Object Access 位定义
_ATYPE_RPRE = 0x01
_ATYPE_RSAFE = 0x02
_ATYPE_ROP = 0x04
_ATYPE_WPRE = 0x08
_ATYPE_WSAFE = 0x10
_ATYPE_WOP = 0x20


def describe_object_access(access: int) -> str:
    """
    获取对象访问权限的 RWRWRW 格式描述

    参数:
        access: 访问权限位

    返回:
        如 "RW_WR_" 格式字符串
    """
    parts = [
        "R" if access & _ATYPE_RPRE else "_",
        "W" if access & _ATYPE_WPRE else "_",
        "R" if access & _ATYPE_RSAFE else "_",
        "W" if access & _ATYPE_WSAFE else "_",
        "R" if access & _ATYPE_ROP else "_",
        "W" if access & _ATYPE_WOP else "_",
    ]
    return "".join(parts)


def describe_access_chinese(access: int) -> str:
    """获取对象访问权限的中文描述"""
    can_read = bool(access & (_ATYPE_RPRE | _ATYPE_RSAFE | _ATYPE_ROP))
    can_write = bool(access & (_ATYPE_WPRE | _ATYPE_WSAFE | _ATYPE_WOP))

    writable_states = []
    if access & _ATYPE_WPRE:
        writable_states.append("PreOP")
    if access & _ATYPE_WSAFE:
        writable_states.append("SafeOP")
    if access & _ATYPE_WOP:
        writable_states.append("OP")

    if can_read and can_write:
        return f"读写({','.join(writable_states)}可写)"
    elif can_read:
        return "只读"
    elif can_write:
        return f"只写({','.join(writable_states)}可写)"
    else:
        return "无权限"


# ===================== 启动转换描述 =====================

def describe_transition(transition: StartupTransition) -> str:
    """获取启动转换阶段中文描述"""
    _desc = {
        StartupTransition.IP: "I>P (Init->PreOp)",
        StartupTransition.PS: "P>S (PreOp->SafeOp)",
        StartupTransition.SO: "S>O (SafeOp->Op)",
        StartupTransition.OS: "O>S (Op->SafeOp)",
        StartupTransition.SP: "S>P (SafeOp->PreOp)",
        StartupTransition.PI: "P>I (PreOp->Init)",
    }
    return _desc.get(transition, str(transition))


# ===================== DC 同步模式描述 =====================

def describe_dc_mode(mode: DcSyncMode) -> str:
    """获取 DC 同步模式中文描述"""
    _desc = {
        DcSyncMode.FREE_RUN: "自由运行",
        DcSyncMode.SM_SYNCHRON: "SM 同步",
        DcSyncMode.DC_SYNCHRON: "DC 同步",
    }
    return _desc.get(mode, "未知")


# ===================== 冗余模式描述 =====================

_REDUNDANCY_NAMES = ["未激活", "双向冗余", "降级(仅primary)"]


def describe_redundancy_mode(mode: int) -> str:
    """获取冗余模式中文描述"""
    if 0 <= mode < len(_REDUNDANCY_NAMES):
        return _REDUNDANCY_NAMES[mode]
    return str(mode)


# ===================== AL Status Code 英文描述 =====================
# 注: 本地英文表已移除 (原 64 条). 当前 Core.dll AL_StatusCode_GetDescription
# 仅返回中文描述; 英文描述暂用代码点回退, 后续 DLL 加 GetDescriptionEn 再接入.


def describe_al_status_en(code: int) -> str:
    """获取 AL Status Code 的英文描述 (DLL 暂未导出英文表, 回退到代码点)"""
    if code >= 0x8000:
        return f"Vendor specific error (0x{code:04X})"
    return f"AL Status 0x{code:04X}"


def describe_al_status_full(code: int) -> str:
    """
    获取 AL Status Code 的完整描述 (中英文, 用于日志)
    格式: "中文描述 (English Description)"
    """
    cn = describe_al_status(code)
    en = describe_al_status_en(code)
    return f"{cn} ({en})"


# ===================== SDO 错误码英文描述 =====================

_SDO_ERROR_EN = {
    0x00000000: "No error",
    0x05030000: "Toggle bit not changed",
    0x05040000: "SDO protocol timeout",
    0x05040001: "Client/Server command specifier not valid or unknown",
    0x05040005: "Out of memory",
    0x06010000: "Unsupported access to an object",
    0x06010001: "Attempt to read to a write only object",
    0x06010002: "Attempt to write to a read only object",
    0x06010003: "Subindex can not be written, SI0 must be 0 for write access",
    0x06010004: "SDO Complete access not supported for variable length objects",
    0x06010005: "Object length exceeds mailbox size",
    0x06010006: "Object mapped to RxPDO, SDO download blocked",
    0x06020000: "The object does not exist in the object directory",
    0x06040041: "The object can not be mapped into the PDO",
    0x06040042: "The number and length of the objects to be mapped would exceed the PDO length",
    0x06040043: "General parameter incompatibility reason",
    0x06040047: "General internal incompatibility in the device",
    0x06060000: "Access failed due to a hardware error",
    0x06070010: "Data type does not match, length of service parameter does not match",
    0x06070012: "Data type does not match, length of service parameter too high",
    0x06070013: "Data type does not match, length of service parameter too low",
    0x06090011: "Subindex does not exist",
    0x06090030: "Value range of parameter exceeded (only for write access)",
    0x06090031: "Value of parameter written too high",
    0x06090032: "Value of parameter written too low",
    0x06090033: "Configured module list does not match detected module list",
    0x06090036: "Maximum value is less than minimum value",
    0x08000000: "General error",
    0x08000020: "Data cannot be transferred or stored to the application",
    0x08000021: "Data cannot be transferred or stored to the application because of local control",
    0x08000022: "Data cannot be transferred or stored to the application because of the present device state",
    0x08000023: "Object dictionary dynamic generation fails or no object dictionary is present",
    0xFFFFFFFF: "Unknown",
}


def describe_sdo_error(code: int) -> str:
    """获取 SDO 错误码英文描述"""
    return _SDO_ERROR_EN.get(code, f"Unknown (0x{code:08X})")


# ===================== SoE 错误码英文描述 =====================

_SOE_ERROR_EN = {
    0x0000: "No error",
    0x1001: "No IDN",
    0x1009: "Invalid access to element 1",
    0x2001: "No Name",
    0x2002: "Name transmission too short",
    0x2003: "Name transmission too long",
    0x2004: "Name cannot be changed (read only)",
    0x2005: "Name is write-protected at this time",
    0x3002: "Attribute transmission too short",
    0x3003: "Attribute transmission too long",
    0x3004: "Attribute cannot be changed (read only)",
    0x3005: "Attribute is write-protected at this time",
    0x4001: "No units",
    0x4002: "Unit transmission too short",
    0x4003: "Unit transmission too long",
    0x4004: "Unit cannot be changed (read only)",
    0x4005: "Unit is write-protected at this time",
    0x5001: "No minimum input value",
    0x5002: "Minimum input value transmission too short",
    0x5003: "Minimum input value transmission too long",
    0x5004: "Minimum input value cannot be changed (read only)",
    0x5005: "Minimum input value is write-protected at this time",
    0x6001: "No maximum input value",
    0x6002: "Maximum input value transmission too short",
    0x6003: "Maximum input value transmission too long",
    0x6004: "Maximum input value cannot be changed (read only)",
    0x6005: "Maximum input value is write-protected at this time",
    0x7002: "Operation data transmission too short",
    0x7003: "Operation data transmission too long",
    0x7004: "Operation data cannot be changed (read only)",
    0x7005: "Operation data is write-protected at this time (state)",
    0x7006: "Operation data is smaller than the minimum input value",
    0x7007: "Operation data is smaller than the maximum input value",
    0x7008: "Invalid operation data:Configured IDN will not be supported",
    0x7009: "Operation data write protected by a password",
    0x700A: "Operation data is write protected, it is configured cyclically",
    0x700B: "Invalid indirect addressing",
    0x700C: "Operation data is write protected, due to other settings",
    0x700D: "Reserved",
    0x7010: "Procedure command already active",
    0x7011: "Procedure command not interruptible",
    0x7012: "Procedure command at this time not executable (state)",
    0x7013: "Procedure command not executable (invalid or false parameters)",
    0x7014: "No data state",
    0x8001: "No default value",
    0x8002: "Default value transmission too long",
    0x8004: "Default value cannot be changed, read only",
    0x800A: "Invalid drive number",
    0x800B: "General error",
    0x800C: "No element addressed",
    0xFFFF: "Unknown",
}


def describe_soe_error(code: int) -> str:
    """获取 SoE 错误码英文描述"""
    return _SOE_ERROR_EN.get(code, f"Unknown (0x{code:04X})")


# ===================== 邮箱错误码英文描述 =====================

_MBX_ERROR_EN = {
    0x0000: "No error",
    0x0001: "Syntax of 6 octet Mailbox Header is wrong",
    0x0002: "The mailbox protocol is not supported",
    0x0003: "Channel Field contains wrong value",
    0x0004: "The service is not supported",
    0x0005: "Invalid mailbox header",
    0x0006: "Length of received mailbox data is too short",
    0x0007: "No more memory in slave",
    0x0008: "The length of data is inconsistent",
    0xFFFF: "Unknown",
}


def describe_mailbox_error(code: int) -> str:
    """获取邮箱错误码英文描述"""
    return _MBX_ERROR_EN.get(code, f"Unknown (0x{code:04X})")


# ===================== 邮箱类型描述 =====================

_MBX_TYPE_EN = {
    0x00: "Error type",
    0x01: "ADS over EtherCAT",
    0x02: "Ethernet over EtherCAT",
    0x03: "CANopen over EtherCAT",
    0x04: "File over EtherCAT",
    0x05: "Servo over EtherCAT",
    0x0F: "Vendor over EtherCAT",
}


def describe_mailbox_type(mbx_type: int) -> str:
    """获取邮箱类型描述"""
    return _MBX_TYPE_EN.get(mbx_type, "Unknown")


# ===================== EtherCAT 数据类型描述 =====================

_EC_DATA_TYPE_NAMES = {
    0x0001: "Boolean",
    0x0002: "Integer8",
    0x0003: "Integer16",
    0x0004: "Integer32",
    0x0005: "Unsigned8",
    0x0006: "Unsigned16",
    0x0007: "Unsigned32",
    0x0008: "Real32",
    0x0009: "VisibleString",
    0x000A: "OctetString",
    0x000B: "UnicodeString",
    0x000C: "TimeOfDay",
    0x000D: "TimeDifference",
    0x000F: "Domain",
    0x0010: "Integer24",
    0x0011: "Real64",
    0x0012: "Integer40",
    0x0013: "Integer48",
    0x0014: "Integer56",
    0x0015: "Integer64",
    0x0016: "Unsigned24",
    0x0018: "Unsigned40",
    0x0019: "Unsigned48",
    0x001A: "Unsigned56",
    0x001B: "Unsigned64",
    0x0030: "Bit1",
    0x0031: "Bit2",
    0x0032: "Bit3",
    0x0033: "Bit4",
    0x0034: "Bit5",
    0x0035: "Bit6",
    0x0036: "Bit7",
    0x0037: "Bit8",
}


def describe_data_type(dtype: int) -> str:
    """获取 EtherCAT 数据类型描述"""
    return _EC_DATA_TYPE_NAMES.get(dtype, f"Unknown (0x{dtype:04X})")


_EC_DATA_TYPE_COMMON = {
    0x0001: "bool",
    0x0002: "int8",
    0x0003: "int16",
    0x0004: "int32",
    0x0005: "uint8",
    0x0006: "uint16",
    0x0007: "uint32",
    0x0008: "float",
    0x0009: "string",
    0x000A: "byte[]",
    0x000B: "string",
    0x000C: "datetime",
    0x000D: "timespan",
    0x000F: "byte[]",
    0x0010: "int24",
    0x0011: "double",
    0x0012: "int40",
    0x0013: "int48",
    0x0014: "int56",
    0x0015: "int64",
    0x0016: "uint24",
    0x0018: "uint40",
    0x0019: "uint48",
    0x001A: "uint56",
    0x001B: "uint64",
    0x0030: "bit1",
    0x0031: "bit2",
    0x0032: "bit3",
    0x0033: "bit4",
    0x0034: "bit5",
    0x0035: "bit6",
    0x0036: "bit7",
    0x0037: "bit8",
}


def describe_data_type_common(dtype: int) -> str:
    """获取常用的数据类型名称（用于UI显示）"""
    return _EC_DATA_TYPE_COMMON.get(dtype, describe_data_type(dtype))


# ===================== 写入条件描述 =====================

def describe_write_condition(access: int) -> str:
    """
    获取写入条件的详细描述（用于编辑对话框）
    返回: "写入条件: SafeOP"、"写入条件: SafeOP/OP" 等

    参数:
        access: 访问权限位
    """
    conditions = []
    if access & _ATYPE_WPRE:
        conditions.append("PreOP")
    if access & _ATYPE_WSAFE:
        conditions.append("SafeOP")
    if access & _ATYPE_WOP:
        conditions.append("OP")
    if not conditions:
        return "不可写入"
    return "写入条件: " + "/".join(conditions)


# ===================== 根据当前状态获取访问权限描述 =====================

def describe_access_with_state(access: int, current_state: int) -> str:
    """
    根据当前状态获取访问权限描述（用于表格显示）

    参数:
        access: 访问权限位
        current_state: 当前从站状态 (EcState 值)

    返回:
        "读写"、"只读"、"只读(SafeOP,OP可写)" 等
    """
    can_read = bool(access & (_ATYPE_RPRE | _ATYPE_RSAFE | _ATYPE_ROP))
    can_write = bool(access & (_ATYPE_WPRE | _ATYPE_WSAFE | _ATYPE_WOP))

    writable_states = []
    if access & _ATYPE_WPRE:
        writable_states.append("PreOP")
    if access & _ATYPE_WSAFE:
        writable_states.append("SafeOP")
    if access & _ATYPE_WOP:
        writable_states.append("OP")

    # 检查当前状态下是否可写
    can_write_now = False
    if can_write:
        base = current_state & 0x0F
        if base == 0x02:  # PreOp
            can_write_now = bool(access & _ATYPE_WPRE)
        elif base == 0x04:  # SafeOp
            can_write_now = bool(access & (_ATYPE_WPRE | _ATYPE_WSAFE))
        elif base == 0x08:  # OP
            can_write_now = bool(access & (_ATYPE_WPRE | _ATYPE_WSAFE | _ATYPE_WOP))

    if can_read and can_write:
        if can_write_now:
            return "读写"
        elif writable_states:
            return f"只读({','.join(writable_states)}可写)"
        else:
            return "只读"
    elif can_read:
        return "只读"
    elif can_write:
        if can_write_now:
            return "只写"
        else:
            return f"只写({','.join(writable_states)}可写)"
    else:
        return "无权限"


# ===================== 链路状态英文描述 =====================

def describe_link_state_en(state: int) -> str:
    """获取链路状态英文描述"""
    _names = {
        0: "Disconnected",
        1: "Connected",
        3: "Primary Only",
        4: "Secondary Only",
    }
    return _names.get(state, "Unknown")


# ===================== FSoE 状态描述 =====================

_FSOE_STATE_CN = {
    0x100: "初始/重置状态",
    0x101: "会话建立",
    0x102: "连接建立",
    0x103: "参数下载",
    0x104: "数据交换",
    0x105: "失效安全",
}

_FSOE_STATE_EN = {
    0x100: "Reset",
    0x101: "Session",
    0x102: "Connection",
    0x103: "Parameter",
    0x104: "Data",
    0x105: "Failsafe",
}


def describe_fsoe_state(state: int) -> str:
    """获取 FSoE 状态中文描述"""
    return _FSOE_STATE_CN.get(state, f"未知状态 (0x{state:04X})")


def describe_fsoe_state_en(state: int) -> str:
    """获取 FSoE 状态英文描述"""
    return _FSOE_STATE_EN.get(state, f"Unknown (0x{state:04X})")


# ===================== FSoE 错误描述 =====================

_FSOE_ERROR_CN = {
    0x0000: "无错误",
    0x0001: "错误的命令",
    0x0002: "未知命令",
    0x0003: "连接ID不匹配",
    0x0004: "CRC校验失败",
    0x0005: "看门狗超时",
    0x0006: "错误的FSoE地址",
    0x0007: "无效数据",
    0x0008: "通信参数长度错误",
    0x0009: "通信参数错误",
    0x000A: "应用参数长度错误",
    0x000B: "应用参数错误",
    0x000C: "意外的会话命令",
    0x000D: "收到失效安全数据",
    0x0100: "FSoE未初始化",
    0x0101: "达到最大连接数",
    0x0102: "无效状态转换",
}

_FSOE_ERROR_EN = {
    0x0000: "No error",
    0x0001: "Wrong command",
    0x0002: "Unknown command",
    0x0003: "Wrong connection ID",
    0x0004: "CRC error",
    0x0005: "Watchdog timeout",
    0x0006: "Wrong FSoE address",
    0x0007: "Wrong data",
    0x0008: "Communication parameter length error",
    0x0009: "Communication parameter error",
    0x000A: "Application parameter length error",
    0x000B: "Application parameter error",
    0x000C: "Unexpected session command",
    0x000D: "Failsafe data received",
    0x0100: "FSoE not initialized",
    0x0101: "Maximum connections reached",
    0x0102: "Invalid state transition",
}


def describe_fsoe_error(error: int) -> str:
    """获取 FSoE 错误中文描述"""
    return _FSOE_ERROR_CN.get(error, f"未知错误 (0x{error:04X})")


def describe_fsoe_error_en(error: int) -> str:
    """获取 FSoE 错误英文描述"""
    return _FSOE_ERROR_EN.get(error, f"Unknown (0x{error:04X})")
