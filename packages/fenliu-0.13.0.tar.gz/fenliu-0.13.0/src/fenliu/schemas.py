"""Pydantic schemas for API validation and serialization."""

from __future__ import annotations

import re
from datetime import datetime

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field
from pydantic import field_validator

from fenliu.custom_types import MediaAttachmentDict
from fenliu.models import INT_TO_DAY_OF_WEEK
from fenliu.models import DayOfWeek

# MM-DD pattern for topical_month_day validation
_MONTH_DAY_RE = re.compile(r"^\d{2}-\d{2}$")
_MAX_MONTH = 12
_MAX_DAY = 31


def _validate_month_day(v: str | None) -> str | None:
    """Validate and normalise a MM-DD string."""
    if v is None:
        return None
    if not _MONTH_DAY_RE.match(v):
        msg = "topical_month_day must be in MM-DD format"
        raise ValueError(msg)
    month, day = int(v[:2]), int(v[3:])
    if not (1 <= month <= _MAX_MONTH and 1 <= day <= _MAX_DAY):
        msg = "topical_month_day contains an invalid month or day"
        raise ValueError(msg)
    return v


def _day_of_week_from_db(v: int | str | DayOfWeek | None) -> DayOfWeek | None:
    """Coerce an int (from DB) or string to DayOfWeek, or pass None through."""
    if v is None:
        return None
    if isinstance(v, int):
        if v not in INT_TO_DAY_OF_WEEK:
            msg = f"Invalid weekday integer: {v}"
            raise ValueError(msg)
        return INT_TO_DAY_OF_WEEK[v]
    return DayOfWeek(v)  # raises ValueError for unknown strings


class HashtagStreamBase(BaseModel):
    """Base schema for hashtag streams."""

    hashtag: str = Field(..., min_length=1, max_length=100, description="Hashtag to monitor (without #)")
    instance: str = Field(default="mastodon.social", max_length=200, description="Fediverse instance")
    active: bool = Field(default=True, description="Whether the stream is active")


class HashtagStreamCreate(HashtagStreamBase):
    """Schema for creating a new hashtag stream."""

    pass


class HashtagStreamUpdate(BaseModel):
    """Schema for updating a hashtag stream."""

    active: bool | None = None
    instance: str | None = Field(None, max_length=200)


class StreamSchedule(BaseModel):
    """Schema for stream scheduling configuration."""

    stream_id: int
    hashtag: str
    enable_scheduling: bool = Field(default=True, description="Whether scheduling is enabled")
    fetch_interval_minutes: int = Field(default=60, ge=5, le=1440, description="Minutes between fetches (5-1440)")
    next_scheduled_fetch: datetime | None = Field(None, description="Next scheduled fetch time")
    last_check: datetime | None = Field(None, description="Last time posts were fetched")

    model_config = ConfigDict(from_attributes=True)


class HashtagStreamResponse(HashtagStreamBase):
    """Schema for hashtag stream response."""

    id: int
    last_check: datetime | None = None
    created_at: datetime
    updated_at: datetime | None = None
    enable_scheduling: bool = Field(default=True, description="Whether scheduling is enabled")
    fetch_interval_minutes: int = Field(default=60, description="Minutes between fetches")
    next_scheduled_fetch: datetime | None = Field(None, description="Next scheduled fetch time")

    model_config = ConfigDict(from_attributes=True)


class PostBase(BaseModel):
    """Base schema for posts."""

    post_id: str = Field(..., max_length=100, description="Unique post identifier")
    content: str = Field(..., description="Post content")
    author_username: str | None = Field(None, max_length=100)
    author_display_name: str | None = Field(None, max_length=200)
    author_url: str | None = Field(None, max_length=500)
    instance: str = Field(..., max_length=200, description="Source instance")
    hashtags: list[str] | None = None
    media_attachments: list[MediaAttachmentDict] | None = None
    boosts: int = Field(default=0, ge=0)
    likes: int = Field(default=0, ge=0)
    replies: int = Field(default=0, ge=0)
    url: str | None = Field(None, max_length=500)
    created_at: datetime | None = None
    spam_score: int = Field(default=0, ge=0, le=100, description="Spam score (0-100)")


class PostCreate(PostBase):
    """Schema for creating a new post."""

    stream_id: int = Field(..., description="Associated hashtag stream ID")


class PostUpdate(BaseModel):
    """Schema for updating a post."""

    processed: bool | None = None
    spam_score: int | None = Field(None, ge=0, le=100)
    manual_spam_score: int | None = Field(None, ge=0, le=100, description="Manually adjusted spam score (0-100)")
    approved: bool | None = Field(None, description="True = approved, False = rejected, None = not reviewed")
    reviewer_notes: str | None = Field(None, max_length=1000, description="Notes from human reviewer")
    curated_exported: bool | None = Field(None, description="Whether exported to curated queue")


class PostResponse(PostBase):
    """Schema for post response."""

    id: int
    stream_id: int | None = None
    fetched_at: datetime
    processed: bool
    reviewed: bool = False
    reviewed_at: datetime | None = None
    reviewer_notes: str | None = None
    manual_spam_score: int | None = Field(None, ge=0, le=100, description="Manually adjusted spam score (0-100)")
    approved: bool | None = Field(None, description="True = approved, False = rejected, None = not reviewed")
    curated_exported: bool = False
    export_date: datetime | None = None
    training_data: bool = False
    queue_status: str | None = Field(None, description="Curated queue status: pending, reserved, delivered, error")

    model_config = ConfigDict(from_attributes=True)


class BlockedUserCreate(BaseModel):
    """Schema for adding a user to the blocklist."""

    account_identifier: str = Field(
        ...,
        min_length=1,
        max_length=500,
        description="Fediverse account identifier or pattern, e.g. @user@instance.social or *.bsky.app",
    )
    pattern_type: str = Field(default="exact", description="Pattern matching type: exact, suffix, prefix, contains")
    notes: str | None = Field(None, max_length=1000)


class BlockedUserResponse(BaseModel):
    """Schema for blocked user response."""

    id: int
    account_identifier: str
    pattern_type: str
    notes: str | None = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class BlockedHashtagCreate(BaseModel):
    """Schema for adding a hashtag to the blocklist."""

    hashtag: str = Field(..., min_length=1, max_length=100, description="Hashtag to block (with or without leading #)")
    notes: str | None = Field(None, max_length=1000)


class BlockedHashtagResponse(BaseModel):
    """Schema for blocked hashtag response."""

    id: int
    hashtag: str
    notes: str | None = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class ReblogSettingsUpdate(BaseModel):
    """Schema for updating global reblog export settings."""

    attachments_only: bool = Field(..., description="When true, only posts with media attachments are export-eligible")
    auto_reject_on_fetch: bool = Field(
        ..., description="When true, posts matching any reblog-control filter are automatically rejected on fetch"
    )
    auto_reject_bots: bool = Field(..., description="When true, posts from bot accounts are automatically rejected")
    require_alt_text: bool = Field(
        ..., description="When true, posts with attachments lacking alt text are ineligible for export"
    )


class ReblogSettingsResponse(BaseModel):
    """Schema for global reblog export settings response."""

    attachments_only: bool
    auto_reject_on_fetch: bool = False
    auto_reject_bots: bool = False
    require_alt_text: bool = False


class StatsResponse(BaseModel):
    """Schema for application statistics."""

    total_streams: int
    active_streams: int
    total_posts: int
    processed_posts: int
    average_spam_score: float | None = None


class FetchResponse(BaseModel):
    """Schema for fetch operation response."""

    stream_id: int
    hashtag: str
    posts_fetched: int
    posts_saved: int
    success: bool
    error_message: str | None = None


class CuratedNextResponse(BaseModel):
    """Schema for the Curated /next queue response."""

    fenliu_post_id: int
    post_uri: str
    post_url: str | None = None
    author_account: str
    content_snippet: str
    hashtags: list[str]
    stream: str | None = None
    has_attachments: bool
    spam_score: int
    post_created_at: datetime | None = None
    approved_at: datetime | None = None
    is_topical: bool = False


class TopicalHashtagCreate(BaseModel):
    """Schema for creating a standalone topical hashtag rule."""

    hashtag: str = Field(..., min_length=1, max_length=100, description="Hashtag (without #)")
    topical_day_of_week: DayOfWeek | None = Field(None, description="Day of week this hashtag is topical")
    topical_month_day: str | None = Field(None, description="Calendar date MM-DD this hashtag is topical")

    @field_validator("topical_day_of_week", mode="before")
    @classmethod
    def _coerce_topical_dow(cls, v: int | str | DayOfWeek | None) -> DayOfWeek | None:
        return _day_of_week_from_db(v)

    @field_validator("topical_month_day", mode="before")
    @classmethod
    def _validate_topical_md(cls, v: str | None) -> str | None:
        return _validate_month_day(v)


class TopicalHashtagUpdate(BaseModel):
    """Schema for updating a standalone topical hashtag rule."""

    topical_day_of_week: DayOfWeek | None = Field(None, description="Day of week this hashtag is topical")
    topical_month_day: str | None = Field(None, description="Calendar date MM-DD this hashtag is topical")

    @field_validator("topical_day_of_week", mode="before")
    @classmethod
    def _coerce_topical_dow(cls, v: int | str | DayOfWeek | None) -> DayOfWeek | None:
        return _day_of_week_from_db(v)

    @field_validator("topical_month_day", mode="before")
    @classmethod
    def _validate_topical_md(cls, v: str | None) -> str | None:
        return _validate_month_day(v)


class TopicalHashtagResponse(BaseModel):
    """Schema for topical hashtag response."""

    id: int
    hashtag: str
    topical_day_of_week: DayOfWeek | None = None
    topical_month_day: str | None = None
    created_at: datetime

    @field_validator("topical_day_of_week", mode="before")
    @classmethod
    def _coerce_topical_dow(cls, v: int | str | DayOfWeek | None) -> DayOfWeek | None:
        return _day_of_week_from_db(v)

    model_config = ConfigDict(from_attributes=True)


class CuratedErrorRequest(BaseModel):
    """Schema for the Curated /error request body."""

    reason: str = Field(..., min_length=1, max_length=1000, description="Reason for the permanent failure")
