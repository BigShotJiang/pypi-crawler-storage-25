"""Template helper functions for generating common HTML components."""

from pathlib import Path

from jinja2 import Environment
from jinja2 import FileSystemLoader

from fenliu.config import settings

_templates_dir = Path(__file__).parent.parent / "templates"
_env = Environment(loader=FileSystemLoader(str(_templates_dir)), autoescape=True)


def generate_header(current_page: str) -> str:
    """Generate the common header/navigation HTML for all pages.

    Renders the shared ``partials/header.html`` Jinja2 macro so that the
    review LiveView (which cannot use Jinja2 template responses directly)
    produces identical navigation to every other page.

    Args:
        current_page: The current page identifier, e.g. ``"review"``,
                      ``"dashboard"``, ``"streams"``, ``"stats"``,
                      ``"queue"``, ``"settings"``.

    Returns:
        HTML string for the header/navigation.

    """
    template = _env.get_template("partials/header.html")
    module = template.make_module(
        vars={
            "app_name": settings.app_name,
            "app_version": settings.app_version,
        }
    )
    return module.header(current_page)  # ty: ignore[unresolved-attribute]
