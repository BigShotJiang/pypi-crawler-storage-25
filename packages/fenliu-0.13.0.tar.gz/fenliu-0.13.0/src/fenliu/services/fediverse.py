"""Fediverse client service for fetching hashtag timelines."""

import asyncio
from datetime import UTC
from datetime import datetime
from typing import Any

import httpx
import stamina
from longwei import APClient
from longwei import NetworkError
from longwei import RatelimitError
from longwei import ServerError
from longwei.models import Status

from fenliu.config import settings
from fenliu.custom_types import MediaAttachmentDict
from fenliu.logging import get_logger

logger = get_logger(__name__)


class FediverseClient:
    """Client for interacting with Fediverse instances."""

    def __init__(self, instance: str | None = None) -> None:
        """Initialize Fediverse client.

        Args:
            instance: Fediverse instance domain (e.g., "mastodon.social").
                      Uses default from settings if not provided.

        """
        self.instance = instance or settings.default_instance
        logger.debug(f"FediverseClient.__init__: instance={self.instance}")

        httpx_client = httpx.AsyncClient(timeout=settings.api_timeout)
        self.client = APClient(instance=self.instance, client=httpx_client)
        self._rate_limit_delay = settings.rate_limit_delay
        self._initialized = False
        logger.debug(f"FediverseClient.__init__: client initialized with timeout={settings.api_timeout}")

    async def _ensure_initialized(self) -> None:
        """Ensure the ActivityPub client is initialized."""
        if not self._initialized:
            logger.debug(f"FediverseClient._ensure_initialized: determining instance type for {self.instance}")
            await self.client.determine_instance_type()
            self._initialized = True
            logger.debug("FediverseClient._ensure_initialized: instance type determined")

    async def close(self) -> None:
        """Close the HTTP client."""
        logger.debug("FediverseClient.close: closing HTTP client")
        await self.client.client.aclose()
        logger.debug("FediverseClient.close: HTTP client closed")

    async def fetch_hashtag_timeline(
        self,
        hashtag: str,
        limit: int = 20,
        min_id: str | None = None,
        max_id: str | None = None,
    ) -> list[Status]:
        """Fetch posts for a specific hashtag.

        Args:
            hashtag: Hashtag to fetch (without #).
            limit: Maximum number of posts to fetch.
            min_id: Return results newer than this ID.
            max_id: Return results older than this ID.

        Returns:
            List of post dictionaries.

        """
        try:
            # Ensure client is initialized
            await self._ensure_initialized()

            # Clean hashtag (remove # if present)
            hashtag = hashtag.lstrip("#").strip()
            logger.debug(f"FediverseClient.fetch_hashtag_timeline: cleaned hashtag={hashtag}")
            if not hashtag:
                logger.warning("Empty hashtag provided")
                return []

            logger.info(f"Fetching #{hashtag} from {self.instance} (limit: {limit})")
            logger.debug(f"FediverseClient.fetch_hashtag_timeline: min_id={min_id}, max_id={max_id}")

            # Apply rate limiting delay
            if self._rate_limit_delay > 0:
                logger.debug(
                    f"FediverseClient.fetch_hashtag_timeline: applying rate limit delay={self._rate_limit_delay}s"
                )
                await asyncio.sleep(self._rate_limit_delay)

            # Fetch posts from Fediverse (with retry on transient errors)
            try:
                posts = await self._fetch_timeline(hashtag, limit, min_id, max_id)
            except RatelimitError:
                wait_seconds = max(0.0, (self.client.ratelimit_reset - datetime.now(UTC)).total_seconds())
                logger.warning(
                    f"Rate limited by {self.instance}; "
                    f"waiting {wait_seconds:.0f}s until {self.client.ratelimit_reset.isoformat()}"
                )
                await asyncio.sleep(wait_seconds)
                posts = await self._fetch_timeline(hashtag, limit, min_id, max_id)

            logger.info(f"Fetched {len(posts)} posts for #{hashtag} from {self.instance}")
            return posts

        except Exception as e:
            logger.error(f"Error fetching #{hashtag} from {self.instance}: {e}")
            return []

    @stamina.retry(
        on=(NetworkError, ServerError),
        attempts=3,
        wait_initial=1.0,
        wait_max=60.0,
    )
    async def _fetch_timeline(
        self,
        hashtag: str,
        limit: int,
        min_id: str | None,
        max_id: str | None,
    ) -> list[Status]:
        """Fetch hashtag timeline with retry on transient errors."""
        return await self.client.get_hashtag_timeline(
            hashtag=hashtag,
            limit=limit,
            min_id=min_id,
            max_id=max_id,
        )

    def _parse_created_at(self, created_at: Any) -> datetime | None:
        """Parse created_at timestamp from Fediverse post.

        Args:
            created_at: Raw created_at value from API.

        Returns:
            Parsed datetime or None if parsing fails.

        """
        if isinstance(created_at, str):
            try:
                return datetime.fromisoformat(created_at.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                return None
        return None

    def _extract_author_info(self, status: Status) -> dict[str, Any]:
        """Extract author information from Fediverse post.

        Args:
            status: Status object from longwei.

        Returns:
            Dictionary with author information.

        """
        account = status.account
        return {
            "author_username": (account.username or "") if account else "",
            "author_acct": (account.acct or "") if account else "",
            "author_display_name": (account.display_name or "") if account else "",
            "author_url": (account.url or "") if account else "",
            "author_is_bot": (account.bot or False) if account else False,
        }

    def _extract_hashtags(self, status: Status) -> list[str]:
        """Extract hashtags from Fediverse post.

        Args:
            status: Status object from longwei.

        Returns:
            List of hashtags.

        """
        return [tag.name for tag in (status.tags or []) if tag.name]

    def _extract_media_attachments(self, status: Status) -> list[MediaAttachmentDict]:
        """Extract media attachments from Fediverse post.

        Args:
            status: Status object from longwei.

        Returns:
            List of media attachment dictionaries.

        """
        media_attachments = []
        for media in status.media_attachments or []:
            media_url = media.url or media.remote_url or media.preview_url
            if not media_url:
                continue
            media_attachments.append(
                {
                    "type": media.type or "unknown",
                    "url": media_url,
                    "description": media.description or "",
                    "preview_url": media.preview_url or media_url,
                }
            )
        return media_attachments

    def _build_post_data_dict(  # noqa: PLR0913
        self,
        post_id: str,
        content: str,
        created_at: datetime | None,
        author_info: dict[str, Any],
        hashtags: list[str],
        boosts: int,
        likes: int,
        replies: int,
        url: str,
        media_attachments: list[MediaAttachmentDict],
        raw_post: dict[str, Any],
    ) -> dict[str, Any]:
        """Build post data dictionary from extracted components.

        Note: This function has many parameters because it consolidates all extracted
        post data from the Fediverse API into a single dictionary format.
        This is intentional and necessary for data transformation.


        Args:
            post_id: Post identifier.
            content: Post content.
            created_at: Post creation timestamp.
            author_info: Dictionary with author information.
            hashtags: List of hashtags.
            boosts: Number of boosts/reblogs.
            likes: Number of likes/favorites.
            replies: Number of replies.
            url: Post URL.
            media_attachments: List of media attachments.
            raw_post: Raw post data from API.

        Returns:
            Dictionary with extracted post data.

        """
        return {
            "post_id": post_id,
            "content": content,
            "author_username": author_info["author_username"],
            "author_acct": author_info["author_acct"],
            "author_display_name": author_info["author_display_name"],
            "author_url": author_info["author_url"],
            "author_is_bot": author_info["author_is_bot"],
            "hashtags": hashtags,
            "boosts": boosts,
            "likes": likes,
            "replies": replies,
            "url": url,
            "created_at": created_at,
            "media_attachments": media_attachments,
            "raw_data": raw_post,  # Keep raw data for debugging
        }

    def extract_post_data(self, status: Status) -> dict[str, Any]:
        """Extract relevant data from a Fediverse post.

        Args:
            status: Status object from longwei.

        Returns:
            Dictionary with extracted post data.

        """
        try:
            return self._build_post_data_dict(
                post_id=status.id or "",
                content=status.content or "",
                created_at=self._parse_created_at(status.created_at),
                author_info=self._extract_author_info(status),
                hashtags=self._extract_hashtags(status),
                boosts=status.reblogs_count or 0,
                likes=status.favourites_count or 0,
                replies=status.replies_count or 0,
                url=status.url or "",
                media_attachments=self._extract_media_attachments(status),
                raw_post=status.model_dump(),
            )

        except Exception as e:
            logger.error(f"Error extracting post data: {e}")
            return {}

    async def fetch_and_process_hashtag(
        self,
        hashtag: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Fetch and process posts for a hashtag.

        Args:
            hashtag: Hashtag to fetch (without #).
            limit: Maximum number of posts to fetch.

        Returns:
            List of processed post data.

        """
        statuses = await self.fetch_hashtag_timeline(hashtag, limit)
        processed_posts = []

        for status in statuses:
            post_data = self.extract_post_data(status)
            if post_data:  # Only include successfully processed posts
                processed_posts.append(post_data)

        logger.info(f"Processed {len(processed_posts)} posts for #{hashtag}")
        return processed_posts


async def test_fediverse_connection() -> bool:
    """Test connection to default Fediverse instance.

    Returns:
        True if connection successful, False otherwise.

    """
    client = None
    try:
        client = FediverseClient()
        # Try to fetch a common hashtag
        posts = await client.fetch_hashtag_timeline("test", limit=1)
        return len(posts) >= 0  # Even empty response means API is reachable
    except Exception as e:
        logger.error(f"Fediverse connection test failed: {e}")
        return False
    finally:
        if client:
            await client.close()
