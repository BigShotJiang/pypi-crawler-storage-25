"""CLI entry points for the ML training pipeline."""

from __future__ import annotations

import argparse
import sys
from collections.abc import Generator
from contextlib import contextmanager

import pandas as pd
from sklearn.model_selection import train_test_split
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.orm import sessionmaker

from fenliu.database import get_db
from fenliu.training.data import export_to_csv
from fenliu.training.data import load_feedback
from fenliu.training.features import fit_pipeline
from fenliu.training.features import get_labels
from fenliu.training.features import transform
from fenliu.training.model import save_artifacts
from fenliu.training.model import train
from fenliu.training.validation import baseline_accuracy
from fenliu.training.validation import cross_validate_report
from fenliu.training.validation import evaluate
from fenliu.training.validation import print_feature_importance

MIN_ROWS: int = 50
ML_CONFIDENCE_THRESHOLD: float = 0.5


@contextmanager
def _open_db(db_path: str | None) -> Generator[Session, None, None]:
    """Open a database session, optionally against an alternate SQLite file."""
    if db_path is None:
        with get_db() as db:
            yield db
        return
    url = db_path if db_path.startswith("sqlite") else f"sqlite:///{db_path}"
    engine = create_engine(url, connect_args={"check_same_thread": False})
    _Session = sessionmaker(bind=engine, autocommit=False, autoflush=False)
    db = _Session()
    try:
        yield db
    finally:
        db.close()
        engine.dispose()


def _cmd_validate(df: pd.DataFrame) -> None:
    """Cross-validate and print comparison against spam_score baseline."""
    pipeline = fit_pipeline(df)
    X = transform(df, pipeline)
    y = get_labels(df)

    baseline = baseline_accuracy(df)
    print(f"\nBaseline (spam_score ≤{baseline['best_threshold']:>3}):  accuracy={baseline['best_accuracy']:.3f}")

    cv_result = cross_validate_report(X, y)
    print(
        f"XGBoost (cross-validated {len(cv_result['scores'])}-fold):  "
        f"accuracy={cv_result['mean_accuracy']:.3f}"
        f"  ±{cv_result['std_accuracy']:.3f}"
    )

    model = train(X, y)
    print_feature_importance(model, pipeline.feature_names)


def _cmd_fit(df: pd.DataFrame, output_dir: str) -> None:
    """Train model on 80/20 split and save artifacts."""
    pipeline = fit_pipeline(df)
    X = transform(df, pipeline)
    y = get_labels(df)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    model = train(X_train, y_train)
    metrics = evaluate(model, X_test, y_test)
    baseline = baseline_accuracy(df)

    metadata = {
        "n_samples": len(df),
        "n_features": X.shape[1],
        "test_accuracy": metrics["accuracy"],
        "test_f1": metrics["f1"],
        "baseline_accuracy": baseline["best_accuracy"],
        "n_approved": int((y == 1).sum()),
        "n_rejected": int((y == 0).sum()),
    }

    save_artifacts(model, pipeline, metadata, output_dir)

    print(f"\nModel trained on {len(df):,} samples.")
    print(f"Test accuracy:      {metrics['accuracy']:.3f}")
    print(f"Test F1:            {metrics['f1']:.3f}")
    print(f"Baseline accuracy:  {baseline['best_accuracy']:.3f}")
    print(f"Artifacts saved to: {output_dir}")


def _cmd_predict(df: pd.DataFrame, output: str) -> None:
    """Generate per-post ML confidence vs spam_score CSV."""
    pipeline = fit_pipeline(df)
    X = transform(df, pipeline)
    y = get_labels(df)

    model = train(X, y)
    confidence = model.predict_proba(X)[:, 1]
    ml_predicted_approved = confidence > ML_CONFIDENCE_THRESHOLD

    result = pd.DataFrame(
        {
            "post_id": df["post_id"].values,
            "decision": df["decision"].values,
            "spam_score_at_review": df["spam_score_at_review"].values,
            "ml_confidence": confidence.round(4),
            "ml_agrees": (ml_predicted_approved == (y == 1)),
        }
    )
    export_to_csv(result, output)

    agrees_pct = result["ml_agrees"].mean() * 100
    print(f"Predictions written to {output} ({len(result):,} rows)")
    print(f"ML agrees with decision: {agrees_pct:.1f}%")


def main() -> None:
    """Entry point for the ``fenliu-train`` command."""
    parser = argparse.ArgumentParser(
        prog="fenliu-train",
        description="ML training pipeline for FenLiu ReviewFeedback data.",
    )
    parser.add_argument(
        "--db",
        default=None,
        metavar="PATH",
        help="Path to a SQLite database file (default: use DATABASE_URL from environment)",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser(
        "validate",
        help="Cross-validate model and compare to spam_score baseline",
    )

    fit_parser = subparsers.add_parser(
        "fit",
        help="Train model and save artifacts",
    )
    fit_parser.add_argument(
        "--output-dir",
        default="models",
        metavar="DIR",
        help="Output directory for artifacts (default: models)",
    )

    predict_parser = subparsers.add_parser(
        "predict",
        help="Generate per-post ML vs spam_score comparison CSV",
    )
    predict_parser.add_argument(
        "--output",
        default="predictions.csv",
        metavar="FILE",
        help="Output CSV path (default: predictions.csv)",
    )

    args = parser.parse_args()

    try:
        with _open_db(args.db) as db:
            df = load_feedback(db)
    except Exception as exc:
        print(f"Error: could not load data: {exc}", file=sys.stderr)
        sys.exit(1)

    if len(df) < MIN_ROWS:
        print(
            f"Error: need at least {MIN_ROWS} rows, have {len(df)}",
            file=sys.stderr,
        )
        sys.exit(1)

    match args.command:
        case "validate":
            _cmd_validate(df)
        case "fit":
            _cmd_fit(df, args.output_dir)
        case "predict":
            _cmd_predict(df, args.output)
