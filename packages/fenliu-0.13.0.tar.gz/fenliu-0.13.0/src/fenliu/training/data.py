"""Load ReviewFeedback rows from the database into a pandas DataFrame."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from fenliu.models import ReviewFeedback

DECISION_CLASSES: tuple[str, ...] = ("approved", "rejected")

_EMPTY_COLUMNS: list[str] = [
    "id",
    "post_id",
    "decision",
    "content_snippet",
    "spam_score_at_review",
    "hashtag_count",
    "attachment_count",
    "has_video",
    "boosts",
    "likes",
    "replies",
    "author_is_bot",
    "instance",
    "author_not_found_errors",
]


def load_feedback(session: Session) -> pd.DataFrame:
    """Load approved/rejected ReviewFeedback rows as a DataFrame.

    Rows with decision ``score_adjusted`` are excluded.
    Null snapshot values are replaced with safe defaults so the
    resulting DataFrame has no NaN in numeric columns.
    """
    rows = session.execute(select(ReviewFeedback).where(ReviewFeedback.decision.in_(DECISION_CLASSES))).scalars().all()

    if not rows:
        return pd.DataFrame(columns=_EMPTY_COLUMNS)

    records = [
        {
            "id": r.id,
            "post_id": r.post_id,
            "decision": r.decision,
            "content_snippet": r.content_snippet or "",
            "spam_score_at_review": r.spam_score_at_review or 0,
            "hashtag_count": r.hashtag_count or 0,
            "attachment_count": r.attachment_count or 0,
            "has_video": int(r.has_video or False),
            "boosts": r.boosts or 0,
            "likes": r.likes or 0,
            "replies": r.replies or 0,
            "author_is_bot": int(r.author_is_bot or False),
            "instance": r.instance or "unknown",
            "author_not_found_errors": r.author_not_found_errors or 0,
        }
        for r in rows
    ]
    return pd.DataFrame(records)


def export_to_csv(df: pd.DataFrame, path: str | Path) -> None:
    """Export a DataFrame to CSV for manual inspection."""
    df.to_csv(path, index=False)
