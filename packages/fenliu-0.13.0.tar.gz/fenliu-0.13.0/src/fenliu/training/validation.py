"""Model validation, baseline comparison, and feature importance reporting."""

from __future__ import annotations

import numpy as np
import pandas as pd
import scipy.sparse
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.model_selection import cross_val_score
from xgboost import XGBClassifier


def evaluate(
    model: XGBClassifier,
    X_test: scipy.sparse.spmatrix | np.ndarray,
    y_test: np.ndarray,
) -> dict[str, float]:
    """Evaluate *model* on a held-out test set.

    Returns:
        Dict with keys ``accuracy``, ``precision``, ``recall``, ``f1``.

    """
    y_pred = model.predict(X_test)
    return {
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "precision": float(precision_score(y_test, y_pred, zero_division=0)),
        "recall": float(recall_score(y_test, y_pred, zero_division=0)),
        "f1": float(f1_score(y_test, y_pred, zero_division=0)),
    }


def baseline_accuracy(
    df: pd.DataFrame,
    thresholds: list[int] | None = None,
) -> dict:
    """Treat ``spam_score_at_review`` as a threshold classifier (baseline).

    A post is predicted approved when its spam score is at or below the
    threshold.  Returns the threshold that maximises accuracy, along with
    per-threshold breakdowns.
    """
    if thresholds is None:
        thresholds = [10, 20, 30, 40, 50, 60, 70, 80]
    y_true = (df["decision"] == "approved").astype(int).values
    scores: dict[int, float] = {}
    for t in thresholds:
        y_pred = (df["spam_score_at_review"].fillna(0) <= t).astype(int).values
        scores[t] = float(accuracy_score(y_true, y_pred))
    best_threshold = max(scores, key=scores.__getitem__)
    return {
        "best_threshold": best_threshold,
        "best_accuracy": scores[best_threshold],
        "by_threshold": scores,
    }


def cross_validate_report(
    X: scipy.sparse.spmatrix | np.ndarray,
    y: np.ndarray,
    cv: int = 5,
) -> dict:
    """Run k-fold cross-validation and return accuracy statistics.

    Args:
        X: Feature matrix.
        y: Binary labels.
        cv: Number of folds.

    Returns:
        Dict with ``mean_accuracy``, ``std_accuracy``, and ``scores`` list.

    """
    model = XGBClassifier(
        n_estimators=100,
        max_depth=5,
        learning_rate=0.1,
        random_state=42,
        eval_metric="logloss",
    )
    cv_scores = cross_val_score(model, X, y, cv=cv, scoring="accuracy")
    return {
        "mean_accuracy": float(cv_scores.mean()),
        "std_accuracy": float(cv_scores.std()),
        "scores": cv_scores.tolist(),
    }


def print_feature_importance(
    model: XGBClassifier,
    feature_names: list[str],
    top_n: int = 20,
) -> None:
    """Print the top *top_n* features ranked by XGBoost importance."""
    importances = model.feature_importances_
    indices = np.argsort(importances)[::-1]
    print(f"\nTop {min(top_n, len(indices))} features by importance:")
    for i in range(min(top_n, len(indices))):
        idx = indices[i]
        name = feature_names[idx] if idx < len(feature_names) else f"feature_{idx}"
        print(f"  {name:<40} {importances[idx]:.4f}")
