"""XGBoost training and artifact serialization."""

from __future__ import annotations

import json
from datetime import UTC
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

import joblib
import numpy as np
import scipy.sparse
from xgboost import XGBClassifier

if TYPE_CHECKING:
    from fenliu.training.features import FittedPipeline


def train(
    X_train: scipy.sparse.spmatrix | np.ndarray,
    y_train: np.ndarray,
) -> XGBClassifier:
    """Train an XGBoost binary classifier.

    Args:
        X_train: Feature matrix (sparse or dense).
        y_train: Binary labels (1=approved, 0=rejected).

    Returns:
        Fitted :class:`~xgboost.XGBClassifier`.

    """
    model = XGBClassifier(
        n_estimators=100,
        max_depth=5,
        learning_rate=0.1,
        random_state=42,
        eval_metric="logloss",
    )
    model.fit(X_train, y_train)
    return model


def save_artifacts(
    model: XGBClassifier,
    pipeline: FittedPipeline,
    metadata: dict,
    output_dir: str | Path,
) -> None:
    """Serialize model and pipeline to *output_dir*.

    Creates ``xgboost_model.pkl``, ``feature_pipeline.pkl``, and
    ``model_metadata.json`` inside *output_dir*.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, out / "xgboost_model.pkl")
    joblib.dump(pipeline, out / "feature_pipeline.pkl")
    with open(out / "model_metadata.json", "w") as f:
        json.dump(
            {**metadata, "saved_at": datetime.now(UTC).isoformat()},
            f,
            indent=2,
            default=str,
        )


def load_artifacts(
    output_dir: str | Path,
) -> tuple[XGBClassifier, FittedPipeline]:
    """Load model and pipeline from *output_dir*.

    Returns:
        Tuple of ``(XGBClassifier, FittedPipeline)``.

    """
    out = Path(output_dir)
    model: XGBClassifier = joblib.load(out / "xgboost_model.pkl")
    pipeline: FittedPipeline = joblib.load(out / "feature_pipeline.pkl")
    return model, pipeline
