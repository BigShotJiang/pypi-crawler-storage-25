"""Feature extraction from ReviewFeedback snapshot columns."""

from __future__ import annotations

import numpy as np
import pandas as pd
import scipy.sparse
from sklearn.feature_extraction.text import TfidfVectorizer

METADATA_COLS: list[str] = [
    "spam_score_at_review",
    "hashtag_count",
    "attachment_count",
    "has_video",
    "boosts",
    "likes",
    "replies",
    "author_is_bot",
    "author_not_found_errors",
]

TOP_INSTANCES_N: int = 20
TFIDF_MAX_FEATURES: int = 200


class FittedPipeline:
    """Container for fitted feature-extraction components."""

    def __init__(
        self,
        vectorizer: TfidfVectorizer,
        top_instances: list[str],
    ) -> None:
        """Initialise with a fitted vectorizer and top-instance list."""
        self.vectorizer = vectorizer
        self.top_instances = top_instances

    @property
    def feature_names(self) -> list[str]:
        """Combined feature names in column order, for interpretability."""
        tfidf_names: list[str] = list(self.vectorizer.get_feature_names_out())
        instance_names = [f"instance_{i}" for i in [*self.top_instances, "other"]]
        return tfidf_names + METADATA_COLS + instance_names


def fit_pipeline(df: pd.DataFrame) -> FittedPipeline:
    """Fit a feature pipeline on training data.

    Args:
        df: DataFrame returned by :func:`~fenliu.training.data.load_feedback`.

    Returns:
        A :class:`FittedPipeline` whose components can be passed to
        :func:`transform`.

    """
    vectorizer = TfidfVectorizer(
        max_features=TFIDF_MAX_FEATURES,
        sublinear_tf=True,
        min_df=2,
    )
    vectorizer.fit(df["content_snippet"].fillna(""))
    top_instances: list[str] = df["instance"].value_counts().nlargest(TOP_INSTANCES_N).index.tolist()
    return FittedPipeline(vectorizer=vectorizer, top_instances=top_instances)


def transform(df: pd.DataFrame, pipeline: FittedPipeline) -> scipy.sparse.spmatrix:
    """Transform a DataFrame into a feature matrix.

    Args:
        df: DataFrame with snapshot columns.
        pipeline: A :class:`FittedPipeline` returned by :func:`fit_pipeline`.

    Returns:
        Sparse feature matrix with shape ``(n_rows, n_features)``.

    """
    # TF-IDF block
    tfidf: scipy.sparse.spmatrix = pipeline.vectorizer.transform(df["content_snippet"].fillna(""))

    # Numeric metadata block
    meta: np.ndarray = df[METADATA_COLS].fillna(0).astype(float).values

    # Instance one-hot block
    instance_cols = [*pipeline.top_instances, "other"]
    mapped = df["instance"].apply(lambda x: x if x in pipeline.top_instances else "other")
    instance_matrix = np.zeros((len(df), len(instance_cols)), dtype=float)
    for j, inst in enumerate(instance_cols):
        instance_matrix[:, j] = (mapped == inst).astype(float)

    dense = np.hstack([meta, instance_matrix])
    return scipy.sparse.hstack([tfidf, scipy.sparse.csr_matrix(dense)])


def get_labels(df: pd.DataFrame) -> np.ndarray:
    """Return binary labels: approved=1, rejected=0."""
    return (df["decision"] == "approved").astype(int).values
