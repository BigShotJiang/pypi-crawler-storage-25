"""Shared response helpers for the FenLiu API."""

from __future__ import annotations

from starlette.responses import JSONResponse


def error_response(message: str, status_code: int) -> JSONResponse:
    """Return a JSON error response with a standard ``{"detail": message}`` envelope."""
    return JSONResponse({"detail": message}, status_code=status_code)
