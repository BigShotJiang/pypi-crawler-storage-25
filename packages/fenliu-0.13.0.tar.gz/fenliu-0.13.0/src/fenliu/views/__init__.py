"""View handlers for FenLiu's web UI."""
