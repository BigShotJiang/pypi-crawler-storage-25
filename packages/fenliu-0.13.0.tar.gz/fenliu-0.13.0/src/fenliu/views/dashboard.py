"""Dashboard view."""

from __future__ import annotations

from sqlalchemy import func
from sqlalchemy import select
from sqlalchemy.orm import joinedload
from starlette.requests import Request
from starlette.responses import Response

from fenliu.config import settings
from fenliu.database import get_db
from fenliu.models import HashtagStream
from fenliu.models import Post
from fenliu.services.api_key import get_api_key
from fenliu.templates_env import templates
from fenliu.utils.display import process_post_for_display
from fenliu.utils.display import process_stream_for_display


async def dashboard(request: Request) -> Response:
    """Render the dashboard page."""
    with get_db() as db:
        # Get statistics
        total_streams: int = db.scalar(select(func.count()).select_from(HashtagStream)) or 0
        active_streams: int = (
            db.scalar(select(func.count()).select_from(HashtagStream).where(HashtagStream.active)) or 0
        )
        total_posts: int = db.scalar(select(func.count()).select_from(Post)) or 0
        processed_posts: int = db.scalar(select(func.count()).select_from(Post).where(Post.processed)) or 0

        # Get curated queue posts (approved and in queue)
        stmt = (
            select(Post)
            .options(joinedload(Post.stream))
            .where(Post.approved.is_(True))
            .where(Post.queue_status.isnot(None))
            .order_by(Post.reserved_at.desc(), Post.export_date.desc())
            .limit(20)
        )
        result = db.execute(stmt)
        recent_posts = list(result.scalars().all())

        # Process posts to make datetimes timezone-aware and serialize
        processed_posts_list = [process_post_for_display(post) for post in recent_posts]

        # Get active streams with post counts in a single query
        stmt = (
            select(HashtagStream, func.count(Post.id).label("post_count"))
            .outerjoin(Post, Post.stream_id == HashtagStream.id)
            .where(HashtagStream.active)
            .group_by(HashtagStream.id)
            .order_by(HashtagStream.hashtag)
        )
        processed_streams = [
            {**process_stream_for_display(stream), "post_count": count} for stream, count in db.execute(stmt).all()
        ]

        # Get API key if it exists
        api_key = get_api_key(db)

        context = {
            "total_streams": total_streams,
            "active_streams": active_streams,
            "total_posts": total_posts,
            "processed_posts": processed_posts,
            "curated_posts": processed_posts_list,
            "active_streams_list": processed_streams,
            "app_name": settings.app_name,
            "app_version": settings.app_version,
            "api_key": api_key or "",
        }
        return templates.TemplateResponse(request, "dashboard.html", context)
