"""Configuration settings for the FenLiu application."""

from importlib.metadata import version

from pydantic import ConfigDict
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings."""

    app_name: str = "FenLiu"
    app_version: str = version(str(__package__))
    debug: bool = False
    log_dir: str = "logs"
    database_url: str = "sqlite:///./fenliu.db"
    default_instance: str = "mastodon.social"
    secret_key: str = "your-secret-key-change-in-production"  # noqa: S105
    # Development placeholder - set via SECRET_KEY env var in production

    # Fediverse API settings
    api_timeout: int = 30
    max_posts_per_fetch: int = 20
    rate_limit_delay: float = 1.0

    # Web interface settings
    posts_per_page: int = 20
    refresh_interval: int = 300  # seconds

    # Database connection pool (non-SQLite only)
    db_pool_size: int = 5
    db_max_overflow: int = 10
    db_pool_recycle: int = 3600

    model_config = ConfigDict(
        env_file=".env",  # type: ignore
        env_file_encoding="utf-8",  # type: ignore
    )


settings = Settings()
