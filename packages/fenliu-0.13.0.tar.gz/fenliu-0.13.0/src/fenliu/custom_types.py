"""Common type definitions for FenLiu.

This module consolidates type aliases and TypedDict definitions used across
multiple modules in the FenLiu project.
"""

from typing import Any
from typing import NotRequired
from typing import TypedDict


class MediaAttachmentDict(TypedDict):
    """Type definition for media attachment dictionaries.

    Used in fediverse client and schemas for media attachment data.
    Fields are NotRequired to handle varying data from different sources.
    """

    type: str
    url: str
    description: NotRequired[str]
    preview_url: NotRequired[str]


class RuleResult(TypedDict):
    """Result from applying a single spam detection rule.

    Used in spam scoring service.
    """

    rule_name: str
    score: int  # 0-100
    weight: float  # 0.0-1.0
    details: "DetailsDict"
    triggered: bool


class ScoringResult(TypedDict):
    """Result of spam scoring for a post.

    Used in spam scoring service and API endpoints.
    """

    final_score: int
    rule_results: list[RuleResult]
    triggered_rules: list[str]
    confidence: float
    post_id: str


# Type aliases for flexible dictionaries
DetailsDict = dict[str, Any]  # Type alias for rule details dictionary
PostDataDict = dict[str, Any]  # Type alias for post data dictionary
RuleDescriptionDict = dict[str, str | float]  # Type alias for rule description dictionary
