"""
Lambda handler for updating a subscription.

Requires authentication (secure mode).
"""

from typing import Dict, Any
from geek_cafe_saas_sdk.lambda_handlers import create_handler, LambdaEvent
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.modules.tenancy.services.subscription_service import SubscriptionService


# Factory creates handler (defaults to secure auth)
handler_wrapper = create_handler(
    service_class=SubscriptionService,
    require_body=True,
    convert_request_case=True
)


def lambda_handler(event: Dict[str, Any], context: Any, injected_service=None) -> Dict[str, Any]:
    """
    Lambda handler for updating a subscription.

    Args:
        event: API Gateway event
        context: Lambda context
        injected_service: Optional SubscriptionService for testing
    """
    return handler_wrapper.execute(event, context, update_subscription, injected_service)


def update_subscription(event: LambdaEvent, service: SubscriptionService) -> ServiceResult:
    """
    Business logic for updating a subscription.

    Service already has request_context with tenant_id and user_id.
    """
    subscription_id = event.path("id", "subscriptionId")

    if not subscription_id:
        raise ValueError("Subscription ID is required in the path")

    return service.update(subscription_id=subscription_id, updates=event.body())
