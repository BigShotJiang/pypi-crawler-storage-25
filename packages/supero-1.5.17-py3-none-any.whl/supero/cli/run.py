"""
supero.cli.run — Main orchestrator for Supero App Runner

Entry point: python3 -m supero.cli

Robust orchestrator with proper logging and error reporting:
  1. Validate project files exist (schemas.py, config.py, setup.py)
  2. Detect & report SDK versions (supero, pymodel_*, requests)
  3. Interactive .env setup (if not configured)
  4. CDN downloads (supero-ui.js, index.html, server.py, config.js)
  5. Run setup.py (handles ALL platform interaction via AppSetup)
  6. Start server (or mobile, or docker)

The CLI does NOT duplicate platform logic — setup.py's AppSetup.run()
handles domain bootstrap, schema upload, services, workflows, policies,
and seed data. The CLI only ensures .env + venv + infrastructure files exist.
"""

import os
import sys
import time
import socket
import subprocess
import argparse
import logging
from datetime import datetime

from supero.cli.env_manager import EnvManager
from supero.cli.interactive import interactive_setup
from supero.cli.cdn_downloader import CdnDownloader

__version__ = "1.2.0"

# ── Logging setup ────────────────────────────────────────────
LOG_FILE = os.path.join(os.getcwd(), ".supero-run.log")

def _setup_logging(verbose: bool = False):
    """Configure file + console logging."""
    logger = logging.getLogger("supero.cli")
    logger.setLevel(logging.DEBUG)

    # File handler — always DEBUG
    fh = logging.FileHandler(LOG_FILE, mode="a")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(
        "[%(asctime)s] %(levelname)s %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    ))
    logger.addHandler(fh)

    # Console handler — INFO or DEBUG
    if verbose:
        ch = logging.StreamHandler()
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(logging.Formatter("  %(levelname)s %(message)s"))
        logger.addHandler(ch)

    return logger


# ── ANSI colors for terminal output ──
class _C:
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    RED    = "\033[91m"
    CYAN   = "\033[96m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"
    RESET  = "\033[0m"

# Disable colors if not a TTY (piped output, CI, etc.)
if not sys.stdout.isatty():
    for attr in ('GREEN', 'YELLOW', 'RED', 'CYAN', 'BOLD', 'DIM', 'RESET'):
        setattr(_C, attr, '')


def _ok(msg):     print(f"  {_C.GREEN}✓{_C.RESET} {msg}")
def _warn(msg):   print(f"  {_C.YELLOW}⚠{_C.RESET} {msg}")
def _fail(msg):   print(f"  {_C.RED}✗{_C.RESET} {msg}")
def _info(msg):   print(f"  {_C.DIM}{msg}{_C.RESET}")
def _header(msg): print(f"\n{_C.BOLD}── {msg} ──{_C.RESET}\n")


def _step(num, title, desc=""):
    """Print a step header with optional description."""
    print(f"\n{_C.BOLD}── Step {num} · {title} ──{_C.RESET}")
    if desc:
        print(f"  {_C.DIM}{desc}{_C.RESET}\n")


# ── Version detection ────────────────────────────────────────

def _detect_versions() -> dict:
    """
    Detect installed SDK versions and report them.

    Returns dict with:
      python: "3.11.5"
      supero: "1.4.8" or None
      supero_location: "/path/to/supero"
      tenant_sdks: [{"name": "pymodel-foo", "version": "0.1.0", "location": "..."}]
      requests: "2.31.0" or None
      venv: True/False (whether running in a venv)
      venv_path: "/path/to/.venv" or None
    """
    info = {
        "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "python_path": sys.executable,
        "supero": None,
        "supero_location": None,
        "tenant_sdks": [],
        "requests": None,
        "venv": hasattr(sys, 'real_prefix') or (
            hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix
        ),
        "venv_path": sys.prefix if hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix else None,
    }

    # Supero SDK
    try:
        import supero
        info["supero"] = getattr(supero, '__version__', 'unknown')
        info["supero_location"] = os.path.dirname(supero.__file__)
    except ImportError:
        pass

    # Requests
    try:
        import requests as _req
        info["requests"] = _req.__version__
    except ImportError:
        pass

    # Tenant SDKs (pymodel_*)
    try:
        import pkg_resources
        for pkg in pkg_resources.working_set:
            if pkg.project_name.startswith('pymodel'):
                info["tenant_sdks"].append({
                    "name": pkg.project_name,
                    "version": pkg.version,
                    "location": pkg.location,
                })
    except Exception:
        pass

    return info


def _print_versions(info: dict, logger=None):
    """Print version info in a clean format."""
    _ok(f"Python {info['python']} ({info['python_path']})")

    if info["venv"]:
        _ok(f"Virtual env: {info['venv_path'] or 'active'}")
    else:
        _warn("Not running in a virtual environment")
        _info("Tip: run.sh creates .venv automatically. Use ./run.sh instead of python3 -m supero.cli")

    if info["supero"]:
        _ok(f"Supero SDK: v{info['supero']}")
        if logger:
            logger.info(f"Supero SDK v{info['supero']} at {info['supero_location']}")
    else:
        _fail("Supero SDK: NOT INSTALLED")
        _info("Install with: pip install supero")

    if info["requests"]:
        _ok(f"Requests: v{info['requests']}")
    else:
        _fail("Requests library: NOT INSTALLED")

    if info["tenant_sdks"]:
        for sdk in info["tenant_sdks"]:
            _ok(f"Tenant SDK: {sdk['name']} v{sdk['version']}")
            if logger:
                logger.info(f"Tenant SDK: {sdk['name']} v{sdk['version']} at {sdk['location']}")
    else:
        _info("No tenant SDK packages installed (will be built during setup)")

    if logger:
        logger.info(f"Versions: python={info['python']}, supero={info['supero']}, "
                     f"requests={info['requests']}, tenant_sdks={len(info['tenant_sdks'])}, "
                     f"venv={info['venv']}")


# ── Launch mode ──────────────────────────────────────────────


def _is_port_available(port: int) -> bool:
    """Check if a port is available to bind."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        s.bind(('', port))
        s.close()
        return True
    except OSError:
        return False


def _find_available_port(start_port: int, max_tries: int = 10) -> int:
    """Find next available port starting from start_port."""
    for offset in range(max_tries):
        port = start_port + offset
        if _is_port_available(port):
            return port
    return start_port  # give up, let it fail with the original


def _resolve_port(preferred: int, interactive: bool = True) -> int:
    """Check if preferred port is available, offer alternatives if not."""
    if _is_port_available(preferred):
        return preferred

    # Port is busy
    _warn(f"Port {preferred} is already in use")

    # Try to kill existing process
    try:
        import subprocess
        result = subprocess.run(
            ["lsof", "-ti", f"tcp:{preferred}"],
            capture_output=True, text=True
        )
        if result.stdout.strip():
            pids = result.stdout.strip()
            if interactive:
                print()
                try:
                    choice = input(f"  Kill existing process on port {preferred}? [y/N] ").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    choice = "n"

                if choice in ("y", "yes"):
                    import time
                    subprocess.run(["kill", "-9"] + pids.split(), capture_output=True)
                    time.sleep(1)
                    if _is_port_available(preferred):
                        _ok(f"Port {preferred} freed")
                        return preferred
    except FileNotFoundError:
        pass  # lsof not available

    # Find alternative
    alt_port = _find_available_port(preferred + 1)

    if interactive:
        print()
        try:
            choice = input(f"  Use port {alt_port} instead? [Y/n] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            choice = "y"

        if choice in ("n", "no"):
            _fail(f"Port {preferred} is in use. Free it or use --port={alt_port}")
            sys.exit(1)
    else:
        _info(f"Port {preferred} busy — using {alt_port}")

    return alt_port


def _update_port_in_env(env, new_port: int):
    """Update PORT in .env when port changes (e.g. busy port fallback)."""
    env.set("PORT", str(new_port))
    env.set("UI_PORT", str(new_port))
    env.save()
    _ok(f"Port updated to {new_port} in .env")


def _prompt_launch_mode() -> str:
    """Ask user how they want to run."""
    print()
    print(f"  How would you like to run this app?")
    print()
    print(f"  {_C.BOLD}1){_C.RESET} {_C.GREEN}Standalone{_C.RESET}    Run directly on this machine")
    print(f"     {_C.DIM}Best for: development, quick testing{_C.RESET}")
    print()
    print(f"  {_C.BOLD}2){_C.RESET} {_C.CYAN}Docker{_C.RESET}        Build and run in a container")
    print(f"     {_C.DIM}Best for: production, reproducible deploys{_C.RESET}")
    print()
    print(f"  {_C.BOLD}3){_C.RESET} {_C.DIM}Setup only{_C.RESET}    Configure without starting server")
    print(f"     {_C.DIM}Best for: CI/CD, preparing deploy{_C.RESET}")
    print()
    try:
        choice = input("  Choose [1/2/3] (default: 1): ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        choice = "1"
    return {"2": "docker", "3": "setup"}.get(choice, "standalone")


# ── Args ─────────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(
        prog="supero-run",
        description="Supero App Runner — interactive setup + server launcher",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ./run.sh                    Interactive setup + start server
  ./run.sh --setup-only       Run setup without starting server
  ./run.sh --server-only      Start server (skip setup)
  ./run.sh --reset            Re-upload schemas and re-run setup
  ./run.sh --docker           Build and run with Docker Compose
  ./run.sh --no-interactive   Use .env values without prompting
  ./run.sh --verbose          Show detailed logs
  ./run.sh --skip-tests       Skip CRUD smoke tests and launch directly

Log file: .supero-run.log (always written, even without --verbose)
        """
    )
    parser.add_argument("--setup-only", action="store_true",
                        help="Run setup without starting server")
    parser.add_argument("--server-only", action="store_true",
                        help="Start server without running setup")
    parser.add_argument("--mobile", action="store_true",
                        help="Also set up the mobile app (Expo)")
    parser.add_argument("--docker", action="store_true",
                        help="Build and run with Docker Compose")
    parser.add_argument("--port", type=int,
                        help="Override server port (default: from .env or 5648)")
    parser.add_argument("--no-interactive", action="store_true",
                        help="Use .env values without prompting")
    parser.add_argument("--reset", action="store_true",
                        help="Re-upload schemas and re-run setup")
    parser.add_argument("--verbose", action="store_true",
                        help="Show detailed logs from setup and server")
    parser.add_argument("--no-seed", action="store_true",
                        help="Skip seeding test data (seed runs by default)")
    parser.add_argument("--seed", action="store_true", default=True,
                        help=argparse.SUPPRESS)
    parser.add_argument("--skip-tests", action="store_true",
                        help="Skip CRUD smoke tests before launching")
    parser.add_argument("--version", action="version",
                        version=f"%(prog)s {__version__}")
    return parser.parse_args()


# ── Project validation ───────────────────────────────────────

def validate_project(path: str, logger=None) -> dict:
    """Validate that required project files exist."""
    required = [
        ("schemas.py", "Schema definitions"),
        ("config.py",  "App configuration"),
        ("setup.py",   "Setup script"),
    ]

    missing = []
    for filename, desc in required:
        filepath = os.path.join(path, filename)
        if os.path.exists(filepath):
            _ok(f"Found {filename}")
        else:
            _fail(f"Missing {filename} ({desc})")
            missing.append(filename)

    has_web = (
        os.path.exists(os.path.join(path, "ui", "app.js"))
        or os.path.exists(os.path.join(os.getcwd(), "ui", "app.js"))
    )
    has_mobile = (
        os.path.exists(os.path.join(path, "mobile", "src", "appConfig.ts"))
        or os.path.exists(os.path.join(os.getcwd(), "mobile", "src", "appConfig.ts"))
    )

    if has_web:
        _ok("Found ui/app.js (Web UI)")
    if has_mobile:
        _ok("Found mobile/src/appConfig.ts (Mobile)")
    if not has_web and not has_mobile:
        _warn("No ui/app.js or mobile/src/appConfig.ts found")

    if missing:
        print()
        _fail(f"Missing required files: {', '.join(missing)}")
        _info("Make sure you're in the app root directory.")
        if logger:
            logger.error(f"Missing project files: {missing}")
        sys.exit(1)

    if logger:
        logger.info(f"Project validated: has_web={has_web}, has_mobile={has_mobile}")

    return {"has_web": has_web, "has_mobile": has_mobile}


def _find_app_dir() -> str:
    """Find the app package directory containing setup.py."""
    cwd = os.getcwd()

    # Flat layout
    if os.path.exists(os.path.join(cwd, "setup.py")):
        return cwd

    # Package layout
    for entry in os.listdir(cwd):
        candidate = os.path.join(cwd, entry)
        if (os.path.isdir(candidate)
                and not entry.startswith(".")
                and entry not in ("mobile", "e2e-tests", ".venv", "__pycache__", "node_modules")
                and os.path.exists(os.path.join(candidate, "setup.py"))):
            return candidate

    return cwd


def _get_lan_ip() -> str:
    """Get LAN IP address for network URL display."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "0.0.0.0"


def _read_app_meta(app_dir: str) -> dict:
    """Extract app metadata from config.py."""
    config_path = os.path.join(app_dir, "config.py")
    result = {"name": "", "emoji": "", "description": "", "public_schemas": []}
    if not os.path.exists(config_path):
        return result

    attr_map = {
        "app_name": "name",
        "display_name": "name",
        "app_emoji": "emoji",
        "app_description": "description",
    }

    try:
        import re as _re
        with open(config_path) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                for attr, key in attr_map.items():
                    if line.startswith(f"{attr}") and "=" in line:
                        val = line.split("=", 1)[1].strip().strip("'\"")
                        if val and not result[key]:
                            result[key] = val
                if line.startswith("public_schemas") and "=" in line:
                    val_part = line.split("=", 1)[1].strip()
                    schemas = _re.findall(r"""["\']([\w-]+)["']""", val_part)
                    if schemas:
                        result["public_schemas"] = schemas
    except Exception:
        pass
    # Fallback: scan app.js for publicSchemas (Phase 2 puts it there)
    if not result["public_schemas"]:
        _app_js = os.path.join(app_dir, "ui", "app.js")
        if not os.path.exists(_app_js):
            _app_js = os.path.join(app_dir, "app.js")
        if os.path.exists(_app_js):
            try:
                import re as _re2
                with open(_app_js) as _f2:
                    _ac = _f2.read()
                _m = _re2.search(r'publicSchemas\s*:\s*\[([^\]]*)\]', _ac)
                if _m:
                    _schemas = _re2.findall(r"['\"](\w[\w-]*)['\"']", _m.group(1))
                    if _schemas:
                        result["public_schemas"] = _schemas
            except Exception:
                pass
    return result


def _ensure_crud_tests(app_dir: str):
    """Generate crud_tests.py in app_dir if it doesn't already exist."""
    dest = os.path.join(app_dir, "crud_tests.py")
    if os.path.exists(dest):
        return
    # Only generate when schemas.py and config.py are present (supero.cli app)
    if not (os.path.exists(os.path.join(app_dir, "schemas.py")) and
            os.path.exists(os.path.join(app_dir, "config.py"))):
        return
    content = '''\
"""
crud_tests.py — CRUD smoke tests for all schemas.

Run automatically by supero CLI (Step 4.5) after setup and before server launch.
Exit 0 = all tests passed. Exit 1 = one or more failures (launch will be blocked).

Can also be run directly:
    python crud_tests.py

Requires env vars (set by run.sh / .env):
    SUPERO_URL, SUPERO_DOMAIN, SUPERO_ADMIN_EMAIL, SUPERO_PASSWORD,
    SUPERO_PROJECT, SUPERO_API_KEY, SUPERO_DEFAULT_TENANT
"""

import os
import sys
import uuid as _uuid
import warnings

import requests
urllib3 = None
try:
    import urllib3 as _urllib3
    urllib3 = _urllib3
except ImportError:
    pass

# Suppress SSL warnings (dev/staging environments use self-signed certs)
warnings.filterwarnings("ignore", message="Unverified HTTPS request")
if urllib3:
    urllib3.disable_warnings()

# -- Load app schemas and config from the same directory ----------------------
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from schemas import ALL_SCHEMAS
from config import AppConfig

# -- Credentials from environment ---------------------------------------------
BASE_URL    = os.environ.get("SUPERO_URL", "https://api.supero.dev").rstrip("/")
DOMAIN      = os.environ.get("SUPERO_DOMAIN", "")
PROJECT     = os.environ.get("SUPERO_PROJECT", "default-project")
API_KEY     = os.environ.get("SUPERO_API_KEY", "")
ADMIN_EMAIL = os.environ.get("SUPERO_ADMIN_EMAIL", "")
ADMIN_PASS  = os.environ.get("SUPERO_PASSWORD", "")

# -- Types to skip when building test payloads --------------------------------
SKIP_TYPES = {"Image", "File"}

# -- Primitive type -> minimal valid value ------------------------------------
TYPE_DEFAULTS = {
    "string":   lambda h: f"test-{h}",
    "integer":  lambda _: 1,
    "float":    lambda _: 1.0,
    "datetime": lambda _: "2026-01-01T00:00:00Z",
    "bool":     lambda _: True,
}


# -- Helpers ------------------------------------------------------------------

def make_session(token=None, api_key=None):
    s = requests.Session()
    s.verify = False
    s.headers.update({"Content-Type": "application/json"})
    if token:
        s.headers["Authorization"] = f"Bearer {token}"
    if api_key:
        s.headers["X-API-Key"] = api_key
    return s


def login(email, password, project=None):
    """Login and return JWT access token, or None on failure."""
    try:
        r = requests.post(
            f"{BASE_URL}/api/v1/auth/login",
            json={"username": email, "password": password,
                  "domain": DOMAIN, "project": project or PROJECT},
            headers={"Content-Type": "application/json"},
            timeout=15, verify=False,
        )
        if r.status_code in (200, 201):
            auth = r.json().get("auth", {})
            return auth.get("access_token") or auth.get("session_id")
    except Exception:
        pass
    return None


def fetch_tenant_uuid(session, tenant_name):
    """Return UUID of named tenant, or None."""
    try:
        r = session.get(f"{BASE_URL}/api/v1/crud/{DOMAIN}/tenant", timeout=15)
        if r.status_code in (200, 201):
            for t in r.json().get("results", []):
                if t.get("name") == tenant_name:
                    return t["uuid"]
    except Exception:
        pass
    return None


def extract_uuid(body):
    """Extract UUID from various response shapes."""
    if not isinstance(body, dict):
        return None
    if body.get("uuid"):
        return body["uuid"]
    data = body.get("data", {})
    if isinstance(data, dict):
        if data.get("uuid"):
            return data["uuid"]
        for v in data.values():
            if isinstance(v, dict) and v.get("uuid"):
                return v["uuid"]
    return None


def build_enum_map(schemas):
    """Build {EnumName: first_valid_value} from ALL_SCHEMAS."""
    return {
        s["name"]: s["values"][0]
        for s in schemas
        if s.get("schema_type") == "enum" and s.get("values")
    }


def make_payload(schema_dict, hex_suffix, tenant_uuid, enum_map):
    """Build minimal valid create payload for a schema."""
    payload = {
        "name": f"smoketest-{schema_dict[\'name\'].lower()}-{hex_suffix}",
        "parent_type": "tenant",
        "parent_uuid": tenant_uuid,
    }
    for attr in schema_dict.get("attributes", []):
        if not attr.get("mandatory"):
            continue
        atype = attr["type"]
        if atype in SKIP_TYPES:
            continue
        if atype in TYPE_DEFAULTS:
            payload[attr["name"]] = TYPE_DEFAULTS[atype](hex_suffix)
        elif atype in enum_map:
            payload[attr["name"]] = enum_map[atype]
    return payload


# -- Core test functions -------------------------------------------------------

def test_schema_crud(session, schema_name, payload, label):
    msgs = []
    created_uuid = None
    url_base = f"{BASE_URL}/api/v1/crud/{DOMAIN}/{schema_name.lower()}"
    passed = True

    try:
        # CREATE
        try:
            r = session.post(url_base, json=payload, timeout=30)
        except Exception as e:
            msgs.append(f"  FAIL CREATE {schema_name} [{label}]: request error -- {e}")
            return False, msgs

        if r.status_code not in (200, 201):
            msgs.append(
                f"  FAIL CREATE {schema_name} [{label}]: "
                f"HTTP {r.status_code} -- {r.text[:200]}"
            )
            return False, msgs

        created_uuid = extract_uuid(r.json())
        if not created_uuid:
            msgs.append(
                f"  FAIL CREATE {schema_name} [{label}]: "
                f"no UUID in response -- {r.text[:200]}"
            )
            return False, msgs
        msgs.append(f"  PASS CREATE {schema_name} [{label}]")

        # READ
        try:
            r = session.get(f"{url_base}/{created_uuid}", timeout=15)
            if r.status_code == 200:
                msgs.append(f"  PASS READ   {schema_name} [{label}]")
            else:
                msgs.append(f"  FAIL READ   {schema_name} [{label}]: HTTP {r.status_code}")
                passed = False
        except Exception as e:
            msgs.append(f"  FAIL READ   {schema_name} [{label}]: {e}")
            passed = False

        # LIST
        try:
            r = session.get(url_base, timeout=15)
            if r.status_code == 200:
                msgs.append(f"  PASS LIST   {schema_name} [{label}]")
            else:
                msgs.append(f"  FAIL LIST   {schema_name} [{label}]: HTTP {r.status_code}")
                passed = False
        except Exception as e:
            msgs.append(f"  FAIL LIST   {schema_name} [{label}]: {e}")
            passed = False

        # UPDATE
        try:
            r = session.put(
                f"{url_base}/{created_uuid}",
                json={"name": payload["name"] + "-upd"},
                timeout=30,
            )
            if r.status_code in (200, 201):
                msgs.append(f"  PASS UPDATE {schema_name} [{label}]")
            else:
                msgs.append(f"  FAIL UPDATE {schema_name} [{label}]: HTTP {r.status_code}")
                passed = False
        except Exception as e:
            msgs.append(f"  FAIL UPDATE {schema_name} [{label}]: {e}")
            passed = False

    finally:
        # DELETE (always attempt cleanup)
        if created_uuid:
            try:
                r = session.delete(f"{url_base}/{created_uuid}", timeout=15)
                if r.status_code in (200, 204):
                    msgs.append(f"  PASS DELETE {schema_name} [{label}]")
                else:
                    msgs.append(
                        f"  WARN DELETE {schema_name} [{label}]: "
                        f"HTTP {r.status_code} (cleanup may have failed)"
                    )
            except Exception as e:
                msgs.append(f"  WARN DELETE {schema_name} [{label}]: {e} (cleanup)")

    return passed, msgs


# -- Main ---------------------------------------------------------------------

def main():
    if not DOMAIN:
        print("  x SUPERO_DOMAIN not set -- cannot run tests")
        sys.exit(1)
    if not API_KEY:
        print("  x SUPERO_API_KEY not set -- cannot run tests")
        sys.exit(1)

    hex_suffix = _uuid.uuid4().hex[:8]
    failures = []
    cfg = AppConfig()

    enum_map = build_enum_map(ALL_SCHEMAS)
    object_schemas = [s for s in ALL_SCHEMAS if s.get("schema_type") == "object"]

    if not object_schemas:
        print("  No object schemas found -- skipping CRUD tests")
        sys.exit(0)

    print(f"\\n  Running CRUD smoke tests -- {len(object_schemas)} schemas\\n")

    admin_session = make_session(api_key=API_KEY)

    # Fast-fail: verify domain is reachable
    try:
        r = admin_session.get(f"{BASE_URL}/api/v1/crud/{DOMAIN}/tenant", timeout=15)
        if r.status_code not in (200, 201):
            print(f"  x Cannot reach domain \'{DOMAIN}\' -- aborting")
            print(f"    HTTP {r.status_code}: {r.text[:200]}")
            sys.exit(1)
    except Exception as e:
        print(f"  x Cannot reach {BASE_URL} -- aborting")
        print(f"    {e}")
        sys.exit(1)

    # Fetch tenant UUID
    tenant_name = next(
        (t["name"] for t in cfg.tenants if t["name"] != "default-tenant"),
        cfg.tenants[0]["name"] if cfg.tenants else "default-tenant",
    )
    tenant_uuid = fetch_tenant_uuid(admin_session, tenant_name)
    if not tenant_uuid:
        tenant_uuid = fetch_tenant_uuid(admin_session, "default-tenant")
    if not tenant_uuid:
        print(f"  x Could not fetch tenant UUID for \'{tenant_name}\' -- aborting")
        sys.exit(1)

    # Build user sessions from config.users
    user_sessions = []
    for u in cfg.users:
        email    = u["email"]
        password = u.get("password", getattr(cfg, "default_user_password", "Password123!"))
        role     = u.get("role", "tenant_user")
        token = login(email, password)
        if token:
            user_sessions.append((make_session(token=token), role, email))
        else:
            print(f"  Warning: Login failed for {email} (role={role}) -- skipping")

    sessions_to_test = [
        (admin_session, "tenant_admin", ADMIN_EMAIL),
        *user_sessions,
    ]

    for schema in object_schemas:
        schema_name = schema["name"]
        payload = make_payload(schema, hex_suffix, tenant_uuid, enum_map)
        print(f"  -- {schema_name} --")
        for session, role, email in sessions_to_test:
            label = f"{role}:{email.split(\'@\')[0]}"
            passed, msgs = test_schema_crud(session, schema_name, payload, label)
            for m in msgs:
                print(m)
            if not passed:
                failures.append(f"{schema_name} [{label}]")
        print()

    if failures:
        print(f"  x {len(failures)} test(s) FAILED:")
        for f in failures:
            print(f"      * {f}")
        sys.exit(1)
    else:
        print("  All CRUD smoke tests passed")
        sys.exit(0)


if __name__ == "__main__":
    main()
'''
    with open(dest, "w") as _f:
        _f.write(content)
    _ok("Generated crud_tests.py")


def _ensure_docker_files(app_dir: str, env: 'EnvManager', app_name: str = "supero-app"):
    """Generate Dockerfile and docker-compose.yml if they don't exist."""
    project_root = os.getcwd()

    dockerfile_path = os.path.join(project_root, "Dockerfile")
    if not os.path.exists(dockerfile_path):
        dockerfile = """# Auto-generated by Supero CLI
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt* ./
RUN pip install --no-cache-dir supero>=1.2.0 requests>=2.28.0 2>/dev/null || true
RUN test -f requirements.txt && pip install --no-cache-dir -r requirements.txt || true

COPY . .

ENV PORT=5648
EXPOSE 5648

CMD ["python3", "-m", "supero.cli", "--server-only"]
"""
        with open(dockerfile_path, "w") as f:
            f.write(dockerfile)
        _ok("Generated Dockerfile")
    else:
        _ok("Found existing Dockerfile")

    compose_path = os.path.join(project_root, "docker-compose.yml")
    if not os.path.exists(compose_path):
        port = env.get("PORT", env.get("UI_PORT", "5648"))
        slug = app_name.lower().replace(" ", "-").replace("_", "-")
        compose = f"""# Auto-generated by Supero CLI
version: '3.8'

services:
  {slug}:
    build: .
    ports:
      - "{port}:{port}"
    env_file:
      - .env
    environment:
      - PORT={port}
      - UI_PORT={port}
    restart: unless-stopped
"""
        with open(compose_path, "w") as f:
            f.write(compose)
        _ok("Generated docker-compose.yml")
    else:
        _ok("Found existing docker-compose.yml")

    return dockerfile_path, compose_path


# ═══════════════════════════════════════════════════════════════
#  Main
# ═══════════════════════════════════════════════════════════════

def main():
    args = parse_args()
    logger = _setup_logging(verbose=args.verbose)

    logger.info(f"=== supero.cli v{__version__} started ===")
    logger.info(f"CWD: {os.getcwd()}")
    logger.info(f"Args: {sys.argv[1:]}")
    logger.info(f"Env: SUPERO_DOMAIN={os.environ.get('SUPERO_DOMAIN', '')}, "
                f"SUPERO_URL={os.environ.get('SUPERO_URL', '')}")

    # ── Banner ──
    print()
    print(f"{_C.BOLD}🚀 Supero App Runner v{__version__}{_C.RESET}")
    print("━" * 40)

    # ── Step 1: Versions + Project validation ──
    _header("Step 1 · Environment & project files")

    versions = _detect_versions()
    _print_versions(versions, logger)
    print()

    app_dir = _find_app_dir()
    if app_dir != os.getcwd():
        _info(f"App directory: {os.path.basename(app_dir)}/")
        logger.info(f"App dir: {app_dir}")

    project = validate_project(app_dir, logger)

    # Resolve ui_dir
    if os.path.exists(os.path.join(app_dir, "ui", "app.js")):
        ui_base = app_dir
    elif os.path.exists(os.path.join(os.getcwd(), "ui", "app.js")):
        ui_base = os.getcwd()
    else:
        ui_base = app_dir

    # ── Step 2: Environment setup ──
    env = EnvManager(env_path=os.path.join(os.getcwd(), ".env"))

    # Clear stale SUPERO_* env vars from previous runs in this shell session.
    # Without this, a key from a different app/project leaks via os.environ.
    for _k in list(os.environ.keys()):
        if _k.startswith("SUPERO_") or _k in ("PLATFORM_CORE_HOST", "PLATFORM_CORE_PORT"):
            if _k not in env.values:
                del os.environ[_k]
    # Sync .env values into os.environ (override any stale values)
    for _k, _v in env.values.items():
        if _k and _v:
            os.environ[_k] = _v

    if not args.server_only:
        if args.reset:
            _header("Step 2 · Resetting configuration")
            env.clear()
            _ok("Configuration cleared")
            logger.info("Configuration reset")
            print()

        if not env.is_configured() or args.reset:
            _header("Step 2 · Domain configuration")
            if args.no_interactive:
                _fail(".env not configured. Run without --no-interactive first.")
                sys.exit(1)
            interactive_setup(env)
        else:
            _header("Step 2 · Configuration")

            domain = env.get('SUPERO_DOMAIN')
            project_name = env.get('SUPERO_PROJECT', 'default-project')
            email = env.get('SUPERO_ADMIN_EMAIL')
            api_key = env.get('SUPERO_API_KEY')
            url = env.get('SUPERO_URL', 'https://api.supero.dev')
            port = env.get('PORT', env.get('UI_PORT', '5648'))

            print(f"  {_C.CYAN}Domain:{_C.RESET}   {domain}")
            print(f"  {_C.CYAN}Project:{_C.RESET}  {project_name}")
            if email:
                print(f"  {_C.CYAN}Email:{_C.RESET}    {email}")
            if api_key and api_key.startswith("ak_"):
                print(f"  {_C.CYAN}API key:{_C.RESET}  ...{api_key[-4:]}")
            elif env.get('SUPERO_PASSWORD'):
                print(f"  {_C.CYAN}Auth:{_C.RESET}     password (saved)")
            else:
                _warn("No API key or password configured")
                if not args.no_interactive:
                    import getpass
                    print()
                    try:
                        pw = getpass.getpass(f"  Enter password for {email}: ")
                    except (EOFError, KeyboardInterrupt):
                        pw = ""
                    if pw:
                        env.set("SUPERO_PASSWORD", pw)
                        env.save()
                        _ok("Password saved")
                    else:
                        _fail("Password required — setup will fail without credentials")
            print(f"  {_C.CYAN}Server:{_C.RESET}   {url}")
            print(f"  {_C.CYAN}Port:{_C.RESET}     {port}")
            print()

            logger.info(f"Config: domain={domain}, project={project}, "
                        f"email={email}, api_key={'yes' if api_key else 'no'}, port={port}")

            if not args.no_interactive:
                try:
                    choice = input(f"  Continue with this configuration? [Y/n] ").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    print()
                    choice = "y"

                if choice in ("n", "no"):
                    # Let user change port
                    print()
                    try:
                        new_port = input(f"  Port [{port}]: ").strip()
                    except (EOFError, KeyboardInterrupt):
                        new_port = ""
                    if new_port and new_port != port:
                        env.set("PORT", new_port)
                        env.set("UI_PORT", new_port)
                        env.save()
                        _ok(f"Port updated to {new_port}")

                    # Offer to re-enter password
                    if not (api_key and api_key.startswith("ak_")):
                        try:
                            import getpass
                            new_pass = getpass.getpass(f"  Password [{('*' * 8 if env.get('SUPERO_PASSWORD') else 'not set')}]: ")
                        except (EOFError, KeyboardInterrupt):
                            new_pass = ""
                        if new_pass:
                            env.set("SUPERO_PASSWORD", new_pass)
                            env.save()
                            _ok("Password updated")
                    print()
    else:
        if not env.is_configured():
            _fail("No .env configuration found. Run without --server-only first.")
            sys.exit(1)
        _header("Step 2 · Skipped (--server-only)")
        _ok(f"Domain: {env.get('SUPERO_DOMAIN')}")

    env.derive_sdk_vars()

    # ── Step 3: CDN downloads + config.js ──
    if project["has_web"]:
        _header("Step 3 · Preparing web UI files")
        ui_dir = os.path.join(ui_base, "ui")

        meta = _read_app_meta(app_dir)
        app_name = env.get("APP_NAME") or meta["name"] or env.get(
            "SUPERO_DOMAIN", "Supero App"
        ).replace("-", " ").title()
        app_emoji = env.get("APP_EMOJI") or meta["emoji"]
        app_description = env.get("APP_DESCRIPTION") or meta["description"]

        cdn = CdnDownloader(verbose=args.verbose)
        cdn.ensure_files(ui_dir, app_name=app_name)
        env.generate_config_js(
            ui_dir,
            app_name=app_name,
            app_emoji=app_emoji,
            app_description=app_description,
        )
        _public = meta.get("public_schemas", [])
        if _public:
            _schemas_csv = ",".join(_public)
            env.set("PUBLIC_SCHEMAS", _schemas_csv)
            _ok(f"Public schemas: {_schemas_csv}")
    else:
        _header("Step 3 · Skipped (no web UI)")
        _info("No ui/app.js found, skipping CDN downloads")

    # ── Step 4: Run setup.py ──
    if not args.server_only:
        _header("Step 4 · Running platform setup")
        _info("This registers the domain, uploads schemas, configures services...")
        logger.info("Starting setup.py")
        print()

        setup_cmd = [sys.executable, "setup.py"]
        if args.no_seed:
            setup_cmd.append("--no-seed")

        setup_start = time.time()

        if args.verbose:
            result = subprocess.run(setup_cmd, cwd=app_dir)
        else:
            result = subprocess.run(
                setup_cmd, cwd=app_dir,
                capture_output=True, text=True
            )
            # Log full output
            if result.stdout:
                logger.info("setup.py stdout:\n" + result.stdout)
            if result.stderr:
                logger.warning("setup.py stderr:\n" + result.stderr)

            # Show meaningful lines to console
            if result.stdout:
                for line in result.stdout.splitlines():
                    stripped = line.strip()
                    if any(k in stripped for k in ("✅", "✓", "⚠", "❌", "Error",
                                                    "created", "skipped", "failed",
                                                    "uploaded", "registered", "logged",
                                                    "ready", "API key")):
                        print(f"  {stripped}")

        setup_elapsed = time.time() - setup_start
        logger.info(f"setup.py completed in {setup_elapsed:.1f}s (exit={result.returncode})")

        if result.returncode != 0:
            print()
            _fail(f"Setup failed (exit code {result.returncode}, {setup_elapsed:.1f}s)")
            if not args.verbose:
                if result.stderr:
                    print(f"\n{_C.DIM}Error output (last 20 lines):{_C.RESET}")
                    for line in result.stderr.strip().splitlines()[-20:]:
                        print(f"  {line}")
                print()
                _info(f"Full logs: {LOG_FILE}")
                _info("Tip: run with --verbose for full output")
                _info("Tip: run with --reset to clear config and retry")
            sys.exit(1)

        print()
        _ok(f"Platform setup complete ({setup_elapsed:.1f}s)")

        # ── Report tenant SDK after setup (may have been installed) ──
        post_versions = _detect_versions()
        if post_versions["tenant_sdks"]:
            for sdk in post_versions["tenant_sdks"]:
                _ok(f"Tenant SDK: {sdk['name']} v{sdk['version']}")
                logger.info(f"Post-setup tenant SDK: {sdk['name']} v{sdk['version']}")
    else:
        _header("Step 4 · Skipped (--server-only)")

    # ── Reload .env after setup ──
    env.reload()

    # Sync ALL .env values into os.environ — always override
    for _k, _v in env.values.items():
        if _k and _v:
            os.environ[_k] = _v

    # ── Regenerate config.js after setup ──
    if project["has_web"]:
        ui_dir = os.path.join(ui_base, "ui")
        meta = _read_app_meta(app_dir)
        env.generate_config_js(
            ui_dir,
            app_name=meta["name"],
            app_emoji=meta["emoji"],
            app_description=meta["description"],
        )
        _ps = env.get("PUBLIC_SCHEMAS", "")
        if _ps:
            os.environ["PUBLIC_SCHEMAS"] = _ps

    # ── Step 4.5: CRUD smoke tests ──
    if not args.server_only and not getattr(args, 'skip_tests', False):
        _ensure_crud_tests(app_dir)
    _crud_tests_path = os.path.join(app_dir, "crud_tests.py")
    if (not args.server_only
            and not getattr(args, 'skip_tests', False)
            and os.path.exists(_crud_tests_path)):
        _header("Step 4.5 · CRUD smoke tests")
        _info("Testing Create, Read, List, Update, Delete on all schemas...")
        print()
        _test_start = time.time()
        if args.verbose:
            _test_result = subprocess.run(
                [sys.executable, "crud_tests.py"], cwd=app_dir
            )
        else:
            _test_result = subprocess.run(
                [sys.executable, "crud_tests.py"], cwd=app_dir,
                capture_output=True, text=True,
            )
            if _test_result.stdout:
                logger.info("crud_tests.py stdout:\n" + _test_result.stdout)
                for _line in _test_result.stdout.splitlines():
                    _s = _line.strip()
                    if _s:
                        print(f"  {_s}")
                    else:
                        print()
            if _test_result.stderr:
                logger.warning("crud_tests.py stderr:\n" + _test_result.stderr)
        _test_elapsed = time.time() - _test_start
        if _test_result.returncode != 0:
            print()
            _fail(f"CRUD smoke tests FAILED ({_test_elapsed:.1f}s) — server launch aborted")
            _info("Fix the failing schemas or use --skip-tests to bypass")
            _info(f"Full logs: {LOG_FILE}")
            sys.exit(1)
        _ok(f"All CRUD smoke tests passed ({_test_elapsed:.1f}s)")

    # ── Step 5: Start server ──
    if not args.setup_only:
        port = args.port or int(env.get("PORT", env.get("UI_PORT", "5648")))

        if not args.docker and not args.server_only and not args.no_interactive:
            launch_mode = _prompt_launch_mode()
            if launch_mode == "docker":
                args.docker = True
            elif launch_mode == "setup":
                _ok("Setup complete! Run ./run.sh to start the server.")
                sys.exit(0)

        if args.docker:
            _header("Step 5 · Starting with Docker")
            meta = _read_app_meta(app_dir)
            _ensure_docker_files(app_dir, env, app_name=meta.get("name", "supero-app"))

            if not os.path.exists(os.path.join(os.getcwd(), ".env")):
                env.save()
                _ok("Created .env for Docker")

            print()
            _info("Building and starting container...")
            _info("This may take a few minutes on first build.")
            print()

            try:
                result = subprocess.run(
                    ["docker", "compose", "up", "--build", "-d"],
                    capture_output=not args.verbose, text=True
                )
                if result.returncode == 0:
                    lan_ip = _get_lan_ip()
                    print()
                    print(f"  {_C.GREEN}{_C.BOLD}✅ CONTAINER RUNNING{_C.RESET}")
                    print()
                    print(f"  {_C.CYAN}Local:{_C.RESET}    http://localhost:{port}")
                    if lan_ip != "0.0.0.0":
                        print(f"  {_C.CYAN}Network:{_C.RESET}  http://{lan_ip}:{port}")
                    print()
                    print(f"  {_C.DIM}View logs:   docker compose logs -f{_C.RESET}")
                    print(f"  {_C.DIM}Stop:        docker compose down{_C.RESET}")
                    print()
                else:
                    _fail("Docker build failed")
                    if not args.verbose and result.stderr:
                        for line in result.stderr.strip().splitlines()[-10:]:
                            print(f"  {line}")
                    _info("Try: docker compose up --build (without -d) for full output")
            except FileNotFoundError:
                _fail("Docker not found. Install: https://docs.docker.com/get-docker/")
                sys.exit(1)

        elif project["has_web"]:
            _header("Step 5 · Starting web server")

            ui_dir = os.path.join(ui_base, "ui")
            server_py = os.path.join(ui_dir, "server.py")

            if not os.path.exists(server_py):
                _fail(f"server.py not found in {ui_dir}")
                sys.exit(1)

            # Check port availability — offer alternatives if busy
            port = _resolve_port(
                port,
                interactive=not args.no_interactive,
            )

            lan_ip = _get_lan_ip()
            admin_email = env.get("SUPERO_ADMIN_EMAIL", "admin@example.com")
            domain = env.get("SUPERO_DOMAIN", "")

            print()
            print(f"  {_C.GREEN}{_C.BOLD}✅ READY{_C.RESET}")
            print()
            print(f"  ┌──────────────────────────────────────────────┐")
            print(f"  │                                              │")
            print(f"  │  {_C.CYAN}Local:{_C.RESET}    http://localhost:{str(port):<17}│")
            if lan_ip != "0.0.0.0":
                print(f"  │  {_C.CYAN}Network:{_C.RESET}  http://{lan_ip}:{str(port):<11}│")
            print(f"  │                                              │")
            if domain:
                print(f"  │  {_C.CYAN}Domain:{_C.RESET}   {domain:<28s}│")
            print(f"  │  {_C.CYAN}Login:{_C.RESET}    {admin_email:<28s}│")
            print(f"  │                                              │")
            print(f"  └──────────────────────────────────────────────┘")
            print()
            print(f"  {_C.DIM}Press Ctrl+C to stop | Logs: .supero-run.log{_C.RESET}")
            print()

            # Update .env if port changed (e.g. busy port fallback)
            orig_port = int(env.get("PORT", env.get("UI_PORT", "5648")))
            if port != orig_port:
                _update_port_in_env(env, port)

            os.environ["PORT"] = str(port)
            os.environ["UI_PORT"] = str(port)

            logger.info(f"Starting server on port {port}")

            try:
                subprocess.run([sys.executable, "server.py"], cwd=ui_dir)
            except KeyboardInterrupt:
                print(f"\n  {_C.DIM}Server stopped.{_C.RESET}")
                logger.info("Server stopped by user (Ctrl+C)")
        else:
            _ok("Setup complete (no web UI to start)")
    else:
        _header("Step 5 · Skipped (--setup-only)")
        _ok("Setup complete. Run without --setup-only to start the server.")

    # ── Mobile setup (optional) ──
    if args.mobile:
        if project.get("has_mobile"):
            _header("Mobile · Setting up Expo app")
            mobile_dir = os.path.join(os.getcwd(), "mobile")
            expo_sh = os.path.join(mobile_dir, "expo.sh")
            if os.path.exists(expo_sh):
                subprocess.run(["bash", expo_sh, "setup"], cwd=mobile_dir)
                _ok("Mobile app ready")
                _info("Start with: cd mobile && ./expo.sh start")
            else:
                _warn("mobile/expo.sh not found")
        else:
            _warn("No mobile app found — skipping")

    logger.info("=== supero.cli finished ===")


if __name__ == "__main__":
    main()
