import asyncio
import dataclasses
import enum
from collections import defaultdict
from collections.abc import Iterable, Mapping
from contextlib import AbstractAsyncContextManager, AbstractContextManager
from http import HTTPStatus
from typing import TYPE_CHECKING, Any, Generic, TypeAlias, TypeVar, final

from typing_extensions import override

from dmr.exceptions import TooManyRequestsError
from dmr.headers import HeaderSpec
from dmr.internal.endpoint import request_endpoint
from dmr.metadata import EndpointMetadata, ResponseSpec, ResponseSpecProvider
from dmr.throttling.algorithms import BaseThrottleAlgorithm, SimpleRate
from dmr.throttling.backends import (
    AsyncDjangoCache,
    BaseThrottleAsyncBackend,
    BaseThrottleSyncBackend,
    SyncDjangoCache,
)
from dmr.throttling.cache_keys import BaseThrottleCacheKey, RemoteAddr
from dmr.throttling.headers import (
    BaseResponseHeadersProvider,
    RetryAfter,
    XRateLimit,
)

if TYPE_CHECKING:
    from dmr.controller import Controller
    from dmr.endpoint import Endpoint
    from dmr.serializer import BaseSerializer

_AnyBackend: TypeAlias = BaseThrottleSyncBackend | BaseThrottleAsyncBackend
_BackendT = TypeVar('_BackendT', bound=_AnyBackend)


@final
@enum.unique
class Rate(enum.IntEnum):
    """
    Throttling rates in seconds.

    Attributes:
        second: 1 second.
        minute: 60 seconds.
        hour: 60 * 60 seconds.
        day: 24 * 60 * 60 seconds.

    """

    second = 1
    minute = 60 * second
    hour = 60 * minute
    day = 24 * hour


class _BaseThrottle(ResponseSpecProvider, Generic[_BackendT]):
    __slots__ = (
        '_algorithm',
        '_async_lock',
        '_backend',
        '_response_headers',
        '_sync_lock',
        'cache_key',
        'duration_in_seconds',
        'max_requests',
    )

    _backend: _BackendT

    def __init__(
        self,
        max_requests: int,
        duration_in_seconds: Rate | int,
        *,
        cache_key: BaseThrottleCacheKey | None = None,
        backend: _BackendT | None = None,
        algorithm: BaseThrottleAlgorithm | None = None,
        response_headers: Iterable[BaseResponseHeadersProvider] | None = None,
    ) -> None:
        """
        Creates new throttling instance.

        Parameters:
            max_requests: Maximum number of requests for the time window.
            duration_in_seconds: Time window in seconds.
            cache_key: Cache key to use.
                Defaults to :class:`~dmr.throttling.cache_keys.RemoteAddr`.
            backend: Storage backend to use.
                Defaults to :class:`~dmr.throttling.backends.SyncDjangoCache`
                for sync endpoints or
                to :class:`~dmr.throttling.backends.AsyncDjangoCache`
                for async endpoints.
            algorithm: Algorithm to use.
                Defaults to :class:`~dmr.throttling.algorithms.SimpleRate`.
            response_headers: Iterable of response headers to use.
                Defaults to a list of
                :class:`~dmr.throttling.headers.XRateLimit`
                and :class:`~dmr.throttling.headers.RetryAfter` instances.

        .. note::

            It is really important for this class to have stateless instances.
            Not even locks can be shared, because these instances can
            be global. It is possible to use them in settings or per controller.
            No state allowed.

        """
        self.max_requests = max_requests
        self.duration_in_seconds = int(duration_in_seconds)
        # Default implementations of the logical parts:
        self.cache_key = cache_key or RemoteAddr()

        default_backend = (
            SyncDjangoCache()
            if isinstance(self, SyncThrottle)
            else AsyncDjangoCache()
        )
        self._backend = backend or default_backend  # type: ignore[assignment]
        self._algorithm = algorithm or SimpleRate()
        self._response_headers = (
            [XRateLimit(), RetryAfter()]
            if response_headers is None
            else response_headers
        )
        # Run check and early initializations:
        self._backend.initialize_algorithm(self._algorithm)

    def full_cache_key(
        self,
        endpoint: 'Endpoint',
        controller: 'Controller[BaseSerializer]',
    ) -> str | None:
        """Get the full cache key value."""
        cache_key = self.cache_key(endpoint, controller)
        if cache_key is None:
            return None

        metadata = endpoint.metadata
        backend_name = type(self._backend).__qualname__
        algorithm_name = type(self._algorithm).__qualname__
        cache_key_name = type(self.cache_key).__qualname__
        # This must ensure that endpoint key is unique:
        return (
            f'{metadata.operation_id}::{metadata.method}::'
            f'{backend_name}::{algorithm_name}::'
            f'{cache_key_name}::{cache_key}::'
            f'{self.max_requests}::{self.duration_in_seconds}'
        )

    @override
    def provide_response_specs(
        self,
        metadata: EndpointMetadata,
        controller_cls: type['Controller[BaseSerializer]'],
        existing_responses: Mapping[HTTPStatus, ResponseSpec],
    ) -> list[ResponseSpec]:
        """Provides responses that can happen when throttle triggers."""
        return self._add_new_response(
            ResponseSpec(
                controller_cls.error_model,
                status_code=TooManyRequestsError.status_code,
                headers=self._headers_spec(),
                description='Raised when throttling rate was hit',
            ),
            existing_responses,
        )

    def collect_response_headers(
        self,
        endpoint: 'Endpoint',
        controller: 'Controller[BaseSerializer]',
        remaining: int,
        reset: int,
        *,
        report_all: bool = False,
    ) -> dict[str, str]:
        """Collects response headers for all ``response_headers`` classes."""
        response_headers: dict[str, str] = {}
        for header_provider in self._response_headers:
            response_headers.update(
                header_provider.response_headers(
                    endpoint,
                    controller,
                    self,
                    remaining,
                    reset,
                    report_all=report_all,
                ),
            )
        return response_headers

    def _headers_spec(self) -> dict[str, HeaderSpec]:
        headers_spec: dict[str, HeaderSpec] = {}
        for header_provider in self._response_headers:
            headers_spec.update(header_provider.provide_headers_specs())
        return headers_spec


class SyncThrottle(_BaseThrottle[BaseThrottleSyncBackend]):
    """
    Sync throttle type for sync endpoints.

    .. versionadded:: 0.7.0
    """

    __slots__ = ()

    def __call__(
        self,
        endpoint: 'Endpoint',
        controller: 'Controller[BaseSerializer]',
        lock: AbstractContextManager[Any, Any],
    ) -> None:
        """
        Put your throttle business logic here.

        Return ``None`` if throttle check passed.
        Raise :exc:`dmr.exceptions.TooManyRequestsError`
        if throttle check failed.
        Raise :exc:`dmr.response.APIError`
        if you want to change the return code, for example,
        when some data is missing or has wrong format.
        """
        cache_key = self.full_cache_key(endpoint, controller)
        if cache_key is None:
            return
        with lock:
            self.check(endpoint, controller, cache_key)

    def check(
        self,
        endpoint: 'Endpoint',
        controller: 'Controller[BaseSerializer]',
        cache_key: str,
    ) -> None:
        """Check whether this request has rate limiting quota left."""
        # NOTE: this is locked on endpoint.py level, don't worry:
        self._backend.incr(
            endpoint,
            controller,
            self,
            cache_key=cache_key,
            algorithm=self._algorithm,
        )

    def report_usage(
        self,
        endpoint: 'Endpoint',
        controller: 'Controller[BaseSerializer]',
    ) -> dict[str, str]:
        """Report throttle usage stats."""
        cache_key = self.full_cache_key(endpoint, controller)
        if cache_key is None:
            return {}
        return self._algorithm.report_usage(
            endpoint,
            controller,
            self,
            self._backend.get(endpoint, controller, self, cache_key=cache_key),
        )


class AsyncThrottle(_BaseThrottle[BaseThrottleAsyncBackend]):
    """
    Async throttle type for async endpoints.

    .. versionadded:: 0.7.0
    """

    __slots__ = ()

    async def __call__(
        self,
        endpoint: 'Endpoint',
        controller: 'Controller[BaseSerializer]',
        lock: AbstractAsyncContextManager[Any, Any],
    ) -> None:
        """
        Put your throttle business logic here.

        Return ``None`` if throttle check passed.
        Raise :exc:`dmr.exceptions.TooManyRequestsError`
        if throttle check failed.
        Raise :exc:`dmr.response.APIError`
        if you want to change the return code, for example,
        when some data is missing or has wrong format.
        """
        cache_key = self.full_cache_key(endpoint, controller)
        if cache_key is None:
            return
        async with lock:
            await self.check(endpoint, controller, cache_key)

    async def check(
        self,
        endpoint: 'Endpoint',
        controller: 'Controller[BaseSerializer]',
        cache_key: str,
    ) -> None:
        """Check whether this request has rate limiting quota left."""
        # NOTE: this is locked on endpoint.py level, don't worry:
        await self._backend.incr(
            endpoint,
            controller,
            self,
            cache_key=cache_key,
            algorithm=self._algorithm,
        )

    async def report_usage(
        self,
        endpoint: 'Endpoint',
        controller: 'Controller[BaseSerializer]',
    ) -> dict[str, str]:
        """Async report throttle usage stats."""
        cache_key = self.full_cache_key(endpoint, controller)
        if cache_key is None:
            return {}
        return self._algorithm.report_usage(
            endpoint,
            controller,
            self,
            await self._backend.get(
                endpoint,
                controller,
                self,
                cache_key=cache_key,
            ),
        )


@dataclasses.dataclass(slots=True, frozen=True)
class ThrottlingReport:
    """
    Get throttling data to be reported in response headers.

    Unlike :exc:`dmr.exceptions.TooManyRequestsError`,
    which reports the first stat for throttle that is failing,
    it reports all stats for all throttles.

    It will make N (which is the number of throttles) requests to cache.

    .. warning::

        This class does not handle exceptions at all.
        Because we don't know how to report headers
        for failing cache connections.
        If you want to handle errors, catch them explicitly.

    .. versionadded:: 0.7.0
    """

    controller: 'Controller[BaseSerializer]'

    def report(self) -> dict[str, str]:
        """
        Report throttling all headers for a sync controller and endpoint.

        Note that it will make N consecutive requests to cache.
        It might be rather long. Use the sync version with care.
        """
        endpoint = self._get_endpoint()
        if not endpoint.metadata.throttling:
            return {}

        result_headers: defaultdict[str, list[str]] = defaultdict(list)
        for throttle in endpoint.metadata.throttling:
            # for mypy: we are sure that it is sync now
            assert isinstance(throttle, SyncThrottle)  # noqa: S101
            for header_name, header_value in throttle.report_usage(
                endpoint,
                self.controller,
            ).items():
                result_headers[header_name].append(header_value)
        return self._format_headers(result_headers)

    async def areport(self) -> dict[str, str]:
        """
        Report throttling all headers for a async controller and endpoint.

        Unlike sync version it makes parallel requests to cache
        by utilizing :func:`asyncio.gather` function inside.
        """
        endpoint = self._get_endpoint()
        if not endpoint.metadata.throttling:
            return {}

        result_headers: defaultdict[str, list[str]] = defaultdict(list)

        # We can run all tasks in "parallel":
        for report in await asyncio.gather(*[
            throttle.report_usage(endpoint, self.controller)
            for throttle in endpoint.metadata.throttling
            if isinstance(throttle, AsyncThrottle)
        ]):
            for header_name, header_value in report.items():
                result_headers[header_name].append(header_value)
        return self._format_headers(result_headers)

    def _get_endpoint(self) -> 'Endpoint':
        return request_endpoint(self.controller.request, strict=True)

    def _format_headers(
        self,
        headers: defaultdict[str, list[str]],
    ) -> dict[str, str]:
        return {
            header_name: ', '.join(header_value)
            for header_name, header_value in headers.items()
        }
