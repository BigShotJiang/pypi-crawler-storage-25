"""EventGraph — the main entry point for building event-driven graphs."""

from __future__ import annotations

import dataclasses
import typing
import warnings
from typing import TYPE_CHECKING, Any, NamedTuple, TypedDict, cast

from langgraph.graph import END, START, StateGraph
from langgraph.types import Command as LGCommand

from langgraph_events._custom_event import STATE_SNAPSHOT_EVENT_NAME
from langgraph_events._event import (
    _NAMESPACE_REGISTRY,
    Command,
    DomainEvent,
    Event,
    Halted,
    HandlerRaised,
    Interrupted,
    Invariant,
    InvariantViolated,
    Namespace,
    Scatter,
)
from langgraph_events._event_log import EventLog
from langgraph_events._handler import (
    HandlerMeta,
    _resolve_type_hints,
    extract_handler_meta,
    on,
)
from langgraph_events._internal import (
    _BASE_FIELDS,
    _InputState,
    _OutputState,
    build_state_schema,
    make_dispatch,
    make_handler_node,
    make_router_node,
    make_seed_node,
)
from langgraph_events._namespace import NamespaceModel

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Callable, Iterator

    from langchain_core.runnables import RunnableConfig
    from langgraph.graph.state import CompiledStateGraph
    from langgraph.store.base import BaseStore

    from langgraph_events._reducer import BaseReducer


class OrphanedEventWarning(UserWarning):
    """Issued when handler return types have no matching subscriber."""


def _any_catcher_covers(
    catchers: list[tuple[HandlerMeta, type[Exception] | None]],
    exc_type: type[Exception],
) -> bool:
    """Return True if any catcher would handle *exc_type*."""
    for _meta, exc_filter in catchers:
        if exc_filter is None or issubclass(exc_type, exc_filter):
            return True
    return False


class ReturnInfo(NamedTuple):
    """Parsed handler return-type annotation."""

    event_types: list[type[Event]]
    scatter_types: list[type[Event]]
    has_scatter: bool
    has_interrupted: bool
    has_annotation: bool


class ReturnContract(NamedTuple):
    """Runtime contract for what a handler may legally return.

    Computed at ``EventGraph`` construction; enforced in ``_collect_result``.
    ``None`` → no enforcement (legacy shape-only check).
    """

    types: tuple[type, ...]
    """Allowed concrete event types for non-Scatter returns."""

    scatter_types: tuple[type, ...] | None
    """Allowed element types for Scatter returns. None = no check."""

    source: str
    """Human-readable origin of the contract, used in error messages."""


def _parse_return_types(fn: Callable[..., Any]) -> ReturnInfo:
    """Parse handler return annotation into a ``ReturnInfo``."""
    try:
        hints = _resolve_type_hints(fn)
    except Exception as exc:
        warnings.warn(
            f"Failed to resolve return type hints for handler {fn.__qualname__!r}; "
            f"treating as unannotated for topology parsing. ({exc})",
            stacklevel=3,
        )
        hints = {}

    return_hint = hints.get("return")
    if return_hint is None:
        return ReturnInfo([], [], False, False, False)

    # If the top-level hint is Scatter[X], wrap it so the loop sees Scatter[X]
    # as a single candidate (otherwise get_args returns the type params).
    origin = typing.get_origin(return_hint)
    if origin is Scatter:
        candidates = (return_hint,)
    else:
        args = typing.get_args(return_hint)
        candidates = args if args else (return_hint,)

    event_types: list[type[Event]] = []
    scatter_types: list[type[Event]] = []
    has_scatter = False
    has_interrupted = False
    for arg in candidates:
        if arg is type(None):
            continue
        if arg is Scatter:
            has_scatter = True
        elif typing.get_origin(arg) is Scatter:
            # Parameterized Scatter[X] — extract event types
            for scatter_arg in typing.get_args(arg):
                if isinstance(scatter_arg, type) and issubclass(scatter_arg, Event):
                    scatter_types.append(scatter_arg)
        elif isinstance(arg, type) and issubclass(arg, Event):
            if issubclass(arg, Interrupted):
                has_interrupted = True
            event_types.append(arg)

    return ReturnInfo(event_types, scatter_types, has_scatter, has_interrupted, True)


class GraphState(NamedTuple):
    """Event-focused snapshot of a checkpointed thread."""

    events: EventLog
    is_interrupted: bool
    interrupted: Interrupted | None


class StreamFrame(NamedTuple):
    """A yielded frame from ``stream_events()`` when ``include_reducers`` is enabled.

    Contains the event and a snapshot of all requested reducer values at
    the point the event was produced.
    """

    event: Event
    reducers: dict[str, list[Any]]
    changed_reducers: frozenset[str] | None = None


class LLMToken(NamedTuple):
    """A text delta from an LLM invocation during handler execution."""

    run_id: str
    content: str


class LLMStreamEnd(NamedTuple):
    """Signals an LLM stream completed."""

    run_id: str
    message_id: str | None  # LangChain AIMessage.id for dedup


class LLMToolCallChunk(NamedTuple):
    """A tool-call chunk from an LLM stream.

    First chunk for a given ``call_index`` carries ``tool_call_id`` and
    ``name``; subsequent chunks may have those as empty strings and only
    carry ``args_delta`` (a partial JSON string). ``call_index`` is
    LangChain's ``tool_call_chunks[i].index`` — it groups chunks that
    belong to the same call when the LLM emits multiple in parallel.
    """

    run_id: str
    call_index: int
    tool_call_id: str
    name: str
    args_delta: str


class CustomEventFrame(NamedTuple):
    """A custom event frame emitted from LangGraph's v2 stream API."""

    name: str
    data: Any


class StateSnapshotFrame(NamedTuple):
    """A typed state snapshot custom frame emitted from v2 stream events."""

    data: dict[str, Any]


StreamItem = (
    Event
    | StreamFrame
    | LLMToken
    | LLMStreamEnd
    | LLMToolCallChunk
    | CustomEventFrame
    | StateSnapshotFrame
)


def _coerce_snapshot_data(data: Any) -> dict[str, Any]:
    if isinstance(data, dict):
        return cast("dict[str, Any]", data)
    return {}


def _compute_return_contract(
    meta: HandlerMeta, info: ReturnInfo
) -> ReturnContract | None:
    """Derive the runtime return-contract for a handler.

    Priority:
    1. Explicit return annotation — authoritative.
    2. ``Command.Outcomes`` inferred from subscribed event types.
    3. No contract (legacy shape-only check in ``_collect_result``).
    """
    if info.has_annotation:
        union_desc = " | ".join(t.__name__ for t in info.event_types) or "None"
        return ReturnContract(
            types=tuple(info.event_types),
            scatter_types=tuple(info.scatter_types) if info.scatter_types else None,
            source=f"declared return type `{union_desc}`",
        )

    outcomes: list[type] = []
    command_names: list[str] = []
    for et in meta.event_types:
        if not (isinstance(et, type) and issubclass(et, Command)):
            continue
        outs = getattr(et, "Outcomes", None)
        if outs is None:
            continue
        args = typing.get_args(outs) or (outs,)
        for t in args:
            if isinstance(t, type) and t not in outcomes:
                outcomes.append(t)
        command_names.append(et.__qualname__)

    if not outcomes:
        return None

    sources = ", ".join(command_names)
    return ReturnContract(
        types=tuple(outcomes),
        scatter_types=None,
        source=f"outcomes of {sources}",
    )


def _verify_inline_outcome_coverage(meta: HandlerMeta, info: ReturnInfo) -> None:
    """For inline ``handle`` handlers with an explicit return annotation,
    require the annotation to cover every nested ``DomainEvent`` of the
    owning ``Command``.

    External ``@on(Cmd)`` handlers are intentionally exempt: outcome
    production can be distributed across multiple handlers (e.g. one
    handler returns ``Placed``, another reacts to ``InvariantViolated``
    and produces ``Rejected``). Inline ``handle`` is the "I own this
    command end-to-end" form, so dropping an outcome there is almost
    always a mistake.

    No annotation → skipped; the contract falls back to ``Command.Outcomes``.
    """
    cmd = getattr(meta.fn, "_inline_command", None)
    if cmd is None or not info.has_annotation:
        return
    nested_outcomes = [
        t
        for t in cmd.__dict__.values()
        if isinstance(t, type) and issubclass(t, Event) and issubclass(t, DomainEvent)
    ]
    if not nested_outcomes:
        return
    covered = tuple(info.event_types) + tuple(info.scatter_types)
    missing = [o for o in nested_outcomes if not any(issubclass(c, o) for c in covered)]
    if not missing:
        return
    declared = " | ".join(t.__name__ for t in covered) or "(no types)"
    missing_names = ", ".join(o.__name__ for o in missing)
    raise TypeError(
        f"Inline `handle` on {cmd.__qualname__} declares return type "
        f"`{declared}` but does not cover outcome(s): {missing_names}. "
        f"Add them to the annotation (e.g. `-> "
        f"{' | '.join(o.__name__ for o in nested_outcomes)}`) or drop "
        f"the annotation to let Outcomes drive the contract."
    )


def _discover_namespace_reducers(
    handlers: list[Callable[..., Any]],
    explicit_reducers: dict[str, BaseReducer],
) -> None:
    """Auto-register reducers declared on domains referenced by handlers.

    Walks each handler's ``_event_types`` (set by ``@on(...)``), finds the
    owning domain via ``__namespace__`` + ``_NAMESPACE_REGISTRY``, and unions that
    domain's ``__reducers__`` into *explicit_reducers*.

    Collisions:
    - Two different discovered reducers with the same name → ``TypeError``.
    - Explicit reducer (already in the dict) shares a name with a discovered
      one → explicit wins; discovered one is skipped silently.
    """
    discovered: dict[str, BaseReducer] = {}
    for fn in handlers:
        for et in getattr(fn, "_event_types", ()):
            namespace_name = getattr(et, "__namespace__", None)
            if not namespace_name:
                continue
            namespace_cls = _NAMESPACE_REGISTRY.get(namespace_name)
            if namespace_cls is None:
                continue
            for r in namespace_cls.__reducers__:
                existing = discovered.get(r.name)
                if existing is None:
                    discovered[r.name] = r
                elif existing is not r:
                    raise TypeError(
                        f"Reducer name {r.name!r} collides between domains: "
                        f"{existing!r} and {r!r}"
                    )
    # Merge into explicit; explicit wins on name conflict.
    for name, r in discovered.items():
        explicit_reducers.setdefault(name, r)


def _expand_command_handlers(
    handlers: list[Any],
) -> list[Callable[..., Any]]:
    """Replace ``Command`` subclasses with their inline ``handle`` functions.

    Each substituted function is stamped via ``on(cls)(fn)`` so that
    ``extract_handler_meta`` sees it like any other ``@on``-subscribed
    handler. Raises ``TypeError`` if a Command subclass has no ``handle``.
    """
    expanded: list[Callable[..., Any]] = []
    for h in handlers:
        if isinstance(h, type) and issubclass(h, Command):
            fn = getattr(h, "__command_handler__", None)
            if fn is None:
                raise TypeError(
                    f"Command {h.__qualname__} has no `handle` method. "
                    f"Either define `handle` inside the command class or "
                    f"register a handler via @on({h.__qualname__})."
                )
            existing = getattr(fn, "_inline_command", None)
            if existing is not None and existing is not h:
                raise TypeError(
                    f"Command {h.__qualname__}'s `handle` is already bound "
                    f"to {existing.__qualname__}. This happens if you alias "
                    f"`handle` across Command classes — define each "
                    f"Command's `handle` in its own class body."
                )
            on(h)(fn)  # sets fn._event_types = (h,); idempotent
            fn._inline_command = h
            expanded.append(fn)
        else:
            expanded.append(h)
    return expanded


class EventGraph:
    """Build and run an event-driven graph from ``@on`` handlers.

    Topology is auto-derived from handler subscriptions.  Internally builds
    a LangGraph ``StateGraph`` with a hub-and-spoke reactive loop.

    Accepts a single seed event or a list of seed events::

        graph = EventGraph([classify, route, review])

        # Single seed event
        log = graph.invoke(DocumentReceived(doc_id="1", content="..."))

        # Multiple seed events (e.g. system prompt + user message)
        log = graph.invoke([
            SystemPromptSet.from_str("You are helpful"),
            UserMessageReceived(message=HumanMessage(content="Hi")),
        ])
    """

    def __init__(
        self,
        handlers: list[Callable[..., Any]],
        *,
        max_rounds: int = 100,
        reducers: list[BaseReducer] | None = None,
        checkpointer: Any = None,
        store: BaseStore | None = None,
        recursion_limit: int | None = None,
    ) -> None:
        if not handlers:
            raise ValueError("EventGraph requires at least one handler")

        handlers = _expand_command_handlers(handlers)

        self._max_rounds = max_rounds
        self._recursion_limit = recursion_limit
        self._checkpointer = checkpointer
        self._store = store
        self._reducers: dict[str, BaseReducer] = {r.name: r for r in (reducers or [])}
        _discover_namespace_reducers(handlers, self._reducers)
        conflicts = set(self._reducers.keys()) & set(_BASE_FIELDS.keys())
        if conflicts:
            raise ValueError(
                f"Reducer name(s) {conflicts} conflict with reserved state fields"
            )
        self._handler_metas: list[HandlerMeta] = []
        self._compiled_graph: CompiledStateGraph | None = None

        reducer_names = frozenset(self._reducers.keys())
        seen_names: dict[str, int] = {}
        for fn in handlers:
            meta = extract_handler_meta(fn, reducer_names=reducer_names)
            # Deduplicate node names — preserve all other meta fields
            # (raises, field_matchers, field_inject_params, ...) so the second
            # copy behaves identically to the first.
            if meta.name in seen_names:
                seen_names[meta.name] += 1
                meta = dataclasses.replace(
                    meta, name=f"{meta.name}_{seen_names[meta.name]}"
                )
            else:
                seen_names[meta.name] = 1
            self._handler_metas.append(meta)

        self._return_info: dict[str, ReturnInfo] = {}
        self._return_contracts: dict[str, ReturnContract | None] = {}
        for meta in self._handler_metas:
            info = _parse_return_types(meta.fn)
            self._return_info[meta.name] = info
            if info.has_annotation and any(t is Event for t in info.event_types):
                raise ValueError(
                    f"Handler '{meta.name}' return type includes base 'Event'. "
                    f"Use specific types (e.g., TypeA | TypeB)."
                )
            self._return_contracts[meta.name] = _compute_return_contract(meta, info)
            _verify_inline_outcome_coverage(meta, info)

        # Warn about event types that are produced but never consumed
        subscribed: set[type[Event]] = set()
        for meta in self._handler_metas:
            subscribed.update(meta.event_types)
        produced: set[type[Event]] = set()
        for info in self._return_info.values():
            produced.update(info.event_types)
            produced.update(info.scatter_types)
        orphaned = {
            t
            for t in produced
            if not issubclass(t, (Halted, Interrupted))
            # A DomainEvent owned by a Namespace or Command — as an outcome
            # (__command__ set) or as a free-standing domain fact
            # (__namespace__ set) — is a terminal by design; having no
            # subscriber is idiomatic, not an orphan.
            and not (
                issubclass(t, DomainEvent)
                and (
                    getattr(t, "__command__", None) is not None
                    or getattr(t, "__namespace__", None) is not None
                )
            )
            and not any(issubclass(t, s) for s in subscribed)
        }
        if orphaned:
            names = ", ".join(sorted(t.__name__ for t in orphaned))
            warnings.warn(
                f"Event type(s) {names} are returned by handlers but no handler "
                f"subscribes to them. These events will be produced but never "
                f"processed.",
                category=OrphanedEventWarning,
                stacklevel=2,
            )

        self._verify_raises_coverage()
        self._verify_invariants_coverage()

    def namespaces(self) -> NamespaceModel:
        """Return a :class:`NamespaceModel` — the code-derived snapshot.

        One artifact covers the full picture: domains, commands, outcomes,
        command handlers, policies, event-to-event edges, and seed events.
        Render it via :meth:`NamespaceModel.text`, :meth:`NamespaceModel.mermaid`
        (with ``view="structure"`` or ``view="choreography"``),
        :meth:`NamespaceModel.json`, or read the data attributes directly.
        """
        return NamespaceModel._build(self._handler_metas, self._return_info)

    @property
    def reducer_names(self) -> frozenset[str]:
        """The names of all registered reducers."""
        return frozenset(self._reducers.keys())

    @property
    def compiled(self) -> CompiledStateGraph:
        """The underlying LangGraph ``CompiledStateGraph``.

        This is the bridge to full LangGraph when you need features
        beyond the EventGraph API: subgraph composition, custom
        streaming modes, direct state access, or advanced checkpointer
        workflows.

        The instance is compiled lazily on first access and cached.
        """
        return self._compile()

    def _compile(self) -> CompiledStateGraph:
        """Compile into a LangGraph ``CompiledStateGraph`` (internal)."""
        if self._compiled_graph is not None:
            return self._compiled_graph

        # Dynamic state schema with per-reducer channels
        state_schema = build_state_schema(self._reducers)

        # Always include reducer channels — filtering is an output concern
        out_schema: Any = _OutputState
        if self._reducers:
            reducer_fields: dict[str, Any] = {"events": list[Event]}
            for name, r in self._reducers.items():
                reducer_fields[name] = r.output_type()
            _OutputWithReducers = TypedDict("_OutputWithReducers", reducer_fields)  # type: ignore[misc]
            out_schema = _OutputWithReducers

        graph: StateGraph[Any] = StateGraph(
            state_schema,
            input_schema=_InputState,  # type: ignore[arg-type]
            output_schema=out_schema,
        )

        # --- nodes ---
        seed_node = make_seed_node(reducers=self._reducers)
        router_node = make_router_node(self._max_rounds)
        dispatch_fn = make_dispatch(self._handler_metas)

        graph.add_node("__seed__", cast("Any", seed_node))
        graph.add_node("__router__", cast("Any", router_node))

        handler_names: list[str] = []
        for meta in self._handler_metas:
            handler_node = make_handler_node(
                meta,
                reducers=self._reducers,
                return_contract=self._return_contracts.get(meta.name),
            )
            graph.add_node(meta.name, cast("Any", handler_node))
            handler_names.append(meta.name)

        # --- edges ---
        graph.add_edge(START, "__seed__")

        # dispatch from seed and from router
        destinations = [*handler_names, END]
        graph.add_conditional_edges("__seed__", dispatch_fn, destinations)
        graph.add_conditional_edges("__router__", dispatch_fn, destinations)

        # all handlers fan-in back to router
        for name in handler_names:
            graph.add_edge(name, "__router__")

        compile_kwargs: dict[str, Any] = {}
        if self._checkpointer is not None:
            compile_kwargs["checkpointer"] = self._checkpointer
        if self._store is not None:
            compile_kwargs["store"] = self._store
        self._compiled_graph = graph.compile(**compile_kwargs)

        # Resolve recursion_limit: explicit kwarg wins; otherwise auto-size
        # so LangGraph's limit never trips before our max_rounds does.
        # Each round is at most 1 router + all handlers.
        if self._recursion_limit is not None:
            limit = self._recursion_limit
        else:
            n_handlers = len(self._handler_metas)
            needed = self._max_rounds * (n_handlers + 1) + 1
            existing = (self._compiled_graph.config or {}).get("recursion_limit", 25)
            limit = max(needed, existing)
        self._compiled_graph.config = {
            **(self._compiled_graph.config or {}),
            "recursion_limit": limit,
        }

        return self._compiled_graph

    def _verify_raises_coverage(self) -> None:
        """Ensure every declared ``raises=`` entry has a matching catcher.

        A catcher is a handler subscribed to ``HandlerRaised``. Its coverage:
        - no field matchers at all → covers any raise
        - ``exception=X`` as the only field matcher → covers any ``exc_type``
          with ``issubclass(exc_type, X)``

        Catchers with any non-``exception`` field matcher (e.g.
        ``source_event=SomeType``) are conservatively ignored for coverage,
        because such a matcher can silently exclude legitimate raises at
        runtime. The user must either drop the extra filter or add a broader
        catcher.

        Raises ``TypeError`` at compile time (first ``invoke()`` / ``compile()``)
        if any declared exception is uncovered.
        """
        catchers: list[tuple[HandlerMeta, type[Exception] | None]] = []
        for meta in self._handler_metas:
            if HandlerRaised not in meta.event_types:
                continue
            # A catcher counts only if its sole field matcher is
            # exception=<ExceptionType>. Any other field matcher, or a
            # non-type (str) matcher on exception=, is conservatively ignored.
            type_exception_match = None
            has_other = False
            for fname, matcher, is_type in meta.field_matchers:
                if fname == "exception" and is_type:
                    type_exception_match = cast("type[Exception]", matcher)
                else:
                    has_other = True
            if has_other:
                continue
            catchers.append((meta, type_exception_match))

        for meta in self._handler_metas:
            for exc_type in meta.raises:
                if not _any_catcher_covers(catchers, exc_type):
                    declared = ", ".join(t.__name__ for t in meta.raises)
                    raise TypeError(
                        f"Handler {meta.name!r} declares raises=({declared}), "
                        f"but no handler subscribes to catch {exc_type.__name__}. "
                        f"Add a handler decorated with "
                        f"@on(HandlerRaised, exception={exc_type.__name__}) "
                        f"(or @on(HandlerRaised) to catch all), or remove the "
                        f"type from raises=. Note: catchers with non-exception "
                        f"field matchers (e.g. source_event=SomeType) do not "
                        f"count toward coverage."
                    )

    def _verify_invariants_coverage(self) -> None:
        """Ensure every ``@on(InvariantViolated, invariant=X)`` matcher
        references an ``X`` declared by some handler's ``invariants=``.

        Unlike ``raises=``, a missing reactor is fine — unhandled violations
        just land in the log. The failure mode this check prevents is the
        reverse: a reactor pinned to an invariant class that no one declares
        is dead code (same silent no-op the old string API had).

        Raises ``TypeError`` at compile time if any pinned reactor references
        an undeclared invariant class.
        """
        declared: set[type[Invariant]] = set()
        for meta in self._handler_metas:
            for inv_cls, _pred in meta.invariants:
                declared.add(inv_cls)

        for meta in self._handler_metas:
            if InvariantViolated not in meta.event_types:
                continue
            for fname, matcher, is_type in meta.field_matchers:
                if fname != "invariant" or not is_type:
                    continue
                inv_cls = cast("type[Invariant]", matcher)
                if inv_cls not in declared:
                    raise TypeError(
                        f"Handler {meta.name!r} subscribes to "
                        f"@on(InvariantViolated, invariant={inv_cls.__name__}), "
                        f"but no handler declares {inv_cls.__name__} in "
                        f"invariants=. The reactor would never fire — add the "
                        f"invariant to some handler's invariants= dict, or "
                        f"remove the matcher."
                    )

    def _require_checkpointer(self, method: str) -> None:
        if self._checkpointer is None:
            raise ValueError(f"{method}() requires a checkpointer")

    @staticmethod
    def _prepare_input(seed: Event | list[Event]) -> dict[str, Any]:
        """Build the input dict from a seed event or list of events."""
        if isinstance(seed, list):
            return {"events": seed}
        return {"events": [seed]}

    def _run(self, inp: Any, **kwargs: Any) -> EventLog:
        compiled = self._compile()
        result = compiled.invoke(inp, **kwargs)
        return EventLog._from_owned(result["events"])

    async def _arun(self, inp: Any, **kwargs: Any) -> EventLog:
        compiled = self._compile()
        result = await compiled.ainvoke(inp, **kwargs)
        return EventLog._from_owned(result["events"])

    @classmethod
    def from_namespaces(
        cls,
        *domains: type[Namespace],
        handlers: list[Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> EventGraph:
        """Build an ``EventGraph`` from domains' inline command handlers.

        Walks each domain's class namespace and registers every ``Command``
        that defines a ``handle`` method. Commands without ``handle`` are
        silently skipped — register those via the ``handlers=`` kwarg or
        ``EventGraph([...])`` directly, which errors on missing ``handle``.

        The ``handlers=`` kwarg is appended as-is — useful for reaction
        handlers subscribed to ``DomainEvent``s, ``HandlerRaised``,
        ``InvariantViolated``, etc.

        Example::

            graph = EventGraph.from_namespaces(Order, Customer,
                                            handlers=[react])
        """
        collected: list[Any] = []
        for dom in domains:
            if not (isinstance(dom, type) and issubclass(dom, Namespace)):
                raise TypeError(
                    f"from_namespaces expects Namespace subclasses, got {dom!r}"
                )
            for attr in dom.__dict__.values():
                if (
                    isinstance(attr, type)
                    and issubclass(attr, Command)
                    and getattr(attr, "__command_handler__", None) is not None
                ):
                    collected.append(attr)
        if handlers:
            collected.extend(handlers)
        return cls(collected, **kwargs)

    def invoke(self, seed: Event | list[Event], **kwargs: Any) -> EventLog:
        """Run the graph synchronously with one or more seed events.

        Args:
            seed: A single event or list of events to start the graph.

        Returns an ``EventLog`` containing all events produced during the run.
        """
        return self._run(self._prepare_input(seed), **kwargs)

    async def ainvoke(self, seed: Event | list[Event], **kwargs: Any) -> EventLog:
        """Run the graph asynchronously with one or more seed events."""
        return await self._arun(self._prepare_input(seed), **kwargs)

    def pre_seed(self, config: RunnableConfig, values: dict[str, Any]) -> None:
        """Inject external state into reducer channels before the first run.

        Use this to hydrate reducers from an external source (e.g. a database
        migration or test fixture) when modelling the data as seed events isn't
        practical.  Call it once before ``invoke``/``ainvoke``::

            graph.pre_seed(config, {"my_reducer": existing_value})
            graph.invoke(StartEvent(), config=config)

        Requires a checkpointer.
        """
        self._require_checkpointer("pre_seed")
        compiled = self._compile()
        compiled.update_state(config, values, as_node="__seed__")

    async def apre_seed(self, config: RunnableConfig, values: dict[str, Any]) -> None:
        """Async version of :meth:`pre_seed`."""
        self._require_checkpointer("apre_seed")
        compiled = self._compile()
        await compiled.aupdate_state(config, values, as_node="__seed__")

    def resume(self, value: Event, **kwargs: Any) -> EventLog:
        """Resume an interrupted graph with a domain event.

        The event is auto-dispatched (handlers subscribed to its type fire),
        then a ``Resumed`` event is created alongside it.
        """
        self._require_checkpointer("resume")
        return self._run(LGCommand(resume=value), **kwargs)

    async def aresume(self, value: Event, **kwargs: Any) -> EventLog:
        """Async version of resume().

        The event is auto-dispatched (handlers subscribed to its type fire),
        then a ``Resumed`` event is created alongside it.
        """
        self._require_checkpointer("aresume")
        return await self._arun(LGCommand(resume=value), **kwargs)

    def get_state(self, config: Any) -> GraphState:
        """Get event-level state of a checkpointed thread."""
        self._require_checkpointer("get_state")
        compiled = self._compile()
        snapshot = compiled.get_state(config)
        all_events = snapshot.values.get("events", [])
        log = EventLog(all_events)
        # Determine interrupt status from the snapshot.
        # snapshot.tasks[*].interrupts distinguishes real interrupts from
        # cancelled/crashed graphs (which also have snapshot.next set).
        has_interrupt = any(getattr(task, "interrupts", ()) for task in snapshot.tasks)
        is_interrupted = bool(snapshot.next) and has_interrupt
        return GraphState(
            events=log,
            is_interrupted=is_interrupted,
            interrupted=log.latest(Interrupted) if is_interrupted else None,
        )

    # --- LLM token helpers ---

    @staticmethod
    def _extract_text_content(chunk: Any) -> str:
        """Extract text from a LangChain chat model stream chunk."""
        content = getattr(chunk, "content", None)
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for item in content:
                if isinstance(item, str):
                    parts.append(item)
                elif isinstance(item, dict) and item.get("type") == "text":
                    text = item.get("text")
                    if isinstance(text, str):
                        parts.append(text)
            return "".join(parts)
        return ""

    def _update_reducer_state(
        self,
        state: dict[str, Any],
        event: Event,
        reducer_names: list[str],
    ) -> frozenset[str]:
        """Incrementally update reducer state with a single new event."""
        changed: set[str] = set()
        for name in reducer_names:
            r = self._reducers[name]
            contribution = r.collect([event])
            if r.has_contributions(contribution):
                reducer_fn = getattr(r, "reducer", None)
                if callable(reducer_fn):
                    state[name] = reducer_fn(state[name], contribution)
                else:
                    state[name] = contribution
                changed.add(name)
        return frozenset(changed)

    # --- High-level event streaming ---

    def _resolve_reducer_names(self, include_reducers: bool | list[str]) -> list[str]:
        """Return reducer names to include, or empty list for disabled."""
        if include_reducers is True:
            return list(self._reducers.keys())
        if include_reducers:  # non-empty list
            unknown = set(include_reducers) - set(self._reducers.keys())
            if unknown:
                warnings.warn(
                    f"Unknown reducer name(s) {unknown} in include_reducers; "
                    f"available: {set(self._reducers.keys())}",
                    stacklevel=2,
                )
            return [n for n in include_reducers if n in self._reducers]
        return []

    @staticmethod
    def _events_from_chunk(chunk: Any, seen: set[int]) -> list[Event]:
        """Extract unseen events from an updates-mode stream chunk."""
        events: list[Event] = []
        if isinstance(chunk, dict):
            for node_output in chunk.values():
                if isinstance(node_output, dict):
                    for event in node_output.get("events", []):
                        eid = id(event)
                        if eid not in seen:
                            seen.add(eid)
                            events.append(event)
        return events

    def _frames_from_values(
        self,
        state: dict[str, Any],
        prev_count: int,
        reducer_names: list[str],
    ) -> tuple[int, list[StreamFrame]]:
        """Extract new events and reducer snapshots from a values-mode state."""
        all_events: list[Event] = state.get("events", [])
        new_events = all_events[prev_count:]
        if not new_events:
            return prev_count, []
        reducers = {
            name: state.get(name, self._reducers[name].empty) for name in reducer_names
        }
        return len(all_events), [
            StreamFrame(event=e, reducers=reducers, changed_reducers=None)
            for e in new_events
        ]

    async def _astream_v2(  # noqa: PLR0912, PLR0915
        self,
        inp: Any,
        seeds: list[Event],
        *,
        reducer_names: list[str],
        include_llm_tokens: bool,
        include_custom_events: bool,
        **kwargs: Any,
    ) -> AsyncIterator[StreamItem]:
        """Stream events using LangGraph's v2 event API with LLM token support."""
        compiled = self._compile()

        # Initialize incremental reducer state.  When a checkpoint exists
        # (subsequent run / resume), start from the checkpointed values so
        # the shadow state matches what the compiled graph already restored.
        # Fall back to r.seed() only on the true first run.
        # NOTE: this issues an extra aget_state round-trip when reducers are
        # present and a checkpointer is configured.
        reducer_state: dict[str, Any] = {}
        checkpoint_values: dict[str, Any] | None = None
        if reducer_names and self._checkpointer is not None:
            config = kwargs.get("config")
            if config is not None:
                snapshot = await compiled.aget_state(config)
                if snapshot.values:
                    checkpoint_values = snapshot.values

        for name in reducer_names:
            if checkpoint_values is not None:
                reducer_state[name] = checkpoint_values.get(
                    name, self._reducers[name].empty
                )
            else:
                reducer_state[name] = self._reducers[name].seed(seeds)

        # Merge seed contributions on top of checkpointed state.
        # - On astream_resume: seeds=[] so this is a no-op.
        # - On astream_events second-run: seeds carry new events that
        #   should layer on top of the restored checkpoint.
        if checkpoint_values is not None:
            for s in seeds:
                self._update_reducer_state(reducer_state, s, reducer_names)

        # Yield seed events
        for s in seeds:
            if reducer_names:
                changed = frozenset(
                    name
                    for name in reducer_names
                    if self._reducers[name].has_contributions(
                        self._reducers[name].collect([s])
                    )
                )
                yield StreamFrame(
                    event=s,
                    reducers=dict(reducer_state),
                    changed_reducers=changed,
                )
            else:
                yield s

        seen: set[int] = set()

        async for raw in compiled.astream_events(
            inp,
            version="v2",
            stream_mode="updates",
            **kwargs,
        ):
            raw_event = raw.get("event")

            if raw_event == "on_chat_model_stream":
                if not include_llm_tokens:
                    continue
                run_id = raw.get("run_id", "")
                chunk = raw.get("data", {}).get("chunk")
                if chunk is None or not run_id:
                    continue
                delta = self._extract_text_content(chunk)
                if delta:
                    yield LLMToken(run_id=run_id, content=delta)
                for tc_chunk in getattr(chunk, "tool_call_chunks", None) or ():
                    index = tc_chunk.get("index")
                    if index is None:
                        raise ValueError(
                            f"LLM tool_call_chunk missing 'index' "
                            f"(run_id={run_id!r}, chunk={tc_chunk!r}). "
                            "LangChain normalizes this — a missing index "
                            "indicates a non-conformant provider or a bug "
                            "upstream."
                        )
                    yield LLMToolCallChunk(
                        run_id=run_id,
                        call_index=index,
                        tool_call_id=tc_chunk.get("id") or "",
                        name=tc_chunk.get("name") or "",
                        args_delta=tc_chunk.get("args") or "",
                    )
                continue

            if raw_event == "on_chat_model_end":
                if not include_llm_tokens:
                    continue
                run_id = raw.get("run_id", "")
                if run_id:
                    output = raw.get("data", {}).get("output")
                    message_id = getattr(output, "id", None)
                    yield LLMStreamEnd(run_id=run_id, message_id=message_id)
                continue

            if raw_event == "on_custom_event":
                if not include_custom_events:
                    continue
                if raw.get("name", "") == STATE_SNAPSHOT_EVENT_NAME:
                    yield StateSnapshotFrame(
                        data=_coerce_snapshot_data(raw.get("data")),
                    )
                else:
                    yield CustomEventFrame(
                        name=raw.get("name", ""),
                        data=raw.get("data"),
                    )
                continue

            if raw_event != "on_chain_stream" or raw.get("name") != "LangGraph":
                continue

            chunk = raw.get("data", {}).get("chunk")
            for event in self._events_from_chunk(chunk, seen):
                if reducer_names:
                    changed = self._update_reducer_state(
                        reducer_state,
                        event,
                        reducer_names,
                    )
                    yield StreamFrame(
                        event=event,
                        reducers=dict(reducer_state),
                        changed_reducers=changed,
                    )
                else:
                    yield event

    def _stream_sync(
        self,
        inp: Any,
        seeds: list[Event],
        reducer_names: list[str],
        **kwargs: Any,
    ) -> Iterator[Event | StreamFrame]:
        """Shared sync streaming core for stream_events/stream_resume."""
        compiled = self._compile()
        if not reducer_names:
            yield from seeds
            seen: set[int] = set()
            for chunk in compiled.stream(inp, stream_mode="updates", **kwargs):
                yield from self._events_from_chunk(chunk, seen)
        else:
            prev_count = 0
            first = True
            for state in compiled.stream(inp, stream_mode="values", **kwargs):
                if first:
                    first = False
                    continue
                prev_count, frames = self._frames_from_values(
                    state, prev_count, reducer_names
                )
                yield from frames

    async def _astream_core(
        self,
        inp: Any,
        seeds: list[Event],
        reducer_names: list[str],
        **kwargs: Any,
    ) -> AsyncIterator[Event | StreamFrame]:
        """Shared async streaming core for astream_events/astream_resume."""
        compiled = self._compile()
        if not reducer_names:
            for s in seeds:
                yield s
            seen: set[int] = set()
            async for chunk in compiled.astream(inp, stream_mode="updates", **kwargs):
                for event in self._events_from_chunk(chunk, seen):
                    yield event
        else:
            prev_count = 0
            first = True
            async for state in compiled.astream(inp, stream_mode="values", **kwargs):
                if first:
                    first = False
                    continue
                prev_count, frames = self._frames_from_values(
                    state, prev_count, reducer_names
                )
                for frame in frames:
                    yield frame

    def stream_events(
        self,
        seed: Event | list[Event],
        *,
        include_reducers: bool | list[str] = False,
        **kwargs: Any,
    ) -> Iterator[Event | StreamFrame]:
        """Yield individual events as they are produced during graph execution.

        Higher-level alternative to ``compiled.stream()`` — yields ``Event``
        objects directly instead of raw LangGraph state dicts.  Seed events
        are yielded first, followed by events produced by handlers.

        Args:
            seed: A single event or list of events to start the graph.
            include_reducers: When truthy, yields ``StreamFrame`` tuples
                instead of bare events.  Pass ``True`` for all reducers or
                a list of reducer names for selective inclusion.
        """
        inp = self._prepare_input(seed)
        kwargs.pop("stream_mode", None)
        reducer_names = self._resolve_reducer_names(include_reducers)
        yield from self._stream_sync(inp, inp["events"], reducer_names, **kwargs)

    def stream_resume(
        self,
        value: Event,
        *,
        include_reducers: bool | list[str] = False,
        **kwargs: Any,
    ) -> Iterator[Event | StreamFrame]:
        """Yield events produced when resuming an interrupted graph.

        Streaming equivalent of ``resume()`` — accepts a domain ``Event``,
        yields events as they are produced.  The ``Command(resume=value)``
        stays internal, exactly like ``resume()``.

        Args:
            value: The domain event to resume with.
            include_reducers: When truthy, yields ``StreamFrame`` tuples
                instead of bare events.  Pass ``True`` for all reducers or
                a list of reducer names for selective inclusion.
        """
        self._require_checkpointer("stream_resume")
        kwargs.pop("stream_mode", None)
        reducer_names = self._resolve_reducer_names(include_reducers)
        yield from self._stream_sync(
            LGCommand(resume=value), [], reducer_names, **kwargs
        )

    async def _astream_entry(
        self,
        inp: Any,
        seeds: list[Event],
        *,
        include_reducers: bool | list[str],
        include_llm_tokens: bool,
        include_custom_events: bool,
        **kwargs: Any,
    ) -> AsyncIterator[StreamItem]:
        """Shared async-stream dispatcher — picks v2 vs core based on flags."""
        kwargs.pop("stream_mode", None)
        reducer_names = self._resolve_reducer_names(include_reducers)
        delegate = (
            self._astream_v2(
                inp,
                seeds,
                reducer_names=reducer_names,
                include_llm_tokens=include_llm_tokens,
                include_custom_events=include_custom_events,
                **kwargs,
            )
            if include_llm_tokens or include_custom_events
            else self._astream_core(inp, seeds, reducer_names, **kwargs)
        )
        async for item in delegate:
            yield item

    async def astream_resume(
        self,
        value: Event,
        *,
        include_reducers: bool | list[str] = False,
        include_llm_tokens: bool = False,
        include_custom_events: bool = False,
        **kwargs: Any,
    ) -> AsyncIterator[StreamItem]:
        """Async version of ``stream_resume()``.

        Streaming equivalent of ``aresume()`` — accepts a domain ``Event``,
        yields events as they are produced.

        Args:
            value: The domain event to resume with.
            include_reducers: When truthy, yields ``StreamFrame`` tuples
                instead of bare events.  Pass ``True`` for all reducers or
                a list of reducer names for selective inclusion.
            include_llm_tokens: When True, yields ``LLMToken`` and
                ``LLMStreamEnd`` frames for LLM token-level streaming.
            include_custom_events: When True, yields ``CustomEventFrame``
                and ``StateSnapshotFrame`` frames for ``on_custom_event`` payloads
                from LangGraph.
        """
        self._require_checkpointer("astream_resume")
        async for item in self._astream_entry(
            LGCommand(resume=value),
            [],
            include_reducers=include_reducers,
            include_llm_tokens=include_llm_tokens,
            include_custom_events=include_custom_events,
            **kwargs,
        ):
            yield item

    async def astream_events(
        self,
        seed: Event | list[Event],
        *,
        include_reducers: bool | list[str] = False,
        include_llm_tokens: bool = False,
        include_custom_events: bool = False,
        **kwargs: Any,
    ) -> AsyncIterator[StreamItem]:
        """Async version of ``stream_events()``.

        Args:
            seed: A single event or list of events to start the graph.
            include_reducers: When truthy, yields ``StreamFrame`` tuples
                instead of bare events.  Pass ``True`` for all reducers or
                a list of reducer names for selective inclusion.
            include_llm_tokens: When True, yields ``LLMToken`` and
                ``LLMStreamEnd`` frames for LLM token-level streaming.
            include_custom_events: When True, yields ``CustomEventFrame``
                and ``StateSnapshotFrame`` frames for ``on_custom_event`` payloads
                from LangGraph.
        """
        inp = self._prepare_input(seed)
        async for item in self._astream_entry(
            inp,
            inp["events"],
            include_reducers=include_reducers,
            include_llm_tokens=include_llm_tokens,
            include_custom_events=include_custom_events,
            **kwargs,
        ):
            yield item
