"""End-to-end tests: full sandbox lifecycle via CLI → local API Server → Novita SDK.

Requires live Novita API credentials. Skipped when NOVITA_API_KEY is not set.
Run with: pytest -v -m e2e --timeout=300

The test starts a local FastAPI server in a background thread and points the
CLI at it via NOVITACLAW_SERVER, exercising the full two-layer architecture:
  CLI (Click + httpx) → API Server (FastAPI) → novita_sandbox SDK

See .claude/skills/e2e-test/references/gotchas.md for known pitfalls.
"""

import json
import os
import socket
import threading
import time

import pytest
import uvicorn
from click.testing import CliRunner

from openclaw_sandbox_cli.cli import cli
from openclaw_sandbox_cli.output import set_json_mode

pytestmark = pytest.mark.e2e

_api_key = os.environ.get("NOVITA_API_KEY", "")


def _needs_api_key():
    if not _api_key:
        pytest.skip("NOVITA_API_KEY not set — skipping live E2E test")


def _free_port() -> int:
    """Find an available TCP port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


# ---------------------------------------------------------------------------
# Module-scoped fixtures: local server + CLI runner
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def server_url():
    """Start the FastAPI server on a random port and return its base URL."""
    _needs_api_key()

    from openclaw_sandbox_server.app import app

    port = _free_port()
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    # Wait for server to be ready
    url = "http://127.0.0.1:{port}/api".format(port=port)
    for _ in range(50):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1):
                break
        except OSError:
            time.sleep(0.1)
    else:
        pytest.fail("Local API server did not start within 5 seconds")

    yield url

    server.should_exit = True
    thread.join(timeout=5)


@pytest.fixture(autouse=True)
def _clean_json_mode():
    yield
    set_json_mode(False)


@pytest.fixture(scope="module")
def runner():
    return CliRunner()


def _invoke(runner, server_url, args):
    """Invoke CLI with NOVITACLAW_SERVER pointing at the local server."""
    env = {"NOVITACLAW_SERVER": server_url}
    if _api_key:
        env["NOVITA_API_KEY"] = _api_key
    return runner.invoke(cli, args, env=env)


# ---------------------------------------------------------------------------
# Sandbox lifecycle fixture: launch once, stop on teardown
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def sandbox(runner, server_url):
    """Launch a sandbox and yield its info dict; always stop it on teardown."""
    _needs_api_key()

    result = _invoke(
        runner,
        server_url,
        ["--json", "launch", "--api-key", _api_key, "--timeout", "120"],
    )
    assert result.exit_code == 0, "launch failed: {out}".format(out=result.output)

    data = json.loads(result.output)
    assert data["status"] == "ok", "launch returned error: {d}".format(d=data)
    assert "sandbox_id" in data

    sandbox_id = data["sandbox_id"]

    yield data

    # Teardown: force-stop regardless of test outcome
    stop_result = _invoke(
        runner,
        server_url,
        ["--json", "stop", "--api-key", _api_key, "-y", sandbox_id],
    )
    if stop_result.exit_code != 0:
        print("WARNING: sandbox cleanup failed: {out}".format(out=stop_result.output))


def _sdk_manager(api_key, sandbox_id):
    """Create a SandboxManager connected to a specific sandbox."""
    from openclaw_sandbox_server.sandbox import SandboxManager

    mgr = SandboxManager(api_key=api_key)
    mgr.connect(sandbox_id)
    return mgr


def _approve_node_pairing(gw_manager, node_manager, node_run_cmd, max_attempts=20):
    """Approve pending node device pairing on a gateway sandbox.

    Polls ``openclaw devices list --json`` until a pending request appears,
    approves it, then re-runs the node process to reconnect (the node does
    not auto-reconnect after pairing approval).
    """
    env = "OPENCLAW_CONFIG_PATH=/home/user/.openclaw/openclaw.json"

    # Poll for pending device
    request_id = None
    last_output = ""
    for _ in range(max_attempts):
        r = gw_manager.run_command("{} openclaw devices list --json 2>&1".format(env), timeout=10)
        last_output = r.stdout if r and r.stdout else "(no output)"
        if r and r.stdout:
            try:
                data = json.loads(r.stdout)
                pending = data.get("pending", [])
                if pending:
                    request_id = pending[0]["requestId"]
                    break
            except (json.JSONDecodeError, KeyError, IndexError):
                pass
        time.sleep(2)
    assert request_id, "No pending device found on gateway. Last output: {out}".format(
        out=last_output
    )

    # Approve
    r = gw_manager.run_command(
        "{env} openclaw devices approve {rid} --json 2>&1".format(env=env, rid=request_id),
        timeout=15,
    )
    assert r and r.stdout and "requestId" in r.stdout, "Device approval failed"

    # Re-run node process to reconnect (node doesn't auto-reconnect after approval)
    node_manager.run_command(node_run_cmd, timeout=10)
    time.sleep(3)

    # Wait for node to show as connected
    last_status_output = ""
    for _ in range(15):
        time.sleep(2)
        r = gw_manager.run_command("{} openclaw nodes status --json 2>&1".format(env), timeout=10)
        last_status_output = r.stdout if r and r.stdout else "(no output)"
        if r and r.stdout:
            try:
                status = json.loads(r.stdout)
                nodes = status.get("nodes", [])
                if nodes and nodes[0].get("connected"):
                    return nodes[0]
            except (json.JSONDecodeError, KeyError, IndexError):
                pass
    pytest.fail(
        "Node did not become connected after pairing approval. Last status: {out}".format(
            out=last_status_output
        )
    )


def _invoke_on_node(gw_manager, token, node_name, command, params):
    """Run ``openclaw nodes invoke`` inside the gateway sandbox and return parsed result."""
    params_json = json.dumps(params)
    script = (
        "#!/bin/bash\n"
        "export OPENCLAW_CONFIG_PATH=/home/user/.openclaw/openclaw.json\n"
        "openclaw nodes invoke"
        " --url ws://localhost:18789"
        " --token '{token}'"
        " --node '{node}'"
        " --command {cmd}"
        " --params '{params}'"
        " --json --timeout 15000 2>&1\n"
    ).format(token=token, node=node_name, cmd=command, params=params_json)
    gw_manager.write_file("/tmp/_e2e_invoke.sh", script)
    r = gw_manager.run_command("bash /tmp/_e2e_invoke.sh", timeout=25)
    assert r and r.stdout, "nodes invoke returned no output"
    return json.loads(r.stdout)


@pytest.fixture(scope="module")
def node_sandbox(runner, server_url, sandbox):
    """Launch a node sandbox, connect to the gateway, and approve pairing."""
    _needs_api_key()

    # Step 1: Launch bare node sandbox
    result = _invoke(
        runner,
        server_url,
        [
            "--json",
            "launch",
            "--api-key",
            _api_key,
            "--mode",
            "node",
            "--timeout",
            "120",
        ],
    )
    assert result.exit_code == 0, "node launch failed: {out}".format(out=result.output)

    launch_data = json.loads(result.output)
    assert launch_data["status"] == "ok", "node launch returned error: {d}".format(d=launch_data)
    node_id = launch_data["sandbox_id"]

    # Step 2: Re-fetch gateway info (token may have changed after gateway restart)
    status_result = _invoke(
        runner,
        server_url,
        ["--json", "status", "--api-key", _api_key, sandbox["sandbox_id"]],
    )
    assert status_result.exit_code == 0, "status failed: {out}".format(out=status_result.output)
    fresh_sandbox = json.loads(status_result.output)
    gateway_ws = fresh_sandbox.get("gateway_ws", sandbox["gateway_ws"])
    gateway_token = fresh_sandbox.get("gateway_token", sandbox.get("gateway_token", ""))

    # Step 3: Connect node to the gateway (with token for auth)
    connect_args = [
        "--json",
        "node",
        "connect",
        "--api-key",
        _api_key,
        "--gateway",
        gateway_ws,
        node_id,
    ]
    if gateway_token:
        connect_args.extend(["--gateway-token", gateway_token])
    connect_result = _invoke(runner, server_url, connect_args)
    assert connect_result.exit_code == 0, "node connect failed: {out}".format(
        out=connect_result.output
    )

    connect_data = json.loads(connect_result.output)
    assert connect_data["status"] == "ok", "node connect returned error: {d}".format(d=connect_data)

    # Step 4: Approve device pairing on the gateway, then reconnect node
    gw_mgr = _sdk_manager(_api_key, sandbox["sandbox_id"])
    node_mgr = _sdk_manager(_api_key, node_id)

    # Build the openclaw node run command for reconnection after approval
    from urllib.parse import urlparse

    parsed = urlparse(gateway_ws)
    gw_host = parsed.hostname
    gw_port = parsed.port or (443 if parsed.scheme == "wss" else 18789)
    tls_flag = " --tls" if parsed.scheme == "wss" else ""
    display_name = connect_data.get("node_display_name", "node-{id}".format(id=node_id[:8]))
    token_env = " OPENCLAW_GATEWAY_TOKEN={tok}".format(tok=gateway_token) if gateway_token else ""
    node_run_cmd = (
        "nohup bash -c 'OPENCLAW_CONFIG_PATH=/home/user/.openclaw/openclaw.json"
        "{token_env} openclaw node run"
        " --host {host} --port {port}{tls}"
        " --display-name {name}'"
        " > /tmp/node.log 2>&1 &"
    ).format(
        token_env=token_env,
        host=gw_host,
        port=gw_port,
        tls=tls_flag,
        name=display_name,
    )

    node_info = _approve_node_pairing(gw_mgr, node_mgr, node_run_cmd)

    # Merge launch + connect + pairing data for tests
    data = {**launch_data, **connect_data, "node_info": node_info}

    yield data

    # Teardown: stop the node sandbox
    stop_result = _invoke(
        runner,
        server_url,
        ["--json", "stop", "--api-key", _api_key, "-y", node_id],
    )
    if stop_result.exit_code != 0:
        print("WARNING: node sandbox cleanup failed: {out}".format(out=stop_result.output))


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestLaunch:
    """Verify launch response fields."""

    def test_returns_sandbox_id(self, sandbox):
        assert sandbox["sandbox_id"]

    def test_returns_webui_url(self, sandbox):
        assert sandbox["webui"].startswith("https://")

    def test_returns_gateway_ws(self, sandbox):
        assert sandbox["gateway_ws"].startswith("wss://")

    def test_returns_terminal_url(self, sandbox):
        assert sandbox["terminal_url"].startswith("https://")

    def test_returns_filemanager_url(self, sandbox):
        assert sandbox["filemanager_url"].startswith("https://")

    def test_returns_service_credentials(self, sandbox):
        assert sandbox["services_username"]
        assert sandbox["services_password"]
        assert len(sandbox["services_password"]) >= 16


class TestList:
    """Verify list command finds the launched sandbox."""

    def test_list_contains_sandbox(self, runner, server_url, sandbox):
        result = _invoke(runner, server_url, ["--json", "list", "--api-key", _api_key])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"

        ids = [s["sandbox_id"] for s in data["sandboxes"]]
        assert sandbox["sandbox_id"] in ids

    def test_list_sandbox_has_state(self, runner, server_url, sandbox):
        result = _invoke(runner, server_url, ["--json", "list", "--api-key", _api_key])
        data = json.loads(result.output)
        sbx = next(s for s in data["sandboxes"] if s["sandbox_id"] == sandbox["sandbox_id"])
        assert sbx["state"]


class TestStatus:
    """Verify status command returns full sandbox info."""

    def test_status_shows_running(self, runner, server_url, sandbox):
        sid = sandbox["sandbox_id"]
        result = _invoke(runner, server_url, ["--json", "status", "--api-key", _api_key, sid])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert data["state"] == "running"

    def test_status_includes_service_urls(self, runner, server_url, sandbox):
        sid = sandbox["sandbox_id"]
        result = _invoke(runner, server_url, ["--json", "status", "--api-key", _api_key, sid])
        data = json.loads(result.output)
        assert data["terminal_url"].startswith("https://")
        assert data["filemanager_url"].startswith("https://")

    def test_status_includes_credentials(self, runner, server_url, sandbox):
        sid = sandbox["sandbox_id"]
        result = _invoke(runner, server_url, ["--json", "status", "--api-key", _api_key, sid])
        data = json.loads(result.output)
        assert data.get("services_username")
        assert data.get("services_password")


class TestGateway:
    """Verify gateway restart via the API server."""

    def test_gateway_restart(self, runner, server_url, sandbox):
        sid = sandbox["sandbox_id"]
        result = _invoke(
            runner,
            server_url,
            ["--json", "gateway", "restart", "--api-key", _api_key, sid],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert data["gateway_ws"].startswith("wss://")
        assert data["webui"].startswith("https://")


class TestDoctor:
    """Verify doctor command runs through the API server."""

    def test_doctor_runs(self, runner, server_url, sandbox):
        sid = sandbox["sandbox_id"]
        result = _invoke(
            runner,
            server_url,
            ["--json", "doctor", "--api-key", _api_key, sid],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert "output" in data


class TestServicesSetup:
    """Verify services setup (already-configured path)."""

    def test_services_already_configured(self, runner, server_url, sandbox):
        sid = sandbox["sandbox_id"]
        result = _invoke(
            runner,
            server_url,
            ["--json", "services", "setup", "--api-key", _api_key, sid],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert data["terminal_url"].startswith("https://")
        assert data.get("already_configured") is True


class TestPauseResume:
    """Verify pause and resume sandbox lifecycle."""

    def test_pause_sandbox(self, runner, server_url, sandbox):
        sid = sandbox["sandbox_id"]
        result = _invoke(
            runner,
            server_url,
            ["--json", "pause", "--api-key", _api_key, sid],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert data["sandbox_id"] == sid

    def test_list_shows_paused_state(self, runner, server_url, sandbox):
        sid = sandbox["sandbox_id"]
        # The Novita platform changes the sandbox ID suffix to -00000000 when
        # paused, so we match by the prefix (everything before the last dash).
        prefix = sid.rsplit("-", 1)[0]
        # Pause takes ~4s/GB RAM; poll until the sandbox appears as paused
        sbx = None
        for _ in range(15):
            result = _invoke(runner, server_url, ["--json", "list", "--api-key", _api_key])
            assert result.exit_code == 0
            data = json.loads(result.output)
            sbx = next(
                (s for s in data["sandboxes"] if s["sandbox_id"].startswith(prefix)),
                None,
            )
            if sbx and sbx.get("state") == "paused":
                break
            time.sleep(2)
        assert sbx is not None, "Paused sandbox not found in list"
        assert sbx["state"] == "paused"

    def test_status_paused_without_resuming(self, runner, server_url, sandbox):
        """Status of paused sandbox should return state=paused without waking it."""
        sid = sandbox["sandbox_id"]
        result = _invoke(
            runner,
            server_url,
            ["--json", "status", "--api-key", _api_key, sid],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert data["state"] == "paused"
        # Verify sandbox is still paused (status did not resume it)
        prefix = sid.rsplit("-", 1)[0]
        result = _invoke(runner, server_url, ["--json", "list", "--api-key", _api_key])
        data = json.loads(result.output)
        sbx = next(
            (s for s in data["sandboxes"] if s["sandbox_id"].startswith(prefix)),
            None,
        )
        assert sbx is not None
        assert sbx["state"] == "paused"

    def test_resume_sandbox(self, runner, server_url, sandbox):
        sid = sandbox["sandbox_id"]
        result = _invoke(
            runner,
            server_url,
            ["--json", "resume", "--api-key", _api_key, sid],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert data["sandbox_id"] == sid

    def test_status_running_after_resume(self, runner, server_url, sandbox):
        sid = sandbox["sandbox_id"]
        result = _invoke(
            runner,
            server_url,
            ["--json", "status", "--api-key", _api_key, sid],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert data["state"] == "running"


class TestNodeLaunch:
    """Verify node launch + connect response fields."""

    def test_node_returns_sandbox_id(self, node_sandbox):
        assert node_sandbox["sandbox_id"]

    def test_node_returns_mode_node(self, node_sandbox):
        assert node_sandbox["mode"] == "node"

    def test_node_returns_display_name(self, node_sandbox):
        assert node_sandbox.get("node_display_name")

    def test_node_returns_service_credentials(self, node_sandbox):
        assert node_sandbox.get("services_username")
        assert node_sandbox.get("services_password")


class TestNodeGatewayIntegration:
    """Verify node is paired, connected, and can execute commands via gateway."""

    def test_node_paired_and_connected(self, node_sandbox):
        node_info = node_sandbox.get("node_info", {})
        assert node_info.get("paired") is True
        assert node_info.get("connected") is True

    def test_node_system_which(self, node_sandbox, sandbox):
        """Invoke system.which on the node via the gateway."""
        gw_mgr = _sdk_manager(_api_key, sandbox["sandbox_id"])
        token = sandbox.get("gateway_token", "")
        display_name = node_sandbox.get("node_display_name", "")

        result = _invoke_on_node(
            gw_mgr, token, display_name, "system.which", {"bins": ["echo", "node"]}
        )
        assert result.get("ok") is True
        bins = result.get("payload", {}).get("bins", {})
        assert "echo" in bins
        assert bins["echo"]  # should be a path like /usr/bin/echo


class TestNodeStatus:
    """Verify node appears in list."""

    def test_node_appears_in_list(self, runner, server_url, node_sandbox):
        result = _invoke(runner, server_url, ["--json", "list", "--api-key", _api_key])
        assert result.exit_code == 0
        data = json.loads(result.output)
        ids = [s["sandbox_id"] for s in data["sandboxes"]]
        assert node_sandbox["sandbox_id"] in ids


class TestNodeStop:
    """Verify node stop works."""

    def test_node_stop(self, runner, server_url, node_sandbox):
        sid = node_sandbox["sandbox_id"]
        result = _invoke(
            runner,
            server_url,
            ["--json", "stop", "--api-key", _api_key, "-y", sid],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert data["sandbox_id"] == sid

        # Verify removed from list
        list_result = _invoke(runner, server_url, ["--json", "list", "--api-key", _api_key])
        list_data = json.loads(list_result.output)
        ids = [s["sandbox_id"] for s in list_data["sandboxes"]]
        assert sid not in ids


class TestStop:
    """Verify stop + removal (must run last)."""

    def test_stop_terminates_sandbox(self, runner, server_url, sandbox):
        sid = sandbox["sandbox_id"]
        result = _invoke(
            runner,
            server_url,
            ["--json", "stop", "--api-key", _api_key, "-y", sid],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert data["sandbox_id"] == sid

    def test_sandbox_removed_after_stop(self, runner, server_url, sandbox):
        result = _invoke(runner, server_url, ["--json", "list", "--api-key", _api_key])
        assert result.exit_code == 0
        data = json.loads(result.output)
        ids = [s["sandbox_id"] for s in data["sandboxes"]]
        assert sandbox["sandbox_id"] not in ids
