"""CLI entry point for OpenClaw Sandbox CLI."""

import atexit
import concurrent.futures
import functools
import json
import os
import subprocess
import sys
import threading
import time
import urllib.request

import click
from dotenv import load_dotenv
from rich.panel import Panel
from rich.table import Table

from .client import APIClient
from .const import (
    API_KEY_URL,
    API_SERVER_URL,
    BRAND_NAME,
    CLI_NAME,
    CONFIG_DIR_NAME,
    ENV_VAR_API_KEY,
    ENV_VAR_SERVER,
    PACKAGE_NAME,
    PROVIDER_NAME,
    VENV_DIR_NAME,
)
from .output import (
    EXIT_MISSING_API_KEY,
    CLIError,
    UpdateError,
    is_json_mode,
    output_error,
    output_server_data,
    output_success,
    set_json_mode,
)
from .utils import console, get_console, print_error, print_info, print_success

load_dotenv()

_API_KEY_HELP = ("{provider} API key (recommended: export {env}=<key>). Get yours at {url}").format(
    provider=PROVIDER_NAME, env=ENV_VAR_API_KEY, url=API_KEY_URL
)

# --- Helpers ---


def _print_api_key_guide():
    """Print API key setup guide and exit."""
    if is_json_mode():
        output_error(
            "MISSING_API_KEY",
            "{provider} API key is required. Set via --api-key or {env} env.".format(
                provider=PROVIDER_NAME,
                env=ENV_VAR_API_KEY,
            ),
            10,
            remediation="export {env}=<your-api-key>".format(env=ENV_VAR_API_KEY),
        )
        return

    print_error(
        "{provider} API key is required. Configure it using one of these methods:".format(
            provider=PROVIDER_NAME,
        )
    )
    console.print()
    console.print("  1. Pass directly (launch only):")
    console.print("     [cyan]{cli} launch --api-key sk_your_api_key[/cyan]".format(cli=CLI_NAME))
    console.print()
    console.print("  2. Set for current command:")
    console.print(
        "     [cyan]{env}=sk_your_api_key {cli} <command>[/cyan]".format(
            env=ENV_VAR_API_KEY,
            cli=CLI_NAME,
        )
    )
    console.print()
    console.print("  3. Export for current session:")
    console.print("     [cyan]export {env}=sk_your_api_key[/cyan]".format(env=ENV_VAR_API_KEY))
    console.print()
    console.print("  4. Add to shell profile (~/.bashrc or ~/.zshrc):")
    console.print(
        "     [cyan]echo 'export {env}=sk_your_api_key' >> ~/.zshrc[/cyan]".format(
            env=ENV_VAR_API_KEY,
        )
    )
    console.print()
    console.print("  Get your API key at: [link={url}]{url}[/link]".format(url=API_KEY_URL))
    raise SystemExit(EXIT_MISSING_API_KEY)


def _resolve_api_key(kwargs) -> str:
    """Resolve API key from kwargs or env, or raise."""
    key = kwargs.get("api_key") or os.environ.get(ENV_VAR_API_KEY)
    if not key:
        _print_api_key_guide()
    return key


def _resolve_server(ctx) -> str:
    """Resolve server URL from env or default."""
    return os.environ.get(ENV_VAR_SERVER) or API_SERVER_URL


def require_api_key(f):
    """Decorator that resolves the API key and injects it into kwargs."""

    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        kwargs["api_key"] = _resolve_api_key(kwargs)
        return f(*args, **kwargs)

    return wrapper


def _make_client(ctx, api_key: str) -> APIClient:
    """Create an APIClient from context and API key."""
    server = _resolve_server(ctx)
    return APIClient(server, api_key)


def _print_resume_hint(sandbox_id: str):
    """Print the resume command hint."""
    print_info("Resume with: [cyan]{cli} resume {id}[/cyan]".format(cli=CLI_NAME, id=sandbox_id))


def _build_webui_url(urls_or_data: dict, gw_token: str = None) -> str:
    """Append gateway token fragment to WebUI URL for auto-authentication."""
    webui_url = urls_or_data.get("webui", "")
    token = gw_token or urls_or_data.get("gateway_token", "")
    if token and "#token=" not in webui_url:
        webui_url = "{base}#token={token}".format(base=webui_url, token=token)
    return webui_url


def _print_webui_url(webui_url):
    """Print the WebUI URL on a standalone line for easy clicking/copying."""
    console.print(
        "\n  [bold green]\u25b6 Web UI:[/bold green] {webui}\n".format(webui=webui_url),
        highlight=False,
    )


def _print_gateway_info(data):
    """Print gateway summary from response data."""
    webui_url = _build_webui_url(data)
    _print_webui_url(webui_url)
    print_info("Gateway WS: {ws}".format(ws=data.get("gateway_ws", "")))
    if data.get("gateway_token"):
        print_info("Gateway Token: {token}".format(token=data["gateway_token"]))


def _format_service_info(data) -> str:
    """Return service URLs and credentials as a string for embedding in a Panel."""
    parts = []
    if data.get("terminal_url"):
        parts.append("[cyan]Web Terminal:[/cyan]       {url}".format(url=data["terminal_url"]))
    if data.get("filemanager_url"):
        parts.append("[cyan]File Manager:[/cyan]       {url}".format(url=data["filemanager_url"]))
    if data.get("services_username"):
        parts.append("[cyan]Login User:[/cyan]         {u}".format(u=data["services_username"]))
    if data.get("services_password"):
        parts.append("[cyan]Login Password:[/cyan]     {p}".format(p=data["services_password"]))
        parts.append("[dim](credentials for Web Terminal & File Manager)[/dim]")
    if parts:
        return "\n" + "\n".join(parts)
    return ""


def _handle_cli_error(e: CLIError):
    """Handle a CLIError -- JSON output or Rich error + exit."""
    if is_json_mode():
        output_error(e.error_code, str(e), e.exit_code, remediation=e.remediation)
    else:
        print_error(str(e))
        if e.remediation:
            print_info("Suggested fix: {r}".format(r=e.remediation))
        raise SystemExit(e.exit_code)


# --- Version check helpers ---


def _parse_version(v: str):
    return tuple(int(x) for x in v.strip().split("."))


def _fetch_latest_version():
    try:
        url = "https://pypi.org/pypi/{}/json".format(PACKAGE_NAME)
        resp = urllib.request.urlopen(url, timeout=5)
        data = json.loads(resp.read())
        return data["info"]["version"]
    except Exception:
        return None


def _config_dir():
    """Return the CLI config directory."""
    return os.path.join(os.path.expanduser("~"), CONFIG_DIR_NAME)


def _update_check_path():
    return os.path.join(_config_dir(), "update_check")


def _should_check_update():
    path = _update_check_path()
    try:
        mtime = os.path.getmtime(path)
        return (time.time() - mtime) > 86400
    except OSError:
        return True


def _save_check_timestamp():
    path = _update_check_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write("")


_update_hint = None


def _background_version_check():
    global _update_hint
    if not _should_check_update():
        return
    latest = _fetch_latest_version()
    if latest is None:
        return
    _save_check_timestamp()
    from . import __version__

    try:
        if _parse_version(latest) > _parse_version(__version__):
            _update_hint = (
                "\n\u2728 {brand} v{latest} is available (current: v{current}). "
                "Run `{cli} update` to upgrade."
            ).format(brand=BRAND_NAME, latest=latest, current=__version__, cli=CLI_NAME)
    except (ValueError, TypeError):
        pass


def _print_update_hint():
    if _update_hint:
        click.echo(_update_hint, err=True)


# --- CLI ---


@click.group()
@click.version_option(package_name=PACKAGE_NAME)
@click.option(
    "--json",
    "-j",
    "json_output",
    is_flag=True,
    help="Output as JSON (for programmatic use). AI agents should always enable this flag.",
)
@click.pass_context
def cli(ctx, json_output):
    ctx.ensure_object(dict)
    set_json_mode(json_output)
    if not json_output and ctx.invoked_subcommand != "update":
        t = threading.Thread(target=_background_version_check, daemon=True)
        t.start()
        atexit.register(_print_update_hint)


def _json_option(f):
    """Add --json/-j to a subcommand, merging with the group-level flag."""

    @click.option("--json", "-j", "json_output", is_flag=True, hidden=True)
    @functools.wraps(f)
    def wrapper(*args, json_output=False, **kwargs):
        if json_output:
            set_json_mode(True)
        return f(*args, **kwargs)

    return wrapper


cli.help = "{brand} - Launch OpenClaw on {provider} Agent Sandbox in one command.".format(
    brand=BRAND_NAME,
    provider=PROVIDER_NAME,
)


@cli.command()
@click.option("--api-key", default=None, help=_API_KEY_HELP + " (also used for OpenClaw LLM)")
@click.option("--timeout", default=180, help="Sandbox creation timeout in seconds (default: 180)")
@click.option(
    "--mode",
    default="gateway",
    type=click.Choice(["gateway", "node"], case_sensitive=False),
    help=(
        "Launch mode: 'gateway' (default) starts a full OpenClaw gateway; "
        "'node' creates a bare node sandbox (use 'node connect' to attach to a gateway)."
    ),
)
@click.option(
    "--display-name",
    default=None,
    help="Node display name shown in the gateway UI (node mode only).",
)
@_json_option
@require_api_key
@click.pass_context
def launch(ctx, api_key, timeout, mode, display_name):
    """Launch a new OpenClaw sandbox environment.

    By default, launches in gateway mode (full OpenClaw gateway).
    Use --mode node to create a bare node sandbox, then use 'node connect' to
    attach it to a gateway.
    """
    try:
        c = get_console()
        client = _make_client(ctx, api_key)

        if mode == "gateway":
            launch_phases = [
                (0, "[bold blue]Creating sandbox..."),
                (5, "[bold blue]Configuring OpenClaw..."),
                (10, "[bold blue]Starting gateway..."),
                (18, "[bold blue]Configuring services..."),
                (25, "[bold blue]Waiting for gateway ready..."),
                (60, "[bold blue]Almost there..."),
            ]
        else:
            launch_phases = [
                (0, "[bold blue]Creating node sandbox..."),
                (5, "[bold blue]Configuring services..."),
            ]

        def _run_launch():
            return client.launch(timeout=timeout, mode=mode, display_name=display_name)

        with c.status(launch_phases[0][1]) as st:
            executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
            try:
                future = executor.submit(_run_launch)
                start = time.monotonic()
                phase_idx = 1
                while not future.done():
                    elapsed = time.monotonic() - start
                    if phase_idx < len(launch_phases) and elapsed >= launch_phases[phase_idx][0]:
                        st.update(launch_phases[phase_idx][1])
                        phase_idx += 1
                    time.sleep(0.3)
                data = future.result()
            finally:
                executor.shutdown(wait=False)

        if is_json_mode():
            output_server_data(data)
            return

        if data.get("mode") == "node":
            _print_node_launch_result(data)
        else:
            _print_gateway_launch_result(data)

    except CLIError as e:
        _handle_cli_error(e)


def _print_gateway_launch_result(data):
    webui_url = _build_webui_url(data)
    summary = (
        "[cyan]Sandbox ID:[/cyan]         {sandbox_id}\n"
        "[cyan]Keep Alive:[/cyan]         {keep_alive}s\n"
        "[cyan]Gateway WebSocket:[/cyan]  {gateway_ws}\n"
        "[cyan]Gateway Token:[/cyan]      {gateway_token}"
    ).format(
        sandbox_id=data["sandbox_id"],
        keep_alive=data.get("keep_alive", ""),
        gateway_ws=data.get("gateway_ws", ""),
        gateway_token=data.get("gateway_token", "(not set)"),
    )
    summary += _format_service_info(data)
    console.print(
        Panel(
            summary,
            title="[green]{brand} Sandbox Ready[/green]".format(brand=BRAND_NAME),
            border_style="green",
        )
    )
    _print_webui_url(webui_url)


def _print_node_launch_result(data):
    summary = (
        "[cyan]Sandbox ID:[/cyan]     {sandbox_id}\n[cyan]Mode:[/cyan]           node"
    ).format(sandbox_id=data["sandbox_id"])
    summary += _format_service_info(data)
    console.print(
        Panel(
            summary,
            title="[green]{brand} Node Sandbox Ready[/green]".format(brand=BRAND_NAME),
            border_style="green",
        )
    )
    hint = (
        "    [cyan]{cli} node connect {sid} --gateway <wss://...> --gateway-token <token>[/cyan]\n"
    ).format(cli=CLI_NAME, sid=data["sandbox_id"])
    console.print(
        "\n  [bold yellow]Next step:[/bold yellow] Connect to a gateway with:\n" + hint,
        highlight=False,
    )
    gw_hint = (
        "  [dim]Gateways created by {cli} are already configured "
        "(tools.exec.security=full, ask=off).\n"
        "  If using an external gateway, ensure exec permissions are set:[/dim]\n\n"
        "    [dim]openclaw config set tools.exec.security full[/dim]\n"
        "    [dim]openclaw config set tools.exec.ask off[/dim]\n"
    ).format(cli=CLI_NAME)
    console.print(gw_hint, highlight=False)


@cli.command()
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@click.option("--yes", "-y", "skip_confirm", is_flag=True, help="Skip confirmation prompt")
@_json_option
@require_api_key
@click.pass_context
def stop(ctx, sandbox_id, api_key, skip_confirm):
    """Stop and terminate a sandbox."""
    try:
        if not skip_confirm and not is_json_mode():
            console.print(
                "\n[bold yellow]\u26a0  Warning:[/bold yellow] Stopping sandbox [cyan]{id}[/cyan] "
                "will permanently destroy all data and configurations.\n"
                "   This action [bold red]cannot be undone[/bold red].\n".format(id=sandbox_id)
            )
            if not click.confirm("Are you sure you want to stop this sandbox?"):
                print_info("Operation cancelled.")
                return

        client = _make_client(ctx, api_key)
        c = get_console()
        with c.status("[bold red]Stopping sandbox..."):
            data = client.stop(sandbox_id)

        if is_json_mode():
            output_server_data(data)
        else:
            print_success("Sandbox [cyan]{id}[/cyan] terminated.".format(id=sandbox_id))

    except CLIError as e:
        _handle_cli_error(e)


@cli.command()
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def pause(ctx, sandbox_id, api_key):
    """Pause a running sandbox to save costs while preserving all state.

    All filesystem contents, memory state, and running processes are preserved.
    No runtime charges while paused. Use 'resume' to restart.
    """
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Pausing sandbox..."):
            data = client.pause(sandbox_id)

        if is_json_mode():
            output_server_data(data)
        else:
            print_success("Sandbox [cyan]{id}[/cyan] paused.".format(id=sandbox_id))
            _print_resume_hint(sandbox_id)

    except CLIError as e:
        _handle_cli_error(e)


@cli.command()
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def resume(ctx, sandbox_id, api_key):
    """Resume a previously paused sandbox.

    Restores the sandbox to its exact state before pausing, including
    filesystem contents, memory, and running processes.
    """
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Resuming sandbox..."):
            data = client.resume(sandbox_id)

        if is_json_mode():
            output_server_data(data)
        else:
            print_success("Sandbox [cyan]{id}[/cyan] resumed.".format(id=sandbox_id))

    except CLIError as e:
        _handle_cli_error(e)


@cli.command("list")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@click.option(
    "--quiet",
    "-q",
    is_flag=True,
    help="Only print sandbox IDs, one per line. Useful for scripting, piping, and easy copy-paste.",
)
@_json_option
@require_api_key
@click.pass_context
def list_sandboxes(ctx, api_key, quiet):
    """List all active sandboxes."""
    try:
        c = get_console()
        client = _make_client(ctx, api_key)

        with c.status("[bold blue]Fetching sandboxes..."):
            data = client.list_sandboxes()

        sandboxes = data.get("sandboxes", [])

        if is_json_mode():
            output_success({"sandboxes": sandboxes})
            return

        if not sandboxes:
            if not quiet:
                print_info("No {brand} sandboxes found.".format(brand=BRAND_NAME))
            return

        if quiet:
            for sbx in sandboxes:
                click.echo(sbx["sandbox_id"])
            return

        table = Table(title="{brand} Sandboxes".format(brand=BRAND_NAME), expand=False)
        table.add_column("Sandbox ID", style="cyan", no_wrap=True)
        table.add_column("Mode", style="magenta")
        table.add_column("State", style="bold")
        table.add_column("CPU", justify="right")
        table.add_column("Memory (MB)", justify="right")
        table.add_column("Started At", style="yellow")

        for sbx in sandboxes:
            table.add_row(
                sbx["sandbox_id"],
                sbx.get("mode", "gateway"),
                sbx.get("state", ""),
                str(sbx.get("cpu", "")),
                str(sbx.get("memory_mb", "")),
                sbx.get("started_at", ""),
            )

        console.print(table)

    except CLIError as e:
        _handle_cli_error(e)


@cli.command()
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def status(ctx, sandbox_id, api_key):
    """Check sandbox status and show access URLs."""
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Fetching sandbox status..."):
            data = client.status(sandbox_id)

        if is_json_mode():
            output_server_data(data)
            return

        mode = data.get("mode", "gateway")
        state = data.get("state", "unknown")
        summary = (
            "[cyan]Sandbox ID:[/cyan]     {sandbox_id}\n[cyan]Status:[/cyan]         {state}"
        ).format(sandbox_id=sandbox_id, state=state)
        if mode == "node" and data.get("node_display_name"):
            summary += "\n[cyan]Node Name:[/cyan]      {name}".format(
                name=data["node_display_name"],
            )
        if state != "paused":
            if mode == "gateway":
                summary += (
                    "\n[cyan]Gateway WS:[/cyan]     {gateway_ws}"
                    "\n[cyan]Gateway Token:[/cyan]  {gateway_token}"
                ).format(
                    gateway_ws=data.get("gateway_ws", ""),
                    gateway_token=data.get("gateway_token") or "(not found)",
                )
            summary += _format_service_info(data)
        panel_title = "Node Status" if mode == "node" else "Gateway Status"
        console.print(Panel(summary, title=panel_title, border_style="blue"))
        if state == "paused":
            _print_resume_hint(sandbox_id)
        elif mode == "gateway":
            webui_url = _build_webui_url(data)
            _print_webui_url(webui_url)

    except CLIError as e:
        _handle_cli_error(e)


@cli.command()
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@click.option("--deep", is_flag=True, help="Scan system services for extra gateway installs")
@click.option("--fix", is_flag=True, help="Apply recommended repairs (alias for --repair)")
@click.option(
    "--force",
    is_flag=True,
    help="Apply aggressive repairs (overwrites custom service config)",
)
@click.option(
    "--generate-gateway-token",
    is_flag=True,
    help="Generate and configure a gateway token",
)
@click.option(
    "--no-workspace-suggestions",
    is_flag=True,
    help="Disable workspace memory system suggestions",
)
@click.option("--repair", is_flag=True, help="Apply recommended repairs without prompting")
@click.option("--yes", "yes_flag", is_flag=True, help="Accept defaults without prompting")
@_json_option
@require_api_key
@click.pass_context
def doctor(
    ctx,
    sandbox_id,
    api_key,
    deep,
    fix,
    force,
    generate_gateway_token,
    no_workspace_suggestions,
    repair,
    yes_flag,
):
    """Run OpenClaw doctor inside a sandbox to diagnose and repair issues."""
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Running OpenClaw doctor..."):
            data = client.gateway_doctor(
                sandbox_id,
                deep=deep,
                fix=fix,
                force=force,
                generate_gateway_token=generate_gateway_token,
                no_workspace_suggestions=no_workspace_suggestions,
                repair=repair,
                yes=yes_flag,
            )

        output_text = data.get("output", "")

        if is_json_mode():
            output_success({"sandbox_id": sandbox_id, "output": output_text})
            return

        if output_text:
            console.print(output_text, highlight=False)
        else:
            print_info("No output from doctor command.")

    except CLIError as e:
        _handle_cli_error(e)


@cli.group()
def pair():
    """Manage channel pairing (Telegram, Discord, etc.)."""


@pair.command("list")
@click.argument("sandbox_id")
@click.option(
    "--channel",
    required=True,
    help="Channel name (telegram, discord, whatsapp, signal, slack, etc.)",
)
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def pair_list(ctx, sandbox_id, channel, api_key):
    """List pending pairing requests for a channel."""
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Fetching pairing requests..."):
            data = client.pairing_list(sandbox_id, channel)

        output_text = data.get("output", "")

        if is_json_mode():
            output_success(
                {
                    "sandbox_id": sandbox_id,
                    "channel": channel,
                    "output": output_text,
                }
            )
            return

        if output_text:
            console.print(output_text, highlight=False)
        else:
            print_info("No pending pairing requests for {channel}.".format(channel=channel))

    except CLIError as e:
        _handle_cli_error(e)


@pair.command("approve")
@click.argument("sandbox_id")
@click.option(
    "--channel",
    required=True,
    help="Channel name (telegram, discord, whatsapp, signal, slack, etc.)",
)
@click.option("--code", required=True, help="Pairing code to approve")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def pair_approve(ctx, sandbox_id, channel, code, api_key):
    """Approve a pending pairing request for a channel."""
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Approving pairing request..."):
            data = client.pairing_approve(sandbox_id, channel, code)

        output_text = data.get("output", "")

        if is_json_mode():
            output_success(
                {
                    "sandbox_id": sandbox_id,
                    "channel": channel,
                    "code": code,
                    "output": output_text,
                }
            )
            return

        if output_text:
            console.print(output_text, highlight=False)
        else:
            print_success("Pairing request approved for {channel}.".format(channel=channel))

    except CLIError as e:
        _handle_cli_error(e)


@cli.group()
def gateway():
    """Manage OpenClaw Gateway (update, restart)."""


@gateway.command("update")
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def gateway_update(ctx, sandbox_id, api_key):
    """Update OpenClaw to the latest version in a sandbox."""
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Updating OpenClaw..."):
            data = client.gateway_update(sandbox_id)

        if is_json_mode():
            output_server_data(data)
            return

        output_text = data.get("output", "")
        if output_text:
            console.print(output_text, highlight=False)
        print_success("OpenClaw updated and gateway restarted.")
        _print_gateway_info(data)

    except CLIError as e:
        _handle_cli_error(e)


@gateway.command("restart")
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def gateway_restart(ctx, sandbox_id, api_key):
    """Restart the OpenClaw Gateway in a sandbox."""
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Restarting gateway..."):
            data = client.gateway_restart(sandbox_id)

        if is_json_mode():
            output_server_data(data)
            return

        print_success("Gateway restarted successfully.")
        _print_gateway_info(data)

    except CLIError as e:
        _handle_cli_error(e)


# --- Services commands ---


@cli.group()
def services():
    """Manage Web Terminal and File Manager services in a sandbox."""
    pass


@services.command("setup")
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def services_setup(ctx, sandbox_id, api_key):
    """Install and start Web Terminal + File Manager on an existing sandbox."""
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Setting up services..."):
            data = client.services_setup(sandbox_id)

        if is_json_mode():
            output_server_data(data)
            return

        if data.get("already_configured"):
            print_info("Services already configured on this sandbox.")
        else:
            print_success("Services configured successfully.")
        info = _format_service_info(data)
        if info:
            console.print(info)

    except CLIError as e:
        _handle_cli_error(e)


@cli.group()
def node():
    """Manage node sandboxes (connect/disconnect to gateways)."""


@node.command("connect")
@click.argument("sandbox_id")
@click.option(
    "--gateway",
    required=True,
    help="Gateway WebSocket URL (wss://...) to connect this node to.",
)
@click.option(
    "--gateway-token",
    default=None,
    help="Gateway auth token for authenticating with the gateway.",
)
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def node_connect(ctx, sandbox_id, gateway, gateway_token, api_key):
    """Connect a node sandbox to a gateway.

    Can be called again with a different gateway URL to rebind the node.
    """
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Starting node process..."):
            data = client.node_connect(
                sandbox_id,
                gateway_url=gateway,
                gateway_token=gateway_token,
            )

        if is_json_mode():
            output_server_data(data)
            return

        node_name = data.get("node_display_name") or "node-{id}".format(id=sandbox_id[:8])
        print_success("Node process started. Waiting for pairing...")
        print_info("Approve this node on the gateway, then it will connect automatically.")

        # Poll status; reconnect only if the node process dies
        max_reconnects = 50
        reconnect_count = 0
        try:
            while True:
                time.sleep(5)
                status = client.node_status(sandbox_id, gateway_url=gateway)
                if status.get("paired"):
                    break
                if status.get("alive"):
                    continue
                # process died → relaunch
                reconnect_count += 1
                if reconnect_count > max_reconnects:
                    raise CLIError(
                        "Node failed to stay alive after {n} reconnect attempts.".format(
                            n=max_reconnects
                        ),
                        error_code="NODE_RECONNECT_LIMIT",
                    )
                print_info(
                    "Reconnecting node ({n}/{max})...".format(n=reconnect_count, max=max_reconnects)
                )
                client.node_reconnect(
                    sandbox_id,
                    gateway_url=gateway,
                    gateway_token=gateway_token,
                )
                time.sleep(5)  # wait for new process to start
        except KeyboardInterrupt:
            c.print()  # newline after ^C
            print_info("Polling stopped. Node is still running in the sandbox.")
            hint = "{cli} node connect {sid} --gateway {gw}".format(
                cli=CLI_NAME, sid=sandbox_id, gw=gateway
            )
            if gateway_token:
                hint += " --gateway-token {tok}".format(tok=gateway_token)
            print_info("Re-check with:")
            c.print("  [cyan]{hint}[/cyan]".format(hint=hint))
            return

        print_success(
            "Node [cyan]{name}[/cyan] paired and connected to gateway.".format(
                name=node_name,
            )
        )
        c.print(
            "\n  [bold yellow]Run a command on this node"
            " (from the gateway machine):[/bold yellow]\n"
            '    [cyan]openclaw nodes run --node "{name}"'
            " -- uname -a[/cyan]\n".format(name=node_name),
            highlight=False,
        )

    except CLIError as e:
        _handle_cli_error(e)


@node.command("disconnect")
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def node_disconnect(ctx, sandbox_id, api_key):
    """Disconnect a node from its gateway.

    The sandbox stays alive and can be reconnected to a different gateway.
    """
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Disconnecting node..."):
            data = client.node_disconnect(sandbox_id)

        if is_json_mode():
            output_server_data(data)
            return

        print_success("Node [cyan]{sid}[/cyan] disconnected from gateway.".format(sid=sandbox_id))

    except CLIError as e:
        _handle_cli_error(e)


@cli.group()
def devices():
    """Manage node devices on a gateway (list, approve pairing requests)."""


@devices.command("list")
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def devices_list(ctx, sandbox_id, api_key):
    """List all devices (paired and pending) on a gateway sandbox."""
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Fetching devices..."):
            data = client.devices_list(sandbox_id, json=is_json_mode())

        if is_json_mode():
            output_server_data(data)
            return

        output_text = data.get("output", "")
        if output_text:
            console.print(output_text, highlight=False)
        else:
            print_info("No devices found on gateway {sid}.".format(sid=sandbox_id))

    except CLIError as e:
        _handle_cli_error(e)


@devices.command("approve")
@click.argument("sandbox_id")
@click.option(
    "--request-id",
    default=None,
    help="Request ID of the specific device to approve.",
)
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
@click.pass_context
def devices_approve(ctx, sandbox_id, request_id, api_key):
    """Approve pending node devices on a gateway sandbox.

    Approves a specific device by --request-id, or all pending devices when
    --all is set or no --request-id is given.
    """
    try:
        client = _make_client(ctx, api_key)
        c = get_console()

        with c.status("[bold blue]Approving device(s)..."):
            data = client.devices_approve(sandbox_id, request_id=request_id)

        approved = data.get("approved", [])
        output_text = data.get("output", "")

        if is_json_mode():
            output_server_data(data)
            return

        if not approved:
            print_info("No pending devices found on gateway {sid}.".format(sid=sandbox_id))
            return

        for rid in approved:
            print_success("Approved device: [cyan]{rid}[/cyan]".format(rid=rid))
        if output_text:
            console.print(output_text, highlight=False)

    except CLIError as e:
        _handle_cli_error(e)


@cli.command()
@_json_option
def update():
    """Check for updates and upgrade to the latest version."""
    try:
        from . import __version__

        current = __version__

        c = get_console()
        with c.status("[bold blue]Checking for updates..."):
            latest = _fetch_latest_version()

        if latest is None:
            raise UpdateError("Failed to check for updates. Please check your network connection.")

        if _parse_version(latest) <= _parse_version(current):
            if is_json_mode():
                output_success(
                    {
                        "current": current,
                        "latest": latest,
                        "updated": False,
                        "message": "Already up to date.",
                    }
                )
            else:
                print_success(
                    "{brand} [cyan]v{ver}[/cyan] is already the latest version.".format(
                        brand=BRAND_NAME,
                        ver=current,
                    ),
                    highlight=False,
                )
            return

        if not is_json_mode():
            print_info(
                "New version available: [cyan]v{current}[/cyan] -> [cyan]v{latest}[/cyan]".format(
                    current=current,
                    latest=latest,
                ),
                highlight=False,
            )

        # Prefer venv pip (installed via install.sh/install.ps1), fall back to system pip
        _venv_dir = os.path.join(_config_dir(), VENV_DIR_NAME)
        if os.name == "nt":
            _venv_pip = os.path.join(_venv_dir, "Scripts", "pip.exe")
        else:
            _venv_pip = os.path.join(_venv_dir, "bin", "pip")

        if os.path.isfile(_venv_pip):
            pip_cmd = [_venv_pip, "install", "-U", PACKAGE_NAME]
        else:
            pip_cmd = [sys.executable, "-m", "pip", "install", "-U", PACKAGE_NAME]

        with c.status("[bold blue]Upgrading {brand}...".format(brand=BRAND_NAME)):
            result = subprocess.run(
                pip_cmd,
                capture_output=True,
                text=True,
            )

        if result.returncode != 0:
            raise UpdateError(
                "pip install failed: {err}".format(
                    err=result.stderr.strip() or result.stdout.strip(),
                )
            )

        _save_check_timestamp()

        if is_json_mode():
            output_success(
                {
                    "current": current,
                    "latest": latest,
                    "updated": True,
                    "message": "Updated to v{}.".format(latest),
                }
            )
        else:
            print_success(
                "Updated {brand} from [cyan]v{old}[/cyan] to [cyan]v{new}[/cyan].".format(
                    brand=BRAND_NAME,
                    old=current,
                    new=latest,
                ),
                highlight=False,
            )

    except CLIError as e:
        _handle_cli_error(e)


if __name__ == "__main__":
    cli()
