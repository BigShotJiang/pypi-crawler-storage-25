"""Brand constants for NovitaClaw (Novita variant).

This is the ONLY file that differs between brand variants.
All other source files import from here instead of hardcoding brand strings.
"""

# --- Display names ---
BRAND_NAME = "NovitaClaw"  # Panel titles, table headers
PROVIDER_NAME = "Novita"  # Help text, error messages
CLI_NAME = "novitaclaw"  # CLI command name
PACKAGE_NAME = "NovitaClaw"  # PyPI distribution name (for version lookup)
CONFIG_DIR_NAME = ".novitaclaw"  # ~/.novitaclaw/

# --- Environment / config ---
ENV_VAR_API_KEY = "NOVITA_API_KEY"  # Environment variable name
API_KEY_URL = "https://novita.ai/docs/guides/quickstart#2-manage-api-key"

# --- Sandbox ---
SANDBOX_APP_LABEL = "novita-openclaw"  # metadata.app value
SANDBOX_PROXY = None  # None = no proxy
SDK_PACKAGE = "novita_sandbox"  # SDK package name

# --- OpenClaw config ---
API_KEY_PLACEHOLDER = "NOVITA_API_KEY"  # Placeholder in openclaw.example.json
OPENCLAW_CONFIG_URL = (
    "https://raw.githubusercontent.com/novitalabs/novitaclaw-config/main/openclaw.example.json"
)

# --- API Server ---
API_SERVER_URL = "https://novitaclaw.novita.ai/api"
ENV_VAR_SERVER = "NOVITACLAW_SERVER"

# --- Self-update ---
VENV_DIR_NAME = ".venv"
