"""FastAPI application entry point for the API Server."""

import contextlib
import logging
import pathlib

from fastapi import FastAPI
from starlette.applications import Starlette
from starlette.responses import Response
from starlette.routing import Mount, Route

from .const import SERVER_DESCRIPTION, SERVER_TITLE
from .errors import ServerError
from .logging import LOG_FMT, LOG_RENAME, CleanJsonFormatter, HealthCheckFilter, build_log_config
from .middleware import generic_error_handler, server_error_handler
from .routes import devices, gateway, health, node, pairing, sandboxes, services

# Patch any handlers that uvicorn has already created before this module was imported.
# Covers the bare "uvicorn ... app:app" case (no --log-config).
_JSON_FMT = CleanJsonFormatter(fmt=LOG_FMT, rename_fields=LOG_RENAME)
_HEALTH_FILTER = HealthCheckFilter()
for _name in (None, "uvicorn", "uvicorn.access", "uvicorn.error"):
    _logger = logging.getLogger(_name)
    for _h in _logger.handlers:
        _h.setFormatter(_JSON_FMT)
    if _name == "uvicorn.access":
        _logger.addFilter(_HEALTH_FILTER)
logging.getLogger().setLevel(logging.INFO)

# MCP server (optional — requires mcp package, Python >=3.10)
_mcp_available = False
try:
    from .mcp import get_mcp_app  # noqa: I001
    from .mcp import mcp as _mcp_server

    _mcp_available = True
except ImportError:
    pass


# --- FastAPI app (REST API at /api) ---

api_app = FastAPI(
    title=SERVER_TITLE,
    description=SERVER_DESCRIPTION,
    root_path="/api",
)

# Register error handlers
api_app.add_exception_handler(ServerError, server_error_handler)
api_app.add_exception_handler(Exception, generic_error_handler)

# Include routers
api_app.include_router(health.router)
api_app.include_router(sandboxes.router)
api_app.include_router(gateway.router)
api_app.include_router(node.router)
api_app.include_router(services.router)
api_app.include_router(pairing.router)
api_app.include_router(devices.router)


# --- Top-level Starlette app: mounts REST at /api and MCP at /mcp ---


@contextlib.asynccontextmanager
async def _lifespan(a: Starlette):
    if _mcp_available:
        # StreamableHTTPSessionManager.run() can only be called once per
        # instance.  When the app is re-entered (e.g. in tests), create a
        # fresh session manager so the lifespan succeeds again.
        if _mcp_server.session_manager._has_started:
            _mcp_server.session_manager._has_started = False
        async with _mcp_server.session_manager.run():
            yield
    else:
        yield


# --- Static doc endpoints (content cached at import time) ---

_DOCS_DIR = pathlib.Path(__file__).resolve().parent.parent / "docs"

_STATIC_FILES = [
    ("install.sh", "text/x-shellscript; charset=utf-8"),
    ("install.ps1", "text/plain; charset=utf-8"),
    ("skill.md", "text/markdown; charset=utf-8"),
]


def _static_route(filename, media_type):
    path = _DOCS_DIR / filename
    content = path.read_text()  # fail loudly at startup if missing

    async def handler(request):
        return Response(content, media_type=media_type)

    return Route("/{f}".format(f=filename), handler)


_routes = [_static_route(f, mt) for f, mt in _STATIC_FILES] + [
    Mount("/api", app=api_app),
]
if _mcp_available:
    _routes.append(Mount("", app=get_mcp_app()))

# MCP SDK removes its RichHandler above, which may leave the root logger with
# no handlers at all.  Ensure it always has a JSON-formatted one so that
# third-party loggers (mcp.*, sandbox SDK, httpx) still emit JSON.
_root_logger = logging.getLogger()
if not _root_logger.handlers:
    _json_handler = logging.StreamHandler()
    _json_handler.setFormatter(_JSON_FMT)
    _root_logger.addHandler(_json_handler)

app = Starlette(routes=_routes, lifespan=_lifespan)


def main():
    """Entry point for the API server command."""
    import uvicorn

    app_path = "{pkg}.app:app".format(pkg=__package__)
    uvicorn.run(app_path, host="0.0.0.0", port=8000, reload=False, log_config=build_log_config())
