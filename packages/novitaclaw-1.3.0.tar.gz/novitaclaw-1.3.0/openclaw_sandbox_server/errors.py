"""Server error hierarchy for the API Server."""


class ServerError(Exception):
    """Base exception for structured server errors."""

    def __init__(
        self, message: str, error_code: str, http_status: int = 500, remediation: str = ""
    ):
        super().__init__(message)
        self.error_code = error_code
        self.http_status = http_status
        self.remediation = remediation


class MissingApiKeyError(ServerError):
    def __init__(self, message: str = "API key is required."):
        super().__init__(
            message,
            "MISSING_API_KEY",
            401,
            remediation="Pass api_key in the request body or set the API key environment variable.",
        )


class SandboxCreateError(ServerError):
    def __init__(self, message: str = "Failed to create sandbox."):
        super().__init__(
            message,
            "SANDBOX_CREATE_FAILED",
            502,
            remediation="Check API key validity and account quota, then retry.",
        )


class SandboxConnectError(ServerError):
    def __init__(self, message: str = "Failed to connect to sandbox."):
        super().__init__(
            message,
            "SANDBOX_CONNECT_FAILED",
            502,
            remediation="Verify the sandbox ID is correct and the sandbox is running.",
        )


class GatewayTimeoutError(ServerError):
    def __init__(self, message: str = "Gateway did not start in time."):
        super().__init__(
            message,
            "GATEWAY_TIMEOUT",
            504,
            remediation="Run 'doctor --fix' to diagnose, or increase the timeout.",
        )


class GatewayError(ServerError):
    def __init__(self, message: str = "Gateway operation failed."):
        super().__init__(
            message,
            "GATEWAY_FAILED",
            502,
            remediation="Run 'doctor --fix' to diagnose and repair the gateway.",
        )


class GatewayUpdateError(ServerError):
    def __init__(self, message: str = "Gateway update failed."):
        super().__init__(
            message,
            "GATEWAY_UPDATE_FAILED",
            502,
            remediation="Retry the update, or run 'doctor --fix' if the issue persists.",
        )


class DoctorError(ServerError):
    def __init__(self, message: str = "Doctor command failed."):
        super().__init__(message, "DOCTOR_FAILED", 500)


class PairingError(ServerError):
    def __init__(self, message: str = "Pairing command failed."):
        super().__init__(
            message,
            "PAIRING_FAILED",
            500,
            remediation="Verify the channel name and pairing code, then retry.",
        )


class ServiceConfigError(ServerError):
    def __init__(self, message: str = "Service configuration failed."):
        super().__init__(message, "SERVICE_CONFIG_FAILED", 500)


class NodeStartError(ServerError):
    def __init__(self, message: str = "Node failed to start."):
        super().__init__(
            message,
            "NODE_START_FAILED",
            502,
            remediation="Check the node log at /tmp/node.log inside the sandbox.",
        )


class SandboxPauseError(ServerError):
    def __init__(self, message: str = "Failed to pause sandbox."):
        super().__init__(
            message,
            "SANDBOX_PAUSE_FAILED",
            502,
            remediation="Verify the sandbox is running, then retry.",
        )


class SandboxResumeError(ServerError):
    def __init__(self, message: str = "Failed to resume sandbox."):
        super().__init__(
            message,
            "SANDBOX_RESUME_FAILED",
            502,
            remediation="Verify the sandbox is paused and your API key is valid, then retry.",
        )


class DeviceError(ServerError):
    def __init__(self, message: str = "Device command failed."):
        super().__init__(
            message,
            "DEVICE_FAILED",
            500,
            remediation="Verify the gateway sandbox is running and openclaw is installed.",
        )
