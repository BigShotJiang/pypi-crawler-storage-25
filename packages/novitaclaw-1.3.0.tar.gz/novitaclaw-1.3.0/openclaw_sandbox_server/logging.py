"""JSON log formatter that strips uvicorn's color_message extra field."""

import logging
import os

from pythonjsonlogger.json import JsonFormatter

LOG_FMT = "%(asctime)s %(levelname)s %(name)s %(pathname)s %(lineno)s %(message)s"
LOG_RENAME = {"asctime": "timestamp", "levelname": "level"}

_CWD = os.getcwd() + os.sep


class CleanJsonFormatter(JsonFormatter):
    """JsonFormatter that merges pathname:lineno into a single ``location`` field."""

    _DROP_KEYS = frozenset(("color_message", "pathname", "lineno"))

    def add_fields(self, log_record, record, message_dict):
        super().add_fields(log_record, record, message_dict)
        # Only add "location" for application code; uvicorn internals are not useful.
        if not record.name.startswith("uvicorn"):
            path = record.pathname
            if path.startswith(_CWD):
                path = path[len(_CWD) :]
            log_record["location"] = "{path}:{line}".format(path=path, line=record.lineno)
        for key in self._DROP_KEYS:
            log_record.pop(key, None)


class HealthCheckFilter(logging.Filter):
    """Suppress access-log entries for the health-check endpoint."""

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        return "/health" not in msg


def build_log_config() -> dict:
    """Build a logging dictConfig that routes all output through CleanJsonFormatter."""
    return {
        "version": 1,
        "disable_existing_loggers": False,
        "filters": {
            "no_health": {"()": HealthCheckFilter},
        },
        "formatters": {
            "json": {
                "()": CleanJsonFormatter,
                "fmt": LOG_FMT,
                "rename_fields": LOG_RENAME,
            },
        },
        "handlers": {
            "default": {
                "formatter": "json",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stderr",
            },
            "access": {
                "formatter": "json",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stdout",
                "filters": ["no_health"],
            },
        },
        "root": {
            "handlers": ["default"],
            "level": "INFO",
        },
        "loggers": {
            "uvicorn": {"handlers": ["default"], "level": "INFO", "propagate": False},
            "uvicorn.error": {"level": "INFO"},
            "uvicorn.access": {"handlers": ["access"], "level": "INFO", "propagate": False},
        },
    }
