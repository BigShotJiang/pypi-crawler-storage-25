"""OpenClaw configuration and service management."""

import json
import logging
import os
import shlex
import time
import urllib.request
from urllib.parse import urlparse

from .const import API_KEY_PLACEHOLDER, OPENCLAW_CONFIG_URL, OPENCLAW_NODE_LOG
from .errors import GatewayTimeoutError, GatewayUpdateError, NodeStartError
from .sandbox import SandboxManager

logger = logging.getLogger(__name__)

GATEWAY_PORT = 18789
OPENCLAW_CONFIG_PATH = "/home/user/.openclaw/openclaw.json"
_LEGACY_CONFIG_PATH = "/home/user/.openclaw/config.json"
_EXEC_APPROVALS_PATH = "/home/user/.openclaw/exec-approvals.json"


def load_openclaw_config_template() -> dict:
    try:
        resp = urllib.request.urlopen(OPENCLAW_CONFIG_URL, timeout=10)
        return json.loads(resp.read())
    except Exception:
        logger.info("Could not fetch remote config, using local template.")
        example_path = os.path.join(os.path.dirname(__file__), "openclaw.example.json")
        with open(example_path) as f:
            return json.load(f)


def generate_openclaw_config(api_key: str) -> dict:
    config = load_openclaw_config_template()
    for provider in config.get("models", {}).get("providers", {}).values():
        if provider.get("apiKey") == API_KEY_PLACEHOLDER:
            provider["apiKey"] = api_key
    config.setdefault("gateway", {})
    config["gateway"]["mode"] = "local"
    config["gateway"]["controlUi"] = {
        "dangerouslyAllowHostHeaderOriginFallback": True,
        "dangerouslyDisableDeviceAuth": True,
    }
    config.setdefault("tools", {}).setdefault("exec", {}).update(
        {
            "security": "full",
            "ask": "off",
        }
    )
    return config


def configure_openclaw(manager: SandboxManager, api_key: str):
    config = generate_openclaw_config(api_key)
    config_content = json.dumps(config, indent=2)
    manager.run_command(
        "mkdir -p /home/user/.openclaw && chmod 700 /home/user/.openclaw",
        timeout=10,
    )
    logger.info("Writing OpenClaw configuration to sandbox...")
    manager.write_file(OPENCLAW_CONFIG_PATH, config_content)
    manager.run_command("chmod 600 {config}".format(config=OPENCLAW_CONFIG_PATH), timeout=10)
    logger.info("OpenClaw configuration written")
    _export_env = (
        "grep -q OPENCLAW_CONFIG_PATH /home/user/.bashrc 2>/dev/null"
        " || echo 'export OPENCLAW_CONFIG_PATH=\"{config}\"' >> /home/user/.bashrc"
    ).format(config=OPENCLAW_CONFIG_PATH)
    manager.run_command(_export_env, timeout=10)
    _write_exec_approvals(manager)
    _fix_extensions_permissions(manager)
    stop_gateway(manager)


def _write_exec_approvals(manager: SandboxManager):
    """Write permissive exec-approvals so nodes can run commands without operator UI."""
    approvals = json.dumps(
        {"version": 1, "defaults": {"security": "full", "ask": "off", "askFallback": "full"}},
    )
    manager.write_file(_EXEC_APPROVALS_PATH, approvals)
    manager.run_command("chmod 600 {path}".format(path=_EXEC_APPROVALS_PATH), timeout=10)
    logger.info("Exec approvals written (security=full)")


def launch_gateway(manager: SandboxManager):
    logger.info("Starting OpenClaw Gateway...")
    manager.run_command(
        "nohup bash -c 'OPENCLAW_CONFIG_PATH={config} openclaw gateway run"
        " --port {port} --bind lan'"
        " > /tmp/gateway.log 2>&1 &".format(config=OPENCLAW_CONFIG_PATH, port=GATEWAY_PORT),
        timeout=10,
    )


def start_gateway(manager: SandboxManager):
    launch_gateway(manager)
    wait_for_gateway(manager)


def _collect_log_tail(manager: SandboxManager, log_path: str) -> str:
    """Read the last 30 lines of a log file inside the sandbox. Returns empty string on failure."""
    result = manager.run_command("tail -30 {log} 2>&1 || true".format(log=log_path), timeout=5)
    if result and result.stdout and result.stdout.strip():
        text = result.stdout.strip()
        logger.error("Log tail (%s):\n%s", log_path, text)
        return text
    return ""


def wait_for_gateway(manager: SandboxManager, max_checks: int = 120):
    for i in range(max_checks):
        result = manager.run_command(
            'curl -s --max-time 2 -o /dev/null -w "%{{http_code}}"'
            " http://localhost:{port}/ 2>/dev/null; echo".format(port=GATEWAY_PORT),
            timeout=10,
        )
        if result and result.stdout and result.stdout.strip() == "200":
            logger.info("OpenClaw Gateway is listening on port %d", GATEWAY_PORT)
            return
        logger.info("  Waiting for Gateway to start (%d/%d)...", i + 1, max_checks)
        time.sleep(1)
    log_text = _collect_log_tail(manager, "/tmp/gateway.log")
    raise GatewayTimeoutError(
        "Gateway did not start in time. Check sandbox logs." + ("\n" + log_text if log_text else "")
    )


def stop_gateway(manager: SandboxManager):
    logger.info("Stopping OpenClaw Gateway...")
    _env = "OPENCLAW_CONFIG_PATH={config}".format(config=OPENCLAW_CONFIG_PATH)
    manager.run_command(
        "{env} openclaw daemon stop 2>/dev/null || true".format(env=_env),
        timeout=15,
        silent=True,
    )
    manager.run_command(
        "{env} openclaw gateway stop 2>/dev/null || true".format(env=_env),
        timeout=15,
        silent=True,
    )
    manager.run_command(
        "pkill -9 -f 'openclaw' 2>/dev/null || true",
        timeout=10,
        silent=True,
    )
    time.sleep(2)
    logger.info("OpenClaw Gateway stopped")


def restart_gateway(manager: SandboxManager):
    stop_gateway(manager)
    start_gateway(manager)


def update_openclaw(manager: SandboxManager) -> str:
    _env = "OPENCLAW_CONFIG_PATH={config}".format(config=OPENCLAW_CONFIG_PATH)
    logger.info("Updating OpenClaw...")
    result = manager.run_command(
        "{env} openclaw update --yes --no-restart 2>&1".format(env=_env),
        timeout=600,
    )
    if result is None:
        raise GatewayUpdateError("Failed to run openclaw update. Check sandbox connectivity.")
    output_text = result.stdout.strip() if result.stdout else ""
    logger.info("OpenClaw updated")
    _fix_extensions_permissions(manager)
    restart_gateway(manager)
    return output_text


def _fix_extensions_permissions(manager: SandboxManager):
    logger.info("Fixing OpenClaw extensions permissions...")
    fix_cmd = (
        "EXT=/usr/local/lib/node_modules/openclaw/extensions"
        ' && if [ -d "$EXT" ]; then'
        '   cp -r "$EXT" /tmp/_oc_ext_fix'
        '   && rm -rf "$EXT"'
        '   && mv /tmp/_oc_ext_fix "$EXT"'
        '   && find "$EXT" -type d -exec chmod 755 {} +'
        '   && find "$EXT" -type f -exec chmod 644 {} +'
        "   && echo ok; fi"
    )
    fix_result = manager.run_command(fix_cmd, timeout=30)
    if fix_result and fix_result.stdout and "ok" in fix_result.stdout:
        logger.info("OpenClaw extensions permissions fixed")
    else:
        logger.info("Extensions directory not found or already fixed")


def _read_config(manager: SandboxManager) -> str:
    try:
        content = manager.read_file(OPENCLAW_CONFIG_PATH)
        if content:
            return content
    except Exception:
        pass
    try:
        content = manager.read_file(_LEGACY_CONFIG_PATH)
        if content:
            return content
    except Exception:
        pass
    return ""


def get_gateway_token(manager: SandboxManager) -> str:
    content = _read_config(manager)
    if content:
        try:
            config = json.loads(content)
            return config.get("gateway", {}).get("auth", {}).get("token", "")
        except (json.JSONDecodeError, AttributeError):
            pass
    return ""


def get_public_urls(manager: SandboxManager) -> dict:
    host = manager.sandbox.get_host(GATEWAY_PORT)
    return {
        "gateway_ws": "wss://{host}".format(host=host),
        "webui": "https://{host}".format(host=host),
    }


# --- Node mode ---


def _parse_ws_host_port(gateway_url: str) -> tuple:
    """Extract (host, port, use_tls) from a wss://host:port or wss://host URL.

    Returns the default WSS port (443) when no explicit port is given for
    wss:// URLs, since the sandbox proxy terminates TLS on 443.
    Uses urlparse for robust parsing. Raises ValueError on invalid input.
    """
    parsed = urlparse(gateway_url)
    host = parsed.hostname
    use_tls = parsed.scheme == "wss"
    if parsed.port:
        port = parsed.port
    elif use_tls:
        port = 443
    else:
        port = GATEWAY_PORT
    if not host:
        raise ValueError("Invalid gateway URL: no host found in '{url}'".format(url=gateway_url))
    return host, port, use_tls


def _write_node_config(manager: SandboxManager):
    """Write openclaw config with exec security settings for the node."""
    node_config = {"tools": {"exec": {"security": "full", "ask": "off"}}}
    config = json.dumps(node_config, indent=2)
    result = manager.run_command(
        "mkdir -p /home/user/.openclaw && chmod 700 /home/user/.openclaw",
        timeout=10,
    )
    if result is None:
        raise NodeStartError("Failed to create config directory in sandbox.")
    manager.write_file(OPENCLAW_CONFIG_PATH, config)
    manager.run_command("chmod 600 {config}".format(config=OPENCLAW_CONFIG_PATH), timeout=10)
    logger.info("Node config written")


def launch_node(
    manager: SandboxManager, gateway_url: str, display_name: str, gateway_token: str = ""
):
    """Start the openclaw node process connecting to a gateway."""
    _write_node_config(manager)
    host, port, use_tls = _parse_ws_host_port(gateway_url)
    logger.info(
        "Starting OpenClaw Node (gateway=%s:%d, tls=%s, name=%s)...",
        host,
        port,
        use_tls,
        display_name,
    )
    tls_flag = " --tls" if use_tls else ""
    token_env = (
        " OPENCLAW_GATEWAY_TOKEN={tok}".format(tok=shlex.quote(gateway_token))
        if gateway_token
        else ""
    )
    cmd = (
        "nohup bash -c 'OPENCLAW_CONFIG_PATH={config}{token_env} openclaw node run"
        " --host {host} --port {port}{tls}"
        " --display-name {name}'"
        " > {log} 2>&1 &"
    ).format(
        config=OPENCLAW_CONFIG_PATH,
        token_env=token_env,
        host=shlex.quote(host),
        port=port,
        tls=tls_flag,
        name=shlex.quote(display_name),
        log=OPENCLAW_NODE_LOG,
    )
    result = manager.run_command(cmd, timeout=10)
    if result is None:
        raise NodeStartError("Failed to launch node process in sandbox.")


def _is_node_alive(manager: SandboxManager) -> bool:
    """Check if the openclaw node process is running."""
    proc = manager.run_command(
        "pgrep '[o]penclaw' > /dev/null 2>&1 && echo ok || true",
        timeout=5,
        silent=True,
    )
    return bool(proc and proc.stdout and "ok" in proc.stdout)


def wait_for_node(
    manager: SandboxManager,
    max_checks: int = 30,
    stable_count: int = 3,
):
    """Wait for the node process to start (process stability only).

    Confirms the process is alive across several consecutive pgrep checks.
    Pairing detection is left to the caller (CLI polls ``check_node_status``).
    """
    alive_streak = 0
    for i in range(max_checks):
        if _is_node_alive(manager):
            alive_streak += 1
            if alive_streak >= stable_count:
                logger.info("OpenClaw Node process is running (stable)")
                return
            logger.info("  Node alive (%d/%d stable checks)...", alive_streak, stable_count)
        else:
            alive_streak = 0
            logger.info("  Waiting for Node process (%d/%d)...", i + 1, max_checks)
        time.sleep(2)

    log_text = _collect_log_tail(manager, OPENCLAW_NODE_LOG)
    raise NodeStartError("Node failed to start." + ("\n" + log_text if log_text else ""))


def check_node_status(manager: SandboxManager, gateway_url: str) -> dict:
    """Check node process and pairing status.

    Returns a dict with:
      - ``alive``: node process is running
      - ``paired``: TCP connection to gateway is established

    Before pairing the gateway rejects the connect handshake with
    NOT_PAIRED and closes the WebSocket, so there is no persistent TCP
    connection.  After pairing approval the next reconnect succeeds and
    the connection stays up — an established TCP socket to the gateway
    port is the signal that pairing is complete.
    """
    alive = _is_node_alive(manager)

    paired = False
    if alive:
        _, port, _ = _parse_ws_host_port(gateway_url)
        conn = manager.run_command(
            "ss -tn state established '( dport = :{port} )' 2>/dev/null"
            " | tail -n +2 | grep -q . && echo ok || true".format(port=port),
            timeout=5,
            silent=True,
        )
        if conn and conn.stdout and "ok" in conn.stdout:
            paired = True

    return {"alive": alive, "paired": paired}


def reconnect_node(
    manager: SandboxManager, gateway_url: str, display_name: str, gateway_token: str = ""
):
    """Re-launch node only if the process has died. Skip if still alive."""
    if _is_node_alive(manager):
        logger.info("Node process still alive, skipping reconnect")
        return
    logger.info("Node process dead, relaunching...")
    launch_node(manager, gateway_url, display_name, gateway_token=gateway_token)


def stop_node(manager: SandboxManager):
    """Stop the openclaw node process inside the sandbox."""
    logger.info("Stopping OpenClaw Node...")
    manager.run_command(
        "pkill -9 openclaw 2>/dev/null || true",
        timeout=10,
        silent=True,
    )
    time.sleep(1)
    logger.info("OpenClaw Node stopped")
