"""Pydantic request/response models for the API Server."""

from __future__ import annotations

from typing import List, Literal, Optional

from pydantic import BaseModel, Field

# --- Requests ---


class LaunchRequest(BaseModel):
    timeout: int = Field(default=180, description="Sandbox creation timeout in seconds")
    template_id: Optional[str] = Field(default=None, description="Override template ID")
    mode: Literal["gateway", "node"] = Field(
        default="gateway",
        description="Launch mode: 'gateway' (default) or 'node'",
    )
    display_name: Optional[str] = Field(
        default=None,
        description="Node display name shown in the gateway (node mode only).",
    )


class NodeConnectRequest(BaseModel):
    gateway_url: str = Field(
        description="Target gateway WebSocket URL (wss://...) to connect the node to.",
    )
    gateway_token: Optional[str] = Field(
        default=None,
        description="Gateway auth token for authenticating with the gateway.",
    )


class PairingApproveRequest(BaseModel):
    channel: str = Field(description="Channel name (telegram, discord, etc.)")
    code: str = Field(description="Pairing code to approve")


class DeviceApproveRequest(BaseModel):
    request_id: Optional[str] = Field(
        default=None,
        description="Request ID to approve. If omitted, all pending devices are approved.",
    )


# --- Responses ---


class ErrorResponse(BaseModel):
    status: str = "error"
    error_code: str
    message: str


class HealthResponse(BaseModel):
    status: str = "ok"


class SandboxInfo(BaseModel):
    sandbox_id: str
    state: str
    mode: Literal["gateway", "node"] = "gateway"
    cpu: Optional[int] = None
    memory_mb: Optional[int] = None
    started_at: Optional[str] = None


class SandboxListResponse(BaseModel):
    status: str = "ok"
    sandboxes: List[SandboxInfo]


class SandboxResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    mode: Literal["gateway", "node"] = "gateway"
    keep_alive: Optional[int] = None
    # Gateway mode fields
    webui: Optional[str] = None
    gateway_ws: Optional[str] = None
    gateway_token: Optional[str] = None
    # Node mode fields
    node_display_name: Optional[str] = None
    # Shared fields
    terminal_url: Optional[str] = None
    filemanager_url: Optional[str] = None
    services_username: Optional[str] = None
    services_password: Optional[str] = None
    state: Optional[str] = None
    message: Optional[str] = None


class NodeResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    node_display_name: Optional[str] = None
    gateway_url: Optional[str] = None
    message: Optional[str] = None


class NodeStatusResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    alive: bool = False
    paired: bool = False


class MessageResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    message: str


class GatewayResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    output: Optional[str] = None
    restarted: Optional[bool] = None
    webui: Optional[str] = None
    gateway_ws: Optional[str] = None
    gateway_token: Optional[str] = None
    message: Optional[str] = None


class DoctorResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    output: str


class PairingResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    channel: Optional[str] = None
    code: Optional[str] = None
    output: str


class DevicesResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    approved: Optional[List[str]] = None
    output: str


class ServiceResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    terminal_url: Optional[str] = None
    filemanager_url: Optional[str] = None
    services_username: Optional[str] = None
    services_password: Optional[str] = None
    already_configured: Optional[bool] = None
