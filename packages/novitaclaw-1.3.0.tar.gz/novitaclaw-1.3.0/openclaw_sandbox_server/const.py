"""Brand constants for NovitaClaw Server (Novita variant).

This is the ONLY file that differs between brand variants on the server side.
"""

import os

# --- Brand ---
BRAND_NAME = "NovitaClaw"
SERVER_TITLE = "NovitaClaw API Server"
SERVER_DESCRIPTION = "API Server for NovitaClaw sandbox management"

# --- Sandbox ---
TEMPLATE_ID = os.environ.get("NOVITACLAW_TEMPLATE_ID", "openclaw")
SANDBOX_APP_LABEL = "novita-openclaw"
SDK_PACKAGE = "novita_sandbox"

# --- OpenClaw config ---
API_KEY_PLACEHOLDER = "NOVITA_API_KEY"
OPENCLAW_CONFIG_URL = (
    "https://raw.githubusercontent.com/novitalabs/novitaclaw-config/main/openclaw.example.json"
)

# --- Sandbox services ---
SERVICES_DIR = "/home/user/.novitaclaw"
TTYD_PORT = 7681
FILE_MANAGER_PORT = 7682
SERVICES_USERNAME = "admin"

# --- OpenClaw node ---
OPENCLAW_NODE_LOG = "/tmp/node.log"


def default_node_name(sandbox_id: str) -> str:
    """Generate a default node display name from sandbox ID."""
    return "node-{id}".format(id=sandbox_id[:8])
