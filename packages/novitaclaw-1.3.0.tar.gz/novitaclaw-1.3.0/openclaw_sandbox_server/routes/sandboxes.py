"""Sandbox CRUD endpoints."""

from fastapi import APIRouter, Depends

from ..const import TEMPLATE_ID, default_node_name
from ..deps import get_api_key
from ..errors import SandboxConnectError, SandboxResumeError
from ..openclaw import (
    configure_openclaw,
    get_gateway_token,
    get_public_urls,
    launch_gateway,
    wait_for_gateway,
)
from ..sandbox import SANDBOX_KEEP_ALIVE, SandboxManager, SandboxState
from ..schemas import (
    LaunchRequest,
    MessageResponse,
    SandboxListResponse,
    SandboxResponse,
)
from ..services import configure_services, get_service_credentials, get_service_urls
from ._helpers import build_webui_url, connect_sandbox

router = APIRouter(prefix="/sandboxes", tags=["sandboxes"])


def _state_str(state) -> str:
    """Convert a SandboxState enum (or fallback) to a plain string."""
    return str(state.value) if hasattr(state, "value") else str(state)


def _get_sandbox_metadata(manager: SandboxManager) -> dict:
    """Get sandbox metadata via get_info() API."""
    info = manager.get_info()
    if info:
        return getattr(info, "metadata", None) or {}
    return {}


def _detect_mode_from_meta(meta: dict) -> str:
    """Extract sandbox mode from a metadata dict, defaulting to 'gateway'."""
    mode = meta.get("mode")
    return mode if mode in ("gateway", "node") else "gateway"


@router.post("", response_model=SandboxResponse)
def create_sandbox(body: LaunchRequest, api_key: str = Depends(get_api_key)):
    """Create a new sandbox (mirrors CLI launch flow)."""
    template_id = body.template_id or TEMPLATE_ID
    manager = SandboxManager(template_id, api_key=api_key)
    sandbox = manager.create(timeout=body.timeout, mode=body.mode, display_name=body.display_name)
    sandbox.set_timeout(SANDBOX_KEEP_ALIVE)

    try:
        if body.mode == "node":
            node_name = body.display_name or default_node_name(sandbox.sandbox_id)
            return _launch_node(manager, sandbox, node_name)
        return _launch_gateway(manager, sandbox, api_key)
    except Exception:
        manager.kill()
        raise


def _launch_gateway(manager, sandbox, api_key):
    configure_openclaw(manager, api_key)
    launch_gateway(manager)
    service_creds = configure_services(manager)
    wait_for_gateway(manager)
    urls = get_public_urls(manager)
    gw_token = get_gateway_token(manager)
    service_urls = get_service_urls(manager)
    webui_url = build_webui_url(urls, gw_token)

    result = {
        "status": "ok",
        "sandbox_id": sandbox.sandbox_id,
        "mode": "gateway",
        "keep_alive": SANDBOX_KEEP_ALIVE,
        "webui": webui_url,
        "gateway_ws": urls["gateway_ws"],
        "terminal_url": service_urls["terminal"],
        "filemanager_url": service_urls["filemanager"],
        "services_username": service_creds["username"],
        "services_password": service_creds["password"],
    }
    if gw_token:
        result["gateway_token"] = gw_token
    return result


def _launch_node(manager, sandbox, display_name):
    # Node sandboxes only get services configured at launch time.
    # Gateway connection is done separately via POST /sandboxes/{id}/node/connect.
    service_creds = configure_services(manager)
    service_urls = get_service_urls(manager)

    return {
        "status": "ok",
        "sandbox_id": sandbox.sandbox_id,
        "mode": "node",
        "node_display_name": display_name,
        "keep_alive": SANDBOX_KEEP_ALIVE,
        "terminal_url": service_urls["terminal"],
        "filemanager_url": service_urls["filemanager"],
        "services_username": service_creds["username"],
        "services_password": service_creds["password"],
    }


@router.get("", response_model=SandboxListResponse)
def list_sandboxes(api_key: str = Depends(get_api_key)):
    """List all active sandboxes."""
    sandboxes = SandboxManager.list_app_sandboxes(api_key=api_key)
    return {
        "status": "ok",
        "sandboxes": [
            {
                "sandbox_id": sbx.sandbox_id,
                "state": _state_str(sbx.state),
                "mode": (
                    sbx.metadata.get("mode", "gateway") if hasattr(sbx, "metadata") else "gateway"
                ),
                "cpu": sbx.cpu_count,
                "memory_mb": sbx.memory_mb,
                "started_at": sbx.started_at.isoformat(),
            }
            for sbx in sandboxes
        ],
    }


@router.get("/{sandbox_id}", response_model=SandboxResponse)
def get_sandbox(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Get sandbox status and access URLs (mirrors CLI status flow).

    For paused sandboxes this returns basic info without connecting,
    so it will NOT resume the sandbox.
    """
    # Fetch info without connecting to avoid resuming paused sandboxes
    info = SandboxManager.get_sandbox_info(sandbox_id, api_key=api_key)
    meta = info.metadata if info.metadata else {}
    mode = _detect_mode_from_meta(meta)

    result = {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "mode": mode,
        "state": _state_str(info.state),
    }

    if mode == "node":
        result["node_display_name"] = meta.get("display_name", default_node_name(sandbox_id))

    # Paused sandboxes have no accessible services; return basic info only
    if info.state == SandboxState.PAUSED:
        return result

    # Running sandbox: connect to get URLs and credentials
    manager = connect_sandbox(sandbox_id, api_key)

    if mode == "gateway":
        urls = get_public_urls(manager)
        gw_token = get_gateway_token(manager)
        webui_url = build_webui_url(urls, gw_token)
        result["webui"] = webui_url
        result["gateway_ws"] = urls["gateway_ws"]
        if gw_token:
            result["gateway_token"] = gw_token

    service_creds = get_service_credentials(manager)
    service_urls = get_service_urls(manager) if service_creds else {}
    if service_urls:
        result["terminal_url"] = service_urls["terminal"]
        result["filemanager_url"] = service_urls["filemanager"]
    if service_creds:
        result["services_username"] = service_creds["username"]
        result["services_password"] = service_creds["password"]
    return result


@router.post("/{sandbox_id}/pause", response_model=MessageResponse)
def pause_sandbox(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Pause a running sandbox. All filesystem and memory state are preserved."""
    manager = connect_sandbox(sandbox_id, api_key)
    manager.pause()
    return {"status": "ok", "sandbox_id": sandbox_id, "message": "Sandbox paused"}


@router.post("/{sandbox_id}/resume", response_model=MessageResponse)
def resume_sandbox(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Resume a paused sandbox."""
    try:
        connect_sandbox(sandbox_id, api_key)
    except SandboxConnectError as e:
        raise SandboxResumeError(str(e)) from e
    return {"status": "ok", "sandbox_id": sandbox_id, "message": "Sandbox resumed"}


@router.delete("/{sandbox_id}", response_model=MessageResponse)
def delete_sandbox(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Stop and terminate a sandbox."""
    manager = connect_sandbox(sandbox_id, api_key)
    manager.kill()
    return {"status": "ok", "sandbox_id": sandbox_id, "message": "Sandbox terminated"}
