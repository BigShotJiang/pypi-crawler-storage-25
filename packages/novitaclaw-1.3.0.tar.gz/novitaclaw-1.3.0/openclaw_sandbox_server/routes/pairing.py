"""Pairing management endpoints."""

from fastapi import APIRouter, Depends, Query

from ..deps import get_api_key
from ..errors import PairingError
from ..openclaw import OPENCLAW_CONFIG_PATH
from ..sandbox import SandboxManager
from ..schemas import PairingApproveRequest
from ._helpers import connect_sandbox

router = APIRouter(prefix="/sandboxes/{sandbox_id}/pairing", tags=["pairing"])


def _run_pairing_cmd(manager: SandboxManager, raw_cmd: str) -> str:
    cmd = "OPENCLAW_CONFIG_PATH={config} {raw}; true".format(
        config=OPENCLAW_CONFIG_PATH,
        raw=raw_cmd,
    )
    result = manager.run_command(cmd, timeout=30)
    if result is None:
        raise PairingError(
            "Pairing command failed to execute. "
            "Check sandbox connectivity and that openclaw is installed."
        )
    return result.stdout.strip() if result.stdout else ""


@router.get("")
def pairing_list(
    sandbox_id: str,
    channel: str = Query(..., description="Channel name"),
    api_key: str = Depends(get_api_key),
):
    """List pending pairing requests for a channel."""
    manager = connect_sandbox(sandbox_id, api_key)

    output_text = _run_pairing_cmd(
        manager,
        "openclaw pairing list {channel} 2>&1".format(channel=channel),
    )
    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "channel": channel,
        "output": output_text,
    }


@router.post("/approve")
def pairing_approve(
    sandbox_id: str,
    body: PairingApproveRequest,
    api_key: str = Depends(get_api_key),
):
    """Approve a pending pairing request."""
    manager = connect_sandbox(sandbox_id, api_key)

    output_text = _run_pairing_cmd(
        manager,
        "openclaw pairing approve {channel} {code} 2>&1".format(
            channel=body.channel, code=body.code
        ),
    )
    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "channel": body.channel,
        "code": body.code,
        "output": output_text,
    }
