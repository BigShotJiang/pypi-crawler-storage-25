from typing import Any, Dict, List, Literal, Optional, Tuple, Type, TypeVar
import json
import dataclasses
import logging

import opik.exceptions
from opik.rest_api import client as rest_client, PromptVersionUpdate
from opik.rest_api import core as rest_api_core
from opik.rest_api.types import prompt_version_detail
from opik.api_objects import opik_query_language, rest_helpers
from . import types as prompt_types
from . import prompt_cache
from . import mask_context as prompt_mask_context_module
from .base_prompt import BasePrompt

LOGGER = logging.getLogger(__name__)

_PromptT = TypeVar("_PromptT", bound=BasePrompt)


@dataclasses.dataclass
class PromptSearchResult:
    """Result from searching prompts, containing name, template structure, and latest version details."""

    name: str
    template_structure: str
    prompt_version_detail: prompt_version_detail.PromptVersionDetail
    project_name: Optional[str]


class PromptClient:
    def __init__(self, client: rest_client.OpikApi):
        self._rest_client = client

    def create_prompt(
        self,
        name: str,
        prompt: str,
        metadata: Optional[Dict[str, Any]],
        type: prompt_types.PromptType = prompt_types.PromptType.MUSTACHE,
        template_structure: str = "text",
        id: Optional[str] = None,
        description: Optional[str] = None,
        change_description: Optional[str] = None,
        tags: Optional[List[str]] = None,
        project_name: Optional[str] = None,
    ) -> prompt_version_detail.PromptVersionDetail:
        """
        Creates the prompt detail for the given prompt name and template.

        Parameters:
        - name: The name of the prompt.
        - prompt: The template content for the prompt.
        - metadata: Optional metadata for the prompt.
        - type: The template type (MUSTACHE or JINJA2).
        - template_structure: Either "text" (default) or "chat".
        - id: Optional unique identifier (UUID) for the prompt.
        - description: Optional description of the prompt (up to 255 characters).
        - change_description: Optional description of changes in this version.
        - tags: Optional list of tags to associate with the prompt.
        - project_name: Optional project name to associate with the prompt. If not provided, the default project will be used.

        Returns:
        - A Prompt object for the provided prompt name and template.

        Raises:
        - PromptTemplateStructureMismatch: If a prompt with the same name already exists but has a different
          template_structure (e.g., trying to create a text prompt when a chat prompt exists, or vice versa).
          Template structure is immutable after prompt creation.
        """
        prompt_version = self._get_latest_version(name, project_name=project_name)

        # For chat prompts, compare parsed JSON to avoid formatting differences
        templates_equal = False

        if prompt_version is not None:
            if prompt_version.template_structure != template_structure:
                raise opik.exceptions.PromptTemplateStructureMismatch(
                    prompt_name=name,
                    existing_structure=prompt_version.template_structure,
                    attempted_structure=template_structure,
                )

            if template_structure == "chat":
                try:
                    existing_messages = json.loads(prompt_version.template)
                    new_messages = json.loads(prompt)
                    templates_equal = existing_messages == new_messages
                except (json.JSONDecodeError, TypeError):
                    templates_equal = prompt_version.template == prompt
            else:
                templates_equal = prompt_version.template == prompt

        # Create a new version if:
        # - No version exists yet (new prompt)
        # - Template content has changed
        # - Metadata has changed
        # - Type has changed
        # Note: template_structure is immutable and used by the backend only if it is the first prompt version.
        if (
            prompt_version is None
            or not templates_equal
            or prompt_version.metadata != metadata
            or prompt_version.type != type.value
        ):
            prompt_version = self._create_new_version(
                name=name,
                prompt=prompt,
                type=type,
                metadata=metadata,
                project_name=project_name,
                is_new=prompt_version is None,
                template_structure=template_structure,
                id=id,
                description=description,
                change_description=change_description,
                tags=tags,
            )

        return prompt_version

    def _create_new_version(
        self,
        name: str,
        prompt: str,
        type: prompt_version_detail.PromptVersionDetailType,
        metadata: Optional[Dict[str, Any]],
        project_name: Optional[str],
        is_new: bool = True,
        template_structure: str = "text",
        id: Optional[str] = None,
        description: Optional[str] = None,
        change_description: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> prompt_version_detail.PromptVersionDetail:
        # If it's a new prompt and container-level params are provided, use create_prompt endpoint
        # which creates both the container and first version in one call
        if is_new and (id is not None or description is not None or tags is not None):
            self._rest_client.prompts.create_prompt(
                name=name,
                id=id,
                description=description,
                template=prompt,
                metadata=metadata,
                change_description=change_description,
                type=type,
                template_structure=template_structure,
                tags=tags,
                project_name=project_name,
            )
            # After creating, retrieve the version that was created
            new_prompt_version_detail = (
                self._rest_client.prompts.retrieve_prompt_version(
                    name=name, project_name=project_name
                )
            )
            # retrieve_prompt_version may not return tags, so we need to set them manually
            # from the tags we just passed to create_prompt
            if tags is not None and new_prompt_version_detail.tags is None:
                # Pydantic objects are frozen, so we copy to inject tags;
                # model_copy preserves every other field automatically.
                new_prompt_version_detail = new_prompt_version_detail.model_copy(
                    update={"tags": tags}
                )
        else:
            # For existing prompts or when no container-level params, use create_prompt_version
            new_prompt_version_detail_data = prompt_version_detail.PromptVersionDetail(
                template=prompt,
                metadata=metadata,
                type=type,
            )
            new_prompt_version_detail = self._rest_client.prompts.create_prompt_version(
                name=name,
                version=new_prompt_version_detail_data,
                template_structure=template_structure,
                project_name=project_name,
            )
        return new_prompt_version_detail

    def _get_latest_version(
        self, name: str, project_name: Optional[str]
    ) -> Optional[prompt_version_detail.PromptVersionDetail]:
        return self.get_prompt(name=name, commit=None, project_name=project_name)

    def get_prompt(
        self,
        name: str,
        commit: Optional[str] = None,
        raise_if_not_template_structure: Optional[str] = None,
        project_name: Optional[str] = None,
        version: Optional[str] = None,
    ) -> Optional[prompt_version_detail.PromptVersionDetail]:
        """
        Retrieve the prompt detail for a given prompt name, optionally
        pinned to a specific ``version``.

        Parameters:
            name: The name of the prompt.
            version: Optional sequential version selector in the wire format
                ``"v<N>"`` (e.g. ``"v3"``). If not provided, the latest
                version is retrieved.
            commit: DEPRECATED in favour of ``version``. Mutually exclusive with ``version``.
            raise_if_not_template_structure: Optional template structure validation. If provided and doesn't match, raises PromptTemplateStructureMismatch.
            project_name: The name of the project to which the prompt belongs. If not provided, the default project is used.

        Returns:
            Prompt: The details of the specified prompt.
        """
        if commit is not None and version is not None:
            raise ValueError(
                "Provide either `commit` or `version`, not both. "
                "Prefer `version` — `commit` is deprecated."
            )
        try:
            prompt_version = self._rest_client.prompts.retrieve_prompt_version(
                name=name,
                commit=commit,
                version_number=version,
                project_name=project_name,
            )

            should_skip_validation = (
                prompt_version.template_structure is None
                and raise_if_not_template_structure == "text"
            )
            if should_skip_validation:
                return prompt_version

            # Client-side validation for template_structure if requested and not skipped
            if (
                raise_if_not_template_structure is not None
                and prompt_version.template_structure != raise_if_not_template_structure
            ):
                raise opik.exceptions.PromptTemplateStructureMismatch(
                    prompt_name=name,
                    existing_structure=prompt_version.template_structure,
                    attempted_structure=raise_if_not_template_structure,
                )

            return prompt_version
        except rest_api_core.ApiError as e:
            if e.status_code != 404:
                raise e
            # 400, 404 - not found
        return None

    def get_prompt_with_cache(
        self,
        name: str,
        commit: Optional[str],
        project_name: Optional[str],
        template_structure: str,
        prompt_cls: Type[_PromptT],
        no_cache: bool = False,
        version: Optional[str] = None,
    ) -> Optional[_PromptT]:
        if commit is not None and version is not None:
            raise ValueError(
                "Provide either `commit` or `version`, not both. "
                "Prefer `version` — `commit` is deprecated."
            )

        def _fetch(mask_id: Optional[str] = None) -> Optional[_PromptT]:
            if mask_id is not None:
                prompt_version = self._rest_client.prompts.get_prompt_version_by_id(
                    version_id=mask_id,
                )
            else:
                prompt_version = self.get_prompt(
                    name=name,
                    commit=commit,
                    raise_if_not_template_structure=template_structure,
                    project_name=project_name,
                    version=version,
                )
            if prompt_version is None:
                return None
            return prompt_cls.from_fern_prompt_version(
                name, prompt_version, project_name=project_name
            )

        def _cached_fetch(
            mask_id: Optional[str] = None,
        ) -> Optional[_PromptT]:
            if no_cache:
                return _fetch(mask_id=mask_id)
            return prompt_cache.get_or_fetch(
                name=name,
                commit=commit,
                project_name=project_name,
                template_structure=template_structure,
                fetch_fn=lambda: _fetch(mask_id=mask_id),
                mask_id=mask_id,
                version=version,
            )

        unmasked = _cached_fetch()
        result = unmasked

        prompt_id = (
            unmasked.__internal_api__prompt_id__ if unmasked is not None else None
        )
        active_mask_id = (
            prompt_mask_context_module.get_mask_for_prompt(prompt_id)
            if prompt_id is not None
            else None
        )
        if active_mask_id is not None:
            result = _cached_fetch(mask_id=active_mask_id)

        if result is not None:
            from opik import opik_context

            opik_context.attach_prompt_to_current_trace(result)
            opik_context.attach_prompt_to_current_span(result)
        return result

    # TODO: Need to add support for prompt name in the BE so we don't
    # need to retrieve the prompt id
    def get_all_prompt_versions(
        self,
        name: str,
        search: Optional[str] = None,
        filter_string: Optional[str] = None,
        project_name: Optional[str] = None,
    ) -> List[prompt_version_detail.PromptVersionDetail]:
        """
        Retrieve all the prompt details for a given prompt name.

        Parameters:
            name: The name of the prompt.
            search: Optional search text to find in the template or change description fields.
            project_name: The name of the project to filter prompts by. If None, all prompts are returned.
            filter_string: A filter string to narrow down the search using Opik Query Language (OQL).
                The format is: "<COLUMN> <OPERATOR> <VALUE> [AND <COLUMN> <OPERATOR> <VALUE>]*"

                Supported columns include:
                - `id`, `commit`, `template`, `change_description`, `created_by`: String fields with full operator support
                - `metadata`: Dictionary field (use dot notation, e.g., "metadata.environment")
                - `type`: Enum field (=, != only)
                - `tags`: List field (use "contains" operator only)
                - `created_at`: DateTime field (use ISO 8601 format, e.g., "2024-01-01T00:00:00Z")

                Examples:
                - `tags contains "production"` - Filter by tag
                - `tags contains "v1" AND tags contains "production"` - Filter by multiple tags
                - `template contains "customer"` - Filter by template content
                - `created_by = "user@example.com"` - Filter by creator
                - `created_at >= "2024-01-01T00:00:00Z"` - Filter by creation date
                - `metadata.environment = "prod"` - Filter by metadata field

        Returns:
            List[PromptVersionDetail]: A list of prompt versions for the given name.

        Example:
            # Get all versions of a prompt
            versions = prompt_client.get_all_prompt_versions(name="my-prompt")

            # Filter by tags (versions containing "production" tag)
            versions = prompt_client.get_all_prompt_versions(
                name="my-prompt",
                filter_string='tags contains "production"')

            # Search for specific text in a template or change description fields
            versions = prompt_client.get_all_prompt_versions(
                name="my-prompt",
                search="customer")

            # Combine search and filtering
            versions = prompt_client.get_all_prompt_versions(
                name="my-prompt",
                search="customer",
                filter_string='tags contains "production"')
        """
        try:
            project_id = rest_helpers.resolve_project_id_by_name_optional(
                self._rest_client, project_name=project_name
            )
            prompts_matching_name_string = self._rest_client.prompts.get_prompts(
                name=name, project_id=project_id
            ).content
            if (
                prompts_matching_name_string is None
                or len(prompts_matching_name_string) == 0
            ):
                raise ValueError("No prompts found for name: " + name)

            filtered_prompt_list = [
                x.id for x in prompts_matching_name_string if name == x.name
            ]
            if len(filtered_prompt_list) == 0:
                raise ValueError("No prompts found for name: " + name)

            filters: Optional[str] = None
            if filter_string:
                oql = opik_query_language.OpikQueryLanguage.for_prompt_versions(
                    filter_string
                )
                filters = oql.parsed_filters

            prompt_id = filtered_prompt_list[0]
            return self._get_prompt_versions_by_id_paginated(
                prompt_id, search=search, filters=filters
            )

        except rest_api_core.ApiError as e:
            if e.status_code != 404:
                raise e

        return []

    def _get_prompt_versions_by_id_paginated(
        self,
        prompt_id: str,
        search: Optional[str] = None,
        filters: Optional[str] = None,
    ) -> List[prompt_version_detail.PromptVersionDetail]:
        page = 1
        size = 100
        prompts: List[prompt_version_detail.PromptVersionDetail] = []
        while True:
            prompt_versions_page = self._rest_client.prompts.get_prompt_versions(
                id=prompt_id,
                page=page,
                size=size,
                search=search,
                filters=filters,
            ).content

            versions = prompt_versions_page or []
            prompts.extend(
                [
                    # Converting to PromptVersionDetail for consistency with other methods.
                    # TODO: backend should implement non-frontend endpoint which will return PromptVersionDetail objects
                    prompt_version_detail.PromptVersionDetail(
                        id=version.id,
                        prompt_id=version.prompt_id,
                        template=version.template,
                        type=version.type,
                        version_type=version.version_type,
                        environment=version.environment,
                        metadata=version.metadata,
                        commit=version.commit,
                        version_number=version.version_number,
                        change_description=version.change_description,
                        template_structure=version.template_structure,
                        created_at=version.created_at,
                        created_by=version.created_by,
                        tags=version.tags,
                    )
                    for version in versions
                ]
            )

            if len(versions) < size:
                break
            page += 1

        return prompts

    def search_prompts(
        self,
        *,
        name: Optional[str] = None,
        parsed_filters: Optional[List[Dict[str, Any]]] = None,
        project_name: Optional[str] = None,
    ) -> List[PromptSearchResult]:
        """
        Search prompt containers by optional name substring and filters, then
        return the latest version detail for each matched prompt container.

        Parameters:
            name: Optional substring of the prompt name to search for.
            parsed_filters: List of parsed filters (OQL) that will be stringified for the backend.
            project_name: The name of the project to search within. If not provided, the default project is used.

        Returns:
            List[PromptSearchResult]: Each result contains name, template_structure, and prompt_version_detail.
        """
        try:
            filters_str = (
                json.dumps(parsed_filters) if parsed_filters is not None else None
            )

            # Page through all prompt containers and collect:
            # (name, template_structure, tags)
            page = 1
            size = 1000
            prompt_info: List[Tuple[str, str, Optional[List[str]]]] = []
            project_id = rest_helpers.resolve_project_id_by_name_optional(
                self._rest_client, project_name=project_name
            )
            while True:
                prompts_page = self._rest_client.prompts.get_prompts(
                    page=page,
                    size=size,
                    name=name,
                    filters=filters_str,
                    project_id=project_id,
                )
                content = prompts_page.content or []
                if len(content) == 0:
                    break
                prompt_info.extend(
                    [(p.name, p.template_structure or "text", p.tags) for p in content]
                )
                if len(content) < size:
                    break
                page += 1

            if len(prompt_info) == 0:
                return []

            # Retrieve latest version for each container name
            results: List[PromptSearchResult] = []
            for prompt_name, template_structure, tags in prompt_info:
                try:
                    latest_version = self._rest_client.prompts.retrieve_prompt_version(
                        name=prompt_name, project_name=project_name
                    )
                    # retrieve_prompt_version may not return tags, so we need to set them from get_prompts response
                    if tags is not None and latest_version.tags is None:
                        # Pydantic objects are frozen, so we copy to inject tags;
                        # model_copy preserves every other field automatically.
                        latest_version = latest_version.model_copy(
                            update={"tags": tags}
                        )
                    results.append(
                        PromptSearchResult(
                            name=prompt_name,
                            template_structure=template_structure,
                            prompt_version_detail=latest_version,
                            project_name=project_name,
                        )
                    )
                except rest_api_core.ApiError as e:
                    # Skip prompts that can't be retrieved (e.g., deleted between search and retrieval)
                    if e.status_code == 404:
                        continue
                    raise e

            return results

        except rest_api_core.ApiError as e:
            if e.status_code != 404:
                raise e
            return []

    def __internal_api__create_mask(
        self,
        name: str,
        prompt: str,
        type: prompt_types.PromptType = prompt_types.PromptType.MUSTACHE,
        metadata: Optional[Dict[str, Any]] = None,
        template_structure: Literal["text", "chat"] = "text",
        project_name: Optional[str] = None,
        change_description: Optional[str] = None,
    ) -> prompt_version_detail.PromptVersionDetail:
        """Create a hidden mask prompt version that overrides get_prompt output when mask context is active.

        Internal API — not intended for end-user use. A mask is a hidden
        prompt version (version_type="mask") that does not appear in the prompt
        history or version listings. When a mask context is active (via
        ``prompt_mask_context``), ``get_prompt`` returns the mask's template
        instead of the latest visible version.

        Args:
            name: Name of the prompt to attach the mask to. The prompt must
                already exist.
            prompt: The template content for the mask version.
            type: Template type (MUSTACHE or JINJA2).
            metadata: Optional metadata dict.
            template_structure: "text" or "chat".
            project_name: Optional project scope. Uses the default project if
                not provided.
            change_description: Optional description of why this mask was
                created.

        Returns:
            The created PromptVersionDetail with version_type="mask".
        """
        new_version = prompt_version_detail.PromptVersionDetail(
            template=prompt,
            metadata=metadata,
            type=type,
            version_type="mask",
            change_description=change_description,
        )
        return self._rest_client.prompts.create_prompt_version(
            name=name,
            version=new_version,
            template_structure=template_structure,
            project_name=project_name,
        )

    def batch_update_prompt_version_tags(
        self,
        version_ids: List[str],
        tags: Optional[List[str]] = None,
        merge: Optional[bool] = None,
    ) -> None:
        """
        Update tags for one or more prompt versions in a single batch operation.

        Parameters:
            version_ids: List of prompt version IDs to update.
            tags: Tags to set or merge. Semantics:
                - None: No change to tags (preserves existing tags).
                - []: Clear all tags (when merge is False or None).
                - ['tag1', 'tag2']: Set or merge tags (based on merge parameter).
            merge: Controls tag update behavior. Semantics:
                - None: Use backend default behavior (replace mode).
                - False: Replace all existing tags (replace mode).
                - True: Merge new tags with existing tags (union).

        Example:
            # Replace tags on multiple versions (default behavior)
            prompts_client.batch_update_prompt_version_tags(
                version_ids=["version-id-1", "version-id-2"],
                tags=["production", "v2"]
            )

            # Merge new tags with existing tags
            prompts_client.batch_update_prompt_version_tags(
                version_ids=["version-id-1"],
                tags=["hotfix"],
                merge=True
            )

            # Clear all tags
            prompts_client.batch_update_prompt_version_tags(
                version_ids=["version-id-1"],
                tags=[]
            )
        """
        update = PromptVersionUpdate(tags=tags)
        self._rest_client.prompts.update_prompt_versions(
            ids=version_ids, update=update, merge_tags=merge
        )
