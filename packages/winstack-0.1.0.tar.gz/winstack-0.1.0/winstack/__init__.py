"""WinStack — Windows-native process orchestrator. No Docker. No WSL."""
__version__ = "0.1.0"
