from __future__ import annotations
from datetime import datetime

from rich import box
from rich.console import Console
from rich.table import Table

from ..core.process_mgr import get_cpu_memory, is_running
from ..core.state import get_service_state

console = Console()

_STATUS_COLORS = {
    "running":    "bold green",
    "starting":   "yellow",
    "stopped":    "dim",
    "error":      "bold red",
    "unhealthy":  "red",
    "unknown":    "dim red",
    "restarting": "bold yellow",
    "failed":     "bold red",
}


def _badge(status: str) -> str:
    color = _STATUS_COLORS.get(status, "white")
    return f"[{color}]{status.upper()}[/{color}]"


def build_status_table(service_names: list[str]) -> Table:
    table = Table(
        title="[bold white]WinStack — Service Status[/]",
        box=box.ROUNDED,
        header_style="bold cyan",
        show_lines=True,
    )
    table.add_column("Service",  style="bold white", min_width=16)
    table.add_column("Status",   min_width=12)
    table.add_column("PID",      justify="right", min_width=8)
    table.add_column("CPU %",    justify="right", min_width=7)
    table.add_column("Mem MB",   justify="right", min_width=8)
    table.add_column("Restarts", justify="right", min_width=9)
    table.add_column("Started",  min_width=10)

    for name in service_names:
        state = get_service_state(name)
        running = is_running(name)

        status = "running" if running else state.get("status", "stopped")
        if status == "running" and not running:
            status = "stopped"

        pid_val  = str(state.get("pid", "")) if running else "—"
        restarts = state.get("restart_count", 0)
        started  = state.get("started_at", "—")
        if started and started != "—":
            try:
                started = datetime.fromisoformat(started).strftime("%H:%M:%S")
            except Exception:
                pass

        cpu, mem = get_cpu_memory(name) if running else (0.0, 0.0)

        table.add_row(
            name,
            _badge(status),
            pid_val,
            f"{cpu:.1f}" if running else "—",
            f"{mem:.1f}" if running else "—",
            str(restarts),
            started,
        )

    return table


def print_status(service_names: list[str]):
    console.print(build_status_table(service_names))
