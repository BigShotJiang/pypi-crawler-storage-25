from __future__ import annotations
import time
from datetime import datetime

from rich.text import Text
from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, DataTable, RichLog, Label
from textual.containers import Vertical
from textual.binding import Binding
from textual import on

from ..core.state import get_service_state, log_path
from ..core.process_mgr import get_cpu_memory, is_running


# ── Status display ────────────────────────────────────────────────────────────

_STATUS: dict[str, tuple[str, str]] = {
    "running":    ("bold green",  "● RUNNING"),
    "starting":   ("yellow",      "◐ STARTING"),
    "restarting": ("bold yellow", "↻ RESTARTING"),
    "stopped":    ("dim white",   "○ STOPPED"),
    "failed":     ("bold red",    "✗ FAILED"),
    "error":      ("bold red",    "✗ ERROR"),
    "unhealthy":  ("red",         "⚠ UNHEALTHY"),
    "unknown":    ("dim red",     "? UNKNOWN"),
}

_TAIL_LINES = 300


# ── Rich text helpers ─────────────────────────────────────────────────────────

def _cpu_text(cpu: float, running: bool) -> Text:
    if not running:
        return Text("—", style="dim")
    style = "bold red" if cpu >= 75 else "yellow" if cpu >= 40 else "green"
    filled = round(cpu / 100 * 5)
    bar = "█" * filled + "░" * (5 - filled)
    return Text(f"{bar} {cpu:4.1f}%", style=style)


def _mem_text(mem: float, running: bool) -> Text:
    if not running:
        return Text("—", style="dim")
    style = "bold red" if mem > 500 else "yellow" if mem > 200 else "green"
    return Text(f"{mem:.1f} MB", style=style)


def _uptime_text(started_at: str, running: bool) -> Text:
    if not running or not started_at or started_at == "—":
        return Text("—", style="dim")
    try:
        secs = int((datetime.now() - datetime.fromisoformat(started_at)).total_seconds())
        if secs < 60:
            label = f"{secs}s"
        elif secs < 3600:
            label = f"{secs // 60}m {secs % 60:02d}s"
        else:
            label = f"{secs // 3600}h {(secs % 3600) // 60:02d}m"
        return Text(label, style="dim white")
    except Exception:
        return Text("—", style="dim")


def _colorize(line: str) -> Text:
    t = Text(line)
    lo = line.lower()
    if any(k in lo for k in ("error", "exception", "traceback", "critical", "fatal")):
        t.stylize("bold red")
    elif any(k in lo for k in ("warning", "warn")):
        t.stylize("yellow")
    elif "debug" in lo:
        t.stylize("dim cyan")
    return t


# ── App ───────────────────────────────────────────────────────────────────────

class _WinStackApp(App):
    TITLE = "WinStack"
    SUB_TITLE = "Process Orchestrator"

    CSS = """
    #top {
        height: 40%;
        min-height: 7;
        max-height: 20;
        border-bottom: solid $accent-darken-2;
    }
    #svc-table {
        height: 1fr;
    }
    #log-title {
        height: 1;
        background: $panel-lighten-2;
        color: $text-muted;
        padding: 0 1;
        text-style: bold;
    }
    #log-view {
        height: 1fr;
        scrollbar-size: 1 1;
    }
    """

    BINDINGS = [
        Binding("q", "quit",        "Quit",       priority=True),
        Binding("r", "restart_svc", "Restart"),
        Binding("s", "toggle_svc",  "Start/Stop"),
        Binding("c", "clear_logs",  "Clear Logs"),
        Binding("g", "scroll_top",  "Log Top",    show=False),
        Binding("G", "scroll_end",  "Log Bottom", show=False),
    ]

    def __init__(self, service_names: list[str], config, **kwargs):
        super().__init__(**kwargs)
        self._names = service_names
        self._config = config
        self._selected: str = service_names[0] if service_names else ""
        self._log_pos: int = 0

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Vertical(id="top"):
            yield DataTable(id="svc-table", cursor_type="row", zebra_stripes=True)
        yield Label("", id="log-title")
        yield RichLog(id="log-view", highlight=True, wrap=False, markup=False)
        yield Footer()

    def on_mount(self) -> None:
        t = self.query_one("#svc-table", DataTable)
        t.add_column("Service", key="svc",    width=18)
        t.add_column("Status",  key="status", width=14)
        t.add_column("PID",     key="pid",    width=8)
        t.add_column("CPU",     key="cpu",    width=16)
        t.add_column("Memory",  key="mem",    width=12)
        t.add_column("Uptime",  key="uptime", width=12)
        t.add_column("↺",       key="rst",    width=4)

        for name in self._names:
            t.add_row(*self._build_row(name), key=name)

        self._switch_to(self._selected)
        self.set_interval(2.0,  self._refresh_table)
        self.set_interval(0.25, self._poll_logs)

    def _build_row(self, name: str) -> tuple:
        state   = get_service_state(name)
        running = is_running(name)
        skey    = "running" if running else state.get("status", "stopped")
        color, label = _STATUS.get(skey, ("white", skey.upper()))
        cpu, mem = get_cpu_memory(name) if running else (0.0, 0.0)
        pid_str  = str(state.get("pid", "")) if running else "—"
        return (
            name,
            Text(label, style=color),
            Text(pid_str, style="white" if running else "dim"),
            _cpu_text(cpu, running),
            _mem_text(mem, running),
            _uptime_text(state.get("started_at", "—"), running),
            str(state.get("restart_count", 0)),
        )

    def _refresh_table(self) -> None:
        t = self.query_one("#svc-table", DataTable)
        for name in self._names:
            r = self._build_row(name)
            t.update_cell(name, "svc",    r[0])
            t.update_cell(name, "status", r[1])
            t.update_cell(name, "pid",    r[2])
            t.update_cell(name, "cpu",    r[3])
            t.update_cell(name, "mem",    r[4])
            t.update_cell(name, "uptime", r[5])
            t.update_cell(name, "rst",    r[6])

    def _switch_to(self, name: str) -> None:
        self._selected = name
        self.query_one("#log-title", Label).update(f"  LOGS  ──  {name}")
        log_view = self.query_one("#log-view", RichLog)
        log_view.clear()
        path = log_path(name)
        if path.exists():
            with open(path, encoding="utf-8", errors="replace") as f:
                for line in f.readlines()[-_TAIL_LINES:]:
                    log_view.write(_colorize(line.rstrip()))
                self._log_pos = f.tell()
        else:
            log_view.write(Text(f"No log file yet for '{name}'. Start it first.", style="dim"))
            self._log_pos = 0

    def _poll_logs(self) -> None:
        path = log_path(self._selected)
        if not path.exists():
            return
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                f.seek(self._log_pos)
                new_lines = f.readlines()
                if new_lines:
                    log_view = self.query_one("#log-view", RichLog)
                    for line in new_lines:
                        log_view.write(_colorize(line.rstrip()))
                self._log_pos = f.tell()
        except OSError:
            pass

    @on(DataTable.RowHighlighted, "#svc-table")
    def _on_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        key = event.row_key
        if key and key.value:
            name = str(key.value)
            if name != self._selected:
                self._switch_to(name)

    def action_restart_svc(self) -> None:
        from ..core.process_mgr import stop_service, start_service
        svc = self._config.services.get(self._selected)
        if not svc:
            return
        stop_service(self._selected)
        time.sleep(0.5)
        start_service(svc, self._config.env)

    def action_toggle_svc(self) -> None:
        from ..core.process_mgr import stop_service, start_service
        name = self._selected
        svc  = self._config.services.get(name)
        if not svc:
            return
        if is_running(name):
            stop_service(name)
        else:
            start_service(svc, self._config.env)

    def action_clear_logs(self) -> None:
        self.query_one("#log-view", RichLog).clear()
        self._log_pos = 0

    def action_scroll_top(self) -> None:
        self.query_one("#log-view", RichLog).scroll_home()

    def action_scroll_end(self) -> None:
        self.query_one("#log-view", RichLog).scroll_end()


# ── Public API ────────────────────────────────────────────────────────────────

def live_dashboard(service_names: list[str], config, refresh_interval: float = 2.0):
    """Launch the interactive split-pane TUI. Press q to exit."""
    _WinStackApp(service_names, config).run()


def tail_logs(service_name: str, lines: int = 50):
    """Print last N lines of a service log then follow in real time (CLI mode)."""
    from rich.console import Console
    console = Console()

    path = log_path(service_name)
    if not path.exists():
        console.print(f"[yellow]No log file yet for '{service_name}'. Has it been started?[/]")
        return

    console.print(f"[bold cyan]── Logs: {service_name} ──[/] [dim](Ctrl+C to stop)[/]\n")
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            for line in f.readlines()[-lines:]:
                console.print(line, end="")
            while True:
                line = f.readline()
                if line:
                    console.print(line, end="")
                else:
                    time.sleep(0.2)
    except KeyboardInterrupt:
        console.print("\n[dim]Log tail stopped.[/]")
