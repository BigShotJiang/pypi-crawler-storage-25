from __future__ import annotations
import os
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

import psutil

from .config import ServiceConfig, WinStackConfig
from .state import update_service_state, get_service_state, log_path, load_state, save_state

# Active watchdog threads keyed by service name
_watchdogs: dict[str, threading.Thread] = {}


def _build_env(svc: ServiceConfig, global_env: dict) -> dict:
    env = os.environ.copy()
    env.update(global_env)
    env.update(svc.env)

    if svc.env_file:
        env_file_path = Path(svc.dir) / svc.env_file if not Path(svc.env_file).is_absolute() else Path(svc.env_file)
        if env_file_path.exists():
            try:
                from dotenv import dotenv_values
                loaded = {k: v for k, v in dotenv_values(env_file_path).items() if v is not None}
                env.update(loaded)
            except ImportError:
                pass

    return env


def start_service(svc: ServiceConfig, global_env: dict) -> int | None:
    """Start a service process. Returns PID or None on failure."""
    log_file_path = log_path(svc.name)
    env = _build_env(svc, global_env)

    with open(log_file_path, "a", encoding="utf-8") as lf:
        lf.write(f"\n{'='*60}\n")
        lf.write(f"Started at {datetime.now().isoformat()}\n")
        lf.write(f"Command:    {svc.start}\n")
        lf.write(f"Directory:  {svc.dir}\n")
        lf.write(f"{'='*60}\n\n")

    try:
        creation_flags = 0
        if sys.platform == "win32":
            creation_flags = subprocess.CREATE_NEW_PROCESS_GROUP

        with open(log_file_path, "a", encoding="utf-8") as lf:
            proc = subprocess.Popen(
                svc.start,
                shell=True,
                cwd=svc.dir,
                env=env,
                stdout=lf,
                stderr=subprocess.STDOUT,
                creationflags=creation_flags,
            )

        update_service_state(
            svc.name,
            pid=proc.pid,
            status="starting",
            started_at=datetime.now().isoformat(),
            restart_count=get_service_state(svc.name).get("restart_count", 0),
        )

        _start_watchdog(svc, global_env)
        return proc.pid

    except Exception as e:
        update_service_state(svc.name, status="error", error=str(e))
        return None


def _start_watchdog(svc: ServiceConfig, global_env: dict) -> None:
    """Spawn a background thread that restarts the service according to its restart policy."""
    policy = svc.restart.policy
    if policy == "no":
        return

    existing = _watchdogs.get(svc.name)
    if existing and existing.is_alive():
        existing.cancel_requested = True  # type: ignore[attr-defined]

    def _watch():
        thread = threading.current_thread()
        attempt = 0
        max_retries = svc.restart.max_retries

        while not getattr(thread, "cancel_requested", False):
            time.sleep(2)

            if getattr(thread, "cancel_requested", False):
                break

            if not is_running(svc.name):
                saved_status = get_service_state(svc.name).get("status", "stopped")
                if saved_status == "stopped":
                    break
                if policy == "on_failure" and saved_status not in ("running", "starting"):
                    break
                if max_retries > 0 and attempt >= max_retries:
                    update_service_state(svc.name, status="failed")
                    break

                attempt += 1
                update_service_state(svc.name, status="restarting")
                new_pid = start_service(svc, global_env)
                if new_pid:
                    prev = get_service_state(svc.name).get("restart_count", 0)
                    update_service_state(svc.name, restart_count=prev + 1, status="running")
                else:
                    update_service_state(svc.name, status="failed")
                    break

    t = threading.Thread(target=_watch, name=f"watchdog-{svc.name}", daemon=True)
    t.cancel_requested = False  # type: ignore[attr-defined]
    _watchdogs[svc.name] = t
    t.start()


def stop_service(name: str, timeout: int = 10) -> bool:
    """Stop a service by name. Returns True if successfully stopped."""
    watchdog = _watchdogs.pop(name, None)
    if watchdog and watchdog.is_alive():
        watchdog.cancel_requested = True  # type: ignore[attr-defined]

    state = get_service_state(name)
    pid = state.get("pid")

    if not pid:
        update_service_state(name, status="stopped", pid=None)
        return True

    try:
        parent = psutil.Process(pid)
        children = parent.children(recursive=True)
        all_procs = [parent] + children

        for proc in all_procs:
            try:
                proc.terminate()
            except psutil.NoSuchProcess:
                pass

        gone, alive = psutil.wait_procs(all_procs, timeout=timeout)

        for proc in alive:
            try:
                proc.kill()
            except psutil.NoSuchProcess:
                pass

        update_service_state(name, status="stopped", pid=None)
        return True

    except psutil.NoSuchProcess:
        update_service_state(name, status="stopped", pid=None)
        return True
    except Exception:
        update_service_state(name, status="unknown", pid=None)
        return False


def is_running(name: str) -> bool:
    pid = get_service_state(name).get("pid")
    if not pid:
        return False
    try:
        proc = psutil.Process(pid)
        return proc.is_running() and proc.status() != psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        return False


def get_cpu_memory(name: str) -> tuple[float, float]:
    """Returns (cpu_percent, memory_mb) for the service."""
    pid = get_service_state(name).get("pid")
    if not pid:
        return 0.0, 0.0
    try:
        proc = psutil.Process(pid)
        cpu = proc.cpu_percent(interval=0.1)
        mem = proc.memory_info().rss / (1024 * 1024)
        return cpu, mem
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return 0.0, 0.0


def reconcile_state(config: WinStackConfig):
    """Cross-check saved PIDs against live processes and correct the state."""
    state = load_state()
    for name, svc_state in state.get("services", {}).items():
        pid = svc_state.get("pid")
        if pid:
            try:
                proc = psutil.Process(pid)
                if proc.is_running() and proc.status() != psutil.STATUS_ZOMBIE:
                    svc_state["status"] = "running"
                else:
                    svc_state["status"] = "stopped"
                    svc_state["pid"] = None
            except psutil.NoSuchProcess:
                svc_state["status"] = "stopped"
                svc_state["pid"] = None
    save_state(state)
