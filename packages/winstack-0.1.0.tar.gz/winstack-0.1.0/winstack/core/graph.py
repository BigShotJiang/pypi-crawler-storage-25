from __future__ import annotations


def topological_sort(services: dict) -> list[str]:
    """Returns service names in start order (dependencies first)."""
    in_degree = {name: 0 for name in services}
    graph = {name: [] for name in services}

    for name, svc in services.items():
        for dep in svc.depends_on:
            if dep in graph:
                graph[dep].append(name)
                in_degree[name] += 1

    queue = [n for n, d in in_degree.items() if d == 0]
    result = []

    while queue:
        node = queue.pop(0)
        result.append(node)
        for neighbor in graph[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    if len(result) != len(services):
        raise ValueError("Circular dependency detected in services config")

    return result


def shutdown_order(services: dict) -> list[str]:
    """Returns service names in stop order (dependents first)."""
    return list(reversed(topological_sort(services)))
