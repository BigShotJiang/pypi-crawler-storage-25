from __future__ import annotations
import socket
import time
from typing import Callable

import httpx

from .config import HealthConfig


def check_http(config: HealthConfig) -> bool:
    try:
        with httpx.Client(timeout=config.timeout) as client:
            resp = client.get(config.url)
            return resp.status_code < 500
    except Exception:
        return False


def check_tcp(config: HealthConfig) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(config.timeout)
            return s.connect_ex((config.host, config.port)) == 0
    except Exception:
        return False


def wait_for_healthy(
    config: HealthConfig,
    on_attempt: Callable[[int, int], None] | None = None,
) -> bool:
    if config.type == "none":
        return True

    check = check_http if config.type == "http" else check_tcp

    for attempt in range(1, config.retries + 1):
        if on_attempt:
            on_attempt(attempt, config.retries)
        if check(config):
            return True
        time.sleep(config.interval)

    return False


def is_healthy(config: HealthConfig) -> bool:
    if config.type == "none":
        return True
    check = check_http if config.type == "http" else check_tcp
    return check(config)
