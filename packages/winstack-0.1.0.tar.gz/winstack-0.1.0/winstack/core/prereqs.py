from __future__ import annotations
import os
import socket
import subprocess
from pathlib import Path
from typing import NamedTuple

from .config import PrerequisiteConfig


class CheckResult(NamedTuple):
    name: str
    passed: bool
    message: str
    fix: str = ""


def check_command(req: PrerequisiteConfig) -> CheckResult:
    try:
        result = subprocess.run(
            [req.name, req.version_flag],
            capture_output=True, text=True, timeout=10,
        )
        output = (result.stdout + result.stderr).strip()
        if req.expected_contains and req.expected_contains not in output:
            return CheckResult(
                name=req.name,
                passed=False,
                message=f"Found but output doesn't contain '{req.expected_contains}'. Got: {output[:100]}",
                fix=req.fix,
            )
        return CheckResult(name=req.name, passed=True, message=output[:80] or "OK")
    except FileNotFoundError:
        return CheckResult(
            name=req.name, passed=False,
            message=f"'{req.name}' not found in PATH",
            fix=req.fix,
        )
    except Exception as e:
        return CheckResult(name=req.name, passed=False, message=str(e), fix=req.fix)


def check_port_free(req: PrerequisiteConfig) -> CheckResult:
    port = req.port
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            if s.connect_ex(("localhost", port)) == 0:
                return CheckResult(
                    name=f"port:{port}",
                    passed=False,
                    message=f"Port {port} is already in use",
                    fix=req.fix or f"Free up port {port} before starting",
                )
        return CheckResult(name=f"port:{port}", passed=True, message=f"Port {port} is free")
    except Exception as e:
        return CheckResult(name=f"port:{port}", passed=True, message=f"Port {port} appears free ({e})")


def check_env_var(req: PrerequisiteConfig) -> CheckResult:
    val = os.environ.get(req.name)
    if val is None:
        return CheckResult(
            name=f"env:{req.name}",
            passed=False,
            message=f"Environment variable '{req.name}' is not set",
            fix=req.fix or f"Set {req.name} before running winstack",
        )
    masked = ("*" * min(len(val), 8)) + "..."
    return CheckResult(name=f"env:{req.name}", passed=True, message=f"Set ({masked})")


def check_folder(req: PrerequisiteConfig) -> CheckResult:
    p = Path(req.path)
    if not p.exists():
        return CheckResult(
            name=f"folder:{req.path}",
            passed=False,
            message=f"Required folder '{req.path}' does not exist",
            fix=req.fix or f"Create the folder: mkdir {req.path}",
        )
    return CheckResult(name=f"folder:{req.path}", passed=True, message="Exists")


def run_checks(prerequisites: list[PrerequisiteConfig]) -> list[CheckResult]:
    dispatch = {
        "command":   check_command,
        "port_free": check_port_free,
        "env_var":   check_env_var,
        "folder":    check_folder,
    }
    results = []
    for req in prerequisites:
        fn = dispatch.get(req.type)
        if fn:
            results.append(fn(req))
        else:
            results.append(CheckResult(name=req.type, passed=False, message=f"Unknown check type: {req.type}"))
    return results
