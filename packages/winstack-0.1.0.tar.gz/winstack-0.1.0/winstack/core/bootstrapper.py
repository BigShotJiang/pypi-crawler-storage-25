from __future__ import annotations
import os
import subprocess
from pathlib import Path

from rich.console import Console

from .config import ServiceConfig, WinStackConfig

console = Console()


def clone_or_pull(svc: ServiceConfig) -> bool:
    """Clone repo if not present, pull if it already exists. Returns True on success."""
    if not svc.repo:
        return True

    svc_dir = Path(svc.dir)

    if svc_dir.exists() and (svc_dir / ".git").exists():
        console.print(f"  [cyan]Pulling[/] latest for {svc.name}...")
        try:
            import git
            repo = git.Repo(svc_dir)
            repo.remotes.origin.pull()
            console.print("  [green]Pull complete[/]")
            return True
        except ImportError:
            console.print("  [yellow]gitpython not installed — skipping pull[/]")
            return True
        except Exception as e:
            console.print(f"  [yellow]git pull warning for {svc.name}: {e}[/]")
            return True  # not fatal — dir exists

    console.print(f"  [cyan]Cloning[/] {svc.repo} → {svc_dir}")
    try:
        import git
        git.Repo.clone_from(svc.repo, svc_dir)
        console.print("  [green]Clone complete[/]")
        return True
    except ImportError:
        console.print("  [red]gitpython not installed. Run: pip install gitpython[/]")
        return False
    except Exception as e:
        console.print(f"  [red]Clone failed for {svc.name}: {e}[/]")
        return False


def run_install(svc: ServiceConfig, global_env: dict) -> bool:
    """Run install command. Returns True on success."""
    if not svc.install:
        return True

    console.print(f"  [cyan]Installing[/] → {svc.install}")

    env = os.environ.copy()
    env.update(global_env)
    env.update(svc.env)

    try:
        result = subprocess.run(
            svc.install,
            shell=True,
            cwd=svc.dir,
            env=env,
        )
        if result.returncode != 0:
            console.print(f"  [red]Install failed (exit {result.returncode})[/]")
            return False
        console.print("  [green]Install complete[/]")
        return True
    except Exception as e:
        console.print(f"  [red]Install error: {e}[/]")
        return False


def bootstrap_service(svc: ServiceConfig, config: WinStackConfig) -> bool:
    ok = clone_or_pull(svc)
    if not ok:
        return False
    return run_install(svc, config.env)
