from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
import yaml


@dataclass
class HealthConfig:
    type: str = "none"       # http | tcp | none
    url: str = ""
    host: str = "localhost"
    port: int = 0
    interval: int = 5        # seconds between retries
    retries: int = 12
    timeout: int = 5


@dataclass
class RestartConfig:
    policy: str = "no"       # no | on_failure | always
    max_retries: int = 3


@dataclass
class DependsOnConfig:
    condition: str = "process_started"   # process_started | process_healthy


@dataclass
class ServiceConfig:
    name: str = ""
    dir: str = ""
    repo: str = ""
    install: str = ""
    start: str = ""
    health: HealthConfig = field(default_factory=HealthConfig)
    depends_on: dict = field(default_factory=dict)   # {name: DependsOnConfig}
    env: dict = field(default_factory=dict)
    env_file: str = ""
    restart: RestartConfig = field(default_factory=RestartConfig)
    replicas: int = 1
    enabled: bool = True


@dataclass
class PrerequisiteConfig:
    type: str = "command"    # command | port_free | env_var | folder
    name: str = ""
    version_flag: str = "--version"
    expected_contains: str = ""
    fix: str = ""
    port: int = 0
    path: str = ""


@dataclass
class WinStackConfig:
    version: str = "1"
    env: dict = field(default_factory=dict)
    prerequisites: list = field(default_factory=list)
    groups: dict = field(default_factory=dict)
    services: dict = field(default_factory=dict)
    config_dir: Path = field(default_factory=Path)


# ── parsers ───────────────────────────────────────────────────────────────────

def _parse_health(data: dict | None) -> HealthConfig:
    if not data:
        return HealthConfig()
    return HealthConfig(
        type=data.get("type", "none"),
        url=data.get("url", ""),
        host=data.get("host", "localhost"),
        port=int(data.get("port", 0)),
        interval=int(data.get("interval", 5)),
        retries=int(data.get("retries", 12)),
        timeout=int(data.get("timeout", 5)),
    )


def _parse_restart(data: dict | None) -> RestartConfig:
    if not data:
        return RestartConfig()
    return RestartConfig(
        policy=data.get("policy", "no"),
        max_retries=int(data.get("max_retries", 3)),
    )


def _parse_depends_on(data: dict | None) -> dict:
    if not data:
        return {}
    result = {}
    for svc, cfg in data.items():
        if isinstance(cfg, dict):
            result[svc] = DependsOnConfig(condition=cfg.get("condition", "process_started"))
        else:
            result[svc] = DependsOnConfig()
    return result


def _parse_prereqs(data: list | None) -> list:
    if not data:
        return []
    return [
        PrerequisiteConfig(
            type=item.get("type", "command"),
            name=item.get("name", ""),
            version_flag=item.get("version_flag", "--version"),
            expected_contains=item.get("expected_contains", ""),
            fix=item.get("fix", ""),
            port=int(item.get("port", 0)),
            path=item.get("path", ""),
        )
        for item in data
    ]


def _parse_services(data: dict, config_dir: Path) -> dict:
    services = {}
    for name, cfg in data.items():
        raw_dir = cfg.get("dir", ".")
        svc_dir = (config_dir / raw_dir).resolve()
        services[name] = ServiceConfig(
            name=name,
            dir=str(svc_dir),
            repo=cfg.get("repo", ""),
            install=cfg.get("install", ""),
            start=cfg.get("start", ""),
            health=_parse_health(cfg.get("health")),
            depends_on=_parse_depends_on(cfg.get("depends_on")),
            env={str(k): str(v) for k, v in cfg.get("env", {}).items()},
            env_file=cfg.get("env_file", ""),
            restart=_parse_restart(cfg.get("restart")),
            replicas=int(cfg.get("replicas", 1)),
            enabled=bool(cfg.get("enabled", True)),
        )
    return services


def load_config(path: str = "winstack.yaml") -> WinStackConfig:
    config_path = Path(path).resolve()
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(config_path) as f:
        data = yaml.safe_load(f) or {}

    config_dir = config_path.parent
    return WinStackConfig(
        version=str(data.get("version", "1")),
        env={str(k): str(v) for k, v in data.get("env", {}).items()},
        prerequisites=_parse_prereqs(data.get("prerequisites")),
        groups=data.get("groups", {}),
        services=_parse_services(data.get("services", {}), config_dir),
        config_dir=config_dir,
    )
