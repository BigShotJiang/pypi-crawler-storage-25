from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path
from typing import Any

STATE_DIR = Path(".winstack")
STATE_FILE = STATE_DIR / "state.json"


def _ensure_dirs():
    STATE_DIR.mkdir(exist_ok=True)
    (STATE_DIR / "logs").mkdir(exist_ok=True)


def load_state() -> dict[str, Any]:
    _ensure_dirs()
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"services": {}}


def save_state(state: dict[str, Any]):
    _ensure_dirs()
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2, default=str)


def update_service_state(name: str, **kwargs):
    state = load_state()
    svc = state["services"].setdefault(name, {})
    svc.update(kwargs)
    svc["updated_at"] = datetime.now().isoformat()
    save_state(state)


def get_service_state(name: str) -> dict[str, Any]:
    return load_state()["services"].get(name, {})


def clear_service_state(name: str):
    state = load_state()
    state["services"].pop(name, None)
    save_state(state)


def log_path(service_name: str) -> Path:
    _ensure_dirs()
    return STATE_DIR / "logs" / f"{service_name}.log"
