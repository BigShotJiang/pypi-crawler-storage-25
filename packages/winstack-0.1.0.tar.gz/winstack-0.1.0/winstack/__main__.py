#!/usr/bin/env python3
"""
WinStack — Windows-native process orchestrator.
No Docker. No WSL. No containers. Just YAML + Python.
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt

app = typer.Typer(
    name="winstack",
    help="Windows-native process orchestrator — no Docker, no WSL required.",
    rich_markup_mode="rich",
    no_args_is_help=True,
)
console = Console()

DEFAULT_CONFIG = "winstack.yaml"


# ── helpers ───────────────────────────────────────────────────────────────────

def _load_config(path: str):
    from .core.config import load_config
    try:
        return load_config(path)
    except FileNotFoundError:
        console.print(f"[red]Config not found:[/] {path}")
        console.print("Run [bold cyan]winstack init[/] to create one.")
        raise typer.Exit(1)


def _filter_services(cfg, group: str | None) -> dict:
    services = {k: v for k, v in cfg.services.items() if v.enabled}
    if group:
        if group not in cfg.groups:
            console.print(f"[red]Group '{group}' not found.[/] Available: {list(cfg.groups.keys())}")
            raise typer.Exit(1)
        names = cfg.groups[group]
        services = {k: v for k, v in services.items() if k in names}
    return services


def _run_prereqs(cfg) -> bool:
    from .core.prereqs import run_checks
    if not cfg.prerequisites:
        return True
    results = run_checks(cfg.prerequisites)
    for r in results:
        icon = "[green]✓[/]" if r.passed else "[red]✗[/]"
        console.print(f"  {icon}  {r.name} — {r.message}")
        if not r.passed and r.fix:
            console.print(f"      [dim]Fix: {r.fix}[/]")
    failed = [r for r in results if not r.passed]
    return len(failed) == 0


def _start_services(cfg, services: dict, skip_install: bool):
    from .core.graph import topological_sort
    from .core.bootstrapper import bootstrap_service
    from .core.process_mgr import start_service
    from .core.health import wait_for_healthy
    from .core.state import update_service_state

    order = topological_sort(services)
    console.print(f"\n[bold cyan]Starting {len(order)} service(s)...[/]\n")

    for name in order:
        svc = services[name]
        console.rule(f"[bold white]{name}[/]", style="dim")

        if not skip_install:
            ok = bootstrap_service(svc, cfg)
            if not ok:
                console.print(f"[red]Bootstrap failed for '{name}'. Aborting.[/]")
                raise typer.Exit(1)

        console.print(f"  [cyan]Starting[/]  {svc.start}")
        pid = start_service(svc, cfg.env)
        if pid is None:
            console.print(f"  [red]Failed to start '{name}'.[/]")
            raise typer.Exit(1)
        console.print(f"  [green]Started[/]   PID {pid}")

        if svc.health.type != "none":
            target = svc.health.url or f"{svc.health.host}:{svc.health.port}"
            console.print(f"  [dim]Waiting for health check ({svc.health.type}: {target})...[/]")

            attempt_display = [0]
            def on_attempt(attempt, total):
                attempt_display[0] = attempt
                console.print(f"  [dim]  attempt {attempt}/{total}...[/]", end="\r")

            healthy = wait_for_healthy(svc.health, on_attempt=on_attempt)
            if healthy:
                update_service_state(name, status="running")
                console.print(f"  [green]✓ Healthy[/]                              ")
            else:
                update_service_state(name, status="unhealthy")
                console.print(f"  [yellow]⚠ Health check timed out — still may start up[/]")
        else:
            update_service_state(name, status="running")

        console.print()


# ── commands ──────────────────────────────────────────────────────────────────

@app.command()
def check(
    config: str = typer.Option(DEFAULT_CONFIG, "--config", "-c", help="Path to winstack.yaml"),
):
    """Run prerequisite checks without starting anything."""
    cfg = _load_config(config)
    if not cfg.prerequisites:
        console.print("[dim]No prerequisites defined in config.[/]")
        return
    console.print("\n[bold cyan]Prerequisite Checks[/]\n")
    passed = _run_prereqs(cfg)
    if passed:
        console.print("\n[green]All checks passed.[/]")
    else:
        console.print("\n[red]Some checks failed — fix above issues first.[/]")
        raise typer.Exit(1)


@app.command()
def bootstrap(
    config: str = typer.Option(DEFAULT_CONFIG, "--config", "-c"),
    group: Optional[str] = typer.Option(None, "--group", "-g", help="Only start this group"),
    skip_install: bool = typer.Option(False, "--skip-install", help="Skip install commands"),
    skip_checks: bool = typer.Option(False, "--skip-checks", help="Skip prerequisite checks"),
):
    """Clone repos, install dependencies, and start all services."""
    from .core.process_mgr import reconcile_state

    cfg = _load_config(config)
    reconcile_state(cfg)

    if not skip_checks and cfg.prerequisites:
        console.print("\n[bold cyan]Prerequisite Checks[/]")
        if not _run_prereqs(cfg):
            console.print("\n[red]Fix prerequisite failures before proceeding.[/]")
            console.print("[dim]Use --skip-checks to bypass.[/]")
            raise typer.Exit(1)
        console.print()

    services = _filter_services(cfg, group)
    _start_services(cfg, services, skip_install=skip_install)

    console.print("[bold green]Bootstrap complete![/]")
    console.print("  [dim]winstack status[/]       — view all services")
    console.print("  [dim]winstack ui[/]            — live dashboard")
    console.print("  [dim]winstack logs <name>[/]   — tail service logs")


@app.command()
def clone(
    config: str = typer.Option(DEFAULT_CONFIG, "--config", "-c"),
    group: Optional[str] = typer.Option(None, "--group", "-g", help="Only clone this group"),
):
    """Clone or pull repos for all services that define a repo URL."""
    from .core.bootstrapper import clone_or_pull

    cfg = _load_config(config)
    services = _filter_services(cfg, group)

    has_repos = {k: v for k, v in services.items() if v.repo}
    if not has_repos:
        console.print("[yellow]No services with a repo: field found in config.[/]")
        raise typer.Exit(0)

    console.print(f"\n[bold cyan]Cloning/pulling {len(has_repos)} repo(s)...[/]\n")
    failed = []
    for name, svc in has_repos.items():
        console.rule(f"[bold white]{name}[/]", style="dim")
        ok = clone_or_pull(svc)
        if not ok:
            failed.append(name)
        console.print()

    if failed:
        console.print(f"[red]Failed:[/] {', '.join(failed)}")
        raise typer.Exit(1)
    console.print("[bold green]All repos ready.[/]")


@app.command()
def up(
    config: str = typer.Option(DEFAULT_CONFIG, "--config", "-c"),
    group: Optional[str] = typer.Option(None, "--group", "-g"),
):
    """Start services (skips clone & install)."""
    from .core.process_mgr import reconcile_state

    cfg = _load_config(config)
    reconcile_state(cfg)

    if cfg.prerequisites:
        console.print("\n[bold cyan]Prerequisite Checks[/]")
        if not _run_prereqs(cfg):
            console.print("\n[red]Fix issues or use --skip-checks flag.[/]")
            raise typer.Exit(1)
        console.print()

    services = _filter_services(cfg, group)
    _start_services(cfg, services, skip_install=True)

    console.print("[bold green]All services started.[/]")


@app.command()
def down(
    config: str = typer.Option(DEFAULT_CONFIG, "--config", "-c"),
    group: Optional[str] = typer.Option(None, "--group", "-g"),
):
    """Stop all running services (dependency-aware order)."""
    from .core.graph import shutdown_order
    from .core.process_mgr import stop_service, reconcile_state

    cfg = _load_config(config)
    reconcile_state(cfg)

    services = _filter_services(cfg, group)
    order = shutdown_order(services)

    console.print(f"\n[bold cyan]Stopping {len(order)} service(s)...[/]\n")
    for name in order:
        console.print(f"  [dim]Stopping[/] {name}...", end=" ")
        ok = stop_service(name)
        console.print("[green]stopped[/]" if ok else "[red]failed[/]")

    console.print("\n[green]Done.[/]")


@app.command()
def restart(
    service: str = typer.Argument(..., help="Service name to restart"),
    config: str = typer.Option(DEFAULT_CONFIG, "--config", "-c"),
):
    """Restart a single service."""
    from .core.process_mgr import stop_service, start_service
    from .core.state import update_service_state, get_service_state

    cfg = _load_config(config)
    if service not in cfg.services:
        console.print(f"[red]Service '{service}' not found in config.[/]")
        raise typer.Exit(1)

    svc = cfg.services[service]

    console.print(f"\n[cyan]Stopping {service}...[/]")
    stop_service(service)
    time.sleep(1)

    console.print(f"[cyan]Starting {service}...[/]")
    prev_restarts = get_service_state(service).get("restart_count", 0)
    pid = start_service(svc, cfg.env)
    if pid:
        update_service_state(service, restart_count=prev_restarts + 1, status="running")
        console.print(f"[green]Restarted '{service}'[/] (PID {pid})")
    else:
        console.print(f"[red]Failed to restart '{service}'.[/]")
        raise typer.Exit(1)


@app.command()
def status(
    config: str = typer.Option(DEFAULT_CONFIG, "--config", "-c"),
):
    """Show status of all services."""
    from .core.process_mgr import reconcile_state
    from .ui.table import print_status

    cfg = _load_config(config)
    reconcile_state(cfg)
    console.print()
    print_status(list(cfg.services.keys()))


@app.command()
def logs(
    service: str = typer.Argument(..., help="Service name"),
    lines: int = typer.Option(50, "--lines", "-n", help="Lines to show before following"),
    config: str = typer.Option(DEFAULT_CONFIG, "--config", "-c"),
):
    """Tail logs for a service (follows in real-time)."""
    from .ui.tui import tail_logs

    cfg = _load_config(config)
    if service not in cfg.services:
        console.print(f"[red]Service '{service}' not found.[/]")
        raise typer.Exit(1)
    tail_logs(service, lines=lines)


@app.command()
def ui(
    config: str = typer.Option(DEFAULT_CONFIG, "--config", "-c"),
    interval: float = typer.Option(2.0, "--interval", help="Refresh interval in seconds"),
):
    """Launch interactive split-pane live dashboard."""
    from .core.process_mgr import reconcile_state
    from .ui.tui import live_dashboard

    cfg = _load_config(config)
    reconcile_state(cfg)
    live_dashboard(list(cfg.services.keys()), cfg, refresh_interval=interval)


@app.command()
def init(
    config: str = typer.Option(DEFAULT_CONFIG, "--config", "-c"),
):
    """Interactive wizard to generate a winstack.yaml."""
    import yaml

    console.print(Panel("[bold cyan]WinStack Init[/] — Config Wizard", expand=False))

    if Path(config).exists():
        if not Confirm.ask(f"[yellow]{config} already exists. Overwrite?[/]"):
            raise typer.Exit(0)

    services = {}
    console.print("\nAdd services one by one. Leave name blank when done.\n")

    while True:
        name = Prompt.ask("  Service name (blank to finish)", default="")
        if not name:
            break

        svc_dir  = Prompt.ask("  Directory (relative to this file)", default=f"./{name}")
        repo     = Prompt.ask("  Git repo URL to clone (blank to skip)", default="")
        install  = Prompt.ask("  Install command (blank to skip)", default="")
        start    = Prompt.ask("  Start command")
        health   = Prompt.ask("  Health check URL (blank to skip)", default="")
        env_file = Prompt.ask("  .env file path (blank to skip)", default="")

        entry: dict = {"dir": svc_dir, "start": start}
        if repo:
            entry["repo"] = repo
        if install:
            entry["install"] = install
        if health:
            entry["health"] = {"type": "http", "url": health, "interval": 5, "retries": 20}
        if env_file:
            entry["env_file"] = env_file

        services[name] = entry
        console.print(f"  [green]✓[/] Added '{name}'\n")

    if not services:
        console.print("[yellow]No services added. Nothing written.[/]")
        raise typer.Exit(0)

    config_data = {"version": "1", "env": {}, "prerequisites": [], "services": services}

    with open(config, "w") as f:
        yaml.dump(config_data, f, default_flow_style=False, sort_keys=False)

    console.print(f"\n[green]Created {config}[/]")
    console.print("Edit it to add prerequisites, env vars, and dependencies.")
    console.print("Then run: [bold cyan]winstack bootstrap[/]")


def main():
    app()


if __name__ == "__main__":
    main()
