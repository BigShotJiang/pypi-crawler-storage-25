# Contributing to WinStack

Thanks for wanting to contribute!

## Setup

```bash
git clone https://github.com/sunnymurali/winstack.git
cd winstack
pip install -e ".[dev]"
```

## Project layout

```
winstack/
├── winstack/
│   ├── __init__.py        version
│   ├── __main__.py        CLI commands (typer)
│   ├── core/
│   │   ├── config.py      YAML parsing & dataclasses
│   │   ├── graph.py       dependency sort (topological)
│   │   ├── state.py       .winstack/state.json read/write
│   │   ├── prereqs.py     prerequisite checkers
│   │   ├── health.py      HTTP & TCP health checks
│   │   ├── process_mgr.py start/stop/watchdog
│   │   └── bootstrapper.py clone/pull + install
│   └── ui/
│       ├── table.py       Rich status table (winstack status)
│       └── tui.py         Textual split-pane dashboard (winstack ui)
├── example.winstack.yaml
├── pyproject.toml
└── README.md
```

## Adding a new command

1. Add a new `@app.command()` function in `winstack/__main__.py`
2. Use lazy imports (`from .core.X import ...`) inside the function body
3. Update the command table in `README.md`

## Adding a new prerequisite type

1. Add a `check_<type>` function in `winstack/core/prereqs.py`
2. Register it in the `dispatch` dict in `run_checks()`
3. Add `type` to `PrerequisiteConfig` docs in `core/config.py`

## Adding a new health check type

1. Add a `check_<type>` function in `winstack/core/health.py`
2. Wire it into `wait_for_healthy()` and `is_healthy()`

## Running locally

```bash
cd your-project
winstack bootstrap        # or: python -m winstack bootstrap
```

## Releasing

1. Bump `version` in `winstack/__init__.py` and `pyproject.toml`
2. Create and push a git tag: `git tag v0.x.0 && git push --tags`
3. GitHub Actions will build and publish to PyPI automatically
