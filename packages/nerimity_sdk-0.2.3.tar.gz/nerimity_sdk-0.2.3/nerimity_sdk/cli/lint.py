"""nerimity lint — static checks for common bot code mistakes."""
from __future__ import annotations
import ast
import os
import sys
from pathlib import Path


def _py_files(path: str) -> list[Path]:
    p = Path(path)
    if p.is_file():
        return [p]
    return list(p.rglob("*.py"))


class _Visitor(ast.NodeVisitor):
    def __init__(self, filename: str) -> None:
        self.filename = filename
        self.issues: list[str] = []
        self._commands: list[str] = []
        self._slash: list[str] = []
        self._buttons: list[str] = []
        self._has_error_handler = False
        self._has_slash_error_handler = False
        self._has_button_error_handler = False

    def _warn(self, node: ast.AST, msg: str) -> None:
        line = getattr(node, "lineno", "?")
        self.issues.append(f"  {self.filename}:{line}  {msg}")

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        for dec in node.decorator_list:
            name = ast.unparse(dec)
            if "on_command_error" in name:
                self._has_error_handler = True
            if "on_slash_error" in name:
                self._has_slash_error_handler = True
            if "on_button_error" in name:
                self._has_button_error_handler = True

            # @bot.command(...)
            if ".command(" in name:
                # Check for missing description
                if "description=" not in name:
                    self._warn(node, f"@command '{node.name}' has no description= — won't show in help")
                self._commands.append(node.name)

            # @bot.slash(...)
            if ".slash(" in name:
                if "description=" not in name:
                    self._warn(node, f"@slash '{node.name}' has no description= — won't show in Nerimity UI")
                self._slash.append(node.name)

            # @bot.button(...)
            if ".button(" in name:
                self._buttons.append(node.name)

        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self.visit_FunctionDef(node)  # type: ignore


def lint_files(paths: list[str]) -> list[str]:
    all_issues: list[str] = []
    visitors: list[_Visitor] = []

    for path in paths:
        for f in _py_files(path):
            try:
                tree = ast.parse(f.read_text(), filename=str(f))
            except SyntaxError as e:
                all_issues.append(f"  {f}: SyntaxError: {e}")
                continue
            v = _Visitor(str(f))
            v.visit(tree)
            all_issues.extend(v.issues)
            visitors.append(v)

    # Global checks across all files
    has_any_command = any(v._commands or v._slash for v in visitors)
    has_error_handler = any(v._has_error_handler for v in visitors)
    has_slash_error_handler = any(v._has_slash_error_handler for v in visitors)
    has_button_error_handler = any(v._has_button_error_handler for v in visitors)
    has_buttons = any(v._buttons for v in visitors)
    has_slash = any(v._slash for v in visitors)

    if has_any_command and not has_error_handler:
        all_issues.append("  (global)  No @bot.on_command_error handler found — errors will only be logged")
    if has_slash and not has_slash_error_handler:
        all_issues.append("  (global)  No @bot.on_slash_error handler found")
    if has_buttons and not has_button_error_handler:
        all_issues.append("  (global)  No @bot.on_button_error handler found")

    return all_issues


def run_lint(paths: list[str]) -> None:
    issues = lint_files(paths)
    if not issues:
        print("✅ No issues found.")
        return
    print(f"⚠️  {len(issues)} issue(s) found:\n")
    for issue in issues:
        print(issue)
    sys.exit(1)
