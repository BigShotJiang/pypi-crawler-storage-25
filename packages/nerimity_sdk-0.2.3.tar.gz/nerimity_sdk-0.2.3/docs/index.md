# nerimity-sdk

A Python library for building bots on [Nerimity](https://nerimity.com).

```bash
pip install nerimity-sdk
```

## How it works

You create a `Bot`, attach handlers with decorators, then call `bot.run()`.
The bot connects over a WebSocket, receives events, and dispatches them to your handlers.

```
Nerimity → WebSocket → GatewayClient → EventEmitter → your handlers
```

Everything your handlers need is in the `ctx` object passed to them.

## Quickstart

**Get a token:** [nerimity.com/app/settings/developer/applications](https://nerimity.com/app/settings/developer/applications) → create app → add Bot → copy token.

```bash
nerimity create my-bot
cd my-bot && cp .env.example .env   # paste token
python bot.py
```

Or manually:

```python
import os
from dotenv import load_dotenv
from nerimity_sdk import Bot

load_dotenv()
bot = Bot(token=os.environ["NERIMITY_TOKEN"], prefix="!")

@bot.on("ready")
async def on_ready(me):
    print(f"Logged in as {me.username}#{me.tag}")

@bot.command("ping", description="Replies with Pong!")
async def ping(ctx):
    await ctx.reply("Pong! 🏓")

bot.run()
```

## What's available

| Feature | How to use |
|---|---|
| Event listeners | `@bot.on("message:created")` |
| Prefix commands | `@bot.command("ping")` |
| Slash commands | `@bot.slash("info")` |
| Buttons | `@bot.button("confirm:{action}")` |
| Argument converters | `args=[Int, MemberConverter]` |
| Confirmation prompts | `await ctx.confirm("Sure?")` |
| Multi-step conversations | `await ctx.ask("Your name?")` |
| DMs | `await ctx.author.send(bot.rest, "Hi!")` |
| Paginator | `await Paginator(pages).send(ctx)` |
| Mention helpers | `mention(user_id)` / `ctx.mentions` |
| Persistent storage | `JsonStore` / `SqliteStore` / `RedisStore` |
| Scheduled tasks | `@bot.cron("0 9 * * *")` |
| Event waiting | `await bot.wait_for("member_joined", ...)` |
| Plugins (hot-reload) | `await bot.plugins.load(MyPlugin())` |
| Error handlers | `@bot.on_command_error` |
| Stale cache detection | `user.stale == True` after reconnect |
| Debug mode | `Bot(debug=True)` |
| Auto-reload on save | `Bot(watch=True)` |

See the [Getting Started guide](guide/installation.md) or the [Example Bot](example.md) for a full working example.
