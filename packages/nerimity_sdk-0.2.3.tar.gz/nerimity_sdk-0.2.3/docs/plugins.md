# Plugin Marketplace

Community plugins for nerimity-sdk. To add yours, open a PR to the docs repo.

## Official contrib plugins

Install the contrib package for ready-made plugins:

```bash
pip install nerimity-sdk-contrib
```

Or copy individual plugins from [`contrib/`](https://github.com/JoddabodScripts/Nerimity-SDK/tree/master/contrib) directly into your `plugins/` folder.

### Available plugins

| Plugin | Description | Usage |
|---|---|---|
| `WelcomePlugin` | Greets new members with a configurable message | `await bot.plugins.load(WelcomePlugin(channel_id="...", message="Welcome {mention}!"))` |
| `AutoModPlugin` | Blocks messages matching a word/regex list | `await bot.plugins.load(AutoModPlugin(blocked=["badword"]))` |
| `StarboardPlugin` | Pins highly-reacted messages to a starboard channel | `await bot.plugins.load(StarboardPlugin(channel_id="...", threshold=3))` |
| `LoggingPlugin` | Logs joins, leaves, deletes, and edits to a log channel | `await bot.plugins.load(LoggingPlugin(channel_id="..."))` |

## Community plugins

*None listed yet — be the first!*

To list your plugin here, open a PR adding a row to this table:

| Plugin | Author | Description | Install |
|---|---|---|---|
| your-plugin | @you | What it does | `pip install your-plugin` |

## Writing a plugin

See the [Plugins API reference](api/plugins.md) for the full guide. Minimal example:

```python
from nerimity_sdk import PluginBase, listener

class MyPlugin(PluginBase):
    name = "my_plugin"
    description = "Does something useful"

    @listener("message:created")
    async def on_message(self, event):
        if "hello" in event.message.content.lower():
            await self.bot.rest.create_message(
                event.message.channel_id, "Hello!"
            )

async def setup(bot):
    await bot.plugins.load(MyPlugin())
```

Drop it in `plugins/my_plugin.py` and load it:

```python
await bot.plugins.load_from_path("plugins/my_plugin.py")
```
