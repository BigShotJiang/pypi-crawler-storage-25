"""Infrastructure layer — concrete adapters that implement domain ports.

Public API groups:

- **Extractors** (``.extractors``): one module per upstream library.
  Heavy deps are lazy-imported so installing with no extras still lets
  you import the package.
- **Rendering** (``.rendering``): :class:`Jinja2Renderer` + bundled
  templates.
- **Policy** (``.policy``): :class:`DefaultPolicy` with size-aware
  precision routing.
- **Scoring** (``.scoring``): :class:`HeuristicScorer`.
- **Metadata** (``.metadata``): :class:`PdfMetadataProbe`,
  :class:`OfficeMetadataProbe`.
- **LLM** (``.llm``): :class:`LLMConfig`,
  :class:`OpenAICompatibleImageDescriber`.

May depend on :mod:`cyberdocextractor.domain` and
:mod:`cyberdocextractor.app`. Must not import from
:mod:`cyberdocextractor.cli`.
"""

from __future__ import annotations

from .extractors import (
    CsvExtractor,
    DoclingExtractor,
    OpenpyxlExtractor,
    PdfplumberExtractor,
    Pymupdf4llmExtractor,
    PymupdfChunkedExtractor,
)
from .llm import LLMConfig, OpenAICompatibleImageDescriber
from .metadata import OfficeMetadataProbe, PdfMetadataProbe
from .policy import DefaultPolicy
from .rendering import Jinja2Renderer
from .scoring import HeuristicScorer

__all__ = [
    "CsvExtractor",
    "DefaultPolicy",
    "DoclingExtractor",
    "HeuristicScorer",
    "Jinja2Renderer",
    "LLMConfig",
    "OfficeMetadataProbe",
    "OpenAICompatibleImageDescriber",
    "OpenpyxlExtractor",
    "PdfMetadataProbe",
    "PdfplumberExtractor",
    "Pymupdf4llmExtractor",
    "PymupdfChunkedExtractor",
]
