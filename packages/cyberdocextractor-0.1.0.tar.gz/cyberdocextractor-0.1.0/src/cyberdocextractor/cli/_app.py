"""Typer-based CLI for CyberDocExtractor.

Only imported when the ``cli`` extra is installed. The thin wrapper in
``cli/__init__.py`` falls back to an informative error when that isn't
the case.
"""

from __future__ import annotations

import sys
from enum import IntEnum
from pathlib import Path
from typing import NoReturn

import typer
from rich.console import Console
from rich.table import Table

from ..app import ConversionPipeline, convert_batch, discover_batch, load_document
from ..domain import (
    ConversionFailedError,
    CyberDocError,
    MimeType,
    PrecisionLevel,
    classify_mime,
)
from ..factory import build_pipeline
from ..infra import LLMConfig

__all__ = ["app"]

_console_out = Console()
_console_err = Console(stderr=True)

app = typer.Typer(
    help=(
        "CyberDocExtractor — convert PDF, DOCX, XLSX, XLS, and CSV files "
        "to Markdown via a pluggable hexagonal pipeline."
    ),
    add_completion=False,
    no_args_is_help=True,
    rich_markup_mode="rich",
)


class _Precision(IntEnum):
    """CLI alias for :class:`PrecisionLevel` (so Typer surfaces the choices)."""

    FASTEST = 1
    BALANCED = 2
    TABLE_OPTIMIZED = 3
    HIGHEST_QUALITY = 4


def _as_precision(level: _Precision) -> PrecisionLevel:
    return PrecisionLevel(int(level))


# ---------------------------------------------------------------------------
# convert
# ---------------------------------------------------------------------------


@app.command(help="Convert a single document to Markdown.")
def convert(
    source: Path = typer.Argument(
        ..., exists=True, readable=True, help="Path to the input document."
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Write Markdown to this path (otherwise stdout).",
    ),
    level: _Precision = typer.Option(
        _Precision.BALANCED,
        "--level",
        "-l",
        help="Precision level: 1=fastest, 4=highest quality.",
    ),
    template: str | None = typer.Option(
        None, "--template", "-t", help="Template name (default: auto-selected)."
    ),
    show_score: bool = typer.Option(
        False, "--show-score", help="Print the quality score to stderr."
    ),
    mime: str | None = typer.Option(
        None,
        "--mime",
        help="Override MIME type if extension-based detection is wrong.",
    ),
    no_fallback: bool = typer.Option(
        False, "--no-fallback", help="Disable extractor fallback chain."
    ),
) -> None:
    """Convert *source* to Markdown."""
    try:
        document = load_document(source, mime=mime, precision=_as_precision(level))
        pipeline = _build_pipeline_or_exit()
        report = pipeline.convert(document, template_name=template, allow_fallback=not no_fallback)
    except CyberDocError as exc:
        _fatal(exc)

    if output is None:
        sys.stdout.write(report.markdown.text)
    else:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(report.markdown.text, encoding="utf-8")
        _console_err.print(f"[green]wrote[/green] {output}")
    if show_score:
        _console_err.print(
            f"quality={report.markdown.quality_score:.2f} "
            f"extractor={report.extractor} "
            f"attempted={list(report.attempted)}"
        )


# ---------------------------------------------------------------------------
# batch
# ---------------------------------------------------------------------------


@app.command(help="Convert every matching file in a directory tree.")
def batch(
    source_dir: Path = typer.Argument(
        ..., exists=True, file_okay=False, dir_okay=True, readable=True
    ),
    target_dir: Path = typer.Argument(...),
    pattern: str = typer.Option(
        "*", "--pattern", "-p", help="Glob pattern (relative to source_dir)."
    ),
    level: _Precision = typer.Option(_Precision.BALANCED, "--level", "-l"),
    template: str | None = typer.Option(None, "--template", "-t"),
) -> None:
    """Convert many documents in one pass."""
    items = discover_batch(source_dir, target_dir, pattern=pattern)
    if not items:
        _console_err.print(f"[yellow]no files matched[/yellow] pattern={pattern!r} in {source_dir}")
        raise typer.Exit(code=1)

    pipeline = _build_pipeline_or_exit()
    result = convert_batch(
        pipeline,
        items,
        template_name=template,
        precision=_as_precision(level),
    )

    summary = Table(title="Batch results")
    summary.add_column("Source")
    summary.add_column("Target")
    summary.add_column("Status")
    summary.add_column("Score", justify="right")
    for success in result.succeeded:
        summary.add_row(
            str(success.source),
            str(success.target),
            "[green]ok[/green]",
            f"{success.report.markdown.quality_score:.2f}",
        )
    for failure in result.failed:
        summary.add_row(
            str(failure.source),
            "-",
            f"[red]fail:[/red] {failure.error_type}",
            "-",
        )
    _console_out.print(summary)
    _console_err.print(
        f"{len(result.succeeded)} ok / {len(result.failed)} failed "
        f"({result.success_rate:.0%} success rate)"
    )
    if result.failed:
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


@app.command(help="Show which extractors are available in this environment.")
def status() -> None:
    """Report which upstream libraries are installed."""
    pipeline = _build_pipeline_or_exit()
    table = Table(title="Extractor status")
    table.add_column("Name")
    table.add_column("Precision")
    table.add_column("PDF")
    table.add_column("DOCX")
    table.add_column("XLSX")
    table.add_column("CSV")
    mime_types = (
        MimeType.PDF.value,
        MimeType.DOCX.value,
        MimeType.XLSX.value,
        MimeType.CSV.value,
    )
    for extractor in pipeline.policy.extractors:  # type: ignore[attr-defined]
        row = [extractor.name, extractor.precision_level.name]
        row.extend("✓" if extractor.supports(m) else "—" for m in mime_types)
        table.add_row(*row)
    _console_out.print(table)


# ---------------------------------------------------------------------------
# info
# ---------------------------------------------------------------------------


@app.command(help="Show size, MIME type, and recommended precision for a file.")
def info(
    source: Path = typer.Argument(..., exists=True, readable=True),
) -> None:
    """Print document metadata without converting."""
    document = load_document(source)
    mime = classify_mime(document.mime)
    table = Table(title=f"info: {source.name}")
    table.add_column("Field")
    table.add_column("Value")
    table.add_row("path", str(source.resolve()))
    table.add_row("mime", document.mime)
    table.add_row(
        "classified",
        mime.name if mime is not None else "[yellow]unknown[/yellow]",
    )
    table.add_row("size", f"{document.size_mb:.2f} MiB ({document.size_bytes} bytes)")
    table.add_row("precision", document.precision.name)
    _console_out.print(table)


# ---------------------------------------------------------------------------
# templates
# ---------------------------------------------------------------------------


@app.command(help="List available Markdown templates.")
def templates() -> None:
    """Print the template names shipped with the package."""
    pipeline = _build_pipeline_or_exit()
    for name in pipeline.renderer.list_templates():
        _console_out.print(name)


# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------


@app.command(help="Print the installed package version.")
def version() -> None:
    """Show the installed ``cyberdocextractor`` version."""
    from .. import __version__

    _console_out.print(f"cyberdoc {__version__}")


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _build_pipeline_or_exit() -> ConversionPipeline:
    try:
        llm_config: LLMConfig | None = None
        try:
            candidate = LLMConfig.from_env()
            llm_config = candidate if candidate.is_configured else None
        except Exception:
            llm_config = None
        return build_pipeline(llm_config=llm_config)
    except Exception as exc:
        _fatal(exc)


def _fatal(exc: BaseException) -> NoReturn:
    _console_err.print(f"[red]error:[/red] {exc}")
    if isinstance(exc, ConversionFailedError):
        _console_err.print(f"[dim]attempted extractors:[/dim] {list(exc.attempted_extractors)}")
    raise typer.Exit(code=1)
