# Contributing to taintly

This document is the dev setup, the test-harness overview, and the rule-authoring contract.

---

## Dev setup

```bash
git clone https://github.com/Nellur35/taintly
cd taintly
pip install -e ".[dev]"
```

That installs the scanner in editable mode plus the dev tooling: pytest, pytest-timeout, pytest-cov, hypothesis, mypy, coverage.

Additional tools referenced in CI (install as needed):

```bash
pip install ruff==0.9.0 bandit==1.8.3 mypy==1.14.1 pip-audit==2.9.0
```

The project is zero-runtime-dep on purpose — don't add `requests`, `pyyaml`, etc. to the main `[project]` dependencies without a discussion. `[project.optional-dependencies].dev` is fair game.

---

## Run the tests

The suite has four layers, each solving a different failure class:

| Command | What it checks |
|---|---|
| `pytest tests/unit/` | Engine, models, reporters, scorer, YAML path parser, job splitter |
| `pytest tests/integration/` | End-to-end: hardened fixtures produce zero findings; subprocess CLI contracts |
| `pytest tests/evasion/` | Documented semantic bypasses — kept visible so gaps are tracked, not hidden |
| `pytest tests/fuzz/` | Adversarial input: YAML bombs, null bytes, RTL unicode, ReDoS payloads |
| `python -m taintly --self-test` | Every rule's `test_positive` fires, every `test_negative` stays silent |
| `python -m taintly --self-test --mutate` | Mutation testing with 100% kill-rate required |
| `python -m taintly --integration-test` | Non-bypass integration tests; known-bypass failures are expected |

Run the whole thing:

```bash
pytest tests/ --cov=taintly --cov-branch --cov-fail-under=80
python -m taintly --self-test --mutate
python -m taintly --integration-test
```

---

## Code style

- **ruff** — `ruff check taintly/` (11 rule sets on; see `pyproject.toml` for the ignore list with per-rule reason comments)
- **ruff format** — `ruff format taintly/`
- **mypy** — `mypy` (strict bundle on; `taintly.testing.*` is the only excluded module tree)
- **bandit** — `bandit -r taintly/ -c pyproject.toml -x taintly/testing/`

All four must pass on every PR. CI enforces them.

### Suppressions require reasons

- `# noqa: RULE` comments must end with a `—` and a one-line reason
- `# type: ignore[errcode]` comments must end with a `—` and a one-line reason
- `# nosec BXXX` comments must end with a `—` and a one-line reason
- `.taintly.yml` `ignore:` entries must set `reason:` and `owner:`; `expires:` is strongly encouraged

The scanner enforces the latter three on its own codebase in `audit-self`; reviewers enforce `# noqa` conventions at PR time.

---

## Authoring a new rule

Rules are pure data — `@dataclass Rule` instances in a file under `taintly/rules/<platform>/`. No engine changes are needed to add a rule.

### Template

```python
Rule(
    id="SEC4-GH-NNN",               # SEC{1..10}-{GH|GL|JK}-{001..999}
    title="Short one-line summary shown in report tables",
    severity=Severity.HIGH,         # CRITICAL / HIGH / MEDIUM / LOW / INFO
    platform=Platform.GITHUB,
    owasp_cicd="CICD-SEC-4",
    description=(
        "Paragraph-length description of WHAT this rule detects and WHY "
        "it matters. Appears in text reports and SARIF messages. 2–4 "
        "sentences. Motivation for the check should be obvious from this "
        "alone."
    ),
    pattern=RegexPattern(
        match=r"...",
        exclude=[r"^\s*#", r"..."],  # comment-only lines and other known FPs
    ),
    remediation=(
        "Actionable fix. Show BAD vs GOOD in a code block where "
        "appropriate. This is what a developer reads when deciding what "
        "to change, so make it copy-pasteable."
    ),
    reference="https://owasp.org/www-project-top-10-ci-cd-security-risks/",
    test_positive=[
        "# at least one sample that MUST trigger",
        "...",
    ],
    test_negative=[
        "# at least one sample that MUST stay silent",
        "...",
    ],
    stride=["T", "E"],               # primary STRIDE categories, primary first
    threat_narrative=(
        "One or two sentences describing the attack story: what the "
        "attacker does, what impact follows. This is the 'how does it go "
        "wrong in practice' field."
    ),
    incidents=[                      # optional but strongly encouraged
        "tj-actions/changed-files (Mar 2025)",
        "Ultralytics (Dec 2024)",
    ],
)
```

### Checklist

A new rule PR must:

- [ ] Pick the right family prefix. `SEC4-*` = pipeline execution (PPE), `SEC3-*` = supply chain, etc. See `docs/RULES.md` for the full map.
- [ ] Use the lowest-numbered unused ID in that family for the target platform.
- [ ] Provide ≥2 `test_positive` and ≥2 `test_negative` samples. Edge cases count. Mutation tests must not survive on the positive samples.
- [ ] Ship `stride=[...]` with at least one category.
- [ ] Ship a `threat_narrative`.
- [ ] Reference a real-world incident if one exists. Even one CVE citation is a meaningful improvement to the rule's credibility.
- [ ] Add a mapping entry in `benchmark/taxonomy.py` under the matching weakness category (AIW / IW / PTW / EPW / UDW / HGW / SEW / KVCW / CFW / GRCW).
- [ ] Pass `python -m taintly --self-test --mutate` (100% kill rate).
- [ ] Pass `pytest tests/` (no coverage regression).
- [ ] Update `CHANGELOG.md` under the `## [Unreleased]` section.

### Pattern-type cheat sheet

| Type | When to use |
|---|---|
| `RegexPattern` | Single-line regex on step content. 80% of rules use this. |
| `AbsencePattern` | Fires when a required pattern is ABSENT from the file / top-level scope. |
| `ContextPattern` | Co-occurrence: anchor + requires (both must be present). Scope=file or scope=job. |
| `SequencePattern` | Ordered absence: anchor appears + `absent_within` lookahead doesn't. |
| `BlockPattern` | Indent-scoped: fire when pattern matches inside a specific YAML block. |
| `PathPattern` | Structural YAML path queries (via `yaml_path.py`). Use when line-level regex is too fragile. |

TAINT rules use a bespoke pattern type (`TaintPattern`) that duck-types the `PatternProtocol`. Adding new taint rules is harder than adding regex rules — see `taintly/taint.py` for the resolver model.

---

## Pull-request workflow

- Branch name: `claude/<scope>` (if generated) or `<your-handle>/<scope>`.
- PR title: imperative, short. Body describes **why**, not **what** (the diff tells the what).
- **Scope discipline**: one logical change per PR. A new rule + a refactor of the scorer is two PRs.
- CI must be green before merge.
- Squash-merge is the default.

### What CI enforces

- `lint` — ruff check + ruff format check
- `type-check` — mypy across Python 3.10/3.11/3.12
- `unit-test` — pytest `tests/unit/integration/evasion/` with 80% branch coverage floor
- `rule-test` — `--self-test`, `--mutate`, `--integration-test` across the Python matrix
- `fuzz` — adversarial input resilience
- `audit-self` — the scanner scans its own workflows; no HIGH+ findings allowed
- `bandit` / `pip-audit` / `gitleaks` / `codeql` — security scanners

---

## Maintainer notes

### Cutting a release

1. Update `CHANGELOG.md`: move `Unreleased` entries to a new version header, date it. Commit via PR, merge.
2. Tag from `main`: `git tag v1.2.3` (or via the API: `gh api -X POST repos/Nellur35/taintly/git/refs -f ref=refs/tags/v1.2.3 -f "sha=$(gh api repos/Nellur35/taintly/git/ref/heads/main -q .object.sha)"`). Version is derived by setuptools-scm at build time from the tag.
3. Push the tag: `git push origin v1.2.3`. `.github/workflows/release.yml` fires, builds sdist+wheel, publishes to PyPI via trusted publishing, then creates a GitHub Release with the artefacts attached and the CHANGELOG section as the body.
4. Move the floating `v1` to the new tag (for consumers that use `@v1`):
   ```bash
   new_sha=$(gh api repos/Nellur35/taintly/git/ref/tags/v1.2.3 -q .object.sha)
   gh api -X PATCH repos/Nellur35/taintly/git/refs/tags/v1 -f "sha=$new_sha" -F "force=true"
   ```

### PyPI trusted publishing setup (one-time)

On PyPI:
1. Create the `taintly` project (or claim ownership).
2. Go to **Manage → Publishing** → **Add a new pending publisher**.
3. Set: owner=`Nellur35`, repo=`taintly`, workflow=`release.yml`, environment=`pypi`.
4. First `release.yml` run after that claims the project.

For TestPyPI dry-runs (validate the publishing path without burning a real version), configure a second pending publisher on test.pypi.org with environment=`testpypi` and trigger `test-release.yml` via `workflow_dispatch`.

The `release.yml` file uses `id-token: write` + `pypa/gh-action-pypi-publish` — no long-lived API token is stored anywhere.

Consumers can install via `pip install taintly` (PyPI), `pip install git+https://github.com/Nellur35/taintly@v1` (any tag/branch/SHA), or via the composite Action (`Nellur35/taintly@v1`) / GitLab CI Component.

---

## Questions / discussion

- Bug reports and feature requests: GitHub Issues
- Security issues: see `SECURITY.md` (private channel required)
- Design discussion: GitHub Discussions
