#!/usr/bin/env bash
#
# verify-examples.sh — assert every example fires its expected taintly rules.
#
# For each directory containing both `.github/workflows/` and an
# `expected-rules.txt` sibling, run `taintly` against it and assert
# that every rule ID listed in `expected-rules.txt` appears at least
# once in the scan output. Lines starting with `#` and blank lines in
# `expected-rules.txt` are ignored.
#
# Also runs a smoke test of the --baseline / --diff flow against
# examples/08-baseline-diff/ to confirm that workflow still works.
#
# Exit code: 0 on success, 1 on any missing rule or unexpected error.
#
# Designed to be path-agnostic — matches rule IDs only, not the full
# scan report (which contains repository-relative paths that differ
# across OSes).
set -euo pipefail

repo_root="$(cd "$(dirname "$0")/.." && pwd)"
examples_dir="$repo_root/examples"

if [ ! -d "$examples_dir" ]; then
  echo "verify-examples: $examples_dir does not exist" >&2
  exit 1
fi

# Locate the taintly entry point. Prefer the in-tree module so CI runs
# what the working tree defines, not a previously-installed wheel.
TAINTLY=( python -m taintly )

fail=0
total=0

# Find every workflow root: a directory containing .github/workflows/
# whose immediate parent has an expected-rules.txt.
while IFS= read -r -d '' wf_dir; do
  scan_target="$(dirname "$(dirname "$wf_dir")")"
  expected="$scan_target/expected-rules.txt"
  if [ ! -f "$expected" ]; then
    continue
  fi
  total=$((total + 1))

  rel_target="${scan_target#$repo_root/}"
  echo "::group::$rel_target"

  scan_output="$(cd "$repo_root" && "${TAINTLY[@]}" "$rel_target" 2>&1 || true)"

  missing=()
  while IFS= read -r line; do
    # Skip comments and blanks.
    case "$line" in ''|'#'*) continue ;; esac
    rule="$(printf '%s' "$line" | tr -d '[:space:]')"
    [ -z "$rule" ] && continue
    # Match the rule ID inside a finding line (severity prefix tolerant).
    if ! printf '%s\n' "$scan_output" | grep -Eq "\b$rule\b"; then
      missing+=("$rule")
    fi
  done < "$expected"

  if [ "${#missing[@]}" -gt 0 ]; then
    echo "MISSING in $rel_target:"
    for r in "${missing[@]}"; do echo "  - $r"; done
    fail=$((fail + 1))
    echo "  --- scan output (first 60 lines) ---"
    printf '%s\n' "$scan_output" | head -60 | sed 's/^/  /'
  else
    echo "OK $rel_target"
  fi
  echo "::endgroup::"
done < <(find "$examples_dir" -type d -name workflows -path '*/.github/workflows' -print0)

# --- baseline / --diff smoke test ---
echo "::group::baseline-diff smoke"
baseline_tmp="$(mktemp -t taintly-baseline.XXXXXX.json)"
trap 'rm -f "$baseline_tmp"' EXIT

before="$examples_dir/08-baseline-diff/before-fix"
after="$examples_dir/08-baseline-diff/after-fix"

if [ -d "$before" ] && [ -d "$after" ]; then
  rel_before="${before#$repo_root/}"
  rel_after="${after#$repo_root/}"

  cd "$repo_root"
  "${TAINTLY[@]}" "$rel_before" --baseline "$baseline_tmp" > /dev/null 2>&1 || true

  diff_out="$("${TAINTLY[@]}" "$rel_after" --diff "$baseline_tmp" 2>&1 || true)"

  # The regression we expect to see in --diff is SEC3-GH-001 (unpinned action).
  # Existing findings carried over from before-fix should NOT appear.
  if printf '%s\n' "$diff_out" | grep -q "SEC3-GH-001"; then
    if printf '%s\n' "$diff_out" | grep -q "TAINT-GH-002\|SEC1-GH-001\|SEC4-GH-005"; then
      echo "FAIL baseline-diff: pre-existing findings leaked through --diff"
      fail=$((fail + 1))
    else
      echo "OK baseline-diff smoke test"
    fi
  else
    echo "FAIL baseline-diff: SEC3-GH-001 regression not surfaced by --diff"
    fail=$((fail + 1))
    printf '%s\n' "$diff_out" | head -40 | sed 's/^/  /'
  fi
else
  echo "SKIP baseline-diff smoke (example 08 not present)"
fi
echo "::endgroup::"

echo
if [ "$fail" -gt 0 ]; then
  echo "verify-examples: $fail / $total scan target(s) failed"
  exit 1
fi
echo "verify-examples: $total scan target(s) verified clean"
