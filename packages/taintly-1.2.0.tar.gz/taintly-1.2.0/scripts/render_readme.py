#!/usr/bin/env python
"""Regenerate the count-driven sections of README.md from rule data.

Two AUTOGEN blocks are owned by this script and rewritten on every
invocation:

    <!-- AUTOGEN:summary --> ...      The opening paragraph of "What it
                                      detects" (totals + per-platform
                                      breakdown + AI/ML count).
    <!-- AUTOGEN:coverage --> ...     The per-category coverage table and
                                      the "Plus N platform-posture rules
                                      (...)" sentence that follows.

Run ``python scripts/render_readme.py`` to rewrite in place. Run with
``--check`` to exit 1 (and diff to stderr) when the file is stale —
wired into the test suite as ``test_readme_counts_in_sync``.

Single source of truth: rules loaded via
``taintly.rules.registry.load_all_rules``; platform-posture rule IDs
extracted from the ``rule_id="PLAT-..."`` string literals in
``taintly/platform/*_checks.py`` (the only places those IDs are
authored).
"""
from __future__ import annotations

import argparse
import difflib
import os
import re
import sys
from collections import Counter
from pathlib import Path

# Allow running as a script without installing the package.
REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

from taintly.rules.registry import load_all_rules  # noqa: E402

README = REPO_ROOT / "README.md"
PLATFORM_DIR = REPO_ROOT / "taintly" / "platform"

_PLAT_ID_RE = re.compile(r'rule_id="(PLAT-G[HL]-\d+)"')
_BLOCK_RE = re.compile(
    r"(<!-- AUTOGEN:(\w[\w-]*) -->)(.*?)(<!-- /AUTOGEN:\2 -->)",
    re.DOTALL,
)


def _plat_rule_ids() -> tuple[list[str], list[str]]:
    """Return (github_ids, gitlab_ids) sorted by numeric suffix.

    Extracted from string-literal ``rule_id="PLAT-..."`` assignments so
    we don't count IDs that only appear in docstrings or comments.
    """
    gh: set[str] = set()
    gl: set[str] = set()
    for py in PLATFORM_DIR.glob("*_checks.py"):
        for m in _PLAT_ID_RE.finditer(py.read_text()):
            rid = m.group(1)
            (gh if rid.startswith("PLAT-GH") else gl).add(rid)
    return (
        sorted(gh, key=lambda r: int(r.rsplit("-", 1)[1])),
        sorted(gl, key=lambda r: int(r.rsplit("-", 1)[1])),
    )


def _file_rule_buckets() -> dict:
    """Compute all counts needed for the three AUTOGEN blocks.

    Breakdown mirrors the README's conventions:
      * per-platform totals
      * per-OWASP-category totals (SEC-1..SEC-10), excluding AI/TAINT so
        they don't double-count the AI/ML and TAINT rows shown separately
      * AI/ML totals (rules whose ID starts ``AI-``)
      * TAINT totals (rules whose ID starts ``TAINT-``)
    """
    rules = load_all_rules()
    ai = Counter()
    taint = Counter()
    by_cat = Counter()  # (platform, category)
    by_plat = Counter()

    for r in rules:
        plat = r.platform.value
        by_plat[plat] += 1
        if r.id.startswith("AI-"):
            ai[plat] += 1
            continue
        if r.id.startswith("TAINT-"):
            taint[plat] += 1
            continue
        by_cat[(plat, r.owasp_cicd)] += 1

    # Count LOTP rules too — they flavour a prose paragraph outside the
    # autogen region but the summary paragraph mentions the total count.
    lotp = Counter(
        r.platform.value for r in rules if r.id.startswith("LOTP-")
    )

    return {
        "total": len(rules),
        "by_plat": by_plat,
        "ai": ai,
        "taint": taint,
        "lotp": lotp,
        "by_cat": by_cat,
    }


_OWASP_ROW_ORDER = [
    ("CICD-SEC-1", "SEC-1", "Insufficient Flow Control"),
    ("CICD-SEC-2", "SEC-2", "Inadequate IAM"),
    ("CICD-SEC-3", "SEC-3", "Dependency Chain Abuse"),
    ("CICD-SEC-4", "SEC-4", "Poisoned Pipeline Execution"),
    ("CICD-SEC-5", "SEC-5", "Insufficient PBAC"),
    ("CICD-SEC-6", "SEC-6", "Insufficient Credential Hygiene"),
    ("CICD-SEC-7", "SEC-7", "Insecure System Configuration"),
    ("CICD-SEC-8", "SEC-8", "Ungoverned 3rd Party Services"),
    ("CICD-SEC-9", "SEC-9", "Improper Artifact Integrity"),
    ("CICD-SEC-10", "SEC-10", "Insufficient Logging"),
]


def render_summary(b: dict, plat_gh: list[str], plat_gl: list[str]) -> str:
    total = b["total"]
    gh = b["by_plat"]["github"]
    gl = b["by_plat"]["gitlab"]
    jk = b["by_plat"]["jenkins"]
    ai_total = sum(b["ai"].values())
    plat_total = len(plat_gh) + len(plat_gl)
    return (
        f"{total} file-based rules and {plat_total} platform-posture "
        f"checks. The file-based rules break down as {gh} GitHub, "
        f"{gl} GitLab, and {jk} Jenkins, and include a dedicated AI / "
        f"ML category ({ai_total} rules across the three platforms, "
        f"plus multi-platform taint analysis) for workflows that run "
        f"model loads or AI coding agents. The posture checks "
        f"({len(plat_gh)} GitHub, {len(plat_gl)} GitLab) only run in "
        f"`--platform-audit` mode."
    )


def render_coverage(b: dict, plat_gh: list[str], plat_gl: list[str]) -> str:
    lines = [
        "| Category | Description | GitHub | GitLab | Jenkins |",
        "|----------|-------------|--------|--------|---------|",
    ]
    for owasp, label, desc in _OWASP_ROW_ORDER:
        gh = b["by_cat"][("github", owasp)]
        gl = b["by_cat"][("gitlab", owasp)]
        jk = b["by_cat"][("jenkins", owasp)]
        lines.append(f"| {label} | {desc} | {gh} | {gl} | {jk} |")
    lines.append(
        "| AI / ML | AI model, agent, MCP | "
        f"{b['ai']['github']} | {b['ai']['gitlab']} | {b['ai']['jenkins']} |"
    )
    lines.append(
        "| TAINT | Multi-stage taint flows | "
        f"{b['taint']['github']} | {b['taint']['gitlab']} | {b['taint']['jenkins']} |"
    )
    table = "\n".join(lines)

    # Format PLAT IDs like `001/002/...` to match the pre-existing prose.
    def _compact(ids: list[str]) -> str:
        return "/".join(i.rsplit("-", 1)[1] for i in ids)

    plat_sentence = (
        f"Plus {len(plat_gh) + len(plat_gl)} platform-posture rules "
        f"(`PLAT-GH-{_compact(plat_gh)}`, "
        f"`PLAT-GL-{_compact(plat_gl)}`)."
    )
    return f"{table}\n\n{plat_sentence}"


def _render_all() -> dict[str, str]:
    b = _file_rule_buckets()
    plat_gh, plat_gl = _plat_rule_ids()
    return {
        "summary": render_summary(b, plat_gh, plat_gl),
        "coverage": render_coverage(b, plat_gh, plat_gl),
    }


def _apply(content: str, blocks: dict[str, str]) -> str:
    """Rewrite every ``<!-- AUTOGEN:name --> ... <!-- /AUTOGEN:name -->``
    region whose name is a key of ``blocks``. An unknown name raises so a
    typo in a marker doesn't silently leave the block stale.

    The rewritten region is always ``open_marker\n{content}\n/open_marker``
    so the rendered content appears on its own lines, which keeps the
    surrounding markdown predictable (tables and code fences need line
    boundaries).
    """
    seen: set[str] = set()

    def _sub(m: re.Match) -> str:
        name = m.group(2)
        seen.add(name)
        if name not in blocks:
            raise KeyError(
                f"Unknown AUTOGEN block in README: {name!r}. "
                f"Known: {sorted(blocks)}"
            )
        open_marker, _, _, close_marker = m.group(1, 2, 3, 4)
        # Preserve an extra blank line inside code-fence-flavoured blocks
        # ("testing" sits inside ```...```). Simplest rule: always wrap
        # the rendered body in newlines.
        return f"{open_marker}\n{blocks[name]}\n{close_marker}"

    new_content = _BLOCK_RE.sub(_sub, content)
    missing = set(blocks) - seen
    if missing:
        raise KeyError(
            f"README is missing AUTOGEN markers for: {sorted(missing)}"
        )
    return new_content


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n", 1)[0])
    parser.add_argument(
        "--check",
        action="store_true",
        help="Exit non-zero if README is out of sync; do not write.",
    )
    args = parser.parse_args()

    content = README.read_text()
    rendered = _apply(content, _render_all())

    if args.check:
        if rendered != content:
            diff = "".join(
                difflib.unified_diff(
                    content.splitlines(keepends=True),
                    rendered.splitlines(keepends=True),
                    fromfile="README.md (on disk)",
                    tofile="README.md (expected)",
                )
            )
            sys.stderr.write(diff)
            sys.stderr.write(
                "\nREADME.md is out of sync with rule data. "
                "Run: python scripts/render_readme.py\n"
            )
            return 1
        return 0

    if rendered != content:
        README.write_text(rendered)
        print(f"Rewrote {os.path.relpath(README, REPO_ROOT)}")
    else:
        print("README.md already in sync.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
