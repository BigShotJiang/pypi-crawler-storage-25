"""Benchmark tests — validate detection and false-positive suppression against
the synthetic fixture corpus in benchmark/fixtures.py.

These tests serve three purposes:
  1. Regression guard: rules in must_fire MUST keep firing
  2. FP regression: rules in must_not_fire MUST NOT fire (catches BUG-7 class regressions)
  3. Taxonomy validation: every per-category fixture covers its assigned weakness codes

Run with: pytest tests/benchmark/ -v

The fixture corpus is defined in benchmark/fixtures.py so it can be shared
between the pytest regression suite (here) and the full benchmark runner
(benchmark/runner.py). Ground truth lives in one place.
"""

from __future__ import annotations

import textwrap

import pytest

from benchmark.fixtures import ALL_FIXTURES, SyntheticFixture
from taintly.engine import scan_file
from taintly.models import Platform

# ============================================================================
# Parametrize over all fixtures that have must_fire or must_not_fire assertions
# ============================================================================

_ASSERTABLE = [f for f in ALL_FIXTURES if f.must_fire or f.must_not_fire]
_IDS = [f.name for f in _ASSERTABLE]


def _scan(fixture: SyntheticFixture, all_rules) -> set[str]:
    """Scan a fixture's inline content and return the set of fired rule IDs."""
    platform = Platform.GITHUB if fixture.platform == "github" else Platform.GITLAB
    rules = [r for r in all_rules if r.platform == platform]

    # Write content to a temp path that the engine will recognise by extension
    import tempfile
    from pathlib import Path

    suffix = ".yml"
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=suffix, delete=False, encoding="utf-8"
    ) as fh:
        fh.write(textwrap.dedent(fixture.content))
        path = fh.name

    try:
        findings = scan_file(path, rules)
        return {f.rule_id for f in findings if f.rule_id != "ENGINE-ERR"}
    finally:
        Path(path).unlink(missing_ok=True)


# ============================================================================
# Test 1: must_fire — rules that MUST appear in findings
# ============================================================================

@pytest.mark.parametrize("fixture", _ASSERTABLE, ids=_IDS)
def test_must_fire(fixture: SyntheticFixture, all_rules):
    """Every rule in must_fire must appear in the scan results."""
    if not fixture.must_fire:
        pytest.skip("no must_fire assertions")

    fired = _scan(fixture, all_rules)
    missing = [r for r in fixture.must_fire if r not in fired]

    assert not missing, (
        f"[{fixture.name}] Rules expected to fire but didn't: {missing}\n"
        f"All fired: {sorted(fired)}\n"
        f"Notes: {fixture.notes}"
    )


# ============================================================================
# Test 2: must_not_fire — false positive guard
# ============================================================================

@pytest.mark.parametrize("fixture", _ASSERTABLE, ids=_IDS)
def test_must_not_fire(fixture: SyntheticFixture, all_rules):
    """Every rule in must_not_fire must NOT appear in the scan results."""
    if not fixture.must_not_fire:
        pytest.skip("no must_not_fire assertions")

    fired = _scan(fixture, all_rules)
    false_positives = [r for r in fixture.must_not_fire if r in fired]

    assert not false_positives, (
        f"[{fixture.name}] FALSE POSITIVE — rules fired but are in must_not_fire: {false_positives}\n"
        f"All fired: {sorted(fired)}\n"
        f"Notes: {fixture.notes}"
    )


# ============================================================================
# Test 3: per-category fixtures have at least one must_fire assertion
# ============================================================================

def test_per_category_fixtures_have_assertions():
    """Every per-category fixture must have at least one must_fire rule."""
    from benchmark.fixtures import CATEGORY_FIXTURES

    bad = [f.name for f in CATEGORY_FIXTURES if not f.must_fire]
    assert not bad, f"Per-category fixtures missing must_fire: {bad}"


# ============================================================================
# Test 4: false-positive fixtures have at least one must_not_fire assertion
# ============================================================================

def test_false_positive_fixtures_have_assertions():
    """Every false-positive fixture must have at least one must_not_fire rule."""
    from benchmark.fixtures import FALSE_POSITIVE_FIXTURES

    bad = [f.name for f in FALSE_POSITIVE_FIXTURES if not f.must_not_fire]
    # fp_gitlab_rules_if has no confirmed rule to assert — skip it
    bad = [n for n in bad if n != "fp_gitlab_rules_if"]
    assert not bad, f"False-positive fixtures missing must_not_fire: {bad}"


# ============================================================================
# Test 5: scorer smoke test — zero findings → score 100, grade A
# ============================================================================

def test_scorer_zero_findings():
    from taintly.scorer import compute_score

    report = compute_score([])
    assert report.total_score == 100
    assert report.grade == "A"
    assert report.bonuses["no_criticals"] == 5
    assert report.bonuses["all_actions_pinned"] == 5
    assert report.bonuses["all_permissions"] == 5


def test_scorer_caps_correctly():
    """Repeat findings of the same rule collapse into ONE cluster and
    deduct once, not N times.

    This is the whole point of the cluster-based scorer: correlated
    findings describing the same root cause shouldn't compound. The
    earlier per-severity-cap model (which capped at 30 pts for 3+
    CRITICALs) implicitly tried to achieve the same effect, but with
    worse fidelity: it treated unrelated CRITICALs the same as
    correlated ones.
    """
    from taintly.models import Finding, Severity
    from taintly.scorer import compute_score

    findings = [
        Finding(
            rule_id="SEC4-GH-001",
            severity=Severity.CRITICAL,
            title="t",
            description="d",
            file="f",
            owasp_cicd="CICD-SEC-4",
        )
        for _ in range(5)
    ]
    report = compute_score(findings)

    # Five identical findings => one cluster, counted once.
    assert report.distinct_risks == 1, (
        f"five identical findings should collapse to ONE cluster, got "
        f"{report.distinct_risks}"
    )

    # Cluster-based deduction is the sole math track; per-severity keys
    # are kept at 0.0 for display-layer compatibility.
    assert report.deductions["CRITICAL"] == 0.0
    assert report.deductions["HIGH"] == 0.0
    assert report.deductions["MEDIUM"] == 0.0
    assert report.deductions["CLUSTERS"] < 0, (
        "cluster track should report a negative deduction"
    )

    # Bonus logic is unchanged: no_criticals is denied (findings contain
    # CRITICALs); pinning / permissions bonuses still apply because
    # neither SEC3-GH-001/002/GL-002 nor SEC2-GH-002 fired.
    assert report.bonuses["no_criticals"] == 0
    assert report.bonuses["all_actions_pinned"] == 5
    assert report.bonuses["all_permissions"] == 5

    # Score must not land in F territory on a single cluster. The exact
    # value is sensitive to weight tuning, so assert a range rather than
    # an exact number.
    assert 80 <= report.total_score <= 100
    assert report.grade in ("A", "B")


def test_scorer_grade_mapping():
    """Grade boundaries are correct."""
    from taintly.scorer import _grade_for

    assert _grade_for(100) == "A"
    assert _grade_for(90) == "A"
    assert _grade_for(89) == "B"
    assert _grade_for(80) == "B"
    assert _grade_for(79) == "C"
    assert _grade_for(65) == "C"
    assert _grade_for(64) == "D"
    assert _grade_for(50) == "D"
    assert _grade_for(49) == "F"
    assert _grade_for(0) == "F"
