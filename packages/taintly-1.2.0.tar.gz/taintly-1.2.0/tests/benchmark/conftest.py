"""Shared fixtures for benchmark tests."""

from __future__ import annotations

import pytest

from taintly.models import Platform
from taintly.rules.registry import load_all_rules


@pytest.fixture(scope="session")
def all_rules():
    return load_all_rules()


@pytest.fixture(scope="session")
def github_rules(all_rules):
    return [r for r in all_rules if r.platform == Platform.GITHUB]


@pytest.fixture(scope="session")
def gitlab_rules(all_rules):
    return [r for r in all_rules if r.platform == Platform.GITLAB]
