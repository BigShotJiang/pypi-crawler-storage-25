"""Scorer v2 tests — confidence weighting, review-needed exclusion,
distinct-cluster counts.

The improvement report flagged two scoring flaws:

1. Repeated correlated findings disproportionately tanked the grade.
2. Low-precision / review-needed rules had the same impact as exact
   syntactic matches.

These tests lock in the fixes so a future refactor can't silently
regress them.
"""

from __future__ import annotations

from taintly.models import Finding, Severity
from taintly.scorer import compute_score


def _fn(
    rule_id: str,
    severity: Severity = Severity.HIGH,
    *,
    confidence: str = "high",
    review_needed: bool = False,
    family: str = "supply_chain_immutability",
    owasp: str = "CICD-SEC-3",
) -> Finding:
    return Finding(
        rule_id=rule_id,
        severity=severity,
        title=rule_id,
        description="",
        file="x.yml",
        line=1,
        owasp_cicd=owasp,
        finding_family=family,
        confidence=confidence,
        review_needed=review_needed,
    )


def test_low_confidence_finding_deducts_less_than_high():
    """A LOW-confidence HIGH finding must move the score less than a
    HIGH-confidence HIGH finding of the same severity.  Uses enough
    findings that per-severity deductions overcome the bonus floor so
    the weight actually shows up in the final score.
    """
    # SEC3-GH-001 is in the "pinned" bonus set, so it suppresses the
    # all_actions_pinned bonus — lets raw deductions drive the score.
    # SEC2-GH-002 similarly suppresses the permissions bonus.
    findings_high = [_fn("SEC3-GH-001", Severity.HIGH, confidence="high") for _ in range(20)]
    findings_high.append(_fn("SEC2-GH-002", Severity.CRITICAL, confidence="high", family="identity_access", owasp="CICD-SEC-2"))
    findings_low = [_fn("SEC3-GH-001", Severity.HIGH, confidence="low") for _ in range(20)]
    findings_low.append(_fn("SEC2-GH-002", Severity.CRITICAL, confidence="low", family="identity_access", owasp="CICD-SEC-2"))

    high_conf = compute_score(findings_high)
    low_conf = compute_score(findings_low)
    assert low_conf.total_score > high_conf.total_score


def test_review_needed_finding_does_not_deduct():
    """Review-needed items are human-triage — they must not touch the
    score at all.  The only effect should be the review-needed cluster
    count surfacing alongside the grade.
    """
    only_review = compute_score([
        _fn("R", Severity.CRITICAL, review_needed=True, family="privileged_pr_trigger", owasp="CICD-SEC-4"),
    ])
    assert only_review.total_score == 100
    assert only_review.review_needed == 1
    assert only_review.distinct_risks == 0


def test_distinct_risk_count_matches_clusters():
    """Correlated findings should produce ONE distinct risk, not N."""
    # Three findings in the same supply-chain family, different rule IDs.
    findings = [
        _fn("SEC3-GH-001"),
        _fn("SEC3-GH-002", severity=Severity.CRITICAL),
        _fn("SEC8-GH-003", severity=Severity.HIGH),
    ]
    score = compute_score(findings)
    assert score.distinct_risks == 1


def test_score_to_dict_includes_distinct_risks():
    score = compute_score([_fn("A", Severity.HIGH)])
    d = score.to_dict()
    assert "distinct_risks" in d
    assert "review_needed" in d


def test_counts_field_keeps_raw_totals():
    """The reported per-severity counts must remain raw/unweighted so the
    UI doesn't misrepresent the number of findings."""
    findings = [
        _fn("A", Severity.HIGH, confidence="low"),
        _fn("B", Severity.HIGH, confidence="low"),
        _fn("C", Severity.HIGH, confidence="low"),
    ]
    score = compute_score(findings)
    assert score.counts["HIGH"] == 3


# ---------------------------------------------------------------------------
# Exploitability weighting
# ---------------------------------------------------------------------------


def _fn_expl(rule_id: str, sev: Severity, exploitability: str) -> Finding:
    return Finding(
        rule_id=rule_id,
        severity=sev,
        title=rule_id,
        description="",
        file="x.yml",
        line=1,
        owasp_cicd="CICD-SEC-3",
        finding_family="supply_chain_immutability",
        confidence="high",
        exploitability=exploitability,
    )


def test_low_exploitability_deducts_less_than_high():
    """Same severity + confidence + rule count — low-exploitability
    clusters should score better than high-exploitability clusters.
    """
    # Need enough findings to push past the bonus floor.
    high_expl = [_fn_expl("SEC3-GH-001", Severity.HIGH, "high") for _ in range(20)]
    low_expl = [_fn_expl("SEC3-GH-001", Severity.HIGH, "low") for _ in range(20)]
    # Suppress bonuses in both cases equally
    from taintly.models import Finding
    high_expl.append(Finding(
        rule_id="SEC2-GH-002", severity=Severity.CRITICAL, title="", description="",
        file="x.yml", line=1, owasp_cicd="CICD-SEC-2",
        finding_family="identity_access", confidence="high", exploitability="high",
    ))
    low_expl.append(Finding(
        rule_id="SEC2-GH-002", severity=Severity.CRITICAL, title="", description="",
        file="x.yml", line=1, owasp_cicd="CICD-SEC-2",
        finding_family="identity_access", confidence="high", exploitability="high",
    ))
    assert compute_score(low_expl).total_score > compute_score(high_expl).total_score
