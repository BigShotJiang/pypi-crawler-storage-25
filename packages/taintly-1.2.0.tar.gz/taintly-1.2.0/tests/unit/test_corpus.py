"""Drive the benchmark/corpus_runner as a pytest gate.

Every labeled corpus scenario becomes an individual test — a
precision regression on the intentional-PR-target or hardened
fixtures should land on exactly one failing test, not on a
hand-inspected tool-report diff.
"""

from __future__ import annotations

import pytest

from benchmark.corpus.labels import CORPUS
from benchmark.corpus_runner import _check_one
from taintly.models import Platform
from taintly.rules.registry import load_all_rules


@pytest.fixture(scope="module")
def gh_rules():
    return [r for r in load_all_rules() if r.platform == Platform.GITHUB]


@pytest.mark.parametrize("label", CORPUS, ids=lambda lb: lb.file)
def test_corpus_scenario(label, gh_rules):
    result = _check_one(label, gh_rules)
    assert result.ok, (
        f"Corpus scenario {label.file} drifted from its label "
        f"({label.description}):\n  "
        + "\n  ".join(result.failures)
    )
