r"""Grammar property tests — EXT-D.

## Why this file exists

Hand-curated SAFE samples die at the boundary the curator forgot.
A rule that hard-codes `$CI_COMMIT_MESSAGE` will pass the curated
SAFE samples (they all use known names) and quietly accept any
`'$FOO'` the next maintainer adds, even though the rule's match
depends on the variable name and not on the single-quote shape.

The mutation harness (EXT-C) catches one direction of this: SAFE →
minimally-unsafe by structural mutation. EXT-D catches the other
direction: random *content* substitution that should remain SAFE.
For each safety category whose claim has a clean transformation
family, we generate Hypothesis bodies and assert no rule fires.

Together they form a precision/recall pincer:

  EXT-C: rule must fire when the safety-defining shape is removed.
  EXT-D: rule must NOT fire when the safety-defining shape is kept,
         regardless of what content sits inside it.

A rule that survives both is one that's actually keying on the shape
rather than on coincidental tokens.

## Categories covered in v1

| Category | Property |
|---|---|
| `single_quoted_shell_var` | EXPANSION primitives (`$VAR`, `${VAR}`, `$(...)`, backticks) inside `'...'` never make a rule fire |
| `yaml_comment_lines`      | Arbitrary printable bytes after a leading `#` never make a rule fire |
| `heredoc_quoted_marker`   | EXPANSION primitives inside `<<'EOF' ... EOF` never make a rule fire |
| `groovy_single_quoted`    | Groovy GSTRING-LIKE primitives (`${params.X}`, `${env.Y}`) inside `sh '...'` never make a rule fire — they're not GStrings there |

The `single_quoted` and `heredoc` strategies are deliberately narrowed
to expansion primitives rather than arbitrary text. Some content-smell
rules (e.g. `SEC6-GL-005` matching `chmod\s+777`) legitimately fire on
literal substrings regardless of shell quoting — they're testing a
different claim (the substring is a smell whether quoted or not). The
property "single quotes neutralize all detections" would conflict with
those rules and produce noise. The narrower property "single quotes
neutralize expansion" is what the safety reference actually says.

`static_string_literal` is excluded: its safety claim is the *absence*
of interpolation primitives, which is a negative constraint expensive
to express as a generator without trivially-safe outputs. The mutation
harness (EXT-C) covers it via the PR-title-injection mutator.

`powershell_iex_local_file` is excluded: its safety surface is shape-
bound (the `Get-Content`/`Type` consumer, not the body content), so a
content generator produces little signal. The mutation harness is the
better discriminator there.

## Performance & determinism

Each property is bounded to ~50 examples per run (the default) so the
file adds <1s to the suite. Hypothesis's default deadline is set to
None for these tests because rule evaluation invokes `_safe_search`,
which uses SIGALRM with a 5-second timeout that interacts poorly with
Hypothesis's per-example deadline.

CI uses `--hypothesis-seed=0` (set per-job, not in this file) for
reproducibility on regressions.

## Failure interpretation

A failing property test reports the minimal counter-example
Hypothesis found. Treat it the same as a hand-curated SAFE FP from
the main oracle (per `docs/oracle/DESIGN.md` §CR-5): tighten the
rule, or — if the rule's match is genuinely required for some
broader recall reason — narrow the property's strategy to exclude
the counter-example and document the carve-out as a new finding in
`docs/oracle/FINDINGS.md`.
"""

from __future__ import annotations

import string

from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st

from taintly.models import Rule
from tests.integration.test_grammar_oracle import _rules_that_fire

# Strategy for arbitrary printable YAML-comment content. Used by the
# yaml_comment_lines property where the safety claim is broader (the
# whole line is non-executable, not just expansion neutralisation).
_PRINTABLE_BYTES = st.text(
    alphabet=st.characters(
        min_codepoint=0x20,
        max_codepoint=0x7E,
    ),
    min_size=1,
    max_size=80,
)


# Variable-name strategy: short identifiers, no underscores at start,
# bounded length to avoid colliding with the long predefined CI variable
# names that several rules pattern-match against.
#
# Staged unfilter: the empty frozenset here means "no names are
# protected from Hypothesis generation." The single-quoted /
# yaml-comment / quoted-heredoc properties should hold for ANY
# variable name — a rule that fires on `echo '$SOMETHING'` is
# matching on the name rather than the shape, which POSIX §2.2.2
# (single quotes neutralise expansion) proves is a precision bug.
# Previous runs of this test surfaced SEC4-GL-003's missing
# single-quoted-shell exclude; that's now fixed. Leave this set
# empty so any future rule that reintroduces the same class of bug
# fails the property test instead of silently masking it.
_PROTECTED_VARIABLE_NAMES: frozenset[str] = frozenset()

_var_name = st.text(
    alphabet=string.ascii_letters + string.digits + "_",
    min_size=1,
    max_size=12,
).filter(
    lambda s: s[0].isalpha() and s.upper() not in _PROTECTED_VARIABLE_NAMES
)


@st.composite
def _expansion_primitive(draw) -> str:
    """Generate one shell-expansion primitive: $VAR, ${VAR}, $(VAR), or `VAR`.

    The whole property surface is "single quotes / quoted heredocs
    neutralize expansion." So we generate the things that WOULD expand
    if not wrapped, not arbitrary text.
    """
    style = draw(st.sampled_from(["dollar", "brace", "subshell", "backtick"]))
    var = draw(_var_name)
    if style == "dollar":
        return f"${var}"
    if style == "brace":
        return f"${{{var}}}"
    if style == "subshell":
        return f"$({var})"
    return f"`{var}`"


def _expansion_body() -> st.SearchStrategy[str]:
    """A non-empty sequence of expansion primitives joined by spaces."""
    return st.lists(_expansion_primitive(), min_size=1, max_size=4).map(" ".join)


@st.composite
def _gstring_primitive(draw) -> str:
    """Generate one Groovy-GString-looking primitive: ${params.X}, ${env.Y},
    or ${X}. These are GString interpolations when written in a double-quoted
    Groovy string; inside a single-quoted Groovy string they're literal (per
    the lang spec). The property is "single quotes neutralize ALL of these,
    regardless of the namespace in use."
    """
    style = draw(st.sampled_from(["params", "env", "bare"]))
    var = draw(_var_name)
    if style == "params":
        return f"${{params.{var}}}"
    if style == "env":
        return f"${{env.{var}}}"
    return f"${{{var}}}"


def _gstring_body() -> st.SearchStrategy[str]:
    """A non-empty sequence of Groovy GString primitives joined by spaces,
    with optional static filler words (no single-quote characters, which
    would break the wrapping)."""
    return st.lists(_gstring_primitive(), min_size=1, max_size=3).map(" ".join)


_PROPERTY_SETTINGS = settings(
    max_examples=50,
    deadline=None,  # SIGALRM in _safe_search interacts poorly with deadlines
    suppress_health_check=[HealthCheck.too_slow],
)


@_PROPERTY_SETTINGS
@given(body=_expansion_body())
def test_single_quoted_expansion_body_never_fires_a_rule(
    body: str, loaded_rules: list[Rule]
) -> None:
    """Property: shell-expansion primitives ($VAR, ${VAR}, $(VAR),
    `VAR`) inside `'...'` are literal per POSIX sh §2.2.2. No rule
    should fire on the wrapped form, regardless of which expansion
    primitive or variable name appears in the body.
    """
    sample = f"      - run: echo '{body}'"
    fired, crashed = _rules_that_fire(loaded_rules, sample)
    assert not crashed, (
        f"Rule(s) crashed on Hypothesis-generated single-quoted sample.\n"
        f"  Body: {body!r}\n"
        f"  Crashes: {[(rid, type(e).__name__) for rid, e in crashed]}"
    )
    assert not fired, (
        f"Rule fired on a single-quoted body that POSIX sh §2.2.2 "
        f"says is literal.\n"
        f"  Body:    {body!r}\n"
        f"  Sample:  {sample!r}\n"
        f"  Fired:   {fired}\n"
        f"  The rule's match probably depends on the body content "
        f"rather than on the single-quote wrapping. See the module "
        f"docstring for failure interpretation."
    )


@_PROPERTY_SETTINGS
@given(body=_PRINTABLE_BYTES)
def test_yaml_comment_body_never_fires_a_rule(
    body: str, loaded_rules: list[Rule]
) -> None:
    """Property: any byte sequence after a leading `#` is a YAML
    comment (YAML 1.2 §6.6) and never reaches any executor. No rule
    should fire on a `# <body>` line.
    """
    sample = f"      # {body}"
    fired, crashed = _rules_that_fire(loaded_rules, sample)
    assert not crashed, (
        f"Rule(s) crashed on Hypothesis-generated YAML-comment sample.\n"
        f"  Body: {body!r}\n"
        f"  Crashes: {[(rid, type(e).__name__) for rid, e in crashed]}"
    )
    assert not fired, (
        f"Rule fired on a YAML-comment body that YAML 1.2 §6.6 says "
        f"is non-executable.\n"
        f"  Body:    {body!r}\n"
        f"  Sample:  {sample!r}\n"
        f"  Fired:   {fired}\n"
        f"  The rule's match probably ignores the # comment marker; "
        f"see the module docstring for failure interpretation."
    )


@_PROPERTY_SETTINGS
@given(
    body_lines=st.lists(_expansion_body(), min_size=1, max_size=4),
)
def test_quoted_heredoc_expansion_body_never_fires_a_rule(
    body_lines: list[str], loaded_rules: list[Rule]
) -> None:
    """Property: shell-expansion primitives inside `<<'EOF' ... EOF`
    are unexpanded per Bash manual §3.6.6. No rule should fire on the
    wrapped form, regardless of which expansion primitive or variable
    name appears in the body lines.
    """
    body = "\n".join(f"          {line}" for line in body_lines)
    sample = (
        "      - run: |\n"
        "          cat <<'EOF'\n"
        f"{body}\n"
        "          EOF"
    )
    fired, crashed = _rules_that_fire(loaded_rules, sample)
    assert not crashed, (
        f"Rule(s) crashed on Hypothesis-generated heredoc sample.\n"
        f"  Body lines: {body_lines!r}\n"
        f"  Crashes:    {[(rid, type(e).__name__) for rid, e in crashed]}"
    )
    assert not fired, (
        f"Rule fired on a quoted-heredoc body that Bash manual §3.6.6 "
        f"says is unexpanded.\n"
        f"  Body lines: {body_lines!r}\n"
        f"  Sample:\n{sample}\n"
        f"  Fired:      {fired}\n"
        f"  The rule's match probably ignores the heredoc-marker "
        f"quoting; see the module docstring for failure interpretation."
    )


@_PROPERTY_SETTINGS
@given(body=_gstring_body())
def test_groovy_single_quoted_gstring_body_never_fires_a_rule(
    body: str, loaded_rules: list[Rule]
) -> None:
    """Property: Groovy GString-looking interpolations (${params.X},
    ${env.Y}, ${X}) inside single-quoted strings are LITERAL per the
    Groovy lang spec — single-quoted literals are java.lang.String, not
    GString. No rule should fire on a Groovy single-quoted `sh '...'`
    containing these tokens, regardless of which namespace they name.
    """
    sample = f"        sh '{body}'"
    fired, crashed = _rules_that_fire(loaded_rules, sample)
    assert not crashed, (
        f"Rule(s) crashed on Hypothesis-generated Groovy single-quoted sample.\n"
        f"  Body: {body!r}\n"
        f"  Crashes: {[(rid, type(e).__name__) for rid, e in crashed]}"
    )
    assert not fired, (
        f"Rule fired on a Groovy single-quoted body that the Groovy lang "
        f"spec says is literal (java.lang.String, not GString).\n"
        f"  Body:    {body!r}\n"
        f"  Sample:  {sample!r}\n"
        f"  Fired:   {fired}\n"
        f"  The rule's match probably ignores the outer quote style; "
        f"see the module docstring for failure interpretation."
    )
