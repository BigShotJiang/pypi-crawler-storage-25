"""Gate: real-world regression corpus — fixtures derived from public
workflows that exhibit specific detection shapes.

When this test fails, either:
  (a) a rule tweak silenced a finding that SHOULD fire (regression) —
      investigate; or
  (b) a rule tweak caused a forbidden rule to fire — investigate; or
  (c) the fixture intentionally no longer represents the shape it
      used to.  Update ``benchmark/real_world/labels.py`` and explain
      in the commit message.

Do not silence this gate by deleting fixtures or relaxing labels
without a concrete regression analysis.
"""

from __future__ import annotations

import pytest

from benchmark.real_world.runner import run_regression


def test_real_world_regression_corpus() -> None:
    """Every fixture's declared ``expected_rule_ids`` must fire and its
    ``forbidden_rule_ids`` must not. See ``benchmark/real_world/labels.py``.
    """
    all_passed, results = run_regression()
    if all_passed:
        return

    lines = ["Real-world regression drift detected:\n"]
    for r in results:
        if r.passed:
            continue
        lines.append(f"  [{r.fixture.path}] {r.fixture.description}")
        if r.missing_expected:
            lines.append(
                "    MISSING (expected but did not fire): "
                + ", ".join(sorted(r.missing_expected))
            )
        if r.firing_forbidden:
            lines.append(
                "    EXTRA (fired but was forbidden): "
                + ", ".join(sorted(r.firing_forbidden))
            )
        lines.append(
            "    actual: "
            + (", ".join(sorted(r.actual_rule_ids)) if r.actual_rule_ids else "(none)")
        )
    lines.append("")
    lines.append("See tests/integration/test_real_world_regression.py for fix guidance.")
    pytest.fail("\n".join(lines))


def test_every_fixture_file_exists() -> None:
    """Each ``Fixture`` entry must point to an on-disk file."""
    from pathlib import Path

    from benchmark.real_world.labels import FIXTURES

    fixtures_dir = (
        Path(__file__).resolve().parents[2]
        / "benchmark"
        / "real_world"
        / "fixtures"
    )
    missing = [f.path for f in FIXTURES if not (fixtures_dir / f.path).is_file()]
    assert not missing, (
        f"Fixture files missing on disk (declared in labels.py): {missing}"
    )


def test_every_fixture_cites_source() -> None:
    """Every fixture file must carry an attribution header citing the
    upstream repo.  Prevents accidental shipment of a fixture without
    license / source provenance."""
    from pathlib import Path

    from benchmark.real_world.labels import FIXTURES

    fixtures_dir = (
        Path(__file__).resolve().parents[2]
        / "benchmark"
        / "real_world"
        / "fixtures"
    )
    missing_citation: list[str] = []
    for f in FIXTURES:
        content = (fixtures_dir / f.path).read_text()
        # First ~15 lines must mention the source repo via
        # ``github.com/<owner>/<repo>`` or a ``derived from:`` phrase.
        header = "\n".join(content.splitlines()[:15]).lower()
        if "derived from" not in header and "github.com/" not in header:
            missing_citation.append(f.path)
    assert not missing_citation, (
        "Fixtures missing source citation in their first 15 lines: "
        f"{missing_citation}"
    )
