"""Grammar mutation harness — EXT-C.

## Why this file exists

The main oracle (`test_grammar_oracle.py`) asks two questions:

  1. Does any rule fire on a SAFE sample? (precision check)
  2. Does at least one expected rule fire on an UNSAFE sample? (recall check)

Both questions are sample-bound. Neither tells us whether the rule is
actually discriminating between SAFE and UNSAFE *shapes* — it could
be matching on a coincidental token (a CI variable name, a path, a
keyword) that happens to appear in the UNSAFE corpus and not in the
SAFE corpus, and we'd never notice as long as the corpora stayed put.

Mutation testing closes that gap. For each SAFE sample, we apply a
minimal transformation that should flip its safety claim. The same
test asserts that the rule set DOES fire on the mutant. That gives a
discrimination signal:

  rule fires on UNSAFE corpus  ✓ (existing oracle test)
  rule does NOT fire on SAFE corpus  ✓ (existing oracle test)
  rule fires on SAFE-corpus + minimal-unsafe-mutation  ✓ (this file)

If the third check fails while the first two pass, the rule is
matching on something OTHER than the shape feature — exactly the
"matches the variable name, not the shape" precision bug the audit
called out.

## What counts as a "minimal unsafe mutation"

A mutation is the smallest syntactic change that flips the language-
semantic safety claim. Examples:

| Category | Mutation |
|---|---|
| `single_quoted_shell_var` | strip the surrounding `'` → unquoted var |
| `double_quoted_shell_var_passed_to_echo` | strip the surrounding `"` → unquoted var |
| `yaml_comment_lines` | strip the leading `#` → uncommented active line |
| `heredoc_quoted_marker` | change `<<'EOF'` to `<<EOF` → expansion enabled |
| `groovy_single_quoted` | change outer `'` to `"` → GString interpolation |

A mutator returns either the mutated source string or `None` if the
mutation doesn't apply to the sample (e.g. a Groovy mutator on a
sample with no `${...}` body has nothing to flip).

## What this file deliberately does NOT do

- We do NOT generate samples randomly. Hypothesis-style fuzzing is a
  separate extension (EXT-D) with different runtime characteristics.
- We do NOT mutate UNSAFE samples. The interesting direction is
  SAFE → UNSAFE; the reverse ("can the rule miss this if we make it
  safer?") is exactly what the SAFE corpus already tests.
- We do NOT assert which rule fires on the mutant. The mutation only
  tests that the rule set discriminates; rule attribution is the
  inverse-index test (EXT-B), not this one.

## Adding a new mutator

1. Pick a SAFE category whose safety claim has a clean syntactic
   inverse (the body of the safety claim points to one or two bytes
   whose presence MAKES it safe).
2. Write a mutator function that takes the sample source and returns
   the mutated source, or `None` if the mutation doesn't apply.
3. Add the mutator to `_MUTATORS`.
4. Run `pytest tests/integration/test_grammar_oracle_mutations.py`.
   The mutated samples should trigger at least one rule. If they
   don't, either the rule set has a precision gap (good — the test
   surfaced it) or the mutation isn't actually unsafe (rare — fix
   the mutator).
"""

from __future__ import annotations

import re
from collections.abc import Callable

import pytest

from taintly.models import Rule
from tests.integration.test_grammar_oracle import (
    SAFE_BY_CONSTRUCTION,
    Sample,
    _rules_that_fire,
)

# A mutator takes the raw sample source and returns either the mutated
# source string or None (mutation does not apply to this sample).
Mutator = Callable[[str], str | None]


def _strip_single_quotes_around_var(source: str) -> str | None:
    """Strip `'...'` around a `$VAR` reference → unquoted var."""
    # Match the smallest 'X' span that contains a $-reference.
    pattern = re.compile(r"'([^']*\$[^']*)'")
    if not pattern.search(source):
        return None
    return pattern.sub(r"\1", source, count=1)


def _strip_double_quotes_around_var(source: str) -> str | None:
    """Strip `"..."` around a `$VAR` reference → unquoted var."""
    pattern = re.compile(r'"([^"]*\$[^"]*)"')
    if not pattern.search(source):
        return None
    return pattern.sub(r"\1", source, count=1)


def _uncomment_yaml_line(source: str) -> str | None:
    """Remove the leading `#` from a YAML-comment line → active code."""
    # Match the first line beginning with optional whitespace then `#`.
    pattern = re.compile(r"^(\s*)#\s?", re.MULTILINE)
    if not pattern.search(source):
        return None
    return pattern.sub(r"\1", source, count=1)


def _unquote_heredoc_marker(source: str) -> str | None:
    """Change `<<'EOF'` / `<<"EOF"` / `<<\\EOF` to `<<EOF` → expansion enabled."""
    # Order matters: try the explicit-quote forms first, then the backslash form.
    for pattern in (
        re.compile(r"<<'([A-Za-z_][A-Za-z0-9_]*)'"),
        re.compile(r'<<"([A-Za-z_][A-Za-z0-9_]*)"'),
        re.compile(r"<<\\([A-Za-z_][A-Za-z0-9_]*)"),
    ):
        if pattern.search(source):
            return pattern.sub(r"<<\1", source, count=1)
    return None


def _groovy_single_to_double_quotes(source: str) -> str | None:
    """Change outer `'...'` to `"..."` in a Groovy `sh '...'` call.

    Only applies when the body contains `${...}` — without an
    interpolation primitive there's no GString surface to expose.
    """
    pattern = re.compile(r"sh\s+'([^']*\$\{[^']*\})[^']*'")
    if not pattern.search(source):
        return None
    return re.sub(
        r"sh\s+'([^']*)'",
        lambda m: f'sh "{m.group(1)}"',
        source,
        count=1,
    )


def _inject_pr_title_into_static(source: str) -> str | None:
    """Inject `${{ github.event.pull_request.title }}` into a static-literal
    `run:` step. The original's safety claim is "no interpolation primitives";
    the mutation introduces the canonical GitHub Actions PR-title injection
    sink, which SEC4-GH-004 should fire on.

    Applied to samples matching the `- run: <command> <args>` shape;
    other static-literal shapes (commented-out lines, non-shell commands
    like `- uses:`) are passed through as None since the injection point
    isn't well-defined for them.
    """
    pattern = re.compile(r"^(\s*- run: )(.+)$", re.MULTILINE)
    match = pattern.search(source)
    if not match:
        return None
    prefix, rest = match.group(1), match.group(2)
    injected = f"{prefix}echo ${{{{ github.event.pull_request.title }}}} {rest}"
    return source[: match.start()] + injected + source[match.end() :]


_MUTATORS: dict[str, Mutator] = {
    "single_quoted_shell_var": _strip_single_quotes_around_var,
    "double_quoted_shell_var_passed_to_echo": _strip_double_quotes_around_var,
    "yaml_comment_lines": _uncomment_yaml_line,
    "heredoc_quoted_marker": _unquote_heredoc_marker,
    "groovy_single_quoted": _groovy_single_to_double_quotes,
    "static_string_literal": _inject_pr_title_into_static,
}


# Known mutation-coverage gaps. Keyed by (category, sample_index). The
# value is an xfail-strict reason. When the underlying rule is fixed and
# the mutation starts triggering, the strict xfail flips to XPASS and
# the build fails — prompting removal of the entry. See
# docs/oracle/FINDINGS.md for each entry's narrative.
_KNOWN_MUTATION_GAPS: dict[tuple[str, int], str] = {
    # Empty: all F-5 mutation gaps closed in step #5 of the audit-
    # follow-up chain. heredoc_quoted_marker[1]/[2] switched to using
    # $CI_COMMIT_MESSAGE so SEC4-GL-001 triggers on the unquoted-
    # heredoc mutation; single_quoted_shell_var[2] is now covered by
    # SEC4-GH-018 (new rule targeting GitHub auto-populated env vars
    # in unquoted shell context).
}


def _mutation_params():
    """Yield (category, sample_index, original_source, mutated_source) for
    every (category, sample) pair where the category has a mutator AND the
    mutator applies to the sample. Known precision-gap mutations are
    decorated with xfail-strict per `_KNOWN_MUTATION_GAPS`.
    """
    for category, mutator in _MUTATORS.items():
        samples = SAFE_BY_CONSTRUCTION.get(category, [])
        for index, sample in enumerate(samples):
            mutated = mutator(sample.source)
            if mutated is None or mutated == sample.source:
                continue
            marks = []
            xfail_reason = _KNOWN_MUTATION_GAPS.get((category, index))
            if xfail_reason:
                marks.append(pytest.mark.xfail(strict=True, reason=xfail_reason))
            yield pytest.param(
                category, index, sample, mutated,
                marks=marks,
                id=f"{category}-{index}",
            )


@pytest.mark.parametrize(
    ("category", "index", "sample", "mutated"),
    list(_mutation_params()),
)
def test_minimal_unsafe_mutation_triggers_some_rule(
    category: str,
    index: int,
    sample: Sample,
    mutated: str,
    loaded_rules: list[Rule],
) -> None:
    """For each SAFE sample, the minimal-unsafe-mutation MUST trigger at
    least one rule.

    Failure means the rule set isn't discriminating between safe and
    unsafe shapes within this category — it's matching on something
    that survives the mutation (a variable name, a keyword, a path)
    rather than on the shape feature that distinguishes safe from
    unsafe. That's a precision-gap signal: the same rule that
    correctly didn't fire on the SAFE sample now incorrectly doesn't
    fire on its UNSAFE mutation.
    """
    fired, crashed = _rules_that_fire(loaded_rules, mutated, sample.platform)
    assert not crashed, (
        f"Rule(s) crashed on mutated sample — scanner-robustness bug.\n"
        f"  Category: {category}[{index}]\n"
        f"  Original: {sample.source!r}\n"
        f"  Mutated:  {mutated!r}\n"
        f"  Crashes:  {[(rid, type(e).__name__) for rid, e in crashed]}"
    )
    assert fired, (
        f"Mutation did not trigger any rule — precision-gap signal.\n"
        f"  Category: {category}[{index}]\n"
        f"  Original: {sample.source!r}  (SAFE; no rule fires — correct)\n"
        f"  Mutated:  {mutated!r}        (UNSAFE; should fire — does not)\n"
        f"  The rule set is not discriminating between this category's\n"
        f"  safe and unsafe shapes; its match probably depends on a\n"
        f"  token that survived the mutation (variable name, keyword,\n"
        f"  path) rather than on the shape feature itself.\n"
        f"  See test_grammar_oracle_mutations.py module docstring."
    )
