"""End-to-end integration tests for documented CI patterns.

These tests invoke the scanner as a subprocess — exactly as a CI job
would — so the patterns described in docs/INTEGRATION.md are
continuously verified. If a change to __main__.py breaks the
baseline/diff contract, SARIF output, or the `--fail-on` exit-code
model, one of these tests fails.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

# =============================================================================
# Fixtures
# =============================================================================


def _run_audit(tmp_path: Path, *args: str) -> subprocess.CompletedProcess[str]:
    """Invoke the CLI at the repo path, capturing output + exit code."""
    return subprocess.run(
        [sys.executable, "-m", "taintly", str(tmp_path), "--no-color", *args],
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )


@pytest.fixture
def vulnerable_repo(tmp_path: Path) -> Path:
    """A tmp repo with a single HIGH-severity workflow (unpinned action)."""
    workflows = tmp_path / ".github" / "workflows"
    workflows.mkdir(parents=True)
    (workflows / "ci.yml").write_text(
        "name: ci\n"
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 5\n"
        "    steps:\n"
        "      - uses: actions/checkout@v4\n"
        "      - run: echo hi\n",
        encoding="utf-8",
    )
    return tmp_path


@pytest.fixture
def clean_repo(tmp_path: Path) -> Path:
    """A tmp repo whose workflow should produce zero findings."""
    workflows = tmp_path / ".github" / "workflows"
    workflows.mkdir(parents=True)
    (workflows / "ci.yml").write_text(
        "name: ci\n"
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 5\n"
        "    steps:\n"
        "      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2\n"
        "        with:\n"
        "          persist-credentials: false\n"
        "      - run: echo hi\n",
        encoding="utf-8",
    )
    return tmp_path


# =============================================================================
# Exit-code contract (INTEGRATION.md §"Exit code reference")
# =============================================================================


def test_exit_zero_on_clean_repo(clean_repo: Path) -> None:
    """A repo with no HIGH+ findings must exit 0 even with the default
    fail-on behaviour. If this ever breaks, every downstream CI that
    depends on the no-findings-means-green contract fails silently.
    """
    result = _run_audit(clean_repo, "--fail-on", "HIGH")
    assert result.returncode == 0, (
        f"clean repo exited {result.returncode}:\n{result.stdout}\n{result.stderr}"
    )


def test_exit_one_on_high_finding(vulnerable_repo: Path) -> None:
    """Unpinned action fires SEC3-GH-001 (HIGH). Exit code must be 1."""
    result = _run_audit(vulnerable_repo, "--fail-on", "HIGH")
    assert result.returncode == 1, (
        f"expected 1 for HIGH finding, got {result.returncode}:\n{result.stdout}"
    )
    assert "SEC3-GH-001" in result.stdout


def test_fail_on_medium_escalates_below_builtin_threshold(tmp_path: Path) -> None:
    """`--fail-on` escalates the severity at which the scanner fails.
    Built-in behaviour is CRITICAL=2, HIGH=1, else 0 — so a MEDIUM-only
    finding exits 0 without `--fail-on`, but should exit 1 with
    `--fail-on MEDIUM`. Verifies the flag is actually wired through the
    composite action's `fail-on` input.
    """
    workflows = tmp_path / ".github" / "workflows"
    workflows.mkdir(parents=True)
    # Fully pinned, fully hardened except for one MEDIUM issue: no
    # top-level permissions block (SEC2-GH-002).
    (workflows / "ci.yml").write_text(
        "name: ci\n"
        "on: push\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 5\n"
        "    steps:\n"
        "      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2\n"
        "        with:\n"
        "          persist-credentials: false\n"
        "      - run: echo hi\n",
        encoding="utf-8",
    )

    default = _run_audit(tmp_path)
    assert default.returncode == 0, (
        f"MEDIUM-only findings should exit 0 by default; got {default.returncode}\n"
        f"{default.stdout}"
    )

    escalated = _run_audit(tmp_path, "--fail-on", "MEDIUM")
    assert escalated.returncode == 1, (
        f"--fail-on MEDIUM should exit 1 on a MEDIUM finding; got "
        f"{escalated.returncode}\n{escalated.stdout}"
    )


# =============================================================================
# Baseline + diff contract (INTEGRATION.md §2)
# =============================================================================


def test_baseline_then_diff_suppresses_existing_findings(vulnerable_repo: Path) -> None:
    """Snapshot the current findings into a baseline, then verify that
    --diff suppresses them and exits 0. This is the onboarding path
    for legacy repos: we must not break it.
    """
    baseline = vulnerable_repo / ".taintly-baseline.json"

    # Step 1: snapshot — this write should always succeed even when
    # findings exist (the scanner does not fail-on during baselining).
    snapshot = _run_audit(vulnerable_repo, "--baseline", str(baseline))
    assert snapshot.returncode == 0, (
        f"baseline write failed ({snapshot.returncode}):\n{snapshot.stderr}"
    )
    assert baseline.exists()
    payload = json.loads(baseline.read_text())
    assert payload["version"] == 1
    assert len(payload["fingerprints"]) >= 1

    # Step 2: re-scan with --diff; all findings should be in the baseline.
    diff = _run_audit(vulnerable_repo, "--diff", str(baseline), "--fail-on", "HIGH")
    assert diff.returncode == 0, (
        f"--diff against a fresh baseline must suppress every finding; "
        f"got exit {diff.returncode}:\n{diff.stdout}"
    )


def test_diff_reports_new_findings_only(vulnerable_repo: Path) -> None:
    """Baseline the current state, introduce a NEW finding, and verify
    --diff reports only the new one (and fails the build)."""
    baseline = vulnerable_repo / ".taintly-baseline.json"
    _run_audit(vulnerable_repo, "--baseline", str(baseline))

    # Add a second unpinned action — a NEW finding on a different line
    # and a different action, so the fingerprint is guaranteed to miss
    # the baseline entry.
    (vulnerable_repo / ".github" / "workflows" / "ci.yml").write_text(
        "name: ci\n"
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 5\n"
        "    steps:\n"
        "      - uses: actions/checkout@v4\n"
        "      - uses: actions/setup-python@v5\n"   # new unpinned action
        "      - run: echo hi\n",
        encoding="utf-8",
    )

    diff = _run_audit(vulnerable_repo, "--diff", str(baseline), "--fail-on", "HIGH")
    assert diff.returncode == 1, (
        f"--diff must fail when NEW finding appears; got exit {diff.returncode}:"
        f"\n{diff.stdout}"
    )
    assert "setup-python" in diff.stdout, (
        f"new finding should reference setup-python:\n{diff.stdout}"
    )


# =============================================================================
# SARIF output shape (INTEGRATION.md §1)
# =============================================================================


def test_sarif_output_is_valid_json_with_runs(vulnerable_repo: Path) -> None:
    """GitHub's upload-sarif action rejects malformed SARIF. Verify
    the top-level shape matches the SARIF 2.1.0 contract."""
    result = _run_audit(vulnerable_repo, "--format", "sarif")
    assert result.returncode == 1  # HIGH finding -> exit 1
    doc = json.loads(result.stdout)
    assert doc["$schema"].endswith(".json"), "SARIF $schema missing"
    assert doc["version"] == "2.1.0"
    assert isinstance(doc["runs"], list) and len(doc["runs"]) >= 1

    run = doc["runs"][0]
    assert run["tool"]["driver"]["name"]
    assert isinstance(run["results"], list)
    # At least one result with a rule-id (the unpinned action).
    assert any(r.get("ruleId", "").startswith("SEC3-GH-") for r in run["results"]), (
        f"expected a SEC3-GH-* result in SARIF:\n{json.dumps(run['results'], indent=2)}"
    )


# =============================================================================
# Exclude-rule pass-through (INTEGRATION.md §3)
# =============================================================================


def test_exclude_rule_suppresses_finding(vulnerable_repo: Path) -> None:
    """--exclude-rule SEC3-GH-001 must suppress the unpinned-action
    finding and flip the build green. This is the mechanism the action's
    `exclude-rules` input relies on."""
    result = _run_audit(
        vulnerable_repo, "--exclude-rule", "SEC3-GH-001", "--fail-on", "HIGH"
    )
    assert result.returncode == 0, (
        f"excluded rule still produced a finding:\n{result.stdout}"
    )
    assert "SEC3-GH-001" not in result.stdout


# =============================================================================
# GitLab CI — SAST report artefact contract (INTEGRATION.md §5)
# =============================================================================


@pytest.fixture
def vulnerable_gitlab_repo(tmp_path: Path) -> Path:
    """A .gitlab-ci.yml that triggers a HIGH GitLab-platform finding."""
    (tmp_path / ".gitlab-ci.yml").write_text(
        # User-controlled CI_COMMIT_BRANCH unquoted in a shell script —
        # SEC4-GL-001 (HIGH). Keeps the fixture small without pulling
        # in a remote include.
        "stages: [test]\n"
        "\n"
        "build:\n"
        "  stage: test\n"
        "  image: python:3.12\n"
        "  script:\n"
        "    - echo $CI_COMMIT_BRANCH\n"
        "    - deploy.sh $CI_COMMIT_BRANCH\n",
        encoding="utf-8",
    )
    return tmp_path


def test_gitlab_scan_produces_sast_compatible_sarif(
    vulnerable_gitlab_repo: Path,
) -> None:
    """The SARIF output written by the scanner must conform to the
    SARIF 2.1.0 shape GitLab expects at `artifacts.reports.sast`.
    Run on a GitLab-only repo so we also exercise the platform
    auto-detection path that the templates depend on.
    """
    result = _run_audit(vulnerable_gitlab_repo, "--format", "sarif")
    # SEC4-GL-001 is HIGH so exit 1 is expected.
    assert result.returncode == 1, (
        f"GitLab scan should exit 1 on HIGH finding; got {result.returncode}"
    )
    doc = json.loads(result.stdout)
    assert doc["version"] == "2.1.0"
    run = doc["runs"][0]
    assert run["tool"]["driver"]["name"]
    # Platform auto-detection must fire a GitLab-platform rule here.
    assert any(r.get("ruleId", "").startswith("SEC4-GL-") for r in run["results"]), (
        f"expected a SEC4-GL-* finding — auto-detect may be broken:\n"
        f"{json.dumps(run['results'], indent=2)}"
    )


def test_gitlab_platform_flag_forces_gitlab_only(tmp_path: Path) -> None:
    """When --platform gitlab is set on a dual-platform repo, only
    GitLab findings come out. Verifies the composite Action / Component
    `platform:` input actually narrows the scan.
    """
    # Both a GitHub workflow and a GitLab CI file in the same repo.
    (tmp_path / ".github" / "workflows").mkdir(parents=True)
    (tmp_path / ".github" / "workflows" / "ci.yml").write_text(
        "on: push\njobs:\n  b:\n    runs-on: ubuntu-latest\n"
        "    steps: [{ uses: actions/checkout@v4 }]\n",
        encoding="utf-8",
    )
    (tmp_path / ".gitlab-ci.yml").write_text(
        "build:\n  script:\n    - deploy.sh $CI_COMMIT_BRANCH\n",
        encoding="utf-8",
    )

    result = _run_audit(tmp_path, "--platform", "gitlab", "--format", "sarif")
    doc = json.loads(result.stdout)
    rule_ids = {r.get("ruleId", "") for r in doc["runs"][0]["results"]}
    # No GitHub findings should appear when platform is forced to gitlab.
    gh_hits = {r for r in rule_ids if r.startswith("SEC") and "-GH-" in r}
    assert not gh_hits, (
        f"--platform gitlab leaked GitHub findings: {sorted(gh_hits)}"
    )


# =============================================================================
# Jenkins — one-liner platform override path
# =============================================================================


def test_jenkins_platform_override_scans_jenkinsfile(tmp_path: Path) -> None:
    """INTEGRATION.md §5e claims `--platform jenkins` works from a
    GitLab job that points at a Jenkinsfile. Lock in the behaviour so
    the doc stays honest.
    """
    (tmp_path / "Jenkinsfile").write_text(
        # SEC4-JK-001 (HIGH) — double-quoted GString interpolates params
        # directly into an sh step, the classic Jenkins command-injection
        # shape.
        "pipeline {\n"
        "  agent any\n"
        "  parameters { string(name: 'BRANCH', defaultValue: 'main') }\n"
        "  stages {\n"
        '    stage("deploy") {\n'
        "      steps {\n"
        '        sh "deploy ${params.BRANCH}"\n'
        "      }\n"
        "    }\n"
        "  }\n"
        "}\n",
        encoding="utf-8",
    )

    result = _run_audit(tmp_path, "--platform", "jenkins", "--fail-on", "HIGH")
    assert result.returncode == 1, (
        f"Jenkinsfile with unsafe sh should exit 1; got {result.returncode}:\n"
        f"{result.stdout}"
    )
    assert "SEC4-JK-001" in result.stdout


# =============================================================================
# Component / template files — YAML shape smoke tests
#
# These tests make sure the Component / include templates shipped in
# templates/ parse as valid YAML and declare the documented inputs.
# They don't execute GitLab's pipeline engine (that's out of scope), but
# they catch the class of bug where a template syntax error silently
# breaks every consumer until someone tries it.
# =============================================================================


def test_gitlab_component_template_declares_documented_inputs() -> None:
    """templates/taintly/template.yml must declare each input the
    README and INTEGRATION.md promise.
    """
    component_path = (
        Path(__file__).parent.parent.parent / "templates" / "taintly" / "template.yml"
    )
    content = component_path.read_text()
    # spec: + inputs: headers present.
    assert "spec:" in content
    assert "inputs:" in content
    # Each documented input.
    for input_name in (
        "stage:",
        "job-name:",
        "path:",
        "fail-on:",
        "min-severity:",
        "platform:",
        "baseline:",
        "baseline-file:",
        "version:",
        "image:",
        "upload-sarif:",
        "extra-args:",
    ):
        assert input_name in content, f"component template missing input: {input_name}"


def test_gitlab_include_template_exports_hidden_job() -> None:
    """The flat include template uses a hidden-job template (`.taintly:`)
    that consumers `extends:` — verify the idiomatic pattern is in place
    so users copying the README recipe work unchanged.
    """
    path = (
        Path(__file__).parent.parent.parent / "templates" / "taintly.gitlab-ci.yml"
    )
    content = path.read_text()
    assert ".taintly:" in content, "hidden-job template missing — `extends:` will fail"
    assert "artifacts:" in content
    # SAST report integration is the headline feature.
    assert "sast: gl-sast-report.json" in content
