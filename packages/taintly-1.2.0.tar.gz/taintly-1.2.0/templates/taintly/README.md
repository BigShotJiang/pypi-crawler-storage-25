# taintly — GitLab CI/CD Component

Scan `.gitlab-ci.yml`, `.github/workflows/*.yml`, and `Jenkinsfile` for pipeline-security issues. One-line consumption.

> **GitLab 16.11+** required for `spec.inputs:`. For older GitLab, use `templates/taintly.gitlab-ci.yml` via plain `include: project:` — same capability, simpler substitution.

## Quick start

```yaml
# .gitlab-ci.yml
include:
  - component: $CI_SERVER_FQDN/<group>/taintly/taintly@v1
    inputs:
      fail-on: HIGH
```

That single include registers a job that:

- Installs the latest `taintly` from PyPI at the pinned version spec
- Scans the repo (defaults to `.`)
- Exits non-zero on HIGH or CRITICAL findings
- Writes `gl-sast-report.json` so findings appear in the **MR widget** and the **Security dashboard**
- Runs on MRs, on pushes to the default branch, and on scheduled pipelines

## Common patterns

### Baseline + diff (adopting on a legacy project)

```bash
# One-time maintainer step:
pip install git+https://github.com/Nellur35/taintly@v1
taintly . --baseline .taintly-baseline.json
git add .taintly-baseline.json && git commit -m "Baseline taintly"
```

```yaml
include:
  - component: $CI_SERVER_FQDN/<group>/taintly/taintly@v1
    inputs:
      fail-on: HIGH
      baseline: true
```

### Dual-platform repo (both `.github/` and `.gitlab-ci.yml`)

Include the component twice with different `platform:` inputs:

```yaml
include:
  - component: $CI_SERVER_FQDN/<group>/taintly/taintly@v1
    inputs:
      job-name: "taintly-gitlab"
      platform: gitlab
  - component: $CI_SERVER_FQDN/<group>/taintly/taintly@v1
    inputs:
      job-name: "taintly-github"
      platform: github
```

### Custom stage / schedule

```yaml
include:
  - component: $CI_SERVER_FQDN/<group>/taintly/taintly@v1
    inputs:
      stage: security        # must exist in your `stages:` list
      fail-on: HIGH
```

### Extra flags

```yaml
include:
  - component: $CI_SERVER_FQDN/<group>/taintly/taintly@v1
    inputs:
      extra-args: "--transitive --score"
```

## Inputs

| Input | Type | Default | Purpose |
|---|---|---|---|
| `stage` | string | `test` | Pipeline stage (must exist in `stages:`) |
| `job-name` | string | `taintly` | Override to include the component twice |
| `path` | string | `.` | Repo root or workflow dir |
| `fail-on` | enum | `HIGH` | Severity that fails the pipeline |
| `min-severity` | enum | `INFO` | Suppress findings below this level |
| `platform` | enum | (auto) | `github` / `gitlab` / `jenkins` |
| `baseline` | boolean | `false` | Enable `--diff` mode |
| `baseline-file` | string | `.taintly-baseline.json` | Baseline path |
| `version` | string | `>=1.0,<2` | pip version spec |
| `image` | string | pinned digest | Container image |
| `upload-sarif` | boolean | `true` | Write `gl-sast-report.json` artefact |
| `extra-args` | string | — | Raw CLI arguments passed through |

## Outputs

The job writes `gl-sast-report.json` (SARIF 2.1.0) as a GitLab SAST report artefact. GitLab auto-ingests this and surfaces findings in:

- The merge-request widget
- **Security & Compliance → Vulnerability report**
- **Security & Compliance → Security dashboard** (Ultimate tier)

## Exit-code semantics

| Code | Meaning |
|---|---|
| 0 | No findings, or max severity below `fail-on` |
| 1 | HIGH finding, or `fail-on` threshold reached |
| 2 | CRITICAL finding |
| 3 | Token / config error |

`fail-on` only **escalates** — setting `fail-on: CRITICAL` does **not** suppress HIGH-level gating (built-in HIGH=1 always applies). To drop a specific finding, use `--exclude-rule` via `extra-args` or commit a `.taintly.yml` with a justified `ignore:` entry.

## Pinning discipline

The default `image:` is pinned by digest. Consumers should:

1. Pin the **component ref** narrowly: `...@v1.2.3`, not `@main`.
2. Update the pin via scheduled Dependabot / Renovate bumps, not manual drift.
3. Keep `version:` narrowed (default `>=0.1,<1` gets bug fixes, blocks breaking majors).

See the project's own `docs/INTEGRATION.md` for the full integration playbook.

## Links

- Source: https://github.com/Nellur35/taintly
- Full integration guide: `docs/INTEGRATION.md`
- Rule reference: `docs/RULES.md`
