# Semantic grammar oracle — Requirements

## Problem

Rules in `taintly` are validated by samples the **rule author** writes into
`Rule.test_positive` / `Rule.test_negative`. That's a test contract with an
oracle-preservation pathology: a rule author who *incorrectly believes* a
given shape is dangerous puts it in `test_positive`; the rule fires on it by
construction; the mutation tests pass because the rule's behaviour matches
what the author said it should do; and the bug survives until an external
audit.

Three such bugs landed in PR #27 ("Fix audit regressions") alone:

| Rule | Bug | Cost of discovery |
|---|---|---|
| `SEC4-JK-001` | Fired on single-quoted Groovy `sh '...'`; single quotes suppress GString interpolation, so `${params.X}` is literal. The rule's own `test_positive` had `sh 'docker build -t ${params.IMAGE_TAG} .'` — the false positive was baked into the contract. | External audit |
| `SEC4-GL-001` | Excluded double-quoted `"$CI_COMMIT_MESSAGE"` in shell but not single-quoted `'$CI_COMMIT_MESSAGE'`; shell doesn't expand `$VAR` in single quotes either. | External audit |
| `SEC6-GH-007` | The `iex(...)` branch fired on any PowerShell `Invoke-Expression`, including `iex (Get-Content ./local.ps1)` which has no remote fetch. | External audit |

All three share the shape: **rule author's intuition about safe-vs-unsafe
got encoded into `test_positive` and was never challenged from the
outside.**

## What we need

A test whose "what's safe" assertion comes from a **different source** than
the rule suite. Specifically: a curated grammar of YAML / Groovy / shell
fragments whose safe-or-unsafe status is knowable from language semantics
alone, independent of what rules happen to exist.

The test then asks two inverted questions the current harness does not ask:

1. **FP contract** — for every `SAFE_BY_CONSTRUCTION` sample, no rule
   anywhere in the registry may fire.
2. **FN contract** — for every `UNSAFE_BY_CONSTRUCTION` sample, at least
   one rule must fire.

A failure of (1) is a false positive the rule author didn't see coming. A
failure of (2) is a recall gap the rule author didn't know they had.

## Functional requirements

### FR-1 — Independence of grammar from rules

Grammar samples MUST be defensible by reference to language semantics (shell
quoting rules, Groovy GString behaviour, YAML parsing, regex syntax) — NOT
by "what the rule set currently does or doesn't do." Every grammar entry
carries a one-line rationale pointing to the semantic reason.

### FR-2 — Cold-readable rationale

A reviewer with no session memory MUST be able to tell, from the grammar
file alone, why each sample is in SAFE vs UNSAFE without running the tool.

### FR-3 — Category coverage

Initial grammar MUST cover at minimum:

- Single-quoted-vs-double-quoted shell variable interpolation
- Groovy GString interpolation (single / double / triple-double quotes)
- YAML comment lines as exclusion markers
- Heredoc quoting semantics (`<<EOF` vs `<<'EOF'`)
- Literal strings with no variables
- PowerShell `iex` with and without a remote fetch
- Unquoted shell variables (unsafe)
- Curl-pipe-bash (unsafe)
- `eval` on user input (unsafe)

### FR-4 — Incremental growth

The grammar MUST be appendable without refactoring. A new category is a
new dict key; a new sample is a new list entry. No per-sample registration
code.

### FR-5 — Failure reporting

When the test fails, the output MUST identify:

- Which sample failed
- Which category the sample came from
- For FP failures: which rule(s) fired
- For FN failures: which rules were expected to fire (or "any rule")

### FR-6 — Self-contained test file

The test file MUST be a single Python module that runs under the existing
`pytest tests/integration/` command with no additional setup, flags, or
environment variables. It MUST NOT depend on test fixtures from other
test files.

## Non-goals

### NG-1 — Not a replacement for `Rule.test_positive` / `test_negative`

Per-rule samples stay. They test the rule's contract; the oracle tests
that the contract describes reality. Both are needed.

### NG-2 — Not a benchmark corpus

A benchmark corpus is drawn from real-world workflows with unknown
correctness; its samples are labelled by human judgement. This oracle is
drawn from language-semantic primitives; its samples are labelled by
reference to standards. Phase 1.1 of `docs/ROADMAP.md` is a separate
effort.

### NG-3 — Not exhaustive on day one

The initial grammar ships ~80 samples across 6 safe + 6 unsafe categories.
Exhaustive coverage is an ongoing curation effort, owned by whoever reviews
FP/FN reports post-merge.

### NG-4 — Not a rule-mutation testing replacement

`python -m taintly --mutate` tests whether the rule's regex/pattern is
tight enough to survive small syntactic perturbations on the author's own
samples. The oracle tests whether the author's samples were correct in
the first place. Orthogonal.

### NG-5 — No auto-fix

When the oracle fails, it reports the failure. It does NOT update the
grammar, downgrade the rule, or propose a fix. A failure is a signal for
human review, not a thing to silence.

## Acceptance criteria

- [ ] `pytest tests/integration/test_grammar_oracle.py` runs in <1s and
      either passes cleanly or reports specific FP/FN failures with
      rule IDs and sample text.
- [ ] The initial grammar covers the 12 categories listed in FR-3.
- [ ] Every sample has a one-line `# rationale:` comment above it citing
      the semantic reason the sample is safe or unsafe.
- [ ] `docs/oracle/DESIGN.md` lists the curation rules; a reviewer with no
      context can add a sample correctly by reading only that doc.
- [ ] `docs/oracle/FINDINGS.md` records any FP/FN the initial run surfaces,
      with enough detail for a follow-up PR to act on without re-running.
- [ ] The existing `pytest tests/` suite still passes (no collateral).

## Out of scope (tracked, not shipped here)

- Fixing the FP/FN findings surfaced by the first run. Each finding is a
  separate rule-precision PR by whoever takes it up.
- Running the oracle on other scanners (actionlint, zizmor, checkov) for
  head-to-head comparison. That's a benchmark-corpus activity, Phase 1.3.
- Grammar-based *generation* (e.g. fuzzing by combining categories). The
  oracle is static today; generative extensions are a separate design.
