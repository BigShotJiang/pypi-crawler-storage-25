# Semantic grammar oracle — Design

This document is the curation guide. A reviewer adding a new sample
should read only this doc; they should NOT need to run the tool to
decide whether their sample belongs in SAFE or UNSAFE.

## The categorisation rule

Every sample has two facts:

1. What does the language spec say about this fragment?
2. Under what assumption would a CI security scanner *want* to fire on it?

A sample goes in:

- **`SAFE_BY_CONSTRUCTION`** when (1) says the fragment cannot execute
  attacker-controlled content, regardless of input. Citation required.
- **`UNSAFE_BY_CONSTRUCTION`** when (1) says the fragment CAN execute
  attacker-controlled content, assuming the input is attacker-controlled.
- **Neither** when correctness depends on context the fragment doesn't
  carry (e.g. "this `run:` step is safe IFF the workflow doesn't use
  pull_request_target"). Context-dependent samples belong in
  `Rule.test_positive`/`Rule.test_negative`, not in the oracle.

The bright-line test is: can you prove the safety claim by quoting a
language standard, RFC, or first-party tool documentation? If yes, it's
an oracle sample. If the argument requires "well, you'd only write it
this way if…" the sample is context-dependent.

## Categories

### SAFE categories

| Key | Premise | Reference |
|---|---|---|
| `single_quoted_shell_var` | Bash/POSIX sh does not perform variable expansion inside single quotes. `'$VAR'` is literal. | POSIX `sh(1)` §2.2.2; [Bash manual §3.1.2.2](https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html) |
| `groovy_single_quoted` | Groovy single-quoted strings are `java.lang.String`, not GString. They do not interpolate `${...}`. | [Groovy lang spec — String](https://groovy-lang.org/syntax.html#_string_summary_table) |
| `yaml_comment_lines` | YAML `#` at start of a line (after optional whitespace) begins a comment that ends at newline. | [YAML 1.2 §6.6](https://yaml.org/spec/1.2.2/#66-comments) |
| `heredoc_quoted_marker` | Bash heredoc with a *quoted* sentinel (`<<'EOF'`) suppresses parameter, command, and arithmetic expansion on the body. | [Bash manual §3.6.6](https://www.gnu.org/software/bash/manual/html_node/Redirections.html#Here-Documents) |
| `static_string_literal` | Fragment contains no `$`, no backticks, no `${...}`, no `$(...)`, no `${{ }}`, no `@Grab`, no `uses:`. Provably has nowhere for input to flow. | First principles |
| `powershell_iex_local_file` | PowerShell `iex` invoked on the output of a local file read (`Get-Content`, `Type`, string literal) with no remote fetch API call (`Invoke-WebRequest`, `DownloadString`, `WebClient`, `Net.Http*`). | [PowerShell Invoke-Expression docs](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/invoke-expression) |
| `double_quoted_shell_var_passed_to_echo` | Bash `"$VAR"` is expanded but passed as a single argument to `echo` / `printf` — and those consumers do NOT re-parse their arguments. Safety here is a property of the consumer (echo's non-re-parsing behaviour), not of bash quoting in general. Samples piping the value to user-defined shell scripts (e.g. `deploy.sh "$VAR"`) do NOT belong here because `deploy.sh` may internally re-parse the argument; see `RETRACTED_SAMPLES` for the dropped example. | [Bash manual §3.5.3](https://www.gnu.org/software/bash/manual/html_node/Shell-Parameter-Expansion.html) + [§3.1.2.3](https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html); `echo(1)` / `printf(1)` |

### UNSAFE categories

| Key | Premise | Reference |
|---|---|---|
| `unquoted_shell_var_in_sh` | An unquoted bash variable reference undergoes word splitting + glob expansion. With attacker-controlled values, metacharacters execute. | [Bash manual §3.5.3](https://www.gnu.org/software/bash/manual/html_node/Shell-Parameter-Expansion.html) + §3.5.7 |
| `double_quoted_gstring_with_param` | Groovy double-quoted (`"..."`) and triple-double-quoted (`"""..."""`) strings ARE GStrings. `${params.X}` interpolates at Groovy parse time, before `sh` sees the command. | [Groovy lang spec — GString](https://groovy-lang.org/syntax.html#_double_quoted_string) |
| `eval_on_dynamic_input` | `eval` (shell) / `groovy.util.Eval.me` (Groovy) / `Invoke-Expression` (PowerShell) evaluate their string argument as code. Any attacker-controlled byte is attacker-controlled code. | [POSIX `eval`](https://pubs.opengroup.org/onlinepubs/9699919799/utilities/eval.html) |
| `pr_title_in_run_block` | GitHub Actions `${{ github.event.pull_request.title }}` is user-controlled. When rendered into a `run:` block, it becomes shell text with attacker-chosen metacharacters. | [GitHub Actions — security hardening](https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions#understanding-the-risk-of-script-injections) |
| `curl_pipe_bash` | `curl <url> \| bash` executes whatever the server at `<url>` returns. No integrity check; a compromised CDN = arbitrary code execution. | [OWASP CI/CD-SEC-6](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-06) |
| `dockerfile_from_latest_image` | `image: name:latest` (or tag-only with no digest pin) resolves the mutable `latest` tag at build/pull time. Registry compromise = attacker-controlled base image. Applies to GitHub Actions `container:` / `services:`, GitLab `image:`, and Jenkins `docker.image()`. | [Docker Hub — mutability disclosure](https://docs.docker.com/engine/reference/builder/#from) |
| `iex_on_interpolated_string` | PowerShell `iex "$(...)"` / `iex "$expr"` re-parses an interpolated subexpression as code. Structurally equivalent to shell `eval "$VAR"` — if the interpolated value carries attacker-controlled content, the re-parse executes it. Distinct from `powershell_iex_local_file` (local-disk read, no interpolation) and from `curl_pipe_bash` (remote fetch). | [PowerShell Invoke-Expression docs](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/invoke-expression) |
| `github_unpinned_action_ref` | GitHub Actions `uses: owner/repo@<ref>` where `<ref>` is a branch or tag rather than a commit SHA. Whoever can write to the tag or branch controls the code that runs on the next resolution. Covers plain tags (`@v4`), branches (`@main`), and references to known-compromised actions. | [OWASP CICD-SEC-3](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-03); [GitHub docs — pinning actions](https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions#using-third-party-actions) |
| `github_docker_action_no_digest` | `uses: docker://<image>:<tag>` without a `@sha256:` digest. The tag is mutable; registry compromise swaps the base image. | [OWASP CICD-SEC-3](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-03); [Docker Hub — content trust](https://docs.docker.com/engine/security/trust/content_trust/) |
| `pip_dependency_confusion_extra_index` | `pip install --extra-index-url <internal>` with a package name that exists on both internal and public indexes. Per pip's own docs, `--extra-index-url` searches PyPI first; a public-index name collision silently replaces the internal package. `--index-url` is the correct isolating flag. | [pip docs — `--extra-index-url` vs `--index-url`](https://pip.pypa.io/en/stable/cli/pip_install/#cmdoption-extra-index-url); [OWASP CICD-SEC-3](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-03) |
| `gitlab_remote_include_no_integrity` | GitLab CI `include: remote:` fetches whatever the URL returns at pipeline-parse time. No sha256 or commit pin; host compromise = arbitrary pipeline config. | [GitLab CI docs — include: remote](https://docs.gitlab.com/ee/ci/yaml/includes.html#include-with-remote); [OWASP CICD-SEC-3](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-03) |
| `jenkins_shared_library_no_sha` | Jenkinsfile `@Library('my-lib') _` resolves the library's default branch (typically `main`) on every build. Whoever pushes to that branch controls everything the pipeline does. `@Library('my-lib@<sha>')` pins it. | [Jenkins docs — shared libraries](https://www.jenkins.io/doc/book/pipeline/shared-libraries/); [OWASP CICD-SEC-3](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-03) |
| `jenkins_grab_no_version` | Groovy `@Grab('group:artifact')` without a version resolves whatever Maven Central currently publishes. The build is a floating dependency on upstream-maintainer choices. | [Groovy @Grab docs](https://groovy-lang.org/grape.html); [OWASP CICD-SEC-3](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-03) |
| `jenkins_docker_image_mutable_tag` | `docker.image('image:latest').inside { ... }` or untagged image resolves the mutable `latest` at build time. Same family as `dockerfile_from_latest_image`, expressed via the Jenkins Docker Pipeline DSL. | [Jenkins Docker Pipeline plugin docs](https://www.jenkins.io/doc/book/pipeline/docker/); [OWASP CICD-SEC-3](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-03) |
| `github_env_injection` | Attacker-controlled GitHub context (PR title, head_ref, issue body, etc.) written to `$GITHUB_ENV`. Sets an environment variable inherited by every subsequent step in the job — equivalent to arbitrary code execution via any step that reads the injected variable. Exploited in the Ultralytics supply-chain compromise (Dec 2024). | [GitHub Actions docs — `$GITHUB_ENV`](https://docs.github.com/en/actions/writing-workflows/choosing-what-your-workflow-does/workflow-commands-for-github-actions#setting-an-environment-variable); [OWASP CICD-SEC-4](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-04) |
| `github_path_injection` | Attacker-controlled GitHub context (PR title, head_ref, issue body, etc.) written to `$GITHUB_PATH`. Prepends a search-path entry for every subsequent step's unqualified command lookup — strictly broader than `$GITHUB_ENV` injection, which only affects steps that reference the injected variable. Direct twin of the `$GITHUB_ENV` attack against a broader sink. | [GitHub Actions docs — `$GITHUB_PATH`](https://docs.github.com/en/actions/writing-workflows/choosing-what-your-workflow-does/workflow-commands-for-github-actions#adding-a-system-path); [OWASP CICD-SEC-4](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-04) |
| `ml_deserialization_unsafe` | Loading ML model artefacts with flags that invoke the Python `pickle` unpickler, which executes arbitrary code via `__reduce__` the moment the file is parsed. Covers HuggingFace `trust_remote_code=True`, `torch.load(...)` without `weights_only=True`, and non-torch pickle-backed loaders (`joblib.load`, `dill.load`, `keras.load_model` without `safe_mode=True`, `numpy.load(..., allow_pickle=True)`). Each call shape is a single workflow line; the exploit lives in the file the workflow downloads. Samples cover GitHub Actions, GitLab CI, and Jenkins. | [PyTorch docs — `torch.load`](https://pytorch.org/docs/stable/generated/torch.load.html); [HuggingFace transformers — `trust_remote_code`](https://huggingface.co/docs/transformers/en/installation#install-from-source); [OWASP CICD-SEC-3](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-03) |
| `llm_output_piped_to_shell` | An LLM API response is piped through a JSON extractor into a shell interpreter (`… \| jq -r .content \| bash`, `… \| sh`, etc.). The attacker prompts the model to emit a command; whatever natural-language output the model returns is then executed as shell source. No jailbreak is required — the model is operating normally and the pipeline treats its output as code. | [OpenAI API docs](https://platform.openai.com/docs/api-reference); [OWASP CICD-SEC-4](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-04) |
| `workflow_write_all_permissions` | `permissions: write-all` at workflow or job scope grants every token permission GitHub exposes. If the `GITHUB_TOKEN` is exfiltrated from any step, the attacker gets the maximum blast radius the workflow could have granted. The safe default is least-privilege: declare explicit `contents: read` (etc.) and upgrade per-job as needed. | [GitHub Actions docs — permissions](https://docs.github.com/en/actions/writing-workflows/choosing-what-your-workflow-does/controlling-permissions-for-github_token#setting-the-github_token-permissions-for-all-jobs-in-a-workflow); [OWASP CICD-SEC-2](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-02) |
| `pipeline_credential_in_yaml` | Credential material stored directly in the pipeline YAML rather than a managed credential store. Covers GitLab's `DOCKER_AUTH_CONFIG: '{…auth:…}'` (base64-encoded registry auth in a committed variables block) and Jenkins `parameters { password(name: …) }` (build-parameter "password" that appears in the job UI and trigger logs). The credential is readable by anyone with repo read access or build-log access. | [GitLab CI docs — DOCKER_AUTH_CONFIG](https://docs.gitlab.com/ee/ci/docker/using_docker_images.html#define-an-image-from-a-private-container-registry); [Jenkins docs — parameterised builds vs. credential store](https://www.jenkins.io/doc/book/using/using-credentials/); [OWASP CICD-SEC-2](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-02) |
| `jenkins_credential_id_from_params` | Jenkins `withCredentials(credentialsId: params.X)` lets the build triggerer choose which credential to bind at runtime. The Jenkins credential store's ACL assumes `credentialsId` is a compile-time constant; a user-controlled binding is a confused-deputy primitive over that ACL. | [Jenkins docs — withCredentials / credentialsId](https://www.jenkins.io/doc/pipeline/steps/credentials-binding/); [OWASP CICD-SEC-2](https://owasp.org/www-project-top-10-ci-cd-security-risks/CICD-SEC-02) |

## Curation rules

### CR-1 — Each sample cites a standard

Every `SAFE_BY_CONSTRUCTION` sample is justified by language semantics.
Every `UNSAFE_BY_CONSTRUCTION` sample is justified by a concrete attack
shape. The `# rationale:` comment is required; reviewers reject PRs that
omit it.

### CR-2 — No context-dependent samples

"This `run: echo $BRANCH` is safe because the workflow is cron-triggered"
is NOT an oracle sample. Context-dependent safety belongs in per-rule
tests. The oracle only admits samples whose correctness holds under any
triggering context.

### CR-3 — Minimal fragments

A sample should be the **smallest fragment** that demonstrates the
category's semantic. Not a whole workflow. Not a whole job. A single
`sh 'foo ${params.X}'` beats a 20-line job definition where the `sh` is
buried. Less surface area = fewer accidental cross-category matches.

### CR-4 — The rule author MUST NOT be the grammar author

When a new rule PR adds samples to its own `test_positive` /
`test_negative`, the rule author must NOT simultaneously add equivalents
to the oracle grammar. Other maintainers add oracle samples. This is the
independence invariant. A PR that adds a rule + oracle samples is a
review red flag.

### CR-5 — A failed FP is not fixed by moving the sample

If the oracle reports that `SEC4-JK-001` fires on a
`single_quoted_shell_var` sample, the fix is to tighten `SEC4-JK-001`,
not to relocate the sample to the UNSAFE grammar or delete it. The
oracle is the canonical claim about what's safe.

### CR-7 — Platform scoping is opt-in for unambiguously-platform-specific shapes

Samples whose construct only makes sense on one platform (Groovy
`sh "..."`, GitHub Actions `${{ github.* }}`, PowerShell `pwsh -c`)
SHOULD set `Sample.platform` so the oracle restricts rule evaluation
to that platform. Samples whose construct is universal (POSIX shell
quoting, YAML comments, heredocs, static literals) MUST stay
platform-agnostic to maximise cross-platform rule coverage. See
`docs/oracle/EXTENSIONS.md` §EXT-A for the full policy and the
consistency tests that enforce it.

### CR-6 — A failed FN may widen the grammar OR the rules

If the oracle reports that no rule fires on a `curl_pipe_bash` sample
and the sample is well-formed, first check whether SEC6-GH-007 SHOULD
fire (it's the curl-pipe-bash rule). If it should and doesn't, fix the
rule. If the sample's shape is genuinely outside any rule's stated
remit, the grammar entry was mis-scoped — either reword it to match a
rule's remit, or delete it as out-of-scope.

## How to add a category

1. Add a new key to `SAFE_BY_CONSTRUCTION` or `UNSAFE_BY_CONSTRUCTION`
   in `tests/integration/test_grammar_oracle.py`.
2. Above the first sample, add a `# --- <category> ---` header comment.
3. Add a `# rationale:` comment above each sample citing the semantic
   reason.
4. Extend the category table in this DESIGN.md document with a new row.
5. Run the oracle. New samples must either pass or reveal a genuine
   rule precision issue; they must not be gratuitously tuned to the
   current rule set.

## How to add a sample to an existing category

1. Drop it in the list, with a `# rationale:` comment.
2. Run the oracle.
3. If the oracle flags it as FP/FN:
   - If the category's premise holds (cite the reference), the rule is
     wrong — file a rule-precision issue.
   - If the premise doesn't hold for this sample, the sample is
     miscategorised — move it or delete it.

## Intended grammar growth rate

Ballpark: 1–2 new samples per month during normal operation, more when a
new sort of FP/FN gets reported. The grammar is a slow-moving reference,
not a continuously-churning fixture.

## What this oracle does NOT replace

- `Rule.test_positive` / `test_negative` — per-rule contract tests.
- `python -m taintly --mutate` — mutation testing on a rule's own
  samples; verifies the regex is tight.
- `python -m taintly --integration-test` — documented semantic
  bypasses, kept visible so gaps are tracked.
- Future benchmark corpus (ROADMAP Phase 1.1) — labelled real-world
  workflows with F1 numbers.

The oracle sits between per-rule unit tests (too local) and the
benchmark corpus (too broad) — it tests that the rule set's whole
implied definition of "safe" matches what the standards say.
