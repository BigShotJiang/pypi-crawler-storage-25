# Semantic grammar oracle — Architecture

## File layout

```
docs/oracle/
├── REQUIREMENTS.md   ← what we need + acceptance criteria
├── DESIGN.md         ← curation guide (how to author samples)
├── ARCHITECTURE.md   ← this file — implementation shape
└── FINDINGS.md       ← observations from each oracle run

tests/integration/
└── test_grammar_oracle.py   ← grammar tables + two test functions
```

One test file, two module-level dicts, two test functions. That's the
whole thing. No new pytest plugins, no new CLI flags, no config.

## Harness mechanics

### Data

Two module-level dicts in `test_grammar_oracle.py`, keyed by
category name, valued by lists of `Sample` dataclass instances:

```python
@dataclass(frozen=True)
class Sample:
    source: str
    rationale: str
    spec_ref: str
    expected_rules: frozenset[str] = frozenset()
    xfail_reason: str | None = None

SAFE_BY_CONSTRUCTION: dict[str, list[Sample]] = {
    "single_quoted_shell_var": [
        Sample(
            source="- run: echo '$CI_COMMIT_MESSAGE'",
            rationale="Shell never expands $VAR inside single quotes.",
            spec_ref="POSIX sh §2.2.2",
        ),
        # ...
    ],
    # ...
}

UNSAFE_BY_CONSTRUCTION: dict[str, list[Sample]] = { ... }
```

Metadata lives ON the sample rather than in parallel dicts keyed by
source-string identity. This makes xfail linkage survive source
reformatting, makes rationale/spec_ref programmatically accessible
(lintable, renderable into failure messages), and lets UNSAFE
samples declare `expected_rules` so the test can assert WHICH rule
fired — not just that some rule did. See the audit feedback on PR
#39 for the motivating rationale.

Category keys MUST match the table in DESIGN.md and the FR-3 bullet
list in REQUIREMENTS.md.

There is a third dict, `RETRACTED_SAMPLES: dict[str, str]`, mapping
the source of a once-proposed sample to the findings-log entry
explaining why it was removed. `test_retracted_samples_do_not_reappear`
guards against silent re-introduction.

### Tests

Two sample-level parametrised tests plus a small suite of meta-tests:

```python
def test_no_rule_fires_on_safe_sample(category, sample: Sample): ...
def test_expected_rule_fires_on_unsafe_sample(category, sample: Sample): ...
def test_every_sample_category_is_documented(): ...
def test_grammar_has_minimum_category_coverage(): ...
def test_retracted_samples_do_not_reappear(): ...
def test_every_sample_has_well_formed_metadata(): ...
```

Test IDs use `{category}-{index}` (not truncated source), so two
samples in the same category with a shared prefix no longer collide
and pytest doesn't silently renumber them.

The unsafe test asserts in three layers, in order: no rule crashed,
at least one rule fired, and — when `sample.expected_rules` is
populated — the intersection with actually-fired rules is
non-empty. The third layer catches the regression mode where the
sample-author's intended rule gets narrowed and something
coincidental covers for it. Before this pass, that class of silent
drift was invisible to the harness.

### How rules are loaded

`load_all_rules()` from `taintly.rules.registry`, filtered to
**exclude `AbsencePattern` rules**.

AbsencePattern rules ask "does this FILE lack key X?" (e.g. "no
top-level `permissions:` block"). They fire on any sample that isn't
a complete workflow — including every 4-line fragment. Running them
against step-level samples is equivalent to running them against an
empty file; they fire by construction on everything and the signal
is zero.

File-level AbsencePattern rules are tested correctly by
`tests/integration/test_all_rules_clean.py`, which scans real
hardened-workflow fixtures. They're out of scope for the oracle.

All other pattern types (`RegexPattern`, `ContextPattern`,
`SequencePattern`, `BlockPattern`, `PathPattern`, `TaintPattern`) are
evaluated in full — that's the aggregate-behaviour check.

### How a sample is scanned

```python
lines = sample.splitlines()
matches = rule.pattern.check(sample, lines)
```

Mirrors how the real engine evaluates rules (see
`taintly.engine.scan_file`). Deliberately NOT using `scan_file`
itself because that adds path-based filtering, platform auto-detect,
and finding-family classification — layers we don't care about for
this test.

### Platform scoping

Samples MAY carry an optional `platform: Platform` field. When set,
the harness restricts rule evaluation to rules whose `Rule.platform`
matches. When unset (the default), every rule is checked regardless
of platform — the v1 behaviour.

Setting `platform` is reserved for samples whose construct is
unambiguously platform-specific:

- Groovy `sh '...'` / `sh "..."` → `Platform.JENKINS`
- GitHub Actions `${{ github.* }}` / `pwsh -c` → `Platform.GITHUB`
- (no GitLab-specific markers in v1; CI variable names like
  `$CI_COMMIT_MESSAGE` exercise rules cross-platform usefully)

Samples whose construct is universal (POSIX shell quoting, YAML
comments, heredocs, static literals, `eval`, curl-pipe-bash,
`image: name:latest`) stay platform-agnostic to maximise coverage.

Two meta-tests guard the policy:

- `test_platform_scoping_is_consistent` asserts samples containing
  platform-specific syntactic markers have a matching `platform`.
- `test_every_sample_has_well_formed_metadata` requires platform-set
  samples to cite the platform in their rationale.

See `docs/oracle/EXTENSIONS.md` §EXT-A for the full RFC, including
the curation policy and FR-by-FR test traceability. A sample that is
genuinely "safe in GitHub but unsafe in GitLab" is still
context-dependent and per DESIGN.md CR-2 belongs in `Rule.test_*`,
not in the oracle.

## Integration with existing suite

### Where it runs

```
pytest tests/integration/
```

Picked up by the existing `unit-test` job in `.github/workflows/ci.yml`
which already runs `tests/integration/`. No workflow change.

### Runtime cost

~120 samples × ~125 rules × O(lines × regex_len) per rule.check(). On
the current machine the whole suite completes in well under 1 s. Safe
to keep in the fast-feedback path.

### Relationship to other test layers

| Layer | Gates against | Uses author's samples? |
|---|---|---|
| `tests/unit/` | Engine, models, reporters | n/a |
| `--self-test` | Rule fires on its `test_positive` | **yes** |
| `--mutate` | Rule survives perturbations to its samples | **yes** |
| `tests/integration/test_all_rules_clean.py` | Hardened workflows → 0 findings | maintainer-authored |
| **`tests/integration/test_grammar_oracle.py`** | Rule set's aggregate behaviour matches language semantics | **no — independently curated grammar** |
| `--integration-test` | Documented semantic bypasses | maintainer-authored |
| Benchmark corpus (Phase 1.1) | Rule set matches real-world workflow labels | benchmark-author-labelled |

The oracle is the only layer whose ground truth is **not** produced by
the same people who write the rules. That's the specific gap it fills.

## Failure reporting

A failure looks like:

```
FAILED tests/integration/test_grammar_oracle.py::
  test_no_rule_fires_on_safe_sample[single_quoted_shell_var-0]

AssertionError: False positive on provably-safe sample.
  Category: single_quoted_shell_var
  Sample:   - run: echo '$CI_COMMIT_MESSAGE'
  Rules that fired: ['SEC4-GL-001']
  Rationale for sample's safety (from grammar): POSIX sh §2.2.2 —
  single quotes suppress all expansion.
```

The message carries everything a reviewer needs to act: the sample,
the rule ID, and the semantic reason the sample is safe. A follow-up
PR can either tighten the rule or reject the grammar entry (after
citing a counter-reference); the oracle's output tells the reviewer
what to look at first.

## State & persistence

The oracle is **stateless between runs**. It does not commit results,
does not maintain an "expected failures" file, and does not trend over
time. A CI run either passes or fails, and the failure itself IS the
signal.

When a category's premise has a known corner case that's out of
current rule scope (for example, a curl-pipe-bash sample that uses
an unusual tool like `zsh -`), we set `Sample.xfail_reason` to a
pointer into `FINDINGS.md`. The harness converts a non-empty
`xfail_reason` into `pytest.mark.xfail(strict=True, ...)`. XFAIL is
strict via pytest's `xfail_strict=true` in `pyproject.toml`, so an
unexpectedly passing xfail fails the build. The reason-string lives
on the sample rather than in a frozenset keyed by source identity,
so reformatting the sample text does not silently drop the xfail.

## Evolution path

### v1 (this PR)

80+ samples across 12 categories. Manual curation. Static grammar.

### v1.x (incremental)

New samples added per rule-precision follow-up PR. DESIGN.md tables
updated to match new categories.

### v2 (future, not in this PR)

Generative variant: instead of hand-curated samples, combine category
primitives (e.g. `single_quoted_shell_var` × `yaml_list_item` ×
`nested_under_step`) via a small DSL. Candidates are filtered by the
same per-category safety invariants. Out of scope; noted for roadmap.

## What breaks it

Three scenarios the maintainer needs to be aware of:

1. **A rule's regex grows broad enough to match a SAFE sample.** That's
   a real bug, should cause a test failure, follow-up PR fixes the
   rule. This is the oracle's happy path — it detected a new FP.
2. **A SAFE sample's premise turns out to be wrong** (e.g. "actually
   Bash 5.2 DOES expand `$VAR` in single quotes under obscure
   LOCALE"). Rare; fix is to delete or reword the sample + update the
   DESIGN.md table to cite the counter-reference.
3. **A new rule fills a gap and correctly fires on an UNSAFE sample**
   that previously had no fire. No action needed — that's expected
   evolution.

None of these require oracle-internal changes. The grammar is stable.

## What this oracle does NOT check

- **File-level AbsencePattern rules** — see "How rules are loaded"
  above. These need whole-workflow context and are tested against
  real fixture files in `test_all_rules_clean.py`.
- **Cross-file / cross-workflow behaviour** — e.g. reusable-workflow
  taint propagation. Samples are single fragments.
- **Platform auto-detect correctness** — `engine.scan_file` has its
  own layer of path-based platform selection. The oracle bypasses
  that by evaluating rules directly.
- **Finding-family clustering, scoring, reporters** — everything
  downstream of `rule.pattern.check()` is out of scope. Those layers
  have their own unit tests.

## What must not be added

- Any sample that tests a *specific rule's* behaviour in isolation.
  Those go in the rule's `test_positive`/`test_negative`. The
  `expected_rules` field on UNSAFE samples is NOT a rule-behaviour
  test: it's an assertion about which rule is *supposed* to own a
  given attack shape. The harness asserts intersection non-empty,
  not equality, so multiple rules sharing coverage is fine.
- Any sample that depends on runtime state (env vars, file presence).
  Samples are static strings, full stop.
- Meta-grammar: categories of categories, grammar validators, etc.
  Keep the structure to SAFE_BY_CONSTRUCTION + UNSAFE_BY_CONSTRUCTION
  + RETRACTED_SAMPLES. Metadata lives on `Sample`; anything richer
  gets a separate discussion first.
