# Semantic grammar oracle — Extensions

Lightweight RFCs for extensions to the oracle that have policy or
architectural implications. Pure additive test infrastructure (e.g.
mutation testing, Hypothesis property tests, coverage artifacts) is
documented inline in the relevant test file's module docstring rather
than here — see `tests/integration/test_grammar_oracle_*.py` for those.

Each section below is a self-contained mini-RFC with the same shape:
Problem → Functional Requirements → Non-goals → Design → Tests that
prove each FR. Security requirements and threat modelling are
deliberately omitted: the oracle is internal test infrastructure with
no users, no untrusted runtime input, and no protected data flow. The
relevant "threats" are bugs in the rules themselves, which the oracle
is designed to surface.

---

## EXT-A — Platform-aware grammar

### Problem

Today the oracle evaluates every rule against every sample regardless
of platform. This produces two pathologies that have already cost two
samples (F-3b, F-3d):

1. **Cross-platform false matches.** A Jenkins-style `sh "..."` string
   embedded in a YAML comment trips `SEC4-JK-001` even though no real
   Jenkinsfile would have a `#`-prefixed line. The rule is correct for
   Jenkinsfiles; the sample is correct for YAML; the cross product is
   noise.
2. **Inability to express platform-specific shapes.** A sample like
   `iex "$($MyVariable)"` is unambiguously a PowerShell construct, but
   asserting it against the GitLab and Jenkins rule sets adds nothing
   and, in F-3d's case, forced retraction-then-relabelling.

The current workaround is to drop or carefully word samples to avoid
the cross-product. That's a curation tax and it bleeds expressiveness:
samples that would naturally exercise a platform-specific rule are
either excluded or written in a maximally-defensive way.

### Functional Requirements

- **FR-A1.** A sample MAY carry an optional `platform: Platform` field.
  When set, the harness restricts rule evaluation to rules with
  matching `Rule.platform`. When unset (the default), evaluation
  remains platform-agnostic — the v1 behaviour is preserved.
- **FR-A2.** Setting `platform` on a sample MUST NOT remove the
  semantic-defensibility burden. The sample's safety/unsafety claim
  still rests on language semantics; `platform` only restricts which
  rule subset is asked to render a verdict.
- **FR-A3.** Samples whose construct genuinely doesn't make sense on
  other platforms (Groovy `sh ""`, GitHub Actions `${{ }}`, PowerShell
  `iex`) SHOULD be platform-scoped. Samples whose construct is
  universal (POSIX shell quoting, YAML comments, heredocs) SHOULD
  remain platform-agnostic.
- **FR-A4.** The sample's `rationale` MUST justify the platform
  restriction when `platform` is set. The rationale lint
  (`test_every_sample_has_well_formed_metadata`) is extended to fail
  on platform-scoped samples whose rationale lacks a platform-citation
  marker (e.g. "Jenkins-only", "GitHub Actions-specific", "PowerShell
  construct").

### Non-goals

- **NG-A1.** We do NOT add platform auto-detection. The harness does
  not parse the sample to guess its platform; the maintainer declares
  it explicitly or it stays platform-agnostic.
- **NG-A2.** We do NOT change the per-platform rule sets or how
  `Rule.platform` is assigned. This RFC is strictly about which rules
  the oracle exercises against a given sample.
- **NG-A3.** We do NOT introduce per-sample expected-fail-on-platform
  semantics. A sample asserts one verdict (safe/unsafe) under one rule
  subset; it does not encode "this is safe in GitHub but unsafe in
  GitLab." Per-platform-divergence claims belong in `Rule.test_*`.

### Design

```python
from taintly.models import Platform

@dataclass(frozen=True)
class Sample:
    source: str
    rationale: str
    spec_ref: str
    expected_rules: frozenset[str] = frozenset()
    xfail_reason: str | None = None
    platform: Platform | None = None  # FR-A1


def _rules_that_fire(
    rules: list[Rule],
    source: str,
    platform: Platform | None = None,  # FR-A1
) -> tuple[list[str], list[tuple[str, BaseException]]]:
    if platform is not None:
        rules = [r for r in rules if r.platform == platform]
    # ... unchanged from here
```

The two test functions thread `sample.platform` into `_rules_that_fire`.
Backfill is conservative: only categories where the construct is
unambiguously platform-specific get `platform` set in v1 of this
extension. Universal categories (POSIX shell quoting, YAML comments,
heredocs, static literals, eval, curl-pipe-bash, image:latest) stay
platform-agnostic so they continue to exercise rules across the whole
registry.

Categories scoped in v1:

| Category | Platform | Justification |
|---|---|---|
| `groovy_single_quoted` | JENKINS | `sh '...'` is Jenkinsfile syntax |
| `double_quoted_gstring_with_param` | JENKINS | GString interpolation is Groovy |
| `pr_title_in_run_block` | GITHUB | `${{ github.* }}` is GitHub Actions-specific |
| `iex_on_interpolated_string` | GITHUB | PowerShell `iex` rule lives in github/ |
| `powershell_iex_local_file` | GITHUB | same |

The rationale-lint extension (FR-A4) flags any platform-set sample
whose rationale doesn't cite a platform marker.

### Tests that prove each FR

| FR | Covered by |
|---|---|
| FR-A1 (optional field, agnostic default) | `test_no_rule_fires_on_safe_sample` and `test_expected_rule_fires_on_unsafe_sample` continue to pass with the existing universal samples whose `platform` is unset; they also pass for the v1-scoped categories with `platform` set. |
| FR-A2 (semantic burden preserved) | `test_every_sample_has_well_formed_metadata` continues to require non-empty `rationale` and `spec_ref`. |
| FR-A3 (correct scoping) | The v1 scoping table is asserted directly by `test_platform_scoping_is_consistent`: every sample whose construct matches one of the platform-specific syntactic markers (the GString shape, `${{ github.* }}`, `pwsh -c`) MUST have a non-None `platform` set. |
| FR-A4 (rationale cites the platform) | `test_every_sample_has_well_formed_metadata` is extended to require a platform-citation marker in rationale when `Sample.platform is not None`. |

### Migration impact

- F-3d (the `iex "$($MyVariable)"` retraction) becomes redundant in
  documentation terms — the sample now lives in
  `iex_on_interpolated_string` with `platform=GITHUB`, and the
  cross-platform-noise risk that drove its removal is structurally
  prevented. The retraction entry stays for institutional memory.
- F-3b (the YAML-comment-with-Jenkins-string retraction) similarly
  becomes structurally preventable — a future re-attempt could ship
  the sample with `platform=GITHUB` (because it's a YAML comment in a
  GitHub Actions workflow). Not in scope for this extension.

---

## EXT-B — Inverse rule-attribution index

### Problem

The oracle's per-sample tests prove "for this sample, the rule set
behaves correctly." They say nothing about rules with NO sample.
Today, ~50% of registry rules have zero UNSAFE-grammar coverage:
silently narrowing one of them — for example, SEC3-GH-001 going from
"matches any unpinned action" to "matches only `@main`" — produces
no test failure because the oracle never asks the rule to do anything.

The audit feedback called this out explicitly: build the inverse
index `{rule_id: [samples that fired on it]}` and assert every rule
either has grammar coverage OR is explicitly marked as fixture-only
with a reason. That forces a per-rule decision.

### Functional Requirements

- **FR-B1.** The oracle MUST classify every loaded rule as either
  *grammar-testable* (i.e. its pattern type can be exercised by a
  single-fragment sample) or *not grammar-testable* (its pattern type
  requires multi-line / cross-step / file-scope context).
- **FR-B2.** Every grammar-testable rule MUST have at least one
  UNSAFE_BY_CONSTRUCTION sample whose `_rules_that_fire` output
  includes that rule's ID, OR be listed in `_REGEX_RULES_WITH_KNOWN_GAP`
  with a tracking note.
- **FR-B3.** Rules that are NOT grammar-testable are automatically
  exempt — no allowlist entry required. Their structural exemption is
  inferred from `type(rule.pattern)`, not from a hand-curated list,
  so future pattern-type additions don't silently re-exempt rules.
- **FR-B4.** The `_REGEX_RULES_WITH_KNOWN_GAP` allowlist MUST be
  validated for staleness: every entry's rule ID must be a real
  loaded rule, and every entry must NOT currently be covered by the
  grammar (entries that get covered are removed in the same PR).
- **FR-B5.** Allowlist entries SHOULD be grouped by family in
  `_REGEX_GAPS_BY_FAMILY` so the file reads as a follow-up workplan
  rather than an opaque exception list. Each family carries a one-
  line characterisation of the gap.

### Non-goals

- **NG-B1.** We do NOT require structural changes to non-RegexPattern
  rules to make them grammar-testable. ContextPattern and
  SequencePattern intentionally need multi-line context; that's a
  feature of the rule type, not a coverage gap.
- **NG-B2.** We do NOT add a "coverage percentage" metric or any
  trend-line gate. Numbers without per-rule decisions invite the
  "ratchet down by 1" failure mode the audit warned against.
- **NG-B3.** We do NOT auto-generate samples for uncovered rules.
  Sample curation is human work; the oracle's value is precisely
  that the SAFE/UNSAFE labels come from a human reading a spec, not
  from a generator.

### Design

```python
# Pattern types that can be exercised by a single-fragment sample.
# The list is intentionally short; new pattern types default to
# "not grammar-testable" until evaluated.
_GRAMMAR_TESTABLE_PATTERN_TYPES: tuple[type, ...] = (RegexPattern,)

# Coverage gaps grouped by family. Each family is a unit of follow-up
# work — a future PR picks a family, writes samples for its members,
# and removes the entries here.
_REGEX_GAPS_BY_FAMILY: dict[str, frozenset[str]] = {
    "SEC2 — identity / secrets in workflow text": frozenset({...}),
    "SEC3 — supply-chain pinning (action SHAs, image tags)": frozenset({...}),
    "SEC4 — poisoned-pipeline-execution patterns": frozenset({...}),
    "SEC6 — credential hygiene (hardcoded secrets, weak refs)": frozenset({...}),
    "SEC7 — runner / job hardening text patterns": frozenset({...}),
    "SEC8 — third-party service text patterns (image:latest etc.)": frozenset({...}),
    "SEC9 — Jenkins artifact integrity text patterns": frozenset({...}),
    "SEC10 — logging / visibility config patterns": frozenset({...}),
}

_REGEX_RULES_WITH_KNOWN_GAP = {
    rid: family
    for family, ids in _REGEX_GAPS_BY_FAMILY.items()
    for rid in ids
}


def _build_coverage_index(rules):
    """Return {rule_id: [test_id of UNSAFE sample(s) that fired]}."""
    ...


def test_every_grammar_testable_rule_has_coverage_or_known_gap(loaded_rules):
    coverage = _build_coverage_index(loaded_rules)
    uncovered_unexempted = [
        r.id for r in loaded_rules
        if isinstance(r.pattern, _GRAMMAR_TESTABLE_PATTERN_TYPES)
        and r.id not in coverage
        and r.id not in _REGEX_RULES_WITH_KNOWN_GAP
    ]
    assert not uncovered_unexempted, ...


def test_known_gaps_are_actual_rules_and_still_uncovered(loaded_rules):
    """Catches stale allowlist entries: rules that were renamed away,
    or rules that DID get a sample but the allowlist entry was left
    behind."""
    ...
```

### Tests that prove each FR

| FR | Covered by |
|---|---|
| FR-B1 (classification) | `test_every_grammar_testable_rule_has_coverage_or_known_gap` filters by `isinstance(pattern, _GRAMMAR_TESTABLE_PATTERN_TYPES)` directly; the partition is data-driven. |
| FR-B2 (coverage or allowlist) | Same test asserts every grammar-testable rule is in coverage OR allowlist. |
| FR-B3 (structural exemption) | The same test never asks non-grammar-testable rules for coverage; the test passes today for ContextPattern/SequencePattern/TaintPattern rules without any allowlist entries. |
| FR-B4 (no stale allowlist) | `test_known_gaps_are_actual_rules_and_still_uncovered` walks the allowlist and asserts (a) the rule still exists, (b) the rule is still uncovered. |
| FR-B5 (per-family grouping) | Code review only — `_REGEX_GAPS_BY_FAMILY` is a literal source-level dict; reviewers see grouping at a glance. No runtime test. |

### Migration impact

- New file `docs/oracle/GAPS.md` lists the families and per-rule action items so contributors know what an oracle-coverage follow-up PR looks like.
- Future rule additions: a new RegexPattern rule with no sample fails
  `test_every_grammar_testable_rule_has_coverage_or_known_gap`. The
  contributor either adds a sample (preferred) or adds the rule to
  `_REGEX_GAPS_BY_FAMILY` with a citation of why it's non-trivial.
- Future rule renames: the staleness test fails on the old ID,
  forcing the rename to be reflected in the allowlist.

---

## EXT-F — AI-agents-in-CI rule family (`AI-*`)

### Problem

Coding agents (Claude Code, OpenAI Codex CLI, Cursor background agents,
Aider, Devin, the `actions/ai-inference` primitive, countless MCP-
wrapper actions) are now routine participants in CI pipelines. The
existing rule families (`SEC1-10`, `LOTP`, `TAINT`) model
human-authored attacks and classical supply-chain threats. They do
NOT model the attack surfaces that agents specifically open:

- An agent given write permissions AND attacker-controllable context
  is a new kind of privilege-escalation path. SEC4 (PPE) gets close
  for the shell-injection case but doesn't model the agent-as-sink.
- An agent can read repository content (READMEs, dependency metadata,
  issue bodies, fetched URLs) that carries attacker-authored
  instructions. Classical input-validation rules see the file read as
  benign because the file looks like a file.
- A rogue agent action — unvetted third-party `uses:` entry, or a
  vetted action pointed at an attacker-controlled inference backend
  — is a supply-chain variant that SEC3 (pinning) partially addresses
  but doesn't fully model; the usual "pin by SHA" advice doesn't
  prevent a pinned action whose `api_url:` points at evil.com.

AI-`*` rules carve out this territory as its own family so the
grammar and intent stay legible. Shoving these into `SEC4-*` muddies
both rule sets — SEC4 is about shell-source injection, and
conflating agent-sinks with shell-sinks would force readers to
disentangle them every time they grepped the ruleset.

### Functional Requirements

- **FR-F1.** A new top-level rule family prefix `AI-` is added to the
  registry. Rules in this family use `owasp_cicd="CICD-SEC-4"` (or
  future CICD-SEC-AI if OWASP adds one) for taxonomy compatibility,
  but the ID prefix signals "this is an agent-specific rule" to
  reviewers.
- **FR-F2.** A curated `KNOWN_AI_AGENT_ACTIONS` constant enumerates
  third-party agent `uses:` action references (e.g.
  `anthropics/claude-code-action`, `OpenAI/codex-cli-action`,
  `cursor/background-agent`, bare `actions/ai-inference`). Rules
  reference this constant rather than hard-coding action names, so a
  new agent action can be added in one place. The list is a
  maintainer-curated allowlist of KNOWN agents, NOT an approval list;
  rules detect "an agent is present here" and then check conditions.

  *Known limitation (recall gap):* the match is on the exact
  `owner/repo` prefix before `@`, which means internal forks
  (`acmecorp/claude-code-action@<sha>` — a vendored copy of the
  upstream agent action) are not detected. Documented rather than
  patched because the alternative — match on `repo-name` alone or
  maintain a fork-alias table — trades recall for significant
  precision loss and maintenance burden. Shops that vendor agent
  actions add their forks to `KNOWN_AI_AGENT_ACTIONS` locally. Same
  discipline as `SEC9-GH-002`'s narrowing: accept the gap, document
  it, leave room for a richer detector later.
- **FR-F3.** AI-rules split along the threat-class taxonomy laid out
  in the project notes:
    - Rogue-AI (classes 1): agent action not on an allowlist of vetted
      actions, or agent with a non-default `api_url:` / `endpoint:` /
      `base_url:`, or agent exposed to secrets it doesn't need.
    - Indirect-prompt-injection enabling (class 2): agent with
      unrestricted file-read, agent with fetch/web-browse tool whose
      URL is `${{ github.* }}`-derived, agent with MCP servers and no
      `require-approval: true`, agent reading from known injectable
      paths (`CLAUDE.md`, dependency manifests) under a PR-writable
      path.
    - Direct-prompt-injection (class 3): agent step input derived
      from `${{ github.event.pull_request.title | body }}`,
      `${{ github.event.issue.body | comment.body }}`, or
      `${{ github.head_ref }}`.
- **FR-F4.** Rules in the `rogue-AI` subclass MUST NOT silently deny
  well-known-safe agent actions: the
  `KNOWN_AI_AGENT_ACTIONS`-but-not-vetted distinction is explicit.
  A separate `VETTED_AI_AGENT_ACTIONS` allowlist (smaller) exists for
  this purpose; rule `AI-GH-020` fires when an agent is detected that
  is NOT on the vetted list. Both lists live in
  `taintly/rules/github/ai_agents.py` (new file) and are
  maintainer-curated with a one-line rationale per entry.
- **FR-F5.** Rules MUST carry grammar samples in the oracle
  (`tests/integration/test_grammar_oracle.py`) — NEW UNSAFE
  categories per rule subclass, each with at least one sample
  exercising the canonical attack shape. Rules in the `direct-prompt-
  injection` subclass share samples with the existing
  `pr_title_in_run_block` category where the same input is used.
- **FR-F6.** Rules for which a static workflow check cannot reliably
  detect the attack — specifically, semantic prompt-injection
  content (hidden instructions in a README, zero-width text in an
  issue body, agent tool-use reasoning that crosses safety
  boundaries) — MUST be explicitly out of scope and documented as
  such. This RFC does NOT promise runtime prompt-injection detection.

  *Rule-description convention (mandatory):* every `AI-*` rule's
  `description` field MUST open with a structural-limitation
  disclaimer sentence of the form:

    "This rule detects [structural workflow condition]; it does NOT
    detect hostile content in the text the agent reads."

  The exact phrasing can vary, but the "what this rule detects vs.
  what it does NOT detect" split must be the first thing a reader
  sees. Without it, a maintainer scanning the description for
  `AI-GH-030` ("unrestricted file-read") reads "detects agent can
  read arbitrary repo content" and reasonably concludes they are
  protected from prompt injection. They are not, and the
  description should not let them think so. This convention is
  enforced by review (not by test) until a linter exists for it.

### Non-goals

- **NG-F1.** Semantic analysis of agent prompts or outputs. The
  scanner stays static; runtime agent-behavior observability is a
  different tool.
- **NG-F2.** Scanning AI-generated CODE. The existing rule set
  already applies to code regardless of author. The interesting
  question about AI-authored code ("did a human review it?") is
  platform-posture territory, not workflow-YAML territory.
- **NG-F3.** A separate `CICD-SEC-AI` OWASP category. Rules live
  under the existing `CICD-SEC-*` taxonomy (mostly SEC-4 Poisoned
  Pipeline Execution, some SEC-3 Dependency Chain Abuse). OWASP can
  add a dedicated category in time; until then the `AI-` prefix
  carries the semantic weight.

### Design

New file `taintly/rules/github/ai_agents.py` with the following
shape:

```python
# Agents currently known to exist as GitHub Actions. Used as a
# detection anchor (these patterns identify "this is an agent step").
# Maintained separately from the vetted list below so new agents can
# be ADDED without implicitly approving them.
KNOWN_AI_AGENT_ACTIONS: frozenset[str] = frozenset({
    "anthropics/claude-code-action",
    "actions/ai-inference",
    "OpenAI/codex-cli-action",
    "cursor/background-agent",
    # ... (see the full list in ai_agents.py)
})

# Actions explicitly vetted for use in this project's CI. Rule
# AI-GH-020 fires when an agent step uses an action that is in
# KNOWN_AI_AGENT_ACTIONS but NOT in this set. Extend this list
# deliberately, with a code comment citing the vetting trail.
VETTED_AI_AGENT_ACTIONS: frozenset[str] = frozenset({
    # (empty until a maintainer explicitly vets one)
})

RULES: list[Rule] = [
    # Rogue-AI subclass ---------------------------------------------
    Rule(id="AI-GH-020", ...),  # unvetted agent action
    Rule(id="AI-GH-021", ...),  # non-default inference endpoint
    Rule(id="AI-GH-022", ...),  # agent exposed to off-topic secrets
    Rule(id="AI-GH-023", ...),  # agent + network egress + secrets

    # Indirect-prompt-injection enabling subclass -------------------
    Rule(id="AI-GH-030", ...),  # unrestricted file-read
    Rule(id="AI-GH-031", ...),  # fetch URL derived from event context
    Rule(id="AI-GH-032", ...),  # MCP tool use without require-approval
    Rule(id="AI-GH-033", ...),  # reads from PR-writable CLAUDE.md / deps manifests

    # Direct-prompt-injection subclass ------------------------------
    Rule(id="AI-GH-003a", ...),  # PR title/body as agent input
    Rule(id="AI-GH-003b", ...),  # issue body/comment as agent input
    Rule(id="AI-GH-003c", ...),  # github.head_ref as agent input
]
```

Each rule's pattern anchors on an agent-action `uses:` reference
from `KNOWN_AI_AGENT_ACTIONS` and adds the class-specific condition.

### Tests that prove each FR

| FR | Covered by |
|---|---|
| FR-F1 (new family prefix) | Rule IDs matching `^AI-(GH\|GL\|JK)-\d{3}` are asserted to exist in `tests/unit/test_audit_findings.py::test_ai_rule_family_loaded`. |
| FR-F2 (`KNOWN_AI_AGENT_ACTIONS`) | A lint test asserts every agent rule's anchor references this constant rather than hard-coding action names. |
| FR-F3 (three subclasses) | `docs/oracle/DESIGN.md` table documents each subclass; inverse-coverage test (EXT-B) enforces every `AI-*` rule has a grammar sample. |
| FR-F4 (vetted-action discipline) | `tests/unit/test_ai_rules.py::test_vetted_list_is_subset_of_known` asserts the vetted list is a subset of the known list; `test_vetted_list_entries_have_rationale` lints the comment-adjacency. |
| FR-F5 (oracle grammar coverage) | EXT-B's `test_every_grammar_testable_rule_has_coverage_or_known_gap` already enforces this for new RegexPattern rules. Non-grammar-testable AI rules (e.g. `AI-GH-023` which requires ContextPattern across env: and `with:` blocks) go on the fixture-only list with a reason. |
| FR-F6 (semantic prompt injection out of scope) | Documented in `docs/oracle/DESIGN.md` under "What the oracle does NOT test," with a pointer to the limitation in the AI-agent rules' descriptions. Enforced by review, not by test. |

### Migration impact

- New file `taintly/rules/github/ai_agents.py` — roughly 10 rules,
  similar size to `sec4_ppe_extended.py`.
- `docs/oracle/DESIGN.md` gains an UNSAFE-categories subsection for
  AI rules (agent-as-sink, interpolation-to-agent-input,
  unvetted-agent).
- `docs/oracle/GAPS.md` opens an `AI-*` section listing rule IDs to
  be implemented.
- `CONTRIBUTING.md` or a new `docs/AI_AGENTS.md` describes how
  maintainers vet new agent actions into `VETTED_AI_AGENT_ACTIONS`.
- Existing rules `SEC4-GH-004` / `SEC4-GH-017` stay; they remain the
  shell-sink and PowerShell-sink specific rules. AI rules layer on
  top without overlap because their anchor is the agent action, not
  the interpretive step.

  *Interaction with existing SEC4 rules — both fire independently.*
  When a workflow step contains BOTH an agent action input AND a
  shell-injection surface (e.g. an `anthropics/claude-code-action`
  step whose input is `${{ github.event.pull_request.title }}` AND
  later writes to `run: echo ${{ github.event.pull_request.title }}`),
  BOTH `AI-GH-003a` AND `SEC4-GH-004` fire. This is intentional: the
  vulnerabilities are independent — an attacker could exploit the
  agent-as-sink path even if the shell-sink were quoted, and vice
  versa. The reporter collapses duplicate findings per line where
  applicable, but the underlying rule IDs stay distinct so users
  filtering by rule family see the full risk picture.

### What's NOT in this RFC (but belongs in the conversation)

- **Class 4 (AI-generated-code provenance)** — agent-authored PRs
  merging without human review, `--no-verify` skips, bypass of
  pre-commit hooks. These are platform-posture questions (GitHub API
  checks: review state, commit signer, required-reviewer config) and
  live under `taintly/platform/`, not the rule engine. Tracked as
  a separate design note; see the project notes attached to the
  extension-planning discussion.
- **Rate-limiting scheduled AI workflows.** `AI-GH-008` in the
  earlier draft ("AI agent invoked from `schedule:` with no rate
  limit") is rate-limit policy, not a semantic rule. Deferred — it's
  worth doing but sits outside the oracle's scope.
