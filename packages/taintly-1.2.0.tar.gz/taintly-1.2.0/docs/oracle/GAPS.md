# Oracle grammar — coverage gaps

Per `docs/oracle/EXTENSIONS.md` §EXT-B, every `RegexPattern` rule
should have at least one UNSAFE_BY_CONSTRUCTION sample firing on it.
Rules that don't are listed in `_REGEX_GAPS_BY_FAMILY` in
`tests/integration/test_grammar_oracle.py` and tracked here as
follow-up work.

A coverage-gap PR picks one family below, writes UNSAFE samples whose
`expected_rules` includes each rule in the family, removes the
corresponding entries from `_REGEX_GAPS_BY_FAMILY`, and updates this
file. Other oracle pattern types (Context/Sequence/Block/Path/Taint)
are structurally exempt — they require multi-line / cross-step
context the oracle doesn't model — and are NOT listed here.

## Open gaps by family

### SEC2 — identity / secrets in workflow text (4 rules)

`SEC2-GH-001`, `SEC2-GL-001`, `SEC2-JK-001`, `SEC2-JK-002`.

Sample shapes to write: workflow YAML / Jenkinsfile fragments that
declare identity material (token names, MFA flags, identity-provider
config) inline rather than via secrets store. The challenge is that
some of these rules pattern-match on declarative posture
(`auth: token`-style YAML keys) which sits at the boundary between
"single-fragment text" and "file-scope structure" — pick the rules
whose regex is line-level first.

<!-- SEC3 family closed — see "Closed gaps" section below. -->


### SEC4 — poisoned-pipeline-execution patterns (10 rules)

`SEC4-GH-002`, `SEC4-GH-006`, `SEC4-GH-007`, `SEC4-GH-008`,
`SEC4-GH-009`, `SEC4-GH-010`, `SEC4-GH-012`, `SEC4-GL-004`,
`SEC4-JK-003`, `SEC4-JK-005`.

Sample shapes to write: the precise per-rule attack surfaces. Each
SEC4 rule typically targets one specific PPE shape (e.g. workflow
modifying `$GITHUB_PATH`, `$GITHUB_ENV` writes from untrusted input,
GitLab `script:` with multi-line commands consuming `$CI_*`). Read
each rule's `description` and its `Rule.test_positive` to see the
intended shape, then write a corresponding minimal grammar sample.

### SEC6 — credential hygiene (16 rules)

`SEC6-GH-001`, `SEC6-GH-003`..`SEC6-GH-006`, `SEC6-GL-001`,
`SEC6-GL-003`..`SEC6-GL-005`, `SEC6-GL-007`, `SEC6-GL-008`,
`SEC6-JK-001`, `SEC6-JK-004`..`SEC6-JK-007`.

Sample shapes to write: literal hardcoded secret strings (Stripe-
style `sk_live_...`, AWS access keys, GitHub PATs, JWTs), in
workflow `env:` blocks and inline shell. Be careful with the linting
side: oracle samples that LOOK like real secrets may trip pre-commit
hooks (gitleaks). Use clearly-fake but format-valid examples — the
secret-string rules pattern-match on format, not on validity.

### SEC7 — runner / job hardening text patterns (6 rules)

`SEC7-GH-001`, `SEC7-GH-002`, `SEC7-GL-001`, `SEC7-JK-001`..`SEC7-JK-003`.

Sample shapes: self-hosted runner labels without isolation hints,
inline `runs-on: [self-hosted]` blocks, Jenkinsfile `agent { label }`
constructs naming non-isolated agents.

### SEC8 — third-party service text patterns (5 rules)

`SEC8-GH-002`, `SEC8-GH-003`, `SEC8-JK-001`..`SEC8-JK-003`.

The first two are the implicit-`:latest` rules for GitHub Actions
(image with no tag at all). Sample shapes: `image: postgres` (no
`:tag`), `image: redis`, etc. The Jenkins variants target
`docker.image('foo')` calls without explicit tags.

### SEC9 — Jenkins artifact integrity text patterns (1 rule)

`SEC9-JK-001`.

Sample shape: Jenkinsfile `archiveArtifacts` / `publishHTML` calls
without integrity verification (no `fingerprint: true`, no
`stash`/`unstash` hash check).

### SEC10 — logging / visibility config patterns (2 rules)

`SEC10-GH-003`, `SEC10-GL-001`.

Sample shapes: workflows that disable step logging (`set +x` style),
or disable artifact retention. The challenge is most logging rules
are file-scope (whole-workflow has no logging step) — pick the line-
level subset of these rules first.

## Closed gaps (for future provenance)

### SEC3 — supply-chain pinning (9 rules) — closed

Closed by the SEC3 grammar-samples PR (step #4 of the EXT-A..EXT-E
follow-up chain). Added 7 new UNSAFE categories in
`tests/integration/test_grammar_oracle.py`:

- `github_unpinned_action_ref` (3 samples) — `SEC3-GH-001`, `SEC3-GH-002`, `SEC3-GH-003`
- `github_docker_action_no_digest` (1 sample) — `SEC3-GH-005`
- `pip_dependency_confusion_extra_index` (1 sample) — `SEC3-GH-008`
- `gitlab_remote_include_no_integrity` (1 sample) — `SEC3-GL-001`
- `jenkins_shared_library_no_sha` (1 sample) — `SEC3-JK-001`
- `jenkins_grab_no_version` (1 sample) — `SEC3-JK-002`
- `jenkins_docker_image_mutable_tag` (1 sample) — `SEC3-JK-003`

Each sample has an `expected_rules` set naming the specific SEC3
rule it exercises. Corresponding entries removed from
`_REGEX_GAPS_BY_FAMILY` in `test_grammar_oracle.py`. Each category
is documented in `DESIGN.md`'s UNSAFE table with spec references
(OWASP CICD-SEC-3 plus per-platform documentation).

---

## Future families

### AI-* — AI-agents-in-CI (RFC: EXTENSIONS.md §EXT-F)

Proposed ~10 rules across three subclasses; none implemented yet.
Tracking here so a future grammar PR can pick the family and write
the samples.

| Subclass | Rules (planned) |
|---|---|
| Rogue AI (class 1) | `AI-GH-020` (unvetted agent action), `AI-GH-021` (non-default inference endpoint), `AI-GH-022` (agent exposed to off-topic secrets), `AI-GH-023` (agent + network egress + secrets) |
| Indirect prompt-injection enabling conditions (class 2) | `AI-GH-030` (unrestricted file-read), `AI-GH-031` (fetch URL from event context), `AI-GH-032` (MCP tool-use without `require-approval: true`), `AI-GH-033` (reads from PR-writable `CLAUDE.md` / dependency manifests) |
| Direct prompt injection (class 3) | `AI-GH-003a` / `AI-GH-003b` / `AI-GH-003c` — PR title/body, issue/comment body, `github.head_ref` fed to an agent as input |

Canonical attack shapes per subclass are documented in EXT-F §Design
and in the rule descriptions when implemented. Semantic prompt-
injection content detection (hidden instructions in a README,
zero-width text in an issue body) is **explicitly out of scope** —
see EXT-F §FR-F6 and §NG-F1.

### Class-4 platform-posture checks (not rule-engine territory)

- Agent-authored PRs merged without a human-attributable review.
- Agent commits that bypass pre-commit hooks (`--no-verify`).
- Missing required-reviewer configuration on branches where agents
  write.

These are GitHub API posture checks, not workflow-YAML matchers.
They live (or will live) under `taintly/platform/github_checks.py`
alongside the existing `PLAT-GH-*` / `ACCT-GH-*` checks. Design
note: `docs/oracle/DESIGN_NOTE_ai_agent_posture.md`.

Planned check IDs (four, not three — `002` split into `a/b` per
review; the two heuristics have different confidence levels and
shouldn't share a rule ID):

| ID | Check |
|---|---|
| `AI-POSTURE-GH-001` | agent-authored PRs merged without human review (honest-case only — see design note for disguised-agent limitation) |
| `AI-POSTURE-GH-002a` | commit message explicitly documents `--no-verify` (high confidence) |
| `AI-POSTURE-GH-002b` | agent commit in repo with `.pre-commit-config.yaml` and gate-able files (medium confidence, `review_needed=True`) |
| `AI-POSTURE-GH-003` | required-reviewer config missing on default branch (high confidence, API-directly-observable — implement first) |
