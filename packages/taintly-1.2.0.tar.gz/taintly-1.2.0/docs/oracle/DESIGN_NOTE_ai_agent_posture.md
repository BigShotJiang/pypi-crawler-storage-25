# Design note — AI-agent posture checks (platform layer)

This is a design note, not a full RFC. Scope is narrow enough that a
short write-up plus the eventual per-check code comments is the right
altitude — see the Tier-B/Tier-C convention in
`docs/oracle/EXTENSIONS.md`'s preamble.

## Problem

AI agents that land changes in a repository introduce a provenance
question the rule engine can't answer: "was the change a human's
intentional commit, or an agent's un-reviewed suggestion that
bypassed the usual gates?" The rule engine scans workflow YAML. This
question lives in GitHub's review / branch-protection / commit-
metadata APIs.

Three observable conditions are worth flagging:

1. **Agent-authored PRs merged without a human-attributable review.**
   An agent opens a PR, CI passes, the repo's branch protection
   treats the agent's own commits as sufficient, the PR merges
   without a human seeing it.
2. **Agent commits that bypass pre-commit hooks.** `--no-verify`
   commits by an agent identity, or by workflows that explicitly set
   `git commit --no-verify`. This silently skips linters and secret
   scanners that protect the mainline.
3. **Missing required-reviewer config on branches where agents
   write.** Orthogonal to (1) — even if (1) currently holds, a branch
   with no required-reviewer setting means (1) could stop holding
   tomorrow with no audit trail.

## Why this isn't rule-engine territory

The rule engine reads text files (workflow YAML, Jenkinsfiles). The
three conditions above are observable only via GitHub's API:

- `/repos/{owner}/{repo}/pulls/{n}/reviews` for PR review state.
- Commit object `author.email` / `verification.signature` for
  authorship heuristics.
- `/repos/{owner}/{repo}/branches/{branch}/protection` for required-
  reviewer config.

The existing `taintly/platform/` layer already makes exactly these
kinds of checks (`PLAT-GH-*`, `ACCT-GH-*`). Adding AI-agent posture
checks there is a natural fit.

## Proposed checks

Three new `AI-POSTURE-GH-*` functions in
`taintly/platform/github_checks.py`:

### `AI-POSTURE-GH-001` — Agent-authored PRs merged without human review

For recent merged PRs (last 30 days, configurable), check whether the
head-commit author matches an agent-identity heuristic:

- Author email ending in `@users.noreply.github.com` with bot-like
  local part (`github-actions[bot]`, `claude[bot]`, `cursor[bot]`,
  …).
- Co-authored-by trailers naming known agents.

Then check whether `reviews` on the PR contains any
`author.type == "User"` entry with `state == "APPROVED"`. Absence of
a human-approved review on an agent-authored merged PR is a finding.

Severity: `MEDIUM` by default (the maintainer's policy question: are
agent merges allowed without human review?). Rule should be
`review_needed=True` so users can set their own policy threshold.

*Honest-case-only detection, mandatory in the description.* This
check catches the agent when it identifies itself as a bot — the
common case today. It does NOT catch:

- Agents that commit with a real user's identity (Cursor's default,
  Aider, Claude Code when the human has configured `user.email`).
- Agents that impersonate via a PAT-authenticated commit under a
  human's account.

The rule's `description` field MUST state this up front. A user
reading "detects agent-authored PRs merged without review" would
otherwise conclude they have more coverage than they do. If you
want coverage of the disguised case, that's a separate tool class
(commit-provenance attestation, signed commits with verified
agent identity, etc.) — out of scope here.

### `AI-POSTURE-GH-002a` — Commit explicitly documents `--no-verify`

Scan recent commit messages for `--no-verify` as a literal
substring. Some agents (and some humans) document the bypass in the
commit message. When present, it's a high-confidence signal: the
author said so.

Severity: `HIGH`, `confidence="high"`.

### `AI-POSTURE-GH-002b` — Agent commit in repo with pre-commit hooks

Scan recent commits for a compound condition:

- Author email in the known-agent list (same heuristic as
  `AI-POSTURE-GH-001`), AND
- Repository root contains `.pre-commit-config.yaml`, AND
- The commit's file set includes paths the hook config would
  normally gate (Python files with a configured formatter, YAML
  files with a configured linter, etc.).

A direct API-level hook-bypass signal doesn't exist. This rule is
heuristic: "an agent committed, there are hooks configured, and at
least one hook SHOULD have fired." Useful as a review-needed
signal; not a high-confidence finding.

Severity: `MEDIUM`, `confidence="medium"`, `review_needed=True`.

*Why split 002a and 002b:* user filtering by high-confidence
findings should see 002a (the author said "--no-verify") but NOT
002b (heuristic). Combining them under one `confidence="medium"` ID
averages the two signals and loses the ability to surface the
strong one. Reporter filtering is what makes this split worth the
extra rule ID.

### `AI-POSTURE-GH-003` — Required-reviewer configuration missing on agent-writable branches

Query branch protection on `main` / default branch. Finding fires
if:

- The `required_pull_request_reviews` block is absent, OR
- `required_approving_review_count` is `0`, OR
- `bypass_pull_request_allowances.apps` or `.users` includes an
  agent identity.

This is the structural version of `AI-POSTURE-GH-001`: (001) catches
"a specific PR slipped through," (003) catches "the config that
allowed it."

Severity: `HIGH`. High-confidence (API-directly-observable).

## Non-goals

- Detecting agent *behaviour* (what the agent reasoned, what tools
  it called). Runtime observability is a different tool.
- Detecting prompt-injection content (same as EXT-F §FR-F6).
- Gating on agent identity at all. This is a posture layer — it
  reports, the maintainer decides. `review_needed=True` keeps the
  findings in an "analyst review" lane rather than hard-failing CI.

## Tests

- Unit tests with `StubClient` (the pattern used by existing
  `PLAT-GH-*` checks): construct synthetic `/pulls/:n/reviews`
  responses, assert the posture function emits / suppresses findings
  correctly.
- Integration test that runs against a fixture repo with known
  agent-authored commits and verifies the output.

## Reporter handling

Posture findings (especially `review_needed=True` ones) are
observationally different from rule findings. A rule finding is
"the scanner verified this condition in your code" — deterministic,
reproducible, shippable as a SARIF entry a code-scanner tool can
track. A posture finding is "the scanner flagged this for your
attention based on API state at scan time" — non-deterministic
across time, policy-dependent, needs a human judgement call.

The reporters (HTML, text, JSON, SARIF) should visually / structurally
separate the two:

- **Text / HTML reporter**: posture findings go in their own
  "Posture observations" section beneath the main rule findings.
  `review_needed=True` items are badged as "review" not "fail" so
  the CI-exit-code ladder reads correctly at a glance.
- **JSON / SARIF reporter**: add a `kind` discriminator
  (`"rule"` vs `"posture"`) on each finding. SARIF already supports
  this via `properties.kind` and the downstream tools that consume
  SARIF know how to handle it.
- **Scorer**: `review_needed=True` findings DO NOT subtract from
  the scanner's A-F grade the way a confirmed-risk finding does.
  The grade measures "what did the scanner prove broken"; review
  items measure "what does the scanner think is worth a human
  look." Conflating them is the path to alert fatigue.

This reporter work belongs in the implementation PR for
`AI-POSTURE-GH-*`, not as a prerequisite — but the design intent is
worth writing down now so the implementation doesn't default to
"just append to the existing finding list" and produce a confused
report.

## Migration

- New file `taintly/platform/ai_agents.py` (or additions to
  `github_checks.py`; the split is an aesthetic call).
- `taintly/__main__.py` wires the new checks into `--github-org`
  / `--github-repo` runs alongside the existing posture checks.
- README / CONTRIBUTING documents the new check IDs and how
  `review_needed` findings flow through the reporter (per the
  §"Reporter handling" section above).

## What this does NOT replace

Still need EXT-F's `AI-*` workflow rules to cover:

- What the workflow declares (agent action, its permissions, its
  inputs).
- The structural injection surfaces a workflow creates.

Posture checks answer "did an agent's change land cleanly?"; EXT-F
rules answer "is the workflow configured in a way an agent could
abuse?" Both are necessary; neither subsumes the other.
