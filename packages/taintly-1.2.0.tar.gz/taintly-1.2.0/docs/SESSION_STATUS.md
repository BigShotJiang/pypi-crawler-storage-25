# taintly v2 — session status

Session date: 2026-04-14
Branch at time of write: `claude/v2-readme-update` (off `main` @ `4446bc2`)

---

## Merged this session (11 PRs)

| PR | Phase | What landed |
|----|-------|------------|
| #5  | pre-v2    | Windows cp1252 encoding fix + executive summary in text report |
| #6  | pre-v2    | Force ASCII when stdout is piped/redirected on Windows |
| #7  | pre-v2    | 29 rule-documentation corrections (GitLab/GitHub/Jenkins remediation text audited against canonical docs) |
| #8  | v2 1a     | GitHub LOTP — 3 rules (LOTP-GH-001/003/004) |
| #9  | v2 1a     | Shared build-tool anchor + `--fix-npm-ignore-scripts` opt-in fix |
| #10 | v2 1a     | GitLab + Jenkins LOTP (LOTP-GL-001, LOTP-JK-001) |
| #11 | v2 2      | GitHub platform-posture scanning (5 rules, Rulesets-aware, secure token handling) |
| #12 | v2 5      | GitLab platform-posture scanning (5 rules) |
| #13 | v2 3      | Self-contained HTML report generator (`--format html`) |
| #14 | v2 1b     | Shallow taint MVP (TAINT-GH-001) — single-hop `${{ }}` → env var → `run:` |
| #15 | chore     | `.gitignore` the `.claude/` worktree scratch dir |

### Final state on `main` (after PR #15)

- 109 file-based rules
  - GitHub: 47 (inc. 3 LOTP + 1 TAINT)
  - GitLab: 31 (inc. 1 LOTP)
  - Jenkins: 31 (inc. 1 LOTP)
- 10 API-based platform-posture rules (5 GH + 5 GL)
- 241 pytest tests
- `--self-test`: 261/261 positive + 285/285 negative samples
- `--self-test --mutate`: 3687/3730 kills (98.8%)

---

## OWASP CI/CD coverage (current)

| Category | GitHub | GitLab | Jenkins |
|---|---:|---:|---:|
| SEC-1  | 1 | 2 | 2 |
| SEC-2  | 3 | 2 | 2 |
| SEC-3  | 4 | 3 | 3 |
| SEC-4  | 20 | 6 | 6 |
| SEC-5  | 1 | 1 | 1 |
| SEC-6  | 6 | 8 | 7 |
| SEC-7  | 4 | 1 | 3 |
| SEC-8  | 4 | 3 | 3 |
| SEC-9  | 2 | 3 | 3 |
| SEC-10 | 2 | 2 | 1 |

Plus 5 PLAT-GH-* and 5 PLAT-GL-* API-based platform rules.

---

## Where I stopped

Mid-way through a README update on branch `claude/v2-readme-update`.
Counts + mutation rates were gathered (see above); the actual README
edits had not yet been written when the session was interrupted.

---

## Still outstanding — planned but not shipped

### v2 content
- **Phase 4 — Cross-workflow analysis** (the last planned v2 phase).
  Multi-file parsing, `workflow_run` producer→consumer graph,
  `workflow_call` / composite-action coverage, artefact handoff
  verification. Architecturally the most complex remaining piece.
- **Correlation annotations**: when a platform-finding matches a
  file-finding (e.g. PLAT-GH-007 default-write-token + SEC2-GH-002
  no permissions block), annotate the file finding with platform
  context rather than rewriting severity. Deferred at Phase 2 time.
- **Remaining platform rules**: 9 more GitHub (PLAT-GH-003/004/006/
  009-014) + 4 more GitLab (PLAT-GL-005/006/007/009).

### Refactors flagged by the taint subagent
1. Engine pattern contract `(content, lines) -> list[(int, str)]`
   flattens away structured taint metadata. A richer `Match` object
   (source expression, env var, source line ≠ sink line, flow kind)
   would let reporters render taint chains in SARIF / HTML.
2. `_split_into_job_segments` in `models.py` is private but genuinely
   useful — worth promoting to public API.
3. `Finding` has no way to carry related lines; `related_lines:
   list[int]` would let taint point at both source and sink.
4. Mutation operator `indent_shift` reshapes YAML structurally; the
   taint rule correctly rejects malformed YAML so 67/68 kills — the
   one "survivor" is invalid YAML. Mutation ops need per-rule
   opt-outs (also useful for ContextPattern).

### HTML-report polish (flagged by that subagent)
- Sort-preserves-expansion: currently a re-sort keeps detail rows
  expanded but doesn't reset them; intentional but noisy on large
  tables.
- No keyboard (Enter/Space) activation for row expansion.
- Fixed SVG width (360px), doesn't scale on narrow viewports.
- `aria-sort` updates only on the last-clicked header.

### Never to ship (explicit cuts)
- LLM-assisted deep review — low ROI, prompt-injection risk, high
  noise. Cut in the v2 critical review.
- Tier 3 desktop app with scheduled scanning / dashboards — v3 scope,
  not v2.
- "Trend comparison" section in the HTML report — incompatible with
  stateless-process principle unless the user supplies a previous
  scan JSON.

---

## Administrative debris to clean up next session

- Local branches `claude/v2-html-report`, `claude/v2-platform-github`
  (etc.) that exist locally but were already merged or replaced by
  `-v2` variants. `git worktree list` has two `.claude/worktrees/agent-*`
  entries that need `git worktree remove` — now that `.claude/` is
  gitignored (PR #15) they won't keep showing as untracked, but the
  worktrees themselves still exist.
- README update was interrupted (this branch).
