# Roadmap — path to v1.0 and beyond

A concrete, phased plan. Each phase has work items, effort estimates, dependencies, and exit criteria. The grade target is **A+ / 96** after Phase 2; Phase 3 is expansion.

<!-- Maintainers: treat this as a living document. Tick items off as they
     ship; drop items that become irrelevant rather than leaving them pending
     indefinitely. Real movement > tidy lists. -->

## Current grade

| Dimension | Grade | Source of claim |
|---|---|---|
| Detection breadth | A− | 118 rules × 3 platforms |
| Detection depth | A− | 7 TAINT rules with multi-hop + `$GITHUB_ENV` + `$GITHUB_OUTPUT` bridges |
| Precision | A | 605/605 self-tests, 100% mutation kill, 20 property tests |
| Recall | B+ | No published benchmark numbers — qualitative only |
| Usability | A | Baseline/diff, auto-fix, 5 output formats, score+debt profile |
| Integration | A | GH Action + GL Component + pre-commit + 12 subprocess tests |
| Code quality | A− | mypy strict (minus `disallow_untyped_defs`), 80% branch coverage |
| Dogfooding | A+ | Self-scan 100/100; own CI gates on own output |
| Threat modelling | A | 118/118 rules carry STRIDE + threat narrative |
| Innovation | A | Platform posture audit, TAINT, cluster scoring |
| Documentation | B+ | Strong INTEGRATION.md; was missing SECURITY / CHANGELOG / CONTRIBUTING before this PR |
| Performance | B | Fast in practice, no regression gate |

**Overall: A− / 91**. Gaps to close: measurable precision+recall, proper YAML parser, performance gate.

---

## Phase 0 — v1.0 release blockers (Week 1)

Everything that prevented external adoption. Phase 0 originally targeted a PyPI release; after repeated setuptools-scm / Trusted-Publisher issues we dropped PyPI and ship exclusively via GitHub Releases (install with `pip install git+https://github.com/Nellur35/taintly@v1`).

| # | Item | Effort | Status |
|---|---|---|---|
| 0.1 | `SECURITY.md` with 90-day disclosure policy | 2h | ✅ shipped in this PR |
| 0.2 | `CHANGELOG.md` (Keep-a-Changelog format, populated from PR history) | 3h | ✅ shipped in this PR |
| 0.3 | `CONTRIBUTING.md` with rule-authoring template + CI cheat sheet | 3h | ✅ shipped in this PR |
| 0.4 | `.github/workflows/release.yml` — PyPI trusted publishing on tag push | 1d | ✅ shipped in this PR |
| 0.5 | `README.md` quickstart pointing at real `pip install` + composite Action | 2h | ✅ shipped in this PR |
| 0.6 | **Maintainer**: configure PyPI trusted publisher (one-time) | 30m | ⏳ external |
| 0.7 | **Maintainer**: cut `v0.9.0` pre-release, shake out PyPI flow | 2h | ⏳ |
| 0.8 | **Maintainer**: cut `v1.0.0` after ~1 week of `v0.9.x` soaking | 2h | ⏳ |

**Exit criteria:** `pip install git+https://github.com/Nellur35/taintly@v1` works. Composite Action resolves at `Nellur35/taintly@v1`.

**Risks:** PyPI project name conflict (check now — `taintly` appears available as of the current search). sdist missing `templates/` or `docs/` — mitigated by the release workflow's `python -m build` + install-test step.

---

## Phase 1 — Measurable quality (Weeks 2–4)

Turn qualitative claims into numbers. Current grade on recall is B+ because we can't point at an F1 value. Precision is A but only because 605 hand-crafted tests pass — that's coverage, not real-world precision.

### 1.1 Benchmark corpus (Week 2, ~2.5 days)

- Expand `benchmark/corpus/` to ≥500 real-world workflows, drawn from:
  - Top-100 OSS Python / JS / Rust projects (public workflows, licence-mirrored)
  - Every CVE-referenced workflow (tj-actions, Trivy, Ultralytics, Codecov) pre- and post-fix
  - The existing `tests/fixtures/` set
- **Labels** per (workflow × rule-ID): `positive` / `negative` / `unknown`. Aim for ~3000 labelled pairs; `unknown` excluded from recall calculations.

### 1.2 Benchmark runner + reporting (Week 3, ~3 days)

- `python -m benchmark run` emits `{rule_id, tp, fp, fn, precision, recall, f1}` per rule + aggregate per platform as JSON.
- Weekly CI job commits results to `benchmark/results/<date>.json` on a `benchmarks` branch.
- `docs/BENCHMARKS.md` auto-updated: F1 per rule, per platform, trended over time.

### 1.3 Head-to-head benchmark (Week 3, ~2 days)

Run each scanner on the same labelled corpus. Publish a comparison table with F1 per category.

- `actionlint` (GitHub Actions syntax/lint)
- `zizmor` (GitHub Actions security)
- `poutine` (pipeline security)
- `checkov` (IaC / some workflow coverage)

This is the differentiator claim — needs evidence.

### 1.4 Performance regression gate (Week 4, ~2 days)

- `pytest-benchmark` on hot paths with representative-workflow fixtures (small / medium / huge).
- Baseline committed to `tests/benchmarks/baselines.json`.
- CI fails if median time regresses > 20% on any workflow class.
- Target: 1000-line workflow scanned in < 200ms.

### 1.5 Recall triage (Week 4, ~1 day)

Where benchmark shows F1 < 0.7 for a rule, either fix or mark as `confidence: low` so the scorer weights it down. The goal is to stop rules from overclaiming.

**Exit criteria:** `docs/BENCHMARKS.md` publishes measurable F1. CI has a performance gate. Precision grade moves A → A+; recall moves B+ → A.

**Risks:** labelling is tedious. Mitigation: bootstrap labels from the scanner's own output, then have a second reviewer spot-check ~10%. The `unknown` escape hatch keeps the corpus growable without blocking the first publish.

---

## Phase 2 — Parser + depth (Weeks 5–8)

The scanner is regex-based. The strongest rules (TAINT, scope=job ContextPattern) work around this by doing their own segmentation. A proper structural access eliminates whole classes of edge case.

### 2.1 Structural YAML access (Week 5, ~3 days)

**Non-goal**: add PyYAML as a runtime dep. Zero-dep is a differentiator.

Two options; recommend (B):

- **(A)** Vendor `tiny-yaml` (~300 LoC permissive-licensed YAML 1.1 parser)
- **(B)** Keep line-level scanner; add a structural index alongside (line → yaml-path) built with a hand-rolled parser that fails gracefully to regex on parse errors

(B) preserves existing rules unchanged and adds capability.

### 2.2 Migrate high-value rules to structural checks (Week 6, ~5 days)

Migration candidates — rules where line-based regex is brittle:

- `SEC4-GH-001` (PRT + checkout) — structural can check `on.pull_request_target` + `jobs.*.steps[*].uses == actions/checkout` with `ref == github.event.pull_request.head.sha`
- `SEC2-GH-002` (missing permissions) — exact boundary check
- `SEC9-GH-005` (cache key poisoning) — precise about `key:` nesting under `with:`
- All `_split_into_job_segments` consumers

Migration path: parser-backed check runs alongside regex for 2 weeks; cut over when F1 matches or exceeds.

### 2.3 Cross-workflow analysis (Week 7, ~4 days)

TAINT engine currently stops at the workflow boundary. A PRT workflow calling a reusable workflow via `uses: ./.github/workflows/build.yml` passes taint through inputs. Add:

- Workflow index (all workflows in repo indexed by file path)
- `workflow_call` input → reusable workflow taint-source registration
- New rule **TAINT-GH-005** — cross-workflow PR-context → reusable-workflow `run:`

### 2.4 Fuzz expansion (Week 8, ~3 days)

Current fuzz has ~50 inputs. Add:

- PowerShell injection shapes (behind the SEC6-GH-007 `iex(` FP class that was fixed earlier was more)
- CRLF line-ending fixtures
- BOM-prefixed YAML
- Anchor / alias abuse (`*` / `&` / `<<`)

**Exit criteria:** structural YAML access live, 5+ rules migrated, cross-workflow taint live, fuzz at ~150 inputs. Detection depth grade moves A− → A+.

**Risks:** YAML parser edge cases. Mitigated by the hybrid fallback — parser failures never crash, they just route to regex.

---

## Phase 3 — Breadth expansion (Weeks 9–12, optional)

Fill the platform matrix. Only expand to a new platform if Phase 1 benchmark shows existing platforms at F1 ≥ 0.8 — otherwise we're spreading thin.

| Platform | Effort | Why it matters |
|---|---|---|
| **Azure Pipelines** | 3w | Biggest market-share gap. `azure-pipelines.yml` + `.azure-pipelines/`. Structure similar to GitHub Actions. |
| **CircleCI** | 3w | `.circleci/config.yml`. Orbs have the same tag-vs-SHA pinning issue as Actions. |
| **Buildkite** | 2w | `.buildkite/pipeline.yml`. Plugin allowlisting is the supply-chain control point. |

**Exit criteria:** 5 platforms with F1 numbers. Breadth grade A− → A.

**Risks:** rule-authoring fatigue. Gated on Phase 1 benchmark evidence.

---

## What to NOT do

Deliberately deferred:

- **Full mypy `disallow_untyped_defs`** — low bug-signal per hour. Ratchet opportunistically; not a milestone.
- **ruff PTH rules** — `os.path` → `pathlib` migration is style churn with no bug signal.
- **LLM-powered SAST** — currently trendy, expensive for a zero-dep tool. Revisit in 2027.
- **Finding-grouping redesign** — current cluster model works. Don't over-engineer.
- **Web UI / server mode** — out of scope. The tool is a CLI; GitHub Security / GitLab Security dashboards are the UI.

---

## Dependency graph

```
Phase 0 ─────────────────┐
                          ├─► Adoption possible
Phase 1 (benchmark)      ─┘
                            ┐
Phase 2 (parser + depth) ───├─► Stronger detection with proof
Phase 1 (benchmark proof) ──┘
Phase 3 (breadth)  ─ gated on Phase 1 F1 ≥ 0.8 on existing platforms
```

Phases 0 and 1 are independent and can run in parallel. Phase 2 depends on Phase 1's benchmark existing (otherwise parser migration can't be verified). Phase 3 is strictly optional.

---

## Grade impact

| After | Overall | Delta | Reason |
|---|---|---|---|
| Today | 91 | — | A− baseline |
| Phase 0 | 92 | +1 | Installable; community artefacts present |
| Phase 0 + 1 | **94** | +3 | Recall + precision become numbers, perf gate live |
| Phase 0 + 1 + 2 | **96** | +2 | Depth, cross-workflow, parser robustness |
| Phase 0 + 1 + 2 + 3 | 97 | +1 | Diminishing returns without benchmark proof per new platform |

---

## Milestones (GitHub)

Proposed GitHub Milestones aligned to the phases:

- **v1.0.0** — Phase 0 complete. Installable. Governance artefacts present.
- **v1.1.0** — Phase 1 complete. First `BENCHMARKS.md` published.
- **v1.2.0** — Phase 2 complete. Structural parser live, cross-workflow taint.
- **v2.0.0** — Phase 3 complete. Azure Pipelines + CircleCI + Buildkite.

The v2 bump reflects that new-platform coverage can break consumers' `--platform auto` assumption on repos that happen to have all three config-file types.
