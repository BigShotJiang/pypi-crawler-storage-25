# CI Integration

Copy-pasteable recipes for running `taintly` in your pipeline. Ranked by value: the basic PR gate is the minimum viable setup; the later patterns solve specific operational problems.

<!-- This document is user-facing. Keep examples copy-pasteable and
     trim any commentary that isn't directly actionable. -->

---

## Quick start (GitHub Actions)

The composite action at the root of this repository gives you a one-step integration:

```yaml
# .github/workflows/taintly.yml
name: taintly
on:
  pull_request:
  push: { branches: [main] }
permissions:
  contents: read
jobs:
  audit:
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/checkout@v4
        with: { persist-credentials: false }
      - uses: Nellur35/taintly@v1
        with:
          fail-on: HIGH
```

Exit 1 when any HIGH/CRITICAL fires. That's the minimum viable integration.

### Without the composite action

If you'd rather call the CLI directly:

```yaml
- uses: actions/setup-python@v5
  with: { python-version: "3.12" }
- run: pip install git+https://github.com/Nellur35/taintly@v1
- run: taintly . --fail-on HIGH --no-color
```

---

## Integration patterns

### 1. SARIF upload to the Security tab

Findings become inline annotations on the GitHub Code Security tab, alongside CodeQL. The `upload-sarif: true` input makes the action write `taintly.sarif` for the caller to upload — the upload step stays in your workflow so the `security-events: write` permission is declared where a reviewer can see it.

```yaml
permissions:
  contents: read
  security-events: write
jobs:
  audit:
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/checkout@v4
        with: { persist-credentials: false }
      - uses: Nellur35/taintly@v1
        id: audit
        with:
          fail-on: HIGH
          upload-sarif: true
        continue-on-error: true      # let the upload run even if findings exist
      - uses: github/codeql-action/upload-sarif@v3
        if: always()
        with:
          sarif_file: ${{ steps.audit.outputs.sarif-file }}
          category: taintly
```

### 2. Baseline + diff — adopting on a repo with existing findings

If the tool fires on 200 pre-existing findings, nobody will fix them. Baseline snapshot once, then only fail on net-new ones.

**One-time maintainer step:**

```bash
pip install git+https://github.com/Nellur35/taintly@v1
taintly . --baseline .taintly-baseline.json
git add .taintly-baseline.json
git commit -m "Snapshot taintly baseline"
```

**In CI, enable baseline mode:**

```yaml
- uses: Nellur35/taintly@v1
  with:
    fail-on: HIGH
    baseline: true
    # baseline-file defaults to .taintly-baseline.json
```

Findings in the baseline are suppressed; new regressions fail.

### 3. Config-driven suppressions

For anything more than a handful of excludes, commit `.taintly.yml`:

```yaml
version: 1
min-severity: MEDIUM
fail-on: HIGH
platform: github   # omit to auto-detect

exclude-rules:
  - SEC4-GH-002    # blanket suppressions (prefer targeted ignores below)

ignore:
  # Time-limited suppression — emits a warning after expires.
  - id: SEC4-GH-002
    path: .github/workflows/internal-only.yml
    reason: "internal-only workflow; fork triggers physically impossible"
    expires: 2026-09-01
    owner: platform-security@example.com

  # Path-wide suppression of a single rule.
  - id: SEC3-GH-001
    path: .github/workflows/vendor/

  # Path-wide suppression of all rules (use sparingly).
  - path: tests/fixtures/
```

The action auto-loads `.taintly.yml` from the scanned path. Set `config: custom-path.yml` if you store it elsewhere.

### 4. Weekly scheduled scan

Catches new rules landing in the scanner without a PR touching your CI:

```yaml
on:
  pull_request:
  push: { branches: [main] }
  schedule:
    - cron: "0 9 * * 1"    # Mondays 09:00 UTC
```

### 5. GitLab CI

Three integration shapes — pick based on your GitLab version and how the team likes to manage CI.

#### 5a. CI/CD Component (GitLab 16.11+, recommended)

```yaml
# .gitlab-ci.yml
include:
  - component: $CI_SERVER_FQDN/nellur35/taintly/taintly@v1
    inputs:
      fail-on: HIGH
```

The component registers a job that installs taintly, scans the repo, writes a SAST report artefact for the MR widget, and fails the pipeline on HIGH+. Full input reference in `templates/taintly/README.md`.

Typical patterns:

```yaml
# Baseline + diff for adopting on a legacy project
- component: $CI_SERVER_FQDN/nellur35/taintly/taintly@v1
  inputs: { fail-on: HIGH, baseline: true }

# Dual-platform repo — include twice with platform overrides
- component: $CI_SERVER_FQDN/nellur35/taintly/taintly@v1
  inputs: { job-name: taintly-gitlab, platform: gitlab }
- component: $CI_SERVER_FQDN/nellur35/taintly/taintly@v1
  inputs: { job-name: taintly-github, platform: github }
```

#### 5b. Flat include template (GitLab pre-16.11)

```yaml
include:
  - project: nellur35/taintly
    file: /templates/taintly.gitlab-ci.yml
    ref: v1.0.0                  # pinned ref required — SEC3-GL-002

taintly:
  extends: .taintly
  variables:
    CICD_AUDIT_FAIL_ON: HIGH     # optional override
```

Same capability, older-GitLab compatible. Overrides via `variables:` instead of typed inputs.

#### 5c. Raw `script:` (no template)

For teams that don't want a shared template:

```yaml
taintly:
  image: python:3.12-slim
  stage: test
  script:
    - pip install git+https://github.com/Nellur35/taintly@v1
    - taintly . --fail-on HIGH --no-color --format sarif > gl-sast-report.json
  artifacts:
    when: always
    reports:
      sast: gl-sast-report.json
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
    - if: $CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH
```

`artifacts.reports.sast` is the magic path — GitLab auto-ingests it and surfaces findings in the MR widget and the Security dashboard.

#### 5d. GitLab-platform posture audit

Catches org-level misconfigurations (MR approval rules missing, variables unprotected, default branch unprotected) that no YAML scan can see:

```yaml
taintly-posture:
  image: python:3.12-slim
  script:
    - pip install git+https://github.com/Nellur35/taintly@v1
    - taintly --platform-audit --gitlab-project "$CI_PROJECT_ID" --no-color
  variables:
    GITLAB_URL: "https://gitlab.example.com"   # self-hosted only
  rules:
    - if: $CI_PIPELINE_SOURCE == "schedule"
```

Token needs `api` scope. Use a dedicated PAT stored as a Protected+Masked CI/CD variable — `$CI_JOB_TOKEN` can't read protected project settings.

#### 5e. Jenkinsfile consumers from GitLab

Same scanner handles Jenkinsfiles — just force the platform:

```yaml
taintly-jenkins:
  extends: .taintly
  variables:
    CICD_AUDIT_PLATFORM: jenkins
```

#### 5f. GitLab-specific gotchas

| Gotcha | Mitigation |
|---|---|
| `$CI_JOB_TOKEN` can't read protected variables | Use a dedicated PAT stored as Protected+Masked CI/CD variable |
| `only:/except:` are deprecated | Use `rules:` (the templates above already do) |
| `artifacts.reports.sast` caps at 20 MB | `--min-severity MEDIUM` to shrink reports on huge monorepos |
| Auto DevOps already runs SAST | Add taintly to stage `test` — it complements Auto DevOps (that scans app code; taintly scans the pipeline) |
| Component ref must be pinned | Use `@v1.0.0`, not `@main`, to satisfy SEC3-GL-002 on your own `.gitlab-ci.yml` |

### 6. Pre-commit hook (local, before push)

`.pre-commit-config.yaml`:

```yaml
repos:
  - repo: local
    hooks:
      - id: taintly
        name: taintly
        entry: taintly
        args: ["--fail-on", "HIGH", "--no-color", "."]
        language: system
        pass_filenames: false
        files: ^(\.github/workflows/.*|\.gitlab-ci\.yml|Jenkinsfile)
```

Runs only when a workflow or Jenkinsfile changes.

### 7. Auto-fix (opt-in)

`taintly --fix` applies deterministic fixes (pin SHAs, add `persist-credentials: false`, add missing `permissions:`). A safe pattern is a separate workflow that runs the fix and opens a PR:

```yaml
name: taintly auto-fix
on:
  workflow_dispatch:
  schedule:
    - cron: "0 3 * * 1"       # Mondays 03:00 UTC
permissions:
  contents: write
  pull-requests: write
jobs:
  fix:
    runs-on: ubuntu-latest
    timeout-minutes: 10
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install git+https://github.com/Nellur35/taintly@v1
      - run: taintly . --fix --no-color
      - uses: peter-evans/create-pull-request@v6
        with:
          branch: taintly/auto-fix
          title: "taintly: apply deterministic fixes"
          body: |
            Generated by `taintly --fix`. Review each change before merging.
            Run the scanner locally to verify: `taintly .`
```

### 8. Platform posture audit (weekly, needs a PAT)

Catches misconfigurations at the GitHub org/repo level that no YAML scan can see — branch protection missing, default write-token, fork-PR approval disabled, etc.

```yaml
on: { schedule: [{ cron: "0 10 * * 1" }] }
permissions:
  contents: read
jobs:
  posture:
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install git+https://github.com/Nellur35/taintly@v1
      - run: |
          taintly --platform-audit \
            --github-repo ${{ github.repository }} \
            --no-color
        env:
          # Fine-grained PAT with repo-admin read + org read (metadata + members).
          GITHUB_TOKEN: ${{ secrets.CICD_AUDIT_PAT }}
```

`${{ secrets.GITHUB_TOKEN }}` is **not** sufficient — it can't read org-level settings.

### 9. Organisation-wide scan

```yaml
on: { schedule: [{ cron: "0 11 * * 1" }] }
jobs:
  org-scan:
    runs-on: ubuntu-latest
    timeout-minutes: 60    # 100 repos ≈ 5 min; scale accordingly
    steps:
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install git+https://github.com/Nellur35/taintly@v1
      - run: |
          taintly \
            --github-org your-org \
            --format sarif \
            --no-color > org-findings.sarif
        env:
          GITHUB_TOKEN: ${{ secrets.CICD_AUDIT_PAT }}
      - uses: actions/upload-artifact@v4
        with: { name: org-findings, path: org-findings.sarif }
```

---

## Action inputs (reference)

| Input | Default | Purpose |
|---|---|---|
| `path` | `.` | Repo root or workflow dir |
| `version` | `>=1.0,<2` | pip version spec for the scanner |
| `python-version` | `3.12` | Python interpreter |
| `fail-on` | `HIGH` | Severity that fails the action |
| `min-severity` | `INFO` | Suppress findings below this level |
| `platform` | (auto) | `github`/`gitlab`/`jenkins` |
| `format` | `text` | Report format printed to the log |
| `config` | (auto) | Path to `.taintly.yml` |
| `exclude-rules` | — | Comma- or newline-separated rule IDs |
| `baseline` | `false` | Enable `--diff <baseline-file>` |
| `baseline-file` | `.taintly-baseline.json` | Baseline path |
| `upload-sarif` | `false` | Write SARIF file for upload step |
| `sarif-file` | `taintly.sarif` | SARIF output path |
| `extra-args` | — | Raw CLI arguments passed through |

Outputs:

| Output | Meaning |
|---|---|
| `exit-code` | Scanner exit code (0 clean, 1 HIGH, 2 CRITICAL) |
| `sarif-file` | Path to the SARIF report when `upload-sarif: true` |

---

## Exit code reference

| Code | Meaning |
|---|---|
| 0 | No findings |
| 1 | HIGH finding, OR `--fail-on` threshold reached |
| 2 | CRITICAL finding |
| 3 | Token / config error (e.g. `--platform-audit` without `GITHUB_TOKEN`) |
| 10+ | Internal errors (self-test / integration-test failures) |

`--fail-on` only **escalates** the failure threshold — it cannot suppress the built-in HIGH=1 / CRITICAL=2 behaviour. So:

- `--fail-on CRITICAL` is a no-op (CRITICAL already exits 2 by default).
- `--fail-on MEDIUM` starts failing on MEDIUM findings that would otherwise exit 0.
- To suppress HIGH-level gating entirely, use `--exclude-rule` or a config-file `ignore:` entry to drop the specific finding; severity-based de-escalation is intentionally not supported.

Use `continue-on-error: true` only on the SARIF-upload flow where you WANT the upload even on findings; for normal PR gates let the non-zero exit code block.
