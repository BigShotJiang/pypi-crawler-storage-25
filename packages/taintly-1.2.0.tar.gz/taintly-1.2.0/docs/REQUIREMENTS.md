# taintly Requirements Document

## Overview

taintly is a zero-dependency CI/CD pipeline security auditor for GitHub Actions and GitLab CI configurations. It detects security misconfigurations, dangerous patterns, and best-practice violations using pure Python 3.10+ stdlib.

---

## Functional Requirements

### F1 — Scanning

- **F1.1** Scan GitHub Actions workflow files (`.github/workflows/*.yml`, `*.yaml`)
- **F1.2** Scan GitLab CI config files (`.gitlab-ci.yml`, `ci/**/*.yml`)
- **F1.3** Auto-detect platform from directory structure; scan both if both present
- **F1.4** Accept a directory path or scan current directory by default
- **F1.5** Scan all repos in a GitHub org via REST API (`--github-org`)
- **F1.6** Scan all projects in a GitLab group via REST API (`--gitlab-group`)

### F2 — Rules

- **F2.1** Rule definitions are declarative data structures, not procedural code
- **F2.2** Adding a rule never requires modifying the scanning engine
- **F2.3** Each rule maps to an OWASP CI/CD Security Risk category
- **F2.4** Each rule has a severity: CRITICAL, HIGH, MEDIUM, LOW, or INFO
- **F2.5** Rules are organized by platform (GitHub/GitLab) and OWASP category
- **F2.6** Rule registry auto-discovers rules from module files — no manual registration
- **F2.7** Each rule includes positive test samples (must trigger) and negative samples (must not)

### F3 — Pattern Types

- **F3.1** `RegexPattern` — match regex against individual lines, with optional exclusions
- **F3.2** `AbsencePattern` — trigger when file does NOT contain a pattern
- **F3.3** `ContextPattern` — trigger when anchor AND requires patterns both exist in file
- **F3.4** `SequencePattern` — trigger when pattern_a appears without pattern_b within N lines
- **F3.5** `BlockPattern` — match pattern within the indented scope of a YAML block

### F4 — Output Formats

- **F4.1** Text format with ANSI color (default), filterable with `--no-color`
- **F4.2** JSON format for programmatic consumption
- **F4.3** CSV format for spreadsheet import and reporting
- **F4.4** SARIF 2.1.0 format for GitHub Advanced Security and GitLab security dashboard

### F5 — Severity Filtering

- **F5.1** Filter findings by minimum severity (`--min-severity`)
- **F5.2** Exit code 0 for no findings at or above threshold
- **F5.3** Exit code 1 for HIGH findings
- **F5.4** Exit code 2 for CRITICAL findings
- **F5.5** Exit code 3 for execution errors
- **F5.6** Exit codes 10-12 for self-test/mutation test failures

### F6 — Auto-Fix (Level 1)

- **F6.1** Pin unpinned actions to commit SHA (`--fix`)
- **F6.2** Add `persist-credentials: false` to checkout steps (`--fix`)
- **F6.3** Add minimal `permissions:` block if absent (`--fix`)
- **F6.4** Dry-run mode shows changes without writing (`--fix-dry-run`)
- **F6.5** SHA resolution via `git ls-remote` with local cache

### F7 — Remediation Guides (Level 3)

- **F7.1** Step-by-step guides for architectural remediations that can't be auto-fixed (`--guide`)
- **F7.2** List all available guides (`--guide list`)
- **F7.3** Print specific guide by rule ID (`--guide <RULE_ID>`)

### F8 — Self-Testing

- **F8.1** Validate all rules against their test samples (`--self-test`)
- **F8.2** Mutation testing to verify rule resilience (`--self-test --mutate`)
- **F8.3** Mutation operators: whitespace_pad, indent_shift, quote_swap, comment_inject, trailing_whitespace, case_change, line_break
- **F8.4** Test a specific rule by ID (`--self-test --rule <ID>`)

---

## Non-Functional Requirements

### NF1 — Zero Dependencies

- **NF1.1** No third-party packages required — stdlib only
- **NF1.2** No pip install, no requirements.txt, no Docker required
- **NF1.3** Requires Python 3.10+ only

### NF2 — Performance

- **NF2.1** Scanning a typical repo (50 workflow files) completes in under 2 seconds
- **NF2.2** SHA resolution is cached within a session to avoid redundant network calls

### NF3 — Security

- **NF3.1** No eval, no exec, no dynamic code execution
- **NF3.2** No shell=True subprocess calls
- **NF3.3** API tokens read only from environment variables, never from config files

### NF4 — Correctness

- **NF4.1** Every rule must have at least one positive and one negative test sample
- **NF4.2** Mutation test kill rate must be ≥ 95% across all rules
- **NF4.3** Self-tests must pass before any release

---

## Rule Coverage Requirements

### GitHub Actions (target: 30+ rules across 10 OWASP categories)

| Category | Min Rules |
|----------|-----------|
| CICD-SEC-1: Insufficient Flow Control | 2 |
| CICD-SEC-2: Inadequate IAM | 3 |
| CICD-SEC-3: Dependency Chain Abuse | 5 |
| CICD-SEC-4: Poisoned Pipeline Execution | 5 |
| CICD-SEC-5: Insufficient PBAC | 2 |
| CICD-SEC-6: Credential Hygiene | 3 |
| CICD-SEC-7: Insecure System Config | 2 |
| CICD-SEC-8: Ungoverned Usage | 2 |
| CICD-SEC-9: Improper Artifact Integrity | 2 |
| CICD-SEC-10: Insufficient Logging | 2 |

### GitLab CI (target: 17+ rules across 10 OWASP categories)

| Category | Min Rules |
|----------|-----------|
| CICD-SEC-3: Dependency Chain Abuse | 3 |
| CICD-SEC-6: Credential Hygiene | 5 |
| CICD-SEC-10: Insufficient Logging | 1 |

---

## Compliance Mapping

All rules map to one or more of:
- [OWASP Top 10 CI/CD Security Risks](https://owasp.org/www-project-top-10-ci-cd-security-risks/)
- Real-world documented attack vectors (tj-actions, Codecov, Aqua Trivy supply chain)
- Published security research (GitHub Security Lab, Orca Security, Fares et al. 2026)
