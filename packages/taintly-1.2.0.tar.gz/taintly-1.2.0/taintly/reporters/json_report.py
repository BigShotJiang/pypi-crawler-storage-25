"""JSON output reporter."""

from __future__ import annotations

import json

from taintly.families import cluster_findings
from taintly.models import AuditReport


def format_json(report: AuditReport) -> str:
    """Render an AuditReport as pretty-printed JSON.

    v2 additions (backwards-compatible):
      * Each finding carries ``finding_family``, ``confidence`` and
        ``review_needed`` fields (unset defaults preserve old output shape).
      * A top-level ``families`` array summarizes root-cause clusters so
        consumers can drive dashboards from distinct risks instead of
        raw rule-match volume.
      * A top-level ``distinct_risk_count`` gives the headline number.
    """
    clusters = cluster_findings(report.findings)
    confirmed_clusters = [cl for cl in clusters if not cl.review_needed]
    review_clusters = [cl for cl in clusters if cl.review_needed]

    # ``errors`` mirrors ENGINE-ERR findings into a top-level array so
    # downstream tooling can detect silent coverage loss without grep-
    # ping the findings stream by ``rule_id``.  The same Findings
    # remain in ``findings`` for backwards compatibility — pre-v1.1
    # consumers parsing only ``findings`` keep working unchanged.
    data = {
        "repo_path": report.repo_path,
        "platform": report.platform,
        "files_scanned": report.files_scanned,
        "summary": report.summary,
        "distinct_risk_count": len(confirmed_clusters),
        "review_needed_count": len(review_clusters),
        "families": [cl.to_dict() for cl in clusters],
        "findings": [f.to_dict() for f in report.findings],
        "errors": [f.to_dict() for f in report.engine_errors()],
    }
    return json.dumps(data, indent=2)
