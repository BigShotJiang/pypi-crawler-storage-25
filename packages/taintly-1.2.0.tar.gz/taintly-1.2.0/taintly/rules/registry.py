"""Rule registry — auto-discovers and loads all rules from rule modules."""

from __future__ import annotations

import importlib
import sys
import traceback
from pathlib import Path

from taintly.models import Platform, Rule


def _discover_rules_in_package(package_path: str, package_name: str) -> list[Rule]:
    """Import all modules in a package and collect RULES lists.

    A rule module that fails to import is a real bug — silently
    dropping its rules produces a scanner that reports clean on files
    it should have flagged. We print the full traceback (not just the
    exception message) so the diagnostic is a copy-pasteable stack,
    and we track failures so load_all_rules() can escalate loudly.
    """
    rules: list[Rule] = []
    pkg_path = Path(package_path)

    if not pkg_path.is_dir():
        return rules

    for item in sorted(pkg_path.iterdir()):
        if item.suffix == ".py" and item.stem != "__init__" and not item.stem.startswith("_"):
            module_name = f"{package_name}.{item.stem}"
            try:
                mod = importlib.import_module(module_name)
                if hasattr(mod, "RULES"):
                    rules.extend(mod.RULES)
            except Exception:
                _IMPORT_FAILURES.append(module_name)
                print(
                    f"ERROR: Failed to load rule module {module_name} — "
                    f"its rules will NOT be applied to scanned files.\n"
                    f"{traceback.format_exc()}",
                    file=sys.stderr,
                )

    return rules


# Module-level so both _discover_rules_in_package (writer) and
# load_all_rules (reader) see the same list across the batch.
_IMPORT_FAILURES: list[str] = []


def load_all_rules() -> list[Rule]:
    """Load all rules from github/, gitlab/, and jenkins/ rule directories."""
    _IMPORT_FAILURES.clear()
    rules: list[Rule] = []
    base = Path(__file__).parent

    for platform_dir in ["github", "gitlab", "jenkins"]:
        pkg_path = base / platform_dir
        pkg_name = f"taintly.rules.{platform_dir}"
        rules.extend(_discover_rules_in_package(str(pkg_path), pkg_name))

    if _IMPORT_FAILURES:
        # The per-module traceback already printed above. This line
        # surfaces the count as a load-summary line so a downstream
        # runner or CI log sees "N modules failed" without having to
        # parse every traceback.
        print(
            f"ERROR: {len(_IMPORT_FAILURES)} rule module(s) failed to load: "
            f"{_IMPORT_FAILURES}. Scanner coverage is degraded.",
            file=sys.stderr,
        )

    return rules


def load_rules_for_platform(platform: Platform) -> list[Rule]:
    """Load rules filtered to a specific platform."""
    return [r for r in load_all_rules() if r.platform == platform]


def get_rule_by_id(rule_id: str) -> Rule | None:
    """Find a specific rule by ID."""
    for r in load_all_rules():
        if r.id == rule_id:
            return r
    return None
