"""Baseline and diff support for taintly.

Allows teams to snapshot the current finding state and only report new
findings in subsequent scans — essential for adopting the tool in repos
with pre-existing issues.

Workflow:
    # Snapshot current state (commit this file)
    python -m taintly . --baseline

    # CI: only report findings introduced since the snapshot
    python -m taintly . --diff .taintly-baseline.json

Fingerprint design:
    sha256(rule_id + "|" + normalised_relative_file_path + "|" + snippet)

    Deliberately excludes line number — line numbers drift as code changes.
    Snippet anchors the fingerprint to the actual content, so a finding
    that moves to a different line is still recognised as the same finding,
    but a new occurrence of the same rule in different content is treated
    as new.
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from typing import Any

BASELINE_FILENAME = ".taintly-baseline.json"
BASELINE_VERSION = 1


# ---------------------------------------------------------------------------
# Fingerprinting
# ---------------------------------------------------------------------------


def fingerprint(finding, repo_path: str) -> str:
    """Return a stable hex fingerprint for a finding.

    Uses rule_id + normalised relative file path + snippet (first 120 chars).
    Excludes line number so the fingerprint survives surrounding-code edits.
    """
    try:
        rel = os.path.relpath(finding.file, os.path.abspath(repo_path))
    except ValueError:
        rel = finding.file
    rel_norm = rel.replace("\\", "/")

    snippet = (finding.snippet or "").strip()[:120]
    raw = f"{finding.rule_id}|{rel_norm}|{snippet}"
    return hashlib.sha256(raw.encode("utf-8", errors="replace")).hexdigest()


# ---------------------------------------------------------------------------
# Baseline data class
# ---------------------------------------------------------------------------


@dataclass
class Baseline:
    version: int
    repo_path: str
    scanned_at: str  # ISO-8601 timestamp
    fingerprints: set[str]  # sha256 hex strings
    finding_count: int  # informational


# ---------------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------------


def save_baseline(findings: list[Any], repo_path: str, output_path: str) -> Baseline:
    """Compute fingerprints for findings and write a baseline JSON file.

    Returns the Baseline that was written.
    """
    import datetime

    fps = {fingerprint(f, repo_path) for f in findings}
    scanned_at = datetime.datetime.now(datetime.timezone.utc).isoformat()

    payload = {
        "version": BASELINE_VERSION,
        "repo_path": os.path.abspath(repo_path),
        "scanned_at": scanned_at,
        "finding_count": len(findings),
        "fingerprints": sorted(fps),  # sorted for stable diffs in git
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
        f.write("\n")

    return Baseline(
        version=BASELINE_VERSION,
        repo_path=os.path.abspath(repo_path),
        scanned_at=scanned_at,
        fingerprints=fps,
        finding_count=len(findings),
    )


# ---------------------------------------------------------------------------
# Load
# ---------------------------------------------------------------------------


class BaselineError(ValueError):
    """Raised when the baseline file cannot be loaded or is invalid."""


def load_baseline(path: str) -> Baseline:
    """Load a baseline from a JSON file.

    Raises:
        FileNotFoundError: if path does not exist.
        BaselineError: if the file is malformed or the version is unsupported.
    """
    abs_path = os.path.abspath(path)
    size = os.path.getsize(abs_path)
    if size > 10 * 1024 * 1024:  # 10 MB cap — baselines should never be this large
        raise BaselineError(f"baseline file is {size} bytes; suspiciously large, refusing to load")

    with open(abs_path, encoding="utf-8", errors="replace") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError as e:
            raise BaselineError(f"baseline file is not valid JSON: {e}") from e

    if not isinstance(data, dict):
        raise BaselineError("baseline file must be a JSON object")

    version = data.get("version")
    if version != BASELINE_VERSION:
        raise BaselineError(
            f"baseline version {version!r} is not supported; expected version {BASELINE_VERSION}"
        )

    fps_raw = data.get("fingerprints")
    if not isinstance(fps_raw, list):
        raise BaselineError("baseline 'fingerprints' must be a list")

    fps: set[str] = set()
    for i, item in enumerate(fps_raw):
        if not isinstance(item, str) or len(item) != 64:
            raise BaselineError(
                f"baseline fingerprints[{i}] is not a valid sha256 hex string: {item!r}"
            )
        fps.add(item)

    return Baseline(
        version=BASELINE_VERSION,
        repo_path=data.get("repo_path", ""),
        scanned_at=data.get("scanned_at", ""),
        fingerprints=fps,
        finding_count=data.get("finding_count", len(fps)),
    )


# ---------------------------------------------------------------------------
# Diff
# ---------------------------------------------------------------------------


def apply_diff(findings: list[Any], baseline: Baseline, repo_path: str) -> tuple[list[Any], int]:
    """Filter findings to only those not present in the baseline.

    Returns:
        (new_findings, suppressed_count)
    """
    new = []
    suppressed = 0
    for f in findings:
        fp = fingerprint(f, repo_path)
        if fp in baseline.fingerprints:
            suppressed += 1
        else:
            new.append(f)
    return new, suppressed


# ---------------------------------------------------------------------------
# Summary helpers
# ---------------------------------------------------------------------------


def format_baseline_summary(baseline: Baseline, output_path: str) -> str:
    """One-line summary printed after writing a baseline."""
    return (
        f"Baseline written: {output_path}\n"
        f"  {baseline.finding_count} finding(s) fingerprinted, "
        f"{len(baseline.fingerprints)} unique\n"
        f"  Commit this file to suppress these findings in future scans."
    )


def format_diff_summary(suppressed: int, new_count: int, baseline_path: str) -> str:
    """One-line summary printed in diff mode."""
    if suppressed == 0 and new_count == 0:
        return f"Diff mode: no findings (baseline: {baseline_path})"
    parts = []
    if suppressed:
        parts.append(f"{suppressed} suppressed (in baseline)")
    if new_count:
        parts.append(f"{new_count} NEW")
    return f"Diff mode ({baseline_path}): {', '.join(parts)}"
