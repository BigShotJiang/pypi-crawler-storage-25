"""Core scanning engine — loads rules, applies patterns, produces findings."""

from __future__ import annotations

import glob
import os
import re

from .families import classify_rule, default_confidence, default_review_needed
from .models import (
    _MAX_SAFE_TEXT_LEN,
    AuditReport,
    Finding,
    Platform,
    Rule,
    Severity,
    scan_session,
)
from .pse_enrichment import enrich_pse_findings
from .workflow_context import analyze as analyze_workflow
from .workflow_context import compute_exploitability
from .workflow_corpus import CorpusPattern, build_corpus

# ---------------------------------------------------------------------------
# Inline suppression
# ---------------------------------------------------------------------------

_SUPPRESS_GENERIC = re.compile(r"#\s*taintly:\s*ignore\s*$", re.IGNORECASE)
_SUPPRESS_SPECIFIC = re.compile(r"#\s*taintly:\s*ignore\[([^\]]+)\]", re.IGNORECASE)


# Rules whose finding describes a project-level setting rather than a
# per-file pattern.  Firing them once per workflow file in a multi-file
# repo is noise — the underlying configuration is the same regardless
# of how many YAML files exist.  ``_dedupe_project_scope`` keeps only
# the first occurrence (lowest file path) per scan so the report
# surfaces the issue exactly once.
_PROJECT_SCOPE_RULES: frozenset[str] = frozenset(
    {
        "SEC10-GL-002",  # Public-pipelines visibility — a GitLab project setting
    }
)


def _dedupe_project_scope(findings: list[Finding]) -> list[Finding]:
    """Keep only the first finding per project-scope rule_id.

    Project-scope rules describe one underlying configuration that is
    shared across every workflow file in the project.  Reporting them
    per file inflates the noise without adding signal.
    """
    seen_project_scope: set[str] = set()
    deduped: list[Finding] = []
    for f in findings:
        if f.rule_id in _PROJECT_SCOPE_RULES:
            if f.rule_id in seen_project_scope:
                continue
            seen_project_scope.add(f.rule_id)
        deduped.append(f)
    return deduped


def _is_suppressed(line: str, rule_id: str) -> bool:
    """Return True if the line carries a taintly suppression comment for rule_id.

    Supported forms:
      # taintly: ignore                     — suppress all rules on this line
      # taintly: ignore[SEC3-GH-001]        — suppress a specific rule
      # taintly: ignore[SEC3-GH-001,SEC3-GH-002]  — suppress multiple rules
    """
    if _SUPPRESS_GENERIC.search(line):
        return True
    m = _SUPPRESS_SPECIFIC.search(line)
    if m:
        suppressed = {s.strip() for s in m.group(1).split(",")}
        if rule_id in suppressed:
            return True
    return False


def scan_file(filepath: str, rules: list[Rule], _content: str | None = None) -> list[Finding]:
    """Scan a single file against a list of rules.

    If _content is provided, use it directly instead of reading from disk.
    filepath is still used for Finding.file attribution.
    """
    findings = []
    if _content is not None:
        content = _content
        lines = content.splitlines()
    else:
        try:
            with open(filepath, encoding="utf-8", errors="replace") as f:
                content = f.read()
            lines = content.splitlines()
        except Exception as e:
            findings.append(
                Finding(
                    rule_id="ENGINE-ERR",
                    severity=Severity.LOW,  # LOW so it survives --min-severity LOW filters
                    title=f"Could not read file: {e}",
                    description=str(e),
                    file=filepath,
                )
            )
            return findings

    # Build a lightweight per-file context once, then use it to derive a
    # context-aware exploitability tier for each finding.  The analyzer is
    # pure-regex (see workflow_context.py) so the cost is a few hundred
    # microseconds per file — comfortably below the per-rule scan budget.
    # Surface silent coverage loss: the ReDoS length cap in _safe_search
    # skips regex evaluation on text > _MAX_SAFE_TEXT_LEN. Full-content
    # patterns (AbsencePattern, ContextPattern requires) on oversize files
    # return no matches regardless of what's inside. Emit a single
    # informational finding so "scan clean" can be distinguished from
    # "scan skipped". Per-line regex continues to work because individual
    # YAML lines fit comfortably under the cap.
    if len(content) > _MAX_SAFE_TEXT_LEN:
        findings.append(
            Finding(
                rule_id="ENGINE-ERR",
                severity=Severity.LOW,
                title=(
                    f"File size {len(content)} bytes exceeds scanner cap "
                    f"({_MAX_SAFE_TEXT_LEN}); file-scope rule coverage degraded"
                ),
                description=(
                    "To prevent regex denial-of-service on adversarial input, "
                    "taintly skips full-content regex on files larger than "
                    f"{_MAX_SAFE_TEXT_LEN} bytes. Per-line rules still run, but "
                    "file-scope patterns (ContextPattern requires / "
                    "AbsencePattern) will not report matches on this file. "
                    "If this is a legitimate large CI config, split it via "
                    "includes / reusable workflows."
                ),
                file=filepath,
            )
        )

    wf_ctx = analyze_workflow(content, file=filepath)

    with scan_session():
        for rule in rules:
            try:
                matches = rule.pattern.check(content, lines)
                for line_num, snippet in matches:
                    # Honour inline suppression comments on the matched line.
                    source_line = lines[line_num - 1] if 0 < line_num <= len(lines) else ""
                    if _is_suppressed(source_line, rule.id):
                        continue
                    # Propagate v2 reporting metadata. Rule-level overrides win;
                    # otherwise fall back to the family/confidence defaults in
                    # taintly.families so every finding is classified.
                    family = rule.finding_family or classify_rule(rule.id, rule.owasp_cicd)
                    confidence = rule.confidence or default_confidence(rule.id)
                    review_needed = rule.review_needed or default_review_needed(rule.id)
                    exploitability = compute_exploitability(family, wf_ctx)
                    findings.append(
                        Finding(
                            rule_id=rule.id,
                            severity=rule.severity,
                            title=rule.title,
                            description=rule.description,
                            file=filepath,
                            line=line_num,
                            snippet=snippet,
                            remediation=rule.remediation,
                            reference=rule.reference,
                            owasp_cicd=rule.owasp_cicd,
                            stride=rule.stride,
                            threat_narrative=rule.threat_narrative,
                            incidents=rule.incidents,
                            finding_family=family,
                            confidence=confidence,
                            exploitability=exploitability,
                            review_needed=review_needed,
                        )
                    )
            except Exception as e:
                findings.append(
                    Finding(
                        rule_id="ENGINE-ERR",
                        severity=Severity.INFO,
                        title=f"Rule {rule.id} failed on {filepath}: {e}",
                        description=str(e),
                        file=filepath,
                    )
                )

    return findings


def detect_platform(repo_path: str) -> Platform | None:
    """Auto-detect CI/CD platform from directory structure."""
    gh_dir = os.path.join(repo_path, ".github", "workflows")
    gl_file = os.path.join(repo_path, ".gitlab-ci.yml")
    jk_file = os.path.join(repo_path, "Jenkinsfile")

    has_github = os.path.isdir(gh_dir)
    has_gitlab = os.path.isfile(gl_file)
    has_jenkins = os.path.isfile(jk_file) or bool(
        glob.glob(os.path.join(repo_path, "Jenkinsfile.*"))
    )

    if has_github and has_gitlab:
        return None  # Both — caller should scan both
    if has_github:
        return Platform.GITHUB
    if has_gitlab:
        return Platform.GITLAB
    if has_jenkins:
        return Platform.JENKINS
    return None


def discover_files(repo_path: str, platform: Platform) -> list[str]:
    """Find all CI/CD config files for a given platform."""
    files = []

    if platform == Platform.GITHUB:
        workflow_dir = os.path.join(repo_path, ".github", "workflows")
        if os.path.isdir(workflow_dir):
            files.extend(glob.glob(os.path.join(workflow_dir, "*.yml")))
            files.extend(glob.glob(os.path.join(workflow_dir, "*.yaml")))

    elif platform == Platform.GITLAB:
        gl_file = os.path.join(repo_path, ".gitlab-ci.yml")
        if os.path.isfile(gl_file):
            files.append(gl_file)
        # Also check for local includes
        for pattern in ["ci/*.yml", "ci/**/*.yml", ".gitlab/*.yml", ".gitlab/**/*.yml"]:
            files.extend(glob.glob(os.path.join(repo_path, pattern), recursive=True))

    elif platform == Platform.JENKINS:
        # Root-level canonical names first — cheap, deterministic.
        for name in ("Jenkinsfile", "Jenkinsfile.groovy"):
            p = os.path.join(repo_path, name)
            if os.path.isfile(p):
                files.append(p)
        files.extend(glob.glob(os.path.join(repo_path, "Jenkinsfile.*")))
        # Nested pipelines: monorepos, ci/, scripts/, jenkins/, per-vendor
        # subtrees. Four patterns cover the shapes seen in the wild
        # (mlcommons vendor dirs, snowflakedb ci/Jenkinsfile.coverage,
        # OpenROAD jenkins/Jenkinsfile.nightly, quic scripts/Jenkinsfile,
        # PaloAltoNetworks Jenkins/declarative-pipeline/Jenkinsfile).
        # Filter out vendor/dep dirs to avoid scanning third-party code.
        excluded_segments = {"node_modules", ".git", "vendor", "__pycache__"}
        for pattern in (
            "**/Jenkinsfile",
            "**/Jenkinsfile.*",
            "**/*.jenkinsfile",
            "jenkins/**/*.groovy",
        ):
            for match in glob.glob(os.path.join(repo_path, pattern), recursive=True):
                # Path-segment check avoids matching node_modules_old etc.
                rel = os.path.relpath(match, repo_path)
                if any(seg in excluded_segments for seg in rel.split(os.sep)):
                    continue
                files.append(match)

    return sorted(set(files))


def scan_repo(
    repo_path: str, rules: list[Rule], platform: Platform | None = None
) -> list[AuditReport]:
    """Scan an entire repository. Returns one report per platform detected."""
    reports = []

    platforms_to_scan = []
    if platform:
        platforms_to_scan = [platform]
    else:
        detected = detect_platform(repo_path)
        if detected:
            platforms_to_scan = [detected]
        else:
            # Check all supported platforms
            for p in [Platform.GITHUB, Platform.GITLAB, Platform.JENKINS]:
                if discover_files(repo_path, p):
                    platforms_to_scan.append(p)

    if not platforms_to_scan:
        report = AuditReport(repo_path=repo_path)
        return [report]

    for plat in platforms_to_scan:
        report = AuditReport(repo_path=repo_path, platform=plat.value)
        platform_rules = [r for r in rules if r.platform == plat]
        files = discover_files(repo_path, plat)
        report.files_scanned = len(files)
        report.rules_loaded = len(platform_rules)

        all_findings: list[Finding] = []
        for fpath in files:
            all_findings.extend(scan_file(fpath, platform_rules))
        # PSE-GH-002: enrich PSE-GH-001 findings by classifying any
        # local IAM policy that matches the workflow's role-to-assume
        # ARN.  Mutates findings in-place — escalation only happens on
        # a CRITICAL classifier verdict; absence of evidence keeps the
        # finding at HIGH.  GitHub-only (the rule is GH-platform).
        if plat == Platform.GITHUB:
            all_findings = enrich_pse_findings(all_findings, repo_path)
            # B2 cross-file pass: build the WorkflowCorpus once per
            # platform-scan and run any rule whose pattern is a
            # CorpusPattern.  Per-file rules (RegexPattern /
            # ContextPattern / …) are unaffected because their
            # CorpusPattern siblings stub `check()` to return [].
            all_findings.extend(_run_corpus_rules(repo_path, platform_rules))
        for f in _dedupe_project_scope(all_findings):
            report.add(f)

        report.summarize()
        reports.append(report)

    return reports


def _run_corpus_rules(repo_path: str, rules: list[Rule]) -> list[Finding]:
    """Build a WorkflowCorpus and run every CorpusPattern rule against it.

    Returns the findings list (already wrapped in :class:`Finding` with
    the rule's metadata).  No-op when no CorpusPattern rules are loaded;
    the corpus build is then skipped entirely so non-cross-file users
    don't pay the walk cost.
    """
    corpus_rules = [r for r in rules if isinstance(r.pattern, CorpusPattern)]
    if not corpus_rules:
        return []

    corpus = build_corpus(repo_path)
    findings: list[Finding] = []
    with scan_session():
        for rule in corpus_rules:
            # The isinstance(r.pattern, CorpusPattern) filter above
            # guarantees this method exists; assert the narrow type
            # for mypy without paying a runtime check at the call.
            corpus_pattern = rule.pattern
            assert isinstance(corpus_pattern, CorpusPattern)  # nosec B101
            try:
                hits = corpus_pattern.check_corpus(corpus)
            except Exception as e:
                findings.append(
                    Finding(
                        rule_id="ENGINE-ERR",
                        severity=Severity.INFO,
                        title=f"Corpus rule {rule.id} failed: {e}",
                        description=str(e),
                        file=repo_path,
                    )
                )
                continue
            for filepath, line_num, snippet in hits:
                family = rule.finding_family or classify_rule(rule.id, rule.owasp_cicd)
                confidence = rule.confidence or default_confidence(rule.id)
                review_needed = rule.review_needed or default_review_needed(rule.id)
                # Cross-file findings don't have a single workflow_context
                # to derive exploitability from — the rule's own logic is
                # the exploitability gate.  Default to "medium" so the
                # reporter doesn't downrank the finding without basis.
                findings.append(
                    Finding(
                        rule_id=rule.id,
                        severity=rule.severity,
                        title=rule.title,
                        description=rule.description,
                        file=filepath,
                        line=line_num,
                        snippet=snippet,
                        remediation=rule.remediation,
                        reference=rule.reference,
                        owasp_cicd=rule.owasp_cicd,
                        stride=rule.stride,
                        threat_narrative=rule.threat_narrative,
                        incidents=rule.incidents,
                        origin="cross-workflow",
                        finding_family=family,
                        confidence=confidence,
                        exploitability="medium",
                        review_needed=review_needed,
                    )
                )
    return findings
