# Changelog

All notable changes to taintly will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

<!-- Maintainers: new versions go at the top. Keep `Unreleased` as the working section. -->

## [Unreleased]

## [1.2.0] — 2026-04-26

Cross-workflow rule family (XF-GH-*), AI rule expansion across three phases, Windows test gate, the eight-example demo surface with real captured output, and PyPI publishing restored.

### Changed — PyPI publishing restored

Reversing the `[Unreleased]` decision in #117. Taintly is back on PyPI:

```bash
pip install taintly
```

The `git+https://github.com/Nellur35/taintly@v1` form is preserved for unreleased revisions. The GitHub Action (`uses: Nellur35/taintly@v1`) and GitLab CI Component remain unchanged.

The two latent bugs that originally caused `taintly-0.0.0` to ship in place of v1.0.0 / v1.1.0 are now both fixed:

- **`[tool.setuptools-scm]` (hyphen) → `[tool.setuptools_scm]` (underscore).** The whole config block was being silently ignored by modern setuptools-scm; even after `fetch-tags: true` landed in #117, the typo would have continued to bite. (`pyproject.toml`, #138)
- **Floating `v1` tag obscured semver tags.** `git describe` walked ancestry and found `v1` (which advances with each release) closer than `v1.1.1`. setuptools-scm couldn't parse `v1` as semver and fell back to `0.0.0`. Now filtered via `git_describe_command = "git describe --dirty --tags --long --match 'v[0-9]*.[0-9]*.[0-9]*'"`. (#138)
- **`+local` version segment.** PEP 440 forbids local-version segments on PyPI. setuptools-scm's default `local_scheme` appended `+g<sha>` to dev builds, producing `1.1.2.dev22+g8d44f71` which TestPyPI rejected with `400`. Set `local_scheme = "no-local-version"`. Tagged-release versions are unaffected. (#139)

A `.github/workflows/test-release.yml` workflow restores the TestPyPI dry-run path; it dispatches manually via `workflow_dispatch` so a real publish can be rehearsed against `test.pypi.org` before any tag push.

### Added — cross-workflow rules (XF-GH family)

A new family for misconfigurations that span multiple workflow files in the same repo. Two of these (XF-GH-002, XF-GH-003) were demoted, renamed, or split mid-development; the catalogue below reflects the post-stabilisation state.

- **`XF-GH-001A`** (HIGH) — Executable-cache poisoning across privilege tiers. A privileged release workflow and a fork-reachable PR workflow share a cache prefix (e.g. `pnpm-store`); attacker writes to the cache via the PR path, victim reads it on the next release. (#127, #131)
- **`XF-GH-001B`** (MEDIUM) — Same cache-prefix shape between two same-tier workflows; less severe than 001A because there's no privilege gradient.
- **`XF-GH-002`** (LOW) — Cross-workflow concurrency-cancel collision. Two workflows share a `concurrency.group:` key; one's run cancels the other's. Demoted because exploitability requires very specific timing. (#128, #131)
- **`XF-GH-003`** (MEDIUM) — Reusable-workflow fanout hub. A reusable workflow called from many callers, each passing `secrets: inherit`; at runtime the hub holds the union of every caller's secret scope. (#129)
- **`XF-GH-004`** (HIGH) — PWN-request shape. `pull_request_target` (write context + secret injection) caller invokes a reusable workflow with `secrets: inherit`. The defining shape behind the Cacheract class of public CI compromises. (#132)

### Added — AI/ML rule expansion (Phases A, C, D)

- **Phase A** — port AI-GH-022/024/025 to GitLab and Jenkins (`AI-GL-022/024/025`, `AI-JK-022/024/025`). (#123)
- **Phase C** — five training-pipeline rules `AI-GH-026..030`. (#124)
- **Phase D** — five multi-agent orchestration rules `AI-GH-031..035`. (#125)
- **`AI-GH-022`** — agent step with permission/sandbox-skip flag. (#119)
- **`AI-GH-023`** — agent + `actions: write` (Cacheract gate). (#120)
- **`AI-GH-024`** — MCP config from PR head + `AI-GH-021` description tweak. (#121)
- **`AI-GH-025`** — `HF_ENDPOINT` / `HF_HOME` rebinding from PR-reachable input. (#122)

### Added — taint and engine

- **`TAINT-GH-009`** — cross-job `needs.X.outputs.Y` reaching a shell sink. (#118)
- **`TAINT-GH-010` / `TAINT-GH-011`** — `workflow_run` head-SHA + multi-trigger idempotency. Multi-trigger handlers can re-fire on the same head SHA with different events; the rules surface the propagation surface that creates. (#126)
- **`PSE-GH-002`** — Permission-Slip Effect rule + reporter snapshots + B2 WorkflowCorpus + B3.1 cache poisoning. (#127)
- **`ENGINE-ERR`** — engine error path fix: previously a single malformed YAML file in a multi-file scan could swallow the whole report; now the engine surfaces the parse failure as a finding and continues. (#118)

### Added — demo surface

Eight worked examples in `examples/` covering the rule families above, each a self-contained scannable directory with a README + `expected-rules.txt`:

1. `01-multi-hop-env` — `TAINT-GH-002`
2. `02-github-env-bridge` — `TAINT-GH-003`
3. `03-agent-output-taint` — `TAINT-GH-005` + AI-GH-006/015/020
4. `04-cross-job-needs` — `TAINT-GH-009`
5. `05-fork-identity-guard-downgrade` — `TAINT-GH-002` vulnerable/ + guarded/
6. `06-cache-prefix-collision` — `XF-GH-001A`
7. `07-pull-request-target-checkout` — `XF-GH-004` + cluster (8 co-firing rules)
8. `08-baseline-diff` — `--baseline` + `--diff` smoke

`scripts/verify-examples.sh` runs in CI on every push, asserting each example fires its expected rule IDs. The top-level `README.md` was rewritten around real captured `taintly --score` output from example 07. (#134)

### Added — Windows test gate

`Tests (Windows, Python 3.12)` job in `ci.yml`. Surfaced and gated against the path-separator bugs in #135. (#136)

### Changed — top-risk panel sort

The "Top distinct risks" panel now sorts by severity → review_needed → confidence (was: severity → exploitability → confidence). Pulls confirmed-CRITICAL ahead of review-needed CRITICAL, which matches how a triager actually scans the panel. (#133)

### Changed — slop-wipe vocabulary cleanup

Measured pass over all 221 rules cleaning AI-cadence prose in `description` and `threat_narrative` fields. No deletions, no demotions, no behaviour changes. `"blast radius"` → `"scope"`, `"permission slip"` → `"OIDC grant"`, etc. Pre-flight TP-table verified clean: 0 rules with `confidence=high + review_needed=True`. (#137)

### Fixed — Windows path-separator bugs

Multiple rule callbacks and `--fix` gates compared paths via `endswith('./...')` against Windows backslash paths. Three tests in `tests/unit/test_cross_workflow_rules.py` failed on local Windows; Linux CI was unaffected. Fixed across rule callbacks, gated by the new Windows test runner so it can't recur silently. (#135, #136)

### Removed — asciinema scripts

`scripts/record-demo.sh` and `scripts/_demo-script.sh`. The demo strategy was pivoted from asciinema cast to README + real captured terminal output (cast-as-static-text). The old walkthrough script is replaced in `examples/README.md` with a one-line `for d in examples/0*/; do ...; done` recipe.

### Verification at release

- All CI lanes green on `main` since #117 (lint, mypy 3.10/3.11/3.12, unit, rule-tests, fuzz, self-audit, Bandit, gitleaks, dep audit, CodeQL, Verify Examples, Windows tests).
- `python -m build` produces a real semver wheel locally (`taintly-1.1.2.dev23-py3-none-any.whl` on untagged `main`); on the `v1.2.0` tag the wheel will be `taintly-1.2.0`.
- TestPyPI rehearsal of the publish pipeline (`test-release.yml` dispatch, run `24963340221`) landed `taintly-1.1.2.dev23` on test.pypi.org with both wheel + sdist.
- 991 pytest pass, 15 skipped.

## [1.1.0] — 2026-04-24

Cross-workflow taint detection and precision work on the existing taint analyzer. Two new rules (one per platform), one precision fix, a meaningful fuzz-corpus expansion, and a README cleanup.

### Added — rules

- **`TAINT-GH-006`** — reusable-workflow input reference (callee-side). Fires when a workflow with `on: workflow_call` references `${{ inputs.X }}`. Review-needed (MEDIUM) because the callee author cannot know whether callers forward attacker-controlled `github.event.*` fields.
- **`TAINT-GH-007`** — caller-side cross-workflow. Complement to `-006`: fires when a job invokes a local reusable workflow AND references a `github.event.*` attacker context in the same job (typically in the `with:` block passing inputs).
- **`TAINT-GH-008`** — `workflow_run` handler references attacker-controlled upstream context. Workflows triggered by `on: workflow_run` inherit `github.event.workflow_run.*` from the upstream run; when the upstream was itself fork-triggerable, `head_branch`, `head_commit.message`, `head_repository.full_name`, and similar fields carry attacker bytes. Found 5 real instances on `pytorch/pytorch` during the pre-release FP-hunt.
- **`TAINT-GL-004`** — GitLab CI Component input reference. GitLab analog of `TAINT-GH-006`; matches `spec.inputs:` + `$[[ inputs.X ]]` substitution.
- **`TAINT-JK-002`** — Jenkins downstream build with tainted parameter. Jenkins analog of `TAINT-GH-007`: `build job: 'other', parameters: [string(name: 'X', value: env.CHANGE_TITLE)]` forwards attacker bytes into the downstream job's `params.X`, breaking per-job credential isolation.
- Rule count: 188 → 193 (88 GitHub, 55 GitLab, 49 Jenkins; 43 AI/ML + 13 taint).

### Fixed — taint precision

- `_references_var` in the taint analyzer now ignores single-quoted `$VAR` references in `run:` / `script:` lines. Bash never interpolates inside single quotes, so `run: echo '$PR_TITLE'` is not an injection sink. A small bash-style quote-state walker (`_shell_quote_context_at`) handles nested and escaped cases; the server-side `${{ env.VAR }}` substitution form stays matched regardless of surrounding shell quotes because the runner substitutes the value before bash sees the line.
- `TAINT-GH-006` exclude list tightened: `timeout-minutes:` (engine-validated numeric) and `concurrency:` (grouping key, never reaches a shell) no longer fire. `runs-on:`, `container:`, `image:` intentionally stay in scope — self-hosted runner hijack and attacker-controlled container image pull are real threats.

### Added — fuzz expansion

+15 adversarial inputs in `tests/fuzz/test_fuzz_yaml.py`. The harness contract is unchanged (`scan_file()` must return a list, not crash or hang within 10s); this batch broadens the input classes:

- Line endings / encoding: UTF-8 BOM, CRLF-only, CR-only (classic Mac), surrogate-half escapes
- YAML 1.1 features real workflows use: `<<: *anchor` merge keys, `*anchor` references in steps lists, `!!str` explicit type tags
- PowerShell `iex` shapes (SEC6-GH-007 historical FP class): literal-string iex, `iex (Invoke-WebRequest ...).Content`, pipe-into-iex, `& $env:VAR` call-operator
- Heredoc variants: `<<EOF` (expansion) vs `<<'EOF'` (literal)
- Empty / degenerate: `steps: []`, `jobs: {}`

### Changed — README

- Dropped the `## Testing` section. "100% mutation kill", "479 positive self-tests", "26 AI findings across 7 of 22 public AI/ML repos" — numbers that read as rigor but don't help a reader decide whether to install the tool. The AI-findings claim had no writeup to back it up. The `docs/RULES.md` catalogue and the AUTOGEN coverage table cover what the tool actually does; `CONTRIBUTING.md` covers how contributors run tests.
- Architecture diagram drops the `benchmark/` subtree (same framing).
- Composite Action and GitLab Component snippets point at `@v1` (moving tag tracking the latest `v1.x.y`) instead of `@main`.
- `scripts/render_readme.py` loses the `testing` AUTOGEN block — down from three managed regions to two.

### Fixed — post-rename URL sweep

Every in-tree reference to `Nellur35/cicd-audit` now points at `Nellur35/taintly`. GitHub's redirect kept the old links working but new code should be canonical. 11 files: README, pyproject.toml, SECURITY, CONTRIBUTING, action.yml, docs/INTEGRATION, docs/ROADMAP, templates/, taintly/reporters/sarif.py, CHANGELOG link targets. Historical `[0.9.0]` changelog body left untouched.

### Verification at release

- 846 pytest pass, 15 skipped
- FP-hunt on ultralytics, huggingface/transformers, pytorch, woodruffw/zizmor:
  - `TAINT-GH-006` surfaced 4 legitimate findings across 3 repos
  - `TAINT-GH-008` surfaced 5 legitimate findings on pytorch (`workflow_run` handlers that forward `head_branch` / `head_repository.full_name` into shell via env-var indirection)
  - `TAINT-GH-007` and `TAINT-JK-002`: 0 findings — these repos correctly don't forward attacker context across workflow / job boundaries
  - One FP each caught and fixed pre-merge: `TAINT-GH-007` was initially matching `pull_request.head.sha` (immutable SHA, not attacker-controlled — regex narrowed); `TAINT-GH-008` was firing on `concurrency.group:` (engine-internal locking key, not a shell sink — excluded).

## [1.0.0] — 2026-04-24

First stable release. The scanner is on PyPI; the GitHub Action, GitLab CI Component, and flat GitLab include template all resolve to a tagged v1. Zero runtime dependencies. Python 3.10+.

### Added — packaging

- **Published on PyPI** at https://pypi.org/project/taintly/. Installs with `pip install taintly`.
- **`[build-system]`** — setuptools>=77 for PEP 639 SPDX `license = "MIT"` shorthand, setuptools-scm>=8 for git-tag-derived versions. Cutting a release is `git tag vX.Y.Z && git push --tags`; the release workflow takes it from there.
- **`.github/workflows/release.yml`** — tag-triggered on `v*.*.*`. Builds sdist + wheel, sanity-checks the wheel installs in a fresh venv, publishes to PyPI via OIDC trusted publishing (no long-lived API token anywhere), creates a GitHub Release with sdist + wheel attached and the matching CHANGELOG section as the release body. Gated on the tag being an ancestor of `main` so a rogue branch tag cannot ship.
- **`.github/workflows/test-release.yml`** — workflow_dispatch-triggered dry run that uploads to TestPyPI. Same build + OIDC flow as `release.yml`, different trusted publisher. Lets maintainers validate the publishing path without burning a real version number.
- **`taintly --version`** — prints the installed version derived from package metadata via `importlib.metadata`.

### Added — repository rename

- The GitHub repository is now `Nellur35/taintly` (was `Nellur35/cicd-audit`). All in-tree URLs, action references, and GitLab CI Component paths point at the new name. GitHub's permanent-redirect keeps old links working, but new code is canonical.
- The Python package is `taintly` (was `cicd_audit`). CLI is `taintly` / `python -m taintly`. Config file is `.taintly.yml`. Environment variables / baseline filename all moved in lockstep.

### Added — community + governance

- **`SECURITY.md`** — private vulnerability report channel + 90-day disclosure window.
- **`CONTRIBUTING.md`** — dev setup, test-harness layers, rule-authoring template, CI gate reference, PyPI trusted-publishing setup.
- **`docs/ROADMAP.md`** — phased 12-week plan through v1.2 and optional Phase 3 (Azure / CircleCI / Buildkite).

### Added — rules

- **`SEC2-GL-003`** / **`SEC2-JK-003`** — hardcoded service credentials (portable GH → GL/JK).
- **`SEC6-GH-009`** — publishing token referenced without OIDC Trusted Publishers. Motivated by the PyPI trusted-publishing rollout in 2024.
- **`SEC10-GH-004`** — `actions/upload-artifact` with a path that includes debug / log / home directories (secret-exfil shape).
- **`AI-GH-019`** — mutable-source TOCTOU: an agent action reads a config/prompt file that a preceding step fetched from an attacker-controlled ref.
- **`AI-GH-020`** — unscoped `allowedTools` on an AI coding-agent action.
- **`AI-GH-021`** — AI agent step runs after the workflow checks out PR head code.
- **`AI-GL-012`** / **`AI-GL-013`** / **`AI-JK-008`** / **`AI-JK-009`** — MCP server hygiene rules ported across GL / JK.
- **`TAINT-JK-001`** — Jenkins attacker-controlled context → double-quoted `sh` / `bat` / `powershell`.
- **LOTP-GH / SEC4-GH actor-spoofing ports** to GitLab and Jenkins.
- Total file-based rules: **188** (87 GitHub, 54 GitLab, 47 Jenkins; 43 AI/ML + 9 taint). Platform-posture rules: **21** (12 GitHub, 9 GitLab).

### Added — auto-fixers

- **`npm_ignore_scripts`** (opt-in via `--fix-npm-ignore-scripts`) — adds `--ignore-scripts` to npm/yarn/pnpm installs. Changes build semantics, so not in the default `--fix` set.
- **`jenkins_cap_add_hint`** (opt-in) — annotates Jenkins `cap-add` / `privileged` agents with a remediation hint.
- **`github_ai_allowed_tools_scaffold`** (opt-in) — scaffolds a scoped `allowedTools:` on agent actions that currently wildcard.
- **`hoist_service_credentials`** (opt-in) — moves inline service credentials to `secrets:` references.
- Total auto-fixers: **14** (10 default-safe + 4 opt-in).

### Added — tooling

- **Auto-generated README counts** (`scripts/render_readme.py`) between AUTOGEN markers. CI gate at `tests/unit/test_readme_counts.py` catches drift.
- **Real-world regression corpus** under `benchmark/corpus/` — 7 rule-ID-level fixtures drawn from public incident write-ups (Ultralytics, Trivy, tj-actions, PyTorch December 2022).
- **Precision corpus** — 5 labelled scenarios; all green at release.

### Fixed

- **`SEC5-GH-001`** — recognises PyPI trusted publishing (`pypa/gh-action-pypi-publish`), sigstore signing (`sigstore/gh-action-sigstore-*`), and attestation (`actions/attest-build-provenance`) as legitimate OIDC consumers. Surfaced by self-scanning `release.yml` — exactly the dogfood feedback loop the scanner is designed for.
- `release.yml` — awk `in` reserved-word usage replaced with `inside` so the release-notes extractor is portable across awk implementations.

### Removed

- **`taintly/ingestion/local.py`** — dead code.

### Changed

- Composite GitHub Action + GitLab CI Component + flat GitLab include template now default their `version:` input to `>=1.0,<2` (was `>=0.1,<1`). Narrows the default version range to the v1 line.

### Testing at release

- 809 pytest pass, 15 skipped.
- 100% mutation kill across 7071 mutants, 7 operators.
- Precision corpus 5/5; real-world regression corpus 7/7.
- 80% branch-coverage floor (fail_under=78 in the legacy-module slice).

## [0.9.0] — Unreleased (release-candidate line)

The `0.9.x` series is the v1.0 shakedown line. Every change below landed between `0.1.0` and the cut. Versions are documented for changelog-readers; git history is authoritative.

### Added — GitLab integration

- **GitLab CI Component** at `templates/taintly/template.yml` (GitLab 16.11+). Typed `spec.inputs:` for stage / job-name / fail-on / min-severity / platform / baseline / version / image / upload-sarif / extra-args. Writes `gl-sast-report.json` for native MR-widget ingestion.
- **Flat include template** at `templates/taintly.gitlab-ci.yml` for older GitLab. Hidden-job `.taintly:` extended via `extends:` + variable overrides. Same capability as the Component.
- **`templates/taintly/README.md`** — user-facing input reference + common patterns (baseline+diff, dual-platform, custom stage).
- Expanded `docs/INTEGRATION.md` §5 (GitLab) from 2 thin recipes to 6 subsections covering Component, flat template, raw `script:`, platform posture audit, Jenkinsfile-from-GitLab, and a gotchas table.
- 5 new subprocess integration tests (`tests/integration/test_ci_integration.py`) verifying SARIF shape, platform override, Jenkins path, and template-input contract.

### Added — GitHub integration

- **Composite Action** at repo root (`action.yml`). 13 inputs, 2 outputs. Handles Python setup, scanner install, CLI argument construction, and (optionally) writes the SARIF file for a separate upload step. One-line consumption: `- uses: Nellur35/cicd-audit@v1`.
- **`docs/INTEGRATION.md`** — 9 copy-pasteable CI patterns: SARIF upload, baseline+diff, config-driven suppressions, weekly scheduled scan, GitLab CI, pre-commit hook, auto-fix PR workflow, platform posture audit, org-wide scan. Reference tables for every action input/output + exit-code semantics.
- 7 subprocess integration tests covering exit codes, baseline/diff semantics, SARIF 2.1.0 shape, and `--exclude-rule` behaviour.

### Added — detection rules

- **`SEC9-GH-005`** — cache-key poisoning. Fires when `actions/cache` derives its key from attacker-controlled context (`github.head_ref`, PR head sha/ref/title, issue title/body, comment body).
- **`SEC3-GH-008`** — pip `--extra-index-url` used without `--index-url` (dependency-confusion shape, motivated by the PyTorch December 2022 incident).
- **`SEC10-GH-003`** — `ACTIONS_STEP_DEBUG` / `ACTIONS_RUNNER_DEBUG` set to true in committed YAML. Debug logging bypasses the runner's secret-masking layer.
- Extended GitLab taint-source list with `GITLAB_USER_{NAME,LOGIN,EMAIL}` and `CI_MERGE_REQUEST_TARGET_BRANCH_NAME`.
- `SEC4-JK-001` / `SEC4-JK-002` now match triple-double-quoted Groovy GStrings (`sh """..."""`) in addition to regular double quotes.

### Added — CI / tooling

- **Dependabot** — weekly pip + github-actions updates, grouped dev tooling (pytest/hypothesis, ruff/mypy), individual PRs for security scanners (bandit, pip-audit).
- **gitleaks secret scanning** — on every push/PR plus a weekly full-history sweep, with an allowlist for test fixtures / rule definitions that intentionally contain fake secrets.
- **mypy type check** — strict-bundle configuration: `no_implicit_optional`, `warn_return_any`, `warn_unreachable`, `strict_equality`, `disallow_any_generics`. Runs across Python 3.10/3.11/3.12 matrix.
- **CodeQL** — `security-extended` queries on every PR + weekly deep-dataflow scan.
- **pytest strict** — `--strict-markers`, `--strict-config`, `xfail_strict`, `filterwarnings=["error"]`.
- **bandit** ratcheted from medium/medium to severity=low + confidence=high. Real smells annotated inline with `# nosec BXXX` + reason.
- **ruff** ratcheted from E/F/W/I/UP to 11 rule sets: +B, +C4, +SIM, +RUF, +PT, +A, +ARG, +PERF, +RET, +TCH, +TRY.
- **Branch coverage** enabled in `pytest-cov`. Floor ratcheted from 60% (line-only) to 80% (line + branch).
- **Property-based tests** (Hypothesis) — 20 invariants on the pattern engine, scorer, YAML-path parser, job splitter, rule-registry integrity, and severity ordering. Motivated by the Goldstein et al. (OOPSLA 2025) finding that PBT catches mutations 52x more often than example-based tests.

### Fixed — audit regressions

- **Bug 2** — `engine.scan_repo` fallthrough now probes Jenkins alongside GitHub/GitLab (dual-platform repos mid-migration no longer silently skip Jenkinsfiles).
- **Bug 3** — `SEC4-JK-001` / `SEC4-JK-002` match only double-quoted Groovy GStrings; single-quoted `sh '...'` is not a GString and doesn't interpolate `${params.X}`.
- **Bug 4** — `_split_into_job_segments` drops hidden-template (`.foo:`) and `spec:` blocks so scope=job rules don't fire twice on templated GitLab pipelines.
- **Bug 7** — Jenkins `SEC3-JK-001` added to `_PINNED_RULE_IDS` so the scorer's +5 all-pinned bonus no longer applies when unpinned shared libraries exist.
- **Bug 10** — `_sweep_tokens` iterates a snapshot of `TokenManager._active` so `tm.clear()`'s self-remove doesn't skip every other token at exit.
- **Bug 18** — `workflow_context` now recognises Jenkins (`credentials()`, `params.`, `agent any`) and GitLab (`CI_JOB_TOKEN`, `VAULT_*`, MR variables) as privileged signals (previously all non-GitHub findings got 0.5× exploitability by default).
- **Bug 19** — `SEC6-GH-007` iex() branch requires a remote-fetch body (Invoke-WebRequest, DownloadString, WebClient) rather than firing on any PowerShell Invoke-Expression call.
- **Bug 21** — `mutate_quote_swap` drops mutants whose quote counts become unbalanced; the harness no longer scores a rule's correct skip of invalid YAML as a miss.
- **Bug 23** — `SEC4-GL-001` excludes single-quoted shell usage; the shell never expands `$VAR` inside single quotes.
- **Bug 24** — `benchmark/taxonomy.py` now maps every TAINT-*, LOTP-*, and SEC4-GH-014/015/016 rule into AIW/IW so Table V comparisons reflect the taint-tracking work.

### Fixed — type drift

- **Real latent bug** in `ingestion/gitlab_api.py`: `fetch_gitlab_ci()` called `_get()` against the `.raw` file endpoint, but `_get()` always `json.loads`-ed the response. Real GitLab YAML content would always raise `JSONDecodeError`. Surfaced by mypy's `warn_unreachable`. Fixed by adding a `_get_raw()` helper that uses `Accept: text/plain` and returns bytes directly.
- 43 missing-generic annotations (`dict` → `dict[str, Any]`) across 18 files.
- `__main__.py` — `token` / `client` variables reused across mutually-exclusive control paths, confusing mypy's narrowing. Renamed to `github_token` / `gitlab_token` / `transitive_token` and `gh_client` / `gl_client` for clarity.
- `rules/{github,gitlab}/taint.py` — `TaintPattern` duck-typed the pattern contract but wasn't in `Rule.pattern`'s type Union. Introduced `PatternProtocol` (structural typing via Protocol).
- `taint.py` — `steps_header_indent` typed as `Optional[int]` but used unguarded on comparison paths. Fixed by splitting the typed `steps_idx: int | None` + non-Optional `steps_header_indent: int`.
- `reporters/sarif.py` — heterogeneous nested SARIF dict annotated `dict[str, Any]`.
- `ingestion/github_api.py` — `dict | list` return narrowed with `isinstance` assertion.
- `platform/github_checks.py` — `Any` id flowed into `int` parameter; narrowed with `isinstance(rs_id, int)`.
- `rules/registry.py`, `fixes.py`, `parsers/gitlab.py` — missing list annotations.

### Fixed — ruff strict ratchet

- **F601** — duplicate dict keys in `reporters/_encoding.py` (`\u2502`/`\u2503` declared twice).
- **B904** — missing `raise ... from exc` in `config.py`, `ConfigError` lost root cause.
- **E741** — ambiguous `l` loop var in `models.py`, `transitive.py`.
- **F841** — unused `rel` variable in `transitive.py` + orphan `import os` (the `rel` computation was never reached; restored in the eventual display-path fix).
- **RUF012** — `TokenManager._active` flagged as mutable class default; annotated `ClassVar[list[TokenManager]]`.

### Fixed — tests + misc

- 5 file-handle leaks in `tests/unit/test_fixes.py` (`open(path).read()` without a context manager), surfaced by pytest strict's `filterwarnings=["error"]`. Fixed via `_read(path)` helper.
- `_SET_OUTPUT_RE` group-name already correct — previously-flagged `(?P<n>...)` / `group("name")` mismatch was already fixed; regression test added.
- `PLAT-GH-001` empty `include:` list now returns `False` (previously silent false-negative: rulesets with no includes were treated as covering-everything).
- `PLAT-GL-003` / `PLAT-GL-004` — `_non_trivial_variables` filters by variable NAME and the `hidden` flag rather than by value length. GitLab 17.x "Masked and hidden" variables (whose value the API never returns) are now retained — the highest-risk class was previously silently skipped.
- `workflow_context` now recognises GitHub Enterprise `runs-on:\n  group: X` as a self-hosted signal.

### Dogfooded

- **Self-audit 100/100 (A).** Every workflow in `.github/workflows/` passes the scanner with zero findings. All 8 jobs pin `timeout-minutes` (motivated by dogfooding SEC10-GH-001). All actions SHA-pinned. All permissions explicit.

### Changed

- Scorer — Jenkins SEC3-JK-001 added to `_PINNED_RULE_IDS` (see Bug 7).
- `benchmark/taxonomy.py` — TAINT / LOTP / SEC4-GH-014/015/016 mappings added.

---

## [0.1.0] — initial development

Pre-CHANGELOG baseline. See git log for early history.

- Core engine, rule registry, 5 pattern types, initial rule set across OWASP CI/CD Top 10.
- GitHub / GitLab / Jenkins platform support.
- Platform posture checks (`--platform-audit`) for GitHub and GitLab.
- Transitive composite-action analysis (`--transitive`).
- Multi-stage taint analyzer (`TAINT-GH-001`..`TAINT-GH-004`, `TAINT-GL-001`..`TAINT-GL-003`).
- Reporters: text / json / csv / sarif / html / score-text.
- Baseline + diff mode for legacy-repo adoption.
- Config file (`.taintly.yml`) with expiring `ignore:` entries.
- Auto-fix (`--fix`, `--fix-dry-run`) for 5 rule classes.

[Unreleased]: https://github.com/Nellur35/taintly/compare/v1.1.0...HEAD
[1.1.0]: https://github.com/Nellur35/taintly/compare/v1.0.0...v1.1.0
[1.0.0]: https://github.com/Nellur35/taintly/compare/v0.9.0...v1.0.0
[0.9.0]: https://github.com/Nellur35/taintly/compare/v0.1.0...v0.9.0
[0.1.0]: https://github.com/Nellur35/taintly/releases/tag/v0.1.0
