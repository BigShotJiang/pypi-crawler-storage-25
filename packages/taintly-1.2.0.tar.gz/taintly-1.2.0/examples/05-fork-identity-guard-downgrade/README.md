# 05 — What a fork-identity guard buys (and what it doesn't)

A common defensive pattern: add `if: github.event.pull_request.head.repo.full_name == github.repository` so the privileged job only runs when the PR is from the same repository, not a fork.

This is a real mitigation — external attackers can no longer reach the job. But it does **not** change the underlying YAML shape, and taintly intentionally still reports the flow at the same severity. This example exists to make that distinction explicit, because users frequently expect the scanner to "see" the guard and downgrade the finding.

## Two variants

`vulnerable/` — no identity check.

```yaml
on: pull_request_target
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - env:
          RAW_TITLE: ${{ github.event.pull_request.title }}
          BUILD_TAG: ${{ env.RAW_TITLE }}
        run: echo "Building with tag: $BUILD_TAG"
```

`guarded/` — adds the identity guard:

```yaml
on: pull_request_target
jobs:
  build:
    runs-on: ubuntu-latest
    if: github.event.pull_request.head.repo.full_name == github.repository
    steps:
      - env:
          RAW_TITLE: ${{ github.event.pull_request.title }}
          BUILD_TAG: ${{ env.RAW_TITLE }}
        run: echo "Building with tag: $BUILD_TAG"
```

## Run both

```
taintly examples/05-fork-identity-guard-downgrade/vulnerable
taintly examples/05-fork-identity-guard-downgrade/guarded
```

Both scans report `[CRITICAL] TAINT-GH-002` at the same severity. The flow is identical — `github.event.pull_request.title -> env.RAW_TITLE -> env.BUILD_TAG -> $BUILD_TAG` — and that flow is the finding. The guard mitigates **who** can fire it; the YAML still says "interpolate this attacker-controlled context into a shell variable through an env chain."

## Why taintly doesn't downgrade

Two reasons:

1. **Scanners flag shape, not exploit chains.** The mitigation lives one PR away from being deleted ("we need this for community contributors"); the shape doesn't.
2. **Same-repo committers are still a threat surface.** A compromised contributor account, a stolen PAT, or an insider all bypass the guard while the shape stays exploitable.

The fork-identity guard belongs in your defence-in-depth, but it isn't a fix for TAINT-GH-002. Treat it as a layer, not a substitute.

## How to actually fix

Apply the TAINT-GH-002 fix from example 01: drop the env chain, bind once, reference the variable:

```yaml
- env:
    RAW_TITLE: ${{ github.event.pull_request.title }}
  run: echo "Building with tag: $RAW_TITLE"
```

Once the shape is fixed, the guard becomes redundant for this flow — but harmless to keep.
