# 07 — PWN-request via reusable workflow (XF-GH-004)

The "pwn-request" shape, documented by GitHub Security Lab: a workflow fires on `pull_request_target` (or `issue_comment`, `pull_request_review`, `workflow_run`) and invokes a reusable workflow that holds privileged scope — through a write-granting `permissions:` block, or through `secrets: inherit`. Whoever can fire the trigger reaches the reusable workflow with the maintainer's full write context.

## The two files

`caller.yml` — fires on `pull_request_target`, calls the reusable workflow with `secrets: inherit`:

```yaml
on:
  pull_request_target:
    types: [opened, synchronize]
jobs:
  validate:
    uses: ./.github/workflows/_validate.yml
    secrets: inherit
```

`_validate.yml` — `workflow_call` reusable, declares write permissions, checks out the PR's head SHA, runs `npm install`:

```yaml
on:
  workflow_call:
permissions:
  contents: write
  pull-requests: write
  issues: write
jobs:
  run:
    steps:
      - uses: actions/checkout@<SHA>  # v4.1.1
        with:
          ref: ${{ github.event.pull_request.head.sha }}
      - run: |
          npm install
          npm test
```

See [`.github/workflows/`](.github/workflows/).

## Why it's wrong

`pull_request_target` runs the workflow definition from the **base** repo (so the attacker can't change the workflow itself via PR), but the run executes against attacker-controlled inputs — and with the base repo's full secrets, write-context, and `GITHUB_TOKEN`. Passing `secrets: inherit` to the reusable workflow hands all of that to the called workflow, where:

1. `permissions:` declares `contents: write` + `pull-requests: write` + `issues: write` — anything those scopes can do (force-push to `main`, post comments as the bot, mutate labels) is now available to the attacker.
2. `actions/checkout@v4` with `ref: ${{ github.event.pull_request.head.sha }}` checks out the **attacker's** code on the privileged runner.
3. `npm install` runs the attacker's `package.json` lifecycle scripts under the inherited secrets and write context — npm's `preinstall` / `postinstall` hooks execute the moment install begins, before any test or lint step.

Anyone who can open a PR or trigger a `pull_request_target`-listed event reaches this code path.

## Run it

```
taintly examples/07-pull-request-target-checkout
```

The scan reports a **cluster** of related findings — the pwn-request shape never fires alone. The structural rule is XF-GH-004; the rest are the consequences:

```
[HIGH]     XF-GH-004    PWN-request shape (the structural finding)
[HIGH]     SEC4-GH-002  pull_request_target trigger detected
[HIGH]     SEC4-GH-012  secrets: inherit passes all caller secrets to called workflow
[CRITICAL] LOTP-GH-001  Build tool executed in job that checks out PR code (npm install / npm test)
[HIGH]     LOTP-GH-003  npm install without --ignore-scripts in externally-triggered workflow
[MEDIUM]   XF-GH-003    Reusable-workflow fanout hub (secrets: inherit)
[MEDIUM]   SEC4-GH-005  Checkout persists credentials to disk
[MEDIUM]   SEC2-GH-002  No explicit permissions defined
```

This is the pattern to recognise in real audits: a single bad shape produces a cluster, and the cluster reinforces the diagnosis. If you only see XF-GH-004, the rule fired but the workflow doesn't actually carry the full shape — investigate. If you see all eight, you've found a real one.

## How to fix

Pick at least one — ideally several:

1. **Switch the caller to plain `pull_request`.** It runs on the fork's commit with a read-only `GITHUB_TOKEN` and no secret injection — the entire chain dissolves.

2. **Gate by same-repo identity.** Add `if: github.event.pull_request.head.repo.full_name == github.repository` on the privileged job. Same-repo PRs only — fork PRs cannot trigger the privileged path.

3. **Replace `secrets: inherit` with explicit per-secret mappings.** Pass only what the reusable actually needs, and drop high-impact secrets entirely.

4. **Drop write permissions from the reusable workflow.** Validation should be `contents: read` only. If the reusable also handles labelling, split it: read-only validation + identity-gated labelling, never both in the same job.

5. **Don't check out the attacker's SHA on `pull_request_target`.** If you must run validation against PR code, do it on `pull_request` (read-only) instead, and have a separate gated workflow apply privileged side-effects after a maintainer review.

6. **Pass `--ignore-scripts` to every npm/yarn/pnpm install in fork-triggered workflows.** Closes the LOTP-GH-003 hook even if the rest of the chain stays.
