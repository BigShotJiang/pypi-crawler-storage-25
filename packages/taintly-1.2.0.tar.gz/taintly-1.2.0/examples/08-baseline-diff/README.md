# 08 — Baseline / diff workflow

Real CI integrations rarely start from zero — most repositories have a backlog of findings the team has accepted, ignored, or scheduled for later. `--baseline` and `--diff` let you set that backlog aside and surface only **new** issues introduced by a change.

This example shows both halves:

* `before-fix/` — an existing release workflow with three long-standing findings (one critical, two medium). The team has accepted these for now.
* `after-fix/` — the same workflow, with the critical taint flow fixed AND an unrelated regression introduced by a new step (an unpinned `actions/upload-artifact@v4`).

A naïve scan of `after-fix/` reports only the new finding — but you can't tell from one scan whether it's a regression or an existing issue. With a baseline captured before the change, `--diff` tells you exactly that.

## The two trees

`before-fix/.github/workflows/release.yml` — three findings: TAINT-GH-002 (multi-hop env taint), SEC1-GH-001 (no environment approval gate), SEC4-GH-005 (checkout persists credentials):

```yaml
on:
  push:
    branches: [main]
permissions:
  contents: write
  packages: write
jobs:
  publish:
    steps:
      - uses: actions/checkout@<SHA>  # v4.1.1
      - env:
          RAW_MSG: ${{ github.event.head_commit.message }}
          BUILD_TAG: ${{ env.RAW_MSG }}
        run: echo "Building tag: $BUILD_TAG"
```

`after-fix/.github/workflows/release.yml` — taint flow fixed (no `github.event.*` reaches `run:`), `persist-credentials: false`, environment approval gate added — but a new step introduces an unpinned action regression (`actions/upload-artifact@v4`):

```yaml
on:
  push:
    branches: [main]
permissions:
  contents: write
  packages: write
jobs:
  publish:
    environment:
      name: production
    steps:
      - uses: actions/checkout@<SHA>  # v4.1.1
        with:
          persist-credentials: false
      - run: |
          echo "Building tag: $GITHUB_SHA"
          mkdir -p out
          echo "release-of-$GITHUB_SHA" > out/marker.txt
      - uses: actions/upload-artifact@v4   # <-- regression: unpinned
        with:
          name: release-marker
          path: out/marker.txt
```

## Run the workflow

Capture a baseline against the existing tree:

```
taintly examples/08-baseline-diff/before-fix --baseline /tmp/baseline.json
```

Output: 3 findings (TAINT-GH-002 / SEC1-GH-001 / SEC4-GH-005), baseline written.

Now scan the proposed change in `--diff` mode against that baseline:

```
taintly examples/08-baseline-diff/after-fix --diff /tmp/baseline.json
```

Output: 1 finding — `[HIGH] SEC3-GH-001: Unpinned action`. The taint flow is gone (the team's fix worked), the existing accepted findings are filtered out (you accepted them yesterday, you don't need to re-litigate), and the only thing surfaced is the genuinely new regression.

## How to wire this into CI

1. Commit `.taintly-baseline.json` to your repo (one-time, captured against `main`).
2. In CI, run `taintly . --diff` on every PR. The PR fails only if the change introduces something the baseline didn't already accept.
3. Refresh the baseline when the team works down the backlog (`taintly . --baseline`); commit the new file.

Treat the baseline as a **declaration of accepted risk**, not a permanent silencer. PRs that touch baselined files should review whether their accepted findings still belong on the list.
