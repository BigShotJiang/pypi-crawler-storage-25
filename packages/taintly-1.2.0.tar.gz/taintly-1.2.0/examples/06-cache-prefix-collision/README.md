# 06 — Cache prefix collision across privilege tiers (XF-GH-001A)

Two workflows in the same repository share a cache key prefix: a privileged release build (push to `main`) and a fork-reachable test job (`pull_request`). Per Adnan Khan (2024), GitHub Actions caches are scoped **per-repository**, not per-trigger — a malicious PR can install a poisoned package store under the shared prefix, and the next push to `main` silently restores it into the privileged build.

## The two workflows

`release.yml` — push to main, has `contents: write` + `packages: write`:

```yaml
on:
  push:
    branches: [main]
permissions:
  contents: write
  packages: write
jobs:
  build:
    steps:
      - uses: actions/cache@v4
        with:
          path: ~/.pnpm-store
          key: pnpm-store-${{ hashFiles('pnpm-lock.yaml') }}
          restore-keys: pnpm-store-
      - run: pnpm install --frozen-lockfile
      - run: pnpm publish --access public
```

`pr-test.yml` — fork-reachable, but only `contents: read`:

```yaml
on: pull_request
jobs:
  test:
    steps:
      - uses: actions/cache@v4
        with:
          path: ~/.pnpm-store
          key: pnpm-store-${{ hashFiles('pnpm-lock.yaml') }}
          restore-keys: pnpm-store-
      - run: pnpm install
      - run: pnpm test
```

See [`.github/workflows/`](.github/workflows/).

## Why it's wrong

The two workflows share the cache key prefix `pnpm-store-`. When a PR runs `pnpm install`, the resulting store is keyed under that prefix. The next push to `main` matches via `restore-keys: pnpm-store-` and restores the PR's store verbatim. If the PR's store contains a backdoored transitive dep (a malicious package replaced one entry in the resolved tree), the privileged release build runs the attacker's code at every `require()` — and ships the resulting artefact via `pnpm publish`.

The fork-reachable workflow doesn't need write permissions to write the cache. The exploit is **deferred** — execution happens later, in a different workflow, with privilege the attacker never had.

## Run it

```
taintly examples/06-cache-prefix-collision
```

Expected headline finding:

```
[HIGH] XF-GH-001A: Executable-cache poisoning across privilege tiers
```

(`XF-GH-001A` is the executable-content tier — package stores, `node_modules`, compiled toolchain layers — where restoring the cache **directly executes** attacker code. The generic data-cache variant `XF-GH-001` is `MEDIUM` and review-needed.)

## How to fix

Two complementary fixes — pick at least one:

1. **Scope the cache key by trigger so fork and privileged builds never share a prefix:**

   ```yaml
   key: ${{ github.event_name }}-pnpm-store-${{ hashFiles('pnpm-lock.yaml') }}
   restore-keys: ${{ github.event_name }}-pnpm-store-
   ```

   `pull_request` and `push` now produce distinct prefixes. A poisoned PR cache cannot be restored by the privileged build.

2. **Drop `restore-keys` from the privileged workflow.** A cache miss is rebuild cost — not a security incident. The release build always re-resolves from `pnpm-lock.yaml` instead of trusting any stored content.

Either fix breaks the chain. Use both for defence in depth.
