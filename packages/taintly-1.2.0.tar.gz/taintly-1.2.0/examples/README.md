# taintly examples

Eight worked examples that demonstrate the rule families taintly catches. Each example is a self-contained, scannable directory — point taintly at the directory, see the findings, read the README for the attack narrative and the fix.

All workflows are synthetic. Generic placeholders (`example-org`, `acme-corp`, `widget-bot`) — never real organisations. The rule findings, however, may reference real incidents in their `Incidents:` field; that's data carried by the rules themselves, not by the example content.

## Index

| #   | Example                                    | Rule(s)              | Severity | What it shows                                                                          |
| --- | ------------------------------------------ | -------------------- | -------- | -------------------------------------------------------------------------------------- |
| 01  | [multi-hop-env](01-multi-hop-env/)         | `TAINT-GH-002`       | CRITICAL | Attacker context laundered through a chain of `env:` indirections into `run:`.         |
| 02  | [github-env-bridge](02-github-env-bridge/) | `TAINT-GH-003`       | CRITICAL | Attacker context written to `$GITHUB_ENV` in one step, expanded as bash in the next.   |
| 03  | [agent-output-taint](03-agent-output-taint/) | `TAINT-GH-005`     | HIGH     | AI agent step output (prompt-injectable) interpolated into a shell `run:` block.       |
| 04  | [cross-job-needs](04-cross-job-needs/)     | `TAINT-GH-009`       | CRITICAL | Producer job exposes attacker context via `outputs:`; privileged consumer interpolates it. |
| 05  | [fork-identity-guard-downgrade](05-fork-identity-guard-downgrade/) | `TAINT-GH-002` | CRITICAL | Two variants: with and without an `if:` identity guard. Both fire — guard is mitigation, not fix. |
| 06  | [cache-prefix-collision](06-cache-prefix-collision/) | `XF-GH-001A` | HIGH     | Privileged release build and fork-reachable PR test share a pnpm-store cache prefix.   |
| 07  | [pull-request-target-checkout](07-pull-request-target-checkout/) | `XF-GH-004` | HIGH     | PWN-request shape: `pull_request_target` caller invokes a write-context reusable workflow with `secrets: inherit`. |
| 08  | [baseline-diff](08-baseline-diff/)         | (workflow demo)      | —        | `--baseline` against an existing tree, `--diff` surfaces only newly-introduced findings. |

## Run all of them

Scan one example:

```bash
taintly examples/01-multi-hop-env
```

Scan every example and assert each fires its expected rules (CI uses this script):

```bash
bash scripts/verify-examples.sh
```

Tour every example sequentially:

```bash
for d in examples/0*/; do echo "=== $d ==="; python -m taintly "$d"; done
```

## How each example is structured

```
examples/<NN-name>/
├── README.md                       # narrative: what's wrong, attack, fix
├── expected-rules.txt              # rules that must fire (verify-examples.sh)
└── .github/workflows/*.yml         # the synthetic vulnerable workflow(s)
```

Examples 05 and 08 split into subdirectories (`vulnerable/` + `guarded/`, `before-fix/` + `after-fix/`) when comparing two scan targets is part of the lesson.

`expected-rules.txt` lines starting with `#` are comments. Blank lines are ignored. One rule ID per line; the rule must appear at least once in the scan output of the parent directory.

## Adding a new example

1. Create `examples/NN-name/` with `.github/workflows/yourfile.yml` and `expected-rules.txt`.
2. Run `taintly examples/NN-name/` and copy the firing rule IDs into `expected-rules.txt`.
3. Run `bash scripts/verify-examples.sh` to confirm.
4. Add a row to the index table above.
