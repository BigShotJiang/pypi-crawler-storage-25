"""Synthetic benchmark fixtures — progressive difficulty test workflows.

These complement the real-world dataset with controlled test cases where
ground truth is known by construction. Organized by the paper's taxonomy.

Three fixture types:
  1. PER-CATEGORY: One workflow per weakness category with known findings
  2. PROGRESSIVE:  Level 1-10 difficulty progression
  3. FALSE-POSITIVE: Patterns that MUST NOT fire (from FastAPI scan analysis)

Each fixture is a complete, valid workflow YAML with annotations.

NOTE: PTW (Privileged Trigger Weakness) replaces TMW in paper v2.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SyntheticFixture:
    """A synthetic workflow with known ground truth."""

    name: str
    description: str
    category: str  # "per_category" | "progressive" | "false_positive"
    difficulty: int  # 1-10 (0 for non-progressive)
    platform: str  # "github" | "gitlab"
    content: str
    must_fire: list[str]
    must_not_fire: list[str] = field(default_factory=list)
    weakness_categories: list[str] = field(default_factory=list)  # Paper taxonomy codes
    notes: str = ""


# ============================================================================
# PER-CATEGORY FIXTURES
# ============================================================================

CATEGORY_FIXTURES: list[SyntheticFixture] = [
    SyntheticFixture(
        name="aiw_script_injection",
        description="Attacker-controlled context values in run: blocks",
        category="per_category",
        difficulty=0,
        platform="github",
        weakness_categories=["AIW"],
        must_fire=["SEC4-GH-004", "SEC4-GH-006"],
        content="""\
name: PR Handler
on: pull_request_target

permissions:
  contents: read

jobs:
  process:
    runs-on: ubuntu-latest
    steps:
      - name: Log PR title
        run: echo "Processing: ${{ github.event.pull_request.title }}"
      - name: Set branch env
        run: echo "BRANCH=${{ github.head_ref }}" >> $GITHUB_ENV
""",
    ),
    SyntheticFixture(
        name="cfw_workflow_run_no_check",
        description="workflow_run without conclusion check + missing env gate",
        category="per_category",
        difficulty=0,
        platform="github",
        weakness_categories=["CFW"],
        must_fire=["SEC4-GH-003", "SEC1-GH-001"],
        content="""\
name: Deploy on Build
on:
  workflow_run:
    workflows: [Build]
    types: [completed]

permissions:
  contents: read

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          persist-credentials: false
      - run: ./deploy.sh
""",
    ),
    SyntheticFixture(
        name="epw_write_all",
        description="write-all permissions",
        category="per_category",
        difficulty=0,
        platform="github",
        weakness_categories=["EPW"],
        must_fire=["SEC2-GH-001"],
        content="""\
name: Overpermissioned
on: push

permissions: write-all

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          persist-credentials: false
      - run: npm test
""",
    ),
    SyntheticFixture(
        name="grcw_self_hosted_pr",
        description="Self-hosted runner on pull_request trigger",
        category="per_category",
        difficulty=0,
        platform="github",
        weakness_categories=["GRCW"],
        must_fire=["SEC7-GH-003"],
        content="""\
name: PR Tests
on: pull_request

permissions:
  contents: read

jobs:
  test:
    runs-on: [self-hosted, linux]
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          persist-credentials: false
      - run: make test
""",
    ),
    SyntheticFixture(
        name="hgw_no_persist_creds",
        description="Checkout without persist-credentials: false + debug mode",
        category="per_category",
        difficulty=0,
        platform="github",
        weakness_categories=["HGW"],
        must_fire=["SEC4-GH-005", "SEC7-GH-002"],
        content="""\
name: CI
on: push

permissions:
  contents: read

env:
  ACTIONS_RUNNER_DEBUG: true

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
      - run: npm ci && npm test
""",
    ),
    SyntheticFixture(
        name="iw_curl_bash_base64",
        description="curl|bash and base64 decode|shell patterns",
        category="per_category",
        difficulty=0,
        platform="github",
        weakness_categories=["IW"],
        must_fire=["SEC6-GH-006", "SEC6-GH-007"],
        content="""\
name: Setup
on: push

permissions:
  contents: read

jobs:
  install:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          persist-credentials: false
      - name: Install tool
        run: curl -sSL https://get.example.com/install.sh | bash
      - name: Run payload
        run: echo 'cGF5bG9hZA==' | base64 --decode | bash
""",
    ),
    SyntheticFixture(
        name="kvcw_cache_in_release",
        description="Mutable cache action in release workflow",
        category="per_category",
        difficulty=0,
        platform="github",
        weakness_categories=["KVCW"],
        must_fire=["SEC9-GH-003"],
        content="""\
name: Release
on:
  release:
    types: [published]

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          persist-credentials: false
      - uses: actions/setup-node@v4
        with:
          cache: npm
      - run: npm ci && npm run build
""",
    ),
    SyntheticFixture(
        name="sew_hardcoded_and_tojson",
        description="Hardcoded secret, toJSON(secrets), inline secret interpolation",
        category="per_category",
        difficulty=0,
        platform="github",
        weakness_categories=["SEW"],
        must_fire=["SEC6-GH-004", "SEC6-GH-005"],
        content="""\
name: Deploy
on: push

permissions:
  contents: read

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          persist-credentials: false
      - name: Dump all secrets
        env:
          ALL_SECRETS: ${{ toJSON(secrets) }}
        run: echo "processing"
      - name: Inline secret
        run: ./deploy.sh ${{ secrets.DEPLOY_KEY }}
""",
    ),
    SyntheticFixture(
        name="ptw_prt_with_checkout",
        description="pull_request_target with checkout of untrusted PR head (PTW)",
        category="per_category",
        difficulty=0,
        platform="github",
        weakness_categories=["PTW"],
        must_fire=["SEC4-GH-001", "SEC4-GH-002"],
        content="""\
name: PR Review
on: pull_request_target

permissions:
  contents: read
  pull-requests: write

jobs:
  review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          ref: ${{ github.event.pull_request.head.sha }}
          persist-credentials: false
      - run: npm ci && npm test
""",
    ),
    SyntheticFixture(
        name="udw_unpinned_actions",
        description="Multiple unpinned actions with mutable tags and branch refs",
        category="per_category",
        difficulty=0,
        platform="github",
        weakness_categories=["UDW"],
        must_fire=["SEC3-GH-001", "SEC3-GH-002", "SEC3-GH-005"],
        content="""\
name: CI
on: push

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v3.1.2
      - uses: some-org/deploy@main
      - uses: docker://alpine:3.18
      - run: npm test
""",
    ),
]


# ============================================================================
# FALSE POSITIVE FIXTURES (from FastAPI real-world scan, BUG-7)
# ============================================================================

FALSE_POSITIVE_FIXTURES: list[SyntheticFixture] = [
    SyntheticFixture(
        name="fp_secret_in_with_block",
        description="Secret passed as action input via with: — NOT shell interpolation",
        category="false_positive",
        difficulty=0,
        platform="github",
        must_fire=[],
        must_not_fire=["SEC6-GH-005"],
        content="""\
name: Label PR
on: pull_request_target

permissions:
  contents: read
  pull-requests: write

jobs:
  label:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          persist-credentials: false
      - uses: actions/labeler@v5
        with:
          repo-token: "${{ secrets.GITHUB_TOKEN }}"
""",
        notes="BUG-7: SEC6-GH-005 must not fire on with: params — action inputs, not shell.",
    ),
    SyntheticFixture(
        name="fp_head_ref_in_checkout_with",
        description="github.head_ref used as checkout ref param — NOT shell injection",
        category="false_positive",
        difficulty=0,
        platform="github",
        must_fire=[],
        must_not_fire=["SEC4-GH-004"],
        content="""\
name: PR CI
on: pull_request

permissions:
  contents: read

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          ref: ${{ github.head_ref }}
          persist-credentials: false
      - run: npm test
""",
        notes="BUG-7: SEC4-GH-004 must not fire when head_ref is a YAML key value, not embedded in shell.",
    ),
    SyntheticFixture(
        name="fp_dispatch_input_in_env",
        description="workflow_dispatch input used in env: block — the SAFE mitigation pattern",
        category="false_positive",
        difficulty=0,
        platform="github",
        must_fire=[],
        must_not_fire=["SEC4-GH-008"],
        content="""\
name: Manual Deploy
on:
  workflow_dispatch:
    inputs:
      environment:
        description: Target environment
        required: true

permissions:
  contents: read

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          persist-credentials: false
      - name: Deploy
        env:
          TARGET_ENV: ${{ github.event.inputs.environment }}
        run: echo "Deploying to $TARGET_ENV"
""",
        notes="BUG-7: SEC4-GH-008 fires on the recommended remediation pattern. env: is safe.",
    ),
    SyntheticFixture(
        name="fp_lotp_guarded_by_pr_event",
        description="npm in PRT file but job gated to pull_request events only — safe",
        category="false_positive",
        difficulty=0,
        platform="github",
        must_fire=[],
        must_not_fire=["SEC4-GH-011"],
        content="""\
name: CI with PRT
on:
  pull_request_target:
  pull_request:

permissions:
  contents: read

jobs:
  lint:
    if: github.event_name == 'pull_request'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          persist-credentials: false
      - run: npm ci && npm run lint

  test:
    if: github.event_name == 'pull_request'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4
        with:
          persist-credentials: false
      - run: npm ci && npm test
""",
        notes="BUG-6: SEC4-GH-011 must not fire when every npm job is gated to pull_request only.",
    ),
    SyntheticFixture(
        name="fp_lotp_make_in_quoted_message",
        description="'make' appears in a quoted JSON message string in issue-manager config — NOT a shell command",
        category="false_positive",
        difficulty=0,
        platform="github",
        must_fire=[],
        must_not_fire=["SEC4-GH-011"],
        content="""\
name: Issue Manager

on:
  pull_request_target:
    types:
      - labeled

permissions:
  issues: write
  pull-requests: write

jobs:
  issue-manager:
    runs-on: ubuntu-latest
    steps:
      - uses: tiangolo/issue-manager@0.6.0
        with:
          token: ${{ secrets.GITHUB_TOKEN }}
          config: >
            {
              "maybe-ai": {
                "delay": 0,
                "message": "This was marked as potentially AI generated. make sure to read the docs about contributing and AI."
              }
            }
""",
        notes="BUG-8: SEC4-GH-011 anchor \\bmake\\b fires on English word 'make' inside a YAML JSON string value.",
    ),
    SyntheticFixture(
        name="fp_gitlab_rules_if",
        description="GitLab rules:if using CI variables — evaluated by engine, not shell",
        category="false_positive",
        difficulty=0,
        platform="gitlab",
        must_fire=[],
        must_not_fire=[],  # GitLab injection rule not yet confirmed; no false positive assertion
        content="""\
stages:
  - build
  - deploy

build:
  stage: build
  rules:
    - if: $CI_COMMIT_BRANCH == "main"
    - if: $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME =~ /^feature/
  script:
    - make build

deploy:
  stage: deploy
  rules:
    - if: $CI_COMMIT_BRANCH == "main"
      when: manual
  script:
    - make deploy
""",
        notes="rules:if blocks are GitLab engine conditions, not shell. Should not fire injection rules.",
    ),
]


# ============================================================================
# All fixtures combined
# ============================================================================

ALL_FIXTURES: list[SyntheticFixture] = CATEGORY_FIXTURES + FALSE_POSITIVE_FIXTURES


def get_fixtures_by_category(category: str) -> list[SyntheticFixture]:
    return [f for f in ALL_FIXTURES if f.category == category]


def get_fixtures_by_weakness(code: str) -> list[SyntheticFixture]:
    return [f for f in ALL_FIXTURES if code in f.weakness_categories]
