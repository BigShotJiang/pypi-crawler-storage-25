"""Benchmark dataset collector — fetches real-world workflows for scanner evaluation.

Reproduces the dataset methodology from:
  Fares, Gamage, Baudry. "Unpacking Security Scanners for GitHub Actions Workflows."
  arXiv:2601.14455v2, March 2026. Université de Montréal.

The paper collected 2,722 workflows from 388 repos across major tech orgs.
This collector uses the same criteria:
  - Repos from verified GitHub orgs of largest tech companies
  - Minimum 2,000 GitHub stars
  - At least one workflow file in .github/workflows/
  - Commit within the last 12 months

Usage:
  GITHUB_TOKEN=ghp_... python -m benchmark collect --output benchmark/dataset/
  GITHUB_TOKEN=ghp_... python -m benchmark collect --orgs microsoft google --min-stars 5000

Zero dependencies — uses only stdlib urllib (same as taintly.ingestion).
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

# ============================================================================
# GitHub orgs from the paper's methodology (largest tech companies by revenue
# with verified GitHub orgs). This list covers the paper's named orgs plus
# additional high-profile orgs to expand coverage.
# ============================================================================

PAPER_ORGS: list[str] = [
    # Explicitly named in the paper
    "microsoft",
    "google",
    "huggingface",
    "vercel",
    "nvidia",
    # Additional large tech company orgs
    "facebook",
    "meta-llama",
    "aws",
    "amazon",
    "apple",
    "hashicorp",
    "docker",
    "kubernetes",
    "apache",
    "mozilla",
    "elastic",
    "grafana",
    "prometheus",
    "tensorflow",
    "pytorch",
    "rust-lang",
    "golang",
    "nodejs",
    "pallets",
    "django",
    "tiangolo",
    "anthropics",
    "openai",
    "langchain-ai",
    "supabase",
    "prisma",
    "cloudflare",
    "stripe",
    "shopify",
    "twitter",
    "uber",
    "airbnb",
    "netflix",
    "spotify",
    "datadog",
    "redhat-developer",
    "jenkinsci",
    "gitlab-org",
]

_BASE = "https://api.github.com"
_RATE_LIMIT_PAUSE = 60


def _get(path: str, token: str) -> dict | list:
    url = f"{_BASE}{path}"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        if e.code == 403:
            reset = e.headers.get("X-RateLimit-Reset")
            if reset:
                wait = max(int(reset) - int(time.time()), 5)
                print(f"  Rate limited. Waiting {wait}s...", file=sys.stderr)
                time.sleep(min(wait, _RATE_LIMIT_PAUSE))
                with urllib.request.urlopen(req, timeout=30) as resp:
                    return json.loads(resp.read())
        raise


def _paginate(path: str, token: str, max_pages: int = 20) -> list[dict]:
    items = []
    page = 1
    while page <= max_pages:
        sep = "&" if "?" in path else "?"
        try:
            data = _get(f"{path}{sep}per_page=100&page={page}", token)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                break
            raise
        if not data:
            break
        if isinstance(data, list):
            items.extend(data)
            if len(data) < 100:
                break
        page += 1
    return items


@dataclass
class WorkflowFile:
    org: str
    repo: str
    repo_stars: int
    path: str
    content: str
    lines: int
    jobs_count: int
    uses_count: int
    triggers: list[str]


@dataclass
class CollectionManifest:
    collected_at: str
    orgs_queried: list[str]
    min_stars: int
    repos_scanned: int
    repos_with_workflows: int
    total_workflows: int
    total_lines: int
    workflows_per_org: dict[str, int] = field(default_factory=dict)


def _count_jobs(content: str) -> int:
    lines = content.splitlines()
    in_jobs = False
    count = 0
    for line in lines:
        if re.match(r"^jobs:\s*$", line):
            in_jobs = True
            continue
        if in_jobs:
            stripped = line.lstrip()
            indent = len(line) - len(stripped)
            if indent == 0 and stripped and not stripped.startswith("#"):
                in_jobs = False
            elif indent == 2 and stripped and not stripped.startswith("#") and ":" in stripped:
                count += 1
    return count


def _count_uses(content: str) -> int:
    return len(re.findall(r"^\s*-?\s*uses:", content, re.MULTILINE))


def _extract_triggers(content: str) -> list[str]:
    m = re.search(r"^on:\s*\[([^\]]+)\]", content, re.MULTILINE)
    if m:
        return [t.strip() for t in m.group(1).split(",")]

    m = re.search(r"^on:\s+(\S+)", content, re.MULTILINE)
    if m and m.group(1):
        return [m.group(1)]

    lines = content.splitlines()
    triggers = []
    in_on = False
    for line in lines:
        if re.match(r"^on:\s*$", line):
            in_on = True
            continue
        if in_on:
            stripped = line.lstrip()
            indent = len(line) - len(stripped)
            if indent == 0 and stripped and not stripped.startswith("#"):
                break
            if indent == 2 and stripped and ":" in stripped:
                triggers.append(stripped.split(":")[0].strip())
    return triggers


def collect_org_workflows(
    org: str,
    token: str,
    min_stars: int = 2000,
    max_age_months: int = 12,
) -> list[WorkflowFile]:
    cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_months * 30)
    cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")

    print(f"  Scanning org: {org}", file=sys.stderr)

    try:
        repos = _paginate(f"/orgs/{org}/repos?sort=stars&direction=desc", token)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"    Org {org} not found, skipping", file=sys.stderr)
            return []
        raise

    workflows = []
    repos_checked = 0

    for repo in repos:
        if repo.get("archived") or repo.get("disabled") or repo.get("fork"):
            continue
        stars = repo.get("stargazers_count", 0)
        if stars < min_stars:
            break  # sorted by stars desc
        pushed_at = repo.get("pushed_at", "")
        if pushed_at and pushed_at < cutoff_str:
            continue

        full_name = repo["full_name"]
        repos_checked += 1

        try:
            wf_items = _get(f"/repos/{full_name}/contents/.github/workflows", token)
        except urllib.error.HTTPError:
            continue

        if not isinstance(wf_items, list):
            continue

        for item in wf_items:
            if item.get("type") != "file":
                continue
            name = item["name"]
            if not (name.endswith(".yml") or name.endswith(".yaml")):
                continue

            try:
                file_data = _get(
                    f"/repos/{full_name}/contents/.github/workflows/{name}", token
                )
                content = base64.b64decode(file_data["content"]).decode("utf-8", errors="replace")
            except Exception:
                continue

            workflows.append(WorkflowFile(
                org=org,
                repo=full_name,
                repo_stars=stars,
                path=f".github/workflows/{name}",
                content=content,
                lines=len(content.splitlines()),
                jobs_count=_count_jobs(content),
                uses_count=_count_uses(content),
                triggers=_extract_triggers(content),
            ))

        if repos_checked % 10 == 0:
            print(f"    {repos_checked} repos, {len(workflows)} workflows so far", file=sys.stderr)

    print(f"    Done: {repos_checked} repos, {len(workflows)} workflows", file=sys.stderr)
    return workflows


def save_dataset(
    workflows: list[WorkflowFile],
    output_dir: str,
    orgs_queried: list[str],
    min_stars: int,
) -> CollectionManifest:
    out = Path(output_dir)
    wf_dir = out / "workflows"
    wf_dir.mkdir(parents=True, exist_ok=True)

    index = []
    for wf in workflows:
        org_dir = wf_dir / wf.org
        org_dir.mkdir(exist_ok=True)

        repo_short = wf.repo.split("/")[-1]
        wf_name = wf.path.split("/")[-1]
        filepath = org_dir / f"{repo_short}__{wf_name}"
        filepath.write_text(wf.content, encoding="utf-8")

        index.append({
            "org": wf.org,
            "repo": wf.repo,
            "repo_stars": wf.repo_stars,
            "path": wf.path,
            "file": str(filepath.relative_to(out)),
            "lines": wf.lines,
            "jobs_count": wf.jobs_count,
            "uses_count": wf.uses_count,
            "triggers": wf.triggers,
        })

    (out / "index.json").write_text(json.dumps(index, indent=2), encoding="utf-8")

    wf_per_org: dict[str, int] = {}
    for wf in workflows:
        wf_per_org[wf.org] = wf_per_org.get(wf.org, 0) + 1

    manifest = CollectionManifest(
        collected_at=datetime.now(timezone.utc).isoformat(),
        orgs_queried=orgs_queried,
        min_stars=min_stars,
        repos_scanned=len(set(wf.repo for wf in workflows)),
        repos_with_workflows=len(set(wf.repo for wf in workflows)),
        total_workflows=len(workflows),
        total_lines=sum(wf.lines for wf in workflows),
        workflows_per_org=wf_per_org,
    )
    (out / "manifest.json").write_text(json.dumps(asdict(manifest), indent=2), encoding="utf-8")
    return manifest


def main():
    parser = argparse.ArgumentParser(
        prog="benchmark-collector",
        description=(
            "Collect real-world GitHub Actions workflows for scanner benchmarking. "
            "Reproduces the methodology from Fares et al. arXiv:2601.14455v2."
        ),
    )
    parser.add_argument("--output", "-o", default="benchmark/dataset")
    parser.add_argument("--orgs", nargs="*", default=None)
    parser.add_argument("--min-stars", type=int, default=2000)
    parser.add_argument("--max-age-months", type=int, default=12)
    args = parser.parse_args()

    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        print("Error: GITHUB_TOKEN environment variable required", file=sys.stderr)
        sys.exit(1)

    orgs = args.orgs or PAPER_ORGS
    all_workflows: list[WorkflowFile] = []

    print(f"Collecting workflows from {len(orgs)} orgs (min {args.min_stars} stars)...", file=sys.stderr)

    for org in orgs:
        try:
            wfs = collect_org_workflows(org, token, args.min_stars, args.max_age_months)
            all_workflows.extend(wfs)
        except Exception as e:
            print(f"  Error on org {org}: {e}", file=sys.stderr)

    if not all_workflows:
        print("No workflows collected.", file=sys.stderr)
        sys.exit(1)

    manifest = save_dataset(all_workflows, args.output, orgs, args.min_stars)
    print(f"\nDone: {manifest.repos_with_workflows} repos, {manifest.total_workflows} workflows → {args.output}/", file=sys.stderr)


if __name__ == "__main__":
    main()
