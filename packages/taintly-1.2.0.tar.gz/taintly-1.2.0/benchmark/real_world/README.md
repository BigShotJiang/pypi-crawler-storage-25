# Real-world regression corpus

Minimal fixtures derived from public workflows that exhibit specific
detection shapes, with rule-ID-level ground truth in [`labels.py`](labels.py).

## What this catches

- **Rule regressions**: a rule tweak that silences a finding on a
  known-vulnerable shape (a GitHub workflow, GitLab pipeline, or
  Jenkinsfile) fails the gate.
- **Forbidden-rule firing**: a rule tweak that widens an adjacent
  rule's scope past its intent also fails.
- **Engine regressions**: a discovery or scoping change that skips
  a fixture or mis-segments a job surfaces here.

Unlike [`benchmark/corpus/`](../corpus/) (which asserts family-level
clusters and score bands), this corpus asserts at the **rule-ID**
level — the tightest grain the scanner produces.

## Running

```bash
python -m benchmark.real_world            # run + pass/fail exit code
python -m benchmark.real_world --verbose  # show hits even on pass
python -m benchmark.real_world --fixture jenkins/roryeckel-codex-Jenkinsfile
```

The pytest gate in
[`tests/integration/test_real_world_regression.py`](../../tests/integration/test_real_world_regression.py)
runs the same check in CI.

## Adding a fixture

1. Find a public workflow that exhibits the shape you want to pin.
   Prefer permissive-license (MIT / Apache-2.0 / BSD) sources.
2. Derive a minimal fixture into
   `fixtures/{ai-ecosystem,gitlab,jenkins,<category>}/<slug>.ext`.
   Keep only the structural ingredients the rule needs.
3. Add a header comment citing the source repo, license, and the
   rule(s) the fixture is meant to exercise.
4. Add a `Fixture(...)` entry to [`labels.py`](labels.py) declaring:
   - `expected_rule_ids` — rule IDs that must fire (strict >=1 hit).
   - `forbidden_rule_ids` — rule IDs that must NOT fire (pin an
     adjacent rule's scope).
5. Run `python -m benchmark.real_world --verbose` to confirm the
   hits match your labels.
6. Add a test-case note to the PR description so reviewers can
   trace the fixture back to the incident / research writeup.

## Discipline

- **Don't silence drift by deleting a fixture**. If the fixture
  genuinely no longer represents the shape it used to (rare), update
  the `Fixture` entry and explain why in the commit.
- **Don't over-specify**. `expected_rule_ids` = "this rule must fire
  somewhere in this fixture." Exact line counts aren't pinned because
  fixtures are trimmed derivatives.
- **Keep fixtures small** (< 100 lines). The test suite must stay
  fast; a full real repo's workflow is usually > 300 lines and adds
  no signal over the few lines that anchor the attack.
