"""Ground truth for the real-world regression corpus.

Each ``Fixture`` entry declares the rule IDs that MUST fire on the
fixture's file (``expected_rule_ids``) and optionally rule IDs that
must NOT fire (``forbidden_rule_ids``) — the latter prevents a rule
from accidentally firing outside its intended shape after a tweak.

Discipline:
  * ``expected_rule_ids`` is a strict "at least one hit" per ID —
    exact line counts aren't gated because fixtures are shortened
    derivatives of real files.
  * ``forbidden_rule_ids`` is "zero hits" for each ID — useful for
    pinning that an adjacent rule stays out of scope (e.g., the
    pydantic fixture triggers AI-GH-021 but NOT SEC4-GH-002, because
    the workflow uses ``persist-credentials: false`` + default token).
  * Every fixture must cite its upstream source in the file header
    (repo slug + license) so attribution is preserved.

See ``runner.py`` for the scanner harness and
``tests/integration/test_real_world_regression.py`` for the CI gate.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Fixture:
    path: str  # relative to benchmark/real_world/fixtures/
    platform: str  # "github" | "gitlab" | "jenkins"
    description: str
    expected_rule_ids: frozenset[str] = field(default_factory=frozenset)
    forbidden_rule_ids: frozenset[str] = field(default_factory=frozenset)


FIXTURES: tuple[Fixture, ...] = (
    # --- AI ecosystem ------------------------------------------------------
    Fixture(
        path="ai-ecosystem/pydantic-ai-bots.yml",
        platform="github",
        description=(
            "pydantic/pydantic-ai bots.yml — AI agent workflow with "
            "PR head-SHA checkout AND post-trigger `gh pr view` "
            "(settings-poisoning + TOCTOU primitives)."
        ),
        expected_rule_ids=frozenset({
            "AI-GH-021",   # agent + PR-head checkout
            "AI-GH-019",   # gh pr view fresh re-read + agent
        }),
        forbidden_rule_ids=frozenset({
            # The workflow has claude_args with --allowed-tools, so
            # AI-GH-020 MUST NOT fire — that'd be an FP.
            "AI-GH-020",
        }),
    ),
    Fixture(
        path="ai-ecosystem/humanlayer-claude-review.yml",
        platform="github",
        description=(
            "humanlayer/humanlayer claude-code-review.yml — agent on "
            "pull_request without allowed_tools allowlist (Aonan Guan "
            "'Comment and Control' class)."
        ),
        expected_rule_ids=frozenset({
            "AI-GH-020",   # fork-reachable + agent + no allowlist
        }),
        forbidden_rule_ids=frozenset({
            # No head-SHA checkout in this fixture — AI-GH-021 must not fire.
            "AI-GH-021",
        }),
    ),
    # --- GitLab ------------------------------------------------------------
    Fixture(
        path="gitlab/cbbrowne-pgcmp.gitlab-ci.yml",
        platform="gitlab",
        description=(
            "cbbrowne/pgcmp .gitlab-ci.yml — hardcoded "
            "POSTGRES_PASSWORD in variables:."
        ),
        expected_rule_ids=frozenset({
            "SEC2-GL-003",
        }),
    ),
    Fixture(
        path="gitlab/aphp-confit-release.gitlab-ci.yml",
        platform="gitlab",
        description=(
            "aphp/confit release stage — pip install "
            "--extra-index-url without --index-url "
            "(dep-confusion class)."
        ),
        expected_rule_ids=frozenset({
            "SEC3-GL-004",
        }),
    ),
    # --- Jenkins -----------------------------------------------------------
    Fixture(
        path="jenkins/roryeckel-codex-Jenkinsfile",
        platform="jenkins",
        description=(
            "roryeckel/codex-jenkinsfile — params.X interpolated into "
            "double-quoted sh \"...\" steps (Groovy-substitution RCE)."
        ),
        expected_rule_ids=frozenset({
            "TAINT-JK-001",
        }),
    ),
    Fixture(
        path="jenkins/snowflakedb-coverage-Jenkinsfile",
        platform="jenkins",
        description=(
            "snowflakedb/universal-driver ci/Jenkinsfile.coverage — "
            "pip --extra-index-url + .inside('--privileged'). Also "
            "validates nested-Jenkinsfile discovery (PR #86)."
        ),
        expected_rule_ids=frozenset({
            "SEC3-JK-004",
            "SEC8-JK-004",
        }),
    ),
    Fixture(
        path="jenkins/fjudith-wordpress-Jenkinsfile",
        platform="jenkins",
        description=(
            "fjudith/docker-wordpress Jenkinsfile — `docker run -e "
            "MYSQL_PASSWORD=wordpress` literal credential."
        ),
        expected_rule_ids=frozenset({
            "SEC2-JK-003",
        }),
    ),
)
