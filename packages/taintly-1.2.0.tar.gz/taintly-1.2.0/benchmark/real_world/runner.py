"""Scan each real-world fixture and diff against the ground truth in
``labels.py``.

Usage:
    python -m benchmark.real_world                      # run + exit 0/1
    python -m benchmark.real_world --verbose            # per-fixture detail
    python -m benchmark.real_world --fixture <path>     # run one

The pytest gate in ``tests/integration/test_real_world_regression.py``
calls ``run_regression()`` directly and asserts no drift.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path

# Support ``python -m benchmark.real_world`` from a checkout without install.
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from taintly.engine import scan_file  # noqa: E402
from taintly.models import Platform  # noqa: E402
from taintly.rules.registry import load_rules_for_platform  # noqa: E402

from .labels import FIXTURES, Fixture  # noqa: E402

FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures"


@dataclass
class FixtureResult:
    fixture: Fixture
    actual_rule_ids: frozenset[str]
    missing_expected: frozenset[str]
    firing_forbidden: frozenset[str]

    @property
    def passed(self) -> bool:
        return not self.missing_expected and not self.firing_forbidden


def _platform_enum(name: str) -> Platform:
    return {
        "github": Platform.GITHUB,
        "gitlab": Platform.GITLAB,
        "jenkins": Platform.JENKINS,
    }[name]


def _run_fixture(fx: Fixture) -> FixtureResult:
    path = FIXTURES_DIR / fx.path
    if not path.is_file():
        raise FileNotFoundError(
            f"Fixture missing: {path} (declared in labels.py). "
            "Ground truth and fixture files must stay in sync."
        )
    platform = _platform_enum(fx.platform)
    rules = load_rules_for_platform(platform)
    findings = scan_file(str(path), rules=rules)
    actual = frozenset(f.rule_id for f in findings if f.rule_id != "ENGINE-ERR")
    missing = fx.expected_rule_ids - actual
    firing_forbidden = fx.forbidden_rule_ids & actual
    return FixtureResult(
        fixture=fx,
        actual_rule_ids=actual,
        missing_expected=missing,
        firing_forbidden=firing_forbidden,
    )


def run_regression(
    fixtures: tuple[Fixture, ...] = FIXTURES,
) -> tuple[bool, list[FixtureResult]]:
    """Run every fixture and return (all_passed, per-fixture results)."""
    results = [_run_fixture(fx) for fx in fixtures]
    return all(r.passed for r in results), results


def _format_result(r: FixtureResult, verbose: bool) -> str:
    status = "PASS" if r.passed else "FAIL"
    lines = [f"  [{status}] {r.fixture.path}"]
    if not r.passed:
        if r.missing_expected:
            lines.append(
                "    expected but did not fire: "
                + ", ".join(sorted(r.missing_expected))
            )
        if r.firing_forbidden:
            lines.append(
                "    fired but was forbidden: "
                + ", ".join(sorted(r.firing_forbidden))
            )
        lines.append(
            "    actual rule hits: "
            + (", ".join(sorted(r.actual_rule_ids)) if r.actual_rule_ids else "(none)")
        )
    elif verbose:
        lines.append(
            "    hits: "
            + (", ".join(sorted(r.actual_rule_ids)) if r.actual_rule_ids else "(none)")
        )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n", 1)[0])
    parser.add_argument("--verbose", action="store_true", help="Show per-fixture hits even on pass.")
    parser.add_argument("--fixture", help="Run one fixture by relative path.")
    args = parser.parse_args()

    fixtures: tuple[Fixture, ...] = FIXTURES
    if args.fixture:
        fixtures = tuple(f for f in FIXTURES if f.path == args.fixture)
        if not fixtures:
            sys.stderr.write(
                f"No fixture matches: {args.fixture!r}\n"
                f"Known: {[f.path for f in FIXTURES]}\n"
            )
            return 2

    all_passed, results = run_regression(fixtures)

    print("Real-world regression corpus")
    print("-" * 70)
    for r in results:
        print(_format_result(r, verbose=args.verbose))
    print("-" * 70)
    n_pass = sum(1 for r in results if r.passed)
    print(f"{n_pass}/{len(results)} fixtures passed.")
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
