"""Real-world regression corpus.

Minimal fixtures derived from public workflows that exhibit detected
attack shapes.  Unlike ``benchmark/corpus/`` (which asserts family-level
clusters + score ranges), this corpus asserts at the rule-ID level —
catching a regression when a specific rule stops firing on a known-
vulnerable shape, or starts firing where it shouldn't.

See ``labels.py`` for the ground truth and ``runner.py`` for the
scanner harness.  ``tests/integration/test_real_world_regression.py``
gates CI on no-drift.
"""
