"""Benchmark runner — scans collected workflows and produces per-category metrics.

Runs taintly against the collected dataset, maps findings to the paper's
10-weakness taxonomy, and outputs:
  - Per-category detection counts (comparable to Table V in the paper)
  - Per-workflow finding breakdown
  - Summary comparison against paper's reported numbers for other scanners

Usage:
  python -m benchmark run --dataset benchmark/dataset/
  python -m benchmark run --dataset benchmark/dataset/ --format json
  python -m benchmark run --dataset benchmark/dataset/ --min-stars 5000

Requires: taintly to be importable (run from repo root).
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from taintly.engine import scan_file
from taintly.models import Platform
from taintly.rules.registry import load_all_rules

from .taxonomy import RULE_TO_WEAKNESS, TAXONOMY

# ============================================================================
# Paper's Table V — v2 (arXiv:2601.14455v2, March 2026)
# Dataset: 2,722 workflows / 388 repos
# Format: {scanner: {weakness_code: total_detections}}
#
# Source: Table V in the paper HTML (fetched April 2026).
# Each cell was "detections/workflows_with_findings" — we store detections.
#
# NOTE: v2 renamed TMW → PTW. The PTW column covers pull_request_target misuse.
# NOTE: zizmor's UDW column appears as — in the fetched table, which conflicts
#       with v1 data (zizmor had UDW:1571 in v1). Verify against the PDF directly:
#       https://arxiv.org/pdf/2601.14455 — Table V, page 7-8.
# ============================================================================

PAPER_RESULTS_V2: dict[str, dict[str, int]] = {
    # scanner: {category_code: total_detections across 2,722 workflows}
    "actionlint": {
        "AIW": 79, "CFW": 24, "EPW": 2094, "GRCW": 31, "HGW": 0,
    },
    "frizbee": {
        "UDW": 8020,
    },
    "ggshield": {
        "SEW": 5,
    },
    "pinny": {
        "UDW": 9811,
    },
    "poutine": {
        "AIW": 125, "CFW": 6, "EPW": 47, "GRCW": 107, "HGW": 121,
        "IW": 201, "KVCW": 0, "PTW": 0, "SEW": 0, "UDW": 2003,
    },
    "scharf": {
        "UDW": 10202,
    },
    "scorecard": {
        "AIW": 2349, "CFW": 2638, "EPW": 5, "GRCW": 16, "HGW": 11347,
    },
    "semgrep": {
        "AIW": 255, "CFW": 15, "IW": 1778, "KVCW": 0, "PTW": 196, "SEW": 89,
    },
    "zizmor": {
        "AIW": 3620, "CFW": 0, "EPW": 2296, "GRCW": 0, "HGW": 8, "IW": 2003,
        # NOTE: UDW appears as — in fetched table; may be a data gap. Verify vs PDF.
    },
}

# v1 numbers retained for reference (596 workflows / 77 repos)
PAPER_RESULTS_V1: dict[str, dict[str, int]] = {
    "actionlint": {"CFW": 24, "EPW": 0, "IW": 0, "SEW": 0, "UDW": 1580},
    "frizbee": {"UDW": 2261},
    "ggshield": {"SEW": 18},
    "pinny": {"UDW": 2282},
    "poutine": {"AIW": 17, "EPW": 43, "IW": 5, "SEW": 8, "PTW": 11, "UDW": 1283},
    "scharf": {"IW": 3},
    "scorecard": {"EPW": 238, "HGW": 218, "SEW": 70, "PTW": 16, "UDW": 1279},
    "semgrep": {"AIW": 3, "IW": 11},
    "zizmor": {"AIW": 16, "CFW": 4, "EPW": 240, "HGW": 221, "IW": 0, "KVCW": 6, "SEW": 119, "PTW": 24, "UDW": 1571},
}


# ============================================================================
# Result models
# ============================================================================


@dataclass
class WorkflowResult:
    """Scan results for a single workflow."""

    file: str
    repo: str
    lines: int
    scan_time_ms: float
    finding_count: int
    findings_by_severity: dict[str, int] = field(default_factory=dict)
    findings_by_category: dict[str, int] = field(default_factory=dict)
    rule_ids_fired: list[str] = field(default_factory=list)


@dataclass
class CategoryResult:
    """Aggregated results for one weakness category."""

    code: str
    name: str
    rules_available: int
    workflows_with_findings: int
    total_findings: int
    finding_details: dict[str, int] = field(default_factory=dict)  # rule_id -> count


@dataclass
class BenchmarkReport:
    """Full benchmark report."""

    dataset_path: str
    workflows_scanned: int
    total_findings: int
    scan_time_total_s: float
    median_scan_time_ms: float
    categories: list[CategoryResult] = field(default_factory=list)
    per_workflow: list[WorkflowResult] = field(default_factory=list)


# ============================================================================
# Runner
# ============================================================================


_PLATFORM_MAP: dict[str, Platform] = {
    "github": Platform.GITHUB,
    "gitlab": Platform.GITLAB,
    "jenkins": Platform.JENKINS,
}

# Index key for star/popularity count varies by platform
_STARS_KEY: dict[str, str] = {
    "github": "repo_stars",
    "gitlab": "project_stars",
    "jenkins": "repo_stars",
}


def run_benchmark(
    dataset_dir: str,
    min_stars: int = 0,
    max_workflows: int = 0,
    platform: str = "github",
) -> BenchmarkReport:
    """Run taintly against all files in the dataset."""
    dataset = Path(dataset_dir)
    index_path = dataset / "index.json"

    if not index_path.exists():
        print(f"Error: {index_path} not found. Run collector first.", file=sys.stderr)
        sys.exit(1)

    with open(index_path, encoding="utf-8") as f:
        index = json.load(f)

    stars_key = _STARS_KEY.get(platform, "repo_stars")
    if min_stars > 0:
        index = [w for w in index if w.get(stars_key, 0) >= min_stars]
    if max_workflows > 0:
        index = index[:max_workflows]

    all_rules = load_all_rules()
    active_platform = _PLATFORM_MAP.get(platform, Platform.GITHUB)
    platform_rules = [r for r in all_rules if r.platform == active_platform]

    print(
        f"Benchmarking {len(index)} files with {len(platform_rules)} "
        f"{platform} rules...",
        file=sys.stderr,
    )

    cat_findings: dict[str, dict[str, int]] = {t.code: {} for t in TAXONOMY}
    cat_workflow_counts: dict[str, set[int]] = {t.code: set() for t in TAXONOMY}

    workflow_results: list[WorkflowResult] = []
    scan_times: list[float] = []
    total_findings = 0

    for i, entry in enumerate(index):
        filepath = dataset / entry["file"]
        if not filepath.exists():
            continue

        content = filepath.read_text(encoding="utf-8", errors="replace")

        t0 = time.perf_counter()
        findings = scan_file(str(filepath), platform_rules, _content=content)
        t1 = time.perf_counter()
        scan_ms = (t1 - t0) * 1000
        scan_times.append(scan_ms)

        findings = [f for f in findings if f.rule_id != "ENGINE-ERR"]
        total_findings += len(findings)

        by_severity: dict[str, int] = {}
        by_category: dict[str, int] = {}
        rule_ids = []

        for f in findings:
            sev = f.severity.value
            by_severity[sev] = by_severity.get(sev, 0) + 1

            categories = RULE_TO_WEAKNESS.get(f.rule_id, [])
            for cat_code in categories:
                by_category[cat_code] = by_category.get(cat_code, 0) + 1
                cat_findings[cat_code][f.rule_id] = cat_findings[cat_code].get(f.rule_id, 0) + 1
                cat_workflow_counts[cat_code].add(i)

            if f.rule_id not in rule_ids:
                rule_ids.append(f.rule_id)

        workflow_results.append(WorkflowResult(
            file=entry["file"],
            repo=entry.get("repo", ""),
            lines=entry.get("lines", 0),
            scan_time_ms=round(scan_ms, 2),
            finding_count=len(findings),
            findings_by_severity=by_severity,
            findings_by_category=by_category,
            rule_ids_fired=rule_ids,
        ))

        if (i + 1) % 100 == 0:
            print(f"  {i + 1}/{len(index)} scanned...", file=sys.stderr)

    category_results = []
    for t in TAXONOMY:
        cr = CategoryResult(
            code=t.code,
            name=t.name,
            rules_available=len(t.taintly_rules),
            workflows_with_findings=len(cat_workflow_counts[t.code]),
            total_findings=sum(cat_findings[t.code].values()),
            finding_details=cat_findings[t.code],
        )
        category_results.append(cr)

    sorted_times = sorted(scan_times)
    median_ms = sorted_times[len(sorted_times) // 2] if sorted_times else 0.0

    return BenchmarkReport(
        dataset_path=dataset_dir,
        workflows_scanned=len(workflow_results),
        total_findings=total_findings,
        scan_time_total_s=round(sum(scan_times) / 1000, 2),
        median_scan_time_ms=round(median_ms, 2),
        categories=category_results,
        per_workflow=workflow_results,
    )


# ============================================================================
# Output formatters
# ============================================================================


def format_text(report: BenchmarkReport, paper_version: str = "v2") -> str:
    paper_data = PAPER_RESULTS_V2 if paper_version == "v2" else PAPER_RESULTS_V1
    dataset_desc = "2,722 workflows/388 repos" if paper_version == "v2" else "596 workflows/77 repos"

    out = []
    out.append("=" * 75)
    out.append("CICD-AUDIT BENCHMARK REPORT")
    out.append(f"  (methodology: Fares et al. arXiv:2601.14455v2)")
    out.append("=" * 75)
    out.append(f"Workflows scanned:   {report.workflows_scanned}")
    out.append(f"Total findings:      {report.total_findings}")
    out.append(f"Total scan time:     {report.scan_time_total_s}s")
    out.append(f"Median per-workflow: {report.median_scan_time_ms}ms")
    out.append("")

    out.append("Per-Category Detection")
    out.append("-" * 75)
    out.append(f"{'Cat':<6} {'Name':<35} {'Rules':>5} {'Findings':>8} {'Workflows':>9}")
    out.append("-" * 75)
    for cr in report.categories:
        out.append(
            f"{cr.code:<6} {cr.name:<35} {cr.rules_available:>5} "
            f"{cr.total_findings:>8} {cr.workflows_with_findings:>9}"
        )
    covered = sum(1 for cr in report.categories if cr.rules_available > 0)
    out.append(f"\nCategory coverage: {covered}/{len(report.categories)}")
    out.append("")

    out.append(f"Comparison: paper's Table V {paper_version} ({dataset_desc})")
    out.append("NOTE: numbers only comparable when run on the same collected dataset.")
    out.append("-" * 75)
    scanners = ["zizmor", "poutine", "scorecard", "semgrep", "taintly"]
    header = f"{'Cat':<6}"
    for s in scanners:
        header += f" {s:>12}"
    out.append(header)
    out.append("-" * 75)
    for cr in report.categories:
        line = f"{cr.code:<6}"
        for s in scanners:
            if s == "taintly":
                val = str(cr.total_findings)
            else:
                val = str(paper_data.get(s, {}).get(cr.code, "—"))
            line += f" {val:>12}"
        out.append(line)
    out.append("-" * 75)

    # Top findings by rule
    rule_counts: dict[str, int] = {}
    for cr in report.categories:
        for rule_id, count in cr.finding_details.items():
            rule_counts[rule_id] = rule_counts.get(rule_id, 0) + count

    if rule_counts:
        out.append("\nTop 15 rules by finding count")
        out.append("-" * 55)
        sorted_rules = sorted(rule_counts.items(), key=lambda x: -x[1])[:15]
        for rule_id, count in sorted_rules:
            cats = RULE_TO_WEAKNESS.get(rule_id, ["?"])
            out.append(f"  {rule_id:<22} {count:>6}  ({', '.join(cats)})")

    return "\n".join(out)


def format_json(report: BenchmarkReport) -> str:
    d = {
        "dataset_path": report.dataset_path,
        "workflows_scanned": report.workflows_scanned,
        "total_findings": report.total_findings,
        "scan_time_total_s": report.scan_time_total_s,
        "median_scan_time_ms": report.median_scan_time_ms,
        "categories": [asdict(cr) for cr in report.categories],
        "per_workflow_summary": {
            "with_findings": sum(1 for w in report.per_workflow if w.finding_count > 0),
            "without_findings": sum(1 for w in report.per_workflow if w.finding_count == 0),
            "max_findings": max((w.finding_count for w in report.per_workflow), default=0),
        },
        "per_workflow": [asdict(w) for w in report.per_workflow],
    }
    return json.dumps(d, indent=2)


# ============================================================================
# CLI
# ============================================================================


def main():
    parser = argparse.ArgumentParser(
        prog="benchmark-runner",
        description="Run taintly against collected benchmark dataset.",
    )
    parser.add_argument("--dataset", "-d", default="benchmark/dataset")
    parser.add_argument("--format", "-f", choices=["text", "json"], default="text")
    parser.add_argument("--min-stars", type=int, default=0)
    parser.add_argument("--max-workflows", type=int, default=0)
    parser.add_argument(
        "--platform", "-p",
        choices=["github", "gitlab", "jenkins"],
        default="github",
        help="Platform to benchmark (default: github)",
    )
    parser.add_argument("--paper-version", choices=["v1", "v2"], default="v2",
                        help="Paper version to compare against (default: v2)")
    parser.add_argument("--output", "-o", help="Write report to file instead of stdout")
    args = parser.parse_args()

    report = run_benchmark(args.dataset, args.min_stars, args.max_workflows, args.platform)

    output = format_text(report, args.paper_version) if args.format == "text" else format_json(report)

    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
        print(f"Report written to {args.output}", file=sys.stderr)
    else:
        print(output)


if __name__ == "__main__":
    main()
