"""Benchmark suite for taintly.

Reproduces and extends the methodology from:
  Fares, Gamage, Baudry. "Unpacking Security Scanners for GitHub Actions Workflows."
  arXiv:2601.14455v2, March 2026. Université de Montréal.

Modules:
  collector  — Fetches real-world workflows from GitHub orgs
  taxonomy   — Maps taintly rules to the paper's 10-weakness classification
  runner     — Scans collected workflows and produces per-category metrics
  labeler    — Ground truth labeling for precision/recall evaluation
  fixtures   — Synthetic benchmark fixtures with known ground truth
"""
