# Labeled precision corpus

A small, hand-labeled set of workflow files used to validate that
taintly's reporting produces the *shape* of output the improvement
report called for — distinct risks, review-needed routing, confidence
weighting, and exploitability tiers — on scenarios whose correct
behavior we know by construction.

This is deliberately smaller and simpler than `benchmark/dataset/`
(which targets the academic-paper comparison against other scanners).
The corpus here is a **precision regression suite**: each file is
annotated with expected cluster count, expected worst exploitability,
and specific rules that must / must not fire.

Run the check:

    python -m benchmark corpus

Exits non-zero if any scenario's actual output drifts from its label.

Adding a new scenario:

1. Drop a `*.yml` workflow file into this directory.
2. Add an entry to `labels.py` describing what you expect.
3. Run `python -m benchmark corpus` to confirm.

The corpus is meant to stay small (~10 files max).  The point is
precision anchoring, not coverage breadth — that's `benchmark/dataset/`.
