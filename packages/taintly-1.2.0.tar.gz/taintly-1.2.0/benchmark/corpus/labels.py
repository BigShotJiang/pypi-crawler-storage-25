"""Ground-truth labels for the precision corpus.

Each entry describes what we expect taintly to produce for the
corresponding workflow file.  The runner in ``benchmark/corpus_runner.py``
compares actual output against these labels and reports any drift.

Expectation fields:
    description          — one-line prose describing the scenario
    min_score / max_score — score must fall within [min, max]
    expected_grade       — optional exact grade letter (A/B/C/D/F)
    expected_families    — set of family IDs that MUST appear in the
                           distinct-risks list (confirmed, not
                           review-needed)
    forbidden_families   — set of family IDs that MUST NOT appear
    review_needed_families — family IDs that must appear only in the
                             review-needed bucket, never as confirmed
    expected_top_exploitability — worst exploitability across any
                                  confirmed cluster (validates context)
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class CorpusLabel:
    file: str
    description: str
    min_score: int = 0
    max_score: int = 100
    expected_grade: str | None = None
    expected_families: frozenset[str] = field(default_factory=frozenset)
    forbidden_families: frozenset[str] = field(default_factory=frozenset)
    review_needed_families: frozenset[str] = field(default_factory=frozenset)
    expected_top_exploitability: str | None = None


CORPUS: tuple[CorpusLabel, ...] = (
    CorpusLabel(
        file="mature_hardened.yml",
        description="Fully hardened CI: SHA-pinned actions, minimal permissions, "
                    "timeout, persist-credentials=false",
        min_score=95, max_score=100,
        expected_grade="A",
        forbidden_families=frozenset({
            "supply_chain_immutability",
            "privileged_pr_trigger",
            "credential_persistence",
        }),
    ),
    CorpusLabel(
        file="typical_oss.yml",
        description="Typical OSS: tag-pinned actions, minimal permissions, "
                    "no privileged trigger. Hygiene debt only.",
        min_score=65, max_score=100,  # Must NOT be F
        expected_families=frozenset({"supply_chain_immutability"}),
        forbidden_families=frozenset({"privileged_pr_trigger", "script_injection"}),
        # In no-secrets, no-privileged context: pinning is 'medium' at worst
        expected_top_exploitability="medium",
    ),
    CorpusLabel(
        file="intentional_pr_target.yml",
        description="pull_request_target with permissions:{} and no checkout. "
                    "Must route to REVIEW-NEEDED, keep score at 100.",
        min_score=100, max_score=100,
        expected_grade="A",
        review_needed_families=frozenset({"privileged_pr_trigger"}),
    ),
    CorpusLabel(
        file="release_unpinned.yml",
        description="Release workflow with write perms and unpinned action — "
                    "real supply-chain surface at high exploitability.",
        min_score=0, max_score=95,
        expected_families=frozenset({"supply_chain_immutability"}),
        expected_top_exploitability="high",
    ),
    CorpusLabel(
        file="classic_ppe.yml",
        description="Classic PPE: pull_request_target + PR checkout + build tool + "
                    "secrets. Worst-case scenario, grade D or F.",
        # NB: the v2 cluster-based scorer intentionally doesn't tank
        # every bad repo to F — the improvement report criticized the
        # old scorer for over-reliance on F grades. Both D and F are
        # acceptable here; the important signal is the cluster list.
        min_score=0, max_score=65,
        expected_families=frozenset({"privileged_pr_trigger", "script_injection"}),
        expected_top_exploitability="high",
    ),
)
