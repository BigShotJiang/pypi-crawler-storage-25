"""Weakness taxonomy from Fares et al. arXiv:2601.14455v2.

Maps the paper's 10 weakness categories to taintly rule IDs.
This mapping enables direct comparison of taintly's detection rates
against the 9 scanners benchmarked in the paper.

NOTE: v2 of the paper (March 2026, 2,722 workflows) renamed TMW (Trigger Misuse
Weakness) to PTW (Privileged Trigger Weakness). This module uses the v2 codes.

Taxonomy:
  AIW  — Action Injection Weakness (CWE-78, CWE-94)
  CFW  — Control Flow Weakness (CWE-691)
  EPW  — Excessive Permissions Weakness (CWE-250, CWE-732)
  GRCW — GitHub Runner Compatibility Weakness (runner-specific)
  HGW  — Hardening Gap Weakness (CWE-1188)
  IW   — Injection Weakness (CWE-78, CWE-94, CWE-116)
  KVCW — Key-Value Cache Weakness (CWE-345)
  PTW  — Privileged Trigger Weakness (CWE-284) [was TMW in v1]
  SEW  — Secret Exposure Weakness (CWE-798, CWE-200, CWE-312)
  UDW  — Unpinned Dependency Weakness (CWE-829)
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class WeaknessCategory:
    """A weakness category from the paper's taxonomy."""

    code: str  # e.g. "AIW"
    name: str
    description: str
    cwes: list[str]
    taintly_rules: list[str]  # Rule IDs that detect this weakness
    owasp_cicd: list[str]  # Corresponding OWASP CI/CD Top 10 categories
    notes: str = ""


TAXONOMY: list[WeaknessCategory] = [
    WeaknessCategory(
        code="AIW",
        name="Action Injection Weakness",
        description=(
            "Untrusted input from GitHub context expressions (${{ }}) is used "
            "in a way that allows code injection via crafted PR titles, issue "
            "bodies, branch names, or commit messages."
        ),
        cwes=["CWE-78", "CWE-94"],
        taintly_rules=[
            "SEC4-GH-004",  # Script injection via attacker-controlled context
            "SEC4-GH-006",  # Attacker-controlled value written to GITHUB_ENV
            "SEC4-GH-007",  # Attacker-controlled value written to GITHUB_OUTPUT
            "SEC4-GH-008",  # workflow_dispatch inputs used in run: block
            "SEC4-GH-014",  # github.event.* attacker-controlled context in run:
            "SEC4-GH-015",  # Attacker-controlled context in shell with no sanitisation
            "SEC4-GH-016",  # Attacker-controlled context used in arg to reusable workflow
            "TAINT-GH-001", # Shallow taint: context → env → run
            "TAINT-GH-002", # Deep taint: multi-hop env propagation
            "TAINT-GH-003", # Deep taint: $GITHUB_ENV → later run:
            "TAINT-GH-004", # Deep taint: $GITHUB_OUTPUT → downstream expression
            "TAINT-GH-005", # Deep taint: AI-agent step output → downstream run:
            "TAINT-GH-006", # Cross-workflow: reusable-workflow inputs.* reference
            "TAINT-GH-007", # Cross-workflow: caller-side tainted with: to reusable
            "TAINT-GH-008", # Cross-workflow: workflow_run inherits upstream attacker context
            "TAINT-GH-009", # Cross-job: needs.<j>.outputs.<n> taint into downstream run:
            "TAINT-GH-010", # workflow_run consumer without head-SHA pin
            "TAINT-GH-011", # Multi-trigger idempotency hole on state mutator
        ],
        owasp_cicd=["CICD-SEC-4"],
    ),
    WeaknessCategory(
        code="CFW",
        name="Control Flow Weakness",
        description=(
            "Workflow control flow allows unintended execution paths, such as "
            "workflow_run without conclusion checks, if-always-true conditions, "
            "or missing environment approval gates."
        ),
        cwes=["CWE-691"],
        taintly_rules=[
            "SEC4-GH-003",  # workflow_run without conclusion check
            "SEC4-GH-013",  # if: always() evaluates to true
            "SEC1-GH-001",  # Deploy job missing environment approval gate
            "SEC1-GL-001",  # GitLab production deploy without manual approval
            "SEC1-GL-002",  # Security gate configured with allow_failure
            "SEC4-GL-004",  # CI_PIPELINE_SOURCE used as sole access control gate
            "SEC4-GL-005",  # MR pipeline runs deploy/publish command
            "SEC5-GL-001",  # Deployment job lacks resource_group protection
            "SEC1-JK-001",  # Production deployment stage has no manual approval
            "SEC4-JK-004",  # Jenkins input step without submitter restriction
            "SEC5-JK-001",  # Pipeline with deploy stage lacks disableConcurrentBuilds
        ],
        owasp_cicd=["CICD-SEC-1", "CICD-SEC-4", "CICD-SEC-5"],
    ),
    WeaknessCategory(
        code="EPW",
        name="Excessive Permissions Weakness",
        description=(
            "Workflow or job-level permissions grant more access than needed, "
            "including write-all, missing permissions block (defaults to read-write), "
            "or id-token:write without OIDC usage."
        ),
        cwes=["CWE-250", "CWE-732"],
        taintly_rules=[
            "SEC2-GH-001",  # Workflow grants write-all permissions
            "SEC2-GH-002",  # No explicit permissions defined
            "SEC5-GH-001",  # id-token:write without OIDC action
            "SEC6-GL-005",  # chmod 777 in GitLab script block
            "SEC9-GL-001",  # Artifacts block without access restriction
            "SEC10-GL-002", # Public pipelines may expose job logs
        ],
        owasp_cicd=["CICD-SEC-2", "CICD-SEC-5"],
    ),
    WeaknessCategory(
        code="GRCW",
        name="GitHub Runner Compatibility Weakness",
        description=(
            "Runner configuration weaknesses including using self-hosted runners "
            "for untrusted workloads, debug mode enabled, or insecure runner settings."
        ),
        cwes=[],
        taintly_rules=[
            "SEC7-GH-001",  # Self-hosted runner detected (informational)
            "SEC7-GH-002",  # Debug mode enabled
            "SEC7-GH-003",  # Self-hosted runner for pull_request
            "SEC7-JK-001",  # Jenkins pipeline uses unconstrained 'agent any'
            "SEC7-JK-002",  # Scripted pipeline node block without agent label
        ],
        owasp_cicd=["CICD-SEC-7"],
        notes="taintly has partial coverage — no runner version/OS compatibility checks.",
    ),
    WeaknessCategory(
        code="HGW",
        name="Hardening Gap Weakness",
        description=(
            "Missing security hardening measures such as persist-credentials: false "
            "on checkout, ACTIONS_ALLOW_UNSECURE_COMMANDS enabled, or insecure "
            "system configuration."
        ),
        cwes=["CWE-1188"],
        taintly_rules=[
            "SEC4-GH-005",  # Checkout persists credentials to disk
            "SEC4-GH-009",  # ACTIONS_ALLOW_UNSECURE_COMMANDS enabled
            "SEC4-GH-010",  # Bot actor check is spoofable
            "SEC10-GH-003", # Actions debug logging enabled — mask bypass
            "SEC2-GL-002",  # Docker-in-Docker service without TLS
            "SEC7-GL-001",  # GitLab CI debug trace enabled
            "SEC1-JK-002",  # Declarative pipeline has no timeout
            "SEC6-JK-004",  # TLS certificate verification disabled
            "SEC8-JK-003",  # Git checkout from non-HTTPS URL (MITM risk)
            "SEC9-JK-002",  # archiveArtifacts without fingerprint: true
            "SEC10-JK-001", # No post { always { } } block
        ],
        owasp_cicd=["CICD-SEC-4", "CICD-SEC-7"],
        notes="taintly covers the main hardening gaps but not all.",
    ),
    WeaknessCategory(
        code="IW",
        name="Injection Weakness",
        description=(
            "Broader injection category covering script injection patterns beyond "
            "direct action injection — includes LOTP tools in PRT context, "
            "curl|bash, base64 decode|shell, and shell variable injection."
        ),
        cwes=["CWE-78", "CWE-94", "CWE-116"],
        taintly_rules=[
            "SEC4-GH-011",  # LOTP tools in pull_request_target
            "SEC6-GH-006",  # Base64-encoded payload executed
            "SEC6-GH-007",  # curl|bash without integrity check
            "SEC4-GL-001",  # GitLab user-controlled variable in shell
            "SEC4-GL-003",  # User-controlled ref/tag used unquoted in shell
            "SEC6-GL-004",  # eval usage in GitLab script block
            "SEC6-GL-006",  # wget/bash or bash-subshell-curl in script block
            "SEC4-JK-001",  # User-controlled build parameter in shell
            "SEC4-JK-002",  # SCM-controlled env variable in shell
            "SEC4-JK-003",  # Dynamic Groovy code evaluation
            "SEC4-JK-005",  # PR author/URL env variable in shell
            "SEC6-JK-007",  # Windows bat step uses Groovy string interpolation
            "SEC9-JK-001",  # Downloads and executes content without integrity check
            "TAINT-GL-001", # Shallow taint: CI variable → variables: → script
            "TAINT-GL-002", # Deep taint: multi-hop variables: propagation
            "TAINT-GL-003", # Deep taint: reports.dotenv → downstream script
            "TAINT-GL-004", # Cross-component: CI Component inputs.* reference
            "TAINT-JK-001", # Shallow taint: env.CHANGE_*/params/ghprb/GERRIT → sh "..."
            "TAINT-JK-002", # Cross-job: downstream build with tainted parameter
            "LOTP-GH-001",  # Build tool in PR-checkout job (LOTP)
            "LOTP-GH-003",  # npm install without --ignore-scripts in PR workflow
            "LOTP-GH-004",  # Build tool after actions/download-artifact
            "LOTP-GH-005",  # npm/yarn/pnpm install + exfil-worthy secret (Shai-Hulud)
            "LOTP-GL-001",  # Build tool in GitLab MR pipeline (LOTP)
            "LOTP-GL-003",  # npm install without --ignore-scripts in MR pipeline (port of LOTP-GH-003)
            "LOTP-GL-005",  # npm/yarn/pnpm install + exfil-worthy secret (Shai-Hulud GL port)
            "LOTP-JK-001",  # Build tool + PR-context env in Jenkinsfile (LOTP)
            "LOTP-JK-003",  # npm install without --ignore-scripts in PR-reachable Jenkinsfile (port of LOTP-GH-003)
            "LOTP-JK-005",  # npm/yarn/pnpm install + npm-publish token in Jenkinsfile (Shai-Hulud JK port)
        ],
        owasp_cicd=["CICD-SEC-4", "CICD-SEC-6"],
    ),
    WeaknessCategory(
        code="KVCW",
        name="Key-Value Cache Weakness",
        description=(
            "Cache poisoning risks from mutable caches used in release/tag "
            "workflows where a PR-poisoned cache could affect production builds."
        ),
        cwes=["CWE-345"],
        taintly_rules=[
            "SEC9-GH-002",  # Mutable cache in release/tag workflow
            "SEC9-GH-005",  # Cache key derived from attacker-controlled context
            "SEC9-GL-003",  # Cache block without explicit key (cross-branch poisoning)
        ],
        owasp_cicd=["CICD-SEC-9"],
    ),
    WeaknessCategory(
        code="PTW",
        name="Privileged Trigger Weakness",
        description=(
            "Dangerous trigger configurations that execute with elevated privileges "
            "on untrusted code — primarily pull_request_target with checkout of PR "
            "head, giving attacker-controlled code access to repo secrets and write "
            "permissions. Called TMW (Trigger Misuse Weakness) in paper v1."
        ),
        cwes=["CWE-284"],
        taintly_rules=[
            "SEC4-GH-001",  # PRT with untrusted PR checkout
            "SEC4-GH-002",  # PRT trigger detected (informational)
            "SEC4-GL-002",  # Trigger job passes CI_JOB_TOKEN downstream
        ],
        owasp_cicd=["CICD-SEC-4"],
        notes="Renamed from TMW in paper v1 to PTW in paper v2 (arXiv:2601.14455v2).",
    ),
    WeaknessCategory(
        code="SEW",
        name="Secret Exposure Weakness",
        description=(
            "Secrets exposed through hardcoding, toJSON(secrets), inline "
            "interpolation in shell commands, long-lived cloud credentials, "
            "or secrets:inherit forwarding."
        ),
        cwes=["CWE-798", "CWE-200", "CWE-312"],
        taintly_rules=[
            "SEC6-GH-001",  # Hardcoded secret in workflow
            "SEC6-GH-003",  # Long-lived cloud creds instead of OIDC
            "SEC6-GH-004",  # toJSON(secrets) dumps all secrets
            "SEC6-GH-005",  # Secret interpolated directly in shell
            "SEC4-GH-012",  # secrets:inherit forwarding
            "SEC2-GH-004",  # Hardcoded creds in container block
            "SEC6-GL-001",  # GitLab hardcoded secret
            "SEC6-GL-002",  # curl piped to shell in script block
            "SEC6-GL-003",  # TLS verification disabled
            "SEC2-GL-001",  # Docker registry credentials in pipeline YAML
            "SEC6-GL-007",  # Long-lived cloud credentials in GitLab CI
            "SEC10-GL-001", # CI_JOB_TOKEN printed to job log
            "SEC2-JK-001",  # Credential stored as build parameter
            "SEC2-JK-002",  # credentialsId bound from user-controlled parameter
            "SEC6-JK-001",  # Hardcoded credential in Jenkins environment block
            "SEC6-JK-002",  # Credential variable echoed inside withCredentials
            "SEC6-JK-003",  # println may expose credential inside withCredentials
            "SEC6-JK-005",  # Long-lived cloud credential in Jenkins env block
            "SEC6-JK-006",  # writeFile writes private key to workspace
            "SEC7-JK-003",  # docker.withRegistry called with null credentials
        ],
        owasp_cicd=["CICD-SEC-2", "CICD-SEC-6"],
    ),
    WeaknessCategory(
        code="UDW",
        name="Unpinned Dependency Weakness",
        description=(
            "Actions or Docker images referenced by mutable tags or branches "
            "instead of immutable commit SHAs or digests. Known compromised "
            "actions are also flagged."
        ),
        cwes=["CWE-829"],
        taintly_rules=[
            "SEC3-GH-001",  # Unpinned action (mutable tag)
            "SEC3-GH-002",  # Action pinned to branch
            "SEC3-GH-003",  # Known compromised action
            "SEC3-GH-005",  # Docker container without digest
            "SEC3-GH-008",  # pip --extra-index-url dependency-confusion shape
            "SEC3-GL-001",  # GitLab remote include
            "SEC3-GL-002",  # GitLab project include without pinned ref
            "SEC3-GL-005",  # GitLab Docker image without digest
            "SEC8-GL-001",  # GitLab CI image uses mutable :latest tag
            "SEC8-GL-002",  # External CI config included without pinned ref
            "SEC8-GL-003",  # Service container uses mutable :latest tag
            "SEC6-GL-008",  # Package registry URL overridden (dependency confusion)
            "SEC9-GL-002",  # Binary downloaded without checksum in GitLab CI
            "SEC9-GH-001",  # Binary downloaded without checksum
            "SEC3-JK-001",  # Jenkins shared library without commit-SHA pinning
            "SEC3-JK-002",  # @Grab annotation without explicit version
            "SEC3-JK-003",  # docker.image().inside() uses :latest
            "SEC8-JK-001",  # Jenkins Docker agent uses :latest
            "SEC8-JK-002",  # Remote Groovy script fetched and executed
            "SEC9-JK-003",  # wget downloads without checksum verification
        ],
        owasp_cicd=["CICD-SEC-3", "CICD-SEC-9"],
    ),
]

# Quick lookup
TAXONOMY_BY_CODE: dict[str, WeaknessCategory] = {t.code: t for t in TAXONOMY}

# Reverse mapping: rule_id → list of weakness codes
RULE_TO_WEAKNESS: dict[str, list[str]] = {}
for _cat in TAXONOMY:
    for _rule_id in _cat.taintly_rules:
        RULE_TO_WEAKNESS.setdefault(_rule_id, []).append(_cat.code)


def get_covered_categories() -> list[str]:
    """Return weakness codes that taintly has at least one rule for."""
    return [t.code for t in TAXONOMY if t.taintly_rules]


def get_uncovered_categories() -> list[str]:
    """Return weakness codes where taintly has zero rules."""
    return [t.code for t in TAXONOMY if not t.taintly_rules]


def format_coverage_matrix() -> str:
    """Format a human-readable coverage matrix."""
    lines = []
    lines.append("Weakness Category Coverage (vs Fares et al. arXiv:2601.14455v2)")
    lines.append("=" * 65)
    for t in TAXONOMY:
        count = len(t.taintly_rules)
        status = f"{count} rules" if count else "NOT COVERED"
        lines.append(f"  {t.code:<6} {t.name:<40} {status}")
    covered = len(get_covered_categories())
    total = len(TAXONOMY)
    lines.append(f"\nCoverage: {covered}/{total} categories")
    if t.notes:
        lines.append(f"\nNotes:")
        for t in TAXONOMY:
            if t.notes:
                lines.append(f"  {t.code}: {t.notes}")
    return "\n".join(lines)
