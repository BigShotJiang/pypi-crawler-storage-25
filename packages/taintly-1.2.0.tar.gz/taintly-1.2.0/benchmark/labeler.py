"""Ground truth labeling tool — adds manual weakness labels to benchmark workflows.

The paper notes: "Current scanner limitations include the absence of labeled
ground-truth datasets, which precludes reliable precision/recall measurement."

This tool lets you build that ground truth incrementally:
  1. Run taintly and all other scanners against the dataset
  2. Where scanners agree, flag as likely true positive for review
  3. Manually label the flagged workflows
  4. Compute precision/recall/F1 against ground truth

Usage:
  python -m benchmark label --init --dataset benchmark/dataset/
"""

from __future__ import annotations

import json
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .taxonomy import TAXONOMY


@dataclass
class WorkflowLabel:
    file: str
    weaknesses_present: list[str]   # Weakness codes confirmed present
    weaknesses_absent: list[str]    # Weakness codes confirmed absent
    weaknesses_unknown: list[str]   # Not yet labeled
    reviewer: str = ""
    notes: str = ""


@dataclass
class LabelSet:
    version: str = "1.0"
    labeled_count: int = 0
    total_count: int = 0
    labels: list[WorkflowLabel] = field(default_factory=list)


def init_labels(dataset_dir: str) -> LabelSet:
    """Initialize empty label set from dataset index."""
    index_path = Path(dataset_dir) / "index.json"
    if not index_path.exists():
        print(f"Error: {index_path} not found. Run collector first.", file=sys.stderr)
        sys.exit(1)

    with open(index_path, encoding="utf-8") as f:
        index = json.load(f)

    all_codes = [t.code for t in TAXONOMY]
    labels = [
        WorkflowLabel(
            file=entry["file"],
            weaknesses_present=[],
            weaknesses_absent=[],
            weaknesses_unknown=all_codes.copy(),
        )
        for entry in index
    ]

    label_set = LabelSet(total_count=len(labels), labeled_count=0, labels=labels)
    out_path = Path(dataset_dir) / "labels.json"
    out_path.write_text(json.dumps(asdict(label_set), indent=2), encoding="utf-8")
    print(f"Initialized {len(labels)} workflow labels -> {out_path}", file=sys.stderr)
    return label_set


def evaluate_labels(dataset_dir: str, results_path: str) -> dict:
    """Compute precision/recall/F1 per category against ground truth."""
    label_path = Path(dataset_dir) / "labels.json"
    if not label_path.exists():
        print("No labels.json found. Run --init and label workflows first.", file=sys.stderr)
        return {}

    with open(label_path, encoding="utf-8") as f:
        label_data = json.load(f)
    with open(results_path, encoding="utf-8") as f:
        results = json.load(f)

    detected: dict[str, set[str]] = {}
    if "per_workflow" in results:
        for wr in results["per_workflow"]:
            detected[wr["file"]] = set(wr.get("findings_by_category", {}).keys())

    metrics = {}
    for t in TAXONOMY:
        tp = fp = fn = 0
        for label in label_data["labels"]:
            f = label["file"]
            is_present = t.code in label.get("weaknesses_present", [])
            is_absent = t.code in label.get("weaknesses_absent", [])
            is_detected = t.code in detected.get(f, set())

            if is_present and is_detected:
                tp += 1
            elif not is_present and is_absent and is_detected:
                fp += 1
            elif is_present and not is_detected:
                fn += 1

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1        = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

        metrics[t.code] = {
            "name": t.name,
            "precision": round(precision, 3),
            "recall": round(recall, 3),
            "f1": round(f1, 3),
            "tp": tp, "fp": fp, "fn": fn,
        }

    return metrics


def format_evaluation(metrics: dict) -> str:
    lines = []
    lines.append("Ground Truth Evaluation")
    lines.append("=" * 75)
    lines.append(f"{'Category':<8} {'Name':<30} {'Prec':>6} {'Rec':>6} {'F1':>6} {'TP':>4} {'FP':>4} {'FN':>4}")
    lines.append("-" * 75)
    for code in [t.code for t in TAXONOMY]:
        if code in metrics:
            m = metrics[code]
            lines.append(
                f"{code:<8} {m['name']:<30} "
                f"{m['precision']:>6.3f} {m['recall']:>6.3f} {m['f1']:>6.3f} "
                f"{m['tp']:>4} {m['fp']:>4} {m['fn']:>4}"
            )
    return "\n".join(lines)
