"""CLI entry point for benchmark suite.

Usage:
  # Collect GitHub Actions workflows
  GITHUB_TOKEN=ghp_... python -m benchmark collect --output benchmark/dataset/

  # Collect GitLab CI pipelines
  GITLAB_TOKEN=glpat-... python -m benchmark collect-gitlab --output benchmark/gitlab-dataset/

  # Collect Jenkinsfiles
  GITHUB_TOKEN=ghp_... python -m benchmark collect-jenkins --output benchmark/jenkins-dataset/

  # Run benchmark (specify platform to match the collected dataset)
  python -m benchmark run --dataset benchmark/dataset/
  python -m benchmark run --dataset benchmark/gitlab-dataset/ --platform gitlab
  python -m benchmark run --dataset benchmark/jenkins-dataset/ --platform jenkins

  # Show taxonomy coverage
  python -m benchmark taxonomy

  # Initialize ground truth labels
  python -m benchmark label --init --dataset benchmark/dataset/
"""

from __future__ import annotations

import sys


def main():
    if len(sys.argv) < 2:
        print(
            "Usage: python -m benchmark <command>\n\n"
            "Commands:\n"
            "  collect          Fetch GitHub Actions workflows from GitHub orgs\n"
            "  collect-gitlab   Fetch .gitlab-ci.yml from GitLab.com groups\n"
            "  collect-jenkins  Fetch Jenkinsfiles from GitHub repos\n"
            "  run              Run taintly against collected dataset\n"
            "  taxonomy         Show weakness category coverage\n"
            "  label            Manage ground truth labels\n",
            file=sys.stderr,
        )
        sys.exit(1)

    command = sys.argv[1]
    # Remove the subcommand so argparse in each module sees the right args
    sys.argv = [sys.argv[0]] + sys.argv[2:]

    if command == "corpus":
        from .corpus_runner import main as corpus_main
        corpus_main()
        return

    if command == "collect":
        from .collector import main as collect_main

        collect_main()
    elif command == "collect-gitlab":
        from .gitlab_collector import main as gitlab_collect_main

        gitlab_collect_main()
    elif command == "collect-jenkins":
        from .jenkins_collector import main as jenkins_collect_main

        jenkins_collect_main()
    elif command == "run":
        from .runner import main as run_main

        run_main()
    elif command == "taxonomy":
        from .taxonomy import format_coverage_matrix

        print(format_coverage_matrix())
    elif command == "label":
        from .labeler import init_labels

        if "--init" in sys.argv:
            dataset = "benchmark/dataset"
            for i, arg in enumerate(sys.argv):
                if arg in ("--dataset", "-d") and i + 1 < len(sys.argv):
                    dataset = sys.argv[i + 1]
            init_labels(dataset)
        else:
            print("Usage: python -m benchmark label --init --dataset <path>", file=sys.stderr)
    else:
        print(f"Unknown command: {command}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
