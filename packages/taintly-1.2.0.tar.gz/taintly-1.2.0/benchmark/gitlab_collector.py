"""GitLab CI benchmark dataset collector.

Fetches real-world .gitlab-ci.yml files from GitLab.com public projects via
the GitLab REST API v4 for scanner benchmarking.

Usage:
  GITLAB_TOKEN=glpat-... python -m benchmark collect-gitlab --output benchmark/gitlab-dataset/
  GITLAB_TOKEN=glpat-... python -m benchmark collect-gitlab --groups gitlab-org gnome kde

Zero dependencies — uses only stdlib urllib.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

# ============================================================================
# Seed groups — major GitLab-hosted open source organisations
# ============================================================================

DEFAULT_GROUPS: list[str] = [
    "gitlab-org",       # GitLab itself — largest public GitLab namespace
    "gnome",            # GNOME desktop project
    "kde",              # KDE desktop project
    "inkscape",         # Inkscape vector graphics
    "libreoffice",      # LibreOffice office suite
    "freedesktop-sdk",  # Freedesktop
    "videolan",         # VLC / VideoLAN
    "gstreamer",        # GStreamer multimedia
    "mesa",             # Mesa 3D graphics
    "wayland",          # Wayland display server
]

_BASE = "https://gitlab.com/api/v4"
_RATE_LIMIT_PAUSE = 60


def _get(path: str, token: str | None) -> dict | list:
    url = f"{_BASE}{path}"
    headers: dict[str, str] = {"Accept": "application/json"}
    if token:
        headers["PRIVATE-TOKEN"] = token
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        if e.code == 429:
            reset = e.headers.get("RateLimit-Reset")
            wait = max(int(reset) - int(time.time()), 5) if reset else _RATE_LIMIT_PAUSE
            print(f"  Rate limited. Waiting {wait}s...", file=sys.stderr)
            time.sleep(min(wait, _RATE_LIMIT_PAUSE))
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read())
        raise


def _paginate(path: str, token: str | None, max_pages: int = 20) -> list[dict]:
    items: list[dict] = []
    page = 1
    while page <= max_pages:
        sep = "&" if "?" in path else "?"
        try:
            data = _get(f"{path}{sep}per_page=100&page={page}", token)
        except urllib.error.HTTPError as e:
            if e.code in (404, 403):
                break
            raise
        if not data:
            break
        if isinstance(data, list):
            items.extend(data)
            if len(data) < 100:
                break
        page += 1
    return items


@dataclass
class PipelineFile:
    group: str
    project: str
    project_id: int
    project_stars: int
    content: str
    lines: int
    stages_count: int
    jobs_count: int


@dataclass
class CollectionManifest:
    collected_at: str
    groups_queried: list[str]
    min_stars: int
    projects_scanned: int
    projects_with_pipelines: int
    total_pipelines: int
    total_lines: int
    pipelines_per_group: dict[str, int] = field(default_factory=dict)


def _count_stages(content: str) -> int:
    import re
    m = re.search(r"^stages\s*:\s*\n((?:[ \t]*-[^\n]*\n)+)", content, re.MULTILINE)
    if m:
        return len([ln for ln in m.group(1).splitlines() if ln.strip().startswith("-")])
    return 0


def _count_jobs(content: str) -> int:
    import re
    # Top-level keys that are not GitLab reserved keywords
    _RESERVED = {
        "stages", "image", "services", "before_script", "after_script",
        "variables", "cache", "include", "workflow", "default",
    }
    count = 0
    for m in re.finditer(r"^([a-zA-Z_][a-zA-Z0-9_\-. ]*):\s*$", content, re.MULTILINE):
        if m.group(1).strip() not in _RESERVED:
            count += 1
    return count


def collect_group_pipelines(
    group: str,
    token: str | None,
    min_stars: int = 100,
    max_age_months: int = 12,
) -> list[PipelineFile]:
    cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_months * 30)
    cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")

    print(f"  Scanning group: {group}", file=sys.stderr)

    try:
        projects = _paginate(
            f"/groups/{group}/projects?order_by=star_count&sort=desc"
            f"&with_shared=false&include_subgroups=true",
            token,
        )
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"    Group {group} not found, skipping", file=sys.stderr)
            return []
        raise

    pipelines: list[PipelineFile] = []
    projects_checked = 0

    for project in projects:
        if project.get("archived") or project.get("visibility") != "public":
            continue
        stars = project.get("star_count", 0)
        if stars < min_stars:
            break  # sorted by star_count desc
        last_activity = project.get("last_activity_at", "")
        if last_activity and last_activity < cutoff_str:
            continue

        project_id = project["id"]
        project_path = project["path_with_namespace"]
        projects_checked += 1

        try:
            # Fetch .gitlab-ci.yml via the repository files API
            file_data = _get(
                f"/projects/{project_id}/repository/files/"
                f".gitlab-ci.yml?ref={project.get('default_branch', 'main')}",
                token,
            )
            if isinstance(file_data, dict) and "content" in file_data:
                content = base64.b64decode(file_data["content"]).decode("utf-8", errors="replace")
            else:
                continue
        except urllib.error.HTTPError:
            continue

        pipelines.append(PipelineFile(
            group=group,
            project=project_path,
            project_id=project_id,
            project_stars=stars,
            content=content,
            lines=len(content.splitlines()),
            stages_count=_count_stages(content),
            jobs_count=_count_jobs(content),
        ))

        if projects_checked % 10 == 0:
            print(
                f"    {projects_checked} projects, {len(pipelines)} pipelines so far",
                file=sys.stderr,
            )

    print(
        f"    Done: {projects_checked} projects, {len(pipelines)} pipelines",
        file=sys.stderr,
    )
    return pipelines


def save_dataset(
    pipelines: list[PipelineFile],
    output_dir: str,
    groups_queried: list[str],
    min_stars: int,
) -> CollectionManifest:
    out = Path(output_dir)
    pl_dir = out / "pipelines"
    pl_dir.mkdir(parents=True, exist_ok=True)

    index = []
    for pl in pipelines:
        group_slug = pl.group.replace("/", "_")
        group_dir = pl_dir / group_slug
        group_dir.mkdir(exist_ok=True)

        project_slug = pl.project.replace("/", "__")
        filepath = group_dir / f"{project_slug}.gitlab-ci.yml"
        filepath.write_text(pl.content, encoding="utf-8")

        index.append({
            "group": pl.group,
            "project": pl.project,
            "project_id": pl.project_id,
            "project_stars": pl.project_stars,
            "file": str(filepath.relative_to(out)),
            "lines": pl.lines,
            "stages_count": pl.stages_count,
            "jobs_count": pl.jobs_count,
        })

    (out / "index.json").write_text(json.dumps(index, indent=2), encoding="utf-8")

    pl_per_group: dict[str, int] = {}
    for pl in pipelines:
        pl_per_group[pl.group] = pl_per_group.get(pl.group, 0) + 1

    manifest = CollectionManifest(
        collected_at=datetime.now(timezone.utc).isoformat(),
        groups_queried=groups_queried,
        min_stars=min_stars,
        projects_scanned=len(set(pl.project for pl in pipelines)),
        projects_with_pipelines=len(set(pl.project for pl in pipelines)),
        total_pipelines=len(pipelines),
        total_lines=sum(pl.lines for pl in pipelines),
        pipelines_per_group=pl_per_group,
    )
    (out / "manifest.json").write_text(
        json.dumps(asdict(manifest), indent=2), encoding="utf-8"
    )
    return manifest


def main():
    parser = argparse.ArgumentParser(
        prog="benchmark-collect-gitlab",
        description="Collect real-world .gitlab-ci.yml files for scanner benchmarking.",
    )
    parser.add_argument("--output", "-o", default="benchmark/gitlab-dataset")
    parser.add_argument("--groups", nargs="*", default=None)
    parser.add_argument("--min-stars", type=int, default=100)
    parser.add_argument("--max-age-months", type=int, default=12)
    args = parser.parse_args()

    token = os.environ.get("GITLAB_TOKEN")
    if not token:
        print(
            "Warning: GITLAB_TOKEN not set. Unauthenticated requests are heavily "
            "rate-limited (10 req/min). Set GITLAB_TOKEN for better throughput.",
            file=sys.stderr,
        )

    groups = args.groups or DEFAULT_GROUPS
    all_pipelines: list[PipelineFile] = []

    print(
        f"Collecting .gitlab-ci.yml from {len(groups)} groups "
        f"(min {args.min_stars} stars)...",
        file=sys.stderr,
    )

    for group in groups:
        try:
            pls = collect_group_pipelines(group, token, args.min_stars, args.max_age_months)
            all_pipelines.extend(pls)
        except Exception as e:
            print(f"  Error on group {group}: {e}", file=sys.stderr)

    if not all_pipelines:
        print("No pipelines collected.", file=sys.stderr)
        sys.exit(1)

    manifest = save_dataset(all_pipelines, args.output, groups, args.min_stars)
    print(
        f"\nDone: {manifest.projects_with_pipelines} projects, "
        f"{manifest.total_pipelines} pipelines → {args.output}/",
        file=sys.stderr,
    )


if __name__ == "__main__":
    main()
