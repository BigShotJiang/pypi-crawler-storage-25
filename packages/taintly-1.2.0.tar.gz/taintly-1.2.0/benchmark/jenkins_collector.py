"""Jenkins benchmark dataset collector.

Fetches real-world Jenkinsfiles from GitHub public repositories via the
GitHub REST API for scanner benchmarking.

Strategy:
  1. List repos in seed GitHub orgs known to use Jenkins CI.
  2. Try to fetch `Jenkinsfile` from the repo root.
  3. Also search for `Jenkinsfile` in common sub-paths.
  4. Fall back to GitHub code search API when direct fetch fails.

Usage:
  GITHUB_TOKEN=ghp_... python -m benchmark collect-jenkins --output benchmark/jenkins-dataset/
  GITHUB_TOKEN=ghp_... python -m benchmark collect-jenkins --orgs jenkinsci apache hashicorp

Zero dependencies — uses only stdlib urllib.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

# ============================================================================
# Seed orgs — organisations known to maintain Jenkins-based CI pipelines
# ============================================================================

DEFAULT_ORGS: list[str] = [
    "jenkinsci",         # Jenkins plugins — canonical Jenkinsfile source
    "apache",            # Apache Software Foundation
    "hashicorp",         # Terraform, Vault, Consul
    "spring-projects",   # Spring Framework
    "cloudfoundry",      # Cloud Foundry
    "openjdk",           # OpenJDK
    "redhat-developer",  # Red Hat developer projects
    "elastic",           # Elasticsearch, Kibana
    "Netflix",           # Netflix OSS
    "linkedin",          # LinkedIn OSS
]

# Paths to check for Jenkinsfile in each repo
_JENKINSFILE_PATHS = [
    "Jenkinsfile",
    "jenkins/Jenkinsfile",
    "ci/Jenkinsfile",
    ".jenkins/Jenkinsfile",
    "pipeline/Jenkinsfile",
]

_BASE = "https://api.github.com"
_RATE_LIMIT_PAUSE = 60


def _get(path: str, token: str) -> dict | list:
    url = f"{_BASE}{path}" if path.startswith("/") else path
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        if e.code == 403:
            reset = e.headers.get("X-RateLimit-Reset")
            if reset:
                wait = max(int(reset) - int(time.time()), 5)
                print(f"  Rate limited. Waiting {wait}s...", file=sys.stderr)
                time.sleep(min(wait, _RATE_LIMIT_PAUSE))
                with urllib.request.urlopen(req, timeout=30) as resp:
                    return json.loads(resp.read())
        raise


def _paginate(path: str, token: str, max_pages: int = 10) -> list[dict]:
    items: list[dict] = []
    page = 1
    while page <= max_pages:
        sep = "&" if "?" in path else "?"
        try:
            data = _get(f"{path}{sep}per_page=100&page={page}", token)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                break
            raise
        if not data:
            break
        if isinstance(data, list):
            items.extend(data)
            if len(data) < 100:
                break
        page += 1
    return items


def _fetch_file(full_name: str, path: str, token: str) -> str | None:
    """Fetch a single file's content from a repo. Returns decoded text or None."""
    try:
        data = _get(f"/repos/{full_name}/contents/{path}", token)
        if isinstance(data, dict) and "content" in data:
            return base64.b64decode(data["content"]).decode("utf-8", errors="replace")
    except urllib.error.HTTPError:
        pass
    return None


def _count_stages(content: str) -> int:
    """Count `stage(...)` or `stage '...'` calls in a Jenkinsfile."""
    return len(re.findall(r"\bstage\s*[\('\"]", content))


def _count_steps(content: str) -> int:
    """Count sh/bat/powershell step calls."""
    return len(re.findall(r"\b(?:sh|bat|powershell)\s*[\('\"]", content))


@dataclass
class JenkinsfileEntry:
    org: str
    repo: str
    repo_stars: int
    path: str          # path within repo (e.g. "Jenkinsfile")
    content: str
    lines: int
    stages_count: int
    steps_count: int


@dataclass
class CollectionManifest:
    collected_at: str
    orgs_queried: list[str]
    min_stars: int
    repos_scanned: int
    repos_with_jenkinsfiles: int
    total_jenkinsfiles: int
    total_lines: int
    jenkinsfiles_per_org: dict[str, int] = field(default_factory=dict)


def collect_org_jenkinsfiles(
    org: str,
    token: str,
    min_stars: int = 100,
    max_age_months: int = 24,
) -> list[JenkinsfileEntry]:
    cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_months * 30)
    cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")

    print(f"  Scanning org: {org}", file=sys.stderr)

    try:
        repos = _paginate(f"/orgs/{org}/repos?sort=stars&direction=desc", token)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"    Org {org} not found, skipping", file=sys.stderr)
            return []
        raise

    entries: list[JenkinsfileEntry] = []
    repos_checked = 0

    for repo in repos:
        if repo.get("archived") or repo.get("disabled") or repo.get("fork"):
            continue
        stars = repo.get("stargazers_count", 0)
        if stars < min_stars:
            break  # sorted by stars desc
        pushed_at = repo.get("pushed_at", "")
        if pushed_at and pushed_at < cutoff_str:
            continue

        full_name = repo["full_name"]
        repos_checked += 1

        # Try each known Jenkinsfile path in priority order
        for jf_path in _JENKINSFILE_PATHS:
            content = _fetch_file(full_name, jf_path, token)
            if content is None:
                continue

            # Validate it looks like a Jenkinsfile (not just any file)
            if not re.search(r"\b(?:pipeline|node|stage|sh|bat)\b", content):
                continue

            entries.append(JenkinsfileEntry(
                org=org,
                repo=full_name,
                repo_stars=stars,
                path=jf_path,
                content=content,
                lines=len(content.splitlines()),
                stages_count=_count_stages(content),
                steps_count=_count_steps(content),
            ))
            break  # one Jenkinsfile per repo

        if repos_checked % 10 == 0:
            print(
                f"    {repos_checked} repos, {len(entries)} Jenkinsfiles so far",
                file=sys.stderr,
            )

    # Code search fallback for orgs with low direct-fetch hit rate
    if len(entries) < 3:
        print(f"    Direct fetch found {len(entries)}, trying code search...", file=sys.stderr)
        try:
            query = urllib.parse.quote(f"filename:Jenkinsfile org:{org}")
            search_data = _get(
                f"/search/code?q={query}&per_page=30",
                token,
            )
            if isinstance(search_data, dict):
                for item in search_data.get("items", []):
                    repo_info = item.get("repository", {})
                    if repo_info.get("fork") or repo_info.get("archived"):
                        continue
                    full_name = repo_info["full_name"]
                    # Skip repos we already collected
                    if any(e.repo == full_name for e in entries):
                        continue
                    stars = repo_info.get("stargazers_count", 0)
                    content = _fetch_file(full_name, item["path"], token)
                    if content and re.search(r"\b(?:pipeline|node|stage|sh|bat)\b", content):
                        entries.append(JenkinsfileEntry(
                            org=org,
                            repo=full_name,
                            repo_stars=stars,
                            path=item["path"],
                            content=content,
                            lines=len(content.splitlines()),
                            stages_count=_count_stages(content),
                            steps_count=_count_steps(content),
                        ))
        except urllib.error.HTTPError as e:
            if e.code != 422:  # 422 = code search unavailable without auth
                raise

    print(
        f"    Done: {repos_checked} repos, {len(entries)} Jenkinsfiles",
        file=sys.stderr,
    )
    return entries


def save_dataset(
    entries: list[JenkinsfileEntry],
    output_dir: str,
    orgs_queried: list[str],
    min_stars: int,
) -> CollectionManifest:
    out = Path(output_dir)
    jf_dir = out / "jenkinsfiles"
    jf_dir.mkdir(parents=True, exist_ok=True)

    index = []
    for entry in entries:
        org_dir = jf_dir / entry.org
        org_dir.mkdir(exist_ok=True)

        repo_short = entry.repo.split("/")[-1]
        path_slug = entry.path.replace("/", "_")
        filepath = org_dir / f"{repo_short}__{path_slug}"
        filepath.write_text(entry.content, encoding="utf-8")

        index.append({
            "org": entry.org,
            "repo": entry.repo,
            "repo_stars": entry.repo_stars,
            "path": entry.path,
            "file": str(filepath.relative_to(out)),
            "lines": entry.lines,
            "stages_count": entry.stages_count,
            "steps_count": entry.steps_count,
        })

    (out / "index.json").write_text(json.dumps(index, indent=2), encoding="utf-8")

    jf_per_org: dict[str, int] = {}
    for entry in entries:
        jf_per_org[entry.org] = jf_per_org.get(entry.org, 0) + 1

    manifest = CollectionManifest(
        collected_at=datetime.now(timezone.utc).isoformat(),
        orgs_queried=orgs_queried,
        min_stars=min_stars,
        repos_scanned=len(set(e.repo for e in entries)),
        repos_with_jenkinsfiles=len(set(e.repo for e in entries)),
        total_jenkinsfiles=len(entries),
        total_lines=sum(e.lines for e in entries),
        jenkinsfiles_per_org=jf_per_org,
    )
    (out / "manifest.json").write_text(
        json.dumps(asdict(manifest), indent=2), encoding="utf-8"
    )
    return manifest


def main():
    parser = argparse.ArgumentParser(
        prog="benchmark-collect-jenkins",
        description="Collect real-world Jenkinsfiles for scanner benchmarking.",
    )
    parser.add_argument("--output", "-o", default="benchmark/jenkins-dataset")
    parser.add_argument("--orgs", nargs="*", default=None)
    parser.add_argument("--min-stars", type=int, default=100)
    parser.add_argument("--max-age-months", type=int, default=24)
    args = parser.parse_args()

    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        print("Error: GITHUB_TOKEN environment variable required", file=sys.stderr)
        sys.exit(1)

    orgs = args.orgs or DEFAULT_ORGS
    all_entries: list[JenkinsfileEntry] = []

    print(
        f"Collecting Jenkinsfiles from {len(orgs)} orgs "
        f"(min {args.min_stars} stars)...",
        file=sys.stderr,
    )

    for org in orgs:
        try:
            ents = collect_org_jenkinsfiles(org, token, args.min_stars, args.max_age_months)
            all_entries.extend(ents)
        except Exception as e:
            print(f"  Error on org {org}: {e}", file=sys.stderr)

    if not all_entries:
        print("No Jenkinsfiles collected.", file=sys.stderr)
        sys.exit(1)

    manifest = save_dataset(all_entries, args.output, orgs, args.min_stars)
    print(
        f"\nDone: {manifest.repos_with_jenkinsfiles} repos, "
        f"{manifest.total_jenkinsfiles} Jenkinsfiles → {args.output}/",
        file=sys.stderr,
    )


if __name__ == "__main__":
    main()
