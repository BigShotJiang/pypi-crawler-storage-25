"""Corpus precision runner.

Validates that taintly's reporting-v2 output stays in line with the
labeled expectations in ``benchmark/corpus/labels.py``.  Prints a
pass/fail table per scenario and exits non-zero if any scenario drifts
from its label — designed to run as a CI gate.

Usage:
    python -m benchmark corpus
    python -m benchmark corpus --verbose      # show the actual score too
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path

from taintly.engine import scan_file
from taintly.families import cluster_findings
from taintly.models import Platform
from taintly.rules.registry import load_all_rules
from taintly.scorer import compute_score

from .corpus.labels import CORPUS, CorpusLabel

_CORPUS_DIR = Path(__file__).parent / "corpus"


@dataclass
class CheckResult:
    label: CorpusLabel
    score: int
    grade: str
    confirmed_families: set[str]
    review_needed_families: set[str]
    top_exploitability: str
    failures: list[str]

    @property
    def ok(self) -> bool:
        return not self.failures


def _check_one(label: CorpusLabel, rules) -> CheckResult:
    path = str(_CORPUS_DIR / label.file)
    findings = scan_file(path, rules)
    score = compute_score(findings)
    clusters = cluster_findings(findings)

    confirmed = {cl.family_id for cl in clusters if not cl.review_needed}
    review = {cl.family_id for cl in clusters if cl.review_needed}

    # Worst exploitability across confirmed (non-review-needed) clusters.
    _rank = {"low": 1, "medium": 2, "high": 3}
    top_expl = "low"
    for cl in clusters:
        if cl.review_needed:
            continue
        if _rank.get(cl.top_exploitability, 0) > _rank.get(top_expl, 0):
            top_expl = cl.top_exploitability

    failures: list[str] = []

    if score.total_score < label.min_score:
        failures.append(
            f"score {score.total_score} below min {label.min_score}"
        )
    if score.total_score > label.max_score:
        failures.append(
            f"score {score.total_score} above max {label.max_score}"
        )
    if label.expected_grade and score.grade != label.expected_grade:
        failures.append(
            f"grade {score.grade!r} != expected {label.expected_grade!r}"
        )

    missing = label.expected_families - confirmed
    if missing:
        failures.append(f"missing expected confirmed families: {sorted(missing)}")

    forbidden = label.forbidden_families & (confirmed | review)
    if forbidden:
        failures.append(f"forbidden families present: {sorted(forbidden)}")

    # review_needed_families: must NOT be in confirmed, MUST be in review
    misplaced = label.review_needed_families & confirmed
    if misplaced:
        failures.append(
            f"families leaked into confirmed bucket (should be review-needed): "
            f"{sorted(misplaced)}"
        )
    missing_review = label.review_needed_families - review
    if missing_review:
        failures.append(
            f"missing review-needed families: {sorted(missing_review)}"
        )

    if label.expected_top_exploitability:
        if _rank.get(top_expl, 0) != _rank.get(label.expected_top_exploitability, 0):
            failures.append(
                f"top_exploitability {top_expl!r} != expected "
                f"{label.expected_top_exploitability!r}"
            )

    return CheckResult(
        label=label,
        score=score.total_score,
        grade=score.grade,
        confirmed_families=confirmed,
        review_needed_families=review,
        top_exploitability=top_expl,
        failures=failures,
    )


def run(verbose: bool = False) -> int:
    rules = [r for r in load_all_rules() if r.platform == Platform.GITHUB]

    print("Corpus precision check — labeled scenarios")
    print("-" * 70)

    all_ok = True
    for label in CORPUS:
        result = _check_one(label, rules)
        status = "PASS" if result.ok else "FAIL"
        if not result.ok:
            all_ok = False
        print(f"  [{status}] {label.file:<32}  score={result.score:>3}/100  grade={result.grade}")
        if verbose:
            print(f"          confirmed: {sorted(result.confirmed_families) or '-'}")
            print(f"          review:    {sorted(result.review_needed_families) or '-'}")
            print(f"          top_expl:  {result.top_exploitability}")
        for failure in result.failures:
            print(f"      ✗ {failure}")

    print("-" * 70)
    if all_ok:
        print(f"All {len(CORPUS)} scenario(s) passed.")
        return 0
    n_fail = sum(1 for lb in CORPUS if not _check_one(lb, rules).ok)
    print(f"{n_fail}/{len(CORPUS)} scenario(s) FAILED.")
    return 10


def main():
    parser = argparse.ArgumentParser(prog="benchmark corpus")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()
    sys.exit(run(verbose=args.verbose))


if __name__ == "__main__":
    main()
