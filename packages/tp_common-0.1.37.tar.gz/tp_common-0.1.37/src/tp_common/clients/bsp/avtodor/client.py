from __future__ import annotations

from tp_common.clients.bsp.avtodor.request import TariffsRequest
from tp_common.clients.bsp.avtodor.response import TariffsResponse
from tp_common.clients.bsp.base_ms_client import BaseMsClient
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger


class BspAvtodorClient(BaseMsClient):
    """Клиент bsp-avtodor: только пути и модели; Bearer и retry — в KeycloakClient."""

    _service_name = "bsp-avtodor"
    _default_api_version_path = ""

    def __init__(
        self,
        *,
        logger: TpLogger,
        keycloak_url: str | None = None,
        avtodor_url: str | None = None,
        keycloak_oauth: KeycloakOAuthClient | None = None,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 3,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        super().__init__(
            logger=logger,
            keycloak_url=keycloak_url,
            keycloak_oauth=keycloak_oauth,
            env_type=env_type,
            service_url=avtodor_url,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    async def get_tariffs(self, request: TariffsRequest) -> TariffsResponse:
        """GET /v1/tariffs — список тарифов с фильтрами и пагинацией.

        Параметры запроса передаются в query string в camelCase
        (alias_generator у `BaseRequest`); enum-значения — строки
        (`use_enum_values=True` у `BaseQueryRequest`).
        """
        return await self.get(
            uri="/tariffs",
            response_schema=TariffsResponse,
            params=request,
        )
