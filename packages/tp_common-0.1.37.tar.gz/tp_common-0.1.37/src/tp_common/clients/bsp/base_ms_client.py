"""Базовый Keycloak-клиент BSP: выбор URL по ``service_name``, probe ``/health``, кеш."""

from __future__ import annotations

import ssl
import threading
import urllib.error
import urllib.request
from collections.abc import Callable
from typing import ClassVar, Final

from tp_common.keycloak.client import KeycloakClient
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger

_DEFAULT_PROBE_TIMEOUT_S: Final[float] = 2.0

_cache_lock = threading.Lock()
_api_base_cache: dict[tuple[str, str], str] = {}


class BspServiceUrlResolutionError(RuntimeError):
    """Ни один кандидат базового URL не прошёл GET ``/health``."""


def api_base_to_health_url(api_base: str) -> str:
    """``http://bsp-mos-account-api/api`` → ``http://bsp-mos-account-api/health``."""
    base = api_base.rstrip("/")
    if base.endswith("/api"):
        return f"{base[:-4]}/health"
    return f"{base}/health"


def check_service_health(
    health_url: str,
    *,
    timeout_s: float = _DEFAULT_PROBE_TIMEOUT_S,
    verify_ssl: bool = False,
) -> tuple[bool, str | None]:
    """GET ``/health`` без Bearer. Возвращает ``(ok, описание_ошибки)``."""
    request = urllib.request.Request(health_url, method="GET")
    context = (
        ssl.create_default_context() if verify_ssl else ssl._create_unverified_context()
    )
    try:
        with urllib.request.urlopen(
            request, timeout=timeout_s, context=context
        ) as response:
            if 200 <= response.status < 300:
                return True, None
            return False, f"HTTP {response.status}"
    except urllib.error.HTTPError as exc:
        return False, f"HTTP {exc.code}"
    except urllib.error.URLError as exc:
        reason = exc.reason
        return False, str(reason) if reason else repr(exc)
    except TimeoutError:
        return False, "timeout"
    except ValueError as exc:
        return False, str(exc)


def is_service_alive(
    health_url: str,
    *,
    timeout_s: float = _DEFAULT_PROBE_TIMEOUT_S,
    verify_ssl: bool = False,
) -> bool:
    ok, _ = check_service_health(health_url, timeout_s=timeout_s, verify_ssl=verify_ssl)
    return ok


def service_name_to_slug(service_name: str) -> str:
    """``bsp-mos-pass`` → ``mos-pass``; без префикса имя не меняется."""
    name = service_name.strip()
    if name.startswith("bsp-"):
        return name[4:]
    return name


def public_api_base_url(service_name: str, env_type: EnvironmentType) -> str:
    """Публичный URL ``…/api`` по slug и контуру (dev/staging — subdomain, prod — path)."""
    if env_type is EnvironmentType.LOCAL:
        return "http://127.0.0.1/api"
    slug = service_name_to_slug(service_name)
    match env_type:
        case EnvironmentType.STAGING:
            return f"https://{slug}.bsp-staging.bz/api"
        case EnvironmentType.PROD:
            return f"https://bsp.8525.ru/{slug}/api"
        case EnvironmentType.DEV:
            return f"https://{slug}.bsp-dev.bz/api"
        case _:
            return "http://127.0.0.1/api"


def _cluster_api_base_candidates(service_name: str) -> list[str]:
    """In-cluster DNS без namespace: ``http://{service_name}-api/api``."""
    name = service_name.strip()
    candidates = [f"http://{name}-api/api"]
    if name.startswith("bsp-"):
        slug = name[4:]
        alt = f"http://{slug}-api/api"
        if alt not in candidates:
            candidates.append(alt)
    return candidates


def iter_api_base_candidates(
    service_name: str,
    env_type: EnvironmentType,
) -> list[str]:
    """Кандидаты: in-cluster DNS, затем публичный URL (первый живой — через probe)."""
    seen: set[str] = set()
    ordered: list[str] = []

    def add(url: str) -> None:
        normalized = url.rstrip("/")
        if normalized not in seen:
            seen.add(normalized)
            ordered.append(normalized)

    if env_type is EnvironmentType.LOCAL:
        add(public_api_base_url(service_name, env_type))
    else:
        for cluster_url in _cluster_api_base_candidates(service_name):
            add(cluster_url)
        add(public_api_base_url(service_name, env_type))

    return ordered


def resolve_api_base_url(
    *,
    service_name: str,
    env_type: EnvironmentType,
    explicit_api_base: str | None = None,
    probe_timeout_s: float = _DEFAULT_PROBE_TIMEOUT_S,
    verify_ssl: bool = False,
    health_check: Callable[[str, float, bool], tuple[bool, str | None]] | None = None,
) -> str:
    """Первый живой ``…/api``; кеш на процесс по ``(service_name, env_type)``."""
    if explicit_api_base and explicit_api_base.strip():
        return explicit_api_base.strip().rstrip("/")

    cache_key = (service_name.strip(), env_type.value)
    with _cache_lock:
        cached = _api_base_cache.get(cache_key)
    if cached is not None:
        return cached

    def default_check(
        url: str, timeout: float, verify: bool
    ) -> tuple[bool, str | None]:
        return check_service_health(url, timeout_s=timeout, verify_ssl=verify)

    check = health_check or default_check
    probe_log: list[str] = []
    for api_base in iter_api_base_candidates(service_name, env_type):
        health_url = api_base_to_health_url(api_base)
        ok, err = check(health_url, probe_timeout_s, verify_ssl)
        probe_log.append(f"{health_url} ({err or 'ok'})" if not ok else health_url)
        if ok:
            with _cache_lock:
                _api_base_cache[cache_key] = api_base
            return api_base

    msg = (
        f"Не найден живой URL для {service_name!r} (env={env_type.value}). "
        f"Проверены: {probe_log}"
    )
    raise BspServiceUrlResolutionError(msg)


def clear_api_base_url_cache() -> None:
    """Сброс кеша (тесты)."""
    with _cache_lock:
        _api_base_cache.clear()


def finalize_client_base_url(api_base: str, api_version_path: str) -> str:
    """Собирает ``base_url`` для ``KeycloakClient`` (с завершающим ``/``)."""
    root = api_base.rstrip("/")
    version = api_version_path.strip()
    if not version:
        return f"{root}/"
    return f"{root}{version.rstrip('/')}/"


class BaseMsClient(KeycloakClient):
    """Базовый клиент микросервисов BSP.

    У подкласса задаётся ``_service_name`` (например ``bsp-mos-account``). Перебор URL:
    in-cluster ``http://{service}-api/health``, затем публичный по slug (``bsp-*`` → ``*``);
    первый 2xx кешируется в памяти процесса.
    """

    _service_name: ClassVar[str]
    _default_api_version_path: ClassVar[str] = "/v1"

    def __init__(
        self,
        *,
        logger: TpLogger,
        keycloak_url: str | None = None,
        keycloak_oauth: KeycloakOAuthClient | None = None,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        service_url: str | None = None,
        max_retries: int = 5,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        name = self._service_name.strip()
        if not name:
            msg = f"{type(self).__name__}._service_name must be set"
            raise ValueError(msg)

        api_base = resolve_api_base_url(
            service_name=name,
            env_type=env_type,
            explicit_api_base=service_url,
            verify_ssl=verify_ssl,
        )
        base_url = finalize_client_base_url(api_base, self._api_version_path())

        super().__init__(
            base_url=base_url,
            logger=logger,
            audience=name,
            keycloak_oauth=keycloak_oauth,
            keycloak_url=keycloak_url,
            env_type=env_type,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    @classmethod
    def _api_version_path(cls) -> str:
        return cls._default_api_version_path
