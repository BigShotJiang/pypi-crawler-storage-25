"""
Пример: POST ``/vehicles/sync`` — синхронизация списка ГРЗ.

Запуск::

  python -m tp_common.clients.bsp.mos_rnis.examples.sync_vehicles
"""

from __future__ import annotations

from tp_common.clients.bsp.mos_rnis.client import BspMosRnisClient
from tp_common.clients.bsp.mos_rnis.examples import demo_params
from tp_common.clients.bsp.mos_rnis.examples._runner import main
from tp_common.clients.bsp.mos_rnis.request import VehicleSyncRequest


async def _call(client: BspMosRnisClient) -> object:
    return await client.sync_vehicles(
        VehicleSyncRequest(reg_numbers=list(demo_params.SYNC_REG_NUMBERS))
    )


if __name__ == "__main__":
    main(_call)
