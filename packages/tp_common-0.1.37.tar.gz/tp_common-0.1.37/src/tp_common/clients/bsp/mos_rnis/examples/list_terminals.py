"""
Пример: GET ``/terminals`` — полный список терминалов по ГРЗ.

Запуск::

  python -m tp_common.clients.bsp.mos_rnis.examples.list_terminals
"""

from __future__ import annotations

from tp_common.clients.bsp.mos_rnis.client import BspMosRnisClient
from tp_common.clients.bsp.mos_rnis.examples import demo_params
from tp_common.clients.bsp.mos_rnis.examples._runner import main
from tp_common.clients.bsp.mos_rnis.request import TerminalsRequest


async def _call(client: BspMosRnisClient) -> object:
    return await client.list_terminals(
        TerminalsRequest(reg_number=demo_params.TERMINALS_REG_NUMBER)
    )


if __name__ == "__main__":
    main(_call)
