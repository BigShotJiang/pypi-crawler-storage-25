"""
Пример: GET ``/tasks`` — поиск задач.

Запуск::

  python -m tp_common.clients.bsp.mos_rnis.examples.list_tasks
"""

from __future__ import annotations

from tp_common.clients.bsp.mos_rnis.client import BspMosRnisClient
from tp_common.clients.bsp.mos_rnis.examples import demo_params
from tp_common.clients.bsp.mos_rnis.examples._runner import main
from tp_common.clients.bsp.mos_rnis.request import TasksRequest


async def _call(client: BspMosRnisClient) -> object:
    return await client.list_tasks(
        TasksRequest(
            reg_number=demo_params.TASK_LIST_REG_NUMBER,
            task_id=demo_params.TASK_LIST_TASK_ID,
            status=demo_params.TASK_LIST_STATUS,
            is_completed=demo_params.TASK_LIST_IS_COMPLETED,
            limit=demo_params.TASK_LIST_LIMIT,
            offset=demo_params.TASK_LIST_OFFSET,
            sort=demo_params.TASK_LIST_SORT,
            sort_by=demo_params.TASK_LIST_SORT_BY,
        )
    )


if __name__ == "__main__":
    main(_call)
