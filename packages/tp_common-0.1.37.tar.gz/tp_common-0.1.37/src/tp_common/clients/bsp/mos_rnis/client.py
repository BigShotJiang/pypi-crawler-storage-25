"""HTTP-клиент bsp-mos-rnis (``/api/v1``)."""

from __future__ import annotations

from tp_common.clients.bsp.base_ms_client import BaseMsClient
from tp_common.clients.bsp.mos_account.response import Account
from tp_common.clients.bsp.mos_rnis.request import (
    AccountCreateRequest,
    TaskEventsRequest,
    TasksRequest,
    TerminalsRequest,
    VehicleCreateRequest,
    VehicleSyncRequest,
)
from tp_common.clients.bsp.mos_rnis.response import (
    TaskEventsResponse,
    TasksResponse,
    TerminalsResponse,
    VehicleResponse,
    VehicleRetryAtResetResponse,
    VehicleSyncResponse,
)
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger


class BspMosRnisClient(BaseMsClient):
    """Клиент bsp-mos-rnis: пути и модели; Bearer и retry — в ``KeycloakClient``.

    Пути: ``/vehicles`` (POST), ``/vehicles/sync`` (POST), ``/vehicles/retry-at/reset`` (POST),
    ``/tasks`` (GET), ``/terminals`` (GET), ``/events/tasks`` (long-poll),
    ``/accounts`` (POST, прокси в bsp-mos-account).
    """

    _service_name = "bsp-mos-rnis"

    def __init__(
        self,
        *,
        keycloak_url: str | None = None,
        logger: TpLogger,
        mos_rnis_url: str | None = None,
        keycloak_oauth: KeycloakOAuthClient | None = None,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 3,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        super().__init__(
            logger=logger,
            keycloak_url=keycloak_url,
            keycloak_oauth=keycloak_oauth,
            env_type=env_type,
            service_url=mos_rnis_url,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    async def ensure_vehicle(self, request: VehicleCreateRequest) -> VehicleResponse:
        """POST ``/vehicles`` — ТС, привязка к ``service_id`` и задача на загрузку."""
        return await self.post(
            uri="/vehicles",
            response_schema=VehicleResponse,
            json=request.model_dump(mode="json", by_alias=True),
        )

    async def sync_vehicles(self, request: VehicleSyncRequest) -> VehicleSyncResponse:
        """POST ``/vehicles/sync`` — полный желаемый набор ГРЗ."""
        return await self.post(
            uri="/vehicles/sync",
            response_schema=VehicleSyncResponse,
            json=request.model_dump(mode="json", by_alias=True),
        )

    async def reset_vehicles_retry_at(self) -> VehicleRetryAtResetResponse:
        """POST ``/vehicles/retry-at/reset`` — ``next_retry_at = now`` для всех ТС сервиса."""
        return await self.post(
            uri="/vehicles/retry-at/reset",
            response_schema=VehicleRetryAtResetResponse,
        )

    async def list_tasks(self, request: TasksRequest) -> TasksResponse:
        """GET ``/tasks`` — поиск задач (``regNumber`` опционален)."""
        return await self.get(
            uri="/tasks",
            response_schema=TasksResponse,
            params=request,
        )

    async def list_terminals(self, request: TerminalsRequest) -> TerminalsResponse:
        """GET ``/terminals`` — все терминалы ТС по ГРЗ (без пагинации)."""
        return await self.get(
            uri="/terminals",
            response_schema=TerminalsResponse,
            params=request,
        )

    async def get_task_events(
        self,
        request: TaskEventsRequest,
        *,
        http_timeout: float = 120.0,
    ) -> TaskEventsResponse:
        """GET ``/events/tasks`` — long-poll app-событий задач.

        ``service_id`` из Bearer (Keycloak). В следующем запросе задайте
        ``TaskEventsRequest.offset`` равным прошлому ``nextOffset``, либо опустите поле.
        """
        return await self.get(
            uri="/events/tasks",
            response_schema=TaskEventsResponse,
            params=request,
            timeout=http_timeout,
        )

    async def create_account(self, request: AccountCreateRequest) -> Account:
        """POST ``/accounts`` — создать аккаунт (прокси в bsp-mos-account, RNIS включён)."""
        return await self.post(
            uri="/accounts",
            response_schema=Account,
            json=request.model_dump(mode="json", exclude_none=True, by_alias=True),
        )
