"""Схемы ответов HTTP-клиента bsp-mos-rnis (зеркало ``bsp-mos-rnis/src/api/v1/*/response.py``)."""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import StrEnum

from pydantic import Field, RootModel

from tp_common.clients.bsp.mos_account.response import Account
from tp_common.clients.bsp.mos_rnis.request import TaskStatus
from tp_common.kafka.app_event.schemas import BaseAppEventMessage
from tp_common.route.schemes import (
    BaseAppEventMessagesResponse,
    BaseQueryResponse,
    BaseResponse,
)


class VehicleRnisStatus(StrEnum):
    NO_REGISTERED = "no_registered"
    NO_TERMINALS = "no_terminals"
    TELEMETRY_TRANSMITTED = "telemetry_transmitted"
    TELEMETRY_NOT_TRANSMITTED = "telemetry_not_transmitted"


class Vehicle(BaseResponse):
    vehicle_id: uuid.UUID
    reg_number: str
    is_registered: bool
    terminals_count: int
    last_transmission_at: datetime | None
    rnis_status: VehicleRnisStatus | None
    next_retry_at: datetime | None
    created_at: datetime
    updated_at: datetime


class VehicleResponse(Vehicle):
    """Ответ POST ``/vehicles``."""


class VehicleSyncResponse(BaseResponse):
    added: int
    deleted: int


class VehicleRetryAtResetResponse(BaseResponse):
    """Ответ POST ``/vehicles/retry-at/reset``."""

    updated: int


class Task(BaseResponse):
    task_id: uuid.UUID
    reg_number: str
    status: TaskStatus
    priority: int
    locked_at: datetime | None
    locked_by: str | None
    error_message: str | None
    found_terminal_count: int
    completed_at: datetime | None
    created_at: datetime
    updated_at: datetime


class TasksResponse(BaseQueryResponse[Task]):
    """Список задач с ``total``."""


class Terminal(BaseResponse):
    terminal_id: uuid.UUID
    vehicle_id: uuid.UUID
    bnso_number: str
    terminal_type: str
    origin_type: str
    terminal_key: str
    last_transmission_at: datetime | None
    created_at: datetime
    updated_at: datetime


class TerminalsResponse(RootModel[list[Terminal]]):
    """Полный список терминалов по ГРЗ — корень JSON-массив."""


class TaskAppEventType(StrEnum):
    STARTED = "started"
    PROCESSING = "processing"
    COMPLETED = "completed"
    ERROR = "error"


class TaskEventMessage(BaseAppEventMessage):
    """Один элемент ``messages`` в ответе GET ``/events/tasks``."""

    task_id: uuid.UUID = Field(description="Идентификатор задачи")


class TaskEventsResponse(BaseAppEventMessagesResponse[TaskEventMessage]):
    """Long-poll: ``messages`` + ``nextOffset``."""


__all__ = [
    "Account",
    "Task",
    "TaskAppEventType",
    "TaskEventMessage",
    "TaskEventsResponse",
    "TasksResponse",
    "Terminal",
    "TerminalsResponse",
    "Vehicle",
    "VehicleResponse",
    "VehicleRetryAtResetResponse",
    "VehicleRnisStatus",
    "VehicleSyncResponse",
]
