"""
Пример: POST ``/vehicles/retry-at/reset`` — немедленный retry для всех ТС сервиса.

Запуск::

  python -m tp_common.clients.bsp.mos_rnis.examples.reset_vehicles_retry_at
"""

from __future__ import annotations

from tp_common.clients.bsp.mos_rnis.client import BspMosRnisClient
from tp_common.clients.bsp.mos_rnis.examples._runner import main


async def _call(client: BspMosRnisClient) -> object:
    return await client.reset_vehicles_retry_at()


if __name__ == "__main__":
    main(_call)
