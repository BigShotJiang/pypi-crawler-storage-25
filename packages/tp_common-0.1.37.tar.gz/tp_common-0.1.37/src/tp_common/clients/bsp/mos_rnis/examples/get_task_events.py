"""
Пример: GET ``/events/tasks`` — long-poll событий задач.

Запуск::

  python -m tp_common.clients.bsp.mos_rnis.examples.get_task_events
"""

from __future__ import annotations

from tp_common.clients.bsp.mos_rnis.client import BspMosRnisClient
from tp_common.clients.bsp.mos_rnis.examples import demo_params
from tp_common.clients.bsp.mos_rnis.examples._runner import main
from tp_common.clients.bsp.mos_rnis.request import TaskEventsRequest


async def _call(client: BspMosRnisClient) -> object:
    return await client.get_task_events(
        TaskEventsRequest(
            offset=demo_params.TASK_EVENTS_OFFSET,
            limit=demo_params.TASK_EVENTS_LIMIT,
            timeout=demo_params.TASK_EVENTS_TIMEOUT,
        ),
        http_timeout=demo_params.TASK_EVENTS_HTTP_TIMEOUT,
    )


if __name__ == "__main__":
    main(_call)
