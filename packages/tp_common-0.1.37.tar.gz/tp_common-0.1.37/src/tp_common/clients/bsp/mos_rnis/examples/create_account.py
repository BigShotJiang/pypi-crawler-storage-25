"""
Пример: POST ``/accounts`` — создание аккаунта (прокси в bsp-mos-account).

Пароль только из окружения: ``MOS_RNIS_ACCOUNT_PASSWORD``.

Запуск::

  set MOS_RNIS_ACCOUNT_PASSWORD=secret
  python -m tp_common.clients.bsp.mos_rnis.examples.create_account
"""

from __future__ import annotations

from tp_common.clients.bsp.mos_rnis.client import BspMosRnisClient
from tp_common.clients.bsp.mos_rnis.examples import demo_params
from tp_common.clients.bsp.mos_rnis.examples._runner import main
from tp_common.clients.bsp.mos_rnis.request import AccountCreateRequest


async def _call(client: BspMosRnisClient) -> object:
    return await client.create_account(
        AccountCreateRequest(
            login=demo_params.ACCOUNT_LOGIN,
            password=demo_params.account_password(),
            proxy=demo_params.ACCOUNT_PROXY,
        )
    )


if __name__ == "__main__":
    main(_call)
