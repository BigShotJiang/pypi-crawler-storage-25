"""Примеры вызовов BspMosRnisClient."""
