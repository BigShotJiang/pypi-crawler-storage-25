"""Общий запуск примеров: клиент из окружения, JSON на stdout."""

from __future__ import annotations

import asyncio
import json
import sys
from collections.abc import Awaitable, Callable
from typing import Any

from tp_common.clients.bsp.mos_rnis.client import BspMosRnisClient
from tp_common.clients.bsp.mos_rnis.examples.create_client import create_mos_rnis_client


async def run_example(
    call: Callable[[BspMosRnisClient], Awaitable[Any]],
) -> None:
    try:
        client = create_mos_rnis_client()
    except ValueError as error:
        print(error, file=sys.stderr)
        raise SystemExit(2) from error

    async with client:
        result = await call(client)
        print(json.dumps(result.model_dump(mode="json"), indent=2, ensure_ascii=False))


def main(call: Callable[[BspMosRnisClient], Awaitable[Any]]) -> None:
    asyncio.run(run_example(call))
