"""
Пример: POST ``/vehicles`` — ТС и задача на загрузку.

Запуск::

  python -m tp_common.clients.bsp.mos_rnis.examples.ensure_vehicle
"""

from __future__ import annotations

from tp_common.clients.bsp.mos_rnis.client import BspMosRnisClient
from tp_common.clients.bsp.mos_rnis.examples import demo_params
from tp_common.clients.bsp.mos_rnis.examples._runner import main
from tp_common.clients.bsp.mos_rnis.request import VehicleCreateRequest


async def _call(client: BspMosRnisClient) -> object:
    return await client.ensure_vehicle(
        VehicleCreateRequest(reg_number=demo_params.REG_NUMBER)
    )


if __name__ == "__main__":
    main(_call)
