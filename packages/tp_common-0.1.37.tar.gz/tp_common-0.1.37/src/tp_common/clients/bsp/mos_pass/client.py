from __future__ import annotations

from tp_common.clients.bsp.base_ms_client import BaseMsClient
from tp_common.clients.bsp.mos_pass.request import (
    PassesRequest,
    TaskEventsRequest,
    TasksRequest,
    VehicleBulkCreateRequest,
    VehicleCreateRequest,
    VehicleRetryTaskUpdateRequest,
    VehicleSyncRequest,
)
from tp_common.clients.bsp.mos_pass.response import (
    PassesResponse,
    TaskEventsResponse,
    TasksResponse,
    Vehicle,
    VehicleResponse,
    VehicleRetryAtResetResponse,
    VehiclesResponse,
    VehicleSyncResponse,
)
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger


class MosPassClient(BaseMsClient):
    """Клиент bsp-mos-pass: пути и модели; Bearer и retry — в ``KeycloakClient``."""

    _service_name = "bsp-mos-pass"

    def __init__(
        self,
        *,
        keycloak_url: str | None = None,
        logger: TpLogger,
        mos_pass_url: str | None = None,
        keycloak_oauth: KeycloakOAuthClient | None = None,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 3,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        super().__init__(
            logger=logger,
            keycloak_url=keycloak_url,
            keycloak_oauth=keycloak_oauth,
            env_type=env_type,
            service_url=mos_pass_url,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    async def list_passes(self, request: PassesRequest) -> PassesResponse:
        return await self.get(
            uri="/passes",
            response_schema=PassesResponse,
            params=request,
        )

    async def list_tasks(self, request: TasksRequest) -> TasksResponse:
        return await self.get(
            uri="/tasks",
            response_schema=TasksResponse,
            params=request,
        )

    async def create_vehicle(self, request: VehicleCreateRequest) -> Vehicle:
        return await self.post(
            uri="/vehicles",
            response_schema=Vehicle,
            json=request.model_dump(mode="json"),
        )

    async def ensure_vehicle(self, request: VehicleCreateRequest) -> VehicleResponse:
        """POST /vehicles/ensure: ТС + задача или повышение приоритета активной задачи."""
        return await self.post(
            uri="/vehicles/ensure",
            response_schema=VehicleResponse,
            json=request.model_dump(mode="json"),
        )

    async def create_vehicles_bulk(
        self, request: VehicleBulkCreateRequest
    ) -> VehiclesResponse:
        return await self.post(
            uri="/vehicles/bulk",
            response_schema=VehiclesResponse,
            json=request.model_dump(mode="json"),
        )

    async def sync_vehicles(self, request: VehicleSyncRequest) -> VehicleSyncResponse:
        return await self.post(
            uri="/vehicles/sync",
            response_schema=VehicleSyncResponse,
            json=request.model_dump(mode="json"),
        )

    async def retry_vehicle_task(
        self, request: VehicleRetryTaskUpdateRequest
    ) -> VehicleResponse:
        return await self.patch(
            uri="/vehicles/retry-task",
            response_schema=VehicleResponse,
            json=request.model_dump(mode="json"),
        )

    async def reset_vehicles_retry_at(self) -> VehicleRetryAtResetResponse:
        """POST /vehicles/retry-at/reset: ``retry_at = now`` для всех ТС сервиса (планировщик ставит задачи)."""
        return await self.post(
            uri="/vehicles/retry-at/reset",
            response_schema=VehicleRetryAtResetResponse,
        )

    async def get_task_events(
        self,
        request: TaskEventsRequest,
        *,
        http_timeout: float = 120.0,
    ) -> TaskEventsResponse:
        """GET /events/tasks: ``service_id`` из Bearer (Keycloak), как у остальных методов.

        Ответ: ``messages`` и ``nextOffset`` (сервер). В следующем запросе передавайте
        ``TaskEventsRequest.offset`` = прошлый ``nextOffset`` (или без поля — со смещения группы).

        ``http_timeout`` — таймаут HTTP-клиента; ``request.timeout`` — long-poll на стороне API.
        """
        return await self.get(
            uri="/events/tasks",
            response_schema=TaskEventsResponse,
            params=request,
            timeout=http_timeout,
        )
