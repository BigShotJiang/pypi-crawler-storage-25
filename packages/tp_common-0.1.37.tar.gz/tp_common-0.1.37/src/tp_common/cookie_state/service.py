from __future__ import annotations

import json
from collections.abc import Iterable
from dataclasses import replace
from email.utils import formatdate
from http.cookies import BaseCookie, Morsel, SimpleCookie
from typing import Any

from aiohttp import CookieJar
from aiohttp.abc import AbstractCookieJar
from yarl import URL

from tp_common.cookie_state.schemes import UniversalCookie


class CookieMetadataRequiredError(ValueError):
    """У cookie нет domain — в CookieJar без подстановки host не кладём."""


# Имена кук, совпадающие с атрибутами Morsel (в т.ч. ``SameSite``), нельзя задать через ``SimpleCookie``.
_morsel_reserved_probe: Morsel = Morsel()


_SET_COOKIE_ATTRIBUTE_NAMES = frozenset(
    {
        "path",
        "domain",
        "samesite",
        "secure",
        "httponly",
        "expires",
        "max-age",
    }
)


def _http_cookie_name_reserved_for_simple_cookie(name: str) -> bool:
    return _morsel_reserved_probe.isReservedKey(name)


def is_request_cookie_name(name: str) -> bool:
    """Имя подходит для пары ``name=value`` в ``Cookie`` / ``ClientSession`` (не атрибут Set-Cookie)."""
    stripped = name.strip()
    if not stripped:
        return False
    if stripped.lower() in _SET_COOKIE_ATTRIBUTE_NAMES:
        return False
    return not _http_cookie_name_reserved_for_simple_cookie(stripped)


class CookieState:
    """
    Сервис состояния cookies: хранит ``list[UniversalCookie]`` и конвертацию
    между БД (``auth_sessions.cookies``), Playwright и aiohttp.

    Парсинг: ``from_browser_*``, ``from_db_string`` / ``from_db_json``, ``from_aiohttp_*``.
    Передавайте экземпляр в другие классы вместо отдельного списка кук.
    """

    __slots__ = ("_cookies",)

    def __init__(self, cookies: Iterable[UniversalCookie] | None = None) -> None:
        self._cookies: list[UniversalCookie] = list(cookies) if cookies else []

    @property
    def cookies(self) -> list[UniversalCookie]:
        return self._cookies

    def __len__(self) -> int:
        return len(self._cookies)

    def fork(self) -> CookieState:
        """Независимая копия (чтобы передать в другой сервис без общего списка)."""
        return CookieState(replace(c) for c in self._cookies)

    @classmethod
    def merge(cls, *states: CookieState) -> CookieState:
        """Объединить несколько состояний; при совпадении (name, domain, path) — последнее."""
        by_key: dict[tuple[str, str, str], UniversalCookie] = {}
        for state in states:
            for cookie in state._cookies:
                if not is_request_cookie_name(cookie.name):
                    continue
                domain = (cookie.domain or "").lstrip(".")
                if not domain:
                    continue
                path = cookie.path or "/"
                by_key[(cookie.name, domain, path)] = replace(cookie)
        result = cls(by_key.values())
        result._apply_same_site(result._cookies)
        return result

    def only_request_cookies(self) -> CookieState:
        """Без атрибутов Set-Cookie (``Path``, ``SameSite``, …) — только пары name=value."""
        return CookieState(c for c in self._cookies if is_request_cookie_name(c.name))

    @staticmethod
    def normalize_same_site(value: str | None) -> str | None:
        if not value:
            return None

        normalized = value.lower()

        if normalized == "lax":
            return "Lax"
        if normalized == "strict":
            return "Strict"
        if normalized == "none":
            return "None"
        return None

    def _apply_same_site(self, items: list[UniversalCookie]) -> None:
        for item in items:
            item.same_site = CookieState.normalize_same_site(item.same_site)

    @classmethod
    def from_browser_playwright(cls, raw: Iterable[Any]) -> CookieState:
        """Сырые куки Playwright (``context.cookies()``): dict или Cookie-объект."""
        result = cls(UniversalCookie.from_playwright_any(c) for c in raw)
        result._apply_same_site(result._cookies)
        return result

    @classmethod
    def from_browser_storage_state(cls, state: dict[str, Any]) -> CookieState:
        """Поле ``cookies`` из ``storage_state()`` Playwright."""
        return cls.from_browser_playwright(state.get("cookies", []))

    @classmethod
    def from_playwright_cookies(cls, raw: Iterable[Any]) -> CookieState:
        """Алиас :meth:`from_browser_playwright` для старого имени."""
        return cls.from_browser_playwright(raw)

    @classmethod
    def from_db_rows(cls, rows: list[dict[str, Any]]) -> CookieState:
        result = cls(UniversalCookie.from_db(row) for row in rows)
        result._apply_same_site(result._cookies)
        return result

    @classmethod
    def from_db_string(cls, raw: str | None) -> CookieState:
        """Строка из БД: JSON-массив объектов UniversalCookie (:meth:`to_db_json`)."""
        if not raw or not raw.strip():
            return cls()

        stripped = raw.strip()
        if not stripped.startswith("["):
            msg = (
                "cookies в БД должны быть JSON-массивом UniversalCookie "
                "(CookieState.to_db_json); строка Cookie-заголовка name=value не поддерживается"
            )
            raise ValueError(msg)

        rows = json.loads(stripped)
        if not isinstance(rows, list):
            msg = "cookies в БД должны быть JSON-массивом объектов"
            raise ValueError(msg)
        return cls.from_db_rows(rows)

    @classmethod
    def from_db_json(cls, raw: str | None) -> CookieState:
        """Алиас :meth:`from_db_string` (имя из комментариев к полю в БД)."""
        return cls.from_db_string(raw)

    @classmethod
    def from_aiohttp_jar(cls, jar: AbstractCookieJar) -> CookieState:
        """Все куки из ``aiohttp.CookieJar`` (или другого ``AbstractCookieJar``)."""
        result = cls(UniversalCookie.from_aiohttp_morsel(m) for m in jar)
        result._apply_same_site(result._cookies)
        return result

    @classmethod
    def from_aiohttp_simple_cookie(cls, simple: BaseCookie[str]) -> CookieState:
        """Например ``response.cookies`` после запроса ``aiohttp.ClientSession``."""
        items = [
            UniversalCookie.from_aiohttp_morsel(morsel)
            for _name, morsel in simple.items()
        ]
        state = cls(items)
        state._apply_same_site(state._cookies)
        return state

    def to_playwright_cookies(self) -> list[dict[str, Any]]:
        return [cookie.to_playwright() for cookie in self._cookies]

    def to_playwright_storage_state(
        self,
        origins: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        return {
            "cookies": self.to_playwright_cookies(),
            "origins": origins or [],
        }

    def to_db_rows(self) -> list[dict[str, Any]]:
        return [cookie.to_db() for cookie in self._cookies]

    def to_db_json(self) -> str:
        return json.dumps(self.to_db_rows(), ensure_ascii=False)

    def to_http_header_value(self) -> str:
        """Строка ``a=b; c=d`` только для заголовка Cookie (не для хранения в БД)."""
        return "; ".join(
            f"{c.name}={c.value}"
            for c in self._cookies
            if is_request_cookie_name(c.name)
        )

    def to_aiohttp_cookie_jar(self, *, unsafe: bool = True) -> CookieJar:
        """Jar только из сохранённых атрибутов; ``domain`` обязателен у каждой cookie."""
        jar = CookieJar(unsafe=unsafe)

        for cookie in self._cookies:
            if not is_request_cookie_name(cookie.name):
                continue

            domain = (cookie.domain or "").lstrip(".")
            if not domain:
                msg = f"cookie {cookie.name!r}: в БД должен быть domain (без подстановки host)"
                raise CookieMetadataRequiredError(msg)

            simple = SimpleCookie()
            simple[cookie.name] = cookie.value
            morsel = simple[cookie.name]
            morsel["domain"] = domain
            morsel["path"] = cookie.path or "/"
            if cookie.secure:
                morsel["secure"] = True
            if cookie.http_only:
                morsel["httponly"] = True
            if cookie.same_site:
                morsel["samesite"] = cookie.same_site
            if cookie.expires is not None:
                morsel["expires"] = formatdate(cookie.expires, usegmt=True)

            scheme = "https" if cookie.secure else "http"
            response_url = URL(f"{scheme}://{domain}{cookie.path or '/'}")

            jar.update_cookies(simple, response_url=response_url)

        return jar

    def save_playwright_storage_state_to_file(
        self,
        path: str,
        origins: list[dict[str, Any]] | None = None,
    ) -> None:
        with open(path, "w", encoding="utf-8") as file:
            json.dump(
                self.to_playwright_storage_state(origins),
                file,
                ensure_ascii=False,
                indent=2,
            )

    @classmethod
    def load_playwright_storage_state_from_file(cls, path: str) -> CookieState:
        with open(path, encoding="utf-8") as file:
            state = json.load(file)

        return cls.from_browser_storage_state(state)

    def save_db_json_to_file(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as file:
            file.write(self.to_db_json())

    @classmethod
    def load_db_json_from_file(cls, path: str) -> CookieState:
        with open(path, encoding="utf-8") as file:
            return cls.from_db_string(file.read())

    @classmethod
    def playwright_to_db_json(cls, raw: Iterable[Any]) -> str:
        """Playwright ``context.cookies()`` → строка для БД."""
        return cls.from_browser_playwright(raw).to_db_json()

    @classmethod
    def db_json_to_playwright(cls, raw: str | None) -> list[dict[str, Any]]:
        """Строка из БД → список словарей для ``context.add_cookies``."""
        return cls.from_db_string(raw).to_playwright_cookies()
