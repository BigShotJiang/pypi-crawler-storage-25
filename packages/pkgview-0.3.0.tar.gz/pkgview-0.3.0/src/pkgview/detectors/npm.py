from __future__ import annotations

import json
import subprocess
from typing import Dict

from pkgview.detectors.base import Detector
from pkgview.models import Package


class NpmDetector(Detector):
    @property
    def name(self) -> str:
        return "npm"

    def detect(self) -> Dict[str, Package]:
        packages: Dict[str, Package] = {}
        try:
            result = subprocess.run(
                ["npm", "list", "-g", "--depth=0", "--json"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            # npm exits non-zero when there are peer dep warnings; parse anyway.
            # Guard against an empty body (e.g. no global packages installed).
            if not result.stdout.strip():
                return {}
            data = json.loads(result.stdout)
            for pkg_name, info in data.get("dependencies", {}).items():
                version: str | None = info.get("version") if isinstance(info, dict) else None
                packages[pkg_name] = Package(
                    name=pkg_name,
                    manager="npm",
                    version=version,
                    category="cli",
                )
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError, ValueError, OSError):
            pass
        return packages

    def check_outdated(self, packages: Dict[str, Package]) -> None:
        """Uses ``npm outdated -g --json`` to find globally outdated packages."""
        try:
            result = subprocess.run(
                ["npm", "outdated", "-g", "--json"],
                capture_output=True,
                text=True,
                timeout=60,
            )
            # npm outdated exits 1 when there are outdated packages — that's OK
            if not result.stdout.strip():
                return
            data = json.loads(result.stdout)
            for name, info in data.items():
                if not isinstance(info, dict):
                    continue
                latest = info.get("latest") or info.get("wanted")
                if name in packages and latest:
                    packages[name].outdated = True
                    packages[name].latest_version = latest
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError, OSError):
            pass
