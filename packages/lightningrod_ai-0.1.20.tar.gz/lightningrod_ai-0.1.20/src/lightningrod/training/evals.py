from __future__ import annotations

from lightningrod._display import _is_notebook, display_error, run_eval_live_display
from lightningrod._generated.api.evaluations import (
    create_eval_job_evaluations_post,
    get_eval_job_evaluations_eval_id_get,
    list_eval_jobs_evaluations_get,
)
from lightningrod._generated.client import AuthenticatedClient
from lightningrod._generated.models import EvalModel, SampleDatasetConfig
from lightningrod._generated.models.create_eval_job_request import CreateEvalJobRequest
from lightningrod._generated.models.eval_job import EvalJob
from lightningrod._generated.models.eval_job_list_response import EvalJobListResponse
from lightningrod._generated.models.training_job_status import TrainingJobStatus
from lightningrod._generated.types import UNSET, Unset
from lightningrod._errors import handle_response_error
from lightningrod.training.client import sample_dataset_to_config
from lightningrod.datasets.dataset import SampleDataset

class EvalsClient:
    def __init__(self, client: AuthenticatedClient):
        self._client = client

    def create(
        self,
        dataset: "SampleDataset",
        models: list[EvalModel],
    ) -> EvalJob:
        dataset_config = sample_dataset_to_config(dataset)
        body = CreateEvalJobRequest(
            models=models,
            dataset=dataset_config,
        )
        response = create_eval_job_evaluations_post.sync_detailed(
            client=self._client,
            body=body,
        )
        return handle_response_error(response, "create eval job")

    def get(self, eval_id: str) -> EvalJob:
        response = get_eval_job_evaluations_eval_id_get.sync_detailed(
            eval_id=eval_id,
            client=self._client,
        )
        return handle_response_error(response, "get eval job")

    def list(
        self,
        *,
        page: int = 1,
        limit: int = 10,
    ) -> EvalJobListResponse:
        response = list_eval_jobs_evaluations_get.sync_detailed(
            client=self._client,
            page=page,
            limit=limit,
        )
        return handle_response_error(response, "list eval jobs")

    def run(
        self,
        models: list[EvalModel],
        dataset: "SampleDataset",
    ) -> EvalJob:
        job = self.create(models=models, dataset=dataset)

        if job.status == TrainingJobStatus.FAILED:
            error_msg = (
                job.error_message
                if not isinstance(job.error_message, Unset) and job.error_message
                else "Unknown error"
            )
            display_error(error_msg, title="Eval Failed", job=job)
            if not _is_notebook():
                raise Exception(f"Eval job {job.id} failed: {error_msg}")

        def poll() -> EvalJob:
            nonlocal job
            job = self.get(job.id)
            return job

        run_eval_live_display(poll, initial_job=job)
        return job
