# -------------------------------------------------------------------------
# Copyright (c) Switch Automation Pty Ltd. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------
"""
A module for sending control request of sensors.
"""

__all__ = ['submit_control', 'submit_control_continue', 'add_control_component']

from .controls import submit_control, submit_control_continue, add_control_component
