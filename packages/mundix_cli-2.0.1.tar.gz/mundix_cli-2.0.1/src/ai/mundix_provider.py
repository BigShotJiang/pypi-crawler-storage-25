"""
MundiX CLI - MundiX AI Provider

Connects to the MundiX backend API for AI inference.
Handles authentication, billing, and session management.
"""

import json
import os
import time
from typing import AsyncIterator, Dict, List, Optional, Any

import requests
import aiohttp

from src.ai.base import AIProvider, ChatMessage, ChatResponse, ModelInfo, ModelTier
from src.core.logging import get_logger

logger = get_logger("ai.mundix")


class MundiXAIProvider(AIProvider):
    """
    AI Provider for the MundiX backend.
    
    Handles communication with the MundiX API including:
    - Authentication with API key
    - Model selection and fallback
    - Session management
    - Credit tracking
    """
    
    def __init__(
        self,
        backend_url: str = "https://chat.mundix.dev/api",
        api_key: str = "",
        default_model: str = "mx-deephat-7b",
    ):
        self.backend_url = backend_url.rstrip("/")
        self.api_key = api_key
        self._default_model = default_model
        self._session: Optional[aiohttp.ClientSession] = None
        self._models_cache: Optional[List[ModelInfo]] = None
        self._credits_remaining: int = 0
        self._initialized = False
    
    @property
    def name(self) -> str:
        return "MundiX AI"
    
    async def initialize(self) -> bool:
        """Initialize the provider and verify API key."""
        try:
            self._session = aiohttp.ClientSession()
            
            # Verify API key and get credits
            if self.api_key:
                await self._verify_key()
            
            self._initialized = True
            logger.info(f"MundiX AI Provider initialized (model: {self._default_model})")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize MundiX AI Provider: {e}")
            return False
    
    async def shutdown(self):
        """Clean up resources."""
        if self._session:
            await self._session.close()
            self._session = None
        self._initialized = False
    
    async def chat(
        self,
        messages: List[ChatMessage],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs
    ) -> ChatResponse:
        """Send messages and get a complete response."""
        if stream:
            # For streaming, use stream method instead
            full_response = ""
            async for token in self.stream(messages, model, temperature, max_tokens, **kwargs):
                full_response += token
            return ChatResponse(
                content=full_response,
                model_used=model or self._default_model,
            )
        
        # Non-streaming request
        url = f"{self.backend_url}/chat"
        headers = self._get_headers()
        
        payload = {
            "messages": [self._message_to_dict(m) for m in messages],
            "model": model or self._default_model,
            "temperature": temperature,
            "stream": False,
        }
        if max_tokens:
            payload["max_tokens"] = max_tokens
        payload.update(kwargs)
        
        try:
            async with self._session.post(url, json=payload, headers=headers) as resp:
                if resp.status == 401:
                    raise PermissionError("Invalid API key. Please check your configuration.")
                elif resp.status == 429:
                    raise PermissionError("Rate limit exceeded. Please wait before making another request.")
                elif resp.status == 402:
                    raise PermissionError("No credits remaining. Please purchase more credits.")
                elif resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"API error {resp.status}: {error_text}")
                
                data = await resp.json()
                
                return ChatResponse(
                    content=data.get("content", data.get("message", "")),
                    model_used=data.get("model", model or self._default_model),
                    tokens_used=data.get("tokens_used", 0),
                    finish_reason=data.get("finish_reason", "stop"),
                    metadata=data.get("metadata", {}),
                )
        except aiohttp.ClientError as e:
            raise RuntimeError(f"Network error: {e}")
    
    async def stream(
        self,
        messages: List[ChatMessage],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> AsyncIterator[str]:
        """Stream response tokens as they are generated."""
        url = f"{self.backend_url}/chat"
        headers = self._get_headers()
        
        payload = {
            "messages": [self._message_to_dict(m) for m in messages],
            "model": model or self._default_model,
            "temperature": temperature,
            "stream": True,
        }
        if max_tokens:
            payload["max_tokens"] = max_tokens
        payload.update(kwargs)
        
        try:
            async with self._session.post(url, json=payload, headers=headers) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"API error {resp.status}: {error_text}")
                
                async for line in resp.content:
                    line = line.decode("utf-8").strip()
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data)
                            token = chunk.get("choices", [{}])[0].get("delta", {}).get("content", "")
                            if token:
                                yield token
                        except json.JSONDecodeError:
                            continue
        except aiohttp.ClientError as e:
            raise RuntimeError(f"Network error: {e}")
    
    async def get_models(self) -> List[ModelInfo]:
        """List available models."""
        if self._models_cache:
            return self._models_cache
        
        # Default model registry
        self._models_cache = [
            ModelInfo(
                id="mx-strategist-72b",
                name="MX-Strategist 72B",
                description="Strategic planner — pentest orchestration & deep analysis",
                context_length=131072,
                tier=ModelTier.BRAIN,
            ),
            ModelInfo(
                id="mx-deephat-7b",
                name="MX-DeepHat 7B",
                description="Offensive specialist — exploit generation & attack chains",
                context_length=131072,
                tier=ModelTier.SPECIALIST,
            ),
            ModelInfo(
                id="mx-swift-3b",
                name="MX-Swift 3B",
                description="Fast executor — parsing, formatting & quick decisions",
                context_length=32768,
                tier=ModelTier.EXECUTOR,
            ),
            ModelInfo(
                id="mx-minitron-8b",
                name="MX-Minitron 8B",
                description="Backup model — reliable fallback",
                context_length=8192,
                tier=ModelTier.BACKUP,
            ),
        ]
        return self._models_cache
    
    async def get_default_model(self) -> str:
        """Get the default model ID."""
        return self._default_model
    
    async def is_available(self) -> bool:
        """Check if the provider is available."""
        if not self._initialized:
            return False
        try:
            async with self._session.get(f"{self.backend_url}/health", timeout=aiohttp.ClientTimeout(total=5)) as resp:
                return resp.status == 200
        except Exception:
            return False
    
    async def get_usage_stats(self) -> Dict[str, Any]:
        """Get usage statistics."""
        return {
            "credits_remaining": self._credits_remaining,
            "model": self._default_model,
            "backend": self.backend_url,
        }
    
    async def _verify_key(self):
        """Verify API key and get account info."""
        try:
            async with self._session.get(
                f"{self.backend_url}/auth/verify",
                headers=self._get_headers(),
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    self._credits_remaining = data.get("credits", 0)
                elif resp.status == 401:
                    logger.warning("Invalid API key")
        except Exception as e:
            logger.warning(f"Could not verify API key: {e}")
    
    def _get_headers(self) -> Dict[str, str]:
        """Get request headers with authentication."""
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "MundiX-CLI/2.0",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers
    
    @staticmethod
    def _message_to_dict(message: ChatMessage) -> Dict[str, str]:
        """Convert ChatMessage to API format."""
        return {
            "role": message.role,
            "content": message.content,
        }
