"""
MundiX CLI - Core Engine

The main orchestrator that ties all modules together:
- AI Provider management
- Session management
- Skill execution
- Memory integration
- System execution
"""

import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, AsyncIterator, Callable, Dict, List, Optional

from src.ai.base import AIProvider, ChatMessage, ChatResponse
from src.core.config import MundiXConfig, get_config
from src.core.logging import get_logger, timer
from src.core.session import SessionContext, SessionManager
from src.memory.base import MemoryBackend, MemoryEntry, MemoryType
from src.skills.models import Skill, SkillResult, SkillStatus
from src.system.executor import CommandExecutor, ExecutionResult
from src.system.safety import SafetyChecker, RiskLevel

logger = get_logger("core.engine")


@dataclass
class EngineState:
    """Current state of the MundiX engine."""
    is_running: bool = False
    is_processing: bool = False
    current_operation: str = ""
    last_error: Optional[str] = None
    started_at: Optional[datetime] = None
    commands_executed: int = 0
    skills_executed: int = 0


class MundiXEngine:
    """
    Core engine that orchestrates all MundiX components.
    
    This is the main entry point for:
    - Processing user queries
    - Executing skills
    - Managing sessions
    - Integrating AI, memory, and system execution
    """
    
    def __init__(
        self,
        ai_provider: Optional[AIProvider] = None,
        memory_backend: Optional[MemoryBackend] = None,
        config: Optional[MundiXConfig] = None,
    ):
        self.config = config or get_config()
        self.ai_provider = ai_provider
        self.memory = memory_backend
        self.session_manager = SessionManager()
        self.executor = CommandExecutor(
            default_timeout=self.config.command_timeout,
            max_output_lines=self.config.max_output_lines,
        )
        self.safety_checker = SafetyChecker()
        self.state = EngineState()
        
        # Callbacks
        self.on_command_output: Optional[Callable[[str], None]] = None
        self.on_skill_complete: Optional[Callable[[SkillResult], None]] = None
        self.on_error: Optional[Callable[[str], None]] = None
    
    async def initialize(self) -> bool:
        """
        Initialize all engine components.
        
        Returns:
            True if initialization was successful
        """
        logger.info("Initializing MundiX Engine...")
        
        try:
            # Initialize AI provider
            if self.ai_provider:
                success = await self.ai_provider.initialize()
                if not success:
                    logger.warning("AI provider initialization failed")
            
            # Initialize memory
            if self.memory:
                await self.memory.initialize()
                logger.info("Memory backend initialized")
            
            # Create initial session
            self.session_manager.create_session()
            logger.info("Session created")
            
            self.state.is_running = True
            self.state.started_at = datetime.now()
            logger.info("MundiX Engine initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Engine initialization failed: {e}")
            self.state.last_error = str(e)
            return False
    
    async def shutdown(self):
        """Shutdown all engine components."""
        logger.info("Shutting down MundiX Engine...")
        self.state.is_running = False
        
        if self.ai_provider:
            await self.ai_provider.shutdown()
        
        await self.executor.cleanup()
        
        self.session_manager.end_session()
        logger.info("MundiX Engine shut down")
    
    async def process_query(
        self,
        query: str,
        stream: bool = False,
    ) -> AsyncIterator[str]:
        """
        Process a user query through the AI provider.
        
        Args:
            query: User's question or command
            stream: If True, yield tokens as they arrive
        
        Yields:
            Response text chunks (if stream=True)
        
        Returns:
            Full response (if stream=False, via final yield)
        """
        if not self.state.is_running:
            raise RuntimeError("Engine is not running. Call initialize() first.")
        
        self.state.is_processing = True
        self.state.current_operation = f"Processing: {query[:50]}..."
        
        try:
            # Store query in memory
            if self.memory:
                await self.memory.store(MemoryEntry(
                    type=MemoryType.QUERY,
                    query=query,
                ))
            
            # Build messages with context
            messages = self._build_messages(query)
            
            # Get AI response
            if self.ai_provider:
                if stream:
                    full_response = ""
                    async for token in self.ai_provider.stream(messages):
                        full_response += token
                        yield token
                    
                    # Store response
                    if self.memory:
                        await self.memory.store(MemoryEntry(
                            type=MemoryType.QUERY,
                            query=query,
                            response=full_response,
                        ))
                else:
                    response = await self.ai_provider.chat(messages)
                    yield response.content
                    
                    # Store response
                    if self.memory:
                        await self.memory.store(MemoryEntry(
                            type=MemoryType.QUERY,
                            query=query,
                            response=response.content,
                        ))
            
            # Add to chat history
            self.session_manager.add_message("user", query)
            
        except Exception as e:
            error_msg = f"Query processing failed: {e}"
            logger.error(error_msg)
            self.state.last_error = error_msg
            if self.on_error:
                self.on_error(error_msg)
            yield f"❌ Error: {e}"
        
        finally:
            self.state.is_processing = False
            self.state.current_operation = ""
    
    async def execute_command(
        self,
        command: str,
        auto_confirm: bool = False,
    ) -> ExecutionResult:
        """
        Execute a shell command with safety checks.
        
        Args:
            command: Shell command to execute
            auto_confirm: Skip safety confirmation
        
        Returns:
            ExecutionResult with output and status
        """
        # Safety check
        safety = self.safety_checker.check(command)
        
        if safety.blocked and not auto_confirm:
            logger.warning(f"Command blocked by safety: {command}")
            return ExecutionResult(
                command=command,
                stdout="",
                stderr=f"Command blocked: {', '.join(safety.warnings)}",
                exit_code=-1,
                duration=0,
            )
        
        # Execute with timing
        async with timer(logger, f"exec:{command[:30]}", {"command": command}):
            result = await self.executor.execute(command)
        
        # Update state
        self.state.commands_executed += 1
        
        # Store in memory
        if self.memory:
            await self.memory.store(MemoryEntry(
                type=MemoryType.COMMAND,
                content=command,
                metadata={
                    "exit_code": result.exit_code,
                    "duration": result.duration,
                    "output_lines": len(result.stdout.splitlines()),
                },
            ))
        
        # Notify callback
        if self.on_command_output and result.stdout:
            self.on_command_output(result.stdout)
        
        return result
    
    def _build_messages(self, query: str) -> List[ChatMessage]:
        """Build message list with system prompt and context."""
        from src.ai.prompts.system import SYSTEM_PROMPT
        
        messages = [
            ChatMessage(role="system", content=SYSTEM_PROMPT),
        ]
        
        # Add session context
        session = self.session_manager.get_session()
        if session:
            context_info = session.to_context_string()
            messages.append(ChatMessage(
                role="system",
                content=f"Current session context: {context_info}",
            ))
        
        # Add recent chat history for context
        history = self.session_manager.get_chat_history(max_messages=10)
        messages.extend(history)
        
        # Add current query
        messages.append(ChatMessage(role="user", content=query))
        
        return messages
