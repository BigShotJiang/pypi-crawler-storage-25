import time
import pytest
import ray

from deisa.ray.types import DeisaArray
from tests.utils import ray_cluster, simple_worker, wait_for_head_node, pick_free_port  # noqa: F401

NB_ITERATIONS = 5


@ray.remote(max_retries=0)
def head_script(enable_distributed_scheduling, nb_nodes) -> None:
    """The head node checks that the values are correct"""
    from deisa.ray.window_handler import Deisa
    from deisa.ray.types import WindowSpec
    import deisa.ray as deisa

    deisa.config.enable_experimental_distributed_scheduling(enable_distributed_scheduling)

    d = Deisa(max_simulation_ahead=2)

    def simulation_callback(array: list[DeisaArray]):
        if array[0].t == 0:
            # NOTE : With the way the current version of deisa handle sim go ahead,
            # sim can send 2 iterations before getting stuck waiting for analytics
            time.sleep(10)
        x = array[0].dask.sum().compute()
        assert x == 10 * array[0].t

    d.register_callback(
        simulation_callback,
        [WindowSpec("array")],
    )
    d.execute_callbacks()


@pytest.mark.parametrize(
    "nb_nodes, enable_distributed_scheduling",
    [
        (4, True),
        (4, False),
    ],
)
def test_sim_going_ahead(nb_nodes: int, enable_distributed_scheduling: bool, ray_cluster) -> None:  # noqa: F811
    #
    # This test is only checking that despite simulation continue sending arrays
    # and at some point get stuck until analytics continue, the workflow is still working
    #
    head_ref = head_script.remote(enable_distributed_scheduling, nb_nodes)
    wait_for_head_node()
    port = pick_free_port()

    worker_refs = []
    for rank in range(4):
        worker_refs.append(
            simple_worker.remote(
                rank=rank,
                position=(rank // 2, rank % 2),
                chunks_per_dim=(2, 2),
                nb_chunks_of_node=4 // nb_nodes,
                chunk_size=(1, 1),
                nb_iterations=NB_ITERATIONS,
                node_id=f"node_{rank % nb_nodes}",
                nb_nodes=nb_nodes,
                port=port,
            )
        )

    ray.get([head_ref] + worker_refs)
