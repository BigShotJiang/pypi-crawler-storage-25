# LEAF UI Refactoring Plan

**Created:** December 4, 2025  
**Status:** ✅ Completed

This document tracks the identified issues and refactoring tasks for the `leaf-ui` React application.

---

## Overview

A comprehensive audit of the leaf-ui codebase revealed several architecture problems, code smells, and technical debt that need to be addressed to improve maintainability, type safety, and developer experience.

---

## Task List

### 🔴 Critical Priority

- [x] **1. Fix wrong export name in DefaultSwitchComponent**
  - **File:** `src/components/SidebarComponent/DisplayDataComponents/controls/switch/DefaultSwitchComponent.tsx`
  - **Issue:** Component exports `DefaultNumberComponent` instead of `DefaultSwitchComponent`
  - **Resolution:** Renamed export to match component name

- [x] **2. Create centralized config for environment variables**
  - **Issue:** `BACKEND_URL`, `KEYCLOAK_URL`, `GRAFANA_URL` defined in multiple files with duplicate fallbacks
  - **Resolution:** Created `src/config/index.ts` with validated env var exports

- [x] **3. Create centralized API client**
  - **Issue:** Fetch calls scattered across files with inconsistent error handling
  - **Resolution:** Created `src/api/client.ts` with base configuration, typed responses, and `ApiError` class

- [x] **4. Fix type safety - replace 'any' types**
  - **Files affected:** `App.tsx`, `PreferenceModal.tsx`, `InputComponent.tsx`, `OutputComponent.tsx`
  - **Resolution:** Created `src/store/hooks.ts` with `useAppSelector` and `useAppDispatch`, updated all components

- [x] **12. Fix silent fallback data in API error handling**
  - **File:** `src/api/markersApi.ts`
  - **Issue:** On fetch error, returns hardcoded fake markers - users see fake data with no indication
  - **Resolution:** Now uses `rejectWithValue` to properly propagate errors

---

### 🟠 Major Priority

- [x] **5. Extract shared hooks**
  - **Hooks created:**
    - `src/hooks/useDebounce.ts` - `useDebounce` and `useDebouncedCallback`
    - `src/hooks/useClickOutside.ts` - `useClickOutside`
  - **Location:** `src/hooks/`

- [x] **6. Extract shared utilities**
  - **Utilities created:**
    - `src/utils/formatters.ts` - `formatLabel()` (formerly `makePretty`)
    - `src/utils/toast.ts` - `showSuccessToast()`, `showErrorToast()`, etc.
  - **Location:** `src/utils/`

- [x] **7. Refactor MapComponent - extract sub-components**
  - **File:** `src/components/MapComponent/MapComponent.tsx` (reduced from 200+ lines to ~60 lines)
  - **New files created:**
    - `MapLayers.tsx` - Handles tile layers, satellite view, and marker clusters
    - `MapEventHandler.tsx` - Handles click and double-click events
    - `useMarkerPolling.ts` - Custom hook for marker data fetching

---

### 🟡 Moderate Priority

- [x] **8. Add CSS variables for theming**
  - **Resolution:** Added comprehensive CSS variables in `src/index.css` including colors, shadows, spacing, z-index scale, and transitions

- [x] **9. Fix CSS typo and consolidate duplicate styles**
  - **Issues fixed:**
    - Typo: `border-bottom: qpx solid #ccc` → `border-bottom: 1px solid #ccc` in `LeafDropMenu.css`
    - Updated all components to use CSS variables for consistent theming

- [x] **10. Remove console.logs and unused code**
  - **Removed:**
    - Debug `console.log` statements from `SidebarComponent.tsx`, `SettingsMenu.tsx`
    - CRA boilerplate in `App.css`
    - Unused `logo.svg` file

- [x] **11. Remove duplicate ToastContainer**
  - **Issue:** `ToastContainer` was in both `App.tsx` AND `MapComponent.tsx`
  - **Resolution:** Removed from `MapComponent.tsx`, kept only in `App.tsx`

---

## New File Structure

```
src/
├── api/
│   ├── client.ts          # ✅ NEW: Centralized fetch client with ApiError
│   ├── markersApi.ts      # ✅ Refactored: uses client, proper error handling
│   ├── outputApi.ts       # ✅ Refactored: typed DeviceCommand interface
│   └── keycloak.ts        # ✅ Updated: uses config
├── config/
│   └── index.ts           # ✅ NEW: Environment config with validation
├── hooks/
│   ├── index.ts           # ✅ NEW: Re-exports
│   ├── useDebounce.ts     # ✅ NEW: useDebounce, useDebouncedCallback
│   └── useClickOutside.ts # ✅ NEW: Click outside detection
├── utils/
│   ├── index.ts           # ✅ NEW: Re-exports
│   ├── formatters.ts      # ✅ NEW: formatLabel (formerly makePretty)
│   └── toast.ts           # ✅ NEW: Toast notification helpers
├── components/
│   ├── MapComponent/
│   │   ├── MapComponent.tsx    # ✅ Simplified to ~60 lines
│   │   ├── MapLayers.tsx       # ✅ NEW: Extracted layer management
│   │   ├── MapEventHandler.tsx # ✅ NEW: Extracted event handling
│   │   └── useMarkerPolling.ts # ✅ NEW: Extracted data fetching
│   └── ...
├── store/
│   ├── index.ts           # ✅ Updated: re-exports hooks
│   ├── hooks.ts           # ✅ NEW: Typed useAppSelector/useAppDispatch
│   ├── markersSlice.ts
│   └── uiSlice.ts
└── types/
    └── marker.ts
```

---

## Progress Log

| Date | Task # | Status | Notes |
|------|--------|--------|-------|
| Dec 4, 2025 | 1 | ✅ | Fixed wrong export name |
| Dec 4, 2025 | 2 | ✅ | Created centralized config |
| Dec 4, 2025 | 3 | ✅ | Created API client with proper error handling |
| Dec 4, 2025 | 4 | ✅ | Fixed all `any` types with typed hooks |
| Dec 4, 2025 | 5 | ✅ | Extracted useDebounce, useClickOutside hooks |
| Dec 4, 2025 | 6 | ✅ | Extracted formatLabel, toast utilities |
| Dec 4, 2025 | 7 | ✅ | Refactored MapComponent into smaller files |
| Dec 4, 2025 | 8 | ✅ | Added comprehensive CSS variables |
| Dec 4, 2025 | 9 | ✅ | Fixed CSS typo, consolidated styles |
| Dec 4, 2025 | 10 | ✅ | Removed console.logs and unused code |
| Dec 4, 2025 | 11 | ✅ | Removed duplicate ToastContainer |
| Dec 4, 2025 | 12 | ✅ | Fixed silent fallback data issue |

---

## Future Considerations

- ✅ **Server-Sent Events (SSE)**: ~~Replace the 2-second polling for markers with SSE for real-time updates.~~ **COMPLETED** - Implemented in `ab58a1e`. The backend now provides `/api/sensor-data/stream` endpoint with debounced batch updates.
- **React Query Migration:** Consider migrating from Redux thunks to React Query for server state (the dependency is already installed but unused)
- **Stricter Marker Types:** The `Marker` type still uses `[key: string]: any` escape hatches - consider defining specific metric types
- **Test Coverage:** Add unit tests for the new hooks and utilities
- **Accessibility:** Add ARIA labels and keyboard navigation for custom dropdowns
- **Unit Preferences:** Consider moving `DEFAULT_PREFERRED_UNITS` to a centralized config or making it admin-configurable
