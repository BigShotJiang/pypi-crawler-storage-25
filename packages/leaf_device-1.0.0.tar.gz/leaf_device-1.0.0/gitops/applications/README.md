# LEAF GitOps Applications

This directory contains ArgoCD Application manifests for deploying LEAF to the mapster-nomad Kubernetes cluster.

## Applications

| File | Environment | Branch | Domain | Namespace |
|------|-------------|--------|--------|-----------|
| `leaf.yaml` | Development | develop | leaf.ornl.gov | leaf |

## Deployment Flow

1. **Push to develop branch** → GitLab CI builds container images → ECR
2. **ArgoCD auto-sync** → Deploys to Kubernetes using Helm chart
3. **Auto-heal** → ArgoCD watches for drift and corrects

## Usage

### Apply to ArgoCD (one-time setup)
```bash
kubectl apply -f gitops/applications/leaf.yaml
```

### Manual sync
```bash
argocd app sync leaf
```

### Check status
```bash
argocd app get leaf
kubectl get pods -n leaf
```

## Image Tags

- **develop branch**: Tags images as `develop` and `latest`

ArgoCD is configured to use the `develop` tag.
