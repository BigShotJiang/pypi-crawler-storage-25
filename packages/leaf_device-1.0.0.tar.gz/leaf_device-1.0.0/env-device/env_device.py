import time
import random
import math
import json
import yaml
import paho.mqtt.client as mqtt

BROKER = "mqtt-broker"
PORT = 1883

# Load sensor configurations from YAML file
with open("devices.yml", "r") as file:
    config = yaml.safe_load(file)

# MQTT Topics
def get_topic(sensor_uuid, data_type):
    return f"iot/environmental/{sensor_uuid}/{data_type}"

# Function to generate random starting points within the defined radius
def generate_random_start_point(center_lat, center_lon, radius_km):
    radius_m = radius_km * 1000
    angle = random.uniform(0, 2 * math.pi)
    distance = random.uniform(0, radius_m)

    delta_lat = (distance / 111139) * math.cos(angle)
    delta_lon = (distance / (111139 * math.cos(math.radians(center_lat)))) * math.sin(angle)

    start_lat = center_lat + delta_lat
    start_lon = center_lon + delta_lon

    return start_lat, start_lon

# Callback function on connection
def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))

# Callback function on publish
def on_publish(client, userdata, mid):
    print(f"Message {mid} published.")

# Create an MQTT client instance
client = mqtt.Client()

# Assign the callback functions
client.on_connect = on_connect
client.on_publish = on_publish

# Connect to the broker with retries
while True:
    try:
        print("Attempting to connect to MQTT broker...")
        client.connect(BROKER, PORT, 60)
        break
    except ConnectionRefusedError:
        print("Connection refused, retrying in 5 seconds...")
        time.sleep(5)

# Start the loop
client.loop_start()

# Initialize sensor states
sensors = []
for sensor_conf in config["sensors"]:
    start_lat, start_lon = generate_random_start_point(
        sensor_conf["latitude"], sensor_conf["longitude"], sensor_conf["radius_km"]
    )
    sensors.append({
        "uuid": sensor_conf["uuid"],
        "make": sensor_conf.get("make", "Unknown"),
        "model": sensor_conf.get("model", "Unknown"),
        "center_lat": sensor_conf["latitude"],
        "center_lon": sensor_conf["longitude"],
        "radius_km": sensor_conf["radius_km"],
        "latitude": start_lat,
        "longitude": start_lon,
        "radiation_sensitivity": sensor_conf["radiation_sensitivity"],
        "temperature_range": sensor_conf["temperature_range"],
        "humidity_range": sensor_conf["humidity_range"],
        "status": sensor_conf.get("status", "Unknown")
    })

def generate_environmental_data(sensor):
    # Generate random environmental data
    temperature = random.uniform(sensor["temperature_range"][0], sensor["temperature_range"][1])
    humidity = random.uniform(sensor["humidity_range"][0], sensor["humidity_range"][1])
    radiation = sensor["radiation_sensitivity"] * random.uniform(0.5, 1.5)
    
    return {
        "temperature": temperature,
        "humidity": humidity,
        "radiation": radiation
    }

def update_sensor_data():
    for sensor in sensors:
        # Update environmental data
        env_data = generate_environmental_data(sensor)

        # Construct the payload
        payload = {
            "id": {
                "unique_id": sensor["uuid"],
                "make": sensor["make"],
                "model": sensor["model"]
            },
            "gps_location": {
                "latitude": sensor["latitude"],
                "longitude": sensor["longitude"]
            },
            "environmental_data": env_data,
            "status": sensor["status"]
        }

        # Define the topic
        topic = f"iot/environmental/{sensor['uuid']}"

        # Publish the message
        client.publish(topic, json.dumps(payload))
        print(f"Published to {topic}: {payload}")

# Run the update loop
try:
    while True:
        update_sensor_data()
        time.sleep(1)
except KeyboardInterrupt:
    print("Simulation stopped.")

client.loop_stop()
client.disconnect()