const protobuf = require("protobufjs");

// Cache for loaded protobuf roots to avoid reloading
const protoCache = {};

async function loadProto(deviceType) {
  if (!protoCache[deviceType]) {
    // Store the promise in the cache immediately to avoid duplicate loads
    protoCache[deviceType] = new protobuf.Root().load(`./protos/${deviceType}.proto`, { keepCase: true })
      .then(root => {
        return root; // Resolve with the root on successful load
      })
      .catch(error => {
        console.error(`Error loading proto file for device type ${deviceType}:`, error);
        delete protoCache[deviceType]; // Remove the failed promise from the cache
        throw error;  // Rethrow or handle error appropriately
      });
  }

  return protoCache[deviceType];
}

module.exports = { loadProto };