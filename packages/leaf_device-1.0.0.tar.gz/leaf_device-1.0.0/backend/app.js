const mqtt = require('mqtt');
const jwt = require('jsonwebtoken');
const jwksRsa = require('jwks-rsa');
const protobuf = require('protobufjs');
const promClient = require('prom-client');
const express = require('express');
const app = express();
const cors = require('cors');
const EventEmitter = require('events');

// Creating a registry to register the metrics
const register = new promClient.Registry();

// SSE Configuration
const SSE_DEBOUNCE_MS = parseInt(process.env.SSE_DEBOUNCE_MS || '500', 10);
const SSE_HEARTBEAT_MS = parseInt(process.env.SSE_HEARTBEAT_MS || '30000', 10);

// Auth & Namespace Configuration
const KEYCLOAK_URL = process.env.KEYCLOAK_URL || 'https://auth.uvdl.ornl.gov';
const KEYCLOAK_REALM = process.env.KEYCLOAK_REALM || 'leaf';
const PUBLIC_NAMESPACES = (process.env.PUBLIC_NAMESPACES || 'sim').split(',').map(s => s.trim());
// Set AUTH_DISABLED=true in local dev to skip JWT validation when Keycloak is unreachable
const AUTH_DISABLED = process.env.AUTH_DISABLED === 'true';

// Event emitter for sensor data updates
const sensorEvents = new EventEmitter();
sensorEvents.setMaxListeners(100); // Allow up to 100 concurrent SSE clients

// Track pending updates for debouncing (per-device)
let pendingUpdates = {};
let debounceTimer = null;

let gauges = {};
let sensorDataCache = {};  // Cache to store the latest sensor data

function ensureGaugeExists(metricName) {
    if (!gauges[metricName]) {
        gauges[metricName] = new promClient.Gauge({
            name: metricName,
            help: `Dynamic gauge for ${metricName}`,
            labelNames: ['device_id', 'namespace']
        });
        register.registerMetric(gauges[metricName]);
    }
}

const dataMessageCounter = new promClient.Counter({
    name: 'data_message_count',
    help: 'Total number of data messages received'
});
const birthMessageCounter = new promClient.Counter({
    name: 'birth_message_count',
    help: 'Total number of birth messages received'
});
register.registerMetric(dataMessageCounter);
register.registerMetric(birthMessageCounter);

const corsOrigins = [
    process.env.FRONTEND_URL || 'https://leaf.ornl.gov',
    `http://${process.env.HOST_IP}:3000`,
    `http://${process.env.HOST_IP}:9001`,
    'http://localhost:3000'
].filter(Boolean);

const corsOptions = {
    origin: corsOrigins,
    credentials: true, // This is essential for cookies, authorization headers with HTTPS
    methods: ['GET', 'POST', 'OPTIONS'], // Ensure OPTIONS is included
    allowedHeaders: ['Content-Type', 'Authorization']
};

app.use(cors(corsOptions));
app.options('*', cors(corsOptions)); // Enable pre-flight across-the-board

app.use(express.json());

// JWKS client for Keycloak token verification
const jwksClient = jwksRsa({
    jwksUri: `${KEYCLOAK_URL}/realms/${KEYCLOAK_REALM}/protocol/openid-connect/certs`,
    cache: true,
    cacheMaxEntries: 10,
    cacheMaxAge: 600000
});

function getSigningKey(header, callback) {
    jwksClient.getSigningKey(header.kid, (err, key) => {
        if (err) return callback(err);
        callback(null, key.getPublicKey());
    });
}

async function verifyToken(token) {
    return new Promise((resolve, reject) => {
        jwt.verify(token, getSigningKey, { algorithms: ['RS256'] }, (err, decoded) => {
            if (err) reject(err);
            else resolve(decoded);
        });
    });
}

async function authMiddleware(req, res, next) {
    if (AUTH_DISABLED) {
        req.user = null;
        return next();
    }

    const authHeader = req.headers.authorization;
    const tokenStr = (authHeader && authHeader.startsWith('Bearer '))
        ? authHeader.slice(7)
        : req.query.token;

    if (!tokenStr) {
        req.user = null;
        return next();
    }

    try {
        req.user = await verifyToken(tokenStr);
    } catch (err) {
        console.warn('Invalid JWT token:', err.message);
        req.user = null;
    }
    next();
}

function getAccessibleNamespaces(user) {
    const allNamespaces = Object.keys(sensorDataCache);

    if (!user) {
        return PUBLIC_NAMESPACES.filter(ns => allNamespaces.includes(ns));
    }

    const groups = (user.groups || []).map(g => g.replace(/^\//, ''));

    if (groups.includes('leaf-admin')) {
        return allNamespaces;
    }

    return [...new Set([...groups, ...PUBLIC_NAMESPACES])].filter(ns => allNamespaces.includes(ns));
}

app.get('/api/metrics', async (req, res) => {
    res.set('Content-Type', register.contentType);
    res.end(await register.metrics());
});

/**
 * Format a single device for API response.
 * Returns null if device doesn't have valid GPS coordinates.
 */
function formatSingleDevice(device_id, data, namespace) {
    // Extract latitude and longitude from input metrics
    const latitude = data.input?.latitude?.value;
    const longitude = data.input?.longitude?.value;
    
    if (latitude === undefined || 
        longitude === undefined || 
        isNaN(latitude) || 
        isNaN(longitude)) {
        return null;
    }
    return {
        device_id: device_id,
        namespace: namespace,
        latitude: latitude,
        longitude: longitude,
        input: data.input,
        output: data.output,
        lastUpdate: data.lastUpdate || Date.now()
    };
}

/**
 * Format devices for API response, optionally filtered to specific namespaces.
 */
function formatAllDevices(namespaces = null) {
    const namespacesToInclude = namespaces || Object.keys(sensorDataCache);
    return namespacesToInclude
        .filter(ns => sensorDataCache[ns])
        .flatMap(ns =>
            Object.entries(sensorDataCache[ns])
                .map(([device_id, data]) => formatSingleDevice(device_id, data, ns))
                .filter(device => device !== null)
        );
}

/**
 * Queue a device update for the next debounced SSE broadcast.
 */
function queueDeviceUpdate(namespace, device_id) {
    pendingUpdates[`${namespace}:${device_id}`] = true;
    
    // If no timer is running, start one
    if (!debounceTimer) {
        debounceTimer = setTimeout(() => {
            flushPendingUpdates();
        }, SSE_DEBOUNCE_MS);
    }
}

/**
 * Flush all pending updates to SSE clients.
 */
function flushPendingUpdates() {
    const keys = Object.keys(pendingUpdates);
    if (keys.length === 0) {
        debounceTimer = null;
        return;
    }
    
    // Format only the devices that changed
    const updatedDevices = keys
        .map(key => {
            const colonIdx = key.indexOf(':');
            const ns = key.substring(0, colonIdx);
            const device_id = key.substring(colonIdx + 1);
            const nsCache = sensorDataCache[ns];
            if (!nsCache || !nsCache[device_id]) return null;
            return formatSingleDevice(device_id, nsCache[device_id], ns);
        })
        .filter(device => device !== null);
    
    if (updatedDevices.length > 0) {
        sensorEvents.emit('batch_update', updatedDevices);
    }
    
    // Reset state
    pendingUpdates = {};
    debounceTimer = null;
}

app.get('/api/sensor-data', authMiddleware, (req, res) => {
    const namespaces = getAccessibleNamespaces(req.user);
    res.json(formatAllDevices(namespaces));
});

/**
 * SSE endpoint for real-time sensor data updates.
 * Sends full_sync on connect, then batch_update messages with only changed devices.
 * Auth: token may be passed as ?token=<jwt> query param (browser EventSource limitation).
 */
app.get('/api/sensor-data/stream', authMiddleware, (req, res) => {
    const namespaces = getAccessibleNamespaces(req.user);

    // SSE headers
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no'); // Disable nginx buffering
    
    // Send initial full sync filtered to accessible namespaces
    const initialData = {
        type: 'full_sync',
        devices: formatAllDevices(namespaces),
        timestamp: Date.now()
    };
    res.write(`data: ${JSON.stringify(initialData)}\n\n`);
    
    // Handler for batch updates — filter to this client's namespaces
    const onBatchUpdate = (updatedDevices) => {
        const filtered = updatedDevices.filter(d => namespaces.includes(d.namespace));
        if (filtered.length === 0) return;
        const message = {
            type: 'batch_update',
            devices: filtered,
            timestamp: Date.now()
        };
        res.write(`data: ${JSON.stringify(message)}\n\n`);
    };
    
    // Subscribe to updates
    sensorEvents.on('batch_update', onBatchUpdate);
    
    // Heartbeat to keep connection alive (every 30s by default)
    const heartbeatInterval = setInterval(() => {
        res.write(`: heartbeat\n\n`);
    }, SSE_HEARTBEAT_MS);
    
    // Cleanup on disconnect
    req.on('close', () => {
        sensorEvents.off('batch_update', onBatchUpdate);
        clearInterval(heartbeatInterval);
        console.log('SSE client disconnected');
    });
    
    console.log('SSE client connected');
});

app.post('/api/send-command', authMiddleware, async (req, res) => {
    // Commands require authentication
    if (!req.user) {
        return res.status(401).send('Authentication required to send commands');
    }

    const { device_id, output } = req.body;

    // Validate the request body
    if (!device_id || !output) {
        return res.status(400).send('Invalid request: device_id or output are missing');
    }

    // Find which namespace this device belongs to
    const namespace = Object.keys(sensorDataCache).find(ns => sensorDataCache[ns][device_id]);
    if (!namespace) {
        return res.status(404).send(`Device ${device_id} not found`);
    }

    // Check that user has access to this namespace
    const accessibleNamespaces = getAccessibleNamespaces(req.user);
    if (!accessibleNamespaces.includes(namespace)) {
        return res.status(403).send('Access denied to this device namespace');
    }

    console.log(`Processing command for device ID: ${device_id} (namespace: ${namespace}) with output: ${JSON.stringify(output)}`);

    try {
        const message = await encodeMetrics(output);
        client.publish(`leaf/${namespace}/DCMD/${device_id}`, message, { qos: 1 }, (err) => {
            if (err) {
                console.error('MQTT publishing error:', err);
                res.status(500).send('Failed to publish message');
            } else {
                console.log(`Message published successfully for device ID: ${device_id}`);
                res.send({ message: 'Message published successfully', device_id: device_id });
            }
        });
    } catch (error) {
        console.error('Encoding error:', error);
        res.status(500).send('Failed to encode message');
    }
});

app.listen(9100, '0.0.0.0', () => {
    console.log(`Server running on 0.0.0.0:9100`);
});

// MQTT client configuration
const mqttHost = process.env.MQTT_HOST || 'mosquitto';
const mqttPort = process.env.MQTT_PORT || '1883';
const client = mqtt.connect(`mqtt://${mqttHost}:${mqttPort}`);
console.log(`Connecting to MQTT broker at mqtt://${mqttHost}:${mqttPort}`);

const protoDir = process.env.PROTOBUF_DIR || './proto';
let protoRoot;
protobuf.load(`${protoDir}/sparkplug_b.proto`)
    .then(root => {
        protoRoot = root;
    })
    .catch(err => {
        console.error('Error loading proto file:', err);
    });

client.on('connect', () => {
    console.log('Connected to MQTT broker');
    const topics = ['leaf/+/DBIRTH/+', 'leaf/+/DDATA/+'];
    client.subscribe(topics, { qos: 1 });
});

client.on('message', (topic, message) => {
    const parts = topic.split('/');
    const msgType = parts[2];  // DBIRTH or DDATA

    if (msgType === 'DBIRTH') {
        handleBirthMessage(topic, message);
    } else if (msgType === 'DDATA') {
        processData(topic, message);
    }
});

function handleBirthMessage(topic, message) {
    const parts = topic.split('/');
    const namespace = parts[1];
    const device_id = parts[3];
    decodeMessage(message)
        .then(decoded => {
            console.log(`Birth message received for device ID ${device_id} in namespace ${namespace}:`, decoded);
            birthMessageCounter.inc();
            if (!sensorDataCache[namespace]) {
                sensorDataCache[namespace] = {};
            }
            sensorDataCache[namespace][device_id] = { input: {}, output: {} };
        })
        .catch(err => {
            console.error('Error decoding birth message:', err);
        });
}

function processData(topic, message) {
    const parts = topic.split('/');
    const namespace = parts[1];
    const device_id = parts[3];
    decodeMessage(message)
        .then(decoded => {
            dataMessageCounter.inc();  // Increment the data message counter

            // Ensure the sensor data cache for this device is initialized
            if (!sensorDataCache[namespace]) {
                sensorDataCache[namespace] = {};
            }
            if (!sensorDataCache[namespace][device_id]) {
                sensorDataCache[namespace][device_id] = { input: {}, output: {} };
            }

            // Build fresh input/output objects from this message so that
            // metrics removed from the device config are no longer cached.
            const newInput = {};
            const newOutput = {};

            decoded.metrics.forEach(metric => {
                ensureGaugeExists(metric.name);  // Ensure a gauge exists for this metric

                // Create a metric entry object
                let metricEntry = {};

                // Determine datatype if applicable
                if (metric.datatype !== undefined) {
                    metricEntry.datatype = protoRoot.lookupEnum('DataType').valuesById[metric.datatype];  // Convert enum value to name
                }

                // Determine the correct value type
                if (metric.doubleValue !== undefined) {
                    metricEntry.value = metric.doubleValue;
                    gauges[metric.name].set({ device_id, namespace }, metric.doubleValue);  // Set gauge value
                } else if (metric.stringValue !== undefined) {
                    metricEntry.value = metric.stringValue;
                } else if (metric.booleanValue !== undefined) {
                    metricEntry.value = metric.booleanValue;
                    gauges[metric.name].set({ device_id, namespace }, metric.booleanValue ? 1 : 0);  // Convert boolean to numeric for gauge
                } else if (metric.intValue !== undefined) { // Handle int case
                    metricEntry.value = metric.intValue; // Use intValue
                    gauges[metric.name].set({ device_id, namespace }, metric.intValue);  // Set gauge value for int
                }

                // Check for additional properties in the metric
                if (metric.properties && metric.properties.keys && metric.properties.keys.length > 0) {
                    const writableIndex = metric.properties.keys.indexOf("is_writable");
                    const minIndex = metric.properties.keys.indexOf("min");
                    const maxIndex = metric.properties.keys.indexOf("max");
                    const unitIndex = metric.properties.keys.indexOf("unit");

                    // Update unit if specified in properties
                    if (unitIndex !== -1) {
                        metricEntry.unit = metric.properties.values[unitIndex].stringValue;
                    }

                    if (writableIndex !== -1 && metric.properties.values[writableIndex].booleanValue) {
                        // Now add min and max if they exist
                        if (minIndex !== -1) {
                            metricEntry.min = metric.properties.values[minIndex].doubleValue;
                        }
                        if (maxIndex !== -1) {
                            metricEntry.max = metric.properties.values[maxIndex].doubleValue;
                        }

                        newOutput[metric.name] = metricEntry;
                    } else {
                        newInput[metric.name] = metricEntry;
                    }
                } else {
                    newInput[metric.name] = metricEntry;
                }
            });

            // Replace cached metrics entirely so stale metrics are removed
            sensorDataCache[namespace][device_id].input = newInput;
            sensorDataCache[namespace][device_id].output = newOutput;
            
            // Update the lastUpdate timestamp for this device
            sensorDataCache[namespace][device_id].lastUpdate = Date.now();
            
            // Queue this device for SSE broadcast (debounced)
            queueDeviceUpdate(namespace, device_id);
        })
        .catch(err => {
            console.error('Error decoding data message:', err);
        });
}

async function decodeMessage(message) {
    if (!protoRoot) throw new Error('Proto file is not loaded');
    const Payload = protoRoot.lookupType('Payload');
    const decodedMessage = Payload.decode(message);
    return Payload.toObject(decodedMessage, {
        longs: String,
        enums: String,
        bytes: String
    });
}

async function encodeMetrics(output) {
    if (!protoRoot) throw new Error('Proto file is not loaded');

    const Payload = protoRoot.lookupType('Payload');
    const Metric = protoRoot.lookupType('Metric');
    const DataType = protoRoot.lookupEnum('DataType');

    let encodedMetrics = Object.keys(output).map(key => {
        let metric = output[key];
        let metricPayload = {
            name: key,
            datatype: DataType.values[metric.datatype] // Resolve enum name (e.g. 'Boolean') to numeric value (e.g. 11)
        };

        // Assign the correct value field based on datatype
        switch (metric.datatype) {
            case 'Double':
                metricPayload.doubleValue = metric.value;
                break;
            case 'Boolean':
                metricPayload.booleanValue = metric.value;
                break;
            case 'Int32': // Handle int32
                metricPayload.intValue = metric.value; // Use intValue
                break;
            default:
                throw new Error('Unsupported datatype');
        }
        return Metric.create(metricPayload);
    });

    let payload = Payload.create({ metrics: encodedMetrics });
    return Payload.encode(payload).finish();
}

module.exports = { client, handleBirthMessage, processData, decodeMessage };
