const mqtt = require('mqtt');
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const path = require('path');

// Express setup
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: process.env.FRONTEND_URL || "http://localhost:3000", // Allow requests from this origin
    methods: ["GET", "POST"]
  }
});

// Use cors middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000', // Allow requests from this origin
  methods: ['GET', 'POST']
}));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// MQTT setup
const mqttHost = process.env.MQTT_HOST || 'mqtt-broker';
const mqttPort = process.env.MQTT_PORT || '1883';
const mqttClient = mqtt.connect(`mqtt://${mqttHost}:${mqttPort}`);
console.log(`Connecting to MQTT broker at mqtt://${mqttHost}:${mqttPort}`);

mqttClient.on('connect', () => {
  console.log('Connected to MQTT broker');

    // Subscribe to the new topic
    mqttClient.subscribe('vehicle/uas/#', (err) => { // Updated to use wildcard for subtopics
      if (!err) {
        console.log('Subscribed to vehicle/uas/#');
      } else {
        console.error('Failed to subscribe to vehicle/uas/#', err);
      }
    });

    // Subscribe to the environmental sensors topic
    mqttClient.subscribe('iot/environmental/#', (err) => { // Using wildcard for subtopics
      if (!err) {
        console.log('Subscribed to iot/environmental/#');
      } else {
        console.error('Failed to subscribe to iot/environmental/#', err);
      }
    });
  });

  
  
  mqttClient.on('message', (topic, message) => {
    if (topic.startsWith('vehicle/uas/')) {
      try {
        const data = JSON.parse(message.toString());
        
        // Log the received data
        console.log(`Received data from ${data.id.unique_id}:`, data);
        
        // Emit the data to the client via Socket.io
        io.emit('uasData', data);
      } catch (error) {
        console.error('Failed to parse data', error);
      }
    } else if (topic.startsWith('iot/environmental/')) {
      try {
        const data = JSON.parse(message.toString());
        
        // Log the received data
        console.log(`Received environmental data from ${data.id.unique_id}:`, data);
        
        // Emit the environmental data to the client via Socket.io
        io.emit('environmentalData', data);
      } catch (error) {
        console.error('Failed to parse environmental data', error);
      }
    }
  });

  
  
// Serve the index.html file for the root route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});