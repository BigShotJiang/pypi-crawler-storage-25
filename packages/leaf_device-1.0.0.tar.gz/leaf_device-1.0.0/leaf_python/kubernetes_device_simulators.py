#!/usr/bin/env python3
"""
LEAF Device Simulators for Kubernetes Deployment
Simulates multiple IoT devices sending data via MQTT using Sparkplug B protocol
"""

import sys
import os
import time
import math
import threading
import random
import json
import paho.mqtt.client as mqtt
from datetime import datetime

# Add the parent directory to path for imports
sys.path.append('/app')

try:
    from leaf_python.utils.leaf_device import LeafDevice
    from leaf_python.utils.sparkplug_b_pb2 import Payload
except ImportError as e:
    print(f"Import error: {e}")
    print("Trying alternative import path...")
    # Fallback import strategy
    from utils.leaf_device import LeafDevice
    from utils.sparkplug_b_pb2 import Payload


class GpsSimulator:
    """Simulates GPS movement in a circular pattern"""
    
    def __init__(self, lat, lon, speed_kmh=1.0, radius_km=1.0, update_rate_hz=1.0):
        self.center_lat = lat
        self.center_lon = lon
        self.angle = 0
        self.speed = speed_kmh / 3600  # Convert speed to km/s
        self.radius = radius_km / 111  # Convert radius from km to degrees (approx.)
        self.update_rate = update_rate_hz  # Update rate in Hz (updates per second)

    def move(self):
        # Calculate time step based on update rate
        time_step = 1 / self.update_rate
        
        # Update the angle based on speed and time step
        self.angle += self.speed * time_step  # time_step in seconds
        if self.angle >= 2 * math.pi:
            self.angle -= 2 * math.pi

        # Calculate new position based on circular motion
        self.latitude = self.center_lat + self.radius * math.cos(self.angle)
        self.longitude = self.center_lon + self.radius * math.sin(self.angle) / math.cos(math.radians(self.latitude))

    def get_position(self):
        return (self.latitude, self.longitude)


class KubernetesLeafDevice(LeafDevice):
    """Extended LeafDevice for Kubernetes environment"""
    
    def __init__(self, device_config):
        # Create a temporary file for the device config
        self.device_file = f"/tmp/{device_config['device_id']}.json"
        with open(self.device_file, 'w') as f:
            json.dump(device_config, f)
        
        super().__init__(self.device_file)
        
        # Override MQTT broker hostname for Kubernetes
        self.mqtt_host = os.getenv('MQTT_HOST', 'leaf-staging-mosquitto')
        self.mqtt_port = int(os.getenv('MQTT_PORT', '1883'))
        
    def connect(self):
        """Connect to MQTT broker with Kubernetes service hostname"""
        self.client.on_message = lambda client, userdata, message: self.on_message(client, userdata, message)
        self.client.on_connect = lambda client, userdata, flags, rc: self._on_connect(client, userdata, flags, rc)
        
        print(f"Connecting to MQTT broker at {self.mqtt_host}:{self.mqtt_port}")
        try:
            self.client.connect(self.mqtt_host, self.mqtt_port, 60)
            self.client.loop_start()
            print(f"Connected to MQTT broker for device {self.device_id}")
        except Exception as e:
            print(f"Failed to connect to MQTT broker: {e}")
            raise

    def on_message(self, client, userdata, message):
        """Handle incoming MQTT commands"""
        try:
            command_payload = Payload.FromString(message.payload)
            print(f"Processing command for {self.device_id}...")
            for metric in command_payload.metrics:
                if metric.name in ["fan_enable", "power_enable", "fan_speed"]:
                    new_value = metric.boolean_value if metric.HasField("boolean_value") else metric.double_value
                    self.set_metric_value(metric.name, new_value)
                    print(f"Command for {metric.name} = {new_value} processed. Sending ack")
                    self.publish_message()
        except Exception as e:
            print(f"Error processing message: {e}")


def simulate_device(device_config):
    """Simulate a single LEAF device"""
    device_id = device_config['device_id']
    print(f"[{datetime.now()}] Starting simulation for device: {device_id}")
    
    try:
        # Create device instance
        leaf = KubernetesLeafDevice(device_config)
        
        # Handle initial states
        leaf.set_metric_value("fan_enable", False)
        leaf.set_metric_value("power_enable", False)
        leaf.set_metric_value("fan_speed", 0)

        # GPS simulation parameters
        speed, radius, publish_rate = [400, 2, 5]  # Increased publish rate for more data

        # Get the lat and lon from the loaded config
        latitude = longitude = 0.0
        for metric in leaf.model["metrics"]: 
            if metric["name"] == "latitude":
                latitude = metric["value"] 
            elif metric["name"] == "longitude":
                longitude = metric["value"]

        gps_simulator = GpsSimulator(latitude, longitude, speed, radius, publish_rate) 
        
        # Connect to MQTT
        leaf.connect()
        leaf.client.subscribe(leaf.cmd_topic)
        
        # Give connection time to establish
        time.sleep(2)
        
        print(f"[{datetime.now()}] Device {device_id} started publishing data every {publish_rate}s")
 
        while True:
            # Update GPS position
            gps_simulator.move()
            lat, lon = gps_simulator.get_position()

            # Update all sensor values with realistic random data
            leaf.set_metric_value("latitude", lat)
            leaf.set_metric_value("longitude", lon)
            leaf.set_metric_value("wind_speed", 15 + random.random() * 10)  # 15-25 m/s
            leaf.set_metric_value("wind_direction", random.uniform(0, 360)) 
            leaf.set_metric_value("pressure", 28 + random.random() * 8)  # 28-36 kPa
            leaf.set_metric_value("temperature", 18 + random.random() * 20)  # 18-38°C
            leaf.set_metric_value("voltage", 22 + random.random() * 6)  # 22-28V
            leaf.set_metric_value("relative_humidity", 40 + random.random() * 40)  # 40-80%

            # Publish the data
            leaf.publish_message()
            print(f"[{datetime.now()}] {device_id}: Published sensor data (temp: {18 + random.random() * 20:.1f}°C, voltage: {22 + random.random() * 6:.1f}V)")
            
            time.sleep(publish_rate)

    except KeyboardInterrupt:
        print(f"[{datetime.now()}] Stopping simulation for device {device_id}")
    except Exception as e:
        print(f"[{datetime.now()}] Error in device simulation {device_id}: {e}")
        import traceback
        traceback.print_exc()


def main():
    """Main function to start all device simulators"""
    print(f"[{datetime.now()}] Starting LEAF Device Simulators")
    
    # Device configurations - using the same structure as JSON files
    device_configs = [
        {
            "device_id": "seattle-01",
            "metrics": [
                {"name": "latitude", "data_type": "double", "units": "°", "value": 47.606209},
                {"name": "longitude", "data_type": "double", "units": "°", "value": -122.332069},
                {"name": "wind_speed", "data_type": "double", "units": "m/s"},
                {"name": "wind_direction", "data_type": "double", "units": "°"},
                {"name": "pressure", "data_type": "double", "units": "kPa"},
                {"name": "temperature", "data_type": "double", "units": "°C"},
                {"name": "voltage", "data_type": "double", "units": "V"},
                {"name": "relative_humidity", "data_type": "double", "units": "%"},
                {"name": "fan_enable", "data_type": "boolean", "is_writable": True},
                {"name": "power_enable", "data_type": "boolean", "is_writable": True},
                {"name": "fan_speed", "data_type": "double", "is_writable": True, "min": 0, "max": 100}
            ]
        },
        {
            "device_id": "chicago-01", 
            "metrics": [
                {"name": "latitude", "data_type": "double", "units": "°", "value": 41.8781},
                {"name": "longitude", "data_type": "double", "units": "°", "value": -87.6298},
                {"name": "wind_speed", "data_type": "double", "units": "m/s"},
                {"name": "wind_direction", "data_type": "double", "units": "°"},
                {"name": "pressure", "data_type": "double", "units": "kPa"},
                {"name": "temperature", "data_type": "double", "units": "°C"},
                {"name": "voltage", "data_type": "double", "units": "V"},
                {"name": "relative_humidity", "data_type": "double", "units": "%"},
                {"name": "fan_enable", "data_type": "boolean", "is_writable": True},
                {"name": "power_enable", "data_type": "boolean", "is_writable": True},
                {"name": "fan_speed", "data_type": "double", "is_writable": True, "min": 0, "max": 100}
            ]
        },
        {
            "device_id": "new_orleans-01",
            "metrics": [
                {"name": "latitude", "data_type": "double", "units": "°", "value": 29.9511},
                {"name": "longitude", "data_type": "double", "units": "°", "value": -90.0715},
                {"name": "wind_speed", "data_type": "double", "units": "m/s"},
                {"name": "wind_direction", "data_type": "double", "units": "°"},
                {"name": "pressure", "data_type": "double", "units": "kPa"},
                {"name": "temperature", "data_type": "double", "units": "°C"},
                {"name": "voltage", "data_type": "double", "units": "V"},
                {"name": "relative_humidity", "data_type": "double", "units": "%"},
                {"name": "fan_enable", "data_type": "boolean", "is_writable": True},
                {"name": "power_enable", "data_type": "boolean", "is_writable": True},
                {"name": "fan_speed", "data_type": "double", "is_writable": True, "min": 0, "max": 100}
            ]
        }
    ]
    
    threads = []
    for device_config in device_configs:
        thread = threading.Thread(target=simulate_device, args=(device_config,))
        threads.append(thread)
        thread.start()

    print(f"[{datetime.now()}] Started {len(threads)} device simulator threads")
    
    try:
        for thread in threads:
            thread.join()
    except KeyboardInterrupt:
        print(f"[{datetime.now()}] Shutting down all device simulators")


if __name__ == "__main__":
    main()