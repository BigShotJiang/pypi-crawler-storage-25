from leaf_python.utils.leaf_device import LeafDevice
from leaf_python.utils.sparkplug_b_pb2 import Payload
import time
import math
import threading
import random


## The following is for debugging in a docker. 
# import debugpy
# debugpy.listen(("0.0.0.0", 5678))
# print("""waiting for debugger to attach. 
# Make sure to use Python: Attach to Docker config 
# Also ensure this container has the 5678 port in compose file""")
# debugpy.wait_for_client()

class GpsSimulator:
    def __init__(self, lat, lon, speed_kmh=1.0, radius_km=1.0, update_rate_hz=1.0):
        self.center_lat = lat
        self.center_lon = lon
        self.angle = 0
        self.speed = speed_kmh / 3600  # Convert speed to km/s
        self.radius = radius_km / 111  # Convert radius from km to degrees (approx.)
        self.update_rate = update_rate_hz  # Update rate in Hz (updates per second)

    def move(self):
        # Calculate time step based on update rate
        time_step = 1 / self.update_rate
        
        # Update the angle based on speed and time step
        self.angle += self.speed * time_step  # time_step in seconds
        if self.angle >= 2 * math.pi:
            self.angle -= 2 * math.pi

        # Calculate new position based on circular motion
        self.latitude = self.center_lat + self.radius * math.cos(self.angle)
        self.longitude = self.center_lon + self.radius * math.sin(self.angle) / math.cos(math.radians(self.latitude))

    def get_position(self):
        return (self.latitude, self.longitude)
    

class myLeafDevice(LeafDevice):
    def on_message(self, client, userdata, message):
        command_payload = Payload.FromString(message.payload)
        print(f"Processing command for {self.device_id}...")
        for metric in command_payload.metrics:
            if metric.name in ["fan_enable", "power_enable", "fan_speed"]:
                new_value = metric.boolean_value if metric.HasField("boolean_value") else metric.double_value
                self.set_metric_value(metric.name, new_value)
                print(f"Command for {metric.name} = {new_value} processed. Sending ack")
                self.publish_message()


def simulate_device(device_file):
    print(f"Creating leaf device based on {device_file}")
    leaf = myLeafDevice(device_file) 

    # Handle inital states: 
    leaf.set_metric_value("fan_enable", False)
    leaf.set_metric_value("power_enable", False)
    leaf.set_metric_value("fan_speed", 0)

    speed, radius, publish_rate = [400, 2, 2]

    # Get the lat and lon from the loaded config, unfortunately its a list
    for metric in leaf.model["metrics"]: 
        if metric["name"] == "latitude":
            latitude = metric["value"] 
        elif metric["name"] == "longitude":
            longitude = metric["value"]
    gps_simulator = GpsSimulator( latitude, 
                                  longitude, 
                                  speed, 
                                  radius, 
                                  publish_rate) 
    mqtt_host = os.environ.get('MQTT_HOST', 'mosquitto')
    mqtt_port = int(os.environ.get('MQTT_PORT', '1883'))
    leaf.connect(mqtt_host, mqtt_port)
    leaf.client.subscribe(leaf.cmd_topic)
 
    try:
        while True:
            gps_simulator.move()
            lat, lon = gps_simulator.get_position()

            leaf.set_metric_value("latitude", lat)
            leaf.set_metric_value("longitude", lon)
            leaf.set_metric_value("wind_speed", 20 + random.random() * 5) 
            leaf.set_metric_value("wind_direction", random.uniform(0, 360)) 
            leaf.set_metric_value("pressure", 30 + random.random() * 10) 
            leaf.set_metric_value("temperature", 30 + random.random() * 10) 
            leaf.set_metric_value("voltage", 24 + random.random() * 10) 
            leaf.set_metric_value("relative_humidity", 28 + random.random() * 10) 

            leaf.publish_message()
            time.sleep(publish_rate)

    except KeyboardInterrupt:
        print(f"Exiting program for device {leaf.device_id}")

def main():
    # In Docker, files are in current directory; locally, use full path
    directory_path = os.environ.get('DEVICE_CONFIG_DIR', '.')
    if not os.path.isabs(directory_path):
        directory_path = os.path.dirname(os.path.abspath(__file__)) if directory_path == '.' else directory_path
    # Get all the json files in that directory
    device_files = [file for file in os.listdir(directory_path) if file.endswith('.json')]
    threads = []
    for device_file in device_files:
        full_path = os.path.join(directory_path, device_file)
        thread = threading.Thread(target=simulate_device, args=(full_path,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()        

if __name__ == "__main__":
    main()
    main()