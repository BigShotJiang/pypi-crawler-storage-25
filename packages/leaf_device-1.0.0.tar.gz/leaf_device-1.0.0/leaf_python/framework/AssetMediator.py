import threading

from .AssetDriver import AssetDriverInterface
from .AssetEvents import DriverEvent, DriverEventType


class Mediator(threading.Thread):
    """Thread-safe event bus that broadcasts events to all registered drivers."""

    def __init__(self):
        super().__init__(daemon=True)
        self.driverList: list[AssetDriverInterface] = []
        self.latestEvent = DriverEvent(DriverEventType.NoEvent, b"")
        self._wait_event = threading.Event()
        self._stop_event = threading.Event()

    def RegisterDriver(self, subject) -> bool:
        """Register a driver to receive broadcast events.

        Returns True if the subject is a valid ``AssetDriverInterface``.
        """
        if isinstance(subject, AssetDriverInterface):
            self.driverList.append(subject)
            return True
        return False

    def SetDriverEvent(self, event: DriverEvent):
        """Post an event to the bus; wakes the mediator thread."""
        self.latestEvent = event
        self._wait_event.set()

    def stop(self):
        """Request a clean shutdown of the mediator thread."""
        self._stop_event.set()
        self._wait_event.set()

    def run(self):
        while not self._stop_event.is_set():
            self._wait_event.wait()
            if self._stop_event.is_set():
                break
            event = self.latestEvent
            self._wait_event.clear()
            for driver in self.driverList:
                driver.Update(event)
