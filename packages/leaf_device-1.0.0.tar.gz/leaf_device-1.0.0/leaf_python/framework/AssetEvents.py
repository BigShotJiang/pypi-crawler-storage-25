from enum import Enum


class DriverEventType(Enum):
    NoEvent = 0
    Status = 1
    Command = 2


class DriverEvent:
    """Carries an event type and its associated payload between drivers."""

    def __init__(self, event_type: DriverEventType, data: bytes | str):
        self._event_type = event_type
        self._data = data

    def GetMessage(self) -> bytes | str:
        return self._data

    def GetEventType(self) -> DriverEventType:
        return self._event_type
