import abc

from .AssetEvents import DriverEvent


class AssetDriverInterface(metaclass=abc.ABCMeta):
    """Abstract base class for all drivers in the LEAF mediator framework."""

    @abc.abstractmethod
    def Notify(self):
        """Signal the mediator that this driver has something to report."""
        raise NotImplementedError

    @abc.abstractmethod
    def Update(self, updateEvent: DriverEvent):
        """Receive a broadcast event from the mediator."""
        raise NotImplementedError
