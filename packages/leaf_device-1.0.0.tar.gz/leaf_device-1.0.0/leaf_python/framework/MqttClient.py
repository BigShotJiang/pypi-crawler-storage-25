import logging
import queue
import ssl
import time
import uuid

import paho.mqtt.client as mqtt

from .AssetDriver import AssetDriverInterface
from .AssetEvents import DriverEvent, DriverEventType
from .AssetMediator import Mediator

log = logging.getLogger(__name__)


class MqttClientDriver(AssetDriverInterface):
    """MQTT driver for the LEAF mediator framework.

    Receives serialized Sparkplug B payloads via Status events and publishes
    them to the broker.  Incoming DCMD messages are forwarded to all drivers
    as Command events.

    Parameters
    ----------
    address:
        Hostname or IP of the MQTT broker.
    mediator:
        The ``Mediator`` instance this driver is registered with.
    device_id:
        Device identifier used to build LEAF topic strings.
    namespace:
        LEAF namespace segment in topic paths (default ``"default"``).
    use_websocket:
        Connect via WebSocket+TLS instead of plain TCP.
    websocket_port:
        Port for WebSocket connections (default 443).
    websocket_path:
        WebSocket path (default ``"/mqtt"``).
    """

    def __init__(
        self,
        address: str,
        mediator: Mediator,
        device_id: str,
        namespace: str = "default",
        use_websocket: bool = False,
        websocket_port: int = 443,
        websocket_path: str = "/mqtt",
    ):
        self.mqttServerAddress = address
        self.assetMediator = mediator
        self.device_id = device_id
        self.namespace = namespace
        self.use_websocket = use_websocket
        self.websocket_port = websocket_port
        self.websocket_path = websocket_path
        self.mqtt_port = 1883

        self.birth_topic = f"leaf/{namespace}/DBIRTH/{device_id}"
        self.data_topic = f"leaf/{namespace}/DDATA/{device_id}"
        self.cmd_topic = f"leaf/{namespace}/DCMD/{device_id}"

        self._command_queue: queue.Queue = queue.Queue()
        self._birth_sent = False
        self._connected = False
        self._pending_birth: bytes | None = None
        self.last_publish_time: float = 0.0  # time.monotonic(); 0 = never published

        self._init_mqtt_client()

    def _init_mqtt_client(self):
        transport = "websockets" if self.use_websocket else "tcp"
        self.mqttClient = mqtt.Client(
            mqtt.CallbackAPIVersion.VERSION1,
            str(uuid.uuid4()),
            transport=transport,
        )
        self.mqttClient.on_connect = self._on_connect
        self.mqttClient.on_disconnect = self._on_disconnect
        self.mqttClient.on_message = self._on_message
        self.mqttClient.reconnect_delay_set(min_delay=5, max_delay=60)

        if self.use_websocket:
            log.info(
                "Configuring WebSocket transport to %s:%d%s",
                self.mqttServerAddress, self.websocket_port, self.websocket_path,
            )
            self.mqttClient.tls_set(cert_reqs=ssl.CERT_NONE)
            self.mqttClient.tls_insecure_set(True)
            self.mqttClient.ws_set_options(path=self.websocket_path)
        else:
            log.info(
                "Using standard MQTT transport to %s:%d",
                self.mqttServerAddress, self.mqtt_port,
            )

    def start(self):
        """Connect to the broker and start the paho network loop.

        Call this after registering the driver with the mediator but before
        starting the mediator thread.
        """
        port = self.websocket_port if self.use_websocket else self.mqtt_port
        self.mqttClient.connect_async(self.mqttServerAddress, port)
        self.mqttClient.loop_start()

    # ------------------------------------------------------------------
    # Paho callbacks (run on paho's network thread)
    # ------------------------------------------------------------------

    def _on_connect(self, client, userdata, flags, rc):
        if rc != 0:
            log.warning("MQTT connection failed (rc=%s), paho will retry", rc)
            return
        log.info("MQTT connected to %s", self.mqttServerAddress)
        self._connected = True
        self.mqttClient.subscribe(self.cmd_topic)
        # Flush a birth message that arrived before the connection was ready.
        if self._pending_birth is not None:
            self._publish(self._pending_birth, self.birth_topic)
            self._birth_sent = True
            self._pending_birth = None

    def _on_disconnect(self, client, userdata, rc):
        log.warning("MQTT disconnected (rc=%s) — will resend birth on reconnect", rc)
        self._connected = False
        self._birth_sent = False

    def _on_message(self, client, userdata, message):
        log.debug("Command received on %s", message.topic)
        self._command_queue.put(message)
        self.Notify()

    # ------------------------------------------------------------------
    # AssetDriverInterface
    # ------------------------------------------------------------------

    def Notify(self):
        """Forward the oldest queued command to the mediator as a Command event."""
        try:
            message = self._command_queue.get_nowait()
            self.assetMediator.SetDriverEvent(
                DriverEvent(DriverEventType.Command, message)
            )
        except queue.Empty:
            log.warning("Notify called but command queue was empty")

    def Update(self, event: DriverEvent):
        """Publish a Status payload or ignore non-Status events."""
        if event.GetEventType() != DriverEventType.Status:
            return
        payload: bytes = event.GetMessage()
        try:
            if self._birth_sent:
                self._publish(payload, self.data_topic)
            elif self._connected:
                self._publish(payload, self.birth_topic)
                self._birth_sent = True
            else:
                # Connection not ready yet — stash as pending birth.
                self._pending_birth = payload
        except Exception:
            log.exception("Publish failed — MQTT may be disconnected")

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _publish(self, payload: bytes, topic: str):
        self.mqttClient.publish(topic=topic, payload=payload, qos=1)
        self.last_publish_time = time.monotonic()
