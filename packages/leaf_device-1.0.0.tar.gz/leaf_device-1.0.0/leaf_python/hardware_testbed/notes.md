mosquitto -c local_mosquitto.conf

If it gives an error about the address in use find the PID and kill it: 

```
sudo lsof -i :1883
sudo kill 14104
```
I0-Master is at IP address: 172.20.20.2
My laptop IP address is: 192.168.3.5 (VPN), 172.20.20.100 local. 
Go to https://172.20.20.2/web/subscribe to edit what the IO-Master sends. 
Go to Parameter->Timer[1]->Change interval to something like 2000 ms. 
Go to Notification-> hit '+', select counter for timer[1], Next
select temperature, counter, unit, there are a bunch of others to choose from. 
In the next screen I don't think consumer ID matters. The rest is mqtt, lifetime, 172.20.20.100, 1883, topic is what ever. 

Run MQTT-Explorer to see data. 

Temp sensor is TV7105, doc is here: https://www.ifm.com/download/files/ifm-0002DD-20230324-IODD11-en/$file/ifm-0002DD-20230324-IODD11-en.pdf
IO-Link Master is AL1320, doc is here: ./IO-Link_documents/Startup_Package_Mosquitto_11-0-0/3. Manuals

Made the protobuf like this: 
```protoc --python_out=./ sparkplug_b.proto ```

I use this to restart my service and incorporate code changes:
docker compose stop hardware-testbed && docker compose rm -f hardware-testbed && docker compose up hardware-testbed --build
docker compose stop sim-device && docker compose rm -f sim-device && docker compose up sim-device --build

To debug, do docker compose up to start everything, then kill leaf-hardware-testbed, then Run Task docker-run: debug in vscode. THEN Run->Start Debugging. 

Doug's magic docker spell:
```
docker compose down --volumes
docker compose up --build
```

For the light 1101 is buzzer beeping and light solid on red. 

For opening iot-core: 
otooleat@lappy:~/Software/ifm_iot_core/IoT-Core_Assistant_V1.2/IoT-Core Assistant V1.2$ java --module-path /usr/share/openjfx/lib --add-modules javafx.controls,javafx.fxml -jar IoT-Core\ Assistant_V1.2.jar                                                

json request that works, this was sent to http://172.20.20.2
{
  "code": "request",
  "cid": 1,
  "adr": "/iolinkmaster/port[4]/iolinkdevice/pdout/setdata",
  "data": {
    "newvalue": "0002"
  }
}

MQTT does just work by default, you have to make the following setups. Using IFM's IOT core tool is a good way to do it. 
► Activate command channel
• Request:
{
"code":"request",
"cid":4711,
"adr":"/connections/mqttConnection/MQTTSetup/mqttCmdChannel/status/start"
}
► Set the IP address of the MQTT broker/server.
• Request:
{
"code":"request",
"cid":4712,
"adr":"/connections/mqttConnection/mqttCmdChannel/mqttCmdChannelSetup/brokerIP/set
data"
"data":{"172.20.20.100"}
}
► Set the port number of the MQTT broker/server.
• Request:
{
"code":"request",
"cid":4713,
"adr":"/connections/mqttConnection/mqttCmdChannel/mqttCmdChannelSetup/brokerPort/s
etdata"
"data":{"1883"}
}
► Set topic.
• Request:
{
"code":"request",
"cid":4714,
"adr":"/connections/mqttConnection/mqttCmdChannel/mqttCmdChannelSetup/cmdTopic/set
data"
"data":{"leaf/io_master_cmd"}
}
► Set standard response topic.
• Request:
{
"code":"request",
"cid":4715,
"adr":"/connections/mqttConnection/mqttCmdChannel/mqttCmdChannelSetup/defaultReply
Topic/setdata"
"data":{"io_master_reply"}
}
► Set the QoS.
• Request:
66
{
"code":"request",
"cid":4716,
"adr":"/connections/mqttConnection/MQTTSetup/QoS/setdata",
"data":{"QoS2"}
}

to make sure the cmd channel is running use: 
{
  "code": "request",
  "cid": 1,
  "adr": "/connections/mqttConnection/mqttCmdChannel/status/getdata"
}
