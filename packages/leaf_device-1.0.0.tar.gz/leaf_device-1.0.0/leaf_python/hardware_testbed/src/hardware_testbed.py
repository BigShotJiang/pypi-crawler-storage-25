from ...utils.leaf_device import LeafDevice
from ...utils.sparkplug_b_pb2 import Payload
import json

## The following is for debugging in a docker. 
# import debugpy
# debugpy.listen(("0.0.0.0", 5678))
# print("""waiting for debugger to attach. 
# Make sure to use Python: Attach to Docker config 
# Also ensure this container has the 5678 port in compose file""")
# debugpy.wait_for_client()

def decode_temperature(hexstring):
    """Decode the temperature from the iolink device which sends data as a 
    hexstring...because sending an int would be too easy 
    """
    temp_hex = hexstring[:4]
    temp_int = int(temp_hex, 16)
    temperature = temp_int * .1
    return temperature

# Overwrite the on_message method if you need to subscribe to anything
class myLeafDevice(LeafDevice): 

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.buzzer_sound = '3'
        self.buzzer_enable = '0'
        self.led_blink = '0'
        self.led_color = '0'
        self.led_io_topic = "leaf/io_master_cmd"
    def on_message(self, client, userdata, message):
        # Catch messages coming from the io-link master
        if message.topic == "leaf/io-link":
            message_dict = json.loads(message.payload.decode("utf-8"))
            try: 
                hextemp = message_dict['data']['payload']['/iolinkmaster/port[1]/iolinkdevice/pdin']['data']
                temp = decode_temperature(hextemp)
                self.set_metric_value("temperature", temp)
                self.publish_message()
            except KeyError:
                print("Contents of message didn't match lookup")

        # Catch messages coming from the broker to the io-link master
        # There is a notes.md that talks about how to configure the io-link master. 
        elif message.topic == self.cmd_topic:   
            # far left hex is buzzer sound (0-7: off, fast pulse ... other sounds)
            # next hex is buzzer on/off (0-1)
            # next hex is light blink (0-6: solid on, low flash slow rate...high flash fast rate)
            # far right hex is color (0-8:off, red, green, orange, blue, violet, turquoise, white, yellow)
            incoming_payload = Payload.FromString(message.payload)
            for metric in incoming_payload.metrics:
                if metric.name == 'led_enable' or 'buzzer_enable':
                    if metric.name == 'led_enable':
                        # convert to string '0' or '1' so we can concat it. 
                        new_value = metric.boolean_value
                        self.led_color = str(int(new_value))
                        # Make sure to let the leaf server know we received this message by updating it.
                        # TODO this is hacky, I should read this value from the IO-link device but I'm in a hurry. 
                        self.set_metric_value(metric.name, new_value)
                        print(f"Command for {self.device_id}/{metric.name} = {new_value} processed")
                        self.publish_message()
                    else:
                        new_value = metric.boolean_value
                        self.buzzer_enable = str(int(new_value))
                        self.set_metric_value(metric.name, new_value)
                        print(f"Command for {self.device_id}/{metric.name} = {new_value} processed")
                        self.publish_message()
                    cmd_string = self.buzzer_sound + self.buzzer_enable + self.led_blink + self.led_color
                    # Package the iolink message and send it. 
                    outgoing_payload = {
                        "code": "request", 
                        "cid": 1, 
                        "adr": "/iolinkmaster/port[4]/iolinkdevice/pdout/setdata", 
                        "data": {
                            "newvalue": cmd_string
                        }
                    }

                    self.client.publish(self.led_io_topic, json.dumps(outgoing_payload))


print("setting up hardware-testbed")
device = myLeafDevice("leaf_python/hardware_testbed/src/device.json")

# You have to connect before subscribing!
device.connect()
device.client.subscribe("leaf/io-link")
device.client.subscribe(device.cmd_topic)

try:
    while True:
        pass
except KeyboardInterrupt:
    print("I'm dead") 