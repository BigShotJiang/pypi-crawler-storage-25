# Use Python 3.10 slim as base image
FROM python:3.10-slim

# Set working directory
WORKDIR /app

# Install system dependencies for protobuf
RUN apt-get update && apt-get install -y --no-install-recommends \
    protobuf-compiler \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python packages
COPY leaf_python/sim_devices/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy the entire leaf_python module to maintain proper imports
COPY leaf_python/ leaf_python/

# Set Python path to find our modules
ENV PYTHONPATH=/app

# Default command
CMD ["python", "leaf_python/kubernetes_device_simulators.py"]