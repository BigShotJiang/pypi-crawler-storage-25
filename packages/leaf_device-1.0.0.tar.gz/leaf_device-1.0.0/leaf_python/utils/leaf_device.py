import logging
import paho.mqtt.client as mqtt
from .sparkplug_b_pb2 import Payload, DataType
import time
import math
import json

import leaf_python

log = logging.getLogger(__name__)

# Maps JSON config data_type strings to Sparkplug B DataType enum values.
_TYPES = {
    "double": DataType.Double,
    "float": DataType.Float,
    "boolean": DataType.Boolean,
    "int": DataType.Int32,
    "int32": DataType.Int32,
    "string": DataType.String,
}


class LeafDevice:
    """Sparkplug B MQTT device client for the LEAF IoT platform.

    Handles protobuf payload construction, birth/data/command topics, and
    optional self-managed MQTT connection (for simulator-style use).  For
    hardware devices that run their own MQTT driver (e.g. the framework
    MqttClientDriver) use ``get_message()`` / ``parse_metrics()`` instead
    of ``connect()`` / ``publish_message()``.

    Parameters
    ----------
    json_file:
        Path to a JSON device-definition file (see example below).
    device_version:
        Firmware/software version string for this specific device
        implementation.  Injected automatically into every DBIRTH payload
        as the ``device_version`` metric so the LEAF server can track what
        is running on each device.

    Example device JSON
    -------------------
    ::

        {
          "device_id": "my-device-01",
          "namespace": "default",
          "metrics": [
            {"name": "latitude",    "data_type": "double",  "units": "°",   "value": 35.9},
            {"name": "temperature", "data_type": "double",  "units": "°C"},
            {"name": "relay",       "data_type": "boolean", "is_writable": true, "value": false}
          ]
        }

    To receive commands, subclass and override ``on_message``::

        class MyDevice(LeafDevice):
            def on_message(self, client, userdata, message):
                for metric in self.parse_metrics(message.payload):
                    self.set_metric_value(metric.name, metric.boolean_value)
                self.publish_message()

        device = MyDevice("device.json")
        device.connect()
    """

    def __init__(self, json_file: str, device_version: str = "unknown"):
        with open(json_file, "r") as fh:
            self.model = json.load(fh)

        self.device_id = self.model["device_id"]
        self.namespace = self.model.get("namespace", "default")

        self.birth_topic = f"leaf/{self.namespace}/DBIRTH/{self.device_id}"
        self.data_topic = f"leaf/{self.namespace}/DDATA/{self.device_id}"
        self.cmd_topic = f"leaf/{self.namespace}/DCMD/{self.device_id}"

        self.payload = Payload()
        self._metric_alias_counter = 1
        # Fast name→index lookup built during _load_metrics.
        self._metric_index: dict[str, int] = {}

        self._load_metrics()
        self._inject_version_metrics(device_version)

        self._message_sequence_counter = 1

        # Owned MQTT client — only used when connect() is called directly.
        self.client = mqtt.Client()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_metrics(self):
        for metric in self.model["metrics"]:
            data_type_key = metric["data_type"]
            if data_type_key not in _TYPES:
                raise ValueError(
                    f"Unsupported data_type '{data_type_key}' for metric "
                    f"'{metric['name']}'. Valid types: {list(_TYPES)}"
                )
            self._add_metric(
                name=metric["name"],
                data_type=_TYPES[data_type_key],
                units=metric.get("units"),
                is_writable=metric.get("is_writable", False),
                min_val=metric.get("min"),
                max_val=metric.get("max"),
            )
            if "value" in metric:
                self.set_metric_value(metric["name"], metric["value"])

    def _inject_version_metrics(self, device_version: str):
        """Append leaf_version and device_version to every payload."""
        self._add_metric("leaf_version", DataType.String)
        self.set_metric_value("leaf_version", leaf_python.__version__)
        self._add_metric("device_version", DataType.String)
        self.set_metric_value("device_version", device_version)

    def _add_metric(
        self,
        name: str,
        data_type,
        units: str | None = None,
        is_writable: bool = False,
        min_val: float | None = None,
        max_val: float | None = None,
    ):
        index = len(self.payload.metrics)
        metric = self.payload.metrics.add()
        metric.name = name
        metric.alias = self._metric_alias_counter
        self._metric_alias_counter += 1
        metric.datatype = data_type

        if units is not None:
            metric.properties.keys.append("unit")
            metric.properties.values.add().string_value = units

        metric.properties.keys.append("is_writable")
        metric.properties.values.add().boolean_value = is_writable

        if min_val is not None:
            metric.properties.keys.append("min")
            metric.properties.values.add().double_value = float(min_val)

        if max_val is not None:
            metric.properties.keys.append("max")
            metric.properties.values.add().double_value = float(max_val)

        self._metric_index[name] = index

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def set_metric_value(self, name: str, value) -> bool:
        """Update a metric value in the payload by name.

        Returns True if the metric was found and updated, False otherwise.
        """
        idx = self._metric_index.get(name)
        if idx is None:
            log.warning("set_metric_value: unknown metric '%s'", name)
            return False

        metric = self.payload.metrics[idx]

        if metric.datatype in (DataType.Double, DataType.Float):
            fval = float(value)
            if abs(fval) < 1e-3 and fval != 0.0:
                fval = float(f"{fval:.3e}")
            else:
                fval = round(fval, 3)
            if metric.datatype == DataType.Double:
                metric.double_value = fval
            else:
                metric.float_value = fval
        elif metric.datatype == DataType.String:
            metric.string_value = str(value)
        elif metric.datatype == DataType.Int32:
            metric.int_value = int(value)
        elif metric.datatype == DataType.Boolean:
            metric.boolean_value = bool(value)

        return True

    def get_message(self) -> bytes:
        """Serialize the current metric state to Sparkplug B protobuf bytes.

        Use this when an external MQTT driver (e.g. ``MqttClientDriver``)
        handles publishing.  The sequence counter is incremented on each call.
        """
        self.payload.timestamp = int(time.time() * 1000)
        self.payload.seq = self._message_sequence_counter
        self._message_sequence_counter += 1
        return self.payload.SerializeToString()

    def parse_metrics(self, payload_bytes: bytes) -> list:
        """Deserialize a Sparkplug B DCMD payload into a list of Metric objects.

        Parameters
        ----------
        payload_bytes:
            Raw bytes received on the DCMD topic.

        Returns
        -------
        list of ``Payload.Metric`` protobuf objects.
        """
        cmd_payload = Payload.FromString(payload_bytes)
        return list(cmd_payload.metrics)

    # ------------------------------------------------------------------
    # Self-managed MQTT (simulator / standalone use)
    # ------------------------------------------------------------------

    def publish_message(self):
        """Publish current metric state to the DDATA topic.

        Only valid after ``connect()`` has been called.
        """
        self.client.publish(self.data_topic, self.get_message())

    def _on_connect(self, client, userdata, flags, rc):
        if rc != 0:
            log.warning("MQTT connect failed (rc=%s)", rc)
            return
        # Reset seq to 0 for DBIRTH per Sparkplug B spec.
        self._message_sequence_counter = 0
        self.payload.timestamp = int(time.time() * 1000)
        self.payload.seq = self._message_sequence_counter
        self._message_sequence_counter += 1
        self.client.publish(self.birth_topic, self.payload.SerializeToString())
        log.debug("DBIRTH sent for %s", self.device_id)

    def on_message(self, client, userdata, message):
        """Override in subclasses to handle incoming DCMD messages."""
        log.debug("on_message not overridden — ignoring command on %s", message.topic)

    def connect(self, mqtt_host: str = "localhost", mqtt_port: int = 1883):
        """Connect to an MQTT broker and start the network loop.

        Only needed for standalone/simulator usage.  Hardware devices using
        ``MqttClientDriver`` do not call this method.
        """
        self.client.on_message = lambda c, u, m: self.on_message(c, u, m)
        self.client.on_connect = lambda c, u, f, rc: self._on_connect(c, u, f, rc)
        self.client.connect(mqtt_host, mqtt_port, 60)
        self.client.loop_start()