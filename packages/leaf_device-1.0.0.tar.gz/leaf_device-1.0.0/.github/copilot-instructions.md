# LEAF Project - Copilot Instructions

## Project Overview

LEAF (Low-power Environmental and Asset Framework) is a full-stack IoT platform for monitoring and controlling remote environmental sensors and devices. The system uses MQTT with Sparkplug B protocol for device communication and provides a React-based UI for visualization and control.

## Architecture

### Components

1. **Backend** (`/backend`) - Node.js Express server
   - MQTT client for device communication
   - REST API for sensor data and device commands
   - Prometheus metrics endpoint
   - Protobuf decoding/encoding for Sparkplug B payloads

2. **Frontend** (`/leaf-ui`) - React TypeScript application
   - Interactive map visualization
   - Device control panels
   - Keycloak authentication integration
   - Redux state management

3. **Device Simulators** (`/leaf_python`) - Python-based device simulators
   - Sparkplug B protocol implementation
   - Multiple simulated device configurations

4. **MQTT Broker** - Eclipse Mosquitto
   - Message broker for device communication
   - WebSocket support for browser clients

5. **Monitoring** - Grafana + Prometheus
   - Custom dashboards for device metrics
   - Backend metrics scraping

## Technology Stack

### Backend
- **Runtime**: Node.js 14+
- **Framework**: Express.js
- **MQTT Client**: mqtt.js
- **Protocol Buffers**: protobufjs
- **Metrics**: prom-client (Prometheus)
- **Real-time**: Server-Sent Events (SSE) for streaming sensor updates

### Frontend
- **Framework**: React 18+ with TypeScript
- **State Management**: Redux Toolkit
- **Authentication**: Keycloak
- **Styling**: CSS

### Infrastructure
- **Container**: Docker
- **Orchestration**: Kubernetes (Helm charts)
- **MQTT Broker**: Eclipse Mosquitto 2.0.18
- **Monitoring**: Grafana, Prometheus

## Code Conventions

### JavaScript/Node.js (Backend)

```javascript
// Use async/await for asynchronous operations
async function decodeMessage(message) {
    if (!protoRoot) throw new Error('Proto file is not loaded');
    const Payload = protoRoot.lookupType('Payload');
    const decodedMessage = Payload.decode(message);
    return Payload.toObject(decodedMessage, {
        longs: String,
        enums: String,
        bytes: String
    });
}

// Environment variables for configuration
const mqttHost = process.env.MQTT_HOST || 'mosquitto';
const mqttPort = process.env.MQTT_PORT || '1883';

// Use camelCase for variables and functions
const sensorDataCache = {};
function handleBirthMessage(topic, message) { }
```

### TypeScript/React (Frontend)

```typescript
// Use functional components with hooks
const MapComponent: React.FC<Props> = ({ markers }) => {
    const [selectedMarker, setSelectedMarker] = useState<Marker | null>(null);
    // ...
};

// Use Redux Toolkit for state management
const markersSlice = createSlice({
    name: 'markers',
    initialState,
    reducers: { }
});
```

### Python (Device Simulators)

```python
# Use snake_case for variables and functions
def send_birth_message(client, device_id):
    pass

# Use type hints where appropriate
def create_metric(name: str, datatype: int, value: Any) -> dict:
    pass
```

## MQTT Topics & Sparkplug B Protocol

### Topic Structure
```
leaf/DBIRTH/{device_id}   - Device birth certificate
leaf/DDATA/{device_id}    - Device telemetry data
leaf/DCMD/{device_id}     - Device commands (from server)
```

### Sparkplug B Payload Structure
```protobuf
message Payload {
    optional uint64 timestamp = 1;
    repeated Metric metrics = 2;
    optional uint64 seq = 3;
}

message Metric {
    optional string name = 1;
    optional uint32 datatype = 4;
    // Value fields based on datatype
    optional double double_value = 13;
    optional bool boolean_value = 14;
    optional string string_value = 15;
    optional PropertySet properties = 9;
}
```

### Supported Data Types
- `Double` (10) - Floating point values
- `Boolean` (11) - True/false values
- `Int32` (3) - Integer values
- `String` (12) - Text values

## API Endpoints

### Backend REST API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/sensor-data` | GET | Get all device sensor data with GPS coordinates |
| `/api/sensor-data/stream` | GET (SSE) | Real-time sensor data stream via Server-Sent Events |
| `/api/metrics` | GET | Prometheus metrics endpoint |
| `/send-command` | POST | Send command to device |

### Server-Sent Events (SSE)

The frontend uses SSE for real-time updates instead of polling. The `/api/sensor-data/stream` endpoint:

1. **On connect**: Sends a `full_sync` message with all devices
2. **On device update**: Sends `batch_update` messages with only changed devices (debounced every 500ms)
3. **Heartbeat**: Sends a keep-alive comment every 30s

#### SSE Message Format
```json
// Initial full sync
{ "type": "full_sync", "devices": [...], "timestamp": 1701234567890 }

// Delta updates (only changed devices)
{ "type": "batch_update", "devices": [...], "timestamp": 1701234567890 }
```

#### Backend Environment Variables for SSE
| Variable | Default | Description |
|----------|---------|-------------|
| `SSE_DEBOUNCE_MS` | `500` | Debounce interval for batching updates |
| `SSE_HEARTBEAT_MS` | `30000` | Heartbeat interval to keep connections alive |

### Command Request Format
```json
{
    "device_id": "device-001",
    "output": {
        "metric_name": {
            "datatype": "Boolean",
            "value": true
        }
    }
}
```

## Environment Variables

### Backend
| Variable | Default | Description |
|----------|---------|-------------|
| `MQTT_HOST` | `mosquitto` | MQTT broker hostname |
| `MQTT_PORT` | `1883` | MQTT broker port |
| `PROTOBUF_DIR` | `./proto` | Path to protobuf definitions |
| `HOST_IP` | - | Host IP for CORS configuration |
| `FRONTEND_URL` | `https://leaf.mapster-nomad.com` | Frontend URL for CORS |
| `SSE_DEBOUNCE_MS` | `500` | Debounce interval for SSE batch updates |
| `SSE_HEARTBEAT_MS` | `30000` | SSE heartbeat interval (keep-alive) |

### Frontend
| Variable | Description |
|----------|-------------|
| `REACT_APP_KEYCLOAK_URL` | Keycloak server URL |
| `REACT_APP_KEYCLOAK_REALM` | Keycloak realm name |
| `REACT_APP_KEYCLOAK_CLIENT_ID` | Keycloak client ID |
| `REACT_APP_BACKEND_URL` | Backend API base URL (e.g., `http://localhost:9100`) |
| `REACT_APP_GRAFANA_URL` | Grafana dashboard URL |
| `REACT_APP_WS_URL` | WebSocket URL for real-time updates |
| `REACT_APP_DEV_MODE` | Set to `true` to bypass Keycloak auth |

**Note:** React environment variables are baked in at **build time**. When building the Docker image, pass them as build args:
```bash
docker build -t leaf-ui:local \
    --build-arg REACT_APP_BACKEND_URL=http://localhost:9100 \
    --build-arg REACT_APP_DEV_MODE=true \
    ./leaf-ui
```

## Sensor Data Structure

Devices report metrics with properties that determine how they're displayed:

```javascript
// Input metrics (read-only sensors)
sensorDataCache[device_id].input = {
    "temperature": { value: 22.5, datatype: "Double", unit: "C" },
    "humidity": { value: 65.0, datatype: "Double", unit: "%" }
};

// Output metrics (controllable)
sensorDataCache[device_id].output = {
    "relay_1": { value: true, datatype: "Boolean", min: 0, max: 1 },
    "setpoint": { value: 25.0, datatype: "Double", min: 15, max: 30 }
};
```

### Metric Properties
- `is_writable` - If true, metric is an output (controllable)
- `min` / `max` - Value bounds for outputs
- `unit` - Display unit (SI units preferred)

## Units Convention

The LEAF project uses SI base units for all transmitted values:
- Length: meters (m)
- Time: seconds (s)
- Mass: kilograms (kg)
- Temperature: Celsius (C)
- Angle: radians (rad)

Display conversions happen only in the UI layer.

## Development Workflow

### Local Development with KIND (Kubernetes in Docker)

The recommended way to run the full LEAF stack locally is using KIND. This provides a complete Kubernetes environment matching production.

#### Prerequisites

```bash
# Install KIND, kubectl, and Helm to ~/.local/bin
curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.20.0/kind-linux-amd64
chmod +x ./kind && mv ./kind ~/.local/bin/

curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
chmod +x kubectl && mv kubectl ~/.local/bin/

curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

export PATH="$HOME/.local/bin:$PATH"  # Add to ~/.bashrc
```

#### Quick Start with KIND

```bash
# Use the local setup script
cd deploy
./local-setup.sh setup    # Create KIND cluster
./local-setup.sh build    # Build Docker images
./local-setup.sh deploy   # Deploy with Helm
./local-setup.sh status   # Check pod status
./local-setup.sh logs     # View backend logs
./local-setup.sh cleanup  # Tear down cluster
```

#### Manual KIND Setup

```bash
# Create cluster with port mappings
kind create cluster --name leaf-local --config deploy/kind-config.yaml

# Build and load images
docker build -t leaf-backend:local ./backend
docker build -t leaf-ui:local --build-arg REACT_APP_BACKEND_URL=http://localhost:9100 ./leaf-ui
docker build -t leaf-device-simulators:local -f leaf_python/device-simulators.Dockerfile .

kind load docker-image leaf-backend:local --name leaf-local
kind load docker-image leaf-ui:local --name leaf-local
kind load docker-image leaf-device-simulators:local --name leaf-local

# Deploy with Helm
helm install leaf-local ./deploy/chart \
    --values ./deploy/environments/local-kind.yaml
```

#### Local Development Ports

| Service | Port | URL |
|---------|------|-----|
| Frontend UI | 3000 | http://localhost:3000 |
| Backend API | 9100 | http://localhost:9100/api/sensor-data |
| MQTT Broker | 1883 | mqtt://localhost:1883 |
| MQTT WebSocket | 9001 | ws://localhost:9001 |
| Grafana | 3001 | http://localhost:3001 |

#### Connecting Physical Devices

For embedded devices to connect to your local cluster:

1. Find your host machine's IP on the local network:
   ```bash
   ip addr show | grep "inet " | grep -v 127.0.0.1
   ```

2. Configure the device to connect to `mqtt://<your-ip>:1883`

3. Ensure your firewall allows incoming connections on port 1883

#### Dev Mode (Bypass Keycloak)

The UI automatically bypasses Keycloak authentication when:
- Running on `localhost`
- Or when `REACT_APP_DEV_MODE=true` is set at build time

### Local Development (Without Kubernetes)

```bash
# Backend
cd backend
npm install
npm start  # Runs on port 9100

# Frontend
cd leaf-ui
npm install
npm start  # Runs on port 3000

# Device Simulators
cd leaf_python/sim_devices
pip install -r requirements.txt
python src/device_simulators.py
```

### Docker Build

```bash
# Backend
docker build -t leaf-backend:latest ./backend

# Frontend
docker build -t leaf-ui:latest ./leaf-ui

# Device Simulators
docker build -t leaf-device-simulators:latest -f leaf_python/device-simulators.Dockerfile .
```

### Kubernetes Deployment

```bash
# Deploy to staging
helm install leaf-staging ./deploy/chart \
    --namespace leaf-staging \
    --values ./deploy/environments/leaf-staging.yaml \
    --create-namespace
```

## File Organization

```
leaf/
├── backend/                 # Node.js backend server
│   ├── app.js              # Main application (MQTT + API)
│   ├── server.js           # Socket.IO server (alternative)
│   └── protobufLoader.js   # Protobuf loading utility
├── leaf-ui/                # React frontend
│   └── src/
│       ├── api/            # API clients
│       ├── components/     # React components
│       ├── store/          # Redux store
│       └── types/          # TypeScript types
├── leaf_python/            # Python device code
│   ├── sim_devices/        # Device simulators
│   ├── hardware_testbed/   # Hardware testing
│   └── utils/              # Shared utilities
├── deploy/                 # Kubernetes deployment
│   ├── chart/              # Helm chart
│   ├── environments/       # Environment configs
│   │   ├── leaf-staging.yaml    # Staging environment
│   │   └── local-kind.yaml      # Local KIND development
│   ├── kind-config.yaml    # KIND cluster configuration
│   └── local-setup.sh      # Local dev automation script
└── proto/                  # Protobuf definitions
```

## Common Patterns

### Adding a New Metric Type

1. Add datatype handling in `app.js` `processData()` function
2. Add encoding support in `encodeMetrics()` function
3. Update frontend components to display/control the new type

### Adding a New Device Simulator

1. Create JSON config in `leaf_python/sim_devices/src/`
2. Define metrics with proper Sparkplug B datatypes
3. Include GPS coordinates (latitude, longitude)

### Adding a New API Endpoint

```javascript
// In app.js
app.get('/api/new-endpoint', async (req, res) => {
    try {
        // Implementation
        res.json({ data: result });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Error message');
    }
});
```

## Testing

### Backend Testing
- Test MQTT connectivity with mosquitto_pub/sub
- Use curl or Postman for API testing
- Monitor Prometheus metrics at `/api/metrics`

### Frontend Testing
- Jest for unit tests (`npm test`)
- React Testing Library for component tests

## Deployment Environments

| Environment | Domain | Namespace |
|-------------|--------|-----------|
| Staging | `staging.leaf-nomad.com` | `leaf-staging` |
| Production | `leaf.mapster-nomad.com` | `leaf-production` |

## Security Considerations

- Authentication handled by external Keycloak
- CORS configured for specific origins
- Network policies restrict inter-pod communication
- TLS managed by cert-manager and ingress-nginx

## Monitoring & Observability

### Prometheus Metrics
- `data_message_count` - Total MQTT data messages received
- `birth_message_count` - Total device birth messages
- Dynamic gauges for each sensor metric by device_id

### Grafana Dashboards
Located in `deploy/chart/dashboards/`:
- Device Summary Dashboard
- Main Dashboard

## Troubleshooting

### Common Issues

1. **MQTT Connection Failed**
   - Check MQTT_HOST and MQTT_PORT environment variables
   - Verify Mosquitto broker is running
   - Check network policies in Kubernetes

2. **Protobuf Decoding Errors**
   - Verify PROTOBUF_DIR points to correct location
   - Ensure `sparkplug_b.proto` file exists
   - In KIND, the proto file is mounted at `/usr/src/app/proto`

3. **CORS Errors**
   - Check HOST_IP or FRONTEND_URL environment variables
   - Verify ingress CORS annotations

4. **Device Not Appearing on Map**
   - Verify device sends valid GPS coordinates (latitude, longitude)
   - Check device sends DBIRTH message before DDATA
   - Confirm the frontend is calling the correct API endpoint (`/api/sensor-data`, not `/sensor-data`)

5. **UI Shows Fallback Data (Not Real Devices)**
   - Check browser console for 404 errors on `/sensor-data`
   - Ensure `REACT_APP_BACKEND_URL` was set at build time
   - Verify the backend API is accessible from the browser

6. **VPN Interfering with KIND**
   - GlobalProtect and similar VPNs can break KIND networking
   - Disconnect VPN before creating the KIND cluster
   - If cluster already exists, may need to recreate it

7. **KIND Cluster Not Accessible**
   - Ensure ports are mapped in `deploy/kind-config.yaml`
   - Check NodePort services are created: `kubectl get svc`
   - Verify no firewall blocking localhost ports
