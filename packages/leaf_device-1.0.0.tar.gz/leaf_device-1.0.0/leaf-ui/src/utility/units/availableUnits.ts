// Returns the set of available display units for a given metric key.
const getAvailableUnits = (key: string): string[] => {
    if (key.includes('speed')) {
        key = 'speed';
    }

    switch (key) {
      case 'temperature':
      case 'temp':
      case 'tmp':
        return ['°C', '°F', 'K'];
      case 'pressure':
        return ['Pa', 'psi', 'kPa', 'inHg'];
      case 'speed':
        return ['m/s', 'knots', 'mph'];
      default:
        return [];
    }
  };

export default getAvailableUnits;