type ConversionFunction = (value: number) => number;

interface ConversionConfig {
  fromUnit: string;
  toUnit: string;
  convert: ConversionFunction;
}

const conversionMap: ConversionConfig[] = [
  {
    fromUnit: '°C',
    toUnit: '°F',
    convert: (value) => (value * 9/5) + 32,
  },
  {
    fromUnit: '°F',
    toUnit: '°C',
    convert: (value) => (value - 32) * 5/9,
  },
  {
    fromUnit: 'K',
    toUnit: '°C',
    convert: (value) => (value - 273.15)
  },
  {
    fromUnit: '°C',
    toUnit: 'K',
    convert: (value) => (value + 273.15)
  },
  {
    fromUnit: '°F',
    toUnit: 'K',
    convert: (value) => (value - 32) * 5/9 + 273.15
  },
  {
    fromUnit: 'K',
    toUnit: '°F',
    convert: (value) => (value - 273.15) * 9/5 + 32
  },
  {
    fromUnit: 'Pa',
    toUnit: 'psi',
    convert: (value) => value * 0.0001450377,
  },
  {
    fromUnit: 'psi',
    toUnit: 'kPa',
    convert: (value) => value / 0.145038
  },
  {
    fromUnit: 'kPa',
    toUnit: 'psi',
    convert: (value) => value * 0.145038
  },
  {
    fromUnit: 'kPa',
    toUnit: 'Pa',
    convert: (value) => value * 1000
  },
  {
    fromUnit: 'Pa',
    toUnit: 'kPa',
    convert: (value) => value / 1000
  },
  {
    fromUnit: 'psi',
    toUnit: 'Pa',
    convert: (value) => value / 0.0001450377
  },
  {
    fromUnit: 'psi',
    toUnit: 'inHg',
    convert: (value) => value * 2.03602
  },
  {
    fromUnit: 'Pa',
    toUnit: 'inHg',
    convert: (value) => value * 0.0002953
  },
  {
    fromUnit: 'kPa',
    toUnit: 'inHg',
    convert: (value) => value * 0.2953
  },
  {
    fromUnit: 'inHg',
    toUnit: 'psi',
    convert: (value) => value * 0.491154
  },
  {
    fromUnit: 'inHg',
    toUnit: 'pa',
    convert: (value) => value * 3386.39
  },
  {
    fromUnit: 'inHg',
    toUnit: 'kPa',
    convert: (value) => value * 3.38639
  },
  {
    fromUnit: 'm/s',
    toUnit: 'knots',
    convert: (value) => value * 1.94384
  },
  {
    fromUnit: 'knots',
    toUnit: 'm/s',
    convert: (value) => value / 1.94384
  },
  {
    fromUnit: 'm/s',
    toUnit: 'mph',
    convert: (value) => value * 2.23694
  },
  {
    fromUnit: 'knot',
    toUnit: 'mph',
    convert: (value) => value * 1.15078
  },
  {
    fromUnit: 'mph',
    toUnit: 'm/s',
    convert: (value) => value / 2.23694
  },
  {
    fromUnit: 'mph',
    toUnit: 'knots',
    convert: (value) => value / 1.15078
  },
  // Add more conversions here...
];

export default conversionMap; 