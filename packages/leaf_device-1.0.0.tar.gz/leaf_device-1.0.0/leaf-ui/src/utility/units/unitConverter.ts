import conversionMap from './conversionMap';

class UnitConverter {
  static convert(value: number, fromUnit: string, toUnit: string): string {
    if (fromUnit === toUnit) {
        return value.toFixed(3); // No conversion needed
    }

    const conversion = conversionMap.find(
      (config) => config.fromUnit === fromUnit && config.toUnit === toUnit
    );

    if (conversion) {
      return conversion.convert(value).toFixed(3);
    }

    throw new Error(`Conversion from ${fromUnit} to ${toUnit} not found.`);
  }
}

export default UnitConverter;