import MapComponent from './components/MapComponent/MapComponent';
import GrafanaEmbedComponent from './components/GrafanaComponent/GrafanaEmbedComponent';
import { useState } from 'react';
import LogoutButton from './components/SettingsMenu/SettingsIconButton';
import LoginButton from './components/SettingsMenu/LoginButton';
import LayersButton, { MapLayer } from './components/MapComponent/LayersButton';
import AnalyticsButton from './components/MapComponent/AnalyticsButton';
import DeviceFinderPanel from './components/DeviceFinderPanel/DeviceFinderPanel';
import PreferenceModal from './components/PreferenceModal/PreferenceModal';
import DemoBanner from './components/DemoBanner/DemoBanner';
import { closePreferenceModal } from './store/uiSlice';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ToastContainer } from 'react-toastify';
import { useKeycloak } from '@react-keycloak/web';
import { useAppDispatch, useAppSelector } from './store';
import { DEV_MODE, QUERY_CONFIG } from './config';

import 'react-toastify/dist/ReactToastify.css';
import "./App.css"

// Create a QueryClient instance with global defaults
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: QUERY_CONFIG.staleTime,
      refetchOnWindowFocus: QUERY_CONFIG.refetchOnWindowFocus,
    },
  },
});

const App: React.FC = () => {
  // In DEV_MODE the Keycloak provider is omitted — use a safe stub
  const keycloakHook = DEV_MODE
    ? { keycloak: { authenticated: false, login: () => {}, logout: () => {} }, initialized: true }
    // eslint-disable-next-line react-hooks/rules-of-hooks
    : useKeycloak();
  const { keycloak, initialized } = keycloakHook;
  const [showGrafana, setShowGrafana] = useState(false);
  const [mapLayer, setMapLayer] = useState<MapLayer>('standard');
  const isPreferenceModalOpen = useAppSelector((state) => state.ui.isPreferenceModalOpen);
  const markers = useAppSelector((state) => state.markers.markers);
  const dispatch = useAppDispatch();
  
  if (!initialized) {
    return <div>Loading...</div>;
  }

  const handleShowGrafana = () => {
    setShowGrafana(true);  // Show the Grafana overlay
  };

  const handleCloseGrafana = () => {
    setShowGrafana(false);  // Hide the Grafana overlay
  };

  const closeMenu = () => {
    // Keep for compatibility with MapComponent
  };

  const handleLayerChange = (layer: MapLayer) => {
    setMapLayer(layer);
  };

  const handleClosePreference = () => {
    dispatch(closePreferenceModal());
  };

  const handleLogout = () => {
    keycloak.logout();
  };

  const handleLogin = () => {
    keycloak.login();
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ 
        position: 'relative', 
        height: '100%', 
        width: '100%',
      }}>
        <ToastContainer 
          position="top-center"
          autoClose={3000}  // Automatically close after 3 seconds
          hideProgressBar={true}
          closeOnClick={true}  // Close when clicking on the toast
          pauseOnHover={true}  // Pause auto-close when hovering over the toast
          draggable={true}
          closeButton={false}  // Show the manual close button ("X")
        />
        <AnalyticsButton onAnalyticsClick={handleShowGrafana} />
        <LayersButton selectedLayer={mapLayer} onLayerChange={handleLayerChange} />
        {keycloak.authenticated
          ? <LogoutButton onLogout={handleLogout} />
          : <LoginButton onLogin={handleLogin} />}
        <MapComponent closeMenu={closeMenu} activeLayer={mapLayer} />
        {isPreferenceModalOpen && <PreferenceModal isOpen={isPreferenceModalOpen} onClose={handleClosePreference} />}
        {showGrafana && <GrafanaEmbedComponent onClose={handleCloseGrafana} />}
        <DeviceFinderPanel
          markers={markers}
        />
        {!keycloak.authenticated && !DEV_MODE && <DemoBanner onLogin={handleLogin} />}
      </div>
    </QueryClientProvider>
  );
};

export default App;