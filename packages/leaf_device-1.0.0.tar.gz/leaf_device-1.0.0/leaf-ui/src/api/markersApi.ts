import { createAsyncThunk } from '@reduxjs/toolkit';
import { Marker } from '../types/marker';
import { apiClient } from './client';

/**
 * Fetch all device markers from the backend.
 * Throws an error on failure - error state should be handled by the UI.
 */
export const fetchMarkersThunk = createAsyncThunk(
  'markers/fetchMarkers',
  async (_, { rejectWithValue }) => {
    try {
      const data = await apiClient.get<Marker[]>('/api/sensor-data');
      return data;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to fetch markers';
      return rejectWithValue(message);
    }
  }
);