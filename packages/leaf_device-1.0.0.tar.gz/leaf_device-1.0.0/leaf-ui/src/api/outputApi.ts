// outputApi.ts

import { apiClient, ApiError } from './client';

export interface DeviceCommand {
  device_id: string;
  output: Record<string, {
    datatype: string;
    value: boolean | number | string;
  }>;
}

/**
 * Send a command to a device via the backend.
 * @param command - The device command containing device_id and output state
 * @throws ApiError if the request fails
 */
export const sendCommand = async (command: DeviceCommand): Promise<void> => {
  await apiClient.post('/api/send-command', command as unknown as Record<string, unknown>);
};

/**
 * @deprecated Use sendCommand instead. This function will be removed in a future version.
 */
export const sendToBackend = async (deviceId: string, outputState: DeviceCommand): Promise<void> => {
  await sendCommand(outputState);
};