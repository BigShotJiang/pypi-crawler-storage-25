/**
 * Centralized configuration for the LEAF UI application.
 * All environment variables should be accessed through this module.
 */

// Helper to get env var with fallback
const getEnvVar = (key: string, fallback: string): string => {
  return process.env[key] || fallback;
};

// Check if we're in local development mode (bypass auth)
export const DEV_MODE = 
  process.env.REACT_APP_DEV_MODE === 'true' || 
  (typeof window !== 'undefined' && window.location.hostname === 'localhost');

// Check if we're running via React dev server (npm start) vs production build
const isDevServer = process.env.NODE_ENV === 'development';

// API Configuration
// In dev server mode, use empty string so requests go through the proxy (setupProxy.js)
// In production, use the configured backend URL
export const API_CONFIG = {
  backendUrl: isDevServer 
    ? '' 
    : getEnvVar('REACT_APP_BACKEND_URL', 'https://leaf.ornl.gov'),
  wsUrl: getEnvVar('REACT_APP_WS_URL', ''),
} as const;

// Keycloak Configuration
export const KEYCLOAK_CONFIG = {
  url: getEnvVar('REACT_APP_KEYCLOAK_URL', 'https://auth.uvdl.ornl.gov'),
  realm: 'leaf',
  clientId: 'leaf-ui',
} as const;

// Grafana Configuration
export const GRAFANA_CONFIG = {
  url: getEnvVar('REACT_APP_GRAFANA_URL', 'https://leaf.ornl.gov/grafana'),
  dashboardPath: '/d/cdxfhgaf14uf4e/main-dashboard?orgId=1&theme=dark&kiosk=tv',
} as const;

// Polling Configuration (fallback if SSE not available)
export const POLLING_CONFIG = {
  markersIntervalMs: 10000,
} as const;

// SSE Configuration
export const SSE_CONFIG = {
  reconnectDelayMs: 3000,
  maxReconnectAttempts: 10,
} as const;

// React Query Configuration
export const QUERY_CONFIG = {
  staleTime: 5000,
  refetchOnWindowFocus: true,
} as const;
