import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import { Provider } from 'react-redux';
import store from './store';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { ReactKeycloakProvider } from '@react-keycloak/web';
import keycloak from './api/keycloak';
import { DEV_MODE } from './config';


const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

// In DEV_MODE (localhost) skip ReactKeycloakProvider entirely so the app
// doesn't hang waiting for Keycloak. useKeycloak() will return a stub.
const AppWithKeycloak = (
  <ReactKeycloakProvider authClient={keycloak}>
    <Provider store={store}>
      <App />
    </Provider>
  </ReactKeycloakProvider>
);

const AppWithoutKeycloak = (
  <Provider store={store}>
    <App />
  </Provider>
);

root.render(
  DEV_MODE ? AppWithoutKeycloak : AppWithKeycloak
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
