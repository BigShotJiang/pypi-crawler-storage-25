/**
 * Returns the display name for a device: the alias if one exists,
 * otherwise falls back to the raw device_id.
 */
export const getDisplayName = (
  deviceId: string,
  aliases: Record<string, string>
): string => {
  return aliases[deviceId] || deviceId;
};
