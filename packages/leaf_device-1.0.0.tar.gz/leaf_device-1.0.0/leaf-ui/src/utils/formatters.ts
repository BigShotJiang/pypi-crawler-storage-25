/**
 * String formatting utilities.
 */

/**
 * Converts a snake_case or camelCase string to Title Case with spaces.
 * Example: "fan_speed" -> "Fan Speed"
 * Example: "windSpeed" -> "Wind Speed"
 */
export function formatLabel(key: string): string {
  return key
    .replace(/([A-Z])/g, ' $1') // Add space before capital letters
    .split(/[_\s]+/) // Split on underscores and spaces
    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ')
    .trim();
}

/**
 * @deprecated Use formatLabel instead. Kept for backwards compatibility.
 */
export const makePretty = formatLabel;
