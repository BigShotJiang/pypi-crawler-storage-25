/**
 * Toast notification utilities.
 * Provides consistent toast styling throughout the application.
 */

import { toast, Bounce, ToastOptions } from 'react-toastify';

const defaultOptions: ToastOptions = {
  position: 'top-center',
  autoClose: 3000,
  hideProgressBar: true,
  closeOnClick: true,
  pauseOnHover: true,
  draggable: true,
  progress: undefined,
  theme: 'light',
  transition: Bounce,
};

/**
 * Show a success toast notification.
 */
export function showSuccessToast(message: string, options?: Partial<ToastOptions>): void {
  toast.success(message, { ...defaultOptions, ...options });
}

/**
 * Show an error toast notification.
 */
export function showErrorToast(message: string, options?: Partial<ToastOptions>): void {
  toast.error(message, { ...defaultOptions, ...options });
}

/**
 * Show an info toast notification.
 */
export function showInfoToast(message: string, options?: Partial<ToastOptions>): void {
  toast.info(message, { ...defaultOptions, ...options });
}

/**
 * Show a warning toast notification.
 */
export function showWarningToast(message: string, options?: Partial<ToastOptions>): void {
  toast.warning(message, { ...defaultOptions, ...options });
}
