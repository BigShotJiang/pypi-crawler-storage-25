import React from 'react';
import LogoutIcon from '@mui/icons-material/Logout';
import IconButton from '@mui/material/IconButton';
import './SettingsMenu.css';

interface LogoutButtonProps {
  onLogout: () => void;
}

const LogoutButton: React.FC<LogoutButtonProps> = ({ onLogout }) => {
  return (
    <div className="icon-button-circle">
      <IconButton 
        edge="end" 
        aria-label="logout" 
        onClick={onLogout}
        sx={{ color: 'white' }}
      >
        <LogoutIcon fontSize="large" />
      </IconButton>
    </div>
  );
};

export default LogoutButton;