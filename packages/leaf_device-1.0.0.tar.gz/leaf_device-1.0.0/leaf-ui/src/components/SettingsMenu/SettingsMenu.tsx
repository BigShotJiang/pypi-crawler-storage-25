import React from 'react';
import { useDispatch } from 'react-redux';
import './SettingsMenu.css';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Divider from '@mui/material/Divider';
import TuneIcon from '@mui/icons-material/Tune';
import HelpIcon from '@mui/icons-material/Help';
import LogoutIcon from '@mui/icons-material/Logout';
import { openPreferenceModal } from '../../store/uiSlice';
import { Marker } from '../../types/marker';

interface SettingsMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
  markers: Marker[]; 
}

const SettingsMenu: React.FC<SettingsMenuProps> = ({ isOpen, onClose, onLogout, markers }) => {
  const dispatch = useDispatch();

  const handleOpenPreference = () => {
    dispatch(openPreferenceModal());
  };

  return (
    <div className={`settings-menu ${isOpen ? 'open' : ''}`}>
      <div className="settings-menu-content">
      <List component="nav" aria-label="main settings" className="settings-menu-list">

        {/* Preferences */}
        <ListItem onClick={handleOpenPreference}>
          <ListItemIcon>
            <TuneIcon />
          </ListItemIcon>
          <ListItemText primary="Preferences" />
        </ListItem>
        
        {/* Help */}
        <ListItem onClick={onClose}>
          <ListItemIcon>
            <HelpIcon />
          </ListItemIcon>
          <ListItemText primary="Help" />
        </ListItem>

        {/* Logout */}
        <Divider />
        <ListItem onClick={onLogout}>
          <ListItemIcon>
            <LogoutIcon />
          </ListItemIcon>
          <ListItemText primary="Logout" />
        </ListItem>

      </List>
      </div>
      
      {/* ORNL Logo at bottom */}
      <div className="settings-menu-logo">
        <img 
          src="/ornl-logo.png" 
          alt="ORNL Logo" 
          className="ornl-logo"
        />
      </div>
    </div>
  );
};

export default SettingsMenu;