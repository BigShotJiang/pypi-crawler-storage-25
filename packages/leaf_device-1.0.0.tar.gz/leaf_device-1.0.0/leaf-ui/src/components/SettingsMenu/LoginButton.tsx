import React from 'react';
import LoginIcon from '@mui/icons-material/Login';
import IconButton from '@mui/material/IconButton';
import './SettingsMenu.css';

interface LoginButtonProps {
  onLogin: () => void;
}

const LoginButton: React.FC<LoginButtonProps> = ({ onLogin }) => {
  return (
    <div className="icon-button-circle">
      <IconButton
        edge="end"
        aria-label="login"
        onClick={onLogin}
        sx={{ color: 'white' }}
      >
        <LoginIcon fontSize="large" />
      </IconButton>
    </div>
  );
};

export default LoginButton;
