import React, { useState, useRef } from 'react';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import LogoutIcon from '@mui/icons-material/Logout';
import './AccountMenu.css';

interface AccountMenuProps {
  onLogout: () => void;
}

const AccountMenu: React.FC<AccountMenuProps> = ({ onLogout }) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const handleMenuToggle = () => {
    setIsOpen((prev) => !prev);
  };

  const handleClickOutside = (event: MouseEvent) => {
    if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
      setIsOpen(false);
    }
  };

  React.useEffect(() => {
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  return (
    <div className="account-menu " ref={menuRef}>
      <AccountCircleIcon className="account-icon" onClick={handleMenuToggle} />
      {isOpen && (
        <div className="account-dropdown-menu">
          <div className="account-dropdown-item" onClick={onLogout}>
            <LogoutIcon className="logout-icon" /> {/* Logout icon */}
            <span>Logout</span> {/* Logout text */}
          </div>
        </div>
      )}
    </div>
  );
};

export default AccountMenu;
