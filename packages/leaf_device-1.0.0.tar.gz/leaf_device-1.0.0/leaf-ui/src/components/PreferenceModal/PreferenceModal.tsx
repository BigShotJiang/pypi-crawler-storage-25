import React, { useState } from 'react';
import { Box, Tabs, Tab, Typography, Button, FormControlLabel, Switch } from '@mui/material';
import './PreferenceModal.css';
import { useAppDispatch, useAppSelector } from '../../store';
import { toggleDarkMode } from '../../store/uiSlice';

interface PreferenceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

const PreferenceModal: React.FC<PreferenceModalProps> = ({ isOpen, onClose }) => {
  const [value, setValue] = useState(0);
  const dispatch = useAppDispatch();
  const darkMode = useAppSelector((state) => state.ui.darkMode);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  const handleToggleDarkMode = () => {
    dispatch(toggleDarkMode());
  };

  if (!isOpen){
    return null;
  } 

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h2>Preferences</h2>
        <Box sx={{ width: '100%' }}>
          <Tabs value={value} onChange={handleChange} aria-label="about modal tabs">
            <Tab label="General" />
            <Tab label="Privacy" />
          </Tabs>
          <TabPanel value={value} index={0}>
            <Typography>
              This application demonstrates the use of React, Leaflet, and Redux to manage maps and
              markers dynamically.
            </Typography>
            <FormControlLabel
              control={<Switch checked={darkMode} onChange={handleToggleDarkMode} />}
              label="Dark Mode"
            />
          </TabPanel>
          <TabPanel value={value} index={1}>
            <Typography>
              This section could describe privacy and security settings if we had them, lol. 
            </Typography>
          </TabPanel>
        </Box>
        <Button onClick={onClose} sx={{ marginTop: 2 }} variant="contained" color="primary">
          Close
        </Button>
      </div>
    </div>
  );
};

export default PreferenceModal;