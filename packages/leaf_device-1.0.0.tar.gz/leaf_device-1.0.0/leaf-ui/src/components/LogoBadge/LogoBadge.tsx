import React from 'react';
import './LogoBadge.css';

const LogoBadge: React.FC = () => {
  return (
    <div className="logo-badge">
      <img
        src={`${process.env.PUBLIC_URL}/leaf-logo.png`}
        alt="LEAF logo"
        className="logo-badge-icon"
      />
    </div>
  );
};

export default LogoBadge;
