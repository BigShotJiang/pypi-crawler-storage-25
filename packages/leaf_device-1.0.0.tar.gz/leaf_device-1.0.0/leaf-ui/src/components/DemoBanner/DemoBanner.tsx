import React from 'react';
import LoginIcon from '@mui/icons-material/Login';
import './DemoBanner.css';

interface DemoBannerProps {
  onLogin: () => void;
}

const DemoBanner: React.FC<DemoBannerProps> = ({ onLogin }) => {
  return (
    <div className="demo-banner">
      <span className="demo-banner-text">
        You're viewing a demo — log in to see your devices.
      </span>
      <button className="demo-banner-login" onClick={onLogin}>
        <LoginIcon fontSize="small" style={{ verticalAlign: 'middle', marginRight: 6 }} />
        Log In
      </button>
    </div>
  );
};

export default DemoBanner;
