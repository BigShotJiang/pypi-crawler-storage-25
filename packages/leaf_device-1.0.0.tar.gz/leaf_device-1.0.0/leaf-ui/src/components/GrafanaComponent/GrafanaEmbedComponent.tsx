import React from 'react';
import './GrafanaEmbedComponent.css';
import { GRAFANA_CONFIG } from '../../config';

interface GrafanaEmbedComponentProps {
  onClose: () => void;
}

const GrafanaEmbedComponent: React.FC<GrafanaEmbedComponentProps> = ({ onClose }) => {
  return (
    <div className="grafana-overlay">
      <button className="close-button" onClick={onClose}>Close</button>
      <iframe
        src={`${GRAFANA_CONFIG.url}${GRAFANA_CONFIG.dashboardPath}`}
        width="100%"
        height="100%"
        title="LEAF Analytics"
        className="grafana-iframe"
      />
    </div>
  );
};

export default GrafanaEmbedComponent;