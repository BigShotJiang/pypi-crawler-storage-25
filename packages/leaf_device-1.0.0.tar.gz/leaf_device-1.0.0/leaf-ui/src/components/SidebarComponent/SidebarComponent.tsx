import React, { useCallback, useEffect, useRef} from 'react';
import SensorsIcon from '@mui/icons-material/Sensors';
import './SidebarComponent.css'; // Ensure this path is correct
import OutputComponent from './DisplayDataComponents/OutputComponent';
import InputComponent from './DisplayDataComponents/InputComponent';
import { Marker } from '../../types/marker';
import { useAppSelector } from '../../store/hooks';
import { getDisplayName } from '../../utils/deviceAlias';
import L from 'leaflet';

/**
 * Format a timestamp as a relative time string (e.g., "2 min ago")
 */
const formatRelativeTime = (timestamp: number | undefined): string => {
  if (!timestamp) return 'N/A';
  const now = Date.now();
  const diff = now - timestamp;
  if (diff < 60000) return 'just now';
  if (diff < 3600000) {
    const mins = Math.floor(diff / 60000);
    return `${mins} min ago`;
  }
  if (diff < 86400000) {
    const hours = Math.floor(diff / 3600000);
    return `${hours} hr ago`;
  }
  const days = Math.floor(diff / 86400000);
  return `${days} day${days > 1 ? 's' : ''} ago`;
};

interface SidebarProps {
  selectedMarker: Marker | null; // The selected marker
}

const Sidebar: React.FC <SidebarProps> = ({ selectedMarker }) =>  {
  const sidebarRef = useRef<HTMLDivElement | null>(null);
  const aliases = useAppSelector((state) => state.deviceAliases.aliases);

  // Callback to handle when the ref is set
  const setSidebarRef = useCallback((node: HTMLDivElement | null) => {
    if (node) {
        L.DomEvent.disableClickPropagation(node);
        L.DomEvent.disableScrollPropagation(node);
        sidebarRef.current = node;
    }
  }, []);

  useEffect(() => {
      return () => {
          if (sidebarRef.current) {
              L.DomEvent.off(sidebarRef.current);
          }
      };
  }, []);

  useEffect(() => {
    if (!sidebarRef.current) return;

    const hideScrollbar = () => {
      sidebarRef.current?.classList.add("hidden-scrollbar");
    };

    const showScrollbar = () => {
      sidebarRef.current?.classList.remove("hidden-scrollbar");
    };

    const sidebarContent = sidebarRef.current;
    sidebarContent.addEventListener("scroll", showScrollbar);

    const timeoutId = setTimeout(hideScrollbar, 1000);

    return () => {
      clearTimeout(timeoutId);
      sidebarContent.removeEventListener("scroll", showScrollbar);
    };
  }, []);


  if (!selectedMarker) {
    return <div className="sidebar">No marker selected</div>;
  }

  const sidebarStyle = {
    left: selectedMarker ? '0' : '-300px',  // Dynamically set the left position
  };
  
  let outputTitle = <h4>Controls</h4>;
  if (selectedMarker.output.size === 0) {
    outputTitle = <span/>;
  }

  return (
    <div ref={setSidebarRef} 
      className="sidebar" 
      style={sidebarStyle} 
      // ref={sidebarRef} 
      onClick={(e) => e.stopPropagation()}
      onDrag={(e) => e.stopPropagation()}
    >
      <div className="sidebar-header">
        <SensorsIcon className="device-icon" />
        <div className="sidebar-header-text">
          <h3>{selectedMarker.device_id
            ? getDisplayName(selectedMarker.device_id, aliases)
            : "No marker selected"}</h3>
          {aliases[selectedMarker.device_id] && (
            <span className="sidebar-device-id">{selectedMarker.device_id}</span>
          )}
          <span className="sidebar-last-update">
            {selectedMarker.lastUpdate
              ? `Updated ${formatRelativeTime(selectedMarker.lastUpdate)}`
              : 'No updates'}
          </span>
        </div>
      </div>

      {/* Sensor Data Section */}
      <div className="sensor-data">
        <h4>Sensor Data</h4>
          <InputComponent marker={selectedMarker ? { ...selectedMarker } : null} />
        {/* <div> */}
        {outputTitle}
          <OutputComponent marker={selectedMarker ? { ...selectedMarker } : null} />
        {/* </div> */}
      </div>
      
    </div>
  );
};




export default Sidebar;