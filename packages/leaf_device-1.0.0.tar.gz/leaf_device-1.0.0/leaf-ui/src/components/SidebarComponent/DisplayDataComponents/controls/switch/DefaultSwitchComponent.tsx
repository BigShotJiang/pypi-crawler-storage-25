import { Switch } from "@mui/material";
import { useEffect, useState } from "react";
import React from "react";
import "./DefaultSwitchComponent.css"

interface Props {
  backendValue: boolean; // Prop for the backend received value
  label: string;
  handleToggleCommand: (label: string, value: boolean) => void; // Debounced function passed as prop
}

const DefaultSwitchComponent: React.FC<Props> = ({ backendValue, label, handleToggleCommand }) => {
  const [commandedState, setCommandedState] = useState<boolean>(backendValue);

  // Update commandedState when backendValue changes
  useEffect(() => {
    setCommandedState(backendValue);
  }, [backendValue]);


  // Function to handle user input change
  const handleInputChange = () => {
    const value = !commandedState;
    handleToggleCommand(label, value);
  };

  return (
    <Switch
        className="output-control switch-control"
        checked={commandedState}
        onChange={(e) => {
            e.stopPropagation();
            
            handleInputChange();
        }}
        sx={{
          '& .MuiSwitch-switchBase.Mui-checked': {
            color: 'var(--color-primary, #4caf50)',
          },
          '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
            backgroundColor: 'var(--color-primary, #4caf50)',
          },
        }}
    />

  );
};

export default DefaultSwitchComponent;