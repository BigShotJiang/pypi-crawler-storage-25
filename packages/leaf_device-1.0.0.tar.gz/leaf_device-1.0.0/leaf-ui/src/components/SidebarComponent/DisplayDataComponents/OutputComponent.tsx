import { useState, useEffect } from "react";
import { Typography } from "@mui/material";
import React from "react";
import { sendCommand, DeviceCommand } from "../../../api/outputApi";
import { useDebouncedCallback } from "../../../hooks";
import { formatLabel, showSuccessToast, showErrorToast } from "../../../utils";
import DefaultNumberComponent from "./controls/numbers/DefaultNumberComponent";
import DefaultSwitchComponent from "./controls/switch/DefaultSwitchComponent";
import DefaultDropdownComponent from "./controls/dropdown/DefaultDropdownComponent";
import { Marker } from "../../../types/marker";
import './OutputComponent.css';

interface OutputComponentProps {
  marker: Marker | null;
}

type OutputState = Record<string, {
  datatype: string;
  value: boolean | number | string;
  min?: number;
  max?: number;
}>;

const OutputComponent: React.FC<OutputComponentProps> = ({ marker }) => {
  const output = marker?.output || {};
  const [outputState, setOutputState] = useState<OutputState>(output);
  
  useEffect(() => {
    setOutputState(output);
  }, [marker, output]);

  const debouncedSendCommand = useDebouncedCallback((command: DeviceCommand) => {
    const label = Object.keys(command.output)[0];
    sendCommand(command)
      .then(() => {
        showSuccessToast(`Message for ${formatLabel(label)} has been sent!`);
      })
      .catch(() => {
        showErrorToast(`Failed to send message for ${formatLabel(label)}`);
      });
  }, 1000);

  const handleToggleChange = (key: string, value: boolean) => {
    const command: DeviceCommand = {
      device_id: marker?.device_id || '',
      output: {
        [key]: {
          datatype: "Boolean",
          value: value
        }
      }
    };
    sendCommand(command)
      .then(() => {
        showSuccessToast(`Message for ${formatLabel(key)} has been sent!`);
      })
      .catch(() => {
        showErrorToast(`Failed to send message for ${formatLabel(key)}`);
      });
  };

  const handleNumberChange = (label: string, newValue: string) => {
    const numericValue = parseFloat(newValue);
    const command: DeviceCommand = {
      device_id: marker?.device_id || '',
      output: {
        [label]: {
          datatype: "Double",
          value: numericValue
        }
      }
    };
    debouncedSendCommand(command);
  };

  const handleDropdownChange = (label: string, newValue: string) => {
    const numericValue = parseInt(newValue);
    const command: DeviceCommand = {
      device_id: marker?.device_id || '',
      output: {
        [label]: {
          datatype: "Int32",
          value: numericValue
        }
      }
    };
    debouncedSendCommand(command);
  };

  const generateOutputDisplayData = (data: OutputState) => {
    const displayData: { key: string; displayKey: string; value: boolean | number | string; type: string; min?: number; max?: number }[] = [];

    for (const [key, value] of Object.entries(data)) {
      if (value?.datatype === "Boolean") {
        displayData.push({ key, displayKey: formatLabel(key), value: value.value, type: "boolean" });
      } else if (value?.datatype === "Double") {
        displayData.push({
          key,
          displayKey: formatLabel(key),
          value: value.value,
          type: "double",
          ...(value.min !== undefined && { min: value.min }),
          ...(value.max !== undefined && { max: value.max }),
        });
      } else if (value?.datatype === "Int32" && value.max !== undefined && value.min !== undefined){
        displayData.push({
          key,
          displayKey: formatLabel(key),
          value: value.value,
          type: "int",
          ...(value.min !== undefined && { min: value.min }),
          ...(value.max !== undefined && { max: value.max }),
        });
      } else {
        displayData.push({ key, displayKey: formatLabel(key), value: String(value.value), type: "text" });
      }
    }

    return displayData;
  };

  const outputDisplayData = generateOutputDisplayData(outputState);
  
  if (!marker) {
    return <div className="sidebar">No marker selected</div>;
  }

  return (
    <div className="output-container">
      {outputDisplayData.map(({ key, displayKey, value, type, min, max }) => {
        if (type === "boolean") {
          return (
            <div className="output-row" key={key}>
              <Typography className="output-label">{displayKey}:</Typography>
              <DefaultSwitchComponent backendValue={value as boolean} label={key} handleToggleCommand={handleToggleChange}/>
            </div>
          );
        } else if (type === "double") {
          return (
            <div className="output-row" key={key}>
              <Typography className="output-label">{displayKey}:</Typography>
              <DefaultNumberComponent backendValue={value as number} max={max} min={min} label={key} handleNumberCommand={handleNumberChange} />
            </div>
          );
        } else if (type === "int" && max !== undefined && min !== undefined) {
          return (
            <div className="output-row" key={key}>
              <Typography className="output-label">{displayKey}:</Typography>
              <DefaultDropdownComponent backendValue={value as number} max={max} min={min} label={key} handleNumberCommand={handleDropdownChange}/>
            </div>
          );
        } else {
          return (
            <div key={key}>
              <strong>{displayKey}:</strong> {value}
            </div>
          );
        }
      })}
    </div>
  );
};

export default OutputComponent;