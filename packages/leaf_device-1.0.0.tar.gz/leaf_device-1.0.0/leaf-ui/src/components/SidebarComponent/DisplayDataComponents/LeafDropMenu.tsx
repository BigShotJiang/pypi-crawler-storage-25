import React from 'react';
import './LeafDropMenu.css'

interface DropdownMenuProps {
  items: string[];
  selectedItem: string;
  listHeader: string
  onSelectItem: (item: string) => void;
}

const LeafDropMenu: React.FC<DropdownMenuProps> = ({ items, selectedItem, listHeader, onSelectItem }) => {
  return (
    <div className="leaf-dropdown-menu">
      <div className="leaf-dropdown-header">{listHeader}</div>
      {items.map((item) => (
        <div
          key={item}
          className={`leaf-dropdown-item ${item === selectedItem ? 'selected' : ''}`}
          onClick={(e) => {
            e.stopPropagation();
            onSelectItem(item)
          }}
        >
          {item}
        </div>
      ))}
    </div>
  );
};

export default LeafDropMenu;