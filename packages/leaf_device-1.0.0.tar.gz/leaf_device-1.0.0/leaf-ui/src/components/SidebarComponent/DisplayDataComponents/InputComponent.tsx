import { useEffect, useState } from "react";
import React from "react";
import UnitConverter from "../../../utility/units/unitConverter";
import LeafDropMenu from "./LeafDropMenu";
import getAvailableUnits from "../../../utility/units/availableUnits";
import { formatLabel } from "../../../utils";
import { Marker } from "../../../types/marker";
import { useAppSelector, useAppDispatch } from "../../../store/hooks";
import { setPreferredUnit } from "../../../store/uiSlice";
import './InputComponent.css';

interface InputComponentProps {
  marker: Marker | null;
}

interface InputMetric {
  datatype?: string;
  value: number | string;
  unit?: string;
  min?: number;
  max?: number;
}

type InputState = Record<string, InputMetric>;

const SENSOR_SETTINGS_KEYS = ['device_id', 'latitude', 'longitude'];

const InputComponent: React.FC<InputComponentProps> = ({ marker }) => {
  const input = marker?.input || {};
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const preferredUnits = useAppSelector((state) => state.ui.preferredUnits);
  const dispatch = useAppDispatch();
  const [inputState, setInputState] = useState<InputState>(input);
  
  useEffect(() => {
    setInputState(input);
  }, [marker, input]);

  const handleUnitChange = (key: string, unit: string) => {
    dispatch(setPreferredUnit({ metricKey: key, unit }));
    setSelectedItem(null);
  };

  const handleItemClick = (key: string) => {
    setSelectedItem(selectedItem === key ? null : key);
  };

  const generateInputDisplayData = (data: InputState) => {
    const displayData: { key: string; displayKey: string; value: string }[] = [];
    const entries = Object.entries(data).filter(([key]) => !SENSOR_SETTINGS_KEYS.includes(key));

    for (const [key, metric] of entries) {
      if (metric.datatype?.toLowerCase() === "string") {
        displayData.push({ 
          key,
          displayKey: formatLabel(key),
          value: String(metric.value)
        });
      } else if (typeof metric === 'object' && metric !== null && 'value' in metric && 'unit' in metric && metric.unit) {
        const toUnit = preferredUnits[key] || metric.unit;
        const displayValue = UnitConverter.convert(metric.value as number, metric.unit, toUnit);
        displayData.push({ 
          key,
          displayKey: formatLabel(key),
          value: `${displayValue} ${toUnit}` 
        });
      }
    }

    return displayData;
  };

  const inputDisplayData = generateInputDisplayData(inputState);

  return (
    <div>
        <ul className="input-list">
            {inputDisplayData.map(({ key, displayKey, value }) => (
                <li 
                    key={key} 
                    className="input-list-item" 
                    onClick={(e) => {
                        e.stopPropagation();
                        handleItemClick(key);
                     }}
                    style={{ position: 'relative' }}
                >
                <strong>{displayKey}:</strong> {value}
                {selectedItem === key && (
                    <LeafDropMenu
                        items={getAvailableUnits(key)}
                        selectedItem={preferredUnits[key] || value.split(' ')[1]}
                        listHeader='Please Select Unit'
                        onSelectItem={(item) => handleUnitChange(key, item)}
                    />
                )}
                </li>
            ))}
        </ul>
    </div>
  );
};

export default InputComponent;