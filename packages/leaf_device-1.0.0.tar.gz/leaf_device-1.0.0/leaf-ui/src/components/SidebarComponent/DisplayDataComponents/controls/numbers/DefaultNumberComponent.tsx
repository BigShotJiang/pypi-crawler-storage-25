import { TextField } from "@mui/material";
import { useEffect, useState } from "react";
import React from "react";

interface Props {
  backendValue: number; // Prop for the backend received value
  max?: number;
  min?: number;
  label: string;
  handleNumberCommand: (label: string, value: string) => void; // Debounced function passed as prop
}

const DefaultNumberComponent:  React.FC<Props> = ({ backendValue, min, max, label, handleNumberCommand }) => {
  const [commandedNumber, setCommandedNumber] = useState<number>(backendValue);

    // Update commandedState when backendValue changes
    useEffect(() => {
      setCommandedNumber(backendValue);
    }, [backendValue]);

  // Function to handle user input change
  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    // const value = parseFloat(event.target.value);
    if (event.target.value) {
      setCommandedNumber(parseFloat(event.target.value));
      handleNumberCommand(label, event.target.value);
    }
  };

  // Dynamic styles for border color and background color
  const getStyles = () => {
    if (commandedNumber === backendValue) {
      return {
        borderColor: 'green',
        backgroundColor: 'rgba(0, 255, 0, 0.1)', // Light green background
      };
    }
    return {
      borderColor: 'yellow',
      backgroundColor: 'rgba(255, 255, 0, 0.1)', // Light yellow background
    };
  };

  return (
    <TextField
      type="number"
      value={commandedNumber}
      onChange={handleInputChange}
      variant="outlined"
      size="small"
      className="output-control number-control"
      InputProps={{
        inputProps: {
          min: min,
          max: max,
        },
      }}
      sx={{
        width: '90px',
        '& .MuiOutlinedInput-root': {
          height: '40px',
          borderRadius: 'var(--radius-sm, 6px)',
          '& fieldset': {
            borderColor: getStyles().borderColor,
          },
          backgroundColor: getStyles().backgroundColor,
          '&:hover fieldset': {
            borderColor: getStyles().borderColor,
          },
          '&.Mui-focused fieldset': {
            borderColor: getStyles().borderColor,
            borderWidth: '2px',
          },
        },
        '& .MuiOutlinedInput-input': {
          textAlign: 'center',
          fontWeight: '500',
          color: '#e0e0e0',
        }
      }}
    />

  );
};

export default DefaultNumberComponent;