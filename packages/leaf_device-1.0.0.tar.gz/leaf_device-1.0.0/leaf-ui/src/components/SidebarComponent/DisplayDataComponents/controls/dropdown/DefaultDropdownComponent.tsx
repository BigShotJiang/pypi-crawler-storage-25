import React, { useMemo, useState, useEffect, useRef } from "react";
import LeafDropMenu from "./../../LeafDropMenu";
import "./DefaultDropdownComponent.css";

interface Props {
  backendValue: number; // Current value from the backend
  min: number;
  max: number;
  label: string;
  handleNumberCommand: (label: string, value: string) => void; // Function to send updates
}

const DefaultDropdownComponent: React.FC<Props> = ({
  backendValue,
  min,
  max,
  label,
  handleNumberCommand,
}) => {
  const [commandedValue, setCommandedValue] = useState<number>(backendValue); // Value selected by the user
  const [status, setStatus] = useState<"stable" | "pending" | "error">("stable"); // State to track sync status
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const componentRef = useRef<HTMLDivElement>(null);

  // Memoize the options array
  const options = useMemo(() => {
    if (typeof min !== "number" || typeof max !== "number" || min > max) {
      console.error("Invalid min or max values:", { min, max });
      return [];
    }
    return Array.from({ length: max - min + 1 }, (_, i) => min + i);
  }, [min, max]);

  // Handle selection of a dropdown item
  const handleDropdownChange = (selectedValue: string) => {
    const numericValue = parseInt(selectedValue, 10);
    setCommandedValue(numericValue);
    setStatus("pending"); // Set status to pending when a command is issued
    handleNumberCommand(label, selectedValue);
    setIsDropdownOpen(false); // Close the dropdown after selection
  };

  // Toggle the dropdown visibility
  const toggleDropdown = () => {
    setIsDropdownOpen((prev) => !prev);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        componentRef.current &&
        !componentRef.current.contains(event.target as Node)
      ) {
        setIsDropdownOpen(false);
      }
    };

    if (isDropdownOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isDropdownOpen]);

  // Update status based on backend value
  useEffect(() => {
    if (commandedValue === backendValue) {
      setStatus("stable");
    } 
  }, [backendValue, commandedValue, status]);

  // Dynamic styles based on status
  const getStyles = () => {
    if (status === "stable") {
      return {
        borderColor: "green",
        backgroundColor: "rgba(0, 255, 0, 0.1)", // Light green background
      };
    } else if (status === "pending") {
      return {
        borderColor: "yellow",
        backgroundColor: "rgba(255, 255, 0, 0.1)", // Light yellow background
      };
    } else if (status === "error") {
      return {
        borderColor: "red",
        backgroundColor: "rgba(255, 0, 0, 0.1)", // Light red background
      };
    }
    return {};
  };

  return (
    <div ref={componentRef} className="default-dropdown-component">
      {/* <div className="dropdown-label">{label}</div> Label is above the dropdown */}
      <div
        className="dropdown-display"
        onClick={toggleDropdown}
        style={{
          border: `2px solid ${getStyles().borderColor}`,
          borderRadius: "4px",
          padding: "8px",
          ...getStyles(),
        }}
      >
        {commandedValue !== undefined ? commandedValue.toString() : "Select an option"}
        <span className="dropdown-arrow">{isDropdownOpen ? "▲" : "▼"}</span>
      </div>
      {isDropdownOpen && (
        <LeafDropMenu
          items={options.map((opt) => opt.toString())}
          selectedItem={commandedValue?.toString() || ""}
          listHeader="Please Select Fan Speed"
          onSelectItem={handleDropdownChange} // Automatically closes after selection
        />
      )}
    </div>
  );
};

export default DefaultDropdownComponent;
