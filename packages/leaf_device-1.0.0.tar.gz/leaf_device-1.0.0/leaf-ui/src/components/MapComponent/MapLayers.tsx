import React, { useEffect, useRef, useCallback } from 'react';
import { useMap } from 'react-leaflet';
import L from 'leaflet';
import { useAppDispatch, useAppSelector } from '../../store';
import { selectMarker } from '../../store/markersSlice';
import { Marker } from '../../types/marker';
import { MapLayer } from './LayersButton';

interface MapLayersProps {
  markers: Marker[];
  closeMenu: () => void;
  activeLayer: MapLayer;
}

/**
 * Handles map layers including tile layers, satellite view, and marker clusters.
 * Must be rendered inside a MapContainer.
 */
const MapLayers: React.FC<MapLayersProps> = ({ markers, closeMenu, activeLayer }) => {
  const map = useMap();
  const darkMode = useAppSelector((state) => state.ui.darkMode);
  const selectedMarker = useAppSelector((state) => state.markers.selectedMarker);
  const dispatch = useAppDispatch();

  const currentLayerRef = useRef<L.TileLayer | null>(null);
  const markerClusterGroupRef = useRef<L.MarkerClusterGroup | null>(null);
  const leafletMarkersRef = useRef<Map<string, L.Marker>>(new Map());
  const markerColorsRef = useRef<Map<string, string>>(new Map());
  const markerPositionsRef = useRef<Map<string, string>>(new Map());
  const markerSelectedRef = useRef<string | null>(null);

  // Create custom marker icon with specified color
  const createMarkerIcon = useCallback((color: string, selected: boolean = false) => {
    const size = selected ? 22 : 14;
    const outerSize = size + 4;
    const borderWidth = selected ? 3 : 2;
    const pulseRing = selected
      ? `<div style="
          position: absolute;
          top: 50%; left: 50%;
          transform: translate(-50%, -50%);
          width: ${outerSize + 12}px;
          height: ${outerSize + 12}px;
          border-radius: 50%;
          border: 2px solid ${color};
          opacity: 0.5;
          animation: marker-pulse 2s ease-out infinite;
        "></div>`
      : '';
    return L.divIcon({
      className: 'custom-marker',
      html: `<div style="position:relative;width:${outerSize}px;height:${outerSize}px;">
        ${pulseRing}
        <div style="
          position: absolute;
          top: 50%; left: 50%;
          transform: translate(-50%, -50%);
          background: ${color};
          width: ${size}px;
          height: ${size}px;
          border-radius: 50%;
          border: ${borderWidth}px solid #ffffff;
          box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        "></div>
      </div>`,
      iconSize: [outerSize, outerSize],
      iconAnchor: [outerSize / 2, outerSize / 2],
    });
  }, []);

  // Determine marker color based on last update time
  const getMarkerColor = (lastUpdate: number | undefined): string => {
    if (!lastUpdate) return '#FF9E1B'; // Forge (orange) for unknown
    
    const now = Date.now();
    const timeSinceUpdate = now - lastUpdate;
    const fifteenMinutes = 15 * 60 * 1000; // 15 minutes in milliseconds
    
    return timeSinceUpdate > fifteenMinutes ? '#FF9E1B' : '#00662C'; // Forge if stale, ORNL Green if fresh
  };

  // Disable double click zoom
  useEffect(() => {
    if (map) {
      map.doubleClickZoom.disable();
    }
  }, [map]);

  // Handle layer switching - create fresh layer instances to ensure clean switching
  useEffect(() => {
    if (!map) return;

    // Remove and destroy current layer completely
    if (currentLayerRef.current) {
      map.removeLayer(currentLayerRef.current);
      currentLayerRef.current = null;
    }

    // Create a fresh layer instance based on selection
    let newLayer: L.TileLayer;
    
    if (activeLayer === 'satellite') {
      newLayer = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        {
          attribution: 'Tiles © Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
          noWrap: false,
        }
      );
    } else if (activeLayer === 'terrain') {
      newLayer = L.tileLayer(
        'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
        {
          attribution: 'Map data: © OpenStreetMap contributors, SRTM | Map style: © OpenTopoMap (CC-BY-SA)',
          maxZoom: 17,
          noWrap: false,
        }
      );
    } else {
      // Use standard OpenStreetMap tiles
      newLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
        noWrap: false,
      });
    }

    map.addLayer(newLayer);
    currentLayerRef.current = newLayer;

    return () => {
      if (currentLayerRef.current && map) {
        map.removeLayer(currentLayerRef.current);
        currentLayerRef.current = null;
      }
    };
  }, [map, darkMode, activeLayer]);

  // Add markers and clusters — uses diff-based updates to avoid destroying existing markers
  useEffect(() => {
    if (!markers || !map) return;

    if (!markerClusterGroupRef.current) {
      markerClusterGroupRef.current = L.markerClusterGroup({
        showCoverageOnHover: false,
        spiderfyOnMaxZoom: true,
        zoomToBoundsOnClick: true,
      });
      map.addLayer(markerClusterGroupRef.current);
    }

    const clusterGroup = markerClusterGroupRef.current;
    const existingLeafletMarkers = leafletMarkersRef.current;
    const currentDeviceIds = new Set(markers.map(m => m.device_id));

    // Remove markers that are no longer in the data
    existingLeafletMarkers.forEach((leafletMarker, deviceId) => {
      if (!currentDeviceIds.has(deviceId)) {
        clusterGroup.removeLayer(leafletMarker);
        existingLeafletMarkers.delete(deviceId);
        markerColorsRef.current.delete(deviceId);
        markerPositionsRef.current.delete(deviceId);
      }
    });

    // Add or update markers
    markers.forEach((marker) => {
      const latitude = marker.input?.latitude?.value;
      const longitude = marker.input?.longitude?.value;

      if (latitude === undefined || longitude === undefined) return;

      const existing = existingLeafletMarkers.get(marker.device_id);
      if (existing) {
        // Only update position when it actually changes — setLatLng()
        // triggers MarkerClusterGroup recalculation which can detach
        // the marker and close its popup
        const posKey = `${latitude},${longitude}`;
        if (markerPositionsRef.current.get(marker.device_id) !== posKey) {
          existing.setLatLng([latitude, longitude]);
          markerPositionsRef.current.set(marker.device_id, posKey);
        }

        // Only replace the icon when the color or selection state changes
        const isSelected = selectedMarker?.device_id === marker.device_id;
        const newColor = getMarkerColor(marker.lastUpdate);
        const prevColor = markerColorsRef.current.get(marker.device_id);
        const wasSelected = markerSelectedRef.current === marker.device_id;
        if (newColor !== prevColor || isSelected !== wasSelected) {
          existing.setIcon(createMarkerIcon(newColor, isSelected));
          markerColorsRef.current.set(marker.device_id, newColor);
        }
      } else {
        // Create a new marker for devices we haven't seen yet
        const isSelected = selectedMarker?.device_id === marker.device_id;
        const markerColor = getMarkerColor(marker.lastUpdate);
        const leafletMarker = L.marker([latitude, longitude], {
          icon: createMarkerIcon(markerColor, isSelected)
        })
          .on('click', (e) => {
            // Prevent event bubbling
            L.DomEvent.stopPropagation(e);

            // Select the new marker
            dispatch(selectMarker(marker.device_id));
            closeMenu();
          });

        existingLeafletMarkers.set(marker.device_id, leafletMarker);
        markerColorsRef.current.set(marker.device_id, markerColor);
        markerPositionsRef.current.set(marker.device_id, `${latitude},${longitude}`);
        clusterGroup.addLayer(leafletMarker);
      }
    });

    // Track which device is selected so we can detect selection changes
    markerSelectedRef.current = selectedMarker?.device_id ?? null;
  }, [markers, selectedMarker, dispatch, map, closeMenu, createMarkerIcon]);

  return null;
};

export default MapLayers;
