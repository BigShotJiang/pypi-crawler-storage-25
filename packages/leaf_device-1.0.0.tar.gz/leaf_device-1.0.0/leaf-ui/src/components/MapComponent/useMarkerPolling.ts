import { useEffect } from 'react';
import { useAppDispatch } from '../../store';
import { fetchMarkersThunk } from '../../api/markersApi';
import { POLLING_CONFIG } from '../../config';

/**
 * Custom hook to handle marker data fetching with polling.
 * Fetches markers on mount and sets up an interval for periodic updates.
 */
export function useMarkerPolling(): void {
  const dispatch = useAppDispatch();

  useEffect(() => {
    // Initial fetch
    dispatch(fetchMarkersThunk());
    
    // Set up polling interval
    const intervalId = setInterval(() => {
      dispatch(fetchMarkersThunk());
    }, POLLING_CONFIG.markersIntervalMs);
  
    // Clean up on unmount
    return () => clearInterval(intervalId);
  }, [dispatch]);
}
