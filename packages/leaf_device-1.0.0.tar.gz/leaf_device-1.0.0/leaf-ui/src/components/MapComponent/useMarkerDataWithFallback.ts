import { useEffect, useRef, useState } from 'react';
import { useAppDispatch, useAppSelector } from '../../store';
import { fetchMarkersThunk } from '../../api/markersApi';
import { DEV_MODE, POLLING_CONFIG } from '../../config';

/**
 * Custom hook that attempts SSE first and falls back to polling if SSE fails.
 * 
 * This handles cases where corporate firewalls (like Netskope) block SSE connections.
 * - First attempts to use SSE for real-time updates
 * - If SSE fails to connect or encounters errors, switches to polling
 * - Uses polling as a reliable fallback mechanism
 */
export function useMarkerDataWithFallback(): void {
  const dispatch = useAppDispatch();
  const { sseConnected, sseError } = useAppSelector((state) => state.markers);
  // In DEV_MODE skip SSE entirely and poll immediately
  const [usePolling, setUsePolling] = useState(DEV_MODE);
  const pollingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const sseCheckTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // If SSE is working, don't use polling
    if (sseConnected && !sseError) {
      console.log('Marker data: Using SSE (real-time)');
      setUsePolling(false);
      
      // Clear polling if it was running
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
        pollingIntervalRef.current = null;
      }
      return;
    }

    // Set a timeout to check if SSE connects successfully
    // If SSE doesn't connect within 5 seconds, fall back to polling
    if (!usePolling && !sseCheckTimeoutRef.current) {
      sseCheckTimeoutRef.current = setTimeout(() => {
        if (!sseConnected) {
          console.warn('Marker data: SSE failed to connect, falling back to polling');
          setUsePolling(true);
        }
      }, 5000);
    }

    // If there's an SSE error, immediately switch to polling
    if (sseError && !usePolling) {
      console.warn('Marker data: SSE error detected, switching to polling:', sseError);
      setUsePolling(true);
    }

    return () => {
      if (sseCheckTimeoutRef.current) {
        clearTimeout(sseCheckTimeoutRef.current);
        sseCheckTimeoutRef.current = null;
      }
    };
  }, [sseConnected, sseError, usePolling]);

  // Set up polling when needed
  useEffect(() => {
    if (!usePolling) return;

    console.log(`Marker data: Starting polling (interval: ${POLLING_CONFIG.markersIntervalMs}ms)`);
    
    // Initial fetch
    dispatch(fetchMarkersThunk());
    
    // Set up polling interval
    pollingIntervalRef.current = setInterval(() => {
      dispatch(fetchMarkersThunk());
    }, POLLING_CONFIG.markersIntervalMs);
  
    // Clean up on unmount or when switching back to SSE
    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
        pollingIntervalRef.current = null;
      }
    };
  }, [dispatch, usePolling]);
}
