import React, { useState, useRef, useEffect } from 'react';
import LayersIcon from '@mui/icons-material/Layers';
import IconButton from '@mui/material/IconButton';
import './LayersButton.css';

export type MapLayer = 'standard' | 'satellite' | 'terrain';

interface LayersButtonProps {
  selectedLayer: MapLayer;
  onLayerChange: (layer: MapLayer) => void;
}

/**
 * Circular button with dropdown for selecting map layers.
 * Positioned to the left of the settings menu button.
 */
const LayersButton: React.FC<LayersButtonProps> = ({ selectedLayer, onLayerChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleSelectLayer = (layer: MapLayer) => {
    onLayerChange(layer);
    setIsOpen(false);
  };

  return (
    <div className="layers-button-container" ref={containerRef}>
      <div className={`layers-button-circle ${selectedLayer !== 'standard' ? 'active' : ''}`}>
        <IconButton 
          aria-label="toggle-layers" 
          onClick={handleToggle}
          sx={{ color: 'white' }}
        >
          <LayersIcon fontSize="large" />
        </IconButton>
      </div>
      
      {isOpen && (
        <div className="layers-dropdown">
          <button 
            className={`layers-dropdown-item ${selectedLayer === 'standard' ? 'selected' : ''}`}
            onClick={() => handleSelectLayer('standard')}
          >
            Map
          </button>
          <button 
            className={`layers-dropdown-item ${selectedLayer === 'satellite' ? 'selected' : ''}`}
            onClick={() => handleSelectLayer('satellite')}
          >
            Satellite
          </button>
          <button 
            className={`layers-dropdown-item ${selectedLayer === 'terrain' ? 'selected' : ''}`}
            onClick={() => handleSelectLayer('terrain')}
          >
            Terrain
          </button>
        </div>
      )}
    </div>
  );
};

export default LayersButton;
