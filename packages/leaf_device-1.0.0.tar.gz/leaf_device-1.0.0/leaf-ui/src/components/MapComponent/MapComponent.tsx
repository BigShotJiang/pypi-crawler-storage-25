import React, { useEffect, useRef } from 'react';
import { MapContainer, ZoomControl, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet.markercluster/dist/MarkerCluster.Default.css';
import 'leaflet.markercluster/dist/MarkerCluster.css';
import './MapComponent.css';

import { useAppSelector } from '../../store';
import SidebarComponent from '../SidebarComponent/SidebarComponent';
import MapLayers from './MapLayers';
import MapEventHandler from './MapEventHandler';
import SelectedMarkerLabel from './SelectedMarkerLabel';
import { useMarkerSSE } from './useMarkerSSE';
import { useMarkerDataWithFallback } from './useMarkerDataWithFallback';
import { MapLayer } from './LayersButton';

// Configure Leaflet default marker icons
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});

interface MapComponentProps {
  closeMenu: () => void;
  activeLayer: MapLayer;
}

// Component to handle panning to coordinates
const PanToCoordinates: React.FC = () => {
  const map = useMap();
  const { panToCoords } = useAppSelector((state) => state.markers);

  useEffect(() => {
    if (map && panToCoords) {
      const currentZoom = map.getZoom();
      map.setView([panToCoords.latitude, panToCoords.longitude], currentZoom, {
        animate: true
      });
    }
  }, [map, panToCoords]);

  return null;
};

const MapComponent: React.FC<MapComponentProps> = ({ closeMenu, activeLayer }) => {
  const { markers, selectedMarker } = useAppSelector((state) => state.markers);

  // Set up real-time marker updates via SSE
  useMarkerSSE();
  
  // Fallback to polling if SSE fails (e.g., blocked by corporate firewall)
  useMarkerDataWithFallback();

  return (
    <MapContainer
      className="map-container"
      center={[37.09, -84.60]}
      worldCopyJump={true}
      maxBounds={[[-90, -180], [90, 180]]}
      maxBoundsViscosity={0.0}
      zoom={4}
      zoomControl={false}
      maxZoom={18}
      minZoom={3}
    >
      <PanToCoordinates />
      <ZoomControl position="bottomright" />
      <SidebarComponent selectedMarker={selectedMarker} />
      <SelectedMarkerLabel />
      <MapLayers markers={markers} closeMenu={closeMenu} activeLayer={activeLayer} />
      <MapEventHandler closeMenu={closeMenu} />
    </MapContainer>
  );
};

export default MapComponent;