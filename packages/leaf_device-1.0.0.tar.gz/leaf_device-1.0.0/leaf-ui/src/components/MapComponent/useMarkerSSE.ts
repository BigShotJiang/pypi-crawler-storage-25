import { useEffect, useRef, useCallback } from 'react';
import { useAppDispatch } from '../../store';
import { setMarkers, updateMarkers, setSSEConnected, setSSEError } from '../../store/markersSlice';
import { API_CONFIG, SSE_CONFIG } from '../../config';
import { Marker } from '../../types/marker';
import keycloak from '../../api/keycloak';

/** SSE message types from the backend */
interface SSEFullSync {
  type: 'full_sync';
  devices: Marker[];
  timestamp: number;
}

interface SSEBatchUpdate {
  type: 'batch_update';
  devices: Marker[];
  timestamp: number;
}

type SSEMessage = SSEFullSync | SSEBatchUpdate;

/**
 * Custom hook to handle real-time marker updates via Server-Sent Events.
 * 
 * - Connects to the SSE endpoint on mount
 * - Receives full_sync on initial connection (replaces all markers)
 * - Receives batch_update when devices change (merges into existing markers)
 * - Automatically reconnects on connection loss
 * - Falls back gracefully if SSE is not supported
 */
export function useMarkerSSE(): void {
  const dispatch = useAppDispatch();
  const eventSourceRef = useRef<EventSource | null>(null);
  const reconnectAttempts = useRef(0);
  const reconnectTimeoutRef = useRef<number | null>(null);

  const connect = useCallback(() => {
    // Don't reconnect if we've exceeded max attempts
    if (reconnectAttempts.current >= SSE_CONFIG.maxReconnectAttempts) {
      console.error('SSE: Max reconnection attempts reached');
      dispatch(setSSEError('Connection lost. Please refresh the page.'));
      return;
    }

    // Build SSE URL - backendUrl may be empty in dev mode (uses proxy)
    // or may include /api suffix in production
    const baseUrl = API_CONFIG.backendUrl.replace(/\/api\/?$/, '');
    const baseSSEUrl = `${baseUrl}/api/sensor-data/stream`;
    // Pass JWT as query param — browser EventSource cannot set headers
    const sseUrl = keycloak.token
      ? `${baseSSEUrl}?token=${encodeURIComponent(keycloak.token)}`
      : baseSSEUrl;
    
    console.log(`SSE: Connecting to ${baseSSEUrl}`);
    
    const eventSource = new EventSource(sseUrl);
    eventSourceRef.current = eventSource;

    eventSource.onopen = () => {
      console.log('SSE: Connected');
      reconnectAttempts.current = 0;
      dispatch(setSSEConnected(true));
      dispatch(setSSEError(null));
    };

    eventSource.onmessage = (event) => {
      try {
        const message: SSEMessage = JSON.parse(event.data);
        
        if (message.type === 'full_sync') {
          // Initial load or reconnection - replace all markers
          console.log(`SSE: Full sync received with ${message.devices.length} devices`);
          dispatch(setMarkers(message.devices));
        } else if (message.type === 'batch_update') {
          // Delta update - merge changed devices
          console.log(`SSE: Batch update received with ${message.devices.length} devices`);
          dispatch(updateMarkers(message.devices));
        }
      } catch (error) {
        console.error('SSE: Failed to parse message', error);
      }
    };

    eventSource.onerror = (error) => {
      console.error('SSE: Connection error', error);
      eventSource.close();
      eventSourceRef.current = null;
      dispatch(setSSEConnected(false));
      
      // Schedule reconnection
      reconnectAttempts.current += 1;
      const delay = SSE_CONFIG.reconnectDelayMs * Math.min(reconnectAttempts.current, 5);
      console.log(`SSE: Reconnecting in ${delay}ms (attempt ${reconnectAttempts.current})`);
      
      reconnectTimeoutRef.current = window.setTimeout(() => {
        connect();
      }, delay);
    };
  }, [dispatch]);

  useEffect(() => {
    // Check if EventSource is supported
    if (typeof EventSource === 'undefined') {
      console.warn('SSE: EventSource not supported, falling back to polling');
      dispatch(setSSEError('Real-time updates not supported in this browser'));
      return;
    }

    connect();

    // Cleanup on unmount
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
        eventSourceRef.current = null;
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [connect, dispatch]);
}
