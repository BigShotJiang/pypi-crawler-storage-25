import React from 'react';
import SearchIcon from '@mui/icons-material/Search';
import IconButton from '@mui/material/IconButton';
import './DeviceFinderButton.css';

interface DeviceFinderButtonProps {
  onDeviceFinderClick: () => void;
}

/**
 * Circular button for opening the device finder panel.
 * Positioned to the left of the analytics button.
 */
const DeviceFinderButton: React.FC<DeviceFinderButtonProps> = ({ onDeviceFinderClick }) => {

  const handleClick = () => {
    onDeviceFinderClick();
  };

  return (
    <div className="device-finder-button-container">
      <div className="device-finder-button-circle">
        <IconButton 
          aria-label="device-finder" 
          onClick={handleClick}
          sx={{ color: 'white' }}
        >
          <SearchIcon fontSize="large" />
        </IconButton>
      </div>
    </div>
  );
};

export default DeviceFinderButton;