import React from 'react';
import { useMap, useMapEvents } from 'react-leaflet';
import { useAppDispatch } from '../../store';
import { selectMarker } from '../../store/markersSlice';
import { closePreferenceModal } from '../../store/uiSlice';

interface MapEventHandlerProps {
  closeMenu: () => void;
}

/**
 * Handles map click and double-click events.
 * Must be rendered inside a MapContainer.
 */
const MapEventHandler: React.FC<MapEventHandlerProps> = ({ closeMenu }) => {
  const map = useMap();
  const dispatch = useAppDispatch();

  useMapEvents({
    click: (e) => {
      // Ignore clicks on the sidebar
      const target = e.originalEvent.target as HTMLElement;
      if (target.closest('.sidebar')) {
        return;
      }
      dispatch(selectMarker(null));
      dispatch(closePreferenceModal());
      closeMenu();
    },
    dblclick: (e) => {
      // Ignore double-clicks on the sidebar
      const target = e.originalEvent.target as HTMLElement;
      if (target.closest('.sidebar')) {
        return;
      }
      map.setZoom(map.getZoom() + 1);
    }
  });

  return null;
};

export default MapEventHandler;
