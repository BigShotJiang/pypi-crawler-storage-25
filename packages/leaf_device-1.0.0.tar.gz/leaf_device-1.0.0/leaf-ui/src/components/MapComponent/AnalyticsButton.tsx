import React from 'react';
import AnalyticsIcon from '@mui/icons-material/Analytics';
import IconButton from '@mui/material/IconButton';
import './AnalyticsButton.css';

interface AnalyticsButtonProps {
  onAnalyticsClick: () => void;
}

/**
 * Circular button for opening analytics/Grafana dashboard.
 * Positioned to the left of the layers button.
 */
const AnalyticsButton: React.FC<AnalyticsButtonProps> = ({ onAnalyticsClick }) => {

  const handleClick = () => {
    onAnalyticsClick();
  };

  return (
    <div className="analytics-button-container">
      <div className="analytics-button-circle">
        <IconButton 
          aria-label="analytics" 
          onClick={handleClick}
          sx={{ color: 'white' }}
        >
          <AnalyticsIcon fontSize="large" />
        </IconButton>
      </div>
    </div>
  );
};

export default AnalyticsButton;