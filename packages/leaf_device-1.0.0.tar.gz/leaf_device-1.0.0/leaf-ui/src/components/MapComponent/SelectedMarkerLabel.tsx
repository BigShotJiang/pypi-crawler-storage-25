import React, { useEffect, useState, useRef } from 'react';
import { useMap } from 'react-leaflet';
import { useAppSelector } from '../../store';
import './SelectedMarkerLabel.css';

/**
 * A pure CSS/HTML label that floats above the selected marker on the map.
 * Unlike Leaflet popups, this is a React-managed DOM element positioned
 * via CSS transforms — completely immune to marker/cluster DOM changes.
 */
const SelectedMarkerLabel: React.FC = () => {
  const map = useMap();
  const selectedMarker = useAppSelector((state) => state.markers.selectedMarker);
  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    if (!map || !selectedMarker) {
      setPosition(null);
      return;
    }

    const lat = selectedMarker.input?.latitude?.value;
    const lng = selectedMarker.input?.longitude?.value;
    if (lat === undefined || lng === undefined) {
      setPosition(null);
      return;
    }

    const updatePosition = () => {
      const point = map.latLngToContainerPoint([lat, lng]);
      setPosition({ x: point.x, y: point.y });
    };

    // Update immediately
    updatePosition();

    // Update on map move/zoom
    map.on('move', updatePosition);
    map.on('zoom', updatePosition);
    map.on('moveend', updatePosition);
    map.on('zoomend', updatePosition);

    return () => {
      map.off('move', updatePosition);
      map.off('zoom', updatePosition);
      map.off('moveend', updatePosition);
      map.off('zoomend', updatePosition);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [map, selectedMarker]);

  if (!selectedMarker || !position) return null;

  return (
    <div
      className="selected-marker-label"
      style={{
        transform: `translate(${position.x}px, ${position.y}px)`,
      }}
    >
      <div className="selected-marker-label-content">
        <span className="selected-marker-label-name">{selectedMarker.device_id}</span>
      </div>
      <div className="selected-marker-label-arrow" />
    </div>
  );
};

export default SelectedMarkerLabel;
