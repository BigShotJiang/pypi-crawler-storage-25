import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import {
  TextField,
  IconButton,
  InputAdornment,
  Typography,
  Menu,
  MenuItem,
  ListItemIcon as MuiListItemIcon,
} from '@mui/material';
import {
  Search as SearchIcon,
  Clear as ClearIcon,
  MoreVert as MoreVertIcon,
  Edit as EditIcon,
  ClearAll as ClearAliasIcon,
} from '@mui/icons-material';
import { useDispatch } from 'react-redux';
import { selectMarker, setPanToCoords } from '../../store/markersSlice';
import { setAlias, removeAlias } from '../../store/deviceAliasSlice';
import { useAppSelector } from '../../store/hooks';
import { getDisplayName } from '../../utils/deviceAlias';
import { Marker } from '../../types/marker';
import './DeviceFinderPanel.css';

interface DeviceFinderPanelProps {
  markers: Marker[];
}

type DeviceStatus = 'online' | 'stale' | 'offline';

const getDeviceStatus = (lastUpdate: number | undefined): DeviceStatus => {
  if (!lastUpdate) return 'offline';
  const diff = Date.now() - lastUpdate;
  if (diff < 5 * 60_000) return 'online';
  if (diff < 15 * 60_000) return 'stale';
  return 'offline';
};

const formatLastUpdate = (timestamp: number | undefined): string => {
  if (!timestamp) return 'No updates';
  const diff = Date.now() - timestamp;
  if (diff < 60_000) return 'Just now';
  if (diff < 3_600_000) {
    const mins = Math.floor(diff / 60_000);
    return `${mins} min ago`;
  }
  if (diff < 86_400_000) {
    const hours = Math.floor(diff / 3_600_000);
    return `${hours} hr ago`;
  }
  const days = Math.floor(diff / 86_400_000);
  return `${days} day${days > 1 ? 's' : ''} ago`;
};

const formatCoords = (marker: Marker): string => {
  const lat = marker.input?.latitude?.value;
  const lng = marker.input?.longitude?.value;
  if (lat == null || lng == null) return 'No location';
  return `${Number(lat).toFixed(3)}°, ${Number(lng).toFixed(3)}°`;
};

const DeviceFinderPanel: React.FC<DeviceFinderPanelProps> = ({
  markers,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const dispatch = useDispatch();
  const panelRef = useRef<HTMLDivElement>(null);
  const aliases = useAppSelector((state) => state.deviceAliases.aliases);

  // Context menu state
  const [menuAnchor, setMenuAnchor] = useState<null | HTMLElement>(null);
  const [menuDeviceId, setMenuDeviceId] = useState<string | null>(null);

  // Inline rename state
  const [renamingDeviceId, setRenamingDeviceId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const renameInputRef = useRef<HTMLInputElement>(null);

  // Auto-focus rename input
  useEffect(() => {
    if (renamingDeviceId && renameInputRef.current) {
      renameInputRef.current.focus();
      renameInputRef.current.select();
    }
  }, [renamingDeviceId]);

  // Filter markers by device_id AND alias
  const filteredMarkers = useMemo(() => {
    if (!searchQuery.trim()) return markers;
    const query = searchQuery.toLowerCase().trim();
    return markers.filter((marker) => {
      const alias = aliases[marker.device_id] || '';
      return (
        marker.device_id.toLowerCase().includes(query) ||
        alias.toLowerCase().includes(query)
      );
    });
  }, [markers, searchQuery, aliases]);

  const handleDeviceClick = useCallback(
    (deviceId: string) => {
      const selected = markers.find((m) => m.device_id === deviceId);
      if (selected?.input?.latitude?.value && selected?.input?.longitude?.value) {
        dispatch(
          setPanToCoords({
            latitude: selected.input.latitude.value,
            longitude: selected.input.longitude.value,
          })
        );
      }
      dispatch(selectMarker(deviceId));
    },
    [markers, dispatch]
  );

  // --- Context menu handlers ---
  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, deviceId: string) => {
    event.stopPropagation();
    setMenuAnchor(event.currentTarget);
    setMenuDeviceId(deviceId);
  };

  const handleMenuClose = () => {
    setMenuAnchor(null);
    setMenuDeviceId(null);
  };

  const handleStartRename = () => {
    if (!menuDeviceId) return;
    const currentName = getDisplayName(menuDeviceId, aliases);
    setRenameValue(currentName);
    setRenamingDeviceId(menuDeviceId);
    handleMenuClose();
  };

  const handleClearAlias = () => {
    if (menuDeviceId) dispatch(removeAlias(menuDeviceId));
    handleMenuClose();
  };

  const handleRenameSubmit = (deviceId: string) => {
    const trimmed = renameValue.trim();
    if (trimmed) {
      dispatch(setAlias({ deviceId, name: trimmed }));
    }
    setRenamingDeviceId(null);
  };

  const handleRenameCancel = () => {
    setRenamingDeviceId(null);
  };

  const handleRenameKeyDown = (e: React.KeyboardEvent, deviceId: string) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleRenameSubmit(deviceId);
    } else if (e.key === 'Escape') {
      handleRenameCancel();
    }
  };

  return (
    <div ref={panelRef} className="device-finder-panel open">
      {/* ── Header ── */}
      <div className="device-finder-header">
        <div className="device-finder-header-row">
          <img
            src={`${process.env.PUBLIC_URL}/leaf-logo.png`}
            alt="LEAF"
            className="device-finder-logo"
          />
          <span className="device-finder-count-badge">
            {filteredMarkers.length !== markers.length
              ? `${filteredMarkers.length} / ${markers.length}`
              : markers.length}
          </span>
        </div>

        {/* Search */}
        <TextField
          fullWidth
          variant="outlined"
          placeholder="Search devices..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="device-finder-search"
          size="small"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon sx={{ color: '#888' }} />
              </InputAdornment>
            ),
            endAdornment: searchQuery ? (
              <InputAdornment position="end">
                <IconButton
                  onClick={() => setSearchQuery('')}
                  size="small"
                  aria-label="clear search"
                >
                  <ClearIcon sx={{ fontSize: 18 }} />
                </IconButton>
              </InputAdornment>
            ) : null,
          }}
        />
      </div>

      {/* ── Card list ── */}
      <div className="device-finder-list">
        {filteredMarkers.length === 0 ? (
          <div className="device-finder-empty">
            <Typography variant="body1" sx={{ color: '#999', fontStyle: 'italic' }}>
              {searchQuery ? 'No devices found' : 'No devices available'}
            </Typography>
            <Typography variant="body2" sx={{ color: '#666', mt: 0.5 }}>
              {searchQuery
                ? 'Try a different search term'
                : 'No devices are currently connected'}
            </Typography>
          </div>
        ) : (
          filteredMarkers.map((marker) => {
            const status = getDeviceStatus(marker.lastUpdate);
            const displayName = getDisplayName(marker.device_id, aliases);
            const hasAlias = !!aliases[marker.device_id];

            return (
              <div
                key={marker.device_id}
                className="device-card"
                onClick={() =>
                  renamingDeviceId !== marker.device_id &&
                  handleDeviceClick(marker.device_id)
                }
              >
                {/* Status dot */}
                <div className={`device-card-status device-status-${status}`} />

                {/* Card body */}
                <div className="device-card-body">
                  {renamingDeviceId === marker.device_id ? (
                    <input
                      ref={renameInputRef}
                      className="device-card-rename-input"
                      value={renameValue}
                      onChange={(e) => setRenameValue(e.target.value)}
                      onKeyDown={(e) => handleRenameKeyDown(e, marker.device_id)}
                      onBlur={() => handleRenameSubmit(marker.device_id)}
                      onClick={(e) => e.stopPropagation()}
                    />
                  ) : (
                    <>
                      <span className="device-card-name">{displayName}</span>
                      {hasAlias && (
                        <span className="device-card-id">{marker.device_id}</span>
                      )}
                    </>
                  )}
                  <div className="device-card-meta">
                    <span className="device-card-location">{formatCoords(marker)}</span>
                    <span className="device-card-sep">·</span>
                    <span className="device-card-time">{formatLastUpdate(marker.lastUpdate)}</span>
                  </div>
                </div>

                {/* Three-dot menu */}
                <IconButton
                  className="device-card-menu-btn"
                  size="small"
                  onClick={(e) => handleMenuOpen(e, marker.device_id)}
                  aria-label="device options"
                >
                  <MoreVertIcon sx={{ fontSize: 20, color: '#888' }} />
                </IconButton>
              </div>
            );
          })
        )}
      </div>

      {/* ── ORNL Logo ── */}
      <div className="device-finder-ornl-footer">
        <img
          src={`${process.env.PUBLIC_URL}/ornl-logo.png`}
          alt="ORNL logo"
          className="device-finder-ornl-logo"
        />
      </div>

      {/* ── Context menu ── */}
      <Menu
        anchorEl={menuAnchor}
        open={Boolean(menuAnchor)}
        onClose={handleMenuClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        sx={{ zIndex: 10001 }}
        slotProps={{
          paper: {
            sx: {
              bgcolor: '#2a2a2a',
              color: '#e0e0e0',
              borderRadius: '8px',
              boxShadow: '0 4px 20px rgba(0,0,0,0.5)',
              minWidth: 160,
            },
          },
        }}
      >
        <MenuItem onClick={handleStartRename}>
          <MuiListItemIcon>
            <EditIcon sx={{ color: '#ccc', fontSize: 18 }} />
          </MuiListItemIcon>
          Rename
        </MenuItem>
        {menuDeviceId && aliases[menuDeviceId] && (
          <MenuItem onClick={handleClearAlias}>
            <MuiListItemIcon>
              <ClearAliasIcon sx={{ color: '#ccc', fontSize: 18 }} />
            </MuiListItemIcon>
            Clear Alias
          </MenuItem>
        )}
      </Menu>
    </div>
  );
};

export default DeviceFinderPanel;