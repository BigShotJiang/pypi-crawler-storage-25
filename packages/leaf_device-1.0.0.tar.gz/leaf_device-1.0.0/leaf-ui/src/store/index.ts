import { Action, configureStore, ThunkAction } from '@reduxjs/toolkit';
import markersReducer from './markersSlice';
import uiReducer from './uiSlice';
import deviceAliasReducer from './deviceAliasSlice';

const store = configureStore({
  reducer: {
    ui: uiReducer,
    markers: markersReducer,
    deviceAliases: deviceAliasReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
// Typed thunk action for your app
export type AppThunk<ReturnType = void> = ThunkAction<ReturnType, RootState, unknown, Action<string>>;

// Re-export hooks from hooks.ts for convenience
export { useAppDispatch, useAppSelector } from './hooks';

export default store;