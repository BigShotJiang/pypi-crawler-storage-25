import { createSlice, PayloadAction } from '@reduxjs/toolkit';

const STORAGE_KEY = 'deviceAliases';

interface DeviceAliasState {
  aliases: Record<string, string>;
}

const loadAliases = (): Record<string, string> => {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // Corrupted data — start fresh
  }
  return {};
};

const persistAliases = (aliases: Record<string, string>) => {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(aliases));
  } catch {
    // Storage full or unavailable — silently ignore
  }
};

const initialState: DeviceAliasState = {
  aliases: loadAliases(),
};

const deviceAliasSlice = createSlice({
  name: 'deviceAliases',
  initialState,
  reducers: {
    setAlias(state, action: PayloadAction<{ deviceId: string; name: string }>) {
      const { deviceId, name } = action.payload;
      const trimmed = name.trim();
      if (trimmed && trimmed !== deviceId) {
        state.aliases[deviceId] = trimmed;
      } else {
        // If alias matches device_id or is empty, remove it
        delete state.aliases[deviceId];
      }
      persistAliases(state.aliases);
    },
    removeAlias(state, action: PayloadAction<string>) {
      delete state.aliases[action.payload];
      persistAliases(state.aliases);
    },
  },
});

export const { setAlias, removeAlias } = deviceAliasSlice.actions;
export default deviceAliasSlice.reducer;
