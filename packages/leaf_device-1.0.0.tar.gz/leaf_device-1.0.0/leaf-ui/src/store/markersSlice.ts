import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Marker } from '../types/marker';
import { fetchMarkersThunk } from '../api/markersApi';

interface MarkersState {
  markers: Marker[];
  selectedMarker: Marker | null;
  panToCoords: { latitude: number; longitude: number } | null;
  loading: boolean;
  error: string | null;
  /** SSE connection status */
  sseConnected: boolean;
  /** SSE-specific error message */
  sseError: string | null;
}

const initialState: MarkersState = {
  markers: [],
  selectedMarker: null,
  panToCoords: null, 
  loading: false,
  error: null,
  sseConnected: false,
  sseError: null,
};

const markersSlice = createSlice({
  name: 'markers',
  initialState,
  reducers: {
    /** Replace all markers (used for full sync from SSE or initial load) */
    setMarkers: (state, action: PayloadAction<Marker[]>) => {
      state.markers = action.payload;
      // If selectedMarker exists, update its reference with new data
      if (state.selectedMarker) {
        const foundMarker = action.payload.find(
          marker => marker.device_id === state.selectedMarker?.device_id
        );
        state.selectedMarker = foundMarker || null;
      }
    },
    
    /** Merge updated markers into existing state (used for SSE delta updates) */
    updateMarkers: (state, action: PayloadAction<Marker[]>) => {
      const updatedDevices = action.payload;
      
      updatedDevices.forEach(updatedMarker => {
        const existingIndex = state.markers.findIndex(
          m => m.device_id === updatedMarker.device_id
        );
        
        if (existingIndex >= 0) {
          // Update existing marker
          state.markers[existingIndex] = updatedMarker;
        } else {
          // New device - add it
          state.markers.push(updatedMarker);
        }
        
        // Update selectedMarker if it matches
        if (state.selectedMarker?.device_id === updatedMarker.device_id) {
          state.selectedMarker = updatedMarker;
        }
      });
    },
    
    addMarkers: (state, action: PayloadAction<Marker | Marker[]>) => {
      // Append the new markers to the existing array of markers
      if (Array.isArray(action.payload)) {
        action.payload.forEach(element => {
          // This looks through the state.markers array for any marker that is equal to the element.deivice_id
          if (!state.markers.some(mark => (mark.device_id === element.device_id))) {
            state.markers.push(element);
          }
        });
      } else {
        state.markers.push(action.payload);
      }
    },
    selectMarker: (state, action: PayloadAction<string | null>) => {
      state.selectedMarker = state.markers.find(marker => marker.device_id === action.payload) || null;
    },
    setPanToCoords: (state, action: PayloadAction<{ latitude: number; longitude: number } | null>) => {
      state.panToCoords = action.payload;
    },
    
    /** Set SSE connection status */
    setSSEConnected: (state, action: PayloadAction<boolean>) => {
      state.sseConnected = action.payload;
    },
    
    /** Set SSE error message */
    setSSEError: (state, action: PayloadAction<string | null>) => {
      state.sseError = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchMarkersThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchMarkersThunk.fulfilled, (state, action: PayloadAction<Marker[]>) => {
        state.loading = false;
        state.markers = action.payload;
        // If selectedMarker exists, update its reference with new fetched data
        if (state.selectedMarker) {
          const foundMarker = action.payload.find(
              marker => marker.device_id === state.selectedMarker?.device_id
          );
          if (foundMarker) {
              state.selectedMarker = foundMarker; // Update the selected marker with fresh data
          } else {
              state.selectedMarker = null; // If not found in fetched markers, clear it
          }
        }
      })
      .addCase(fetchMarkersThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Failed to fetch markers';
      });
  },
});

export const { 
  setMarkers,
  updateMarkers,
  addMarkers, 
  selectMarker, 
  setPanToCoords,
  setSSEConnected,
  setSSEError,
} = markersSlice.actions;
export default markersSlice.reducer;