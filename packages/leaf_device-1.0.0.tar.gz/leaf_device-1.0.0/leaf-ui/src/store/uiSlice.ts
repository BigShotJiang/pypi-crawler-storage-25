import { createSlice, PayloadAction } from '@reduxjs/toolkit';

const UNIT_PREFS_KEY = 'unitPreferences';
const THEME_KEY = 'theme';

const DEFAULT_PREFERRED_UNITS: Record<string, string> = {
  temperature: '°C',
  pressure: 'psi',
  wind_speed: 'm/s',
  speed: 'm/s',
};

const loadUnitPreferences = (): Record<string, string> => {
  try {
    const raw = window.localStorage.getItem(UNIT_PREFS_KEY);
    if (raw) return { ...DEFAULT_PREFERRED_UNITS, ...JSON.parse(raw) };
  } catch {
    // Corrupted data — use defaults
  }
  return { ...DEFAULT_PREFERRED_UNITS };
};

const loadDarkMode = (): boolean => {
  try {
    return window.localStorage.getItem(THEME_KEY) === 'dark';
  } catch {
    return false;
  }
};

interface UIState {
  isPreferenceModalOpen: boolean;
  darkMode: boolean;
  preferredUnits: Record<string, string>;
}

const initialDarkMode = loadDarkMode();

const initialState: UIState = {
  isPreferenceModalOpen: false,
  darkMode: initialDarkMode,
  preferredUnits: loadUnitPreferences(),
};

// Apply persisted theme on load
if (initialDarkMode) {
  document.documentElement.setAttribute('data-theme', 'dark');
}

const uiSlice = createSlice({
  name: 'ui',
  initialState,
  reducers: {
    openPreferenceModal(state) {
      state.isPreferenceModalOpen = true;
    },
    closePreferenceModal(state) {
      state.isPreferenceModalOpen = false;
    },
    toggleDarkMode(state) {
      state.darkMode = !state.darkMode;
      const mode = state.darkMode ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', mode);
      window.localStorage.setItem(THEME_KEY, mode);
    },
    setPreferredUnit(state, action: PayloadAction<{ metricKey: string; unit: string }>) {
      const { metricKey, unit } = action.payload;
      state.preferredUnits[metricKey] = unit;
      try {
        window.localStorage.setItem(UNIT_PREFS_KEY, JSON.stringify(state.preferredUnits));
      } catch {
        // Storage unavailable
      }
    },
  },
});

export const { openPreferenceModal, closePreferenceModal, toggleDarkMode, setPreferredUnit } = uiSlice.actions;
export default uiSlice.reducer;