/// <reference types="react-scripts" />

declare namespace NodeJS {
    interface ProcessEnv {
        REACT_APP_KEYCLOAK_URL: string;
        REACT_APP_BACKEND_URL: string;
        REACT_APP_GRAFANA_URL: string;
        REACT_APP_WS_URL: string;
        // Add other environment variables as needed
    }
}