export interface Marker {
    device_id: string;
    input: {
        latitude: {
            datatype: string;
            value: number;
            unit: string;
        }
        longitude: {
            datatype: string;
            value: number;
            unit: string;
        }
        [key: string]: any; // This allows for additional dynamic properties
    };
    output: {
        [key: string]: any; // This allows for additional dynamic properties
    };
    lastUpdate?: number; // Timestamp of last message received
}