{{/*
Expand the name of the chart.
*/}}
{{- define "leaf.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "leaf.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "leaf.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "leaf.labels" -}}
helm.sh/chart: {{ include "leaf.chart" . }}
{{ include "leaf.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "leaf.selectorLabels" -}}
app.kubernetes.io/name: {{ include "leaf.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "leaf.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "leaf.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
LEAF UI fullname
*/}}
{{- define "leaf.leafUI.fullname" -}}
{{- printf "%s-ui" (include "leaf.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Backend fullname
*/}}
{{- define "leaf.backend.fullname" -}}
{{- printf "%s-backend" (include "leaf.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Mosquitto fullname
*/}}
{{- define "leaf.mosquitto.fullname" -}}
{{- printf "%s-mosquitto" (include "leaf.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
External Keycloak URL
*/}}
{{- define "leaf.keycloak.url" -}}
{{- .Values.externalAuth.keycloakUrl }}
{{- end }}

{{/*
Grafana fullname
*/}}
{{- define "leaf.grafana.fullname" -}}
{{- printf "%s-grafana" (include "leaf.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Redis fullname
*/}}
{{- define "leaf.redis.fullname" -}}
{{- printf "%s-redis" (include "leaf.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common image pull policy
*/}}
{{- define "leaf.imagePullPolicy" -}}
{{- if .Values.global.imageTag }}
{{- if eq .Values.global.imageTag "latest" }}
Always
{{- else }}
{{- .Values.image.pullPolicy }}
{{- end }}
{{- else }}
{{- .Values.image.pullPolicy }}
{{- end }}
{{- end }}

{{/*
Image registry helper
*/}}
{{- define "leaf.imageRegistry" -}}
{{- if .Values.global.imageRegistry }}
{{- .Values.global.imageRegistry }}
{{- else if .Values.image.registry }}
{{- .Values.image.registry }}
{{- end }}
{{- end }}

{{/*
Full image name for a component
Usage: {{ include "leaf.image" (dict "component" .Values.leafUI "global" .Values.global "registry" (include "leaf.imageRegistry" .)) }}
*/}}
{{- define "leaf.image" -}}
{{- $registry := .registry -}}
{{- $repository := .component.image.repository -}}
{{- $tag := .component.image.tag | default .global.imageTag | default "latest" -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" $registry $repository $tag -}}
{{- else -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}
{{- end }}

{{/*
Resource name for component
*/}}
{{- define "leaf.componentName" -}}
{{- printf "%s-%s" (include "leaf.fullname" .) .component | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Component labels
*/}}
{{- define "leaf.componentLabels" -}}
{{ include "leaf.labels" . }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/*
Component selector labels
*/}}
{{- define "leaf.componentSelectorLabels" -}}
{{ include "leaf.selectorLabels" . }}
app.kubernetes.io/component: {{ .component }}
{{- end }}