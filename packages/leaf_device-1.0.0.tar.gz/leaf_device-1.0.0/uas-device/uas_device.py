import time
import random
import math
import json
import yaml
import paho.mqtt.client as mqtt

BROKER = "mqtt-broker"
PORT = 1883

# Load drone configurations from YAML file
with open("devices.yml", "r") as file:
    config = yaml.safe_load(file)

# MQTT Topics
def get_topic(drone_uuid, data_type):
    return f"drones/{drone_uuid}/data/{data_type}"

# Function to generate random starting points within the defined radius
def generate_random_start_point(center_lat, center_lon, radius_km):
    radius_m = radius_km * 1000
    angle = random.uniform(0, 2 * math.pi)
    distance = random.uniform(0, radius_m)

    delta_lat = (distance / 111139) * math.cos(angle)
    delta_lon = (distance / (111139 * math.cos(math.radians(center_lat)))) * math.sin(angle)

    start_lat = center_lat + delta_lat
    start_lon = center_lon + delta_lon

    return start_lat, start_lon

# Callback function on connection
def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))

# Callback function on publish
def on_publish(client, userdata, mid):
    print(f"Message {mid} published.")

# Create an MQTT client instance
client = mqtt.Client()

# Assign the callback functions
client.on_connect = on_connect
client.on_publish = on_publish

# Connect to the broker with retries
while True:
    try:
        print("Attempting to connect to MQTT broker...")
        client.connect(BROKER, PORT, 60)
        break
    except ConnectionRefusedError:
        print("Connection refused, retrying in 5 seconds...")
        time.sleep(5)

# Start the loop
client.loop_start()

# Initialize drone states
drones = []
for drone_conf in config["drones"]:
    start_lat, start_lon = generate_random_start_point(
        drone_conf["latitude"], drone_conf["longitude"], drone_conf["radius_km"]
    )
    drones.append({
        "uuid": drone_conf["uuid"],
        "make": drone_conf.get("make", "Unknown"),
        "model": drone_conf.get("model", "Unknown"),
        "faa": drone_conf.get("faa_registration", "Unknown"),
        "center_lat": drone_conf["latitude"],
        "center_lon": drone_conf["longitude"],
        "radius_km": drone_conf["radius_km"],
        "current_angle": 0,
        "speed_kmh": drone_conf["speed_kmh"],
        "latitude": start_lat,
        "longitude": start_lon,
        "direction": drone_conf["direction"],
        "battery": 100,  # Initialize battery percentage
        "altitude": random.uniform(50, 150),  # Initialize altitude randomly
        "heading_dir": drone_conf.get("heading_deg", 0),
        "status": drone_conf.get("status", "Unknown")
    })

def calculate_heading(lat1, lon1, lat2, lon2):
    # Calculate the heading from lat1, lon1 to lat2, lon2
    d_lon = lon2 - lon1
    x = math.sin(math.radians(d_lon)) * math.cos(math.radians(lat2))
    y = math.cos(math.radians(lat1)) * math.sin(math.radians(lat2)) - (math.sin(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.cos(math.radians(d_lon)))
    heading = (math.degrees(math.atan2(x, y)) + 360) % 360
    return heading

def update_drone_battery_and_altitude(drone):
    # Simulate battery drain
    drone["battery"] = max(0, drone["battery"] - random.uniform(0.01, 0.1))

    # Simulate slight altitude changes
    altitude_change = random.uniform(-0.5, 0.5)
    drone["altitude"] = max(0, drone["altitude"] + altitude_change)

def update_drone_positions():
    for drone in drones:
        # Dither speed slightly
        drone["speed_kmh"] += random.uniform(-0.5, 0.5)
        drone["speed_kmh"] = max(0, drone["speed_kmh"])  # Ensure speed is not negative

        # Calculate the distance the drone travels in one second based on its speed
        distance_km = drone["speed_kmh"] / 3600

        # Determine the direction of rotation
        direction_multiplier = 1 if drone["direction"] == "clockwise" else -1

        # Increment the angle based on the distance covered
        delta_angle = direction_multiplier * (distance_km / drone["radius_km"])
        drone["current_angle"] = (drone["current_angle"] + delta_angle) % (2 * math.pi)

        # Calculate the new position based on the current angle
        new_latitude = drone["center_lat"] + (drone["radius_km"] / 111) * math.cos(drone["current_angle"])
        new_longitude = drone["center_lon"] + (drone["radius_km"] / (111 * math.cos(math.radians(drone["center_lat"])))) * math.sin(drone["current_angle"])

        # Calculate heading based on the change in coordinates
        drone["heading_dir"] = calculate_heading(drone["latitude"], drone["longitude"], new_latitude, new_longitude)

        # Update the drone's latitude and longitude
        drone["latitude"] = new_latitude
        drone["longitude"] = new_longitude

        # Update battery and altitude
        update_drone_battery_and_altitude(drone)

        # Construct the payload
        payload = {
            "id": {
                "unique_id": drone["uuid"],
                "make": drone["make"],
                "model": drone["model"],
                "faa": drone["faa"]
            },
            "gps_location": {
                "latitude": drone["latitude"],
                "longitude": drone["longitude"]
            },
            "battery": drone["battery"],
            "altitude": drone["altitude"],
            "speed": drone["speed_kmh"],
            "heading": drone["heading_dir"],
            "status": drone["status"]
        }

        # Define the topic
        topic = f"vehicle/uas/{drone['uuid']}"

        # Publish the message
        client.publish(topic, json.dumps(payload))
        print(f"Published to {topic}: {payload}")

# Run the update loop
try:
    while True:
        update_drone_positions()
        time.sleep(1)
except KeyboardInterrupt:
    print("Simulation stopped.")

client.loop_stop()
client.disconnect()