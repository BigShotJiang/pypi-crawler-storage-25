# LEAF: Low-power Environmental Framework

## Dynamic UI Generation
In order for the UI to display the information and controls for an asset, a device UI configuration file needs to be passed to LEAF. The config file lists all the sensor fields and UI control elements for the GUI to populate in the side panel when an asset is selected. The config file also links the UI elements to MQTT topics.

Take for example an asset composed of a temperature sensor and a remotely controlled light. Following the Sparkplug naming convention, the asset may send a birth message to the server using the following namespace:
```spBv1.0/bobs_temp_stations/NBIRTH/station1```

Here is an example part of a payload of a NBIRTH message (shown decoded into JSON):
```
...
    "metrics": [
      {
        "name": "temperature",
        "dataType": "double",
        "value": 22.5
      },
      {
        "name": "light",
        "dataType": "boolean",
        "value": false
      }
    ]
...
```
If we want to display the current temperature value and provide a button to control the light, the device config file might look like this:

*bobs_temp_stations.yaml:*
```
sensor-values:                  # The UI group of values to display
    - ui_type: "value_display"  # One of the built in LEAF UI widgets
      label: "Temperature"      # The text describing the display, an attribute of the widget
      dataType: "double"        # The type of the metric
      units: "C"                # The units to display the temperature in
      metric: "temperature"     # The mqtt metric to link to this display
controls:                       # The UI group of control elements.
    - ui_type: "simple_button"
      label: "light switch"
      metric: "light"
```
When the user selects an asset that is a `bobs_temp_stations` the side panel is generated to include a display of the temperature measurement and a button to switch the light on/off. LEAF contains many built-in display and control types, but other custom types can easily be added. This framework allows setup of customized implementations without having to write any code.

## System Design
### Units
The LEAF project uses the base and derived units from the SI system for all transmitted values
[(wikipedia reference)](https://en.wikipedia.org/wiki/International_System_of_Units#SI_base_units).
Other units can be viewed in the GUI, but any values passed from devices to the server and stored in the database must use m, s, kg, C, rad, etc.

### Server requirements
The LEAF server is a portable Docker image and can run on any general server hardware - AWS, Azure, even simple desktops and laptops. It does not rely on any particular server framework functions. Ubuntu is the main development target for the LEAF server, but there is nothing (known) preventing it from running on Windows or other Linux OS servers.

### Handling multiple radios
LEAF devices that run Linux use modem manager under the hood to prioritize which radio is used for communications. The priority from highest to lowest is: local (line-of-sight) radio, cell, the iridium satcoms.

### Development notes for repo management
Once LEAF reaches version 1.0, additional development should take place in forked repositories. Useful features that are developed in other projects can be contributed back to the original repo via pull requests. No project specific details, configurations, or information should be contained in the original repo. Like wise the project specific repos should contain as much config files and as little code as possible.
