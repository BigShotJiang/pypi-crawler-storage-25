"""Skill context-exposure analysis.

Background (cited from Claude Code's public Skills documentation):
    "skill descriptions are loaded into context so Claude knows what's
    available, but full skill content only loads when invoked"

    "a skill's body loads only when it's used, so long reference
    material costs almost nothing until you need it"

        https://code.claude.com/docs/en/skills

    Community reports describe setups where the full body ends up in
    context anyway:

        https://github.com/anthropics/claude-code/issues/14882

This module computes the gap between the two scenarios described above
*without* claiming which one applies to any given user. We measure the
ceiling.

Definitions (v0.1.x — symmetric content-only ratio):
    - promised load        = tokens for the ``description`` frontmatter
                             value only. This is the field the docs
                             call out as loaded at startup so Claude
                             knows when the skill applies.
    - worst-case load      = tokens for the SKILL.md body (markdown
                             content after frontmatter). This is what
                             would load on demand.
    - exposure multiplier  = body / description, per file and aggregate.

Both numerator and denominator are content tokens — no frontmatter
overhead, no name-vs-keys-and-delimiters asymmetry. A previous v0.1.0
formula compared full-file (frontmatter + body) tokens to (name +
description) field values — that ratio inflated the multiplier by
attributing all frontmatter weight to the numerator while the
denominator was only two YAML strings.

Only SKILL.md entrypoints are analyzed. CLAUDE.md / AGENTS.md,
slash-command prompts, subagents, and supporting files inside a skill
directory are not subject to the body-on-demand loading pattern in the
same way, so they are excluded.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from promptc.models import FileRole, ParsedFile
from promptc.tokens import count_tokens

ANTHROPIC_DOCS_URL = "https://code.claude.com/docs/en/skills"
COMMUNITY_ISSUE_URL = "https://github.com/anthropics/claude-code/issues/14882"

EXPOSURE_NARRATIVE = (
    "Claude Code's Skills documentation describes the loading model: skill "
    "descriptions load into context at session start so Claude knows what's "
    "available, while the full SKILL.md body loads only when the skill is "
    "invoked."
    f"\n  Docs:  {ANTHROPIC_DOCS_URL}"
    "\n"
    "\nCommunity reports describe setups where the full body ends up in "
    "context anyway."
    f"\n  Issue: {COMMUNITY_ISSUE_URL}"
    "\n"
    "\nThe multiplier above is the ceiling of your exposure in the second "
    "scenario. This tool makes no claim about whether that happens in your "
    "setup; it measures the upper bound."
)


@dataclass
class FileExposure:
    file_path: str
    name: str | None
    promised_tokens: int
    worst_case_tokens: int

    @property
    def has_promise(self) -> bool:
        return self.promised_tokens > 0

    @property
    def multiplier(self) -> float | None:
        """worst-case / promised. Returns None when promised is 0 (undefined)."""
        if self.promised_tokens == 0:
            return None
        return self.worst_case_tokens / self.promised_tokens


@dataclass
class ExposureReport:
    files: list[FileExposure] = field(default_factory=list)
    skills_without_description: list[str] = field(default_factory=list)

    @property
    def total_promised(self) -> int:
        return sum(f.promised_tokens for f in self.files)

    @property
    def total_worst_case(self) -> int:
        return sum(f.worst_case_tokens for f in self.files)

    @property
    def multiplier(self) -> float | None:
        if self.total_promised == 0:
            return None
        return self.total_worst_case / self.total_promised

    @property
    def skill_count(self) -> int:
        return len(self.files)

    def top_by_worst_case(self, n: int) -> list[FileExposure]:
        return sorted(self.files, key=lambda f: f.worst_case_tokens, reverse=True)[:n]


def _promised_tokens(parsed: ParsedFile) -> int:
    """Tokens for the frontmatter ``description`` field value only.

    Prefers the cached ``description_tokens`` on the parsed file; recomputes
    if cache is missing but description text is present.
    """
    if parsed.description_tokens is not None:
        return parsed.description_tokens
    if parsed.description is not None:
        return count_tokens(parsed.description)
    return 0


def analyze_exposure(files: list[ParsedFile]) -> ExposureReport:
    """Build an :class:`ExposureReport` over the SKILL files in ``files``.

    Non-skill files (instructions, prompts, agents, other) are loaded in
    full regardless and are excluded from this analysis.
    """
    report = ExposureReport()

    for parsed in files:
        if parsed.role is not FileRole.SKILL:
            continue

        promised = _promised_tokens(parsed)
        exposure = FileExposure(
            file_path=parsed.relative_path,
            name=parsed.name,
            promised_tokens=promised,
            worst_case_tokens=parsed.body_tokens,
        )
        report.files.append(exposure)

        if parsed.description is None:
            report.skills_without_description.append(parsed.relative_path)

    report.files.sort(key=lambda f: f.worst_case_tokens, reverse=True)
    return report
