"""Regression test: the canonical ingero_annotate.py lives ONLY in
python/ingero-annotate/. The 5 vendored copies (md5 2aed7ca2)
previously sat inside each adapter directory and drifted invisibly;
v0.19 Phase E.2 consolidated them, and this test pins the
consolidation so a future contributor cannot silently re-vendor.
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path


# Walk up from this test file to the repository root. The package
# layout is `<repo>/python/ingero-annotate/tests/this_file`, so two
# `parent` steps land at the package root and a third lands at
# `<repo>/python/`. We want `<repo>/`.
REPO_ROOT = Path(__file__).resolve().parents[3]
CANONICAL = REPO_ROOT / "python" / "ingero-annotate" / "ingero_annotate.py"


def test_canonical_module_exists() -> None:
    assert CANONICAL.is_file(), (
        f"canonical ingero_annotate.py missing at {CANONICAL}"
    )


def test_no_vendored_copies_in_adapter_dirs() -> None:
    """No adapter directory may carry its own ingero_annotate.py.

    Pre-v0.19, five adapters (pytorch-lightning, ray, hf-trainer,
    deepspeed, accelerate) each vendored an identical 296-line copy.
    Maintaining 5 copies of one library is the kind of footgun that
    quietly drifts. v0.19 Phase E.2 deleted them; this test pins
    the deletion.
    """
    integrations = REPO_ROOT / "examples" / "integrations"
    if not integrations.is_dir():
        # Some packaging layouts may not ship the integrations dir;
        # the canonical module is what matters. Skip gracefully.
        return
    offending: list[str] = []
    for d in integrations.iterdir():
        if not d.is_dir():
            continue
        local = d / "ingero_annotate.py"
        if local.is_file():
            offending.append(str(local.relative_to(REPO_ROOT)))
    assert not offending, (
        "vendored ingero_annotate.py copies still present in:\n  "
        + "\n  ".join(offending)
        + "\nDelete them and import from the ingero-annotate package."
    )


def test_canonical_module_is_well_formed() -> None:
    """The canonical module is non-empty and importable as text.

    A future packaging mistake (empty file, build cleared the module)
    would otherwise let this test suite pass with no actual code.
    """
    text = CANONICAL.read_text(encoding="utf-8")
    assert len(text) > 1000, f"canonical module is suspiciously small: {len(text)} bytes"
    # The module must expose AnnotationWriter (the public class) and
    # at least one of the protocol helpers. Pinning both catches a
    # broken build (empty file, partial copy) without being too
    # strict about every internal symbol.
    for sym in ("class AnnotationWriter", "def encode_annotation", "def validate_labels"):
        assert sym in text, f"canonical module is missing: {sym}"


def test_canonical_module_md5_stable() -> None:
    """Pin the md5 of the canonical module. A future edit MUST update
    this value deliberately; an unintended drift fails the test.

    The original 5 vendored copies all hashed to 2aed7ca2fc98cfbdfcd1611b7d86a03e.
    The canonical module is byte-identical at consolidation time.
    """
    h = hashlib.md5(CANONICAL.read_bytes()).hexdigest()
    # Recorded at consolidation time (v0.19 Phase E.2, 2026-05-24).
    expected = "2aed7ca2fc98cfbdfcd1611b7d86a03e"
    assert h == expected, (
        f"canonical module md5 drifted: got {h}, expected {expected}. "
        "Update this pin INTENTIONALLY when you change the module."
    )
