"""End-to-end install-and-use tests for the ingero-annotate package.

These tests simulate exactly what a user does on a fresh machine:

    pip install ingero-annotate
    python -c "from ingero_annotate import AnnotationWriter; ..."

with the agent's annotation socket on the other end. The tests run
`pip install` (not `python -m build` + extract; pip is the actual
distribution channel) against the source tree, then spawn a fresh
Python subprocess that:

  1. Imports `ingero_annotate` FROM THE INSTALLED LOCATION (the
     source tree is intentionally NOT on sys.path; if the wrong copy
     is imported, the assertion on `__file__` catches it).
  2. Stands up a Unix-domain socket server in a background thread.
  3. Uses the public API (`AnnotationWriter`, `encode_annotation`,
     `validate_labels`) to write annotations.
  4. Verifies the wire payload reached the server with the right
     NDJSON shape.

The test catches every category of release-day "doesn't work on the
first try" failure:

  - `pyproject.toml` is malformed (`pip install` would refuse).
  - Hatchling wheel target misses the module file (`pip install`
    succeeds but import fails).
  - Public symbols are renamed or removed (subprocess import fails).
  - The wire payload regresses (subprocess assertion fails).

A maintainer who ships a v0.1.1 (or any future release) and breaks
ANY of those will see this test fail in CI long before PyPI.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest


# python/ingero-annotate/tests/this_file -> 3x parent = repo root.
REPO_ROOT = Path(__file__).resolve().parents[3]
PKG_DIR = REPO_ROOT / "python" / "ingero-annotate"


def _have_pip() -> bool:
    return shutil.which("pip") is not None or shutil.which("pip3") is not None


# The driver script is run in a SEPARATE Python subprocess against the
# installed-target directory. It must not import anything from the
# source tree, so it self-contains everything (no helpers from this
# test file's scope are accessible).
DRIVER = textwrap.dedent(
    """
    import json
    import os
    import socket
    import sys
    import threading
    import time

    install_dir, sock_path = sys.argv[1], sys.argv[2]

    # Force imports to come from the installed-target dir ONLY.
    # We deliberately do NOT add the source tree to sys.path; the
    # test asserts on __file__ that the loaded module is the
    # installed one.
    sys.path.insert(0, install_dir)

    from ingero_annotate import (
        AnnotationWriter,
        encode_annotation,
        validate_labels,
    )
    import ingero_annotate as _mod

    # Print the resolved module path so the test can assert it landed
    # in the install dir, not in the source tree.
    print("MODULE_FILE:", _mod.__file__, flush=True)
    print("DRIVER_PID:", os.getpid(), flush=True)

    # Exercise the no-socket helpers first - encode_annotation and
    # validate_labels are part of the public API and would surface
    # an import-time crash from a partial-copy wheel.
    validate_labels({"step": "42", "request_id": "req-abc.123"})
    encoded = encode_annotation(
        labels={"step": "42", "request_id": "req-abc.123"},
        pid=os.getpid(),
        ts_ns=1_700_000_000_000_000_000,
    )
    assert isinstance(encoded, (bytes, bytearray, str)), (
        f"encode_annotation returned wrong type: {type(encoded)}"
    )
    print("ENCODE_LEN:", len(encoded), flush=True)

    # Stand up the UDS server before the writer connects.
    received = []
    ready = threading.Event()

    def serve():
        srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        srv.bind(sock_path)
        srv.listen(1)
        srv.settimeout(5.0)
        ready.set()
        try:
            conn, _ = srv.accept()
        finally:
            srv.close()
        with conn:
            conn.settimeout(5.0)
            buf = b""
            while len(received) < 1:
                try:
                    chunk = conn.recv(4096)
                except socket.timeout:
                    break
                if not chunk:
                    break
                buf += chunk
                while b"\\n" in buf:
                    line, buf = buf.split(b"\\n", 1)
                    received.append(line)

    t = threading.Thread(target=serve, daemon=True)
    t.start()
    if not ready.wait(2.0):
        sys.exit("server failed to bind in 2s")

    # Public-API smoke: open a writer, send one annotation, observe
    # the wire payload.
    writer = AnnotationWriter(socket_path=sock_path)
    try:
        writer.write({"step": "42", "request_id": "req-abc.123"}, pid=os.getpid())
    finally:
        writer.close()

    # Wait briefly for the server thread to drain.
    t.join(timeout=3.0)
    if not received:
        sys.exit("no annotation line received within 3s")

    # Echo the line back so the test can assert on the JSON shape.
    print("LINE:", received[0].decode("utf-8"), flush=True)
    """
)


@pytest.mark.skipif(not _have_pip(), reason="pip is required for this E2E test")
def test_pip_install_then_import_and_write(tmp_path: Path) -> None:
    """The full user flow: pip install -> import -> write -> verify."""
    install_dir = tmp_path / "site"
    install_dir.mkdir()

    # Step 1: real `pip install --target` against the package
    # directory. This goes through the build backend (hatchling),
    # builds a wheel, and installs it as if from PyPI. --no-deps
    # keeps the test hermetic.
    pip_cmd = [
        sys.executable,
        "-m",
        "pip",
        "install",
        "--target",
        str(install_dir),
        "--no-deps",
        "--quiet",
        "--disable-pip-version-check",
        str(PKG_DIR),
    ]
    result = subprocess.run(
        pip_cmd,
        capture_output=True,
        text=True,
        timeout=180,
    )
    if result.returncode != 0:
        pytest.fail(
            "`pip install` of the package failed. This is exactly the "
            "release-day blocker the test exists to catch.\n"
            f"stdout:\n{result.stdout}\n"
            f"stderr:\n{result.stderr}"
        )

    # Step 2: the wheel must have placed ingero_annotate.py in the
    # install target. Hatchling's wheel target ships the top-level
    # module; if pyproject.toml's `include` ever drifts, this fires.
    installed_module = install_dir / "ingero_annotate.py"
    if not installed_module.is_file():
        contents = sorted(p.name for p in install_dir.iterdir())
        pytest.fail(
            "pip install succeeded but ingero_annotate.py is missing "
            f"from {install_dir}. Contents: {contents}"
        )

    # Step 3: the dist-info dir must also be present (proves it
    # actually went through the wheel pipeline, not a copy).
    dist_info = list(install_dir.glob("ingero_annotate-*.dist-info"))
    assert dist_info, (
        f"no ingero_annotate-*.dist-info in {install_dir}; "
        "the install did not go through the wheel pipeline"
    )

    # Step 4: run the driver subprocess. It uses the installed
    # module exclusively. The subprocess inherits NO PYTHONPATH from
    # the test process (env=clean-ish) so the source tree cannot
    # accidentally shadow the installed copy.
    sock_path = str(tmp_path / "annotate.sock")
    driver_file = tmp_path / "driver.py"
    driver_file.write_text(DRIVER)

    # Strip any inherited PYTHONPATH that could point at the source
    # tree; pass the install dir explicitly via argv instead. PATH
    # and other env stay intact so the subprocess can find Python.
    env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}

    proc = subprocess.run(
        [sys.executable, str(driver_file), str(install_dir), sock_path],
        capture_output=True,
        text=True,
        timeout=30,
        env=env,
    )
    if proc.returncode != 0:
        pytest.fail(
            "driver subprocess failed (user-flow simulation broke).\n"
            f"argv: install_dir={install_dir} sock={sock_path}\n"
            f"stdout:\n{proc.stdout}\n"
            f"stderr:\n{proc.stderr}"
        )

    # Step 5: verify what the subprocess reported.
    lines = proc.stdout.splitlines()

    # 5a: the loaded module file MUST be the installed one. If the
    # subprocess imported from the source tree, the install was a
    # no-op and the test would silently lie about coverage.
    module_lines = [l for l in lines if l.startswith("MODULE_FILE:")]
    assert module_lines, f"driver did not print MODULE_FILE: {proc.stdout!r}"
    loaded_path = module_lines[0].split(":", 1)[1].strip()
    assert str(install_dir) in loaded_path, (
        f"driver imported the WRONG ingero_annotate module: "
        f"loaded {loaded_path!r}, expected one under {install_dir!r}"
    )

    # 5b: encode_annotation returned a non-empty payload (the
    # public helper is intact).
    encode_lines = [l for l in lines if l.startswith("ENCODE_LEN:")]
    assert encode_lines, "driver did not print ENCODE_LEN"
    assert int(encode_lines[0].split(":", 1)[1].strip()) > 0

    # 5c: a real NDJSON line crossed the wire. Parse and verify
    # the v0.17 wire-shape fields.
    line_lines = [l for l in lines if l.startswith("LINE:")]
    assert line_lines, f"driver did not print LINE: {proc.stdout!r}"
    wire = line_lines[0].split(":", 1)[1].strip()
    payload = json.loads(wire)
    assert "labels" in payload, f"missing labels: {payload}"
    assert payload["labels"]["step"] == "42"
    assert payload["labels"]["request_id"] == "req-abc.123"
    # pid on the wire must match the driver subprocess (NOT this
    # test process), since the writer ran inside the subprocess.
    driver_pid_lines = [l for l in lines if l.startswith("DRIVER_PID:")]
    assert driver_pid_lines, "driver did not print DRIVER_PID"
    driver_pid = int(driver_pid_lines[0].split(":", 1)[1].strip())
    assert payload.get("pid") == driver_pid, (
        f"wire pid {payload.get('pid')} != driver pid {driver_pid}"
    )


@pytest.mark.skipif(not _have_pip(), reason="pip is required for this E2E test")
def test_pip_install_from_sdist(tmp_path: Path) -> None:
    """sdist install path (pip falls back to sdist when no wheel
    matches the platform).

    Distributors and corporate gates sometimes prefer the sdist.
    If the source distribution is broken (missing files in
    `tool.hatch.build.targets.sdist.include`, etc.), the wheel
    test above still passes but a user on the sdist path is
    stuck. This test pins both paths.
    """
    pytest.importorskip("build", reason="`build` not installed; skip sdist E2E")
    import build  # noqa: F401

    dist_dir = tmp_path / "dist"
    dist_dir.mkdir()

    # Build the sdist. `--no-isolation` reuses the current Python
    # environment so the test does not require python3-venv on the
    # host (CI images often skip it). Hatchling is already on the
    # path of any environment that has `build` installed.
    try:
        import hatchling  # noqa: F401
    except ImportError:
        pytest.skip("hatchling not importable; cannot run --no-isolation build")

    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "build",
            "--sdist",
            "--no-isolation",
            "--outdir",
            str(dist_dir),
            str(PKG_DIR),
        ],
        capture_output=True,
        text=True,
        timeout=180,
    )
    if result.returncode != 0:
        pytest.fail(
            f"`python -m build --sdist --no-isolation` failed:\n"
            f"stdout:\n{result.stdout}\n"
            f"stderr:\n{result.stderr}"
        )

    sdists = list(dist_dir.glob("ingero_annotate-*.tar.gz")) + list(
        dist_dir.glob("ingero-annotate-*.tar.gz")
    )
    assert sdists, f"no sdist produced in {dist_dir}; files: {list(dist_dir.iterdir())}"

    # Install from the sdist into a clean target.
    install_dir = tmp_path / "site"
    install_dir.mkdir()
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--target",
            str(install_dir),
            "--no-deps",
            "--quiet",
            "--disable-pip-version-check",
            str(sdists[0]),
        ],
        capture_output=True,
        text=True,
        timeout=180,
    )
    if result.returncode != 0:
        pytest.fail(
            f"`pip install <sdist>` failed:\n"
            f"stdout:\n{result.stdout}\n"
            f"stderr:\n{result.stderr}"
        )

    assert (install_dir / "ingero_annotate.py").is_file(), (
        "sdist install did not deposit ingero_annotate.py"
    )

    # Quick import smoke from the installed location.
    env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    smoke = subprocess.run(
        [
            sys.executable,
            "-c",
            "import sys; sys.path.insert(0, sys.argv[1]); "
            "from ingero_annotate import AnnotationWriter, encode_annotation; "
            "import ingero_annotate; print(ingero_annotate.__file__)",
            str(install_dir),
        ],
        capture_output=True,
        text=True,
        timeout=15,
        env=env,
    )
    if smoke.returncode != 0:
        pytest.fail(
            f"sdist-installed import smoke failed:\n"
            f"stdout:\n{smoke.stdout}\n"
            f"stderr:\n{smoke.stderr}"
        )
    assert str(install_dir) in smoke.stdout, (
        f"sdist-installed module loaded from wrong path: {smoke.stdout!r}"
    )


@pytest.mark.skipif(not _have_pip(), reason="pip is required for this E2E test")
def test_pip_install_metadata_is_well_formed(tmp_path: Path) -> None:
    """The PyPI metadata that pip+twine read MUST parse cleanly.

    A malformed `pyproject.toml` (wrong classifier syntax, missing
    required field, license declared without license-files) often
    `pip install`s fine on the local machine but fails on
    twine upload. This test runs pip with `--dry-run` if available
    OR a minimal metadata-only build to catch those issues before
    they hit PyPI.
    """
    install_dir = tmp_path / "site"
    install_dir.mkdir()

    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--target",
            str(install_dir),
            "--no-deps",
            "--quiet",
            "--disable-pip-version-check",
            str(PKG_DIR),
        ],
        capture_output=True,
        text=True,
        timeout=180,
    )
    if result.returncode != 0:
        pytest.fail(
            "metadata install failed - pyproject.toml is likely malformed:\n"
            f"stdout:\n{result.stdout}\n"
            f"stderr:\n{result.stderr}"
        )

    # The dist-info dir is what pip / twine / pypi.org actually use.
    # Parse the METADATA file and verify the v0.1.0 fields are sane.
    dist_info = list(install_dir.glob("ingero_annotate-*.dist-info"))
    assert dist_info, f"no dist-info in {install_dir}"
    metadata = (dist_info[0] / "METADATA").read_text(encoding="utf-8")

    # The header lines pip parses are case-sensitive; assert the
    # essentials are present and shaped correctly.
    required_lines = [
        "Metadata-Version:",
        "Name: ingero-annotate",
        "Version: ",
        "Summary: ",
        "Requires-Python:",
    ]
    for needle in required_lines:
        assert needle in metadata, (
            f"METADATA missing required field {needle!r}; "
            "PyPI upload will reject or warn"
        )
