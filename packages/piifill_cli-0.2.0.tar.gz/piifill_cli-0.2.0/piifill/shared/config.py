from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    log_level: str = "INFO"
    log_file: str = "piifill.log"
    supported_extensions: List[str] = [
        "txt", "json", "csv", "sql", "pdf", "docx", "png", "jpg", "jpeg", "xlsx"
    ]
    default_mask_style: str = "redact" # redact, mask, tokenize
    language: str = "en"

    class Config:
        env_prefix = "PIIFILL_"

settings = Settings()
