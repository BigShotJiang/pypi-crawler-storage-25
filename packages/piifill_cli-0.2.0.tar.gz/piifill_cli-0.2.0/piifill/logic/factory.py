from .parsers import IParser

class FileProcessor:
    """Factory to create the correct parser based on file extension."""
    _parser_map = {
        'txt': 'TextParser',
        'json': 'JSONParser',
        'jsonl': 'JSONLParser',
        'csv': 'CSVParser',
        'sql': 'SQLParser',
        'pdf': 'PDFParser',
        'docx': 'DocxParser',
        'png': 'ImageParser',
        'jpg': 'ImageParser',
        'jpeg': 'ImageParser',
        'xlsx': 'XLSXParser'
    }
    _instances = {}
    
    @staticmethod
    def get_parser(extension: str) -> IParser:
        """
        Returns a parser instance for the given extension.
        Falls back to TextParser.
        """
        ext = extension.lower().replace('.', '')
        parser_name = FileProcessor._parser_map.get(ext, 'TextParser')
        
        if parser_name not in FileProcessor._instances:
            # Lazy import to avoid circular dependencies and heavy startup
            if parser_name == 'ImageParser':
                from .vision import ImageParser
                FileProcessor._instances[parser_name] = ImageParser()
            else:
                from .parsers import TextParser, JSONParser, JSONLParser, CSVParser, SQLParser, PDFParser, DocxParser, XLSXParser
                parsers = {
                    'TextParser': TextParser,
                    'JSONParser': JSONParser,
                    'JSONLParser': JSONLParser,
                    'CSVParser': CSVParser,
                    'SQLParser': SQLParser,
                    'PDFParser': PDFParser,
                    'DocxParser': DocxParser,
                    'XLSXParser': XLSXParser
                }
                FileProcessor._instances[parser_name] = parsers[parser_name]()
                
        return FileProcessor._instances[parser_name]
