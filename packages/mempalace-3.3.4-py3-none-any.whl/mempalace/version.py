"""Single source of truth for the MemPalace package version."""

__version__ = "3.3.4"
