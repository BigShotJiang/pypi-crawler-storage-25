"""CompactionPipeline: segmentation, compaction, and storage.

Extracted from engine.py — handles Phase 2 of turn processing (compact_if_needed),
manual compaction (compact_manual), and the shared compaction core (_run_compaction).
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from typing import TYPE_CHECKING

from .engine_utils import extract_turn_pairs
from .store import ContextStore
from .turn_tag_index import TurnTagIndex

if TYPE_CHECKING:
    from .compactor import DomainCompactor
    from .segmenter import TopicSegmenter
    from .semantic_search import SemanticSearchManager
    from .telemetry import TelemetryLedger
    from ..types import (
        CompactionReport,
        CompactionResult,
        CompactionSignal,
        EngineState,
        CanonicalTurnRow,
        Message,
        SegmentMetadata,
        StoredSegment,
        VirtualContextConfig,
    )

logger = logging.getLogger(__name__)

# Lazy-import for _is_stub_content from engine to avoid circular imports.
_is_stub_content_fn: Callable[[str], bool] | None = None


def _ensure_engine_imports() -> None:
    """Lazy-import module-level symbols from engine to avoid circular imports."""
    global _is_stub_content_fn
    if _is_stub_content_fn is None:
        from ..engine import _is_stub_content as _stub
        _is_stub_content_fn = _stub


class CompactionPipeline:
    """Segmentation, compaction, storage, and tag summary building.

    Owns the ``compact_if_needed`` and ``compact_manual`` entry points as well
    as the shared ``_run_compaction`` core that both call.

    Constructor dependencies mirror what the engine previously wired internally.
    """

    def __init__(
        self,
        compactor: DomainCompactor | None,
        segmenter: TopicSegmenter,
        store: ContextStore,
        turn_tag_index: TurnTagIndex,
        engine_state: EngineState,
        config: VirtualContextConfig,
        supersession_checker,
        fact_curator,
        semantic: SemanticSearchManager,
        telemetry: TelemetryLedger,
        save_state_callback: Callable,
        session_state_provider=None,
        worker_id: str | None = None,
    ) -> None:
        self._compactor = compactor
        self._segmenter = segmenter
        self._store = store
        self._turn_tag_index = turn_tag_index
        self._engine_state = engine_state
        self._config = config
        self._supersession_checker = supersession_checker
        self._fact_curator = fact_curator
        self._semantic = semantic
        self._telemetry = telemetry
        self._save_state_callback = save_state_callback
        self._session_state_provider = session_state_provider
        # Per-write ownership guard: the worker identity seeded at construction
        # (or set post-construction by the caller). ProxyState writes its own
        # self._worker_id here after construction so store_segment guards can
        # scope every write to the live compaction_operation row.
        self._worker_id: str | None = worker_id

    def _load_compactable_rows(self) -> tuple[list["CanonicalTurnRow"], list["Message"]]:
        from ..types import Message

        rows = list(
            self._store.get_uncompacted_canonical_turns(
                self._config.conversation_id,
                protected_recent_turns=self._config.monitor.protected_recent_turns,
            )
        )
        messages: list[Message] = []
        for row in rows:
            messages.append(Message(role="user", content=row.user_content))
            messages.append(Message(role="assistant", content=row.assistant_content))
        return rows, messages

    def _refresh_compaction_watermark(self) -> None:
        rows = list(self._store.get_all_canonical_turns(self._config.conversation_id))
        if not rows:
            self._engine_state.compacted_prefix_messages = 0
            self._engine_state.last_compacted_turn = -1
            return
        explicit_groups = [
            int(getattr(row, "turn_group_number"))
            if getattr(row, "turn_group_number", None) is not None
            else -1
            for row in rows
        ]
        if rows and all(group >= 0 for group in explicit_groups):
            grouped_rows: list[tuple[int, list["CanonicalTurnRow"]]] = []
            grouped_by_turn: dict[int, list["CanonicalTurnRow"]] = {}
            for row, turn_group_number in zip(rows, explicit_groups, strict=False):
                grouped_by_turn.setdefault(turn_group_number, []).append(row)
            grouped_rows = sorted(grouped_by_turn.items(), key=lambda item: item[0])
        else:
            grouped_rows = []
            pending: list["CanonicalTurnRow"] = []

            def _flush_pending() -> None:
                nonlocal pending
                if not pending:
                    return
                grouped_rows.append((len(grouped_rows), list(pending)))
                pending = []

            for row in rows:
                has_user = bool(getattr(row, "user_content", ""))
                has_assistant = bool(getattr(row, "assistant_content", ""))
                if has_user and has_assistant:
                    _flush_pending()
                    grouped_rows.append((len(grouped_rows), [row]))
                    continue
                if has_user:
                    _flush_pending()
                    pending = [row]
                    continue
                if has_assistant:
                    if pending:
                        pending.append(row)
                        _flush_pending()
                    else:
                        grouped_rows.append((len(grouped_rows), [row]))
                    continue
                _flush_pending()
            _flush_pending()

        last_prefix_turn = -1
        for turn_number, group_rows in grouped_rows:
            if group_rows and all(getattr(row, "compacted_at", None) for row in group_rows):
                last_prefix_turn = turn_number
                continue
            break
        if last_prefix_turn < 0:
            self._engine_state.compacted_prefix_messages = 0
            self._engine_state.last_compacted_turn = -1
            return
        self._engine_state.compacted_prefix_messages = (last_prefix_turn + 1) * 2
        self._engine_state.last_compacted_turn = last_prefix_turn

    # ------------------------------------------------------------------
    # Public entry points
    # ------------------------------------------------------------------

    def compact_if_needed(
        self,
        conversation_history: list[Message],
        signal: CompactionSignal,
        progress_callback: Callable[..., None] | None = None,
        turn_id: str = "",
        operation_id: str | None = None,
        *,
        preexisting_operation_id: str | None = None,
    ) -> CompactionReport | None:
        """Phase 2 of turn processing: run compaction.

        Slow (~10s with LLM summarizer). Can run in background after
        tag_turn() completes — the next request only needs the tag index.

        *signal*: the CompactionSignal returned by tag_turn().
        *operation_id*: the compaction_operation PK for the per-write ownership
        guard.  When provided (along with ``self._worker_id``), every
        ``store_segment`` call is scoped to the active compaction row — stale
        writes raise ``CompactionLeaseLost`` instead of inserting silently.
        *preexisting_operation_id*: when set by the takeover path, overrides
        *operation_id* so all downstream guarded writes use the pre-inserted
        row's id rather than a freshly generated one.
        """
        if preexisting_operation_id is not None:
            operation_id = preexisting_operation_id
        _t_compact = time.monotonic()

        if self._compactor is None:
            logger.warning(
                "Compaction triggered but no LLM provider configured. "
                "Configure a provider in the providers section."
            )
            return None

        logger.info(
            f"Compaction triggered ({signal.priority}): "
            f"{signal.current_tokens}/{signal.budget_tokens} tokens, "
            f"overflow={signal.overflow_tokens}"
        )

        compact_rows, compact_messages = self._load_compactable_rows()

        if not compact_messages:
            logger.info(
                "Compaction skipped: no uncompacted canonical turns outside protected zone "
                "(history=%d msgs, protected=%d turns, compacted_prefix_messages=%d)",
                len(conversation_history),
                self._config.monitor.protected_recent_turns,
                self._engine_state.compacted_prefix_messages,
            )
            return None

        logger.info(
            "Compacting %d canonical turns (%d messages, first_turn=%d, last_turn=%d, watermark=%d)",
            len(compact_rows),
            len(compact_messages),
            compact_rows[0].turn_number if compact_rows else -1,
            compact_rows[-1].turn_number if compact_rows else -1,
            self._engine_state.compacted_prefix_messages,
        )
        report = self._run_compaction(
            conversation_history,
            compact_messages,
            compact_rows=compact_rows,
            progress_callback=progress_callback,
            generated_by_turn_id=turn_id,
            operation_id=operation_id,
        )

        self._engine_state.last_compact_ms = round((time.monotonic() - _t_compact) * 1000, 1)
        self._commit_compaction_state(conversation_history)
        return report

    def compact_manual(
        self,
        conversation_history: list[Message],
        turn_id: str = "",
        operation_id: str | None = None,
    ) -> CompactionReport | None:
        """Trigger manual compaction regardless of thresholds.

        Uses the same pipeline as on_turn_complete: respects the compaction
        watermark, protected recent turns, advances the watermark, stores
        segments, and rebuilds tag summaries for affected tags.
        *operation_id*: see ``compact_if_needed`` for ownership-guard semantics.
        """
        if self._compactor is None:
            logger.warning("No LLM provider configured for compaction")
            return None

        if not conversation_history:
            return None

        compact_rows, compact_messages = self._load_compactable_rows()
        if not compact_messages:
            return None

        report = self._run_compaction(
            conversation_history,
            compact_messages,
            compact_rows=compact_rows,
            generated_by_turn_id=turn_id,
            operation_id=operation_id,
        )

        self._commit_compaction_state(conversation_history)
        return report

    # ------------------------------------------------------------------
    # Internal pipeline
    # ------------------------------------------------------------------

    def _propagate_tool_output_links(
        self, segment_ref: str, turn_start: int, turn_end: int,
    ) -> None:
        """Copy turn-level tool output links to the segment join table.

        Iterates turns in ``[turn_start, turn_end)`` and for each turn that
        has ``turn_tool_outputs`` entries, writes a corresponding
        ``segment_tool_outputs`` row.  Non-critical — failures are silenced.
        """
        try:
            for t in range(turn_start, turn_end):
                refs = self._store.get_tool_outputs_for_turn(
                    self._config.conversation_id, t,
                )
                for ref in refs:
                    self._store.link_segment_tool_output(
                        self._config.conversation_id, segment_ref, ref,
                    )
        except Exception:
            pass  # non-critical

    def _run_compaction(
        self,
        conversation_history: list[Message],
        compact_messages: list[Message],
        *,
        compact_rows: list["CanonicalTurnRow"] | None = None,
        progress_callback: Callable[..., None] | None = None,
        generated_by_turn_id: str = "",
        operation_id: str | None = None,
        preexisting_operation_id: str | None = None,
    ) -> CompactionReport:
        """Shared compaction core: segment, compact, store, build tag summaries.

        Called by both ``compact_if_needed`` (threshold-triggered) and
        ``compact_manual`` (explicit) after their respective guard checks
        have selected *compact_messages*.

        *operation_id*: when provided alongside ``self._worker_id``, every
        ``store_segment`` call carries the ownership guard kwargs so a stale
        write raises ``CompactionLeaseLost`` before it persists.
        *preexisting_operation_id*: takeover path override; takes precedence
        over *operation_id* when set.

        Returns a CompactionReport (never None — callers handle None guards).
        """
        if preexisting_operation_id is not None:
            operation_id = preexisting_operation_id
        from ..types import CompactionReport

        compact_rows = list(compact_rows or [])

        turn_offset = compact_rows[0].turn_number if compact_rows else (self._engine_state.compacted_prefix_messages // 2)

        def _emit_weighted_progress(
            done: int,
            total: int,
            result,
            *,
            phase: str,
            phase_name: str,
            base_percent: int,
            span_percent: int,
            **kwargs,
        ) -> None:
            if not progress_callback:
                return
            progress_fraction = kwargs.pop("progress_fraction", 0.0)
            bounded_total = max(total, 1)
            bounded_done = max(0, min(done, bounded_total))
            if progress_fraction:
                bounded_done = min(
                    float(bounded_total),
                    float(bounded_done) + max(0.0, min(float(progress_fraction), 0.999)),
                )
            overall_percent = base_percent + int(span_percent * bounded_done / bounded_total)
            progress_callback(
                done,
                total,
                result,
                phase=phase,
                overall_percent=overall_percent,
                phase_name=phase_name,
                **kwargs,
            )

        _segmenter_phase_ranges = {
            "segment_tagging": (0, 12),
            "segment_grouping": (12, 10),
            "segment_postprocess": (22, 3),
        }

        def _segmenter_progress(done: int, total: int, result, **kwargs) -> None:
            phase_name = str(kwargs.pop("phase_name", "segment_tagging"))
            base_percent, span_percent = _segmenter_phase_ranges.get(
                phase_name, (0, 25),
            )
            _emit_weighted_progress(
                done,
                total,
                result,
                phase=phase_name,
                phase_name=phase_name,
                base_percent=base_percent,
                span_percent=span_percent,
                **kwargs,
            )

        # Phase 1: Segmenter (0-25%)
        segments = self._segmenter.segment(
            compact_messages,
            turn_offset=turn_offset,
            progress_callback=_segmenter_progress,
        )
        logger.info(
            "Segmented %d messages into %d segments (watermark=%d)",
            len(compact_messages), len(segments), self._engine_state.compacted_prefix_messages,
        )

        # Phase 2+3: Compact + Store (25-75%)
        results = self._compact_and_store(
            segments,
            len(compact_messages),
            compact_rows=compact_rows,
            progress_callback=progress_callback,
            generated_by_turn_id=generated_by_turn_id,
            operation_id=operation_id,
        )

        compacted_turn_ids = [
            row.canonical_turn_id
            for row in compact_rows
            if getattr(row, "canonical_turn_id", "")
        ]
        if compacted_turn_ids:
            self._store.mark_canonical_turns_compacted(
                self._config.conversation_id,
                compacted_turn_ids,
                operation_id=operation_id,
                owner_worker_id=self._worker_id,
                lifecycle_epoch=(
                    int(self._engine_state.lifecycle_epoch)
                    if operation_id is not None and self._worker_id is not None
                    else None
                ),
            )
        if compact_rows:
            self._refresh_compaction_watermark()

        tokens_freed = sum(r.original_tokens - r.summary_tokens for r in results)
        tags = list({tag for r in results for tag in r.tags})

        # Build/update tag summaries — only for tags in newly compacted segments
        tag_summaries_built, cover_tags = self._build_tag_summaries(
            results=results,
            compact_rows=compact_rows,
            operation_id=operation_id,
            generated_by_turn_id=generated_by_turn_id,
            progress_callback=progress_callback,
        )

        report = CompactionReport(
            segments_compacted=len(results),
            tokens_freed=tokens_freed,
            tags=tags,
            results=results,
            tag_summaries_built=tag_summaries_built,
            cover_tags=cover_tags,
        )

        self._refresh_shared_retrieval_snapshots()

        return report

    def _build_tag_summaries(
        self,
        *,
        results: list,
        compact_rows: list | None,
        operation_id: str | None,
        generated_by_turn_id: str = "",
        progress_callback: Callable[..., None] | None = None,
    ) -> tuple[int, list[str]]:
        """Build and persist tag summaries for the just-compacted segments.

        Returns ``(count_built, cover_tags)`` so callers (``_run_compaction``)
        can populate the resulting ``CompactionReport``.

        Cover-tag derivation:

        * Intersect ``compute_cover_set`` (greedy on the in-memory tag index)
          with the set of tags carried by ``results``. Then apply the
          primary-tag guarantee so every result's ``primary_tag`` is included
          in ``cover_tags`` even if the greedy set-cover dropped it.

        Turn-data sourcing for ``compact_tag_summaries`` (``tag_to_turns`` +
        ``tag_to_canonical_turn_ids`` + ``max_turn``):

        * Prefer the in-memory ``_turn_tag_index.entries`` (normal
          request-driven path). The index carries the same per-turn tags
          the tagger produced.
        * Fall back to deriving the maps from ``compact_rows`` when the
          index is empty (cold-start / takeover compactions). Each
          ``CanonicalTurnRow`` carries its own ``turn_number`` +
          ``canonical_turn_id`` + ``tags`` + ``primary_tag``, so the data
          is equivalent for the compactor's per-tag summary builder. The
          fallback closes a gap where takeover compactions with an empty
          in-memory index silently skipped tag-summary building even
          though ``cover_tags`` was correctly populated.

        Caller contract: invoke once per compaction pass with the
        ``results`` and ``compact_rows`` produced upstream.
        """
        if not (results and self._compactor):
            return 0, []

        # Greedy cover from the in-memory tag index, intersected with the
        # tags carried by newly compacted segments.
        compacted_tags = {tag for r in results for tag in r.tags}
        cover_tags: list[str] = [
            t for t in self._turn_tag_index.compute_cover_set()
            if t in compacted_tags
        ]
        # Primary tag guarantee: ensure every segment's primary_tag gets a
        # tag summary, even if the greedy set cover dropped it. Without
        # this, ephemeral topics (2-3 turns) lose their most specific tag
        # to broader tags that cover more segments.
        cover_set = set(cover_tags)
        for r in results:
            if r.primary_tag and r.primary_tag not in cover_set:
                cover_tags.append(r.primary_tag)
                cover_set.add(r.primary_tag)
        if not cover_tags:
            return 0, []

        # Gather segment summaries per cover tag (input to the compactor's
        # per-tag summary builder).
        tag_to_summaries: dict[str, list] = {}
        for tag in cover_tags:
            summaries = self._store.get_summaries_by_tags(
                tags=[tag], min_overlap=1, limit=50,
                conversation_id=self._config.conversation_id,
            )
            if summaries:
                tag_to_summaries[tag] = summaries

        # Gather turn numbers + canonical_turn_ids per cover tag, plus
        # ``max_turn``. Prefer the in-memory index; fall back to the
        # compact_rows source when the index is empty.
        tag_to_turns: dict[str, list[int]] = {}
        tag_to_canonical_turn_ids: dict[str, list[str]] = {}
        if self._turn_tag_index.entries:
            for entry in self._turn_tag_index.entries:
                for tag in entry.tags:
                    if tag in cover_tags:
                        tag_to_turns.setdefault(tag, []).append(entry.turn_number)
                        if entry.canonical_turn_id:
                            tag_to_canonical_turn_ids.setdefault(tag, []).append(
                                entry.canonical_turn_id,
                            )
            max_turn = max(e.turn_number for e in self._turn_tag_index.entries)
        else:
            for row in compact_rows or []:
                row_tags = set(getattr(row, "tags", None) or [])
                row_primary = getattr(row, "primary_tag", "") or ""
                if row_primary:
                    row_tags.add(row_primary)
                # ``turn_number`` is a real int (0 is valid, -1 means
                # "unset"); avoid ``or`` because ``0 or -1`` evaluates
                # to -1 and corrupts the cover-tag → turn-number map.
                _raw_turn = getattr(row, "turn_number", -1)
                row_turn = int(_raw_turn if _raw_turn is not None else -1)
                row_cid = getattr(row, "canonical_turn_id", "") or ""
                for tag in row_tags:
                    if tag in cover_tags:
                        tag_to_turns.setdefault(tag, []).append(row_turn)
                        if row_cid:
                            tag_to_canonical_turn_ids.setdefault(tag, []).append(row_cid)
            max_turn = max(
                (
                    int(
                        getattr(r, "turn_number", -1)
                        if getattr(r, "turn_number", -1) is not None
                        else -1
                    )
                    for r in (compact_rows or [])
                ),
                default=0,
            )

        # Load existing tag summaries for the compactor's staleness check.
        existing_tag_summaries: dict = {}
        for tag in cover_tags:
            ts = self._store.get_tag_summary(
                tag, conversation_id=self._config.conversation_id,
            )
            if ts:
                existing_tag_summaries[tag] = ts

        new_tag_summaries = self._compactor.compact_tag_summaries(
            cover_tags=cover_tags,
            tag_to_summaries=tag_to_summaries,
            tag_to_turns=tag_to_turns,
            tag_to_canonical_turn_ids=tag_to_canonical_turn_ids,
            existing_tag_summaries=existing_tag_summaries,
            max_turn=max_turn,
            generated_by_turn_id=generated_by_turn_id,
        )

        for ts_i, ts in enumerate(new_tag_summaries):
            self._store.save_tag_summary(
                ts,
                conversation_id=self._config.conversation_id,
                operation_id=operation_id,
                owner_worker_id=self._worker_id,
                lifecycle_epoch=(
                    int(self._engine_state.lifecycle_epoch)
                    if operation_id is not None and self._worker_id is not None
                    else None
                ),
            )
            # Compute and store tag summary embedding for RRF scoring.
            try:
                embed_fn = self._semantic.get_embed_fn() if self._semantic else None
                if embed_fn and ts.summary:
                    emb = embed_fn([ts.summary[:2000]])[0]
                    self._store.store_tag_summary_embedding(
                        ts.tag, self._config.conversation_id, emb,
                        operation_id=operation_id,
                        owner_worker_id=self._worker_id,
                        lifecycle_epoch=(
                            int(self._engine_state.lifecycle_epoch)
                            if operation_id is not None and self._worker_id is not None
                            else None
                        ),
                    )
            except Exception as e:
                logger.debug("Failed to embed tag summary '%s': %s", ts.tag, e)
            if progress_callback:
                try:
                    _pct = 95 + int(5 * (ts_i + 1) / max(len(new_tag_summaries), 1))
                    progress_callback(
                        ts_i + 1, len(new_tag_summaries), None,
                        phase="tag_summary_built",
                        overall_percent=_pct,
                        phase_name="tag_summaries",
                        tag=ts.tag,
                    )
                except Exception:
                    pass

        return len(new_tag_summaries), cover_tags

    def _refresh_shared_retrieval_snapshots(self) -> None:
        if self._session_state_provider is None or not self._config.conversation_id:
            return
        try:
            self._session_state_provider.refresh_tag_stats_snapshot(
                self._config.conversation_id,
            )
        except Exception:
            logger.warning(
                "Tag-stats snapshot refresh failed for %s",
                self._config.conversation_id[:12],
                exc_info=True,
            )
        try:
            self._session_state_provider.refresh_tag_summary_embedding_snapshot(
                self._config.conversation_id,
            )
        except Exception:
            logger.warning(
                "Tag-summary embedding snapshot refresh failed for %s",
                self._config.conversation_id[:12],
                exc_info=True,
            )

    def _commit_compaction_state(self, conversation_history: list[Message]) -> None:
        """Persist the committed compaction checkpoint."""
        saved = self._save_state_callback(conversation_history)
        if not saved:
            logger.warning(
                "Compaction checkpoint save failed for conversation %s",
                self._config.conversation_id[:12],
            )

    def _compact_and_store(
        self, segments: list, compact_messages_len: int,
        *,
        compact_rows: list["CanonicalTurnRow"] | None = None,
        progress_callback: Callable[..., None] | None = None,
        generated_by_turn_id: str = "",
        operation_id: str | None = None,
    ) -> list[CompactionResult]:
        """Two-pass compact and store.

        Pass 1 (sequential, no LLM): handle stubs, check store for merge
        candidates, combine turns where matches are found.

        Pass 2 (batch, LLM): compact all prepared segments, then store results.
        """
        from datetime import datetime, timezone

        from ..types import CompactionResult, FactSignal, Message, SegmentMetadata, StoredSegment
        from .tag_scoring import compute_relatedness

        _ensure_engine_imports()
        compact_rows = list(compact_rows or [])

        all_results: list[CompactionResult] = []

        def _emit_progress(
            done: int,
            total: int,
            result,
            *,
            phase: str,
            phase_name: str,
            base_percent: int,
            span_percent: int,
            **kwargs,
        ) -> None:
            if not progress_callback:
                return
            bounded_total = max(total, 1)
            bounded_done = max(0, min(done, bounded_total))
            overall_percent = base_percent + int(span_percent * bounded_done / bounded_total)
            progress_callback(
                done,
                total,
                result,
                phase=phase,
                overall_percent=overall_percent,
                phase_name=phase_name,
                **kwargs,
            )

        # D1: Gather fact signals from TurnTagIndex scoped per segment.
        # Also record the contributing turn range per segment for tool-output linkage.
        seg_cursor = 0
        segment_signals: dict[str, list[FactSignal]] = {}
        segment_code_refs: dict[str, list[dict]] = {}
        segment_turn_ranges: dict[str, tuple[int, int]] = {}  # seg.id -> (start, end_exclusive)
        segment_canonical_turn_ids: dict[str, list[str]] = {}
        merged_existing_exact_ranges: dict[str, tuple[int, int] | None] = {}
        for seg in segments:
            seg_turn_count = getattr(seg, "turn_count", 0) or (len(seg.messages) // 2)
            seg_rows = compact_rows[seg_cursor:seg_cursor + seg_turn_count]
            if seg_rows:
                segment_turn_ranges[seg.id] = (
                    seg_rows[0].turn_number,
                    seg_rows[-1].turn_number + 1,
                )
                segment_canonical_turn_ids[seg.id] = [
                    row.canonical_turn_id for row in seg_rows if row.canonical_turn_id
                ]
            else:
                segment_turn_ranges[seg.id] = (seg_cursor, seg_cursor + seg_turn_count)
                segment_canonical_turn_ids[seg.id] = []
            signals: list[FactSignal] = []
            code_refs: list[dict] = []
            for row in seg_rows:
                entry = self._turn_tag_index.get_tags_for_canonical_turn(row.canonical_turn_id)
                if entry is None:
                    entry = self._turn_tag_index.bind_canonical_turn_id(
                        row.turn_number,
                        row.canonical_turn_id,
                    )
                if entry is None:
                    logger.debug(
                        "Missing canonical turn tag entry during compaction for conv=%s turn=%d canonical=%s",
                        self._config.conversation_id[:12],
                        row.turn_number,
                        row.canonical_turn_id[:12] if row.canonical_turn_id else "",
                    )
                    continue
                if entry and entry.fact_signals:
                    signals.extend(entry.fact_signals)
                if entry and getattr(entry, "code_refs", None):
                    code_refs.extend(entry.code_refs)
            if signals:
                segment_signals[seg.id] = signals
            if code_refs:
                segment_code_refs[seg.id] = code_refs
            seg_cursor += seg_turn_count

        merge_lookback = self._config.compactor.merge_lookback
        max_seg_tokens = self._config.compactor.max_segment_tokens
        merge_threshold = self._config.compactor.merge_overlap_threshold

        # ==================================================================
        # Pass 1: Sequential pre-pass — stubs + merge check (no LLM calls)
        # ==================================================================
        compactable: list = []  # segments ready for LLM compaction
        now = datetime.now(timezone.utc)

        # P1: pre-load embeddings and embed_fn once (not per-segment)
        stored_embeddings = self._store.load_tag_summary_embeddings(
            conversation_id=self._config.conversation_id,
        )
        embed_fn = self._semantic.get_embed_fn() if self._semantic else None

        for seg in segments:
            # --- Stub passthrough (no LLM) ---
            text = " ".join(m.content for m in seg.messages)
            if _is_stub_content_fn(text):
                text = text.strip()
                turn_range = segment_turn_ranges.get(seg.id)
                logger.info(
                    "SEGMENT passthrough_stub ref=%s tokens=%d primary=%s",
                    seg.id[:8], seg.token_count, seg.primary_tag,
                )
                result = CompactionResult(
                    segment_id=seg.id,
                    primary_tag=seg.primary_tag,
                    tags=seg.tags,
                    summary=text or f"[empty turn: {seg.primary_tag}]",
                    summary_tokens=seg.token_count,
                    full_text=text,
                    original_tokens=seg.token_count,
                    messages=[{"role": m.role, "content": m.content} for m in seg.messages],
                    metadata=SegmentMetadata(
                        code_refs=segment_code_refs.get(seg.id, []),
                        turn_count=seg.turn_count,
                        canonical_turn_ids=list(segment_canonical_turn_ids.get(seg.id, [])),
                        start_turn_number=turn_range[0] if turn_range else -1,
                        end_turn_number=(turn_range[1] - 1) if turn_range and turn_range[1] > turn_range[0] else -1,
                        generated_by_turn_id=generated_by_turn_id,
                        session_date=getattr(seg, "session_date", ""),
                    ),
                    compression_ratio=1.0,
                    timestamp=seg.start_timestamp,
                )
                stored = StoredSegment(
                    ref=result.segment_id,
                    conversation_id=self._config.conversation_id,
                    primary_tag=result.primary_tag,
                    tags=result.tags,
                    summary=result.summary,
                    summary_tokens=result.summary_tokens,
                    full_text=result.full_text,
                    full_tokens=result.original_tokens,
                    messages=result.messages,
                    metadata=result.metadata,
                    compaction_model="passthrough",
                    compression_ratio=1.0,
                    start_timestamp=result.timestamp,
                    end_timestamp=result.timestamp,
                )
                self._store.store_segment(
                    stored,
                    operation_id=operation_id,
                    owner_worker_id=self._worker_id,
                    lifecycle_epoch=(
                        int(self._engine_state.lifecycle_epoch)
                        if operation_id is not None and self._worker_id is not None
                        else None
                    ),
                )
                # Propagate turn → segment tool output links
                turn_range = segment_turn_ranges.get(seg.id)
                if turn_range:
                    self._propagate_tool_output_links(stored.ref, *turn_range)
                all_results.append(result)
                continue

            # --- Merge check: find best existing segment to merge with ---
            if merge_lookback > 0:
                candidates = self._store.get_segments_by_tags(
                    tags=seg.tags, min_overlap=1, limit=merge_lookback,
                    conversation_id=self._config.conversation_id,
                )
                seg_tags = set(seg.tags)
                seg_text = " ".join(m.content for m in seg.messages)[:2000]
                # B4: Pre-compute segment embedding once (not per-candidate)
                seg_embedding = None
                if embed_fn and seg_text:
                    try:
                        seg_embedding = embed_fn([seg_text])[0]
                    except Exception:
                        pass
                best_score = 0.0
                best_candidate = None

                for candidate in candidates:
                    combined_tokens = candidate.full_tokens + seg.token_count
                    if combined_tokens > max_seg_tokens:
                        continue
                    # Multi-signal relatedness: tag overlap + embedding + keyword
                    cand_embedding = stored_embeddings.get(candidate.primary_tag)
                    relatedness = compute_relatedness(
                        tags_a=seg_tags,
                        tags_b=set(candidate.tags),
                        text_a=seg_text,
                        text_b=candidate.summary[:2000] if candidate.summary else "",
                        embedding_a=seg_embedding,
                        embedding_b=cand_embedding,
                    )
                    if relatedness < merge_threshold:
                        continue
                    try:
                        age_days = (now - candidate.created_at).days
                    except (TypeError, AttributeError):
                        age_days = 30
                    recency = max(0.5, 1.0 - age_days / 60)
                    combined_score = relatedness * recency
                    if combined_score > best_score:
                        best_score = combined_score
                        best_candidate = candidate

                if best_candidate is not None:
                    # Combine turns: prepend existing segment's messages
                    candidate_messages = [
                        Message(role=m.get("role", "user"), content=m.get("content", ""))
                        for m in best_candidate.messages
                    ]
                    seg.messages = candidate_messages + list(seg.messages)
                    seg.merge_ref = best_candidate.ref
                    seg.token_count += best_candidate.full_tokens
                    seg.start_timestamp = best_candidate.start_timestamp
                    old_tc = best_candidate.metadata.turn_count if best_candidate.metadata else len(best_candidate.messages) // 2
                    seg.turn_count += old_tc
                    seg.tags = list(set(best_candidate.tags) | seg_tags)
                    old_start = getattr(best_candidate.metadata, "start_turn_number", -1)
                    old_end = getattr(best_candidate.metadata, "end_turn_number", -1)
                    merged_existing_exact_ranges[seg.id] = (
                        (old_start, old_end)
                        if old_start >= 0 and old_end >= old_start
                        else None
                    )
                    logger.info(
                        "MERGE PREP: segment '%s' (%s) merging with stored %s "
                        "(%s, %d existing turns, relatedness=%.2f)",
                        seg.id[:8], seg.primary_tag,
                        best_candidate.ref[:8], best_candidate.primary_tag,
                        old_tc, best_score,
                    )

            compactable.append(seg)

        if not compactable:
            if all_results:
                _emit_progress(
                    len(all_results),
                    len(all_results),
                    all_results[-1],
                    phase="segment_stored",
                    phase_name="store",
                    base_percent=80,
                    span_percent=15,
                )
            return all_results

        logger.info("Pass 1 complete: %d stubs stored, %d segments ready for compaction (%d merges)",
                    len(all_results), len(compactable),
                    sum(1 for s in compactable if s.merge_ref))

        # ==================================================================
        # Pass 2: Batch LLM compaction + store
        # ==================================================================
        fact_signals_by_segment = {
            seg.id: segment_signals[seg.id]
            for seg in compactable if seg.id in segment_signals
        } or None
        code_refs_by_segment = {
            seg.id: segment_code_refs[seg.id]
            for seg in compactable if seg.id in segment_code_refs
        } or None

        def _compactor_progress(done: int, total: int, result, **kwargs) -> None:
            kwargs.pop("phase", None)  # avoid double-passing phase
            _emit_progress(
                done,
                total,
                result,
                phase="segment_compacting",
                phase_name=str(kwargs.pop("phase_name", "compactor")),
                base_percent=25,
                span_percent=55,
                **kwargs,
            )

        results = self._compactor.compact(
            compactable,
            fact_signals_by_segment=fact_signals_by_segment,
            code_refs_by_segment=code_refs_by_segment,
            progress_callback=_compactor_progress,
        )

        for seg_idx, result in enumerate(results):
            seg = compactable[seg_idx]
            new_turn_range = segment_turn_ranges.get(seg.id)
            exact_start = -1
            exact_end = -1
            if new_turn_range and new_turn_range[1] > new_turn_range[0]:
                new_start = new_turn_range[0]
                new_end = new_turn_range[1] - 1
                if seg.merge_ref:
                    existing_range = merged_existing_exact_ranges.get(seg.id)
                    if existing_range is not None:
                        exact_start = min(existing_range[0], new_start)
                        exact_end = max(existing_range[1], new_end)
                else:
                    exact_start = new_start
                    exact_end = new_end
            result.metadata.start_turn_number = exact_start
            result.metadata.end_turn_number = exact_end
            result.metadata.generated_by_turn_id = generated_by_turn_id
            result.metadata.canonical_turn_ids = list(segment_canonical_turn_ids.get(seg.id, []))

            # Store or update
            if seg.merge_ref:
                stored = StoredSegment(
                    ref=seg.merge_ref,
                    conversation_id=self._config.conversation_id,
                    primary_tag=result.primary_tag,
                    tags=seg.tags,
                    summary=result.summary,
                    summary_tokens=result.summary_tokens,
                    full_text=result.full_text,
                    full_tokens=result.original_tokens,
                    messages=result.messages,
                    metadata=result.metadata,
                    compaction_model=self._compactor.model_name,
                    compression_ratio=result.compression_ratio,
                    start_timestamp=seg.start_timestamp,
                    end_timestamp=result.timestamp,
                )
                self._store.update_segment(
                    stored,
                    operation_id=operation_id,
                    owner_worker_id=self._worker_id,
                    lifecycle_epoch=(
                        int(self._engine_state.lifecycle_epoch)
                        if operation_id is not None and self._worker_id is not None
                        else None
                    ),
                )
                self._semantic.embed_and_store_chunks(stored)
                result.segment_id = seg.merge_ref
                session_date = getattr(result.metadata, 'session_date', '') if result.metadata else ''
                logger.info(
                    "  COMPACT MERGED %d/%d: %s (session_date=%s, %dt→%dt, %d turns)",
                    seg_idx + 1, len(results), result.primary_tag,
                    session_date or 'none',
                    result.original_tokens, result.summary_tokens, seg.turn_count,
                )
            else:
                stored = StoredSegment(
                    ref=result.segment_id,
                    conversation_id=self._config.conversation_id,
                    primary_tag=result.primary_tag,
                    tags=result.tags,
                    summary=result.summary,
                    summary_tokens=result.summary_tokens,
                    full_text=result.full_text,
                    full_tokens=result.original_tokens,
                    messages=result.messages,
                    metadata=result.metadata,
                    compaction_model=self._compactor.model_name,
                    compression_ratio=result.compression_ratio,
                    start_timestamp=result.timestamp,
                    end_timestamp=result.timestamp,
                )
                self._store.store_segment(
                    stored,
                    operation_id=operation_id,
                    owner_worker_id=self._worker_id,
                    lifecycle_epoch=(
                        int(self._engine_state.lifecycle_epoch)
                        if operation_id is not None and self._worker_id is not None
                        else None
                    ),
                )
                self._semantic.embed_and_store_chunks(stored)
                session_date = getattr(result.metadata, 'session_date', '') if result.metadata else ''
                logger.info(
                    "  COMPACT NEW %d/%d: %s (session_date=%s, %dt→%dt, %d turns)",
                    seg_idx + 1, len(results), result.primary_tag,
                    session_date or 'none',
                    result.original_tokens, result.summary_tokens, seg.turn_count,
                )

            # Propagate turn → segment tool output links
            turn_range = segment_turn_ranges.get(seg.id)
            if turn_range:
                self._propagate_tool_output_links(stored.ref, *turn_range)

            all_results.append(result)
            stored_done = seg_idx + 1

            _emit_progress(
                stored_done,
                len(results),
                result,
                phase="segment_stored",
                phase_name="store",
                base_percent=80,
                span_percent=15,
            )

            _seg_ref = stored.ref
            if result.facts:
                for fact in result.facts:
                    fact.segment_ref = _seg_ref
                    fact.conversation_id = self._config.conversation_id
                _deleted, _inserted = self._store.replace_facts_for_segment(
                    self._config.conversation_id, _seg_ref, result.facts,
                    operation_id=operation_id,
                    owner_worker_id=self._worker_id,
                    lifecycle_epoch=(
                        int(self._engine_state.lifecycle_epoch)
                        if operation_id is not None and self._worker_id is not None
                        else None
                    ),
                )
                if _deleted:
                    logger.info("  Replaced %d old facts with %d new for segment %s",
                                _deleted, _inserted, result.primary_tag)
                else:
                    logger.info("  Stored %d facts for segment %s", _inserted, result.primary_tag)
                _superseded_count = 0
                _links_count = 0
                if self._supersession_checker:
                    try:
                        if hasattr(self._supersession_checker, 'check_and_link'):
                            _links_count, _superseded_count = self._supersession_checker.check_and_link(result.facts)
                        else:
                            _superseded_count = self._supersession_checker.check_and_supersede(result.facts) or 0
                        if _superseded_count:
                            logger.info("  Superseded %d facts for segment %s", _superseded_count, result.primary_tag)
                        if _links_count:
                            logger.info("  Linked %d facts for segment %s", _links_count, result.primary_tag)
                    except Exception as e:
                        logger.warning("Supersession/linking failed: %s", e)
                _emit_progress(
                    stored_done,
                    len(results),
                    result,
                    phase="facts_extracted",
                    phase_name="store",
                    base_percent=80,
                    span_percent=15,
                    fact_count=len(result.facts),
                    superseded_count=_superseded_count,
                    links_count=_links_count,
                )

        return all_results
