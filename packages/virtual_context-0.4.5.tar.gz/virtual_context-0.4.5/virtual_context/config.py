"""Configuration loading, validation, and defaults."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import yaml

from .types import (
    AssemblerConfig,
    CompactorConfig,
    DampeningConfig,
    TelemetryConfig,
    FactsConfig,
    SearchConfig,
    KeywordTagConfig,
    MonitorConfig,
    PagingConfig,
    ProxyConfig,
    ProxyInstanceConfig,
    RetrieverConfig,
    ScoringConfig,
    SegmenterConfig,
    StorageConfig,
    StrategyConfig,
    SummarizationConfig,
    CurationConfig,
    SupersessionConfig,
    TagGeneratorConfig,
    TagPromptRule,
    TagSplittingConfig,
    ToolOutputConfig,
    ToolOutputRule,
    VirtualContextConfig,
)

CONFIG_FILENAMES = [
    "virtual-context.yaml",
    "virtual-context.yml",
    "virtual-context.json",
    "virtualcontext.yaml",
    "virtualcontext.yml",
    "virtualcontext.json",
]


def _discover_config() -> Path | None:
    """Search CWD then parent dirs up to home for a config file.

    Falls back to ``~/.virtualcontext/config.yaml`` if nothing is found in the
    directory tree, so daemon-created home configs are discovered automatically.
    """
    cwd = Path.cwd()
    home = Path.home()
    search = cwd
    while True:
        for name in CONFIG_FILENAMES:
            candidate = search / name
            if candidate.is_file():
                return candidate
        if search == home or search == search.parent:
            break
        search = search.parent
    # Fallback: home-level config created by `daemon install`
    home_config = home / ".virtualcontext" / "config.yaml"
    if home_config.is_file():
        return home_config
    return None


def _parse_tag_generator(raw: dict[str, Any]) -> TagGeneratorConfig:
    keyword_raw = raw.get("keyword_fallback", {})
    keyword_fallback = None
    if keyword_raw:
        keyword_fallback = KeywordTagConfig(
            tag_keywords=keyword_raw.get("tag_keywords", {}),
            tag_patterns=keyword_raw.get("tag_patterns", {}),
        )

    # Pattern overrides: user-supplied list, or None to use defaults
    pattern_kwargs: dict = {}
    temporal_patterns_raw = raw.get("temporal_patterns")
    if temporal_patterns_raw is not None:
        pattern_kwargs["temporal_patterns"] = list(temporal_patterns_raw)

    # Tag splitting config
    split_raw = raw.get("tag_splitting", {})
    tag_splitting = TagSplittingConfig(
        enabled=split_raw.get("enabled", False),
        frequency_threshold=split_raw.get("frequency_threshold", 15),
        frequency_pct_threshold=split_raw.get("frequency_pct_threshold", 0.15),
        max_splits_per_turn=split_raw.get("max_splits_per_turn", 1),
    )

    _defaults = TagGeneratorConfig()
    return TagGeneratorConfig(
        type=raw.get("type", _defaults.type),
        provider=raw.get("provider", _defaults.provider),
        model=raw.get("model", _defaults.model),
        max_tags=raw.get("max_tags", _defaults.max_tags),
        min_tags=raw.get("min_tags", _defaults.min_tags),
        max_tokens=raw.get("max_tokens", _defaults.max_tokens),
        prompt_mode=raw.get("prompt_mode", _defaults.prompt_mode),
        keyword_fallback=keyword_fallback,
        context_lookback_pairs=raw.get("context_lookback_pairs", _defaults.context_lookback_pairs),
        context_bleed_threshold=raw.get("context_bleed_threshold", _defaults.context_bleed_threshold),
        disable_thinking=raw.get("disable_thinking", _defaults.disable_thinking),
        temporal_heuristic_enabled=raw.get("temporal_heuristic_enabled", _defaults.temporal_heuristic_enabled),
        tag_splitting=tag_splitting,
        **pattern_kwargs,
    )


def _parse_tag_rules(raw_list: list[dict[str, Any]]) -> list[TagPromptRule]:
    rules = []
    for entry in raw_list:
        rules.append(TagPromptRule(
            match=entry.get("match", "*"),
            priority=entry.get("priority", 5),
            summary_prompt=entry.get("summary_prompt"),
        ))
    return rules


def _parse_strategy_configs(raw: dict[str, Any]) -> dict[str, StrategyConfig]:
    configs = {}
    for name, conf in raw.items():
        configs[name] = StrategyConfig(
            min_overlap=conf.get("min_overlap", 1),
            max_results=conf.get("max_results", 10),
            max_budget_fraction=conf.get("max_budget_fraction", 0.25),
            include_related=conf.get("include_related", True),
        )
    if "default" not in configs:
        configs["default"] = StrategyConfig()
    return configs


def _build_config(raw: dict[str, Any], *, validate: bool = True) -> VirtualContextConfig:
    # Tag generator
    tag_gen_raw = raw.get("tag_generator", {})
    tag_generator = _parse_tag_generator(tag_gen_raw)

    # Tag rules
    tag_rules = _parse_tag_rules(raw.get("tag_rules", []))

    # Dataclass defaults (single source of truth for default values)
    _vc_defaults = VirtualContextConfig()
    _mon_defaults = MonitorConfig()
    _seg_defaults = SegmenterConfig()
    _cmp_defaults = CompactorConfig()
    _sum_defaults = SummarizationConfig()
    _sto_defaults = StorageConfig()
    _sch_defaults = SearchConfig()

    # Compaction / monitor
    compaction = raw.get("compaction", {})
    monitor_config = MonitorConfig(
        context_window=raw.get("context_window", _vc_defaults.context_window),
        soft_threshold=compaction.get("soft_threshold", _mon_defaults.soft_threshold),
        hard_threshold=compaction.get("hard_threshold", _mon_defaults.hard_threshold),
        protected_recent_turns=compaction.get("protected_recent_turns", _mon_defaults.protected_recent_turns),
        defer_payload_mutation=compaction.get("defer_payload_mutation", _mon_defaults.defer_payload_mutation),
        flush_ttl_seconds=compaction.get("flush_ttl_seconds", _mon_defaults.flush_ttl_seconds),
    )
    segmenter_config = SegmenterConfig(
        session_gap_minutes=compaction.get("session_gap_minutes", _seg_defaults.session_gap_minutes),
        tag_overlap_threshold=compaction.get("tag_overlap_threshold", _seg_defaults.tag_overlap_threshold),
        max_segment_turns=compaction.get("max_segment_turns", _seg_defaults.max_segment_turns),
        tool_result_segment_threshold=compaction.get("tool_result_segment_threshold", _seg_defaults.tool_result_segment_threshold),
    )
    compactor_config = CompactorConfig(
        summary_ratio=compaction.get("summary_ratio", _cmp_defaults.summary_ratio),
        min_summary_tokens=compaction.get("min_summary_tokens", _cmp_defaults.min_summary_tokens),
        max_summary_tokens=compaction.get("max_summary_tokens", _cmp_defaults.max_summary_tokens),
        max_concurrent_summaries=compaction.get("max_concurrent_summaries", _cmp_defaults.max_concurrent_summaries),
        overflow_buffer=compaction.get("overflow_buffer", _cmp_defaults.overflow_buffer),
        llm_token_overhead=compaction.get("llm_token_overhead", _cmp_defaults.llm_token_overhead),
        merge_lookback=compaction.get("merge_lookback", _cmp_defaults.merge_lookback),
        max_segment_tokens=compaction.get("max_segment_tokens", _cmp_defaults.max_segment_tokens),
        merge_overlap_threshold=compaction.get("merge_overlap_threshold", _cmp_defaults.merge_overlap_threshold),
        code_mode=compaction.get("code_mode", _cmp_defaults.code_mode),
    )

    # Summarization
    summ_raw = raw.get("summarization", {})
    summarization = SummarizationConfig(
        provider=summ_raw.get("provider", _sum_defaults.provider),
        model=summ_raw.get("model", _sum_defaults.model),
        max_tokens=summ_raw.get("max_tokens", _sum_defaults.max_tokens),
        temperature=summ_raw.get("temperature", _sum_defaults.temperature),
    )

    # Storage
    storage_raw = raw.get("storage", {})
    backend = storage_raw.get("backend", _sto_defaults.backend)
    fs_raw = storage_raw.get("filesystem", {})
    sqlite_raw = storage_raw.get("sqlite", {})
    pg_raw = storage_raw.get("postgres", {})
    neo4j_raw = storage_raw.get("neo4j", {})
    fdb_raw = storage_raw.get("falkordb", {})
    storage_root = raw.get("storage_root", _vc_defaults.storage_root)
    storage_config = StorageConfig(
        backend=backend,
        root=fs_raw.get("root", storage_root + "/store"),
        sqlite_path=sqlite_raw.get("path", storage_root + "/store.db"),
        postgres_dsn=pg_raw.get("dsn", _sto_defaults.postgres_dsn),
        neo4j_uri=neo4j_raw.get("uri", _sto_defaults.neo4j_uri),
        neo4j_user=neo4j_raw.get("user", _sto_defaults.neo4j_user),
        neo4j_password=neo4j_raw.get("password", _sto_defaults.neo4j_password),
        falkordb_host=fdb_raw.get("host", _sto_defaults.falkordb_host),
        falkordb_port=fdb_raw.get("port", _sto_defaults.falkordb_port),
        falkordb_password=fdb_raw.get("password", _sto_defaults.falkordb_password),
    )

    # Search (find_quote excerpts and snippet lengths)
    search_raw = raw.get("search", {})
    search_config = SearchConfig(
        excerpt_context_chars=search_raw.get("excerpt_context_chars", _sch_defaults.excerpt_context_chars),
        fts_snippet_chars=search_raw.get("fts_snippet_chars", _sch_defaults.fts_snippet_chars),
        tool_output_snippet_chars=search_raw.get("tool_output_snippet_chars", _sch_defaults.tool_output_snippet_chars),
        postgres_max_words=search_raw.get("postgres_max_words", _sch_defaults.postgres_max_words),
        find_quote_max_results=search_raw.get("find_quote_max_results", _sch_defaults.find_quote_max_results),
        find_quote_default_results=search_raw.get("find_quote_default_results", _sch_defaults.find_quote_default_results),
        remember_when_max_results=search_raw.get("remember_when_max_results", _sch_defaults.remember_when_max_results),
        semantic_search_max_results=search_raw.get("semantic_search_max_results", _sch_defaults.semantic_search_max_results),
        query_facts_default_limit=search_raw.get("query_facts_default_limit", _sch_defaults.query_facts_default_limit),
        search_facts_max_results=search_raw.get("search_facts_max_results", _sch_defaults.search_facts_max_results),
    )

    # Facts
    facts_raw = raw.get("facts", {})
    facts_config = FactsConfig(
        graph_links=facts_raw.get("graph_links", True),
        link_types=facts_raw.get("link_types", [
            "supersedes", "caused_by", "part_of", "contradicts", "same_as", "related_to",
        ]),
    )

    # Assembly
    _asm_defaults = AssemblerConfig()
    assembly_raw = raw.get("assembly", {})
    assembler_config = AssemblerConfig(
        core_context_max_tokens=assembly_raw.get("core_context_max_tokens", _asm_defaults.core_context_max_tokens),
        tag_context_max_tokens=assembly_raw.get("tag_context_max_tokens", _asm_defaults.tag_context_max_tokens),
        facts_max_tokens=assembly_raw.get("facts_max_tokens", _asm_defaults.facts_max_tokens),
        core_files=assembly_raw.get("core_files", []),
        recent_turns_always_included=assembly_raw.get("recent_turns_always_included", _asm_defaults.recent_turns_always_included),
        context_hint_enabled=assembly_raw.get("context_hint_enabled", _asm_defaults.context_hint_enabled),
        context_hint_max_tokens=assembly_raw.get("context_hint_max_tokens", _asm_defaults.context_hint_max_tokens),
        pre_compaction_filtering=assembly_raw.get("pre_compaction_filtering", _asm_defaults.pre_compaction_filtering),
        context_injection_max_tokens=assembly_raw.get("context_injection_max_tokens", -1),
    )

    # Retrieval
    _ret_defaults = RetrieverConfig()
    retrieval_raw = raw.get("retrieval", {})
    strategy_raw = retrieval_raw.get("strategy_config", {})
    strategy_configs = _parse_strategy_configs(strategy_raw)
    scoring_raw = retrieval_raw.get("scoring", {})
    _sc_defaults = ScoringConfig()
    dampening_raw = scoring_raw.get("dampening", {})
    _damp_defaults = DampeningConfig()
    dampening_config = DampeningConfig(
        hub_enabled=dampening_raw.get("hub_enabled", _damp_defaults.hub_enabled),
        hub_penalty_strength=dampening_raw.get("hub_penalty_strength", _damp_defaults.hub_penalty_strength),
        hub_min_score=dampening_raw.get("hub_min_score", _damp_defaults.hub_min_score),
        gravity_enabled=dampening_raw.get("gravity_enabled", _damp_defaults.gravity_enabled),
        gravity_threshold=dampening_raw.get("gravity_threshold", _damp_defaults.gravity_threshold),
        gravity_factor=dampening_raw.get("gravity_factor", _damp_defaults.gravity_factor),
        resolution_enabled=dampening_raw.get("resolution_enabled", _damp_defaults.resolution_enabled),
        resolution_boost=dampening_raw.get("resolution_boost", _damp_defaults.resolution_boost),
    )
    scoring_config = ScoringConfig(
        idf_weight=scoring_raw.get("idf_weight", _sc_defaults.idf_weight),
        bm25_weight=scoring_raw.get("bm25_weight", _sc_defaults.bm25_weight),
        embedding_weight=scoring_raw.get("embedding_weight", _sc_defaults.embedding_weight),
        rrf_k=scoring_raw.get("rrf_k", _sc_defaults.rrf_k),
        bm25_limit=scoring_raw.get("bm25_limit", _sc_defaults.bm25_limit),
        embedding_limit=scoring_raw.get("embedding_limit", _sc_defaults.embedding_limit),
        embedding_min_threshold=scoring_raw.get("embedding_min_threshold", _sc_defaults.embedding_min_threshold),
        dampening=dampening_config,
    )
    retriever_config = RetrieverConfig(
        skip_active_tags=retrieval_raw.get("skip_active_tags", _ret_defaults.skip_active_tags),
        active_tag_lookback=retrieval_raw.get("active_tag_lookback", _ret_defaults.active_tag_lookback),
        tag_context_max_tokens=assembler_config.tag_context_max_tokens,
        strategy_configs=strategy_configs,
        anchorless_lookback=retrieval_raw.get("anchorless_lookback", _ret_defaults.anchorless_lookback),
        inbound_tagger_type=retrieval_raw.get("inbound_tagger_type", _ret_defaults.inbound_tagger_type),
        embedding_model=retrieval_raw.get("embedding_model", _ret_defaults.embedding_model),
        embedding_threshold=retrieval_raw.get("embedding_threshold", _ret_defaults.embedding_threshold),
        scoring=scoring_config,
    )

    # Telemetry (also accepts legacy "cost_tracking" key)
    telemetry_raw = raw.get("telemetry", raw.get("cost_tracking", {}))
    telemetry_config = TelemetryConfig(
        enabled=telemetry_raw.get("enabled", False),
        models_file=telemetry_raw.get("models_file", "models.yaml"),
    )

    # Proxy settings
    proxy_raw = raw.get("proxy", {})
    instances_raw = proxy_raw.get("instances", [])
    instances = [
        ProxyInstanceConfig(
            port=inst.get("port", 5757),
            upstream=inst.get("upstream", ""),
            label=inst.get("label", ""),
            host=inst.get("host", "127.0.0.1"),
            config=inst.get("config", ""),
            upstream_context_limit=inst.get("upstream_context_limit", 0),
        )
        for inst in instances_raw
    ]
    _prx_defaults = ProxyConfig()
    proxy_config = ProxyConfig(
        request_log_dir=proxy_raw.get(
            "request_log_dir",
            os.path.join(storage_root, "request_log"),
        ),
        request_log_max_files=proxy_raw.get("request_log_max_files", _prx_defaults.request_log_max_files),
        upstream_context_limit=proxy_raw.get("upstream_context_limit", _prx_defaults.upstream_context_limit),
        passthrough_trim_ratio=proxy_raw.get("passthrough_trim_ratio", _prx_defaults.passthrough_trim_ratio),
        llm_calls_log=proxy_raw.get("llm_calls_log", _prx_defaults.llm_calls_log),
        history_widening_threshold=proxy_raw.get("history_widening_threshold", _prx_defaults.history_widening_threshold),
        redis_url=os.environ.get("REDIS_URL", proxy_raw.get("redis_url", "")),
        redis_history_cap=proxy_raw.get("redis_history_cap", 600),
        instances=instances,
    )

    # Paging settings
    _pag_defaults = PagingConfig()
    paging_raw = raw.get("paging", {})
    paging_config = PagingConfig(
        enabled=paging_raw.get("enabled", _pag_defaults.enabled),
        autonomous_models=paging_raw.get("autonomous_models", _pag_defaults.autonomous_models),
        auto_promote=paging_raw.get("auto_promote", _pag_defaults.auto_promote),
        auto_evict=paging_raw.get("auto_evict", _pag_defaults.auto_evict),
        max_tool_loops=paging_raw.get("max_tool_loops", _pag_defaults.max_tool_loops),
    )

    # Tool output interception
    to_raw = raw.get("tool_output", {})
    tool_output_rules = [
        ToolOutputRule(
            match=r.get("match", "*"),
            truncate_threshold=r.get("truncate_threshold"),
            head_ratio=r.get("head_ratio", 0.6),
            tail_ratio=r.get("tail_ratio", 0.4),
            max_index_bytes=r.get("max_index_bytes"),
        )
        for r in to_raw.get("rules", [])
    ]
    tool_output_config = ToolOutputConfig(
        enabled=to_raw.get("enabled", False),
        default_truncate_threshold=to_raw.get("default_truncate_threshold", 8192),
        max_index_bytes=to_raw.get("max_index_bytes", 524_288),
        default_head_ratio=to_raw.get("default_head_ratio", 0.6),
        default_tail_ratio=to_raw.get("default_tail_ratio", 0.4),
        rules=tool_output_rules,
    )

    # Supersession config
    ss_raw = raw.get("supersession", {})
    supersession_config = SupersessionConfig(
        enabled=ss_raw.get("enabled", False),
        provider=ss_raw.get("provider", ""),
        model=ss_raw.get("model", ""),
        batch_size=ss_raw.get("batch_size", 20),
    )

    # Curation config
    cur_raw = raw.get("curation", {})
    curation_config = CurationConfig(
        enabled=cur_raw.get("enabled", False),
        provider=cur_raw.get("provider", ""),
        model=cur_raw.get("model", ""),
        max_response_tokens=cur_raw.get("max_response_tokens", 2048),
    )

    cfg = VirtualContextConfig(
        version=raw.get("version", "0.2"),
        storage_root=storage_root,
        context_window=raw.get("context_window", 120_000),
        token_counter=raw.get("token_counter", "estimate"),
        tag_generator=tag_generator,
        tag_rules=tag_rules,
        monitor=monitor_config,
        segmenter=segmenter_config,
        compactor=compactor_config,
        retriever=retriever_config,
        assembler=assembler_config,
        summarization=summarization,
        storage=storage_config,
        telemetry=telemetry_config,
        paging=paging_config,
        proxy=proxy_config,
        tool_output=tool_output_config,
        search=search_config,
        facts=facts_config,
        supersession=supersession_config,
        curation=curation_config,
        providers=raw.get("providers", {}),
    )
    # Accept both "conversation_id" (preferred) and "session_id" (legacy)
    if "conversation_id" in raw:
        cfg.conversation_id = raw["conversation_id"]
    elif "session_id" in raw:
        cfg.conversation_id = raw["session_id"]
    # tenant_id flows from yaml
    # or from programmatic ``cfg.tenant_id = ...`` assignment by cloud's
    # REST handler. Empty default is correct for single-user proxy / dev.
    if "tenant_id" in raw:
        cfg.tenant_id = raw["tenant_id"]

    if validate:
        errors = validate_config(cfg)
        if errors:
            raise ValueError(
                "Invalid configuration:\n  - " + "\n  - ".join(errors)
            )

    return cfg


def validate_config(config: VirtualContextConfig) -> list[str]:
    """Validate a config. Returns list of error strings (empty = valid)."""
    errors: list[str] = []

    # Tag generator validation
    if config.tag_generator.type not in ("llm", "keyword"):
        errors.append(
            f"tag_generator.type must be 'llm' or 'keyword', "
            f"got '{config.tag_generator.type}'"
        )

    if config.tag_generator.type == "llm":
        if not config.tag_generator.provider:
            errors.append("tag_generator.provider is required when type is 'llm'")
        if not config.tag_generator.model:
            errors.append("tag_generator.model is required when type is 'llm'")

    if config.tag_generator.max_tags < config.tag_generator.min_tags:
        errors.append(
            f"tag_generator.max_tags ({config.tag_generator.max_tags}) must be >= "
            f"min_tags ({config.tag_generator.min_tags})"
        )

    # Monitor thresholds
    if config.monitor.soft_threshold >= config.monitor.hard_threshold:
        errors.append(
            f"soft_threshold ({config.monitor.soft_threshold}) must be < "
            f"hard_threshold ({config.monitor.hard_threshold})"
        )

    if config.monitor.protected_recent_turns < 1:
        errors.append("protected_recent_turns must be >= 1")

    # Strategy configs
    for name, sc in config.retriever.strategy_configs.items():
        if sc.max_budget_fraction <= 0 or sc.max_budget_fraction > 1.0:
            errors.append(
                f"strategy_config[{name}].max_budget_fraction must be in (0, 1.0], "
                f"got {sc.max_budget_fraction}"
            )
        if sc.min_overlap < 1:
            errors.append(
                f"strategy_config[{name}].min_overlap must be >= 1, "
                f"got {sc.min_overlap}"
            )

    # Pre-compaction filtering mode
    _valid_pcf = {"off", "conservative", "aggressive"}
    if config.assembler.pre_compaction_filtering not in _valid_pcf:
        errors.append(
            f"assembly.pre_compaction_filtering must be one of {_valid_pcf}, "
            f"got '{config.assembler.pre_compaction_filtering}'"
        )

    # Segmenter config
    if not (0.0 <= config.segmenter.tag_overlap_threshold <= 1.0):
        errors.append(
            f"segmenter.tag_overlap_threshold must be in [0.0, 1.0], "
            f"got {config.segmenter.tag_overlap_threshold}"
        )
    if config.segmenter.max_segment_turns < 0:
        errors.append(
            f"segmenter.max_segment_turns must be >= 0, "
            f"got {config.segmenter.max_segment_turns}"
        )
    if config.segmenter.tool_result_segment_threshold < 0:
        errors.append(
            f"segmenter.tool_result_segment_threshold must be >= 0, "
            f"got {config.segmenter.tool_result_segment_threshold}"
        )

    # Storage backend
    _valid_backends = ("sqlite", "filesystem", "postgres", "neo4j", "falkordb")
    if config.storage.backend not in _valid_backends:
        errors.append(
            f"storage.backend must be one of {_valid_backends}, "
            f"got '{config.storage.backend}'"
        )

    # Paging autonomous_models
    if not isinstance(config.paging.autonomous_models, list):
        errors.append(
            "paging.autonomous_models must be a list of model-name prefixes"
        )

    # Proxy instances validation
    seen_ports: dict[str, int] = {}  # "host:port" -> index
    seen_labels: dict[str, int] = {}  # "label" -> index
    for i, inst in enumerate(config.proxy.instances):
        if not inst.upstream:
            errors.append(
                f"proxy.instances[{i}].upstream is required"
            )
        key = f"{inst.host}:{inst.port}"
        if key in seen_ports:
            errors.append(
                f"proxy.instances[{i}] duplicates {key} "
                f"(same as instances[{seen_ports[key]}])"
            )
        seen_ports[key] = i

        # Per-instance config file validation
        if inst.config:
            from pathlib import Path as _Path
            if not _Path(inst.config).is_file():
                errors.append(
                    f"proxy.instances[{i}].config file not found: {inst.config}"
                )

        # Label uniqueness
        if inst.label:
            if inst.label in seen_labels:
                errors.append(
                    f"proxy.instances[{i}].label '{inst.label}' duplicates "
                    f"instances[{seen_labels[inst.label]}]"
                )
            seen_labels[inst.label] = i

    # Check that summarization provider exists in providers
    if config.providers and config.summarization.provider not in config.providers:
        errors.append(
            f"Summarization provider '{config.summarization.provider}' "
            f"not found in providers section"
        )

    return errors


def load_config(
    config_path: str | Path | None = None,
    config_dict: dict | None = None,
    *,
    validate: bool = True,
) -> VirtualContextConfig:
    """Load config from dict, explicit path, or auto-discover.

    Parameters
    ----------
    config_path : str | Path | None
        Explicit path to a YAML/JSON config file.
    config_dict : dict | None
        Raw config dictionary (overrides ``config_path``).
    validate : bool
        If True (default), run ``validate_config()`` and raise
        ``ValueError`` on invalid configuration.
    """
    if config_dict is not None:
        return _build_config(config_dict, validate=validate)

    if config_path is not None:
        path = Path(config_path)
    else:
        path = _discover_config()

    if path is None:
        # Return defaults
        return _build_config({}, validate=validate)

    if not path.is_file():
        raise FileNotFoundError(f"Config file not found: {path}")

    text = path.read_text()
    if path.suffix == ".json":
        raw = json.loads(text)
    else:
        raw = yaml.safe_load(text) or {}

    return _build_config(raw, validate=validate)
