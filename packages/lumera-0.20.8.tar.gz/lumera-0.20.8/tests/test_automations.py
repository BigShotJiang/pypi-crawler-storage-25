from typing import Any, Mapping

import pytest

import lumera.automations as automations
from lumera._utils import LumeraAPIError


def test_automation_exposes_schedule_metadata() -> None:
    auto = automations.Automation(
        {
            "id": "auto-1",
            "name": "Daily Report",
            "schedule": "0 7 * * *",
            "schedule_tz": "America/Los_Angeles",
            "schedule_preset_id": "preset-1",
        }
    )

    assert auto.schedule == "0 7 * * *"
    assert auto.schedule_tz == "America/Los_Angeles"
    assert auto.schedule_preset_id == "preset-1"


def test_list_presets(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> Mapping[str, Any]:
        captured["method"] = method
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {
            "presets": [
                {
                    "id": "preset-1",
                    "name": "Daily Run",
                    "automation_id": "auto-1",
                    "inputs": {"city": "SF"},
                }
            ]
        }

    monkeypatch.setattr(automations, "_api_request", fake_api)

    presets = automations.list_presets(" auto-1 ")

    assert len(presets) == 1
    assert presets[0].id == "preset-1"
    assert presets[0].name == "Daily Run"
    assert presets[0].automation_id == "auto-1"
    assert presets[0].inputs == {"city": "SF"}
    assert captured["method"] == "GET"
    assert captured["path"] == "automations/auto-1/presets"
    assert captured["kwargs"] == {}


def test_create_preset(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> Mapping[str, Any]:
        captured["method"] = method
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {
            "id": "preset-1",
            "name": "Daily Run",
            "automation_id": "auto-1",
            "inputs": {"city": "SF"},
        }

    monkeypatch.setattr(automations, "_api_request", fake_api)

    preset = automations.create_preset(" auto-1 ", name=" Daily Run ", inputs={"city": "SF"})

    assert preset.id == "preset-1"
    assert captured["method"] == "POST"
    assert captured["path"] == "automations/auto-1/presets"
    assert captured["kwargs"]["json_body"] == {
        "name": "Daily Run",
        "inputs": {"city": "SF"},
    }


def test_update_includes_schedule_preset_id(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> Mapping[str, Any]:
        captured["method"] = method
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {
            "id": "auto-1",
            "name": "Daily Report",
            "schedule": "0 7 * * *",
            "schedule_tz": "America/Los_Angeles",
            "schedule_preset_id": "preset-1",
        }

    monkeypatch.setattr(automations, "_api_request", fake_api)

    updated = automations.update(
        " auto-1 ",
        schedule="0 7 * * *",
        schedule_tz="America/Los_Angeles",
        schedule_preset_id="preset-1",
    )

    assert updated.schedule == "0 7 * * *"
    assert updated.schedule_tz == "America/Los_Angeles"
    assert updated.schedule_preset_id == "preset-1"
    assert captured["method"] == "PATCH"
    assert captured["path"] == "automations/auto-1"
    assert captured["kwargs"]["json_body"] == {
        "schedule": "0 7 * * *",
        "schedule_tz": "America/Los_Angeles",
        "schedule_preset_id": "preset-1",
    }


def test_upsert_passes_schedule_preset_id_on_update(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_get_by_external_id(external_id: str) -> automations.Automation:
        assert external_id == "daily-report"
        return automations.Automation({"id": "auto-1", "external_id": external_id})

    def fake_update(automation_id: str, **kwargs: object) -> automations.Automation:
        captured["automation_id"] = automation_id
        captured["kwargs"] = kwargs
        return automations.Automation({"id": automation_id, "name": kwargs.get("name", "")})

    monkeypatch.setattr(automations, "get_by_external_id", fake_get_by_external_id)
    monkeypatch.setattr(automations, "update", fake_update)

    automations.upsert(
        external_id="daily-report",
        name="Daily Report",
        code="def main(): return {}",
        schedule="0 7 * * *",
        schedule_tz="UTC",
        schedule_preset_id="preset-1",
    )

    assert captured["automation_id"] == "auto-1"
    assert captured["kwargs"]["schedule_preset_id"] == "preset-1"


def test_upsert_schedule_preset_id_requires_existing_automation(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_get_by_external_id(external_id: str) -> automations.Automation:
        raise LumeraAPIError(404, "not found", url="automations", payload=None)

    monkeypatch.setattr(automations, "get_by_external_id", fake_get_by_external_id)

    with pytest.raises(ValueError, match="schedule_preset_id requires an existing automation"):
        automations.upsert(
            external_id="new-report",
            name="New Report",
            code="def main(): return {}",
            schedule_preset_id="preset-1",
        )
