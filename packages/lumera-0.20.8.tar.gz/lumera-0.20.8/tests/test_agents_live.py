import io
import json
import pathlib

import pytest
import requests

import lumera._live as _live
import lumera._utils as _utils
import lumera.agents as agents


@pytest.fixture(autouse=True)
def reset_http_session() -> None:
    _utils._http_session = None
    yield
    _utils._http_session = None


class DummyResponse:
    def __init__(
        self,
        *,
        status_code: int = 200,
        json_data: dict | None = None,
        text: str | None = None,
        headers: dict[str, str] | None = None,
        url: str | None = None,
    ) -> None:
        self.status_code = status_code
        self._json_data = json_data
        self._text = (
            text if text is not None else (json.dumps(json_data) if json_data is not None else "")
        )
        self.headers = headers or {
            "Content-Type": "application/json" if json_data is not None else "text/plain"
        }
        self.url = url or "https://app.lumerahq.com/api/agents/test"

    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 300

    def json(self) -> dict:
        if self._json_data is None:
            raise ValueError("no json payload")
        return self._json_data

    @property
    def text(self) -> str:
        return self._text

    def raise_for_status(self) -> None:
        if not self.ok:
            raise requests.HTTPError(response=self)


class DummyStreamResponse(DummyResponse):
    def __init__(self, *, lines: list[str], **kwargs: object) -> None:
        super().__init__(**kwargs)
        self._lines = lines

    def __enter__(self) -> "DummyStreamResponse":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> bool:
        return False

    def iter_lines(self, decode_unicode: bool = False):
        del decode_unicode
        for line in self._lines:
            yield line


def test_start_live_encodes_files_and_returns_handle(
    monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path
) -> None:
    file_path = tmp_path / "invoice.pdf"
    file_path.write_bytes(b"%PDF-1.7")

    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> dict[str, object]:
        captured["method"] = method
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {
            "status": "accepted",
            "session_id": "invoice-42",
            "request_id": "req_123",
        }

    monkeypatch.setattr(agents, "_api_request", fake_api)

    run = agents.start_live(
        "support-agent",
        "Review this invoice",
        session_id="invoice-42",
        files=[file_path],
    )

    assert run.agent_id == "support-agent"
    assert run.session_id == "invoice-42"
    assert run.request_id == "req_123"
    assert run.status == "accepted"

    assert captured["method"] == "POST"
    assert captured["path"] == "agents/support-agent/live/start"
    kwargs = captured["kwargs"]
    assert isinstance(kwargs, dict)
    payload = kwargs["json_body"]
    assert isinstance(payload, dict)
    assert payload["message"] == "Review this invoice"
    assert payload["session_id"] == "invoice-42"
    files = payload["files"]
    assert isinstance(files, list)
    assert files[0]["filename"] == "invoice.pdf"
    assert files[0]["content_type"] == "application/pdf"
    assert files[0]["content"]


def test_get_live_state_uses_stream_snapshot_when_request_id_present(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv(_utils.TOKEN_ENV, "tok")
    captured: dict[str, object] = {}

    lines = [
        "id: 3:14",
        "event: snapshot",
        'data: {"sessionId":"case-1","streamEpoch":3,"status":"failed","lastSeq":14,"requestId":"req_999","assistant":{"content":"Partial answer","blocks":[]},"toolCalls":[{"id":"tc_1"}],"actions":[],"error":"tool failed","canContinue":true}',
        "",
    ]

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyStreamResponse:
            captured["method"] = method
            captured["url"] = url
            captured["kwargs"] = kwargs
            return DummyStreamResponse(
                lines=lines,
                headers={"Content-Type": "text/event-stream"},
                url=str(url),
            )

        def mount(self, prefix: str, adapter: object) -> None:
            del prefix, adapter

    monkeypatch.setattr(_live, "_get_session", lambda: MockSession())

    state = agents.get_live_state("support-agent", session_id="case-1", request_id="req_999")

    assert state.session_id == "case-1"
    assert state.stream_epoch == 3
    assert state.status == "failed"
    assert state.last_seq == 14
    assert state.request_id == "req_999"
    assert state.assistant_text == "Partial answer"
    assert state.error == "tool failed"
    assert state.can_continue is True
    assert state.is_terminal is True
    assert state.tool_calls == [{"id": "tc_1"}]

    assert captured["method"] == "GET"
    assert str(captured["url"]).endswith("/agents/support-agent/live/stream")
    kwargs = captured["kwargs"]
    assert isinstance(kwargs, dict)
    assert kwargs["params"] == {"session_id": "case-1", "request_id": "req_999", "wait_ms": 0}


def test_live_run_stream_parses_sse_and_tracks_last_event_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv(_utils.TOKEN_ENV, "tok")
    monkeypatch.setenv("LUMERA_AUTOMATION_ID", "auto_1")
    monkeypatch.setenv("LUMERA_RUN_ID", "run_1")

    captured: dict[str, object] = {}

    lines = [
        "id: 1:0",
        "event: snapshot",
        'data: {"sessionId":"case-1","streamEpoch":1,"status":"running","lastSeq":0,"requestId":"req_1","assistant":{"content":"","blocks":[]},"toolCalls":[],"actions":[],"canContinue":false}',
        "",
        "id: 1:1",
        "event: text_delta",
        'data: {"type":"text_delta","delta":"Hello","request_id":"req_1"}',
        "",
        "id: 1:2",
        "event: done",
        'data: {"type":"done","success":true,"request_id":"req_1"}',
        "",
    ]

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyStreamResponse:
            captured["method"] = method
            captured["url"] = url
            captured["kwargs"] = kwargs
            return DummyStreamResponse(
                lines=lines,
                headers={"Content-Type": "text/event-stream"},
                url=str(url),
            )

        def mount(self, prefix: str, adapter: object) -> None:
            del prefix, adapter

    monkeypatch.setattr(_live, "_get_session", lambda: MockSession())

    run = agents.AgentLiveRun("support-agent", "case-1", "req_1", "accepted")
    envelopes = list(run.stream(wait_ms=5000, timeout=20))

    assert len(envelopes) == 3
    assert envelopes[0].kind == "snapshot"
    assert envelopes[0].state is not None
    assert envelopes[0].state.status == "running"
    assert envelopes[0].state.request_id == "req_1"

    assert envelopes[1].kind == "event"
    assert envelopes[1].type == "text_delta"
    assert envelopes[1].delta == "Hello"
    assert envelopes[1].is_terminal is False

    assert envelopes[2].kind == "event"
    assert envelopes[2].type == "done"
    assert envelopes[2].is_terminal is True

    assert run.last_event_id == "1:2"
    assert run.request_id == "req_1"

    state = run.state(timeout=20)
    assert state.status == "completed"
    assert state.assistant_text == "Hello"

    assert captured["method"] == "GET"
    assert str(captured["url"]).endswith("/agents/support-agent/live/stream")
    kwargs = captured["kwargs"]
    assert isinstance(kwargs, dict)
    assert kwargs["params"] == {"session_id": "case-1", "request_id": "req_1", "wait_ms": 5000}
    headers = kwargs["headers"]
    assert isinstance(headers, dict)
    assert headers["Accept"] == "text/event-stream"
    assert headers["Authorization"] == "token tok"
    assert headers["User-Agent"].startswith("lumera-sdk/")
    assert headers["X-Lumera-Client"].startswith("lumera-sdk/")
    assert "lm-provenance" in headers


def test_live_run_stream_allows_empty_replay_after_terminal_cursor(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv(_utils.TOKEN_ENV, "tok")

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyStreamResponse:
            del method, url, kwargs
            return DummyStreamResponse(
                lines=[],
                headers={"Content-Type": "text/event-stream"},
            )

        def mount(self, prefix: str, adapter: object) -> None:
            del prefix, adapter

    monkeypatch.setattr(_live, "_get_session", lambda: MockSession())

    envelopes = list(
        agents.stream_live(
            "support-agent",
            session_id="case-1",
            last_event_id="1:2",
            timeout=20,
        )
    )

    assert envelopes == []


def test_get_live_state_falls_back_to_history(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_history(agent_id: str, *, session_id: str | None = None, timeout: int = 30):
        assert agent_id == "support-agent"
        assert session_id == "case-1"
        del timeout
        return [
            {"role": "user", "content": "Hello", "request_id": "req_1"},
            {"role": "assistant", "content": "Settled answer", "request_id": "req_1", "blocks": []},
        ]

    monkeypatch.setattr(agents, "get_history", fake_history)

    state = agents.get_live_state("support-agent", session_id="case-1")

    assert state.session_id == "case-1"
    assert state.status == "completed"
    assert state.request_id == "req_1"
    assert state.assistant_text == "Settled answer"


def test_live_run_print_stream_renders_text_and_tools(monkeypatch: pytest.MonkeyPatch) -> None:
    lines = [
        "id: 1:1",
        "event: tool_start",
        'data: {"type":"tool_start","tool":"read","request_id":"req_1"}',
        "",
        "id: 1:2",
        "event: text_delta",
        'data: {"type":"text_delta","delta":"Hello world","request_id":"req_1"}',
        "",
        "id: 1:3",
        "event: done",
        'data: {"type":"done","success":true,"request_id":"req_1"}',
        "",
    ]

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyStreamResponse:
            del method, url, kwargs
            return DummyStreamResponse(
                lines=lines,
                headers={"Content-Type": "text/event-stream"},
            )

        def mount(self, prefix: str, adapter: object) -> None:
            del prefix, adapter

    monkeypatch.setenv(_utils.TOKEN_ENV, "tok")
    monkeypatch.setattr(_live, "_get_session", lambda: MockSession())

    run = agents.AgentLiveRun("support-agent", "case-1", "req_1", "accepted")
    out = io.StringIO()
    final = run.print_stream(file=out)

    rendered = out.getvalue()
    assert "[tool:start] read" in rendered
    assert "Hello world" in rendered
    assert "[done] completed" in rendered
    assert final.status == "completed"


def test_live_run_wait_streams_until_terminal(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(_utils.TOKEN_ENV, "tok")
    lines = [
        "id: 1:0",
        "event: snapshot",
        'data: {"sessionId":"case-1","streamEpoch":1,"status":"running","lastSeq":0,"requestId":"req_1","assistant":{"content":"","blocks":[]},"toolCalls":[],"actions":[],"canContinue":false}',
        "",
        "id: 1:1",
        "event: text_delta",
        'data: {"type":"text_delta","delta":"done","request_id":"req_1"}',
        "",
        "id: 1:2",
        "event: done",
        'data: {"type":"done","success":true,"request_id":"req_1"}',
        "",
    ]

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyStreamResponse:
            del method, url, kwargs
            return DummyStreamResponse(
                lines=lines,
                headers={"Content-Type": "text/event-stream"},
            )

        def mount(self, prefix: str, adapter: object) -> None:
            del prefix, adapter

    monkeypatch.setattr(_live, "_get_session", lambda: MockSession())
    monkeypatch.setattr(_live.time, "sleep", lambda _seconds: None)

    run = agents.AgentLiveRun("support-agent", "case-1", "req_1", "accepted")
    final = run.wait(timeout=5, poll_interval=0.01)

    assert final.status == "completed"
    assert final.assistant_text == "done"
