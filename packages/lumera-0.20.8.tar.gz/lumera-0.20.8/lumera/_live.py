"""Shared thin live-client helpers for Lumera SDK modules."""

from __future__ import annotations

import builtins
import json
import sys
import time
from typing import Any, Callable, IO, Iterator, Mapping

from ._utils import LumeraAPIError, _api_headers, _api_url, _get_session, _raise_api_error

_TERMINAL_LIVE_STATUSES = {"completed", "failed", "interrupted", "aborted"}
_TERMINAL_LIVE_EVENT_TYPES = {"terminal", "done", "error"}


class LiveStreamError(RuntimeError):
    """Raised when a live SSE stream ends before a terminal state is observed."""

    def __init__(self, message: str, *, event_count: int = 0) -> None:
        super().__init__(message)
        self.event_count = event_count


class LiveStateBase:
    """Thin wrapper over the sandbox live-state snapshot JSON."""

    def __init__(self, data: Mapping[str, Any]) -> None:
        self._data = dict(data)

    @property
    def session_id(self) -> str:
        return _as_str(self._data.get("sessionId"))

    @property
    def stream_epoch(self) -> int:
        return _as_int(self._data.get("streamEpoch"))

    @property
    def status(self) -> str:
        return _as_str(self._data.get("status"))

    @property
    def last_seq(self) -> int:
        return _as_int(self._data.get("lastSeq"))

    @property
    def request_id(self) -> str | None:
        return _as_optional_str(self._data.get("requestId"))

    @property
    def session_name(self) -> str | None:
        return _as_optional_str(self._data.get("sessionName"))

    @property
    def trace_id(self) -> str | None:
        return _as_optional_str(self._data.get("traceId"))

    @property
    def surface(self) -> str | None:
        return _as_optional_str(self._data.get("surface"))

    @property
    def scope_id(self) -> str | None:
        return _as_optional_str(self._data.get("scopeId"))

    @property
    def actor_email(self) -> str | None:
        return _as_optional_str(self._data.get("actorEmail"))

    @property
    def user_message(self) -> str | None:
        return _as_optional_str(self._data.get("userMessage"))

    @property
    def assistant(self) -> dict[str, Any]:
        value = self._data.get("assistant")
        return dict(value) if isinstance(value, Mapping) else {}

    @property
    def assistant_text(self) -> str:
        return _as_str(self.assistant.get("content"))

    @property
    def assistant_blocks(self) -> list[Any]:
        value = self.assistant.get("blocks")
        return builtins.list(value) if isinstance(value, builtins.list) else []

    @property
    def tool_calls(self) -> list[Any]:
        value = self._data.get("toolCalls")
        return builtins.list(value) if isinstance(value, builtins.list) else []

    @property
    def actions(self) -> list[Any]:
        value = self._data.get("actions")
        return builtins.list(value) if isinstance(value, builtins.list) else []

    @property
    def usage(self) -> dict[str, Any] | None:
        value = self._data.get("usage")
        return dict(value) if isinstance(value, Mapping) else None

    @property
    def error(self) -> str | None:
        return _as_optional_str(self._data.get("error"))

    @property
    def can_continue(self) -> bool:
        return bool(self._data.get("canContinue", False))

    @property
    def writer_heartbeat_at(self) -> str | None:
        return _as_optional_str(self._data.get("writerHeartbeatAt"))

    @property
    def updated_at(self) -> str | None:
        return _as_optional_str(self._data.get("updatedAt"))

    @property
    def is_terminal(self) -> bool:
        return self.status in _TERMINAL_LIVE_STATUSES

    @property
    def raw(self) -> dict[str, Any]:
        return dict(self._data)

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(status={self.status!r}, session_id={self.session_id!r}, "
            f"request_id={self.request_id!r}, last_seq={self.last_seq})"
        )


class LiveEnvelopeBase:
    """Single SSE envelope from a live stream."""

    _state_cls = LiveStateBase

    def __init__(
        self,
        kind: str,
        *,
        event_id: str | None = None,
        event_name: str | None = None,
        payload: Mapping[str, Any] | None = None,
    ) -> None:
        self.kind = kind
        self.id = event_id
        self.event_name = event_name
        self._payload = dict(payload or {})

    @property
    def payload(self) -> dict[str, Any]:
        return dict(self._payload)

    @property
    def state(self) -> LiveStateBase | None:
        if self.kind != "snapshot":
            return None
        return self._state_cls(self._payload)

    @property
    def type(self) -> str | None:
        if self.kind != "event":
            return None
        return _as_optional_str(self._payload.get("type"))

    @property
    def delta(self) -> str | None:
        if self.kind != "event":
            return None
        return _as_optional_str(self._payload.get("delta"))

    @property
    def tool(self) -> str | None:
        if self.kind != "event":
            return None
        return _as_optional_str(self._payload.get("tool"))

    @property
    def message(self) -> str | None:
        if self.kind != "event":
            return None
        return _as_optional_str(self._payload.get("message"))

    @property
    def error(self) -> str | None:
        if self.kind == "snapshot":
            state = self.state
            return state.error if state is not None else None
        if self.kind != "event":
            return None
        return _as_optional_str(self._payload.get("error"))

    @property
    def request_id(self) -> str | None:
        if self.kind == "snapshot":
            state = self.state
            return state.request_id if state is not None else None
        return _as_optional_str(self._payload.get("request_id"))

    @property
    def trace_id(self) -> str | None:
        if self.kind == "snapshot":
            state = self.state
            return state.trace_id if state is not None else None
        return _as_optional_str(self._payload.get("trace_id"))

    @property
    def success(self) -> bool | None:
        if self.kind != "event":
            return None
        value = self._payload.get("success")
        return bool(value) if isinstance(value, bool) else None

    @property
    def usage(self) -> dict[str, Any] | None:
        if self.kind != "event":
            return None
        value = self._payload.get("usage")
        return dict(value) if isinstance(value, Mapping) else None

    @property
    def file(self) -> dict[str, Any] | None:
        if self.kind != "event":
            return None
        value = self._payload.get("file")
        return dict(value) if isinstance(value, Mapping) else None

    @property
    def is_terminal(self) -> bool:
        if self.kind == "snapshot":
            state = self.state
            return state.is_terminal if state is not None else False
        if self.kind != "event":
            return False
        evt_type = self.type
        return evt_type in _TERMINAL_LIVE_EVENT_TYPES if evt_type else False

    def __repr__(self) -> str:
        if self.kind == "snapshot":
            return f"{self.__class__.__name__}(kind='snapshot', id={self.id!r}, state={self.state!r})"
        return (
            f"{self.__class__.__name__}(kind={self.kind!r}, id={self.id!r}, "
            f"event_name={self.event_name!r}, type={self.type!r})"
        )


class LiveRunBase:
    """Shared thin live-run handle with stream/state/history/abort helpers."""

    def __init__(
        self,
        *,
        session_id: str,
        request_id: str | None,
        status: str,
        stream_fn: Callable[..., Iterator[LiveEnvelopeBase]],
        state_fn: Callable[..., LiveStateBase],
        history_fn: Callable[..., list[dict[str, Any]]],
        abort_fn: Callable[..., bool],
        state_cls: type[LiveStateBase] = LiveStateBase,
    ) -> None:
        self.session_id = session_id
        self.request_id = request_id
        self.status = status
        self.last_event_id: str | None = None
        self._stream_fn = stream_fn
        self._state_fn = state_fn
        self._history_fn = history_fn
        self._abort_fn = abort_fn
        self._state_cls = state_cls
        self._state_data: dict[str, Any] | None = None

    def _cached_state(self) -> LiveStateBase | None:
        if self._state_data is None:
            return None
        return self._state_cls(dict(self._state_data))

    def _remember_state(self, data: Mapping[str, Any]) -> LiveStateBase:
        self._state_data = _normalize_live_state_data(
            data,
            session_id=self.session_id,
            request_id=self.request_id,
            fallback_status=self.status or "running",
        )
        state = self._cached_state()
        assert state is not None
        if not self.request_id and state.request_id:
            self.request_id = state.request_id
            self._state_data["requestId"] = state.request_id
        return state

    def _remember_envelope(self, envelope: LiveEnvelopeBase) -> LiveStateBase:
        self._state_data = _apply_live_envelope_to_state_data(
            self._state_data,
            envelope,
            session_id=self.session_id,
            request_id=self.request_id,
            fallback_status=self.status or "running",
        )
        state = self._cached_state()
        assert state is not None
        if not self.request_id and state.request_id:
            self.request_id = state.request_id
            self._state_data["requestId"] = state.request_id
        return state

    def _remember_history(self, history: list[dict[str, Any]]) -> LiveStateBase | None:
        synthesized = _live_state_from_history(
            history,
            session_id=self.session_id,
            request_id=self.request_id,
        )
        if synthesized is None:
            return self._cached_state()
        return self._remember_state(synthesized)

    def stream(
        self,
        *,
        wait_ms: int | None = 10000,
        last_event_id: str | None = None,
        timeout: int = 300,
    ) -> Iterator[LiveEnvelopeBase]:
        """Stream live envelopes for this run."""
        cursor = self.last_event_id if last_event_id is None else last_event_id
        for envelope in self._stream_fn(wait_ms=wait_ms, last_event_id=cursor, timeout=timeout):
            if envelope.id:
                self.last_event_id = envelope.id
            if not self.request_id and envelope.request_id:
                self.request_id = envelope.request_id
            self._remember_envelope(envelope)
            yield envelope

    def state(self, *, timeout: int = 30) -> LiveStateBase:
        """Fetch the latest live snapshot for this run's session."""
        cached = self._cached_state()
        if cached is not None and cached.is_terminal:
            return cached
        try:
            state = self._state_fn(timeout=timeout)
        except RuntimeError:
            history = self.history(timeout=timeout)
            synthesized = self._remember_history(history)
            if synthesized is not None:
                return synthesized
            raise
        return self._remember_state(state.raw)

    def history(self, *, timeout: int = 30) -> list[dict[str, Any]]:
        """Fetch parsed durable session history for this run's session."""
        return self._history_fn(timeout=timeout)

    def abort(self, *, timeout: int = 30) -> bool:
        """Abort the active run for this run's session."""
        return self._abort_fn(timeout=timeout)

    def wait(self, *, timeout: int = 300, poll_interval: float = 0.5) -> LiveStateBase:
        """Follow the live stream until the run reaches a terminal status."""
        if timeout <= 0:
            raise ValueError("timeout must be > 0")
        if poll_interval <= 0:
            raise ValueError("poll_interval must be > 0")

        deadline = time.monotonic() + timeout
        while True:
            cached = self._cached_state()
            if cached is not None and cached.is_terminal:
                if not cached.assistant_text:
                    history_state = self._remember_history(self.history(timeout=30))
                    if history_state is not None:
                        cached = history_state
                return cached

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(
                    f"Timed out waiting for live run {self.request_id or self.session_id!r}"
                )

            wait_ms = max(0, min(10000, int(remaining * 1000)))
            stream_timeout = max(1, int(remaining) + 5)
            try:
                for _evt in self.stream(wait_ms=wait_ms, timeout=stream_timeout):
                    pass
            except LumeraAPIError as exc:
                if exc.status_code != 409:
                    raise
            except LiveStreamError:
                pass

            cached = self._cached_state()
            if cached is not None and cached.is_terminal:
                if not cached.assistant_text:
                    history_state = self._remember_history(self.history(timeout=30))
                    if history_state is not None:
                        cached = history_state
                return cached

            history_state = self._remember_history(self.history(timeout=30))
            if history_state is not None and history_state.is_terminal:
                return history_state

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(
                    f"Timed out waiting for live run {self.request_id or self.session_id!r}"
                )
            time.sleep(min(poll_interval, max(0.0, remaining)))

    def print_stream(
        self,
        *,
        show_tools: bool = True,
        show_thinking: bool = False,
        show_usage: bool = True,
        show_resets: bool = True,
        timestamps: bool = False,
        wait_ms: int | None = 10000,
        timeout: int = 300,
        file: IO[str] | None = None,
    ) -> LiveStateBase:
        """Convenience renderer for CLI / notebook live streaming.

        This is intentionally a thin default renderer over ``stream()``. It is
        useful for scripts and local debugging when you want to see what the
        agent is doing without building your own event loop.
        """
        out = file or sys.stdout
        at_line_start = True
        started_at = time.monotonic()

        def _prefix() -> str:
            return f"[{time.strftime('%H:%M:%S')}] " if timestamps else ""

        def _write_text(text: str) -> None:
            nonlocal at_line_start
            if not text:
                return
            if at_line_start and timestamps:
                out.write(_prefix())
            out.write(text)
            out.flush()
            at_line_start = text.endswith("\n")

        def _write_line(text: str) -> None:
            nonlocal at_line_start
            if not at_line_start:
                out.write("\n")
            out.write(f"{_prefix()}{text}\n")
            out.flush()
            at_line_start = True

        for evt in self.stream(wait_ms=wait_ms, timeout=timeout):
            if evt.kind == "snapshot":
                continue
            if evt.kind == "reset":
                if show_resets:
                    _write_line("[reset] live cursor unavailable, resynced to latest state")
                continue
            evt_type = evt.type or evt.event_name or "event"
            if evt_type == "text_delta":
                _write_text(evt.delta or "")
                continue
            if evt_type == "thinking_delta":
                if show_thinking and evt.delta:
                    _write_line(f"[thinking] {evt.delta}")
                continue
            if evt_type == "tool_start":
                if show_tools:
                    _write_line(f"[tool:start] {evt.tool or 'tool'}")
                continue
            if evt_type == "tool_end":
                if show_tools:
                    if evt.success is False:
                        _write_line(f"[tool:error] {evt.tool or 'tool'}")
                    else:
                        _write_line(f"[tool:end] {evt.tool or 'tool'}")
                continue
            if evt_type == "tool_progress":
                if show_tools and evt.message:
                    _write_line(f"[tool:progress] {evt.message}")
                continue
            if evt_type == "usage":
                if show_usage and evt.usage is not None:
                    usage = evt.usage
                    _write_line(
                        "[usage] input={input} output={output} cacheRead={cache_read} cacheWrite={cache_write}".format(
                            input=usage.get("input", 0),
                            output=usage.get("output", 0),
                            cache_read=usage.get("cacheRead", 0),
                            cache_write=usage.get("cacheWrite", 0),
                        )
                    )
                continue
            if evt_type == "file_created":
                file_info = evt.file or {}
                name = file_info.get("name") or "artifact"
                _write_line(f"[file] {name}")
                continue
            if evt_type == "session_update":
                if evt.message:
                    _write_line(f"[session] {evt.message}")
                continue
            if evt_type == "info":
                if evt.message:
                    _write_line(f"[info] {evt.message}")
                continue
            if evt_type == "error":
                _write_line(f"[error] {evt.error or 'live run failed'}")
                continue
            if evt_type == "terminal":
                terminal_status = _as_optional_str(evt.payload.get("status")) or "completed"
                _write_line(f"[done] {terminal_status}")
                continue
            if evt_type == "done":
                if evt.success is False:
                    _write_line("[done] failed")
                else:
                    _write_line("[done] completed")
                continue
            if evt.message:
                _write_line(f"[{evt_type}] {evt.message}")

        state = self._cached_state()
        if state is not None and state.is_terminal:
            if not state.assistant_text:
                history_state = self._remember_history(self.history(timeout=30))
                if history_state is not None:
                    state = history_state
            return state

        remaining = max(0.1, timeout - (time.monotonic() - started_at))
        return self.wait(timeout=remaining)


def _normalize_live_state_data(
    data: Mapping[str, Any] | None,
    *,
    session_id: str,
    request_id: str | None,
    fallback_status: str,
) -> dict[str, Any]:
    normalized = dict(data or {})
    normalized.setdefault("sessionId", session_id)
    if request_id and not normalized.get("requestId"):
        normalized["requestId"] = request_id
    normalized.setdefault("status", fallback_status)

    assistant = normalized.get("assistant")
    if not isinstance(assistant, Mapping):
        assistant = {}
    assistant_map = dict(assistant)
    assistant_map.setdefault("content", "")
    blocks = assistant_map.get("blocks")
    assistant_map["blocks"] = builtins.list(blocks) if isinstance(blocks, builtins.list) else []
    normalized["assistant"] = assistant_map

    tool_calls = normalized.get("toolCalls")
    normalized["toolCalls"] = builtins.list(tool_calls) if isinstance(tool_calls, builtins.list) else []
    actions = normalized.get("actions")
    normalized["actions"] = builtins.list(actions) if isinstance(actions, builtins.list) else []
    normalized.setdefault("canContinue", False)
    normalized.setdefault("lastSeq", 0)
    return normalized


def _parse_live_event_id(event_id: str | None) -> tuple[int, int] | None:
    if not event_id or ":" not in event_id:
        return None
    epoch_str, seq_str = event_id.split(":", 1)
    try:
        return int(epoch_str), int(seq_str)
    except ValueError:
        return None


def _apply_live_envelope_to_state_data(
    state_data: Mapping[str, Any] | None,
    envelope: LiveEnvelopeBase,
    *,
    session_id: str,
    request_id: str | None,
    fallback_status: str,
) -> dict[str, Any]:
    if envelope.kind == "snapshot" and envelope.state is not None:
        return _normalize_live_state_data(
            envelope.state.raw,
            session_id=session_id,
            request_id=request_id or envelope.request_id,
            fallback_status=fallback_status,
        )

    data = _normalize_live_state_data(
        state_data,
        session_id=session_id,
        request_id=request_id or envelope.request_id,
        fallback_status=fallback_status,
    )

    parsed_event_id = _parse_live_event_id(envelope.id)
    if parsed_event_id is not None:
        stream_epoch, last_seq = parsed_event_id
        data["streamEpoch"] = stream_epoch
        data["lastSeq"] = last_seq

    if envelope.request_id and not data.get("requestId"):
        data["requestId"] = envelope.request_id

    if envelope.kind != "event":
        return data

    evt_type = envelope.type or envelope.event_name or "event"
    assistant = dict(data.get("assistant") or {})
    assistant.setdefault("content", "")
    assistant.setdefault("blocks", [])

    if evt_type == "text_delta" and envelope.delta:
        assistant["content"] = _as_str(assistant.get("content")) + envelope.delta
        data["assistant"] = assistant
        data["status"] = "running"
        return data

    if evt_type == "usage" and envelope.usage is not None:
        data["usage"] = envelope.usage
        return data

    if evt_type == "error":
        message = envelope.error or "live run failed"
        data["error"] = message
        lowered = message.lower()
        data["status"] = "aborted" if "cancel" in lowered else "failed"
        return data

    if evt_type == "terminal":
        payload = envelope.payload
        status = _as_optional_str(payload.get("status"))
        if status:
            data["status"] = status
        else:
            data["status"] = "failed" if envelope.error else "completed"
        if "canContinue" in payload:
            data["canContinue"] = bool(payload.get("canContinue"))
        if envelope.error:
            data["error"] = envelope.error
        return data

    if evt_type == "done":
        data["status"] = "failed" if envelope.success is False else "completed"
        return data

    return data


def _live_state_from_history(
    history: list[dict[str, Any]],
    *,
    session_id: str,
    request_id: str | None,
) -> dict[str, Any] | None:
    assistant_message: dict[str, Any] | None = None
    if request_id:
        for message in reversed(history):
            if not isinstance(message, Mapping):
                continue
            if _as_str(message.get("role")) != "assistant":
                continue
            if _as_optional_str(message.get("request_id")) == request_id:
                assistant_message = dict(message)
                break
    if assistant_message is None:
        for message in reversed(history):
            if not isinstance(message, Mapping):
                continue
            if _as_str(message.get("role")) == "assistant":
                assistant_message = dict(message)
                break
    if assistant_message is None:
        return None

    blocks = assistant_message.get("blocks")
    return _normalize_live_state_data(
        {
            "sessionId": session_id,
            "status": "completed",
            "requestId": _as_optional_str(assistant_message.get("request_id")) or request_id,
            "assistant": {
                "content": _as_str(assistant_message.get("content")),
                "blocks": builtins.list(blocks) if isinstance(blocks, builtins.list) else [],
            },
            "toolCalls": [],
            "actions": [],
            "canContinue": False,
        },
        session_id=session_id,
        request_id=request_id,
        fallback_status="completed",
    )


def _stream_live_request(
    path: str,
    *,
    params: Mapping[str, Any],
    last_event_id: str | None,
    timeout: int,
    envelope_cls: type[LiveEnvelopeBase],
    error_cls: type[LiveStreamError],
    require_terminal: bool = True,
) -> Iterator[LiveEnvelopeBase]:
    headers = _api_headers(accept="text/event-stream")
    if last_event_id:
        headers["Last-Event-ID"] = last_event_id

    session = _get_session()
    url = _api_url(path)

    with session.request("GET", url, params=params, headers=headers, stream=True, timeout=timeout) as resp:
        if not resp.ok:
            _raise_api_error(resp)

        event_count = 0
        saw_terminal = False
        current_event = "message"
        current_id: str | None = None
        current_data_lines: list[str] = []

        for line in resp.iter_lines(decode_unicode=True):
            if line is None:
                continue
            if line.startswith(":"):
                continue
            if line.startswith("event:"):
                current_event = line[6:].strip() or "message"
                continue
            if line.startswith("id:"):
                current_id = line[3:].strip() or None
                continue
            if line.startswith("data:"):
                value = line[5:]
                if value.startswith(" "):
                    value = value[1:]
                current_data_lines.append(value)
                continue
            if line != "":
                continue

            envelope = _finish_sse_frame(
                event_name=current_event,
                event_id=current_id,
                data_lines=current_data_lines,
                envelope_cls=envelope_cls,
                error_cls=error_cls,
            )
            current_event = "message"
            current_id = None
            current_data_lines = []
            if envelope is None:
                continue
            event_count += 1
            saw_terminal = saw_terminal or envelope.is_terminal
            yield envelope

        trailing = _finish_sse_frame(
            event_name=current_event,
            event_id=current_id,
            data_lines=current_data_lines,
            envelope_cls=envelope_cls,
            error_cls=error_cls,
        )
        if trailing is not None:
            event_count += 1
            saw_terminal = saw_terminal or trailing.is_terminal
            yield trailing

        if not require_terminal:
            return
        if not saw_terminal:
            if event_count == 0 and last_event_id:
                return
            raise error_cls(
                (
                    "Live stream ended before any terminal state was observed"
                    if event_count > 0
                    else "Live stream ended before any events arrived"
                ),
                event_count=event_count,
            )


def _finish_sse_frame(
    *,
    event_name: str,
    event_id: str | None,
    data_lines: list[str],
    envelope_cls: type[LiveEnvelopeBase],
    error_cls: type[LiveStreamError],
) -> LiveEnvelopeBase | None:
    if not data_lines:
        return None

    raw = "\n".join(data_lines)
    try:
        payload_obj = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise error_cls(f"Failed to parse live stream payload for event {event_name!r}") from exc
    if not isinstance(payload_obj, Mapping):
        raise error_cls(
            f"Unexpected live stream payload type for event {event_name!r}: {type(payload_obj)!r}"
        )
    payload = dict(payload_obj)

    if event_name == "snapshot":
        return envelope_cls("snapshot", event_id=event_id, event_name=event_name, payload=payload)
    if event_name == "reset":
        return envelope_cls("reset", event_id=event_id, event_name=event_name, payload=payload)
    return envelope_cls("event", event_id=event_id, event_name=event_name, payload=payload)


def _normalize_session_id(session_id: str | None) -> str:
    if session_id and session_id.strip():
        return session_id.strip()
    return "default"


def _as_str(value: Any) -> str:
    return value if isinstance(value, str) else ""


def _as_optional_str(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value
    return None


def _as_int(value: Any) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return 0


def _coerce_mapping(value: object, *, name: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise RuntimeError(f"Unexpected {name} response: expected object, got {type(value)!r}")
    return dict(value)
