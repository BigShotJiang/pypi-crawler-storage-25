"""
Slack Integration

Provides an authenticated Slack WebClient using Lumera-managed OAuth credentials.

Example:
    from lumera.integrations import slack

    # Send a message
    slack.send_message("#general", "Hello from Lumera!")

    # Reply in a thread
    slack.reply_in_thread("#general", "1234567890.123456", "Thread reply")

    # Get the raw client for advanced usage
    client = slack.get_client()
    client.reactions_add(channel="C123", timestamp="1234567890.123456", name="thumbsup")
"""

import logging
from typing import Any, Optional

from slack_sdk import WebClient

from .._utils import get_access_token

logger = logging.getLogger(__name__)


def get_client(token: Optional[str] = None) -> WebClient:
    """
    Returns an authenticated Slack WebClient.

    If no token is provided, fetches a Slack access token from Lumera.
    """
    if token is None:
        token = get_access_token("slack")
    return WebClient(token=token)


def send_message(
    channel: str,
    text: str,
    thread_ts: Optional[str] = None,
    client: Optional[WebClient] = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Post a message to a Slack channel."""
    if client is None:
        client = get_client()
    response = client.chat_postMessage(
        channel=channel,
        text=text,
        thread_ts=thread_ts,
        **kwargs,
    )
    return response.data


def reply_in_thread(
    channel: str,
    thread_ts: str,
    text: str,
    client: Optional[WebClient] = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Reply to a message thread."""
    return send_message(
        channel=channel,
        text=text,
        thread_ts=thread_ts,
        client=client,
        **kwargs,
    )


def upload_file(
    channels: str,
    file_path: Optional[str] = None,
    content: Optional[str] = None,
    filename: Optional[str] = None,
    title: Optional[str] = None,
    client: Optional[WebClient] = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Upload a file to Slack. Provide either file_path or content."""
    if client is None:
        client = get_client()

    upload_kwargs: dict[str, Any] = {"channel": channels, **kwargs}
    if file_path is not None:
        upload_kwargs["file"] = file_path
    if content is not None:
        upload_kwargs["content"] = content
    if filename is not None:
        upload_kwargs["filename"] = filename
    if title is not None:
        upload_kwargs["title"] = title

    response = client.files_upload_v2(**upload_kwargs)
    return response.data


def add_reaction(
    channel: str,
    timestamp: str,
    name: str,
    client: Optional[WebClient] = None,
) -> dict[str, Any]:
    """Add an emoji reaction to a message."""
    if client is None:
        client = get_client()
    response = client.reactions_add(
        channel=channel,
        timestamp=timestamp,
        name=name,
    )
    return response.data


def get_channel_history(
    channel: str,
    limit: int = 100,
    client: Optional[WebClient] = None,
    **kwargs: Any,
) -> list[dict[str, Any]]:
    """Fetch recent messages from a channel."""
    if client is None:
        client = get_client()
    response = client.conversations_history(
        channel=channel,
        limit=limit,
        **kwargs,
    )
    return response.data.get("messages", [])


__all__ = [
    "get_client",
    "send_message",
    "reply_in_thread",
    "upload_file",
    "add_reaction",
    "get_channel_history",
]
