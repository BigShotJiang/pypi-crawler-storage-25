# memory-link-rewriter — link integrity + UID rewriting for MemForge folders.
#
# Spec: 0.4.0
#
# Subcommands:
#   check   — validate UID uniqueness + link integrity (path links + mem:uid)
#   rename  — move a file + rewrite all internal references to it
#   upgrade — rewrite path-form internal links to mem:uid form (when target has uid)
#
# Lays the foundation for the index generator + memory-rollup tool, both
# of which depend on stable UID resolution.
#
# v0.4 remit (normative, per SPEC.md §"Multi-agent concurrency / Tool-side
# contract"): this tool MUST NOT mirror-write the `superseded_by:` field as
# a side effect of any operation. Mirror-writing `superseded_by:` is
# exclusively the responsibility of the resolve operation
# (memforge-resolve), which writes it inside its atomic
# `memforge: resolve <topic>` commit. Adding mirror-write logic here would
# reintroduce an unguarded authority channel.
#
# Defaults: per-cwd memory folder ($USER-claude-projects/memory/) +
# ~/.claude/global-memory/. Override with --path (repeatable).

from __future__ import annotations

import argparse
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from memforge.frontmatter import parse as _mf_parse, has_frontmatter as _mf_has_fm  # noqa: E402

USER = os.environ.get("USER", "")
DEFAULT_PATHS = [
    Path.home() / ".claude" / "projects" / f"{USER}-claude-projects" / "memory",
    Path.home() / ".claude" / "global-memory",
]
ARCHIVE_DIRNAME = "archive"

# Markdown link regex: captures [text](target).
# Skips images (![...](...)) and reference-style links ([text][ref]).
LINK_RE = re.compile(r"(?<!!)\[([^\]\n]+?)\]\(([^)\n]+?)\)")
MEM_URI_RE = re.compile(r"^mem:([A-Za-z0-9_\-]+)$")


@dataclass
class Memory:
    path: Path                    # absolute path on disk
    relpath: Path                 # path relative to root (memory folder)
    root: Path                    # the memory folder root
    uid: str | None = None
    name: str | None = None
    tier: str | None = None
    has_frontmatter: bool = False


@dataclass
class FolderIndex:
    root: Path
    memories: list[Memory] = field(default_factory=list)
    by_uid: dict[str, Memory] = field(default_factory=dict)
    by_relpath: dict[str, Memory] = field(default_factory=dict)
    duplicate_uids: list[tuple[str, list[Memory]]] = field(default_factory=list)


# ----- frontmatter parsing -----

def parse_frontmatter(text: str) -> dict:
    """Compatibility shim. Returns full frontmatter dict (was scalar-only).
    Use memforge.frontmatter.parse() in new code."""
    fm, _ = _mf_parse(text)
    return fm


def has_frontmatter(text: str) -> bool:
    return _mf_has_fm(text)


# ----- folder scan -----

def walk_memory_files(root: Path) -> Iterable[Path]:
    """Yield all .md files under root, excluding archive/ subtrees and MEMORY.md."""
    for dirpath, dirnames, filenames in os.walk(root):
        # prune archive
        if ARCHIVE_DIRNAME in dirnames:
            dirnames.remove(ARCHIVE_DIRNAME)
        for fn in filenames:
            if not fn.endswith(".md"):
                continue
            if fn == "MEMORY.md":
                continue
            yield Path(dirpath) / fn


def index_folder(root: Path) -> FolderIndex:
    idx = FolderIndex(root=root)
    seen_uid: dict[str, Memory] = {}
    dup_groups: dict[str, list[Memory]] = {}

    for fpath in walk_memory_files(root):
        try:
            text = fpath.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        fm = parse_frontmatter(text)
        m = Memory(
            path=fpath,
            relpath=fpath.relative_to(root),
            root=root,
            uid=fm.get("uid"),
            name=fm.get("name"),
            tier=fm.get("tier"),
            has_frontmatter=has_frontmatter(text),
        )
        idx.memories.append(m)
        idx.by_relpath[str(m.relpath)] = m
        if m.uid:
            if m.uid in seen_uid:
                dup_groups.setdefault(m.uid, [seen_uid[m.uid]]).append(m)
            else:
                seen_uid[m.uid] = m
                idx.by_uid[m.uid] = m

    idx.duplicate_uids = list(dup_groups.items())
    return idx


# ----- link extraction + classification -----

@dataclass
class Link:
    text: str
    target: str
    is_mem_uri: bool
    uid: str | None  # set if is_mem_uri
    span: tuple[int, int]  # (start, end) in source text


def extract_links(text: str) -> list[Link]:
    out = []
    for m in LINK_RE.finditer(text):
        target = m.group(2).strip()
        mem_match = MEM_URI_RE.match(target)
        out.append(Link(
            text=m.group(1),
            target=target,
            is_mem_uri=mem_match is not None,
            uid=mem_match.group(1) if mem_match else None,
            span=(m.start(), m.end()),
        ))
    return out


def is_internal_path_link(target: str) -> bool:
    """A link is internal if it ends in .md and isn't an absolute URL or anchor-only."""
    if "://" in target:
        return False
    if target.startswith("#"):
        return False
    target = target.split("#", 1)[0]  # strip fragment
    return target.endswith(".md")


# ----- check subcommand -----

def cmd_check(idx: FolderIndex, *, json_out: bool = False) -> int:
    issues = []
    warnings = []

    # duplicate uids
    for uid, files in idx.duplicate_uids:
        issues.append(f"duplicate uid '{uid}' in {len(files)+1} files: " +
                      ", ".join(str(m.relpath) for m in files))

    # missing uids (warning only in v0.3.0; will be error in v0.4.0)
    missing_uid = [m for m in idx.memories if not m.uid and m.has_frontmatter]
    if missing_uid:
        warnings.append(f"{len(missing_uid)} files missing uid (required in v0.4.0)")
        for m in missing_uid[:5]:
            warnings.append(f"  - {m.relpath}")
        if len(missing_uid) > 5:
            warnings.append(f"  - ... ({len(missing_uid) - 5} more)")

    # link integrity
    broken_path_links: list[tuple[Memory, Link]] = []
    broken_mem_links: list[tuple[Memory, Link]] = []
    for m in idx.memories:
        text = m.path.read_text(encoding="utf-8")
        for link in extract_links(text):
            if link.is_mem_uri:
                if link.uid not in idx.by_uid:
                    broken_mem_links.append((m, link))
            elif is_internal_path_link(link.target):
                target_path = link.target.split("#", 1)[0]
                # resolve relative to the file's directory
                resolved = (m.path.parent / target_path).resolve()
                try:
                    rel = resolved.relative_to(idx.root)
                except ValueError:
                    continue  # link goes outside the memory folder
                if str(rel) not in idx.by_relpath and not (idx.root / rel).exists():
                    broken_path_links.append((m, link))

    if broken_mem_links:
        issues.append(f"{len(broken_mem_links)} broken mem:uid links")
        for m, link in broken_mem_links[:10]:
            issues.append(f"  - {m.relpath}: mem:{link.uid} -> not found")

    if broken_path_links:
        issues.append(f"{len(broken_path_links)} broken path links")
        for m, link in broken_path_links[:10]:
            issues.append(f"  - {m.relpath}: {link.target} -> not found")

    # report
    print(f"====== {idx.root} ======")
    print(f"  Files indexed: {len(idx.memories)}")
    print(f"  With UID: {sum(1 for m in idx.memories if m.uid)}")
    print(f"  Tier=index: {sum(1 for m in idx.memories if m.tier == 'index')}")
    print(f"  Tier=detail: {sum(1 for m in idx.memories if m.tier == 'detail')}")
    print()

    if issues:
        print("  ISSUES:")
        for line in issues:
            print(f"    {line}")
        print()
    if warnings:
        print("  WARNINGS:")
        for line in warnings:
            print(f"    {line}")
        print()

    return 1 if issues else 0


# ----- rename subcommand -----

def cmd_rename(idx: FolderIndex, src: Path, dst: Path, *, dry_run: bool) -> int:
    """Move src to dst within the memory folder + rewrite all references."""
    root_resolved = idx.root.resolve()
    src_abs = src.resolve()
    dst_abs = dst.resolve()
    try:
        src_rel = src_abs.relative_to(root_resolved)
        dst_rel = dst_abs.relative_to(root_resolved)
    except ValueError:
        print(f"error: src or dst outside memory root {idx.root} (resolved={root_resolved})", file=sys.stderr)
        return 2

    if not src_abs.exists():
        print(f"error: source file does not exist: {src_abs}", file=sys.stderr)
        return 2
    if dst_abs.exists():
        print(f"error: destination already exists: {dst_abs}", file=sys.stderr)
        return 2

    # find all references to src in OTHER files
    src_basename = src_abs.name
    src_relpath_str = str(src_rel)
    rewrites: list[tuple[Memory, list[tuple[Link, str]]]] = []

    for m in idx.memories:
        if m.path == src_abs:
            continue
        text = m.path.read_text(encoding="utf-8")
        per_file: list[tuple[Link, str]] = []
        for link in extract_links(text):
            if link.is_mem_uri:
                continue  # mem:uid is stable across renames; no rewrite needed
            if not is_internal_path_link(link.target):
                continue
            link_path = link.target.split("#", 1)[0]
            link_resolved = (m.path.parent / link_path).resolve()
            if link_resolved == src_abs:
                # rewrite to dst (relative to this file's parent)
                new_rel = os.path.relpath(dst_abs, m.path.parent)
                fragment = ("#" + link.target.split("#", 1)[1]) if "#" in link.target else ""
                new_target = new_rel + fragment
                per_file.append((link, new_target))
        if per_file:
            rewrites.append((m, per_file))

    print(f"rename: {src_rel} -> {dst_rel}")
    print(f"references to rewrite: {sum(len(per) for _, per in rewrites)} in {len(rewrites)} files")
    for m, per in rewrites:
        print(f"  {m.relpath}:")
        for link, new in per:
            print(f"    {link.target} -> {new}")

    if dry_run:
        print("\n(dry-run; no changes written)")
        return 0

    # move file
    dst_abs.parent.mkdir(parents=True, exist_ok=True)
    src_abs.rename(dst_abs)

    # rewrite references
    for m, per in rewrites:
        text = m.path.read_text(encoding="utf-8")
        # apply rewrites in reverse to keep spans valid
        per_sorted = sorted(per, key=lambda x: -x[0].span[0])
        for link, new in per_sorted:
            start, end = link.span
            old_md = text[start:end]
            new_md = f"[{link.text}]({new})"
            text = text[:start] + new_md + text[end:]
        m.path.write_text(text, encoding="utf-8")

    print(f"\nmoved + rewrote {len(rewrites)} files")
    return 0


# ----- rename-batch subcommand -----

def cmd_rename_batch(idx: FolderIndex, pairs: list[tuple[Path, Path]], *, dry_run: bool) -> int:
    """Move many files + rewrite all internal references in ONE pass.

    Closes the O(N) subprocess-spawn pattern in memory-rollup. Cost: one
    folder index + one file-walk + one write per affected file, regardless
    of how many files are being moved.
    """
    root_resolved = idx.root.resolve()
    src_to_dst: dict[Path, Path] = {}
    for src, dst in pairs:
        src_abs = src.resolve()
        dst_abs = dst.resolve()
        try:
            src_abs.relative_to(root_resolved)
            dst_abs.relative_to(root_resolved)
        except ValueError:
            print(f"error: src or dst outside memory root {idx.root} (resolved={root_resolved})", file=sys.stderr)
            return 2
        if not src_abs.exists():
            print(f"error: source file does not exist: {src_abs}", file=sys.stderr)
            return 2
        if dst_abs.exists():
            print(f"error: destination already exists: {dst_abs}", file=sys.stderr)
            return 2
        src_to_dst[src_abs] = dst_abs

    if not src_to_dst:
        print("rename-batch: empty pair list; nothing to do")
        return 0

    src_set = set(src_to_dst.keys())
    # Per-memory rewrite plan. For each memory, the "effective parent dir"
    # is its post-move location (same as current for non-moved files; the
    # mapped destination's parent for moved files). Relative paths are
    # computed against that effective parent so links survive the move.
    rewrites: list[tuple[Memory, Path, list[tuple[Link, str]]]] = []

    for m in idx.memories:
        m_resolved = m.path.resolve()
        is_moved = m_resolved in src_set
        new_m_dir = src_to_dst[m_resolved].parent if is_moved else m.path.parent.resolve()

        text = m.path.read_text(encoding="utf-8")
        per_file: list[tuple[Link, str]] = []
        for link in extract_links(text):
            if link.is_mem_uri:
                continue
            if not is_internal_path_link(link.target):
                continue
            link_path = link.target.split("#", 1)[0]
            link_resolved = (m.path.parent / link_path).resolve()
            # Determine the link target's post-move location.
            target_post = src_to_dst.get(link_resolved, link_resolved)
            if target_post == link_resolved and not is_moved:
                # neither this file nor the link target is being moved:
                # nothing to rewrite.
                continue
            new_rel = os.path.relpath(target_post, new_m_dir)
            fragment = ("#" + link.target.split("#", 1)[1]) if "#" in link.target else ""
            new_target = new_rel + fragment
            if new_target == link.target:
                continue
            per_file.append((link, new_target))
        if per_file:
            rewrites.append((m, new_m_dir, per_file))

    print(f"rename-batch: {len(src_to_dst)} files to move")
    print(f"references to rewrite: {sum(len(per) for _, _, per in rewrites)} in {len(rewrites)} files")

    if dry_run:
        for src, dst in pairs:
            print(f"  {src.resolve().relative_to(root_resolved)} -> {dst.resolve().relative_to(root_resolved)}")
        print("\n(dry-run; no changes written)")
        return 0

    # Pre-compute rewritten text for each affected memory; defer writes
    # until after moves so we can write to the post-move path.
    rewritten_text: dict[Path, str] = {}
    for m, _new_dir, per in rewrites:
        text = m.path.read_text(encoding="utf-8")
        per_sorted = sorted(per, key=lambda x: -x[0].span[0])
        for link, new in per_sorted:
            start, end = link.span
            new_md = f"[{link.text}]({new})"
            text = text[:start] + new_md + text[end:]
        rewritten_text[m.path.resolve()] = text

    moved: list[tuple[Path, Path]] = []
    try:
        for src_abs, dst_abs in src_to_dst.items():
            dst_abs.parent.mkdir(parents=True, exist_ok=True)
            src_abs.rename(dst_abs)
            moved.append((src_abs, dst_abs))

        for m_resolved, text in rewritten_text.items():
            target_path = src_to_dst.get(m_resolved, m_resolved)
            target_path.write_text(text, encoding="utf-8")
    except Exception as e:
        print(f"error during batch rename: {e}; rolling back {len(moved)} moves", file=sys.stderr)
        for src_abs, dst_abs in reversed(moved):
            try:
                dst_abs.rename(src_abs)
            except OSError:
                pass
        return 2

    print(f"\nmoved {len(src_to_dst)} files; rewrote refs in {len(rewrites)} files")
    return 0


# ----- upgrade subcommand -----

def cmd_upgrade(idx: FolderIndex, *, dry_run: bool) -> int:
    """Rewrite path-form internal links to mem:uid form when target has uid."""
    upgraded_count = 0
    files_touched = 0

    for m in idx.memories:
        text = m.path.read_text(encoding="utf-8")
        replacements: list[tuple[Link, str]] = []
        for link in extract_links(text):
            if link.is_mem_uri:
                continue
            if not is_internal_path_link(link.target):
                continue
            link_path = link.target.split("#", 1)[0]
            link_resolved = (m.path.parent / link_path).resolve()
            try:
                target_rel = link_resolved.relative_to(idx.root)
            except ValueError:
                continue
            target_mem = idx.by_relpath.get(str(target_rel))
            if target_mem and target_mem.uid:
                fragment = ("#" + link.target.split("#", 1)[1]) if "#" in link.target else ""
                replacements.append((link, f"mem:{target_mem.uid}{fragment}"))

        if not replacements:
            continue

        files_touched += 1
        upgraded_count += len(replacements)
        print(f"  {m.relpath}: {len(replacements)} link(s)")
        for link, new in replacements[:3]:
            print(f"    {link.target} -> {new}")
        if len(replacements) > 3:
            print(f"    ... +{len(replacements) - 3} more")

        if not dry_run:
            replacements_sorted = sorted(replacements, key=lambda x: -x[0].span[0])
            for link, new in replacements_sorted:
                start, end = link.span
                new_md = f"[{link.text}]({new})"
                text = text[:start] + new_md + text[end:]
            m.path.write_text(text, encoding="utf-8")

    print(f"\nupgraded {upgraded_count} link(s) in {files_touched} file(s)")
    if dry_run:
        print("(dry-run; no changes written)")
    return 0


# ----- main -----

def main() -> int:
    p = argparse.ArgumentParser(
        prog="memory-link-rewriter",
        description="Link integrity + UID rewriting for MemForge folders (spec 0.3.0).",
    )
    p.add_argument("--path", action="append", type=Path,
                   help="Memory folder to operate on (repeatable; defaults to per-cwd + global).")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_check = sub.add_parser("check", help="Validate UID uniqueness + link integrity.")

    p_rename = sub.add_parser("rename", help="Move a file + rewrite references.")
    p_rename.add_argument("src", type=Path)
    p_rename.add_argument("dst", type=Path)
    p_rename.add_argument("--dry-run", action="store_true")

    p_batch = sub.add_parser("rename-batch",
        help="Move multiple files + rewrite references in ONE pass. "
             "Reads JSON [{\"src\":\"...\",\"dst\":\"...\"},...] from --json or stdin.")
    p_batch.add_argument("--json", type=Path, default=None,
                         help="JSON file with [{src,dst},...]; reads stdin if omitted")
    p_batch.add_argument("--dry-run", action="store_true")

    p_upgrade = sub.add_parser("upgrade", help="Rewrite path links to mem:uid form.")
    p_upgrade.add_argument("--dry-run", action="store_true")

    args = p.parse_args()
    paths = args.path or DEFAULT_PATHS
    paths = [p for p in paths if p.is_dir()]

    if not paths:
        print("no memory folders found", file=sys.stderr)
        return 2

    rc = 0
    for root in paths:
        idx = index_folder(root)
        if args.cmd == "check":
            rc = max(rc, cmd_check(idx))
        elif args.cmd == "rename":
            rc = max(rc, cmd_rename(idx, args.src, args.dst, dry_run=args.dry_run))
        elif args.cmd == "rename-batch":
            import json as _json
            raw = args.json.read_text(encoding="utf-8") if args.json else sys.stdin.read()
            try:
                items = _json.loads(raw)
            except _json.JSONDecodeError as e:
                print(f"error: invalid JSON for rename-batch: {e}", file=sys.stderr)
                return 2
            pairs = [(Path(item["src"]), Path(item["dst"])) for item in items]
            rc = max(rc, cmd_rename_batch(idx, pairs, dry_run=args.dry_run))
        elif args.cmd == "upgrade":
            rc = max(rc, cmd_upgrade(idx, dry_run=args.dry_run))
    return rc


if __name__ == "__main__":
    sys.exit(main())
