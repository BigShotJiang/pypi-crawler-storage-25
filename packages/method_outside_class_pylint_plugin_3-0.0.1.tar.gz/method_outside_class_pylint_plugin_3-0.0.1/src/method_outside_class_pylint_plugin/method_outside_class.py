from astroid import nodes
from typing import TYPE_CHECKING, Optional

from pylint.checkers import BaseChecker

if TYPE_CHECKING:
    from pylint.lint import PyLinter

def register(linter: "PyLinter") -> None:
    """This required method auto registers the checker during initialization.
    :param linter: The linter to register the checker to.
    """
    linter.register_checker(ClasslessMethod(linter))

class ClasslessMethod(BaseChecker):

    name = "method-outside-class"
    msgs = {
        "W5100": (
            "Method defined outside class",
            "classless-method",
            "Used when a method is defined outside class"
        ),
    }

    def __init__(self, linter: Optional["PyLinter"] = None) -> None:
        super().__init__(linter)


    def visit_functiondef(self, node: nodes.FunctionDef) -> None:
        if not isinstance(node.parent, nodes.ClassDef):
            self.add_message("W5100", node=node)