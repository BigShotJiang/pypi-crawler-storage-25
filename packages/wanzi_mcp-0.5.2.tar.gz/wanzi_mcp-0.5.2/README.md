# 丸子 MCP (wanzi-mcp)

Cursor AI 聊天桥接工具 —— 在独立 GUI 窗口中与 Cursor AI 实时对话。

## 安装

```bash
pip install wanzi-mcp
```

PyPI → https://pypi.org/project/wanzi-mcp/

## CLI 命令

| 命令 | 说明 |
|------|------|
| `wanzi` | 启动后端 + GUI 窗口（默认模式） |
| `wanzi serve` | 只启动后端服务（MCP Server，IDE 自动调用） |
| `wanzi gui` | 只打开 GUI 窗口（需后端已运行） |
| `wanzi install` | 写入 `~/.cursor/mcp.json` 注册 MCP |

## 快速开始

```bash
# 1. 安装
pip install wanzi-mcp

# 2. 启动（后端 + GUI 一起启动）
wanzi

# 3. 注册到 Cursor（也可在 GUI 中点击"安装到 Cursor"按钮）
wanzi install
```

## 功能特性

- **实时对话** — GUI 窗口与 Cursor AI 双向消息通信
- **多会话隔离** — 每个 Cursor 对话自动分配独立会话
- **图片支持** — 支持发送和接收图片消息
- **会话管理** — 创建、重命名、删除会话，删除单条消息
- **自动端口释放** — 启动时自动清理占用端口的进程
- **阻塞式长轮询** — 工具调用阻塞到用户发消息，无超时中断问题
