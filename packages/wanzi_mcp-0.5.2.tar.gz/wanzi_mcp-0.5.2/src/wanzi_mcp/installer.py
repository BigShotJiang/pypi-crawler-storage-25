"""一键写入 Cursor 全局 mcp.json，注册丸子 MCP；同时配置超时。"""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
from pathlib import Path

MCP_TIMEOUT_MS = 604_800_000  # 7 天


def _cursor_settings_path() -> Path:
    sys = platform.system()
    if sys == "Windows":
        base = Path.home() / "AppData" / "Roaming"
    elif sys == "Darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path.home() / ".config"
    return base / "Cursor" / "User" / "settings.json"


def _configure_timeout(timeout_ms: int = MCP_TIMEOUT_MS):
    settings_path = _cursor_settings_path()
    if not settings_path.parent.exists():
        print(f"[SKIP] 未找到 Cursor 配置目录: {settings_path.parent}")
        return

    settings: dict = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text("utf-8"))
        except Exception:
            pass

    changed = False
    if settings.get("mcp.server.timeout") != timeout_ms:
        settings["mcp.server.timeout"] = timeout_ms
        changed = True

    if settings.get("cursor.agent.enableSubAgents") is not False:
        settings["cursor.agent.enableSubAgents"] = False
        changed = True

    if changed:
        settings_path.write_text(
            json.dumps(settings, indent=4, ensure_ascii=False), "utf-8"
        )
        print(f"[OK] Cursor settings 已更新 → {settings_path}")
    else:
        print(f"[OK] Cursor settings 无需修改")


_NO_SUBAGENT_RULE = """\
---
description: 禁止使用子代理
globs:
alwaysApply: true
---

Never use subagents or the Task tool. Always perform all work directly.
"""


def _write_no_subagents_rule():
    """Write a global Cursor rule to disable sub-agents."""
    rules_dir = Path.home() / ".cursor" / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)
    rule_path = rules_dir / "no-subagents.mdc"
    rule_path.write_text(_NO_SUBAGENT_RULE, "utf-8")
    print(f"[OK] 子代理禁用规则已写入 → {rule_path}")


def install_to_cursor(port: int = 8765):
    mcp_json = Path.home() / ".cursor" / "mcp.json"
    mcp_json.parent.mkdir(parents=True, exist_ok=True)

    config: dict = {}
    if mcp_json.exists():
        try:
            config = json.loads(mcp_json.read_text("utf-8"))
        except Exception:
            pass

    servers = config.setdefault("mcpServers", {})
    import sys
    py = sys.executable or "python"
    servers["wanzi-mcp"] = {
        "command": py,
        "args": ["-m", "wanzi_mcp", "--stdio", "--port", str(port)],
    }

    mcp_json.write_text(json.dumps(config, indent=2, ensure_ascii=False), "utf-8")
    print(f"[OK] written to {mcp_json}")
    print(f"  stdio mode: {py} -m wanzi_mcp --stdio --port {port}")

    _configure_timeout()
    _write_no_subagents_rule()


def _find_cursor_from_registry() -> str | None:
    """Windows: 从注册表卸载项中读取 Cursor 安装路径。"""
    try:
        import winreg
    except ImportError:
        return None

    uninstall_key = r"Software\Microsoft\Windows\CurrentVersion\Uninstall"
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, uninstall_key) as key:
            i = 0
            while True:
                try:
                    sub_name = winreg.EnumKey(key, i)
                    i += 1
                except OSError:
                    break
                try:
                    with winreg.OpenKey(key, sub_name) as sub:
                        name, _ = winreg.QueryValueEx(sub, "DisplayName")
                        if "cursor" in str(name).lower():
                            loc, _ = winreg.QueryValueEx(sub, "InstallLocation")
                            exe = Path(loc) / "Cursor.exe"
                            if exe.exists():
                                return str(exe)
                except OSError:
                    continue
    except OSError:
        pass
    return None


def find_cursor_path() -> str | None:
    """自动查找 Cursor 可执行文件路径，返回 None 表示未找到。"""
    sys = platform.system()

    if sys == "Windows":
        # 优先从注册表获取（支持自定义安装路径）
        reg_path = _find_cursor_from_registry()
        if reg_path:
            return reg_path

        candidates = [
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "cursor" / "Cursor.exe",
            Path(os.environ.get("LOCALAPPDATA", "")) / "cursor" / "Cursor.exe",
        ]
        for p in candidates:
            if p.exists():
                return str(p)
        return shutil.which("cursor")

    if sys == "Darwin":
        app = Path("/Applications/Cursor.app/Contents/MacOS/Cursor")
        if app.exists():
            return str(app)
        return shutil.which("cursor")

    # Linux
    return shutil.which("cursor")


def open_cursor() -> dict:
    """启动 Cursor，返回 {ok, message, path}。"""
    path = find_cursor_path()
    if not path:
        return {"ok": False, "message": "未找到 Cursor，请确认已安装"}

    try:
        if platform.system() == "Windows":
            subprocess.Popen([path], creationflags=subprocess.DETACHED_PROCESS)
        else:
            subprocess.Popen([path], start_new_session=True)
        return {"ok": True, "message": "已启动 Cursor", "path": path}
    except Exception as e:
        return {"ok": False, "message": f"启动失败：{e}"}
