"""Cursor workbench.desktop.main.js one-click injection module.

Injects three patches:
  1. Block Cursor auto-update UI
  2. Block telemetry / data reporting
  3. Auto-retry green button in Composer toolbar
"""
from __future__ import annotations

import hashlib
import os
import platform
import re
import shutil
from datetime import datetime
from pathlib import Path

# ── Marker tags ──────────────────────────────────────────────────
_UPDATE_START = "/*WANZI_BLOCK_UPDATE_START*/"
_UPDATE_END = "/*WANZI_BLOCK_UPDATE_END*/"
_TELE_START = "/*WANZI_BLOCK_TELEMETRY_START*/"
_TELE_END = "/*WANZI_BLOCK_TELEMETRY_END*/"
_RETRY_START = "/*WANZI_AUTO_RETRY_START*/"
_RETRY_END = "/*WANZI_AUTO_RETRY_END*/"

_ALL_MARKERS = [
    (_UPDATE_START, _UPDATE_END),
    (_TELE_START, _TELE_END),
    (_RETRY_START, _RETRY_END),
]


# ── Injected script bodies ───────────────────────────────────────

BLOCK_UPDATE_SCRIPT = r""";(() => {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  if (window.__wanziUpdateBlockerInstalled) return;
  window.__wanziUpdateBlockerInstalled = true;
  var MODAL_KW = /Update recommended|newer version of Cursor|We recommend updating|Update available/i;
  var INLINE_KW = /New update available|Install Now|Later/i;
  function kill() {
    try { document.querySelectorAll('.cursor-modal-container').forEach(function(m) {
      if (MODAL_KW.test(m.textContent || '')) { var b = m.closest('.cursor-modal-backing') || m; if (b && b.parentNode) b.parentNode.removeChild(b); }
    }); } catch (e) {}
    try { document.querySelectorAll('.update-notification-outer-container, .minor-version-notification-container').forEach(function(n) {
      if (INLINE_KW.test(n.textContent || '')) { if (n.parentNode) n.parentNode.removeChild(n); }
    }); } catch (e) {}
  }
  function install() { kill(); try { var obs = new MutationObserver(kill); obs.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'] }); } catch (e) {} }
  if (document.body) install(); else document.addEventListener('DOMContentLoaded', install);
})();"""

BLOCK_TELEMETRY_SCRIPT = r""";(() => {
  if (typeof window === 'undefined') return;
  if (window.__wanziTelemetryBlockerInstalled) return;
  window.__wanziTelemetryBlockerInstalled = true;
  var BH = /(^|\.)dc\.services\.visualstudio\.com$|(^|\.)mobile\.events\.data\.microsoft\.com$|(^|\.)vortex\.data\.microsoft\.com$|(^|\.)browser\.events\.data\.microsoft\.com$/i;
  var BP = /\/(api|v0|aiserver\.v1\.AiService)\/(usage(\/|$)|telemetry|events|RecordEvent|RecordTelemetry|metrics)/i;
  function chk(u){if(!u)return false;var s=String(u);try{var o=new URL(s,location.origin);if(BH.test(o.hostname))return true;if(BP.test(o.pathname))return true;}catch(e){}return false;}
  try{var of=window.fetch;if(of&&!of.__wz){var wf=function(i,n){var u=(i&&i.url)?i.url:i;if(chk(u))return Promise.resolve(new Response('',{status:204}));return of.apply(this,arguments);};wf.__wz=true;window.fetch=wf;}}catch(e){}
  try{if(navigator.sendBeacon&&!navigator.sendBeacon.__wz){var ob=navigator.sendBeacon.bind(navigator);var wb=function(u,d){if(chk(u))return true;return ob(u,d);};wb.__wz=true;navigator.sendBeacon=wb;}}catch(e){}
  try{var xo=XMLHttpRequest.prototype.open;var xs=XMLHttpRequest.prototype.send;if(xo&&!xo.__wz){var wo=function(m,u){try{this.__wzB=chk(u);}catch(e){}return xo.apply(this,arguments);};wo.__wz=true;XMLHttpRequest.prototype.open=wo;var ws=function(b){if(this.__wzB){try{Object.defineProperty(this,'readyState',{value:4,configurable:true});}catch(e){}try{Object.defineProperty(this,'status',{value:204,configurable:true});}catch(e){}try{this.dispatchEvent(new Event('load'));}catch(e){}return;}return xs.apply(this,arguments);};ws.__wz=true;XMLHttpRequest.prototype.send=ws;}}catch(e){}
  try{var ss={_serviceBrand:undefined,sendErrorTelemetry:function(){return Promise.resolve();},publicLog:function(){return Promise.resolve();},publicLog2:function(){return Promise.resolve();},publicLogError:function(){return Promise.resolve();},publicLogError2:function(){return Promise.resolve();},setExperimentProperty:function(){},isOptedIn:false,telemetryLevel:0};Object.defineProperty(window,'__wanziSilentTelemetry',{value:ss,configurable:false,writable:false,enumerable:false});}catch(e){}
})();"""

AUTO_RETRY_SCRIPT = r""";try{(function(){
  "use strict";
  if(typeof window==='undefined'||typeof document==='undefined')return;
  if(window.__wanziRetryTeardown)window.__wanziRetryTeardown();
  var TAG="[Wanzi-Retry]";
  var LIMIT=500,GONE_MS=360,GONE_CAP=6000,APPEAR_MS=480;
  var SEL_POPUP=".composer-warning-popup";
  var SEL_STICKY=".composer-sticky-human-message";
  var SEL_EDITOR='.aislash-editor-input[contenteditable="true"]';
  var SEL_SEND=".send-with-mode .anysphere-icon-button";
  var SEL_ROOT="[data-composer-id]";
  function qs(r,s){return(r||document).querySelector(s);}
  function qsf(r,s){return(r&&r.querySelector(s))||document.querySelector(s);}
  function qsa(r,s){return(r||document).querySelectorAll(s);}
  function delay(ms){return new Promise(function(ok){setTimeout(ok,ms);});}
  function shortId(id){return String(id||"*").slice(-6);}
  function log(id,m){console.log(TAG+"["+shortId(id)+"] "+m);}
  function esc(id){try{return CSS.escape(id);}catch(e){return String(id).replace(/"/g,'\\"');}}
  function rootById(id){return document.querySelector('[data-composer-id="'+esc(id)+'"]');}
  var inst=Object.create(null);
  function buildIcon(){
    var NS="http://www.w3.org/2000/svg";var s=document.createElementNS(NS,"svg");
    s.setAttribute("viewBox","0 0 1024 1024");s.setAttribute("width","20");s.setAttribute("height","20");s.style.display="block";
    function p(d,c){var el=document.createElementNS(NS,"path");el.setAttribute("d",d);el.setAttribute("fill",c);return el;}
    s.appendChild(p("M512 0C229.2736 0 0 229.2736 0 512s229.2736 512 512 512 512-229.2736 512-512S794.7264 0 512 0z","#22c55e"));
    s.appendChild(p("M253.3376 589.6704l-1.3312-3.7888-0.768-2.3552-0.3584-0.9728-1.1264-3.2256-0.256-0.9216 12.3904 35.9936-12.9536-37.632-0.8704-2.56-0.256-0.5632-0.3584-1.0752-0.4608-1.28-0.1024-0.256h0.0512l-0.6144-1.7408-0.256-0.6144-0.512-1.536v-0.1024l-0.256-0.7168v-0.1536l0.256 0.8704-0.4608-2.7648a9.216 9.216 0 0 1 6.144-8.704l51.9168-17.92a9.216 9.216 0 0 1 11.6224 5.6832l14.848 43.2128a186.2144 186.2144 0 0 0 41.5232 62.976 187.648 187.648 0 1 0-23.3472-236.9536 36.5568 36.5568 0 1 1-60.7744-40.7552A260.096 260.096 0 0 1 503.8592 256a260.8128 260.8128 0 1 1-240.9984 360.6528l-0.512-0.8704a9.1648 9.1648 0 0 1-0.3072-0.8192l-0.2048-0.6144-1.1776-3.328-2.4064-6.3488a259.072 259.072 0 0 1-3.9936-12.1344l-0.2048-0.6656-0.768-2.2528 0.5632 1.4848-0.512-1.4336z","#fff"));
    s.appendChild(p("M239.872 404.7872l56.3712-144.5888a20.48 20.48 0 0 1 35.84-4.3008l98.816 141.0048a20.48 20.48 0 0 1-16.384 32.256l-155.136 3.5328a20.48 20.48 0 0 1-19.5072-27.904z","#fff"));
    return s;
  }
  var SPIN_ID="__wanzi_retry_anim";
  if(!document.getElementById(SPIN_ID)){var st=document.createElement("style");st.id=SPIN_ID;st.textContent="@keyframes wanzi-retry-rotate{0%{transform:rotate(0)}to{transform:rotate(360deg)}}";document.head.appendChild(st);}
  function locateToolbar(root){
    if(!root)return null;
    var nodes=qsa(root,".button-container.composer-button-area");
    if(nodes.length)return nodes[nodes.length-1];
    nodes=qsa(root,'[class*="composer-button-area"]');
    if(nodes.length)return nodes[nodes.length-1];
    var senders=qsa(root,".send-with-mode");
    for(var k=senders.length-1;k>=0;k--){
      if(!senders[k].querySelector(".anysphere-icon-button"))continue;
      var row=senders[k].closest('[class*="button-container"]')||senders[k].parentElement;
      if(row&&root.contains(row))return row;
    }
    return null;
  }
  function triggerBottomSend(root){
    if(!root)return false;
    var sels=[".button-container.composer-button-area "+SEL_SEND,".composer-button-area "+SEL_SEND,SEL_SEND];
    for(var i=0;i<sels.length;i++){var h=qsa(root,sels[i]);if(h.length){h[h.length-1].click();return true;}}
    var bar=locateToolbar(root);if(bar){var b=bar.querySelector(SEL_SEND);if(b){b.click();return true;}}
    return false;
  }
  function monitorEl(root,sel,want,timeout){
    return new Promise(function(resolve){
      if(!root){resolve(false);return;}
      var chk=function(){return!!qsf(root,sel);};
      if((want&&chk())||(!want&&!chk())){resolve(true);return;}
      var done=false;
      function fin(v){if(done)return;done=true;if(w1){w1.disconnect();w1=null;}if(w2){w2.disconnect();w2=null;}clearTimeout(t);resolve(v);}
      var w1=new MutationObserver(function(){var e=chk();if((want&&e)||(!want&&!e))fin(true);});
      w1.observe(root,{childList:true,subtree:true});
      var w2=null;
      if(document.body&&document.body!==root){w2=new MutationObserver(function(){var e=chk();if((want&&e)||(!want&&!e))fin(true);});w2.observe(document.body,{childList:true,subtree:true});}
      var t=setTimeout(function(){fin(false);},timeout);
    });
  }
  function waitSettled(root,sel,absentMs,capMs){
    return new Promise(function(resolve){
      var origin=Date.now(),sinceGone=null;
      function poll(){
        var present=root?!!qsf(root,sel):false,now=Date.now();
        if(now-origin>capMs){resolve(false);return;}
        if(!present){if(sinceGone===null)sinceGone=now;if(now-sinceGone>=absentMs){resolve(true);return;}}else{sinceGone=null;}
        setTimeout(poll,40);
      }
      poll();
    });
  }
  function waitStableAppear(root,sel,timeout,holdMs){
    return new Promise(function(resolve){
      var origin=Date.now(),seenSince=null;
      function poll(){
        var present=root?!!qsf(root,sel):false,now=Date.now();
        if(now-origin>timeout){resolve(false);return;}
        if(present){if(seenSince===null)seenSince=now;if(now-seenSince>=holdMs){resolve(true);return;}}else{seenSince=null;}
        setTimeout(poll,40);
      }
      poll();
    });
  }
  function findStickyMsg(root){
    if(!root)return null;
    var popup=qsf(root,SEL_POPUP);
    if(popup){var bbl=popup.closest('[data-message-role="human"]');if(bbl)return bbl;}
    var all=qsa(root,SEL_STICKY);
    return all.length?all[all.length-1]:null;
  }
  async function resendFromBubble(root,id,att){
    var bbl=findStickyMsg(root);
    if(!bbl){log(id,"#"+att+" bubble not found");return false;}
    var msgEl=bbl.querySelector(".composer-human-message");
    (msgEl||bbl).click();
    log(id,"#"+att+" activating bubble");
    var ed=null;
    for(var i=0;i<15;i++){await delay(200);ed=bbl.querySelector(SEL_EDITOR);if(ed)break;}
    if(!ed){log(id,"#"+att+" editor not ready");return false;}
    var btn=null;
    for(var j=0;j<10;j++){await delay(200);btn=bbl.querySelector(SEL_SEND);if(btn)break;}
    if(btn){btn.click();log(id,"#"+att+" clicked send");return true;}
    ed.focus();
    ed.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:true,cancelable:true}));
    log(id,"#"+att+" simulated Enter");
    return true;
  }
  function alive(id,gen){var s=inst[id];return s&&s.generation===gen&&s.running;}
  async function retryLoop(id,gen){
    var s=inst[id];if(!s)return;
    var root=rootById(id);
    if(!root){log(id,"composer root gone, abort");halt(id);return;}
    s.attempts=1;refreshUI(id);
    log(id,"#1 initial send");
    triggerBottomSend(root);
    log(id,"waiting for billing popup...");
    var appeared=await monitorEl(root,SEL_POPUP,true,10000);
    if(!alive(id,gen)){log(id,"aborted");return;}
    s=inst[id];
    if(!appeared){log(id,"no popup in 10s, possibly OK");halt(id);return;}
    while(alive(id,gen)&&s.attempts<LIMIT){
      root=rootById(id);
      if(!root){log(id,"root vanished");halt(id);return;}
      s.attempts++;refreshUI(id);
      await delay(200);
      if(!alive(id,gen))return;
      var ok=await resendFromBubble(root,id,s.attempts);
      if(!alive(id,gen))return;
      if(!ok){log(id,"send failed, stopping");halt(id);return;}
      log(id,"#"+s.attempts+" waiting popup gone");
      var vanished=await monitorEl(root,SEL_POPUP,false,8000);
      if(!alive(id,gen))return;
      if(!vanished)vanished=await monitorEl(root,SEL_POPUP,false,20000);
      if(!alive(id,gen))return;
      if(!vanished){log(id,"popup stuck, stopping");halt(id);return;}
      var stable=await waitSettled(root,SEL_POPUP,GONE_MS,GONE_CAP);
      if(!alive(id,gen))return;
      if(!stable){log(id,"popup flickering, stopping");halt(id);return;}
      log(id,"#"+s.attempts+" waiting popup reappear");
      var back=await waitStableAppear(root,SEL_POPUP,10000,APPEAR_MS);
      if(!alive(id,gen))return;
      if(!back){log(id,"popup gone, success!");halt(id);return;}
    }
    if(s&&s.attempts>=LIMIT)log(id,"reached limit "+LIMIT);
    halt(id);
  }
  function engage(id){
    var s=inst[id];if(!s)return;
    if(s.running){halt(id);return;}
    s.running=true;s.attempts=0;s.generation=(s.generation|0)+1;
    var gen=s.generation;
    refreshUI(id);log(id,"started");
    retryLoop(id,gen);
  }
  function halt(id){
    var s=inst[id];if(!s)return;
    if(s.running){s.running=false;s.generation=(s.generation|0)+1;log(id,"stopped, total "+s.attempts);}
    s.attempts=0;refreshUI(id);
  }
  function mountBtn(id){
    var root=rootById(id);if(!root)return;
    if(!inst[id])inst[id]={running:false,attempts:0,generation:0,btnEl:null};
    var s=inst[id];
    if(s.btnEl&&s.btnEl.isConnected&&root.contains(s.btnEl))return;
    var toolbar=locateToolbar(root);if(!toolbar)return;
    var wrap=document.createElement("div");
    wrap.title="自动重试（点击开始/停止）";
    var cs=wrap.style;
    cs.marginLeft="2px";cs.width="24px";cs.height="24px";cs.display="flex";
    cs.alignItems="center";cs.justifyContent="center";cs.borderRadius="50%";
    cs.cursor="pointer";cs.flexShrink="0";cs.userSelect="none";cs.position="relative";
    wrap.appendChild(buildIcon());
    wrap.onclick=function(){engage(id);};
    var modeWrap=toolbar.querySelector(".send-with-mode");
    if(modeWrap)toolbar.insertBefore(wrap,modeWrap);else toolbar.appendChild(wrap);
    s.btnEl=wrap;refreshUI(id);log(id,"button mounted");
  }
  function refreshUI(id){
    var s=inst[id];if(!s)return;
    var el=s.btnEl;if(!el||!el.isConnected)return;
    var icon=el.querySelector("svg");
    var chip=el.querySelector(".__wz_retry_badge");
    if(s.running){
      if(icon)icon.style.animation="wanzi-retry-rotate 1s linear infinite";
      if(!chip){
        chip=document.createElement("span");chip.className="__wz_retry_badge";
        var c=chip.style;
        c.position="absolute";c.top="-3px";c.right="-4px";c.minWidth="12px";
        c.height="12px";c.lineHeight="12px";c.borderRadius="6px";c.background="#c0392b";
        c.color="#fff";c.fontSize="8px";c.fontWeight="700";c.textAlign="center";
        c.padding="0 2px";c.pointerEvents="none";
        el.appendChild(chip);
      }
      chip.textContent=String(s.attempts);
      chip.style.display="";
      el.title="Stop ("+s.attempts+"/"+LIMIT+")";
    }else{
      if(icon)icon.style.animation="";
      if(chip)chip.style.display="none";
      el.title="自动重试（点击开始/停止）";
    }
  }
  function scan(){
    var roots=document.querySelectorAll(SEL_ROOT);
    var live=Object.create(null);
    for(var i=0;i<roots.length;i++){var rid=roots[i].getAttribute("data-composer-id");if(rid){live[rid]=true;mountBtn(rid);}}
    Object.keys(inst).forEach(function(id){
      if(!live[id]){halt(id);var s=inst[id];if(s&&s.btnEl&&s.btnEl.parentNode)s.btnEl.parentNode.removeChild(s.btnEl);delete inst[id];}
    });
  }
  scan();
  var domWatch=new MutationObserver(function(){scan();});
  domWatch.observe(document.body,{childList:true,subtree:true});
  window.__wanziRetryTeardown=function(){
    Object.keys(inst).forEach(function(id){halt(id);var s=inst[id];if(s&&s.btnEl&&s.btnEl.parentNode)s.btnEl.parentNode.removeChild(s.btnEl);delete inst[id];});
    if(domWatch){domWatch.disconnect();domWatch=null;}
  };
  log("*","ready (multi-composer)");
})();}catch(_wzErr){console.error("[Wanzi-Retry] patch error:",_wzErr);}"""


# ── Locate Cursor installation ───────────────────────────────────

def _find_cursor_from_process() -> Path | None:
    """Try to find Cursor install dir from running process."""
    try:
        import subprocess
        if platform.system() == "Windows":
            result = subprocess.run(
                ["powershell", "-Command",
                 "(Get-Process Cursor -ErrorAction SilentlyContinue | Select-Object -First 1).Path"],
                capture_output=True, text=True, timeout=10,
            )
            exe = result.stdout.strip()
            if exe and Path(exe).exists():
                return Path(exe).parent
        else:
            result = subprocess.run(
                ["pgrep", "-a", "-f", "Cursor"],
                capture_output=True, text=True, timeout=5,
            )
            for line in result.stdout.strip().splitlines():
                parts = line.split(None, 1)
                if len(parts) > 1 and "cursor" in parts[1].lower():
                    p = Path(parts[1].split()[0])
                    if p.exists():
                        return p.parent
    except Exception:
        pass
    return None


def _find_workbench_bundle() -> Path | None:
    """Find workbench.desktop.main.js across platforms."""
    system = platform.system()
    candidates: list[Path] = []

    if system == "Windows":
        local = os.environ.get("LOCALAPPDATA", "")
        if local:
            candidates.append(
                Path(local) / "Programs" / "Cursor" / "resources" / "app"
                / "out" / "vs" / "workbench" / "workbench.desktop.main.js"
            )
        program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
        candidates.append(
            Path(program_files) / "Cursor" / "resources" / "app"
            / "out" / "vs" / "workbench" / "workbench.desktop.main.js"
        )
        proc_dir = _find_cursor_from_process()
        if proc_dir:
            candidates.insert(0,
                proc_dir / "resources" / "app"
                / "out" / "vs" / "workbench" / "workbench.desktop.main.js"
            )
    elif system == "Darwin":
        candidates.append(
            Path("/Applications/Cursor.app/Contents/Resources/app"
                 "/out/vs/workbench/workbench.desktop.main.js")
        )
    else:
        home = Path.home()
        candidates.extend([
            Path("/opt/cursor/resources/app/out/vs/workbench/workbench.desktop.main.js"),
            home / ".local" / "share" / "cursor" / "resources" / "app"
            / "out" / "vs" / "workbench" / "workbench.desktop.main.js",
            Path("/usr/share/cursor/resources/app/out/vs/workbench/workbench.desktop.main.js"),
        ])

    for c in candidates:
        if c.exists():
            return c
    return None


def _backup_bundle(bundle_path: Path) -> Path:
    """Create a timestamped backup before modifying."""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = bundle_path.with_suffix(f".wanzi-backup-{ts}.js")
    shutil.copy2(bundle_path, backup)
    return backup


def _update_product_checksum(bundle_path: Path):
    """Update product.json checksum after modifying the bundle."""
    product_candidates = [
        bundle_path.parent.parent.parent.parent / "product.json",
        bundle_path.parent.parent.parent.parent.parent / "product.json",
    ]
    for product_path in product_candidates:
        if not product_path.exists():
            continue
        try:
            import json
            product = json.loads(product_path.read_text("utf-8"))
            checksums = product.get("checksums")
            if not isinstance(checksums, dict):
                continue
            rel_key = "vs/workbench/workbench.desktop.main.js"
            if rel_key in checksums:
                content = bundle_path.read_bytes()
                import base64
                new_hash = base64.b64encode(
                    hashlib.md5(content).digest()
                ).decode().rstrip("=")
                checksums[rel_key] = new_hash
                product_path.write_text(
                    json.dumps(product, indent="\t", ensure_ascii=False),
                    encoding="utf-8",
                )
        except Exception:
            pass


# ── Public API ───────────────────────────────────────────────────

def get_inject_status() -> dict:
    """Check which patches are currently injected."""
    bundle = _find_workbench_bundle()
    if not bundle:
        return {
            "found": False,
            "path": None,
            "update_blocked": False,
            "telemetry_blocked": False,
            "retry_injected": False,
        }

    content = bundle.read_text("utf-8")
    return {
        "found": True,
        "path": str(bundle),
        "update_blocked": _UPDATE_START in content,
        "telemetry_blocked": _TELE_START in content,
        "retry_injected": _RETRY_START in content,
    }


def _disable_sub_agents():
    """Write cursor.agent.enableSubAgents=false to Cursor settings.json."""
    try:
        from .installer import _cursor_settings_path
        import json
        sp = _cursor_settings_path()
        if not sp.parent.exists():
            return
        settings: dict = {}
        if sp.exists():
            try:
                settings = json.loads(sp.read_text("utf-8"))
            except Exception:
                pass
        if settings.get("cursor.agent.enableSubAgents") is not False:
            settings["cursor.agent.enableSubAgents"] = False
            sp.write_text(json.dumps(settings, indent=4, ensure_ascii=False), "utf-8")
    except Exception:
        pass


def inject_all() -> dict:
    """Inject all three patches into workbench.desktop.main.js."""
    bundle = _find_workbench_bundle()
    if not bundle:
        return {"ok": False, "error": "未找到 Cursor workbench.desktop.main.js"}

    try:
        bundle.stat()
    except PermissionError:
        return {
            "ok": False,
            "error": "权限不足，请以管理员身份运行",
        }

    try:
        content = bundle.read_text("utf-8")
    except Exception as e:
        return {"ok": False, "error": f"读取 bundle 失败: {e}"}

    backup_path = _backup_bundle(bundle)

    injected = []

    if _UPDATE_START not in content:
        content = content.rstrip() + "\n" + _UPDATE_START + BLOCK_UPDATE_SCRIPT + _UPDATE_END + "\n"
        injected.append("禁止更新")

    if _TELE_START not in content:
        content = content.rstrip() + "\n" + _TELE_START + BLOCK_TELEMETRY_SCRIPT + _TELE_END + "\n"
        injected.append("禁用上报")

    if _RETRY_START not in content:
        content = content.rstrip() + "\n" + _RETRY_START + AUTO_RETRY_SCRIPT + _RETRY_END + "\n"
        injected.append("自动重试")

    if not injected:
        return {
            "ok": True,
            "message": "所有补丁已存在，无需重复注入",
            "injected": [],
            "backup": str(backup_path),
        }

    try:
        bundle.write_text(content, "utf-8")
    except PermissionError:
        return {
            "ok": False,
            "error": "写入失败，权限不足。请关闭 Cursor 后以管理员身份运行",
        }
    except Exception as e:
        return {"ok": False, "error": f"写入失败: {e}"}

    _update_product_checksum(bundle)
    _disable_sub_agents()

    return {
        "ok": True,
        "message": f"已注入: {', '.join(injected)}，已禁用子代理。请重启 Cursor 生效",
        "injected": injected,
        "backup": str(backup_path),
    }


def remove_all() -> dict:
    """Remove all injected patches."""
    bundle = _find_workbench_bundle()
    if not bundle:
        return {"ok": False, "error": "未找到 Cursor workbench.desktop.main.js"}

    try:
        content = bundle.read_text("utf-8")
    except Exception as e:
        return {"ok": False, "error": f"读取失败: {e}"}

    removed = []
    for start, end in _ALL_MARKERS:
        pattern = re.escape(start) + r"[\s\S]*?" + re.escape(end) + r"\n?"
        if re.search(pattern, content):
            content = re.sub(pattern, "", content)
            removed.append(start.split("_")[1].lower())

    if not removed:
        return {"ok": True, "message": "未检测到任何补丁", "removed": []}

    try:
        bundle.write_text(content, "utf-8")
    except Exception as e:
        return {"ok": False, "error": f"写入失败: {e}"}

    _update_product_checksum(bundle)

    return {
        "ok": True,
        "message": f"已移除 {len(removed)} 个补丁，请重启 Cursor 生效",
        "removed": removed,
    }
