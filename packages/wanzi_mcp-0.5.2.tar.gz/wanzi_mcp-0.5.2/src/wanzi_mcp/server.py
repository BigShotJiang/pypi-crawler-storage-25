from __future__ import annotations

import base64
import json
import tempfile
import uuid as _uuid
from pathlib import Path

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route, WebSocketRoute
from starlette.staticfiles import StaticFiles
from starlette.websockets import WebSocket, WebSocketDisconnect


from .session import SessionManager

manager = SessionManager()

_UPLOAD_DIR = Path(tempfile.gettempdir()) / "wanzi-mcp-uploads"
_UPLOAD_DIR.mkdir(exist_ok=True)

_MIME_MAP = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".bmp": "image/bmp",
}

_KEEPALIVE_SENTINEL = object()


async def _wait_with_keepalive(sid: str):
    """Wait for user message. Returns Message, _KEEPALIVE_SENTINEL on timeout, None if session closed."""
    if sid not in manager._sessions:
        return None
    msg = await manager.wait_for_message(sid)
    if msg is SessionManager._SENTINEL:
        return None
    if msg is not None:
        return msg
    if sid not in manager._sessions:
        return None
    return _KEEPALIVE_SENTINEL


async def _ensure_session(sid: str):
    """首次调用时才创建会话并通知 GUI。"""
    is_new = sid not in manager._sessions
    session = manager.get_or_create(sid)
    if is_new:
        await manager.broadcast(
            {"type": "session_created", "session": session.to_summary()}
        )
        connect_msg = manager.add_assistant_message(sid, "🔗 Cursor 会话已连接")
        await manager.broadcast(
            {
                "type": "assistant_message",
                "session_id": sid,
                "message": connect_msg.to_dict(),
            }
        )
    return session


# ── WebSocket endpoint ─────────────────────────
async def handle_ws(ws: WebSocket):
    await ws.accept()
    manager.register_ws(ws)
    try:
        while True:
            data = await ws.receive_json()
            action = data.get("type")

            if action == "send_message":
                sid = data["session_id"]
                content = data.get("content", "")
                images = data.get("images", [])
                msg = await manager.push_user_message(sid, content, images)
                await manager.broadcast(
                    {
                        "type": "user_message",
                        "session_id": sid,
                        "message": msg.to_dict(),
                    }
                )

            elif action == "list_sessions":
                await ws.send_json(
                    {
                        "type": "session_list",
                        "sessions": [
                            s.to_summary() for s in manager.list_sessions()
                        ],
                    }
                )

            elif action == "get_session":
                sid = data["session_id"]
                session = manager.get_or_create(sid)
                await ws.send_json(
                    {"type": "session_detail", "session": session.to_dict()}
                )

            elif action == "create_session":
                sid = data.get("session_id") or _uuid.uuid4().hex[:8]
                title = data.get("title", "新会话")
                session = manager.get_or_create(sid)
                session.title = title
                await manager.broadcast(
                    {"type": "session_created", "session": session.to_summary()}
                )

            elif action == "rename_session":
                manager.rename_session(data["session_id"], data["title"])
                await manager.broadcast(
                    {
                        "type": "session_renamed",
                        "session_id": data["session_id"],
                        "title": data["title"],
                    }
                )

            elif action == "delete_session":
                manager.delete_session(data["session_id"])
                await manager.broadcast(
                    {"type": "session_deleted", "session_id": data["session_id"]}
                )

            elif action == "delete_message":
                sid = data["session_id"]
                mid = data["message_id"]
                if manager.delete_message(sid, mid):
                    await manager.broadcast(
                        {
                            "type": "message_deleted",
                            "session_id": sid,
                            "message_id": mid,
                        }
                    )
    except WebSocketDisconnect:
        pass
    finally:
        manager.unregister_ws(ws)


# ── 图片上传 ────────────────────────────────────
def _read_upload_as_base64(img_url: str) -> dict | None:
    filename = img_url.split("/")[-1]
    path = _UPLOAD_DIR / filename
    if not path.exists():
        return None
    suffix = path.suffix.lower()
    mime = _MIME_MAP.get(suffix, "image/png")
    return {"data": base64.b64encode(path.read_bytes()).decode(), "mime": mime}


async def handle_upload(request: Request):
    form = await request.form()
    file = form.get("file")
    if file is None:
        return JSONResponse({"ok": False, "message": "no file"}, status_code=400)

    ext = Path(file.filename).suffix.lower() if file.filename else ".png"
    if ext not in _MIME_MAP:
        return JSONResponse({"ok": False, "message": "不支持的图片格式"}, status_code=400)

    name = _uuid.uuid4().hex[:12] + ext
    dest = _UPLOAD_DIR / name
    dest.write_bytes(await file.read())

    url = f"/uploads/{name}"
    return JSONResponse({"ok": True, "url": url})


# ── MCP HTTP API (for stdio proxy) ──────────────
async def _wait_or_disconnect(request: Request, sid: str):
    """Wait for user message, but detect HTTP client disconnect every 2s."""
    import asyncio
    if sid not in manager._sessions:
        return None
    q = manager._queues.get(sid)
    if q is None:
        return None

    deadline = asyncio.get_event_loop().time() + SessionManager.KEEPALIVE_TIMEOUT
    while True:
        remaining = deadline - asyncio.get_event_loop().time()
        if remaining <= 0:
            return _KEEPALIVE_SENTINEL

        try:
            msg = await asyncio.wait_for(q.get(), timeout=min(2.0, remaining))
        except asyncio.TimeoutError:
            if await request.is_disconnected():
                await manager.broadcast({"type": "session_disconnected", "session_id": sid})
                return None
            if sid not in manager._sessions:
                return None
            continue

        if msg is SessionManager._SENTINEL:
            return None
        return msg


async def handle_mcp_check(request: Request):
    """stdio 代理调用：发送 reply + 等待下一条用户消息。"""
    body = await request.json()
    sid = body.get("session_id") or _uuid.uuid4().hex[:8]
    reply = body.get("reply")

    await _ensure_session(sid)

    if reply:
        msg = manager.add_assistant_message(sid, reply)
        await manager.broadcast(
            {"type": "assistant_message", "session_id": sid, "message": msg.to_dict()}
        )

    await manager.broadcast({"type": "session_waiting", "session_id": sid})
    user_msg = await _wait_or_disconnect(request, sid)

    if user_msg is None:
        return JSONResponse({"session_id": sid, "signal": "closed"})
    if user_msg is _KEEPALIVE_SENTINEL:
        return JSONResponse({"session_id": sid, "signal": "keepalive"})

    images_b64 = []
    for img_url in (user_msg.images or []):
        img_data = _read_upload_as_base64(img_url)
        if img_data:
            images_b64.append(img_data)

    result = {"session_id": sid, "content": user_msg.content or "", "images": images_b64}
    return JSONResponse(result)


async def handle_mcp_send(request: Request):
    """stdio 代理调用：单向推送消息。"""
    body = await request.json()
    sid = body.get("session_id") or _uuid.uuid4().hex[:8]
    content = body["content"]

    await _ensure_session(sid)
    msg = manager.add_assistant_message(sid, content)
    await manager.broadcast(
        {"type": "assistant_message", "session_id": sid, "message": msg.to_dict()}
    )
    return JSONResponse({"session_id": sid, "sent": True})


async def handle_mcp_ask(request: Request):
    """stdio 代理调用：发问题 + 等回答。"""
    body = await request.json()
    sid = body.get("session_id") or _uuid.uuid4().hex[:8]
    question = body["question"]

    await _ensure_session(sid)
    msg = manager.add_assistant_message(sid, question)
    await manager.broadcast(
        {"type": "assistant_message", "session_id": sid, "message": msg.to_dict()}
    )

    await manager.broadcast({"type": "session_waiting", "session_id": sid})
    answer = await _wait_or_disconnect(request, sid)

    if answer is None:
        return JSONResponse({"session_id": sid, "signal": "closed"})
    if answer is _KEEPALIVE_SENTINEL:
        return JSONResponse({"session_id": sid, "signal": "keepalive"})

    images_b64 = []
    for img_url in (answer.images or []):
        img_data = _read_upload_as_base64(img_url)
        if img_data:
            images_b64.append(img_data)

    result = {"session_id": sid, "content": answer.content or "", "images": images_b64}
    return JSONResponse(result)


# ── REST: 服务状态 ──────────────────────────────
async def handle_status(request: Request):
    return JSONResponse({
        "ok": True,
        "mcp_api": True,
        "ws_connections": len(manager._ws_clients),
        "sessions": len(manager._sessions),
    })


# ── REST: 安装到 Cursor ─────────────────────────
async def handle_install(request: Request):
    from .installer import install_to_cursor

    port = request.query_params.get("port", "8765")
    try:
        install_to_cursor(int(port))
        return JSONResponse({"ok": True, "message": "已写入 mcp.json 并配置 MCP 超时"})
    except Exception as e:
        return JSONResponse({"ok": False, "message": str(e)}, status_code=500)


# ── REST: 打开 Cursor ────────────────────────────
async def handle_open_cursor(request: Request):
    from .installer import open_cursor

    result = open_cursor()
    status = 200 if result["ok"] else 500
    return JSONResponse(result, status_code=status)


# ── REST: Cursor 一键注入 ────────────────────────
async def handle_inject_cursor(request: Request):
    from .cursor_inject import inject_all

    try:
        result = inject_all()
        status = 200 if result["ok"] else 500
        return JSONResponse(result, status_code=status)
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)


async def handle_inject_status(request: Request):
    from .cursor_inject import get_inject_status

    try:
        return JSONResponse(get_inject_status())
    except Exception as e:
        return JSONResponse({"found": False, "error": str(e)}, status_code=500)


async def handle_inject_remove(request: Request):
    from .cursor_inject import remove_all

    try:
        result = remove_all()
        status = 200 if result["ok"] else 500
        return JSONResponse(result, status_code=status)
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)


# ── Build ASGI app ──────────────────────────────
_STATIC_DIR = Path(__file__).parent / "gui" / "static"


def create_app() -> Starlette:
    return Starlette(
        routes=[
            Route("/api/mcp/check", handle_mcp_check, methods=["POST"]),
            Route("/api/mcp/send", handle_mcp_send, methods=["POST"]),
            Route("/api/mcp/ask", handle_mcp_ask, methods=["POST"]),
            Route("/api/status", handle_status),
            Route("/api/install", handle_install, methods=["POST"]),
            Route("/api/open-cursor", handle_open_cursor, methods=["POST"]),
            Route("/api/inject-cursor", handle_inject_cursor, methods=["POST"]),
            Route("/api/inject-status", handle_inject_status),
            Route("/api/inject-remove", handle_inject_remove, methods=["POST"]),
            Route("/api/upload", handle_upload, methods=["POST"]),
            Mount("/uploads", app=StaticFiles(directory=str(_UPLOAD_DIR))),
            WebSocketRoute("/ws", handle_ws),
            Mount(
                "/",
                app=StaticFiles(directory=str(_STATIC_DIR), html=True),
            ),
        ],
    )


app = create_app()
