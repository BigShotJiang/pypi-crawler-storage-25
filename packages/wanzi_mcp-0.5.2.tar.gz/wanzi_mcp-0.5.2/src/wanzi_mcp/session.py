from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from .models import Message, MessageRole, Session

logger = logging.getLogger(__name__)

_DEFAULT_STORE_DIR = Path.home() / ".wanzi-mcp" / "sessions"


class SessionManager:
    """会话管理器，支持文件持久化。"""

    def __init__(self, store_dir: Path | None = None):
        self._store_dir = store_dir or _DEFAULT_STORE_DIR
        self._store_dir.mkdir(parents=True, exist_ok=True)
        self._sessions: dict[str, Session] = {}
        self._queues: dict[str, asyncio.Queue[Message]] = {}
        self._ws_clients: set[Any] = set()
        self._load_all()

    # ── 持久化 ─────────────────────────────────

    def _session_path(self, session_id: str) -> Path:
        return self._store_dir / f"{session_id}.json"

    def _save(self, session_id: str):
        session = self._sessions.get(session_id)
        if not session:
            return
        try:
            self._session_path(session_id).write_text(
                json.dumps(session.to_dict(), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception as e:
            logger.warning("save session %s failed: %s", session_id, e)

    def _delete_file(self, session_id: str):
        try:
            self._session_path(session_id).unlink(missing_ok=True)
        except Exception as e:
            logger.warning("delete session file %s failed: %s", session_id, e)

    def _load_all(self):
        for path in self._store_dir.glob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                session = Session(
                    id=data["id"],
                    title=data.get("title", "新会话"),
                    messages=[
                        Message(
                            role=MessageRole(m["role"]),
                            content=m["content"],
                            images=m.get("images", []),
                            id=m["id"],
                            timestamp=m.get("timestamp", ""),
                        )
                        for m in data.get("messages", [])
                    ],
                    created_at=data.get("created_at", datetime.now().isoformat()),
                    updated_at=data.get("updated_at", datetime.now().isoformat()),
                )
                self._sessions[session.id] = session
                self._queues[session.id] = asyncio.Queue()
            except Exception as e:
                logger.warning("load session %s failed: %s", path.name, e)

    # ── 会话 CRUD ──────────────────────────────

    def get_or_create(self, session_id: str) -> Session:
        if session_id not in self._sessions:
            self._sessions[session_id] = Session(id=session_id)
            self._queues[session_id] = asyncio.Queue()
            self._save(session_id)
        return self._sessions[session_id]

    def list_sessions(self) -> list[Session]:
        return sorted(
            self._sessions.values(),
            key=lambda s: s.updated_at,
            reverse=True,
        )

    def rename_session(self, session_id: str, title: str):
        if session_id in self._sessions:
            self._sessions[session_id].title = title
            self._save(session_id)

    _SENTINEL = object()

    def delete_session(self, session_id: str):
        self._sessions.pop(session_id, None)
        q = self._queues.pop(session_id, None)
        if q is not None:
            q.put_nowait(self._SENTINEL)
        self._delete_file(session_id)

    def delete_message(self, session_id: str, message_id: str) -> bool:
        session = self._sessions.get(session_id)
        if not session:
            return False
        before = len(session.messages)
        session.messages = [m for m in session.messages if m.id != message_id]
        if len(session.messages) < before:
            session.updated_at = datetime.now().isoformat()
            self._save(session_id)
            return True
        return False

    # ── 消息 ───────────────────────────────────

    MAX_HISTORY = 200

    async def push_user_message(
        self, session_id: str, content: str, images: list[str] | None = None
    ) -> Message:
        session = self.get_or_create(session_id)
        msg = Message(role=MessageRole.USER, content=content, images=images or [])
        session.messages.append(msg)
        self._trim(session)
        session.updated_at = datetime.now().isoformat()
        self._save(session_id)
        await self._queues[session_id].put(msg)
        return msg

    def add_assistant_message(self, session_id: str, content: str) -> Message:
        session = self.get_or_create(session_id)
        msg = Message(role=MessageRole.ASSISTANT, content=content)
        session.messages.append(msg)
        self._trim(session)
        session.updated_at = datetime.now().isoformat()
        self._save(session_id)
        return msg

    @staticmethod
    def _trim(session: Session):
        if len(session.messages) > SessionManager.MAX_HISTORY:
            session.messages = session.messages[-SessionManager.MAX_HISTORY:]

    KEEPALIVE_TIMEOUT = 480  # 8 minutes

    async def wait_for_message(
        self, session_id: str, timeout: float | None = None
    ) -> Optional[Message]:
        self.get_or_create(session_id)
        effective_timeout = timeout if timeout is not None else self.KEEPALIVE_TIMEOUT
        try:
            return await asyncio.wait_for(
                self._queues[session_id].get(), timeout=effective_timeout
            )
        except asyncio.TimeoutError:
            return None

    # ── WebSocket 管理 ─────────────────────────

    def register_ws(self, ws: Any):
        self._ws_clients.add(ws)

    def unregister_ws(self, ws: Any):
        self._ws_clients.discard(ws)

    async def broadcast(self, data: dict):
        dead: list[Any] = []
        for ws in self._ws_clients:
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self._ws_clients.discard(ws)
