"""pywebview GUI 窗口：包裹本地 Web 页面。"""

from __future__ import annotations

import webview


class _JsApi:
    """暴露给前端的 Python 方法。"""

    def flash_taskbar(self):
        from .taskbar import flash
        flash()

    def open_url(self, url):
        import webbrowser
        webbrowser.open(url)


def start_gui(port: int = 8765):
    url = f"http://localhost:{port}/"
    api = _JsApi()
    window = webview.create_window(
        "丸子 MCP",
        url,
        width=920,
        height=660,
        min_size=(640, 400),
        text_select=True,
        js_api=api,
        maximized=True,
    )

    def _on_started(main_window):
        main_window.events.shown.wait(10)
        from .taskbar import start_hotkey_listener
        start_hotkey_listener()

    webview.start(func=_on_started, args=(window,))
