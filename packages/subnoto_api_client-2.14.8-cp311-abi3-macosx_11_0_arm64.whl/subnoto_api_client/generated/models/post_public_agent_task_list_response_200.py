from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_agent_task_list_response_200_pagination import PostPublicAgentTaskListResponse200Pagination
  from ..models.post_public_agent_task_list_response_200_tasks_item import PostPublicAgentTaskListResponse200TasksItem





T = TypeVar("T", bound="PostPublicAgentTaskListResponse200")



@_attrs_define
class PostPublicAgentTaskListResponse200:
    """ 
        Attributes:
            tasks (list[PostPublicAgentTaskListResponse200TasksItem]):
            pagination (PostPublicAgentTaskListResponse200Pagination):
     """

    tasks: list[PostPublicAgentTaskListResponse200TasksItem]
    pagination: PostPublicAgentTaskListResponse200Pagination





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_agent_task_list_response_200_pagination import PostPublicAgentTaskListResponse200Pagination
        from ..models.post_public_agent_task_list_response_200_tasks_item import PostPublicAgentTaskListResponse200TasksItem
        tasks = []
        for tasks_item_data in self.tasks:
            tasks_item = tasks_item_data.to_dict()
            tasks.append(tasks_item)



        pagination = self.pagination.to_dict()


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "tasks": tasks,
            "pagination": pagination,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_agent_task_list_response_200_pagination import PostPublicAgentTaskListResponse200Pagination
        from ..models.post_public_agent_task_list_response_200_tasks_item import PostPublicAgentTaskListResponse200TasksItem
        d = dict(src_dict)
        tasks = []
        _tasks = d.pop("tasks")
        for tasks_item_data in (_tasks):
            tasks_item = PostPublicAgentTaskListResponse200TasksItem.from_dict(tasks_item_data)



            tasks.append(tasks_item)


        pagination = PostPublicAgentTaskListResponse200Pagination.from_dict(d.pop("pagination"))




        post_public_agent_task_list_response_200 = cls(
            tasks=tasks,
            pagination=pagination,
        )

        return post_public_agent_task_list_response_200

