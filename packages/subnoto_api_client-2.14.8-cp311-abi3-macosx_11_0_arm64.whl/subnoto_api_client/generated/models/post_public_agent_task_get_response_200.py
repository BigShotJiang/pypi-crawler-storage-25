from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_agent_task_get_response_200_reports_item import PostPublicAgentTaskGetResponse200ReportsItem





T = TypeVar("T", bound="PostPublicAgentTaskGetResponse200")



@_attrs_define
class PostPublicAgentTaskGetResponse200:
    """ 
        Attributes:
            reports (list[PostPublicAgentTaskGetResponse200ReportsItem]):
     """

    reports: list[PostPublicAgentTaskGetResponse200ReportsItem]





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_agent_task_get_response_200_reports_item import PostPublicAgentTaskGetResponse200ReportsItem
        reports = []
        for reports_item_data in self.reports:
            reports_item = reports_item_data.to_dict()
            reports.append(reports_item)




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "reports": reports,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_agent_task_get_response_200_reports_item import PostPublicAgentTaskGetResponse200ReportsItem
        d = dict(src_dict)
        reports = []
        _reports = d.pop("reports")
        for reports_item_data in (_reports):
            reports_item = PostPublicAgentTaskGetResponse200ReportsItem.from_dict(reports_item_data)



            reports.append(reports_item)


        post_public_agent_task_get_response_200 = cls(
            reports=reports,
        )

        return post_public_agent_task_get_response_200

