from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="PostPublicAgentTaskGetResponse200ReportsItemAuthor")



@_attrs_define
class PostPublicAgentTaskGetResponse200ReportsItemAuthor:
    """ 
        Attributes:
            uuid (str): Author public UUID (nil UUID for System).
            email (str): Author email address.
            name (str): Author display name.
     """

    uuid: str
    email: str
    name: str





    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        email = self.email

        name = self.name


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "uuid": uuid,
            "email": email,
            "name": name,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid")

        email = d.pop("email")

        name = d.pop("name")

        post_public_agent_task_get_response_200_reports_item_author = cls(
            uuid=uuid,
            email=email,
            name=name,
        )

        return post_public_agent_task_get_response_200_reports_item_author

