from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_agent_task_list_response_200_tasks_item_latest_report import PostPublicAgentTaskListResponse200TasksItemLatestReport





T = TypeVar("T", bound="PostPublicAgentTaskListResponse200TasksItem")



@_attrs_define
class PostPublicAgentTaskListResponse200TasksItem:
    """ 
        Attributes:
            task_uuid (str): The task grouping UUID.
            report_count (int): Number of reports recorded for this task.
            latest_report (PostPublicAgentTaskListResponse200TasksItemLatestReport):
     """

    task_uuid: str
    report_count: int
    latest_report: PostPublicAgentTaskListResponse200TasksItemLatestReport





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_agent_task_list_response_200_tasks_item_latest_report import PostPublicAgentTaskListResponse200TasksItemLatestReport
        task_uuid = self.task_uuid

        report_count = self.report_count

        latest_report = self.latest_report.to_dict()


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "taskUuid": task_uuid,
            "reportCount": report_count,
            "latestReport": latest_report,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_agent_task_list_response_200_tasks_item_latest_report import PostPublicAgentTaskListResponse200TasksItemLatestReport
        d = dict(src_dict)
        task_uuid = d.pop("taskUuid")

        report_count = d.pop("reportCount")

        latest_report = PostPublicAgentTaskListResponse200TasksItemLatestReport.from_dict(d.pop("latestReport"))




        post_public_agent_task_list_response_200_tasks_item = cls(
            task_uuid=task_uuid,
            report_count=report_count,
            latest_report=latest_report,
        )

        return post_public_agent_task_list_response_200_tasks_item

