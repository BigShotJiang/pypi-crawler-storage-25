from enum import Enum

class PostPublicAgentTaskReportBodyState(str, Enum):
    COMPLETE = "complete"
    FAILURE = "failure"
    IDLE = "idle"
    WORKING = "working"

    def __str__(self) -> str:
        return str(self.value)
