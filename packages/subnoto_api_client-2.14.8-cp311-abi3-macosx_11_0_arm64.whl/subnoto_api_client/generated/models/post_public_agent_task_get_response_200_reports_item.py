from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_agent_task_get_response_200_reports_item_state import PostPublicAgentTaskGetResponse200ReportsItemState
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_agent_task_get_response_200_reports_item_author import PostPublicAgentTaskGetResponse200ReportsItemAuthor





T = TypeVar("T", bound="PostPublicAgentTaskGetResponse200ReportsItem")



@_attrs_define
class PostPublicAgentTaskGetResponse200ReportsItem:
    """ 
        Attributes:
            report_id (float): Unique numeric ID of the report row.
            state (PostPublicAgentTaskGetResponse200ReportsItemState): The reported state.
            summary (str): The report summary.
            timestamp (float): The report timestamp (unix ms).
            author (PostPublicAgentTaskGetResponse200ReportsItemAuthor):
            link (str | Unset): Optional resource link.
     """

    report_id: float
    state: PostPublicAgentTaskGetResponse200ReportsItemState
    summary: str
    timestamp: float
    author: PostPublicAgentTaskGetResponse200ReportsItemAuthor
    link: str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_agent_task_get_response_200_reports_item_author import PostPublicAgentTaskGetResponse200ReportsItemAuthor
        report_id = self.report_id

        state = self.state.value

        summary = self.summary

        timestamp = self.timestamp

        author = self.author.to_dict()

        link = self.link


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "reportId": report_id,
            "state": state,
            "summary": summary,
            "timestamp": timestamp,
            "author": author,
        })
        if link is not UNSET:
            field_dict["link"] = link

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_agent_task_get_response_200_reports_item_author import PostPublicAgentTaskGetResponse200ReportsItemAuthor
        d = dict(src_dict)
        report_id = d.pop("reportId")

        state = PostPublicAgentTaskGetResponse200ReportsItemState(d.pop("state"))




        summary = d.pop("summary")

        timestamp = d.pop("timestamp")

        author = PostPublicAgentTaskGetResponse200ReportsItemAuthor.from_dict(d.pop("author"))




        link = d.pop("link", UNSET)

        post_public_agent_task_get_response_200_reports_item = cls(
            report_id=report_id,
            state=state,
            summary=summary,
            timestamp=timestamp,
            author=author,
            link=link,
        )

        return post_public_agent_task_get_response_200_reports_item

