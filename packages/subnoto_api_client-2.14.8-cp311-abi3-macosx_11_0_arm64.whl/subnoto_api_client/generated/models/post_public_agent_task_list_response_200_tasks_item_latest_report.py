from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_agent_task_list_response_200_tasks_item_latest_report_state import PostPublicAgentTaskListResponse200TasksItemLatestReportState
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_agent_task_list_response_200_tasks_item_latest_report_author import PostPublicAgentTaskListResponse200TasksItemLatestReportAuthor





T = TypeVar("T", bound="PostPublicAgentTaskListResponse200TasksItemLatestReport")



@_attrs_define
class PostPublicAgentTaskListResponse200TasksItemLatestReport:
    """ 
        Attributes:
            state (PostPublicAgentTaskListResponse200TasksItemLatestReportState): The latest reported state.
            summary (str): The latest reported summary.
            timestamp (float): The timestamp of the latest report (unix ms).
            author (PostPublicAgentTaskListResponse200TasksItemLatestReportAuthor):
            link (str | Unset): Optional resource link from the latest report.
     """

    state: PostPublicAgentTaskListResponse200TasksItemLatestReportState
    summary: str
    timestamp: float
    author: PostPublicAgentTaskListResponse200TasksItemLatestReportAuthor
    link: str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_agent_task_list_response_200_tasks_item_latest_report_author import PostPublicAgentTaskListResponse200TasksItemLatestReportAuthor
        state = self.state.value

        summary = self.summary

        timestamp = self.timestamp

        author = self.author.to_dict()

        link = self.link


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "state": state,
            "summary": summary,
            "timestamp": timestamp,
            "author": author,
        })
        if link is not UNSET:
            field_dict["link"] = link

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_agent_task_list_response_200_tasks_item_latest_report_author import PostPublicAgentTaskListResponse200TasksItemLatestReportAuthor
        d = dict(src_dict)
        state = PostPublicAgentTaskListResponse200TasksItemLatestReportState(d.pop("state"))




        summary = d.pop("summary")

        timestamp = d.pop("timestamp")

        author = PostPublicAgentTaskListResponse200TasksItemLatestReportAuthor.from_dict(d.pop("author"))




        link = d.pop("link", UNSET)

        post_public_agent_task_list_response_200_tasks_item_latest_report = cls(
            state=state,
            summary=summary,
            timestamp=timestamp,
            author=author,
            link=link,
        )

        return post_public_agent_task_list_response_200_tasks_item_latest_report

