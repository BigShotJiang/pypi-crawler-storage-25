from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_agent_task_list_body_sort_order import PostPublicAgentTaskListBodySortOrder
from ..models.post_public_agent_task_list_body_state_filter_item import PostPublicAgentTaskListBodyStateFilterItem
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="PostPublicAgentTaskListBody")



@_attrs_define
class PostPublicAgentTaskListBody:
    """ 
        Attributes:
            state_filter (list[PostPublicAgentTaskListBodyStateFilterItem] | Unset): Filter tasks whose latest report is in
                one of the given states. Omit or empty to return all.
            page (int | Unset): The page number (1-indexed). Defaults to 1. Default: 1.
            limit (int | Unset): The number of tasks per page. Defaults to 50, maximum is 50. Default: 50.
            sort_order (PostPublicAgentTaskListBodySortOrder | Unset): Sort tasks by the latest report timestamp. Defaults
                to 'desc'. Default: PostPublicAgentTaskListBodySortOrder.DESC.
     """

    state_filter: list[PostPublicAgentTaskListBodyStateFilterItem] | Unset = UNSET
    page: int | Unset = 1
    limit: int | Unset = 50
    sort_order: PostPublicAgentTaskListBodySortOrder | Unset = PostPublicAgentTaskListBodySortOrder.DESC
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        state_filter: list[str] | Unset = UNSET
        if not isinstance(self.state_filter, Unset):
            state_filter = []
            for state_filter_item_data in self.state_filter:
                state_filter_item = state_filter_item_data.value
                state_filter.append(state_filter_item)



        page = self.page

        limit = self.limit

        sort_order: str | Unset = UNSET
        if not isinstance(self.sort_order, Unset):
            sort_order = self.sort_order.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if state_filter is not UNSET:
            field_dict["stateFilter"] = state_filter
        if page is not UNSET:
            field_dict["page"] = page
        if limit is not UNSET:
            field_dict["limit"] = limit
        if sort_order is not UNSET:
            field_dict["sortOrder"] = sort_order

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _state_filter = d.pop("stateFilter", UNSET)
        state_filter: list[PostPublicAgentTaskListBodyStateFilterItem] | Unset = UNSET
        if _state_filter is not UNSET:
            state_filter = []
            for state_filter_item_data in _state_filter:
                state_filter_item = PostPublicAgentTaskListBodyStateFilterItem(state_filter_item_data)



                state_filter.append(state_filter_item)


        page = d.pop("page", UNSET)

        limit = d.pop("limit", UNSET)

        _sort_order = d.pop("sortOrder", UNSET)
        sort_order: PostPublicAgentTaskListBodySortOrder | Unset
        if isinstance(_sort_order,  Unset):
            sort_order = UNSET
        else:
            sort_order = PostPublicAgentTaskListBodySortOrder(_sort_order)




        post_public_agent_task_list_body = cls(
            state_filter=state_filter,
            page=page,
            limit=limit,
            sort_order=sort_order,
        )


        post_public_agent_task_list_body.additional_properties = d
        return post_public_agent_task_list_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
