from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="PostPublicAgentTaskReportResponse200")



@_attrs_define
class PostPublicAgentTaskReportResponse200:
    """ 
        Attributes:
            report_id (float): The numeric ID of the stored report row.
            timestamp (float): The unix timestamp (ms) recorded on the report.
     """

    report_id: float
    timestamp: float





    def to_dict(self) -> dict[str, Any]:
        report_id = self.report_id

        timestamp = self.timestamp


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "reportId": report_id,
            "timestamp": timestamp,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        report_id = d.pop("reportId")

        timestamp = d.pop("timestamp")

        post_public_agent_task_report_response_200 = cls(
            report_id=report_id,
            timestamp=timestamp,
        )

        return post_public_agent_task_report_response_200

