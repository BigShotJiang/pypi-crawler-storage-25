from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_agent_task_report_body_state import PostPublicAgentTaskReportBodyState
from ..types import UNSET, Unset
from uuid import UUID






T = TypeVar("T", bound="PostPublicAgentTaskReportBody")



@_attrs_define
class PostPublicAgentTaskReportBody:
    """ 
        Attributes:
            task_uuid (UUID): Client-generated UUID that groups multiple reports into a single task. Reuse this UUID to
                append updates to the same task.
            summary (str): One-line status description of what the agent is doing now (160 characters maximum, no newlines).
            state (PostPublicAgentTaskReportBodyState): Current task state. Use 'working' for in-progress, 'complete' when
                finished, 'failure' when you need user input or have hit a blocker, 'idle' when nothing is in progress.
            link (str | Unset): Optional URL pointing to a relevant resource (PR, issue, artifact, log). Must be http(s).
     """

    task_uuid: UUID
    summary: str
    state: PostPublicAgentTaskReportBodyState
    link: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        task_uuid = str(self.task_uuid)

        summary = self.summary

        state = self.state.value

        link = self.link


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "taskUuid": task_uuid,
            "summary": summary,
            "state": state,
        })
        if link is not UNSET:
            field_dict["link"] = link

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        task_uuid = UUID(d.pop("taskUuid"))




        summary = d.pop("summary")

        state = PostPublicAgentTaskReportBodyState(d.pop("state"))




        link = d.pop("link", UNSET)

        post_public_agent_task_report_body = cls(
            task_uuid=task_uuid,
            summary=summary,
            state=state,
            link=link,
        )


        post_public_agent_task_report_body.additional_properties = d
        return post_public_agent_task_report_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
