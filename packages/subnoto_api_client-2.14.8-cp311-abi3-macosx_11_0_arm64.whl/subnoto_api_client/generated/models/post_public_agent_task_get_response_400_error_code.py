from enum import Enum

class PostPublicAgentTaskGetResponse400ErrorCode(str, Enum):
    AGENT_TASK_NOT_FOUND = "AGENT_TASK_NOT_FOUND"
    INVALID_REQUEST_FORMAT = "INVALID_REQUEST_FORMAT"

    def __str__(self) -> str:
        return str(self.value)
