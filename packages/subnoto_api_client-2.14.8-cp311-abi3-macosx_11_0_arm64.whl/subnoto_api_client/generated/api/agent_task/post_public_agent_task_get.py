from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_public_agent_task_get_body import PostPublicAgentTaskGetBody
from ...models.post_public_agent_task_get_response_200 import PostPublicAgentTaskGetResponse200
from ...models.post_public_agent_task_get_response_400 import PostPublicAgentTaskGetResponse400
from ...models.post_public_agent_task_get_response_401 import PostPublicAgentTaskGetResponse401
from ...models.post_public_agent_task_get_response_403 import PostPublicAgentTaskGetResponse403
from ...models.post_public_agent_task_get_response_500 import PostPublicAgentTaskGetResponse500
from typing import cast



def _get_kwargs(
    *,
    body: PostPublicAgentTaskGetBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/public/agent-task/get",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostPublicAgentTaskGetResponse200 | PostPublicAgentTaskGetResponse400 | PostPublicAgentTaskGetResponse401 | PostPublicAgentTaskGetResponse403 | PostPublicAgentTaskGetResponse500 | None:
    if response.status_code == 200:
        response_200 = PostPublicAgentTaskGetResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = PostPublicAgentTaskGetResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = PostPublicAgentTaskGetResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = PostPublicAgentTaskGetResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 500:
        response_500 = PostPublicAgentTaskGetResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostPublicAgentTaskGetResponse200 | PostPublicAgentTaskGetResponse400 | PostPublicAgentTaskGetResponse401 | PostPublicAgentTaskGetResponse403 | PostPublicAgentTaskGetResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAgentTaskGetBody,

) -> Response[PostPublicAgentTaskGetResponse200 | PostPublicAgentTaskGetResponse400 | PostPublicAgentTaskGetResponse401 | PostPublicAgentTaskGetResponse403 | PostPublicAgentTaskGetResponse500]:
    """ get

     Get the full history of reports for a single agent task, ordered from oldest to newest. Capped at
    100 reports per call.

    Args:
        body (PostPublicAgentTaskGetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostPublicAgentTaskGetResponse200 | PostPublicAgentTaskGetResponse400 | PostPublicAgentTaskGetResponse401 | PostPublicAgentTaskGetResponse403 | PostPublicAgentTaskGetResponse500]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAgentTaskGetBody,

) -> PostPublicAgentTaskGetResponse200 | PostPublicAgentTaskGetResponse400 | PostPublicAgentTaskGetResponse401 | PostPublicAgentTaskGetResponse403 | PostPublicAgentTaskGetResponse500 | None:
    """ get

     Get the full history of reports for a single agent task, ordered from oldest to newest. Capped at
    100 reports per call.

    Args:
        body (PostPublicAgentTaskGetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostPublicAgentTaskGetResponse200 | PostPublicAgentTaskGetResponse400 | PostPublicAgentTaskGetResponse401 | PostPublicAgentTaskGetResponse403 | PostPublicAgentTaskGetResponse500
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAgentTaskGetBody,

) -> Response[PostPublicAgentTaskGetResponse200 | PostPublicAgentTaskGetResponse400 | PostPublicAgentTaskGetResponse401 | PostPublicAgentTaskGetResponse403 | PostPublicAgentTaskGetResponse500]:
    """ get

     Get the full history of reports for a single agent task, ordered from oldest to newest. Capped at
    100 reports per call.

    Args:
        body (PostPublicAgentTaskGetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostPublicAgentTaskGetResponse200 | PostPublicAgentTaskGetResponse400 | PostPublicAgentTaskGetResponse401 | PostPublicAgentTaskGetResponse403 | PostPublicAgentTaskGetResponse500]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAgentTaskGetBody,

) -> PostPublicAgentTaskGetResponse200 | PostPublicAgentTaskGetResponse400 | PostPublicAgentTaskGetResponse401 | PostPublicAgentTaskGetResponse403 | PostPublicAgentTaskGetResponse500 | None:
    """ get

     Get the full history of reports for a single agent task, ordered from oldest to newest. Capped at
    100 reports per call.

    Args:
        body (PostPublicAgentTaskGetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostPublicAgentTaskGetResponse200 | PostPublicAgentTaskGetResponse400 | PostPublicAgentTaskGetResponse401 | PostPublicAgentTaskGetResponse403 | PostPublicAgentTaskGetResponse500
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
