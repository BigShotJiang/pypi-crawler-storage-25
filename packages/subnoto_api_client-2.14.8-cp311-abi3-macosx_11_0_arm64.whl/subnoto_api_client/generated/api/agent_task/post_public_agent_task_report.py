from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_public_agent_task_report_body import PostPublicAgentTaskReportBody
from ...models.post_public_agent_task_report_response_200 import PostPublicAgentTaskReportResponse200
from ...models.post_public_agent_task_report_response_401 import PostPublicAgentTaskReportResponse401
from ...models.post_public_agent_task_report_response_403 import PostPublicAgentTaskReportResponse403
from ...models.post_public_agent_task_report_response_500 import PostPublicAgentTaskReportResponse500
from typing import cast



def _get_kwargs(
    *,
    body: PostPublicAgentTaskReportBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/public/agent-task/report",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostPublicAgentTaskReportResponse200 | PostPublicAgentTaskReportResponse401 | PostPublicAgentTaskReportResponse403 | PostPublicAgentTaskReportResponse500 | None:
    if response.status_code == 200:
        response_200 = PostPublicAgentTaskReportResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 401:
        response_401 = PostPublicAgentTaskReportResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = PostPublicAgentTaskReportResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 500:
        response_500 = PostPublicAgentTaskReportResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostPublicAgentTaskReportResponse200 | PostPublicAgentTaskReportResponse401 | PostPublicAgentTaskReportResponse403 | PostPublicAgentTaskReportResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAgentTaskReportBody,

) -> Response[PostPublicAgentTaskReportResponse200 | PostPublicAgentTaskReportResponse401 | PostPublicAgentTaskReportResponse403 | PostPublicAgentTaskReportResponse500]:
    """ report

     Report agent task progress. Reuse the same taskUuid across calls to build a single task's history.
    Use state='working' for in-progress updates and 'complete', 'failure', or 'idle' to signal an end
    state.

    Args:
        body (PostPublicAgentTaskReportBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostPublicAgentTaskReportResponse200 | PostPublicAgentTaskReportResponse401 | PostPublicAgentTaskReportResponse403 | PostPublicAgentTaskReportResponse500]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAgentTaskReportBody,

) -> PostPublicAgentTaskReportResponse200 | PostPublicAgentTaskReportResponse401 | PostPublicAgentTaskReportResponse403 | PostPublicAgentTaskReportResponse500 | None:
    """ report

     Report agent task progress. Reuse the same taskUuid across calls to build a single task's history.
    Use state='working' for in-progress updates and 'complete', 'failure', or 'idle' to signal an end
    state.

    Args:
        body (PostPublicAgentTaskReportBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostPublicAgentTaskReportResponse200 | PostPublicAgentTaskReportResponse401 | PostPublicAgentTaskReportResponse403 | PostPublicAgentTaskReportResponse500
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAgentTaskReportBody,

) -> Response[PostPublicAgentTaskReportResponse200 | PostPublicAgentTaskReportResponse401 | PostPublicAgentTaskReportResponse403 | PostPublicAgentTaskReportResponse500]:
    """ report

     Report agent task progress. Reuse the same taskUuid across calls to build a single task's history.
    Use state='working' for in-progress updates and 'complete', 'failure', or 'idle' to signal an end
    state.

    Args:
        body (PostPublicAgentTaskReportBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostPublicAgentTaskReportResponse200 | PostPublicAgentTaskReportResponse401 | PostPublicAgentTaskReportResponse403 | PostPublicAgentTaskReportResponse500]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAgentTaskReportBody,

) -> PostPublicAgentTaskReportResponse200 | PostPublicAgentTaskReportResponse401 | PostPublicAgentTaskReportResponse403 | PostPublicAgentTaskReportResponse500 | None:
    """ report

     Report agent task progress. Reuse the same taskUuid across calls to build a single task's history.
    Use state='working' for in-progress updates and 'complete', 'failure', or 'idle' to signal an end
    state.

    Args:
        body (PostPublicAgentTaskReportBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostPublicAgentTaskReportResponse200 | PostPublicAgentTaskReportResponse401 | PostPublicAgentTaskReportResponse403 | PostPublicAgentTaskReportResponse500
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
