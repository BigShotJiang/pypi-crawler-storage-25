from setuptools import setup, find_packages

setup(
    name="makini-ai",
    version="1.0.7",
    description="Federated Agent Orchestration Engine based on Stack Physics",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Makini Authors",
    author_email="dickens.nyabuti@gmail.com",
    url="https://api.makini.ai",
    project_urls={
        "Source": "https://github.com/nyabutid/makini",
        "Documentation": "https://api.makini.ai",
        "Tracker": "https://github.com/nyabutid/makini/issues",
    },
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "streamlit>=1.35.0",
        "pysqlite3",
        "pyyaml",
        "networkx",
        "inflect",
        "protobuf>=5.26.1",
        "requests"
    ],
    entry_points={
        "console_scripts": [
            "makini=makini.cli_runner.makini_cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
)
