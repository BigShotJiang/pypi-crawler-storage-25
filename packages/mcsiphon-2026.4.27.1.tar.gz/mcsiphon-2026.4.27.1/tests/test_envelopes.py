"""Smoke tests for envelope builders. No network — just XML well-formedness
and the strict-ordering / single-element gotchas we discovered live."""
import xml.etree.ElementTree as ET

from mcsiphon import envelopes


def _parse(s: str) -> ET.Element:
    return ET.fromstring(s)


def test_get_time_zone_well_formed():
    root = _parse(envelopes.get_time_zone())
    assert root.tag.endswith("Envelope")


def test_list_node_service_logs_includes_listrequest():
    body = envelopes.list_node_service_logs()
    assert "<soap:ListRequest>" in body
    _parse(body)


def test_get_one_file_has_no_wrapper():
    """GetOneFile must NOT wrap FileName in <soap:GetOneFile> — that triggers
    'Unexpected subelement GetOneFile' on Axis2. Verified live 2026-04-26."""
    body = envelopes.get_one_file("/var/log/x.txt")
    assert "<soap:FileName>" in body
    assert "<soap:GetOneFile>" not in body


def test_get_one_file_escapes_xml_metachars():
    body = envelopes.get_one_file("/path/with<>&chars.txt")
    assert "<>" not in body
    assert "&lt;" in body and "&gt;" in body and "&amp;" in body


def test_select_log_files_strict_field_order():
    """selectLogFiles must include all 16 fields in WSDL declaration order.
    Axis2 ADB rejects misordering with 'Unexpected subelement <Name>'."""
    body = envelopes.select_log_files(services=["Cisco CallManager"])
    # Verify the strict order (each subsequent field must come AFTER its predecessor)
    expected_order = [
        "ServiceLogs", "SystemLogs", "SearchStr", "Frequency", "JobType",
        "ToDate", "FromDate", "TimeZone", "RelText", "RelTime",
        "Port", "IPAddress", "UserName", "Password", "ZipInfo", "RemoteFolder",
    ]
    last_pos = -1
    for field in expected_order:
        pos = body.find(f"<soap:{field}")
        assert pos > last_pos, f"{field} appears before predecessors (pos={pos}, prev={last_pos})"
        last_pos = pos


def test_select_log_files_jobtype_is_locked():
    """JobType must be hardcoded to DownloadtoClient — the SFTP-push variant
    would let callers exfiltrate to arbitrary external servers."""
    body = envelopes.select_log_files(services=["x"], frequency="OnDemand")
    assert "<soap:JobType>DownloadtoClient</soap:JobType>" in body
    assert "PushtoSFTPServer" not in body


def test_select_log_files_sftp_fields_blank():
    body = envelopes.select_log_files(services=["x"])
    assert "<soap:Port>0</soap:Port>" in body
    assert "<soap:IPAddress></soap:IPAddress>" in body
    assert "<soap:RemoteFolder></soap:RemoteFolder>" in body
