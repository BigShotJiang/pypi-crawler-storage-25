"""Smoke tests for the SDL → SIPL/SIPT preprocessor.

ALL test fixtures below are PLACEHOLDER values, NOT real production data.
IPs use RFC 5737 documentation ranges, hostnames use the IANA-reserved
.example TLD, and Call-IDs are obviously synthetic zero-fills.
"""
from mcsiphon.sdl_to_siplt import convert

_SAMPLE_FILEHEAD = (
    "18047782.000 |00:23:18.222 |FileHead |UTC:-06:00,Date: 2020/01/01, "
    "AppName: CCM, AppId: 100, AppNodeId: 1, "
    "AppVersion: CUCM Install=PLACEHOLDER, HostName: PLACEHOLDER-cucm-pub, "
    "HostIPAddress: ::ffff:192.0.2.100, AppStartTime: 2020/01/01 00:00:00"
)

_SAMPLE_OUT_BLOCK = """\
18047785.001 |00:23:18.225 |AppInfo  |SIPTcp - wait_SdlSPISignal: Outgoing SIP TCP message to 192.0.2.10 on port 50000 index 1
[100000001,NET]
SIP/2.0 200 OK
Via: SIP/2.0/TCP 192.0.2.10:50000;branch=z9hG4bK00000001
Call-ID: 00000000-0000-0000-0000-000000000001@192.0.2.10
CSeq: 1 REGISTER
Content-Length: 0

"""

_SAMPLE_IN_BLOCK = """\
18047846.002 |00:23:18.802 |AppInfo  |SIPTcp - wait_SdlReadRsp: Incoming SIP TCP message from 192.0.2.20 on port 50001 index 2 with 1036 bytes:
[100000002,NET]
REGISTER sip:PLACEHOLDER-cucm-pub.YOURDOMAIN.example SIP/2.0
Via: SIP/2.0/TCP 192.0.2.20:50001;branch=z9hG4bK00000002
Call-ID: 00000000-0000-0000-0000-000000000002@192.0.2.20
CSeq: 1 REGISTER
Content-Length: 0

"""


def test_extracts_filehead_date_and_local_ip():
    """The local CUCM IP and date come from FileHead. Without that, we
    couldn't render the diagram with correct sender/receiver labels."""
    raw = _SAMPLE_FILEHEAD + "\n" + _SAMPLE_OUT_BLOCK
    out = convert(raw)
    assert "2020/01/01" in out
    assert "192.0.2.100" in out


def test_outgoing_block_emits_sipt():
    """OUT direction → SIPT (transmitted), local first, remote at position 5."""
    raw = _SAMPLE_FILEHEAD + "\n" + _SAMPLE_OUT_BLOCK
    out = convert(raw)
    lines = [ln for ln in out.split("\n") if ln and "EOF_SENTINEL" not in ln]
    assert len(lines) == 1
    fields = lines[0].split("|")
    assert fields[1] == "SIPT"
    assert fields[4] == "OUT"
    assert fields[5] == "192.0.2.100"  # local placeholder
    assert fields[8] == "192.0.2.10"   # remote placeholder
    assert fields[9] == "50000"        # placeholder port
    assert "200 OK" in fields[-1]


def test_incoming_block_emits_sipl():
    """IN direction → SIPL (received), local first, remote at position 5."""
    raw = _SAMPLE_FILEHEAD + "\n" + _SAMPLE_IN_BLOCK
    out = convert(raw)
    lines = [ln for ln in out.split("\n") if ln and "EOF_SENTINEL" not in ln]
    assert len(lines) == 1
    fields = lines[0].split("|")
    assert fields[1] == "SIPL"
    assert fields[4] == "IN"
    assert fields[8] == "192.0.2.20"
    assert fields[-1] == "REGISTER"


def test_call_id_extracted_for_correlation():
    """Call-ID becomes the GUID field — matters for ladder grouping."""
    raw = _SAMPLE_FILEHEAD + "\n" + _SAMPLE_IN_BLOCK
    out = convert(raw)
    line = [ln for ln in out.split("\n") if ln and "EOF_SENTINEL" not in ln][0]
    assert "00000000-0000-0000-0000-000000000002@192.0.2.20" in line


def test_sentinel_appended_with_safe_marker():
    """Workaround for HTMLGenerator's last-line-drop bug
    (decompiled/docs/lessons-learned.md item 7).

    Hamilton H5: the marker must be distinctive (not str-replace-able into a
    real SIP message), all 14 pipe-separated fields must be present so the
    legacy parser consumes it cleanly, and MSG_LABEL must be unmistakably
    not a SIP method/response code.
    """
    raw = _SAMPLE_FILEHEAD + "\n" + _SAMPLE_OUT_BLOCK
    out = convert(raw)
    assert "EOF_SENTINEL_DROP_ME" in out
    sentinel_line = out.strip().split("\n")[-1]
    assert sentinel_line.endswith("EOF_SENTINEL_DROP_ME")
    fields = sentinel_line.split("|")
    assert len(fields) == 14, f"sentinel must have 14 SIPL/SIPT fields, got {len(fields)}"
    # MSG_LABEL is the last field; must NOT look like a SIP method or response
    assert fields[-1] == "EOF_SENTINEL_DROP_ME"


def test_decompress_if_gzip_handles_both():
    """`.gzo` files come back already-decompressed; `.gz` files come back
    gzipped. The helper transparently handles both."""
    import gzip

    from mcsiphon.sdl_to_siplt import decompress_if_gzip

    plain = b"already plain text\nline 2\n"
    assert decompress_if_gzip(plain) == plain.decode()

    compressed = gzip.compress(plain)
    assert decompress_if_gzip(compressed) == plain.decode()


def test_msgtag_unique_per_message():
    """Each emitted line gets a distinct MSGTAG so the engine doesn't dedupe."""
    raw = _SAMPLE_FILEHEAD + "\n" + _SAMPLE_OUT_BLOCK + "\n" + _SAMPLE_IN_BLOCK
    out = convert(raw)
    lines = [ln for ln in out.split("\n") if ln and "EOF_SENTINEL" not in ln]
    msgtags = [ln.split("|")[11] for ln in lines]
    assert len(set(msgtags)) == len(msgtags)
