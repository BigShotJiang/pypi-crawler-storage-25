"""Tests for the SOAP/MTOM client — focused on Hamilton review fixes."""
import pytest

from mcsiphon.client import (
    TctFault,
    TctParseError,
    _check_for_fault,
    _parse_response,
)


# ---------------------------------------------------------------------------
# Hamilton C1: namespace-aware fault detection
# ---------------------------------------------------------------------------

_FAULT_SOAPENV = b"""<?xml version="1.0"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
  <soapenv:Body>
    <soapenv:Fault>
      <faultcode>soapenv:Server</faultcode>
      <faultstring>Cisco-style fault from CUCM</faultstring>
    </soapenv:Fault>
  </soapenv:Body>
</soapenv:Envelope>"""

_FAULT_DIFFERENT_PREFIX = b"""<?xml version="1.0"?>
<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">
  <SOAP-ENV:Body>
    <SOAP-ENV:Fault>
      <faultcode>SOAP-ENV:Server</faultcode>
      <faultstring>Same fault, different prefix - must still be detected</faultstring>
    </SOAP-ENV:Fault>
  </SOAP-ENV:Body>
</SOAP-ENV:Envelope>"""

_FAULT_SHORT_PREFIX = b"""<?xml version="1.0"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body>
    <s:Fault>
      <faultcode>s:Server</faultcode>
      <faultstring>Single-letter prefix variant</faultstring>
    </s:Fault>
  </s:Body>
</s:Envelope>"""

_OK_RESPONSE = b"""<?xml version="1.0"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
  <soapenv:Body>
    <ns1:getTimeZoneResponse xmlns:ns1="http://schemas.cisco.com/ast/soap"/>
  </soapenv:Body>
</soapenv:Envelope>"""


def test_check_for_fault_detects_soapenv_prefix():
    with pytest.raises(TctFault, match="Cisco-style fault"):
        _check_for_fault(_FAULT_SOAPENV)


def test_check_for_fault_detects_uppercase_prefix():
    """Critical: previous substring match for `<soapenv:Fault>` would
    silently miss this — Cisco could rewrap responses through a proxy
    and start using a different prefix."""
    with pytest.raises(TctFault, match="Same fault, different prefix"):
        _check_for_fault(_FAULT_DIFFERENT_PREFIX)


def test_check_for_fault_detects_short_prefix():
    with pytest.raises(TctFault, match="Single-letter prefix"):
        _check_for_fault(_FAULT_SHORT_PREFIX)


def test_check_for_fault_passes_clean_response():
    """OK response has no Fault element — must not raise."""
    _check_for_fault(_OK_RESPONSE)  # no exception expected


def test_check_for_fault_tolerates_non_xml_with_fault_shape():
    """If we get truncated/malformed XML that still mentions a fault, raise
    rather than silently returning. Better loud than wrong."""
    truncated = b"<random html>HTTP error <faultstring>auth failed</faultstring> Fault>"
    with pytest.raises(TctFault, match="auth failed"):
        _check_for_fault(truncated)


def test_check_for_fault_tolerates_non_xml_without_fault_shape():
    """Random non-XML bytes that aren't fault-shaped should pass through —
    let the caller's parsing surface the real error."""
    _check_for_fault(b"Internal Server Error 500")  # no exception expected


# ---------------------------------------------------------------------------
# Hamilton M3: MTOM parse error surfaces loudly
# ---------------------------------------------------------------------------


def test_parse_response_passthrough_for_non_multipart():
    """Plain XML response → returned as-is, no attachments."""
    body = b"<envelope/>"
    env, atts = _parse_response(body, "text/xml; charset=utf-8")
    assert env == body
    assert atts == []


def test_parse_response_raises_on_unparseable_boundary():
    """Hamilton M3: previously this returned (raw_body, []) which meant
    the caller tried to XML-parse the raw multipart bytes and got a
    confusing error. Now it raises loudly."""
    body = b"--something\r\nContent-Type: text/xml\r\n\r\n<env/>\r\n--something--"
    # Content-Type advertises multipart but with no boundary parameter
    with pytest.raises(TctParseError, match="boundary not parseable"):
        _parse_response(body, "multipart/related; type=\"application/xop+xml\"")


def test_parse_response_handles_normal_mtom_envelope_only():
    """Single-part MTOM (typical for listNodeServiceLogs) — envelope + no atts."""
    boundary = "MIMEBoundary123"
    body = (
        f"--{boundary}\r\n"
        "Content-Type: application/xop+xml; charset=utf-8\r\n"
        "Content-Transfer-Encoding: binary\r\n"
        "\r\n"
        "<envelope/>\r\n"
        f"--{boundary}--\r\n"
    ).encode()
    env, atts = _parse_response(body, f'multipart/related; boundary="{boundary}"')
    assert env == b"<envelope/>"
    assert atts == []
