"""HTTP + MTOM client for CUCM 15 LogCollectionPortTypeService."""
import email
import re
import xml.etree.ElementTree as ET

import httpx

ENDPOINT_PATH = "/logcollectionservice2/services/LogCollectionPortTypeService"

# SOAP envelope namespace — used for namespace-aware Fault detection.
# Substring matching on `<soapenv:Fault>` would silently miss faults if
# the prefix changed (SOAP-ENV:, s:, ns0:, etc.) — Hamilton review C1.
_SOAP_ENV_NS = "http://schemas.xmlsoap.org/soap/envelope/"


class TctFault(RuntimeError):
    """Raised when the server returns a SOAP fault."""


class TctParseError(RuntimeError):
    """Raised when the server response can't be parsed (malformed MTOM, etc)."""


class TctClient:
    def __init__(self, base: str, user: str, password: str, verify_tls: bool = True):
        self.base = base.rstrip("/")
        self.endpoint = self.base + ENDPOINT_PATH
        self._client = httpx.Client(
            auth=(user, password),
            verify=verify_tls,
            timeout=120.0,
        )

    def call(self, body: str, soap_action: str = "") -> tuple[bytes, list[bytes]]:
        """POST a SOAP envelope. Returns (envelope_bytes, [attachment_bytes, ...]).

        Raises TctFault on SOAP fault (namespace-aware — survives prefix changes).
        Raises TctParseError if the response can't be parsed as expected MTOM.
        Caller is responsible for parsing the envelope XML further.
        """
        headers = {
            "Content-Type": "text/xml; charset=utf-8",
            "SOAPAction": f'"{soap_action}"',
        }
        r = self._client.post(self.endpoint, content=body.encode("utf-8"), headers=headers)
        ct = r.headers.get("content-type", "")
        envelope, attachments = _parse_response(r.content, ct)
        _check_for_fault(envelope)
        return envelope, attachments

    def close(self) -> None:
        self._client.close()


def _check_for_fault(envelope: bytes) -> None:
    """Raise TctFault if the envelope contains a SOAP fault. Namespace-aware:
    finds <{soap-env-ns}Fault> regardless of namespace prefix.

    Falls back to a tolerant substring check if XML parsing fails — better
    to surface a fault we can name than to swallow one we can't parse.
    """
    try:
        root = ET.fromstring(envelope)
    except ET.ParseError:
        # Pre-XML failure modes (HTML error pages, truncated MIME). Be tolerant:
        # if the bytes mention "Fault" in a SOAP-shaped context, raise.
        if b"Fault>" in envelope and (b"faultstring" in envelope or b"faultcode" in envelope):
            m = re.search(rb"<[^>]*faultstring[^>]*>([^<]+)<", envelope)
            msg = m.group(1).decode("utf-8", errors="replace") if m else "unparseable SOAP fault"
            raise TctFault(msg)
        return  # not XML and not fault-shaped — let caller handle

    fault = root.find(f".//{{{_SOAP_ENV_NS}}}Fault")
    if fault is None:
        return
    # faultstring is typically un-namespaced inside Fault per SOAP 1.1 spec
    fs_elem = fault.find("faultstring")
    if fs_elem is None:
        # SOAP 1.2 uses {ns}Reason/{ns}Text instead — try that
        fs_elem = fault.find(f"{{{_SOAP_ENV_NS}}}Reason/{{{_SOAP_ENV_NS}}}Text")
    msg = (fs_elem.text or "").strip() if fs_elem is not None else "unknown SOAP fault"
    raise TctFault(msg)


def _parse_response(body: bytes, content_type: str) -> tuple[bytes, list[bytes]]:
    """Parse Cisco Axis2 response. Returns (envelope_bytes, [attachment_bytes, ...]).

    CUCM 15 LogCollectionPortTypeService always wraps responses as
    multipart/related MTOM. listNodeServiceLogs and selectLogFiles return
    just the SOAP envelope as the only part. GetOneFile returns the SOAP
    envelope as part 0 plus the file bytes as part 1.

    Raises TctParseError if the Content-Type advertises multipart but the
    boundary can't be parsed — better to fail loudly than return malformed
    bytes that ET.fromstring will choke on with a useless error
    (Hamilton review M3).
    """
    if "multipart/related" not in content_type:
        return body, []
    m = re.search(r'boundary="?([^";\s\r\n]+)"?', content_type)
    if not m:
        raise TctParseError(
            f"multipart/related content-type but boundary not parseable: {content_type[:200]}"
        )
    boundary = m.group(1)
    wrapped = (
        b'Content-Type: multipart/related; boundary="'
        + boundary.encode()
        + b'"\r\n\r\n'
        + body
    )
    msg = email.message_from_bytes(wrapped)
    parts = list(msg.walk())[1:]  # skip outer container
    if not parts:
        raise TctParseError(
            f"multipart/related but no parts found (body len={len(body)})"
        )
    envelope = parts[0].get_payload(decode=True) or b""
    attachments = [p.get_payload(decode=True) or b"" for p in parts[1:]]
    return envelope, attachments
