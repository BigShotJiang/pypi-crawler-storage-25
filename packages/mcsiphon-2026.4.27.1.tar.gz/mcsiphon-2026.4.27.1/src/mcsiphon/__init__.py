"""mcsiphon — read-only MCP server for CUCM 15 Trace Collection."""
