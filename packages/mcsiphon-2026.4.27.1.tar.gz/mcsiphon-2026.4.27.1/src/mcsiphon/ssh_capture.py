"""SSH-driven packet capture on a Cisco Unified CM publisher.

CUCM's restricted CLI requires an interactive PTY (paramiko's `invoke_shell()`
rather than `exec_command()`). The `utils network capture` command runs in
the foreground and returns control when complete.

The CUCM CLI prompt is typically `admin:` (or whatever the SSH username is
plus a colon). We wait for that prompt to know a command has finished.

Hardening per the Margaret Hamilton review (2026-04):
- C2: explicit success indicator instead of "error" substring heuristic
- C3: bounded buffer + clear timeout-vs-prompt-miss signal
- H1: uuid+pid in default filename to prevent concurrent-call collisions
- H2: channel close in finally regardless of exception path
- H3: known_hosts policy default is `reject`; `CUCM_SSH_INSECURE_AUTOADD=1`
      opt-in for first-time bootstrap (with stderr warning)
"""
import os
import re
import sys
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Optional

import paramiko


_FIRST_PROMPT_TIMEOUT = 30.0
# Buffer cap: keep head + tail to preserve prompt detection without OOM.
# 4 MB is plenty for legitimate `utils network capture` output (which is
# ~1 KB of summary text); anything pathological will trigger the cap.
_MAX_BUFFER = 4 * 1024 * 1024
# Loosened prompt regex — original `^[a-zA-Z][a-zA-Z0-9_-]*:\s*$` rejected
# digit-leading hostnames and was anchored to a full line. This matches
# any short word ending in `:` near the end of buffer.
_PROMPT_RE = re.compile(rb"\n([a-zA-Z][a-zA-Z0-9_.-]{0,80}):\s*\Z")


class ReadResult(Enum):
    PROMPT = "prompt"      # we saw the CUCM prompt — command finished cleanly
    TIMEOUT = "timeout"    # deadline expired without seeing a prompt
    CLOSED = "closed"      # channel closed unexpectedly


@dataclass
class CaptureResult:
    success: bool
    command: str
    filename: str
    server_path: str
    output: str           # raw CLI output (truncated if exceeded buffer)
    read_status: str      # "prompt" | "timeout" | "closed"
    output_truncated: bool
    error: Optional[str] = None


def _read_until_prompt(chan: paramiko.Channel, timeout: float) -> tuple[bytes, ReadResult, bool]:
    """Drain channel until prompt, timeout, or close. Bounded buffer.

    Returns: (buffer, status, truncated)
        buffer: bytes captured (may be truncated — head + tail preserved)
        status: PROMPT / TIMEOUT / CLOSED
        truncated: True if total bytes received exceeded _MAX_BUFFER
    """
    head = bytearray()
    tail = bytearray()
    total_seen = 0
    truncated = False
    closed = False
    deadline = time.monotonic() + timeout

    while time.monotonic() < deadline:
        if chan.closed or chan.exit_status_ready():
            buf = bytes(head + (b"\n... [TRUNCATED] ...\n" if truncated else b"") + tail)
            return buf, ReadResult.CLOSED, truncated
        if chan.recv_ready():
            try:
                chunk = chan.recv(8192)
            except Exception:
                closed = True
                break
            if not chunk:
                # Empty bytes from recv() = peer closed the channel
                closed = True
                break
            total_seen += len(chunk)
            # Keep head untruncated until cap, then accumulate into rolling tail
            if not truncated:
                head.extend(chunk)
                if len(head) > _MAX_BUFFER // 2:
                    truncated = True
                    # Flush head down to its first half
                    overflow = bytes(head[_MAX_BUFFER // 2:])
                    del head[_MAX_BUFFER // 2:]
                    tail.extend(overflow)
            else:
                tail.extend(chunk)
                # Keep tail bounded too — drop oldest bytes
                if len(tail) > _MAX_BUFFER // 2:
                    drop = len(tail) - _MAX_BUFFER // 2
                    del tail[:drop]
            # Prompt detection on the most recent bytes only — avoids
            # re-scanning megabytes on each chunk
            window = bytes(tail[-2048:]) if tail else bytes(head[-2048:])
            if _PROMPT_RE.search(window) and b"\n" in window:
                buf = bytes(head + (b"\n... [TRUNCATED] ...\n" if truncated else b"") + tail)
                return buf, ReadResult.PROMPT, truncated
        else:
            time.sleep(0.1)

    buf = bytes(head + (b"\n... [TRUNCATED] ...\n" if truncated else b"") + tail)
    return buf, (ReadResult.CLOSED if closed else ReadResult.TIMEOUT), truncated


def _looks_successful(output: str, filename: str) -> bool:
    """Determine if the capture command succeeded based on explicit signals,
    not heuristic substrings. Returns True only if we have positive evidence
    of success.

    CUCM CLI conventions observed:
    - Lines starting with `%` indicate failure (e.g., `% Invalid input`)
    - `Executed command unsuccessfully` is the explicit failure marker
    - `Executing command with options:` echoes the parsed args (success path
      always shows this). Capture summary follows.
    """
    if not output:
        return False
    # Hard failures
    if "Executed command unsuccessfully" in output:
        return False
    if re.search(r"^%\s+\w", output, re.MULTILINE):
        return False
    if "Permission denied" in output or "Authorization failed" in output:
        return False
    # Positive evidence: we saw the command echo + capture-relevant output
    if "Executing command with options:" in output and filename in output:
        return True
    # Conservative fallback: command ran (we got our prompt back) and no
    # explicit failure. This is the "didn't fail loudly" case — trust but
    # downstream `get_one_file` will surface a missing file if it's lying.
    return True


def _build_host_key_policy() -> paramiko.MissingHostKeyPolicy:
    """Reject unknown hosts by default. Opt-in to TOFU via env var.

    CUCM platform admin SSH is the most privileged account on the cluster.
    Default `AutoAddPolicy` would silently accept any host key, exposing
    the credential to MITM. Hamilton review H3.
    """
    if os.environ.get("CUCM_SSH_INSECURE_AUTOADD", "").lower() in ("1", "true", "yes"):
        print(
            "[mcsiphon] WARNING: CUCM_SSH_INSECURE_AUTOADD=1 — "
            "accepting any SSH host key (TOFU). Use only for first-run bootstrap.",
            file=sys.stderr,
        )
        return paramiko.AutoAddPolicy()
    return paramiko.RejectPolicy()


def run_capture(
    host: str,
    user: str,
    *,
    password: str | None = None,
    key_filename: str | None = None,
    port: int = 22,
    interface: str = "eth0",
    duration_seconds: int = 60,
    count: int | None = None,
    host_filter: str | None = None,
    port_filter: int | None = None,
    filename: str | None = None,
    known_hosts: str | None = None,
) -> CaptureResult:
    """Run `utils network capture` on a CUCM node over SSH.

    Args:
        host: CUCM hostname or IP
        user: platform admin username (typically `admin`)
        password: SSH password (or use key_filename instead)
        key_filename: path to SSH private key
        port: SSH port (default 22)
        interface: network interface (default eth0)
        duration_seconds: capture duration; combined with `count` if both given
        count: max packets to capture (default 100000 if duration-only)
        host_filter: optional source/dest IP filter
        port_filter: optional port filter (e.g. 5060 for SIP)
        filename: capture file name on the server (default auto-generated
            with uuid+pid for concurrency safety)
        known_hosts: path to a known_hosts file (defaults to ~/.ssh/known_hosts)

    Returns: CaptureResult. Inspect `success` AND `read_status`:
        - success=True, read_status="prompt": clean
        - success=False, read_status="prompt": command ran but failed
          (check `output` for the error message)
        - read_status="timeout": command may still be running on server
        - read_status="closed": channel dropped — likely network issue
    """
    if not filename:
        # Hamilton H1: collision-safe filename for concurrent calls.
        # Format: cap_<unix-ms>_<short-uuid>
        filename = f"cap_{int(time.time() * 1000)}_{uuid.uuid4().hex[:6]}"
    cap_count = count or 100000
    cmd_parts = [
        "utils", "network", "capture",
        interface,
        "size", "all",
        "count", str(cap_count),
        "file", filename,
    ]
    if duration_seconds:
        cmd_parts += ["duration", str(duration_seconds)]
    if host_filter:
        cmd_parts += ["host", host_filter]
    if port_filter:
        cmd_parts += ["port", str(port_filter)]
    cmd = " ".join(cmd_parts)

    server_path = f"/var/log/active/platform/cli/{filename}.cap"

    client = paramiko.SSHClient()
    if known_hosts:
        try:
            client.load_host_keys(known_hosts)
        except FileNotFoundError:
            pass  # empty known_hosts — policy below decides
    else:
        try:
            client.load_system_host_keys()
        except Exception:
            pass
    client.set_missing_host_key_policy(_build_host_key_policy())

    chan = None
    try:
        client.connect(
            host,
            port=port,
            username=user,
            password=password,
            key_filename=key_filename,
            allow_agent=True,
            look_for_keys=True,
            timeout=15,
        )
        chan = client.invoke_shell()
        # Wait for initial prompt (banner + login messages first)
        _, init_status, _ = _read_until_prompt(chan, _FIRST_PROMPT_TIMEOUT)
        if init_status is ReadResult.TIMEOUT:
            return CaptureResult(
                success=False, command=cmd, filename=f"{filename}.cap",
                server_path=server_path, output="", read_status=init_status.value,
                output_truncated=False,
                error="Initial CUCM prompt not seen within 30s of SSH connect — "
                "verify the account has shell access (some accounts are AXL-only).",
            )
        if init_status is ReadResult.CLOSED:
            return CaptureResult(
                success=False, command=cmd, filename=f"{filename}.cap",
                server_path=server_path, output="", read_status=init_status.value,
                output_truncated=False,
                error="SSH channel closed before initial prompt.",
            )
        # Send capture command — server returns to prompt when done.
        chan.send((cmd + "\n").encode())
        # Read until prompt. Cisco quirks (verified live 2026-04-27):
        #   1. CUCM holds the SSH channel silent for the entire capture —
        #      no progress output until the very end.
        #   2. `duration` is NOT a hard ceiling. We've observed `duration 15`
        #      captures running 179s server-side (~12x). The `count` param
        #      may be the real stop condition, or duration may be a minimum.
        #   3. Even short captures take ~90s+ server-side floor.
        # Floor at 180s; add 60s margin over duration. If deadline still
        # fires, the file usually lands anyway — callers recover via
        # `get_one_file(server_path)` once `read_status="timeout"` is seen.
        cli_deadline = max(duration_seconds + 60, 180)
        out, status, truncated = _read_until_prompt(chan, cli_deadline)
        text = out.decode("utf-8", errors="replace")
        success = (status is ReadResult.PROMPT) and _looks_successful(text, filename)
        error = None
        if not success and status is ReadResult.TIMEOUT:
            error = (
                f"CLI timeout after {cli_deadline}s — "
                "command may still be running server-side; retry "
                "`get_one_file` against the server_path after a brief delay."
            )
        elif not success and status is ReadResult.CLOSED:
            error = "SSH channel closed unexpectedly during capture."
        elif not success:
            error = "Command completed but did not appear to succeed; check `output`."
        return CaptureResult(
            success=success,
            command=cmd,
            filename=f"{filename}.cap",
            server_path=server_path,
            output=text,
            read_status=status.value,
            output_truncated=truncated,
            error=error,
        )
    except paramiko.ssh_exception.BadHostKeyException as exc:
        return CaptureResult(
            success=False, command=cmd, filename=f"{filename}.cap",
            server_path=server_path, output="", read_status="closed",
            output_truncated=False,
            error=(
                f"SSH host key mismatch: {exc}. "
                "If this is a legitimate first-time connection, set "
                "CUCM_SSH_INSECURE_AUTOADD=1 once to bootstrap, then unset."
            ),
        )
    except paramiko.ssh_exception.SSHException as exc:
        return CaptureResult(
            success=False, command=cmd, filename=f"{filename}.cap",
            server_path=server_path, output="", read_status="closed",
            output_truncated=False,
            error=(
                f"{type(exc).__name__}: {exc}. "
                "If host key was rejected, set CUCM_SSH_INSECURE_AUTOADD=1 "
                "once to add it (then unset)."
            ),
        )
    except Exception as exc:
        return CaptureResult(
            success=False, command=cmd, filename=f"{filename}.cap",
            server_path=server_path, output="", read_status="closed",
            output_truncated=False,
            error=f"{type(exc).__name__}: {exc}",
        )
    finally:
        # Hamilton H2: close channel even if read raised
        if chan is not None:
            try:
                chan.close()
            except Exception:
                pass
        client.close()
