"""SOAP envelope builders for CUCM 15 LogCollectionPortTypeService.

Hand-crafted XML strings — the WSDL surface is small enough that a full SOAP
toolkit (zeep) adds more weight than it removes. xml.sax.saxutils.escape
guards against injection from filenames/search strings.
"""
from xml.sax.saxutils import escape

_HEAD = (
    '<soapenv:Envelope '
    'xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" '
    'xmlns:soap="http://schemas.cisco.com/ast/soap">'
    '<soapenv:Body>'
)
_TAIL = '</soapenv:Body></soapenv:Envelope>'


def get_time_zone(local_host: str = "") -> str:
    # Same RPC-style trick as GetOneFile: getTimeZoneRequest references
    # <part element="tns:LocalHost">, so the body is <soap:LocalHost> directly,
    # not <soap:getTimeZone>. Sending <soap:getTimeZone/> produces
    # 'Unexpected subelement getTimeZone'.
    return f'{_HEAD}<soap:LocalHost>{escape(local_host)}</soap:LocalHost>{_TAIL}'


def list_node_service_logs() -> str:
    # The ListRequest body is ignored by the server in practice; any string works.
    return (
        f'{_HEAD}'
        '<soap:listNodeServiceLogs>'
        '<soap:ListRequest>x</soap:ListRequest>'
        '</soap:listNodeServiceLogs>'
        f'{_TAIL}'
    )


def select_log_files(
    services: list[str],
    system_logs: list[str] | None = None,
    search_str: str = "",
    frequency: str = "OnDemand",
    from_date: str = "",
    to_date: str = "",
    time_zone: str = "UTC",
    rel_text: str = "Minutes",
    rel_time: int = 5,
) -> str:
    """Build selectLogFiles envelope. Strict 16-field WSDL order required.

    JobType is hardcoded to DownloadtoClient. SFTP-push fields (Port,
    IPAddress, UserName, Password, RemoteFolder) are sent empty —
    never exposed to callers. ZipInfo is hardcoded to false.
    """
    system_logs = system_logs or []
    items = "".join(f"<soap:item>{escape(s)}</soap:item>" for s in services)
    sys_items = "".join(f"<soap:item>{escape(s)}</soap:item>" for s in system_logs)
    return (
        f'{_HEAD}'
        '<soap:selectLogFiles>'
        '<soap:FileSelectionCriteria>'
        f'<soap:ServiceLogs>{items}</soap:ServiceLogs>'
        f'<soap:SystemLogs>{sys_items}</soap:SystemLogs>'
        f'<soap:SearchStr>{escape(search_str)}</soap:SearchStr>'
        f'<soap:Frequency>{escape(frequency)}</soap:Frequency>'
        '<soap:JobType>DownloadtoClient</soap:JobType>'
        f'<soap:ToDate>{escape(to_date)}</soap:ToDate>'
        f'<soap:FromDate>{escape(from_date)}</soap:FromDate>'
        f'<soap:TimeZone>{escape(time_zone)}</soap:TimeZone>'
        f'<soap:RelText>{escape(rel_text)}</soap:RelText>'
        f'<soap:RelTime>{int(rel_time)}</soap:RelTime>'
        '<soap:Port>0</soap:Port>'
        '<soap:IPAddress></soap:IPAddress>'
        '<soap:UserName></soap:UserName>'
        '<soap:Password></soap:Password>'
        '<soap:ZipInfo>false</soap:ZipInfo>'
        '<soap:RemoteFolder></soap:RemoteFolder>'
        '</soap:FileSelectionCriteria>'
        '</soap:selectLogFiles>'
        f'{_TAIL}'
    )


def get_one_file(file_name: str) -> str:
    # Single FileName element directly in Body — no wrapper. Per WSDL message
    # def: GetOneFileRequest has only one part (FileName). LocalHost and
    # TimeZone elements declared in the schema are unused by any message.
    return f'{_HEAD}<soap:FileName>{escape(file_name)}</soap:FileName>{_TAIL}'
