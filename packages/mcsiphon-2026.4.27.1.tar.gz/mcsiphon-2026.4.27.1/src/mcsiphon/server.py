"""FastMCP server exposing CUCM 15 Trace Collection as 8 tools."""
import os
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from importlib.metadata import version as _pkg_version
from pathlib import Path

from dotenv import load_dotenv
from fastmcp import FastMCP
from platformdirs import user_cache_dir

from . import envelopes, sdl_to_siplt, ssh_capture
from .client import TctClient

load_dotenv()

_NS = {
    "ns1": "http://schemas.cisco.com/ast/soap",
    "soapenv": "http://schemas.xmlsoap.org/soap/envelope/",
}

mcp = FastMCP("CUCM TCT (read-only)")

# Lazily initialized so `import mcsiphon.server` doesn't blow up when
# env vars aren't set (CLI --help, tests, IDE introspection, etc.).
_client: TctClient | None = None
_cache: Path | None = None


def _get_client() -> tuple[TctClient, Path]:
    global _client, _cache
    if _client is None:
        base = os.environ["TCT_BASE"].rstrip("/")
        user = os.environ["TCT_USER"]
        password = os.environ["TCT_PASS"]
        verify = os.environ.get("TCT_VERIFY_TLS", "true").lower() in ("true", "1", "yes")
        _client = TctClient(base, user, password, verify_tls=verify)
        # Underscore (not hyphen) in the cache subdir — ladder.sh's arg parser
        # silently truncates path values at `-` (decompiled/docs/lessons-learned.md
        # item 8). Anything that ends up in this cache must have a dash-free
        # absolute path.
        _cache = Path(user_cache_dir("mcsiphon")) / "files"
        _cache.mkdir(parents=True, exist_ok=True)
    assert _cache is not None
    return _client, _cache


def _text(elem: ET.Element | None) -> str | None:
    return elem.text if elem is not None else None


@mcp.tool
def health() -> dict:
    """Verify CUCM connectivity + auth by calling getTimeZone.

    Returns the server timezone alongside connection metadata so the LLM
    can confirm everything's wired up before issuing other tools.
    """
    cli, _ = _get_client()
    envelope, _ = cli.call(envelopes.get_time_zone(), "")
    root = ET.fromstring(envelope)
    # Response wraps an HTML-escaped XML payload in <ns1:TimeZone>.
    # We surface the raw inner string — LLM can interpret as needed.
    tz = root.find(".//ns1:TimeZone", _NS)
    _, cache = _get_client()
    return {
        "status": "ok",
        "cucm_base": os.environ["TCT_BASE"].rstrip("/"),
        "user": os.environ["TCT_USER"],
        "tls_verify": os.environ.get("TCT_VERIFY_TLS", "true").lower() in ("true", "1", "yes"),
        "server_time_zone": _text(tz),
        "cache_dir": str(cache),
    }


@mcp.tool
def get_time_zone() -> dict:
    """Return the CUCM server's timezone string."""
    cli, _ = _get_client()
    envelope, _ = cli.call(envelopes.get_time_zone(), "")
    root = ET.fromstring(envelope)
    # Response wraps an HTML-escaped XML payload in <ns1:TimeZone>.
    # We surface the raw inner string — LLM can interpret as needed.
    tz = root.find(".//ns1:TimeZone", _NS)
    return {"time_zone": _text(tz)}


@mcp.tool
def list_node_service_logs() -> dict:
    """Enumerate services available for log collection on each cluster node.

    Returns a dict keyed by node hostname, each value containing two lists:
    `ServiceLog` (per-service trace logs like "Cisco CallManager") and
    `SystemLog` (system-level logs like "Security Logs"). Use service names
    from this output as input to `select_log_files`.
    """
    cli, _ = _get_client()
    envelope, _ = cli.call(envelopes.list_node_service_logs(), "")
    root = ET.fromstring(envelope)
    result: dict[str, dict[str, list[str]]] = {}
    for node in root.iter("{http://schemas.cisco.com/ast/soap}listNodeServiceLogsReturn"):
        name = _text(node.find("ns1:name", _NS))
        if not name:
            continue
        result[name] = {
            "ServiceLog": [
                t for t in (i.text for i in node.findall("ns1:ServiceLog/ns1:item", _NS)) if t
            ],
            "SystemLog": [
                t for t in (i.text for i in node.findall("ns1:SystemLog/ns1:item", _NS)) if t
            ],
        }
    return result


@mcp.tool
def select_log_files(
    services: list[str],
    minutes_back: int = 5,
    search_str: str = "",
    time_zone: str = "UTC",
) -> list[dict]:
    """Find log files matching criteria. Returns metadata only — call
    `get_one_file` per result to download bytes.

    Args:
        services: Service names from `list_node_service_logs`
            (e.g. ["Cisco CallManager"])
        minutes_back: Relative time window in minutes (default 5).
            Smaller windows = less server load.
        search_str: Optional full-text filter applied server-side
        time_zone: Time zone name (default UTC)

    Returns: list of {node, service, name, absolute_path, size_bytes, modified_date}.
        Pass `absolute_path` to `get_one_file` to download.
    """
    cli, _ = _get_client()
    envelope, _ = cli.call(
        envelopes.select_log_files(
            services=services,
            search_str=search_str,
            time_zone=time_zone,
            rel_text="Minutes",
            rel_time=minutes_back,
        ),
        "",
    )
    root = ET.fromstring(envelope)
    results: list[dict] = []
    for node in root.iter("{http://schemas.cisco.com/ast/soap}Node"):
        node_name = _text(node.find("ns1:name", _NS))
        for svc in node.findall("ns1:ServiceList/ns1:ServiceLogs", _NS):
            svc_name = _text(svc.find("ns1:name", _NS))
            for f in svc.findall("ns1:SetOfFiles/ns1:File", _NS):
                results.append(
                    {
                        "node": node_name,
                        "service": svc_name,
                        "name": _text(f.find("ns1:name", _NS)),
                        "absolute_path": _text(f.find("ns1:absolutepath", _NS)),
                        "size_bytes": _text(f.find("ns1:filesize", _NS)),
                        "modified_date": _text(f.find("ns1:modifiedDate", _NS)),
                    }
                )
    return results


@mcp.tool
def get_one_file(absolute_path: str, preview_chars: int = 2000) -> dict:
    """Download a single log file from CUCM. Caches to local disk.

    CUCM 15 returns log files **already decompressed**, even when the
    filename advertises `.gz` or `.gzo`. The cached file matches what's
    actually delivered (plain text in the typical case).

    Args:
        absolute_path: From `select_log_files` results (e.g.
            "/var/log/active/cm/trace/ccm/sdl/SDL001_100_000127.txt.gzo")
        preview_chars: Bytes of preview to return inline (default 2000).
            For full-file work, read from `cache_path` directly.

    Returns: {cache_path, size_bytes, line_count, preview}
    """
    cli, cache = _get_client()
    envelope, attachments = cli.call(envelopes.get_one_file(absolute_path), "GetOneFile")
    if not attachments:
        return {"error": "No file content in MTOM response", "envelope_size": len(envelope)}
    content = attachments[-1]
    cache_name = absolute_path.replace("/", "_").lstrip("_")
    cache_path = cache / cache_name
    cache_path.write_bytes(content)
    text = content.decode("utf-8", errors="replace")
    return {
        "cache_path": str(cache_path),
        "size_bytes": len(content),
        "line_count": text.count("\n"),
        "preview": text[:preview_chars],
    }


@mcp.tool
def render_sip_ladder(
    absolute_path: str,
    max_messages: int = 199,
) -> dict:
    """Fetch a CUCM SDL trace and render a SIP call-flow ladder diagram.

    Pipeline: GetOneFile → preprocess (modern SDL → legacy SIPL/SIPT format)
    → invoke RTMT's `HTMLGenerator` headlessly → return paths to the
    generated HTML + PNG.

    Modern CUCM 15 SDL traces have multi-line SIP message blocks that the
    shipped RTMT template can't parse. This tool's preprocessor flattens
    each block into the legacy single-line pipe-delimited format
    `UCM_CTRACE.xml` was designed for, so the existing engine works
    end-to-end without template surgery.

    Requires two env vars:
        RTMT_LADDER_SCRIPT — path to ladder.sh (the wrapper around HTMLGenerator)
        RTMT_TEMPLATE_DIR  — directory containing the CLI-friendly template
                             (typically `<rtmt-base>/clavConfigCli/`)

    Args:
        absolute_path: From `select_log_files` (e.g.
            "/var/log/active/cm/trace/ccm/sdl/SDL001_100_000127.txt.gzo")
        max_messages: Cap on SIP messages to render. RTMT's HTMLGenerator
            silently truncates at 200 messages (CallFlowProcessor.java:355);
            default 199 stays under the cap. Set lower for narrower diagrams.

    Returns: dict with cache_path (raw SDL), siplt_path (converted),
        message_count, render_dir, index_html (for browser viewing),
        ladder_url (file:// URL).
    """
    ladder_script = os.environ.get("RTMT_LADDER_SCRIPT")
    template_dir = os.environ.get("RTMT_TEMPLATE_DIR")
    if not ladder_script or not template_dir:
        return {
            "error": "Set RTMT_LADDER_SCRIPT and RTMT_TEMPLATE_DIR env vars first.",
            "RTMT_LADDER_SCRIPT": ladder_script,
            "RTMT_TEMPLATE_DIR": template_dir,
        }
    if not Path(ladder_script).exists():
        return {"error": f"RTMT_LADDER_SCRIPT not found: {ladder_script}"}
    if not Path(template_dir).is_dir():
        return {"error": f"RTMT_TEMPLATE_DIR not a directory: {template_dir}"}

    # Step 1: download (uses MTOM client + cache)
    cli, cache = _get_client()
    envelope, attachments = cli.call(envelopes.get_one_file(absolute_path), "GetOneFile")
    if not attachments:
        return {"error": "GetOneFile returned no attachment", "envelope_size": len(envelope)}
    # Server returns .gzo files decompressed but .gz files in raw gzip
    raw = sdl_to_siplt.decompress_if_gzip(attachments[-1])
    cache_name = absolute_path.replace("/", "_").lstrip("_")
    cache_path = cache / cache_name
    cache_path.write_text(raw)

    # Step 2: convert to SIPL/SIPT format
    siplt = sdl_to_siplt.convert(raw)
    siplt_lines = siplt.strip().split("\n")
    if max_messages and len(siplt_lines) > max_messages:
        siplt_lines = siplt_lines[:max_messages]
        siplt = "\n".join(siplt_lines) + "\n"
    # Use a dedicated per-render dir so the -filter only matches one file
    # (cache contains many files; ladder.sh's filter is naive substring match)
    render_dir = cache / f"{cache_name}.render"
    render_dir.mkdir(exist_ok=True)
    siplt_input_dir = render_dir / "input"
    siplt_input_dir.mkdir(exist_ok=True)
    # Filename embeds 'siplt' to give the -filter something distinctive
    siplt_path = siplt_input_dir / "trace_siplt.txt"
    siplt_path.write_text(siplt)
    message_count = max(0, len(siplt_lines) - 1)  # subtract sentinel

    # Step 3: render via ladder.sh subprocess
    # H4 + H6: catch TimeoutExpired (Bug 9 in lessons-learned can hang the JVM)
    # and surface stdout too (Java tools often write diagnostics to stdout)
    cmd = [
        ladder_script,
        "-path", str(siplt_input_dir),
        "-temps", template_dir,
        "-filter", "siplt",
        "-out", str(render_dir),
    ]
    timed_out = False
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
        exit_code: int | None = result.returncode
        stdout_tail = (result.stdout or "")[-400:]
        stderr_tail = (result.stderr or "")[-400:]
    except subprocess.TimeoutExpired as exc:
        timed_out = True
        exit_code = None
        stdout_tail = (exc.stdout.decode(errors="replace") if exc.stdout else "")[-400:]
        stderr_tail = (exc.stderr.decode(errors="replace") if exc.stderr else "")[-400:]

    index_html = render_dir / "index.html"
    rendered = index_html.exists()
    return {
        "cache_path": str(cache_path),
        "siplt_path": str(siplt_path),
        "message_count": message_count,
        "render_dir": str(render_dir),
        "index_html": str(index_html) if rendered else None,
        "ladder_url": f"file://{index_html}" if rendered else None,
        "render_exit_code": exit_code,
        "render_stdout_tail": stdout_tail,
        "render_stderr_tail": stderr_tail,
        "render_timed_out": timed_out,
        "error": (
            "Render timed out after 90s (likely Bug 9 — JOptionPane hang on "
            "empty match results). Inspect siplt_path to verify the input "
            "matches the loaded templates."
            if timed_out and not rendered else None
        ),
    }


@mcp.tool
def capture_packets(
    duration_seconds: int = 60,
    interface: str = "eth0",
    host_filter: str = "",
    port_filter: int = 0,
    filename: str = "",
) -> dict:
    """Run `utils network capture` on the CUCM publisher via SSH, wait for
    completion, return the absolute path of the resulting `.cap` file.

    Requires SSH credentials in env (none of these are exposed via other tools):
        CUCM_SSH_USER  — platform admin username (typically "admin")
        CUCM_SSH_PASS  — password (or set CUCM_SSH_KEY for key auth)
        CUCM_SSH_KEY   — path to SSH private key (optional)
        CUCM_SSH_PORT  — SSH port (default 22)
        CUCM_SSH_HOST  — defaults to the hostname from TCT_BASE

    Args:
        duration_seconds: how long to capture (default 60)
        interface: network interface (default eth0)
        host_filter: optional IP to filter on (src OR dst)
        port_filter: optional port to filter on (e.g. 5060 for SIP)
        filename: capture file basename (default auto-generated)

    Returns: dict with success, server_path, filename, command, output_tail.
        After success, try `get_one_file` with the server_path to download —
        but `/var/log/active/platform/cli/` may or may not be exposed via
        the LogCollection service depending on RBAC.
    """
    user = os.environ.get("CUCM_SSH_USER")
    password = os.environ.get("CUCM_SSH_PASS")
    key = os.environ.get("CUCM_SSH_KEY")
    port = int(os.environ.get("CUCM_SSH_PORT", "22"))
    host = os.environ.get("CUCM_SSH_HOST")
    if not host:
        base = os.environ.get("TCT_BASE", "")
        m = re.match(r"https?://([^:/]+)", base)
        host = m.group(1) if m else ""
    if not (user and host):
        return {"error": "Set CUCM_SSH_USER + CUCM_SSH_HOST (or TCT_BASE) env vars."}
    if not (password or key):
        return {"error": "Set CUCM_SSH_PASS or CUCM_SSH_KEY for SSH auth."}

    result = ssh_capture.run_capture(
        host=host,
        user=user,
        password=password,
        key_filename=key,
        port=port,
        interface=interface,
        duration_seconds=duration_seconds,
        host_filter=host_filter or None,
        port_filter=port_filter or None,
        filename=filename or None,
    )
    return {
        "success": result.success,
        "server_path": result.server_path,
        "filename": result.filename,
        "command": result.command,
        "output_tail": result.output[-1000:] if result.output else "",
        "read_status": result.read_status,
        "output_truncated": result.output_truncated,
        "error": result.error,
    }


@mcp.tool
def capture_and_fetch(
    duration_seconds: int = 60,
    interface: str = "eth0",
    host_filter: str = "",
    port_filter: int = 0,
    filename: str = "",
) -> dict:
    """One-shot: SSH-trigger a packet capture on the publisher, wait for it
    to finish, then fetch the resulting `.cap` file via the SOAP API.

    Equivalent to `capture_packets()` followed by `get_one_file()` with the
    returned `server_path`, but returns a single combined result. Use this
    when you want the bytes locally; use `capture_packets()` alone if
    you'd rather leave the file on the server (e.g. for SFTP push).

    Args mirror `capture_packets()`. See that tool for env var requirements.

    Returns:
        cap dict from capture_packets (server_path, command, etc.) + file
        dict from get_one_file (cache_path, size_bytes) merged. Plus a
        `pcap_local_path` shortcut for the most common use case.
    """
    cap = capture_packets(
        duration_seconds=duration_seconds,
        interface=interface,
        host_filter=host_filter,
        port_filter=port_filter,
        filename=filename,
    )
    if not cap.get("success"):
        return {
            "capture": cap,
            "fetch": None,
            "pcap_local_path": None,
            "server_path": cap.get("server_path"),
            "hint": (
                "Capture failed — file is NOT on the server. Inspect "
                "`capture.error` and `capture.output_tail`. If `read_status` "
                "is 'timeout', the command may still be running; retry with "
                "`get_one_file` against `server_path` after a delay."
            ),
        }

    # Small grace period for CUCM to finalize the file after the SSH session
    # closes — observed delay between capture completion and metadata flush
    time.sleep(2)

    try:
        fetched = get_one_file(absolute_path=cap["server_path"], preview_chars=0)
    except Exception as exc:
        # Capture succeeded but fetch failed — file IS on the server.
        # Surface the path so the caller can retry just the fetch step.
        return {
            "capture": cap,
            "fetch": {"error": f"{type(exc).__name__}: {exc}"},
            "pcap_local_path": None,
            "server_path": cap["server_path"],
            "hint": (
                "Capture succeeded but fetch failed. The .cap file IS on the "
                "publisher at `server_path`. Retry with `get_one_file"
                "(absolute_path=server_path)` once the network issue clears."
            ),
        }
    return {
        "capture": cap,
        "fetch": fetched,
        "pcap_local_path": fetched.get("cache_path"),
        "pcap_size_bytes": fetched.get("size_bytes"),
        "server_path": cap["server_path"],
        "hint": None,
    }


def main() -> None:
    try:
        pkg_version = _pkg_version("mcsiphon")
    except Exception:
        pkg_version = "0.1.0"
    print(f"mcsiphon v{pkg_version}", file=sys.stderr)
    # Fail fast if config is missing — better at startup than first tool call
    _, cache = _get_client()
    print(f"  CUCM:       {os.environ['TCT_BASE']}", file=sys.stderr)
    print(f"  User:       {os.environ['TCT_USER']}", file=sys.stderr)
    print(f"  TLS verify: {os.environ.get('TCT_VERIFY_TLS', 'true')}", file=sys.stderr)
    print(f"  Cache:      {cache}", file=sys.stderr)
    mcp.run()


if __name__ == "__main__":
    main()
