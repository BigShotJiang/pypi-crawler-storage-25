"""Convert modern CUCM 15 SDL traces to the legacy SIPL/SIPT pipe-delimited
format that ships with RTMT's UCM_CTRACE.xml template.

Note: CUCM serves `.gzo` files pre-decompressed but `.gz` files in raw gzip.
Use `decompress_if_gzip()` on the MTOM attachment bytes before calling
`convert()`.

The DSL the legacy template uses can't easily be extended to handle
multi-line SIP message blocks (see decompiled/docs/lessons-learned.md
items 6-8 in the rtmt repo). Instead we preprocess.

Modern SDL format (multi-line per SIP message):
    <seq>.<us> |<HH:MM:SS.mmm> |AppInfo  |SIPTcp - wait_SdlSPISignal: Outgoing SIP TCP message to <IP> on port <PORT> index <N>
    [<id>,NET]
    {SIP/2.0 200 OK | INVITE sip:... SIP/2.0}
    Via: ...
    Call-ID: ...
    CSeq: ...
    ...

Legacy SIPL/SIPT format (single line):
    yyyy/MM/dd HH:mm:ss:SSS|SIPL|0|TCP|IN|<local>|<port>|<MAC>|<remote>|<port>|<corr>|<tag>|<guid>|<msg_label>

(SIPL = received, SIPT = transmitted, per Cisco convention. Position 1 is
always the local CUCM, position 5 is the remote endpoint, regardless of
direction. Direction marker controls which side is sender vs receiver.)
"""
import gzip
import re


def decompress_if_gzip(raw: bytes) -> str:
    """Return decompressed text. Detects standard gzip magic and gunzips;
    otherwise decodes the bytes as UTF-8 directly.

    CUCM serves `.gzo` files already-decompressed (proprietary IIS-era
    convention) but `.gz` files in raw gzip. Both filenames appear in
    `selectLogFiles` results, so callers shouldn't have to switch on
    the extension.
    """
    if len(raw) >= 2 and raw[0] == 0x1F and raw[1] == 0x8B:
        return gzip.decompress(raw).decode("utf-8", errors="replace")
    return raw.decode("utf-8", errors="replace")

_FILEHEAD = re.compile(
    r"\|FileHead\s*\|.*?Date:\s*(\d{4}/\d{2}/\d{2}).*?"
    r"HostIPAddress:\s*(?:::ffff:)?([0-9.]+)"
)
_PREFIX_OUT = re.compile(
    r"^[\d.]+\s*\|(\d{2}:\d{2}:\d{2}\.\d{3})\s*\|AppInfo\s*"
    r"\|SIPTcp\s*-\s*wait_SdlSPISignal:\s*Outgoing SIP TCP message to "
    r"([\d.]+) on port (\d+)"
)
_PREFIX_IN = re.compile(
    r"^[\d.]+\s*\|(\d{2}:\d{2}:\d{2}\.\d{3})\s*\|AppInfo\s*"
    r"\|SIPTcp\s*-\s*wait_SdlReadRsp:\s*Incoming SIP TCP message from "
    r"([\d.]+) on port (\d+)"
)
_NET_MARKER = re.compile(r"^\[(\d+),NET\]\s*$")
_SIP_REQUEST = re.compile(r"^([A-Z]+)\s+sip:[^\s]+\s+SIP/2\.0\s*$")
_SIP_RESPONSE = re.compile(r"^SIP/2\.0\s+(\d{3}\s+.+?)\s*$")
_CALL_ID = re.compile(r"^Call-ID:\s*(.+?)\s*$", re.IGNORECASE)
_NEXT_TRACE = re.compile(r"^\d+\.\d+\s*\|\d{2}:\d{2}:\d{2}\.\d{3}\s*\|")


def convert(raw: str, default_date: str = "2000/01/01", default_local: str = "127.0.0.1") -> str:
    """Convert raw SDL trace text to SIPL/SIPT lines.

    Returns the converted text (one SIPL/SIPT line per SIP message). The
    output is ready to feed `ladder.sh` with the shipped UCM_CTRACE.xml
    template.
    """
    lines = raw.splitlines()
    n = len(lines)

    # Pull date + local CUCM IP from the first FileHead (file may have multiple)
    date, local_ip = default_date, default_local
    for line in lines[:50]:
        m = _FILEHEAD.search(line)
        if m:
            date, local_ip = m.group(1), m.group(2)
            break

    out: list[str] = []
    i = 0
    while i < n:
        line = lines[i]
        m_out = _PREFIX_OUT.search(line)
        m_in = _PREFIX_IN.search(line) if not m_out else None
        if not (m_out or m_in):
            i += 1
            continue

        direction = "OUT" if m_out else "IN"
        match = m_out or m_in
        timestamp, remote_ip, remote_port = match.group(1), match.group(2), match.group(3)
        i += 1

        # Skip blanks, find [xxx,NET] marker
        msg_id = ""
        while i < n and not lines[i].strip():
            i += 1
        if i < n:
            mm = _NET_MARKER.match(lines[i])
            if mm:
                msg_id = mm.group(1)
                i += 1

        # Skip blanks, parse SIP request or response line
        msg_label = "?"
        while i < n and not lines[i].strip():
            i += 1
        if i < n:
            req = _SIP_REQUEST.match(lines[i])
            resp = _SIP_RESPONSE.match(lines[i])
            if req:
                msg_label = req.group(1)
                i += 1
            elif resp:
                msg_label = resp.group(1).strip()
                i += 1

        # Scan headers for Call-ID until blank or next trace line
        call_id = ""
        while i < n:
            ln = lines[i]
            if _NEXT_TRACE.match(ln):
                break
            if not ln.strip():
                i += 1
                continue
            mci = _CALL_ID.match(ln)
            if mci and not call_id:
                call_id = mci.group(1)
            i += 1

        # Build the SIPL/SIPT line
        # Position 1 = local CUCM, position 5 = remote (for both IN and OUT)
        sip_tag = "SIPL" if direction == "IN" else "SIPT"
        date_time = f"{date} {timestamp.replace('.', ':')}"
        # Each SIP message gets a unique MSGTAG — sequential index avoids the
        # hidden last-line-drop dedup behavior we couldn't fully characterize
        msgtag = f"m{len(out):05d}"
        corr = msg_id or "0"
        guid = call_id or f"no-callid-{len(out)}"
        # MAC field is empty (modern SDL doesn't include device MAC in prefix)
        line_out = (
            f"{date_time}|{sip_tag}|0|TCP|{direction}|"
            f"{local_ip}|0||{remote_ip}|{remote_port}|"
            f"{corr}|{msgtag}|{guid}|{msg_label}"
        )
        out.append(line_out)

    # Append a sentinel — HTMLGenerator silently drops the last line
    # (decompiled/docs/lessons-learned.md item 7).
    #
    # H5 (Hamilton review): the previous implementation tried to clone the
    # last line and substitute the MSG_LABEL with "EOF_SENTINEL" via a
    # str.replace — but `str.replace` mutates ALL occurrences, so a
    # MSG_LABEL value that appeared elsewhere in the line (CallID substring
    # match, etc.) would corrupt the sentinel. And if the substitution
    # didn't happen, the sentinel was a real-looking SIP message that
    # rendered as a spurious arrow.
    #
    # Build the sentinel from scratch with safe placeholders. Same field
    # count and pipe positions; matches the legacy SIPL/SIPT shape so the
    # parser consumes (and then discards) it. Last field is unmistakably
    # not a SIP method/response.
    if out:
        sentinel_ts = f"{default_date} 00:00:00:000"
        sentinel = (
            f"{sentinel_ts}|SIPL|0|TCP|IN|"
            f"sentinel|0||sentinel|0|"
            f"sentinel|sentinel|sentinel|EOF_SENTINEL_DROP_ME"
        )
        out.append(sentinel)

    return "\n".join(out) + "\n"
