"""GeoSpark Utilities."""
