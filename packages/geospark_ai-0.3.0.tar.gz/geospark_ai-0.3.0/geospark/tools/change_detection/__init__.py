"""Change detection tools."""
