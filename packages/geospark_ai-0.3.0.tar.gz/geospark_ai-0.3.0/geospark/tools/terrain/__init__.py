"""Terrain analysis tools."""
