"""GeoSpark test suite."""
