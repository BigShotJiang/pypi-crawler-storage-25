from collections import Counter

import numpy as np
import pandas as pd
from numpy.typing import NDArray
from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KernelDensity

from generalized_naive_bayes._core import fast_entropy


def calculate_argmax_indices(matrix: NDArray[np.float64]) -> tuple[int]:
    """
    Calculate maximum indices of a matrix.

    Parameters
    ----------
    matrix : NDArray[np.float64]
        Matrix to find the maximum indices.

    Returns
    -------
    tuple[int]
        Indices of the maximum value in the matrix.
    """
    indices = np.unravel_index(np.argmax(matrix, axis=None), matrix.shape)
    converted_indices = tuple(int(i) for i in indices)
    return converted_indices


def get_duplicated_features(feature_pairs: list[tuple[int, int]]) -> Counter:
    """
    Calculate duplicated features.

    Parameters
    ----------
    feature_pairs : list[tuple[int, int]]
        List of feature pairs.
        [(1, 2), (2, 3), ...]

    Returns
    -------
    Counter
        Duplicated feature pairs.
    """
    seen = set()
    result = Counter()
    for tup in feature_pairs:
        for item in tup:
            int_item = int(item)
            if int_item in seen:
                result[int_item] += 1
            else:
                seen.add(int_item)
    return result


def find_optimal_bandwidth(X_data):  # pragma: no cover
    """
    Finds the optimal bandwidth for KDE using 5-fold cross-validation.

    Args:
        X_data (np.array): Data array. Shape (n_samples, n_features).

    Returns:
        float: The optimal bandwidth value.
    """
    if X_data.ndim == 1:
        X_data = X_data.reshape(-1, 1)
    bandwidths = {"bandwidth": np.logspace(-0.75, 0.75, 20)}
    grid = GridSearchCV(KernelDensity(kernel="gaussian"), param_grid=bandwidths, cv=3)
    grid.fit(X_data)
    return float(grid.best_params_["bandwidth"])


def quantile_discretize_feature(
    feature: NDArray[np.float64], n_bins: int
) -> NDArray[np.int64]:
    """
    Discretizes a continuous feature into quantile-based bins.

    Parameters
    ----------
    feature : NDArray[np.float64]
        Continuous feature array.
    n_bins : int
        Number of bins to discretize into.

    Returns
    -------
    NDArray[np.int64]
        Discretized feature array.
    """
    binned_feature = pd.qcut(feature, q=n_bins, labels=False, duplicates="drop") + 1
    return binned_feature


def uniform_discretize_feature(
    feature: NDArray[np.float64], n_bins: int
) -> NDArray[np.int64]:
    """
    Discretizes a continuous feature into uniform-width bins.

    Parameters
    ----------
    feature : NDArray[np.float64]
        Continuous feature array.
    n_bins : int
        Number of bins to discretize into.

    Returns
    -------
    NDArray[np.int64]
        Discretized feature array.
    """
    binned_feature = np.digitize(
        feature,
        bins=np.linspace(feature.min(), feature.max(), n_bins + 1),
    )
    return binned_feature


# def entropy(labels):
#     """Computes entropy of label distribution."""
#     n_labels = len(labels)
#     if n_labels <= 1:
#         return 0.0

#     _, counts = np.unique(labels, return_counts=True, axis=0)
#     probs = counts / n_labels

#     return -np.sum(probs * np.log2(probs))


def entropy(labels):
    return fast_entropy(labels)


def analyse_running_info_matrix(model):  # pragma: no cover
    """
    Calculates the running sum of matrix edges, subtracting vector penalties
    for duplicate node occurrences efficiently.
    """
    running_sum = 0.0
    node_counts = {}

    results = []
    subtraction = []

    for i, (u, v) in enumerate(model.feature_pairs_):
        edge_val = model.total_correlation_matrix[u, v]
        running_sum += edge_val

        if u in node_counts:
            penalty = model.mutual_info_vector[u]
            running_sum -= penalty
            subtraction.append(u)
        node_counts[u] = node_counts.get(u, 0) + 1

        if v in node_counts:
            penalty = model.mutual_info_vector[v]
            running_sum -= penalty
            subtraction.append(v)
        node_counts[v] = node_counts.get(v, 0) + 1

        results.append(running_sum)

    return np.array(results), np.array(subtraction)
