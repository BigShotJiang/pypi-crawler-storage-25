import math
import textwrap
from typing import List, Optional, Tuple

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import seaborn as sns
from numpy.typing import NDArray
from scipy.stats import multivariate_normal, norm

from generalized_naive_bayes import GeneralizedNaiveBayesClassifier


def plot_1d_gaussian_diagnostics(
    uni_means: NDArray[np.float64],
    uni_vars: NDArray[np.float64],
    X: NDArray[np.float64],
    y: NDArray[np.float64],
    classes: NDArray[np.int64],
    X_test: Optional[NDArray[np.float64]] = None,
) -> None:
    """
    Generates diagnostic plots for univariate Gaussian fits, with an option
    to highlight unlabeled test data and its density on each class curve.

    This function creates a grid of subplots for each feature. Each plot shows:
    - The Gaussian PDF for each class.
    - A rug plot of the training data for each class.
    - If X_test is provided, a rug plot of the test data is shown in black.
    - For each test point, an 'x' marker is placed on each class's density
      curve, showing the probability density assigned to that point.

    Parameters
    ----------
    uni_means : NDArray[np.float64]
        Mean of each feature for each class, shape (n_classes, n_features).
    uni_vars : NDArray[np.float64]
        Variance of each feature for each class, shape (n_classes, n_features).
    X : NDArray[np.float64]
        Input feature matrix for training.
    y : NDArray[np.float64]
        Target labels array for training data.
    classes : NDArray[np.int64]
        Array of unique class labels.
    X_test : Optional[NDArray[np.float64]], default=None
        An optional array of unlabeled test data (can be 1D for a single sample
        or 2D for multiple samples) to highlight on the plots.

    Returns
    -------
    None
    """
    num_features = X.shape[1]
    colors = sns.color_palette("tab10", len(classes))

    # Ensure X_test is 2D for consistent processing
    if X_test is not None and X_test.ndim == 1:
        X_test = X_test.reshape(1, -1)

    num_cols = 3
    num_rows = math.ceil(num_features / num_cols)
    fig, axes = plt.subplots(
        num_rows, num_cols, figsize=(14, 4 * num_rows), squeeze=False
    )
    axes = axes.flatten()

    for feat_idx in range(num_features):
        ax = axes[feat_idx]

        # Determine plot range from all data
        all_data = [X[:, feat_idx]]
        if X_test is not None:
            all_data.append(X_test[:, feat_idx])
        x_min = np.concatenate(all_data).min()
        x_max = np.concatenate(all_data).max()
        x_range = np.linspace(x_min, x_max, 200)

        # Plot training data distributions
        for cls_idx, cls in enumerate(classes):
            mean = uni_means[cls_idx, feat_idx]
            std_dev = np.sqrt(uni_vars[cls_idx, feat_idx])
            density = norm.pdf(x_range, mean, std_dev)
            ax.plot(x_range, density, color=colors[cls_idx], label=f"Class {cls}")
            ax.fill_between(x_range, density, color=colors[cls_idx], alpha=0.2)
            feature_data = X[y == cls][:, feat_idx]
            sns.rugplot(feature_data, ax=ax, color=colors[cls_idx], height=0.05)

        # Highlight test data points and their densities
        if X_test is not None:
            sns.rugplot(
                X_test[:, feat_idx], ax=ax, color="black", height=0.07, linewidth=1.5
            )
            for test_sample in X_test:
                test_val = test_sample[feat_idx]
                for cls_idx, _ in enumerate(classes):
                    mean = uni_means[cls_idx, feat_idx]
                    std_dev = np.sqrt(uni_vars[cls_idx, feat_idx])
                    density_at_point = norm.pdf(test_val, mean, std_dev)
                    # Use a scatter plot to place an 'x' on the density curve
                    ax.scatter(
                        test_val,
                        density_at_point,
                        marker="x",
                        color=colors[cls_idx],
                        s=60,  # Size of the marker
                        linewidths=1.5,
                        zorder=5,  # Ensure marker is on top
                    )

        # Final plot styling
        ax.set_title(f"Feature {feat_idx} Density Comparison")
        ax.set_xlabel(f"Feature {feat_idx} Value")
        ax.set_ylabel("Density")
        ax.grid(True, which="both", linestyle="--", linewidth=0.5, alpha=0.6, zorder=0)

        # Create custom legend
        handles, labels = ax.get_legend_handles_labels()
        if X_test is not None:
            # Create a handle for the rug plot
            handles.append(plt.Line2D([0], [0], color="black", lw=2, label="Test Data"))
            # Create a handle for the 'x' markers
            handles.append(
                plt.Line2D(
                    [0],
                    [0],
                    linestyle="None",
                    marker="x",
                    color="gray",
                    markersize=8,
                    label="Test Point Density",
                )
            )
        ax.legend(handles=handles)

    for i in range(num_features, len(axes)):
        axes[i].axis("off")

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    fig.suptitle("Multi-Class Gaussian Diagnostic Plots per Feature", fontsize=18)
    plt.show()


def plot_2d_gaussian_diagnostics(
    multi_means: NDArray[np.float64],
    multi_cov: NDArray[np.float64],
    X: NDArray[np.float64],
    y: NDArray[np.float64],
    classes: NDArray[np.int64],
    nodes: List[Tuple[int, int]],
    X_test: Optional[NDArray[np.float64]] = None,
) -> None:
    """
    Generates 2D diagnostic plots for multivariate Gaussian fits.

    For each specified feature pair (node), this function visualizes the fitted
    2D Gaussian distributions for each class using contour plots. It overlays
    the training data and can also highlight the position of unlabeled test points.

    Parameters
    ----------
    multi_means : NDArray[np.float64]
        Mean vectors for each class and node pair, from _fit_multivariate_gaussians.
        Shape: (n_classes, n_nodes, 2).
    multi_cov : NDArray[np.float64]
        Covariance matrices for each class and node pair.
        Shape: (n_classes, n_nodes, 2, 2).
    X : NDArray[np.float64]
        Input feature matrix for training.
    y : NDArray[np.float64]
        Target labels array for training data.
    classes : NDArray[np.int64]
        Array of unique class labels.
    nodes : list[tuple[int, int]]
        List of tuples representing feature pairs to plot.
    X_test : Optional[NDArray[np.float64]], default=None
        An optional array of unlabeled test data (can be 1D for a single sample
        or 2D for multiple samples) to highlight on the plots.
    """
    sns.set_style("whitegrid")
    num_nodes = len(nodes)
    colors = sns.color_palette("tab10", len(classes))

    # Ensure X_test is 2D for consistent processing
    if X_test is not None and X_test.ndim == 1:
        X_test = X_test.reshape(1, -1)

    num_cols = 3
    num_rows = math.ceil(num_nodes / num_cols)
    fig, axes = plt.subplots(
        num_rows, num_cols, figsize=(14, 4 * num_rows), squeeze=False
    )
    axes = axes.flatten()

    for node_idx, node in enumerate(nodes):
        ax = axes[node_idx]
        feat1, feat2 = node

        # Determine plot boundaries from all available data
        x_data = [X[:, feat1]]
        y_data = [X[:, feat2]]
        if X_test is not None:
            x_data.append(X_test[:, feat1])
            y_data.append(X_test[:, feat2])
        x_min, x_max = np.concatenate(x_data).min(), np.concatenate(x_data).max()
        y_min, y_max = np.concatenate(y_data).min(), np.concatenate(y_data).max()

        # Add a small margin to the plot boundaries
        x_margin = (x_max - x_min) * 0.05
        y_margin = (y_max - y_min) * 0.05

        # Create a grid of points
        xx, yy = np.mgrid[
            x_min - x_margin : x_max + x_margin : 100j,
            y_min - y_margin : y_max + y_margin : 100j,
        ]
        positions = np.vstack([xx.ravel(), yy.ravel()])

        for cls_idx, cls in enumerate(classes):
            # Get pre-fitted parameters
            mean_vector = multi_means[cls_idx, node_idx]
            cov_matrix = multi_cov[cls_idx, node_idx]

            # Calculate PDF on the grid
            try:
                rv = multivariate_normal(mean=mean_vector, cov=cov_matrix)
                zz = np.reshape(rv.pdf(positions.T), xx.shape)
            except np.linalg.LinAlgError:
                # Skip if covariance matrix is singular
                continue

            # Calculate meaningful contour levels based on cumulative mass
            sorted_levels = np.sort(zz.ravel())
            cumulative_mass = np.cumsum(sorted_levels)
            normalized_mass = cumulative_mass / cumulative_mass[-1]
            iso_proportions = np.linspace(0, 1, 8)[1:]
            level_values = np.interp(iso_proportions, normalized_mass, sorted_levels)

            # Plot contours
            ax.contourf(
                xx,
                yy,
                zz,
                levels=level_values,
                colors=[colors[cls_idx]],
                alpha=0.2,
                zorder=1,
            )
            ax.contour(
                xx,
                yy,
                zz,
                levels=level_values,
                colors=[colors[cls_idx]],
                linewidths=0.5,
                zorder=1,
            )

            # Plot training data points
            X_cls = X[y == cls]
            ax.scatter(
                X_cls[:, feat1],
                X_cls[:, feat2],
                color=colors[cls_idx],
                s=15,
                alpha=0.9,
                label=f"Class {cls}",
                zorder=2,
            )

        # Plot test data points
        if X_test is not None:
            ax.scatter(
                X_test[:, feat1],
                X_test[:, feat2],
                color="black",
                marker="X",
                s=50,
                linewidths=1,
                label="Test Data",
                zorder=5,
            )

        ax.set_title(f"Node {node} Density Comparison")
        ax.set_xlabel(f"Feature {feat1} Value")
        ax.set_ylabel(f"Feature {feat2} Value")
        ax.legend()
        ax.grid(True, which="both", linestyle="--", linewidth=0.5, alpha=0.5, zorder=0)

    # Turn off any unused subplots
    for i in range(num_nodes, len(axes)):
        axes[i].axis("off")

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    fig.suptitle("2D Gaussian Diagnostic Plots per Feature Pair", fontsize=18)
    plt.show()


def plot_2d_kde_diagnostics(
    kde_fits: dict,
    X: NDArray[np.float64],
    y: NDArray[np.float64],
    classes: NDArray[np.int64],
    nodes: List[Tuple[int, int]],
    X_test: Optional[NDArray[np.float64]] = None,
) -> None:
    """
    Generates 2D diagnostic plots from pre-fitted multivariate KDE objects,
    with an option to highlight unlabeled test data.

    Parameters
    ----------
    kde_fits : dict
        A nested dictionary from `_get_multi_kde_fits` where keys are
        class index, then the node's integer index.
    X : NDArray[np.float64]
        Input feature matrix for training.
    y : NDArray[np.float64]
        Target labels array for training data.
    classes : NDArray[np.int64]
        Array of unique class labels.
    nodes : list[tuple[int, int]]
        List of tuples representing feature pairs.
    X_test : Optional[NDArray[np.float64]], default=None
        An optional array of unlabeled test data (can be 1D for a single sample
        or 2D for multiple samples) to highlight on the plots.

    Returns
    -------
    None
    """
    sns.set_style("whitegrid")
    num_nodes = len(nodes)
    colors = sns.color_palette("tab10", len(classes))

    # Ensure X_test is 2D for consistent processing
    if X_test is not None and X_test.ndim == 1:
        X_test = X_test.reshape(1, -1)

    num_cols = 3
    num_rows = math.ceil(num_nodes / num_cols)
    fig, axes = plt.subplots(
        num_rows, num_cols, figsize=(14, 4 * num_rows), squeeze=False
    )
    axes = axes.flatten()

    for node_idx, node in enumerate(nodes):
        ax = axes[node_idx]
        feat1, feat2 = node

        # Determine plot boundaries from all available data
        x_data = [X[:, feat1]]
        y_data = [X[:, feat2]]
        if X_test is not None:
            x_data.append(X_test[:, feat1])
            y_data.append(X_test[:, feat2])
        x_min, x_max = np.concatenate(x_data).min(), np.concatenate(x_data).max()
        y_min, y_max = np.concatenate(y_data).min(), np.concatenate(y_data).max()

        # Add a small margin to the plot boundaries
        x_margin = (x_max - x_min) * 0.05
        y_margin = (y_max - y_min) * 0.05

        # Create a grid of points
        xx, yy = np.mgrid[
            x_min - x_margin : x_max + x_margin : 100j,
            y_min - y_margin : y_max + y_margin : 100j,
        ]
        positions = np.vstack([xx.ravel(), yy.ravel()])

        for cls_idx, cls in enumerate(classes):
            if node_idx in kde_fits.get(cls_idx, {}):
                kde = kde_fits[cls_idx][node_idx]
                zz = np.reshape(kde(positions).T, xx.shape)

                # Calculate meaningful contour levels based on cumulative mass
                sorted_levels = np.sort(zz.ravel())
                cumulative_mass = np.cumsum(sorted_levels)
                normalized_mass = cumulative_mass / cumulative_mass[-1]
                iso_proportions = np.linspace(0, 1, 8)[1:]

                level_values = np.interp(
                    iso_proportions, normalized_mass, sorted_levels
                )
                ax.contourf(
                    xx,
                    yy,
                    zz,
                    levels=level_values,
                    colors=[colors[cls_idx]],
                    alpha=0.2,
                    zorder=1,
                )
                ax.contour(
                    xx,
                    yy,
                    zz,
                    levels=level_values,
                    colors=[colors[cls_idx]],
                    linewidths=0.5,
                    zorder=1,
                )

            # Plot training data points
            X_cls = X[y == cls]
            ax.scatter(
                X_cls[:, feat1],
                X_cls[:, feat2],
                color=colors[cls_idx],
                s=15,
                alpha=0.9,
                label=f"Class {cls}",
                zorder=2,
            )

        # Plot test data points
        if X_test is not None:
            ax.scatter(
                X_test[:, feat1],
                X_test[:, feat2],
                color="black",
                marker="X",
                s=50,
                linewidths=1,
                label="Test Data",
                zorder=5,
            )

        ax.set_title(f"Node {node} Density Comparison")
        ax.set_xlabel(f"Feature {feat1} Value")
        ax.set_ylabel(f"Feature {feat2} Value")
        ax.legend()
        ax.grid(True, which="both", linestyle="--", linewidth=0.5, alpha=0.5, zorder=0)

    # Turn off any unused subplots
    for i in range(num_nodes, len(axes)):
        axes[i].axis("off")

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    fig.suptitle("2D KDE Diagnostic Plots per Feature Pair", fontsize=18)
    plt.show()


def plot_1d_kde_diagnostics(
    kde_fits: dict,
    X: NDArray[np.float64],
    y: NDArray[np.float64],
    classes: NDArray[np.int64],
    X_test: Optional[NDArray[np.float64]] = None,
) -> None:
    """
    Generates diagnostic plots for Kernel Density Estimation (KDE) fits,
    with an option to highlight unlabeled test data and its density.

    This function creates a grid of subplots for each feature. Each plot shows:
    - The KDE curve for each class.
    - A rug plot of the training data.
    - If X_test is provided, a rug plot of the test data is shown in black,
      and an 'x' marker is placed on each density curve showing the
      probability density assigned to that test point.

    Parameters
    ----------
    kde_fits : dict
        A nested dictionary of fitted gaussian_kde objects.
    X : NDArray[np.float64]
        Input feature matrix for training.
    y : NDArray[np.float64]
        Target labels array for training data.
    classes : NDArray[np.int64]
        Array of unique class labels.
    X_test : Optional[NDArray[np.float64]], default=None
        An optional array of unlabeled test data (can be 1D for a single sample
        or 2D for multiple samples) to highlight on the plots.

    Returns
    -------
    None
    """
    num_features = X.shape[1]
    colors = sns.color_palette("tab10", len(classes))

    # Ensure X_test is 2D for consistent processing
    if X_test is not None and X_test.ndim == 1:
        X_test = X_test.reshape(1, -1)

    num_cols = 3
    num_rows = math.ceil(num_features / num_cols)
    fig, axes = plt.subplots(
        num_rows, num_cols, figsize=(14, 4 * num_rows), squeeze=False
    )
    axes = axes.flatten()

    for feat_idx in range(num_features):
        ax = axes[feat_idx]

        # Determine plot range from all data
        all_data = [X[:, feat_idx]]
        if X_test is not None:
            all_data.append(X_test[:, feat_idx])
        x_min = np.concatenate(all_data).min()
        x_max = np.concatenate(all_data).max()
        x_range = np.linspace(x_min, x_max, 200)

        # Plot training data distributions
        for cls_idx, cls in enumerate(classes):
            if feat_idx in kde_fits.get(cls_idx, {}):
                kde = kde_fits[cls_idx][feat_idx]
                density = kde(x_range)

                ax.plot(x_range, density, color=colors[cls_idx], label=f"Class {cls}")
                ax.fill_between(x_range, density, color=colors[cls_idx], alpha=0.2)

                feature_data = X[y == cls][:, feat_idx]
                sns.rugplot(feature_data, ax=ax, color=colors[cls_idx], height=0.05)

        # Highlight test data points and their densities
        if X_test is not None:
            sns.rugplot(
                X_test[:, feat_idx], ax=ax, color="black", height=0.07, linewidth=1.5
            )
            for test_sample in X_test:
                test_val = test_sample[feat_idx]
                for cls_idx, _ in enumerate(classes):
                    if feat_idx in kde_fits.get(cls_idx, {}):
                        kde = kde_fits[cls_idx][feat_idx]
                        density_at_point = kde(test_val)
                        ax.scatter(
                            test_val,
                            density_at_point,
                            marker="x",
                            color=colors[cls_idx],
                            s=60,
                            linewidths=1.5,
                            zorder=5,
                        )

        # Final plot styling and custom legend
        ax.set_title(f"Feature {feat_idx} Density Comparison")
        ax.set_xlabel(f"Feature {feat_idx} Value")
        ax.set_ylabel("Density")
        ax.grid(True, which="both", linestyle="--", linewidth=0.5, alpha=0.6, zorder=0)

        handles, labels = ax.get_legend_handles_labels()
        if X_test is not None:
            handles.append(plt.Line2D([0], [0], color="black", lw=2, label="Test Data"))
            handles.append(
                plt.Line2D(
                    [0],
                    [0],
                    linestyle="None",
                    marker="x",
                    color="gray",
                    markersize=8,
                    label="Test Point Density",
                )
            )
        ax.legend(handles=handles)

    for i in range(num_features, len(axes)):
        axes[i].axis("off")

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    fig.suptitle("Multi-Class KDE Diagnostic Plots per Feature", fontsize=18)
    plt.show()


def plot_feature_importance(
    model: GeneralizedNaiveBayesClassifier,
    column_names: Optional[List[str]] = None,
    ax: Optional[plt.Axes] = None,
    figsize: Tuple[int, int] = (10, 7),
    title: str = "Feature Importance based on Mutual Information",
) -> Tuple[plt.Figure, plt.Axes]:
    """
    Generates and displays a styled plot of feature importances.

    This function creates a horizontal bar chart to visualize the importance
    of each feature, sorted in descending order. It offers customization
    options for the plot title and size and can be integrated into
    existing subplots by passing an `Axes` object.

    Parameters
    ----------
    model : GeneralizedNaiveBayesClassifier
        An instance of GeneralizedNaiveBayesClassifier that has been fitted.
    column_names : Optional[List[str]], default=None
        A list of names for the features. If None, features will be
        labeled by their index.
    ax : Optional[plt.Axes], default=None
        The matplotlib Axes object to draw the plot on. If None, a new
        figure and axes are created.
    figsize : Tuple[int, int], default=(10, 7)
        The size of the figure to create if `ax` is not provided.
    title : str, default='Feature Importance based on Mutual Information'
        The title for the plot.

    Returns
    -------
    Tuple[plt.Figure, plt.Axes]
        A tuple containing the matplotlib Figure and Axes objects used for
        the plot, allowing for further customization.

    Raises
    ------
    ValueError
        If the model has not been fitted yet or if the feature type is
        not 'gaussian'.
    """
    if model.classes_ is None:
        raise ValueError("Model has not been fitted yet.")

    if model.input_features_type != "gaussian":
        raise ValueError(
            "Feature importance is only available for 'gaussian' feature type."
        )

    feature_importance = model.get_feature_importance()

    # Prepare feature names
    if column_names is None:
        feature_names = [f"Feature {i}" for i in range(len(feature_importance))]
    else:
        if len(column_names) != len(feature_importance):
            raise ValueError(
                "Length of column_names must match the number of features."
            )
        # feature_names = column_names
        feature_names = [f"{name} ({i})" for i, name in enumerate(column_names)]

    sorted_indices = np.argsort(feature_importance)
    sorted_importance = feature_importance[sorted_indices]
    sorted_names = [feature_names[i] for i in sorted_indices]

    # Create figure and axes if not provided
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.get_figure()

    colors = sns.color_palette("viridis", n_colors=len(sorted_importance))
    bars = ax.barh(range(len(sorted_importance)), sorted_importance, color=colors)

    for bar in bars:
        width = bar.get_width()
        ax.text(
            width + (ax.get_xlim()[1] * 0.01),
            bar.get_y() + bar.get_height() / 2,
            f"{width:.4f}",
            va="center",
            ha="left",
            fontsize=9,
        )

    ax.set_yticks(range(len(sorted_importance)))
    ax.set_yticklabels(sorted_names)
    ax.set_title(title, fontsize=16, pad=20)
    ax.set_xlabel("Importance Score", fontsize=12)
    ax.set_ylabel("Feature", fontsize=12)
    ax.grid(True, which="major", axis="x", linestyle="--", linewidth=0.5, alpha=0.7)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)

    ax.set_xlim(right=ax.get_xlim()[1] * 1.15)

    fig.tight_layout()

    return fig, ax


def visualize_arborescence(
    graph: nx.DiGraph,
    dmst_graph: nx.DiGraph,
    column_names: list[str] | None = None,
    random_seed: int = 45,
    figsize: tuple[int, int] = (16, 8),
) -> None:
    """
    Visualize the original directed graph and its Maximum Spanning Arborescence.

    Parameters
    ----------
    graph : nx.DiGraph
        The original directed graph with weighted edges.
    dmst_graph : nx.DiGraph
        The directed maximum spanning tree (DMST) / maximum spanning arborescence.
    column_names : list[str], optional
        A list of feature names corresponding to the node indices.
        Length must match the number of nodes.
    random_seed : int, default=45
        Seed for the spring layout algorithm to ensure reproducible node positioning.
    figsize : tuple[int, int], default=(16, 8)
        The dimensions of the matplotlib figure.

    Raises
    ------
    ValueError
        If the length of `column_names` does not match the number of nodes.
    """
    if column_names is not None:
        if len(column_names) != len(graph.nodes):
            raise ValueError(
                f"The length of 'column_names' ({len(column_names)}) must exactly "
                f"match the number of nodes in the graph ({len(graph.nodes)})."
            )

        # Wrap text to max 15 characters per line
        wrapped_names = [textwrap.fill(name, width=15) for name in column_names]
        mapping = {i: name for i, name in enumerate(wrapped_names)}

        graph = nx.relabel_nodes(graph, mapping)
        dmst_graph = nx.relabel_nodes(dmst_graph, mapping)

    pos = nx.spring_layout(graph, seed=random_seed)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)
    ax1.margins(0.20)
    ax2.margins(0.20)

    bbox_style = dict(boxstyle="round,pad=0.3", fc="white", ec="gray", alpha=0.9)

    # --- Plot 1: Original Graph ---
    ax1.set_title("Original Directed Graph", fontsize=14, pad=20)
    nx.draw(
        graph,
        pos,
        ax=ax1,
        with_labels=True,
        node_color="lightblue",
        node_size=2500,
        font_size=11,
        font_weight="bold",
        arrows=True,
        connectionstyle="arc3, rad=0.1",
    )

    raw_edge_labels = nx.get_edge_attributes(graph, "weight")
    orig_labels = {
        k[:2]: f"{str(k[0]).replace(chr(10), ' ')} → "
        f"{str(k[1]).replace(chr(10), ' ')}\n{weight:.4f}"
        for k, weight in raw_edge_labels.items()
    }
    nx.draw_networkx_edge_labels(
        graph,
        pos,
        ax=ax1,
        edge_labels=orig_labels,
        label_pos=0.75,
        rotate=False,
        font_size=8,
        bbox=bbox_style,
    )

    # --- Plot 2: DMST ---
    ax2.set_title("Maximum Spanning Arborescence (DMST)", fontsize=14, pad=20)
    nx.draw(
        dmst_graph,
        pos,
        ax=ax2,
        with_labels=True,
        node_color="lightgreen",
        node_size=2500,
        font_size=11,
        font_weight="bold",
        arrows=True,
    )

    raw_dmst_labels = nx.get_edge_attributes(dmst_graph, "weight")
    dmst_labels = {k[:2]: f"{weight:.4f}" for k, weight in raw_dmst_labels.items()}
    nx.draw_networkx_edge_labels(
        dmst_graph, pos, ax=ax2, edge_labels=dmst_labels, font_size=10, bbox=bbox_style
    )

    plt.tight_layout()
    plt.show()
