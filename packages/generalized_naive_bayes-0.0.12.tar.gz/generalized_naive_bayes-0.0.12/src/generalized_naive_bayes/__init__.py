from generalized_naive_bayes.core.classifier import GeneralizedNaiveBayesClassifier

__all__ = ["GeneralizedNaiveBayesClassifier"]
