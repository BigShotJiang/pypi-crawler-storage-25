import warnings
from collections import Counter
from itertools import combinations_with_replacement
from typing import Literal

import networkx as nx
import numpy as np
from numpy.typing import NDArray
from scipy.stats import gaussian_kde

from generalized_naive_bayes.utils import (
    calculate_argmax_indices,
    entropy,
    get_duplicated_features,
    quantile_discretize_feature,
    uniform_discretize_feature,
)


class GeneralizedNaiveBayesClassifier:
    def __init__(
        self,
        input_features_type: Literal["general", "gaussian"] = "general",
        feature_pair_selection: Literal["base", "dmst"] = "dmst",
    ) -> None:
        """
        Initialize the Gaussian Naive Bayes classifier.

        Parameters
        ----------
        input_features_type : str, optional
            Type of input features, either 'general' or 'gaussian'.
            Default is 'general'.
        feature_pair_selection : str, optional
            Method for selecting feature pairs, either 'base' or 'dmst'.
            dmst stands for "Directed Maximum Spanning Tree", which is a more
            sophisticated method for determining feature dependencies.
            Default is 'dmst'.

        Returns
        -------
        None
        """
        self.eps = np.finfo(np.float64).eps
        self.input_features_type = input_features_type
        self.feature_pair_selection = feature_pair_selection
        self.classes_ = None
        self.priors_ = None
        self.counts_ = None
        self.feature_pairs_ = None

        if input_features_type not in ["general", "gaussian"]:
            raise ValueError("Invalid input_features_type, use 'gaussian' or 'general'")

        if feature_pair_selection not in ["base", "dmst"]:
            raise ValueError("Invalid feature_pair_selection, use 'base' or 'dmst'")

    def __repr__(self):
        return (
            f"GeneralizedNaiveBayesClassifier("
            f"input_features_type: {self.input_features_type})"
        )

    def _get_priors_and_counts(self, y: NDArray[np.float64]) -> None:
        """
        Calculate class priors and counts.

        Parameters
        ----------
        y : NDArray[np.float64]
            Vector of shape (n_samples,) containing class labels.

        Returns
        -------
        None
        """
        self.classes_, self.counts_ = np.unique(y, sorted=True, return_counts=True)
        self.priors_ = self.counts_ / np.sum(self.counts_)

    def _calculate_mutual_info_vector_gaussian(
        self, X: NDArray[np.float64], y: NDArray[np.float64]
    ) -> NDArray[np.float64]:
        """
        Calculate mutual information vector for Gaussian features.

        For each feature, compute the mutual information between the feature
        and the class labels using the Gaussian formula.

        Parameters
        ----------
        X : NDArray[np.float64]
            Matrix of shape (n_samples, n_features) containing training data.
        y : Vector1D
            Matrix of shape (n_samples,) containing class labels.

        Returns
        -------
        NDArray[np.float64]
            Mutual information vector for all Xi features and Y target.
        """
        log_overall_var = np.log(np.std(X, axis=0, ddof=1) + self.eps)

        log_class_var = np.zeros_like(log_overall_var)
        for idx, cls in enumerate(self.classes_):
            X_cls = X[y == cls]
            var_cls = np.std(X_cls, axis=0, ddof=1)
            log_class_var += self.priors_[idx] * np.log(var_cls + self.eps)

        return log_overall_var - log_class_var

    def _calculate_total_correlation_matrix_gaussian(
        self, X: NDArray[np.float64], y: NDArray[np.float64]
    ) -> NDArray[np.float64]:
        """
        Calculate total correlation matrix, introduced by Satosi Watanabe.
        For 2 input features Xi and Xj, and target Y:
        M[i,j] = H(Xi) + H(Xj) + H(Y) - H(Xi, Xj, Y)

        It quantifies the total amount of dependence or redundancy shared
        among all three variables collectively. Essentially, it calculates
        the difference between the maximum possible entropy
        (if Xi, Xj, and Y were completely independent of one another)
        and their actual joint entropy.

        Parameters
        ----------
        X : NDArray[np.float64]
            Matrix of shape (n_samples, n_features) containing training data.
        y : Vector1D
            Matrix of shape (n_samples,) containing class labels.

        Returns
        -------
        NDArray[np.float64]
            Total correlation matrix using Gaussian formula.
        """
        log_overall_var = np.log(np.std(X, axis=0, ddof=1) ** 2 + self.eps)

        x_col = log_overall_var[:, np.newaxis]
        x_row = log_overall_var[np.newaxis, :]
        var_sum_matrix = x_col + x_row

        class_sum = np.zeros_like(var_sum_matrix)

        for idx, cls in enumerate(self.classes_):
            X_cls = X[y == cls]

            cov_matrix = np.cov(X_cls, rowvar=False, ddof=1)
            cov_matrix = cov_matrix + np.eye(X.shape[1]) * self.eps
            variances = np.diag(cov_matrix)

            var_product_matrix = np.outer(variances, variances)
            cov_squared_matrix = cov_matrix**2
            determinant_matrix = var_product_matrix - cov_squared_matrix

            # Add 'eps' to avoid log(0) for multicollinearity cases
            class_sum += self.priors_[idx] * np.log(determinant_matrix + self.eps)

        final_double_info_matrix = 0.5 * (var_sum_matrix - class_sum)
        return final_double_info_matrix

    def _get_feature_pairs_base(
        self,
        mutual_info_vector: NDArray[np.float64],
        total_correlation_matrix: NDArray[np.float64],
    ) -> list[tuple[int, int]]:
        """
        Calculate feature pairs (X_i, X_j) for building the classifier's structure.

        This method determines the optimal connections between features based on
        mutual and total correlation modelling. It starts with the most informative pair
        of features and iteratively adds connections until all features are included.

        Parameters
        ----------
        mutual_info_vector : NDArray[np.float64]
            Vector of mutual information for each feature.
        total_correlation_matrix : NDArray[np.float64]
            Total correlation matrix for each pair of features.

        Returns
        -------
        list[tuple[int, int]]
            List of tuples representing feature pairs. Each tuple contains
            (parent_node, child_node) indices.
        """
        num_cols = total_correlation_matrix.shape[1]
        masked_final_info = total_correlation_matrix.copy()
        np.fill_diagonal(masked_final_info, -np.inf)

        diff_matrix = total_correlation_matrix - mutual_info_vector[:, np.newaxis]
        np.fill_diagonal(diff_matrix, -np.inf)

        init_node = calculate_argmax_indices(masked_final_info)
        feature_pairs = [init_node]

        remaining_cols = set(range(num_cols)) - set(init_node)
        selectable_rows = set(init_node)

        while remaining_cols:
            selectable_rows_list = sorted(selectable_rows)
            remaining_cols_list = sorted(remaining_cols)

            submatrix = diff_matrix[np.ix_(selectable_rows_list, remaining_cols_list)]
            max_row_idx, max_col_idx = calculate_argmax_indices(submatrix)

            new_row = selectable_rows_list[max_row_idx]
            new_col = remaining_cols_list[max_col_idx]
            new_node = (new_row, new_col)

            feature_pairs.append(new_node)
            remaining_cols.remove(new_col)
            selectable_rows.add(new_col)

        return feature_pairs

    def _get_feature_pairs_dmst(
        self,
        mutual_info_vector: NDArray[np.float64],
        total_correlation_matrix: NDArray[np.float64],
    ) -> list[tuple[int, int]]:
        """
        Calculate feature pairs using a Maximum Spanning Arborescence (DMST).

        Constructs a fully connected directed graph and finds the optimal directed
        spanning tree using Edmonds' algorithm. The tree is rooted at the pair
        of features with the highest joint interaction.

        Parameters
        ----------
        mutual_info_vector : NDArray[np.float64]
            Vector of shape (n_features,)
            containing mutual information for each feature.
        total_correlation_matrix : NDArray[np.float64]
            Matrix of shape (n_features, n_features) containing total correlation.

        Returns
        -------
        list[tuple[int, int]]
            List of tuples representing feature pairs. Each tuple contains
            (parent_node, child_node) indices forming the optimal arborescence.
        """
        num_features = total_correlation_matrix.shape[1]

        masked_tc = total_correlation_matrix.copy()
        np.fill_diagonal(masked_tc, -np.inf)

        # Edge weight calculation: M[i,j] - I(X_j; Y)
        diff_matrix = total_correlation_matrix - mutual_info_vector[:, np.newaxis]
        np.fill_diagonal(diff_matrix, -np.inf)

        # Identify the initial root pair (highest joint information)
        node_u, node_v = np.unravel_index(np.argmax(masked_tc), masked_tc.shape)

        edges = []

        # Find minimum weight to shift values (ensures Edmonds' algo spans all nodes)
        min_weight = min(
            np.min(masked_tc[masked_tc != -np.inf]),
            np.min(diff_matrix[diff_matrix != -np.inf]),
        )
        shift = abs(min_weight) + 1.0 if min_weight < 0 else 0.0

        for i in range(num_features):
            for j in range(num_features):
                if i == j:
                    continue

                # Rule 1: The initial connection between the starting pair
                if i == node_u and j == node_v:
                    weight = float(masked_tc[i, j]) + shift
                    edges.append((i, j, weight))

                # Rule 2: No edges can point TO the starting nodes (u or v).
                elif j not in (node_u, node_v):
                    weight = float(diff_matrix[i, j]) + shift
                    edges.append((i, j, weight))

        G = nx.DiGraph()
        G.add_weighted_edges_from(edges)

        # Find the maximum spanning arborescence
        dmst_graph = nx.maximum_spanning_arborescence(G)
        self.feature_graph_ = G
        self.dmst_graph_ = dmst_graph

        return list(dmst_graph.edges())

    def _preprocess_entropy_data(
        self,
        X: NDArray[np.float64],
        y: NDArray[np.float64],
        discretization: str,
    ) -> tuple[NDArray[np.float64], float, NDArray[np.float64]]:
        """
        Discretize the feature matrix and pre-calculate marginal entropies.

        Using vectorized operations to discretize features and
        compute marginal entropies for the target and each feature.
        This method prepares the data for efficient
        mutual information and interaction calculations.

        Parameters
        ----------
        X : NDArray[np.float64]
            Input samples matrix of shape (n_samples, n_features).
        y : NDArray[np.float64]
            Target vector of shape (n_samples,).
        discretization : str
            Method to discretize continuous features.
            Must be either 'uniform' or 'quantile'.

        Returns
        -------
        X_discrete : NDArray[np.float64]
            Discretized version of the input matrix X.
        h_y : float
            Marginal entropy of the target variable y.
        h_feats : NDArray[np.float64]
            Vector of shape (n_features,) containing marginal entropies
            for each feature in X.

        Raises
        ------
        ValueError
            If the provided discretization method is not supported.
        """
        n_samples = X.shape[0]
        n_bins = int(np.cbrt(n_samples))

        func_map = {
            "uniform": uniform_discretize_feature,
            "quantile": quantile_discretize_feature,
        }

        if discretization not in func_map:
            raise ValueError(
                f"Invalid discretization method: '{discretization}'. "
                "Use 'uniform' or 'quantile'."
            )

        discretize = func_map[discretization]
        X_discrete = np.apply_along_axis(discretize, 0, X, n_bins)
        h_y = float(entropy(y))
        h_feats = np.apply_along_axis(entropy, 0, X_discrete)
        return X_discrete, h_y, h_feats

    def _calc_mutual_information_vector_discrete(
        self,
        X: NDArray[np.float64],
        y: NDArray[np.float64],
        discretization: str = "quantile",
    ) -> NDArray[np.float64]:
        """
        Calculate the Mutual Information (MI) vector between features and the target.

        Computes the metric I(Y; Xi) = H(Y) + H(Xi) - H(Xi, Y) for each feature.
        The final results are vectorized and clamped to ensure non-negativity.

        Parameters
        ----------
        X : NDArray[np.float64]
            Input samples matrix of shape (n_samples, n_features).
        y : NDArray[np.float64]
            Target vector of shape (n_samples,).
        discretization : {'uniform', 'quantile'}, default='quantile'
            Method to discretize continuous features.

        Returns
        -------
        mi_vector : NDArray[np.float64]
            Vector of shape (n_features,) containing the mutual information
            between each feature and the target.
        """
        X_discrete, h_y, h_feats = self._preprocess_entropy_data(
            X=X, y=y, discretization=discretization
        )
        n_features = X.shape[1]

        joint_entropies = np.array(
            [entropy(np.column_stack((X_discrete[:, i], y))) for i in range(n_features)]
        )

        # Vectorized arithmetic and clamping (removes the need for a max() loop)
        mi_vector = h_y + h_feats - joint_entropies
        return np.maximum(0.0, mi_vector)

    def _calc_total_correlation_matrix_discrete(
        self,
        X: NDArray[np.float64],
        y: NDArray[np.float64],
        discretization: str = "quantile",
    ) -> NDArray[np.float64]:
        """
        Calculate the Total Correlation (Interaction) Matrix for
        feature pairs and target.

        Computes the total correlation metric for triplets (Xi, Xj, Y).
        The formula used is C(Xi, Xj, Y) = H(Xi) + H(Xj) + H(Y) - H(Xi, Xj, Y).

        Parameters
        ----------
        X : NDArray[np.float64]
            Input samples matrix of shape (n_samples, n_features).
        y : NDArray[np.float64]
            Target vector of shape (n_samples,).
        discretization : {'uniform', 'quantile'}, default='quantile'
            Method to discretize continuous features.

        Returns
        -------
        tc_matrix : NDArray[np.float64]
            A symmetric matrix of shape (n_features, n_features) representing the
            total correlation among feature i, feature j, and the target y.
        """
        X_discrete, h_y, h_feats = self._preprocess_entropy_data(X, y, discretization)
        n_features = X.shape[1]

        tc_matrix = np.zeros((n_features, n_features))

        # iterating strictly over the upper triangle
        for i, j in combinations_with_replacement(range(n_features), 2):
            joint_triplet = np.column_stack((X_discrete[:, i], X_discrete[:, j], y))
            sum_marginals = h_feats[i] + h_feats[j] + h_y

            val = sum_marginals - entropy(joint_triplet)

            tc_matrix[i, j] = tc_matrix[j, i] = val

        return np.maximum(0.0, tc_matrix)

    def _entropy_from_samples(
        self, kde: gaussian_kde, samples: NDArray[np.float64]
    ) -> float:
        """
        Calculate the in-sample entropy estimate.

        Estimates the entropy H(X) as approximately -mean(log p(x)),
        computed at the training samples.

        Parameters
        ----------
        kde : gaussian_kde
            Fitted SciPy Gaussian Kernel Density Estimator.
        samples : NDArray[np.float64]
            Array of samples. Shape can be (n_samples,) for 1D or (2, n_samples) for 2D.

        Returns
        -------
        float
            Estimated continuous entropy.
        """
        return float(-np.mean(kde.logpdf(samples)))

    def _entropy_from_grid_1d(self, kde: gaussian_kde, n_grid: int) -> float:
        """
        Calculate the 1D grid-based entropy estimate.

        Estimates the entropy H(X) as the negative integral of p(x) log p(x)
        from 0 to 1, approximated using a Riemann sum.

        Parameters
        ----------
        kde : gaussian_kde
            Fitted 1D SciPy Gaussian Kernel Density Estimator.
        n_grid : int
            Number of points to evaluate along the [0, 1] grid.

        Returns
        -------
        float
            Estimated continuous entropy.
        """
        grid = np.linspace(0, 1, n_grid)
        dx = 1.0 / (n_grid - 1)

        p = kde.pdf(grid)
        p = p / (np.sum(p) * dx)  # Renormalize

        mask = p > 0
        return float(-np.sum(p[mask] * np.log(p[mask])) * dx)

    def _entropy_from_grid_2d(self, kde: gaussian_kde, n_grid: int) -> float:
        """
        Calculate the 2D grid-based joint entropy estimate.

        Estimates the joint entropy H(X, Y) as the negative double integral of
        p(x, y) log p(x, y) over the unit square.

        Parameters
        ----------
        kde : gaussian_kde
            Fitted 2D SciPy Gaussian Kernel Density Estimator.
        n_grid : int
            Number of points to evaluate along each axis of the [0, 1] grid.

        Returns
        -------
        float
            Estimated continuous joint entropy.
        """
        lin = np.linspace(0, 1, n_grid)
        Xm, Ym = np.meshgrid(lin, lin)
        grid = np.vstack([Xm.ravel(), Ym.ravel()])  # shape (2, n_grid^2)

        cell_area = (1.0 / (n_grid - 1)) ** 2

        p = kde.pdf(grid)
        p = p / (np.sum(p) * cell_area)  # Renormalize

        mask = p > 0
        return float(-np.sum(p[mask] * np.log(p[mask])) * cell_area)

    def _entropy_1d(
        self,
        x: NDArray[np.float64],
        bw_method: str | float,
        method: Literal["in_sample", "uniform_grid"],
        n_grid_1d: int,
    ) -> float:
        """
        Fit a 1D KDE and return its entropy.

        Parameters
        ----------
        x : NDArray[np.float64]
            1D feature array of shape (n_samples,).
        bw_method : str or float
            Bandwidth selector passed to scipy.stats.gaussian_kde.
        method : {'in_sample', 'uniform_grid'}
            The entropy estimation method to use.
        n_grid_1d : int
            Number of grid points if method is 'uniform_grid'.

        Returns
        -------
        float
            Estimated marginal entropy. Returns 0.0 if the array has zero variance.
        """
        if np.var(x) == 0:
            return 0.0

        try:
            kde = gaussian_kde(x, bw_method=bw_method)
            if method == "uniform_grid":
                return self._entropy_from_grid_1d(kde, n_grid_1d)
            return self._entropy_from_samples(kde, x)
        except np.linalg.LinAlgError:
            return 0.0

    def _entropy_2d(
        self,
        data: NDArray[np.float64],
        bw_method: str | float,
        method: Literal["in_sample", "uniform_grid"],
        n_grid_1d: int,
        n_grid_2d: int,
    ) -> float:
        """
        Fit a 2D KDE and return its joint entropy.

        Handles degenerate cases mathematically:
        - If one feature has zero variance, joint entropy is the entropy of the other.
        - If features are perfectly collinear, joint entropy is the entropy of one.

        Parameters
        ----------
        data : NDArray[np.float64]
            2D array of shape (2, n_samples) containing the two features.
        bw_method : str or float
            Bandwidth selector passed to scipy.stats.gaussian_kde.
        method : {'in_sample', 'uniform_grid'}
            The entropy estimation method to use.
        n_grid_1d : int
            Grid points for 1D fallback calculations.
        n_grid_2d : int
            Grid points per axis for 2D integration.

        Returns
        -------
        float
            Estimated joint entropy.
        """
        x, y = data[0], data[1]
        var_x, var_y = np.var(x), np.var(y)

        # Handle zero variance edge cases
        if var_x == 0 and var_y == 0:
            return 0.0
        elif var_x == 0:
            return self._entropy_1d(
                y, bw_method=bw_method, method=method, n_grid_1d=n_grid_1d
            )
        elif var_y == 0:
            return self._entropy_1d(
                x, bw_method=bw_method, method=method, n_grid_1d=n_grid_1d
            )

        try:
            kde = gaussian_kde(data, bw_method=bw_method)
            if method == "uniform_grid":
                return self._entropy_from_grid_2d(kde, n_grid_2d)
            return self._entropy_from_samples(kde, data)
        except np.linalg.LinAlgError:
            # Perfectly collinear features -> H(X, Y) = H(X)
            return self._entropy_1d(
                x, bw_method=bw_method, method=method, n_grid_1d=n_grid_1d
            )

    def _calc_mutual_information_vector_kde(
        self,
        X: NDArray[np.float64],
        y: NDArray[np.float64],
        method: Literal["in_sample", "uniform_grid"] = "in_sample",
        bw_method: str | float = "scott",
        n_grid_1d: int = 1000,
    ) -> NDArray[np.float64]:
        """
        Calculate the Mutual Information (MI) vector using KDE.

        Computes $I(X_i; Y) = H(X_i) - H(X_i | Y)$ for each feature.

        Parameters
        ----------
        X : NDArray[np.float64]
            Continuous feature matrix of shape (n_samples, n_features).
            Must be MinMax-scaled to [0, 1] when using method="uniform_grid".
        y : NDArray[np.float64]
            Discrete class labels of shape (n_samples,).
        method : {'in_sample', 'uniform_grid'}, default='in_sample'
            Entropy estimation method.
        bw_method : str or float, default='scott'
            Bandwidth selector passed to scipy.stats.gaussian_kde.
        n_grid_1d : int, default=1000
            Grid points for 1D integration (uniform_grid only).

        Returns
        -------
        NDArray[np.float64]
            Vector of shape (n_features,) containing the mutual information
            between each feature and the target.
        """
        if method not in ("in_sample", "uniform_grid"):
            raise ValueError(
                f"method must be 'in_sample' or 'uniform_grid', got '{method}'."
            )

        X_T = X.T
        n_features = X.shape[1]
        X_by_class = [X[y == cls].T for cls in self.classes_]

        # H(Xi) — global marginal entropy per feature
        h_feats = np.array(
            [
                self._entropy_1d(
                    X_T[i], bw_method=bw_method, method=method, n_grid_1d=n_grid_1d
                )
                for i in range(n_features)
            ]
        )

        # H(Xi | Y) — class-conditional entropy per feature
        h_cond_feats = np.array(
            [
                sum(
                    self.priors_[k]
                    * self._entropy_1d(
                        X_by_class[k][i],
                        bw_method=bw_method,
                        method=method,
                        n_grid_1d=n_grid_1d,
                    )
                    for k in range(len(self.classes_))
                )
                for i in range(n_features)
            ]
        )

        mi_vector = h_feats - h_cond_feats
        return np.maximum(0.0, mi_vector)

    def _calc_total_correlation_matrix_kde(
        self,
        X: NDArray[np.float64],
        y: NDArray[np.float64],
        method: Literal["in_sample", "uniform_grid"] = "in_sample",
        bw_method: str | float = "scott",
        n_grid_1d: int = 1000,
        n_grid_2d: int = 100,
    ) -> NDArray[np.float64]:
        """
        Calculate the Total Correlation (Interaction) Matrix using KDE.

        Computes $M_{i,j} = H(X_i) + H(X_j) - H(X_i, X_j | Y)$.
        For the diagonal elements, computes $2H(X_i) - H(X_i | Y)$.

        Parameters
        ----------
        X : NDArray[np.float64]
            Continuous feature matrix of shape (n_samples, n_features).
            Must be MinMax-scaled to [0, 1] when using method="uniform_grid".
        y : NDArray[np.float64]
            Discrete class labels of shape (n_samples,).
        method : {'in_sample', 'uniform_grid'}, default='in_sample'
            Entropy estimation method.
        bw_method : str or float, default='scott'
            Bandwidth selector passed to scipy.stats.gaussian_kde.
        n_grid_1d : int, default=1000
            Grid points for 1D integration (uniform_grid only).
        n_grid_2d : int, default=100
            Grid points per axis for 2D integration (uniform_grid only).

        Returns
        -------
        NDArray[np.float64]
            A symmetric matrix of shape (n_features, n_features) representing the
            total correlation among feature i, feature j, and the target y.
        """
        if method not in ("in_sample", "uniform_grid"):
            raise ValueError(
                f"method must be 'in_sample' or 'uniform_grid', got '{method}'."
            )

        X_T = X.T
        n_features = X.shape[1]
        X_by_class = [X[y == cls].T for cls in self.classes_]

        # H(Xi) — global marginal entropy per feature
        h_feats = np.array(
            [
                self._entropy_1d(
                    X_T[i], bw_method=bw_method, method=method, n_grid_1d=n_grid_1d
                )
                for i in range(n_features)
            ]
        )

        # H(Xi | Y) — class-conditional entropy per feature
        h_cond_feats = np.array(
            [
                sum(
                    self.priors_[k]
                    * self._entropy_1d(
                        X_by_class[k][i],
                        bw_method=bw_method,
                        method=method,
                        n_grid_1d=n_grid_1d,
                    )
                    for k in range(len(self.classes_))
                )
                for i in range(n_features)
            ]
        )

        tc_matrix = np.zeros((n_features, n_features))

        for i, j in combinations_with_replacement(range(n_features), 2):
            if i == j:
                tc_matrix[i, i] = 2 * h_feats[i] - h_cond_feats[i]
                continue

            # H(Xi, Xj | Y) = Σ_k P(Y=k) * H(Xi, Xj | Y=k)
            h_joint_cond = sum(
                self.priors_[k]
                * self._entropy_2d(
                    X_by_class[k][[i, j], :], bw_method, method, n_grid_1d, n_grid_2d
                )
                for k in range(len(self.priors_))
            )
            tc_matrix[i, j] = tc_matrix[j, i] = h_feats[i] + h_feats[j] - h_joint_cond

        return np.maximum(0.0, tc_matrix)

    def _fit_multivariate_gaussians(
        self,
        X: NDArray[np.float64],
        y: NDArray[np.float64],
        feature_pairs: list[tuple[int, int]],
        classes: list[int],
    ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        """
        Fit multivariate Gaussian parameters (mean vectors and covariance matrices)
        for each class and each pair of features specified in feature_pairs.

        Parameters
        ----------
        X : NDArray[np.float64]
            Input features array of shape (n_samples, n_features)
        y : NDArray[np.float64]
            Target labels array of shape (n_samples,)
        feature_pairs : list[tuple[int, int]]
            List of feature pairs (tuples) to fit Gaussian parameters for
        classes : list[int], optional
            List of class labels to fit parameters for

        Returns
        -------
        tuple[NDArray[np.float64], NDArray[np.float64]]
            multi_means : NDArray[np.float64]
                Mean vectors for each class and feature pair,
                shape (n_classes, n_feature_pairs, n_selected_feat)
            multi_cov : NDArray[np.float64]
                Covariance matrices for each class and feature pair,
                shape (n_classes, n_feature_pairs, n_selected_feat, n_selected_feat)
        """
        n_classes = len(classes)
        n_feature_pairs = len(feature_pairs)
        n_selected_feat = 2

        multi_means = np.zeros(
            (n_classes, n_feature_pairs, n_selected_feat), dtype=np.float64
        )
        multi_cov = np.zeros(
            (n_classes, n_feature_pairs, n_selected_feat, n_selected_feat),
            dtype=np.float64,
        )

        for cls_idx, cls in enumerate(classes):
            X_cls = X[y == cls]
            for feature_pair_idx, feature_pair in enumerate(feature_pairs):
                X_cls_features = X_cls[:, feature_pair]
                mean_vector = X_cls_features.mean(axis=0)

                cov_matrix = (
                    np.cov(X_cls_features, rowvar=False, ddof=1)
                    + np.eye(n_selected_feat) * self.eps
                )
                multi_means[cls_idx, feature_pair_idx] = mean_vector
                multi_cov[cls_idx, feature_pair_idx] = cov_matrix

        return multi_means, multi_cov

    def _fit_univariate_gaussians(
        self, X: NDArray[np.float64], y: NDArray[np.float64], classes: list[int]
    ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        """
        Fit univariate Gaussian parameters for each class and feature.

        Parameters
        ----------
        X : NDArray[np.float64]
            2D array of shape (n_samples, n_features) containing the training data.
        y : NDArray[np.float64]
            1D array of shape (n_samples,) containing class labels for each sample.
        classes : list[int]
            List of unique class labels to fit. The order of labels determines the row
            ordering in the returned mean and variance arrays.

        Returns
        -------
        tuple[NDArray[np.float64], NDArray[np.float64]]
            uni_means : ndarray, shape (n_classes, n_features)
                Mean of each feature for each class.
            uni_vars : ndarray, shape (n_classes, n_features)
                Unbiased sample variance (ddof=1) of each feature for each class with
                a small epsilon (self.eps) added for numerical stability.
        """
        n_classes = len(classes)
        n_features = X.shape[1]

        uni_means = np.zeros((n_classes, n_features), dtype=np.float64)
        uni_vars = np.zeros((n_classes, n_features), dtype=np.float64)

        for cls_idx, cls in enumerate(classes):
            X_cls = X[y == cls]
            mean_cls = X_cls.mean(axis=0)
            var_cls = np.var(X_cls, axis=0, ddof=1) + self.eps
            uni_means[cls_idx] = mean_cls
            uni_vars[cls_idx] = var_cls

        return uni_means, uni_vars

    def _calc_sum_multivariate_log_prob(
        self,
        X: NDArray[np.float64],
        feature_pairs: list[tuple[int, int]],
        classes: list[int],
        multi_means: NDArray[np.float64],
        multi_covs: NDArray[np.float64],
    ) -> NDArray[np.float64]:
        """
        Calculate the sum of log-probabilities for multivariate Gaussian distributions.

        For each class and multivariate feature pair defined in feature_pairs:
            - computes the log probability of each sample
            - using multivariate normal distribution
              with corresponding mean and covariance matrix.

        Parameters
        ----------
        X : NDArray[np.float64]
            Input samples matrix of shape (n_samples, n_features)
        feature_pairs : list[tuple[int, int]]
            List of tuples containing feature indices for each multivariate feature pair
        classes : list[int]
            List of class labels
        multi_means : NDArray[np.float64]
            Array of mean vectors for multivariate Gaussian distributions
            Shape: (n_classes, n_feature_pairs, n_selected_feat)
        multi_covs : NDArray[np.float64]
            Array of covariance matrices for multivariate Gaussian distributions
            Shape: (n_classes, n_feature_pairs, n_selected_feat, n_selected_feat)

        Returns
        -------
        NDArray[np.float64]
            Array of log probabilities for each class, feature pair and sample
            Shape: (n_classes, n_feature_pairs, n_samples)

        Notes
        -----
        The log probability is computed using the multivariate normal density formula:
        log(p(x)) = -0.5 * (d*log(2π) + log(det(Σ)) + (x-μ)ᵀΣ⁻¹(x-μ))
        where d is the dimension, Σ is the covariance matrix, and μ is the mean vector.
        """
        n_classes = len(classes)
        n_feature_pairs = len(feature_pairs)
        n_samples = X.shape[0]

        sum_log_likelihood = np.zeros(
            (n_classes, n_feature_pairs, n_samples), dtype=X.dtype
        )

        for cls_idx, cls in enumerate(classes):
            for feature_pair_idx, feature_pair in enumerate(feature_pairs):
                mean = multi_means[cls_idx][feature_pair_idx]
                cov = multi_covs[cls_idx][feature_pair_idx]

                cov_inv = np.linalg.inv(cov)
                det_cov = np.linalg.det(cov)
                const = -0.5 * (
                    len(feature_pair) * np.log(2 * np.pi) + np.log(det_cov + self.eps)
                )

                diff = X[:, list(feature_pair)] - mean
                mahalanobis_term = np.einsum("ij,ij->i", diff @ cov_inv, diff)
                log_prob = const - 0.5 * mahalanobis_term
                sum_log_likelihood[cls_idx, feature_pair_idx] = log_prob

        return sum_log_likelihood

    def _calc_sum_univariate_log_prob(
        self,
        X: NDArray[np.float64],
        duplicated_features: Counter,
        classes: list[int],
        uni_means: NDArray[np.float64],
        uni_vars: NDArray[np.float64],
    ) -> NDArray[np.float64]:
        """
        Calculate the sum of log-probabilities for univariate Gaussians.

        This function computes the sum of log-probabilities for univariate
        Gaussian distributions for each class and feature combination,
        taking into account feature repetition counts.

        Parameters
        ----------
        X : NDArray[np.float64]
            Input features matrix of shape (n_samples, n_features)
        duplicated_features : Counter
            Counter object containing the count of duplicated features
        classes : list[int]
            List of class labels
        uni_means : NDArray[np.float64]
            Array of univariate means for each class and feature
        uni_vars : NDArray[np.float64]
            Array of univariate variances for each class and feature

        Returns
        -------
        NDArray[np.float64]
            Array of shape (n_classes, n_terms, n_samples) containing the sum of
            log-probabilities for each class, term and sample

        Notes
        -----
        The function calculates the log probability using the formula:
            log_prob = -0.5 * log(2π * var) - 0.5 * (x - mean)^2 / var
            and multiplies it by the feature repetition count
        """
        n_classes = len(classes)
        n_terms = len(duplicated_features)
        n_samples = X.shape[0]

        sum_univariate_log_likelihood = np.zeros(
            (n_classes, n_terms, n_samples), dtype=X.dtype
        )

        for cls_idx, cls in enumerate(classes):
            for count_idx, (key, value) in enumerate(duplicated_features.items()):
                mean = uni_means[cls_idx][key]
                var = uni_vars[cls_idx][key]

                log_const = -0.5 * np.log(2 * np.pi * var + self.eps)
                log_prob = log_const - 0.5 * ((X[:, key] - mean) ** 2) / var

                sum_univariate_log_likelihood[cls_idx, count_idx] = log_prob * value

        return sum_univariate_log_likelihood

    def _get_multi_kde_fits(
        self,
        X: NDArray[np.float64],
        y: NDArray[np.float64],
        classes: NDArray[np.int64],
        feature_pairs: list[tuple[int, int]],
        bw_method_double: str | float = "scott",
    ) -> dict:
        """
        Fits multiple Kernel Density Estimations (KDE) for each combination.

        This method creates Gaussian KDE fits
        for each class in the dataset and for each node specified in the input.
        The KDEs are used to estimate the probability density of features
        for different class-node combinations.

        Parameters
        ----------
        X : NDArray[np.float64]
            The feature matrix where each row is a sample and each column is a feature.
        y : NDArray[np.float64]
            The target values (class labels) for each sample.
        classes : NDArray[np.int64]
            Array of unique class labels.
        feature_pairs : list[tuple[int, int]]
            List of node tuples representing feature pairs.
        bw_method_double : str or float, optional
            The method used to calculate the estimator bandwidth.
            This can be 'scott', 'silverman', or a float value.
            Default is 'scott'.

        Returns
        -------
        dict
            A nested dictionary where the outer key is the class index
            and the inner key is the node index,
            containing the fitted KDE for that class-node combination.
        """
        kde_fits = {}

        for cls_idx, cls in enumerate(classes):
            X_cls = X[y == cls]
            class_node_kde_fits = {}
            for index, node in enumerate(feature_pairs):
                feature_data = X_cls[:, list(node)].copy()
                kde_node_fit = gaussian_kde(feature_data.T, bw_method=bw_method_double)
                class_node_kde_fits[index] = kde_node_fit
            kde_fits[cls_idx] = class_node_kde_fits
        return kde_fits

    def _get_single_kde_fits(
        self,
        X: NDArray[np.float64],
        y: NDArray[np.float64],
        classes: NDArray[np.int64],
        bw_method_single: str | float = "scott",
    ) -> dict:
        """
        Fits Kernel Density Estimation (KDE) for specified features in each class.

        Parameters
        ----------
        X : NDArray[np.float64]
            Input feature matrix where rows are samples and columns are features.
        y : NDArray[np.float64]
            Target labels array.
        classes : NDArray[np.int64]
            Array of unique class labels.
        bw_method_single : str or float, optional
            The method used to calculate the estimator bandwidth.
            This can be 'scott', 'silverman', or a float value.
            Default is 'scott'.

        Returns
        -------
        dict
            Nested dictionary where:
            - First level keys are class indices
            - Second level keys are duplicated node indices
            - Values are fitted gaussian_kde objects for each class-node combination
        """
        num_features = X.shape[1]
        kde_fits = {}

        for cls_idx, cls in enumerate(classes):
            X_cls = X[y == cls]
            class_kde_fits = {}
            for feat_idx in range(num_features):
                feature_data = X_cls[:, feat_idx]
                kde = gaussian_kde(feature_data, bw_method=bw_method_single)
                class_kde_fits[feat_idx] = kde

            kde_fits[cls_idx] = class_kde_fits

        return kde_fits

    def _predict_with_kdes(
        self,
        X: NDArray[np.float64],
        multi_kde_outputs: dict,
        single_kde_outputs: dict,
        classes: NDArray[np.int64],
        feature_pairs: list[tuple[int, int]],
        duplicated_features: Counter,
    ) -> NDArray[np.float64]:
        """
        Predicts class probabilities using Kernel Density Estimation (KDE).

        This method calculates log probabilities for each class
        using both multivariate and univariate KDE models.
        It handles duplicate features by subtracting their individual contributions
        to avoid double counting.

        Parameters
        ----------
        X : NDArray[np.float64]
            Input data matrix of shape (n_samples, n_features)
        multi_kde_outputs : dict
            Dictionary containing multivariate KDE models
            for each class and node combination
        single_kde_outputs : dict
            Dictionary containing univariate KDE models
            for duplicated feature_pairs for each class
        classes : NDArray[np.int64]
            Array of unique class labels
        feature_pairs : list[tuple[int, int]]
            List of tuples representing feature pairs
        duplicated_features : Counter
            Counter object tracking duplicated feature_pairs in the graph

        Returns
        -------
        NDArray[np.float64]
            Matrix of log probabilities with shape (n_samples, n_classes)
        """
        num_records = X.shape[0]
        n_classes = len(classes)
        log_probabilities = np.zeros((num_records, n_classes))
        for cls_idx, cls in enumerate(classes):
            multi_kdes = multi_kde_outputs[cls_idx]
            single_kdes = single_kde_outputs[cls_idx]

            sum_prob_pred = np.zeros(num_records)

            for index, node in enumerate(feature_pairs):
                multi_kde = multi_kdes[index]
                data_subset = X[:, node].T
                density = np.log(multi_kde(data_subset) + self.eps)
                sum_prob_pred = sum_prob_pred + density

            for index, (feature, feat_count) in enumerate(duplicated_features.items()):
                feat_kde = single_kdes[index]
                data_subset = X[:, feature]
                density = np.log(feat_kde(data_subset) + self.eps)
                sum_prob_pred = sum_prob_pred - density * feat_count

            log_probabilities[:, cls_idx] = sum_prob_pred
        return log_probabilities

    def _predict_with_gaussian(
        self,
        X: NDArray[np.float64],
        feature_pairs: list[tuple[int, int]],
        duplicated_features: Counter,
        classes: NDArray[np.int64],
        multi_means: NDArray[np.float64],
        multi_covs: NDArray[np.float64],
        uni_means: NDArray[np.float64],
        uni_vars: NDArray[np.float64],
    ) -> NDArray[np.float64]:
        """
        Predicts log probabilities using Gaussian distributions.

        Parameters
        ----------
        X : NDArray[np.float64]
            Input data matrix of shape (n_samples, n_features)
        feature_pairs : list[tuple[int, int]]
            List of node tuples representing feature pairs
        duplicated_features : Counter
            Counter object tracking duplicated feature_pairs in the graph
        classes : NDArray[np.int64]
            Array of unique class labels
        multi_means : NDArray[np.float64]
            Array of means for multivariate Gaussians
            with shape (n_classes, n_feature_pairs, n_selected_feat)
        multi_covs : NDArray[np.float64]
            Array of covariance matrices for multivariate Gaussians
            with shape (n_classes, n_feature_pairs, n_selected_feat, n_selected_feat)
        uni_means : NDArray[np.float64]
            Array of means for univariate Gaussians
            with shape (n_classes, n_features)
        uni_vars : NDArray[np.float64]
            Array of variances for univariate Gaussians
            with shape (n_classes, n_features)

        Returns
        -------
        NDArray[np.float64]
            Matrix of log probabilities with shape (n_samples, n_classes)
        """
        multi_probs = self._calc_sum_multivariate_log_prob(
            X=X,
            feature_pairs=feature_pairs,
            classes=classes,
            multi_means=multi_means,
            multi_covs=multi_covs,
        ).sum(axis=1)

        uni_probs = self._calc_sum_univariate_log_prob(
            X=X,
            duplicated_features=duplicated_features,
            classes=classes,
            uni_means=uni_means,
            uni_vars=uni_vars,
        ).sum(axis=1)

        log_probabilities = (multi_probs - uni_probs).T
        return log_probabilities

    def fit(
        self,
        X: NDArray[np.float64],
        y: NDArray[np.float64],
        bw_method_single: str | float = "scott",
        bw_method_double: str | float = "scott",
        entropy_approx_method: Literal["discrete", "kde_based"] = "discrete",
        entropy_kde_method: Literal["in_sample", "uniform_grid"] = "uniform_grid",
        discretization: str = "quantile",
    ) -> "GeneralizedNaiveBayesClassifier":
        """
        Fits the Generalized Naive Bayes model to the training data.

        This method trains the model using the provided features X and target labels y.
            - For Gaussian features, it calculates priors, node relationships,
              and fits univariate and multivariate Gaussian distributions.
            - For general features, it builds a maximum spanning tree
              and fits kernel density estimators.

        Parameters
        ----------
        X : NDArray[np.float64]
            Training data features matrix of shape (n_samples, n_features)
        y : NDArray[np.float64]
            Target labels of shape (n_samples,)
        bw_method_single : str or float, optional
            The method used to calculate the bandwidth for univariate KDE.
            This can be 'scott', 'silverman', or a float value.
            Default is 'scott'.
        bw_method_double : str or float, optional
            The method used to calculate the bandwidth for multivariate KDE.
            This can be 'scott', 'silverman', or a float value.
            Default is 'scott'.
        entropy_approx_method : {'discrete', 'kde_based'}, optional
            The method to approximate entropy for KDE-based metrics.
            'discrete' uses discrete approximations, while
            'kde_based' uses kernel density estimation.
            Default is 'discrete'.
        entropy_kde_method : {'in_sample', 'uniform_grid'}, optional
            The method to estimate entropy when using KDE-based metrics.
            'in_sample' evaluates the KDE at the training samples, while
            'uniform_grid' uses a uniform grid for integration.
            Default is 'uniform_grid'.
        discretization : str, optional
            Method for discretizing continuous features.
            Options are 'uniform' for equal-width bins
            or 'quantile' for equal-frequency bins.
            Default is 'quantile'.

        Returns
        -------
        None
        """
        self._get_priors_and_counts(y=y)

        # Preprocess data and calculate mutual information and total correlation
        if self.input_features_type == "gaussian":
            self.mutual_info_vector = self._calculate_mutual_info_vector_gaussian(
                X=X, y=y
            )
            self.total_correlation_matrix = (
                self._calculate_total_correlation_matrix_gaussian(X=X, y=y)
            )

        elif self.input_features_type == "general":
            if entropy_approx_method == "discrete":
                self.mutual_info_vector = self._calc_mutual_information_vector_discrete(
                    X=X, y=y, discretization=discretization
                )
                self.total_correlation_matrix = (
                    self._calc_total_correlation_matrix_discrete(
                        X=X, y=y, discretization=discretization
                    )
                )
            else:
                self.mutual_info_vector = self._calc_mutual_information_vector_kde(
                    X=X, y=y, method=entropy_kde_method, bw_method=bw_method_single
                )
                self.total_correlation_matrix = self._calc_total_correlation_matrix_kde(
                    X=X, y=y, method=entropy_kde_method, bw_method=bw_method_double
                )

        # Select feature pairs based on the chosen method
        if self.feature_pair_selection == "base":
            self.feature_pairs_ = self._get_feature_pairs_base(
                mutual_info_vector=self.mutual_info_vector,
                total_correlation_matrix=self.total_correlation_matrix,
            )
        elif self.feature_pair_selection == "dmst":
            self.feature_pairs_ = self._get_feature_pairs_dmst(
                mutual_info_vector=self.mutual_info_vector,
                total_correlation_matrix=self.total_correlation_matrix,
            )

        # Fit density estimators for prediction
        if self.input_features_type == "gaussian":
            self.multi_means, self.multi_covs = self._fit_multivariate_gaussians(
                X=X, y=y, feature_pairs=self.feature_pairs_, classes=self.classes_
            )
            self.uni_means, self.uni_var = self._fit_univariate_gaussians(
                X=X, y=y, classes=self.classes_
            )

        elif self.input_features_type == "general":
            self.multi_kde_fits = self._get_multi_kde_fits(
                X=X,
                y=y,
                classes=self.classes_,
                feature_pairs=self.feature_pairs_,
                bw_method_double=bw_method_double,
            )
            self.single_kde_fits = self._get_single_kde_fits(
                X=X,
                y=y,
                classes=self.classes_,
                bw_method_single=bw_method_single,
            )

        return self

    def predict_proba(
        self, X: NDArray[np.float64], num_feature_pairs_to_predict: int = None
    ) -> NDArray[np.float64]:
        """
        Calculate the logprobability estimates for the classes.
        Need calibration to get proper probabilities.

        Parameters
        ----------
        X : NDArray[np.float64]
            Input data matrix where each row represents a sample
            and each column represents a feature.
        num_feature_pairs_to_predict : int, optional
            Number of feature_pairs to use for prediction.

        Returns
        -------
        NDArray[np.float64]
            Returns the probability of the samples for each class in the model.
            The columns correspond to the classes in sorted order,
            as they appear in the attribute `classes_`.

        Raises
        ------
        ValueError
            If the model has not been fitted yet (i.e., if `classes_` is None).
        """
        if self.classes_ is None:
            raise ValueError("Model has not been fitted yet.")

        if (num_feature_pairs_to_predict is not None) and (
            num_feature_pairs_to_predict > len(self.feature_pairs_)
        ):
            warnings.warn(
                "The requested number of feature_pairs "
                f"({num_feature_pairs_to_predict}) is larger than the number of"
                f" feature_pairs after model fit ({len(self.feature_pairs_)}).",
                UserWarning,
            )

        feature_pairs_to_predict = self.feature_pairs_[:num_feature_pairs_to_predict]
        duplicated_features_counter = get_duplicated_features(feature_pairs_to_predict)

        if self.input_features_type == "gaussian":
            log_prob = self._predict_with_gaussian(
                X=X,
                feature_pairs=feature_pairs_to_predict,
                duplicated_features=duplicated_features_counter,
                classes=self.classes_,
                multi_means=self.multi_means,
                multi_covs=self.multi_covs,
                uni_means=self.uni_means,
                uni_vars=self.uni_var,
            )

        if self.input_features_type == "general":
            log_prob = self._predict_with_kdes(
                X=X,
                multi_kde_outputs=self.multi_kde_fits,
                single_kde_outputs=self.single_kde_fits,
                classes=self.classes_,
                feature_pairs=feature_pairs_to_predict,
                duplicated_features=duplicated_features_counter,
            )

        # Normalize probabilities
        log_prob_normalized = log_prob - np.max(log_prob, axis=1)[:, np.newaxis]

        prob = np.exp(log_prob_normalized)
        prob /= prob.sum(axis=1)[:, np.newaxis]

        return prob

    def predict(self, X: NDArray[np.float64], num_feature_pairs_to_predict: int = None):
        """
        Predicts class labels for samples in X.

        Parameters
        ----------
        X : NDArray[np.float64]
            The input samples to predict class labels for.
            Should be a numpy array of shape (n_samples, n_features).
        num_feature_pairs_to_predict : int, optional
            Number of feature_pairs to use for prediction.
            If None, all feature_pairs are used. Default is None.

        Returns
        -------
        NDArray[np.int64]
            Predicted class labels for each sample in X.
            Returns a numpy array of shape (n_samples,)
            where each element is the predicted class label.
        """
        pred = self.predict_proba(
            X=X, num_feature_pairs_to_predict=num_feature_pairs_to_predict
        )
        return self.classes_[np.argmax(pred, axis=1)]

    def get_feature_importance(self) -> NDArray[np.float64]:
        """
        Get feature importance based on the mutual information matrix.

        Returns
        -------
        NDArray[np.float64]
            Array of feature importance scores.
            The importance of each feature is calculated
            as the sum of mutual information values
            connected to that feature in the MST.

        Raises
        ------
        ValueError
            If the model has not been fitted yet (i.e., if `mi_matrix` is None).
        """
        if self.classes_ is None:
            raise ValueError("Model has not been fitted yet.")

        if self.input_features_type != "gaussian":
            raise ValueError(
                "Feature importance is only available for 'gaussian' feature type."
            )

        output = self.total_correlation_matrix - self.mutual_info_vector
        np.fill_diagonal(output, 0)

        filled_double_info = self.total_correlation_matrix.copy()
        np.fill_diagonal(filled_double_info, 0)

        feature_importance = np.sum(output, axis=0) / (output.shape[1] - 1)
        total_correlation_mean = np.sum(filled_double_info, axis=0) / (
            output.shape[0] - 1
        )
        return feature_importance + total_correlation_mean

    # def predict_proba_modified(
    #     self, X: NDArray[np.float64], num_feature_pairs_to_predict: int = None
    # ) -> NDArray[np.float64]:
    #     """
    #     Calculate the logprobability estimates for the classes.
    #     Need calibration to get proper probabilities.

    #     Parameters
    #     ----------
    #     X : NDArray[np.float64]
    #         Input data matrix where each row represents a sample
    #         and each column represents a feature.
    #     num_feature_pairs_to_predict : int, optional
    #         Number of feature_pairs to use for prediction.

    #     Returns
    #     -------
    #     NDArray[np.float64]
    #         Returns the probability of the samples for each class in the model.
    #         The columns correspond to the classes in sorted order,
    #         as they appear in the attribute `classes_`.

    #     Raises
    #     ------
    #     ValueError
    #         If the model has not been fitted yet (i.e., if `classes_` is None).
    #     """
    #     if self.classes_ is None:
    #         raise ValueError("Model has not been fitted yet.")

    #     if (num_feature_pairs_to_predict is not None) and (
    #         num_feature_pairs_to_predict > len(self.feature_pairs_)
    #     ):
    #         warnings.warn(
    #             "The requested number of feature_pairs "
    #             f"({num_feature_pairs_to_predict}) is larger than the number of"
    #             f" feature_pairs after model fit ({len(self.feature_pairs_)}).",
    #             UserWarning,
    #         )

    #     feature_pairs_to_predict = self.feature_pairs_[:num_feature_pairs_to_predict]
    #     duplicated_features_counter = get_duplicated_features(
    #         feature_pairs_to_predict
    #     )

    #     if self.input_features_type == "gaussian":
    #         log_prob = self._predict_with_gaussian(
    #             X=X,
    #             feature_pairs=feature_pairs_to_predict,
    #             duplicated_features=duplicated_features_counter,
    #             classes=self.classes_,
    #             multi_means=self.multi_means,
    #             multi_covs=self.multi_covs,
    #             uni_means=self.uni_means,
    #             uni_vars=self.uni_var,
    #         )

    #     if self.input_features_type == "general":
    #         log_prob = self._predict_with_kdes(
    #             X=X,
    #             multi_kde_outputs=self.multi_kde_fits,
    #             single_kde_outputs=self.single_kde_fits,
    #             classes=self.classes_,
    #             feature_pairs=feature_pairs_to_predict,
    #             duplicated_features=duplicated_features_counter,
    #         )

    #     # Normalize probabilities
    #     log_prob_normalized = log_prob - np.max(log_prob, axis=1)[:, np.newaxis]

    #     prob = np.exp(log_prob_normalized)
    #     prob /= prob.sum(axis=1)[:, np.newaxis]

    #     return X, log_prob, prob

    # def calculate_node_weights(
    #     self, num_feature_pairs: int = None
    # ) -> tuple[NDArray[np.float64], dict]:
    #     """
    #     Calculates weights for each node based on the information matrix.

    #     Returns
    #     -------
    #     NDArray[np.float64]
    #         Array of node weights.
    #         The weight of each node is calculated
    #         as the sum of mutual information values
    #         connected to that node in the MST.
    #     """
    #     if num_feature_pairs is None:
    #         num_feature_pairs = len(self.feature_pairs_)
    #     running_sum, duplicates = self.analyse_running_info_matrix()
    #     running_sum = running_sum[:num_feature_pairs]
    #     duplicates = duplicates[:num_feature_pairs]

    #     unnorm_weights = np.diff(running_sum, prepend=0)
    #     node_weights = unnorm_weights / unnorm_weights.sum()

    #     from collections import defaultdict

    #     result = defaultdict(float)

    #     # Loop through paired keys and values
    #     for key, val in zip(duplicates, node_weights[1:]):
    #         result[int(key)] += float(val)

    #     # Convert back to a standard dict if needed (optional)
    #     return node_weights, dict(result)

    # def _predict_with_weighted_kdes(
    #     self,
    #     X: NDArray[np.float64],
    #     multi_kde_outputs: dict,
    #     single_kde_outputs: dict,
    #     classes: NDArray[np.int64],
    #     feature_pairs: list[tuple[int, int]],
    #     duplicated_features: Counter,
    #     node_weights: np.ndarray,
    # ) -> NDArray[np.float64]:
    #     """
    #     Predicts class probabilities using Kernel Density Estimation (KDE).

    #     This method calculates log probabilities for each class
    #     using both multivariate and univariate KDE models.
    #     It handles duplicate feature_pairs
    #     by subtracting their individual contributions
    #     to avoid double counting.

    #     Parameters
    #     ----------
    #     X : NDArray[np.float64]
    #         Input data matrix of shape (n_samples, n_features)
    #     multi_kde_outputs : dict
    #         Dictionary containing multivariate KDE models
    #         for each class and node combination
    #     single_kde_outputs : dict
    #         Dictionary containing univariate KDE models
    #         for duplicated feature_pairs for each class
    #     classes : NDArray[np.int64]
    #         Array of unique class labels
    #     feature_pairs : list[tuple[int, int]]
    #         List of tuples representing feature pairs
    #     duplicated_features : Counter
    #         Counter object tracking duplicated feature_pairs in the graph

    #     Returns
    #     -------
    #     NDArray[np.float64]
    #         Matrix of log probabilities with shape (n_samples, n_classes)
    #     """
    #     num_records = X.shape[0]
    #     n_classes = len(classes)
    #     log_probabilities = np.zeros((num_records, n_classes))
    #     for cls_idx, cls in enumerate(classes):
    #         multi_kdes = multi_kde_outputs[cls_idx]
    #         single_kdes = single_kde_outputs[cls_idx]

    #         sum_prob_pred = np.zeros(num_records)

    #         for index, node in enumerate(feature_pairs):
    #             multi_kde = multi_kdes[index]
    #             data_subset = X[:, node].T
    #             density = (
    #                 np.log(multi_kde(data_subset) + self.eps) * node_weights[index]
    #             )
    #             sum_prob_pred = sum_prob_pred + density

    #         for index, (feature, feat_weight) in enumerate(
    #                                           duplicated_features.items()):
    #             feat_kde = single_kdes[index]
    #             data_subset = X[:, feature]
    #             density = np.log(feat_kde(data_subset) + self.eps)
    #             sum_prob_pred = sum_prob_pred - density * feat_weight
    #         log_probabilities[:, cls_idx] = sum_prob_pred
    #     return log_probabilities

    # def predict_with_weighted_feature_pairs(
    #     self, X: NDArray[np.float64], num_feature_pairs_to_predict: int = None
    # ) -> NDArray[np.float64]:
    #     """
    #     Predict class probabilities using weighted feature_pairs.

    #     Parameters
    #     ----------
    #     X : NDArray[np.float64]
    #         Input data matrix where each row represents a sample
    #         and each column represents a feature.
    #     num_feature_pairs_to_predict : int, optional
    #         Number of feature_pairs to use for prediction.

    #     Returns
    #     -------
    #     NDArray[np.float64]
    #         Returns the probability of the samples for each class in the model.
    #         The columns correspond to the classes in sorted order,
    #         as they appear in the attribute `classes_`.
    #     """
    #     if self.classes_ is None:
    #         raise ValueError("Model has not been fitted yet.")

    #     if (num_feature_pairs_to_predict is not None) and (
    #         num_feature_pairs_to_predict > len(self.feature_pairs_)
    #     ):
    #         warnings.warn(
    #             "The requested number of feature_pairs "
    #             f"({num_feature_pairs_to_predict}) is larger than the number of"
    #             f" feature_pairs after model fit ({len(self.feature_pairs_)}).",
    #             UserWarning,
    #         )

    #     feature_pairs_to_predict = self.feature_pairs_[:num_feature_pairs_to_predict]
    #     node_weights, node_weight_dict = self.calculate_node_weights(
    #         num_feature_pairs=num_feature_pairs_to_predict
    #     )

    #     log_prob = self._predict_with_weighted_kdes(
    #         X=X,
    #         multi_kde_outputs=self.multi_kde_fits,
    #         single_kde_outputs=self.single_kde_fits,
    #         classes=self.classes_,
    #         feature_pairs=feature_pairs_to_predict,
    #         duplicated_features=node_weight_dict,
    #         node_weights=node_weights,
    #     )

    #     # Normalize probabilities
    #     log_prob_normalized = log_prob - np.max(log_prob, axis=1)[:, np.newaxis]

    #     prob = np.exp(log_prob_normalized)
    #     prob /= prob.sum(axis=1)[:, np.newaxis]

    #     return self.classes_[np.argmax(prob, axis=1)]
