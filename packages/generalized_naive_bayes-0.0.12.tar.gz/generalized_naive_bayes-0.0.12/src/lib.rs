use pyo3::prelude::*;
use pyo3::exceptions::PyValueError;
use numpy::PyReadonlyArrayDyn;
use std::collections::HashMap;

#[pyfunction]
#[pyo3(signature = (labels))]
fn fast_entropy(labels: PyReadonlyArrayDyn<'_, i64>) -> PyResult<f64> {
    let view = labels.as_array();
    let shape = view.shape();

    if shape.is_empty() || shape[0] <= 1 {
        return Ok(0.0);
    }

    let n_labels = shape[0] as f64;

    // Use a HashMap to count frequencies (O(N) time complexity)
    let mut counts: HashMap<Vec<i64>, usize> = HashMap::new();

    // Handle 1D arrays or multi-column 2D arrays
    if view.ndim() == 1 {
        for item in view.iter() {
            *counts.entry(vec![*item]).or_insert(0) += 1;
        }
    } else if view.ndim() == 2 {
        for row in view.rows() {
            // Collect the row into a Vec to use as a Hash key
            let row_vec: Vec<i64> = row.iter().copied().collect();
            *counts.entry(row_vec).or_insert(0) += 1;
        }
    } else {
        return Err(PyValueError::new_err("Only 1D or 2D label arrays are supported."));
    }

    // Calculate Entropy
    let mut entropy = 0.0;
    for count in counts.values() {
        let prob = (*count as f64) / n_labels;
        entropy -= prob * prob.log2();
    }

    Ok(entropy)
}

// Register the module and function with Python
#[pymodule]
fn _core(_py: Python, m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(fast_entropy, m)?)?;
    Ok(())
}
