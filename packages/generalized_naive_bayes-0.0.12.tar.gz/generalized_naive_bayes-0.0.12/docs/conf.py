import os
import sys

sys.path.insert(0, os.path.abspath("../src"))

project = "generalized-naive-bayes"
copyright = "2025, Abraham Papp"
author = "Abraham Papp"
release = "v0.0.7"


extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.viewcode",
]


html_theme = "sphinx_rtd_theme"

templates_path = ["_templates"]
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]
html_static_path = ["_static"]
