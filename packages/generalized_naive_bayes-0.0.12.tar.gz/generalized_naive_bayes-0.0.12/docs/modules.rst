generalized_naive_bayes
=======================

.. toctree::
   :maxdepth: 4

   generalized_naive_bayes
