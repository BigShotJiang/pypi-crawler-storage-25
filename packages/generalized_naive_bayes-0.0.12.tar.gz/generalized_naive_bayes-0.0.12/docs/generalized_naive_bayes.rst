generalized\_naive\_bayes package
=================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   generalized_naive_bayes.core
   generalized_naive_bayes.utils

Module contents
---------------

.. automodule:: generalized_naive_bayes
   :members:
   :show-inheritance:
   :undoc-members:
