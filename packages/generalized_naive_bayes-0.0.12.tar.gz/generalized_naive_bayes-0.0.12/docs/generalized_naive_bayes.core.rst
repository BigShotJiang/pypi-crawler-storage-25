generalized\_naive\_bayes.core package
======================================

Submodules
----------

generalized\_naive\_bayes.core.classifier module
------------------------------------------------

.. automodule:: generalized_naive_bayes.core.classifier
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: generalized_naive_bayes.core
   :members:
   :show-inheritance:
   :undoc-members:
