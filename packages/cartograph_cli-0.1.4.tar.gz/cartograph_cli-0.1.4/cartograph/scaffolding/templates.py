"""
Language-specific file templates for widget scaffolding.

Each function writes starter src/, tests/, and examples/ files for a given language.
None of these need the Cartograph instance — they just write files to disk.

To add a scaffold template for a new language:
  1. Write a function with the signature:
       def <lang>(target_dir, module_name, display_name, **kwargs)
     - target_dir: the widget root (src/, tests/, examples/ already exist)
     - module_name: snake_case identifier derived from the widget ID
     - display_name: human-readable title for comments/docstrings
  2. Register it in TEMPLATES at the bottom of this file.

If no template is registered for a language, scaffolding falls back to
the Python template (stub files will be wrong — always add a real one).
"""

import json
import os


def python(target_dir, module_name, display_name, **_):
    with open(os.path.join(target_dir, "src", "__init__.py"), "w") as f:
        f.write("# Package marker — add explicit exports here once the public API is stable.\n")
    with open(os.path.join(target_dir, "src", f"{module_name}.py"), "w") as f:
        f.write(f'def {module_name}(value):\n    """{display_name}: process a value."""\n    return value\n')
    with open(os.path.join(target_dir, "tests", f"test_{module_name}.py"), "w") as f:
        f.write(
            f"def test_placeholder():\n"
            f"    # TODO: replace with real tests\n"
            f"    pass\n"
        )
    with open(os.path.join(target_dir, "examples", "example_usage.py"), "w") as f:
        f.write(
            f'"""\n'
            f"Example usage of {display_name}.\n\n"
            f"This file must run and exit cleanly with no user input, no network calls,\n"
            f"and no external services or API keys. Use fake/hardcoded data to demonstrate the API.\n"
            f"The widget's own declared dependencies are fine — the validator installs them first.\n"
            f'"""\n'
            f"import sys, os\n"
            f"sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))\n"
            f"from src.{module_name} import {module_name}\n\n"
            f"# [TODO] Replace with a realistic call using fake data\n"
            f'result = {module_name}("hello")\n'
            f'print(f"Result: {{result}}")\n'
        )


def javascript(target_dir, module_name, display_name, **kwargs):
    # PascalCase component name from snake_case module_name
    component_name = "".join(w.capitalize() for w in module_name.split("_"))

    # Pre-populate React deps in widget.json
    manifest_path = os.path.join(target_dir, "widget.json")
    with open(manifest_path) as f:
        manifest = json.load(f)
    manifest["tech_stack"]["dependencies"] = [
        "react>=18.0.0",
        "react-dom>=18.0.0",
    ]
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)

    with open(os.path.join(target_dir, "src", f"{component_name}.jsx"), "w") as f:
        f.write(
            f"/**\n"
            f" * {display_name}\n"
            f" */\n"
            f"export function {component_name}({{ children }}) {{\n"
            f"  return (\n"
            f"    <div className=\"{module_name.replace('_', '-')}\">\n"
            f"      {{children}}\n"
            f"    </div>\n"
            f"  )\n"
            f"}}\n"
        )

    with open(os.path.join(target_dir, "tests", f"test_{component_name}.jsx"), "w") as f:
        f.write(
            f"import {{ render, screen }} from '@testing-library/react'\n"
            f"import {{ {component_name} }} from '../src/{component_name}.jsx'\n\n"
            f"test('renders children', () => {{\n"
            f"  render(<{component_name}>Hello</{component_name}>)\n"
            f"  expect(screen.getByText('Hello')).toBeTruthy()\n"
            f"}})\n"
        )

    with open(os.path.join(target_dir, "examples", "example_usage.jsx"), "w") as f:
        f.write(
            f"/**\n"
            f" * Example usage of {display_name}.\n"
            f" *\n"
            f" * Renders via react-dom/server — no browser needed.\n"
            f" * Use fake/hardcoded props to demonstrate the component API.\n"
            f" */\n"
            f"import {{ renderToString }} from 'react-dom/server'\n"
            f"import {{ {component_name} }} from '../src/{component_name}.jsx'\n\n"
            f"// [TODO] Replace with a realistic call using fake props\n"
            f"const html = renderToString(\n"
            f"  <{component_name}>Example content</{component_name}>\n"
            f")\n"
            f"console.log(html)\n"
        )

    with open(os.path.join(target_dir, "examples", "usage_hint.jsx"), "w") as f:
        f.write(
            f"/**\n"
            f" * Usage hint for {display_name} — real integration code, not pipeline-validated.\n"
            f" *\n"
            f" * Show how this component fits into a real app: routing, providers, layout, etc.\n"
            f" * This file is a courtesy from the author and is not executed by Cartograph.\n"
            f" * Fill it in or delete it — it has no effect on validation or checkin.\n"
            f" */\n\n"
            f"// [TODO] Show a real-world integration — e.g. inside a router, a page, a provider tree\n"
            f"// import {{ {component_name} }} from './cartograph/{component_name}/src/{component_name}.jsx'\n"
            f"//\n"
            f"// export function MyPage() {{\n"
            f"//   return <{component_name}>Hello</{component_name}>\n"
            f"// }}\n"
        )


def nim(target_dir, module_name, display_name, **_):
    # Nim stdlib modules are resolved before --path:src, so a src file named
    # e.g. "base64.nim" silently shadows to std/base64 and breaks imports.
    # Suffix with _lib to guarantee no collision with any stdlib module.
    src_module = f"{module_name}_lib"

    # .nimble file is required by `nimble test` — names the package
    with open(os.path.join(target_dir, f"{module_name}.nimble"), "w") as f:
        f.write(
            f'# Package\n'
            f'version = "0.1.0"\n'
            f'author = "Widget Author"\n'
            f'description = "{display_name}"\n'
            f'license = "MIT"\n'
            f'srcDir = "src"\n\n'
            f'# Dependencies\n'
            f'requires "nim >= 2.0.0"\n\n'
            f'# Tasks\n'
            f'task test, "run tests":\n'
            f'  for f in listFiles("tests"):\n'
            f'    if f.endsWith(".nim"):\n'
            f'      exec "nimble c -r --path:src " & f\n'
        )

    with open(os.path.join(target_dir, "src", f"{src_module}.nim"), "w") as f:
        f.write(
            f'## {display_name}\n\n'
            f'func {module_name}*(value: string): string =\n'
            f'  ## Process a value.\n'
            f'  value\n'
        )

    with open(os.path.join(target_dir, "tests", f"test_{module_name}.nim"), "w") as f:
        f.write(
            f'import std/unittest\n'
            f'import {src_module}\n\n'
            f'suite "{display_name}":\n'
            f'  test "placeholder":\n'
            f'    # TODO: replace with real tests\n'
            f'    check true\n'
        )

    with open(os.path.join(target_dir, "examples", "example_usage.nim"), "w") as f:
        f.write(
            f'## Example usage of {display_name}.\n'
            f'##\n'
            f'## This file must compile and run cleanly with no user input,\n'
            f'## no network calls, and no external services. Use fake/hardcoded\n'
            f'## data to demonstrate the API.\n\n'
            f'import {src_module}\n\n'
            f'# [TODO] Replace with a realistic call using fake data\n'
            f'let result = {module_name}("hello")\n'
            f'discard result  # replace with meaningful output or assertions\n'
        )


def typescript(target_dir, module_name, display_name, **_):
    with open(os.path.join(target_dir, "src", f"{module_name}.ts"), "w") as f:
        f.write(
            f"/**\n"
            f" * {display_name}\n"
            f" */\n"
            f"export function {module_name}(value: string): string {{\n"
            f"  return value\n"
            f"}}\n"
        )

    with open(os.path.join(target_dir, "tests", f"test_{module_name}.ts"), "w") as f:
        f.write(
            f"import {{ {module_name} }} from '../src/{module_name}'\n\n"
            f"test('placeholder', () => {{\n"
            f"  // TODO: replace with real tests\n"
            f"  expect({module_name}('hello')).toBe('hello')\n"
            f"}})\n"
        )

    with open(os.path.join(target_dir, "examples", "example_usage.ts"), "w") as f:
        f.write(
            f"/**\n"
            f" * Example usage of {display_name}.\n"
            f" *\n"
            f" * This file must run and exit cleanly with no user input, no network calls,\n"
            f" * and no external services or API keys. Use fake/hardcoded data to demonstrate the API.\n"
            f" * The widget's own declared dependencies are fine - the validator installs them first.\n"
            f" */\n"
            f"import {{ {module_name} }} from '../src/{module_name}'\n\n"
            f"// [TODO] Replace with a realistic call using fake data\n"
            f"const result = {module_name}('hello')\n"
            f"console.log(`Result: ${{result}}`)\n"
        )


# Registry: maps normalized language name -> template function
TEMPLATES = {
    "python": python,
    "javascript": javascript,
    "typescript": typescript,
    "nim": nim,
}
