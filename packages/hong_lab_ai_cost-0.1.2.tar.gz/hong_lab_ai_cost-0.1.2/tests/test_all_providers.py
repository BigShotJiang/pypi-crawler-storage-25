"""
本地测试 hong-lab-ai-cost SDK — 所有 Provider（无需真实 API key）。

使用 Mock 对象模拟四种场景：
A. OpenAI 官方 API
B. Google Gemini (google-genai SDK)
C. Anthropic
D. 第三方代理 (apiyihe.org, 使用 OpenAI SDK + 自定义 base_url)
"""

import json
import logging
import shutil
from pathlib import Path
from types import SimpleNamespace

# ── 开启日志 ──
logging.basicConfig(level=logging.DEBUG, format="%(name)s  %(levelname)s  %(message)s")

from hong_lab_ai_cost import CostTracker, PricingCatalog

# ── 准备干净的 costs 目录 ──
COSTS_DIR = Path(__file__).parent / ".cost-tracker"
if COSTS_DIR.exists():
    shutil.rmtree(COSTS_DIR)

print("\n" + "=" * 65)
print("  Lab Cost Tracker SDK — 多 Provider 本地测试")
print("=" * 65 + "\n")

tracker = CostTracker(
    project="TestProject",
    user="kyle",
    email="kyle@aucklanduni.ac.nz",
    remote_url=None,
    storage_dir=str(COSTS_DIR),
)

print("✅ CostTracker 初始化成功\n")


# ════════════════════════════════════════════════════════════════════
# 场景 A: OpenAI 官方 API
# ════════════════════════════════════════════════════════════════════
print("── 场景 A: OpenAI 官方 API ─────────────────────────")


class MockOpenAICompletions:
    def create(self, **kwargs):
        return SimpleNamespace(
            model="gpt-4o-mini-2024-07-18",
            usage=SimpleNamespace(prompt_tokens=100, completion_tokens=50),
            choices=[SimpleNamespace(message=SimpleNamespace(content="Hello!"))],
        )


class MockOpenAIChat:
    def __init__(self):
        self.completions = MockOpenAICompletions()


class MockOpenAIClient:
    __module__ = "openai._client"

    def __init__(self, base_url="https://api.openai.com/v1"):
        self.chat = MockOpenAIChat()
        self.base_url = base_url


openai_client = MockOpenAIClient()
openai_client = tracker.wrap(openai_client)

resp = openai_client.chat.completions.create(model="gpt-4o-mini", messages=[])
print(f"  📝 OpenAI: model={resp.model}, tokens=100+50")

# Verify double-wrap prevention
openai_client2 = tracker.wrap(openai_client)
assert openai_client2 is openai_client, "❌ Double-wrap should return same client"
print("  ✅ 防重复 wrap 正常")


# ════════════════════════════════════════════════════════════════════
# 场景 B: Google Gemini (google-genai SDK)
# ════════════════════════════════════════════════════════════════════
print("\n── 场景 B: Google Gemini ────────────────────────────")


class MockGeminiModels:
    def generate_content(self, *args, **kwargs):
        return SimpleNamespace(
            usage_metadata=SimpleNamespace(
                prompt_token_count=200,
                candidates_token_count=80,
                total_token_count=280,
            ),
            text="新西兰奥克兰大学是该国顶尖的研究型大学。",
        )


class MockGeminiClient:
    __module__ = "google.genai._api_client"

    def __init__(self):
        self.models = MockGeminiModels()


gemini_client = MockGeminiClient()
gemini_client = tracker.wrap(gemini_client)

resp = gemini_client.models.generate_content(model="gemini-2.5-flash", contents="Hello")
print(f"  📝 Gemini: model=gemini-2.5-flash, tokens=200+80")


# ════════════════════════════════════════════════════════════════════
# 场景 C: Anthropic
# ════════════════════════════════════════════════════════════════════
print("\n── 场景 C: Anthropic ───────────────────────────────")


class MockAnthropicMessages:
    def create(self, **kwargs):
        return SimpleNamespace(
            model="claude-3-5-haiku-20241022",
            usage=SimpleNamespace(input_tokens=150, output_tokens=60),
            content=[SimpleNamespace(text="Hello from Claude!")],
        )


class MockAnthropicClient:
    __module__ = "anthropic._client"

    def __init__(self):
        self.messages = MockAnthropicMessages()


anthropic_client = MockAnthropicClient()
anthropic_client = tracker.wrap(anthropic_client)

resp = anthropic_client.messages.create(model="claude-3-5-haiku-20241022", messages=[])
print(f"  📝 Anthropic: model={resp.model}, tokens=150+60")


# ════════════════════════════════════════════════════════════════════
# 场景 D: 第三方代理 (apiyihe.org, OpenAI SDK + 自定义 base_url)
# ════════════════════════════════════════════════════════════════════
print("\n── 场景 D: 第三方代理 (apiyihe.org) ────────────────")


class MockProxyCompletions:
    def create(self, **kwargs):
        return SimpleNamespace(
            model="gemini-2.5-flash-lite-preview-06-17",
            usage=SimpleNamespace(prompt_tokens=300, completion_tokens=120),
            choices=[SimpleNamespace(message=SimpleNamespace(content="代理回复"))],
        )


class MockProxyChat:
    def __init__(self):
        self.completions = MockProxyCompletions()


class MockProxyClient:
    __module__ = "openai._client"

    def __init__(self):
        self.chat = MockProxyChat()
        self.base_url = "https://z.apiyihe.org/v1"


proxy_client = MockProxyClient()
proxy_client = tracker.wrap(proxy_client)

resp = proxy_client.chat.completions.create(model="gemini-2.5-flash-lite-preview-06-17", messages=[])
print(f"  📝 代理: model={resp.model}, base_url=apiyihe.org, tokens=300+120")


# ════════════════════════════════════════════════════════════════════
# 验证汇总数据
# ════════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)

s = tracker.summary()
print("📊 费用汇总:")
print(f"   Project         : {s['project']}")
print(f"   Total requests  : {s['total_requests']}")
print(f"   Total cost (USD): ${s['total_cost_usd']:.6f}")
print(f"   Prompt tokens   : {s['total_prompt_tokens']:,}")
print(f"   Completion toks : {s['total_completion_tokens']:,}")
print()
print("   By model:")
for model, info in s["by_model"].items():
    print(f"     {model:45s}  ${info['cost_usd']:.6f}  ({info['requests']} req)")
print()

# ── 验证文件 ──
detail_path = COSTS_DIR / "detail.jsonl"
assert detail_path.exists(), "❌ detail.jsonl 不存在！"

lines = [l for l in detail_path.read_text().strip().split("\n") if l.strip()]
assert len(lines) == 4, f"❌ 期望 4 条记录，实际 {len(lines)} 条"

# 检查第一条记录（OpenAI）
rec0 = json.loads(lines[0])
assert rec0["model"] == "gpt-4o-mini-2024-07-18"
assert rec0["metadata"]["provider"] == "openai"
assert "api.openai.com" in rec0["metadata"]["base_url"]
print("✅ OpenAI 记录正确（含 base_url）")

# 检查 Gemini 记录
rec1 = json.loads(lines[1])
assert rec1["model"] == "gemini-2.5-flash"
assert rec1["metadata"]["provider"] == "google"
print("✅ Gemini 记录正确")

# 检查 Anthropic 记录
rec2 = json.loads(lines[2])
assert rec2["model"] == "claude-3-5-haiku-20241022"
assert rec2["metadata"]["provider"] == "anthropic"
print("✅ Anthropic 记录正确")

# 检查代理记录
rec3 = json.loads(lines[3])
assert rec3["model"] == "gemini-2.5-flash-lite-preview-06-17"
assert "apiyihe" in rec3["metadata"]["base_url"]
print("✅ 第三方代理记录正确（base_url=apiyihe.org）")

# ── PricingCatalog 测试 ──
print()
catalog = PricingCatalog()
for name in ["gpt-4o-mini", "gemini-2.5-flash", "claude-3-5-haiku-20241022", "unknown-xyz"]:
    price = catalog.get(name)
    if price:
        print(f"  💰 {name:45s}  ${price.input_per_1m}/1M in  ${price.output_per_1m}/1M out")
    else:
        print(f"  ⚠️  {name:45s}  价格未知")

print("\n" + "=" * 65)
print("  🎉 所有测试通过！四种 Provider 全部正常。")
print("=" * 65 + "\n")
