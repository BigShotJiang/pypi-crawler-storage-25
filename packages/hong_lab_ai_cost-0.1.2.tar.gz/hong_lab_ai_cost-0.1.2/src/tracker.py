"""
CostTracker — main entry point.

Usage:
    from hong_lab_ai_cost import CostTracker

    tracker = CostTracker(
        project="DentalVLM",
        user="kyle",
        email="kyle@aucklanduni.ac.nz",
    )

    # OpenAI (official or third-party proxy)
    client = tracker.wrap(OpenAI(api_key="..."))
    response = client.chat.completions.create(model="gpt-4o-mini", ...)

    # Gemini
    client = tracker.wrap(genai.Client(api_key="..."))
    response = client.models.generate_content(model="gemini-2.5-flash", ...)

    # Anthropic
    client = tracker.wrap(anthropic.Anthropic(api_key="..."))
    response = client.messages.create(model="claude-3-5-sonnet-20241022", ...)

    # Check local summary anytime
    print(tracker.summary())
"""

from __future__ import annotations

import atexit
import logging
from pathlib import Path
from typing import Any, Optional

from hong_lab_ai_cost.config import TrackerConfig, find_project_root, load_config
from hong_lab_ai_cost.pricing import PricingCatalog
from hong_lab_ai_cost.storage import LocalStorage
from hong_lab_ai_cost.sync import RemoteSync

logger = logging.getLogger("hong_lab_ai_cost")


class ProjectSuspendedError(Exception):
    """Raised when admin has suspended this project via the dashboard.

    All LLM API calls are blocked until the admin resumes the project
    and the script is restarted.
    """
    pass


class CostTracker:
    """
    Lightweight API cost tracker for research labs.

    Args:
        project: Project name (e.g., "DentalVLM")
        user: User display name (e.g., "kyle"). Used for local records and
              server-side whitelist validation.
        email: User email (e.g., "kyle@aucklanduni.ac.nz"). Used for
               server-side whitelist validation.
        remote_url: Remote API URL for syncing. None = local-only mode.
            Can also be set via env var COST_TRACKER_REMOTE_URL or
            .cost-tracker.yaml config file.
        config_path: Explicit path to .cost-tracker.yaml.
        storage_dir: Explicit costs dir, bypasses find_project_root().
    """

    def __init__(
        self,
        project: Optional[str] = None,
        user: Optional[str] = None,
        email: Optional[str] = None,
        remote_url: Optional[str] = None,
        config_path: Optional[str] = None,
        storage_dir: Optional[str] = None,
    ):
        # Load config (YAML < env < explicit args)
        self._config = load_config(
            project=project, user=user, email=email,
            remote_url=remote_url, config_path=config_path,
        )

        # Pricing catalog
        self._pricing = PricingCatalog()
        for model_name, prices in self._config.pricing_overrides.items():
            self._pricing.set(
                model_name,
                prices.get("provider", "custom"),
                prices.get("input_per_1m", 0),
                prices.get("output_per_1m", 0),
            )

        # Local storage
        if storage_dir:
            costs_path = Path(storage_dir)
        else:
            project_root = find_project_root()
            costs_path = project_root / self._config.costs_dir
        self._storage = LocalStorage(str(costs_path), self._config.project)

        # Kill-switch state: set to True when server reports project is suspended
        self._suspended = False

        # Remote sync (no background thread — upload per-call)
        # Server validates user + email against a whitelist.
        self._sync: Optional[RemoteSync] = None
        if self._config.remote_url:
            self._sync = RemoteSync(
                remote_url=self._config.remote_url,
                user=self._config.user,
                email=self._config.email,
            )
            atexit.register(self._shutdown)

            # Startup self-healing: flush any stale unsynced records from previous runs
            self._auto_flush_stale()

            # Init-time check: fail fast if project is already suspended
            self._check_project_status()

        logger.info(
            f"CostTracker initialized: project={self._config.project}, "
            f"user={self._config.user}, email={self._config.email}, "
            f"remote={'✓' if self._sync else '✗'}"
        )

    def wrap(self, client: Any) -> Any:
        """
        Wrap any supported LLM client to transparently track usage.

        Supported clients:
        - openai.OpenAI (including third-party proxies with custom base_url)
        - google.genai.Client
        - anthropic.Anthropic

        The client is patched in-place and returned as-is, preserving IDE
        autocompletion and type hints.

        For unsupported providers, use tracker.record() for manual tracking.
        """
        from hong_lab_ai_cost.wrapper import detect_and_wrap
        return detect_and_wrap(client, self)

    def record(
        self,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
        task: str = "",
        dataset: str = "",
        metadata: Optional[dict] = None,
    ) -> str:
        """
        Manually record a usage entry (for non-OpenAI APIs or custom tracking).

        Each call is saved locally AND immediately uploaded to the remote API
        (if configured). If the upload fails, the record stays local and will
        be retried at flush() or process exit.

        Returns:
            The record ID.

        Raises:
            ProjectSuspendedError: If the project has been suspended by admin.
        """
        cost = self._pricing.calculate_cost(model, prompt_tokens, completion_tokens)
        record = {
            "user": self._config.user or "unknown",
            "email": self._config.email or "",
            "project": self._config.project,
            "model": model,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
            "cost_usd": round(cost, 6),
            "task": task,
            "dataset": dataset,
        }
        if metadata:
            record["metadata"] = metadata

        # 1. Save locally (storage.append adds id, timestamp, synced flag)
        record_id = self._storage.append(record)

        logger.debug(
            f"Recorded: model={model}, tokens={prompt_tokens}+{completion_tokens}, "
            f"cost=${cost:.4f}"
        )

        # 2. Immediately upload to remote (if configured)
        if self._sync:
            full_record = {**record, "id": record_id}
            result = self._sync.upload_one(full_record)
            if result.synced:
                self._storage.mark_synced({record_id})
                # Piggyback flush: retry stale records on successful upload
                self._sync.flush(self._storage)

            # Kill switch: server reported project is suspended
            if result.suspended:
                self._suspended = True
                logger.warning(
                    f"⛔ Project '{self._config.project}' has been SUSPENDED by admin. "
                    f"All further API calls will be blocked."
                )
                raise ProjectSuspendedError(
                    f"⛔ Project '{self._config.project}' has been suspended by admin.\n"
                    f"   All API calls are blocked. Contact your admin to resume."
                )

        return record_id

    def check_suspended(self):
        """Check if the project is currently suspended. Raises if so.

        Called by wrapper before each LLM API call.
        """
        if self._suspended:
            raise ProjectSuspendedError(
                f"⛔ Project '{self._config.project}' is suspended by admin.\n"
                f"   API call blocked. Contact your admin to resume."
            )

    def summary(self) -> dict:
        """Get the current aggregated cost summary."""
        return self._storage.get_summary()

    def flush(self):
        """Force sync of all unsynced records to remote (e.g. after a batch run)."""
        if self._sync:
            self._sync.flush(self._storage)

    @property
    def pricing(self) -> PricingCatalog:
        """Access the pricing catalog to view or modify model prices."""
        return self._pricing

    @property
    def config(self) -> TrackerConfig:
        """Access the resolved configuration."""
        return self._config

    def _auto_flush_stale(self):
        """Startup self-healing: retry uploading stale unsynced records.

        When the server was down (e.g., for hours), records accumulate locally
        with synced=false. On next startup, this method auto-retries them all.
        """
        try:
            count = self._sync.flush(self._storage)
            if count:
                logger.info(f"Auto-flushed {count} stale records from previous session")
        except Exception:
            pass  # Don't block startup on flush failure

    def _check_project_status(self):
        """Init-time check: fail fast if project is already suspended.

        Prevents students from wasting an LLM call before discovering
        the project is suspended.
        """
        try:
            status = self._sync.check_project_status(self._config.project)
            if status.get("is_suspended"):
                self._suspended = True
                raise ProjectSuspendedError(
                    f"⛔ Project '{self._config.project}' is currently suspended by admin.\n"
                    f"   Cannot start. Contact your admin to resume the project."
                )
        except ProjectSuspendedError:
            raise  # Re-raise our own exception
        except Exception as e:
            # Network error during status check — don't block startup
            logger.debug(f"Project status check skipped: {e}")

    def _shutdown(self):
        """Cleanup: flush remaining unsynced records at process exit."""
        if self._sync:
            try:
                self._sync.flush(self._storage)
            except Exception:
                pass
