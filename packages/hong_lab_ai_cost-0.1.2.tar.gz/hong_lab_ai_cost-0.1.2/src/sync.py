"""
Remote sync: upload local usage records to the remote API.

Design:
- Each API call is uploaded immediately after being recorded locally.
- If the upload fails (network error, server down), the record stays
  local (synced=false) and will be retried on the next flush() or
  at process exit via atexit.
- No background threads — simple and predictable for research scripts.

Authentication:
- Sends X-Lab-User and X-Lab-Email headers with each request.
- Server validates these against a whitelist.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

import requests

logger = logging.getLogger("hong_lab_ai_cost.sync")


@dataclass
class UploadResult:
    """Result of a single upload_one() or flush() call."""
    synced: bool = False
    suspended_projects: list[str] = field(default_factory=list)

    @property
    def suspended(self) -> bool:
        return len(self.suspended_projects) > 0


class RemoteSync:
    """Syncs local usage records to the remote cost-tracker API."""

    def __init__(
        self,
        remote_url: str,
        user: Optional[str] = None,
        email: Optional[str] = None,
        batch_size: int = 50,
    ):
        self._remote_url = remote_url.rstrip("/")
        self._user = user
        self._email = email
        self._batch_size = batch_size

    @property
    def upload_url(self) -> str:
        return f"{self._remote_url}/api/v1/usage/batch"

    def _build_headers(self) -> dict:
        """Build request headers with user/email for server-side whitelist validation."""
        headers = {"Content-Type": "application/json"}
        if self._user:
            headers["X-Lab-User"] = self._user
        if self._email:
            headers["X-Lab-Email"] = self._email
        return headers

    def upload_one(self, record: dict) -> UploadResult:
        """
        Upload a single record immediately after it is recorded.

        Returns an UploadResult with synced=True on success,
        and any suspended_projects reported by the server.
        On failure the record stays local (synced=false) for later retry.
        """
        try:
            resp = requests.post(
                self.upload_url,
                json={"records": [record]},
                headers=self._build_headers(),
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()
            suspended = data.get("suspended_projects", [])
            logger.debug(f"Uploaded record {record.get('id', '?')} to remote")
            return UploadResult(synced=True, suspended_projects=suspended)
        except Exception as e:
            logger.warning(f"Upload failed (record kept locally): {e}")
            return UploadResult(synced=False)

    def flush(self, storage) -> int:
        """
        Retry uploading all unsynced local records in batches.
        Called at atexit or manually via tracker.flush().
        Returns the number of records successfully synced.
        """
        total_synced = 0
        try:
            while True:
                unsynced = storage.get_unsynced(limit=self._batch_size)
                if not unsynced:
                    break

                resp = requests.post(
                    self.upload_url,
                    json={"records": unsynced},
                    headers=self._build_headers(),
                    timeout=30,
                )
                resp.raise_for_status()
                data = resp.json()
                synced_ids = set(data.get("synced_ids", [r["id"] for r in unsynced]))

                if synced_ids:
                    storage.mark_synced(synced_ids)
                    total_synced += len(synced_ids)
                else:
                    break
        except Exception as e:
            logger.warning(f"Flush sync failed: {e}")

        if total_synced:
            logger.info(f"Flushed {total_synced} unsynced records to remote")
        return total_synced

    def check_project_status(self, project: str) -> dict:
        """Lightweight check if project is suspended (called at SDK init).

        Returns {"is_suspended": bool, "project": str}.
        On failure, returns {"is_suspended": False} to avoid blocking startup.
        """
        try:
            resp = requests.get(
                f"{self._remote_url}/api/v1/projects/{project}/status",
                headers=self._build_headers(),
                timeout=5,
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            logger.warning(f"Project status check failed (assuming active): {e}")
            return {"is_suspended": False, "project": project}
