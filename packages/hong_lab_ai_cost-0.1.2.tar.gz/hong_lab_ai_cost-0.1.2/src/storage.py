"""
Local storage: dual-file strategy.

- detail.jsonl  — append-only, one record per API call (full detail)
- summary.json  — aggregated view, updated after each call (easy to read)
"""

from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from uuid import uuid4


class LocalStorage:
    """Thread-safe local cost storage with detail + summary files."""

    def __init__(self, costs_dir: str, project: str):
        self._dir = Path(costs_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._detail_path = self._dir / "detail.jsonl"
        self._summary_path = self._dir / "summary.json"
        self._sync_state_path = self._dir / "sync_state.json"
        self._project = project
        self._lock = threading.Lock()
        self._summary = self._load_summary()

    # ── Public API ──────────────────────────────────────────────────────────

    def append(self, record: dict) -> str:
        """Append a usage record. Returns the record ID."""
        record_id = str(uuid4())
        record = {
            "id": record_id,
            "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "project": self._project,
            "synced": False,
            **record,
        }

        with self._lock:
            # 1. Append to detail log
            with open(self._detail_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

            # 2. Update summary
            self._update_summary(record)
            self._save_summary()

        return record_id

    def get_unsynced(self, limit: int = 100) -> list[dict]:
        """Read unsynced records from detail.jsonl."""
        records = []
        if not self._detail_path.exists():
            return records
        with open(self._detail_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                rec = json.loads(line)
                if not rec.get("synced", False):
                    records.append(rec)
                    if len(records) >= limit:
                        break
        return records

    def mark_synced(self, record_ids: set[str]):
        """Mark records as synced in detail.jsonl."""
        if not self._detail_path.exists() or not record_ids:
            return
        lines = []
        with open(self._detail_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                rec = json.loads(line)
                if rec.get("id") in record_ids:
                    rec["synced"] = True
                lines.append(json.dumps(rec, ensure_ascii=False))

        with open(self._detail_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

    def get_summary(self) -> dict:
        """Return the current summary."""
        return dict(self._summary)

    # ── Internal ────────────────────────────────────────────────────────────

    def _load_summary(self) -> dict:
        if self._summary_path.exists():
            with open(self._summary_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {
            "project": self._project,
            "total_cost_usd": 0.0,
            "total_prompt_tokens": 0,
            "total_completion_tokens": 0,
            "total_requests": 0,
            "by_model": {},
            "by_user": {},
            "last_updated": None,
        }

    def _update_summary(self, record: dict):
        s = self._summary
        cost = record.get("cost_usd", 0.0)
        prompt_t = record.get("prompt_tokens", 0)
        completion_t = record.get("completion_tokens", 0)
        model = record.get("model", "unknown")
        user = record.get("user", "unknown")

        s["total_cost_usd"] = round(s["total_cost_usd"] + cost, 6)
        s["total_prompt_tokens"] += prompt_t
        s["total_completion_tokens"] += completion_t
        s["total_requests"] += 1
        s["last_updated"] = record.get("timestamp")

        # By model
        if model not in s["by_model"]:
            s["by_model"][model] = {"cost_usd": 0.0, "requests": 0, "prompt_tokens": 0, "completion_tokens": 0}
        m = s["by_model"][model]
        m["cost_usd"] = round(m["cost_usd"] + cost, 6)
        m["requests"] += 1
        m["prompt_tokens"] += prompt_t
        m["completion_tokens"] += completion_t

        # By user
        if user not in s["by_user"]:
            s["by_user"][user] = {"cost_usd": 0.0, "requests": 0}
        u = s["by_user"][user]
        u["cost_usd"] = round(u["cost_usd"] + cost, 6)
        u["requests"] += 1

    def _save_summary(self):
        with open(self._summary_path, "w", encoding="utf-8") as f:
            json.dump(self._summary, f, indent=2, ensure_ascii=False)
