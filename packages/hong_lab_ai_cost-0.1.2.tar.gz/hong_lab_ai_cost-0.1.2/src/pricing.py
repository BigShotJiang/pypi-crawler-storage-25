"""
Pricing catalog for common LLM models.

Prices are in USD per 1M tokens (input / output).
Sources: official provider pricing pages (2024-05).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class ModelPrice:
    provider: str
    input_per_1m: float   # USD per 1M prompt tokens
    output_per_1m: float  # USD per 1M completion tokens


# ── Default price table ────────────────────────────────────────────────────
_DEFAULT_PRICES: dict[str, ModelPrice] = {
    # OpenAI
    "gpt-4o":               ModelPrice("openai",    5.00,  15.00),
    "gpt-4o-mini":          ModelPrice("openai",    0.15,   0.60),
    "gpt-4-turbo":          ModelPrice("openai",   10.00,  30.00),
    "gpt-4":                ModelPrice("openai",   30.00,  60.00),
    "gpt-3.5-turbo":        ModelPrice("openai",    0.50,   1.50),
    "o1":                   ModelPrice("openai",   15.00,  60.00),
    "o1-mini":              ModelPrice("openai",    3.00,  12.00),
    "o3-mini":              ModelPrice("openai",    1.10,   4.40),
    # Anthropic
    "claude-3-5-sonnet-20241022": ModelPrice("anthropic",  3.00,  15.00),
    "claude-3-5-haiku-20241022":  ModelPrice("anthropic",  0.80,   4.00),
    "claude-3-opus-20240229":     ModelPrice("anthropic", 15.00,  75.00),
    "claude-3-haiku-20240307":    ModelPrice("anthropic",  0.25,   1.25),
    # Google Gemini (via AI Studio / Vertex)
    "gemini-2.5-pro":       ModelPrice("google",    1.25,  10.00),
    "gemini-2.5-flash":     ModelPrice("google",    0.15,   0.60),
    "gemini-2.0-flash":     ModelPrice("google",    0.10,   0.40),
    "gemini-1.5-pro":       ModelPrice("google",    1.25,   5.00),
    "gemini-1.5-flash":     ModelPrice("google",    0.075,  0.30),
}


class PricingCatalog:
    """Lookup and override model pricing."""

    def __init__(self):
        # shallow copy so overrides don't affect the global dict
        self._prices: dict[str, ModelPrice] = dict(_DEFAULT_PRICES)

    def get(self, model: str) -> Optional[ModelPrice]:
        """Return ModelPrice for *model*, or None if not found."""
        # Exact match first
        if model in self._prices:
            return self._prices[model]
        # Prefix match (e.g., "gpt-4o-mini-2024-07-18" → "gpt-4o-mini")
        for key, price in self._prices.items():
            if model.startswith(key):
                return price
        return None

    def set(
        self,
        model: str,
        provider: str,
        input_per_1m: float,
        output_per_1m: float,
    ):
        """Add or override a model's pricing."""
        self._prices[model] = ModelPrice(provider, input_per_1m, output_per_1m)

    def calculate_cost(
        self,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
    ) -> float:
        """Return estimated cost in USD."""
        price = self.get(model)
        if price is None:
            return 0.0
        return (
            prompt_tokens / 1_000_000 * price.input_per_1m
            + completion_tokens / 1_000_000 * price.output_per_1m
        )

    def list_models(self) -> list[dict]:
        """Return all known models as a list of dicts."""
        return [
            {
                "model": name,
                "provider": p.provider,
                "input_per_1m_usd": p.input_per_1m,
                "output_per_1m_usd": p.output_per_1m,
            }
            for name, p in sorted(self._prices.items())
        ]
