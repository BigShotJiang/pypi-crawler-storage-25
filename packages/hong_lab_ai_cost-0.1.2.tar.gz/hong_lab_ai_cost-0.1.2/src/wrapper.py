"""
Multi-provider adapter: auto-detect and patch client methods for cost tracking.

Supported providers:
- OpenAI (including third-party proxies with custom base_url, e.g. apiyihe.org)
- Google Gemini (google-genai SDK)
- Anthropic

Design: monkey-patch the original client's methods instead of proxy objects,
so IDE autocompletion and type hints are preserved.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from hong_lab_ai_cost.tracker import CostTracker

logger = logging.getLogger("hong_lab_ai_cost")

# ── Sentinel to prevent double-wrapping ─────────────────────────────────────
_PATCHED_ATTR = "_hong_lab_ai_cost_patched"


def detect_and_wrap(client: Any, tracker: CostTracker) -> Any:
    """
    Auto-detect the provider from the client type and patch it for tracking.

    Returns the **original** client (patched in-place), preserving IDE
    autocompletion and type hints.

    Raises TypeError if the client type is not recognized.
    """
    if getattr(client, _PATCHED_ATTR, False):
        logger.warning("Client is already wrapped — skipping double-wrap.")
        return client

    module = getattr(type(client), "__module__", "") or ""
    cls_name = type(client).__name__

    if "openai" in module:
        _wrap_openai(client, tracker)
    elif "google" in module:
        _wrap_gemini(client, tracker)
    elif "anthropic" in module:
        _wrap_anthropic(client, tracker)
    else:
        raise TypeError(
            f"Unsupported client type: {cls_name} (module={module}). "
            f"Supported: openai.OpenAI, google.genai.Client, anthropic.Anthropic. "
            f"Use tracker.record() for manual tracking of other providers."
        )

    object.__setattr__(client, _PATCHED_ATTR, True)
    logger.info(f"Wrapped {cls_name} client for cost tracking")
    return client


# ── OpenAI adapter (also handles third-party proxies) ───────────────────────

def _wrap_openai(client: Any, tracker: CostTracker) -> None:
    """Patch OpenAI client. Works for official API and proxies (apiyihe.org etc.)."""
    original_create = client.chat.completions.create

    # Capture base_url to distinguish official vs third-party
    base_url = str(getattr(client, "base_url", "https://api.openai.com"))

    def tracked_create(*args, **kwargs):
        tracker.check_suspended()  # Kill switch: block if project suspended
        response = original_create(*args, **kwargs)
        usage = getattr(response, "usage", None)
        if usage:
            tracker.record(
                model=getattr(response, "model", kwargs.get("model", "unknown")),
                prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0,
                completion_tokens=getattr(usage, "completion_tokens", 0) or 0,
                metadata={"provider": "openai", "base_url": base_url},
            )
        return response

    client.chat.completions.create = tracked_create


# ── Gemini adapter (google-genai SDK) ───────────────────────────────────────

def _wrap_gemini(client: Any, tracker: CostTracker) -> None:
    """Patch google.genai.Client for cost tracking."""
    original_generate = client.models.generate_content

    def tracked_generate(*args, **kwargs):
        tracker.check_suspended()  # Kill switch: block if project suspended
        response = original_generate(*args, **kwargs)
        meta = getattr(response, "usage_metadata", None)
        if meta:
            # Model name comes from the call arguments, not the response
            model = kwargs.get("model") or (args[0] if args else "unknown")
            tracker.record(
                model=str(model),
                prompt_tokens=getattr(meta, "prompt_token_count", 0) or 0,
                completion_tokens=getattr(meta, "candidates_token_count", 0) or 0,
                metadata={"provider": "google"},
            )
        return response

    client.models.generate_content = tracked_generate


# ── Anthropic adapter ──────────────────────────────────────────────────────

def _wrap_anthropic(client: Any, tracker: CostTracker) -> None:
    """Patch anthropic.Anthropic for cost tracking."""
    original_create = client.messages.create

    def tracked_create(*args, **kwargs):
        tracker.check_suspended()  # Kill switch: block if project suspended
        response = original_create(*args, **kwargs)
        usage = getattr(response, "usage", None)
        if usage:
            tracker.record(
                model=getattr(response, "model", kwargs.get("model", "unknown")),
                prompt_tokens=getattr(usage, "input_tokens", 0) or 0,
                completion_tokens=getattr(usage, "output_tokens", 0) or 0,
                metadata={"provider": "anthropic"},
            )
        return response

    client.messages.create = tracked_create
