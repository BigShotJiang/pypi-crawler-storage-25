"""
YAML / environment variable configuration loader.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml


_CONFIG_FILENAME = ".cost-tracker.yaml"


@dataclass
class TrackerConfig:
    """Resolved configuration for CostTracker."""
    project: str = "default"
    user: Optional[str] = None           # Display name (e.g., "kyle")
    email: Optional[str] = None          # Email for server whitelist (e.g., "kyle@aucklanduni.ac.nz")
    remote_url: Optional[str] = None     # e.g. https://cost-api-xxxx.run.app
    costs_dir: str = ".cost-tracker"     # relative to project root (hidden dir)
    pricing_overrides: dict[str, dict] = field(default_factory=dict)


def find_project_root(start: Optional[str] = None) -> Path:
    """Walk up from *start* (default: cwd) looking for .cost-tracker.yaml or .git."""
    p = Path(start) if start else Path.cwd()
    for directory in [p, *p.parents]:
        if (directory / _CONFIG_FILENAME).exists():
            return directory
        if (directory / ".git").exists():
            return directory
    return p


def load_config(
    project: Optional[str] = None,
    user: Optional[str] = None,
    email: Optional[str] = None,
    remote_url: Optional[str] = None,
    config_path: Optional[str] = None,
) -> TrackerConfig:
    """
    Load config with priority: explicit args > env vars > YAML file > defaults.
    """
    cfg = TrackerConfig()

    # ── 1. YAML file ──
    if config_path:
        yaml_path = Path(config_path)
    else:
        yaml_path = find_project_root() / _CONFIG_FILENAME

    if yaml_path.exists():
        with open(yaml_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        cfg.project = data.get("project", cfg.project)
        cfg.user = data.get("user", cfg.user)
        cfg.email = data.get("email", cfg.email)
        cfg.remote_url = data.get("remote_url", cfg.remote_url)
        cfg.costs_dir = data.get("costs_dir", cfg.costs_dir)
        cfg.pricing_overrides = data.get("pricing", {})

    # ── 2. Environment variables ──
    cfg.project = os.getenv("COST_TRACKER_PROJECT", cfg.project)
    cfg.user = os.getenv("COST_TRACKER_USER", cfg.user)
    cfg.email = os.getenv("COST_TRACKER_EMAIL", cfg.email)
    cfg.remote_url = os.getenv("COST_TRACKER_REMOTE_URL", cfg.remote_url)

    # ── 3. Explicit arguments (highest priority) ──
    if project:
        cfg.project = project
    if user:
        cfg.user = user
    if email:
        cfg.email = email
    if remote_url:
        cfg.remote_url = remote_url

    return cfg
