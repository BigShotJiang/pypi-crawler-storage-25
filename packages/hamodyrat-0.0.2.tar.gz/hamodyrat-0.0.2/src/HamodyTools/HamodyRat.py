try:
	import requests
	from uuid import uuid4
	import uuid
	import urllib3
	urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ModuleNotFoundError:
	import os
	os.system("pip install uuid4")
class Hamody:
	def facebook(email):
		device_id = str(uuid4())
		url = "https://b-graph.facebook.com/auth/login"
		headers = {
    "Authorization": "OAuth 200424423651082|2a9918c6bcd75b94cefcbb5635c6ad16",
    "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 12; SM-G998B Build/SP1A.210812.016) [FBAN/FB4A;FBAV/400.0.0.31.81;FBPN/com.facebook.katana;FBLC/ar_EG;FBBV/443217422;FBMF/samsung;FBBD/samsung;FBDV/SM-G998B;FBSV/12;FBCA/arm64-v8a:null;FBDM/{density=3.0,width=1440,height=3200};]",
    "Content-Type": "application/x-www-form-urlencoded",
    "X-FB-Connection-Type": "WIFI",
    "X-FB-Capabilities": "36r/3Ok=",
    "X-FB-Net-HNI": "60202", 
    "X-FB-SIM-HNI": "60202"
}
		data = {
    "email": email,
    "password": "Hamodyrats",
    "credentials_type": "password",
    "error_detail_type": "button_with_disabled",
    "format": "json",
    "device_id": device_id,
    "generate_session_cookies": "1",
    "generate_analytics_claim": "1",
    "generate_machine_id": "1",
    "method": "POST"
}
		r = requests.post(url, data=data, headers=headers, verify=False, timeout=15).json()
		if r["error"]["error_user_msg"]=="The email you entered doesn't appear to belong to an account. Please check your email address and try again.":
			return False
		elif r["error"]["error_user_msg"]=="Invalid username or password":
			return True