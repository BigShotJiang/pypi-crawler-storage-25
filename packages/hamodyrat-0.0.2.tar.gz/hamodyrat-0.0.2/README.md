<h1 align="center">HamodyToola</h1>
<p align="center">It's a Usefull Project for Developers ... It checkers Emails Found Or Not Found</p>

<p align="center"> • DevVlopered The Lib BY Hamody • </p>


## Installing :
```
pip install HamodyRat

```
## • Get Email instagram •

from HamodyRat import Hamody

email = "m********@gmail.com"

r = Hamody.facebook(email)

print(r)

```