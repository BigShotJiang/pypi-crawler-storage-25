"""Exact token counting using tiktoken."""

import json
from typing import Any

import tiktoken

# Global encoding cache for performance
_encoding_cache: tiktoken.Encoding | None = None


def count_tokens_exact(
    messages: list[dict[str, Any]], model: str | None = None
) -> int:
    """Count exact tokens for messages using tiktoken.

    Uses cl100k_base encoding (GPT-4/Claude tokenizer) which provides accurate
    counts for most modern LLMs. Model parameter is optional and primarily for
    future extensibility.

    Args:
        messages: Messages in model format
        model: Optional model name (currently unused, defaults to cl100k_base)

    Returns:
        Exact token count
    """

    # Use cl100k_base encoding (GPT-4/Claude/most modern LLMs)
    # This provides accurate token counts for:
    # - All Claude models (3, 3.5, 4.x)
    # - GPT-4 and GPT-3.5-turbo
    # - Most other transformer-based models
    encoding_name = "cl100k_base"

    # Future: could add model-specific encodings here if needed
    # For now, cl100k_base is universal enough

    encoding = tiktoken.get_encoding(encoding_name)

    total_tokens = 0

    for message in messages:
        # Count role
        total_tokens += len(encoding.encode(message.get("role", ""), disallowed_special=()))

        # Count content
        content = message.get("content", "")
        if isinstance(content, str):
            total_tokens += len(encoding.encode(content, disallowed_special=()))
        elif isinstance(content, list):
            # Handle structured content (parts)
            for part in content:
                if isinstance(part, dict):
                    if "text" in part:
                        total_tokens += len(encoding.encode(part["text"], disallowed_special=()))
                    if "type" in part:
                        total_tokens += len(encoding.encode(part["type"], disallowed_special=()))
                    # Tool use/result structures
                    if "tool_use_id" in part:
                        total_tokens += len(
                            encoding.encode(part["tool_use_id"], disallowed_special=())
                        )
                    if "name" in part:
                        total_tokens += len(
                            encoding.encode(part["name"], disallowed_special=())
                        )
                    if "input" in part:
                        # Tool input is usually a dict
                        total_tokens += len(
                            encoding.encode(
                                json.dumps(part["input"]), disallowed_special=()
                            )
                        )
                    if "content" in part:
                        total_tokens += len(
                            encoding.encode(str(part["content"]), disallowed_special=())
                        )

        # Message formatting overhead (approximate)
        # Each message has some structural tokens
        total_tokens += 4

    return total_tokens


def get_encoding() -> tiktoken.Encoding:
    """Get cached encoding for performance.

    Caches the encoding globally to avoid repeated loading.
    Uses cl100k_base (GPT-4/Claude tokenizer).

    Returns:
        Cached tiktoken encoding
    """
    global _encoding_cache
    if _encoding_cache is None:
        _encoding_cache = tiktoken.get_encoding("cl100k_base")
    return _encoding_cache


def count_tokens_fast(text: str) -> int:
    """Fast exact token counting for plain text.

    Optimized for pruning decisions where we count many outputs.
    Uses cached encoding to avoid repeated loading.

    Args:
        text: Plain text to count tokens for

    Returns:
        Exact token count
    """
    if not text:
        return 0

    encoding = get_encoding()
    return len(encoding.encode(text, disallowed_special=()))
