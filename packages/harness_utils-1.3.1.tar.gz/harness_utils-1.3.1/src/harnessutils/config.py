"""Configuration schema for harness-utils."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class TruncationConfig:
    """Configuration for Tier 1: Output truncation."""

    max_lines: int = 2000
    max_bytes: int = 50 * 1024  # 50KB
    direction: str = "head"  # "head" or "tail"

    # Phase 2: Content-aware truncation
    max_tokens: int = 2000  # Token-based limit
    use_content_aware: bool = True  # Enable content-aware truncation
    preserve_errors: bool = True  # Keep all errors/warnings in logs
    json_array_limit: int = 10  # Keep first/last N items in JSON arrays
    stacktrace_frame_limit: int = 20  # Keep top/bottom N frames in stacktraces

    def validate(self) -> None:
        """Validate truncation configuration.

        Raises:
            ConfigurationError: If configuration is invalid
        """
        from harnessutils.exceptions import ConfigurationError

        if self.max_lines <= 0:
            raise ConfigurationError(
                f"max_lines must be positive, got {self.max_lines}",
                "Set max_lines to a positive integer (e.g., 2000)",
            )

        if self.max_bytes <= 0:
            raise ConfigurationError(
                f"max_bytes must be positive, got {self.max_bytes}",
                "Set max_bytes to a positive integer (e.g., 50000)",
            )

        if self.max_tokens <= 0:
            raise ConfigurationError(
                f"max_tokens must be positive, got {self.max_tokens}",
                "Set max_tokens to a positive integer (e.g., 2000)",
            )

        if self.direction not in ["head", "tail"]:
            raise ConfigurationError(
                f"direction must be 'head' or 'tail', got '{self.direction}'",
                "Set direction to either 'head' (keep beginning) or 'tail' (keep end)",
            )

        if self.json_array_limit <= 0:
            raise ConfigurationError(
                f"json_array_limit must be positive, got {self.json_array_limit}",
                "Set json_array_limit to a positive integer (e.g., 10)",
            )

        if self.stacktrace_frame_limit <= 0:
            raise ConfigurationError(
                f"stacktrace_frame_limit must be positive, got {self.stacktrace_frame_limit}",
                "Set stacktrace_frame_limit to a positive integer (e.g., 20)",
            )


@dataclass
class PruningConfig:
    """Configuration for Tier 2: Selective pruning."""

    prune_protect: int = 40_000  # Keep recent 40K tokens
    prune_minimum: int = 20_000  # Only prune if saves 20K+ tokens
    protect_turns: int = 2  # Protect last 2 turns
    protected_tools: list[str] = field(
        default_factory=lambda: ["skill_execution", "subtask_invocation"]
    )

    # Importance scoring (Phase 1.2)
    use_importance_scoring: bool = True  # Enable smart pruning
    recency_weight: float = 1.0  # Weight for recency score
    size_weight: float = -0.5  # Weight for size penalty (negative)
    semantic_weight: float = 2.0  # Weight for semantic importance
    tool_priority_weight: float = 1.5  # Weight for tool type priority
    recency_decay: float = 0.1  # Exponential decay rate per turn

    # Tool importance map (higher = more important)
    tool_importance: dict[str, float] = field(
        default_factory=lambda: {
            "read": 50.0,
            "write": 100.0,  # Code changes are important
            "edit": 100.0,
            "grep": 30.0,  # Search results often repetitive
            "glob": 30.0,
            "bash": 70.0,
            "skill_execution": 150.0,  # Complex operations
            "subtask_invocation": 150.0,
            "error": 200.0,  # Critical for debugging
        }
    )

    # Semantic boost scores
    error_boost: float = 500.0  # Boost for outputs with errors
    warning_boost: float = 200.0  # Boost for warnings
    user_requested_boost: float = 300.0  # User explicitly asked for this

    # Query-conditioned re-scoring
    query_weight: float = 1.5  # Weight for query relevance boost

    # Deduplication (Phase 1.3)
    detect_duplicates: bool = True  # Enable duplicate detection
    similarity_threshold: float = 0.8  # Similarity threshold (0.0-1.0)
    duplicate_lookback: int = 20  # Check last N outputs for duplicates

    def validate(self) -> None:
        """Validate pruning configuration.

        Raises:
            ConfigurationError: If configuration is invalid
        """
        from harnessutils.exceptions import ConfigurationError

        if self.prune_minimum >= self.prune_protect:
            raise ConfigurationError(
                f"prune_minimum ({self.prune_minimum}) must be < "
                f"prune_protect ({self.prune_protect})",
                "Set prune_minimum to a value less than prune_protect. "
                "Example: prune_minimum=20000, prune_protect=40000",
            )

        if self.protect_turns < 0:
            raise ConfigurationError(
                f"protect_turns must be >= 0, got {self.protect_turns}",
                "Set protect_turns to 0 or more (e.g., 2 to protect last 2 turns)",
            )

        if self.similarity_threshold < 0.0 or self.similarity_threshold > 1.0:
            raise ConfigurationError(
                f"similarity_threshold must be between 0.0 and 1.0, "
                f"got {self.similarity_threshold}",
                "Set similarity_threshold to a value between 0.0 (loose matching) "
                "and 1.0 (exact matching). Try 0.8 for most cases.",
            )

        if self.duplicate_lookback <= 0:
            raise ConfigurationError(
                f"duplicate_lookback must be positive, got {self.duplicate_lookback}",
                "Set duplicate_lookback to a positive integer (e.g., 20)",
            )

        # Check weights are non-negative
        for weight_name in [
            "recency_weight",
            "semantic_weight",
            "tool_priority_weight",
            "error_boost",
            "warning_boost",
            "user_requested_boost",
        ]:
            weight = getattr(self, weight_name)
            if weight < 0:
                raise ConfigurationError(
                    f"{weight_name} must be >= 0, got {weight}",
                    f"Set {weight_name} to a non-negative value",
                )


@dataclass
class TokenConfig:
    """Configuration for token estimation."""

    chars_per_token: int = 4


@dataclass
class ModelLimitsConfig:
    """Configuration for model limits."""

    default_context_limit: int = 200_000
    default_output_limit: int = 8_192

    def validate(self) -> None:
        """Validate model limits configuration.

        Raises:
            ConfigurationError: If configuration is invalid
        """
        from harnessutils.exceptions import ConfigurationError

        if self.default_context_limit <= 0:
            raise ConfigurationError(
                f"default_context_limit must be positive, got {self.default_context_limit}",
                "Set default_context_limit to your model's context window size (e.g., 200000)",
            )

        if self.default_output_limit <= 0:
            raise ConfigurationError(
                f"default_output_limit must be positive, got {self.default_output_limit}",
                "Set default_output_limit to your model's max output tokens (e.g., 8192)",
            )

        if self.default_output_limit >= self.default_context_limit:
            raise ConfigurationError(
                f"default_output_limit ({self.default_output_limit}) must be < "
                f"default_context_limit ({self.default_context_limit})",
                "Set default_output_limit to less than default_context_limit. "
                "Example: context_limit=200000, output_limit=8192",
            )


@dataclass
class StorageConfig:
    """Configuration for storage layer."""

    base_path: Path = field(default_factory=lambda: Path("data"))
    retention_days: int = 7  # For truncated outputs


@dataclass
class SummarizationConfig:
    """Configuration for Tier 3: Summarization.

    Note: Model selection is user-controlled. Set differential_model and full_model
    to match your LLM provider, or pass model parameter directly to compact().
    If not set, your LLMClient.invoke() will receive None and should use its own default.
    """

    mode: str = "differential"  # "differential" or "full"
    differential_model: str | None = None  # Optional: model for differential mode
    full_model: str | None = None  # Optional: model for full mode
    max_messages_since_summary: int = 30  # Force full if exceeded
    summarization_prompt: str | None = None  # None → use SUMMARIZATION_PROMPT constant
    differential_prompt: str | None = None  # None → use DIFFERENTIAL_SUMMARIZATION_PROMPT
    include_tool_outputs: bool = True  # Include tool outputs in summarization input
    tool_output_max_tokens: int = 300  # Max tokens per tool output in summarization

    def validate(self) -> None:
        """Validate summarization configuration.

        Raises:
            ConfigurationError: If configuration is invalid
        """
        from harnessutils.exceptions import ConfigurationError

        if self.mode not in ["differential", "full"]:
            raise ConfigurationError(
                f"mode must be 'differential' or 'full', got '{self.mode}'",
                "Set mode to either 'differential' (incremental) or 'full' "
                "(complete re-summarization)",
            )

        if self.max_messages_since_summary <= 0:
            raise ConfigurationError(
                f"max_messages_since_summary must be positive, "
                f"got {self.max_messages_since_summary}",
                "Set max_messages_since_summary to a positive integer (e.g., 30)",
            )


@dataclass
class CompactionConfig:
    """Configuration for context compaction."""

    auto: bool = True  # Enable auto-summarization
    prune: bool = True  # Enable pruning

    # Phase 2: Predictive overflow detection
    use_predictive: bool = True  # Enable predictive overflow detection
    predictive_lookahead: int = 5  # Predict N turns ahead
    predictive_safety_margin: float = 0.8  # Trigger at 80% of limit

    def validate(self) -> None:
        """Validate compaction configuration.

        Raises:
            ConfigurationError: If configuration is invalid
        """
        from harnessutils.exceptions import ConfigurationError

        if self.predictive_lookahead <= 0:
            raise ConfigurationError(
                f"predictive_lookahead must be positive, got {self.predictive_lookahead}",
                "Set predictive_lookahead to a positive integer (e.g., 5 turns ahead)",
            )

        if self.predictive_safety_margin <= 0.0 or self.predictive_safety_margin >= 1.0:
            raise ConfigurationError(
                f"predictive_safety_margin must be between 0.0 and 1.0 "
                f"(exclusive), got {self.predictive_safety_margin}",
                "Set predictive_safety_margin to a value like 0.8 "
                "(trigger at 80% of limit)",
            )


@dataclass
class HarnessConfig:
    """Main configuration for harness-utils.

    Provides all configuration parameters for context window management
    with sensible defaults from the CTXWINARCH.md specification.
    """

    truncation: TruncationConfig = field(default_factory=TruncationConfig)
    pruning: PruningConfig = field(default_factory=PruningConfig)
    tokens: TokenConfig = field(default_factory=TokenConfig)
    model_limits: ModelLimitsConfig = field(default_factory=ModelLimitsConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)
    compaction: CompactionConfig = field(default_factory=CompactionConfig)
    summarization: SummarizationConfig = field(default_factory=SummarizationConfig)

    def validate(self) -> None:
        """Validate entire configuration.

        Checks all sub-configs and cross-config constraints.

        Raises:
            ConfigurationError: If any configuration is invalid
        """
        from harnessutils.exceptions import ConfigurationError

        # Validate all sub-configs
        self.truncation.validate()
        self.pruning.validate()
        self.model_limits.validate()
        self.compaction.validate()
        self.summarization.validate()

        # Cross-config validations
        # 1. prune_protect must be less than context_limit
        usable_limit = (
            self.model_limits.default_context_limit
            - self.model_limits.default_output_limit
        )
        if self.pruning.prune_protect >= usable_limit:
            raise ConfigurationError(
                f"prune_protect ({self.pruning.prune_protect}) must be < "
                f"usable context ({usable_limit} = "
                f"{self.model_limits.default_context_limit} - "
                f"{self.model_limits.default_output_limit})",
                f"Set prune_protect to less than {usable_limit}. "
                f"Recommended: {int(usable_limit * 0.2)} (20% of usable context)",
            )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "HarnessConfig":
        """Create configuration from dictionary.

        Args:
            data: Configuration dictionary

        Returns:
            HarnessConfig instance
        """
        config = cls()

        if "truncation" in data:
            config.truncation = TruncationConfig(**data["truncation"])
        if "pruning" in data:
            protected = data["pruning"].get("protected_tools")
            pruning_data = {k: v for k, v in data["pruning"].items() if k != "protected_tools"}
            if protected:
                pruning_data["protected_tools"] = protected
            config.pruning = PruningConfig(**pruning_data)
        if "tokens" in data:
            config.tokens = TokenConfig(**data["tokens"])
        if "model_limits" in data:
            config.model_limits = ModelLimitsConfig(**data["model_limits"])
        if "storage" in data:
            storage_data = data["storage"].copy()
            if "base_path" in storage_data:
                storage_data["base_path"] = Path(storage_data["base_path"])
            config.storage = StorageConfig(**storage_data)
        if "compaction" in data:
            config.compaction = CompactionConfig(**data["compaction"])
        if "summarization" in data:
            config.summarization = SummarizationConfig(**data["summarization"])

        return config

    @classmethod
    def from_toml(cls, path: Path) -> "HarnessConfig":
        """Load configuration from TOML file.

        Args:
            path: Path to TOML configuration file

        Returns:
            HarnessConfig instance
        """
        import tomllib

        with open(path, "rb") as f:
            data = tomllib.load(f)

        return cls.from_dict(data)

    @classmethod
    def from_json(cls, path: Path) -> "HarnessConfig":
        """Load configuration from JSON file.

        Args:
            path: Path to JSON configuration file

        Returns:
            HarnessConfig instance
        """
        import json

        with open(path) as f:
            data = json.load(f)

        return cls.from_dict(data)
