"""Conversation model."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from harnessutils.models.velocity import ConversationVelocity

if TYPE_CHECKING:
    from harnessutils.quality import QualityHistory, QualitySnapshot


@dataclass
class Conversation:
    """A conversation containing multiple messages.

    Conversations track the overall context and metadata for a series
    of messages between user and assistant.
    """

    id: str
    project_id: str | None = None
    created: int | None = None  # Unix timestamp in milliseconds
    updated: int | None = None  # Unix timestamp in milliseconds
    pending_summarization: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def excluded_outputs(self) -> list[str]:
        """Call IDs of tool outputs excluded from API payloads."""
        return self.metadata.get("excluded_outputs", [])

    def add_excluded_outputs(self, call_ids: list[str]) -> None:
        """Accumulate excluded call IDs (deduplicates)."""
        existing = set(self.excluded_outputs)
        existing.update(call_ids)
        self.metadata["excluded_outputs"] = list(existing)

    def get_velocity(self) -> ConversationVelocity | None:
        """Get velocity tracker from metadata.

        Returns:
            ConversationVelocity instance or None if not tracked
        """
        velocity_data = self.metadata.get("velocity")
        if velocity_data is None:
            return None

        return ConversationVelocity.from_dict(velocity_data)

    def update_velocity(self, tokens_added: int) -> None:
        """Update velocity tracker with new token delta.

        Args:
            tokens_added: Tokens added in this turn
        """
        velocity = self.get_velocity()
        if velocity is None:
            velocity = ConversationVelocity()

        velocity.add_delta(tokens_added)
        self.metadata["velocity"] = velocity.to_dict()

    def get_quality_history(self) -> QualityHistory | None:
        """Get quality history from metadata.

        Returns:
            QualityHistory instance or None if not tracked
        """
        from harnessutils.quality import QualityHistory

        history_data = self.metadata.get("quality_history")
        if history_data is None:
            return None

        return QualityHistory.from_dict(history_data)

    def update_quality_history(self, snapshot: QualitySnapshot) -> None:
        """Add quality snapshot to history.

        Args:
            snapshot: Quality snapshot to add
        """
        from harnessutils.quality import QualityHistory

        history = self.get_quality_history()
        if history is None:
            history = QualityHistory()

        history.add_snapshot(snapshot)
        self.metadata["quality_history"] = history.to_dict()

    def to_dict(self) -> dict[str, Any]:
        """Convert conversation to dictionary for storage.

        Returns:
            Dictionary representation
        """
        return {
            "id": self.id,
            "project_id": self.project_id,
            "created": self.created,
            "updated": self.updated,
            "pending_summarization": self.pending_summarization,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Conversation:
        """Create conversation from dictionary.

        Args:
            data: Dictionary representation

        Returns:
            Conversation instance
        """
        return cls(
            id=data["id"],
            project_id=data.get("project_id"),
            created=data.get("created"),
            updated=data.get("updated"),
            pending_summarization=data.get("pending_summarization", False),
            metadata=data.get("metadata", {}),
        )
