"""Message lifecycle hooks for ConversationManager.

Hooks let consumers inject behaviour at the two key points in the
add_message() lifecycle without subclassing ConversationManager.

Pre-hook  (on_before_add_message)
    Fires before the message is persisted. The return value replaces
    the message that will be stored. Raising any exception rejects the
    message — it is never written to storage.

Post-hook (on_after_add_message)
    Fires after the message has been successfully persisted. The return
    value is ignored. Exceptions propagate to the caller but the message
    has already been stored.

See docs/message-hooks.md for usage guide and worked examples.
"""

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from harnessutils.models.message import Message


@dataclass
class MessageHooks:
    """Callbacks for the add_message() lifecycle.

    Pass an instance to ConversationManager() to intercept messages
    before and after they are persisted.

    Example — reject messages that contain a forbidden string::

        def guard(conv_id: str, msg: Message) -> Message:
            for part in msg.parts:
                if part.type == "text" and "forbidden" in part.text:
                    raise ValueError("Rejected: forbidden content")
            return msg

        manager = ConversationManager(
            message_hooks=MessageHooks(on_before_add_message=guard)
        )

    Example — write every stored message to a semantic memory backend::

        def index(conv_id: str, msg: Message) -> None:
            import asyncio
            asyncio.get_event_loop().run_until_complete(
                manager.semantic_memory.add_artifact(
                    content=str(msg.to_dict()),
                    kind="message",
                    namespace=conv_id,
                )
            )

        manager = ConversationManager(
            semantic_memory=backend,
            message_hooks=MessageHooks(on_after_add_message=index),
        )
    """

    on_before_add_message: "Callable[[str, Message], Message] | None" = None
    """Called before the message is persisted.

    Signature::

        def hook(conversation_id: str, message: Message) -> Message

    - Return the message unchanged to pass it through.
    - Return a *different* Message to replace what gets stored
      (e.g. for content redaction or metadata injection).
    - Raise any exception to reject the message. The message will
      NOT be stored, and the exception propagates to the caller.
      on_after_add_message will NOT be called.
    """

    on_after_add_message: "Callable[[str, Message], None] | None" = None
    """Called after the message has been successfully persisted.

    Signature::

        def hook(conversation_id: str, message: Message) -> None

    - The message received is the one actually stored (i.e. the value
      returned by on_before_add_message, if one was set).
    - Return value is ignored.
    - Exceptions propagate to the caller. The message has already been
      stored at this point — raising here does not undo storage.
    - Intended for side effects: audit logging, semantic memory writes,
      metrics, etc.
    """

    metadata: dict[str, Any] = field(default_factory=dict)
    """Arbitrary metadata you can read inside your hook implementations."""
