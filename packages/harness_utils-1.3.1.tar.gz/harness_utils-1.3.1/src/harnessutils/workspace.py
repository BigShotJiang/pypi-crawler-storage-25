"""Workspace management for harness-utils.

Manages the .harness/ directory under a workspace root, providing a
stable project UUID that persists across sessions.
"""

import uuid
from pathlib import Path


def resolve_workspace(workspace_root: Path, harness_name: str = ".harness") -> tuple[Path, str]:
    """Ensure the harness directory exists and return (harness_dir, project_id).

    Creates the harness directory and project_id file if they don't exist.
    Reads existing project_id if present.

    Args:
        workspace_root: Root directory of the workspace
        harness_name: Name of the harness directory (default: ".harness")

    Returns:
        Tuple of (harness_dir, project_id)
    """
    harness_dir = workspace_root / harness_name
    harness_dir.mkdir(parents=True, exist_ok=True)

    id_file = harness_dir / "project_id"
    if id_file.exists():
        project_id = id_file.read_text().strip()
    else:
        project_id = str(uuid.uuid4())
        id_file.write_text(project_id)

    return harness_dir, project_id
