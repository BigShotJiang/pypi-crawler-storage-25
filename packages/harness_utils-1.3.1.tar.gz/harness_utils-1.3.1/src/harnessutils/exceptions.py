"""Custom exceptions for harness-utils with remediation guidance."""


class HarnessError(Exception):
    """Base exception for harness-utils errors."""

    def __init__(self, message: str, remediation: str | None = None):
        """Initialize with error message and optional remediation steps.

        Args:
            message: Error description
            remediation: Steps to fix the error
        """
        self.message = message
        self.remediation = remediation
        super().__init__(self._format_error())

    def _format_error(self) -> str:
        """Format error with remediation if available."""
        if self.remediation:
            return f"{self.message}\n\nHow to fix:\n{self.remediation}"
        return self.message


class ConfigurationError(HarnessError):
    """Invalid configuration detected."""


class PruningError(HarnessError):
    """Error during pruning operation."""


class SummarizationError(HarnessError):
    """Error during summarization operation."""


class TruncationError(HarnessError):
    """Error during truncation operation."""


class SnapshotError(HarnessError):
    """Error with snapshot operations."""


class StorageError(HarnessError):
    """Error with storage backend."""
