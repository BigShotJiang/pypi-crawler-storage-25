# harness-utils — Semantic Memory Integration Design

This document covers only what **harness-utils** needs to implement to support semantic
memory. The consumer (ctrl+code) owns the `ContextAssembler`, `ArtifactWriter`, and the
rootset-backed implementation of the protocol defined here. Chunking, saliency scoring,
entity extraction, retrieval pipelines — none of that is harness-utils' concern.

---

## What harness-utils Needs to Do

Three things:

1. Define `SemanticMemoryBackend` — the async protocol consumers implement
2. Workspace management — generate/persist a stable project UUID under `.harness/`
3. Wire it into `ConversationManager` — accept the backend + workspace root, expose both

---

## 1. SemanticMemoryBackend Protocol

New file: `src/harnessutils/memory.py`

```python
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class SemanticMemoryBackend(Protocol):
    async def add_artifact(
        self,
        content: str,
        kind: str,
        *,
        namespace: str = "default",
        metadata: dict[str, Any] | None = None,
    ) -> Any: ...

    async def search_artifacts(
        self,
        query: str,
        *,
        top_k: int = 10,
        kind: str | None = None,
        namespace: str | None = None,
        min_similarity: float = 0.0,
    ) -> list[Any]: ...

    async def get_artifact(self, artifact_id: int) -> Any | None: ...

    async def update_artifact(
        self,
        artifact_id: int,
        *,
        metadata: dict[str, Any] | None = None,
        content: str | None = None,
    ) -> Any: ...

    async def delete_artifact(self, artifact_id: int) -> None: ...
```

Export from `__init__.py` alongside `LLMClient` and `StorageBackend`.

---

## 2. Workspace Management — `.harness/` Directory

When a `workspace_root` is provided to `ConversationManager`, harness-utils manages a
`.harness/` directory there.

```
{workspace_root}/
└── .harness/
    ├── project_id        # stable UUID, written once, never changes
    └── sessions/         # FilesystemStorage base path (replaces "data/")
```

### project_id

- A UUID4 written to `.harness/project_id` on first initialisation
- Read on subsequent initialisations — never regenerated
- Stable across directory renames, git remote changes, anything external
- Used as the `namespace` for semantic memory operations and as `ConversationManager.project_id`

### sessions/

- When `workspace_root` is provided and `storage` is not explicitly passed, `ConversationManager`
  defaults to `FilesystemStorage` with `base_path = workspace_root / ".harness" / "sessions"`
- If `storage` is passed explicitly, it's used as-is — no override

### Implementation

New utility: `src/harnessutils/workspace.py`

```python
from pathlib import Path
import uuid


def resolve_workspace(workspace_root: Path) -> tuple[Path, str]:
    """Ensure .harness/ exists and return (harness_dir, project_id).

    Creates .harness/ and project_id file if they don't exist.
    Reads existing project_id if present.
    """
    harness_dir = workspace_root / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)

    id_file = harness_dir / "project_id"
    if id_file.exists():
        project_id = id_file.read_text().strip()
    else:
        project_id = str(uuid.uuid4())
        id_file.write_text(project_id)

    return harness_dir, project_id
```

---

## 3. ConversationManager Changes

### New signature

```python
def __init__(
    self,
    storage: StorageBackend | None = None,
    config: HarnessConfig | None = None,
    *,
    workspace_root: Path | str | None = None,
    semantic_memory: SemanticMemoryBackend | None = None,
) -> None:
```

### Behaviour

```python
self.config = config or HarnessConfig()
self.project_id: str | None = None
self.semantic_memory = semantic_memory

if workspace_root is not None:
    harness_dir, self.project_id = resolve_workspace(Path(workspace_root))
    if storage is None:
        sessions_path = harness_dir / "sessions"
        storage_config = StorageConfig(base_path=sessions_path)
        storage = FilesystemStorage(storage_config)

self.storage = storage or MemoryStorage()
```

When `workspace_root` is omitted, behaviour is identical to today. No breaking change.

### Exposed attributes

| Attribute | Type | Meaning |
|---|---|---|
| `manager.project_id` | `str \| None` | Stable workspace UUID; `None` if no workspace_root |
| `manager.semantic_memory` | `SemanticMemoryBackend \| None` | The backend if provided |

The consumer (ctrl+code) accesses `manager.semantic_memory` and `manager.project_id` directly
to drive artifact writes and reads. `ConversationManager` does not call `semantic_memory`
internally — it is a holder, not an orchestrator.

---

## What harness-utils Does NOT Do

These are ctrl+code's responsibility:

- Chunking (tree-sitter, sentence-boundary, JSON structural)
- Saliency scoring
- Entity extraction and entity index writes
- Supersession detection
- Engagement tracking
- ContextAssembler (retrieval pipeline, RRF fusion, budget trim)
- ArtifactWriter (turn artifacts → rootset)
- Session summary maintenance
- rootset schema (entity_index, engagement_log, supersession_log tables)

---

## File Changes

| File | Change |
|---|---|
| `src/harnessutils/memory.py` | New — `SemanticMemoryBackend` protocol |
| `src/harnessutils/workspace.py` | New — `resolve_workspace()` utility |
| `src/harnessutils/manager.py` | Accept `workspace_root`, `semantic_memory`; wire workspace init |
| `src/harnessutils/__init__.py` | Export `SemanticMemoryBackend` |

`StorageConfig` and `FilesystemStorage` are unchanged — the sessions path is just passed in
as `base_path` at construction time.

---

## Non-Goals

- No async anywhere in harness-utils itself — `SemanticMemoryBackend` is async because
  the implementations (rootset) are async. harness-utils only holds the reference.
- No `.gitignore` management — recommend in docs, not enforced in code.
- No migration of existing `data/` directories — consumers handle that.
