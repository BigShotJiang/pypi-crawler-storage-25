"""Tests for message conversion to model format."""

from harnessutils import (
    CompactionPart,
    Message,
    ReasoningPart,
    StepStartPart,
    TextPart,
    ToolPart,
    ToolState,
    generate_id,
)
from harnessutils.conversion.to_model import to_model_messages
from harnessutils.models.parts import TimeInfo


def test_convert_simple_message():
    """Test converting simple message."""
    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="Hello"))

    converted = to_model_messages([msg])

    assert len(converted) == 1
    assert converted[0]["role"] == "user"
    assert "Hello" in str(converted[0]["content"])


def test_convert_empty_messages():
    """Test converting empty message list."""
    converted = to_model_messages([])
    assert converted == []


def test_convert_multiple_messages():
    """Test converting multiple messages."""
    msg1 = Message(id=generate_id("msg"), role="user")
    msg1.add_part(TextPart(text="Question"))

    msg2 = Message(id=generate_id("msg"), role="assistant")
    msg2.add_part(TextPart(text="Answer"))

    converted = to_model_messages([msg1, msg2])

    assert len(converted) == 2
    assert converted[0]["role"] == "user"
    assert converted[1]["role"] == "assistant"


def test_convert_tool_message():
    """Test converting message with tool."""
    msg = Message(id=generate_id("msg"), role="assistant")
    tool_part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "ls"},
            output="file1.txt",
        ),
    )
    msg.add_part(tool_part)

    converted = to_model_messages([msg])

    assert len(converted) == 1
    assert converted[0]["role"] == "assistant"


def test_stops_at_summary_boundary():
    """Conversion stops at the user message that triggered the summary."""
    user_before = Message(id="u0", role="user")
    user_before.add_part(TextPart(text="Before summary"))

    # Summary message — parent is u0
    summary = Message(id="s1", role="assistant", summary=True, parent_id="u0")
    summary.add_part(TextPart(text="Here is the summary."))

    user_after = Message(id="u2", role="user")
    user_after.add_part(TextPart(text="After summary"))

    assistant_after = Message(id="a3", role="assistant")
    assistant_after.add_part(TextPart(text="After response"))

    converted = to_model_messages([user_before, summary, user_after, assistant_after])

    # user_before (u0) should NOT appear — it's the summary parent boundary
    roles_and_contents = [(m["role"], m["content"]) for m in converted]
    contents = [c for _, c in roles_and_contents]
    assert "Before summary" not in " ".join(contents)
    # Messages after the summary should appear
    assert any("After summary" in c for c in contents)
    assert any("After response" in c for c in contents)


def test_compaction_part_in_user_message():
    """CompactionPart in a user message produces a placeholder."""
    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(CompactionPart())

    converted = to_model_messages([msg])

    assert len(converted) == 1
    assert "What did we do so far?" in converted[0]["content"]


def test_empty_user_message_excluded():
    """User message with no valid text parts produces no output."""
    msg = Message(id=generate_id("msg"), role="user")
    # No parts added

    converted = to_model_messages([msg])
    assert converted == []


def test_empty_assistant_message_excluded():
    """Assistant message with no content parts produces no output."""
    msg = Message(id=generate_id("msg"), role="assistant")
    # No parts added

    converted = to_model_messages([msg])
    assert converted == []


def test_error_message_without_partial_output_excluded():
    """Errored assistant message with no partial output is excluded."""
    msg = Message(id=generate_id("msg"), role="assistant", error="something went wrong")
    msg.add_part(TextPart(text="partial"))
    # has_partial_output() checks if any part has content — TextPart alone
    # doesn't count as "partial tool output", so this tests the error gate

    # Build a clean error message with no tool parts at all
    err_msg = Message(id=generate_id("msg"), role="assistant", error="fatal")
    # No parts — has_partial_output() returns False

    converted = to_model_messages([err_msg])
    assert converted == []


def test_reasoning_part_included():
    """ReasoningPart in an assistant message is included as [Extended thinking]."""
    msg = Message(id=generate_id("msg"), role="assistant")
    msg.add_part(ReasoningPart(text="I am thinking through the problem carefully."))
    msg.add_part(TextPart(text="The answer is 42."))

    converted = to_model_messages([msg])

    assert len(converted) == 1
    content = converted[0]["content"]
    assert "[Extended thinking:" in content
    assert "The answer is 42." in content


def test_tool_error_state():
    """Tool part with status=error is included as [Tool Error: ...]."""
    msg = Message(id=generate_id("msg"), role="assistant")
    tool_part = ToolPart(
        tool="bash",
        call_id="call_err",
        state=ToolState(status="error", error="command not found"),
    )
    msg.add_part(tool_part)

    converted = to_model_messages([msg])

    assert len(converted) == 1
    assert "[Tool Error: bash]" in converted[0]["content"]
    assert "command not found" in converted[0]["content"]


def test_tool_interrupted_pending_state():
    """Tool part with status=pending is included as interrupted marker."""
    msg = Message(id=generate_id("msg"), role="assistant")
    tool_part = ToolPart(
        tool="read",
        call_id="call_int",
        state=ToolState(status="pending"),
    )
    msg.add_part(tool_part)

    converted = to_model_messages([msg])

    assert len(converted) == 1
    assert "interrupted" in converted[0]["content"].lower()
    assert "read" in converted[0]["content"]


def test_tool_interrupted_running_state():
    """Tool part with status=running is included as interrupted marker."""
    msg = Message(id=generate_id("msg"), role="assistant")
    tool_part = ToolPart(
        tool="write",
        call_id="call_run",
        state=ToolState(status="running"),
    )
    msg.add_part(tool_part)

    converted = to_model_messages([msg])

    assert len(converted) == 1
    assert "interrupted" in converted[0]["content"].lower()


def test_compacted_tool_output_shows_marker():
    """Compacted tool output is replaced with the cleared marker."""
    msg = Message(id=generate_id("msg"), role="assistant")
    tool_part = ToolPart(
        tool="read",
        call_id="call_cmp",
        state=ToolState(status="completed", output=""),
    )
    tool_part.state.time = TimeInfo(start=1000, end=2000, compacted=3000)
    msg.add_part(tool_part)

    converted = to_model_messages([msg])

    assert len(converted) == 1
    assert "[Old tool result content cleared]" in converted[0]["content"]


def test_user_ignored_parts_only_excluded():
    """User message whose only parts are all ignored hits the no-content guard (line 74)."""
    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="hidden", ignored=True))

    converted = to_model_messages([msg])
    assert converted == []


def test_error_assistant_no_text_parts_excluded():
    """Errored assistant with parts but no TextParts hits has_partial_output=False guard."""
    msg = Message(id=generate_id("msg"), role="assistant", error="fatal")
    msg.add_part(ToolPart(tool="bash", call_id="c1", state=ToolState(status="pending")))

    converted = to_model_messages([msg])
    assert converted == []


def test_assistant_step_start_part_only_excluded():
    """Assistant with only a StepStartPart produces no content and hits the empty guard."""
    msg = Message(id=generate_id("msg"), role="assistant")
    msg.add_part(StepStartPart(snapshot="snap_abc"))

    converted = to_model_messages([msg])
    assert converted == []
