"""Tests for query-conditioned pruning and micro-summarization (1.3.0 features)."""

import pytest

from harnessutils import (
    ConversationManager,
    HarnessConfig,
    MemoryStorage,
    Message,
    TextPart,
    ToolPart,
    ToolState,
    generate_id,
)
from harnessutils.compaction.pruning import (
    OutputImportance,
    _compute_query_relevance,
    prune_tool_outputs,
    score_tool_output,
)
from harnessutils.models.parts import TimeInfo, part_from_dict
from harnessutils.conversion.to_model import to_model_messages


# ---------------------------------------------------------------------------
# _compute_query_relevance
# ---------------------------------------------------------------------------

def test_query_relevance_empty_query():
    assert _compute_query_relevance("", "some output text", 1.5) == 0.0


def test_query_relevance_empty_output():
    assert _compute_query_relevance("fix the bug", "", 1.5) == 0.0


def test_query_relevance_full_match():
    """All query terms present in output → maximum coverage."""
    score = _compute_query_relevance("session manager", "session manager handles state", 1.0)
    assert score == pytest.approx(100.0)  # 2/2 content words match


def test_query_relevance_partial_match():
    score = _compute_query_relevance("session manager", "session handles state", 1.0)
    # "session" matches, "manager" doesn't → 1/2 = 0.5 coverage
    assert score == pytest.approx(50.0)


def test_query_relevance_no_match():
    score = _compute_query_relevance("database schema", "file not found error", 1.5)
    assert score == 0.0


def test_query_relevance_stop_words_filtered():
    """Stop words in query don't count toward meaningful terms."""
    # "the" and "is" are stop words — only "bug" matters
    score_with_stops = _compute_query_relevance("the bug is here", "bug found in module", 1.0)
    score_content_only = _compute_query_relevance("bug here", "bug found in module", 1.0)
    # "bug" and "here" — "bug" matches, "here" doesn't → 0.5
    # "the bug is here" → stop words removed → "bug here" → same result
    assert score_with_stops == score_content_only


def test_query_relevance_weight_scales_score():
    score_low = _compute_query_relevance("session", "session started", 1.0)
    score_high = _compute_query_relevance("session", "session started", 2.0)
    assert score_high == pytest.approx(score_low * 2)


def test_query_relevance_all_stop_words():
    """Query consisting only of stop words → 0.0 (no meaningful terms)."""
    score = _compute_query_relevance("the is a an", "some output text", 1.5)
    assert score == 0.0


# ---------------------------------------------------------------------------
# score_tool_output with query param
# ---------------------------------------------------------------------------

def _make_msg_with_tool(tool: str, output: str) -> tuple[Message, ToolPart]:
    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool=tool,
        call_id=generate_id("call"),
        state=ToolState(status="completed", output=output),
    )
    msg.add_part(part)
    return msg, part


def test_score_tool_output_query_relevance_zero_without_query():
    config = HarnessConfig()
    msg, part = _make_msg_with_tool("bash", "session manager loaded")
    score = score_tool_output(part, msg, [msg], config.pruning)
    assert score.query_relevance == 0.0


def test_score_tool_output_query_relevance_nonzero_with_query():
    config = HarnessConfig()
    msg, part = _make_msg_with_tool("bash", "session manager loaded")
    score = score_tool_output(part, msg, [msg], config.pruning, query="session manager")
    assert score.query_relevance > 0.0


def test_score_tool_output_query_relevance_included_in_total():
    config = HarnessConfig()
    msg, part = _make_msg_with_tool("bash", "session manager loaded")
    score_no_query = score_tool_output(part, msg, [msg], config.pruning)
    score_with_query = score_tool_output(part, msg, [msg], config.pruning, query="session manager")
    assert score_with_query.total_score > score_no_query.total_score


def test_score_tool_output_query_default_is_zero():
    """query_relevance defaults to 0.0 on OutputImportance."""
    imp = OutputImportance(
        recency_score=10.0,
        size_penalty=-5.0,
        semantic_score=0.0,
        tool_priority=50.0,
        token_count=100,
    )
    assert imp.query_relevance == 0.0
    assert imp.total_score == pytest.approx(55.0)


def test_score_tool_output_query_relevance_added_to_total():
    imp = OutputImportance(
        recency_score=10.0,
        size_penalty=-5.0,
        semantic_score=0.0,
        tool_priority=50.0,
        token_count=100,
        query_relevance=30.0,
    )
    assert imp.total_score == pytest.approx(85.0)


# ---------------------------------------------------------------------------
# prune_tool_outputs — query param preserves relevant outputs
# ---------------------------------------------------------------------------

def _build_conversation_with_outputs(outputs: list[tuple[str, str]]) -> list[Message]:
    """Build a list of messages: user turn followed by assistant tool outputs.

    Each output is a (tool_name, output_text) pair.
    """
    user_msg = Message(id=generate_id("msg"), role="user")
    user_msg.add_part(TextPart(text="do something"))

    # Add two older user/assistant turns before to age the outputs past protect_turns
    old_user = Message(id="old_user_1", role="user")
    old_user.add_part(TextPart(text="older turn"))
    old_asst = Message(id="old_asst_1", role="assistant")
    for tool, output in outputs:
        part = ToolPart(
            tool=tool,
            call_id=generate_id("call"),
            state=ToolState(status="completed", output=output),
        )
        old_asst.add_part(part)

    new_user = Message(id=generate_id("msg"), role="user")
    new_user.add_part(TextPart(text="now do more"))

    return [old_user, old_asst, new_user]


def test_prune_with_query_boosts_relevant_output():
    """An output relevant to the query scores higher and is pruned last."""
    config = HarnessConfig()
    config.pruning.prune_protect = 0
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0
    config.pruning.use_importance_scoring = True
    config.pruning.detect_duplicates = False

    relevant_output = "session manager loaded context from disk"
    irrelevant_output = "z" * 2000  # large but unrelated

    messages = _build_conversation_with_outputs([
        ("bash", relevant_output),
        ("bash", irrelevant_output),
    ])

    # Find the relevant part before pruning
    asst_msg = messages[1]
    relevant_part = asst_msg.parts[0]
    irrelevant_part = asst_msg.parts[1]

    result = prune_tool_outputs(messages, config.pruning, query="session manager")

    # Irrelevant output should be pruned before relevant one
    # (relevant part has query_relevance boost)
    decisions_by_part = {d.part_id: d for d in result.decisions}

    rel_decision = decisions_by_part.get(relevant_part.call_id)
    irrel_decision = decisions_by_part.get(irrelevant_part.call_id)

    if rel_decision and irrel_decision:
        if irrel_decision.was_pruned:
            # If irrelevant was pruned, relevant should be kept
            assert not rel_decision.was_pruned or rel_decision.importance_score > irrel_decision.importance_score


def test_prune_without_query_no_query_relevance_in_scores():
    """With no query, all query_relevance scores should be 0."""
    config = HarnessConfig()
    config.pruning.prune_protect = 0
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0
    config.pruning.use_importance_scoring = True
    config.pruning.detect_duplicates = False

    messages = _build_conversation_with_outputs([("bash", "x" * 500)])
    result = prune_tool_outputs(messages, config.pruning)

    for decision in result.decisions:
        if decision.importance_score is not None:
            # All scored decisions should not have inflated scores from query
            # Just verify the function ran cleanly without query
            assert decision.importance_score is not None


# ---------------------------------------------------------------------------
# summarizer callback
# ---------------------------------------------------------------------------

def test_summarizer_called_before_clearing():
    """Summarizer is invoked with tool name and output before zeroing."""
    config = HarnessConfig()
    config.pruning.prune_protect = 0
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0
    config.pruning.detect_duplicates = False

    calls: list[tuple[str, str]] = []

    def mock_summarizer(tool: str, output: str) -> str:
        calls.append((tool, output))
        return f"summary of {tool}"

    messages = _build_conversation_with_outputs([("bash", "x" * 1000)])
    prune_tool_outputs(messages, config.pruning, summarizer=mock_summarizer)

    assert len(calls) == 1
    assert calls[0][0] == "bash"
    assert calls[0][1] == "x" * 1000


def test_summarizer_result_stored_in_summary_text():
    """summary_text is set to the summarizer's return value."""
    config = HarnessConfig()
    config.pruning.prune_protect = 0
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0
    config.pruning.detect_duplicates = False

    def mock_summarizer(tool: str, output: str) -> str:
        return "ran ls, found 3 files"

    messages = _build_conversation_with_outputs([("bash", "x" * 1000)])
    asst_msg = messages[1]
    tool_part = asst_msg.parts[0]

    prune_tool_outputs(messages, config.pruning, summarizer=mock_summarizer)

    assert tool_part.state.output != ""  # Output preserved in storage
    assert tool_part.state.summary_text == "ran ls, found 3 files"


def test_summarizer_not_called_when_none():
    """No errors and output cleared normally when summarizer is None."""
    config = HarnessConfig()
    config.pruning.prune_protect = 0
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0
    config.pruning.detect_duplicates = False

    messages = _build_conversation_with_outputs([("bash", "x" * 1000)])
    asst_msg = messages[1]
    tool_part = asst_msg.parts[0]

    result = prune_tool_outputs(messages, config.pruning, summarizer=None)

    assert tool_part.call_id in result.excluded_call_ids  # Excluded, not mutated
    assert tool_part.state.summary_text is None


def test_summarizer_called_for_duplicates():
    """Summarizer is invoked when pruning duplicates too."""
    config = HarnessConfig()
    config.pruning.prune_protect = 100_000
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0
    config.pruning.detect_duplicates = True
    config.pruning.similarity_threshold = 0.8

    calls: list[str] = []

    def mock_summarizer(tool: str, output: str) -> str:
        calls.append(output)
        return "duplicate summary"

    identical_output = "file1.py\nfile2.py\nfile3.py"

    old_user = Message(id="old_user_1", role="user")
    old_user.add_part(TextPart(text="first"))
    old_asst = Message(id="old_asst_1", role="assistant")
    part_original = ToolPart(
        tool="glob",
        call_id="call_1",
        state=ToolState(status="completed", output=identical_output),
    )
    old_asst.add_part(part_original)

    mid_user = Message(id="mid_user_1", role="user")
    mid_user.add_part(TextPart(text="second"))
    mid_asst = Message(id="mid_asst_1", role="assistant")
    part_dup = ToolPart(
        tool="glob",
        call_id="call_2",
        state=ToolState(status="completed", output=identical_output),
    )
    mid_asst.add_part(part_dup)

    new_user = Message(id="new_user_1", role="user")
    new_user.add_part(TextPart(text="third"))

    messages = [old_user, old_asst, mid_user, mid_asst, new_user]
    prune_tool_outputs(messages, config.pruning, summarizer=mock_summarizer)

    # At least one duplicate should have been summarized
    assert len(calls) >= 1
    pruned_part = part_original  # older one gets pruned
    assert pruned_part.state.summary_text == "duplicate summary"


# ---------------------------------------------------------------------------
# ToolState.summary_text serialization
# ---------------------------------------------------------------------------

def test_toolstate_summary_text_serializes():
    """summary_text is included in ToolPart.to_dict()."""
    part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            output="",
            summary_text="ran ls, found 3 files",
        ),
    )
    d = part.to_dict()
    assert d["state"]["summary_text"] == "ran ls, found 3 files"


def test_toolstate_summary_text_none_serializes():
    """summary_text=None is included in to_dict() as None."""
    part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(status="completed", output="some output"),
    )
    d = part.to_dict()
    assert d["state"]["summary_text"] is None


def test_toolstate_summary_text_deserializes():
    """summary_text round-trips through part_from_dict."""
    part = ToolPart(
        tool="grep",
        call_id="call_2",
        state=ToolState(
            status="completed",
            output="",
            summary_text="grep found 5 matches in src/",
        ),
    )
    d = part.to_dict()
    restored = part_from_dict(d)
    assert isinstance(restored, ToolPart)
    assert restored.state.summary_text == "grep found 5 matches in src/"


def test_toolstate_summary_text_none_deserializes():
    """summary_text=None round-trips through part_from_dict."""
    part = ToolPart(
        tool="read",
        call_id="call_3",
        state=ToolState(status="completed", output="file contents"),
    )
    d = part.to_dict()
    restored = part_from_dict(d)
    assert isinstance(restored, ToolPart)
    assert restored.state.summary_text is None


# ---------------------------------------------------------------------------
# to_model rendering of summary_text
# ---------------------------------------------------------------------------

def test_to_model_renders_summarized_marker_when_summary_text_set():
    """[Summarized: ...] is rendered when summary_text is set on a compacted output."""
    msg = Message(id=generate_id("msg"), role="assistant")
    tool_part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(status="completed", output="", summary_text="ran ls, found 3 files"),
    )
    tool_part.state.time = TimeInfo(start=1000, end=2000, compacted=3000)
    msg.add_part(tool_part)

    converted = to_model_messages([msg])

    assert len(converted) == 1
    assert "[Summarized: ran ls, found 3 files]" in converted[0]["content"]
    assert "[Old tool result content cleared]" not in converted[0]["content"]


def test_to_model_renders_cleared_marker_when_no_summary_text():
    """[Old tool result content cleared] is rendered when summary_text is None."""
    msg = Message(id=generate_id("msg"), role="assistant")
    tool_part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(status="completed", output=""),
    )
    tool_part.state.time = TimeInfo(start=1000, end=2000, compacted=3000)
    msg.add_part(tool_part)

    converted = to_model_messages([msg])

    assert len(converted) == 1
    assert "[Old tool result content cleared]" in converted[0]["content"]
    assert "[Summarized:" not in converted[0]["content"]


# ---------------------------------------------------------------------------
# prune_before_turn with query and summarizer via ConversationManager
# ---------------------------------------------------------------------------

def test_prune_before_turn_accepts_query_and_summarizer():
    """prune_before_turn passes query and summarizer through to pruning."""
    config = HarnessConfig()
    config.pruning.prune_protect = 0
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0
    config.pruning.detect_duplicates = False

    storage = MemoryStorage()
    manager = ConversationManager(storage, config)
    conv = manager.create_conversation()

    msg = Message(id=generate_id("msg"), role="assistant")
    tool_part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(status="completed", output="x" * 1000),
    )
    msg.add_part(tool_part)
    manager.add_message(conv.id, msg)

    calls: list[tuple[str, str]] = []

    def mock_summarizer(tool: str, output: str) -> str:
        calls.append((tool, output))
        return "summary text"

    result = manager.prune_before_turn(
        conv.id,
        query="find the bug",
        summarizer=mock_summarizer,
    )

    assert "pruned" in result
    if result["pruned"] > 0:
        assert len(calls) > 0
        assert calls[0][0] == "bash"
