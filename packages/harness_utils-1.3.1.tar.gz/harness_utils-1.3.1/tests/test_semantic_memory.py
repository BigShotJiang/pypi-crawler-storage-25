"""Tests for semantic memory backend protocol and workspace management."""

import tempfile
from pathlib import Path
from typing import Any

import pytest

from harnessutils import ConversationManager, SemanticMemoryBackend
from harnessutils.memory import SemanticMemoryBackend as SemanticMemoryBackendDirect
from harnessutils.workspace import resolve_workspace


# --- Minimal concrete implementation for protocol checks ---

class _FakeBackend:
    async def add_artifact(self, content, kind, *, namespace="default", metadata=None):
        return 1

    async def search_artifacts(self, query, *, top_k=10, kind=None, namespace=None, min_similarity=0.0):
        return []

    async def get_artifact(self, artifact_id):
        return None

    async def update_artifact(self, artifact_id, *, metadata=None, content=None):
        return None

    async def delete_artifact(self, artifact_id):
        return None


# --- SemanticMemoryBackend protocol tests ---

def test_protocol_is_runtime_checkable():
    backend = _FakeBackend()
    assert isinstance(backend, SemanticMemoryBackend)


def test_protocol_exported_from_init():
    from harnessutils import SemanticMemoryBackend as exported
    assert exported is SemanticMemoryBackendDirect


def test_non_conforming_class_fails_isinstance():
    class _Bad:
        pass

    assert not isinstance(_Bad(), SemanticMemoryBackend)


def test_missing_one_method_fails():
    class _MissingDelete:
        async def add_artifact(self, content, kind, *, namespace="default", metadata=None):
            return None

        async def search_artifacts(self, query, *, top_k=10, kind=None, namespace=None, min_similarity=0.0):
            return []

        async def get_artifact(self, artifact_id):
            return None

        async def update_artifact(self, artifact_id, *, metadata=None, content=None):
            return None

        # delete_artifact intentionally missing

    assert not isinstance(_MissingDelete(), SemanticMemoryBackend)


# --- resolve_workspace tests ---

def test_resolve_workspace_creates_harness_dir(tmp_path):
    harness_dir, project_id = resolve_workspace(tmp_path)
    assert harness_dir == tmp_path / ".harness"
    assert harness_dir.is_dir()


def test_resolve_workspace_writes_project_id(tmp_path):
    harness_dir, project_id = resolve_workspace(tmp_path)
    id_file = harness_dir / "project_id"
    assert id_file.exists()
    assert id_file.read_text().strip() == project_id


def test_resolve_workspace_stable_across_calls(tmp_path):
    _, project_id_1 = resolve_workspace(tmp_path)
    _, project_id_2 = resolve_workspace(tmp_path)
    assert project_id_1 == project_id_2


def test_resolve_workspace_project_id_is_uuid(tmp_path):
    import uuid
    _, project_id = resolve_workspace(tmp_path)
    # Should not raise
    uuid.UUID(project_id)


# --- ConversationManager integration tests ---

def test_manager_default_no_workspace():
    manager = ConversationManager()
    assert manager.project_id is None
    assert manager.semantic_memory is None


def test_manager_workspace_root_sets_project_id(tmp_path):
    manager = ConversationManager(workspace_root=tmp_path)
    assert manager.project_id is not None
    # Should be a valid UUID
    import uuid
    uuid.UUID(manager.project_id)


def test_manager_workspace_root_creates_filesystem_storage(tmp_path):
    from harnessutils.storage.filesystem import FilesystemStorage
    manager = ConversationManager(workspace_root=tmp_path)
    assert isinstance(manager.storage, FilesystemStorage)
    sessions_dir = tmp_path / ".harness" / "sessions"
    assert sessions_dir.is_dir()


def test_manager_workspace_root_stable_project_id(tmp_path):
    manager1 = ConversationManager(workspace_root=tmp_path)
    manager2 = ConversationManager(workspace_root=tmp_path)
    assert manager1.project_id == manager2.project_id


def test_manager_explicit_storage_not_overridden(tmp_path):
    from harnessutils.storage.memory import MemoryStorage
    explicit = MemoryStorage()
    manager = ConversationManager(storage=explicit, workspace_root=tmp_path)
    assert manager.storage is explicit


def test_manager_accepts_semantic_memory():
    backend = _FakeBackend()
    manager = ConversationManager(semantic_memory=backend)
    assert manager.semantic_memory is backend


def test_manager_semantic_memory_not_called_internally():
    """harness-utils must not invoke the backend on its own."""
    called = []

    class _Tracking(_FakeBackend):
        async def add_artifact(self, *args, **kwargs):
            called.append("add_artifact")
            return 1

        async def search_artifacts(self, *args, **kwargs):
            called.append("search_artifacts")
            return []

    manager = ConversationManager(semantic_memory=_Tracking())
    conv = manager.create_conversation()
    assert called == [], "ConversationManager must not call semantic_memory internally"
