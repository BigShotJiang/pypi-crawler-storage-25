"""Tests for workspace resolution utility."""

import uuid

from harnessutils.workspace import resolve_workspace


def test_creates_harness_dir(tmp_path):
    resolve_workspace(tmp_path)
    assert (tmp_path / ".harness").is_dir()


def test_writes_project_id_file(tmp_path):
    _, project_id = resolve_workspace(tmp_path)
    id_file = tmp_path / ".harness" / "project_id"
    assert id_file.exists()
    assert id_file.read_text().strip() == project_id
    # Must be valid UUID4
    uuid.UUID(project_id)


def test_project_id_stable(tmp_path):
    _, pid1 = resolve_workspace(tmp_path)
    _, pid2 = resolve_workspace(tmp_path)
    assert pid1 == pid2


def test_different_roots_different_ids(tmp_path):
    root1 = tmp_path / "a"
    root2 = tmp_path / "b"
    root1.mkdir()
    root2.mkdir()
    _, pid1 = resolve_workspace(root1)
    _, pid2 = resolve_workspace(root2)
    assert pid1 != pid2


def test_returns_harness_dir_path(tmp_path):
    harness_dir, _ = resolve_workspace(tmp_path)
    assert harness_dir == tmp_path / ".harness"
    assert harness_dir.is_dir()


def test_idempotent(tmp_path):
    ids = [resolve_workspace(tmp_path)[1] for _ in range(10)]
    assert len(set(ids)) == 1
    # Only one file on disk
    id_files = list((tmp_path / ".harness").iterdir())
    assert len(id_files) == 1
