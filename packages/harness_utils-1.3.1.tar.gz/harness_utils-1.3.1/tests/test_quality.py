"""Tests for Phase 3B: Quality metrics."""

import time

from harnessutils.compaction.pruning import PruningDecision
from harnessutils.config import HarnessConfig, PruningConfig
from harnessutils.manager import ConversationManager
from harnessutils.models.message import Message
from harnessutils.models.parts import TextPart, ToolPart
from harnessutils.models.usage import CacheUsage, Usage
from harnessutils.quality import (
    QualityHistory,
    QualitySnapshot,
    assess_quality,
    calculate_error_preservation_rate,
    calculate_health,
    calculate_information_density,
    calculate_protected_ratio,
    calculate_redundancy_ratio,
    calculate_staleness_score,
    generate_recommendations,
)
from harnessutils.storage.memory import MemoryStorage


def create_test_message(
    role: str = "assistant",
    tool_outputs: list[str] | None = None,
    tokens: int = 100,
) -> Message:
    """Helper to create test messages.

    Args:
        role: Message role
        tool_outputs: Optional list of tool outputs to add
        tokens: Token count for message

    Returns:
        Test message
    """
    msg = Message(
        id=f"msg_{int(time.time() * 1000000)}",
        role=role,
        tokens=Usage(
            input=0,
            output=tokens,
            cache=CacheUsage(read=0, write=0),
        ),
    )

    if role == "user":
        msg.add_part(TextPart(text="test user message"))
    elif tool_outputs:
        for output in tool_outputs:
            tool_part = ToolPart(tool="test_tool")
            tool_part.state.output = output
            tool_part.state.status = "completed"
            msg.add_part(tool_part)
    else:
        msg.add_part(TextPart(text="test assistant message"))

    return msg


# =============================================================================
# Metric Calculation Tests
# =============================================================================


def test_calculate_information_density_all_unique():
    """Test information density with all unique outputs."""
    messages = [
        create_test_message(
            tool_outputs=["The quick brown fox jumps over the lazy dog"]
        ),
        create_test_message(
            tool_outputs=["A completely different sentence with unique words"]
        ),
    ]

    density = calculate_information_density(messages)

    # All unique shingles = 1.0 density
    assert density > 0.9  # Allow some variation due to shingling


def test_calculate_information_density_with_duplicates():
    """Test information density with duplicate outputs."""
    duplicate_output = "The quick brown fox jumps over the lazy dog"

    messages = [
        create_test_message(tool_outputs=[duplicate_output]),
        create_test_message(tool_outputs=[duplicate_output]),  # Exact duplicate
        create_test_message(tool_outputs=[duplicate_output]),  # Another duplicate
    ]

    density = calculate_information_density(messages)

    # Heavy duplicates = lower density
    assert density < 0.5


def test_calculate_redundancy_ratio():
    """Test redundancy ratio calculation."""
    duplicate_output = "Error: File not found at /path/to/file"

    config = PruningConfig(
        similarity_threshold=0.8,
        duplicate_lookback=10,
    )

    messages = [
        create_test_message(tool_outputs=["Unique output 1"]),
        create_test_message(tool_outputs=[duplicate_output]),
        create_test_message(tool_outputs=[duplicate_output]),  # Duplicate
        create_test_message(tool_outputs=["Unique output 2"]),
    ]

    redundancy = calculate_redundancy_ratio(messages, config)

    # Should detect 1 duplicate out of 4 outputs
    assert 0.2 < redundancy < 0.4


def test_calculate_staleness_score():
    """Test staleness score calculation."""
    messages = [
        create_test_message(tokens=1000),  # Oldest
        create_test_message(tokens=1000),
        create_test_message(tokens=1000),
        create_test_message(tokens=1000),  # Newest
    ]

    staleness = calculate_staleness_score(messages)

    # Should be > 0 (some age) but < 1.0 (not completely stale)
    assert 0.0 < staleness < 1.0

    # Recent messages should lower staleness
    messages_with_fresh = messages + [create_test_message(tokens=5000)]
    staleness_with_fresh = calculate_staleness_score(messages_with_fresh)

    # Adding fresh high-token message should reduce staleness
    assert staleness_with_fresh < staleness


def test_calculate_error_preservation_rate():
    """Test error preservation rate calculation."""
    error_output = "Error: Connection refused\nTraceback (most recent call last)"
    normal_output = "Success: Operation completed"

    messages = [
        create_test_message(tool_outputs=[error_output]),
        create_test_message(tool_outputs=[normal_output]),
        create_test_message(tool_outputs=[error_output]),
    ]

    # Without decisions, all errors assumed kept
    rate = calculate_error_preservation_rate(messages, decisions=None)
    assert rate == 1.0

    # With decisions showing one error pruned
    decisions = [
        PruningDecision(
            message_id="msg_1",
            part_id="part_1",
            tool="test_tool",
            decision="pruned_fifo",
            tokens=100,
        ),
    ]

    # Note: Without matching IDs, this test just validates no crash
    rate_with_decisions = calculate_error_preservation_rate(messages, decisions)
    assert 0.0 <= rate_with_decisions <= 1.0


def test_calculate_protected_ratio():
    """Test protected ratio calculation."""
    config = PruningConfig(
        protect_turns=2,
        protected_tools=["read", "write"],
    )

    messages = [
        create_test_message(tool_outputs=["old output"]),  # Not protected
        create_test_message(tool_outputs=["recent output 1"]),  # Protected by recency
        create_test_message(tool_outputs=["recent output 2"]),  # Protected by recency
    ]

    # Note: ContextInspector needs proper setup, this validates no crash
    protected_ratio = calculate_protected_ratio(messages, config)
    assert 0.0 <= protected_ratio <= 1.0


# =============================================================================
# Quality Assessment Tests
# =============================================================================


def test_assess_quality_good_health():
    """Test quality assessment for good health."""
    # Create messages with high quality characteristics
    messages = [
        create_test_message(tool_outputs=["Unique output 1"]),
        create_test_message(tool_outputs=["Unique output 2"]),
        create_test_message(tool_outputs=["Unique output 3"]),
    ]

    config = PruningConfig()
    snapshot = assess_quality(messages, config)

    # Verify snapshot structure
    assert isinstance(snapshot, QualitySnapshot)
    assert snapshot.timestamp > 0
    assert 0.0 <= snapshot.information_density <= 1.0
    assert 0.0 <= snapshot.redundancy_ratio <= 1.0
    assert 0.0 <= snapshot.staleness_score <= 1.0
    assert 0.0 <= snapshot.error_preservation_rate <= 1.0
    assert 0.0 <= snapshot.protected_ratio <= 1.0
    assert snapshot.health in ["good", "degraded", "poor"]
    assert isinstance(snapshot.recommendations, list)


def test_assess_quality_degraded_health():
    """Test quality assessment for degraded health."""
    # Mix of good and bad characteristics
    messages = [
        create_test_message(tool_outputs=["output 1"]),
        create_test_message(tool_outputs=["output 1"]),  # Some duplication
        create_test_message(tool_outputs=["unique output"]),
    ]

    config = PruningConfig()
    snapshot = assess_quality(messages, config)

    # Should classify as degraded (not perfect, not terrible)
    # Note: Exact classification depends on thresholds
    assert snapshot.health in ["good", "degraded", "poor"]


def test_assess_quality_poor_health():
    """Test quality assessment for poor health."""
    # Create messages with poor quality characteristics
    duplicate = "duplicate output content"
    messages = [
        create_test_message(tool_outputs=[duplicate]),
        create_test_message(tool_outputs=[duplicate]),
        create_test_message(tool_outputs=[duplicate]),
        create_test_message(tool_outputs=[duplicate]),
    ]

    config = PruningConfig()
    snapshot = assess_quality(messages, config)

    # High redundancy should trigger recommendations
    assert len(snapshot.recommendations) > 0


def test_calculate_health():
    """Test health classification."""
    # Good health
    good_snapshot = QualitySnapshot(
        timestamp=int(time.time() * 1000),
        information_density=0.9,
        redundancy_ratio=0.1,
        staleness_score=0.2,
        error_preservation_rate=1.0,
        protected_ratio=0.3,
        health="",
        recommendations=[],
    )
    assert calculate_health(good_snapshot) == "good"

    # Poor health
    poor_snapshot = QualitySnapshot(
        timestamp=int(time.time() * 1000),
        information_density=0.3,
        redundancy_ratio=0.6,
        staleness_score=0.7,
        error_preservation_rate=0.5,
        protected_ratio=0.5,
        health="",
        recommendations=[],
    )
    assert calculate_health(poor_snapshot) == "poor"

    # Degraded health
    degraded_snapshot = QualitySnapshot(
        timestamp=int(time.time() * 1000),
        information_density=0.6,
        redundancy_ratio=0.25,
        staleness_score=0.4,
        error_preservation_rate=0.85,
        protected_ratio=0.3,
        health="",
        recommendations=[],
    )
    assert calculate_health(degraded_snapshot) == "degraded"


def test_generate_recommendations():
    """Test recommendation generation."""
    # High redundancy
    snapshot = QualitySnapshot(
        timestamp=int(time.time() * 1000),
        information_density=0.5,
        redundancy_ratio=0.3,
        staleness_score=0.5,
        error_preservation_rate=0.7,
        protected_ratio=0.5,
        health="poor",
        recommendations=[],
    )

    recs = generate_recommendations(snapshot)

    # Should generate multiple recommendations
    assert len(recs) > 0
    assert any("redundancy" in rec.lower() for rec in recs)
    assert any("protected" in rec.lower() for rec in recs)
    assert any("staleness" in rec.lower() or "aging" in rec.lower() for rec in recs)
    assert any("error" in rec.lower() for rec in recs)
    assert any("density" in rec.lower() for rec in recs)


# =============================================================================
# Manager Integration Tests
# =============================================================================


def test_get_context_quality():
    """Test ConversationManager.get_context_quality()."""
    manager = ConversationManager(
        storage=MemoryStorage(),
        config=HarnessConfig(),
    )

    conv = manager.create_conversation()

    # Add messages
    msg1 = create_test_message(tool_outputs=["output 1"])
    msg2 = create_test_message(tool_outputs=["output 2"])
    manager.add_message(conv.id, msg1)
    manager.add_message(conv.id, msg2)

    # Get quality metrics
    quality = manager.get_context_quality(conv.id)

    # Verify structure
    assert "information_density" in quality
    assert "redundancy_ratio" in quality
    assert "staleness_score" in quality
    assert "error_preservation_rate" in quality
    assert "protected_ratio" in quality
    assert "health" in quality
    assert "recommendations" in quality
    assert quality["health"] in ["good", "degraded", "poor"]
    assert isinstance(quality["recommendations"], list)


def test_track_quality_metric():
    """Test ConversationManager.track_quality_metric()."""
    manager = ConversationManager(
        storage=MemoryStorage(),
        config=HarnessConfig(),
    )

    conv = manager.create_conversation()

    # Track custom metric
    manager.track_quality_metric(
        conversation_id=conv.id,
        metric_name="information_density",
        value=0.85,
    )

    # Verify stored
    trend = manager.get_quality_trend(conv.id, "information_density", window=10)
    assert len(trend) == 1
    assert trend[0][1] == 0.85


def test_get_quality_trend():
    """Test ConversationManager.get_quality_trend()."""
    manager = ConversationManager(
        storage=MemoryStorage(),
        config=HarnessConfig(),
    )

    conv = manager.create_conversation()

    # Add messages and track quality multiple times
    for i in range(5):
        msg = create_test_message(tool_outputs=[f"output {i}"])
        manager.add_message(conv.id, msg)
        manager.get_context_quality(conv.id)  # This tracks automatically

    # Get trend
    trend = manager.get_quality_trend(conv.id, "information_density", window=10)

    # Should have 5 snapshots
    assert len(trend) == 5

    # Each should be (timestamp, value)
    for timestamp, value in trend:
        assert isinstance(timestamp, int)
        assert isinstance(value, float)
        assert 0.0 <= value <= 1.0


def test_quality_history_serialization():
    """Test QualityHistory serialization."""
    snapshot = QualitySnapshot(
        timestamp=int(time.time() * 1000),
        information_density=0.8,
        redundancy_ratio=0.2,
        staleness_score=0.3,
        error_preservation_rate=0.9,
        protected_ratio=0.4,
        health="good",
        recommendations=["Test recommendation"],
    )

    history = QualityHistory()
    history.add_snapshot(snapshot)

    # Serialize
    history_dict = history.to_dict()

    # Deserialize
    restored = QualityHistory.from_dict(history_dict)

    assert len(restored.snapshots) == 1
    assert restored.snapshots[0].information_density == 0.8
    assert restored.snapshots[0].health == "good"


def test_quality_history_trimming():
    """Test QualityHistory max_snapshots trimming."""
    history = QualityHistory(max_snapshots=3)

    # Add 5 snapshots
    for i in range(5):
        snapshot = QualitySnapshot(
            timestamp=int(time.time() * 1000) + i,
            information_density=0.8,
            redundancy_ratio=0.2,
            staleness_score=0.3,
            error_preservation_rate=0.9,
            protected_ratio=0.4,
            health="good",
            recommendations=[],
        )
        history.add_snapshot(snapshot)

    # Should only keep last 3
    assert len(history.snapshots) == 3

    # Most recent should be first (timestamp 4)
    assert history.snapshots[0].timestamp > history.snapshots[1].timestamp


def test_error_preservation_uses_decisions():
    """Error preservation rate should use pruning decisions when available."""
    # Create a message with an error output
    msg = create_test_message(tool_outputs=["Error: database connection failed"])

    # Set status to completed (output contains "error")
    for part in msg.parts:
        if part.type == "tool":
            part.state.status = "completed"

    messages = [msg]

    # With a decision marking the error as pruned_low_importance
    call_id = None
    for part in msg.parts:
        if part.type == "tool":
            call_id = getattr(part, "call_id", None)

    if call_id:
        pruned_decision = PruningDecision(
            message_id=msg.id,
            part_id=call_id,
            tool="test_tool",
            decision="pruned_low_importance",
            tokens=100,
            timestamp=int(time.time() * 1000),
        )

        # With the pruned decision, error preservation rate should be < 1.0
        rate_with_decisions = calculate_error_preservation_rate(messages, [pruned_decision])
        # The error was pruned, so kept_errors should be 0
        assert rate_with_decisions == 0.0

    # Without decisions, all errors assumed kept
    rate_without_decisions = calculate_error_preservation_rate(messages, None)
    assert rate_without_decisions == 1.0
