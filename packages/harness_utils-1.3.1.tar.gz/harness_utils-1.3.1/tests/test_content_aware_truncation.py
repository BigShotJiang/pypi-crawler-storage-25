"""Tests for content-aware truncation (Phase 2)."""

import json

from harnessutils.compaction.truncation import (
    detect_content_type,
    truncate_output,
)
from harnessutils.config import TruncationConfig


class TestContentTypeDetection:
    """Test content type detection."""

    def test_detect_json_object(self):
        """Detect JSON object."""
        output = '{"key": "value", "number": 42}'
        assert detect_content_type(output) == "json"

    def test_detect_json_array(self):
        """Detect JSON array."""
        output = '[{"id": 1}, {"id": 2}]'
        assert detect_content_type(output) == "json"

    def test_detect_invalid_json(self):
        """Invalid JSON should not be detected as JSON."""
        output = '{"key": invalid}'
        assert detect_content_type(output) != "json"

    def test_detect_python_stacktrace(self):
        """Detect Python stacktrace."""
        output = """Traceback (most recent call last):
  File "test.py", line 10, in <module>
    raise ValueError("error")
ValueError: error"""
        assert detect_content_type(output) == "stacktrace"

    def test_detect_javascript_stacktrace(self):
        """Detect JavaScript stacktrace."""
        output = """Error: something went wrong
    at Object.<anonymous> (/app/index.js:10:15)
    at Module._compile (internal/modules/cjs/loader.js:999:30)"""
        assert detect_content_type(output) == "stacktrace"

    def test_detect_logs_with_timestamp(self):
        """Detect logs with ISO timestamp."""
        output = "2024-01-15T10:30:45 INFO: Starting service"
        assert detect_content_type(output) == "logs"

    def test_detect_logs_with_level(self):
        """Detect logs with log level."""
        output = "[ERROR] Database connection failed"
        assert detect_content_type(output) == "logs"

    def test_detect_python_code(self):
        """Detect Python code."""
        output = """def hello():
    print("world")"""
        assert detect_content_type(output) == "code"

    def test_detect_javascript_code(self):
        """Detect JavaScript code."""
        output = "const foo = () => { return 42; }"
        assert detect_content_type(output) == "code"

    def test_detect_plain_text(self):
        """Plain text should be detected as text."""
        output = "This is just plain text content."
        assert detect_content_type(output) == "text"

    def test_detect_empty_string(self):
        """Empty string should be text."""
        assert detect_content_type("") == "text"


class TestJSONTruncation:
    """Test JSON truncation."""

    def test_json_array_truncation(self):
        """JSON arrays should keep first/last items."""
        data = [{"id": i, "data": "x" * 100} for i in range(100)]
        output = json.dumps(data)
        config = TruncationConfig(max_tokens=500, use_content_aware=True)

        result = truncate_output(output, config)

        assert result.truncated
        assert result.content_type == "json"
        # Should mention truncation
        assert "truncated" in result.content

    def test_json_object_preserved(self):
        """Small JSON objects should not be truncated."""
        output = '{"key": "value", "number": 42}'
        config = TruncationConfig(max_tokens=500, use_content_aware=True)

        result = truncate_output(output, config)

        assert not result.truncated
        assert result.content_type == "json"

    def test_json_valid_after_truncation(self):
        """Truncated JSON arrays should remain valid JSON."""
        data = [{"id": i, "name": f"item{i}", "data": "x" * 50} for i in range(100)]
        output = json.dumps(data)
        config = TruncationConfig(max_tokens=500, use_content_aware=True)

        result = truncate_output(output, config)

        assert result.truncated
        # Extract JSON part (before truncation message)
        json_part = result.content.split("\n\n...")[0]
        parsed = json.loads(json_part)
        assert isinstance(parsed, list)
        assert len(parsed) == 10  # First 5 + last 5


class TestStacktraceTruncation:
    """Test stacktrace truncation."""

    def test_stacktrace_preserves_error_message(self):
        """Stacktrace should preserve error message."""
        output = """Traceback (most recent call last):
  File "test.py", line 1, in <module>
    foo()
  File "test.py", line 2, in foo
    bar()
  File "test.py", line 3, in bar
    raise ValueError("critical error message")
ValueError: critical error message"""

        config = TruncationConfig(max_tokens=100, use_content_aware=True, stacktrace_frame_limit=4)

        result = truncate_output(output, config)

        assert result.content_type == "stacktrace"
        assert "critical error message" in result.content

    def test_stacktrace_preserves_frames(self):
        """Stacktrace should keep top and bottom frames."""
        lines = ["Traceback (most recent call last):"]
        for i in range(30):
            lines.append(f'  File "test.py", line {i}, in func{i}')

        output = "\n".join(lines)
        config = TruncationConfig(max_tokens=100, use_content_aware=True, stacktrace_frame_limit=10)

        result = truncate_output(output, config)

        assert "frames truncated" in result.content


class TestLogsTruncation:
    """Test logs truncation."""

    def test_logs_preserve_errors(self):
        """Logs should preserve all ERROR lines."""
        lines = [
            "2024-01-15T10:30:00 INFO: Starting",
            "2024-01-15T10:30:01 ERROR: Database connection failed",
            "2024-01-15T10:30:02 INFO: Retrying",
            "2024-01-15T10:30:03 ERROR: Second error",
            "2024-01-15T10:30:04 INFO: Done",
        ]
        output = "\n".join(lines)
        config = TruncationConfig(max_tokens=100, use_content_aware=True)

        result = truncate_output(output, config)

        assert result.content_type == "logs"
        assert "Database connection failed" in result.content
        assert "Second error" in result.content

    def test_logs_preserve_warnings(self):
        """Logs should preserve all WARN lines."""
        lines = [
            "INFO: Normal operation",
            "[WARN] Slow query detected",
            "INFO: Continuing",
        ]
        output = "\n".join(lines)
        config = TruncationConfig(max_tokens=50, use_content_aware=True)

        result = truncate_output(output, config)

        assert "Slow query detected" in result.content

    def test_logs_truncate_info(self):
        """Logs should sample INFO lines."""
        lines = ["INFO: Message " + str(i) for i in range(200)]
        output = "\n".join(lines)
        config = TruncationConfig(max_tokens=100, use_content_aware=True)

        result = truncate_output(output, config)

        assert "info lines truncated" in result.content.lower()


class TestCodeTruncation:
    """Test code truncation."""

    def test_code_preserves_signatures(self):
        """Code should preserve function signatures."""
        output = """def function1():
    # Implementation
    pass

def function2():
    # Implementation
    pass

def function3():
    # Long implementation
    """ + "\n".join(["    code_line" for _ in range(100)])

        config = TruncationConfig(max_tokens=100, use_content_aware=True)

        result = truncate_output(output, config)

        assert result.content_type == "code"
        assert "def function1():" in result.content or "def function" in result.content


class TestTextTruncation:
    """Test plain text truncation."""

    def test_text_head_and_tail(self):
        """Text should keep head and tail."""
        output = " ".join([f"word{i}" for i in range(1000)])
        config = TruncationConfig(max_tokens=100, use_content_aware=True)

        result = truncate_output(output, config)

        assert result.content_type == "text"
        assert "word0" in result.content  # Head
        assert "truncated" in result.content
        # Should have tail as well (last words)
        assert "word" in result.content.split("truncated")[-1]


class TestConfigurationOptions:
    """Test configuration options."""

    def test_content_aware_disabled_fallback(self):
        """When content-aware is disabled, use legacy truncation."""
        output = '{"key": "value"}'
        config = TruncationConfig(
            max_tokens=100,
            use_content_aware=False,
            max_lines=5,
            max_bytes=100,
        )

        result = truncate_output(output, config)

        # Should use legacy truncation (not detect JSON)
        assert not result.truncated  # Small enough for legacy limits

    def test_content_type_override(self):
        """Content type can be overridden."""
        output = '{"key": "value"}'  # Looks like JSON
        config = TruncationConfig(max_tokens=100, use_content_aware=True)

        result = truncate_output(output, config, content_type="text")

        assert result.content_type == "text"

    def test_preserve_errors_flag(self):
        """preserve_errors flag should affect log truncation."""
        lines = ["ERROR: Important error"] + ["INFO: msg" for _ in range(100)]
        output = "\n".join(lines)

        config_preserve = TruncationConfig(
            max_tokens=50, use_content_aware=True, preserve_errors=True
        )
        result_preserve = truncate_output(output, config_preserve, content_type="logs")

        assert "Important error" in result_preserve.content

    def test_fallback_on_error(self):
        """Should fallback to text truncation on errors."""
        # Malformed JSON that will cause truncation error
        output = '{"key": "value"' + ("x" * 10000)
        config = TruncationConfig(max_tokens=100, use_content_aware=True)

        # Should not raise, should fallback to text
        result = truncate_output(output, config)

        assert result.truncated
        # May detect as text after fallback
        assert result.content_type in ("json", "text")


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_output(self):
        """Empty output should not be truncated."""
        config = TruncationConfig(max_tokens=100, use_content_aware=True)
        result = truncate_output("", config)

        assert not result.truncated
        assert result.content == ""

    def test_whitespace_only(self):
        """Whitespace-only output."""
        config = TruncationConfig(max_tokens=100, use_content_aware=True)
        result = truncate_output("   \n\n  ", config)

        assert not result.truncated

    def test_very_large_json(self):
        """Very large JSON should be truncated."""
        data = [{"id": i, "data": "x" * 1000} for i in range(100)]
        output = json.dumps(data)
        config = TruncationConfig(max_tokens=500, use_content_aware=True)

        result = truncate_output(output, config)

        assert result.truncated
        assert result.content_type == "json"

    def test_mixed_content(self):
        """Mixed content should pick best match."""
        output = """Some text at the start
{"json": "object"}
More text after"""
        config = TruncationConfig(max_tokens=100, use_content_aware=True)

        result = truncate_output(output, config)

        # Should detect as text (not pure JSON)
        assert result.content_type == "text"


class TestJsonArrayLimit:
    """Test json_array_limit config field is respected."""

    def test_json_array_limit_respected(self):
        """json_array_limit config value should control truncation cutoff."""
        # Build an array with 20 items, each large enough to need truncation
        data = [{"id": i, "value": "x" * 200} for i in range(20)]
        import json
        output = json.dumps(data)

        # With json_array_limit=5, should keep only 5 items (head 2 + tail 3)
        config = TruncationConfig(
            max_tokens=50,
            use_content_aware=True,
            json_array_limit=5,
        )
        result = truncate_output(output, config)

        assert result.truncated
        assert result.content_type == "json"
        # Should mention 15 items truncated (20 - 5)
        assert "15 items truncated" in result.content

    def test_json_array_limit_default_ten(self):
        """Default json_array_limit=10 should keep first 5 + last 5."""
        data = [{"id": i, "value": "x" * 200} for i in range(30)]
        import json
        output = json.dumps(data)

        config = TruncationConfig(
            max_tokens=50,
            use_content_aware=True,
            json_array_limit=10,
        )
        result = truncate_output(output, config)

        assert result.truncated
        # Should mention 20 items truncated (30 - 10)
        assert "20 items truncated" in result.content
