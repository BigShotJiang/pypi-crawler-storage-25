"""Tests for cross-conversation project memory."""

from harnessutils.manager import ConversationManager
from harnessutils.storage.memory import MemoryStorage


class TestProjectMemory:
    """Test project-scoped cross-conversation memory."""

    def setup_method(self):
        """Set up test fixtures."""
        self.storage = MemoryStorage()
        self.manager = ConversationManager(storage=self.storage)

    def test_set_get_memory(self):
        """Setting and getting a memory key should work."""
        self.manager.set_memory("project1", "user_name", "Alice")
        result = self.manager.get_memory("project1", "user_name")
        assert result == "Alice"

    def test_get_memory_default(self):
        """Getting non-existent key returns default."""
        result = self.manager.get_memory("project1", "missing_key", default="fallback")
        assert result == "fallback"

    def test_get_memory_default_none(self):
        """Getting non-existent key returns None when no default provided."""
        result = self.manager.get_memory("project1", "missing_key")
        assert result is None

    def test_delete_memory(self):
        """Deleting a memory key should remove it."""
        self.manager.set_memory("project1", "key", "value")
        self.manager.delete_memory("project1", "key")
        result = self.manager.get_memory("project1", "key")
        assert result is None

    def test_delete_nonexistent_key_no_error(self):
        """Deleting a non-existent key should not raise."""
        self.manager.delete_memory("project1", "nonexistent")  # Should not raise

    def test_list_memory(self):
        """list_memory should return all stored keys."""
        self.manager.set_memory("project1", "key1", "val1")
        self.manager.set_memory("project1", "key2", "val2")

        result = self.manager.list_memory("project1")
        assert result == {"key1": "val1", "key2": "val2"}

    def test_list_memory_empty(self):
        """list_memory for new project returns empty dict."""
        result = self.manager.list_memory("new_project")
        assert result == {}

    def test_memory_across_projects(self):
        """Memory for different projects should be isolated."""
        self.manager.set_memory("project1", "key", "project1_value")
        self.manager.set_memory("project2", "key", "project2_value")

        assert self.manager.get_memory("project1", "key") == "project1_value"
        assert self.manager.get_memory("project2", "key") == "project2_value"

    def test_memory_persists_across_conversations(self):
        """Memory should persist across different conversations in same project."""
        # Set memory in one conversation context
        self.manager.set_memory("myproject", "user_pref", "dark_mode")

        # Create a new manager with same storage (simulates new conversation)
        manager2 = ConversationManager(storage=self.storage)

        # Memory should still be available
        result = manager2.get_memory("myproject", "user_pref")
        assert result == "dark_mode"

    def test_memory_stores_complex_values(self):
        """Memory should store any JSON-serializable value."""
        preferences = {
            "theme": "dark",
            "language": "python",
            "tools": ["read", "write", "bash"],
        }
        self.manager.set_memory("proj", "preferences", preferences)

        result = self.manager.get_memory("proj", "preferences")
        assert result == preferences

    def test_memory_missing_backend(self):
        """_load_project_memory handles AttributeError from backends without memory support."""
        class LegacyStorage:
            """Storage backend without memory methods."""
            conversations: dict = {}
            messages: dict = {}

            def save_conversation(self, *args, **kwargs): pass
            def load_conversation(self, conv_id, *args, **kwargs):
                raise FileNotFoundError()
            def save_message(self, *args, **kwargs): pass
            def load_message(self, *args, **kwargs): raise FileNotFoundError()
            def list_messages(self, *args, **kwargs): return []
            def save_truncated_output(self, *args, **kwargs): pass
            # No save_project_memory / load_project_memory

        manager = ConversationManager(storage=LegacyStorage())

        # Should return empty dict (no AttributeError raised)
        result = manager._load_project_memory("any_project")
        assert result == {}

        # get_memory should also handle gracefully
        result2 = manager.get_memory("any_project", "key", default="default_val")
        assert result2 == "default_val"
