"""Tests for context snapshot functionality."""

import json
import tempfile
from pathlib import Path

from harnessutils import ConversationManager
from harnessutils.models.message import Message
from harnessutils.models.parts import (
    CompactionPart,
    PatchPart,
    ReasoningPart,
    StepFinishPart,
    StepStartPart,
    SubtaskPart,
    TextPart,
    TimeInfo,
    ToolPart,
    ToolState,
)
from harnessutils.snapshots import Snapshot, SnapshotManager
from harnessutils.utils.ids import generate_id


def test_create_snapshot_basic():
    """Test basic snapshot creation."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add a message
    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="Hello"))
    manager.add_message(conv.id, msg)

    # Create snapshot
    snapshot = manager.create_snapshot(conv.id)

    assert snapshot is not None
    assert snapshot.conversation_id == conv.id
    assert snapshot.snapshot_id is not None
    assert len(snapshot.messages) == 1
    assert snapshot.timestamp > 0


def test_snapshot_with_metadata():
    """Test snapshot with custom metadata."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    snapshot = manager.create_snapshot(
        conv.id,
        metadata={"reason": "test_baseline", "version": "1.0"}
    )

    assert snapshot.metadata["reason"] == "test_baseline"
    assert snapshot.metadata["version"] == "1.0"


def test_restore_snapshot():
    """Test restoring conversation from snapshot."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add messages
    msg1 = Message(id=generate_id("msg"), role="user")
    msg1.add_part(TextPart(text="First message"))
    manager.add_message(conv.id, msg1)

    msg2 = Message(id=generate_id("msg"), role="assistant")
    msg2.add_part(TextPart(text="Response"))
    manager.add_message(conv.id, msg2)

    # Create snapshot
    snapshot = manager.create_snapshot(conv.id)

    # Add more messages
    msg3 = Message(id=generate_id("msg"), role="user")
    msg3.add_part(TextPart(text="Third message"))
    manager.add_message(conv.id, msg3)

    assert len(manager.get_messages(conv.id)) == 3

    # Restore snapshot
    restored_conv_id = manager.restore_snapshot(snapshot.snapshot_id)

    assert restored_conv_id == conv.id

    # Should have original 2 messages
    restored_messages = manager.get_messages(restored_conv_id)
    assert len(restored_messages) == 2
    # Check that correct messages are present (order may vary due to alphabetic sort)
    restored_ids = {msg.id for msg in restored_messages}
    assert msg1.id in restored_ids
    assert msg2.id in restored_ids
    assert msg3.id not in restored_ids


def test_compare_snapshots():
    """Test comparing two snapshots."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add initial message
    msg1 = Message(id=generate_id("msg"), role="user")
    msg1.add_part(TextPart(text="Initial"))
    manager.add_message(conv.id, msg1)

    # Create first snapshot
    snap1 = manager.create_snapshot(conv.id)

    # Add more messages
    msg2 = Message(id=generate_id("msg"), role="assistant")
    msg2.add_part(TextPart(text="Response"))
    manager.add_message(conv.id, msg2)

    msg3 = Message(id=generate_id("msg"), role="user")
    msg3.add_part(TextPart(text="Follow-up"))
    manager.add_message(conv.id, msg3)

    # Create second snapshot
    snap2 = manager.create_snapshot(conv.id)

    # Compare
    diff = manager.compare_snapshots(snap1.snapshot_id, snap2.snapshot_id)

    assert diff is not None
    assert diff.messages_added == 2
    assert diff.messages_removed == 0
    assert len(diff.message_changes) > 0


def test_export_import_snapshot():
    """Test exporting and importing snapshots to/from JSON."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add message
    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="Test message"))
    manager.add_message(conv.id, msg)

    # Create snapshot
    original_snap = manager.create_snapshot(conv.id, metadata={"test": "export"})

    # Export to temp file
    with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".json") as f:
        temp_path = f.name

    try:
        manager.export_snapshot(original_snap.snapshot_id, temp_path)

        # Verify file exists and is valid JSON
        assert Path(temp_path).exists()

        with open(temp_path) as f:
            data = json.load(f)

        assert data["snapshot_id"] == original_snap.snapshot_id
        assert data["metadata"]["test"] == "export"

        # Import into new manager
        manager2 = ConversationManager()
        imported_snap = manager2.import_snapshot(temp_path)

        assert imported_snap.snapshot_id == original_snap.snapshot_id
        assert imported_snap.conversation_id == original_snap.conversation_id
        assert len(imported_snap.messages) == len(original_snap.messages)
        assert imported_snap.metadata["test"] == "export"

    finally:
        # Cleanup
        Path(temp_path).unlink()


def test_snapshot_with_tool_outputs():
    """Test snapshot preserves tool outputs."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add message with tool output
    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="File contents here"),
    )
    msg.add_part(part)
    manager.add_message(conv.id, msg)

    # Create snapshot
    snapshot = manager.create_snapshot(conv.id)

    # Verify tool output is preserved
    assert len(snapshot.messages) == 1
    msg_data = snapshot.messages[0]
    assert len(msg_data["parts"]) == 1
    part_data = msg_data["parts"][0]
    assert part_data["tool"] == "read"
    assert part_data["state"]["output"] == "File contents here"


def test_snapshot_manager_list_snapshots():
    """Test listing snapshots for a conversation."""
    manager = ConversationManager()
    conv1 = manager.create_conversation()
    conv2 = manager.create_conversation()

    # Create snapshots
    snap1 = manager.create_snapshot(conv1.id)
    snap2 = manager.create_snapshot(conv1.id)
    snap3 = manager.create_snapshot(conv2.id)

    # List all snapshots for conv1
    conv1_snaps = manager.snapshot_manager.list_snapshots(conv1.id)

    assert len(conv1_snaps) == 2
    assert snap1.snapshot_id in [s.snapshot_id for s in conv1_snaps]
    assert snap2.snapshot_id in [s.snapshot_id for s in conv1_snaps]
    assert snap3.snapshot_id not in [s.snapshot_id for s in conv1_snaps]


def test_snapshot_manager_delete_snapshot():
    """Test deleting a snapshot."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    snapshot = manager.create_snapshot(conv.id)

    # Verify snapshot exists
    assert manager.snapshot_manager.get_snapshot(snapshot.snapshot_id) is not None

    # Delete snapshot
    deleted = manager.snapshot_manager.delete_snapshot(snapshot.snapshot_id)

    assert deleted is True
    assert manager.snapshot_manager.get_snapshot(snapshot.snapshot_id) is None


def test_snapshot_serialization():
    """Test snapshot to_dict and from_dict."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="Test"))
    manager.add_message(conv.id, msg)

    original = manager.create_snapshot(conv.id)

    # Serialize and deserialize
    data = original.to_dict()
    from harnessutils.snapshots import Snapshot

    restored = Snapshot.from_dict(data)

    assert restored.snapshot_id == original.snapshot_id
    assert restored.conversation_id == original.conversation_id
    assert restored.timestamp == original.timestamp
    assert len(restored.messages) == len(original.messages)


def test_snapshot_comparison_no_changes():
    """Test comparing identical snapshots."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="Same"))
    manager.add_message(conv.id, msg)

    snap1 = manager.create_snapshot(conv.id)
    snap2 = manager.create_snapshot(conv.id)  # Same state

    diff = manager.compare_snapshots(snap1.snapshot_id, snap2.snapshot_id)

    assert diff is not None
    assert diff.messages_added == 0
    assert diff.messages_removed == 0


def test_restore_snapshot_not_found():
    """Test restoring non-existent snapshot raises error."""
    manager = ConversationManager()

    try:
        manager.restore_snapshot("nonexistent_snapshot_id")
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError as e:
        assert "not found" in str(e).lower()


def test_export_snapshot_not_found():
    """Test exporting non-existent snapshot raises error."""
    manager = ConversationManager()

    with tempfile.NamedTemporaryFile(suffix=".json") as f:
        try:
            manager.export_snapshot("nonexistent_snapshot_id", f.name)
            assert False, "Should have raised FileNotFoundError"
        except FileNotFoundError as e:
            assert "not found" in str(e).lower()


# ---------------------------------------------------------------------------
# Restore path: all part type deserialization
# ---------------------------------------------------------------------------


def _make_manager_with_msg(part: object) -> tuple[ConversationManager, str, str]:
    """Helper: create a manager, conversation, and message with one part."""
    manager = ConversationManager()
    conv = manager.create_conversation()
    msg = Message(id=generate_id("msg"), role="assistant")
    msg.add_part(part)  # type: ignore[arg-type]
    manager.add_message(conv.id, msg)
    return manager, conv.id, msg.id


def test_restore_snapshot_reasoning_part():
    """restore_snapshot correctly deserializes a ReasoningPart."""
    manager, conv_id, _ = _make_manager_with_msg(ReasoningPart(text="deep thought"))
    snapshot = manager.create_snapshot(conv_id)
    msgs, _ = manager.snapshot_manager.restore_snapshot(snapshot)

    assert len(msgs) == 1
    assert msgs[0].parts[0].type == "reasoning"
    assert msgs[0].parts[0].text == "deep thought"  # type: ignore[attr-defined]


def test_restore_snapshot_tool_part_with_time_info():
    """restore_snapshot correctly deserializes a ToolPart whose state has TimeInfo."""
    tool_part = ToolPart(
        tool="read_file",
        call_id="c_time",
        state=ToolState(
            status="completed",
            output="file contents",
            time=TimeInfo(start=1000, end=2000, compacted=None),
        ),
    )
    manager, conv_id, _ = _make_manager_with_msg(tool_part)
    snapshot = manager.create_snapshot(conv_id)
    msgs, _ = manager.snapshot_manager.restore_snapshot(snapshot)

    assert msgs[0].parts[0].type == "tool"
    restored = msgs[0].parts[0]
    assert restored.tool == "read_file"  # type: ignore[attr-defined]
    assert restored.state.time is not None  # type: ignore[attr-defined]
    assert restored.state.time.start == 1000  # type: ignore[attr-defined]
    assert restored.state.time.end == 2000  # type: ignore[attr-defined]


def test_restore_snapshot_step_start_part():
    """restore_snapshot correctly deserializes a StepStartPart."""
    manager, conv_id, _ = _make_manager_with_msg(StepStartPart(snapshot="snap_001"))
    snapshot = manager.create_snapshot(conv_id)
    msgs, _ = manager.snapshot_manager.restore_snapshot(snapshot)

    assert msgs[0].parts[0].type == "step-start"
    assert msgs[0].parts[0].snapshot == "snap_001"  # type: ignore[attr-defined]


def test_restore_snapshot_step_finish_part():
    """restore_snapshot correctly deserializes a StepFinishPart."""
    manager, conv_id, _ = _make_manager_with_msg(
        StepFinishPart(reason="tool-calls", snapshot="snap_002", cost=0.05)
    )
    snapshot = manager.create_snapshot(conv_id)
    msgs, _ = manager.snapshot_manager.restore_snapshot(snapshot)

    part = msgs[0].parts[0]
    assert part.type == "step-finish"
    assert part.reason == "tool-calls"  # type: ignore[attr-defined]
    assert part.cost == 0.05  # type: ignore[attr-defined]


def test_restore_snapshot_compaction_part():
    """restore_snapshot correctly deserializes a CompactionPart."""
    manager, conv_id, _ = _make_manager_with_msg(CompactionPart(auto=True))
    snapshot = manager.create_snapshot(conv_id)
    msgs, _ = manager.snapshot_manager.restore_snapshot(snapshot)

    part = msgs[0].parts[0]
    assert part.type == "compaction"
    assert part.auto is True  # type: ignore[attr-defined]


def test_restore_snapshot_patch_part():
    """restore_snapshot correctly deserializes a PatchPart."""
    manager, conv_id, _ = _make_manager_with_msg(
        PatchPart(hash="abc123", files=["src/foo.py", "src/bar.py"])
    )
    snapshot = manager.create_snapshot(conv_id)
    msgs, _ = manager.snapshot_manager.restore_snapshot(snapshot)

    part = msgs[0].parts[0]
    assert part.type == "patch"
    assert part.hash == "abc123"  # type: ignore[attr-defined]
    assert part.files == ["src/foo.py", "src/bar.py"]  # type: ignore[attr-defined]


def test_restore_snapshot_subtask_part():
    """restore_snapshot correctly deserializes a SubtaskPart."""
    manager, conv_id, _ = _make_manager_with_msg(
        SubtaskPart(prompt="do something", description="helper task", agent="worker")
    )
    snapshot = manager.create_snapshot(conv_id)
    msgs, _ = manager.snapshot_manager.restore_snapshot(snapshot)

    part = msgs[0].parts[0]
    assert part.type == "subtask"
    assert part.prompt == "do something"  # type: ignore[attr-defined]
    assert part.agent == "worker"  # type: ignore[attr-defined]


def test_restore_snapshot_unknown_part_type():
    """Unknown part type in snapshot data falls back to empty TextPart."""
    manager = ConversationManager()
    conv = manager.create_conversation()
    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="original"))
    manager.add_message(conv.id, msg)

    snapshot = manager.create_snapshot(conv.id)

    # Inject an unknown part type directly
    snapshot.messages[0]["parts"][0]["type"] = "future_unknown_type"

    msgs, _ = manager.snapshot_manager.restore_snapshot(snapshot)

    # Falls back to a TextPart with empty text
    assert msgs[0].parts[0].type == "text"


# ---------------------------------------------------------------------------
# compare_snapshots edge cases
# ---------------------------------------------------------------------------


def test_compare_snapshots_missing_returns_none():
    """compare_snapshots returns None when a snapshot ID doesn't exist."""
    manager = ConversationManager()
    conv = manager.create_conversation()
    snap = manager.create_snapshot(conv.id)

    result = manager.compare_snapshots(snap.snapshot_id, "nonexistent_id")
    assert result is None


def test_compare_snapshots_removed_messages():
    """compare_snapshots reports removed message IDs when snap2 has fewer messages."""
    sm = SnapshotManager()
    msg1 = {"id": "msg-a", "role": "user", "parts": []}
    msg2 = {"id": "msg-b", "role": "assistant", "parts": []}

    snap1 = Snapshot(
        snapshot_id="s1",
        conversation_id="c1",
        timestamp=1000,
        messages=[msg1, msg2],
        conversation={},
        config={"model": "claude"},
    )
    snap2 = Snapshot(
        snapshot_id="s2",
        conversation_id="c1",
        timestamp=2000,
        messages=[msg1],  # msg-b removed
        conversation={},
        config={"model": "claude"},
    )
    sm._snapshots["s1"] = snap1
    sm._snapshots["s2"] = snap2

    diff = sm.compare_snapshots("s1", "s2")

    assert diff is not None
    assert diff.messages_removed == 1
    removed_changes = [c for c in diff.message_changes if c["type"] == "removed"]
    assert len(removed_changes) == 1
    assert "msg-b" in removed_changes[0]["ids"]


def test_compare_snapshots_config_change():
    """compare_snapshots reports config_changes when configs differ."""
    sm = SnapshotManager()

    snap1 = Snapshot(
        snapshot_id="s1",
        conversation_id="c1",
        timestamp=1000,
        messages=[],
        conversation={},
        config={"model": "claude-3", "max_tokens": 4096},
    )
    snap2 = Snapshot(
        snapshot_id="s2",
        conversation_id="c1",
        timestamp=2000,
        messages=[],
        conversation={},
        config={"model": "claude-4", "max_tokens": 8192},
    )
    sm._snapshots["s1"] = snap1
    sm._snapshots["s2"] = snap2

    diff = sm.compare_snapshots("s1", "s2")

    assert diff is not None
    assert len(diff.config_changes) == 1
    assert diff.config_changes[0]["type"] == "config_modified"


# ---------------------------------------------------------------------------
# delete_snapshot edge cases
# ---------------------------------------------------------------------------


def test_delete_snapshot_returns_false_when_not_found():
    """delete_snapshot returns False when the snapshot ID doesn't exist."""
    sm = SnapshotManager()
    result = sm.delete_snapshot("does_not_exist")
    assert result is False
