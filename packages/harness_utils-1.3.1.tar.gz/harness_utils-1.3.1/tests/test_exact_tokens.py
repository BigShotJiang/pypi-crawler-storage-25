"""Tests for exact token counting with tiktoken."""

from harnessutils import ConversationManager, MemoryStorage, Message, TextPart, generate_id
from harnessutils.tokens.exact import count_tokens_exact


def test_calculate_context_usage_empty():
    """Test exact token counting with empty conversation."""
    storage = MemoryStorage()
    manager = ConversationManager(storage)

    conv = manager.create_conversation()

    # Empty conversation should have minimal tokens
    token_count = manager.calculate_context_usage(conv.id)
    assert token_count >= 0


def test_calculate_context_usage_simple():
    """Test exact token counting with simple messages."""
    storage = MemoryStorage()
    manager = ConversationManager(storage)

    conv = manager.create_conversation()

    # Add a simple user message
    msg1 = Message(id=generate_id("msg"), role="user")
    msg1.add_part(TextPart(text="Hello, how are you?"))
    manager.add_message(conv.id, msg1)

    # Add an assistant response
    msg2 = Message(id=generate_id("msg"), role="assistant")
    msg2.add_part(TextPart(text="I'm doing well, thank you!"))
    manager.add_message(conv.id, msg2)

    token_count = manager.calculate_context_usage(conv.id)

    # Should have tokens for both messages
    # Rough estimate: "Hello, how are you?" ~5 tokens, response ~7 tokens, plus overhead
    assert token_count > 10
    assert token_count < 100


def test_calculate_context_usage_long_text():
    """Test exact token counting with longer text."""
    storage = MemoryStorage()
    manager = ConversationManager(storage)

    conv = manager.create_conversation()

    # Add a message with longer text
    msg = Message(id=generate_id("msg"), role="user")
    text = "This is a longer message. " * 100  # 2700 chars, ~600-700 tokens
    msg.add_part(TextPart(text=text))
    manager.add_message(conv.id, msg)

    token_count = manager.calculate_context_usage(conv.id)

    # Should be roughly 600-700 tokens for this text
    assert token_count > 500
    assert token_count < 800


def test_calculate_context_usage_multiple_messages():
    """Test exact token counting with multiple messages."""
    storage = MemoryStorage()
    manager = ConversationManager(storage)

    conv = manager.create_conversation()

    # Add multiple messages
    for i in range(10):
        msg = Message(id=generate_id("msg"), role="user" if i % 2 == 0 else "assistant")
        msg.add_part(TextPart(text=f"Message number {i}"))
        manager.add_message(conv.id, msg)

    token_count = manager.calculate_context_usage(conv.id)

    # Should have tokens for all 10 messages
    assert token_count > 30  # At least 3 tokens per message
    assert token_count < 200  # But not too many


def test_calculate_context_usage_different_models():
    """Test exact token counting with different model names."""
    storage = MemoryStorage()
    manager = ConversationManager(storage)

    conv = manager.create_conversation()

    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="Hello"))
    manager.add_message(conv.id, msg)

    # Should work with different model names
    token_count_claude = manager.calculate_context_usage(conv.id, "claude-3-5-sonnet-20241022")
    token_count_gpt4 = manager.calculate_context_usage(conv.id, "gpt-4")

    # Both should give similar counts (all use cl100k_base)
    assert token_count_claude > 0
    assert token_count_gpt4 > 0
    assert abs(token_count_claude - token_count_gpt4) < 5


def test_calculate_context_usage_with_special_tokens():
    """Test that special token strings in content are counted as normal text.

    Regression test for ValueError when content contains strings like
    <|endoftext|>, <|im_start|>, etc. that tiktoken treats as special tokens.
    """
    storage = MemoryStorage()
    manager = ConversationManager(storage)

    conv = manager.create_conversation()

    # Add messages containing special token strings
    msg1 = Message(id=generate_id("msg"), role="user")
    msg1.add_part(TextPart(text="The model uses <|endoftext|> as a separator"))
    manager.add_message(conv.id, msg1)

    msg2 = Message(id=generate_id("msg"), role="assistant")
    msg2.add_part(TextPart(text="Yes, <|im_start|> and <|im_end|> are also special tokens"))
    manager.add_message(conv.id, msg2)

    # Should not raise ValueError about disallowed special tokens
    token_count = manager.calculate_context_usage(conv.id)

    # Should successfully count tokens (treating special token strings as normal text)
    assert token_count > 20
    assert token_count < 100


# ---------------------------------------------------------------------------
# Structured (list) content — covers the elif isinstance(content, list) path
# ---------------------------------------------------------------------------

def test_count_tokens_list_content_text_part():
    """Message with list-format content containing a text block."""
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "Please run the bash tool."},
            ],
        }
    ]
    count = count_tokens_exact(messages)
    assert count > 0


def test_count_tokens_tool_use_block():
    """Message with tool_use content block (tool_use_id, name, input)."""
    messages = [
        {
            "role": "assistant",
            "content": [
                {
                    "type": "tool_use",
                    "tool_use_id": "call_abc123",
                    "name": "bash",
                    "input": {"command": "ls -la"},
                }
            ],
        }
    ]
    count = count_tokens_exact(messages)
    # Should count: type + tool_use_id + name + json(input) + overhead
    assert count > 5


def test_count_tokens_tool_result_block():
    """Message with tool_result content block (tool_use_id, content)."""
    messages = [
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "call_abc123",
                    "content": "file1.txt\nfile2.txt\nfile3.txt",
                }
            ],
        }
    ]
    count = count_tokens_exact(messages)
    assert count > 5


def test_count_tokens_mixed_list_content():
    """Message with multiple blocks of different types."""
    messages = [
        {
            "role": "assistant",
            "content": [
                {"type": "text", "text": "I'll run the command."},
                {
                    "type": "tool_use",
                    "tool_use_id": "call_xyz",
                    "name": "read",
                    "input": {"path": "/etc/hosts"},
                },
            ],
        }
    ]
    count = count_tokens_exact(messages)
    assert count > 10


def test_count_tokens_list_greater_than_string():
    """Structured content should produce a higher count than an empty message."""
    empty = [{"role": "user", "content": []}]
    with_content = [
        {
            "role": "user",
            "content": [{"type": "text", "text": "Hello world"}],
        }
    ]
    assert count_tokens_exact(with_content) > count_tokens_exact(empty)
