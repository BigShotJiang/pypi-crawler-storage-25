# OpenAI Codex Harness Engineering - Key Findings

**Source:** "Harness engineering: leveraging Codex in an agent-first world" (OpenAI, Feb 11, 2026)
**Author:** Ryan Lopopolo, Member of Technical Staff

## Executive Summary

OpenAI team built an internal product over 5 months with **0 lines of manually-written code**. All code (1M lines, ~1,500 PRs) written by Codex agents. 3 engineers driving Codex averaged 3.5 PRs/engineer/day. Estimated 1/10th the time vs manual coding.

**Core Philosophy: "Humans steer. Agents execute."**

---

## 1. Redefining the Engineer's Role

### What Changed
- Engineers no longer write code directly
- Primary job: enabling agents to do useful work
- Design environments, specify intent, build feedback loops
- Work depth-first: break goals into building blocks, prompt agent to construct them

### When Something Failed
**Never "try harder"** - instead ask: "what capability is missing, and how do we make it both legible and enforceable for the agent?"

### Human Interaction Model
- Interact almost entirely through prompts
- Engineer describes task → agent opens PR
- Agents use standard dev tools directly (gh, local scripts, repo-embedded skills)
- Humans may review PRs but aren't required
- Over time, pushed almost all review to agent-to-agent

---

## 2. Increasing Application Legibility

### Bottleneck: Human QA Capacity
**Solution:** Make UI, logs, metrics directly legible to Codex

### Techniques
- **Per-worktree app instances**: Codex launches one instance per change
- **Chrome DevTools Protocol**: Wired into agent runtime
  - Skills for DOM snapshots, screenshots, navigation
  - Enables: reproduce bugs, validate fixes, reason about UI behavior
- **Ephemeral observability stack**: Per worktree
  - Logs queryable via LogQL
  - Metrics queryable via PromQL
  - Fully isolated, torn down after task completion

### Example Prompts That Became Tractable
- "Ensure service startup completes in under 800ms"
- "No span in these four critical user journeys exceeds two seconds"

### Key Insight
> "We regularly see single Codex runs work on a single task for upwards of six hours (often while the humans are sleeping)."

---

## 3. Repository Knowledge as System of Record

### What Failed: The "One Big AGENTS.md" Approach

**Why it failed:**
1. **Context is scarce**: Giant file crowds out task, code, relevant docs
2. **Too much guidance = no guidance**: When everything is "important," nothing is
3. **Rots instantly**: Becomes graveyard of stale rules, agents can't tell what's true
4. **Hard to verify**: Single blob doesn't lend itself to mechanical checks

### Solution: AGENTS.md as Table of Contents

**Structure:**
- Short AGENTS.md (~100 lines) injected into context as a map
- Structured docs/ directory as system of record

```
AGENTS.md
ARCHITECTURE.md
docs/
├── design-docs/
│   ├── index.md
│   ├── core-beliefs.md
│   └── ...
├── exec-plans/
│   ├── active/
│   ├── completed/
│   └── tech-debt-tracker.md
├── generated/
│   └── db-schema.md
├── product-specs/
│   ├── index.md
│   ├── new-user-onboarding.md
│   └── ...
├── references/
│   ├── design-system-reference-llms.txt
│   ├── nixpacks-llms.txt
│   └── ...
├── DESIGN.md
├── FRONTEND.md
├── PLANS.md
└── PRODUCT_SENSE.md
```

### Key Components

**Design docs**: Catalogued and indexed, including verification status and core beliefs
**Architecture docs**: Top-level map of domains and package layering
**Plans as first-class artifacts**:
- Lightweight plans for small changes
- Complex work captured in execution plans with progress/decision logs
- Active plans, completed plans, tech debt all versioned and co-located

### Progressive Disclosure
Give agents a **map**, not a 1,000-page manual. Agents start with small entry point and are taught where to look next.

### Mechanical Enforcement
- Dedicated linters and CI jobs validate knowledge base
- Check: up to date, cross-linked, structured correctly
- Recurring "doc-gardening" agent scans for stale docs
- Opens fix-up PRs automatically

---

## 4. Agent Legibility is the Goal

### Core Principle
**Codebase optimized first for Codex's legibility, not human preferences**

> "From the agent's point of view, anything it can't access in-context while running effectively doesn't exist."

### What Doesn't Exist to Agents
- Google Docs
- Chat threads (Slack discussions)
- Knowledge in people's heads

### What Does Exist
- Repository-local, versioned artifacts
- Code, markdown, schemas, executable plans

### Critical Realization
> "That Slack discussion that aligned the team on an architectural pattern? If it isn't discoverable to the agent, it's illegible in the same way it would be unknown to a new hire joining three months later."

### Onboarding Analogy
Give agents the same information you'd give a new teammate:
- Product principles
- Engineering norms
- Team culture (emoji preferences included!)

### Technology Choices
- Favor dependencies that can be fully internalized and reasoned about in-repo
- "Boring" technologies easier for agents (composability, API stability, well-represented in training set)
- Sometimes cheaper to reimplement subsets than work around opaque upstream behavior
- Example: Custom map-with-concurrency helper instead of generic p-limit package
  - Tightly integrated with OpenTelemetry
  - 100% test coverage
  - Behaves exactly as runtime expects

---

## 5. Enforcing Architecture and Taste

### Core Philosophy
**Enforce invariants, not micromanage implementations**

Example: Require Codex to "parse data shapes at the boundary" but not prescriptive on how (model chose Zod, but library wasn't specified)

### Rigid Architectural Model

**Agents are most effective in environments with strict boundaries and predictable structure**

**Layered Domain Architecture:**
Within each business domain (e.g., App Settings):
- Types → Config → Repo → Service → Runtime → UI
- Code can only depend "forward" through layers
- Cross-cutting concerns (auth, connectors, telemetry, feature flags) enter through single interface: **Providers**
- Anything else: disallowed and mechanically enforced

### Why This Matters
> "This is the kind of architecture you usually postpone until you have hundreds of engineers. With coding agents, it's an early prerequisite: the constraints are what allows speed without decay or architectural drift."

### Enforcement Mechanisms
1. **Custom linters** (Codex-generated!)
2. **Structural tests**
3. **Taste invariants**:
   - Structured logging
   - Naming conventions for schemas/types
   - File size limits
   - Platform-specific reliability requirements

### Error Messages
Custom lint error messages inject remediation instructions into agent context

### Human-First vs Agent-First
- Human-first: Rules might feel pedantic or constraining
- Agent-first: **Rules become multipliers** - once encoded, apply everywhere at once

### Platform Organization Analogy
> "Enforce boundaries centrally, allow autonomy locally. You care deeply about boundaries, correctness, and reproducibility. Within those boundaries, you allow teams—or agents—significant freedom."

### Output Quality
Code doesn't always match human stylistic preferences, **and that's okay**. As long as output is correct, maintainable, and legible to future agent runs, it meets the bar.

### Continuous Feedback Loop
- Review comments captured as documentation updates
- User-facing bugs encoded directly into tooling
- When documentation falls short, promote the rule into code

---

## 6. Throughput Changes the Merge Philosophy

### Key Shift
Many conventional engineering norms became counterproductive at high agent throughput.

### New Operating Model
- **Minimal blocking merge gates**
- **Short-lived pull requests**
- **Test flakes**: Addressed with follow-up runs rather than blocking indefinitely
- **Philosophy**: In a system where agent throughput far exceeds human attention:
  - Corrections are cheap
  - Waiting is expensive

### Tradeoff Context
> "This would be irresponsible in a low-throughput environment. Here, it's often the right tradeoff."

---

## 7. What "Agent-Generated" Actually Means

### Everything in the Codebase

**Agents produce:**
- Product code and tests
- CI configuration and release tooling
- Internal developer tools
- Documentation and design history
- Evaluation harnesses
- Review comments and responses
- Scripts that manage the repository itself
- Production dashboard definition files

### Human Role
- Remain in the loop
- Work at different layer of abstraction
- Prioritize work
- Translate user feedback into acceptance criteria
- Validate outcomes
- When agent struggles: identify what's missing (tools, guardrails, documentation)
- **Always have Codex itself write the fix**

### Agent Autonomy
Agents use standard development tools directly:
- Pull review feedback
- Respond inline
- Push updates
- Often squash and merge their own pull requests

---

## 8. Increasing Levels of Autonomy

### Threshold Crossed
Repository recently reached point where Codex can **end-to-end drive a new feature** from single prompt.

### Full Autonomous Loop
Given a single prompt, agent can now:
1. Validate current state of codebase
2. Reproduce a reported bug
3. Record video demonstrating the failure
4. Implement a fix
5. Validate the fix by driving the application
6. Record second video demonstrating resolution
7. Open pull request
8. Respond to agent and human feedback
9. Detect and remediate build failures
10. Escalate to human only when judgment is required
11. Merge the change

### Important Caveat
> "This behavior depends heavily on the specific structure and tooling of this repository and should not be assumed to generalize without similar investment—at least, not yet."

---

## 9. Entropy and Garbage Collection

### The Problem
Full agent autonomy introduces novel problems. Codex replicates patterns that already exist—even uneven or suboptimal ones. Over time, this leads to drift.

### Initial Approach (Didn't Scale)
Humans spent every Friday (20% of the week) cleaning up "AI slop"

### Solution: Golden Principles + Automated Cleanup

**Golden Principles:**
Opinionated, mechanical rules that keep codebase legible and consistent for future agent runs.

**Examples:**
1. Prefer shared utility packages over hand-rolled helpers (keeps invariants centralized)
2. Don't probe data "YOLO-style" - validate boundaries or rely on typed SDKs (agent can't accidentally build on guessed shapes)

**Automated Process:**
- Regular cadence of background Codex tasks
- Scan for deviations
- Update quality grades
- Open targeted refactoring pull requests
- Most can be reviewed in under a minute and automerged

### The Analogy
> "This functions like garbage collection. Technical debt is like a high-interest loan: it's almost always better to pay it down continuously in small increments than to let it compound and tackle it in painful bursts."

### The Outcome
- Human taste captured once
- Enforced continuously on every line of code
- Catch and resolve bad patterns on daily basis
- Prevent spread for days or weeks

---

## 10. What They're Still Learning

### Known Unknowns
1. **Long-term architectural coherence**: How does it evolve over years in fully agent-generated system?
2. **Human judgment leverage**: Where does it add most value and how to encode it so it compounds?
3. **Model capability evolution**: How will system evolve as models continue to improve?

### What's Become Clear
> "Building software still demands discipline, but the discipline shows up more in the scaffolding rather than the code."

**New Focus Areas:**
- Tooling
- Abstractions
- Feedback loops that keep codebase coherent

### Most Difficult Challenges Now
> "Our most difficult challenges now center on designing environments, feedback loops, and control systems that help agents accomplish our goal: build and maintain complex, reliable software at scale."

---

## Key Metrics

- **Timeline**: 5 months (started late August 2025)
- **Team size**: Started with 3 engineers, now 7
- **Code volume**: ~1 million lines
- **Pull requests**: ~1,500 merged
- **Throughput**: 3.5 PRs per engineer per day (increasing as team grows)
- **Speed multiplier**: ~10x faster than manual coding
- **Users**: Hundreds of internal users, including daily power users
- **Longest autonomous runs**: 6+ hours while humans sleep

---

## Applicability to Other Agent Systems

These lessons directly apply to:
- Claude Code workflows
- GitHub Copilot Workspace
- Cursor AI
- Any agentic coding system

**Core transferable insights:**
1. Repository structure and documentation strategy
2. Making everything discoverable in-repo
3. Mechanical enforcement over documentation
4. Fast iteration with cheap corrections
5. Agent legibility as primary optimization target
6. Automated cleanup/maintenance agents
7. Treating technical debt as continuous paydown problem

---

## Questions for Later Discussion

1. How much of this applies to our current setup with Claude Code?
2. Should we restructure our docs/ directory following their pattern?
3. Can we create automated "doc-gardening" tasks?
4. What mechanical enforcement (linters) would be most valuable?
5. How do we balance "corrections are cheap" vs quality standards?
6. Should CLAUDE.md become a "table of contents" instead of comprehensive guide?
7. What "golden principles" should we encode for our codebase?
8. Can we set up agent-to-agent review workflows?

---

## Related Reading

- "Unlocking the Codex harness: how we built the App Server" (Feb 4, 2026)
- "Inside OpenAI's in-house data agent" (Jan 29, 2026)
- "Unrolling the Codex agent loop" (Jan 23, 2026)
