# Message Hooks

`MessageHooks` lets you inject behaviour at the two key points in
`ConversationManager.add_message()` without subclassing anything.

```
caller
  │
  ▼
on_before_add_message()   ← can modify the message, or raise to reject it
  │
  ▼
storage.save_message()    ← message written to disk / memory
  │
  ▼
on_after_add_message()    ← side effects: logging, audit, semantic memory
  │
  ▼
caller
```

---

## Quick start

```python
from harnessutils import ConversationManager, MessageHooks
from harnessutils.models.message import Message

def my_pre_hook(conversation_id: str, message: Message) -> Message:
    # inspect, modify, or raise
    return message

def my_post_hook(conversation_id: str, message: Message) -> None:
    # side effects only
    pass

manager = ConversationManager(
    message_hooks=MessageHooks(
        on_before_add_message=my_pre_hook,
        on_after_add_message=my_post_hook,
    )
)
```

Either hook is optional. Pass only the one you need.

---

## Pre-hook contract

```python
def hook(conversation_id: str, message: Message) -> Message
```

| What you do | Effect |
|---|---|
| `return message` | Message stored unchanged |
| `return modified_message` | Modified message stored instead |
| `raise AnyException` | Message **not** stored; exception propagates; post-hook **not** called |

The returned `Message` is what gets written to storage and what
`on_after_add_message` receives. You can return the same object
(mutated) or a brand-new one.

### Example — reject messages containing a forbidden phrase

```python
from harnessutils.models.message import Message
from harnessutils.models.parts import TextPart

class GuardrailViolation(Exception):
    pass

def jailbreak_guard(conv_id: str, msg: Message) -> Message:
    forbidden = ["ignore previous instructions", "disregard your system prompt"]
    for part in msg.parts:
        if part.type == "text":
            lower = part.text.lower()
            if any(phrase in lower for phrase in forbidden):
                raise GuardrailViolation(f"Blocked message in {conv_id}")
    return msg
```

### Example — redact PII before storage

```python
import re

_EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[a-z]{2,}", re.IGNORECASE)

def redact_pii(conv_id: str, msg: Message) -> Message:
    for part in msg.parts:
        if part.type == "text":
            part.text = _EMAIL_RE.sub("[REDACTED]", part.text)
    return msg
```

### Example — inject metadata on every message

```python
import time

def stamp(conv_id: str, msg: Message) -> Message:
    msg.metadata["ingested_at"] = int(time.time() * 1000)
    msg.metadata["conversation"] = conv_id
    return msg
```

---

## Post-hook contract

```python
def hook(conversation_id: str, message: Message) -> None
```

| What you do | Effect |
|---|---|
| Normal return | Nothing — return value is ignored |
| `raise AnyException` | Exception propagates to caller; message **already stored** |

The message received is the value returned by the pre-hook (or the
original message if no pre-hook was set). The message is already in
storage when this fires.

### Example — write every message to a semantic memory backend

```python
import asyncio
from harnessutils.models.message import Message

def index_to_memory(conv_id: str, msg: Message) -> None:
    # manager.semantic_memory is the SemanticMemoryBackend you passed in
    text_parts = [
        p.text for p in msg.parts if p.type == "text"
    ]
    if not text_parts:
        return
    content = "\n".join(text_parts)
    asyncio.get_event_loop().run_until_complete(
        manager.semantic_memory.add_artifact(
            content=content,
            kind="message",
            namespace=conv_id,
            metadata={"role": msg.role, "message_id": msg.id},
        )
    )
```

### Example — emit a structured audit log

```python
import json, logging

audit = logging.getLogger("audit")

def audit_log(conv_id: str, msg: Message) -> None:
    audit.info(json.dumps({
        "event": "message_stored",
        "conversation_id": conv_id,
        "message_id": msg.id,
        "role": msg.role,
        "parts": len(msg.parts),
    }))
```

### Example — update metrics

```python
from prometheus_client import Counter

MESSAGES_STORED = Counter("messages_stored_total", "Messages stored", ["role"])

def track_metrics(conv_id: str, msg: Message) -> None:
    MESSAGES_STORED.labels(role=msg.role).inc()
```

---

## Using hooks alongside semantic memory

`ConversationManager` holds `semantic_memory` as a plain attribute and
never calls it internally. The post-hook is the natural place to drive
artifact writes:

```python
from harnessutils import ConversationManager, MessageHooks, SemanticMemoryBackend

class MyMemoryBackend:
    # ... implements SemanticMemoryBackend protocol ...

backend = MyMemoryBackend()

def write_to_memory(conv_id: str, msg: Message) -> None:
    import asyncio
    loop = asyncio.get_event_loop()
    for part in msg.parts:
        if part.type == "tool" and part.state and part.state.output:
            loop.run_until_complete(
                backend.add_artifact(
                    content=part.state.output,
                    kind="tool_output",
                    namespace=conv_id,
                    metadata={"tool": part.tool, "message_id": msg.id},
                )
            )

manager = ConversationManager(
    semantic_memory=backend,
    message_hooks=MessageHooks(on_after_add_message=write_to_memory),
)
```

---

## Hook execution order

1. `on_before_add_message(conv_id, original_message)` → returns `stored_message`
2. `storage.save_message(...)` — `stored_message` written to disk
3. `_message_cache` updated
4. Conversation metadata updated (velocity, timestamp)
5. `on_after_add_message(conv_id, stored_message)`

If step 1 raises, steps 2–5 are skipped entirely.
If step 5 raises, the message has already been persisted (step 2 already ran).

---

## Thread safety

Hooks are called synchronously inside `add_message()`. If you need to
do async work (e.g. awaiting a database write), run it via
`asyncio.get_event_loop().run_until_complete(...)` or use a dedicated
background thread/queue. harness-utils does not manage an event loop.
