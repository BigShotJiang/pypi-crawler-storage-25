"""Regression tests for _customizations/ layer."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from sonzai import AgentCapabilities, ChatStreamEvent, StoredFact


class TestStoredFact:
    def test_imports_from_customizations(self) -> None:
        from sonzai._customizations import StoredFact as CustStoredFact

        assert StoredFact is CustStoredFact

    def test_roundtrips_all_spec_fields(self) -> None:
        payload = {
            "fact_id": "fact_123",
            "content": "user likes coffee",
            "fact_type": "preference",
            "importance": 0.8,
            "confidence": 0.95,
            "entity": "user",
            "source_type": "chat",
            "source_id": "msg_42",
            "session_id": "sess_abc",
            "mention_count": 3,
            "metadata": {"extra": "info"},
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-02T00:00:00Z",
        }
        fact = StoredFact.model_validate(payload)
        assert fact.fact_id == "fact_123"
        assert fact.session_id == "sess_abc"
        assert fact.source_id == "msg_42"
        assert fact.metadata == {"extra": "info"}

    def test_unknown_fields_raise_under_forbid(self) -> None:
        """Generated StoredFact uses extra='forbid' per spec
        additionalProperties: false. Unknown fields must raise
        ValidationError — this is the loud-drift-detection behavior that
        would have caught the release-time session_id/source_id bug.
        """
        with pytest.raises(ValidationError) as exc:
            StoredFact.model_validate({
                "fact_id": "x",
                "content": "y",
                "fact_type": "t",
                "importance": 0.0,
                "confidence": 0.0,
                "mention_count": 0,
                "created_at": "",
                "updated_at": "",
                "future_field_that_does_not_exist_yet": "foo",
            })
        assert "future_field_that_does_not_exist_yet" in str(exc.value)


class TestAgentCapabilities:
    # Required fields in the generated spec: imageGeneration, musicGeneration,
    # videoGeneration, voiceGeneration (no defaults → must always be present).
    _REQUIRED = {
        "imageGeneration": False,
        "musicGeneration": False,
        "videoGeneration": False,
        "voiceGeneration": False,
    }
    # Same required fields in snake_case form (for populate_by_name=True tests).
    _REQUIRED_SNAKE = {
        "image_generation": False,
        "music_generation": False,
        "video_generation": False,
        "voice_generation": False,
    }

    def test_imports_from_customizations(self) -> None:
        from sonzai._customizations import AgentCapabilities as CustAgentCapabilities

        assert AgentCapabilities is CustAgentCapabilities

    def test_camel_case_alias_input(self) -> None:
        """Server sends camelCase; SDK exposes snake_case with aliases."""
        payload = {
            **self._REQUIRED,
            "imageGeneration": True,
            "memoryMode": "full",
            "musicGeneration": False,
        }
        caps = AgentCapabilities.model_validate(payload)
        assert caps.custom_tools is None
        assert caps.image_generation is True
        assert caps.memory_mode == "full"

    def test_snake_case_input_also_works(self) -> None:
        """populate_by_name=True lets users pass either form."""
        payload = {
            **self._REQUIRED_SNAKE,
            "image_generation": True,
            "memory_mode": "summary",
        }
        caps = AgentCapabilities.model_validate(payload)
        assert caps.image_generation is True

    def test_dump_round_trips_to_camel(self) -> None:
        caps = AgentCapabilities.model_validate({
            **self._REQUIRED,
            "imageGeneration": True,
            "memoryMode": "full",
        })
        dumped = caps.model_dump(by_alias=True, exclude_none=True)
        assert "imageGeneration" in dumped
        assert "musicGeneration" in dumped
        assert "memoryMode" in dumped


class TestChatStreamEvent:
    def test_imports_from_customizations(self) -> None:
        from sonzai._customizations import ChatStreamEvent as CustChatStreamEvent

        assert ChatStreamEvent is CustChatStreamEvent

    def test_content_property_on_delta_frame(self) -> None:
        event = ChatStreamEvent.model_validate(
            {"choices": [{"delta": {"content": "Hello"}, "index": 0}]}
        )
        assert event.content == "Hello"

    def test_empty_event_has_no_content(self) -> None:
        event = ChatStreamEvent.model_validate({})
        assert event.content == ""
        assert not event.is_finished

    def test_is_finished_on_stop_frame(self) -> None:
        event = ChatStreamEvent.model_validate(
            {"choices": [{"delta": {"content": "."}, "finish_reason": "stop", "index": 0}]}
        )
        assert event.is_finished

    def test_is_finished_on_length_frame(self) -> None:
        event = ChatStreamEvent.model_validate(
            {"choices": [{"delta": {}, "finish_reason": "length", "index": 0}]}
        )
        assert event.is_finished

    def test_is_finished_on_content_filter_frame(self) -> None:
        event = ChatStreamEvent.model_validate(
            {"choices": [{"delta": {}, "finish_reason": "content_filter", "index": 0}]}
        )
        assert event.is_finished

    def test_is_finished_on_tool_calls_frame(self) -> None:
        event = ChatStreamEvent.model_validate(
            {"choices": [{"delta": {}, "finish_reason": "tool_calls", "index": 0}]}
        )
        assert event.is_finished

    def test_not_finished_on_empty_finish_reason(self) -> None:
        event = ChatStreamEvent.model_validate(
            {"choices": [{"delta": {"content": "x"}, "finish_reason": None, "index": 0}]}
        )
        assert not event.is_finished

    def test_client_extension_fields_default_empty(self) -> None:
        event = ChatStreamEvent.model_validate({})
        assert event.full_content == ""
        assert event.finish_reason == ""
        assert event.external_tool_calls == []
        assert event.is_token_error is False

    def test_client_extension_fields_round_trip(self) -> None:
        event = ChatStreamEvent(
            full_content="done",
            finish_reason="stop",
            continuation_token="abc",
            is_token_error=True,
        )
        assert event.full_content == "done"
        assert event.continuation_token == "abc"
        assert event.is_token_error is True

    def test_free_form_data_preserved(self) -> None:
        """`data` on side_effects frames is free-form per spec — must survive."""
        event = ChatStreamEvent.model_validate(
            {"type": "side_effects", "data": {"facts": [{"content": "x"}]}}
        )
        assert event.type == "side_effects"
        assert event.data == {"facts": [{"content": "x"}]}


class TestMemoryNodeMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import MemoryNode
        from sonzai._generated.models import MemoryNode as GenMemoryNode
        assert MemoryNode is GenMemoryNode

    def test_spec_fields_roundtrip(self) -> None:
        """Spec fields are name/description (not title/summary)."""
        from sonzai import MemoryNode
        payload = {
            "node_id": "n1",
            "agent_id": "a1",
            "path": "root/child",
            "name": "my-node",
            "description": "hello",
            "memory_type": "semantic",
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }
        node = MemoryNode.model_validate(payload)
        assert node.name == "my-node"
        assert node.description == "hello"
        assert node.memory_type == "semantic"

    def test_old_hand_rolled_fields_gone(self) -> None:
        """title/summary are no longer fields — hand-rolled was stale."""
        from sonzai import MemoryNode
        assert "title" not in MemoryNode.model_fields
        assert "summary" not in MemoryNode.model_fields


class TestAtomicFactMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import AtomicFact
        from sonzai._generated.models import AtomicFact as GenAtomicFact
        assert AtomicFact is GenAtomicFact

    def test_surfaces_new_spec_fields(self) -> None:
        """Spec has extra fields like cluster_id, character_salience that hand-rolled lacked."""
        from sonzai import AtomicFact
        assert "cluster_id" in AtomicFact.model_fields
        assert "character_salience" in AtomicFact.model_fields
        assert "retention_strength" in AtomicFact.model_fields

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import AtomicFact
        payload = {
            "fact_id": "f1",
            "agent_id": "a1",
            "node_id": "n1",
            "atomic_text": "hello",
            "fact_type": "stable",
            "confidence": 0.9,
            "mention_count": 1,
            "last_confirmed": "2026-01-01T00:00:00Z",
            "retention_strength": 0.5,
            "last_retrieved_at": "2026-01-01T00:00:00Z",
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }
        fact = AtomicFact.model_validate(payload)
        assert fact.fact_id == "f1"
        assert fact.confidence == 0.9


class TestMemoryResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import MemoryResponse
        from sonzai._generated.models import MemoryResponse as GenMemoryResponse
        assert MemoryResponse is GenMemoryResponse

    def test_schema_field_aliased(self) -> None:
        """$schema is a field (aliased to field_schema in Python)."""
        from sonzai import MemoryResponse
        payload = {
            "$schema": "https://api.sonz.ai/api/v1/schemas/MemoryResponse.json",
            "nodes": [],
        }
        resp = MemoryResponse.model_validate(payload)
        assert resp.field_schema is not None
        assert "MemoryResponse" in str(resp.field_schema)
        assert resp.nodes == []


class TestTimelineSessionMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import TimelineSession
        from sonzai._generated.models import TimelineSession as GenTimelineSession
        assert TimelineSession is GenTimelineSession

    def test_required_roundtrip(self) -> None:
        from sonzai import TimelineSession
        payload = {
            "session_id": "s1",
            "facts": [],
            "first_fact_at": "2026-01-01T00:00:00Z",
            "last_fact_at": "2026-01-01T00:00:00Z",
            "fact_count": 0,
        }
        ts = TimelineSession.model_validate(payload)
        assert ts.session_id == "s1"
        assert ts.fact_count == 0


class TestListAllFactsResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import ListAllFactsResponse
        from sonzai._generated.models import ListAllFactsResponse as GenListAllFactsResponse
        assert ListAllFactsResponse is GenListAllFactsResponse

    def test_references_stored_fact(self) -> None:
        from sonzai import ListAllFactsResponse
        payload = {"facts": [], "total": 0}
        resp = ListAllFactsResponse.model_validate(payload)
        assert resp.total == 0


# ---------------------------------------------------------------------------
# Batch 2 — Personality & Traits
# ---------------------------------------------------------------------------

_BIG5_TRAIT = {"score": 0.7, "confidence": 0.9}
_FULL_BIG5_ASSESSMENT = {
    "agreeableness": _BIG5_TRAIT,
    "conscientiousness": _BIG5_TRAIT,
    "extraversion": _BIG5_TRAIT,
    "neuroticism": _BIG5_TRAIT,
    "openness": _BIG5_TRAIT,
}
_DIMENSIONS = {
    "aesthetic": 7.0,
    "assertiveness": 6.0,
    "compassion": 9.0,
    "enthusiasm": 7.0,
    "industriousness": 6.0,
    "intellect": 9.0,
    "orderliness": 5.0,
    "politeness": 8.0,
    "volatility": 2.0,
    "withdrawal": 3.0,
}
_BEHAVIORS = {
    "conflict_approach": "collaborative",
    "empathy_style": "reflective",
    "question_frequency": "moderate",
    "response_length": "medium",
}
_PREFERENCES = {
    "conversation_pace": "relaxed",
    "emotional_expression": "open",
    "formality": "casual",
    "humor_style": "dry",
}
_PROFILE = {
    "agent_id": "agent_1",
    "behaviors": _BEHAVIORS,
    "big5": _FULL_BIG5_ASSESSMENT,
    "created_at": "2026-01-01T00:00:00Z",
    "dimensions": _DIMENSIONS,
    "gender": "female",
    "name": "Luna",
    "preferences": _PREFERENCES,
    "primary_traits": ["curious", "empathetic"],
    "speech_patterns": ["uses ellipses...", "asks questions"],
    "temperature": 0.7,
    "true_dislikes": ["rudeness"],
    "true_interests": ["astronomy", "cooking"],
}
_DELTA = {
    "delta": 0.05,
    "new_value": 0.8,
    "old_value": 0.75,
    "timestamp": "2026-01-01T00:00:00Z",
    "trait_category": "big5",
    "trait_name": "openness",
    "trigger_type": "conversation",
}


class TestBig5TraitMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import Big5Trait
        from sonzai._generated.models import Big5Trait as GenBig5Trait
        assert Big5Trait is GenBig5Trait

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import Big5Trait
        trait = Big5Trait.model_validate({"score": 0.75, "confidence": 0.9})
        assert trait.score == 0.75
        assert trait.confidence == 0.9
        assert trait.level is None
        assert trait.facets is None

    def test_old_fields_gone(self) -> None:
        from sonzai import Big5Trait
        # hand-rolled had `percentile` — spec does not
        assert "percentile" not in Big5Trait.model_fields


class TestBig5Migration:
    def test_imports_from_generated(self) -> None:
        from sonzai import Big5
        from sonzai._generated.models import Big5 as GenBig5
        assert Big5 is GenBig5

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import Big5
        payload = {
            "agreeableness": 0.9,
            "conscientiousness": 0.6,
            "extraversion": 0.75,
            "neuroticism": 0.25,
            "openness": 0.85,
        }
        b = Big5.model_validate(payload)
        assert b.openness == 0.85
        assert b.agreeableness == 0.9

    def test_old_fields_gone(self) -> None:
        from sonzai import Big5
        # hand-rolled Big5 had Big5Trait objects; generated has float fields
        # The field names are the same but types differ — verify they're floats
        b = Big5.model_validate({
            "agreeableness": 0.5,
            "conscientiousness": 0.5,
            "extraversion": 0.5,
            "neuroticism": 0.5,
            "openness": 0.5,
        })
        assert isinstance(b.openness, float)


class TestPersonalityDimensionsMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import PersonalityDimensions
        from sonzai._generated.models import PersonalityDimensions as GenPersonalityDimensions
        assert PersonalityDimensions is GenPersonalityDimensions

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import PersonalityDimensions
        dims = PersonalityDimensions.model_validate(_DIMENSIONS)
        assert dims.intellect == 9.0
        assert dims.withdrawal == 3.0
        assert dims.volatility == 2.0


class TestTraitPrecisionMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import TraitPrecision
        from sonzai._generated.models import TraitPrecision as GenTraitPrecision
        assert TraitPrecision is GenTraitPrecision

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import TraitPrecision
        tp = TraitPrecision.model_validate({
            "precision": 0.85,
            "last_updated_at": "2026-01-01T00:00:00Z",
            "observation_count": 42,
        })
        assert tp.precision == 0.85
        assert tp.observation_count == 42
        assert tp.last_updated_at is not None


class TestPersonalityProfileMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import PersonalityProfile
        from sonzai._generated.models import PersonalityProfile as GenPersonalityProfile
        assert PersonalityProfile is GenPersonalityProfile

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import PersonalityProfile
        profile = PersonalityProfile.model_validate(_PROFILE)
        assert profile.agent_id == "agent_1"
        assert profile.name == "Luna"
        assert profile.temperature == 0.7
        assert profile.big5.openness.score == 0.7
        assert profile.dimensions.intellect == 9.0

    def test_old_fields_gone(self) -> None:
        from sonzai import PersonalityProfile
        # hand-rolled had bio/avatar_url/personality_prompt as required str (non-optional)
        # generated has them as optional — just verify field exists in right form
        assert "bio" in PersonalityProfile.model_fields
        # hand-rolled had no field_schema; generated PersonalityProfile has no $schema either


class TestPersonalityDeltaMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import PersonalityDelta
        from sonzai._generated.models import PersonalityDelta as GenPersonalityDelta
        assert PersonalityDelta is GenPersonalityDelta

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import PersonalityDelta
        delta = PersonalityDelta.model_validate(_DELTA)
        assert delta.trait_category == "big5"
        assert delta.trait_name == "openness"
        assert delta.delta == 0.05
        assert delta.trigger_type == "conversation"

    def test_old_fields_gone(self) -> None:
        from sonzai import PersonalityDelta
        # hand-rolled had delta_id, change, reason — spec does not
        assert "delta_id" not in PersonalityDelta.model_fields
        assert "change" not in PersonalityDelta.model_fields
        assert "reason" not in PersonalityDelta.model_fields


class TestPersonalityResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import PersonalityResponse
        from sonzai._generated.models import PersonalityResponse as GenPersonalityResponse
        assert PersonalityResponse is GenPersonalityResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import PersonalityResponse
        resp = PersonalityResponse.model_validate({
            "profile": _PROFILE,
            "evolution": [_DELTA],
        })
        assert resp.profile.name == "Luna"
        assert len(resp.evolution) == 1
        assert resp.evolution[0].trait_name == "openness"

    def test_schema_field_aliased(self) -> None:
        from sonzai import PersonalityResponse
        resp = PersonalityResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/PersonalityResponse.json",
            "profile": _PROFILE,
            "evolution": None,
        })
        assert resp.field_schema is not None
        assert "PersonalityResponse" in str(resp.field_schema)
        assert resp.evolution is None

    def test_old_evolution_shape_gone(self) -> None:
        from sonzai import PersonalityDelta
        # old hand-rolled PersonalityDelta had delta_id; spec has trait_category
        assert "trait_category" in PersonalityDelta.model_fields


# ---------------------------------------------------------------------------
# Batch 3 — Agent Behavior (Goal, Habit, Interests)
# ---------------------------------------------------------------------------


class TestGoalMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import Goal
        from sonzai._generated.models import Goal as GenGoal
        assert Goal is GenGoal

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import Goal
        payload = {
            "goal_id": "g1",
            "agent_id": "a1",
            "type": "personal_growth",
            "title": "Learn Python",
            "description": "Become proficient in Python",
            "priority": 1,
            "status": "active",
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-02T00:00:00Z",
        }
        goal = Goal.model_validate(payload)
        assert goal.goal_id == "g1"
        assert goal.agent_id == "a1"
        assert goal.type == "personal_growth"
        assert goal.status == "active"
        assert goal.priority == 1

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import Goal
        with pytest.raises(ValidationError):
            Goal.model_validate({
                "goal_id": "g1",
                "agent_id": "a1",
                "type": "personal_growth",
                "title": "Learn Python",
                "description": "desc",
                "priority": 1,
                "status": "active",
                "created_at": "2026-01-01T00:00:00Z",
                "updated_at": "2026-01-02T00:00:00Z",
                "unknown_field": "boom",
            })


class TestGoalsResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import GoalsResponse
        from sonzai._generated.models import GoalsResponse as GenGoalsResponse
        assert GoalsResponse is GenGoalsResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import GoalsResponse
        resp = GoalsResponse.model_validate({"goals": None})
        assert resp.goals is None

    def test_schema_field_aliased(self) -> None:
        from sonzai import GoalsResponse
        resp = GoalsResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/GoalsResponse.json",
            "goals": None,
        })
        assert resp.field_schema is not None
        assert "GoalsResponse" in str(resp.field_schema)


class TestHabitMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import Habit
        from sonzai._generated.models import Habit as GenHabit
        assert Habit is GenHabit

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import Habit
        payload = {
            "agent_id": "a1",
            "name": "morning-run",
            "category": "fitness",
            "description": "Run every morning",
            "display_name": "Morning Run",
            "strength": 0.75,
            "formed": True,
            "observation_count": 30,
            "last_reinforced_at": "2026-01-15T08:00:00Z",
            "daily_reinforced": 0.9,
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-15T08:00:00Z",
        }
        habit = Habit.model_validate(payload)
        assert habit.agent_id == "a1"
        assert habit.name == "morning-run"
        assert habit.strength == 0.75
        assert habit.formed is True
        assert habit.observation_count == 30

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import Habit
        with pytest.raises(ValidationError):
            Habit.model_validate({
                "agent_id": "a1",
                "name": "morning-run",
                "category": "fitness",
                "description": "desc",
                "display_name": "Morning Run",
                "strength": 0.5,
                "formed": False,
                "observation_count": 0,
                "last_reinforced_at": "2026-01-01T00:00:00Z",
                "daily_reinforced": 0.0,
                "created_at": "2026-01-01T00:00:00Z",
                "updated_at": "2026-01-01T00:00:00Z",
                "unknown_field": "boom",
            })


class TestHabitsResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import HabitsResponse
        from sonzai._generated.models import HabitsResponse as GenHabitsResponse
        assert HabitsResponse is GenHabitsResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import HabitsResponse
        resp = HabitsResponse.model_validate({"habits": None})
        assert resp.habits is None

    def test_schema_field_aliased(self) -> None:
        from sonzai import HabitsResponse
        resp = HabitsResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/HabitsResponse.json",
            "habits": None,
        })
        assert resp.field_schema is not None
        assert "HabitsResponse" in str(resp.field_schema)


class TestInterestsResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import InterestsResponse
        from sonzai._generated.models import InterestsResponse as GenInterestsResponse
        assert InterestsResponse is GenInterestsResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import InterestsResponse
        resp = InterestsResponse.model_validate({"interests": None})
        assert resp.interests is None

    def test_schema_field_aliased(self) -> None:
        from sonzai import InterestsResponse
        resp = InterestsResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/InterestsResponse.json",
            "interests": None,
        })
        assert resp.field_schema is not None
        assert "InterestsResponse" in str(resp.field_schema)


# ---------------------------------------------------------------------------
# Batch 4 — Mood & Diary
# ---------------------------------------------------------------------------

_MOOD_STATE = {
    "agent_id": "agent_1",
    "valence": 0.6,
    "arousal": 0.4,
    "tension": 0.2,
    "affiliation": 0.8,
    "label": "content",
    "baseline_valence": 0.5,
    "baseline_arousal": 0.5,
    "baseline_tension": 0.3,
    "baseline_affiliation": 0.7,
    "last_interaction_at": "2026-01-01T00:00:00Z",
    "last_decay_at": "2026-01-01T00:00:00Z",
    "created_at": "2026-01-01T00:00:00Z",
    "updated_at": "2026-01-02T00:00:00Z",
}


class TestMoodStateMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import MoodState
        from sonzai._generated.models import MoodState as GenMoodState
        assert MoodState is GenMoodState

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import MoodState
        ms = MoodState.model_validate(_MOOD_STATE)
        assert ms.agent_id == "agent_1"
        assert ms.valence == 0.6
        assert ms.arousal == 0.4
        assert ms.tension == 0.2
        assert ms.affiliation == 0.8
        assert ms.label == "content"
        assert ms.baseline_valence == 0.5
        assert ms.last_interaction_at is not None

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import MoodState
        with pytest.raises(ValidationError):
            MoodState.model_validate({**_MOOD_STATE, "unknown_field": "boom"})

    def test_old_hand_rolled_fields_gone(self) -> None:
        """Hand-rolled MoodState lacked agent_id and baseline_* fields."""
        from sonzai import MoodState
        assert "agent_id" in MoodState.model_fields
        assert "baseline_valence" in MoodState.model_fields
        assert "baseline_arousal" in MoodState.model_fields
        assert "baseline_tension" in MoodState.model_fields
        assert "baseline_affiliation" in MoodState.model_fields


class TestMoodResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import MoodResponse
        from sonzai._generated.models import MoodResponse as GenMoodResponse
        assert MoodResponse is GenMoodResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import MoodResponse
        resp = MoodResponse.model_validate({"mood": _MOOD_STATE})
        assert resp.mood.agent_id == "agent_1"
        assert resp.mood.valence == 0.6

    def test_schema_field_aliased(self) -> None:
        from sonzai import MoodResponse
        resp = MoodResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/MoodResponse.json",
            "mood": _MOOD_STATE,
        })
        assert resp.field_schema is not None
        assert "MoodResponse" in str(resp.field_schema)

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import MoodResponse
        with pytest.raises(ValidationError):
            MoodResponse.model_validate({"mood": _MOOD_STATE, "unknown_field": "boom"})


class TestMoodHistoryEntryMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import MoodHistoryEntry
        from sonzai._generated.models import MoodHistoryEntry as GenMoodHistoryEntry
        assert MoodHistoryEntry is GenMoodHistoryEntry

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import MoodHistoryEntry
        entry = MoodHistoryEntry.model_validate({
            "valence": 0.5,
            "arousal": 0.3,
            "tension": 0.2,
            "affiliation": 0.7,
            "timestamp": "2026-01-01T00:00:00Z",
        })
        assert entry.valence == 0.5
        assert entry.tension == 0.2
        assert entry.timestamp == "2026-01-01T00:00:00Z"
        assert entry.label is None

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import MoodHistoryEntry
        with pytest.raises(ValidationError):
            MoodHistoryEntry.model_validate({
                "valence": 0.5, "arousal": 0.3, "tension": 0.2,
                "affiliation": 0.7, "timestamp": "2026-01-01T00:00:00Z",
                "unknown_field": "boom",
            })


class TestMoodHistoryResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import MoodHistoryResponse
        from sonzai._generated.models import MoodHistoryResponse as GenMoodHistoryResponse
        assert MoodHistoryResponse is GenMoodHistoryResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import MoodHistoryResponse
        resp = MoodHistoryResponse.model_validate({"entries": None})
        assert resp.entries is None

    def test_with_entries(self) -> None:
        from sonzai import MoodHistoryResponse
        resp = MoodHistoryResponse.model_validate({
            "entries": [{
                "valence": 0.5, "arousal": 0.3, "tension": 0.2,
                "affiliation": 0.7, "timestamp": "2026-01-01T00:00:00Z",
            }],
        })
        assert resp.entries is not None
        assert len(resp.entries) == 1
        assert resp.entries[0].valence == 0.5

    def test_schema_field_aliased(self) -> None:
        from sonzai import MoodHistoryResponse
        resp = MoodHistoryResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/MoodHistoryResponse.json",
            "entries": None,
        })
        assert resp.field_schema is not None
        assert "MoodHistoryResponse" in str(resp.field_schema)


class TestDiaryEntryMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import DiaryEntry
        from sonzai._generated.models import DiaryEntry as GenDiaryEntry
        assert DiaryEntry is GenDiaryEntry

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import DiaryEntry
        entry = DiaryEntry.model_validate({
            "entry_id": "e1",
            "agent_id": "a1",
            "date": "2026-01-01",
            "content": "Today was a good day.",
            "created_at": "2026-01-01T00:00:00Z",
        })
        assert entry.entry_id == "e1"
        assert entry.agent_id == "a1"
        assert entry.date == "2026-01-01"
        assert entry.content == "Today was a good day."
        assert entry.created_at is not None

    def test_optional_fields_default_none(self) -> None:
        from sonzai import DiaryEntry
        entry = DiaryEntry.model_validate({
            "entry_id": "e1",
            "agent_id": "a1",
            "date": "2026-01-01",
            "content": "Hello.",
            "created_at": "2026-01-01T00:00:00Z",
        })
        assert entry.mood is None
        assert entry.tags is None
        assert entry.title is None
        assert entry.user_id is None

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import DiaryEntry
        with pytest.raises(ValidationError):
            DiaryEntry.model_validate({
                "entry_id": "e1",
                "agent_id": "a1",
                "date": "2026-01-01",
                "content": "Hello.",
                "created_at": "2026-01-01T00:00:00Z",
                "body": "old deprecated field",
            })


# ---------------------------------------------------------------------------
# Batch 5 — Memory Extensions
# ---------------------------------------------------------------------------


class TestMoodAggregateResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import MoodAggregateResponse
        from sonzai._generated.models import MoodAggregateResponse as GenMoodAggregateResponse
        assert MoodAggregateResponse is GenMoodAggregateResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import MoodAggregateResponse
        resp = MoodAggregateResponse.model_validate({
            "valence": 0.6,
            "arousal": 0.4,
            "tension": 0.2,
            "affiliation": 0.8,
            "label": "positive",
            "user_count": 42,
            "days_window": 7,
        })
        assert resp.valence == 0.6
        assert resp.arousal == 0.4
        assert resp.tension == 0.2
        assert resp.affiliation == 0.8
        assert resp.label == "positive"
        assert resp.user_count == 42
        assert resp.days_window == 7

    def test_old_hand_rolled_fields_gone(self) -> None:
        """Hand-rolled had float defaults; generated fields are required (no defaults)."""
        from sonzai import MoodAggregateResponse
        # All 7 spec fields should be present
        for field in ("valence", "arousal", "tension", "affiliation", "label", "user_count", "days_window"):
            assert field in MoodAggregateResponse.model_fields

    def test_schema_field_aliased(self) -> None:
        from sonzai import MoodAggregateResponse
        resp = MoodAggregateResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/MoodAggregateResponse.json",
            "valence": 0.0, "arousal": 0.0, "tension": 0.0,
            "affiliation": 0.0, "label": "", "user_count": 0, "days_window": 0,
        })
        assert resp.field_schema is not None
        assert "MoodAggregateResponse" in str(resp.field_schema)


class TestTimeMachineMoodSnapshotMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import TimeMachineMoodSnapshot
        from sonzai._generated.models import TimeMachineMoodSnapshot as GenTimeMachineMoodSnapshot
        assert TimeMachineMoodSnapshot is GenTimeMachineMoodSnapshot

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import TimeMachineMoodSnapshot
        snap = TimeMachineMoodSnapshot.model_validate({
            "valence": 0.5,
            "arousal": 0.3,
            "tension": 0.1,
            "affiliation": 0.7,
            "label": "calm",
        })
        assert snap.valence == 0.5
        assert snap.arousal == 0.3
        assert snap.tension == 0.1
        assert snap.affiliation == 0.7
        assert snap.label == "calm"

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import TimeMachineMoodSnapshot
        with pytest.raises(ValidationError):
            TimeMachineMoodSnapshot.model_validate({
                "valence": 0.0, "arousal": 0.0, "tension": 0.0,
                "affiliation": 0.0, "label": "", "unknown_field": "boom",
            })


_BIG5_TRAIT_SNAP = {"score": 0.7, "confidence": 0.9}
_BIG5_ASSESSMENT_SNAP = {
    "agreeableness": _BIG5_TRAIT_SNAP,
    "conscientiousness": _BIG5_TRAIT_SNAP,
    "extraversion": _BIG5_TRAIT_SNAP,
    "neuroticism": _BIG5_TRAIT_SNAP,
    "openness": _BIG5_TRAIT_SNAP,
}
_MOOD_SNAP = {"valence": 0.5, "arousal": 0.3, "tension": 0.1, "affiliation": 0.7, "label": "calm"}


class TestTimeMachineResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import TimeMachineResponse
        from sonzai._generated.models import TimeMachineResponse as GenTimeMachineResponse
        assert TimeMachineResponse is GenTimeMachineResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import TimeMachineResponse
        resp = TimeMachineResponse.model_validate({
            "personality_at": _BIG5_ASSESSMENT_SNAP,
            "current_personality": _BIG5_ASSESSMENT_SNAP,
            "evolution_events": None,
            "mood_at": _MOOD_SNAP,
            "requested_at": "2026-01-01T00:00:00Z",
        })
        assert resp.requested_at == "2026-01-01T00:00:00Z"
        assert resp.mood_at.valence == 0.5
        assert resp.mood_at.label == "calm"
        assert resp.personality_at.openness.score == 0.7
        assert resp.current_personality.agreeableness.confidence == 0.9
        assert resp.evolution_events is None

    def test_old_hand_rolled_fields_gone(self) -> None:
        """Hand-rolled had dict[str, Any] for personality_at/current_personality;
        generated uses Big5Assessment with typed fields."""
        from sonzai import TimeMachineResponse
        from sonzai._generated.models import Big5Assessment
        import inspect
        hints = TimeMachineResponse.model_fields
        assert "personality_at" in hints
        assert "current_personality" in hints
        # Verify these are Big5Assessment, not dict
        assert hints["personality_at"].annotation is Big5Assessment

    def test_schema_field_aliased(self) -> None:
        from sonzai import TimeMachineResponse
        resp = TimeMachineResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/TimeMachineResponse.json",
            "personality_at": _BIG5_ASSESSMENT_SNAP,
            "current_personality": _BIG5_ASSESSMENT_SNAP,
            "evolution_events": None,
            "mood_at": _MOOD_SNAP,
            "requested_at": "2026-01-01T00:00:00Z",
        })
        assert resp.field_schema is not None
        assert "TimeMachineResponse" in str(resp.field_schema)


class TestMemorySummaryMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import MemorySummary
        from sonzai._generated.models import MemorySummary as GenMemorySummary
        assert MemorySummary is GenMemorySummary

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import MemorySummary
        ms = MemorySummary.model_validate({
            "summary_id": "sum_1",
            "agent_id": "a1",
            "stage": "consolidation",
            "summary": "The user discussed hobbies and goals.",
            "period_start": "2026-01-01T00:00:00Z",
            "period_end": "2026-01-07T23:59:59Z",
            "created_at": "2026-01-08T00:00:00Z",
        })
        assert ms.summary_id == "sum_1"
        assert ms.agent_id == "a1"
        assert ms.stage == "consolidation"
        assert ms.summary == "The user discussed hobbies and goals."
        assert ms.period_start is not None
        assert ms.period_end is not None
        assert ms.created_at is not None

    def test_old_hand_rolled_fields_gone(self) -> None:
        """Hand-rolled had summary_text/timestamp/fact_count/confidence;
        generated uses summary/summary_id/period_start/period_end/created_at."""
        from sonzai import MemorySummary
        assert "summary_id" in MemorySummary.model_fields
        assert "summary" in MemorySummary.model_fields
        assert "period_start" in MemorySummary.model_fields
        assert "period_end" in MemorySummary.model_fields
        assert "created_at" in MemorySummary.model_fields
        assert "summary_text" not in MemorySummary.model_fields
        assert "timestamp" not in MemorySummary.model_fields
        assert "fact_count" not in MemorySummary.model_fields

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import MemorySummary
        with pytest.raises(ValidationError):
            MemorySummary.model_validate({
                "summary_id": "x", "agent_id": "a1", "stage": "s",
                "summary": "text",
                "period_start": "2026-01-01T00:00:00Z",
                "period_end": "2026-01-07T00:00:00Z",
                "created_at": "2026-01-08T00:00:00Z",
                "unknown_field": "boom",
            })


class TestSummariesResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import SummariesResponse
        from sonzai._generated.models import SummariesResponse as GenSummariesResponse
        assert SummariesResponse is GenSummariesResponse

    def test_minimal_required_roundtrip_none(self) -> None:
        from sonzai import SummariesResponse
        resp = SummariesResponse.model_validate({"summaries": None})
        assert resp.summaries is None

    def test_with_summaries(self) -> None:
        from sonzai import SummariesResponse
        resp = SummariesResponse.model_validate({
            "summaries": [{
                "summary_id": "sum_1",
                "agent_id": "a1",
                "stage": "consolidation",
                "summary": "text",
                "period_start": "2026-01-01T00:00:00Z",
                "period_end": "2026-01-07T00:00:00Z",
                "created_at": "2026-01-08T00:00:00Z",
            }],
        })
        assert resp.summaries is not None
        assert len(resp.summaries) == 1
        assert resp.summaries[0].summary_id == "sum_1"
        assert resp.summaries[0].summary == "text"

    def test_schema_field_aliased(self) -> None:
        from sonzai import SummariesResponse
        resp = SummariesResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/SummariesResponse.json",
            "summaries": None,
        })
        assert resp.field_schema is not None
        assert "SummariesResponse" in str(resp.field_schema)


class TestPersonalityShiftMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import PersonalityShift
        from sonzai._generated.models import PersonalityShift as GenPersonalityShift
        assert PersonalityShift is GenPersonalityShift

    def test_required_fields_roundtrip(self) -> None:
        from sonzai import PersonalityShift
        shift = PersonalityShift.model_validate({
            "trait_name": "openness",
            "direction": "increase",
            "magnitude": "moderate",
            "trigger_types": ["conversation"],
            "timeframe_days": 30,
        })
        assert shift.trait_name == "openness"
        assert shift.direction == "increase"
        assert shift.magnitude == "moderate"
        assert shift.trigger_types == ["conversation"]
        assert shift.timeframe_days == 30

    def test_optional_fields(self) -> None:
        from sonzai import PersonalityShift
        shift = PersonalityShift.model_validate({
            "trait_name": "conscientiousness",
            "direction": "decrease",
            "magnitude": "slight",
            "trigger_types": None,
            "timeframe_days": 7,
            "reasoning": "gradual change",
            "timestamp": "2026-04-01T00:00:00Z",
        })
        assert shift.reasoning == "gradual change"
        assert shift.trigger_types is None

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import PersonalityShift
        with pytest.raises(ValidationError):
            PersonalityShift.model_validate({
                "trait_name": "openness",
                "direction": "increase",
                "magnitude": "moderate",
                "trigger_types": [],
                "timeframe_days": 10,
                "unknown": "boom",
            })


class TestRecentShiftsResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import RecentShiftsResponse
        from sonzai._generated.models import RecentShiftsResponse as GenRecentShiftsResponse
        assert RecentShiftsResponse is GenRecentShiftsResponse

    def test_minimal_required_roundtrip_none(self) -> None:
        from sonzai import RecentShiftsResponse
        resp = RecentShiftsResponse.model_validate({"shifts": None})
        assert resp.shifts is None

    def test_with_shifts(self) -> None:
        from sonzai import RecentShiftsResponse
        resp = RecentShiftsResponse.model_validate({
            "shifts": [{
                "trait_name": "openness",
                "direction": "increase",
                "magnitude": "moderate",
                "trigger_types": ["event"],
                "timeframe_days": 14,
            }],
        })
        assert resp.shifts is not None
        assert len(resp.shifts) == 1
        assert resp.shifts[0].trait_name == "openness"

    def test_schema_field_aliased(self) -> None:
        from sonzai import RecentShiftsResponse
        resp = RecentShiftsResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/RecentShiftsResponse.json",
            "shifts": None,
        })
        assert resp.field_schema is not None
        assert "RecentShiftsResponse" in str(resp.field_schema)


class TestSignificantMomentMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import SignificantMoment
        from sonzai._generated.models import SignificantMoment as GenSignificantMoment
        assert SignificantMoment is GenSignificantMoment

    def test_required_fields_roundtrip(self) -> None:
        from sonzai import SignificantMoment
        moment = SignificantMoment.model_validate({
            "description": "First meeting",
            "reasoning": "Strong emotional impact",
            "trigger_type": "conversation",
            "created_at": "2026-04-01T00:00:00Z",
        })
        assert moment.description == "First meeting"
        assert moment.reasoning == "Strong emotional impact"
        assert moment.trigger_type == "conversation"
        assert moment.created_at == "2026-04-01T00:00:00Z"

    def test_optional_fields(self) -> None:
        from sonzai import SignificantMoment
        moment = SignificantMoment.model_validate({
            "description": "A walk in the park",
            "reasoning": "Shared experience",
            "trigger_type": "event",
            "created_at": "2026-04-10T00:00:00Z",
            "emotional_impact": "positive",
            "location": "Central Park",
            "partner_name": "Alex",
            "traits_affected": ["openness", "agreeableness"],
        })
        assert moment.emotional_impact == "positive"
        assert moment.location == "Central Park"
        assert moment.traits_affected == ["openness", "agreeableness"]

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import SignificantMoment
        with pytest.raises(ValidationError):
            SignificantMoment.model_validate({
                "description": "x",
                "reasoning": "y",
                "trigger_type": "z",
                "created_at": "2026-01-01T00:00:00Z",
                "unknown": "boom",
            })


class TestSignificantMomentsResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import SignificantMomentsResponse
        from sonzai._generated.models import SignificantMomentsResponse as GenSignificantMomentsResponse
        assert SignificantMomentsResponse is GenSignificantMomentsResponse

    def test_minimal_required_roundtrip_none(self) -> None:
        from sonzai import SignificantMomentsResponse
        resp = SignificantMomentsResponse.model_validate({"moments": None})
        assert resp.moments is None

    def test_with_moments(self) -> None:
        from sonzai import SignificantMomentsResponse
        resp = SignificantMomentsResponse.model_validate({
            "moments": [{
                "description": "First meeting",
                "reasoning": "Impact",
                "trigger_type": "conversation",
                "created_at": "2026-04-01T00:00:00Z",
            }],
        })
        assert resp.moments is not None
        assert len(resp.moments) == 1
        assert resp.moments[0].description == "First meeting"

    def test_schema_field_aliased(self) -> None:
        from sonzai import SignificantMomentsResponse
        resp = SignificantMomentsResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/SignificantMomentsResponse.json",
            "moments": None,
        })
        assert resp.field_schema is not None
        assert "SignificantMomentsResponse" in str(resp.field_schema)


class TestBatchPersonalityEntryMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import BatchPersonalityEntry
        from sonzai._generated.models import BatchPersonalityEntry as GenBatchPersonalityEntry
        assert BatchPersonalityEntry is GenBatchPersonalityEntry

    def test_required_fields_present(self) -> None:
        from sonzai import BatchPersonalityEntry
        assert "profile" in BatchPersonalityEntry.model_fields
        assert "evolution_count" in BatchPersonalityEntry.model_fields

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import BatchPersonalityEntry
        # model_config should have extra='forbid'
        assert BatchPersonalityEntry.model_config.get("extra") == "forbid"


class TestBreakthroughMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai._generated.models import Breakthrough as GenBreakthrough
        from sonzai.types import Breakthrough
        assert Breakthrough is GenBreakthrough

    def test_required_fields_roundtrip(self) -> None:
        from sonzai.types import Breakthrough
        bt = Breakthrough.model_validate({
            "breakthrough_id": "bt-1",
            "agent_id": "agent-1",
            "user_id": "user-1",
            "breakthrough_number": 3,
            "level_at_breakthrough": 5,
            "narrative": "A major breakthrough occurred.",
            "personality_shifts": ["became more empathetic"],
            "new_goals": ["help others"],
            "achieved_goals": ["overcome fear"],
            "skill_points_awarded": 100,
            "acknowledged": True,
            "created_at": "2026-04-01T00:00:00Z",
        })
        assert bt.breakthrough_id == "bt-1"
        assert bt.agent_id == "agent-1"
        assert bt.user_id == "user-1"
        assert bt.breakthrough_number == 3
        assert bt.level_at_breakthrough == 5
        assert bt.narrative == "A major breakthrough occurred."
        assert bt.personality_shifts == ["became more empathetic"]
        assert bt.new_goals == ["help others"]
        assert bt.achieved_goals == ["overcome fear"]
        assert bt.skill_points_awarded == 100
        assert bt.acknowledged is True

    def test_nullable_list_fields(self) -> None:
        from sonzai.types import Breakthrough
        bt = Breakthrough.model_validate({
            "breakthrough_id": "bt-2",
            "agent_id": "agent-1",
            "user_id": "user-1",
            "breakthrough_number": 1,
            "level_at_breakthrough": 2,
            "narrative": "Small shift.",
            "personality_shifts": None,
            "new_goals": None,
            "achieved_goals": None,
            "skill_points_awarded": 10,
            "acknowledged": False,
            "created_at": "2026-04-01T00:00:00Z",
        })
        assert bt.personality_shifts is None
        assert bt.new_goals is None
        assert bt.achieved_goals is None

    def test_optional_trait_evolved(self) -> None:
        from sonzai.types import Breakthrough
        bt = Breakthrough.model_validate({
            "breakthrough_id": "bt-3",
            "agent_id": "agent-1",
            "user_id": "user-1",
            "breakthrough_number": 2,
            "level_at_breakthrough": 4,
            "narrative": "Openness grew.",
            "personality_shifts": [],
            "new_goals": [],
            "achieved_goals": [],
            "skill_points_awarded": 50,
            "acknowledged": False,
            "created_at": "2026-04-01T00:00:00Z",
            "trait_evolved": "openness",
        })
        assert bt.trait_evolved == "openness"

    def test_extra_fields_forbidden(self) -> None:
        from sonzai.types import Breakthrough
        assert Breakthrough.model_config.get("extra") == "forbid"


class TestBreakthroughsResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import BreakthroughsResponse
        from sonzai._generated.models import BreakthroughsResponse as GenBreakthroughsResponse
        assert BreakthroughsResponse is GenBreakthroughsResponse

    def test_minimal_required_roundtrip_none(self) -> None:
        from sonzai import BreakthroughsResponse
        resp = BreakthroughsResponse.model_validate({"breakthroughs": None})
        assert resp.breakthroughs is None

    def test_with_breakthroughs(self) -> None:
        from sonzai import BreakthroughsResponse
        resp = BreakthroughsResponse.model_validate({
            "breakthroughs": [{
                "breakthrough_id": "bt-1",
                "agent_id": "agent-1",
                "user_id": "user-1",
                "breakthrough_number": 1,
                "level_at_breakthrough": 3,
                "narrative": "First breakthrough.",
                "personality_shifts": ["more open"],
                "new_goals": ["explore"],
                "achieved_goals": [],
                "skill_points_awarded": 75,
                "acknowledged": False,
                "created_at": "2026-04-01T00:00:00Z",
            }],
        })
        assert resp.breakthroughs is not None
        assert len(resp.breakthroughs) == 1
        assert resp.breakthroughs[0].breakthrough_id == "bt-1"

    def test_schema_field_aliased(self) -> None:
        from sonzai import BreakthroughsResponse
        resp = BreakthroughsResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/BreakthroughsResponse.json",
            "breakthroughs": None,
        })
        assert resp.field_schema is not None
        assert "BreakthroughsResponse" in str(resp.field_schema)

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import BreakthroughsResponse
        assert BreakthroughsResponse.model_config.get("extra") == "forbid"


class TestConstellationResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import ConstellationResponse
        from sonzai._generated.models import ConstellationResponse as GenConstellationResponse
        assert ConstellationResponse is GenConstellationResponse

    def test_minimal_required_roundtrip_none(self) -> None:
        from sonzai import ConstellationResponse
        resp = ConstellationResponse.model_validate({
            "nodes": None,
            "edges": None,
            "insights": None,
        })
        assert resp.nodes is None
        assert resp.edges is None
        assert resp.insights is None

    def test_with_nodes_edges_insights(self) -> None:
        from sonzai import ConstellationResponse
        resp = ConstellationResponse.model_validate({
            "nodes": [{
                "AgentID": "agent-1",
                "Brightness": 0.8,
                "CreatedAt": "2026-04-01T00:00:00Z",
                "Description": "A key person",
                "FirstMentionedAt": "2026-03-01T00:00:00Z",
                "Label": "Alice",
                "LastMentionedAt": "2026-04-01T00:00:00Z",
                "MentionCount": 5,
                "NodeID": "node-1",
                "NodeType": "person",
                "Significance": 0.9,
                "UpdatedAt": "2026-04-01T00:00:00Z",
                "UserID": "user-1",
            }],
            "edges": [{
                "AgentID": "agent-1",
                "CoOccurrenceCount": 3,
                "CreatedAt": "2026-04-01T00:00:00Z",
                "EdgeID": "edge-1",
                "EdgeType": "friend",
                "FromNodeID": "node-1",
                "Strength": 0.7,
                "ToNodeID": "node-2",
                "UpdatedAt": "2026-04-01T00:00:00Z",
            }],
            "insights": [{
                "AgentID": "agent-1",
                "Confidence": 0.85,
                "Content": "Alice is a close friend.",
                "CreatedAt": "2026-04-01T00:00:00Z",
                "InsightID": "insight-1",
                "InsightType": "relationship",
                "Priority": 1,
                "RelatedNodes": ["node-1"],
                "Surfaced": False,
                "UpdatedAt": "2026-04-01T00:00:00Z",
                "UserID": "user-1",
            }],
        })
        assert resp.nodes is not None
        assert len(resp.nodes) == 1
        assert resp.edges is not None
        assert len(resp.edges) == 1
        assert resp.insights is not None
        assert len(resp.insights) == 1

    def test_schema_field_aliased(self) -> None:
        from sonzai import ConstellationResponse
        resp = ConstellationResponse.model_validate({
            "$schema": "https://api.sonz.ai/api/v1/schemas/ConstellationResponse.json",
            "nodes": None,
            "edges": None,
            "insights": None,
        })
        assert resp.field_schema is not None
        assert "ConstellationResponse" in str(resp.field_schema)

    def test_extra_fields_forbidden(self) -> None:
        from sonzai import ConstellationResponse
        assert ConstellationResponse.model_config.get("extra") == "forbid"


# ---------------------------------------------------------------------------
# Batch 8 — KB Core migration tests
# ---------------------------------------------------------------------------


class TestKBDocumentMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBDocument
        from sonzai._generated.models import KBDocument as GenKBDocument
        assert KBDocument is GenKBDocument

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBDocument
        payload = {
            "project_id": "proj-1",
            "document_id": "doc-1",
            "file_name": "report.pdf",
            "content_type": "application/pdf",
            "file_size": 1024,
            "gcs_path": "gs://bucket/report.pdf",
            "checksum": "abc123",
            "status": "processed",
            "node_count": 10,
            "edge_count": 5,
            "extraction_tokens": 500,
            "uploaded_by": "user-1",
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }
        doc = KBDocument.model_validate(payload)
        assert doc.project_id == "proj-1"
        assert doc.document_id == "doc-1"
        assert doc.node_count == 10
        assert doc.edge_count == 5

    def test_spec_fields_present(self) -> None:
        from sonzai import KBDocument
        # node_count and edge_count are spec fields absent in hand-rolled
        assert "node_count" in KBDocument.model_fields
        assert "edge_count" in KBDocument.model_fields


class TestKBNodeMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBNode
        from sonzai._generated.models import KBNode as GenKBNode
        assert KBNode is GenKBNode

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBNode
        payload = {
            "project_id": "proj-1",
            "node_id": "node-1",
            "node_type": "Person",
            "label": "Alice",
            "norm_label": "alice",
            "properties": {"age": 30},
            "source_docs": ["doc-1"],
            "source_type": "manual",
            "version": 1,
            "is_active": True,
            "confidence": 0.9,
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }
        node = KBNode.model_validate(payload)
        assert node.node_id == "node-1"
        assert node.label == "Alice"
        assert node.source_docs == ["doc-1"]

    def test_spec_fields_present(self) -> None:
        from sonzai import KBNode
        # source_docs (list) is spec-generated; hand-rolled lacked it
        assert "source_docs" in KBNode.model_fields
        assert "property_sources" in KBNode.model_fields


class TestKBNodeHistoryMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBNodeHistory
        from sonzai._generated.models import KBNodeHistory as GenKBNodeHistory
        assert KBNodeHistory is GenKBNodeHistory

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBNodeHistory
        payload = {
            "project_id": "proj-1",
            "node_id": "node-1",
            "version": 2,
            "properties": {"key": "val"},
            "changed_by": "user-1",
            "change_type": "update",
            "changed_at": "2026-01-01T00:00:00Z",
        }
        hist = KBNodeHistory.model_validate(payload)
        assert hist.node_id == "node-1"
        assert hist.version == 2
        assert hist.change_type == "update"


class TestKBEdgeMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBEdge
        from sonzai._generated.models import KBEdge as GenKBEdge
        assert KBEdge is GenKBEdge

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBEdge
        payload = {
            "project_id": "proj-1",
            "edge_id": "edge-1",
            "from_node_id": "node-1",
            "to_node_id": "node-2",
            "edge_type": "KNOWS",
            "confidence": 0.85,
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }
        edge = KBEdge.model_validate(payload)
        assert edge.edge_id == "edge-1"
        assert edge.from_node_id == "node-1"
        assert edge.confidence == 0.85


class TestKBSchemaFieldMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBSchemaField
        from sonzai._generated.models import KBSchemaField as GenKBSchemaField
        assert KBSchemaField is GenKBSchemaField

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBSchemaField
        payload = {
            "name": "age",
            "type": "integer",
            "required": True,
        }
        field = KBSchemaField.model_validate(payload)
        assert field.name == "age"
        assert field.type == "integer"
        assert field.required is True

    def test_optional_fields(self) -> None:
        from sonzai import KBSchemaField
        payload = {
            "name": "bio",
            "type": "string",
            "required": False,
            "description": "User biography",
            "enum_values": ["short", "long"],
        }
        field = KBSchemaField.model_validate(payload)
        assert field.description == "User biography"
        assert field.enum_values == ["short", "long"]


class TestKBEntitySchemaMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBEntitySchema
        from sonzai._generated.models import KBEntitySchema as GenKBEntitySchema
        assert KBEntitySchema is GenKBEntitySchema

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBEntitySchema
        payload = {
            "project_id": "proj-1",
            "schema_id": "schema-1",
            "entity_type": "Person",
            "fields": None,
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }
        schema = KBEntitySchema.model_validate(payload)
        assert schema.schema_id == "schema-1"
        assert schema.entity_type == "Person"
        assert schema.fields is None

    def test_with_fields_and_similarity_config(self) -> None:
        from sonzai import KBEntitySchema
        payload = {
            "project_id": "proj-1",
            "schema_id": "schema-2",
            "entity_type": "Company",
            "fields": [{"name": "revenue", "type": "float", "required": False}],
            "similarity_config": {
                "enabled": True,
                "threshold": 0.8,
                "max_edges_per_node": 5,
                "field_weights": {"revenue": 1.0},
            },
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }
        schema = KBEntitySchema.model_validate(payload)
        assert schema.fields is not None
        assert len(schema.fields) == 1
        assert schema.similarity_config is not None
        assert schema.similarity_config.enabled is True


class TestKBSimilarityConfigMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBSimilarityConfig
        from sonzai._generated.models import KBSimilarityConfig as GenKBSimilarityConfig
        assert KBSimilarityConfig is GenKBSimilarityConfig

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBSimilarityConfig
        payload = {
            "enabled": True,
            "threshold": 0.75,
            "max_edges_per_node": 10,
            "field_weights": {"label": 2.0, "type": 1.0},
        }
        cfg = KBSimilarityConfig.model_validate(payload)
        assert cfg.enabled is True
        assert cfg.threshold == 0.75
        assert cfg.max_edges_per_node == 10
        assert cfg.field_weights["label"] == 2.0

    def test_spec_fields_present(self) -> None:
        from sonzai import KBSimilarityConfig
        # Hand-rolled had match_fields; spec has field_weights + enabled
        assert "enabled" in KBSimilarityConfig.model_fields
        assert "field_weights" in KBSimilarityConfig.model_fields
        assert "max_edges_per_node" in KBSimilarityConfig.model_fields


class TestKBRelatedNodeMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBRelatedNode
        from sonzai._generated.models import KBRelatedNode as GenKBRelatedNode
        assert KBRelatedNode is GenKBRelatedNode

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBRelatedNode
        payload = {
            "node_id": "node-2",
            "label": "Bob",
            "type": "Person",
            "edge": "KNOWS",
        }
        rel = KBRelatedNode.model_validate(payload)
        assert rel.node_id == "node-2"
        assert rel.label == "Bob"
        assert rel.edge == "KNOWS"

    def test_spec_field_edge_string(self) -> None:
        from sonzai import KBRelatedNode
        # Spec uses `edge: str`; hand-rolled had `edge_type: str` and `node_type: str`
        assert "edge" in KBRelatedNode.model_fields
        assert "type" in KBRelatedNode.model_fields


class TestKBSearchResultMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBSearchResult
        from sonzai._generated.models import KBSearchResult as GenKBSearchResult
        assert KBSearchResult is GenKBSearchResult

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBSearchResult
        payload = {
            "node_id": "node-abc",
            "type": "Person",
            "label": "Alice",
            "properties": {"age": 30},
            "updated_at": "2024-01-01T00:00:00Z",
            "version": 1,
        }
        result = KBSearchResult.model_validate(payload)
        assert result.node_id == "node-abc"
        assert result.type == "Person"
        assert result.label == "Alice"
        assert result.version == 1

    def test_spec_fields_present(self) -> None:
        from sonzai import KBSearchResult
        for field in ("node_id", "type", "label", "properties", "updated_at", "version"):
            assert field in KBSearchResult.model_fields


class TestKBSearchResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBSearchResponse
        from sonzai._generated.models import KBSearchResponse as GenKBSearchResponse
        assert KBSearchResponse is GenKBSearchResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBSearchResponse
        payload = {
            "query": "find Alice",
            "results": None,
            "total": 0,
        }
        resp = KBSearchResponse.model_validate(payload)
        assert resp.query == "find Alice"
        assert resp.total == 0

    def test_spec_fields_present(self) -> None:
        from sonzai import KBSearchResponse
        for field in ("query", "results", "total"):
            assert field in KBSearchResponse.model_fields


class TestKBAnalyticsRuleMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBAnalyticsRule
        from sonzai._generated.models import KBAnalyticsRule as GenKBAnalyticsRule
        assert KBAnalyticsRule is GenKBAnalyticsRule

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBAnalyticsRule
        payload = {
            "project_id": "proj-1",
            "rule_id": "rule-1",
            "rule_type": "recommendation",
            "name": "Top Products",
            "config": {"k": 5},
            "enabled": True,
            "schedule": "0 * * * *",
            "last_run_at": "2024-01-01T00:00:00Z",
            "last_run_status": "success",
            "last_run_duration_ms": 120,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }
        rule = KBAnalyticsRule.model_validate(payload)
        assert rule.project_id == "proj-1"
        assert rule.rule_id == "rule-1"
        assert rule.enabled is True

    def test_spec_fields_present(self) -> None:
        from sonzai import KBAnalyticsRule
        for field in (
            "project_id", "rule_id", "rule_type", "name", "config",
            "enabled", "schedule", "last_run_at", "last_run_status",
            "last_run_duration_ms", "created_at", "updated_at",
        ):
            assert field in KBAnalyticsRule.model_fields


class TestKBRecommendationScoreMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBRecommendationScore
        from sonzai._generated.models import KBRecommendationScore as GenKBRecommendationScore
        assert KBRecommendationScore is GenKBRecommendationScore

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBRecommendationScore
        payload = {
            "project_id": "proj-1",
            "rule_id": "rule-1",
            "source_node_id": "node-src",
            "score": 0.95,
            "target_node_id": "node-tgt",
            "target_label": "Widget",
            "target_type": "Product",
            "reasoning": {"why": "high similarity"},
            "computed_at": "2024-01-01T00:00:00Z",
        }
        rec = KBRecommendationScore.model_validate(payload)
        assert rec.project_id == "proj-1"
        assert rec.score == 0.95
        assert rec.target_node_id == "node-tgt"

    def test_spec_fields_present(self) -> None:
        from sonzai import KBRecommendationScore
        for field in (
            "project_id", "rule_id", "source_node_id", "score",
            "target_node_id", "target_label", "target_type", "reasoning", "computed_at",
        ):
            assert field in KBRecommendationScore.model_fields


class TestKBConversionStatsMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBConversionStats
        from sonzai._generated.models import KBConversionStats as GenKBConversionStats
        assert KBConversionStats is GenKBConversionStats

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBConversionStats
        payload = {
            "project_id": "proj-1",
            "rule_id": "rule-1",
            "segment_key": "seg-A",
            "target_type": "Product",
            "conversion_count": 10,
            "total_leads": 100,
            "shown_count": 200,
            "conversion_rate": 0.05,
            "avg_days_to_convert": 3.5,
            "top_features": {"price": 0.8},
            "computed_at": "2024-01-01T00:00:00Z",
        }
        stats = KBConversionStats.model_validate(payload)
        assert stats.project_id == "proj-1"
        assert stats.conversion_count == 10
        assert stats.conversion_rate == 0.05

    def test_spec_fields_present(self) -> None:
        from sonzai import KBConversionStats
        for field in (
            "project_id", "rule_id", "segment_key", "target_type",
            "conversion_count", "total_leads", "shown_count", "conversion_rate",
            "avg_days_to_convert", "top_features", "computed_at",
        ):
            assert field in KBConversionStats.model_fields


class TestKBTrendAggregationMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBTrendAggregation
        from sonzai._generated.models import KBTrendAggregation as GenKBTrendAggregation
        assert KBTrendAggregation is GenKBTrendAggregation

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBTrendAggregation
        payload = {
            "project_id": "proj-1",
            "node_id": "node-1",
            "metric_name": "page_views",
            "window": "7d",
            "value": 42.0,
            "sample_count": 7,
            "min_value": 5.0,
            "max_value": 10.0,
            "computed_at": "2024-01-01T00:00:00Z",
        }
        agg = KBTrendAggregation.model_validate(payload)
        assert agg.project_id == "proj-1"
        assert agg.metric_name == "page_views"
        assert agg.value == 42.0

    def test_spec_fields_present(self) -> None:
        from sonzai import KBTrendAggregation
        for field in (
            "project_id", "node_id", "metric_name", "window",
            "value", "sample_count", "min_value", "max_value", "computed_at",
        ):
            assert field in KBTrendAggregation.model_fields


class TestKBTrendRankingMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import KBTrendRanking
        from sonzai._generated.models import KBTrendRanking as GenKBTrendRanking
        assert KBTrendRanking is GenKBTrendRanking

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import KBTrendRanking
        payload = {
            "project_id": "proj-1",
            "rule_id": "rule-1",
            "ranking_type": "trending",
            "window": "7d",
            "rank": 1,
            "node_id": "node-1",
            "node_label": "Widget A",
            "value": 99.5,
            "computed_at": "2024-01-01T00:00:00Z",
        }
        ranking = KBTrendRanking.model_validate(payload)
        assert ranking.project_id == "proj-1"
        assert ranking.rank == 1
        assert ranking.node_label == "Widget A"

    def test_spec_fields_present(self) -> None:
        from sonzai import KBTrendRanking
        for field in (
            "project_id", "rule_id", "ranking_type", "window",
            "rank", "node_id", "node_label", "value", "computed_at",
        ):
            assert field in KBTrendRanking.model_fields


# ---------------------------------------------------------------------------
# Batch 10 — Agents/Evals/Inventory/Projects
# ---------------------------------------------------------------------------


class TestAgentIndexMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import AgentIndex
        from sonzai._generated.models import AgentIndex as GenAgentIndex
        assert AgentIndex is GenAgentIndex

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import AgentIndex
        payload = {
            "agent_id": "agt-1",
            "tenant_id": "tnt-1",
            "owner_user_id": "usr-1",
            "instance_count": 2,
            "is_active": True,
            "created_at": "2024-01-01T00:00:00Z",
        }
        obj = AgentIndex.model_validate(payload)
        assert obj.agent_id == "agt-1"
        assert obj.instance_count == 2
        assert obj.is_active is True

    def test_spec_fields_present(self) -> None:
        from sonzai import AgentIndex
        for field in ("agent_id", "tenant_id", "owner_user_id", "instance_count", "is_active", "created_at"):
            assert field in AgentIndex.model_fields


class TestAgentInstanceMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import AgentInstance
        from sonzai._generated.models import AgentInstance as GenAgentInstance
        assert AgentInstance is GenAgentInstance

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import AgentInstance
        payload = {
            "instance_id": "inst-1",
            "agent_id": "agt-1",
            "name": "Default",
            "status": "active",
            "is_default": True,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-02T00:00:00Z",
        }
        obj = AgentInstance.model_validate(payload)
        assert obj.instance_id == "inst-1"
        assert obj.name == "Default"
        assert obj.is_default is True

    def test_spec_fields_present(self) -> None:
        from sonzai import AgentInstance
        for field in ("instance_id", "agent_id", "name", "status", "is_default", "created_at", "updated_at"):
            assert field in AgentInstance.model_fields


class TestEvalCategoryMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import EvalCategory
        from sonzai._generated.models import EvalCategory as GenEvalCategory
        assert EvalCategory is GenEvalCategory

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import EvalCategory
        payload = {
            "key": "empathy",
            "label": "Empathy",
            "prompt_instructions": "Evaluate emotional awareness.",
        }
        obj = EvalCategory.model_validate(payload)
        assert obj.key == "empathy"
        assert obj.label == "Empathy"
        assert obj.prompt_instructions == "Evaluate emotional awareness."

    def test_spec_fields_present(self) -> None:
        from sonzai import EvalCategory
        for field in ("key", "label", "prompt_instructions"):
            assert field in EvalCategory.model_fields


class TestEvalTemplateMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import EvalTemplate
        from sonzai._generated.models import EvalTemplate as GenEvalTemplate
        assert EvalTemplate is GenEvalTemplate

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import EvalTemplate
        payload = {
            "template_id": "tpl-1",
            "name": "Quality Check",
            "description": "Checks quality",
            "template_type": "quality",
            "judge_model": "gpt-4",
            "temperature": 0.3,
            "max_tokens": 8192,
            "scoring_rubric": "Rate 1-10",
            "categories": None,
            "is_system": False,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-02T00:00:00Z",
        }
        obj = EvalTemplate.model_validate(payload)
        assert obj.template_id == "tpl-1"
        assert obj.name == "Quality Check"
        assert obj.template_type == "quality"

    def test_spec_fields_present(self) -> None:
        from sonzai import EvalTemplate
        for field in ("template_id", "name", "description", "template_type", "judge_model",
                      "temperature", "max_tokens", "scoring_rubric", "created_at", "updated_at"):
            assert field in EvalTemplate.model_fields


class TestEvalRunMigration:
    def test_imports_from_customization(self) -> None:
        from sonzai import EvalRun
        from sonzai._customizations import EvalRun as CustEvalRun
        from sonzai._generated.models import EvalRun as GenEvalRun
        assert EvalRun is CustEvalRun
        assert EvalRun is not GenEvalRun
        assert issubclass(EvalRun, GenEvalRun)

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import EvalRun
        payload = {
            "run_id": "run-1",
            "tenant_id": "tnt-1",
            "project_id": "proj-1",
            "agent_id": "agt-1",
            "agent_name": "Agent",
            "status": "completed",
            "character_config": {},
            "template_id": "tpl-1",
            "template_snapshot": {},
            "simulation_config": {},
            "simulation_model": "gpt-4",
            "user_persona": {},
            "transcript": [],
            "evaluation_result": {},
            "adaptation_result": {},
            "simulation_state": {},
            "total_sessions": 1,
            "total_turns": 5,
            "simulated_minutes": 30,
            "total_cost_usd": 0.5,
            "simulation_cost_usd": 0.3,
            "evaluation_cost_usd": 0.2,
            "adaptation_template_id": "adapt-1",
            "adaptation_template_snapshot": None,
            "started_at": "2024-01-01T00:00:00Z",
            "created_at": "2024-01-01T00:00:00Z",
            "completed_at": None,
        }
        obj = EvalRun.model_validate(payload)
        assert obj.run_id == "run-1"
        assert obj.agent_id == "agt-1"
        assert obj.total_turns == 5

    def test_id_alias_returns_run_id(self) -> None:
        from sonzai import EvalRun
        payload = {
            "run_id": "run-42",
            "agent_id": "agt-1",
            "agent_name": "Agent",
            "status": "completed",
            "character_config": {},
            "template_id": "tpl-1",
            "template_snapshot": {},
            "simulation_config": {},
            "simulation_model": "gpt-4",
            "user_persona": {},
            "transcript": [],
            "evaluation_result": {},
            "adaptation_result": {},
            "simulation_state": {},
            "total_sessions": 1,
            "total_turns": 5,
            "simulated_minutes": 30,
            "total_cost_usd": 0.5,
            "simulation_cost_usd": 0.3,
            "evaluation_cost_usd": 0.2,
            "adaptation_template_id": "adapt-1",
            "adaptation_template_snapshot": None,
            "started_at": "2024-01-01T00:00:00Z",
            "created_at": "2024-01-01T00:00:00Z",
            "completed_at": None,
        }
        obj = EvalRun.model_validate(payload)
        assert obj.id == "run-42"
        assert obj.id == obj.run_id


class TestImportJobMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import ImportJob
        from sonzai._generated.models import ImportJob as GenImportJob
        assert ImportJob is GenImportJob

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import ImportJob
        payload = {
            "job_id": "job-1",
            "tenant_id": "tnt-1",
            "agent_id": "agt-1",
            "job_type": "batch",
            "status": "pending",
            "source_type": "csv",
            "total_users": 10,
            "processed_users": 5,
            "facts_stored": 45,
            "facts_deduped": 5,
            "facts_extracted": 50,
            "errors": 0,
            "warmth_score": 3,
            "constellation_nodes": 2,
            "error_details": None,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-02T00:00:00Z",
        }
        obj = ImportJob.model_validate(payload)
        assert obj.job_id == "job-1"
        assert obj.status == "pending"
        assert obj.total_users == 10

    def test_spec_fields_present(self) -> None:
        from sonzai import ImportJob
        for field in ("job_id", "tenant_id", "agent_id", "job_type", "status",
                      "total_users", "processed_users", "created_at", "updated_at"):
            assert field in ImportJob.model_fields


class TestJobUserMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import JobUser
        from sonzai._generated.models import JobUser as GenJobUser
        assert JobUser is GenJobUser

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import JobUser
        payload = {
            "job_id": "job-1",
            "user_id": "usr-1",
            "status": "completed",
            "facts_stored": 10,
            "facts_deduped": 2,
            "warmth_score": 5,
            "updated_at": "2024-01-02T00:00:00Z",
        }
        obj = JobUser.model_validate(payload)
        assert obj.job_id == "job-1"
        assert obj.user_id == "usr-1"
        assert obj.facts_stored == 10

    def test_spec_fields_present(self) -> None:
        from sonzai import JobUser
        for field in ("job_id", "user_id", "status", "facts_stored", "facts_deduped", "warmth_score", "updated_at"):
            assert field in JobUser.model_fields


class TestBatchImportUserMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import BatchImportUser
        from sonzai._generated.models import BatchImportUser as GenBatchImportUser
        assert BatchImportUser is GenBatchImportUser

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import BatchImportUser
        payload = {"user_id": "usr-1"}
        obj = BatchImportUser.model_validate(payload)
        assert obj.user_id == "usr-1"

    def test_spec_fields_present(self) -> None:
        from sonzai import BatchImportUser
        assert "user_id" in BatchImportUser.model_fields


class TestInventoryItemMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import InventoryItem
        from sonzai._generated.models import InventoryItem as GenInventoryItem
        assert InventoryItem is GenInventoryItem

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import InventoryItem
        payload = {
            "fact_id": "fact-1",
            "item_label": "Widget",
            "user_properties": {"color": "red"},
        }
        obj = InventoryItem.model_validate(payload)
        assert obj.fact_id == "fact-1"
        assert obj.item_label == "Widget"
        assert obj.user_properties == {"color": "red"}

    def test_spec_fields_present(self) -> None:
        from sonzai import InventoryItem
        for field in ("fact_id", "item_label", "user_properties"):
            assert field in InventoryItem.model_fields


class TestCustomStateMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import CustomState
        from sonzai._generated.models import CustomState as GenCustomState
        assert CustomState is GenCustomState

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import CustomState
        payload = {
            "state_id": "st-1",
            "agent_id": "agt-1",
            "scope": "user",
            "key": "mood",
            "value": "happy",
            "content_type": "text",
            "user_id": None,
            "instance_id": None,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-02T00:00:00Z",
        }
        obj = CustomState.model_validate(payload)
        assert obj.state_id == "st-1"
        assert obj.key == "mood"
        assert obj.value == "happy"

    def test_spec_fields_present(self) -> None:
        from sonzai import CustomState
        for field in ("state_id", "agent_id", "scope", "key", "value", "content_type",
                      "created_at", "updated_at"):
            assert field in CustomState.model_fields


class TestCustomToolDefinitionMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import CustomToolDefinition
        from sonzai._generated.models import CustomToolDefinition as GenCustomToolDefinition
        assert CustomToolDefinition is GenCustomToolDefinition

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import CustomToolDefinition
        payload = {
            "name": "get_weather",
            "description": "Fetches weather for a location",
            "parameters": {"type": "object", "properties": {"location": {"type": "string"}}},
        }
        obj = CustomToolDefinition.model_validate(payload)
        assert obj.name == "get_weather"
        assert obj.description == "Fetches weather for a location"

    def test_spec_fields_present(self) -> None:
        from sonzai import CustomToolDefinition
        for field in ("name", "description", "parameters"):
            assert field in CustomToolDefinition.model_fields


class TestPendingCapabilityMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import PendingCapability
        from sonzai._generated.models import PendingCapability as GenPendingCapability
        assert PendingCapability is GenPendingCapability

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import PendingCapability
        payload = {"capability": "vision"}
        obj = PendingCapability.model_validate(payload)
        assert obj.capability == "vision"

    def test_spec_fields_present(self) -> None:
        from sonzai import PendingCapability
        assert "capability" in PendingCapability.model_fields


class TestProjectMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import Project
        from sonzai._generated.models import Project as GenProject
        assert Project is GenProject

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import Project
        payload = {
            "project_id": "proj-1",
            "tenant_id": "tnt-1",
            "name": "My Game",
            "game_name": "FantasyRPG",
            "environment": "production",
            "created_at": "2024-01-01T00:00:00Z",
            "is_active": True,
        }
        obj = Project.model_validate(payload)
        assert obj.project_id == "proj-1"
        assert obj.name == "My Game"
        assert obj.is_active is True

    def test_spec_fields_present(self) -> None:
        from sonzai import Project
        for field in ("project_id", "tenant_id", "name", "game_name", "environment", "created_at", "is_active"):
            assert field in Project.model_fields


class TestProjectAPIKeyMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import ProjectAPIKey
        from sonzai._generated.models import ProjectAPIKey as GenProjectAPIKey
        assert ProjectAPIKey is GenProjectAPIKey

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import ProjectAPIKey
        payload = {
            "key_id": "key-1",
            "project_id": "proj-1",
            "tenant_id": "tnt-1",
            "name": "API Key",
            "key_prefix": "sk-",
            "created_by": "usr-1",
            "created_at": "2024-01-01T00:00:00Z",
            "is_active": True,
            "is_admin_managed": False,
            "scopes": ["read"],
        }
        obj = ProjectAPIKey.model_validate(payload)
        assert obj.key_id == "key-1"
        assert obj.project_id == "proj-1"
        assert obj.is_active is True

    def test_spec_fields_present(self) -> None:
        from sonzai import ProjectAPIKey
        for field in ("key_id", "project_id", "tenant_id", "name", "key_prefix",
                      "created_by", "created_at", "is_active", "is_admin_managed"):
            assert field in ProjectAPIKey.model_fields


class TestWebhookDeliveryAttemptMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import WebhookDeliveryAttempt
        from sonzai._generated.models import WebhookDeliveryAttempt as GenWebhookDeliveryAttempt
        assert WebhookDeliveryAttempt is GenWebhookDeliveryAttempt

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import WebhookDeliveryAttempt
        payload = {
            "attempt_id": "att-1",
            "event_type": "message.created",
            "webhook_url": "https://example.com/hook",
            "response_code": 200,
            "duration_ms": 150,
            "attempt_number": 1,
            "status": "success",
            "created_at": "2024-01-01T00:00:00Z",
            "project_id": "proj-1",
        }
        obj = WebhookDeliveryAttempt.model_validate(payload)
        assert obj.attempt_id == "att-1"
        assert obj.response_code == 200
        assert obj.status == "success"

    def test_spec_fields_present(self) -> None:
        from sonzai import WebhookDeliveryAttempt
        for field in ("attempt_id", "event_type", "webhook_url", "response_code",
                      "duration_ms", "attempt_number", "status", "created_at"):
            assert field in WebhookDeliveryAttempt.model_fields


# ---------------------------------------------------------------------------
# Batch 11 — Priming & Users
# ---------------------------------------------------------------------------


class TestPrimeContentBlockMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import PrimeContentBlock
        from sonzai._generated.models import PrimeContentBlock as GenPrimeContentBlock
        assert PrimeContentBlock is GenPrimeContentBlock

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import PrimeContentBlock
        payload = {"type": "text", "body": "Hello world"}
        obj = PrimeContentBlock.model_validate(payload)
        assert obj.type == "text"
        assert obj.body == "Hello world"

    def test_spec_fields_present(self) -> None:
        from sonzai import PrimeContentBlock
        for field in ("type", "body"):
            assert field in PrimeContentBlock.model_fields


class TestPrimeUserMetadataMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import PrimeUserMetadata
        from sonzai._generated.models import PrimeUserMetadata as GenPrimeUserMetadata
        assert PrimeUserMetadata is GenPrimeUserMetadata

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import PrimeUserMetadata
        payload: dict = {}
        obj = PrimeUserMetadata.model_validate(payload)
        assert obj.company is None
        assert obj.email is None

    def test_spec_fields_present(self) -> None:
        from sonzai import PrimeUserMetadata
        for field in ("company", "email", "phone", "title"):
            assert field in PrimeUserMetadata.model_fields


class TestUserPersonaMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import UserPersona
        from sonzai._generated.models import UserPersona as GenUserPersona
        assert UserPersona is GenUserPersona

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import UserPersona
        payload = {
            "name": "Casual Gamer",
            "description": "A laid-back player who enjoys casual games",
            "style": "informal",
        }
        obj = UserPersona.model_validate(payload)
        assert obj.name == "Casual Gamer"
        assert obj.description == "A laid-back player who enjoys casual games"
        assert obj.style == "informal"

    def test_spec_fields_present(self) -> None:
        from sonzai import UserPersona
        for field in ("name", "description", "style"):
            assert field in UserPersona.model_fields


class TestUserPersonaRecordMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import UserPersonaRecord
        from sonzai._generated.models import UserPersonaRecord as GenUserPersonaRecord
        assert UserPersonaRecord is GenUserPersonaRecord

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import UserPersonaRecord
        payload = {
            "persona_id": "persona-1",
            "name": "Power User",
            "description": "An experienced user who knows the product well",
            "style": "technical",
            "is_default": False,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-02T00:00:00Z",
        }
        obj = UserPersonaRecord.model_validate(payload)
        assert obj.persona_id == "persona-1"
        assert obj.name == "Power User"
        assert obj.is_default is False

    def test_spec_fields_present(self) -> None:
        from sonzai import UserPersonaRecord
        for field in ("persona_id", "name", "description", "style", "is_default",
                      "created_at", "updated_at"):
            assert field in UserPersonaRecord.model_fields


class TestUsersResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import UsersResponse
        from sonzai._generated.models import UsersResponse as GenUsersResponse
        assert UsersResponse is GenUsersResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import UsersResponse
        payload = {
            "users": [
                {"user_id": "u-1", "role": "user"},
            ],
            "total": 1,
        }
        obj = UsersResponse.model_validate(payload)
        assert obj.total == 1
        assert len(obj.users) == 1
        assert obj.users[0].user_id == "u-1"

    def test_spec_fields_present(self) -> None:
        from sonzai import UsersResponse
        for field in ("users", "total"):
            assert field in UsersResponse.model_fields


# ---------------------------------------------------------------------------
# Batch 12 (FINAL) — Support/Forks/Wisdom
# ---------------------------------------------------------------------------


class TestForkResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import ForkResponse
        from sonzai._generated.models import ForkResponse as GenForkResponse
        assert ForkResponse is GenForkResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import ForkResponse
        payload = {
            "agent_id": "agent-fork-1",
            "source_agent_id": "agent-src-1",
            "status": "pending",
            "name": "My Forked Agent",
        }
        obj = ForkResponse.model_validate(payload)
        assert obj.agent_id == "agent-fork-1"
        assert obj.source_agent_id == "agent-src-1"
        assert obj.status == "pending"
        assert obj.name == "My Forked Agent"

    def test_spec_fields_present(self) -> None:
        from sonzai import ForkResponse
        for field in ("agent_id", "source_agent_id", "status", "name"):
            assert field in ForkResponse.model_fields


class TestForkStatusResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import ForkStatusResponse
        from sonzai._generated.models import ForkStatusResponse as GenForkStatusResponse
        assert ForkStatusResponse is GenForkStatusResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import ForkStatusResponse
        payload = {
            "status": "running",
            "source_agent_id": "agent-src-1",
            "tables_copied": 3,
            "tables_total": 10,
        }
        obj = ForkStatusResponse.model_validate(payload)
        assert obj.status == "running"
        assert obj.source_agent_id == "agent-src-1"
        assert obj.tables_copied == 3
        assert obj.tables_total == 10

    def test_spec_fields_present(self) -> None:
        from sonzai import ForkStatusResponse
        for field in ("status", "source_agent_id", "tables_copied", "tables_total"):
            assert field in ForkStatusResponse.model_fields


class TestSupportTicketCommentMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import SupportTicketComment
        from sonzai._generated.models import SupportTicketComment as GenSupportTicketComment
        assert SupportTicketComment is GenSupportTicketComment

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import SupportTicketComment
        payload = {
            "comment_id": "c-1",
            "ticket_id": "t-1",
            "author_id": "u-1",
            "author_email": "user@example.com",
            "author_type": "user",
            "content": "Hello",
            "is_internal": False,
            "created_at": "2026-01-01T00:00:00Z",
        }
        obj = SupportTicketComment.model_validate(payload)
        assert obj.comment_id == "c-1"
        assert obj.ticket_id == "t-1"
        assert obj.is_internal is False

    def test_spec_fields_present(self) -> None:
        from sonzai import SupportTicketComment
        for field in ("comment_id", "ticket_id", "author_id", "author_email",
                      "author_type", "content", "is_internal", "created_at"):
            assert field in SupportTicketComment.model_fields


class TestSupportTicketHistoryMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import SupportTicketHistory
        from sonzai._generated.models import SupportTicketHistory as GenSupportTicketHistory
        assert SupportTicketHistory is GenSupportTicketHistory

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import SupportTicketHistory
        payload = {
            "history_id": "h-1",
            "ticket_id": "t-1",
            "changed_by": "u-1",
            "changed_by_email": "user@example.com",
            "field_changed": "status",
            "created_at": "2026-01-01T00:00:00Z",
        }
        obj = SupportTicketHistory.model_validate(payload)
        assert obj.history_id == "h-1"
        assert obj.field_changed == "status"

    def test_spec_fields_present(self) -> None:
        from sonzai import SupportTicketHistory
        for field in ("history_id", "ticket_id", "changed_by", "changed_by_email",
                      "field_changed", "created_at"):
            assert field in SupportTicketHistory.model_fields


class TestSupportTicketMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import SupportTicket
        from sonzai._generated.models import SupportTicket as GenSupportTicket
        assert SupportTicket is GenSupportTicket

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import SupportTicket
        payload = {
            "ticket_id": "t-1",
            "tenant_id": "tenant-1",
            "created_by": "u-1",
            "created_by_email": "user@example.com",
            "title": "Something broke",
            "description": "It stopped working",
            "type": "bug",
            "status": "open",
            "priority": "high",
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }
        obj = SupportTicket.model_validate(payload)
        assert obj.ticket_id == "t-1"
        assert obj.title == "Something broke"
        assert obj.status == "open"

    def test_spec_fields_present(self) -> None:
        from sonzai import SupportTicket
        for field in ("ticket_id", "tenant_id", "created_by", "created_by_email",
                      "title", "description", "type", "status", "priority",
                      "created_at", "updated_at"):
            assert field in SupportTicket.model_fields


class TestTicketDetailResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import TicketDetailResponse
        from sonzai._generated.models import TicketDetailResponse as GenTicketDetailResponse
        assert TicketDetailResponse is GenTicketDetailResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import TicketDetailResponse
        payload = {
            "ticket": {
                "ticket_id": "t-1",
                "tenant_id": "tenant-1",
                "created_by": "u-1",
                "created_by_email": "user@example.com",
                "title": "Issue",
                "description": "Details",
                "type": "support",
                "status": "open",
                "priority": "medium",
                "created_at": "2026-01-01T00:00:00Z",
                "updated_at": "2026-01-01T00:00:00Z",
            }
        }
        obj = TicketDetailResponse.model_validate(payload)
        assert obj.ticket.ticket_id == "t-1"
        assert obj.history is None

    def test_spec_fields_present(self) -> None:
        from sonzai import TicketDetailResponse
        assert "ticket" in TicketDetailResponse.model_fields


class TestTicketListResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import TicketListResponse
        from sonzai._generated.models import TicketListResponse as GenTicketListResponse
        assert TicketListResponse is GenTicketListResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import TicketListResponse
        payload = {
            "tickets": [],
            "total": 0,
            "has_more": False,
        }
        obj = TicketListResponse.model_validate(payload)
        assert obj.total == 0
        assert obj.has_more is False

    def test_spec_fields_present(self) -> None:
        from sonzai import TicketListResponse
        for field in ("tickets", "total", "has_more"):
            assert field in TicketListResponse.model_fields


class TestTicketSummaryMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import TicketSummary
        from sonzai._generated.models import TicketSummary as GenTicketSummary
        assert TicketSummary is GenTicketSummary

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import TicketSummary
        payload = {
            "ticket_id": "t-1",
            "title": "Login issue",
            "type": "support",
            "status": "open",
            "priority": "medium",
            "created_by_email": "user@example.com",
            "comment_count": 0,
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }
        obj = TicketSummary.model_validate(payload)
        assert obj.ticket_id == "t-1"
        assert obj.title == "Login issue"
        assert obj.comment_count == 0

    def test_spec_fields_present(self) -> None:
        from sonzai import TicketSummary
        for field in ("ticket_id", "title", "type", "status", "priority",
                      "created_by_email", "comment_count", "created_at", "updated_at"):
            assert field in TicketSummary.model_fields


class TestWisdomAuditResponseMigration:
    def test_imports_from_generated(self) -> None:
        from sonzai import WisdomAuditResponse
        from sonzai._generated.models import WisdomAuditResponse as GenWisdomAuditResponse
        assert WisdomAuditResponse is GenWisdomAuditResponse

    def test_minimal_required_roundtrip(self) -> None:
        from sonzai import WisdomAuditResponse
        payload = {
            "fact_id": "fact-1",
            "content": "Users prefer dark mode",
            "source_user_count": 42,
            "promotion_confidence": 0.87,
        }
        obj = WisdomAuditResponse.model_validate(payload)
        assert obj.fact_id == "fact-1"
        assert obj.content == "Users prefer dark mode"
        assert obj.source_user_count == 42
        assert obj.promotion_confidence == 0.87

    def test_spec_fields_present(self) -> None:
        from sonzai import WisdomAuditResponse
        for field in ("fact_id", "content", "source_user_count", "promotion_confidence"):
            assert field in WisdomAuditResponse.model_fields
