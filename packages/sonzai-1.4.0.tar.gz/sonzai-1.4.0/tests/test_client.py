"""Tests for the Sonzai client."""

import json

import httpx
import pytest
import respx

from sonzai import (
    AsyncSonzai,
    AuthenticationError,
    BadRequestError,
    NotFoundError,
    Sonzai,
)


@pytest.fixture
def base_url():
    return "https://api.test.sonz.ai"


@pytest.fixture
def client(base_url):
    c = Sonzai(api_key="test-key", base_url=base_url)
    yield c
    c.close()


@pytest.fixture
def async_client(base_url):
    return AsyncSonzai(api_key="test-key", base_url=base_url)


class TestClientInit:
    def test_requires_api_key(self):
        with pytest.raises(ValueError, match="api_key must be provided"):
            Sonzai()

    def test_accepts_api_key(self):
        client = Sonzai(api_key="test-key")
        assert client.agents is not None
        client.close()

    def test_env_var_api_key(self, monkeypatch):
        monkeypatch.setenv("SONZAI_API_KEY", "env-key")
        client = Sonzai()
        assert client.agents is not None
        client.close()

    def test_context_manager(self):
        with Sonzai(api_key="test-key") as client:
            assert client.agents is not None


class TestChat:
    @respx.mock
    def test_chat_sync(self, client, base_url):
        sse_body = (
            'data: {"choices":[{"delta":{"content":"Hello"},"finish_reason":null,"index":0}]}\n\n'
            'data: {"choices":[{"delta":{"content":" world"},"finish_reason":"stop","index":0}],'
            '"usage":{"promptTokens":10,"completionTokens":5,"totalTokens":15}}\n\n'
            "data: [DONE]\n\n"
        )
        respx.post(f"{base_url}/api/v1/agents/agent-1/chat").mock(
            return_value=httpx.Response(
                200,
                content=sse_body,
                headers={"content-type": "text/event-stream"},
            )
        )

        response = client.agents.chat(
            agent_id="agent-1",
            messages=[{"role": "user", "content": "Hi"}],
        )
        assert response.content == "Hello world"
        assert response.usage is not None
        assert response.usage.total_tokens == 15

    @respx.mock
    def test_chat_stream(self, client, base_url):
        sse_body = (
            'data: {"choices":[{"delta":{"content":"Hi"},"finish_reason":null,"index":0}]}\n\n'
            'data: {"choices":[{"delta":{"content":"!"},"finish_reason":"stop","index":0}]}\n\n'
            "data: [DONE]\n\n"
        )
        respx.post(f"{base_url}/api/v1/agents/agent-1/chat").mock(
            return_value=httpx.Response(
                200,
                content=sse_body,
                headers={"content-type": "text/event-stream"},
            )
        )

        events = list(
            client.agents.chat(
                agent_id="agent-1",
                messages=[{"role": "user", "content": "Hi"}],
                stream=True,
            )
        )
        assert len(events) == 2
        assert events[0].content == "Hi"
        assert events[1].content == "!"
        assert events[1].is_finished


class TestMemory:
    @respx.mock
    def test_list_memory(self, client, base_url):
        respx.get(f"{base_url}/api/v1/agents/agent-1/memory").mock(
            return_value=httpx.Response(
                200,
                json={
                    "nodes": [
                        {
                            "node_id": "n1",
                            "agent_id": "agent-1",
                            "name": "Favorites",
                            "description": "Favorite things",
                            "path": "root/favorites",
                            "memory_type": "semantic",
                            "importance": 0.8,
                            "created_at": "2026-01-01T00:00:00Z",
                            "updated_at": "2026-01-01T00:00:00Z",
                        }
                    ],
                    "contents": {},
                },
            )
        )

        result = client.agents.memory.list("agent-1")
        assert len(result.nodes) == 1
        assert result.nodes[0].node_id == "n1"
        assert result.nodes[0].name == "Favorites"

    @respx.mock
    def test_search_memory(self, client, base_url):
        respx.get(f"{base_url}/api/v1/agents/agent-1/memory/search").mock(
            return_value=httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "fact_id": "f1",
                            "content": "Likes pizza",
                            "fact_type": "preference",
                            "score": 0.95,
                        }
                    ]
                },
            )
        )

        result = client.agents.memory.search("agent-1", query="food")
        assert len(result.results) == 1
        assert result.results[0].content == "Likes pizza"


class TestPersonality:
    @respx.mock
    def test_get_personality(self, client, base_url):
        _trait = {"score": 0.8, "confidence": 0.9}
        respx.get(f"{base_url}/api/v1/agents/agent-1/personality").mock(
            return_value=httpx.Response(
                200,
                json={
                    "profile": {
                        "agent_id": "agent-1",
                        "name": "Luna",
                        "gender": "female",
                        "created_at": "2026-01-01T00:00:00Z",
                        "temperature": 0.7,
                        "speech_patterns": [],
                        "true_interests": [],
                        "true_dislikes": [],
                        "primary_traits": [],
                        "big5": {
                            "openness": {"score": 0.8, "confidence": 0.9},
                            "conscientiousness": {"score": 0.6, "confidence": 0.8},
                            "extraversion": {"score": 0.7, "confidence": 0.85},
                            "agreeableness": {"score": 0.9, "confidence": 0.95},
                            "neuroticism": {"score": 0.3, "confidence": 0.75},
                        },
                        "dimensions": {
                            "intellect": 8.0, "aesthetic": 7.0, "industriousness": 6.0,
                            "orderliness": 5.0, "enthusiasm": 7.0, "assertiveness": 6.0,
                            "compassion": 9.0, "politeness": 8.0, "withdrawal": 3.0,
                            "volatility": 2.0,
                        },
                        "preferences": {
                            "conversation_pace": "relaxed",
                            "emotional_expression": "open",
                            "formality": "casual",
                            "humor_style": "dry",
                        },
                        "behaviors": {
                            "conflict_approach": "collaborative",
                            "empathy_style": "reflective",
                            "question_frequency": "moderate",
                            "response_length": "medium",
                        },
                    },
                    "evolution": [],
                },
            )
        )

        result = client.agents.personality.get("agent-1")
        assert result.profile.name == "Luna"
        assert result.profile.big5.openness.score == 0.8


class TestSessions:
    @respx.mock
    def test_start_session(self, client, base_url):
        respx.post(f"{base_url}/api/v1/agents/agent-1/sessions/start").mock(
            return_value=httpx.Response(200, json={"success": True})
        )

        result = client.agents.sessions.start(
            "agent-1", user_id="user-1", session_id="sess-1"
        )
        assert result.success

    @respx.mock
    def test_end_session(self, client, base_url):
        respx.post(f"{base_url}/api/v1/agents/agent-1/sessions/end").mock(
            return_value=httpx.Response(200, json={"success": True})
        )

        result = client.agents.sessions.end(
            "agent-1",
            user_id="user-1",
            session_id="sess-1",
            total_messages=10,
            duration_seconds=300,
        )
        assert result.success


class TestInstances:
    @respx.mock
    def test_list_instances(self, client, base_url):
        respx.get(f"{base_url}/api/v1/agents/agent-1/instances").mock(
            return_value=httpx.Response(
                200,
                json={
                    "instances": [
                        {
                            "instance_id": "inst-1",
                            "agent_id": "agent-1",
                            "name": "Default",
                            "status": "active",
                            "is_default": True,
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-02T00:00:00Z",
                        }
                    ]
                },
            )
        )

        result = client.agents.instances.list("agent-1")
        assert len(result.instances) == 1
        assert result.instances[0].name == "Default"

    @respx.mock
    def test_create_instance(self, client, base_url):
        respx.post(f"{base_url}/api/v1/agents/agent-1/instances").mock(
            return_value=httpx.Response(
                201,
                json={
                    "instance_id": "inst-2",
                    "agent_id": "agent-1",
                    "name": "Test",
                    "status": "active",
                    "is_default": False,
                    "created_at": "2024-01-01T00:00:00Z",
                    "updated_at": "2024-01-02T00:00:00Z",
                },
            )
        )

        result = client.agents.instances.create("agent-1", name="Test")
        assert result.instance_id == "inst-2"
        assert result.name == "Test"


class TestNotifications:
    @respx.mock
    def test_list_notifications(self, client, base_url):
        respx.get(f"{base_url}/api/v1/agents/agent-1/notifications").mock(
            return_value=httpx.Response(
                200,
                json={
                    "notifications": [
                        {
                            "message_id": "msg-1",
                            "agent_id": "agent-1",
                            "generated_message": "Hey there!",
                            "status": "pending",
                        }
                    ]
                },
            )
        )

        result = client.agents.notifications.list("agent-1")
        assert len(result.notifications) == 1
        assert result.notifications[0].generated_message == "Hey there!"

    @respx.mock
    def test_consume_notification(self, client, base_url):
        respx.post(
            f"{base_url}/api/v1/agents/agent-1/notifications/msg-1/consume"
        ).mock(return_value=httpx.Response(200, json={"success": True}))

        result = client.agents.notifications.consume("agent-1", "msg-1")
        assert result.success


_EVAL_TEMPLATE_FIXTURE = {
    "template_id": "tpl-1",
    "name": "Quality Check",
    "description": "Evaluates quality",
    "template_type": "quality",
    "judge_model": "gpt-4",
    "temperature": 0.3,
    "max_tokens": 8192,
    "scoring_rubric": "Be helpful",
    "is_system": False,
    "categories": None,
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-02T00:00:00Z",
}

_EVAL_RUN_FIXTURE = {
    "run_id": "run-1",
    "agent_id": "agent-1",
    "agent_name": "Agent",
    "status": "completed",
    "character_config": {},
    "template_id": "tpl-1",
    "template_snapshot": {},
    "simulation_config": {},
    "simulation_model": "gpt-4",
    "user_persona": {},
    "transcript": [],
    "evaluation_result": {},
    "adaptation_result": {},
    "simulation_state": {},
    "total_sessions": 1,
    "total_turns": 20,
    "simulated_minutes": 30,
    "total_cost_usd": 0.5,
    "simulation_cost_usd": 0.3,
    "evaluation_cost_usd": 0.2,
    "adaptation_template_id": "adapt-1",
    "adaptation_template_snapshot": None,
    "started_at": "2024-01-01T00:00:00Z",
    "created_at": "2024-01-01T00:00:00Z",
    "completed_at": None,
}


class TestEvalTemplates:
    @respx.mock
    def test_list_templates(self, client, base_url):
        respx.get(f"{base_url}/api/v1/eval-templates").mock(
            return_value=httpx.Response(
                200,
                json={"templates": [_EVAL_TEMPLATE_FIXTURE]},
            )
        )

        result = client.eval_templates.list()
        assert len(result.templates) == 1
        assert result.templates[0].name == "Quality Check"

    @respx.mock
    def test_create_template(self, client, base_url):
        fixture = {**_EVAL_TEMPLATE_FIXTURE, "template_id": "tpl-2", "name": "New Template"}
        respx.post(f"{base_url}/api/v1/eval-templates").mock(
            return_value=httpx.Response(201, json=fixture)
        )

        result = client.eval_templates.create(
            name="New Template", scoring_rubric="Score well"
        )
        assert result.template_id == "tpl-2"


class TestEvalRuns:
    @respx.mock
    def test_list_runs(self, client, base_url):
        respx.get(f"{base_url}/api/v1/eval-runs").mock(
            return_value=httpx.Response(
                200,
                json={"runs": [_EVAL_RUN_FIXTURE], "total_count": 1},
            )
        )

        result = client.eval_runs.list()
        assert len(result.runs) == 1
        assert result.runs[0].status == "completed"


class TestTriggerGameEvent:
    """TD-SDK-009: trigger_backend_event should accept an optional `messages` list
    and forward it in the JSON body. When omitted, the field must NOT appear
    in the payload (back-compat with older Platform servers)."""

    @respx.mock
    def test_trigger_event_with_messages(self, client, base_url):
        route = respx.post(f"{base_url}/api/v1/agents/agent-1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )

        from sonzai.types import ChatMessage

        client.agents.trigger_backend_event(
            "agent-1",
            user_id="user-1",
            event_type="daily_summary",
            messages=[
                ChatMessage(role="user", content="hi"),
                {"role": "assistant", "content": "hello"},
            ],
        )

        assert route.called
        sent = json.loads(route.calls.last.request.content)
        assert sent["messages"] == [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        assert sent["event_type"] == "daily_summary"
        assert sent["user_id"] == "user-1"

    @respx.mock
    def test_trigger_event_without_messages_omits_field(self, client, base_url):
        route = respx.post(f"{base_url}/api/v1/agents/agent-1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )

        client.agents.trigger_backend_event(
            "agent-1",
            user_id="user-1",
            event_type="daily_summary",
        )

        assert route.called
        sent = json.loads(route.calls.last.request.content)
        assert "messages" not in sent

    @respx.mock
    async def test_trigger_event_async_with_messages(self, async_client, base_url):
        route = respx.post(f"{base_url}/api/v1/agents/agent-1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )

        await async_client.agents.trigger_backend_event(
            "agent-1",
            user_id="user-1",
            event_type="daily_summary",
            messages=[{"role": "user", "content": "hi"}],
        )

        assert route.called
        sent = json.loads(route.calls.last.request.content)
        assert sent["messages"] == [{"role": "user", "content": "hi"}]
        await async_client.close()


class TestErrorHandling:
    @respx.mock
    def test_401_raises_auth_error(self, client, base_url):
        respx.get(f"{base_url}/api/v1/agents/agent-1/memory").mock(
            return_value=httpx.Response(401, json={"error": "Invalid API key"})
        )

        with pytest.raises(AuthenticationError):
            client.agents.memory.list("agent-1")

    @respx.mock
    def test_404_raises_not_found(self, client, base_url):
        respx.get(f"{base_url}/api/v1/agents/bad-id/personality").mock(
            return_value=httpx.Response(404, json={"error": "Agent not found"})
        )

        with pytest.raises(NotFoundError):
            client.agents.personality.get("bad-id")

    @respx.mock
    def test_400_raises_bad_request(self, client, base_url):
        respx.post(f"{base_url}/api/v1/agents/agent-1/chat").mock(
            return_value=httpx.Response(
                400, json={"error": "messages is required"}
            )
        )

        with pytest.raises(BadRequestError):
            client.agents.chat(agent_id="agent-1", messages=[])
