# EasyID Python SDK

Official Python SDK for the EasyID identity verification API.

EasyID 易验云 focuses on identity verification and security risk control APIs, including real-name verification, liveness detection, face recognition, phone verification, and fraud-risk related capabilities.

中文文档： [README.zh-CN.md](README.zh-CN.md)

## Install

```bash
pip install easyid-python
```

## Quick Start

```python
from easyid import EasyID

client = EasyID("ak_xxx", "sk_xxx")
result = client.idcard.verify2(name="张三", id_number="110101199001011234")

print(result.match)
```

## Supported APIs

- IDCard: `verify2`, `verify3`, `ocr`
- Phone: `status`, `verify3`
- Face: `liveness`, `compare`, `verify`
- Bank: `verify4`
- Risk: `score`, `store_fingerprint`
- Billing: `balance`, `records`

## Configuration

- `base_url`
- `timeout`
- `session`

## Error Handling

Service-side business errors raise `APIError`.

```python
from easyid import APIError

try:
    client.phone.status(phone="13800138000")
except APIError as exc:
    print(exc.code, exc.message, exc.request_id)
```

## Security Notice

This is a server-side SDK. Never expose `secret` in browsers, mobile apps, or other untrusted clients.

## Official Resources

- Official website: `https://www.easyid.com.cn/`
- GitHub organization: `https://github.com/easyid-com-cn/`
