"""
tests/test_integration.py
--------------------------
End-to-end integration tests that run the generator against the three
demo modules (element.py, container.py, graphics.py) and assert on the
content of the resulting stubs.

These tests mirror the test suite from the original build/tests/test_stubpy.py
but are restructured as pytest classes and use the shared fixtures from
conftest.py.
"""
from __future__ import annotations

import ast
import os
import sys
import tempfile
import textwrap
from pathlib import Path

import pytest

from stubpy import generate_stub

from .conftest import assert_valid_syntax, flatten, make_stub


# ---------------------------------------------------------------------------
# Plain class stubs
# ---------------------------------------------------------------------------

class TestPlain:
    def test_basic_signature(self):
        c = make_stub("""
            class Rect:
                def __init__(self, width: float, height: float) -> None: pass
                def area(self) -> float: return self.width * self.height
        """)
        assert "def __init__(self, width: float, height: float) -> None:" in c
        assert "def area(self) -> float:" in c

    def test_default_value(self):
        c = make_stub("class Box:\n    def __init__(self, size: int = 10) -> None: pass\n")
        assert "size: int = 10" in c

    def test_no_hints_keeps_param_names(self):
        c = make_stub("class Bare:\n    def __init__(self, x, y): pass\n")
        assert "def __init__(self, x, y)" in c


# ---------------------------------------------------------------------------
# Type annotation handling
# ---------------------------------------------------------------------------

class TestAnnotations:
    def test_optional_shorthand(self):
        c = make_stub("""
            class A:
                def __init__(self, x: str | None = None) -> None: pass
        """)
        assert "Optional[str]" in c

    def test_union_three_types(self):
        c = make_stub("""
            class A:
                def __init__(self, x: str | int | float) -> None: pass
        """)
        assert "str | int | float" in c

    def test_callable_annotation(self):
        c = make_stub("""
            from typing import Callable
            class A:
                def __init__(self, fn: Callable[[], None] | None = None) -> None: pass
        """)
        assert "Callable" in c

    def test_literal_annotation(self):
        c = make_stub("""
            from typing import Literal
            class A:
                def __init__(self, cap: Literal["butt", "round"] = "butt") -> None: pass
        """)
        assert "Literal['butt', 'round']" in c

    def test_tuple_annotation(self):
        c = make_stub("""
            from typing import Tuple
            class A:
                def __init__(self, pt: Tuple[float, float]) -> None: pass
        """)
        assert "Tuple[float, float]" in c


# ---------------------------------------------------------------------------
# Single-level **kwargs backtracing
# ---------------------------------------------------------------------------

class TestSingleKwargs:
    SRC = """
        class Parent:
            def __init__(self, color: str, size: int) -> None: pass
        class Child(Parent):
            def __init__(self, label: str, **kwargs): super().__init__(**kwargs)
    """

    @staticmethod
    def _child_section(c: str) -> str:
        return c.split("class Child")[1].split("\nclass ")[0]

    def test_merged(self):
        c = make_stub(self.SRC)
        child = self._child_section(c)
        assert "label: str" in child
        assert "color: str" in child
        assert "size: int"  in child

    def test_kwargs_gone(self):
        c = make_stub(self.SRC)
        assert "**kwargs" not in self._child_section(c)

    def test_defaults_preserved(self):
        c = make_stub("""
            class B:
                def __init__(self, x: float = 0.0) -> None: pass
            class D(B):
                def __init__(self, name: str, **kwargs): super().__init__(**kwargs)
        """)
        assert "x: float = 0.0" in c


# ---------------------------------------------------------------------------
# Multi-level **kwargs backtracing
# ---------------------------------------------------------------------------

class TestMultiLevel:
    SRC = """
        class A:
            def __init__(self, name: str, legs: int, wild: bool = True) -> None: pass
        class B(A):
            def __init__(self, owner: str, **kwargs): super().__init__(**kwargs)
        class C(B):
            def __init__(self, breed: str, **kwargs): super().__init__(**kwargs)
        class D(C):
            def __init__(self, job: str, **kwargs): super().__init__(**kwargs)
    """

    @staticmethod
    def _sec(c: str, name: str) -> str:
        return c.split(f"class {name}")[1].split("\nclass ")[0]

    def test_three_levels(self):
        c = make_stub(self.SRC)
        s = self._sec(c, "C")
        for p in ("breed: str", "owner: str", "name: str", "legs: int"):
            assert p in s
        assert "**kwargs" not in s

    def test_four_levels_with_default(self):
        c = make_stub(self.SRC)
        s = self._sec(c, "D")
        for p in ("job: str", "breed: str", "owner: str", "name: str", "wild: bool = True"):
            assert p in s
        assert "**kwargs" not in s

    def test_own_param_comes_first(self):
        c = flatten(make_stub(self.SRC))
        for line in c.splitlines():
            if "class C(" in line:
                in_c = True
            if "def __init__" in line and "class C" in c.split("def __init__")[0].rsplit("\n", 5)[-1]:
                assert line.index("breed") < line.index("owner") < line.index("name")
                break


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_open_kwargs_preserved_when_no_parent(self):
        c = make_stub("class W:\n    def __init__(self, x: str, **kwargs): pass\n")
        assert "**kwargs" in c

    def test_unresolved_args_preserved(self):
        c = make_stub("class V:\n    def __init__(self, first: int, *args): pass\n")
        assert "*args" in c

    def test_kw_only_gets_separator(self):
        c = flatten(make_stub("""
            class K:
                def __init__(self, a: int, *, b: str = "x") -> None: pass
        """))
        init_line = [l for l in c.splitlines() if "def __init__" in l][0]
        assert "*," in init_line
        assert init_line.index("*,") < init_line.index("b:")


# ---------------------------------------------------------------------------
# Special method decorators
# ---------------------------------------------------------------------------

class TestSpecialMethods:
    def test_classmethod(self):
        c = make_stub("""
            class F:
                @classmethod
                def create(cls, v: int) -> 'F': return cls()
        """)
        assert "@classmethod" in c
        assert "def create(cls, v: int)" in c

    def test_staticmethod(self):
        c = make_stub("""
            class U:
                @staticmethod
                def add(a: int, b: int) -> int: return a + b
        """)
        assert "@staticmethod" in c
        assert "def add(a: int, b: int) -> int:" in c

    def test_property_with_setter(self):
        c = make_stub("""
            class P:
                @property
                def value(self) -> float: return self._v
                @value.setter
                def value(self, v: float) -> None: self._v = v
        """)
        assert "@property"     in c
        assert "def value(self) -> float:" in c
        assert "@value.setter" in c
        assert "def value(self, v: float) -> None:" in c


# ---------------------------------------------------------------------------
# @classmethod cls() backtracing
# ---------------------------------------------------------------------------

class TestClassmethodCls:
    SRC = """
        class Widget:
            def __init__(self, width: int, height: int, color: str = "black") -> None:
                pass

            @classmethod
            def square(cls, **kwargs) -> 'Widget':
                return cls(**kwargs)

            @classmethod
            def colored(cls, color: str, **kwargs) -> 'Widget':
                return cls(color=color, **kwargs)
    """

    @staticmethod
    def _method_line(content: str, method: str) -> str:
        for line in flatten(content).splitlines():
            if f"def {method}(cls" in line:
                return line
        return ""

    def test_square_gets_init_params(self):
        c = make_stub(self.SRC)
        line = self._method_line(c, "square")
        assert line, "square method not found"
        assert "width: int"  in line
        assert "height: int" in line
        assert "color: str"  in line
        assert "**kwargs"    not in line

    def test_colored_excludes_explicit_param_once(self):
        c = make_stub(self.SRC)
        line = self._method_line(c, "colored")
        assert line, "colored method not found"
        assert "color: str" in line
        assert "width: int" in line
        assert line.count("color:") == 1

    def test_chained_cls_kwargs(self):
        c = make_stub("""
            class Base:
                def __init__(self, x: int, y: int) -> None: pass
            class Child(Base):
                def __init__(self, label: str, **kwargs): super().__init__(**kwargs)
                @classmethod
                def make(cls, **kwargs) -> 'Child':
                    return cls(**kwargs)
        """)
        line = self._method_line(c, "make")
        assert "label: str" in line
        assert "x: int"     in line
        assert "y: int"     in line
        assert "**kwargs"   not in line


# ---------------------------------------------------------------------------
# Type alias preservation
# ---------------------------------------------------------------------------

class TestTypeAliasPreservation:
    @staticmethod
    def _make_types_package() -> tuple[str, str]:
        tmpdir = tempfile.mkdtemp()
        types_src = textwrap.dedent("""
            from typing import Literal, Tuple
            Number = int | float
            Length = str | float | int
            Color  = str | Tuple[float, float, float]
            Cap    = Literal["butt", "round", "square"]
        """)
        open(os.path.join(tmpdir, "__init__.py"), "w").close()
        open(os.path.join(tmpdir, "types.py"), "w").write(types_src)
        return tmpdir, os.path.basename(tmpdir)

    def test_aliases_preserved_not_expanded(self):
        tmpdir, pkg_name = self._make_types_package()
        src = textwrap.dedent(f"""
            from __future__ import annotations
            import sys
            sys.path.insert(0, {repr(os.path.dirname(tmpdir))})
            from {pkg_name} import types

            class Shape:
                def __init__(self, width: types.Length, color: types.Color) -> None:
                    pass
        """)
        tmp = tempfile.NamedTemporaryFile(
            suffix=".py", mode="w", delete=False, encoding="utf-8", dir=tmpdir
        )
        tmp.write(src); tmp.flush(); tmp.close()
        c = generate_stub(tmp.name, str(Path(tmp.name).with_suffix(".pyi")))
        assert "types.Length" in c
        assert "types.Color"  in c
        assert "str | float | int" not in c

    def test_type_module_import_in_header(self):
        tmpdir, pkg_name = self._make_types_package()
        src = textwrap.dedent(f"""
            from __future__ import annotations
            import sys
            sys.path.insert(0, {repr(os.path.dirname(tmpdir))})
            from {pkg_name} import types

            class A:
                def __init__(self, x: types.Length) -> None: pass
        """)
        tmp = tempfile.NamedTemporaryFile(
            suffix=".py", mode="w", delete=False, encoding="utf-8", dir=tmpdir
        )
        tmp.write(src); tmp.flush(); tmp.close()
        c = generate_stub(tmp.name, str(Path(tmp.name).with_suffix(".pyi")))
        header = "\n".join(c.splitlines()[:10])
        assert "import types" in header


# ---------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------

class TestFormatting:
    def test_many_params_multiline(self):
        c = make_stub("""
            class A:
                def __init__(self, x: int, y: int, z: int) -> None: pass
        """)
        def_lines = [l for l in c.splitlines() if "def __init__" in l]
        assert def_lines
        assert def_lines[0].rstrip().endswith("("), \
            "Expected multi-line: def line should end with '('"

    def test_few_params_inline(self):
        c = make_stub("""
            class A:
                def move(self, x: int, y: int) -> None: pass
        """)
        move_lines = [l for l in c.splitlines() if "def move" in l]
        assert move_lines
        assert "x: int" in move_lines[0], "Expected inline formatting"

    def test_multiline_is_valid_python(self):
        c = make_stub("""
            class A:
                def __init__(self, a: int, b: str, c: float, d: bool = True) -> None: pass
        """)
        assert_valid_syntax(c)

    def test_trailing_comma_on_param_lines(self):
        c = make_stub("""
            class A:
                def __init__(self, x: int, y: int, z: int) -> None: pass
        """)
        for line in c.splitlines():
            stripped = line.strip()
            if any(p in stripped for p in ("x:", "y:", "z:")) and ")" not in stripped:
                assert stripped.endswith(","), f"Missing trailing comma: {line!r}"


# ---------------------------------------------------------------------------
# demo/element.py — integration
# ---------------------------------------------------------------------------

class TestElementDemo:
    @pytest.fixture(autouse=True)
    def setup(self, element_stub):
        self.c    = element_stub
        self.flat = flatten(element_stub)

    def _sec(self, name: str) -> str:
        return self.c.split(f"class {name}")[1].split("\nclass ")[0]

    def test_both_classes_present(self):
        assert "class Style:"      in self.c
        assert "class Element(ABC):" in self.c

    def test_valid_syntax(self):
        assert_valid_syntax(self.c)

    def test_style_open_kwargs_preserved(self):
        assert "**props: Any" in self._sec("Style")

    def test_style_classmethod(self):
        s = self._sec("Style")
        assert "@classmethod" in s
        assert "def from_dict(cls, data: Dict[str, Any]) -> Style:" in s

    def test_style_dunder_methods(self):
        s = self._sec("Style")
        assert "def __setitem__" in s
        assert "def __getitem__" in s

    def test_element_init_params(self):
        elem = flatten(self._sec("Element"))
        init = [l for l in elem.splitlines() if "def __init__" in l][0]
        assert "id: Optional[str]"    in init
        assert "title: Optional[str]" in init
        assert "opacity: float"       in init
        assert "-> None"              in init

    def test_element_transform_methods(self):
        assert "def translate(self, tx: float, ty: float = 0.0) -> Element:" in self.c
        assert "def scale(self, sx: float, sy: Optional[float] = None) -> Element:" in self.c

    def test_element_rotate_multiline(self):
        rotate_lines = [l for l in self.c.splitlines() if "def rotate(" in l]
        assert rotate_lines, "rotate not found"
        assert rotate_lines[0].rstrip().endswith("("), "rotate should be multi-line"

    def test_element_blank_resolves_kwargs(self):
        """blank(**kwargs) → cls(opacity=0.0, **kwargs): id & title appear; opacity excluded."""
        elem    = flatten(self._sec("Element"))
        methods = [l for l in elem.splitlines() if "def blank(cls" in l]
        assert methods, "blank classmethod not found"
        line = methods[0]
        assert "id:"    in line
        assert "title:" in line
        assert "**kwargs" not in line

    def test_no_cross_imports_in_header(self):
        # element.py does not import from any sibling demo module —
        # only stdlib and typing imports appear in the header.
        header = self.c.splitlines()[:10]
        non_abc_demo = [l for l in header if l.startswith("from demo") and "abc" not in l]
        assert not non_abc_demo, f"Unexpected demo import in header: {non_abc_demo}"


# ---------------------------------------------------------------------------
# demo/container.py — integration
# ---------------------------------------------------------------------------

class TestContainerDemo:
    @pytest.fixture(autouse=True)
    def setup(self, container_stub):
        self.c    = container_stub
        self.flat = flatten(container_stub)

    def _sec(self, name: str) -> str:
        return self.c.split(f"class {name}")[1].split("\nclass ")[0]

    def test_both_classes_present(self):
        assert "class Container(Element):" in self.c
        assert "class Layer(Container):"   in self.c

    def test_element_import_in_header(self):
        header = "\n".join(self.c.splitlines()[:8])
        assert "from demo.element import Element" in header

    def test_valid_syntax(self):
        assert_valid_syntax(self.c)

    def test_star_args_preserved(self):
        cont = flatten(self._sec("Container"))
        init = [l for l in cont.splitlines() if "def __init__" in l][0]
        assert "*elements: Element" in init

    def test_kwargs_resolved_from_element(self):
        cont = flatten(self._sec("Container"))
        init = [l for l in cont.splitlines() if "def __init__" in l][0]
        assert "id: Optional[str]"    in init
        assert "title: Optional[str]" in init
        assert "opacity: float"       in init
        assert "**kwargs"             not in init

    def test_container_methods(self):
        assert "def add(self, *elements: Element) -> Container:" in self.c
        assert "def remove(self, element: Element) -> Container:" in self.c
        assert "def get(self, index: int) -> Element:"           in self.c
        assert "def clone(self, deep: bool = True) -> Container:" in self.c

    def test_container_dunder_methods(self):
        assert "def __iter__(self) -> Iterator[Element]:" in self.c
        assert "def __len__(self) -> int:"                in self.c

    def test_layer_three_level_chain(self):
        layer = flatten(self._sec("Layer"))
        init  = [l for l in layer.splitlines() if "def __init__" in l][0]
        for p in ("name: str", "locked: bool", "visible: bool", "label:", "id:", "opacity:"):
            assert p in init, f"Missing: {p}"
        assert "**kwargs" not in init

    def test_layer_kw_only_separator(self):
        layer = flatten(self._sec("Layer"))
        init  = [l for l in layer.splitlines() if "def __init__" in l][0]
        assert "*," in init
        assert init.index("visible:") < init.index("*,") < init.index("label:")

    def test_layer_own_methods(self):
        assert "def lock(self) -> Layer:"       in self.c
        assert "def unlock(self) -> Layer:"     in self.c
        assert "def hide(self) -> Layer:"       in self.c
        assert "def show_layer(self) -> Layer:" in self.c


# ---------------------------------------------------------------------------
# demo/graphics.py — integration
# ---------------------------------------------------------------------------

class TestGraphicsDemo:
    @pytest.fixture(autouse=True)
    def setup(self, graphics_stub):
        self.c    = graphics_stub
        self.flat = flatten(graphics_stub)

    def _sec(self, name: str) -> str:
        return self.c.split(f"class {name}")[1].split("\nclass ")[0]

    def test_expected_classes_present(self):
        for cls in ("Shape", "Path", "Arc", "Rectangle", "Square", "Circle"):
            assert f"class {cls}" in self.c
        # Element lives in element.py — should NOT be redefined here
        assert "class Element:" not in self.c

    def test_valid_syntax(self):
        assert_valid_syntax(self.c)

    def test_types_import_in_header(self):
        header = "\n".join(self.c.splitlines()[:8])
        assert "from demo import types" in header

    def test_element_import_in_header(self):
        header = "\n".join(self.c.splitlines()[:8])
        assert "from demo.element import Element" in header

    def test_arc_fully_resolved(self):
        arc = self._sec("Arc")
        for p in ("angle: float", "offset: float", "d: str", "clip_path",
                  "fill", "stroke_linecap", "opacity: float"):
            assert p in arc, f"Missing: {p}"
        assert "**kwargs" not in arc

    def test_type_aliases_in_shape(self):
        shape = self._sec("Shape")
        assert "types.Color"          in shape
        assert "types.Length"         in shape
        assert "types.StrokeLineCap"  in shape
        assert "types.StrokeLineJoin" in shape
        assert "str | float | int"    not in shape

    def test_type_aliases_propagated_through_kwargs(self):
        rect = self._sec("Rectangle")
        assert "types.Length" in rect
        assert "types.Color"  in rect

    def test_circle_property(self):
        circ = self._sec("Circle")
        assert "@property"               in circ
        assert "def area(self) -> float:" in circ

    def test_circle_diameter_property_alias(self):
        circ = self._sec("Circle")
        assert "def diameter(self) -> types.Length:" in circ

    def test_circle_unit_classmethod_resolved(self):
        circ  = flatten(self._sec("Circle"))
        lines = [l for l in circ.splitlines() if "def unit(cls" in l]
        assert lines, "Circle.unit not found"
        line = lines[0]
        # Shape + Element params present
        for p in ("fill", "opacity", "stroke_width"):
            assert p in line, f"Missing in unit: {p}"
        # r, cx, cy are hardcoded in cls(r=1, cx=0, cy=0, ...) → excluded
        param_names = [
            tok.strip().split(":")[0].split("=")[0].strip()
            for tok in line.split("(cls,")[1].split(",")
            if tok.strip()
        ]
        for excluded in ("r", "cx", "cy"):
            assert excluded not in param_names, f"{excluded} should be excluded"
        assert "**kwargs" not in line

    def test_circle_at_origin_keeps_r(self):
        """at_origin has explicit r param — it's not hardcoded, so r must appear."""
        circ  = flatten(self._sec("Circle"))
        lines = [l for l in circ.splitlines() if "def at_origin(cls" in l]
        assert lines, "Circle.at_origin not found"
        assert "r:" in lines[0]

    def test_rectangle_from_bounds_classmethod(self):
        rect  = flatten(self._sec("Rectangle"))
        lines = [l for l in rect.splitlines() if "def from_bounds(cls" in l]
        assert lines, "Rectangle.from_bounds not found"
        line = lines[0]
        for p in ("x1:", "x2:", "y1:", "y2:"):
            assert p in line
        # Should also inherit Shape + Element params
        assert "fill" in line
        assert "opacity" in line

    def test_square_inherits_full_chain(self):
        sq = self._sec("Square")
        for p in ("size:", "x:", "y:", "width:", "height:", "fill", "opacity"):
            assert p in sq, f"Missing in Square: {p}"
        assert "**kwargs" not in sq

    def test_path_methods(self):
        path = self.c
        assert "def move_to(self, x: float, y: float) -> Path:" in path
        assert "def line_to(self, x: float, y: float) -> Path:" in path
        assert "def close(self) -> Path:"                        in path


# ---------------------------------------------------------------------------
# Static methods — comprehensive
# ---------------------------------------------------------------------------

class TestStaticMethods:
    def test_static_no_args(self):
        c = make_stub("""
            class A:
                @staticmethod
                def util() -> int: return 42
        """)
        assert "@staticmethod" in c
        assert "def util() -> int: ..." in c
        assert "self" not in c.split("def util")[1].split("\n")[0]
        assert "cls"  not in c.split("def util")[1].split("\n")[0]

    def test_static_with_args(self):
        c = make_stub("""
            class A:
                @staticmethod
                def add(a: float, b: float = 1.0) -> float: return a + b
        """)
        assert "def add(a: float, b: float = 1.0) -> float: ..." in c

    def test_static_open_kwargs(self):
        c = make_stub("""
            class A:
                @staticmethod
                def factory(**kwargs) -> None: pass
        """)
        assert "@staticmethod" in c
        assert "**kwargs" in c

    def test_static_not_inherited_by_stub(self):
        """Only methods defined directly on the class appear."""
        c = make_stub("""
            class Parent:
                @staticmethod
                def parent_util() -> int: return 0
            class Child(Parent):
                @staticmethod
                def child_util() -> str: return ""
        """)
        child_sec = c.split("class Child")[1]
        assert "child_util" in child_sec
        assert "parent_util" not in child_sec

    def test_static_valid_syntax(self):
        c = make_stub("""
            class A:
                @staticmethod
                def compute(x: int, y: int, z: int) -> int: return x + y + z
        """)
        assert_valid_syntax(c)


# ---------------------------------------------------------------------------
# *args and **kwargs together
# ---------------------------------------------------------------------------

class TestArgsAndKwargsTogether:
    def test_both_no_parent(self):
        """*args and **kwargs together with no parent are both preserved."""
        from typing import Any
        c = make_stub("""
            from typing import Any
            class A:
                def __init__(self, x: int, *args: str, flag: bool = False, **kwargs: Any) -> None:
                    pass
        """)
        c_flat = flatten(c)
        init = [l for l in c_flat.splitlines() if "def __init__" in l][0]
        assert "*args: str"     in init
        assert "**kwargs: Any"  in init
        assert "flag: bool"     in init
        # *args must come before **kwargs
        assert init.index("*args") < init.index("**kwargs")
        assert_valid_syntax(c)

    def test_args_before_kwargs_in_output(self):
        """*args always appears before **kwargs in the emitted signature."""
        c = make_stub("""
            class Parent:
                def __init__(self, label: str, **kwargs) -> None: pass
            class Child(Parent):
                def __init__(self, *items: int, **kwargs) -> None:
                    super().__init__(**kwargs)
        """)
        c_flat = flatten(c)
        child_lines = [l for l in c_flat.splitlines() if "class Child" in l or
                       ("def __init__" in l and "Child" in c_flat.split(l)[0].split("class ")[-1])]
        child_init = [l for l in c_flat.splitlines()
                      if "def __init__" in l and "Child" in c.split("def __init__")[1 if c.count("def __init__") > 1 else 0]]
        # Simpler: check the child section
        child_sec = flatten(c.split("class Child")[1])
        init_line = [l for l in child_sec.splitlines() if "def __init__" in l][0]
        assert "*items: int" in init_line
        assert "**kwargs"    in init_line
        assert init_line.index("*items") < init_line.index("**kwargs")
        assert_valid_syntax(c)

    def test_args_before_kwargs_open_parent(self):
        """*args precedes residual **kwargs when parent **kwargs is unresolved."""
        c = make_stub("""
            class Parent:
                def __init__(self, label: str, **kwargs) -> None: pass
            class Child(Parent):
                def __init__(self, *items: int, **kwargs) -> None:
                    super().__init__(**kwargs)
        """)
        child_sec = flatten(c.split("class Child")[1])
        init_line = [l for l in child_sec.splitlines() if "def __init__" in l][0]
        assert "label: str"  in init_line
        assert "*items: int" in init_line
        assert "**kwargs"    in init_line
        assert init_line.index("*items") < init_line.index("**kwargs")
        assert_valid_syntax(c)

    def test_args_after_resolved_kwargs_params(self):
        """When **kwargs resolves fully, *args follows the concrete params."""
        c = make_stub("""
            class Parent:
                def __init__(self, color: str = "black", size: int = 10) -> None: pass
            class Child(Parent):
                def __init__(self, *args: str, **kwargs) -> None:
                    super().__init__(**kwargs)
        """)
        child_sec = flatten(c.split("class Child")[1])
        init_line = [l for l in child_sec.splitlines() if "def __init__" in l][0]
        assert "color: str"  in init_line
        assert "size: int"   in init_line
        assert "*args: str"  in init_line
        assert "**kwargs" not in init_line   # fully resolved
        # concrete params come before *args
        assert init_line.index("color") < init_line.index("*args")
        assert_valid_syntax(c)

    def test_three_level_with_star_args(self):
        """Three-level chain where grandchild has *args."""
        c = make_stub("""
            class GrandParent:
                def __init__(self, width: float, height: float) -> None: pass
            class Middle(GrandParent):
                def __init__(self, name: str, **kwargs) -> None:
                    super().__init__(**kwargs)
            class GrandChild(Middle):
                def __init__(self, *tags: str, **kwargs) -> None:
                    super().__init__(**kwargs)
        """)
        gc_sec = flatten(c.split("class GrandChild")[1])
        init_line = [l for l in gc_sec.splitlines() if "def __init__" in l][0]
        assert "name: str"   in init_line
        assert "width: float" in init_line
        assert "*tags: str"  in init_line
        assert "**kwargs" not in init_line   # fully resolved
        assert_valid_syntax(c)

    def test_kw_only_with_kwargs_resolved(self):
        """Keyword-only params from parent survive through **kwargs backtracing."""
        c = make_stub("""
            class Parent:
                def __init__(self, a: int, *, b: str = "x") -> None: pass
            class Child(Parent):
                def __init__(self, prefix: str, **kwargs) -> None:
                    super().__init__(**kwargs)
        """)
        child_sec = flatten(c.split("class Child")[1])
        init_line = [l for l in child_sec.splitlines() if "def __init__" in l][0]
        assert "prefix: str" in init_line
        assert "a: int"      in init_line
        assert "b: str"      in init_line
        assert "*,"          in init_line     # kw-only separator present
        assert "**kwargs" not in init_line
        assert_valid_syntax(c)


# ---------------------------------------------------------------------------
# Inline import support
# ---------------------------------------------------------------------------

class TestInlineImports:
    """Imports inside function / method bodies are discovered and re-emitted.

    Projects sometimes place imports inside functions to break circular
    dependencies.  stubpy's AST pre-pass uses ``ast.walk`` across the *entire*
    source tree, so inline imports are found in ``scan_import_statements``.
    They are re-emitted in the ``.pyi`` header when the imported name actually
    appears in a stub annotation (return type, parameter type, base class, etc.).
    Imports whose names never appear in the stub body are silently skipped, just
    like top-level imports that are unused in the output.
    """

    def test_inline_import_used_as_return_type(self):
        """Inline import used as a return-type annotation is re-emitted."""
        c = make_stub("""
            def factory() -> 'Widget':
                from demo_module import Widget
                return Widget()
        """)
        assert "from demo_module import Widget" in c
        assert_valid_syntax(c)

    def test_inline_import_as_alias_used_in_annotation(self):
        """``import X as Y`` inline; alias appears in return annotation."""
        c = make_stub("""
            def make() -> 'W':
                from demo_module import Widget as W
                return W()
        """)
        assert "from demo_module import Widget as W" in c
        assert_valid_syntax(c)

    def test_inline_import_in_method_used_as_base(self):
        """Inline import whose name appears as a base class is re-emitted."""
        c = make_stub("""
            class Renderer:
                def _get_canvas(self) -> 'Canvas': ...
            # Canvas is used as an annotation so it appears in the stub body,
            # causing the inline import to be re-emitted.
            def setup() -> 'Canvas':
                from render_lib import Canvas
                return Canvas()
        """)
        assert "from render_lib import Canvas" in c
        assert_valid_syntax(c)

    def test_inline_import_unused_in_stub_not_emitted(self):
        """Inline import whose name never appears in a stub annotation is not emitted.

        The import is discovered but ``collect_cross_imports`` only re-emits
        names that are actually referenced in the generated stub body.
        """
        c = make_stub("""
            class R:
                def render(self):
                    from rlib import Canvas   # Canvas not in any annotation
                    return Canvas()
        """)
        # render has no annotation → Canvas never appears in stub → no import
        assert "rlib" not in c
        assert_valid_syntax(c)

    def test_inline_stdlib_excluded(self):
        """Inline stdlib / typing imports are not re-emitted as cross-file imports."""
        c = make_stub("""
            def helper(x: int) -> list:
                from typing import List
                return []
        """)
        assert_valid_syntax(c)
