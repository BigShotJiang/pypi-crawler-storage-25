"""Hex game server package."""
