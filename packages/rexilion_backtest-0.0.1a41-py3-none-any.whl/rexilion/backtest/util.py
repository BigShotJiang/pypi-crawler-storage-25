import pandas as pd
import numpy as np
import glob
import pandas as pd
from rexilion.backtest import formula

def load_data(data_path, candle_path, start_time, end_time, shift_time):
    import numpy as np
    import pandas as pd

    def _infer_step_ms(times_ms: np.ndarray) -> int:
        if times_ms.size < 2:
            return 0
        t = np.array(times_ms, dtype=np.int64, copy=True)
        t.sort()
        diffs = np.diff(t)
        diffs = diffs[diffs > 0]
        if diffs.size == 0:
            return 0
        return int(np.median(diffs))

    def _step_label(step_ms: int) -> str:
        if step_ms <= 0:
            return "unknown"
        # snap to common intervals if within 2% tolerance
        common = [
            ("1m", 60_000),
            ("3m", 180_000),
            ("5m", 300_000),
            ("10m", 600_000),
            ("15m", 900_000),
            ("30m", 1_800_000),
            ("1h", 3_600_000),
            ("2h", 7_200_000),
            ("4h", 14_400_000),
            ("1d", 86_400_000),
        ]
        for name, ms in common:
            if abs(step_ms - ms) <= int(0.02 * ms):
                return name
        mins = step_ms / 60_000.0
        return f"{mins:.3f}m"

    def _ceil_to_grid(ts_ms: int, step_ms: int, base_ms: int) -> int:
        # smallest value >= ts_ms such that (val - base_ms) % step_ms == 0
        if step_ms <= 0:
            return int(ts_ms)
        x = int(ts_ms) - int(base_ms)
        if x <= 0:
            return int(base_ms)
        q = (x + step_ms - 1) // step_ms
        return int(base_ms + q * step_ms)

    def _ms_to_iso(ms: int) -> str:
        return pd.to_datetime(int(ms), unit="ms", utc=True).strftime("%Y-%m-%d %H:%M:%S")

    # ─────────────────────────────────────────────────────────────
    # Load datasource (optional)
    # ─────────────────────────────────────────────────────────────
    if data_path:
        data = pd.read_csv(data_path)

        # drop any overlapping candle columns from datasource
        if "close" in data.columns:
            data = data.drop(columns=["close"])

        if "start_time" not in data.columns:
            data = pd.DataFrame()
        else:
            data["start_time"] = pd.to_numeric(data["start_time"], errors="coerce")
            data = data.dropna(subset=["start_time"]).copy()
            data["start_time"] = data["start_time"].astype(np.int64)
            data = data.sort_values("start_time", kind="mergesort").reset_index(drop=True)
    else:
        data = pd.DataFrame()

    # ─────────────────────────────────────────────────────────────
    # Load candles
    # ─────────────────────────────────────────────────────────────
    candle = pd.read_csv(candle_path)
    if "start_time" not in candle.columns:
        raise ValueError("Candle CSV missing start_time.")
    candle["start_time"] = pd.to_numeric(candle["start_time"], errors="coerce")
    candle = candle.dropna(subset=["start_time"]).copy()
    candle["start_time"] = candle["start_time"].astype(np.int64)

    # stable ordering & remove duplicate timestamps
    candle = candle.sort_values("start_time", kind="mergesort")
    candle = candle.drop_duplicates(subset=["start_time"], keep="last").reset_index(drop=True)

    # ─────────────────────────────────────────────────────────────
    # Detect timeframes
    # ─────────────────────────────────────────────────────────────
    candle_times = candle["start_time"].to_numpy(np.int64, copy=False)
    candle_step_ms = _infer_step_ms(candle_times)
    if candle_step_ms <= 0:
        raise ValueError("Could not infer candle timeframe (candle_step_ms).")

    data_step_ms = 0
    if not data.empty:
        data_times = data["start_time"].to_numpy(np.int64, copy=False)
        data_step_ms = _infer_step_ms(data_times)
        if data_step_ms <= 0:
            # fallback for sparse/broken datasource
            data_step_ms = 3_600_000

    # base for candle grid alignment (safer than assuming epoch-aligned)
    base_ms = int(candle_times[0] % candle_step_ms)

    # ─────────────────────────────────────────────────────────────
    # PRINT detector + mapping summary (your request)
    # ─────────────────────────────────────────────────────────────
    print(
        f"[load_data] data_step={_step_label(int(data_step_ms))} ({int(data_step_ms)} ms) | "
        f"candle_step={_step_label(int(candle_step_ms))} ({int(candle_step_ms)} ms) | "
        f"delay={float(shift_time):g}m | base_ms={base_ms}"
    )

    # ─────────────────────────────────────────────────────────────
    # Map datasource -> execution candle start_time (enter on close)
    # Rule:
    #   desired_close = data_start + data_step + delay
    #   exec_start    = ceil_to_candle_grid(desired_close) - candle_step
    # ─────────────────────────────────────────────────────────────
    shift_ms = int(float(shift_time) * 60_000)

    if not data.empty:
        data = data.copy()

        # keep original datasource time (useful for audits)
        data["data_start_time"] = data["start_time"].astype(np.int64)

        # readable datasource datetime
        data["data_datetime"] = pd.to_datetime(
            data["data_start_time"], unit="ms", utc=True
        ).dt.strftime("%Y-%m-%d %H:%M:%S")

        desired_close = data["data_start_time"].to_numpy(np.int64) + int(data_step_ms) + int(shift_ms)

        exec_start = np.empty_like(desired_close, dtype=np.int64)
        for i in range(desired_close.size):
            close_aligned = _ceil_to_grid(int(desired_close[i]), candle_step_ms, base_ms)
            exec_start[i] = int(close_aligned - candle_step_ms)

        data["start_time"] = exec_start

        # readable execution candle datetime (start_time of execution candle)
        data["exec_datetime"] = pd.to_datetime(
            data["start_time"], unit="ms", utc=True
        ).dt.strftime("%Y-%m-%d %H:%M:%S")

        # keep only needed candles (so series "reacts" at datasource frequency)
        exec_set = set(exec_start.tolist())
        candle_exec = candle[candle["start_time"].isin(exec_set)].copy()

        # exact match only
        df = pd.merge(data, candle_exec, on="start_time", how="inner")

        # drop typical clutter if present
        columns_to_drop = [
            "end_time_y", "end_time_x",
            "Unnamed: 0_x", "Unnamed: 0_y",
            "end_time",
            "candle_ori_datetime",  # remove if exists (we keep exec_datetime instead)
        ]
        df = df.drop(columns=[c for c in columns_to_drop if c in df.columns], axis=1)

        # PRINT mapping examples (first 2)
        n_show = min(2, len(df))
        print(f"[load_data] mapped_rows={len(df)} (showing {n_show})")
        if n_show > 0:
            ds0 = df["data_start_time"].to_numpy(np.int64)[:n_show]
            ex0 = df["start_time"].to_numpy(np.int64)[:n_show]
            for i in range(n_show):
                d0 = int(ds0[i])
                e0 = int(ex0[i])
                desired0 = int(d0 + int(data_step_ms) + int(shift_ms))
                close_aligned0 = _ceil_to_grid(desired0, int(candle_step_ms), int(base_ms))
                print(
                    f"  ex{i}: data_start={_ms_to_iso(d0)} | desired_close={_ms_to_iso(desired0)} | "
                    f"aligned_close={_ms_to_iso(close_aligned0)} | exec_start={_ms_to_iso(e0)}"
                )

        # PRINT match coverage
        matched_exec = set(df["start_time"].astype(np.int64).tolist())
        miss = len(exec_set) - len(matched_exec)
        if miss:
            print(f"[load_data][WARN] missing_exec_candles={miss} (dropped due to no exact candle match)")
        else:
            print("[load_data] all_exec_candles_matched=YES")

        # OPTIONAL: keep output lean by selecting a clean column order when possible
        # (keeps everything else intact if some cols are missing)
        preferred_first = [
            "start_time",       # execution candle start_time (ms)
            "exec_datetime",    # execution candle readable
            "data_start_time",  # datasource start_time (ms)
            "data_datetime",    # datasource readable
        ]
        keep_order = [c for c in preferred_first if c in df.columns] + [c for c in df.columns if c not in preferred_first]
        df = df[keep_order]

    else:
        # datasource empty: just return candle series as-is
        df = candle.copy()

        # readable candle datetime
        if "exec_datetime" not in df.columns:
            df["exec_datetime"] = pd.to_datetime(df["start_time"], unit="ms", utc=True).dt.strftime("%Y-%m-%d %H:%M:%S")

        print(f"[load_data] datasource empty -> returning candles only (rows={len(df)})")

        # Remove the old helper col if present
        if "candle_ori_datetime" in df.columns:
            df = df.drop(columns=["candle_ori_datetime"])

    # ─────────────────────────────────────────────────────────────
    # Window filter (based on EXECUTION candle start_time)
    # ─────────────────────────────────────────────────────────────
    start_ms = int(start_time.timestamp() * 1000)
    end_ms   = int(end_time.timestamp() * 1000)

    before = len(df)
    df = df[(df["start_time"] >= start_ms) & (df["start_time"] < end_ms)].copy()
    df = df.sort_values("start_time", kind="mergesort").reset_index(drop=True)
    after = len(df)
    print(f"[load_data] window_filter rows: {before} -> {after}")

    # returns on the execution series (now 1-per-data-bar if datasource is regular)
    if "close" in df.columns:
        df["price_chg"] = df["close"].pct_change()
    else:
        df["price_chg"] = np.nan

    # attach detector info (handy for sanity checks)
    df.attrs["data_step_ms"] = int(data_step_ms)
    df.attrs["candle_step_ms"] = int(candle_step_ms)
    df.attrs["data_step_label"] = _step_label(int(data_step_ms))
    df.attrs["candle_step_label"] = _step_label(int(candle_step_ms))

    return df

def slice_data(df: pd.DataFrame, start_time, end_time) -> pd.DataFrame:
    """
    Return only the rows whose 'start_time' (in ms) lies in [start_time, end_time).

    Parameters
    ----------
    df : pd.DataFrame
        Must contain a 'start_time' column (ms since epoch, UTC).
    start_time : datetime-like or pd.Timestamp
        Inclusive lower bound.
    end_time : datetime-like or pd.Timestamp
        Exclusive upper bound.

    Returns
    -------
    pd.DataFrame
        The filtered, index-reset DataFrame.
    """
    # 1) coerce to pandas Timestamp with UTC
    start_ts = pd.to_datetime(start_time, utc=True)
    end_ts   = pd.to_datetime(end_time,   utc=True)

    # 2) convert to millis
    start_ms = int(start_ts.timestamp() * 1000)
    end_ms   = int(end_ts.timestamp()   * 1000)

    # 3) filter and reset index
    mask = (df['start_time'] >= start_ms) & (df['start_time'] < end_ms)
    return df.loc[mask].reset_index(drop=True)

def generate_report(df, param1, param2, fees, sr_multiplier, start_time, end_time):
    # Calculate trades and PnL
    df["trades"] = abs(df["pos"] - df["pos"].shift(1))
    df["pnl"] = df["price_chg"] * df["pos"].shift(1) - df["trades"] * fees / 100.0
    df = slice_data(df, start_time, end_time)
    df["cumu"] = df["pnl"].cumsum()

    # Sharpe Ratio
    sharp_ratio = df["pnl"].mean() / df["pnl"].std() * np.sqrt(365 * sr_multiplier) if df["pnl"].std() != 0 else 0

    # Maximum drawdown and recovery period
    df["cumu_max"] = df["cumu"].cummax()
    df["drawdown"] = df["cumu"] - df["cumu_max"]
    mdd = df["drawdown"].min()

    recovery_period_days = None  # Default when no recovery occurs
    if mdd < 0:  # Proceed only if a drawdown exists
        # Find the start of the maximum drawdown
        mdd_start_idx = df[df["drawdown"] == mdd].index[0]

        # Find recovery index (if exists)
        recovery_idxs = df[(df.index > mdd_start_idx) & (df["cumu"] >= df.loc[mdd_start_idx, "cumu_max"])].index

        if len(recovery_idxs) > 0:
            recovery_period = recovery_idxs[0] - mdd_start_idx

            # Convert to days
            if isinstance(df.index, pd.DatetimeIndex):
                recovery_period_days = recovery_period.total_seconds() / (3600 * 24)
            else:
                recovery_period_days = recovery_period / 24  # Assume each step in the index represents 1 hour

    # Annualized return and Calmar Ratio
    ar = df["pnl"].mean() * 365 * sr_multiplier
    cr = ar / abs(mdd) if mdd != 0 else float('inf')

    # Total trades
    trades_count = df["trades"].sum()

    # Generate report
    report = {
        "param1": param1,
        "param2": param2,
        "SR": sharp_ratio,
        "CR": cr,
        "MDD": mdd,
        "Recovery Period (days)": recovery_period_days,
        "Trades": trades_count,
        "AR": ar,
        "Trades Ratio": trades_count / len(df),
    }
    return report, df

def merge_csv_files(folder_path, output_file):
    """
    Merges multiple CSV files based on 'start_time' and 'datetime', keeping the first 'close' column
    encountered and removing 'close' and 'endtime' from all other files.
    
    :param folder_path: Path to the folder containing CSV files.
    :param output_file: Path to save the merged CSV file.
    """
    try:
        csv_files = glob.glob(f"{folder_path}/*.csv")
        if not csv_files:
            print("No CSV files found in the folder. Skipping merge.")
            return

        dfs = {}
        required_columns = {'start_time', 'datetime'}
        close_file = None  # Track the file with the first 'close' column
        
        for file in csv_files:
            try:
                df = pd.read_csv(file, usecols=lambda col: col not in ['Unnamed: 0'])
                if not required_columns.issubset(df.columns):
                    print(f"Skipping {file}: Required columns {required_columns} not found.")
                    continue
                df = df.drop_duplicates(subset=['start_time', 'datetime'])
                df = df.drop(columns=['endtime'], errors='ignore')  # Drop 'endtime' column
                dfs[file] = df
                
                # Check for 'close' column and set the first one found
                if 'close' in df.columns and close_file is None:
                    close_file = file
            except Exception as e:
                print(f"Error reading {file}: {str(e)}")
                continue

        if not dfs:
            print("No valid CSV files found. Skipping merge.")
            return

        # Use the DataFrame with the first 'close' as the base (if found), otherwise the first file
        if close_file:
            base_file = close_file
            print(f"Using 'close' from {base_file}")
        else:
            base_file = list(dfs.keys())[0]
            print(f"No 'close' column found in any file; using {base_file} as base without 'close'.")
        
        merged_df = dfs[base_file]

        # Merge with remaining DataFrames, dropping their 'close' columns if not the base
        for file, df in dfs.items():
            if file == base_file:
                continue
            df_no_close = df.drop(columns=['close'], errors='ignore')  # Drop 'close' if not base
            suffix = f"_{file.split('/')[-1].replace('.csv', '')}"
            merged_df = merged_df.merge(df_no_close, on=['start_time', 'datetime'], 
                                        how='inner', suffixes=(None, suffix))

        # Save result
        merged_df.to_csv(output_file, index=False)
        print(f"Merged data saved to {output_file}")

    except Exception as e:
        print(f"Error during merge: {str(e)}")

def data_transformation(
    data_csv: str,
    output_csv: str,
    time_col: str = 'start_time',
    windows: list[int] = [12, 24],
    cols_to_enrich: list[str] = None,
    shift: int = 0,
) -> pd.DataFrame:
    # 1. load
    df = pd.read_csv(data_csv)

    # 2. decide which columns to enrich
    if cols_to_enrich is None:
        cols_to_enrich = [
            c for c in df.select_dtypes(include='number').columns
            if c != time_col
        ]

    # 3. restrict to time_col + your cols, and apply shift to them
    keep = [time_col] + cols_to_enrich
    df_base = df[keep].copy()
    if shift:
        for col in cols_to_enrich:
            df_base[col] = df_base[col].shift(shift)

    # 4. build metrics for each enriched column
    all_metrics: dict[str, pd.Series] = {}
    for col in cols_to_enrich:
        s = df_base[col]
        all_metrics[f'formula.pct_change({col})']         = formula.pct_change(s)
        all_metrics[f'formula.signed_log1p({col})']       = formula.signed_log1p(s)
        all_metrics[f'formula.log_returns({col})']        = formula.log_returns(s)
        for w in range(1, 4):
            all_metrics[f'formula.diff_n({col},{w})']     = formula.diff_n(s, w)
            all_metrics[f'formula.log_diff_n({col},{w})'] = formula.log_diff_n(s, w)
        for w in windows:
            all_metrics[f'formula.rolling_mean({col},{w})']               = formula.rolling_mean(s, w)
            all_metrics[f'formula.rolling_std({col},{w})']                = formula.rolling_std(s, w)
            all_metrics[f'formula.rolling_min({col},{w})']                = formula.rolling_min(s, w)
            all_metrics[f'formula.rolling_max({col},{w})']                = formula.rolling_max(s, w)
            all_metrics[f'formula.rolling_sum({col},{w})']                = formula.rolling_sum(s, w)
            all_metrics[f'formula.rolling_range({col},{w})']              = formula.rolling_range(s, w)
            all_metrics[f'formula.rolling_cvs({col},{w})']                = formula.rolling_cvs(s, w)
            all_metrics[f'formula.rolling_var({col},{w})']                = formula.rolling_var(s, w)
            all_metrics[f'formula.rolling_skew({col},{w})']               = formula.rolling_skew(s, w)
            all_metrics[f'formula.rolling_kurt({col},{w})']               = formula.rolling_kurt(s, w)
            all_metrics[f'formula.rolling_moment({col},{w},5)']           = formula.rolling_moment(s, w, 5)
            all_metrics[f'formula.rolling_moment({col},{w},6)']           = formula.rolling_moment(s, w, 6)
            all_metrics[f'formula.rolling_zscore({col},{w})']             = formula.rolling_zscore(s, w)
            all_metrics[f'formula.rolling_zscore_mean({col},{w})']        = formula.rolling_zscore_mean(s, w)
            all_metrics[f'formula.rolling_ema({col},{w})']                = formula.rolling_ema(s, w)
            all_metrics[f'formula.rolling_wma({col},{w})']                = formula.rolling_wma(s, w)
            all_metrics[f'formula.rolling_minmax_normalize({col},{w})']   = formula.rolling_minmax_normalize(s, w)
            all_metrics[f'formula.rolling_mean_normalize({col},{w})']     = formula.rolling_mean_normalize(s, w)
            all_metrics[f'formula.rolling_sigmoid_zscore({col},{w})']     = formula.rolling_sigmoid_zscore(s, w)
            all_metrics[f'formula.rolling_median({col},{w})']             = formula.rolling_median(s, w)
            all_metrics[f'formula.rolling_iqr({col},{w})']                = formula.rolling_iqr(s, w)
            all_metrics[f'formula.rolling_mad({col},{w})']                = formula.rolling_mad(s, w)
            all_metrics[f'formula.rolling_max_drawdown({col},{w})']       = formula.rolling_max_drawdown(s, w)
            all_metrics[f'formula.rolling_trend_slope({col},{w})']        = formula.rolling_trend_slope(s, w)
            all_metrics[f'formula.rolling_entropy({col},{w})']            = formula.rolling_entropy(s, w)
            all_metrics[f'formula.rolling_positive_ratio({col},{w})']     = formula.rolling_positive_ratio(s, w)
            all_metrics[f'formula.rolling_direction_changes({col},{w})']  = formula.rolling_direction_changes(s, w)
            all_metrics[f'formula.rolling_autocorr({col},{w},1)']         = formula.rolling_autocorr(s, w, 1)
            all_metrics[f'formula.rolling_autocorr({col},{w},2)']         = formula.rolling_autocorr(s, w, 2)
            all_metrics[f'formula.rolling_autocorr({col},{w},3)']         = formula.rolling_autocorr(s, w, 3)
            all_metrics[f'formula.rolling_autocorr({col},{w},4)']         = formula.rolling_autocorr(s, w, 4)
            all_metrics[f'formula.rolling_autocorr({col},{w},5)']         = formula.rolling_autocorr(s, w, 5)
            all_metrics[f'formula.rolling_autocorr({col},{w},6)']         = formula.rolling_autocorr(s, w, 6)
            all_metrics[f'formula.rolling_autocorr({col},{w},12)']        = formula.rolling_autocorr(s, w, 12)
            all_metrics[f'formula.rolling_autocorr({col},{w},24)']        = formula.rolling_autocorr(s, w, 24)
            all_metrics[f'formula.rolling_sharpe_like({col},{w})']        = formula.rolling_sharpe_like(s, w)
            all_metrics[f'formula.rolling_zscore_jump({col},{w})']        = formula.rolling_zscore_jump(s, w)
            all_metrics[f'formula.rolling_volatility_adjusted_return({col},{w})'] = formula.rolling_volatility_adjusted_return(s, w)
            all_metrics[f'formula.rolling_slope_acceleration({col},{w})'] = formula.rolling_slope_acceleration(s, w)

    # 5. assemble, drop warm‑up, write
    df_metrics = pd.DataFrame(all_metrics, index=df_base.index)
    warmup = max(max(windows), shift or 0)
    df_enriched = pd.concat([df_base, df_metrics], axis=1).iloc[warmup:].reset_index(drop=True)
    df_enriched.to_csv(output_csv, index=False)
    return df_enriched