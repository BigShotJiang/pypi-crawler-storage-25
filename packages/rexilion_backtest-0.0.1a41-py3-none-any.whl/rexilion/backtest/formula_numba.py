# -*- coding: utf-8 -*-
import numpy as np
from numba import njit, prange
from math import isnan, sqrt, log, atan

# ──────────────────────────────────────────────────────────────────────────────
# Helpers (Numba-friendly)
# ──────────────────────────────────────────────────────────────────────────────

@njit(cache=False, nogil=True)   # cache=False to force rebuild
def _as_f64(a):
    b = np.asarray(a, np.float64)   # cast
    return np.ascontiguousarray(b)  # then contiguous

@njit(cache=True, nogil=True)
def _isfinite(x):
    return np.isfinite(x)

# ──────────────────────────────────────────────────────────────────────────────
# Diff helpers
# ──────────────────────────────────────────────────────────────────────────────

@njit(cache=True, nogil=True)
def diff(arr, periods=1):
    a = _as_f64(arr)
    if periods < 1:
        raise ValueError("`periods` must be a positive integer")
    n = a.size
    out = np.empty(n, np.float64)
    for i in range(min(periods, n)):
        out[i] = np.nan
    for i in range(periods, n):
        out[i] = a[i] - a[i - periods]
    return out

@njit(cache=True, nogil=True)
def diff_n(arr, n_diffs=1) -> np.ndarray:
    d = _as_f64(arr)
    for _ in range(n_diffs):
        d = diff(d, 1)
    return d

# ──────────────────────────────────────────────────────────────────────────────
# Rolling aggregates (Numba)
# ──────────────────────────────────────────────────────────────────────────────

@njit(cache=True, nogil=True)
def rolling_sum(x: np.ndarray, window: int, min_periods: int = -1, fill_value: float = np.nan) -> np.ndarray:
    x = _as_f64(x)
    n = x.size
    if window < 1:
        raise ValueError("`window` must be an integer ≥ 1")
    if min_periods == -1:
        min_periods = window
    if min_periods < 1:
        raise ValueError("`min_periods` must be an integer ≥ 1")

    out = np.empty(n, np.float64)
    # maintain rolling sum and count of finite values
    roll_sum = 0.0
    roll_cnt = 0

    for i in range(n):
        xi = x[i]
        if _isfinite(xi):
            roll_sum += xi
            roll_cnt += 1
        if i >= window:
            x_old = x[i - window]
            if _isfinite(x_old):
                roll_sum -= x_old
                roll_cnt -= 1

        if i >= window - 1:
            out[i] = roll_sum if roll_cnt >= min_periods else fill_value
        else:
            out[i] = fill_value
    return out

@njit(cache=True, nogil=True)
def rolling_mean(array, rolling_window):
    a = _as_f64(array)
    n = a.size
    out = np.empty(n, np.float64)
    if rolling_window < 1:
        for i in range(n):
            out[i] = np.nan
        return out

    s = 0.0
    cnt = 0
    for i in range(n):
        ai = a[i]
        if np.isfinite(ai):
            s += ai
            cnt += 1
        if i >= rolling_window:
            ao = a[i - rolling_window]
            if np.isfinite(ao):
                s -= ao
                cnt -= 1
        if i >= rolling_window - 1:
            out[i] = (s / cnt) if cnt > 0 else np.nan
        else:
            out[i] = np.nan
    return out

@njit(cache=True, nogil=True)
def rolling_ema(data, window):
    d = _as_f64(data)
    n = d.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if window < 1 or window > n:
        return out

    alpha = 2.0 / (window + 1.0)
    s = 0.0
    count = 0
    seeded = False
    prev = np.nan

    for i in range(n):
        v = d[i]
        if not np.isfinite(v):
            s = 0.0
            count = 0
            seeded = False
            prev = np.nan
            continue

        if not seeded:
            s += v
            count += 1
            if count == window:
                prev = s / window
                out[i] = prev
                seeded = True
        else:
            prev = (v - prev) * alpha + prev
            out[i] = prev

    return out

@njit(cache=True, nogil=True)
def rolling_wma(data, window):
    d = _as_f64(data)
    n = d.size
    out = np.empty(n, np.float64)
    if window > n:
        for i in range(n):
            out[i] = np.nan
        return out
    weight_sum = window * (window + 1) * 0.5
    for i in range(window - 1):
        out[i] = np.nan
    for i in range(window - 1, n):
        s = 0.0
        w = 1
        # weights: 1..window aligned to most recent being weight=window
        for k in range(i - window + 1, i + 1):
            s += d[k] * w
            w += 1
        out[i] = s / weight_sum
    return out

@njit(cache=True, nogil=True)
def rolling_wilder_mean(data, window):
    """
    Wilder moving average / RMA.

    First valid value:
        mean of first `window` consecutive finite values.

    After that:
        out[i] = (out[i-1] * (window - 1) + data[i]) / window

    NaN/inf behavior:
        If NaN/inf appears, output becomes NaN and the calculation resets.
        It then waits for a new full window of consecutive finite values.
    """
    d = _as_f64(data)
    n = d.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if n == 0 or window < 1 or window > n:
        return out

    count = 0
    s = 0.0
    prev = np.nan
    seeded = False

    for i in range(n):
        v = d[i]

        if not np.isfinite(v):
            count = 0
            s = 0.0
            prev = np.nan
            seeded = False
            out[i] = np.nan
            continue

        if not seeded:
            s += v
            count += 1

            if count == window:
                prev = s / window
                out[i] = prev
                seeded = True
            else:
                out[i] = np.nan

        else:
            prev = ((prev * (window - 1.0)) + v) / window
            out[i] = prev

    return out

@njit(cache=True, nogil=True)
def rolling_min(array, rolling_window):
    a = _as_f64(array)
    n = a.size
    out = np.empty(n, np.float64)
    if rolling_window > n:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(rolling_window - 1):
        out[i] = np.nan
    for i in range(rolling_window - 1, n):
        m = a[i - rolling_window + 1]
        for j in range(i - rolling_window + 2, i + 1):
            if a[j] < m:
                m = a[j]
        out[i] = m
    return out

@njit(cache=True, nogil=True)
def rolling_max(array, rolling_window):
    a = _as_f64(array)
    n = a.size
    out = np.empty(n, np.float64)
    if rolling_window > n:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(rolling_window - 1):
        out[i] = np.nan
    for i in range(rolling_window - 1, n):
        m = a[i - rolling_window + 1]
        for j in range(i - rolling_window + 2, i + 1):
            if a[j] > m:
                m = a[j]
        out[i] = m
    return out

@njit(cache=True, nogil=True)
def rolling_std(array, window):
    a = _as_f64(array)
    n = a.size
    out = np.empty(n, np.float64)
    if window > n:
        for i in range(n):
            out[i] = np.nan
        return out

    s = 0.0
    ss = 0.0
    cnt = 0

    for i in range(n):
        ai = a[i]
        if np.isfinite(ai):
            s += ai
            ss += ai * ai
            cnt += 1

        if i >= window:
            ao = a[i - window]
            if np.isfinite(ao):
                s -= ao
                ss -= ao * ao
                cnt -= 1

        if i >= window - 1:
            if cnt > 1:
                var = (ss - (s * s) / cnt) / (cnt - 1)
                out[i] = sqrt(var) if var > 0.0 else 0.0
            else:
                out[i] = np.nan
        else:
            out[i] = np.nan
    return out

# ──────────────────────────────────────────────────────────────────────────────
# Transforms built on rolling primitives
# ──────────────────────────────────────────────────────────────────────────────

@njit(cache=True, nogil=True)
def rolling_mean_normalize(array, rolling_window):
    a = _as_f64(array)
    sma = rolling_mean(a, rolling_window)
    mn = rolling_min(a, rolling_window)
    mx = rolling_max(a, rolling_window)
    n = a.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = (a[i] - sma[i]) / (mx[i] - mn[i] + 1e-9)
    return out

@njit(cache=True, nogil=True)
def rolling_zscore_mean(array, rolling_window):
    a = _as_f64(array)
    sma = rolling_mean(a, rolling_window)
    stddev = rolling_std(a, rolling_window)
    n = a.size
    z = np.empty(n, np.float64)
    for i in range(n):
        z[i] = (a[i] - sma[i]) / (stddev[i] + 1e-9)
    # remove local mean
    zm = rolling_mean(z, rolling_window)
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = z[i] - zm[i]
    return out

@njit(cache=True, nogil=True)
def rolling_zscore(array, rolling_window):
    a = _as_f64(array)
    sma = rolling_mean(a, rolling_window)
    stddev = rolling_std(a, rolling_window)
    n = a.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = (a[i] - sma[i]) / (stddev[i] + 1e-9)
    return out

@njit(cache=True, nogil=True)
def rolling_sigmoid_zscore(arr: np.ndarray, window: int) -> np.ndarray:
    z = rolling_zscore(arr, window)
    n = z.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = np.tanh(z[i] / 2.0)
    return out

@njit(cache=True, nogil=True)
def rolling_minmax_original(array, rolling_window):
    a = _as_f64(array)
    mn = rolling_min(a, rolling_window)
    mx = rolling_max(a, rolling_window)
    n = a.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = (a[i] - mn[i]) / (mx[i] - mn[i] + 1e-9)
    return out

@njit(cache=True, nogil=True)
def rolling_minmax_normalize(array, rolling_window):
    a = _as_f64(array)
    mn = rolling_min(a, rolling_window)
    mx = rolling_max(a, rolling_window)
    n = a.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = 2.0 * (a[i] - mn[i]) / (mx[i] - mn[i] + 1e-9) - 1.0
    return out

@njit(cache=True, nogil=True)
def rolling_skew(arr, window):
    x = _as_f64(arr)
    n = x.size
    out = np.empty(n, np.float64)
    if n < window:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(window - 1):
        out[i] = np.nan
    for i in range(window - 1, n):
        # compute sample skewness over window
        m = 0.0
        for k in range(i - window + 1, i + 1):
            m += x[k]
        m /= window
        s2 = 0.0
        s3 = 0.0
        for k in range(i - window + 1, i + 1):
            d = x[k] - m
            s2 += d * d
            s3 += d * d * d
        if window > 2 and s2 > 0.0:
            s2 /= (window - 1)
            std = sqrt(s2)
            out[i] = (window / ((window - 1.0) * (window - 2.0))) * (s3 / (std * std * std))
        else:
            out[i] = np.nan
    return out

@njit(cache=True, nogil=True)
def rolling_var(arr, window):
    x = _as_f64(arr)
    n = x.size
    out = np.empty(n, np.float64)
    if n < window:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(window - 1):
        out[i] = np.nan
    for i in range(window - 1, n):
        m = 0.0
        for k in range(i - window + 1, i + 1):
            m += x[k]
        m /= window
        v = 0.0
        for k in range(i - window + 1, i + 1):
            d = x[k] - m
            v += d * d
        out[i] = v / (window - 1.0) if window > 1 else np.nan
    return out

@njit(cache=True, nogil=True)
def rolling_kurt(arr, window):
    x = _as_f64(arr)
    n = x.size
    out = np.empty(n, np.float64)
    if n < window:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(window - 1):
        out[i] = np.nan
    for i in range(window - 1, n):
        m = 0.0
        for k in range(i - window + 1, i + 1):
            m += x[k]
        m /= window
        s = 0.0
        m4 = 0.0
        for k in range(i - window + 1, i + 1):
            d = x[k] - m
            s += d * d
            m4 += d * d * d * d
        s /= window
        if s > 0.0:
            m4 /= window
            out[i] = m4 / (s * s) - 3.0
        else:
            out[i] = np.nan
    return out

@njit(cache=True, nogil=True)
def rolling_tanh_estimator(arr, rolling_window):
    a = _as_f64(arr)
    sma = rolling_mean(a, rolling_window)
    std = rolling_std(a, rolling_window)
    n = a.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = np.tanh(0.01 * (a[i] - sma[i]) / (std[i] + 1e-9))
    return out

@njit(cache=True, nogil=True)
def sigmoid(arr):
    a = _as_f64(arr)
    n = a.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = 2.0 * (1.0 / (1.0 + np.exp(-a[i]))) - 1.0
    return out

@njit(cache=True, nogil=True)
def rolling_softmax(arr, window):
    x = _as_f64(arr)
    n = x.size
    out = np.empty(n, np.float64)
    if window > n:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(window - 1):
        out[i] = np.nan
    for i in range(window - 1, n):
        # softmax over the window, return value for last element
        m = x[i - window + 1]
        for k in range(i - window + 2, i + 1):
            if x[k] > m:
                m = x[k]
        s = 0.0
        last_exp = 0.0
        for k in range(i - window + 1, i + 1):
            e = np.exp(x[k] - m)
            s += e
            if k == i:
                last_exp = e
        sm_last = last_exp / s
        out[i] = 2.0 * sm_last - 1.0
    return out

@njit(cache=True, nogil=True)
def rolling_l1_normalization(arr, rolling_window):
    x = _as_f64(arr)
    n = x.size
    abs_arr = np.empty(n, np.float64)
    for i in range(n):
        abs_arr[i] = abs(x[i])
    abs_sum = rolling_sum(abs_arr, rolling_window, -1, np.nan)
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = 2.0 * (x[i] / (abs_sum[i] + 1e-9)) - 1.0
    return out

@njit(cache=True, nogil=True)
def rolling_median(array, rolling_window):
    a = _as_f64(array)
    n = a.size
    out = np.empty(n, np.float64)
    if rolling_window > n:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(rolling_window - 1):
        out[i] = np.nan
    buf = np.empty(rolling_window, np.float64)
    for i in range(rolling_window - 1, n):
        # copy & sort
        for k in range(rolling_window):
            buf[k] = a[i - rolling_window + 1 + k]
        buf.sort()
        if rolling_window % 2 == 1:
            out[i] = buf[rolling_window // 2]
        else:
            j = rolling_window // 2
            out[i] = 0.5 * (buf[j - 1] + buf[j])
    return out

@njit(cache=True, nogil=True)
def signed_log1p(x: np.ndarray) -> np.ndarray:
    a = _as_f64(x)
    n = a.size
    out = np.empty(n, np.float64)
    for i in range(n):
        v = a[i]
        if v >= 0.0:
            out[i] = log(1.0 + v)
        else:
            out[i] = -log(1.0 + (-v))
    return out

@njit(cache=True, nogil=True)
def rolling_cvs(array: np.ndarray, rolling_window: int) -> np.ndarray:
    a = _as_f64(array)
    std = rolling_std(a, rolling_window)
    mean = rolling_mean(a, rolling_window)
    n = a.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = std[i] / (mean[i] + 1e-9)
    return out

@njit(cache=True, nogil=True)
def rolling_range(array, rolling_window):
    a = _as_f64(array)
    return rolling_max(a, rolling_window) - rolling_min(a, rolling_window)

@njit(cache=True, nogil=True)
def rolling_moment(array: np.ndarray, rolling_window: int, moment: int) -> np.ndarray:
    a = _as_f64(array)
    mu = rolling_mean(a, rolling_window)
    sigma = rolling_std(a, rolling_window)
    n = a.size
    out = np.empty(n, np.float64)
    # compute E[(x-mu)^moment] / sigma^moment
    for i in range(n):
        # local mean over window i handled via separate pass to keep speed:
        # we just reuse mu and compute numerator with an extra inner loop
        if i < rolling_window - 1:
            out[i] = np.nan
        else:
            s = 0.0
            for k in range(i - rolling_window + 1, i + 1):
                d = a[k] - mu[i]
                # power
                p = 1.0
                for _ in range(moment):
                    p *= d
                s += p
            num = s / rolling_window
            denom = 1.0
            if moment > 0:
                pow_sigma = sigma[i]
                for _ in range(moment - 1):
                    pow_sigma *= sigma[i]
                denom = pow_sigma + 1e-9
            out[i] = num / denom
    return out

@njit(cache=True, nogil=True)
def pct_change(arr):
    a = _as_f64(arr)
    n = a.size
    out = np.empty(n, np.float64)
    out[0] = np.nan
    for i in range(1, n):
        denom = a[i - 1]
        out[i] = (a[i] - denom) / (denom + 1e-9)
    return out

@njit(cache=True, nogil=True)
def log_diff_n(arr, n_diffs=1) -> np.ndarray:
    d = diff_n(arr, n_diffs)
    return signed_log1p(d)

@njit(cache=True, nogil=True)
def rolling_iqr(array: np.ndarray, rolling_window: int) -> np.ndarray:
    a = _as_f64(array)
    n = a.size
    out = np.empty(n, np.float64)
    if rolling_window > n:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(rolling_window - 1):
        out[i] = np.nan
    buf = np.empty(rolling_window, np.float64)
    for i in range(rolling_window - 1, n):
        for k in range(rolling_window):
            buf[k] = a[i - rolling_window + 1 + k]
        buf.sort()
        # 25th and 75th percentiles (simple nearest-rank interpolation)
        q25_idx = 0.25 * (rolling_window - 1)
        q75_idx = 0.75 * (rolling_window - 1)
        lo = int(q25_idx)
        hi = int(q25_idx + 1.0)
        w = q25_idx - lo
        q25 = buf[lo] * (1.0 - w) + buf[hi] * w if hi < rolling_window else buf[lo]

        lo2 = int(q75_idx)
        hi2 = int(q75_idx + 1.0)
        w2 = q75_idx - lo2
        q75 = buf[lo2] * (1.0 - w2) + buf[hi2] * w2 if hi2 < rolling_window else buf[lo2]

        out[i] = q75 - q25
    return out

@njit(cache=True, nogil=True)
def rolling_mad(array: np.ndarray, rolling_window: int) -> np.ndarray:
    a = _as_f64(array)
    n = a.size
    out = np.empty(n, np.float64)
    if rolling_window > n:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(rolling_window - 1):
        out[i] = np.nan
    win = np.empty(rolling_window, np.float64)
    dev = np.empty(rolling_window, np.float64)
    for i in range(rolling_window - 1, n):
        # median
        for k in range(rolling_window):
            win[k] = a[i - rolling_window + 1 + k]
        win.sort()
        med = win[rolling_window // 2] if (rolling_window % 2 == 1) else 0.5 * (win[rolling_window // 2 - 1] + win[rolling_window // 2])
        # deviations
        for k in range(rolling_window):
            dev[k] = abs(a[i - rolling_window + 1 + k] - med)
        dev.sort()
        mad = dev[rolling_window // 2] if (rolling_window % 2 == 1) else 0.5 * (dev[rolling_window // 2 - 1] + dev[rolling_window // 2])
        out[i] = mad
    return out

@njit(cache=True, nogil=True)
def rolling_robust_z(array, rolling_window):
    x = _as_f64(array)
    med = rolling_median(x, rolling_window)
    mad = rolling_mad(x, rolling_window)
    n = x.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = (x[i] - med[i]) / (mad[i] + 1e-9)
    return out

@njit(cache=True, nogil=True)
def rolling_max_drawdown(array, rolling_window):
    x = _as_f64(array)
    rm = rolling_max(x, rolling_window)
    n = x.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = (rm[i] - x[i]) / (rm[i] + 1e-9)
    return out

@njit(cache=True, nogil=True)
def rolling_trend_slope(array: np.ndarray, window: int) -> np.ndarray:
    y = _as_f64(array)
    n = y.size
    out = np.empty(n, np.float64)
    if window > n:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(window - 1):
        out[i] = np.nan
    # precompute x demean denom for 0..window-1
    x_mean = (window - 1) * 0.5
    denom = 0.0
    for i in range(window):
        d = i - x_mean
        denom += d * d
    for t in range(window - 1, n):
        # compute y_mean
        y_mean = 0.0
        for k in range(t - window + 1, t + 1):
            y_mean += y[k]
        y_mean /= window
        # slope = sum( (x-xbar)*(y-ybar) ) / sum((x-xbar)^2)
        num = 0.0
        idx = 0
        for k in range(t - window + 1, t + 1):
            num += (idx - x_mean) * (y[k] - y_mean)
            idx += 1
        out[t] = num / denom
    return out

@njit(cache=True, nogil=True)
def rolling_entropy(array, window):
    a = _as_f64(array)
    n = a.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = np.nan

    if window < 2 or window > n:
        return out

    bins = int(sqrt(window))
    if bins < 2:
        bins = 2
    elif bins > 16:
        bins = 16

    counts = np.empty(bins, np.int64)

    for i in range(window - 1, n):
        start = i - window + 1
        first = a[start]
        if not np.isfinite(first):
            continue

        mn = first
        mx = first
        valid = True

        for k in range(start + 1, i + 1):
            v = a[k]
            if not np.isfinite(v):
                valid = False
                break
            if v < mn:
                mn = v
            if v > mx:
                mx = v

        if not valid:
            continue

        rng = mx - mn
        if rng <= 0.0:
            out[i] = 0.0
            continue

        for b in range(bins):
            counts[b] = 0

        scale = bins / rng
        for k in range(start, i + 1):
            idx = int((a[k] - mn) * scale)
            if idx < 0:
                idx = 0
            elif idx >= bins:
                idx = bins - 1
            counts[idx] += 1

        ent = 0.0
        inv_window = 1.0 / window
        for b in range(bins):
            c = counts[b]
            if c > 0:
                p = c * inv_window
                ent -= p * log(p)

        out[i] = ent
    return out

@njit(cache=True, nogil=True)
def rolling_positive_ratio(array, rolling_window):
    x = _as_f64(array)
    n = x.size
    # 1-lag diff
    d = np.empty(n, np.float64)
    d[0] = np.nan
    for i in range(1, n):
        d[i] = x[i] - x[i - 1]
    # positive mask as float
    pos = np.empty(n, np.float64)
    pos[0] = np.nan
    for i in range(1, n):
        pos[i] = 1.0 if (not np.isnan(d[i]) and d[i] > 0.0) else 0.0
    return rolling_mean(pos, rolling_window)

@njit(cache=True, nogil=True)
def count_direction_changes(x):
    a = _as_f64(x)
    n = a.size
    if n < 3:
        return 0.0
    # dx = diff(sign(diff(x)))
    flips = 0
    prev = a[1] - a[0]
    for i in range(2, n):
        cur = a[i] - a[i - 1]
        s_prev = 0.0
        if prev > 0: s_prev = 1.0
        elif prev < 0: s_prev = -1.0
        s_cur = 0.0
        if cur > 0: s_cur = 1.0
        elif cur < 0: s_cur = -1.0
        if s_cur != s_prev and s_prev != 0.0 and s_cur != 0.0:
            flips += 1
        prev = cur
    return float(flips)

@njit(cache=True, nogil=True)
def rolling_direction_changes(array, window):
    a = _as_f64(array)
    n = a.size
    out = np.empty(n, np.float64)
    if window > n:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(window - 1):
        out[i] = np.nan
    buf = np.empty(window, np.float64)
    for i in range(window - 1, n):
        for k in range(window):
            buf[k] = a[i - window + 1 + k]
        out[i] = count_direction_changes(buf)
    return out

@njit(cache=True, nogil=True)
def rolling_autocorr(array, window, lag=1):
    x = _as_f64(array)
    n = x.size
    out = np.empty(n, np.float64)
    if window > n or lag < 1 or lag >= window:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(window - 1):
        out[i] = np.nan
    for t in range(window - 1, n):
        # window [t-window+1 .. t]
        # y1: first window-lag, y2: last window-lag, both length window-lag
        m1 = 0.0
        m2 = 0.0
        L = window - lag
        for k in range(L):
            y1 = x[t - window + 1 + k]
            y2 = x[t - window + 1 + lag + k]
            m1 += y1
            m2 += y2
        m1 /= L
        m2 /= L
        num = 0.0
        s1 = 0.0
        s2 = 0.0
        for k in range(L):
            y1 = x[t - window + 1 + k] - m1
            y2 = x[t - window + 1 + lag + k] - m2
            num += y1 * y2
            s1 += y1 * y1
            s2 += y2 * y2
        den = sqrt(s1 * s2)
        out[t] = num / den if den != 0.0 else np.nan
    return out

@njit(cache=True, nogil=True)
def rolling_sharpe_like(array, rolling_window):
    x = _as_f64(array)
    mu = rolling_mean(x, rolling_window)
    sigma = rolling_std(x, rolling_window)
    n = x.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = (mu[i] / (sigma[i] + 1e-9)) * np.sqrt(365.0)
    return out

@njit(cache=True, nogil=True)
def rolling_zscore_jump(array, window):
    x = _as_f64(array)
    n = x.size
    out = np.empty(n, np.float64)
    if window > n:
        for i in range(n):
            out[i] = np.nan
        return out
    for i in range(window - 1):
        out[i] = np.nan
    for i in range(window - 1, n):
        # stats for this window
        m = 0.0
        for k in range(i - window + 1, i + 1):
            m += x[k]
        m /= window
        s2 = 0.0
        for k in range(i - window + 1, i + 1):
            d = x[k] - m
            s2 += d * d
        s = sqrt(s2 / window)
        cnt = 0.0
        for k in range(i - window + 1, i + 1):
            z = abs((x[k] - m) / (s + 1e-9))
            if z > 2.0:
                cnt += 1.0
        out[i] = cnt
    return out

@njit(cache=True, nogil=True)
def log_returns(arr) -> np.ndarray:
    a = _as_f64(arr)
    n = a.size
    out = np.empty(n, np.float64)
    out[0] = np.nan
    for i in range(1, n):
        prev = a[i - 1]
        # Guard against non-positive or zero prev (rare if prices, but safe)
        r = a[i] / (prev + 1e-12)
        if r <= 0.0 or np.isnan(r):
            out[i] = np.nan
        else:
            out[i] = np.log(r)
    return out

@njit(cache=True, nogil=True)
def rolling_trend_angle(arr: np.ndarray, window: int, to_degrees: bool = False) -> np.ndarray:
    slopes = rolling_trend_slope(arr, window)
    n = slopes.size
    out = np.empty(n, np.float64)
    k = 180.0 / np.pi
    for i in range(n):
        s = slopes[i]
        if np.isnan(s):
            out[i] = np.nan
        else:
            ang = np.arctan(s)
            out[i] = ang * k if to_degrees else ang
    return out


@njit(cache=True, nogil=True)
def rolling_volatility_adjusted_return(arr: np.ndarray, window: int) -> np.ndarray:
    ret = pct_change(arr)
    std = rolling_std(ret, window)
    n = ret.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = ret[i] / (std[i] + 1e-9)
    return out

@njit(cache=True, nogil=True)
def rolling_slope_acceleration(array: np.ndarray, window: int) -> np.ndarray:
    slopes = rolling_trend_slope(array, window)
    n = slopes.size
    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = np.nan
    for i in range(window, n):
        prev = slopes[i - 1]
        cur = slopes[i]
        out[i] = cur - prev
    return out

@njit(cache=True, nogil=True)
def rolling_rsi_wilder(x, window):
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if n == 0 or window < 1:
        return out

    gain = np.empty(n, np.float64)
    loss = np.empty(n, np.float64)

    gain[0] = np.nan
    loss[0] = np.nan

    for i in range(1, n):
        xi = x[i]
        xp = x[i - 1]

        if not np.isfinite(xi) or not np.isfinite(xp):
            gain[i] = np.nan
            loss[i] = np.nan
        else:
            d = xi - xp

            if d > 0.0:
                gain[i] = d
                loss[i] = 0.0
            elif d < 0.0:
                gain[i] = 0.0
                loss[i] = -d
            else:
                gain[i] = 0.0
                loss[i] = 0.0

    avg_gain = rolling_wilder_mean(gain, window)
    avg_loss = rolling_wilder_mean(loss, window)

    for i in range(n):
        g = avg_gain[i]
        l = avg_loss[i]

        if not np.isfinite(g) or not np.isfinite(l):
            out[i] = np.nan
        elif g == 0.0 and l == 0.0:
            out[i] = 50.0
        elif l == 0.0:
            out[i] = 100.0
        elif g == 0.0:
            out[i] = 0.0
        else:
            rs = g / l
            out[i] = 100.0 - (100.0 / (1.0 + rs))

    return out

@njit(cache=True, nogil=True)
def rolling_rsi_sma(x: np.ndarray, window: int) -> np.ndarray:
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if n == 0 or window < 1:
        return out

    delta = np.empty(n, np.float64)
    gain = np.empty(n, np.float64)
    loss = np.empty(n, np.float64)

    delta[0] = np.nan
    gain[0] = np.nan
    loss[0] = np.nan

    for i in range(1, n):
        xi = x[i]
        x_prev = x[i - 1]

        if not np.isfinite(xi) or not np.isfinite(x_prev):
            delta[i] = np.nan
            gain[i] = np.nan
            loss[i] = np.nan
        else:
            di = xi - x_prev
            delta[i] = di

            if di > 0.0:
                gain[i] = di
                loss[i] = 0.0
            elif di < 0.0:
                gain[i] = 0.0
                loss[i] = -di
            else:
                gain[i] = 0.0
                loss[i] = 0.0

    gain_sum = rolling_sum(gain, window, window, np.nan)
    loss_sum = rolling_sum(loss, window, window, np.nan)

    for i in range(n):
        g = gain_sum[i]
        l = loss_sum[i]

        if not np.isfinite(g) or not np.isfinite(l):
            out[i] = np.nan
        elif g == 0.0 and l == 0.0:
            out[i] = 50.0
        elif l == 0.0:
            out[i] = 100.0
        else:
            rs = g / l
            out[i] = 100.0 - (100.0 / (1.0 + rs))

    return out

@njit(cache=True, nogil=True)
def rolling_regression_fitted(x: np.ndarray, window: int) -> np.ndarray:
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if n == 0 or window < 2 or window > n:
        return out

    x_mean = (window - 1) * 0.5
    denom = 0.0
    for j in range(window):
        dx = j - x_mean
        denom += dx * dx

    if denom <= 0.0:
        return out

    for i in range(window - 1, n):
        start = i - window + 1
        y_sum = 0.0
        valid = True

        for j in range(window):
            y = x[start + j]
            if not np.isfinite(y):
                valid = False
                break
            y_sum += y

        if not valid:
            continue

        y_mean = y_sum / window
        num = 0.0
        for j in range(window):
            num += (j - x_mean) * (x[start + j] - y_mean)

        slope = num / denom
        intercept = y_mean - slope * x_mean
        out[i] = intercept + slope * (window - 1)

    return out

@njit(cache=True, nogil=True)
def rolling_regression_residual(x: np.ndarray, window: int) -> np.ndarray:
    fitted = rolling_regression_fitted(x, window)
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        xi = x[i]
        fi = fitted[i]
        if not np.isfinite(xi) or not np.isfinite(fi):
            out[i] = np.nan
        else:
            out[i] = xi - fi

    return out

@njit(cache=True, nogil=True)
def rolling_regression_r2(x: np.ndarray, window: int) -> np.ndarray:
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if n == 0 or window < 2 or window > n:
        return out

    x_mean = (window - 1) * 0.5
    denom = 0.0
    for j in range(window):
        dx = j - x_mean
        denom += dx * dx

    if denom <= 0.0:
        return out

    for i in range(window - 1, n):
        start = i - window + 1
        y_sum = 0.0
        valid = True

        for j in range(window):
            y = x[start + j]
            if not np.isfinite(y):
                valid = False
                break
            y_sum += y

        if not valid:
            continue

        y_mean = y_sum / window
        num = 0.0
        ss_tot = 0.0
        for j in range(window):
            dy = x[start + j] - y_mean
            num += (j - x_mean) * dy
            ss_tot += dy * dy

        if ss_tot <= 0.0:
            continue

        slope = num / denom
        intercept = y_mean - slope * x_mean
        ss_res = 0.0
        for j in range(window):
            err = x[start + j] - (intercept + slope * j)
            ss_res += err * err

        out[i] = 1.0 - (ss_res / ss_tot)

    return out

@njit(cache=True, nogil=True)
def rolling_slope_tstat(x: np.ndarray, window: int) -> np.ndarray:
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if n == 0 or window < 3 or window > n:
        return out

    x_mean = (window - 1) * 0.5
    denom = 0.0
    for j in range(window):
        dx = j - x_mean
        denom += dx * dx

    if denom <= 0.0:
        return out

    for i in range(window - 1, n):
        start = i - window + 1
        y_sum = 0.0
        valid = True

        for j in range(window):
            y = x[start + j]
            if not np.isfinite(y):
                valid = False
                break
            y_sum += y

        if not valid:
            continue

        y_mean = y_sum / window
        num = 0.0
        for j in range(window):
            num += (j - x_mean) * (x[start + j] - y_mean)

        slope = num / denom
        intercept = y_mean - slope * x_mean
        ss_res = 0.0
        for j in range(window):
            err = x[start + j] - (intercept + slope * j)
            ss_res += err * err

        sigma2 = ss_res / (window - 2)
        if sigma2 <= 0.0:
            continue

        slope_se = np.sqrt(sigma2 / denom)
        if slope_se > 0.0:
            out[i] = slope / slope_se

    return out


# ──────────────────────────────────────────────────────────────────────────────
# Shape / surprise transforms
# These are intentionally raw transforms; z-score them downstream if needed.
# ──────────────────────────────────────────────────────────────────────────────

@njit(cache=True, nogil=True)
def rolling_path_efficiency(array, rolling_window):
    x = _as_f64(array)
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if rolling_window < 2 or rolling_window > n:
        return out

    for i in range(rolling_window - 1, n):
        start = i - rolling_window + 1
        valid = True
        path = 0.0

        prev = x[start]
        if not np.isfinite(prev):
            valid = False

        if valid:
            for k in range(start + 1, i + 1):
                cur = x[k]
                if not np.isfinite(cur):
                    valid = False
                    break
                path += abs(cur - prev)
                prev = cur

        if valid:
            direct = abs(x[i] - x[start])
            out[i] = direct / (path + 1e-9) if path > 0.0 else 0.0

    return out


@njit(cache=True, nogil=True)
def rolling_tail_surprise(array, rolling_window):
    x = _as_f64(array)
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if rolling_window < 2 or rolling_window > n:
        return out

    for i in range(rolling_window - 1, n):
        start = i - rolling_window + 1
        v = x[i]
        if not np.isfinite(v):
            continue

        less = 0.0
        greater = 0.0
        equal = 0.0
        valid = True

        for k in range(start, i + 1):
            y = x[k]
            if not np.isfinite(y):
                valid = False
                break
            if y < v:
                less += 1.0
            elif y > v:
                greater += 1.0
            else:
                equal += 1.0

        if not valid:
            continue

        rank_mid = (less + 0.5 * equal) / rolling_window
        if rank_mid > 0.5:
            upper_tail = (greater + 0.5 * equal + 0.5) / (rolling_window + 1.0)
            out[i] = -log(upper_tail)
        elif rank_mid < 0.5:
            lower_tail = (less + 0.5 * equal + 0.5) / (rolling_window + 1.0)
            out[i] = log(lower_tail)
        else:
            out[i] = 0.0

    return out


@njit(cache=True, nogil=True)
def rolling_pattern_discord(array, rolling_window):
    x = _as_f64(array)
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if rolling_window < 4 or rolling_window > n:
        return out

    subseq_len = rolling_window // 4
    if subseq_len < 3:
        subseq_len = 3
    max_subseq = rolling_window // 2
    if subseq_len > max_subseq:
        subseq_len = max_subseq
    if subseq_len < 2:
        return out

    for i in range(rolling_window - 1, n):
        start = i - rolling_window + 1
        valid = True
        for k in range(start, i + 1):
            if not np.isfinite(x[k]):
                valid = False
                break
        if not valid:
            continue

        latest_start = i - subseq_len + 1
        latest_mean = 0.0
        for k in range(subseq_len):
            latest_mean += x[latest_start + k]
        latest_mean /= subseq_len

        latest_var = 0.0
        for k in range(subseq_len):
            d = x[latest_start + k] - latest_mean
            latest_var += d * d
        latest_std = sqrt(latest_var / subseq_len)

        candidate_last = latest_start - subseq_len
        if candidate_last < start:
            continue

        best = np.inf
        for cand_start in range(start, candidate_last + 1):
            cand_mean = 0.0
            for k in range(subseq_len):
                cand_mean += x[cand_start + k]
            cand_mean /= subseq_len

            cand_var = 0.0
            for k in range(subseq_len):
                d = x[cand_start + k] - cand_mean
                cand_var += d * d
            cand_std = sqrt(cand_var / subseq_len)

            dist = 0.0
            for k in range(subseq_len):
                if latest_std > 1e-12:
                    a = (x[latest_start + k] - latest_mean) / latest_std
                else:
                    a = 0.0

                if cand_std > 1e-12:
                    b = (x[cand_start + k] - cand_mean) / cand_std
                else:
                    b = 0.0

                d = a - b
                dist += d * d

            dist = sqrt(dist / subseq_len)
            if dist < best:
                best = dist

        if best < np.inf:
            out[i] = best

    return out


@njit(cache=True, nogil=True)
def rolling_permutation_entropy(array, rolling_window):
    x = _as_f64(array)
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if rolling_window < 3 or rolling_window > n:
        return out

    norm = log(6.0)
    for i in range(rolling_window - 1, n):
        start = i - rolling_window + 1
        counts = np.zeros(6, np.float64)
        valid = True
        total = rolling_window - 2

        for k in range(start, i - 1):
            a = x[k]
            b = x[k + 1]
            c = x[k + 2]
            if not np.isfinite(a) or not np.isfinite(b) or not np.isfinite(c):
                valid = False
                break

            if a <= b and b <= c:
                idx = 0
            elif a <= c and c < b:
                idx = 1
            elif b < a and a <= c:
                idx = 2
            elif b <= c and c < a:
                idx = 3
            elif c < a and a <= b:
                idx = 4
            else:
                idx = 5

            counts[idx] += 1.0

        if not valid:
            continue

        ent = 0.0
        for k in range(6):
            if counts[k] > 0.0:
                p = counts[k] / total
                ent -= p * log(p)

        out[i] = ent / norm

    return out


@njit(cache=True, nogil=True)
def rolling_turning_point_pressure(array, rolling_window):
    x = _as_f64(array)
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if rolling_window < 3 or rolling_window > n:
        return out

    for i in range(rolling_window - 1, n):
        start = i - rolling_window + 1
        valid = True
        path = 0.0

        for k in range(start + 1, i + 1):
            if not np.isfinite(x[k]) or not np.isfinite(x[k - 1]):
                valid = False
                break
            path += abs(x[k] - x[k - 1])

        if not valid:
            continue

        pressure = 0.0
        for k in range(start + 1, i):
            prev = x[k - 1]
            cur = x[k]
            nxt = x[k + 1]

            if cur > prev and cur > nxt:
                left = cur - prev
                right = cur - nxt
                amp = left if left < right else right
                pressure -= amp
            elif cur < prev and cur < nxt:
                left = prev - cur
                right = nxt - cur
                amp = left if left < right else right
                pressure += amp

        out[i] = pressure / (path + 1e-9) if path > 0.0 else 0.0

    return out


@njit(cache=True, nogil=True)
def rolling_local_fractal_dimension(array, rolling_window):
    x = _as_f64(array)
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if rolling_window < 2 or rolling_window > n:
        return out

    steps = rolling_window - 1.0
    dx = 1.0 / steps

    for i in range(rolling_window - 1, n):
        start = i - rolling_window + 1
        valid = True
        mn = x[start]
        mx = x[start]

        if not np.isfinite(mn):
            valid = False

        if valid:
            for k in range(start + 1, i + 1):
                v = x[k]
                if not np.isfinite(v):
                    valid = False
                    break
                if v < mn:
                    mn = v
                if v > mx:
                    mx = v

        if not valid:
            continue

        rng = mx - mn
        if rng <= 1e-12:
            out[i] = 1.0
            continue

        length = 0.0
        dmax = 0.0
        y0 = (x[start] - mn) / rng
        prev_y = y0

        for k in range(start + 1, i + 1):
            y = (x[k] - mn) / rng
            dy = y - prev_y
            length += sqrt(dx * dx + dy * dy)
            prev_y = y

            t = (k - start) / steps
            dy0 = y - y0
            d = sqrt(t * t + dy0 * dy0)
            if d > dmax:
                dmax = d

        if length > 0.0 and dmax > 0.0:
            ratio = dmax / length
            out[i] = log(steps) / (log(steps) + log(ratio))

    return out


@njit(cache=True, nogil=True)
def rolling_run_length_imbalance(array, rolling_window):
    x = _as_f64(array)
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if rolling_window < 2 or rolling_window > n:
        return out

    denom = rolling_window - 1.0
    for i in range(rolling_window - 1, n):
        start = i - rolling_window + 1
        valid = True
        up_run = 0
        down_run = 0
        max_up = 0
        max_down = 0

        for k in range(start + 1, i + 1):
            a = x[k - 1]
            b = x[k]
            if not np.isfinite(a) or not np.isfinite(b):
                valid = False
                break

            d = b - a
            if d > 0.0:
                up_run += 1
                down_run = 0
            elif d < 0.0:
                down_run += 1
                up_run = 0
            else:
                up_run = 0
                down_run = 0

            if up_run > max_up:
                max_up = up_run
            if down_run > max_down:
                max_down = down_run

        if valid:
            out[i] = (max_up - max_down) / denom

    return out


@njit(cache=True, nogil=True)
def rolling_extreme_spacing(array, rolling_window):
    x = _as_f64(array)
    n = x.size
    out = np.empty(n, np.float64)

    for i in range(n):
        out[i] = np.nan

    if rolling_window < 2 or rolling_window > n:
        return out

    denom = rolling_window - 1.0
    for i in range(rolling_window - 1, n):
        start = i - rolling_window + 1
        valid = True
        mn = x[start]
        mx = x[start]
        min_idx = start
        max_idx = start

        if not np.isfinite(mn):
            valid = False

        if valid:
            for k in range(start + 1, i + 1):
                v = x[k]
                if not np.isfinite(v):
                    valid = False
                    break
                if v <= mn:
                    mn = v
                    min_idx = k
                if v >= mx:
                    mx = v
                    max_idx = k

        if valid:
            out[i] = abs(max_idx - min_idx) / denom

    return out
