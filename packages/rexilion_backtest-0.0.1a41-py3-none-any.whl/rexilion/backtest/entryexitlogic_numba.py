from numba import njit
import numpy as np
from rexilion.backtest.formula_numba import (
    rolling_mean,
    rolling_ema,
    rolling_wma,
    rolling_std,
    rolling_min,
    rolling_max
)

# Mode IDs
MODE_MR = 0
MODE_MR_0 = 1
MODE_0_SIDELINE = 2
MODE_MOMENTUM = 3
MODE_MOMENTUM_SIDELINE = 4
MODE_MOMENTUM_0 = 5
MODE_MR_SMAMA = 6
MODE_MR_EMAMA = 7
MODE_MR_WMAMA = 8
MODE_MOMENTUM_SMAMA = 9
MODE_MOMENTUM_EMAMA = 10
MODE_MOMENTUM_WMAMA = 11
MODE_MR_SMA = 12
MODE_MR_EMA = 13
MODE_MR_WMA = 14
MODE_MOMENTUM_SMA = 15
MODE_MOMENTUM_EMA = 16
MODE_MOMENTUM_WMA = 17
MODE_MOM_SMA_SIDELINE = 18
MODE_MOM_EMA_SIDELINE = 19
MODE_MOM_WMA_SIDELINE = 20
MODE_MM_MR = 21
MODE_MM_MR_MID = 22
MODE_MM_MOMENTUM = 23
MODE_MM_MOMENTUM_MID = 24
MODE_MM_MR_SMA = 25
MODE_MM_MR_EMA = 26
MODE_MM_MR_WMA = 27
MODE_MM_MOMENTUM_SMA = 28
MODE_MM_MOMENTUM_EMA = 29
MODE_MM_MOMENTUM_WMA = 30
MODE_BB_MR = 31
MODE_BB_MOMENTUM = 32
MODE_BB_MR_SMA = 33
MODE_BB_MOMENTUM_SMA = 34

# _X modes
MODE_MR_SMAMA_X = 36
MODE_MR_EMAMA_X = 37
MODE_MR_WMAMA_X = 38
MODE_MOMENTUM_SMAMA_X = 39
MODE_MOMENTUM_EMAMA_X = 40
MODE_MOMENTUM_WMAMA_X = 41
MODE_MM_MR_X = 42
MODE_MM_MR_MID_X = 43
MODE_MM_MOMENTUM_X = 44
MODE_MM_MOMENTUM_MID_X = 45
MODE_MM_MR_SMA_X = 46
MODE_MM_MR_EMA_X = 47
MODE_MM_MR_WMA_X = 48
MODE_MM_MOMENTUM_SMA_X = 49
MODE_MM_MOMENTUM_EMA_X = 50
MODE_MM_MOMENTUM_WMA_X = 51

# New single-side modes
# For these modes only:
#   All applicable single-side modes use xL + thr_long to enter,
#   and xS + thr_short to exit back to flat.
# Positive / Negative refers to the sign / boundary choice of the EXIT condition.
MODE_MOM_LONG_EXIT_POS = 52
MODE_MOM_LONG_EXIT_NEG = 53
MODE_MOM_SHORT_EXIT_POS = 54
MODE_MOM_SHORT_EXIT_NEG = 55
MODE_MR_LONG_EXIT_POS = 56
MODE_MR_LONG_EXIT_NEG = 57
MODE_MR_SHORT_EXIT_POS = 58
MODE_MR_SHORT_EXIT_NEG = 59

# Family single-side modes (minimal additive implementation)
# For these modes only:
#   thr_long  -> entry threshold on xL boundary
#   thr_short -> exit threshold on xS boundary
#   all applicable modes: xL enters, xS exits to flat
# POS / NEG selects which family boundary is used on the EXIT stream.
MODE_MM_MR_LONG_EXIT_POS = 60
MODE_MM_MR_LONG_EXIT_NEG = 61
MODE_MM_MR_SHORT_EXIT_POS = 62
MODE_MM_MR_SHORT_EXIT_NEG = 63
MODE_MM_MOMENTUM_LONG_EXIT_POS = 64
MODE_MM_MOMENTUM_LONG_EXIT_NEG = 65
MODE_MM_MOMENTUM_SHORT_EXIT_POS = 66
MODE_MM_MOMENTUM_SHORT_EXIT_NEG = 67
MODE_BB_MR_LONG_EXIT_POS = 68
MODE_BB_MR_LONG_EXIT_NEG = 69
MODE_BB_MR_SHORT_EXIT_POS = 70
MODE_BB_MR_SHORT_EXIT_NEG = 71
MODE_BB_MOMENTUM_LONG_EXIT_POS = 72
MODE_BB_MOMENTUM_LONG_EXIT_NEG = 73
MODE_BB_MOMENTUM_SHORT_EXIT_POS = 74
MODE_BB_MOMENTUM_SHORT_EXIT_NEG = 75
MODE_MR_SMAMA_LONG_EXIT_POS = 76
MODE_MR_SMAMA_LONG_EXIT_NEG = 77
MODE_MR_SMAMA_SHORT_EXIT_POS = 78
MODE_MR_SMAMA_SHORT_EXIT_NEG = 79
MODE_MOMENTUM_SMAMA_LONG_EXIT_POS = 80
MODE_MOMENTUM_SMAMA_LONG_EXIT_NEG = 81
MODE_MOMENTUM_SMAMA_SHORT_EXIT_POS = 82
MODE_MOMENTUM_SMAMA_SHORT_EXIT_NEG = 83
MODE_MR_EMAMA_LONG_EXIT_POS = 84
MODE_MR_EMAMA_LONG_EXIT_NEG = 85
MODE_MR_EMAMA_SHORT_EXIT_POS = 86
MODE_MR_EMAMA_SHORT_EXIT_NEG = 87
MODE_MOMENTUM_EMAMA_LONG_EXIT_POS = 88
MODE_MOMENTUM_EMAMA_LONG_EXIT_NEG = 89
MODE_MOMENTUM_EMAMA_SHORT_EXIT_POS = 90
MODE_MOMENTUM_EMAMA_SHORT_EXIT_NEG = 91
MODE_MR_WMAMA_LONG_EXIT_POS = 92
MODE_MR_WMAMA_LONG_EXIT_NEG = 93
MODE_MR_WMAMA_SHORT_EXIT_POS = 94
MODE_MR_WMAMA_SHORT_EXIT_NEG = 95
MODE_MOMENTUM_WMAMA_LONG_EXIT_POS = 96
MODE_MOMENTUM_WMAMA_LONG_EXIT_NEG = 97
MODE_MOMENTUM_WMAMA_SHORT_EXIT_POS = 98
MODE_MOMENTUM_WMAMA_SHORT_EXIT_NEG = 99

# Gated momentum-family modes
# Enter when one gate opens, hold while that same gate remains open,
# exit to flat when it closes. Both gates open is treated as conflict -> flat.
MODE_MOMENTUM_GATED = 100
MODE_MM_MOMENTUM_X_GATED = 101
MODE_BB_MOMENTUM_GATED = 102
MODE_MOMENTUM_SMAMA_GATED = 103
MODE_MOMENTUM_EMAMA_GATED = 104
MODE_MOMENTUM_WMAMA_GATED = 105

SIDE_LONG = 1
SIDE_SHORT = -1

# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# Convention:
#   1  => only long hit
#  -1  => only short hit
#   2  => both hit (conflict)  → FLAT
#   0  => neutral (no hits)    → CARRY prev
# ──────────────────────────────────────────────────────────────────────────────
@njit(cache=True)
def _entry_from_dual_mom(xL, xS, thr_long, thr_short, prev):
    long_hit = xL > thr_long
    short_hit = xS < -thr_short
    if long_hit and not short_hit:
        return 1
    if short_hit and not long_hit:
        return -1
    if long_hit and short_hit:
        return 2
    return 0


@njit(cache=True)
def _entry_from_dual_mr(xL, xS, thr_long, thr_short, prev):
    long_hit = xL < -thr_long
    short_hit = xS > thr_short
    if long_hit and not short_hit:
        return 1
    if short_hit and not long_hit:
        return -1
    if long_hit and short_hit:
        return 2
    return 0


@njit(cache=True)
def _resolve_dual_hits(long_hit, short_hit):
    if long_hit and not short_hit:
        return 1
    if short_hit and not long_hit:
        return -1
    if long_hit and short_hit:
        return 2
    return 0


@njit(cache=True)
def _range_level(mn, mx, thr):
    return mn + (mx - mn) * thr


@njit(cache=True)
def _upper_range_level(mn, mx, thr):
    return mx - (mx - mn) * thr

@njit(cache=True)
def _single_side_mom_exit_pos(
    entry_signal,
    exit_signal,
    entry_threshold,
    exit_threshold,
    prev_pos,
    side
):
    if prev_pos == 0:
        if side == SIDE_LONG:
            return 1 if entry_signal > entry_threshold else 0
        if side == SIDE_SHORT:
            return -1 if entry_signal < -entry_threshold else 0
        return 0

    if prev_pos == side:
        if side == SIDE_LONG:
            return 0 if exit_signal < exit_threshold else 1
        if side == SIDE_SHORT:
            return 0 if exit_signal > exit_threshold else -1
        return 0

    return 0


@njit(cache=True)
def _single_side_mom_exit_neg(
    entry_signal,
    exit_signal,
    entry_threshold,
    exit_threshold,
    prev_pos,
    side
):
    if prev_pos == 0:
        if side == SIDE_LONG:
            return 1 if entry_signal > entry_threshold else 0
        if side == SIDE_SHORT:
            return -1 if entry_signal < -entry_threshold else 0
        return 0

    if prev_pos == side:
        if side == SIDE_LONG:
            return 0 if exit_signal < -exit_threshold else 1
        if side == SIDE_SHORT:
            return 0 if exit_signal > -exit_threshold else -1
        return 0

    return 0


@njit(cache=True)
def _single_side_mr_exit_pos(
    entry_signal,
    exit_signal,
    entry_threshold,
    exit_threshold,
    prev_pos,
    side
):
    if prev_pos == 0:
        if side == SIDE_LONG:
            return 1 if entry_signal < -entry_threshold else 0
        if side == SIDE_SHORT:
            return -1 if entry_signal > entry_threshold else 0
        return 0

    if prev_pos == side:
        if side == SIDE_LONG:
            return 0 if exit_signal > exit_threshold else 1
        if side == SIDE_SHORT:
            return 0 if exit_signal < exit_threshold else -1
        return 0

    return 0


@njit(cache=True)
def _single_side_mr_exit_neg(
    entry_signal,
    exit_signal,
    entry_threshold,
    exit_threshold,
    prev_pos,
    side
):
    if prev_pos == 0:
        if side == SIDE_LONG:
            return 1 if entry_signal < -entry_threshold else 0
        if side == SIDE_SHORT:
            return -1 if entry_signal > entry_threshold else 0
        return 0

    if prev_pos == side:
        if side == SIDE_LONG:
            return 0 if exit_signal > -exit_threshold else 1
        if side == SIDE_SHORT:
            return 0 if exit_signal < -exit_threshold else -1
        return 0

    return 0


@njit(cache=True)
def _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev_pos, side):
    if prev_pos == 0:
        return side if entry_hit else 0

    if prev_pos == side:
        return 0 if exit_hit else side

    return 0


@njit(cache=True)
def _gated_from_dual_hits(long_hit, short_hit, prev_pos):
    if long_hit and short_hit:
        return 0

    if prev_pos == 1:
        return 1 if long_hit else 0

    if prev_pos == -1:
        return -1 if short_hit else 0

    if long_hit:
        return 1

    if short_hit:
        return -1

    return 0

# ──────────────────────────────────────────────────────────────────────────────
# THRESHOLD FAMILY
# ──────────────────────────────────────────────────────────────────────────────
@njit(cache=True)
def entry_exit_threshold(
    processed_long: np.ndarray,
    processed_short: np.ndarray,
    rolling_window_long: int,
    rolling_window_short: int,
    thr_long: float,
    thr_short: float,
    mode_id: int,
    weightage: float = 1.0
) -> np.ndarray:
    n = processed_long.shape[0]
    warmup = rolling_window_long if rolling_window_long > rolling_window_short else rolling_window_short

    pos = np.empty(n, np.int8)
    for i in range(warmup):
        pos[i] = 0

    use_sma = (
        mode_id == MODE_MR_SMAMA or mode_id == MODE_MOMENTUM_SMAMA
        or mode_id == MODE_MR_SMA or mode_id == MODE_MOMENTUM_SMA
        or mode_id == MODE_MM_MOMENTUM_SMA or mode_id == MODE_MM_MR_SMA
        or mode_id == MODE_MOM_SMA_SIDELINE
        or mode_id == MODE_BB_MR or mode_id == MODE_BB_MOMENTUM
        or mode_id == MODE_BB_MR_SMA or mode_id == MODE_BB_MOMENTUM_SMA
        or mode_id == MODE_MR_SMAMA_X or mode_id == MODE_MOMENTUM_SMAMA_X
        or mode_id == MODE_MM_MOMENTUM_SMA_X or mode_id == MODE_MM_MR_SMA_X
        or mode_id == MODE_BB_MR_LONG_EXIT_POS or mode_id == MODE_BB_MR_LONG_EXIT_NEG
        or mode_id == MODE_BB_MR_SHORT_EXIT_POS or mode_id == MODE_BB_MR_SHORT_EXIT_NEG
        or mode_id == MODE_BB_MOMENTUM_LONG_EXIT_POS or mode_id == MODE_BB_MOMENTUM_LONG_EXIT_NEG
        or mode_id == MODE_BB_MOMENTUM_SHORT_EXIT_POS or mode_id == MODE_BB_MOMENTUM_SHORT_EXIT_NEG
        or mode_id == MODE_MR_SMAMA_LONG_EXIT_POS or mode_id == MODE_MR_SMAMA_LONG_EXIT_NEG
        or mode_id == MODE_MR_SMAMA_SHORT_EXIT_POS or mode_id == MODE_MR_SMAMA_SHORT_EXIT_NEG
        or mode_id == MODE_MOMENTUM_SMAMA_LONG_EXIT_POS or mode_id == MODE_MOMENTUM_SMAMA_LONG_EXIT_NEG
        or mode_id == MODE_MOMENTUM_SMAMA_SHORT_EXIT_POS or mode_id == MODE_MOMENTUM_SMAMA_SHORT_EXIT_NEG
        or mode_id == MODE_BB_MOMENTUM_GATED
        or mode_id == MODE_MOMENTUM_SMAMA_GATED
    )
    use_ema = (
        mode_id == MODE_MR_EMAMA or mode_id == MODE_MOMENTUM_EMAMA
        or mode_id == MODE_MR_EMA or mode_id == MODE_MOMENTUM_EMA
        or mode_id == MODE_MM_MOMENTUM_EMA or mode_id == MODE_MM_MR_EMA
        or mode_id == MODE_MOM_EMA_SIDELINE
        or mode_id == MODE_MR_EMAMA_X or mode_id == MODE_MOMENTUM_EMAMA_X
        or mode_id == MODE_MM_MOMENTUM_EMA_X or mode_id == MODE_MM_MR_EMA_X
        or mode_id == MODE_MR_EMAMA_LONG_EXIT_POS or mode_id == MODE_MR_EMAMA_LONG_EXIT_NEG
        or mode_id == MODE_MR_EMAMA_SHORT_EXIT_POS or mode_id == MODE_MR_EMAMA_SHORT_EXIT_NEG
        or mode_id == MODE_MOMENTUM_EMAMA_LONG_EXIT_POS or mode_id == MODE_MOMENTUM_EMAMA_LONG_EXIT_NEG
        or mode_id == MODE_MOMENTUM_EMAMA_SHORT_EXIT_POS or mode_id == MODE_MOMENTUM_EMAMA_SHORT_EXIT_NEG
        or mode_id == MODE_MOMENTUM_EMAMA_GATED
    )
    use_wma = (
        mode_id == MODE_MR_WMAMA or mode_id == MODE_MOMENTUM_WMAMA
        or mode_id == MODE_MR_WMA or mode_id == MODE_MOMENTUM_WMA
        or mode_id == MODE_MM_MOMENTUM_WMA or mode_id == MODE_MM_MR_WMA
        or mode_id == MODE_MOM_WMA_SIDELINE
        or mode_id == MODE_MR_WMAMA_X or mode_id == MODE_MOMENTUM_WMAMA_X
        or mode_id == MODE_MM_MOMENTUM_WMA_X or mode_id == MODE_MM_MR_WMA_X
        or mode_id == MODE_MR_WMAMA_LONG_EXIT_POS or mode_id == MODE_MR_WMAMA_LONG_EXIT_NEG
        or mode_id == MODE_MR_WMAMA_SHORT_EXIT_POS or mode_id == MODE_MR_WMAMA_SHORT_EXIT_NEG
        or mode_id == MODE_MOMENTUM_WMAMA_LONG_EXIT_POS or mode_id == MODE_MOMENTUM_WMAMA_LONG_EXIT_NEG
        or mode_id == MODE_MOMENTUM_WMAMA_SHORT_EXIT_POS or mode_id == MODE_MOMENTUM_WMAMA_SHORT_EXIT_NEG
        or mode_id == MODE_MOMENTUM_WMAMA_GATED
    )
    use_std = (
        mode_id == MODE_BB_MR or mode_id == MODE_BB_MOMENTUM
        or mode_id == MODE_BB_MR_SMA or mode_id == MODE_BB_MOMENTUM_SMA
        or mode_id == MODE_BB_MR_LONG_EXIT_POS or mode_id == MODE_BB_MR_LONG_EXIT_NEG
        or mode_id == MODE_BB_MR_SHORT_EXIT_POS or mode_id == MODE_BB_MR_SHORT_EXIT_NEG
        or mode_id == MODE_BB_MOMENTUM_LONG_EXIT_POS or mode_id == MODE_BB_MOMENTUM_LONG_EXIT_NEG
        or mode_id == MODE_BB_MOMENTUM_SHORT_EXIT_POS or mode_id == MODE_BB_MOMENTUM_SHORT_EXIT_NEG
        or mode_id == MODE_BB_MOMENTUM_GATED
    )
    use_minmax = (
        mode_id == MODE_MM_MOMENTUM or mode_id == MODE_MM_MOMENTUM_MID
        or mode_id == MODE_MM_MOMENTUM_EMA or mode_id == MODE_MM_MOMENTUM_SMA
        or mode_id == MODE_MM_MOMENTUM_WMA or mode_id == MODE_MM_MR
        or mode_id == MODE_MM_MR_MID
        or mode_id == MODE_MM_MR_EMA or mode_id == MODE_MM_MR_SMA
        or mode_id == MODE_MM_MR_WMA
        or mode_id == MODE_MM_MOMENTUM_X or mode_id == MODE_MM_MOMENTUM_MID_X
        or mode_id == MODE_MM_MOMENTUM_EMA_X or mode_id == MODE_MM_MOMENTUM_SMA_X
        or mode_id == MODE_MM_MOMENTUM_WMA_X or mode_id == MODE_MM_MR_X
        or mode_id == MODE_MM_MR_MID_X
        or mode_id == MODE_MM_MR_EMA_X or mode_id == MODE_MM_MR_SMA_X
        or mode_id == MODE_MM_MR_WMA_X
        or mode_id == MODE_MM_MR_LONG_EXIT_POS or mode_id == MODE_MM_MR_LONG_EXIT_NEG
        or mode_id == MODE_MM_MR_SHORT_EXIT_POS or mode_id == MODE_MM_MR_SHORT_EXIT_NEG
        or mode_id == MODE_MM_MOMENTUM_LONG_EXIT_POS or mode_id == MODE_MM_MOMENTUM_LONG_EXIT_NEG
        or mode_id == MODE_MM_MOMENTUM_SHORT_EXIT_POS or mode_id == MODE_MM_MOMENTUM_SHORT_EXIT_NEG
        or mode_id == MODE_MM_MOMENTUM_X_GATED
    )

    if use_sma:
        smaL = rolling_mean(processed_long, rolling_window_long)
        smaS = rolling_mean(processed_short, rolling_window_short)
    else:
        smaL = smaS = np.empty(1, np.float64)

    if use_ema:
        emaL = rolling_ema(processed_long, rolling_window_long)
        emaS = rolling_ema(processed_short, rolling_window_short)
    else:
        emaL = emaS = np.empty(1, np.float64)

    if use_wma:
        wmaL = rolling_wma(processed_long, rolling_window_long)
        wmaS = rolling_wma(processed_short, rolling_window_short)
    else:
        wmaL = wmaS = np.empty(1, np.float64)

    if use_std:
        stdL = rolling_std(processed_long, rolling_window_long)
        stdS = rolling_std(processed_short, rolling_window_short)
    else:
        stdL = stdS = np.empty(1, np.float64)

    if use_minmax:
        mnL = rolling_min(processed_long, rolling_window_long)
        mxL = rolling_max(processed_long, rolling_window_long)
        mnS = rolling_min(processed_short, rolling_window_short)
        mxS = rolling_max(processed_short, rolling_window_short)
    else:
        mnL = mxL = mnS = mxS = np.empty(1, np.float64)

    for i in range(warmup, n):
        xL = processed_long[i]
        xS = processed_short[i]
        prev = pos[i - 1]

        # ── Original modes (unchanged except BB original updated with clash handling)
        if mode_id == MODE_MR:
            d = _entry_from_dual_mr(xL, xS, thr_long, thr_short, prev)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MR_0:
            d = _entry_from_dual_mr(xL, xS, thr_long, thr_short, prev)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL >= 0.0) or (prev == -1 and xS <= 0.0):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MR_SMA:
            d = _entry_from_dual_mr(xL, xS, thr_long, thr_short, prev)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL >= smaL[i]) or (prev == -1 and xS <= smaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MR_EMA:
            d = _entry_from_dual_mr(xL, xS, thr_long, thr_short, prev)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL >= emaL[i]) or (prev == -1 and xS <= emaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MR_WMA:
            d = _entry_from_dual_mr(xL, xS, thr_long, thr_short, prev)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL >= wmaL[i]) or (prev == -1 and xS <= wmaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_0_SIDELINE:
            if (xL > 0.0) and (xL < thr_long):
                pos[i] = 1
            elif (xS < 0.0) and (xS > -thr_short):
                pos[i] = -1
            elif (prev == 1 and xL >= thr_short) or (prev == -1 and xS <= -thr_long):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MOMENTUM:
            d = _entry_from_dual_mom(xL, xS, thr_long, thr_short, prev)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MOMENTUM_0:
            d = _entry_from_dual_mom(xL, xS, thr_long, thr_short, prev)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL <= 0.0) or (prev == -1 and xS >= 0.0):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MOMENTUM_SIDELINE:
            d = _entry_from_dual_mom(xL, xS, thr_long, thr_short, prev)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL <= thr_long) or (prev == -1 and xS >= -thr_short):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MOMENTUM_SMA:
            d = _entry_from_dual_mom(xL, xS, thr_long, thr_short, prev)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL <= smaL[i]) or (prev == -1 and xS >= smaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MOMENTUM_EMA:
            d = _entry_from_dual_mom(xL, xS, thr_long, thr_short, prev)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL <= emaL[i]) or (prev == -1 and xS >= emaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MOMENTUM_WMA:
            d = _entry_from_dual_mom(xL, xS, thr_long, thr_short, prev)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL <= wmaL[i]) or (prev == -1 and xS >= wmaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MR_SMAMA:
            mL = smaL[i]
            mS = smaS[i]
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            if xS > upS:
                pos[i] = -1
            elif xL < loL:
                pos[i] = 1
            else:
                pos[i] = prev

        elif mode_id == MODE_MOMENTUM_SMAMA:
            mL = smaL[i]
            mS = smaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            if xL > upL:
                pos[i] = 1
            elif xS < loS:
                pos[i] = -1
            else:
                pos[i] = prev

        elif mode_id == MODE_MR_EMAMA:
            mL = emaL[i]
            mS = emaS[i]
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            if xS > upS:
                pos[i] = -1
            elif xL < loL:
                pos[i] = 1
            else:
                pos[i] = prev

        elif mode_id == MODE_MOMENTUM_EMAMA:
            mL = emaL[i]
            mS = emaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            if xL > upL:
                pos[i] = 1
            elif xS < loS:
                pos[i] = -1
            else:
                pos[i] = prev

        elif mode_id == MODE_MR_WMAMA:
            mL = wmaL[i]
            mS = wmaS[i]
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            if xS > upS:
                pos[i] = -1
            elif xL < loL:
                pos[i] = 1
            else:
                pos[i] = prev

        elif mode_id == MODE_MOMENTUM_WMAMA:
            mL = wmaL[i]
            mS = wmaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            if xL > upL:
                pos[i] = 1
            elif xS < loS:
                pos[i] = -1
            else:
                pos[i] = prev

        elif mode_id == MODE_BB_MR:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            upS = midS + bandS * thr_short
            loL = midL - bandL * thr_long
            long_hit = xL < loL
            short_hit = xS > upS
            d = _resolve_dual_hits(long_hit, short_hit)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_BB_MOMENTUM:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            upL = midL + bandL * thr_long
            loS = midS - bandS * thr_short
            long_hit = xL > upL
            short_hit = xS < loS
            d = _resolve_dual_hits(long_hit, short_hit)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_BB_MR_SMA:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            upS = midS + bandS * thr_short
            loL = midL - bandL * thr_long
            long_hit = xL < loL
            short_hit = xS > upS
            d = _resolve_dual_hits(long_hit, short_hit)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL >= midL) or (prev == -1 and xS <= midS):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_BB_MOMENTUM_SMA:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            upL = midL + bandL * thr_long
            loS = midS - bandS * thr_short
            long_hit = xL > upL
            short_hit = xS < loS
            d = _resolve_dual_hits(long_hit, short_hit)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL <= midL) or (prev == -1 and xS >= midS):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MM_MR:
            if xL < mnL[i] * thr_long:
                pos[i] = 1
            elif xS > mxS[i] * thr_short:
                pos[i] = -1
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MR_MID:
            midL = (mnL[i] + mxL[i]) / 2.0
            midS = (mnS[i] + mxS[i]) / 2.0
            if xL < mnL[i] * thr_long:
                pos[i] = 1
            elif xS > mxS[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and xL >= midL) or (prev == -1 and xS <= midS):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MR_SMA:
            if xL < mnL[i] * thr_long:
                pos[i] = 1
            elif xS > mxS[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and xL >= smaL[i]) or (prev == -1 and xS <= smaS[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MR_EMA:
            if xL < mnL[i] * thr_long:
                pos[i] = 1
            elif xS > mxS[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and xL >= emaL[i]) or (prev == -1 and xS <= emaS[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MR_WMA:
            if xL < mnL[i] * thr_long:
                pos[i] = 1
            elif xS > mxS[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and xL >= wmaL[i]) or (prev == -1 and xS <= wmaS[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MOMENTUM:
            if xL > mxL[i] * thr_long:
                pos[i] = 1
            elif xS < mnS[i] * thr_short:
                pos[i] = -1
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MOMENTUM_MID:
            midL = (mnL[i] + mxL[i]) / 2.0
            midS = (mnS[i] + mxS[i]) / 2.0
            if xL > mxL[i] * thr_long:
                pos[i] = 1
            elif xS < mnS[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and xL <= midL) or (prev == -1 and xS >= midS):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MOMENTUM_SMA:
            if xL > mxL[i] * thr_long:
                pos[i] = 1
            elif xS < mnS[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and xL <= smaL[i]) or (prev == -1 and xS >= smaS[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MOMENTUM_EMA:
            if xL > mxL[i] * thr_long:
                pos[i] = 1
            elif xS < mnS[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and xL <= emaL[i]) or (prev == -1 and xS >= emaS[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MOMENTUM_WMA:
            if xL > mxL[i] * thr_long:
                pos[i] = 1
            elif xS < mnS[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and xL <= wmaL[i]) or (prev == -1 and xS >= wmaS[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        # ── _X modes (new behavior only here)
        elif mode_id == MODE_MR_SMAMA_X:
            mL = smaL[i]
            mS = smaS[i]
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            d = _resolve_dual_hits(xL < loL, xS > upS)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MOMENTUM_SMAMA_X:
            mL = smaL[i]
            mS = smaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            d = _resolve_dual_hits(xL > upL, xS < loS)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MR_EMAMA_X:
            mL = emaL[i]
            mS = emaS[i]
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            d = _resolve_dual_hits(xL < loL, xS > upS)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MOMENTUM_EMAMA_X:
            mL = emaL[i]
            mS = emaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            d = _resolve_dual_hits(xL > upL, xS < loS)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MR_WMAMA_X:
            mL = wmaL[i]
            mS = wmaS[i]
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            d = _resolve_dual_hits(xL < loL, xS > upS)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MOMENTUM_WMAMA_X:
            mL = wmaL[i]
            mS = wmaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            d = _resolve_dual_hits(xL > upL, xS < loS)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MM_MR_X:
            long_level = _range_level(mnL[i], mxL[i], thr_long)
            short_level = _upper_range_level(mnS[i], mxS[i], thr_short)
            d = _resolve_dual_hits(xL < long_level, xS > short_level)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MM_MR_MID_X:
            midL = (mnL[i] + mxL[i]) / 2.0
            midS = (mnS[i] + mxS[i]) / 2.0
            long_level = _range_level(mnL[i], mxL[i], thr_long)
            short_level = _upper_range_level(mnS[i], mxS[i], thr_short)
            d = _resolve_dual_hits(xL < long_level, xS > short_level)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL >= midL) or (prev == -1 and xS <= midS):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MM_MR_SMA_X:
            long_level = _range_level(mnL[i], mxL[i], thr_long)
            short_level = _upper_range_level(mnS[i], mxS[i], thr_short)
            d = _resolve_dual_hits(xL < long_level, xS > short_level)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL >= smaL[i]) or (prev == -1 and xS <= smaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MM_MR_EMA_X:
            long_level = _range_level(mnL[i], mxL[i], thr_long)
            short_level = _upper_range_level(mnS[i], mxS[i], thr_short)
            d = _resolve_dual_hits(xL < long_level, xS > short_level)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL >= emaL[i]) or (prev == -1 and xS <= emaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MM_MR_WMA_X:
            long_level = _range_level(mnL[i], mxL[i], thr_long)
            short_level = _upper_range_level(mnS[i], mxS[i], thr_short)
            d = _resolve_dual_hits(xL < long_level, xS > short_level)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL >= wmaL[i]) or (prev == -1 and xS <= wmaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MM_MOMENTUM_X:
            long_level = _range_level(mnL[i], mxL[i], thr_long)
            short_level = _range_level(mnS[i], mxS[i], thr_short)
            d = _resolve_dual_hits(xL > long_level, xS < short_level)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MM_MOMENTUM_MID_X:
            midL = (mnL[i] + mxL[i]) / 2.0
            midS = (mnS[i] + mxS[i]) / 2.0
            long_level = _range_level(mnL[i], mxL[i], thr_long)
            short_level = _range_level(mnS[i], mxS[i], thr_short)
            d = _resolve_dual_hits(xL > long_level, xS < short_level)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL <= midL) or (prev == -1 and xS >= midS):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MM_MOMENTUM_SMA_X:
            long_level = _range_level(mnL[i], mxL[i], thr_long)
            short_level = _range_level(mnS[i], mxS[i], thr_short)
            d = _resolve_dual_hits(xL > long_level, xS < short_level)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL <= smaL[i]) or (prev == -1 and xS >= smaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MM_MOMENTUM_EMA_X:
            long_level = _range_level(mnL[i], mxL[i], thr_long)
            short_level = _range_level(mnS[i], mxS[i], thr_short)
            d = _resolve_dual_hits(xL > long_level, xS < short_level)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL <= emaL[i]) or (prev == -1 and xS >= emaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MM_MOMENTUM_WMA_X:
            long_level = _range_level(mnL[i], mxL[i], thr_long)
            short_level = _range_level(mnS[i], mxS[i], thr_short)
            d = _resolve_dual_hits(xL > long_level, xS < short_level)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and xL <= wmaL[i]) or (prev == -1 and xS >= wmaS[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MOMENTUM_GATED:
            pos[i] = _gated_from_dual_hits(xL > thr_long, xS < -thr_short, prev)

        elif mode_id == MODE_MM_MOMENTUM_X_GATED:
            long_level = _range_level(mnL[i], mxL[i], thr_long)
            short_level = _range_level(mnS[i], mxS[i], thr_short)
            pos[i] = _gated_from_dual_hits(xL > long_level, xS < short_level, prev)

        elif mode_id == MODE_BB_MOMENTUM_GATED:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            upL = midL + bandL * thr_long
            loS = midS - bandS * thr_short
            pos[i] = _gated_from_dual_hits(xL > upL, xS < loS, prev)

        elif mode_id == MODE_MOMENTUM_SMAMA_GATED:
            mL = smaL[i]
            mS = smaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            pos[i] = _gated_from_dual_hits(xL > upL, xS < loS, prev)

        elif mode_id == MODE_MOMENTUM_EMAMA_GATED:
            mL = emaL[i]
            mS = emaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            pos[i] = _gated_from_dual_hits(xL > upL, xS < loS, prev)

        elif mode_id == MODE_MOMENTUM_WMAMA_GATED:
            mL = wmaL[i]
            mS = wmaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            pos[i] = _gated_from_dual_hits(xL > upL, xS < loS, prev)

        elif mode_id == MODE_MOM_LONG_EXIT_POS:
            pos[i] = _single_side_mom_exit_pos(xL, xS, thr_long, thr_short, prev, SIDE_LONG)

        elif mode_id == MODE_MOM_LONG_EXIT_NEG:
            pos[i] = _single_side_mom_exit_neg(xL, xS, thr_long, thr_short, prev, SIDE_LONG)

        elif mode_id == MODE_MOM_SHORT_EXIT_POS:
            pos[i] = _single_side_mom_exit_pos(xL, xS, thr_long, thr_short, prev, SIDE_SHORT)

        elif mode_id == MODE_MOM_SHORT_EXIT_NEG:
            pos[i] = _single_side_mom_exit_neg(xL, xS, thr_long, thr_short, prev, SIDE_SHORT)

        elif mode_id == MODE_MR_LONG_EXIT_POS:
            pos[i] = _single_side_mr_exit_pos(xL, xS, thr_long, thr_short, prev, SIDE_LONG)

        elif mode_id == MODE_MR_LONG_EXIT_NEG:
            pos[i] = _single_side_mr_exit_neg(xL, xS, thr_long, thr_short, prev, SIDE_LONG)

        elif mode_id == MODE_MR_SHORT_EXIT_POS:
            pos[i] = _single_side_mr_exit_pos(xL, xS, thr_long, thr_short, prev, SIDE_SHORT)

        elif mode_id == MODE_MR_SHORT_EXIT_NEG:
            pos[i] = _single_side_mr_exit_neg(xL, xS, thr_long, thr_short, prev, SIDE_SHORT)

        # ── Family single-side modes (original modes untouched)
        elif mode_id == MODE_MM_MR_LONG_EXIT_POS:
            entry_hit = xL < mnL[i] * thr_long
            exit_hit = xS > mxS[i] * thr_short
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MM_MR_LONG_EXIT_NEG:
            entry_hit = xL < mnL[i] * thr_long
            exit_hit = xS > mnS[i] * thr_short
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MM_MR_SHORT_EXIT_POS:
            entry_hit = xL < mnL[i] * thr_long
            exit_hit = xS > mxS[i] * thr_short
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MM_MR_SHORT_EXIT_NEG:
            entry_hit = xL < mnL[i] * thr_long
            exit_hit = xS > mnS[i] * thr_short
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MM_MOMENTUM_LONG_EXIT_POS:
            entry_hit = xL > mxL[i] * thr_long
            exit_hit = xS < mxS[i] * thr_short
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MM_MOMENTUM_LONG_EXIT_NEG:
            entry_hit = xL > mxL[i] * thr_long
            exit_hit = xS < mnS[i] * thr_short
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MM_MOMENTUM_SHORT_EXIT_POS:
            entry_hit = xL > mxL[i] * thr_long
            exit_hit = xS < mxS[i] * thr_short
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MM_MOMENTUM_SHORT_EXIT_NEG:
            entry_hit = xL > mxL[i] * thr_long
            exit_hit = xS < mnS[i] * thr_short
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_BB_MR_LONG_EXIT_POS:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            entry_hit = xL < (midL - bandL * thr_long)
            exit_hit = xS > (midS + bandS * thr_short)
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_BB_MR_LONG_EXIT_NEG:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            entry_hit = xL < (midL - bandL * thr_long)
            exit_hit = xS > (midS - bandS * thr_short)
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_BB_MR_SHORT_EXIT_POS:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            entry_hit = xL < (midL - bandL * thr_long)
            exit_hit = xS > (midS + bandS * thr_short)
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_BB_MR_SHORT_EXIT_NEG:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            entry_hit = xL < (midL - bandL * thr_long)
            exit_hit = xS > (midS - bandS * thr_short)
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_BB_MOMENTUM_LONG_EXIT_POS:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            entry_hit = xL > (midL + bandL * thr_long)
            exit_hit = xS < (midS + bandS * thr_short)
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_BB_MOMENTUM_LONG_EXIT_NEG:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            entry_hit = xL > (midL + bandL * thr_long)
            exit_hit = xS < (midS - bandS * thr_short)
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_BB_MOMENTUM_SHORT_EXIT_POS:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            entry_hit = xL > (midL + bandL * thr_long)
            exit_hit = xS < (midS + bandS * thr_short)
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_BB_MOMENTUM_SHORT_EXIT_NEG:
            midL = smaL[i]
            midS = smaS[i]
            bandL = stdL[i]
            bandS = stdS[i]
            entry_hit = xL > (midL + bandL * thr_long)
            exit_hit = xS < (midS - bandS * thr_short)
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MR_SMAMA_LONG_EXIT_POS:
            mL = smaL[i]
            mS = smaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL < loL
            exit_hit = xS > upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MR_SMAMA_LONG_EXIT_NEG:
            mL = smaL[i]
            mS = smaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL < loL
            exit_hit = xS > loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MR_SMAMA_SHORT_EXIT_POS:
            mL = smaL[i]
            mS = smaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL < loL
            exit_hit = xS > upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MR_SMAMA_SHORT_EXIT_NEG:
            mL = smaL[i]
            mS = smaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL < loL
            exit_hit = xS > loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MOMENTUM_SMAMA_LONG_EXIT_POS:
            mL = smaL[i]
            mS = smaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL > upL
            exit_hit = xS < upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MOMENTUM_SMAMA_LONG_EXIT_NEG:
            mL = smaL[i]
            mS = smaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL > upL
            exit_hit = xS < loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MOMENTUM_SMAMA_SHORT_EXIT_POS:
            mL = smaL[i]
            mS = smaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL > upL
            exit_hit = xS < upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MOMENTUM_SMAMA_SHORT_EXIT_NEG:
            mL = smaL[i]
            mS = smaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL > upL
            exit_hit = xS < loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MR_EMAMA_LONG_EXIT_POS:
            mL = emaL[i]
            mS = emaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL < loL
            exit_hit = xS > upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MR_EMAMA_LONG_EXIT_NEG:
            mL = emaL[i]
            mS = emaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL < loL
            exit_hit = xS > loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MR_EMAMA_SHORT_EXIT_POS:
            mL = emaL[i]
            mS = emaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL < loL
            exit_hit = xS > upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MR_EMAMA_SHORT_EXIT_NEG:
            mL = emaL[i]
            mS = emaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL < loL
            exit_hit = xS > loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MOMENTUM_EMAMA_LONG_EXIT_POS:
            mL = emaL[i]
            mS = emaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL > upL
            exit_hit = xS < upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MOMENTUM_EMAMA_LONG_EXIT_NEG:
            mL = emaL[i]
            mS = emaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL > upL
            exit_hit = xS < loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MOMENTUM_EMAMA_SHORT_EXIT_POS:
            mL = emaL[i]
            mS = emaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL > upL
            exit_hit = xS < upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MOMENTUM_EMAMA_SHORT_EXIT_NEG:
            mL = emaL[i]
            mS = emaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL > upL
            exit_hit = xS < loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MR_WMAMA_LONG_EXIT_POS:
            mL = wmaL[i]
            mS = wmaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL < loL
            exit_hit = xS > upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MR_WMAMA_LONG_EXIT_NEG:
            mL = wmaL[i]
            mS = wmaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL < loL
            exit_hit = xS > loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MR_WMAMA_SHORT_EXIT_POS:
            mL = wmaL[i]
            mS = wmaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL < loL
            exit_hit = xS > upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MR_WMAMA_SHORT_EXIT_NEG:
            mL = wmaL[i]
            mS = wmaS[i]
            loL = mL * (1.0 - thr_long) if mL > 0 else mL * (1.0 + thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL < loL
            exit_hit = xS > loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MOMENTUM_WMAMA_LONG_EXIT_POS:
            mL = wmaL[i]
            mS = wmaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL > upL
            exit_hit = xS < upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MOMENTUM_WMAMA_LONG_EXIT_NEG:
            mL = wmaL[i]
            mS = wmaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL > upL
            exit_hit = xS < loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_LONG)

        elif mode_id == MODE_MOMENTUM_WMAMA_SHORT_EXIT_POS:
            mL = wmaL[i]
            mS = wmaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            upS = mS * (1.0 + thr_short) if mS > 0 else mS * (1.0 - thr_short)
            entry_hit = xL > upL
            exit_hit = xS < upS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)

        elif mode_id == MODE_MOMENTUM_WMAMA_SHORT_EXIT_NEG:
            mL = wmaL[i]
            mS = wmaS[i]
            upL = mL * (1.0 + thr_long) if mL > 0 else mL * (1.0 - thr_long)
            loS = mS * (1.0 - thr_short) if mS > 0 else mS * (1.0 + thr_short)
            entry_hit = xL > upL
            exit_hit = xS < loS
            pos[i] = _single_side_from_entry_exit_hit(entry_hit, exit_hit, prev, SIDE_SHORT)
        else:
            pos[i] = prev

    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = pos[i] * weightage
    return out