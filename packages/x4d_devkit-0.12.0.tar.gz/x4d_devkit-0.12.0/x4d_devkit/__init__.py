"""X-4D dataset format SDK."""

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("x4d-devkit")
except PackageNotFoundError:  # source checkout without installed metadata
    __version__ = "0.0.0+unknown"

from x4d_devkit.client import X4DClient
from x4d_devkit.core import (
    Annotation,
    CalibratedSensor,
    ClipLoader,
    ClipMeta,
    EgoPose,
    Instance,
    PointFormat,
    Sample,
    SampleData,
    SchemaVersionMismatch,
    SensorInfo,
    Transform,
    TransformChain,
    generate_token,
)
from x4d_devkit.eval import (
    Box,
    DetectionConfig,
    DetectionEval,
    DetectionResult,
    boxes_from_clip,
    calc_ap,
    calc_tp,
    evaluate,
    nusc_detection_config,
)
from x4d_devkit.validation import validate_clip, ValidationReport
from x4d_devkit.fusion import LIDAR_FUSED_DTYPE, FusionSource, fuse_pointclouds  # noqa: E402,F401

__all__ = [
    "__version__",
    "Annotation",
    "Box",
    "CalibratedSensor",
    "LIDAR_FUSED_DTYPE",
    "FusionSource",
    "fuse_pointclouds",
    "ClipLoader",
    "ClipMeta",
    "DetectionConfig",
    "DetectionEval",
    "DetectionResult",
    "EgoPose",
    "Instance",
    "PointFormat",
    "Sample",
    "SampleData",
    "SchemaVersionMismatch",
    "SensorInfo",
    "Transform",
    "TransformChain",
    "ValidationReport",
    "X4DClient",
    "boxes_from_clip",
    "calc_ap",
    "calc_tp",
    "evaluate",
    "generate_token",
    "nusc_detection_config",
    "validate_clip",
]
