"""Clip directory validation."""
from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np

from x4d_devkit.validation.report import ValidationReport, ValidationIssue

CHANNEL_FRAME_ID_REGEX = re.compile(r"^[a-z][a-z0-9_]{0,63}$")

REQUIRED_JSON_FILES = [
    "meta.json",
    "calibrated_sensor.json",
    "ego_pose.json",
    "sample.json",
    "sample_data.json",
    "annotation.json",
    "instance.json",
]

KNOWN_CATEGORIES = {
    "car",
    "truck",
    "bus",
    "trailer",
    "construction_vehicle",
    "pedestrian",
    "motorcycle",
    "bicycle",
    "vehicle.car",
    "vehicle.truck",
    "vehicle.bus.bendy",
    "vehicle.bus.rigid",
    "vehicle.trailer",
    "vehicle.construction",
    "human.pedestrian.adult",
    "human.pedestrian.child",
    "human.pedestrian.construction_worker",
    "human.pedestrian.police_officer",
    "vehicle.motorcycle",
    "vehicle.bicycle",
    "traffic_cone",
    "barrier",
    "movable_object.barrier",
    "movable_object.trafficcone",
    "movable_object.pushable_pullable",
    "movable_object.debris",
    "static_object.bicycle_rack",
}


def validate_clip(clip_dir: str | Path) -> ValidationReport:
    """Validate an X-4D clip directory for completeness and correctness.

    Checks:
        1. All required JSON files exist and parse correctly.
        2. LiDAR binary files exist and have valid format.
        3. Ego pose references are valid.
        4. Annotation integrity (categories, bbox dimensions, references).
        5. Prev/next chain integrity for samples.

    Args:
        clip_dir: Path to the clip directory (must contain meta.json).

    Returns:
        ValidationReport with errors and warnings. Use ``report.ok`` to
        check if validation passed (no errors).

    Example::

        report = validate_clip("/data/clips/my_clip")
        if report.ok:
            print("Validation passed!")
        else:
            for err in report.errors:
                print(f"  {err.check}: {err.message}")
    """
    clip_dir = Path(clip_dir)

    # Try to get clip_id from meta.json, fallback to directory name
    clip_id = clip_dir.name
    issues: list[ValidationIssue] = []
    jsons: dict[str, any] = {}

    # 1. Check JSON files exist and parse
    for fname in REQUIRED_JSON_FILES:
        path = clip_dir / fname
        if not path.exists():
            issues.append(
                ValidationIssue("json_exists", "error", f"Missing {fname}")
            )
            continue
        try:
            with open(path) as f:
                jsons[fname] = json.load(f)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            issues.append(
                ValidationIssue("json_parse", "error", f"Cannot parse {fname}", str(e))
            )

    if "meta.json" in jsons:
        clip_id = jsons["meta.json"].get("clip_id", clip_id)

    # Schema v0.6+: explicit annotation_frame_id + per-sensor frame_id, both
    # resolving against calibrated_sensor.json.
    # v0.7 additions: explicit ego_pose_frame_id, lowercase regex on every
    # channel/frame_id, and `fusion.frame` removed.
    # v0.8 additions: self-reference root in calibrated_sensor.json,
    # annotation_frame_id must equal some sensor's frame_id (label-source colocation).
    if "meta.json" in jsons:
        meta = jsons["meta.json"]
        sv = str(meta.get("schema_version", ""))
        is_v06_plus = sv in {"0.6", "0.7", "0.8"}
        is_v07_plus = sv in {"0.7", "0.8"}
        is_v07 = sv == "0.7"
        is_v08 = sv == "0.8"
        if is_v06_plus:
            cs_records = jsons.get("calibrated_sensor.json", []) or []
            cs_channels = {r.get("channel") for r in cs_records if r.get("channel")}
            calib_frame_ids = set(cs_channels) | {"base_link"}
            sensors = (meta.get("sensors") or {})
            sensor_frame_ids: set[str] = set()
            for ch, info in sensors.items():
                if is_v07_plus and not CHANNEL_FRAME_ID_REGEX.match(str(ch)):
                    issues.append(
                        ValidationIssue(
                            "channel_regex",
                            "error",
                            f"channel {ch!r} violates v0.7+ ^[a-z][a-z0-9_]{{0,63}}$",
                        )
                    )
                fid = (info or {}).get("frame_id") if isinstance(info, dict) else None
                if not fid:
                    issues.append(
                        ValidationIssue(
                            "sensor_frame_id",
                            "error",
                            f"sensors[{ch!r}].frame_id is required in schema {sv}",
                        )
                    )
                    continue
                if is_v07_plus and not CHANNEL_FRAME_ID_REGEX.match(str(fid)):
                    issues.append(
                        ValidationIssue(
                            "frame_id_regex",
                            "error",
                            f"sensors[{ch!r}].frame_id={fid!r} violates v0.7+ regex",
                        )
                    )
                if is_v07_plus and isinstance(info.get("fusion"), dict) and "frame" in info["fusion"]:
                    issues.append(
                        ValidationIssue(
                            "fusion_frame_removed",
                            "error",
                            f"sensors[{ch!r}].fusion.frame is removed in v0.7+ — "
                            "use sensors[ch].frame_id only",
                        )
                    )
                sensor_frame_ids.add(fid)
                # v0.8: lookup by frame_id (channel and frame_id are decoupled —
                # producer-private channel name != ROS frame_id). Pre-v0.8: lookup
                # by channel (legacy "channel ≡ frame_id" assumption).
                if is_v08:
                    if fid not in cs_channels:
                        issues.append(
                            ValidationIssue(
                                "sensor_frame_id",
                                "error",
                                f"sensors[{ch!r}].frame_id={fid!r} not in calibration "
                                f"tree (known channels: {sorted(cs_channels)})",
                            )
                        )
                else:
                    if ch not in cs_channels:
                        issues.append(
                            ValidationIssue(
                                "sensor_frame_id",
                                "error",
                                f"sensors[{ch!r}] has no matching calibrated_sensor record",
                            )
                        )
            calib_frame_ids |= sensor_frame_ids

            def _check_frame_id(field: str, value):
                if not value:
                    issues.append(
                        ValidationIssue(
                            field, "error",
                            f"meta.{field} is required in schema {sv}",
                        )
                    )
                    return
                if is_v07_plus and not CHANNEL_FRAME_ID_REGEX.match(str(value)):
                    issues.append(
                        ValidationIssue(
                            f"{field}_regex", "error",
                            f"meta.{field}={value!r} violates v0.7 regex",
                        )
                    )
                if value not in calib_frame_ids:
                    issues.append(
                        ValidationIssue(
                            field, "error",
                            f"{field}={value!r} does not resolve in calibration tree "
                            f"(known: {sorted(calib_frame_ids)})",
                        )
                    )

            ann_fid = meta.get("annotation_frame_id")
            _check_frame_id("annotation_frame_id", ann_fid)
            if is_v07:
                _check_frame_id("ego_pose_frame_id", meta.get("ego_pose_frame_id"))

            for r in cs_records:
                ch = r.get("channel")
                if is_v07_plus and ch and not CHANNEL_FRAME_ID_REGEX.match(str(ch)):
                    issues.append(
                        ValidationIssue(
                            "calibrated_sensor_channel_regex",
                            "error",
                            f"calibrated_sensor channel {ch!r} violates v0.7+ regex",
                        )
                    )

            # v0.8 I1: exactly one self-reference root record
            if is_v08:
                self_refs = [
                    r for r in cs_records
                    if r.get("channel") and r.get("parent_frame") == r.get("channel")
                ]
                if len(self_refs) == 0:
                    issues.append(
                        ValidationIssue(
                            "self_reference_root_missing",
                            "error",
                            "v0.8 requires exactly 1 calibrated_sensor record with "
                            "parent_frame == channel (self-reference root); found 0",
                        )
                    )
                elif len(self_refs) > 1:
                    issues.append(
                        ValidationIssue(
                            "self_reference_root_multiple",
                            "error",
                            f"v0.8 requires exactly 1 self-reference root; found "
                            f"{len(self_refs)}: {[r['channel'] for r in self_refs]}",
                        )
                    )
                else:
                    # I1 cont: root record must be identity transform.
                    root = self_refs[0]
                    t = root.get("translation") or {}
                    r = root.get("rotation") or {}
                    is_identity_t = all(abs(float(t.get(k, 0))) < 1e-9 for k in "xyz")
                    is_identity_r = (
                        abs(float(r.get("qx", 0))) < 1e-9
                        and abs(float(r.get("qy", 0))) < 1e-9
                        and abs(float(r.get("qz", 0))) < 1e-9
                        and abs(float(r.get("qw", 1)) - 1.0) < 1e-9
                    )
                    if not (is_identity_t and is_identity_r):
                        issues.append(
                            ValidationIssue(
                                "self_reference_root_not_identity",
                                "error",
                                f"v0.8 self-reference root {root['channel']!r} must be "
                                "identity transform (translation=0, rotation=identity)",
                            )
                        )

            # v0.8 I2: annotation_frame_id must equal some sensor's frame_id
            # (label-source colocation)
            if is_v08 and ann_fid:
                colocated = any(
                    info.get("frame_id") == ann_fid
                    and info.get("modality") in {"lidar"}
                    for info in sensors.values()
                    if isinstance(info, dict)
                )
                if not colocated:
                    issues.append(
                        ValidationIssue(
                            "label_source_colocation",
                            "error",
                            f"v0.8 requires annotation_frame_id={ann_fid!r} to equal "
                            "some sensor's frame_id (with modality lidar) — annotations "
                            "must be colocated with their source data",
                        )
                    )

    # If we can't parse essential files, return early
    if "sample.json" not in jsons or "sample_data.json" not in jsons:
        return ValidationReport(clip_id=clip_id, issues=issues)

    # 2. Build indices
    samples = jsons["sample.json"]
    sample_data = jsons["sample_data.json"]
    ego_poses = jsons.get("ego_pose.json", [])
    annotations = jsons.get("annotation.json", [])
    instances = jsons.get("instance.json", [])

    sample_tokens = {s["sample_token"] for s in samples}
    ego_pose_tokens = {ep["ego_pose_token"] for ep in ego_poses}
    instance_tokens = {inst["instance_token"] for inst in instances}

    # 3. LiDAR file completeness
    # Find lidar keyframe sample_data records
    lidar_sds = [
        sd
        for sd in sample_data
        if sd.get("is_keyframe") and "LIDAR" in sd.get("channel", "").upper()
    ]

    for sd in lidar_sds:
        file_path = clip_dir / sd["file_path"]
        if not file_path.exists():
            issues.append(
                ValidationIssue(
                    "lidar_exists",
                    "error",
                    f"Missing LiDAR file: {sd['file_path']}",
                )
            )
            continue
        # Check format
        try:
            raw = np.fromfile(str(file_path), dtype=np.float32)
            if raw.size == 0:
                issues.append(
                    ValidationIssue(
                        "lidar_format",
                        "error",
                        f"Empty point cloud: {sd['file_path']}",
                    )
                )
            elif raw.size % 5 != 0:
                # Try other common strides
                valid = False
                for stride in [3, 4, 6]:
                    if raw.size % stride == 0:
                        valid = True
                        break
                if not valid:
                    issues.append(
                        ValidationIssue(
                            "lidar_format",
                            "warning",
                            f"Point cloud size {raw.size} not divisible by expected stride",
                            sd["file_path"],
                        )
                    )
        except Exception as e:
            issues.append(
                ValidationIssue(
                    "lidar_format",
                    "error",
                    f"Cannot read point cloud: {sd['file_path']}",
                    str(e),
                )
            )

    if not lidar_sds:
        issues.append(
            ValidationIssue("lidar_exists", "error", "No LiDAR keyframe data found")
        )

    # 4. Ego pose coverage
    for sd in lidar_sds:
        if sd.get("ego_pose_token") and sd["ego_pose_token"] not in ego_pose_tokens:
            issues.append(
                ValidationIssue(
                    "ego_pose_ref",
                    "error",
                    f"sample_data references missing ego_pose: {sd['ego_pose_token']}",
                )
            )

    # 5. Annotation integrity
    for ann in annotations:
        # Category check
        cat = ann.get("category", "")
        if cat not in KNOWN_CATEGORIES:
            issues.append(
                ValidationIssue(
                    "annotation_category",
                    "warning",
                    f"Unknown category: {cat}",
                    ann.get("annotation_token", ""),
                )
            )

        # Bbox dimensions
        bbox = ann.get("bbox_3d", {})
        size = bbox.get("size", {})
        for dim in ["length", "width", "height"]:
            val = size.get(dim, 0)
            if not isinstance(val, (int, float)) or val <= 0 or not np.isfinite(val):
                issues.append(
                    ValidationIssue(
                        "annotation_bbox",
                        "error",
                        f"Invalid bbox {dim}={val}",
                        ann.get("annotation_token", ""),
                    )
                )
                break

        # num_lidar_pts must be a non-negative integer (v0.5+: real-computed,
        # 0 means "no points in box", not a default placeholder).
        npts = ann.get("num_lidar_pts")
        if not isinstance(npts, int) or isinstance(npts, bool) or npts < 0:
            issues.append(
                ValidationIssue(
                    "annotation_num_lidar_pts",
                    "error",
                    f"Invalid num_lidar_pts={npts!r} (must be int >= 0)",
                    ann.get("annotation_token", ""),
                )
            )

        # Sample token reference
        if ann.get("sample_token") not in sample_tokens:
            issues.append(
                ValidationIssue(
                    "annotation_ref",
                    "error",
                    f"Annotation references missing sample: {ann.get('sample_token')}",
                )
            )

        # Instance token reference
        if ann.get("instance_token") and ann["instance_token"] not in instance_tokens:
            issues.append(
                ValidationIssue(
                    "annotation_ref",
                    "error",
                    f"Annotation references missing instance: {ann.get('instance_token')}",
                )
            )

    # 6. Prev/next chain integrity for samples
    for s in samples:
        if s.get("prev") and s["prev"] not in sample_tokens:
            issues.append(
                ValidationIssue(
                    "chain_integrity",
                    "warning",
                    f"Sample prev token not found: {s['prev']}",
                )
            )
        if s.get("next") and s["next"] not in sample_tokens:
            issues.append(
                ValidationIssue(
                    "chain_integrity",
                    "warning",
                    f"Sample next token not found: {s['next']}",
                )
            )

    return ValidationReport(clip_id=clip_id, issues=issues)
