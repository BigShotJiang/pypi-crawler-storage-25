"""Frozen dataclass models for X4D dataset entities.

All models are frozen (immutable) dataclasses. Array fields (translation,
rotation, size, velocity) are stored as numpy float64 arrays.

Coordinate conventions:
    - Quaternions: [qx, qy, qz, qw]
    - Translation: [x, y, z] in meters
    - Size: [length, width, height] in meters
    - Velocity: [vx, vy, vz] in m/s
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np


@dataclass(frozen=True)
class PointFormat:
    """Binary layout of a LiDAR point cloud .bin file.

    Each point is laid out as ``len(fields)`` consecutive scalars of the
    matching numpy dtype (``types[i]`` for ``fields[i]``). ``bytes_per_point``
    is the on-disk stride in bytes.

    Attributes:
        fields: Per-component field names, e.g. ``["x", "y", "z", "intensity", "time"]``.
        types: Per-component numpy dtype names, e.g. ``["float32", ...]``.
        bytes_per_point: Total bytes per point on disk (== sum of dtype sizes).
    """

    fields: tuple[str, ...]
    types: tuple[str, ...]
    bytes_per_point: int

    def __post_init__(self) -> None:
        # Normalise sequences → immutable tuples for free hashability.
        object.__setattr__(self, "fields", tuple(self.fields))
        object.__setattr__(self, "types", tuple(self.types))
        if len(self.fields) != len(self.types):
            raise ValueError(
                f"PointFormat: fields ({len(self.fields)}) and types "
                f"({len(self.types)}) must have equal length"
            )

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> PointFormat:
        return cls(
            fields=tuple(d["fields"]),
            types=tuple(d["types"]),
            bytes_per_point=int(d["bytes_per_point"]),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "fields": list(self.fields),
            "types": list(self.types),
            "bytes_per_point": self.bytes_per_point,
        }

    @property
    def num_fields(self) -> int:
        return len(self.fields)


@dataclass(frozen=True)
class SensorInfo:
    """Per-channel sensor metadata embedded in ``meta.json``.

    Attributes:
        modality: ``"lidar"`` or ``"camera"``.
        frame_id: ROS-style frame_id of this channel's stored data. Required by
            v0.6 schema; ``None`` on older clips. For fused outputs the producer
            should set this to the fusion target frame (e.g. ``"base_link"``).
        point_format: Binary point layout (LiDAR only; ``None`` for cameras).
        resolution: ``(width, height)`` in pixels (cameras only; ``None`` for LiDAR).
        extras: Any additional fields the producer wrote into the sensor dict.
            Preserved verbatim so ``to_dict()`` round-trips unknown keys.
    """

    modality: str
    frame_id: str | None = None
    point_format: PointFormat | None = None
    resolution: tuple[int, int] | None = None
    extras: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> SensorInfo:
        modality = d["modality"]
        frame_id = d.get("frame_id")
        pf_raw = d.get("point_format")
        point_format = PointFormat.from_dict(pf_raw) if pf_raw is not None else None
        res_raw = d.get("resolution")
        resolution = (int(res_raw[0]), int(res_raw[1])) if res_raw is not None else None
        known = {"modality", "frame_id", "point_format", "resolution"}
        extras = {k: v for k, v in d.items() if k not in known}
        return cls(
            modality=modality,
            frame_id=frame_id,
            point_format=point_format,
            resolution=resolution,
            extras=extras,
        )

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"modality": self.modality}
        if self.frame_id is not None:
            out["frame_id"] = self.frame_id
        if self.point_format is not None:
            out["point_format"] = self.point_format.to_dict()
        if self.resolution is not None:
            out["resolution"] = list(self.resolution)
        out.update(self.extras)
        return out


@dataclass(frozen=True)
class ClipMeta:
    """Metadata for an X4D clip (from meta.json).

    Attributes:
        clip_id: Unique clip identifier (e.g. "20180724_n015_scene-0061_000").
        schema_version: X4D format version (e.g. "0.5").
        session_id: Recording session identifier.
        vehicle_id: Vehicle identifier.
        capture_time_utc: Capture timestamp in ISO 8601 format.
        duration_s: Clip duration in seconds.
        num_keyframes: Number of keyframes (annotated frames).
        num_sweeps: Number of sweep frames (non-annotated intermediate frames).
        sensors: Per-channel sensor metadata, keyed by channel name. Each
            value is a ``SensorInfo`` carrying modality + (for LiDAR) the
            binary ``PointFormat`` describing the .bin file layout.
        annotation_frame_id: The ROS frame_id annotations are stored in.
            Required by v0.6 schema. ``None`` on older clips (callers can
            consult ``ClipLoader.annotation_frame_id`` for a back-compat
            fallback that infers ``"base_link"`` for v0.5 clips).
        ego_pose_frame_id: The ROS frame_id whose pose ``ego_pose.json``
            expresses in clip-local world. Required by v0.7 schema. ``None``
            on older clips (loader falls back to ``annotation_frame_id``).
    """

    clip_id: str
    schema_version: str
    session_id: str
    vehicle_id: str
    capture_time_utc: str
    duration_s: float
    num_keyframes: int
    num_sweeps: int
    sensors: dict[str, SensorInfo]
    annotation_frame_id: str | None = None
    ego_pose_frame_id: str | None = None


@dataclass(frozen=True)
class CalibratedSensor:
    """Static sensor extrinsic calibration.

    Attributes:
        token: Unique token for this calibrated sensor record.
        channel: Sensor channel name — equals the ROS frame_id of the sensor
            (e.g. "lidar_top", "cam_front_left").
        parent_frame: ROS frame_id of the parent in the calibration tree.
            v0.8 self-reference root: ``parent_frame == channel`` marks the root.
            Pre-v0.8 clips: parent is typically "base_link" (implicit root).
        modality: "lidar" or "camera".
        translation: (3,) float64 array — sensor position in parent frame [x, y, z] meters.
        rotation: (4,) float64 array — sensor orientation as quaternion [qx, qy, qz, qw].
        intrinsics: Full camera intrinsics dict (camera_model, fx, fy, cx, cy,
            image_width, image_height) or None for LiDAR.
        distortion: Distortion model dict (model + coefficients) or None.
    """

    token: str
    channel: str
    modality: str
    translation: np.ndarray
    rotation: np.ndarray
    intrinsics: dict | None
    distortion: dict | None
    parent_frame: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=np.float64))
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=np.float64))


@dataclass(frozen=True)
class EgoPose:
    """Ego vehicle pose at a specific timestamp (ego → world transform).

    The world frame is a local coordinate system where the first ego pose
    of the clip is approximately at the origin.

    Attributes:
        token: Unique token for this ego pose record.
        timestamp_us: Timestamp in microseconds.
        translation: (3,) float64 array — ego position in world frame [x, y, z] meters.
        rotation: (4,) float64 array — ego orientation as quaternion [qx, qy, qz, qw].
    """

    token: str
    timestamp_us: int
    translation: np.ndarray
    rotation: np.ndarray

    def __post_init__(self) -> None:
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=np.float64))
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=np.float64))


@dataclass(frozen=True)
class Sample:
    """A synchronized snapshot across all sensors at a timestamp.

    Attributes:
        token: Unique sample token.
        timestamp_us: Timestamp in microseconds.
        is_keyframe: True if this sample has annotations.
        prev: Token of previous sample in temporal order, or "" if first.
        next: Token of next sample in temporal order, or "" if last.
    """

    token: str
    timestamp_us: int
    is_keyframe: bool
    prev: str
    next: str


@dataclass(frozen=True)
class SampleData:
    """A single sensor observation (one channel at one timestamp).

    Attributes:
        token: Unique sample_data token.
        sample_token: Token of the parent sample.
        channel: Sensor channel name (e.g. "LIDAR_TOP", "CAM_FRONT").
        timestamp_us: Timestamp in microseconds.
        file_path: Relative path to the sensor data file within the clip directory.
        ego_pose_token: Token of the ego pose at this timestamp.
        calibrated_sensor_token: Token of the calibrated sensor for this channel.
        is_keyframe: True if this is a keyframe (annotated) observation.
        width: Image width in pixels (None for LiDAR).
        height: Image height in pixels (None for LiDAR).
        prev: Token of previous sample_data in same channel, or "" if first.
        next: Token of next sample_data in same channel, or "" if last.
    """

    token: str
    sample_token: str
    channel: str
    timestamp_us: int
    file_path: str
    ego_pose_token: str
    calibrated_sensor_token: str
    is_keyframe: bool
    width: int | None
    height: int | None
    prev: str
    next: str


@dataclass(frozen=True)
class Annotation:
    """A 3D bounding box annotation in the clip's vehicle-local annotation frame.

    Annotations are stored in whichever vehicle-local frame the producer
    declared via ``meta.annotation_frame_id`` (v0.6+) — typically ``"base_link"``
    for fused-lidar clips, ``"LIDAR_TOP"`` for nuScenes-style top-lidar clips,
    or another sensor's frame_id. The frame is rigid relative to ``base_link``
    via calibration, so per-sample timing is determined by ``sample_token``.
    For v0.5 clips without an explicit field, the convention is per-sample ego
    frame (== ``base_link``). Use ``ClipLoader.annotations_for_sample(..., frame=...)``
    to transform to ``"clip_world"`` or any other frame_id in the calibration tree.

    Attributes:
        token: Unique annotation token.
        sample_token: Token of the sample this annotation belongs to.
        instance_token: Token of the tracked object instance.
        category: Object category string (e.g. "car", "pedestrian").
        translation: (3,) float64 array — box center [x, y, z] in the
            annotation frame at this sample's timestamp.
        size: (3,) float64 array — box dimensions [length, width, height] in meters.
        rotation: (4,) float64 array — box orientation as quaternion [qx, qy, qz, qw],
            relative to the annotation frame.
        num_lidar_pts: Number of LiDAR points inside this box (real-counted, ≥ 0).
        visibility: Visibility level as string ("1" to "4", or "" if unknown).
        velocity: (3,) float64 array — velocity [vx, vy, vz] in m/s, in the
            annotation frame (forward = +x, left = +y), or None.
        attributes: List of attribute strings (e.g. ["vehicle.moving"]).
        prev: Token of previous annotation of same instance, or "" if first.
        next: Token of next annotation of same instance, or "" if last.
        score: Detection confidence score (None for ground truth, float for predictions).
    """

    token: str
    sample_token: str
    instance_token: str
    category: str
    translation: np.ndarray
    size: np.ndarray
    rotation: np.ndarray
    num_lidar_pts: int
    visibility: str
    velocity: np.ndarray | None
    attributes: list[str]
    prev: str
    next: str
    score: float | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=np.float64))
        object.__setattr__(self, "size", np.asarray(self.size, dtype=np.float64))
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=np.float64))
        if self.velocity is not None:
            object.__setattr__(self, "velocity", np.asarray(self.velocity, dtype=np.float64))


@dataclass(frozen=True)
class Instance:
    """A tracked object instance across multiple samples.

    Attributes:
        token: Unique instance token.
        category: Object category string.
        num_annotations: Total number of annotations for this instance.
        first_annotation_token: Token of the first annotation in temporal order.
        last_annotation_token: Token of the last annotation in temporal order.
    """

    token: str
    category: str
    num_annotations: int
    first_annotation_token: str
    last_annotation_token: str
