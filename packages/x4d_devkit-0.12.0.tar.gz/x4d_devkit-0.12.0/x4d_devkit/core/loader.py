"""ClipLoader: load an X4D clip directory into typed dataclasses.

Coordinate frames in this loader are *real frame_id strings only* — every
frame is either a node in the clip's calibration tree (e.g. ``"LIDAR_TOP"``,
``"base_link"``, ``"cam_front"``) or the constant ``"clip_world"`` for the
SLAM-anchored clip-local world. The legacy magic aliases ``"sensor"``,
``"ego"``, ``"world"`` are no longer accepted; use the helpers
:meth:`ClipLoader.sensor_frame_id`, :attr:`ClipLoader.ego_pose_frame_id`,
and :data:`CLIP_WORLD_FRAME_ID` instead.
"""

from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path
from typing import Any

import numpy as np

from x4d_devkit.core.models import (
    ClipMeta,
    CalibratedSensor,
    EgoPose,
    Sample,
    SampleData,
    Annotation,
    Instance,
    SensorInfo,
)
from x4d_devkit.core.transform import Transform, TransformChain, rotation_matrix_to_quat


CLIP_WORLD_FRAME_ID = "clip_world"
"""The constant frame_id of the SLAM-anchored clip-local world.

Defined by the X-4D dataset spec (v0.8+). Not a node in
``calibrated_sensor.json``; it is the dynamic edge wired through
``ego_pose.json`` (``ego_pose[t]: clip_world ← ego_pose_frame_id``).
"""

_MAGIC_FRAME_REPLACEMENTS = {
    "sensor": "loader.sensor_frame_id(sd)  (e.g. 'LIDAR_TOP')",
    "ego":    "loader.ego_pose_frame_id    (e.g. 'base_link')",
    "world":  f"the constant {CLIP_WORLD_FRAME_ID!r}  "
              "(also exported as x4d_devkit.core.loader.CLIP_WORLD_FRAME_ID)",
}


def _reject_magic_frame(frame: str) -> None:
    """Reject the legacy magic aliases ('sensor' / 'ego' / 'world') with a hint."""
    if frame in _MAGIC_FRAME_REPLACEMENTS:
        replacements = "; ".join(
            f"{alias!r} → {hint}" for alias, hint in _MAGIC_FRAME_REPLACEMENTS.items()
        )
        raise ValueError(
            f"frame {frame!r} is not a valid frame_id — the legacy magic aliases "
            f"'sensor', 'ego', 'world' were removed. Use real frame_ids instead: "
            f"{replacements}."
        )


class SchemaVersionMismatch(ValueError):
    """Raised when a clip's ``meta.schema_version`` doesn't match the consumer's expectations.

    Attributes:
        actual: the version found in ``meta.json``.
        expected: the version (or set of versions) the consumer required.
    """

    def __init__(self, actual: str, expected: "str | set[str]") -> None:
        self.actual = actual
        self.expected = expected
        if isinstance(expected, str):
            msg = f"clip schema_version is {actual!r}, expected {expected!r}"
        else:
            msg = f"clip schema_version is {actual!r}, expected one of {sorted(expected)!r}"
        super().__init__(msg)


class ClipLoader:
    """Load and index an X4D clip directory.

    Eagerly parses all JSON metadata into frozen dataclasses on construction.
    Binary sensor data (point clouds, images) is loaded on demand.

    Args:
        clip_dir: Path to a clip directory containing meta.json and other
            X4D JSON/binary files.

    Example::

        loader = ClipLoader("/data/clips/my_clip")
        print(loader.meta.clip_id)

        # Find lidar channels by modality — never hardcode "lidar" / "LIDAR_TOP".
        # The directory/channel name is producer-defined: nuScenes-converted clips
        # use "LIDAR_TOP", X-4D platform fused output uses "lidar", reconstruction
        # pipelines may use any name. Always look up via meta.sensors.
        lidar_channels = [
            ch for ch, info in loader.meta.sensors.items()
            if info.modality == "lidar"
        ]

        for sample in loader.samples:
            for sd in loader.sample_data_for_sample(sample.token):
                if sd.channel in lidar_channels:
                    pts = loader.load_point_cloud(sd, frame=loader.ego_pose_frame_id)

        # Annotations in their stored frame:
        anns = loader.annotations_for_sample(sample.token)
        # Or transform to clip-local world / a specific sensor frame:
        anns_world = loader.annotations_for_sample(sample.token, frame=CLIP_WORLD_FRAME_ID)
        anns_lidar = loader.annotations_for_sample(sample.token, frame="LIDAR_TOP")
    """

    def __init__(
        self,
        clip_dir: str | Path,
        *,
        expected_schema_version: "str | set[str] | None" = None,
    ) -> None:
        self._clip_dir = Path(clip_dir)

        # Load and parse all JSON
        self._meta = self._load_meta()
        if expected_schema_version is not None:
            self.require_schema_version(expected_schema_version)
        self._calibrated_sensors = self._load_calibrated_sensors()
        self._ego_poses = self._load_ego_poses()
        self._samples = self._load_samples()
        self._sample_data = self._load_sample_data()
        self._annotations = self._load_annotations()
        self._instances = self._load_instances()

        # Build global token → object index
        self._token_index: dict[str, Any] = {}
        for cs in self._calibrated_sensors:
            self._token_index[cs.token] = cs
        for ep in self._ego_poses:
            self._token_index[ep.token] = ep
        for s in self._samples:
            self._token_index[s.token] = s
        for sd in self._sample_data:
            self._token_index[sd.token] = sd
        for a in self._annotations:
            self._token_index[a.token] = a
        for i in self._instances:
            self._token_index[i.token] = i

        # Build auxiliary indices
        self._sd_by_channel: dict[str, list[SampleData]] = {}
        for sd in self._sample_data:
            self._sd_by_channel.setdefault(sd.channel, []).append(sd)
        for ch in self._sd_by_channel:
            self._sd_by_channel[ch].sort(key=lambda sd: sd.timestamp_us)

        self._sd_by_sample: dict[str, list[SampleData]] = {}
        for sd in self._sample_data:
            self._sd_by_sample.setdefault(sd.sample_token, []).append(sd)

        self._ann_by_sample: dict[str, list[Annotation]] = {}
        for a in self._annotations:
            self._ann_by_sample.setdefault(a.sample_token, []).append(a)

    def _read_json(self, name: str) -> Any:
        with open(self._clip_dir / name) as f:
            return json.load(f)

    def _load_meta(self) -> ClipMeta:
        d = self._read_json("meta.json")
        sensors = {
            channel: SensorInfo.from_dict(raw)
            for channel, raw in (d.get("sensors") or {}).items()
        }
        return ClipMeta(
            clip_id=d["clip_id"],
            schema_version=d["schema_version"],
            session_id=d["session_id"],
            vehicle_id=d["vehicle_id"],
            capture_time_utc=d["capture_time_utc"],
            duration_s=d["duration_s"],
            num_keyframes=d["keyframe_count"],
            num_sweeps=d["sweep_count"],
            sensors=sensors,
            annotation_frame_id=d.get("annotation_frame_id"),
            ego_pose_frame_id=d.get("ego_pose_frame_id"),
        )

    def _load_calibrated_sensors(self) -> list[CalibratedSensor]:
        records = self._read_json("calibrated_sensor.json")
        result = []
        for r in records:
            t = r["translation"]
            q = r["rotation"]
            intr = r.get("intrinsics")
            result.append(CalibratedSensor(
                token=r["calibrated_sensor_token"],
                channel=r["channel"],
                parent_frame=r.get("parent_frame"),
                modality="camera" if intr is not None else "lidar",
                translation=[t["x"], t["y"], t["z"]],
                rotation=[q["qx"], q["qy"], q["qz"], q["qw"]],
                intrinsics=intr,
                distortion=r.get("distortion"),
            ))
        return result

    def _load_ego_poses(self) -> list[EgoPose]:
        records = self._read_json("ego_pose.json")
        result = []
        for r in records:
            t = r["translation"]
            q = r["rotation"]
            result.append(EgoPose(
                token=r["ego_pose_token"],
                timestamp_us=r["timestamp_us"],
                translation=[t["x"], t["y"], t["z"]],
                rotation=[q["qx"], q["qy"], q["qz"], q["qw"]],
            ))
        result.sort(key=lambda ep: ep.timestamp_us)
        return result

    def _load_samples(self) -> list[Sample]:
        records = self._read_json("sample.json")
        result = []
        for r in records:
            result.append(Sample(
                token=r["sample_token"],
                timestamp_us=r["timestamp_us"],
                is_keyframe=r["is_keyframe"],
                prev=r["prev"] or "",
                next=r["next"] or "",
            ))
        result.sort(key=lambda s: s.timestamp_us)
        return result

    def _load_sample_data(self) -> list[SampleData]:
        records = self._read_json("sample_data.json")
        result = []
        for r in records:
            result.append(SampleData(
                token=r["sample_data_token"],
                sample_token=r["sample_token"],
                channel=r["channel"],
                timestamp_us=r["timestamp_us"],
                file_path=r["file_path"],
                ego_pose_token=r["ego_pose_token"],
                calibrated_sensor_token=r["calibrated_sensor_token"],
                is_keyframe=r["is_keyframe"],
                width=r.get("width"),
                height=r.get("height"),
                prev=r["prev"] or "",
                next=r["next"] or "",
            ))
        return result

    def _load_annotations(self) -> list[Annotation]:
        records = self._read_json("annotation.json")
        result = []
        for r in records:
            bbox = r["bbox_3d"]
            t = bbox["translation"]
            s = bbox["size"]
            q = bbox["rotation"]
            vel = r.get("velocity")
            result.append(Annotation(
                token=r["annotation_token"],
                sample_token=r["sample_token"],
                instance_token=r["instance_token"],
                category=r["category"],
                translation=[t["x"], t["y"], t["z"]],
                size=[s["length"], s["width"], s["height"]],
                rotation=[q["qx"], q["qy"], q["qz"], q["qw"]],
                num_lidar_pts=r["num_lidar_pts"],
                visibility=str(r["visibility"]) if r["visibility"] is not None else "",
                velocity=[vel["vx"], vel["vy"], vel["vz"]] if vel else None,
                attributes=r.get("attributes", []),
                prev=r["prev"] or "",
                next=r["next"] or "",
                score=r.get("score"),
            ))
        return result

    def _load_instances(self) -> list[Instance]:
        records = self._read_json("instance.json")
        return [
            Instance(
                token=r["instance_token"],
                category=r["category"],
                num_annotations=r["num_annotations"],
                first_annotation_token=r["first_annotation_token"],
                last_annotation_token=r["last_annotation_token"],
            )
            for r in records
        ]

    # --- Public API ---

    @property
    def clip_dir(self) -> Path:
        """Absolute path to the clip directory."""
        return self._clip_dir

    @property
    def meta(self) -> ClipMeta:
        """Clip metadata (from meta.json)."""
        return self._meta

    @property
    def schema_version(self) -> str:
        """Shortcut for ``self.meta.schema_version`` — the X-4D format version this clip was written in."""
        return self._meta.schema_version

    @property
    def annotation_frame_id(self) -> str:
        """The vehicle-local frame_id annotations are stored in.

        Returns ``meta.annotation_frame_id`` if explicitly set (v0.6+ clips).
        Pre-v0.6 clips fall back to ``"base_link"`` — the per-sample ego frame
        all earlier loader code already assumed.
        """
        if self._meta.annotation_frame_id is not None:
            return self._meta.annotation_frame_id
        return "base_link"

    @property
    def ego_pose_frame_id(self) -> str:
        """The frame_id whose pose ``ego_pose.json`` expresses in clip-local world.

        Returns ``meta.ego_pose_frame_id`` if explicitly set (v0.7+). Pre-v0.7
        clips fall back to ``annotation_frame_id`` — every X-4D and nuScenes
        clip pose is anchored to the same frame as its annotations.
        """
        if self._meta.ego_pose_frame_id is not None:
            return self._meta.ego_pose_frame_id
        return self.annotation_frame_id

    def frame_id_for_channel(self, channel: str) -> str:
        """Resolve the ROS frame_id of a sensor channel.

        Looks up ``meta.sensors[channel].frame_id`` (v0.6+). Falls back to the
        channel name itself for older clips, per the v0.4 ``channel ≡ frame_id``
        convention.
        """
        info = self._meta.sensors.get(channel)
        if info is not None and info.frame_id is not None:
            return info.frame_id
        return channel

    def sensor_frame_id(self, sd: SampleData) -> str:
        """ROS frame_id of the sensor that produced ``sd``.

        Sugar for ``frame_id_for_channel(sd.channel)`` — the canonical way to
        get the source frame_id for a piece of sample_data when calling
        :meth:`load_point_cloud` / :meth:`get_transform`.
        """
        return self.frame_id_for_channel(sd.channel)

    def require_schema_version(self, expected: "str | set[str]") -> None:
        """Raise ``SchemaVersionMismatch`` if the clip's schema_version isn't in ``expected``.

        Args:
            expected: a single version string (e.g. ``"0.5"``) or a set of accepted
                versions (e.g. ``{"0.4", "0.5"}``).

        Example::

            loader = ClipLoader(path)
            loader.require_schema_version("0.5")  # raises if not 0.5
        """
        actual = self._meta.schema_version
        if isinstance(expected, str):
            if actual != expected:
                raise SchemaVersionMismatch(actual, expected)
        else:
            if actual not in expected:
                raise SchemaVersionMismatch(actual, set(expected))

    @property
    def samples(self) -> list[Sample]:
        """All samples, sorted by timestamp."""
        return self._samples

    @property
    def sample_data(self) -> list[SampleData]:
        """All sample_data records across all channels."""
        return self._sample_data

    @property
    def ego_poses(self) -> list[EgoPose]:
        """All ego poses, sorted by timestamp."""
        return self._ego_poses

    @property
    def calibrated_sensors(self) -> list[CalibratedSensor]:
        """All calibrated sensor records (one per channel)."""
        return self._calibrated_sensors

    @property
    def annotations(self) -> list[Annotation]:
        """All annotations in their **native frame** (``annotation_frame_id``).

        Use ``annotations_for_sample(token, frame=...)`` to request a specific frame.
        """
        return self._annotations

    @property
    def instances(self) -> list[Instance]:
        """All tracked object instances."""
        return self._instances

    def get(self, token: str) -> Any:
        """O(1) lookup by token across all entity types.

        Args:
            token: Any entity token (sample, sample_data, annotation, etc.).

        Returns:
            The entity object matching the token.

        Raises:
            KeyError: If the token is not found.
        """
        return self._token_index[token]

    def sample_data_for_channel(self, channel: str) -> list[SampleData]:
        """Get all sample_data for a sensor channel, sorted by timestamp.

        Args:
            channel: Sensor channel name (e.g. "LIDAR_TOP", "CAM_FRONT").

        Returns:
            List of SampleData records for this channel, time-ordered.
        """
        return self._sd_by_channel.get(channel, [])

    def sample_data_for_sample(self, sample_token: str) -> list[SampleData]:
        """Get all sample_data records for a sample (all channels at that timestamp).

        Args:
            sample_token: The sample token.

        Returns:
            List of SampleData records (one per channel) for this sample.
        """
        return self._sd_by_sample.get(sample_token, [])

    def annotations_for_sample(
        self,
        sample_token: str,
        frame: str | None = None,
    ) -> list[Annotation]:
        """All annotations for a given sample, optionally transformed to ``frame``.

        Args:
            sample_token: The sample token.
            frame: Target frame_id. ``None`` (default) returns annotations in
                their stored frame (``loader.annotation_frame_id``). Any other
                value must be a real frame_id in the calibration tree, or the
                constant :data:`CLIP_WORLD_FRAME_ID`. The legacy magic aliases
                ``"sensor"``/``"ego"``/``"world"`` raise ``ValueError``.

        Returns:
            List of Annotation objects in the requested frame.
        """
        if frame is not None:
            _reject_magic_frame(frame)

        anns = self._ann_by_sample.get(sample_token, [])
        if not anns or frame is None or frame == self.annotation_frame_id:
            return anns

        sd = None
        if frame == CLIP_WORLD_FRAME_ID:
            sd = self._representative_sd_for_sample(sample_token)
        T = self.get_transform(self.annotation_frame_id, frame, sd=sd)
        return [self._transform_annotation(a, T) for a in anns]

    def load_point_cloud(
        self,
        sd: SampleData,
        frame: str | None = None,
    ) -> np.ndarray:
        """Load point cloud binary file as (N, C) float32 array.

        Args:
            sd: The SampleData record for the point cloud.
            frame: Target frame_id. ``None`` (default) returns raw sensor
                coordinates. Any other value must be a real frame_id in the
                calibration tree, or :data:`CLIP_WORLD_FRAME_ID`. The legacy
                magic aliases ``"sensor"``/``"ego"``/``"world"`` raise
                ``ValueError``.

        Returns:
            Point cloud as (N, C) float32 array with xyz in the requested frame.
        """
        if frame is not None:
            _reject_magic_frame(frame)

        sensor_info = self._meta.sensors[sd.channel]
        if sensor_info.point_format is None:
            raise ValueError(
                f"channel '{sd.channel}' has no point_format in meta.json — "
                f"cannot load as a point cloud (modality={sensor_info.modality})"
            )
        num_fields = sensor_info.point_format.num_fields

        path = self._clip_dir / sd.file_path
        raw = np.fromfile(str(path), dtype=np.float32)
        pts = raw.reshape(-1, num_fields)

        src_frame = self.sensor_frame_id(sd)
        if frame is None or frame == src_frame:
            return pts

        T = self.get_transform(src_frame, frame, sd=sd)
        pts[:, :3] = T.apply(pts[:, :3].astype(np.float64)).astype(np.float32)
        return pts

    def get_transform(
        self,
        from_frame: str,
        to_frame: str,
        *,
        sd: SampleData | None = None,
    ) -> Transform:
        """Build the SE(3) transform ``to_frame ← from_frame``.

        Both arguments are real frame_id strings (calibration-tree nodes or
        :data:`CLIP_WORLD_FRAME_ID`). When either side is ``CLIP_WORLD_FRAME_ID``
        the transform is dynamic and ``sd`` (or another ego_pose-bearing
        SampleData) must be supplied to fix the timestamp.

        Args:
            from_frame: Source frame_id.
            to_frame: Destination frame_id.
            sd: SampleData fixing the ego_pose for ``CLIP_WORLD_FRAME_ID``;
                omit when both frames are static (in the calibration tree).

        Returns:
            Transform such that ``p_to = T.apply(p_from)``.

        Raises:
            ValueError: if a magic alias is passed, or ``CLIP_WORLD_FRAME_ID``
                is requested without ``sd``.
            KeyError: if a frame_id is not in the calibration tree.
        """
        _reject_magic_frame(from_frame)
        _reject_magic_frame(to_frame)
        if from_frame == to_frame:
            return Transform.identity()
        T_root_from_src = self._root_from_frame(from_frame, sd=sd)
        T_root_from_dst = self._root_from_frame(to_frame, sd=sd)
        return T_root_from_dst.inverse @ T_root_from_src

    def load_image_path(self, sd: SampleData) -> Path:
        """Get the absolute path to an image file.

        Does not load the image — returns the path for use with OpenCV, PIL, etc.

        Args:
            sd: The SampleData record for a camera channel.

        Returns:
            Absolute Path to the image file.
        """
        return self._clip_dir / sd.file_path

    # --- Private helpers ---

    def _get_transform_chain(self) -> TransformChain:
        """Lazily initialize and return a TransformChain."""
        if not hasattr(self, "_transform_chain"):
            self._transform_chain = TransformChain(self)
        return self._transform_chain

    def _root_from_frame(
        self, frame_id: str, *, sd: SampleData | None = None,
    ) -> Transform:
        """Transform from ``frame_id`` to the calibration tree root.

        For :data:`CLIP_WORLD_FRAME_ID` the result is dynamic (depends on
        ``sd.ego_pose_token``); for any other frame it is the static walk
        through ``calibrated_sensor.json``.
        """
        chain = self._get_transform_chain()
        if frame_id != CLIP_WORLD_FRAME_ID:
            return chain.get_root_from_frame_id(frame_id)
        if sd is None:
            raise ValueError(
                f"frame {CLIP_WORLD_FRAME_ID!r} is dynamic — pass sd=<SampleData> "
                f"so the transform can be evaluated at the correct ego_pose."
            )
        ego_fid = self.ego_pose_frame_id
        T_root_from_ego = chain.get_root_from_frame_id(ego_fid)
        T_world_from_ego = chain.get_world_from_ego(sd.ego_pose_token)
        # T_root_from_world = T_root_from_ego @ T_world_from_ego.inverse
        return T_root_from_ego @ T_world_from_ego.inverse

    def _representative_sd_for_sample(self, sample_token: str) -> SampleData:
        """Pick a representative SampleData (preferring lidar) for a sample."""
        sds = self._sd_by_sample.get(sample_token, [])
        if not sds:
            raise ValueError(
                f"sample {sample_token!r} has no sample_data — cannot resolve "
                f"{CLIP_WORLD_FRAME_ID!r}."
            )
        cs_map = {cs.channel: cs for cs in self._calibrated_sensors}
        return next(
            (s for s in sds if cs_map.get(s.channel) and cs_map[s.channel].modality == "lidar"),
            sds[0],
        )

    @staticmethod
    def _transform_annotation(ann: Annotation, T: Transform) -> Annotation:
        """Apply a rigid transform to an annotation's pose, returning a new Annotation."""
        new_translation = T.apply(ann.translation)
        new_rotation_mat = T.rotation @ Transform.from_quat(
            [0, 0, 0], ann.rotation
        ).rotation
        new_quat = rotation_matrix_to_quat(new_rotation_mat)

        new_velocity = None
        if ann.velocity is not None:
            new_velocity = T.rotation @ ann.velocity

        return replace(
            ann,
            translation=new_translation,
            rotation=np.array(new_quat),
            velocity=new_velocity,
        )
