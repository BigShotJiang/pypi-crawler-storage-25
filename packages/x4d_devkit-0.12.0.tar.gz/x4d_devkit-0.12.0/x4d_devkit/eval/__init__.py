"""Evaluation layer for X4D dataset."""

from x4d_devkit.eval.api import boxes_from_clip, evaluate
from x4d_devkit.eval.box import Box
from x4d_devkit.eval.detection import (
    DetectionConfig,
    DetectionEval,
    DetectionResult,
    calc_ap,
    calc_tp,
    detzero_detection_config,
    nusc_detection_config,
)

__all__ = [
    "Box",
    "DetectionConfig",
    "DetectionEval",
    "DetectionResult",
    "boxes_from_clip",
    "calc_ap",
    "calc_tp",
    "detzero_detection_config",
    "evaluate",
    "nusc_detection_config",
]
