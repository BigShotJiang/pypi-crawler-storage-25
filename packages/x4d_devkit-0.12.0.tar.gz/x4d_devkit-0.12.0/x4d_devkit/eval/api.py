"""Pure-function detection evaluation API.

`evaluate(gt, pred, config)` consumes in-memory ``dict[str, list[Box]]``
without requiring on-disk clip directories — designed for the metric
callback hot path of training pipelines. Use ``boxes_from_clip(loader,
config)`` to build the dicts from a ``ClipLoader`` (replicating the
behaviour previously hidden inside ``DetectionEval._extract_boxes``).

The two-step split is intentional: extraction (which applies the
config's ``category_map`` and ``class_range``) is decoupled from
evaluation (per-class accumulate → AP → TP errors → NDS), so training
code that already has predictions in memory never has to round-trip
through disk.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from x4d_devkit.eval.box import Box
from x4d_devkit.eval.matching import MetricData, accumulate

if TYPE_CHECKING:
    from x4d_devkit.core.loader import ClipLoader
    from x4d_devkit.eval.detection import DetectionConfig, DetectionResult


TP_METRICS = ["trans_err", "scale_err", "orient_err", "vel_err", "attr_err"]


def _filter_for_eval(
    boxes: dict[str, list[Box]],
    class_names: list[str],
    class_range: dict[str, float],
    max_boxes: int | None = None,
) -> dict[str, list[Box]]:
    """Drop boxes whose category isn't in ``class_names`` or whose ego-frame
    XY distance exceeds the per-class range. Optionally cap predictions per
    sample (top-N by score)."""
    class_names_set = set(class_names)
    out: dict[str, list[Box]] = {}
    for sample_token, sample_boxes in boxes.items():
        kept = []
        for b in sample_boxes:
            if b.category not in class_names_set:
                continue
            r = class_range.get(b.category)
            if r is not None:
                if float(np.linalg.norm(b.translation[:2])) > r:
                    continue
            kept.append(b)
        if max_boxes is not None and len(kept) > max_boxes:
            kept.sort(key=lambda b: (b.score if b.score is not None else 0.0), reverse=True)
            kept = kept[:max_boxes]
        out[sample_token] = kept
    return out


def boxes_from_clip(
    clip: ClipLoader,
    config: DetectionConfig,
    *,
    apply_score_cap: bool = False,
) -> dict[str, list[Box]]:
    """Extract per-sample boxes from a ClipLoader, applying the config's
    category mapping and class-range distance filter.

    v0.5: annotations are already in per-sample ego frame, so the
    distance filter is just ``||translation[:2]||`` — no ego_pose
    subtraction.

    Args:
        clip: Source clip.
        config: Provides ``category_map``, ``class_names``, ``class_range``,
            and (when ``apply_score_cap=True``) ``max_boxes_per_sample``.
        apply_score_cap: Set to True for *prediction* clips so the per-sample
            top-K cap from ``config.max_boxes_per_sample`` is applied. GT
            extraction leaves it False.

    Returns:
        ``{sample_token: [Box, ...]}`` keyed exactly as ``evaluate()`` expects.
    """
    from x4d_devkit.eval.detection import map_category

    out: dict[str, list[Box]] = {}
    cap = config.max_boxes_per_sample if apply_score_cap else None
    for sample in clip.samples:
        anns = clip.annotations_for_sample(sample.token)
        kept: list[Box] = []
        for ann in anns:
            det_name = map_category(ann.category, config.category_map, config.class_names)
            if det_name is None or det_name not in config.class_range:
                continue
            dist = float(np.linalg.norm(ann.translation[:2]))
            if dist > config.class_range[det_name]:
                continue
            kept.append(Box(
                translation=ann.translation,
                size=ann.size,
                rotation=ann.rotation,
                category=det_name,
                score=ann.score,
                velocity=ann.velocity,
                attributes=list(ann.attributes),
            ))
        if cap is not None and len(kept) > cap:
            kept.sort(key=lambda b: (b.score if b.score is not None else 0.0), reverse=True)
            kept = kept[:cap]
        out[sample.token] = kept
    return out


def evaluate(
    gt: dict[str, list[Box]],
    pred: dict[str, list[Box]],
    config: DetectionConfig,
) -> DetectionResult:
    """Run detection evaluation on in-memory boxes.

    The training-pipeline entry point: feed dicts of ``Box`` instances
    keyed by sample_token, get back the same ``DetectionResult`` that
    ``DetectionEval.evaluate()`` produces. No disk I/O, no ClipLoader
    requirement.

    The function applies ``config.class_range`` distance filtering and the
    ``config.max_boxes_per_sample`` cap on predictions, but does **not**
    apply ``config.category_map`` — predictions are expected to already
    carry final class names. Use ``boxes_from_clip()`` if you need the
    mapping applied.

    Args:
        gt: ``{sample_token: [Box, ...]}`` for ground truth. Box.score
            should be ``None``.
        pred: ``{sample_token: [Box, ...]}`` for predictions. Box.score
            must be a float.
        config: Evaluation configuration.

    Returns:
        DetectionResult with mAP, NDS, per-class APs, and TP errors.
    """
    from x4d_devkit.eval.detection import DetectionResult, calc_ap, calc_tp

    cfg = config
    gt_f = _filter_for_eval(gt, cfg.class_names, cfg.class_range)
    pred_f = _filter_for_eval(
        pred, cfg.class_names, cfg.class_range, max_boxes=cfg.max_boxes_per_sample
    )
    for st in gt_f:
        pred_f.setdefault(st, [])

    metric_data: dict[str, dict[str, MetricData]] = {}
    for class_name in cfg.class_names:
        metric_data[class_name] = {}
        for dist_th in cfg.dist_thresholds:
            metric_data[class_name][str(dist_th)] = accumulate(
                gt_f, pred_f, class_name, dist_th
            )

    label_aps: dict[str, dict[str, float]] = {}
    for class_name in cfg.class_names:
        label_aps[class_name] = {}
        for dist_th in cfg.dist_thresholds:
            md = metric_data[class_name][str(dist_th)]
            label_aps[class_name][str(dist_th)] = calc_ap(md, cfg.min_recall, cfg.min_precision)

    mean_dist_aps = {
        cn: float(np.mean(list(label_aps[cn].values())))
        for cn in cfg.class_names
    }
    all_ap_values = [ap for cn_aps in label_aps.values() for ap in cn_aps.values()]
    mean_ap = float(np.mean(all_ap_values)) if all_ap_values else 0.0

    label_tp_errors: dict[str, dict[str, float]] = {}
    for class_name in cfg.class_names:
        md = metric_data[class_name][str(cfg.dist_th_tp)]
        label_tp_errors[class_name] = {}
        for metric_name in TP_METRICS:
            if class_name == "traffic_cone" and metric_name in ("attr_err", "vel_err", "orient_err"):
                label_tp_errors[class_name][metric_name] = float("nan")
            elif class_name == "barrier" and metric_name in ("attr_err", "vel_err"):
                label_tp_errors[class_name][metric_name] = float("nan")
            else:
                label_tp_errors[class_name][metric_name] = calc_tp(md, cfg.min_recall, metric_name)

    tp_errors = {}
    for metric_name in TP_METRICS:
        values = [label_tp_errors[cn][metric_name] for cn in cfg.class_names]
        tp_errors[metric_name] = float(np.nanmean(values))

    tp_scores = {m: max(0.0, 1.0 - tp_errors[m]) for m in TP_METRICS}
    nd_score = (cfg.mean_ap_weight * mean_ap + sum(tp_scores.values())) / (
        cfg.mean_ap_weight + len(tp_scores)
    )

    return DetectionResult(
        mean_ap=mean_ap,
        nd_score=nd_score,
        label_aps=label_aps,
        mean_dist_aps=mean_dist_aps,
        tp_errors=tp_errors,
        label_tp_errors=label_tp_errors,
        tp_scores=tp_scores,
    )
