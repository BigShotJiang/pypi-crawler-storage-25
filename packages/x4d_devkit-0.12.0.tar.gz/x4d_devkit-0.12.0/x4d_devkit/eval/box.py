"""Typed 3D bounding box for detection evaluation.

`Box` is the data shape that ``evaluate()`` and ``accumulate()`` consume.
It mirrors the fields previously expected as a dict (``translation``,
``size``, ``rotation``, ``category``, ``score``, ``velocity``,
``attributes``) but with type checking, frozen semantics, and
constructor helpers for common upstream LiDAR detection layouts.

GT vs. prediction is distinguished by ``score`` — None for ground truth,
float for predictions. ``sample_token`` is *not* a field on Box; it's
the key of the outer ``dict[str, list[Box]]`` passed to ``evaluate``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class Box:
    """A 3D bounding box for detection evaluation.

    Attributes:
        translation: (3,) float64 — box center [x, y, z] in meters,
            in **per-sample ego frame** (matching annotations v0.5).
        size: (3,) float64 — [length, width, height] in meters.
        rotation: (4,) float64 — box orientation as quaternion
            [qx, qy, qz, qw]. Last-w convention (nuScenes-compatible).
        category: Final detection class name (e.g. ``"car"``,
            ``"Vehicle"``). Class mapping from raw hierarchical labels
            (``"vehicle.car"`` → ``"car"``) is the caller's
            responsibility — ``Box.category`` is consumed verbatim.
        score: Detection confidence in [0, 1] for predictions, or
            ``None`` for ground truth.
        velocity: (3,) float64 [vx, vy, vz] in m/s in the same ego
            frame, or ``None`` if velocity is unknown. ``vel_err``
            (AVE) uses only the [:2] xy component.
        attributes: List of attribute strings (e.g.
            ``["vehicle.moving"]``). Empty list = no attributes.
    """

    translation: np.ndarray
    size: np.ndarray
    rotation: np.ndarray
    category: str
    score: float | None = None
    velocity: np.ndarray | None = None
    attributes: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        # Coerce array fields to float64 numpy arrays.
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=np.float64))
        object.__setattr__(self, "size", np.asarray(self.size, dtype=np.float64))
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=np.float64))
        if self.velocity is not None:
            object.__setattr__(self, "velocity", np.asarray(self.velocity, dtype=np.float64))

        if self.translation.shape != (3,):
            raise ValueError(
                f"Box.translation must be shape (3,), got {self.translation.shape}"
            )
        if self.size.shape != (3,):
            raise ValueError(
                f"Box.size must be shape (3,), got {self.size.shape}"
            )
        if self.rotation.shape != (4,):
            raise ValueError(
                f"Box.rotation must be shape (4,) [qx, qy, qz, qw], got {self.rotation.shape}"
            )

    @classmethod
    def from_xyzlwhyaw_vxvy(
        cls,
        bbox: Sequence[float] | np.ndarray,
        category: str,
        score: float | None = None,
        attributes: list[str] | None = None,
    ) -> Box:
        """Construct a Box from a 9-D LiDAR-frame array.

        Layout: ``[x, y, z, l, w, h, yaw, vx, vy]``. This is the de-facto
        encoding used by mmdetection3d's ``LiDARInstance3DBoxes`` (with
        velocity head), OpenPCDet, and DetZero. The yaw is converted to a
        quaternion ``[0, 0, sin(yaw/2), cos(yaw/2)]``; ``(vx, vy)`` is
        wrapped into a ``(3,)`` velocity array with ``vz = 0``.

        Use this in training-pipeline metric callbacks to convert per-batch
        detector outputs directly to evaluation-ready boxes — instead of
        passing ``rotation=[0, 0, 0, 1]`` placeholders that silently zero
        out the orientation error (AOE) component.

        Args:
            bbox: 9-element array ``[x, y, z, l, w, h, yaw, vx, vy]``.
            category: Final detection class name.
            score: Detection confidence (predictions) or None (GT).
            attributes: Optional attribute strings.

        Returns:
            A frozen Box.

        Raises:
            ValueError: If ``bbox`` is not 9-element.
        """
        b = np.asarray(bbox, dtype=np.float64)
        if b.shape != (9,):
            raise ValueError(
                f"bbox must be shape (9,) [x, y, z, l, w, h, yaw, vx, vy], got {b.shape}"
            )
        x, y, z, l, w, h, yaw, vx, vy = b
        half = 0.5 * float(yaw)
        rotation = np.array([0.0, 0.0, np.sin(half), np.cos(half)], dtype=np.float64)
        velocity = np.array([float(vx), float(vy), 0.0], dtype=np.float64)
        return cls(
            translation=np.array([x, y, z], dtype=np.float64),
            size=np.array([l, w, h], dtype=np.float64),
            rotation=rotation,
            category=category,
            score=score,
            velocity=velocity,
            attributes=list(attributes) if attributes is not None else [],
        )
