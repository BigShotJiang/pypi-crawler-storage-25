"""3D object detection evaluation: mAP, TP metrics, NDS.

The evaluator is **not** tied to any fixed set of categories.
All class names, distance ranges, and category mappings are injected
via ``DetectionConfig``.  Two ready-made presets are provided:

* ``nusc_detection_config()`` — nuScenes CVPR 2019 (10 classes)
* ``detzero_detection_config()`` — DetZero 3-class (Vehicle / Pedestrian / Cyclist)

Users can create their own ``DetectionConfig`` for any category set.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from x4d_devkit.eval.matching import MetricData

if TYPE_CHECKING:
    from x4d_devkit.core.loader import ClipLoader

TP_METRICS = ["trans_err", "scale_err", "orient_err", "vel_err", "attr_err"]

# ── Presets (convenience constants, NOT used by the evaluator directly) ──

NUSC_DETECTION_NAMES = [
    "car", "truck", "bus", "trailer", "construction_vehicle",
    "pedestrian", "motorcycle", "bicycle", "traffic_cone", "barrier",
]

NUSC_CLASS_RANGE = {
    "car": 50, "truck": 50, "bus": 50, "trailer": 50,
    "construction_vehicle": 50, "pedestrian": 40, "motorcycle": 40,
    "bicycle": 40, "traffic_cone": 30, "barrier": 30,
}

NUSC_CATEGORY_MAP: dict[str, str] = {
    "vehicle.car": "car",
    "vehicle.truck": "truck",
    "vehicle.bus.bendy": "bus",
    "vehicle.bus.rigid": "bus",
    "vehicle.trailer": "trailer",
    "vehicle.construction": "construction_vehicle",
    "human.pedestrian.adult": "pedestrian",
    "human.pedestrian.child": "pedestrian",
    "human.pedestrian.wheelchair": "pedestrian",
    "human.pedestrian.stroller": "pedestrian",
    "human.pedestrian.personal_mobility": "pedestrian",
    "human.pedestrian.police_officer": "pedestrian",
    "human.pedestrian.construction_worker": "pedestrian",
    "vehicle.motorcycle": "motorcycle",
    "vehicle.bicycle": "bicycle",
    "movable_object.trafficcone": "traffic_cone",
    "movable_object.barrier": "barrier",
}

DETZERO_DETECTION_NAMES = ["Vehicle", "Pedestrian", "Cyclist"]

DETZERO_CLASS_RANGE = {
    "Vehicle": 75, "Pedestrian": 50, "Cyclist": 50,
}

DETZERO_CATEGORY_MAP: dict[str, str] = {
    # nuScenes full names → DetZero classes
    "vehicle.car": "Vehicle",
    "vehicle.truck": "Vehicle",
    "vehicle.bus.bendy": "Vehicle",
    "vehicle.bus.rigid": "Vehicle",
    "vehicle.trailer": "Vehicle",
    "vehicle.construction": "Vehicle",
    "human.pedestrian.adult": "Pedestrian",
    "human.pedestrian.child": "Pedestrian",
    "human.pedestrian.wheelchair": "Pedestrian",
    "human.pedestrian.stroller": "Pedestrian",
    "human.pedestrian.personal_mobility": "Pedestrian",
    "human.pedestrian.police_officer": "Pedestrian",
    "human.pedestrian.construction_worker": "Pedestrian",
    "vehicle.motorcycle": "Cyclist",
    "vehicle.bicycle": "Cyclist",
    # Short names
    "car": "Vehicle", "truck": "Vehicle", "bus": "Vehicle",
    "trailer": "Vehicle", "construction_vehicle": "Vehicle",
    "pedestrian": "Pedestrian",
    "motorcycle": "Cyclist", "bicycle": "Cyclist",
}

# Backwards-compatible aliases
DETECTION_NAMES = NUSC_DETECTION_NAMES
CLASS_RANGE = NUSC_CLASS_RANGE
CATEGORY_MAP = NUSC_CATEGORY_MAP


def map_category(
    raw_category: str,
    category_map: dict[str, str] | None = None,
    class_names: list[str] | None = None,
) -> str | None:
    """Map a raw annotation category to a detection class name.

    Args:
        raw_category: The raw category string from the annotation.
        category_map: Mapping from raw names to detection class names.
            Falls back to ``NUSC_CATEGORY_MAP`` if *None*.
        class_names: Set of valid detection class names.
            If the raw category is already a valid class name, it is
            returned as-is.  Falls back to ``NUSC_DETECTION_NAMES``
            if *None*.

    Returns:
        Detection class name, or *None* if unrecognized.
    """
    if category_map is None:
        category_map = NUSC_CATEGORY_MAP
    if class_names is None:
        class_names = NUSC_DETECTION_NAMES

    if raw_category in category_map:
        return category_map[raw_category]
    if raw_category in class_names:
        return raw_category
    return None


@dataclass(frozen=True)
class DetectionConfig:
    """Evaluation configuration — fully user-controlled.

    All fields (class names, distance ranges, category mapping) are
    injected here.  Nothing is hardcoded in the evaluator.
    """
    class_names: list[str]
    dist_thresholds: list[float]
    dist_th_tp: float
    min_recall: float
    min_precision: float
    max_boxes_per_sample: int
    class_range: dict[str, float]
    category_map: dict[str, str] = field(default_factory=dict)
    num_recall_points: int = 101
    mean_ap_weight: int = 5


def nusc_detection_config() -> DetectionConfig:
    """Return nuScenes CVPR2019 standard detection evaluation config (10 classes)."""
    return DetectionConfig(
        class_names=list(NUSC_DETECTION_NAMES),
        dist_thresholds=[0.5, 1.0, 2.0, 4.0],
        dist_th_tp=2.0,
        min_recall=0.1,
        min_precision=0.1,
        max_boxes_per_sample=500,
        class_range=dict(NUSC_CLASS_RANGE),
        category_map=dict(NUSC_CATEGORY_MAP),
    )


def detzero_detection_config() -> DetectionConfig:
    """Return DetZero 3-class detection evaluation config."""
    return DetectionConfig(
        class_names=list(DETZERO_DETECTION_NAMES),
        dist_thresholds=[0.5, 1.0, 2.0, 4.0],
        dist_th_tp=2.0,
        min_recall=0.1,
        min_precision=0.1,
        max_boxes_per_sample=500,
        class_range=dict(DETZERO_CLASS_RANGE),
        category_map=dict(DETZERO_CATEGORY_MAP),
    )


@dataclass
class DetectionResult:
    """Result of a detection evaluation.

    Attributes:
        mean_ap: Mean Average Precision across all classes and distance thresholds.
        nd_score: nuScenes Detection Score (NDS) — weighted combination of mAP and TP scores.
        label_aps: Per-class, per-distance-threshold AP values.
            ``label_aps["car"]["0.5"]`` = AP for cars at 0.5m threshold.
        mean_dist_aps: Per-class AP averaged across distance thresholds.
        tp_errors: Mean TP errors across all classes (trans_err, scale_err,
            orient_err, vel_err, attr_err).
        label_tp_errors: Per-class TP errors at the ``dist_th_tp`` threshold.
        tp_scores: TP scores (1 - error), clamped to [0, 1].
    """

    mean_ap: float
    nd_score: float
    label_aps: dict[str, dict[str, float]]
    mean_dist_aps: dict[str, float]
    tp_errors: dict[str, float]
    label_tp_errors: dict[str, dict[str, float]]
    tp_scores: dict[str, float]


def calc_ap(md: MetricData, min_recall: float, min_precision: float) -> float:
    """Calculate Average Precision from MetricData."""
    prec = np.copy(md.precision)
    prec = prec[round(100 * min_recall) + 1:]
    prec -= min_precision
    prec[prec < 0] = 0
    if len(prec) == 0:
        return 0.0
    return float(np.mean(prec) / (1.0 - min_precision))


def calc_tp(md: MetricData, min_recall: float, metric_name: str) -> float:
    """Calculate mean TP metric between min_recall and max_recall."""
    first_ind = round(100 * min_recall) + 1
    last_ind = md.max_recall_ind
    if last_ind < first_ind:
        return 1.0
    metric_arr = getattr(md, metric_name)
    return float(np.nanmean(metric_arr[first_ind:last_ind + 1]))


# Deprecated aliases — removed in 0.7.0. Use calc_ap / calc_tp.
_calc_ap = calc_ap
_calc_tp = calc_tp


class DetectionEval:
    """3D object detection evaluator.

    Computes mAP, TP metrics (ATE, ASE, AOE, AVE, AAE), and NDS
    following the nuScenes detection evaluation protocol.

    Args:
        gt_clips: List of ClipLoader instances with ground truth annotations.
        pred_clips: List of ClipLoader instances with predicted annotations
            (each annotation should have a ``score`` field).
        config: Evaluation configuration. Defaults to ``nusc_detection_config()``.

    Example::

        from x4d_devkit import ClipLoader, DetectionEval
        from x4d_devkit.eval import nusc_detection_config

        gt = [ClipLoader(p) for p in gt_dirs]
        pred = [ClipLoader(p) for p in pred_dirs]
        result = DetectionEval(gt, pred).evaluate()
        print(f"mAP={result.mean_ap:.3f}  NDS={result.nd_score:.3f}")
    """

    def __init__(
        self,
        gt_clips: list[ClipLoader],
        pred_clips: list[ClipLoader],
        config: DetectionConfig | None = None,
    ) -> None:
        self._gt_clips = gt_clips
        self._pred_clips = pred_clips
        self._config = config or nusc_detection_config()

    def evaluate(self) -> DetectionResult:
        """Run the evaluation and return results.

        Returns:
            DetectionResult with mAP, NDS, per-class APs, and TP errors.
        """
        from x4d_devkit.eval.api import boxes_from_clip, evaluate as _evaluate

        cfg = self._config
        gt_by_id = {c.meta.clip_id: c for c in self._gt_clips}
        pred_by_id = {c.meta.clip_id: c for c in self._pred_clips}

        all_gt: dict[str, list] = {}
        all_pred: dict[str, list] = {}

        for clip_id, gt_clip in gt_by_id.items():
            for st, boxes in boxes_from_clip(gt_clip, cfg).items():
                all_gt[st] = boxes
            pred_clip = pred_by_id.get(clip_id)
            if pred_clip is not None:
                for st, boxes in boxes_from_clip(pred_clip, cfg, apply_score_cap=True).items():
                    all_pred[st] = boxes

        return _evaluate(all_gt, all_pred, cfg)
