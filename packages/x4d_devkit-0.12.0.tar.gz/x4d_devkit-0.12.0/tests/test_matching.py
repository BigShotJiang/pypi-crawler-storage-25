# tests/test_matching.py
"""Unit tests for detection matching with synthetic data."""

import numpy as np
import pytest

from x4d_devkit.eval import Box
from x4d_devkit.eval.matching import MetricData, accumulate


def _make_box(translation, size, rotation, category, score=None,
              velocity=None, attributes=None):
    """Helper to construct a Box matching what accumulate() expects."""
    return Box(
        translation=np.asarray(translation, dtype=float),
        size=np.asarray(size, dtype=float),
        rotation=np.asarray(rotation, dtype=float),
        category=category,
        score=score,
        velocity=np.asarray(velocity, dtype=float) if velocity is not None else None,
        attributes=attributes or [],
    )


class TestMetricData:
    def test_no_predictions(self):
        md = MetricData.no_predictions()
        assert md.recall.shape == (101,)
        assert md.precision.shape == (101,)
        assert md.recall[0] == 0.0
        assert md.precision[0] == 0.0


class TestAccumulate:
    def test_perfect_match(self):
        gt_boxes = {"sample1": [_make_box([10, 20, 1], [4, 2, 1.5], [0, 0, 0, 1], "car")]}
        pred_boxes = {"sample1": [_make_box([10, 20, 1], [4, 2, 1.5], [0, 0, 0, 1], "car", score=0.9)]}
        md = accumulate(gt_boxes, pred_boxes, "car", dist_th=2.0)
        assert md.max_recall_ind == 100

    def test_no_predictions(self):
        gt_boxes = {"sample1": [_make_box([10, 20, 1], [4, 2, 1.5], [0, 0, 0, 1], "car")]}
        pred_boxes = {"sample1": []}
        md = accumulate(gt_boxes, pred_boxes, "car", dist_th=2.0)
        assert md.max_recall_ind == 0

    def test_false_positive(self):
        gt_boxes = {"sample1": [_make_box([10, 20, 1], [4, 2, 1.5], [0, 0, 0, 1], "car")]}
        pred_boxes = {"sample1": [_make_box([100, 200, 1], [4, 2, 1.5], [0, 0, 0, 1], "car", score=0.9)]}
        md = accumulate(gt_boxes, pred_boxes, "car", dist_th=2.0)
        assert md.max_recall_ind == 0

    def test_multiple_preds_one_gt(self):
        gt_boxes = {"sample1": [_make_box([10, 20, 1], [4, 2, 1.5], [0, 0, 0, 1], "car")]}
        pred_boxes = {"sample1": [
            _make_box([10, 20, 1], [4, 2, 1.5], [0, 0, 0, 1], "car", score=0.9),
            _make_box([10, 20.5, 1], [4, 2, 1.5], [0, 0, 0, 1], "car", score=0.8),
        ]}
        md = accumulate(gt_boxes, pred_boxes, "car", dist_th=2.0)
        assert md.max_recall_ind == 100

    def test_filters_by_class(self):
        gt_boxes = {"sample1": [
            _make_box([10, 20, 1], [4, 2, 1.5], [0, 0, 0, 1], "car"),
            _make_box([30, 40, 1], [6, 2.5, 2], [0, 0, 0, 1], "truck"),
        ]}
        pred_boxes = {"sample1": [
            _make_box([10, 20, 1], [4, 2, 1.5], [0, 0, 0, 1], "car", score=0.9),
        ]}
        md = accumulate(gt_boxes, pred_boxes, "car", dist_th=2.0)
        assert md.max_recall_ind == 100

    def test_trans_err_recorded(self):
        gt_boxes = {"sample1": [_make_box([10, 20, 1], [4, 2, 1.5], [0, 0, 0, 1], "car")]}
        pred_boxes = {"sample1": [_make_box([10.5, 20, 1], [4, 2, 1.5], [0, 0, 0, 1], "car", score=0.9)]}
        md = accumulate(gt_boxes, pred_boxes, "car", dist_th=2.0)
        assert md.trans_err[100] == pytest.approx(0.5, abs=0.01)
