"""Unit tests for the in-memory evaluate() pure function."""

import numpy as np
import pytest

from x4d_devkit.eval import (
    Box,
    DetectionConfig,
    DetectionResult,
    evaluate,
    nusc_detection_config,
)


def _gt_box(x, y, z, category="car"):
    return Box(
        translation=[x, y, z], size=[4.0, 2.0, 1.5],
        rotation=[0.0, 0.0, 0.0, 1.0], category=category,
        velocity=[0.0, 0.0, 0.0], attributes=[],
    )


def _pred_box(x, y, z, score, category="car"):
    return Box(
        translation=[x, y, z], size=[4.0, 2.0, 1.5],
        rotation=[0.0, 0.0, 0.0, 1.0], category=category,
        score=score, velocity=[0.0, 0.0, 0.0], attributes=[],
    )


def _tiny_config(class_names=("car",)) -> DetectionConfig:
    """Single-class config with NUSC-style thresholds, no traffic_cone/barrier
    special cases hitting our class."""
    cn = list(class_names)
    return DetectionConfig(
        class_names=cn,
        dist_thresholds=[0.5, 1.0, 2.0, 4.0],
        dist_th_tp=2.0,
        min_recall=0.1,
        min_precision=0.1,
        max_boxes_per_sample=500,
        class_range={c: 50.0 for c in cn},
        category_map={},
    )


class TestEvaluatePerfect:
    def test_perfect_single_class_single_sample(self):
        cfg = _tiny_config()
        gt = {"s1": [_gt_box(10, 20, 1)]}
        pred = {"s1": [_pred_box(10, 20, 1, score=0.9)]}
        result = evaluate(gt, pred, cfg)
        assert isinstance(result, DetectionResult)
        assert result.mean_ap == pytest.approx(1.0)
        assert result.mean_dist_aps["car"] == pytest.approx(1.0)
        assert result.label_tp_errors["car"]["trans_err"] < 1e-6
        assert result.label_tp_errors["car"]["scale_err"] < 1e-6
        assert result.nd_score > 0.9

    def test_perfect_multi_sample(self):
        cfg = _tiny_config()
        gt = {f"s{i}": [_gt_box(10 + i, 0, 0)] for i in range(5)}
        pred = {f"s{i}": [_pred_box(10 + i, 0, 0, score=0.9)] for i in range(5)}
        result = evaluate(gt, pred, cfg)
        assert result.mean_ap == pytest.approx(1.0)


class TestEvaluateNoisy:
    def test_translation_noise_increases_trans_err(self):
        cfg = _tiny_config()
        rng = np.random.default_rng(7)
        gt = {f"s{i}": [_gt_box(10.0 * i, 0, 0)] for i in range(20)}
        pred = {
            f"s{i}": [_pred_box(10.0 * i + rng.normal(0, 0.5), 0, 0, score=0.9)]
            for i in range(20)
        }
        result = evaluate(gt, pred, cfg)
        assert result.label_tp_errors["car"]["trans_err"] > 0.1
        assert result.label_tp_errors["car"]["trans_err"] < 2.0


class TestEvaluateEmpty:
    def test_empty_predictions_zero_ap(self):
        cfg = _tiny_config()
        gt = {"s1": [_gt_box(10, 20, 1)]}
        pred = {"s1": []}
        result = evaluate(gt, pred, cfg)
        assert result.mean_ap == pytest.approx(0.0)

    def test_no_gt_for_class_zero_ap(self):
        cfg = _tiny_config()
        gt = {"s1": []}
        pred = {"s1": [_pred_box(10, 20, 1, score=0.9)]}
        result = evaluate(gt, pred, cfg)
        assert result.mean_ap == pytest.approx(0.0)

    def test_pred_sample_missing_from_gt_treated_as_empty_gt(self):
        cfg = _tiny_config()
        gt = {"s1": [_gt_box(10, 20, 1)]}
        pred = {"s2": [_pred_box(10, 20, 1, score=0.9)]}
        result = evaluate(gt, pred, cfg)
        assert result.mean_ap == pytest.approx(0.0)


class TestEvaluateClassRangeFilter:
    def test_filters_far_boxes(self):
        cfg = _tiny_config()
        cfg = DetectionConfig(
            class_names=["car"],
            dist_thresholds=cfg.dist_thresholds,
            dist_th_tp=cfg.dist_th_tp,
            min_recall=cfg.min_recall,
            min_precision=cfg.min_precision,
            max_boxes_per_sample=cfg.max_boxes_per_sample,
            class_range={"car": 10.0},
            category_map={},
        )
        gt = {"s1": [_gt_box(100, 0, 0), _gt_box(5, 0, 0)]}
        pred = {"s1": [_pred_box(5, 0, 0, score=0.9)]}
        result = evaluate(gt, pred, cfg)
        # The far GT box is filtered out, near GT matches → AP = 1.0.
        assert result.mean_ap == pytest.approx(1.0)


class TestEvaluateMaxBoxesPerSample:
    def test_low_score_predictions_dropped_when_capped(self):
        cfg = DetectionConfig(
            class_names=["car"],
            dist_thresholds=[0.5, 1.0, 2.0, 4.0],
            dist_th_tp=2.0,
            min_recall=0.1, min_precision=0.1,
            max_boxes_per_sample=1,
            class_range={"car": 50.0},
            category_map={},
        )
        gt = {"s1": [_gt_box(10, 0, 0)]}
        pred = {"s1": [
            _pred_box(40, 0, 0, score=0.95),  # high-score FP, kept by cap
            _pred_box(10, 0, 0, score=0.10),  # low-score TP, dropped by cap
        ]}
        result = evaluate(gt, pred, cfg)
        # The TP was dropped, only FP remains → mAP near 0.
        assert result.mean_ap < 0.1


class TestEvaluateMatchesDetectionEval:
    """evaluate() is what DetectionEval.evaluate() delegates to — sanity-check
    they produce identical numbers when fed equivalent inputs."""

    def test_no_gt_no_pred_zero(self):
        cfg = _tiny_config()
        result = evaluate({}, {}, cfg)
        assert result.mean_ap == 0.0
        assert result.label_aps["car"]["0.5"] == 0.0
