"""Tests for ClipLoader coordinate frame support — frame-graph (post-magic-string) API.

The new contract: every frame is a real frame_id string (a node in the
calibration tree) plus the constant ``"clip_world"`` for the SLAM-anchored
clip-local world. The legacy magic strings ``"sensor"``, ``"ego"``, ``"world"``
are rejected to remove the "did you mean my-actual-frame_id-string?" foot-gun.

Unit tests use synthetic data (no nuScenes dependency). Integration tests
require nuScenes mini data.
"""

import json
import os
from pathlib import Path

import numpy as np
import pytest

from x4d_devkit.core.loader import ClipLoader


CLIP_WORLD = "clip_world"


# ---------------------------------------------------------------------------
# Synthetic clip fixture
# ---------------------------------------------------------------------------

def _make_synthetic_clip(tmp_path: Path) -> Path:
    """Create a minimal synthetic clip for unit testing."""
    clip_dir = tmp_path / "synthetic_clip"
    clip_dir.mkdir()

    # -- meta.json --
    (clip_dir / "meta.json").write_text(json.dumps({
        "clip_id": "test-clip",
        "schema_version": "0.2",
        "session_id": "sess-001",
        "vehicle_id": "veh-001",
        "capture_time_utc": "2026-01-01T00:00:00Z",
        "duration_s": 1.0,
        "keyframe_count": 2,
        "sweep_count": 0,
        "sensors": {
            "LIDAR_TOP": {
                "modality": "lidar",
                "point_format": {
                    "fields": ["x", "y", "z", "intensity"],
                    "types": ["float32"] * 4,
                    "bytes_per_point": 16,
                },
            },
            "CAM_FRONT": {
                "modality": "camera",
            }
        }
    }))

    # -- calibrated_sensor.json --
    # LiDAR: translated 1m up (z=1), no rotation
    # Camera: translated 0.5m forward (x=0.5), no rotation
    (clip_dir / "calibrated_sensor.json").write_text(json.dumps([
        {
            "calibrated_sensor_token": "cs-lidar",
            "channel": "LIDAR_TOP",
            "translation": {"x": 0.0, "y": 0.0, "z": 1.0},
            "rotation": {"qx": 0.0, "qy": 0.0, "qz": 0.0, "qw": 1.0},
            "intrinsics": None,
            "distortion": None,
        },
        {
            "calibrated_sensor_token": "cs-cam",
            "channel": "CAM_FRONT",
            "translation": {"x": 0.5, "y": 0.0, "z": 0.8},
            "rotation": {"qx": 0.0, "qy": 0.0, "qz": 0.0, "qw": 1.0},
            "intrinsics": {"camera_model": "pinhole",
                           "fx": 1000, "fy": 1000, "cx": 320, "cy": 240,
                           "image_width": 640, "image_height": 480},
            "distortion": None,
        },
    ]))

    # -- ego_pose.json --
    # Frame 0: ego at origin
    # Frame 1: ego moved 10m forward (x=10)
    (clip_dir / "ego_pose.json").write_text(json.dumps([
        {
            "ego_pose_token": "ep-0",
            "timestamp_us": 1000000,
            "translation": {"x": 0.0, "y": 0.0, "z": 0.0},
            "rotation": {"qx": 0.0, "qy": 0.0, "qz": 0.0, "qw": 1.0},
        },
        {
            "ego_pose_token": "ep-1",
            "timestamp_us": 1500000,
            "translation": {"x": 10.0, "y": 0.0, "z": 0.0},
            "rotation": {"qx": 0.0, "qy": 0.0, "qz": 0.0, "qw": 1.0},
        },
    ]))

    # -- sample.json --
    (clip_dir / "sample.json").write_text(json.dumps([
        {
            "sample_token": "s-0",
            "timestamp_us": 1000000,
            "is_keyframe": True,
            "prev": None,
            "next": "s-1",
        },
        {
            "sample_token": "s-1",
            "timestamp_us": 1500000,
            "is_keyframe": True,
            "prev": "s-0",
            "next": None,
        },
    ]))

    # -- sample_data.json --
    lidar_dir = clip_dir / "LIDAR_TOP"
    lidar_dir.mkdir()

    (clip_dir / "sample_data.json").write_text(json.dumps([
        {
            "sample_data_token": "sd-lidar-0",
            "sample_token": "s-0",
            "channel": "LIDAR_TOP",
            "timestamp_us": 1000000,
            "file_path": "LIDAR_TOP/frame0.bin",
            "ego_pose_token": "ep-0",
            "calibrated_sensor_token": "cs-lidar",
            "is_keyframe": True,
            "width": None,
            "height": None,
            "prev": None,
            "next": "sd-lidar-1",
        },
        {
            "sample_data_token": "sd-lidar-1",
            "sample_token": "s-1",
            "channel": "LIDAR_TOP",
            "timestamp_us": 1500000,
            "file_path": "LIDAR_TOP/frame1.bin",
            "ego_pose_token": "ep-1",
            "calibrated_sensor_token": "cs-lidar",
            "is_keyframe": True,
            "width": None,
            "height": None,
            "prev": "sd-lidar-0",
            "next": None,
        },
    ]))

    # -- point cloud binary files --
    # 4 points at known positions: (1,0,0), (0,1,0), (0,0,1), (5,5,0)
    # 4 fields: x, y, z, intensity
    pts = np.array([
        [1.0, 0.0, 0.0, 0.5],
        [0.0, 1.0, 0.0, 0.5],
        [0.0, 0.0, 1.0, 0.5],
        [5.0, 5.0, 0.0, 0.5],
    ], dtype=np.float32)
    pts.tofile(str(lidar_dir / "frame0.bin"))
    pts.tofile(str(lidar_dir / "frame1.bin"))

    # -- annotation.json (v0.5: per-sample ego frame; here ann_frame == base_link) --
    # s-0 ego at origin; s-1 ego at (10, 0, 0). Same world pos (5,3,0) and (10,3,0)
    # for the two frames maps to ego (5,3,0) and (0,3,0) respectively.
    (clip_dir / "annotation.json").write_text(json.dumps([
        {
            "annotation_token": "ann-0",
            "sample_token": "s-0",
            "instance_token": "inst-0",
            "category": "car",
            "bbox_3d": {
                "translation": {"x": 5.0, "y": 3.0, "z": 0.0},
                "size": {"length": 4.5, "width": 2.0, "height": 1.5},
                "rotation": {"qx": 0.0, "qy": 0.0, "qz": 0.0, "qw": 1.0},
            },
            "num_lidar_pts": 100,
            "visibility": "4",
            "velocity": {"vx": 5.0, "vy": 0.0, "vz": 0.0},
            "attributes": [],
            "prev": None,
            "next": "ann-1",
            "score": None,
        },
        {
            "annotation_token": "ann-1",
            "sample_token": "s-1",
            "instance_token": "inst-0",
            "category": "car",
            "bbox_3d": {
                "translation": {"x": 0.0, "y": 3.0, "z": 0.0},
                "size": {"length": 4.5, "width": 2.0, "height": 1.5},
                "rotation": {"qx": 0.0, "qy": 0.0, "qz": 0.0, "qw": 1.0},
            },
            "num_lidar_pts": 90,
            "visibility": "4",
            "velocity": {"vx": 5.0, "vy": 0.0, "vz": 0.0},
            "attributes": [],
            "prev": "ann-0",
            "next": None,
            "score": None,
        },
    ]))

    # -- instance.json --
    (clip_dir / "instance.json").write_text(json.dumps([
        {
            "instance_token": "inst-0",
            "category": "car",
            "num_annotations": 2,
            "first_annotation_token": "ann-0",
            "last_annotation_token": "ann-1",
        },
    ]))

    return clip_dir


@pytest.fixture(scope="module")
def synthetic_clip(tmp_path_factory):
    return _make_synthetic_clip(tmp_path_factory.mktemp("synth"))


@pytest.fixture(scope="module")
def loader(synthetic_clip):
    return ClipLoader(synthetic_clip)


# ---------------------------------------------------------------------------
# Frame-id helpers (the user-facing way to discover frame names)
# ---------------------------------------------------------------------------

class TestFrameIdHelpers:
    def test_ego_pose_frame_id_exposes_ego_frame(self, loader):
        # v0.2 fallback chain: meta.ego_pose_frame_id None → annotation_frame_id None → "base_link".
        assert loader.ego_pose_frame_id == "base_link"

    def test_annotation_frame_id_exposed(self, loader):
        assert loader.annotation_frame_id == "base_link"

    def test_sensor_frame_id_returns_channel_frame(self, loader):
        sd = loader.sample_data_for_channel("LIDAR_TOP")[0]
        # v0.2 has no per-sensor frame_id, falls back to channel name.
        assert loader.sensor_frame_id(sd) == "LIDAR_TOP"

    def test_clip_world_constant_is_string_literal(self):
        # The spec pins this name. Any consumer can pass it as a regular frame.
        from x4d_devkit.core.loader import CLIP_WORLD_FRAME_ID
        assert CLIP_WORLD_FRAME_ID == "clip_world"


# ---------------------------------------------------------------------------
# load_point_cloud — explicit frame_id, no magic strings
# ---------------------------------------------------------------------------

class TestLoadPointCloudFrames:
    def test_no_frame_returns_raw_sensor(self, loader):
        """Default (no frame=) returns the raw sensor data unchanged."""
        sd = loader.sample_data_for_channel("LIDAR_TOP")[0]
        pts = loader.load_point_cloud(sd)
        assert pts.shape == (4, 4)
        np.testing.assert_allclose(pts[0, :3], [1.0, 0.0, 0.0], atol=1e-6)

    def test_frame_equal_to_sensor_frame_is_noop(self, loader):
        """Passing the sensor's own frame_id matches the no-frame default."""
        sd = loader.sample_data_for_channel("LIDAR_TOP")[0]
        pts_default = loader.load_point_cloud(sd)
        pts_explicit = loader.load_point_cloud(sd, frame=loader.sensor_frame_id(sd))
        np.testing.assert_array_equal(pts_default, pts_explicit)

    def test_frame_equal_to_ego_applies_calibration(self, loader):
        """frame=ego_pose_frame_id applies sensor-to-ego (z+1 for LIDAR_TOP)."""
        sd = loader.sample_data_for_channel("LIDAR_TOP")[0]
        pts = loader.load_point_cloud(sd, frame=loader.ego_pose_frame_id)
        np.testing.assert_allclose(pts[0, :3], [1.0, 0.0, 1.0], atol=1e-5)
        np.testing.assert_allclose(pts[2, :3], [0.0, 0.0, 2.0], atol=1e-5)

    def test_frame_clip_world_first_ego(self, loader):
        """frame='clip_world' for the first ego pose (at origin) ≡ ego frame."""
        sd = loader.sample_data_for_channel("LIDAR_TOP")[0]  # ep-0 at origin
        pts_ego = loader.load_point_cloud(sd, frame=loader.ego_pose_frame_id)
        pts_world = loader.load_point_cloud(sd, frame=CLIP_WORLD)
        np.testing.assert_allclose(pts_world[:, :3], pts_ego[:, :3], atol=1e-5)

    def test_frame_clip_world_second_ego(self, loader):
        """frame='clip_world' for the second ego pose adds the ego offset."""
        sd = loader.sample_data_for_channel("LIDAR_TOP")[1]  # ep-1 at x=10
        pts = loader.load_point_cloud(sd, frame=CLIP_WORLD)
        np.testing.assert_allclose(pts[0, :3], [11.0, 0.0, 1.0], atol=1e-5)

    def test_intensity_preserved(self, loader):
        """Non-xyz columns are passed through unchanged."""
        sd = loader.sample_data_for_channel("LIDAR_TOP")[0]
        pts = loader.load_point_cloud(sd, frame=CLIP_WORLD)
        np.testing.assert_allclose(pts[:, 3], 0.5, atol=1e-6)

    def test_magic_string_world_rejected(self, loader):
        """The legacy magic string 'world' must be rejected with a hint."""
        sd = loader.sample_data_for_channel("LIDAR_TOP")[0]
        with pytest.raises(ValueError, match=r"clip_world"):
            loader.load_point_cloud(sd, frame="world")

    def test_magic_string_ego_rejected(self, loader):
        sd = loader.sample_data_for_channel("LIDAR_TOP")[0]
        with pytest.raises(ValueError, match=r"ego_pose_frame_id"):
            loader.load_point_cloud(sd, frame="ego")

    def test_magic_string_sensor_rejected(self, loader):
        sd = loader.sample_data_for_channel("LIDAR_TOP")[0]
        with pytest.raises(ValueError, match=r"sensor_frame_id"):
            loader.load_point_cloud(sd, frame="sensor")

    def test_unknown_frame_id_raises_keyerror(self, loader):
        sd = loader.sample_data_for_channel("LIDAR_TOP")[0]
        with pytest.raises(KeyError, match=r"not_a_real_frame"):
            loader.load_point_cloud(sd, frame="not_a_real_frame")


# ---------------------------------------------------------------------------
# annotations_for_sample — explicit frame_id, no magic strings
# ---------------------------------------------------------------------------

class TestAnnotationsForSampleFrames:
    def test_no_frame_returns_native(self, loader):
        """Default (no frame=) returns annotations in the stored frame, unchanged."""
        anns = loader.annotations_for_sample("s-0")
        assert len(anns) == 1
        np.testing.assert_allclose(anns[0].translation, [5.0, 3.0, 0.0])

    def test_frame_equal_to_annotation_frame_is_noop(self, loader):
        """Passing annotation_frame_id matches the no-frame default."""
        anns_default = loader.annotations_for_sample("s-0")
        anns_explicit = loader.annotations_for_sample("s-0", frame=loader.annotation_frame_id)
        np.testing.assert_allclose(anns_default[0].translation, anns_explicit[0].translation)

    def test_frame_clip_world_first_sample(self, loader):
        """frame='clip_world' on the first sample (ego at origin) ≡ stored ego."""
        anns = loader.annotations_for_sample("s-0", frame=CLIP_WORLD)
        np.testing.assert_allclose(anns[0].translation, [5.0, 3.0, 0.0], atol=1e-5)

    def test_frame_clip_world_second_sample(self, loader):
        """frame='clip_world' on the second sample (ego at x=10) shifts by ego offset."""
        anns = loader.annotations_for_sample("s-1", frame=CLIP_WORLD)
        np.testing.assert_allclose(anns[0].translation, [10.0, 3.0, 0.0], atol=1e-5)

    def test_native_velocity_unchanged(self, loader):
        anns = loader.annotations_for_sample("s-0")
        np.testing.assert_allclose(anns[0].velocity, [5.0, 0.0, 0.0], atol=1e-5)

    def test_clip_world_preserves_other_fields(self, loader):
        anns_native = loader.annotations_for_sample("s-0")
        anns_world = loader.annotations_for_sample("s-0", frame=CLIP_WORLD)
        assert anns_native[0].token == anns_world[0].token
        assert anns_native[0].category == anns_world[0].category
        np.testing.assert_allclose(anns_native[0].size, anns_world[0].size)
        assert anns_native[0].num_lidar_pts == anns_world[0].num_lidar_pts

    def test_returns_new_objects(self, loader):
        """Transformed annotations are new objects; originals untouched."""
        anns_native = loader.annotations_for_sample("s-1")
        anns_world = loader.annotations_for_sample("s-1", frame=CLIP_WORLD)
        np.testing.assert_allclose(anns_native[0].translation, [0.0, 3.0, 0.0])
        assert not np.allclose(anns_world[0].translation, anns_native[0].translation, atol=0.1)

    def test_frame_sensor_id_transforms_to_that_sensor(self, loader):
        """Passing a sensor's frame_id transforms annotations into that sensor's frame."""
        # LIDAR_TOP is at (0,0,1) in ego frame. Annotation at ego (5,3,0) →
        # LIDAR_TOP frame: subtract z=1 → (5,3,-1).
        anns = loader.annotations_for_sample("s-0", frame="LIDAR_TOP")
        np.testing.assert_allclose(anns[0].translation, [5.0, 3.0, -1.0], atol=1e-5)

    def test_magic_string_sensor_rejected(self, loader):
        with pytest.raises(ValueError, match=r"sensor_frame_id"):
            loader.annotations_for_sample("s-0", frame="sensor")

    def test_magic_string_ego_rejected(self, loader):
        with pytest.raises(ValueError, match=r"ego_pose_frame_id"):
            loader.annotations_for_sample("s-0", frame="ego")

    def test_magic_string_world_rejected(self, loader):
        with pytest.raises(ValueError, match=r"clip_world"):
            loader.annotations_for_sample("s-0", frame="world")

    def test_unknown_frame_id_raises(self, loader):
        with pytest.raises((KeyError, ValueError), match=r"not_a_real_frame"):
            loader.annotations_for_sample("s-0", frame="not_a_real_frame")

    def test_empty_sample_returns_empty(self, loader):
        assert loader.annotations_for_sample("nonexistent") == []
        assert loader.annotations_for_sample("nonexistent", frame=CLIP_WORLD) == []


# ---------------------------------------------------------------------------
# get_transform — frame_id × frame_id, sd carries dynamic context
# ---------------------------------------------------------------------------

class TestGetTransform:
    def test_identity_same_frame(self, loader):
        T = loader.get_transform("LIDAR_TOP", "LIDAR_TOP")
        np.testing.assert_allclose(T.as_matrix, np.eye(4), atol=1e-10)

    def test_static_sensor_to_ego(self, loader):
        # Static-only: no sd needed.
        T = loader.get_transform("LIDAR_TOP", loader.ego_pose_frame_id)
        np.testing.assert_allclose(T.translation, [0.0, 0.0, 1.0], atol=1e-10)

    def test_static_sensor_to_sensor(self, loader):
        # LIDAR_TOP at (0,0,1) and CAM_FRONT at (0.5,0,0.8) in ego frame.
        # T_CAM_from_LIDAR = T_CAM_from_ego @ T_ego_from_LIDAR
        #   = (-0.5, 0, -0.8) ∘ (0, 0, +1) = (-0.5, 0, +0.2)
        T = loader.get_transform("LIDAR_TOP", "CAM_FRONT")
        np.testing.assert_allclose(T.translation, [-0.5, 0.0, 0.2], atol=1e-10)

    def test_dynamic_sensor_to_clip_world_requires_sd(self, loader):
        sd = loader.sample_data_for_channel("LIDAR_TOP")[1]  # ego at x=10
        T = loader.get_transform("LIDAR_TOP", CLIP_WORLD, sd=sd)
        # sensor → ego (z+1) → world (x+10)  →  (10, 0, 1)
        np.testing.assert_allclose(T.translation, [10.0, 0.0, 1.0], atol=1e-10)

    def test_clip_world_without_sd_raises(self, loader):
        with pytest.raises(ValueError, match=r"clip_world"):
            loader.get_transform("LIDAR_TOP", CLIP_WORLD)

    def test_round_trip_through_clip_world(self, loader):
        sd = loader.sample_data_for_channel("LIDAR_TOP")[1]
        T_fwd = loader.get_transform("LIDAR_TOP", CLIP_WORLD, sd=sd)
        T_rev = loader.get_transform(CLIP_WORLD, "LIDAR_TOP", sd=sd)
        np.testing.assert_allclose((T_fwd @ T_rev).as_matrix, np.eye(4), atol=1e-10)

    def test_magic_string_rejected(self, loader):
        sd = loader.sample_data_for_channel("LIDAR_TOP")[0]
        with pytest.raises(ValueError, match=r"clip_world"):
            loader.get_transform("sensor", "world", sd=sd)

    def test_unknown_frame_id_raises_keyerror(self, loader):
        with pytest.raises(KeyError, match=r"not_a_real_frame"):
            loader.get_transform("LIDAR_TOP", "not_a_real_frame")

    def test_consistency_with_load_point_cloud(self, loader):
        sd = loader.sample_data_for_channel("LIDAR_TOP")[1]
        pts_sensor = loader.load_point_cloud(sd)
        pts_world = loader.load_point_cloud(sd, frame=CLIP_WORLD)
        T = loader.get_transform("LIDAR_TOP", CLIP_WORLD, sd=sd)
        pts_manual = T.apply(pts_sensor[:, :3].astype(np.float64)).astype(np.float32)
        np.testing.assert_allclose(pts_world[:, :3], pts_manual, atol=1e-5)


# ---------------------------------------------------------------------------
# Integration tests (nuScenes)
# ---------------------------------------------------------------------------

NUSCENES_DATAROOT = "/data/PublicDatasets/nuscenes"
NUSCENES_AVAILABLE = os.path.isdir(os.path.join(NUSCENES_DATAROOT, "v1.0-mini"))


@pytest.fixture(scope="module")
def nuscenes_loader(tmp_path_factory):
    if not NUSCENES_AVAILABLE:
        pytest.skip("nuScenes data not found")
    from x4d_devkit.converters.nuscenes import NuScenesConverter

    out = tmp_path_factory.mktemp("frames_test")
    conv = NuScenesConverter(
        dataroot=NUSCENES_DATAROOT, version="v1.0-mini", output_dir=str(out),
    )
    scene = conv.nusc.scene[0]
    clip_id = conv.convert_scene(scene["token"])
    return ClipLoader(out / "clips" / clip_id)


@pytest.mark.skipif(not NUSCENES_AVAILABLE, reason="nuScenes data not found")
class TestCoordinateFramesIntegration:
    def test_point_cloud_round_trip(self, nuscenes_loader):
        """sensor → clip_world → sensor recovers original points."""
        sd = next(
            s for s in nuscenes_loader.sample_data_for_channel("LIDAR_TOP") if s.is_keyframe
        )
        pts_sensor = nuscenes_loader.load_point_cloud(sd)
        pts_world = nuscenes_loader.load_point_cloud(sd, frame=CLIP_WORLD)
        T_back = nuscenes_loader.get_transform(CLIP_WORLD, "LIDAR_TOP", sd=sd)
        recovered = T_back.apply(pts_world[:, :3].astype(np.float64)).astype(np.float32)
        np.testing.assert_allclose(recovered, pts_sensor[:, :3], atol=1e-4)

    def test_ego_annotations_near_ego(self, nuscenes_loader):
        sample = nuscenes_loader.samples[0]
        anns_native = nuscenes_loader.annotations_for_sample(sample.token)
        anns_world = nuscenes_loader.annotations_for_sample(sample.token, frame=CLIP_WORLD)
        if not anns_native:
            pytest.skip("No annotations in first sample")
        for ann in anns_native:
            dist = np.linalg.norm(ann.translation[:2])
            assert dist < 200, f"Annotation too far in native frame: {dist}m"
        # World frame should differ for at least one annotation (ego usually not at origin).
        diffs = [
            np.linalg.norm(an.translation - aw.translation)
            for an, aw in zip(anns_native, anns_world)
        ]
        assert max(diffs) > 0  # at minimum, different positions
