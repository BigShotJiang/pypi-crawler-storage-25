"""Unit tests for v0.6.0 API additions.

Covers:
    - x4d_devkit.__version__
    - ClipLoader.schema_version property + require_schema_version + constructor kwarg
    - SchemaVersionMismatch exception
    - calc_ap / calc_tp public re-exports (and underscore aliases still work)
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

import x4d_devkit
from x4d_devkit import (
    ClipLoader,
    SchemaVersionMismatch,
    calc_ap,
    calc_tp,
)
from x4d_devkit.eval.matching import MetricData


def _write_minimal_clip(clip_dir: Path, schema_version: str) -> None:
    """Write the minimum JSON files ClipLoader.__init__ needs to succeed."""
    clip_dir.mkdir(parents=True, exist_ok=True)
    meta = {
        "clip_id": "20260504_test_001",
        "schema_version": schema_version,
        "session_id": "20260504_test",
        "vehicle_id": "test",
        "capture_time_utc": "2026-05-04T00:00:00Z",
        "duration_s": 0.0,
        "keyframe_count": 0,
        "sweep_count": 0,
        "sensors": [],
    }
    (clip_dir / "meta.json").write_text(json.dumps(meta))
    for empty in (
        "calibrated_sensor.json",
        "ego_pose.json",
        "sample.json",
        "sample_data.json",
        "annotation.json",
        "instance.json",
    ):
        (clip_dir / empty).write_text("[]")


def test_package_has_version_attribute():
    """__version__ is a non-empty string matching expected shape."""
    assert isinstance(x4d_devkit.__version__, str)
    assert x4d_devkit.__version__  # non-empty
    # Either a real version (e.g. "0.6.0", "0.6.0.post1") or the editable fallback.
    assert "." in x4d_devkit.__version__ or x4d_devkit.__version__.startswith("0.0.0")


def test_loader_schema_version_property(tmp_path):
    _write_minimal_clip(tmp_path, "0.5")
    loader = ClipLoader(tmp_path)
    assert loader.schema_version == "0.5"
    assert loader.schema_version == loader.meta.schema_version


def test_loader_require_schema_version_match(tmp_path):
    _write_minimal_clip(tmp_path, "0.5")
    loader = ClipLoader(tmp_path)
    loader.require_schema_version("0.5")  # no raise


def test_loader_require_schema_version_mismatch(tmp_path):
    _write_minimal_clip(tmp_path, "0.4")
    loader = ClipLoader(tmp_path)
    with pytest.raises(SchemaVersionMismatch) as exc:
        loader.require_schema_version("0.5")
    assert exc.value.actual == "0.4"
    assert exc.value.expected == "0.5"
    assert "0.4" in str(exc.value) and "0.5" in str(exc.value)


def test_loader_require_schema_version_set(tmp_path):
    _write_minimal_clip(tmp_path, "0.4")
    loader = ClipLoader(tmp_path)
    loader.require_schema_version({"0.4", "0.5"})  # no raise
    with pytest.raises(SchemaVersionMismatch):
        loader.require_schema_version({"0.5", "0.6"})


def test_loader_constructor_strict_check_match(tmp_path):
    _write_minimal_clip(tmp_path, "0.5")
    ClipLoader(tmp_path, expected_schema_version="0.5")  # no raise


def test_loader_constructor_strict_check_mismatch(tmp_path):
    _write_minimal_clip(tmp_path, "0.4")
    with pytest.raises(SchemaVersionMismatch):
        ClipLoader(tmp_path, expected_schema_version="0.5")


def test_loader_constructor_strict_check_set(tmp_path):
    _write_minimal_clip(tmp_path, "0.5")
    ClipLoader(tmp_path, expected_schema_version={"0.4", "0.5"})  # no raise
    _write_minimal_clip(tmp_path, "0.3")
    with pytest.raises(SchemaVersionMismatch):
        ClipLoader(tmp_path, expected_schema_version={"0.4", "0.5"})


def _md_with_precision(prec: np.ndarray) -> MetricData:
    """Build a MetricData with just enough fields for calc_ap / calc_tp."""
    n = len(prec)
    md = MetricData(
        recall=np.linspace(0, 1, n),
        precision=prec,
        confidence=np.linspace(1, 0, n),
        trans_err=np.zeros(n),
        vel_err=np.zeros(n),
        scale_err=np.zeros(n),
        orient_err=np.zeros(n),
        attr_err=np.zeros(n),
    )
    return md


def test_calc_ap_public_export():
    """calc_ap is importable from x4d_devkit and x4d_devkit.eval, returns expected value."""
    from x4d_devkit.eval import calc_ap as eval_calc_ap

    assert eval_calc_ap is calc_ap

    # Constant precision = 1.0 across recall, min_recall=0, min_precision=0 → AP=1.0
    md = _md_with_precision(np.ones(101))
    ap = calc_ap(md, min_recall=0.0, min_precision=0.0)
    assert ap == pytest.approx(1.0)

    # Constant 0 precision → AP=0.0
    md = _md_with_precision(np.zeros(101))
    ap = calc_ap(md, min_recall=0.0, min_precision=0.0)
    assert ap == pytest.approx(0.0)


def test_calc_tp_public_export():
    """calc_tp is importable and returns mean of metric in valid recall range."""
    from x4d_devkit.eval import calc_tp as eval_calc_tp

    assert eval_calc_tp is calc_tp

    md = _md_with_precision(np.ones(101))
    md.trans_err[:] = 0.5
    # min_recall=0 → first_ind=1; max_recall_ind defaults; mean over [1..max] of 0.5 = 0.5
    tp = calc_tp(md, min_recall=0.0, metric_name="trans_err")
    assert tp == pytest.approx(0.5)


def test_underscore_aliases_still_work():
    """Old _calc_ap / _calc_tp names remain importable (deprecated alias)."""
    from x4d_devkit.eval.detection import _calc_ap, _calc_tp

    assert _calc_ap is calc_ap
    assert _calc_tp is calc_tp
