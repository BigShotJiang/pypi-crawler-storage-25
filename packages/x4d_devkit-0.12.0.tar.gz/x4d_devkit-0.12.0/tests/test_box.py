"""Unit tests for the Box detection dataclass."""

import numpy as np
import pytest

from x4d_devkit.eval import Box


class TestBoxConstruction:
    def test_minimal_gt(self):
        b = Box(
            translation=[1.0, 2.0, 3.0],
            size=[4.0, 2.0, 1.5],
            rotation=[0.0, 0.0, 0.0, 1.0],
            category="car",
        )
        assert b.translation.dtype == np.float64
        assert b.translation.shape == (3,)
        assert b.size.shape == (3,)
        assert b.rotation.shape == (4,)
        assert b.category == "car"
        assert b.score is None
        assert b.velocity is None
        assert b.attributes == []

    def test_prediction_with_score_and_velocity(self):
        b = Box(
            translation=np.array([10.0, 20.0, 1.0]),
            size=np.array([4.5, 1.8, 1.5]),
            rotation=np.array([0.0, 0.0, 0.0, 1.0]),
            category="car",
            score=0.85,
            velocity=[1.0, 0.5, 0.0],
            attributes=["vehicle.moving"],
        )
        assert b.score == 0.85
        assert b.velocity.dtype == np.float64
        assert b.velocity.tolist() == [1.0, 0.5, 0.0]
        assert b.attributes == ["vehicle.moving"]

    def test_frozen(self):
        b = Box(
            translation=[0, 0, 0], size=[1, 1, 1],
            rotation=[0, 0, 0, 1], category="car",
        )
        with pytest.raises((AttributeError, Exception)):
            b.category = "truck"

    def test_rejects_wrong_translation_shape(self):
        with pytest.raises(ValueError, match="translation"):
            Box(translation=[1, 2], size=[1, 1, 1],
                rotation=[0, 0, 0, 1], category="car")

    def test_rejects_wrong_rotation_shape(self):
        with pytest.raises(ValueError, match="rotation"):
            Box(translation=[1, 2, 3], size=[1, 1, 1],
                rotation=[0, 0, 0], category="car")

    def test_rejects_wrong_size_shape(self):
        with pytest.raises(ValueError, match="size"):
            Box(translation=[1, 2, 3], size=[1, 1],
                rotation=[0, 0, 0, 1], category="car")


class TestFromXyzlwhyawVxvy:
    def test_yaw_zero_gives_identity_quat(self):
        b = Box.from_xyzlwhyaw_vxvy(
            [0, 0, 0, 4, 2, 1.5, 0.0, 0, 0], category="car", score=0.9,
        )
        assert b.rotation[0] == 0.0
        assert b.rotation[1] == 0.0
        assert b.rotation[2] == pytest.approx(0.0)
        assert b.rotation[3] == pytest.approx(1.0)

    def test_yaw_pi_half_gives_z_quat(self):
        b = Box.from_xyzlwhyaw_vxvy(
            [0, 0, 0, 4, 2, 1.5, np.pi / 2, 0, 0], category="car",
        )
        assert b.rotation[2] == pytest.approx(np.sin(np.pi / 4))
        assert b.rotation[3] == pytest.approx(np.cos(np.pi / 4))

    def test_yaw_round_trip_via_quaternion_yaw(self):
        from x4d_devkit.eval.metrics import quaternion_yaw

        for yaw in [-2.5, -1.0, 0.0, 0.7, np.pi - 0.01]:
            b = Box.from_xyzlwhyaw_vxvy(
                [1, 2, 3, 4, 2, 1.5, yaw, 0, 0], category="car",
            )
            recovered = quaternion_yaw(b.rotation)
            assert recovered == pytest.approx(yaw, abs=1e-6)

    def test_velocity_lifts_to_3d(self):
        b = Box.from_xyzlwhyaw_vxvy(
            [0, 0, 0, 4, 2, 1.5, 0, 1.5, -0.5], category="car",
        )
        assert b.velocity.shape == (3,)
        assert b.velocity.tolist() == [1.5, -0.5, 0.0]

    def test_translation_and_size_preserved(self):
        b = Box.from_xyzlwhyaw_vxvy(
            [10, 20, 1, 4.5, 1.8, 1.5, 0.0, 0, 0], category="car",
        )
        assert b.translation.tolist() == [10.0, 20.0, 1.0]
        assert b.size.tolist() == [4.5, 1.8, 1.5]

    def test_rejects_wrong_shape(self):
        with pytest.raises(ValueError, match="bbox must be shape"):
            Box.from_xyzlwhyaw_vxvy([1, 2, 3], category="car")

    def test_attributes_default_empty(self):
        b = Box.from_xyzlwhyaw_vxvy(
            [0, 0, 0, 4, 2, 1.5, 0, 0, 0], category="car",
        )
        assert b.attributes == []

    def test_attributes_passthrough(self):
        b = Box.from_xyzlwhyaw_vxvy(
            [0, 0, 0, 4, 2, 1.5, 0, 0, 0], category="car",
            attributes=["vehicle.moving"],
        )
        assert b.attributes == ["vehicle.moving"]
