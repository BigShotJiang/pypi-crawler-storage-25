from dataclasses import dataclass
from datetime import datetime

from haiv_mail.address import Address


@dataclass(frozen=True)
class WaitingStatus:
    """A mind that is currently waiting for mail."""

    address: Address
    waiting_for: Address | None
    started_at: datetime
