from dataclasses import dataclass


@dataclass(frozen=True)
class Address:
    """A mind's mail address: name@colony."""

    name: str
    colony: str

    def __str__(self) -> str:
        return f"{self.name}@{self.colony}"

    @classmethod
    def parse(cls, raw: str) -> "Address":
        if "@" not in raw:
            raise ValueError(f"Invalid address (missing @): {raw!r}")
        name, colony = raw.split("@", 1)
        if not name or not colony:
            raise ValueError(f"Invalid address (empty part): {raw!r}")
        return cls(name=name, colony=colony)
