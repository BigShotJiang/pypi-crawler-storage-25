"""Domain operations built on top of MailStore.

These are not data layer concerns — they are logic that any
consumer could write, packaged for convenience.
"""

from haiv_mail.address import Address
from haiv_mail.message import Message
from haiv_mail.protocol import MailStore


def reply(
    store: MailStore,
    original: Message,
    sender: Address,
    body: str,
    subject: str | None = None,
) -> Message:
    """Reply to a message. Swaps sender/recipient, threads via in_reply_to."""
    if subject is None:
        subj = original.subject
        if not subj.startswith("Re: "):
            subj = f"Re: {subj}"
        subject = subj
    return store.send(
        sender=sender,
        recipients=[original.sender],
        subject=subject,
        body=body,
        in_reply_to=original.id,
    )
