"""haiv-mail: communication library for minds.

Consumers depend on the protocol:

    from haiv_mail import Address, Message, MailStore

The default implementation is SQLite-backed:

    from haiv_mail import Mailbox

    store: MailStore = Mailbox(db_path=Path("~/.local/state/haiv/mail.db"))
    msg = store.send(...)

Domain operations (built on MailStore, not part of it):

    from haiv_mail.domain import reply
    reply(store, original_msg, sender=my_addr, body="response")
"""

from haiv_mail.address import Address
from haiv_mail.message import Message
from haiv_mail.presence import WaitingStatus
from haiv_mail.protocol import MailStore
from haiv_mail.mailbox import Mailbox

__all__ = ["Address", "Message", "WaitingStatus", "MailStore", "Mailbox"]
