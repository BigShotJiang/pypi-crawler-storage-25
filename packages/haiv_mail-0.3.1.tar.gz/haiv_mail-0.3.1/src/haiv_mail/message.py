from dataclasses import dataclass, field
from datetime import datetime, timezone
from uuid import uuid4

from haiv_mail.address import Address


@dataclass(frozen=True)
class Message:
    """A single message between minds."""

    sender: Address
    recipients: list[Address]
    subject: str
    body: str
    in_reply_to: str | None = None
    id: str = field(default_factory=lambda: uuid4().hex[:12])
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
