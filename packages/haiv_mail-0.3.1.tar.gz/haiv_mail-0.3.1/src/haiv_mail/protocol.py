"""The mail protocol. Consumers depend on this, not on any implementation."""

from typing import Protocol

from haiv_mail.address import Address
from haiv_mail.message import Message


class MailStore(Protocol):
    """What any mail data layer must provide.

    Covers DMs and mailing lists in a unified model.
    Domain logic (reply, wait) lives above this boundary.
    """

    # -- DMs --

    def send(
        self,
        sender: Address,
        recipients: list[Address],
        subject: str,
        body: str,
        in_reply_to: str | None = None,
    ) -> Message: ...

    def deliver(self, msg: Message) -> None: ...

    def delete_message(self, addr: Address, message_id: str) -> bool: ...

    def list_messages(self, addr: Address) -> list[Message]: ...

    def list_sent(self, addr: Address) -> list[Message]: ...

    def read_message(self, addr: Address, message_id: str) -> Message | None: ...

    def unread_count(self, addr: Address) -> int: ...

    def unread_ids(self, addr: Address) -> set[str]: ...

    def thread(self, addr: Address, message_id: str) -> list[Message]: ...

    # -- mailing lists --

    def create_list(self, name: str, creator: Address, description: str = "") -> None: ...

    def is_list(self, name: str) -> bool: ...

    def get_list_info(self, name: str) -> dict | None: ...

    def get_all_lists(self) -> list[dict]: ...

    def get_joined_lists(self, addr: Address) -> list[dict]: ...

    def join_list(self, name: str, addr: Address) -> None: ...

    def leave_list(self, name: str, addr: Address) -> None: ...

    def post_to_list(
        self, name: str, sender: Address, subject: str, body: str,
        in_reply_to: str | None = None,
    ) -> Message: ...

    def list_posts(self, name: str) -> list[Message]: ...

    def read_list_post(self, message_id: str) -> Message | None: ...

    def reply_count(self, message_id: str) -> int: ...

    # -- unified --

    def list_unread_activity(self, addr: Address) -> list[dict]: ...
