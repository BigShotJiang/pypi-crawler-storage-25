from haiv import cmd

from haiv_mail.commands.mail._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="Mailing lists I'm on",
        flags=[
            cmd.Flag("all", type=bool),
        ],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)
    show_all = ctx.args.has("all")

    if show_all:
        lists = mb.get_all_lists()
    else:
        lists = mb.get_joined_lists(me)

    if not lists:
        if show_all:
            ctx.print("No lists exist yet.")
        else:
            ctx.print("Not on any lists.")
            ctx.print("  hv mail lists --all        see all lists")
        ctx.print("  hv mail create <name>      create one")
        return

    for ml in lists:
        desc = f"  {ml['description']}" if ml['description'] else ""
        ctx.print(f"  {ml['name']}{desc}")
