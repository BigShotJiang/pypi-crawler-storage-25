from haiv import cmd

from haiv_mail.commands.mail._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(description="Browse threads in a mailing list")


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)
    name = ctx.args.get_one("name")

    info = mb.get_list_info(name)
    if info is None:
        ctx.print(f"List '{name}' does not exist.")
        return

    if info['description']:
        ctx.print(f"  {info['description']}")
        ctx.print(f"")

    posts = mb.list_posts(name)
    if not posts:
        ctx.print(f"No posts yet.")
        ctx.print(f"  hv mail send {name} --subject <s> --body <b>")
        return

    for post in posts:
        ts = post.timestamp.strftime("%Y-%m-%d %H:%M")
        replies = mb.reply_count(post.id)
        reply_str = f"  ({replies} replies)" if replies > 0 else ""
        ctx.print(f"  {post.id}  {ts}  {post.sender}  {post.subject}{reply_str}")
