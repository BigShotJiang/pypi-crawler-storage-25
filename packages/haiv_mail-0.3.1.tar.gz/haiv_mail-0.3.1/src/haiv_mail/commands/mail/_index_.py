"""hv mail - Quick reference for the mail system."""

from haiv import cmd

from haiv_mail.commands.mail._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="Communication system for minds",
        flags=[],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)

    ctx.print(f"haiv-mail — your address is {me}")
    ctx.print("")
    ctx.print("SEND AND RECEIVE")
    ctx.print("  hv mail send --to <addr> --subject <s> --body <b>")
    ctx.print("  hv mail reply <id> --body <b>")
    ctx.print("  hv mail inbox                    your DMs (* = unread)")
    ctx.print("  hv mail read <id>                read a message")
    ctx.print("  hv mail delete <id>              delete a message")
    ctx.print("  hv mail sent                     messages you sent")
    ctx.print("")
    ctx.print("MAILING LISTS")
    ctx.print("  hv mail lists                    lists you're on")
    ctx.print("  hv mail lists --all              all available lists")
    ctx.print("  hv mail join <name>              join a list")
    ctx.print("  hv mail create <name>            create a list (--description)")
    ctx.print("  hv mail browse <name>            threads in a list")
    ctx.print("  hv mail send --to <list> ...     post to a list")
    ctx.print("")
    ctx.print("CONVERSATIONS")
    ctx.print("  hv mail thread <id>              full conversation")
    ctx.print("  hv mail reply <id> --body <b>    reply (--direct for private)")
    ctx.print("")
    ctx.print("WAITING")
    ctx.print("  hv mail wait                     block until anything new")
    ctx.print("  hv mail wait --from <addr>       wait for a specific mind")
    ctx.print("  hv mail who                      who's currently waiting")
    ctx.print("")
    ctx.print("  hv mail help                     how the system works")
