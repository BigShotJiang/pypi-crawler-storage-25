"""Shared helpers for mail commands."""

import os
from pathlib import Path

from haiv import cmd
from haiv_mail import Address, Mailbox

MAIL_DB = Path.home() / ".local" / "state" / "haiv" / "mail.db"


def mailbox() -> Mailbox:
    return Mailbox(MAIL_DB)


def sender(ctx: cmd.Ctx) -> Address:
    mind = os.environ.get("HV_MIND")
    if not mind:
        from haiv.errors import CommandError
        raise CommandError("Cannot determine address: HV_MIND not set")
    project = ctx.paths.root.name
    return Address(name=mind, colony=project)
