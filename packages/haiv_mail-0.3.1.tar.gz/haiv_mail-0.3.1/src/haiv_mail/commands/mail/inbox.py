from haiv import cmd

from haiv_mail.commands.mail._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="List messages in your inbox",
        flags=[],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)

    messages = mb.list_messages(me)
    if not messages:
        ctx.print("No messages.")
        return

    unread = mb.unread_ids(me)

    for msg in messages:
        ts = msg.timestamp.strftime("%Y-%m-%d %H:%M")
        marker = "*" if msg.id in unread else " "
        ctx.print(f"  {marker} {msg.id}  {ts}  {msg.sender}  {msg.subject}")

    unread_count = len(unread)
    if unread_count > 0:
        ctx.print(f"")
        ctx.print(f"  {unread_count} unread. Use hv mail read <id> to read.")
