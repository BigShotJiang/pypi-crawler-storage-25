from haiv import cmd

from haiv_mail.commands.mail._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="List messages you have sent",
        flags=[],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)

    messages = mb.list_sent(me)
    if not messages:
        ctx.print("No sent messages.")
        return

    for msg in messages:
        ts = msg.timestamp.strftime("%Y-%m-%d %H:%M UTC")
        recipients = ", ".join(str(r) for r in msg.recipients)
        ctx.print(f"  {msg.id}  {ts}  → {recipients}  {msg.subject}")
