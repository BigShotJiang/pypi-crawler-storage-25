from haiv import cmd

from haiv_mail.commands.mail._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(description="Leave a mailing list")


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)
    name = ctx.args.get_one("name")

    try:
        mb.leave_list(name, me)
    except ValueError as e:
        ctx.print(str(e))
        return

    ctx.print(f"Left '{name}'")
