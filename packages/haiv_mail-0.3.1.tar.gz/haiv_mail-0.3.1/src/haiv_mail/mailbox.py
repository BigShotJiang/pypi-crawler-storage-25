"""Mailbox: the data layer. SQLite underneath, DTOs above."""

import sqlite3
from pathlib import Path

from haiv_mail.address import Address
from haiv_mail.message import Message
from haiv_mail.presence import WaitingStatus


_SCHEMA = """\
CREATE TABLE IF NOT EXISTS messages (
    id          TEXT PRIMARY KEY,
    timestamp   TEXT NOT NULL,
    sender      TEXT NOT NULL,
    recipients  TEXT NOT NULL,
    subject     TEXT NOT NULL,
    body        TEXT NOT NULL,
    in_reply_to TEXT
);

CREATE TABLE IF NOT EXISTS deliveries (
    message_id  TEXT NOT NULL,
    recipient   TEXT NOT NULL,
    is_read     INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (message_id, recipient),
    FOREIGN KEY (message_id) REFERENCES messages(id)
);

CREATE TABLE IF NOT EXISTS presence (
    address     TEXT PRIMARY KEY,
    waiting_for TEXT,
    started_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS mailing_lists (
    name        TEXT PRIMARY KEY,
    description TEXT NOT NULL DEFAULT '',
    created_by  TEXT NOT NULL,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS list_members (
    list_name   TEXT NOT NULL,
    address     TEXT NOT NULL,
    PRIMARY KEY (list_name, address),
    FOREIGN KEY (list_name) REFERENCES mailing_lists(name)
);

CREATE TABLE IF NOT EXISTS list_posts (
    message_id  TEXT NOT NULL,
    list_name   TEXT NOT NULL,
    PRIMARY KEY (message_id, list_name),
    FOREIGN KEY (message_id) REFERENCES messages(id),
    FOREIGN KEY (list_name) REFERENCES mailing_lists(name)
);

CREATE TABLE IF NOT EXISTS list_reads (
    message_id  TEXT NOT NULL,
    address     TEXT NOT NULL,
    PRIMARY KEY (message_id, address)
);
"""

_MIGRATIONS = [
    "ALTER TABLE deliveries ADD COLUMN is_read INTEGER NOT NULL DEFAULT 0",
]


class Mailbox:
    """Data layer for mail. Consumers see only DTOs (Message, Address)."""

    def __init__(self, db_path: Path | str = ":memory:") -> None:
        self._db_path = db_path
        if isinstance(db_path, Path):
            db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path), timeout=10)
        if str(db_path) != ":memory:":
            self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=10000")
        self._conn.executescript(_SCHEMA)
        self._migrate()

    # -- writes --

    def send(
        self,
        sender: Address,
        recipients: list[Address],
        subject: str,
        body: str,
        in_reply_to: str | None = None,
    ) -> Message:
        if not subject or not subject.strip():
            raise ValueError("Subject cannot be empty")
        if not body or not body.strip():
            raise ValueError("Body cannot be empty")
        if not recipients:
            raise ValueError("At least one recipient required")
        msg = Message(
            sender=sender,
            recipients=recipients,
            subject=subject,
            body=body,
            in_reply_to=in_reply_to,
        )
        self._insert_message(msg)
        return msg

    def reply(
        self,
        original: Message,
        sender: Address,
        body: str,
        subject: str | None = None,
    ) -> Message:
        """Convenience wrapper. Prefer haiv_mail.domain.reply() for new code."""
        from haiv_mail.domain import reply
        return reply(self, original, sender, body, subject)

    def deliver(self, msg: Message) -> None:
        self._insert_message(msg)

    def delete_message(self, addr: Address, message_id: str) -> bool:
        cursor = self._conn.execute(
            "DELETE FROM deliveries WHERE message_id = ? AND recipient = ?",
            (message_id, str(addr)),
        )
        self._conn.commit()
        return cursor.rowcount > 0

    # -- reads --

    def list_messages(self, addr: Address) -> list[Message]:
        rows = self._conn.execute(
            """SELECT m.id, m.timestamp, m.sender, m.recipients,
                      m.subject, m.body, m.in_reply_to
               FROM messages m
               JOIN deliveries d ON m.id = d.message_id
               WHERE d.recipient = ?
               ORDER BY m.timestamp DESC""",
            (str(addr),),
        ).fetchall()
        return [self._row_to_message(r) for r in rows]

    def list_sent(self, addr: Address) -> list[Message]:
        rows = self._conn.execute(
            """SELECT id, timestamp, sender, recipients,
                      subject, body, in_reply_to
               FROM messages
               WHERE sender = ?
               ORDER BY timestamp DESC""",
            (str(addr),),
        ).fetchall()
        return [self._row_to_message(r) for r in rows]

    def read_message(self, addr: Address, message_id: str) -> Message | None:
        row = self._conn.execute(
            """SELECT m.id, m.timestamp, m.sender, m.recipients,
                      m.subject, m.body, m.in_reply_to
               FROM messages m
               JOIN deliveries d ON m.id = d.message_id
               WHERE m.id = ? AND d.recipient = ?""",
            (message_id, str(addr)),
        ).fetchone()
        if row is None:
            return None
        self._conn.execute(
            "UPDATE deliveries SET is_read = 1 WHERE message_id = ? AND recipient = ?",
            (message_id, str(addr)),
        )
        self._conn.commit()
        return self._row_to_message(row)

    def unread_count(self, addr: Address) -> int:
        row = self._conn.execute(
            """SELECT COUNT(*) FROM deliveries
               WHERE recipient = ? AND is_read = 0""",
            (str(addr),),
        ).fetchone()
        return row[0]

    def unread_ids(self, addr: Address) -> set[str]:
        """Return message IDs that are unread for this address."""
        rows = self._conn.execute(
            "SELECT message_id FROM deliveries WHERE recipient = ? AND is_read = 0",
            (str(addr),),
        ).fetchall()
        return {r[0] for r in rows}

    def contacts(self, addr: Address) -> list[Address]:
        """List all addresses this mind has communicated with."""
        rows = self._conn.execute(
            """SELECT DISTINCT sender FROM messages m
               JOIN deliveries d ON m.id = d.message_id
               WHERE d.recipient = ?
               UNION
               SELECT DISTINCT d2.recipient FROM messages m2
               JOIN deliveries d2 ON m2.id = d2.message_id
               WHERE m2.sender = ?""",
            (str(addr), str(addr)),
        ).fetchall()
        result = []
        for (raw,) in rows:
            a = Address.parse(raw)
            if a != addr:
                result.append(a)
        result.sort(key=str)
        return result

    def thread(self, addr: Address, message_id: str) -> list[Message]:
        """Collect all messages in a thread, oldest first.

        Walks in_reply_to to find the root, then collects everything
        that chains back to it. Searches messages visible to addr
        (received or sent).
        """
        visible = {m.id: m for m in self.list_messages(addr) + self.list_sent(addr)}

        # Walk to root
        root_id = message_id
        while root_id in visible and visible[root_id].in_reply_to:
            parent = visible[root_id].in_reply_to
            if parent in visible:
                root_id = parent
            else:
                break

        # Collect descendants
        thread_ids = {root_id}
        changed = True
        while changed:
            changed = False
            for m in visible.values():
                if m.id not in thread_ids and m.in_reply_to in thread_ids:
                    thread_ids.add(m.id)
                    changed = True

        thread = [m for m in visible.values() if m.id in thread_ids]
        thread.sort(key=lambda m: m.timestamp)
        return thread

    # -- mailing lists --

    def create_list(self, name: str, creator: Address, description: str = "") -> None:
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).isoformat()
        try:
            self._conn.execute(
                "INSERT INTO mailing_lists (name, description, created_by, created_at) VALUES (?, ?, ?, ?)",
                (name, description, str(creator), now),
            )
            # Auto-join the creator
            self._conn.execute(
                "INSERT OR IGNORE INTO list_members (list_name, address) VALUES (?, ?)",
                (name, str(creator)),
            )
            self._conn.commit()
        except sqlite3.IntegrityError:
            raise ValueError(f"List '{name}' already exists")

    def is_list(self, name: str) -> bool:
        row = self._conn.execute(
            "SELECT 1 FROM mailing_lists WHERE name = ?", (name,)
        ).fetchone()
        return row is not None

    def get_list_info(self, name: str) -> dict | None:
        row = self._conn.execute(
            "SELECT name, description, created_by, created_at FROM mailing_lists WHERE name = ?",
            (name,),
        ).fetchone()
        if row is None:
            return None
        return {"name": row[0], "description": row[1], "created_by": row[2], "created_at": row[3]}

    def get_all_lists(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT name, description, created_by, created_at FROM mailing_lists ORDER BY name"
        ).fetchall()
        return [{"name": r[0], "description": r[1], "created_by": r[2], "created_at": r[3]} for r in rows]

    def get_joined_lists(self, addr: Address) -> list[dict]:
        rows = self._conn.execute(
            """SELECT ml.name, ml.description, ml.created_by, ml.created_at
               FROM mailing_lists ml
               JOIN list_members lm ON ml.name = lm.list_name
               WHERE lm.address = ?
               ORDER BY ml.name""",
            (str(addr),),
        ).fetchall()
        return [{"name": r[0], "description": r[1], "created_by": r[2], "created_at": r[3]} for r in rows]

    def join_list(self, name: str, addr: Address) -> None:
        if not self.is_list(name):
            raise ValueError(f"List '{name}' does not exist")
        self._conn.execute(
            "INSERT OR IGNORE INTO list_members (list_name, address) VALUES (?, ?)",
            (name, str(addr)),
        )
        self._conn.commit()

    def leave_list(self, name: str, addr: Address) -> None:
        if not self.is_list(name):
            raise ValueError(f"List '{name}' does not exist")
        self._conn.execute(
            "DELETE FROM list_members WHERE list_name = ? AND address = ?",
            (name, str(addr)),
        )
        self._conn.commit()

    def post_to_list(
        self, name: str, sender: Address, subject: str, body: str,
        in_reply_to: str | None = None,
    ) -> Message:
        if not self.is_list(name):
            raise ValueError(f"List '{name}' does not exist")
        if not subject or not subject.strip():
            raise ValueError("Subject cannot be empty")
        if not body or not body.strip():
            raise ValueError("Body cannot be empty")

        list_addr = Address(name=name, colony="lists")
        msg = Message(
            sender=sender,
            recipients=[list_addr],
            subject=subject,
            body=body,
            in_reply_to=in_reply_to,
        )

        recipients_str = str(list_addr)
        self._conn.execute(
            """INSERT OR IGNORE INTO messages
               (id, timestamp, sender, recipients, subject, body, in_reply_to)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (msg.id, msg.timestamp.isoformat(), str(msg.sender),
             recipients_str, msg.subject, msg.body, msg.in_reply_to),
        )
        self._conn.execute(
            "INSERT OR IGNORE INTO list_posts (message_id, list_name) VALUES (?, ?)",
            (msg.id, name),
        )
        self._conn.commit()
        return msg

    def list_posts(self, name: str) -> list[Message]:
        """Top-level posts in a list, newest first."""
        rows = self._conn.execute(
            """SELECT m.id, m.timestamp, m.sender, m.recipients,
                      m.subject, m.body, m.in_reply_to
               FROM messages m
               JOIN list_posts lp ON m.id = lp.message_id
               WHERE lp.list_name = ? AND m.in_reply_to IS NULL
               ORDER BY m.timestamp DESC""",
            (name,),
        ).fetchall()
        return [self._row_to_message(r) for r in rows]

    def read_list_post(self, message_id: str) -> Message | None:
        row = self._conn.execute(
            """SELECT m.id, m.timestamp, m.sender, m.recipients,
                      m.subject, m.body, m.in_reply_to
               FROM messages m
               JOIN list_posts lp ON m.id = lp.message_id
               WHERE m.id = ?""",
            (message_id,),
        ).fetchone()
        if row is None:
            return None
        return self._row_to_message(row)

    def reply_count(self, message_id: str) -> int:
        """Count all replies in a thread (direct and nested)."""
        all_ids = {message_id}
        changed = True
        while changed:
            changed = False
            placeholders = ",".join("?" * len(all_ids))
            rows = self._conn.execute(
                f"""SELECT m.id FROM messages m
                    JOIN list_posts lp ON m.id = lp.message_id
                    WHERE m.in_reply_to IN ({placeholders})""",
                list(all_ids),
            ).fetchall()
            for (mid,) in rows:
                if mid not in all_ids:
                    all_ids.add(mid)
                    changed = True
        return len(all_ids) - 1

    def list_thread(self, message_id: str) -> list[Message]:
        """Get a list post and all its replies, oldest first."""
        # Find root
        root_id = message_id
        while True:
            row = self._conn.execute(
                "SELECT in_reply_to FROM messages WHERE id = ?", (root_id,)
            ).fetchone()
            if row is None or row[0] is None:
                break
            root_id = row[0]

        # Collect all in thread
        all_ids = {root_id}
        rows = []
        root_row = self._conn.execute(
            """SELECT m.id, m.timestamp, m.sender, m.recipients,
                      m.subject, m.body, m.in_reply_to
               FROM messages m WHERE m.id = ?""",
            (root_id,),
        ).fetchone()
        if root_row:
            rows.append(root_row)

        changed = True
        while changed:
            changed = False
            placeholders = ",".join("?" * len(all_ids))
            new_rows = self._conn.execute(
                f"""SELECT m.id, m.timestamp, m.sender, m.recipients,
                           m.subject, m.body, m.in_reply_to
                    FROM messages m
                    JOIN list_posts lp ON m.id = lp.message_id
                    WHERE m.in_reply_to IN ({placeholders})""",
                list(all_ids),
            ).fetchall()
            for r in new_rows:
                if r[0] not in all_ids:
                    all_ids.add(r[0])
                    rows.append(r)
                    changed = True

        messages = [self._row_to_message(r) for r in rows]
        messages.sort(key=lambda m: m.timestamp)
        return messages

    def list_unread_activity(self, addr: Address) -> list[dict]:
        """For each joined list, count posts not yet read by this address.
        Excludes posts sent by this address."""
        lists = self.get_joined_lists(addr)
        activity = []
        for ml in lists:
            row = self._conn.execute(
                """SELECT COUNT(*) FROM list_posts lp
                   JOIN messages m ON lp.message_id = m.id
                   WHERE lp.list_name = ?
                   AND m.sender != ?
                   AND lp.message_id NOT IN (
                       SELECT message_id FROM list_reads WHERE address = ?
                   )""",
                (ml["name"], str(addr), str(addr)),
            ).fetchone()
            count = row[0] if row else 0
            if count > 0:
                activity.append({"list": ml["name"], "count": count})
        return activity

    # -- presence --

    def list_waiting(self, stale_minutes: float = 30) -> list[WaitingStatus]:
        """List minds currently waiting for mail. Cleans up stale entries."""
        from datetime import datetime, timedelta, timezone

        cutoff = (datetime.now(timezone.utc) - timedelta(minutes=stale_minutes)).isoformat()
        self._conn.execute("DELETE FROM presence WHERE started_at < ?", (cutoff,))
        self._conn.commit()

        rows = self._conn.execute("SELECT address, waiting_for, started_at FROM presence").fetchall()
        result = []
        for addr_str, waiting_for_str, started_at_str in rows:
            ts = datetime.fromisoformat(started_at_str)
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            result.append(WaitingStatus(
                address=Address.parse(addr_str),
                waiting_for=Address.parse(waiting_for_str) if waiting_for_str else None,
                started_at=ts,
            ))
        return result

    def _register_waiting(self, addr: Address, waiting_for: Address | None) -> None:
        from datetime import datetime, timezone

        self._conn.execute(
            "INSERT OR REPLACE INTO presence (address, waiting_for, started_at) VALUES (?, ?, ?)",
            (str(addr), str(waiting_for) if waiting_for else None, datetime.now(timezone.utc).isoformat()),
        )
        self._conn.commit()

    def _unregister_waiting(self, addr: Address) -> None:
        self._conn.execute("DELETE FROM presence WHERE address = ?", (str(addr),))
        self._conn.commit()

    def _check_mutual_wait(self, addr: Address, waiting_for: Address) -> bool:
        """Returns True if waiting_for is already waiting for addr (deadlock)."""
        row = self._conn.execute(
            "SELECT 1 FROM presence WHERE address = ? AND waiting_for = ?",
            (str(waiting_for), str(addr)),
        ).fetchone()
        return row is not None

    # -- wait --

    def wait(
        self,
        addr: Address,
        from_addr: Address | None = None,
        timeout: float | None = None,
    ) -> Message | None:
        """Block until an unread message exists for addr. Returns the message, or None on timeout.

        Registers presence while waiting. Checks for unread messages immediately
        (catches mail that arrived before wait started), then polls.
        """
        import time

        self._register_waiting(addr, from_addr)
        try:
            where = "d.recipient = ? AND d.is_read = 0"
            params: list[str] = [str(addr)]
            if from_addr:
                where += " AND m.sender = ?"
                params.append(str(from_addr))

            deadline = time.monotonic() + timeout if timeout else None
            poll_interval = 0.5

            while True:
                # Check DMs
                row = self._conn.execute(
                    f"""SELECT m.id, m.timestamp, m.sender, m.recipients,
                               m.subject, m.body, m.in_reply_to
                        FROM messages m
                        JOIN deliveries d ON m.id = d.message_id
                        WHERE {where}
                        ORDER BY m.timestamp DESC LIMIT 1""",
                    params,
                ).fetchone()

                if row:
                    return self._row_to_message(row)

                # Check list activity (if not filtering by sender)
                if not from_addr:
                    activity = self.list_unread_activity(addr)
                    if activity:
                        # Return the newest unread list post
                        list_name = activity[0]["list"]
                        list_row = self._conn.execute(
                            """SELECT m.id, m.timestamp, m.sender, m.recipients,
                                      m.subject, m.body, m.in_reply_to
                               FROM messages m
                               JOIN list_posts lp ON m.id = lp.message_id
                               WHERE lp.list_name = ?
                               AND m.sender != ?
                               AND lp.message_id NOT IN (
                                   SELECT message_id FROM list_reads WHERE address = ?
                               )
                               ORDER BY m.timestamp DESC LIMIT 1""",
                            (list_name, str(addr), str(addr)),
                        ).fetchone()
                        if list_row:
                            return self._row_to_message(list_row)

                if deadline and time.monotonic() >= deadline:
                    return None

                time.sleep(poll_interval)
        finally:
            self._unregister_waiting(addr)

    # -- internal --

    def _migrate(self) -> None:
        for sql in _MIGRATIONS:
            try:
                self._conn.execute(sql)
                self._conn.commit()
            except sqlite3.OperationalError:
                pass  # column already exists

    # -- entity ↔ DTO translation --

    def _insert_message(self, msg: Message) -> None:
        recipients_str = ",".join(str(r) for r in msg.recipients)
        self._conn.execute(
            """INSERT OR IGNORE INTO messages
               (id, timestamp, sender, recipients, subject, body, in_reply_to)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                msg.id,
                msg.timestamp.isoformat(),
                str(msg.sender),
                recipients_str,
                msg.subject,
                msg.body,
                msg.in_reply_to,
            ),
        )
        for recipient in msg.recipients:
            self._conn.execute(
                "INSERT OR IGNORE INTO deliveries (message_id, recipient) VALUES (?, ?)",
                (msg.id, str(recipient)),
            )
        self._conn.commit()

    @staticmethod
    def _row_to_message(row: tuple) -> Message:
        from datetime import datetime, timezone

        id_, timestamp_str, sender_str, recipients_str, subject, body, in_reply_to = row
        timestamp = datetime.fromisoformat(timestamp_str)
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=timezone.utc)
        return Message(
            id=id_,
            timestamp=timestamp,
            sender=Address.parse(sender_str),
            recipients=[Address.parse(r.strip()) for r in recipients_str.split(",")],
            subject=subject,
            body=body,
            in_reply_to=in_reply_to,
        )
