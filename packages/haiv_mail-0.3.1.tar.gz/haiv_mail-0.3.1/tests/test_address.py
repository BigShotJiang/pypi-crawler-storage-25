import pytest

from haiv_mail.address import Address


def test_parse_valid():
    addr = Address.parse("仁@haiv-mail")
    assert addr.name == "仁"
    assert addr.colony == "haiv-mail"


def test_str_roundtrip():
    addr = Address.parse("luna@haiv")
    assert str(addr) == "luna@haiv"
    assert Address.parse(str(addr)) == addr


def test_equality():
    assert Address.parse("a@b") == Address.parse("a@b")
    assert Address.parse("a@b") != Address.parse("a@c")


def test_hashable():
    s = {Address.parse("a@b"), Address.parse("a@b"), Address.parse("c@d")}
    assert len(s) == 2


def test_parse_missing_at():
    with pytest.raises(ValueError, match="missing @"):
        Address.parse("noatsign")


def test_parse_empty_name():
    with pytest.raises(ValueError, match="empty part"):
        Address.parse("@colony")


def test_parse_empty_colony():
    with pytest.raises(ValueError, match="empty part"):
        Address.parse("name@")


def test_unicode_address():
    addr = Address.parse("仁@はいぶ")
    assert addr.name == "仁"
    assert addr.colony == "はいぶ"
    assert str(addr) == "仁@はいぶ"
