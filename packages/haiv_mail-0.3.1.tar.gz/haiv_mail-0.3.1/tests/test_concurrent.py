"""Integration tests for concurrent access to a shared mail.db."""

import multiprocessing
from pathlib import Path

from haiv_mail.address import Address
from haiv_mail.mailbox import Mailbox


import time


def _send_delayed(db_path: str, sender_name: str, recipient: str, delay: float) -> None:
    """Send a single message after a delay. Used to test wait()."""
    time.sleep(delay)
    mb = Mailbox(Path(db_path))
    mb.send(
        sender=Address.parse(f"{sender_name}@colony"),
        recipients=[Address.parse(recipient)],
        subject=f"delayed from {sender_name}",
        body="arrived",
    )


def _send_messages(db_path: str, sender_name: str, count: int, recipient: str = "inbox@colony") -> None:
    mb = Mailbox(Path(db_path))
    sender = Address.parse(f"{sender_name}@colony")
    recip = Address.parse(recipient)
    for i in range(count):
        mb.send(
            sender=sender,
            recipients=[recip],
            subject=f"msg {i} from {sender_name}",
            body=f"body {i}",
        )


def test_concurrent_writers(tmp_path: Path):
    """Multiple processes writing to the same db simultaneously."""
    db_path = str(tmp_path / "mail.db")
    num_writers = 4
    msgs_per_writer = 25

    processes = []
    for i in range(num_writers):
        p = multiprocessing.Process(
            target=_send_messages,
            args=(db_path, f"mind{i}", msgs_per_writer),
        )
        processes.append(p)

    for p in processes:
        p.start()
    for p in processes:
        p.join()

    # All processes should succeed
    for p in processes:
        assert p.exitcode == 0

    # All messages should be delivered
    mb = Mailbox(Path(db_path))
    recipient = Address.parse("inbox@colony")
    messages = mb.list_messages(recipient)
    assert len(messages) == num_writers * msgs_per_writer

    # Each writer's messages are all present
    for i in range(num_writers):
        sender = Address.parse(f"mind{i}@colony")
        sent = mb.list_sent(sender)
        assert len(sent) == msgs_per_writer


def test_read_while_writing(tmp_path: Path):
    """One process writes while another reads — no blocking."""
    db_path = tmp_path / "mail.db"
    mb = Mailbox(db_path)
    recipient = Address.parse("reader@colony")

    # Seed some messages
    for i in range(10):
        mb.send(
            sender=Address.parse("seeder@colony"),
            recipients=[recipient],
            subject=f"seed {i}",
            body=f"body {i}",
        )

    # Writer process adds more while we read
    writer = multiprocessing.Process(
        target=_send_messages,
        args=(str(db_path), "writer", 50, "reader@colony"),
    )
    writer.start()

    # Read repeatedly while writer is active
    read_count = 0
    for _ in range(20):
        messages = mb.list_messages(recipient)
        read_count += len(messages)

    writer.join()
    assert writer.exitcode == 0

    # We should have read successfully every time (read_count > 0)
    assert read_count > 0

    # Final state: all messages present
    messages = mb.list_messages(recipient)
    assert len(messages) == 60  # 10 seeded + 50 from writer


def test_wait_returns_on_new_message(tmp_path: Path):
    """wait() blocks until a message arrives from another process."""
    db_path = tmp_path / "mail.db"
    mb = Mailbox(db_path)
    recipient = Address.parse("waiter@colony")

    # Another process sends after 1 second
    sender_proc = multiprocessing.Process(
        target=_send_delayed,
        args=(str(db_path), "notifier", "waiter@colony", 1.0),
    )
    sender_proc.start()

    start = time.monotonic()
    msg = mb.wait(recipient, timeout=5.0)
    elapsed = time.monotonic() - start

    sender_proc.join()
    assert sender_proc.exitcode == 0
    assert msg is not None
    assert msg.subject == "delayed from notifier"
    assert elapsed >= 0.8  # waited for the message
    assert elapsed < 4.0   # didn't wait until timeout


def test_wait_timeout_returns_none(tmp_path: Path):
    """wait() returns None when timeout expires with no mail."""
    db_path = tmp_path / "mail.db"
    mb = Mailbox(db_path)
    recipient = Address.parse("lonely@colony")

    start = time.monotonic()
    msg = mb.wait(recipient, timeout=1.0)
    elapsed = time.monotonic() - start

    assert msg is None
    assert elapsed >= 0.9


def test_wait_with_from_filter(tmp_path: Path):
    """wait() with from_addr only triggers on messages from that sender."""
    db_path = tmp_path / "mail.db"
    mb = Mailbox(db_path)
    recipient = Address.parse("waiter@colony")
    wanted = Address.parse("vip@colony")

    # Send from wrong sender first, then right sender
    def _send_two(db_path_str: str) -> None:
        m = Mailbox(Path(db_path_str))
        time.sleep(0.5)
        # This one should be ignored by the filter
        m.send(
            sender=Address.parse("nobody@colony"),
            recipients=[Address.parse("waiter@colony")],
            subject="from nobody",
            body="ignore me",
        )
        time.sleep(1.0)
        # This one should trigger the wait
        m.send(
            sender=Address.parse("vip@colony"),
            recipients=[Address.parse("waiter@colony")],
            subject="from vip",
            body="notice me",
        )

    proc = multiprocessing.Process(target=_send_two, args=(str(db_path),))
    proc.start()

    msg = mb.wait(recipient, from_addr=wanted, timeout=5.0)

    proc.join()
    assert msg is not None
    assert msg.subject == "from vip"


def test_wait_returns_immediately_for_existing_unread(tmp_path: Path):
    """Bug fix: wait() should return immediately if unread mail already exists."""
    db_path = tmp_path / "mail.db"
    mb = Mailbox(db_path)
    recipient = Address.parse("waiter@colony")

    # Message arrives BEFORE wait starts
    mb.send(
        sender=Address.parse("early@colony"),
        recipients=[recipient],
        subject="already here",
        body="arrived before wait",
    )

    start = time.monotonic()
    msg = mb.wait(recipient, timeout=5.0)
    elapsed = time.monotonic() - start

    assert msg is not None
    assert msg.subject == "already here"
    assert elapsed < 1.0  # should return immediately, not wait for timeout


def _wait_and_check(db_path_str: str, addr_str: str) -> None:
    """Wait with a short timeout in a subprocess."""
    mb = Mailbox(Path(db_path_str))
    mb.wait(Address.parse(addr_str), timeout=2.0)


def test_presence_registered_during_wait(tmp_path: Path):
    """wait() registers and cleans up presence."""
    db_path = tmp_path / "mail.db"
    mb = Mailbox(db_path)
    addr = Address.parse("waiter@colony")

    # Start wait in another process
    proc = multiprocessing.Process(
        target=_wait_and_check,
        args=(str(db_path), "waiter@colony"),
    )
    proc.start()

    time.sleep(0.5)

    # Should be registered while waiting
    waiting = mb.list_waiting()
    assert any(w.address == addr for w in waiting)

    proc.join()
    assert proc.exitcode == 0

    # Should be cleaned up after wait returns
    waiting = mb.list_waiting()
    assert not any(w.address == addr for w in waiting)
