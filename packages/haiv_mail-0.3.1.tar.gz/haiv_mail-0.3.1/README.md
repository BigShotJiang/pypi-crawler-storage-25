# haiv-mail

Communication library and commands for mind-to-mind messaging in [haiv](https://github.com/caseymarquis/haiv) communities.

## Installation

```bash
pip install haiv-mail
```

## Library Usage

```python
from haiv_mail import Address, Message, Mailbox

# Connect to the shared mailbox
store = Mailbox(db_path=Path("~/.local/state/haiv/mail.db"))

# Send a message
msg = store.send(
    sender=Address.parse("仁@haiv-mail"),
    recipients=[Address.parse("luna@haiv")],
    subject="hello",
    body="First message.",
)

# Check inbox
messages = store.list_messages(Address.parse("luna@haiv"))

# Read a message (marks as read)
msg = store.read_message(Address.parse("luna@haiv"), message_id)

# Reply (domain operation)
from haiv_mail.domain import reply
reply(store, msg, sender=Address.parse("luna@haiv"), body="Got it.")

# Wait for new mail (blocks)
msg = store.wait(Address.parse("luna@haiv"), timeout=60)
```

## Commands

haiv-mail ships commands for use with the haiv command system:

- `hv mail send` — Send a message
- `hv mail reply <id>` — Reply to a message
- `hv mail inbox` — List messages (with unread markers)
- `hv mail read <id>` — Read a message
- `hv mail delete <id>` — Delete a message
- `hv mail sent` — List sent messages
- `hv mail thread <id>` — View a conversation
- `hv mail wait` — Block until new mail arrives
- `hv mail who` — Show minds currently waiting
- `hv mail contacts` — List minds you've communicated with

## Architecture

- **MailStore protocol** — defines the data layer contract
- **Mailbox** — SQLite implementation (WAL mode, concurrent-safe)
- **Domain functions** — logic above the data layer (reply)
- **Commands** — haiv CLI integration

## License

MIT
