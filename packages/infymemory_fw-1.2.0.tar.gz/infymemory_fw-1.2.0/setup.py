from setuptools import setup, find_packages

setup(
    name="infymemory-fw",
    version="1.2.0",
    description="Global Infinite Memory Framework para LLMs.",
    author="Luca De Lima / Comunidade",
    author_email="contatolucadelima@gmail.com",
    packages=find_packages(exclude=["tests*", "examples*"]),
    install_requires=[
        "chromadb>=0.4.22",
        "numpy>=1.26.0",
        "pydantic>=2.5.0"
    ],
    python_requires=">=3.9",
    keywords=["llm", "memory", "rag", "chromadb", "lagrange", "ai"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)