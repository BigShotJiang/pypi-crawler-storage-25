# 🧠 InfyMemory Framework

**O motor de contexto infinito para LLMs, movido a otimização matemática.**

O **InfyMemory** é um framework open-source em Python projetado para resolver o problema clássico de limite de tokens e "amnésia" das Inteligências Artificiais. Em vez de apenas empilhar logs de chat em um banco vetorial, o InfyMemory utiliza uma arquitetura de três camadas (RAM, Disco e Matemática) para garantir que sua IA tenha um contexto rico, sem latência e sem redundâncias.

Ideal para integrações com **n8n**, agentes autônomos locais, assistentes virtuais de longa duração e fluxos de **hiperautomação**.

---

## ✨ Por que o InfyMemory?

Sistemas RAG (Retrieval-Augmented Generation) tradicionais sofrem de poluição de contexto: se o usuário repete a mesma coisa cinco vezes, a busca vetorial retorna cinco documentos iguais, desperdiçando tokens e confundindo a IA.

O InfyMemory resolve isso com:

* ⚡ **Contexto Deslizante (RAM Buffer):** Memória de curtíssimo prazo com complexidade $O(1)$ para latência zero durante a conversa.
* 🗜️ **Destilador Semântico:** Transforma mensagens antigas em "fatos" canônicos em background, sem travar a resposta principal.
* 🧮 **Otimizador Lagrangiano:** Um filtro matemático de busca que penaliza severamente informações redundantes e prioriza a diversidade do contexto.
* 🧹 **Faxina Noturna (Clustering):** Varre o banco de dados silenciosamente para fundir milhares de memórias repetidas em verdades absolutas, mantendo o banco leve e performático (otimizado para hardware Apple Silicon).

---

## 📐 A Matemática por Trás (Otimização Lagrangiana)

Ao buscar uma memória, o framework não traz apenas o que é mais parecido com a pergunta. Ele calcula um balanço perfeito usando multiplicadores de Lagrange para garantir um contexto rico:

$$Score = (\lambda_{rel} \cdot Rel) - (\beta_{red} \cdot Red) - (\gamma_{time} \cdot \ln(1 + Idade))$$

Onde o algoritmo:
1.  Prioriza a **Relevância** ($Rel$).
2.  Pune severamente a **Redundância** ($Red$).
3.  Aplica um leve decaimento baseado no **Tempo** ($Idade$).

---

## 🚀 Instalação

O framework é leve e desenhado para rodar localmente com máxima eficiência.

```bash
pip install infymemory chromadb numpy

## 💻 Quick Start: Llama-3 Local (Ollama)
import requests
from infymemory.core import InfyMemoryCore
from infymemory.distilizer import LLMDistiller

# 1. Defina como a biblioteca vai falar com a sua IA (Ex: Ollama rodando Llama-3)
def ollama_llm(prompt: str) -> str:
    response = requests.post(
        "http://localhost:11434/api/generate",
        json={"model": "llama3", "prompt": prompt, "stream": False, "format": "json"}
    )
    return response.json().get("response", "[]")

# 2. Inicialize o Destilador e o Coração do Framework
distiller = LLMDistiller(llm_callable=ollama_llm)
memory = InfyMemoryCore(db_path="./meu_banco_infinito", ram_limit=5, distiller=distiller)

# 3. Use na sua aplicação (n8n, Terminal, Webhook, etc)
# Adicione a conversa atual...
memory.add_interaction("Qual é o foco da nossa automação?", "Estamos focando em cobranças via n8n.")

# ... e quando precisar responder, puxe o contexto perfeito em milissegundos!
contexto_perfeito = memory.get_context("O que eu estou automatizando?")
print(contexto_perfeito['historical_disk'])
* **

---

## 🏗️ Arquitetura em 3 Pilares

* **O Motor de Curto Prazo (Core & VectorStore):** Mantém a fluidez da conversa. Quando a RAM enche, ele trava os dados em lote e os envia para o destilador.
* **O Trabalhador Invisível (LLMDistiller):** Captura as mensagens que "caíram" da RAM e extrai apenas regras absolutas, fatos e preferências no formato JSON, salvando-os de forma persistente.
* **A Faxina (LagrangeOptimizer):** Roda processos de otimização para agrupar memórias com similaridade $> 0.90$ e solicita que a LLM as funda, eliminando redundâncias e mantendo o banco saudável.

---

## ⚙️ Casos de Uso

* **Orquestração de Funcionários Digitais:** Mantém o alinhamento e o histórico de ações de agentes autônomos sem estourar a janela de contexto.
* **Assistentes de Longa Duração:** Companheiros de IA que recordam rotinas e preferências passadas sem a necessidade de repetir informações manualmente no prompt.
* **Automação B2Dev:** Funciona como uma camada de memória persistente para fluxos de CI/CD e CRMs operados inteiramente por IA.

---

## 🤝 Contribuindo

Pull requests são muito bem-vindos. Para mudanças maiores, por favor abra uma *issue* primeiro para discutirmos o que você gostaria de alterar.

1.  Faça o **Fork** do projeto.
2.  Crie sua **Feature Branch** (`git checkout -b feature/InovacaoIncrivel`).
3.  Faça o **Commit** de suas mudanças (`git commit -m 'Add some InovacaoIncrivel'`).
4.  Faça o **Push** para a Branch (`git push origin feature/InovacaoIncrivel`).
5.  Abra um **Pull Request**.

---

## 📄 Licença

Este projeto está licenciado sob a **Licença MIT** - veja o arquivo [LICENSE](LICENSE) para detalhes.

> **Construído para empoderar arquitetos de hiperautomação.**