import sys
import os
import time

# O "truque mágico" para o Python achar a pasta infymemory
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from infymemory.core import InfyMemoryCore
from infymemory.distilizer import LLMDistiller

# Usamos um mock ultrarrápido para a LLM para não termos que esperar
# horas gerando 10.000 textos reais na sua máquina local durante o teste.
def mock_llm_fast(prompt: str) -> str:
    return '["Fato fundido e consolidado com sucesso."]'

def run_stress_test():
    print("=== Iniciando Teste de Estresse (10.000 Memórias) ===\n")
    
    # 1. Setup Isolado para o Teste
    # Criamos um banco temporário apenas para este teste
    db_path = "./tests/stress_db"
    distiller = LLMDistiller(llm_callable=mock_llm_fast)
    
    # Instanciamos o core com nosso destilador rápido
    core = InfyMemoryCore(db_path=db_path, ram_limit=10, distiller=distiller)

    # 2. Povoamento em Massa (Simulando 1 ano de conversas intensas)
    print("1. Povoando o banco vetorial com 10.000 fatos (Isso testa o I/O do disco)...")
    start_time = time.time()
    
    for i in range(10000):
        # Injetamos 500 fatos IDÊNTICOS de propósito para a faxina ter o que limpar depois
        if i < 500:
            texto = "O usuário Luca está desenvolvendo o InfyMemory com Python e ChromaDB."
        else:
            texto = f"Log de operação aleatória número {i}: Sistema em funcionamento normal."
            
        core.vector_store.save_fact(texto, metadata={"origem": "teste_carga"})
        
        # Feedback visual a cada 2500 inserções
        if (i + 1) % 2500 == 0:
            print(f"   -> {(i + 1)} memórias indexadas...")
            
    print(f"✅ Povoamento concluído em {time.time() - start_time:.2f} segundos.\n")

    # 3. Teste de Latência (O momento da verdade)
    print("2. Testando Latência de Busca (Com Filtro Lagrangiano ativo)...")
    query = "O que o Luca está desenvolvendo?"
    
    start_search = time.time()
    contexto = core.get_context(query=query, n_results=10) 
    search_time = (time.time() - start_search) * 1000 # Convertendo para milissegundos
    
    print(f"✅ Busca e filtragem concluídas em {search_time:.2f} ms.")
    print(f"   -> A latência ideal para não travar automações é abaixo de 100ms.\n")

    # 4. Teste da Faxina Noturna (Clustering Pesado)
    print("3. Testando Faxina Noturna (Cálculo da matriz de 10k x 10k)...")
    print("   Isso vai exigir do processador. Calculando 100 milhões de relações...")
    start_cleanup = time.time()
    
    # Rodamos o otimizador direto com um threshold rigoroso
    core.optimizer.run_nightly_cleanup(core.vector_store, distiller, similarity_threshold=0.95)
    
    print(f"✅ Faxina concluída em {time.time() - start_cleanup:.2f} segundos.")
    print("=== Teste Finalizado ===")

if __name__ == "__main__":
    run_stress_test()