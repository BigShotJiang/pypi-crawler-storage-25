import sys
import os
import requests

# O truque mágico para o Python achar a pasta raiz
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from infymemory.core import InfyMemoryCore
from infymemory.distilizer import LLMDistiller

# 1. A Ponte com o seu M4 (Ollama)
def ollama_extractor(prompt: str) -> str:
    print("   [IA Trabalhando...] Lendo as mensagens e extraindo fatos...")
    url = "http://localhost:11434/api/generate"
    
    # Adicionamos um reforço extra no prompt para modelos menores
    prompt_reforcado = prompt + "\n\nCRÍTICO: Responda APENAS com um array JSON válido. Exemplo: [\"Fato 1\", \"Fato 2\"]"
    
    payload = {
        "model": "phi3",
        "prompt": prompt_reforcado,
        "stream": False,
        "options": {
            "temperature": 0.0,       # Zero criatividade, foco apenas nos dados
            "num_predict": 150
        # Removemos a trava do "format": "json" para o modelo respirar melhor
        }
    }
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        raw_response = response.json().get("response", "[]")
        
        # O NOSSO X-9: Vai imprimir na tela exatamente o que a IA pensou
        print(f"\n   [Debug Phi-3] Texto Bruto: {raw_response}\n") 
        
        return raw_response
    except Exception as e:
        print(f"Erro na comunicação com a LLM: {e}")
        return "[]"

def run_real_test():
    print("=== Iniciando Teste com LLM Real (Phi-3) ===\n")
    
    # 2. Instanciando o Framework
    distiller = LLMDistiller(llm_callable=ollama_extractor)
    
    # Colocamos o limite de RAM em APENAS 2 pares de mensagens. 
    # Isso significa que na 3ª interação, a RAM vai estourar e ele vai chamar a IA para resumir.
    memory = InfyMemoryCore(db_path="./tests/real_db", ram_limit=2, distiller=distiller)

    # 3. Simulando a conversa com o usuário
    conversa = [
        ("Oi, meu nome é Luca e eu sou Desenvolvedor e Arquiteto de Automação.", "Olá Luca! Como posso ajudar hoje?"),
        ("Eu estou construindo um CRM usando n8n chamado Loomie.", "Excelente! O Loomie foca em qual mercado?"),
        ("Focamos no modelo B2Dev, criando automações para outros desenvolvedores.", "Entendido, um nicho muito técnico e promissor!"),
        ("Acabei de comprar um MacBook para focar nisso.", "Ótima máquina para rodar ferramentas locais de IA.")
    ]

    print("Iniciando chat (Aguarde o aviso de limite de RAM)...\n")
    for pergunta, resposta in conversa:
        print(f"User: {pergunta}")
        # A mágica acontece aqui dentro:
        memory.add_interaction(pergunta, resposta)
        
    print("\n---------------------------------------------------")
    print("Chat finalizado. Vamos ver o que a IA salvou no HD Vetorial!")
    print("---------------------------------------------------\n")

    # 4. Buscando na Memória Infinita
    contexto = memory.get_context("O que o usuário está construindo e para quem?")
    
    fatos_salvos = contexto.get('historical_disk', [])
    if not fatos_salvos:
        print("Nenhum fato foi salvo. Verifique se a IA retornou o JSON corretamente.")
    else:
        print("Fatos extraídos e indexados com sucesso pelo ChromaDB:")
        for fato in fatos_salvos:
            print(f"✅ {fato}")

if __name__ == "__main__":
    run_real_test()