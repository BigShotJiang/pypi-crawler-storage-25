import sys
import os
import numpy as np

# --- O TRUQUE MÁGICO DO PYTHON ---
# Isso força o script a olhar para a pasta anterior (raiz do infymemory) ANTES de tentar importar.
# ATENÇÃO: Isso precisa obrigatoriamente ficar na linha acima do 'from optimizer'
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from infymemory.optimizer import LagrangeOptimizer

def run_math_test():
    print("=== Iniciando Teste da Matemática Lagrangiana ===\n")
    
    # 1. Setup com pesos rigorosos para redundância (beta_red alto)
    opt = LagrangeOptimizer(lambda_rel=1.0, beta_red=1.5, gamma_time=0.1)

    # 2. Criando vetores sintéticos (Imagine que são coordenadas no espaço)
    query_emb = np.array([1.0, 0.0, 0.0])

    doc1_emb = np.array([1.0, 0.0, 0.0])  # Perfeito (Relevância 1.0)
    doc2_emb = np.array([0.98, 0.02, 0.0])  # Quase idêntico ao Doc 1 (Muito redundante)
    doc3_emb = np.array([0.4, 0.8, 0.0])  # Assunto diferente

    raw_results = {
        'documents': [['Fato A: Config n8n', 'Fato B: Setup n8n (Redundante)', 'Fato C: Uso de Docker']],
        'embeddings': [[doc1_emb, doc2_emb, doc3_emb]],
        'metadatas': [[{'timestamp': 1600000000}] * 3],
        'query_embedding': query_emb
    }

    # 3. Execução
    selecionados = opt.filter_context(raw_results, top_k=2)

    print(f"Resultados brutos: 3 fatos")
    print(f"Selecionados pelo Filtro: {selecionados}")

    if "Fato B: Setup n8n (Redundante)" not in selecionados:
        print("\n✅ SUCESSO: O otimizador detectou redundância e priorizou a diversidade!")
    else:
        print("\n❌ FALHA: O otimizador permitiu informação duplicada.")

if __name__ == "__main__":
    run_math_test()