from abc import ABC, abstractmethod
from typing import List, Dict

class BaseDistiller(ABC):
    @abstractmethod
    def extract_facts(self, interactions: List[Dict[str, str]]) -> List[str]:
        pass

    @abstractmethod
    def fuse_facts(self, facts: List[str]) -> List[str]:
        pass