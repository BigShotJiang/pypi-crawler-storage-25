from typing import List, Dict, Any
from .vector_store import InfyVectorStore
from .interfaces import BaseDistiller
from .optimizer import LagrangeOptimizer

class InfyMemoryCore:
    def __init__(self, db_path: str = "./infy_db", ram_limit: int = 10, distiller: BaseDistiller = None, embedding_function=None):
        """
        O coração do InfyMemory Framework.
        - ram_limit: Quantidade de *pares* de interação mantidos vivos na RAM.
        - distiller: A classe que vai transformar texto longo em fatos.
        """
        self.ram_buffer: Dict[str, List[Dict[str, str]]] = {}
        self.ram_limit = ram_limit
        self.vector_store = InfyVectorStore(db_path=db_path, embedding_function=embedding_function)
        self.distiller = distiller
        self.optimizer = LagrangeOptimizer()

    def add_interaction(self, user_id: str, user_text: str, ai_text: str):
        if user_id not in self.ram_buffer:
            self.ram_buffer[user_id] = []
        
        self.ram_buffer[user_id].append({"role": "user", "content": user_text})
        self.ram_buffer[user_id].append({"role": "ai", "content": ai_text})

        if len(self.ram_buffer[user_id]) >= (self.ram_limit * 2):
            self._handle_overflow(user_id)

    def _handle_overflow(self, user_id: str):
        """A mágica do Contexto Deslizante: Remove da RAM, resume e salva no vetor."""
        if not self.distiller:
            print("[InfyMemory Aviso] Nenhum destilador plugado. Apagando RAM velha sem salvar...")
            self.ram_buffer[user_id] = self.ram_buffer[user_id][-(self.ram_limit):]
            return

        print(f"[InfyMemory] Limite de RAM atingido para usuário {user_id}. Iniciando destilação de memórias...")
        half_point = self.ram_limit
        old_messages = self.ram_buffer[user_id][:half_point]
        facts = self.distiller.extract_facts(old_messages)
        
        for fact in facts:
            self.vector_store.save_fact(fact, user_id)

        self.ram_buffer[user_id] = self.ram_buffer[user_id][half_point:]
        print(f"[InfyMemory] Limpeza concluída para usuário {user_id}. {len(facts)} fatos salvos eternamente.")

    def get_context(self, user_id: str, query: str, n_results: int = 4) -> Dict[str, Any]:
        """A busca que a LLM vai usar antes de responder qualquer pergunta."""

        raw_results = self.vector_store.search_raw(query, user_id, n_results=n_results)
        
        disk_facts = []
        if raw_results and raw_results['documents'] and raw_results['documents'][0]:
            disk_facts = raw_results['documents'][0]

        return {
            "recent_ram": self.ram_buffer.get(user_id, []),
            "historical_disk": disk_facts
        }
    
    def run_nightly_maintenance(self):
        """Dispara o processo pesado de clusterização e limpeza do banco."""
        if not self.distiller:
            print("[InfyMemory Erro] Destilador necessário para fundir memórias.")
            return
        self.optimizer.run_nightly_cleanup(self.vector_store, self.distiller)