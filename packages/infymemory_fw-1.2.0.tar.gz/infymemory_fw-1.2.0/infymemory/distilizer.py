import json
from typing import List, Dict
from .interfaces import BaseDistiller

class LLMDistiller(BaseDistiller):
    def __init__(self, llm_callable):
        """
        Recebe a função que chama o modelo local (ex: Ollama com Phi-3)
        """
        self.llm_callable = llm_callable

    def extract_facts(self, interactions: List[Dict[str, str]]) -> List[str]:
        # Monta o texto do buffer da RAM
        texto_conversa = ""
        for msg in interactions:
            autor = "Humano" if msg['role'] == 'user' else "Assistente"
            texto_conversa += f"{autor}: {msg['content']}\n"

        prompt = f"""Extraia os fatos mais importantes sobre o usuário desta conversa. 
Retorne APENAS um array JSON válido com strings. Exemplo: ["O usuário gosta de café", "O usuário mora no Brasil"].
Se não houver fatos relevantes, retorne [].

Conversa:
{texto_conversa}"""

        resposta = self.llm_callable(prompt)
        
        # Tenta converter a string devolvida pelo Phi-3 em uma lista do Python
        try:
            # Limpeza básica caso o LLM coloque texto antes/depois do JSON
            inicio = resposta.find('[')
            fim = resposta.rfind(']') + 1
            if inicio != -1 and fim != -1:
                json_str = resposta[inicio:fim]
                fatos = json.loads(json_str)
                return fatos if isinstance(fatos, list) else []
            return []
        except json.JSONDecodeError:
            print("[Distiller Aviso] Falha ao processar o JSON do modelo.")
            return []

    def fuse_facts(self, facts: List[str]) -> List[str]:
        # Esta função será usada pelo otimizador na faxina noturna
        prompt = f"""Combine estes fatos redundantes em uma única lista de fatos consolidados.
Retorne APENAS um array JSON válido.
Fatos: {facts}"""
        
        resposta = self.llm_callable(prompt)
        try:
            inicio = resposta.find('[')
            fim = resposta.rfind(']') + 1
            if inicio != -1 and fim != -1:
                return json.loads(resposta[inicio:fim])
            return []
        except:
            return facts