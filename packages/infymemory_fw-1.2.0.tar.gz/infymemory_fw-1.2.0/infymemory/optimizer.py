import numpy as np
import time
from typing import List, Dict, Any
from collections import defaultdict
from .vector_store import InfyVectorStore
from .interfaces import BaseDistiller

class LagrangeOptimizer:
    def __init__(self, lambda_rel: float = 1.0, beta_red: float = 0.5, gamma_time: float = 0.05):
        self.lambda_rel = lambda_rel
        self.beta_red = beta_red
        self.gamma_time = gamma_time

    def _cosine_similarity(self, vec1: np.ndarray, vec2: np.ndarray) -> float:
        dot_product = np.dot(vec1, vec2)
        norm = np.linalg.norm(vec1) * np.linalg.norm(vec2)
        return dot_product / norm if norm > 0 else 0.0

    def filter_context(self, raw_results: Dict[str, Any], top_k: int = 4) -> List[str]:
        """Filtro Lagrangiano em tempo real para a busca"""
        docs = raw_results.get('documents', [[]])[0]
        embs = raw_results.get('embeddings', [[]])[0]
        metas = raw_results.get('metadatas', [[]])[0]
        q_emb = np.array(raw_results.get('query_embedding', []))

        if not docs or len(docs) <= top_k: return docs
        if len(q_emb.shape) == 0 or q_emb.size == 0:
            return docs[:top_k]

        agora = time.time()
        embs_np = np.array(embs)
        if len(embs_np) == 0:
            return docs[:top_k]
        selecionados_idx, candidatos_idx = [], list(range(len(docs)))

        while len(selecionados_idx) < top_k and candidatos_idx:
            melhor_score, melhor_idx = -np.inf, -1
            for i in candidatos_idx:
                rel = self._cosine_similarity(q_emb, embs_np[i])
                red = max([self._cosine_similarity(embs_np[i], embs_np[s]) for s in selecionados_idx]) if selecionados_idx else 0.0
                idade_dias = max((agora - metas[i].get('timestamp', agora)) / 86400.0, 0)
                
                score = (self.lambda_rel * rel) - (self.beta_red * red) - (self.gamma_time * np.log1p(idade_dias))
                if score > melhor_score:
                    melhor_score, melhor_idx = score, i
            selecionados_idx.append(melhor_idx)
            candidatos_idx.remove(melhor_idx)
        return [docs[i] for i in selecionados_idx]

    def run_nightly_cleanup(self, vector_store: InfyVectorStore, distiller: BaseDistiller, similarity_threshold: float = 0.85):
        """
        Calcula a matriz de similaridade de todo o banco agrupando por user_id,
        agrupa vetores repetidos por usuário, pede para o LLM fundi-los,
        salva o novo e deleta os velhos. Evita vazamento de contexto entre usuários.
        """
        data = vector_store.get_all_memory()
        docs = data.get('documents', [])
        embs = data.get('embeddings', [])
        ids = data.get('ids', [])
        metadatas = data.get('metadatas', [])

        if not docs or len(docs) < 2:
            print("[InfyMemory Otimizador] Poucos dados para faxina.")
            return

        print(f"[InfyMemory Otimizador] Analisando {len(docs)} memórias para redundância...")
        
        # Agrupamento por user_id extraído dos metadados
        user_data: Dict[str, Dict[str, Any]] = defaultdict(lambda: {"docs": [], "embs": [], "ids": [], "indices": []})
        
        for idx, (doc, emb, meta) in enumerate(zip(docs, embs, metadatas)):
            user_id = meta.get("user_id", "default")
            user_data[user_id]["docs"].append(doc)
            user_data[user_id]["embs"].append(emb)
            user_data[user_id]["ids"].append(ids[idx])
            user_data[user_id]["indices"].append(idx)
        
        total_deleted = 0
        
        # Processar cada usuário isoladamente
        for user_id, user_info in user_data.items():
            user_docs = user_info["docs"]
            user_embs = user_info["embs"]
            user_ids = user_info["ids"]
            
            if len(user_docs) < 2:
                print(f"[InfyMemory Otimizador] Usuário {user_id}: Poucos dados para faxina.")
                continue
            
            print(f"[InfyMemory Otimizador] Processando usuário {user_id} com {len(user_docs)} memórias...")
            
            # Matriz de similaridade apenas para este usuário
            embs_matrix = np.array(user_embs)
            if embs_matrix.ndim != 2 or len(embs_matrix) != len(user_docs):
                print(f"[InfyMemory Otimizador] Usuário {user_id}: Embeddings ausentes/inválidos. Faxina cancelada.")
                continue
            
            norms = np.linalg.norm(embs_matrix, axis=1, keepdims=True)
            norms[norms == 0] = 1e-12
            normalized_embs = embs_matrix / norms
            
            similarity_matrix = np.dot(normalized_embs, normalized_embs.T)
            
            # Clustering para este usuário
            visited = set()
            clusters_to_fuse = []
            
            for i in range(len(user_docs)):
                if i in visited:
                    continue
                
                current_cluster = [i]
                visited.add(i)
                
                for j in range(i + 1, len(user_docs)):
                    if j not in visited and similarity_matrix[i, j] >= similarity_threshold:
                        current_cluster.append(j)
                        visited.add(j)
                
                if len(current_cluster) > 1:
                    clusters_to_fuse.append(current_cluster)
            
            if not clusters_to_fuse:
                print(f"[InfyMemory Otimizador] Usuário {user_id}: Banco limpo. Nenhuma redundância alta detectada.")
                continue
            
            print(f"[InfyMemory Otimizador] Usuário {user_id}: Encontrados {len(clusters_to_fuse)} grupos redundantes. Iniciando fusão...")
            
            # Processar clusters deste usuário
            for cluster in clusters_to_fuse:
                redundant_texts = [user_docs[idx] for idx in cluster]
                ids_to_delete = [user_ids[idx] for idx in cluster]
                fused_facts = distiller.fuse_facts(redundant_texts)
                
                if fused_facts:
                    for new_fact in fused_facts:
                        vector_store.save_fact(new_fact, user_id, metadata={"fused": True})
                    
                    vector_store.delete_facts(ids_to_delete)
                    total_deleted += len(ids_to_delete)
        
        print(f"[InfyMemory Otimizador] Faxina concluída! {total_deleted} memórias antigas deletadas e substituídas por fatos limpos.")