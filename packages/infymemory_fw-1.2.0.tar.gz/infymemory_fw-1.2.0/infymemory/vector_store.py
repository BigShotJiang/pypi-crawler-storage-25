import chromadb
import time
from typing import Dict, Any, List

class InfyVectorStore:
    #Inicializa o cliente do ChromaDB e a coleção onde os fatos serão armazenados.
    def __init__(self, db_path: str = "./infy_db", collection_name: str = "infinite_memory"):
        self.client = chromadb.PersistentClient(path=db_path)
        
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
            embedding_function=embedding_function
        )
    
    def save_fact(self, text: str, user_id: str, metadata: dict = None):
        if metadata is None:
            metadata = {}
        
        memory_id = f"mem_{time.time_ns()}"
        metadata["timestamp"] = time.time()
        metadata["user_id"] = user_id
        
        self.collection.add(
            documents=[text],
            metadatas=[metadata],
            ids=[memory_id]
        )
    
    def search_raw(self, query: str, user_id: str, n_results: int = 20) -> Dict[str, Any]:
        results = self.collection.query(
            query_texts=[query],
            n_results=n_results,
            include=["documents", "embeddings", "metadatas"],
            where={"user_id": user_id}
        )
        return results

    def get_all_memory(self) -> Dict[str, Any]:
        """Puxa o banco de dados inteiro para a matriz matemática."""
        return self.collection.get(include=["documents", "embeddings", "metadatas"])

    def delete_facts(self, ids: List[str]):
        """Apaga memórias antigas ou redundantes do disco rígido."""
        if ids:
            self.collection.delete(ids=ids)