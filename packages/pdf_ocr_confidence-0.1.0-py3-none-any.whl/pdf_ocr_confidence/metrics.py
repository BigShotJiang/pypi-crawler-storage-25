"""Image quality metrics for OCR confidence estimation."""

from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np
from PIL import Image


@dataclass
class QualityMetrics:
    """Quality metrics for a PDF page image.
    
    Attributes:
        dpi: Dots per inch (resolution)
        blur_score: Laplacian variance (higher = sharper)
        contrast: Contrast ratio (0-1, higher = better)
        edge_density: Proportion of edge pixels (0-1)
        brightness: Average brightness (0-255)
    """
    
    dpi: float
    blur_score: float
    contrast: float
    edge_density: float
    brightness: float
    
    def to_dict(self):
        """Convert metrics to dictionary."""
        return {
            "dpi": self.dpi,
            "blur_score": self.blur_score,
            "contrast": self.contrast,
            "edge_density": self.edge_density,
            "brightness": self.brightness,
        }


def calculate_blur_score(image: np.ndarray) -> float:
    """Calculate blur score using Laplacian variance.
    
    Higher scores indicate sharper images.
    Typical thresholds: <100 = blurry, >100 = acceptable
    """
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = image
    
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    variance = laplacian.var()
    return float(variance)


def calculate_contrast(image: np.ndarray) -> float:
    """Calculate contrast ratio using histogram.
    
    Returns normalized contrast (0-1).
    """
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = image
    
    # Calculate histogram
    hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
    hist = hist.flatten()
    
    # Calculate cumulative distribution
    cdf = hist.cumsum()
    cdf_normalized = cdf / cdf[-1]
    
    # Find 5th and 95th percentiles
    p5 = np.searchsorted(cdf_normalized, 0.05)
    p95 = np.searchsorted(cdf_normalized, 0.95)
    
    # Contrast is the range normalized by max possible range
    contrast = (p95 - p5) / 255.0
    return float(contrast)


def calculate_edge_density(image: np.ndarray) -> float:
    """Calculate edge density using Canny edge detection.
    
    Returns proportion of edge pixels (0-1).
    """
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = image
    
    # Apply Canny edge detection
    edges = cv2.Canny(gray, 50, 150)
    
    # Calculate proportion of edge pixels
    edge_pixels = np.count_nonzero(edges)
    total_pixels = edges.size
    density = edge_pixels / total_pixels
    
    return float(density)


def calculate_brightness(image: np.ndarray) -> float:
    """Calculate average brightness.
    
    Returns value between 0-255.
    """
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = image
    
    return float(gray.mean())


def analyze_image_quality(
    image: Image.Image,
    dpi: Optional[float] = None
) -> QualityMetrics:
    """Analyze image quality metrics.
    
    Args:
        image: PIL Image object
        dpi: DPI if known, otherwise estimated from image size
        
    Returns:
        QualityMetrics object with all quality measurements
    """
    # Convert PIL to numpy array
    img_array = np.array(image)
    
    # Estimate DPI if not provided
    if dpi is None:
        # Assume 8.5x11 inch page (letter size)
        width_inches = 8.5
        dpi = image.width / width_inches
    
    # Calculate all metrics
    blur_score = calculate_blur_score(img_array)
    contrast = calculate_contrast(img_array)
    edge_density = calculate_edge_density(img_array)
    brightness = calculate_brightness(img_array)
    
    return QualityMetrics(
        dpi=dpi,
        blur_score=blur_score,
        contrast=contrast,
        edge_density=edge_density,
        brightness=brightness,
    )
