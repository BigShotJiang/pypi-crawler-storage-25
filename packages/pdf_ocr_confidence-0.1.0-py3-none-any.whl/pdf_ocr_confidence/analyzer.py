"""Core PDF analysis and confidence scoring."""

import io
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import List, Optional, Union

import fitz  # PyMuPDF
from PIL import Image

from .config import ConfidenceConfig
from .metrics import QualityMetrics, analyze_image_quality


class OCRRecommendation(str, Enum):
    """Recommendation for OCR processing."""
    
    NATIVE = "native"  # Has text layer, skip OCR
    CHEAP_OCR = "cheap_ocr"  # High quality, use fast/cheap OCR
    EXPENSIVE_OCR = "expensive_ocr"  # Low quality, use robust/expensive OCR


@dataclass
class PageResult:
    """Analysis result for a single page.
    
    Attributes:
        number: Page number (1-indexed)
        has_text: Whether page has extractable text
        confidence: Overall confidence score (0-1)
        quality_metrics: Detailed quality measurements
    """
    
    number: int
    has_text: bool
    confidence: float
    quality_metrics: Optional[QualityMetrics] = None
    
    def to_dict(self):
        """Convert to dictionary."""
        return {
            "number": self.number,
            "has_text": self.has_text,
            "confidence": self.confidence,
            "quality_metrics": self.quality_metrics.to_dict() if self.quality_metrics else None,
        }


@dataclass
class PDFConfidenceResult:
    """Complete analysis result for a PDF document.
    
    Attributes:
        confidence: Overall document confidence (0-1)
        recommendation: OCR processing recommendation
        pages: Per-page analysis results
        has_native_text: Whether document has any extractable text
    """
    
    confidence: float
    recommendation: OCRRecommendation
    pages: List[PageResult]
    has_native_text: bool
    
    def to_dict(self):
        """Convert to dictionary."""
        return {
            "confidence": self.confidence,
            "recommendation": self.recommendation.value,
            "has_native_text": self.has_native_text,
            "pages": [page.to_dict() for page in self.pages],
        }


def check_native_text(pdf_path: Union[str, Path]) -> bool:
    """Check if PDF has extractable text layer.
    
    Returns True if any page has meaningful text content.
    """
    doc = fitz.open(pdf_path)
    try:
        for page in doc:
            text = page.get_text().strip()
            # Check if there's substantial text (not just whitespace/artifacts)
            if len(text) > 50:  # Arbitrary threshold
                return True
        return False
    finally:
        doc.close()


def calculate_confidence_score(
    metrics: QualityMetrics,
    config: ConfidenceConfig
) -> float:
    """Calculate confidence score from quality metrics.
    
    Uses weighted combination of normalized metrics.
    Returns value between 0 and 1.
    """
    # Normalize each metric to 0-1 scale
    dpi_score = min(metrics.dpi / config.min_dpi, 1.0)
    blur_score = min(metrics.blur_score / config.blur_threshold, 1.0)
    contrast_score = min(metrics.contrast / config.min_contrast, 1.0)
    edge_score = min(metrics.edge_density / config.edge_threshold, 1.0)
    
    # Brightness penalty (too dark or too bright is bad)
    # Ideal brightness around 127, penalize extremes
    brightness_score = 1.0 - abs(metrics.brightness - 127) / 127
    
    # Weighted average (adjust weights based on importance)
    weights = {
        'dpi': 0.25,
        'blur': 0.30,
        'contrast': 0.20,
        'edge': 0.15,
        'brightness': 0.10,
    }
    
    confidence = (
        weights['dpi'] * dpi_score +
        weights['blur'] * blur_score +
        weights['contrast'] * contrast_score +
        weights['edge'] * edge_score +
        weights['brightness'] * brightness_score
    )
    
    return max(0.0, min(1.0, confidence))


def analyze_page(
    doc: fitz.Document,
    page_num: int,
    config: ConfidenceConfig
) -> PageResult:
    """Analyze a single PDF page.
    
    Args:
        doc: PyMuPDF document object
        page_num: Page number (0-indexed)
        config: Analysis configuration
        
    Returns:
        PageResult with confidence and metrics
    """
    page = doc[page_num]
    
    # Check for native text
    text = page.get_text().strip()
    has_text = len(text) > 50
    
    # If has native text, return high confidence
    if has_text:
        return PageResult(
            number=page_num + 1,
            has_text=True,
            confidence=1.0,
            quality_metrics=None,
        )
    
    # Render page to image
    # Use 150 DPI for analysis (balance between speed and accuracy)
    zoom = 150 / 72  # 72 is PDF default DPI
    mat = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=mat)
    
    # Convert to PIL Image
    img = Image.open(io.BytesIO(pix.tobytes("png")))
    
    # Analyze image quality
    metrics = analyze_image_quality(img, dpi=150)
    
    # Calculate confidence score
    confidence = calculate_confidence_score(metrics, config)
    
    return PageResult(
        number=page_num + 1,
        has_text=False,
        confidence=confidence,
        quality_metrics=metrics,
    )


def get_recommendation(
    confidence: float,
    has_native_text: bool,
    config: ConfidenceConfig
) -> OCRRecommendation:
    """Determine OCR recommendation based on confidence score."""
    if has_native_text:
        return OCRRecommendation.NATIVE
    elif confidence >= config.cheap_ocr_threshold:
        return OCRRecommendation.CHEAP_OCR
    else:
        return OCRRecommendation.EXPENSIVE_OCR


def analyze_pdf(
    pdf_path: Union[str, Path],
    config: Optional[ConfidenceConfig] = None
) -> PDFConfidenceResult:
    """Analyze a PDF file and return confidence score with recommendation.
    
    Args:
        pdf_path: Path to PDF file
        config: Configuration (uses defaults if None)
        
    Returns:
        PDFConfidenceResult with overall confidence, recommendation, and per-page details
    """
    if config is None:
        config = ConfidenceConfig()
    
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")
    
    # Quick check for native text
    has_native_text = check_native_text(pdf_path)
    
    # Open document
    doc = fitz.open(pdf_path)
    try:
        total_pages = len(doc)
        
        # Determine which pages to analyze
        if config.sample_pages is None:
            pages_to_analyze = range(total_pages)
        else:
            # Sample evenly distributed pages
            step = max(1, total_pages // config.sample_pages)
            pages_to_analyze = range(0, total_pages, step)[:config.sample_pages]
        
        # Analyze each page
        page_results = []
        for page_num in pages_to_analyze:
            result = analyze_page(doc, page_num, config)
            page_results.append(result)
        
        # Calculate overall confidence
        if has_native_text:
            overall_confidence = 1.0
        else:
            # Average confidence across analyzed pages
            confidences = [p.confidence for p in page_results]
            overall_confidence = sum(confidences) / len(confidences) if confidences else 0.0
        
        # Get recommendation
        recommendation = get_recommendation(overall_confidence, has_native_text, config)
        
        return PDFConfidenceResult(
            confidence=overall_confidence,
            recommendation=recommendation,
            pages=page_results,
            has_native_text=has_native_text,
        )
    
    finally:
        doc.close()
