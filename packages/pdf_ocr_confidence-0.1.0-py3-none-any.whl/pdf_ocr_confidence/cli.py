#!/usr/bin/env python3
"""Command-line interface for pdf-ocr-confidence."""

import argparse
import json
import sys
from pathlib import Path

from .analyzer import analyze_pdf
from .config import ConfidenceConfig


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Estimate OCR confidence for PDF files"
    )
    parser.add_argument(
        "pdf",
        type=Path,
        help="Path to PDF file",
    )
    parser.add_argument(
        "--expensive-threshold",
        type=float,
        default=0.4,
        help="Threshold for expensive OCR recommendation (default: 0.4)",
    )
    parser.add_argument(
        "--cheap-threshold",
        type=float,
        default=0.7,
        help="Threshold for cheap OCR recommendation (default: 0.7)",
    )
    parser.add_argument(
        "--sample-pages",
        type=int,
        help="Number of pages to sample (default: all pages)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Show detailed per-page metrics",
    )
    
    args = parser.parse_args()
    
    # Validate PDF exists
    if not args.pdf.exists():
        print(f"Error: File not found: {args.pdf}", file=sys.stderr)
        sys.exit(1)
    
    # Create config
    config = ConfidenceConfig(
        expensive_ocr_threshold=args.expensive_threshold,
        cheap_ocr_threshold=args.cheap_threshold,
        sample_pages=args.sample_pages,
    )
    
    # Analyze PDF
    try:
        result = analyze_pdf(args.pdf, config=config)
    except Exception as e:
        print(f"Error analyzing PDF: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Output results
    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print(f"PDF: {args.pdf.name}")
        print(f"Confidence: {result.confidence:.2%}")
        print(f"Recommendation: {result.recommendation.value}")
        print(f"Has Native Text: {'Yes' if result.has_native_text else 'No'}")
        
        if args.verbose:
            print(f"\nPages Analyzed: {len(result.pages)}")
            for page in result.pages:
                print(f"\n  Page {page.number}:")
                print(f"    Confidence: {page.confidence:.2%}")
                if page.quality_metrics:
                    m = page.quality_metrics
                    print(f"    DPI: {m.dpi:.1f}, Blur: {m.blur_score:.1f}, "
                          f"Contrast: {m.contrast:.2%}")
    
    # Exit code based on recommendation
    if result.recommendation.value == "native":
        sys.exit(0)  # Success - no OCR needed
    elif result.recommendation.value == "cheap_ocr":
        sys.exit(1)  # Use cheap OCR
    else:
        sys.exit(2)  # Use expensive OCR


if __name__ == "__main__":
    main()
