"""Configuration for OCR confidence analysis."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class ConfidenceConfig:
    """Configuration for PDF OCR confidence analysis.
    
    Attributes:
        expensive_ocr_threshold: Below this score, recommend expensive OCR (0-1)
        cheap_ocr_threshold: Above this score, recommend cheap OCR (0-1)
        sample_pages: Number of pages to analyze (None = all pages)
        min_dpi: Minimum acceptable DPI for good OCR
        min_contrast: Minimum contrast ratio (0-1)
        blur_threshold: Laplacian variance threshold for blur detection
        edge_threshold: Minimum edge density for clear text
    """
    
    expensive_ocr_threshold: float = 0.4
    cheap_ocr_threshold: float = 0.7
    sample_pages: Optional[int] = None
    min_dpi: float = 150.0
    min_contrast: float = 0.3
    blur_threshold: float = 100.0
    edge_threshold: float = 0.05
    
    def __post_init__(self):
        """Validate configuration values."""
        if not 0 <= self.expensive_ocr_threshold <= 1:
            raise ValueError("expensive_ocr_threshold must be between 0 and 1")
        if not 0 <= self.cheap_ocr_threshold <= 1:
            raise ValueError("cheap_ocr_threshold must be between 0 and 1")
        if self.expensive_ocr_threshold >= self.cheap_ocr_threshold:
            raise ValueError("expensive_ocr_threshold must be less than cheap_ocr_threshold")
        if self.sample_pages is not None and self.sample_pages < 1:
            raise ValueError("sample_pages must be at least 1")
