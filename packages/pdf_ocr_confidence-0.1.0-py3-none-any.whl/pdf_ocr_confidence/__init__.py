"""PDF OCR Confidence - Estimate OCR quality before running expensive models."""

from .analyzer import analyze_pdf, PDFConfidenceResult, PageResult
from .config import ConfidenceConfig
from .metrics import QualityMetrics

__version__ = "0.1.0"
__all__ = [
    "analyze_pdf",
    "PDFConfidenceResult",
    "PageResult",
    "ConfidenceConfig",
    "QualityMetrics",
]
